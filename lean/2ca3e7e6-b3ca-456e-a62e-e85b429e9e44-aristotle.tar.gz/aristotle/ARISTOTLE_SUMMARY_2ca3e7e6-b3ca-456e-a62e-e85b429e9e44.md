# Summary of changes
Filled all 3 sorry gaps in `SKEFTHawking/CGLTransform.lean`:

1. **`cgl_fdr_general`**: Used `rw [← h_fdr, mul_div_cancel_right₀ _ hb.ne']` to rewrite the goal `noise = -b / beta` into `noise = noise * beta / beta` and cancel.

2. **`cgl_fdr_spatial`**: Same proof as `cgl_fdr_general` (identical structure).

3. **`cgl_implies_secondOrderKMS`**: Used `linarith` to chain the 5 linear hypotheses (`h_cgl`, `h_trev_12`, `h_trev_30`, `h_model_1`, `h_model_3`) to conclude `j_tx * beta = s_1 + s_3`.

The file builds successfully with no remaining sorries.