import pathlib,subprocess,hashlib,json
root=pathlib.Path('/private/tmp/skeft-phase6ee-alignment.rdkc68tx/SK_EFT_Hawking');base='83dac57c6936bded796624bd34069e7366f25f03'
def source_code(s):
 out=[];i=0;depth=0;quoted=False
 while i<len(s):
  if depth:
   if s.startswith('/-',i): depth+=1;i+=2
   elif s.startswith('-/',i):depth-=1;i+=2
   else:i+=1
  elif quoted:
   out.append(s[i])
   if s[i]=='\\' and i+1<len(s):out.append(s[i+1]);i+=2;continue
   if s[i]=='"':quoted=False
   i+=1
  elif s.startswith('/-',i):depth=1;i+=2
  elif s.startswith('--',i):
   j=s.find('\n',i);i=len(s) if j<0 else j
  elif s[i]=='"':quoted=True;out.append(s[i]);i+=1
  else:
   if not s[i].isspace():out.append(s[i])
   i+=1
 assert depth==0 and not quoted
 return ''.join(out).encode()
files=subprocess.check_output(['git','diff','--name-only',base],cwd=root,text=True).splitlines();rows=[]
for f in files:
 if not f.endswith('.lean'):continue
 old=subprocess.check_output(['git','show',base+':'+f],cwd=root).decode();new=(root/f).read_text();a=source_code(old);b=source_code(new);assert a==b,f
 rows.append({'path':f,'code_bytes':len(a),'unchanged_code_sha256':hashlib.sha256(a).hexdigest(),'candidate_file_sha256':hashlib.sha256(new.encode()).hexdigest()})
assert len(rows)==3
# Counts are derived from the unchanged canonical catalog, not native rereadback.
z=json.loads((root/'lean/lean_deps.json').read_bytes());counts={m:sum(r.get('module')=='SKEFTHawking.Control.'+m for r in z) for m in ['RotatingWave','BanachAveraging','DriveCalibration','CompositeReadoutCeilings']}
assert counts==dict(RotatingWave=117,BanachAveraging=8,DriveCalibration=45,CompositeReadoutCeilings=44)
assert not subprocess.check_output(['git','diff',base,'--','lean/lean_deps.json','lean/lean_deps.json.hash'],cwd=root)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print(json.dumps({'base':base,'scope':files,'lean_noncomment_source_identity':rows,'canonical_module_entries':counts,'fresh_build':False,'catalog_regenerated':False},indent=2))
