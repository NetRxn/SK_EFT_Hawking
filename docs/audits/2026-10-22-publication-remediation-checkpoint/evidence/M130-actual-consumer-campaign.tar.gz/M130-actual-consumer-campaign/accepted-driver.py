"""DATA ONLY: M108 complete child fault envelope; no science execution grant.
Requires a fresh explicit ROOT execution configuration and canonical FIRST/MODEL.
The author has neither imported nor executed this file.
"""
from pathlib import Path
import ast, base64, datetime, hashlib, importlib.util, json, os, re, subprocess, sys, time, traceback
import xml.etree.ElementTree as ET

def _owned_test_child(argv, cwd, env, stdout, stderr, row, record,
                      clock=time.monotonic, diagnostic_deadline=900,
                      terminal_clock=None, owned_handles=None):
    """Wait the exact child before propagating the original first fault."""
    started = clock()
    primary = None
    secondary = []
    fault_events = []
    returncode = None
    def remember(operation, info):
        nonlocal primary
        if primary is None:
            primary = info
        else:
            secondary.append(info)
        fault_events.append((operation, info))
    def attempt(operation, action):
        try:
            return action()
        except BaseException:
            remember(operation, sys.exc_info())
            return None
    process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    try:
        if owned_handles is not None:
            owned_handles.append(process)
        row.update(pid=process.pid, status="RUNNING")
        record()
        while returncode is None:
            try:
                returncode = process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                if clock() - started > diagnostic_deadline:
                    row["diagnostic_deadline_exceeded"] = True
                    record()
    except BaseException:
        remember("owned-child-body", sys.exc_info())
    finally:
        while returncode is None:
            try:
                returncode = process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                continue
            except BaseException:
                remember("natural-wait", sys.exc_info())
        # Actual wait/returncode above is authoritative; row writes are diagnostics.
        attempt("terminal-row", lambda: row.update(returncode=returncode, status="TERMINAL"))
        def timestamp():
            value = (terminal_clock() if terminal_clock is not None else
                     datetime.datetime.now(datetime.timezone.utc).isoformat())
            row["ended"] = value
        attempt("terminal-timestamp", timestamp)
        def fault_summary():
            row["first_child_fault_type"] = None if primary is None else type(primary[1]).__name__
            row["secondary_child_fault_types"] = [type(x[1]).__name__ for x in secondary]
            row["child_fault_operations"] = [x[0] for x in fault_events]
        attempt("terminal-fault-summary", fault_summary)
        attempt("terminal-record", record)
        # Best effort only: failure here is retained natively, never rethrows itself.
        attempt("final-fault-summary", fault_summary)
    if primary is not None:
        raise primary[1].with_traceback(primary[2])
    return returncode

def main():
    assert len(sys.argv) == 2, "Fresh ROOT execution configuration required"
    cfg_path = Path(sys.argv[1]).resolve()
    cfg = json.loads(cfg_path.read_text())
    assert cfg["explicit_ROOT_execution_grant"] is True
    assert cfg["whole_M122_consumer_DATA_intake_accepted"] is True
    assert cfg["exclusive_current_M_consumer_campaign_admission"] is True
    assert cfg["consumer_actual_cause_observer_review_required"] is True
    plan_path = Path(cfg["control_plan"]).resolve()
    plan_raw = plan_path.read_bytes()
    sha = lambda raw: hashlib.sha256(raw).hexdigest()
    assert sha(plan_raw) == cfg["accepted_control_plan_sha256"]
    plan = json.loads(plan_raw)
    m = Path(plan["intended_checkout"])
    p = Path(plan["primary"])
    targets = {row["target"]: row for row in plan["source_owners"]}
    test = m / "tests/test_graphene_consumer_propagation.py"
    o = Path(cfg["output_directory"]).resolve()
    assert o.is_relative_to(m / "outputs/continuity")
    assert (o / "FIRST.json").is_file() and (o / "MODEL.md").is_file()
    first = json.loads((o / "FIRST.json").read_text())
    assert first["returncode"] == 0 and json.loads(first["stdout"])["fresh"]
    packet = Path(cfg["canonical_execution_packet"]).resolve()
    assert first["argv"][-1] == str(packet)
    assert not (o / "runtime.json").exists()
    env = {k:v for k,v in os.environ.items() if k not in
           ["PYTHONPATH", "PYTHONHOME", "PYTEST_ADDOPTS", "VIRTUAL_ENV", "UV_PROJECT_ENVIRONMENT"]}
    env.update(GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1")
    os.environ["GIT_OPTIONAL_LOCKS"] = "0"
    now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
    def module(name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        value = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(value)
        return value
    # Existing passive custody helper and existing durable journal only.
    helper = Path(cfg["existing_passive_custody_helper"])
    assert sha(helper.read_bytes()) == cfg["existing_passive_custody_helper_sha256"]
    C = module("metric_campaign_custody", helper)
    def all_source_owners_exact():
        for relative, row in targets.items():
            current = m / relative
            assert current.read_bytes() == base64.b64decode(row["before_base64"])
            assert C.state(current) == row["before_state"]
        assert sha((m / "src/core/formulas.py").read_bytes()) == plan["canonical_formula_sha256"]
        assert sha(test.read_bytes()) == plan["consumer_test_sha256"]
    all_source_owners_exact()
    templates = cfg["fresh_current_custody_templates"]
    assert set(templates) == {"M", "T", "P", "B"}
    # These are taken only under this new ROOT exclusive grant, never M104's live phase.
    before = {k:C.snapshot(v["root"], v) for k,v in templates.items()}
    references_before = {f:C.state(Path(f)) for f in cfg["held_references"]}
    assert before == templates, "External accepted current custody, never self-rebaseline"
    assert references_before == cfg["held_reference_states"]
    d = dict(task=cfg["task"], status="RUNNING", started=now(), driver_pid=os.getpid(),
             driver_executable=sys.executable, driver_prefix=sys.prefix,
             execution_configuration=str(cfg_path), canonical_execution_packet=str(packet),
             plan_sha256=sha(plan_raw), children=[], controls=[], custody_before=before,
             references_before=references_before,
             earlier_M120=cfg["M120_terminal_receipt"],
             actual_scientific_cause_acceptance="PENDING_FULL_NONAUTHOR_REVIEW")
    def save():
        (o / "runtime.json").write_text(json.dumps(d, indent=2) + "\n")
    def current_custody(label):
        after = {k:C.snapshot(v["root"], v) for k,v in templates.items()}
        refs = {f:C.state(Path(f)) for f in cfg["held_references"]}
        assert after == before and refs == references_before, label
        all_source_owners_exact()
        # Retain full bodies, not only a success bit.
        d.setdefault("custody_checkpoints", []).append(
            dict(label=label, at=now(), roots=after, references=refs))
        save()
    owned_child_handles = []
    def child(label, args, selectors=None):
        cache = Path("/private/tmp") / ("publication-metric-empty-bytecode-" + str(os.getpid()) + "-" + label)
        assert not cache.exists()
        argv = [str(m / ".venv/bin/python"), "-B", "-X", "pycache_prefix=" + str(cache), *args]
        row = dict(label=label, argv=argv, cwd=str(m), started=now(),
                   status="STARTING", selectors=selectors, bytecode_lookup_prefix=str(cache),
                   raw_stdout=str(o / (label + ".stdout")), raw_stderr=str(o / (label + ".stderr")),
                   junitxml=None if selectors is None else str(o / (label + ".xml")))
        d["children"].append(row); save()
        primary_child_fault = None
        secondary_child_faults = []
        so = se = None
        try:
            so = (o / (label + ".stdout")).open("xb")
            se = (o / (label + ".stderr")).open("xb")
            rc = _owned_test_child(argv, m, env, so, se, row, save,
                                   owned_handles=owned_child_handles)
        except BaseException:
            primary_child_fault = sys.exc_info()
        finally:
            for stream in (se, so):
                if stream is not None:
                    try:
                        stream.close()
                    except BaseException:
                        if primary_child_fault is None:
                            primary_child_fault = sys.exc_info()
                        else:
                            secondary_child_faults.append(sys.exc_info())
        if primary_child_fault is not None:
            raise primary_child_fault[1].with_traceback(primary_child_fault[2])
        row.update(returncode=rc, status="TERMINAL", ended=now(),
                   stdout_sha256=sha((o / (label + ".stdout")).read_bytes()),
                   stderr_sha256=sha((o / (label + ".stderr")).read_bytes()))
        assert not cache.exists(), "No bytecode writes are permitted"
        if selectors is not None:
            cases = []
            for tc in ET.parse(o / (label + ".xml")).iter("testcase"):
                failure, error, skip = tc.find("failure"), tc.find("error"), tc.find("skipped")
                status = "error" if error is not None else "skipped" if skip is not None else "failed" if failure is not None else "passed"
                cases.append(dict(classname=tc.get("classname"), name=tc.get("name"), status=status,
                                  failure=None if failure is None else failure.text,
                                  failure_message=None if failure is None else failure.get("message"),
                                  error=None if error is None else error.text))
            row["cases"] = cases
            row["summary"] = {k:sum(c["status"] == k for c in cases)
                              for k in ["passed", "failed", "error", "skipped"]}
        save()
        print(json.dumps(dict(label=label, pid=row["pid"], returncode=rc,
                              summary=row.get("summary"), raw_stdout=str(o / (label + ".stdout")),
                              raw_stderr=str(o / (label + ".stderr")))), flush=True)
        assert not row.get("diagnostic_deadline_exceeded"), "Settled over-deadline child is failure; no dependent work"
        return row
    def tests(label, selectors, full=False):
        nodes = ["tests/test_graphene_metric.py", "tests/test_bilayer_two_band_state.py",
                 "tests/test_graphene_consumer_propagation.py"] if full else [
                 "tests/test_graphene_consumer_propagation.py"]
        assert selectors == ([":FULL520:"] if full else [":FULL11:"])
        return child(label, ["-m", "pytest", "-q", "-s", "--tb=long", "-p", "no:cacheprovider",
                             *nodes, "--junitxml=" + str(o / (label + ".xml"))], selectors)
    identities = lambda row: [[c["classname"], c["name"]] for c in row["cases"]]
    def green(row, expected):
        assert row["returncode"] == 0 and identities(row) == expected
        assert row["summary"] == dict(passed=len(expected), failed=0, error=0, skipped=0)
    def red_exact(row, rec):
        assert row["returncode"] == 1 and identities(row) == rec["expected_selected_ordered_IDs"]
        assert row["summary"] == rec["expected_red_summary"]
        assert sha(test.read_bytes()) == plan["consumer_test_sha256"]
        for actual, expected in zip(row["cases"], rec["per_case_causal_bindings"]):
            assert actual["status"] == expected["expected_status"]
            assert actual["error"] is None
            if actual["status"] == "passed":
                assert actual["failure"] is None
                continue
            body = actual["failure"] or ""
            matches = list(re.finditer(r"(?m)^((?:src|tests)/[^:\n]+):(\d+): (\w+)\s*$", body))
            assert matches
            terminal = expected["prospective_terminal"]
            assert (matches[-1][1], int(matches[-1][2]), matches[-1][3]) == (
                terminal["path"], terminal["line"], terminal["kind"])
            assert terminal["kind"] == expected["expected_failure_kind"] == "AssertionError"
            assert terminal["source_line"].strip() in body
            message = actual["failure_message"]
            assert isinstance(message, str) and "\r" not in message and "\x00" not in message
            message_lines = message.split("\n")
            head = message_lines[0]
            assert re.fullmatch(r"(?:AssertionError: )?assert \S[^\r\n]*", head)
            assert all(re.fullmatch(r" \+ +(?:where|and) +\S[^\r\n]*", line)
                       for line in message_lines[1:])
            # Validate a derived header view only; keep original raw message/body unchanged.
            assertion_header = head[16:] if head.startswith("AssertionError: ") else head
            try:
                header_tree = ast.parse(assertion_header, mode="exec")
            except SyntaxError as exc:
                raise AssertionError("Malformed raw assertion header") from exc
            assert len(header_tree.body) == 1 and isinstance(header_tree.body[0], ast.Assert)
            assert header_tree.body[0].msg is None
            assert all(line in body for line in message_lines)
            for expression in expected["required_unchanged_test_expression_fragments"]:
                assert expression in body
            # No invented historical transcript or automatic acceptance of unseen causes.
            # Store complete actual first-fault body/message/terminal/input diagnostics.
            actual["prospective_structural_binding_passed"] = True
            actual["whole_nonauthor_cause_acceptance"] = "REQUIRED_NOT_ESTABLISHED"
    save()
    J = None
    try:
        current_custody("entry")
        origin_code = (
            "import json,sys;from pathlib import Path;import src.core.formulas as F;"
            "import tests.test_graphene_consumer_propagation as T;import scripts.seed_journal as J;"
            "import src.graphene.bilayer_eos as E;import src.core.visualizations as V;"
            "import scripts.paper_tables.sources as S;"
            "import pytest,numpy,mpmath;print(json.dumps(dict(executable=sys.executable,"
            "prefix=sys.prefix,cwd=str(Path.cwd()),formulas=str(Path(F.__file__).resolve()),"
            "tests=str(Path(T.__file__).resolve()),journal=str(Path(J.__file__).resolve()),"
            "pytest=pytest.__file__,numpy=numpy.__file__,mpmath=mpmath.__file__,"
            "dont_write_bytecode=sys.dont_write_bytecode,"
            "source_sha256=__import__('hashlib').sha256(Path(F.__file__).read_bytes()).hexdigest(),"
            "consumer_modules=[dict(path=str(Path(x.__file__).resolve()),sha256=__import__('hashlib').sha256(Path(x.__file__).read_bytes()).hexdigest()) for x in (E,V,S)],"
            "consumer_specs=[dict(path=str(Path('papers/paper16_graphene_sk_eft/tables.py').resolve()),sha256=__import__('hashlib').sha256(Path('papers/paper16_graphene_sk_eft/tables.py').read_bytes()).hexdigest())])))"
        )
        origin_child = child("origins", ["-c", origin_code])
        assert origin_child["returncode"] == 0
        origin = json.loads((o / "origins.stdout").read_text())
        assert origin["executable"] == str(m / ".venv/bin/python") and origin["prefix"] == str(m / ".venv")
        assert origin["cwd"] == str(m) and origin["formulas"] == str(m / "src/core/formulas.py")
        assert origin["tests"] == str(test) and origin["journal"] == str(m / "scripts/seed_journal.py")
        assert origin["dont_write_bytecode"] is True and origin["source_sha256"] == plan["canonical_formula_sha256"]
        for name in ["pytest", "numpy", "mpmath"]: assert str(m / ".venv") + "/" in origin[name]
        assert {row["path"]: row["sha256"] for row in origin["consumer_modules"] + origin["consumer_specs"]} == {
            str(m / relative): row["before_state"]["sha256"] for relative, row in targets.items()}
        d["actual_origin"] = origin; save()
        sys.path.insert(0, str(m))
        from scripts import seed_journal as J
        assert Path(J.__file__).resolve() == m / "scripts/seed_journal.py"
        assert J.outstanding(include_live=True) == []
        full = tests("initial-full520", [":FULL520:"], full=True)
        green(full, plan["expected_full520_ordered_IDs"])
        assert identities(full)[:509] == plan["expected_original509_ordered_IDs"]
        assert identities(full)[:470] == plan["expected_metric470_ordered_IDs"]
        current_custody("initial-full520")
        for rec in plan["controls"]:
            label = rec["id"]
            assert re.fullmatch("[A-Za-z0-9-]+", label)
            assert J.outstanding(include_live=True) == []
            target = m / rec["target"]
            original = base64.b64decode(rec["before_base64"])
            original_state = rec["before_state"]
            baseline = tests(label + "-baseline", [":FULL11:"])
            green(baseline, rec["expected_selected_ordered_IDs"])
            current_custody(label + "-baseline")
            mutant = base64.b64decode(rec["mutant_base64"])
            assert sha(mutant) == rec["mutant_sha256"]
            assert target.read_bytes() == original and C.state(target) == original_state
            control = dict(id=label, selectors=[":FULL11:"], baseline=baseline["summary"],
                           original_state=original_state, mutant_sha256=sha(mutant), status="PREPARED")
            d["controls"].append(control); save()
            red_problem = None
            try:
                with J.seeded_mutation(target, mutant, reason=cfg["task"] + " real producer " + label) as returned:
                    assert returned == original
                    live = [q for q in J.outstanding(include_live=True)
                            if q.get("path") == str(target) and q.get("pid") == os.getpid()]
                    assert len(live) == 1 and live[0]["live"]
                    assert Path(live[0]["backup"]).read_bytes() == original
                    assert target.read_bytes() == mutant
                    control.update(live_journal=live, mutant_state=C.state(target), status="LIVE_REAL_PRODUCTION_SEED"); save()
                    red = tests(label + "-red", [":FULL11:"])
                    control["actual_red"] = red["summary"]; save()
                    red_exact(red, rec)
                    control["prospective_per_case_structural_binding_passed"] = True
                    control["whole_actual_scientific_cause_review"] = "REQUIRED_NOT_ESTABLISHED"; save()
            except BaseException as exc:
                red_problem = exc
                control["red_or_seed_failure"] = dict(type=type(exc).__name__, detail=str(exc), traceback=traceback.format_exc())
                save()
            finally:
                # child() never returns/raises while its owned child is live.
                assert all(handle.returncode is not None for handle in owned_child_handles)
                assert target.read_bytes() == original and C.state(target) == original_state
                assert J.outstanding(include_live=True) == []
                control.update(restored_state=C.state(target), journal_empty_after=True); save()
                restored = tests(label + "-restored", [":FULL11:"])
                green(restored, rec["expected_selected_ordered_IDs"])
                control["restored"] = restored["summary"]; save()
                current_custody(label + "-restored")
            if red_problem is not None:
                raise red_problem
            control.update(status="RESTORED_HEALTHY_PENDING_FULL_CAUSE_REVIEW",
                           actual_green_structural_red_restored_green=True); save()
        final = tests("final-full520", [":FULL520:"], full=True)
        green(final, plan["expected_full520_ordered_IDs"])
        assert identities(final)[:509] == plan["expected_original509_ordered_IDs"]
        assert identities(final)[:470] == plan["expected_metric470_ordered_IDs"]
        current_custody("final-full520")
        d.update(status="CONSUMER_STRUCTURAL_CAMPAIGNS_PENDING_EXACT_ACTUAL_CAUSE_REVIEW", ended=now()); save()
    except BaseException as exc:
        d.update(status="FAILED_PRESERVED_DEPENDENTS_STOPPED", ended=now(),
                 error=dict(type=type(exc).__name__, detail=str(exc), traceback=traceback.format_exc()))
        save()
    # ROOT execution wrapper owns final custody reconciliation, complete manifest,
    # and ONE canonical FINAL after this natural terminal; never a source reset.
    d["execution_wrapper_still_owes"] = [
        "Personally read all raw XML/streams/source/input/terminal evidence",
        "Verify exact restored source/full mode/nsmtime and empty durable journal",
        "Save complete current custody/reference effects and all artifact hashes",
        "Complete report/commands/evidence/manifest before ONE canonical FINAL",
        "Obtain genuine nonauthor complete actual-evidence review and ROOT intake"
    ]
    save()
    print(json.dumps(dict(status=d["status"], children=len(d["children"]),
                          controls=len(d["controls"]), output_directory=str(o))), flush=True)
    return 0 if d["status"] == "CONSUMER_STRUCTURAL_CAMPAIGNS_PENDING_EXACT_ACTUAL_CAUSE_REVIEW" else 1

if __name__ == "__main__":
    sys.exit(main())
