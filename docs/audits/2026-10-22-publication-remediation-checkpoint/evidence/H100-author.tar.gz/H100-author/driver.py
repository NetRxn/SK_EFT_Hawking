"""UNGRANTED H100 full-module driver SOURCE DATA; independent review and ROOT release required.

This file has not been imported, compiled, collected or executed by its author.
The existing test owners retain all fixture/native/SAME/cleanup authority.
"""
from pathlib import Path
import argparse
import base64
import datetime
import hashlib
import json
import os
import stat
import struct
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

W = Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research')
P = W / 'SK_EFT_Hawking'
I = W / '.codex-python-worktrees/publication-integrated-science-20261019'
AUTHOR = I / 'outputs/continuity/hook-H99-complete-current-admission-repair-author-20261022-r100'
RELEASE = P / '.codex/continuity/publication-hook-H100-full-module-exact-runtime-release-20261022-r1.json'
SCOPE = 'H100_ONE_CURRENT_UNFILTERED_HOOK_MODULE_QUALIFICATION'
UNOBSERVED = object()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def state(path):
    p = Path(path)
    try:
        s = p.lstat()
    except FileNotFoundError:
        return {'kind': 'missing'}
    kind = 'directory' if stat.S_ISDIR(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'file'
    row = dict(kind=kind, mode=s.st_mode, mtime_ns=s.st_mtime_ns, size=s.st_size)
    if kind == 'file':
        row['sha256'] = sha(p.read_bytes())
    if kind == 'symlink':
        row['target'] = os.readlink(p)
    return row


def index_semantics(path):
    raw = Path(path).read_bytes()
    magic, version, count = struct.unpack('>4sII', raw[:12])
    require(magic == b'DIRC' and version == 2, 'Unreviewed index encoding')
    require(hashlib.sha1(raw[:-20]).digest() == raw[-20:], 'Index checksum differs')
    pos = 12
    rows = []
    for _ in range(count):
        begin = pos
        fields = struct.unpack('>10I20sH', raw[pos:pos + 62])
        pos += 62
        require(not fields[-1] & 0x4000, 'Extended index flags unreviewed')
        end = raw.index(b'\0', pos)
        name = raw[pos:end]
        mode, oid, stage = fields[6], fields[10].hex(), (fields[11] >> 12) & 3
        rows.append(('%06o %s %d\t' % (mode, oid, stage)).encode() + name + b'\0')
        pos = begin + ((end + 1 - begin + 7) // 8) * 8
    semantic = b''.join(rows)
    return dict(path=str(path), version=version, entries=count,
                raw_sha256=sha(raw), semantic_sha256=sha(semantic), semantic_bytes=len(semantic))


def fixed_snapshot(config):
    known = {}
    for label, root in config['known_custody'].items():
        known[label] = dict(root=root['root'],
                           sources={name: state(Path(root['root']) / name) for name in root['sources']},
                           admin={name: state(name) for name in root['admin']})
    return dict(known_custody=known,
                loose_refs={name: state(name) for name in config['loose_refs']},
                resolved_refs=resolved_refs(config),
                indexes={name: index_semantics(row['path']) for name, row in config['indexes'].items()},
                pins={name: state(name) for name in config['pins']})


def expected_snapshot(config):
    return {key: config[key] for key in ('known_custody', 'loose_refs', 'resolved_refs', 'indexes', 'pins')}


def resolved_refs(config):
    """Resolve only the retained name population and explicitly known loose paths."""
    packed = {}
    for line in (P / '.git/packed-refs').read_text().splitlines():
        if line and not line.startswith(('#', '^')):
            oid, name = line.split(' ', 1)
            packed[name] = oid
    names = [line.split(' ', 1)[0] for line in config['resolved_refs']['text'].splitlines()]
    def resolve(name, seen):
        require(name not in seen and name in names, 'Unknown/cyclic retained symbolic target')
        path = P / '.git' / name
        if str(path) in config['loose_refs'] and config['loose_refs'][str(path)]['kind'] == 'file':
            text = path.read_text().strip()
            if text.startswith('ref: '):
                target = text[5:]
                return resolve(target, seen + [name])[0], target
            return text, ''
        require(name in packed, 'Retained ref absent from known loose/packed population')
        return packed[name], ''
    text = ''.join('%s %s %s\n' % (name, *resolve(name, [])) for name in names)
    return dict(count=len(names), text=text, sha256=sha(text.encode()))


def freeze(value):
    if type(value) is bytes:
        return dict(type='bytes', bytes=len(value), sha256=sha(value), base64=base64.b64encode(value).decode('ascii'))
    if value is None or type(value) in (str, int, float, bool):
        return value
    if type(value) in (tuple, list):
        return dict(type=type(value).__name__, items=[freeze(x) for x in value])
    return dict(type=type(value).__module__ + '.' + type(value).__qualname__, unsupported=True)


class Faults:
    """Native exception tuples precede all formatting, timestamps and disk work."""
    def __init__(self):
        self.first = None
        self.rows = []

    def caught(self, operation):
        info = sys.exc_info()
        row = [operation, info, None]
        if self.first is None:
            self.first = row
        self.rows.append(row)
        try:
            row[2] = time.monotonic_ns()
        except BaseException:
            self.rows.append(['fault-timestamp', sys.exc_info(), None])

    def attempt(self, operation, function, *args, **kwargs):
        try:
            return function(*args, **kwargs)
        except BaseException:
            self.caught(operation)
            return UNOBSERVED

    def data(self):
        rows = []
        for operation, (kind, error, tb), observed in self.rows:
            frames = []
            while tb is not None:
                frames.append(dict(filename=tb.tb_frame.f_code.co_filename,
                                   function=tb.tb_frame.f_code.co_name, line=tb.tb_lineno))
                tb = tb.tb_next
            rows.append(dict(operation=operation, object_id=id(error),
                             type=kind.__module__ + '.' + kind.__qualname__,
                             arguments=freeze(BaseException.args.__get__(error)),
                             observed_monotonic_ns=observed, traceback=frames))
        return rows

    def propagate(self):
        if self.first is not None:
            kind, error, tb = self.first[1]
            raise error.with_traceback(tb)


def write_new(path, raw):
    with Path(path).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def json_new(path, value):
    write_new(path, (json.dumps(value, indent=2) + '\n').encode())


def journal(output, name, value):
    """Only the current task's diagnostic row is replaced; old raw channels stay exclusive."""
    raw = (json.dumps(value, indent=2) + '\n').encode()
    temporary = output / (name + '.next')
    write_new(temporary, raw)
    os.replace(temporary, output / name)


def own_child(output, env, label, args, children, faults):
    """The sole retained Popen owns natural settlement even after diagnostic failure."""
    q = so = se = None
    row = dict(label=label, pid=None, status='NOT_LAUNCHED', returncode=None,
               started=None, ended=None, natural_terminal=False)
    children.append(row)
    try:
        cold = output / ('cache/absent-pycache-' + label)
        require(not cold.exists(), 'Cold lookup prefix already exists')
        argv = [str(P / '.venv/bin/python'), '-B', '-X', 'pycache_prefix=' + str(cold), *args]
        row.update(argv=argv, cwd=str(I), started=utc(), cold_prefix=str(cold), cold_absent_before=True)
        journal(output, 'children.json', children)
        so = (output / (label + '.stdout')).open('xb')
        se = (output / (label + '.stderr')).open('xb')
        q = subprocess.Popen(argv, cwd=I, env=env, stdout=so, stderr=se)
        row.update(pid=q.pid, status='RUNNING')
        journal(output, 'children.json', children)
    except BaseException:
        faults.caught(label + ':launch-or-initial-diagnostics')
    finally:
        if q is not None:
            # TimeoutExpired is only a progress interval. No signal, restart or restoration follows it.
            while q.returncode is None:
                try:
                    q.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    def progress():
                        row.update(last_observed=utc(), stdout_bytes=(output / (label + '.stdout')).stat().st_size,
                                   stderr_bytes=(output / (label + '.stderr')).stat().st_size)
                        journal(output, 'children.json', children)
                    faults.attempt(label + ':progress', progress)
                except BaseException:
                    faults.caught(label + ':natural-wait')
            # Actual stored native returncode is reserved before fallible metadata/IO.
            row['returncode'] = q.returncode
            row['natural_terminal'] = True
            row['status'] = 'TERMINAL'
            def terminal():
                row.update(ended=utc(), cold_absent_after=not cold.exists())
            faults.attempt(label + ':terminal-metadata', terminal)
        for name, stream in (('stderr', se), ('stdout', so)):
            if stream is not None:
                faults.attempt(label + ':' + name + ':flush', stream.flush)
                faults.attempt(label + ':' + name + ':fsync', lambda stream=stream: os.fsync(stream.fileno()))
                faults.attempt(label + ':' + name + ':close', stream.close)
        def final_record():
            for channel in ('stdout', 'stderr'):
                path = output / (label + '.' + channel)
                row[channel] = state(path)
            row['driver_faults'] = faults.data()
            journal(output, 'children.json', children)
        faults.attempt(label + ':final-record-format-hash-write', final_record)
    return row


def xml_cases(path):
    rows = []
    for case in ET.parse(path).getroot().iter('testcase'):
        bad = [tag for tag in ('failure', 'error', 'skipped') if case.find(tag) is not None]
        require(len(bad) <= 1, 'Ambiguous testcase result')
        rows.append(dict(classname=case.get('classname'), name=case.get('name'),
                         outcome={'failure': 'failed', 'error': 'error', 'skipped': 'skipped'}.get(bad[0], 'passed') if bad else 'passed',
                         attributes=dict(case.attrib),
                         testcase_xml_base64=base64.b64encode(ET.tostring(case, encoding='utf-8')).decode('ascii')))
    return rows


def keys(rows):
    return [(row['classname'], row['name']) for row in rows]


def checked_pin(pin):
    require(type(pin) is dict and type(pin.get('path')) is str and type(pin.get('sha256')) is str,
            'Malformed external file pin')
    raw = Path(pin['path']).read_bytes()
    require(sha(raw) == pin['sha256'], 'Externally pinned file differs: ' + pin['path'])
    if 'bytes' in pin:
        require(type(pin['bytes']) is int and len(raw) == pin['bytes'], 'Externally pinned byte length differs')
    return raw


def timestamp(value):
    require(type(value) is str, 'Missing original UTC timestamp')
    parsed = datetime.datetime.fromisoformat(value)
    require(parsed.tzinfo is not None and parsed.utcoffset() == datetime.timedelta(0), 'Require actual aware UTC time')
    return parsed


def full_environment_digest(values):
    require(type(values) is dict and all(type(k) is str and type(v) is str for k, v in values.items()),
            'Environment must be the complete string mapping')
    return sha(json.dumps(values, sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode('ascii'))


def complete_admission(detached_sha):
    """Read-only existing-gate repair; no output/cache/import/Popen precedes its return."""
    require(type(detached_sha) is str and len(detached_sha) == 64 and
            all(x in '0123456789abcdef' for x in detached_sha), 'Require external lowercase raw release SHA256')
    require(Path.cwd() == I and Path(sys.prefix) == P / '.venv', 'Wrong prepared runtime/cwd')
    require(sys.flags.dont_write_bytecode and not sys.flags.optimize, 'Require ordinary prepared Python -B without optimization')
    raw_release = RELEASE.read_bytes()
    require(sha(raw_release) == detached_sha, 'Externally supplied release SHA mismatch')
    release = json.loads(raw_release)
    require(release['schema'] == 'H100-exact-runtime-release/v1' and release['scope'] == SCOPE and
            release['authorized'] is True, 'No exact ROOT runtime grant')
    config_path = AUTHOR / 'execution-config-DATA.json'
    raw_config = config_path.read_bytes()
    require(sha(raw_config) == release['config_sha256'], 'Released config differs')
    require(Path(__file__) == AUTHOR / 'driver.py' and sha(Path(__file__).read_bytes()) == release['driver_sha256'],
            'Released driver differs')
    config = json.loads(raw_config)
    require(config['scope'] == SCOPE and config['status'] == 'UNGRANTED_SOURCE_DATA' and
            config['driver_sha256'] == release['driver_sha256'], 'Unreviewed source config')
    startup = release['parent_startup']
    template = startup['orig_argv_template']
    require(template == config['parent_startup']['orig_argv_template'], 'Unapproved full parent argv template')
    slot = {'type': 'detached-release-raw-sha256/v1'}
    require(sum(type(x) is dict and x == slot for x in template) == 1 and
            all(type(x) is str or x == slot for x in template), 'Require exactly one typed detached SHA slot')
    expanded = [detached_sha if type(x) is dict else x for x in template]
    require(startup['executable'] == config['parent_startup']['executable'] == sys.executable,
            'Actual complete parent executable differs')
    require(startup['cwd'] == str(I) == str(Path.cwd()) and list(sys.orig_argv) == expanded,
            'Actual complete parent orig_argv/cwd differs')
    require(list(sys.argv) == [str(AUTHOR / 'driver.py'), '--release-sha256', detached_sha],
            'Actual parent script/remaining argv differs')
    environment = dict(os.environ)
    require(startup['environment_codec'] == config['parent_startup']['environment_codec'] == 'ascii-json-sorted-compact/v1' and
            full_environment_digest(environment) == startup['environment_sha256'], 'Complete external parent environment differs')
    require(not any(detached_sha in value for value in environment.values()),
            'Detached release SHA cannot occur in the hashed parent environment')
    require(environment.get('GIT_OPTIONAL_LOCKS') == '0' and environment.get('HOME') == config['HOME'],
            'Actual parent GIT0/HOME differs')
    require(not any(name in environment for name in config['parent_startup']['forbidden_redirects']),
            'Unapproved parent Python/pytest redirect or inspection environment')
    pair = dict(author_task=config['author_task'], driver_sha256=release['driver_sha256'], config_sha256=release['config_sha256'])
    review = json.loads(checked_pin(release['independent_review']))
    binding = review['admission_binding']
    require(all(binding.get(k) == value for k, value in pair.items()) and
            binding.get('verdict') == 'ACCEPT_UNGRANTED_SOURCE_DATA_ONLY' and
            type(binding.get('reviewer')) is str and binding['reviewer'] not in ('', config['author_owner'], 'root'),
            'Independent nonauthor review does not accept this complete source pair')
    intake = json.loads(checked_pin(release['ROOT_whole_intake']))['admission_binding']
    require(all(intake.get(k) == value for k, value in pair.items()) and
            intake.get('status') == 'ROOT_WHOLE_INTAKEN_SOURCE_DATA_ONLY' and
            intake.get('review') == {k: release['independent_review'][k] for k in ('path', 'sha256')},
            'ROOT whole intake does not bind this exact fresh review/source pair')
    contract = config['current_execution_contract']
    packet_pin = release['current_execution_packet']
    first_pin = release['current_FIRST']
    require(packet_pin['path'] == contract['packet_path'] and first_pin['path'] == contract['FIRST_path'],
            'Current execution packet/FIRST role path differs')
    packet = json.loads(checked_pin(packet_pin))
    require(all(packet.get(k) == value for k, value in contract['packet_fields'].items()),
            'New runtime packet task/parent/checkout/role/owner/scope/output differs')
    require(packet.get('source') == config['canonical_current_source'], 'New execution packet current source identity differs')
    authorities = packet['references']['authorities']
    required_pins = [dict(path=str(AUTHOR / 'driver.py'), sha256=release['driver_sha256']),
                     dict(path=str(config_path), sha256=release['config_sha256']),
                     *[{k: release[name][k] for k in ('path', 'sha256')} for name in ('independent_review', 'ROOT_whole_intake')]]
    for required_pin in required_pins:
        require(sum(row.get('path') == required_pin['path'] and row.get('sha256') == required_pin['sha256']
                    for row in authorities) == 1, 'New packet missing exact source/review/intake authority')
    require(all(row.get('path') not in (str(RELEASE), first_pin['path']) for row in authorities),
            'Packet cannot hash its future FIRST/release')
    first = json.loads(checked_pin(first_pin))
    checker_argv = [str(P / '.venv/bin/python'), '-B', str(P / 'scripts/codex_continuity.py'), 'check', packet_pin['path']]
    require(first.get('packet') == packet_pin['path'] and first.get('argv') == checker_argv and
            first.get('cwd') == str(I) and first.get('environment_override') == {'GIT_OPTIONAL_LOCKS': '0'},
            'Actual current FIRST packet/checker argv/cwd/explicit GIT0 differs')
    require(type(first.get('returncode')) is int and first['returncode'] == 0 and first.get('stderr') == '' and
            first.get('stderr_hex') == '', 'Current FIRST did not actually succeed with empty stderr')
    require(type(first.get('stdout')) is str and type(first.get('stdout_hex')) is str and
            bytes.fromhex(first['stdout_hex']) == first['stdout'].encode(), 'FIRST original stdout channels differ')
    checked = json.loads(first['stdout'])
    require(checked.get('fresh') is True and checked.get('changed') == [] and
            checked.get('task') == contract['packet_fields']['task'], 'Actual FIRST result is stale/failed/wrong runtime task')
    require(timestamp(first['start']) >= timestamp(config['author_FIRST_completed']) and
            timestamp(first['end']) >= timestamp(first['start']) and
            timestamp(release['issued_at']) >= timestamp(first['end']) and
            type(first.get('duration_ns')) is int and first['duration_ns'] >= 0, 'Original actual FIRST/release chronology differs')
    raw_dir = first['raw_directory']
    require(type(raw_dir) is str and raw_dir.startswith('/private/tmp/publication-hook-H100-runtime-FIRST-') and
            Path(raw_dir).parent == Path('/private/tmp'), 'Current FIRST original raw directory differs')
    raw_pins = release['current_FIRST_raw']
    require(set(raw_pins) == {'rawrc', 'stdout', 'stderr', 'invocation.json'} and
            all(pin['path'] == str(Path(raw_dir) / name) for name, pin in raw_pins.items()),
            'Current FIRST original separate channel paths differ')
    raw = {name: checked_pin(pin) for name, pin in raw_pins.items()}
    require(raw['rawrc'] == b'0\n' and raw['stdout'].hex() == first['stdout_hex'] and
            raw['stderr'] == b'', 'Original actual FIRST raw channels differ')
    invocation = json.loads(raw['invocation.json'])
    require(set(invocation) == set(contract['FIRST_invocation_fields']) and
            all(invocation[k] == first[k] for k in contract['FIRST_invocation_fields']),
            'Actual original FIRST invocation/raw receipt crossbinding differs')
    require(release['output'] == config['runtime_output'], 'Released output differs')
    output = Path(config['runtime_output'])
    require(not output.exists(), 'Runtime output already exists; never replay')
    # Pure fixed-known reads only: no Git child/census or self-baseline admission.
    before = fixed_snapshot(config)
    require(before == expected_snapshot(config), 'Current external source/admin/index/ref/input admission differs')
    for name, row in config['indexes'].items():
        require(index_semantics(row['path']) == row, 'Semantic/raw index mismatch: ' + name)
    return config, raw_config, raw_release, release, output, before


def main():
    # No argparse help/usage output, candidate import or directory write occurs on refusal.
    require(len(sys.argv) == 3 and sys.argv[1] == '--release-sha256', 'Require exact detached-release invocation')
    config, raw_config, raw_release, release, output, before = complete_admission(sys.argv[2])
    env = dict(os.environ)
    removed = {name: env.pop(name) for name in config['remove_redirects'] if name in env}
    require(env.get('HOME') == config['HOME'], 'Ordinary HOME differs')
    env.update(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1',
               UV_CACHE_DIR=str(output / 'cache/uv'), CARGO_HOME=str(output / 'cache/cargo'))
    faults = Faults()
    children = []
    result = dict(status='ADMITTED_NOT_QUALIFIED', actual_current_count='UNMEASURED',
                  all55_source_campaigns='UNRUN', children=children,
                  release_sha256=sha(raw_release), config_sha256=sha(raw_config))
    try:
        output.mkdir()
        (output / 'cache').mkdir()
        json_new(output / 'admission.json', dict(before=before, release=release, actual_utc=utc(),
                                                environment_removed=freeze(removed), HOME=env.get('HOME'),
                                                environment_overrides={name: env[name] for name in config['environment_overrides']}))
        probe = own_child(output, env, 'imports', ['-c', config['origin_probe_source']], children, faults)
        faults.propagate()
        require(probe['natural_terminal'] and probe['returncode'] == 0 and probe['cold_absent_after'], 'Actual import prerequisite failed')
        actual = json.loads((output / 'imports.stdout').read_bytes())
        require(actual['cwd'] == str(I) and actual['prefix'] == str(P / '.venv') and actual['platform'] == 'darwin', 'Wrong actual import context')
        require(actual['origins'] == config['expected_origins'] and actual['producer'] == str(I / 'scripts/pre-commit-notebooks.sh'), 'Actual loaded origins differ')
        require(all(actual['capabilities'].values()), 'Original Darwin capability absent')
        require(actual['pycache_prefix'] == probe['cold_prefix'] and actual['dont_write_bytecode'] is True, 'Cold/no-bytecode probe differs')
        json_new(output / 'actual-origins.json', actual)
        # Recheck all fixed sources after imports, before the one unchanged full invocation.
        require(fixed_snapshot(config) == before, 'Custody changed before full module')
        full = own_child(output, env, 'full', ['-c', config['full_entry_source'],
                                              *config['full_pytest_arguments'], '--junitxml', str(output / 'full.xml')], children, faults)
        faults.propagate()
        cases = xml_cases(output / 'full.xml')
        current_keys = keys(cases)
        require(len(current_keys) == len(set(current_keys)), 'Duplicate current IDs')
        actual_definitions = {row['name'].split('[', 1)[0] for row in cases}
        comparison = {}
        for label, historical in config['historical_cohorts'].items():
            oldkeys = keys(historical['cases'])
            oldset = set(oldkeys)
            retained = [key for key in current_keys if key in oldset]
            comparison[label] = dict(expected=len(oldkeys), actual_retained=len(retained),
                                     all_in_original_order=retained == oldkeys,
                                     rows=[dict(previous=row, current_outcome=next((x['outcome'] for x in cases if (x['classname'], x['name']) == key), 'MISSING')) for row, key in zip(historical['cases'], oldkeys)])
        counts = {name: sum(row['outcome'] == name for row in cases) for name in ('passed', 'failed', 'error', 'skipped')}
        json_new(output / 'complete-cases.json', dict(cases=cases, comparison=comparison, actual_current_count=len(cases), summary=counts,
                                                     all_current_source_definitions=sorted(actual_definitions),
                                                     all_source_definitions_present=actual_definitions == set(config['all_current_source_test_definitions'])))
        result.update(actual_current_count=len(cases), summary=counts, original_order=comparison,
                      full_raw={name: state(output / name) for name in ('full.stdout', 'full.stderr', 'full.xml')})
        markers = [line[len(b'H98_FULL_LOADED_ORIGIN '):] for line in (output / 'full.stdout').read_bytes().splitlines()
                   if line.startswith(b'H98_FULL_LOADED_ORIGIN ')]
        require(len(markers) == 1, 'Actual same-full-runtime loaded-origin record missing/ambiguous')
        loaded = json.loads(markers[0])
        json_new(output / 'full-loaded-origin.json', loaded)
        require(loaded['pytest_returncode'] == full['returncode'], 'Native pytest and child terminal returncodes differ')
        result['actual_full_loaded_origin'] = loaded
        # Full original raw JUnit retains every failure and all captured passing native/source receipts.
        # This observer never reopens native endpoints, polls witnesses or repairs missing receipts.
        require(full['natural_terminal'] and full['cold_absent_after'], 'Full natural/cold terminal missing')
        require(full['returncode'] == 0 and bool(cases) and counts == dict(passed=len(cases), failed=0, error=0, skipped=0), 'Full module failed; preserve original result')
        require(all(row['all_in_original_order'] for row in comparison.values()), 'Historical complete cohort missing/reordered')
        require(actual_definitions == set(config['all_current_source_test_definitions']), 'Complete current source test-definition population differs')
        result['status'] = 'COMPLETE_UNFILTERED_CURRENT_MODULE_AUTHOR_EVIDENCE_REVIEW_PENDING'
    except BaseException:
        faults.caught('qualification-body')
        result['status'] = 'FAILED_PRESERVED_DEPENDENTS_STOPPED'
    finally:
        def custody():
            after = fixed_snapshot(config)
            json_new(output / 'returned-custody.json', dict(after=after, exact=after == before,
                                                           bounds='Fixed-known I/P/B endpoints; no global atomic or process-absence claim'))
            require(after == before, 'Returned fixed-known custody differs; no repair/rebaseline')
        faults.attempt('returned-custody-read-hash-format-write', custody)
        def final():
            if faults.first is not None:
                result['status'] = 'FAILED_PRESERVED_DEPENDENTS_STOPPED'
            result.update(ended=utc(), faults=faults.data(), actual_driver_pid=os.getpid(),
                          acceptance='AUTHOR_EVIDENCE_ONLY; ROOT whole intake and fresh independent actual-evidence review required')
            journal(output, 'runtime.json', result)
        faults.attempt('final-result-format-timestamp-write', final)
    faults.propagate()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
