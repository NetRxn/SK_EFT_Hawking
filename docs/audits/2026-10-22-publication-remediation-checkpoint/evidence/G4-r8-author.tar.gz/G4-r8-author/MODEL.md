# Model and ownership

Inherited model; original G4 author implementing the whole accepted construction in assigned Q only. Sole canonical FIRST rc0/freshtrue precedes this immutable model. ROOT owns integration, scientific acceptance, actual production controls, Git and closure. Preserve all peer files and existing Q absence/cache repairs. Scoped pure units only under exact assigned command contract. No all21 accepted scientific baseline or receipt is manufactured.
