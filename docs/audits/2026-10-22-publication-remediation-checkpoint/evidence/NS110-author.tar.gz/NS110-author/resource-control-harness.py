#!/usr/bin/env python3
"""Complete proposed source DATA. Unapplied/unrun; separate ROOT grant required.

The accepted Campaign and original st_proxy/_term_thread/seed_journal retain
scientific, fixture and restoration ownership. This module supplies control
activations and source-bound observation, never a substitute quiet predicate.
"""
from __future__ import annotations
import ast, base64, hashlib, importlib.util, json, os, signal, stat
import subprocess, sys, time, traceback, struct, threading, dis
from pathlib import Path

class NativeExceptionRegistry:
    """Strong native objects and unformatted first clock/TB/args before observers."""
    def __init__(self):self.objects={};self.pending={};self.operations={};self.operation_sequence=0
    def primitive(self,value):
        if type(value) in (str,int,float,bool,type(None)):return value
        if type(value)is bytes:return {'bytes_hex':value.hex()}
        if type(value)is tuple:return {'tuple':[self.primitive(x)for x in value]}
        return {'opaque_object':id(value),'type_module':type(value).__module__,'type_name':type(value).__qualname__}
    def call_facts(self,value):
        # Only own acyclic source-call fact dictionaries; arbitrary native args
        # retain the original opaque policy and cannot recurse through a cycle.
        if type(value)is dict:return {k:self.call_facts(v)for k,v in value.items()}
        if type(value)is list:return [self.call_facts(x)for x in value]
        return self.primitive(value)
    def arm(self,frame,operation,**facts):
        self.operation_sequence+=1
        row={'operation_sequence':self.operation_sequence,'operation':operation,'frame_object':id(frame),'file':frame.f_code.co_filename,'function':frame.f_code.co_name,'armed_line':frame.f_lineno,'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns(),**facts}
        self.operations[threading.get_ident()]=row
        return row
    def capture(self,frame,event_arg):
        typ,exc,tb=event_arg
        # First instructions: real clocks and actual objects; no __str__/repr,
        # clean(), inventory, JSON, file I/O, formatter or replacement exception.
        mono=time.monotonic_ns();wall=time.time_ns();key=id(exc)
        if key not in self.objects:
            self.objects[key]={'exception':exc,'traceback':tb,'type':typ,'first_monotonic_ns':mono,'first_utc_ns':wall,'first_frame':frame}
        strong=self.objects[key];chain=[];cursor=tb
        while cursor is not None:
            f=cursor.tb_frame;chain.append({'traceback_object':id(cursor),'frame_object':id(f),'file':f.f_code.co_filename,'function':f.f_code.co_name,'code_firstline':f.f_code.co_firstlineno,'line':cursor.tb_lineno,'lasti':cursor.tb_lasti});cursor=cursor.tb_next
        op=self.operations.get(threading.get_ident());bound=op if op is not None and any(t['frame_object']==op['frame_object']for t in chain)else None
        if bound is not None and bound['operation']in('open','write','fsync'):
            source_frame=next(t.tb_frame for t in self._tb_objects(tb)if id(t.tb_frame)==bound['frame_object'])
            local=source_frame.f_locals;argument_name={'open':'bad','write':'fd','fsync':'duplicate'}[bound['operation']]
            native_call=strong.get('actual_native_call')
            if native_call is None and argument_name in local and 'syscall_lineage'in local and 'native_call_capture'in local:
                actual_argument=local[argument_name]
                native_call={'argument':str(actual_argument)if bound['operation']=='open'else self.primitive(actual_argument),'lineage':self.primitive(local['syscall_lineage']),'immediate_pre_call':self.call_facts(local['native_call_capture']),'capture_frame_object':id(source_frame),'capture_line':source_frame.f_lineno}
                strong['actual_native_call']=native_call
            bound={**bound,'native_actual_call':native_call}
        row={'exception_object':key,'type_module':typ.__module__,'type':typ.__qualname__,'errno':OSError.errno.__get__(exc,typ)if isinstance(exc,OSError)else None,'args':self.primitive(BaseException.args.__get__(exc,typ)),'first_traceback_object':id(strong['traceback']),'traceback_object':id(tb),'traceback':chain,'first_monotonic_ns':strong['first_monotonic_ns'],'first_utc_ns':strong['first_utc_ns'],'observed_monotonic_ns':mono,'observed_utc_ns':wall,'operation':bound,'metadata_attempt':strong.get('metadata_attempt')}
        previous=self.pending.get(id(frame))
        if previous is not None and previous['handler_seen']:
            previous['latest_native']=row;previous.setdefault('secondary_native',[]).append(row)
        else:self.pending[id(frame)]={'native':row,'latest_native':row,'handler_seen':False}
        return row
    def _tb_objects(self,tb):
        rows=[]
        while tb is not None:rows.append(tb);tb=tb.tb_next
        return rows
    def line(self,frame,handler_lines,retry_line,nested_handler_lines=()):
        pending=self.pending.get(id(frame))
        if pending is None:return None
        if frame.f_lineno in handler_lines:pending['handler_seen']=True
        if frame.f_lineno in nested_handler_lines:pending['latest_native']=pending['native']
        if pending['handler_seen'] and frame.f_lineno==retry_line:
            self.pending.pop(id(frame));return {'disposition':'caught_then_original_retry','native':pending['native'],'frame_object':id(frame)}
        return None
    def exit(self,frame):
        pending=self.pending.pop(id(frame),None);opcode=dis.opname[frame.f_code.co_code[frame.f_lasti]]
        escaped=pending is not None and opcode not in ('RETURN_VALUE','RETURN_CONST','YIELD_VALUE','YIELD_FROM')
        return {'disposition':'escaped_exception'if escaped else 'normal_return','opcode':opcode,'native':None if pending is None else pending['latest_native'],'first_frame_fault':None if pending is None else pending['native'],'secondary_native':[]if pending is None else pending.get('secondary_native',[]),'handler_seen':False if pending is None else pending['handler_seen'],'frame_object':id(frame),'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns()}

class RecoveryAuthority:
    """Distinct failed recovery only; delivery is an externally ROOT-owned capability."""
    def __init__(self,protocol,execution_sha,role,pid,observer_pid):
        self.protocol=protocol;self.execution_sha=execution_sha;self.role=role;self.pid=pid;self.observer_pid=observer_pid;self.consumed=set();self.first_errors=[]
    @staticmethod
    def digest(raw):return hashlib.sha256(raw).hexdigest()
    @staticmethod
    def encode(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
    @staticmethod
    def exact_file(path):
        p=Path(path)
        try:s=p.lstat()
        except FileNotFoundError:return {'kind':'missing','path':str(p)}
        if not stat.S_ISREG(s.st_mode) or p.is_symlink():raise RuntimeError('recovery input is not exact regular non-symlink file')
        raw=p.read_bytes()
        return {'kind':'file','path':str(p),'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'raw_base64':base64.b64encode(raw).decode()}
    def load(self,stage,challenge,principal):
        delivery=Path(self.protocol['delivery_directory'])/('ROOT-recovery-'+stage+'.admission')
        if not delivery.exists():return None
        if not delivery.is_absolute()or delivery.parent.resolve()!=delivery.parent or delivery.is_symlink()or not delivery.is_file():raise RuntimeError('ROOT recovery delivery namespace/regular leaf changed before read')
        envelope=json.loads(delivery.read_bytes());authority=Path(envelope['authority_path'])
        prefix='ROOT-recovery-'+stage+'-';suffix='.authority';name=authority.name
        token=name[len(prefix):-len(suffix)]if name.startswith(prefix)and name.endswith(suffix)else''
        if not authority.is_absolute()or authority.parent!=delivery.parent or str(authority)!=os.path.normpath(str(authority))or authority.is_symlink()or len(token)!=32 or any(c not in '0123456789abcdef'for c in token):raise RuntimeError('foreign/malformed recovery authority path refused BEFORE its bytes are read')
        raw=authority.read_bytes();external=envelope['external_raw_sha256']
        if self.digest(raw)!=external or external==self.execution_sha:raise RuntimeError('new separate ROOT recovery raw SHA differs/reuses original execution grant')
        g=json.loads(raw)
        if g.get('schema')!='publication-native-root-failed-recovery/v1'or g.get('state')!='ROOT_AUTHORIZED_FAILED_RECOVERY'or g.get('approved_by')!='ROOT'or g.get('mode')!='RECOVERY_FAILED_UNQUALIFIED':raise RuntimeError('distinct ROOT failed recovery authority absent')
        if g['stage']!=stage or g['execution_authority_sha256']!=self.execution_sha or g['challenge_sha256']!=self.digest(self.encode(challenge))or self.encode(g['principal'])!=self.encode(principal):raise RuntimeError('recovery authority foreign to exact current owner/frame/challenge')
        if g['observer_pid']!=self.observer_pid or g['attempt_id']in self.consumed:raise RuntimeError('foreign observer/replayed recovery attempt')
        if g['ordinary_quiet_or_scientific_qualification']is not False or g['dependents_must_stop']is not True:raise RuntimeError('recovery cannot qualify original attempt or continue dependents')
        if type(g['attempt_id'])is not str or len(g['attempt_id'])!=32 or any(c not in '0123456789abcdef'for c in g['attempt_id']):raise RuntimeError('invalid exact recovery attempt identity')
        if authority!=delivery.parent/('ROOT-recovery-'+stage+'-'+g['attempt_id']+'.authority')or not authority.is_absolute()or authority.is_symlink()or delivery.is_symlink():raise RuntimeError('recovery authority outside exact exclusive delivery namespace')
        if not g['preserved_history_prefixes']:raise RuntimeError('original first-fault/negative history pins absent')
        for pin in g['preserved_history_prefixes']:
            if type(pin['bytes'])is not int or pin['bytes']<=0:raise RuntimeError('preserved history prefix must be nonempty exact bytes')
            b=Path(pin['path']).read_bytes()
            if len(b)<pin['bytes']or self.digest(b[:pin['bytes']])!=pin['sha256']:raise RuntimeError('original failed history was lost/replaced')
        return {'body':g,'raw_sha256':external,'authority_path':str(authority),'delivery':self.exact_file(delivery),'authority':self.exact_file(authority)}
    def consume(self,grant):self.consumed.add(grant['body']['attempt_id'])
    @staticmethod
    def exclusive_bytes(path,raw,mode=0o400):
        p=Path(path)
        if not p.is_absolute()or p.is_symlink()or p.exists():raise RuntimeError('recovery archive/blob must be new exclusive file')
        fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
        with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
        directory=os.open(p.parent,os.O_RDONLY)
        try:os.fsync(directory)
        finally:os.close(directory)
        return RecoveryAuthority.exact_file(p)
    @staticmethod
    def validate_resources(proof,contract,allow_close2=False):
        # Fresh source-owned objects, not old ordinary receipts or endpoint absence.
        if proof['pid']!=contract['pid']or proof['nodeid']not in contract['expected_ids']or proof['inflight']!=0 or type(proof['inflight'])is not int:raise RuntimeError('fresh exact owner/inflight proof absent')
        if proof['fixture_required']is not contract['fixture_requirements'][proof['nodeid']]:raise RuntimeError('recovery original source fixture requirement differs')
        groups=proof['registrations']
        if set(groups)!={'rig','broker','connection','worker'}:raise RuntimeError('recovery registration kinds incomplete')
        for kind,rows in groups.items():
            identities=[r['identity']for r in rows];keys={'pid','object'}|({'lock'}if kind=='broker'else{'thread','done'}if kind=='worker'else set())
            if len({RecoveryAuthority.encode(v)for v in identities})!=len(identities)or any(set(v)!=keys or any(type(x)is not int or x<=0 for x in v.values())for v in identities):raise RuntimeError('recovery unknown/duplicate/incomplete original identity')
            if [r['ordinal']for r in rows]!=list(range(1,len(rows)+1))or any(r['resource']!=kind or r['identity']['pid']!=proof['pid']for r in rows):raise RuntimeError('recovery exact registration order/principal differs')
        if [w['identity']for w in proof['workers']]!=[r['identity']for r in groups['worker']]:raise RuntimeError('fresh actual worker population differs')
        if any(w['alive']is not False or w['done']is not True or type(w['thread_ident'])is not int for w in proof['workers']):raise RuntimeError('actual owned worker not joined/done/identified')
        if proof['fixture_required']is True:
            if len(groups['rig'])!=1 or proof['rig_identity']!=groups['rig'][0]['identity']:raise RuntimeError('actual original registered rig absent')
        elif proof['rig_identity']is not None or any(groups[k]for k in ('rig','broker','connection')):raise RuntimeError('source-proved no-rig disposition differs')
        if [b['identity']for b in proof['brokers']]!=[r['identity']for r in groups['broker']]or [c['identity']for c in proof['connections']]!=[r['identity']for r in groups['connection']]:raise RuntimeError('actual broker/connection population differs')
        for broker in proof['brokers']:
            for r in broker['records'].values():
                if r['state']not in('LIVE','TERMINATED')or r['close_owner']is not None or any(a['pending']is not False for a in r['attempts']):raise RuntimeError('actual broker/establishment owner still active')
                if any(o['state']!='DONE'or o['response_write']not in('NOT_STARTED','NOT_WRITTEN','DONE','FAILED')for o in r['operations'].values()):raise RuntimeError('actual operation/write still active')
                if any(o['state']!='DONE'for o in r['deletes']+r['closures'])or any(o['response_write']not in('NOT_WRITTEN','DONE','FAILED')for o in r['closures']):raise RuntimeError('actual delete/closure still active')
        for c in proof['connections']:
            if type(c['closed'])is not int or c['closed']not in((1,2)if allow_close2 else(1,)):raise RuntimeError('actual transport physical settlement unavailable')
        expected_sources={'scripts.lean_slots.proxy':{'path':contract['proxy'],'sha256':contract['proxy_sha256']},'seed_journal':{'path':contract['journal'],'sha256':contract['journal_sha256']}}
        if proof['loaded_sources']!=expected_sources:raise RuntimeError('fresh loaded-source origin/hash proof differs')
        if any(x['closed']is not True for x in proof['publication_stream_owners']):raise RuntimeError('actual original publication handle not closed')
        if allow_close2 and proof['original_exact_once_contract_satisfied']is not False:raise RuntimeError('wrong close2 history must remain failed')
        return True

class IntactBackupFailedRecovery:
    """Failed owner-barrier release; original entry/canonical journal stay unchanged."""
    def __init__(self,grant,plan,external_sha,work,tap):
        self.g=grant;self.plan=plan;self.work=Path(work);self.tap=tap;self.active=None;self.errors=[];self.held={}
        self.authority=RecoveryAuthority(grant['recovery']['protocol'],external_sha,'parent',os.getpid(),tap.observer_pid)
    def checkpoint(self,campaign,frame):
        if self.active is not None:return self.active['disposition']
        if self.g['control']['mode']!='control':return None
        window=campaign.seed_window
        if window is None:return None
        trigger=window.get('original_failure')or next(iter(window.get('barrier_failures',[])),None)or getattr(self.tap,'recovery_original_edge',None)
        if trigger is None:return None # no new failed authority before actual original failure/forbidden edge
        try:
            handle=window.get('handle')
            if window['child_attempted']and(handle is None or handle.poll()is None):return None
            entry=window.get('journal_entry')
            if entry is None:return None
            old={k:v for k,v in entry.items()if k!='live'}
            backup=RecoveryAuthority.exact_file(old['backup'])
            if backup.get('kind')!='file'or backup['sha256']!=old['sha256']or base64.b64decode(backup['raw_base64'])!=window['original']:return None
            source=RecoveryAuthority.exact_file(self.plan['proxy'])
            if source['sha256']!=hashlib.sha256(window['image']).hexdigest()or source['mode']!=window['original_state']['mode']:return None
            principal={'role':'parent','pid':os.getpid(),'frame_object':id(frame),'function':frame.f_code.co_name,'source_file':frame.f_code.co_filename,'source_sha256':hashlib.sha256(Path(frame.f_code.co_filename).read_bytes()).hexdigest(),'original_seed_owner_frame':id(self.tap.seed_owner_frame)}
            challenge={'source_history_prefix':self.held.get(id(frame),{}).get('challenge',{}).get('source_history_prefix',self.tap.n),'principal':principal,'route_id':self.g['control'].get('route_id'),'original_entry':old,'source':source,'backup':backup,'child_attempted':window['child_attempted'],'actual_Popen':None if handle is None else{'pid':handle.pid,'object':id(handle),'returncode':handle.returncode},'first_failure':window.get('original_failure'),'ordinary_quiet_asserted':False,'recovery_trigger':trigger}
            key=id(frame)
            if key not in self.held:
                self.held[key]={'frame':frame,'challenge':challenge};self.tap.recovery_request('RECOVERY_PARENT_HELD',frame,challenge)
            elif self.held[key]['challenge']!=challenge:return None
            grant=self.authority.load('parent',challenge,principal)
            if grant is None:return None
            result=self.tap.recovery_rendezvous('RECOVERY_PARENT_SETTLEMENT_REQUEST',frame,{'authority':grant,'challenge':challenge,'original_entry':old,'unchanged_entry_argument':True})
            disposition={'mode':'RECOVERY_FAILED_UNQUALIFIED','ordinary_quiet':False,'scientific_qualification':False,'dependents_stopped':True,'attempt_id':grant['body']['attempt_id'],'first_failure':window.get('original_failure'),'independent_settlement':result}
            self.authority.consume(grant);self.active={'grant':grant,'entry':old,'disposition':disposition,'challenge':challenge,'source_owner_frame':self.tap.seed_owner_frame};campaign.recovery_failed_unqualified=disposition
            return disposition
        except BaseException:
            self.errors.append(self.tap.native.capture(sys._getframe(),sys.exc_info()))
            return None # same original barrier/frame/pathlock stays in scope
    def wait_at_original_restore(self,campaign,frame):
        while self.active is None:
            self.checkpoint(campaign,frame)
            if self.active is None:
                try:time.sleep(.05)
                except BaseException:self.errors.append(self.tap.native.capture(sys._getframe(),sys.exc_info()))
        while True:
            try:
                entry=frame.f_locals['entry'];caller=frame.f_back;original=self.tap.canonical_restore
                if entry!=self.active['entry']or caller is not self.tap.seed_owner_frame or caller.f_locals.get('entry')is not entry or original is None or frame.f_code is not original.__code__ or frame.f_globals.get('_restore')is not original:raise RuntimeError('unchanged canonical function/argument/original owning generator differs')
                # NO replacement function, caller-local rewrite or callee-argument write.
                return self.tap.recovery_rendezvous('BEFORE_ORIGINAL_FAILED_RECOVERY_RESTORE',frame,{'authority':self.active['grant'],'entry':entry,'disposition':self.active['disposition'],'original_argument_object':id(entry),'original_owner_frame':id(caller),'canonical_function_object':id(original)})
            except BaseException:self.errors.append(self.tap.native.capture(sys._getframe(),sys.exc_info()))
            try:time.sleep(.05)
            except BaseException:self.errors.append(self.tap.native.capture(sys._getframe(),sys.exc_info()))
    def after_original_restore(self,frame):
        return self.tap.recovery_rendezvous('AFTER_ORIGINAL_FAILED_RECOVERY_RESTORE',frame,{'authority':self.active['grant'],'entry':self.active['entry'],'disposition':self.active['disposition'],'canonical_function_object_unchanged':True})

BASE_DRIVER = '52628f4c755bbd9b75f4694eb701024bec013f90e00899af2632d0e0164ac130'
BASE_PLAN = '5d6e353f2dc092d3f028882cc5f86d6c354292772960c7dc1b62a88d404e10bd'
UNRECOVERABLE = {'M2-close-two','permanent-stream-loss','inner-barrier-bypass',
                 'unconditional-hold','permanent-coverage-loss'}
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read_json(path): return json.loads(Path(path).read_bytes())
def require(value, message):
    if not value: raise RuntimeError(message)
def durable(path, value):
    path=Path(path);pending=path.with_name(path.name+'.pending-'+str(os.getpid()))
    with pending.open('x', encoding='utf-8') as f:
        json.dump(value, f, sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.link(pending,path);pending.unlink()
    fd=os.open(path.parent,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
digest=sha
def state(path):
    path=Path(path)
    try:s=path.lstat()
    except FileNotFoundError:return {'kind':'missing'}
    result={'kind':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'other','mode':s.st_mode,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size}
    if result['kind']=='file':result['sha256']=digest(path.read_bytes())
    if result['kind']=='symlink':result['target']=os.readlink(path)
    return result
file_state=state

def directory_population_delta(expected,actual,error=None):
    # Exact source predicate; unavailable names are never an empty population.
    valid=type(expected) is list and all(type(x) is str and x not in ('','.','..') and '/' not in x for x in expected) and expected==sorted(set(expected))
    observed=error is None and type(actual) is list and all(type(x) is str for x in actual) and actual==sorted(set(actual))
    additions=sorted(set(actual)-set(expected)) if valid and observed else None
    deletions=sorted(set(expected)-set(actual)) if valid and observed else None
    return {'expected':expected,'actual':actual,'read_error':error,'expected_valid':valid,'actual_observed':observed,'additions':additions,'deletions':deletions,'refused':not valid or not observed or actual!=expected}

def parse_index_semantics(raw):
    """Independent read of known SHA1 Git index v2/v3/v4; no Git process/cache."""
    require(raw[:4]==b'DIRC' and len(raw)>=32,'invalid actual Git index')
    version,count=struct.unpack('>II',raw[4:12]);require(version in (2,3,4),'unsupported actual index version')
    require(hashlib.sha1(raw[:-20]).digest()==raw[-20:],'actual index checksum differs')
    offset=12;previous=b'';entries=[]
    for ordinal in range(count):
        start=offset;require(offset+62<=len(raw)-20,'truncated actual index entry')
        values=struct.unpack('>10I20sH',raw[offset:offset+62]);offset+=62;mode=values[6];oid=values[10];flags=values[11]
        if flags&0x4000:
            require(version>=3 and offset+2<=len(raw)-20,'invalid extended index flags');extended=struct.unpack('>H',raw[offset:offset+2])[0];offset+=2
            require(not extended&0x4000,'sparse skip-worktree index needs separate support')
        if version==4:
            remove=raw[offset]&0x7f;byte=raw[offset];offset+=1
            while byte&0x80:
                byte=raw[offset];offset+=1;remove=((remove+1)<<7)+(byte&0x7f)
            require(remove<=len(previous),'invalid compressed index prefix')
            end=raw.index(b'\0',offset,len(raw)-20);name=previous[:len(previous)-remove]+raw[offset:end];offset=end+1
        else:
            end=raw.index(b'\0',offset,len(raw)-20);name=raw[offset:end];offset=end+1
            offset=start+((offset-start+7)//8)*8
        require(name and not name.startswith(b'/') and b'\0'not in name,'invalid actual index path')
        require(mode in (0o100644,0o100755,0o120000,0o160000),'unsupported sparse/unknown index mode')
        entries.append({'path_hex':name.hex(),'mode':format(mode,'06o'),'oid':oid.hex(),'stage':(flags>>12)&3});previous=name
    extensions=[]
    while offset<len(raw)-20:
        require(offset+8<=len(raw)-20,'truncated actual index extension');tag=raw[offset:offset+4];size=struct.unpack('>I',raw[offset+4:offset+8])[0];offset+=8
        require(offset+size<=len(raw)-20 and 65<=tag[0]<=90,'unknown required/split index extension')
        extensions.append({'signature_hex':tag.hex(),'bytes':size,'sha256':sha(raw[offset:offset+size])});offset+=size
    require(len({(e['path_hex'],e['stage'])for e in entries})==len(entries),'duplicate actual semantic index entry')
    stage_bytes=b''.join(e['mode'].encode()+b' '+e['oid'].encode()+b' '+str(e['stage']).encode()+b'\t'+bytes.fromhex(e['path_hex'])+b'\0'for e in entries)
    return {'raw_sha256':sha(raw),'version':version,'entries':entries,'stage_text_hex':stage_bytes.hex(),'extensions':extensions}

def parse_ref_semantics(raw,path):
    """Known exact ref-file contents only; directory populations stay separate."""
    text=raw.decode('ascii');lines=text.splitlines();name=Path(path).name
    def oid(value):return len(value)==40 and all(c in '0123456789abcdef'for c in value)
    if name=='packed-refs':
        rows=[]
        for line in lines:
            if line.startswith('#')or not line:continue
            if line.startswith('^'):require(oid(line[1:]),'invalid peeled actual ref');rows.append({'peeled':line[1:]});continue
            fields=line.split(' ');require(len(fields)==2 and oid(fields[0])and fields[1].startswith('refs/'),'invalid actual packed ref');rows.append({'name':fields[1],'oid':fields[0]})
        return {'raw_sha256':sha(raw),'kind':'packed','rows':rows}
    if name=='FETCH_HEAD':
        rows=[line.split('\t')for line in lines];require(all(row and oid(row[0])for row in rows),'invalid actual FETCH_HEAD')
        return {'raw_sha256':sha(raw),'kind':'fetch','rows':rows}
    require(len(lines)==1,'unexpected actual ref population')
    if lines[0].startswith('ref: '):require(lines[0][5:].startswith('refs/'),'invalid symbolic actual ref');return {'raw_sha256':sha(raw),'kind':'symbolic','target':lines[0][5:]}
    require(oid(lines[0]),'invalid actual direct ref');return {'raw_sha256':sha(raw),'kind':'direct','oid':lines[0]}

def observe_known_custody(plan,names,mutant=None):
    """Promoted original Campaign.custody state/name predicates, no writes."""
    actual={};deltas=[]
    for name,snap in plan['known_custody'].items():
        root=Path(snap['root']);got={'sources':{},'admin':{},'admin_directory_names':{},'admin_directory_comparisons':{}}
        for rel,expected in snap['sources'].items():
            v=state(root/rel);got['sources'][rel]=v;want=mutant if name=='NS'and rel=='scripts/lean_slots/proxy.py'and mutant is not None else expected
            if v!=want:deltas.append({'root':name,'path':str(root/rel),'expected':want,'actual':v})
        for path,expected in snap['admin'].items():
            try:v=state(path)
            except OSError as exc:v={'kind':'unavailable','read_error':{'type':type(exc).__name__,'errno':exc.errno,'filename':exc.filename}}
            got['admin'][path]=v
            if v!=expected:deltas.append({'root':name,'path':path,'expected':expected,'actual':v})
        for path,expected_names in names[name].items():
            observed=None;error=None
            try:observed=sorted(x.name for x in Path(path).iterdir())
            except OSError as exc:error={'type':type(exc).__name__,'errno':exc.errno,'filename':exc.filename}
            comparison=directory_population_delta(expected_names,observed,error)
            got['admin_directory_names'][path]=observed;got['admin_directory_comparisons'][path]=comparison
            if comparison['refused']:deltas.append({'root':name,'path':path,'kind':'directory_population','comparison':comparison})
        actual[name]=got
    return actual,deltas

def validate_runtime_paths(plan,grant,fresh=True):
    """One pure complete ownership layout; no grant rewriting or filesystem writes."""
    def path(value):
        require(type(value)is str and value.startswith('/')and os.path.normpath(value)==value,'noncanonical absolute granted path')
        p=Path(value)
        for ancestor in (p,*p.parents):
            try:s=ancestor.lstat()
            except FileNotFoundError:continue
            require(not stat.S_ISLNK(s.st_mode),'symlink in runtime ownership path')
        require(str(p.resolve())==value,'resolved path aliases ROOT grant')
        return p
    def absent(p):
        try:p.lstat()
        except FileNotFoundError:return True
        return False
    def overlap(a,b):
        a=Path(str(a).casefold());b=Path(str(b).casefold())
        return a==b or a.is_relative_to(b)or b.is_relative_to(a)
    output=path(grant['output']);work=path(grant['harness_output'])
    roots=[path(str(Path(plan['roots'][r])/'outputs/continuity'))for r in ('NS','B')]
    require(not overlap(output,work),'runtime output scopes overlap/nest')
    require(all(any(p.is_relative_to(root)and p!=root for root in roots)for p in (output,work)),'runtime output outside admitted continuity roots')
    require(absent(output)and(not fresh or absent(work)),'preexisting runtime output scope')
    names=['physical-admission.json','driver.py','requests','exclusive-start.json','independent-observer.stdout','independent-observer.stderr','independent-raw','independent-start.json','harness-returned.json','original-failure.json','independent-terminal.json','independent-observer-final-error.json']
    reserved={name:str(work/name)for name in names}
    require(grant['artifact_layout']==reserved,'complete reserved artifact layout differs from external grant')
    require(grant['driver_path']==reserved['driver.py'],'driver path aliases reserved ownership')
    controls=grant['control'];capabilities={k:path(controls[k])for k in ('release_dir','remove_fault_path','os_fault_file')}
    for key,p in capabilities.items():
        require(p.parent==work,'capability outside exact owned runtime root')
        require(all(not overlap(p,Path(other))for other in reserved.values()),'capability overlaps reserved artifact/subtree')
        require(all(not p.name.casefold().startswith(name.casefold()+'.pending-')and p.name.casefold()!=name.casefold()+'.pending'for name in names),'capability aliases reserved atomic pending namespace')
        require(not fresh or absent(p),'preexisting runtime capability')
    values=list(capabilities.values());require(all(not overlap(a,b)and not a.name.casefold().startswith(b.name.casefold()+'.pending')and not b.name.casefold().startswith(a.name.casefold()+'.pending')for n,a in enumerate(values)for b in values[n+1:]),'capability aliases/ancestors/pending namespaces overlap')
    require(type(controls['release_token'])is str and bool(controls['release_token']),'release token absent at pure boundary')
    require(all(not fresh or absent(Path(value))for value in reserved.values()),'preexisting reserved runtime artifact')
    protocol=grant['recovery']['protocol']
    require(protocol['schema']=='publication-native-failed-recovery-protocol/v1'and protocol['delivery_directory']==str(work/'requests')and protocol['mode']=='RECOVERY_FAILED_UNQUALIFIED'and protocol['backup_input']=='UNCHANGED_INTACT_ORIGINAL_ENTRY','failed recovery protocol/ownership namespace differs')
    return {'output':str(output),'work':str(work),'reserved':reserved,'capabilities':{k:str(v)for k,v in capabilities.items()},'atomic_namespace_policy':'all reserved .pending and .pending-* siblings reserved; requests/independent-raw/release subtrees exclusively owned'}

def admit_prepared_startup(plan,grant,role,authority_path,external_sha,packet_dir):
    """Observed executable never supplies its own external approval."""
    prepared=grant['prepared_runtime'];primary=plan['primary_python']
    require(prepared['primary_python']==primary,'immutable primary_python differs')
    require(type(prepared['admitted_invocation_paths'])is list and primary in prepared['admitted_invocation_paths']and len(set(prepared['admitted_invocation_paths']))==len(prepared['admitted_invocation_paths']),'explicit interpreter invocation paths absent/duplicate')
    resolved=Path(primary).resolve(strict=True);s=resolved.stat()
    identity={'resolved':str(resolved),'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':sha(resolved.read_bytes())}
    require(identity==prepared['resolved_identity'],'prepared executable physical identity differs')
    for value in prepared['admitted_invocation_paths']:
        require(type(value)is str and value.startswith('/')and os.path.normpath(value)==value and Path(value).resolve(strict=True)==resolved,'unadmitted/different executable alias target')
    version={'version_info':list(sys.version_info),'implementation':sys.implementation.name,'cache_tag':sys.implementation.cache_tag,'sys_version':sys.version}
    require(version==prepared['interpreter_version'],'actual interpreter version/implementation differs')
    require(grant['assigned_cwd']==plan['roots']['B'],'assigned startup checkout differs from immutable B root')
    env_raw=json.dumps(sorted(os.environ.items()),separators=(',',':'),ensure_ascii=True).encode()
    expected_roles={}
    for candidate in ('harness','observer'):
        admitted=grant['startup'][candidate];invoked=admitted['executable']
        require(invoked in prepared['admitted_invocation_paths'],'planned role uses unadmitted executable/alias')
        script=packet_dir/('resource-control-harness.py'if candidate=='harness'else'independent-journal-observer.py')
        tail=[str(Path(grant['current_plan_path'])),str(Path(authority_path)),{'external_raw_authority_sha256':True}]if candidate=='harness'else[str(Path(authority_path)),{'external_raw_authority_sha256':True},grant['harness_output']]
        recipe=[invoked,'-B',str(script),*tail]
        require(admitted['argv_recipe']==recipe and sum(type(x)is dict for x in recipe)==1,'complete immutable argv recipe/external digest slot differs')
        slots=[x for x in admitted['argv_recipe']if type(x)is dict]
        require(len(slots)==1 and set(slots[0])=={'external_raw_authority_sha256'}and slots[0]['external_raw_authority_sha256']is True,'external digest slot must be exactly typed true')
        expected_roles[candidate]=[external_sha if type(x)is dict else x for x in recipe]
        require(admitted['argv_recipe']==recipe and admitted['cwd']==grant['assigned_cwd'],'complete planned role argv/cwd differs before effects')
        # Observer Popen inherits this exact environment with already-required GIT0.
        require(admitted['environment_sha256']==sha(env_raw),'complete planned role environment differs before effects')
    startup=grant['startup'][role];invocation=startup['executable'];expected=expected_roles[role]
    require(invocation in prepared['admitted_invocation_paths']and sys.executable==invocation,'actual executable is not exact externally admitted invocation')
    require(sys.orig_argv==expected,'complete actual/external prepared startup argv differs')
    require(str(Path.cwd())==startup['cwd']==grant['assigned_cwd'],'exact actual startup cwd differs')
    require(sha(env_raw)==startup['environment_sha256'],'complete actual startup environment differs')
    require(sys.dont_write_bytecode and os.environ.get('GIT_OPTIONAL_LOCKS')=='0','actual startup -B/GIT0 contract differs')
    require(grant['independent_observer']=={'pid_binding':'EXACT_HARNESS_PID_FROM_EXCLUSIVE_START_RECORD','argv_recipe':grant['startup']['observer']['argv_recipe'],'cwd':grant['startup']['observer']['cwd'],'harness_output':grant['harness_output']},'observer startup fields differ from external complete startup')
    return {'role':role,'actual_orig_argv':list(sys.orig_argv),'actual_sys_executable':sys.executable,'actual_cwd':str(Path.cwd()),'environment_sha256':sha(env_raw),'prepared_identity':identity,'version':version,'authority_sha256':external_sha,'derived_complete_role_argv':expected_roles}

def physical_current_admission(plan,grant,authority_path,external_sha,packet_dir):
    """Mandatory pure read boundary before ANY runtime output/import/process."""
    started=time.monotonic_ns();actual,deltas=observe_known_custody(plan,grant['expected_admin_directory_names'])
    require(not deltas,'actual source/admin/mode/nsmtime/name custody differs before runtime effects')
    expected=grant['physical_semantics'];require(set(expected)==set(plan['known_custody']),'semantic root coverage differs');semantics={}
    for root,snap in plan['known_custody'].items():
        index_paths={p for p in snap['admin']if Path(p).name=='index'}
        ref_paths={p for p,v in snap['admin'].items()if v['kind']!='directory'and(('/refs/'in p and '/logs/'not in p)or Path(p).name in ('HEAD','ORIG_HEAD','packed-refs','FETCH_HEAD'))}
        require(set(expected[root]['indexes'])==index_paths and set(expected[root]['refs'])==ref_paths,'actual semantic index/ref path coverage differs')
        indexes={};refs={}
        for path in sorted(index_paths):
            indexes[path]={'kind':'missing'}if actual[root]['admin'][path]['kind']=='missing'else parse_index_semantics(Path(path).read_bytes())
        for path in sorted(ref_paths):
            refs[path]={'kind':'missing'}if actual[root]['admin'][path]['kind']=='missing'else parse_ref_semantics(Path(path).read_bytes(),path)
        semantics[root]={'indexes':indexes,'refs':refs};require(semantics[root]==expected[root],'actual raw/semantic index/ref differs before runtime effects')
    layout=validate_runtime_paths(plan,grant,fresh=True)
    startup=admit_prepared_startup(plan,grant,'harness',authority_path,external_sha,packet_dir)
    for key,value in [('harness_sha256',Path(__file__)),('observer_sha256',packet_dir/'independent-journal-observer.py'),('source_images_sha256',packet_dir/'source-images.json'),('control_bindings_sha256',packet_dir/'control-bindings.json'),('intent_coverage_sha256',packet_dir/'intent-coverage.json')]:require(sha(value.read_bytes())==grant[key],'actual startup input changed before runtime effects')
    require(sha(Path(authority_path).read_bytes())==external_sha and sha(Path(grant['current_plan_path']).read_bytes())==grant['plan_sha256'],'actual ROOT authority/plan changed before runtime effects')
    return {'status':'EXACT_KNOWN_PHYSICAL_INPUTS_OBSERVED','started_monotonic_ns':started,'ended_monotonic_ns':time.monotonic_ns(),'actual':actual,'semantics':semantics,'deltas':deltas,'historical_B_gap':grant['historical_B_gap'],'authority_sha256':external_sha,'runtime_layout':layout,'actual_startup':startup,'scope':'known endpoints only; no refresh, census or runtime grant inferred'}

def bind_current(plan_path, authority_path, external_sha, selected, packet_dir):
    """Read supplied exact current binding; never refresh a snapshot or grant one."""
    authority_path=Path(authority_path).resolve(); plan_path=Path(plan_path).resolve()
    require(authority_path!=plan_path,'plan is not authority')
    raw=authority_path.read_bytes(); require(len(external_sha)==64 and sha(raw)==external_sha,'external ROOT raw SHA mismatch')
    g=json.loads(raw); p=read_json(plan_path); images=read_json(packet_dir/'source-images.json')
    require(g.get('schema')=='publication-ns-root-execution-authority/v1' and g.get('state')=='ROOT_GRANTED_EXACT_INPUTS' and g.get('approved_by')=='ROOT','ROOT authority absent')
    require(g.get('harness_schema')=='publication-ns-complete-resource-harness/v1','wrong harness grant schema')
    require(g['current_plan_path']==str(plan_path),'current plan path differs')
    require(g['plan_sha256']==sha(plan_path.read_bytes()) and g['historical_plan_sha256']==BASE_PLAN,'plan binding differs')
    require(g['harness_sha256']==sha(Path(__file__).read_bytes()),'harness source differs')
    require(g['observer_sha256']==sha((packet_dir/'independent-journal-observer.py').read_bytes()),'independent observer differs')
    require(g['source_images_sha256']==sha((packet_dir/'source-images.json').read_bytes()) and g['control_bindings_sha256']==sha((packet_dir/'control-bindings.json').read_bytes()),'whole DATA images/bindings differ')
    historical=json.loads(base64.b64decode(images['plan']['base64']))
    require(sha(base64.b64decode(images['plan']['base64']))==BASE_PLAN,'historical plan corrupted')
    mutable={'known_custody','author_current_preflight_observation'}
    require({k:v for k,v in p.items() if k not in mutable}=={k:v for k,v in historical.items() if k not in mutable},'science/origins/oracles/budgets/roots changed')
    require(set(p['known_custody'])=={'NS','P','B'} and g['roots']==p['roots'],'root population differs')
    require(g['journal_helper']==p['journal_helper'],'actual original journal source tap path differs')
    changes=[]
    for root,old in historical['known_custody'].items():
        current=p['known_custody'][root]
        require(current['root']==old['root'],'custody root changed')
        require({k:v for k,v in current.items() if k not in ('sources','admin')}=={k:v for k,v in old.items() if k not in ('sources','admin')},'historical semantic/index/ref provenance changed')
        for group in ('sources','admin'):
            require(set(old[group])<=set(current[group]),'historical custody guard omitted')
            for path in sorted(set(old[group])|set(current[group])):
                before=old[group].get(path);after=current[group].get(path)
                if before!=after:changes.append({'root':root,'group':group,'path':path,'before':before,'after':after})
    require(g['current_reconciliations']==changes,'every current custody difference requires separate exact ROOT binding')
    require(g['historical_B_gap']=={'status':'UNATTRIBUTED_UNREFRESHED_HISTORY','old_mtime_ns':1792589561991210841,'later_observed_mtime_ns':1792600276626820842,'disposition':'ROOT_EXPLICIT_CURRENT_BINDING_DOES_NOT_WAIVE_HISTORY'},'B discrepancy erased or attributed')
    require(set(g['expected_admin_directory_names'])=={'NS','P','B'},'names roots incomplete')
    for root,snap in p['known_custody'].items():
        names=g['expected_admin_directory_names'][root]
        require(set(names)=={k for k,v in snap['admin'].items() if v['kind']=='directory'},'names directory coverage differs')
        for path,values in names.items():
            require(type(values)is list and values==sorted(set(values)) and all(type(n)is str and n not in ('','.','..') and '/' not in n for n in values),'invalid exact names')
    expected=images['canonical_driver'] if selected=='canonical' else next(v for v in images['driver_derivatives'] if v['id']==selected)
    driver_raw=base64.b64decode(expected['base64'] if selected=='canonical' else expected['after_base64'])
    require(sha(driver_raw)==g['derivative_sha256'],'selected whole derivative differs')
    if g['control']['mode']=='control':
        routed=next(x for x in images['routing_adapter_images'] if x['derivative']==selected and x['recipe']==g['control']['recipe'])
        require(routed['before_sha256']==sha(driver_raw),'routing beforeimage differs')
        driver_raw=base64.b64decode(routed['after_base64'])
    recovery_image=next(x for x in images['recovery_execution_images']if x['mode']==g['control']['mode']and x['derivative']==selected)
    require(recovery_image['before_sha256']==sha(driver_raw),'failed-recovery execution image does not extend original exact route')
    driver_raw=base64.b64decode(recovery_image['after_base64'])
    require(sha(driver_raw)==g['driver_sha256'],'complete bound route/recovery image differs')
    control=g['control']; require(control['derivative']==selected,'control/derivative mismatch')
    if control['mode']=='science':require(selected=='canonical' and type(control['recipe'])is int and control['recipe']==0 and control['target_ids']==[] and g['signal_roles']==[],'full scientific mode must remain original canonical all20 with no control activation')
    coverage=read_json(packet_dir/'intent-coverage.json');require(g['intent_coverage_sha256']==sha((packet_dir/'intent-coverage.json').read_bytes()),'intent/activation contract unbound')
    if control['mode']=='control':
        route=next(x for x in coverage['execution_routes'] if x['route_id']==control['route_id'])
        require(route['control']==control['id'] and route['derivative']==selected,'exact named route differs')
        require(control['recipe']==route['recipe'] and control['target_ids']==route['target_ids'],'exact original recipe/selector activation differs')
        require(all(control.get(k)==v for k,v in route['required_activation'].items()),'required actual original-resource activation differs')
        require(g['signal_roles']==route['required_signal_roles'],'exact separately granted signal role differs')
    require(sys.dont_write_bytecode and os.environ.get('GIT_OPTIONAL_LOCKS')=='0','prepared -B and optional-lock-disabled environment required')
    require(control['mode'] in ('science','control') and control['recipe'] in range(0,21),'invalid activation')
    require(set(control['target_ids'])<=set(p['fixture_requirements']),'unknown target ID')
    if control['mode']=='control':
        require(control['target_ids'] and all(p['fixture_requirements'][n] is True for n in control['target_ids']),'actual required fixture target missing')
        require(g['recovery']['prepared_before_execution'] is True and g['recovery']['root_disposition']=='EXPLICIT_ROOT_OWNED','recovery disposition absent')
        if control['id'] in UNRECOVERABLE or control.get('permanent') or selected in ('sole-existing-restoration-call-loss','positive-proof-return-liveness-loss','sole-no-child-branch-loss'):
            require(g['recovery']['mode']=='RETAIN_EXACT_QUARANTINE_UNTIL_NEW_ROOT_AUTHORITY','permanent/unsafe recovery may not synthesize ordinary proof')
    expected_programs={next(x['after_sha256'] for x in images['child_instrumentation_images'] if x['derivative']=='canonical'),next(x['after_sha256'] for x in images['child_instrumentation_images'] if x['derivative']==selected)}
    require(set(g['child_program_sha256s'])==expected_programs,'exact complete original/derivative child programs differ')
    require(g['child_program_by_phase']=={'canonical':next(x['after_sha256']for x in images['child_instrumentation_images']if x['derivative']=='canonical'),'red':next(x['after_sha256']for x in images['child_instrumentation_images']if x['derivative']==selected)},'exact phase-to-program binding differs')
    require(g['independent_observer']['pid_binding']=='EXACT_HARNESS_PID_FROM_EXCLUSIVE_START_RECORD','observer identity unbound')
    require(g['signal_roles']==[] or all(x in ('parent','child') for x in g['signal_roles']),'invalid signal grant')
    return g,p,driver_raw

# Inserted immediately before the existing observer instance, after every canonical
# observer definition, before original pytest.main. No original test/helper body edit.
CHILD_CONTROL_CODE = r'''
import dis, ast, fcntl, stat, base64
class NativeExceptionRegistry:
    """Strong native objects and unformatted first clock/TB/args before observers."""
    def __init__(self):self.objects={};self.pending={};self.operations={};self.operation_sequence=0
    def primitive(self,value):
        if type(value) in (str,int,float,bool,type(None)):return value
        if type(value)is bytes:return {'bytes_hex':value.hex()}
        if type(value)is tuple:return {'tuple':[self.primitive(x)for x in value]}
        return {'opaque_object':id(value),'type_module':type(value).__module__,'type_name':type(value).__qualname__}
    def call_facts(self,value):
        # Only own acyclic source-call fact dictionaries; arbitrary native args
        # retain the original opaque policy and cannot recurse through a cycle.
        if type(value)is dict:return {k:self.call_facts(v)for k,v in value.items()}
        if type(value)is list:return [self.call_facts(x)for x in value]
        return self.primitive(value)
    def arm(self,frame,operation,**facts):
        self.operation_sequence+=1
        row={'operation_sequence':self.operation_sequence,'operation':operation,'frame_object':id(frame),'file':frame.f_code.co_filename,'function':frame.f_code.co_name,'armed_line':frame.f_lineno,'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns(),**facts}
        self.operations[threading.get_ident()]=row
        return row
    def capture(self,frame,event_arg):
        typ,exc,tb=event_arg
        # First instructions: real clocks and actual objects; no __str__/repr,
        # clean(), inventory, JSON, file I/O, formatter or replacement exception.
        mono=time.monotonic_ns();wall=time.time_ns();key=id(exc)
        if key not in self.objects:
            self.objects[key]={'exception':exc,'traceback':tb,'type':typ,'first_monotonic_ns':mono,'first_utc_ns':wall,'first_frame':frame}
        strong=self.objects[key];chain=[];cursor=tb
        while cursor is not None:
            f=cursor.tb_frame;chain.append({'traceback_object':id(cursor),'frame_object':id(f),'file':f.f_code.co_filename,'function':f.f_code.co_name,'code_firstline':f.f_code.co_firstlineno,'line':cursor.tb_lineno,'lasti':cursor.tb_lasti});cursor=cursor.tb_next
        op=self.operations.get(threading.get_ident());bound=op if op is not None and any(t['frame_object']==op['frame_object']for t in chain)else None
        if bound is not None and bound['operation']in('open','write','fsync'):
            source_frame=next(t.tb_frame for t in self._tb_objects(tb)if id(t.tb_frame)==bound['frame_object'])
            local=source_frame.f_locals;argument_name={'open':'bad','write':'fd','fsync':'duplicate'}[bound['operation']]
            native_call=strong.get('actual_native_call')
            if native_call is None and argument_name in local and 'syscall_lineage'in local and 'native_call_capture'in local:
                actual_argument=local[argument_name]
                native_call={'argument':str(actual_argument)if bound['operation']=='open'else self.primitive(actual_argument),'lineage':self.primitive(local['syscall_lineage']),'immediate_pre_call':self.call_facts(local['native_call_capture']),'capture_frame_object':id(source_frame),'capture_line':source_frame.f_lineno}
                strong['actual_native_call']=native_call
            bound={**bound,'native_actual_call':native_call}
        row={'exception_object':key,'type_module':typ.__module__,'type':typ.__qualname__,'errno':OSError.errno.__get__(exc,typ)if isinstance(exc,OSError)else None,'args':self.primitive(BaseException.args.__get__(exc,typ)),'first_traceback_object':id(strong['traceback']),'traceback_object':id(tb),'traceback':chain,'first_monotonic_ns':strong['first_monotonic_ns'],'first_utc_ns':strong['first_utc_ns'],'observed_monotonic_ns':mono,'observed_utc_ns':wall,'operation':bound,'metadata_attempt':strong.get('metadata_attempt')}
        previous=self.pending.get(id(frame))
        if previous is not None and previous['handler_seen']:
            previous['latest_native']=row;previous.setdefault('secondary_native',[]).append(row)
        else:self.pending[id(frame)]={'native':row,'latest_native':row,'handler_seen':False}
        return row
    def _tb_objects(self,tb):
        rows=[]
        while tb is not None:rows.append(tb);tb=tb.tb_next
        return rows
    def line(self,frame,handler_lines,retry_line,nested_handler_lines=()):
        pending=self.pending.get(id(frame))
        if pending is None:return None
        if frame.f_lineno in handler_lines:pending['handler_seen']=True
        if frame.f_lineno in nested_handler_lines:pending['latest_native']=pending['native']
        if pending['handler_seen'] and frame.f_lineno==retry_line:
            self.pending.pop(id(frame));return {'disposition':'caught_then_original_retry','native':pending['native'],'frame_object':id(frame)}
        return None
    def exit(self,frame):
        pending=self.pending.pop(id(frame),None);opcode=dis.opname[frame.f_code.co_code[frame.f_lasti]]
        escaped=pending is not None and opcode not in ('RETURN_VALUE','RETURN_CONST','YIELD_VALUE','YIELD_FROM')
        return {'disposition':'escaped_exception'if escaped else 'normal_return','opcode':opcode,'native':None if pending is None else pending['latest_native'],'first_frame_fault':None if pending is None else pending['native'],'secondary_native':[]if pending is None else pending.get('secondary_native',[]),'handler_seen':False if pending is None else pending['handler_seen'],'frame_object':id(frame),'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns()}

class RecoveryAuthority:
    """Distinct failed recovery only; delivery is an externally ROOT-owned capability."""
    def __init__(self,protocol,execution_sha,role,pid,observer_pid):
        self.protocol=protocol;self.execution_sha=execution_sha;self.role=role;self.pid=pid;self.observer_pid=observer_pid;self.consumed=set();self.first_errors=[]
    @staticmethod
    def digest(raw):return hashlib.sha256(raw).hexdigest()
    @staticmethod
    def encode(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
    @staticmethod
    def exact_file(path):
        p=Path(path)
        try:s=p.lstat()
        except FileNotFoundError:return {'kind':'missing','path':str(p)}
        if not stat.S_ISREG(s.st_mode) or p.is_symlink():raise RuntimeError('recovery input is not exact regular non-symlink file')
        raw=p.read_bytes()
        return {'kind':'file','path':str(p),'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'raw_base64':base64.b64encode(raw).decode()}
    def load(self,stage,challenge,principal):
        delivery=Path(self.protocol['delivery_directory'])/('ROOT-recovery-'+stage+'.admission')
        if not delivery.exists():return None
        if not delivery.is_absolute()or delivery.parent.resolve()!=delivery.parent or delivery.is_symlink()or not delivery.is_file():raise RuntimeError('ROOT recovery delivery namespace/regular leaf changed before read')
        envelope=json.loads(delivery.read_bytes());authority=Path(envelope['authority_path'])
        prefix='ROOT-recovery-'+stage+'-';suffix='.authority';name=authority.name
        token=name[len(prefix):-len(suffix)]if name.startswith(prefix)and name.endswith(suffix)else''
        if not authority.is_absolute()or authority.parent!=delivery.parent or str(authority)!=os.path.normpath(str(authority))or authority.is_symlink()or len(token)!=32 or any(c not in '0123456789abcdef'for c in token):raise RuntimeError('foreign/malformed recovery authority path refused BEFORE its bytes are read')
        raw=authority.read_bytes();external=envelope['external_raw_sha256']
        if self.digest(raw)!=external or external==self.execution_sha:raise RuntimeError('new separate ROOT recovery raw SHA differs/reuses original execution grant')
        g=json.loads(raw)
        if g.get('schema')!='publication-native-root-failed-recovery/v1'or g.get('state')!='ROOT_AUTHORIZED_FAILED_RECOVERY'or g.get('approved_by')!='ROOT'or g.get('mode')!='RECOVERY_FAILED_UNQUALIFIED':raise RuntimeError('distinct ROOT failed recovery authority absent')
        if g['stage']!=stage or g['execution_authority_sha256']!=self.execution_sha or g['challenge_sha256']!=self.digest(self.encode(challenge))or self.encode(g['principal'])!=self.encode(principal):raise RuntimeError('recovery authority foreign to exact current owner/frame/challenge')
        if g['observer_pid']!=self.observer_pid or g['attempt_id']in self.consumed:raise RuntimeError('foreign observer/replayed recovery attempt')
        if g['ordinary_quiet_or_scientific_qualification']is not False or g['dependents_must_stop']is not True:raise RuntimeError('recovery cannot qualify original attempt or continue dependents')
        if type(g['attempt_id'])is not str or len(g['attempt_id'])!=32 or any(c not in '0123456789abcdef'for c in g['attempt_id']):raise RuntimeError('invalid exact recovery attempt identity')
        if authority!=delivery.parent/('ROOT-recovery-'+stage+'-'+g['attempt_id']+'.authority')or not authority.is_absolute()or authority.is_symlink()or delivery.is_symlink():raise RuntimeError('recovery authority outside exact exclusive delivery namespace')
        if not g['preserved_history_prefixes']:raise RuntimeError('original first-fault/negative history pins absent')
        for pin in g['preserved_history_prefixes']:
            if type(pin['bytes'])is not int or pin['bytes']<=0:raise RuntimeError('preserved history prefix must be nonempty exact bytes')
            b=Path(pin['path']).read_bytes()
            if len(b)<pin['bytes']or self.digest(b[:pin['bytes']])!=pin['sha256']:raise RuntimeError('original failed history was lost/replaced')
        return {'body':g,'raw_sha256':external,'authority_path':str(authority),'delivery':self.exact_file(delivery),'authority':self.exact_file(authority)}
    def consume(self,grant):self.consumed.add(grant['body']['attempt_id'])
    @staticmethod
    def exclusive_bytes(path,raw,mode=0o400):
        p=Path(path)
        if not p.is_absolute()or p.is_symlink()or p.exists():raise RuntimeError('recovery archive/blob must be new exclusive file')
        fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
        with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
        directory=os.open(p.parent,os.O_RDONLY)
        try:os.fsync(directory)
        finally:os.close(directory)
        return RecoveryAuthority.exact_file(p)
    @staticmethod
    def validate_resources(proof,contract,allow_close2=False):
        # Fresh source-owned objects, not old ordinary receipts or endpoint absence.
        if proof['pid']!=contract['pid']or proof['nodeid']not in contract['expected_ids']or proof['inflight']!=0 or type(proof['inflight'])is not int:raise RuntimeError('fresh exact owner/inflight proof absent')
        if proof['fixture_required']is not contract['fixture_requirements'][proof['nodeid']]:raise RuntimeError('recovery original source fixture requirement differs')
        groups=proof['registrations']
        if set(groups)!={'rig','broker','connection','worker'}:raise RuntimeError('recovery registration kinds incomplete')
        for kind,rows in groups.items():
            identities=[r['identity']for r in rows];keys={'pid','object'}|({'lock'}if kind=='broker'else{'thread','done'}if kind=='worker'else set())
            if len({RecoveryAuthority.encode(v)for v in identities})!=len(identities)or any(set(v)!=keys or any(type(x)is not int or x<=0 for x in v.values())for v in identities):raise RuntimeError('recovery unknown/duplicate/incomplete original identity')
            if [r['ordinal']for r in rows]!=list(range(1,len(rows)+1))or any(r['resource']!=kind or r['identity']['pid']!=proof['pid']for r in rows):raise RuntimeError('recovery exact registration order/principal differs')
        if [w['identity']for w in proof['workers']]!=[r['identity']for r in groups['worker']]:raise RuntimeError('fresh actual worker population differs')
        if any(w['alive']is not False or w['done']is not True or type(w['thread_ident'])is not int for w in proof['workers']):raise RuntimeError('actual owned worker not joined/done/identified')
        if proof['fixture_required']is True:
            if len(groups['rig'])!=1 or proof['rig_identity']!=groups['rig'][0]['identity']:raise RuntimeError('actual original registered rig absent')
        elif proof['rig_identity']is not None or any(groups[k]for k in ('rig','broker','connection')):raise RuntimeError('source-proved no-rig disposition differs')
        if [b['identity']for b in proof['brokers']]!=[r['identity']for r in groups['broker']]or [c['identity']for c in proof['connections']]!=[r['identity']for r in groups['connection']]:raise RuntimeError('actual broker/connection population differs')
        for broker in proof['brokers']:
            for r in broker['records'].values():
                if r['state']not in('LIVE','TERMINATED')or r['close_owner']is not None or any(a['pending']is not False for a in r['attempts']):raise RuntimeError('actual broker/establishment owner still active')
                if any(o['state']!='DONE'or o['response_write']not in('NOT_STARTED','NOT_WRITTEN','DONE','FAILED')for o in r['operations'].values()):raise RuntimeError('actual operation/write still active')
                if any(o['state']!='DONE'for o in r['deletes']+r['closures'])or any(o['response_write']not in('NOT_WRITTEN','DONE','FAILED')for o in r['closures']):raise RuntimeError('actual delete/closure still active')
        for c in proof['connections']:
            if type(c['closed'])is not int or c['closed']not in((1,2)if allow_close2 else(1,)):raise RuntimeError('actual transport physical settlement unavailable')
        expected_sources={'scripts.lean_slots.proxy':{'path':contract['proxy'],'sha256':contract['proxy_sha256']},'seed_journal':{'path':contract['journal'],'sha256':contract['journal_sha256']}}
        if proof['loaded_sources']!=expected_sources:raise RuntimeError('fresh loaded-source origin/hash proof differs')
        if any(x['closed']is not True for x in proof['publication_stream_owners']):raise RuntimeError('actual original publication handle not closed')
        if allow_close2 and proof['original_exact_once_contract_satisfied']is not False:raise RuntimeError('wrong close2 history must remain failed')
        return True

class OriginalResourceControl:
    def __init__(self, observer):
        self.o=observer;self.spec=cfg['native_control'];self.owned={};self.n=0
        self.previous_trace=sys.gettrace();self.native=NativeExceptionRegistry();self.close_patches={};self.retain_exception_history={};self.metadata_sequence=0;self.metadata_current={};self.metadata_failures={};self.metadata_caught={};self.metadata_frames=[]
        tree=ast.parse('\n'.join(self.spec['observer_lines']));self.retain_retry=None;self.retain_handlers=set();self.retain_nested_handlers=set()
        for method in ast.walk(tree):
            if isinstance(method,ast.FunctionDef)and method.name=='retain'and method.lineno==observer.retain.__func__.__code__.co_firstlineno:
                for node in ast.walk(method):
                    if isinstance(node,ast.Try)and any(isinstance(v,ast.Return)for v in node.body):
                        self.retain_retry=node.body[0].lineno;self.retain_handlers={h.body[0].lineno for h in node.handlers}
                self.retain_nested_handlers={h.body[0].lineno for h in ast.walk(method)if isinstance(h,ast.ExceptHandler)}-self.retain_handlers
        if self.retain_retry is None and self.spec['derivative']!='sole-observer-retention-loss':raise RuntimeError('exact retain retry source missing')
        self.original_emit=globals()['emit'];self.stream_fd={};self.stream_owners={};self.retained_stream_owners=[];self.io_admissions={};self.gated=set()
        self.o._root_recovery=self
        self.install_stream_fault()
        sys.settrace(self.trace);threading.settrace(self.trace)
        old=observer.quiet_attempt
        def attempt(context,stage):
            if self.target(context):self.activate(context,stage)
            self.release_if_authorized(context)
            return old(context,stage)
        observer.quiet_attempt=attempt
    def recovery_resources(self,c):
        # Reobserve actual original retained registrations, never damaged ordinary
        # serialized inventories. No original context/counter/record is repaired.
        rows={k:[x['row']for x in v]for k,v in c['registered'].items()}
        rigs=[x['object']for x in c['registered']['rig']]
        if c['fixture_required']and len(rigs)!=1:raise RuntimeError('recovery original registered rig unavailable')
        rig=rigs[0]if rigs else None
        actual={'rig':rigs,'broker':[]if rig is None else list(rig.brokers),'connection':[]if rig is None else list(rig.connections),'worker':list(c['workers'])}
        for kind,objects in actual.items():
            expected=[x['object']for x in c['registered'][kind]]
            if len(objects)!=len(expected)or any(a is not b for a,b in zip(objects,expected)):raise RuntimeError('fresh recovery original object population differs')
        brokers=[]
        for b in actual['broker']:
            if not b._lock.acquire(timeout=1):raise RuntimeError('fresh recovery metadata unavailable')
            try:
                records=self.formatted(copy.deepcopy(b._backend))
                if type(records)is not dict or 'native_format_error'in records:raise RuntimeError('fresh recovery backend cannot be represented; native formatting history retained')
            finally:b._lock.release()
            brokers.append({'identity':self.o.identity('broker',b),'records':records})
        connections=[{'identity':self.o.identity('connection',x),'closed':x.closed}for x in actual['connection']]
        return {'pid':os.getpid(),'nodeid':c['item'].nodeid,'context_object':id(c),'fixture_required':c['fixture_required'],'registrations':rows,'rig_identity':None if rig is None else self.o.identity('rig',rig),'workers':[{'identity':self.o.identity('worker',w),'thread_ident':w.thread.ident,'alive':w.thread.is_alive(),'done':w.done.is_set()}for w in actual['worker']],'inflight':c['inflight'],'brokers':brokers,'connections':connections,'publication_stream_owners':[{'owner_object':id(handle),'closed':handle.closed}for handle in self.retained_stream_owners],'original_exact_once_contract_satisfied':all(type(x.closed)is int and x.closed==1 for x in actual['connection']),'loaded_sources':{name:{'path':str(Path(sys.modules[name].__file__).resolve()),'sha256':hashlib.sha256(Path(sys.modules[name].__file__).read_bytes()).hexdigest()}for name in ('scripts.lean_slots.proxy','seed_journal')if name in sys.modules}}
    def recovery_owner_actions(self,c,authorization):
        owner=self.owned.get(c['item'].nodeid);actions=authorization['body']['owner_actions']
        expected=[]
        if owner is not None and not owner.get('released'):
            if 'release'in owner:expected.append({'action':'SET_EXACT_OWNED_EVENT_AND_ORIGINAL_JOIN','event_object':id(owner['release']),'worker':self.o.identity('worker',owner['worker'])})
            if owner.get('ticket')is not None:expected.append({'action':'FINISH_EXACT_OWNED_UNSENT_TICKET','broker':self.o.identity('broker',owner['broker']),'ticket_object':id(owner['ticket'])})
            if owner.get('deferred_closes')and not owner.get('deferred_consumed_by_exact_worker'):expected.extend({'action':'ONE_ORIGINAL_DEFERRED_CLOSE','connection':self.o.identity('connection',conn)}for conn,_ in owner['deferred_closes'])
        if RecoveryAuthority.encode(actions)!=RecoveryAuthority.encode(expected):raise RuntimeError('ROOT recovery actions differ from actual original owner capabilities')
        if owner is None:return
        if owner.get('ticket')is not None and not owner.get('released'):
            b=owner['broker'];t=owner['ticket']
            with b._lock:
                r=b._backend[t['key']]
                if r['operations'].get(t['id'])is not t or t['state']!='PENDING'or t['phase']!='ADMITTED'or t['mapping']is not None or t['response_write']!='NOT_STARTED':raise RuntimeError('recovery cannot generic-abort a foreign/dispatched ticket')
                b.finish(t,error=RuntimeError('explicit NEW ROOT RECOVERY_FAILED_UNQUALIFIED abort of this exact control-owned unsent ticket'))
        if 'release'in owner and not owner.get('released'):owner['release'].set();self.o.module._term_join(owner['worker'])
        for conn,original in ([]if owner.get('released')or owner.get('deferred_consumed_by_exact_worker')else owner.get('deferred_closes',[])):
            if type(conn.closed)is not int or conn.closed!=0:raise RuntimeError('deferred actual original close already consumed')
            original(conn)
            if conn.closed!=1:raise RuntimeError('original deferred close did not close exactly once')
        owner['released']=True
    def recovery_checkpoint(self,observer,c,frame):
        if self.spec['mode']=='control'and cfg['phase']=='red'and c.get('result_saved')is True:
            published=self.__dict__.setdefault('recovery_context_registries',{})
            if c['item'].nodeid not in published:
                actual=self.observed_actual(c)
                if 'registered'not in actual:raise RuntimeError('complete original context source registry unavailable')
                self.raw('RECOVERY_CONTEXT_SOURCE_REGISTRY',nodeid=c['item'].nodeid,actual=actual)
                published[c['item'].nodeid]=actual['registered']
        if self.spec['mode']!='control'or cfg['phase']!='red'or not self.target(c)or c.get('result_saved')is not True:return None
        if not cfg.get('recovery_protocol')or getattr(self,'recovery_original_source_edge',None)is None:return None
        if self.recovery_original_source_edge.get('actual',{}).get('nodeid')!=c['item'].nodeid:return None
        if getattr(self,'recovery_failed',None)is not None:
            if self.recovery_failed['context_object']!=id(c):raise RuntimeError('recovery cannot continue dependent context')
            return {'mode':'RECOVERY_FAILED_UNQUALIFIED','quiescent':False,'problems':['original attempt permanently failed; distinct physical settlement only'],'context_object':id(c)}
        try:
            if not hasattr(self,'recovery_authority'):
                p=cfg['recovery_protocol'];self.recovery_authority=RecoveryAuthority(p,p['execution_authority_sha256'],'child',os.getpid(),p['observer_pid'])
            # First checkpoint is kept as a strong original frame/context. A
            # moving loop/clock/new audit error cannot substitute another owner.
            if not hasattr(self,'recovery_challenge'):
                self.recovery_frame=frame;self.recovery_context=c
                principal={'role':'child','pid':os.getpid(),'frame_object':id(frame),'context_object':id(c),'nodeid':c['item'].nodeid,'function':frame.f_code.co_name,'program_sha256':self.spec['program_sha256'],'config_path':sys.argv[1]}
                self.recovery_challenge={'original_source_edge':{'sequence':self.recovery_original_source_edge['sequence'],'kind':self.recovery_original_source_edge['kind'],'nodeid':c['item'].nodeid},'source_history_prefix':self.n,'principal':principal,'route_id':self.spec.get('route_id'),'registered':{k:[r['row']for r in v]for k,v in c['registered'].items()},'inflight':c['inflight'],'first_native_objects':[{'object':key,'first_monotonic_ns':v['first_monotonic_ns'],'first_utc_ns':v['first_utc_ns']}for key,v in self.native.objects.items()],'source_frame_held':True}
                self.raw('RECOVERY_CHILD_HELD',challenge=self.recovery_challenge,actual=self.observed_actual(c))
            a=self.recovery_authority.load('child',self.recovery_challenge,self.recovery_challenge['principal'])
            if a is None:return None
            if c is not self.recovery_context:raise RuntimeError('original recovery context changed')
            if c['item'].nodeid!=cfg['recovery_protocol']['expected_ids'][-1]:raise RuntimeError('failed recovery cannot silently drop remaining original selected IDs')
            self.recovery_owner_actions(c,a)
            proof=self.recovery_resources(c)
            contract={'pid':os.getpid(),'expected_ids':cfg['recovery_protocol']['expected_ids'],'proxy':cfg['proxy'],'proxy_sha256':cfg['proxy_sha256'],'journal':cfg['journal'],'journal_sha256':cfg['journal_sha256'],'fixture_requirements':cfg['fixture_requirements']}
            close2=self.spec['id']=='M2-close-two'and self.spec.get('route_id')in('route-025','route-026')
            RecoveryAuthority.validate_resources(proof,contract,close2)
            row=self.raw('RECOVERY_CHILD_SETTLED_FAILED',authority=a,challenge=self.recovery_challenge,proof=proof,original_history_invalid=True,ordinary_quiet=False)
            request=Path(self.spec['channel'])/('child-%s-%08d.json'%(os.getpid(),row['sequence']));ack=request.with_suffix('.recovery-ack')
            while not ack.exists():time.sleep(.05)
            admitted=json.loads(ack.read_bytes())
            if admitted['status']!='INDEPENDENT_RECOVERY_FAILED_UNQUALIFIED'or admitted['observer_pid']!=self.spec['independent_observer_pid']or admitted['request_sha256']!=hashlib.sha256(request.read_bytes()).hexdigest()or admitted['recovery_authority_sha256']!=a['raw_sha256']:raise RuntimeError('distinct independent recovery ACK differs')
            self.recovery_authority.consume(a);self.recovery_failed={'mode':'RECOVERY_FAILED_UNQUALIFIED','context_object':id(c),'authorization':a,'challenge':self.recovery_challenge,'proof':proof,'independent_ack':admitted};c['failed_unqualified_recovery']=True
            return {'mode':'RECOVERY_FAILED_UNQUALIFIED','quiescent':False,'problems':['physical resources settled under NEW ROOT; ordinary history remains invalid'],'context_object':id(c)}
        except BaseException:
            self.__dict__.setdefault('recovery_errors',[]).append(self.native.capture(sys._getframe(),sys.exc_info()))
            return None # original guard/owner remains held, never exception-as-quiet
    def recovery_finish(self,observer,session,exitstatus):
        if getattr(self,'recovery_failed',None)is None:return False
        proofs=[self.recovery_resources(c)for c in observer.contexts]
        for p in proofs:RecoveryAuthority.validate_resources(p,{'pid':os.getpid(),'expected_ids':observer.collections,'proxy':cfg['proxy'],'proxy_sha256':cfg['proxy_sha256'],'journal':cfg['journal'],'journal_sha256':cfg['journal_sha256'],'fixture_requirements':cfg['fixture_requirements']},self.spec['id']=='M2-close-two'and p['nodeid']==self.recovery_challenge['principal']['nodeid'])
        if [c['item'].nodeid for c in observer.contexts]!=observer.collections:raise RuntimeError('recovery cannot substitute a context subset for full original collection')
        if any(c['teardown_complete']is not True for c in observer.contexts):raise RuntimeError('actual original fixture teardown incomplete in failed recovery')
        self.raw('RECOVERY_CHILD_FINAL_FAILED',authorization_sha256=self.recovery_failed['authorization']['raw_sha256'],proofs=proofs,contexts=[{'nodeid':c['item'].nodeid,'teardown_complete':c['teardown_complete']}for c in observer.contexts],collection=observer.collections,original_faults=observer.faults,recovery_secondary_native_errors=getattr(self,'recovery_errors',[]),ordinary_quiet=False,scientific_qualification=False,dependents_stopped=True)
        for n,v in observer.original.items():
            if n=='_thread_start':threading.Thread.start=v
            else:setattr(observer.module,n,v)
        session.exitstatus=1 # natural pytest return through the existing sys.exit(code)
        return True

    def target(self,c):
        return self.spec['mode']=='control' and cfg['phase']=='red' and cfg['recipe']==self.spec['recipe'] and c['item'].nodeid in self.spec['target_ids']
    def actual(self,c):
        rig=next((x['object'] for x in c['registered']['rig']),None)
        owner=self.owned.get(c['item'].nodeid);metadata_owner=None
        if owner is not None and owner.get('acquired')is not None and owner['acquired'].is_set()and not owner['release'].is_set():
            metadata_owner={'broker':self.o.identity('broker',owner['broker']),'worker':self.o.identity('worker',owner['worker']),'release_event_object':id(owner['release']),'acquired_event_object':id(owner['acquired'])}
        return {'nodeid':c['item'].nodeid,'fixture_required':c['fixture_required'],'rig':None if rig is None else self.o.identity('rig',rig),'registered':{k:[r['row'] for r in v] for k,v in c['registered'].items()},'workers':[{'identity':self.o.identity('worker',w),'alive':w.thread.is_alive(),'done':w.done.is_set(),'ident':w.thread.ident} for w in c['workers']],'control_deadline_ns':c.get('control_deadline_ns'),'metadata_owner':metadata_owner,'owned_lock':any(v.get('broker') is (None if rig is None or not rig.brokers else rig.brokers[0]) and v.get('acquired') is not None and v['acquired'].is_set() and not v['release'].is_set() for v in self.owned.values()),'inflight':c['inflight'],'connections':[] if rig is None else [{'identity':self.o.identity('connection',x),'closed':x.closed} for x in rig.connections]}
    def observed_actual(self,c):
        try:return self.actual(c)
        except BaseException:
            error=self.native.capture(sys._getframe(),sys.exc_info())
            return {'nodeid':c['item'].nodeid,'observation_error':error,'control_deadline_ns':c.get('control_deadline_ns')}
    def formatted(self,value):
        try:return clean(value)
        except BaseException:return {'native_format_error':self.native.capture(sys._getframe(),sys.exc_info())}
    def raw(self,event,**values):
        self.n+=1;row={'sequence':self.n,'kind':event,'pid':os.getpid(),'config_path':sys.argv[1],'program_sha256':self.spec['program_sha256'],'utc_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),**values}
        p=Path(self.spec['channel'])/('child-%s-%08d.json'%(os.getpid(),self.n))
        while True:
            try:
                pending=p.with_name(p.name+'.pending')
                with pending.open('x') as f:json.dump(row,f,sort_keys=True);f.flush();os.fsync(f.fileno())
                os.link(pending,p);pending.unlink()
                fd=os.open(p.parent,os.O_RDONLY)
                try:os.fsync(fd)
                finally:os.close(fd)
                break
            except BaseException as exc:
                self.__dict__.setdefault('audit_publication_failures',[]).append(self.native.capture(sys._getframe(),sys.exc_info()))
                # Preserve exact fixture frame on audit loss; no fake success.
                try:time.sleep(1)
                except BaseException as stopped:self.__dict__['audit_publication_failures'].append(self.native.capture(sys._getframe(),sys.exc_info()))
        return row
    def activate(self,c,stage):
        key=c['item'].nodeid
        if key in self.owned and self.owned[key].get('activated'):return
        require=c['fixture_required'] is True and len(c['registered']['rig'])==1
        if not require:raise RuntimeError('control requires actual registered original rig')
        rig=c['registered']['rig'][0]['object'];broker=rig.brokers[0]
        if not any(r['object'] is broker for r in c['registered']['broker']):raise RuntimeError('original broker registration unavailable')
        owner=self.owned.setdefault(key,{'rig':rig,'broker':broker,'context':c,'released':False});owner['activated']=True
        ident=self.spec['id'];worker_needed=self.spec.get('create_live_worker') is True
        if worker_needed and not self.spec.get('need_settled_worker'):
            release=threading.Event();acquired=threading.Event();owner.update(release=release,acquired=acquired)
            def wait_owned():
                if ident in ('M2-metadata-lock','M2-observation-deadline'):
                    with broker._lock:acquired.set();release.wait()
                else:
                    acquired.set();release.wait()
                    if self.spec.get('live_close_worker'):
                        for conn,original in owner.get('deferred_closes',[]):original(conn)
                        owner['deferred_consumed_by_exact_worker']=True
            owner['worker']=self.o.module._term_thread(wait_owned)
            if not acquired.wait(5):raise RuntimeError('actual owned worker did not reach original lock/Event')
        elif self.spec.get('need_settled_worker'):
            owner['worker']=self.o.module._term_thread(lambda:None)
            self.o.module._term_join(owner['worker'])
        if ident in ('M2-false-quiet','M2-unexpected-pending-ticket'):
            client=broker.mint();ticket=broker.admit(client)
            with broker._lock:
                record=broker._backend[ticket['key']]
                if record['operations'].get(ticket['id']) is not ticket or ticket['state']!='PENDING' or ticket['phase']!='ADMITTED' or ticket['mapping'] is not None or ticket['response_write']!='NOT_STARTED':raise RuntimeError('exact unsent owned admission not established')
            owner.update(ticket=ticket,client=client)
        if ident=='M2-close-two':
            if not rig.connections:raise RuntimeError('doubleclose control requires actual original nonempty transport')
            if any(w.thread.is_alive() or not w.done.is_set() for w in c['workers']):raise RuntimeError('doubleclose isolation requires stopped actual workers')
            conn=rig.connections[0]
            if conn.closed!=1:raise RuntimeError('doubleclose control starts at actual one close')
            type(conn).close(conn)
            if conn.closed!=2:raise RuntimeError('second actual original close did not occur')
            owner['doubleclosed']=conn
        if self.spec.get('need_connection') and not rig.connections:raise RuntimeError('connection omission cannot count on empty population')
        self.raw('CONTROL_ACTIVATED',control=ident,stage=stage,actual=self.observed_actual(c),owned_ticket_object=id(owner['ticket']) if 'ticket'in owner else None)
    def release_if_authorized(self,c):
        owner=self.owned.get(c['item'].nodeid)
        if not owner or owner['released']:return
        p=Path(self.spec['release_dir'])/(hashlib.sha256(c['item'].nodeid.encode()).hexdigest()+'.json')
        if not p.exists():return
        grant=json.loads(p.read_bytes())
        if grant.get('token')!=self.spec['release_token'] or grant.get('pid')!=os.getpid() or grant.get('nodeid')!=c['item'].nodeid:raise RuntimeError('release does not bind exact original owner')
        if owner.get('doubleclosed') is not None:raise RuntimeError('actual doubleclose has no ordinary release')
        if 'ticket'in owner:
            b=owner['broker'];t=owner['ticket']
            with b._lock:
                r=b._backend[t['key']]
                if r['operations'].get(t['id']) is not t or t['state']!='PENDING' or t['phase']!='ADMITTED' or t['mapping'] is not None or t['response_write']!='NOT_STARTED':raise RuntimeError('owned unsent ticket changed; no substitute abort')
                b.finish(t,error=RuntimeError('ROOT-authorized abort of exact unsent control ticket'))
        if 'release'in owner:owner['release'].set();self.o.module._term_join(owner['worker'])
        for conn,original in ([] if owner.get('deferred_consumed_by_exact_worker') else owner.get('deferred_closes',[])):
            if conn.closed!=0:raise RuntimeError('deferred original transport state changed')
            original(conn)
            if conn.closed!=1:raise RuntimeError('deferred real close did not close once')
        owner['released']=True;self.raw('CONTROL_ORIGINAL_OWNER_RELEASED',actual=self.observed_actual(c))
    def patch_close(self,context,cls):
        if cls in self.close_patches:return
        original=cls.close;self.close_patches[cls]=original
        def close(conn):
            if self.target(context) and self.spec['id']=='M2-close-zero':
                owner=self.owned.setdefault(context['item'].nodeid,{'rig':context['registered']['rig'][0]['object'],'broker':context['registered']['broker'][0]['object'],'context':context,'released':False})
                values=owner.setdefault('deferred_closes',[])
                if any(x is conn for x,_ in values):raise RuntimeError('same transport deferred twice')
                values.append((conn,original));self.raw('ORIGINAL_CLOSE_DEFERRED',connection=self.o.identity('connection',conn),closed=conn.closed)
                return None
            return original(conn)
        cls.close=close
    def io_file_identity(self,path):
        st=os.stat(path,follow_symlinks=False)
        if not stat.S_ISREG(st.st_mode):raise RuntimeError('actual IO capability is not regular file')
        return {'path':str(path),'device':st.st_dev,'inode':st.st_ino,'mode':st.st_mode,'uid':st.st_uid,'gid':st.st_gid,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns}
    def io_fd_identity(self,fd):
        st=os.fstat(fd)
        return {'fd':fd,'device':st.st_dev,'inode':st.st_ino,'mode':st.st_mode,'uid':st.st_uid,'gid':st.st_gid,'flags':fcntl.fcntl(fd,fcntl.F_GETFL),'fd_flags':fcntl.fcntl(fd,fcntl.F_GETFD)}
    def io_rendezvous(self,kind,frame,**facts):
        row=self.raw(kind,source_frame={'frame_object':id(frame),'file':frame.f_code.co_filename,'function':frame.f_code.co_name,'line':frame.f_lineno,'code_firstline':frame.f_code.co_firstlineno},**facts)
        path=Path(self.spec['channel'])/('child-%s-%08d.json'%(os.getpid(),row['sequence']));ack=path.with_suffix('.ack')
        while True:
            try:
                if ack.exists():
                    grant=json.loads(ack.read_bytes())
                    if grant['status']!='INDEPENDENT_IO_IDENTITY_ADMITTED'or grant['observer_pid']!=self.spec['independent_observer_pid']or grant['request_sha256']!=hashlib.sha256(path.read_bytes()).hexdigest():raise RuntimeError('exact IO admission ACK differs')
                    return row,grant
                time.sleep(.05)
            except BaseException:self.native.capture(sys._getframe(),sys.exc_info())
    def actual_call(self,operation,argument,lineage,owner):
        # argument is the actual local passed to the native callable, not ACK data.
        if operation=='open':
            if not isinstance(argument,Path):raise RuntimeError('actual ENOTDIR argument type changed')
            return {'argument':str(argument),'lineage':{'tuple':list(lineage)},'descriptor':None,'owner':None}
        if type(argument)is not int or argument<0:raise RuntimeError('native descriptor must be a real nonnegative int')
        if type(lineage)is not tuple or len(lineage)!=5:raise RuntimeError('actual descriptor creation lineage absent')
        creator,source_fd,created_fd,closed_fd,close_result=lineage
        if type(created_fd)is not int or created_fd<0 or argument!=created_fd:raise RuntimeError('syscall argument differs from actual created descriptor')
        if operation=='write':
            if creator!='os.open-readonly' or source_fd is not None or closed_fd is not None or close_result is not None:raise RuntimeError('actual readonly open lineage differs')
            descriptor=self.io_fd_identity(argument)
        else:
            if creator!='os.dup-close' or type(source_fd)is not int or source_fd<0 or closed_fd!=created_fd or close_result is not None:raise RuntimeError('actual duplicate close lineage differs')
            if owner['object'].fileno()!=source_fd:raise RuntimeError('duplicate source is not actual retained original owner')
            descriptor=None # this exact duplicate was closed; retained before identity is separately bound.
        return {'argument':argument,'lineage':{'tuple':list(lineage)},'descriptor':descriptor,'owner':{'owner_object':id(owner['object']),'closed':owner['object'].closed,'fd_identity':self.io_fd_identity(owner['object'].fileno())}}
    def pre_io(self,frame,operation,**facts):
        row,ack=self.io_rendezvous('IO_BEFORE_NATIVE_SYSCALL',frame,operation=operation,requested_stream=str(stream),actual=None if active is None else self.observed_actual(active),**facts)
        admitted=ack['exact_operation'];self.io_admissions[row['sequence']]=admitted
        return self.native.arm(frame,operation,admission_sequence=row['sequence'],admission_request_sha256=ack['request_sha256'])
    def immediately_before_call(self,operation,argument,lineage,owner,admitted_capture):
        actual=self.actual_call(operation,argument,lineage,owner)
        if actual!=admitted_capture:raise RuntimeError('actual syscall argument/owner changed after independent admission; no native marker/release')
        return actual
    def install_stream_fault(self):
        if self.spec.get('stream_fault')not in('open','write','fsync'):return
        original_open=Path.open;original_write=os.write;original_fsync=os.fsync
        def selected():return self.spec['mode']=='control'and cfg['phase']=='red'
        def armed():return active is not None and self.target(active)and active.get('result_saved')and not Path(self.spec['remove_fault_path']).exists()
        def opened(path,*args,**kw):
            if Path(path)==stream and armed()and self.spec['stream_fault']=='open':
                bad=Path(self.spec['os_fault_file'])/'observer.jsonl';syscall_lineage=('Path.open',str(bad),None,None,None)
                actual_call=self.actual_call('open',bad,syscall_lineage,None)
                self.pre_io(sys._getframe(),'open',actual_call=actual_call,actual_path=str(bad),stream_identity=self.io_file_identity(stream),fault_identity=self.io_file_identity(self.spec['os_fault_file']),stream_owner=None,stream_owner_now=None,descriptor=None,duplication=None)
                native_call_capture=self.immediately_before_call('open',bad,syscall_lineage,None,actual_call)
                return original_open(bad,*args,**kw) # actual ENOTDIR
            handle=original_open(path,*args,**kw)
            if Path(path)==stream:
                fd=handle.fileno();self.stream_fd[fd]=(os.fstat(fd).st_dev,os.fstat(fd).st_ino)
                if selected():
                    lease={'owner_object':id(handle),'fd_identity':self.io_fd_identity(fd),'file_identity':self.io_file_identity(stream)}
                    self.retained_stream_owners.append(handle);self.stream_owners[fd]={'object':handle,'lease':lease}
                    row,ack=self.io_rendezvous('ACTUAL_STREAM_OWNER_OPENED',sys._getframe(),lease=lease,actual=None if active is None else self.observed_actual(active))
                    self.stream_owners[fd]['admitted_lease']=ack['exact_operation']
            return handle
        self_control=self
        class PublicationFile:
            def __init__(self,real):self.real=real
            def __enter__(self):self.real.__enter__();return self
            def __exit__(self,*args):return self.real.__exit__(*args)
            def write(self,value):
                if armed()and self_control.spec['stream_fault']=='write':
                    original_fd=self.real.fileno();owner=self_control.stream_owners[original_fd]
                    if owner['object']is not self.real:raise RuntimeError('exact original stream owner changed')
                    created_fd=os.open(self_control.spec['os_fault_file'],os.O_RDONLY);fd=created_fd;syscall_lineage=('os.open-readonly',None,created_fd,None,None)
                    try:
                        actual_call=self_control.actual_call('write',fd,syscall_lineage,owner)
                        self_control.pre_io(sys._getframe(),'write',actual_call=actual_call,actual_path=self_control.spec['os_fault_file'],stream_identity=self_control.io_file_identity(stream),fault_identity=self_control.io_file_identity(self_control.spec['os_fault_file']),stream_owner=owner['admitted_lease'],stream_owner_now={'owner_object':id(self.real),'closed':self.real.closed,'fd_identity':self_control.io_fd_identity(original_fd)},descriptor=self_control.io_fd_identity(fd),duplication=None)
                        native_call_capture=self_control.immediately_before_call('write',fd,syscall_lineage,owner,actual_call)
                        return original_write(fd,value.encode()) # actual read-only EBADF
                    finally:os.close(fd)
                return self.real.write(value)
            def flush(self):return self.real.flush()
            def fileno(self):return self.real.fileno()
        def file_open(path,*args,**kw):
            handle=opened(path,*args,**kw)
            return PublicationFile(handle)if Path(path)==stream and self.spec['stream_fault']=='write'else handle
        def fsync(fd):
            if fd in self.stream_fd and(os.fstat(fd).st_dev,os.fstat(fd).st_ino)==self.stream_fd[fd]and armed()and self.spec['stream_fault']=='fsync':
                owner=self.stream_owners[fd]
                if owner['object'].fileno()!=fd:raise RuntimeError('actual stream owner fd changed')
                created_duplicate=os.dup(fd);duplicate=created_duplicate;before=self.io_fd_identity(created_duplicate);close_argument=created_duplicate;closed=os.close(close_argument);syscall_lineage=('os.dup-close',fd,created_duplicate,close_argument,closed)
                actual_call=self.actual_call('fsync',duplicate,syscall_lineage,owner)
                self.pre_io(sys._getframe(),'fsync',actual_call=actual_call,actual_path=str(stream),stream_identity=self.io_file_identity(stream),fault_identity=self.io_file_identity(self.spec['os_fault_file']),stream_owner=owner['admitted_lease'],stream_owner_now={'owner_object':id(owner['object']),'closed':owner['object'].closed,'fd_identity':self.io_fd_identity(fd)},descriptor=before,duplication={'source_fd':fd,'duplicate_fd':duplicate,'before':before,'close_called_fd':duplicate,'close_return':closed})
                native_call_capture=self.immediately_before_call('fsync',duplicate,syscall_lineage,owner,actual_call)
                return original_fsync(duplicate) # actual EBADF; original stream remains open
            return original_fsync(fd)
        Path.open=file_open;os.fsync=fsync
    def await_exact_owner(self,c,row):
        # This callback retains the actual source frame, native exception and
        # original owner while the independent observer inspects the exact edge.
        if c is None:return
        control=self.spec['id'];kind=row['kind'];edge=row.get('frame_exit')or{}
        waiting=(control=='M2-observer-IO' and (kind=='NATIVE_RETAIN_CAUGHT_RETRY'or(kind=='SOURCE_FRAME_EXIT'and edge.get('disposition')=='escaped_exception')))or(control=='M2-observation-deadline'and((self.spec['derivative']=='canonical'and kind=='NATIVE_RETAIN_CAUGHT_RETRY'and len(self.metadata_caught.get((c['item'].nodeid,id(c)),set()))>=2)or(self.spec['derivative']=='diagnostic-deadline-as-observer-exit'and kind=='SOURCE_FRAME_EXIT'and edge.get('disposition')=='escaped_exception')))or(control=='M2-metadata-lock'and(kind=='NATIVE_RETAIN_CAUGHT_RETRY'or kind=='AFTER_ORIGINAL_METADATA_READ'))
        if not waiting or c is None:return
        release=Path(self.spec['release_dir'])/(hashlib.sha256(c['item'].nodeid.encode()).hexdigest()+'.json')
        marker=Path(self.spec['remove_fault_path'])if self.spec.get('stream_fault')else None
        while not (marker.exists()if marker is not None else release.exists()):
            if self.recovery_checkpoint(self.o,c,sys._getframe())is not None:return
            try:time.sleep(.05)
            except BaseException:
                self.native.capture(sys._getframe(),sys.exc_info())
        self.release_if_authorized(c)
    def trace(self,frame,event,arg):
        if frame.f_globals is not globals():return self.trace
        name=frame.f_code.co_name;loc=frame.f_locals;c=loc.get('context') or active
        relevant={'quiet_attempt','inventory','rig','retain','request_stop','pytest_runtest_teardown','opened','write','fsync'}
        if name=='serve' and event=='line' and 'connection_class'in loc and c is not None and self.target(c):self.patch_close(c,loc['connection_class'])
        if name not in relevant or(c is not None and not self.target(c)):return self.trace
        row=None
        if event=='exception':
            native=self.native.capture(frame,arg) # BEFORE actual(), clean(), formatting, JSON
            if name=='rig'and c is not None and native['type']=='RuntimeError'and native['args']=={'tuple':['actual metadata lock did not permit bounded observation']}:
                attempt=self.metadata_current.get(id(frame))
                if attempt is not None and native['traceback'][-1]['frame_object']==attempt['rig_frame_object']and native['traceback'][-1]['line']==attempt['acquire_line']:
                    native['metadata_attempt']=attempt;self.native.objects[native['exception_object']]['metadata_attempt']=attempt
            if name=='retain'and c is not None:
                self.retain_exception_history.setdefault((c['item'].nodeid,id(c)),[]).append(native)
                attempt=native.get('metadata_attempt')
                if attempt is not None and native['args']=={'tuple':['actual metadata lock did not permit bounded observation']}:
                    self.metadata_failures[(c['item'].nodeid,id(c),attempt['attempt_id'])]=native['exception_object']
            row=self.raw('SOURCE_EXCEPTION_EDGE',function=name,line=frame.f_lineno,exception=native,actual=None if c is None else self.observed_actual(c))
        elif event=='line':
            if name=='retain':
                caught=self.native.line(frame,self.retain_handlers,self.retain_retry,self.retain_nested_handlers)
                if caught is not None:
                    attempt=caught['native'].get('metadata_attempt')
                    if attempt is not None and self.metadata_failures.get((c['item'].nodeid,id(c),attempt['attempt_id']))==caught['native']['exception_object']:
                        self.metadata_caught.setdefault((c['item'].nodeid,id(c)),set()).add(attempt['attempt_id'])
                    row=self.raw('NATIVE_RETAIN_CAUGHT_RETRY',function=name,line=frame.f_lineno,frame_exit=caught,actual=None if c is None else self.observed_actual(c))
            if name=='rig' and 'broker'in loc:
                source=self.spec['observer_lines'];line=source[frame.f_lineno-1]if 0<frame.f_lineno<=len(source)else ''
                if 'broker._lock.acquire(timeout=1)'in line and self.spec['id']in('M2-metadata-lock','M2-observation-deadline')and self.observed_actual(c).get('owned_lock')is True and self.owned[c['item'].nodeid]['broker']is loc['broker']:
                    retain=frame.f_back
                    while retain is not None and not(retain.f_code.co_name=='retain'and retain.f_locals.get('context')is c):retain=retain.f_back
                    if retain is None:raise RuntimeError('actual metadata attempt has no same original retain frame')
                    self.metadata_sequence+=1;self.metadata_frames.extend((frame,retain))
                    attempt={'attempt_id':self.metadata_sequence,'nodeid':c['item'].nodeid,'context_object':id(c),'retain_frame_object':id(retain),'rig_frame_object':id(frame),'broker':self.o.identity('broker',loc['broker']),'metadata_owner':self.observed_actual(c)['metadata_owner'],'pid':os.getpid(),'config_path':sys.argv[1],'program_sha256':self.spec['program_sha256'],'source_file':frame.f_code.co_filename,'acquire_line':frame.f_lineno,'monotonic_ns':time.monotonic_ns()}
                    self.metadata_current[id(frame)]=attempt;self.raw('METADATA_ATTEMPT_STARTED',attempt=attempt,actual=self.observed_actual(c))
                if 'copy.deepcopy(broker._backend)'in line:row=self.raw('BEFORE_ORIGINAL_METADATA_READ',line=frame.f_lineno,broker=self.o.identity('broker',loc['broker']),actual=self.observed_actual(c))
                if 'finally:broker._lock.release()'in line:row=self.raw('AFTER_ORIGINAL_METADATA_READ',line=frame.f_lineno,broker=self.o.identity('broker',loc['broker']),records=self.formatted(loc.get('records')),actual=self.observed_actual(c))
        elif event=='return':
            edge=self.native.exit(frame) # Opcode+same native object distinguish occurrence from escape.
            if name=='quiet_attempt':row=self.raw('ACTUAL_QUIET_RETURN',line=frame.f_lineno,receipt=self.formatted(arg),frame_exit=edge,actual=self.observed_actual(c))
            elif name in ('retain','request_stop'):row=self.raw('SOURCE_FRAME_EXIT',function=name,line=frame.f_lineno,frame_exit=edge,result=self.formatted(arg)if edge['disposition']=='normal_return'else None,signum=loc.get('signum'),stop_requests=self.formatted(stop_requests),actual=None if c is None else self.observed_actual(c))
        if row is not None:
            if c is not None and c.get('result_saved')is True and row['kind']in('NATIVE_RETAIN_CAUGHT_RETRY','ACTUAL_QUIET_RETURN','SOURCE_FRAME_EXIT')and not hasattr(self,'recovery_original_source_edge'):self.recovery_original_source_edge=row
            self.await_exact_owner(c,row)
            if c is not None and self.spec.get('permanent')and c.get('result_saved')is True and row['kind']in('NATIVE_RETAIN_CAUGHT_RETRY','ACTUAL_QUIET_RETURN','SOURCE_FRAME_EXIT'):
                while self.recovery_checkpoint(self.o,c,frame)is None:
                    try:time.sleep(.05)
                    except BaseException:self.native.capture(sys._getframe(),sys.exc_info())
        if c is not None:self.release_if_authorized(c)
        return self.trace
_harness_control=OriginalResourceControl(observer)
'''

class SourceTap:
    """Observe exact parent/journal edges; original owners keep all exit decisions."""
    def __init__(self, driver, grant, channel):
        self.d=driver;self.g=grant;self.channel=channel;self.n=0;self.native=NativeExceptionRegistry()
        self.driver_path=str(Path(grant['driver_path']).resolve())
        self.journal_path=str(Path(grant['journal_helper']).resolve())
        self.previous=None;self.file_hold=None;self.child_bound=set();self.seed_owner_frame=None;self.canonical_restore=None;self.failed_recovery=None;self.campaign=None;self.observer_pid=None
    def retained_source_hash(self,frame):
        while True:
            try:return sha(Path(frame.f_code.co_filename).read_bytes())
            except BaseException as exc:
                self.__dict__.setdefault('audit_source_failures',[]).append(self.native.capture(sys._getframe(),sys.exc_info()))
                try:time.sleep(1)
                except BaseException as stopped:self.__dict__['audit_source_failures'].append(self.native.capture(sys._getframe(),sys.exc_info()))
    def request(self,kind,frame,extra=None):
        self.n+=1
        row={'sequence':self.n,'kind':kind,'pid':os.getpid(),'frame_object':id(frame),'function':frame.f_code.co_name,'line':frame.f_lineno,'file':frame.f_code.co_filename,'source_sha256':self.retained_source_hash(frame),'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns(),'extra':extra or {}}
        while True:
            try:
                durable(self.channel/('parent-%08d.json'%self.n),row);break
            except BaseException as exc:
                self.__dict__.setdefault('audit_publication_failures',[]).append(self.native.capture(sys._getframe(),sys.exc_info()))
                try:time.sleep(1)
                except BaseException as stopped:self.__dict__['audit_publication_failures'].append(self.native.capture(sys._getframe(),sys.exc_info()))
        return row
    def rendezvous(self,kind,frame,extra=None):
        r=self.request(kind,frame,extra);request=self.channel/('parent-%08d.json'%r['sequence']);ack=request.with_suffix('.ack')
        # No elapsed-time release. Observer disappearance leaves this original
        # journal/source frame and lock in scope; later ROOT recovery is separate.
        while True:
            try:
                if kind=='BEFORE_ORIGINAL_RESTORE'and self.failed_recovery is not None:
                    disposition=self.failed_recovery.checkpoint(self.campaign,frame)
                    if disposition is not None:return self.failed_recovery.wait_at_original_restore(self.campaign,frame)
                if ack.exists():
                    a=read_json(ack);require(a['request_sha256']==sha(request.read_bytes()) and a['status']=='INDEPENDENT_SNAPSHOT_DURABLE','independent snapshot refusal')
                    return a
                time.sleep(.05)
            except BaseException as exc:
                # Invalid/unreadable ACK or signal cannot unwind this original
                # journal frame/path lock. Preserve fault and retain quarantine.
                self.__dict__.setdefault('rendezvous_failures',[]).append(self.native.capture(sys._getframe(),sys.exc_info()))
                try:time.sleep(1)
                except BaseException as stopped:self.__dict__['rendezvous_failures'].append(self.native.capture(sys._getframe(),sys.exc_info()))
    def recovery_request(self,kind,frame,extra):return self.request(kind,frame,extra)
    def recovery_rendezvous(self,kind,frame,extra):
        row=self.request(kind,frame,extra);path=self.channel/('parent-%08d.json'%row['sequence']);ack=path.with_suffix('.recovery-ack')
        while True:
            try:
                if ack.exists():
                    value=read_json(ack)
                    require(value['status']=='INDEPENDENT_RECOVERY_FAILED_UNQUALIFIED'and value['observer_pid']==self.observer_pid and value['request_sha256']==sha(path.read_bytes()),'distinct failed-recovery source ACK differs')
                    require(value['recovery_authority_sha256']==extra['authority']['raw_sha256'],'new recovery authority differs at actual source edge')
                    return value
                time.sleep(.05)
            except BaseException:self.__dict__.setdefault('failed_recovery_rendezvous_errors',[]).append(self.native.capture(sys._getframe(),sys.exc_info()))

    def trace(self,frame,event,arg):
        path=str(Path(frame.f_code.co_filename).resolve()) if not frame.f_code.co_filename.startswith('<') else frame.f_code.co_filename
        if path not in (self.driver_path,self.journal_path):return self.trace
        name=frame.f_code.co_name;loc=frame.f_locals
        native=self.native.capture(frame,arg)if event=='exception'else None
        if path==self.journal_path:
            if event=='exception':self.request('PARENT_JOURNAL_EXCEPTION_EDGE',frame,{'exception':native})
            if name=='_open_entry' and event=='return':
                edge=self.native.exit(frame)
                if edge['disposition']=='escaped_exception':self.request('PARENT_JOURNAL_FRAME_EXIT',frame,{'frame_exit':edge})
                else:
                    self.canonical_restore=frame.f_globals['_restore'];self.rendezvous('ORIGINAL_DURABLE_ENTRY_BEFORE_SEED',frame,{'entry':arg})
            elif name=='seeded_mutation' and event=='return' and type(arg)is bytes:
                self.seed_owner_frame=frame;self.rendezvous('ORIGINAL_SEEDED_YIELD',frame)
            elif name=='_restore' and event=='call':
                recovery=self.failed_recovery
                if recovery is not None and(recovery.active is not None or self.g['recovery']['mode']=='RETAIN_EXACT_QUARANTINE_UNTIL_NEW_ROOT_AUTHORITY'):
                    if recovery.active is None and self.g['control']['derivative']=='sole-existing-restoration-call-loss':
                        edge=self.request('PARENT_ORIGINAL_RESTORE_ENTRY_WITHOUT_INNER_PROOF',frame,{'entry':loc.get('entry'),'original_seed_owner_frame':id(self.seed_owner_frame),'derivative':self.g['control']['derivative']})
                        if not hasattr(self,'recovery_original_edge'):self.recovery_original_edge=edge
                    recovery.wait_at_original_restore(self.campaign,frame)
                else:self.rendezvous('BEFORE_ORIGINAL_RESTORE',frame,{'entry':loc.get('entry')})
            elif name=='_restore' and event=='return':
                if self.failed_recovery is not None and self.failed_recovery.active is not None:self.failed_recovery.after_original_restore(frame)
                else:self.rendezvous('AFTER_ORIGINAL_RESTORE',frame)
        elif name in ('request_stop','resource_coverage','restoration_proof','hold_restoration_barrier','custody','causal','child'):
            if event=='exception':
                self.request('PARENT_EXCEPTION_EDGE',frame,{'exception':native,'deltas':loc.get('deltas') if name=='custody' else None})
                if name=='restoration_proof' and self.file_hold is not None and not self.g['control'].get('permanent'):
                    self.rendezvous('ACTUAL_BARRIER_FILE_FAILURE_BEFORE_OWNER_RESTORE',frame,{'held':self.file_hold})
                    held=self.file_hold;source=Path(held['path'])
                    if held['kind']=='missing':
                        retained=Path(held['retained']);require(sha(retained.read_bytes())==held['sha256'],'same original stream changed');retained.rename(source)
                    else:os.chmod(source,stat.S_IMODE(held['original_mode']))
                    self.file_hold=None
            elif event=='return':
                extra={'frame_exit':self.native.exit(frame)}
                if name=='request_stop':extra.update(signum=loc.get('signum'),actual_signals=loc['self'].stop_signals)
                if name=='causal' and loc.get('n')==16:extra.update(actual_decision=arg,call=loc.get('call'),posts=loc.get('posts'),remaining_causal16=causal16_conjuncts(loc))
                if name=='custody':extra.update(deltas=loc.get('deltas'),actual=loc.get('actual'))
                if name=='restoration_proof':extra.update(actual_proof=arg,child_attempted=(loc.get('window')or{}).get('child_attempted'))
                self.request('PARENT_SOURCE_FRAME_EXIT',frame,extra)
            elif event=='line' and name=='custody' and 'comparison'in loc:
                line=Path(self.driver_path).read_text().splitlines()[frame.f_lineno-1]
                if "if comparison['refused']" in line or 'CONTROL loss of only explicit' in line:
                    self.request('DIRECTORY_BEFORE_EXACT_APPEND',frame,{'comparison':loc['comparison'],'deltas_before':list(loc['deltas']),'path':loc['p'],'root':loc['name']})
            elif event=='line' and name=='child':
                line=Path(self.driver_path).read_text().splitlines()[frame.f_lineno-1]
                if 'subprocess.Popen(argv' in line:self.request('BEFORE_ACTUAL_DRIVER_POPEN',frame,{'child_attempted':(loc['self'].seed_window or {}).get('child_attempted'),'argv':loc.get('argv')})
                if "if env.get('PYTEST_ADDOPTS')" in line:self.request('ACTUAL_PRELAUNCH_REFUSAL_BRANCH',frame,{'nonempty_options':bool(loc.get('env',{}).get('PYTEST_ADDOPTS')),'child_attempted':(loc['self'].seed_window or {}).get('child_attempted')})
                if 'while self.proc.poll() is None:'in line and 'config'in loc and 'pid'in loc and loc['pid']not in self.child_bound:
                    self.rendezvous('ACTUAL_CHILD_LAUNCH_BOUNDARY',frame,{'path':str(loc['obs']),'pid':loc['pid'],'config_path':str(loc['config']),'recipe':loc['recipe'],'phase':loc['phase'],'label':loc['label']})
                    self.child_bound.add(loc['pid'])
                if 'if cold.exists()'in line and 'raw'in loc:
                    self.request('ACTUAL_CHILD_RAW_BOUNDARY',frame,{'path':str(loc['obs']),'pid':loc['pid'],'config_path':str(loc['config']),'recipe':loc['recipe'],'phase':loc['phase'],'label':loc['label'],'raw_path':str(loc['step']/'raw.json')})
                if 'rows=[json.loads(x)' in line and loc.get('obs') is not None:
                    self.request('ACTUAL_CHILD_STREAM_BOUNDARY',frame,{'path':str(loc['obs']),'pid':loc['self'].last_handle.pid,'child_reaped':loc['self'].last_handle.poll() is not None})
                self.parent_file_seam(frame)
            elif event=='line' and name=='hold_restoration_barrier':
                line=Path(self.driver_path).read_text().splitlines()[frame.f_lineno-1]
                if 'CONTROL refuses to return actual positive proof' in line:
                    edge=self.request('ACTUAL_POSITIVE_PROOF_ILLEGAL_CONTINUE',frame,{'proof':loc.get('proof')})
                    if not hasattr(self,'recovery_original_edge'):self.recovery_original_edge=edge
            elif event=='line' and name=='restoration_proof':
                line=Path(self.driver_path).read_text().splitlines()[frame.f_lineno-1]
                if "if not window['child_attempted']" in line or "if False and not window['child_attempted']" in line:self.request('ACTUAL_NO_CHILD_BRANCH',frame,{'child_attempted':loc['window']['child_attempted'],'handle_absent':loc['window'].get('handle') is None})
        return self.trace
    def parent_file_seam(self,frame):
        spec=self.g['control'];loc=frame.f_locals;camp=loc['self']
        if spec['mode']!='control' or loc.get('phase')!='red' or loc.get('recipe')!=spec['recipe']:return
        line=Path(self.driver_path).read_text().splitlines()[frame.f_lineno-1]
        if 'rows=[json.loads(x)' not in line:return
        key=('file-seam',id(frame))
        if getattr(self,'file_activated',None)==key:return
        self.file_activated=key
        obs=loc['obs'];stream=obs.read_bytes();self.request('ACTUAL_PARENT_STREAM_BEFORE_FILE_SEAM',frame,{'path':str(obs),'sha256':sha(stream),'bytes':len(stream),'child_reaped':camp.last_handle.poll() is not None,'pid':camp.last_handle.pid})
        if spec['id']=='M2-missing-receipt':
            retained=obs.with_name(obs.name+'.same-original-retained');require(not retained.exists(),'retained path already exists');obs.rename(retained)
            self.rendezvous('ACTUAL_STREAM_TEMPORARILY_UNAVAILABLE',frame,{'path':str(obs),'retained':str(retained),'sha256':sha(stream)})
            self.file_hold={'kind':'missing','path':str(obs),'retained':str(retained),'sha256':sha(stream)}
        elif spec['id']=='M2-unreadable-receipt':
            old_mode=obs.stat().st_mode;os.chmod(obs,0)
            self.rendezvous('ACTUAL_STREAM_READ_DENIED',frame,{'path':str(obs),'original_mode':old_mode,'sha256':sha(stream)})
            self.file_hold={'kind':'unreadable','path':str(obs),'original_mode':old_mode,'sha256':sha(stream)}
        elif spec.get('parent_xml_failure'):
            xml=loc['xml'];held=xml.with_name(xml.name+'.same-original-retained');require(not held.exists(),'retained XML already exists');xml.rename(held)
            self.request('ACTUAL_PARENT_XML_UNAVAILABLE_AFTER_COMPLETE_STREAM',frame,{'path':str(xml),'retained':str(held),'stream_sha256':sha(stream)})

def causal16_conjuncts(loc):
    close=loc.get('close',{});r=loc.get('r',{});posts=loc.get('posts',[])
    return {'receipt_equality':r.get('closures')==[close],'final_state':close.get('final_state')=='TERMINATED','status':close.get('result',{}).get('status') in (200,204),'response_write':close.get('response_write')=='DONE','original_first_cause':close.get('first_error')=='owned frontdoor write failure','close_done':close.get('state')=='DONE','record_terminated':r.get('state')=='TERMINATED','no_owner':r.get('close_owner') is None,'actual_write_failure':any(p['kwargs'].get('write_failure') is True for p in posts)}

def run(plan_path, authority_path, external_sha):
    packet_dir=Path(__file__).resolve().parent; raw=Path(authority_path).read_bytes()
    require(sha(raw)==external_sha,'external SHA missing'); preliminary=json.loads(raw)
    grant,plan,driver_raw=bind_current(plan_path,authority_path,external_sha,preliminary['control']['derivative'],packet_dir)
    physical=physical_current_admission(plan,grant,authority_path,external_sha,packet_dir)
    # All paths and hashes are supplied by external ROOT. No grants are minted.
    work=Path(grant['harness_output']);allowed=[Path(plan['roots'][r])/'outputs/continuity' for r in ('NS','B')]
    require(work.is_absolute() and any(work.is_relative_to(root) and work!=root for root in allowed),'harness output outside ROOT-owned continuity scope')
    require(not work.exists() and Path(grant['output']).resolve()!=work.resolve(),'exclusive distinct fresh harness output required');work.mkdir(parents=True)
    durable(work/'physical-admission.json',physical)
    channel=work/'requests';channel.mkdir()
    release_dir=Path(grant['control']['release_dir']);require(release_dir.parent==work,'release directory outside owned runtime output');release_dir.mkdir()
    fault_marker=Path(grant['control']['remove_fault_path']);require(fault_marker.parent==work and not fault_marker.exists(),'fault removal capability outside fresh owned scope')
    require(type(grant['control']['release_token'])is str and bool(grant['control']['release_token']),'exact nonempty release token required')
    fault_file=Path(grant['control']['os_fault_file']);require(fault_file.parent==work,'OS fault file outside owned runtime output');fault_file.write_bytes(b'original owned regular-file OS fault capability\n')
    driver_path=Path(grant['driver_path']);require(driver_path.parent==work and not driver_path.exists(),'driver image path outside owned runtime output')
    driver_path.write_bytes(driver_raw);require(sha(driver_path.read_bytes())==grant['driver_sha256'],'materialized image differs')
    start={'pid':os.getpid(),'argv':sys.argv,'driver':str(driver_path),'grant_sha256':external_sha,'utc_ns':time.time_ns()};durable(work/'exclusive-start.json',start)
    observer_stdout=(work/'independent-observer.stdout').open('xb');observer_stderr=(work/'independent-observer.stderr').open('xb')
    observer=subprocess.Popen(physical['actual_startup']['derived_complete_role_argv']['observer'],cwd=grant['independent_observer']['cwd'],stdout=observer_stdout,stderr=observer_stderr,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
    require(observer.pid!=os.getpid(),'observer must be genuinely separate')
    ready=work/'independent-start.json'
    while not ready.exists():
        require(observer.poll()is None,'independent observer refused startup before original driver import');time.sleep(.05)
    admitted=read_json(ready);require(admitted['pid']==observer.pid and admitted['observed_parent_pid']==os.getpid()and admitted['grant_sha256']==external_sha,'exact independent startup receipt differs')
    spec=importlib.util.spec_from_file_location('frozen_ns_campaign',driver_path);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    driver.state=state;driver.directory_population_delta=directory_population_delta
    images=read_json(packet_dir/'source-images.json')
    original_child=driver.CHILD_CODE
    canonical_execution=next(x for x in images['recovery_execution_images']if x['id']=='science-canonical')
    canonical_tree=ast.parse(base64.b64decode(canonical_execution['after_base64']).decode())
    canonical_child=next(n.value.value for n in canonical_tree.body if isinstance(n,ast.Assign)and any(isinstance(a,ast.Name)and a.id=='CHILD_CODE'for a in n.targets))
    require(original_child.count('observer=Observer()')==1,'observer seam differs')
    # Instantiate original observer first; install seam before original pytest.main.
    driver.CHILD_CODE=original_child.replace('observer=Observer()','observer=Observer()\n'+CHILD_CONTROL_CODE,1)
    derivative_child=driver.CHILD_CODE
    canonical_instrumented=canonical_child.replace('observer=Observer()','observer=Observer()\n'+CHILD_CONTROL_CODE,1)
    original_child_method=driver.Campaign.child
    def route_child(campaign,label,selectors,phase,recipe=0,mutant=None):
        selected=(grant['control']['mode']=='control' and phase=='red' and recipe==grant['control']['recipe'])
        driver.CHILD_CODE=derivative_child if selected else canonical_instrumented
        return original_child_method(campaign,label,selectors,phase,recipe,mutant)
    driver.Campaign.child=route_child
    original_save=driver.save
    def save(path,value):
        if Path(path).name=='config.json' and isinstance(value,dict) and 'pytest_argv'in value:
            value=dict(value);value['native_control']={**grant['control'],'channel':str(channel),'independent_observer_pid':observer.pid,'observer_lines':driver.CHILD_CODE.splitlines(),'program_sha256':sha(driver.CHILD_CODE.encode())}
            value['recovery_protocol']={**grant['recovery']['protocol'],'execution_authority_sha256':external_sha,'harness_pid':os.getpid(),'observer_pid':observer.pid,'expected_ids':[x['id']for x in plan['canonical_305']]if value['recipe']==0 else plan['recipes'][value['recipe']-1]['current_full_ids']}
            require(sha(driver.CHILD_CODE.encode()) in grant['child_program_sha256s'],'exact instrumented child program is unbound')
        return original_save(path,value)
    driver.save=save
    original_custody=driver.Campaign.custody
    directory_done=False
    def custody(campaign,label,mutant=None):
        nonlocal directory_done
        c=grant['control'];owned=None
        if c['id']=='directory-population' and not directory_done:
            path=Path(c['directory_path']).resolve()
            require(str(path) in plan['known_custody'][c['directory_root']]['admin'],'directory control path lacks original custody guard')
            require(c['directory_private_owner']=='ROOT_EXCLUSIVE_PRIVATE_CONTROL_PATH','shared administrative mutation forbidden')
            require(sorted(x.name for x in path.iterdir())==grant['expected_admin_directory_names'][c['directory_root']][str(path)],'actual bound directory population differs before activation')
            require(all(type(n)is str and n not in ('','.','..') and Path(n).name==n for n in [c['directory_leaf']]+([c['directory_swap_leaf']] if c['directory_fault']=='swap' else [])),'invalid owned directory child name')
            require(path.is_relative_to(Path(c['directory_owned_parent'])) and path!=Path(c['directory_owned_parent']),'directory outside exact ROOT-owned private subtree')
            if c['directory_fault']=='add':
                leaf=path/c['directory_leaf'];require(not leaf.exists(),'control name already exists');
                with leaf.open('xb') as f:f.write(b'ROOT-owned actual directory control\n')
                owned=('add',leaf,sha(leaf.read_bytes()))
            elif c['directory_fault'] in ('delete','swap'):
                leaf=path/c['directory_leaf'];require(leaf.is_file() and not leaf.is_symlink() and state(leaf)==c['directory_leaf_state'],'exact preexisting ROOT-owned control leaf required');retained=path.with_name(path.name+'.retained-control-leaf') if c['directory_fault']=='delete' else path/c['directory_swap_leaf'];require(not retained.exists(),'retained/swap control path already exists');leaf.rename(retained);owned=('name',leaf,retained)
            elif c['directory_fault']=='iterdir':
                retained=path.with_name(path.name+'.same-original-retained');require(not retained.exists(),'retained directory path exists');path.rename(retained);path.write_bytes(b'ROOT-owned ENOTDIR control\n');owned=('iterdir',path,retained)
            else:raise RuntimeError('exact directory activation not supported')
            directory_done=True
        try:return original_custody(campaign,label,mutant)
        finally:
            if owned is not None:
                if owned[0]=='add':require(sha(owned[1].read_bytes())==owned[2],'owned directory leaf changed');owned[1].unlink()
                elif owned[0]=='name':require(not owned[1].exists(),'original control name reappeared');owned[2].rename(owned[1])
                else:require(owned[1].read_bytes()==b'ROOT-owned ENOTDIR control\n','owned OS seam changed');owned[1].unlink();owned[2].rename(owned[1])
                # No mtime restoration/reset: raw metadata delta requires a later
                # separate ROOT current binding, never a fabricated names pass.
    driver.Campaign.custody=custody
    tap=SourceTap(driver,grant,channel);sys.settrace(tap.trace)
    campaign=driver.Campaign(plan_path,grant['output'],authority_path,external_sha)
    tap.campaign=campaign;tap.observer_pid=observer.pid
    if grant['control']['mode']=='control':
        tap.failed_recovery=IntactBackupFailedRecovery(grant,plan,external_sha,work,tap);campaign._failed_recovery=tap.failed_recovery
    failure=None
    try:return campaign.run()
    except BaseException as exc:
        failure=exc;native=tap.native.capture(sys._getframe(),sys.exc_info())
        try:durable(work/'original-failure.json',{'native':native})
        except BaseException:tap.native.capture(sys._getframe(),sys.exc_info())
        raise
    finally:
        # Reached only when original Campaign/journal frames have lawfully exited.
        # An unresolved seed/barrier cannot arrive here by timeout or observer death.
        sys.settrace(None)
        durable(work/'harness-returned.json',{'original_failure':None if failure is None else type(failure).__name__,'utc_ns':time.time_ns()})
        # Observer verifies original restoration itself before accepting this marker.
        observer_rc=observer.wait();observer_stdout.close();observer_stderr.close()
        if observer_rc!=0 or not (work/'independent-terminal.json').is_file():
            durable(work/'independent-observer-final-error.json',{'returncode':observer_rc,'original_failure_preserved':None if failure is None else type(failure).__name__})
            if failure is None:raise RuntimeError('independent observer did not establish terminal state')

if __name__=='__main__':
    require(len(sys.argv)==4,'usage: resource-control-harness.py CURRENT_PLAN SEPARATE_ROOT_AUTHORITY EXTERNAL_RAW_SHA256')
    run(*sys.argv[1:])
