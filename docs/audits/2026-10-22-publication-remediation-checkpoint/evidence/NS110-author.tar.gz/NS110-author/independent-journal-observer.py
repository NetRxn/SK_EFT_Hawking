#!/usr/bin/env python3
"""Proposed independent observer DATA; no author execution or ROOT grant here.

This separate process independently opens the unchanged original journal, backup,
source and lock; retains every raw snapshot and read error; and acknowledges only
source-bound gates whose actual state agrees. It never repairs or grants quiet.
"""
from __future__ import annotations
import ast, base64, fcntl, hashlib, json, os, signal, stat, sys, time, traceback, threading, dis
from pathlib import Path

class NativeExceptionRegistry:
    """Strong native objects and unformatted first clock/TB/args before observers."""
    def __init__(self):self.objects={};self.pending={};self.operations={};self.operation_sequence=0
    def primitive(self,value):
        if type(value) in (str,int,float,bool,type(None)):return value
        if type(value)is bytes:return {'bytes_hex':value.hex()}
        if type(value)is tuple:return {'tuple':[self.primitive(x)for x in value]}
        return {'opaque_object':id(value),'type_module':type(value).__module__,'type_name':type(value).__qualname__}
    def call_facts(self,value):
        # Only own acyclic source-call fact dictionaries; arbitrary native args
        # retain the original opaque policy and cannot recurse through a cycle.
        if type(value)is dict:return {k:self.call_facts(v)for k,v in value.items()}
        if type(value)is list:return [self.call_facts(x)for x in value]
        return self.primitive(value)
    def arm(self,frame,operation,**facts):
        self.operation_sequence+=1
        row={'operation_sequence':self.operation_sequence,'operation':operation,'frame_object':id(frame),'file':frame.f_code.co_filename,'function':frame.f_code.co_name,'armed_line':frame.f_lineno,'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns(),**facts}
        self.operations[threading.get_ident()]=row
        return row
    def capture(self,frame,event_arg):
        typ,exc,tb=event_arg
        # First instructions: real clocks and actual objects; no __str__/repr,
        # clean(), inventory, JSON, file I/O, formatter or replacement exception.
        mono=time.monotonic_ns();wall=time.time_ns();key=id(exc)
        if key not in self.objects:
            self.objects[key]={'exception':exc,'traceback':tb,'type':typ,'first_monotonic_ns':mono,'first_utc_ns':wall,'first_frame':frame}
        strong=self.objects[key];chain=[];cursor=tb
        while cursor is not None:
            f=cursor.tb_frame;chain.append({'traceback_object':id(cursor),'frame_object':id(f),'file':f.f_code.co_filename,'function':f.f_code.co_name,'code_firstline':f.f_code.co_firstlineno,'line':cursor.tb_lineno,'lasti':cursor.tb_lasti});cursor=cursor.tb_next
        op=self.operations.get(threading.get_ident());bound=op if op is not None and any(t['frame_object']==op['frame_object']for t in chain)else None
        if bound is not None and bound['operation']in('open','write','fsync'):
            source_frame=next(t.tb_frame for t in self._tb_objects(tb)if id(t.tb_frame)==bound['frame_object'])
            local=source_frame.f_locals;argument_name={'open':'bad','write':'fd','fsync':'duplicate'}[bound['operation']]
            native_call=strong.get('actual_native_call')
            if native_call is None and argument_name in local and 'syscall_lineage'in local and 'native_call_capture'in local:
                actual_argument=local[argument_name]
                native_call={'argument':str(actual_argument)if bound['operation']=='open'else self.primitive(actual_argument),'lineage':self.primitive(local['syscall_lineage']),'immediate_pre_call':self.call_facts(local['native_call_capture']),'capture_frame_object':id(source_frame),'capture_line':source_frame.f_lineno}
                strong['actual_native_call']=native_call
            bound={**bound,'native_actual_call':native_call}
        row={'exception_object':key,'type_module':typ.__module__,'type':typ.__qualname__,'errno':OSError.errno.__get__(exc,typ)if isinstance(exc,OSError)else None,'args':self.primitive(BaseException.args.__get__(exc,typ)),'first_traceback_object':id(strong['traceback']),'traceback_object':id(tb),'traceback':chain,'first_monotonic_ns':strong['first_monotonic_ns'],'first_utc_ns':strong['first_utc_ns'],'observed_monotonic_ns':mono,'observed_utc_ns':wall,'operation':bound,'metadata_attempt':strong.get('metadata_attempt')}
        previous=self.pending.get(id(frame))
        if previous is not None and previous['handler_seen']:
            previous['latest_native']=row;previous.setdefault('secondary_native',[]).append(row)
        else:self.pending[id(frame)]={'native':row,'latest_native':row,'handler_seen':False}
        return row
    def _tb_objects(self,tb):
        rows=[]
        while tb is not None:rows.append(tb);tb=tb.tb_next
        return rows
    def line(self,frame,handler_lines,retry_line,nested_handler_lines=()):
        pending=self.pending.get(id(frame))
        if pending is None:return None
        if frame.f_lineno in handler_lines:pending['handler_seen']=True
        if frame.f_lineno in nested_handler_lines:pending['latest_native']=pending['native']
        if pending['handler_seen'] and frame.f_lineno==retry_line:
            self.pending.pop(id(frame));return {'disposition':'caught_then_original_retry','native':pending['native'],'frame_object':id(frame)}
        return None
    def exit(self,frame):
        pending=self.pending.pop(id(frame),None);opcode=dis.opname[frame.f_code.co_code[frame.f_lasti]]
        escaped=pending is not None and opcode not in ('RETURN_VALUE','RETURN_CONST','YIELD_VALUE','YIELD_FROM')
        return {'disposition':'escaped_exception'if escaped else 'normal_return','opcode':opcode,'native':None if pending is None else pending['latest_native'],'first_frame_fault':None if pending is None else pending['native'],'secondary_native':[]if pending is None else pending.get('secondary_native',[]),'handler_seen':False if pending is None else pending['handler_seen'],'frame_object':id(frame),'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns()}

class RecoveryAuthority:
    """Distinct failed recovery only; delivery is an externally ROOT-owned capability."""
    def __init__(self,protocol,execution_sha,role,pid,observer_pid):
        self.protocol=protocol;self.execution_sha=execution_sha;self.role=role;self.pid=pid;self.observer_pid=observer_pid;self.consumed=set();self.first_errors=[]
    @staticmethod
    def digest(raw):return hashlib.sha256(raw).hexdigest()
    @staticmethod
    def encode(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
    @staticmethod
    def exact_file(path):
        p=Path(path)
        try:s=p.lstat()
        except FileNotFoundError:return {'kind':'missing','path':str(p)}
        if not stat.S_ISREG(s.st_mode) or p.is_symlink():raise RuntimeError('recovery input is not exact regular non-symlink file')
        raw=p.read_bytes()
        return {'kind':'file','path':str(p),'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'raw_base64':base64.b64encode(raw).decode()}
    def load(self,stage,challenge,principal):
        delivery=Path(self.protocol['delivery_directory'])/('ROOT-recovery-'+stage+'.admission')
        if not delivery.exists():return None
        if not delivery.is_absolute()or delivery.parent.resolve()!=delivery.parent or delivery.is_symlink()or not delivery.is_file():raise RuntimeError('ROOT recovery delivery namespace/regular leaf changed before read')
        envelope=json.loads(delivery.read_bytes());authority=Path(envelope['authority_path'])
        prefix='ROOT-recovery-'+stage+'-';suffix='.authority';name=authority.name
        token=name[len(prefix):-len(suffix)]if name.startswith(prefix)and name.endswith(suffix)else''
        if not authority.is_absolute()or authority.parent!=delivery.parent or str(authority)!=os.path.normpath(str(authority))or authority.is_symlink()or len(token)!=32 or any(c not in '0123456789abcdef'for c in token):raise RuntimeError('foreign/malformed recovery authority path refused BEFORE its bytes are read')
        raw=authority.read_bytes();external=envelope['external_raw_sha256']
        if self.digest(raw)!=external or external==self.execution_sha:raise RuntimeError('new separate ROOT recovery raw SHA differs/reuses original execution grant')
        g=json.loads(raw)
        if g.get('schema')!='publication-native-root-failed-recovery/v1'or g.get('state')!='ROOT_AUTHORIZED_FAILED_RECOVERY'or g.get('approved_by')!='ROOT'or g.get('mode')!='RECOVERY_FAILED_UNQUALIFIED':raise RuntimeError('distinct ROOT failed recovery authority absent')
        if g['stage']!=stage or g['execution_authority_sha256']!=self.execution_sha or g['challenge_sha256']!=self.digest(self.encode(challenge))or self.encode(g['principal'])!=self.encode(principal):raise RuntimeError('recovery authority foreign to exact current owner/frame/challenge')
        if g['observer_pid']!=self.observer_pid or g['attempt_id']in self.consumed:raise RuntimeError('foreign observer/replayed recovery attempt')
        if g['ordinary_quiet_or_scientific_qualification']is not False or g['dependents_must_stop']is not True:raise RuntimeError('recovery cannot qualify original attempt or continue dependents')
        if type(g['attempt_id'])is not str or len(g['attempt_id'])!=32 or any(c not in '0123456789abcdef'for c in g['attempt_id']):raise RuntimeError('invalid exact recovery attempt identity')
        if authority!=delivery.parent/('ROOT-recovery-'+stage+'-'+g['attempt_id']+'.authority')or not authority.is_absolute()or authority.is_symlink()or delivery.is_symlink():raise RuntimeError('recovery authority outside exact exclusive delivery namespace')
        if not g['preserved_history_prefixes']:raise RuntimeError('original first-fault/negative history pins absent')
        for pin in g['preserved_history_prefixes']:
            if type(pin['bytes'])is not int or pin['bytes']<=0:raise RuntimeError('preserved history prefix must be nonempty exact bytes')
            b=Path(pin['path']).read_bytes()
            if len(b)<pin['bytes']or self.digest(b[:pin['bytes']])!=pin['sha256']:raise RuntimeError('original failed history was lost/replaced')
        return {'body':g,'raw_sha256':external,'authority_path':str(authority),'delivery':self.exact_file(delivery),'authority':self.exact_file(authority)}
    def consume(self,grant):self.consumed.add(grant['body']['attempt_id'])
    @staticmethod
    def exclusive_bytes(path,raw,mode=0o400):
        p=Path(path)
        if not p.is_absolute()or p.is_symlink()or p.exists():raise RuntimeError('recovery archive/blob must be new exclusive file')
        fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
        with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
        directory=os.open(p.parent,os.O_RDONLY)
        try:os.fsync(directory)
        finally:os.close(directory)
        return RecoveryAuthority.exact_file(p)
    @staticmethod
    def validate_resources(proof,contract,allow_close2=False):
        # Fresh source-owned objects, not old ordinary receipts or endpoint absence.
        if proof['pid']!=contract['pid']or proof['nodeid']not in contract['expected_ids']or proof['inflight']!=0 or type(proof['inflight'])is not int:raise RuntimeError('fresh exact owner/inflight proof absent')
        if proof['fixture_required']is not contract['fixture_requirements'][proof['nodeid']]:raise RuntimeError('recovery original source fixture requirement differs')
        groups=proof['registrations']
        if set(groups)!={'rig','broker','connection','worker'}:raise RuntimeError('recovery registration kinds incomplete')
        for kind,rows in groups.items():
            identities=[r['identity']for r in rows];keys={'pid','object'}|({'lock'}if kind=='broker'else{'thread','done'}if kind=='worker'else set())
            if len({RecoveryAuthority.encode(v)for v in identities})!=len(identities)or any(set(v)!=keys or any(type(x)is not int or x<=0 for x in v.values())for v in identities):raise RuntimeError('recovery unknown/duplicate/incomplete original identity')
            if [r['ordinal']for r in rows]!=list(range(1,len(rows)+1))or any(r['resource']!=kind or r['identity']['pid']!=proof['pid']for r in rows):raise RuntimeError('recovery exact registration order/principal differs')
        if [w['identity']for w in proof['workers']]!=[r['identity']for r in groups['worker']]:raise RuntimeError('fresh actual worker population differs')
        if any(w['alive']is not False or w['done']is not True or type(w['thread_ident'])is not int for w in proof['workers']):raise RuntimeError('actual owned worker not joined/done/identified')
        if proof['fixture_required']is True:
            if len(groups['rig'])!=1 or proof['rig_identity']!=groups['rig'][0]['identity']:raise RuntimeError('actual original registered rig absent')
        elif proof['rig_identity']is not None or any(groups[k]for k in ('rig','broker','connection')):raise RuntimeError('source-proved no-rig disposition differs')
        if [b['identity']for b in proof['brokers']]!=[r['identity']for r in groups['broker']]or [c['identity']for c in proof['connections']]!=[r['identity']for r in groups['connection']]:raise RuntimeError('actual broker/connection population differs')
        for broker in proof['brokers']:
            for r in broker['records'].values():
                if r['state']not in('LIVE','TERMINATED')or r['close_owner']is not None or any(a['pending']is not False for a in r['attempts']):raise RuntimeError('actual broker/establishment owner still active')
                if any(o['state']!='DONE'or o['response_write']not in('NOT_STARTED','NOT_WRITTEN','DONE','FAILED')for o in r['operations'].values()):raise RuntimeError('actual operation/write still active')
                if any(o['state']!='DONE'for o in r['deletes']+r['closures'])or any(o['response_write']not in('NOT_WRITTEN','DONE','FAILED')for o in r['closures']):raise RuntimeError('actual delete/closure still active')
        for c in proof['connections']:
            if type(c['closed'])is not int or c['closed']not in((1,2)if allow_close2 else(1,)):raise RuntimeError('actual transport physical settlement unavailable')
        expected_sources={'scripts.lean_slots.proxy':{'path':contract['proxy'],'sha256':contract['proxy_sha256']},'seed_journal':{'path':contract['journal'],'sha256':contract['journal_sha256']}}
        if proof['loaded_sources']!=expected_sources:raise RuntimeError('fresh loaded-source origin/hash proof differs')
        if any(x['closed']is not True for x in proof['publication_stream_owners']):raise RuntimeError('actual original publication handle not closed')
        if allow_close2 and proof['original_exact_once_contract_satisfied']is not False:raise RuntimeError('wrong close2 history must remain failed')
        return True

OBS_NATIVE=NativeExceptionRegistry()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def require(ok,message):
    if not ok:raise RuntimeError(message)
class StopCampaign(RuntimeError):pass

def write(path,value):
    path=Path(path);pending=path.with_name(path.name+'.pending-'+str(os.getpid()))
    with pending.open('x') as f:json.dump(value,f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
    os.link(pending,path);pending.unlink()
    fd=os.open(path.parent,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
sha=digest

def validate_runtime_paths(plan,grant,fresh=True):
    """One pure complete ownership layout; no grant rewriting or filesystem writes."""
    def path(value):
        require(type(value)is str and value.startswith('/')and os.path.normpath(value)==value,'noncanonical absolute granted path')
        p=Path(value)
        for ancestor in (p,*p.parents):
            try:s=ancestor.lstat()
            except FileNotFoundError:continue
            require(not stat.S_ISLNK(s.st_mode),'symlink in runtime ownership path')
        require(str(p.resolve())==value,'resolved path aliases ROOT grant')
        return p
    def absent(p):
        try:p.lstat()
        except FileNotFoundError:return True
        return False
    def overlap(a,b):
        a=Path(str(a).casefold());b=Path(str(b).casefold())
        return a==b or a.is_relative_to(b)or b.is_relative_to(a)
    output=path(grant['output']);work=path(grant['harness_output'])
    roots=[path(str(Path(plan['roots'][r])/'outputs/continuity'))for r in ('NS','B')]
    require(not overlap(output,work),'runtime output scopes overlap/nest')
    require(all(any(p.is_relative_to(root)and p!=root for root in roots)for p in (output,work)),'runtime output outside admitted continuity roots')
    require(absent(output)and(not fresh or absent(work)),'preexisting runtime output scope')
    names=['physical-admission.json','driver.py','requests','exclusive-start.json','independent-observer.stdout','independent-observer.stderr','independent-raw','independent-start.json','harness-returned.json','original-failure.json','independent-terminal.json','independent-observer-final-error.json']
    reserved={name:str(work/name)for name in names}
    require(grant['artifact_layout']==reserved,'complete reserved artifact layout differs from external grant')
    require(grant['driver_path']==reserved['driver.py'],'driver path aliases reserved ownership')
    controls=grant['control'];capabilities={k:path(controls[k])for k in ('release_dir','remove_fault_path','os_fault_file')}
    for key,p in capabilities.items():
        require(p.parent==work,'capability outside exact owned runtime root')
        require(all(not overlap(p,Path(other))for other in reserved.values()),'capability overlaps reserved artifact/subtree')
        require(all(not p.name.casefold().startswith(name.casefold()+'.pending-')and p.name.casefold()!=name.casefold()+'.pending'for name in names),'capability aliases reserved atomic pending namespace')
        require(not fresh or absent(p),'preexisting runtime capability')
    values=list(capabilities.values());require(all(not overlap(a,b)and not a.name.casefold().startswith(b.name.casefold()+'.pending')and not b.name.casefold().startswith(a.name.casefold()+'.pending')for n,a in enumerate(values)for b in values[n+1:]),'capability aliases/ancestors/pending namespaces overlap')
    require(type(controls['release_token'])is str and bool(controls['release_token']),'release token absent at pure boundary')
    require(all(not fresh or absent(Path(value))for value in reserved.values()),'preexisting reserved runtime artifact')
    protocol=grant['recovery']['protocol']
    require(protocol['schema']=='publication-native-failed-recovery-protocol/v1'and protocol['delivery_directory']==str(work/'requests')and protocol['mode']=='RECOVERY_FAILED_UNQUALIFIED'and protocol['backup_input']=='UNCHANGED_INTACT_ORIGINAL_ENTRY','failed recovery protocol/ownership namespace differs')
    return {'output':str(output),'work':str(work),'reserved':reserved,'capabilities':{k:str(v)for k,v in capabilities.items()},'atomic_namespace_policy':'all reserved .pending and .pending-* siblings reserved; requests/independent-raw/release subtrees exclusively owned'}

def admit_prepared_startup(plan,grant,role,authority_path,external_sha,packet_dir):
    """Observed executable never supplies its own external approval."""
    prepared=grant['prepared_runtime'];primary=plan['primary_python']
    require(prepared['primary_python']==primary,'immutable primary_python differs')
    require(type(prepared['admitted_invocation_paths'])is list and primary in prepared['admitted_invocation_paths']and len(set(prepared['admitted_invocation_paths']))==len(prepared['admitted_invocation_paths']),'explicit interpreter invocation paths absent/duplicate')
    resolved=Path(primary).resolve(strict=True);s=resolved.stat()
    identity={'resolved':str(resolved),'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':sha(resolved.read_bytes())}
    require(identity==prepared['resolved_identity'],'prepared executable physical identity differs')
    for value in prepared['admitted_invocation_paths']:
        require(type(value)is str and value.startswith('/')and os.path.normpath(value)==value and Path(value).resolve(strict=True)==resolved,'unadmitted/different executable alias target')
    version={'version_info':list(sys.version_info),'implementation':sys.implementation.name,'cache_tag':sys.implementation.cache_tag,'sys_version':sys.version}
    require(version==prepared['interpreter_version'],'actual interpreter version/implementation differs')
    require(grant['assigned_cwd']==plan['roots']['B'],'assigned startup checkout differs from immutable B root')
    env_raw=json.dumps(sorted(os.environ.items()),separators=(',',':'),ensure_ascii=True).encode()
    expected_roles={}
    for candidate in ('harness','observer'):
        admitted=grant['startup'][candidate];invoked=admitted['executable']
        require(invoked in prepared['admitted_invocation_paths'],'planned role uses unadmitted executable/alias')
        script=packet_dir/('resource-control-harness.py'if candidate=='harness'else'independent-journal-observer.py')
        tail=[str(Path(grant['current_plan_path'])),str(Path(authority_path)),{'external_raw_authority_sha256':True}]if candidate=='harness'else[str(Path(authority_path)),{'external_raw_authority_sha256':True},grant['harness_output']]
        recipe=[invoked,'-B',str(script),*tail]
        require(admitted['argv_recipe']==recipe and sum(type(x)is dict for x in recipe)==1,'complete immutable argv recipe/external digest slot differs')
        slots=[x for x in admitted['argv_recipe']if type(x)is dict]
        require(len(slots)==1 and set(slots[0])=={'external_raw_authority_sha256'}and slots[0]['external_raw_authority_sha256']is True,'external digest slot must be exactly typed true')
        expected_roles[candidate]=[external_sha if type(x)is dict else x for x in recipe]
        require(admitted['argv_recipe']==recipe and admitted['cwd']==grant['assigned_cwd'],'complete planned role argv/cwd differs before effects')
        # Observer Popen inherits this exact environment with already-required GIT0.
        require(admitted['environment_sha256']==sha(env_raw),'complete planned role environment differs before effects')
    startup=grant['startup'][role];invocation=startup['executable'];expected=expected_roles[role]
    require(invocation in prepared['admitted_invocation_paths']and sys.executable==invocation,'actual executable is not exact externally admitted invocation')
    require(sys.orig_argv==expected,'complete actual/external prepared startup argv differs')
    require(str(Path.cwd())==startup['cwd']==grant['assigned_cwd'],'exact actual startup cwd differs')
    require(sha(env_raw)==startup['environment_sha256'],'complete actual startup environment differs')
    require(sys.dont_write_bytecode and os.environ.get('GIT_OPTIONAL_LOCKS')=='0','actual startup -B/GIT0 contract differs')
    require(grant['independent_observer']=={'pid_binding':'EXACT_HARNESS_PID_FROM_EXCLUSIVE_START_RECORD','argv_recipe':grant['startup']['observer']['argv_recipe'],'cwd':grant['startup']['observer']['cwd'],'harness_output':grant['harness_output']},'observer startup fields differ from external complete startup')
    return {'role':role,'actual_orig_argv':list(sys.orig_argv),'actual_sys_executable':sys.executable,'actual_cwd':str(Path.cwd()),'environment_sha256':sha(env_raw),'prepared_identity':identity,'version':version,'authority_sha256':external_sha,'derived_complete_role_argv':expected_roles}

def alive(pid):
    require(type(pid)is int and pid>0,'exact positive PID required')
    try:os.kill(pid,0)
    except ProcessLookupError:return False
    except PermissionError:return True
    return True

def capture(path):
    p=Path(path)
    try:
        s=p.lstat();v={'path':str(p),'kind':'file' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'other','mode':s.st_mode,'mtime_ns':s.st_mtime_ns,'size':s.st_size,'device':s.st_dev,'inode':s.st_ino}
        if v['kind']=='file':
            raw=p.read_bytes();v.update(sha256=digest(raw),raw_base64=base64.b64encode(raw).decode())
        return v
    except BaseException as exc:return {'path':str(p),'error':OBS_NATIVE.capture(sys._getframe(),sys.exc_info())}

# Exact original parent methods are inserted below as independent stdlib source.
# They read the bound original test AST and actual raw child stream afresh.
class ResourceStreamVerifier:
    def __init__(self,plan):self.plan=plan
    def fixture_requirements(self):
        text=Path(self.plan['test']).read_text()
        if digest(text.encode())!=self.plan['test_sha256']:raise StopCampaign('fixture source differs')
        tree=ast.parse(text)
        direct={n.name:('st_proxy' in [a.arg for a in n.args.args+n.args.kwonlyargs]) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
        result={c['id']:direct[c['id'].split('::')[-1].split('[',1)[0]] for c in self.plan['canonical_305']}
        if result!=self.plan['fixture_requirements'] or len(result)!=305 or sum(result.values())!=183:raise StopCampaign('complete original fixture population differs')
        return result
    def resource_coverage(self,rows,cfg,ids):
        required=self.fixture_requirements()
        if cfg['fixture_requirements']!=required:raise StopCampaign('config fixture authority differs')
        collections=[r for r in rows if r['kind']=='collection']
        if len(collections)!=1 or collections[0].get('canonical_fixture_requirements')!=required or collections[0].get('fixture_requirements')!={x:required[x] for x in ids}:raise StopCampaign('actual collection fixture closure coverage differs')
        contexts=[r for r in rows if r['kind']=='context_started']
        if len({r.get('item_identity') for r in contexts})!=len(ids) or [r['nodeid'] for r in contexts]!=ids or any(r.get('fixture_required') is not required[r['nodeid']] or type(r.get('item_identity')) is not int for r in contexts):raise StopCampaign('actual required fixture context population differs')
        registrations=[r for r in rows if r['kind']=='resource_registered']
        if any(r.get('nodeid') not in ids for r in registrations):raise StopCampaign('registration outside exact collection')
        def identity(value):
            return type(value) is dict and value.get('pid')==rows[0]['pid'] and all(type(x) is int and x>0 for x in value.values())
        for node in ids:
            regs=[r for r in registrations if r['nodeid']==node]
            context=next(r for r in contexts if r['nodeid']==node)
            if any(r['sequence']<=context['sequence'] for r in regs):raise StopCampaign('resource precedes actual context')
            groups={kind:[r for r in regs if r['registration']['resource']==kind] for kind in ('rig','broker','connection','worker')}
            if sum(map(len,groups.values()))!=len(regs):raise StopCampaign('unknown registration kind')
            for kind,values in groups.items():
                if any(type(r['registration']['ordinal']) is not int for r in values) or [r['registration']['ordinal'] for r in values]!=list(range(1,len(values)+1)) or any(not identity(r['registration']['identity']) for r in values) or len({json.dumps(r['registration']['identity'],sort_keys=True) for r in values})!=len(values):raise StopCampaign('duplicate/subset/unknown registered identity')
                keys={'pid','object'}|({'lock'} if kind=='broker' else {'thread','done'} if kind=='worker' else set())
                if any(set(r['registration']['identity'])!=keys for r in values):raise StopCampaign('incomplete resource identity')
            bound=[r for r in rows if r['kind']=='fixture_bound' and r['nodeid']==node]
            confirms=[r for r in rows if r['kind']=='fixture_confirmed' and r['nodeid']==node]
            if required[node]:
                if len(groups['rig'])!=1 or not groups['broker'] or len(bound)!=1 or len(confirms)!=2 or [r['stage'] for r in confirms]!=['fixture_setup','call']:raise StopCampaign('required fixture binding coverage missing')
                rid=groups['rig'][0]['registration']['identity']
                if not groups['rig'][0]['sequence']<bound[0]['sequence']<confirms[0]['sequence']<confirms[1]['sequence'] or any(r['sequence']<=bound[0]['sequence'] for kind in ('broker','connection') for r in groups[kind]):raise StopCampaign('actual fixture registration order differs')
                if any(r['identity']!=rid for r in bound+confirms) or bound[0]['fixture_code_file']!=cfg['test'] or bound[0]['fixture_code_line']!=self.plan['fixture_authority']['fixture_code_firstline']:raise StopCampaign('required fixture replaced/unknown')
            elif groups['rig'] or groups['broker'] or groups['connection'] or bound or len(confirms)!=1 or confirms[0]['stage']!='call' or confirms[0]['identity'] is not None:raise StopCampaign('source no-rig disposition differs')
            for reg in groups['worker']:
                wid=reg['registration']['identity']
                starts=[r for r in rows if r['kind']=='owned_worker_start_returned' and r['nodeid']==node and r['identity']==wid]
                returns=[r for r in rows if r['kind']=='owned_worker_helper_returned' and r['nodeid']==node and r['identity']==wid]
                if len(starts)!=1 or len(returns)!=1 or not reg['sequence']<starts[0]['sequence']<returns[0]['sequence'] or type(starts[0]['thread_ident']) is not int or starts[0]['thread_ident']!=returns[0]['thread_ident']:raise StopCampaign('actual worker start/return registration incomplete')
            expected_workers=[r['registration']['identity'] for r in groups['worker']]
            for kind in ('owned_worker_start_returned','owned_worker_helper_returned'):
                if [r['identity'] for r in rows if r['kind']==kind and r['nodeid']==node]!=expected_workers:raise StopCampaign('extra/subset worker creation events')
            for stage in ('call','pre_teardown','post_teardown','session_final'):
                quiet=[r for r in rows if r['kind'] in ('quiet_after','teardown_quiet') and r.get('stage')==stage and r.get('nodeid')==node]
                if len(quiet)!=1:raise StopCampaign('missing positive resource stage')
                row=quiet[0]
                if type(row.get('inflight')) is not int or row['inflight']!=0:raise StopCampaign('unknown/noninteger in-flight state')
                expected={kind:[r['registration'] for r in group if r['sequence']<row['sequence']] for kind,group in groups.items()}
                if row.get('fixture_required') is not required[node] or row.get('resource_inventory')!=expected:raise StopCampaign('exact complete registered resource stage coverage differs')
                wr=row['workers'];wids=[x['identity'] for x in expected['worker']]
                if [x.get('identity') for x in wr]!=wids or any(x['thread'].get('alive') is not False or x.get('done') is not True or type(x['thread'].get('ident')) is not int for x in wr):raise StopCampaign('missing/duplicate/unknown/live worker stage')
                for worker in wr:
                    started=next(r for r in rows if r['kind']=='owned_worker_start_returned' and r['nodeid']==node and r['identity']==worker['identity'])
                    if worker['thread']['ident']!=started['thread_ident']:raise StopCampaign('worker thread identity substituted')
                rig=row.get('rig')
                if required[node]:
                    if type(rig) is not dict or rig.get('resource_identity')!=expected['rig'][0]['identity'] or rig.get('inventory')!=expected or len(rig.get('records',[]))!=len(expected['broker']) or [x.get('identity') for x in rig.get('connections',[])]!=[x['identity'] for x in expected['connection']]:raise StopCampaign('required actual rig/broker/connection omitted/replaced')
                elif rig is not None or any(expected[k] for k in ('rig','broker','connection')):raise StopCampaign('no-rig resource evidence differs')
        finish=next(r for r in rows if r['kind']=='session_finish')
        expected=[{'nodeid':node,'registration':r['registration']} for node in ids for kind in ('rig','broker','connection','worker') for r in registrations if r['nodeid']==node and r['registration']['resource']==kind]
        if finish.get('resource_registrations')!=expected:raise StopCampaign('complete retained final registration inventory differs')
        return True

def complete_stream(plan,contract):
    path=Path(contract['observation']);expected_pid=contract['pid'];ids=contract['expected_ids']
    require(type(ids)is list and ids and len(set(ids))==len(ids),'external expected ordered cohort invalid')
    raw=Path(path).read_bytes();rows=[json.loads(line) for line in raw.splitlines()]
    require(rows and all(type(r['sequence'])is int for r in rows)and [r['sequence'] for r in rows]==list(range(1,len(rows)+1)),'actual stream gaps/partial/duplicates')
    require(all(r['pid']==expected_pid for r in rows),'stream PID differs')
    starts=[r for r in rows if r['kind']=='child_started'];collections=[r for r in rows if r['kind']=='collection'];finishes=[r for r in rows if r['kind']=='session_finish']
    require(len(starts)==len(collections)==len(finishes)==1,'start/collection/final coverage missing')
    require(starts[0]['cwd']==plan['roots']['NS'] and starts[0]['plan_sha256']==plan['_current_plan_sha256'],'actual origin differs')
    require(collections[0]['ids']==ids,'actual collection differs from independent exact plan/recipe/phase cohort')
    cfg={'fixture_requirements':plan['fixture_requirements'],'test':plan['test']}
    ResourceStreamVerifier(plan).resource_coverage(rows,cfg,ids)
    expected_proxy=contract['proxy_sha256']
    require(finishes[0]['origins']=={'scripts.lean_slots.proxy':{'path':plan['proxy'],'sha256':expected_proxy},'seed_journal':{'path':plan['journal_helper'],'sha256':plan['journal_sha256']}},'independently bound actual loaded-origin fields differ')
    require(finishes[0]['resource_barrier_complete'] is True and finishes[0]['origins_exact'] is True,'actual final origin/teardown incomplete')
    require(starts[0]['test']==plan['test']if 'test'in starts[0]else True,'actual child test field differs')
    require([r['nodeid']for r in rows if r['kind']=='context_started']==ids,'exact ordered contexts differ')
    require([r['nodeid']for r in rows if r['kind']=='original_call_result']==ids,'exact ordered original call population differs')
    for when in ('setup','call','teardown'):
        require([r['nodeid']for r in rows if r['kind']=='pytest_report'and r['when']==when]==ids,'exact ordered '+when+' report population differs')
    require([r['id']for r in finishes[0]['results']]==ids,'exact final call registration differs')
    require(finishes[0]['contexts']==[{'nodeid':node,'teardown_complete':True}for node in ids],'exact complete final context/teardown population differs')
    for stage in ('call','pre_teardown','post_teardown','session_final'):
        positive=[r for r in rows if r['kind'] in ('quiet_after','teardown_quiet') and r.get('stage')==stage]
        require([r['nodeid'] for r in positive]==ids,'positive stage population/order differs')
        for row in positive:
            require(row['quiescent'] is True and row['problems']==[] and type(row['inflight'])is int and row['inflight']==0,'actual quiet unknown/false')
            rig=row['rig']
            if rig is None:continue
            require(not rig.get('observation_failed'),'actual metadata observation unknown')
            for table in rig['records']:
                for rec in table.values():
                    require(rec['state'] in ('LIVE','TERMINATED') and rec['close_owner'] is None,'actual close owner/state residual')
                    require(all(a['pending'] is False for a in rec['attempts']),'actual establishment residual')
                    require(all(o['state']=='DONE' and o['response_write'] in ('NOT_STARTED','NOT_WRITTEN','DONE','FAILED') for o in rec['operations'].values()),'actual operation/write residual')
                    require(all(o['state']=='DONE' for o in rec['deletes']+rec['closures']) and all(o['response_write'] in ('NOT_WRITTEN','DONE','FAILED') for o in rec['closures']),'actual delete/closure residual')
            require(all(type(c['closed'])is int and c['closed']==1 for c in rig['connections']),'actual transport count residual')
    return {'path':str(path),'sha256':digest(raw),'raw_base64':base64.b64encode(raw).decode(),'ids':ids,'external_contract':contract,'observer_faults':finishes[0].get('observer_faults'),'complete_positive_resources':True}

class IndependentJournalObserver:
    def __init__(self,authority,external_sha,work):
        raw=Path(authority).read_bytes();require(digest(raw)==external_sha,'external ROOT hash differs')
        self.g=json.loads(raw);require(self.g.get('state')=='ROOT_GRANTED_EXACT_INPUTS' and self.g.get('approved_by')=='ROOT','ROOT grant absent')
        require(self.g['observer_sha256']==digest(Path(__file__).read_bytes()),'observer source unbound')
        self.work=Path(work);require(str(self.work)==self.g['harness_output'],'observer output binding differs')
        self.plan=json.loads(Path(self.g['current_plan_path']).read_bytes());require(digest(Path(self.g['current_plan_path']).read_bytes())==self.g['plan_sha256'],'current plan differs')
        self.actual_startup=admit_prepared_startup(self.plan,self.g,'observer',authority,external_sha,Path(__file__).resolve().parent)
        self.runtime_layout=validate_runtime_paths(self.plan,self.g,fresh=False)
        self.start=json.loads((self.work/'exclusive-start.json').read_bytes());self.parent=self.start['pid']
        require(self.parent!=os.getpid() and alive(self.parent),'genuine distinct live owner required')
        require(self.start['grant_sha256']==external_sha,'start record grant differs')
        self.plan=json.loads(Path(self.g['current_plan_path']).read_bytes());require(digest(Path(self.g['current_plan_path']).read_bytes())==self.g['plan_sha256'],'current plan differs')
        self.plan['_current_plan_sha256']=self.g['plan_sha256']
        self.root=Path(self.plan['roots']['NS']);self.proxy=Path(self.plan['proxy']);self.journal=self.root/'.seed-journal'
        self.lock=self.journal/(digest(str(self.proxy.resolve()).encode())[:16]+'.lock')
        self.fault_identity=self.io_physical_identity(self.g['control']['os_fault_file']);fault_fd=os.open(self.g['control']['os_fault_file'],os.O_RDONLY)
        try:self.fault_read_flags=fcntl.fcntl(fault_fd,fcntl.F_GETFL)
        finally:os.close(fault_fd)
        self.out=self.work/'independent-raw';self.out.mkdir();self.n=0;self.seen=set();self.bound_entry=None;self.seed_active=False;self.child_pids=set();self.signalled=set();self.quarantine=False;self.child_streams={};self.frame_edges=[];self.first_retain_fault={};self.native_occurrences={};self.metadata_started={};self.all_streams={};self.stream_leases={};self.io_admissions={};self.active_recipe=None;self.seeded_state=None;self.recovery_challenges={};self.recovery_child_settled={};self.recovery_child_final={};self.recovery_parent_challenges={};self.recovery_materials={};self.recovery_causal_rows={};self.recovery_actual_registries={};self.recovery_restore_admitted=None;self.failed_recovery=False;self.execution_sha=external_sha;self.recovery_authority=RecoveryAuthority(self.g['recovery']['protocol'],external_sha,'observer',os.getpid(),os.getpid())
        write(self.work/'independent-start.json',{'pid':os.getpid(),'observed_parent_pid':self.parent,'observer_sha256':digest(Path(__file__).read_bytes()),'grant_sha256':external_sha,'actual_startup':self.actual_startup,'runtime_layout':self.runtime_layout,'utc_ns':time.time_ns()})
    def snapshot(self,request=None):
        self.n+=1
        # Enumerate this exact original journal directory only, never host processes.
        entries=[]
        try:
            names=sorted(p.name for p in self.journal.iterdir())
            for name in names:
                if name.endswith('.json'):
                    raw=capture(self.journal/name);entries.append(raw)
        except FileNotFoundError:names=[];entries=[]
        except BaseException as exc:names=None;entries=[{'directory_error':OBS_NATIVE.capture(sys._getframe(),sys.exc_info())}]
        source=capture(self.proxy);lock=capture(self.lock);lock_probe={'path':str(self.lock)}
        try:
            # Read-only existing fd; do not create, truncate or rewrite lock holder.
            with self.lock.open('rb') as handle:
                try:
                    fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:lock_probe['other_owner_holds']=True
                else:
                    lock_probe['other_owner_holds']=False;fcntl.flock(handle.fileno(),fcntl.LOCK_UN)
        except BaseException as exc:lock_probe['error']=OBS_NATIVE.capture(sys._getframe(),sys.exc_info())
        decoded=[];backups=[]
        for captured in entries:
            try:
                e=json.loads(base64.b64decode(captured['raw_base64']));e['observed_live']=alive(e['pid']);decoded.append(e)
                backups.append(capture(e['backup']))
            except BaseException as exc:decoded.append({'decode_error':OBS_NATIVE.capture(sys._getframe(),sys.exc_info())})
        snapshot={'sequence':self.n,'observer_pid':os.getpid(),'utc_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),'request':request,'source':source,'journal_names':names,'journal_raw':entries,'decoded_entries':decoded,'backup_raw':backups,'lock_raw':lock,'lock_probe':lock_probe,'parent_alive':alive(self.parent),'known_child_liveness':{str(p):alive(p) for p in self.child_pids}}
        write(self.out/('%08d.json'%self.n),snapshot)
        return snapshot
    def intact(self,snapshot,seeded):
        require(snapshot['parent_alive'],'dead owner is not drain proof')
        entries=snapshot['decoded_entries'];require(len(entries)==1,'same single original journal entry unavailable')
        entry=entries[0];require(entry['path']==str(self.proxy) and entry['pid']==self.parent and entry['observed_live'] is True,'actual original journal ownership differs')
        require(entry['sha256']==self.plan['proxy_state']['sha256'],'canonical backup hash differs')
        raw=snapshot['backup_raw'][0];require(raw.get('sha256')==entry['sha256'],'actual backup unavailable/corrupt')
        if self.bound_entry is None:
            self.bound_entry={k:v for k,v in entry.items() if k!='observed_live'}
            candidates=[r for r in self.plan['recipes'] if entry['reason']=='NS all20 '+str(r['number'])+' '+r['name']]
            require(len(candidates)==1,'actual original journal reason does not bind an original recipe');self.active_recipe=candidates[0]['number'];self.child_streams={}
        require({k:v for k,v in entry.items() if k!='observed_live'}==self.bound_entry,'original journal entry changed')
        require(snapshot['lock_probe'].get('other_owner_holds') is True,'original source lock not independently held')
        lock=base64.b64decode(snapshot['lock_raw']['raw_base64']).decode();require(lock.startswith('pid='+str(self.parent)+' '),'actual lock holder metadata differs')
        src=snapshot['source'];original=self.plan['proxy_state']
        require(src['mode']==original['mode'],'source full mode differs')
        expected=self.plan['recipes'][self.active_recipe-1]['mutant_sha256'] if seeded else original['sha256']
        require(src['sha256']==expected,'actual original/seeded bytes differ')
        if seeded:
            current={k:src[k] for k in ('mode','mtime_ns','size','sha256','device','inode')}
            if self.seeded_state is None:self.seeded_state=current
            require(current==self.seeded_state,'same actual seeded full state changed')
        return entry
    def recovery_contract(self,contract):
        return {**contract,'proxy':self.plan['proxy'],'journal':self.plan['journal_helper'],'journal_sha256':self.plan['journal_sha256'],'fixture_requirements':self.plan['fixture_requirements']}
    def recovery_history(self,authority,challenge,role,pid):
        count=challenge['source_history_prefix'];require(type(count)is int and count>0,'complete nonempty source history prefix absent')
        pins=authority['body']['preserved_history_prefixes'];by_path={p['path']:p for p in pins}
        require(len(by_path)==len(pins),'duplicate history pin path')
        expected=[self.work/'requests'/(('child-%s-%08d.json'%(pid,n))if role=='child'else('parent-%08d.json'%n))for n in range(1,count+1)]
        material=self.recovery_materials[self.bound_entry['id']];expected.append(Path(material['path']))
        for path in expected:
            raw=path.read_bytes();require(by_path.get(str(path))=={'path':str(path),'bytes':len(raw),'sha256':digest(raw)},'original complete source/first-fault/prefault archive history not exactly externally pinned')
        require(RecoveryAuthority.exact_file(material['path'])==material,'original immutable pre-fault journal/backup/source archive identity/state changed')
    def recovery_physical(self,proof,contract,allow_close2=False):
        RecoveryAuthority.validate_resources(proof,self.recovery_contract(contract),allow_close2)
        known=self.recovery_actual_registries.get((proof['pid'],proof['nodeid']))
        require(known is not None and RecoveryAuthority.encode(proof['registrations'])==RecoveryAuthority.encode(known),'fresh failed resource population differs from independently retained source registry')
        owners=[{'owner_object':owner,'closed':True}for(pid,owner)in self.stream_leases if pid==proof['pid']]
        require(RecoveryAuthority.encode(proof['publication_stream_owners'])==RecoveryAuthority.encode(owners),'complete independent original stream-owner population differs')
        return True
    def recovery_child(self,path,row,snapshot):
        contract=self.bind_child(row['config_path'],row['pid']);pid=row['pid'];kind=row['kind']
        require(row['program_sha256']==contract['program_sha256'],'failed recovery child source differs')
        self.intact(snapshot,True)
        if kind=='RECOVERY_ORIGINAL_PUBLICATION_FAILED':
            require(pid in self.recovery_child_settled and row['ordinary_quiet']is False and row['scientific_qualification']is False,'failed publication lacks prior exact independent settlement')
            require(type(row['original_kind'])is str,'original failed publication kind absent');return
        if kind=='RECOVERY_CONTEXT_SOURCE_REGISTRY':
            actual=row['actual'];require(row['nodeid']==actual['nodeid']and actual['nodeid']in contract['expected_ids']and actual['fixture_required']is self.plan['fixture_requirements'][actual['nodeid']],'complete original context registry principal differs')
            self.recovery_actual_registries[(pid,actual['nodeid'])]=actual['registered'];return
        if kind=='RECOVERY_CHILD_HELD':
            challenge=row['challenge'];p=challenge['principal']
            require(p['role']=='child'and p['pid']==pid and p['program_sha256']==contract['program_sha256']and p['config_path']==contract['config_path']and p['nodeid']in contract['expected_ids'],'failed recovery source-held principal differs')
            require(challenge['route_id']==self.g['control']['route_id']and challenge['source_frame_held']is True,'failed recovery route/frame differs')
            require(RecoveryAuthority.encode(challenge['registered'])==RecoveryAuthority.encode(row['actual']['registered'])and RecoveryAuthority.encode(challenge['registered'])==RecoveryAuthority.encode(self.recovery_actual_registries.get((pid,p['nodeid']))),'held original registry differs from independently observed source population')
            self.recovery_challenges[pid]=challenge;return
        if kind=='RECOVERY_FIXTURE_TEARDOWN_AUTHORIZED_FAILED':
            require(pid in self.recovery_child_settled and row['ordinary_quiet']is False,'fixture teardown lacks distinct failed-settlement authority')
            self.recovery_physical(row['proof'],contract,self.g['control']['id']=='M2-close-two'and row['nodeid']==self.recovery_child_settled[pid]['proof']['nodeid']);return
        if kind=='RECOVERY_CHILD_SETTLED_FAILED':
            require(pid not in self.recovery_child_settled,'failed child settlement attempt already admitted')
            challenge=self.recovery_challenges[pid];require(row['challenge']==challenge,'actual recovery child challenge changed')
            a=self.recovery_authority.load('child',challenge,challenge['principal'])
            require(a is not None and a['raw_sha256']==row['authority']['raw_sha256'],'fresh distinct ROOT child recovery authority differs')
            self.recovery_history(a,challenge,'child',pid)
            original=challenge['original_source_edge'];require(original['nodeid']==challenge['principal']['nodeid']and any(r['sequence']==original['sequence']for r in self.recovery_causal_rows.get(pid,[]))and original['sequence']<=challenge['source_history_prefix'],'exact preceding independently interpreted original fault/forbidden source edge absent')
            original_path=self.work/'requests'/('child-%s-%08d.json'%(pid,original['sequence']));original_row=json.loads(original_path.read_bytes());require(original_row['kind']==original['kind']and original_row['actual']['nodeid']==original['nodeid'],'ROOT recovery source-edge identity differs')
            require(row['proof']['nodeid']==contract['expected_ids'][-1],'failed release cannot omit later selected context')
            close2=self.g['control']['id']=='M2-close-two'and self.g['control']['route_id']in('route-025','route-026')
            self.recovery_physical(row['proof'],contract,close2)
            require(row['original_history_invalid']is True and row['ordinary_quiet']is False,'recovery cannot repair original publication/quiet history')
            self.recovery_authority.consume(a)
            self.recovery_child_settled[pid]={'authority':a,'proof':row['proof'],'challenge':challenge,'source_request_sha256':digest(path.read_bytes()),'source_request':str(path)}
            write(path.with_suffix('.recovery-ack'),{'status':'INDEPENDENT_RECOVERY_FAILED_UNQUALIFIED','observer_pid':os.getpid(),'request_sha256':digest(path.read_bytes()),'recovery_authority_sha256':a['raw_sha256'],'ordinary_quiet':False});return
        require(kind=='RECOVERY_CHILD_FINAL_FAILED'and pid in self.recovery_child_settled,'unknown/unsettled recovery child final')
        settled=self.recovery_child_settled[pid]
        require(row['authorization_sha256']==settled['authority']['raw_sha256']and row['collection']==contract['expected_ids'],'failed final authority/full external cohort differs')
        require(row['contexts']==[{'nodeid':node,'teardown_complete':True}for node in contract['expected_ids']],'actual original teardown/full-context final proof incomplete')
        require([p['nodeid']for p in row['proofs']]==contract['expected_ids'],'fresh failed final resource population differs')
        for proof in row['proofs']:self.recovery_physical(proof,contract,self.g['control']['id']=='M2-close-two'and proof['nodeid']==settled['proof']['nodeid'])
        require(row['ordinary_quiet']is False and row['scientific_qualification']is False and row['dependents_stopped']is True,'failed final qualification/continuation forbidden')
        self.recovery_child_final[pid]={'row':row,'path':str(path),'sha256':digest(path.read_bytes())}
        write(self.out/('failed-recovery-child-final-'+str(pid)+'.evidence'),self.recovery_child_final[pid])
    def recovery_parent(self,path,row,snapshot):
        kind=row['kind'];extra=row['extra']
        if kind=='RECOVERY_PARENT_HELD':
            require(extra['principal']['pid']==self.parent and extra['route_id']==self.g['control']['route_id'],'failed parent exact principal/route differs')
            self.recovery_parent_challenges[extra['principal']['frame_object']]=extra;return
        require(kind in('RECOVERY_PARENT_SETTLEMENT_REQUEST','BEFORE_ORIGINAL_FAILED_RECOVERY_RESTORE','AFTER_ORIGINAL_FAILED_RECOVERY_RESTORE'),'unknown failed parent source edge')
        a=extra['authority'];body=a['body'];challenge=next(v for v in self.recovery_parent_challenges.values()if RecoveryAuthority.digest(RecoveryAuthority.encode(v))==body['challenge_sha256'])
        actual=self.recovery_authority.load('parent',challenge,challenge['principal'])
        require(actual is not None and actual['raw_sha256']==a['raw_sha256'],'distinct exact ROOT parent recovery authority differs')
        if kind!='AFTER_ORIGINAL_FAILED_RECOVERY_RESTORE':
            self.intact(snapshot,True);entry=self.bound_entry
            self.recovery_history(actual,challenge,'parent',self.parent)
            require(challenge['original_entry']==entry,'original canonical journal entry differs in failed recovery')
            require(snapshot['backup_raw'][0]['sha256']==entry['sha256'],'failed recovery requires original valid backup; damaged input remains separate OPEN owner-API duty')
            source={k:snapshot['source'][k]for k in ('mode','mtime_ns','sha256','device','inode')}
            require(all(challenge['source'][k]==v for k,v in source.items()),'actual source changed after failed-parent authority')
            parent_faults=[r for r in self.frame_edges if r['kind']=='PARENT_EXCEPTION_EDGE'and r['sequence']<=challenge['source_history_prefix']]
            require(challenge['recovery_trigger']is not None and(any(r['sequence']<=challenge['source_history_prefix']for r in self.recovery_causal_rows.get(self.parent,[]))or self.recovery_causal_rows or(parent_faults and challenge['first_failure']is not None)),'preceding original failure/forbidden history absent')
            if challenge['child_attempted']:
                handle=challenge['actual_Popen'];require(handle is not None and type(handle['returncode'])is int,'actual owned Popen not naturally reaped')
                if handle['pid']in self.recovery_child_final:
                    require(self.recovery_child_final[handle['pid']]['row']['pid']==handle['pid'],'recovery child/Popen identity differs')
                else:
                    # Parent-only barrier faults may have an intact genuine
                    # ordinary child stream. Reuse the exact original verifier;
                    # IO/close2 invalid histories cannot pass this branch.
                    contract=self.all_streams[handle['pid']]
                    fresh=self.bind_child(contract['config_path'],handle['pid'],require_active_seed=False)
                    complete_stream(self.plan,fresh)
            else:
                require(challenge['actual_Popen']is None,'no-child source branch has a handle')
                branches=[r for r in self.frame_edges if r['kind']=='ACTUAL_PRELAUNCH_REFUSAL_BRANCH']
                require(branches and branches[-1]['extra']=={'nonempty_options':True,'child_attempted':False},'actual no-child refusal not source-proved')
                require(not any(r['kind']=='BEFORE_ACTUAL_DRIVER_POPEN'and r['sequence']>branches[-1]['sequence']for r in self.frame_edges),'child attempt follows no-child proof')
            material=self.recovery_materials[entry['id']]
            require(digest(Path(material['path']).read_bytes())==material['sha256'],'independent pre-fault entry/backup/source archive changed')
            if kind=='BEFORE_ORIGINAL_FAILED_RECOVERY_RESTORE':
                require(self.recovery_restore_admitted is not None and extra['entry']==entry and extra['original_owner_frame']==challenge['principal']['original_seed_owner_frame'],'same original _restore entry/owning generator changed')
            self.recovery_restore_admitted={'authority_sha256':a['raw_sha256'],'entry':entry,'challenge':challenge,'material':material}
        else:
            admitted=self.recovery_restore_admitted;require(admitted is not None and a['raw_sha256']==admitted['authority_sha256']and extra['entry']==admitted['entry'],'failed restore outcome does not bind original entry')
            expected=self.plan['proxy_state'];require(all(snapshot['source'][k]==expected[k]for k in ('mode','mtime_ns','sha256'))and snapshot['decoded_entries']==[],'canonical restored fullmode/nsmtime/bytes/entry drop not exact')
            require(snapshot['lock_probe'].get('other_owner_holds')is True and snapshot['parent_alive']is True,'actual original owner/pathlock lost before recovery outcome')
            require(digest(Path(admitted['material']['path']).read_bytes())==admitted['material']['sha256'],'failed evidence archive changed during canonical drop')
            self.recovery_authority.consume(actual)
            self.failed_recovery=True;self.seed_active=False;self.bound_entry=None;self.seeded_state=None;self.active_recipe=None
            write(self.out/'RECOVERY_FAILED_UNQUALIFIED.evidence',{'authority_sha256':a['raw_sha256'],'source':snapshot['source'],'journal_raw':snapshot['journal_raw'],'pre_fault_archive':admitted['material'],'old_failure_history_preserved':True,'ordinary_quiet':False,'scientific_qualification':False,'dependents_stopped':True})
        write(path.with_suffix('.recovery-ack'),{'status':'INDEPENDENT_RECOVERY_FAILED_UNQUALIFIED','observer_pid':os.getpid(),'request_sha256':digest(path.read_bytes()),'recovery_authority_sha256':a['raw_sha256'],'ordinary_quiet':False})

    def gate(self,path,row,snapshot):
        kind=row['kind'];status=None
        if kind=='ORIGINAL_DURABLE_ENTRY_BEFORE_SEED':
            entry=self.intact(snapshot,False);self.seed_active=True;status='INDEPENDENT_SNAPSHOT_DURABLE'
            material={'original_entry':self.bound_entry,'source_full_state':snapshot['source'],'canonical_bytes_base64':snapshot['backup_raw'][0]['raw_base64'],'original_journal_raw':snapshot['journal_raw'],'backup_raw':snapshot['backup_raw'],'observer_pid':os.getpid(),'execution_authority_sha256':self.execution_sha,'qualification':False}
            archive=self.out/('pre-fault-canonical-'+entry['id']+'.evidence');require(not archive.exists(),'pre-fault recovery archive already exists');self.recovery_materials[entry['id']]=RecoveryAuthority.exclusive_bytes(archive,RecoveryAuthority.encode(material))
        elif kind=='ORIGINAL_SEEDED_YIELD':self.intact(snapshot,True);status='INDEPENDENT_SNAPSHOT_DURABLE'
        elif kind=='BEFORE_ORIGINAL_RESTORE':
            self.intact(snapshot,True)
            # Independently re-open actual complete child streams; no trust in
            # driver receipt labels, status, reaping or its positive-proof claim.
            c=self.g['control'];nochild=c['derivative'] in ('ordinary-prelaunch-environment-refusal','sole-no-child-branch-loss')
            require(not(c['mode']=='control'and c['id']=='M2-observer-IO'and c.get('stream_fault')),'original positive publication stream permanently invalid after actual IO seam; NEW ROOT recovery required, no ordinary restore ACK')
            if nochild:
                events=[e for e in self.frame_edges if e.get('kind')=='ACTUAL_PRELAUNCH_REFUSAL_BRANCH']
                require(events and events[-1]['extra']=={'nonempty_options':True,'child_attempted':False},'actual no-child refusal not independently observed')
                require(not any(e['kind']=='BEFORE_ACTUAL_DRIVER_POPEN' and e['sequence']>events[-1]['sequence'] for e in self.frame_edges),'Popen attempt after no-child refusal')
            else:
                require(self.child_streams,'no actual source-bound observation file')
                self.plan['_active_recipe']=self.active_recipe
                for pid,contract in list(self.child_streams.items()):
                    fresh=self.bind_child(contract['config_path'],pid);complete_stream(self.plan,fresh)
            # Unsafe source edge is retained even when proof is unavailable. Do
            # not ACK/release it merely because this is a negative control.
            status='INDEPENDENT_SNAPSHOT_DURABLE'
        elif kind=='AFTER_ORIGINAL_RESTORE':
            src=snapshot['source'];expected=self.plan['proxy_state']
            require(all(src[k]==expected[k] for k in ('mode','mtime_ns','sha256')) and snapshot['decoded_entries']==[],'exact original restoration/empty journal not observed')
            self.seed_active=False;self.bound_entry=None;self.seeded_state=None;self.active_recipe=None;status='INDEPENDENT_SNAPSHOT_DURABLE'
        elif kind in ('ACTUAL_STREAM_TEMPORARILY_UNAVAILABLE','ACTUAL_STREAM_READ_DENIED','ACTUAL_BARRIER_FILE_FAILURE_BEFORE_OWNER_RESTORE'):
            self.intact(snapshot,True)
            extra=row['extra'];file_raw=None
            if kind=='ACTUAL_STREAM_TEMPORARILY_UNAVAILABLE':
                file_raw=capture(extra['retained']);require(file_raw.get('sha256')==extra['sha256'] and not Path(extra['path']).exists(),'same original moved stream is not retained/absent')
            elif kind=='ACTUAL_STREAM_READ_DENIED':
                file_raw=capture(extra['path']);require(file_raw.get('error',{}).get('type')=='PermissionError','actual independent OS read denial not established')
            write(self.out/('file-seam-%08d.json'%snapshot['sequence']),{'kind':kind,'actual_file':file_raw,'source_request':row})
            status='INDEPENDENT_SNAPSHOT_DURABLE'
        if status:
            write(path.with_suffix('.ack'),{'status':status,'request_sha256':digest(path.read_bytes()),'raw_snapshot':str(self.out/('%08d.json'%snapshot['sequence'])),'observer_pid':os.getpid()})
    def bind_child(self,config_path,pid,source_extra=None,require_active_seed=True):
        # Cohort comes ONLY from external full plan + actual independently opened
        # launch/config recipe+phase. Activation target_ids never selects tests.
        config_path=Path(config_path);raw=config_path.read_bytes();cfg=json.loads(raw)
        launched_raw=(config_path.parent/'launched.json').read_bytes();launched=json.loads(launched_raw)
        require(launched['pid']==pid and launched['config_sha256']==digest(raw),'actual launch/config/PID differs')
        argv=launched['argv'];require(len(argv)==7 and argv[0]==self.plan['primary_python']and argv[1:3]==['-B','-X']and argv[4]=='-c'and argv[6]==str(config_path),'actual exact original child argv differs')
        program=digest(argv[5].encode());require(program in self.g['child_program_sha256s']and cfg['native_control']['program_sha256']==program,'actual child program unbound')
        require(all(cfg['native_control'].get(k)==v for k,v in self.g['control'].items())and cfg['native_control']['independent_observer_pid']==os.getpid(),'actual exact control/independent observer config differs')
        require(cfg['root']==self.plan['roots']['NS']and launched['cwd']==cfg['root']and cfg['test']==self.plan['test']and cfg['journal']==self.plan['journal_helper']and cfg['proxy']==self.plan['proxy'],'actual child root/source paths differ')
        require(cfg['plan_sha256']==self.g['plan_sha256']and cfg['test_sha256']==self.plan['test_sha256']and cfg['journal_sha256']==self.plan['journal_sha256'],'actual child origin hashes differ')
        require(cfg['fixture_requirements']==self.plan['fixture_requirements']and cfg['canonical_ids']==[x['id']for x in self.plan['canonical_305']],'actual full fixture/canonical authority differs')
        recipe=cfg['recipe'];phase=cfg['phase'];require(type(recipe)is int and 0<=recipe<=20 and phase in ('healthy','red','restored'),'actual recipe/phase invalid')
        require(recipe!=0 or phase!='red','full endpoint cannot be red')
        role='red'if phase=='red'else 'canonical';require(program==self.g['child_program_by_phase'][role],'actual phase used the wrong complete observer program')
        expected=[x['id']for x in self.plan['canonical_305']]if recipe==0 else self.plan['recipes'][recipe-1]['current_full_ids']
        selectors=['tests/test_lean_slots.py']if recipe==0 else self.plan['recipes'][recipe-1]['actual_selectors']
        pytest_argv=['-p','no:cacheprovider','--capture=tee-sys','-o','junit_logging=all','-o','junit_log_passing_tests=true','--junitxml='+str(config_path.parent/'pytest.xml'),'-q',*selectors]
        require(cfg['pytest_argv']==pytest_argv and launched['pytest_argv']==pytest_argv,'actual exact original selector argv differs')
        require(cfg['observation']==str(config_path.parent/'observations.jsonl')and config_path.parent.is_relative_to(Path(self.g['output'])),'actual stream/config outside bound original output')
        proxy=self.plan['recipes'][recipe-1]['mutant_sha256']if phase=='red'else self.plan['proxy_state']['sha256'];require(cfg['proxy_sha256']==proxy,'actual phase proxy binding differs')
        if source_extra is not None:require(source_extra['recipe']==recipe and source_extra['phase']==phase and source_extra['path']==cfg['observation'],'actual source frame recipe/phase/stream differs')
        program_tree=ast.parse(argv[5]);observer_class=next(n for n in program_tree.body if isinstance(n,ast.ClassDef)and n.name=='Observer')
        rig=next(n for n in observer_class.body if isinstance(n,ast.FunctionDef)and n.name=='rig');retain=next(n for n in observer_class.body if isinstance(n,ast.FunctionDef)and n.name=='retain')
        acquire_lines=[n.lineno for n in ast.walk(rig)if isinstance(n,ast.Raise)and isinstance(n.exc,ast.Call)and n.exc.args and isinstance(n.exc.args[0],ast.Constant)and n.exc.args[0].value=='actual metadata lock did not permit bounded observation']
        retry_lines=[n.body[0].lineno for n in ast.walk(retain)if isinstance(n,ast.Try)and any(isinstance(v,ast.Return)for v in n.body)]
        io_lines={}
        for operation,callee,argname in [('open','original_open','bad'),('write','original_write','fd'),('fsync','original_fsync','duplicate')]:
            found=[n.lineno for n in ast.walk(program_tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id==callee and n.args and isinstance(n.args[0],ast.Name)and n.args[0].id==argname]
            require(len(found)==1,'exact actual native syscall/argument source is missing or ambiguous');io_lines[operation]=found[0]
        protocol={**self.g['recovery']['protocol'],'execution_authority_sha256':self.execution_sha,'harness_pid':self.parent,'observer_pid':os.getpid(),'expected_ids':expected}
        require(cfg['recovery_protocol']==protocol,'actual failed-recovery protocol/principals/full cohort differs')
        c={'io_syscall_lines':io_lines,'pid':pid,'config_path':str(config_path),'config_sha256':digest(raw),'launched_sha256':digest(launched_raw),'program_sha256':program,'recipe':recipe,'phase':phase,'proxy_sha256':proxy,'observation':cfg['observation'],'expected_ids':expected,'expected_ids_authority':'EXTERNAL_FULL_PLAN_RECIPE_PHASE_NEVER_COLLECTION_OR_ACTIVATION_TARGETS','pytest_argv':pytest_argv,'metadata_acquire_lines':acquire_lines,'retain_retry_lines':retry_lines}
        if pid in self.all_streams:require(self.all_streams[pid]==c,'same exact child contract changed')
        self.all_streams[pid]=c;self.child_pids.add(pid)
        if phase=='red'and require_active_seed:
            require(self.active_recipe==recipe and self.seed_active,'red child outside exact original seed');self.child_streams[pid]=c
        return c
    def io_physical_identity(self,path):
        st=os.stat(path,follow_symlinks=False);require(stat.S_ISREG(st.st_mode),'IO capability not an actual regular file')
        return {'path':str(path),'device':st.st_dev,'inode':st.st_ino,'mode':st.st_mode,'uid':st.st_uid,'gid':st.st_gid,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns}
    def admit_io(self,path,row,contract,snapshot):
        require(contract['phase']=='red'and self.g['control']['id']=='M2-observer-IO','IO admission outside exact control route')
        require(row['program_sha256']==contract['program_sha256'],'IO source program differs')
        self.intact(snapshot,True);source=row['source_frame'];require(source['file']=='<string>'and type(source['frame_object'])is int,'actual child IO source frame absent')
        stream=self.io_physical_identity(contract['observation']);fault=self.io_physical_identity(self.g['control']['os_fault_file'])
        require(fault==self.fault_identity,'same owned granted fault capability changed')
        common=('device','inode','mode','uid','gid')
        if row['kind']=='ACTUAL_STREAM_OWNER_OPENED':
            require(source['function']=='opened','stream owner source frame differs');lease=row['lease'];fd=lease['fd_identity']
            require(lease['file_identity']==stream and all(fd[k]==stream[k]for k in common),'actual stream fd/file identity differs')
            require(type(lease['owner_object'])is int and lease['owner_object']>0 and type(fd['fd'])is int and fd['fd']>=0,'actual stream owner identity invalid')
            require(fd['flags']&os.O_ACCMODE==os.O_WRONLY and fd['flags']&os.O_APPEND and fd['fd_flags']==fcntl.FD_CLOEXEC,'actual original append-stream flags differ')
            key=(row['pid'],lease['owner_object']);require(key not in self.stream_leases,'duplicate/reused stream owner')
            admitted={'owner_object':lease['owner_object'],'fd_identity':fd,'opening_file_identity':stream,'source_frame':source,'config_sha256':contract['config_sha256'],'program_sha256':contract['program_sha256'],'pid':row['pid'],'nodeid':(row.get('actual')or{}).get('nodeid')}
            self.stream_leases[key]=admitted;exact=admitted
        else:
            operation=row['operation'];require(operation==self.g['control']['stream_fault'],'actual OS operation differs from granted seam')
            require(source['function']=={'open':'opened','write':'write','fsync':'fsync'}[operation],'native operation source function differs')
            require(row['requested_stream']==contract['observation']and row['stream_identity']==stream and row['fault_identity']==fault,'exact independent stream/fault physical state differs')
            owner=row['stream_owner'];current_owner=row['stream_owner_now'];descriptor=row['descriptor'];duplicate=row['duplication'];actual=row.get('actual')or{}
            require(actual.get('nodeid')in self.g['control']['target_ids']and actual.get('fixture_required')is True,'IO native attempt outside exact active original node')
            if operation=='open':
                require(row['actual_path']==str(Path(self.g['control']['os_fault_file'])/'observer.jsonl')and owner is None and current_owner is None and descriptor is None and duplicate is None,'actual ENOTDIR path/owner/fd binding differs')
            else:
                require(type(owner)is dict and self.stream_leases.get((row['pid'],owner['owner_object']))==owner,'exact authenticated original stream owner differs')
                original=owner['fd_identity'];require(owner['nodeid']==actual['nodeid']and current_owner=={'owner_object':owner['owner_object'],'closed':False,'fd_identity':original},'exact original stream owner/current fd state differs')
                require(all(original[k]==stream[k]for k in common),'same original stream device/inode/owner/mode changed')
                require(type(descriptor)is dict and type(descriptor['fd'])is int and descriptor['fd']>=0 and descriptor['fd']!=original['fd']and descriptor['fd_flags']==fcntl.FD_CLOEXEC,'actual separate OS descriptor identity/flags differ')
                if operation=='write':
                    require(row['actual_path']==self.g['control']['os_fault_file']and duplicate is None,'actual write path/duplicate binding differs')
                    require(all(descriptor[k]==fault[k]for k in common)and descriptor['flags']==self.fault_read_flags,'actual readonly fault fd device/inode/owner/full flags differ')
                else:
                    require(row['actual_path']==contract['observation']and all(descriptor[k]==original[k]for k in common+('flags','fd_flags')),'actual duplicate is not same original stream/flags')
                    require(duplicate=={'source_fd':original['fd'],'duplicate_fd':descriptor['fd'],'before':descriptor,'close_called_fd':descriptor['fd'],'close_return':None},'exact stream duplicate/actual close lineage differs')
            call=row['actual_call'];require(type(call)is dict,'independent actual syscall source argument absent')
            if operation=='open':
                require(call=={'argument':row['actual_path'],'lineage':{'tuple':['Path.open',row['actual_path'],None,None,None]},'descriptor':None,'owner':None},'actual Path.open argument/lineage differs')
            else:
                require(type(call['argument'])is int and call['argument']>=0 and call['argument']==descriptor['fd'],'declared descriptor is not actual nonnegative syscall argument')
                require(call['owner']==current_owner,'actual call owner differs from current original lease')
                if operation=='write':
                    require(call['descriptor']==descriptor and call['lineage']=={'tuple':['os.open-readonly',None,descriptor['fd'],None,None]},'actual readonly creation/argument/physical descriptor differs')
                else:
                    require(call['descriptor']is None and call['lineage']=={'tuple':['os.dup-close',original['fd'],descriptor['fd'],descriptor['fd'],None]},'actual duplicate return/close/call argument lineage differs')
            exact={k:row[k]for k in ('operation','requested_stream','actual_path','stream_identity','fault_identity','stream_owner','stream_owner_now','descriptor','duplication','source_frame','actual_call')}
            exact['nodeid']=actual['nodeid'];exact['rig_identity']=actual['rig']
            self.io_admissions[(row['pid'],row['sequence'])]={'exact':exact,'request_sha256':digest(path.read_bytes()),'contract':contract}
        write(path.with_suffix('.ack'),{'status':'INDEPENDENT_IO_IDENTITY_ADMITTED','request_sha256':digest(path.read_bytes()),'exact_operation':exact,'observer_pid':os.getpid(),'independent_snapshot':snapshot['sequence']})
    def native_valid(self,native,row):
        require(type(native)is dict and type(native['exception_object'])is int and native['exception_object']>0,'native exception identity absent')
        require(type(native['first_traceback_object'])is int and native['traceback']and native['traceback_object']==native['traceback'][0]['traceback_object'],'native traceback absent/changed')
        require(native['first_monotonic_ns']<=native['observed_monotonic_ns']<=row['monotonic_ns']and native['first_utc_ns']<=native['observed_utc_ns'],'native first clocks invalid')
        require(type(native['args'])is dict and type(native['args'].get('tuple'))is list,'native BaseException.args absent')
        return native
    def child_control(self,row,snapshot):
        kind=row['kind'];actual=row.get('actual')or{};pid=row['pid'];contract=self.bind_child(row['config_path'],pid)
        require(row['program_sha256']==contract['program_sha256'],'native row program differs from actual child')
        c=self.g['control'];node=actual.get('nodeid');require(node is None or node in contract['expected_ids'],'native node outside full cohort')
        if node is not None and 'registered'in actual:self.recovery_actual_registries[(pid,node)]=actual['registered']
        edge=row.get('frame_exit')or{};native=row.get('exception')if kind=='SOURCE_EXCEPTION_EDGE'else edge.get('native')
        if kind=='METADATA_ATTEMPT_STARTED':
            attempt=row['attempt'];require(attempt['pid']==pid and attempt['nodeid']==node and attempt['config_path']==row['config_path']and attempt['program_sha256']==contract['program_sha256'],'actual metadata principal differs')
            require(actual.get('owned_lock')is True and attempt['metadata_owner']==actual.get('metadata_owner')and attempt['metadata_owner']['broker']==attempt['broker']and attempt['broker']in[r['identity']for r in actual['registered']['broker']]and attempt['metadata_owner']['worker']in[r['identity']for r in actual['registered']['worker']],'actual exact metadata broker/worker/Event owner unavailable')
            require(attempt['source_file']=='<string>'and attempt['acquire_line']in contract['metadata_acquire_lines']and all(type(attempt[k])is int and attempt[k]>0 for k in('attempt_id','context_object','retain_frame_object','rig_frame_object','acquire_line','monotonic_ns')),'actual metadata source/context identity absent')
            key=(pid,attempt['attempt_id']);require(key not in self.metadata_started,'duplicate actual metadata attempt')
            self.metadata_started[key]=attempt
        attempt=None
        if native is not None and native.get('metadata_attempt')is not None:
            attempt=native['metadata_attempt'];require(self.metadata_started.get((pid,attempt['attempt_id']))==attempt,'native fault lacks exact distinct admitted original metadata attempt')
            require(attempt['nodeid']==node and attempt['monotonic_ns']<=native['first_monotonic_ns']and any(t['frame_object']==attempt['rig_frame_object']and t['function']=='rig'for t in native['traceback']),'native metadata cause/frame/time differs')
            require(native['traceback'][-1]['frame_object']==attempt['rig_frame_object']and native['traceback'][-1]['line']==attempt['acquire_line'],'native failure is outside exact original lock acquisition/raise')

        if native is not None:
            self.native_valid(native,row);self.native_occurrences.setdefault((pid,node,native['exception_object']),[]).append(row)
        # Enroll FIRST retain fault BEFORE any unrelated negative filter/return.
        if kind=='SOURCE_EXCEPTION_EDGE'and row.get('function')=='retain':
            require(native is not None,'actual retain exception lacks native object')
            key=(pid,node);anchor=self.first_retain_fault.setdefault(key,{'first_native':native,'first_row':row['sequence'],'occurrences':[],'actual_context_deadline_ns':None,'metadata_attempts':{},'caught_metadata_attempts':[]})
            anchor['occurrences'].append(native['exception_object'])
            if attempt is not None and native['type']=='RuntimeError'and native['args']=={'tuple':['actual metadata lock did not permit bounded observation']}:
                if anchor['metadata_attempts']:
                    previous=next(iter(anchor['metadata_attempts'].values()))['attempt']
                    require(all(attempt[k]==previous[k]for k in('context_object','retain_frame_object','nodeid','broker','metadata_owner')),'metadata repetition crosses original context/owner')
                require(attempt['attempt_id']not in anchor['metadata_attempts'],'same actual metadata attempt counted twice at retain')
                anchor['metadata_attempts'][attempt['attempt_id']]={'attempt':attempt,'exception_object':native['exception_object']}

            deadline=actual.get('control_deadline_ns')
            if deadline is not None:
                require(type(deadline)is int and deadline>=anchor['first_native']['first_monotonic_ns'],'actual context deadline invalid')
                if anchor['actual_context_deadline_ns']is None:anchor['actual_context_deadline_ns']=deadline
                require(anchor['actual_context_deadline_ns']==deadline,'actual original context deadline changed')
        if kind=='CONTROL_ACTIVATED'and c['id']=='M2-signal-stop':
            for role in self.g['signal_roles']:
                target=self.parent if role=='parent'else pid;key=(role,target)
                if key not in self.signalled:
                    self.intact(snapshot,True);require(alive(target),'exact signal target absent')
                    write(self.out/('signal-'+role+'-'+str(target)+'.json'),{'target_pid':target,'role':role,'signal':int(signal.SIGTERM),'before_snapshot':snapshot['sequence']})
                    os.kill(target,signal.SIGTERM);self.signalled.add(key)
        anchor=self.first_retain_fault.get((pid,node))
        if kind=='NATIVE_RETAIN_CAUGHT_RETRY'and attempt is not None and anchor is not None:
            require(row['line']in contract['retain_retry_lines']and edge['frame_object']==attempt['retain_frame_object'],'caught/retry is not exact same original retain frame/line')
            saved=anchor['metadata_attempts'].get(attempt['attempt_id'])
            require(saved is not None and saved['exception_object']==native['exception_object'],'caught/retry does not pair exact original metadata fault')
            require(attempt['attempt_id']not in anchor['caught_metadata_attempts'],'duplicate caught/retry metadata pair')
            anchor['caught_metadata_attempts'].append(attempt['attempt_id'])
        negative=False;discriminator=None
        if kind=='ACTUAL_QUIET_RETURN':
            receipt=row.get('receipt')or{};records=[r for table in(receipt.get('rig')or{}).get('records',[])for r in table.values()]
            pending=any(any(a.get('pending')is not False for a in r['attempts'])or any(o['state']!='DONE'for o in r['operations'].values())or r['state']not in('LIVE','TERMINATED')or r['close_owner']is not None for r in records)
            negative=receipt.get('quiescent')is False or(receipt.get('quiescent')is True and(pending or any(w['alive']is not False or w['done']is not True for w in actual.get('workers',[]))or any(x['closed']!=1 for x in actual.get('connections',[]))))
            discriminator='ACTUAL_RESIDUAL_OR_FALSE_QUIET'
        if c['id']in('M2-metadata-lock','M2-observation-deadline'):
            lock_fault=attempt is not None and native is not None and native['type']=='RuntimeError'and native['args']=={'tuple':['actual metadata lock did not permit bounded observation']}and actual.get('owned_lock')is True
            if c['id']=='M2-metadata-lock':
                negative=(kind=='NATIVE_RETAIN_CAUGHT_RETRY'and lock_fault)or(kind=='AFTER_ORIGINAL_METADATA_READ'and actual.get('owned_lock')is True)
                discriminator='ORIGINAL_LOCK_REFUSAL_CAUGHT_RETRY_OR_ACTUAL_FORBIDDEN_COPY'
            else:
                anchor=self.first_retain_fault.get((pid,node));negative=False
                if anchor is not None and lock_fault:
                    if c['derivative']=='canonical':
                        negative=kind=='NATIVE_RETAIN_CAUGHT_RETRY'and len(anchor['caught_metadata_attempts'])>=2 and row['monotonic_ns']>=anchor['first_native']['first_monotonic_ns']+1000000000 and edge.get('disposition')=='caught_then_original_retry'
                        discriminator='CANONICAL_ACTUAL_REPEATED_CAUGHT_FAULTS_BEYOND_FIRST_NATIVE_DIAGNOSTIC_WINDOW'
                    elif c['derivative']=='diagnostic-deadline-as-observer-exit':
                        deadline=actual.get('control_deadline_ns');require(deadline is None or anchor['actual_context_deadline_ns']==deadline,'escape changed actual context deadline')
                        negative=kind=='SOURCE_FRAME_EXIT'and row.get('function')=='retain'and edge.get('disposition')=='escaped_exception'and deadline is not None and edge['monotonic_ns']>=deadline and len(anchor['metadata_attempts'])>=2 and len(anchor['caught_metadata_attempts'])>=1 and anchor['metadata_attempts'].get(attempt['attempt_id'],{}).get('exception_object')==native['exception_object']and attempt['attempt_id']not in anchor['caught_metadata_attempts']
                        discriminator='DERIVATIVE_SAME_NATIVE_EXCEPTION_ESCAPED_AT_ACTUAL_ORIGINAL_CONTEXT_DEADLINE'
        if c['id']=='M2-observer-IO':
            negative=False
            if native is not None:
                op=native.get('operation');args=native['args']['tuple'];expected={'open':20,'write':9,'fsync':9}[c['stream_fault']]
                admitted=self.io_admissions.get((pid,op.get('admission_sequence')))if type(op)is dict else None
                native_call=op.get('native_actual_call')if type(op)is dict else None
                actual_argument_valid=type(native_call)is dict and (type(native_call['argument'])is str if c['stream_fault']=='open'else type(native_call['argument'])is int and native_call['argument']>=0)
                bound=actual_argument_valid and admitted is not None and type(op.get('native_actual_call'))is dict and op['operation']==c['stream_fault']and op['native_actual_call']['immediate_pre_call']==admitted['exact']['actual_call']and op['native_actual_call']['argument']==admitted['exact']['actual_call']['argument']and op['native_actual_call']['lineage']==admitted['exact']['actual_call']['lineage']and op['admission_request_sha256']==admitted['request_sha256']and admitted['contract']==contract and admitted['exact']['nodeid']==node and admitted['exact']['rig_identity']==actual.get('rig')and native['errno']==expected and args and args[0]==expected
                if bound:
                    source=admitted['exact']['source_frame'];require(op['native_actual_call']['capture_line']==contract['io_syscall_lines'][op['operation']]and op['native_actual_call']['capture_frame_object']==source['frame_object']and any(t['frame_object']==source['frame_object']and t['line']==op['native_actual_call']['capture_line']for t in native['traceback'])and op['frame_object']==source['frame_object']and op['file']==source['file']and op['function']==source['function']and any(t['frame_object']==source['frame_object']for t in native['traceback']),'same admitted actual syscall frame absent from native TB')
                    negative=(c['derivative']=='canonical'and kind=='NATIVE_RETAIN_CAUGHT_RETRY'and edge.get('disposition')=='caught_then_original_retry')or(c['derivative']=='sole-observer-retention-loss'and kind=='SOURCE_FRAME_EXIT'and row.get('function')=='retain'and edge.get('disposition')=='escaped_exception')
                    discriminator='NATIVE_OS_ERROR_CAUGHT_RETRY_VS_SAME_OBJECT_ACTUAL_RETAIN_ESCAPE'
        if c['id']=='M2-signal-stop'and kind=='SOURCE_FRAME_EXIT'and row.get('function')=='request_stop':negative=True;discriminator='NATIVE_HANDLER_ACTUAL_RETURN_OR_ESCAPE'
        if not negative:return
        self.intact(snapshot,True)
        write(self.out/('independent-negative-'+str(pid)+'-'+str(row['sequence'])+'.json'),{'discriminator':discriminator,'native':native,'first_retain':self.first_retain_fault.get((pid,node)),'actual_context_deadline_ns':actual.get('control_deadline_ns'),'source_request':row,'independent_snapshot':snapshot['sequence'],'historical_stream_validity':'NEVER_REPAIRED_BY_SEAM_REMOVAL'})
        if c.get('stream_fault'):
            marker=Path(c['remove_fault_path'])
            if not marker.exists():write(marker,{'observer_pid':os.getpid(),'negative_raw_sequence':row['sequence'],'native_exception_object':native['exception_object'],'permanent_invalid_stream':True,'new_quiet_authority':False})
        if node and c.get('release_policy')=='EXACT_ORIGINAL_OWNER_AFTER_INDEPENDENT_NEGATIVE'and c['id']!='M2-close-two':
            release=Path(c['release_dir'])/(digest(node.encode())+'.json')
            if not release.exists():write(release,{'token':c['release_token'],'pid':pid,'nodeid':node,'negative_raw_sequence':row['sequence'],'independent_snapshot':snapshot['sequence']})
    def judge_source_edge(self,row,snapshot):
        # Retain affirmative AND refusing causal judgments. These are proposed
        # raw evidence contracts, never author/runtime/ROOT acceptance.
        c=self.g['control'];kind=row['kind'];actual=row.get('actual')or{};extra=row.get('extra')or{};edge=None;facts={}
        if kind=='PARENT_SOURCE_FRAME_EXIT' and row.get('function')=='causal' and 'call'in extra:
            call=extra['call'];loc={}
            for frame in call['frames']:loc.update(frame['locals'])
            close=loc.get('close',{});rec=loc.get('r',{});posts=extra.get('posts')or[]
            facts={'receipt_equality':rec.get('closures')==[close],'final_state':close.get('final_state')=='TERMINATED','status':close.get('result',{}).get('status') in (200,204),'write_done':close.get('response_write')=='DONE','first_cause':close.get('first_error')=='owned frontdoor write failure','close_done':close.get('state')=='DONE','terminated':rec.get('state')=='TERMINATED','no_owner':rec.get('close_owner') is None,'write_failure':any(p['kwargs'].get('write_failure') is True for p in posts)}
            binding=any(f.get('close_binding',{}).get('same_record_closure_object') is True and f['close_binding']['id']==close.get('id') and f['locals'].get('close')==close and f['locals'].get('r')==rec for f in call['frames'])
            facts.update(binding=binding,all_other_conjuncts_true=all(facts.values()),actual_decision=extra.get('actual_decision'))
            edge='CAUSAL16_ALL_OTHER_PREDICATES_INDEPENDENTLY_RECOMPUTED'
            if c['derivative']=='genuine-prior-receipt-substitution':
                provenance=[f.get('control_payload_provenance') for f in call['frames'] if f.get('control_payload_provenance')]
                facts['actual_genuine_prior_provenance']=provenance
                facts['distinct_prior_payload']=bool(provenance) and all(p['prior_literal']!=p['current_literal'] and digest(json.dumps(p['prior_literal'],sort_keys=True).encode())==p['prior_literal_sha256'] and digest(json.dumps(p['current_literal'],sort_keys=True).encode())==p['current_literal_sha256'] and p['prior_first_serialized_literal']==p['prior_literal'] and p['serialized_r_is_current'] is True and p['actual_current_source_binding'] is True and p['serialized_receipt_equals_current_closure'] is False for p in provenance)
        elif kind=='PARENT_SOURCE_FRAME_EXIT' and row.get('function')=='request_stop':
            facts=extra;edge='EXACT_PARENT_HANDLER_THROW_VS_RETURN'
        elif kind=='ACTUAL_QUIET_RETURN':
            receipt=row.get('receipt')or{};rig=receipt.get('rig')or{};records=[r for table in rig.get('records',[])for r in table.values()]
            facts={'reported_quiescent':receipt.get('quiescent'),'actual_live_workers':[w for w in actual.get('workers',[])if w['alive'] is not False or w['done'] is not True],'actual_wrong_close_counts':[v for v in actual.get('connections',[])if v['closed']!=1],'actual_pending_operations':[o for r in records for o in r['operations'].values()if o['state']!='DONE'],'raw_reported_problems':receipt.get('problems'),'complete_registered_identities':actual.get('registered')}
            facts['all_unrelated_for_count']=not facts['actual_live_workers'] and not facts['actual_pending_operations'] and actual.get('inflight')==0
            edge='FIRST_ACTUAL_CHILD_QUIET_PROGRESSION_OR_REFUSAL'
        elif kind in ('BEFORE_ORIGINAL_METADATA_READ','AFTER_ORIGINAL_METADATA_READ'):
            facts={'actual_other_owner_holds':actual.get('owned_lock'),'broker':row.get('broker'),'actual_workers':actual.get('workers'),'records_after_actual_copy':row.get('records')};edge=kind
        elif kind in ('SOURCE_EXCEPTION_EDGE','SOURCE_FRAME_EXIT','NATIVE_RETAIN_CAUGHT_RETRY') and row.get('function') in ('retain','request_stop','inventory','rig'):
            facts={'function':row['function'],'actual_exception':row.get('exception'),'frame_exit':row.get('frame_exit'),'actual_signum':row.get('signum'),'actual_stop_requests':row.get('stop_requests'),'actual_resources':actual};edge='EXACT_SOURCE_EXCEPTION_OR_HANDLER_RETURN_EDGE'
        elif kind=='PARENT_ORIGINAL_RESTORE_ENTRY_WITHOUT_INNER_PROOF':
            require(c['derivative']=='sole-existing-restoration-call-loss'and row['function']=='_restore'and extra['derivative']==c['derivative']and extra['entry']==self.bound_entry and extra['original_seed_owner_frame']>0,'wrong actual original restore interception edge')
            facts=extra;edge=kind
        elif kind in ('ACTUAL_POSITIVE_PROOF_ILLEGAL_CONTINUE','ACTUAL_NO_CHILD_BRANCH','ACTUAL_PRELAUNCH_REFUSAL_BRANCH'):
            facts=extra;edge=kind
            if kind=='ACTUAL_POSITIVE_PROOF_ILLEGAL_CONTINUE':
                self.plan['_active_recipe']=self.active_recipe
                facts={**facts,'independent_complete_actual_streams':[complete_stream(self.plan,contract)for contract in self.child_streams.values()]}
        elif kind=='DIRECTORY_BEFORE_EXACT_APPEND' or (kind=='PARENT_EXCEPTION_EDGE' and row.get('function')=='custody'):
            facts=extra;edge='EXACT_DIRECTORY_COMPARISON_APPEND_EDGE'
            if c['id']=='directory-population':
                path=Path(c['directory_path']);observed=None;error=None
                try:observed=sorted(x.name for x in path.iterdir())
                except OSError as exc:error=OBS_NATIVE.capture(sys._getframe(),sys.exc_info())
                expected=self.g['expected_admin_directory_names'][c['directory_root']][str(path)]
                facts={**facts,'independent_directory_state':capture(path),'independent_names':observed,'independent_error':error,'externally_bound_expected_names':expected,'independent_refused':error is not None or observed!=expected}
        elif kind in ('BEFORE_ORIGINAL_RESTORE','AFTER_ORIGINAL_RESTORE'):
            facts={'actual_source':snapshot['source'],'actual_entry':snapshot['decoded_entries'],'actual_lock':snapshot['lock_probe']};edge=kind
        if edge is not None:
            self.recovery_causal_rows.setdefault(row['pid'],[]).append({'sequence':row['sequence'],'edge':edge,'facts':facts})
            write(self.out/('causal-%08d.json'%snapshot['sequence']),{'status':'SOURCE_BOUND_RAW_EVIDENCE_NOT_ACCEPTANCE','control':c['id'],'derivative':c['derivative'],'edge':edge,'facts':facts,'request_sequence':row['sequence'],'independent_snapshot':snapshot['sequence'],'surviving_guards':'original retain/quiet/parent/Popen/non-daemon and observer rendezvous remain explicit; first forbidden edge cannot be inferred from aggregate returncode'})
    def loop(self):
        while True:
            for path in sorted((self.work/'requests').glob('*.json')):
                if path.name in self.seen:continue
                raw=path.read_bytes();row=json.loads(raw)
                # Native child rows can arrive before launched.json publication.
                # Keep them unseen/uninterpreted until the source-bound launch
                # rendezvous authenticates this exact child contract. Original
                # native clocks remain untouched; no row/anchor is discarded.
                if path.name.startswith('child-')and row['pid']not in self.all_streams:continue
                self.seen.add(path.name)
                require(row['pid']==self.parent or row['pid'] in self.child_pids or path.name.startswith('child-'+str(row['pid'])+'-'),'request principal differs')
                snapshot=self.snapshot({'path':str(path),'sha256':digest(raw),'raw_base64':base64.b64encode(raw).decode()})
                try:
                    if path.name.startswith('child-'):
                        if row['kind'].startswith('RECOVERY_'):
                            self.recovery_child(path,row,snapshot)
                        elif row['kind']in('ACTUAL_STREAM_OWNER_OPENED','IO_BEFORE_NATIVE_SYSCALL'):
                            contract=self.bind_child(row['config_path'],row['pid']);self.admit_io(path,row,contract,snapshot)
                        else:self.child_control(row,snapshot);self.judge_source_edge(row,snapshot)
                    else:
                        require(row['file'] in (self.g['driver_path'],self.plan['journal_helper']),'parent source path differs')
                        require(row['source_sha256']==(self.g['driver_sha256'] if row['file']==self.g['driver_path'] else self.plan['journal_sha256']),'actual unchanged original source hash differs')
                        require(digest(Path(self.plan['journal_helper']).read_bytes())==self.plan['journal_sha256'],'original journal source changed')
                        self.frame_edges.append(row)
                        if row['kind'].startswith('RECOVERY_')or row['kind']in('BEFORE_ORIGINAL_FAILED_RECOVERY_RESTORE','AFTER_ORIGINAL_FAILED_RECOVERY_RESTORE'):
                            self.recovery_parent(path,row,snapshot);continue
                        if row['kind']=='ACTUAL_CHILD_LAUNCH_BOUNDARY':
                            extra=row['extra'];contract=self.bind_child(extra['config_path'],extra['pid'],extra)
                            write(path.with_suffix('.ack'),{'status':'INDEPENDENT_SNAPSHOT_DURABLE','request_sha256':digest(raw),'contract':contract,'observer_pid':os.getpid()})
                        self.judge_source_edge(row,snapshot)
                        self.gate(path,row,snapshot)
                except BaseException as exc:
                    # Preserve failed observation; no ACK and no elapsed release.
                    self.quarantine=True
                    write(self.out/('failure-%08d.json'%snapshot['sequence']),{'native':OBS_NATIVE.capture(sys._getframe(),sys.exc_info()),'request':row,'held_original_seed':self.seed_active})
            if (self.work/'harness-returned.json').exists():
                terminal=self.snapshot({'kind':'independent_terminal'})
                require(not self.seed_active and terminal['decoded_entries']==[],'returned driver cannot certify restoration')
                require(all(terminal['source'].get(k)==self.plan['proxy_state'][k] for k in ('mode','mtime_ns','sha256')),'independent terminal source state differs')
                require(self.all_streams,'no actual independently bound child cohort')
                if self.failed_recovery:
                    require(self.recovery_restore_admitted is not None,'failed terminal lacks separate original restore disposition')
                    for contract in list(self.all_streams.values()):
                        if contract['pid']not in self.recovery_child_final:
                            fresh=self.bind_child(contract['config_path'],contract['pid'],require_active_seed=False);complete_stream(self.plan,fresh)
                    write(self.out/'FAILED_UNQUALIFIED_TERMINAL.evidence',{'physical_source_restoration':terminal,'original_failure_history_preserved':True,'ordinary_quiet':False,'scientific_qualification':False,'dependents_stopped':True})
                else:
                    for contract in list(self.all_streams.values()):
                        fresh=self.bind_child(contract['config_path'],contract['pid'],require_active_seed=False);complete_stream(self.plan,fresh)
                write(self.work/'independent-terminal.json',{'raw_snapshot':terminal['sequence'],'failed_observations_preserved':self.quarantine,'quiet_from_driver_selfreport':False})
                return
            # A dead parent is an observation fault, never a release/quiet proof.
            if not alive(self.parent):
                self.snapshot({'kind':'OWNER_ABSENT_QUARANTINE_NO_DRAIN_PROOF'});self.quarantine=True
            time.sleep(.05)

if __name__=='__main__':
    require(len(sys.argv)==4,'usage: independent-journal-observer.py SEPARATE_ROOT_AUTHORITY EXTERNAL_RAW_SHA256 HARNESS_OUTPUT')
    IndependentJournalObserver(*sys.argv[1:]).loop()
