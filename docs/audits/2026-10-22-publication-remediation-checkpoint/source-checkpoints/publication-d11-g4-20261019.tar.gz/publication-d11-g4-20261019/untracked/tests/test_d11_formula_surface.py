"""D11 finite numerical/source-model controls; no new kernel/physical proof.

Original D11/D12 tests remain unchanged. Local interval references and exact
rational arithmetic are independent of the canonical functions being checked.
Precision and budgets are fixed by the accepted corrected design.
"""
from fractions import Fraction as Q
import math
import numpy as np
import pytest
from mpmath.ctx_iv import MPIntervalContext
from mpmath.ctx_mp import MPContext
from mpmath.libmp import to_rational
from src.core import formulas as F
from src.core import visualizations as V

U=Q(1,2**53)
RHO=Q(1,2**100)
PRECISIONS=(192,384,768,1536)
def gamma(n):
    return n*U/(1-n*U)
def exact(x):
    return Q(int(x.numerator),int(x.denominator)) if isinstance(x,Q) else Q.from_float(float(x))
def bounds(x):
    return tuple(Q(*to_rational(a)) for a in x._mpi_)
def iv(c,x):
    x=exact(x)
    return c.mpf(x.numerator)/x.denominator
def dyad(c,x):
    q=Q(*to_rational(x._mpf_))
    return iv(c,q)
def conj(c,z):
    return c.mpc(z.real,-z.imag)
def mag2(z):
    return z.real**2+z.imag**2
def upper(x):
    return bounds(x)[1]
# Independent elementary reference: direct rational powers/Taylor coefficients,
# separately organized from the production recurrence; no candidate helper calls.
from functools import lru_cache

@lru_cache(None)
def _reference_pi(bits):
    J=2*bits+64; h=bits+32
    def atan_small(q):
        lower=upper=Q(0); quantum=Q(1,1<<h)
        for j in range(J):
            t=q**(2*j+1)/Q(2*j+1)
            n=(t.numerator<<h)//t.denominator
            a=n*quantum; b=(n+1)*quantum
            lower,upper=(lower+a,upper+b) if j%2==0 else (lower-b,upper-a)
        r=q**(2*J+1)/Q(2*J+1)
        return (lower,upper+r) if J%2==0 else (lower-r,upper)
    a,b=atan_small(Q(1,5)),atan_small(Q(1,239))
    return 16*a[0]-4*b[1],16*a[1]-4*b[0]

@lru_cache(None)
def _reference_coefficients(M):
    return tuple(Q((-1)**j,math.factorial(2*j)) for j in range(M)),tuple(Q((-1)**j,math.factorial(2*j+1)) for j in range(M))

def oracle_context(bits=53):
    c=MPIntervalContext();c.prec=bits
    # Directed conversion remains a basic-operation trust premise, independently
    # checked below. These exact pi endpoints have an independent analytic bound.
    pl,pu=_reference_pi(bits)
    c.pi=c.mpf([iv(c,pl),iv(c,pu)])
    def trig(x,want_sine):
        xl,xu=bounds(x)
        a,b=(2*xl/pu,2*xu/pl) if xl>=0 else ((2*xl/pl,2*xu/pu) if xu<=0 else (2*xl/pl,2*xu/pl))
        midpoint=(a+b)/2+Q(1,2); k=midpoint.numerator//midpoint.denominator
        if not Q(2*k-1,2)<=a<=b<=Q(2*k+1,2):
            raise ArithmeticError("independent quadrant unresolved")
        offset=(k*pl/2,k*pu/2) if k>=0 else (k*pu/2,k*pl/2)
        lo,hi=max(xl-offset[1],-pu/4),min(xu-offset[0],pu/4)
        z=c.mpf([iv(c,lo),iv(c,hi)]); w=z*z
        # Independent fixed term rule; (2M)! >= M^M. At every fixed
        # reference precision this is much smaller than 2^-(bits+64).
        # Actual exact factorial remainder, not the coarser production bound.
        M=bits//4+32; coscoef,sinccoef=_reference_coefficients(M)
        def horner(coeff):
            v=iv(c,coeff[-1])
            for q in reversed(coeff[:-1]):v=v*w+iv(c,q)
            return v
        re=Q(1,math.factorial(2*M))
        cs=horner(coscoef)+c.mpf([-iv(c,re),iv(c,re)])
        # Independent exact range intersection: near zero a valid Taylor box
        # may extend above1, although the true real cosine cannot.
        cl,cu=bounds(cs);cs=c.mpf([iv(c,max(cl,Q(-1))),iv(c,min(cu,Q(1)))])
        sn=horner(sinccoef)+c.mpf([-iv(c,re),iv(c,re)])
        sl,su=bounds(sn);sn=c.mpf([iv(c,max(sl,Q(5,6))),iv(c,min(su,Q(1)))])
        ss=z*sn
        co,si=((cs,ss),(-ss,cs),(-cs,-ss),(ss,-cs))[k%4]
        return si if want_sine else co
    c.sin=lambda x:trig(x,True)
    c.cos=lambda x:trig(x,False)
    return c

def reference(fn,scale,budget):
    previous=None
    for bits in PRECISIONS:
        c=oracle_context(bits)
        interval=fn(c);lo,hi=bounds(interval)
        if scale==0:
            assert lo==hi==0
            return lo,hi
        target=min(RHO*scale,budget/64)
        if previous is not None:
            a,b=previous
            if max(a,lo)<=min(b,hi) and hi-lo<=b-a and hi-lo<=target and b-a<=target:
                return lo,hi
        previous=lo,hi
    raise ArithmeticError("independent reference UNRESOLVED at fixed precision schedule")
def compare(value,fn,scale,coefficient=128,budget=None):
    scale=abs(exact(scale));B=gamma(coefficient)*scale if budget is None else budget
    lo,hi=reference(fn,scale,B)
    x=exact(value)
    error=max(abs(x-lo),abs(x-hi))
    assert error<=B, (value,float(error),float(B))
    return error,B
def hermitian_reference(model,scale,budget):
    """eighe is only a dyadic proposal, certified with outward R and Gram."""
    previous=None
    for bits in PRECISIONS:
        mp=MPContext();mp.prec=bits
        ci=oracle_context(bits)
        h=mp.matrix(model(mp));hi=model(ci)
        lam,q=mp.eighe(h)
        n=len(hi);qq=[[ci.mpc(dyad(ci,q[i,j].real),dyad(ci,q[i,j].imag)) for j in range(n)] for i in range(n)]
        ll=[dyad(ci,lam[j]) for j in range(n)]
        r2=ci.mpf(0);g2=ci.mpf(0);h2=ci.mpf(0)
        for i in range(n):
            for j in range(n):
                r=sum((hi[i][k]*qq[k][j] for k in range(n)),ci.mpc(0))-qq[i][j]*ll[j]
                g=sum((conj(ci,qq[k][i])*qq[k][j] for k in range(n)),ci.mpc(0))-(1 if i==j else 0)
                r2+=mag2(r);g2+=mag2(g);h2+=mag2(hi[i][j])
        eta=upper(ci.sqrt(g2));assert eta<1
        eps=upper(ci.sqrt(r2))+eta*(upper(ci.sqrt(h2))+max(abs(Q(*to_rational(lam[j]._mpf_))) for j in range(n)))
        target=min(RHO*scale,budget/64)
        intervals=[(Q(*to_rational(lam[j]._mpf_))-eps,Q(*to_rational(lam[j]._mpf_))+eps) for j in range(n)]
        if previous is not None:
            old,oe=previous
            if eta<=RHO and eps<=target and oe<=target and eps<=oe and all(max(a,c)<=min(b,d) for (a,b),(c,d) in zip(old,intervals)):
                return intervals
        previous=intervals,eps
    raise ArithmeticError("Hermitian residual reference UNRESOLVED")
def cv(c,x):
    # MPContext and MPIntervalContext both interpret finite binary floats exactly.
    q=exact(x)
    return c.mpf(q.numerator)/q.denominator
def diatomic_matrix(c,m1,m2,spring,k,a):
    m1,m2,spring,k,a=(cv(c,x) for x in (m1,m2,spring,k,a))
    z=-(spring/c.sqrt(m1*m2))*(1+(c.exp(c.j*k*a) if isinstance(c,MPContext) else c.mpc(c.cos(k*a),c.sin(k*a))))
    return [[c.mpc(2*spring/m1),z],[c.conj(z) if isinstance(c,MPContext) else conj(c,z),c.mpc(2*spring/m2)]]
def check_diatomic(m1,m2,spring,k,a):
    model=lambda c:diatomic_matrix(c,m1,m2,spring,k,a)
    ci=oracle_context(384);h=model(ci)
    scale=max(sum(upper(ci.sqrt(mag2(x))) for x in row) for row in h)
    B=gamma(256)*scale
    refs=hermitian_reference(model,scale,B)
    actual=F.diatomic_branches(m1,m2,spring,k,a)
    for x,(lo,hi) in zip(actual,refs):
        assert max(abs(exact(x)-lo),abs(exact(x)-hi))<=B
    H=np.array([[complex(x) for x in row] for row in model(MPContext())])
    vals,vec=np.linalg.eigh(H)
    for val,v in zip(vals,vec.T):
        assert np.linalg.norm(H@v-val*v)<=float(gamma(1024))*(np.linalg.norm(H,np.inf)+abs(val))*np.linalg.norm(v)
    assert np.linalg.norm(vec.conj().T@vec-np.eye(2))<=float(gamma(1024))

def test_all_original_and_near_degenerate_diatomic_matrix_families():
    for m1,m2,spring,a in [(1,2,1,1),(2,3,4,.5),(1,1,2,2)]:
        for k in (0,math.pi,-math.pi,math.pi/2,-math.pi/2,math.pi/3,-math.pi/3,
                  math.pi+2**-26,math.pi-2**-26,math.pi+2**-40,math.pi-2**-40):
            check_diatomic(m1,m2,spring,k,a)
    assert F.phononic_gap_edges()==(1.,2.)
    assert F.phononic_gap_rational_enclosure()==(1.,1.41)
    assert 141**2<2*100**2<142**2
    for args in [(0,2,1,0,1),(1,-1,1,0,1),(1,2,0,0,1),(1,2,1,0,0),(1,2,1,float("nan"),1)]:
        with pytest.raises((ValueError,ArithmeticError)):F.diatomic_branches(*args)

def check_pt(g,real=None,imag=None):
    gq=exact(g);rp=gamma(128)*(1+gq*gq)
    ci=oracle_context(384)
    r=upper(ci.sqrt(abs(1-iv(ci,gq)**2)))
    budget=min(rp/r if r else upper(ci.sqrt(iv(ci,rp))),upper(ci.sqrt(iv(ci,rp))))+gamma(16)*max(Q(1),r)
    fn=lambda c:c.sqrt(abs(1-iv(c,gq)**2))
    if abs(gq)==1:
        assert F.pt_eigenvalue_splitting(g)==0
        H=np.array([[1j*g,1],[1,-1j*g]])
        assert np.array_equal(H@H,np.zeros((2,2))) and np.linalg.matrix_rank(H)==1 and np.any(H!=0)
    else:
        y=F.pt_eigenvalue_splitting(g)/2 if abs(gq)<1 else (imag if imag is not None else math.sqrt((abs(g)-1)*(abs(g)+1)))
        compare(y,fn,1+abs(gq),budget=budget)
        assert abs(exact(y)**2-abs(1-gq*gq))<=rp
    if real is not None and imag is not None:
        assert (imag==0 if abs(gq)<=1 else real==0)
        x=abs(real) if abs(gq)<=1 else abs(imag)
        if abs(gq)==1:assert x==0
        else:compare(x,fn,1+abs(gq),budget=budget)

def test_PT_complete_endpoint_and_signed_families():
    for g in [0,.25,.5,.9,1,-1]+[sgn*(1+side*2.**-b) for sgn in (-1,1) for side in (-1,1) for b in (20,40)]:
        check_pt(g)

def test_exact_mixing_absolute_means_and_singular_algebra():
    for h,i in [(1,4),(4,1),(2,2),(2,8),(-1,-4)]:
        for f in [Q(0),Q(1,4),Q(1,2),Q(2,3),Q(3,4),Q(1)]:
            den=i+2*h-f*(i-h);v=h*(i+2*h+2*f*(i-h))/den
            K=(abs(i)+2*abs(h)+abs(f)*abs(i-h))/abs(den)
            compare(F.maxwell_garnett(h,i,f),lambda c:iv(c,v),max(abs(h),abs(i)),budget=gamma(128)*max(abs(h),abs(i))*max(1,K)**2)
            d=(1-f)*i+f*h;vr=(1-f)*h+f*i;rr=Q(h*i)/d;gap=f*(1-f)*(h-i)**2/d
            compare(F.voigt_modulus(h,i,f),lambda c:iv(c,vr),abs((1-f)*h)+abs(f*i),32)
            kd=(abs((1-f)*i)+abs(f*h))/abs(d)
            for fun,ref in [(F.reuss_modulus,rr),(F.voigt_reuss_gap,gap)]:
                compare(fun(h,i,f),lambda c:iv(c,ref),abs(ref),budget=gamma(128)*abs(ref)*max(1,kd))
    assert F.voigt_modulus(1,4,Q(2,3))==3 and F.reuss_modulus(1,4,Q(2,3))==2
    with pytest.raises(ValueError):F.reuss_modulus(1,-1,Q(1,2))
    with pytest.raises(ValueError):F.maxwell_garnett(1,-2,0)
    assert F.maxwell_garnett(1,4,.5)!=F.maxwell_garnett(4,1,.5)

def test_honeycomb_dirac_cones_units_and_primitive_family():
    angles=[0,math.pi,2*math.pi/3,4*math.pi/3]+[2*math.pi*j/n for n in (4,5,7) for j in range(n)]
    for a in angles:
        for fun,ref in [(math.sin,lambda c:c.sin(iv(c,a))),(math.cos,lambda c:c.cos(iv(c,a)))]:
            compare(fun(a),ref,1,budget=8*U)
    for a,b in [(0,0),(math.pi,0),(2*math.pi/3,4*math.pi/3),(4*math.pi/3,2*math.pi/3),(.3,-.7)]:
        z=F.honeycomb_structure_factor(a,b)
        compare(z.real,lambda c:1+c.cos(iv(c,a))+c.cos(iv(c,b)),3,128)
        compare(z.imag,lambda c:c.sin(iv(c,a))+c.sin(iv(c,b)),3,128)
        compare(F.haldane_nnn(a,b),lambda c:c.sin(iv(c,a))+c.sin(iv(c,b)-iv(c,a))-c.sin(iv(c,b)),3,128)
    qs=[(0,0),(1,0),(1,1),(-1,2)]+[(sgn*2.**-10,0) for sgn in(-1,1)]+[(0,sgn*2.**-10) for sgn in(-1,1)]+[(a*2.**-30,b*2.**-30) for a in(-1,1) for b in(-1,1)]
    for a,b in qs:
        compare(F.dirac_linear_form_norm(a,b),lambda c:c.sqrt(iv(c,a)**2-iv(c,a)*iv(c,b)+iv(c,b)**2),abs(a)+abs(b),128)
    for t,a,h in [(1,1,1),(2,1,1),(1,2,1),(1,1,2),(1,1,-1),(0,1,1)]:
        r=3*exact(t)*exact(a)/(2*exact(h))
        compare(F.fermi_velocity(t,a,h),lambda c:iv(c,r),abs(r),32)
    from src.core.constants import HBAR,E_CHARGE
    t=2.7*E_CHARGE;a=1.42e-10
    r=3*exact(t)*exact(a)/(2*exact(HBAR))
    compare(F.fermi_velocity(t,a,HBAR),lambda c:iv(c,r),abs(r),32)
    assert not math.isclose(F.fermi_velocity(2.7,a,HBAR),float(r),rel_tol=1e-6)

def test_safe_angle_boxes_and_real_public_FHS_receipts():
    c=oracle_context(192)
    boxes=[((-1,1),(0,0),"AMBIGUOUS_REAL_SIGN"),((1,2),(0,0),"USABLE"),((-2,-1),(0,0),"USABLE"),((0,0),(0,0),"ZERO_BOX"),
           ((-1,1),(-1,1),"ORIGIN_BOX"),((-2,-1),(-1,0),"CUT_BOX"),((-2,-1),(0,1),"USABLE"),((-2,-1),(-1,1),"CUT_BOX"),
           ((0,0),(1,2),"USABLE"),((0,0),(-2,-1),"USABLE"),((1,2),(1,2),"USABLE")]
    for x,y,status in boxes:
        a,s=F._d11_safe_arg(c,c.mpf(list(x)),c.mpf(list(y)));assert s==status
        if status=="AMBIGUOUS_REAL_SIGN":
            lo,hi=bounds(a);assert lo<=0 and hi>=bounds(c.pi)[1]
    assert F.haldane_lattice_chern(1,4,0,0)==0
    for n in (4,5,7):
        r=F._d11_fhs_certificate(1,n,1,1,None)
        assert r["chern"]==-1 and len(r["angle_statuses"])==n*n and all(s=="USABLE" for s in r["angle_statuses"])
    assert [F.haldane_lattice_chern(m) for m in (1,5,6)]==[-1,0,0]
    for n in (True,4.,1,3,6,9,12):
        with pytest.raises(ValueError):F.haldane_lattice_chern(1,n)
    with pytest.raises(ValueError):F.haldane_lattice_chern(-1,4,0,0)
    with pytest.raises(ValueError,match="overlap"):F.haldane_lattice_chern(0,2,1,0)

def test_exact_nondyadic_and_default_flip_cover_and_error():
    for bracket,tol in [((0,8),Q(1,10**12)),((Q(1,3),Q(19,3)),Q(1,10**10))]:
        r=F._d11_flip_certificate(bracket=bracket,tol=tol)
        assert abs(r["value"]-3.3177)<5e-5 and r["error"]<=tol
        lo,hi=r["interval"];leaves=r["leaves"]
        assert leaves[0][0]==lo and leaves[-1][1]==hi and all(a[1]==b[0] for a,b in zip(leaves,leaves[1:]))
        assert all(x["minimum_margin"]>0 for _,_,x in leaves)
        assert r["work"]["used"]<=r["work"]["limit"]
        for attempt in r["point_receipts"]:
            assert attempt["schedule"]==r["schedule"]
            assert 0<attempt["used_after"]-attempt["used_before"]<=4*4**2*len(r["schedule"])
        assert all(leaf[2]["schedule"]==r["schedule"] for leaf in leaves)
        assert tuple(independent_wilson(q,4) for q in (lo,hi))==r["endpoint_chern"]
        for k,j,q in r["generated"]:
            assert q==exact(bracket[0])+Q(k,2**j)*(exact(bracket[1])-exact(bracket[0]))
            assert max(abs(q.numerator).bit_length(),q.denominator.bit_length())<=r["Bstar"]
    with pytest.raises(ValueError,match="does not straddle"):F.haldane_flip_location(bracket=(6,8))
    with pytest.raises(ValueError):F.haldane_flip_location(tol=0)


def _full_xy(trace, n, grid=None):
    assert trace.x is not None and trace.y is not None
    assert len(trace.x)==len(trace.y)==n
    if grid is not None:
        assert len(grid)==n and np.array_equal(np.asarray(trace.x),np.asarray(grid))

def _annotations(fig):
    return [(a.text,a.x,a.y,a.xref,a.yref) for a in fig.layout.annotations]

def _effective_display(obj, template, path, default):
    # Inspect original returned-object properties, then their template/default.
    def read(parent):
        for part in path.split('.'):
            parent=getattr(parent,part,None)
            if parent is None:return None
        return parent
    value=read(obj)
    if value is None:value=read(template)
    return default if value is None else value


def _positive_display(value):
    values=np.atleast_1d(value)
    assert values.size and all(math.isfinite(float(v)) and float(v)>0 for v in values.flat)


def _paint_exposed(value):
    # The original finite figures use named/hex or rgba paint. Color choice is
    # cosmetic; zero alpha removes the promised curve/marker/filled region.
    import re
    for color in np.atleast_1d(value).flat:
        if color is None:continue  # normal Plotly palette/default paint
        if isinstance(color,str):
            assert color.strip().lower()!='transparent'
            rgba=re.fullmatch(r'rgba\([^,]+,[^,]+,[^,]+,\s*([^,)]+)\)',color.strip(),re.I)
            if rgba:_positive_display(float(rgba.group(1)))


def _text_paint_exposed(fig, *sources):
    # Specific local/template role paint precedes the general layout font.
    # None is ordinary inheritance, not evidence that scientific words vanished.
    for obj,path in (*sources,(fig.layout,'font.color'),
                     (fig.layout.template.layout,'font.color')):
        color=_effective_display(obj,None,path,None)
        if color is not None:
            _paint_exposed(color)
            return


def _axis_template(fig, name):
    # Plotly selects the full numbered container before the generic one; it
    # does not merge unspecified properties of a present numbered container.
    layout=fig.layout.template.layout
    selected=name if name in layout.to_plotly_json() else name[0]+'axis'
    return getattr(layout,selected,None)


def _panel_axes(fig, spacing=None):
    # Independent original single/two-panel geometry, not just trace axis IDs.
    panels=[('xaxis','yaxis',(0.,1.))] if spacing is None else [
        ('xaxis','yaxis',(0.,(1-spacing)/2)),
        ('xaxis2','yaxis2',((1+spacing)/2,1.))]
    for xn,yn,xdomain in panels:
        for name,domain,anchor in [(xn,xdomain,yn.replace('axis','')),
                                    (yn,(0.,1.),xn.replace('axis',''))]:
            axis=getattr(fig.layout,name)
            template=_axis_template(fig,name)
            get=lambda prop,default:_effective_display(axis,template,prop,default)
            assert tuple(get('domain',(0.,1.)))==domain
            assert get('anchor',anchor)==anchor
            assert get('visible',True) is True
            assert get('type','linear')=='linear'
            assert get('overlaying',None) is None and get('matches',None) is None
            assert get('scaleanchor',None) is None
            interval=get('range',None)
            if interval is None:
                assert get('autorange',True) is True
            else:
                assert len(interval)==2 and all(math.isfinite(float(v)) for v in interval)
                assert interval[0]<interval[1]


def _scientific_trace_in_panel(fig, trace):
    # The sole off-axis proxy is independently pinned by _complete_fig3 and is
    # excluded only at that explicit call site, never by arbitrary meta text.
    for coordinate,ref in [(trace.x,trace.xaxis or 'x'),(trace.y,trace.yaxis or 'y')]:
        name=ref[0]+'axis'+ref[1:]
        axis=getattr(fig.layout,name)
        template=_axis_template(fig,name)
        interval=_effective_display(axis,template,'range',None)
        if interval is not None:
            assert all(interval[0]<=v<=interval[1] for v in coordinate)


def _required_legends(fig, indices):
    templates=fig.layout.template.data.scatter
    template=templates[0] if templates else None
    assert _effective_display(fig.layout,fig.layout.template.layout,'showlegend',True) is True
    _text_paint_exposed(fig,(fig.layout.legend,'font.color'),
                        (fig.layout.template.layout.legend,'font.color'))
    for i in indices:
        assert fig.data[i].name
        assert _effective_display(fig.data[i],template,'showlegend',True) is True


def _visible_display(fig):
    # Bounded original D6 exposure, not a universal style/pixel evaluator.
    templates=fig.layout.template.data.scatter
    template=templates[0] if templates else None
    _text_paint_exposed(fig,(fig.layout.title,'font.color'),
                        (fig.layout.template.layout.title,'font.color'))
    for index,t in enumerate(fig.data):
        get=lambda prop,default:_effective_display(t,template,prop,default)
        assert get('visible',True) is True
        _positive_display(get('opacity',1))
        mode=t.mode or ''
        if 'lines' in mode:
            _positive_display(get('line.width',2))
            _paint_exposed(get('line.color',None))
        if 'markers' in mode:
            _positive_display(get('marker.size',6))
            _positive_display(get('marker.opacity',1))
            _paint_exposed(get('marker.color',None))
        if t.fill=='toself':_paint_exposed(get('fillcolor',None))
        if 'text' in mode:
            text_template=templates[index%len(templates)] if templates else None
            _text_paint_exposed(fig,(t,'textfont.color'),
                                (text_template,'textfont.color'))
    for a in fig.layout.annotations:
        template_a=fig.layout.template.layout.annotationdefaults
        assert _effective_display(a,template_a,'visible',True) is True
        _positive_display(_effective_display(a,template_a,'opacity',1))
        assert a.clicktoshow in (None,False)
        _text_paint_exposed(fig,(a,'font.color'),
                            (fig.layout.annotationdefaults,'font.color'),
                            (template_a,'font.color'))
    for shape in fig.layout.shapes:
        template_s=fig.layout.template.layout.shapedefaults
        get=lambda prop,default:_effective_display(shape,template_s,prop,default)
        assert get('visible',True) is True
        _positive_display(get('opacity',1))
        if shape.type=='rect':_paint_exposed(get('fillcolor','rgba(0,0,0,0)'))
        elif shape.type=='line':
            _positive_display(get('line.width',2))
            _paint_exposed(get('line.color',None))
    for name in ('xaxis','yaxis','xaxis2','yaxis2'):
        axis=getattr(fig.layout,name,None)
        assert axis is None or axis.visible is not False
        if axis is not None:
            axis_template=_axis_template(fig,name)
            assert _effective_display(axis,axis_template,'showticklabels',True) is True
            for role in ('title.font.color','tickfont.color'):
                _text_paint_exposed(fig,(axis,role),(axis_template,role),
                                    (axis,'color'),(axis_template,'color'))


def _complete_fig1(fig):
    assert len(fig.data)==4
    _panel_axes(fig)
    _required_legends(fig,range(4))
    for trace in fig.data:_scientific_trace_in_panel(fig,trace)
    for t in fig.data[:2]:_full_xy(t,801,np.linspace(-math.pi,math.pi,801))
    for t,y,symbol in [(fig.data[2],1,'diamond'),(fig.data[3],2,'diamond-open')]:
        _full_xy(t,2,[-math.pi,math.pi]);assert list(t.y)==[y,y] and t.marker.symbol==symbol
    assert [t.name for t in fig.data]==[
        "optical branch  ω²₊", "acoustic branch  ω²₋",
        "ω²₋(±π) = 1  (lower edge attained)",
        "ω²₊(±π) = 2  (upper edge attained)"]
    assert [t.mode for t in fig.data]==['lines','lines','markers','markers']
    assert all((t.xaxis or 'x',t.yaxis or 'y')==('x','y') for t in fig.data)
    _visible_display(fig)
    assert fig.layout.title.text=="Certified phononic band gap — diatomic chain (m₁, m₂, κ, a) = (1, 2, 1, 1)"
    assert len(fig.layout.shapes)==1
    rect=fig.layout.shapes[0]
    assert (rect.type,rect.x0,rect.x1,rect.xref,rect.yref)==('rect',0,1,'x domain','y')
    assert _annotations(fig)==[
        ("certified gap  ω² ∈ (1, 2)  — no state here",0,2.,'x domain','y'),
        ("rational inner bracket in ω:  1 &lt; 141/100 ≤ √2<br>(norm_num, no floating point)",0.,1.5,'x','y')]
    assert list(fig.layout.xaxis.tickvals)==[-math.pi,-math.pi/2,0,math.pi/2,math.pi]
    assert list(fig.layout.xaxis.ticktext)==["−π","−π/2","0","π/2","π"]
    assert any(s.y0==1 and s.y1==2 and s.xref=='x domain' for s in fig.layout.shapes)
    text="rational inner bracket in ω:  1 &lt; 141/100 ≤ √2<br>(norm_num, no floating point)"
    assert (text,0.,1.5,'x','y') in _annotations(fig)
    assert any('no state here' in a.text for a in fig.layout.annotations)
    assert fig.layout.xaxis.title.text=="Bloch wavevector  k a  (dimensionless)"
    assert fig.layout.yaxis.title.text=="squared frequency  ω²  (units of κ/m₁)"

def _complete_fig2(fig):
    assert len(fig.data)==5
    _panel_axes(fig)
    _required_legends(fig,range(5))
    for trace in fig.data:_scientific_trace_in_panel(fig,trace)
    _visible_display(fig)
    assert fig.layout.title.text=="PT transition and the order-2 exceptional point"
    assert [t.name for t in fig.data]==[
        "Re λ = +√(1−g²)", "Re λ = −√(1−g²)",
        "Im λ = +√(g²−1)  (PT-broken)", "Im λ = −√(g²−1)",
        "EP2 at g = 1  (defective, Δ = 0)"]
    assert [t.mode for t in fig.data]==['lines']*4+['markers']
    assert all((t.xaxis or 'x',t.yaxis or 'y')==('x','y') for t in fig.data)
    assert len(fig.layout.annotations)==2 and len(fig.layout.shapes)==2
    assert _annotations(fig)[0]==("PT-unbroken — spectrum real",0.,1,'x','y domain')
    for shape in fig.layout.shapes:
        assert (shape.xref,shape.yref,shape.y0,shape.y1)==('x','y domain',0,1)
    for t in fig.data[:2]:_full_xy(t,500,np.linspace(0,1,500))
    for t in fig.data[2:4]:_full_xy(t,300,np.linspace(1,1.6,300))
    _full_xy(fig.data[4],1,[1.]);assert list(fig.data[4].y)==[0.]
    assert fig.data[4].name=="EP2 at g = 1  (defective, Δ = 0)"
    assert fig.data[4].marker.symbol=='x'
    assert any(s.x0==0 and s.x1==1 and s.xref=='x' for s in fig.layout.shapes)
    line=[s for s in fig.layout.shapes if s.type=='line']
    assert len(line)==1 and line[0].x0==line[0].x1
    compare(line[0].x0,lambda c:c.sqrt(iv(c,Q(99,100))),1,32)
    assert any(a.text=="g² = 99/100 ⟹ Δ ≤ 1/5 (tight)" and a.x==line[0].x0 and a.xref=='x' and a.yref=='y domain' for a in fig.layout.annotations)
    assert fig.layout.xaxis.title.text=="non-Hermiticity  g  (dimensionless)"
    assert fig.layout.yaxis.title.text=="eigenvalue λ  (units of the hopping scale)"

def _complete_fig3(fig):
    assert len(fig.data)==6
    _panel_axes(fig,.13)
    _required_legends(fig,(0,1,2))
    for i in (0,1,3,4,5):_scientific_trace_in_panel(fig,fig.data[i])
    _visible_display(fig)
    assert fig.layout.title.text=="Haldane Chern witness — mass inversion is NOT sufficient at fixed N"
    assert [t.name for t in fig.data[:2]]==[
        "gap at K  = 2|m − 3√3 t₂ sin φ|", "gap at K′ = 2|m + 3√3 t₂ sin φ|"]
    assert all((t.xaxis,t.yaxis,t.mode)==('x','y','lines') for t in fig.data[:2])
    assert (fig.data[2].xaxis,fig.data[2].yaxis,fig.data[2].mode,fig.data[2].marker.symbol)==('x2','y2','markers','square')
    assert len(fig.layout.annotations)==4 and len(fig.layout.shapes)==3
    assert _annotations(fig)[:2]==[
        ("(left) Dirac-point gaps, t₂ = 1, φ = π/2",.2175,1.,'paper','paper'),
        ("(right) certified C, t = t₂ = 1, φ = π/2, 4×4 torus",.7825,1.,'paper','paper')]
    analytic=fig.layout.annotations[2]
    assert (analytic.text,analytic.x,analytic.xref,analytic.yref)==(
        "analytic inversion window  |m| &lt; 3√3 ≈ 5.196",0.,'x','y')
    compare(analytic.y,lambda c:iv(c,.94)*2*(8+3*c.sqrt(3)*c.sin(iv(c,math.pi/2))),32,128)
    for t in fig.data[3:]:
        assert t.mode=='markers+text' and t.marker.symbol=='diamond' and t.name is None and t.showlegend is False
    for t in fig.data[:2]:_full_xy(t,600,np.linspace(-8,8,600))
    _full_xy(fig.data[2],1,[-999.]);assert list(fig.data[2].y)==[-999.]
    assert fig.data[2].meta==dict(role='display_only_legend_proxy')
    assert fig.data[2].name=="shaded: analytic inversion window |m| < 3√3"
    expected=[(1.,-1.,"m = 1:  C = −1"),(5.,0.,"m = 5:  C = 0<br>inside the window"),(6.,0.,"m = 6:  C = 0")]
    for t,(x,y,text) in zip(fig.data[3:],expected):
        _full_xy(t,1,[x]);assert list(t.y)==[y] and list(t.text)==[text]
        assert t.xaxis=='x2' and t.yaxis=='y2'
    rects=[s for s in fig.layout.shapes if s.type=='rect']
    assert len(rects)==2 and {s.xref for s in rects}=={'x','x2'}
    for s in rects:
        assert s.yref==('y domain' if s.xref=='x' else 'y2 domain') and (s.y0,s.y1)==(0,1)
        assert s.x0==-s.x1
        compare(s.x1,lambda c:3*c.sqrt(3)*c.sin(iv(c,math.pi/2)),6,128)
    receipt=fig.layout.meta['d11_flip']
    assert receipt['scope']=='finite numerical; not Lean-certified'
    assert tuple(receipt['endpoint_chern'])==(-1,0)
    lo,hi=map(Q,receipt['interval']);err=Q(receipt['error']);tol=Q(receipt['tolerance'])
    assert lo<hi and err<=tol==Q(1,10**12)
    assert err==(hi-lo)/2+abs(exact(receipt['value'])-(lo+hi)/2)
    leaves=receipt['cover_leaves'];assert leaves
    assert Q(leaves[0]['lo'])==lo and Q(leaves[-1]['hi'])==hi
    assert all(Q(a['hi'])==Q(b['lo']) for a,b in zip(leaves,leaves[1:]))
    assert all(Q(x['minimum_margin'])>0 for x in leaves)
    assert receipt['work']['used']<=receipt['work']['limit']
    assert receipt['schedule'][0]==128
    lines=[s for s in fig.layout.shapes if s.type=='line']
    assert len(lines)==1 and lines[0].xref=='x2' and lines[0].x0==lines[0].x1==receipt['value']
    assert (lines[0].yref,lines[0].y0,lines[0].y1)==('y2 domain',0,1)
    assert _annotations(fig)[3]==(f"4×4 invariant flips ≈ {receipt['value']:.4f}<br>(numerical, not certified)",receipt['value'],1,'x2','y2 domain')
    assert any(a.text==f"4×4 invariant flips ≈ {receipt['value']:.4f}<br>(numerical, not certified)" and a.x==receipt['value'] and a.xref=='x2' for a in fig.layout.annotations)
    assert fig.layout.xaxis.title.text==fig.layout.xaxis2.title.text=="Semenoff mass  m  (units of t)"
    assert fig.layout.yaxis.title.text=="Dirac gap (units of t)"
    assert fig.layout.yaxis2.title.text=="lattice Chern number  C"
    assert list(fig.layout.xaxis2.range)==[-.5,8.5] and list(fig.layout.yaxis2.range)==[-1.55,.75]

def _complete_fig4(fig):
    assert len(fig.data)==6
    _panel_axes(fig,.12)
    _required_legends(fig,(0,2,3,4,5))
    for trace in fig.data:_scientific_trace_in_panel(fig,trace)
    _visible_display(fig)
    assert fig.layout.title.text=="Algebraic effective-medium bounds (two-scale route deliberately not taken)"
    assert [t.name for t in fig.data]==[
        "(left) ε<sub>eff</sub>  (Maxwell–Garnett)", None,
        "(right) exact Voigt − Reuss gap", "(right) Voigt (iso-strain, arithmetic)",
        "(right) Reuss (iso-stress, harmonic)", "(right) f = 2/3: gap = 1 exactly"]
    assert [(t.xaxis,t.yaxis) for t in fig.data]==[('x','y')]*2+[('x2','y2')]*4
    assert [t.mode for t in fig.data]==['lines','markers+text',None,'lines','lines','lines+markers']
    assert fig.data[2].fill=='toself' and fig.data[2].hoverinfo=='skip'
    assert fig.data[1].marker.symbol==fig.data[5].marker.symbol=='diamond'
    assert fig.data[1].showlegend is False
    assert len(fig.layout.shapes)==1
    shape=fig.layout.shapes[0]
    assert (shape.type,shape.x0,shape.x1,shape.xref,shape.yref)==('rect',0,1,'x domain','y')
    assert _annotations(fig)==[
        ("(left) Maxwell–Garnett, ε<sub>h</sub> = 1, ε<sub>i</sub> = 4",.22,1.,'paper','paper'),
        ("(right) Voigt–Reuss, M₁ = 1, M₂ = 4",.78,1.,'paper','paper'),
        ("constituent bounds  ε<sub>h</sub> ≤ ε<sub>eff</sub> ≤ ε<sub>i</sub>  (non-strict)",.5,3.6,'x','y')]
    assert list(fig.layout.yaxis.range)==[.4,4.6]
    grid=np.linspace(0,1,400)
    for i in (0,3,4):_full_xy(fig.data[i],400,grid)
    _full_xy(fig.data[1],1,[.5]);assert list(fig.data[1].y)==[2.]
    assert list(fig.data[1].text)==["f = 1/2 ⟹ ε<sub>eff</sub> = 2 (certified)"]
    _full_xy(fig.data[2],800,list(grid)+list(grid[::-1]))
    assert list(fig.data[2].y)==list(fig.data[3].y)+list(fig.data[4].y)[::-1]
    _full_xy(fig.data[5],2,[2./3,2./3])
    for a,r in zip(fig.data[5].y,[2,3]):assert abs(exact(a)-r)<=gamma(128)*r
    assert fig.data[5].name=="(right) f = 2/3: gap = 1 exactly"
    assert any(s.y0==1 and s.y1==4 and s.xref=='x domain' for s in fig.layout.shapes)
    assert ("constituent bounds  ε<sub>h</sub> ≤ ε<sub>eff</sub> ≤ ε<sub>i</sub>  (non-strict)",.5,3.6,'x','y') in _annotations(fig)
    assert fig.layout.xaxis.title.text=="inclusion fill fraction  f  (dimensionless)"
    assert fig.layout.xaxis2.title.text=="phase-2 fill fraction  f  (dimensionless)"
    assert fig.layout.yaxis.title.text=="ε<sub>eff</sub>  (units of ε₀)"
    assert fig.layout.yaxis2.title.text=="modulus M  (units of M₁)"

def check_all_actual_figure_arrays_and_live_display_contract():
    fig=V.fig_d11_phononic_band_gap()
    _complete_fig1(fig)
    assert len(fig.data)==4
    for k,op,ac in zip(fig.data[0].x,fig.data[0].y,fig.data[1].y):
        check_diatomic(1,2,1,float(k),1)
        assert (ac,op)==F.diatomic_branches(1,2,1,float(k))
    assert len(fig.data[0].x)==801
    assert list(fig.data[2].y)==[1,1] and list(fig.data[3].y)==[2,2]
    assert any(a.text=="rational inner bracket in ω:  1 &lt; 141/100 ≤ √2<br>(norm_num, no floating point)" for a in fig.layout.annotations)
    assert any(x.y0==1 and x.y1==2 for x in fig.layout.shapes)
    pt=V.fig_d11_pt_exceptional_point();_complete_fig2(pt);assert [len(t.x) for t in pt.data]==[500,500,300,300,1]
    for g,y,yn in zip(pt.data[0].x,pt.data[0].y,pt.data[1].y):
        assert y==-yn and y>=0;check_pt(float(g),float(y),0)
    for g,y,yn in zip(pt.data[2].x,pt.data[2].y,pt.data[3].y):
        assert y==-yn and y>=0;check_pt(float(g),0,float(y))
    hf=V.fig_d11_haldane_chern()
    _complete_fig3(hf)
    assert len(hf.data[0].x)==len(hf.data[1].x)==600
    for m,a,b in zip(hf.data[0].x,hf.data[0].y,hf.data[1].y):
        shift=lambda c:3*c.sqrt(3)*c.sin(iv(c,math.pi/2))
        scale=abs(exact(m))+6
        for val,sgn in [(a,-1),(b,1)]:
            compare(val,lambda c:2*abs(iv(c,float(m))+sgn*shift(c)),2*scale,128)
    scientific=[t for t in hf.data if t.mode=="markers+text"]
    assert [list(t.y)[0] for t in scientific]==[-1,0,0]
    assert [F.haldane_lattice_chern(list(t.x)[0]) for t in scientific]==[-1,0,0]
    assert hf.data[2].meta["role"]=="display_only_legend_proxy"
    assert hf.layout.meta["d11_flip"]["scope"]=="finite numerical; not Lean-certified"
    ef=V.fig_d11_effective_medium();_complete_fig4(ef);assert len(ef.data[0].x)==400
    for f,mg in zip(ef.data[0].x,ef.data[0].y):
        fq=exact(f);r=(4+2+2*fq*3)/(4+2-fq*3)
        compare(mg,lambda c:iv(c,r),4,128)
    for f,v,r in zip(ef.data[3].x,ef.data[3].y,ef.data[4].y):
        fq=exact(f);compare(v,lambda c:iv(c,1+3*fq),1+3*fq,32);compare(r,lambda c:iv(c,Q(4)/(4-3*fq)),Q(4)/(4-3*fq),128)
    assert list(ef.data[2].y)==list(ef.data[3].y)+list(ef.data[4].y)[::-1]
    assert np.allclose(ef.data[5].y,[2,3],rtol=0,atol=1e-12)

def bernal_model(c,u,g,f):
    u,g,f=cv(c,u),cv(c,g),c.mpc(cv(c,f.real),cv(c,f.imag))
    fc=c.conj(f) if isinstance(c,MPContext) else conj(c,f)
    z=c.mpc(0)
    return [[c.mpc(u),f,z,z],[fc,c.mpc(u),c.mpc(g),z],
            [z,c.mpc(g),c.mpc(-u),f],[z,z,fc,c.mpc(-u)]]

def test_Bernal_full_independent_Hermitian_minimum_and_chirality():
    for u,g in [(0,1),(.5,1),(1,2),(-.5,1),(.5,-1),(.5,0)]:
        uq,gq=exact(u),exact(g);den=gq*gq+4*uq*uq
        r=4*uq*uq*gq*gq/den
        compare(F.bernal_full_gap_sq(u,g),lambda c:iv(c,r),abs(r),128)
        xstar=2*uq*uq*(gq*gq+2*uq*uq)/den
        def model(c):
            f=c.sqrt(cv(c,xstar))
            # Direct actual four-band Hermitian model, both upper hoppings f.
            z=c.mpc(0);uu=cv(c,u);gg=cv(c,g)
            return [[c.mpc(uu),c.mpc(f),z,z],[c.mpc(f),c.mpc(uu),c.mpc(gg),z],
                    [z,c.mpc(gg),c.mpc(-uu),c.mpc(f)],[z,z,c.mpc(f),c.mpc(-uu)]]
        ci=oracle_context(384);h=model(ci)
        scale=max(sum(upper(ci.sqrt(mag2(x))) for x in row) for row in h)
        if r:
            # Much tighter spectral oracle is required to propagate the square.
            spec=hermitian_reference(model,scale,gamma(128)*r/64)
            lo,hi=spec[2];assert lo>0
            a,b=4*lo*lo,4*hi*hi
            assert b-a<=gamma(128)*r/64 and a<=r<=b
        else:
            # Exact zero eigenvalue of the specified matrix, not "small enough".
            if u==0:
                assert xstar==0
                H=np.array([[0,0,0,0],[0,0,g,0],[0,g,0,0],[0,0,0,0]],complex)
                v=np.array([1,0,0,0],complex)
                assert np.array_equal(H@v,np.zeros(4))
            else:
                assert g==0 and xstar==uq*uq
                H=np.array([[u,abs(u),0,0],[abs(u),u,0,0],[0,0,-u,abs(u)],[0,0,abs(u),-u]],complex)
                v=np.array([1,-math.copysign(1,u),0,0],complex)
                assert np.array_equal(H@v,np.zeros(4))
        H=np.array([[u,1j,0,0],[-1j,u,g,0],[0,g,-u,1j],[0,0,-1j,-u]],complex)
        assert np.array_equal(H,H.conj().T)
        swapped=H.copy();swapped[2,3]=-1j;swapped[3,2]=1j
        assert not np.array_equal(H,swapped)
        # Equal spectra are deliberately not our model-equality criterion.
        assert np.allclose(np.linalg.eigvalsh(H),np.linalg.eigvalsh(swapped),atol=1e-12,rtol=0)
        assert np.linalg.norm(H@np.array([0,0,0,1])-swapped@np.array([0,0,0,1]))==2
    with pytest.raises(ValueError):F.bernal_full_gap_sq(0,0)

def test_all_named_haldane_coefficients_signs_and_families():
    for m in (0,-1,1,5,6):
        for t2 in (0,.5,1,2,-1):
            for phi in (0,math.pi/6,-math.pi/6,math.pi/2,-math.pi/2):
                shift=lambda c:3*c.sqrt(3)*iv(c,t2)*c.sin(iv(c,phi))
                a,b=F.haldane_dirac_masses(m,t2,phi)
                S=abs(m)+6*abs(t2)
                compare(a,lambda c:iv(c,m)-shift(c),S,128)
                compare(b,lambda c:iv(c,m)+shift(c),S,128)
                compare(F.haldane_mass_inversion_window(t2,phi),lambda c:abs(shift(c)),6*abs(t2),128)
    # Explicitly supplied binary phi is a distinct admitted model input.
    exact_default=F._d11_fhs_certificate(1,4,1,1,None)
    explicit=F._d11_fhs_certificate(1,4,1,1,math.pi/2)
    assert exact_default["chern"]==explicit["chern"]==-1
    assert exact_default["schedule"]!=() and explicit["schedule"]!=()

def independent_wilson(m,n,t=1,t2=1):
    labels=[]
    for prec in PRECISIONS[:2]:
        c=MPContext();c.prec=prec;v={}
        for a in range(n):
            for b in range(n):
                x,y=2*c.pi*a/n,2*c.pi*b/n
                f=1+c.exp(c.j*x)+c.exp(c.j*y)
                z=cv(c,m)-2*cv(c,t2)*(c.sin(x)+c.sin(y-x)-c.sin(y))
                # Independent Pauli Hermitian eigensystem, no north-gauge formula.
                H=c.matrix([[z,cv(c,t)*f],[cv(c,t)*c.conj(f),-z]])
                ev,Qm=c.eighe(H)
                v[a,b]=(Qm[0,0],Qm[1,0])
        def link(a,b,mu):
            aa,bb=((a+1)%n,b) if mu==0 else(a,(b+1)%n)
            z=sum(c.conj(v[a,b][i])*v[aa,bb][i] for i in range(2))
            assert abs(z)>0
            return z/abs(z)
        s=c.mpf(0)
        for a in range(n):
            for b in range(n):
                s+=c.arg(link(a,b,0)*link((a+1)%n,b,1)*c.conj(link(a,(b+1)%n,0))*c.conj(link(a,b,1)))
        val=s/(2*c.pi);nearest=int(c.nint(val))
        assert abs(val-nearest)<c.mpf(2)**-100
        labels.append(nearest)
    assert labels[0]==labels[1]
    return labels[0]

def test_independent_Pauli_Wilson_orientation_and_domain_controls():
    for n in (4,5,7):
        for m in (1,5,6):
            assert F.haldane_lattice_chern(m,n)==independent_wilson(m,n)
    assert F._fhs_principal(-math.pi)==math.pi
    for x in (-3*math.pi,-math.pi,0,math.pi,3*math.pi):
        assert -math.pi<F._fhs_principal(x)<=math.pi
    for value in (float("nan"),float("inf"),True,1j,np.array([1])):
        with pytest.raises((ValueError,ArithmeticError)):F.haldane_lattice_chern(value)
    with pytest.raises(ArithmeticError):
        F._d11_fhs_certificate(1,4,1,1,None,schedule=(128,),work=dict(used=0,limit=1))

def test_reference_failure_cannot_pass_or_hide_a_wide_interval():
    with pytest.raises(ArithmeticError,match="reference UNRESOLVED"):
        reference(lambda c:c.mpf([0,1]),Q(1),gamma(128))
    with pytest.raises(AssertionError):
        compare(1+2**-20,lambda c:c.mpf(1),1,128)


def _notebook_mixing_reference():
    """All501 original binary inputs; independent rational identities, not F/env."""
    grid=np.linspace(0.,1.,501)
    mg=[];voigt=[];reuss=[];gap=[];residuals=[]
    for f in grid:
        q=Q.from_float(float(f))
        mg.append(float((6+6*q)/(6-3*q)))
        voigt.append(float(1+3*q));reuss.append(float(Q(4)/(4-3*q)))
        gap.append(float(9*q*(1-q)/(4-3*q)))
        residuals.append(abs((voigt[-1]-reuss[-1])-gap[-1]))
    assert len(grid)==len(mg)==len(voigt)==len(reuss)==len(gap)==len(residuals)==501
    return grid,np.asarray(mg),max(residuals),voigt,reuss,gap,residuals


def test_notebook_real_table_and_constituent_cells_assert():
    from pathlib import Path
    import json,contextlib,io
    n=json.loads(Path("notebooks/D11_TopologicalBandTheory_Technical.ipynb").read_text())
    assert len(n["cells"])==20 and sum(c["cell_type"]=="code" for c in n["cells"])==12
    def four(fn,scale):
        lo,hi=reference(fn,Q(scale),gamma(128)*Q(scale))
        a,b=f"{float(lo):.4f}",f"{float(hi):.4f}"
        assert a==b
        return a
    shift=lambda c:3*c.sqrt(3)*c.sin(iv(c,math.pi/2))
    window=four(shift,6);sqrt3=four(lambda c:3*c.sqrt(3),6)
    expected=[f"analytic inversion window half-width |3sqrt(3) t2 sin(phi)| = {window} [3*sqrt(3) = {sqrt3}]",
              "", "m mass(K) mass(K') inverted? certified C (4x4)"]
    for m,flag,C in [(1,True,-1),(5,True,0),(6,False,0)]:
        left=four(lambda c:iv(c,m)-shift(c),m+6)
        right=four(lambda c:iv(c,m)+shift(c),m+6)
        expected.append(f"{m:.1f} {left} {right} {flag} {C:+d}")
    expected+=["","NOTE m = 5 is INSIDE the window yet certifies C = 0.",
              "Mass inversion is NOT sufficient at fixed grid size (necessity is sampled at m=6, not proved)."]
    for index in (11,14):
        env=dict(F=F,np=np)
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            exec(compile("".join(n["cells"][index]["source"]),f"D11-cell-{index}","exec"),env)
        assert stream.getvalue()
        assert "assert" in "".join(n["cells"][index]["source"])
        text=[" ".join(x.split()) for x in stream.getvalue().strip().splitlines()]
        if index==11:
            assert text==expected
        else:
            assert len(env['fs'])==len(env['vals'])==501
            assert env['eps']==2 and env['worst']<1e-12
            grid,mg,independent_worst,voigt,reuss,gap,residuals=_notebook_mixing_reference()
            assert np.array_equal(env['fs'],grid) and np.array_equal(env['vals'],mg)
            assert env['worst']==independent_worst
            # Check every candidate numerical input to the displayed diagnostic,
            # in addition to its independent expected maximum and printed value.
            for q,v,r,g in zip(grid,voigt,reuss,gap):
                assert F.voigt_modulus(1.,4.,q)==v and F.reuss_modulus(1.,4.,q)==r
                assert F.voigt_reuss_gap(1.,4.,q)==g
            assert independent_worst<1e-12
            assert text==["Maxwell-Garnett (1, 4, 1/2) = 2 [Lean: exactly 2]",
                "constituent bounds respected over f in [0,1]: True",
                f"max |(M_V - M_R) - exact gap formula| over f : {independent_worst:.3e} [Lean voigt_sub_reuss_eq: identity]",
                "OK - the gap is an exact identity, not merely non-negative."]



def test_actual_numpy_primitive_admission_and_refusal():
    angles=[0.,math.pi,math.pi/2,-math.pi/2,math.pi/6,-math.pi/6]+[2*math.pi*j/n for n in(4,5,7) for j in range(n)]
    for a in angles:
        compare(float(np.sin(a)),lambda c:c.sin(iv(c,a)),1,budget=8*U)
        compare(float(np.cos(a)),lambda c:c.cos(iv(c,a)),1,budget=8*U)
        z=np.exp(1j*a)
        compare(z.real,lambda c:c.cos(iv(c,a)),1,budget=8*U)
        compare(z.imag,lambda c:c.sin(iv(c,a)),1,budget=8*U)
    for x in (1.,2.,3.,4.):
        ci=oracle_context(384);scale=upper(ci.sqrt(iv(ci,x)))
        compare(float(np.sqrt(x)),lambda c:c.sqrt(iv(c,x)),scale,budget=2*U*scale)
    for fun,args in [(F.maxwell_garnett,(float("inf"),4,.5)),(F.voigt_modulus,(1,float("nan"),.5)),(F.reuss_modulus,(1,True,.5)),(F.honeycomb_structure_factor,(1j,0)),(F.dirac_linear_form_norm,(np.array([1]),0)),(F.fermi_velocity,(1,1,0)),(F.bernal_full_gap_sq,(0,0))]:
        with pytest.raises((ValueError,ArithmeticError)):fun(*args)


def test_tiny_tolerance_and_no_float_stagnation_fallback():
    with pytest.raises(ArithmeticError):
        F.haldane_flip_location(tol=Q(1,2**100))


def test_positive_output_underflow_refuses_instead_of_returning_zero():
    with pytest.raises(ArithmeticError):
        F.bernal_full_gap_sq(Q(1,2**600),1)


def test_diatomic_extreme_ratio_preserves_representable_branch_or_refuses_underflow():
    # x/optical underflows in the old evaluation, although 4*x*y/optical does not.
    ac,op=F.diatomic_branches(1e300,1e-300,1,1)
    assert ac>0 and op>0 and math.isfinite(ac) and math.isfinite(op)
    x=Q(1)/exact(1e300);y=Q(1)/exact(1e-300)
    compare(ac,lambda c:4*iv(c,x)*iv(c,y)*c.sin(c.mpf(1)/2)**2/(iv(c,x)+iv(c,y)+c.sqrt((iv(c,x)-iv(c,y))**2+4*iv(c,x)*iv(c,y)*c.cos(c.mpf(1)/2)**2)),abs(exact(ac)),256)
    with pytest.raises(ArithmeticError):F.diatomic_branches(1,2,1,1e-200)
    with pytest.raises(ArithmeticError):F.diatomic_branches(1,2,1,1e-200,1e-200)
    with pytest.raises(ArithmeticError):F.diatomic_branches(1,2,1,float.fromhex("0x0.0000000000001p-1022"))

def _reference_point_arg(x,y,bits=128):
    """Independent direct sums, wider J and exact remainder; not production code."""
    pl,pu=_reference_pi(bits+32)
    def at(q):
        if q<0:
            l,h=at(-q);return -h,-l
        if q>1:
            l,h=at(1/q);return pl/2-h,pu/2-l
        if q>Q(1,2):
            l,h=at((q-1)/(q+1));return pl/4+l,pu/4+h
        J=2*bits+64
        s=sum(((-1)**j*q**(2*j+1)/Q(2*j+1) for j in range(J)),Q())
        r=q**(2*J+1)/Q(2*J+1)
        return (s,s+r) if J%2==0 else (s-r,s)
    if y==0:
        assert x!=0;return (Q(0),Q(0)) if x>0 else (pl,pu)
    if x==0:return (pl/2,pu/2) if y>0 else (-pu/2,-pl/2)
    l,h=at(abs(y/x))
    if x>0:return (l,h) if y>0 else (-h,-l)
    return (pl-h,pu-l) if y>0 else (l-pu,h-pl)

def test_exact_operational128_angle_counterexample_and_point_quadrants():
    q=Q(60049829456636199434713166017370860845,2**128)
    A=Q(237751477255236011272150636645860459593,2**130)
    S80=sum(((-1)**j*q**(2*j+1)/Q(2*j+1) for j in range(80)),Q())
    assert S80>A and q**161/161<Q(1,2**300)
    for p in (128,192,256):
        c=MPIntervalContext();c.prec=p
        points=[(Q(1),q),(Q(1),Q(0)),(Q(-1),Q(0)),(Q(0),Q(1)),(Q(0),Q(-1)),
                (Q(2),Q(3)),(Q(-2),Q(3)),(Q(-2),Q(-3)),(Q(2),Q(-3))]
        for x,y in points:
            l,h=F._d11_point_arg(c,x,y);a,b=_reference_point_arg(x,y,p)
            assert l<=a<=b<=h
            result,status=F._d11_safe_arg(c,iv(c,x),iv(c,y))
            assert status=='USABLE'
            lo,hi=bounds(result);assert lo<=a<=b<=hi
        lo,hi=F._d11_point_arg(c,Q(1),q)
        assert lo<=S80 and S80+q**161/161<=hi
        assert hi-lo<Q(1,2**(p-2))
        assert c._d11_elementary['series_terms']>0

def test_actual_public_angle_receipts_contain_every_admitted_corner():
    receipt=F._d11_fhs_certificate(1,4,0,0,None)
    assert receipt['chern']==0 and len(receipt['angle_receipts'])==16
    cache={}
    for row in receipt['angle_receipts']:
        lo,hi=row['angle'];assert row['status']=='USABLE'
        for x in row['real']:
            for y in row['imag']:
                key=(x,y)
                if key not in cache:cache[key]=_reference_point_arg(x,y,receipt['precision'])
                a,b=cache[key];assert lo<=a<=b<=hi

def test_rigorous_basic_directed_and_trig_contracts():
    for p in (128,192,256):
        c=MPIntervalContext();c.prec=p
        for x,y in [(Q(1,3),Q(7,11)),(Q(-1,3),Q(7,11)),(Q(1,2**700),Q(3,2**500))]:
            a,b=iv(c,x),iv(c,y)
            for result,target in [(a+b,x+y),(a-b,x-y),(a*b,x*y),(a/b,x/y)]:
                lo,hi=bounds(result);assert lo<=target<=hi
        l,h=bounds(c.sqrt(c.mpf(3)));assert l*l<=3<=h*h and l>0
        for j,n in [(1,4),(2,4),(3,4),(1,5),(3,7)]:
            co,si=F._d11_sincos(c,turn=Q(j,n))
            if (4*j)%n==0:
                k=(4*j)//n
                assert bounds(co)==((1,0,-1,0)[k],)*2 and bounds(si)==((0,1,0,-1)[k],)*2
                continue
            pl,pu=_reference_pi(p+32)
            ref=oracle_context(p+32);angle=ref.mpf([iv(ref,2*pl*j/n),iv(ref,2*pu*j/n)])
            for out,rr in [(co,ref.cos(angle)),(si,ref.sin(angle))]:
                lo,hi=bounds(out);a,b=bounds(rr);assert lo<=a<=b<=hi
        for angle in (Q(1,2**1300),Q(-1,2**1300),Q(1,3),Q(-7,2)):
            co,si=F._d11_sincos(c,phi=angle)
            r=oracle_context(p+32)
            for out,rr in [(co,r.cos(iv(r,angle))),(si,r.sin(iv(r,angle)))]:
                lo,hi=bounds(out);a,b=bounds(rr);assert lo<=a<=b<=hi
        for angle in (Q(0),):
            co,si=F._d11_sincos(c,phi=angle);assert bounds(co)==(1,1) and bounds(si)==(0,0)

def test_signed_haldane_shift_no_premature_underflow_and_rounding_cells():
    for t,phi in [(1e-200,1e-200),(-1e-200,1e-200),(1e-200,-1e-200)]:
        with pytest.raises(ArithmeticError):F.haldane_mass_inversion_window(t,phi)
        with pytest.raises(ArithmeticError):F.haldane_dirac_masses(0,t,phi)
        # Nonzero m can absorb the shift in final rounding without declaring S=0.
        assert F.haldane_dirac_masses(1,t,phi)==(1.,1.)
    for t,phi in [(0,1),(1,0),(-1,0)]:
        assert F.haldane_mass_inversion_window(t,phi)==0
        assert F.haldane_dirac_masses(2,t,phi)==(2,2)
    for t,phi in [(1,.2),(-1,.2),(1,-.2),(2,.4),(1e308,1e-308)]:
        fn=lambda c:3*c.sqrt(3)*iv(c,t)*c.sin(iv(c,phi))
        lo,hi=reference(fn,Q(6)*abs(exact(t))*abs(exact(phi)),gamma(128)*Q(6)*abs(exact(t))*abs(exact(phi)))
        for m in (0.,1.):
            a,b=F.haldane_dirac_masses(m,t,phi)
            scale=abs(exact(m))+max(abs(lo),abs(hi))
            assert max(abs(exact(a)-(exact(m)-hi)),abs(exact(a)-(exact(m)-lo)))<=gamma(128)*scale
            assert max(abs(exact(b)-(exact(m)+hi)),abs(exact(b)-(exact(m)+lo)))<=gamma(128)*scale
        window=F.haldane_mass_inversion_window(t,phi)
        assert max(abs(exact(window)-abs(lo)),abs(exact(window)-abs(hi)))<=gamma(128)*max(abs(lo),abs(hi))
    # An enclosure must lie inside the rounding cell; the rounded point need not
    # lie inside the narrow real interval itself.
    half=Q(1,2**54)
    assert F._d11_rounded_interval(Q(1)+half/2,Q(1)+half,Q(2))==1.
    with pytest.raises(ArithmeticError):F._d11_rounded_interval(Q(1),Q(1)+Q(1,2**51),Q(2))

def test_both_dirac_axes_and_global_norm_remainder_with_input_allowance():
    qs=[(0.,0.),(1.,0.),(1.,1.),(-1.,2.)]
    qs += [(s*2.**-10,0.) for s in (-1,1)]
    qs += [(0.,s*2.**-10) for s in (-1,1)]
    qs += [(a*2.**-30,b*2.**-30) for a in (-1,1) for b in (-1,1)]
    for a,b in qs:
        compare(F.dirac_linear_form_norm(a,b),lambda c:c.sqrt(iv(c,a)**2-iv(c,a)*iv(c,b)+iv(c,b)**2),abs(a)+abs(b),128)
        for swapped in (False,True):
            c=oracle_context(384);K1,K2=(4*c.pi/3,2*c.pi/3) if swapped else (2*c.pi/3,4*c.pi/3)
            # The candidate receives these exact binary values; model error is
            # bounded independently against the symbolic K+q.
            x,y=(4*math.pi/3+a,2*math.pi/3+b) if swapped else (2*math.pi/3+a,4*math.pi/3+b)
            e1=max(abs(exact(x)-z) for z in bounds(K1+iv(c,a)))
            e2=max(abs(exact(y)-z) for z in bounds(K2+iv(c,b)))
            z=F.honeycomb_structure_factor(x,y)
            value=abs(z);linear=F.dirac_linear_form_norm(a,b)
            fixed=exact(a)**2+exact(b)**2+e1+e2+gamma(128)*3+gamma(128)*(abs(exact(a))+abs(exact(b)))+gamma(8)*3
            assert abs(exact(value)-exact(linear))<=fixed
    c=oracle_context(384);x,y=2*c.pi/3+1,4*c.pi/3+1
    re=1+c.cos(x)+c.cos(y);im=c.sin(x)+c.sin(y)
    norm=c.sqrt(re**2+im**2);lin=c.mpf(1)
    assert bounds(norm-lin)[0]>0 or bounds(norm-lin)[1]<0



def test_complete_fig1_layout_and_sample_contract():
    _complete_fig1(V.fig_d11_phononic_band_gap())


def test_complete_fig2_layout_and_sample_contract():
    _complete_fig2(V.fig_d11_pt_exceptional_point())


def test_complete_fig3_layout_and_sample_contract():
    _complete_fig3(V.fig_d11_haldane_chern())


def test_complete_fig4_layout_and_sample_contract():
    _complete_fig4(V.fig_d11_effective_medium())


def test_integer_root_actual_proposal_postconditions_and_exact_squares():
    for p in (128,192,256):
        c=MPIntervalContext();c.prec=p
        for q in (Q(0),Q(3),Q(1,3),Q(9,16),Q(1,2**700),Q(2**700)):
            out=F._d11_sqrt(c,iv(c,q));lo,hi=bounds(out)
            assert 0<=lo and lo*lo<=q<=hi*hi
            if q in (Q(0),Q(9,16),Q(1,2**700),Q(2**700)):
                assert lo==hi and lo*lo==q
        with pytest.raises(ArithmeticError):F._d11_sqrt(c,c.mpf(-1))


def test_public_fhs_scalar_boundary_preserves_private_cover_carrier():
    for value in ((1, 1), [1, 1], np.array([1, 1])):
        with pytest.raises(ValueError):
            F.haldane_lattice_chern(value)
    for value in (1, 1., Q(1), np.float64(1), np.int64(1)):
        assert F.haldane_lattice_chern(value) == -1
    certificate = F._d11_fhs_certificate(
        (Q(1), Q(1)+Q(1,1000)), 4, 1, 1, None, cell=True)
    assert certificate["minimum_margin"] > 0


# Existing D6 consumers, exercised against actual producer/notebook source.
# These are mutation cases for the existing tests, not physics_checks dispatch.
_D6_SOURCE_MUTATIONS = [
    ('attained_lower', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract',
     'ω²₋(±π) = 1  (lower edge attained)', 'ω²₋(±π) = 1  (lower edge NOT attained)'),
    ('optical_sign', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract',
     'optical branch  ω²₊', 'optical branch  ω²₋'),
    ('broken_negative_component', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract',
     'Im λ = −√(g²−1)', 'Re λ = −√(g²−1)'),
    ('unbroken_phase', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract',
     'PT-unbroken — spectrum real', 'PT-unbroken — spectrum imaginary'),
    ('K_cone_sign', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract',
     'gap at K  = 2|m − 3√3 t₂ sin φ|', 'gap at K  = 2|m + 3√3 t₂ sin φ|'),
    ('analytic_window_direction', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract',
     'analytic inversion window  |m| &lt; 3√3 ≈ 5.196', 'analytic inversion window  |m| &gt; 3√3 ≈ 5.196'),
    ('finite_not_continuum', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract',
     '(right) certified C, t = t₂ = 1, φ = π/2, 4×4 torus', '(right) continuum C, t = t₂ = 1, φ = π/2, 4×4 torus'),
    ('Voigt_arithmetic', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     '(right) Voigt (iso-strain, arithmetic)', '(right) Voigt (iso-strain, harmonic)'),
    ('gap_not_physical_bounds', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     '(right) exact Voigt − Reuss gap', '(right) physical effective-modulus bounds'),
    ('MG_correct_panel', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     'name="(left) ε<sub>eff</sub>  (Maxwell–Garnett)"), row=1, col=1)',
     'name="(left) ε<sub>eff</sub>  (Maxwell–Garnett)"), row=1, col=2)'),
    # Complementary whole-inventory controls, beyond the eleven r7 escapes.
    ('acoustic_sign', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract',
     'acoustic branch  ω²₋', 'acoustic branch  ω²₊'),
    ('attained_upper', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract',
     'ω²₊(±π) = 2  (upper edge attained)', 'ω²₊(±π) = 2  (upper edge NOT attained)'),
    ('gap_exclusion_text', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract',
     '— no state here', '— states occur here'),
    ('secondary_acoustic_sample', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract',
     'x=k, y=acoustic,', 'x=k[:-1], y=acoustic[:-1],'),
    ('gap_rectangle', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract',
     'fig.add_hrect(y0=lo, y1=hi,', 'fig.add_hrect(y0=lo, y1=hi+0.1,'),
    ('rational_frequency_units', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract',
     'rational inner bracket in ω:', 'rational inner bracket in ω²:'),
    ('real_negative_sign', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract',
     'Re λ = −√(1−g²)', 'Re λ = +√(1−g²)'),
    ('broken_positive_phase', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract',
     'Im λ = +√(g²−1)  (PT-broken)', 'Re λ = +√(g²−1)  (PT-unbroken)'),
    ('proximity_inequality', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract',
     'g² = 99/100 ⟹ Δ ≤ 1/5 (tight)', 'g² = 99/100 ⟹ Δ ≥ 1/5 (tight)'),
    ('secondary_broken_sample', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract',
     'x=g_broken, y=-imag,', 'x=g_broken[:-1], y=-imag[:-1],'),
    ('EP_coordinate', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract',
     'x=[1.0], y=[0.0],', 'x=[1.1], y=[0.0],'),
    ('Kprime_cone_sign', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract',
     'gap at K′ = 2|m + 3√3 t₂ sin φ|', 'gap at K′ = 2|m − 3√3 t₂ sin φ|'),
    ('mass_inversion_not_sufficient', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract',
     'Haldane Chern witness — mass inversion is NOT sufficient at fixed N',
     'Haldane Chern witness — mass inversion is sufficient at fixed N'),
    ('secondary_Kprime_sample', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract',
     'x=m, y=gap_Kp,', 'x=m[:-1], y=gap_Kp[:-1],'),
    ('scientific_marker_text', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract',
     'm = 5:  C = 0<br>inside the window', 'm = 5:  C = 1<br>inside the window'),
    ('flip_line_binding', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract',
     'fig.add_vline(x=m_flip,', 'fig.add_vline(x=m_flip+0.1,'),
    ('Reuss_harmonic', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     '(right) Reuss (iso-stress, harmonic)', '(right) Reuss (iso-stress, arithmetic)'),
    ('gap_not_maximum', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     'name=f"(right) f = 2/3: gap = ', 'name=f"(right) MAXIMUM f = 2/3: gap = '),
    ('algebraic_title', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     'Algebraic effective-medium bounds (two-scale route deliberately not taken)',
     'Physical homogenized effective-medium bounds'),
    ('secondary_ribbon_sample', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     'y=np.concatenate([voigt, reuss[::-1]]),', 'y=np.concatenate([voigt, reuss[:-1][::-1]]),'),
    ('constituent_rectangle', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     'fig.add_hrect(y0=1.0, y1=4.0,', 'fig.add_hrect(y0=1.0, y1=4.1,'),
    ('permittivity_units', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract',
     '(units of ε₀)', '(units of a modulus)'),
]


# Whole original geometry/exposure mechanisms, including every r9 counterexample.
# Each mutation changes the real producer; current correct producer bytes restore.
_D6_SOURCE_MUTATIONS.extend([
    ('unpainted_constituent_default', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.shapes[0].fillcolor = None\n    return _bundle_layout('),
    ('r9_hidden_optical_line', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[0].line.width = 0\n    return _bundle_layout('),
    ('r9_all_bands_outside_range', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.update_yaxes(range=[10,11])\n    return _bundle_layout('),
    ('r9_hidden_EP_marker', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[4].marker.size = 0\n    return _bundle_layout('),
    ('r9_finite_C_domain_overlap', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.xaxis2.domain = fig.layout.xaxis.domain\n    return _bundle_layout('),
    ('r9_finite_C_wrong_anchor', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis2.anchor = "x"\n    return _bundle_layout('),
    ('r9_hidden_constituent_region', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.shapes[0].visible = False\n    return _bundle_layout('),
    ('r9_hidden_required_Voigt_legend', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[3].showlegend = False\n    return _bundle_layout('),
    ('r9_direct_visible_complement', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[0].visible = False\n    return _bundle_layout('),
    ('hidden_acoustic_line_paint', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[1].line.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('hidden_attained_edge_marker', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[3].marker.size = 0\n    return _bundle_layout('),
    ('hidden_gap_shading', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.shapes[0].fillcolor = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('hidden_lower_edge_legend', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[2].showlegend = False\n    return _bundle_layout('),
    ('single_panel_wrong_anchor', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis.anchor = "free"\n    return _bundle_layout('),
    ('single_panel_collapsed_domain', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.xaxis.domain = [0,.01]\n    return _bundle_layout('),
    ('PT_negative_line_width', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[1].line.width = 0\n    return _bundle_layout('),
    ('PT_EP_marker_opacity', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[4].marker.opacity = 0\n    return _bundle_layout('),
    ('PT_proximity_line_hidden', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.shapes[1].line.width = 0\n    return _bundle_layout('),
    ('PT_unbroken_region_opacity', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.shapes[0].opacity = 0\n    return _bundle_layout('),
    ('PT_signed_branches_outside_range', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis.range = [0,2]\n    return _bundle_layout('),
    ('PT_required_legend_globally_hidden', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.showlegend = False\n    return _bundle_layout('),
    ('PT_log_reinterpretation', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis.type = "log"\n    return _bundle_layout('),
    ('Dirac_Kprime_line_hidden', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[1].line.width = 0\n    return _bundle_layout('),
    ('finite_C_scientific_marker_hidden', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[4].marker.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('finite_C_window_proxy_legend_hidden', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[2].showlegend = False\n    return _bundle_layout('),
    ('Dirac_window_region_hidden', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.shapes[0].opacity = 0\n    return _bundle_layout('),
    ('finite_C_window_region_hidden', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.shapes[1].fillcolor = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('finite_C_flip_line_hidden', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.shapes[2].line.width = 0\n    return _bundle_layout('),
    ('finite_C_vertical_domain_cropped', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis2.domain = [0,.01]\n    return _bundle_layout('),
    ('finite_C_overlaying_left_panel', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis2.overlaying = "y"\n    return _bundle_layout('),
    ('MG_curve_hidden', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[0].line.width = 0\n    return _bundle_layout('),
    ('MG_halffill_marker_hidden', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[1].marker.opacity = 0\n    return _bundle_layout('),
    ('elastic_gap_ribbon_hidden', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[2].fillcolor = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('Reuss_required_legend_hidden', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[4].showlegend = False\n    return _bundle_layout('),
    ('elastic_gap_line_hidden', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[5].line.width = 0\n    return _bundle_layout('),
    ('elastic_gap_marker_hidden', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[5].marker.size = 0\n    return _bundle_layout('),
    ('elastic_right_domain_overlap', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.xaxis2.domain = fig.layout.xaxis.domain\n    return _bundle_layout('),
    ('elastic_right_wrong_anchor', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis2.anchor = "x"\n    return _bundle_layout('),
    ('elastic_curves_outside_range', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis2.range = [10,11]\n    return _bundle_layout('),
    ('MG_annotation_hidden', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.annotations[2].opacity = 0\n    return _bundle_layout('),
])


# Original scientific words must remain exposed, not merely stored in metadata.
_D6_SOURCE_MUTATIONS.extend([
    ('r11_rational_annotation_paint', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.annotations[1].font.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('r11_PT_required_legend_paint', 'fig_d11_pt_exceptional_point', 'test_complete_fig2_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.legend.font.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('r11_m5_inside_window_paint', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[4].textfont.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('r11_constituent_annotation_paint', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.annotations[2].font.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('r11_annotation_opacity_complement', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.annotations[1].opacity = 0\n    return _bundle_layout('),
    ('scientific_title_paint', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.title.font.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('squared_frequency_unit_paint', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis.title.font.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('wavevector_tick_paint', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.xaxis.tickfont.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('wavevector_tick_labels_hidden', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.xaxis.showticklabels = False\n    return _bundle_layout('),
    ('finite_C_axis_unit_paint', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis2.title.font.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('finite_C_tick_paint', 'fig_d11_haldane_chern', 'test_complete_fig3_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis2.tickfont.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('MG_half_fill_text_paint', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.data[1].textfont.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('layout_inherited_text_paint', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.font.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('axis_inherited_text_paint', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'fig.layout.yaxis.color = "rgba(0,0,0,0)"\n    return _bundle_layout('),
    ('annotation_template_text_paint', 'fig_d11_phononic_band_gap', 'test_complete_fig1_layout_and_sample_contract', 'return _bundle_layout(', 'def _finish(*args, **kwargs):\n        result = _bundle_layout(*args, **kwargs)\n        result.layout.template.layout.annotationdefaults.font.color = "rgba(0,0,0,0)"\n        return result\n    return _finish('),
])


# Original right-panel text/geometry uses the actual numbered template container.
_D6_SOURCE_MUTATIONS.extend([
    ('numbered_template_y_title', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', "def _finish(*args, **kwargs):\n        result = _bundle_layout(*args, **kwargs)\n        result.layout.template.layout.update({'yaxis2': {'title': {'font': {'color': 'rgba(0,0,0,0)'}}}})\n        return result\n    return _finish("),
    ('numbered_template_y_ticks', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', "def _finish(*args, **kwargs):\n        result = _bundle_layout(*args, **kwargs)\n        result.layout.template.layout.update({'yaxis2': {'tickfont': {'color': 'rgba(0,0,0,0)'}}})\n        return result\n    return _finish("),
    ('numbered_template_x_title', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', "def _finish(*args, **kwargs):\n        result = _bundle_layout(*args, **kwargs)\n        result.layout.template.layout.update({'xaxis2': {'title': {'font': {'color': 'rgba(0,0,0,0)'}}}})\n        return result\n    return _finish("),
    ('numbered_template_x_ticks', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', "def _finish(*args, **kwargs):\n        result = _bundle_layout(*args, **kwargs)\n        result.layout.template.layout.update({'xaxis2': {'tickfont': {'color': 'rgba(0,0,0,0)'}}})\n        return result\n    return _finish("),
    ('numbered_template_hidden_ticks', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', "def _finish(*args, **kwargs):\n        result = _bundle_layout(*args, **kwargs)\n        result.layout.template.layout.update({'yaxis2': {'showticklabels': False}})\n        return result\n    return _finish("),
    ('numbered_template_excluded_range', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', "def _finish(*args, **kwargs):\n        result = _bundle_layout(*args, **kwargs)\n        result.layout.template.layout.update({'yaxis2': {'range': [10, 11]}})\n        return result\n    return _finish("),
    ('numbered_template_hidden_axis', 'fig_d11_effective_medium', 'test_complete_fig4_layout_and_sample_contract', 'return _bundle_layout(', "def _finish(*args, **kwargs):\n        result = _bundle_layout(*args, **kwargs)\n        result.layout.template.layout.update({'yaxis2': {'visible': False}})\n        return result\n    return _finish("),
])


def _actual_d6_consumer_control(producer, consumer, old, new, *, cell=None):
    """Hard original -> intended assertion RED -> exact restore -> hard GREEN."""
    from pathlib import Path
    import ast,datetime,hashlib,json,os,subprocess,sys
    from scripts import seed_journal as journal
    root=Path(__file__).resolve().parent.parent
    path=(root/'notebooks/D11_TopologicalBandTheory_Technical.ipynb'
          if cell is not None else Path(V.__file__).resolve())
    def state():
        s=path.stat()
        return dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),mode=s.st_mode,
                    mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
    def mutate(text):
        if cell is not None:
            notebook=__import__('json').loads(text)
            source=''.join(notebook['cells'][cell]['source'])
            assert source.count(old)==1
            notebook['cells'][cell]['source']=source.replace(old,new,1).splitlines(keepends=True)
            return __import__('json').dumps(notebook,ensure_ascii=False,indent=1)+'\n'
        node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==producer)
        lines=text.splitlines(keepends=True)
        source=''.join(lines[node.lineno-1:node.end_lineno])
        assert source.count(old)==1,(producer,old)
        return ''.join(lines[:node.lineno-1])+source.replace(old,new,1)+''.join(lines[node.end_lineno:])
    code=("import pathlib,runpy,hashlib;from src.core import formulas as F,visualizations as V;"
          "root=pathlib.Path.cwd();assert all(pathlib.Path(m.__file__).resolve().is_relative_to(root)for m in(F,V));"
          "ns=runpy.run_path('tests/test_d11_formula_surface.py');"
          +f"ns[{consumer!r}]();"+
          "print('D6_CONSUMER_OK',V.__file__,hashlib.sha256(pathlib.Path(V.__file__).read_bytes()).hexdigest())")
    argv=[sys.executable,'-B','-c',code]
    def run():
        start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        r=subprocess.run(argv,cwd=root,env=dict(os.environ,PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1'),
                         text=True,capture_output=True)
        return dict(argv=argv,cwd=str(root),start=start,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
    before=state();baseline=run();assert baseline['returncode']==0,baseline
    with journal.seeded_mutation(path,mutate,reason='D11 D6 actual '+consumer):
        seeded=state();red=run()
        assert seeded['sha256']!=before['sha256']
        assert red['returncode']==1 and 'AssertionError' in red['stderr'],red
        assert consumer in red['stderr'] and 'SyntaxError' not in red['stderr'] and 'ImportError' not in red['stderr'],red
    restored=state()
    assert all(restored[k]==before[k] for k in ('sha256','mode','mtime_ns'))
    green=run();assert green['returncode']==0,green
    assert not list(journal.JOURNAL_DIR.glob('*.json'))
    result=dict(producer=producer,consumer=consumer,old=old,new=new,cell=cell,path=str(path),
                before=before,seeded=seeded,restored=restored,baseline=baseline,red=red,green=green,
                journal_empty=True,ctime_restored=False)
    print('D11_D6_PRODUCTION_CONTROL='+json.dumps(result))
    return result


@pytest.mark.parametrize('case,producer,consumer,old,new',_D6_SOURCE_MUTATIONS,
                         ids=[r[0] for r in _D6_SOURCE_MUTATIONS])
def test_actual_D6_scientific_display_source_mutations(case,producer,consumer,old,new):
    _actual_d6_consumer_control(producer,consumer,old,new)


@pytest.mark.parametrize('cell,old,new',[
    (14,'print(f"max |(M_V - M_R) - exact gap formula| over f :',
     'worst = 9e-13\nprint(f"max |(M_V - M_R) - exact gap formula| over f :'),
    (11,'Mass inversion is NOT sufficient','Mass inversion is sufficient'),
    (11,'m = 5 is INSIDE the window','m = 5 is OUTSIDE the window'),
    (14,'np.linspace(0.0, 1.0, 501)','np.linspace(0.0, 1.0, 500)'),
],ids=['independent_residual','sufficiency','inside_window','whole_population'])
def test_actual_D6_notebook_source_mutations(cell,old,new):
    _actual_d6_consumer_control(None,'test_notebook_real_table_and_constituent_cells_assert',old,new,cell=cell)


def test_all_actual_figure_arrays_and_live_display_contract():
    # Keep the original full numerical decider reachable by normal pytest discovery.
    check_all_actual_figure_arrays_and_live_display_contract()


@pytest.mark.parametrize('role',[
    'title','legend','annotations','trace_text','axis_title','axis_ticks',
    'layout_font','axis_color','annotation_defaults',
])
def test_scientific_text_default_template_and_local_override(role):
    # Actual returned two-panel figure; these inheritance checks are unit controls,
    # distinct from the journalled real production-source mutations above.
    fig=V.fig_d11_effective_medium()
    def check():
        _visible_display(fig)
        _required_legends(fig,(0,2,3,4,5))
    check()  # the ordinary partially unspecified default paint is valid
    transparent='rgba(0,0,0,0)'
    opaque='rgba(17,34,51,1)'
    if role=='title':
        fig.layout.template.layout.title.font.color=transparent
        override=lambda:setattr(fig.layout.title.font,'color',opaque)
    elif role=='legend':
        fig.layout.template.layout.legend.font.color=transparent
        override=lambda:setattr(fig.layout.legend.font,'color',opaque)
    elif role=='annotations':
        fig.layout.template.layout.annotationdefaults.font.color=transparent
        override=lambda:[setattr(a.font,'color',opaque)for a in fig.layout.annotations]
    elif role=='trace_text':
        fig.layout.template.data.scatter[0].textfont.color=transparent
        override=lambda:setattr(fig.data[1].textfont,'color',opaque)
    elif role in ('axis_title','axis_ticks'):
        template=fig.layout.template.layout.xaxis
        if role=='axis_title':
            template.title.font.color=transparent
            override=lambda:[setattr(a.title.font,'color',opaque)for a in (fig.layout.xaxis,fig.layout.xaxis2)]
        else:
            template.tickfont.color=transparent
            override=lambda:[setattr(a.tickfont,'color',opaque)for a in (fig.layout.xaxis,fig.layout.xaxis2)]
    elif role=='layout_font':
        fig.layout.template.layout.font.color=transparent
        override=lambda:setattr(fig.layout.font,'color',opaque)
    elif role=='axis_color':
        fig.layout.yaxis.color=transparent
        override=lambda:(setattr(fig.layout.yaxis.title.font,'color',opaque),
                         setattr(fig.layout.yaxis.tickfont,'color',opaque))
    else:
        fig.layout.annotationdefaults.font.color=transparent
        override=lambda:[setattr(a.font,'color',opaque)for a in fig.layout.annotations]
    with pytest.raises(AssertionError):check()
    override()
    check()  # an opaque specific role overrides transparent inherited paint


@pytest.mark.parametrize('axis_name',['xaxis2','yaxis2'])
@pytest.mark.parametrize('role',['title','ticks'])
def test_numbered_axis_template_container_and_role_precedence(axis_name,role):
    fig=V.fig_d11_effective_medium()
    check=lambda:_complete_fig4(fig)
    check()
    template=fig.layout.template.layout
    local=getattr(fig.layout,axis_name)
    template[axis_name]=dict(type='linear')
    specific=getattr(template,axis_name)
    generic_name=axis_name[0]+'axis'
    generic=getattr(template,generic_name)
    first=getattr(fig.layout,generic_name)
    transparent='rgba(0,0,0,0)'
    opaque='rgba(17,34,51,1)'
    def font(axis):return axis.title.font if role=='title' else axis.tickfont
    font(specific).color=transparent
    with pytest.raises(AssertionError):check()
    font(local).color=opaque
    check()  # a local role overrides the numbered template
    font(local).color=None
    font(specific).color=opaque
    font(generic).color=transparent
    font(first).color=opaque
    check()  # the numbered role overrides the generic container
    template[axis_name]=dict(type='linear')
    assert axis_name in template.to_plotly_json()
    check()  # a present partial container does not inherit generic properties
    template[axis_name]=None
    assert axis_name not in template.to_plotly_json()
    with pytest.raises(AssertionError):check()  # absent container falls back
    font(local).color=opaque
    check()


def test_numbered_axis_template_geometry_range_and_local_precedence():
    fig=V.fig_d11_effective_medium()
    check=lambda:_complete_fig4(fig)
    check()
    # Explicit local panel domains/anchors take precedence over templates.
    fig.layout.template.layout.xaxis2=dict(domain=[0,.1],anchor='y')
    check()
    fig.layout.template.layout.yaxis2=dict(range=[10,11])
    with pytest.raises(AssertionError):check()
    fig.layout.yaxis2.range=[0,5]
    check()
    fig.layout.template.layout.yaxis2.visible=False
    with pytest.raises(AssertionError):check()
    fig.layout.yaxis2.visible=True
    check()


# Phase D: source/consumer seams. These guards inspect the actual production
# registries and ASTs; they do not add numerical evidence to VERIFIES by making
# dummy formula calls. Runtime evidence is the original numerical/control suite.
import ast as _surface_ast
import json as _surface_json
import re as _surface_re
from pathlib import Path as _SurfacePath

_D11_ROOT = _SurfacePath(__file__).resolve().parents[1]
_D11_REVIEWED_FLOOR = frozenset('''diatomic_branches phononic_gap_edges
phononic_gap_rational_enclosure pt_eigenvalue_splitting maxwell_garnett
voigt_modulus reuss_modulus voigt_reuss_gap honeycomb_structure_factor
dirac_linear_form_norm fermi_velocity haldane_nnn haldane_dirac_masses
haldane_mass_inversion_window haldane_lattice_chern haldane_flip_location
bernal_full_gap_sq'''.split())


def _d11_tree(relative):
    return _surface_ast.parse((_D11_ROOT / relative).read_text(encoding='utf-8'))


def _d11_registry():
    # Literal evaluation does not import graph/cache/database machinery.
    tree = _d11_tree('src/core/provenance.py')
    nodes = [n for n in tree.body if isinstance(n, _surface_ast.Assign)
             and any(isinstance(t, _surface_ast.Name) and t.id == 'PAPER_DEPENDENCIES'
                     for t in n.targets)]
    assert len(nodes) == 1
    keys = [_surface_ast.literal_eval(k) for k in nodes[0].value.keys]
    assert len(keys) == len(set(keys)), 'duplicate paper registry key'
    return _surface_ast.literal_eval(nodes[0].value)


def _d11_region(tree):
    functions = [n for n in tree.body if isinstance(n, _surface_ast.FunctionDef)]
    first = [i for i, n in enumerate(functions) if n.name == 'diatomic_branches']
    last = [i for i, n in enumerate(functions) if n.name == 'bernal_full_gap_sq']
    assert len(first) == len(last) == 1, 'missing/duplicate D11 delimiter'
    assert first[0] < last[0], 'reversed D11 delimiters'
    names = [n.name for n in functions[first[0]:last[0]+1] if not n.name.startswith('_')]
    assert len(names) == len(set(names)), 'duplicate public D11 definition'
    assert all(sum(f.name==name for f in functions)==1 for name in names), 'public D11 name redefined outside region'
    assert _D11_REVIEWED_FLOOR <= set(names), 'reviewed public model removed'
    return names



def _d11_population_contract(declared, tree, consumer_owed):
    region=_d11_region(tree)
    defined={n.name for n in tree.body if isinstance(n,_surface_ast.FunctionDef)}
    assert declared and len(declared)==len(set(declared)), 'empty/duplicate registry population'
    assert set(region)|set(consumer_owed) <= set(declared), 'unregistered source/consumer model'
    assert set(declared) <= defined, 'registry names absent Formula definitions'
    assert set(declared)==set(region)|set(consumer_owed), 'unjustified extra registry model'
    return region


def _d11_import_bindings(tree):
    """Resolve actual imports, refusing ambiguity rather than tail matching.

    This bounded source guard supports canonical module/direct-function imports.
    Rebinding a canonical alias anywhere in the inspected scope requires explicit
    review; it is not silently treated as a formula call.
    """
    bindings = {}
    for n in _surface_ast.walk(tree):
        pairs = []
        if isinstance(n, _surface_ast.ImportFrom):
            pairs = [(a.asname or a.name, (n.module or '')+'.'+a.name) for a in n.names]
        elif isinstance(n, _surface_ast.Import):
            pairs = [(a.asname or a.name.split('.')[0], a.name if a.asname else a.name.split('.')[0])
                     for a in n.names]
        for alias, target in pairs:
            assert alias not in bindings or bindings[alias] == target, f'ambiguous import {alias}'
            bindings[alias] = target
    canonical = {a for a, b in bindings.items() if b in ('src.core.formulas','src.core.visualizations')
                 or b.startswith(('src.core.formulas.','src.core.visualizations.'))}
    for n in _surface_ast.walk(tree):
        if isinstance(n, _surface_ast.Name) and isinstance(n.ctx, (_surface_ast.Store, _surface_ast.Del)):
            assert n.id not in canonical, f'rebound canonical alias {n.id}'
        if isinstance(n, _surface_ast.arg):
            assert n.arg not in canonical, f'shadowed canonical alias {n.arg}'
    return bindings


def _d11_call_target(call, bindings):
    f = call.func
    if isinstance(f, _surface_ast.Name):
        return bindings.get(f.id, f.id)
    if isinstance(f, _surface_ast.Attribute):
        parts = []
        while isinstance(f, _surface_ast.Attribute):
            parts.append(f.attr); f = f.value
        if isinstance(f, _surface_ast.Name):
            return '.'.join([bindings.get(f.id, f.id), *reversed(parts)])
    return None


def _d11_calls(node, bindings, prefix):
    return {t[len(prefix):] for c in _surface_ast.walk(node)
            if isinstance(c, _surface_ast.Call)
            and (t := _d11_call_target(c, bindings)) and t.startswith(prefix)}


def _d11_formula_closure(initial, formula_tree):
    """Conservative static call closure, including private certification helpers.

    It inventories dependencies, not a proof of every Python control-flow path.
    Public functions reached outside the delimiter region become owed too.
    """
    by_name = {n.name:n for n in formula_tree.body if isinstance(n, _surface_ast.FunctionDef)}
    pending, seen, public = list(initial), set(), set()
    while pending:
        name = pending.pop()
        assert name in by_name, f'consumer calls missing canonical formula {name}'
        if name in seen:
            continue
        seen.add(name)
        if not name.startswith('_'):
            public.add(name)
        for call in _surface_ast.walk(by_name[name]):
            if isinstance(call, _surface_ast.Call) and isinstance(call.func, _surface_ast.Name):
                if call.func.id in by_name:
                    pending.append(call.func.id)
    return public


def _d11_used_formula_calls(function, bindings):
    """Require formula output to reach a figure mutation/return, not dead locals.

    Assignment dependencies are conservatively closed over the finite AST. This
    catches the previously unused enclosure locals; full semantic output checks
    remain the independently reviewed D6 actual-array/label tests above.
    """
    dependencies = {}
    def refs(node):
        found = _d11_calls(node, bindings, 'src.core.formulas.')
        for x in _surface_ast.walk(node):
            if isinstance(x, _surface_ast.Name) and isinstance(x.ctx, _surface_ast.Load):
                found |= dependencies.get(x.id, set())
        return found
    assignments = [n for n in _surface_ast.walk(function)
                   if isinstance(n, (_surface_ast.Assign, _surface_ast.AnnAssign))]
    for _ in range(len(assignments)+1):
        changed = False
        for n in assignments:
            if n.value is None:
                continue
            targets = n.targets if isinstance(n, _surface_ast.Assign) else [n.target]
            for target in targets:
                for x in _surface_ast.walk(target):
                    if isinstance(x, _surface_ast.Name):
                        updated = dependencies.get(x.id,set()) | refs(n.value)
                        if updated != dependencies.get(x.id,set()):
                            dependencies[x.id] = updated; changed = True
        if not changed:
            break
    used = set()
    for n in _surface_ast.walk(function):
        if isinstance(n, _surface_ast.Return):
            used |= refs(n)
        elif isinstance(n, _surface_ast.Call) and isinstance(n.func, _surface_ast.Attribute):
            if n.func.attr.startswith(('add_', 'update_')):
                used |= refs(n)
    return used


def _d11_consumer_surface(tex=None, figure_tree=None, visual_tree=None, notebook=None):
    tex = (_D11_ROOT/'papers/D11/paper_draft.tex').read_text() if tex is None else tex
    figure_tree = _d11_tree('scripts/review_figures.py') if figure_tree is None else figure_tree
    visual_tree = _d11_tree('src/core/visualizations.py') if visual_tree is None else visual_tree
    notebook = _surface_json.loads((_D11_ROOT/'notebooks/D11_TopologicalBandTheory_Technical.ipynb').read_text()) if notebook is None else notebook
    imports = _surface_re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}', tex)
    images = {_SurfacePath(p).stem for p in imports}
    assert len(imports) == len(images) == 5 and all(x.startswith('d11_') for x in images)
    specs = {}
    for n in _surface_ast.walk(figure_tree):
        if isinstance(n, _surface_ast.Call) and isinstance(n.func, _surface_ast.Name) and n.func.id == 'FigureSpec':
            kw = {x.arg:x.value for x in n.keywords}
            if isinstance(kw.get('name'), _surface_ast.Constant) and kw['name'].value in images:
                name = kw['name'].value
                assert name not in specs, f'duplicate FigureSpec {name}'
                specs[name] = _surface_ast.literal_eval(kw['function'])
    assert set(specs) == images, 'manuscript image has no actual FigureSpec'
    functions = {n.name:n for n in visual_tree.body if isinstance(n, _surface_ast.FunctionDef)}
    module_imports = [n for n in visual_tree.body if isinstance(n,(_surface_ast.Import,_surface_ast.ImportFrom))]
    producer_calls = {}
    for name in specs.values():
        assert name in functions, f'unresolved producer {name}'
        fn = functions[name]
        # Other producers' local aliases cannot rebind this producer's F.
        scope = _surface_ast.Module(body=module_imports+[fn],type_ignores=[])
        bindings = _d11_import_bindings(scope)
        calls = _d11_calls(fn, bindings, 'src.core.formulas.')
        assert calls, f'producer {name} has no canonical formula calls'
        assert calls <= _d11_used_formula_calls(fn,bindings), f'dead canonical producer locals: {name}'
        producer_calls[name] = calls
    cells = notebook['cells']
    assert len(cells) == 20 and sum(c['cell_type']=='code' for c in cells) == 12
    code = '\n'.join(''.join(c['source']) for c in cells if c['cell_type']=='code')
    # Per-cell parses avoid IPython output payloads and keep actual source calls.
    code_tree = _surface_ast.parse(code)
    nb_bindings = _d11_import_bindings(code_tree)
    refs = _surface_re.findall(r'^#\s*viz-ref:\s*(\w+)\s*$', code, _surface_re.M)
    assert len(refs) == len(set(refs)) == 5 and set(refs) == set(specs.values())
    notebook_calls = _d11_calls(code_tree, nb_bindings, 'src.core.visualizations.')
    assert set(refs) <= notebook_calls, 'viz-ref without an actual canonical Call'
    for c in cells:
        source = ''.join(c['source'])
        if c['cell_type']=='code' and (m := _surface_re.search(r'^#\s*viz-ref:\s*(\w+)\s*$',source,_surface_re.M)):
            assert m.group(1) in _d11_calls(_surface_ast.parse(source), nb_bindings,'src.core.visualizations.')
    all_calls = set().union(*producer_calls.values()) | _d11_calls(code_tree,nb_bindings,'src.core.formulas.')
    owed = _d11_formula_closure(all_calls,_d11_tree('src/core/formulas.py'))
    return {'images':images,'specs':specs,'producer_calls':producer_calls,'notebook_calls':notebook_calls,'owed':owed}


def _d11_meaningful_assertions(tree=None):
    """Per-assertion output dataflow, not whole-method test-kind promotion.

    Equality/approx identities must contain the relevant actual formula result,
    directly or through assignment. Bounds and unrelated golden assertions do
    not count. This is a source seam; r15 owns executed numerical evidence.
    """
    tree = _d11_tree('tests/test_bundle_formulas_d11_d12.py') if tree is None else tree
    bindings = _d11_import_bindings(tree)
    # Eligibility follows the real source/consumer population.  The old17 set
    # remains a subset floor, not an exclusion filter for later physical APIs.
    population = set(_d11_region(_d11_tree('src/core/formulas.py'))) | _d11_consumer_surface()['owed']
    assert _D11_REVIEWED_FLOOR <= population
    evidence = {}
    for cls in [n for n in tree.body if isinstance(n,_surface_ast.ClassDef)]:
        for fn in [n for n in cls.body if isinstance(n,_surface_ast.FunctionDef)]:
            dependencies = {}
            def refs(node):
                result = _d11_calls(node,bindings,'src.core.formulas.')
                for n in _surface_ast.walk(node):
                    if isinstance(n,_surface_ast.Name) and isinstance(n.ctx,_surface_ast.Load):
                        result |= dependencies.get(n.id,set())
                return result
            # Source order matters: later unrelated assignments cannot support an
            # earlier assertion; loops retain their actual equality assertions.
            for node in sorted(_surface_ast.walk(fn),key=lambda n:getattr(n,'lineno',10**9)):
                if isinstance(node,_surface_ast.Assign):
                    values=refs(node.value)
                    for target in node.targets:
                        for n in _surface_ast.walk(target):
                            if isinstance(n,_surface_ast.Name): dependencies[n.id]=values
                elif isinstance(node,_surface_ast.Assert):
                    expr=node.test
                    if isinstance(expr,_surface_ast.Compare) and len(expr.ops)==1 and isinstance(expr.ops[0],_surface_ast.Eq):
                        left,right=refs(expr.left),refs(expr.comparators[0])
                        # x == x is not an independent identity.
                        if _surface_ast.dump(expr.left)==_surface_ast.dump(expr.comparators[0]): continue
                        for name in (left|right)&population:
                            evidence.setdefault(name,[]).append((cls.name,fn.name,node.lineno))
    return evidence


class TestD11PhaseDStatic:
    """Readonly guards only: safe to run without graph/native/seed admission."""

    def test_registry_exact_population_and_metadata(self):
        registry=_d11_registry(); entry=registry['D11']
        region=_d11_population_contract(entry['formulas'],_d11_tree('src/core/formulas.py'),_d11_consumer_surface()['owed'])
        owed=set(region)|_d11_consumer_surface()['owed']
        source_order=[n.name for n in _d11_tree('src/core/formulas.py').body
                      if isinstance(n,_surface_ast.FunctionDef) and n.name in owed]
        assert entry['formulas']==source_order and len(entry['formulas'])==len(set(entry['formulas']))
        assert entry['platforms']==entry['parameters']==[]
        metadata=_surface_json.loads((_D11_ROOT/'papers/D11/bundle_metadata.json').read_text())
        assert entry['title']==metadata['title']=='Kernel-Verified Topological Band Theory & Metamaterial Substrate'
        assert entry['topic']=='Finite-lattice topology, band spectra and algebraic composite models'
        spec=(_D11_ROOT/'docs/superpowers/specs/2026-10-19-d11-computation-coverage-design.md').read_text()
        claims=_surface_re.findall(r'^\d+\. `([^\n]+)`$',spec,_surface_re.M)
        assert len(claims)==9 and len(set(claims))==9 and entry['key_claims']==claims
        assert _d11_consumer_surface()['owed'] <= set(entry['formulas'])

    def test_apex_homes_resolve_from_existing_records(self):
        metadata=_surface_json.loads((_D11_ROOT/'papers/D11/bundle_metadata.json').read_text())
        records=_surface_json.loads((_D11_ROOT/'lean/lean_deps.json').read_text())
        by_name={}
        for r in records: by_name.setdefault(r['name'],[]).append(r)
        apices=metadata['apex_theorems']; assert len(apices)>=73
        assert len({a['name'] for a in apices})==len(apices)
        homes=set()
        for a in apices:
            found=by_name.get(a['name'],[])
            assert len(found)==1, f'unresolved/ambiguous apex {a["name"]}'
            homes.add(found[0]['module'].removeprefix('SKEFTHawking.'))
        assert _d11_registry()['D11']['lean_modules']==sorted(homes)

    def test_original_direct_assertions_cover_each_formula(self):
        actual=_d11_meaningful_assertions()
        assert _D11_REVIEWED_FLOOR <= set(actual), f'no relevant equality/identity: {_D11_REVIEWED_FLOOR-set(actual)}'
        # Haldane numerical/formal models and inline D6 display obligations remain
        # actual reviewed tests, not phantom Formula nodes or physics-check strings.
        old=_d11_tree('tests/test_d11_formula_surface.py')
        names={n.name for n in old.body if isinstance(n,_surface_ast.FunctionDef)}
        assert {'_actual_d6_consumer_control','check_all_actual_figure_arrays_and_live_display_contract',
                '_complete_fig1','_complete_fig2','_complete_fig3','_complete_fig4'} <= names

    def test_d12_unchanged_positive_population(self):
        tree=_d11_tree('src/core/formulas.py')
        fns=[n.name for n in tree.body if isinstance(n,_surface_ast.FunctionDef)]
        first=fns.index('poisson_avg_error_floor'); last=fns.index('bloch_siegert_scale')
        assert first<last
        actual={n for n in fns[first:last+1] if not n.startswith('_')}
        declared=_d11_registry()['D12']['formulas']
        # Preserve D12's existing seam: region inclusion plus global existence.
        # Its reviewed registry also includes snr_chain_window_ceiling outside
        # these delimiters; region equality would reject that valid dependency.
        assert len(actual)>=20 and actual <= set(declared)
        assert len(declared)>=28 and len(declared)==len(set(declared))
        assert set(declared) <= {n for n in fns if not n.startswith('_')}

    @pytest.mark.parametrize('defect',['first','last','reversed','duplicate','removed'])
    def test_delimiter_and_population_negative_controls(self,defect):
        tree=_d11_tree('src/core/formulas.py')
        if defect in ('first','last'):
            wanted='diatomic_branches' if defect=='first' else 'bernal_full_gap_sq'
            next(n for n in tree.body if isinstance(n,_surface_ast.FunctionDef) and n.name==wanted).name='renamed'
        elif defect=='reversed': tree.body.reverse()
        elif defect=='duplicate':
            tree.body.append(next(n for n in tree.body if isinstance(n,_surface_ast.FunctionDef) and n.name=='diatomic_branches'))
        else:
            tree.body=[n for n in tree.body if not(isinstance(n,_surface_ast.FunctionDef) and n.name=='fermi_velocity')]
        with pytest.raises(AssertionError): _d11_region(tree)

    def test_new_public_region_function_is_automatically_owed(self):
        tree=_d11_tree('src/core/formulas.py')
        last=next(i for i,n in enumerate(tree.body) if isinstance(n,_surface_ast.FunctionDef) and n.name=='bernal_full_gap_sq')
        tree.body.insert(last,_surface_ast.parse('def future_public_model():\n return 1\n').body[0])
        assert 'future_public_model' in _d11_region(tree)
        assert 'future_public_model' not in _d11_registry()['D11']['formulas']

    @pytest.mark.parametrize('source',[
        'from wrong import formulas as F\nx=F.fermi_velocity(1,1,1)',
        'from src.core import formulas as F\nfrom wrong import formulas as F\nx=F.fermi_velocity(1,1,1)',
        'from src.core import formulas as F\nF=object()\nx=F.fermi_velocity(1,1,1)',
        'from src.core import formulas as F\n# F.fermi_velocity(1,1,1)',
    ])
    def test_alias_wrong_ambiguous_rebound_and_comment_controls(self,source):
        tree=_surface_ast.parse(source)
        try: calls=_d11_calls(tree,_d11_import_bindings(tree),'src.core.formulas.')
        except AssertionError: return
        assert not calls

    def test_canonical_direct_import_call_and_outside_region_closure(self):
        tree=_surface_ast.parse('from src.core.formulas import fermi_velocity as velocity\nx=velocity(1,1,1)')
        assert _d11_calls(tree,_d11_import_bindings(tree),'src.core.formulas.')=={'fermi_velocity'}
        formula_tree=_surface_ast.parse('def outside():\n return 1\ndef _helper():\n return outside()\n')
        assert _d11_formula_closure({'_helper'},formula_tree)=={'outside'}

    def test_unused_enclosure_call_is_not_a_display_dependency(self):
        tree=_surface_ast.parse('from src.core import formulas as F\ndef fig():\n dead=F.phononic_gap_rational_enclosure()\n return 1\n')
        fn=tree.body[1]; bindings=_d11_import_bindings(tree)
        assert _d11_calls(fn,bindings,'src.core.formulas.')=={'phononic_gap_rational_enclosure'}
        assert not _d11_used_formula_calls(fn,bindings)

    @pytest.mark.parametrize('defect',['image','spec','producer','viz_comment_only','wrong_notebook_alias'])
    def test_actual_consumer_omission_controls(self,defect):
        tex=(_D11_ROOT/'papers/D11/paper_draft.tex').read_text()
        specs=_d11_tree('scripts/review_figures.py'); vis=_d11_tree('src/core/visualizations.py')
        nb=_surface_json.loads((_D11_ROOT/'notebooks/D11_TopologicalBandTheory_Technical.ipynb').read_text())
        if defect=='image': tex=tex.replace('d11_fig1_phononic_band_gap.png','not_registered.png')
        elif defect=='spec':
            for n in _surface_ast.walk(specs):
                if isinstance(n,_surface_ast.Constant) and n.value=='d11_fig1_phononic_band_gap': n.value='not_registered'
        elif defect=='producer':
            next(n for n in vis.body if isinstance(n,_surface_ast.FunctionDef) and n.name=='fig_d11_phononic_band_gap').name='not_registered'
        elif defect=='viz_comment_only':
            nb['cells'][6]['source']=['# viz-ref: fig_d11_phononic_band_gap\n','# V.fig_d11_phononic_band_gap().show()\n']
        else:
            nb['cells'][1]['source']=[s.replace('from src.core import visualizations as V','from wrong import visualizations as V') for s in nb['cells'][1]['source']]
        with pytest.raises(AssertionError): _d11_consumer_surface(tex,specs,vis,nb)

    def test_unrelated_golden_assertion_does_not_promote_bounds(self):
        tree=_surface_ast.parse('from src.core import formulas as F\nclass T:\n def test_mixed(self):\n  x=F.fermi_velocity(1,1,1)\n  assert x>0\n  assert 2==2\n')
        assert 'fermi_velocity' not in _d11_meaningful_assertions(tree)

    def test_durable_sentence_and_cluster_identity_is_not_index_claim_identity(self):
        review=_surface_json.loads((_D11_ROOT/'papers/D11/claims_review.json').read_text())
        ids=[s['id'] for s in review['sentences']]
        assert len(ids)==len(set(ids))>=169 and all(x.startswith('sentence:D11:') for x in ids)
        for relative in ('papers/D11/claims_review.json','papers/D11/prose_state.json','papers/D11/audit_log.jsonl',
                         'papers/claim_clusters.json','papers/cluster_bundle_index.json'):
            assert 'claim:D11:' not in (_D11_ROOT/relative).read_text(), f'existing-writer identity migration required: {relative}'
        clusters=_surface_json.loads((_D11_ROOT/'papers/claim_clusters.json').read_text())
        members={m for c in clusters['clusters'] for m in c.get('members',[]) if m.startswith('sentence:D11:')}
        # Cluster quote identities are historical sentences, not auto-summary indices.
        assert members and all(not m.startswith('claim:') for m in members)


    @pytest.mark.parametrize('defect',['empty','omitted','ghost','duplicate'])
    def test_declared_population_refuses_each_missing_or_false_measurement(self,defect):
        actual=_d11_registry()['D11']['formulas']; declared=list(actual)
        if defect=='empty': declared=[]
        elif defect=='omitted': declared.remove('fermi_velocity')
        elif defect=='ghost': declared.append('does_not_exist')
        else: declared.append(declared[0])
        with pytest.raises(AssertionError):
            _d11_population_contract(declared,_d11_tree('src/core/formulas.py'),set())

    def test_outside_consumer_public_dependency_is_not_exempt(self):
        tree=_d11_tree('src/core/formulas.py')
        tree.body.extend(_surface_ast.parse('def outside_public_model():\n return 1\ndef _outside_helper():\n return outside_public_model()\n').body)
        owed=_d11_formula_closure({'_outside_helper'},tree)
        assert owed=={'outside_public_model'}
        with pytest.raises(AssertionError):
            _d11_population_contract(_d11_registry()['D11']['formulas'],tree,owed)
        # Adding the real outside definition resolves the missing dependency;
        # its location outside the original region is not a blanket exemption.
        _d11_population_contract(_d11_registry()['D11']['formulas']+['outside_public_model'],tree,owed)


class TestD11PhaseDActualGraph:
    """ROOT-only runtime: actual extractors may reach Lean-index refresh.

    No monkeypatch, dummy nodes, alternate evaluator or fixture-only green.
    This class is deliberately not run by the source author allocation.
    """

    def test_existing_production_nodes_edges_and_gate_union(self):
        from scripts import build_graph as bg
        from scripts.readiness_gates import GraphIndex, _eval_computation_correctness
        assert _SurfacePath(bg.__file__).resolve()==_D11_ROOT/'scripts/build_graph.py'
        formulas=bg.extract_formula_nodes(); papers=bg.extract_paper_nodes()
        claims=bg.extract_paper_claim_nodes(); tests=bg.extract_python_test_nodes()
        nodes=formulas+papers+claims+tests; ids={n['id'] for n in nodes}
        real_population=set(_d11_region(_d11_tree('src/core/formulas.py')))|_d11_consumer_surface()['owed']
        expected={'formula:'+n for n in real_population}
        assert expected <= {n['id'] for n in formulas}
        assert {n['name'] for n in formulas if n['id'] in expected}==set(_d11_registry()['D11']['formulas'])
        actual_claims=[n for n in claims if n['id'].startswith('claim:D11:')]
        assert len(actual_claims)==9
        assert [n['name'] for n in sorted(actual_claims,key=lambda n:n['meta']['index'])]==_d11_registry()['D11']['key_claims']
        assert all(n['meta']['source']=='declared' for n in actual_claims)
        ce=bg.extract_claims_edges(ids); ge=bg.extract_grounded_in_edges(ids); ve=bg.extract_verifies_edges(ids)
        wanted_claims={'claim:D11:'+str(i) for i in range(9)}
        assert {e['target'] for e in ce if e['source']=='paper:D11'}==wanted_claims
        # Declared bundle/formula pairs express dependency coverage, not per-claim proofs.
        assert {(e['source'],e['target']) for e in ge if e['source'] in wanted_claims}=={(c,f) for c in wanted_claims for f in expected}
        index=GraphIndex({'nodes':nodes,'links':ce+ge+ve}); paper=index.by_id['paper:D11']
        union={'formula:'+n for n in paper['meta']['formulas']}
        for c in index.outgoing('paper:D11','CLAIMS'):
            union.update(e['target'] for e in index.outgoing(c['target'],'GROUNDED_IN'))
        assert union==expected and union <= set(index.by_id)
        assertions=_d11_meaningful_assertions()
        for f in expected:
            qualified={'test:test_bundle_formulas_d11_d12::'+c+'::'+m for c,m,_ in assertions.get(f.removeprefix('formula:'),[])}
            assert any(e['source'] in qualified and e['test_kind'] in {'golden','identity','roundtrip'}
                       for e in index.incoming(f,'VERIFIES')), f'no meaningful classified edge for {f}'
        result=_eval_computation_correctness(paper,index)
        assert result.state=='passed' and not result.blockers
        d12=index.by_id['paper:D12']
        assert set(d12['meta']['formulas'])==set(_d11_registry()['D12']['formulas'])
        assert {'formula:'+n for n in d12['meta']['formulas']} <= ids

    def test_existing_sentence_history_and_cluster_producers_keep_exact_ids(self):
        from scripts import build_graph as bg
        assert _SurfacePath(bg.__file__).resolve()==_D11_ROOT/'scripts/build_graph.py'
        review=_surface_json.loads((_D11_ROOT/'papers/D11/claims_review.json').read_text())
        prose=_surface_json.loads((_D11_ROOT/'papers/D11/prose_state.json').read_text())
        events=[_surface_json.loads(s) for s in (_D11_ROOT/'papers/D11/audit_log.jsonl').read_text().splitlines() if s.strip()]
        clusters=_surface_json.loads((_D11_ROOT/'papers/claim_clusters.json').read_text())
        sentences=bg.extract_sentence_nodes(); audits=bg.extract_audit_event_nodes()
        cluster_nodes=bg.extract_claim_cluster_nodes()
        current={s['id'] for s in review['sentences']}
        expected=current|set(prose.get('sentences',{}))
        actual={s['id']:s for s in sentences if s['id'].startswith('sentence:D11:')}
        assert set(actual)==expected
        for s in review['sentences']:
            assert actual[s['id']]['meta']['quote']==s['quote']
        audit_by_id={n['id']:n for n in audits}
        for event in events:
            if event.get('id'):
                assert audit_by_id[event['id']]['meta']==event.get('meta',{})
        paper_nodes=bg.extract_paper_nodes(); formulas=bg.extract_formula_nodes()
        claim_nodes=bg.extract_paper_claim_nodes()
        ids={n['id'] for n in sentences+audits+cluster_nodes+paper_nodes+formulas+claim_nodes}
        members=bg.extract_member_of_edges(ids); logged=bg.extract_logged_by_edges(ids)
        expected_members={(m,c['id']) for c in clusters['clusters'] for m in c.get('members',[])
                          if m.startswith('sentence:D11:') and m in ids and c['id'] in ids}
        assert {(e['source'],e['target']) for e in members if e['source'].startswith('sentence:D11:')}==expected_members
        for event in events:
            target=event.get('meta',{}).get('target_id')
            if event.get('id') and target and target in ids:
                assert any(e['source']==event['id'] and e['target']==target for e in logged)
        # Existing backing chains remain sentence-owned. Missing targets retain
        # the existing extractor's explicit missing-target semantics; registration
        # cannot manufacture a repair of historical sentence evidence.
        backed=bg.extract_backed_by_edges(ids)
        assert all(not e['source'].startswith('claim:D11:') for e in backed+members)
        assert all(not e['target'].startswith('claim:D11:') for e in logged)
        wanted_links=sum(1 for s in review['sentences']
                         for link in (s.get('chain_proposed') or {}).get('links',[]) or []
                         if link.get('kind') and link.get('target'))
        assert sum(e['source'] in current for e in backed)==wanted_links


@pytest.fixture(scope='class')
def _d11_s1_owner():
    # Import audit: static register/constants, readonly mapping parser, roster,
    # sentence-state definitions and TeX regexes only. No derive/main/T3 writer.
    from scripts import aristotle_usage_by_bundle as owner
    assert _SurfacePath(owner.__file__).resolve()==_D11_ROOT/'scripts/aristotle_usage_by_bundle.py'
    return owner


class TestD11WholeS1Consumer:
    """Actual existing pure functions; inert fixtures are not production poisons."""

    def test_live_bundle_receives_direct_D11_and_D12_entries(self,_d11_s1_owner):
        owner=_d11_s1_owner
        sources=owner.bundle_source_papers()
        declared=owner.bundle_declared_modules(sources)
        assert list(declared)==owner.ALL_BUNDLES
        assert set(declared['D11'])==set(_d11_registry()['D11']['lean_modules'])
        assert len(declared['D11'])==19
        assert set(_d11_registry()['D12']['lean_modules']) <= declared['D12']
        assert len(declared['D12'])>=3

    def test_actual_D11_relative_and_full_homes_resolve_all19(self,_d11_s1_owner):
        owner=_d11_s1_owner
        records=_surface_json.loads((_D11_ROOT/'lean/lean_deps.json').read_text())
        homes=_d11_registry()['D11']['lean_modules']
        indexed={'SKEFTHawking.'+h for h in homes}
        assert indexed <= {r['module'] for r in records}
        assert owner.expand_short_modules(set(homes),records)==indexed
        assert owner.expand_short_modules(indexed,records)==indexed
        # This is the real live routing+expansion composition, not only a direct
        # function fixture with the19 values manually supplied.
        live=owner.bundle_declared_modules(owner.bundle_source_papers())
        assert owner.expand_short_modules(live['D11'],records)==indexed
        d12={'SKEFTHawking.'+h for h in _d11_registry()['D12']['lean_modules']}
        assert d12 <= owner.expand_short_modules(live['D12'],records)

    @pytest.mark.parametrize('inputs,expected',[
        ({'Honeycomb'},{'SKEFTHawking.GrapheneBand.Honeycomb','SKEFTHawking.Other.Honeycomb','Foreign.GrapheneBand.Honeycomb'}),
        ({'GrapheneBand.Honeycomb'},{'SKEFTHawking.GrapheneBand.Honeycomb'}),
        ({'SKEFTHawking.GrapheneBand.Honeycomb'},{'SKEFTHawking.GrapheneBand.Honeycomb'}),
        ({'Foreign.GrapheneBand.Honeycomb'},{'Foreign.GrapheneBand.Honeycomb'}),
        ({'Unindexed.GrapheneBand.Honeycomb'},set()),
        ({'GrapheneBand.Unknown'},set()),
        ({'SKEFTHawking.Unknown.Honeycomb'},set()),
        ({'honeycomb'},set()),
        (set(),set()),
        ({'Unknown'},set()),
    ])
    def test_qualified_exactness_and_historical_short_collision_union(self,_d11_s1_owner,inputs,expected):
        records=[{'module':m} for m in ['SKEFTHawking.GrapheneBand.Honeycomb',
                 'SKEFTHawking.Other.Honeycomb','Foreign.GrapheneBand.Honeycomb']]
        assert _d11_s1_owner.expand_short_modules(inputs,records)==expected

    def test_full_indexed_precedence_over_relative_interpretation(self,_d11_s1_owner):
        records=[{'module':'GrapheneBand.Honeycomb'},
                 {'module':'SKEFTHawking.GrapheneBand.Honeycomb'}]
        assert _d11_s1_owner.expand_short_modules({'GrapheneBand.Honeycomb'},records)=={'GrapheneBand.Honeycomb'}

    def test_duplicate_records_and_mixed_name_forms_are_idempotent(self,_d11_s1_owner):
        name='SKEFTHawking.GrapheneBand.Honeycomb'
        records=[{'module':name},{'module':name},{'module':'Foreign.X.Honeycomb'}]
        assert _d11_s1_owner.expand_short_modules({'GrapheneBand.Honeycomb',name},records)=={name}
        assert _d11_s1_owner.expand_short_modules({'Honeycomb','GrapheneBand.Honeycomb',name},records)=={name,'Foreign.X.Honeycomb'}

    def test_all_current_last_component_inputs_keep_original_union(self,_d11_s1_owner):
        records=_surface_json.loads((_D11_ROOT/'lean/lean_deps.json').read_text())
        expected={}
        for row in records:
            expected.setdefault(row['module'].rsplit('.',1)[-1],set()).add(row['module'])
        for short,modules in expected.items():
            assert _d11_s1_owner.expand_short_modules({short},records)==modules

    def test_direct_mapped_and_extra_union_without_input_or_roster_mutation(self,_d11_s1_owner,monkeypatch):
        owner=_d11_s1_owner
        registry={'D11':{'lean_modules':['direct','shared']},
                  'legacy':{'lean_modules':['mapped','shared']},
                  'UNKNOWN_BUNDLE':{'lean_modules':['foreign']}}
        extras={'D11':['extra','shared'],'D12':['only_extra'],'UNKNOWN_BUNDLE':['foreign_extra']}
        sources={'D11':['legacy','D11','missing','legacy'],'UNKNOWN_BUNDLE':['legacy']}
        before=_surface_json.dumps({'registry':registry,'extras':extras,'sources':sources},sort_keys=True)
        monkeypatch.setattr(owner,'PAPER_DEPENDENCIES',registry)
        monkeypatch.setattr(owner,'BUNDLE_EXTRA_LEAN_MODULES',extras)
        result=owner.bundle_declared_modules(sources)
        assert list(result)==owner.ALL_BUNDLES
        assert result['D11']=={'direct','shared','mapped','extra'}
        assert result['D12']=={'only_extra'}
        assert 'UNKNOWN_BUNDLE' not in result
        assert all(not result[b] for b in owner.ALL_BUNDLES if b not in {'D11','D12'})
        assert before==_surface_json.dumps({'registry':registry,'extras':extras,'sources':sources},sort_keys=True)
        # Even a missing legacy mapping is not permission to drop a direct home.
        assert owner.bundle_declared_modules({})['D11']=={'direct','shared','extra'}

    def test_all21_actual_legacy_contributions_survive_direct_union(self,_d11_s1_owner):
        owner=_d11_s1_owner;sources=owner.bundle_source_papers()
        actual=owner.bundle_declared_modules(sources)
        for bundle in owner.ALL_BUNDLES:
            legacy=set()
            for source in sources.get(bundle,[]):
                legacy.update(owner.PAPER_DEPENDENCIES.get(source,{}).get('lean_modules',[]))
            direct=set(owner.PAPER_DEPENDENCIES.get(bundle,{}).get('lean_modules',[]))
            extra=set(owner.BUNDLE_EXTRA_LEAN_MODULES.get(bundle,[]))
            assert actual[bundle]==legacy|direct|extra
# r24 exact-source dashboard controls. These call the real owners; cached graph
# data is an explicit inert boundary, never an extraction or native receipt.
@pytest.fixture
def d11_dashboard_inert(monkeypatch):
    import importlib
    import subprocess
    import sys
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    monkeypatch.syspath_prepend(str(root / "scripts"))
    dash = importlib.import_module("provenance_dashboard")
    assert Path(dash.__file__).resolve() == root / "scripts/provenance_dashboard.py"
    observed = {"graph_calls": 0, "graph": {"nodes": [], "links": []}}

    def forbidden(*args, **kwargs):
        raise AssertionError("inert dashboard control reached extraction/native/PG")

    def graph():
        observed["graph_calls"] += 1
        return observed["graph"]

    monkeypatch.setattr(dash, "get_cached_graph", graph)
    monkeypatch.setattr(dash, "_schedule_pg_sync", forbidden)
    monkeypatch.setattr(subprocess, "run", forbidden)
    monkeypatch.setattr(subprocess, "Popen", forbidden)
    for name in ("scripts.build_graph", "build_graph"):
        module = importlib.import_module(name)
        monkeypatch.setattr(module, "build_graph_json", forbidden)
    for name in ("scripts.extract_lean_deps", "extract_lean_deps"):
        module = importlib.import_module(name)
        monkeypatch.setattr(module, "load_lean_deps", forbidden)
        monkeypatch.setattr(module, "_run_extraction", forbidden)
    return dash, observed


@pytest.fixture
def d11_dashboard_source_tree(d11_dashboard_inert, tmp_path, monkeypatch):
    from src.core import provenance, constants
    dash, observed = d11_dashboard_inert
    lean = tmp_path / "lean/SKEFTHawking"
    lean.mkdir(parents=True)
    paper = tmp_path / "papers/D11"
    paper.mkdir(parents=True)
    (paper / "paper_draft.tex").write_text("D11 source fixture", encoding="utf-8")
    monkeypatch.setattr(dash, "PROJECT_ROOT", tmp_path)
    monkeypatch.setattr(provenance, "PAPER_DEPENDENCIES", {
        "D11": {"title": "D11 fixture", "lean_modules": [], "formulas": [],
                "platforms": [], "key_claims": []}})
    monkeypatch.setattr(provenance, "PARAMETER_PROVENANCE", {})
    monkeypatch.setattr(constants, "ARISTOTLE_THEOREMS", {"observed": "fixture-run"})
    monkeypatch.setattr(constants, "AXIOM_METADATA", {})
    return dash, observed, lean, provenance, constants


class TestD11DashboardModuleConsumers:
    @staticmethod
    def rows(context, names):
        dash, observed, lean, provenance, constants = context
        provenance.PAPER_DEPENDENCIES["D11"]["lean_modules"] = names
        papers = dash.load_paper_claims()
        assert len(papers) == 1
        assert observed["graph_calls"] >= 1
        return papers[0]["lean_module_details"]

    def test_real_declared_population_and_all_nineteen_homes(self, d11_dashboard_inert):
        from pathlib import Path
        from src.core.provenance import PAPER_DEPENDENCIES
        from src.core.constants import ARISTOTLE_THEOREMS
        dash, observed = d11_dashboard_inert
        lean = Path(dash.PROJECT_ROOT) / "lean/SKEFTHawking"
        actual = {p["name"]: p for p in dash.load_paper_claims()}
        inputs = 0
        for paper, entry in PAPER_DEPENDENCIES.items():
            names = entry.get("lean_modules", [])
            card = actual.get(paper)
            if card is None:
                # Registry identity is not a promise of an on-disk paper/card.
                assert not (Path(dash.PROJECT_ROOT) / "papers" / paper / "paper_draft.tex").is_file()
            else:
                assert [r["module"] for r in card["lean_module_details"]] == names
            for position, name in enumerate(names):
                key = name.replace("/", ".").removeprefix("SKEFTHawking.")
                path = lean.joinpath(*key.split(".")).with_suffix(".lean")
                if not path.is_file():
                    choices = list(lean.rglob(key + ".lean"))
                    assert len(choices) == 1
                    path = choices[0]
                lines = path.read_text(encoding="utf-8").splitlines()
                theorem_lines = [s for s in lines if s.startswith("theorem ")]
                aristotle = sum(s.split()[1].split("(")[0].split(":")[0].strip()
                                in ARISTOTLE_THEOREMS for s in theorem_lines)
                if card is not None:
                    row = card["lean_module_details"][position]
                    assert row["counts_measured"] is True
                    assert (row["theorems"], row["aristotle"]) == (len(theorem_lines), aristotle)
                inputs += 1
        assert inputs == 67
        rows = actual["D11"]["lean_module_details"]
        assert len(rows) == 19
        nested = [r for r in rows if "." in r["module"]]
        assert len(nested) == 9 and all(r["theorems"] > 0 for r in nested)
        zero = next(r for r in rows if r["module"] == "BlochBundle")
        assert zero["counts_measured"] and zero["theorems"] == zero["aristotle"] == 0
        assert observed["graph_calls"] == 1

    @pytest.mark.parametrize("name", ["Nested.Exact", "SKEFTHawking.Nested.Exact",
                                     "Nested/Exact", "SKEFTHawking/Nested/Exact", "Exact"])
    def test_supported_spellings_read_actual_nested_source(self, d11_dashboard_source_tree, name):
        context = d11_dashboard_source_tree
        lean = context[2]
        (lean / "Nested").mkdir()
        (lean / "Nested/Exact.lean").write_text(
            "theorem observed : True := trivial\nlemma ignored : True := trivial\n"
            "  theorem indented : True := trivial\ntheorem other(x : Nat) : x=x := rfl\n")
        row, = self.rows(context, [name])
        assert row["module"] == name
        assert row["counts_measured"] and row["count_reason"] == "readable_source"
        assert (row["theorems"], row["aristotle"]) == (2, 1)
        assert row["source"] == "lean/SKEFTHawking/Nested/Exact.lean"

    def test_top_level_precedence_collisions_and_no_qualified_tail_guess(self, d11_dashboard_source_tree):
        context = d11_dashboard_source_tree
        lean = context[2]
        for folder in ("A", "B"):
            (lean / folder).mkdir()
            (lean / folder / "Same.lean").write_text("theorem nested : True := trivial\n")
        rows = self.rows(context, ["Same", "A.Same", "Foreign.Same", "Missing.A.Same"])
        assert rows[0]["counts_measured"] is False
        assert rows[1]["counts_measured"] and rows[1]["theorems"] == 1
        assert all(not r["counts_measured"] and r["theorems"] is None
                   and r["aristotle"] is None for r in rows[2:])
        (lean / "Same.lean").write_text("-- successful readable zero\n")
        row, = self.rows(context, ["Same"])
        assert row["counts_measured"] and row["theorems"] == row["aristotle"] == 0
        assert row["source"] == "lean/SKEFTHawking/Same.lean"

    @pytest.mark.parametrize("name", [None, 7, True, "", "/Exact", "../Exact",
                                     "Nested..Exact", "Nested/../Exact", "Nested\\Exact",
                                     "Nested.\x00Exact", "Nested. Exact", "Exact.lean"])
    def test_invalid_names_retain_unknown_row(self, d11_dashboard_source_tree, name):
        row, = self.rows(d11_dashboard_source_tree, [name])
        assert row["module"] == name
        assert row["counts_measured"] is False
        assert row["theorems"] is row["aristotle"] is None
        assert row["count_reason"] == "invalid_module_name"

    def test_missing_zero_encoding_and_containment_are_distinct(self, d11_dashboard_source_tree, tmp_path):
        context = d11_dashboard_source_tree
        lean = context[2]
        (lean / "Zero.lean").write_text("-- zero\n")
        (lean / "Bad.lean").write_bytes(b"\xff")
        outside = tmp_path / "outside.lean"
        outside.write_text("theorem outside : True := trivial\n")
        (lean / "Escape.lean").symlink_to(outside)
        (lean / "Inside.lean").symlink_to(lean / "Zero.lean")
        rows = self.rows(context, ["Missing", "Zero", "Bad", "Escape", "Inside"])
        assert [r["counts_measured"] for r in rows] == [False, True, False, False, True]
        assert [r["theorems"] for r in rows] == [None, 0, None, None, 0]
        assert rows[2]["count_reason"] == "invalid_source_encoding"
        assert rows[3]["count_reason"] == "source_outside_root"

    def test_unreadable_source_does_not_abort_other_rows(self, d11_dashboard_source_tree, monkeypatch):
        from pathlib import Path
        context = d11_dashboard_source_tree
        lean = context[2]
        denied = lean / "Denied.lean"
        denied.write_text("theorem present : True := trivial\n")
        (lean / "Good.lean").write_text("theorem observed : True := trivial\n")
        read = Path.read_text
        def guarded(path, *args, **kwargs):
            if path == denied:
                raise PermissionError("explicit read-denied source fixture")
            return read(path, *args, **kwargs)
        monkeypatch.setattr(Path, "read_text", guarded)
        rows = self.rows(context, ["Denied", "Good"])
        assert not rows[0]["counts_measured"] and rows[0]["theorems"] is None
        assert rows[0]["count_reason"] == "unreadable_source"
        assert rows[1]["counts_measured"] and rows[1]["theorems"] == 1

    def test_index_failure_preserves_all_declared_unknown_rows(self, d11_dashboard_source_tree, monkeypatch):
        import check_bundle_source_freshness as owner
        context = d11_dashboard_source_tree
        def unavailable(*args, **kwargs):
            raise OSError("explicit index fixture unavailable")
        monkeypatch.setattr(owner, "_lean_module_index", unavailable)
        rows = self.rows(context, ["First", "Second"])
        assert [r["module"] for r in rows] == ["First", "Second"]
        assert all(not r["counts_measured"] and r["theorems"] is None
                   and r["count_reason"] == "index_unavailable" for r in rows)

    @pytest.mark.parametrize("source", ["Nested.Exact", "SKEFTHawking.Nested.Exact",
                                       "Nested/Exact", None])
    def test_live_exact_axiom_join_and_old_cache_unknown(self, d11_dashboard_source_tree, source):
        dash, observed, lean, provenance, constants = d11_dashboard_source_tree
        (lean / "Nested").mkdir()
        (lean / "Nested/Exact.lean").write_text("axiom supplied : True\n")
        (lean / "Nested/Sibling.lean").write_text("-- sibling\n")
        provenance.PAPER_DEPENDENCIES["D11"]["lean_modules"] = ["Nested.Exact"]
        provenance.PAPER_DEPENDENCIES["OTHER"] = {"title": "Sibling only", "lean_modules": ["Nested.Sibling"]}
        meta = {"module": "Nested"}
        if source is not None:
            meta["source_module"] = source
        observed["graph"] = {"nodes": [{"id": "lean:Example.supplied", "type": "LeanAxiom",
                                       "name": "supplied", "meta": meta}], "links": []}
        card, = dash.load_proof_architecture()["axiom_cards"]
        assert card["module"] == "Nested"
        if source is None:
            assert card["papers"] == [] and card["papers_measured"] is False
            assert card["papers_reason"] == "exact_source_unavailable"
        else:
            assert card["papers"] == ["D11 fixture"] and card["papers_measured"] is True
        assert "Sibling only" not in card["papers"]

    def test_historical_empty_and_unresolved_registry_coverage(self, d11_dashboard_source_tree):
        dash, observed, lean, provenance, constants = d11_dashboard_source_tree
        (lean / "Nested").mkdir()
        (lean / "Nested/Exact.lean").write_text("-- exact\n")
        constants.AXIOM_METADATA.update({"old": {"module": "SKEFTHawking.Nested.Exact", "eliminability": "removed"}})
        provenance.PAPER_DEPENDENCIES["D11"]["lean_modules"] = ["Nested.Exact"]
        result = dash.load_proof_architecture()
        card, = result["axiom_cards"]
        assert card["papers_measured"] and card["papers"] == ["D11 fixture"]
        provenance.PAPER_DEPENDENCIES["D11"]["lean_modules"] = []
        card, = dash.load_proof_architecture()["axiom_cards"]
        assert card["papers_measured"] and card["papers"] == []
        provenance.PAPER_DEPENDENCIES["D11"]["lean_modules"] = ["Foreign.Exact"]
        result = dash.load_proof_architecture()
        card, = result["axiom_cards"]
        assert not card["papers_measured"] and card["papers"] == []
        assert result["module_coverage"]["unresolved"] == [{"paper": "D11", "module": "Foreign.Exact", "reason": "unresolved_module"}]


# Physical lattice controls use actual ideal bonds/k/F and an independent matrix
# residual/Gram reference.  The old free-f scalar controls remain unchanged.
def _bernal_physical_matrix(c, u, g, t, a, angle, eta, wavevector):
    aa, alpha = cv(c, a), cv(c, angle)
    co, si, root = c.cos(alpha), c.sin(alpha), c.sqrt(3)
    base = ((aa, c.mpf(0)), (-aa/2, eta*root*aa/2), (-aa/2, -eta*root*aa/2))
    bonds = [(co*x-si*y, si*x+co*y) for x, y in base]
    kx, ky = wavevector(c, bonds) if callable(wavevector) else tuple(cv(c, z) for z in wavevector)
    phases = [kx*x+ky*y for x, y in bonds]
    re = cv(c, t)*sum((c.cos(phi) for phi in phases), c.mpf(0))
    im = cv(c, t)*sum((c.sin(phi) for phi in phases), c.mpf(0))
    Fk = c.mpc(re, im); fc = c.conj(Fk) if isinstance(c, MPContext) else conj(c, Fk)
    uu, gg, zero = cv(c, u), cv(c, g), c.mpc(0)
    return [[c.mpc(uu), Fk, zero, zero], [fc, c.mpc(uu), c.mpc(gg), zero],
            [zero, c.mpc(gg), c.mpc(-uu), Fk], [zero, zero, fc, c.mpc(-uu)]]


def _bernal_node_wavevector(j, k, n):
    def wavevector(c, bonds):
        a1 = tuple(bonds[0][i]-bonds[2][i] for i in range(2))
        a2 = tuple(bonds[1][i]-bonds[2][i] for i in range(2))
        det = a1[0]*a2[1]-a1[1]*a2[0]
        theta1, theta2 = 2*c.pi*j/n, 2*c.pi*k/n
        return ((a2[1]*theta1-a1[1]*theta2)/det,
                (-a2[0]*theta1+a1[0]*theta2)/det)
    return wavevector


def _bernal_matrix_gap_reference(u, g, t, a, angle, eta, wavevector):
    model = lambda c: _bernal_physical_matrix(c, u, g, t, a, angle, eta, wavevector)
    scale = abs(exact(u))+abs(exact(g))+3*abs(exact(t))
    spectra = hermitian_reference(model, scale, Q(1, 10**12))
    lo, hi = spectra[2]
    assert lo > 0, 'positive-gap reference must not hide an unresolved zero root'
    return 4*lo*lo, 4*hi*hi, spectra


def test_bernal_physical_domain_both_regimes_and_scalar_obstruction():
    interior = F.bernal_lattice_gap_sq(Q(1,2), 1, 1, abs_error=Q(1,10**12), return_diagnostics=True)
    boundary = F.bernal_lattice_gap_sq(Q(1,2), 1, Q(1,10), abs_error=Q(1,10**12), return_diagnostics=True)
    assert interior['value'] == .5 and interior['regime'] == 'interior'
    assert interior['x_star'] == Q(3,8) and interior['y'] == Q(3,8)
    assert boundary['regime'] == 'boundary' and boundary['y'] == Q(9,100)
    lo, hi, _ = _bernal_matrix_gap_reference(Q(1,2), 1, Q(1,10), 1, 0, 1, (0,0))
    assert max(abs(exact(boundary['value'])-lo), abs(exact(boundary['value'])-hi)) <= Q(1,10**12)
    assert .5 < boundary['value'] < 1
    assert F.bernal_lattice_gap_sq(.5, 1, 0, abs_error=1e-12) == 1
    assert F.bernal_lattice_gap_sq(Q(1,2), 0, Q(1,10), abs_error=1e-12) == float(Q(4,25))
    # Exact rational branch test straddles the mathematical algebraic threshold.
    below = F.bernal_lattice_gap_sq(.5, 1, Q(1,5), abs_error=1e-12, return_diagnostics=True)
    above = F.bernal_lattice_gap_sq(.5, 1, Q(21,100), abs_error=1e-12, return_diagnostics=True)
    assert below['regime'] == 'boundary' and above['regime'] == 'interior'


def test_bernal_physical_zeros_signs_intersections_and_energy_scaling():
    for u, g, t in [(0,0,0),(0,0,1),(0,1,1),(.5,0,1),(.5,0,Q(1,6))]:
        assert F.bernal_lattice_gap_sq(u,g,t,abs_error=1e-12) == 0.
    base = F.bernal_lattice_gap_sq(.5,1,Q(1,10),abs_error=1e-12)
    for su in (-1,1):
        for sg in (-1,1):
            for st in (-1,1):
                got = F.bernal_lattice_gap_sq(su*Q(1,2),sg,st*Q(1,10),abs_error=1e-12)
                assert got == base
    scaled = F.bernal_lattice_gap_sq(1,2,Q(1,5),abs_error=1e-12)
    assert abs(exact(scaled)-4*exact(base)) <= Q(1,10**12)
    with pytest.raises(ValueError): F.bernal_full_gap_sq(0,0)


@pytest.mark.parametrize('a,angle,eta', [(1,0,1),(Q(7,10),Q(2,5),-1),(2,Q(-1,3),1)])
def test_bernal_actual_rotated_reflected_geometry_minimizing_k_reference(a, angle, eta):
    result = F.bernal_lattice_minimizer(.5, 1, 1, a, angle=angle, handedness=eta,
        coordinate_error=Q(1,10**7), energy_error=Q(1,10**8), work_limit=100000)
    assert result['gap_sq'] == .5 and result['regime'] == 'interior'
    assert result['coordinate_bound'] <= Q(1,10**7) and result['energy_bound'] <= Q(1,10**8)
    # Direct binary-proposal distance to EVERY corner of the returned rational box.
    for x in result['k_box'][0]:
        for y in result['k_box'][1]:
            dist2 = (exact(result['k'][0])-x)**2+(exact(result['k'][1])-y)**2
            assert dist2 <= result['coordinate_bound']**2
    lo, hi, _ = _bernal_matrix_gap_reference(.5,1,1,a,angle,eta,result['k'])
    assert max(abs(lo-Q(1,2)),abs(hi-Q(1,2))) <= result['energy_bound']+Q(1,10**12)
    # Independent monotone turn/root check: no copied producer inversion helper.
    c=oracle_context(384); left,right=result['turn_interval']
    z=(c.sqrt(iv(c,Q(3,8)))-1)/2
    lc=c.cos(2*c.pi*iv(c,left));rc=c.cos(2*c.pi*iv(c,right))
    assert bounds(lc)[0] >= bounds(z)[1] and bounds(rc)[1] <= bounds(z)[0]
    # Reflection/rotation/rescaling are actually present in the bond Gram data.
    bonds=result['bonds']; ci=oracle_context(384)
    for d in bonds:
        xx=ci.mpf([iv(ci,d[0][0]),iv(ci,d[0][1])]);yy=ci.mpf([iv(ci,d[1][0]),iv(ci,d[1][1])])
        assert bounds(xx*xx+yy*yy)[0] <= exact(a)**2 <= bounds(xx*xx+yy*yy)[1]


def test_bernal_minimizer_boundary_dirac_zero_and_length_scaling():
    kw=dict(coordinate_error=1e-7,energy_error=1e-8,work_limit=100000)
    gamma_point=F.bernal_lattice_minimizer(.5,1,Q(1,10),1,**kw)
    assert gamma_point['k'] == (0.,0.) and gamma_point['regime'] == 'boundary'
    zero=F.bernal_lattice_minimizer(.5,1,0,1,**kw)
    assert zero['k'] == (0.,0.) and zero['gap_sq'] == 1
    dirac=F.bernal_lattice_minimizer(0,1,1,1,**kw)
    assert dirac['gap_sq'] == 0 and dirac['turn_interval'] == (Q(1,3),Q(1,3))
    first=F.bernal_lattice_minimizer(.5,1,1,1,**kw)
    second=F.bernal_lattice_minimizer(.5,1,1,2,**kw)
    assert all(abs(exact(x)-2*exact(y)) <= Q(1,10**7) for x,y in zip(first['k'],second['k']))


def test_bernal_grid_actual_positive_N_nodes_covering_and_independent_minimum():
    for n in (1,2,3):
        result=F.bernal_lattice_grid_gap_sq(.5,1,1,n,abs_error=100,work_limit=10000,return_diagnostics=True)
        assert result['visited_count'] == n*n and result['trig_entries'] == n
        assert result['work_used'] == n*n+n
        assert result['interval'][0] <= Q(1,2) <= result['interval'][1]
        assert result['absolute_error'] <= 100
        node_boxes=[_bernal_matrix_gap_reference(.5,1,1,1,0,1,_bernal_node_wavevector(j,k,n))[:2]
                    for j in range(n) for k in range(n)]
        lo,hi=min(a for a,b in node_boxes),min(b for a,b in node_boxes)
        sl,sh=result['sampled_interval']
        assert max(lo,sl) <= min(hi,sh)
        assert max(abs(exact(result['value'])-result['interval'][0]),abs(exact(result['value'])-result['interval'][1])) <= 100
        assert result['finite_mesh_is_continuous_minimum'] is False
    # Divisible-by-three is valid for this physical torus, without north-pole policy.
    assert F.bernal_lattice_grid_gap_sq(0,1,1,3,abs_error=1e-12,work_limit=100) == 0
    assert F.bernal_lattice_grid_gap_sq(.5,1,0,3,abs_error=1e-12,work_limit=100) == 1
    with pytest.raises(F._D11Unresolved): F.bernal_lattice_grid_gap_sq(.5,1,1,1,abs_error=1e-12,work_limit=100)


@pytest.mark.parametrize('bad',[True,False,float('nan'),float('inf'),1j,np.array([1])])
def test_bernal_new_exact_admission_never_projects_bad_parameters(bad):
    with pytest.raises(ValueError): F.bernal_lattice_gap_sq(.5,1,bad,abs_error=1e-12)
    with pytest.raises(ValueError): F.bernal_lattice_minimizer(.5,1,1,bad,coordinate_error=1e-7,energy_error=1e-8,work_limit=100)
    with pytest.raises(ValueError): F.bernal_lattice_grid_gap_sq(.5,1,1,bad,abs_error=1,work_limit=100)


def test_bernal_finite_work_precision_allocation_and_representation_refusals(monkeypatch):
    calls=[];original=F._d11_sincos
    def observed(*args,**kw):
        calls.append(kw);return original(*args,**kw)
    monkeypatch.setattr(F,'_d11_sincos',observed)
    with pytest.raises(F._D11Unresolved) as fail:
        F.bernal_lattice_grid_gap_sq(.5,1,1,10**8,abs_error=1,work_limit=1)
    assert not calls and fail.value.history and fail.value.stage == 'physical_grid'
    with pytest.raises(F._D11Unresolved):
        F.bernal_lattice_minimizer(.5,1,1,1,coordinate_error=1e-8,energy_error=1e-9,work_limit=1)
    with pytest.raises(F._D11Unresolved): F.bernal_lattice_gap_sq(Q(1,2**600),1,1,abs_error=Q(1,2**1300))
    original_schedule=F._d11_schedule
    monkeypatch.setattr(F,'_d11_schedule',lambda bits:(2,))
    with pytest.raises(F._D11Unresolved) as precision:
        F.bernal_lattice_gap_sq(.5,1,Q(1,10),abs_error=Q(1,10**40))
    assert precision.value.history[-1]['precision'] == 2
    monkeypatch.setattr(F,'_d11_schedule',original_schedule)
    import mpmath.ctx_iv as iv_owner
    def allocation_failure():raise MemoryError('independent interval context allocation failure')
    monkeypatch.setattr(iv_owner,'MPIntervalContext',allocation_failure)
    with pytest.raises(F._D11Unresolved) as allocation:
        F.bernal_lattice_gap_sq(.5,1,1,abs_error=1e-12)
    assert isinstance(allocation.value.__cause__,MemoryError)
    assert all(row['cause']=='MemoryError' for row in allocation.value.history)


# Deliberately called only under a later ROOT source-mutation grant. No decorator
# or automatic test invokes this journalled production0/nonzero/restored0 helper.
_BERNAL_PHYSICAL_MUTATIONS = (
    ('scalar_alias','_d11_bl_model',"regime, y, exact_gap = 'boundary', X, None", "regime, y, exact_gap = 'boundary', X, 4*v*h/c",'test_bernal_physical_domain_both_regimes_and_scalar_obstruction'),
    ('lost_full_gap_factor','_d11_bl_model','4*v*h/c','v*h/c','test_bernal_physical_domain_both_regimes_and_scalar_obstruction'),
    ('zero_hopping_fake_zero','_d11_bl_model',"'zero_hopping', Q(0), 4*v","'zero_hopping', Q(0), Q(0)",'test_bernal_physical_domain_both_regimes_and_scalar_obstruction'),
    ('skipped_grid_node','bernal_lattice_grid_gap_sq','for k in range(n):','for k in range(n if n == 1 else n-1):','test_bernal_grid_actual_positive_N_nodes_covering_and_independent_minimum'),
    ('dropped_covering','bernal_lattice_grid_gap_sq','max(Q(0), low-cover_upper)','max(Q(0), low)','test_bernal_grid_actual_positive_N_nodes_covering_and_independent_minimum'),
)


def _actual_bernal_physical_production_control(index):
    """SOURCE construction only in R58; actual later run must retain exact receipts."""
    import ast,datetime,hashlib,json,os,subprocess,sys
    from pathlib import Path
    from scripts import seed_journal as journal
    label,owner,old,new,consumer=_BERNAL_PHYSICAL_MUTATIONS[index]
    root=Path(__file__).resolve().parents[1]
    path=root/('src/core/provenance.py' if owner is None else 'src/core/formulas.py')
    def snap():
        st=path.stat();return dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),mode=st.st_mode,mtime_ns=st.st_mtime_ns)
    def mutate(text):
        if owner is None:
            assert text.count(old)==1
            return text.replace(old,new,1)
        fn=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==owner)
        lines=text.splitlines(keepends=True);body=''.join(lines[fn.lineno-1:fn.end_lineno])
        assert body.count(old)==1,(owner,old)
        return ''.join(lines[:fn.lineno-1])+body.replace(old,new,1)+''.join(lines[fn.end_lineno:])
    code=("import pathlib,runpy;from src.core import formulas as F;"
          "assert pathlib.Path(F.__file__).resolve()==pathlib.Path('src/core/formulas.py').resolve();"
          "ns=runpy.run_path('tests/test_d11_formula_surface.py');"+f"ns[{consumer!r}]()")
    argv=[sys.executable,'-B','-c',code]
    def run():
        start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        r=subprocess.run(argv,cwd=root,env=dict(os.environ,PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True)
        return dict(start=start,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,argv=argv,cwd=str(root))
    before=snap();baseline=run();assert baseline['returncode']==0,baseline
    with journal.seeded_mutation(path,mutate,reason='Bernal physical '+label):
        seeded=snap();red=run();assert red['returncode']!=0 and 'AssertionError' in red['stderr'],red
        assert 'SyntaxError' not in red['stderr'] and 'ImportError' not in red['stderr']
    restored=snap();assert restored==before
    green=run();assert green['returncode']==0,green
    assert not list(journal.JOURNAL_DIR.glob('*.json'))
    result=dict(label=label,owner=owner,consumer=consumer,before=before,seeded=seeded,restored=restored,baseline=baseline,red=red,green=green)
    print('D11_BERNAL_PHYSICAL_CONTROL='+json.dumps(result));return result



def test_bernal_quarterpoint_equality_and_near_boundary_coordinate_energy():
    # g=0,u=t: exact target cos=0, root turn1/4, including a quarter equality.
    result=F.bernal_lattice_minimizer(.5,0,.5,1,coordinate_error=1e-7,energy_error=1e-8,work_limit=100000)
    assert result['turn_interval'][0] <= Q(1,4) <= result['turn_interval'][1]
    assert result['gap_sq'] == 0 and result['energy_bound'] <= exact(1e-8)
    # Approaching Gamma from the admissible interior does not become a clamp.
    near=F.bernal_lattice_minimizer(.5,1,Q(21,100),1,coordinate_error=1e-7,energy_error=1e-8,work_limit=100000)
    assert near['regime'] == 'interior' and near['turn_interval'][1] > 0
    assert near['y'] < near['X'] and near['coordinate_bound'] <= exact(1e-7)


def test_bernal_physical_matrix_unitary_orientation_and_all_band_boxes():
    result=F.bernal_lattice_minimizer(.5,-1,-1,1,angle=Q(1,3),handedness=-1,
        coordinate_error=1e-7,energy_error=1e-8,work_limit=100000)
    lo,hi,spectra=_bernal_matrix_gap_reference(.5,-1,-1,1,Q(1,3),-1,result['k'])
    for actual,ref in zip(result['ordered_bands'],spectra):
        assert max(actual[0],ref[0]) <= min(actual[1],ref[1])
    assert max(abs(lo-Q(1,2)),abs(hi-Q(1,2))) <= result['energy_bound']+Q(1,10**12)
    # Separate actual-bond and diagonal-gauge construction, not eigenvalue equality.
    c=oracle_context(384);a=cv(c,1);alpha=cv(c,Q(1,3));root=c.sqrt(3)
    co,si=c.cos(alpha),c.sin(alpha)
    base=((a,c.mpf(0)),(-a/2,-root*a/2),(-a/2,root*a/2))
    bonds=[(co*x-si*y,si*x+co*y) for x,y in base]
    # Off-minimum physical wavevector gives a genuinely complex common phase;
    # the minimizing anti-diagonal phase path alone can have real hopping.
    arbitrary_k=(Q(7,10),Q(-2,5))
    k=tuple(cv(c,z) for z in arbitrary_k)
    phase=[k[0]*d[0]+k[1]*d[1] for d in bonds]
    exp=lambda x:c.mpc(c.cos(x),c.sin(x))
    f=-1*(1+exp(phase[0]-phase[2])+exp(phase[1]-phase[2]))
    p=exp(phase[2]);D=(p,c.mpc(1),c.mpc(1),conj(c,p));z=c.mpc(0);u=cv(c,.5);g=cv(c,-1)
    H=[[c.mpc(u),f,z,z],[conj(c,f),c.mpc(u),c.mpc(g),z],
       [z,c.mpc(g),c.mpc(-u),f],[z,z,conj(c,f),c.mpc(-u)]]
    physical=_bernal_physical_matrix(c,.5,-1,-1,1,Q(1,3),-1,arbitrary_k)
    for i in range(4):
        for j in range(4):
            difference=physical[i][j]-D[i]*H[i][j]*conj(c,D[j])
            assert bounds(difference.real)[0] <= 0 <= bounds(difference.real)[1]
            assert bounds(difference.imag)[0] <= 0 <= bounds(difference.imag)[1]
    # Retain the wrong-orientation negative: physical upper hopping is equal in both layers.
    assert physical[0][1] == physical[2][3]
    il,ih=bounds(physical[0][1].imag)
    assert il>0 or ih<0, 'complex physical hopping required for orientation negative'
    wrong=physical[2][3]-conj(c,physical[2][3])
    wl,wh=bounds(wrong.imag)
    assert wl>0 or wh<0


def test_bernal_new_public_interfaces_have_actual_equality_controls(monkeypatch):
    # Extend only this NEW control's required population; the old17 predicate and
    # every old assertion remain byte-identical in their original tests.
    import sys
    added={'bernal_lattice_gap_sq','bernal_lattice_minimizer','bernal_lattice_grid_gap_sq'}
    old=_D11_REVIEWED_FLOOR
    assert len(old)==17
    monkeypatch.setattr(sys.modules[__name__],'_D11_REVIEWED_FLOOR',old|added)
    evidence=_d11_meaningful_assertions()
    assert old|added <= set(evidence)
    assert all(any(cls=='TestBernalPhysicalLatticeInterfaces' for cls,fn,line in evidence[name]) for name in added)



def test_bernal_returned_binary_conversion_cannot_hide_unmet_requested_error():
    # Exact physical interior gap4/5 is not binary64-representable. No amount of
    # interval precision makes this requested absolute return tolerance possible.
    tolerance=Q(1,10**100)
    try:
        got=F.bernal_lattice_gap_sq(1,1,1,abs_error=tolerance,return_diagnostics=True)
    except F._D11Unresolved as error:
        assert error.stage=='continuous_gap' and error.history
        return
    assert abs(exact(got['value'])-Q(4,5)) <= tolerance
    assert got['absolute_error'] <= tolerance


def test_bernal_all_new_tolerances_geometry_integer_admissions_are_strict():
    for bad in (0,-1,True,float('nan'),float('inf')):
        with pytest.raises(ValueError):F.bernal_lattice_gap_sq(.5,1,1,abs_error=bad)
        with pytest.raises(ValueError):F.bernal_lattice_minimizer(.5,1,1,1,coordinate_error=bad,energy_error=1,work_limit=100)
        with pytest.raises(ValueError):F.bernal_lattice_minimizer(.5,1,1,1,coordinate_error=1,energy_error=bad,work_limit=100)
    for bad in (0,-1,True,1.5):
        with pytest.raises(ValueError):F.bernal_lattice_grid_gap_sq(.5,1,1,3,abs_error=1,work_limit=bad)
    for bad in (0,2,True,1.5):
        with pytest.raises(ValueError):F.bernal_lattice_minimizer(.5,1,1,1,handedness=bad,coordinate_error=1,energy_error=1,work_limit=100)
    for a in (0,-1):
        with pytest.raises(ValueError):F.bernal_lattice_minimizer(.5,1,1,a,coordinate_error=1,energy_error=1,work_limit=100)


def test_bernal_literal_registry_and_all_three_public_functions_are_present():
    names=_d11_region(_d11_tree('src/core/formulas.py'))
    expected=_D11_REVIEWED_FLOOR|{'bernal_lattice_gap_sq','bernal_lattice_minimizer','bernal_lattice_grid_gap_sq'}
    assert set(names)==expected and len(names)==20
    assert _d11_registry()['D11']['formulas']==names


_BERNAL_PHYSICAL_MUTATIONS += (
    ('hardcoded_hopping_range','_d11_bl_model','h, v, X = g*g, u*u, 9*t*t','h, v, X = g*g, u*u, Q(9)','test_bernal_physical_domain_both_regimes_and_scalar_obstruction'),
    ('hidden_conversion_error','_d11_bl_return','if error > tolerance:','if False:','test_bernal_returned_binary_conversion_cannot_hide_unmet_requested_error'),
    ('missing_real_registry_name',None,"                          'bernal_lattice_minimizer',\n",'','test_bernal_literal_registry_and_all_three_public_functions_are_present'),
)



def test_bernal_nearest_binary_threshold_decisions_remain_exact():
    edge=math.sqrt(1/24)
    lower=math.nextafter(edge,-math.inf);upper=math.nextafter(edge,math.inf)
    assert 9*exact(lower)**2 < Q(3,8) < 9*exact(upper)**2
    lo=F.bernal_lattice_gap_sq(.5,1,lower,abs_error=1e-12,return_diagnostics=True)
    hi=F.bernal_lattice_gap_sq(.5,1,upper,abs_error=1e-12,return_diagnostics=True)
    assert lo['regime']=='boundary' and hi['regime']=='interior'
    assert lo['X']==9*exact(lower)**2 and hi['X']==9*exact(upper)**2
    proposal=F.bernal_lattice_minimizer(.5,1,upper,1,coordinate_error=1e-7,energy_error=1e-8,work_limit=100000)
    assert proposal['regime']=='interior' and proposal['turn_interval'][1]>0
    for bad_n in (0,-1,1.5):
        with pytest.raises(ValueError):F.bernal_lattice_grid_gap_sq(.5,1,1,bad_n,abs_error=1,work_limit=100)


def test_bernal_uncertain_phase_encloses_independent_endpoint_trigonometry():
    # Exercise the actual uncertain-phase production seam, not a mocked verdict.
    c=F._d11_bl_context(128,128);work=dict(used=0,limit=10)
    cosine,sine=F._d11_bl_trig_box(c,F._d11_interval(c,Q(1,5),Q(2,5)),work)
    reference=oracle_context(384)
    for phase in (Q(1,5),Q(3,10),Q(2,5)):
        for returned,wanted in ((cosine,reference.cos(iv(reference,phase))),(sine,reference.sin(iv(reference,phase)))):
            lo,hi=F._d11_bounds(returned);a,b=bounds(wanted)
            assert lo<=a<=b<=hi
    assert work['used']==1


_BERNAL_PHYSICAL_MUTATIONS += (
    ('discarded_phase_uncertainty','_d11_bl_trig_box','(hi-lo)/2','0','test_bernal_uncertain_phase_encloses_independent_endpoint_trigonometry'),
)


# D63 source-constructed controls. Original322 case definitions and all599
# assertions remain above unchanged, apart from the additive evidence-population
# eligibility repair; none of these new controls has run in the author task.
def test_bernal_real_meaningful_population_includes_all_current_interfaces():
    actual = _d11_meaningful_assertions()
    population = set(_d11_region(_d11_tree('src/core/formulas.py'))) | _d11_consumer_surface()['owed']
    assert len(_D11_REVIEWED_FLOOR) == 17 and _D11_REVIEWED_FLOOR <= population
    assert set(actual) == population == set(_d11_registry()['D11']['formulas'])
    for name in ('bernal_lattice_gap_sq', 'bernal_lattice_minimizer', 'bernal_lattice_grid_gap_sq'):
        assert any(cls == 'TestBernalPhysicalLatticeInterfaces' and
                   method == 'test_selected_physical_zero_hopping_is_not_the_scalar_alias'
                   for cls, method, line in actual[name])


@pytest.mark.parametrize('name', ['bernal_lattice_gap_sq', 'bernal_lattice_minimizer', 'bernal_lattice_grid_gap_sq'])
@pytest.mark.parametrize('defect', ['bounds_with_unrelated_equality', 'reflexive', 'overwritten_output'])
def test_bernal_new_coverage_requires_relevant_nonreflexive_output_equality(name, defect):
    call = 'x=F.' + name + '(1,1,1)'
    tail = {'bounds_with_unrelated_equality': 'assert x>0\n  assert 2==2',
            'reflexive': 'assert x==x',
            'overwritten_output': 'x=1\n  assert x==1'}[defect]
    tree = _surface_ast.parse('from src.core import formulas as F\nclass T:\n def test_actual(self):\n  '+call+'\n  '+tail+'\n')
    assert name not in _d11_meaningful_assertions(tree)


@pytest.mark.parametrize('u,t,a,angle,eta', [
    (Q(1,2),Q(1,2),1,0,1),
    (Q(1,4),Q(1,2),Q(7,10),Q(2,5),-1),
    (Q(3,2),Q(1,2),2,Q(-1,3),1),
    (2,Q(1,2),1,0,-1),
    (0,Q(1,2),1,0,1),
])
def test_bernal_decoupled_local_error_matches_actual_physical_bands(u,t,a,angle,eta):
    result=F.bernal_lattice_minimizer(u,0,t,a,angle=angle,handedness=eta,
        coordinate_error=1e-7,energy_error=1e-8,work_limit=100000)
    minimum=4*max(abs(exact(u))-3*abs(exact(t)),Q(0))**2
    assert exact(result['gap_sq']) == minimum
    assert result['coordinate_bound'] <= exact(1e-7) and result['energy_bound'] <= exact(1e-8)
    assert result['work_used'] <= 100000
    for x in result['k_box'][0]:
        for y in result['k_box'][1]:
            assert (exact(result['k'][0])-x)**2+(exact(result['k'][1])-y)**2 <= result['coordinate_bound']**2
    # Independent physical bond/k/F matrix and residual/Gram enclosure, including
    # zero/repeated bands; do not demand a strictly positive reference root here.
    model=lambda c:_bernal_physical_matrix(c,u,0,t,a,angle,eta,result['k'])
    spectra=hermitian_reference(model,abs(exact(u))+3*abs(exact(t)),Q(1,10**14))
    for produced,reference in zip(result['ordered_bands'],spectra):
        assert max(produced[0],reference[0]) <= min(produced[1],reference[1])
    lo,hi=spectra[2]
    lower=Q(0) if lo<=0<=hi else min(lo*lo,hi*hi)
    upper=max(lo*lo,hi*hi)
    assert max(abs(4*lower-minimum),abs(4*upper-minimum)) <= result['energy_bound']+Q(1,10**12)
    pl,ph=result['point_gap_interval']
    assert max(abs(pl-minimum),abs(ph-minimum)) <= result['energy_bound']
