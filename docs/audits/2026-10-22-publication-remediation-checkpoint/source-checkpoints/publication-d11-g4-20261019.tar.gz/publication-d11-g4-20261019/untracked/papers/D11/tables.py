r"""Principal D11 certificate index for the existing paper-table pipeline.

The rows are source references and scoped statement summaries. They introduce no
numerical computation. Regenerate the table bodies with the canonical renderer:

    uv run python scripts/render_paper_tables.py --paper D11

Source paths are relative to lean/SKEFTHawking/. The manuscript owns captions,
labels and layout; this module owns only the three table specifications.
"""

from scripts.paper_tables import Col


def certificate_index_fhs():
    """Return the twelve fhs source-reference rows."""
    return [
        {
            'declaration': '\\thm{principal\\_add\\_branch}',
            'source': '\\thm{TopologicalBand/\\allowbreak{}PrincipalBranch\\allowbreak{}.lean}',
            'scope': 'Principal representative plus integer full turns equals the input angle.',
        },
        {
            'declaration': '\\thm{sum\\_forwardDiff\\_eq\\_zero}',
            'source': '\\thm{TopologicalBand/\\allowbreak{}FiniteTorus\\allowbreak{}.lean}',
            'scope': 'A forward difference sums to zero on the periodic grid.',
        },
        {
            'declaration': '\\thm{sum\\_plaquetteArg\\_eq\\_two\\_pi\\_mul\\_latticeChern}',
            'source': '\\thm{TopologicalBand/\\allowbreak{}FHSLatticeGauge\\allowbreak{}.lean}',
            'scope': 'Total principal plaquette phase is $2\\pi C$ for circle links.',
        },
        {
            'declaration': '\\thm{latticeChern\\_gaugeInvariant}',
            'source': '\\thm{TopologicalBand/\\allowbreak{}FHSLatticeGauge\\allowbreak{}.lean}',
            'scope': 'Vertex circle action leaves the integer unchanged.',
        },
        {
            'declaration': '\\thm{blochLatticeChern\\_integrality}',
            'source': '\\thm{TopologicalBand/\\allowbreak{}BlochFrame\\allowbreak{}.lean}',
            'scope': 'The link identity applies to an admissible sampled frame.',
        },
        {
            'declaration': '\\thm{blochLatticeChern\\_rephase}',
            'source': '\\thm{TopologicalBand/\\allowbreak{}BlochFrame\\allowbreak{}.lean}',
            'scope': 'Pointwise frame phases induce the allowed link action.',
        },
        {
            'declaration': '\\thm{selfNormSq\\_lbVec}',
            'source': '\\thm{TopologicalBand/\\allowbreak{}BlochFrameOfD\\allowbreak{}.lean}',
            'scope': 'Raw lower-band vector has norm squared $2r(r+d_2)$.',
        },
        {
            'declaration': '\\thm{blochLatticeChern\\_eq\\_zero\\_of\\_narrow\\_D}',
            'source': '\\thm{TopologicalBand/\\allowbreak{}BlochFrameOfD\\allowbreak{}.lean}',
            'scope': 'Admissible raw overlaps narrower than $\\pi/4$ imply zero integer.',
        },
        {
            'declaration': '\\thm{acousticBloch\\_eigenvalue\\_iff}',
            'source': '\\thm{AcousticBlochOperator\\allowbreak{}.lean}',
            'scope': 'For a positive-parameter diatomic chain, a real number is a secular root iff it equals a branch.',
        },
        {
            'declaration': '\\thm{phononic\\_band\\_gap\\_exists}',
            'source': '\\thm{PhononicBandGap\\allowbreak{}.lean}',
            'scope': 'Concrete rational crystal has separated branches for every real momentum.',
        },
        {
            'declaration': '\\thm{band\\_gap\\_falsifier}',
            'source': '\\thm{PhononicBandGap\\allowbreak{}.lean}',
            'scope': 'No secular root lies strictly inside the squared-frequency gap.',
        },
        {
            'declaration': '\\thm{band\\_gap\\_rational\\_enclosure}',
            'source': '\\thm{BandGapEnclosure\\allowbreak{}.lean}',
            'scope': 'A rational inner frequency interval is free of modes.',
        },
    ]


def certificate_index_algebra():
    """Return the twelve algebra source-reference rows."""
    return [
        {
            'declaration': '\\thm{ptBloch\\_secular\\_det}',
            'source': '\\thm{ExceptionalPoint\\allowbreak{}.lean}',
            'scope': 'Exact characteristic polynomial of the normalized two-level matrix.',
        },
        {
            'declaration': '\\thm{pt\\_symmetric\\_real\\_spectrum\\_iff}',
            'source': '\\thm{ExceptionalPoint\\allowbreak{}.lean}',
            'scope': 'Real root exists iff $g^2\\le1$.',
        },
        {
            'declaration': '\\thm{exceptional\\_point\\_defective}',
            'source': '\\thm{NonHermitianBloch\\allowbreak{}.lean}',
            'scope': 'At $g=1$, nilpotence, kernel-line witness and failed second candidate.',
        },
        {
            'declaration': '\\thm{ep\\_order\\_two}',
            'source': '\\thm{ExceptionalPoint\\allowbreak{}.lean}',
            'scope': 'The critical characteristic polynomial is $\\lambda^2$.',
        },
        {
            'declaration': '\\thm{ep\\_proximity\\_enclosure}',
            'source': '\\thm{NonHermitianWinding\\allowbreak{}.lean}',
            'scope': '$99/100\\le g^2\\le1$ entails real splitting at most $1/5$.',
        },
        {
            'declaration': '\\thm{maxwellGarnett\\_clausius\\_mossotti}',
            'source': '\\thm{MaxwellGarnett\\allowbreak{}.lean}',
            'scope': 'Adopted expression satisfies the cross-multiplied relation when its denominator is nonzero.',
        },
        {
            'declaration': '\\thm{maxwellGarnett\\_host\\_recovery}',
            'source': '\\thm{MaxwellGarnett\\allowbreak{}.lean}',
            'scope': 'Zero fill recovers the host with nonzero denominator.',
        },
        {
            'declaration': '\\thm{effectiveMedium\\_constituent\\_bounds}',
            'source': '\\thm{EffectiveMediumBounds\\allowbreak{}.lean}',
            'scope': 'Positive ordered constituents and $f\\in[0,1]$ bracket the adopted formula.',
        },
        {
            'declaration': '\\thm{effectiveMedium\\_constituent\\_bounds\\_strict}',
            'source': '\\thm{EffectiveMediumBounds\\allowbreak{}.lean}',
            'scope': 'Positive host, strict constituent contrast and interior fill give strict interiority.',
        },
        {
            'declaration': '\\thm{effectiveMedium\\_worked\\_point\\_strict}',
            'source': '\\thm{EffectiveMediumBounds\\allowbreak{}.lean}',
            'scope': 'Instantiation of general strictness at $(1,4,1/2)$.',
        },
        {
            'declaration': '\\thm{voigt\\_sub\\_reuss\\_eq}',
            'source': '\\thm{EffectiveModuli\\allowbreak{}.lean}',
            'scope': 'Exact arithmetic-minus-harmonic difference for positive moduli and $f\\in[0,1]$.',
        },
        {
            'declaration': '\\thm{effectiveModuli\\_enclosure}',
            'source': '\\thm{EffectiveModuli\\allowbreak{}.lean}',
            'scope': 'Ordered positive moduli and $f\\in[0,1]$ bracket both averages; no physical $M_{\\rm eff}$ occurs.',
        },
    ]


def certificate_index_graphene():
    """Return the twelve graphene source-reference rows."""
    return [
        {
            'declaration': '\\thm{isHoneycombChart\\_of\\_neighbours}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}Honeycomb\\allowbreak{}.lean}',
            'scope': 'Nonzero equal-length $120^\\circ$ bond geometry forces the $60^\\circ$ phase chart.',
        },
        {
            'declaration': '\\thm{structureFactor\\_linear\\_expansion\\_global}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}DiracExpansion\\allowbreak{}.lean}',
            'scope': 'Explicit quadratic error between structure-factor magnitude and its linear form.',
        },
        {
            'declaration': '\\thm{dispersion\\_fermiVelocity\\_enclosure}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}DiracExpansion\\allowbreak{}.lean}',
            'scope': 'For honeycomb neighbours and $\\hbar\\ne0$, unit-hopping slope and quadratic remainder are composed.',
        },
        {
            'declaration': '\\thm{haldaneFrame\\_latticeChern\\_eq\\_neg\\_one}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}HaldaneWitness\\allowbreak{}.lean}',
            'scope': 'Declared $4\\times4$ mass-one lower band has $C=-1$.',
        },
        {
            'declaration': '\\thm{haldane\\_massInversion\\_not\\_sufficient\\_at\\_N4}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}HaldaneWitness\\allowbreak{}.lean}',
            'scope': 'On the $4\\times4$ grid, mass five is inside the cone inversion window but has lattice integer zero.',
        },
        {
            'declaration': '\\thm{coneBerryPhase\\_pi}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}HaldaneWitness\\allowbreak{}.lean}',
            'scope': 'A specific discrete loop has Wilson-product argument $\\pi$.',
        },
        {
            'declaration': '\\thm{bernal\\_det\\_eq}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}BernalBilayer\\allowbreak{}.lean}',
            'scope': 'Four-band determinant equals the real secular quadratic.',
        },
        {
            'declaration': '\\thm{bernal\\_eigenvector\\_iff}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}BernalBilayer\\allowbreak{}.lean}',
            'scope': 'Secular roots carry actual nonzero matrix eigenvectors.',
        },
        {
            'declaration': '\\thm{bernal\\_lowRoot\\_enclosure}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}BernalBilayer\\allowbreak{}.lean}',
            'scope': 'For $\\gamma>0$ and $x\\ge0$, a selected unbiased low secular root has a global two-sided enclosure.',
        },
        {
            'declaration': '\\thm{bernal\\_halfGapSq\\_isLeast}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}BernalBilayer\\allowbreak{}.lean}',
            'scope': 'For $\\gamma>0$, exact least squared energy in the scalar spectral family $x\\ge0$. Physical equality additionally requires $x_*\\le9t^2$; see the separate crystal construction.',
        },
        {
            'declaration': '\\thm{bernal\\_fullGapSq\\_eq}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}BernalBilayer\\allowbreak{}.lean}',
            'scope': 'For $\\gamma>0$, full-gap versus half-gap squared conversion with $U=2u$. The physical constrained minimum is given separately in Eq.~\\eqref{eq:bernal-physical-gap}.',
        },
        {
            'declaration': '\\thm{bernal\\_spectrum\\_not\\_determine\\_model}',
            'source': '\\thm{GrapheneBand/\\allowbreak{}BernalBilayer\\allowbreak{}.lean}',
            'scope': 'Hermitian equal-spectrum layer-conjugated matrices can differ in chirality.',
        },
    ]


TABLES = {
    'certificate_index_fhs': {
        "description": 'Finite-grid and acoustic certificate index.',
        "rows": certificate_index_fhs,
        "columns": [
            Col("declaration", "Declaration", align=r"p{0.32\textwidth}"),
            Col("source", "Source file", align=r"p{0.24\textwidth}"),
            Col("scope", "Conclusion and domain", align=r"p{0.34\textwidth}"),
        ],
    },
    'certificate_index_algebra': {
        "description": 'Non-Hermitian and adopted effective-medium certificate index.',
        "rows": certificate_index_algebra,
        "columns": [
            Col("declaration", "Declaration", align=r"p{0.32\textwidth}"),
            Col("source", "Source file", align=r"p{0.24\textwidth}"),
            Col("scope", "Conclusion and domain", align=r"p{0.34\textwidth}"),
        ],
    },
    'certificate_index_graphene': {
        "description": 'Graphene and model-identification certificate index.',
        "rows": certificate_index_graphene,
        "columns": [
            Col("declaration", "Declaration", align=r"p{0.32\textwidth}"),
            Col("source", "Source file", align=r"p{0.24\textwidth}"),
            Col("scope", "Conclusion and domain", align=r"p{0.34\textwidth}"),
        ],
    },
}
