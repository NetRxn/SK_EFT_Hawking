---
paper: D11
bundle: D11
bundle_target: D11
tier: 2
reviewer: Codex-publication-lead
model: Codex
review_date: 2026-10-20
readiness_gates_version: 1
kind: targeted-infra
---

# Exact module identity and honest source uncertainty

This is a ROOT-authored public filing of a coherent infrastructure defect, not
a new independent review or canonical closure. A local independent review found
the qualified-name defect before implementation. This tracked filing follows
the implementation; it does not establish that a public finding preceded code.
The finding remains OPEN until independent filing verification and the declared
command pass, followed by the existing closure writer.

ROOT accepts implementation and integration accountability. The next action is
genuinely nonauthor whole verification of this filing, the exact implementation
and its actual evidence, then current verification and canonical closure. See
[the evidence boundary](SCOPED_REVIEW.md) and
[selected actual control metadata](CONTROL_EVIDENCE.json).

### 1.1 — MAJOR — qualified module identity and unavailable source were lost across the dashboard path

- **Severity:** major
- **Lane:** `infra`
- **Gate:** ComputationCorrectness
- **Location:** `scripts/check_bundle_source_freshness.py::_lean_module_index`, `scripts/provenance_dashboard.py::load_paper_claims`, `scripts/provenance_dashboard.py::load_proof_architecture`, `scripts/build_graph.py::extract_lean_declaration_nodes`, `scripts/templates/dashboard.html`
- **Verify:** `uv run python -m pytest -q tests/test_d11_formula_surface.py::TestD11DashboardModuleConsumers tests/test_build_graph.py::TestExactSourceModuleMetadata tests/test_template_contract.py::TestD11DashboardSourceTemplate`
- **Observed:** Literal dotted filenames omitted real nested source modules from
  the paper-card counts. Unavailable source could be displayed as a measured
  zero. Family-level theorem metadata did not supply the exact source identity
  needed by the corresponding live/historical axiom attribution. D11 exposes
  nine positive nested homes and one genuinely readable zero among its direct
  homes; same-family guessing or initializing counts before a successful read
  cannot distinguish these cases honestly.
- **Expected:** Reuse the existing exact source index, with complete relative
  keys, existing unique aliases and collision/top-level precedence. Retain
  unresolved, unreadable, invalid or escaped sources as UNKNOWN. A readable
  zero is measured zero. Emit exact source identity additively, preserving
  existing family metadata and node identities; attribute axioms by exact
  source and explicit registry coverage. Old source-less cache entries remain
  UNKNOWN until their existing owner regenerates them.
- **Repair evidence:** The existing index has a compatible optional root; the
  existing dashboard loaders resolve validated full names through it, count
  only contained regular UTF-8 sources, and render uncertainty explicitly.
  The declaration emitter adds `meta.source_module` without replacing its
  family field. Exact-source axiom joins preserve UNKNOWN versus measured
  empty. Three separate actual production regressions—old dotted reader,
  false-zero rendering and missing emitted source identity—each produced
  unchanged-decider exits 0, 1, 0 with exact restoration and empty journals.
  The emitter discriminator raises `KeyError('source_module')` at the asserted
  field lookup; it is a test failure, not a collection error or an asserted
  physical theorem.
- **Independent scope:** Genuine whole original D1–D8 source/scientific-carrier,
  control and affected-profile review accepted this bounded repair. The current
  complete nine-module default profile has 509 passes and one missing-population
  skip. A separate remaining-slow profile has 13 passes and two PG-availability
  skips. Full graph export/global-integrity/readiness tests actually passed.
  The selected evidence contains hashes and precise limits, not fabricated new
  executions or a claim of successful database writes.
- **Remaining:** Public filing review, current declared verification and existing
  canonical closure; exact old indexed-claim meaning/pointer/cache reconciliation,
  applicable PG/native/browser/compiled-paper/current full gates and protected
  integration. Source counts and test-coverage G4 do not discharge the physical,
  microscopic, continuum Chern, homogenization, units or other original scientific
  BUILD obligations. The current computation report explicitly still notes that
  `haldane_flip_location` has no resolving Lean theorem. No whole D11 publication
  acceptance, main merge or scientific deferral is supplied by this filing.
