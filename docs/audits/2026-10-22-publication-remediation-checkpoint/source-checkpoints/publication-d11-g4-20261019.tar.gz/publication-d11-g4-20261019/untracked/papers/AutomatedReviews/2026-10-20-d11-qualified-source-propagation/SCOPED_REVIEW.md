# Source and evidence boundary

This document is the publication lead's reconciliation of existing evidence. It
is not a newly conducted independent review, a source-control checkpoint or a
canonical finding disposition. The independent assessment and actual execution
receipts have their own dates and scopes.

The complete original D1–D8 repair was independently assessed against its
scientific construction, source, original test populations, notebook carrier,
three actual production-source regressions and complete affected default plus
remaining-slow profiles. That whole review's SHA-256 is
`e2f89307a04a7cdc19b7a63eabc9dfed5c8610c5b54eeee31a5b59bcc0555d04`.
It accepted the bounded increment, with no mandatory finding at that scope.
This public filing still requires its own genuinely nonauthor verification.

The production controls changed the actual reader, template and emitter source,
not their tests or expected answers. Each observed a passing baseline, the
intended failing production regression and a passing exact restoration. All
mutated source bytes, full modes and nanosecond mtimes were restored; each final
mutation journal was empty. Selected metadata below identifies original channel
hashes and the exact failures. It is an authored summary, not a replacement for
the original OS byte streams, proof of an arbitrary host's state or a fresh run.

The complete affected default selection produced 509 passes and one existing
skip because no ProductionRun nodes were available for its shape assertion. The
separate fifteen slow cases produced 13 passes and two existing `PG+AGE not
available` skips. Their fixture does not establish the underlying database
exception or host-wide database failure, and no successful write is credited.
Flask/template contract tests executed server rendering, not browser JavaScript.

A later fresh full candidate graph contained 51,018 nodes and 18,352 edges and
ran all 704 gate evaluations. D11's computation gate passed for its 17 grounded
formulas with substantive classified tests. Its report retains the unresolved
Lean backing for `haldane_flip_location`; fix propagation still requires a
fresh evaluation and canonical disposition. These are candidate observations,
not changes to the primary portfolio snapshot, proof of physical calibration,
full native acceptance or publication readiness.

The qualified-source identity repair does not establish all old indexed claim
meanings or external pointer/cache migration. The existing writers must preserve
and reconcile those meanings. PG/native/browser/compiled-paper/current full
qualification, original scientific constructions, canonical closure and protected
main delivery remain separate obligations. No private assignment, human review,
operator-approved deferral or main merge is inferred.
