# D11 Bernal physical-domain construction and implementation contract

2026-10-20: **SCIENTIFIC CONTINUATION DESIGN; no implementation acceptance.** R49's model-specific manual construction has genuine R50 independent scientific acceptance. R53-M2 identifies the outstanding formal/numerical/consumer continuation. Publication ROOT owns the full scientific program; the R54 author accepts this selected-lattice design. Implementing workers must explicitly accept coherent assigned paths and acceptance reviewer before execution. This document supplies the scientific mechanism/spec to the existing assignment/review system; it is not a second queue, gate, registry or waiver.

Existing owners: `lean/SKEFTHawking/GrapheneBand/Honeycomb.lean`, `GrapheneBand/BernalBilayer.lean`, `src/core/formulas.py`, `src/core/provenance.py`, current D11 reference/numerical tests and ordinary bundle/table/notebook/graph writers. No API/Lean/test/metadata implementation is performed by R54. Genuine WHOLE scientific design/original-intent review precedes a coherent source grant. Source/kernel/numerical/consumer/rendered/canonical/main acceptance remains separate.

## 1. Original objective and actual physical model

The owed bridge is scalar-family leastness to an attained minimum on an actual FIXED honeycomb crystal. A freely supplied complex f cannot supply it. Select the infinite periodic nearest-neighbour Bernal crystal: three planar bonds delta_j satisfy actual `IsHoneycombNeighbours` (nonzero equal bond lengths and pairwise120-degree angles); both layers have the SAME orientation and real hopping t; gamma is real dimer coupling and u real half-bias. Full bias is U=2u. k is wavevector, delta length, k.delta dimensionless radians. t,u,gamma/bands have energy units; squared gaps have energy-squared units.

This discrete tight-binding lattice has continuous Bloch parameter on its full reciprocal torus. It is neither an arbitrary finite mesh nor a continuum field limit. Skew/remote hopping, interactions, disorder, edges, self-consistent electrostatics and material/transport/readout matching remain substantive ROOT-owned work. This selected-model result neither includes them nor proves them infeasible or deferred. Original other D11 science remains full strength.

    a1=delta0-delta2, a2=delta1-delta2, theta=(k.a1,k.a2),
    S(theta)=1+exp(i theta1)+exp(i theta2), f=t S(theta),
    F=t sum_j exp(i k.deltaj),
    H(u,gamma,f)=[[u,f,0,0],[conj(f),u,gamma,0],
                  [0,gamma,-u,f],[0,0,conj(f),-u]].

This is actual `bernalBloch`; do not conjugate layer2's upper hopping. Retain the shipped equal-spectrum/swapped-chirality countermodel as a negative model-identification control.

## 2. Geometry, reciprocal domain and actual eigenvector adapter

Existing `isHoneycombChart_of_neighbours` gives |a1|²=|a2|²=L>0 and a1.a2=L/2; `chart_len_sq_of_neighbours` gives L=3a_CC². Write a1=(A,B), a2=(C,D), Delta=AD-BC. The polynomial Gram identity yields

    Delta²=(A²+B²)(C²+D²)-(AC+BD)²=3L²/4>0,
    k(theta)=((D theta1-B theta2)/Delta,(-C theta1+A theta2)/Delta).

Multiplication proves k.a1=theta1 and k.a2=theta2. Every phase pair therefore has an ACTUAL finite inverse-length wavevector. Phase translations by2pi(n,m) correspond to reciprocal translations; prove S/spectral periodicity and the physical basis adapter, not entrywise periodicity of unadapted H(F). No Wigner-Seitz polygon is needed for range/leastness. Preserve the source's shear refutation: a different arbitrary primitive pair cannot simply be substituted into unchanged S.

`neighbourSum_eq_structureFactor` gives F=exp(i phi)f, phi=k.delta2. Define

    Dphi=diag(exp(i phi),1,1,exp(-i phi)),
    H(F)=Dphi H(f) Dphi*, Dphi Dphi*=I.

Prove all16 entries and the unitary identities. If H(f)v=Ev with v!=0, w=Dphi v remains nonzero and H(F)w=Ew; Dphi* gives the converse. At u0 explicitly transport `E(gamma v0-f v2)=-f²v3` to `E(gamma w0-F w2)=-F²w3`. This is stronger than determinant equality and supplies no basis-independent interpretation of raw vector components.

A numerical coordinate constructor must use EXACT ideal geometry rather than claim approximate floating bond arrays satisfy exact120-degree hypotheses. For positive a_CC, rotation alpha and handedness eta in {-1,+1}, set

    d0=(a_CC,0), d1=(-a_CC/2,eta sqrt(3)a_CC/2),
    d2=(-a_CC/2,-eta sqrt(3)a_CC/2), delta_j=R(alpha)d_j.

Prove this satisfies the existing neighbour structure; interval-enclose its exact real values from exact admitted a_CC/alpha. Formal theorems remain general in actual neighbour geometry. Arbitrary measured bond arrays need an additional uncertainty/model-error contract, not projection to ideal geometry. This explicitly generated numerical subfamily does not replace the general physical proof by one canonical sampled lattice.

## 3. Full physical range and attained constrained spectrum

Triangle inequality gives0<=x=|f|²<=X=9t². If t!=0 and x in[0,X], let q=sqrt(x)/|t| in[0,3], z=(q-1)/2 in[-1/2,1], s=acos(z) in[0,2pi/3]. Then S(s,-s)=1+2cos(s)=q, so |tS|²=x. Section2 supplies actual k. Unimodular adaptation gives the same range for F. x0 is Dirac, xX Gamma. At t0 range is{0}, with no division by t. Named Gamma/M/K witnesses alone are insufficient for this surjectivity.

Let g=|gamma|, h=g², v=u², c=h+4v. Actual determinant/eigenvector source gives

    Q=w²-(h+2x)w+x(x-4v), w=E²-u²,
    lambda±(x)=x+v+h/2 +/- sqrt(h²/4+c x).

The four bands are +/-sqrt(lambda-) and +/-sqrt(lambda+), including repeated/zero energies. Their sum is2x+2v+h, product P=(x-v)²+hv. For h>0, lambda+>0 and lambda->=0; for h0 they are(sqrt(x)+/-|u|)². Degree-four completeness and actual nonzero-eigenvector iff exclude hidden bands. Half-filled gap is2min sqrt(lambda-), not an inferred finite-temperature, chemical-potential or transport gap.

For g>0, c>0 and R=h²/4+cx>0:

    lambda-'=1-c/(2sqrt(R)), lambda-''=c²/(4R^(3/2))>0,
    x*=2v(h+2v)/c, y=min(x*,X), G²=4lambda-(y).

The derivative changes sign only at x*. Independently,

    B=x+h/2+4v²/c,
    B²-R=(x-x*)²,
    lambda-(x)-vh/c=(x-x*)²/(B+sqrt(R)).

This supplies scalar lower bound/strictness without sample optimization. Derivative ordering, exact physical range and actual matrix/eigenvector bridge prove BOTH physical leastness and actual attainment at y.

The scalar-floor physical equality holds iff x*<=X: G²=4vh/c=U²g²/(g²+U²). At equality Gamma attains it; interior nonzero-bias minimum has positive x. If x*>X, Gamma is minimizing and

    G²=4[X+v+h/2-sqrt(h²/4+cX)] > 4vh/c.

The EXACT equivalent regime criterion for g>0 is

    4v²+(2h-4X)v-Xh<=0,
    v<=[2X-h+sqrt(h²+4X²)]/4.

The second root is negative for h>0,X>=0; v>=0 picks the correct interval. Numeric regime decisions use exact rational comparisons, not a floating radical or epsilon. For u,g,t all nonzero, lambda-'(0)=-4v/h<0 and X>0, so an actual positive x<X has lambda-<u² and G<|U| even in the boundary regime. A non-Dirac physical minimum is proved; a circular ring is not.

## 4. Zero/sign/threshold/scaling branches

- t0: x0 at all momenta, G²=4u² for every gamma; no manufactured free-f witness.
- g0: lambda-=(sqrt(x)-|u|)², y=min(u²,X), G=2max(|u|-3|t|,0). Equality |u|=3|t| is Gamma touching; below is attained zero, above positive boundary gap.
- u0,g>0: y0, Dirac touching if t!=0; no strict bias conclusion.
- u=g=0: selected PHYSICAL gap0 for every t. Old scalar helper's undefined0/0 refusal remains its unchanged contract; the new physical function explicitly has its own zero contract.
- Signs of t,u,gamma leave energies/threshold/gap unchanged, not phase-sensitive vector conventions. Formal energy reduction uses `bernalSecular u gamma = bernalSecular u |gamma|` and old positive-gamma proofs only after that reduction.
- Positive energy scaling by a multiplies x*,X,lambda,G² by a² and G by a; regime invariant. Positive length scaling by b sends k to k/b at fixed phases and preserves bands. Mechanical momentum is hbar k, not the API wavevector.

Mandatory exact examples: (t,g,u)=(1,1,1/2) gives x*3/8, lambda_min1/8; (1/10,1,1/2) gives X9/100 and lambda_min21/25-sqrt(43/100), strictly between1/8 and1/4; (0,1,1/2) gives G²1 versus scalar1/2; (1/10,0,1/2) gives G²4/25 versus scalar0. Same u/g with different t decisively refutes a hidden scalar alias. An exact nonzero mathematical threshold fixture is t=sqrt(1/24),g1,u1/2, giving X=x*=3/8. Its algebraic t is NOT falsely passed as an exact binary production input; rational/binary points on both sides separately test exact production decisions. Intersections t0/u0 must agree across formulas.

## 5. Complete proposed numerical interface in the existing owner

These are proposed names, NOT implemented declarations. Add coherently inside the existing D11 region of `src/core/formulas.py` BEFORE the retained `bernal_full_gap_sq` delimiter, with actual literal `PAPER_DEPENDENCIES['D11']['formulas']` entries. Preserve all17 current public methods/old tests and scalar0/0/underflow refusals. No new runner, cache or scalar alias.

1. `bernal_lattice_gap_sq(bias_u,gamma,hopping_t,*,abs_error,return_diagnostics=False)`: continuous selected-crystal G² with actual enclosure/return-error<=abs_error. Geometry independence follows the actual range theorem, not arbitrary x. Diagnostics identify model/regime/x*/X/y and analytic physical witness; interface2 supplies numerical coordinates.
2. `bernal_lattice_minimizer(bias_u,gamma,hopping_t,a_cc,*,angle=0,handedness=1,coordinate_error,energy_error,work_limit)`: dictionary of certified phase/k enclosures for exact ideal geometry, y, spectral enclosure and coordinate/energy errors. A k-box encloses a PROVED actual minimizer; its rounded point is not falsely exact. t0 chooses k0; nonzero-t yX chooses Gamma, y0 exact Dirac expression; interiors use monotone validated inversion.
3. `bernal_lattice_grid_gap_sq(bias_u,gamma,hopping_t,n_grid,*,abs_error,work_limit,return_diagnostics=False)`: actual uniform positive-N phase-grid estimate of continuous G² with rigorous TOTAL error<=abs_error. Diagnostics separately retain exact sampled G_N² enclosure, covering bound and final continuous interval. N1 and multiples of3 are valid; arbitrary Cartesian/nonuniform nodes cannot enter or inherit the theorem.

Use existing `_d11_q` exact rational/binary-ratio input admission, `_d11_size` bit admission, finite `_d11_schedule`, `_d11_interval`, `_d11_sqrt`, `_d11_sincos` and `_D11Unresolved`. No bool/complex/array/nonfinite input. Tolerances are strictly positive exact admitted reals in displayed units; a_CC>0; handedness nonbool integer +/-1; N/work_limit positive nonbool integers. Invalid input gives ValueError; finite precision/work/representation exhaustion `_D11Unresolved` with real stage/history. No NaN, infinite schedule, clamped input, fallback scalar or tolerance widening. For every call, define B as the maximum numerator/denominator bit length of ALL admitted exact parameters and tolerances, together with N/work_limit bit lengths where present; `_d11_schedule(B)` is finite, and successful output requires the actual enclosure/error postconditions. The Bernal grid validator is its own N>=1 admission in the same owner: do not reuse `_d11_grid`, whose Haldane policy excludes N1 and multiples of3.

Diagnostics are an ordinary existing-owner dictionary, not a service: exact ratios/units/model, regime, rational x*/X/y (x* null on g0), outward output interval, exact ratio of binary result, certified absolute error, finite precision/work/allocation history, and when relevant exact grid definition/count/covering/bound or ideal-geometry/phase/k enclosures and coordinate/energy uncertainties. Branch precedence is t0, g0, u0, then positive-g interior/equality/boundary. Every intersection must agree analytically. Diagnostics are not kernel or material-uncertainty evidence. Coordinate_error bounds Euclidean distance from the returned binary k proposal to EVERY point in its rational k-box: outward sqrt(dx_max²+dy_max²)<=coordinate_error. Energy_error bounds the full-gap-squared error at the rounded proposal against the exact minimizing G², in energy-squared units, including coordinate/phase/spectral/conversion terms. A caller requesting an energy gap rather than its square requires an additional outward square-root conversion and its separately stated energy-unit tolerance; do not reuse squared units.

For [L,H] and returned float f with exact ratio q require max(|q-L|,|H-q|)<=abs_error, including conversion error and complete quantity error. Nonzero mathematical values cannot underflow to0; exact structural0 requires a proved analytic branch, not a small interval. Existing `_d11_rounded_interval` additionally requires whole rounding-cell/fixed-budget admission: reuse only at that contract. A new private enclosure-to-tolerance helper may be explicitly reviewed in the SAME owner; do not relax the old helper or its callers to obtain success.

## 6. Stable spectral evaluation and validated momentum witness

Continuous evaluation first computes exact rational u,t,g, X and x*/regime/y. Interior/equality G² is rational4vh/c; boundary needs one outward root. For pointwise or boundary low energy avoid cancellation:

    b=x+v+h/2, R=h²/4+cx,
    lambda+=b+sqrt(R), P=(x-v)²+hv,
    lambda-=P/lambda+ if lambda+>0.

The sole lambda+0 case is x=v=h=0, handled structurally. Use nonnegative interval-square rules, not independent multiplication of a straddling interval by itself. Prove the denominator excludes0 before division, refine or refuse. Keep g0 analytic branch separate; never switch small g to0. Intersect a computed norm-square interval with[0,X] only by the proved range and retain that reason; this is sound set intersection, not repairing an invalid acos argument.

Private physical point evaluation constructs actual ideal bonds/rotation and k.deltaj with outward rational/elementary intervals, then F=t sum exp(i k.deltaj). Controls independently compute phases/f/Dphi. Bound x=|F|², both lambda branches and all four ordered energy intervals via outward roots. Stable scalar evaluation is not the independent matrix oracle; physical residual/Gram controls remain mandatory. Repeated/overlapping roots retain enclosing multiplicity or refuse; sorting approximate eigenvalues does not certify them.

For an interior y, q=sqrt(y)/|t| and z=(q-1)/2 are exact algebraic values. Do not repeat the failed floating multiply/divide roundtrip or clamp1.0000000000000002. Isolate r=s/(2pi) in[0,1/3] solving cos(2pi r)=z with existing rigorous turn trig/root enclosures; endpoints y0/yX are exact special cases. Maintain a rational bracket; at quarter points q1=l+(h-l)/4 and q3=h-(h-l)/4, strict outward comparisons bound the root on the proper side. At least one point differs from the root by strict monotonicity, so sufficiently precise tests contract by at least3/4 even when the other point equals the root. A FINITE schedule may exhaust and must refuse. No guessed midpoint equality or unbounded retry.

Map theta=(2pi r,-2pi r) through the interval nondegenerate ideal chart. Delta is mathematically nonzero; its numeric enclosure must exclude0 before division. Return a rational k-box and finite binary proposal with explicit coordinate error. The exact k* inside the box is the minimizer. For rounded khat use

    |theta_i(khat)-theta_i(k*)|<=|a_i| |khat-k*|,
    |x(khat)-x(k*)|<=6t² sum_i min(dtheta_i,2).

The exponential chord bound justifies this conservative modulus. Propagate it through section7's spectral modulus and retain coordinate/conversion, phase and spectral errors separately. Exact minimizing status never attaches to khat without exact endpoint algebra. Material/geometry measurement uncertainty remains a separate scientific model-error construction.

## 7. Uniform positive-N covering theorem and TOTAL finite-grid error

Exact nodes are theta(j,l)=2pi(j/N,l/N), j,l=0,...,N-1, N>=1. A translated mesh requires its explicit same-covering proof; clustered/nonuniform nodes or a Cartesian k-grid cannot inherit it. Every exact minimizing phase has nearest circular mesh distance<=pi/N per coordinate. Since both |S|<=3 and the exponential chord bound holds,

    |x(theta)-x(theta_grid)|<=6t²(d1+d2)<=d=12pi t²/N.

For g>0 derivative grows from-4u²/g² toward1, so M=max(4u²/g²,1) is a valid global absolute derivative bound. The mean-value theorem gives

    0<=G_N²-G²<=4Md=48pi M t²/N.

For g0, |lambda(x)-lambda(y)|<=|x-y|+2|u|sqrt(|x-y|), so B_N=4[d+2|u|sqrt(d)]. At t0 B_N0. This is for EVERY positive N with exact real samples, not merely a limit or an assertion that an arbitrary grid covers. The positive-g estimate need not be uniform as g->0. Its conservatism is cost/possible UNRESOLVED at a requested tolerance, never a branch switch or removed sample.

The numerical algorithm evaluates ALL N² actual uniform phase nodes using exact rational turns and validated trig. Charge every node/refinement and trigonometric-table construction through existing `_d11_charge` with caller's shared positive work_limit. Before a pass, compare the required N² node count plus N trigonometric entries to remaining work and refuse if insufficient; do not allocate first and discover exhaustion afterward. Stream the grid minima and keep at most the N pass-local trig entries, with actual visited count and deterministic node order retained in diagnostics. `_d11_size` admits all integer/trig DAG products from input-bit/precision bounds before their allocation; finite actual MemoryError/overflow/allocation exceptions become UNRESOLVED with cause, not guessed numerical results. Pass-local reuse of N trig pairs is permitted; no global cache or alternate runner. Never skip degenerate nodes. Let node intervals[Li,Hi] enclose4lambda-(xi), including phase/root arithmetic error. Then

    G_N² in[L_N,H_N]=[min_i Li,min_i Hi],
    G² in[max(0,L_N-B_N),H_N].

Compute B_N outward with a proved pi interval and the CORRECT branch. Grid subset plus covering proves inclusion; sampled convergence is not a substitute. Return f only if its exact-ratio maximum distance to this FINAL physical interval<=abs_error. Thus pointwise, minimization enclosure, sampling, pi/root and float-conversion errors all count. Retain the sampled interval separately; never assert finite-mesh attainment of a continuous minimizer. Fixed N with an excessive covering error returns UNRESOLVED, not an unrequested larger N or tolerance. N1/Gamma, N divisible3/Dirac and a mesh missing an interior minimizing point are mandatory complements.

The independent spectral reference uses actual physical bonds/k/three-bond F and existing `hermitian_reference`: `eighe` proposes dyadic vectors/eigenvalues only; outward residual and Gram defect certify their enclosures under its actual tighter budget. Preserve independent reference passes/contraction checks. Production formula versus a second copy of itself is not this oracle. Separate exact polynomial/threshold identities and physical range proofs establish global facts; finite high-precision matrix samples do not. A reference UNRESOLVED is not production PASS.

## 8. Formal/native construction in EXISTING source owners

Intended lemma descriptions below are proof obligations, not claims that proposed names already exist. Recover actual Mathlib declarations/spellings under the normal worker protocol; build missing library-grade infrastructure rather than assume the conclusion or declare infeasibility.

| Existing source owner | Required substantive result | Actual inherited dependency |
|---|---|---|
| Honeycomb.lean | Gram determinant nonzero; explicit inverse phase map; reciprocal increments; exact ideal-neighbour constructor | `IsHoneycombNeighbours`, `isHoneycombChart_of_neighbours`, `chart_len_sq_of_neighbours`, `planeDot` |
| Honeycomb.lean | Upper norm-square bound9t² AND every x in[0,9t²] attained by actual k; t0 singleton | `structureFactorT`, `neighbourSum_eq_structureFactor`, unit exponential norm and cosine/acos range law |
| BernalBilayer.lean | Dphi unitary/all16-entry conjugacy; actual nonzero eigenvector and chirality transport | `bernalBloch`, `bernal_eigenvector_iff`, `bernal_chirality_two`; swapped countermodel retained |
| BernalBilayer.lean | Four complete branches/nonnegativity/repeated roots and arbitrary-real-gamma sign reduction | `bernal_det_eq`, `bernal_bands_real`, squared-coupling identity |
| BernalBilayer.lean | `IsLeast` of ACTUAL physical spectral E² set at lambda-(min(x*,X)); actual k/E/nonzero-v membership and lower-bound direction | Old scalar floor/attainment/`bernal_halfGapSq_isLeast`, new range/unitary and branch monotonicity |
| BernalBilayer.lean | Exact iff attainment regime, Gamma strict boundary, zero/sign/intersection/scaling and actual non-Dirac suppression | Derived polynomial/radical identities; no circular-ring conclusion |
| Honeycomb/Bernal owners | All positive-N circular grid cover, exponential norm-square modulus, positive-g Lipschitz/zero-g Holder bounds and G_N² error | ACTUAL nodes/complete finite minimum; covering is proved, not assumed |

Define the physical spectral set by `exists k E v`, v!=0, actual H(F) eigenvector equation and z=E². Do not define a structure already carrying physical attainment or rename arbitrary x physical. Prove BOTH membership and lower-bound directions of IsLeast. Full-gap-square theorem multiplies the actual least half-gap by4 with U=2u; `bernal_fullGapSq_eq` alone is scalar algebra, not the new physical theorem. Spectral periodicity on real k plus inverse chart supplies reciprocal-torus reading; any quotient representation must agree with actual spectra and retain the general real-k theorem. No assumed continuum bundle is needed.

ROOT owns live ADR008 acquire/prepare/probe/dispatch. No lane is assumed open here. Required native receipts bind exact source/import/toolchain/dependency fingerprints, actual declaration names, complete diagnostics and kernel/axiom scans. No sorry/project axiom/native_decide/renamed scalar theorem discharges the result. Add genuine actual-neighbour interior/Gamma/zero matrix nonvacuity and refutation controls. Independent reviewer reads whole source/math and actual matching evidence; root owns authoritative current build/extraction. Local proof-call success is not a published build or gate result.

## 9. Complete control complements and original evidence

Retain every existing17 formula, original tests/assertions/precision/domain/refusal behavior, all9 structured claim meanings/history and original R49/R50 evidence. Preserve all54 completed author records and the failed acos roundtrip as dated supplementary evidence; no retrospective pass. R50's independent exact polynomial/matrix checks are carrying manual evidence, not an executed new suite.

Required actual controls under the later coherent grant:

- Generate valid rotated/reflected/rescaled ideal bonds; verify chart inverse, reciprocal shifts, Delta sign/nonzero, complex three-bond F and Dphi16-entry/eigenvector bridge. Collinear/zero/sheared wrong-chart controls cannot manufacture independent phases. Equal-spectrum swapped orientation stays a rejected model identity.
- Physical k for interior/Gamma/Dirac/t0, negative/zero t/g/u, exact branch intersections/repeated roots, threshold equality and both sides. Same u/g with t1,t1/10,t0 decisively detects a two-input alias. Include signed-t phase and zero-g positive boundary versus attained crossing.
- Exact algebraic threshold fixtures and rational/binary near-threshold production inputs; exact polynomial choice versus interval radical enclosure. Tiny/huge/underflow/overflow/cancellation/allocation failures, no epsilon regime flip, small-g-to-zero switch or fabricated zero.
- Actual physical matrix residual/Gram reference, all low/high branch multiplicities and complete spectral budgets. Independent exact determinant/positive-denominator checks; raw `np.linalg.eigvalsh` or free f=sqrt(x*) samples alone cannot establish physical geometry/total error.
- Uniform N1,2,3/larger grids, actual node count and independent finite min; pointwise+covering+rounding errors. Valid translated mesh retains bound; clustered/wrong-coordinate grids do not. Omit a node/drop sampling error/underbound pi or root/mislabel grid optimum exact torus: unchanged independent oracles must be red.
- Interior root bracket, exact endpoints, quarter-point equality and near-yX; no clamp or float roundtrip q. Bounded-work exhaustion/straddling denominator/unrepresentable k gives UNRESOLVED. Energy-at-rounded-k error is separate from exact k* existence.
- Production0->nonzero->restored0 at actual public t-dependent API, registry/claim/consumer and error-display seams. Seed hardcode t1, scalar boundary fallback, missing factor4/fullU conversion, dropped physical0/0 branch, skipped node or hidden uncertainty/status. Preserve original source/index/oracles/restoration journal. No copied formula or test mirroring words can earn that evidence.

Root runs original full scientific/provenance/notebook/figures/graph suites and additions at the accepted source. Old passing populations stay at their hashes. This design or unreviewed enclosures cannot supply that runtime acceptance.

## 10. Exact current consumer propagation and closure

ONE domain obligation has multiple consumers: `PAPER_DEPENDENCIES['D11']['key_claims'][7]` is the eighth of9 claims and unconditionally connects the scalar expression to finite physical momentum. Metadata summaries for `bernal_mexicanHat`, `bernal_halfGapSq_isLeast`, `bernal_fullGapSq_eq`, current scalar formula/Bernal docstrings do the same. The corrected article and scalar-family index alone do not discharge it.

After actual substantive implementation and independent acceptance:

1. Keep old scalar theorem/API bodies, names and actual scope. Register NEW physical theorem/API with t/domain/error contract; do not relabel the scalar theorem. Eighth claim states the selected crystal, interior/boundary and validation scope; other8 remain meaning-identical. Claim IDs must not silently acquire a different meaning: retain old statement/history and use existing meaning/pointer/closure writers for accepted replacement and invalidation/review. Existing sentence IDs differ from9 structured IDs.
2. Use actual literal `src/core/provenance.py` PAPER_DEPENDENCIES, `scripts/build_graph.py` and qualified Formula/TESTED_BY/source owners. New methods go inside the D11 region and real registry; `_d11_region`/population contracts detect their complete population. Preserve17 reviewed floor/old scalar delimiter/qualified module homes and genuine tests. No count/gate writer or blanket Cartesian edges prove new semantics. Every new formula has actual relevant tests; missing/unmatched status is honestly blocked/open.
3. Metadata gains real new physical theorem statements only after kernel acceptance, preserving identities/history through existing writers. Three old scalar apex summaries cannot stay universally physical. Regenerate current extraction/counts/modules/claims/graph through existing owners; old cached names or declared verification labels are not kernel/science evidence.
4. Article gains actual selected-model/range/attained regime/Gamma/zero/grid derivation with explicit manual/kernel/numerical status. `tables.py` and existing three generated index bodies use the actual renderer; no inline snippets/hand counts. Preserve existing36 source-grounded rows; new principal rows require real declarations. Reconcile source manifest/changelog. Actual canonical compile/whole article/math/tables/PDF and metadata update follow.
5. Inspected technical notebook/four Plotly/included figure source scan has no Bernal public call/panel. Do not pretend those four figures validate the new function. Rerun actual consumer discovery later; a publication numerical worked example must instantiate actual geometry/domain/error via existing notebook/plot pipeline, with independent output/pixel controls. Preserve all four old scientific panels/tests. No fake image/data/result or unowned dashboard edit supplies propagation.
6. Existing D11-07 truthful declaration rename/native propagation, standalone counts packaging and bibliography production stay open under their owners. They and full material/transport/continuum/other D11 science are not reassigned or deferred by this design. ROOT refreshes actual canonical all21-bundle gates/checkpoint/main coordination; no green cell is typed from a design.

Original physical-domain BUILD closes only after actual source/formal/numerical/consumer repair, genuine independent WHOLE verification and existing canonical recorded closure. Immediate scientifically correct Haldane/prose corrections may stand while it builds. Disclosure, a generic ROOT label, this document or a scalar fixture is not completion.


## 11. R58 authored numerical SOURCE — independent review/runtime pending

The three section5 interfaces now have authored source in the existing formulas owner, before the retained scalar delimiter. This is implementation SOURCE, not accepted runtime, new physical kernel content, material calibration or closure. All original sections1–10 remain the governing scientific contract; R55's design acceptance has not been converted into executed evidence.

- Continuous gap uses exact rational t-dependent branch/regime/y with stable positive-denominator spectral evaluation, structural zeros and explicit total binary return-error admission.
- Minimizer generates the exact ideal geometry outward, isolates the monotone phase root through quarter-point comparisons with finite shared work, constructs the actual physical k-box, and evaluates the actual three-bond Hamiltonian at its binary proposal. Uncertain phases use a rigorous midpoint trig enclosure plus a global Lipschitz radius, not discarded uncertainty. Returned coordinate bound covers every point of the box; squared-energy error retains pointwise and coordinate-modulus bounds and all interval/conversion uncertainty.
- Uniform positive-N grid preflights N²+N work before its pass-local table, charges and visits every node and streams outward minima. Gamma/Dirac exact-phase identities refine their enclosing x-boxes without dropping nodes. Its final continuous interval retains the positive-g or zero-g covering, pointwise and pi/root/conversion errors. Fixed-N/work/precision/representability/allocation exhaustion stays UNRESOLVED with stage/history/cause.
- The literal formula population extends17→20 in source order with three real functions. Every old function body, scalar refusal, test/assertion/decorator/parameter/budget and old17 population predicate is retained. Additional exact20/old17subset/three-new-real-equality controls are additive. The nine structured claim meanings, metadata scalar apices, actual physical Lean theorem claims, article/notebook/figures and canonical semantic/count writers are unchanged and remain ROOT propagation work.
- New source controls independently construct actual rotated/reflected/scaled bonds, inverse-chart k, three-bond F and all16 diagonal-unitary entries, with the existing independent Hermitian residual/Gram oracle. Branch/sign/zero/threshold/quarter-equality/grid/finite-work/precision/allocation/conversion/domain complements and nine journalled actual production mutation constructions are present. None was imported, collected or executed in R58. Old scalar free-f tests remain scalar controls, not relabelled physical evidence.

A fresh NONAUTHOR whole source/math/control review is next, then ROOT must actually execute the full old+new suites and physical references and journalled production0/nonzero/restored0 with exact restoration. Full physical geometry/range/unitary/IsLeast/grid Lean construction, normal native/kernel/import/axiom evidence, coherent consumer propagation, current compiled articles/gates/main/human review and every original material/transport/continuum/other D11 BUILD remain owed. This source status is not scientific or publication completion.


## 12. D63 repair specification: local physical error and complete evidence population

D62's actual complete two-module baseline is320PASS/2FAIL. Prior R59 whole SOURCE acceptance remains bounded; the actual failures require new construction and independent review. The following specification precedes its implementation. No precision/tolerance/work/original-oracle relaxation is permitted.

For gamma=0 write A(k)=|F(k)|, b=|u|, and A*=sqrt(y)=min(b,3|t|). Every ideal bond has norm a_CC, so for the exact minimizing k* in the returned box and binary proposal khat at Euclidean distance at most r,

    |F(khat)-F(k*)| <= |t| sum_j |exp(i khat.delta_j)-exp(i k*.delta_j)|
                         <= 3|t| a_CC r = e,
    |A(khat)-A*| <= e,
    |4(A(khat)-b)^2-4(A*-b)^2| <= 4e(2|A*-b|+e).

This is a physical three-bond amplitude estimate, valid at every orientation/reflection/scale and every decoupled regime, not an assumed scalar witness. When y=u^2 (attained crossing), |A*-b|=0 and the squared gap error is at most4e^2, quadratically small in the momentum-box radius. At the decoupled Gamma boundary it retains the nonzero2|A*-b| term. At t=0 e=0. The full physical interval pointwise spectral/binary error remains required independently, with the maximum of that error and this local modulus; no uncertainty component is discarded. Positive gamma retains its existing proven global modulus and zero-gamma is still selected by exact equality only. The grid has no momentum witness and retains its original global Holder covering estimate unchanged.

The old gamma=0 global norm-square Holder estimate is valid but insufficient at an attained zero: it is O(sqrt(r)), whereas actual squared gap error is O(r^2). At(.5,0,.5,1), k*=(pi/2,-pi/(2sqrt3)), nearest-binary coordinate error alone is about6e-17 in the first coordinate. The old sufficient certificate needs radius below about1.3e-18 at energy_error1e-8, so finer root brackets cannot make that bound fit. This is a representational error-bound obstruction, not physical infeasibility or a reason to enlarge the requested tolerance. New controls retain exact quarterpoint/nearboundary inputs and original100000 shared work. Root inversion and finite precision remain bounded; genuine resource/uncertainty exhaustion still refuses with actual cause/history.

For graph coverage the current per-assertion meaningful-dataflow scanner intersects with the frozen old17 floor. It therefore hides relevant equalities for new real APIs from its qualified-test list, even though the actual existing extractor sees their canonical calls/equalities. Replace only that eligibility population with the current source-derived D11 public region union actual producer-consumer closure, retaining old17 as the immutable subset floor and exact registry/source equality in their existing guards. Preserve every old per-assertion equality/dataflow/alias/reflexivity rule and the complete actual graph union/classification assertion. No graph edge is inserted by hand and no test-kind rule changes. Add unmocked current-population equality coverage and negative bounds/unrelated/reflexive tests for the new APIs. Existing nine production sensitivity definitions, all old599 assertions and all scientific consumers remain intact; these additions are source-constructed UNRUN until ROOT admission.

Genuine whole nonauthor mathematical/source/control review and actual complete original two-module execution plus all nine production sensitivities follow. Full formal physical/kernel/native, article/nine-claim/apex/consumer/writer/gate/main/material/continuum duties remain unchanged.
