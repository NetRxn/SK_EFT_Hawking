
"""Phase A: current-input reader/consumer controls, no table migration prerequisite."""
from pathlib import Path
import hashlib
import json
import re
import sys
import pytest
ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT/'scripts'), str(ROOT)]
import validate_helpers as H
from validation.checks import papers_prose as pp, prose_lean_refs as pr
from validation.checks import bundles_readiness as br
import seed_journal

HOST = ROOT/'papers/E1/tables/lkb_device_params.tex'
DRAFT = ROOT/'papers/E1/paper_draft.tex'

def details(result):
    return [(d.name, d.passed, d.message, d.measured) for d in result.details]

def test_parent_alias_context_and_ordered_repeat_maps(tmp_path):
    draft=tmp_path/'paper_draft.tex'; child=tmp_path/'one.tex'
    draft.write_text(r'\newcommand{\lean}[1]{\texttt{#1}}'+'\n'+
        r'There is no \input{one}. Then \input{one}.')
    child.write_text(r'\lean{absent_test_reference}')
    view=H.draft_source_view(draft); text=view.require_text()
    occurrences=[(t,o)for t,o in pr._prose_verbatim_tokens(text)if t=='absent_test_reference']
    assert len(occurrences)==2
    assert pr._prose_occurrence_disclaimed(text,occurrences[0][1])
    positions=[view.locations(o,o+1)[0]for _,o in occurrences]
    assert positions[0]['occurrence']!=positions[1]['occurrence']
    assert all(p['path']==child.relative_to(view.root).as_posix() for p in positions)
    child.write_text('source changed')
    assert not view.still_current()

@pytest.mark.parametrize('kind',['missing','cycle','invalid_utf8','comment_only','bib'])
def test_active_population_and_physical_superset_are_distinct(tmp_path,kind):
    draft=tmp_path/'paper_draft.tex'; child=tmp_path/'one.tex'
    if kind=='comment_only':
        draft.write_text('% \\input{one}\nVisible body.'); child.write_text('not reader prose')
    elif kind=='bib':
        draft.write_text('Visible body.'); (tmp_path/'sibling.bib').write_text('not reader prose')
    else:
        draft.write_text(r'\input{one}')
        if kind=='cycle':child.write_text(r'\input{paper_draft}')
        if kind=='invalid_utf8':child.write_bytes(b'\xff')
    view=H.draft_source_view(draft)
    if kind in ['missing','cycle','invalid_utf8']:
        assert view.gaps
        with pytest.raises(ValueError):view.require_text()
    else:
        assert not view.gaps and 'not reader prose'not in view.text
        assert len(view.sources)==1 and len(view.files)>len(view.sources)

def run_seed(check,addition,assert_mutant):
    assert HOST.is_file() and r'\input{tables/lkb_device_params.tex}' in DRAFT.read_text()
    original=HOST.read_bytes();mtime=HOST.stat().st_mtime_ns;baseline=details(check())
    with seed_journal.seeded_mutation(HOST,lambda text:text+'\n'+addition+'\n',
            reason='phase A actual current included-input consumer non-vacuity'):
        assert_mutant(check())
    assert HOST.read_bytes()==original and HOST.stat().st_mtime_ns==mtime
    assert details(check())==baseline
    assert not seed_journal.outstanding(include_live=True)

def test_PRODUCTION_current_input_absent_theorem_red_restore():
    def red(result):
        assert not result.passed
        assert any('rthree_missing_theorem' in d.message and str(HOST)in d.message for d in result.details)
    run_seed(pr.check_prose_theorem_reference_coverage,r'\texttt{rthree_missing_theorem}',red)

def test_PRODUCTION_current_input_dangling_ref_red_restore():
    def red(result):
        assert not result.passed
        assert any('rthree_missing_label'in d.message and str(HOST)in d.message for d in result.details)
    run_seed(pp.check_bundle_cross_references_resolve,r'\ref{rthree_missing_label}',red)

def test_PRODUCTION_current_input_emdash_red_restore():
    count=lambda result:next((int(x.message.split()[0]) for x in result.details if x.name=='E1'),0)
    old=count(br.check_bundle_prose_em_dash_free())
    def red(result):
        assert not result.passed and count(result)==old+1
    run_seed(br.check_bundle_prose_em_dash_free,'Visible production control — source.',red)


def test_PRODUCTION_current_input_missing_child_is_unmeasured_restore():
    def red(result):
        assert not result.passed and not result.measured
        assert any('rthree_missing_child'in d.message for d in result.details)
    run_seed(pr.check_prose_theorem_reference_coverage,r'\input{rthree_missing_child}',red)

def test_PRODUCTION_registered_module_reach_changes_actual_ratchet_restore():
    module_host=ROOT/'papers/I1/tables/table3_finding_classes.tex'
    assert module_host.is_file() and r'\input{tables/table3_finding_classes.tex}' in (ROOT/'papers/I1/paper_draft.tex').read_text()
    original=module_host.read_bytes();mtime=module_host.stat().st_mtime_ns
    baseline=br.check_bundle_lean_module_coverage();before=details(baseline)
    count=lambda r:int(next(d.message for d in r.details if d.name=='ratchet').split()[0])
    old=count(baseline)
    with seed_journal.seeded_mutation(module_host,lambda text:text+'\nAPSEta.He3A\n',
            reason='real registered module appears only in actual included source'):
        assert count(br.check_bundle_lean_module_coverage())==old-1
    assert module_host.read_bytes()==original and module_host.stat().st_mtime_ns==mtime
    assert details(br.check_bundle_lean_module_coverage())==before
    assert not seed_journal.outstanding(include_live=True)

def test_PRODUCTION_current_input_readiness_placeholder_red_restore():
    import readiness_gates as rg
    idx=rg.GraphIndex(dict(nodes=[dict(id='placeholder:rthree',type='PlaceholderMarker',
        name='rthree_known_placeholder')],links=[]))
    measure=lambda:rg._eval_lean_proof_substance(dict(id='paper:E1'),idx)
    before=measure();original=HOST.read_bytes();mtime=HOST.stat().st_mtime_ns
    with seed_journal.seeded_mutation(HOST,lambda text:text+'\n'+r'\texttt{rthree_known_placeholder}',
            reason='real included input must reach existing Gate5 consumer'):
        assert measure().state=='blocked'
    assert measure()==before
    assert HOST.read_bytes()==original and HOST.stat().st_mtime_ns==mtime
    assert not seed_journal.outstanding(include_live=True)

def test_PRODUCTION_current_input_graph_citation_and_portable_source_restore(monkeypatch):
    import build_graph as bg
    import scripts.extract_lean_deps as loader
    held=ROOT/'lean/lean_deps.json'
    monkeypatch.setattr(loader,'load_lean_deps',lambda:json.loads(held.read_text()))
    nodes=bg.extract_lean_declaration_nodes();ids={n['id']for n in nodes}|{'paper:E1'}
    def edges():return [e for e in bg.extract_cites_theorem_edges(ids)if e['source']=='paper:E1']
    before=edges();original=HOST.read_bytes();mtime=HOST.stat().st_mtime_ns
    with seed_journal.seeded_mutation(HOST,lambda text:text+'\n'+r'\texttt{acousticMetric_det}',
            reason='real input must produce theorem edge through existing graph resolver'):
        actual=edges();added=[e for e in actual if e['reference']=='acousticMetric_det']
        assert added and any(x['path']=='papers/E1/tables/lkb_device_params.tex'
                             for e in added for x in e['source_locations'])
        assert all(not Path(x['path']).is_absolute()for e in actual for x in e['source_locations'])
    assert HOST.read_bytes()==original and HOST.stat().st_mtime_ns==mtime
    assert edges()==before
    assert not seed_journal.outstanding(include_live=True)


@pytest.mark.parametrize('literal', [
    r'\verb|\input{not_a_file}|',
    r'\verb*+\input{not_a_file}+',
    r'\verb|100% \input{not_a_file}|',
    r'\verb%\input{not_a_file}%',
])
def test_A2_literal_inputs_remain_visible_without_becoming_dependencies(tmp_path, literal):
    from validation._tex import _tex_source_views
    draft = tmp_path / 'paper_draft.tex'
    child = tmp_path / 'active.tex'
    child.write_text('Active child.')
    source = literal + '\n' + r'\input{active}'
    draft.write_text(source)
    visible, commands = _tex_source_views(source)
    view = H.draft_source_view(draft)
    assert not view.gaps and view.still_current()
    assert literal in visible and literal in view.require_text()
    assert len(visible) == len(commands) == len(source)
    assert commands[:len(literal)] == ' ' * len(literal)
    assert child.resolve() in view.sources
    assert any(p.name == 'not_a_file.tex' for p in view.files)
    assert not any(p.name == 'not_a_file.tex' for p in view.sources)


def test_A2_comments_cannot_activate_verbs_or_inputs_and_offsets_stay_exact(tmp_path):
    from validation._tex import _strip_tex_comments, _tex_source_views, TEX_VERB_RE
    source = ('% ' + r'\verb|% literal| \input{hidden}' + '\r\n'
              + r'\verb*|50% literal| \input{active}' + '\r\n'
              + r'\% is visible % \input{also_hidden}' + '\r\n')
    draft = tmp_path / 'paper_draft.tex'
    draft.write_bytes(source.encode())
    (tmp_path / 'active.tex').write_text('Active text.')
    visible, commands = _tex_source_views(source)
    assert pr._PROSE_VERB_RE is TEX_VERB_RE
    assert _strip_tex_comments(source) == visible
    assert len(source) == len(visible) == len(commands)
    assert [i for i, c in enumerate(source) if c in '\r\n'] == [
        i for i, c in enumerate(visible) if c in '\r\n']
    assert 'hidden' not in visible and 'also_hidden' not in commands
    assert r'\verb*|50% literal|' in visible
    assert r'\% is visible' in visible
    assert commands.index(r'\input{active}') == source.index(r'\input{active}')
    view = H.draft_source_view(draft)
    assert not view.gaps and 'Active text.' in view.require_text()


@pytest.mark.parametrize('ending', ['\n', '\r\n'])
def test_A2_fingerprints_hash_exact_utf8_line_endings_and_detect_real_drift(tmp_path, ending):
    draft = tmp_path / 'paper_draft.tex'
    child = tmp_path / 'child.tex'
    raw = ('Parent.' + ending + r'\input{child}' + ending).encode()
    child_raw = ('α source.' + ending + r'\texttt{a2_reference}' + ending).encode()
    draft.write_bytes(raw)
    child.write_bytes(child_raw)
    view = H.draft_source_view(draft)
    assert not view.gaps and view.still_current()
    assert view.contents[draft.resolve()] == raw.decode('utf-8')
    for path, data in [(draft, raw), (child, child_raw)]:
        assert view.file_hashes[path.relative_to(view.root).as_posix()] == hashlib.sha256(data).hexdigest()
    offset = view.text.index(r'\texttt{a2_reference}')
    assert view.location(offset) == (str(child.resolve()), 2)
    span = view.locations(offset, offset + 1)[0]
    assert span['file_sha256'] == hashlib.sha256(child_raw).hexdigest()
    child.write_bytes(child_raw + b'Actual byte drift.')
    assert not view.still_current()


def _A2_reference_corpus(tmp_path, monkeypatch, source):
    root = tmp_path / 'papers'
    bundle = root / 'D1'
    bundle.mkdir(parents=True)
    (bundle / 'paper_draft.tex').write_text(source)
    monkeypatch.setattr(H, 'PAPERS_DIR', root)
    monkeypatch.setattr(H, 'bundle_codes_or_unmeasured', lambda: (['D1'], None))
    return root, bundle


@pytest.mark.parametrize('inactive', ['commented_include', 'commented_label', 'literal_label'])
def test_A2_inactive_tex_labels_do_not_rescue_active_references(tmp_path, monkeypatch, inactive):
    prefix = {
        'commented_include': '% ' + r'\input{hidden}',
        'commented_label': '% ' + r'\label{ghost}',
        'literal_label': r'\verb|\label{ghost}|',
    }[inactive]
    root, bundle = _A2_reference_corpus(tmp_path, monkeypatch,
        prefix + '\n' + r'\label{base}\ref{base} \ref{ghost}')
    (bundle / 'hidden.tex').write_text(r'\label{ghost}')
    result = pp.check_bundle_cross_references_resolve()
    assert not result.passed and result.measured
    assert any(d.name == 'reference_site' and 'ghost' in d.message for d in result.details)


def test_A2_active_included_labels_resolve_and_repeated_labels_fail(tmp_path, monkeypatch):
    root, bundle = _A2_reference_corpus(tmp_path, monkeypatch,
        r'\input{child} \ref{included}')
    (bundle / 'child.tex').write_text(r'\label{included}')
    assert pp.check_bundle_cross_references_resolve().passed
    (bundle / 'paper_draft.tex').write_text(r'\input{child} \input{child} \ref{included}')
    result = pp.check_bundle_cross_references_resolve()
    assert not result.passed and result.measured
    assert any(d.name == 'duplicate_label' and 'included' in d.message for d in result.details)


@pytest.mark.parametrize('filename', ['compat.sty', 'compat'])
def test_A2_physical_style_and_extensionless_label_compatibility_is_retained(tmp_path, monkeypatch, filename):
    root, bundle = _A2_reference_corpus(tmp_path, monkeypatch,
        r'\label{base}\ref{base} \ref{compat}')
    style = bundle / filename
    style.write_text(r'\label{compat}')
    original = H.draft_input_closure
    monkeypatch.setattr(H, 'draft_input_closure', lambda tex, _seen=None: original(tex, _seen) + [style])
    result = pp.check_bundle_cross_references_resolve()
    assert result.passed and result.measured
    assert style.resolve() not in H.draft_source_view(bundle / 'paper_draft.tex').sources


def test_A2_legacy_inactive_labels_do_not_satisfy_the_legacy_ratchet(tmp_path, monkeypatch):
    root, bundle = _A2_reference_corpus(tmp_path, monkeypatch, r'\label{base}\ref{base}')
    legacy = root / 'paper9_legacy'
    legacy.mkdir()
    (legacy / 'paper_draft.tex').write_text('% ' + r'\input{hidden}' + '\n' + r'\ref{ghost}')
    (legacy / 'hidden.tex').write_text(r'\label{ghost}')
    result = pp.check_bundle_cross_references_resolve()
    detail = next(d for d in result.details if d.name == 'legacy_ratchet')
    assert detail.measured and detail.message.startswith('1 of 1 legacy draft(s)')


def test_A2_reference_gap_details_are_unique_unmeasured_and_keep_concrete_failures(tmp_path, monkeypatch):
    root, bundle = _A2_reference_corpus(tmp_path, monkeypatch, r'\input{absent_bundle}')
    other = root / 'D2'
    other.mkdir()
    (other / 'paper_draft.tex').write_text(r'\ref{real_dangling_reference}')
    legacy = root / 'paper9_legacy'
    legacy.mkdir()
    (legacy / 'paper_draft.tex').write_text(r'\input{absent_legacy}')
    monkeypatch.setattr(H, 'bundle_codes_or_unmeasured', lambda: (['D1', 'D2'], None))
    result = pp.check_bundle_cross_references_resolve()
    assert not result.passed and not result.measured
    gaps = [d for d in result.details if d.name == 'input_gap']
    assert len(gaps) == len({d.message for d in gaps}) == 2
    assert all(not d.measured and not d.passed for d in gaps)
    for name in ['summary', 'legacy_ratchet']:
        detail = next(d for d in result.details if d.name == name)
        assert not detail.measured and not detail.passed
    assert any(d.name == 'reference_site' and not d.passed and d.measured
               and 'real_dangling_reference' in d.message for d in result.details)


def test_A2_reference_empty_readable_population_retains_unmeasured_gaps(tmp_path, monkeypatch):
    _A2_reference_corpus(tmp_path, monkeypatch, r'\input{absent}')
    result = pp.check_bundle_cross_references_resolve()
    assert not result.passed and not result.measured
    assert len([d for d in result.details if d.name == 'input_gap']) == 1
    assert all(not d.measured for d in result.details if d.name in ['input_gap', 'seam'])


def _A2_graph_corpus(tmp_path, monkeypatch, tokens, declarations):
    import build_graph as bg
    folder = tmp_path / 'papers' / 'D1'
    folder.mkdir(parents=True)
    (folder / 'paper_draft.tex').write_text(' '.join(r'\texttt{' + t + '}' for t in tokens))
    monkeypatch.setattr(bg, 'PROJECT_ROOT', tmp_path)
    monkeypatch.setattr(bg, 'extract_lean_declaration_nodes', lambda: declarations)
    short = {}
    for node in declarations:
        short.setdefault(node['id'].rsplit('.', 1)[-1], []).append(node['id'])
    monkeypatch.setattr(bg, '_LEAN_SHORT_INDEX', short)
    monkeypatch.setattr(bg, '_LEAN_MODULE_INDEX', {
        n['id']: n['meta']['full_module'] for n in declarations})
    return bg, {n['id'] for n in declarations} | {'paper:D1'}


@pytest.mark.parametrize('token,expected', [
    ('actual_result', True),
    ('SKEFTHawking.Acoustic.actual_result', True),
    ('Acoustic.actual_result', True),
    ('Reported.Module.actual_result', True),
    ('SKEFTHawking.Reported.Module.actual_result', True),
    ('WrongNamespace.actual_result', False),
])
def test_A2_graph_qualified_names_require_actual_namespace_or_module(tmp_path, monkeypatch, token, expected):
    declarations = [dict(id='lean:SKEFTHawking.Acoustic.actual_result',
        type='LeanTheorem', meta=dict(full_module='SKEFTHawking.Reported.Module'))]
    bg, ids = _A2_graph_corpus(tmp_path, monkeypatch, [token], declarations)
    edges = bg.extract_cites_theorem_edges(ids)
    assert bool(edges) is expected
    if expected:
        assert len(edges) == 1 and edges[0]['target'] == declarations[0]['id']
        assert all(not Path(x['path']).is_absolute() for x in edges[0]['source_locations'])


def test_A2_graph_ambiguous_unqualified_names_stay_unresolved(tmp_path, monkeypatch):
    declarations = [dict(id='lean:SKEFTHawking.' + ns + '.shared_result',
        type='LeanTheorem', meta=dict(full_module='SKEFTHawking.' + ns)) for ns in ['First', 'Second']]
    bg, ids = _A2_graph_corpus(tmp_path, monkeypatch, ['shared_result', 'Wrong.shared_result'], declarations)
    assert bg.extract_cites_theorem_edges(ids) == []


def test_A2_graph_deduplicates_supported_aliases_and_rejects_python_identity(tmp_path, monkeypatch):
    declarations = [
        dict(id='lean:SKEFTHawking.Acoustic.actual_result', type='LeanTheorem',
             meta=dict(full_module='SKEFTHawking.Acoustic')),
        dict(id='lean:SKEFTHawking.bundle_cross_references_resolve', type='LeanDef',
             meta=dict(full_module='SKEFTHawking.Infrastructure')),
    ]
    bg, ids = _A2_graph_corpus(tmp_path, monkeypatch,
        ['actual_result', 'Acoustic.actual_result', 'bundle_cross_references_resolve'], declarations)
    edges = bg.extract_cites_theorem_edges(ids)
    assert [e['target'] for e in edges] == [declarations[0]['id']]


def test_A2_current_methodology_literal_and_bounded_graph_are_readable(monkeypatch):
    import build_graph as bg
    import scripts.extract_lean_deps as loader
    draft = ROOT / 'papers/paper15_methodology/paper_draft.tex'
    original = draft.read_bytes()
    held = ROOT / 'lean/lean_deps.json'
    held_hash = hashlib.sha256(held.read_bytes()).hexdigest()
    view = H.draft_source_view(draft)
    assert not view.gaps and r'\verb|\input{counts.tex}|' in view.require_text()
    assert ROOT / 'docs/counts.tex' in view.sources
    monkeypatch.setattr(loader, 'load_lean_deps', lambda: json.loads(held.read_bytes()))
    nodes = bg.extract_lean_declaration_nodes()
    ids = {n['id'] for n in nodes} | {'paper:paper15_methodology'}
    edges = bg.extract_cites_theorem_edges(ids)
    assert all(e['source'] == 'paper:paper15_methodology' for e in edges)
    assert draft.read_bytes() == original and hashlib.sha256(held.read_bytes()).hexdigest() == held_hash


@pytest.mark.parametrize('first', ['direct', 'facade'])
def test_A2_registered_check_discovery_supports_both_import_orders(first):
    import os
    import subprocess
    code = """
import json,sys
from pathlib import Path
sys.path[:0] = [str(Path.cwd()/'scripts'), str(Path.cwd())]
if sys.argv[1] == 'facade':
    import validate
from validation.checks import prose_lean_refs as pr
names = pr._registered_python_check_names()
import validate
from validation._registry import _CHECKS
print(json.dumps(dict(names=sorted(names), owner=sorted(s.name for s in _CHECKS),
    identity=validate._CHECKS is _CHECKS)))
"""
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', SKEFT_VALIDATION_NO_MEMO='1')
    result = subprocess.run([sys.executable, '-B', '-c', code, first],
        cwd=ROOT, env=env, capture_output=True, text=True, check=True)
    actual = json.loads(result.stdout)
    assert actual['identity'] and actual['names'] == actual['owner']
    assert 'bundle_cross_references_resolve' in actual['names']


def _A2_empty_lean_index():
    return dict(names=set(), shorts=set(), dotted_suffixes=set(), modules=set(),
                short_to_modules={}, registry_keys=set(), excluded_theorem_keys=set(), count=0)


def test_A2_registration_snapshot_refreshes_without_mutating_prior_requests(monkeypatch):
    import validate
    from validation._registry import _CHECKS, register_check, CheckResult
    cached = _A2_empty_lean_index()
    monkeypatch.setattr(pr, '_LEAN_NAME_INDEX_CACHE', cached)
    before = pr._load_lean_name_index()
    old = list(_CHECKS)
    name = 'a2_temporary_registered_check_identity'
    assert name not in before['python_checks']
    try:
        register_check(name, 'In-memory registration snapshot control')(lambda: CheckResult(passed=True))
        after = pr._load_lean_name_index()
        assert name in after['python_checks'] and name not in before['python_checks']
        assert validate._CHECKS is _CHECKS and pr._LEAN_NAME_INDEX_CACHE is cached
    finally:
        _CHECKS[:] = old
    assert name not in pr._load_lean_name_index()['python_checks']


def test_A2_python_check_identity_is_exact_and_not_a_scientific_declaration(monkeypatch):
    index = _A2_empty_lean_index()
    index['python_checks'] = pr._registered_python_check_names()
    monkeypatch.setattr(pr, '_lean_source_declares', lambda name: False)
    monkeypatch.setattr(pr, '_physlib_declares', lambda name: False)
    name = 'bundle_cross_references_resolve'
    assert pr._resolve_prose_ref(name, index) == 'PYTHON_CHECK'
    assert pr._resolve_prose_ref('a2_unknown_cross_references_resolve', index) == 'ABSENT'
    assert pr._resolve_prose_ref('SKEFTHawking.' + name, index) == 'ABSENT'
    assert pr._resolve_prose_ref('a2_missing_scientific_theorem', index) == 'ABSENT'
    index['excluded_theorem_keys'] = {name}
    assert pr._resolve_prose_ref(name, index) == 'ABSENT'


def test_A2_actual_aristotle_exclusion_cannot_be_overridden_by_check_registration(tmp_path, monkeypatch):
    from src.core import constants
    name = 'bundle_cross_references_resolve'
    monkeypatch.setattr(constants, 'ARISTOTLE_THEOREMS', {name: 'missing-theorem-control'})
    monkeypatch.setattr(pr, '_LEAN_NAME_INDEX_CACHE', None)
    monkeypatch.setattr(H, 'load_lean_deps', lambda: [])
    monkeypatch.setattr(H, 'COUNTS_JSON_PATH', tmp_path / 'absent-counts.json')
    monkeypatch.setattr(pr, '_lean_source_declares', lambda token: False)
    monkeypatch.setattr(pr, '_physlib_declares', lambda token: False)
    index = pr._load_lean_name_index()
    assert name in index['python_checks'] and name in index['excluded_theorem_keys']
    assert pr._resolve_prose_ref(name, index) == 'ABSENT'


@pytest.mark.parametrize('consumer', ['placeholder', 'disclosure'])
def test_A2_included_scientific_failures_survive_another_drafts_gap(tmp_path, monkeypatch, consumer):
    from src.core import constants
    from validation.checks import lean_substrate as ls
    root, bundle = _A2_reference_corpus(tmp_path, monkeypatch, r'\input{claim}')
    (bundle / 'claim.tex').write_text(
        r'Formally verified \texttt{a2_placeholder}. '
        r'\texttt{a2_disclosure} establishes a result.')
    other = root / 'D2'
    other.mkdir()
    (other / 'paper_draft.tex').write_text(r'\input{missing}')
    monkeypatch.setattr(H, 'all_paper_drafts', lambda: [bundle / 'paper_draft.tex', other / 'paper_draft.tex'])
    monkeypatch.setattr(constants, 'PLACEHOLDER_THEOREMS', {
        'a2_placeholder': dict(lean_name='a2_placeholder')})
    monkeypatch.setattr(constants, 'MODELING_ASSUMPTION_THEOREMS', {
        'a2_disclosure': dict(lean_name='a2_disclosure', category='definitional')})
    check = ls.check_placeholder_not_cited if consumer == 'placeholder' else ls.check_disclosure_consistency
    result = check()
    assert not result.passed and not result.measured
    assert any(d.name == 'D1' and not d.passed and d.measured for d in result.details)
    assert all(not d.measured for d in result.details if d.name in ['input_gap', 'summary'])


def test_A2_real_prose_consumer_resolves_included_registered_identity_only(tmp_path, monkeypatch):
    root, bundle = _A2_reference_corpus(tmp_path, monkeypatch,
        r'\newcommand{\lean}[1]{\texttt{#1}} \input{checks}')
    child = bundle / 'checks.tex'
    name = 'bundle_cross_references_resolve'
    child.write_text(r'\lean{' + name + '}')
    index = _A2_empty_lean_index()
    index['python_checks'] = pr._registered_python_check_names()
    monkeypatch.setattr(pr, 'BUNDLE_CODES', ['D1'])
    monkeypatch.setattr(pr, '_load_lean_name_index', lambda: index)
    monkeypatch.setattr(pr, '_lean_source_declares', lambda token: False)
    monkeypatch.setattr(pr, '_physlib_declares', lambda token: False)
    baseline = pr.check_prose_theorem_reference_coverage()
    assert baseline.passed and baseline.measured
    assert '1 bundle Python check identifier(s)' in baseline.details[0].message
    for token in ['a2_unknown_checker_identity', 'SKEFTHawking.' + name]:
        child.write_text(r'\lean{' + token + '}')
        result = pr.check_prose_theorem_reference_coverage()
        assert not result.passed and result.measured
        assert any(token in d.message and str(child) in d.message and not d.passed
                   for d in result.details)


@pytest.mark.parametrize('check_name,detail_names', [
    ('check_bundle_prose_em_dash_free', ['summary']),
    ('check_bundle_sentence_length', ['over_100_words', 'over_60_words']),
    ('check_bundle_reader_facing_voice', ['summary']),
])
def test_A2_style_aggregate_details_do_not_measure_an_unread_population(tmp_path, monkeypatch, check_name, detail_names):
    _A2_reference_corpus(tmp_path, monkeypatch, r'\input{a2_missing_active_input}')
    result = getattr(br, check_name)()
    assert not result.passed and not result.measured
    for name in detail_names:
        assert not next(d for d in result.details if d.name == name).measured


def test_A2_included_embedded_citation_diagnostics_survive_another_bundle_gap(tmp_path, monkeypatch):
    from src.core import citations
    root, bundle = _A2_reference_corpus(tmp_path, monkeypatch, r'\input{claim}')
    (bundle / 'claim.tex').write_text(r'\texttt{doe_2024_result}')
    other = root / 'D2'
    other.mkdir()
    (other / 'paper_draft.tex').write_text(r'\input{missing}')
    monkeypatch.setattr(pr, 'BUNDLE_CODES', ['D1', 'D2'])
    monkeypatch.setattr(H, 'load_lean_deps', lambda: [dict(name='SKEFTHawking.doe_2024_result')])
    monkeypatch.setattr(pr, '_registry_surnames', lambda: {'doe'})
    monkeypatch.setattr(citations, 'CITATION_REGISTRY', {})
    result = pr.check_theorem_name_embedded_citations()
    assert not result.passed and not result.measured
    assert any(d.name.startswith('embedded_citation_missing:D1:') and d.measured
               for d in result.details)
    assert all(not d.measured for d in result.details if d.name in ['input_gap', 'summary'])
