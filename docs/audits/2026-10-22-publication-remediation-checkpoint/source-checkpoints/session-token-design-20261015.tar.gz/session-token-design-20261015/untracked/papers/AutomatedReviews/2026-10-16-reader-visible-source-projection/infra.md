---
paper: infra
bundle: infra
bundle_target: infra
tier: 2
reviewer: ROOT
kind: targeted-infra
---

# Phase A existing-reader source projection

### 1.1 — 🔴 MAJOR — Reader-visible included claims must remain in existing consumer populations

- **Severity:** major
- **Lane:** `infra`
- **Gate:** FixPropagation
- **Location:** `docs/../.claude/plugins/skeft-qa/agents/claims-reviewer.md`, `docs/architecture/QA_QI_INFRASTRUCTURE_MAP.md`, `docs/architecture/VALIDATION_ARCHITECTURE.md`, `docs/architecture/VALIDATION_GATE_TOPOLOGY.md`, `scripts/build_graph.py`, `scripts/readiness_gates.py`, `scripts/validate_helpers.py`, `scripts/validation/_tex.py`, `scripts/validation/checks/bundles_readiness.py`, `scripts/validation/checks/lean_substrate.py`, `scripts/validation/checks/papers_prose.py`, `scripts/validation/checks/prose_lean_refs.py`, `tests/test_reader_visible_phase_a.py`, `docs/superpowers/specs/2026-10-16-reader-visible-sources-r3-design.md`, `docs/superpowers/plans/2026-10-16-reader-visible-sources-r3.md`, `papers/D1/paper_draft.tex`, `papers/E1/tables/lkb_device_params.tex`, `papers/I1/tables/table3_finding_classes.tex`
- **Verify:** `python -B -m pytest -m '' -q -s -p no:cacheprovider --basetemp=.codex/continuity/publication-phase-A-qualification-r1/pytest-tmp tests/test_reader_visible_phase_a.py tests/test_d5_prose_lean_refs.py tests/test_d5_papers_prose.py::TestBundleCrossReferencesResolve tests/test_unscannable_input_guard.py tests/test_validate_registry_contract.py`
- **Independent review:** Current source needs literal-aware include traversal, active-only .tex labels, qualified graph resolution, exact CRLF fingerprints and consistent unmeasured reference details. New exact CheckSpec membership must preserve scientific resolver boundaries. A2 source-only repairs precede separately admitted qualification; historical selected results and index failures remain unchanged.
- **Observed:** Existing raw-only theorem/ref/module/graph/readiness readers omit included claims, and style/gap readers do not share active-text scope. Current E1/I1 included artifacts provide independent production controls. The retained selected unscannable-input suite also seeds D1.
- **Expected:** One existing-owner projection with complete active source/gap semantics, parent aliases/context/source maps, unchanged resolvers/thresholds and journalled real-input non-vacuity. All fourteen retained paths and the three temporary production paths are one explicitly reserved allocation, not a planner guarantee over absent files.
- **Execution contract:** ROOT admits the existing paired Python runtime, exclusive clean whole-S journal and exact source/lock/temp/preservation effects in the reviewed Phase A allocation before this command runs. No uv sync/install/cache/dependency creation. The pytest session autouse repair must have nothing to repair; any outstanding live/orphan/corrupt entry or orphan backup/tmp blocks launch, not permission to restore another owner's source.
- **Limits:** This Verify qualifies only the allocated current-input package. Existing corpus reds, broader default/plugin/owner gates, CodeQL, raw-index exceptions, later table/provenance/compile work and publication gates remain independent and unwaived. No source/science correspondence finding or unrelated overlapping issue closes with this item.
