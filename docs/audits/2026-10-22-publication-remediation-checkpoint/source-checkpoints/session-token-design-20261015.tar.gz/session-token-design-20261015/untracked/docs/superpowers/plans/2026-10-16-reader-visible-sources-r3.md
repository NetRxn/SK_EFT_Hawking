# Reader-visible source projection: phase-specific execution plan

Proposed only. All phases require their own complete acceptance boundary.

A. ROOT reconciles the actual focused finding and connected consumer target group
through the existing parser/orchestrate planner before code. Owners/spec precede
source. Allocate an exclusive ordinary Python interval and existing seed journal
for D1 paper_draft, E1 lkb_device_params and I1 table3_finding_classes. The selected existing D1 guard remains in Verify; E1/I1 parent drafts and all three complete bundles are preserved bytes+mtime. Freeze source/index,
canonical JSON, all unowned outputs/histories/registries and missing human states.
Apply the complete reader/consumer/doc/test package; no manuscript/spec/output or
catalog edit. Actual tests exercise current included artifacts, never future D9
snippets. Use the phase-A exact Verify in the reviewed proposal. Capture each real
consumer baseline, seeded delta/red, exact bytes/mtime/details/journal restoration.
The graph test reads the actual held canonical JSON through a read-only loader
seam; it must not trigger extraction/refresh/build. Compare all real-input source
origins, active/physical populations, aliases/context, gaps, module/graph/ref/style
outcomes. Run relevant registry/memo/helper/nonmeasurement and normal scope/default
plugin obligations. Preserve and explain old/new exposed reds without a threshold
increase or fake full-green assertion. Fresh independent whole A review follows.

B. Independently review all existing per-unit source/historical evidence and the
actual no-write/catalog plan. ROOT's bounded manifest evidence receipt does not
accept current semantic binding, science, catalogs or migration. Keep every unit,
history and UNKNOWN. Any actual necessary payload must be reviewed before C.

C. After accepted A+B, allocate one coherent table/renderer/necessary-provenance
source-display transaction. Preserve all reviewed cells/captions/citations/status
language, D9 grouping, D10 spacing and D1 inline hierarchy. Selected render loads
all current specs before choosing writes; inspect import effects and preserve all
unowned outputs. Global freshness is a separate writer. No speculative ingest
mode, source-location audit, absent human-state creation or catalog acceptance is
allocated. Source snapshot UI tests and whole table/D1 hierarchy controls have a
separate C Verify; they cannot qualify A. A new necessary catalog transaction would
need its exact pins, strict original-schema compatibility, lock/retry/write effects
and fresh review, rather than an invented exactly-once promise.

D. Allocate seven-manuscript multipass compile/ref checks and rendered pixel review,
then fresh whole frozen-candidate source/effects/provenance/science/layout review.
ROOT owns supported finding closure and ordinary Git/PR/main integration. Broader
full-project/publication/runtime gates remain distinct.


## A1 exact allocation and effects

ROOT files the focused finding and accepted doc-first spec/plan, parses its actual
identity and declares the full retained/new/temporary path reservation before code.
The existing planner groups by each finding's own canonical existing file set and
checks overlaps at dispatch; it does not transitively merge every overlapping issue.
Nonexistent new files are explicit creation reservations. The hidden plugin path
uses the measured canonical-equivalent Location spelling docs/../.claude/... because
the current target parser strips a leading dot. Do not claim planner ownership of
unresolved paths; ROOT reserves all fourteen retained paths, three seeded files and
the journal/evidence/temp resources explicitly. All overlapping unrelated findings
remain open and are deferred from this same S interval, not silently absorbed.

Before pytest, capture complete originals and byte/mtime/mode pins for D1/E1/I1
bundles, all scientific drafts/catalogs/audits/append histories, missing human
states, canonical data/registries, outputs and the raw/semantic index. Admit only a
clean exclusive whole-S journal: outstanding(include_live=True) is empty and no
orphan .bak/.json/.json.tmp exists. Retain old persistent locks; do not infer a lease
from lock contents. If dirty, stop before the autouse repair fixture and return to
ROOT for separate ownership reconciliation. Never disable that fixture to hide debt.

Use the pre-existing P .venv Python via a captured PATH prefix, cwd S and source
origins S, PYTHONDONTWRITEBYTECODE=1, GIT_OPTIONAL_LOCKS=0,
SKEFT_VALIDATION_NO_MEMO=1 and PYTEST_DISABLE_PLUGIN_AUTOLOAD=1. The exact finding
Verify is Python/pytest directly, not uv; S has no venv. No dependency creation or
cache/install action is admitted. The declared new absent --basetemp directory is
owned test scratch; pytest may recreate/remove that directory, never an existing
unrelated one. Builtin fixtures and repo conftest remain enabled. Explicit test
paths do not run the plugin suite and are not a default/full-suite claim.

Allocate existing journal per-path lock metadata, UUID backup/entry/tmp durability
files and their normal removal, plus pytest scratch/evidence receipts. Persistent
locks for the three declared paths may be created/updated and retained; unrelated
locks and all unowned artifacts remain exact. Source bytes/mtime/mode restore is
mandatory for every seed, including each of four expected D1 fixture invocations.
Capture actual baseline/mutant/restored check details and source/module origins
around existing calls using passive one-off observation, not mirrored tests or a
new permanent harness. On normal failure use existing context restoration; retain
any abnormal journal evidence and return to ROOT, without broad repair/reset.

After selected Verify, rehash the complete scientific/index/journal/unowned set.
A clean journal means no outstanding entry/backup/tmp; persistent allocated locks
are reported separately, not described as byte-identical. Any raw-index change is
FAILED/causeUNKNOWN until independently explained; never repair/relabel history.

Normal helper/memo/nonmeasurement/registry/default/plugin/verify_scope obligations
remain mandatory before whole A acceptance, but the complete broad effect universe
is not authorized by this three-source-seed interval. verify_scope includes a fast
suite and counts_fresh; counts_fresh can invoke update_counts/ExtractDeps and write
global canonical artifacts. Default/plugin tests also create subprocess and temp
Git/fixture artifacts and may have production seeds beyond D1/E1/I1. ROOT must
inspect/allocate those exact effects in a separate qualification stage; no Lean,
global writer, network/UI or broad repair enters this narrow allocation implicitly.
The infra planner's dashboard gate is recorded for ROOT applicability review, not
waived or represented by this pytest result. Fresh whole independent A review and
ROOT acceptance follow the complete required evidence. C1-C3 and later C/D stay
deferred and are not rewritten or accepted by this A1 repair.


## A2 ordered source and qualification allocation

1. ROOT freezes the independent implementation/design review, amends this spec,
   plan and focused finding, and refreshes actual parser/planner overlap evidence.
   A fresh adversarial pass checks the amended source-only contract before code.
2. One publication writer repairs the entire A2 source contract in the existing
   twelve implementation paths plus scripts/validation/_tex.py; the existing new
   test path remains the only test creation target. Architecture and claims-reviewer
   documentation follow the actual owners in the same source package. ROOT alone
   writes this finding/spec/plan, notebooks, registries and integration artifacts.
   No tests, seeds, runtime installation, cache or compiled artifact, Git writes,
   manuscript/output/catalog changes, controller action or shared global writer
   is authorized during this source-only interval. Capture whole changed-file diff,
   hashes and unresolved execution prerequisites; do not mark A accepted.
3. Separately ROOT establishes an actual normal dependency/runtime target. S has no
   Lean cache. Matching manifests do not admit source dependencies there. Either a
   documented normal owner route with exact command/pins/effects exists, or use an
   already normally admitted primary/registered-slot candidate after reviewed-source
   equivalence and isolation checks. No ad-hoc dependency copy/symlink, production
   resolver redirection, extra Lean slot or worker-native build is authorized.
4. Before broader tests, inventory transitive seed/helper effects and actual marker
   collection. Reserve lean/SKEFTHawking.lean (memo tests seed it), dynamically derived
   algebra fixtures, manifests/lakefile/constants, all corpus/review/citation/journal
   targets and persistent locks. Journal-kill/repair controls may signal only their
   owned temporary processes and entries in an explicitly exclusive clean interval.
   Serialise all source/pin/memo mutations against builds and extraction.
5. Preserve verify_scope as the canonical driver. Its nested uv children do not
   inherit command-line basetemp/cacheprovider options merely because the parent
   had them. Admit actual child interpreters/source origins and inherited supported
   environment/options or explicitly reserve their real .pytest_cache, TMPDIR,
   basetemp and uv/cache effects, including destructive scratch reuse. Verify the
   counts_fresh nested child as well. Parent Python provenance alone is insufficient.
6. ROOT allocates counts_fresh/update_counts/ExtractDeps/load_lean_deps canonical
   JSON/hash/counts/regen-lock/cache/build effects and source epoch separately. A
   held regeneration lock may yield stale data; retain actual outputs/errors and
   verify freshness. No production DB, UI or network is implicit. Resolve dashboard
   gate applicability explicitly. Keep all historical raw-index exceptions failed
   and unexplained unless actual evidence establishes their cause; never reset or
   fabricate attribution. Those exceptions do not prohibit independent source work.
7. Re-run the exact finding Verify only after a fresh selected interval. Then execute
   the complete allocated helper/memo/default/plugin/canonical-scope obligations,
   record real consumer baseline/mutant/restored evidence, preserve all old/new reds
   without raising thresholds, and obtain whole independent frozen-candidate review.
   Source-only repair, selected green and normal dependency admission are distinct
   from whole A, publication, security, closure and merge acceptance.
