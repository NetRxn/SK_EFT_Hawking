# Reader-visible source projection: phased r3 design

Proposed, unexecuted and subject to whole independent review and ROOT allocation.

Phase A extends the existing physical dependency owner with active ordered text
and source maps. Cache membership remains conservative; visible physical source
sites and logical repeated occurrences are explicitly different projections. All
directly affected theorem/ref/module/graph/readiness/disclosure/style consumers
move together, including em-dash. Parent aliases and existing contextual predicates
remain in logical order; active gaps, cycles, invalid text and source drift are
explicit. Graph coordinates are relative snapshot evidence. No new checker, table
renderer, manuscript, catalog, ingest mode or dashboard source-location deployment
is needed for A to be useful. Current E1 and I1 included inputs provide non-vacuity.

B is the independently accepted historical/current evidence manifest plus an
accepted no-write/catalog plan. Evidence acceptance is narrower than current
semantic binding or scientific acceptance. The measured default is to keep all
existing catalog/history bytes and missing human states exact.

C follows accepted A+B. It moves the complete reviewed tables and preserves
grouping/spacing, while any necessary source display is a computed snapshot
assessment, never metadata-selected path reads or persisted CURRENT claims.
No location-only writer is proposed. If B establishes an actual necessary catalog
payload, ROOT must review that complete strict-schema/writer/UI transaction before
C; this design does not invent it or bypass ordinary ingestion.

The computed assessment contract is logical-quote-snapshot/v1: string schema,
state UNKNOWN or MATCHED_SNAPSHOT, fixed enum reason, content fingerprint string,
ordered owner-generated relative locations, logical integer interval for a unique
verified match and null interval/empty locations otherwise. The function accepts
a trusted view, string quote and optional expected fingerprint only. It never
accepts caller source fragments, path/order/reason metadata or historical snapshot
file pointers. Multiple/repeated quotes are ambiguous; missing/changed inputs or
a mismatched expected fingerprint are UNKNOWN. Every matched result is explicitly
a snapshot. A later current use must rederive it from a fresh view.

D owns affected multipass compilation/ref logs, pixels, fresh frozen-candidate
whole review, supported closure and normal integration. Old red corpus gates,
CodeQL and raw-index exceptions remain unwaived throughout.


## A1 declared execution population

The phase-A exact Verify includes the retained D1 unscannable-input production
fixture as well as current E1/I1 controls. Its allocation reserves all fourteen
retained paths, the three existing seeded production files, durable journal/lock
resources and fresh owned evidence/temp space. D1/E1/I1 complete bytes/mtime and
all unowned canonical/catalog/output/index state are protected. Existing autouse
repair is admitted only on a clean exclusively reserved whole-S journal; no
unrelated orphan restoration is authorized. Normal/default/plugin/helper/global
writer qualification remains a separate explicit owner gate. Proposed code and
tests are otherwise the exact reviewed r3 Phase A package. No new Phase C design,
source installation, writer or current-location acceptance follows from A1.


## A2 source repair contract

The next allocation repairs Phase A source before further qualification. A1 records
only its completed selected interval; it does not authorize another test or seed.
Extend the existing owners in place; create no alternate parser, resolver, registry
or qualification harness. The complete original A consumer population remains owed.

Promote the existing delimiter verb syntax to validation/_tex.py and delete its
private duplicate. Active input traversal ignores commands within delimiter verb
and verb-star spans, including percent content. Comments remain inactive; a verb
spelling inside a comment must not reactivate text. Preserve the frozen comment
helper API and character/line offsets. Keep reader-visible literal text separate
from the input traversal mask. Preserve the conservative physical closure.

Read source as exact UTF-8 bytes decoded without newline translation. Fingerprints
represent the original bytes; unchanged LF/CRLF remain current, while byte drift,
invalid text and actual missing/cyclic active includes remain explicit gaps.
Collect .tex labels only from active logical text. Preserve physical .sty and
extensionless compatibility separately, without allowing inactive .tex labels to
rescue active references. Keep concrete reference failures visible. Incomplete
aggregate, gap, summary and partial legacy-population details are unmeasured;
emit each gap once rather than discarding independently measured diagnostics.

Qualified graph references must resolve their declared namespace through existing
exact or recognized module qualification. An absent qualified name must never
acquire a proved-result edge solely through a unique leaf fallback. Preserve the
existing policy for unqualified short names and edge uniqueness. This does not
accept or revise the historical scientific short-name resolver policy.

Python check identifiers resolve through actual CheckSpec.name registration, with
safe direct-import and facade-first order and explicit cache semantics. Exact
registered identifiers may establish infrastructure identity; membership never
proves a Lean theorem or scientific claim. Preserve explicit theorem/scientific
claim rules, ARISTOTLE exclusions, aliases/context, namespace distinctions and
waivers. Unknown identifiers of the same shape and scientific names remain subject
to their existing resolver. Do not copy a registry roster or exempt a whole table.

Source controls cover literal/star/percent/comment interactions, LF/CRLF hashes and
real byte drift, inactive/include/repeated labels and style compatibility, short,
supported qualified, wrong-namespace and ambiguous graph tokens, registry import
orders and negative scientific/unknown tokens, plus unmeasured detail semantics.
Write the controls now; executing them requires a separate ROOT interval.

Full real-input qualification still owes every directly affected consumer,
including disclosure and theorem embedded citations, all aliases/repetition/gaps
and physical/logical differences. The bounded graph seam uses frozen real canonical
data and does not certify extraction or the whole graph. Full/default/plugin and
canonical-scope qualification retains its real global-writer effects.
