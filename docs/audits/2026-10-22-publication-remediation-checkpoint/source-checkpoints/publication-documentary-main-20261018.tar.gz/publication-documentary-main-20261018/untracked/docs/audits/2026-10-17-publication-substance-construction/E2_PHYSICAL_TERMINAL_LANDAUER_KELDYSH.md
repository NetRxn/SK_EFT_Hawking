# Reviewed-source delivery: Finite-band AB-graph physical-terminal Landauer and Keldysh routes

This transports the COMPLETE original construction. Its original dated awaiting-review statements describe its author snapshot. Complete genuinely nonauthor manual review by publication_njl_target_review and lead intake761c56fb accept the declared model scope only. The [full original review](reviews/E2_PHYSICAL_TERMINAL_LANDAUER_KELDYSH.md) and [full original MODEL](source-models/E2_PHYSICAL_TERMINAL_LANDAUER_KELDYSH.md) are preserved. No runtime/native, physical-device, full gates, finding closure, integration/main or publication acceptance follows.

The established route agreement concerns the same specified NONINTERACTING finite-band AB-graph carrier, with its actual physical cut current, lead channels, covariance, bound-state/initial-memory conditions and finite-window errors. It does not identify the interacting bilayer nozzle, physical incoming Hawking state, screening/circuit receiver or calibrated detection band. Conserving interacting self-energy/vertex/noise, material/contact/gate/nozzle/horizon matching, two independently normalized physical routes and usable error-controlled band remain BUILD.

<!-- BEGIN EXACT ORIGINAL CONSTRUCTION -->

# Physical AB-contact scattering and independent lead-elimination current/noise construction

Status: new manual construction, awaiting genuinely nonauthor whole scientific verification. No model, numerical, symbolic, test, native or runtime execution. SOURCE_MODEL.md was saved at 2026-10-18T09:35:51.289451+00:00 before this author's new mathematics. Earlier lead planning is disclosed there; it is not accepted derivation. All statements below concern the explicitly selected noninteracting microscopic carrier. They do not derive a heated nozzle, Hawking preparation or calibrated device readout.

## 1. Same physical graph, contacts, state and observable

Let C be the predecessor's finite physical orthogonal pi-orbital AB honeycomb bilayer graph. Retain its actual bond embeddings, intralayer hopping -gamma_0, vertical B1–A2 hopping gamma_1, onsite energies, Peierls phases and q=-e. Work first with one spin. The final independent-spin multiplicity is g_s=2. Full lattice orbitals already include both valleys; no extra valley multiplier occurs. No area or effective channel number multiplies a terminal current.

There are m specified physical contact channels a. Channel a is a semi-infinite chain n=1,2,... with onsite epsilon_a and hopping -t_a, t_a>0. Its first site couples to an actual boundary orbital through column v_a in C (one nonzero entry for a single physical bond); the Hamiltonian block from that lead into C is v_a<1_a| and its Hermitian conjugate. Complex v_a contains the actual contact Peierls phase and hopping, not a fitted conductance. Independent channels may be grouped into one reservoir only when their incoming Fermi functions agree. The one-particle carrier is

    H_1 = C^d ⊕ (⊕_a l2(N)),
    h = [ h_C    V ; V†    h_L ],
    h_L,a = epsilon_a - t_a (right shift + left shift),
    V = sum_a v_a <1_a|.                                      (1)

All entries are finite and m,d finite; h is bounded selfadjoint. On annihilator columns the one-particle dynamics is c(t)=exp(-iht/hbar)c; its action on the infinite CAR algebra is the corresponding quasifree automorphism; one does not require a trace-class infinite-lead Gibbs density or finite total lead number. Every current considered below is a finite-rank bilinear, hence a bounded local CAR observable. A gauge-invariant quasifree covariance 0<=R<=1 specifies a positive state. A stationary state requires [R,h]=0; this is proved for the incoming construction, not assumed for an arbitrary quench.

For a chosen finite embedding block Q (C or the enlargement below), the partitioned preparation used in the finite-time proof is R_0=R_Q ⊕ (⊕_a f_a(h_tail,a)), with 0<=R_Q<=1 and

    f_a(E) = [1+exp(beta_a(E-mu_a))]^-1, beta_a>0.              (2)

This specifies noninteracting reservoirs maintained as incoming-state idealizations; inelastic reservoir thermalization and actual contacts are not derived. The zero-temperature limit is allowed separately. The uncoupled chains start immediately outside the chosen Q. Preparing thermal full chains before enlarging Q is a different finite-time quench: it induces Q-tail correlations and is not the product preparation just written. In the proved bound-free regime the stationary incoming limit is independent of finite Q preparation; no equality of the two finite-time quenches is asserted. For a preparation with initial Q-tail correlations, or a tail covariance other than f(h_tail), section 8 must retain their explicit covariance terms rather than use (23)/(24) unchanged.

For the physically oriented bond i->j set z_ij=h_ij c_i†c_j (including its Peierls phase). With a_ij=integral_i^j A.dl, h_ij=t_ij exp(-iq a_ij/hbar),

    I_i->j = (iq/hbar)(z_ij-z_ij†),
    q n_dot_i + sum_j I_i->j = 0,
    V_i->j = phi_i-phi_j-a_dot_ij,
    d<H_kin>/dt = sum_(unoriented bonds) <I_i->j> V_i->j.     (3)

The energy equality in (3) is a finite-volume identity; in an infinite lead it means the local/relative work balance with boundary energy flux retained, not a finite expectation of the extensive infinite kinetic energy. For a finite-support drive its explicit work term is a finite sum. The identity follows by differentiating the hopping and using the onsite-potential commutator; each bond appears once. Gauge c_i->exp(iq chi_i/hbar)c_i, a_ij->a_ij+chi_j-chi_i, phi_i->phi_i-chi_dot_i preserves it. Finite-support gauge changes suffice to prove local Ward identities. Infinite-region constant phase rotations are also well-defined one-particle unitaries/CAR automorphisms; no unbounded many-body lead charge is used as an observable in a Kubo formula.

Define I_a to be charge entering the AB region across the actual bond lead 1_a -> C. It is minus the outward current in (3). For a single contact to orbital i its one-particle vertex is

    j_a = (iq/hbar)[ v_a* |1_a><i| - v_a |i><1_a| ].          (4)

For a vector contact sum the corresponding bonds. Thus sum_a I_a=Q_dot_C, Q_C=q dGamma(P_C), a bounded finite-region charge. This sign means that electrons incident from a higher-mu left reservoir give negative signed charge current into C from the left. A voltage variable mu=q V gives positive differential electrical conductance. Reversing all port-current directions changes mean-current signs consistently, not auto-noise.

Include every first lead site in an enlarged finite block Q=C ⊕ span{|1_a>}. Embed only the tails n>=2. Each measured vertex (4), its second phase derivative, and Q_C then live in Q. This enlargement is an exact repartition of (1); it does not move the measured cut to the tail and does not discard first-site charge accumulation. Symbols G, W and A below may use Q instead of C; actual vertices always stay at (4).

## 2. Exact semi-infinite surface resolvent and thermal source

The open-end chain has generalized eigenfunctions sqrt(2/pi) sin(kn), 0<k<pi. Their orthogonality follows from the sine transform (odd extension of the Fourier series); completeness follows from that same unitary transform. Since E=epsilon-2t cos k and dE/dk=2t sin k,

    phi_E(n)=sin(kn)/sqrt(pi t sin k),
    <E|E'>=delta(E-E'),
    rho_s(E)=|phi_E(1)|^2=sin k/(pi t),                       (5)

inside B_a=(epsilon_a-2t_a,epsilon_a+2t_a), and zero outside. Plane-wave components of this delta-energy-normalized standing wave carry incoming flux 1/h, h=2 pi hbar. Multiplication by sqrt(h) makes unit particle flux but removes the chosen delta-energy normalization; we never mix these conventions.

Decimating the first site gives g(z)=[z-epsilon-t^2 g(z)]^-1. The solution selected by g(z)~1/z at infinity and Im g(z)<0 in the upper half-plane is

    g_a(z) = [(z-epsilon_a)-sqrt((z-epsilon_a)^2-4t_a^2)]/(2t_a^2),
    sqrt ~ z-epsilon_a at infinity,
    g_a(E+i0) = -exp(ik_a)/t_a within B_a.                   (6)

The branch is analytically continued through the upper half-plane, not chosen independently by a real square-root sign on both exterior components. Therefore -Im g_a/pi=rho_s, and

    Sigma_a^r = g_a v_a v_a†,
    Gamma_a = i(Sigma_a^r-Sigma_a^a)=2 sin(k_a)/t_a v_a v_a†,
    W_a = sqrt(2 sin(k_a)/t_a) v_a,
    Gamma = sum_(open a) W_a W_a†,
    Sigma_a^< = i f_a Gamma_a, Sigma_a^> = -i(1-f_a) Gamma_a. (7)

For Q, replace v_a by -t_a|1_a> and the uncoupled surface by the chain starting at site 2; h_Q contains the original v_a bonds. Formulae (5)–(7) are unchanged. Closed channels have Gamma_a=0 but retain real Sigma_a^r and evanescent fields; they are not dropped from G. Band edges require limits, not division by sin k=0.

The factors in (7) also follow directly from a thermal half-chain field y: <y_n† y_m>=integral_B dE phi_E(m) phi_E(n)* f_a(E). Multiplying by the actual V gives the lesser/greater source. No flat density of states, bosonic occupation, sheet conductivity or wide-band limit has entered.

## 3. Resolvent, on-shell scattering and exact spectral normalization

Block Gaussian elimination of z-h gives, for Im z>0,

    G^r(z)=P_Q(z-h)^-1 P_Q = [z-h_Q-Sigma^r(z)]^-1.          (8)

At a non-pole interior energy let u_a(E) be the Q part of the incoming scattering state. Solving the lead recurrence with the incoming sine wave in (5) and outgoing retarded correction gives

    u_a(E)=G^r(E) v_a phi_E(1)=G^r(E) W_a(E)/sqrt(2pi),
    S(E)=1-i W(E)†G^r(E)W(E).                               (9)

In (9) v denotes the tail coupling when Q is used. The scattering reference takes disconnected reflection as S=1. In an actual lead coordinate the wave is

    psi_{a,b,E}(n) = i/[2 sqrt(pi t_a sin k_a)]
                     [delta_ab exp(-ik_a n)-S_ab exp(+ik_a n)].

This fixes the otherwise immaterial reflected reference phase. Indeed g_n1^r=-exp(ik n)/t; inserting this recurrence and u in the outgoing coefficient gives precisely (9). Static shifts of the reference cut change phases, not probabilities; the finite-frequency local matrix elements below retain their actual positions.

At non-pole real energies the inverse identity gives

    G^r-G^a = -i G^r Gamma G^a = -i G^a Gamma G^r,
    S†S=SS†=1,
    A_a(E)=G^r Gamma_a G^a=2pi u_a(E)u_a(E)†.                (10)

For example, expanding S†S yields i W†(G^a-G^r)W+W†G^a Gamma G^r W=0. Hence T_ab=|S_ab|^2 for distinct single channels, or its grouped trace, lies in a unitary-channel transmission matrix. Caroli follows directly:

    T_ab=Tr[Gamma_a G^r Gamma_b G^a], a!=b.                 (11)

Its order is incoming b -> outgoing a. Every state/energy/changing open-channel population is explicit; (9) is not a fixed-size matrix across a threshold. The identities hold almost everywhere on open bands and extend as spectral measures, not as a claim of finite on-shell values at every exceptional point.

## 4. Bound states, completeness, and a nonvacuous physical AB regime

General finite-band contacts can have exterior, embedded or compact dark eigenstates, including threshold eigenstates. The finite-block resolvent (8) is a finite matrix of algebraic functions generated by the finitely many square roots (6). Away from finitely many branch points it is meromorphic on finitely many sheets; its nontrivial denominator cannot vanish identically because G~1/z. There are finitely many poles/exceptional energies. Stone's inversion applied to each finite-coordinate matrix element separates its absolutely continuous jump and its real-pole residues; there is no remaining singular continuous measure. A branch-point singularity may have an integrable density or an atom, and must be checked. Lead coordinates follow by the recurrence and the free resolvent, so these statements hold for every finite-coordinate vector; such vectors are dense. This proves spectral exhaustion here, rather than invoking a wave-operator name as a substitute for a surface calculation.

Let b_s be orthonormal bound eigenvectors, E_s their energies, and w_s=P_Q b_s. The residue of G at an isolated pole is w_s w_s† (sum over degeneracy); these are projected vectors, not independently normalized Q eigenvectors. Normalization includes the evanescent tail. Outside all lead bands a central eigenvector u has norm u†[1-Sigma'(E_s)]u after tail reconstruction, since d(z-h_L)^-1/dz=-(z-h_L)^-2. Thus energy-dependent embedding has no missing residue factor. The complete local identity is

    P_Q = integral dE/(2pi) sum_a A_a(E) + sum_s w_s w_s†.    (12)

Here and below the left P_Q denotes the identity on Q. Compact dark states are included even if their energies lie inside a propagating band. Scattering states span the AC part: their local density is exactly the jump in (10), and the sine transform supplies the incoming normalization. Smooth incoming packets supported in compact subbands have integrable contact amplitudes by integration by parts in E. Solving the time-dependent finite-rank coupling for these packets gives the incoming wave map, with (9) as its stationary solution. Its range exhausts the AC density just computed. Density of those packets then extends the map isometrically to the AC channel spaces; no additional AC state is left by (12).

A concrete countercontrol also exists within the AB carrier: take the four-orbital path below but identical narrow lead bands [-2t,2t] with gamma_1>2t. A normalized vector on the vertical dimer with positive dimer eigenvalue has full-h Rayleigh quotient gamma_1, since its other orbital and lead amplitudes vanish. Therefore spec(h) intersects (2t,infinity). Outside the lead bands the Schur resolvent is meromorphic, so that spectral weight contains an actual bound eigenstate. Nonzero contact couplings do not change that Rayleigh quotient. Thus finite contacts alone cannot justify erasing bound preparation or asserting a unique NESS.

An explicit genuinely AB, conducting, bound-free example is the four physical orbitals A1–B1–A2–B2 with two intralayer bonds of magnitude gamma_0>0 and the vertical bond gamma_1>0. This is the finite open AB unit graph, not a continuum channel-count surrogate. Couple A1 and B2 to two actual chains, both with epsilon=0, hopping t and endpoint coupling magnitude t. Choose

    t > gamma_0+gamma_1 >= ||h_C||,

with zero central onsite energies; signs/phases on this path are removable static gauges. For real E>=2t, 0<g(E)<=1/t and V V†=t^2(P_A1+P_B2). Thus

    E-h_C-g(E)VV† >= (2t-||h_C||-t) 1 >0.

For E<=-2t the same argument applied with signs gives a strictly negative definite inverse denominator. At both edges the inequalities remain strict. In the band, a real eigenstate must have zero propagating lead tails (an oscillatory or edge affine solution is not l2). Its endpoint amplitudes vanish; the nonzero path hoppings force the next amplitude, and then all four amplitudes, to vanish. Equivalently a null vector of E-h_C-Sigma^r has zero Gamma quadratic form, hence zero endpoints, and the recurrence eliminates it. No exterior, embedded, edge or compact eigenstate exists.

Moreover G_B2,A1 has cofactor equal, up to sign/phase, to the nonzero product of the three path hoppings divided by det(E-h_C-Sigma). Consequently T_RL(E)>0 at every interior energy. This is a nonempty finite-band transmission regime of the actual AB carrier for arbitrary positive gamma_0,gamma_1 satisfying the displayed lead choice; it invents no calibrated material values. It is not a proof for every larger flake/contact pattern.

For this example every finite-coordinate density vanishes as a square root at band edges because there is no edge pole. The finite-coordinate propagators decay O(|t_time|^-3/2): set E=-2t cos k in the spectral integral; the endpoint amplitude is proportional to k^2, and the quadratic stationary phase rescales k by |t_time|^-1/2; away from endpoints integrate by parts. This also follows with the opposite edge pi-k. In particular U_QQ(t_time) is L1 in time. This fact justifies the long-time source limit used in section 8 by dominated convergence, not a formal deletion of an initial term.

For general contacts retain (12). A stationary quasifree state has incoming AC covariance plus a positive contraction R_b commuting with h on the bound sector; choose a joint eigenbasis within each degenerate bound energy. Its occupations are extra preparation data, not fixed by f_a. A partitioned quench can retain bound coherences exp[-i(E_s-E_t)t/hbar](R_0)_{st}; then the state is not stationary and a one-frequency stationary PSD is not its full description. Local AC-bound transients decay under the integrable spectral conditions just discussed; they are not assumed absent at finite time.

## 5. Exact cut-current matrix, storage and the DC reduction

For incoming labels b,c define the actual two-energy matrix

    M^a_bc(E,E')=u_b(E)† j_a u_c(E'),
    B^a_bc(E,E')=(h/q) M^a_bc(E,E')
      =(hbar/q) W_b(E)† G^a(E) j_a G^r(E') W_c(E').          (13)

Hermiticity gives B^a_cb(E',E)=B^a_bc(E,E')*. This is defined from the actual internal-Q cut, not by multiplying scattering matrices at two unrelated energies. Closed-channel evanescent fields are already in u; only incoming open-channel labels are summed. Matrix elements involving a bound state use its normalized w_s instead of u.

At equal energy, the lead recurrence/constant flux gives

    B^a(E,E)=P_a-S†(E) P_a S(E).                             (14)

To verify this, evaluate the cut current in an arbitrary incoming superposition. Equal-energy continuity makes its flux independent of the number of lead sites between the cut and the reference section; the plane-wave amplitudes in (9) give q/h times incoming minus outgoing probability. Polarization in the incoming superposition gives the entire matrix (14), not only its diagonal. A bound stationary state has zero mean current through a single separating lead cut: its tail has finite norm, and its tail number commutator has expectation zero. Degenerate bound coherences satisfying stationarity give the same result by polarization.

Using incoming CAR {a_b(E),a_c†(E')}=delta_bc delta(E-E') and <a_b†a_c>=delta_bc delta(E-E') f_b(E),

    I_a(t)= (q/h) sum_bc integral dE dE' exp[i(E-E')t/hbar]
                   a_b†(E) B^a_bc(E,E') a_c(E')             (15)

on the AC sector (plus the bound/cross terms where present). Therefore

    <I_a> = (g_s q/h) integral dE [m_a(E) f_a(E)
                                  -sum_b T_ab(E) f_b(E)]
           = (g_s q/h) integral dE sum_b T_ab(E)[f_a-f_b].   (16)

The second equality uses row unitarity; m_a is the actual open-channel count in a reservoir group. In two terminals T_LR and T_RL have equal total trace by unitary block identities, so I_L=(g_s q/h) integral T(E)(f_L-f_R), I_R=-I_L. This is total terminal current, not sheet current. The equilibrium DC conductance is G=(g_s q^2/h) integral T(E)(-f'(E)). Energy current has E/q in place of the charge factor in (16); stationary sum is zero. Reservoir heat leaving a is J_a^E-mu_a I_a/q. Maintained electrochemical sources supply sum_a mu_a I_a/q; there is no assertion of inelastic heating inside the elastic central region. Local explicit electric work remains (3).

At different energies, (4) and the eigen-equations instead give the exact storage identity

    sum_a M^a_bc(E,E')= i q(E-E')/hbar u_b(E)† P_C u_c(E').   (17)

Thus at E'=E+hbar omega the terminal sum measures -i omega times the finite AB charge matrix. Between the original contact and a tail reference cut there is also the corresponding first-site storage term. Neither two-energy unitarity nor I_L(omega)+I_R(omega)=0 follows from (14). Lattice velocities and counterpropagating cross terms at different energies must remain in (13). This directly addresses the finite-band limit of a far-terminal textbook formula.


## 6. Scattering derivation of the full ordered current noise

Let delta I=I-<I>. Define, without an extra Fourier factor,

    S^>_ab(omega)=integral_R dt exp(i omega t)<delta I_a(t) delta I_b(0)>,
    S^<_ab(omega)=integral_R dt exp(i omega t)<delta I_b(0) delta I_a(t)>,
    S^sym=(S^>+S^<)/2.                                      (18)

These are spectral measures when there are bound-state lines. Stationary AC states in the bound-free regime give ordinary densities in the usual distributional sense. Expanding (15), CAR and independence of the incoming reservoirs give the connected contraction

    <a_b†(E) a_c(E') a_d†(F) a_e(F')>_connected
      =delta_be delta_cd delta(E-F') delta(E'-F)
                       f_b(E)[1-f_c(E')].

The disconnected contraction is exactly the product of the two means and has been subtracted. The plus sign is fixed by the CAR anticommutator minus the occupied contraction; it is not Bose bunching. Fourier integration yields h delta(E'-E-hbar omega), hence

    S^>_ab(omega)=(g_s q^2/h) sum_cd integral dE
       f_c(E)[1-f_d(E+hbar omega)]
       B^a_cd(E,E+hbar omega) B^b_dc(E+hbar omega,E).         (19)

This is the full finite-frequency covariance of the actual contact current for the selected stationary AC model. It includes all incoming-reservoir pairs, reflections, contact phases and cross-energy vertices. It is not a statement of screened external-circuit noise. For fixed omega the matrix S^> is Hermitian positive semidefinite: contraction with port coefficients is a sum of absolute squares with nonnegative Fermi weights. S^<_ab(omega)=S^>_ba(-omega), so S^sym is also a Hermitian PSD matrix. Cross spectra may be complex; an entry need not be nonnegative. Equation (17) gives exactly sum_a S^>_ab=-i omega S^>_Q_C,b and sum_ab S^>_ab=omega^2 S^>_Q_C,Q_C. No AC conservation violation is hidden by forcing terminal sums to zero.

For a stationary bound sector choose simultaneous eigenvectors of h and R_b, occupations n_s in [0,1]. Combine continuous incoming labels and discrete bound labels x into a measure dnu_x (dE for an incoming channel, counting measure for a bound state), normalized full states psi_x, energies E_x and occupations n_x. The complete formula is

    S^>_ab(omega)=2pi g_s sum_(types x,y) integral dnu_x dnu_y
       n_x(1-n_y) <psi_x,j_a psi_y><psi_y,j_b psi_x>
       delta(omega-(E_y-E_x)/hbar).                           (20)

Continuous-continuous terms reduce exactly to (19). Bound-bound lines and bound-continuum thresholds are retained, even though a stationary bound state carries no DC current through an isolated terminal cut. If R_b does not commute with h, use the finite-time covariance in section 8; (20) is not a stationary representation of such coherences. A bound-free theorem is therefore substantive, not a harmless normalization choice.

## 7. DC thermal/partition controls, units and frequency conventions

At omega=0, (14) and unitary block algebra give the two-terminal auto-noise, with transmission eigenvalues tau_n(E) in [0,1],

    S_LL(0)=(g_s q^2/h) integral dE sum_n {
       tau_n[f_L(1-f_L)+f_R(1-f_R)]
       +tau_n(1-tau_n)(f_L-f_R)^2 }.                          (21)

For completeness, expand Tr over incoming L/R blocks of B_L=P_L-S†P_LS. The LL and RR square terms contain tau_n^2 and the LR/RL terms contain tau_n(1-tau_n). Combining the Fermi factors changes the first two terms into the two tau_n thermal terms plus the displayed partition square. This proves (21) from the same finite-band cut, without assuming constant transmissions. At zero frequency S^>=S^<=S^sym for an auto-spectrum.

In equilibrium f_L=f_R=f, f(1-f)=k_B T(-f'), so S_LL(0)=2 k_B T G exactly, with G from (16). At T=0 under bias, (21) becomes (g_s q^2/h) integral_(between mu_L,mu_R) dE sum_n tau_n(1-tau_n). A perfectly transmitted channel has no partition noise but still has equilibrium thermal/finite-frequency quantum noise. Reflection at one energy alone does not remove all local finite-frequency noise. The genuine disconnected-contact control v_a=0 makes j_a=0 and all its mean and cross spectra exactly zero; arbitrary central bound memory then does not resurrect that absent cut.

A transparent physical-graph control is the four-orbital AB path with gamma_1=gamma_0=t and matched end lead hoppings/couplings t. The entire graph is a uniform infinite chain after a static sign gauge, so solving its plane-wave recurrence gives S transmission of unit modulus and zero reflection in the band. This is an explicitly tuned model control, not a claim that measured bilayer parameters are equal. The bound-free example of section 4 instead allows unequal positive gamma_0,gamma_1 and has strictly positive transmission in a full open band. For a closed-channel control choose both lead bands to exclude E=0. There is no incoming zero-energy channel and no zero-energy DC transmission; a bound transition at a different frequency is not ruled out. An isolated band edge is not assigned an artificial current by dividing by zero velocity; limiting transmissions may be finite and the threshold/DC limit requires its own stated order.

The vertex j has units A, u has units J^-1/2, M has units A/J, and B in (13) is dimensionless. The prefactor q^2/h times dE in (19) has units C^2/s=A^2 s, the spectral density per angular-frequency convention with variance integral d omega/(2pi) S. For f_Hz, S_Hz(f_Hz)=S_angular(2pi f_Hz), since d omega/(2pi)=d f_Hz. No additional 2pi multiplies the value. A one-sided auto-spectrum for a real detector quadrature is 2 S^sym_angular(2pi f_Hz) for positive f_Hz, with DC treated by its measure; fold once. Its equilibrium low-frequency Johnson value is 4k_B T G. Positive omega in S^> means the conductor can absorb hbar omega in this convention; at equilibrium T=0 the negative-frequency/emission branch vanishes. A photon-emission observable is not obtained by relabeling the positive S^> branch.

Physical spin contributes g_s=2 once; contacts/chains are already actual channels. Neither homogeneous sheet area normalization nor the continuum valley factor four is introduced. Equations (19)–(21) are fermion noise, not a Planck-law Hawking excess. The historical Phase5w research report's BEC/sheet/terminal and emission-normalization transfers do not supply these missing physical identifications.

## 8. Independent Heisenberg/contour lead elimination, including the initial term

This route starts from the equations of motion of (1), not from S or (19). Let x be the Q annihilator column, y the decoupled-tail column and T the Q-to-tail hopping block (so the full one-particle block is [h_Q,T;T†,h_tail]). Direct integration gives

    y(t)=exp[-ih_tail(t-t_0)/hbar] y(t_0)
      -(i/hbar) integral_t0^t ds exp[-ih_tail(t-s)/hbar] T† x(s),
    i hbar x_dot(t)=h_Q x(t)+xi(t)
      -(i/hbar) integral_t0^t ds T exp[-ih_tail(t-s)/hbar] T† x(s),
    xi(t)=T exp[-ih_tail(t-t_0)/hbar] y(t_0).                 (22)

The memory kernel and the two ordered source covariances are fixed by the actual half-chain spectrum. Define G^r(t,t')=-i theta(t-t') times the Q propagator of the full h, G^<(t,t')=i<x†(t') x(t)> and G^>(t,t')=-i<x(t)x†(t')>. Time transforms use integral dt/hbar exp(iEt/hbar) and inverse integral dE/(2pi); thus G^r(E) has units J^-1 and equals (8). With convolution * meaning integral ds/hbar, the kernel Sigma^r(t,t')=-i theta(t-t') T exp[-ih_tail(t-t')/hbar]T† has energy-square units in time and transforms to the energy self-energy (7). Sigma^<(t,t')=i T exp[-ih_tail(t-t')/hbar] f(h_tail)T†; Sigma^> uses -i(1-f). Fourier transformation by (5) gives exactly (7), independently of scattering.

The exact finite-t_0 solution is

    x(t)=U_QQ(t-t_0)x(t_0)+integral_t0^t ds/hbar G^r(t,s)xi(s),
    G^<(t,t')= i U_QQ(t-t_0) R_Q U_QQ(t'-t_0)†
                        + (G^r * Sigma^< * G^a)(t,t').     (23)

The time integrals in the second line run on [t_0,infinity), with causal support. This follows by multiplying the solution and using the partitioned initial state. More generally put L(t)=P_Q U(t-t_0)P_tail, the source-propagation block. The exact covariance for an arbitrary initial block state is U_QQ R_Q U_QQ† + L R_tail L† + U_QQ R_Q,tail L† + L R_tail,Q U_QQ†, with the left factors at t and right factors at t' and an overall i for G^<. This states the missing cross terms explicitly; a nonthermal R_tail changes the source covariance too. Equation (23) is also the Langreth lesser component of the contour Dyson equation: if G=-i<T_C x x†>, Gaussian integration of y gives G=G_0+G_0*Sigma*G; separating contour order on the two branches yields (BC)^<=B^r*C^<+B^<*C^a and (BC)^r=B^r*C^r. Iteration retains the initial contribution (1+G^r*Sigma^r)*G_0^<*(1+Sigma^a*G^a). Formula (23) is its finite-time physical form. It has not been removed by a formal inverse applied to a free on-shell delta function.

For the bound-free AB regime in section 4, U_QQ tends to zero and is L1. At fixed t-t', let t_0->-infinity. The first term of (23) vanishes. In the second term the amplitude for a source eigenmode E is the integral of -i U_QQ(s) exp(iEs/hbar)/hbar for 0<=s<=t-t_0, times its actual contact coupling. L1 convergence makes this amplitude converge uniformly to G^r(E) times the coupling. The half-chain spectral weight (5) has finite integral; bounded convergence then passes the product through its f(E) weighted integral. Thus, with this actual no-bound/no-edge-pole hypothesis,

    G^<(E)=i sum_a f_a(E) G^r(E)Gamma_a(E)G^a(E),
    G^>(E)=-i sum_a [1-f_a(E)] G^r(E)Gamma_a(E)G^a(E).       (24)

No scattering formula was used to obtain (22)–(24). In a general contact model the non-decaying part of the homogeneous solution and the retained quench memory contribute the bound-sector terms of (12)/(20); stationary (24) alone is not a universal solution. The exact finite-time U R_0 U† always remains available. A claim of unique NESS without these hypotheses is false.

The same derivation handles bounded time-dependent h_Q(t) or contact phases by two-time kernels; stationary energy products are then convolutions, not a static transmission law. No finite-AC wide-band limit was invoked. For linear AC about a stationary state the bounded-cut response is stated in section 10; the actual screened circuit is a further model.

## 9. Independent contour current/noise, then explicit same-carrier agreement

The measured contact source is internal to Q: replace its Peierls flux by Phi_a on the forward/backward contour. Its first insertion is the actual j_a=-partial_Phi_a h_Q and its second insertion is the physical contact Hessian. Lead Gaussian integration leaves the same nonlocal Sigma in the central quadratic contour action. The two connected first-insertion derivatives of its logarithmic generating functional pair central Grassmann propagators into one closed loop; separating greater/lesser branches yields

    <I_a>=-i g_s Tr[j_a G^<(t,t)],
    C_ab(t,t')=g_s Tr[j_a G^>(t,t') j_b G^<(t',t)].          (25)

One can check the loop sign directly: G^>=-i<x x†>, G^<=i<x† x>; their product has positive sign, and the unpaired mean product is removed by log/connected differentiation. There is no extra minus or factor two. The same result follows by differentiating the Gaussian inverse kernel twice and carrying the contour branch signs. The local Hessian belongs in the response/contact term, not in the connected measurement covariance of the undifferentiated current operators. At finite t_0, (23) must be inserted into (25); it automatically retains the initial sector and nonstationary covariance.

For the stationary source limit (24), the independent frequency-domain contour result is

    S^>_ab(omega)=g_s hbar/(2pi) integral dE
       Tr[j_a G^>(E+hbar omega) j_b G^<(E)],                 (26)

because the two inverse energy transforms contribute (2pi)^-2 and the time integral contributes h delta(E'-E-hbar omega). The signs -i and +i multiply to +1. Equation (26) is a central two-time bubble with the actual finite-support cut vertices. It is not source17's closed-lattice Kubo answer, and not a guess using an optical conductivity.

Now compare the two constructions rather than name them equivalent. Equations (9)/(10) and the independently derived (24) give the explicit pointwise identity

    -i G^<(E)=2pi sum_c f_c(E) u_c(E)u_c(E)†,
     i G^>(E)=2pi sum_d [1-f_d(E)] u_d(E)u_d(E)†.            (27)

Insert (27) in the first line of (25): it becomes the incoming diagonal expectation of (15), hence (16). Insert (27) in (26): the trace becomes (2pi)^2 sum_cd f_c(1-f_d) M^a_cd M^b_dc. Its prefactor is h; substituting M=(q/h)B gives q^2/h and exactly (19), including cross terms and all finite-frequency phases. If bound states are retained, add their normalized spectral weights and stationary occupations to both sides, obtaining (20). With nonstationary initial coherences, use the same U R_0 U† in both full-state expansions, giving (25) before a stationary Fourier transform. This is a constructive bijection between the source/central and incoming-state partial spectral operators, not a declaration that Keldysh and scattering must agree.

For the usual NEGF DC form it is also possible to keep the first sites in the lead partition instead of Q. Differentiating the finite-volume lead number and then retaining its finite bond commutator gives the exact incoming charge expression

    <I_a>=(g_s q/hbar) integral dE/(2pi)
                Tr[Sigma_a^<(E) G^>(E)-Sigma_a^>(E) G^<(E)].(28)

Insert (7) and (24). The products i*(-i) are +1; the difference of Fermi weights is f_a-f_b, and the trace is Tr[Gamma_a G^r Gamma_b G^a]. This gives (16) with no factor-of-two ambiguity. Equation (28) is a DC/steady contact identity, not a license to use a scalar lesser self-energy as a finite-frequency cut vertex. Moving the first-site partition back or forth is exact provided its charge accumulation is retained for AC.


## 10. Equilibrium KMS, physical cut response and contact Ward identities

If all reservoirs have common beta,mu and there are no bound states, the complete spectral identity (12) identifies the stationary covariance with f(h), not merely an assumed effective temperature for one outgoing channel. With bound states this is true only when their occupations are also f(E_s). Number-conserving current insertions do not change total fermion number, so the chemical-potential factor cancels in their detailed balance. At E'=E+hbar omega,

    f(E')[1-f(E)] = exp(-beta hbar omega) f(E)[1-f(E')].

Change integration labels in (19)/(20) to obtain the matrix relations

    S^<(omega)=exp(-beta hbar omega) S^>(omega),
    S^sym(omega)=1/2 coth(beta hbar omega/2)
                                      [S^>(omega)-S^<(omega)]. (29)

The formula is interpreted by its continuous or measure limit at zero frequency, including possible bound lines. At T=0 it describes absorption versus emission, not a bosonic thermal population substituted for the incoming Fermi state.

A precise admittance port can be defined without treating infinite lead number as a bounded observable. Apply a physical Peierls flux Phi_a(t) on the measured bond(s), oriented so j_a=-partial h/partial Phi_a. The conjugate electromotive voltage is V_a=-Phi_dot_a; the local work is sum I_a V_a. All perturbing hopping changes and current derivatives are finite-rank. Expand the exact local CAR evolution to first order (Duhamel on the bounded local perturbation). In a stationary state this gives the retarded susceptibility and the equal-time contact term

    chi_ab(z)=(i/hbar) integral_0^infinity dt exp(izt)
                                      <[I_a(t),I_b(0)]>,
    T_ab=<partial^2 H/partial Phi_a partial Phi_b>,
    delta<I_a>(z)=sum_b [chi_ab(z)-T_ab] Phi_b(z),
    Y(z)=[chi(z)-T]/(i z), Im z>0.                          (30)

Currents, chi and T include g_s once. The source has linear Hamiltonian -I Phi, hence the positive i/hbar response sign. The measured current itself changes by -T Phi, which fixes the contact sign. Finite-volume derivation converges for fixed Im z>0 to this local expression; no extensive charge or extensive Gibbs trace is needed. A different distribution of the same electric drive among bond phases and scalar potentials must be related by the gauge transformation in (3); omitting the induced scalar/source terms is not that same experiment.

At real nonzero omega let Y_H=(Y+Y†)/2. Hermiticity and stationarity in (30), by splitting its time integral into positive and negative times, give

    Im_H chi = [chi-chi†]/(2i)=[S^>-S^<]/(2hbar),
    Y_H=[S^>-S^<]/(2hbar omega),
    S^sym=hbar omega coth(beta hbar omega/2) Y_H             (31)

in equilibrium. T is a Hermitian real-Hessian expectation and drops out of the dissipative part, but not out of the full complex admittance. Matrix anti-Hermitian/imaginary-part operations must not be replaced by entrywise real parts at magnetic field or for cross responses. With isolated bound transitions (31) is a distributional dissipation relation; an ordinary value may require finite resolution. Nonequilibrium (30) still makes sense under the stated stationary state/retarded convergence, but its noise cannot be assigned the equilibrium coth factor.

This admittance is the response of the selected microscopic bare bond-current ports. It is not automatically the total external current including screened displacement and gate currents. At low frequency its dissipative two-terminal auto response agrees with (16): from (19), (29) and (31),

    Y_H,aa(0)= (g_s q^2/(2h)) integral dE (-f')
                                      Tr[B^a(E,E)^2].

The elementary projection identity Tr[(P_a-S†P_a S)^2]=2(m_a-Tr[S_aa†S_aa]) reduces it to the Landauer G_aa. This limiting formula requires its integral/limit to exist (e.g. finite positive temperature in the smooth bound-free regime); do not assert a derivative through a threshold at T=0 without specifying that limit. Cross dissipative entries are the Hermitian part of the DC conductance matrix. This provides an actual FDT/conductance check, not a separately imposed Johnson prefactor.

For any finite site set B, q P_B is a bounded one-particle gauge generator and its second quantization is a bounded local charge. Its commutator gives exactly the sum of oriented cut vertices. Differentiating the local continuity identity under the source, including the contact Hessian and scalar-potential response, gives the contact Ward identity: the sum of responses equals -i omega times the stored-charge response, with the corresponding equal-time/source derivatives retained. The same identity holds for the noise by (17). For a whole lead, use finite-segment charges first; the outer-cut term is present at every finite length. A limiting incoming/DC flux may remove that term only under its actual limit, not at arbitrary AC frequency. Static phase reassignments on a whole half-chain can alternatively be implemented by the bounded one-particle unitary exp(i theta P_lead), inducing a CAR automorphism without positing a finite many-body lead-charge operator. This establishes gauge covariance of the local cut experiment; it does not solve Poisson screening or add missing displacement current.

## 11. Finite-resolution and model-error bounds on stated domains

These bounds concern the actual selected operator/state, not calibrated error bars for a device. They also specify a finite operational observable when (20) has spectral lines. Put J_a=||j_a||_2 (Hilbert–Schmidt), L_a=||j_a||_1, with finite rank on Q. For any gauge-invariant quasifree 0<=R<=1 commuting with h, Wick's finite-rank trace gives

    |<I_a>|<=g_s L_a,
    |C_ab(t)|<=g_s J_a J_b.                                 (32)

For a real integrable probe w(t), X_a=integral dt w(t) delta I_a(t) exists as a bounded observable. Its covariance is integral dt ds w_a(t)w_b(s) C_ab(t-s), or integral d omega/(2pi) w_hat_a(-omega) w_hat_b(omega) S_ab(omega) using w_hat(omega)=integral exp(i omega t)w(t)dt. The variance is nonnegative by its operator definition and equals the positive spectral quadratic form. There is no pointwise-PSD estimator asserted for a finite observation. Replacing w_a,w_b by v_a,v_b incurs the simple absolute bound

    g_s J_a J_b [||w_a-v_a||_1 ||w_b||_1
                              +||v_a||_1 ||w_b-v_b||_1].    (33)

Thus omitted time/window tails have an explicit L1 bound. Frequency-band omission has the actual nonnegative spectral-tail integral for an auto probe, not an invented epsilon independent of the state. Since h is bounded, transition frequencies lie in (spec(h)-spec(h))/hbar, a finite interval, including bound-state lines. A selected smaller usable band is not proved nonempty by this mathematical compact support.

Suppose two identified carriers on the same Hilbert space have ||h-h_tilde||<=epsilon_h, ||R-R_tilde||<=epsilon_R and finite-rank currents with delta J_a=||j_a-j_tilde_a||_2. Both covariances are stationary for their own h. Duhamel gives ||U(t)-U_tilde(t)||<=|t| epsilon_h/hbar. Telescoping the finite-rank Wick trace, keeping both R and 1-R, yields

    |C_ab(t)-C_tilde_ab(t)| <= g_s [
       delta J_a J_b + J_tilde_a delta J_b
       + J_tilde_a J_tilde_b (2 epsilon_R+2|t|epsilon_h/hbar)].(34)

The bilinear trace form is C_ab(t)=g_s Tr[j_a U(t)(1-R) j_b R U(t)†]; either rearrangement by cyclicity gives the same bound. The first two terms use the original J_b and the intermediate tilde J_a consistently. Integrating (34) against |w_a(t)w_b(s)| with t replaced by t-s gives a finite filtered-error bound when the corresponding first difference-time moment is finite. For the mean use g_s[||j_a-j_tilde_a||_1+L_tilde_a epsilon_R]. No claim that small Hamiltonian error automatically yields small stationary-state error at a bound-state/threshold transition is made.

For the chain/contact parameter perturbations in (1), a concrete operator bound is

    epsilon_h <= ||delta h_C|| + max_a(|delta epsilon_a|+2|delta t_a|)
                                      +||delta V||,          (35)

by a block-diagonal plus off-diagonal decomposition; ||[0,delta V;delta V†,0]||=||delta V||. The same formula applies to Q repartitioning. A bond perturbation gives delta j directly from (4), so current errors are not hidden in epsilon_h alone. At positive temperatures and energies in a stated compact interval,

    |delta f| <= beta_max |delta mu|/4
                    +max|E-mu| |delta beta|/4

along the straight parameter interpolation with the displayed extrema. This controls only the incoming Fermi functions; changed contact spectral operators must also be bounded. At T=0 no uniform small-mu bound of this kind exists.

For z=E+i eta, eta>0, the full selfadjoint resolvent identity gives

    ||(z-h)^-1-(z-h_tilde)^-1|| <= epsilon_h/eta^2.           (36)

A compressed central resolvent obeys the same bound. At a real compact subband where Gamma>=gamma 1 on the relevant embedding and no pole exists, the dissipative inverse estimate gives ||G||<=2/gamma. More generally directly certify a positive minimum singular value of E-h_Q-Sigma(E) on the specified compact set. Bounds on delta Sigma, W and their derivatives obtained from (6) then propagate through (8)/(13) and the integral (19) by ordinary product estimates; thresholds must be omitted with their actual residual spectral weight or treated by their explicit square-root asymptotics. The rank-two AB example need not satisfy Gamma>=gamma 1, but its nonsingular continuous denominator on the closed band supplies the second option. An eta>0 estimate alone gives no uniform eta->0, pointwise band-edge, resonance-crossing or unresolved bound-occupation estimate.

For a finite-lead approximation and a fixed probe time horizon T, retain the actual initial infinite-state compression rather than silently replace it by a finite-volume Gibbs state. Cut each tail only at graph distance at least d from the support of the measured currents/Q. Extend the cut Hamiltonian by its decoupled outer tails so both act on the same Hilbert space and have norm <=H_*. For n<d the rows P_Q h^n are identical: an n-step path cannot reach the changed bond. Taylor expansion therefore gives

    ||P_Q[U(t)-U_L(t)]|| <= 2 sum_(n>=d) (H_*|t|/hbar)^n/n!
                         <=2 exp(x) x^d/d!, x=H_*T/hbar.    (37)

Let epsilon_U be the displayed row bound on the union of the finite current supports over |t|<=T. Compressing the same R_0, the local two-time occupied and empty propagator errors are at most 2 epsilon_U, since each of their two propagators contributes epsilon_U. Thus the mean error is at most 2g_s L_a epsilon_U and the connected two-time covariance error at most 4g_s J_a J_b epsilon_U. These absolute bounds can exceed the trivial observable bound but are valid; a different finite initial preparation adds its own epsilon_R term. This is a genuine path-distance truncation error before reflections return, not a finite-lead NESS theorem. Take L->infinity at fixed finite probe before an unlimited-time limit. Formula (37) can be weak numerically but is a proved finite bound, not an unexecuted empirical convergence result.

If an orthogonal Wannier/projection approximation is introduced, keep its complement as a block, bound its coupling K and its prepared-state/current mismatch. Comparing h with its block diagonal version has epsilon_h=||K||, so (34) controls finite-time errors with those explicit preparation/current bounds. A low-energy downfolding may offer a sharper energy-restricted bound, but it must retain normalization and physical cut-current projection; replacing the full carrier by the predecessor's two-band optical response is not a terminal-noise error estimate. No numerical Wannier residual or calibrated contact uncertainty has been supplied here.

## 12. What is constructed and what remains the original task

The new construction gives an actual finite physical AB graph with semi-infinite finite-band contacts, exact chain normalization and causal embedding, a nonvacuous conducting bound-free AB regime, explicit bound/initial-memory alternatives, actual local two-energy cut-current kernels, a scattering mean/noise route and an independently eliminated contour/Heisenberg route, and their constructive same-carrier equality. It gives finite-resolution bounds, equilibrium cut-port FDT with the contact term, and the correct storage/ordering/spin/unit conventions. It proves no universal wide-band approximation and does not identify the actual terminal PSD with a homogeneous optical sheet kernel.

The next physical constructions remain substantive: choose and constrain the actual device contact Hamiltonian and Wannier/interaction error; construct the interacting gated bilayer collision/imbalance/electrothermal background and physical heated-nozzle stationary solution; derive its mode conversion and actual incoming (possibly correlated/anomalous) state; couple the physical screened charge/gate/displacement currents to the receiver; derive absolute calibration and uncertainties, usable nonempty identifiable frequency band and sensitivity; establish the full target's two-route agreement rather than only this noninteracting carrier. Source propagation, genuine numerical checks, native integration, full gates, finding closure, bundle review and main delivery require separate authority/evidence. Existing full-suite/main failures and native/cross-layer obligations are untouched.

## Source reading and provenance limits

Carrying predecessor: full E2 microscopic17 source/model/construction/independent review at hashes in the packet and full accepted18 Onsager context at its exact previously read hashes. This note does not reaccept its own ancestors or count a source copy as new physics. The original source17 planning and stale pending-flag correction remain historical evidence.

Personally read official primary parsed passages: [Blanter–Buttiker v2](https://arxiv.org/pdf/cond-mat/9910158v2), the exact-velocity versus reduced-current discussion, noise conventions/footnote4 and AC caution; [Jauho–Wingreen–Meir v1](https://arxiv.org/pdf/cond-mat/9404027v1), contour/lead equations, time-dependent current, retarded/lesser embedding and Appendix A/B. Their differing current/Fourier conventions are not silently transplanted. The v1 identifier is April1994 even though its generated title page prints August2013. These were carrying-section reads, not claims to read all99/42 pages or inspect PDF pixels. The proofs here explicitly derive their own lattice vertices and limits. No primary fulltext was saved or admitted. The local164-line Phase5w research report was read as historical secondary context, not accepted physical proof.

CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

No contradiction requires weakening the original task. Two temptations are specifically excluded by the carrying primary passages and the direct construction: the constant-velocity far-lead two-energy vertex is an approximation, and the lesser Dyson equation's initial contribution is not erased for arbitrary finite-band contacts. The historical local report's universal Hawking/sheet/terminal and two-independent-route assertions do not supply those proofs. The exact construction retains physical-terminal/source/noise BUILD beyond its noninteracting model scope.

<!-- END EXACT ORIGINAL CONSTRUCTION -->

Documentary transport only; all original mathematical/source-domain content above is byte-exact.
