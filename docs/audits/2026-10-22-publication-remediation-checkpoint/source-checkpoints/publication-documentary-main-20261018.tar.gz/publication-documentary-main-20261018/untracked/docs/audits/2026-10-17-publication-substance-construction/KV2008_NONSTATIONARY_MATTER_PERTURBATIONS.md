# KV2008 nonstationary dust/radiation, scalar and metric transfer

Author: publication_g4_traceability. Independently accepted MANUAL mathematical construction within the declared source model; physical, numerical and native acceptance remain open. [source/model contract](source-models/KV2008_NONSTATIONARY_MATTER_PERTURBATIONS.md) was saved before the new derivation. This advances the actual selected2008 matter-perturbation obligation. No software evolution, numerical error receipt, physical parameter selection, native result, empirical fit or closure is claimed.

## 1. Fixed model, variables and units

The source-selected fixed-mu action and background are exactly the accepted ancestor constructions e75de997 and8c30bea0. The carrying primary is [KV2008, version7](https://arxiv.org/html/0806.2805v7), particularly the effective-action discussion in §II, curvature convention in §III, and conserved-fluid equations/ansatz in §IV. New perturbation equations below are derived here, not asserted to be printed in that paper. Their ideal-fluid closure is additional explicit input.

Use signature(-+++), R_std=+6(dotH+2H²)=-R_KV, c=hbar=1. Set M²=sF0/(8pi)>0, f>0, U=V/chi, V=-f²/2+f⁴/6-u*f, fixed u=chi*F0*mu, t_*²=chi*F0 and sigma=3M²/F0. Then

S=integral sqrt(-g)[M²*f*R/2-U(f)]+S_m[g,psi],
M²*f*G_mu_nu=T_mu_nu-U*g_mu_nu+M²(nabla_mu nabla_nu f-g_mu_nu box f),
M²*R/2=U_f,  nabla^mu T_mu_nu=0,
3M²*box f=2fU_f-4U+T.                                             (1)

All variations retain delta mu=0. One may not replace U_f by the derivative of epsilon-F*epsilon_F, or append the earlier H5 exchange. The classical fixed-sector scalar action is the allowed effective formulation, not a fundamental freely propagating flat-space three-form.

The Jordan background g=a²(-deta²+dx²) has a>0. Define Hc=a'/a, where HERE AND BELOW primes mean d/deta; dots mean Jordan physical d/dt, dt=a*deta. Ancestor tau=t/t_* derivatives convert by d/deta=(a/t_*)d/dtau. k is a comoving Fourier wave number, laplacian=-k². Dust and radiation have physical Jordan densities rho_d,rho_r, pressures0,rho_r/3, rho_d'=-3Hc*rho_d, rho_r'=-4Hc*rho_r. For fractional perturbations a species must have rho_i>0 on the interval; if absent, omit its contrast/velocity pair. A vacuum test stress requires separately specified absolute conserved stress, not division by rho0.

Take ideal barotropic sound speeds0 and1/3, no entropy perturbation, interactions or anisotropic stress. This omits neutrino stress, baryon-photon scattering and recombination, rather than claiming those observed species obey an exact two-fluid closure. Backgrounds solve the full constrained ancestor equations, not just a chosen a(eta). On each finite interval require a,f bounded away from0 and finite smooth background coefficients; expansion Hc>0 is needed for a redshift chart, not for time-domain existence.

## 2. Actual conformal matter coupling

Set K=sqrt(3/2)*M, phi=K*log f, g_E=f*g_J, a_E=sqrt(f)*a and A(phi)=f^(-1/2). The common conformal time is eta. Write H_E=a_E'/a_E=Hc+f'/(2f), v=phi'=K*f'/f and alpha=dlogA/dphi=-1/(2K)=-1/(sqrt6*M), a constant. The transformed action is canonical gravity+scalar with W=U/f² and S_m[A²g_E,psi]. Varying that actual matter action gives

box_E phi-W_phi+alpha*T_E=0,
nabla_E,mu T_E^mu_nu=alpha*T_E*partial_nu phi.                    (2)

The signs can be checked without assuming a coupled-quintessence formula: delta S_m/dphi=sqrt(-g_E)*alpha*T_E. The canonical scalar divergence is (box phi-W_phi)*partial_nu phi=-alpha*T_E*partial_nu phi, canceling the matter divergence.

rho_iE=f^(-2)rho_iJ, p_iE=f^(-2)p_iJ. In particular

rho_dE'=(-3H_E+alpha*v)rho_dE,
rho_rE'=-4H_E*rho_rE,
v'=-2H_E*v-a_E²[W_phi+alpha*rho_dE],
3M²*H_E²=v²/2+a_E²[W+rho_dE+rho_rE],
H_E²-H_E'=[v²+a_E²(rho_dE+4rho_rE/3)]/(2M²).                    (3)

This is the exact conformal image of the ancestor background, including its Friedmann constraint. Directly rho_dE*a_E³=A*(rho_dJ*a³), so the energy-exchange sign is independently fixed. Radiation trace0 has no such exchange. Einstein-frame densities are NOT the separately conserved Jordan m,r.

Needed derivatives are explicit, with d/dphi=(f/K)d/df:

W=(-1/2+f²/6-u/f)/chi,
W_phi=(f²/3+u/f)/(K*chi),
W_phiphi=(2f²/3-u/f)/(K²*chi).                                    (4)

No stationary-point simplification W_phi0 is used on a general time-dependent background. M and phi have mass dimension1, W/rho have mass dimension4, eta has inverse mass, a and f are dimensionless, H_E has mass and k has mass. Thus alpha has inverse mass, v has mass², q=delta phi has mass, and every term below has the same dimensions. No calibration of t_*,M,u or present G is selected.

## 3. Completely fixed finite-k scalar gauge and actual equations

For k>0 Newtonian gauge has no scalar shift or spatial shear:

g_E=a_E²[-(1+2Psi_E)deta²+(1-2Phi_E)delta_ij dx^i dx^j].

Zero total linear anisotropic stress gives Psi_E=Phi_E=P. Canonical scalar spatial anisotropic stress is quadratic in gradients and vanishes at linear order around homogeneous phi. Perfect fluids add none. P and q=delta phi are the corresponding Newtonian-gauge/Bardeen representatives, not arbitrary synchronous variables. Define fluid velocity by delta T^0_i=-(rho+p)*i*k_i*u_i, so theta_i=k²*u_i. This fixes every momentum sign. The scalar momentum is delta T_phi^0_i=-i*k_i*v*q/a_E². Use velocity POTENTIALS u_i, not theta_i/k² evaluated at k0.

Let delta_d,delta_r denote Einstein-frame fractional densities. Exact linear fluid equations are

delta_d'=-k²*u_d+3P'+alpha*q',
u_d'=-(H_E+alpha*v)u_d+P+alpha*q,
delta_r'=-(4/3)k²*u_r+4P',
u_r'=delta_r/4+P.                                                  (5)

Derivation: dust particle number obeys delta_n'=-theta_d+3P'; its mass is proportional to A, hence delta_d=delta_n+alpha*q. Variation of the mass-dependent point-particle action gives acceleration potential P+alpha*q and friction H_E+alpha*v. This also follows from the spatial component of(2). Radiation's conformally invariant perfect-fluid equations give the last pair. Neither a constant-G growth law nor a quasistatic limit is imported.

The exact perturbed scalar equation is

q''+2H_E*q'+(k²+a_E²*W_phiphi)q
 =4vP'-2a_E²[W_phi+alpha*rho_dE]P-a_E²*alpha*rho_dE*delta_d.        (6)

In detail delta(box_E)phi=a_E^(-2)[-q''-2H_Eq'-k²q+v(Psi_E'+3Phi_E')+2Psi_E(v'+2H_Ev)]. Also delta T_E=-rho_dE*delta_d. Inserting these into(2) and using(3) gives(6), including the lapse multiplier of the background matter source. Dropping that multiplier would not be an exact nonstationary equation. alpha is constant here; there is no omitted alpha_phi term for this selected model.

Define total perturbations and momentum numerator

delta rho_T=(v*q'-v²*P)/a_E²+W_phi*q+rho_dE*delta_d+rho_rE*delta_r,
delta p_T=(v*q'-v²*P)/a_E²-W_phi*q+rho_rE*delta_r/3,
B=[v*q+a_E²(rho_dE*u_d+4rho_rE*u_r/3)]/(2M²).                     (7)

The Einstein00,0i,traceless and spatial-trace equations respectively are

C=k²P+3H_E(P'+H_EP)+a_E²*delta rho_T/(2M²)=0,
P'+H_EP=B,
Psi_E-Phi_E=0,
P''+3H_EP'+(2H_E'+H_E²)P=a_E²*delta p_T/(2M²).                   (8)

The sign of00 is fixed by the static weak-field limit k²P=-a_E²*delta rho/(2M²), so a positive overdensity has negative Newtonian potential. The sign of0i follows from delta G^0_i=-2i*k_i(P'+H_EP)/a_E² and the explicitly defined negative momentum density. These constraints do not assume subhorizon modes.

## 4. Concrete first-order IVP, propagation and true data count

Use Y=(P,q,s,delta_d,u_d,delta_r,u_r), s=q'. Given a smooth exact background, evolve the following SEVEN first-order equations:

P'=B-H_EP,
q'=s,
s'=-2H_Es-(k²+a_E²W_phiphi)q+4v(B-H_EP)
    -2a_E²(W_phi+alpha*rho_dE)P-a_E²*alpha*rho_dE*delta_d,
delta_d'=-k²u_d+3(B-H_EP)+alpha*s,
u_d'=-(H_E+alpha*v)u_d+P+alpha*q,
delta_r'=-(4/3)k²u_r+4(B-H_EP),
u_r'=delta_r/4+P.                                                   (9)

Impose the SINGLE initial00 constraint

C=k²P+3H_EB+[v*s-v²P+a_E²W_phi*q
                 +a_E²rho_dE*delta_d+a_E²rho_rE*delta_r]/(2M²)=0. (10)

No division by H_E,Hc,v,f' or k occurs in(9). It remains regular at a Hubble turning point or scalar turning point on the stated positive-f background. Do not eliminate P through a denominator2M²k²-v² and then call its zero a physical singularity. To initialize the codimension-one constraint, if v!=0 solve(10) for s; if v0 solve for P using coefficient k²>0. These charts cover all finite-k initial backgrounds and make the differential ofC nonzero. Other valid choices are possible, but arbitrary seven initial values are not.

Here is an explicit propagation proof rather than an imposed redundant evolution. Differentiate B using(3),(5) and q'=s; coupling terms cancel and give

B'+2H_EB=a_E²*delta p_T/(2M²)+(H_E²-H_E')P.                       (11)

For example (a_E²rho_dE*u_d)'=a_E²rho_dE[-2H_Eu_d+P+alpha*q]; the scalar term (v'+2H_Ev)q contributes -a_E²(W_phi+alpha*rho_dE)q, canceling the dust alpha term. The radiation pair contributes a_E²rho_rE*delta_r/3. Substitution of P'=B-H_EP into(11) yields EXACTLY the spatial-trace equation in(8), without usingC0.

With the scalar and matter equations, total Einstein-frame stress is conserved. Let E^mu_nu be the linear residual G^mu_nu-T_total^mu_nu/M². The exact background residual is zero, so linearized Bianchi is the background covariant divergence ofE, with no residual-background connection term. Our0i,slip and(11) set E^0_i,E^i_0,E^i_j to0. Since E^0_0=2C/a_E², its nu0 divergence gives

(E^0_0)'+3H_E*E^0_0=0, equivalently C'+H_E*C=0.                  (12)

Thus initially zeroC remains zero. A nonzeroC is a constraint-violating solution, not an additional scalar physical mode. This derivation holds for k>0; the0i equation must not be inferred by dividing a zero homogeneous gradient.

For two populated fluids the seven variables minus one independent constraint give SIX scalar initial data per real Fourier component: two gravitational-scalar data plus two per fluid. There is no remaining finite-k scalar gauge freedom. For complex Fourier amplitudes impose Y(-k)=conjY(k) for real fields; this is not doubling physical data. Omit two data for each absent fluid. Vector/vorticity and tensor sectors are separate, not silently counted among scalar data.

At k0 the Newtonian scalar spatial gauge condition loses meaning and0i contains no equation. Homogeneous isotropic perturbations are instead variations of the ancestor constrained background at fixedu, with its linearized Friedmann constraint, a homogeneous time reparameterization and an arbitrary constant normalization ofa removed. Varying the ancestor time-domain system and C0 gives a well-defined homogeneous IVP, including atH0; delta mu is excluded. At a degenerate constraint point such as equilibrium Minkowski, satisfying its linearized constraint alone does not prove integrability to a nonlinear constrained family; only tangents of actual admissible initial-data families are meant. No unrestricted homogeneous data count or nonlinear linearization-stability theorem is asserted. Equations(9) may be taken to k→0 for regular velocity-potential families satisfying their limiting momentum condition, but this special limit must not be called every homogeneous solution or extra free gauge-invariant modes. In vacuum at a stationary background it yields the accepted two physical scalar data and the earlier homogeneous mass/stability control.

## 5. Explicit Jordan reconstruction and all component constraints

Keep identical eta and coordinates. Set d=delta f=f*q/K, b=f', H=Hc, and use Psi,Phi WITHOUT subscript for Jordan potentials. Conformal transformation gives

Psi=P-q/(2K)=P+alpha*q,
Phi=P+q/(2K)=P-alpha*q,
delta_iJ=delta_iE+2q/K=delta_iE-4alpha*q,
u_iJ=u_iE,   H=H_E+alpha*v.                                      (13)

These relations follow by multiplying the perturbed metric by f+delta f and rho_E=f^(-2)rho_J. They are not a transformation between unrelated gauge choices: both metrics retain Newtonian form in the same coordinates, and the perturbation of phi is evaluated on that same slicing. All fields can therefore be reconstructed from the actual first-order solution.

For independent check, define A0=k²Phi+3H(Phi'+H*Psi), and
E_s=Phi''+H(Psi'+2Phi')+(2H'+H²)Psi+(k²/3)(Phi-Psi).
The FULL Jordan00,0i, tracelessij and mean spatial-trace equations are

2f*A0-3H²*d
 =-a²(delta rho_J+U_f*d)/M²+k²*d+3H*d'-3b*Phi'-6H*b*Psi,
2f(Phi'+H*Psi)=a²[rho_d*u_d+4rho_r*u_r/3]/M²+d'-H*d-b*Psi,
f(Phi-Psi)=d,
2f*E_s-(2H'+H²)d
 =a²(delta p_J-U_f*d)/M²+d''+H*d'+(2/3)k²*d
   -b(Psi'+2Phi')-2Psi(f''+H*b),                                  (14)

where delta rho_J=rho_d*delta_dJ+rho_r*delta_rJ and delta p_J=rho_r*delta_rJ/3. All background f,a,U derivatives in(14) are evaluated on the same exact nonstationary solution. The slip equation assumes k>0; its scalar traceless operator has no k0 content.

One direct component check is delta[(nabla^0 nabla_0-box)f]=a^-2[k²d+3Hd'-3bPhi'-6HbPsi]. The mean spatial derivative combination is a^-2[d''+Hd'+(2/3)k²d-b(Psi'+2Phi')-2Psi(f''+Hb)]. Together with background G^0_0=-3H²/a² and G^i_i/3=-(2H'+H²)/a² these give(14) by varying(1), fixing its signs and factors.

The integrated Maxwell equation is not discarded. Its explicit first variation is

delta R=(2/a²)[-3Phi''-3H(Psi'+3Phi')
                  -6(H'+H²)Psi+k²(Psi-2Phi)]=2U_ff*d/M².          (15)

The covariant trace equation equivalently gives

d''+2Hd'+[k²+a²*m_J²(f)]d
 =b(Psi'+3Phi')+2Psi(f''+2Hb)+a²rho_d*delta_dJ/(3M²),
m_J²(f)=2(fU_ff-U_f)/(3M²).                                       (16)

Away from a stationary background m_J²(f) need not be positive and(16) is driven by background/metric/matter terms; it is not an autonomous stable massive equation. Its absence of a radiation trace is exact, not an omission of radiation gravitational effects. Both(15) and(16) follow from the reconstructed full equations; neither is an extra freely imposed oscillator.

Finally(13) converts(5) to the truly conserved Jordan fluids:

delta_dJ'=-k²u_d+3Phi',  u_d'=-H*u_d+Psi,
delta_rJ'=-(4/3)k²u_r+4Phi',  u_r'=delta_rJ/4+Psi.                 (17)

For instance the extra alpha*q' in the Einstein dust density cancels against the -4alpha*q' conversion to leave3Phi'. This explicitly checks the physical frame, time and force potential. No constant-G Poisson closure was inserted. Full(14)–(17) are equivalent to the constrained Einstein construction on f>0; invertibility of the field transformation and the already derived matter action supply that equivalence.

## 6. Existence, reconstruction errors and endpoints

For each fixed finite k>0, (9) is a linear ODE Y'=L_k(eta)Y, with every entry explicitly specified in(3)–(9). On a compact regular background interval it is continuous; its integral equation has a unique fundamental matrix T_k(eta,eta_i), constructed by uniformly convergent Picard iterated integrals, bounded in any subordinate norm by exp(integral||L_k||). Proof: the nth iterated integral is bounded by (integral||L_k||)^n/n!, and the series can be differentiated under the uniformly convergent integral. This is an actual constructive IVP, not just a named transfer matrix. Equation(12) ensures T maps admissible initial data to admissible data. Smooth background gives all derivatives needed in(14)–(16).

This establishes linear evolution on each finite regular interval, not global nonlinear stability or uniform all-k ultraviolet control. k-dependent norm growth contains the explicitly present k²; any finite-band/spatial Sobolev claim needs its own energy/uniform estimates. No calibrated primordial stochastic spectrum or selected amplitude is assumed. These are linearized equations: a finite-time bounded mode can be multiplied by a sufficiently small perturbation parameter to stay in the declared linear regime, but no quantitative nonlinear remainder, dust multistream/caustic theorem or global nonlinear stability follows from the linear norm bound. f0, a0, singular background blowup and a non-ideal fluid closure change the domain; no numerical zero is filled across those events. Positive nonzero fluid densities remain positive on finite regular intervals by the exact conservation formulas.

For a future validated calculation suppose the exact admissible background Z and a certified approximation Ztilde lie in a proven compact positive-a,positive-f domain, with background error e_Z(eta). Use the actual entries to bound ||L_k||≤ell(eta), ||L_k(Z)-L_k(Ztilde)||≤b(eta)e_Z, and ||Ytilde||≤Ymax. If the numerical residual Ytilde'-L_k(Ztilde)Ytilde has norm≤r, variation of constants gives

||Y-Ytilde||(eta)≤exp(integral_i^eta ell)*e_Yi
 +integral_i^eta exp(integral_s^eta ell)[r(s)+b(s)e_Z(s)Ymax(s)]ds.   (18)

This is forward time; reversed intervals use the corresponding absolute-time integration bounds. Initial projection/constraint error, parameters, rounding and quadrature must be bounded as actual additional terms. ell,b are not accepted from an unverified receipt; they are explicit row-sum/derivative suprema of the given finite matrix on an established domain. The background constraint/residual/error route of e75de997 supplies e_Z only when actually validated. For a forced constraint residual C'+H_EC=r_C, the exact integrating factor gives C(eta)=a_E(i)C_i/a_E(eta)+a_E(eta)^(-1)integral_i^eta a_E(s)r_C(s)ds. SmallC alone does not bound physical solution error.

For physical observer evaluation use a common Jordan redshift chart H_J>0, a_o1, x=ln a=-ln(1+z). Convert d/deta=aH_J*d/dx; equivalently L_x=L_eta/(aH_J). A shared-redshift error requires a proven positive aH_J margin and includes its denominator/background error, not substitution of a time error at unequal redshifts. This reduces to the ancestor background chart and distance contract. Local algebraic reconstruction(13) and derivative entries in(9) then give explicit Lipschitz observer errors on the compact domain; the powers1/f,1/a and photon endpoint denominators require their stated positive margins. No unrun numerical implementation is certified.

## 7. Controls that distinguish the model and rule out false shortcuts

Vacuum expanding deSitter: take rho_i0, constant f_b=(-3u)^(1/3)>1, u<-1/3. Then v0,W_phi0 and no fluid data. Equations(6),(8) give q''+2H_Eq'+(k²+a_E²*m_E²)q0, m_E²=2f_b²/(sigma*t_*²). For k>0 the momentum and00 equations force P0. By(13) Psi_J=-d/(2f_b),Phi_J=d/(2f_b); (16) becomes the accepted q_f cosmic-time equation with m_J²=f_b*m_E²=2f_b³/(sigma*t_*²). In the static Minkowski limit u=-1/3,f1,H0 the same massive KG and scalar slip remain. Thus metric scalar response is reconstructed rather than erased by declaring vacuum has no perturbations.

For the homogeneous stationary vacuum, use the separate k0 constrained-background variation described above. The physical-time scalar roots lambda²+3H_b lambda+m_J²0 reproduce the earlier constrained FRW stability. Constant homogeneous rescalings and clock shifts are not additional finite-k modes.

Radiation control: its trace is identically0 in(2),(16), but rho_r,delta_r,u_r still enter00/0i and metric driving. A constant-f solution is possible when fU_f=2U and no dust: it is GR with M_eff²=M²f and cosmological constant U/(M²f), plus radiation. With d=d'0 its perturbations reduce to exact GR ideal-radiation equations. With arbitrary dust rho_d!=0 a constant-f assumption instead requires the trace relation -rho_d=4U-2fU_f; a time-varying conserved dust density generally violates it. Consequently imposing fconstant and importing exact GR dust growth is NOT a valid control for this nonstationary model. Scalar sourcing by dust is a required retained effect.

At a scalar turning point v0 with populated matter the IVP and(10) stay regular, but q remains a physical scalar perturbation. At H_J0 the time-domain theory stays regular; fixed-redshift/observer parametrization may fail. At an absent species do not claim unconstrained finite fractional density modes. At k0 do not impose divided spatial constraints. Positivity of f gives positive canonical kinetic and tensor terms, not a theorem of nonstationary scalar stability, negligible fifth forces or viable clustering. Replacing the exact exchange by Einstein rho_dE'=-3H_Erho_dE, dropping lapse/source terms in(6), or using Psi_J=Phi_J for q!=0 fails the explicit controls above.

## 8. Tensor channel and actual Jordan observer transfer

For h_ij transverse traceless at k>0, the exact quadratic tensor action on the same nonstationary background has coefficient M²*f*a³/8 in Jordan physical time. Varying it gives

h_ij''+(2Hc+f'/f)h_ij'+k²h_ij=0,
or ddot h_ij+(3H_J+dot f/f)dot h_ij+(k²/a²)h_ij=0.                (19)

There are two TT polarizations, each with two initial data, unit characteristic speed and positive kinetic coefficient. Perfect scalar fluids supply no linear TT anisotropic source. An added real TT stress would enter as2a²*pi_TT/(M²f) in the conformal equation and is not supplied here. Einstein transformation gives friction2H_E, providing an independent normalization check. The tensor rescaling z_T*h with z_T=a*sqrt(f) obeys y''+[k²-z_T''/z_T]y0. For the displayed summed tensor-component action the unit-kinetic field is (M/2)*z_T*h_ij, with an additional fixed normalization for the chosen polarization inner product; no quantum power normalization is inferred. The same mode equation holds; a time-dependent pump need not imply monotone Jordan unweighted energy. No stationary-vacuum energy monotonicity is extrapolated to arbitrary backgrounds.

For scalar observables define Jordan comoving contrasts

Delta_i=delta_iJ+3Hc*(1+w_i)u_i.                                  (20)

Under a scalar time shift the two terms transform oppositely using the conserved Jordan background; these combinations, or their Newtonian representatives, are legitimate density transfer variables. Matter peculiar acceleration is driven by Psi_J=P+alpha*q, lensing by (Phi_J+Psi_J)/2=P, and slip Phi_J-Psi_J=q/K. Thus lensing and dynamical mass can probe different combinations without inserting a quasistatic effectiveG. The exact constraint also gives k²P=-a_E²[delta rho_T+3H_E(vq/a_E²+rho_dE*u_d+4rho_rE*u_r/3)]/(2M²); it is a full total comoving constraint, not dust-only Poisson.

For given admissible initial column vectors e_A(k), (9) constructs transfer columns T_k*e_A. Explicit row maps from(13),(20) give Psi_J(k,eta),Phi_J(k,eta),Delta_d,Delta_r,u_i. If a PSD initial covariance C_AB(k) is later physically supplied, the resulting linear two-point covariance is T*C*T_dagger followed by these row maps; no C or power normalization is invented. Correlations/entropy modes are not silently assigned adiabatic values.

A chosen observer/source congruence has Jordan four-velocity u^mu=a^(-1)(1-Psi,v^i) to first order, with a dust tracer obeying(17) or a separately specified measured trajectory; it is not selected by the radiation velocity by default. Jordan minimally coupled light defines actual redshift1+z=(u_mu k^mu)_s/(u_mu k^mu)_o. With outward observer-to-source direction n and conformal Newtonian velocity v_i=-i*k_i*u, its linear redshift perturbation at fixed coordinate endpoints is

delta ln(1+z)=Psi_o-Psi_s+n·(v_s-v_o)
                   -integral_source^observer (Phi'+Psi')deta.     (21)

This fixes endpoint gravitational and Doppler signs; observed fixed-z source time shifts must also be included when predicting distances/number counts. The integrated potential is2P', so the ISW temperature contribution has the opposite sign to the redshift term. No claim about the source's intrinsic spectrum is inserted.

A complete geometric distance transfer can be constructed without a flat-G distance ansatz: insert reconstructed Jordan g_J into null geodesic k^nu*nabla_nu k^mu0 and a parallel-transported observer screen. Normalize the backward ray's measured observer frequency to1 and screen basis by the local Jordan orthonormal tetrad. The screen Jacobi matrix solves D_AB''=-R_AC D_CB in affine parameter, R_AC the screen curvature contraction chosen with traceR=R_mu_nu*k^mu*k^nu; D(o)0,D'(o)=I with affine parameter increasing into the past. Integrate to the source event selected by the invariant redshift condition above. Then D_A=sqrt(detD) on a no-caustic branch, and D_L=(1+z)²D_A under minimally coupled photon-number conservation. Differentiate this explicit IVP at perturbation amplitude0 to obtain the linear observable; all coefficients are determined by(13)–(17) and background, including Ricci perturbations/endpoint motion. Riemann sign uses R_std consistently. This is a concrete observer-IVP prescription with initial/boundary data, not a freely chosen lensing/growth transfer function.

For a spatially flat background the linear Born transverse convergence part equivalently reads kappa=(1/2)integral_0^chi_s [chi(chi_s-chi)/chi_s]*laplacian_perp(Phi+Psi)dchi. This is only its lensing term: Doppler, observer/source potential and redshift-to-affine conversion are required for the COMPLETE observed distance and are supplied by the geometric IVP, not dropped. The formula gives2P in the integrand, making conformal lensing correspondence explicit. Background Hubble/angular/luminosity distances and the declared apparent-CPL subtraction remain exactly those of e75de997, using H_J at the same redshift and the declared reference matter densities. Perturbation/selection/lensing corrections are layered through this actual metric and measurement map, not absorbed into a universal source w0,wa.

On a finite no-caustic ray interval with bounded curvature and positive redshift derivative at the selected endpoint, geodesic/screen/Jacobi plus endpoint equations are a smooth finite ODE/event problem. The same variation-of-constants/residual argument as(18), now including first metric derivatives and curvature, bounds affine transport; the inverse-function bound1/|dz/dlambda| controls endpoint displacement. A positive determinant margin controls the square-root distance reconstruction. These margins, regular observer/source tetrads, derivative/curvature errors and quadrature are real future validation obligations, not consequences of a small background H error. Turning redshift events or caustics require a changed chart rather than fake finite errors.

## 9. Scientific next construction and unchanged acceptance

This is a complete selected ideal-fluid finite-k linear forward system, propagated constraints, data count, explicit Jordan equations, tensor channel and concrete observer transfer/finite-window error route. It goes beyond the accepted stationary vacuum modes while preserving their controls. It needs a fresh independent nonauthor derivation review before any manual acceptance.

The next substantive implementation is one constrained background+linear-transfer evaluator on admitted exact parameters/data, with actual initial constraint projection, positive-f event handling, independent vacuum/radiation/dust-source controls, residual/refinement/rounding bounds and observer-ray/error tests. ROOT alone can allocate that runtime/native/integration work. Real species/initial spectra, baryon/neutrino/recombination closure, local measuredG/time/length calibration, source-selected regime/priors, rapid-oscillation physical averaging/measurement response and same-data likelihood/model selection remain BUILD. No calibrated parameter, initial spectrum, nonempty observedband or empirical significance has been assigned. Distinct2011plateau dynamics, microscopic ADW/magnitude and all original shared physical obligations remain separate. No native theorem, source installation, new gate/ledger, failed-model verdict, reduced charter, scientific deferral, main or publication closure follows.

Complete original independent manual verification: [full review](reviews/KV2008_NONSTATIONARY_MATTER_PERTURBATIONS.md). Source selection and process scope: [original source/model contract](source-models/KV2008_NONSTATIONARY_MATTER_PERTURBATIONS.md). This records scoped mathematics, not native, physical, main or publication closure.
