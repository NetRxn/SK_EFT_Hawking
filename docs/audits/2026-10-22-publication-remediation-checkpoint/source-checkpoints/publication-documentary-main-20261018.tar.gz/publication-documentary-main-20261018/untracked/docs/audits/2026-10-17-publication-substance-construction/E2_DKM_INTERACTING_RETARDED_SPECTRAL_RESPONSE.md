# Interacting retarded spectral response — construction

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** Whole declared interacting carrier and retarded spectral construction, exact state/operator/frequency and source conventions; independent manual acceptance only.

**Original physical obligations.** Original physical Mori/KMS/sum-rule/DKM/CHHK and actual low-frequency transport, phase/material/contact/nozzle/readout/calibration remain owed; model evidence does not identify the actual device.

The construction author is publication_njl_target_review; the complete independent scientific review is by publication_root7_current_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE](E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE.md), [fixed source model](source-models/E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE.md), [full independent review](reviews/E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE-CONSTRUCTION -->
# Same interacting AB/contact carrier: signed response, thermal measures, moments and exact memory

AUTHOR MANUAL SCIENTIFIC CONSTRUCTION; genuinely nonauthor WHOLE review and lead intake required. This is the original nonzero interacting E2r3 physical CAR family with all semi-infinite finite-band contacts, not a replacement free, finite-only, zero-coupling, zero-mu or favourable-state model. It constructs its response/moment/memory substrate. A bulk/device DKM limit, physical transport coefficients and a useful calibrated window remain substantive BUILD, decomposed below. No production source, predicate body or runtime/native state is changed.

## 1. Fixed physical carrier and precisely inherited state construction

The new fixed SOURCE_MODEL dca1bfb1 was saved14:30:20.054102–14:30:20.054595 UTC after genuine FIRST/full protection and BEFORE new mathematical scratch. It contains the entire exact original r3 MODEL72df7302 and growth MODEL5f9584a6. The full bound actual definitions and complete r3/growth constructions and their genuinely nonauthor reviews were personally read before this proof. The14:33:38 progress marker records completed dependency-reading/prospective work; it is not a fabricated exact mental-start time. Some orientational measure notation was considered after the carrying reads and before that marker; no new mathematics preceded MODEL. Original earlier pre-MODEL and direct-definition-read-first failures remain unwaived.

The one-particle graph is the same finite embedded AB pi-orbital patch C with both physical spins, every original intralayer/vertical/contact hopping, and finitely many semi-infinite nearest-neighbour finite-band chains. Physical charge is q=-e. The bounded self-adjoint hopping h includes the original one-body self-image/background potential. The static gate model has normalized disjoint uniform radius-a_i charge spheres above a grounded plane in dielectric epsilon>0. Its actual energy coefficients are

    U_ii=e²/(4pi epsilon)[6/(5a_i)-1/(2z_i)],
    U_ij=e²/(4pi epsilon)[1/R_ij-1/R*_ij],
    u_i=-e²/(16pi epsilon z_i)-sum_j U_ij nu_j,
    V=sum_i U_ii n_iup n_idown + sum_(i<j) U_ij N_i N_j,
    H_lambda=dGamma(h)+lambda V,
    w=||V||=sum_i U_ii+4sum_(i<j)U_ij.                     (1)

All cloud/gate separations, physical positions, selected coefficients, spin counts and nonzero physical lambda=1 remain. Arbitrary real comparison lambda, beta>0 and real mu are retained. No infinite total-energy element or Gibbs trace is required: the physical point-norm continuous CAR group alpha is the full free group conjugated by its norm-convergent bounded-local V cocycle. In vacuum Fock H is self-adjoint on the direct-sum dGamma(h) domain; local CAR polynomials lie in every physical generator domain. In thermal representations use the same algebraic dynamics, not a finite-particle replacement.

For clarity the exact inherited positive equilibrium construction is restated. Let K_L=H_lambda,L-mu N_L in finite contact boxes and R_0=f_beta(h-mu) for the coupled infinite free state omega_0. V is neutral. Its entire free imaginary-time polynomial V_E(u) has norm <=w exp(4kappa u), kappa>=||h-mu||. The norm-convergent equation Y'=-lambda V_E Y, Y(0)=1 at u=beta/2 gives

    omega(A)=omega_0(Y A Y†)/omega_0(Y Y†),
    exp(-beta|lambda|w)<=omega_0(Y Y†)<=exp(beta|lambda|w).
                                                                  (2)

In each box this numerator/denominator is exactly the positive normalized exp(-beta K_L) expectation by cyclic trace. Orbital Taylor paths, cocycle simplex tails and local Fermi-covariance polynomial approximation give the explicit local limit of r3(28)–(31); numerator and denominator converge on every fixed local algebra. Thus (2) is positive and normalized on the full infinite CAR algebra, not formal imaginary symbols. Finite-volume tau_K KMS passes via Gaussian analytic smears, compact-time/contact convergence and the bounded-strip maximum principle as in the fully read r3(31a–e). No infinite trace or epsilon-to-zero limit of a divergent Gaussian bound is used.

Tau_t=gamma_(-mu t/hbar) alpha_t is the full-CAR equilibrium KMS group; gamma_theta(B_r)=exp(i r theta)B_r. Gauge and tau invariance pass to (2), hence omega is physical-alpha stationary. On neutral charges/currents, tau=alpha. On charged grade-r fields the physical strip boundary has factor exp(-beta mu r); ordinary physical-H KMS at nonzero mu is not claimed. This exact inherited theorem, including its full proof/review25114f36 and lead76747, is a dependency, not new scientific self-acceptance.

The other original states remain: the partitioned positive free Q/tail preparation with arbitrary central positive contraction, every original thermal tail, correlated positive initial states with their actual higher moments, the S1 coherent state and stationary Gaussian vacuum countercontrol. Their interacting quench evolution is generally nonstationary and receives no equilibrium KMS by declaration.

## 2. Actual bounded channels, physical positions and conservation

Choose any finite family of Hermitian neutral local CAR polynomials X_a, centered by omega, containing ALL requested physical spin-summed local charges Q_i=qN_i, actual contact/bond currents and finite measured weighted channels. Real and imaginary parts allow every complex channel without discarding a component. Write a_a=||X_a||. The original local current oriented j into i is

    I_(i<-j)=(iq/hbar)sum_sigma[conj(h_ij) c_j†c_i-h_ij c_i†c_j],
    ||I_(i<-j)||=2|q h_ij|/hbar,
    delta Q_i=sum_(j adjacent i) I_(i<-j),
    delta A_f=sum_(oriented bonds i<-j)(f_i-f_j)I_(i<-j),
    A_f=sum_i f_i Q_i,  f_i=0 outside its finite support.   (3)

Here delta=(i/hbar)[H,.]; there is one term for each unordered bond in the last sum. These equalities are exact because [V,N_i]=0, not a weak-coupling assumption. Boundary bonds MUST be included. In particular a q=0 finite-central charge leaks into its real contacts; it is not the conserved infinite total charge.

For actual positions r_i, A_k=sum_i g_i exp(-ik.r_i)Q_i with real finite g_i has A_k†=A_-k. A cell-area/volume division is allowed only with its explicit positive physical input and associated units. Arbitrary finite complex arrays F define A_a=sum_b F_ab X_b; no translational or inversion symmetry, Fourier orthogonality or continuum momentum integral is invented for the finite embedded patch. The state, all contacts and all weights are retained, including null or conserved combinations.

The current has genuine nonzero interaction content at later order. At an actual contact a-i, the full-graph local transition |a_up,i_down> to |i_up,i_down> changes V energy by U_ii>0, so the [V,I_up] matrix element has magnitude U_ii|qv_a|/hbar. Opposite-spin absence gives zero as a control. Other hoppings/interactions are not removed. The exact interacting expectations below retain the full four-spin-pair noise and connected vertex; a dressed free bubble or classical collision covariance cannot replace them.

## 3. Ordered matrix Borel measures and exact thermal balance

In the GNS representation of (2), U_t pi(A)Omega=pi(alpha_t A)Omega is a strongly continuous unitary group, U_t=exp(i t L), with L a self-adjoint FREQUENCY generator. Let x_a=pi(X_a)Omega and E_L its spectral resolution. Then

    M_ab(domega)=<x_a,E_L(domega)x_b>,
    C^>_ab(t)=omega(alpha_t(X_a)X_b)
                           =integral exp(-iomega t) M_ab(domega),
    C^<_ab(t)=omega(X_b alpha_t(X_a))
                           =integral exp(-iomega t) M_ba(-domega).
                                                                  (4)

The Hilbert inner product is conjugate-linear first. For every Borel set B and vector c, c†M(B)c=||E_L(B)sum_a c_a x_a||²>=0; the finite matrix measure is Hermitian PSD, mass M_ab(R)=omega(X_a X_b), not necessarily real entrywise. Cauchy-Schwarz bounds total variation |M_ab|(R)<=a_a a_b. Finite complex channels transform the measure by F M F†, so their positivity is genuine, not an assumed scalar sign on cross entries.

To derive detailed balance, in a finite box use exact interacting eigenstates of H and N, weights p_m proportional exp[-beta(E_m-mu N_m)]. The neutral matrix element X_a,mn has N_m=N_n and frequency omega_nm=(E_n-E_m)/hbar. Its contribution is p_m X_a,mn X_b,nm. Interchanging m,n multiplies its weight by exp(-beta hbar omega_nm). This proves the full matrix identity, not only a diagonal free-particle formula. Local state/dynamics convergence gives weak convergence of the two ordered measures (uniform local second moments ensure tightness); on compact frequency sets the exponential is bounded, so the identity passes, then Borel exhaustion gives

    M^<(domega)=M^T(-domega)=exp(-b omega)M(domega),
    K(domega):=M-M^<=(1-exp(-b omega))M(domega), b=beta hbar.
                                                                  (5)

Equivalently this follows by Fourier testing the actual neutral KMS strip. No density with respect to Lebesgue measure is assumed. For omega>0 K is PSD; on omega<0 it is NSD, with K_ab(-domega)=-K_ba(domega). A Hermitian SINGLE channel has an odd signed commutator measure. For the complex spatial channel, the correct relation is K_k(-domega)=-K_-k(domega); same-k oddness requires an independently established k/-k symmetry. None is present by naming the patch graphene.

A grade-r charged channel instead has lesser/greater factor exp[-beta(hbar omega+mu r)] because its intermediate particle-number difference is -r. For annihilation r=-1 this is exp[-beta(hbar omega-mu)], not exp(-b omega). This charged countercontrol retains nonzero mu and the whole graph; the retarded electromagnetic response here concerns neutral sources. Ordinary operator KMS has no extra fermionic minus sign; time-ordered fermionic antiperiodicity is a different convention.

## 4. Independent elastic noise and every zero-inclusive probe

Define the actual centered elastic matrix

    E_ab=M_ab({0})=<P_0 x_a,P_0 x_b>, P_0=E_L({0}),
    M=E delta_0+M_inel,
    K({0})=0,
    M_sym=E delta_0+(1/2)coth(b omega/2)K on omega!=0.      (6)

E is PSD; for the Hermitian basis thermal balance also gives E=E^T. It can vanish for some channels; it is NEVER set to zero from KMS or reconstructed by multiplying zero by singular coth. Centering removes the mean, not every invariant GNS vector. E and M_inel are actual independent components of the original observable, not a changed population or Gaussian approximation.

For X_f=int dt f_a(t)alpha_t(X_a), finite L1 probes, its exact ordered/symmetrized covariance is the corresponding positive matrix quadratic form of M/M_sym and Fourier transforms. With fhat(omega)=int dt exp(iomega t)f(t), the elastic term is sum_ab conjugate(fhat_a(0)) E_ab fhat_b(0). Precisely, for Y=sum_a integral f_a(t)X_a(t)dt, omega(Y†Y)=sum_ab integral conjugate(fhat_a(omega)) M_ab(domega) fhat_b(omega). Its elastic contribution is therefore exactly that displayed quadratic form, including complex probes. Zero-inclusive probes retain this term; it vanishes exactly when their zero-frequency vector lies in the E-nullspace, including a probe with fhat(0)=0. Standard spectral-density notation is S^>=2pi M, S^<=2pi M^<, S_sym=2pi M_sym AS MEASURES; if densities exist, inverse angular Fourier is d omega/(2pi). Hz uses omega=2pi f; a one-sided fold is performed once only. An elastic measure is not a smooth PSD to interpolate.

A strict positive elastic countercontrol uses each actual finite interacting contact box, retaining every hopping/U/beta/mu: total N_L is conserved and its faithful Gibbs density gives Var(N_L)>0 (vacuum and occupied sectors both have positive weight). Its centered spectral measure is Var(N_L)delta_0 and commutator response identically zero. This does not assert that the infinite extensive N is a bounded CAR observable or that its thermodynamic variance limit exists. For the actual infinite model a finite q=0 region obeys (3) including storage; its E is the exact P_0 expression, possibly zero. A physical bulk q=0 susceptibility/order of limits is separately owed. These controls prevent false elimination of elastic noise without replacing the infinite target by a box.

In a nonstationary quench, omega_init(Y†Y)>=0 for Y=sum_a int f_a(t)[A_a(t)-omega_init(A_a(t))]dt proves the full positive TWO-TIME covariance for every retained correlated state. There need be no time-difference kernel, single-frequency measure, detailed balance or FDT. The causal two-time response uses the actual same initial state; no equilibrium formula is transplanted to it.

## 5. Actual source sign, true UHP function and dispersion

For a finite neutral physical perturbation H'(t)=-sum_b f_b(t)X_b, differentiating the full interacting interaction-picture unitary gives delta<X_a(t)>=int ds chi^R_ab(t-s)f_b(s) at linear order, where

    chi^R_ab(t)=(i/hbar)theta(t)omega([alpha_t(X_a),X_b]),
    chi_ab(z)=(i/hbar)int_0^infinity dt exp(izt)omega([X_a(t),X_b])
             =(1/hbar)int K_ab(domega)/(omega-z), Im z>0.  (7)

The time integral exists absolutely, bounded by2a_a a_b/(hbar Im z). Uniform domination of every complex derivative on compact UHP sets proves HOLomorphy, with derivative bound2a_a a_b n!/[hbar(Im z)^(n+1)]. This is an actual complex response, not an existential real-value predicate. The Cauchy formula follows from int_0^infinity exp[i(z-omega)t]dt=i/(z-omega). Changing the sign of H' changes the response sign; it is not a convention-free nonnegative assertion.

In boundary distribution/Borel form, chi_AH=(chi-chi†)/(2i) has measure pi K/hbar and the Hermitian part is its principal-value dispersion. The finite-variation Cauchy transform gives the Kramers–Kronig identity as a distribution; pointwise boundary values or a regular density require extra regularity. Matrix Hermitian/anti-Hermitian parts, not entrywise imaginary parts of arbitrary cross entries, describe absorption. For a diagonal neutral channel at positive frequency absorption is nonnegative. Its negative-frequency counterpart is negative. For Hermitian X_a the real causal kernel gives the corresponding frequency-conjugation relation; for A_k use its adjoint -k partner, not assumed inversion symmetry.

The response has units [X_a X_b]/J; its time kernel has units [X_a X_b]/(J s), since hbar has J s. The absorptive Borel measure has units [X_a X_b]/(J s); density, if present, has units [X_a X_b]/J. This distinction fixes the2pi/hbar factors. No compact many-body spectral support follows from bounded one-particle bandwidth.

## 6. Derived integrated moments, window bounds and high-frequency weight

Every local channel has all delta derivatives from the actual even-term support tree. Decompose the actual Hamiltonian into singleton onsite terms, two-orbital hopping terms of norm|h_ij|, and all actual density-pair terms of norm|lambda U|. Let J_E=sup_x sum_(X contains x)||Phi_X|| in joules; the finite central clique, bounded finite-degree hopping/contact graph and finitely many tail types give an explicit finite supremum of these actual incident coefficient sums, as derived in growth(5)/(6). No volume norm of the extensive H is used. For s>=1 supported spin orbitals and this model-derived incident energy J_E, ||delta^n X||<=n!(2sJ_E/hbar)^n||X||, with sharper componentwise physical-charge/current constants in growth(10)/(11). Thus every moment below is finite with actual volume-independent bounds. Differentiating the actual commutator correlation at zero gives

    int omega^n K_ab(domega)=i^n omega([delta^n X_a,X_b]),
    int K_ab=omega([X_a,X_b]),
    int omega K_ab=(1/hbar)omega([X_b,[H,X_a]]),
    int omega chi_AH,AA(domega)/pi
                              =omega([A,[H,A]])/hbar².     (8)

These are integrated equalities derived from H and its proven domain, not a supplied pointwise bound renamed f-sum. For a Hermitian scalar A, K is odd, so the positive-frequency first moment is HALF the last full-line moment. The double commutator is nonnegative in equilibrium. The full-line expansion at large imaginary z is -sum_n [int omega^n K]/(hbar z^(n+1)); after terms n=0,...,p the remainder has absolute value at most integral |omega|^(p+1)|K_ab|(domega)/[hbar |z|^(p+1) Im z], from 1/(omega-z)=-sum_(n=0)^p omega^n/z^(n+1)+omega^(p+1)/[z^(p+1)(omega-z)]. It is an asymptotic moment expansion, not a universal convergent series at all z.

For r>0, finite Lambda>=r, let g_r=(1-exp(-b r))/r. Its monotonicity follows from exp(-x)(1+x)<=1. For every channel combination, positivity then yields the genuine integrated thermal window inequality

    0<=int_[r,Lambda] chi_AH(domega)/(pi omega)
            <=g_r M([r,Lambda])/hbar <=g_r M(R)/hbar,       (9)

in quadratic-form order, and the same with any PSD matrix probe after its trace. On a finite family of actual spatial weights, integrating k over a bounded chosen region gives the corresponding positive weighted Gram matrix of those weights. It does NOT collapse to one local variance or a Brillouin-zone/nu² factor without the source's translational/periodic/Poisson-summation hypotheses. All physical area, charge and normalization factors remain explicit.

The operator growth gives, for n>=0,

    M_A({|omega|>=R})<=R^(-2n)||delta^n A||²,
    int_[r,Lambda] chi_AH,AA(domega)/(pi omega)
        <=g_r a_A² [n! epsilon_A^n/r^n]²/hbar.             (10)

Here use A or its adjoint in (4) as appropriate; absolute-frequency weights are invariant under that reversal. The actual norm derivative may replace the upper majorant for a sharper bound. Choose n=floor[r/(exp(1)epsilon_A)] when positive to obtain an explicit exponential WEIGHT tail from n!<=n^n. This is not a pointwise spectrum or optimal CHHK coefficient. The independent zero atom is excluded by r>0, never erased. Comparing (9)/(10) with CHHK requires actual spatial/volume/transport matching below.

## 7. Exact graph f-sum, Peierls Hessian and storage Ward identities

For finite complex charge weights A_f, A_g of (3), CAR and [V,Q_i]=0 give an explicit microscopic first moment:

    omega([A_f†,[H,A_g]])
      =-q² sum_(bonds i<-j,sigma)
           (conj(f_i)-conj(f_j))(g_i-g_j)
           omega(h_ij c_i†c_j+conj(h_ij) c_j†c_i).              (11)

The two signs follow from [Q_f,c_i†c_j]=q(f_i-f_j)c_i†c_j and [H,Q_g] having the opposite difference. Onsite/background terms and V vanish from this double commutator, but the exact interacting state on its RHS remains; higher moments do contain V. No free-state evaluation or extra spin factor is introduced. For f=g the total expression is nonnegative by (8), not by asserting every complex-flux bond expectation has a favourable sign.

Put a real physical flux Phi_b on each oriented bond via h_ij exp(iq Phi_b/hbar), retaining the Hermitian conjugate. Direct differentiation gives I_b=-partial_Phi_b H, and T_bc=omega(partial²_Phi_b,Phi_c H), with T_bb=-q² omega(H_bond)/hbar² for independent bond fluxes. Phi has Wb=J/A units; T has A²/J. Scalar potential enters H_phi=+sum_i phi_i Q_i. Therefore sources in (7) are f_Q=-phi and f_I=Phi; the actual linear currents include their operator derivative:

    delta Q=chi_QI Phi-chi_QQ phi,
    delta I=(chi_II-T)Phi-chi_IQ phi,
    -iz chi_QQ=B chi_IQ,
    -iz chi_QI=B(chi_II-T).                               (12)

B is the actual oriented incidence/storage matrix for the chosen finite charges and ALL their boundary bonds. To prove (12), differentiate the retarded Q correlation and integrate by parts:
B chi_IZ=-(i/hbar)omega([Q,Z])-iz chi_QZ for a test operator Z. For Z=Q the equal-time commutator vanishes. For a bond current, -(i/hbar)omega([Q_i,I_b])=B_ib T_bb by the explicit two-mode CAR calculation. This is precisely the contact term required in (12). Dropping it violates storage/gauge covariance; it is not an optional noise delta.

The same exact local unitary gauge transformation U_theta=exp(i sum_i theta_i Q_i/hbar) gives Phi_(i<-j)->Phi_(i<-j)+theta_i-theta_j and phi_i->phi_i-dot(theta_i). Hence the bond electromotive voltage -dot(Phi_b)-(phi_i-phi_j) is invariant. Density interactions commute with the gauge and add no Peierls derivative for the FIXED static kernel. A driven dielectric/gate would add its own work/response. For phi=0, voltage=iz Phi and Y=(chi_II-T)/(iz), with dissipative real-frequency part pi K_II/(hbar omega)=[S^>_II-S^<_II]/(2hbar omega) when these measures have densities, agreeing with the complete interacting neutral FDT. The contact Hessian is absent from covariance of two undifferentiated currents but necessary in the response.

Differentiating the full ordered covariance gives -iomega M_QX=B M_IX and its adjoint second-channel relation, hence omega² M_QQ=B M_II B^T as a measure. At zero these constrain current/storage elastic blocks without discarding the charge elastic atom. No arbitrary continuum k factor replaces the incidence matrix, and no external circuit displacement current is included without construction.
## 8. A genuine positive thermal Hilbert space, including its nulls

Define the neutral Duhamel form by actual bounded KMS correlation, not an unbounded imaginary-time observable:

    D(A,B)=(1/beta)integral_0^beta du omega(A† alpha_(i hbar u)(B)),
    g(omega)=(1-exp(-b omega))/(b omega), g(0)=1,
    nu_ab(domega)=g(omega)M_ab(domega), C_ab=D(X_a,X_b).
                                                                  (13)

The imaginary expression in the first line means the analytic strip matrix element. In a finite box its coefficient between levels m,n is the logarithmic mean of p_m,p_n, a positive number; hence D is positive semidefinite. The inequality between logarithmic and arithmetic means gives D(A,A)<=[omega(A†A)+omega(AA†)]/2<=||A||². On the neutral algebra the chemical potential cancels in each matrix element but remains in the actual p_m and state. The actual local KMS limit passes both the bounded strip form and this inequality; this is also the spectral expression (13). Every g is strictly positive, so no nonzero ordered measure is lost by changing metric.

Factor EXACT zero-D vectors and complete, obtaining a positive Hilbert space H_D. Physical alpha acts unitarily, with a self-adjoint frequency generator L_D and U_D(t)=exp(itL_D). This is a representation of the actual positive correlation form, not an assumed classical stochastic ensemble. Null vectors are alpha-invariant; generator derivatives are well-defined on the quotient. For every local polynomial, the proven norm derivative/domain bounds and D<=norm give all L_D domains. In this convention L_D[A]=[delta A]/i. The adjoint operation J[A]=[A†] is an antiunitary involution on the neutral space, J L_D=-L_D J, by the logarithmic-mean eigenbasis formula and its limit. For Hermitian channels nu_ab(-domega)=nu_ba(domega), so C is real symmetric. A complex channel is retained by its full Hermitian pair.

Let R_ab(z)=<X_a,(z-L_D)^(-1)X_b>_D. Since K=b omega nu, the original response, not a newly chosen observable, is

    chi(z)=beta[C-z R(z)],
    C_D(t)=integral exp(-iomega t)nu(domega),
    chi^R(t)=-beta theta(t) d_t C_D(t),
    lim_(eta down 0) chi(i eta)=beta(C-E), E=nu({0})=M({0}).
                                                                  (14)

The last equality follows from dominated convergence of omega/(omega-i eta); the zero atom contributes zero. The isothermal static form beta C includes elastic redistribution and in general differs from this dynamical limit. A conserved fluctuation has C=E>0 and chi identically zero. No Gram null, elastic atom or physical channel is removed to make an inverse exist, and beta C is not yet an experimentally matched bulk compressibility.

## 9. Exact finite-channel projection and conserving memory

Take ANY finite list u_i of original local channel vectors, with all original zero/cross channels included. Its Gram matrix G=U†U, Uc=sum_i c_i u_i, is PSD. Define P=U G^+ U† on its actual range (Moore–Penrose inverse only on its positive finite spectrum), Q=1-P. This is the orthogonal projection even for dependent/null original channels; the channel-to-range map and its nulls remain recorded. A zero-D original channel has zero ordered spectral mass because g>0, not an artificially discarded signal.

Every u_i is in D(L_D). Thus T=Q L_D P is bounded and finite rank, M=P L_D P is Hermitian. Although L_D is unbounded, removing the bounded self-adjoint T+T† leaves a self-adjoint block-diagonal operator: P preserves its domain, its off-diagonal parts cancel on that domain, and both P and Q reduce its resolvent. Its Q part L_Q on Q D(L_D) is consequently self-adjoint. This proves the compression domain, rather than assuming every unbounded compression is self-adjoint. For Im z=eta>0, block elimination gives

    Sigma(z)=T†(z-L_Q)^(-1)T,
    P(z-L_D)^(-1)P=[zP-M-Sigma(z)]^(-1),
    Im Sigma(z)<=0, ||Sigma(z)||<=||T||²/eta,
    Im[zP-M-Sigma(z)]>=eta P.                            (15)

The inverse norm is at most1/eta. It exists on the full positive projection range for all UHP z, including conserved sectors; no real-axis inverse or z=0 cancellation is silently imposed. For any vectors its scalar imaginary part follows from Im(z-L_Q)^(-1)=-eta[(Re z-L_Q)²+eta²]^(-1). This also proves the matrix sign without an arbitrary relaxation rate.

The kernel K_mem(t)=T† exp(-itL_Q)T is a positive stationary matrix kernel (its full two-time quadratic form is a squared Hilbert norm), not pointwise entrywise positive in time. With the same Fourier sign as (7), Sigma(z)=-i integral_0^infinity exp(izt)K_mem(t)dt. Eliminating the Q component of the exact unitary evolution gives

    u'(t)=-i M u(t)-integral_0^t K_mem(t-s)u(s)ds,
    u(t)=P exp(-itL_D)P, u(0)=P.                          (16)

The sign follows directly from the two factors -i in the P-Q equations. The bounded kernel norm <=||T||² gives existence on every finite time interval by the Volterra series. It carries the full interacting force and every connected covariance; no free bubble, collision event noise or Markov assertion has been substituted. A nonstationary quench retains its two-time positive form in section4 and is not assigned this equilibrium unitary thermal metric by fiat.

## 10. Actual density/current chain, two-pole comparator and a computable residual

For ANY actual Hermitian finite weighted charge N, let C=D(N,N). If C=0 retain its null signal; if C>0 define v²=||L_D N||_D²/C. Its units are s^-2. If v=0, N is an invariant thermal vector, giving its elastic-only measure and chi=0. This is a necessary original control, not a reason to select a different observable. For C>0 and v>0 set

    e0=N/sqrt(C), e1=L_D e0/v,
    F=Q L_D e1=L_D e1-v e0,
    m(z)=<F,(z-L_Q)^(-1)F>_D,
    R_00(z)=(z-m(z))/[z(z-m(z))-v²],
    chi_N(z)=beta C v²/[v²-z²+z m(z)].                    (17)

Here P projects onto e0,e1. The even thermal scalar measure of a Hermitian N gives <e0,L_D e0>=0 and <e1,L_D e1>=0 (finite third moment); Q L_D e0=0. These facts produce the displayed2x2 block, not an assumed current equation. The actual first vector v e1=L_D N is proportional to the physical incidence/storage current (3), including contacts. F contains L_D² N and thus the actual interaction-current force. It is not a free phenomenological noise parameter.

J e0=e0, J e1=-e1, and J F=F; the complementary space is J invariant. Therefore F has an even positive spectral measure nu_F for L_Q. The exact normalized canonical density correlation obeys a''+v²a+integral_0^t k(t-s)a'(s)ds=0, a(0)=1, a'(0)=0, k(t)=<F,exp(-itL_Q)F>_D. Its transform is exactly (17), including any conserved/elastic component; that component is not recoverable by assuming m regular at zero.

For every fixed positive resolution eta0 (s^-1), not a selected favourable sample,

    m(i eta0)=-i r_eta0,
    r_eta0=eta0 integral nu_F(domega)/(eta0²+omega²)>=0,
    |m(z)-m(i eta0)|
                <=||F||² |z-i eta0|/[(Im z)eta0].         (18)

This is an ACTUAL state/force functional and exact resolvent-identity bound for the whole fixed carrier. It is strictly positive iff F has nonzero Hilbert norm. F=0 is the undamped finite-rank chain control and must remain in the population. No positive coercivity or small residual is asserted for every charge weight/parameter. At nonzero physical wavenumber k, WHEN r_eta0>0 define the finite-channel comparison numbers tau_eta0=1/r_eta0 and D_eff(k,eta0)=v(k)²/[r_eta0 k²]. These have s and m²/s units, respectively; their actual positive norm/force formulas replace all-ones normalization. They are not automatically independent of k, resolution, patch weights, contacts or volume, and therefore are not yet the requested bulk diffusion/relaxation coefficients.

Putting the comparator m0=-ir, r>0, gives

    chi_0(z)=chi_stat v0²/[v0²-z²-ir z]
       =chi_stat D k²/[D k²-tau z²-iz],
    tau=1/r, v0²=D k²/tau,
    Im chi_0(omega)=chi_stat D k² omega/
                    [omega²+(D k²-tau omega²)²].          (19)

For the exact finite-channel comparator use chi_stat=beta C and v0=v, r=r_eta0; for a physical bulk approximation supply separately justified matching errors, not a fit masquerading as derivation. Both poles (-ir plus/minus sqrt(4v0²-r²))/2 are in the lower half-plane for v0²,r>0. The zero-v limit has a conserved cancellation and cannot be interpreted by dividing by v. At r=0 the exact upper-plane prescription retains undamped real spectral atoms, not a regular dissipative curve. A complex Fourier channel with coupled cosine/sine sectors uses the full matrix (15); no time-reversal, inversion or scalar diagonalization has been presumed.

For D0=v0²-z²-ir0 z, DeltaD=(v²-v0²)+z[m(z)+ir0], numerator B=beta C v² and target B0=chi_stat v0², if |DeltaD|<=theta|D0| with theta<1, direct subtraction yields

    |chi_N(z)-chi_0(z)|
      <=|B-B0|/[(1-theta)|D0|]
               +|B0||DeltaD|/[(1-theta)|D0|²].            (20)

Thus there is an explicit finite-resolution, finite-window acceptance budget from actual forces, moments and matching errors. For identical C,v and r_eta0 use (18) to bound |DeltaD| by |z| times its residual. It may be large; no nonempty useful band or real-axis flatness is invented. On a window z=omega+i eta, a bounded test psi gives response error <=||psi||_1 sup_window RHS(20), with its complement separately budgeted. Letting eta vanish without a uniform force/limiting-absorption estimate is forbidden. Such a response bound alone does NOT control an inverse-noise reconstruction through a singular zero-frequency Bose factor: actual weighted-measure error and elastic E need their own bounds.

The exact m(z) decays as ||F||²/z at high imaginary frequency by its finite mass. A constant -ir cannot be its exact all-frequency value when r>0. Moreover the exact Hermitian-channel commutator moments force the odd/even expansion of section6; an all-frequency white-memory replacement generally changes higher sum rules. This proves why (19) is a windowed controlled comparator rather than an exact global microscopic theorem.

## 11. Controlled finite-time, contact-volume and probe comparisons

Here are actual approximation errors, not a claim that the original graph has been run. For a fixed local polynomial A of degree at most d with coefficient absolute sum c_A, the inherited orbital path-tail epsilon_U(T,L) and full cocycle telescope give, uniformly |t|<=T,

    ||alpha_L^t(A)-alpha^t(A)||
      <=eta_A(T,L):=c_A epsilon_U(T,L)
                        [d+8|lambda|w T/hbar].           (21)

Explicitly, if all hopping paths of lengths below ell from the support of A AND V fit within the box, x=||h||_bound T/hbar gives epsilon_U(T,L)<=2exp(x)x^ell/ell!: the common Taylor terms cancel and each of the two orbital remainders is bounded by exp(x)x^ell/ell!. This is the original full growth/r3 path-tail with the boundary measured from the support of A AND V; this is not permission to omit a contact. This error tends to zero for fixed T as the contacts grow. Let eta_state(S,L) be the actual local-state norm error on a finite set S. It is explicitly furnished by r3(28)–(31): with M_imag=beta w exp(4kappa beta), a=|lambda|M_imag, e_N=exp(kappa beta)(kappa beta)^(N+1)/(N+1)!, delta_Y=exp(a)a^(K+1)/(K+1)!+4|lambda|beta w exp(3kappa beta)e_N exp(2a), eta_R<=beta kappa/(2sqrt(q_poly)), and C_s=4^s 4s(2s-1)!!, use

    B_err=2delta_Y(2exp(a)+delta_Y)
                         +C_s eta_R(exp(a)+delta_Y)^2,
    eta_state(S,L)<=min[2, 2exp(beta|lambda|w) B_err].      (22)

Here s>=1 counts the finite enlarged spin-orbital set S_N (the scalar empty algebra has zero state difference); q_poly is a polynomial degree, NOT physical charge or wavevector. All boxes must contain the specified Taylor/polynomial path neighbourhoods. This enormous but explicit bound is for fixed beta, mu, local set, not a material numerical rate. When an evolved A is not local, first cut its dynamics into a common finite S, use (21), then (22); do not apply a local-state bound directly to an uncut quasi-local element.

If a=||A||, b0=||B|| and eta_A,eta_B bound two dynamics replacements, ordered-product difference is at most b0 eta_A+a eta_B+ab0 eta_state on that common cut algebra. The centered covariance difference is consequently bounded by

    2(b0 eta_A+a eta_B)+3ab0 eta_state.                   (23)

The mean subtraction accounts for the extra terms, so this is not merely a bound on raw products. Double time filters multiply its uniform bound by ||f||_1||g||_1. The exact two-time formula (23) also applies to the same retained nonstationary quench states if their actual initial state restriction error is supplied; it gives no equilibrium identity for them.

For the retarded response at Im z=eta>0 split at a finite T. Let epsilon_comm(t,L) be the genuine expectation difference of the two commutators, bounded by the same two product telescopes and state/cut errors above. Then

    |chi_ab(z)-chi_ab,L(z)|
      <=(1/hbar)integral_0^T e^(-eta t)epsilon_comm(t,L)dt
                           +4a_a a_b e^(-eta T)/(hbar eta).
                                                                  (24)

This is a constructive controlled infinite-contact UHP response: choose T first for the tail then L/local approximations for the compact integral. No real-axis/long-time interchange or hidden finite-only model has been used. Actual first finite moments are local nested commutators; make their full finite supports fit before comparing their states. Uniform higher moment bounds give tightness and passage of any lower moment by tail splitting.

For the D form, smear a neutral B by the same real Gaussian of width epsilon seconds, B_epsilon=(sqrt(pi)epsilon)^(-1)integral exp(-t²/epsilon²)alpha_t(B)dt. Norm differentiation and the exact Gaussian first absolute moment give ||B-B_epsilon||<=epsilon||delta B||/sqrt(pi). The combined infinite/finite D replacement error is <=2||A||epsilon||delta B||/sqrt(pi), using the uniform derivative norm. At FIXED epsilon, r3(31b) gives the explicit compact strip bound exp(Y²/epsilon²)[delta_B,L(R)+2||B||eta_epsilon(T,R)] with eta_epsilon(T,R)<=epsilon exp(-(R-T)²/epsilon²)/[sqrt(pi)(R-T)], together with the state estimate (22) on a local cut. Integrate that actual correlation error over u in[0,beta] and divide by beta to compare (13). Choose epsilon for the first error, R for the Gaussian tail, and L for the remaining finite support/dynamics/state errors. Never take epsilon to zero in the divergent strip prefactor. This proves actual D/Gram/moment convergence by an ordered construction.

An inverse Gram, v ratio or r reciprocal is continuous only on a measured positive spectral/gap lower bound; near nulls use the full channel map and absolute form errors instead. Also weak convergence of M_L does NOT imply E_L=M_L({0}) converges to E: arbitrarily near-zero atoms may accumulate at zero. The true invariant projection (6), or separate uniform near-zero-mass bounds, is required. A matched ordered-noise window similarly requires bounded continuous spectral tests plus explicit tail and zero-atom control; response closeness (20) cannot replace those requirements. These are mathematical stability boundaries, not deferrals of the original noise objective.

## 12. Actual source formula and definitions: what has and has not been matched

Personally read primary CHHK v2 https://arxiv.org/html/2509.18255v2, sections2–3 Eq1–6, section6 Eq17 and Methods7.1–7.2 Eq22–31, and v1 https://arxiv.org/html/2509.18255v1 sections2–3 Eq12–19. Its v1 Eq15/v2 Eq4 has the denominator omega²+(Dk²-tau omega²)², the physically stable comparator (19). Its positive-frequency thermal integrated argument uses a translational spatial local correlator, not every finite weighted patch observable. The source energy convention sets hbar=1; here beta is J^-1, omega s^-1, k m^-1, D m²/s, tau s, with b=beta hbar and the stated charge/area normalizations. Physical chi must have the units of the measured source/conjugate observable. A normalized inequality cannot supply these factors.

The nine actual bound N DKMBootstrap modules were read directly before proof: Predicates, AxiomSet, KMSConsistency, NoCrossing, SDPStructure, LDPBridge, SKEFTSpecialization, E1E2CrossBridge, HorizonTransportBootstrap. The following incoming failures are independently corroborated by those definitions but are NOT counted as this construction or native repair:

* Predicates.dkmImGRetarded instead has omega²(1-tau omega²)²+(Dk²)². At positive all-ones parameters, omega=2,k=1 it returns2/37, whereas the actual source comparator returns2/13. This is an exact manual rational counterexample, not a computation/test run. Its dimensions also differ unless unrelated quantities are silently normalized. F1 universal equality to that formula has not been built by (19).
* Literal F4 says G>=0 on ALL real frequencies; F6 says same-k odd. Together they force G=0. F1 at omega=-1,k=1 and positive parameters is strictly negative, contradicting F4. An equilibrium scalar commutator is signed; a positive ordered matrix measure/positive-frequency absorption has a different domain. Merely renaming F4 cannot repair this bundle.
* F5 is existence of a real value equal to the already supplied real G(alpha,k), not UHP holomorphy; (7)/(15) construct actual complex analytic functions instead. F2 is a supplied pointwise G/omega bound, not the integrated microscopic equalities and inequalities (8)–(10).
* AxiomSet assumes implication fields supplying positivity/analyticity/PT from named predicates; KMSConsistency consumes the supplied positivity implication without its KMS argument. NoCrossing repackages a conjunction, SDPStructure's analytic label names that bundle and its candidate set is True. These are not actual KMS/Lehmann/current constructions.
* LDPBridge chooses sigma²=chi D, with no constructed collision/noise rate or large-deviation process. E1E2CrossBridge owns the platform string classifier and three all-ones records; its normalized MIR and HorizonTransportBootstrap's inclusive OR remain conditional algebra, not exclusive physical classifications. The established factorial-growth and normalized real inequalities are not denied or rewritten.

The current MODEL/measure/response/growth/finite-channel memory supplies actual ingredients for an honestly redefined spectral theorem. It does NOT inhabit the inconsistent literal F1–F6 bundle, establish an actual LDP, prove a polariton pump-to-commutator law, or derive a BEC Hamiltonian. Those require distinct coherent original-strength scientific/native tasks, not a false completion theorem.

For the same original E2 device DKM objective, exact finite-channel C,v,F,r_eta have been constructed as real state/Hamiltonian functionals with units and all zero domains. To obtain bulk chi,D,tau, the following load-bearing limits remain to BUILD, in this order:

1. Establish actual bilayer/Wannier/exchange/dynamical screening/gate and contact residuals relative to the fixed rigid-sphere finite-patch Hamiltonian; do not call it an exact material Coulomb projection. For increasing central area, prove uniform incident interaction/growth constants rather than extrapolate this finite-central U bound to an unscreened plane.
2. Specify actual spatial observation cells, electrochemical source normalization, stationarity/incoming state and the large-area/lead/low-k order of limits. Derive the density/static Duhamel response per area and separately its invariant/elastic component. Finite patch weights and finite-region k=0 storage cannot supply translational Poisson-summation factors or thermodynamic susceptibility.
3. Calculate/bound the genuine interacting current-force spectral memory for the full retained density/current block, including cross/Hall sectors, boundary contacts and any extra slow/conserved variables. Prove the required kinetic/hydrodynamic scale separation, force decay/integrability and controlled low-k/finite-frequency plateau, or record the actual failed construction. No exponential decay, coercivity or scalar relaxation follows from locality alone.
4. Use those bounds to match chi_stat, D and tau (with uncertainty) and verify (20), the independent elastic/inelastic ordered-noise test bounds and source cutoff conditions1/tau below the frequency cutoff and1/sqrt(D tau) below the inverse-length cutoff. A nonempty useful window requires the actual errors small there; no such inequality is claimed here.
5. Carry that physical local response through the actual nozzle/horizon/scattering/input state, leads/ports, contact displacement and receiver transfer, environmental noise, physical calibration and an identifiable measured observable/detection band. Independent microscopic Landauer/Keldysh agreement, realistic material noise and the original first-principles charter remain owed.

These are viable, explicitly decomposed next constructions, not infeasibility claims or operator-approved scope reductions. This accepted assignment owns the substrate/next-step exposition through nonauthor review; acceptance of the remaining scientific handoffs must be recorded by the existing lead assignment system, not invented as completed private work. All21 criteria/B1–B8/D12, the full publication roadmap, and the distinct E1 polariton and BEC commitments remain unchanged.

## 13. Full manual controls and genuine future validation boundary

The following controls use the original family, actual operators or its original finite-box approximants; none replaces the target model.

* SIGN/SOURCE: faithful finite interacting Gibbs plus a nonzero actual local charge-hopping commutator yields a nonzero transition and positive-frequency absorptive weight; the negative-frequency adjoint partner reverses its sign. If a chosen channel has zero weight, retain it as a zero control. Change H'=-fX to+fX and the whole response sign flips. An all-real-frequency nonnegative odd nonzero curve is impossible.
* MATRIX/ADJOINT: for a charge Q and its actual total inflow J=delta Q, a positive transition weight w contributes w[[1,iomega],[-iomega,omega²]] to M_(Q,J), PSD rank1. Its cross entry is imaginary, not a positive real scalar. For actual A_k, the negative-frequency measure of the pair(A_k,A_k†) is matched to the positive-frequency adjoint pair(A_-k,A_-k†) as in(5), with no unproved same-k inversion. The full graph/contact storage J, not an isolated two-site substitute, is used.
* MU/STATE: the exact charged grade-r factor contains mu r, while every measured neutral channel has beta hbar omega. Arbitrary nonzero mu is retained. The full interacting finite Gibbs check is trace cyclicity, not free-state Wick factorization. A general quench has positive filtered two-time covariance yet no stationary KMS/FDT. The original stationary vacuum Gaussian countercontrol at nonzero lambda remains; a dynamical vertex is not a universal instantaneous nonGaussianity theorem.
* ELASTIC/NULL: total N_L in each original full interacting box has positive centered elastic variance and zero response. Infinite bounded local q=0 channels retain their boundary currents and exact invariant projection; no fictitious infinite total N observable is introduced. Dependent original Gram channels, C=0, v=0 and F=0 are processed in their exact domains, not skipped to obtain positive relaxation.
* INTERACTION/WARD: the U_ii contact transition in section2 gives a nonzero [V,I] matrix element at the original physical coupling. Full ordered/retarded correlators include all connected spin/cross terms. Deleting T from(12) breaks its explicit equal-time CAR contact term. Charge-source sign, Wb flux, hbar and angular-vs-Hz factors are fixed, so their common poison factors are testable. Storage cuts must include all crossing bonds.
* MOMENT/MEMORY: delta-domain/factorial bounds derive every integrated moment and signed first sum rule. Odd/even scalar moments rule out a globally exact positive white-memory rate; the exact memory has nonpositive UHP imaginary part and a positive two-time kernel, including zero and undamped sectors. The telegraph poles are stable only in the stated positive domain; no useful real-axis band follows without the actual residual tests and independent elastic bounds.

Required NEXT actual SOURCE/NATIVE/REFERENCE work is DATA, UNRUN: formalize the original graph CAR/current/gauge derivations and positive infinite-state limit with all units, the GNS/Duhamel Borel measures and separate invariant projection, signed KMS/UHP/current sum rules, the domain-correct Gram projection/memory and the finite-window error theorem. Preserve every original parameter/state/channel, zero case and complex adjoint pair. Replace contradictory placeholder predicates only in a coherent ROOT-allocated definition/theorem/consumer migration; do not add a lexical checker and count it as physical proof. No production declaration was changed here.

The independent numerical reference should use genuinely distinct routes: finite full-CAR Jordan–Wigner matrices with exact interacting Lehmann spectral sums versus real-time source/Peierls derivatives and the previously independent interacting contour/current expansion, with explicitly bounded finite-volume/time/approximation errors. It must retain all original hopping/U/contact/mu/beta/state populations, use positivity and all integrated moments, zero-inclusive probe covariance, storage/Hessian and full ordered cross-noise controls, then compare the exact projected resolvent to its force-memory calculation. A finite-box result is a bounded reference, not the infinite device's acceptance. No recipe, imported matrix package or numerical model has been executed by this manual task.

Mandatory future real poisons include wrong retarded/source sign, negative-frequency clipping, same-k oddness without partner, lost mu twist, omitted elastic atom, doubled spin/Hz factor, wrong denominator, missing boundary/contact Hessian, free-bubble vertex omission, arbitrary Gram inverse, dropped null channel, changed population and an unjustified constant memory. Each needs the actual targeted red result, a byte+nanosecond-mtime mutation journal, exact restoration, original-control green, and the full original unfiltered suite/native/independent review; string checks or authored test counts are insufficient. ROOT owns all actual execution/admission/main coordination. G4/G5/G11, runtime/native/publication/main remain open, and this manual author completion is not independent acceptance.

<!-- END SOURCE137-EXACT-E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE-CONSTRUCTION -->

<!-- BEGIN SOURCE137-EXACT-E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE-REPORT -->
# Same interacting CAR retarded/spectral/memory scientific AUTHOR handback

AUTHOR construction complete for fresh genuinely nonauthor WHOLE scientific review; no independent acceptance, publication closure or actual execution is asserted. Original E1:2.3/Phase6q3.3–3.4–5.2/D5 focused1.1 and the full E2 device objective remain BUILD. The incoming literal predicate contradictions were not repaired in production.

## Scientific result and its boundaries

CONSTRUCTION.md has thirteen coherent sections and24 equation groups on the SAME nonzero interacting E2r3 AB/static-gate/spin2/semi-infinite-contact CAR family. All original hoppings/U, physical geometry, arbitrary finite beta/real mu, charged sectors, quench/correlated states, finite spatial weights and actual charge/current channels remain. This is not a free/finite-only/mu0 or favourable-state replacement.

The new construction derives actual positive matrix spectral Borel measures and full-unit KMS detailed balance, signed absorptive measures with the correct adjoint momentum pairing, and the independent elastic atom/zero-inclusive filter covariance. It derives a genuinely holomorphic causal UHP response from the physical source sign, exact integrated microscopic commutator moments, a thermal window inequality/operator-growth spectral-weight tail, and the graph f-sum/contact Hessian/storage Ward identities. It retains full interacting forces/cross noise/vertices rather than a dressed free bubble. The existing positive infinite interacting KMS-state proof is reused at exact accepted historical bindings, with physical H versus H-mu N and charged twist preserved.

The actual positive Duhamel Hilbert construction includes null/elastic sectors and a domain-correct exact Gram projection, self-adjoint complementary compression, signed resolvent and Volterra memory. For each actual Hermitian density channel it derives C,v,F and the force-defined r_eta, including C=0/v=0/F=0 cases. The correct stable two-pole comparator and its explicit residual bound follow. These finite-channel quantities are genuine state/Hamiltonian functionals; they are not yet bulk chi,D,tau. The error may be large. Exact all-frequency constant positive memory is ruled out by its resolvent asymptotics/moments; no useful physical window has been silently assumed.

Finite time/lead-volume/state/Gaussian-strip/probe errors and Gram/zero-atom stability limits are explicit. Sections12–13 preserve the source/native/reference work and real poison/restoration controls. The actual material/Wannier/exchange/dynamical screening/contact, uniform large-area/growth and translational normalization, kinetic/hydrodynamic memory-flatness, low-k/static/elastic limits, independent physical route, horizon/scattering/state, receiver/calibration and identifiable nonempty useful band remain constructive obligations. Distinct E1 polariton/BEC and all21/B1–B8/D12 duties remain. No deferral, infeasibility decision or weakened charter is requested.

## Chronology, depth and exact inputs

Original packet64bf8b37 FIRST ran exactly once from N at14:29:04.906703–14:29:05.172996 UTC, rc0, fresh true, separate stdout/stderr retained. Full initial protection14:29:59.139570–14:30:00.648609 captured37 bound references, P/N/M tracked plus ALL known dirty/untracked source bytes/fullstats, raw-index bytes separately from semantic stages, actual HEAD/status/refs and bounded admin/pointers; seven owned outputs were absent.

The fixed full SOURCE_MODEL was saved14:30:20.054102–14:30:20.054595 UTC, SHA dca1bfb166485255db4588d193b2435ace3b049261c40e3ad4c96ff2cccb6779, BEFORE new mathematics. It encloses the exact entire original r3 MODEL72df7302 and growth MODEL5f9584a6; both remain immutable. Full direct nine-module dependency definitions and carrying r3/growth constructions, models, full genuinely nonauthor reviews and lead decisions were personally read before proof reasoning. The14:33:38 read-completion/progress field is NOT an exact mental-start bound: small measure-orientation scratch followed the completed carrying reads/model and preceded that marker. That precision is retained; no timing is backdated.

Full actual r3 construction b7e396fb6bd530ad692d2b59f417721d6806a80217b1c6304fa1046324f33406/review25114f3678c1a8cafee69eb995c50f42df0561cf7dc8f9cd5ebb371243014a7f/lead76747f67 and growth construction4d6ee9064a276f7d88bd07da857c94043dabe87d17ab89b0ed4f188425a7787f/reviewe8d051d531fb7b540db80379a21c0ae1fadbcf4ddba417ef7cc1ac91134e2728/leade2c8a284 are exact historical scientific dependencies, not a new self-review. Their original pre-MODEL/definition-read-first failures remain unwaived. All new derivation was manual after the fixed MODEL/current carrying reads.

Primary CHHK v2 sections2–3/6 and Methods7.1–7.2 carrying Eq1–6/17/22–31 and v1 sections2–3 Eq12–19 were personally read through official arXiv HTML, with URLs/depth in the construction. No full text was saved/admitted. The older exact r68 body was familiar at its pinned hash; the actual new r69 authority/top and update were read, with dated ROOT/main/gate distinctions preserved. Clipped combined dependency displays were recovered by bounded contiguous carrying reads; no unseen payload is credited. Final actual thirteen-section construction was read back in full bounded groups, with carrying growth/state-error constants separately checked. This is author verification only.

An early author draft wrote ReY=K_II/(2hbar omega); it was corrected BEFORE final to pi K_II/(hbar omega)=(Sgreater-Sless)/(2hbar omega), because K is the Borel measure and S=2pi M. The exact failed expression and draft hashes are retained in evidence/tool history. Elastic-probe null cases, transform conjugations, incident J_E/path tails, imaginary-time state constant and geometric remainder were made explicit on readback. These are manual draft repairs, not executed tests or retroactive source acceptance.

## Actual status/protection and next acceptance

Initial observed heads were P d329a0a738ff20fefd3827cc2ef0d4a091e36219, N d164ebf77208bdfd690cd73ded4e9f81a85409d8, M3fdd3f0960ba30ba95fadf959d9bef3a300fdaf0; initial tracked rosters5186/4869/4906 and known dirty/untracked rosters7/64/3 were captured, not reset. ROOT r384/frontier descriptions and the goal badge do not confer a publication runtime lease. The dated main39 failed tests/CI84-of85 floor failure/CI_SKIP failures remain; separate Lean10834 and isolated NJL200 receipts do not close them. Literal VerifyFAIL4, ADW application/runtime, native/publication/fullG4/G5/G11 and main remain open. The unanswered15-path execution-ownership question grants nothing.

Only the seven allocated ignored leaves were written. No source/Git/index/ref/holding/registry/book/ledger/notebook/native/controller/build/runtime mutation, project/helper/model/mathsoftware/test import/evaluation/collection/execution, source recipe execution, external communication or delegation occurred. Read-only Git, stdlib text/hash/JSON/stat and primary WEB reads were used. The required native/reference/poison plan is DATA UNRUN.

The complete construction, MODEL, this REPORT and evidence/process are written before the ONE original final check. Its literal result and actual post-check full source/ref/admin/raw+semantic/HEAD/status recapture will be appended below with unknown-actor changes preserved, without refreshing/rebaselining. Fresh genuinely nonauthor whole scientific review must assess every proof, domain and physical limit and the recorded process boundaries; lead intake follows. This author does not record a canonical finding closure or scientific acceptance.

## Actual original final and terminal freeze

ONE original final ran14:53:44.093240–14:53:44.393754 UTC, rc1, fresh false, changed=[owned-files], stderr empty. Its reconciliation-required wording is preserved literally in final-check.json; no refresh/retry or interpretation as independent acceptance occurred. The author-created ignored leaves account for the adapter ownership change; the fuller terminal protection comparison remains separately authoritative for actual Git/admin movements.

Actual terminal protection14:54:38.097442–14:54:39.435748 UTC found all37 bound reference fullstates and packet unchanged; ALL original P5186/N4869/M4906 tracked plus known7/64/3 source fullstates/bytes/modes unchanged, no new observed source paths. All three raw indexes including bytes and fullstats match exactly; semantic stages, HEADs, tracked rosters and both status streams also match exactly. Every actual read-only Git command returned0.

Shared show-ref streams differ in all three repositories: refs/heads/worktree-wt1 d329a0a738ff20fefd3827cc2ef0d4a091e36219 -> 5e491ce416008f2d26a3dc10329ce7c000a8b088. The bounded administrative comparison records P3/N4/M3 fullstat changes: common.git directory, refs/heads directory, changed worktree-wt1 ref file, plus N's worktree gitdir timestamp. P's .git directory fullstat also makes its pointer field unequal; no .git pointer-file rewrite is claimed. Actor/cause/integration acceptance UNKNOWN. These movements are preserved against the ORIGINAL baseline, not reset, absorbed as a new favourable baseline or called complete administrative preservation. Serial snapshots do not establish global quiescence.

Scientific MODEL/CONSTRUCTION are now frozen; author completion awaits genuinely nonauthor whole review. No physical/native/publication/gate/main closure follows from this handback.

<!-- END SOURCE137-EXACT-E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE-REPORT -->
