# Original L1 finite spatial normalization — source-model

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** Full original signed action/Haar/Berezin two-site control, D=3366=2922+0+444, coupled nonzero-separation insertion, source-dependent Z and explicit domains/errors, arbitrary coupling cancellations. All coefficients retained exactly.

**Original physical obligations.** No physical zero-source/vacuum susceptibility, full tensor/multiplicity/source/volume/operator/coupling matching or derived [0.1,10] window. Full arbitrary-volume original family remains the target; modes/matter and physical transport are distinct.

The construction author is publication_main55_independent_review; the complete independent scientific review is by publication_njl_target_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION](../L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md), [fixed source model](../source-models/L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md), [full independent review](../reviews/L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION-SOURCE_MODEL -->
Actual MODEL save UTC: 2026-10-18T14:55:19.725781+00:00

# Fixed original physical family BEFORE new mathematics

This SOURCE_MODEL is saved prospectively at the actual timestamp below, after fresh FIRST/protection and reading existing model definitions, before any new mathematical scratch, coefficient selection or derivation. Reading/scoping existing accepted results is not represented as a new proof. Full five notes/reviews and inventory still must be completely read before new derivation. No parameter, eigenchannel, physical normalization or physical window is selected to fit an answer.

## Original microscopic family and orders

For every positive integer four-tuple L, use the finite four-dimensional hypercubic torus Λ=product Z/L_mu Z with V=product L_mu, spacing a>0 and physical regulator volume V a^4. Fix real periodic fermion boundary conditions in all four directions for the constructions here. Every x has four independent unbarred ψ_xI and four independent barred generators, I=1,...,4. Fix source Berezin orientation with the sitewise ordered top monomial bar1 bar2 bar3 bar4 ψ1 ψ2 ψ3 ψ4 integrating to1, and lexicographic site order. The original complex Dirac generators are not replaced by a real Majorana/Pfaffian assumption.

Each positively indexed link has an independent compact Ω_(x,μ)=diag(U_L,U_R), both factors independently normalized SU(2) Haar; independent links exist even for coincident neighbors. Fix the actual carrying-note gamma basis

γ_j=[[0,−iσ_j],[iσ_j,0]], j=1,2,3;
γ_4=[[0,I],[I,0]], γ_5=diag(I,−I), ε_1234=+1.

Retain T=a ehat, with all four blocks ADDED exactly, including small-torus coincidences:

T_(x,μ,A)=1/4[barψ_x γ_A Ω_(x,μ)† ψ_(x+μ)
 −barψ_(x+μ) Ω_(x,μ) γ_A ψ_x
 −barψ_x γ_A Ω_(x−μ,μ) ψ_(x−μ)
 +barψ_(x−μ) Ω_(x−μ,μ)† γ_A ψ_x].

Retain the ordered plaquette of the original source/carrying action, with left-to-right matrix multiplication:

Ω_(x,κλ)=Ω_(x,κ) Ω_(x+κ,λ) Ω_(x+λ,κ)† Ω_(x,λ)†.

Do not commute gamma/link factors or substitute another transport/plaquette orientation during a calculation. The full gauge/source interpretation must be checked with these fixed conventions; no extended-lattice gauge-invariance or continuum conclusion is assumed here. The one-site reduction of this order is the original plaquette commutator. Official primary HTML was read for the actual displayed orders before this save; no PDF-version identity or full-paper proof-depth claim is made.

The full selected original action is S=g1 sum_x S4_x + g2 sum_x S2_x, arbitrary finite g1,g2 (complex algebraic family, with real-coupling physical slice requiring its own domain). In exactly the carrying normalization,

S4_x=ε_ABCD T_(x,1,A) T_(x,2,B) T_(x,3,C) T_(x,4,D),
S2_x=(1/4) sum_(κ,λ,μ,ν,C,D) ε^(κλμν)
 Tr[Ω_(x,κλ) γ_C γ_D γ_5] T_(x,μ,C) T_(x,ν,D).

The exponent is +S. Neither interaction is deleted or treated as a quadratic/free scalar action. No extra mass, kinetic term, positive Gaussian measure or source-paper ellipsis interaction is inserted. a^4/a^2 cancellation under T=a ehat is the inherited convention; physical field normalization is not inferred from it.

## Actual observables and sources

Use all16V original T coordinates with dimensionless independent J_xμA, plus the invariant-candidate local symmetric metric composite G_xμν=sum_A T_xμA T_xνA for all ten independent μ≤ν pairs per site. Couple +sum J T +sum_x,μ≤ν H_xμν G_xμν in Z(J,H)=integral Haar/Berezin exp(S+sources). Every off-diagonal H pair is counted ONCE; a full symmetric K representation has K_μμ=H_μμ and K_μν=H_μν/2 for μ<ν. This is a coordinate convention, not a physical spin-2 projection.

Keep the entire joint26V-coordinate response, source order and any singular directions. G is built from original T and is not auxiliary h. Preserve the exact signed/possibly complex Hermite weight W, with arbitrary representation variance σ²>0, whenever auxiliary variables are used: W does not shift with sources and is not discarded or replaced by a positive density. Normalization uses actual Z and must be refused on its zero set. No positive physical probability measure, nonzero source-free metric background or Lorentzian dynamics is postulated.

## Prospectively fixed finite spatial construction and full target

The primary new finite control is Λ*=Z/2 Z × Z/1 Z × Z/1 Z × Z/1 Z, with sites0 and e1, periodic boundary conditions as above, independent Ω_(x,μ) at BOTH sites and the ENTIRE action for arbitrary g1,g2. It is an extended coupled two-site torus, not two uncoupled copies of the one-site model. All forward/backward and other-direction coincident blocks and all plaquettes are retained before any simplification. Any geometry/center/saturation cancellation must be proved for this fixed geometry, not imported from V=1. No coefficient, nonzero Z, sign or physical usefulness is assumed. The full arbitrary-L family remains the scientific target; this finite control does not replace it or prove a volume approximation. The previously accepted V=1 model remains an exact control, not new progress.

New work must actually evaluate a nonzero-separation coupled spatial metric coefficient/response and normalization/domain for this same family beyond a formal coefficient algorithm, then construct the physical tensor/source/units/spacing/volume/cutoff/field-normalization/numerator/multiplicity/subtraction bridge. Actual g1/g2-to-L1 u_g/c_D/γ_star matching or a precise demonstrated mismatch is required; no equality is chosen. The dimensionless physical χ_vest window[0.1,10] remains a derived RESULT to establish on a justified domain with errors; χ=1, a coordinate eigenvalue, M/(96g2²), a scalar bubble or a selected eigenchannel cannot replace it.

Retain the old zero-mean G, rank-ten joint26 one-site response, nonzero-tetrad-source witness versus physical vacuum distinction, source-order/gauge/Hessian/pole limitations and near-instability/refusal conditions. Full ADW ordered phase/background/full constrained fluctuations/Lorentzian/continuum/graviton and independent magnitude remain BUILD. All THREE distinct L1 duties (B3 susceptibility/window; physical tensor dynamics; physical transport/frequency matching), the shared D1/E1/E2 dispersive law and all21/B1–B8/D12 objectives remain. Missing results require continued substantive work and, if computation is needed, a concrete DATA UNRUN error/precision/poison/exact-restore plan, not infeasibility, deferral, a changed target or invented execution authority.

Only assigned seven ignored leaves may be written. No mathematical/coefficient engine, project/helper/model import/evaluation, tests/build/native/controller/source/Git/holding/registry/book/closure mutation or delegation. Fresh genuinely nonauthor whole SCIENCE review is required after author freeze; author cannot self-accept or close any finding.


<!-- END SOURCE137-EXACT-L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION-SOURCE_MODEL -->
