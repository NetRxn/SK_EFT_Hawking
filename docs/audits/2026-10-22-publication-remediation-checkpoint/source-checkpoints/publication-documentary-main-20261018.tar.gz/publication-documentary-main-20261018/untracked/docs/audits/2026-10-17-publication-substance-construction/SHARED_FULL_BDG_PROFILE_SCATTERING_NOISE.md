# Reviewed-source delivery: CONSTRUCTION — SHARED_FULL_BDG_PROFILE_SCATTERING_NOISE

This is the COMPLETE original construction, transported as documentary SOURCE DATA. Scope: PARTIAL manual GP/BdG milestone: exact scattering/band states/finite-time field; small leading-Hawking remainder and stationary whole-field completeness/state still BUILD. Lead intake bedf71db accepts that exact scientific scope, not physical/device/native/gate/main completion. Original author-pending statements describe their dated author snapshot and remain unchanged. Full [construction](SHARED_FULL_BDG_PROFILE_SCATTERING_NOISE.md), [independent review](reviews/SHARED_FULL_BDG_PROFILE_SCATTERING_NOISE.md) and [fixed source/model](source-models/SHARED_FULL_BDG_PROFILE_SCATTERING_NOISE.md) are delivered together. All original process failures, chronology, mandatory historical rejections and remaining physical BUILD obligations are retained. No mathematics or review verdict is shortened or changed. No runtime/native/application/publication acceptance follows.

<!-- BEGIN COMPLETE ORIGINAL CONSTRUCTION -->

# Fixed-profile continuum GP/BdG scattering and quantum-noise construction

AUTHOR CONSTRUCTION, MANUAL, NOT INDEPENDENTLY ACCEPTED. This extends the reviewed chiral result to the fixed physical Bose-gas family in SOURCE_MODEL.md. All parameters remain symbolic: m,rho0,L>0 and 0<c_l<v0<c_r. No favorable numerical example is selected. The stationary whole-field scattering-completeness bridge and the full physical D1/E1/E2 task remain BUILD; no gate, native/runtime, source-application or publication acceptance is asserted.

## 1. Model chronology, primary depth, and physical stationary GP background

SOURCE_MODEL.md was saved at 2026-10-18T11:43:52.046206+00:00 with SHA256 23d73a45ad9eee2102a8f4c646342a04cb4a63ed3e14241403aed45e44e82759. New mathematics began at 2026-10-18T11:46:50.791691+00:00, after personally reading the carrying primary body I–V and Appendices A–C. The lead's earlier prospective planning remains disclosed as planning, not proof or retroactive model-first credit. No parameter/model choice was fitted after a result.

The carrying primary is [Coutant–Weinfurtner, arXiv:1707.09664v2](https://arxiv.org/html/1707.09664v2), particularly II–III, IV.3.1 and A–C. It supplies physical BdG and infrared comparison context. The new full-frequency connection derivation below uses [NIST DLMF 16.8](https://dlmf.nist.gov/16.8) for the generalized hypergeometric identity. Neither source supplies a calibrated finite experimental band or a microscopic/device error budget. No article was downloaded, saved or admitted to holdings. Web handles and chronology are in evidence.json.

Keep physical hbar and k_B. The original field satisfies [Psi(x),Psi†(y)]=delta(x-y). In the effective one-dimensional repulsive contact model, GP is

    i hbar Psi_t=[-hbar² partial_x²/(2m)+V(x)+g(x)|Psi|²]Psi.

Let Delta_l=v0²-c_l²>0, Delta_r=c_r²-v0²>0, Delta=Delta_l+Delta_r. The fixed family is

    c²(x)=c_l²+Delta/(1+exp(-x/L)), v=-v0,
    g(x)=m c²(x)/rho0, V(x)=mu-m v0²/2-m c²(x),
    Psi0=sqrt(rho0)exp[-i mu t/hbar-i m v0 x/hbar].             (1)

Substitution gives kinetic m v0²/2 and interaction g rho0=m c², hence exactly mu; continuity is partial_x(rho0 v)=0. V is real and g positive. Their units are energy and energy times length. This is an exact GP solution, not an exact many-body state. Define xi(x)=hbar/(2m c(x)); changing healing-length conventions changes dimensionless parameters.

At exp(x_H/L)=Delta_l/Delta_r the horizon has c=v0, and

    kappa=partial_x(c+v)|_H=Delta_l Delta_r/(2v0 L Delta)>0.     (2)

hbar kappa/(2pi k_B) is a temperature unit, not by definition a Gibbs temperature. The older chiral logistic s(x) is a coefficient of a different reduced operator. Here c-v0=(c²-v0²)/(c+v0) is not logistic; only c²-v0² is. Near criticality c-v0 approximates (c²-v0²)/(2v0), with an error still to quantify. Reversing sides/rescaling a chiral coefficient does not restore its omitted downstream branch. No identification of the two operators is used.

## 2. Quadratic action, original CCR, density and physical current

Use density-phase variables Psi=sqrt(rho0+delta rho)exp[i(S0+theta)], n=delta rho/(2rho0), phi=n+i theta to linear order. Expanding the original boson CCR gives

    [n(x),theta(y)]=i delta(x-y)/(2rho0),
    [delta rho(x),theta(y)]=i delta(x-y),
    [phi(x),phi†(y)]=delta(x-y)/rho0.                           (3)

The second-order density-phase Lagrangian is

    L2=-2hbar rho0 n(partial_t+v partial_x)theta
       -hbar²rho0[(n')²+(theta')²]/(2m)-2g rho0² n².            (4)

The Hamiltonian cross term is symmetrized quantum mechanically. Keeping the density-gradient term retains quantum pressure. With a=hbar/(2m), variation gives

    D_t theta=a n''-c²n/a, D_t n=-a theta'',
    D_t=partial_t+v partial_x.                                (5)

The equivalent relative Nambu equation is i hbar partial_t Phi=B Phi, where

    B=-i hbar v partial_x I
      +[[K+m c²,m c²],[-m c²,-K-m c²]], K=-hbar²partial_x²/(2m).
                                                                    (6)

The actual linear physical observables are

    delta rho=2rho0 n,
    delta j=2rho0 v n+2a rho0 theta'.                           (7)

Equation (5) proves partial_t delta rho+partial_x delta j=0. Density has units length^-1 and particle current time^-1. Neither is graphene electrical conductivity/current. The indefinite BdG norm flux below is another quantity.

## 3. Twice-integrated density potential: exact inverse and domain

At nonzero angular frequency omega, D=-i omega+v partial_x. Set

    n=p'', theta=-Dp/a.                                      (8)

Then both original equations hold exactly if and only if

    [D²+a²partial_x^4-c²(x)partial_x²]p=0.                     (9)

The placement c²partial_x² belongs to p. The density equation is instead D²n+a²partial_x^4 n-(c²n)''=0. A once-integrated density variable would retain a differentiated c² coefficient; using its dispersion polynomial alone would not justify (9).

There is a genuine inverse on the original four-dimensional solution space. Original continuity gives (v n+a theta')'=i omega n. Define

    p'=(v n+a theta')/(i omega),
    p=(v p'+a theta)/(i omega).                               (10)

Differentiation verifies that the second expression has the first as its derivative, p''=n and -Dp/a=theta. The other BdG equation then yields (9). Conversely (8) maps every C^4 solution of (9) to the original pair. Adding a constant or affine term to p changes theta at nonzero omega; (10) fixes both constants. Thus no integration/gauge sector is silently discarded. On compact bands away from zero the omega^-1 and omega^-2 multipliers are bounded; smooth wavepackets/spatial smearings provide a natural domain. This inverse is not asserted at omega=0 or for the global unsmeared phase.

## 4. Physical normalization checked against homogeneous equal-time CCR

For p=h exp(ikx), Omega=omega-vk=omega+v0 k, the original equations give

    Omega²=c²k²+a²k^4,
    theta=U=i Omega h/a, n=V=-k²h, V/U=i a k²/Omega,
    u=V+iU, w=V-iU.                                         (11)

Here (u,w) is the relative-field Nambu spinor. Directly

    rho0(|u|²-|w|²)=4rho0 Im(V U*)=4rho0 Omega k²|h|²/a.       (12)

Normalize first in dk with [a_k,a_k'†]=delta(k-k'). For positive comoving Omega choose |h_k|²=a/(4rho0 k²Omega). Then rho0(|u|²-|w|²)=1. The expansion with dk/sqrt(2pi) and the conjugate spinor gives delta/rho0 in [phi,phi†]; u_k w_-k is even, so [phi,phi]=0. This independently reproduces (3). Drift changes time frequencies but not this equal-time check.

Changing variables to omega on a simple real branch requires a_omega=a_k/sqrt(|v_g|), v_g=d omega/dk, since delta(k-k')=|v_g|delta(omega-omega'). Thus take real positive p amplitude

    h=[a/(4rho0 k²|Omega v_g|)]^(1/2),
    |U|²=m|Omega|/[2hbar rho0 k²|v_g|],
    Im(V U*)=sign(Omega)/(4rho0|v_g|).                         (13)

A negative-norm root multiplies a creation operator, never a negative population. The spinor norm is sign(Omega)delta(omega-omega'). Green's identity for (6) gives

    J_B=rho0 v(|u|²-|w|²)
        +(hbar rho0/m)Im(u* u'+w* w').                        (14)

For a plane wave J_B equals v_g times (12), hence sign(Omega)sign(v_g) under (13). Quasiparticle energy per angular-frequency flux is hbar omega/(2pi) times signed population. Physical particle current remains (7); a plane wave independently satisfies delta j=(omega/k)delta rho.

The official HTML's rho-delta relative CCR and inverse-group-velocity prose are not used. Its displayed Eq16 |U|² is four times (13), whereas its Eq15 plus V/U gives (13). Under its displayed d omega/sqrt(2pi) convention the former fails the original homogeneous CCR check. This construction states its own normalization; it does not assume every source edition shares the HTML issue.

## 5. Roots and the actual channel threshold

Use dimensionless q=a k/v0, nu=a omega/v0², sound ratios r_l=c_l/v0<1<r_r=c_r/v0, and b=v0 L/a. The homogeneous polynomial is

    Q_j(q)=q^4+(r_j²-1)q²-2nu q-nu².                          (15)

Set

    B_l=1-20r_l²-8r_l^4, d_l=r_l²(1-r_l²)^3,
    t_+=(B_l+sqrt(B_l²+64d_l))/32>0,
    t_-=(B_l-sqrt(B_l²+64d_l))/32<0,
    nu_*=sqrt(t_+), omega_*=(v0²/a)nu_*.                       (16)

The monic quartic discriminant is

    Disc Q_j=16nu²[-16nu^4+(1-20r_j²-8r_j^4)nu²
                          -r_j²(r_j²-1)^3].                  (17)

For the left the bracket is 16(t_+-nu²)(nu²-t_-); for the right it is strictly negative for nu>0. Together with the small-frequency roots, or directly the two homogeneous dispersion branches, this proves the following structure throughout 0<omega<omega_*.

Left: two incoming high-momentum roots k_+>0,k_-<0 with v_g>0 and norms +,-; two outgoing roots k_p<0,k_d<0 with v_g<0 and norms -,+. Right: k_u>0 outgoing and k_D<0 incoming, both positive norm, plus a complex-conjugate pair k_g,k_e with Im k_g<0 (growing right) and Im k_e>0 (decaying right). All real roots are simple. No channel is dropped before imposing the no-growing-right boundary condition. The threshold omega_* is derived, not an adopted UV cutoff.

At zero frequency k_+/- tend to +/-sqrt(Delta_l)/a, k_p~-omega/(v0-c_l), k_d~-omega/(v0+c_l), k_u~omega/(c_r-v0), k_D~-omega/(c_r+v0). The right complex roots tend to +/-i sqrt(Delta_r)/a. The negative-norm incoming/outgoing assignments follow sign(Omega), not sign(k) alone.

## 6. Full-frequency 4F3 solutions and connection minors

Let z=-exp(x/L), r_i=iL k_i^l, s_j=iL k_j^r. Indexed r_i now denotes a spatial exponent, distinct from the sound ratios r_l,r_r above. Since c²=(c_l²-c_r² z)/(1-z), multiplying the actual equation (9) by 1-z gives

    [product_i(vartheta-r_i)-z product_j(vartheta-s_j)]p=0,
    vartheta=z partial_z.                                    (18)

Each left-normalized solution is

    f_i=exp(r_i x/L) 4F3({r_i-s_j}_{j=1..4};
                           {1+r_i-r_h}_{h!=i};-exp(x/L)).     (19)

Substitution verifies the coefficient ratio product_j(n-1+r_i-s_j)/[n product_h!=i(n+r_i-r_h)]. The left exponents have distinct imaginary parts, so this is a basis for positive real frequency. Continue on the negative z axis, avoiding z=1. Reconstruct n,theta with (8), not by equating p to the field.

The generalized hypergeometric connection identity yields the right coefficient of exp(s_j x/L), initially for noninteger right differences,

    C_ji= product_h!=i Gamma(1+r_i-r_h) product_t!=j Gamma(s_j-s_t)
          /[product_t!=j Gamma(r_i-s_t)
            product_h!=i Gamma(1+s_j-r_h)].                   (20)

No extra phase occurs: log(-z)=x/L. For equally sized ordered sets I,J, let M(J,I)=det C_{J,I}, V(x_I)=product_{i<i'}(x_i-x_i'). The exact canceled formula is

    M(J,I)=V(r_I)/V(s_J)
      * product_{i in I,h notin I}Gamma(1+r_i-r_h)
        product_{j in J,t notin J}Gamma(s_j-s_t)
      /[product_{i in I,t notin J}Gamma(r_i-s_t)
        product_{j in J,h notin I}Gamma(1+s_j-r_h)].            (21)

Proof: write C_ji=pi L_i R_j/sin(pi(r_i-s_j)), with L_i=product_h!=i Gamma(1+r_i-r_h)/product_t Gamma(r_i-s_t) and R_j=product_t!=j Gamma(s_j-s_t)/product_h Gamma(1+s_j-r_h). Apply the sine Cauchy determinant and reflection formula. Each selected left pair gives Gamma(1+z)Gamma(1-z)sin(pi z)=pi z; each right pair Gamma(w)Gamma(-w)sin(pi w)=-pi/w. The sine determinant sign cancels those right signs and every pi cancels. The n=1 result is (20); n=4 gives the Wronskian ratio V(r)/V(s), an independent sign check.

## 7. Physical boundary inversion, nonzero determinant, resonances and flux

Use signed columns C_in=(a_+,a_-†,a_D)^T, C_out=(a_u,a_p†,a_d)^T and real-root p amplitudes h from (13). Left coefficients are h_+a_+,h_-a_-†,h_p a_p†,h_d a_d. The boundary equations are

    C_gp h_p a_p†+C_gd h_d a_d=-C_g+ h_+a_+-C_g- h_-a_-†,
    C_Dp h_p a_p†+C_Dd h_d a_d=h_D a_D-C_D+ h_+a_+-C_D- h_-a_-†.
                                                                    (22)

The first removes actual growth; the second specifies the actual incoming downstream mode. Set M0=M((g,D),(p,d)). It is nonzero throughout the entire open three-channel interval. In (21) its Gamma arguments are: 1+r_out-r_high of real part one; s_g-s_u,s_g-s_e,s_D-s_e of positive real part; s_D-s_u nonzero imaginary; r_out-s_u nonzero imaginary; r_out-s_e positive real part; 1+s_g-r_high real part greater than one; 1+s_D-r_high real part one. A left/right real root cannot coincide at nonzero omega because subtracting their dispersion polynomials gives (c_r²-c_l²)k²=0. None is a Gamma pole or zero. Both Vandermondes are nonzero. Thus h_p h_d M0 is a proved nonzero physical determinant, not a hypothesized gap/inverse.

Cramer's rule and the u row give C_out=T C_in. For b0=+ or -,

    T_p,b0=-(h_b0/h_p)M((g,D),(b0,d))/M0,
    T_d,b0=-(h_b0/h_d)M((g,D),(p,b0))/M0,
    T_u,b0= (h_b0/h_u)M((g,D,u),(p,d,b0))/M0,
    T_p,D=-(h_D/h_p)M((g),(d))/M0,
    T_d,D= (h_D/h_d)M((g),(p))/M0,
    T_u,D= (h_D/h_u)M((g,u),(p,d))/M0.                         (23)

In particular beta=T_u,-. Every needed J contains g; its right complement contains only the other propagating root(s) and/or e. Thus all Gamma arguments in (21),(23) have positive real part, real part one, or nonzero imaginary part. All nine entries are finite and nonzero for this fixed family.

Individual coordinates (20) can have apparent poles when a right growing exponent differs by an integer from another exponent. Its Frobenius solution then has resonant/logarithmic descendants. The canceled minors (21) give the finite invariant limit. Adding a multiple of the g row to a resonant propagating row changes no relevant minor or growth-free coefficient. Since (22) kills the entire growing solution, its descendants also vanish. Remaining decaying logarithmic descendants change no leading propagating amplitude. Nonresonant solutions continue to the unique bounded-channel limits (21); no integer-free restriction on L is imposed. One must use these canceled expressions rather than separately evaluate and subtract divergent connection coordinates.

Green's identity (14) for any two bounded scattering solutions gives

    T† J T=J, T J T†=J, J=diag(1,-1,1).                       (24)

Distinct real-root interference carries zero net conserved flux and decaying tails vanish. The second identity follows from the first for a square T. This proves the full indefinite channel flux law with downstream coupling retained. It is not physical particle-current conservation per quasiparticle and is not a Gibbs/KMS theorem.

## 8. Explicit uniform finite-frequency constants and error control

These deliberately conservative bounds concern exact scattering amplitudes on a nonempty compact theoretical interval. They do not identify an experimental band or assume that a Hawking-limit approximation is accurate there.

Take nu_lo=nu_*/8, nu_hi=nu_*/4, t_lo=nu_lo²,t_hi=nu_hi². Define

    K=1+max(|r_l²-1|,|r_r²-1|,2nu_hi,nu_hi²),
    D_l=256t_lo(t_+-t_hi)(t_lo-t_-),
    D_r=16t_lo r_r²(r_r²-1)^3,
    delta=min(sqrt(D_l),sqrt(D_r))/(2K)^5>0,
    zeta=t_lo/K³>0,
    delta_x=(r_r²-r_l²)zeta²/(2K)^3>0.                        (25)

The monic Cauchy bound gives |q|<=K. The discriminant is the product of the six squared root distances; bounding the other five by 2K proves each same-side distance >=delta. Since the product of four roots has modulus nu², |q|>=zeta. Finally Q_r(q_l)=(r_r²-r_l²)q_l² proves each cross-side distance >=delta_x. These gaps are derived algebraically for the entire band.

Implicit differentiation of (15) gives

    |partial_nu q|<=M1=2(K+nu_hi)/delta³.                      (26)

For every real root, |nu+q|>=r_l zeta, and its dimensionless group velocity equals Q_q/[2(nu+q)]. Logarithmically differentiating h therefore gives

    |partial_nu log h|<=H=M1/zeta+(1+M1)/(r_l zeta)+3M1/delta.
                                                                    (27)

The right conjugate pair has Re(s_g)>=b delta/2, -Re(s_e)>=b delta/2. Every Gamma argument needed in (23) has Re>=0, modulus at least eta=min(1,b delta/2,b delta_x), and modulus at most R=1+2bK. The convergent series

    psi(z)=-EulerGamma-1/z+sum_{n>=1}z/[n(n+z)]

bounds its digamma by Psi=1+1/eta+R pi²/6: |n+z|>=n. Each argument derivative is at most 2bM1. A size-n minor has 4n(4-n) Gamma factors counting numerator and denominator; a ratio in (23) has at most 32. Its Vandermondes have at most eight root differences. Thus all nine exact entries satisfy

    |partial_nu T_ij|<=B |T_ij|,
    B=64bM1 Psi+16M1/delta+2H<infinity.                       (28)

This includes the physical normalization derivative. No desired small correction is assumed.

Fix nu_c=(nu_lo+nu_hi)/2 and the exact T_c from (21),(23). For epsilon>0 set

    d_epsilon=min((nu_hi-nu_lo)/2,log(1+epsilon)/B)>0,
    I_epsilon=(v0²/a)[nu_c-d_epsilon,nu_c+d_epsilon].            (29)

Integrating (28) proves uniformly on this nonempty interval

    |T_ij(nu)-T_ij(nu_c)|<=|T_ij(nu_c)|(exp(B|nu-nu_c|)-1),
    ||T(nu)-T_c||_F<=||T_c||_F epsilon.                        (30)

All constants, the center and its matrix are explicit algebraic-root/Gamma functions of the fixed physical parameters, not fitted transfer/temperature or an unspecified inverse. The interval may be very narrow and this theorem is inside the GP/BdG model only.

For vacuum n_u=|beta|², |n_u(nu)/n_u(nu_c)-1|<=exp(2B|nu-nu_c|)-1. For mode-diagonal thermal inputs define Nmax and M_N bounding populations and derivatives. For comoving Bose populations at T_j>0 explicit choices are

    Omega_min=(v0²/a)r_l zeta,
    Nmax_j=[exp(hbar Omega_min/(k_B T_j))-1]^-1,
    M_N,j=(hbar v0²/(a k_B T_j))(1+M1)Nmax_j(1+Nmax_j),        (31)

and zero for T_j=0. Maximize over j. In signed columns the ordered input covariance has N or N+1 entries. With M_c=||T_c||_F, d=|nu-nu_c|,

    ||K_out(nu)-K_out(nu_c)||
      <=M_c²[(exp(2Bd)-1)(Nmax+1)+M_N d].                      (32)

This follows by adding/subtracting T_c K_in(nu)T_c† and using (30). It bounds occupations and anomalous covariance together on the actual scattering algebra.

There is also a concrete comparison with the infrared scale Theta in section 9. Define F_c=omega_c|beta(omega_c)|²/Theta and B_F=1/nu_lo+2B. Then

    |omega|beta(omega)|²/Theta-1|
       <=|F_c-1|+F_c[exp(B_F|nu-nu_c|)-1].                    (33)

The center error is explicit, not asserted small. A uniformly small leading-Hawking relative remainder toward zero with a useful explicit upper edge is NOT proved by (30) or (33). Setting |F_c-1|=0 or silently replacing it with nominal O(omega) would be false. The exact finite-frequency formula makes the missing stronger estimate concrete. It does not establish an experimentally useful band.

## 9. Infrared profile calculation, downstream factors and chiral comparison

Derive zero-frequency constants from (5), not by setting omega=0 in (10). The nonconstant homogeneous zero mode has chi=rho0 theta' and

    chi''=(c²-v0²)chi/a².                                    (34)

Let Q_l=sqrt(Delta_l)/a,Q_r=sqrt(Delta_r)/a,ell=Q_l L,r=Q_r L. The right-decaying solution is

    chi=e^{-Q_r x}2F1(r-i ell,r+i ell;1+2r;-e^{-x/L}).          (35)

Substitution checks the equation. With y=e^{-x/L}, the coefficient of e^{+iQ_l x} is D_+=Gamma(1+2r)Gamma(-2i ell)/[Gamma(r-i ell)Gamma(1+r-i ell)], and D_-=conjugate(D_+). The orientation follows y^{+i ell}=e^{-iQ_l x}, rather than an inconsistent A2/A3 label.

For the Abel integral I=integral chi/rho0 dx, multiply by exp(epsilon x),0<epsilon L<r. The Mellin power is r-epsilon L, where the integral is absolutely convergent; take epsilon down to zero in the Gamma formula. This gives

    I=pi L Gamma(1+2r)/[rho0 r ell sinh(pi ell)|Gamma(r+i ell)|²]>0,
    |D_+|²/I²=rho0²r²ell sinh²(pi ell)
                   /[2pi L²(r²+ell²)sinh(2pi ell)].            (36)

Use Gamma(z+1)=zGamma(z), |Gamma(iy)|²=pi/[y sinh(pi y)] to verify both identities. This proves the actual profile denominator nonzero.

The infrared limits can be extracted directly from the exact minors, with Gamma(z)~1/z only for collapsing acoustic differences. For an explicit check define alpha_p=L/(v0-c_l),alpha_d=L/(v0+c_l),alpha_D=L/(v0+c_r),alpha_u=L/(c_r-v0), A=alpha_p-alpha_d,S=alpha_D+alpha_u,P=(alpha_p+alpha_u)(alpha_d+alpha_u). For M0 and M3=M((g,D,u),(p,d,-)), leading Gamma factors give

    M0 ~ (-i omega)² A P/(r S)
           *|Gamma(1+i ell)|² Gamma(2r)/|Gamma(1+r+i ell)|²,
    M3 -> -A ell²/(r² S)
           *Gamma(1-2i ell)Gamma(2r)
            /[Gamma(r-i ell)Gamma(1+r-i ell)].                 (37)

Thus

    |M3/M0|² ~ ell³(r²+ell²)tanh(pi ell)/(pi r²P² omega^4),
    h_-²/h_u² ~ a³ c_r omega³/[(c_r-v0)²Delta_l^(5/2)].        (38)

In simplifying, |Gamma(1+r+i ell)|²/[Gamma(r-i ell)Gamma(1+r-i ell)] equals Gamma(1+r+i ell)/Gamma(r-i ell); its squared modulus is r²+ell², not its square. Also P=L²Delta/[Delta_l(c_r-v0)²]. Inserting these identities proves

    Theta=lim_{omega down to 0}omega|beta|²
          =kappa tanh(pi ell)Gamma0/(2pi),
    Gamma0=4v0 c_r/(v0+c_r)².                                (39)

The other minors, with the same root substitutions, give the downstream limits

    |R0|²=(v0-c_r)²/(v0+c_r)²,
    |B0|²=[(v0-c_l)²/(v0+c_r)²]c_r/c_l,
    |T0|²=[(v0+c_l)²/(v0+c_r)²]c_r/c_l.                       (40)

Here R0=T_u,D,B0=T_p,D,T0=T_d,D in the signed convention; |R0|²-|B0|²+|T0|²=1 and Gamma0=1-|R0|². Their phases can be redefined with channel phases. The source HTML Eq71b specialization has a conflicting square-root factor versus its general Eq55a and fails this flux check with its displayed T0. Our exact minors, rather than that conflicting specialization, control (40).

A second independent CCR-dependent check uses U_Z²=v0²/[4rho0 Delta_l^(3/2)]. Matching the original phase amplitudes gives

    omega|beta|² -> |D_-|²/[Q_l²rho0² U_Z² I²]
                    *m c_r/(2hbar rho0)*(1+R0)²,
    R0=(v0-c_r)/(v0+c_r)

in a phase convention with real R0. Substituting (36) yields c_r Delta_l Delta_r tanh(pi ell)/[pi L Delta(v0+c_r)²], exactly (39). This checks the normalization-dependent coefficient separately from the full-frequency construction. It is not a finite-frequency Planck law.

The greybody-removed frequency scale is Theta/Gamma0=kappa tanh(pi ell)/(2pi), with exact fractional deficit

    1-tanh(pi ell)=2/[exp(2pi ell)+1].                         (41)

For fixed asymptotic material parameters and varying L, D_H=kappa xi_H/v0=kappa a/v0² satisfies ell D_H=Delta_l^(3/2)Delta_r/(2v0³Delta)>0. The deficit is exponentially small in 1/D_H and has no nonzero quadratic asymptotic coefficient for this family. Even in the smooth limit Gamma0 need not approach one. This is a source-controlled physical GP profile with downstream scattering, not a universal pi/6 law or a result for an actual graphene/polariton device. A quantitative chiral reduction remains a distinct error estimate.

## 10. Incoming quantum state, anomalous covariance and non-KMS controls

Use the boson CCR on L²(I,d omega) for the three incoming annihilators a_+,a_-,a_D. A mode-diagonal quasifree input N_+,N_-,N_D>=0 is positive, including vacuum. Thermal alternatives may use the positive comoving energies |Omega_j|; the negative-norm input is never assigned a negative Bose occupation. For the right d branch Omega_D~omega c_r/(v0+c_r), so rest-frame thermal temperature gives the infrared laboratory-frequency scale multiplied by 1+v0/c_r. Global Gibbs equilibrium for the unbounded laboratory quadratic energy is not assumed.

Write the rows of T as (A,beta,R),(C,D,B),(F,G,H). Direct multiplication gives

    n_u=|A|²N_++|beta|²(N_-+1)+|R|²N_D,
    n_p=|C|²(N_++1)+|D|²N_-+|B|²(N_D+1),
    n_d=|F|²N_++|G|²(N_-+1)+|H|²N_D,
    c_up=<a_u a_p>=A C*(N_++1)+beta D*N_-+R B*(N_D+1).        (42)

Row orthogonality A C*-beta D*+R B*=0 gives vacuum c_up=beta D*, n_u=|beta|²,n_p=|C|²+|B|². With N_+=N_-=0,N_D=N, cancellation of the N² term and (24) give

    n_u n_p-|c_up|²=(|C|²-|beta|²)N-|beta|².                  (43)

Negative (43) violates the separable normally ordered inequality |c|²<=n_u n_p; equality is allowed, unlike a strict bound printed in the source. In the infrared,

    (|C|²-|beta|²)/|beta|² -> (c_r-c_l)²/(4c_r c_l).           (44)

One check: choose channel phases with B0=(v0-c_l)sqrt(c_r/c_l)/(v0+c_r). The leading partner/u conversion ratio is (c_l/c_r)[(1+B0 sqrt(c_r/c_l))/(1+R0)]²=(c_l+c_r)²/(4c_l c_r). Thus thermal downstream population can remove this witness; vacuum entanglement is not arbitrary-temperature robustness.

The exact symplectic map preserves band CCR and covariance positivity. It produces a generally nonequilibrium anomalously correlated state, not global KMS/Gibbs. A Planck-like marginal would not establish KMS. beta²~Theta/omega makes the total infrared quasiparticle number diverge logarithmically. Moreover a stationary nonzero frequency-diagonal Bogoliubov multiplication kernel is not Hilbert–Schmidt on a nonatomic L² space even on a compact band. Global Fock-unitary implementability is therefore not inferred from bounded band amplitudes. The algebraic band state and finite smeared observables remain valid. Finite observation-time packets/modes are physical detector restrictions, not proof of a global infrared Fock state.

## 11. Actual density/current scattering contributions, ordered noise, units

Use (19),(22),(8),(13) to construct the scattering contribution to the physical fields (7). For real compact smooth spatial weights and a compact positive band I, its Hermitian observable has the actual input expansion

    X_sc(t)=integral_I d omega/sqrt(2pi)
      [e^{-i omega t}q(omega)C_in(omega)
       +e^{+i omega t}C_in†(omega)q†(omega)].                 (45)

The density functional is 2rho0 partial_x² on the normalized p solution; the current functional is 2rho0 v partial_x²-2rho0 partial_x D, followed by the spatial integral. Thus q is fixed by the physical operator/profile/modes, not supplied as a desired transfer, Planck law, or graphene sigma_Q. Compact x support and frequency band make q continuous and square-integrable. These are exact scattering-sector density/current contributions. Their identification with the entire stationary local field remains section 12's BUILD.

For S^>(omega)=integral dt exp(i omega t)<X_sc(t)X_sc(0)> and omega>0 in I,

    S^>(+omega)=|q_+|²(N_++1)+|q_-|²N_-+|q_D|²(N_D+1),
    S^>(-omega)=|q_+|²N_++|q_-|²(N_-+1)+|q_D|²N_D,
    S_sym=sum_j |q_j|²(N_j+1/2),
    S^>(+omega)-S^>(-omega)=|q_+|²-|q_-|²+|q_D|².             (46)

With chi_R=(i/hbar)theta(t)<[X(t),X(0)]> for perturbation -F X, Im chi_R=(S^>(omega)-S^>(-omega))/(2hbar). The equilibrium coth relation needs KMS detailed balance; anomalous scattering does not supply it.

Variance is integral d omega S_sym/(2pi). The two-sided PSD per Hz is S_sym(2pi f), and its one-sided symmetric per-Hz version is 2S_sym(2pi f) for f>0. If an angular density instead integrates against d omega, it is S_sym/(2pi), giving the corresponding 2pi conversion. Density PSD units are length^-2 time; particle-current PSD time^-1; a weighted X PSD has X² time and q units X sqrt(time). A raw density/current PSD is not a bare Planck occupation.

## 12. Spectral attempts, complete finite-time field, and load-bearing residuals

There is additional stability progress, but not yet a full stationary completeness theorem. For nonreal omega no homogeneous real-k dispersion can equal omega; no spatial exponent has zero real part. Each side has two exponents of each real-part sign (continue from small nonzero Im omega, or the high-frequency quartic). Select the two left decaying exponents Re r>0 and the two right growing exponents Re s>0 as I,J in (21). Complementary left/right exponents have negative real parts. Every Gamma argument in (21) has strictly positive real part (the 1+ differences exceed one). None vanishes or is a pole.

The Evans wedge of the left decaying pair and right decaying pair is proportional to M(J,I) times the full right Wronskian. Divide the two decaying wedges by their internal Vandermondes at repeated roots. The resulting expression is the Gamma product of (21) times the cross differences between right growing and decaying roots, which cannot vanish because their real parts have opposite signs. Same-side collisions are removable divided-difference basis artifacts. Integer differences within a decaying or growing pair also require logarithmic Frobenius limits: subtract the pole multiple of the other solution before taking the limit. Their wedge has a finite nonzero continuation because the selected/complementary cross arguments in (21) remain in the strictly positive half-plane. This is a limiting statement about the entire selected subspace, not separately divergent Frobenius vectors. This gives a nonzero normalized wedge and excludes nonreal L² eigenmodes. For each fixed nonreal omega the exponentially convergent logistic tails have spatial exponential dichotomies. This wedge constructs a decaying Green kernel and bounded L² resolvent. It is a real-spectrum claim, not a uniform resolvent or a uniform-in-time stability bound. These new manual author arguments require whole independent scientific verification.

For real omega>omega_* only one left solution decays spatially, with Re r_i>0; the other left exponents have nonpositive real part. Its C_gi in (20) is nonzero: all Gamma arguments have positive real part (or greater than one), since every other left exponent has nonpositive real part and every other right exponent has smaller real part than s_g. Thus that sole left L² candidate grows on the right. Below threshold all left roots are real and no nonzero oscillatory Frobenius combination is L² there. At a nonzero threshold polynomial/logarithmic degeneracies still do not decay on the left. At zero, use the original coupled equations separately: v n+a theta′ is constant; an L² solution and its asymptotic derivatives force that constant to zero, and the resulting chi equation (34) has only nondecaying left oscillations unless chi=0. Then theta is constant and L² forces theta=n=0. This avoids the invalid zero-frequency inverse (10). This excludes L² bound modes too. It does not remove generalized zero/threshold modes or prove expansion of arbitrary wavepackets.

An independent complete finite-time field/state construction is possible without stationary scattering completeness. Split (6) on L²(R) direct-sum L²(R) into its self-adjoint kinetic/drift block and bounded W=m c²[[1,1],[-1,-1]], ||W||<=2m c_r². The Duhamel series gives a strongly continuous evolution with

    ||U(t)||<=exp(beta0 |t|), beta0=2m c_r²/hbar,
    ||U(t)-U_N(t)||<=exp(beta0|t|)(beta0|t|)^(N+1)/(N+1)!.    (47)

This is an explicit full-continuum finite-time remainder without a finite box. Smooth bounded coefficients preserve the H² core. B†J=JB proves U†JU=J there and then by density; Nambu conjugation symmetry also holds. Transporting any positive full-field algebraic quasifree initial covariance produces a positive full-field state with the actual local equal-time CCR and continuity (7). The fluctuation-field vacuum at t=0 is an explicit example; bounded nonnegative occupation operators give further initial states. Fock implementation is unnecessary. Gapless finite-temperature covariances unbounded at zero require a smaller test-function domain and are not silently included in the bounded-covariance example.

The finite-time state need not be stationary or equal the scattering incoming vacuum. Real spectrum, no L² modes and pseudo-unitarity do not alone prove completeness. The exact remaining obligations after these actual attempts are:

1. Prove stationary wave-operator/spectral completeness for this indefinite, non-self-adjoint two-asymptote BdG generator, with high-frequency, threshold and zero-sector control. The exact Jost/minor/Evans formulas give a concrete resolvent route, but contour closure must justify its large-frequency arc, zero/threshold terms and continuum normalization. A positive-energy Stone theorem cannot simply be assumed here.
2. Construct and identify the full stationary incoming quasifree state on an explicit whole-field test algebra, including infrared restrictions, and prove its equal-time local CCR. Only then equate (45),(46) with the full local stationary density/current noise. The stationary band state and full finite-time state are distinct positive constructions; their identification remains missing.
3. Supply a uniformly small infrared/Hawking-limit approximation remainder if that leading approximation is used, rather than treating compact-band variation control (25)–(33) as small leading-law error or a usable detector band.
4. Bound the microscopic dilute quasi-1D gas to GP/BdG approximation on the same scales: weak depletion, one-dimensional phase/infrared fluctuations, interaction corrections, transverse modes, finite geometry and state preparation/reservoirs. Exact GP substitution does not quantify these errors. Here the dimensionless Lieb–Liniger coupling is gamma_LL=m g/(hbar²rho0)=m²c²/(hbar²rho0²)=1/[4(rho0 xi)²]. Weak-coupling assumptions therefore restrict the symbolic family rather than follow from g>0. A transverse gap and relevant interaction/temperature/frequency/inhomogeneity separation must be supplied and controlled. The infinite one-dimensional GP mean is not a proof of true equilibrium long-range condensate order at finite temperature; finite coherence/depletion errors require their own domain and bound.
5. Build the actual target platform's profile/dispersion/state, losses, optical/electrical readout and calibration/error budget, and exhibit a nonempty useful detection interval. BEC particle current is not graphene electrical sigma_Q; polariton pump/reservoir dynamics and electronic collision/width effects are not supplied by this Hamiltonian.

These are substantive BUILD obligations, not an infeasibility conclusion, waiver, optional deferral or new routing ledger. No universal pi/6 coefficient, empirical detection, full shared D1/E1/E2 law, all21/B1–B8/D12 completion, native proof, full gate, source application/main or publication acceptance follows. Fresh genuinely nonauthor whole scientific review must assess the entire construction before any scoped lead intake.

<!-- END COMPLETE ORIGINAL CONSTRUCTION -->
