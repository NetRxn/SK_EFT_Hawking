# Original L1 full-action source and continuum prerequisites — source-model

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** All twelve sections: literal original action local-covariance residual, exact source identities and controlled smooth classical Wilson/midpoint/frame/action/source limits and errors.

**Original physical obligations.** No family-wide physical no-go or quantum continuum. Additional covariant C is not an approved replacement/equivalent regulator, and D3366/rank/source coefficients do not transfer. Original physical B3/window, modes/matter and transport remain owed.

The construction author is publication_njl_target_review; the complete independent scientific review is by publication_root7_current_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE](../L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE.md), [fixed source model](../source-models/L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE.md), [full independent review](../reviews/L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE-SOURCE_MODEL -->
# Prospective original-action gauge/source/continuum model — fixed BEFORE new mathematics

This source/model contract is saved after the original FIRST and full genuine initial protection and BEFORE ANY new gauge/Ward/plaquette/action/coefficient/continuum mathematical scratch. No construction or covariance is claimed by these definitions. Prior accepted one-/two-site mathematics and the prior printed-order countercontrol are immutable inputs, not new proof under this task. The entire original model below is retained byte-for-byte, SHA256829c0c498d6030c6b5f0678b950a30550b55d50044c14185f1adbe3050c42949. No original coupling, source, measure, boundary, geometry, physical goal or arbitrary-volume member is replaced.

<!-- BEGIN EXACT ENTIRE ORIGINAL MODEL829c0c49 -->
Actual MODEL save UTC: 2026-10-18T14:55:19.725781+00:00

# Fixed original physical family BEFORE new mathematics

This SOURCE_MODEL is saved prospectively at the actual timestamp below, after fresh FIRST/protection and reading existing model definitions, before any new mathematical scratch, coefficient selection or derivation. Reading/scoping existing accepted results is not represented as a new proof. Full five notes/reviews and inventory still must be completely read before new derivation. No parameter, eigenchannel, physical normalization or physical window is selected to fit an answer.

## Original microscopic family and orders

For every positive integer four-tuple L, use the finite four-dimensional hypercubic torus Λ=product Z/L_mu Z with V=product L_mu, spacing a>0 and physical regulator volume V a^4. Fix real periodic fermion boundary conditions in all four directions for the constructions here. Every x has four independent unbarred ψ_xI and four independent barred generators, I=1,...,4. Fix source Berezin orientation with the sitewise ordered top monomial bar1 bar2 bar3 bar4 ψ1 ψ2 ψ3 ψ4 integrating to1, and lexicographic site order. The original complex Dirac generators are not replaced by a real Majorana/Pfaffian assumption.

Each positively indexed link has an independent compact Ω_(x,μ)=diag(U_L,U_R), both factors independently normalized SU(2) Haar; independent links exist even for coincident neighbors. Fix the actual carrying-note gamma basis

γ_j=[[0,−iσ_j],[iσ_j,0]], j=1,2,3;
γ_4=[[0,I],[I,0]], γ_5=diag(I,−I), ε_1234=+1.

Retain T=a ehat, with all four blocks ADDED exactly, including small-torus coincidences:

T_(x,μ,A)=1/4[barψ_x γ_A Ω_(x,μ)† ψ_(x+μ)
 −barψ_(x+μ) Ω_(x,μ) γ_A ψ_x
 −barψ_x γ_A Ω_(x−μ,μ) ψ_(x−μ)
 +barψ_(x−μ) Ω_(x−μ,μ)† γ_A ψ_x].

Retain the ordered plaquette of the original source/carrying action, with left-to-right matrix multiplication:

Ω_(x,κλ)=Ω_(x,κ) Ω_(x+κ,λ) Ω_(x+λ,κ)† Ω_(x,λ)†.

Do not commute gamma/link factors or substitute another transport/plaquette orientation during a calculation. The full gauge/source interpretation must be checked with these fixed conventions; no extended-lattice gauge-invariance or continuum conclusion is assumed here. The one-site reduction of this order is the original plaquette commutator. Official primary HTML was read for the actual displayed orders before this save; no PDF-version identity or full-paper proof-depth claim is made.

The full selected original action is S=g1 sum_x S4_x + g2 sum_x S2_x, arbitrary finite g1,g2 (complex algebraic family, with real-coupling physical slice requiring its own domain). In exactly the carrying normalization,

S4_x=ε_ABCD T_(x,1,A) T_(x,2,B) T_(x,3,C) T_(x,4,D),
S2_x=(1/4) sum_(κ,λ,μ,ν,C,D) ε^(κλμν)
 Tr[Ω_(x,κλ) γ_C γ_D γ_5] T_(x,μ,C) T_(x,ν,D).

The exponent is +S. Neither interaction is deleted or treated as a quadratic/free scalar action. No extra mass, kinetic term, positive Gaussian measure or source-paper ellipsis interaction is inserted. a^4/a^2 cancellation under T=a ehat is the inherited convention; physical field normalization is not inferred from it.

## Actual observables and sources

Use all16V original T coordinates with dimensionless independent J_xμA, plus the invariant-candidate local symmetric metric composite G_xμν=sum_A T_xμA T_xνA for all ten independent μ≤ν pairs per site. Couple +sum J T +sum_x,μ≤ν H_xμν G_xμν in Z(J,H)=integral Haar/Berezin exp(S+sources). Every off-diagonal H pair is counted ONCE; a full symmetric K representation has K_μμ=H_μμ and K_μν=H_μν/2 for μ<ν. This is a coordinate convention, not a physical spin-2 projection.

Keep the entire joint26V-coordinate response, source order and any singular directions. G is built from original T and is not auxiliary h. Preserve the exact signed/possibly complex Hermite weight W, with arbitrary representation variance σ²>0, whenever auxiliary variables are used: W does not shift with sources and is not discarded or replaced by a positive density. Normalization uses actual Z and must be refused on its zero set. No positive physical probability measure, nonzero source-free metric background or Lorentzian dynamics is postulated.

## Prospectively fixed finite spatial construction and full target

The primary new finite control is Λ*=Z/2 Z × Z/1 Z × Z/1 Z × Z/1 Z, with sites0 and e1, periodic boundary conditions as above, independent Ω_(x,μ) at BOTH sites and the ENTIRE action for arbitrary g1,g2. It is an extended coupled two-site torus, not two uncoupled copies of the one-site model. All forward/backward and other-direction coincident blocks and all plaquettes are retained before any simplification. Any geometry/center/saturation cancellation must be proved for this fixed geometry, not imported from V=1. No coefficient, nonzero Z, sign or physical usefulness is assumed. The full arbitrary-L family remains the scientific target; this finite control does not replace it or prove a volume approximation. The previously accepted V=1 model remains an exact control, not new progress.

New work must actually evaluate a nonzero-separation coupled spatial metric coefficient/response and normalization/domain for this same family beyond a formal coefficient algorithm, then construct the physical tensor/source/units/spacing/volume/cutoff/field-normalization/numerator/multiplicity/subtraction bridge. Actual g1/g2-to-L1 u_g/c_D/γ_star matching or a precise demonstrated mismatch is required; no equality is chosen. The dimensionless physical χ_vest window[0.1,10] remains a derived RESULT to establish on a justified domain with errors; χ=1, a coordinate eigenvalue, M/(96g2²), a scalar bubble or a selected eigenchannel cannot replace it.

Retain the old zero-mean G, rank-ten joint26 one-site response, nonzero-tetrad-source witness versus physical vacuum distinction, source-order/gauge/Hessian/pole limitations and near-instability/refusal conditions. Full ADW ordered phase/background/full constrained fluctuations/Lorentzian/continuum/graviton and independent magnitude remain BUILD. All THREE distinct L1 duties (B3 susceptibility/window; physical tensor dynamics; physical transport/frequency matching), the shared D1/E1/E2 dispersive law and all21/B1–B8/D12 objectives remain. Missing results require continued substantive work and, if computation is needed, a concrete DATA UNRUN error/precision/poison/exact-restore plan, not infeasibility, deferral, a changed target or invented execution authority.

Only assigned seven ignored leaves may be written. No mathematical/coefficient engine, project/helper/model import/evaluation, tests/build/native/controller/source/Git/holding/registry/book/closure mutation or delegation. Fresh genuinely nonauthor whole SCIENCE review is required after author freeze; author cannot self-accept or close any finding.


<!-- END EXACT ENTIRE ORIGINAL MODEL829c0c49 -->

## Fixed new-task targets and additional branch (definitions only, not derived results)

ORIGINAL LITERAL branch L: precisely the enclosed original arbitrary finite periodic four-torus, arbitrary finite complex g1/g2 and full S4/S2, independent Spin(4) Haar and original Berezin orientation, original four coincident-added T blocks, literal printed left-to-right plaquette, all16V tetrad J and10V once-pair metric H source coordinates. The old two-site source polynomial and D3366, one-site ranks and all accepted domains remain statements of THIS literal branch only. They are never transported automatically to an altered branch. Gauge/action/source behaviour is to be derived, including any nonzero full-action residual; no Elitzur, physical vacuum or action covariance is an assumed premise.

Fixed gauge conventions for every comparison: column psi'(x)=V(x)psi(x), bar'(x)=bar(x)V(x)^dagger; V(x) in Spin(4) at each site. Positive-link transporter Omega(x,mu) maps the spinor at x to x+mu and transforms by V(x+mu)Omega(x,mu)V(x)^dagger. Its negative-direction transporter is the inverse link. Gamma matrices, gamma5 and epsilon are exactly the enclosure. Joint sources are defined before products/integration; metric G=sum_A T_A T_A is never auxiliary h. Any source Ward formula must retain the literal action residual, singular-cofactor/nonzero-Z refusals and once-counted offdiagonal convention.

EXPLICIT ADDITIONAL PATH branch C (researched alongside L, not replacing L): on the SAME full arbitrary-volume/coupling/link/fermion family and with the SAME four T blocks, source definitions and S4/S2 tensor forms, replace ONLY the plaquette insertion by the closed transport along the uniquely fixed oriented path x -> x+mu -> x+mu+nu -> x+nu -> x. Each positive step uses the positive-link transporter just defined and each negative step its inverse. Compose column transports with the rightmost matrix acting FIRST. This fixed path specification, not a convenient future algebraic answer, determines the insertion order. Every other interaction term/coupling/prefactor remains. The closed path is based at x. The new branch's action/measure/source/gauge properties and any relation or failure of equivalence to L must be proved, not assumed. Link inversion and Haar invariance alone are not an equivalence of full T/action/source. No operator decision approving replacement or reduced original physical scope is inferred. No D3366, V1 rank or Hessian from L is asserted for C.

SMOOTH CLASSICAL EMBEDDING to be studied (separate from the full quantum Haar family): let A_mu(x) be an arbitrary C^3 spin(4)-valued anti-Hermitian connection on a fixed compact neighbourhood of the paths, with finite symbolic sup bounds on all derivatives through order3; allow smooth periodic domains or compact interior charts with all paths contained. Keep generic C^4 Grassmann-coefficient spinor/bar fields and C^3 site gauge maps with finite symbolic coefficient/derivative bounds, not a selected background or state. Use a FIXED finite Grassmann generator algebra with its monomial coefficient l1 norm for these classical embeddings and matrix operator norms for the finite connection/gauge matrices. Its coefficients may depend on x; do not collapse all lattice-site quantum generators to this embedding when discussing quantum limits. The physical engineering units and required actual quantum interpretation are still to be matched.

For a chosen edge define EXACT Wilson transport by the column-spinor differential equation dU(s)/ds=-A_mu(x+s e_mu)U(s), U(0)=I,0<=s<=a. Separately define the SOURCE-MIDPOINT link exp[-a A_mu(x+(a/2)e_mu)]. These are separate prescribed constructions. Do not assume midpoint transport has exact finite gauge covariance or is exactly Wilson transport; derive any bounds and connection/curvature convention explicitly. Relate A to the source's omega_AB gamma-commutator normalization before claiming an EHC sign or g2 normalization. Preserve gamma/frame/world units and all epsilon factors. No formal big-O alone is accepted as a quantitative remainder.

The embedding is a controlled kinematic comparison target, NOT an assumption of phase selection, clustering, positive Gibbs measure, thermodynamic/quantum continuum convergence, Lorentzian continuation, graviton/matter poles, physical susceptibility or a window. All expansion constants must be expressed in the declared symbolic derivative/norm data and a stated small-a/compact-domain range, without fitted material inputs or changing this path definition after proof.

FULL ORIGINAL physical source/projector/operator/coupling/contact/subtraction/units/state/volume/continuum/response/error goals remain. Any candidate Q=Z_Q G/a^2 uses a symbol to be physically derived, not chosen to obtain chi or [0.1,10]. The full52 two-site joint tensor and arbitrary-volume kernel, actual physical zero-source ordered state, positivity/continuation, microscopic dynamics/matter and physical frequency/transport remain BUILD. B3 requires [0.1,10] as a RESULT; no interval, scalar bubble, selected eigenchannel or coordinate normalization substitutes. Three L1 duties remain distinct and the one shared D1/E1/E2 law/all21/B1-B8/D12 remain separate unwaived work.

No execution, coefficient/math engine, source installation, native/Lean, holding, runtime, main or closure authority is conferred. Required independent references/precision/refinement/populations and real poison/exact-byte-mode-nsmtime restoration are DATA UNRUN plans only. Fresh genuinely nonauthor WHOLE science review and lead intake are required. Original process/ref/admin/raw-index failures remain immutable, not waived by this model save.

<!-- END SOURCE137-EXACT-L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE-SOURCE_MODEL -->
