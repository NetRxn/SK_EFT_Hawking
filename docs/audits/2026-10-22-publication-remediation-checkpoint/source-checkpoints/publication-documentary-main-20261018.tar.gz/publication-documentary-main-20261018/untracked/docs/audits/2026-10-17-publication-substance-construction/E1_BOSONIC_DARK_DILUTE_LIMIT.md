# Bosonic dark modes, exact count reduction and a controlled dilute limit

Author: publication scientific lead. Independently accepted MANUAL mathematical construction within the declared model; native and physical acceptance remain open. Parent: original E1/D1 dark-reservoir/noise BUILD. This extends the accepted quantum counting-register construction by providing a finite-mode BOSONIC realization and bounding its dilute limit. It is not a derivation of the actual material bath, Markov rates or optical/detector sensitivity. No physical closure, implementation or native acceptance.

## 1. Actual bosonic realization and stipulated bath law

Fix an integer J≥1, cavity a and J canonical bosonic dark modes d_j. Let N=a†a and R=sum_j d_j†d_j. Adopt finite real Delta,U,chi,omega_D, finite constant F, gamma0>0,gamma_R>0,gamma_in≥0 and the angular-rate Hamiltonian/jumps

K=Delta N+(U/2)N(N-1)+chi N R+omega_D R+i(Fa†-conj(F)a),
L0=sqrt(gamma0)a,
L_(i,j)=sqrt(gamma_in/J) a d_j†,
L_(R,j)=sqrt(gamma_R)d_j.                                           (1)

These are ordinary bosonic creation operators, so stimulation is retained. Equal couplings and equal decay rates, dependence of cavity feedback only on total R, unidirectional Markov conversion and absence of other material interactions are assumptions. A microscopic Hamiltonian-to-bath/secular/Markov derivation and finite-temperature backconversion are still owed. In particular this note does not identify gamma_in/J with a measured per-mode matrix element. Physical density/mode/area and energy calibration remains separate.

Use the finite carrier N+R≤L for each finite J. It has finite dimension; every conversion preserves N+R and every loss lowers it, while only the drive crosses the upper shell. Ordinary finite GKSL therefore supplies an actual CPTP dynamics. The accepted joint moment/cutoff argument extends because conversion conserves Q=N+R and

sum_j L_(i,j)†L_(i,j)=gamma_in N(1+R/J),
sum_j L_(R,j)†L_(R,j)=gamma_R R.                                   (2)

For delta=min(gamma0,gamma_R)>0, EXACTLY the same uniform Q exponential bounds and omitted-drive-link error hold as in the accepted dark-counter note, independent of J. They construct a conservative full-Fock semigroup at fixed J and normal invariant states. This verifies the needed hypotheses rather than assuming a formal infinite GKSL expression generates one. No core/extension/invariant-state uniqueness or mixing theorem follows.

## 2. Exact aggregate equation, including stimulation

For a joint state block diagonal in total dark R, let rho_r be the cavity operator obtained by tracing the r-sector dark block. It is positive, with sum_r Tr rho_r=1; cavity coherences remain. The aggregate equations close exactly:

dot rho_r=-i[K_r,rho_r]+gamma0 D[a]rho_r
 +gamma_in{[1+(r-1)/J]a rho_(r-1)a†-[1+r/J]{N,rho_r}/2}
 +gamma_R{(r+1)rho_(r+1)-r rho_r},                                 (3)

where K_r=Delta N+(U/2)N(N-1)+chi r N+i(Fa†-conj(F)a); the scalar omega_D r drops out of its commutator. The gain with rho_(-1) is absent. A finite total cutoff retains the real upper-shell drive truncation; no independent per-register cutoff or overflow reset is substituted.

To prove the gain coefficient, trace sum_j d_j† rho_(r-1) d_j and use cyclicity between its finite adjacent sectors. The trace equals Tr[(J+R)rho_(r-1)]=(J+r-1)rho_(r-1) after the dark partial trace. The loss coefficient follows from sum_j d_j d_j†=J+R. Register decay similarly uses sum_j d_j†d_j=R, giving(r+1)rho_(r+1). These are sector identities for the full operators, not a coherent-state closure or an assumption of independent occupancies. Infinite versions are obtained from the controlled finite-Q dynamics.

For an explicit positive lifting, the r-boson dark sector has dimension D_r=binomial(r+J-1,J-1). Let tau_r=I_r/D_r and lift each rho_r to rho_r tensor tau_r. Direct number-basis summation gives

sum_j d_j† tau_(r-1) d_j=(J+r-1)tau_r,
sum_j d_j tau_(r+1) d_j†=(r+1)tau_r.                               (4)

For r0 the first term is absent. For r≥1, sum_j d_j†I_(r-1)d_j=r I_r and rD_r/D_(r-1)=J+r-1. The second identity follows from sum_j d_j I_(r+1)d_j†=(J+r)I_r and (J+r)D_r/D_(r+1)=r+1. The Hamiltonian and anticommutator terms preserve this lifted class. Thus(3) has a genuine bosonic state realization, not just a positive formal probability recursion.

On the common cavity/counting-register Hilbert space, (3) is the register-diagonal sector of the explicit jump

A_J=sqrt(gamma_in) a S sqrt(1+R/J),                               (5)

with the same radiative/death jumps and diagonal Hamiltonian as the accepted counter note. The ordering in(5) gives source-sector factor sqrt(1+r/J). Its product A_J†A_J=gamma_in N(1+R/J). This defines one CPTP extension to off-diagonal register states; no physical identification of those register coherences with different-J bosonic Fock spaces is needed or claimed.

## 3. Quantitative dilute limit on the SAME register space

Let T_J be that common-space counter dynamics, and T_infty the accepted aS counter dynamics. This comparison is of coarse count/cavity states; it is NOT trace-norm convergence between unembedded physical Fock spaces of different numbers of modes.

At fixed total cutoff L, write A_infty=sqrt(gamma_in)aS. Then

||A_J||≤sqrt(gamma_in L)sqrt(1+L/J),
||A_infty||≤sqrt(gamma_in L),
||A_J-A_infty||≤sqrt(gamma_in L)[sqrt(1+L/J)-1].

For bounded jumps A,B, expand the gain and anticommutator terms to prove

||D[A]-D[B]||_(1→1)≤2(||A||+||B||)||A-B||.

The square-root factors cancel in the product, yielding

||G_(J,L)-G_(infty,L)||_(1→1)≤2 gamma_in L²/J,
||T_(J,L)(t)rho-T_(infty,L)(t)rho||_1≤2 gamma_in t L²/J.              (6)

Both finite dynamics are CPTP contractions, so Duhamel introduces no exponential amplification. This bound is safe, not claimed sharp. gamma_in0 makes the conversion difference exactly0; do not divide by gamma_in to evaluate that case.

For the SAME rho0 supported in Q≤M and any s>0,L≥M, the two uniform cutoff errors and(6) give

||T_J(t)rho0-T_infty(t)rho0||_1
 ≤4|F|t sqrt((L+1)M0(s))exp((c_s t-sL)/2)+2 gamma_in t L²/J,
M0(s)=Tr[rho0 exp(sQ)], c_s=(exp(s)-1)|F|²/delta.                   (7)

First choose L to make the actual cutoff error small, then J to meet the requested dilute error; this is an explicit finite-time approximation, not a bare R/J slogan. For example L growing as a sufficiently large multiple of log J makes both terms tend to0 uniformly on any fixed finite time interval. Strong convergence for each arbitrary trace-class initial state follows by finite-block density and contraction, with actual tail errors required for a quantitative bound. Initial states are compared on the SAME coarse-register space throughout.

Uniform stationary Q tails imply trace-norm relative compactness of a family of selected invariant coarse states as J→infinity. Any trace-norm subsequential limit is T_infty-invariant, using compact-time strong semigroup convergence on fixed inputs and contraction on the changing states. This does not establish uniqueness or a uniform O(1/J) bound between arbitrary stationary states. A mixing/stability theorem would be needed for that stronger assertion.

## 4. Exact drift/noise corrections at finite J

Define the actual conversion expectation

lambda_J=gamma_in[<N>+<NR>/J]≥0.

The exact first moments are

<N>'=-gamma0<N>-lambda_J+F<a†>+conj(F)<a>,
<R>'=lambda_J-gamma_R<R>.                                         (8)

The infinite amplitude equation has the additional stimulated dissipative correction

alpha'=-(iDelta+(gamma0+gamma_in)/2)alpha-iU<a(N-1)>
        -(i chi+gamma_in/(2J))<aR>+F.                              (9)

It follows by applying D[A_J]* to a: the result is-gamma_in a(1+R/J)/2. Other terms are as in the accepted counter proof. Equations for unbounded expectations require the same stated finite-particle/moment passage; they are not unrestricted bounded-observable identities.

At a selected stationary state all needed polynomial moments are controlled by the Q exponential bound. The local Lindblad number covariance becomes

D_NN=gamma0<N>+lambda_J,
D_RR=lambda_J+gamma_R<R>, D_NR=D_RN=-lambda_J.                      (10)

It is a positive sum of channel covariance matrices. At stationarity D_RR=2lambda_J and gamma_R<R>=lambda_J. These are local quantum-noise identities, not measured PSDs or literal fixed jumps of a conditional number mean. The same conversion event causes the negative cross correlation; stimulation increases its coefficient.

The relation to the coherent Falque-type rate has TWO explicit nonnegative terms:

<R>'=gamma_in|alpha|²-gamma_R<R>
       +gamma_in n_inc+(gamma_in/J)<NR>,
n_inc=<N>-|alpha|²≥0.                                               (11)

Thus a mean-field rate can arise in a jointly dilute and nearly coherent regime, but neither condition is proved by a static blueshift ratio or a nominal coherent pump. Higher cumulants and Cov(a,R) remain in the amplitude feedback. The optical drive can be coherent while the interacting output state is not.

At the SAME actual finite-J moments, the stimulated departure from the linear conversion law obeys

0≤lambda_J-gamma_in<N>=(gamma_in/J)<NR>
 ≤(gamma_in/(4J))<Q²>
 ≤gamma_in exp[R_*(exp(s)-1)]/(2J s²), s>0,                        (12)

where R_*=4|F|²/delta². The first inequality uses4NR≤(N+R)²; the last uses pointwise Q²≤2s^(-2)exp(sQ), followed by the stationary exponential bound. No derivative of an MGF upper envelope is taken. This bounds the law's extra term at the same state; it does NOT bound the change of<N> or of the whole stationary state as J changes without a mixing theorem. Relative error additionally requires a supported positive reference rate; at zero rate use the absolute bound/identity.

## 5. Full original physical work retained

This supplies actual bosonic conversion channels, an exact aggregate counting law, a state lifting, quantitative finite-time dilute approximation and explicit drift/noise corrections. It improves the earlier stipulated isometry model by deriving it as a controlled limit of one symmetric bosonic family. The preceding counting construction is retained separately as [the complete counting-register note](E1_QUANTUM_DARK_CONVERSION_COUNTER.md). It does not prove that the real material has J equivalent independent channels, equal Markov rates, negligible reverse processes or the assumed collective dispersive coupling. Nor does it derive those rates from a physical phonon/reservoir Hamiltonian, validate energy/detailed-balance assumptions, match mode/density/temperature/area, or determine the experimental effective J and observation window.

Next substantive construction is the actual material transition/bath model and normalization, including finite-temperature backconversion, then physical parameter and closure/error calibration, coupled spectra/transfer and a nonempty identifiable detection band. Use(7),(11),(12) only after the source-qualified inputs and requested absolute/relative error domain are supplied. Native/implementation/integrated verification and existing canonical closure remain separate ROOT-owned work. This construction does not close E1/D1, weaken any original charter or add a new gate/queue.

Complete original independent manual review: [scientific verification](reviews/E1_BOSONIC_DARK_DILUTE_LIMIT.md). The publication scientific lead accepts the original BUILD; this status records scoped mathematical acceptance and does not close the finding or publication.
