# Original L1 finite spatial normalization — review

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** Full original signed action/Haar/Berezin two-site control, D=3366=2922+0+444, coupled nonzero-separation insertion, source-dependent Z and explicit domains/errors, arbitrary coupling cancellations. All coefficients retained exactly.

**Original physical obligations.** No physical zero-source/vacuum susceptibility, full tensor/multiplicity/source/volume/operator/coupling matching or derived [0.1,10] window. Full arbitrary-volume original family remains the target; modes/matter and physical transport are distinct.

The construction author is publication_main55_independent_review; the complete independent scientific review is by publication_njl_target_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION](../L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md), [fixed source model](../source-models/L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md), [full independent review](../reviews/L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION-REVIEW -->
# Independent whole scientific review: original coupled L1 metric/source normalization

**Verdict: ACCEPTED as a whole manual finite-regulator milestone, within the declared domain. No mandatory mathematical correction found. Original physical B3 susceptibility/normalization/window, full tensor/state/volume/dynamics/transport, computational/native and publication gates remain BUILD.** This verdict covers the entire current construction, including the arbitrary-g1 cancellations and evaluated denominator; it is not acceptance of coefficients alone. Lead intake and future ROOT reference/runtime/source/native decisions remain separate.

I authored none of this L1 construction or its five predecessor notes. My earlier stopped E2 geometry author attempt is unrelated and provides no scientific authority here. The accepted object is CONSTRUCTION SHA256 `4e3759bc3c49bc0c9e6b6cde9f6020ac19f49726463af5be1e9472f94dc951a6`, under MODEL `829c0c498d6030c6b5f0678b950a30550b55d50044c14185f1adbe3050c42949` and author REPORT `734b076f3d4ab54e8f4181fec118b6b0e3258d63227908e298b48202bd301744`. All equalities below were independently checked by manual algebra, not numerical/symbolic evaluation, coefficient software or execution. No source was installed or changed.

## 1. Authority, chronology and actual depth

The original exact five-argv official FIRST ran once, cwd N, 2026-10-18T15:33:40.577053–15:33:40.801910 UTC, rc0, fresh=true, changed=[], stderr empty. Its actual channels are retained in first-check.json. Initial protection was actually captured 15:34:14.514428–15:34:16.034158: all33 unique bound-reference states/hashes matched; P/N/M tracked populations5186/4869/4906, all known dirty/untracked populations7/64/3, raw indexes separately from semantic stage bytes, HEAD/status/all refs, actual Git argv/rc/separate channels, bounded administrative paths and all five original owned absences. P/N/M HEADs are respectively d329a0a738ff20fefd3827cc2ef0d4a091e36219, d164ebf77208bdfd690cd73ded4e9f81a85409d8 and3fdd3f0960ba30ba95fadf959d9bef3a300fdaf0. No favourable baseline or packet refresh was substituted.

Before review proof reasoning I personally read the complete current MODEL; all FIVE original auxiliary, composite-source, one-site coefficient, one-site metric and exact-scalar-bubble notes and all FIVE complete independent reviews; the complete current construction/report/inventory; actual L1 manuscript; complete VestigialSusceptibility source; all noncomment GravitationalWaves declaration/proof bodies; and full carrying canonical functions/docstrings. The first aggregate manuscript display clipped part of the discussion tail; explicit392–536 recovery removed that reading gap. Unrelated canonical/GW prose is not claimed fully read. Exact predecessor hashes are preserved in the initial evidence, rather than inferring new acceptance from old verdicts.

I personally read official [Diakonov1109.0091v1 HTML §§V.1–V.6](https://arxiv.org/html/1109.0091v1), especially Eq26/30, four-block Eq32, EHC Eq34, measure35–37 and carrying gamma/link conventions. This is HTML source-level reading, not PDF/HTML byte equivalence, pixel QA, holding acquisition or a full-paper scientific audit. Author process/FIRST/FINAL and the scientific chronology/terminal comparisons were also read. Large raw protection/base64 inventories are data bindings, not claimed scientific prose reading.

The author MODEL save14:55:19.725781 preceded its first persisted new scratch15:03:16.270267. Author evidence retains the initial unresolved-D save15:13:11.953677, intermediate2922-plus-B save15:20:50.990019, and completed-B save15:24:58.869096. I do not reinterpret those as an invented exact mental-start timestamp or erase their initially incomplete stages. The author's original FINAL rc1/owned-files and actual shared wt1 movement5e491ce4→56137fba plus directory-stat changes remain UNKNOWN-actor exceptions, not a universal administrative pass. They do not imply a changed physical model or scientific acceptance. The present reviewer FIRST remains distinct. My first persisted completion record is15:41:50.994978; it does not invent an earlier exact mental review-start time.

## 2. Full original model and saturation/cancellation audit

The four-block Eq32 with alpha1/2 really gives the longitudinal C=A†−B expressions(1) on the two-site torus. At direction1 the forward/backward links are independent A,B although the endpoint is the same neighbouring site. At directions2–4 each site's self-neighbour blocks ADD to the anticommutator(2). Link inversion sends that anticommutator to its negative. All8 links/16 SU2 measures,16 Grassmann generators, original1/4, periodic boundaries, arbitrary finite complex g1,g2 and the full action are retained. Restricting evaluated sources to H0,11/H1,11 is not changing the action. The arbitrary-L family is preserved pointwise, but this calculation proves no arbitrary-L coefficient or infrared approximation.

Counting individual generators gives S4x=(7,1), Ax=(4,0), Bx=(3,1), and each longitudinal G insertion=(2,2), with sites reversed for x=1. Thus2q+p+l=4. I checked every permitted source-dependent class: q2 same-site oversaturation and opposite-site unused transverse-link oddness; q1,p1,l1 and q1,l2 oversaturation; q1,p2 forcing S4x Ay By and at least two unused odd transverse T links; p1,l3 requiring nonexistent(2,2); p2,l2 forcing A0A1 or B0B1 with an unused odd transverse T; and p3,l1 forcing A0B1² or A1B0² with A's own unused transverse links. Metric sources involve only longitudinal links and cannot invalidate these oddness arguments. This exhausts the possibilities, so all g1 terms and all lower-degree source-dependent interaction coefficients vanish on this slice, without setting a coupling to zero.

For p4,l0, solving site counts leaves exactly A0²A1², A0A1B0B1, B0²B1². Their multiplicities divided by4! are1/4,1,1/4. No omitted p4 site pattern can satisfy both eight-generator site bounds. Consequently Z=Dg2^4+Q4, with D requiring the full contractions rather than a borrowed one-site constant. The one-site V1 partition polynomial does not factorize this V2 integral.

## 3. Independent full D=2922+0+444 calculation

On this torus the reverse(1,j) plaquette X A Y† A† is the dagger of A Y A† X†, including when the transverse extent is one. Combining both epsilon orders and the antisymmetric internal trace cancels the action1/4, giving exactly the signs in(7a). Internal gamma traces give L_j4=2(c_j+d_j), L_jm=−2epsilon_jma(c_a−d_a). Hence ||L||F²=16(|c|²+|d|²). This checks the original gamma, epsilon and curvature normalization rather than postulating a covariance tensor.

Each Ax,j is odd in its three own transverse centers and the single opposite center j; each Bx,j is odd only in own center j. Flipping all three centers at0 makes A0A1B0B1 odd. For A0²A1², opposite-site parity kills j≠k inside each squared A; for B0²B1² own-center parity does the same. These are center flips, distinct from the earlier inversion argument. The mixed contribution is exactly zero, not a numerical nearzero.

The old two-row T fourth derivative is 4b deltaCE deltaDF+2c(deltaCD deltaEF+deltaCF deltaED), with b13/32,c1/16. Antisymmetric contraction is (4b−2c)||L||²=3||L||²/2; the second c term enters with a MINUS sign. For equal missing directions the local T pairs are independent of the two curvatures. Conditional conjugations of X,Y by independent A,B give f=x0²y0²+(1−x0²)(1−y0²)/3. Haar moments Ex0²=1/4,Ex0⁴=1/8 give Ef=1/4,Ef²=5/72 and E r0r1=1−2Ef+Ef²=41/72. Separate chiral sectors give

I A0j²A1j²=(9/4)256[2(41/72)+2(9/16)]=1304.

For different missing directions, Ω0j appears in neither T nor the opposite curvature; integrating it makes P0 independently Haar even after conditioning on all other links. The analogous Ω1k makes P1 independently Haar. Thus E L L=2(deltaCE deltaDF−deltaCF deltaDE), E||L||²=24, each saturated site gives36, and the product is1296. The complete A contribution is(3·1304+6·1296)/4=2922. Correlated same-direction curvatures were not silently treated independently.

For B, a transverse SU2 commutator has each imaginary component's second moment2/9. From the explicit chiral L formulas the sum/difference cross terms cancel and E L_CD L_EF=(16/9)(deltaCE deltaDF−deltaCF deltaDE). This is not the independent-Haar value2. Its missing transverse T link is independent of curvature and longitudinal links. Summing the nine surviving B0j²B1k² terms with their1/4 produces(9/4)(16/9)²=64/9 multiplying I R0R1.

I checked K(7f) directly. For local A=xi l−eta r and Bj=eta sigma_j r+xi sigma_j l, the two embedded-Pauli anticommutators of gamma_j are i deltaij A ±epsilonijk Bk, while those of gamma4 are Bi. Multiplying their two chiral contributions with −1/16 gives Kjk=[delta_jk(A²−B²)+BjBk]/8, Kj4=−iABj/8,K44=−B²/8. Since w=(B,−iA), this is KDF=(wD wF−deltaDF w²)/8, traceK=−3w²/8 and R=−[2w²T²+(wT)²]/8. No ordinary positive random-spinor covariance was used.

Endpoint Spin4 rotations preserve the local T/w scalar contractions and Berezin orientation while reducing each quaternion block of C to rI/sI. Only this insertion symmetry is needed, not full-action gauge covariance. The degree-four reduced coefficient is even separately in r,s and chirality symmetric: F=u(r⁴+s⁴)+v r²s². Haar r²,s² moments2/5 give I F=10u+4v. These polynomial probes do not replace the physical Haar ensemble.

For C=I, the actual8×8 source determinant is the squared Schur expression(7i). Pa=i gamma5 gamma_a satisfies Pa²=a²I and gamma_J Pa gamma_J=i gamma5[J²gamma_a−2(aJ)gamma_J], fixing its sign. Its relevant homogeneous P11 gives the following independent differential audits in four dimensions:

- Delta_a Delta_b P11=(3/4)J⁴; Delta_J² J⁴=192, giving144.
- Delta_a P11=(3/32)b²J⁴; D_bJ²(b²J⁴)=48J² and Delta_J J²=8, giving36. The exchanged mixed operator also gives36.
- D_aJ²P11=−(3/8)b²J²+(15/4)(bJ)²; D_bJ²(b²J²)=16 and D_bJ²(bJ)²=40, giving−6+150=144.

The R0R1 weights4,2,2,1 and1/64 therefore give F11=(576+72+72+144)/64=27/2. The operators were checked, not merely the displayed final sum.

For C=diag(I,0), reordering both chiral site rows/columns yields X with blocks iqa,qL/4,−qJ/4,iqb. The complementary block is diag(I,−I)X†diag(I,−I), so the full determinant is(detX)² after real polynomial continuation, without a hidden Berezin permutation sign. The trace term h=aᵀMJ has M=mI+N, m=bL, N skew/selfdual, MᵀM=b²L²I, TrM=4m,TrN²=−4(b²L²−m²). These identities retain the epsilon part of h. Dropping that part would change the audit.

Specifically Delta_a h²=2b²J²L² and Delta_a P10=(3/32)b²J²L² give the first three unweighted operator values48,12,12. For the last,

D_aJ² h²=2[(TrM)²+TrM²]=48(bL)²−8b²L²,
D_bL² h² after this operation=48·40−8·16=1792.

The base term contributes2 and h²/64 contributes28, so the fourth value is30. Thus F10=(4·48+2·12+2·12+30)/64=135/32. Parallel e4 sources independently reduce the two full determinants to(ab−J²/16)^4 or(ab−JL/16)^4, whose required cross coefficient is3/128. This verifies signs/normalization in both Schur controls. Now u135/32,v=27/2−270/32=81/16, I F=999/16, DB=(64/9)(999/16)=444. Including the mixed zero and A2922 gives D=3366. This completes the full denominator proof on the stated slice, not just source-only algebra.

## 4. Source determinant, Haar moments and all insertion factorials

The full source matrix has off-diagonal blocks BJL and−BJL†, and the two4-component block exchange has positive sign; the determinant is |detBJL|²/4^8 for real sources. Source-only independent endpoint rotations justify aligning J,L for the Haar average. They do not assert gauge invariance of the full action. For the difference of two independent unit quaternion vectors, a=rL²=2−2dot has moments2,5,14,42 from E dot²=1/4,E dot⁴=1/8. Chiral radii are independent and the relative orientation has E tau²1/4,E tau⁴1/8. With c² averaged as ab/4 and c⁴ as a²b²/8, expanding(10) squared gives:

v⁴:25;
v³w:2(28+28+25)+(28+50+28)=268;
v²w²:50+[84+50+112+50]+212=558.

All odd orientation terms vanish. Thus F8 denominator65536 is4^8, not4^4. In four dimensions Delta^m R^m|0=4^m m!(m+1)!. Dividing by m!n! from exp(HU+KV) gives Q4 coefficients375/32,201/4,2511/32. In particular the m3,n1 factor12288/65536=3/16 multiplies268. Multiplying source coefficients by3!1!,2!2!,4! gives603/2,2511/8,1125/4 respectively. This verifies every factorial and the actual mixed separated insertion. A factorized product of two V1 quadratic metric-source polynomials has no H³K term, so it cannot reproduce this witness.

## 5. Norm, zero/refusal, connected response and error domains

The entrywise Grassmann l1 norm is submultiplicative. Each gamma-times-link has at most8 nonzero unit-bounded entries; four T blocks divided by4 give ||T||1≤8 even when endpoints coincide. Trace modulus≤4 and the actual two-site epsilon/internal populations give ||S2||1≤49152, ||S4||1≤196608. Hence |D|≤49152^4/24 before using its sign. This is conservative signed coefficient control; it does not posit a positive probability law.

I differentiated the exact quartic rather than treating a large-source approximation as exact. At H=K=t: q6477/32,d4923/8,ZH=ZK=2qt³,ZHK=dt², and kappa=4−d/q=2072/2159. With z=3366g2^4/(qt^4), (18) follows. On |z|≤e<1, |Z|≥q|t|⁴(1−e). The first ratio change is bounded by(d/q)e/(1−e); the second by4(2e+e²)/(1−e)². This is exactly E(e), with no omitted source derivative of an interaction remainder because all that remainder is constant here.

For real |t|≥max(1,[100Dmax|g2|⁴/q]^(1/4)), e≤1/100, E≤4/99+804/9801<3/16, kappa>3/4, giving ReC01<−9/(16t²). Couplings were not chosen to make this true: arbitrary complex g1,g2 remain covered by the absolute bound. At g2=0 it is an exact control, not the selected model. Directly differentiating logZ(t,t) gives chiO=t^-2[12/(1+z)−16/(1+z)²] and its stated error<1/t²; hence RechiO<−3/t² on the same domain.

For real sources the completed-square Q4 expression follows under u=H+K,v=H−K, including the negative mixed−522 coefficient and compensating24816/5 term. Therefore Q4>0 away from H=K=0; real g2 gives positive normalization except the stated simultaneous zero. For complex parameters, the exact forbidden locus is3366g2^4+Q4=0; no global logarithm is assumed. At g2≠0 all selected first/second source-zero metric derivatives vanish. The mixed fourth connected derivative is(603/2)/(3366g2^4)=67/(748g2^4), since log's higher powers start at degree8. The exact cross-response numerator t²[d·3366g2^4−kappa q²t^4] has the stated small/large real-source sign transition and zero-source value0. Negative Hessian at a nonzero-source point and finite normalized algebra are not a physical positive-measure vacuum or a thermodynamic obstruction.

The modulo4 Grassmann selection also proves odd-T and TG insertions vanish generally, but not every G mean or TT entry. At nonzero H the selected mean is generally nonzero. Old rank10 joint26 results cannot be moved to this joint52 response. Singular cofactor/auxiliary machinery and the complete signed W remain required for any auxiliary cross-check; h is not T/G.

## 6. Literal gauge/source convention and physical normalization audit

Actual official HTML Eq26 places the four plaquette matrices in the literal left-to-right order fixed by MODEL; Eq30 transforms each link by V_endpoint Omega V_start†. On the declared torus, take A=I,X=Omega0,2=I,Y=Omega1,2 and V0=V,V1=I. The self-loop X remainsI, A'=V†, and the product really becomes V†YV, rather than the presumed base-site VYV†. With V=exp(i pi sigma3/4),Y=i sigma1 these are+i sigma2 and−i sigma2. The statement agrees with the displayed primary convention, and the fixed model has not silently reversed its plaquette. The older review's broad gauge language does not override this explicit new limitation. This ONLY checks a literal plaquette/basepoint convention: it does not prove noninvariance of the fully summed action, impossibility of a consistent physical convention or a no-go for the original programme. Those calculations remain owed.

For the explicitly conditional physical candidate Q=ZQ G/a², a^4 jQ=HG gives H=a²ZQj. A scalar source through a symmetric projector P requires the factor(2−delta_munu) on once-pair off-diagonal coordinates; each response insertion must carry its own weight. Taking two such factors gives a^4(ZQ/a²)²=ZQ² in the Fourier response sum. With translation invariance, Var(sum a^4Q)/Vphys equals the integrated response; the average's variance has one further division by Vphys. These are algebraic connected ratios and need not be positive. Units [ZQ]=L^(2−Delta),[chiQ]=L^(4−2Delta) agree: the dimensionless bare-Delta2 scalar bubble, a Delta3 quadratically divergent response and a dimensionless metric's L^4 response are distinct. These are necessary source bookkeeping identities, not a derived physical operator, source calibration or tensor projector.

The actual canonical/log bubble is still the IR log and is not the exact positive two-propagator cutoff integral for every positive mass. The note correctly retains the earlier exact scalar remainder and does not reidentify it with the physical metric response. Vestigial source's+8,32/8, supplied u_g/c_D and W6 RPA identities are arithmetic/supplied-input structures, without an original g1/g2/ZQ matching. Likewise actual GW c*sqrt(chi), adopted1/10,10 and gamma*omega do not derive a microscopic value, frequency units or transport coefficient. A response arbitrarily close to its RPA pole is not uniformly bounded by positive inputs alone. Canonical/native factual and consumer qualification debt remains; I changed none and did not turn the manuscript's accurate disclaimers into B3 closure.

The new finite spatial component does not supply the full52 tensor, all separations, ordered zero-source state, thermodynamic/continuum error, constrained graviton/matter propagator, physical source renormalization/operator mixing/contact subtraction, cutoff/numerator/multiplicity matching, g1/g2-effective coupling map, or the requested [0.1,10] as a RESULT. Those are explicit full-strength next constructions, not defeated routes or operator-approved deferrals. L1 susceptibility/window, microscopic dynamics and physical transport/frequency remain three separate duties; shared D1/E1/E2 dispersive matching is separate again. All21/B1–B8/D12 obligations remain unwaived.

## 7. Independent assurance boundary and disposition

The proposed reference is concrete DATA UNRUN: two independently ordered exact Q(i) wedge/top-coefficient implementations for F10/F11, a direct original three-contraction Haar reference preserving all16 SU2 factors, and separate2922/0/444/3366 comparisons. The unreduced degree≤24 follows from at most four plaquette link factors plus two T link factors per S2, repeated four times. The even Haar table population for four quaternion coordinates with total half-degree≤12 is binom(16,4)=1820 per factor, not the full polynomial population. The balanced Grassmann population is sum binom(8,k)^2=binom(16,8)=12870. These numbers do not claim measured memory, runtime or coefficient-bit populations. The8GiB/8CPU-hour envelope is prospective, with actual bit lengths/populations/elimination order and resource failures to be recorded rather than hidden. Any optional outward-rounded quadrature requires full integration-error intervals and cannot certify exact zero by a floating nearzero.

Controls correctly retain old one-site source/off-diagonal coefficients, independent full-W auxiliary agreement, removal of cross-site coupling destroying H³K, an odd Berezin-orientation swap reversing unnormalized saturated coefficients, and a T1/4→1/2 poison scaling the degree-eight saturated result by256. Changing the radial fourth moment5→4 changes the v⁴ source coefficient25→16, so it is an effective Haar poison. Separate1304/1296 checks are necessary because mere plaquette reversal can preserve even moments. All g1 terms must remain until the actual cancellations are checked. These are justified assurance targets, not performed poison tests. A future executable packet must bind exact source bytes/modes/nsmtime, apply actual poisons, retain actual red receipts, restore precisely and record green receipts and origins; this review grants none of those executions. The present mathematical verdict rests on the explicit manual rederivations above, not on an unrun reference.

No mandatory scientific repair of the declared whole finite-regulator milestone was found. Accept its exact normalized finite-control/source-response results as a partial substantive increment under the original obligation. Do not close B3 or promote G4/G5/G11/main, native/kernel/reference or human publication gates. In particular existing main39 failures, CI84-of85 versus required85 floor, CI_SKIP, literalVerify4 failures and separate Lean10834/NJL200 receipts are not altered by this review. The pending ADW execution question grants nothing.

## 8. Final-check and preservation procedure

This complete review/evidence/process is written BEFORE the one original FINAL. FINAL has not yet run at this report-save point. Its literal argv/cwd/UTC/return code and separate channels will be saved once in final-check.json, followed by genuine full terminal reference/P/N/M tracked+known dirty/raw+semantic index/HEAD/status/refs/admin capture and exact comparison in evidence/process. Any actual drift will remain explicit with actor UNKNOWN; no source reset, packet refresh, inferred waiver or all-administration-green assertion is made in advance. Only the five assigned ignored reviewer leaves may be written. After terminal capture/freeze no further reviewer edits occur. Lead intake is required and source/application/runtime/native/reference/main authority remains ROOT-owned.

Pre-FINAL process exception: a display-only inspection of initial evidence used commands[0] although commands is a dictionary and returned actual KeyError: 0/rc1. It made no source/index/packet change and invoked no continuity check. The exception is retained in evidence; dictionary keys were then inspected directly without refreshing the original baseline. This does not change the scientific verdict.

<!-- END SOURCE137-EXACT-L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION-REVIEW -->
