# KV2008 varying-G forward model and declared observable reconstruction

Status: **SCOPED MANUAL MATHEMATICAL ACCEPTANCE** of the source-selected 2008 varying-G homogeneous background, constrained local stability, declared observer reconstruction and finite-window error route. See the [complete original independent review](reviews/KV2008_VARYING_G_FORWARD_MODEL.md). This selects one published dynamical branch, distinct from the 2011 plateau scenario and the conditional constant-G H5 bath. No numerical run, physical viability, data fit, perturbation theory, native proof, scientific deferral, gate or publication acceptance follows. The original prospective review language in section6 records construction-time sequencing; that scoped review is now complete, and the next substantive evaluator/calibration/perturbation/likelihood duties remain owed. Publication scientific lead retains the full forward-model/likelihood obligation; ROOT retains actual runtime/native and integration allocation.

## Source and scientific target

The lead personally read the carrying action, field-equation, FRW, asymptotic and extrapolation sections of [Klinkhamer–Volovik 2008, arXiv0806.2805v7](https://arxiv.org/pdf/0806.2805v7), especially Eqs2.1,2.6–2.8,4.1–4.15,5.1–5.7,5.14–5.18 and footnote4. Official extracted text was inspected in sequence. Two attempted web PDF screenshots failed, so no pixel inspection is claimed. This reading distinguishes the varying gravitational coupling from the separate constant-G phenomenological H5 bath previously constructed. The published matter action is minimally coupled and independent of F. Its matter is conserved; appending an exchange term changes this model.

The independently read carrying sections of [the 2011 plateau review, arXiv1102.3152v4](https://arxiv.org/pdf/1102.3152v4), §§5–7 and AppendixA, do not specify a full calibrated transition dynamics/likelihood. The present note does not replace that distinct scenario with the 2008 equations. The original Phase5x research and Phase5y attempted constructions remain credited historical work, not evidence of a selected current empirical result. No contemporary survey numbers or significance are adopted from those old reports.

Original root1 acceptance still requires a physically selected regime, units/parameters/initial state, late-time expansion and perturbation forward model, controlled numerical prediction and same-data likelihood. This note pays down the concrete background/observable part for one source-selected model. It does not establish infeasibility of the family or discharge empirical/perturbative obligations.

## 1. Action, units and actual dynamical potential

Use the source's metric/curvature conventions. The four-form amplitude F has dimension mass²; its action contains R/(16πG(F))+epsilon(F)+L_m. Eliminating the four-form equation at a FIXED integration constant mu gives the effective potential epsilon(F)-mu F. Off equilibrium this differs from epsilon(F)-F epsilonPrime(F). No derivative of the latter is substituted into the former.

Fix F0>0, chi>0, s>0 and the source ansatz

epsilon(F)=(-f²+f⁴/3)/(2chi), f=F/F0>0,
G(F)^(-1)=s F0 f,
t_* = sqrt(chi F0), tau=t/t_*, h=t_* H,
u=chi F0 mu, sigma=3s/(8pi)>0,
V(f)=chi rho_V=-f²/2+f⁴/6-u f.

Here u is constant, and primes below denote d/dtau except V_f,V_ff. Equilibrium has u0=-1/3. V_f=-f+(2/3)f³-u and V_ff=-1+2f². At u0, V=f(f+2)(f-1)²/6, nonnegative on the selected f>0 branch. f=0 is excluded because G is singular there. The scale t_* and source sigma must remain in physical calibration; setting sigma1 is a dimensionless convention, not a measured Planck period.

## 2. A nonsingular constrained forward system

Let m=chi rho_dust, r=chi rho_radiation, with pressure0 and rho_radiation/3. Splitting source perfect matter into these TWO separately conserved fluids is an explicit background extension with no exchange. A single source fluid is recovered by setting one density0. Let p=f'. Define A(f,h)=V_f/sigma-2h². Evolve

f'=p,
h'=A,
p'=h p-2 f A-(3m+4r)/sigma,
m'=-3h m,
r'=-4h r,
x'=h, with x=ln a.                                                   (1)

Impose the Friedmann constraint

C=sigma(h p+f h²)-V(f)-m-r=0.                                         (2)

These equations contain no division by h, so their time-domain evolution does not create a spurious singularity at a turning point. All vector-field components are polynomials in the state for fixed finite u and positive sigma. Thus finite initial data have a unique local solution. It is physically admissible only while f>0; a redshift chart additionally requires h>0.

Proof of constraint propagation: differentiating (2), substituting (1), and grouping terms gives

C'=sigma[h' p+h p'+p h²+2f h h']-V_f p+3h m+4h r
   =[sigma(h'+2h²)-V_f]p=0.                                         (3)

Consequently exact initial C0 implies exact Friedmann consistency. Conserved positive matter has m(tau)=m0 exp(-3(x-x0)) and r(tau)=r0 exp(-4(x-x0)); nonnegative initial densities stay nonnegative in either time direction on the existence interval.

Equivalence to the source equations is explicit. Maxwell is h'+2h²=V_f/sigma. The00 equation is (2). The spatial Einstein equation in these units is

f(2h'+3h²)=3V/sigma-r/sigma-2h p-p'.                                 (4)

Using (1), its right side equals2f h'+3(V+m+r)/sigma-3h p, which equals the left side by C0. Conversely the Maxwell,00, spatial and conservation equations yield (1) without division by h. The second-order f equation is therefore not an independently postulated canonical scalar equation. At a point h0=0, constraint requires V(f0)+m0+r0=0; it cannot be enforced by dividing by h0. For h0≠0, consistent initial p0=[V(f0)+m0+r0-sigma f0 h0²]/(sigma h0). A free five-parameter initialization that ignores (2) is inadmissible.

The physical vacuum obeys p_V=-rho_V, but V'=V_f p=sigma(h'+2h²)p need not vanish. The varying-G gravitational sector supplies the required consistency. Bare vacuum w=-1 does not make it a separately conserved dark-energy fluid in constant-G GR.

## 3. Exact perturbed-mu de Sitter branch and its stability

For a matter-free expanding stationary point, p=m=r=0, h=h_*>0 and f=f_*>0. Maxwell and constraint give V_f=2sigma h_*² and V=sigma f_* h_*². Eliminating h gives

f_* V_f-2V=f_*(f_*³/3+u)=0.

Thus

f_*=(-3u)^(1/3), h_*²=f_*(f_*²-1)/(2sigma),                         (5)

and a positive expanding stationary point on this ansatz exists exactly for u<-1/3. At u=-1/3, f1,h0 is Minkowski. For -1/3<u<0 the positive candidate has negative h² and is not a real de Sitter solution; u≥0 gives no f_*>0. These are statements about this explicit ansatz, not the whole q-theory family.

This is also a locally asymptotically stable constrained branch. In vacuum, the linearized C0 condition is delta p=h_* delta f-2f_* delta h. The physical two-variable linearization (delta f,delta h) therefore has matrix

[[h_*, -2f_*], [V_ff(f_*)/sigma, -4h_*]].                            (6)

Its trace=-3h_*<0 and determinant=2f_*³/sigma>0. Its discriminant is

9h_*²-8f_*³/sigma=-f_*(7f_*²+9)/(2sigma)<0.

The eigenvalues have real part-3h_*/2. Dust and radiation add decaying modes-3h_* and-4h_*; their forcing makes the constrained Jacobian block triangular after eliminating p through h>0. The smooth finite-dimensional linearization theorem gives local asymptotic stability on C0. The open f>0,h>0 neighborhood can be chosen to retain physical signs; nonnegative fluid subspace is invariant. This proves a local basin and not a global attractor from arbitrary early data, a parameter fit or physical realizability of the phenomenological G(F) ansatz.

Near Minkowski u0, first-order vacuum equations give delta f''+(2/sigma)delta f=0 and delta h'=delta f/sigma. Thus the induced frequency squared in physical time is2/(sigma chi F0). This arises from the coupled gravitational equations; epsilonSecond by itself is not this normalized mass². Large-time averaging/acceleration and clustering require their own analyses; no radiation-to-dust/DE transition is inferred from a period alone.

## 4. A specified redshift observable, not a bare-vacuum CPL assignment

Take a0=1 and a present expanding point h0>0. On a connected h>0 interval set x=ln a=-ln(1+z), E(x)=H/H0=h(x)/h0. The source matter action is minimally coupled, so these Jordan-frame expansion/redshift variables are the ones used here. Local measured-G identification and perturbative astrophysical calibration remain extra physical requirements.

If the reference constant-G observer uses the present cosmological G(F_present), its density parameters are

Omega_m0=m0/(sigma f0 h0²), Omega_r0=r0/(sigma f0 h0²).                 (7)

This normalization follows from M0²=[8piG(F_present)]^(-1)=sF0f0/(8pi), H0=h0/t_* and physical rho_m=m/chi. Unlike a fixed-G Friedmann identity, present V+m+r need not equal sigma f0h0²: the hp term is present. No conventional sum rule is silently imposed on V alone. If observationally calibrated reference densities differ, they must be declared separately as Omega_m*,Omega_r*.

For explicitly declared fixed reference densities define

D(x)=E²-Omega_m* exp(-3x)-Omega_r* exp(-4x).                         (8)

On any interval D>0, the observer's effective separately conserved dark-energy reconstruction is

w_app=-1-D_x/(3D).

It is a diagnostic of this declared GR subtraction, not p_V/rho_V of the source. Its CPL tangent at a1 is

w0=-1-D_x(0)/(3D0),
wa=[D_xx(0)D0-D_x(0)²]/(3D0²).                                     (9)

Proof: w(a)=w0+wa(1-a) has w_x(0)=-wa; differentiate the stated w_app. The required derivatives are supplied by the actual forward equations, with A=h' and B=h''=V_ff p/sigma-4h A:

(E²)_x=2A/h0²,
(E²)_xx=2B/(h h0²),
D_x=2A/h0²+3Omega_m* exp(-3x)+4Omega_r* exp(-4x),
D_xx=2B/(h h0²)-9Omega_m* exp(-3x)-16Omega_r* exp(-4x).               (10)

Use these only on h>0,D>0; as D approaches zero the diagnostic becomes ill conditioned, and h0=0 gives no H0-normalized chart. Negative D is a refusal of this positive-DE reconstruction, not a numerical zero to fill. At the exact matter-free stationary branch with zero reference densities, E1,D1,A0,B0 give w0=-1,wa0. Away from that branch (9) depends on actual initial data and reference subtraction; no universal numerical pair or exclusion follows.

Distances for flat background and standard minimally coupled light with c1 are

D_H(z)=1/(H0 E(z)), D_M(z)=H0^(-1) integral_0^z ds/E(s),
D_A=D_M/(1+z), D_L=(1+z)D_M.                                       (11)

These are instantaneous-background relations. If ultrafast oscillations are observationally unresolved, replacing them by an averaged H requires a separately controlled averaging theorem and measurement response. In particular average(1/H),1/average(H) and1/sqrt(average(H²)) must not be interchanged. Sound horizon, SN absolute calibration/evolution, lensing/growth, CMB transfer and detector effects are not supplied by (11).

## 5. An explicit finite-window numerical error contract

The following is a mathematical route for a future validated solver, not a claim that one ran. For fixed u,sigma and a convex box |f|≤F,|p|≤P,|h|≤H,|m|≤M,|r|≤R, let

Amax=(F+(2/3)F³+|u|)/sigma+2H².

An infinity-norm Jacobian bound for the five-state time vector field in (1), excluding x, is

L=max{1,
  (1+2F²)/sigma+4H,
  2Amax+2F(1+2F²)/sigma+H+P+8FH+7/sigma,
  3M+3H, 4R+4H}.                                                   (12)

Proof: rows respectively bound f',h',p',m',r'. For p', partials are-2A-2fV_ff/sigma, h, p+8fh, -3/sigma and-4/sigma. Every row sum is bounded by (12). Use F,P,H,M,R≥0 and finite, sigma>0. A vector-field magnitude bound is

Bmax=max{P,Amax,HP+2F Amax+(3M+4R)/sigma,3HM,4HR}.

For a redshift-domain solver where h≥h_min>0, evolve z_x=Ftime(z)/h. Its Jacobian row sum is bounded by

Lx=L/h_min+Bmax/h_min².                                             (13)

This fixes the independent variable: a time-trajectory error alone does not certify values at the same redshift. Fix identical exact u,sigma and h0 normalization. Let an approximate x-trajectory have initial infinity error≤e0 and continuous residual≤eta, certified throughout the common box. Gronwall gives for |x|≤X

e(x)≤e0 exp(Lx|x|)+eta [exp(Lx|x|)-1]/Lx.                           (14)

If needed Lx0 is interpreted by its continuous limit eta|x|; the bound above has Lx>0 when the box/chart exists. To turn (14) into existence coverage, enclosure tubes must stay inside the certified f>0,h>0 box up to the requested boundary; local existence and continuation then apply. The bounding box and residual are obligations to prove, not inputs accepted because a receipt says so. Constraint drift should also be bounded from (2); small drift alone cannot establish trajectory accuracy.

If both E and approximate E are bounded below by a proven E_min>0 at the SAME redshift and their h error≤e_h(z), then

|1/E-1/E_tilde|≤e_h(z)/(h0 E_min²),
|D_M-D_M_tilde|≤[H0 h0 E_min²]^(-1) integral_0^z e_h(s)ds.            (15)

D_H,D_A,D_L inherit their explicit factors. Parameter/calibration errors, validated quadrature, roundoff, event/refusal handling and physical modeling/averaging uncertainty must be added separately; (14)–(15) do not certify ordinary floating output or a confidence interval. CPL diagnostics further require error enclosures for D,D_x,D_xx and a positive D margin; no unsupported derivative estimate is inferred from just a state error.

## 6. Ownership, attempt evidence and next substantive action

This is an accepted-author assignment by the publication scientific lead under existing KV root1, with full independent nonauthor review required next. It constructs a source-selected, constraint-preserving background rather than merely documenting an omitted fit. Actual numerical implementation is not authorized by a manual note; ROOT must allocate the isolated target and review the original objective.

The next concrete build is an actual validated forward evaluator for (1)–(2) and its declared h>0 redshift chart, covering the published equilibrium and perturbed-mu initial examples plus exact stationary controls (5), refusing invalid constraints/signs and demonstrating residual/refinement/error envelopes. Original sigma/u/t_* and present-state calibration must be explicit, as must the averaging treatment for ultrafast branches. After this, carry perturbations and source/parameter selection into a same-data cosmological likelihood; do not treat an ordinary CPL tangent as a fit or DESI significance. The distinct2011plateau transition mechanism and other shared microscopic/ADW magnitude obligations remain owed in the canonical disposition map. Accurate manuscript corrections stay; no affected finding or bundle closes from this manual increment.
