# Reviewed-source delivery: Full charge-active bilayer Onsager carrier

This is a documentary transport of the complete original manual construction. Its dated author statements about awaiting review describe the original author snapshot. Subsequent genuinely nonauthor scoped manual mathematical/model acceptance is preserved in the [complete original review](reviews/E2_BILAYER_CHARGE_ENERGY_ONSAGER.md); the [complete original source/model contract](source-models/E2_BILAYER_CHARGE_ENERGY_ONSAGER.md) retains model and chronology qualifications. Lead intake 52eb57af accepts that stated manual scope only. No device calibration, implementation, runtime/native, G4/G5/G11, finding closure, integration/main or publication acceptance follows. Full original microscopic/collision/current/contact/scattering/state/noise/independent-route/calibrated nonempty-band BUILD remains owed.

<!-- BEGIN EXACT ORIGINAL CONSTRUCTION -->

# E2: bilayer charge–energy–momentum mode and normalized acoustic current

Author construction for fresh independent scientific review. Manual mathematics only; no numerical evaluation, model import, test, native proof, runtime or source installation. This extends the earlier assumed one-component acoustic carrier by deriving its parameters and current overlap from a declared two-band bilayer kinetic carrier. It does not finish the physical bilayer, contact, scattering, quantum-state, calibration or usable detection-band obligations. All those original BUILD objectives remain owed at full strength.

## 0. Source choice, sequence and target boundary

This r2 is the coherent full-strength author repair of immutable r1 construction43094cca, full independent review269c928f and lead-requires-repair30ee6a81. That review required completion of the general charge-active Onsager current, affinity and work/entropy closure, not removal of its charge sector. The original eighteen numbered groups are retained with (5)–(6) repaired, explicit additional subgroups and carefully stated special-sector domains. There is no whole scientific acceptance yet. Fresh genuinely nonauthor complete scientific review follows.

The NEW SOURCE_MODEL was saved at2026-10-18T08:45:18.939307+00:00 before new r2 mathematical scratch. This does not cure r1's real provisional reasoning before its model save at08:13:02.296858UTC or lead's older conceptual scratch. The complete original rejected note, report, review, checks, source-reading and evidence mistakes remain immutable. I authored r1 and this successor and cannot independently accept either. Historical peer review of the different earlier one-component carrier is not self-review authority.

Primary source constraints, personally read in the carrying main and supplementary sections:

* [Geurs et al., arXiv:2509.16321v2](https://arxiv.org/html/2509.16321v2): parabolic AB bilayer, fourfold degeneracy, a unipolar model, deliberately slow gate response, hot-bias thermal depletion and the limitations of the nozzle reduction. S9 differentiates at fixed entropy per particle, whereas the main text calls the sound relation isothermal. S17's displayed quantity has the units of pressure divided by mass; S13/main pressure and S19 momentum flux distinguish them. The main 3b viscosity sign differs from S3/S22/S26. Here dimensions and positive dissipation fix our conventions. These are source-form inconsistencies, not an allegation about executable repository behavior. No numerical device parameter is adopted from the source as a qualified measurement here.
* [Nguyen, Wagner and Simon, arXiv:1901.07039](https://arxiv.org/pdf/1901.07039): the low-energy parabolic kinetic carrier, normal/intraband and interband currents, screened collision interactions and conservative electron–hole momentum drag. Its DC simplifications do not establish finite-frequency interband suppression, imbalance conservation, fast thermal locking or our target's rates. The currently read HTML Eq107 prints a product momentum condition inconsistent with its Eq108 parametrization and direct force sum; here conservative drag uses the explicitly derived density/rate equality in §5. No fitted rate or microscopic residual transport coefficient is imported.
* [Wagner, Nguyen and Simon, arXiv:1905.09835](https://arxiv.org/pdf/1905.09835): the two-fluid charge-current and drag organization is a useful primary precedent. Its transport fit and relaxation parameters are not imported into the nozzle or used as measured inputs.

Only selected carrying sections were read; no exhaustive review of every figure/page of the latter two papers is claimed. No full text was saved or admitted to holdings. The equations below are exposed derivations of the declared carrier, not quotations of a device-validated model.

Take positive elementary charge e, positive effective excitation mass m, spin/valley degeneracy g=4, and t=k_B T>0. A controlled material use still requires bounds on gap, trigonal warping, higher bands, interaction corrections and the hydrodynamic frequency/wave-number window. We first allow two velocities; a common temperature is already a closure requiring sufficiently rapid interspecies energy exchange. Its failure requires separate energy moments, not an assertion that no model exists. The background is homogeneous, at rest, with both species present, and at chemical equilibrium when reaction terms are enabled. No magnetic field is included. A later constant subsonic flow is a separate control, not a global nozzle solution.

## 1. Two-band thermodynamics and strict positivity

Use positive quasiparticle energies ε=p²/(2m) for electrons and holes, with charges −e and +e. The chemical potentials for their excitation numbers are μ_e=μ_I+μ and μ_h=μ_I−μ. Define net electron number n=n_e−n_h, total excitation number N=n_e+n_h, and entropy density s. These are two-dimensional densities; n may have either sign. The per-band density of states already contains all four spin/valley species:

\[
 D=\frac{gm}{2\pi\hbar^2},\quad f_i(\varepsilon)=\frac1{\exp[(\varepsilon-\mu_i)/t]+1},
 \quad L(z)=\log(1+e^z),\quad F(z)=\int_0^\infty\frac{y\,dy}{e^{y-z}+1}.
\]
\[
 n_i=Dt L(\mu_i/t),\quad P_i=Dt^2 F(\mu_i/t),\quad
 \mathcal E_i=P_i,\quad s_i=\frac{2P_i-\mu_i n_i}{T}.
 \tag{1}
\]

Proof: the radial momentum measure is D dε. Isotropic kinetic pressure is half the momentum–velocity trace, hence D∫ε f_i dε, equal to the energy density in two dimensions. Integrating t log(1+exp[(μ_i−ε)/t]) by parts gives the same pressure. Differentiation with respect to μ_i and T gives dP_i=n_i dμ_i+s_i dT. The Fermi entropy functional gives the displayed s_i. Summing yields dE=T ds+μ dn+μ_I dN and E+P=Ts+μn+μ_I N, where P=P_e+P_h.

Let a=(n,N,s)^T, λ=(μ,μ_I,T)^T and H=∂λ/∂a, at an admissible finite-T background. Then

\[
 H=H^T>0,\quad \delta P=a^T H\delta a,\quad
 \mathcal E(\alpha a)=\alpha^2\mathcal E(a),\quad
 Ha=\lambda,\quad a^THa=2P>0. \tag{2}
\]

Strict positivity is not assumed from the sign of pressure alone. The second variation of E−T_0 S−μ_{e0}n_e−μ_{h0}n_h about Fermi distributions is
D t_0 Σ_i∫(δf_i)²/[2f_i(1−f_i)]dε, positive for a nonzero perturbation. On the independent number and energy moments its covariance Gram is strictly positive: an affine function of ε that vanishes for all ε in both positive-weight species must have all coefficients zero. Thus the moment susceptibility is invertible, heat capacity is positive, and the constrained Legendre energy has SPD Hessian in (n,N,s). This statement is for finite T and both finite species densities, not the singular zero-hole boundary. Scaling T and both μ_i by α scales n,N,s by α and E by α² in (1). Euler differentiation gives Ha=λ and a^Tλ=E+P=2P. The pressure differential follows Gibbs–Duhem. An interacting/nonparabolic model can still use the positive-H system below, but need not satisfy Ha=λ or E=P.

## 2. Exact thermal, degenerate and neutral controls

At chemical equilibrium μ_I=0, L(x)−L(−x)=x. Also F'(x)=L(x), so F(x)+F(−x)=x²/2+π²/6: differentiate once and use F(0)=Σ_{j≥1}(−1)^{j+1}/j²=π²/12, obtained by termwise exponential integration (or the elementary Fourier-series value of that convergent sum). Consequently

\[
 n=D\mu,\quad N=2Dt\log[2\cosh(\mu/2t)],\quad
 P=D\left(\frac{\mu^2}{2}+\frac{\pi^2 t^2}{6}\right),\quad
 s=\frac{D\pi^2 k_B^2T}{3},\quad
 \mathcal E_{\rm eq}(n,s)=\frac{n^2}{2D}+\frac{3s^2}{2D\pi^2k_B^2}.
 \tag{3}
\]

The equation for N follows by multiplying the two logarithm arguments. The equilibrium energy follows by eliminating μ and T in P; its derivatives reproduce μ,T. It is the energy after minimizing over N at fixed n,s, not an assertion that imbalance is a conserved variable or equilibrates instantly in the material.

As T→0 at fixed nonzero n, N→|n| and P→n²/(2D). At n=0 and T>0, N=2Dt log2 and P=Dπ²t²/6, so the neutral energy and momentum sectors remain populated. Limits with n=T=0 have zero inertia and are excluded from acoustic normalization. Exact finite-T expressions, not a phenomenological background-density quadrature, are used in this declared carrier. Finite-T closure is adiabatic unless explicitly changed in §9.

## 3. Momentum, energy and charge from kinetic moments

Write local distributions to first order in each velocity as f_i(ε−p_x u_i). An integration by parts gives

\[
 \Pi_i=u_i Dm\int_0^\infty \varepsilon[-f_i'(\varepsilon)]d\varepsilon
       =m n_i u_i,\quad
 j_i=n_i u_i,\quad j_{E,i}=2P_i u_i,\quad j_{s,i}=s_i u_i.
\]
\[
 \rho_i=mn_i,\quad
 J_{\rm conv}=-e(n_eu_e-n_hu_h). \tag{4}
\]

Here the angular average of p_x² is mε, and that of εp_x²/m is ε². Thus the energy-current integral is D∫ε²(−f_i')dε=2P_i. For the entropy current use d[-k_B(f log f+(1−f)log(1−f))]/df=(ε−μ_i)/T: the analogous integral gives (2P_i−μ_i n_i)/T. These are intraband kinetic moments. They do not cancel the additional interband current vertex at finite frequency, nor prove an exact Galilean current theorem for the whole lattice/bilayer Hamiltonian.

The physical inertia of this carrier is m(n_e+n_h); the relativistic monolayer substitution (E+P)/v_F² is not used. J_sheet is in A/m, momentum density in kg/(m s), and ρ_i in kg/m². A distinct species thermal moment would be needed if common T is not justified. Equation (4) supplies the finite-density charge coupling that the earlier one-component action assumed.

## 4. General charge-active Onsager carrier: conserved current, gauge invariance and driven work

Set b_e=(n_e,n_e,s_e)^T, b_h=(−n_h,n_h,s_h)^T, B=(b_e,b_h), M=diag(mn_e,mn_h), e_n=(1,0,0)^T, e_N=(0,1,0)^T, e_s=(0,0,1)^T and δλ=Hδa. B and M denote constant equilibrium-background coefficients in this linear moment model, and b_e+b_h=a_0. Write g=∂_xδλ. A general symmetric positive-semidefinite transport matrix L_d is retained, INCLUDING its charge and all cross entries. With internal thermodynamic chemical potentials (excluding electric potential energy), define

\[
 E=-\partial_x\phi-\partial_t A,\quad
 F=g+e e_n E,\quad j_d=-L_d F,\quad
 j_a=B\mathbf u+j_d,\quad
 J_{total}=-e e_n^T j_a=J_{conv}-e e_n^T j_d,
 \quad J_{conv}=-e B_n\mathbf u . \tag{5a}
\]

Here j_d has number, imbalance-number and entropy flux components. This completes the constitutive flux, not a source term that violates charge continuity. The linear system is

\[
 \partial_t\delta a+\partial_x j_a=-\Lambda e_N\delta\mu_I,
\]
\[
 M\partial_t\mathbf u+B^Tg
 =-K\begin{pmatrix}1&-1\\-1&1\end{pmatrix}\mathbf u
   +\partial_x(V\partial_x\mathbf u)-R_{mr}\mathbf u
   -e B_n^T E . \tag{5}
\]

Assume L_d,V,R_mr symmetric PSD, K,Λ≥0, finite continuous coefficients, T_0>0, and the positive finite-T two-species background. Constant V suffices for all Fourier results; the divergence form also gives the correct boundary/work identity for varying V. No magnetic/Hall terms are included. Λ relaxes the imbalance affinity around μ_I0=0. The nonlinear reaction and entropy closure are addressed explicitly below, not declared complete from a first-order equation.

Multiplying the n equation by −e gives the EXACT local linear charge identity

\[
 \partial_t\delta q+\partial_xJ_{total}=0,\qquad\delta q=-e\delta n. \tag{5b}
\]

The reaction does not enter because e_n^Te_N=0. At zero field j_n=−e_n^TL_d g need not vanish. The convective kinetic moment (4) alone is therefore not the total current of (5), even at E=0. The original r1 omission and its explicit sinusoidal countercontrol below remain a genuine scientific defect in that frozen version.

The field and F are gauge invariant under A→A+χ_x, φ→φ−χ_t; n,N,s and their internal thermodynamic λ do not transform. Explicitly F_n=∂_x(δμ−eφ)−e A_t, whose two gauge variations cancel. The other affinities are δμ_I,x and δT_x. The source action ∫(A J_total−φ δq)dxdt changes by the boundary term minus ∫χ(∂_xJ_total+∂_tδq), which vanishes by (5b). Thus the constitutive current satisfies the same electromagnetic conservation requirement, rather than using gauge-dependent scalar potential alone as its driving force. E is a specified external source; no unconstructed Maxwell/contact field is silently included.

### 4.1 Exact local quadratic availability balance and boundary flux

Define the perturbative availability density and nonnegative dissipation

\[
 w_2=\tfrac12(\delta a^TH\delta a+\mathbf u^TM\mathbf u),
\]
\[
 D=F^TL_dF+\Lambda(\delta\mu_I)^2+K(u_e-u_h)^2
 +(\partial_x\mathbf u)^TV(\partial_x\mathbf u)+\mathbf u^TR_{mr}\mathbf u\ge0.
\]
\[
 \partial_t w_2+\partial_x J_{w_2}=EJ_{total}-D,
 \qquad J_{w_2}=\delta\lambda^T j_a-\mathbf u^TV\partial_x\mathbf u . \tag{6}
\]

This is exact for the constant-H/M/B linear system, with the displayed quadratic densities/fluxes. To prove it, use δλ^Tδa_t and u^TMu_t. Integration by parts LOCALLY gives −∂_x(δλ^Tj_a)+g^Tj_a. The g^T B u term cancels −u^TB^Tg. Viscosity gives ∂_x(u^TVu_x)−u_x^TVu_x. Drag, reaction and relaxation give their stated negatives. The remaining identity is

\[
 g^Tj_d=(F-e e_nE)^Tj_d=-F^TL_dF+E(-e e_n^Tj_d).
\]

Adding mechanical power −eE B_nu produces E times the SAME total conserved current in (5b). Every cross term in L_d participates in both flux and work. There is no missing electrical forcing or an unrelated diagonal-conductivity patch. Units are sheet power J/(m²s) for EJ and every term of D; J_w has units W/m. Affinities n,N have J/m units, entropy affinity has K/m units; fluxes n,N have1/(m s), entropy flux has J/(K m s). Therefore L_nn has1/(J s), L_ns=L_sn has1/(K s), and L_ss has J/(K²s) units. Symmetry/PSD is a statement of the physical paired quadratic form; fixed reference scales may put it into dimensionless coordinates without changing sign.

On [x_L,x_R],

\[
 \frac{d}{dt}\int w_2dx=\int EJ_{total}dx-\int Ddx-[J_{w_2}]_{x_L}^{x_R}. \tag{6a}
\]

Periodicity or zero net availability boundary flux eliminates the last term; open contacts must retain it. At E=0 this recovers r1's correct zero-field energy estimate, now with the proper local current. At E≠0 it is a driven availability identity, not full physical energy disappearing without heat. It does not require σ_Q matching, equilibrium FDT or a chosen noise covariance.

### 4.2 Entropy and full driven energy: an explicit thermodynamic completion

The linear entropy equation is δs_t+∂_x(B_su+j_s)=0. Irreversible heating/entropy creation is SECOND order about equilibrium and is not contained in that first-order equation. It would be false to call w_2 the entire internal/physical energy or to read (6)'s negative D as loss of total closed-system energy.

Here is a consistent completion, with its exact domain and target limitation. On a positive-T thermodynamic domain use the full smooth energy E_int(a) of §1 (or a declared positive-H replacement), λ(a)=∂E_int/∂a and T=λ_s>0. Keep the background B,M fixed; this is a specified thermodynamic MOMENT closure extending the linear carrier, not a claimed nonlinear Euler/nozzle derivation. Let F=λ_x+e e_nE, j_a=Bu−L_d F and the momentum equation be (5) with g=λ_x. Retain imbalance reaction −Λe_N μ_I. Split its nonnegative dissipation D into D_f+Σ_b D_b with every piece≥0: D_f heats the retained fluid and D_b heats separately declared stationary local baths. The all-fluid choice D_f=D is one definite completion, not a measured heat partition. Add entropy source e_s D_f/T to a_t+∂_xj_a and bath energy equations h_b,t=D_b with differentiable bath entropy S_b'(h_b)=1/T_b(h_b)>0. No bath energy/entropy flux is chosen here; if such flux is present it must be included on both sides consistently. For a positive availability storage relative to a thermal reference, additionally take stable baths with concave S_b (nonnegative heat capacity where invertible), and reference T_b0=T_0. The balance identities themselves require only the stated positive temperatures; positivity relative to that reference uses these stability/minimum hypotheses.

For ANY smooth solution remaining in this domain, the chain rule and the same cancellations prove

\[
 \mathcal E_{mat}=E_{int}(a)+\tfrac12\mathbf u^TM\mathbf u,\quad
 J_{E,mat}=\lambda^Tj_a-\mathbf u^TV\mathbf u_x,
\]
\[
 \partial_t\mathcal E_{mat}+\partial_xJ_{E,mat}=EJ_{total}-\sum_b D_b,
 \quad
 \partial_t(\mathcal E_{mat}+\sum_b h_b)+\partial_xJ_{E,mat}=EJ_{total},
\]
\[
 \partial_t(s+\sum_bS_b)+\partial_x(e_s^Tj_a)
 =\frac{D_f}{T}+\sum_b\frac{D_b}{T_b}\ge0. \tag{6b}
\]

Proof: the reaction contributes −Λμ_I² to the energy derivative, the full flux/friction contributes the other negative terms of D, the entropy source adds T(D_f/T)=D_f, and each bath adds D_b. Imbalance reaction does not violate charge. The source order is explicit: D is quadratic, so linearizing this completion yields exactly (5), and (6) is its second-order perturbative availability balance. For equilibrium reference λ_0=(μ_0,0,T_0), define total availability A=E_mat+Σh_b−μ_0 n−T_0(s+ΣS_b) minus its constant background. Its exact local balance in this declared completion has boundary flux J_E−μ_0 j_n−T_0 j_s and source

\[
 \partial_t A+\partial_x(J_E-\mu_0 j_n-T_0j_s)
 =EJ_{total}-T_0\left(D_f/T+\sum_bD_b/T_b\right). \tag{6c}
\]

Convex E_int and concave stable bath entropies make A nonnegative after subtracting its equilibrium minimum at μ_I0=0, λ_0=(μ_0,0,T_0), T_b0=T_0, on the admitted convex domain. This follows by the supporting-plane inequalities and positive kinetic energy. The identity follows by subtracting charge-number and entropy balances; it is not a new source of energy or an assumption that external phonon/impurity losses heat the fluid at its temperature. Their partition, bath state, heat removal and entropy flux need actual target modeling. No global nonlinear solution/positivity theorem is inferred for this completion; the statements are identities on its stated smooth positive-temperature domain. The finite-dimensional linear well-posedness and passivity claims later remain separate.

For source conventions, E J_total is gauge-invariant external work. If one chooses the scalar-potential split, charge conservation gives E J_total=−∂_x(φJ_total)−φ∂_tδq−A_tJ_total. Thus adding φδq to material energy and φJ_total to its flux yields source φ_tδq−A_tJ_total. That potential-energy split is gauge dependent; (6) and (6b)'s electromagnetic work are not. It is not a proof of a closed field-plus-matter Maxwell energy without the actual electromagnetic degrees of freedom.

### 4.3 Required nonzero-charge and cross-entry controls

**Periodic zero-field charge diffusion.** Set L_d=ell e_ne_n^T with ell>0, E=0 and initially u=0, δa=e_n n_1 cos(kx), k=2πj/L≠0. H_nn>0, so j_n=ell H_nn k n_1 sin(kx), δn_t=−ell H_nn k²n_1 cos(kx), J_d=−e ell H_nn k n_1 sin(kx). Hence δq_t+∂_xJ_d=0 pointwise. A current falsely set to J_conv=0 fails it. Initially ∫w_2,t dx=−ell H_nn² k²n_1² L/2, exactly −∫D dx. Mechanical pressure excites u after the initial instant in the FREE full system; no exact pure exponential is claimed for that coupled evolution. If an explicitly clamped-u comparison is wanted, an external force cancelling B^Tg keeps u=0 with zero mechanical work, and δn(t)=n_1 exp(−ell H_nn k²t)cos(kx), δN=δs=0 is the exact linear diffusive solution. The clamp is a different control, not a discarded full-system force. Noncharge affinities generated by H do not enter this rank-one L_d but remain in the pressure force.

**Homogeneous driven Joule control.** At g=0, j_d=−e L_d e_nE, so
J_d=e² L_nn E and E J_d=e²L_nnE²=D_d≥0.
The homogeneous first-order density/entropy divergence is zero even for nonzero flux; diffusion's electrical work is dissipated, not inserted as fictitious charge accumulation. At an initially motionless state the added channel contributes zero change of w_2 because its power equals its dissipation, while (6b) places that power into heat. Resolved velocities can accelerate subsequently and add mechanical work. Periodic uniform E is realized by a time-dependent uniform A, not an illegal periodic scalar-potential slope. These are instantaneous/linear constitutive controls, not a steady finite-temperature state without a heat sink.

**Genuine PSD charge/thermal/imbalance cross matrix.** Choose ell,ell_I,ell_T>0, real dimensionless β and real α,γ,δ with entropy-per-particle units J/K, δ≠0. Put v=(1,β,α)^T, w=(0,1,γ)^T, z=(0,0,δ)^T and
L_d=ell vv^T+ell_I ww^T+ell_T zz^T.
This is SPD since the three vectors span; its determinant is ell ell_I ell_T δ²>0 in the paired units. All entries are retained:
L_nn=ell, L_nN=ellβ, L_ns=ellα,
L_NN=ellβ²+ell_I, L_Ns=ellβα+ell_Iγ,
L_ss=ellα²+ell_Iγ²+ell_Tδ².
Let X=F_n+βF_N+αF_s, Y=F_N+γF_s. Then
j_n=−ell X,
j_N=−βell X−ell_I Y,
j_s=−αell X−γell_I Y−ell_Tδ²F_s,
and D_d=ell X²+ell_I Y²+ell_Tδ²F_s².
Thus all charge/imbalance/thermal cross terms occur in the SAME conserved flux and positive work. In the E=μ_x=μ_I,x=0 thermal-gradient control with α≠0, j_n=−ellα T_x is genuinely nonzero, with reciprocal entropy current under electric driving. With a uniform electric field the cross imbalance and entropy currents are −e ellβ E and −e ellα E, while charge Joule power stays e²ell E². Under an open-circuit j_n=0 constraint, E=−(μ_x+βμ_I,x+αT_x)/e; the remaining Y/δ terms still dissipate nonnegatively. This is a constructive full-rank matrix example, not an unrelated diagonal electrical add-on or a claim of measured target thermopower.

### 4.4 No double counting of the explicitly resolved relative current

The kinetic moments (4), barycentric decomposition (7) and drag channel (8) already contain relative electron–hole charge transport. Eliminating v gives the pressure mobility bb^T/(K−iωρ_r). One may add L_d ONLY for an additional matched residual moment sector, not insert this same mobility a second time as intrinsic σ_Q. A measured total conductivity cannot be added unchanged to (8) without subtracting/matching its resolved projection, including cross correlations and relaxation.

A precise projection prescription uses the positive equilibrium moment/Kubo inner product on an admitted microscopic state. Let P_R project onto all explicitly retained density/energy and species-momentum functions; its actual Gram matrix must be invertible on the chosen nonredundant list. Write each microscopic flux as P_R j_i+Q_R j_i, Q_R=1−P_R. Only the Q_R fluxes enter a residual collision/memory calculation, with the matching Schur/cross blocks retained if they couple back. Under a self-adjoint strictly positive residual relaxation C_Q, a finite matched approximation can have L_ij=⟨Q_Rj_i,C_Q^−1 Q_Rj_j⟩, up to the fixed common thermodynamic scale absorbed in its definition. This is a symmetric PSD Gram form. It is a definition to derive/match on actual operators, not a measured transport formula supplied by this note.

There is a decisive specialization: for strictly parabolic INTRABAND carriers and BOTH exact species momenta retained, the charge flux is exactly their linear combination −e(Π_e−Π_h)/m. Its residual charge projection then vanishes. Higher intraband moments alone cannot manufacture a second charge channel. This does NOT remove general charge-active L_d from (5); it prevents falsely deriving it twice from the same ideal carrier. The general model is an EXTENDED moment closure allowing residual interband/nonparabolic/additional-channel response. Its actual current, thermodynamics and overlap/projection errors must be supplied before material matching; ideal formulas (1)–(4) remain the explicitly declared parabolic core. The real bilayer current's interband term and finite-frequency warning make that full microscopic construction necessary, not automatically solved.

An explicit passive auxiliary realization shows that the retained general PSD matrix is a coherent deterministic sector. In fixed scaled coordinates let z be r additional odd moments with energy z^TM_z z/2, M_z>0, coupling matrix D_z from these residual moments into the three physical fluxes, and relaxation C_z=C_z^T>0. Replace j_d by D_z z and set
M_z z_t+D_z^TF=−C_z z.
Multiplication by z^T and the same continuity/work calculation give (6) with extra energy z^TM_z z/2, transport dissipation z^TC_z z and current contribution −e e_n^TD_z z. In the overdamped algebraic limit z=−C_z^−1D_z^TF, the exact local law is L_d=D_z C_z^−1D_z^T. Every finite PSD L_d has such a factorization, including the full-rank cross example. Resolved and residual coordinates must correspond to disjoint projected moments for a microscopic use; simply duplicating v in z is forbidden.

For real ω the finite-memory response is L(ω)=D_z(C_z−iωM_z)^−1D_z^T. Its Hermitian real part is D_z(C_z+iωM_z)^−1 C_z(C_z−iωM_z)^−1D_z^T≥0. If C_z≥c_zI>0 then ‖(C_z−iωM_z)^−1‖≤1/c_z by accretivity, and
‖L(ω)−L(0)‖≤|ω|‖D_z‖²‖M_z‖/c_z².
This gives an explicit finite-frequency deterministic matching/error target. It does not derive an interband bath, its quantum noise, a Markov approximation at actual material rates or a contact detector spectrum. Symmetry is assumed at zero magnetic field; magnetic/Hall and nonreciprocal couplings require their own matched treatment.

At all dissipative entries off and E=0, the original conservative system survives exactly: x=H^{1/2}δa and p=M^{1/2}u have Fourier generator −ik[[0,C],[C^T,0]], C=H^{1/2}BM^−1/2. Its two singular values give two sound pairs and the remaining thermodynamic zero mode. The single acoustic projection below is a further explicitly stated limit, not a derivation of the general full transport/noise model by dropping its other sectors.

## 5. Barycentric and relative modes; intrinsic versus acoustic current

Define u=(n_eu_e+n_hu_h)/N, v=u_e−u_h, ρ=mN, ρ_r=mn_en_h/N and

\[
 b=\left(\frac{2n_en_h}{N},\ 0,\ \frac{n_hs_e-n_es_h}{N}\right)^T.
\]
\[
 \tfrac12\sum_i mn_i u_i^2=\tfrac12\rho u^2+\tfrac12\rho_rv^2,
 \quad B\mathbf u=a u+b v,\quad
 J_{\rm conv}=-e(nu+b_n v). \tag{7}
\]

Insert u_e=u+(n_h/N)v, u_h=u−(n_e/N)v to prove every coefficient. With the other dissipative entries off, (5) becomes
δa_t+a u_x+b v_x=0,
ρu_t+a^Tδλ_x=−en E_x,
ρ_rv_t+b^Tδλ_x=−Kv−eb_n E_x.
At frequency convention exp(−iωt), eliminating v gives the pressure-gradient mobility bb^T/(K−iωρ_r). In a spatially uniform field, adding a common momentum relaxation rate γ_mr gives

\[
 \sigma_{\rm resolved}(\omega)
 =\frac{e^2 n^2}{\rho(\gamma_{mr}-i\omega)}
  +\frac{e^2 b_n^2}{K-i\omega\rho_r}. \tag{8}
\]

Here L_d=0 and the added momentum relaxation acts ONLY on the common mode at rate γ_mr, with no extra relative damping beyond K. A common rate applied to BOTH species velocities would also add γ_mrρ_r to the relative denominator; generic species relaxation may mix the modes. Thus σ_resolved refers only to these two explicitly specified resolved channels. With homogeneous fields/coefficients and an independently matched additional instantaneous L_d, σ_total=σ_resolved+e²L_nn; the auxiliary memory realization instead adds e² e_n^T L(ω)e_n. Nonuniform or coupled transport requires the full (5), not this sum by assertion. Both real parts are nonnegative for positive rates. The second channel is a relative electron–hole current, not the acoustic charge overlap; it cannot be inserted as σ_Q into an acoustic mode normalization. Thermoelectric coupling remains in b_s. At neutrality the first numerator vanishes but b_n=N/2 and ρ_r=mN/4, so relative electrical conduction remains possible. In a source two-fluid parametrization the conservative drag coefficient is K=mn_e/τ_eh=mn_h/τ_he; summing the two drag forces gives (−mn_e/τ_eh+mn_h/τ_he)v, so this density/rate equality is necessary for total momentum conservation. The source HTML Eq108 satisfies it, whereas its printed Eq107 product condition generally does not. We retain the derived force equality, not that product label; adopting a value or a measured thermal-locking inequality remains an independent task. In the single-species limit use the one-fluid theory directly: formulas dividing by ρ_r are not uniform when holes or electrons disappear.

## 6. Controlled locked branch and its finite-density eigenvector

At leading order v=0 with additional dissipative entries off, the equations are
δa_t+a u_x=0 and ρu_t+a^THδa_x=0. Nonzero-frequency compressions can be written δa=−a ξ_x and u=ξ_t. Therefore

\[
 B_{\rm bulk}=a^THa=2P,\quad c^2=\frac{2P}{mN},\quad
 \omega=\pm c|k|,\quad \delta a=\frac{k}{\omega}a u . \tag{9}
\]

In whitened variables (x,p)=(H^{1/2}δa,√ρ u), let A=H^{1/2}a/√ρ, with |A|=c. The acoustic normalized eigenvectors are (±A/c,1)/√2 for the first-order k generator, up to branch labels and phase. The other two thermodynamic modes have u=0 and a^THδa=0. The energy and current components of the acoustic eigenvector are fixed, not separately fitted: δε=λ^Tδa=(2P)ku/ω, δn=nku/ω, and J_ac=−en u. A pure acoustic initial condition is required for a single-branch-only description; generic initial data also contain the stationary composition sector and relative transients.

Using (3), the degenerate finite-density control is c²=|n|/(mD)=πℏ²|n|/(2m²) for g=4. The neutral thermal control is c²=π²k_BT/(6m log2)>0. It has zero convective charge overlap even though there is sound and the relative current in (8). At finite n and finite T, c>0 and the convective charge coupling is nonzero. This is a charged finite-density mode, not merely a neutral counterexample.

## 7. A finite-time bound for velocity locking

A statement that drag is fast is not itself an error bound. Here E=0 and L_d=Λ=V=R_mr=0; no unresolved transport/current or noise bound is included. For K>0, set r=√ρ_r v, C_r=H^{1/2}b/√ρ_r, γ=K/ρ_r, and retain x,p,A from §6. For one Fourier component the exact positive system is

\[
 \dot x=-ik A p-ik C_r r,\quad
 \dot p=-ik A^T x,\quad
 \dot r=-\gamma r-ik C_r^T x .
\]

Let U_0=(|x_0|²+|p_0|²+|r_0|²)^{1/2}. Equation (6) implies its norm does not increase. Direct integration gives
|r(t)|≤e^{−γt}|r_0|+|k|‖C_r‖U_0/γ.
Compare y=(x,p) with the locked skew-Hermitian evolution y_lock having the same y_0. Duhamel and unit norm of the locked propagator yield

\[
 \|y(t)-y_{lock}(t)\|
 \le\frac{|k|\|C_r\||r_0|}{\gamma}
       +\frac{t k^2\|C_r\|^2 U_0}{\gamma}. \tag{10}
\]

This is an explicit finite-time estimate, including the initial relative-velocity layer; it is not uniform for arbitrarily long times or high k. For finitely many retained modes |k|≤k_max use the same bound in the direct-sum norm with the largest coefficients. Eliminating r at real ω instead produces a correction of norm ≤η_k=k²‖C_r‖²/γ to the locked frequency generator. Its Markov replacement has error ≤k²‖C_r‖²|ω|/γ². For an off-pole locked resolvent at distance d>η_k from {0,±ck}, the Neumann identity bounds the resolvent difference by η_k/[d(d−η_k)]. No such off-pole bound is claimed on the acoustic pole. Drift elimination alone does not establish quantum fluctuation noise: a compatible bath covariance/FDT or another specified positive state is still needed.

## 8. Imbalance relaxation and when it changes sound

In the locked system set L_d=V=R_mr=0 and E=0, retaining only −Λe_Nδμ_I. The positive entropy source of (6b) is quadratic and does not alter this linear modulus. Split a into a_r=(n,s) and N, with the corresponding blocks of H. For a monochromatic compression z=ku/ω, δa_r=a_r z. Solving its N equation gives

\[
 \delta N=Nz-\frac{\Lambda(Ha)_N}{\Lambda H_{NN}-i\omega}z,
\quad \delta P=B(\omega)z,
\quad B(\omega)=B_f-\frac{\Lambda[(Ha)_N]^2}{\Lambda H_{NN}-i\omega},
\]
\[
 B_f=a^THa,\quad
 B_{fast}=B_f-\frac{[(Ha)_N]^2}{H_{NN}}
 =a_r^T(H_{rr}-H_{rN}H_{NN}^{-1}H_{Nr})a_r>0. \tag{11}
\]

To verify, write δN=Nz+Δ, insert δμ_I=(Ha)_Nz+H_NNΔ into (−iω)Δ=−Λδμ_I, and then δP=B_f z+(Ha)_NΔ. The Schur complement is SPD; strict positivity of B_fast holds when a_r≠0, which includes every finite-T state here because s>0. For ω>0 the imaginary part of B(ω) is nonpositive, as required for a lossy compressional modulus with exp(−iωt). For this ideal scale-invariant carrier at μ_I=0, Ha=λ and (Ha)_N=0: compression already follows the chemical-equilibrium tangent, so both moduli equal 2P. This equality is derived, not generally assumed for a gapped or interacting bilayer. Off-equilibrium μ_I backgrounds require the background reaction and energy balance too; (11) is not their stationary theory. Actual recombination/imbalance rates and their possible memory are still unknown inputs.

## 9. Thermal closure, viscosity and electrostatics

The entropy equation of (5) without dissipative entries gives advection, hence (9) is adiabatic. Fast thermal clamping is a different model. On the chemical-equilibrium tangent δμ_I=0 AS WELL AS δT=0, with net density δn=nz, (3) gives δP=n²z/D, so its common-flow compressional speed is c_T²=n²/(mND), with heat exchanged by a reservoir and N following the equilibrated N(n,T) tangent: δN=tanh[μ/(2t)]δn and δs=0. The δN formula follows by differentiating the explicit N in (3) at fixed T and n=Dμ. Instantaneous chemical equilibration is a constrained/fast-reaction model, not the frozen-N continuity law. Merely setting the background μ_I=0 while freezing δN is insufficient; that different fixed-T/frozen-imbalance derivative must use the full three-variable Hessian. At n=0 this does not carry the neutral energy sound of (9). In a SEPARATE one-band dilute unipolar classical control, c_T²=t/m while c_ad²=2t/m. This is not the μ_I=0 two-band chemical-equilibrium dilute limit, which cannot suppress just one thermally dilute species by that same condition. They coincide only in appropriate degenerate limits, not by changing the label on a finite-T derivative.

For a longitudinal Newtonian flow in two dimensions, stress is 2η times the traceless strain plus ζ times the divergence. A one-dimensional longitudinal perturbation thus has η_L=η+ζ. Its positive-dissipation equation is ρu_t+δP_x=η_L u_xx−ργ_mr u, so
ν_L=η_L/(mN) and ω²+i(γ_mr+ν_Lk²)ω−c²k²=0.
In the weak-loss regime the amplitude decay rate is (γ_mr+ν_Lk²)/2; the energy/population rate is twice that. For the degenerate unipolar kinetic estimate η=m|n|v_Fℓ_ee/4, the shear contribution is ν= v_Fℓ_ee/4. No actual viscosity, ℓ_ee, bulk viscosity or high-bias relaxation law has been qualified here. The sign follows (6), independently of inconsistent printed source conventions.

A separately justified static local capacitance C_g per area adds δE_gate=e²(δn)²/(2C_g), i.e. H_gate=(e²/C_g)e_ne_n^T. It adds e²n²/C_g to B_bulk and e²n²/(mNC_g) to c², recovering the unipolar e²|n|/(mC_g) term. A nonlocal positive electrostatic kernel U(k) instead gives B(k)=2P+e²n²U(k); a dispersive/dissipative U(k,ω) requires its dynamical fields and associated noise. For example an unscreened U∝1/|k| gives a nonacoustic small-k charged dispersion. The actual slowly responding gate does not license an arbitrary instantaneous C_g or zero Coulomb kernel. Microscopic collision screening and macroscopic gate/contact electrostatics are different inputs. A controlled comparison to the measured nozzle must supply the actual kernel, transverse mode and boundary conditions.

## 10. Canonical finite-domain action and width-to-line current

For this CONSERVATIVE retained acoustic subsector, set additional L_d/current moments and all dissipative coefficients off after the stated locking/adiabatic projection; no full dissipative carrier is quantized here. For a locally uniform strip of width W>0 and a transverse-uniform retained acoustic mode define
ρ_1=WmN, B_1=W(2P), Q_1=−eWn.
Then δq_line=−Q_1 ξ_x, I_ac=Q_1 ξ_t, and

\[
 S_2=\frac12\int dt\,dx[\rho_1\xi_t^2-B_1\xi_x^2],\quad
 \Pi=\rho_1\xi_t,\quad c^2=B_1/\rho_1,
 \quad H_2=\frac12\int[\Pi^2/\rho_1+B_1\xi_x^2]dx. \tag{12}
\]

This follows by integrating the kinetic energy ρu²/2 and the compression energy δa^THδa/2 over width W. In particular I_ac is the physical integrated convective current from (4); it was not assigned from conductivity. ρ_1 has units kg/m, B_1 force, Q_1 C/m, ξ length, and I amperes. Transverse nonuniformity, wall layers and electrode sensitivity require a weighted mode normalization, not silent use of the full width W.

For periodic length L retain finitely many nonzero Fourier k=2πj/L and fix the density/translation zero modes. Put ω_k=c|k| and independent bosons [b_k,b_l†]=δ_kl. An explicit real displacement is

\[
 \xi(x)=i\sum_{k\ne0}\operatorname{sgn}(k)
 \sqrt{\frac{\hbar}{2\rho_1L\omega_k}}
 [b_k e^{ikx}-b_k^\dagger e^{-ikx}],
\quad
 \Pi(x)=\sum_{k\ne0}\operatorname{sgn}(k)
 \sqrt{\frac{\rho_1\hbar\omega_k}{2L}}
 [b_k e^{ikx}+b_k^\dagger e^{-ikx}].
\]

The commutator is iℏ times the retained Fourier delta projector, with the constant mode removed. Substitution gives H_2=Σ_kℏω_k(b_k†b_k+1/2). All retained frequencies are positive; each finite Fourier model has a self-adjoint positive oscillator Hamiltonian and positive Gaussian states. This is a spatial mode truncation, not an energy cutoff on electronic distributions and not a proof that a dissipative two-fluid theory is an isolated Hamiltonian. The finite oscillator Hilbert space remains an infinite-dimensional bosonic Fock space per mode; no finite-dimensional Hilbert-space claim is made.

## 11. Derived local spectrum, response and contact term

Let w(x) be a real normalized spatial probe, ∫w dx=1, with transform w̃(k). Smear I=∫w I_ac dx. In a stationary gauge-invariant Gaussian state with independent directional occupations n_±(ω)≥0 and no anomalous/cross-frequency covariances, define the two-sided angular-frequency symmetrized spectrum by S_sym(ω)=∫dt e^{iωt}⟨{I(t),I(0)}/2⟩. In the continuum-length limit, for ω>0,

\[
 G_{ac}=\frac{Q_1^2}{2\rho_1 c}
       =\frac{We^2n^2}{2mNc},\quad
 F(\omega)=|\widetilde w(\omega/c)|^2,
\quad
 S_{sym}(\omega)=\hbar\omega G_{ac}F(\omega)[1+n_+(\omega)+n_-(\omega)]. \tag{13}
\]

Proof: I_k has coefficient Q_1 sgn(k)√(ℏω_k/(2ρ_1L)); each direction contributes a density of states L/(2πc). Fourier transforming the symmetrized cosine contributes π(2n_s+1). Thus a single direction contributes ℏω G_ac F(n_s+1/2); summing proves (13). At finite L these are spectral delta lines, not a smooth band; continuum smoothing requires a specified measurement resolution/limit. No fitted broadening is manufactured. The directional ordered spectra are S^>_s=ℏωG_ac F(n_s+1), S^<_s=ℏωG_ac F n_s at positive ω with S^>(ω)=∫e^{iωt}⟨I(t)I(0)⟩dt. Total commutator weight is 2ℏωG_ac F. Occupation asymmetry does not change it. Neutral n=0 gives G_ac=0; the relative-current noise is a distinct sector, not zero by this calculation. The finite-density degenerate limit is G_ac=We²|n|/(2mc), without a claim of a single electronic Landauer channel or quantized terminal conductance.

For a localized longitudinal electromagnetic source the coupling density is Q_1(A ξ_t+φ ξ_x). Integration by parts gives Q_1ξE, E=−A_t−φ_x. Canonical momentum is Π=ρ_1ξ_t+Q_1 A; hence the measured current is Q_1(Π−Q_1 A)/ρ_1. A current Kubo calculation must include the contact term Q_1²/ρ_1, smeared with ∫w²dx. Directly solving the action gives

\[
 Y(k,\omega)=\frac{-i\omega Q_1^2}{\rho_1[c^2 k^2-(\omega+i0)^2]},\qquad
 \operatorname{Re}Y_{ww}(\omega)=G_{ac}F(\omega). \tag{14}
\]

Indeed ReY integrates πωQ_1²δ(c²k²−ω²)/ρ_1 with dk/(2π), and the two roots give (14). This includes the canonical contact cancellation; dropping it leaves an incorrect local reactive term. It is a local self-response to the same smeared source, not contact-to-contact admittance. The spectral commutator relation agrees with (14). A thermal state satisfies S_sym=ℏω coth(ℏω/2k_BT_b)ReY, but neither a material bath temperature nor an outgoing Hawking state was derived.

For an independently established single outgoing Hawking excess n_out=Γ n_H over the same vacuum baseline and other direction unchanged, the one-sided symmetrized excess is 2ℏωG_ac F Γ n_H. Γ is an occupation transmission once, not Γ² or an additional G_ac factor. Conversion to a two-sided per-Hz density is S_f(f)=S_ω(2πf), since dω/(2π)=df; one-sided positive-f densities have another factor two relative to that two-sided density. An already one-sided angular-frequency excess is converted by substitution ω=2πf without a second factor two. A gain/noise model must declare ordered versus symmetrized and baseline conventions; a passive detector is not automatically a symmetrized-noise meter. General Gaussian directional covariance and extra reservoir channels must be propagated rather than discarded to force (13).

## 12. Uniform flow and finite spatial response control

A separate homogeneous subsonic ideal-carrier control with constant U has
S=ρ_1∫[(∂_t+U∂_x)ξ]²/2−B_1∫ξ_x²/2.
The density perturbation is −a ξ_x and δu=(∂_t+U∂_x)ξ. Total linear charge current, including advection of δn, is Q_1δu−Q_1Uξ_x=Q_1ξ_t. Canonical Π=ρ_1(∂_t+U∂_x)ξ and
H_lab=∫[Π²/(2ρ_1)+B_1ξ_x²/2−UΠξ_x]dx.
Completing the square leaves B_1−ρ_1U²>0 exactly when |U|<c. The mode normalization uses the comoving positive frequency c|k|, whereas the lab frequency is ω_k=Uk+c|k|.

For direction s=± and positive lab ω, k_s=sω/(c+sU). Current amplitudes contain ω/√(c|k_s|), and the lab density of states is proportional to 1/(c+sU); those factors cancel to give

\[
 S_{sym}(\omega)=\hbar\omega G_{ac}
 \sum_{s=\pm}|\widetilde w(k_s)|^2[n_s(k_s)+\tfrac12]. \tag{15}
\]

At U=0 this reduces to (13). The state occupations must be specified at the corresponding k or converted frequency, not assumed to have an invariant thermal argument. At |U|≥c this lab Hamiltonian is not positive; no global positive-KMS or horizon conclusion follows from this homogeneous control. A spatially varying nozzle requires a physical stationary background and scattering/partner-channel construction, not substitution of U(x), c(x) into a local formula alone.

If w≥0, ∫w=1, centered at x_0 with variance σ_x²<∞, then
1−|w̃(k)|²=∫∫w(x)w(y)[1−cos(k(x−y))]dxdy≤k²σ_x².
Thus max(0,1−k²σ_x²)≤F≤1. This is a real finite-frequency envelope, not a declaration that a particular experimental interval satisfies it. A sign-changing probe needs a separate norm bound. Boundary mode distortion and transverse form factors are additional errors.

## 13. Electronic truncation, stable domains and observable error transport

The formal ideal carrier extends ε to infinity. To compare with a parabolic material window E_Λ, require E_Λ>μ_i. Since f_i≤exp[(μ_i−ε)/t], direct integration bounds its discarded ideal tails:

\[
 n_i^{tail}\le Dt e^{(\mu_i-E_\Lambda)/t},\quad
 \mathcal E_i^{tail}\le Dt(E_\Lambda+t)e^{(\mu_i-E_\Lambda)/t},
\]
\[
 s_i^{tail}\le k_BD(E_\Lambda-\mu_i+2t)e^{(\mu_i-E_\Lambda)/t},\quad
 \chi_{\Pi_i\Pi_i}^{tail}\le mD(E_\Lambda+t)e^{(\mu_i-E_\Lambda)/t}. \tag{16}
\]

For entropy use the exact Fermi identity h(f)=log(1+e^{−x})+x f at x=(ε−μ_i)/t>0, then h≤(1+x)e^{−x}. For momentum susceptibility use mD∫ε f(1−f)dε/t. A sharp cutoff changes the integration-by-parts identity: χ_cut=m n_cut−mD E_Λ f_i(E_Λ), so one must not simply assert exact m n_cut inertia. These tail estimates concern the ideal carrier, not the difference between real high-energy bands and that carrier. Actual band/interaction/interband errors require independent evidence and bounds.

On any compact domain with T≥T_min>0, both n_i≥n_min>0, m>0, and bounded model parameters, H and M have positive lower eigenvalue bounds. Finite Fourier projections of (5) have the energy estimate (6) and therefore no exponentially growing linear solutions. Uniform locking also needs K/ρ_r bounded below and explicit k/time limits in (10). The degenerate one-fluid limit is treated separately, not through a false uniform inverse-ρ_r estimate. Nonlinear drift/heating/nozzle errors are outside this linear stability proof and remain to be bounded.

For positive measured/model line parameters let |δρ_1|≤ε_ρρ_m, |δB_1|≤ε_B B_m with ε_ρ,ε_B<1 and |δQ_1|≤ε_Q. Define d_m=√(ρ_m B_m), l=√[(1−ε_ρ)(1−ε_B)], u=√[(1+ε_ρ)(1+ε_B)]. Since G=Q_1²/(2√(ρ_1B_1)), triangle inequalities give

\[
 |G_a-G_m|\le\frac{2|Q_m|\epsilon_Q+\epsilon_Q^2}{2d_m l}
 +G_m\max(|l^{-1}-1|,|u^{-1}-1|). \tag{17}
\]

The sound-speed ratio lies between √[(1−ε_B)/(1+ε_ρ)] and √[(1+ε_B)/(1−ε_ρ)]. Absolute charge errors make (17) usable near neutrality, where a relative error divided by n would fail. No ε is assumed small without measurement or derivation.

More generally a finite filtered observable X_actual=X_model+ΔX with Var(ΔX)≤ε_X² satisfies

\[
 |\operatorname{Var}X_{actual}-\operatorname{Var}X_{model}|
 \le2\sqrt{\operatorname{Var}X_{model}}\epsilon_X+\epsilon_X^2. \tag{18}
\]

This follows Cauchy–Schwarz and retains cross-correlations. It can carry unresolved interband/contact/relative/thermal channels only after a genuine bound on their total filtered difference is supplied. It does not set such channels to zero, or convert a drift error into a quantum covariance error. A finite filtered-time estimate (10) is one deterministic ingredient, not by itself a full spectral uncertainty certificate at a pole.

## 14. Remaining construction duties and concrete continuation

This coherent successor produces the source-grounded conditional finite-density branch, actual convective inertia/current moments, COMPLETE general charge-active Onsager flux/current/affinity/work/entropy closure, explicit residual projection/auxiliary realization and positive cross-entry controls, alongside the retained relative-current/locking/canonical local-spectrum results. It gives finite-domain and uncertainty statements that expose the needed inputs. It does not claim the actual bilayer device realizes those approximations, or that the unipolar source closes a bipolar/noise problem.

The accepted owning objective remains E2's physical electrical/noise response and error-controlled identifiable band, shared with D1 where applicable. The next substantive chain is: independently review this full note; derive/bound the actual finite-frequency bilayer current/stress/energy and collision vertices including interband and imbalance channels; determine the dynamical gate/contact kernel and transverse mode; construct the stationary heated nozzle and coupled scattering/state/noise problem; then propagate measured or independently derived parameter/bath/transfer uncertainties into a nonempty usable band. The independent fermionic Landauer and microscopic Keldysh routes remain distinct owed constructions; this quadratic carrier does not establish their equivalence.

The added unresolved current sector needs its actual microscopic residual projection, memory/collision coefficients and independently specified positive quantum covariance. Deterministic passivity, a declared PSD matrix or an auxiliary relaxation moment cannot provide its fluctuation spectrum; the isolated acoustic Gaussian calculation is not that missing bath. No current can be counted in both its explicit relative mode and L_d. Exact still-required inputs include material m/gap/warping/window and equation-of-state errors; common-temperature equilibration and drag/recombination/momentum/viscous rates with domains; gate/oxide/contact electromagnetic response and reservoir noise; physical incoming/outgoing/partner channels, losses and a CCR-preserving scattering map; the actual non-equilibrium state and detector ordering; electrical transfer, background/cross-noise and calibration; and numerical/native/runtime/integration verification on any future installed implementation. None is a supplied fit here. No demonstrated infeasibility, operator-approved deferral, relaxed claim-strength target, publication gate closure or main acceptance is requested or inferred.

Process: author repair → fresh genuinely nonauthor complete scientific verification → recorded scoped acceptance/closure by the designated writer, with all residual BUILD and original publication gates explicit. The complete original eighteen-group r1 scientific rejection269c928f remains immutable; this is a proposed full repair, not its acceptance. All eighteen numbered groups and their original controls remain, with groups5/6 substantively completed and special-domain precisions made explicit. This artifact is an ignored author proposal and is not an installed manuscript, code change, native result or public roadmap closure.

<!-- END EXACT ORIGINAL CONSTRUCTION -->

Documentary transport only; all original mathematical and source-domain text above is byte-exact.
