# Full GP/BdG leading law and uniform error — review

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** All thirteen sections, fixed GP model, analytic root/minor/Gamma normalizations, leading coefficient, explicit zero-reaching infrared error and corrected two-sided Hermitian generated covariance/filter/Hz conventions. Scalar Planck comparison is a specified mathematical comparison.

**Original physical obligations.** Stationary whole-field spectral/state completeness, local equal-time CCR/noise and missing sectors, microscopic/target-platform validity and calibrated receiver/useful nonempty physical band remain owed. Original P1/S1/process failures unwaived.

The construction author is publication_main55_independent_review; the complete independent scientific review is by publication_njl_target_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR](../SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md), [fixed source model](../source-models/SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md), [full independent review](../reviews/SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR-REVIEW -->
# Whole independent scientific review — corrected full GP/BdG leading law

**ACCEPTED PARTIAL MANUAL SCIENTIFIC MILESTONE for the ENTIRE declared thirteen-section construction. No mandatory mathematical correction found.** The reviewed CONSTRUCTION is feab451fab1f16631681b9fd65ffd37242392908ad9b36055abab8e692b264af, MODEL9aa2973847ad116c104c8548cfc3a4a26d3cffbd9d3d73237f9fa7e5602f8fbd and REPORT655151a83a423512c338cc033515d6661a8f22fa9e90ae1e85f6a9cdeda97a3c. The original shared D1/E1/E2 physical BUILD remains OPEN. This verifies the actual same-model zero-reaching uniform mathematical error and the corrected Hermitian generated-diagonal covariance, not stationary whole-field completeness, microscopic gas validity or a calibrated target-device band.

I authored none of this new GP leading-law/corrective derivation. Earlier publication/source/scientific work is dependency history and gives no scientific self-acceptance here. I independently rederived the entire current root/minor/Gamma/normalization/Theta/coefficient/error/Planck-comparison chain and full section11 contractions after completing the required reading and receiving the explicit documentary ACK. Exact preservation of sections2–10 is DATA evidence, not my reason for accepting their mathematics. Old S1/P1 rejections and all process/source/native failures remain immutable and unwaived.

## 1. Complete reading before independent proof; genuine scope

FIRST ran exactly once from N16:41:37.947120–16:41:38.179997 UTC, five argv, rc0/freshtrue/changedempty, separate stderr empty. Initial protection16:42:27.284986–16:42:28.591137 captured all62 unique bindings, P5186/N4869/M4906 tracked states plus ALL literal historical7/64/3 and actual dirty/untracked paths, raw index bytes/fullstates separately from semantic stage, HEAD/status/all-status/refs and bounded administration, all21 read-only Git command channels and five owned absences. Every reference hash matched. The seventh primary historical infra.md was explicitly INITIAL MISSING, not inferred from clean porcelain.

BEFORE ANY independent derivation or countercheck I read the complete current MODEL, all13 sections/41389bytes of CONSTRUCTION, full16192-byte REPORT, current process/evidence scientific/chronology/assurance prose and original checks; original full34639-byte GP construction and full35028-byte independent review; the leading-r1 full28155-byte review, its remaining original sections/report and whole original models; complete chiral note/review and response/dispersion audit; actual canonical three carrying function bodies, entire KappaScaling and carrying HawkingUniversality definitions/proofs. Current r71 prefix was read completely; unchanged governance and historical notebook/source depth were reused only at protected exact hashes. Raw binary/base64 records are statically parsed/compared, not represented as human prose.

The exact complete-read dataset was saved16:46:06.942199 with review_proof_started=false. Entire leading MODEL17c444c0 appears exactly once in9aa at byte2743; entire original23d73a45 appears once at4442. All nine complete old2–10 section byte ranges equal the current ranges. The recorded whole-source hashes, bounded tool receipts and honest reuse boundaries are in evidence. I STOPPED at that checkpoint as directed. Lead ACKdc05bb21921896b23a2a8412fc55f7541f83c42d3b54c67241221b3ef1e841e7 was read/pinned and actually recorded16:47:34.364381 BEFORE proof. The exact mental proof-start instant was not persisted; it is bounded after that ACK and before the first proof persistence. No earlier read or check is relabeled proof, repeated, refreshed or backdated.

The lead's first ACK collector compared the wrong nested DATA field and produced62 false flags; failed545c2142 remains historical, was NOT issued as an ACK and confers no authority. The corrected77-check receipt fixes schema reading only. It is documentary coordination, not scientific acceptance, runtime permission or a process waiver. One large ACK display clipped redundant reference data; the scalar authority fields were recovered separately. Initial combined reference/native search displays also clipped irrelevant roster/search lines; required new scientific prose and actual definitions were recovered in bounded calls before the complete-read checkpoint. No unseen clipped scientific text is credited.

Official primary read-only crosschecks here include [DLMF5.5](https://dlmf.nist.gov/5.5) recurrence/reflection, [5.7](https://dlmf.nist.gov/5.7) digamma series and [16.8](https://dlmf.nist.gov/16.8) equation/bases/connection/limiting qualifications, plus the actual model, normalization and constant-flow passages of [1707.09664v2](https://arxiv.org/html/1707.09664v2). Earlier whole carrying primary depth is exact-edition history, not a claimed new whole-PDF/pixel read. No article/fulltext was saved/admitted. These identities are inputs/crosschecks; the new proof is checked below rather than accepted from a source name.

## 2. Fixed physical family, original normalization and exact operator

The entire family m,rho0,L>0,0<c_l<v0<c_r, arbitrary real mu and v=-v0 is retained. Substituting g=mc²/rho0 and V=mu-mv0²/2-mc² into the original stationary GP equation gives exactly mu on the stated constant-density flowing background. It is an exact GP substitution, not an exact microscopic many-body state. With a=hbar/(2m), the full quantum-pressure density/phase equations are D_t theta=a n''-c²n/a and D_t n=-a theta''. The canonical commutator [phi,phi†]=delta/rho0 gives [n,theta]=i delta/(2rho0); delta rho=2rho0 n and delta j=2rho0v n+2a rho0 theta' satisfy continuity. No electronic current is inferred.

For omega!=0 the inverse p'=(v n+a theta')/(iomega), p=(v p'+a theta)/(iomega) fixes both integration constants and yields n=p'',theta=-Dp/a. The resulting ordered scalar equation is (D²+a²partial_x^4-c²partial_x²)p=0. Its density equation instead has -(c²n)'', so no differentiated-profile term is silently omitted. Zero and unrestricted phase remain outside that inverse.

For p=h exp(ikx), n=-k²h and theta=iOmega h/a give rho0(|u|²-|w|²)=4rho0Omega k²|h|²/a. Original equal-time CCR first fixes the dk amplitude; conversion to delta-angular-frequency normalization gives h²=a/[4rho0k²|Omega v_g|]. Since Omega v_g=Q_physical,k/2, h²=a/[2rho0k²|Q_physical,k|]. This fixes the source's conflicting factors independently. Negative norm is a creation operator, not a negative population. Current/density ratio omega/k checks continuity independently of the indefinite norm flux. No hbar,rho0 or group-speed factor is fitted to a desired temperature.

## 3. Quartic, threshold, analytic high/acoustic root domains

Dimensionless q=ak/v0,nu=aomega/v0² give Q=q^4+(s_j²-1)q²-2nu q-nu². In the left case p=-A, the depressed-quartic discriminant reduces to16nu²[-16nu^4+(1-20l²-8l^4)nu²+l²A³]. Thus the quoted positive t_+ and nu_* are the actual first positive threshold; the right discriminant has the stated nonreal-pair structure. Continuation from zero preserves all three physical channels on the original open subthreshold interval. The new smaller mathematical interval does not remove a channel or replace that threshold.

For high q0=+/-sqrt(A),+/-i sqrt(B), h=d0/8 gives |q|>=7|q0|/8 and |q+q0|>=15|q0|/8 on its circle. Hence the unperturbed modulus is at least735|q0|³h/512>=d0³h, whereas eta_h[2(H+h)+1]<d0³h/4. Rouché gives one root per fixed disc. Its contour moment is analytic in nu and uniqueness fixes the actual branch through zero; this is a constructed root domain, not an assumed inverse/gap.

For q=nu w, the quadratic atzero has roots wp=-1/(1-l),wd=-1/(1+l),wu=1/(s-1),wD=-1/(s+1). The separations2l/A and2s/B and hw<=sigma/8 imply the circle modulus >=(7/4)s_j hw>=l hw. On eta_w the quartic perturbation is <=l hw/4. Each acoustic w is uniquely analytic; because its equation is even in nu, so is the selected w. This regularizes the collapsing q roots without assuming a nonzero q-gap atzero.

The common eta bounds acoustic |q| by d0/8 and separates it from both high discs. At real positive nu the sign/conjugation/norm assignments remain the physical ones. Cauchy on radiuseta gives2h/eta and2hw/eta on radiuseta/2, then |q_ac'|<=W+hw. Even Taylor coefficients also give the displayed hw(|nu|/eta)²/[1-(|nu|/eta)²] bound. Every constant is strictly positive for each allowed original parameter, including every L>0; no uniform claim at an excluded critical parameter endpoint is made.

## 4. Reconstruct the actual minors and all regularization factors

The full p equation becomes product(vartheta-R_i)-z product(vartheta-S_j) with z=-exp(x/L). Factoring its left exponential gives the4F3 coefficient recurrence in the predecessor. The actual connection formula uses log(-z)=x/L without a hidden phase. Reflection and the sine-Cauchy determinant give the selected/complementary minor formula; n1 is the connection coefficient and n4 the Wronskian ratio, fixing its ordered sign.

For M0 rows(g,D)/columns(p,d), complements are(u,e)/(m,h); for M3 rows(g,D,u)/columns(p,d,m), complements are(e)/(h). Dividing their ACTUAL products leaves the Vandermonde ratio(Rp-Rm)(Rd-Rm)/[(Sg-Su)(SD-Su)]. The left Gamma quotient leaves Gamma(1+Rm-Rh) over Gamma(1+Rp-Rm)Gamma(1+Rd-Rm); the right quotient leaves Gamma(Su-Se) over Gamma(Sg-Su)Gamma(SD-Su). The other two reciprocal product groups supply Gamma(Rp-Su)Gamma(Rd-Su)/Gamma(Rm-Se) and Gamma(1+Sg-Rm)Gamma(1+SD-Rm)/Gamma(1+Su-Rh). Recurrence cancels the Vandermonde factors into exactly(7), including the incoming negative high-root choice.

Gamma(Rp-Su) and Gamma(Rd-Su) each have argument ib nu(w_out-wu). Shifting them and the two imaginary high-difference denominator Gamma factors yields EXACTLY Z=nu²M3/M0 in(8). There is no leftover nu power or separately evaluated divergent coordinate. Atzero the six numerator arguments are[1-2iell,r,1,1,1+r+iell,1+iell] and denominator[1+iell,1+iell,1+r,1,r-iell,1-iell]; real parts are>=c=min(1,r)>0. The elementary factors are iell,iell and nonzero acoustic differences.

The physical canceled-minor boundary determinant and its invariant subspace continuation remain the carrying result. Right integer/resonant exponent differences do not create a pole in these surviving products. Killing the complete growing solution kills its resonant descendants; row redefinitions by that row do not alter selected minors. The exact regularized physical amplitude therefore extends over every allowed L rather than requiring an integer-free population. This is not an assumption that separately divergent Frobenius rows can be numerically subtracted safely.

## 5. Physical flux ratio N and all complex nonzero denominators

Since Q_physical,k=(v0³/a)Q_q, q_u=nu wu and Q_q(q_u)=nu Du, the physical h ratio is exactly nu³ wu²Du/[-qm²Dm]=nu³N, with Du,Dm as(9). Atzero Du=2s,Dm=-2A^(3/2),qm=-sqrt(A), giving N0=s/[(s-1)²A^(5/2)]. Thus nu|beta|²=N|Z|². This checks the original units and signs rather than guessing their cancelling prefactor.

Du'=8nu w³+(12nu²w²+2B)w' is bounded by Lu. Dm'=(12qm²-2A)qm'-2 is bounded by Lm. The min radiusnu0 then gives |Du|>=s, |Dm|>=A^(3/2), |qm|>=sqrt(A)-h and |wu|>=wu(0)-hw. Every Gamma argument moves by<=2bM|nu|; nu0<=c/(4bM) keeps Re>=c/2 and nu0<=ell/(4bM) keeps the elementary high differences>=ell/2. Acoustic differences remain>=c_w-2hw>0. These are complex-disc bounds, not real-axis-only positivity extrapolated to complex analyticity. Every denominator in(11) is genuinely positive, including Lu; no silent zero-denominator convention is needed.

## 6. Derive the actual coefficient Theta

The acoustic product Pw=(wp-wu)(wd-wu) equals(A+B)/[A(s-1)²]. In Z0, (iell)²/(ib)²=ell²/b², Gamma(r)/Gamma(1+r)=1/r and one Gamma(1+iell) cancels. This gives the exact complex(12).

Recurrence/conjugation/reflection give |Gamma(1-2iell)|²=2piell/sinh(2piell), the denominator product modulus[piell/sinh(piell)]², and |Gamma(1+r+iell)/Gamma(r-iell)|²=r²+ell². The last factor is not squared a second time. Consequently |Z0|²=ell³(r²+ell²)tanh(piell)/(pi b^4r²Pw²). Inserting ell=b sqrt(A),r=b sqrt(B),Pw,N0 gives Theta_nu=sAB tanh(piell)/[pi b(A+B)(s+1)²].

Independently differentiating the FIXED c² profile at c=v0 gives kappa=(v0²/a)AB/[2b(A+B)]. The actual downstream factor is Gamma0=4s/(s+1)². Hence Theta=(v0²/a)Theta_nu=kappa Gamma0 tanh(piell)/(2pi). Its agreement with the separate old zero-mode Abel/normalization calculation is a crosscheck; that source limit is not inserted as the present proof's answer. Gamma0 remains nonunit and no incoming KMS/thermal state is selected to obtain the coefficient.

## 7. Explicit small zero-reaching error

All shifted arguments satisfy |z|<=Rg=1+2bQ and Re z>=c/2. The convergent digamma series therefore gives |psi(z)|<=1+2/c+Rg pi²/6, using |n+z|>=n and EulerGamma<1. N'/N contributes exactly the four positive terms in CN. Each elementary high-difference log costs<=4bM/ell, each acoustic-w-difference log<=2Mw/(c_w-2hw), and twelve Gamma logs cost24bM Psi together. Thus CZ and C=CN+2CZ are valid evaluated conservative constants, without unknown exact-beta values or a special-function supremum.

Z#(nu)=conjugate(Z(conjugate nu)) is analytic and nonzero on the symmetric disc with the same derivative bound. N is analytic/nonzero and positive on the physical real interval. Therefore G=NZZ#/(N0|Z0|²) has G0=1 and |G'/G|<=C. A simply connected disc supplies its logarithm; radial integration gives |logG|<=C|nu| and |G-1|<=exp(C|nu|)-1. This proves(16), and min(nu0,log(1+eps)/C) is a strictly positive explicit upper edge for every allowed input/tolerance. It reaches zero and avoids the old exact-center mismatch. Its possibly tiny size is not detector sensitivity or calibration. Vacuum occupation and weighted quasiparticle energy flux inherit this estimate; total IR particle number need not be finite.

## 8. Every first derivative and the nonzero finite coefficient

Implicit differentiation of the quartics gives qm'=qh'=1/A,qg'=qe'=-1/B and w'_j(0)=0. Thus Du'=0,Dm'=8 and N'/N0=6/A^(3/2). The two elementary high-difference logs contribute -4/A^(3/2) to Re Z'/Z; acoustic-w logs contribute zero.

I checked all twelve Gamma arguments, not only the final coefficient. Their derivatives divided by ib, in exact numerator/denominator order, are respectively
[0,wu+1/B,wp-wu,wd-wu,-1/B-1/A,wD-1/A]
and[wp-1/A,wd-1/A,-1/B-wu,wD-wu,1/A+1/B,wu-1/A].
Terms at real arguments contribute zero real part. The r+iell pair contributes b(1/A+1/B)Im[psi(1+r+iell)-psi(r+iell)]=-1/(B sqrt(A)). The remaining1+iell terms have coefficient b(wp+wd-wD-wu)=-2b(1/A+1/B). This gives(19).

Digamma reflection/recurrence gives Im psi(1+iell)=[pi coth(piell)-1/ell]/2. Before its rational cancellation, G'(0)=-2/A^(3/2)-2/(B sqrt(A))-4b(1/A+1/B)Impsi. The +1/ell part cancels BOTH rational terms, leaving -2pi b(A+B)coth(piell)/(AB)=-1/(2t0). Thus Theta_nu=Gamma0 t0 and the finite occupation coefficient is exactly-Gamma0/2, negative/nonzero throughout the allowed family.

The complex bound |G|<=exp(Cnu0), Cauchy coefficients and the geometric sum from degree2 give C2=2exp(Cnu0)/nu0² on |nu|<=nu0/2. Therefore |G-1+nu/(2t0)|<=C2nu² and the actual occupation error in(22) is<=Theta_nu C2nu. No unproved second derivative or desired coefficient is used.

## 9–10. Scalar Planck comparison, smoothing and units

With h(x)=x/(exp x-1), x=nu/t0, the comparison occupation is(Theta_nu/nu)h(x). Taylor's remainder on0<x<=1 gives |h-1+x/2|<=x²; explicitly its numerator is x³/4-(1-x/2)R and denominator>=x. Convexity gives h>=1/(e-1)>1/2. The verified SAME linear coefficient of G and h yields |G/h-1|<=2(C2+t0^-2)nu², the stated tolerance edge and no exact finite-frequency equality assumption. This is a scalar comparison, not KMS/global Gibbs or an incoming thermal preparation.

The exact finite-profile deficit is2/(exp(2piell)+1). Triangle inequality yields(24). At fixed rough profile a smaller tolerance against the UNMODIFIED greybody-weighted kappa scale cannot hold towardzero; that is a demonstrated comparison-domain fact, not infeasibility or deferral of the original device target. At fixed asymptotes ell D_H=Delta_l^(3/2)Delta_r/(2v0³Delta)>0, so the deficit is beyond all positive powers as D_H->0. No universal nonzero quadratic coefficient follows. Actual healing-length/profile/material conventions must still be matched to native adopted definitions. t0 and Theta are frequency scales; hbar(v0²/a)t0/k_B is only the declared comparison temperature unit, not a measured thermodynamic temperature. Real mu remains arbitrary and cancels from the relative equation rather than being tuned tozero.

## 11. Full corrected physical Hermitian contribution and filters

For the ACTUAL normalized outgoing-u mode, d_rho=-2rho0 k_u²h_u gives |d_rho|²=(2rho0/v0)nu wu²/Du. Continuity gives d_j/d_rho=omega/k_u=v0/wu, independently. Multiplying by n_u=Theta_nu G/nu yields exactly W_rho,W_j and the leading constants rho0Theta_nu/[v0s(s-1)²],rho0v0Theta_nu/s. Their units are time/length² and1/time. Log differentiation of the nonzero prefactors gives C_rho=2Mw/(wu0-hw)+Lu/s,C_j=Lu/s and(27). These are EACH-SIDED generated weights; they are not yet a full variance or electronic PSD.

From the original signed row b=A a_++beta a_-†+R a_D, incoming independent vacuum contractions give <b†b>=|beta|² and <bb†>=|A|²+|R|²=1+|beta|² by the actual pseudo-unitary CCR. Same-u <bb>=0 because the annihilation and negative-partner creation channels are distinct. This is the specified positive-frequency/u marginal, not a statement that full cross-channel, thermal or correlated covariances vanish. In particular partner anomalous covariance remains in the full predecessor transformation.

For X_E(t)=int_0^E[d b exp(-iomega t)+d* b† exp(iomega t)]domega/sqrt(2pi), direct contraction gives S^>(+omega)=|d|²(n+1),S^>(-omega)=|d|²n, S_sym on EACH side=|d|²(n+1/2). Outgoing-u vacuum subtraction or outgoing normal ordering leaves W=|d|²n on BOTH sides. The commutator difference is |d|², independent of n. The quantum half-background is not silently equated with a realizable experimental subtraction.

With the stated fhat(Omega)=int f(t)exp(-iOmega t)dt, X_f=int[d b f_++d* b†f_-]domega/sqrt(2pi). Thus X_f†=X_(conjugate f). Direct multiplication gives
<X_f†X_g>=int |d|²[n conjugate(f_+)g_++(n+1)conjugate(f_-)g_-]domega/(2pi),
<X_gX_f†>=int |d|²[(n+1)conjugate(f_+)g_++n conjugate(f_-)g_-]domega/(2pi).
Their half-sum and outgoing-vacuum subtraction are exactly(30). This explicitly checks complex adjoints and reversed ordering rather than using real-filter equality outside its domain. The generated diagonal is a positive integral form; Cauchy-Schwarz gives its stated cross-filter control.

For REAL f, f_-=conjugate(f_+), X_f is Hermitian and the generated variance is EXACTLY2 int_0^E |fhat|²W domega/(2pi). For complex f the nonnegative quantity is instead Delta<X_f†X_f>=int W(|f_+|²+|f_-|²)domega/(2pi). Therefore(31)'s(A_+²+A_-²) bound and its real-filter2 specialization follow from(27) without removing a frequency side. The conservative complex version is not mislabeled a Hermitian variance. The leading weighted form J_f in(32) contains both signs; integrating the pointwise relative bound gives its correctly weighted error. If J_f=0, both forms vanish and no relative division is allowed.

The real nonnegative smooth compact-time unit-integral filter is a concrete normalization countercontrol: ||fhat||infinity=1,fhat0=1,W->W0>0, hence V_gen/(W0E/(2pi))->2. The rejected r1 bound tends to1 on the SAME allowed physical parameters and shrinking edge. The repaired bound tends to2. This genuinely fixes S1 rather than renaming a one-sign annihilation-number quadratic form as the physical Hermitian variance. Exact one-sign frequency filters need their own time domain; no impossible compact-time one-sign test is assumed.

Under the convention variance=int_R dOmega/(2pi)|fhat|²S_sym, positive-angular one-sided PSD is2S_sym; the generated one is2W. If the angular density instead integrates against dOmega alone it is S_sym/(2pi). Substitution Omega=2pi f_Hz gives two-sided per-Hz S_sym(2pi f_Hz), one-sided2S_sym(2pi f_Hz), with NO extra2pi multiplier in this convention. Filters are evaluated at2pi f_Hz. d has units X sqrt(time); time-filter units1/time give dimensionless fhat and X_f units X, while dimensionless f gives fhat time and X_f units X*time. Equations30–33 consequently have the required dimensions at point of use.

For a real spatial weight on the homogeneous asymptotic plane wave, the actual multiplier is F_w(k)=int w(x)exp(ikx)dx. Its bound||w||1² gives the stated absolute variance bound. Nonzero mean gives the actual leading factor|int w|²; zero mean may null that leading direction and requires an absolute or higher-order estimate, never division byzero. Density/current or spatial-channel combinations must use their SUMMED complex coefficient BEFORE squaring. These statements do not import a plane wave into a finite inhomogeneous readout position or remove physical interference/evanescent/downstream terms.

Finally n~Theta/omega needs tests with int|h|²/omega finite, such as h=O(omega^p),p>0. The density/current coefficient supplies sqrt(omega), so bounded finite-time filters have finite generated diagonal and outgoing-vacuum half-background integrals here. Total IR quasiparticle number, unrestricted phase, global Fock implementation and whole local stationary CCR are NOT thereby proved. General nonvacuum/thermal/correlated inputs can require stricter weighted domains. The complete new section11, REPORT and control/units statements agree.

## 12–13. Assurance, physical residuals and disposition

The fixed threshold, all physical roots/channels, negative-norm creation assignment, collapsing acoustic regularization, nonunit Gamma0, finiteell tanh and every allowed L/resonance remain load-bearing. The DATA UNRUN independent root/canceled-Gamma reference versus a separately integrated full coupled BdG boundary problem is appropriate: it must validate residuals/flux/normalization, refine arithmetic/root branches/spatial cuts/asymptotics/frequency/filter quadrature independently, retain tinyomega/threshold/critical/small-largeell,r/integer/nonvacuum populations, and preserve every actual failed case. The added b/b† contraction versus two-sided spectral/variance/Hz calculation and unit-integral real-filter limit are meaningful independent references. Wrong norm/h/vg/rho0/pole/Gamma0/tanh/sign, deleted frequency side, missing2, false KMS/occupation-as-PSD and zero-leading-division poisons are not waived. Actual red/exact-byte-mode-nsmtime restore/green evidence needs future real allocation; no test, numerical/symbolic engine or native calculation ran here.

New r2 immutable initial6072d185 actually contains ALL literal7/64/3 keys, including infra.md={kind:missing}; I inspected that saved entry, not a later assertion. Its genuine MODEL and preproof ACK chronology are distinct from old P1. This correct prospective task does NOT repair old r1's missing initial absence or retrospectively accept its S1 bound. Old r1/whole-review/process exceptions remain unchanged/unwaived. Current author final was once rc1/owned-files only, not fresh/pass; its two directory timestamp movements retain UNKNOWN cause. My own final/terminal checks still follow this pre-final REVIEW and will be recorded literally in the other allocated leaves without rewriting this scientific verdict.

A later lead readback reports P advanced from initialD329 to3153094e with three new clock files and aggregate registration. That is NOT a changed mathematical model, favorable rebaseline, new clock-science acceptance or runtime grant. Actual terminal protection must measure the original P source/index/HEAD/refs differences, retain their raw bytes/stats/rosters and UNKNOWN actor/cause, and distinguish them from the unchanged fixed GP inputs/N/M. No current-P-fixed-D329 or blanket quiescence claim is made.

The accepted scientific increment is full fixed-model infrared leading-law/error plus corrected physical-u Hermitian generated covariance, at manual proof scope. The following ORIGINAL work remains substantive BUILD:

- Stationary indefinite wave-operator/spectral completeness, high-frequency contour closure, threshold/zero/generalized sectors, and a full stationary incoming positive whole-field test-algebra state with local equal-time CCR/noise identification. Separate finite-time field and band states cannot substitute.
- Microscopic gas-to-GP/BdG/depletion/coherence/phase/transverse/finite-geometry/preparation errors and quantified chiral reduction. Exact GP substitution does not establish these regimes for every symbolic parameter.
- Actual polariton/electronic/gas profile/dispersion/interactions/loss/input state, optical/electrical/contact/circuit receiver response and absolute calibration/uncertainty, independent microscopic routes and an identifiable NONEMPTY physically useful error-controlled band. A strictly positive, possibly tiny mathematical IR edge is not that band; particle current is not graphene electrical noise.
- ONE shared D1/E1/E2 law, THREE distinct L1 obligations, all21/B1–B8/D12, D5/pump/BEC/CHHK/transport, source G11, computation G4, proof G5, native/main/human gates and all prior actual failures.

No infeasibility, deferral, reduced charter, physical publication green or canonical closure is inferred. This genuinely independent WHOLE manual scientific review is ready for separate current lead intake. ROOT alone retains actual source/runtime/native/main coordination; SOURCE100/pending15ADW question grants nothing. Exactly five ignored review leaves are writable; authors' frozen models/notes/reports and lead notebook remain untouched.

<!-- END SOURCE137-EXACT-SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR-REVIEW -->
