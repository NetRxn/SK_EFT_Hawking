# Full GP/BdG leading law and uniform error — source-model

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** All thirteen sections, fixed GP model, analytic root/minor/Gamma normalizations, leading coefficient, explicit zero-reaching infrared error and corrected two-sided Hermitian generated covariance/filter/Hz conventions. Scalar Planck comparison is a specified mathematical comparison.

**Original physical obligations.** Stationary whole-field spectral/state completeness, local equal-time CCR/noise and missing sectors, microscopic/target-platform validity and calibrated receiver/useful nonempty physical band remain owed. Original P1/S1/process failures unwaived.

The construction author is publication_main55_independent_review; the complete independent scientific review is by publication_njl_target_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR](../SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md), [fixed source model](../source-models/SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md), [full independent review](../reviews/SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR-SOURCE_MODEL -->
# Prospective corrective full-GP/BdG source/model contract

Saved UTC: 2026-10-18T16:28:23.044799+00:00. The genuine FIRST and complete immutable initial-protection.json precede this save. This model is fixed BEFORE ANY new corrective mathematical scratch. No prior mathematical result or reviewer correction is silently counted as this author completion.

Retain the ENTIRE original symbolic continuum quasi-one-dimensional repulsive Bose-gas GP/BdG family, positive m,rho0,L and 0<c_l<v0<c_r, arbitrary real mu, fixed logistic c-squared profile, actual g/V, full quantum pressure, original field CCR and all physical co/downstream and negative-norm channels. Keep original state/preparation alternatives, operators, scattering/minor/flux normalization, infrared/test domains and full physical platform/readout/calibration objective. No favorable parameter/state/profile, chiral/free reduction, unit-greybody or thermal/KMS replacement is selected.

The corrective author objective is coherent repair of S1 in the entire thirteen-section leading-law construction: derive actual ordered/symmetrized/normal-ordered positive and negative frequency, angular/Hz and real/complex filter conventions for the physical Hermitian asymptotic-u density/current generated diagonal component, with correct bounds, dimensions, controls and report. Preserve every valid original root/Gamma/minor/Theta/coefficient/uniform-error/scalar-comparison proof and its domain; all other channels, cross/nonvacuum contributions and stationary whole-field limitations remain explicit. The earlier whole review and all earlier calculations are immutable historical inputs, not new author mathematics.

The old author P1 missing known primary absence is FAILED PROCESS, UNWAIVED; this new prospective task cannot backdate or cure it. All prior process/ref/admin UNKNOWNs remain. The full original shared D1/E1/E2 law, stationary spectral completeness/whole-field local CCR/state/noise, gas-to-GP/BdG/transverse/depletion/preparation, device/pump/BEC/electronic readout/calibrated useful-band, all21/B1-B8/D12, THREE distinct L1 roots, CHHK/G4/G5/G11/native/main/human objectives remain BUILD. No source/runtime/native/project/model/test/engine or Git/book/holding/closure execution/mutation is authorized.

STOP before ANY corrective mathematical scratch after this save until publication scientific lead explicitly acknowledges documentary manual-scope preflight. That acknowledgement will not be independent scientific acceptance or runtime/native authority. This author cannot review or accept this r2; a fresh genuinely nonauthor WHOLE review is required after freeze.

## Byte-exact historical full original leading-law MODEL17c444c0

<BEGIN_ORIGINAL_LEADING_MODEL>
# Fixed same-family full-GP/BdG infrared leading-law author model

Prospectively fixed after genuine FIRST/full initial protection and saved BEFORE any new root/Gamma/coefficient/IR-remainder/interval or other mathematical scratch by this author. The entire original model below is byte-exact and unchanged. Retain all m,rho0,L>0,0<c_l<v0<c_r, real mu, v=-v0, logistic c^2, actual g and V, full quantum-pressure BdG operator, all channels/root domains, field CCR and state/measurement normalization. No weak-dispersion/chiral/free/profile/graybody=1/thermal-state replacement or universal quadratic law is permitted.

The prospective objective is an independently derived actual leading infrared conversion law and an explicit uniformly SMALL relative or correctly weighted remainder on a nonempty interval reaching omega->0, using the actual full root/connection/minor/flux normalization and repeated-root limits for all allowed L. No unproved analytic extension/gap, unknown exact-beta supremum, compact interval away from zero or exact-centre tautology may replace that objective. The original leading Theta formula is a target to DERIVE, not an assumption. Any unresolved clause must remain a precise substantive construction with attempts/next action, not a changed physical objective. Original stationary whole-field completeness/state and gas/material/GP/BdG/device/receiver/calibrated-band errors remain BUILD unless proved. Whole-note nonauthor review is mandatory. Old process failures remain unwaived. No model/mathsoftware/project/test/native/runtime or actual source/Git/holding/book/closure mutation is authorized.

## Byte-exact original fixed model enclosure

<BEGIN_ORIGINAL_MODEL>
# Fixed physical source/model contract before new author mathematics

Saved UTC: 2026-10-18T11:43:52.046206+00:00. The original FIRST d8a053 was fresh at11:41:08UTC. Genuine scoped14reference/full tracked+known dirty/raw-semantic index/HEAD/status/refs protection was persisted252ea2 before this file and before any new derivation/scratch mathematics. Model selection is now fixed; no favorable parameter tuning is allowed.

This is a new SCIENCE author task, not renewal of this worker's earlier SOURCE reviews. The publication lead's prospective c6623fb4 planning and limited primary readings predate this MODEL, explicitly as unverified planning, not accepted proof or backdated model-first credit. The previous reviewed chiral KdV construction d8717ddd and whole review retain their exact narrower scope. Its logistic s=c-v is not identified with the new physical profile.

Select a continuum quasi-one-dimensional repulsive contact Bose gas with physical mass m>0, linear background density rho0>0 and constant physical flow v=-v0. Fix the entire symbolic family L>0,0<c_l<v0<c_r and arbitrary real chemical potential mu. The sound-speed-squared profile is

    c(x)^2 = c_l^2 + (c_r^2-c_l^2)/(1+exp(-x/L)).

The physical contact coupling g(x) and real static external V(x) must be determined from this profile and the exact stationary GP equation, not assumed independent or fitted to a spectrum. The field retains its physical equal-time bosonic CCR and units; no normalized scalar replaces the actual field. GP and its full quantum-pressure BdG linearization are explicitly approximations to the many-body gas. Quasi-1D transverse reduction, weak depletion/quasicondensate domains and physical implementation/material errors are independent obligations; no claim applies automatically to pumped polaritons, bilayer graphene or a calibrated experiment.

Derive the actual quadratic action/Hamiltonian, density/phase and particle-current observables, symplectic norm/flux and delta-frequency plane-wave normalization from the original field CCR, correcting any source text/sign/group-velocity inconsistency by calculation. Retain the co-propagating downstream channel and negative-norm partner. The three-channel scattering below the actual supersonic threshold must be constructed from the same differential operator/profile and its asymptotic conditions, not supplied as arbitrary pseudo-unitary data. Above-threshold, evanescent, bound, unstable and zero-frequency sectors cannot silently disappear from a claim about the complete field.

Specify the incoming quasifree vacuum and thermal alternatives as actual positive quantum states with the correct creation/annihilation assignment for negative-norm branches; retain outgoing occupations, anomalous cross covariance and physical filtered density/current correlations with frequency/Hz/sidedness and units. Do not postulate a Planck law, greybody factor or bath occupation as the result. A scattering-sector formula alone is not full continuum spectral completeness or proof of dynamical stability.

Derive the actual profile's low-frequency coefficients and its relation/contrast to the reviewed chiral approximation. The carrying primary is Coutant–Weinfurtner arXiv1707.09664v2, version12January2018. The author's first official HTML read before MODEL covered introductory/model/scattering setup through general matching onset, while full carrying sections/matching/constant-flow example/AppendicesA–C must be personally read before their use. Earlier lead reads and secondary notes are context only. No fulltext is downloaded, saved or admitted. Own mathematical notes will identify exact primary inputs and independent derivations.

The assigned finite-frequency result requires a meaningful uniform remainder for this actual full profile/operator with parameter-derived constants on a proved nonempty interval. Nominal O(omega), an unspecified inverse/gap/error, a finite-box cutoff, a low-frequency limit or a postulated favorable S-matrix does not fulfill it. Prove necessary construction/stability/domain assumptions where possible. If an actual lemma remains missing, preserve the exact attempted estimates and decomposition as BUILD rather than inventing a bound, declaring infeasibility or presenting a conditional/toy result as complete.

Original shared D1/E1/E2 physical law/profile/in-out-state/observable/units/error/device and calibrated identifiable usable-band work remains owed. No universal pi/6 coefficient, universal replacement, physical target narrowing, native/runtime/source/gate/closure/main acceptance or deferral is authorized. Seven allocated ignored files only; no project/helper/model/mathsoftware/test/recipe execution, actual source/Git/holding/registry/notebook mutation or delegation. A fresh genuinely nonauthor whole scientific review and separate lead intake must assess the resulting complete work. ROOT retains actual application/runtime/native/full gates/main.

<END_ORIGINAL_MODEL>

<END_ORIGINAL_LEADING_MODEL>

<!-- END SOURCE137-EXACT-SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR-SOURCE_MODEL -->
