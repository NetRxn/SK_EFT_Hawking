# E1 three-well electron–hole/localized-exciton phonon projection

AUTHOR MANUAL CONSTRUCTION. This derives a normalized microscopic projection and correlated thermal matrix beyond the preceding generic overlap family. It is a source-qualified candidate construction, with full scoped independent manual verification recorded in the linked original review. It does not identify actual Falque disorder/spin states, supply fitted material constants or complete the E1/D1 spectrum/noise/band BUILD. SOURCE_MODEL was saved before new scratch. No model/software/native evaluation.

## 1. Source, microscopic Hilbert space and the approximation being built

Primary carrying source: [Savona, author preprint](https://arxiv.org/pdf/cond-mat/0702179), full Section2 Eq1–14 and Section3.2 Eq18–25. Its normalized rigid-exciton/COM framework supplies a construction route and explicit disorder/relative-state/scalar-light limitations. [Falque heldv2](https://arxiv.org/html/2311.01392v2) III/AppB supplies the three-well/Hopfield geometry and source-specific response constraints. [Stepanov](https://www.nature.com/articles/s41467-019-11886-3), existing supplement Notes1/3/Eq25–26, motivates localized states/acoustic phonons and separately the density-phonon forcing. None fixes target microscopic spinors or offdiagonal conversion. Detailed read/version/access evidence remains in the accepted scout and this report; new web reads are not admitted holdings.

Let ell=1,2,3 label THREE orthogonal electronic well sectors at actual positions z_ell, retained symbolically. The direct-sum electronic model excludes indirect electron–hole pairs and interwell tunneling unless explicitly included in H_X or in the residual below. Orthogonal sectors can be realized exactly by separated infinite-barrier wells; finite-barrier target states require their actual overlap/tunneling calculation. Choosing an orthonormal localized BASIS for a subspace is not permission to Gram–Schmidt physical Hamiltonian eigenvectors or discard tunneling. In the declared direct-well model, a one-body phonon operator does not move the spectator carrier to another well, so it is block diagonal in ell even though the BATH is shared.

For positive electron/hole in-plane masses m_e,m_h put M=m_e+m_h, mu=m_e*m_h/M, alpha_e=m_e/M, alpha_h=m_h/M. With in-plane coordinates rho_e,rho_h,

R=alpha_e*rho_e+alpha_h*rho_h, r=rho_e-rho_h,
rho_e=R+alpha_h*r, rho_h=R-alpha_e*r,
d²rho_e d²rho_h=d²R d²r,
T_parallel=-(hbar²/2M)Delta_R-(hbar²/2mu)Delta_r.                  (1)

For each Cartesian coordinate the inverse transformation determinant is-(alpha_e+alpha_h)=-1; the two-dimensional absolute Jacobian is1. This fixes both relative Fourier arguments below; no inverse-mass factor is silently exchanged.

Take normalized z envelopes f_eell(z),f_hell(z), each with integral|f|²dz=1; a normalized relative1s state phi_ell(r) with integral|phi|²d²r=1; and orthonormal COM spinors u_ella,sigma(R), sum_sigma integral u_ella,sigma* u_ellb,sigma d²R=delta_ab. A pair wavefunction in sector ell is

Psi_ella,sigma(r_e,r_h)=f_eell(z_e) f_hell(z_h) phi_ell(r) u_ella,sigma(R).
<Psi_ella,Psi_ell'b>=delta_ell,ell' delta_ab.                    (2)

The units are f:L^-1/2, phi:L^-1, u:L^-1, Psi:L^-3, giving a unit norm in the six carrier coordinates. Arbitrary complex envelopes require the displayed conjugates in all inner products. Spin may be position-dependent through u. All electronic states used in an exact eigenmode calculation are retained as such; the factorization is a stated rigid-relative-state projection, with its residual controlled in Section7 rather than claimed physically exact.

Projecting a scalar confinement/disorder perturbation U_eell(rho_e)+U_hell(rho_h) into(2) produces the COM matrix potential (spin identity in this scalar version)

V_ell(R)=integral d²r |phi_ell(r)|²
              [U_eell(R+alpha_h*r)+U_hell(R-alpha_e*r)],
H_COM,ell=E_1s,ell-(hbar²/2M)Delta_R+V_ell(R).                   (3)

This is the actual electron/hole convolution behind the source COM model. U contains z-averaged band-edge confinement fluctuations; a spin Hamiltonian, tunneling and relative-state couplings must be retained if present. No target disorder variance/correlation length/well width is assigned from a different sample.

## 2. Relative and finite-well form factors, including the signed hole convention

Fix a longitudinal acoustic phonon field in normalization volume V_B, rho_m mass density, Omega_Q=u_s|Q|, Q=(q,q_z), and real signed band-edge deformation energies a_c, a_v. By DEFINITION a_c*divU is the conduction-electron band-edge shift and a_v*divU the VALENCE-ELECTRON band-edge shift. The positive hole excitation shifts by MINUS that valence-edge shift. Thus the pair interaction is

v_Q=s_Q[a_c exp(iQ.r_e)-a_v exp(iQ.r_h)],
s_Q=sqrt[hbar|Q|/(2rho_m V_B u_s)],
H_ep=lambda sum_Q v_Q (b_Q+b_-Q†), v_-Q=v_Q†.                    (4)

s_Q is dimensionless, v_Q an energy; lambda is dimensionless. If a source instead defines a HOLE deformation energy D_h, use D_h=-a_v and write a_c electron PLUS D_h hole; applying another minus would be wrong. This fixes convention without importing numerical constants. The signed energies may be well-dependent; equations(4–5) are then read with a_c,ell and a_v,ell in each well. Identical-well examples below explicitly specialize them. Strain/quadrature phase conventions may change together with coefficients while preserving Hermiticity. Multiple acoustic branches require their own polarizations/strain tensors and sums, not a fitted scalar substitution. No optical drive makes this closed Hamiltonian time independent, not the bare pair/phonon energies separately conserved.

Define

F_eell(q_z)=integral dz |f_eell(z)|² exp(iq_z z), and similarly F_hell,
I_ell(k)=integral d²r |phi_ell(r)|² exp(ik.r),
M_ell,ab(q)=sum_sigma integral d²R u_ella,sigma*(R)
                                      exp(iq.R)u_ellb,sigma(R).
G_ell,ab(Q)=s_Q[a_c F_eell(q_z) I_ell(alpha_h*q)
                         -a_v F_hell(q_z) I_ell(-alpha_e*q)]M_ell,ab(q).                 (5)

This follows by inserting BOTH inverse coordinates in(4) and factorizing the three normalized integrals. For a complex anisotropic relative state, I need not be real/even; retain its sign/conjugation. I(-k)=I(k)* and F(-q_z)=F(q_z)*. M_ab(-q)=M_ba(q)*, hence G_ell,ab(-Q)=G_ell,ba(Q)* exactly. Offdiagonal spinor overlap is not generally the product of a constant spin overlap and a spatial integral. If different relative/subband states are retained, replace each density form factor by its actual cross integral with bra/ket conjugates; the definition integral Psi_a* v_Q Psi_b is the general formula. Equation(5) is the explicitly declared common1s/common-subband manifold.

For a fully derived normalized2D exponential1s candidate take a>0,

phi(r)=sqrt[2/(pi*a²)]exp(-|r|/a),
I(k)=[1+(a|k|/2)²]^-3/2, phi(0)=sqrt[2/(pi*a²)].                 (6)

Normalization follows from integral_0^infinity r exp(-2r/a)dr=a²/4 and the angular factor2pi. Angular integration gives J0(|k|r); differentiating integral_0^infinity exp(-kappa*r)J0(kr)dr=(kappa²+k²)^-1/2 gives the weighted radial integral kappa/(kappa²+k²)^3/2. With kappa=2/a and the normalization coefficient4/a² this is(6). The Laplace identity follows by integrating the angular representation of J0 against exp(-kappa*r), kappa>0. The factor is dimensionless, real/even and equals1 at0. The length a is not a material Bohr radius until its Coulomb/confinement equation is matched; here a is the declared relative-state length.

A second explicit controlled confinement candidate is the normalized infinite square well centered at z_ell with width w_eell>0:

f_eell(z)=sqrt(2/w_eell)cos[pi(z-z_ell)/w_eell] for |z-z_ell|<w_eell/2,
F_eell(q_z)=exp(iq_z*z_ell) f(q_z*w_eell/2),
f(t)=pi² sin(t)/[t(pi²-t²)], f(0)=1, f(pi)=f(-pi)=1/2.            (7)

The same holds for the hole with its own width. For an exact separated-square-well realization, choose supports in distinct wells disjoint for both species; otherwise retain actual overlaps/tunneling in the larger model. Expanding2cos²=1+cos(2pi*zeta/w) gives sinc(t)+[sinc(t+pi)+sinc(t-pi)]/2, which is exactly(7) with removable limits. The position PHASE must remain. General finite-barrier envelopes use their actual Fourier integral, |F|<=1; square wells are an analytic candidate rather than claimed measured wells. Also |I|<=1 and ||M(q)||<=1 for a complete orthonormal manifold compressed from the unitary multiplication exp(iq.R). A finite selection is a contraction. Consequently ||G_ell(Q)||<=s_Q(|a_c|+|a_v|) within these scalar assumptions.

## 3. Normalize complete hybrid eigenmodes before projecting

Use the one-excitation space H_one=H_photon direct-sum [direct-sum_ell H_Xell], with orthonormal photon modes |c_m> and the electronic basis(2). The Hermitian linear system Hamiltonian is

H_lin=sum_mn h_C,mn |c_m><c_n|+sum_la,l'b h_X,la;l'b |X_la><X_l'b|
                     +sum_m,la [kappa_la,m |X_la><c_m|+h.c.].
|p_mu>=sum_m C_mmu|c_m>+sum_la X_la,mu|X_la>,
sum_m C_mmu* C_mnu+sum_la X_la,mu* X_la,nu=delta_mu,nu.           (8)

Retain actual tunneling/spin mixing in h_X if present. A complete unitary eigenbasis gives canonical mode operators in the adopted dilute bosonic carrier. The physical electron/hole projection is exact at the ONE-PAIR level; replacing many composite excitons by exact bosons is a separate density/Pauli-overlap approximation not controlled by the single-pair projection bound. No actual Falque density permits silently accepting it. Photon leakage and nonradiative losses enter as separate open-system channels, not by treating right eigenvectors of a non-Hermitian loss matrix as an orthonormal canonical basis.

Orthogonal complete hybrid modes generally have NONORTHOGONAL exciton components:

sum_la X_la,mu* X_la,nu=-sum_m C_mmu* C_mnu for mu!=nu.
G_mu,nu(Q)=sum_ell,a,b X_ella,mu* G_ell,ab(Q) X_ellb,nu.          (9)

Thus a phonon matrix can connect orthogonal hybrid modes even for an electronic scalar operator. After factoring out the LA strain prefactor, a spatially uniform scalar DEFORMATION operator on the electronic sector is its projector, not identity on H_one; an actual Q0 LA displacement has zero strain prefactor. Do not set(9) to zero by Gram–Schmidt on X or rescale each X to unit norm. Diagonal G_pp, offdiagonal G_jp and all dark–dark G_jk are parts of ONE projected matrix. The polariton diagonal term carries its excitonic probability, a pure-exciton→polariton amplitude carries one Hopfield amplitude, and a general hybrid→hybrid term carries both actual coefficients. G(-Q)=G(Q)†. A completely photon-like mode has zero deformation coupling in this model.

The dipole selection must also use normalized pairs. Let E_m(R,z) be the physical electric field amplitude per photon of the selected cavity mode, normalized by its electromagnetic energy with the actual dielectric structure. Its units are V/m; its normalization is NOT inferred from the observed pump waist. For a fixed dipole vector d_cv,sigma, the rotating-wave pair-creation coefficient is

kappa_ella,m=-phi_ell*(0) sum_sigma integral d²R dz
 u_ella,sigma*(R) f_eell*(z) f_hell*(z) d_cv,sigma.E_m(R,z).         (10)

With a physical one-photon field this has energy units: the R integral supplies a length, phi(0) removes it, z overlap is dimensionless, and dipole times field is energy. This is the coincident electron/hole coordinate matrix element, not a phonon overlap. Optical weights into a specified external mode depend on(10) and its physical mirror/collection channel. A state is dark to a specified optical set if ALL those matrix elements vanish; small but nonzero weights mean weak brightness. Darkness may arise from spin, parity, momentum or three-well interference, with different phonon consequences. The actual accessible optical set and spin preparation remain target inputs.

For an isolated bright exciton combination |B>=sum_ell b_ell|X_ell>, sum|b|²=1, coupled to one photon with energy coupling kappa_B, the exact normalized two-mode eigenvalues are

E_±=(E_C+E_B)/2 ± sqrt[((E_C-E_B)/2)²+|kappa_B|²],
|P>=C|c>+X|B>, |C|²+|X|²=1,
|X_-|²=[1+(E_C-E_B)/sqrt[(E_C-E_B)²+4|kappa_B|²]]/2.             (11)

The formula follows by diagonalizing the Hermitian2×2 matrix; it matches the sign convention of an exciton-photon detuning E_B-E_C in the complementary form. A photon antinode fixes neither all b_ell nor relative signs until the optical field and overlaps in(10) are supplied. Finesse/Hopfield measurements constrain this structure, not absolute dark-mode normalization or loadedQ.

## 4. A shared three-well phonon field is not three independent baths

Within identical relative/confinement channels and the SAME normalized COM spinor u in each well, write G_ell(Q)=exp(iq_z*z_ell)g_0(Q)M(q). Define h(Q)=g_0(Q)M_uu(q), retaining the actual COM density form factor. For dark well vector d and bright vector b,

G_DP(Q)=X*h(Q) sum_ell d_ell* b_ell exp(iq_z*z_ell),
G_PP(Q)=|X|²*h(Q) sum_ell |b_ell|²exp(iq_z*z_ell).              (12)

The sum is coherent at each Q; a rate contains its squared modulus, with cross-well interference. It is not sum|d*b|²/3 or an independent-bath average. As a concrete symmetric well-channel control, use positions(-d,0,d), d>0, b=(1,1,1)/sqrt3 and d_vec=(1,0,-1)/sqrt2. In a degenerate uncoupled three-well electronic Hamiltonian and equal chosen optical couplings, d_vec is a legitimate dark E_B eigenmode; it is not a projected/reorthogonalized polariton.

G_DP(Q)=-i sqrt(2/3) X*h(Q) sin(q_z*d),
|G_DP(Q)|²=(2/3)|X*h(Q)|²sin²(q_z*d).                          (13)

It vanishes for common-phase q_z*d0; where h(Q)!=0 it is nonzero whenever sin(q_z*d)!=0. Exact optical destructive interference therefore need not forbid phonon conversion. Conversely it does not prove any specified material coefficient nonzero, nor establish an energetically downward channel: a lower polariton lies below the uncoupled dark E_B in this simple model, so P→D is uphill at zero density.

For channel coefficients g_ell(Q)=h(Q)exp(iq_z*z_ell), the emitted spectral cross matrix has entries proportional to sum_Q |h|² exp[iq_z(z_ell-z_ell')]delta(v-Omega_Q). In the ideal isotropic POINT-coupling angular average, it is a diagonal weight times sinc(v|z_ell-z_ell'|/u_s). This follows from half integral_-1^1 exp(iQ*Delta_z*x)dx=sin(Q*Delta_z)/(Q*Delta_z). Real finite-well/angular form factors keep their weighted angular integral instead. Long wavelength gives a nearly rank-one common bath; within a shell |exp(iq_z*Delta_z)-1|<=|Q*Delta_z| gives a direct absolute deviation bound by |Q*Delta_z| times its positive diagonal weight. Approximate decorrelation needs an actual oscillatory-integral/error bound over the admitted frequency band; in the point-shell example |sinc x|<=min(1,1/|x|). The low-frequency band never becomes uniformly independent by declaring large spacing. No division by3 is generated by these formulas.

## 5. A solvable localized COM example with exact nonzero overlap and optical controls

Choose the DECLARED candidate COM Hamiltonian on the full plane

h_X=E_ref-(hbar²/2M)Delta_R+(M omega_t²/2)|R|²,
l=sqrt[hbar/(M omega_t)], omega_t>0,
u_0(R)=(sqrt(pi)*l)^-1 exp(-|R|²/(2l²)),
u_1(R)=sqrt2*(x/l)u_0(R), E_0=E_ref+hbar omega_t, E_1=E_ref+2hbar omega_t. (14)

Both functions are real, normalized and orthogonal: Gaussian moments give <x²>_0=l²/2 and parity gives<u_1,u_0>=0. Direct differentiation in h_X gives the displayed eigenvalues, so no eigenmode was changed by an orthogonalization trick. The source localization model permits a COM potential; the harmonic potential here is a solvable family, not a claimed target disorder reconstruction.

The normalized density Fourier transform is exp(-l²|q|²/4). Differentiating it with respect to q_x gives

M_10(q)=integral u_1 exp(iq.R)u_0 d²R
             =i*l*q_x/sqrt2 exp(-l²|q|²/4),
M_00(q)=exp(-l²|q|²/4).                                         (15)

At q0 the offdiagonal overlap is exactly0; at finite q_x it is nonzero. Multiplying(15) by the fully calculated electron/hole bracket in(5) produces the actual analytic transition amplitude, including finite-well position phases and relative Fourier factors. It is nonzero whenever q_x!=0 and that bracket!=0. Deformation-energy cancellation is an explicit exception, not suppressed. The Q0 LA strain prefactor itself vanishes; this is distinct from the in-plane q0 orthogonality control at possibly finite q_z.

To make the hybrid example an EXACT eigenmodel WITHIN the declared retained1s projection (whose microscopic residual is calculated in(25)), specify ONE photon mode whose in-plane electric profile is proportional to u_0 and identical selected spin in all three wells. Its optical matrix couples only each well's u_0, because the COMPLETE oscillator eigenbasis has<u_n,u_0>=delta_n0. Retain all uncoupled oscillator eigenmodes; the hybrid P formed with the bright three-well u_0 combination is exactly(11). A normalized D=|ell,u_1> is an actual orthogonal uncoupled exciton eigenmode. Its overlap with P is X*b_ell times(15), times the bracket in(5). Their orthogonality is physical in the full direct sum, not enforced by changing their exciton parts.

Optical weights are channel-specific. With Fourier convention U_a(k)=integral u_a(R)exp(ik.R)d²R,

U_0(k)=2sqrt(pi)*l exp(-l²|k|²/2),
U_1(k)=i*2sqrt(2pi)*l²*k_x exp(-l²|k|²/2),
W_0(k)=4pi*l² exp(-l²|k|²),
W_1(k)=8pi*l^4*k_x² exp(-l²|k|²).                               (16)

Parseval gives integral W_a(k)d²k/(2pi)²=1, so these are normalized momentum weights with area units, not unspecified number densities. u_1 is exactly dark to normal-incidence plane waves and the selected u_0 cavity mode, but weakly bright at small nonzero k_x. It is NOT dark to all propagating optical modes. A physical finite aperture measures its actual integral with the external mode/dipole/collection weight in(10); an ideal plane wave is a continuum mode, not an exactly normalized finite-A Gaussian. Finite sample boundaries or additional photon modes are omitted couplings subject to Section7, not claimed absent.

In this example E_D=E_1>E_0>E_- for nonzero optical coupling, hence the zero-density forward gap (E_--E_D)/hbar is NEGATIVE. The calculated nonzero finite-q matrix therefore requires phonon absorption for P→D and has zero positive-gap emission at T0; D→P can emit. The example proves neither a downward target reservoir nor a positive thermal band. A different measured localized energy could change that sign, which must be calculated rather than selected for convenience.

Forbidden-spin control: if the pumped spinor and D have disjoint spin support and a_c,a_v are spin identity, each pointwise spin sum in(5) vanishes at EVERY Q. All conversion amplitudes vanish even though a density-phonon diagonal term survives. Spatial parity can instead make optical weight0 while(15) is nonzero. Three-well optical interference gives the independent control(13). These three controls demonstrate why optical darkness alone implies neither zero nor nonzero phonon conversion.

## 6. Full unsymmetrized correlated spectrum, thermal signs and interacting channels

On the finite adopted bosonic system carrier, second-quantize the COMPLETE hybrid matrix, not only selected P↔D terms:

F_Q=sum_mu,nu G_mu,nu(Q) a_mu†a_nu, F_-Q=F_Q†,
H_int=lambda sum_Q [F_Q b_Q+F_Q†b_Q†].                           (17)

This is the reindexed form of sum F_Q(b_Q+b_-Q†). It preserves the total number of system excitations, includes diagonal density scattering and all offdiagonal conversion, and is Hermitian. It is not a derivation of Pauli-free bosons at arbitrary physical density. On a finite system basis choose dimensionless Hermitian matrices S_A spanning its operator space and expand F_Q=sum_A v_AQ S_A. Then B_A=sum_Q(v_AQ b_Q+v_AQ* b_Q†) is Hermitian with energy units and H_int=lambda sum_A S_A B_A. Spin/well/channel correlations remain in the COMPLEX coefficients v; no independent-bath declaration is made.

For a free Gaussian thermal phonon bath, n_Q=[exp(beta*hbar*Omega_Q)-1]^-1, define the unsymmetrized transform with exp(+ivt). Direct contractions yield the positive matrix-valued spectral measure

Gamma_AB(v)=(2pi*lambda²/hbar²)sum_Q {
 (n_Q+1)v_AQ v_BQ* delta(v-Omega_Q)
               +n_Q v_AQ* v_BQ delta(v+Omega_Q)},
Gamma_AB(-v)=exp(-beta*hbar*v)Gamma_BA(v), v>0.                  (18)

Positivity follows for any complex vector c from each outer product: c†v v†c=|v†c|²>=0 and the conjugate vector similarly. The KMS transpose follows because on the positive shell n_Q=exp(-beta*hbar*v)(n_Q+1). Delta contributes time units; Gamma has rate units. In a finite discrete bath this is a measure, not a finite pointwise rate. Continuum density/correlation convergence and actual bath state are additional physical requirements; summing a delta at a discrete energy is not an irreversible law.

For a three-dimensional continuum with the declared linear acoustic branch, sum_Q becomes V_B integral d³Q/(2pi)³. Write v_AQ=s_Q d_A(Q), with d_A an energy-valued projected deformation coefficient. The normalization volume cancels exactly, giving on a positive shell

Gamma_AB(v)=lambda²/[8pi² rho_m hbar u_s] integral d³Q |Q|
 d_A(Q)d_B(Q)*[n_B(u_s|Q|)+1]delta(v-u_s|Q|)
 =lambda²*v³/[8pi² rho_m hbar u_s^5] [n_B(v)+1]
     integral dOmega d_A((v/u_s)Qhat)d_B((v/u_s)Qhat)*.

The radial integral is Q³/u_s at Q=v/u_s. This has rate units and preserves the well/angular form factors. A phonon guide, discrete confinement branch or different bath dimension requires its ACTUAL density of states instead; no arbitrary normalization area survives as a fitted rate. COM profiles remain normalized, so changing their physical area changes M and optical mode overlaps, not a free multiplicative V_B. This continuum conversion is conditional on correlation/integral existence, not an admission of any target spectrum.

Let H_S be the actual finite Hermitian system Hamiltonian including retained interactions. Form S_A(v)=sum_(E-E'=hbar*v)P_E' S_A P_E, retaining COMPLETE degenerate blocks. Positive Gamma defines the finite spectral GKSL model with coefficients Gamma_AB(v) and jumps S_B(v), including Lamb-shift terms under their convergence/renormalization assumptions. This is a MODEL reduction of(17); no finite-coupling driven Davies/Floquet error is inferred. The prior thermal construction supplies distinct defined CP/locality/error comparisons, not automatic rate-flatness equivalence.

For the diagonal interaction specialization used to compare to that note, let n be pumped-mode number and m_j dark occupations,

H_S/hbar=omega_p*n+(U/2)n(n-1)+sum_j omega_j*m_j+n sum_j chi_j*m_j,
nu_(n,m;j)=omega_p-omega_j+U(n-1)+sum_k chi_k*m_k-(n-1)chi_j.      (19)

Subtracting the final energy at(n-1,m+e_j) gives every term. The forward squared bosonic factor is n(m_j+1); the same actual matrix appears in reverse with opposite energy. Degenerate common omega_j,chi_j recover the earlier nu0+U(n-1)-chi(n-r-1). General dark interactions/mixing require the spectral projectors of their actual Hamiltonian rather than this convenient diagonal formula. Simultaneously rotating all species by omega_l times total number leaves these conversion gaps unchanged. A bare exciton optical energy, laser detuning or collective reservoir-density pole cannot replace(19).

For nu>0, T0 leaves emission and removes reverse absorption; a negative forward gap uses Gamma(-|nu|). At zero gap group the full spectral block and evaluate a legitimate full-product limit, not n_B(0). Matrix KMS does not make every forward/reverse pair equal. The conditional total-R scalar law of the accepted note requires identical dark Hamiltonian/couplings, R-charge-separated spectral blocks and a genuinely isotropic channel matrix Gamma_jk(v)=Gamma(v)delta_jk/J on the matched transition space, together with compatible other terms preserving the normalized dark-sector lift. A shared three-well field is generally correlated or low rank and does not meet that condition. Unitary diagonalization of its spectral matrix can produce collective jumps, but cannot transform unequal eigenvalues into isotropic J rates or retain an unrelated diagonal dark Hamiltonian by assertion. Refuse that reduction unless actual matrix/degeneracy/error evidence establishes it; keep(17–19) otherwise.

## 7. Controlled projection error on an explicit finite energy/bath domain

The analytic projection must carry an error contract. For this purpose ALONE fix a larger finite electronic/photonic energy basis, a finite total-system-particle cutoff L, finitely many phonon modes and phonon number caps K_Q. Compress their operators into that finite Hilbert space so the CLOSED Hamiltonian H is a bounded Hermitian matrix. This auxiliary error-domain bath is not silently identified with the untruncated Gaussian bath used in(18); a capped thermal oscillator has boundary corrections to its Bose correlators. Removing energy/mode/phonon caps requires its own tail/domain evidence.

Let P project to the declared retained system subspace tensor the identity on this finite bath; Q=1-P, let v=||Q H P|| (energy), and H_d=PHP direct-sum QHQ. For any unit initial vector psi=Ppsi, Duhamel gives

||(exp(-iHt/hbar)-exp(-iH_d t/hbar))P||<=|t|v/hbar,
||Q exp(-iHt/hbar)psi||²<=min(1,t²v²/hbar²),
||rho_full(t)-rho_projected(t)||_1<=min(2,2|t|v/hbar).            (20)

Proof: (H-H_d)exp(-iH_d s/hbar)P=QHP exp(-iPHP s/hbar)P. Both full/diagonal propagators are unitary and the integrand has norm<=v. Leakage is no greater than the vector difference; pure-state trace distance is at most twice vector distance and convexity extends to mixed supported states. Partial trace is contractive. For an observable O its expectation error is <=||O|| times the last bound. This is a genuine finite-time omitted-state bound; no dimensionless heuristic hides the actual coupling.

A usable residual decomposition is

v<=r_S+|lambda|sum_Q [sqrt(K_Q)||Q F_Q P||
                                  +sqrt(K_Q+1)||Q F_Q†P||],
r_S=||Q H_S P||.                                                (21)

Free bath terms commute with P. The displayed square-root oscillator bounds are safe on the declared capped domain; sharper top-capped creation bounds are optional. r_S includes relative-state/spin/tunneling/omitted-photon and nonlinear mode-scattering residuals, rather than dropping them. F_Q and H_S in(21) are the AMBIENT operators on the larger finite basis BEFORE applying the retained P, with the same L carrier. Using only their already-retained matrices would artificially set the missing residual to zero and is forbidden. One may bound it by L times the norm of its full ONE-PARTICLE matrix before restriction, because second quantization is a sum of at most L identical one-body operators. Actual restricted offblock norms can be smaller and must be calculated if used; no unproved square-root improvement is required.

For a real eigenenergy E of H with dist(E,spectrum(QHQ))>=Delta>0, solve the Q equation and eliminate it:

Qpsi=-(QHQ-E)^-1 QHP Ppsi, ||Qpsi||<=v||Ppsi||/Delta,
H_eff(E)=PHP-PHQ(QHQ-E)^-1QHP,
||H_eff(E)-PHP||<=v²/Delta.                                     (22)

These are exact finite-domain resolvent/Schur-complement identities, not a global-in-time dynamical error or a claim every omitted state is gapped. Near a phonon resonance Delta can vanish even when the electronic relative1s gap is large; then use(20) or retain those states, not a false gap denominator. The target Delta,r_S and all omitted matrix norms remain to be measured/constructed. The bound applies to the chosen low-energy projection including the rigid-relative ansatz, provided its actual residual is evaluated there. It does not certify that ansatz from the word1s alone.

There is a second independent INPUT-matrix error: if approximate retained states are isometrically embedded by W and a microscopic one-particle vertex V_Q differs from the adopted one by operator norm epsilon_Q on this domain, then

||W†V_Q W-W†Vtilde_Q W||<=epsilon_Q.                             (23)

If two isometries W,Wtilde satisfy ||W-Wtilde||<=eta and the same bounded vertex V_Q is used, splitting the product gives a difference<=2eta||V_Q||. This explicitly controls envelope/spinor approximations after a consistent embedding; it does not authorize comparing unrelated nonorthogonal modes. Combining such bounds with(21) needs the actual finite energy cutoff and bath tail, not invented material tolerances. These are projection/error statements, not Born/Markov/secular/Floquet or measured PSD uncertainty.

A concrete relative-projection residual can also be calculated, rather than left as a formal v. On the strict2D relative Coulomb model H_rel=-(hbar²/2mu)Delta_r-k/r with k>0, direct differentiation of(6) gives

a=hbar²/(2mu*k), E_rel=-hbar²/(2mu*a²),
<r²>_phi=3a²/2, <r^4>_phi=15a^4/2.                             (24)

The 1/r coefficient cancels because Delta exp(-r/a)=(a^-2-(a*r)^-1)exp(-r/a); the normalized weak eigenfunction is regular enough for the Coulomb quadratic form, and this identifies the declared1s eigenstate. A real finite-width well changes the averaged Coulomb potential, whose actual compressed residual must be added. No physical a or k is invented.

If the z-averaged confinement potentials have global gradient bounds K_e,K_h on the admitted coordinate domain, multiplication by U_e(R+alpha_h*r)-U_e(R)+U_h(R-alpha_e*r)-U_h(R) has norm on a factorized1s input at most sqrt(3/2)*a*(alpha_h*K_e+alpha_e*K_h). Subtracting the COM multiplication part does not alter its omitted-relative component. This bounds Q_rel H P_rel for arbitrary normalized COM input under that explicit bounded-gradient hypothesis. Coordinate-domain boundaries need their own embedding error; finite energy alone is not asserted to make an arbitrary gradient uniformly bounded.

For the harmonic example, use ACTUAL carrier potentials U_e=(m_e*omega_t²/2)|rho_e|² and U_h=(m_h*omega_t²/2)|rho_h|². Equation(1) cancels the cross term exactly, leaving the COM trap in(14) plus delta H_rel=(mu*omega_t²/2)r². The projected relative constant is absorbed in E_ref; the exact residual on the1s manifold is

||Q_rel delta H_rel P_rel||
 =(mu*omega_t²/2)sqrt[<r^4>-<r²>²]=sqrt21*mu*omega_t²*a²/4.       (25)

Indeed (r²-<r²>)phi is the omitted vector and the COM factor is arbitrary normalized. Thus the harmonic COM candidate and its microscopic carrier origin have a calculated finite relative-state error instead of being identified without qualification. Combine this with actual z/Coulomb/spin/tunneling/optical/interaction and phonon offblock norms through(21). On a fixed finite energy/bath carrier(20) gives its genuine finite-time absolute error; if an ACTUAL total omitted spectral gap exists, (22) adds its resolvent bound. No gap, smallness or material validity is inferred merely from this analytic expression.

## 8. What is constructed, physical calibration next, and full unchanged acceptance

This constructs the electron/hole mass coordinates, normalized3D pair/2Drelative/COM spinors, signed finite-well/relative deformation matrix, exact three-well phases/correlations, complete hybrid normalization, dipole selection, solvable localized optical/phonon controls, correlated unsymmetrized spectrum and finite-domain omitted-state/gap bounds. It no longer treats the material vertex as an unexplained g_jQ. The actual target still needs well widths/positions/alloy/interface/spin/mixing and material deformation/elastic/dielectric data, a local disorder-state reconstruction and physical occupation density establishing the boson/projection regime.

The simultaneous response/noise calibration must constrain the FULL matrix, state and rate partition against the already identified target/same-sample response evidence, matching detuning, location, pump shape, optical mode and linewidth conventions. Do not infer a bare gap from a collective pole, all rates from a static energy product, a quantum noise covariance from coherent susceptibility, or independent baths from three wells. No current manuscript defect is inferred merely from the finesse/Q distinction.

Next compute the actual target wavefunctions/optical weights and full G(Q), retain allowed/forbidden channels with their signed interacting gaps, establish the residual/tail budget and bath state, then construct the finite-coupling driven memory/Floquet/locality/nonlinear errors. Propagate ALL diagonal density, conversion/reverse, radiative, pump and cross-noise through the coupled spatial horizon/scattering/optical/polarization/aperture/detector/background response. Derive an identifiable nonempty error-controlled spontaneous/stimulated band under the original E1/D1 charter. Fresh complete nonauthor scientific review must verify every equation, normalization/phase, domain and control, followed by author repair, independent verification and lead intake. Native/runtime/application/integration/canonical closure/main/publication/human review remain separate ROOT-owned gates. No reduced scope, deferral, impossibility, new ledger or new checker is requested.

Complete original independent manual verification: [full review](reviews/E1_LOCALIZED_EXCITON_PHONON_PROJECTION.md). Source selection and process scope: [original source/model contract](source-models/E1_LOCALIZED_EXCITON_PHONON_PROJECTION.md). This records scoped mathematics, not native, physical, main or publication closure.
