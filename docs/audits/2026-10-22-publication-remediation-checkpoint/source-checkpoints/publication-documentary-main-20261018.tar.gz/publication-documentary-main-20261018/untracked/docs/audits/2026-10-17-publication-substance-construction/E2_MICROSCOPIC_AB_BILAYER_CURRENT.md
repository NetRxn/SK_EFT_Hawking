# Reviewed-source delivery: Microscopic AB-bilayer current and optical comparison

This is a documentary transport of the complete original manual construction. Its dated author statements about awaiting review describe the original author snapshot. Subsequent genuinely nonauthor scoped manual mathematical/model acceptance is preserved in the [complete original review](reviews/E2_MICROSCOPIC_AB_BILAYER_CURRENT.md); the [complete original source/model contract](source-models/E2_MICROSCOPIC_AB_BILAYER_CURRENT.md) retains model and chronology qualifications. Lead intake 94f7eb44 accepts that stated manual scope only. No device calibration, implementation, runtime/native, G4/G5/G11, finding closure, integration/main or publication acceptance follows. Full original microscopic/collision/current/contact/scattering/state/noise/independent-route/calibrated nonempty-band BUILD remains owed.

<!-- BEGIN EXACT ORIGINAL CONSTRUCTION -->

# Microscopic AB-bilayer charge current, optical kernel and controlled two-band comparison

Author scientific construction, NOT independently accepted. This builds a microscopic fermionic current/response substrate for E2; all original device/nozzle/calibration obligations remain. SOURCE_MODEL.md fixes the actual model and source-depth/chronology limits. All calculations below are manual; no model/software/test/native execution occurred.

## 1. Finite physical lattice and signs

Let V be a finite AB-stacked honeycomb bilayer, with actual positions r_i, two spin states and orthogonal pi orbitals. Intralayer nearest-neighbor hoppings are -gamma0; the vertical B1-A2 dimer hopping is gamma1>0. Omit skew hoppings/asymmetry/interactions explicitly. Let q=-e, e>0, a_ij=integral_i^j A.dl, a_ji=-a_ij. Choose one orientation of each unordered physical bond, including its boundary path. On the finite fermionic Fock space define

    z_ij = t_ij exp(-i q a_ij/hbar) c_i^dagger c_j,
    H0[a] = sum_bonds,spin (z_ij+z_ij^dagger),
    H[a,phi] = H0[a]+sum_i q phi_i n_i.                         (1)

Complex hoppings may be included with reverse conjugation, but no magnetic/target parameter is assumed by doing so. No valley degeneracy is added to this full lattice: both valleys are already present. The continuum below uses spin2 times valley2, g=4, once. This bounded finite Hamiltonian is self-adjoint and generates a unitary evolution. Fermionic occupation bounds are exact, not a classical or bosonic replacement.

Under A->A+grad chi, phi->phi-chi_dot and one-particle wavefunction psi_i->exp(iq chi_i/hbar)psi_i, the hopping matrix transforms by G h G^dagger; the scalar term supplies i hbar G_dot G^dagger. The action and physical expectations are covariant. A nontrivial torus flux is not a removable single-valued gauge transformation.

## 2. Exact continuity, electric work and contact

For each oriented bond set

    I_ij = -partial H0/partial a_ij
         = i q (z_ij-z_ij^dagger)/hbar,
    q n_i_dot + sum_j I_ij = 0,
    V_ij = phi_i-phi_j-a_ij_dot,
    d <H0>/dt = sum_bonds <I_ij> V_ij.                         (2)

Indeed [n_i,z_ij]=z_ij, hence n_i_dot=(-i/hbar)(z_ij-z_ij^dagger); reversing a bond reverses I. The last identity follows from partial_t H0=-sum I a_dot and the scalar commutator -sum phi_i q n_i_dot. It is the electric-field line integral, not phi alone, that supplies work. Gauge covariance of (1) therefore includes an actual local conserved current. For a terminal cut, sum (2) over one set of vertices; internal bonds cancel and the remaining operator is the cut current, with its own noise normalization.

For a spatially uniform x-directed A on an area A_s,

    I_x = sum_bonds delta_x_ij I_ij = -partial_Ax H0,
    delta_x_ij=partial a_ij/partial A_x,
    T_xx = partial_Ax^2 H0,
    H0[A_x]=H0[0]-A_x I_x+(A_x^2/2) T_xx+O(A_x^3).           (3)

For open physical bonds delta_x_ij=(r_j-r_i)_x; a periodic boundary bond uses its actual lifted path displacement, not wrapped coordinates. I_x has units C m/s, sheet current density is <I_x>/A_s in A/m, and T_xx is the diamagnetic/contact operator of THIS same Hamiltonian. It is not replaced by an arbitrary positive conductivity. The finite lattice supplies both vertex and contact before a continuum cutoff. A sharp projected continuum cutoff is not claimed to inherit its full spatial Ward identity automatically.

## 3. Actual fermionic covariance and retarded response

Let h be the finite one-particle matrix, j=-partial_A h and tau=partial_A^2 h at A=0. For beta>0 and specified chemical potential mu, rho=Z^-1 exp[-beta(dGamma(h)-mu N)] and r=(1+exp[beta(h-mu)])^-1. Write h|a>=E_a|a>, f_a=f(E_a). The finite CAR/Wick identity gives, for the connected covariance,

    C(t) = <delta I_x(t) delta I_x(0)>
         = Tr[ r j(t) (1-r) j ],
    chi(z) = (i/hbar) integral_0^infty exp(izt)<[I_x(t),I_x]>dt
           = sum_ab (f_a-f_b)|j_ab|^2/(E_b-E_a-hbar z),
    sigma_xx(z) = i [<T_xx>-chi(z)]/(A_s z), Im z>0.          (4)

This sign follows from perturbation -I_x A_x and E_x=iz A_x with exp(-i omega t). The full current has delta<I_x>=[chi-<T_xx>]A_x. All interband matrix elements and the actual contact remain in (4). Nonuniform/source-cut responses use their own two vertices; they are not equal to this homogeneous sheet kernel merely by units.

At strictly positive frequency, the dissipative spectral distribution is

    Re sigma_xx(omega)
      = pi/(A_s omega) sum_ab(f_a-f_b)|j_ab|^2
                              delta(E_b-E_a-hbar omega).     (5)

It is nonnegative because the Fermi function decreases. This statement concerns positive-frequency transition weights, not an asserted finite collisionless dc conductivity or a positive contact operator at arbitrary finite flux. Degenerate/zero-frequency and finite-flux stiffness must be treated with their exact discrete covariance/contact and order of limits; they are not inferred from dividing a commutator by omega at zero.

## 4. Ordered noise, KMS, sidedness and physical observable

Define S^>(omega)=A_s^-1 integral dt exp(i omega t) C(t), and S^< by the reverse operator order. The exact finite spectral measures are

    S^>(omega)= (2pi/A_s) sum_ab f_a(1-f_b)|j_ab|^2
                                      delta(omega-(E_b-E_a)/hbar),
    S^<(omega)=exp(-beta hbar omega) S^>(omega),
    S^>-S^< = 2 hbar omega Re sigma_xx(omega),
    S_sym=(S^>+S^<)/2
         = hbar omega coth(beta hbar omega/2) Re sigma_xx(omega)
                                      for omega>0.           (6)

The factor hbar in converting the two delta functions is essential. Each S^> weight is nonnegative, giving positive covariance for every time-smeared Hermitian probe. The zero-frequency diagonal covariance is also positive but not fixed by the nonzero-frequency commutator relation alone. A finite-dimensional Gaussian calculation of the same covariance is not a second independent Landauer/nozzle derivation.

S here is a homogeneous current-noise intensity per area, not a terminal cut-current PSD. It has units A^2 s; identical dimensions do not equate the observables. A specified spatial/circuit probe and contacts are still required. For an actual two-sided PSD with C(t)=integral d omega/(2pi) S(omega) exp(-i omega t), conversion to ordinary Hz is S_f(f)=S(2pi f), with no extra2pi. Folding a symmetric real signal to positive f multiplies by2 once. An absorbing detector measures an ordered rather than automatically symmetrized kernel. None of (6) installs a Hawking occupation or a measured device noise floor.

## 5. Source-selected continuum Hamiltonian and normalized current spinors

Around one valley, reorder the four orbitals as (A1,B2;A2,B1), use physical momentum p and p_+=p_x+i p_y, and select the symmetric nearest-neighbor continuum model

    h4(p) = [ 0    u ; u^dagger  gamma1 sigma_x ],
    u = v [0 p_-; p_+ 0],
    h2(p) = -(1/(2m))[0 p_-^2; p_+^2 0],
    m=gamma1/(2v^2), epsilon=p^2/(2m),
    u_lambda=( -lambda exp(-2i theta), 1 )/sqrt2,
    h2 u_lambda=lambda epsilon u_lambda.                     (7)

Both valleys are unitarily related; the continuum sum has g=4. These are the carrying source Hamiltonians with explicit charge/momentum convention, not a monolayer conformal substitution. The full continuum vertex is v4_x=partial_p_x h4 and the physical electronic current is -e v4_x. In the two-band carrier, v2_x=-(1/m)[0 p_-;p_+ 0], so

    <u_lambda|v2_x|u_lambda> = lambda p_x/m,
    <u_+|v2_x|u_-> = i p_y/m,
    |<u_+|v2_x|u_->|^2=p^2 sin^2(theta)/m^2.                  (8)

Direct multiplication proves these expressions. The off-diagonal term creates/annihilates an electron-hole pair and is absent from a purely convective two-fluid current. Its finite-frequency contribution cannot be dropped using a DC approximation. Subtracting the filled-valence equilibrium reference identifies the convective part as -e(n_e u_e-n_h u_h), consistent with the resolved-momentum carrier. It does not supply an additional intrinsic sigma_Q on top of the already resolved relative-current channel.

## 6. Explicit two-band positive-frequency optical absorption

Take the homogeneous thermodynamic continuum of (7), specified equilibrium f(E), no scattering, q=0 and omega>0. The interband transition energy is2epsilon. In this carrier,

    Re sigma_2,inter(omega)
      = (pi e^2 g/omega) integral d^2p/(2pi hbar)^2
           [f(-epsilon)-f(epsilon)] (p^2 sin^2 theta/m^2)
                                        delta(hbar omega-2epsilon)
      = (g e^2/(8hbar)) F(omega),
    F(omega)=sinh(beta hbar omega/2)/
                  [cosh(beta mu)+cosh(beta hbar omega/2)].    (9)

Angular integration gives pi; p dp=m d epsilon and p^2/m^2=2epsilon/m. The remaining integral is hbar omega/2 before the prefactor g/(4pi hbar^2), giving the displayed coefficient. At T=0, F is the Pauli step at hbar omega=2|mu|, away from its endpoint. At mu=0 and positive T, F=tanh(beta hbar omega/4), so interband absorption tends to zero linearly at low frequency. For g=4 the unblocked coefficient is e^2/(2hbar), not an assumed4e^2/h dc transport value. A finite radial cutoff is harmless to THIS absorptive integral only if its resonance lies strictly inside the retained domain. This is not a proof of a full-cutoff Ward identity or of target cutoff applicability.

## 7. Intraband weight and exact matching to the resolved two-fluid moments

The collisionless intraband Drude weight, meaning sigma_intra=i D2/(omega+i0), is

    D2=e^2 g sum_lambda integral d^2p/(2pi hbar)^2
                         (p_x/m)^2[-f'(lambda epsilon)]
      = e^2(n_e+n_h)/m,
    n_e=D0 integral_0^infty f(epsilon)d epsilon,
    n_h=D0 integral_0^infty [1-f(-epsilon)]d epsilon,
    D0=g m/(2pi hbar^2),
    e^2 n^2/(mN)+4e^2 n_e n_h/(mN)=e^2 N/m,
    n=n_e-n_h, N=n_e+n_h.                                   (10)

The radial integration is an integration by parts of epsilon times the derivative of the electron/hole occupations; finite positive temperature tails vanish. The last identity is n^2+4n_e n_h=N^2. Thus the ideal common/relative current weights sum to the microscopic intraband weight. Relaxation/drag require their own conservative collision derivation; replacing the pole by a fitted constant or adding the same relative conductivity again is not justified. Equation (10) is a continuum integration limit; finite cutoff boundary terms and actual four-band high-energy occupation must be retained when comparing physical models.

## 8. Exact four-band low states and normalized isometry

Write gamma=gamma1, w=vp, S_theta=[0 exp(-i theta);exp(i theta) 0]. Let

    E=(sqrt(gamma^2+4w^2)-gamma)/2,
    w^2=E(E+gamma), r=w/(E+gamma),
    Psi_lambda=(u_lambda, lambda r S_theta u_lambda)/sqrt(1+r^2).
                                                                    (11)

Schur elimination gives h_eff(Ephys)=w^2(Ephys I+gamma S_2theta)/(Ephys^2-gamma^2). Since S_2theta u_lambda=-lambda u_lambda and S_theta u_lambda is a sigma_x eigenvector of eigenvalue -lambda, the displayed Psi_lambda solves h4 Psi_lambda=lambda E Psi_lambda, is normalized, and Psi_+,Psi_- are orthogonal. The p=0 low subspace is defined by its continuous orbital projector; the angular band basis there is not a unique pair of eigenvectors. High energies are +/- (E+gamma). At every fixed p this is a complete orthogonal four-band decomposition.

The energy error against epsilon=w^2/gamma is exactly

    epsilon-E=E^2/gamma <= w^4/gamma^3.                       (12)

Thus the parabolic energy is a controlled approximation on a specified compact vp/gamma domain, not an all-energy identity. Source trigonal-warping/asymmetry/lattice corrections are separate physical terms; their omission is not bounded by (12).

## 9. Physical current vertex after four-band projection

Using v4_x=v[0 sigma_x;sigma_x 0], direct substitution in (11) gives

    <Psi_lambda|v4_x|Psi_lambda>=lambda v_eff cos theta,
    <Psi_+|v4_x|Psi_->=i v_eff sin theta,
    v_eff=2v^2p/(gamma+2E)
         =(p/m)/sqrt(1+4(vp/gamma)^2),
    0<=1-v_eff/(p/m)<=2(vp/gamma)^2.                         (13)

For example sigma_x S_theta+S_theta sigma_x=2cos theta I and the difference has the sine term; normalization supplies r/(1+r^2)=w/(gamma+2E). The current difference in the matched two-dimensional band basis has operator norm e|(p/m)-v_eff|, bounded by 2e(p/m)(vp/gamma)^2. This is a full vertex bound, not just diagonal group velocity.

The projected physical interband vertex is NOT simply partial_p of -E S_2theta: the latter's off-diagonal magnitude is2E|sin theta|/p. Projection has a momentum-dependent isometry; its connection terms must accompany the effective current/contact. Keeping only the effective dispersion can therefore miss a response correction even when its energies are accurate. Equations (11)–(13) construct that correction explicitly for the selected four-band model.

## 10. Four-band absorption below the dimer transition and an explicit response error

For0<hbar omega<gamma, all positive-frequency q=0 transitions involving a high band have threshold at least gamma (or an exactly gamma resonance for same-sign low/high bands). Intraband contributions are at zero frequency. Thus the regular absorptive part of this clean symmetric four-band carrier comes only from -E to+E, at any specified equilibrium T,mu. Performing the same angular integral as (9) and using delta(hbar omega-2E(p)) gives

    Re sigma_4,reg(omega)
       =(g e^2/(16hbar))[(hbar omega+2gamma)/(hbar omega+gamma)]
                                                        F(omega),
    Re sigma_4,reg / Re sigma_2,inter
       =(gamma+hbar omega/2)/(gamma+hbar omega),
    0<=Re sigma_2,inter-Re sigma_4,reg
       <=(g e^2/(8hbar)) F(omega) [hbar omega/(2gamma)].        (14)

The ratio is asserted where F>0; the absolute formula/bound remains valid when F=0. The radial delta integral is p E'(p)/2=E(gamma+E)/(gamma+2E), which proves the coefficient independently. This reproduces the low-transition part of the carrying optical source, with finite-T occupation derived here. It is an actual microscopic finite-frequency comparison for the specified carriers. Equality concerns ONLY the regular Re sigma, not the complete complex kernel: virtual high-band transitions and their contact still contribute to the reactive response below threshold. The complete finite spectral formula(4) retains them. A Lorentzian broadening leaks high-band tails below gamma; it cannot be inserted while keeping the sharp-threshold assertion unchanged.

The same equilibrium temperature/chemical potential is held in this comparison. Matching a specified density instead changes mu between the two dispersions and requires an additional thermodynamic error/calibration, not hidden use of the same number. For the noise(6), multiply the absolute absorptive error by its specified positive thermal prefactor on a compact positive-frequency window. This does not give the noise of an unknown nonequilibrium Hawking state.

## 11. Finite spectral resolution and perturbations on a common physical Hilbert space

There is no assertion that a finite closed graph has a smooth measured spectrum. Its exact answer is the finite positive spectral measure(5)–(6). A frequency test function psi with compact support strictly inside(0,gamma/hbar), finite spatial probe and a retained resonance away from a momentum boundary specifies a continuum absorptive comparison. For C1 integrand B(p) after smearing and smooth compact momentum cutoff, rectangular momentum cells of diameter delta p give

    | sum_cells area(cell) B(p_cell)-integral B(p)d^2p |
       <= delta p sum_cells area(cell) sup_cell |grad B|.     (15)

This follows cell by cell from the mean-value integral, including boundary cells after zero extension of the smooth cutoff. It is an explicit computable finite-volume quadrature bound when those derivative bounds are supplied, not their experimental evaluation. Missing lattice/valley boundary contributions require their own control; a selected smooth patch is not the entire Brillouin zone.

On a fixed finite microscopic Hilbert space compare H0,H1 and I0,I1, with norms of Hamiltonian difference epsilon_H, current difference epsilon_I, max current norm J, contact difference epsilon_T and max contact norm Tstar. Same beta,mu and number operator are assumed. The normalized Gibbs states obey epsilon_rho<=min(2,2beta epsilon_H). Duhamel's derivative of the normalized exponential and trace Holder prove this bound, without commuting the perturbation with H. Unitary Duhamel gives ||I1(t)-I0(t)||<=epsilon_I+2|t|epsilon_H J/hbar. For Im z=eta>0,

    |chi1(z)-chi0(z)|
      <=[2J^2 epsilon_rho+4J epsilon_I]/(hbar eta)
                         +4epsilon_H J^2/(hbar^2 eta^2),
    |sigma1(z)-sigma0(z)|
      <=[epsilon_T+Tstar epsilon_rho+|chi1-chi0|]/(A_s |z|).  (16)

The commutator difference is bounded by4J epsilon_I+4|t|epsilon_H J^2/hbar; the state difference adds2J^2 epsilon_rho. These finite constants state a genuine finite-resolution stability route. One-particle errors lift as ||dGamma(delta h)||<=d||delta h|| for d retained orbitals, and similarly for current/contact. They are not volume-uniform thermodynamic or hydrodynamic bounds, and do not compare different Hilbert spaces until an explicit isometry/complement estimate is supplied. Equations(11)–(14) instead supply the stated low-band comparison with its high-channel restriction explicitly.

For any time filter K with finite zeroth and first absolute moments, centered covariances also satisfy

    | integral K(t)[C1(t)-C0(t)]dt |/A_s
      <=[(3J^2 epsilon_rho+4J epsilon_I)||K||_1
              +(2epsilon_H J^2/hbar)||tK||_1]/A_s.           (17)

Here the raw two-operator term costs J^2epsilon_rho+2Jepsilon_I plus the dynamic term; subtracting the two mean squares costs at most2J(J epsilon_rho+epsilon_I). This treats arbitrary actual correlated current covariance on the common finite system; it does not assume a noise-error bound from a deterministic drift alone.

## 12. Controls, matching and remaining original physical construction

Charge continuity works on each actual bond and on any terminal cut, not only after spatial integration. Static pure gauges leave predictions covariant; nontrivial periodic flux is excluded from that control. Every nonzero-frequency thermal spectral weight is positive and the reverse weight has its actual KMS ratio. Current normalization uses the full microscopic spin/valley count exactly once. The two-band pair current survives despite zero convective charge at neutrality. Its finite-T positive-frequency limit is different from a constant dc conductance. The common/relative ideal weights recover the microscopic intraband sum. Four-band energy, normalization, physical vertex and regular absorptive errors are separately explicit; replacing the vertex by a derivative of an approximate dispersion fails the off-diagonal control. Equilibrium thermal FDT, finite-volume distributions, smoothing and physical terminal measurement remain different statements.

This note does not supply the target's collision integral, electron-electron/phonon/impurity or boundary rates, a finite-frequency conserving interacting vertex, actual gate/circuit/contact response, source-selected material band/asymmetry/temperature/density errors, heated stationary nozzle, coupled horizon/transverse scattering, actual partner/loss/incoming state or receiver covariance. The gauge-covariant lattice formula is an actual microscopic model; its noninteracting nearest-neighbor approximation is not a calibrated target. Four-band-to-two-band errors(12)–(14) do not bound omitted interactions, skew hopping or nozzle hydrodynamics. These remain full BUILD tasks rather than impossibility or approved deferral.

Next substantive chain: supply/derive the actual omitted microscopic terms and physical state/parameter error envelopes; propagate their current/contact/response errors using a controlled common representation and finite-resolution bounds; construct the conserving collision/current/noise and gate/contact/nozzle scattering chain; derive rather than assume the actual mode-to-terminal electrical transfer and covariance; obtain a nonempty identifiable detection band with all physical, statistical and systematic errors. Independent microscopic fermionic Landauer–Büttiker and Keldysh routes and their agreement remain owed. Equation(4)'s Wick evaluation is not renamed that completed two-route programme. General charge-active Onsager completion under NJL's separate author task must be matched without double counting the resolved relative current.

Full independent scientific verification of EVERY group and unnumbered sign/normalization/error step is required before scoped manual acceptance. ROOT actual software/native qualification, source/consumer/figure propagation, canonical closure, integration/main/full publication and genuine human review remain separate. No original objective has been reduced, deferred or declared infeasible here.

<!-- END EXACT ORIGINAL CONSTRUCTION -->

Documentary transport only; all original mathematical and source-domain text above is byte-exact.
