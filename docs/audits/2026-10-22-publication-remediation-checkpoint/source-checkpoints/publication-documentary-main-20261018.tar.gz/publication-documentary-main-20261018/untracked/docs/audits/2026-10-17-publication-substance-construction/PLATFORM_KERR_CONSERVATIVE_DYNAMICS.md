# Conservative full-Fock driven-mode dynamics from the actual cutoff family

Author: publication scientific lead. **SCOPED DECLARED-MODEL MANUAL MATHEMATICAL ACCEPTANCE** of the full-Fock strongly continuous conservative CPTP semigroup, finite-time cutoff error, finite-matrix generator agreement/closability and normal invariant state. See the [complete original independent review](reviews/PLATFORM_KERR_CONSERVATIVE_DYNAMICS.md). Parent remains the D5/E1 physical-platform operator-growth BUILD. This advances the exact declared single-mode driven-loss model beyond the accepted finite-cutoff/weak-stationary limit. The prospective verification language below records the original author sequence; full scoped nonauthor verification is now complete. Core/equality/extension uniqueness, physical polariton modal/port/bath reduction and pump calibration, BEC Hamiltonian growth, global physical F3/MIR, native/integrated evidence and the original scientific programme remain owed. No native/software execution, claim deferral, finding closure or publication acceptance.

## 1. Exact inherited family and new target

Use precisely the carrier, truncated annihilator a_L, number N_L, Hamiltonian K_L=f(N_L)+i(Fa_L†-conj(F)a_L) and loss generator G_L from the full independently accepted PLATFORM_NONLINEAR_PUMP_TAIL note. Here gamma>0, F is constant finite complex, and f is a single fixed real sequence on nonnegative integers, consistently restricted at each cutoff. Kerr f(n)=Delta n+Un(n-1)/2 is the intended example. Rates retain the predecessor's units; no mean photon count becomes a hard support assumption. The finite generators have their ordinary finite-dimensional CPTP semigroups T_L(t). The top CCR defect stays present.

Let H=l²(N0), P_L project through level L, and identify each finite trace-class matrix with its zero extension to H. The goal here is an ACTUAL strongly continuous conservative CPTP semigroup on trace class, obtained by a controlled cutoff limit, with a normal invariant state. We do not assume an infinite formal Lindblad expression already generates one, and do not claim its algebraic matrix core is automatically a generator core.

## 2. Uniform transient exponential moments

For any finite-state solution rho_L(t), s>0 and z=e^s, define M_L(t,s)=Tr[rho_L(t)e^(sN_L)] and D_L(t,s)=Tr[rho_L(t)N_L e^(sN_L)]. The predecessor's exact ladder and weighted Cauchy identities hold for EVERY density matrix, not just stationary ones:

partial_t M_L=(z-1)[-gamma D_L/z+2Re(F X_L)],
|X_L|²≤D_L M_L/z.                                                   (1)

Set y=sqrt(D_L/z). Completing the square gives

-gamma y²+2|F|y sqrt(M_L)≤|F|² M_L/gamma.

Thus, with c_s=(e^s-1)|F|²/gamma,

M_L(t,s)≤M_L(0,s) exp(c_s t),
p_L(t):=Tr[rho_L(t)|L><L|]≤M_L(0,s) exp(c_s t-sL).                  (2)

These bounds are cutoff independent at fixed s and fixed observation time. They are intentionally a finite-time upper bound and do not assert Poisson transient statistics or a uniform-in-time mixing rate. The stationary bound remains the sharper exp[R(e^s-1)], R=4|F|²/gamma². F0 gives c_s0 and the drive boundary term below vanishes exactly.

## 3. Controlled Cauchy property for the actual dynamics

Take a density matrix rho0 supported through a fixed M, and J≥L+1 with L≥M. At any time u, embed rho_L(u)=T_L(u)rho0 into H_J. The exact difference of the two generators on this embedded state is the missing raising Hamiltonian link

B_L=iF sqrt(L+1)|L+1><L|-i conj(F)sqrt(L+1)|L><L+1|,
(G_J-G_L)rho_L=-i[B_L,rho_L].

The diagonal Hamiltonian agrees even for arbitrarily growing fixed real f, and the one-photon-loss term agrees: a_L†a_L=N_L exactly. Positivity rho_L²≤rho_L gives

||(G_J-G_L)rho_L(u)||_1≤2|F|sqrt((L+1)p_L(u)).                      (3)

Duhamel in the larger FINITE matrix space and trace-norm contractivity on Hermitian inputs yield

||T_J(t)rho0-T_L(t)rho0||_1
 ≤2|F|sqrt((L+1)M0(s)) exp(-sL/2) integral_0^t exp(c_s u/2)du
 ≤2|F|t sqrt((L+1)M0(s)) exp((c_s t-sL)/2),                         (4)

where M0(s)=Tr[rho0 e^(sN)]≤e^(sM). This bound is independent of J and tends to0 uniformly for t in every finite[0,T]. It does not require a spectral gap, a stationary approximation or a bound on f beyond its fixed finite entries at every finite level. For J=L the difference is0. No division by c_s is needed, so F0 is a literal0 bound. The cutoff comparison is for the same rho0 and same f,F,gamma.

## 4. Extend the limit to every trace-class input

For each L define the CPTP initial compression/reset channel

Pi_L(X)=P_L X P_L+Tr[(I-P_L)X]|0><0|,
Phi_L(t)X=embed[T_L(t)Pi_L(X)].                                    (5)

The reset channel is used only to define the approximants on the COMMON full trace-class space; it is not a physical extra dissipator. It discards off-block coherences and transfers outside trace into level0. Pi_L is CP and trace preserving, with trace-norm operator norm1. Indeed its adjoint is unital CP; the operator norm bound follows from the CP Schwarz inequality and duality. Pi_L X→X in trace norm for every trace-class X, by finite-rank approximation and ||Tr[(I-P_L)X]||≤||X-P_L X P_L||_1. A density matrix already supported through M is unchanged for L≥M.

Equation(4) first proves uniform-on-compact-time convergence on all finite-support density matrices. Their complex linear span is dense in trace class: diagonalize each finite-block Hermitian part into positive finite-block matrices, then combine real and imaginary parts. All Phi_L(t) are norm1 contractions on trace class, so this convergence extends uniquely and uniformly on each finite time interval to every fixed trace-class X. Denote the limit T(t)X. No uniform operator-norm convergence of Phi_L is asserted.

Linearity, trace preservation and positivity pass to the trace-norm limit. Complete positivity also passes: for each finite ancilla dimension, entrywise convergence of the finitely many block components implies trace-norm convergence of the amplified finite block matrix; the positive cone is closed. Therefore every T(t) is CPTP and conservative, with ||T(t)||_(1→1)=1.

For each finite L, Phi_L(t)Phi_L(u)=Phi_L(t+u), because a reset of the already finite-supported output does nothing. Passing to the limit at fixed X is valid by

||Phi_L(t)Phi_L(u)X-T(t)T(u)X||_1
 ≤||Phi_L(u)X-T(u)X||_1+||(Phi_L(t)-T(t))T(u)X||_1→0.

Consequently T(t+u)=T(t)T(u). Moreover T(0)=I since Pi_L→I strongly. Each finite approximant orbit is continuous and convergence on compact time intervals is uniform for fixed X, hence t↦T(t)X is continuous. This constructs a strongly continuous conservative CPTP semigroup on full trace class. Its adjoint gives a normal unital CP evolution of bounded observables. This is a definite chosen cutoff-limit dynamics, not merely a family of weak stationary identities.

For a normalized full initial state with tail delta_M=Tr[rho0(I-P_M)]<1, let rho_M=P_M rho0 P_M/(1-delta_M). The predecessor's purification argument gives ||rho0-rho_M||_1≤2sqrt(delta_M). Contractivity and(4), followed by J→infinity, imply for L≥M

||Phi_L(t)rho0-T(t)rho0||_1
 ≤4sqrt(delta_M)+2|F|t sqrt((L+1)e^(sM)) exp((c_s t-sL)/2).           (6)

Choose M with small actual tail first, then L. This is not a state-independent cutoff error for arbitrary infinite-energy states; the tail must be known. For finite-supported rho0, the stronger M0(s) in(4) applies directly.

## 5. Identify the actual generator on the finite matrix domain

Let D0 be the algebraic finite-matrix operators, the union of all P_M trace-class blocks, and define G0(X) by the formal full-Fock Schrödinger expression

G0X=-i[f(N)+i(Fa†-conj(F)a),X]
           +gamma(aXa†-(NX+XN)/2).                                (7)

All terms are finite matrices for X∈D0. For L≥M+1 and X supported through M, G_L X=G0X exactly. The finite variation-of-constants identity and strong uniform convergence on compact intervals therefore give

T(t)X-X=integral_0^t T(u)G0X du.                                   (8)

It follows that X lies in the domain of the strongly continuous semigroup generator A and AX=G0X. Thus the actual constructed A extends the specified unbounded formal expression on its full algebraic matrix domain. A is closed; its graph therefore contains the graph closure of G0.

Closability can also be checked without assuming an abstract Lindblad theorem. For any finite-matrix observable O, G0*(O) is a bounded finite matrix supported at most one level higher. If X_j→0 and G0X_j→Y in trace norm, then Tr(OY)=lim Tr[G0*(O)X_j]=0 for all finite-matrix O. Those matrix units separate trace-class operators, so Y0. Hence G0 is closable. We have NOT proved D0 is a core for A, that A equals this closure, uniqueness among all closed extensions, or a full-domain GKSL formula for A. Those extra statements are not necessary to the explicit semigroup construction or the invariant state below.

For Kerr the diagonal Hamiltonian polynomial has a conventional unbounded realization, but this note does not claim a separate self-adjointness/relative-bound theorem for the full driven Hamiltonian or a uniqueness theorem for every possible master-equation realization. The dynamics constructed above and its finite-matrix generator agreement are the exact scope.

## 6. A normal invariant state for this actual semigroup

For each L choose ANY finite invariant density matrix rho_L, whose existence and uniform exponential bound were independently established in the predecessor. The uniform bound makes the embedded family trace-norm relatively compact by finite-block compression and the gentle bound. Select a subsequence L_j→infinity with rho_(L_j)→rho_* in trace norm. Positivity and trace continuity give a normal trace-one rho_*. Monotone compression transfers

Tr[rho_* e^(sN)]≤exp[R(e^s-1)] for every s≥0.                       (9)

The predecessor's finite stationary residual estimate is

||G_J(rho_L)||_1≤eta_L(s)
 :=2|F|sqrt(L+1) exp([R(e^s-1)-sL]/2), J≥L+1.

Its finite CPTP evolution therefore satisfies ||T_J(t)rho_L-rho_L||_1≤t eta_L(s). For each fixed L pass J→infinity through the constructed dynamics to get the SAME bound for T(t)rho_L. Along the chosen subsequence, contractivity gives

||T(t)rho_*-rho_*||_1≤2||rho_*-rho_(L_j)||_1+t eta_(L_j)(s)→0.       (10)

This proves T(t)rho_*=rho_* for every t≥0. There is no need to exchange the infinite-time average with the cutoff limit, assume a uniform mixing gap, or infer strong invariance from just a weak algebraic test identity. It also gives rho_*∈D(A), A rho_*0. In fact rho_L∈D0, G0rho_L tends to0 by the same residual, so rho_* belongs to the graph closure of G0 with value0. None of this proves a unique invariant state or convergence from arbitrary initial data.

## 7. Which operator-growth obligation this does and does not pay

The invariant state's exponential-number moments imply polynomial weighted moments by pointwise n^j≤j!t^(-j)e^(tn). The predecessor's intrinsic Kerr ladder commutators on the finite-particle domain transfer their diagonal positive expectations through monotone compression. Thus its state-weighted factorial bound survives for rho_* with the SAME explicit prefactor C(R,t), rate constant2(|Delta|+|U|)/(nu t) and intrinsic Hamiltonian-only qualification. These quantities are finite under(9). This neither makes the full-Fock ladder bounded nor turns a nonfaithful state seminorm into a global operator norm.

In particular a drive-dependent bound on stationary exponential tails, and even an actual conservative dynamics carrying that state, do not establish pump<threshold→global physical operator growth with epsilon=sqrt(n_max). Full driven commutators include a real drive term; generator powers are different again. The physical input port/mode/reservoir/response and reference rate must be matched, with multimode and spatial reduction errors, before MIR/uniqueness can be tested. The BEC microscopic Hamiltonian/domain/growth branch remains distinct. Those original full-strength tasks are retained BUILD.

Next substantive acceptance is full independent verification of(1)–(10), then native implementation/verification and a source-supported physical reduction/observable-topology bridge through ROOT's ordinary allocation. This note installs no source, assumes no lease, edits no roadmap to complete, and closes no serious finding or bundle. The previous finite/weak milestone remains accurate for its own scope; the new actual semigroup proof, if accepted, is a separately dated scientific increment.
