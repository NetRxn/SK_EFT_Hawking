# A quantum dark-conversion counter, joint dynamics and correlated noise

Author: publication scientific lead. Independently accepted MANUAL mathematical construction within the declared model; native and physical acceptance remain open. Parent: original E1/D1 physical noise/readout and dark-reservoir BUILD. This constructs an explicitly specified mesoscopic conversion/noise model and its quantum state evolution, rather than guessing covariance from a fitted deterministic rate. It does not establish that the Falque material reservoir has this microscopic realization, calibrate its rates, complete an optical/horizon/noise band or close any finding/gate. All original physical objectives remain owed.

## 1. Source target and explicit modeling choice

The existing independently reviewed E1_DYNAMIC_DARK_RESERVOIR note carries the actual Falque AppendixB coherent-field/rate equations and their source/units qualifications. In particular the source reservoir equation is Rdot=gamma_in|psi|²-gamma_R R, with an energy-valued dispersive shift U_R R in the polariton equation. A static blueshift ratio supplies neither stochastic variance nor separate rates. We now supply ONE explicit Markov conversion model with a classical occupation register, and measure the closure needed to reach that deterministic equation. It is not asserted to be an ordinary bosonic dark-mode creation operator: that would produce a stimulation factor absent from the stated rate.

Take H=Fock(a) tensor l²(N0), with basis|n,r>. Let N=a†a, R|n,r>=r|n,r>, and S|r>=|r+1>. S is an isometry with S†S=I; it is NOT b†, and has no sqrt(r+1) factor. Let b|r>=sqrt(r)|r-1>, so b†b=R. The reservoir is a counting register with a specified loss law; its diagonal-state sector will be invariant.

In angular-rate units define

K=Delta N+(U/2)N(N-1)+chi N R+i(Fa†-conj(F)a),
L0=sqrt(gamma0) a,
Li=sqrt(gamma_in) a S,
LR=sqrt(gamma_R) b.                                                  (1)

Tensor identities are implicit. Assume gamma0>0,gamma_R>0,gamma_in≥0, constant finite F, and finite real Delta,U,chi; chi=U_R/hbar in a declared normalized-mode reduction. The physical Hamiltonian is hbar K. The actual density/area projection, U,chi,rates and jump interpretation must be matched to the material sample. Distinct quantum realizations can share a mean reservoir rate, so the source rate alone does not select(1).

## 2. Exact finite carrier, without register overflow fiction

Use the total-excitation cutoff H_L=span{|n,r>:n+r≤L}. Put Q=N+R and compress each operator in(1) to this triangular carrier. Conversion aS changes(n,r) to(n-1,r+1), leaving Q unchanged; it therefore never overflows this carrier. Radiative a and register b lower Q. Their compressed identities are

a_L†a_L=N_L, b_L†b_L=R_L, (aS)_L†(aS)_L=N_L,
[Q_L,(aS)_L]=0, [Q_L,a_L]=-a_L, [Q_L,b_L]=-b_L.                      (2)

The raising drive is genuinely truncated; full canonical aa† is not used at the top. Every finite generator G_L=-i[K_L,.]+sum_j D[Lj,L] is ordinary finite-dimensional GKSL and hence has a CPTP evolution and at least one invariant state. A state initially block diagonal in r stays so: Hamiltonian/drive preserve r and each jump changes that label by a definite amount. Off-diagonal cavity coherences are retained. This invariant sector is a quantum-classical register model, not a claim of a coherent dark condensate.

## 3. Actual infinite conservative evolution and stationary state

Let delta=min(gamma0,gamma_R)>0. For z=e^s,s>0 and V=z^Q, the diagonal Hamiltonian and conversion dissipator commute with V and contribute zero. The exact loss contribution is

-(z-1)(gamma0 N+gamma_R R)V/z.

The drive uses the same exact ladder identities and weighted Cauchy step as the independently accepted full-Fock Kerr construction. If M=Tr(rho V), D_N=Tr(rho N V), D_R=Tr(rho R V), D_Q=D_N+D_R, then

partial_t M≤(z-1)[-delta D_Q/z+2|F|sqrt(D_N M/z)]
           ≤(z-1)[-delta D_Q/z+2|F|sqrt(D_Q M/z)].                  (3)

Completing the square gives M(t,s)≤M(0,s)exp(c_s t), c_s=(z-1)|F|²/delta. Stationarity first yields D_Q≤R_* z M, then integration in s gives

M_stationary(s)≤exp[R_*(e^s-1)], R_*=4|F|²/delta².                  (4)

The number symbol R_* in(4) is a dimensionless bound constant, not the register operator R or a physical reservoir measurement. These estimates are uniform in L and do not depend on Delta,U,chi or gamma_in. Independence of gamma_in here reflects internal conservation of Q by conversion; it is not independence of actual correlations or relaxation.

Only the drive link crosses Q=L. For a state supported in H_L, let B_plus be its raising part, so B_plus†B_plus=|F|²(N+1)P_(Q=L)≤|F|²(L+1)P_(Q=L). Unlike a one-mode top link this has multiple rows. The Schatten Cauchy inequality ||B_plus rho||_1≤||B_plus rho^(1/2)||_2 ||rho^(1/2)||_2 bounds it by |F|sqrt((L+1)p_(Q=L)); the adjoint term gives

||(G_J-G_L)rho_L||_1≤2|F|sqrt((L+1)p_(Q=L)), J≥L+1.                 (5)

All conversion and lowering-loss contributions agree exactly. The diagonal chi N R term also agrees, regardless of its unbounded growth. Thus the finite-time Duhamel/Cauchy proof of the accepted full-Fock construction extends with Q in place of N, finite blocks of dimension(L+1)(L+2)/2, gamma replaced by delta in the moment bound, and reset to|0,0>. Explicitly, for rho0 supported in Q≤M,

||T_J(t)rho0-T_L(t)rho0||_1
 ≤2|F|t sqrt((L+1)Tr[rho0 e^(sQ)])exp((c_s t-sL)/2).                 (6)

Finite total-number blocks exhaust this separable Hilbert space. Dense trace-class extension, CP amplification, composition and compact-time continuity therefore give an actual strongly continuous conservative CPTP semigroup T(t). Its generator agrees with the formal(1) Lindblad expression on all finite matrices. Choose finite invariant states by Cesaro averaging from the joint vacuum, so they retain the invariant register-diagonal sector. A subsequential normal limit of those states has(4); passing the stationary residual in(5) through the actual semigroup proves its STRONG invariance. This reuses an accepted theorem after verifying every carrier/jump/boundary hypothesis, not by assuming an infinite formal GKSL expression is already a generator. Core equality, uniqueness of extensions/invariant states and mixing are not claimed. gamma0=0 is outside this delta-based proof, not declared impossible.

## 4. Exact first moments and the mean-field closure error

Direct commutators and jump adjoints on the finite carrier give

d<N>/dt=-(gamma0+gamma_in)<N>+F<a_L†>+conj(F)<a_L>,
d<R>/dt=gamma_in<N>-gamma_R<R>.                                    (7)

Register conversion removes one cavity quantum while recording one reservoir count. At stationarity every finite model satisfies <R>=gamma_in<N>/gamma_R. Uniform exponential Q moments transfer these identities to the constructed invariant infinite state, since all unbounded terms in(7) are controlled by polynomial Q moments and their tails. This is an exact first-moment equality, not a factorization of joint cavity/register state.

For the infinite ladder the amplitude equation on the same finite-particle matrix domain is

alpha'=-(iDelta+(gamma0+gamma_in)/2)alpha
        -iU<a(N-1)>-i chi<a R>+F, alpha=<a>.                      (8)

Full expectations of this unbounded identity require the appropriate moment/domain passage; exponential Q stationary states supply polynomial weighted integrability. It is not a full-domain identity for arbitrary trace-class states. Finite-cutoff amplitude has its true top drive correction, not an exact untruncated F term.

The Falque-type replacement N→|alpha|² has a definite error

n_inc=<N>-|alpha|²≥0,
<R>'=gamma_in|alpha|²-gamma_R<R>+gamma_in n_inc.                     (9)

The inequality follows from state Cauchy–Schwarz. Nonzero incoherent population is not represented by the source's coherent mean-field density alone. Likewise <a R>=alpha<R>+Cov(a,R), and <a(N-1)>=<a†aa> differs from |alpha|²alpha unless the corresponding higher cumulants are controlled. These are explicit closure obligations. Equal deterministic rate structure is not by itself a microscopic derivation or evidence that those errors are small at the target device.

## 5. Quantum jump noise and the required cross covariance

At finite cutoff the bounded joint GKSL model has a vacuum-input quantum stochastic dilation. Equivalently its Lindblad product/carre-du-champ identity computes the same local noise quadratic variations without asserting a dilation theorem on arbitrary infinite domains. For any two observables A,B,

G*(AB)-G*(A)B-A G*(B)=sum_j [Lj†,A][B,Lj].                          (10)

Hamiltonian contributions cancel by the Leibniz rule. For Hermitian number observables use the symmetrized covariance of these expressions. In conversion, [N,Li]=-Li and[R,Li]=Li, with Li†Li=gamma_in N. Thus the SAME conversion noise decreases N and increases R. The infinitesimal expectation diffusion matrix for(N,R) is

D_NN=(gamma0+gamma_in)<N>,
D_RR=gamma_in<N>+gamma_R<R>,
D_NR=D_RN=-gamma_in<N>.                                            (11)

Radiative and register losses are independent input channels; coherent Hamiltonian drive changes drift, not the Lindblad quadratic variation. The matrix is positive semidefinite: its determinant equals gamma0 gamma_in<N>²+(gamma0+gamma_in)gamma_R<N><R>≥0. This is a quantum noise consistency result, not a license to drop pump/optical/phonon channels that are outside(1).

In a bounded-cutoff jump unraveling the observed channel intensities are gamma_in<N>_conditional, gamma0<N>_conditional and gamma_R<R>_conditional. Individual number-basis matrix elements of those jump operators change(N,R) by(-1,+1),(-1,0) and(0,-1). These channel labels do NOT assert that the conditional expectation<N> itself jumps by exactly minus1: jump conditioning also reweights the state. Equation(11) follows from the operator identity(10), without a hidden classical number trajectory or deterministic substitution in higher correlations. In the infinite stationary state the diagonal moments in(11) are finite, so the finite-matrix expression has an unambiguous integrable limit. This does not prove a general unbounded Hudson–Parthasarathy dilation or white measured output PSD.

At stationarity(7) gives D_RR=2 gamma_in<N> and D_NR=-gamma_in<N>. Choosing independent reservoir and cavity conversion noises would erase a real anticorrelation. Omitting register death noise would lose the factor2. Neither coefficient can be inferred from a static blueshift ratio without selecting and matching a noise model.

## 6. Controlled diagnostic: externally clamped source

As a distinct classical reference, CLAMP the conversion source to an independent Poisson immigration process of constant rate lambda≥0 and retain per-particle register death gamma_R r. This is not the interacting cavity model with its fluctuating N. Its invariant register distribution is Poisson with mean lambda/gamma_R, because detailed balance p_(r+1)gamma_R(r+1)=p_r lambda fixes every probability and the normalized sum. For t≥0 the conditional mean obeys E[R(t)|R(0)]=lambda/gamma_R+(R(0)-lambda/gamma_R)exp(-gamma_R t). Therefore the stationary centered covariance and two-sided angular-frequency PSD are

C_R(t)=(lambda/gamma_R) exp(-gamma_R|t|),
S_R(omega)=integral exp(iomega t)C_R(t)dt
          =2lambda/(gamma_R²+omega²).                             (12)

At lambda0 the invariant state is exactly r0 and both vanish; no0/0 evaluation is used. At omega0, S_R=2lambda/gamma_R² has units count²*time. The symmetrized potential proxy chi² S_R has angular-frequency-noise units only after the stated mode normalization; its energy-valued counterpart is U_R² S_R. The Lorentzian is colored, approaching a white plateau only for |omega|/gamma_R small, with exact relative plateau departure omega²/(gamma_R²+omega²) for lambda>0. For lambda0 there is no nonzero plateau against which to form a relative error. It is not a target-device prediction or total detector PSD. Restoring quantum cavity feedback, incoherent population, cross covariance, reservoir channels and spatial optical filtering changes the spectrum.

## 7. Original scientific acceptance and next construction

This supplies an actual state-preserving mesoscopic conversion model, its infinite conservative dynamics, a stationary first-moment relation, quantum-correlated local noise and an exactly solved clamped diagnostic. It does not show that a real material dark reservoir is a counting register, that its events are Markov or unidirectional, that bosonic stimulation/saturation/backconversion is absent, or that temperature/phonon detailed balance permits those rates. Those are physical matching questions; different microscopic generators can share(7) while differing in noise.

The next substantive physical build is a source-qualified material conversion/decay/backconversion model, supported mode/density/area normalization and bath/rate/state calibration; then derive and bound the closure terms in(9) and compute the actual coupled optical/current covariance and nonempty error-controlled detection band. Keep acoustic/radiative/pump/dark and detector channels distinct and derive their joint transfer. Independent native/implementation/physical review and the existing recorded closure remain required. No new gate or second task queue is created, no quoted false physical claim is restored, and no deferral or reduction of the full E1/D1 objective is requested.

Complete original independent manual review: [scientific verification](reviews/E1_QUANTUM_DARK_CONVERSION_COUNTER.md). The publication scientific lead accepts the original BUILD; this status records scoped mathematical acceptance and does not close the finding or publication.
