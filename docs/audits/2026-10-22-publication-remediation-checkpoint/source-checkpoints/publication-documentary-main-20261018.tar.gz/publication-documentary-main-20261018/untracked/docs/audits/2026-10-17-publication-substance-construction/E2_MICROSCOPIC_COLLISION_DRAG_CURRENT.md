# Reviewed-source delivery: Screened Coulomb collision, drag and physical-current matching

This transports the COMPLETE original construction. Its original dated awaiting-review statements describe its author snapshot. Complete genuinely nonauthor manual review by publication_main55_independent_review and lead intakecf93efe7 accept the declared model scope only. The [full original review](reviews/E2_MICROSCOPIC_COLLISION_DRAG_CURRENT.md) and [full original MODEL](source-models/E2_MICROSCOPIC_COLLISION_DRAG_CURRENT.md) are preserved. No runtime/native, physical-device, full gates, finding closure, integration/main or publication acceptance follows.

Equation22a is restricted to a literal pointwise local $\mu_I=0$ steady first-gradient calculation with momentum solvability. General local-FD perturbations retain
$$(\partial_t+v\partial_x+C)g=\beta jE-(\partial_t+v\partial_x+C)h_{\rm loc},\qquad h_{\rm loc}=\beta[\delta\mu+\lambda\delta\mu_I+(E-\mu)\delta T/T].$$
In particular $C h_{\rm loc}=\beta C\lambda\delta\mu_I$; the reaction term $-\beta C\lambda\delta\mu_I$ and projected/time/streaming sources cannot be dropped. A uniform imbalance without electric field or gradient has $\dot N=-\Lambda\delta\mu_I$, not a closed zero-reaction solution. The full original review below supplies this precision. Physical source-selected rates, actual state/domain/gap, reacting transport, quantum covariance, gate/nozzle/contact/horizon matching and a calibrated identifiable nonempty band remain BUILD.

<!-- BEGIN EXACT ORIGINAL CONSTRUCTION -->

# Microscopic screened Coulomb collision, drag, current and controlled kinetic memory in AB bilayer

NEW manual author construction, awaiting a genuinely nonauthor complete scientific review and lead intake. SOURCE_MODEL.md was genuinely saved before new mathematical scratch. Original E2 physical electrical/noise/readout/calibrated-band BUILD is retained. The results below concern an explicit microscopic projected interaction at a declared Born/on-shell/Markov kinetic approximation and exact consequences of that selected kinetic operator. They are not a rigorous many-body kinetic limit, a measured drag rate, a quantum finite-frequency noise construction or a completed nozzle.

## 1. Carrier, units, spinors and actual density vertex

Use the same source-selected two-band AB carrier as accepted17: physical momentum p, ε_p=p²/(2m), m>0, band λ=±, valley ξ=±, spin s=1,2 and q=−e<0. Write a=(λ,ξ,s,p), dν(p)=d²p/(2πℏ)², and sum flavors explicitly. No extra degeneracy factor multiplies a sum over all four flavors. An equivalent flavor-balanced one-valley calculation has g=4 once. Choose

    u^ξ_λ(p)=(-λ exp(-2iξθ_p),1)/sqrt2,
    F^ξ_{λ'λ}(p',p)=u^ξ_{λ'}(p')†u^ξ_λ(p)
                  =[1+λ'λ exp(2iξ(θ_p'-θ_p))]/2.             (1)

This follows by multiplying the two normalized spinor components, not by selecting a scalar chirality factor afterwards. F(p,p')=F(p',p)* with swapped bands. Its magnitude squared is cos²(θ'−θ) for equal bands and sin²(θ'−θ) for opposite bands; |F|≤1. At equal nonzero momentum the interband density vertex vanishes. The angular frame at p=0 is arbitrary on a measure-zero set; all explicit collision controls below stay away from it.

On a finite area A with periodic one-particle normalization, before a continuum limit,

    ρ_Q = sum_{p,λ'λ,ξs} F^ξ_{λ'λ}(p+Q,p)
                          c†_{λ'ξs,p+Q} c_{λξs,p},
    H_C = (1/(2A)) sum_Q U(Q) :ρ_Q ρ_-Q: .                  (2)

Normal ordering is relative to the filled-valence reference, with a neutralizing uniform background. A finite band/momentum cutoff makes this an actual finite CAR Hamiltonian; the cutoff-to-carrier and many-body-to-kinetic limits are not declared proved. U is real, even and has units J m², so (2) has energy units. Normal ordering produces the fermionic two-body term plus the specified reference/one-body pieces; Hartree shifts and physical self-energy/vertex corrections cannot be silently counted twice or discarded from a device calculation. Long-range small-Q scattering preserves flavor; intervalley transfer and Umklapp are outside this selected kernel, requiring actual material errors.

## 2. Concrete screened Coulomb carrier and a constructive RPA comparison

Let ε_d=ε0 ε_r with ε_r>0. Wave number is k=|Q|/ℏ, not |Q| itself. Our selected static Thomas–Fermi type potential is

    U_TF(Q)=e²/[2 ε_d (k+κ)], κ>0.
    At the ideal μ_I=0 equilibrium, D=g m/(2πℏ²),
    κ_TF=e² D/(2ε_d), U_TF=1/[2ε_d k/e²+D].                (3)

κ may be held as an explicitly supplied positive screening parameter; κ_TF is the value derived from THIS ideal equilibrium compressibility, not a calibrated nozzle input. The full static ideal-band RPA reference is accessible as a definite spinor integral,

    χ(Q)=sum_{λλ',ξs} integral dν(p) |F^ξ_{λ'λ}(p+Q,p)|²
          [f(λ ε_p)-f(λ' ε_{p+Q})]/[λ' ε_{p+Q}-λ ε_p],
    U_RPA(Q)=1/[2ε_d k/e²+χ(Q)],
    χ(0)=D at μ_I=0.                                      (4)

The divided difference is positive and is defined by −f' at coincident energies. Thus χ≥0. At Q=0 only intraband terms survive, and integrating −f' over ε≥0 gives D[f_e(0)+f_h(0)]=D. This is the same thermodynamic n=Dμ derivative, without an additional factor g.

For finite β>0 and bounded μ, χ is finite and continuous on any compact Q domain in this ideal carrier. For large p≥4Q_max, equal-band divided differences decay with the Fermi tails; opposite-band |F|² is O(Q²/p²) while its energy denominator is O(p²/m), making the radial tail O(Q² dp/p³). Near finite momenta the divided difference is bounded by β/4, including band-touching coincidences. These dominate the integral uniformly on compact Q and prove continuity by dominated convergence. A fixed annulus |p| between p0 and2p0 with p0≥4Q_max has equal-band |F|² bounded below and finite-energy Fermi derivative bounded strictly away from zero. Its positive measure gives χ(Q)≥χ_min>0 uniformly there. This lower bound can be very small; it is not a target numerical estimate. Compactness also gives a finite χ_max. Consequently U_RPA is bounded positive on compact transfer domains, rather than inheriting a bare1/Q singularity.

At κ=κ_TF, a supplied or derived ε_χ≥sup|χ(Q)−D| yields

    |U_RPA-U_TF| ≤ ε_χ/(χ_min D) = ε_U.                    (5)

This is an explicit error route from the actual static polarization, not a proof that ε_χ is small at the target frequency/momentum. The source's small-βq²/m approximation is not copied globally. Dynamical screening, finite-coupling/self-energy/local-field errors and measured dielectric/temperature/density domains remain owed. Both potentials define legitimate selected static collision carriers; concrete formulas below use U_TF unless the RPA reference is explicitly substituted with its corresponding bounds.

## 3. Direct/exchange amplitudes with flavor selection

For four distinct one-particle labels satisfying p1+p2=p3+p4, normalized fermionic wedge states give matrix element A_34;12/A, where

    A_34;12 = U(p3-p1) F_31 F_42 δ_{f3f1}δ_{f4f2}
             -U(p4-p1) F_41 F_32 δ_{f4f1}δ_{f3f2}.          (6)

Each F has the valley of the conserved flavor along its own line. The relative minus sign follows by exchanging two outgoing fermion creation operators. The1/2 in (2) is canceled by the two vertex orderings; there is no additional2 in this wedge amplitude. Reversing initial/final pairs conjugates it, and exchanging either ordered pair changes its sign. Hermiticity, reciprocity and indistinguishability are therefore properties of the actual amplitude.

For different incoming flavors and the fixed outgoing assignment f3=f1, f4=f2, exchange is absent; it must not be artificially added as interference between distinguishable outgoing flavors. For the same incoming flavor both terms interfere. Repeated identical incoming or outgoing one-particle labels have zero wedge amplitude. For a constant contact U and collinear same-band spinors the direct and exchange products coincide and cancel for identical flavor; this is a control, not a statement that realistic screened same-flavor scattering vanishes. Equal-band90-degree density transfer has F=0, whereas180-degree transfer need not vanish in this winding-two carrier. At Q=0 a forward unchanged event has zero moment increment, and an equal-momentum band-change density vertex is zero.

Summing explicitly over final/partner flavors and relabeling outgoing particles recovers the source's direct-minus-exchange compact integral. The two modulus-square terms become the same after final-label interchange; their1/2 final-pair factor leaves the integrated g|D|²−Re(DX*) combination. Its unsymmetrized compact integrand need not be pointwise positive or individually real. Our representation retains |A|² before summing/relabeling, which is the actual positivity witness. No second g multiplies it.

## 4. The kinetic approximation and complete gain/loss counting

The finite Hamiltonian amplitudes above are exact for the selected projected interaction. Their use in the following continuum collision law assumes weak-scattering second-order Born/Fermi-golden-rule, diagonal band occupations, quasiparticle on-shell energy conservation, Pauli/molecular-chaos factorization, slow center-coordinate gradients and Markov coarse graining. These are the same kinds of carrying assumptions made explicit in source AppendixC.4; they do not amount to a proved uniform many-body weak-coupling limit or to a finite-frequency coherence theory. A finite-box exact resonance sum is not called an evaluated continuum rate.

Define the nonnegative ordered-label measure

    dΓ = (2π/ℏ) |A_34;12|² (2πℏ)² δ²(p1+p2-p3-p4)
                δ(E1+E2-E3-E4) product_{i=1}^4 dν(pi),
    E_i=λ_i ε_pi,  sum all four band/flavor labels,
    X=f1 f2(1-f3)(1-f4), Y=f3 f4(1-f1)(1-f2).              (7)

The measure has units1/(m² s). Holding label1 fixed gives

    dot f1|coll = (1/2) sum_{234} integral (dΓ/dν1) (Y-X),
    d/dt sum_a integral dν ψ_a f_a
                  = -(1/8) integral dΓ (Δψ)(X-Y),
    Δψ=ψ1+ψ2-ψ3-ψ4.                                      (8)

The1/2 avoids counting the two ordered final fermions twice, including flavor labels. To obtain the weak1/8, first average the tagged expression over1↔2, then average it with the reversed event12↔34. Equivalently an unoriented unordered physical event has eight ordered descriptions:2 initial orders,2 final orders,2 directions. Integrating once per such event uses dΓ/8. This convention is used consistently for entropy, drag and noise below. It is not a finite-grid quadrature rule. Coincident labels/unchanged sets are excluded or give zero increment; their diagonal continuum sets do not generate an extra collision.

All band label channels remain in (7)–(8), including imbalance-changing ones. Symmetric restriction of the event set under these eight operations preserves every invariant of each retained exact event. Arbitrarily rounding energy on a mesh would not do that.

## 5. Detailed balance, entropy and the actual linearized positive operator

For full band-changing collisions use a common β and chemical potentials for the conserved flavor charges only. In the flavor-balanced rest state,

    f_a^0=[1+exp(β(E_a-μ))]^-1, w_a=f_a^0(1-f_a^0)>0,
    X0=Y0=R=f1^0 f2^0(1-f3^0)(1-f4^0),
    f=f0+w h,
    <g,C h>_w=(1/8) integral dΓ R (Δg)* Δh.                (9)

Indeed f/(1-f)=exp[-β(E-μ)] makes X0/Y0=1 on the shell. Linearizing log(X/Y) gives Δh, so X−Y=RΔh to first order and dot h=−C h. The polarized form in (9) follows directly from (8), not from guessing a positive drag matrix. It is Hermitian nonnegative. For nonlinear occupations0<f<1,

    dot S_coll=(k_B/8) integral dΓ (X-Y) log(X/Y) ≥0,
    F2=(1/(2β))||h||_w² per area,
    dot F2=-(1/β)<h,C h>_w ≤0.                            (10)

The entropy sign is the elementary monotonicity of log, with the actual fermionic Pauli factors. For regular finite-domain kernels below the form is bounded and defines a self-adjoint nonnegative C; no domain/gap assumption is hidden in that statement. For a full uncut operator a form domain/closure and convergence must be justified separately. A bounded finite Galerkin compression has an exact positive matrix form but does not prove continuum convergence.

## 6. Exact collision invariants and actual Auger control

Every event conserves total electron number for each flavor, the signed band energy E and physical momentum p. Therefore the functions1_f, E, p_x,p_y have Δ=0 and lie in the collision nullspace. Equation (9) also proves the exact kernel criterion: a function is null iff Δh=0 for dΓR-almost every retained event. We do not assert this list exhausts the nullspace for a restricted network or continuum carrier. In particular the excitation imbalance count is NOT generally an invariant.

Define electron excitations e_f(k)=c_{+,f,k} and hole creation d†_f(k)=c_{-,f,-k}. Then f_h(k)=1-f_-(-k), hole momentum is k and charge+e, and

    n=n_e-n_h, N=n_e+n_h,
    μ_e=μ_I+μ, μ_h=μ_I-μ,
    full collision equilibrium requires μ_I=0.              (11)

The filled sea is subtracted in these finite excitation observables. In original electron variables δN=Σλ∫λ δf_λ, whereas net charge number usesΣλ∫δf_λ. Thus Δλ tests imbalance change.

An explicit allowed Auger event uses a>0 and

    λ1=+, p1=(3a/2,a/2); λ2=-, p2=(-a/2,a/2);
    λ3=+, p3=(a,0);     λ4=+, p4=(0,a).

Momentum is exactly conserved and p1²−p2²=p3²+p4²=2a². Use flavors f1=f3=α, f2=f4=β≠α. Exchange is then absent. The direct factors have |F_31|²=9/10 and |F_42|²=1/2, so |A|²=9 U(p3-p1)²/20>0. The energy-shell derivative in p3 after eliminating p4 is (p3−p4)/m≠0. Hence this is the center of a genuine positive-coarea-measure neighborhood, with strictly positive finite-T Pauli weight, not an isolated zero-measure example. Here Δλ=−2. It proves a nonzero imbalance-changing contribution to the full quadratic form on that test function, not a calibrated chemical relaxation rate, a small-channel theorem or a continuum gap. The inverse reaction is retained by detailed balance.

The source's statement that its numerical Auger contribution was small is not transferred as a rate/error bound. All full-kernel equilibrium and invariant claims above include it. Restricting to e+ h↔e'+h' or same-species elastic channels below is explicitly a useful subkernel, not proof of microscopic imbalance conservation.

## 7. A nonzero continuum electron–hole drag family

For physical electron/hole momenta put P=k+l, r=(k-l)/2. Elastic outgoing momenta

    k'=P/2+R_θ r, l'=P/2-R_θ r                            (12)

conserve both excitation momentum and ε_k+ε_l. At P=0 choose r=a e_x and θ=π/3. The corresponding original-electron event is

    (+,k,α),(-,-l',β) -> (+,k',α),(-,-l,β), α≠β.

It conserves the original signed energy/momentum. The two direct vertices are same-band, each with modulus1/2; |A|²=U(k'-k)²/16>0. The electron x-momentum increment k_x−k'_x=a/2 is nonzero. The Pauli weight in excitation variables is f_e(k)f_h(l)[1-f_e(k')][1-f_h(l')]>0. For the outgoing excitation shell, p-space coarea is

    integral d²k' d²l' δ²(P-k'-l')
                   δ[(k²+l²-k'²-l'²)/(2m)] = (m/2) dθ,    (13)

locally for r≠0, before the displayed (2πℏ) normalizations. It follows by d²r'=r' dr' dθ and δ((r²-r'²)/m). Small open variations of P, r and θ preserve nonzero vertices and nonzero momentum transfer. They give positive phase-space measure. Thus P=0 is a center used to exhibit an open family, not a claim that one exact center alone contributes finite drag.

Opposite flavors give a direct positive control without relying on a favorable exchange sign. The full antisymmetrized sum includes same-flavor and all allowed channels. Chirality zero, forward unchanged transfer, zero interaction and the appropriate empty-species boundaries give their genuine zero controls.

## 8. Finite-domain bounds without invented rates or hidden resonances

Take an admitted compact event domain Ω with all four momenta bounded, away from the displayed angular-frame singularities for derivative controls, invariant under pair permutations/reversal, flavor relabeling and spatial rotations/reflections. Retain exact energy/momentum delta constraints. Choose its control patches away from conditional shell singularities, e.g. with all necessary velocity-difference Jacobians bounded below; the explicit elastic and Auger centers above have regular choices and may be covered by such neighborhoods. The complement, including degenerate/collinear/resonant regions, is not declared absent from the physical kernel.

For κ≥κ_min>0, ε_r≥ε_min>0,

    0<U_min≤U_TF(Q)≤U_max=e²/(2ε0 ε_min κ_min),
    |A|≤2U_max on Ω.                                     (14)

An upper transfer bound and upper ε_r,κ similarly give U_min>0. Finite β/μ ranges make every f_i and1−f_i bounded below on Ω. The coarea mass Λ_Ω, defined as the integral of (2π/ℏ)(2πℏ)²δPδE product dν and finite band/flavor sums without |A|², is finite on a finite regular compact cover. Thus for bounded test h,

    0≤<h,C_Ωh>_w≤8 U_max² Λ_Ω ||h||_∞,Ω².                 (15)

The factor8 is (1/8) times4 from |A|² and16 from |Δh|². This is a dimensional bound with actual phase measure, not a numerical evaluation. With uniform conditional coarea bounds the tagged weighted collision frequency ν_* is finite. From |Δh|²≤4Σ_i|h_i|² and the event symmetries,

    <h,C_Ωh>_w≤2ν_* ||h||_w²,
    ν_* = sup_1 [w1^-1 integral_{234,Ω} (dΓ/dν1) R].        (16)

Hence the positive form defines a bounded self-adjoint C_Ω on the full ideal FD fluctuation Hilbert space. Modes outside the event support may be null; no false global spectral gap is asserted. Compact regularity and a lower shell-Jacobian bound supply ν_* through the same finite cover, rather than assuming a singular endpoint has a finite rate. Other event patches and tails need their own actual estimates and can be added as positive forms when admitted.

If U is changed by at most ε_U on the same domain, |δA|≤2ε_U and, taking U_max as a common amplitude bound, ||A1|²−|A0|²|≤8U_max ε_U. Inserting this bound into the actual polarized integral controls the corresponding collision/drag matrix errors for fixed occupations. Variation of the occupations adds a separately bounded product-weight error. This provides a concrete screening-error transport route from (5); it does not claim the omitted dynamic-screening, singular-domain, UV or physical-material errors have been bounded.

## 9. Susceptibilities and the physical momentum/current moments

At positive T set t=β^-1=k_BT and D=g m/(2πℏ²), from the radial angular integral in dν. For positive excitation energies,

    n_i=D integral_0∞ f_i(ε)dε,
    P_i=D integral_0∞ ε f_i(ε)dε,
    S_i=<χ_i,χ_i>_w=m n_i/β,
    χ_e=1_{λ=+}p_x, χ_h=1_{λ=-}p_x,
    δΠ_i=β S_i u_i=m n_i u_i,
    J_intra=-(e/m)(Π_e-Π_h).                              (17)

Angular p_x² average is mε. Since −f_i'=β f_i(1−f_i), integration by parts gives βD m∫ε f_i(1−f_i)dε=m n_i. The hole signs are not guessed: δf_h(k)=−δf_-(-k), so Π_h=∫k δf_h=∫p δf_-(p); in original variables both χ_i use+p_x. Small species velocities therefore give h=β(p_xu_e on+, p_xu_h on−). The valence current is electronic −eλp_x/m, which transforms to charge+e and velocity k/m for holes.

Energy and number fluxes derived similarly are2P_i u_i and n_i u_i, and entropy flux is s_i u_i, with s_i=(2P_i−μ_i n_i)/T. These recover the exact B/M normalization of the full18 moment construction, not a monolayer enthalpy-mass substitution. The infinite ideal-band integration is a declared carrier identity: a physical sharp cutoff has the nonzero boundary term mD E_Λ f_i(E_Λ) and cannot use m n_cut without it. Four-band/high-energy/interaction corrections to the actual material inertia are not bounded by this identity.

## 10. Collision-derived drag and the conservative force pair

For a flavor-balanced isotropic collision domain write

    a_C=<χ_e,C χ_e>_w,
    <χ_e,Cχ_h>_w=-a_C, <χ_h,Cχ_h>_w=a_C,
    K=β a_C≥0,
    dot Π_e|coll=-K(u_e-u_h),
    dot Π_h|coll=+K(u_e-u_h).                              (18)

These equalities follow because χ_e+χ_h=p_x is an exact invariant of every retained elastic OR Auger event. In particular Δχ_h=−Δχ_e. They are a consequence of the actual event form, not an independently imposed drag ansatz. The positive family (12)–(13) makes a_C>0 whenever that family with positive weight is retained; full-kernel additions cannot remove this lower form bound. At a local displaced FD trial the entropy/availability dissipation is K(u_e−u_h)². The rate convention is

    K=m n_e/τ_eh=m n_h/τ_he,
    n_e/τ_eh=n_h/τ_he.                                    (19)

This follows by summing the actual force densities. The source's printed107 product is inconsistent with this condition and its own108 ansatz. No source numerical0.15,10-percent fit, phonon/disorder/boundary rate or calibrated target time is adopted.

The same full operator gives an actual projected reaction coefficient. Linearizing a local FD state at μ_I=0 gives h=β[δμ+λδμ_I+(E−μ)δT/T]; its number/energy pieces are collision invariants. Hence

    dot N|coll=−Λ δμ_I, Λ=β<λ,Cλ>_w≥0,                   (18a)

and the explicit Auger family proves strict positivity when retained. Its reaction availability loss is Λ(δμ_I)². This matches the reaction-affinity channel in the full18 construction, without asserting that the FD trial manifold is invariant, that Λ is a calibrated physical number, or that an imbalance spectral gap/convergence is proved. Auger may contribute to odd-momentum relaxation as well as even imbalance; its existence does not prove a closed two-velocity dynamics. Equality (18) is a projected trial force, while unresolved-moment feedback is retained below.

## 11. Orthogonal common/relative projection and Drude decomposition

Let N=n_e+n_h>0, n=n_e−n_h, ρ=mN, ρ_r=mn_en_h/N>0. Define

    χ_P=χ_e+χ_h,
    χ_R=(n_h/N)χ_e-(n_e/N)χ_h,
    <χ_P,χ_R>_w=0,
    ||χ_P||_w²=ρ/β, ||χ_R||_w²=ρ_r/β,
    h=β(u χ_P+v χ_R),
    u=(n_eu_e+n_hu_h)/N, v=u_e-u_h.                        (20)

Thus F2=(ρu²+ρ_rv²)/2 and J_intra=−e(nu+b_n v), b_n=2n_en_h/N. Common momentum is an exact collision zero mode. The relative trial decay in the two-moment Galerkin compression is γ_R=K/ρ_r. In the explicitly closed two-moment control with a common-only external damping γ_m≥0,

    σ_mom(z)=e² n²/[ρ(z+γ_m)]
                         +e² b_n²/[ρ_r(z+γ_R)], Re z>0,
    e² n²/ρ+e² b_n²/ρ_r=e²N/m.                            (21)

The last equality is n²+4n_en_h=N², the actual microscopic intraband Drude sum of accepted17. At neutrality the common charge overlap is zero while the relative one is nonzero. At a one-species boundary do the direct one-fluid calculation; inverseρ_r estimates are not uniform. With γ_m=0 and n≠0 there is a common-momentum pole, not a finite collision-limited dc conductivity. Electric forcing gives−enE and−eb_nE in the common/relative equations, with actual power EJ. γ_m is a separate control input, not Coulomb momentum relaxation. Applying a species-independent damping to BOTH velocities also damps the relative mode; it cannot be called common-only.

## 12. Genuine orthogonal residual and the no-doublecount result

In the weighted diagonal occupation Hilbert space take the orthogonal projector P onto the actual thermodynamic moments n,N,energy (equivalently entropy at this equilibrium), all retained collision invariants and resolved species momenta (using their nonsingular Gram matrix on the chosen symmetry sector); Q=1−P. The exact intraband charge vertex is

    j_a=−e λ p_x/m=−(e/m)(χ_e−χ_h), Qj=0.                 (22)

Therefore a residual formula using the same space cannot produce an additional charge-current Gram or σ_Q from higher diagonal moments once both momenta are retained. Heat/stress residuals need not vanish. Qj=0 does NOT mean Q dynamics may be dropped: collision and streaming coupling to Q can change the effective friction of the resolved current through a Schur complement. A measured total conductivity cannot be added again on top of (21).

The optical interband vertex of accepted17 is an off-diagonal band bilinear, not a function h_λ(p). It lies outside this occupation Hilbert space. Its low-band energy separation2ε_p has no uniform positive gap at band touching; a finite Q collision gap below is not a proof about that coherence sector. Nonparabolic/interacting current and microscopic gauge/contact terms may also create genuinely additional sectors. The general charge-active PSD L_d in the full18 extension remains allowed and owed at physical matching strength, rather than being deleted to force (22) or falsely derived twice from the resolved relative channel.

The thermodynamic-gradient matching can also be made explicit. At μ_I=0 put v_a=λp_x/m and

    a_n=v, a_N=λv, a_s=(E−μ)v/T,
    F=(∂xδμ+eE_x, ∂xδμ_I, ∂xδT),
    [v∂x f0+qE_x∂p_x f0]/w = β sum_i a_i F_i,
    C h = −β sum_i a_i F_i                                (22a)

for the steady first-gradient transport equation about local FD, with h the non-equilibrium correction and the local thermodynamic gradients counted only in the displayed source. Time-dependent local-FD variables also have a time-derivative source in their thermodynamic P space;22a does NOT drop that term from an initial-value equation. For complete dynamics use the total fluctuation and all resolved streaming/source equations13. Differentiating f0(E−μ−λμ_I,T) gives these three vertices and the negative electronic force sign directly. Testing δf=w h gives the conjugate fluxes j_n,j_N,j_s as <a_i,h>_w, and J=−e j_n. These are precisely the thermodynamic flux/affinity units of full18, not a copied scalar conductivity.

With resolved corrections held at h_P=0 and only the genuine Q residual eliminated at zero frequency, Q gives C_QQ h_Q=−βΣ_i Qa_i F_i and

    L_d,ij=β<Qa_i,C_QQ^-1 Qa_j>_w.                        (22b)

This requires a proved invertible positive Q block; otherwise its actual memory/null sector must be retained. It is a reciprocal PSD Gram with the displayed β fixed by the actual FD linearization. In the strictly parabolic diagonal carrier, a_n=−j/e and a_N=(χ_e+χ_h)/m both lie in P, so its residual number/charge AND imbalance flux rows vanish. Heat/entropy need not vanish: a_s contains p_xp²/(2m²T), which is not a linear species momentum. In the concrete e_Q control24 its coefficient is d_s=||χ_Q||_w/(2m²T)>0, giving the genuine held-moment residual L_ss=β d_s²/c. Full source/current response still includes the P–Q cross feedback23; held-moment elimination is not a second added total thermoelectric response. The general charge/thermal cross entries allowed by full18 need an actual extended nonparabolic/coherent/interacting carrier and remain BUILD; their absence in this restricted diagonal parabolic residual is a derived domain statement, not deletion of the original physical obligation.

## 13. Finite Galerkin equations, streaming, sources and exact memory

Choose a finite subspace with the actual conserved functions retained and compress C_Ω by its form, not by changing individual event conservation. In orthonormal weighted coordinates its matrix C_G is symmetric PSD. Project multiplication by v_x=λp_x/m to a real symmetric matrix V_G; for Fourier wave number k_x the generator is A(k)=C_G+i k_x V_G. At k=0 the uniform electric source is βj E, exactly from qE∂_p f0=−β w j E. Thermodynamic-gradient sources use their actual conjugate streaming/flux vertices. Charge continuity follows by testing the kinetic equation against the conserved number function; no bare CCP truncation that omits its density partner is used for inhomogeneous continuity. An odd longitudinal homogeneous control below is a separately invariant k=0 sector.

Split the finite variables x=P_Gh, y=Q_Gh. With Laplace z, Re z>0,

    [z+A_PP-A_PQ(z+A_QQ)^-1 A_QP] x
      =f_P+x0-A_PQ(z+A_QQ)^-1(f_Q+y0).                     (23)

Every term follows by solving the Q equation; the initial-slip and Q source are not discarded. In time, the P equation contains +∫_0^t A_PQ exp[−A_QQ(t-s)]A_QP x(s)ds and −A_PQ exp(−A_QQ t)y0, plus the corresponding negative convolution of f_Q. At k=0 A=C and the effective friction is C_PP−C_PQ(z+C_QQ)^−1C_QP. This is generally frequency-dependent even though the selected microscopic kinetic collision law is Markov.

For real z>0 its matrices are real symmetric; for complex z the reciprocal matrix is complex symmetric at k=0, so the charge/heat flux response with properly paired forces is Onsager reciprocal at zero magnetic field. More generally, if ε is the time-reversal parity matrix, C commutes with ε and V anticommutes; εA(k)ε=A(−k). This supplies the corresponding parity/spatial reciprocity, rather than confusing transpose with complex conjugate frequency. A finite projection must retain those symmetries to claim it.

For y=−(z+A_QQ)^−1A_QP x, the quadratic form of the full Schur bracket is (x,y)†(z+A)(x,y). Its real part is Re z (||x||²+||y||²)+(x,y)†C_G(x,y)≥0. Thus the exact projected response is passive/causal. Collision null modes must remain explicitly in P or in a handled null block. No inverse C_QQ at zero is licensed merely by saying 'unresolved'. A finite PSD matrix alone does not prove a continuum collision gap or Galerkin convergence.

## 14. Actual finite positive-gap/current control from physical scattering weights

A concrete three-dimensional homogeneous odd-longitudinal Galerkin space can be built without a fictitious energy grid. Use χ_P,χ_R and

    χ_Q=1_{λ=+}p_x(p²−α),
    α=<χ_e p²,χ_e>_w/||χ_e||_w²=4mP_e/n_e,
    e_P=sqrt(β/ρ)χ_P, e_R=sqrt(β/ρ_r)χ_R,
    e_Q=χ_Q/||χ_Q||_w.                                   (24)

Integration by parts gives the stated α. Finite T gives ||χ_Q||>0 because p² is not constant on the positive FD radial weight. χ_Q is orthogonal to both species momenta; its odd parity makes it orthogonal to flavor number/energy invariants and to p_y. Work in the flavor-balanced longitudinal sector at k=0; no other physical conservation law has been projected into an untracked inverse.

Take two compact regular elastic event families around (12), with radii0<a1<a2, both a_i²<α/2, chosen small enough for a prescribed positive parabolic momentum window. At their centers,

    Δχ_R=Δχ_e=a_i/2,
    Δχ_Q=(a_i²−α) Δχ_e.

The two vectors (Δχ_R,Δχ_Q) are linearly independent since their determinant is (a1 a2/4)(a2²−a1²)≠0. On sufficiently small nonzero neighborhoods both amplitudes/Pauli weights remain bounded below and the shell remains regular. Symmetrize the neighborhoods under all event operations and spatial rotations/reflections; this preserves positivity and exact invariants. These are integrals of the actual screened |A|² and exact physical shells, not quadrature nodes assigned fake energy conservation.

For any nonzero linear combination b_Rχ_R+b_Qχ_Q, its increment cannot vanish on both center families, and by continuity has strictly positive squared integral on at least one neighborhood. Therefore the actual two-by-two collision Gram on (e_R,e_Q) is SPD,

    C_G=0 on e_P,  C_G|_{R,Q}=[[a,b],[b,c]],
    a>0, c>0, ac−b²>0,
    λ_min ≥(ac−b²)/(a+c)>0,
    γ_Q=c>0.                                             (25)

The λ_min inequality is det/λ_max≥det/tr. Its constants are definite positive physical collision integrals for THIS finite control, not numerically evaluated target rates. At each center the rotational average of Δχ_RΔχ_Q is (a_i²−α)|k−k'|²/2<0. That continuous averaged scalar stays strictly negative on sufficiently small neighborhoods, so the rotationally symmetrized integral has b<0 and is nonzero in this control. A fixed x-component product need not retain its pointwise sign near rotations where Δp_x=0; the averaged argument, not such a false pointwise assertion, proves this claim. One may restrict to exactly these neighborhoods to avoid an unproved cancellation from other channels. Full-kernel additions preserve positivity of this subspace's form when admitted, although they change its entries and may change b. The actual pair-current and missing domain/physical errors remain outside the control.

Here the current has the attained nonzero e_R coefficient j_R=−(2e/m)sqrt(ρ_r/β). Since Qj=0, its exact three-mode response is

    σ_G(z)=β j_P²/z+β j_R²/[z+a-b²/(z+c)],
    β j_P²=e²n²/ρ,
    a_eff(0)=a-b²/c>0.                                   (26)

This gives a real nontrivial feedback example and finite regular relative dc response, with common momentum still present. It is the explicit finite control requested, not a proof that every continuum Q sector is gapped or that this small Galerkin model converges to the measured device. The physical interaction kernel, not an arbitrary abstract PSD matrix, supplies a,b,c and their positivity witnesses.

## 15. Controlled local/memory approximations with their actual domains

On a finite Q block whose coercivity has actually been established, C_QQ≥γI>0, write B=||C_PQ||. For real ω,

    ||C_eff(-iω)-C_eff(0)||≤|ω| B²/γ²,
    ||M(t)||≤B² exp(−γt), M(t)=C_PQ exp(−C_QQ t)C_QP,
    ||initial slip||≤B exp(−γt)||y0||.                      (27)

Resolvent identity and ||(C_QQ−iω)^−1||≤1/γ prove the first bound; no commutation beyond self-adjointness is needed. For differentiable x(t), replacing the memory integral by C_PQ C_QQ^-1 C_QP x(t) has error at most

    (B²/γ²) sup_{0≤s≤t}||dot x(s)||
                  +(B²/γ) exp(−γt)||x(t)||.               (28)

The first term integrates s exp(−γs); the second is the missing tail t→∞. Initial slip from (27) is an additional term. In the actual control (25), γ=c and B=|b|, so the hypotheses are proved for that finite Q block rather than assumed as a continuum property.

At a fixed k with C_QQ≥γ, A_QQ=C_QQ+ikV_QQ is accretive and its resolvent has norm≤1/γ on Re z≥0. Thus the fixed-k frequency error is bounded by |z| ||A_PQ(k)|| ||A_QP(k)||/γ². For comparison to local k=0 feedback, the triangle/resolvent identities give

    ||F(k)-F(0)|| ≤ |k|[||V_PQ||||C_QP||+||C_PQ||||V_QP||]/γ
       +k²||V_PQ||||V_QP||/γ
       +|k| ||C_PQ||||C_QP||||V_QQ||/γ²,                   (29)

where F(k)=A_PQ(k)A_QQ(k)^−1A_QP(k). The explicit streaming term ikV_PP must also be kept; these bounds do not eliminate continuity. Uniform continuum/high-k/long-time/nonlinear or actual device error claims require further evidence, and null/near-null Q modes must be moved into the resolved list or handled as memory, not assigned a manufactured γ.

## 16. Actual event-count noise at the declared kinetic scope

For each unoriented unordered collision event use independent coarse-grained forward and reverse counts with conditional rates r X and r Y, where r carries the same golden-rule measure as dΓ/8. Their occupation increment is ν_event=(−1,−1,+1,+1) with the labels/phase measure specified above. This is the Boltzmann–Langevin/molecular-chaos kinetic construction, not an exact stochastic representation of the closed interacting quantum state. At equilibrium forward and reverse weights both equal R, so the count-difference covariance is2rR dt and every invariant annihilates its increment.

For any two moment test functions g,h, at uniform area A,

    Cov(dM_g,dM_h)/dt=(2/A)<g,C h>_w.                      (30)

The same8-fold convention as (8)–(9) is essential. The Dirichlet increment square is the actual noise Gram, so positivity and conservation follow event by event, including Auger if retained. For equilibrium independent quasiparticle occupations the FD fluctuation variance is w. For orthonormal weighted finite modes set x_i=sqrt(A)<e_i,h>_w; their equilibrium covariance is I and free availability is |x|²/(2β). The linearized kinetic stochastic system is

    dot x=−C_G x+sqrt(A)β j E+ξ,
    <ξ(t)ξ(t')^T>=2 C_G δ(t-t'),
    J_sheet=j^T x/sqrt(A).                                (31)

Indeed the covariance Lyapunov equation −C I−I C+2C=0 reproduces the actual FD variance. A general initial correlated state need not have it. This is a derived semiclassical equilibrium noise normalization, not a quantum Markov bath assignment from deterministic dissipation alone.

For positive/nonzero-frequency regular parts,

    σ(z)=β j^T(C_G+z)^−1j,
    A S_J^(two-sided)(ω)=2β^-1 Re σ(−iω+0),
    S_Ix/A=A S_J, I_x=A J_sheet.                           (32)

The two-sided transform is integral dt exp(iωt)Cov; inverse measure dω/(2π). Formula (32) follows by multiplying the resolvents around2C, or from equilibrium x covariance exp(−C|t|). It has exactly the classical2k_BT factor and units A²s for the noise intensity. For ordinary Hz substituteω=2πf, with no additional2π; folding a real symmetric signal to one side multiplies by2, giving4k_BT Reσ for the corresponding area-normalized intensity. A terminal-current probe, contact geometry and detector ordering remain separate observables, not supplied by the area normalization.

## 17. Zero modes, quantum distinction and full physical continuation

A conserved common mode has no collision white-noise forcing in (31). If its equilibrium initial amplitude is not conditioned to zero, it is a stationary random constant, giving2π j_P² δ(ω) in the intensity. Its response is βj_P²/z, with real Drude measureπβj_P²δ(ω); (32) then agrees as a distribution. One cannot take C^-1 on that mode or call its dc response finite. A fixed-momentum conditional ensemble removes its covariance only with the corresponding constrained observable/source sector; it cannot be combined with an unconstrained accelerating-field response to manufacture a false FDT. Real boundary, disorder, phonon and circuit relaxation need their own conserving/thermal accounting.

Boltzmann–Langevin counts are classical at the selected quasiparticle kinetic scope. Their white equilibrium factor2k_BT does NOT prove S^</S^>=exp(−βℏω), quantum coth or the microscopic interband spectral formula. At low |βℏω| the exact equilibrium quantum factorℏω coth(βℏω/2) approaches2k_BT, but that limit does not validate the kinetic Markov approximation, projected current or physical state. The full17 microscopic operator/contact/Kubo result remains a separate quantum reference; a conserving collision/self-energy/vertex/noise bridge and its domain/error are still owed. Interaction energy/current, projected density/contact and full lattice Ward contributions must be carried in that bridge; total kinetic collision invariants alone do not compute them. A Hawking state, partner/loss covariance or measured background is not created by detailed balance.

This note supplies actual complex spinor interaction vertices, antisymmetrized flavor events and symmetry factors, full allowed Auger/elastic invariants, entropy/FD linearization, nonzero drag and moment/current normalization, an actual physical-weight finite Galerkin gap/control and exact memory/slip/closure bounds, plus selected semiclassical event noise. It leaves the original scientific objective at full strength: actual interacting/asymmetric/skew/four-band current/EOS/stress/energy and finite-frequency coherence/collision/noise; dynamical screening and finite-coupling/Markov/model/truncation/convergence errors; physical thermal/imbalance/drag/viscous rates and uncertainties; dynamic gate/circuit/contacts and reservoir heat/noise; heated stationary nozzle and normalized transverse/horizon/partner/loss scattering; actual incoming/outgoing/receiver state and ordering; sourced calibrated transfer/background with all errors and a nonempty identifiable usable detection band. Independent microscopic fermionic Landauer–Büttiker and Keldysh routes and their agreement remain owed. This construction is not renamed those two completed routes.

Next substantive action is full genuinely nonauthor scientific review of EVERY group, domain and normalization above, then lead intake and repairs of any mandatory finding. Subsequent construction should evaluate/control the actual admissible collision/coherence/screening/contact reduction and physical parameter/error envelope before a target rate or band can be accepted. No source application, project/model/mathsoftware/test evaluation, native result, G4/G5/G11 or canonical closure, main merge, bundle green, infeasibility, operator deferral or reduced scope is asserted. ROOT owns actual runtime/native/gates/integration/main, and genuine final human publication review remains separate.

<!-- END EXACT ORIGINAL CONSTRUCTION -->

Documentary transport only; all original mathematical/source-domain content above is byte-exact.
