# Independent complete KV2008 varying-G scientific review

**SCOPED MANUAL MATHEMATICAL ACCEPTANCE.** I find no mandatory mathematical repair in the complete construction e75de997098e32a05567f39aaf920704fa3d9c1cadbfb721e7287fa72a0f6b41. I independently re-derived equations(1)–(15), checked their domains, and personally read the carrying official primary equations. This is acceptance of the source-corresponding homogeneous background, its constrained local stability, specified observer map and proposed finite-window error route. No numerical solver, physical viability, fit, perturbation theory, native proof, gate, finding or bundle is accepted as complete.

## Independence and actual evidence

I did not author this new lead construction. My earlier full review concerned the separate conditional constant-G H5-bath construction; it is not imported as proof of this varying-G model. Earlier KV documentary authorship is disclosed as historical context only. This is a fresh whole-model review, not an inverse-only or predecessor acceptance.

The original official continuity check was the FIRST action from the assigned N checkout and returned0/freshtrue/changed[]. Its exact argv/cwd, observed output and native receipt f2bbae are preserved. That first native exec exposed elapsed0.074453958seconds and combined output, but not absolute UTC or separately captured stdout/stderr. Those missing fields are null, not inferred or retroactively filled. No repeat or packet refresh occurred. Later capture timestamps do not pretend to be the first-check time. This is an administrative evidence limitation, not a native Lean or model run.

I read the entire CONSTRUCTION and AUTHOR record, complete current r60 notebook (recovering the truncated middle separately), current owning Phase5x status/Wave3 goals and AGENTS. Prior governing documents are reused at exact pinned hashes. The original packet, all referenced inputs,64dirty N sources and explicit raw index/admin files have an initial byte/fullstat snapshot. This read-only check grants no execution authority.

I personally opened official arXiv0806.2805v7 and read its carrying action, Maxwell/Einstein equations, dimensionless ansatz, FRW dynamics, oscillation/asymptotic context and footnote4. The model correspondence is supported by Eqs2.1,2.6–2.8,4.1–4.15 and5.1–5.7; the later extrapolation and footnote distinguish conservation from a possible changed-mu scenario. [Official2008 paper](https://arxiv.org/pdf/0806.2805v7).

I also read the relevant official1102.3152v4 §5–7 and AppendixA passages: its plateau discussion is a distinct scenario, not an instruction to identify it with this model or an exact calibrated transition solution. No whole-paper/pixel/figure inspection is claimed for either source. Web locators/read extent are retained in process.json; no full text was downloaded or admitted to holdings. [Official2011 paper](https://arxiv.org/pdf/1102.3152v4).

## Action, dimensions and source correspondence

With [F]=mass² and [chi]=mass^-4, t_*=sqrt(chi*F0) has units of time; h,tau,f,u=chi*F0*mu and sigma=3s/(8pi) are dimensionless. V=chi*(epsilon-mu*F)=-f²/2+f⁴/6-u*f, V_f=-f+2f³/3-u and V_ff=-1+2f². At u0=-1/3 it factors f*(f+2)*(f-1)^2/6 and is nonnegative on f>0. This is not the off-equilibrium derivative of epsilon-F*epsilonPrime. Excluding f0 is appropriate because G^-1=sF0*f vanishes there.

The source's curvature convention gives Maxwell(3s/8pi)*(Hdot+2H²)=epsilon_F-mu. Multiplication by chi*F0 and the stated scales gives sigma*(h'+2h²)=V_f. Its00 equation becomes sigma*(h*p+f*h²)=V+m+r. Its spatial equation, with vacuum pressure minus vacuum density and radiation pressure r/3, becomes f*(2h'+3h²)=3V/sigma-r/sigma-2h*p-p'. Two separately conserved dust/radiation fluids are an explicitly stated extension of the source perfect matter sector, with no exchange. No H5 decay law is appended to this source-selected model.

## Full constrained evolution and turning points

Solving the spatial equation with the00 constraint gives p'=h*p-2f*A-(3m+4r)/sigma, A=V_f/sigma-2h². Together with f'=p,h'=A,m'=-3h*m,r'=-4h*r,x'=h, this is the stated polynomial time vector field. It is locally Lipschitz at every finite state for fixed finite u and sigma>0. The mathematical vector field remains regular at h0; physical f>0 and the separate expanding-redshift h>0 chart still matter.

Direct differentiation of C=sigma*(h*p+f*h²)-V-m-r produces sigma*(A*p+h*p'+p*h²+2f*h*A)-V_f*p+3h*m+4h*r. Substituting p' cancels the matter and f*h*A terms; what remains is[sigma*(A+2h²)-V_f]*p=0. Thus C is exactly constant along the polynomial equations, including at h0, and an exact C0 initialization stays on the source constraint.

Conversely Maxwell, the spatial equation, conservation and C0 imply the displayed p' equation without division by h. Substitution into the spatial right side gives2f*A+3(V+m+r)/sigma-3h*p, which equals f*(2A+3h²) by C0. This proves the homogeneous constrained equivalence; it is not a proof that arbitrary inhomogeneous PDE solutions are represented by the FRW ansatz. At h0 one must impose V+m+r=0; at nonzero h the stated formula for p0 follows algebraically. Arbitrary five-parameter data need not be admissible. Exact preservation of a wrong nonzero C would not make those data physical.

The matter solutions m=m0*exp(-3(x-x0)) and r=r0*exp(-4(x-x0)) keep nonnegative matter nonnegative in either time direction on the existence interval. The vacuum pressure ratio remains-1 although V'=V_f*p need not vanish: the varying-G sector is essential, so no constant-G separately conserved DE equation is inferred.

## Exact de Sitter branch and complete constrained stability

At p=m=r0 and constant positive f,h, Maxwell and C give V_f=2sigma*h² and V=sigma*f*h². Hence f*V_f-2V=f*(f³/3+u). On f>0 the stationary solution has f_*=(-3u)^(1/3), h_*²=f_*(f_*²-1)/(2sigma). It is expanding real de Sitter exactly for u<-1/3; equality gives Minkowski, -1/3<u<0 gives negative h², and u>=0 has no positive f candidate. This is a result for the declared ansatz, not all q-theory.

At expanding de Sitter, the derivative of C with respect to p is sigma*h_*!=0, so the constraint is a smooth local manifold and p can be eliminated. In vacuum its first variation is delta p=h_*delta f-2f_*delta h. The reduced two-variable matrix therefore is[[h_*,-2f_*],[V_ff/sigma,-4h_*]]. Its trace is-3h_* and its determinant is-4h_*²+2f_*V_ff/sigma=2f_*³/sigma>0. The discriminant9h_*²-8f_*³/sigma=-f_*(7f_*²+9)/(2sigma)<0 gives real parts-3h_*/2.

Dust and radiation supply lower diagonal modes-3h_*,-4h_*; their perturbations force the upper block through delta p but have no first-order feedback from f/h at the zero-density background. The full reduced matrix is block triangular. All four eigenvalues have negative real part, so the smooth finite-dimensional linearization theorem yields local asymptotic stability on C0. A small f>0,h>0 neighborhood and the invariant nonnegative fluid subspace supply the stated admissible local basin. This establishes neither a global attractor, viability, calibrated initial state nor observable perturbation stability.

At fixed u0 near f1,h0 in vacuum, linearization gives delta h'=delta f/sigma and delta f''=-2delta f/sigma. Restoring t_* gives frequency squared2/(sigma*chi*F0), not a bare-potential curvature mass. The Minkowski constraint has no first-order vacuum restriction and its higher-order constraint is not thereby discarded: these linear equations do not authorize arbitrary finite-amplitude linear initial data, a global stability claim or a free relativistic propagator. The note makes none of those extensions.

## Units, observer subtraction and fixed-redshift derivatives

M0²=sF0*f0/(8pi) and H0=h0/t_* imply3M0²H0²=sigma*f0*h0²/chi. Since physical dust/radiation densities are m0/chi,r0/chi, Eq(7)'s Omegas follow exactly. The hp term prevents silently replacing the source00 equation with a standard fixed-G sum rule. This declared cosmological reference G is not automatically the local measured Newton constant; that calibration remains explicit additional work.

On a connected h>0 interval, d/dx=(1/h)d/dtau and E=h/h0. Thus(E²)_x=2A/h0² and(E²)_xx=2B/(h*h0²), with B=V_ff*p/sigma-4h*A. Differentiating the declared constant-G reference subtraction gives D_x and D_xx in(10), including the positive3/4 coefficients in D_x and negative9/16 in D_xx. A fixed-redshift derivative is not an unconverted time derivative.

For D>0, w_app=-1-D_x/(3D). At a1, d/da=d/dx and wa=-w_x, giving(9) with its denominator derivative and signs. The exact matter-free stationary control, with zero reference densities, has E=D1,A=B0,w0=-1,wa0. No generic pair follows away from that state. The diagnostic requires h0>0,h>0,D>0 and becomes ill-conditioned as D approaches zero. The prose's compressed 'near D0' is read in that zero-denominator sense; it is not a claim of ill-conditioning at every arbitrary positive present D0. Expanding the phrase to 'as D approaches zero' would be a useful nonblocking wording clarification.

The flat Jordan-frame distances in(11) use the declared minimally coupled light/c1 convention. They are background relations, not calibrated sound horizon, luminosity evolution, growth or detector calculations. The warning that average(1/H),1/average(H) and1/sqrt(average(H²)) differ is essential; no uncontrolled oscillation averaging is accepted.

## Every finite-window error constant and its scope

For the convex box, |V_f|<=(F+2F³/3+|u|), so |A|<=Amax. The h' row has row sum at most(1+2F²)/sigma+4H. For p', the derivatives are-2A-2f*V_ff/sigma,h,p+8f*h,-3/sigma,-4/sigma in the corresponding f,p,h,m,r order. Their absolute sum is bounded by the exact third row in(12). The other row sums are1,3M+3H,4R+4H. Thus L is a valid infinity-norm Lipschitz bound; Bmax correctly bounds the vector-field magnitude componentwise.

For g(z)=Ftime(z)/h, Dg=DFtime/h-Ftime*(derivative of h)/h², so row sums are bounded by L/h_min+Bmax/h_min² on the convex box intersected with h>=h_min>0. This proves(13). It is a SAME-redshift evolution bound, not a time-trajectory error misapplied to matching z values. Fixing identical exact u,sigma and h0 is a necessary stated condition.

With bounded continuous residual eta and initial infinity error e0 in that common domain, integration of the usual differential norm inequality gives(14) in either x direction: e0*exp(Lx*|x|)+eta*(exp(Lx*|x|)-1)/Lx. At Lx0 the continuous limit is eta*|x|. A certified tube staying inside physical f>0 and h>=h_min with bounded state supplies existence coverage by continuation; the claimed box, residual and margins must themselves be established. Small constraint drift is an additional check, not a replacement for trajectory error or valid initial C0.

At the same redshift and normalization, |E-E_tilde|<=e_h/h0. Positive proven E,E_tilde>=E_min gives reciprocal error<=e_h/(h0*E_min²), and integration supplies(15)'s1/(H0*h0*E_min²) factor. Hubble/angular/luminosity distance errors inherit their displayed geometric factors. Parameter, calibration, quadrature, rounding and modeling errors are excluded explicitly and must be added; D,D_x,D_xx error bounds and a positive D margin are separately needed for CPL errors. No ordinary floating solver output, derivative estimate or confidence interval is certified here.

## Preservation, process and scientific continuation

The retained initial pins cover the original packet/references,64current dirty-source files and raw index/HEAD/admin inputs. Hash/size/mode/ns-mtime comparisons and the original once-only final check are recorded below. No source or other author's output was edited. Official web reads are read-only and their tool IDs/URLs/line windows are recorded; no screenshot, download, holdings or primary-admission step is inferred. The author recorded two prior screenshot failures; they remain failures, not a fresh reviewer pixel result.

One large notebook display was truncated and its missing middle was recovered separately. A broad memory registry search also truncated; no historical fact from that search is substituted for the fresh authority or primary evidence. Raw first-check UTC/pipe capture limits remain openly retained. No mathematical software, production import, model/solver/helper/test, Lean/native/controller/build/render/export/compiler/dependency operation, Git mutation, sourceholding/registry/notebook/ledger/closure write or subagent was used. Manual derivations above, stdlib byte/stat/JSON reads and official continuity metadata checks are the evidence boundary.

The next substantive numerical task remains a validated evaluator of(1)–(2), valid initialization, positivity/constraint/events, fixed-redshift tubes and error/refinement controls at explicitly calibrated source parameters, including stationary and perturbed-mu controls. Physical regime selection, ultrafast averaging/response, perturbations, actual measurement calibration, same-data likelihood and the distinct2011transition scenario remain BUILD. Acceptance here neither reduces that original scope nor grants main/publication readiness or scientific deferral.

Terminal original FINAL official continuity check: 2026-10-18T06:02:21.177487+00:00 to 2026-10-18T06:02:21.488688+00:00, rc1, actual changed=['owned-files']; separately captured stderr=''. All88 initial input byte/hash/size/mode/ns-mtime pins, including the raw index5202b904a2441c427d706d50bac053e269e49a26184d681571ce6d6e203fc49a, remain exact before/after (mismatches0/0). Packet SHA remains58ff212f4bcbd58da7ebc390f3c9ad2f2903dcc80b0d5f3638424cdaf157b0bb. Only the five allocated ignored reviewer outputs drift. No original packet refresh or source/authority mutation. Scoped manual acceptance is frozen; no runtime/native/physical/closure acceptance follows.

## CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

No substantive contradiction was found in the source correspondence or mathematical equations under their stated assumptions. The actual2008 matter sector is conserved; importing the earlier H5 exchange would change it, and the new note does not do so. Source-selected phenomenological functions and a stable background are not a late-time empirical fit or proof of family-wide viability/impossibility. The original raw-index exception remains unwaived; current raw-byte preservation is not an explanation of that historical event.
