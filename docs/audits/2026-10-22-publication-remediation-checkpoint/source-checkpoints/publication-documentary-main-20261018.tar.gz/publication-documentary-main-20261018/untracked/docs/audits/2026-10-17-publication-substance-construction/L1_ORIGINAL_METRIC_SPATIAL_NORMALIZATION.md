# Original L1 finite spatial normalization — construction

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** Full original signed action/Haar/Berezin two-site control, D=3366=2922+0+444, coupled nonzero-separation insertion, source-dependent Z and explicit domains/errors, arbitrary coupling cancellations. All coefficients retained exactly.

**Original physical obligations.** No physical zero-source/vacuum susceptibility, full tensor/multiplicity/source/volume/operator/coupling matching or derived [0.1,10] window. Full arbitrary-volume original family remains the target; modes/matter and physical transport are distinct.

The construction author is publication_main55_independent_review; the complete independent scientific review is by publication_njl_target_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION](L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md), [fixed source model](source-models/L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md), [full independent review](reviews/L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION-CONSTRUCTION -->
# Original L1 coupled spatial metric construction — author result, independent review required

This is new manual mathematics AFTER the genuine MODEL save 2026-10-18T14:55:19.725781+00:00 (SHA829c0c498d6030c6b5f0678b950a30550b55d50044c14185f1adbe3050c42949), and after full personal reading of all five carrying constructions and all five nonauthor reviews. The first persisted scratch record is 15:03:16.270267 UTC; that records an actual persistence event, not an invented earlier scratch timestamp. No mathematical, numerical, symbolic or coefficient engine was run. All coefficients and inequalities below were derived manually. SOURCE_MODEL remains unchanged. These are author results requiring fresh whole independent SCIENCE review.

## 1. Entire fixed family, finite control, and observable

SOURCE_MODEL fixes the original finite periodic four-torus family, arbitrary finite complex g1,g2, the independent normalized Spin(4)=SU(2)L×SU(2)R Haar links, eight Grassmann generators per site, gamma matrices, all four T blocks and printed left-to-right plaquette. This construction uses the prospectively fixed control Λ*=2×1×1×1, not a subsequently selected geometry. Both sites and all eight links, both interactions and their arbitrary couplings remain in the integral. Physical real-coupling interpretations require additional conditions, not automatic positivity of this signed algebra.

Write the sites 0,1=e1, A=Ω0,1 and B=Ω1,1, and C=A†−B. Exact addition of the original four blocks gives

T0,1,a=(bar0 γa C ψ1−bar1 C† γa ψ0)/4,
T1,1,a=(bar0 C γa ψ1−bar1 γa C† ψ0)/4.                 (1)

For j=2,3,4, forward/backward neighbors coincide but the two sites' links remain independent. At each site x,

Tx,j,a=barx {γa, Ωx,j†−Ωx,j} ψx/4.                    (2)

No block has been overwritten when its endpoints coincide. In particular (2) is odd under inversion of that one transverse link Ωx,j→Ωx,j†, with normalized Haar unchanged.

Keep the actual ten once-counted metric sources at each site. Restrict their values, not the model, to H=H0,11 and K=H1,11 with the other sources zero and J=0. Define U=G0,11=Σa T0,1,a² and V=G1,11=Σa T1,1,a². Then

Z(H,K)=I exp(g1 S4+g2 S2+HU+KV),                     (3)

where I is the entire Haar/Berezin integral with the fixed orientation; S4 and S2 are the full sums over both sites. Original insertions at sites 0 and1 have separation a e1. This is a coupled spatial observable, not two independent one-site integrals. It does not approximate an infinite-volume separation or continuum momentum kernel.

## 2. Grassmann saturation, site counts and exact interaction cancellations

There are sixteen Grassmann generators, or eight bar/ψ pairs. S4 has four pairs; S2 and either metric insertion have two pairs. A monomial S4^q S2^p times total metric-source degree l can contribute only if

2q+p+l=4.                                            (4)

Every longitudinal T in (1) supplies one generator at each site. Hence l metric insertions supply (2l,2l) generators at sites (0,1). A local S4 at x supplies (7,1) generators, or (1,7) at the other site: there is precisely one longitudinal T and three transverse T factors. Split S2=A0+A1+B0+B1, where Ax contains its two T directions both transverse and Bx contains one longitudinal T and one transverse T. Their site generator counts are

A0:(4,0), A1:(0,4), B0:(3,1), B1:(1,3).             (5)

Ax's complementary plaquette directions are (1,j); its link dependence reaches the other site only through the single transverse link in direction j. Its own T directions are the two different transverse directions other than j. Bx's complementary plaquette is entirely transverse and depends only on transverse links at x; its sole transverse T uses the missing third transverse direction. These facts hold for each ordered ε term, including both orientations of each plaquette.

The following cancellations are exact, before any numerical approximation:

* q=2,p=l=0: same-site S4² oversaturates that site's eight generators. S4,0 S4,1 has an odd single transverse T for each independent transverse link at either site. Inverting one such otherwise unused link proves its Haar integral zero.
* q=1,p=1,l=1 or q=1,p=0,l=2: the S4 site already receives 7+2l>8 generators. These terms vanish algebraically.
* q=1,p=2,l=0: site counts force S4,x Ay By with y the other site. Ay can contain only one of x's transverse links; By contains no transverse link at x. At least two of the three transverse T factors in S4,x therefore remain odd in an otherwise unused independent link. Their Haar integrals vanish. Thus the last possible g1 term also vanishes.
* q=0,p=1,l=3: (6,6) from the metric insertions would require a (2,2) S2 term. No term in (5) has that count.
* q=0,p=2,l=2: only A0 A1 and B0 B1 survive site counting. In A0 A1, A0's two transverse T directions can be paired by at most one opposite-site link in A1's plaquette. At least one transverse T remains odd in a link appearing nowhere else. In B0 B1, each site's transverse T direction is absent from its own transverse plaquette and from the opposite site's links. Again the corresponding independent Haar integral is zero. The metric insertions use only longitudinal links and do not spoil either cancellation.
* q=0,p=3,l=1: site counts force A0 B1² or A1 B0². The two transverse T factors in the A term are unpaired at its site; the B terms at the other site do not contain those links. Their Haar integrals vanish.

Consequently the ENTIRE restricted-source partition function, for arbitrary g1,g2 retained in (3), has the exact form

Z(H,K)=D g2^4+Q4(H,K).                               (6)

D is one scalar, initially unassumed; the manual completion in section2b evaluates it as3366. The cancellation of g1 here is a proved property of this geometry and source slice. It is not a deletion of g1 from the original model, nor evidence that g1 cancels for other observables or larger tori. In particular all terms needed to test the cancellation remain in (3).

At zero source, the only potentially contributing g2^4 site patterns give the concrete remaining contraction

D=I[ A0² A1²/4 + A0 A1 B0 B1 + B0² B1²/4 ].         (7)

The factors 1/4,1,1/4 follow from the multinomial expansion divided by4!, not a choice of measure. The further MANUAL attempt below evaluates the A part and kills the mixed part, then completes the signed B remainder by exact determinants in section2b. This DOES establish the finite source-free normalization Z(0,0)=3366g2^4 for g2≠0, while it does NOT normalize a thermodynamic physical vacuum. The earlier absolute-bound source domain remains valid without assuming a sign for D, and the completed exact value now gives the additional source-free domain. No one-site value such as96g2² is substituted for (7).

### 2a. Additional manual evaluation of the three contractions

For this geometry, the reverse plaquette equals the dagger of the forward plaquette: this is immediate for transverse commutators, and Pj1=X A Y† A†=(A Y A† X†)† for a longitudinal/transverse pair. First antisymmetrize the two T factors to remove the symmetric gamma trace; then combine both ordered plaquette orientations. The original1/4 cancels exactly, as in the original one-site derivation. If Lκλ denotes the antisymmetric part of Tr(Pκλ γCγDγ5), write contractions Lκλ Tμ Tν with both internal C,D summed. Then

Ax=L14 T2 T3−L13 T2 T4+L12 T3 T4,
Bx=L34 T1 T2−L24 T1 T3+L23 T1 T4.                   (7a)

Let Ax,j be the term whose complementary plaquette is(1,j), and Bx,j the term whose transverse T direction is j. Each Ax,j is odd in ALL three transverse link centers at x, and in the single center in direction j at the other site. Each Bx,j is odd only in center j at x. These are center flips Ω→−Ω, distinct from the inversion control earlier. Flipping all three transverse centers at0 therefore changes the sign of A0 A1 B0 B1: its first three factors each change sign and B1 does not. Hence its Haar integral is EXACTLY ZERO.

The same parity kills cross terms Ax,j Ax,k with j≠k in A0² A1²: the opposite site's squared A term is even in its own three centers, leaving the two distinct opposite-site centers from Ax,j Ax,k odd. Thus only nine terms A0,j² A1,k² remain. For B0² B1², the independent center at a site's transverse T direction kills different j,k within that site's B². Only nine B0,j² B1,k² remain.

For P=diag(c0+i c·σ,d0+i d·σ), the retained antisymmetric trace obeys

L_j4=2(c_j+d_j), L_jm=−2 ε_jma(c_a−d_a),
||L||F²=16(|c|²+|d|²).                              (7b)

The old exact two-row transverse T fourth-moment tensor, with b=13/32,c=1/16, is 4b δCEδDF+2c(δCDδEF+δCFδED). Its contraction against antisymmetric L_CD L_EF is (4b−2c)||L||F²=(3/2)||L||F². This is actual old Haar/Berezin data, not a Gaussian substitution.

If j=k, the two sites' transverse T pairs use links independent of both curvatures. Write their missing transverse links as X,Y, their independent longitudinal links as A,B. In one chiral sector the plaquettes are P0=A Y A† X† and P1=B X B† Y†. Their marginal distributions are Haar. Let r0,r1 be their imaginary quaternion vector squares. Conditional on X,Y, the two longitudinal conjugations are independent. If x0,y0 are scalar quaternion components and

f=x0² y0²+(1−x0²)(1−y0²)/3,

then E(r0 r1)=E(1−f)². Normalized Haar gives E x0²=1/4,E x0⁴=1/8, so E f=1/4, E f²=5/72 and E(r0 r1)=41/72. Also E r0=E r1=3/4. Left and right sectors are independent. Consequently

I(A0,j² A1,j²)=(9/4)·256[2·41/72+2·9/16]=1304.     (7c)

If j≠k, the curvature in A0,j contains its own missing transverse link Ω0,j, which appears in no T or other curvature in that term. Haar integration of that link makes P0 a Haar matrix independent of all remaining variables. The analogous missing Ω1,k makes P1 independently Haar. Their L second moment is 2(δCEδDF−δCFδDE), their expected squared norm is24, and each site's saturated T contraction is(3/2)·24=36. Thus

I(A0,j² A1,k²)=36²=1296, j≠k,
(1/4)I A0² A1²=(3·1304+6·1296)/4=2922.              (7d)

For the B part, the complementary transverse commutator is independent of its transverse T link and of all longitudinal links. Its exact imaginary-vector second moment is2/9 per coordinate in each chiral sector. Hence

E L_CD L_EF=(16/9)(δCEδDF−δCFδDE).                   (7e)

Define the local four-generator tensor, after integrating that one transverse T link,

Kx,DF=Elink Tx,j,D Tx,j,F
 =−(1/16) Σ_(s=L,R),i=1..3
   [barx {γD,Ps σi} ψx][barx {γF,Ps σi} ψx],          (7f)

where Ps σi is the Pauli matrix embedded in the indicated chiral block. The factor−1/16 is (−i/2)² times E u_i u_j=δij/4 from Ω†−Ω=−2i u·σ. It is not a positive tensor covariance of commuting random numbers. This expression is independent of the transverse direction j. Put

Rx=Gx,11 TrKx−ΣCE Tx,1,C Tx,1,E Kx,CE.

All nine B0,j² B1,k² terms are identical after independent relabeling of transverse Haar links at the two sites. Their curvature integrations are independent. The remaining constant therefore has the explicit reduced form

D=2922+DB,
DB=(64/9) I_(only A,B Haar; full Berezin) R0 R1.       (7g)

Here(9/4)·(16/9)²=64/9, including the1/4 from(7). R0 R1 contains four longitudinal T factors and degree-four local Grassmann tensors K0,K1. It has only degree FOUR in C=A†−B, not the unreduced degree24 link polynomial. All transverse Haar integrations of this B contribution have actually been performed. The first saved manual attempt stopped at this reduced signed contraction and honestly left its value unknown. The subsequent manual completion below evaluates it; the initial unevaluated stage is preserved in timed evidence rather than backdated as complete.

A further concrete reduction of this last task follows from endpoint Spin(4) invariance of the integrated tensors R: change variables to CL=r I,CR=s I. The required Berezin top coefficient F(r,s)=IBerezin R0 R1 is homogeneous degree4, even in r and s by the independent chiral endpoint centers, and symmetric under exchanging chirality (gamma4 similarity and Haar L/R interchange). Thus F=u(r⁴+s⁴)+v r²s², with u=F(1,0), v=F(1,1)−2F(1,0). The remaining Haar average is10u+4v, using E r⁴=E s⁴=5 and E r²s²=4. Evaluating polynomial coefficient probes at(1,0),(1,1) is an algebraic reconstruction of(7g), not selecting a replacement physical link ensemble or couplings. The first attempt left these two top coefficients unevaluated. They are completed manually next. Every factor/invariance in(7a)–(7g) and the new completion require independent review together with the earlier derivation.

### 2b. Manual completion of the remaining B contraction

Define the local Grassmann-even axial vector wD=i barψ γ5γD ψ. Direct expansion of(7f) gives

KDF=(wD wF−δDF w²)/8,
Rx=−[2wx² Tx,1²+(wx·Tx,1)²]/8.                     (7h)

One explicit check of this tensor identity uses ψ=(l,r),barψ=(η,ξ), A=ξl−ηr, Bj=ησj r+ξσj l. Then w=(B1,B2,B3,−iA); the independent imaginary quaternion coordinates have covarianceδij/4. Equation(7f) gives Kjk=[δjk(A²−B²)+BjBk]/8, Kj4=−iABj/8, K44=−B²/8, proving(7h), including the signs. All quantities here are even Grassmann polynomials, so their products commute. They are not ordinary commuting random spinor values.

Let a,b be temporary linear sources for w0,w1, and J,L for T0,1,T1,1. These auxiliary source letters in this derivation do not change the fixed physical MODEL or source normalization. The determinant generates all insertions; its overall Berezin sign is positive as in(8). For C=I, T0,1=T1,1=T, so one source J suffices. The diagonal bilinear blocks are Pa=iγ5γa,Pb=iγ5γb, and the off-diagonal blocks are±γJ/4. Since Pa²=a²I and

(γJ/4)Pa(γJ/4)=iγ5[J²γa−2(a·J)γJ]/16,

the Schur determinant, continued polynomially through a²=0, is

detM=[a²b²+(J² a·b−2(a·J)(b·J))/8+J^4/256]².       (7i)

Only the a²b²J^4 homogeneous part contributes to F(1,1):

P11=(a²b² J^4)/128+((a·b)²J^4)/64
    −J²(a·b)(a·J)(b·J)/16+(a·J)²(b·J)²/16.

Write DaJ=Σi ∂ai∂Ji, and similarly DbJ. From(7h),

F(1,1)=(1/64)[4 ΔaΔb ΔJ²+2 ΔaΔJ DbJ²
                         +2 ΔbΔJ DaJ²+DaJ² DbJ²] P11|0.

For audit, the FOUR displayed operator values on P11 are respectively144,36,36,144. The first follows from ΔaΔb P11=(3/4)J^4 and ΔJ²J^4=192. For the second, ΔaP11=(3/32)b²J^4, DbJ²(b²J^4)=48J², and ΔJJ²=8. For the fourth, DaJ²P11=−(3/8)b²J²+(15/4)(b·J)²; DbJ² acts on the two terms by16 and40. Thus

F(1,1)=[4·144+2·36+2·36+144]/64=27/2.              (7j)

For C=diag(I,0), keep separate J,L. Reorder the eight-by-eight matrix into its two chiral blocks. With qX=X4 I−i Xjσj, its upper chiral block is

X=[[i qa,qL/4],[−qJ/4,i qb]].

The lower block is diag(I,−I) X† diag(I,−I) for real sources, so detM=(detX)², with polynomial continuation for complex sources. The quaternion Schur determinant is

detX=a²b²−h/8+J²L²/256,
h=(1/2)Tr(qb† qJ qa† qL).

The trace identity gives h=(a·J)(b·L)+(a·L)(b·J)−(a·b)(J·L) plus an oriented ε(a,b,J,L) term. Its sign is immaterial for the contractions below; its magnitude and self-dual tensor contribution are retained, not discarded. The relevant homogeneous part of detM is

P10=a²b²J²L²/128+h²/64.

Consequently

F(1,0)=(1/64)[4 ΔaΔbΔJΔL+2 ΔaΔJ DbL²
                         +2 ΔbΔL DaJ²+DaJ² DbL²] P10|0.

The FOUR operator values here are48,12,12,30. For the first two, the quaternion product norm gives Δa h²=2b²J²L², so ΔaP10=(3/32)b²J²L². For the last operator, write h=aᵀ M J, M=mI+N, m=b·L, with N the self-dual or anti-self-dual combination of L∧b and its Hodge dual. Then TrM=4m, TrN²=−4(b²L²−m²), and

DaJ²h²=2[(TrM)²+TrM²]=48(b·L)²−8b²L².

DbL² on these two terms gives48·40−8·16=1792. The a²b²J²L² term contributes256/128=2 and the h² term1792/64=28, totaling30. Therefore

F(1,0)=[4·48+2·12+2·12+30]/64=135/32,
u=135/32, v=F(1,1)−2u=81/16,
Ilong F=10u+4v=999/16,
DB=(64/9)(999/16)=444,
D=2922+444=3366.                                     (7k)

An additional scalar-source sign check is available in both determinants: set all source vectors parallel to e4. Equation(7i) becomes (ab−J²/16)^4, while the chiral case becomes (ab−JL/16)^4. Each has the required coefficient3/128 for the corresponding a²b² quartic-source monomial. This checks the Schur signs and factors independently of the subsequent tensor differential contraction.

These are exact MANUAL coefficient contractions, not output from symbolic/numeric/coefficient software. Both determinant identities and all differential operator counts are exposed for independent verification. In particular the epsilon contribution in h is essential to the self-dual N norm; dropping it changes the1792/30 audit. Combining all attempted reductions, the entire restricted-source partition function is now EVALUATED:

Z(H,K)=3366 g2^4+Q4(H,K), arbitrary g1,g2.             (7l)

The original action is not replaced by a scalar model; this is its exact finite-geometry restricted observable. At zero source it is nonzero exactly for g2≠0, over the complex algebraic family. This establishes a finite source-free normalization on that domain. It does NOT establish a thermodynamic physical vacuum, a positive underlying measure or the required physical matching/window.

## 3. Direct evaluation of the saturated spatial source polynomial

Introduce linear sources J·T0,1+L·T1,1 temporarily to compute the source-only degree-eight term. For real J,L put γJ=ΣJaγa and

BJL=γJ C+CγL.

The eight-by-eight fermion bilinear matrix in site order is

M=(1/4) [[0,BJL], [−BJL†,0]].                         (8)

The stipulated Berezin orientation gives det M, with positive sign for eight pairs. Therefore its saturated source coefficient is |det BJL|²/4^8. This determinant is ONLY the saturated source term of the full integral. Saturation, rather than a free-model approximation, removes interaction factors from this one coefficient.

The source-only Haar/Berezin measure admits independent endpoint Spin(4) rotations. Under their change of variables C→V0 C V1†, the two source vectors rotate independently; the Berezin Jacobians are1. This uses the kinematic link Haar measure and the bilinear source expression, NOT an assumption about gauge invariance of the full printed action. The averaged polynomial depends only on R=J·J and S=L·L. Align J=j e4,L=k e4 for the real calculation and extend the resulting invariant polynomial algebraically to complex sources.

Write CL=rL UL, CR=rR UR, where conditional orientations UL,UR are independent normalized SU(2), and rL,rR≥0. Each C sector is a difference of two independent Haar unit quaternions. Their radial and orientation distributions separate by bi-invariance. Let a=rL²,b=rR² and τ be the Euclidean inner product of the two unit quaternion orientations. The elementary normalized S³ moments give

E a=2, E a²=5, E a³=14, E a⁴=42,
E τ²=1/4, E τ⁴=1/8, E τ^(odd)=0,                  (9)

with a,b independent and identically distributed and independent of τ. For example a=2(1−u·v), E(u·v)²=1/4, E(u·v)⁴=1/8; this yields all four radial moments in (9). No fitted covariance or Gaussian quaternion law is used.

In the aligned frame, BJL has off-diagonal blocks j CR+k CL and j CL+k CR. Set v=j²,w=k²,c=√(ab)τ. Its determinant is

P=[vb+wa+2jk c][va+wb+2jk c]
 =ab(v²+w²)+vw(a²+b²+4c²)+2jk c(a+b)(v+w).          (10)

The conditional even-τ expansion of P² has coefficients

[v⁴]E P²=[w⁴]E P²=E a²b²=25,
[v³w]E P²=[vw³]E P²=E[3ab(a²+b²)+4a²b²]=268,
[v²w²]E P²=E[a⁴+b⁴+10a²b²+4ab(a²+b²)]=558.        (11)

For the middle expressions E(ab(a²+b²))=56 and E(a²b²)=25. All moments and numerical factors are displayed so independent review can reconstruct the normalization from the original Haar law and gamma basis. Thus the exact degree-eight linear-source term is

F8(J,L)=[25(R⁴+S⁴)+268(R³S+RS³)+558R²S²]/65536.     (12)

Metric insertions are Laplacians, not auxiliary-field squares. In four vector dimensions,

ΔJ^m (J·J)^m|J=0=4^m m! (m+1)!.

Dividing the resulting insertion by m!n! from exp(HU+KV), with m+n=4, gives

Q4(H,K)=a4(H⁴+K⁴)+b4(H³K+HK³)+c4 H²K²,
a4=375/32, b4=201/4, c4=2511/32.                    (13)

In particular the unnormalized, genuinely nonzero-separation mixed insertion is

I(U³ V)=3!·1!·b4=603/2,
I(U² V²)=2!·2!·c4=2511/8,
I(U⁴)=4!·a4=1125/4.                                 (14)

These are full-action insertions, independent of both couplings by saturation. The H³K term could not be obtained by multiplying two independent one-site metric partition polynomials (each of degree≤2). Thus the result actually probes the coupled two-site algebra. It is not a one-site response relabeled spatial. Conversely, even the mixed/self moment comparison does not have the Hölder properties of positive random metric variables; no probability measure is inferred from these signed Berezin integrals.

## 4. Full normalization bound and actual separated connected response

Use the coefficient ℓ1 norm on canonical Grassmann monomials, which is submultiplicative; a top Berezin coefficient is bounded by that norm. Each γa times a Spin(4) link has at most eight nonzero entries of modulus≤1, so the sum of four T blocks/4 obeys ||T||1≤8. Addition of coincident blocks preserves the bound. A unitary printed plaquette times γCγDγ5 has trace modulus≤4. Counting all24 spacetime ε terms, all16 C,D pairs and the1/4 prefactor gives

||S2||1≤2·24·16·(4/4)·8²=49152.                    (15)

Normalized Haar has mass1. Equation(7), or the full S2^4/4! coefficient, therefore yields the explicit conservative bound

|D|≤Dmax=49152^4/24.                                 (16)

This is an absolute coefficient bound in a signed theory; it is not a Monte Carlo or positive-density bound. No assumption on the sign of D was used to obtain this bound; section2b subsequently evaluates D=3366. The analogous retained full S4 norm is196608; it is not inserted in (16), because section2 PROVES its exact cancellation for these observables. Both g1 and g2 remain arbitrary.

On H=K=t≠0, define

q=2a4+2b4+c4=6477/32,
d=6b4+4c4=4923/8,
κ=4−d/q=2072/2159,
z=D g2^4/(q t^4).                                   (17)

Then Z=q t^4(1+z), ZH=ZK=2q t³, ZHK=d t², and the connected separated response has the EXACT form

C01(t)=∂H∂K logZ|H=K=t
 =(1/t²)[ (d/q)/(1+z)−4/(1+z)² ].                   (18)

Here ∂logZ means the algebraic ratio Z'/Z on a nonzero-Z chart; global log branches are unnecessary. Put

e=Dmax |g2|^4/(q |t|^4).

For e<1, the normalization is certified by

|Z(t,t)|≥q|t|^4(1−e),                               (19)

and comparison with the explicitly evaluated leading response gives

|C01(t)+κ/t²| ≤ E(e)/|t|²,
E(e)=(d/q)e/(1−e)+(8e+4e²)/(1−e)².                 (20)

To derive(20), bound the change in ZHK/Z by (d/q)e/(1−e) and the change of ZH ZK/Z² by(8e+4e²)/(1−e)². All numerator derivatives are exact because the entire interaction remainder in (6) is constant on this source slice.

A concrete arbitrary-coupling domain is real t with

|t|≥T(g2)=max{1, [100 Dmax |g2|^4/q]^(1/4)}.         (21)

No g2 is fitted or selected. On this domain e≤1/100, |Z|≥(99/100)q|t|^4. Since d/q<4,

E(e)≤4/99+804/9801<1/16+1/8=3/16,
κ>3/4,
Re C01(t)<−9/(16 t²)<0.                             (22)

This is an actual nonzero separated connected response with a uniform full-interaction error bound on the stated finite-source domain, including arbitrary g1. The bound was derived without relying on the subsequent D evaluation; after section2b one can replace Dmax by3366 for a sharper domain. At g2=0, Dg2^4=0 and the result is exactly−κ/t²; the model is NOT restricted to that check.

There is also a global real-source normalization control after evaluating D. Set u=H+K,v=H−K. Direct rewriting of(13) gives

Q4=[6477u⁴−522u²v²+45v⁴]/512
   =[45(v²−29u²/5)²+(24816/5)u⁴]/512.

Thus Q4>0 for real(H,K)≠(0,0), and for real g2 the restricted Z is strictly positive unless g2=H=K=0. This is normalization positivity, NOT positivity of a measure or Hessian. Over complex inputs the exact refusal locus is3366g2^4+Q4=0. Along H=K=t the exact cross-response numerator is t²[d·3366g2^4−κq²t^4]; at real g2≠0 it is positive for sufficiently small nonzero t, vanishes at that stated equality, and is negative for large t. Its zero-source value is0. None of these coordinate sign changes is identified with physical χ_vest.

For the total insertion O=U+V, χO=d²/dt²logZ(t,t) has exact form

χO(t)=(1/t²)[12/(1+z)−16/(1+z)²].                   (23)

The same argument gives |χO+4/t²|≤[12e/(1−e)+(32e+16e²)/(1−e)²]/t². At e≤1/100 this error is<1/t² (12/99+3216/9801<1). Therefore ReχO<−3/t². The full interacting finite-source chart does not furnish a positive susceptibility or a positive-measure Gibbs state merely because Z is nonzero. This is a countercontrol against importing log-convexity or treating this chart as the physical vacuum; it is not a no-go statement for the original physical model on other domains.

## 5. What was and was not evaluated

Equations(12)–(14), the exact cancellation(6), and the full-domain response(18)–(22) are evaluated manual results. The actual chronology first left D in three contractions, then reduced it to2922 plus(7g), then COMPLETED that signed remainder in section2b. D=3366 and the restricted Z are now fully evaluated. At g2≠0 the finite source-free denominator is nonzero, and all first and second restricted longitudinal metric derivatives of logZ vanish at H=K=0. The mixed fourth connected insertion there is (603/2)/(3366g2^4)=67/(748g2^4). A finite source-free normalized algebra is established; a physical thermodynamic vacuum is NOT established by that calculation or by positivity of its normalization. Other metric directions, TT response entries, and larger tori have not been evaluated by this calculation.

In particular the old one-site zero mean G and rank-ten joint26-coordinate Hessian remain exact old results on their old zero-source domain. Their ranks are NOT transferred to the present52-coordinate joint response or to arbitrary volume. The general Grassmann degree selection at J=0 implies one-T expectations and mixed T/G insertions vanish: they have degree2 and6 modulo4 while S and H insertions have degree0 modulo4. It does not force the TT block or every G mean to vanish in general. At this nonzero metric-source point, ⟨U⟩=ZH/Z is generally nonzero. The scalar response(18) is not a complete physical tensor projection, and cannot establish invertibility of the whole joint Hessian or a constrained graviton sector.

The exact auxiliary identity remains available with its FULL signed Hermite weight W and arbitrary representation variance. Neither C in(1) nor G is auxiliary h. Source differentiation must act on detM before a formal substitution of products; W has not been shifted, discarded or assigned positivity anywhere in this direct Berezin calculation. An independent auxiliary check must reproduce(12)–(14) with the same off-diagonal/source and Berezin orientations.

## 6. Literal printed plaquette/gauge-order countercontrol

The official primary HTML personally read is [Diakonov, arXiv:1109.0091v1, §§V.1–V.6](https://arxiv.org/html/1109.0091v1). It supplies the carrying orders, α=1/2 discretization, action and compact/Grassmann measures; no official PDF reading or PDF/HTML byte equivalence is claimed. Its Eq26 prints the left-to-right plaquette used in MODEL; Eq30 prints Ωxμ→Vx+μ Ωxμ Vx†; Eqs29,31 give the endpoint spinor/frame transformations. Those displayed conventions require a check before importing the asserted continuum/gauge interpretation.

There is an explicit extended-control mismatch. For the(1,2) plaquette at0 set Ω0,1=I, Ω0,2=I, Ω1,2=Y. The printed product is P0,12=Y. Set V0=V,V1=I. Using precisely the displayed link transformation and left-to-right multiplication gives

Ω0,1'=V†, Ω0,2'=I, Ω1,2'=Y,
P0,12'=V† Y V,                                     (24)

where a curvature at site0 paired with its frame matrices would require V Y V†. In one SU(2) sector choose V=exp(iπσ3/4), Y=iσ1; the two matrices are+iσ2 and−iσ2. The other sector may be identity. These are legitimate fixed two-site link values. Thus the literal printed product does not have that assumed base-site covariance under the stated transformation. This is a convention/order obligation, not permission to silently reverse products in MODEL.

This counterexample alone is NOT a completed proof of noninvariance of the entire summed Grassmann action: cancellations in that action would need their own proof. It does rule out claiming the usual plaquette basepoint covariance from these printed conventions. The original physical gauge/continuum bridge remains BUILD until a source-controlled convention reconciliation and coherent full-action calculation. The finite algebra and conservative norms above are well-defined with the fixed literal order, and the source-only endpoint rotation used in section3 does not assume full-action covariance.

## 7. Exact physical source/volume/units map and its missing data

The fixed microscopic T=a ehat is dimensionless in the regulator algebra. Bare Bμν=Gμν/a² has engineering dimension L^-2. Even a multiplicative physical-operator candidate Qμν=ZQ(a)Gμν/a² requires ZQ to be derived/calibrated, not fitted to the desired χ. The actual operator identification, possible tensor/operator mixing and contact subtractions have not been derived. The following source accounting is necessary under this stated candidate, not proof that it is the physical operator. A once-pair continuum source convention is

Σx a^4 Σμ≤ν jμν(x) Qμν(x)
 =Σx Σμ≤ν Hμν(x)Gμν(x), H=a² ZQ j.                 (25)

For a physical symmetric contraction Σallμν Pμν Qμν, independent once-pair coordinates instead require Hμν=(2−δμν)a² ZQ Pμν j. An omitted factor2 on off-diagonals changes the tensor response; the old coordinate variance9 versus Frobenius variance18 is not a physical spin-two multiplicity.

Under translation invariance, the integrated physical response is

χQ(p)=a^4 Σx exp(−ip·ax) (ZQ/a²)² C_G(x,0)
     =ZQ² Σx exp(−ip·ax) C_G(x,0),                  (26)

with the corresponding tensor weights on both insertions. The finite physical volume is Va^4. For a constant source, define Otot=Σx a^4 Q(x) and Vphys=Va^4. Then ∂j²logZ=Var(Otot), the susceptibility density is Var(Otot)/Vphys, and Var(Otot/Vphys) is that density divided once more by Vphys. These are algebraic connected responses, not automatically positive variances. The total insertion, its density response and the response of its average must not be interchanged. Equation(26) assumes the specified physical operator and source, and still requires a nonzero normalized background/state, connected subtraction and volume control. The present single separated component supplies none of the omitted tensor components, all separations, or their infinite-volume error.

If [Q]=L^-Δ then [ZQ]=L^(2−Δ), [χQ]=L^(4−2Δ). A bareΔ=2 composite has dimensionless integrated response, whereas a proposed O(Λ²) susceptibility has dimensionL^-2 and needsΔ=3, an additional dimensionful normalization/numerator, or a differently defined operator. A dimensionless physical metric (Δ=0) instead gives an L^4 integrated response. These are distinct quantities; no equality follows from the name metric susceptibility. The scalar four-dimensional bubble with two (p²+r)^−1 factors is dimensionless. It cannot by itself supply a quadratically divergent physical metric response.

A tensor continuum bridge would have to derive the background metric, full constrained vertex/numerator, source renormalization, field and spin/channel multiplicities, cutoff shape and lattice Brillouin-zone matching, contact/subtraction scheme, and analytic continuation/positivity conditions. A trace/traceless coordinate arithmetic factor or chosen eigenvalue is not that derivation. Neither reflection positivity nor a Lorentzian retarded spectrum has been established by(18). The finite-source negative Hessian(23) explicitly blocks importing positive-Gibbs convexity on this algebraic chart. No ordered phase, physical spin-two projector, Goldstone/graviton mode or full g1/g2 phase diagram is inferred.

## 8. Coupling/RPA/window matching: actual mismatch, not assigned equality

The current source definitions personally read in full relevant bodies supply L1 u_g from Nf,γ_proj,D and log2, an independently supplied c_D, and γ_star in the RPA expression. Their arithmetic positivity does not derive those parameters from original g1,g2 or ZQ. The exact fixed control instead gives(6) and(18), with g1 canceled only by the proved geometry/source selection and g2 entering through the evaluated3366g2^4. In particular its large-source χO is negative and tends to0 as t grows. No map from those results to the adopted positive χ_vest or its window can be obtained by setting u_g or ZQ to a convenient value. This is a demonstrated distinction in definitions and domains, not proof that a physical matching on another justified domain is impossible.

The previously reviewed regulated scalar integral is

Πexact(r,Λ)=[log(1+Λ²/r)−Λ²/(Λ²+r)]/(16π²)>0,

whereas the current carrying old IR expression is [log(Λ²/r)−1]/(16π²), positive only for r<Λ²/e. Their exact difference is [log(1+x)+x/(1+x)]/(16π²), x=r/Λ², between2x/[(1+x)16π²] and2x/(16π²). This controlled scalar error still needs the tensor/numerator/source/coupling bridge; it is not the missing physical computation. Similarly χ0/(1−γ_star χ0) has no finite uniform upper bound if positive inputs can approach its pole. Required refusal/domain controls include a proved distance from the pole and quantitative propagation of parameter and truncation error. Positivity of free scalar inputs cannot produce the target[0.1,10].

The current Lean numerical factors for trace/traceless channels and the window bounds are supplied/adopted definitions and arithmetic implications. c_GW=c√χ_vest does not determine χ_vest; the assumed γω frequency correction and laboratory frequency units are a separate matching problem. The physical [0.1,10] RESULT remains owed, unchanged; neither χ=1, a selected coordinate/eigenchannel, M/(96g2²), the finite-source value(18), nor a different interval is substituted. All three distinct L1 duties, shared D1/E1/E2 dispersive matching and the original all21/B1–B8/D12 physical charter remain BUILD.

## 9. Completed contraction, independent DATA UNRUN reference, and missing physical construction

The original three contractions in(7) have now ALL been attempted and evaluated manually: the mixed term vanishes, the A part is2922, and the B part is444. The actual saved chronology of the intermediate unevaluated stage is retained in evidence; it was not backdated as complete. Section2b supplies the two16-generator top coefficients F(1,0)=135/32,F(1,1)=27/2 and every operator factor used to obtain them. No numerical/symbolic coefficient computation was run.

A prospective DATA UNRUN reference job should independently extract these two top coefficients in exact Q(i) arithmetic from the stated16 generators and explicit matrices in(1),(7f). It should independently reconstruct D directly from all THREE original contractions in(7) before any cancellations, retaining all eight links/sixteen SU(2) factors, and compare to3366 and the separate2922/0/444 contributions. A second independently ordered wedge/top-coefficient implementation must agree, including Berezin orientation, chiral block permutation, epsilon contribution and factorials. A float nearzero cannot certify an exact cancellation. Such a reference job is independent assurance still UNRUN, not a replacement for the printed manual calculation or permission to execute.

For a direct reference, independent quaternion Haar moments satisfy

E ∏u_i^(2m_i)=∏(1/2)_(m_i)/(2)_(Σm_i),              (27)

and odd coordinate powers vanish. The unreduced S2^4 total link degree is≤24. The even-moment table through degree24 has1820 entries per SU(2) factor (Σm_i≤12). Sixteen such tables suffice, but this is NOT the full polynomial population. Balanced16-generator Grassmann sectors have Σk binom(8,k)²=binom(16,8)=12870 states; each can carry many link monomials before integration. By contrast the reduced F(1,0),F(1,1) job has only fixed Q(i) matrix entries and no remaining Haar variables. This sharper task follows from actual manual contraction, not a generic new algorithm.

An actual later authorized job should record exact coefficient numerator/denominator bit lengths, sector populations and elimination order, compare the two reduced top coefficients against the direct three-contraction reference, and retain all intermediate signed contributions. A prospective initial resource envelope for the unreduced reference is one contraction at a time,8GiB memory/8CPU-hour cap, with surviving Grassmann/link-polynomial populations after each link elimination. These are declared resource controls, NOT measured requirements, feasibility guarantees or execution permission. If independently authorized numeric quadrature is used as a secondary check, outward-rounded error intervals must include all compact-domain integration error and certify the sign/nonzero interval for D. The printed exact result is the assurance target; any actual reference implementation must be independently reviewed and admitted under its own future authorization.

Mandatory independent controls are: reproduce all four old one-site source/metric coefficients and their off-diagonal convention before the new torus; reproduce(12)–(14) with independent determinant/source differentiation and full W; show that deleting the cross-site block destroys the H³K witness; swap two adjacent generators in the Berezin top orientation as a poison and require the known source coefficients to reverse sign; perturb the1/4 T normalization to1/2 and require the saturated degree-eight result to multiply by256; poison E r⁴=5 to4 and require failure of the displayed25/268/558 audit (the R⁴ coefficient changes from25 to16); verify the1304/1296 curvature-correlation controls independently rather than relying on a plaquette reversal that could leave even moments invariant; retain arbitrary g1 terms until the link/site cancellations are checked; and restore every poisoned input byte-for-byte before any comparison. Native/proof/source/runtime/ownership grants are separate and absent.

The next substantive missing calculation is to extend the full tensor J/H insertion population to the arbitrary-L family, certify zero-free/source-free/thermodynamic domains, evaluate the full connected spatial kernel and its volume errors, then derive the physical tensor/normalization/coupling/cutoff/continuation bridge with an actual window bound and pole refusal. The finite control does not bound those missing steps, and no reduction of the original physical objective is proposed.

## 10. Scope and independent acceptance boundary

This construction provides a new exact coupled nonzero-separation insertion, proved geometry cancellations, an evaluated full finite-control restricted Z (including its source-free denominator), and a full-interaction finite-source connected-response domain with explicit error. It evaluates D and the finite source-free normalization, but leaves the full tensor/volume/thermodynamic physical state/coupling/window objectives unresolved. Those are substantive BUILD, not an asserted infeasibility or completed milestone by relabeling. The printed gauge-order control and signed-Hessian control are load-bearing limitations. A fresh genuinely nonauthor whole SCIENCE review must independently check every derivation, old-result reuse, cancellation, normalization, error constant and physical boundary. No author/source/native/publication acceptance or closure is claimed.

<!-- END SOURCE137-EXACT-L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION-CONSTRUCTION -->

<!-- BEGIN SOURCE137-EXACT-L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION-REPORT -->
# L1 original coupled spatial normalization — author handback

Status: **SUBSTANTIVE FINITE-REGULATOR RESULT; ORIGINAL PHYSICAL B3/WINDOW BUILD REMAINS; FRESH WHOLE NONAUTHOR SCIENCE REVIEW REQUIRED.** This is an author construction, not scientific acceptance, source/runtime delivery, a changed charter, or closure.

The prospectively fixed original2×1×1×1 periodic Spin(4)/Haar/Berezin model has now been evaluated on its two separated longitudinal metric-source coordinates, retaining the ENTIRE original action and arbitrary g1,g2. The new manual result is

Z(H0,11,H1,11)=3366g2^4+(375/32)(H⁴+K⁴)+(201/4)(H³K+HK³)+(2511/32)H²K².

It supplies a nonzero-separation mixed insertion I(G0,11³ G1,11)=603/2, a finite source-free normalization for g2≠0, and an exact connected two-site response at H=K=t with a uniform large-source comparison bound. CONSTRUCTION.md prints all mathematics and limitations; SOURCE_MODEL.md fixes the unchanged microscopic family and conventions. No engine/project/helper/model/test/native code was executed. The independent reference plan is DATA UNRUN.

## Actual chronology, authority and read depth

The ONE original FIRST ran at14:51:59.838795–14:52:00.031992 UTC, rc0,freshtrue,changed[], with the exact five argv in first-check.json and separate stdout/stderr. The complete baseline was saved at14:52:44.697169, before assertions or new mathematics:31 packet reference bindings, all P/N/M tracked paths and known dirty/untracked/historical-absent states, raw and semantic indexes, HEAD/status/refs,83 bounded administrative states, and all seven owned initial absences. Actual baseline populations were P5186tracked/7known/0porcelain, N4869/64/64, M4906/3/3. These protected inventories are not inferred porcelain populations. The actual31bindings/29authority preparation counts control over the lead's shorthand27. No refresh or implied live lease/hook/runtime authority.

The genuine SOURCE_MODEL save was14:55:19.725781 UTC, SHA829c0c498d6030c6b5f0678b950a30550b55d50044c14185f1adbe3050c42949, BEFORE any new mathematics. It fixes every original T block, gamma/plaquette/Berezin order, all arbitrary-volume and arbitrary-coupling terms, actual ten once-pair H sources, the full physical objective and the finite extended control. No new math preceded it. All FIVE original full constructions and FIVE complete nonauthor reviews were then personally read before new derivation; the full frozen inventory report was also read. Exact files/hashes/depth/tool receipts are in evidence.json. Earlier accepted mathematics is reused with its actual domains; copied old reviews are not new acceptance.

The actual L1 manuscript was read in full; VestigialSusceptibility.lean in full; all noncomment GravitationalWaves declarations/proofs and full relevant canonical function bodies/docstrings were read. Unrelated GravitationalWaves comments and unrelated canonical module text are not claimed fully read. The bound inventory JSON receipts are protected; a full fresh prose reading of every large JSON field is not claimed. The official [arXiv1109.0091v1 HTML §§V.1–V.6](https://arxiv.org/html/1109.0091v1) was read for carrying definitions/orders. No PDF read, PDF/HTML identity, saved fulltext or holding admission is asserted.

The first persisted manual scratch record is15:03:16.270267, after all carrying reads; it is not a fabricated exact earlier scratch time. CONSTRUCTION first save15:13:11.953677 left D unresolved. Further manual reduction at15:20:50.990019 found2922 plus a remaining signed B term. The15:24:58.869096 save completed that term as444. These actual stages remain in evidence; no backdating of the initially incomplete calculation. A later bounded rg locator output was truncated; it supplies no additional full-module read claim. No active retarded-response or six-file-review outputs were inspected, no delegation occurred, and no other author's work or lead notebook was edited.

## Exact new calculation and its controls

1. All coincident blocks are added. Longitudinal C=Ω0,1†−Ω1,1 connects both sites. Each transverse T is the exact anticommutator with Ω†−Ω; independent link inversion/center parity and site Grassmann counts prove every allowed g1 term and every source-dependent interaction coefficient vanishes on this particular source slice. This is geometry-specific, not g1 deletion or a free replacement.
2. The saturated source-only8×8 determinant and true difference-of-Haar-quaternion moments give the full degree-eight linear-source coefficients25,268,558 over65536. Laplacian insertions and exponential factorials give the displayed Q4. The H³K term cannot arise from a product of independent one-site metric polynomials. The original source/Berezin orientation and off-diagonal once-pair convention are retained.
3. The source-free S2^4/4! contraction splits into A0²A1²/4, A0A1B0B1, and B0²B1²/4. Center parity kills the mixed term. Equal/different-direction local contractions are1304/1296, giving2922. The other term reduces via the exact16/9 commutator tensor and local gamma/Pauli K to two fixed Berezin determinants F(1,0)=135/32,F(1,1)=27/2, giving444. The original1/4,1/4 T and factorial/source factors are exposed. D=3366 is an evaluated author result, not an assumed denominator. The epsilon/self-dual term in the chiral determinant is retained; the displayed operator-value audits are mandatory review targets.
4. Real-source Q4 has a positive completed-square expression and Z>0 unless real g2=H=K=0; complex refusal is exactly3366g2^4+Q4=0. At source zero and g2≠0, the two selected longitudinal metric first/second derivatives vanish; the separated mixed fourth connected derivative is67/(748g2^4). At H=K=t≠0 the exact cross-response is t^-2[(d/q)/(1+z)−4/(1+z)²], q6477/32,d4923/8,z3366g2^4/(qt^4). A stated arbitrary-coupling domain gives |error|<3/(16t²) around−(2072/2159)/t², so the response is genuinely nonzero. The total-source Hessian becomes negative for large real source. Normalization positivity does not establish a positive physical measure, convex effective action or physical vacuum.
5. The old full signed W, h≠T/G, source-before-product rule, one-site zero mean/rank-ten joint26 response, nonzero-source witness versus vacuum distinction, gauge/Hessian/pole limits remain. Their rank/positivity statements are not transferred to the new joint52 coordinates or arbitrary volume.

The finite algebra is exact with no truncation or numerical precision tolerance; it still requires independent mathematical verification. The large-source error is explicit and uniform on its stated t/g2 domain. No finite-volume-to-continuum, full tensor, source-to-vacuum, or physical-model matching error bound is claimed. Those remain substantive missing calculations.

## Physical interface findings and every unfinished objective

**Gauge/order interface.** With the literal printed plaquette and displayed Ωxμ→Vx+μΩxμVx†, a concrete two-site link assignment gives P0,12'=V†YV instead of the required base-site VYV†. V=exp(iπσ3/4),Y=iσ1 gives opposite sigma2 signs. This exact source/convention countercontrol is in CONSTRUCTION§6. It is not a full proof of noninvariance of the summed Grassmann action or an infeasibility verdict. A coherent source-controlled convention and full-action/gauge calculation are owed before importing physical covariance/continuum claims. The original model was not silently reversed or repaired here.

**Full spatial/tensor/state calculation.** Only the two longitudinal metric-source coordinates were fully evaluated. The full52-coordinate J/H response, all tensor channels and nonzero separations, arbitrary-L coefficients and zero sets, volume/thermodynamic errors, zero-source ordered background, constrained Hessian, nondegenerate metric, reflection/state positivity and Lorentzian continuation are NOT derived. The two-site transverse periods are one regulator cell; this is no controlled infrared approximation. Finite normalized Z is not a thermodynamic physical vacuum. Necessary next evidence is an exact full-tensor finite-volume construction with source/gauge controls and a quantitative larger-volume/domain analysis, not relabeling coordinate eigenspaces as spin2.

**Physical source/units/normalization.** CONSTRUCTION§7 derives the necessary source factors under a stated candidate Q=ZQ G/a²: H=a²ZQ j; full symmetric contractions require off-diagonal factor2; χQ=ZQ²Σx exp(−ipax)C_G with proper Va^4 total/density/average factors. The physical operator identification, possible tensor/operator mixing and contacts, derived ZQ, numerator, multiplicity, Brillouin-zone/cutoff and subtraction map remain uncomputed. The dimensionless bareΔ2 integrated response differs from an O(Λ²) quantity and from a dimensionless metric's L^4 integrated response. This dimensional accounting demonstrates why the old dimensionless scalar bubble is insufficient; it is not a completed physical normalization.

**Couplings and target window.** Actual source u_g(Nf,γproj,D), c_D and γ_star remain supplied inputs, without a derived g1/g2 map. This geometry's exact canceled g1 and3366g2^4 dependence are not identified with that scalar/RPA model. The physical [0.1,10] RESULT remains unproved on any justified physical input domain; no value, alternate interval, eigenchannel or normalization is fitted. The scalar regulated-bubble/IR difference remains controlled on its own domain, but tensor/coupling/error transfer and RPA distance-from-pole/refusal still need derivation. A large-source exact response that tends to0 with negative Hessian does not furnish the required positive window.

**Distinct L1 and shared-law obligations.** B3 susceptibility/window, full physical tensor/graviton dynamics, and physical transport/frequency matching are distinct unfinished duties. Existing c_GW=c√χ and γω implications do not supply their microscopic coefficients, physical frequency/units or observational matching. Full ADW phase, constrained fluctuations, Lorentzian/continuum/graviton and independent magnitude remain BUILD. Shared D1/E1/E2 dispersive matching and all21/B1–B8/D12 original goals remain unwaived. No task-completion, source/publication/native/holding acceptance follows from this finite result.

## Concrete independent assurance and next evidence

CONSTRUCTION§9 specifies DATA UNRUN exact Q(i) top-coefficient checks for F(1,0),F(1,1), a fully independent original three-contraction Haar/Berezin reference and separate2922/0/444 comparison, all16 SU(2) factors and fixed orders,12870 balanced Grassmann sectors, quaternion moment tables, population/bit-length/error/resource records, and a bounded reference envelope. It explicitly distinguishes prospective caps from measured resources and any numeric interval from exact zero/sign proof. All tests/builds/recipes/native proofs remain DATA UNRUN.

Mandatory controls include old one-site coefficients/conventions, full signed-W auxiliary agreement, deletion of the cross-site block destroying the witness, Berezin swap sign reversal,1/4→1/2 T normalization changing degree-eight coefficients by256, poisoned Haar moment detection, independent1304/1296 curvature checks, retained g1 terms until cancellations, and exact restoration. No poison was applied to actual files. Next substantive physical evidence must address every interface just listed; the finite result does not replace those objectives or presume infeasibility. Fresh genuinely nonauthor WHOLE SCIENCE review must check all original notes/reviews, model chronology, equations(1)–(27) including7a–7l, all claims/domains/constants/controls and physical limits, then lead intake. Computational/native/source admission remain ROOT-only under separate grants.

## Preservation and terminal procedure

Only the seven packet-owned ignored leaves were written. Full first/baseline/read/manual-save receipts and actual21 Git argv with separate pipes are in evidence.json; this report links the actual claims instead of dumping protected raw/base64 data. Full REPORT/CONSTRUCTION/MODEL/evidence/process are saved BEFORE the one original FINAL. That check has not yet run as of this report save; its actual stdout/stderr/UTC/rc will be preserved in final-check.json, followed by the full genuine terminal P/N/M/reference/index/admin capture and comparison in evidence/process. No presumed green terminal claim is made here. After that capture the seven leaves will freeze, and the final handback will provide actual statuses and hashes without rewriting this report or rerunning FIRST/FINAL.

<!-- END SOURCE137-EXACT-L1_ORIGINAL_METRIC_SPATIAL_NORMALIZATION-REPORT -->
