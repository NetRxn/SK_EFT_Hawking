# Interacting retarded spectral response — review

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** Whole declared interacting carrier and retarded spectral construction, exact state/operator/frequency and source conventions; independent manual acceptance only.

**Original physical obligations.** Original physical Mori/KMS/sum-rule/DKM/CHHK and actual low-frequency transport, phase/material/contact/nozzle/readout/calibration remain owed; model evidence does not identify the actual device.

The construction author is publication_njl_target_review; the complete independent scientific review is by publication_root7_current_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE](../E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE.md), [fixed source model](../source-models/E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE.md), [full independent review](../reviews/E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE-REVIEW -->
# Whole interacting retarded/spectral/memory construction — independent scientific review

**ACCEPTED AT THE DECLARED INTERACTING-LATTICE MANUAL SCIENTIFIC SCOPE.** I find no mandatory scientific repair in the complete thirteen-section/24-group construction at its stated domains. This accepts the actual signed matrix spectral measures, interacting neutral response, moment/current identities, positive thermal Hilbert construction, domain-correct exact memory and conditional comparison/error results on the original finite-central interacting CAR family with semi-infinite contacts. It does not accept physical bulk transport coefficients, a small-error useful band, actual material/device matching, native/runtime/source application, publication gates or main.

The exact construction is 9b59467b28483d7100522396eb1eb992b5785c4bbfd93a4b7e704a764e8a64ec; fixed SOURCE_MODEL dca1bfb166485255db4588d193b2435ace3b049261c40e3ad4c96ff2cccb6779; complete author REPORT ef9b1737cc53ccbb0858edff9db76869a302b03216a2685cc3154cc073cd531f. This is a genuinely nonauthor review. I authored neither this construction nor the interacting/growth science ancestors. My earlier whole scientific reviews and documentary SOURCE authorship are disclosed and confer no automatic acceptance.

The original material, large-area/continuum, physical density/transport/DKM-window, nozzle/horizon/state, contact/receiver/calibration and identifiable nonempty useful-band objectives remain BUILD. The original pre-MODEL and growth definition-read-first process failures remain unwaived. All21/B1–B8/D12, three separate L1 obligations, shared D1/E1/E2 law, native G4/G5/G11, actual failed main/CI/Verify receipts, ROOT integration/main and human acceptance remain separate.

## Complete reading, original model and scope

Before any new review proof reasoning, I personally read the full current fixed model, the complete original r3 interacting construction and whole nonauthor review, complete growth construction and whole nonauthor review, their exact physical models and carrying lead growth disposition, and the actual nine bound DKM definition/proof bodies. I then read the complete current thirteen sections and all24 equation groups, the full author report/process/FIRST/FINAL and the carrying author evidence chronology and draft corrections. Combined displays that clipped were recovered in bounded contiguous intervals; unseen output is not counted as read.

Static byte checks verify the complete original r3 model appears twice in the new MODEL because it is also enclosed in the complete growth model, which appears exactly once. These are actual full byte-identical enclosures, not substituted summaries. The current construction has the complete ordered sections1–13 and displays1–24. All source and science artifacts remain immutable. A parsed roster/count is not the mathematical acceptance; the independent derivations below establish that.

The carrier retains the finite physical embedded AB pi-orbital patch, both actual spins, nonzero intralayer/vertical/contact hopping, every original semi-infinite nearest-neighbour finite-band contact, bounded one-particle h and its image/background onsite potentials. The selected grounded-plane/static-dielectric/disjoint-rigid-cloud electrostatics and its finite central density interaction remain unchanged. Physical lambda=1 and all real comparison lambda, finite beta>0, arbitrary real mu including nonzero, complex physical hopping phases, spatial weights and original prepared states remain. This is not a free, finite-only, zero-mu, vacuum-selected, zero-interaction or changed-contact substitute.

For the original physical E2 objective I read the actual PAPER_STRATEGY E2 content: physically matched electrical noise/response, independent Keldysh and Landauer–Büttiker routes, an experimentally meaningful observable and detection band. Unsupported old numerical completion claims in that charter are not accepted by reproducing it. This milestone does not establish those device predictions or erase the original scientific work. The D5/E1/Phase6q original physical Hamiltonian/state-to-response/growth/transport classification remains the parent objective.

## 1. Inherited interacting state, domains and preparations

I rechecked the load-bearing ancestors at their actual full source, rather than relying on their verdict labels. Uniform normalized spherical clouds give self-energy coefficient6/(5a), image average1/(2z), and disjoint pair direct-minus-image inverse centre distances. Removing individual bare electron self-energy leaves the physical self-image potential −e²/(16pi epsilon z). Opposite-spin onsite U and four intersite spin pairs give the actual quartic V. Its positive coefficients make full central occupancy attain w=sum U_ii+4sum U_ij. The current model carries exactly this finite physical approximation; actual Wannier/exchange/dynamical-screening matching is still owed.

The infinite extensive many-body generator is not treated as a bounded CAR element. In vacuum Fock, dGamma(h) is the self-adjoint direct sum of its bounded p-particle sectors on its natural square-summability domain; finite-particle truncations form a core. Bounded self-adjoint V gives physical H on that same domain. In arbitrary thermal representations the norm-convergent local interaction cocycle defines the physical CAR automorphism without an infinite Gibbs trace or assumption that the state is normal in vacuum Fock.

The inherited positive equilibrium state is genuinely constructed. Y(u)=exp(uK_0)exp(−uK_lambda) solves Yprime=−lambda V_E(u)Y. At u=beta/2, cyclic finite-volume trace gives omega_0(Y A Y†)=Tr(exp(−beta K_lambda)A)/Z_0. Positivity and the denominator bounds exp(±beta|lambda|w) follow before the limit. Fixed-beta local orbital/cocycle/state approximations produce a positive normalized infinite state. Grandcanonical tau, its charged physical-time twist and Gaussian-smear/closed-strip limits are established in the complete r3 proof; an exp(beta²/epsilon²) majorant is never simply sent to epsilon=0.

Tau=gamma_(−mu t/hbar) composed physical alpha. V, charge and current channels are neutral, so their real and strip correlations use the physical group with ordinary neutral KMS. A charged grade-r channel retains the chemical factor. No arbitrary-mu full-CAR physical-H KMS is reinstated. Gauge/tau invariance also gives physical-alpha stationarity.

All original nonstationary preparations remain admitted: arbitrary positive-contraction central blocks and original tails, actual higher moments for correlated states, S1 coherent controls and the stationary Gaussian vacuum countercontrol. The old same-time S1 proof, including its explicit positive time interval and mean subtraction, remains distinct from an unequal-time non-Wick vertex. Nonzero coupling alone is not promoted into universal state nonGaussianity. The new spectral/memory claims apply to the selected equilibrium stationary state; the quench retains its positive two-time form and causal two-time response without an invented KMS spectrum.

The support-tree ancestor supplies actual local generator domains and bounds. Every even Hamiltonian term touches at most two spin orbitals; it commutes with every disjoint polynomial. Finite graph degree, bounded h and the finite central interaction prove the incident energy J_E is finite. At support size s, at most s+j vertices can contribute at step j, so the norm sum is bounded by (s+j)J_E. Combining with the commutator factor2 gives (2J_E)^n(s)_n, bounded by n!(2sJ_E)^n, and physical derivatives pay hbar^−n. This is not an assumed F3 coefficient or a total-volume norm of H. It establishes all local derivative domains, fixed-order cut stabilization and stationary high-frequency weight bounds on this same interacting model.

## 2. Physical channel and continuity identities — group3

For a spin-resolved bond, [H,q n_i] gives the displayed current with its actual charge sign and complex hopping conjugation. Summing the two spins gives norm2|q h_ij|/hbar: each two-mode current has eigenvalues±|q h_ij|/hbar and the commuting spin blocks can attain their positive maximum simultaneously. This is an operator statement, not spin-factorized interacting noise.

Since V and all onsite/background terms commute with every local number, delta Q_i equals the complete incident bond sum. Multiplying by finite weights and adding produces (f_i−f_j) on each unordered bond, including every crossing boundary bond. A finite central k=0 charge is therefore not conserved when it exchanges with its real leads. The infinite total charge is not inserted as a bounded CAR observable.

The actual weighted A_k has adjoint A_−k for real spatial envelope. Complex channels are retained by their complete Hermitian components. No patch translation, inversion, Fourier orthogonality, extra valley multiplicity or continuum area factor is inferred. Local-state centering changes a channel's norm and constant part appropriately; every later a_a denotes its stated actual norm bound.

The full-graph U_ii contact matrix element of [V,I_up] is nonzero with the opposite spin present. It vanishes in the corresponding empty-opposite-spin control. This verifies that later force/current moments contain the actual interaction even though the first density continuity commutator does not.

## 3. Matrix spectral orientation and detailed balance — groups4–5

Let x_a=pi(X_a)Omega for the Hermitian centered basis and U_t=exp(itL), with the Hilbert product conjugate-linear first. By stationarity,

omega(alpha_t(X_a)X_b)=<U_t x_a,x_b>
                     =int exp(−iomega t)<x_a,E_L(domega)x_b>.

This fixes the signs in group4. Reversing operator order gives M_ba(−domega). For every Borel set and coefficient vector c, c†M(B)c is the squared norm of E_L(B)sum c_a x_a; hence the full matrix Borel measure is positive and Hermitian. Its total mass is omega(X_a X_b), which need not be real entrywise. Cauchy–Schwarz for spectral partitions bounds offdiagonal total variation by a_a a_b.

For complex channels A=F X, the ordered A,A† measure transforms as F M F†. This is different from falsely treating each cross entry as a positive real spectral density. The Hermitian basis/GNS expression and that ordered complex-channel convention must be kept together.

In a finite full interacting Gibbs box, a transition contributes p_m X_a,mn X_b,nm at omega=(E_n−E_m)/hbar. Neutrality gives equal particle number. Swapping the two levels multiplies the thermal weight by exp(−beta hbar omega), proving M^T(−domega)=exp(−b omega)M(domega). The original full local state/dynamics limit supplies weak convergence; uniform local second moments give tightness. On compact frequency sets the exponential factor is bounded. Passing the identity there and then exhausting Borel sets establishes the full measure identity, without assuming absolute continuity or losing negative frequencies.

Thus K=(1−exp(−b omega))M is a signed Hermitian matrix measure, positive on omega>0 and negative on omega<0. Its negative-frequency partner is −K^T. A single Hermitian channel has odd K. A complex spatial channel instead pairs k with −k; same-k oddness needs an additional real physical symmetry. This proof makes no such symmetry assumption.

For grade r, X_mn requires N_m−N_n=r, so the reversed Gibbs weight is exp[−beta(hbar omega+mu r)]. For annihilation r=−1 it is exp[−beta(hbar omega−mu)]. This retains the arbitrary-mu charged countercontrol instead of confusing stationarity, neutral physical KMS and full-CAR grandcanonical KMS. There is no extra fermionic sign in the ordinary operator KMS relation.

## 4. Elastic atom, every probe and nonstationary covariance — group6

E=M({0}) is the actual Gram matrix of invariant GNS projections. It is PSD and, for this Hermitian thermal basis, symmetric. Centering removes the mean vector but need not remove every invariant fluctuation. K({0})=0 supplies no value for E. The coth reconstruction consequently applies to the inelastic nonzero-frequency measure; it does not recover the missing atom by a zero-times-infinity operation.

For Y=sum_a integral f_a(t)X_a(t)dt, its GNS vector is sum_a fhat_a(L)x_a. Squaring gives precisely integral fhat† M fhat and the elastic quadratic form fhat(0)†E fhat(0). It can vanish when the probe's zero vector lies in E's nullspace; the author correctly repaired its earlier “all probes” overstatement. Complex probes, dependent channels and zero-average probes are handled without deleting them. The symmetrized measure remains positive as the average of the two ordered positive measures.

S=2pi M is the density-style measure convention; ordinary inverse angular transform uses d omega/(2pi) when densities exist. Changing to Hz changes the argument to2pi f, and positive-frequency folding occurs once. E delta_0 is a measure, not a smooth PSD interpolation value.

Every retained finite interacting Gibbs box gives a strict elastic control: total N_L commutes with H_L and has positive variance because its faithful density gives positive weights to vacuum and occupied sectors. Its response is zero while its centered noise is not. The construction correctly does not claim an infinite extensive N is bounded or that a finite-region local charge inherits that conservation. In the original infinite model E remains its actual invariant projection, possibly zero.

For arbitrary retained quench states, omega_init(Y†Y)>=0 gives the complete positive two-time centered covariance. No single-frequency measure, detailed balance, equilibrium FDT or thermal memory metric is assigned to that nonstationary family.

## 5. Actual causal source, UHP function and dimensions — group7

Expanding physical evolution under Hprime=−fX gives +i/hbar times the commutator, so the source sign is fixed. The time kernel is bounded by2a_a a_b/hbar. Exponential damping with Im z=eta>0 gives norm bound2a_a a_b/(hbar eta). Every nth complex derivative pays t^n; its integral yields the stated2a_a a_b n!/(hbar eta^(n+1)). These uniform compact-UHP majorants prove true holomorphy, not the repository's real-value existential predicate.

Integrating exp[i(z−omega)t] gives i/(z−omega). Combining with +i/hbar produces the Cauchy transform int K/[hbar(omega−z)] with the correct sign. Boundary anti-Hermitian matrix measure is pi K/hbar; the Hermitian part is its principal-value dispersion distribution. No arbitrary cross entry is replaced by its scalar imaginary part, and no pointwise boundary density or limiting-absorption estimate is inferred merely from finite total variation.

Chi has conjugate-observable response units X_a X_b/J. Its time kernel has X_a X_b/(J s); its absorptive Borel measure has X_a X_b/(J s), whereas its density, if it exists, has X_a X_b/J. These checks distinguish beta, hbar and2pi factors. Bounded one-particle h does not imply compact interacting many-body spectral support.

## 6. Integrated microscopic moments and genuine thermal inequalities — groups8–10

The local generator bounds justify differentiating the actual commutator covariance. The nth derivative equals (−i)^n int omega^n K; hence int omega^n K=i^n omega([delta^n X_a,X_b]). At n=1, substituting delta=(i/hbar)[H,.] yields omega([X_b,[H,X_a]])/hbar. The absorptive first moment therefore has the stated hbar^−2 double commutator. For a Hermitian scalar its positive-frequency first moment is half the full odd-commutator first moment. Equilibrium positivity gives its nonnegative value; no positive sign for every individual bond expectation is required.

The large imaginary-frequency expansion follows by the exact finite geometric identity for1/(omega−z). The remainder retains |omega|^(p+1)|K|/[hbar |z|^(p+1)Im z]. Proven higher local derivatives supply the required moments. This is an asymptotic expansion, not a power series claimed convergent for every z.

For omega≥r>0, g(omega)=(1−exp(−b omega))/omega is positive and decreasing: its derivative sign is exp(−x)(1+x)−1≤0. Therefore the exact quadratic-form thermal window integral is bounded by g(r)M([r,Lambda])/hbar and then g(r)M(R)/hbar. Matrix cross entries are not bounded by an entrywise positivity argument; the inequality is tested in every coefficient vector or PSD probe trace.

The GNS moment estimate gives M_A(|omega|≥R)≤R^−2n||delta^n A||². Inserting the actual support-tree bound gives group10. If n=floor[r/(e epsilon_A)]>0, n!≤n^n makes the weight bound exponentially small in n. The n=0 case remains valid; no claim uses this integer choice when it is zero or when the channel is null. This is integrated weight control, not a pointwise device spectrum or the optimal CHHK numerical constant. The independent elastic atom remains excluded only by the explicitly positive lower frequency r.

A weighted spatial integration forms the actual Gram matrix of finite weights. The source's Brillouin-zone/Poisson-summation and unit-cell normalizations cannot be imported into a finite inhomogeneous open patch. The construction leaves that physical matching as work owed.

## 7. Actual graph f-sum, Hessian, gauge and Ward identities — groups11–12

For each bond [Q_f,c_i†c_j]=q(f_i−f_j)c_i†c_j. The inner [H,Q_g] has the opposite weight difference. Applying the outer conjugated charge gives the minus sign and product of differences in group11, including complex h and both physical spins. V and onsite terms vanish from this first double commutator because they commute with all site charges; their effect remains in the actual interacting expectation and higher moments. This is a real microscopic identity, not a supplied “sum-rule” parameter.

Differentiating h_ij exp(iq Phi/hbar) gives I=−partial_Phi H and T_bb=−q²omega(H_bond)/hbar². Scalar potential couples as +phi Q, so the generic negative source of group7 is f_Q=−phi and the flux source f_I=Phi. Current differentiation contributes −T Phi in addition to the retarded state response.

I independently integrated by parts:
B chi_IZ=−(i/hbar)omega([Q,Z])−iz chi_QZ.
For Z=Q the equal-time commutator is zero. For a bond current, direct CAR gives −(i/hbar)[Q_i,I_b]=B_ib T_bb after expectation. Thus
−iz chi_QI=B(chi_II−T),
with the exact signs in group12. Omitting T fails this contact identity. Every crossing boundary bond remains in B.

The local gauge unitary gives Phi→Phi+theta_i−theta_j and phi→phi−dot theta, leaving −dot Phi−(phi_i−phi_j) invariant. Fixed density V is gauge invariant and has no flux derivative. A truly driven gate/kernel would require its own terms.

For phi=0, voltage=iz Phi gives Y=(chi_II−T)/(iz). At nonzero real frequency where the regular densities are used, Y_H=pi K_II/(hbar omega)=(Sgreater−Sless)/(2hbar omega). This fixes the author's earlier draft factor. The full analytic Y retains the contact term; this divided-frequency identity does not define a zero-frequency division of distributions or eliminate a possible zero-frequency pole/Drude contribution. No regular DC admittance is accepted here. Zero-inclusive noise still uses the independent E and the complete ordered measure. This is the literal nonzero-frequency domain of the displayed quotient, not a claim that the original DC/bulk/device objective has been delivered.

Differentiating each time of the covariance gives −iomega M_QX=B M_IX and its second-channel adjoint. Combining them yields omega²M_QQ=B M_II B^T. At zero these remain constraints on storage/current elastic blocks, not permission to discard charge E. No continuum k or external displacement current replaces the actual incidence matrix.

## 8. Positive thermal Hilbert space and exact response relation — groups13–14

The Duhamel expression is a KMS strip correlation, not a claim that every local interacting observable has an unbounded imaginary-time operator at all u. In a finite box its spectral coefficient is the logarithmic mean of two Gibbs probabilities. It is positive and at most their arithmetic mean; therefore
0≤D(A,A)≤[omega(A†A)+omega(AA†)]/2≤||A||².
The local KMS/strip limit preserves this inequality on the neutral algebra.

For the Hermitian channel basis the corresponding spectral factor is
g_D(omega)=(1−exp(−b omega))/(b omega), g_D(0)=1.
It is strictly positive at every finite real omega, and K=b omega nu with nu=g_D M. The exponential growth of g_D in one direction is not ignored: KMS and the logarithmic-mean bound establish its finite mass. A zero-D vector consequently has zero ordered mass, not merely a small or deleted signal.

Quotienting exact nulls and completing gives a genuine positive Hilbert space. Alpha preserves the form and is strongly continuous there because D≤norm²; Stone's generator L_D is self-adjoint. The proven local norm derivatives place local polynomials in all its domains and give L_D[A]=[delta A]/i. Adjoint is an antiunitary J on this neutral thermal space: finite-volume logarithmic-mean symmetry gives J L_D=−L_D J, and the established form/dynamics limit passes it. This is not an assumed physical time-reversal symmetry of the graph.

The thermal spectral measure of each Hermitian channel satisfies nu(−domega)=nu^T(domega); its Gram C is real symmetric. Direct substitution of K=b omega nu into the Cauchy transform gives
chi=beta(C−zR), R=<X,(z−L_D)^−1X>.
Inverse transform yields chi^R=−beta theta(t) d_t C_D(t). It is not −beta d_t[theta C_D], which would introduce a spurious contact term.

At z=i eta, omega/(omega−i eta) is bounded by1 and tends to1 off zero and0 at zero. Dominated convergence proves chi(i0)=beta(C−E). Isothermal beta C differs by the invariant redistribution. A conserved fluctuation C=E>0 has zero response. Neither elastic nor null directions are removed to obtain this formula, and beta C is not automatically a measured thermodynamic bulk compressibility.

## 9. Domain-correct projection, resolvent and memory — groups15–16

For every original finite list u_i, the Gram pseudoinverse formula P=U G^+ U† is the exact orthogonal projection onto its positive range. Dependence and nulls remain in the original channel map. No arbitrary inverse or removed population is used.

Since all u_i lie in D(L_D), L_D P is bounded finite rank. Its adjoint extends P L_D, so T=Q L_D P and T† are bounded. Subtracting the bounded self-adjoint offdiagonal T+T† from L_D leaves a self-adjoint operator on D(L_D). P preserves that domain; its block offdiagonal terms vanish. Hence P,Q reduce this operator and its resolvent, proving the complementary part L_Q self-adjoint on QD(L_D). This avoids the false general assertion that arbitrary compressions of an unbounded self-adjoint operator are self-adjoint.

Block elimination now gives the exact Schur complement Sigma=T†(z−L_Q)^−1T and compressed resolvent inverse. The imaginary part of a self-adjoint resolvent is −eta[(Re z−L_Q)^2+eta²]^−1. Consequently Im Sigma≤0, ||Sigma||≤||T||²/eta and the inverse denominator has imaginary part at least eta P, giving inverse norm≤1/eta on the full range. This holds for every eta>0 and includes conserved sectors; it is not a claim about a real-axis inverse.

K_mem(t)=T†exp(−itL_Q)T is positive as a two-time matrix kernel: its filtered quadratic form is the squared norm of an integrated unitary vector. It need not have entrywise positive values at each time. Its transform is Sigma=−i int_0^infinity exp(izt)K_mem(t)dt, with the sign fixed by the elementary resolvent integral.

For q(0)=0, the Q equation gives q(t)=−i int exp(−iL_Q(t−s))T u(s)ds. Substitution into the P equation produces (−i)^2=−1 and exactly the Volterra equation in group16. The bounded kernel supplies finite-time Volterra convergence. This memory retains the actual interacting force; no Markov rate, free bubble, event covariance or nonstationary thermal metric has been assumed.

## 10. Actual density-force chain and every zero case — groups17–20

For Hermitian N with C>0, normalize e0=N/sqrt C. If ||L_D N||=0, it is invariant and its response vanishes; the elastic channel remains. If C=0, its actual null signal remains in the channel map. These are original cases, not excluded samples.

For C>0 and v>0, e1=L_D e0/v is normalized and orthogonal to e0 because the scalar thermal measure is even. Its third moment is finite and odd, so <e1,L_D e1>=0. Also Q L_D e0=0. Thus in this actual pair M has offdiagonal v and diagonal0; T has first column0 and second F=Q L_D e1=L_D e1−v e0. The force contains the actual L_D²N, hence interaction-current terms, not a chosen relaxation constant.

The Schur inverse gives R00=(z−m)/[z(z−m)−v²]. Inserting it into beta C(1−zR00) gives beta C v²/[v²−z²+z m], with all signs fixed. J e0=e0, J e1=−e1 and JF=F make the force spectral measure even. Its mass is ||F||². Eliminating the current yields a''+v²a+int k a'=0 with a(0)=1,a'(0)=0; no initial force term is dropped because the initial vector is e0.

At positive eta0, evenness cancels the real part of m(i eta0), leaving
r_eta0=eta0 int nu_F/(eta0²+omega²)≥0.
Its integrand is strictly positive, so r_eta0>0 exactly when F is nonzero in the thermal Hilbert space. F=0 is an admitted undamped chain, not an inconvenient omitted population. The resolvent identity gives
|m(z)−m(i eta0)|≤||F||²|z−i eta0|/[(Im z)eta0].
This is a real computed functional definition and bound on the stated model; it need not be small.

V² here has frequency² units. F has frequency units, m and r have frequency units. When k≠0 and r>0, tau_eta=1/r and D_eff=v²/(r k²) have seconds and m²/s. Their k/resolution/weight/contact/patch dependence prevents calling them established bulk tau,D. No transport-window existence follows from a positive norm.

With constant m0=−ir, the comparator denominator is v0²−z²−irz. Dividing by r gives Dk²−tau z²−iz and the stated imaginary part with denominator omega²+(Dk²−tau omega²)^2. Its poles lie strictly below the real line when r,v0²>0. The r=0 and v=0 limits retain their undamped/conserved prescriptions; they cannot be obtained by silently dividing by zero or discarding spectral atoms. Complex spatial pairs use the full matrix projection.

Writing the actual denominator as D0+DeltaD and subtracting B/(D0+DeltaD)−B0/D0 gives exactly group20 under |DeltaD|≤theta|D0|, theta<1. Both numerator mismatch and denominator mismatch appear. For identical C,v the resolvent bound18 controls DeltaD. There is no claimed window where theta is small; the conditional inequality is a calculable acceptance criterion whose premise still needs physical evidence. At finite eta a bounded response probe costs its L1 norm times the window supremum; complement/tails remain. Sending eta to0 without uniform limiting absorption/force bounds is not allowed. Response closeness alone cannot reconstruct noise across the singular Bose factor or bound independent E.

For high imaginary z, z m(z)→||F||² by finite mass and dominated convergence. Thus m cannot equal a nonzero constant −ir at every frequency. The scalar Hermitian commutator also has its required odd/even moments; a globally white memory generally creates a forbidden higher-moment term. This is an exact obstruction to that all-frequency ansatz, not physical infeasibility of a controlled finite window.

## 11. All error and limit estimates — groups21–24

On the common infinite one-particle space, free paths of degree below ell from the full A/V support cannot meet the changed boundary bond. Their projected Taylor coefficients coincide. Two exponential tails give epsilon_U≤2exp(x)x^ell/ell!, with x=||h||_bound T/hbar. A degree-d monomial costs d epsilon_U; four V fields cost4w epsilon_U; the two interacting cocycle sides add8|lambda|wT epsilon_U/hbar. Multiplying by the actual coefficient absolute sum proves group21 uniformly on compact real times. No contact is omitted and no finite-only carrier is substituted.

The explicit inherited imaginary-state bound uses kappa≥||h−mu||, M_imag=beta w exp(4kappa beta), orbital tail e_N and Dyson tail at finite beta. Telescoping four fields gives4w exp(3kappa beta)e_N; nonunitary integral-equation comparison contributes exp(2a). The local free covariance Bernstein bound eta_R≤beta kappa/(2sqrt(q_poly)) and finite Majorana expansion constant4^s4s(2s−1)!! give B_err and the true denominator lower bound in group22. The coefficient is loose but valid; min with2 is an actual state-norm cap. Empty algebra has zero mismatch, and positive approximation degrees/cut neighbourhoods remain explicit. These are not invented numerical material errors.

For two dynamics replacements, raw-product error is b eta_A+a eta_B plus the local state term. Telescoping both means gives the additional same dynamics cost and two state terms. This proves group23:
2(b eta_A+a eta_B)+3ab eta_state.
Use a common finite cut before the local-state estimate; a quasi-local evolved operator is not falsely inserted into a finite-algebra bound. Double L1 probes multiply the supremum. Actual preparation error for a quench remains distinct.

In the retarded transform, the two commutators each have norm≤2ab. Their unestimated tail after T therefore costs4ab exp(−eta T)/(hbar eta). The compact integral costs the actual expectation mismatch divided by hbar, proving group24. Choose T for the tail, then contact length/local-state approximation for the compact interval. This constructs infinite-contact UHP response at fixed eta, not a real-axis/DC/large-time exchange.

For D/Gram comparison, Gaussian averaging gives ||B−B_epsilon||≤epsilon||delta B||/sqrt(pi) from the exact Gaussian first absolute moment. Two finite/infinite replacements cost2||A||epsilon||delta B||/sqrt(pi), using their uniform derivative bound. At fixed epsilon the inherited compact strip error has exp(Y²/epsilon²), actual compact-time delta_B,L and the explicit Gaussian tail epsilon exp[−(R−T)^2/epsilon²]/[sqrt(pi)(R−T)]. Choose epsilon for the first error, then R and contact/local-state approximation. Never send epsilon to0 through that divergent prefactor. Integrating the actual strip correlation/state error proves D/Gram convergence. Centered covariance additionally retains the mean/state telescopes already explicit in group23.

Uniform higher derivative moments permit lower-moment limits by tail splitting. None of this makes inverse Gram, v ratios or reciprocal r uniformly continuous near a null eigenvalue; a measured/proved positive lower bound is needed for those inverse claims. Absolute forms and the original channel map remain available without it.

Weak measure convergence does not prove convergence of M_L({0}); atoms can approach zero. The actual invariant projection E or an additional uniform near-zero-mass argument is required. Bounded continuous spectral tests with independent tail/zero control are the admitted ordered-noise comparisons. This correctly separates stable finite probes from unproved pointwise PSD, zero-atom or physical useful-band convergence.

## 12. Source/predicate comparison and meaningful controls

I personally checked the official CHHK v2 Eq4/17 and Methods7.1/7.2 carrying definitions and lattice normalization context, in addition to the previously read v1 Eq15. The stable comparator matches that denominator and its positive-imaginary-axis form. The source's spatial lattice/thermal assumptions do not identify this open finite patch with bulk density response. Its hbar=1 convention is not copied over physical SI factors here. [CHHK v2](https://arxiv.org/html/2509.18255v2)

The actual repository F1 has a different formula; at the stated all-one values it gives2/37 rather than2/13. Literal F4 is all-real nonnegativity and F6 oddness, forcing zero; F1 at negative frequency contradicts F4 for every positive capsule. F5 is a real-value existential, not holomorphy. F2 supplies a pointwise bound, not the integrated microscopic moments. Those exact bodies were read before review reasoning, and remain unchanged.

The action-link structure assumes its response implications; the KMS wrapper projects that positivity without its KMS hypothesis; NoCrossing packages assumptions; SDP feasibility is True. The LDP function is constructed from selected parameters independently of G. Assigned classifier labels and all-one MIR records do not become physical platform classifications. The new actual measures/response/memory therefore do not inhabit or repair that inconsistent literal full bundle by declaration. Valid normalized inequalities, factorial estimates and conditional sequence mathematics remain.

I independently checked all manual controls, including the actual charge/inflow transition matrix
w[[1,iomega],[-iomega,omega²]], positive rank1 and generally imaginary offdiagonal; negative-frequency adjoint sign; arbitrary-mu charged versus neutral balance; conserved finite-box elastic fluctuation with zero response; dependent/null channels and v/F zero cases; the actual U contact-force matrix element; Hessian/storage signs; all unit/folding factors; moment asymptotics and comparator limits. These use actual original operators or retained finite-box approximants, not a favorable model replacement.

The independent future finite-CAR Lehmann/reference-versus-source/contour calculation is DATA UNRUN. Wrong signs, frequency clipping, lost adjoint partner/mu twist/elastic atom, doubled spin/Hz, wrong denominator, omitted Hessian/boundary/vertex, arbitrary Gram inverse, removed population and unjustified white memory need actual targeted red receipts, exact byte+nanosecond-mtime restoration and full original green/native review later. No string count, planned poison or manual control is reported as an executed production test.

## 13. Process, actual preservation and original full objective

The author's recorded fixed MODEL save14:30:20.054102–14:30:20.054595 precedes its new mathematics and first construction write14:42:31.852159. The14:33:38 marker is a reading/progress checkpoint, not an exact mental-start timestamp; the explicitly disclosed small orientation scratch followed the completed model/dependency reads and preceded that marker. I do not backdate those observations. The old interacting pre-MODEL and growth direct-definition-first failures remain unwaived; current mathematical acceptance does not cure them.

Author evidence retains its failed draft ReY=K/(2hbar omega), corrected before final to pi K/(hbar omega) because S=2pi M. The final expression has been independently derived above; the failed draft is not a runtime/test failure or silently erased. The probe statement was also correctly narrowed to the actual elastic quadratic form/null condition. One top-level initialized evidence field new_math_started remains false despite the actual completed new proof and later records. That stale initial flag must not be read as evidence that no mathematics occurred; the detailed model/read/write chronology and report are authoritative. Lead intake should preserve this metadata precision, not alter the frozen author's record.

Author FIRST/FINAL counts remain1/1, no refresh. Its original FINAL returned1/owned-files. Full author terminal evidence separately retains shared wt1 d329→5e491ce4 and bounded administration changes with actor/cause UNKNOWN; adapter changed-files output is not a full administrative preservation claim. Its historical known7 P paths and actual clean-P status remain distinct inventories.

My fresh original FIRST ran once14:57:21.289652–14:57:21.595160 UTC, exact five argv/cwd N, rc0 fresh=true changed=[], separate stdout/stderr. Packet d452aa5b2823c4b0507282020b264323ac0ca5e8409b989bd6096c382be22a5a is DATA, not a sixth argument. Full protection was saved before assertions:35 unique packet/reference fullstates, P5186/N4869/M4906 tracked states, actual0/64/3 dirty-untracked paths, raw-index bytes/fullstats separately from semantic stages, HEAD/status/named refs, bounded administrative paths and five owned absences. Captures are serial observations, not global atomic quiescence.

My actual prefinal comparison at15:03:02–15:03:04 found all bound references and every P/N/M tracked/known dirty fullstate, raw/semantic index, HEAD/status/refs exact. Two directory mtime/ctime pairs differ from this genuine review baseline; actor/cause UNKNOWN. No source change, earlier author's named-ref movement during this review, new lease, runtime or application grant is inferred. The full actual receipt and subsequent terminal comparison remain separate JSON records. This complete scientific report precedes my ONE original FINAL; only its genuine receipt/protection/freeze follow. No terminal result is predicted here.

Only the five allocated ignored review leaves are written. No actual source/Git/index/ref/book/holding/registry/ledger/notebook/closure mutation, project/helper/model/test/mathsoftware import/evaluation/collection/execution, recipe/native/Lean/controller/build/render/export, external communication or delegation occurred. Official primary web reads were read-only, with no full-text saving or holding admission. Other active L1/science-source authors' changing outputs were not inspected.

The accepted scientific milestone is the exact finite-central interacting-lattice, infinite-contact state/response/spectral/memory construction, with its complete quantum channels, errors and zero cases. It is a substantive component of the original full physical objective, not its replacement. Original physical material/Wannier/exchange/dynamical screening/contact matching; uniform large-area/growth and translational/volume normalization; physical bulk susceptibility, force decay, kinetic/hydrodynamic memory-flatness and low-k limits; a genuinely small-error nonempty window; independent microscopic routes; nozzle/horizon/incoming partner state; receiver/displacement/gate transfer; absolute noise calibration and uncertainty remain BUILD.

Publication scientific lead retains the accepted parent ownership; publication_njl_target_review authored this milestone; this whole review supplies fresh nonauthor manual verification. Next action is lead full intake of these exact proofs and process boundaries, then explicit assignment of actual material/large-area/force-memory/window and receiver continuation with required independent scientific evidence. No owner acceptance of a private future task is invented. ROOT retains source definition/consumer migration, actual application, reference/runtime/native qualification, full gates and safe main milestones.

Distinct polariton pump/spatial/Fock and BEC Hamiltonian work, all21/B1–B8/D12, three separate L1 roots and the single shared dispersive-law obligation remain. Dated main/CI/Verify failures, ADW pending runtime/application, G4/G5/G11, full publication and human/main gates are not converted into passes. There is no infeasibility finding, operator-approved deferral, reduced charter, portfolio green, physical device completion or native acceptance.

<!-- END SOURCE137-EXACT-E2_DKM_INTERACTING_RETARDED_SPECTRAL_RESPONSE-REVIEW -->
