# Original L1 full-action source and continuum prerequisites — construction

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** All twelve sections: literal original action local-covariance residual, exact source identities and controlled smooth classical Wilson/midpoint/frame/action/source limits and errors.

**Original physical obligations.** No family-wide physical no-go or quantum continuum. Additional covariant C is not an approved replacement/equivalent regulator, and D3366/rank/source coefficients do not transfer. Original physical B3/window, modes/matter and transport remain owed.

The construction author is publication_njl_target_review; the complete independent scientific review is by publication_root7_current_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE](L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE.md), [fixed source model](source-models/L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE.md), [full independent review](reviews/L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE-CONSTRUCTION -->
# Original full-action gauge/source bridge and controlled classical continuum conventions

AUTHOR mathematical construction, not independent acceptance. Fixed SOURCE_MODEL c24761f9fcc7299cb0fbc1cf150ff7b1f8d465f3986f21dd51601a6d3985bbed contains the ENTIRE original model829c0c49 byte-exactly. The literal regulator L remains the original scientific obligation. The separately fixed path regulator C is an ADDITIONAL branch. No old L coefficients, D3366, ranks, phase, or physical normalization are transferred to C. All reference/computation plans below are DATA UNRUN.

## 1. Original arbitrary-volume algebra and actual primary conventions

Let Λ=product Z/L_mu, every L_mu positive, V=product L_mu, spacing a>0. Retain all independent links, including links with coincident endpoints, eight Grassmann generators/site, lexicographic site order and the original local top bar1 bar2 bar3 bar4 psi1 psi2 psi3 psi4 ->1. Retain arbitrary finite complex g1,g2, plus the real physical slice without assuming positivity. The original four blocks are ADDED before any coincident-site simplification:

(1) T_xmu^A=(bar_x gamma_A U_xmu† psi_(x+mu) - bar_(x+mu) U_xmu gamma_A psi_x - bar_x gamma_A U_(x-mu),mu psi_(x-mu) + bar_(x-mu) U_(x-mu),mu† gamma_A psi_x)/4.

All T are even Grassmann polynomials, so commute with one another. Write E_xmu=sum_A gamma_A T_xmu^A and G_xmunu=sum_A T_xmu^A T_xnu^A. Gamma_j has upper-right -i sigma_j and lower-left i sigma_j, gamma_4 has offdiagonal I, gamma_5=diag(I,-I)=gamma_1 gamma_2 gamma_3 gamma_4, epsilon_1234=+1. No gamma/link reorder is implicit.

(2) P_L(x;k,l)=U_xk U_(x+k),l U_(x+l),k† U_xl†,
S4_x=epsilon_ABCD T_x1^A T_x2^B T_x3^C T_x4^D,
S2L_x=(1/4) sum_(k,l,mu,nu) epsilon^(klmunu) Tr[P_L E_xmu E_xnu gamma_5],
S_L=g1 sum_x S4_x+g2 sum_x S2L_x.

The exponent is +S, with the original 1/4, all ordered world-index tuples, and all internal indices. Define Q(J,H)=sum_(xmuA) J_xmuA T_xmu^A+sum_(x,mu<=nu) H_xmunu G_xmunu. There are 16V+10V source coordinates; every metric offdiagonal is counted ONCE. I denotes the normalized independent Spin(4) Haar integrals followed by the fixed Berezin functional. Z_L(J,H)=I exp(S_L+Q) is a finite polynomial, not a positive Gibbs trace. Normalized expectations/logarithmic derivatives are used only where the actual Z is nonzero; singular points require unnormalized coefficients/cofactors, not division or a positive-density replacement. G is not auxiliary h. The earlier exact auxiliary identity and its signed/complex Hermite W remain unchanged: no source-dependent shift/discarding of W is used here.

Actual primary reading: [arXiv1109.0091v1 official HTML](https://arxiv.org/html/1109.0091v1) V.1–V.6 and the carrying [official PDF text](https://arxiv.org/pdf/1109.0091v1) specify these same link/plaquette/frame/action orders. HTML equations26/30/32/33–34 correspond to the carrying PDF equations17/21/23/24–25. This is a statement about the selected actual text passages, not whole-document byte equivalence or inspected PDF pixels. No new full text was saved. The source's asserted continuum/local gauge interpretation does not replace the direct checks below.

## 2. Full action transformation, including its literal residual

Fix column psi'_x=V_x psi_x, bar'_x=bar_x V_x† and U'_xmu=V_(x+mu) U_xmu V_x†. Define R_x by V_x† gamma_A V_x=sum_B R_x,AB gamma_B. Clifford invariance and continuity on Spin(4) give real R_x in SO(4), and V commutes with gamma_5. In EACH of the four blocks of (1), the neighboring V factors cancel and leave V_x† gamma_A V_x. Therefore

(3) T'_xmu^A=R_x,AB T_xmu^B, E'_xmu=V_x E_xmu V_x†, G'_xmunu=G_xmunu, S4'_x=S4_x.

This is valid also on small tori because it is a blockwise identity before collecting coincidences. The literal plaquette transforms into the following actual product, which must not be replaced by a closed transport:

P_L(gU)=(V_(x+k) U_xk V_x†)(V_(x+k+l) U_(x+k),l V_(x+k)†)
         (V_(x+l) U_(x+l),k† V_(x+k+l)†)(V_x U_xl† V_(x+l)†).

Cyclic trace and (3) give the ENTIRE summed-action difference

(4) Delta_g S_L=(g2/4) sum_(x,k,l,mu,nu) epsilon^(klmunu)
 Tr[{V_x† P_L(gU) V_x-P_L(U)} E_xmu E_xnu gamma_5].

No ordered term, coincident block, site, S4 term or source is dropped. For V_x(t)=exp(t X_x), X in spin(4), delta U=X_end U-U X_start and delta U†=X_start U†-U† X_end. Set r_X P_L=delta P_L-[X_x,P_L]. Then

(5) delta_X S_L=(g2/4) sum epsilon Tr[(r_X P_L) E_mu E_nu gamma_5].

A CONSTANT V does conjugate the full literal plaquette, so global Spin(4) is an exact symmetry of L. Equations(4)–(5), not a local-gauge assertion or merely a plaquette mismatch, govern local transformations.

## 3. A nonzero coefficient of the FULL original action

Here is an explicit member of the original family proving that the local residual need not vanish as a Grassmann polynomial. Take every L_mu>=5, x=0, y=x+e3, z=x+e4. Put every independent link equal to I except U_(x+e1),2=Y=diag(i sigma_1,I_R). Set V_x=diag(exp(i pi sigma_3/4),I_R), all other V=I. These are legitimate link/gauge evaluations; the general Haar integral and full coupling family are not replaced by this control.

Extract the ordered quartic monomial M=bar_x3 bar_x4 psi_y1 psi_z1. This local displayed order is used for both sides. Converting to the original global lexicographic Grassmann order multiplies both coefficients by the SAME permutation sign; the nonzero difference is unchanged in substance. There are no missing S4 contributions: S4 has degree8. For any S2 base b, both bars at x require b=x (the distinct world directions cannot both have x=b+/-mu=b+/-nu on L_mu>=5). At base x only the first forward block of T_3 and T_4 can supply these psi endpoints. Thus the full sum reduces FOR THIS coefficient only to the curvature pair12/21 and frame pair34/43; no other site or ordered term can cancel it.

At x, P12=Y and P21=Y†; all other plaquettes are I. Combining BOTH world orders with the action's 1/4 gives sum_CD K_CD T_3^C T_4^D, where K_CD=(1/2)Tr[(Y-Y†) gamma_C gamma_D gamma_5]. Its nonzero antisymmetric entries are K14=2, K41=-2, K23=-2, K32=2. The relevant gamma columns, with bar rows3/4 and psi column1, are gamma1:(0,i), gamma2:(0,-1), gamma3:(i,0), gamma4:(1,0). Moving psi_y past the second bar yields

[M](T_3^C T_4^D)=[-gamma_C,31 gamma_D,41+gamma_C,41 gamma_D,31]/16.

For (C,D)=(1,4),(4,1),(2,3),(3,2), the numerators are i,-i,-i,i. Their weighted sum is 8i; hence [M]S_L=i g2/2. After the ACTUAL gauge transformation P12'=V_x† Y V_x. Removing the frame conjugations leaves V_x† P12' V_x=(V_x†)^2 Y V_x^2=diag(-i sigma_1,I_R). Every K above changes sign. Consequently

(6) [M]S_L=i g2/2, [M]S_L(g fields)=-i g2/2, [M]Delta_g S_L=-i g2 !=0 for g2!=0.

This proves a failure of universal pointwise local covariance of the ENTIRE selected literal action, with arbitrary g1 retained. It does not assert failure on every small torus, a nonzero integral of every residual, a quantum anomaly, absence of a physical completion, or physical infeasibility. At g2=0 this particular residual vanishes and S4 is invariant. A nonzero polynomial can integrate to zero; source Ward residuals must remain even where their particular integral vanishes.

## 4. Exact measure, joint sources and residual Ward identities

Each SU(2) block has determinant1, so the independent Grassmann change psi->Vpsi, bar->bar V† has Jacobian det(V)^(-1)det(V†)^(-1)=1/site. Independent link Haar measure is invariant under the endpoint left/right multiplications, including self-links. Fixed Berezin orientation is retained. No positivity assumption is involved.

Write J^g_xmu=R_x^T J_xmu and leave H unchanged. The FULL change-of-variables identity is

(7) Z_L(J,H)=I exp{S_L+Delta_g S_L+Q(J^g,H)}.

If Z_L!=0, this is <exp[Delta_g S_L+sum(J^g-J)T]>_(J,H)=1. Let theta_x=dR_x/dt|0, an antisymmetric matrix, and W_X=sum_(xmuAB) J_xmuA theta_x,AB partial/partial J_xmuB. Differentiating the finite polynomial identity gives

(8) W_X Z_L=-I[(delta_X S_L) exp(S_L+Q)],
I[(delta_X O+O delta_X S_L+O sum J delta_X T) exp(S_L+Q)]=0,
W_X partial_(H_I) log Z_L=-<G_I;delta_X S_L>_(J,H).

The last formula uses connected covariance, not a positive probabilistic one; it holds locally on a nonzero-Z domain. More general derivatives retain all contact/source terms by differentiating (7), not by replacing it with zero. At J=0 the first identity requires the particular integrated residual to vanish; that does not negate (6). Constant X has delta S=0 and gives the usual global Ward identity. Neither exact Haar/Berezin measure nor invariant G alone licenses local Elitzur arguments for literal L.

Once-pair H derivatives insert G_mu nu exactly once. For a full symmetric source written sum_mu nu K_mu nu G_mu nu, K_diag=H_diag and K_off=H_off/2; the derivative with respect to an independent symmetric K_off inserts 2G_off. Responses transform with a factor2 per such offdiagonal insertion. No tensor projector, physical metric or gauge rank follows from a coordinate name.

## 5. Additional prospectively fixed closed-path regulator C

The saved path x->x+k->x+k+l->x+l->x, with columns and rightmost-first composition, uniquely yields

(9) P_C=U_xl† U_(x+l),k† U_(x+k),l U_xk.

The endpoint factors telescope, giving P_C(gU)=V_x P_C(U)V_x†. Keep the SAME T blocks, action forms, g1,g2, all sources and measures. Then S_C=g1 sum S4+g2 sum S2C is exactly locally invariant on every original finite torus, and

(10) Z_C(J,H)=Z_C(R^T J,H), W_X Z_C=0.

This constructs a covariant ADDITIONAL regulator, not an operator-approved replacement. The exact relation is
S_C-S_L=(g2/4)sum epsilon Tr[(P_C-P_L)E_mu E_nu gamma_5].
The actions are not identical under the identity variables: otherwise the invariant C action would make L invariant, contradicting (6). No complete source-preserving change-of-variables equivalence is proved or assumed. Inverting U under Haar also changes all four T blocks and their source couplings; Haar invariance alone is insufficient. D3366, the original one-site joint rank10, metric means and finite Hessians belong to L and are NOT asserted for C. New C partition functions/nonzero domains/coefficient/rank computations remain owed.

## 6. What exact Ward identities do and do not constrain

For C at J=0, on any actual nonzero Z_C(0,H) domain, local Spin(4) averaging gives <T_xmu^A>=0 and <T_xmu^A G_y rho sigma>=0. For x!=y it also gives the undressed <T_xmu^A T_ynu^B>=0, because the vector at either site averages to zero independently. At one site, the internal two-vector tensor is proportional to delta_AB with an unconstrained world-index coefficient. These are signed finite-functional identities, not positive-state, phase, or graviton statements. They give no value/sign/rank of the G response. A transport-dressed separated T correlator is a different operator.

For L only the global internal isotropy follows from the action symmetry; no separated-site zero follows from local gauge averaging. Independently, at J=0 the action and H terms have degrees0 mod4 while a single T or TG has degree2 mod4; since the top Berezin degree is8V, those odd-in-T observables vanish by saturation in BOTH branches. A single G and TT have degree0 mod4 and are not forced to vanish by that argument. The accepted special L one-/two-site cancellations remain their own results.

For C write m=partial_J logZ and C_JJ=partial_J partial_J logZ, v_B=sum_A J_A theta_AB. Equation(10) implies v·m=0 and

(11) C_JJ v=-(partial_J v)^T m.

Only where m=0 does a nonzero gauge-orbit vector v give a null Hessian direction. At J=0, v=0 makes this identity trivial, not a rank count. H is internally invariant and does not acquire gauge zero modes just because it is called a metric. For L the same differentiation includes the explicit residual insertions of (8). No physical constrained spin2 subspace or positive Hessian is derived here.

## 7. Exact Wilson links, midpoint error, and frame approximation

The fixed smooth classical embedding is SEPARATE from the independent-generator quantum Haar theory. Use a fixed finite Grassmann algebra with coefficient l1 norm, summed over spinor components for u_j,b_j bounds. Matrix norms below are Euclidean operator norms; induced component l1/infinity norms are <=2 times the operator norm in dimension4. Gamma matrices are signed permutations, with induced norms1. Let M_j bound every order-j coordinate partial of A on the compact path neighbourhood. The fixed MODEL assumes C3 A and C4 spinors; the displayed estimates actually need only C2 A and third spinor derivatives. Thus the C3 gauge maps of the MODEL, whose transformed A is C2, suffice as well. All bounds are symbolic finite actual suprema on that neighbourhood, 0<a<=a_*; no preferred background/state is selected.

Exact column transport obeys dU/ds=-A_mu(x+s)U, U(0)=I. Anti-Hermiticity makes U unitary. For A'=V A V†-(partial V)V†, differentiation proves U'=V_end U V_start† exactly. The midpoint matrix M=exp[-a A_mu(x+a/2)] is a DISTINCT prescribed link. Dyson expansion through degree2, Taylor's midpoint cancellation, and the absolute higher-order tails give

(12) ||U-M||_op<=a^3 B_mid,
B_mid=M2/24+M0 M1/2+M0^3 exp(a_* M0)/3.

Indeed the first-integral error is <=a^3 M2/24; replacing the ordered quadratic integrand by its midpoint value costs <=a^3 M0 M1/2, since each argument differs from the midpoint by at most a/2. The Dyson and exponential tails each cost <=a^3 M0^3 exp(a_* M0)/6. Inverse links have the same bound. The midpoint gauge defect is bounded by a^3[B_mid(A')+B_mid(A)], with the ACTUAL transformed derivative bounds; it is not exactly covariant at finite a.

For a positive or negative signed s let p(s)=U(s)† psi(x+s), b(s)=bar(x+s)U(s), with the corresponding edge ODE. Then p'=U†D psi and b'=(bar left-D)U, D=partial+A and bar left-D=partial bar-bar A. The literal four T blocks give the central difference
T/a={bar gamma[p(a)-p(-a)]-[b(a)-b(-a)]gamma psi}/(4a).
Hence

(13) e_mu^A=(1/2)[bar gamma_A D_mu psi-(bar left-D_mu)gamma_A psi],
||T/a-e||_1<=a^2 C_T.

Here is an explicit uniform C_T. Let u_j,b_j be the component-l1 bounds for every jth coordinate derivative of psi,bar through3 and set a_j=2M_j. Define
D(u)=u3+3a0 u2+3(a1+a0^2)u1+(a2+3a0 a1+a0^3)u0,
C_T^W=[b0 D(u)+u0 D(b)]/6,
C_T^mid=C_T^W+2B_mid b0 u0.
Use the matching C_T for Wilson or midpoint links. The derivative identity underlying the bound is
D_mu^3 psi=partial_mu^3 psi+3A partial_mu^2 psi+3(partial_mu A+A^2)partial_mu psi
 +(partial_mu^2 A+(partial_mu A)A+2A(partial_mu A)+A^3)psi.
The row version has the corresponding reversed/sign-changed products and the same norm bound. The central difference error is a^2/12 times the third derivatives of each transported field; their induced matrix norm bound2 gives C_T^W. Four midpoint block errors, each <=2a^3 B_mid b0u0 before the 1/4, give the stated additional constant after division by a.

For subsequent estimates set
 e0=[b0(u1+a0u0)+(b1+a0b0)u0]/2, B_e=e0+a_*^2 C_T,
 e1=[b1(u1+a0u0)+b0(u2+a1u0+a0u1)+(b2+a1b0+a0b1)u0+(b1+a0b0)u1]/2.
Then ||e||_1<=e0, ||T/a||_1<=B_e, and every first coordinate derivative of e is <=e1. The Grassmann coefficient l1 norm is submultiplicative; no sampling/positivity is used.

## 8. Actual plaquette orientation and an explicit controlled remainder

For an edge at x+a v in direction mu, with v=0 or one unit direction, Taylor/Dyson expansion gives

(14) U_(x+a v),mu=I-a A_mu(x)+a^2{A_mu(x)^2/2-[v·partial+(1/2)partial_mu]A_mu(x)}+R,
||R||_op<=a^3 E3,
E3=2M2+2M0M1+M0^3 exp(a_*M0)/6.

The inverse has +aA and the opposite derivative sign, with the same A^2/2 and error bound. The midpoint link has the same quadratic polynomial and this same generous bound. For (14), the first-integral Taylor remainder uses |v+t e_mu|_1<=2 and costs <=2a^3 M2. The quadratic-product error costs <=2a^3 M0M1; all Dyson terms of order>=3 cost <=a^3 M0^3 exp(a_* M0)/6. Taking adjoints proves the inverse statement without changing its norm.

Multiplying the FOUR ordered quadratic polynomials, the literal first-order factors are (-A_k,-A_l,+A_k,+A_l). The derivative contribution is partial_l A_k-partial_k A_l. Reversing the positions to C changes the commutator sign, not that derivative contribution. Therefore

(15) P_L=I+a^2 F_L+R_L, F_L=-partial_k A_l+partial_l A_k+[A_k,A_l],
P_C=I-a^2 F_++R_C, F_+=partial_k A_l-partial_l A_k+[A_k,A_l].

Both errors obey ||R_L/C||_op<=a^3 C_P with the explicit constants
B2=M0^2/2+2M1, B_Q=1+a_* M0+a_*^2 B2,
C_P=4E3 B_Q^3+12M0B2+6a_*B2^2+4(M0+a_*B2)^3+a_*(M0+a_*B2)^4.
To see all terms, replace four exact unitary factors by their quadratic polynomials: telescoping costs <=4a^3 E3 B_Q^3. The higher-degree part of the polynomial product has the pair terms12a^3 M0B2+6a^4B2^2, the four triples <=4a^3(M0+a_*B2)^3 and the quadruple <=a^4(M0+a_*B2)^4. Thus (15) is a bound, not a formal O-symbol.

Two independent manual controls fix the orientation. For constant noncommuting A_k=X,A_l=Y, P_L=e^(-aX)e^(-aY)e^(aX)e^(aY) has +a^2[X,Y], whereas P_C has -a^2[X,Y]. For commuting A_k=0,A_l=x_k Z, BOTH products equal exp(-a^2 Z) on this plaquette, with NEGATIVE derivative curvature. A source-printed +F sign must not override these fixed transport/link orders. F_L is not the covariant curvature of the same generic A; (15) does not label a whole physical theory impossible.

## 9. Spin normalization, action densities and volume errors

Write the SAME connection convention as

(16) A_mu=(1/8)omega_mu^AB[gamma_A,gamma_B], omega^AB=-omega^BA.

Clifford commutators give a Lie-algebra homomorphism, so F_+=(1/8)F_omega^AB[gamma_A,gamma_B], F_omega=d omega+omega wedge omega. Direct Clifford multiplication gives
Tr([gamma_A,gamma_B]gamma_C gamma_D gamma_5)=8 epsilon_ABCD,
Tr(F_+ gamma_C gamma_D gamma_5)=F_omega^AB epsilon_ABCD.
The identity-plaquette trace Tr(gamma_C gamma_D gamma_5) is ZERO, not an unremoved divergent term. Define
f_EHC=(1/4)epsilon^(klmunu)epsilon_ABCD F_omega,kl^AB e_mu^C e_nu^D.
Then the additional branch with its SAME original g2 has S2C leading density -f_EHC, while S4 has leading density det(e):

(17) S_C -> integral d^4x [g1 det(e)-g2 f_EHC] IN THE DECLARED SMOOTH CLASSICAL EMBEDDING ONLY.

The original L has leading density (1/4)epsilon Tr(F_L gamma_C gamma_D gamma_5)e_mu^C e_nu^D instead. No silent g2 flip or claimed physical regulator equivalence repairs that distinction. Equation(17) is not a determination of Newton's constant, Lorentzian sign, physical frame normalization, quantum limit or phase.

Here are actual coefficient-norm errors. Put F0=2M1+2M0^2, F1=2M2+4M0M1. Both curvature norms are <=F0; their first derivatives are <=F1. At each lattice cell,

(18) ||S4_x-a^4 det(e(x))||_1<=96a^6 C_T B_e^3,
||S2C_x+a^4 f_EHC(x)||_1<=384a^5 C_P B_e^2+768a^6 F0 C_T B_e.

For S4 there are24 internal permutations and four telescoping frame replacements. For S2 the24 world permutations,16 internal pairs, trace bound4 and original1/4 give384. Two frame replacements give the further factor2. L has the same absolute error bound against ITS OWN F_L leading density. Set
L4=96e1 e0^3,
L2=384(F1 e0^2+2F0 e1 e0).
These bound each coordinate derivative of the corresponding density. In a fixed periodic rectangular physical box (a divides all periods), or a fixed union of interior cells with every path contained, let V_phys=Va^4. The cell Riemann error is <=4a V_phys times a coordinate derivative bound. Consequently

(19) ||S_C-integral(g1 det(e)-g2 f_EHC)||_1
 <=V_phys{96|g1|a^2 C_T B_e^3+|g2|[384a C_P B_e^2+768a^2 F0 C_T B_e]
          +4a[|g1|L4+|g2|L2]}.

There is no boundary term hidden by wrapping a nonperiodic field; the stated periodic/interior conditions matter. Couplings are fixed or supplied with their ACTUAL a-dependent bounds; arbitrary running couplings do not automatically preserve convergence. Norm units are consistent: A carries inverse length, M_j length^(-j-1), F inverse length squared and T/a carries the declared derivative/field units. With dimensionless coefficient spinors e has inverse length, so det(e) and F e e have inverse length fourth power. Matching a physical dimensionless coframe requires its own actual field/length normalization and physical coupling map. No such scale is fitted here.

These are controlled classical coefficient statements. Independent lattice generators at every site and full Haar link integration are not identified with one fixed smooth finite Grassmann algebra. No uniform quantum domination, thermodynamic limit, normalized nonzero-Z limit, clustering, ordered state, Lorentzian continuation or gravitational pole follows by interchanging them with (19).

## 10. Source scaling, physical integrated response and remaining matching

For the declared embedding, a linear smooth coframe source integral a^4 j_T e corresponds to J=a^3 j_T. For the conditional operator candidate Q_phys=Z_Q(a)G/a^2, a physical source integral a^4 j_Q Q_phys corresponds to H=a^2 Z_Q(a)j_Q. Z_Q is an UNKNOWN operator/units matching factor, not a choice to obtain a window. Once-pair versus full-symmetric offdiagonal factors remain those in section4.

Let jT0,jT1,jQ0,jQ1 bound source values/first derivatives. Frame approximation errors in the full exponent are <=16V a^6 jT0 C_T and <=80V a^6 |Z_Q|jQ0 C_T B_e, respectively. The corresponding derivative bounds of the continuum source densities are16(jT1 e0+jT0 e1) and40|Z_Q|(jQ1 e0^2+2jQ0 e0 e1); add 4a V_phys times these to bound their Riemann errors. These bounds assume the actual source/Z_Q growth domain; an unbounded a-dependent factor needs its own renormalization estimate.

If an actual translation-invariant physical state, operator matching, tensor projection and contact subtraction are separately established, the connected integrated four-dimensional susceptibility in the once-pair basis would be

(20) chi_IJ(p)=Z_Q(a)^2 sum_r exp(-i p·a r) <G_0I;G_rJ>_physical,matched

with the stated offdiagonal weights on each insertion. The a^4 volume element cancels the two factors a^(-2). Equivalently a uniform physical-source second derivative of log Z divided by Va^4 gives the zero-momentum density response. Total response, response density and average-over-volume response are distinct. Equation(20) is a CONDITIONAL normalization identity, not a calculated physical chi, Kubo dynamics, quantum analytic continuation or a state-existence result. At nontranslation-invariant sources one must keep the full x,y kernel instead of this shortcut.

The full52-coordinate coupled two-site tensor, arbitrary-volume kernel, zero-source physical ordered state, source/operator mixing and contact subtraction, physical positivity/continuation, microscopic graviton/matter dynamics and actual g1,g2->u_g,c_D,gamma_star matching remain BUILD. The old scalar regulated bubble/native VestigialSusceptibility algebra is not this physical tensor. No scalar result, chosen Z_Q, selected eigenchannel, old D3366, local Ward zero or changed-regulator rank proves B3's dimensionless [0.1,10] AS A RESULT. The three L1 obligations remain separate: susceptibility/window; microscopic physical tensor dynamics; physical transport/frequency matching. The ONE separate shared D1/E1/E2 dispersive-law obligation and all21/B1–B8/D12 goals remain intact.

## 11. Independent reference, precision, populations and poisons — DATA UNRUN

Nothing below was executed, collected, imported, evaluated by software or measured. It is a concrete candidate plan for a separately allocated actual reference/native task, not a new runtime grant.

* Full-action coefficient(6): use exact4x4 gamma/Spin matrices over Q(i,sqrt(2)), including V=(I+i sigma3)/sqrt(2) in the left block. The fixed control torus is5^4 (625 bases,2500 independent links), one Y link, and the four selected Grassmann generators. A formal Grassmann quotient/extractor may remove all other generators solely to extract M after all original T/action terms are generated; it is NOT a physical truncation or a replacement family. Record both the displayed local M order and the actual global permutation sign. Audit all625 bases and all24 ordered world tuples before justified locality pruning. All g1/g2 terms stay symbolic; S4's absence at degree4 is proved, not tuned. Two independent wedge extractors with different canonicalization order must produce i g2/2,-i g2/2 and -i g2, not normalize outputs to those values.
* Full C covariance and L residual: exact symbolic endpoint matrices/source transforms and all four T blocks; independently check (4),(7),(8),(9),(10), both measure Jacobians and once-pair insertions on original small tori including coincidences. Carry old one-/two-site L regression populations separately; no C D3366/rank expectation. A residual may have zero unsourced integral: choose a genuinely nonzero source coefficient before declaring the residual-sensitive Ward poison detectable. Preserve failed attempts if that coefficient is not yet constructed.
* Smooth controls: independently bound an interval Wilson ODE and midpoint exponential, including their own numerical approximation errors; compare a,a/2,a/4 with generic spinor/source derivative enclosures satisfying the FIXED model, the constant-noncommuting and Abelian-linear controls of section8, and a nonconstant smooth gauge map with its actual transformed M_j. Check norms and absolute residual inequalities, not only fitted log-log slopes or a formal order. Generic tests must retain all field components and world directions. Use rational interval endpoints/explicit rounding certificates and report actual bit lengths, term counts, origins, full failed cases and memory/time. A prospective ceiling4GiB/2CPU-hours per bounded reference is a proposed refusal/resource cap only; actual cost UNKNOWN and no execution/admission authorization follows.
* Meaningful poisons: insert old literal order into C; omit an endpoint V; drop action1/4 or a T block; change gamma5/Berezin sign; omit Delta S in a residual-sensitive L source Ward coefficient; drop an offdiagonal factor2; flip either derivative or commutator sign in (15); assert exact midpoint covariance; import D3366 into C. Each must be checked against an independently generated polynomial/interval/operator predicate, not duplicate prose. Require actual red failure, exact original bytes/modes/nsmtime restoration, then actual green rerun with full channels/origins. Do not call restoration performed here. Preserve failures and original populations, never skip troublesome samples or weaken budgets to obtain green.

## 12. Disposition and scientific acceptance boundary

This author component supplies a full-action nonzero residual/control, exact residual source identities, an explicitly additional covariant finite regulator, and controlled smooth-link/frame/action/source comparisons with signs/constants/errors. All are new manual author proofs awaiting genuinely NONAUTHOR WHOLE scientific verification and lead intake, including the coefficient, all factor/count/sign/derivative bounds, physical domains, source normalization, and model-before-mathematics chronology.

Original L remains in the portfolio with its full physical obligation. The added C regulator requires its own physical matching/decision and coefficient/state analyses, not a silent replacement. No infeasibility, deferral, original-charter reduction, physical-window/dynamics completion, software/reference/native execution, source application, G4/G5/G11 green, main merge or human acceptance is asserted. All old process/ref/admin/raw-index failures remain immutable/unwaived. ROOT alone owns any later actual application/runtime/native/main allocation. The full original BUILD continues.

<!-- END SOURCE137-EXACT-L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE-CONSTRUCTION -->

<!-- BEGIN SOURCE137-EXACT-L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE-REPORT -->
# Author handback — original L1 action, sources and controlled continuum conventions

The new manual author component is complete and requires fresh genuinely nonauthor WHOLE scientific review. It is not physical B3 completion or source/runtime/native/main acceptance. The full coherent CONSTRUCTION has12 sections and20 numbered equation groups.

The main new result is a FULL-action local-covariance countercontrol for the literal original regulator: on every torus with L_mu>=5, the coefficient of bar_x3 bar_x4 psi_(x+3),1 psi_(x+4),1 changes from i g2/2 to -i g2/2 under the specified admissible local Spin(4) transformation. All other sites/ordered terms are excluded for this coefficient by their actual support; S4 has degree8. The residual is -i g2 for arbitrary g1 and nonzero g2, not merely a mismatched plaquette or an integrated/physical no-go. Exact summed residual and Haar/Berezin/source Ward identities retain this distinction.

The prospectively fixed additional closed-path regulator C is fully locally covariant, with the SAME original frame blocks/couplings/source forms. It is not installed as a replacement, proved fully source-equivalent, or assigned the old literal D3366/ranks. Its source Ward identities, local/global averaging distinctions and conditional Hessian constraints are derived without a positive measure or a new physical vacuum. Normalized formulae refuse actual zero Z.

The controlled smooth classical comparison derives exact Wilson versus midpoint error bounds, the frame central-difference bound, separate literal/C plaquette expansions and signs, explicit gamma/omega/epsilon/g2 normalization, per-cell and fixed-volume action/source bounds. With the fixed column transport convention the C insertion is I-a²F, so its mathematical EHC density carries -g2. No physical coupling/frame normalization is chosen to hide that sign. The classical embedding does not justify exchanging a->0 with independent Haar/Berezin integration, normalized/thermodynamic limits or state selection.

Physical source matching is constructed as a conditional units/volume relation, with UNKNOWN Z_Q and actual once-pair offdiagonal weights; it does not compute physical chi. Full52 tensor/spatial/arbitrary-volume response, state/positivity/continuation, dynamics/matter, coupling/contact/operator matching and B3[0.1,10] AS A RESULT remain BUILD. The three L1 obligations, separate ONE shared D1/E1/E2 law, all21/B1–B8/D12 goals and original physical target remain unchanged. No infeasibility, deferral or reduced scope is requested or inferred.

Chronology and evidence: original FIRST16:12:43.906654–16:12:44.306053 UTC rc0; genuine full initial coverage16:13:33.003655–16:13:34.574734; fixed MODEL16:14:22.380798–16:14:22.381074, SHA c24761f9fcc7299cb0fbc1cf150ff7b1f8d465f3986f21dd51601a6d3985bbed. Its entire original829c0c49 enclosure is byte-exact. Carrying primary HTML/PDF TEXT orders were personally read before new derivation; exact-hash predecessor full-note/review/source readings were honestly reused. First persisted new manual scratch16:19:22.526457 is after those events; the exact mental-start instant was not separately persisted and is not invented. First full construction save16:34:04.900348–16:34:04.900619. No MODEL rewrite, FIRST repeat, refresh or project/mathematical evaluation occurred.

One actual document-writing wrapper failed parsing before any CONSTRUCTION/REPORT write: mathematical triple-prime text prematurely closed a Python raw triple-single string. Its retained description is recorded in evidence; the raw original stderr and exact original start/end timestamp were not recovered after compaction and are UNKNOWN. The descriptive stderr field is reconstructed from the retained tool error, not a newly captured raw channel. The corrected wrapper only wrote text with a safe delimiter. No scientific result is credited to that failed wrapper. The original failures array was empty before this event; the separate actual_failures record retains the event rather than rewriting earlier history.

Initial protection covers49 unique bound references, P5186/N4869/M4906 tracked source paths plus ALL known7/64/3 dirty/untracked/historical paths, raw-index bytes/stat separately from semantic stage, HEAD/status/all-status/refs and bounded administration, and all seven initial absences. Terminal comparison and the ONE original FINAL are still pending at this pre-final report save and will be recorded explicitly below without refreshing the initial baseline. Shared changes, if any, will be reported as UNKNOWN rather than attributed or waived.

Required next step: fresh nonauthor whole scientific review of all12 sections, especially the full-action coefficient, residual Ward/source signs, C relation and non-transfer, complete constants and smooth/quantum/physical domains. The independent reference/precision/refinement/original-population/poison/exact-restoration protocol is DATA UNRUN, not a claimed test result. ROOT retains actual source/runtime/native/G4/G5/G11/main allocation; no grant was inferred from this author task.

Actual original FINAL and terminal preservation (later than the pre-final report above): the SAME original packet was checked ONCE at16:36:46.068034–16:36:46.462775 UTC, rc1, fresh=false, changed=[owned-files], stderr empty. This is retained as the literal reconciliation-required result; it is not a fresh/pass result or authorization to refresh. No reference/source difference was reported by the adapter.

Full terminal protection16:37:28.895650–16:37:30.260153 UTC found all49 bound reference full states and the original packet exact. All P5186/N4869/M4906 tracked-plus-known states, all7/64/3 known dirty/untracked/historical bytes, all three raw-index bytes AND full states, and all21 captured Git command channels/return codes remain exact. The three HEADs/status/semantic-stage/refs streams are unchanged. Two unique directories have timestamp-only movement: the shared P common gitdir (observed in all three repositories) and N's worktree gitdir. Those four observations retain UNKNOWN actor/cause and no waiver. No global quiescence is claimed and no reset, source or Git mutation was performed.

The seven allocated leaves are now terminal/frozen. Manual author completion is not independent scientific acceptance. Fresh whole nonauthor review and lead intake remain required.

<!-- END SOURCE137-EXACT-L1_ORIGINAL_ACTION_GAUGE_SOURCE_CONTINUUM_BRIDGE-REPORT -->
