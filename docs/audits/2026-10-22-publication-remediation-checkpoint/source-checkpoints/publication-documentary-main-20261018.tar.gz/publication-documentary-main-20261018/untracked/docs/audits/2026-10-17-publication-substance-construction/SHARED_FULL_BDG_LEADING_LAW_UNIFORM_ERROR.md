# Full GP/BdG leading law and uniform error — construction

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** All thirteen sections, fixed GP model, analytic root/minor/Gamma normalizations, leading coefficient, explicit zero-reaching infrared error and corrected two-sided Hermitian generated covariance/filter/Hz conventions. Scalar Planck comparison is a specified mathematical comparison.

**Original physical obligations.** Stationary whole-field spectral/state completeness, local equal-time CCR/noise and missing sectors, microscopic/target-platform validity and calibrated receiver/useful nonempty physical band remain owed. Original P1/S1/process failures unwaived.

The construction author is publication_main55_independent_review; the complete independent scientific review is by publication_njl_target_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR](SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md), [fixed source model](source-models/SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md), [full independent review](reviews/SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR-CONSTRUCTION -->
# SAME full logistic-c² GP/BdG r2: uniform leading law and correctly normalized Hermitian generated variance

AUTHOR MANUAL SCIENTIFIC CONSTRUCTION — fresh genuinely nonauthor WHOLE scientific review and lead intake required. No project/helper/model/mathsoftware/test/recipe/native/runtime execution; no production source or shared notebook mutation. This is the same original full dispersive GP/BdG model and channel problem, not the chiral reduction, a new profile or a fitted thermal/greybody law.

## 1. Model, actual ordering and what this construction proves

The NEW corrective author FIRST ran once16:27:03.824902–16:27:04.100168 UTC, rc0/freshtrue/changed[], separate stderr empty. Genuine initial capture16:28:21.810751–16:28:23.018166 covers ALL53 literal bindings/51 unique reference paths, full P/N/M tracked5186/4869/4906 and literal historical known7/64/3 plus actual extras, raw/semantic indexes/HEAD/status/refs/admin and EIGHT owned absences. Immutable initial-protection.json saved16:28:23.040243, SHA6072d1853dfd453ba8cca2319c2a18229db80f6399919b5f350ab95ffe005fb5. The specific historical primary infra.md MISSING state is present; clean porcelain was not used to infer it. Immediately afterward MODEL9aa2973847ad116c104c8548cfc3a4a26d3cffbd9d3d73237f9fa7e5602f8fbd saved16:28:23.044799–16:28:23.044978, BEFORE any new corrective mathematics, enclosing the ENTIRE original17c444c0 MODEL byte exactly, itself enclosing23d73a45. No model/initial baseline rewrite occurs.

The author STOPPED before mathematics for documentary lead preflight. Explicit ACK receipt2a9ee5bc dated16:29:48.382975 was personally read and recorded16:30:12.269665 BEFORE corrective proof. The ACK is manual-scope/protection coordination only, not scientific acceptance/source/runtime/native authority; its two actual directory timestamp differences remain UNKNOWN/unwaived. New corrective mathematics began after that recorded boundary; no exact mental-start instant is fabricated. All carrying full models, original817e20d9 proof/whole reviewdc9e1a42, root7 NEWdd92e430 entire13-section proof/report and whole reviewcf8c3e60/native definitions were personally read before this new proof and reused only at verified unchanged hashes.

The old leading-law r1 package was REQUIRES_CORRECTION: S1 omitted the negative-frequency contribution in its physical Hermitian generated variance bound; P1 omitted a known historical primary ABSENCE from its actual initial capture. Its six generated known paths really were protected in tracked, but its seventh was not. Both old artifacts and failures remain immutable/unwaived. This new author delivery corrects S1 prospectively and has its own complete initial protection; it cannot backdate or cure P1. Earlier model/definition/process and UNKNOWN ref/admin histories remain actual. Sections2–10 below preserve the ENTIRE original root/Gamma/minor/normalization/Theta/coefficient/uniform-error/Planck-comparison proofs byte exactly; section11 derives the coherent new observable convention and bound. Full fresh genuinely nonauthor WHOLE review of this r2 remains required; this author does not review or accept it.

Retain every m,rho0,L>0,0<c_l<v0<c_r and real mu, v=-v0,
 c²=c_l²+(c_r²-c_l²)/(1+exp(-x/L)),
 g=mc²/rho0, V=mu-mv0²/2-mc².
The exact stationary GP background, original field CCR, quantum pressure, coupled density/phase system, co-propagating sector, positive/negative-norm incoming/outgoing conventions and physical normalization are unchanged. Let a=hbar/(2m). All roots and amplitudes below are those of the full operator, with no weak-dispersion or thermal-state assumption.

The predecessor817e20d9/whole-reviewdc9e1a42/leadbedf71db supplies the full exact4F3 connection/canceled-minor formulas, proven physical inversion and channel threshold. It explicitly left a SMALL leading-law error toward zero unproved. Here we construct it, including a genuine explicit positive upper edge for each supplied parameter set and tolerance; no unknown exact-center error or supremum of unknown beta appears. We also derive the first finite-frequency coefficient, and a controlled scalar Planck-comparator error as a CONSEQUENCE, not an assumed state.

Stationary whole-field completeness/state, microscopic gas-to-GP/BdG validity and target device/calibrated useful-band matching remain distinct substantive BUILD unless actually proved. A model-specific interval can be extremely narrow and is not a claimed experimentally useful one.

## 2. Dimensionless roots and exact full-operator data

Use
 l=c_l/v0 in(0,1), s=c_r/v0>1, A=1-l², B=s²-1,
 b=v0 L/a, ell=b sqrt(A), r=b sqrt(B), nu=a omega/v0².
Here l,s are SOUND ratios; r is the positive right spatial scale. Spatial exponents below use different symbols R_i,S_j. All A,B,b,ell,r are strictly positive.

The exact homogeneous dispersion polynomial is
 Q_j(q,nu)=q^4+(s_j²-1)q²-2nu q-nu².                   (1)
Its original physical three-channel threshold is nu_* from predecessor(16): with
 B_l=1-20l²-8l^4, d_l=l²(1-l²)^3,
 nu_*={ [B_l+sqrt(B_l²+64d_l)]/32 }^(1/2)>0.
Retain the entire open0<nu<nu_* physical interval. We construct a smaller interval near its endpoint0, not alter that threshold or its channel population.

Let q_m,q_h be the left high negative/positive incoming roots with limits -sqrt(A),+sqrt(A). Right growing/decaying roots q_g,q_e have limits -i sqrt(B),+i sqrt(B). Acoustic roots are EXACTLY q=nu w, where
 nu² w^4+(s_j²-1)w²-2w-1=0.                            (2)
At nu=0 set
 w_p=-1/(1-l), w_d=-1/(1+l),
 w_u= 1/(s-1), w_D=-1/(s+1).                            (3)
Thus R_p=i b nu w_p(nu), R_d=i b nu w_d(nu),
R_m=i b q_m(nu), R_h=i b q_h(nu);
S_u=i b nu w_u(nu), S_D=i b nu w_D(nu),
S_g=i b q_g(nu), S_e=i b q_e(nu).
The letters w_p etc without argument in a CONSTANT below mean the explicit values(3), not unknown exact functions. The repeated zero acoustic roots are regularized by(2), not an assumed nonzero-frequency gap.

## 3. Explicit complex root discs and their analytic continuation THROUGH zero

The proof supplies actual constants; it does not assume root analyticity/gaps. Set
 d0=min(sqrt(A),sqrt(B)), H=max(sqrt(A),sqrt(B)), h=d0/8,
 eta_h=min(1,d0³ h/[8(H+h+1)]).

For a high root q0 in {+/-sqrt(A),+/-i sqrt(B)}, on |q-q0|=h,
 |Q_j(q,0)|=|q|² |q-q0||q+q0|
   >=(7/8)²(15/8)|q0|³ h >=d0³ h.
For |nu|<=eta_h the perturbation obeys
 |2nu q+nu²| <=eta_h[2(H+h)+1] <d0³ h/4.
Rouché therefore gives exactly ONE zero inside each disc, uniformly. The contour integral of q Q_q/Q divided by2pi i equals that zero and is analytic in nu; uniqueness makes it the desired branch. The discs are disjoint from the zero cluster and the opposite high root. No numerical root finder or chosen physical example is used.

For the acoustic quadratic at nu=0, same-side w-root separations are
 sigma_l=2l/A, sigma_r=2s/B.
Let
 wmin=min(|w_p|,|w_d|,|w_u|,|w_D|),
 c_w=min(|w_p-w_u|,|w_d-w_u|)>0,
 hw=min(1,wmin/8,sigma_l/8,sigma_r/8,c_w/8),
 W=max(|w_p|,|w_d|,|w_u|,|w_D|)+hw,
 eta_w=sqrt(l hw/(4W^4)).
On each circle |w-w0|=hw,
 |(s_j²-1)w²-2w-1|
   >=|s_j²-1|hw(sigma_j-hw) >=l hw,
while |nu²w^4|<=l hw/4 for |nu|<=eta_w. Again there is exactly one analytic root in each disc. Since(2) is even in nu and the chosen zero is unique, EVERY w_j(nu) is even.

Set the common positive radius
 eta=min(eta_h,eta_w,d0/(8W),nu_*/4).                     (4)
Then all high roots stay within h of their explicit q0, all w within hw of their explicit w0, and |nu w|<=d0/8. Thus these four branches exhaust each quartic at nonzero nu and agree by continuation with the original physical assignments. At real nu they have the correct real/conjugate symmetries. In particular on the left q_m remains negative; q_p,q_d are distinct and negative; q_u>0,q_D<0 on the right.

On |nu|<=eta/2 Cauchy's inequality gives
 Mh=2h/eta, Mw=2hw/eta,
 |q_high'|<=Mh, |w_j'|<=Mw,
 |q_acoustic'|<=W+hw.
Define M=max(Mh,W+hw), Q=H+h.                             (5)
The acoustic |q| bound from(4) is smaller than Q. More sharply, evenness gives w_j'(0)=0 and
 |w_j(nu)-w_j(0)|
    <=hw (|nu|/eta)^2/[1-(|nu|/eta)^2].
Every exponent derivative is <=b M and every exponent-difference derivative <=2b M. These are evaluated parameter constants, not inverse-root assumptions.

## 4. Collapse the actual minors, not separate divergent connection coordinates

Let M0=M((g,D),(p,d)) and M3=M((g,D,u),(p,d,m)) in the exact ordered minor formula of the predecessor. The physical beta is
 beta=(h_m/h_u) M3/M0,                                   (6)
with the original positive frequency-normalized p amplitudes. All nine original S entries/channels and their indefinite flux law remain; only this actual conversion coefficient is being expanded.

Cancel the selected/common Gamma products in M3/M0 BEFORE taking zero. The Vandermonde ratio supplies
 (R_p-R_m)(R_d-R_m)/[(S_g-S_u)(S_D-S_u)].
Using Gamma(1+z)=z Gamma(z) once on each factor yields the exact quotient
 R(nu):=M3/M0 =
 [ Gamma(1+R_m-R_h) Gamma(S_u-S_e)
   Gamma(R_p-S_u) Gamma(R_d-S_u)
   Gamma(1+S_g-R_m) Gamma(1+S_D-R_m) ]
 /
 [ Gamma(R_p-R_m) Gamma(R_d-R_m)
   Gamma(1+S_g-S_u) Gamma(1+S_D-S_u)
   Gamma(R_m-S_e) Gamma(1+S_u-R_h) ].                      (7)
The n=2 and n=3 minor orders, including the high negative incoming root, fix its sign. This is direct algebra from the FULL4F3 formula; no desired beta is inserted.

Two Gamma factors in(7) collapse like1/nu. Define the EXACT REGULARIZED amplitude Z(nu)=nu² R(nu). Shift also the two purely imaginary denominator arguments, giving
 Z(nu)= [(R_p-R_m)(R_d-R_m)]
         /[(ib)²(w_p(nu)-w_u(nu))(w_d(nu)-w_u(nu))]
   * [Gamma(1+R_m-R_h) Gamma(S_u-S_e)
      Gamma(1+R_p-S_u) Gamma(1+R_d-S_u)
      Gamma(1+S_g-R_m) Gamma(1+S_D-R_m)]
     /[Gamma(1+R_p-R_m) Gamma(1+R_d-R_m)
       Gamma(1+S_g-S_u) Gamma(1+S_D-S_u)
       Gamma(R_m-S_e) Gamma(1+S_u-R_h)].                  (8)
There is NO leftover nu^-1, nu^-2,0/0 or separately evaluated divergent connection entry in(8). Every Gamma argument at zero has real part >=c=min(1,r)>0. Explicitly numerator arguments are
 1-2i ell, r,1,1,1+r+i ell,1+i ell;
denominator arguments are
 1+i ell,1+i ell,1+r,1,r-i ell,1-i ell.
The elementary factors at zero are i ell,i ell and the nonzero w differences(3). This proves an actual analytic nonzero extension, not a named regularization assumption.

For all allowed L>0 this formulation is safe even when original right exponent differences are integers. Its Gamma arguments stay in a positive half-plane on the explicit disc below. The predecessor's physical canceled-minor subspace limit supplies the same scattering amplitude at such resonances; it is not necessary to evaluate divergent Frobenius rows or exclude resonant L.

## 5. Original physical flux normalization is regularized exactly

For real simple roots, the dispersion derivative gives Omega v_g=Q_physical,k/2. Hence the original normalized p amplitude has
 h_j²=a/[2rho0 k_j²|Q_physical,k(k_j)|].
All physical hbar, rho0, v_g and negative-norm signs remain. Because Q_l,q(q_m)<0 and Q_r,q(q_u)>0 near zero, their ratio is EXACTLY
 h_m²/h_u²=nu³ N(nu),
 N(nu)=w_u(nu)² D_u(nu)/[-q_m(nu)² D_m(nu)],
 D_u=4nu²w_u³+2B w_u-2,
 D_m=4q_m³-2A q_m-2nu.                                  (9)
N(0)=s/[(s-1)² A^(5/2)]>0.
Thus for every real positive frequency in our disc,
 nu |beta|²=N(nu)|Z(nu)|².                               (10)
The singular normalizations have canceled in the physically weighted observable. This is NOT an inverse for the full zero-frequency phase field, whose predecessor domain restriction remains.

We now explicitly keep the denominator nonzero. On |nu|<=eta/2 let
 Lu=8(eta/2)W³+[12(eta/2)²W²+2B]Mw,
 Lm=(12Q²+2A)M+2.
Then |D_u'|<=Lu, |D_m'|<=Lm, D_u(0)=2s and D_m(0)=-2A^(3/2). Define
 nu0=min(eta/2,c/(4bM),ell/(4bM),s/Lu,A^(3/2)/Lm)>0.     (11)
All listed denominators are positive; no zero-Lu convention is needed since B,Mw>0. For complex |nu|<=nu0, |D_u|>=s and |D_m|>=A^(3/2), |q_m|>=sqrt(A)-h, |w_u|>=w_u(0)-hw>0. Every Gamma argument in(8) has Re>=c/2, every elementary R_out-R_m has modulus>=ell/2, and w differences have modulus>=c_w-2hw>0. Also nu0<nu_*; the original physical threshold and all three propagating channels are respected.

## 6. Derive the actual leading scale independently

Put Pw=(w_p-w_u)(w_d-w_u)=(A+B)/[A(s-1)²]. Evaluating(8) at zero and canceling Gamma(r)/Gamma(1+r) gives
 Z0=ell²/[b² r Pw]
       *Gamma(1-2i ell)Gamma(1+r+i ell)
        /[Gamma(1+i ell)Gamma(r-i ell)Gamma(1-i ell)].     (12)
The sign/phase is immaterial for occupation but this complex formula fixes it. Recurrence, conjugation and Gamma reflection give
 |Gamma(1-2i ell)|²=2pi ell/sinh(2pi ell),
 |Gamma(1+i ell)Gamma(1-i ell)|²
      =[pi ell/sinh(pi ell)]²,
 |Gamma(1+r+i ell)/Gamma(r-i ell)|²=r²+ell².
Consequently
 |Z0|²=ell³(r²+ell²)tanh(pi ell)/(pi b^4 r² Pw²),
 Theta_nu:=N0|Z0|²
     =s A B tanh(pi ell)/[pi b(A+B)(s+1)²]>0.             (13)
The real frequency scale is Theta=(v0²/a)Theta_nu. Differentiating the unchanged physical profile at c=v0 gives
 kappa=(v0²/a) AB/[2b(A+B)], Gamma0=4s/(s+1)²,
 Theta=kappa Gamma0 tanh(pi ell)/(2pi).                   (14)
Here Gamma0 is the actual downstream zero-frequency transmission factor also fixed by the full connection/flux problem. We have DERIVED its appearance in the coefficient from(7)–(13); no Gamma0=1, target temperature or full-frequency thermal law was assumed.

An independent source/previous zero-mode check uses the right-decaying solution of the original coupled zero-frequency equations, not the singular p inverse. Its Abel integral and Gamma modulus reproduce(14), as detailed in the unchanged predecessor(34)–(39) and whole review. That exact prior result is a cross-check; the present proof through(8),(9),(12) independently evaluates the new regularized limit.

## 7. Explicit SMALL uniform remainder on a nonempty interval REACHING zero

Let Rg=1+2bQ, and
 Psi=1+2/c+Rg pi²/6.
For Re z>=c/2 and |z|<=Rg, the convergent digamma series
 psi(z)=-EulerGamma-1/z+sum_(n>=1) z/[n(n+z)]
has |psi|<=Psi, since |n+z|>=n and EulerGamma<1. No unknown special-function supremum is used.

On |nu|<=nu0, logarithmic differentiation of(8) and(9) gives the concrete constants
 C_N=2Mw/[w_u(0)-hw]+Lu/s+
                  2M/[sqrt(A)-h]+Lm/A^(3/2),
 C_Z=8bM/ell+4Mw/(c_w-2hw)+24bM Psi,
 C=C_N+2C_Z.                                             (15)
Explanation: two elementary exponent differences cost8bM/ell in total; two w differences cost4Mw/(c_w-2hw); twelve numerator/denominator Gamma factors each cost<=2bM Psi. The normalization derivative is precisely C_N. These bounds hold on the COMPLEX disc, not only the real physical curve.

Define Z#(nu)=conjugate(Z(conjugate(nu))), an analytic function on this symmetric disc, and
 G(nu)=N(nu)Z(nu)Z#(nu)/(N0|Z0|²).
All factors are analytic and NONZERO by(11), G(0)=1, and |G'/G|<=C. Its unique analytic logarithm with logG(0)=0 is the integral of G'/G in the simply connected disc. Along a radial segment |logG(nu)|<=C|nu|. On the real physical interval G=omega|beta|²/Theta>0. Therefore
 |omega|beta(omega)|²/Theta-1|
      <=exp(C nu)-1, 0<nu<=nu0.                          (16)
For ANY supplied tolerance eps>0 the explicit edge
 nu_eps=min(nu0, log(1+eps)/C),
 omega_eps=(v0²/a)nu_eps>0                              (17)
gives the uniform SMALL relative/energy-weighted error <=eps on0<omega<=omega_eps. This interval genuinely accumulates at zero. It has no exact-center mismatch or unproved gap/analyticity premise. All constants are algebraic, exponential/logarithmic or fixed universal pi in the original physical parameters; none uses unknown exact beta values. It can be conservatively tiny and is not experimental sensitivity/calibration.

In vacuum n_u=|beta|², so(16) also controls the outgoing-u occupation relative to Theta/omega and the generated quasiparticle ENERGY flux per angular frequency hbar omega n_u/(2pi) relative to hbar Theta/(2pi). It does not assert finite total infrared quasiparticle number: its integral still diverges logarithmically.

## 8. Actual first NONZERO finite-frequency coefficient, with controlled remainder

This can be computed, not left as an O term. Differentiate the actual quartics at zero. Acoustic evenness gives w_j'(0)=0. For high roots,
 q_m'(0)=q_h'(0)=1/A,
 q_g'(0)=q_e'(0)=-1/B.                                  (18)
In(9), D_u'(0)=0, D_m'(0)=8; hence N'(0)/N0=6/A^(3/2).

For(8), the two elementary R_out-R_m logs contribute -4/A^(3/2) to Re(Z'/Z); w-difference logs have zero derivative. The twelve Gamma logs reduce, using psi(1+z)-psi(z)=1/z, to
 Re(Gamma-log-derivative total)
    =-1/(B sqrt(A))-2b(1/A+1/B) Im psi(1+i ell).          (19)
To verify rather than hide cancellation: Gamma(1+R_m-R_h)'s argument derivative is zero; all arguments real at zero contribute purely imaginary derivatives; the r+i ell pair contributes b(1/A+1/B)Im[psi(1+r+i ell)-psi(r+i ell)]=-1/(B sqrt(A)); the remaining1+i ell coefficient is b(w_p+w_d-w_D-w_u)=-2b(1/A+1/B). This accounts for every factor.

For a complete audit of(19), the twelve argument derivatives divided by ib, in the exact numerator/denominator order of(8), are:
| side | arguments at zero | derivatives divided by ib |
|---|---|---|
| numerator |1-2iell; r;1;1;1+r+iell;1+iell |0; w_u+1/B; w_p-w_u; w_d-w_u; -1/B-1/A; w_D-1/A |
| denominator |1+iell;1+iell;1+r;1;r-iell;1-iell |w_p-1/A; w_d-1/A; -1/B-w_u; w_D-w_u;1/A+1/B;w_u-1/A |
All w in this table are the explicit real zero values(3). Multiplying by psi at each listed argument, subtracting the denominator row and taking the real part gives(19). This exposes every factor rather than relying on an unspecified automatic differentiation.

Conjugation plus digamma reflection gives
 Im psi(1+i ell)=[pi coth(pi ell)-1/ell]/2.
Combining twice(19) and the elementary logs with N'/N cancels the apparent inverse-ell rational term. The exact real derivative is
 G'(0)=-2pi b(A+B)coth(pi ell)/(AB)=-1/(2t0),
 t0:=AB tanh(pi ell)/[4pi b(A+B)]>0,
 Theta_nu=Gamma0 t0.                                    (20)
The coefficient is nonzero and negative for every allowed positive parameter set. No weak-dispersion limit or fitted coefficient was used.

Because |G|<=exp(Cnu0) on the complex disc, Cauchy bounds its Taylor coefficients. For real0<=nu<=nu0/2,
 |G(nu)-1+nu/(2t0)|<=C2 nu²,
 C2=2exp(Cnu0)/nu0².                                    (21)
This follows by summing the positive geometric bound on coefficients n>=2, not assuming another unproved derivative. Equivalently,
 |beta|²=Theta_nu/nu-Gamma0/2+E_beta(nu),
 |E_beta(nu)|<=Theta_nu C2 nu.                           (22)
Thus the FIRST finite occupation correction is exactly -Gamma0/2; it is not universal pi D²/6 and is not the profile smoothing correction.

## 9. A derived controlled scalar Planck COMPARISON, not full KMS

Define the comparison scalar P(nu)=Gamma0/[exp(nu/t0)-1]. This is a mathematical comparator with the independently derived t0, not an incoming thermal-state assumption. Put x=nu/t0. For0<x<=1, Taylor's integral remainder e^x-1=x+x²/2+R,0<=R<=e x³/6 gives
 |x/(e^x-1)-1+x/2|<=x²,
 x/(e^x-1)>=1/(e-1)>1/2.
Together with(21), for
 0<nu<=min(nu0/2,t0),
 | |beta|²/P(nu)-1 |
      <=2(C2+t0^-2)nu².                                 (23)
An explicit tolerance edge is therefore the additional minimum with
 sqrt[eps/(2(C2+t0^-2))].
This is uniform small relative error to this scalar Planck-shaped occupation on a nonempty interval toward zero. It is proved by the actual exact amplitude and its independently derived first coefficient, not by declaring finite-frequency equality. It neither establishes global KMS/Gibbs, all orders of the Planck law, incoming thermal preparation nor full-field stationary noise.

Every original input occupation/cross covariance remains in the unchanged3x3 signed transformation. For general input, n_u=|T_u,+|²N_++|beta|²(N_-+1)+|T_u,D|²N_D with the actual anomalous/cross terms for nondiagonal states. Vacuum was used only for the explicit generated-occupation interpretation. Arbitrary thermal/correlated inputs are NOT silently replaced; their infrared populations can change the leading observable and need their actual weighted-domain/error analysis.

## 10. Profile smoothing, physical temperature conventions and all-L controls

The exact model factor obeys
 1-tanh(pi ell)=2/[exp(2pi ell)+1]=:delta_profile.
Gamma0=4s/(s+1)² is nonunit for s>1 and is retained. Comparing to the unmodified greybody-weighted kappa/(2pi) law gives
 |omega|beta|²/[Gamma0 kappa/(2pi)]-1|
    <=delta_profile+tanh(pi ell)[exp(Cnu)-1].             (24)
For a fixed rough profile a tolerance less than delta_profile cannot hold uniformly toward zero for that UNMODIFIED scale: the limit already differs. This is a precise convention/profile countercontrol, not an infeasibility or deferral of the original device objective. The actualTheta theorem(16) works for ALL allowed L>0; L was not chosen to make its proof succeed.

With fixed asymptotes, ell D_H=Delta_l^(3/2)Delta_r/(2v0³Delta), D_H=kappa a/v0². Thus the smoothing deficit is beyond all positive powers as D_H->0 along this family. This agrees with the previous full profile result, and cannot justify the adopted entire quadratic phenomenological law or a universal nonzero D² coefficient. Full co/downstream physics has been retained; no quantified chiral reduction or hydrodynamic gas validity follows merely because the profile becomes smooth.

Theta and t0 are FREQUENCY scales. A temperature in kelvin is hbar(v0²/a)t0/k_B only under the stated Planck-comparison interpretation; a measured thermodynamic/KMS temperature is not inferred. The physical mu has stayed arbitrary in the exact GP background and cancels in the relative BdG equation, rather than being tuned to zero.

## 11. Physical density/current, full Hermitian filter conventions and IR domain

The original physical observables remain delta rho=2rho0 n and delta j=2rho0 v n+2a rho0 theta'. These are particle observables, NOT graphene electrical sigma_Q/current. Stationary whole-field completeness, a stationary incoming whole-field positive local-CCR state and identification with the full local physical noise remain BUILD. This section constructs only the actual homogeneous asymptotic outgoing-u SCATTERING COMPONENT and its generated diagonal covariance. Other channels, interference/evanescent tails, anomalous/correlated/nonvacuum inputs retain the complete predecessor formulas and their actual domains.

For the homogeneous right plane wave with the original delta-angular-frequency normalization,
    |d_u|²=(2rho0/v0)nu w_u(nu)²/D_u(nu),
    j_u/d_u=omega/k_u=v0/w_u(nu).                            (25)
Indeed d_u=-2rho0 k_u² h_u, h_u²=a/[2rho0 k_u²|Q_physical,k|], Q_physical,k=(v0³/a)nu D_u, and k_u=(v0/a)nu w_u. Substitution gives(25), independently checked against continuity. The coefficient d_u may carry its actual propagation/spatial phase; it is not an arbitrary desired transfer. For either density or current write that channel's complex mode coefficient as d(omega).

On each compact positive subthreshold band the incoming vacuum and the original signed3x3 map give b(omega)=a_u(omega),
    <b†(omega)b(omega')>=n_u(omega)delta(omega-omega'),
    <b(omega)b†(omega')>=(n_u(omega)+1)delta(omega-omega'),
    <b(omega)b(omega')>=0, n_u=|beta|².
The first identity follows by contracting the negative-norm incoming CREATION term with its adjoint in the incoming vacuum; the second uses the actual outgoing CCR, and the last follows because the incoming positive channels and negative partner are distinct independent vacuum modes. This is an actual positive band-state calculation, not a presumed full-field stationary vacuum or KMS theorem. Extend toward zero only on the weighted test domains below.

Define W(omega)=|d(omega)|² n_u(omega). Equations(10),(25) give
    W_rho=(2rho0/v0)[w_u²/D_u]Theta_nu G(nu),
    W_j=(2rho0 v0)[1/D_u]Theta_nu G(nu),                    (26)
with leading constants
    W_rho,0=rho0 Theta_nu/[v0 s(s-1)²],
    W_j,0=rho0 v0 Theta_nu/s.
These are EACH-SIDED NORMAL-ORDERED GENERATED spectral weights, not yet a two-sided-integrated variance or one-sided PSD. They are finite and strictly positive at zero although quasiparticle occupation diverges. Their units are time/length² for density and1/time for particle current. Actual real linear combinations of density/current/spatial channels use their summed complex coefficient d before taking its modulus; cross terms must not be replaced by a sum of separately squared coefficients.

Set C_rho=2Mw/[w_u(0)-hw]+Lu/s and C_j=Lu/s. The nonzero analytic prefactors prove
    |W_rho/W_rho,0-1|<=exp[(C+C_rho)nu]-1,
    |W_j/W_j,0-1|<=exp[(C+C_j)nu]-1.                        (27)
The corresponding logarithmic tolerance edge is explicit in addition to nu0, for every allowed parameter/tolerance. No requested observable coefficient is supplied by hand. Write D_W=C+C_weight, choosing the actual density or current weight.

For a cutoff E with0<E<=(v0²/a)nu0, define the Hermitian channel contribution
    X_E(t)=integral_0^E d omega/sqrt(2pi)
       [d(omega)b(omega)e^(-i omega t)
        +conjugate(d(omega))b†(omega)e^(i omega t)].         (28)
This is a scattering-sector operator-valued distribution on its stated tests, not the full local field. The same low-frequency expressions can be obtained by first integrating from a positive lower cutoff and then taking its limit on this weighted test algebra. We retain BOTH frequency sides of this Hermitian operator.

Using S^>(Omega)=integral_R dt e^(i Omega t)<X_E(t)X_E(0)>, direct contraction for0<omega<E gives
    S^>(+omega)=|d|²(n_u+1), S^>(-omega)=|d|² n_u,
    S_sym(+omega)=S_sym(-omega)=|d|²(n_u+1/2),
    Delta S^>(+omega)=Delta S^>(-omega)
      =Delta S_sym(+omega)=Delta S_sym(-omega)=W(omega).    (29)
Here Delta subtracts the OUTGOING-u vacuum covariance (n_u=0) at the same mode normalization. Equivalently use normal ordering with respect to b,b†. The full symmetrized quantum noise also includes |d|²/2 on each side. “Generated” does not mean dropping this background is a full experimental subtraction; that requires the actual receiver/preparation/calibration bridge. No thermal coth identity is used. The spectral commutator S^>(+omega)-S^>(-omega)=|d|² is independent of n_u as required by the outgoing CCR.

Real AND complex finite-time filters are distinguished explicitly. Take f,g integrable compactly supported time weights (or a justified weighted test completion), define fhat(Omega)=integral_R f(t)e^(-i Omega t)dt and X_f=integral_R f(t)X_E(t)dt. Then X_f†=X_(conjugate f), not generally X_f. Put f_+=fhat(omega), f_-=fhat(-omega), and similarly g. With the actual zero mean, direct multiplication gives
    <X_f† X_g>=integral_0^E |d|²
        [n_u conjugate(f_+)g_+ +(n_u+1)conjugate(f_-)g_-]
                                                 d omega/(2pi),
    <X_g X_f†>=integral_0^E |d|²
        [(n_u+1)conjugate(f_+)g_+ +n_u conjugate(f_-)g_-]
                                                 d omega/(2pi),
    (1/2)<X_f†X_g+X_gX_f†>=integral_0^E |d|²(n_u+1/2)
        [conjugate(f_+)g_+ +conjugate(f_-)g_-]d omega/(2pi),
    Delta<X_f† X_g>=<:X_f†X_g:>_out
       =integral_0^E W[conjugate(f_+)g_+
                       +conjugate(f_-)g_-]d omega/(2pi).   (30)
The subtraction is the same in either ordered or symmetrized quadratic form. These equations also fix complex-filter adjoints and the state-independent commutator; setting f_- to zero without changing the physical observable would be wrong. The positive generated quadratic form follows from W>=0. For different physical channels form their actual coefficients/cross covariance before applying this contraction; the full predecessor anomalous/input cross channels are not assumed to vanish outside the specified incoming vacuum/u marginal.

For REAL f, f_-=conjugate(f_+), X_f is Hermitian and the physical generated diagonal variance is
    V_gen,f(E)=Delta<X_f²>
             =2 integral_0^E |fhat(omega)|² W(omega)
                                                   d omega/(2pi).
For a complex f, the nonnegative generated quadratic form is instead
    Delta<X_f†X_f>=integral_0^E W(|f_+|²+|f_-|²)d omega/(2pi).
Let A_f,+/-=sup_(0<omega<E)|fhat(+/-omega)| and nu_E=aE/v0². Equation(27) yields the explicit absolute bounds
    Delta<X_f†X_f>
       <=(A_f,+²+A_f,-²)W0 exp(D_W nu_E) E/(2pi),
    V_gen,f(E)<=2||fhat||_infinity² W0 exp(D_W nu_E) E/(2pi)
                           for real f.                   (31)
The second is also a conservative complex-filter bound when interpreted as Delta<X_f†X_f>, not a real variance of a non-Hermitian X_f. Cauchy-Schwarz for the positive integral form in(30) bounds cross-filter terms by the corresponding two diagonal quadratic forms. No missing negative side is absorbed in an undefined W0.

There is also correctly weighted leading-constant control. Define J_f(E)=integral_0^E (|f_+|²+|f_-|²)d omega/(2pi). Then
    |Delta<X_f†X_f>-W0 J_f(E)|
       <=W0[exp(D_W nu_E)-1]J_f(E).                        (32)
For real f, J_f=2 integral_0^E |fhat|²d omega/(2pi). If J_f=0 both sides vanish; no relative division is made in a null direction. Otherwise the same exponential is a uniform relative error toward the actual leading weighted quadratic form. This is a physical-mode-derived contribution, not an occupation substituted for a PSD.

Sidedness and frequency units: variance of real X_f is integral_R dOmega/(2pi)|fhat(Omega)|²S_sym(Omega). Thus with the measure d omega/(2pi) over POSITIVE angular frequency, the one-sided symmetrized PSD is2S_sym(+omega) and the generated one is2W(omega). An angular-frequency density integrating against d omega WITHOUT2pi is S_sym/(2pi) two-sided or2S_sym/(2pi) one-sided. With ordinary frequency f_Hz=omega/(2pi),
    S_Hz^(two)(f_Hz)=S_sym(2pi f_Hz),
    S_Hz^(one)(f_Hz)=2S_sym(2pi f_Hz), f_Hz>0,
    Delta S_Hz^(one)(f_Hz)=2W(2pi f_Hz).                   (33)
Here d omega/(2pi)=d f_Hz; no extra2pi multiplier belongs in S_Hz under this convention. The filter is evaluated at2pi f_Hz. If time f has units1/time, X_f has X's units and fhat is dimensionless; if f is dimensionless, X_f has X*time units and fhat has time units. Equations(30)–(33) then have the required X² or X²*time² units. Density/current PSD units are respectively time/length² and1/time, before any separately specified spatial weights or actual receiver map.

A real integrable spatial weight w(x) on a HOMOGENEOUS asymptotic-u plane wave adds its actual form factor F_w(k)=integral w(x)e^(ikx)dx to d. Retain |F_w(k_u)|² and its phases/cross products; |F_w|<=||w||_1 gives an absolute contribution bound multiplied by ||w||_1² in(31). If integral w!=0, its actual leading constant is multiplied by |integral w|², and any relative form-factor error needs its own bound. If integral w=0, the leading term can vanish and no division by that constant is allowed; use the absolute bound or derive the next term. This is not an asymptotic-plane-wave substitution at a finite inhomogeneous position. Full profile mode functionals, evanescent/downstream/interference and spatial-readout errors remain the predecessor construction/BUILD as stated.

Countercontrol proving why the rejected r1 factor was false: choose real nonnegative smooth compact-time f with integral f=1. Then ||fhat||_infinity=1, fhat(0)=1, and continuity with W->W0>0 gives
    V_gen,f(E)/(W0 E/(2pi))->2 as E down to0.               (34)
The old bound WITHOUT2 had its same normalized limit1 and therefore failed on sufficiently small positive edges for EVERY allowed parameter set. The corrected(31) tends to2 in this control; it is not merely made looser by changing physical inputs. A single ordered positive-frequency number quadratic B_h†B_h can have only integral W|h|²/(2pi), but B_h is a distinct complex annihilation-mode observable, not the Hermitian density/current component(28). It cannot replace the physical task to preserve the rejected bound. Exact one-sign frequency tests also need their proper time domain and are not claimed to have compact time support.

IR/state boundary: beta²~Theta/omega defines an outgoing quasiparticle smeared quadratic form only on tests with integral_0^edge |h(omega)|²/omega d omega<infinity, e.g.h=O(omega^p),p>0. Equation(25) supplies sqrt(omega) for this density/current channel; bounded finite-time f therefore has finite generated diagonal variance with the actual factor2 in(31). The outgoing-vacuum symmetrized term is separately integrable since |d|²=O(omega) for this channel. This does not prove total finite IR quasiparticle number, unrestricted phase, global Fock implementation, whole local equal-time CCR, stationary incoming whole-field state or total physical PSD. General thermal/correlated inputs may add infrared divergences and require their actual weighted test algebra and full covariance; a formal coth or occupation replacement cannot control them automatically.

## 12. Exact controls, errors and full original BUILD

The leading theorem uses the actual physical threshold, both nonzero high roots, both collapsing acoustic roots, right complex roots, all3channels and the nonzero physical boundary determinant from the complete full-GP predecessor. Pole cancellation is algebraic at zero, and all surviving Gamma factors have an evaluated positive real-part bound. Arbitrary integer/resonant right differences and every L>0 remain, with no omitted population. Rouché discs, explicit constants and exact Gamma recurrence provide manual counterchecks independent of an exact beta center or numerical root plot.

Concrete controls:
- At nu=0 use the analytic w equation, not the singular original p inverse.
- Removing the downstream greybody or substituting Gamma0=1 changesTheta and the -Gamma0/2 coefficient.
- Removing finite-ell tanh changes the actual zero limit by delta_profile, which cannot be repaired by shrinking a nonzero-frequency interval.
- Reversing the incoming negative high root or its norm sign changes the physical flux normalization; a real negative norm is a creation operator, never a negative population.
- Retaining a leftover Gamma(nu)-pole after(8), or using a nominal fixed nonzero acoustic-root gap, fails the zero-disc theorem.
- A literal full finite-frequency Planck identity, global Fock implementation, total finite IR number, KMS state or physical electrical PSD is NOT among(16),(23),(27),(31).
- The real unit-integral finite-time filter(34) rejects the old missing-factor2 Hermitian variance; complex-filter adjoints and both frequency signs in(30) must survive. One-sided Hz PSD must agree with two-sided angular variance. A zero spatial/filter leading direction must not be divided by its vanishing constant.

All equations are manual, not software/native checked. DATA UNRUN future verification must independently compute the actual roots and canceled Gamma quotient with directed precision/branch controls; compare against an independently integrated full two-component BdG boundary problem with validated residual/normalization errors; include tiny positive omega, threshold approach, small/large ell and r, integer/near-integer right exponent gaps, critical asymptote limits, original positive parameter populations and nonvacuum/anomalous inputs. Refine root/Gamma precision, spatial cuts, boundary asymptotics and frequency/filter quadrature independently. Poison tests must reject wrong negative-norm sign, wrong h/v_g/rho0 factor, omitted two collapsing factors, wrong i/sign in(7), extra Gamma0 or tanh, integer-L exclusion, false compact-center assumption, raw occupation-as-PSD and a hidden thermal/KMS assertion. Add an independent b,b† contraction versus ordered/symmetrized/normal-ordered spectral integration and a real unit-integral finite-time-filter limit(34), checking both signs, complex f/g adjoints, angular/Hz conversion and zero-leading spatial directions. A real poison deleting one frequency side or reusing the rejected bound must fail while the corrected bound passes without changing original parameters/populations. Actual source/test byte/mode/nsmtime, raw/semantic index/HEAD/status/refs must be protected/restored only under future real ROOT ownership; none of these recipes is executed or admission evidence here.

Remaining substantive constructions: stationary indefinite spectral/wave-operator completeness with high-frequency arc, threshold and zero-sector control; actual whole-field stationary incoming positive CCR state and full local density/current noise identification; microscopic gas-to-GP/BdG weak depletion/one-dimensional phase/transverse/finite-geometry/preparation errors; quantified chiral comparison if used; actual target polariton/electronic/gas profile, interactions/losses/background/incoming state and optical/electrical receiver/measurement/calibration; an identifiable nonempty physically useful band. The present model-specific IR interval is an actual missing component repaired for review, not a replacement of that full charter.

Original one shared D1/E1/E2 law (not L1's three distinct roots), all21/B1-B8/D12, D5/pump/BEC/CHHK/transport, source G11, numerical G4, proof G5, native/current main failures and genuine human review remain unwaived. Fresh genuinely nonauthor WHOLE scientific review and lead intake must assess this entire construction; no canonical closure or publication green follows from author delivery.


## 13. Primary source/dependency use, process and independent-review boundary

The current author main55 authored the original full-GP predecessor817e20d9 but NONE of root7's NEWdd92e430 root-disc/minor-quotient/error/coefficient proof. The current author then genuinely independently reviewed that entire new13-section note at cf8c3e60, requiring S1 correction and preserving P1. That frozen whole review is historical input, not an independent review or acceptance of this new r2 authored correction. A different genuinely nonauthor WHOLE scientific reviewer must assess this entire r2 after freeze. No author selfacceptance is made.

Full original MODEL17c444c0/CONSTRUCTIONdd92e430/REPORTc52e4311 and whole REVIEWcf8c3e60 plus carrying MODEL23d73a45/fullGP817e20d9/full nonauthor reviewdc9e1a42/leadbedf71db, chiral/response obligation and actual canonical/native definitions were personally read before this corrective proof; exact unchanged-hash reads from the immediately preceding whole review are honestly reused. The original full carrying official1707.09664v2 bodyI–V/AppendicesA–C was personally read in the original author task, fixed edition12January2018, with actual receipt in the original evidence; the version/model was reopened in the recent independent review. DLMF16.8 differential/bases/connection/limiting identities and5.5 recurrence/reflection plus5.7.6/8 digamma series were personally read/crosschecked in that review. No fresh PDF-pixel/fulltext acquisition or new source-before-proof chronology is fabricated, and the distinct chiral1707.09651 remains a different operator.

Section11's new corrective mathematical proof is direct contraction of the ORIGINAL positive incoming-vacuum channel operators and their signed scattering map/CCR, after the fixed newMODEL and explicit lead preflight ACK. The existing equations1–24/root/Gamma/error/Planck scope is retained exactly; equations25–27 are rederived from the same original physical mode amplitudes. The corrected Hermitian variance, actual complex-filter covariance/units/sidedness and countercontrol are derived here, not a new measured device spectrum. No project/helper/model/mathsoftware/test/coefficient engine/native/runtime execution or source/Git/index/ref/holding/registry/book/closure mutation/delegation occurred.

The initial-protection.json dataset is immutable and never rewritten. It captures the literal historical P7/N64/M3 matrix including the explicit initial MISSING infra.md state, separate from actual porcelain. Documentary preflight140checks/0fail does not grant scientific acceptance or cure oldP1; its actual two administrative timestamp differences remain UNKNOWN/unwaived. The lead's preflight parser initially hit heading prose before JSON and was corrected before ACK/proof; old packet-preparation TypeError was before official packet invocation/output/FIRST. Those are historical process facts, not mathematical failures or successful earlier starts. All prior failed author/reviewer records remain unchanged. Current report/evidence/process must precede ONE original FINAL, followed by actual terminal capture/freeze of exactlyEIGHT owned leaves. No check refresh, outside actor attribution or blanket administrative quiescence is permitted. Source100/pending15ADW question grants nothing.

All original physical BUILD and distinct source/runtime/native/main/human gates in section12 remain. No full primary text was saved/admitted, no holding/registry/source changed, no KMS/full stationary field or calibrated target-platform observable was fabricated. This prospective correction is AUTHOR delivery only, pending fresh genuinely nonauthor whole science and separate lead intake.

<!-- END SOURCE137-EXACT-SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR-CONSTRUCTION -->

<!-- BEGIN SOURCE137-EXACT-SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR-REPORT -->
# Full-GP/BdG leading-law corrective r2 — author report

AUTHOR DELIVERY ONLY, pending fresh genuinely nonauthor WHOLE scientific review and lead intake. No author self-review/acceptance, source/runtime/native/gate/main or publication green. The full original shared D1/E1/E2 scientific and physical objective remains BUILD. This new task prospectively corrects the S1 Hermitian variance error in the entire original thirteen-section leading-law construction; the old r1/P1 process failure and frozen rejected artifacts remain immutable and UNWAIVED.

## Result and corrected observable

The fixed full continuum GP/BdG family is unchanged: m,rho0,L>0,0<c_l<v0<c_r, arbitrary real mu, v=-v0, actual logistic c^2, original g/V, quantum pressure, field CCR, co/downstream and negative-norm channels, original incoming preparation alternatives and mode/flux normalization. No favorable parameter/state/profile/chiral/free/unit-greybody/thermal replacement is made.

The complete13-section CONSTRUCTION retains root7's entire root-disc, canceled-minor/Gamma, physical normalization, independently derivedTheta, first-coefficient, constructive small infrared interval and scalar Planck-comparison proofs. Sections2–10 are byte-exact whole-section copies of dd92e430, independently reviewed earlier at cf8c3e60 within that REQUIRES_CORRECTION report, not a whole acceptance. Section11 is coherently rederived here after the new fixed MODEL and explicit documentary preflight ACK. Section1/13 chronology and section12 controls are updated to the actual new author task; no old chronology is relabeled current.

For either actual asymptotic outgoing-u particle density/current mode, let d(omega) be its ORIGINAL physical coefficient and n_u=|beta|^2 in the original incoming vacuum. W=|d|^2n_u is EACH-SIDED generated normal-ordered spectral weight. The correct physical Hermitian field contribution contains both d b exp(-iomega t) and its adjoint. Direct b,b† contraction therefore gives, for a real time filter f,

    V_gen,f(E)=2 integral_0^E |fhat(omega)|^2 W(omega)domega/(2pi),
    V_gen,f(E)<=2||fhat||_infinity^2 W0 exp(D_W nu_E)E/(2pi).

The previous whole note omitted this2 in its last section11 bound. That bound is FALSE for a smooth nonnegative compact-time unit-integral filter as E->0: actual variance divided by W0E/(2pi) tends to2, while the rejected bound tends to1. The new statement retains the physical Hermitian observable, both frequency sides and zero-reaching domain; it does not replace them by a one-sided ordered annihilation-number quadratic form to keep the old result.

The new section11 also derives the complete real/complex-filter ordered, reversed, symmetrized and outgoing-vacuum-subtracted covariances. For complex f, X_f†=X_(conjugate f) and

    Delta<X_f†X_g>=integral_0^E W
      [conjugate(fhat(+omega))ghat(+omega)
       +conjugate(fhat(-omega))ghat(-omega)]domega/(2pi).

Its positive diagonal bound uses(A_f,+^2+A_f,-^2)W0 exp(D_W nu_E)E/(2pi). For real f the two terms coincide, producing2. The correctly weighted leading quadratic form J_f includes both sides; its error is <=W0[exp(D_W nu_E)-1]J_f. Null J_f is treated without relative division. Cross-filter controls follow by the actual positive quadratic form, and physical channel coefficients are combined BEFORE taking squared moduli, so actual cross terms are not dropped.

At positive frequency the full ordered PSD is|d|^2(n_u+1), at negative frequency|d|^2n_u. The symmetrized PSD on EACH side is|d|^2(n_u+1/2). Outgoing-vacuum subtraction yields W on EACH side; the full quantum background is not equated to experimental subtraction. The one-sided generated PSD, integrated over positive angular frequency with domega/(2pi), is2W. With ordinary f_Hz=omega/(2pi), two-sided per-Hz PSD is S_sym(2pi f_Hz) and one-sided is2S_sym(2pi f_Hz), with no extra2pi multiplier. Actual filter argument, dimensions and adjoints are retained.

The original physical mode weights remain

    |d_rho|^2=(2rho0/v0)nu w_u^2/D_u, j_u/d_rho=v0/w_u,
    W_rho=(2rho0/v0)(w_u^2/D_u)Theta_nu G,
    W_j=(2rho0v0)/D_u Theta_nu G.

Their leading constants, dimensions time/length^2 and1/time, and exponential relative-error constants are unchanged and rederived from the original h/CCR/continuity normalization. Bounded finite-time filters give a finite generated diagonal IR contribution, with the correct2. Real spatial weights retain their actual plane-wave form factor and phases; an absolute||w||_1^2 control is supplied, while a zero spatial mean/leading constant is not divided away. This is explicitly an asymptotic homogeneous-u component, not an exact plane-wave substitution at a finite inhomogeneous position.

## Whole retained mathematical scope

All original root and mode populations remain: the true quartic physical threshold, high roots, even acoustic q=nu w root regularization through zero, right growing/decaying roots, every L>0 and integer/near-integer resonance. Explicit Rouché discs, analytic continuation, Cauchy root derivatives and evaluated nonzero/Gamma half-plane constants remain. No fixed nonzero acoustic-q gap or exact-beta supremum is introduced.

The actual ordered M3/M0 quotient and Z=nu^2M3/M0 cancel the two acoustic poles and shift the imaginary Gamma arguments before zero. Original physical normalization gives nu|beta|^2=N|Z|^2. The actual leadingTheta remains

    Theta=kappa Gamma0 tanh(piell)/(2pi), Gamma0=4s/(s+1)^2.

All twelve Gamma derivatives, normalization and elementary factors give G'(0)=-1/(2t0) and the actual finite occupation correction-Gamma0/2. The complex logarithm/log-derivative bound and Cauchy remainder provide explicit positive small-tolerance IR edges reaching zero for every original allowed parameter. Their intervals can be extremely conservative/tiny. The scalar Planck comparison remains DERIVED and restricted; it is not global KMS, exact finite-frequency thermal equality or a supplied incoming thermal preparation. The finite-ell profile deficit/nonunitGamma0 and beyond-all-powers fixed-asymptote smooth limit remain; no universal nonzero pi/6 quadratic law is asserted.

The corrected covariance is derived from the actual incoming-vacuum u marginal on the band/scattering algebra. Full cross-channel/anomalous/correlated/thermal inputs remain in the original signed3x3 transformation with their actual test domains. Quasiparticle occupation~1/omega still requires integral|h|^2/omega<infinity; derivative density/current supplies sqrt(omega), but unrestricted phase, total finite IR quasiparticle number, global Fock implementation, full local stationary CCR/state/noise and detector PSD are NOT completed. Gapless thermal inputs can introduce further divergences. No coth/occupation substitution supplies the missing physical observable.

## Genuine FIRST, immutable protection, MODEL and explicit preproof ACK

The new packet5a10fc693bcf54069e58e1f10ca6d9ec2b72358f547d612d1b301bef3fd10674 is data, never an extra argv. FIRST ran once from N16:27:03.824902–16:27:04.100168 UTC with exactly five argv, rc0/freshtrue/changed[], empty separate stderr. No repeat/refresh.

Actual initial capture16:28:21.810751–16:28:23.018166 covers ALL53 literal bindings/51 unique reference paths, complete P5186/N4869/M4906 tracked, literal mandatory P7/N64/M3 plus actual dirty/untracked extras, raw indexes including bytes/fullstats independently of semantic stage, HEAD/status/namedrefs,83 scoped administrative entries and21 separate-pipe optional-lock-disabled read-only Git receipts, and EIGHT owned absences. Actual porcelain is0/64/3; historical known paths are a separate category. The primary seventh historical infra.md is explicitly captured MISSING initially, alongside the six generated files that are actually tracked. The complete dataset was frozen in initial-protection.json16:28:23.040243 SHA6072d1853dfd453ba8cca2319c2a18229db80f6399919b5f350ab95ffe005fb5 and is NEVER REWRITTEN.

IMMEDIATELY afterward SOURCE_MODEL saved16:28:23.044799–16:28:23.044978 UTC, SHA9aa2973847ad116c104c8548cfc3a4a26d3cffbd9d3d73237f9fa7e5602f8fbd, before ANY new corrective mathematics. It encloses the ENTIRE original17c444c0 model byte exactly, including the entire original23d73a45 family. No favorable model selection after a result occurred.

The author then STOPPED before math as required. Lead documentary preflight receipt2a9ee5bcd6ee6b6d631f338c9b1f287cea1b9bc87372630bd82092206529ef85 dated16:29:48.382975 was personally read and recorded16:30:12.269665 before proof. Its140checks/0fail verify the actual literal inventories, known absence, owned states, hashes and raw/source/Git scope; its two genuine administrative timestamp differences have UNKNOWN cause and remain unwaived. It is NOT scientific acceptance/source/runtime/native/main authority. The lead's parser initially read heading prose before JSON; correction occurred before ACK/proof, with the failed attempt separately preserved. Earlier packet assembly TypeError was before official packet invocation/output/FIRST, not an earlier successful task start.

Only after that actual recorded ACK did new corrective mathematics begin; exact mental-start instant is UNKNOWN, bounded after16:30:12.269665 and before the first construction save16:33:48.921896. The construction serialization is static text, not software mathematics/model/test execution. Initial dataset and model hashes were rechecked unchanged before the save. Sections2–10 whole-byte comparison is exact, with individual section hashes recorded in evidence. Old r1/model/report/review/P1 leaves are not edited/backdated or retroactively accepted.

The old author P1 is independently established: its original initial tracked5186/dirty0 captured six generated known paths but NO historical absent primary infra.md, and its complete initial JSON contains zero occurrences of that path. This current task's genuine complete protection does NOT cure that failed initial chronology. The old r1 scientific S1 rejection and process/ref/admin UNKNOWNs remain. This new r2 is an actual corrective author attempt, not a waiver or self-review.

## Reading provenance and actual controls

The full original MODEL17c444c0/CONSTRUCTIONdd92e430/REPORTc52e4311, complete whole reviewcf8c3e60 and all carrying original23d73a45/817e20d9/dc9e1a42/leadbedf71db, chiral/response obligations and relevant actual native/canonical definitions were personally read before new proof. Exact unchanged-hash full reads from the immediately preceding whole review are honestly reused. The author originally wrote817e20d9 but none of root7's newdd92e430 proof, then independently revieweddd92e430; that earlier role is history, not current independent acceptance. This author cannot accept or independently review this new r2.

The carrying primary1707.09664v2 full bodyI–V/AppendicesA–C was personally read in the original author task at its fixed12January2018 edition; source/model identity was reopened in the recent whole review. DLMF16.8 differential/connection/limiting qualifications and5.5 recurrence/reflection plus5.7.6/8 series were personally checked there. This is honest existing depth, not a new full PDF/pixel or retroactive fresh-read claim. No fulltext downloaded/saved/admitted and no holding/registry changed. Current new contractions derive directly from the original bosonic channel CCR, not a citation or an unrelated noise model.

Manual author assurance covers the physical d normalization, actual outgoing marginal n/n+1 and vanishing same-u anomalous vacuum covariance, ordered/reversed/symmetrized/normal-ordered forms, complex adjoints, actual real-filter2, one-/two-sided/angular/Hz conversion, filter/spatial units, positivity/null domains, IR integrability and the unit-integral-filter limit that disproves the old bound. The full original root/Gamma/leading-law/coefficient/error proofs and their domains remain in the complete construction, with static whole-section preservation, not removed because this repair is local.

All future numerical/verification recipes remain DATA UNRUN: independent directed-precision root/canceled-Gamma reference versus independently integrated full coupled BdG boundary problem with validated residual/flux/normalization, tinyomega/threshold/small-largeell,r/near-critical/integer/near-integer/nonvacuum populations, independent spatial/asymptotic/frequency/filter/arithmetic refinements and actual real poisons. Add a genuinely independent field contraction versus spectral/variance integration with both sides, complex f/g adjoints, one-sided Hz conversion and zero-leading directions. Missing2/one-deleted-side/incorrect vacuum/occupation-PSD poisons must reject without changing original parameters or populations. Exact source/data/test bytes/modes/nsmtime/rawsemantic index/HEAD/status/refs restoration requires future real ownership; nothing was executed here.

No project/helper/model/test/recipe imports/eval/collection/execution, coefficient/symbolic/numerical mathematics engine, native/Lean/controller/build/render/runtime, source/Git/index/ref/book/holding/registry/closure/main mutation or delegation occurred. Only eight allocated ignored author leaves are writable. E2/L1 workers remain active and their changing outputs were not read/reverted. Source100/pending15ADW question grants nothing. Current fixed r70 is read; notebook remains lead-only.

## Entire physical objective and next genuinely independent verification

This author result corrects a real normalization defect prospectively and preserves useful manual mathematical progress; it is not full original physical completion. The following remain substantive BUILD, not infeasibility, approved deferral or reduced charter:

- Stationary indefinite spectral/wave-operator completeness, high-frequency contour arc, threshold/zero/generalized sectors and actual stationary whole-field incoming positive test-algebra state/local CCR/noise identification. Separate full finite-time field/state and positive scattering-band state do not alone bridge them.
- Microscopic gas-to-GP/BdG weak depletion, one-dimensional phase/coherence/IR, transverse/finite-geometry/preparation/reservoir errors and any quantified full/chiral reduction. Exact GP substitution and an exact mathematical IR amplitude do not establish these physical approximation regimes.
- Actual polariton/electronic/gas profiles/dispersion/interactions/loss/incoming states, optical/electrical receiver/displacement/circuit/calibration, independent microscopic routes, absolute observable/inference uncertainty and an identifiable NONEMPTY error-small physically useful band. A tiny positive mathematical IR edge is not an experimental band or graphene electrical conductivity/noise.
- One shared D1/E1/E2 law, all21/B1–B8/D12, THREE distinct L1 roots, D5/pump/BEC/transport/CHHK, current source/native defects and full G4/G5/G11/main/human gates. No source application or canonical/publication closure follows from this ignored author delivery.

Next: a fresh genuinely NONAUTHOR WHOLE science review of ALL13sections, including the original root/minor/Gamma/normalization/coefficient/error domains and the entire new Hermitian covariance/variance convention, plus preservation/process limits and physical BUILD, then separate current lead intake. No reviewer acceptance/lease is invented in this report. ROOT actual source/runtime/native/gates/main and human publication review remain separate future authority/evidence.

This complete REPORT/CONSTRUCTION/evidence/process precedes the ONE original FINAL. Record its literal UTC/argv/cwd/rc/separate pipes without refreshing; then genuine full terminal capture must compare all51 unique references/53bindings and full P/N/M tracked+literal known+actualextras, rawsemantic indexes/HEAD/status/refs and scoped admin to the ORIGINAL immutable initial dataset. Verify initial-protection/model remain exact, preserve every outside movement with UNKNOWN actor/cause and no blanket quiescence claim, then freeze exactly eight leaves. The scientific report will not be rewritten after FINAL; actual terminal metadata follows in evidence/process/final-check only.

<!-- END SOURCE137-EXACT-SHARED_FULL_BDG_LEADING_LAW_UNIFORM_ERROR-REPORT -->
