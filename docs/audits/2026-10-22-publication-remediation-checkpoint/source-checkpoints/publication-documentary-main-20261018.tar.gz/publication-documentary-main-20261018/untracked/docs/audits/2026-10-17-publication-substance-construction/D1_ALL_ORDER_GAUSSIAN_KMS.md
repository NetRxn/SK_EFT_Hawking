# D1:3.2 — an all-N Gaussian action/KMS and remainder construction

Author: Publication Remediation lead, 18 October 2026. **Manual mathematical construction; independently accepted within the declared Gaussian scope.** See the [complete nonauthor review](reviews/D1_ALL_ORDER_GAUSSIAN_KMS.md). Parent is the existing D1 Stage10 finding3.2, with action-basis row2 and physical-spectrum row1 linked. Original D1 all-orders physical programme remains ACTIVE BUILD. This supplies a concrete first bridge beyond integer-pair cardinalities, not a new charter or a complete physical Hawking result. Manual mathematical acceptance does not establish numerical/model/test execution, native proof, physical applicability, gate or finding closure, integration or publication readiness.

## 0. Exact objective and scope

For a stated stationary scalar Gaussian class, construct actual differential operators/actions at every finite order, establish the integration-by-parts basis, derive coefficient constraints from thermal spectral correlations, and bound the error of the resulting noise/response approximation on a declared band. Also construct one positive thermal carrier whose retarded response realizes these statements. This is a substantive subtask of D1:3.2, not a replacement of its inhomogeneous, nonlinear, device/state and horizon/spectrum duties. “All orders” here means an indexed statement for each finite N. No convergence requirement is imposed on a general physical EFT. The explicit thermal-factor series in this particular carrier does additionally converge inside its stated radius.

The existing full first/second-order action equalities remain actual algebraic representation results under their stated coefficient structures. ThirdOrderSK has actual field/coefficient definitions and selected-pair count/parity results. None is erased. Neither those counts nor copying three coefficient fields constructs the arbitrary-N operator, its physical KMS applicability or a Hawking spectrum. The present class is homogeneous, at rest, scalar, Gaussian and spatial-parity-even. No identification of its coefficients with the repository's transport coefficients is assumed. In particular, the algebraic structures in the existing source do not themselves establish the physical spectral hypotheses used below.

## 1. Conventions and the finite-order action basis

Set hbar=k_B=1, beta>0. Fourier convention is f(t,x)=integral exp(-i omega t+i k x) fhat(omega,k) d omega d k/(2pi)^2. Fields r,a are real Schwartz functions on R^(1+1); compactly supported smooth functions also suffice for integration by parts. There are no spatial boundaries or position-dependent coefficients in this first construction. For each finite L, consider translation-invariant quadratic local densities with one a and one r, or two a fields, total derivative degree at most L. Spatial reflection is imposed in the rest frame, so the canonical symbols contain even powers of k.

Every cross bilinear integral of (partial^alpha a)(partial^eta r) equals (-1)^|alpha| integral a partial^(alpha+eta) r. Hence the cross action has a representative integral a P(partial_t,partial_x) r. These representatives are independent: if the integral vanishes for all a,r, then P r=0 as a distribution for every r. Fourier localization near any real (omega,k) implies the polynomial symbol of P vanishes everywhere, so every coefficient vanishes. Equivalently, if some real P r is nonzero, choosing a=P r gives a strictly positive L2 square, a contradiction. This proves both spanning and independence for the chosen finite class, not just the number of its labels.

For a same-field bilinear integral a Q(partial) a, integration by parts removes the formally antisymmetric part: only (Q+Q*)/2 matters, with Q*=Q(-partial) for real constant coefficients. Spatial parity then leaves even time derivatives as well. Therefore the quadratic SK action can be written

    S[r,a] = integral a(-omega,-k) D(omega,k) r(omega,k)
             + (i/2) integral a(-omega,-k) N(omega,k) a(omega,k),       (1)

where D(-omega,-k)=D(omega,k)* and N is real and even. Normalization S[r,0]=0 and the SK conjugation rule follow directly. Im S>=0 for every admitted real a if and only if N>=0 on the admitted Fourier support: necessity follows by wave-packet localization, and sufficiency by the integral of N|ahat|^2/2. This positivity statement is about the actual integrated quadratic form. It is not a pointwise independent-jet positivity assertion.

In the spatial-parity-even rest-frame subclass write

    D(omega,k) = P(omega^2,k^2) - i omega Gamma(omega^2,k^2),           (2)

with real P,Gamma on real frequencies. A finite jet uses coefficients a_pq,g_pq on p+q<=n. These yield actual reactive derivatives of order2(p+q), actual odd-time dissipative derivatives of order2(p+q)+1 and noise derivatives of order2(p+q). The signs and powers of i are fixed by (2) and the Fourier convention; they are not additional coefficient assumptions. These are explicit operator/action representatives at every n. Local field-shift symmetry, flow, gauge constraints, boundaries and nonlinear monomials require additional, separately proved quotients and are not silently included.

## 2. An actual positive thermal spectral carrier

Fix m>0, Omega>0 and gamma>0. Let

    D(z)=m(Omega^2-z^2)-i gamma z,
    R(z)=1/D(z).

Both poles are strictly in the lower half-plane. In the underdamped case their imaginary part is -gamma/(2m). In the overdamped case they are -i[gamma +/- sqrt(gamma^2-4m^2 Omega^2)]/(2m), and both bracketed quantities are positive. The repeated-pole case is still strictly below the real axis. Thus R is analytic in the upper half-plane and has the retarded boundary condition. On the real axis

    rho(omega)=2 Im R(omega)
      =2 gamma omega/[m^2(Omega^2-omega^2)^2+gamma^2 omega^2].          (3)

It is odd and positive for omega>0. Near zero rho=O(omega), and at infinity rho=O(|omega|^-3). Advanced boundary values are R_A(omega)=R(omega)*. Since R decays as z^-2, Cauchy's formula, closing R_R in the upper and R_A in the lower half-plane, gives the unsubtracted dispersion identity

    R(z)=integral_R rho(nu)/(nu-z) d nu/(2pi), Im z>0.               (4)

Indeed (R_R-R_A)=i rho, the upper contour has the pole z and the lower contour does not; the large semicircles vanish. Absolute convergence follows from the stated small/large-frequency bounds. This is an equality for the actual rational response, not an assumed susceptibility.

Let n_beta(nu)=1/(exp(beta nu)-1), nu>0. On doubled bosonic Fock space over L2(R_+) direct-sum L2(R_+), take independent annihilation distributions A_nu,B_nu and their vacuum. Define a Hermitian field, initially as a Segal field,

    phi(t)=integral_0^infty sqrt(rho(nu)/(2pi)) {
       sqrt(1+n_beta)[A_nu exp(-i nu t)+A_nu^dag exp(i nu t)]
       +sqrt(n_beta)[B_nu^dag exp(-i nu t)+B_nu exp(i nu t)] } d nu.  (5)

Its one-particle functions are L2: rho(1+2n_beta) is bounded near zero and integrable at infinity. Each real-time phi(t) is therefore a well-defined essentially self-adjoint Segal field on the usual finite-particle analytic core. Time evolution is implemented by the second quantization of multiplication by nu direct-sum -nu. The resulting Liouvillian is not claimed to be bounded below; this is the thermal doubled representation, not a proposed zero-temperature ground-state Hamiltonian.

Vacuum contraction in the doubled representation gives

    W(t)=<phi(t)phi(0)>
       =integral_0^infty rho(nu)/(2pi)
          [(1+n_beta)exp(-i nu t)+n_beta exp(i nu t)] d nu.          (6)

This is a positive correlation kernel by the explicit Hilbert-space construction. Its Fourier measure satisfies W(-omega)=exp(-beta omega)W(omega). For complex t-i s, 0<s<beta, the two terms have respectively exp(-s nu) and n_beta exp(s nu), giving convergence and analyticity in the lower strip. At s=beta, detailed balance yields W(t-i beta)=W(-t), in the boundary/distribution sense. For frequency-compact smeared fields this is immediate by dominated convergence; the full distribution follows by Schwartz approximation and the spectral bounds. Wick factorization, or the Gaussian Weyl characteristic function and this same strip identity, gives the KMS identity on the generated Gaussian/Weyl algebra. Thus the thermal state is constructed, not an assigned scalar FDR label.

The commutator in (5) is state-independent, because (1+n_beta)-n_beta=1. It equals integral rho(omega)exp(-i omega t)d omega/(2pi). The response i theta(t)<[phi(t),phi(0)]> consequently has transform (4), exactly R. The symmetrized correlation is

    C(omega)=(W(omega)+W(-omega))/2
            =(rho(omega)/2)coth(beta omega/2)
            =coth(beta omega/2) Im R(omega).                       (7)

The real-axis zero-frequency value is interpreted by the continuous limit, not by a division at zero. This construction also explains why “an even conservative inverse kernel has no thermal fluctuations” is not an acceptable blanket inference: a conservative oscillator's retarded i0 boundary carries delta spectral mass. The gamma>0 carrier above has ordinary nonzero spectral density; gamma=0 must be treated distributionally or as a separate oscillator construction, not by deleting its i0 spectral contribution.

## 3. Derived SK noise and its all-N coefficient connection

For any admitted scalar response of form (2) with physical thermal spectral relation (7), R=1/D and Im R=omega Gamma/|D|^2 on the regular real-frequency region. The Gaussian noise kernel required by (1) is therefore

    F_beta(omega)=omega coth(beta omega/2), F_beta(0)=2/beta,
    N(omega,k)=F_beta(omega) Gamma(omega^2,k^2),
    C(omega,k)=N(omega,k)/|D(omega,k)|^2.                           (8)

For the actual carrier define the operator-valued distribution eta=m(partial_t^2+Omega^2)phi+gamma partial_t phi on Schwartz smearings. Its symmetrized spectrum is |D|^2 C, and its commutator spectrum is |D|^2 rho=2 gamma omega. Therefore eta has the actual noise spectrum gamma F_beta, and D phi=eta is an operator-distribution identity in the constructed state. R D=1 on real frequencies, so the stationary response is its stable retarded inverse. This derives both the response and the quantum force covariance from (5), rather than assigning two equal scalar noise formulas. These equalities follow from the actual carrier for D=m(Omega^2-omega^2)-i gamma omega, Gamma=gamma. In another medium (8) is conditional on establishing its retarded, state and equilibrium spectral hypotheses. Nonnegative Gamma gives N>=0 because F_beta>0. Reactive coefficients in P do not by themselves determine the noise. In the classical low-frequency limit N=(2/beta)Gamma plus controlled quantum corrections. With the iN/2 convention in (1), the ordinary friction gamma and imaginary density i sigma a^2 satisfy sigma=gamma/beta. This fixes the factor-of-two convention explicitly.

The only imported analytic identity below is the personally read primary [NIST DLMF4.36.3](https://dlmf.nist.gov/4.36.E3): coth x=1/x+2x sum_(l>=1)1/(x^2+pi^2 l^2), away from its imaginary-axis poles. All following coefficient and error statements are derived here. For every finite M>=0 set

    F_M(omega)=2/beta + sum_(j=0)^(M-1)
       (-1)^j beta^(2j+1) zeta(2j+2) omega^(2j+2)
          /(4^j pi^(2j+2)),                                     (9)

with the sum empty for M=0. For real omega, the finite geometric identity inside each positive summand gives the EXACT remainder

    F_beta-F_M = (-1)^M beta^(2M+1) omega^(2M+2)/4^M
        * sum_(l>=1)1/[pi^(2M)l^(2M)(pi^2 l^2+(beta omega/2)^2)].    (10)

The interchange here involves only finitely many sums plus absolutely convergent positive series; it assumes no infinite EFT convergence. The remainder has sign (-1)^M for omega!=0. Its magnitude is at most

    E_M(omega)= beta^(2M+1)|omega|^(2M+2) zeta(2M+2)
                    /(4^M pi^(2M+2)).                           (11)

A corresponding lower bound divides E_M by 1+(beta omega/(2pi))^2. At omega=0 both remainders vanish. In particular, the first coefficients are

    F_M = 2/beta + beta omega^2/6 - beta^3 omega^4/360 + ... .        (12)

Let f_0=2/beta and, for j>=1,

    f_j=(-1)^(j-1) beta^(2j-1) zeta(2j)/(4^(j-1)pi^(2j)).

If g_pq are the actual even Taylor/finite-jet coefficients of Gamma, then for EACH finite n the noise jet coefficients are

    h_pq=sum_(j=0)^p f_j g_(p-j),q, p+q<=n.                       (13)

This follows by ordinary finite coefficient multiplication modulo terms of degree greater than n in u=omega^2,v=k^2. The reactive a_pq do not appear. It is an action/operator coefficient connection, not a count of admissible pairs. For the concrete carrier Gamma=gamma, h_j0=gamma f_j and every q>0 coefficient vanishes: an actual all-N family of local noise actions accompanies the same causal response. To infer a general medium's g_pq, stability and physical state still requires a separate construction; arbitrary polynomial jets are not guaranteed to define a stable passive response.

## 4. Controlled band, positive finite approximations and observable error

For a fixed 0<r<1 and |omega|<=2pi r/beta, (11) becomes

    sup |F_beta-F_M| <= (4/beta) zeta(2M+2) r^(2M+2)
                       <= (8/beta) r^(2M+2),                     (14)

using zeta(s)<=1+1/(s-1)<=2 for s>=2. This tends to zero uniformly. The radius is the nearest nonzero imaginary pole of coth, not a claim about a device's hydrodynamic or Hawking validity band. Each finite remainder statement (10) is valid for every real omega, although the bound is useful for convergence on this smaller band.

Since F_beta>=2/beta, a sufficient positive-noise condition is (8/beta)r^(2M+2)<2/beta. For r<=1/2 and M>=1, (14)<=1/(2beta), so F_M>=3/(2beta)>0. M=0 has F_0=2/beta>0 directly. Thus the finite Gaussian actions (1), with N_M=gamma F_M, have nonnegative imaginary quadratic form on the ACTUAL band-limited test space. No global positivity is inferred for the polynomial outside that space. A concrete negative control is beta=1,M=2,omega=10:

    F_2(10)=2+100/6-10000/360=-82/9<0,

whereas F_beta(10)>0. Finite-order thermal Taylor data cannot be promoted to a globally positive noise model without this domain qualification. At any chosen r<1, sufficiently large finite M gives the same positivity conclusion by (14).

For the concrete oscillator |D(omega)|^2=m^2(Omega^2-omega^2)^2+gamma^2 omega^2>0 at EVERY real frequency. On any compact frequency band it has a positive minimum d^2. This follows directly: a zero would require omega=0 from gamma>0 and then Omega=0, contradicting the assumptions. Hence the ACTUAL symmetrized observable error obeys

    sup_band |C-C_M| <= gamma E_M,max/d^2,
    C_M=N_M/|D|^2.                                               (15)

For an actual real linear filter H supported in that band, its variance error is at most

    integral |H(omega)|^2 |C-C_M| d omega/(2pi)
      <= gamma E_M,max/d^2 * integral |H|^2 d omega/(2pi).          (16)

This is an observable covariance/error statement, not a formal coefficient limit. Filter normalization and units remain those in (1); converting to detector current/PSD/Hz or a physical optical aperture is not accomplished here.

More generally suppose on the SAME fixed compact band |D|>=d>0, |D|<=Dmax, |N|<=Nmax and an actual approximate pair satisfies |D-D_n|<=epsilon_D<d and |N-N_n|<=epsilon_N. Triangle inequality gives |D_n|>=d-epsilon_D and

    |R-R_n| <= epsilon_D/[d(d-epsilon_D)],
    |C-C_n| <= epsilon_N/(d-epsilon_D)^2
      + Nmax epsilon_D(2Dmax+epsilon_D)/[d^2(d-epsilon_D)^2].        (17)

To prove the second formula, split N/|D|^2-N_n/|D_n|^2 into the noise difference over |D_n|^2 and N times the reciprocal-denominator difference, then use ||D_n|^2-|D|^2|<=epsilon_D(2Dmax+epsilon_D). For the concrete carrier epsilon_D=0, (17) reduces to (15). For a physical medium the remainder inputs in (17) must actually be derived; supplying them is not their construction. Near resonances d may be small, making the usable band narrower. No nonempty DEVICE band has been claimed.

## 5. What has and has not been built

Built manually: an actual positive thermal Gaussian representation with exact retarded response; a finite-order IBP action basis and independence argument for a declared rest-frame subclass; all-N derived noise coefficient convolution; an exact signed finite remainder, uniform thermal band/positivity controls and actual filtered-observable error; explicit low-order, zero-frequency, high-frequency and conservative-i0 controls. These give a substantive first attempt at existing D1:3.2 beyond coefficient counting.

Still owed at the ORIGINAL full strength: nonlinear/a-field/symmetry and background-dependent classification, actual connection of the repository's first/full-second/third-order carriers to physical derivative operators and KMS transformations, physical transport parameters, nonequilibrium replacements where the pump invalidates equilibrium KMS, spatial/horizon/mode-conversion and Bogoliubov/state normalization, all-order physical spectral corrections with valid finite-order remainder, actual numerical/native evidence and propagation to D1/E1/E2 outputs, independent review and canonical closure. In particular a Hawking temperature beta_H cannot be substituted for beta merely because the factor coth appears. The construction's finite oscillator is a genuine physical mathematical carrier, not the target polariton/graphene device or horizon.

No original false algebra or factual claim is reinstated. No universal all-order transport count, all-background uniqueness, physical D1 detection band or publication gate is closed. General EFT acceptance does not require a convergent infinite series: rigorous per-order asymptotic control would also satisfy the relevant mathematical duty when physically matched. This note's stronger convergence result belongs only to the specified thermal factor.

## 6. Provenance and process

Primary identity personally read: NIST DLMF4.36.E3 via official page, 18 October 2026; the visible equation and its excluded imaginary poles were read. Its single cited partial-fraction identity supports (9)–(11); the further proofs are author's derivations. An initial direct primary lookup occurred before the local-corpus scan/README read, contrary to the local-first order; that sequencing exception is preserved. No claim is made to have dispatched an unavailable research-scout or used a Claude hook. No source tier, holdings registry or canonical citation was upgraded. This is our research work in the owning repository; no authored work was stored in Lit-Search.

The complete local146-line research report 'Dynamical KMS symmetry and the fluctuation-dissipation relation in Schwinger-Keldysh EFT' was read. Its CGL/other equation attributions were not freshly primary-verified here and are not used as axioms. Its blanket conservative-zero-fluctuation statement is corrected by the distributional control in section2. Actual SecondOrderSK carrying actions/KMS structures and ThirdOrderSK carrying records/theorem were read as source; no kernel or theorem lookup execution occurred. One preliminary search named absent FirstOrderSK.lean; the actual source's cross-reference identifies SKDoubling.lean. No absent-source theorem was inferred.

The construction author’s initial exact official assignment check passed before the original note was written. Only assigned ignored outputs were written. No symbolic/numerical mathematics program, project import, test, Lean/native, compiler, renderer, Git mutation, closure writer or shared notebook operation was run. The complete independent nonauthor review accepted the declared Gaussian manual construction after checking the original objective, constants, Fourier signs, domain/state issues and remaining physical duties. Its full report is linked above. This delivery updates only acceptance status and transports that review; native and full scientific acceptance remain separate.
