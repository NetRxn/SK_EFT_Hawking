# KV2008 fixed-sector covariant perturbations and the actual de Sitter scalar mode

Author: publication scientific lead. Independently accepted MANUAL mathematical construction within the selected source model; native and empirical acceptance remain open. Parent: existing KV2008 forward-model/perturbation BUILD, not a new research charter. The selected2008 background construction and original scope remain. No numerical evaluator, calibrated cosmology, same-data likelihood, native proof or publication closure is supplied here.

## 1. Source conventions and the exact selected-sector equations

The lead personally reread the official [2008 source](https://arxiv.org/pdf/0806.2805v7), Eqs2.1–2.8 and its curvature convention/de Sitter Eq3.1, during this construction. In particular the source explicitly permits its fixed-mu effective scalar action at the classical field-equation level. The three-form is not silently reclassified as a freely propagating flat-space scalar. We work within ONE spatially constant integration-constant sector; delta mu=0. Changes between sectors or2011plateau transitions are not perturbations covered here.

For this note ONLY choose the standard curvature convention R_std=+6(dot H+2H²) on flat FRW; it is the NEGATIVE of the source's R_KV, whose de Sitter value is-12H². Keep signature(-+++), ordinary physical time t and box=g^(mu nu)nabla_mu nabla_nu. This explicit curvature translation converts the source's effective gravitational action into

S_mu=integral sqrt(-g)[(M_*²/2) f R_std-U(f)]+S_m[g,psi],
M_*²=sF0/(8pi)>0, sigma=3M_*²/F0, t_*²=chi F0,
U(f)=V(f)/chi, V=-f²/2+f⁴/6-u f, f>0.                              (1)

Here M_* is the positive square root of M_*². S_m and its T_mu nu use the usual convention T_mu nu=-2/sqrt(-g) delta S_m/delta g^(mu nu). Matter is minimally coupled in this Jordan frame and independent of f. The phenomenological choices for epsilon and G are the SAME selected source ansatz, not derived microscopic physics. The equations obtained by varying the fixed-sector effective action are

M_*² f G_mu nu=T_mu nu-U g_mu nu
                +M_*²(nabla_mu nabla_nu f-g_mu nu box f),
(M_*²/2)R_std=U_f, nabla^mu T_mu nu=0.                              (2)

At the original four-form level, the second equation is the integrated Maxwell equation in the selected fixed-mu sector. It is not an additional kinetic term assigned to that four-form. Taking the metric trace and substituting the second equation yields the exact covariant trace equation

3M_*² box f=2f U_f-4U+T, T=g^(mu nu)T_mu nu.                        (3)

This is not an independently postulated scalar potential equation. Both the metric and Maxwell constraints remain required. The original Friedmann equations follow directly: multiplying00 by chi gives sigma(fh²+hp)=V+m+r. In the homogeneous trace, T=-rho_dust and radiation trace0 give

f''+3h f'=(4V-2fV_f+m)/sigma.                                      (4)

Combining the constraint and h'=V_f/sigma-2h² shows(4) equals the already constructed p'=hp-2fh'-(3m+4r)/sigma, so no alternative background or matter exchange is introduced. Primes in(4) mean d/dtau, tau=t/t_*; derivatives in(2)–(3) have physical units.

## 2. Einstein-frame positive kinetic normalization, with its domain

For f>0 define g_E=f g, phi=sqrt(3/2) M_* log f. The conformal curvature identity, followed by integration of the total derivative for compactly supported variations, converts(1) into

S_mu=integral sqrt(-g_E)[(M_*²/2)R_E
       -(1/2)g_E^(mu nu)partial_mu phi partial_nu phi-W(phi)]
       +S_m[f^(-1)g_E,psi],
W=U/f²=(-1/2+f²/6-u/f)/chi.                                       (5)

For clarity the gravitational kinetic term before phi substitution is
-(3M_*²/4)g_E^(mu nu)partial_mu(log f)partial_nu(log f).
Thus there is a positive ordinary scalar kinetic energy on this branch; it does not come from epsilonSecond alone. The matter action becomes conformally coupled, so an Einstein-frame matter density cannot be inserted into the old Jordan-frame conserved m,r equations. All observational redshift/distance conventions in the earlier note stay Jordan-frame. This is a classical local equivalence on f>0, not a new statement about the quantum measure, boundaries, sector changes or f=0.

A potential-equation check makes the normalization testable without appealing to a name for this theory:

W_f=f/(3chi)+u/(chi f²),
W_ff=1/(3chi)-2u/(chi f³),
d/dphi=[f/(sqrt(3/2)M_*)]d/df.                                    (6)

The spatially varying degree of freedom arises from coupled curvature/f dynamics in this effective gravitational model. No massless spin2 spectrum of microscopic ADW or emergent spacetime is being constructed by this change of variables; Einstein gravity was already a term of the selected source action.

## 3. A real inhomogeneous perturbation equation on the expanding stationary branch

Use the actual source-selected vacuum stationary branch

u<-1/3, f_b=(-3u)^(1/3)>1,
H_b²=f_b(f_b²-1)/(2sigma t_*²), a(t)=a_i exp[H_b(t-t_i)].

The background has f=f_b constant, T_mu nu0, U_b=3M_*² f_b H_b² and U_f,b=6M_*² H_b². Because the background f is constant, delta f is gauge invariant at linear order and delta(box)f_b=0. Linearizing(3) gives

(box_b-m_J²)delta f=delta T/(3M_*²),
m_J²=2(f_b U_ff,b-U_f,b)/(3M_*²)
     =2f_b³/(sigma t_*²)>0.                                       (7)

Here delta T means the full first variation of the scalar matter trace. At the vacuum background its metric-contraction term vanishes. For each spatial Fourier mode q_k=delta f_k this becomes

ddot q_k+3H_b dot q_k+[k²/a²+m_J²]q_k=J_k,
J_k=-delta T_k/(3M_*²).                                            (8)

No quasi-static or short-wavelength approximation was used. In particular physical sound speed squared is1 for this canonically normalized vacuum scalar. This does not prove that a matter-filled, time-dependent background clusters as CDM. Perturbing mu instead of keeping delta mu0 would add a separate source and would be a different contract.

The remaining metric perturbations are not discarded. Linearizing the metric equation about the same vacuum gives

f_b[delta G_mu nu+3H_b² delta g_mu nu]
 =delta T_mu nu/M_*²+nabla_mu nabla_nu(delta f)
   -g_b,mu nu box_b(delta f)-3H_b² g_b,mu nu delta f.                 (9)

This includes scalar gravitational constraints; solving only(8) does not by itself compute lensing, growth or a density transfer function. A covariantly conserved delta T_mu nu must be supplied consistently, rather than choosing an arbitrary dust trace with incompatible metric stress.

The independent Einstein-frame check gives W_f,b0, W_ff,b=1/chi and

m_E²=W_phi phi,b=2f_b²/(sigma t_*²),
H_E=H_b/sqrt(f_b), m_E²=m_J²/f_b,
m_E²/H_E²=4f_b²/(f_b²-1).                                         (10)

This checks both the sign and the factor of f in the mass/time conversion. In vacuum the linear Einstein-frame metric equation is the cosmological-constant Einstein equation: scalar stress has no linear fluctuation beyond the constant W_b metric term because phi_b is constant and W_phi,b0. The independently propagating scalar obeys the canonical massive equation. This supplies the linear decoupling, rather than merely counting arbitrary field components.

## 4. Positive finite-energy controls, homogeneous limit and the tensor channel

For a homogeneous vacuum mode J0 define lambda as its physical-time exponent. Its two characteristic roots satisfy

lambda²+3H_b lambda+m_J²=0,
9H_b²-4m_J²=-f_b(7f_b²+9)/(2sigma t_*²)<0.

Their real part is-3H_b/2. Multiplying by t_* reproduces exactly the eigenvalues of the prior constrained two-variable FRW Jacobian. This is a cross-check on the covariant perturbation construction, not a new assumption of stability.

For every finite k let E_k=(|dot q_k|²+[k²/a²+m_J²]|q_k|²)/2. Direct differentiation of(8) gives

E_k'=-3H_b|dot q_k|²-H_b(k²/a²)|q_k|²+Re[conj(dot q_k)J_k].         (11)

In vacuum this is nonincreasing and positive definite because m_J²>0. Therefore finite-energy Fourier data have no unbounded growing scalar mode in this precise linear vacuum problem. For a consistent trace source, Young's inequality yields

E_k(t)<=E_k(t_i)+(1/(6H_b))integral_(t_i)^t |J_k(v)|²dv,

retaining additional nonpositive terms. This is an absolute source-to-energy estimate, not a full matter-response solution. Standard modewise integration or the finite-energy Klein–Gordon evolution constructs the actual linear solution; no declaration of formal degree-counting replaces it. Summing/integrating(11) gives the corresponding spatial finite-energy bound for data and forcing in the stated energy/L² spaces, by Fourier truncation and limit. No ultraviolet-finite quantum vacuum variance is claimed.

The transverse traceless vacuum metric perturbations have the quadratic Jordan action

S_T^(2)=(M_*² f_b/8)integral dt d³x a³
              [dot h_ij dot h_ij-a^(-2)partial_l h_ij partial_l h_ij],
ddot h_ij+3H_b dot h_ij-a^(-2)laplacian h_ij=0.                     (12)

The coefficient is positive. There are the usual two independent TT polarizations for a nonzero Fourier wave vector, with unit propagation speed and no tensor mass. Their vacuum kinetic/gradient energy is nonincreasing by the same computation with mass0. The zero-k constant tensor amplitude is allowed and is not falsely classified as exponential decay. This is the tensor sector of the assumed effective gravitational action, not a microscopic derivation of physical graviton degrees of freedom from the ADW field content.

At the equilibrium Minkowski limit u=-1/3,f_b1,H_b0, the scalar mass squared remains2/(sigma t_*²)>0 and its wave equation is ordinary massive Klein–Gordon. Formula(11) without H terms still holds, while the forcing estimate containing1/H_b is inapplicable. Instead sqrt(E(t))<=sqrt(E(t_i))+(1/sqrt2)integral|J| follows directly. For u>-1/3 the stated positive expanding branch does not exist, so none of its de Sitter estimates is used. f=0, sigma0, chi0, negative kinetic normalization and arbitrary changes of sector are excluded, never filled with a nominal numerical value.

## 5. Remaining original obligations and actual next action

This constructs an actual covariant trace equation, canonical positive-kinetic carrier, inhomogeneous vacuum Fourier modes/energy estimates and tensor channel for the SAME selected KV2008 ansatz. It advances the explicit perturbation obligation rather than changing the target to a scalar reporting API. It is manually accepted mathematics only, with its complete nonauthor scientific review retained separately; native, numerical and empirical verification remain required.

Original late-time prediction still needs the nonstationary matter/radiation background and its full metric/matter/scalar perturbations, initial-state/parameter/source selection, local-G and physical-time calibration, an observationally justified rapid-oscillation averaging map and actual sound-horizon/lensing/growth/SN transfer. It also needs a validated constrained evaluator with event/refinement/residual/rounding errors and a same-data likelihood with priors and identifiability. Neither the positive de Sitter mass nor the bare vacuum pressure assigns a universal CPL pair, predicts the magnitude without calibrated inputs or establishes empirical viability/exclusion. The2011plateau transition and independent microscopic ADW/vacuum-scale duties remain separate BUILDs. ROOT owns native/runtime/integrated acceptance and canonical closure; no new gate, scope reduction or deferral is introduced.

Complete original independent manual review: [scientific verification](reviews/KV2008_COVARIANT_PERTURBATIONS.md). The publication scientific lead accepts the original BUILD; this status records scoped mathematical acceptance and does not close the finding or publication.
