# Reviewed-source delivery: CONSTRUCTION — E2_INTERACTING_PHYSICAL_TERMINAL_CURRENT_NOISE

This is the COMPLETE original construction, transported as documentary SOURCE DATA. Scope: Declared-carrier interacting quantum current/noise; complete39 groups, K1 full-CAR grandcanonical KMS and S2 vacuum control, manual science only. Lead intake 76747f67 accepts that exact scientific scope, not physical/device/native/gate/main completion. Original author-pending statements describe their dated author snapshot and remain unchanged. Full [construction](E2_INTERACTING_PHYSICAL_TERMINAL_CURRENT_NOISE.md), [independent review](reviews/E2_INTERACTING_PHYSICAL_TERMINAL_CURRENT_NOISE.md) and [fixed source/model](source-models/E2_INTERACTING_PHYSICAL_TERMINAL_CURRENT_NOISE.md) are delivered together. All original process failures, chronology, mandatory historical rejections and remaining physical BUILD obligations are retained. No mathematics or review verdict is shortened or changed. No runtime/native/application/publication acceptance follows.

<!-- BEGIN COMPLETE ORIGINAL CONSTRUCTION -->

# Interacting physical AB contacts: two-time quantum current/noise, explicit vertex and finite-time control

Status: COHERENT K1 AUTHOR REPAIR r3, awaiting fresh genuinely nonauthor WHOLE scientific verification and lead intake. The full r2 review f74a104c independently verified the S1 equal-time state proof but rejected whole-note acceptance for using physical-H dynamics in the nonzero-chemical-potential full-CAR KMS claim. This successor preserves the physical model, nonzero chemical potential, S1 and all39 original numbered groups, and repairs the grandcanonical dynamics and complete analytic/local-limit proof. The fixed r3 SOURCE_MODEL was genuinely saved at2026-10-18T11:38:55.063759+00:00 BEFORE new K1 mathematics. The original r1 model-before-mathematics failure remains unwaived; no original acceptance/compliance, runtime/native or full device/Hawking/calibration completion is implied.

## 1. Physical AB graph and explicit grounded-gate electrostatics

Keep the terminal predecessor's finite physical AB pi-orbital graph, physical spin up/down, q=-e and actual finite-band half-chain contact Hamiltonian h. A concrete four-orbital embedded subgraph is

    r_1=(-b,0,d), r_2=(0,0,d),
    r_3=(0,0,d+c), r_4=(b,0,d+c),                            (1)

with intralayer bonds1–2 and3–4, vertical AB bond2–3, b>0 the declared bond length and c>0 interlayer distance. Both end orbitals may have the nonzero predecessor contacts; larger finite AB patches are allowed with the same construction. These are actual orbital positions and physical bonds, not a continuum optical-response substitution. Named b,c,d, gamma0,gamma1, lead hoppings, onsite energies and contact hoppings are selected physical inputs, not measured values or an error-certified Wannier fit.

The gate is the grounded perfect plane z=0 and epsilon>0 is a homogeneous static dielectric permittivity in SI. At site i choose normalized rho_i(x)=3/(4pi a_i^3) on its radius-a_i sphere and zero elsewhere. Require z_i>a_i>0 and |r_i-r_j|>a_i+a_j. In (1), taking every a_i<min(d,b/2,c/2) suffices. The Dirichlet electrostatic Green kernel is

    G_D(x,y)=(1/(4pi epsilon)) [1/|x-y|-1/|x-y*|],
    y*=(y_x,y_y,-y_z),
    U_ij=e^2 integral dx dy rho_i(x)G_D(x,y)rho_j(y).         (2)

The first term has the unit point source under -epsilon Laplacian; the image term is harmonic for z>0, cancels the boundary value and decays at infinity. Uniqueness follows by integrating epsilon|grad phi|² for the difference with zero boundary/decay, first at finite radius then taking its vanishing surface term. Thus this is the actual specified static gate solution. Its quadratic form equals epsilon integral |grad phi|², so the cloud matrix is PSD. Every pair entry is positive since image distance exceeds actual distance for z_x,z_y>0.

The potential of a normalized uniform sphere is 1/r outside and (3a²-r²)/(2a³) inside. Matching value/normal derivative at r=a and its Poisson source proves this expression. Averaging the interior potential uses average r²=3a²/5 and gives6/(5a). The potential of a disjoint sphere and that of every image sphere is harmonic throughout the other sphere; the harmonic mean-value property applied twice makes its double average exactly the inverse center distance. Therefore, with k_e=e²/(4pi epsilon),

    U_ii=k_e[6/(5a_i)-1/(2z_i)],
    U_ij=k_e[1/R_ij-1/R*_ij], i!=j.                          (3)

The image spheres cannot overlap the originals because z_i>a_i. These finite coefficients have units J, not J m² as the separate homogeneous kinetic kernel. For (1), R_12=R_34=b, R_23=c, R_13=R_24=sqrt(b²+c²), R_14=sqrt(4b²+c²); their image distances are respectively sqrt(b²+4d²), sqrt(b²+4(d+c)²), 2d+c, sqrt(b²+(2d+c)²), sqrt(4b²+(2d+c)²). Equations (2)/(3) give all ten entries, with no uncomputed normalization factor.

Let N_i=n_iup+n_idown and nu_i be fixed background charges in electron-number units with the same cloud shapes. Start from classical electrostatic energy(1/2)(N-nu)^T U(N-nu), remove only each individual electron's divergent/model-dependent BARE Coulomb self-energy B_ii N_i/2, B_ii=6k_e/(5a_i), and discard the static background constant. Do NOT remove its physical self-image energy. N_i²=N_i+2n_iup n_idown gives

    E_el = V + sum_i u_i N_i,
    V=sum_i U_ii n_iup n_idown + sum_(i<j) U_ij N_i N_j,
    u_i=-k_e/(4z_i)-sum_j U_ij nu_j.                         (4)

In particular the physical single-electron self-image energy is negative -k_e/(4z_i). Subtracting the entire screened U_ii N_i/2 without restoring this term would be wrong. Put the explicit static u_i into h's onsite energies, in addition to any declared external gate/material onsite term. Keep V as the bounded quartic interaction. lambda is a dimensionless interpolation parameter in H_lambda=H_0+lambda V; the selected physical charge model has lambda=1. A perturbative estimate need not be small there; no weak physical coupling is asserted by notation.

For spin-orbitals alpha=(i,sigma), U_alpha,beta=U_ij and identical alpha excluded,

    V=(1/2)sum_(alpha!=beta) U_alpha,beta
                      c_alpha† c_beta† c_beta c_alpha,
    w=||V||=sum_i U_ii+4 sum_(i<j) U_ij.                    (5)

All coefficients are positive and the fully occupied central configuration attains this upper bound, proving equality. Equivalently its antisymmetric pair tensor is U_alpha,beta(delta_alpha,gamma delta_beta,delta -delta_alpha,delta delta_beta,gamma) with coefficient1/4 in the conventional four-index form. CAR gives exact identical-spin onsite exclusion and outgoing exchange signs. The physical spin sum is inside V and I=I_up+I_down; INTERACTING noise has four spin-pair terms, not an automatic multiplier two.

This is an explicitly defined rigid site-charge approximation. True Wannier pair exchange, orthogonalization, finite orbital tails, dynamical dielectric/gate fluctuations and material parameters remain owed. Section12 gives a residual comparison domain; the density approximation is not claimed exact for actual graphene merely because its electrostatics is solved.

## 2. Non-Gaussian dynamics, state and unchanged current/contact identity

H_0 denotes the full free AB-plus-contact CAR generator, including (4)'s fixed one-body potentials. Throughout the real-time quench and response construction, alpha_lambda denotes PHYSICAL H_lambda evolution; it is not silently relabeled as grandcanonical evolution. The distinct equilibrium group tau_lambda is defined in section9. Its one-particle h is bounded; a finite infinite-lead many-body energy or Gibbs trace is not needed. For a reference positive state omega, define alpha_0^t by the predecessor CAR automorphism and V_t=alpha_0^t(V). The norm-convergent time-ordered cocycle S(t) solves

    dS/dt=-(i lambda/hbar)V_t S, S(0)=1,
    A_lambda(t)=S(t)† alpha_0^t(A)S(t).                      (6)

The series has bound sum(|lambda|wt/hbar)^n/n!, is unitary for real lambda, and defines the interacting automorphism on the CAR algebra. The state omega composed with it is positive and normalized, generally NON-Gaussian. A sudden interaction switch at0 supplies the work lambda omega(V) in the unchanged prepared state; a smooth strength ramp adds dot(lambda) omega_t(V) to external power. The constant-strength formulas below concern times after that switch, not zero-cost preparation. In the main quench omega is the exact chosen Q/tail free product state of the predecessor, with arbitrary positive-contraction Q covariance and thermal free tails; Q includes the measured first sites. A correlated positive non-Gaussian initial omega is also allowed, retaining its actual higher moments. It is not Wick-replaced.

The measured actual contact current is the same finite-rank bond bilinear as before, per spin,

    I_a,sigma=(iq/hbar)[v_a* c_1a,sigma† c_i,sigma
                                  -v_a c_i,sigma† c_1a,sigma],
    I_a=sum_sigma I_a,sigma, a_a=2||j_a||_1 >= ||I_a||.       (7)

For any local bond current use its corresponding finite rank. V depends only on site numbers, so [V,N_i]=0, [V,N_total,sigma]=0. Thus the exact physical continuity identity sum_a I_a,lambda(t)=dQ_C,lambda(t)/dt holds. It holds coefficientwise in lambda, including every mean and two-time covariance. Gauge phases cancel in each density factor, so local Peierls/scalar gauge covariance survives. V has no derivative with respect to a fixed contact Peierls flux; the current and contact Hessian are unchanged operators, with changed state/evolution. In a driven finite-volume/local-relative work balance, hopping electric work still equals sum I V_bond; the interaction energy participates through its time derivative and boundary flux. If the ACTUAL dielectric/gate kernel is driven, partial_t U and its response/noise are additional terms, not included by this fixed-kernel proof.

No unique interacting NESS, stationary scattering-state replacement, asymptotic completeness or continuum kinetic limit is inferred from the free terminal predecessor.

## 3. First independent route: actual first and second mean/noise orders

Use coefficients without factorials: A_lambda(t)=A_0(t)+lambda A_1(t)+lambda² A_2(t)+... . Expanding (6) directly gives, with B_0(s)=alpha_0^s(B),

    A_1(t)=(i/hbar) integral_0^t du [V_u,A_0(t)],
    A_2(t)=-(1/hbar²) integral_(0<u<v<t) du dv
                                  [V_u,[V_v,A_0(t)]].      (8)

The earlier time is the OUTER commutator; its reversal would not generally be correct. Derive it by multiplying the anti-time-ordered S† on the left of A_0 with time-ordered S on the right and grouping the two mixed-order triangles. The same equations apply to B. They contain the explicit quartic (5), not an unspecified norm-only interaction.

For fixed initial omega, all first/second mean and genuinely ordered raw/connected coefficients are

    m_An=omega(A_n),
    F_0=omega(A_0 B_0),
    F_1=omega(A_1 B_0+A_0 B_1),
    F_2=omega(A_2 B_0+A_1 B_1+A_0 B_2),
    C_0=F_0-m_A0 m_B0,
    C_1=F_1-m_A1 m_B0-m_A0 m_B1,
    C_2=F_2-m_A2 m_B0-m_A1 m_B1-m_A0 m_B2.                 (9)

In particular the two-observation A_1 B_1 term and the first-order mean-product term cannot be dropped. Equations (8)/(9), with V's actual finite sum, are explicit finite time integrals of known CAR monomials for EVERY current pair, not an interaction-renormalized free-noise assertion. Lesser order reverses the measured operator order; symmetrization is half their sum.

For the quasifree reference, each integrand is evaluated by actual free covariance R_0 and propagator e^-iht/hbar. In normal order,

    omega_0(c†(f_1)...c†(f_p)c(g_p)...c(g_1))
                              =det[omega_0(c†(f_i)c(g_j))]. (10)

For a non-normal string first apply CAR, including its actual unequal-time anticommutator, or sum signed pairings of its full ordered contraction matrix. This derives both direct and exchange terms, all spin labels and equal-time contacts. Mean order1 has at most six fields/order2 ten; raw noise order1 eight/order2 twelve, hence finite determinants of sizes3/5 and4/6 after ordering. These counts do not replace the formula. Arbitrary correlated initial states instead retain their actual monomial expectations in (9); the same evolution and remainder below apply. Interacting evolution does not GENERALLY preserve quasifreeness; nonzero lambda alone is not a proof that every state at every time is nonGaussian. Reference Wick rule(10) therefore cannot be transferred to the full interacting noise without separately establishing the relevant state's quasifree property. The S1 result below proves nonGaussianity for its SPECIFIC coherent initial state and positive-time interval, by an equal-time witness, not by the unequal-time vertex alone.

An exact same-Hamiltonian countercontrol prevents the universal inference. Let Omega be the zero-particle Fock vacuum on the full AB/contact graph, retaining every original nonzero hopping, actual onsite/intersite quartic coefficient and any nonzero lambda. Since h is number conserving and V is normal ordered and number conserving, H_0 Omega=0 and V Omega=0 (an optional scalar energy shift only contributes a phase). Equivalently every free-time V_t annihilates Omega, so the full cocycle series gives S(t)Omega=Omega. The free dynamics leaves the vacuum state invariant, and hence so does physical interacting alpha_lambda. Its one-particle covariance remains R=0 and it is a positive normalized gauge-invariant quasifree state at EVERY time. Its Wick identities are valid even though lambda!=0. This is an initial-state countercontrol, not deleting any hopping/interaction, changing the finite-beta/nonzero-mu equilibrium family or replacing the S1 state or the device target by vacuum. It disproves only the inherited universal sentence; S1 and the nonzero dynamic vertex retain their explicit separate domains.

## 4. Independent closed-contour construction and explicit order matching

First do a finite lead box with its actual initial density matrix; take the fixed-time limit justified in section8. Insert fermionic coherent resolutions of identity between each short-time forward and backward evolution. The initial density is the boundary kernel; normal-ordered (5) contributes the actual quartic Grassmann polynomial, hopping gives the free quadratic action. The contour is 0 forward to t, then backward to0; opposite branch signs come from the inverse evolution. For the declared quasifree reference boundary, integrating the Gaussian noninteracting lead fields produces the same finite-band surface self-energy and original initial/cross blocks as the predecessor, while the central quartic term remains unintegrated. For a general non-Gaussian correlated initial state the boundary density kernel contains additional vertices: retain those exact boundary insertions/monomial expectations in (9)/(11), rather than calling that boundary Gaussian or dropping its correlations. Thus the central generating functional is non-Gaussian. Lead elimination is exact; it does not assert Gaussian central noise.

For t>=s put A at the returning t endpoint and B on the forward s branch. Directly following the contour gives

    F_lambda(t,s)=omega[S†(t) A_0(t) S(t,s) B_0(s) S(s)],
    S(t,s)=S(t)S†(s),
    F_lambda=omega(T_C A(t_-)B(s_+)
                      exp[-i lambda integral_C dz V_z/hbar]).(11)

No real-time normalization denominator is discarded: at zero observable/source the same forward/backward paths cancel exactly, S†S=1. Initial interaction dependence is absent only for the declared fixed-state quench; equilibrium needs the vertical branch and denominator of section10. A Peierls source on the two branches differentiates to the actual current; log generates its connected covariance. The second derivative of the current operator is the contact RESPONSE Hessian, not an extra delta noise in covariance of two undifferentiated measured currents.

For compact notation below angle brackets mean omega, A=A_0(t), B=B_0(s). Expanding the three physical contour segments independently gives

    F_1=(i/hbar){ integral_0^t du <V_u A B>
                   -integral_s^t du <A V_u B>
                   -integral_0^s du <A B V_u> },            (12)

and hbar² F_2 is the following SIX terms:

    -integral_(0<u<v<t) du dv <V_u V_v A B>
    -integral_(s<u<v<t) du dv <A V_v V_u B>
    -integral_(0<u<v<s) du dv <A B V_v V_u>
    +integral_0^t du integral_s^t dv <V_u A V_v B>
    +integral_0^t du integral_0^s dv <V_u A B V_v>
    -integral_s^t du integral_0^s dv <A V_u B V_v>.           (13)

These signs follow respectively from two backward, two middle-forward, two early-forward, and the three cross-segment placements. Expanding (8) into its four double-commutator products and partitioning each square into u<v and v<u yields precisely (13) after including A_1 B_1. At first order the A V_u B terms on0<u<s cancel between the two commutators, giving (12). This is explicit order-by-order route agreement on the SAME Hamiltonian, initial state and cut; it is not merely equating two names or defining their answers to match. For s>t exchange the branch placements while retaining the requested operator order. Mean subtraction in (9) gives connected contour noise, including all vertex and initial pieces.

## 5. A genuinely nonzero interaction vertex, not a dressed free bubble

The central spin-resolved charge symmetry makes the exact one-particle Green functions block diagonal in spin in any state invariant under separate spin-number rotations. A bubble with two one-particle Gs and disjoint up/down current vertices is therefore ZERO for cross-spin noise, even if those Gs are dressed. The exact interacting cross covariance need not be zero.

For this vertex formula assume the free reference is quasifree and spin-block diagonal (hence its spin blocks are independent). To see the actual first-order contour vertex, define D_XY(z,z')=omega_0(T_C X(z)Y(z'))-omega_0(X(z))omega_0(Y(z')) for free bilinears. The opposite-spin part of V is sum_ij U_ij n_iup n_jdown. Independent free spin blocks factor, and connected differentiation of (11) gives

    C_up,down^(1)(t,s)=-(i/hbar)sum_ij U_ij integral_C dz
          D_(I_up,n_iup)(t_-,z) D_(n_jdown,I_down)(z,s_+).   (14)

Here C^(1) is the lambda coefficient; D is a covariance, not an i-multiplied Green function. Tadpoles attached to a single measured spin cancel against the mean subtraction in (9). Pure same-spin vertices cannot connect the independent other measured spin at this order. CAR evaluation of each D gives its actual occupied/empty free propagators. At order2 use (13)/(9): two quartic insertions plus all subtractions, with their full signed six-pair Wick sums. No class of two-vertex/self-energy/exchange graphs is omitted by an assumed factorization; the explicit six real domains fix every term, including interaction vertices linking both measurements.

For a concrete local proof that (14) is nonzero, choose an actual contact a–i with phase gauged to real v!=0, U=U_ii>0. In each spin put ONE particle in the normalized coherent orbital (|a>+|i>)/sqrt2, all other central/lead orbitals empty. This is a gauge-invariant quasifree Slater state with separate spin-number symmetry, valid at the enlarged Q/tail partition with vacuum tails (zero-temperature chemical potential below their bands). All AB and contact hoppings stay nonzero; this is an initial-state control, not deleting the graph. On each one-particle spin sector let z=|a><a|-|i><i|, x and y be Pauli matrices, c_v=qv/hbar. Then n_i=(1-z)/2 and I_sigma=-c_v y_sigma. The initial spin states have <x>=1,<y>=<z>=0. Since [n_i,I]=-i c_v x,

    [V,I_up]=-i U c_v x_up n_idown
          on the occupied control subspace,
    <n_idown y_down>=i/2,
    C_up,down,lambda(t,0)
            =-i lambda U c_v² t/(2hbar)+O(t²).              (15)

The free cross covariance vanishes identically by spin independence. Other central density terms have empty-site factors in this first derivative and vanish; hopping changes only higher time orders. Thus (15) holds on the FULL nonzero physical AB/contact graph, not just an isolated favorable two-level replacement. The term is an imaginary ordered covariance, permitted at unequal times; its Hermitian-reversed counterpart has the conjugate/order relation. It is a real connected quantum four-point vertex which a spin-diagonal dressed bubble misses exactly. This unequal-time vertex by itself does NOT establish nonGaussianity of the instantaneous evolved state; the separate equal-time proof below is necessary. For fixed real lambda!=0 it is nonzero on a sufficiently small positive-time interval by the explicit Taylor bounds below.

### S1 repair: instantaneous state, countercontrol and quantitative nonzero interval

The logical distinction is essential: quasifree Wick identities constrain bare CAR fields evaluated in one state at one common time. Interacting Heisenberg fields at different times are nonlinear in the initial bare fields. Consequently a connected history can violate a free/dressed two-point factorization even when the instantaneous state is stationary and Gaussian.

An exact countercontrol uses just two fermionic modes with H=U n_up n_down and rho=1/4 times the four-dimensional identity. This rho is positive, normalized, stationary and gauge-invariant quasifree with one-particle covariance R=1/2 times the identity. For theta=Ut/hbar, the CAR give c_up(t)=exp(-i theta n_down)c_up. Factorizing the initial maximally mixed spin blocks therefore gives

    omega(c_up(t)c_up†)=(1+exp(-i theta))/4,
    omega(c_up(t)c_up† n_down)=exp(-i theta)/4,
    omega(n_down)=1/2,
    omega(c_up(t)c_up† n_down)
       -omega(c_up(t)c_up†)omega(n_down)
                       =(exp(-i theta)-1)/8.             (15a)

In detail omega(1-n_up)=1/2, omega(exp(-i theta n_down))=(1+exp(-i theta))/2 and omega(n_down exp(-i theta n_down))=exp(-i theta)/2. All cross-spin one-particle contractions vanish, so a Wick replacement using only those history two-point functions would incorrectly set this connected term to zero whenever theta is not a multiple of2pi. The state nevertheless remains the SAME Gaussian rho at every time: [rho,H]=0. There is no contradiction because c_up(t) is a nonlinear dressed operator. This two-mode example is a logical countercontrol, NOT a replacement for the physical AB/contact carrier or for the full-graph control in (15).

Now retain exactly the full-graph state and physical inputs of (15): one coherent particle (|a>+|i>)/sqrt2 in each spin, every other central/lead orbital empty, all AB/contact hoppings nonzero, actual U=U_ii>0 and real v!=0. Write N=n_iup and B=I_a,down=-c_v y_down on the initially occupied two-site spin sector, with c_v=qv/hbar. Their bare operators commute. Let omega_lambda,t=omega_0 composed with alpha_lambda^t, and define the SAME-TIME connected observable

    K(t)=omega_lambda,t(N B)
                  -omega_lambda,t(N)omega_lambda,t(B)
        =omega_0(N_lambda(t)B_lambda(t))
                  -omega_0(N_lambda(t))omega_0(B_lambda(t)),
    K(0)=0,
    Kprime(0)=lambda U c_v/(4hbar).                       (15b)

Here is the complete derivative including its mean subtractions. Since V is a density interaction, [V,N]=0. Its onsite opposite-spin contribution to [V,B] is -i U c_v N x_down; other terms contain initially empty central-site densities and have zero expectation, including after multiplication by N. Initial independence of spin blocks gives <N>=1/2, <N²>=1/2 and <x_down>=1. Thus the interaction contribution to the raw derivative is (lambda U c_v/hbar)<N² x_down>, and the derivative of the product of means contributes (lambda U c_v/hbar)<N><N x_down>. Their difference is lambda U c_v/(4hbar). All free terms cancel as a whole: at lambda=0 the actual spin-preserving free dynamics and the factorized initial spin state keep K_free(t)=0 for EVERY time, on the whole graph. No individual hopping derivative is silently discarded. Extra occupied-site interactions would change this control, but those sites are exactly empty in the specified state; no physical hopping or population is retuned.

A finite interval follows without a formal O(t²) alone. This state lies in the conserved two-particle sector. With the SAME w=||V|| from (5), let K_2=2||h||+|lambda|w, an energy bound on ||H_lambda|| in that sector. The exact local spin-current norm is ||B||=|c_v|, and ||N||=1. For r_2(x)=exp(x)-1-x and t>=0, nested commutator bounds and the ordinary product Taylor series give

    |K(t)-lambda U c_v t/(4hbar)|
       <=|c_v|[r_2(2K_2 t/hbar)+r_2(4K_2 t/hbar)]
       <=2|c_v| r_2(4K_2 t/hbar).
    T_* = min{hbar/(4K_2),
                    |lambda|U hbar/(128 exp(1)K_2²)} >0,
    0<t<T_* implies
            |K(t)| >= |lambda|U|c_v|t/(8hbar)>0.          (15c)

To verify the bounds, alpha_t(N)alpha_t(B)=alpha_t(NB), so the raw product Taylor coefficients are bounded by |c_v|(2K_2/hbar)^n/n!. Each mean has its corresponding exponential majorant; convolution bounds the product of means by |c_v|(4K_2/hbar)^n/n!. Subtract their constant and linear terms, already evaluated in (15b), to obtain the first line. The elementary series bound r_2(x)<=exp(x)x²/2 then bounds the remainder by16|c_v|exp(1)K_2²t²/hbar² when t<=hbar/(4K_2). The second upper bound defining T_* makes that remainder at most half the magnitude of the linear term. For fixed real lambda!=0, U>0 and v!=0, K_2>0 and both bounds are positive times; K has units of current, Kprime has units of current/time. At lambda=0, the exact free K is zero, and no nonzero interval is asserted. This bound is a finite-time control, not a calibrated stationary rate or a useful physical-band guarantee.

Finally, H_lambda commutes with the separate total up/down particle numbers and the initial state is invariant under their two independent U(1) rotations. Hence the instantaneous state retains zero normal cross-spin contractions and zero anomalous contractions. Were that instantaneous state quasifree, its spin-block-diagonal covariance would force Wick factorization of the even up-spin density N and even down-spin current B, so K(t) would be zero. The strict same-time inequality (15c) contradicts that consequence and proves instantaneous nonGaussianity for0<t<T_* in THIS full-graph control. This is the missing state proof. It preserves the valid dynamic vertex (15) while refusing the invalid implication exposed by the stationary Gaussian countercontrol (15a).

## 6. Nonzero physical mean and second-order ordered-noise controls

For a separate full-graph control occupy a_up, a_down and i_down, with every other orbital empty (a three-particle Slater state, vacuum tails). The down cut is initially Pauli blocked, and the up current creates the actual intermediate double occupation D at i. Set Delta=epsilon_i-epsilon_a, including the one-body image/background/external terms from (4). Initially V=0; on D its value is U. Let p_up be the probability of this direct transferred configuration. Its one-hop amplitudes through third time order are the usual actual Hamiltonian products, and their Delta/U-dependent terms give

    [p_up,lambda(t)-p_up,0(t)]_(through t^4)
       =-|v|²(2Delta lambda U+lambda² U²)t^4/(12hbar^4),
    [<I_a,lambda(t)>-<I_a,0(t)>]_(through t^3)
       =-q |v|²(2Delta lambda U+lambda² U²)t^3/(3hbar^4).
                                                                    (16)

For clarity the probability coefficient follows by writing the direct two-configuration Hamiltonian entries 0,v;v,delta with delta=Delta+lambda U: the transition amplitude has -iv t/hbar, -v delta t²/(2hbar²), and +iv delta² t³/(6hbar³). Their square contributes -v²delta²t⁴/(12hbar⁴). Other kinetic loops contribute additional lambda-INDEPENDENT t⁴ terms. A path involving another site and an interaction needs additional hops: at this order the only interaction-dependent final one-hop configuration is D. A two-hop final configuration first has probability t⁴ and its order-two amplitude cannot contain V because V kills the initial state. The initially blocked down cut and other contacts require extra hops for interaction dependence. This proves (16) for the original measured TOTAL contact current on the full graph. Delta=0 removes the first-order mean coefficient but not the negative second-order transfer-probability coefficient and corresponding NONZERO signed-current coefficient; Delta!=0 gives both. No physical hopping is set to zero.

The SAME three-particle state gives a direct second-order ordered auto-noise coefficient. Initially <I_a>=0 and I_a acting on the state creates only D with squared amplitude c_v². Since V kills the initial state,

    <[V,I_a] I_a>=-U c_v²,
    <[V,[V,I_a]] I_a>=U² c_v²,
    C_aa,lambda(t,0)= C_aa,0(t,0)
       -i lambda U c_v² t/hbar
       -lambda² U² c_v² t²/(2hbar²)
       +terms linear in lambda of order t² + O(t³).        (17)

The unspecified linear t² coefficient is fully supplied by (8)/(9)/(13), not claimed zero; the displayed lambda² t² coefficient is exact and cannot be canceled by a kinetic term at that joint order. Thus both first and second interaction orders are nontrivial quantum noise, not only a formal Dyson definition. With X(T)=integral_0^T sum_a I_a(t)dt=Q_C(T)-Q_C(0), the initial state has definite Q_C, and its transfer-variance interaction-dependent t⁴ term is q² times the probability coefficient in (16). It is also the double integral of the exact ordered covariance; physical nonnegative exact variance is not replaced by a potentially negative truncated correction.

All these controls have finitely many particles in vacuum tails. On the n-particle sector ||H_lambda||<=n||h||+|lambda|w=:K_n. The Taylor remainder for a current evolved to time t, after degree r in time, is at most

    a_a exp(2K_n|t|/hbar)(2K_n|t|/hbar)^(r+1)/(r+1)!.       (18)

Multiplication by a second current costs its norm. Differences between lambda and0 use the sum of their bounds. These actual finite-sector bounds justify a small positive-time interval where the nonzero leading coefficients persist; they do not give a stationary calibrated rate. Zero lambda removes every interaction coefficient; disconnecting the actual hopping makes its current and all its covariances zero; density interactions cannot violate total local charge storage. Exact spin/Pauli controls and the nonzero cross vertex above remain simultaneously.

## 7. Actual finite-time, filtered and initial-state remainder

Write r_3(x)=exp(x)-1-x-x²/2<=exp(x)x³/6 for x>=0. Nested commutators in (8) obey

    ||A_n(t)|| <= ||A||(2wt/hbar)^n/n!,
    ||A_lambda(t)-sum_(n=0)^2 lambda^n A_n(t)||
                             <= ||A|| r_3(2|lambda|wt/hbar).
                                                                    (19)

This follows from ||[V_t,X]||<=2w||X|| and the ordered-simplex volume t^n/n!; it is independent of lead volume or particle number. Convolving the A and B coefficient bounds proves an analogous product bound with x=2|lambda|w(t+s)/hbar. A positive normalized omega has norm1. The raw expectation and the product of its two means each have the same exponential majorant, hence

    |C_lambda(t,s)-sum_(n=0)^2 lambda^n C_n(t,s)|
                <=2 a_a a_b r_3(2|lambda|w(t+s)/hbar).      (20)

This is for the exact connected ordered covariance, including vertex/mean terms, not a rate or PSD approximation. For real probes f,g supported in[0,T], multiply (20) by |f(t)g(s)| and integrate, obtaining

    filtered error <=2 a_a a_b ||f||_1||g||_1
                                  r_3(4|lambda|wT/hbar).   (21)

Exact filtered variances are nonnegative; a finite-order correction or polynomial need not be PSD by itself. Outside the stated finite-time/beta domains the bound may be too large to be useful. In particular lambda=1 does not guarantee smallness for a physical gate interaction.

For any two positive initial states whose norm as functionals differs by eta, the SAME dynamics gives mean mismatch<=eta a_a and connected covariance mismatch<=3 eta a_a a_b: one eta from the raw product and two from telescoping its means. Thus initial correlations cannot be discarded; either their actual higher monomials enter (9), or a measured/proved eta pays this error. Norm convergence of infinite-volume global states is not assumed; section10 instead proves local-state convergence constructively.

## 8. Separate finite-lead truncation at fixed probe time

Cut each tail at graph distance at least d from Q containing all central interaction sites and measured currents. Extend the cut Hamiltonian with decoupled outer tails on the SAME one-particle Hilbert space. Let ||h||,||h_L||<=H_* and x=H_*T/hbar. Polynomial paths of degree n<d cannot reach the changed bond, so

    epsilon_U=2exp(x)x^d/d!
       >=sup_(|t|<=T) ||P_Q(e^-iht/hbar-e^-ih_Lt/hbar)||.    (22)

The CAR norm of c(f) is ||f||. Each quartic monomial of (5) has four unit-norm free orbitals; telescoping them gives ||V_t-V_t,L||<=4w epsilon_U. Unitarity and Duhamel for the interaction-picture cocycles then give

    ||S(t)-S_L(t)||<=4|lambda|wt epsilon_U/hbar,
    ||I_a,lambda(t)-I_a,lambda,L(t)||
                 <=2a_a epsilon_U(1+4|lambda|wt/hbar).      (23)

The first2a_a epsilon_U is the free bilinear error and twice the cocycle difference supplies the rest. For the SAME infinite initial state restricted to the cut observables, connected covariance error on[0,T]^2 is therefore at most

    8a_a a_b epsilon_U(1+4|lambda|wT/hbar).                  (24)

Indeed the raw-product error is b deltaA+a deltaB and the mean-product error is bounded by the same quantity. Multiply by the probe L1 norms for the filtered bound. A separately prepared finite Gibbs/product state must additionally pay its actual local/state mismatch; it is not silently the original state compression. Take L->infinity at fixed T/filter first. These bounds do NOT justify a finite-lead NESS, an unrestricted long-time lambda expansion, or exchanging L,time and weak-coupling limits.

## 9. True interacting equilibrium state: positivity and normalization

The quench state in section2 is generally not KMS. A DISTINCT equilibrium construction chooses common beta>0 and arbitrary real chemical potential mu, INCLUDING nonzero mu, with the FULL COUPLED free covariance R=f_beta(h-mu) and its actual Q-tail correlations. Here beta has units inverse energy. Define the gauge automorphism gamma_theta on the CAR algebra by gamma_theta(B)=exp(i r theta)B for a charge-grade-r monomial, equivalently [N,B]=rB in finite volume. In particular annihilation has r=-1, creation has r=+1, and densities/currents/V are neutral. This gauge group exists directly on infinite CAR; no infinite total-number element or Gibbs trace is asserted.

In finite lead volume H_lambda,L=dGamma(h_L)+lambda V is the PHYSICAL Hamiltonian and K_lambda,L=H_lambda,L-mu N_L is the GRANDCANONICAL generator. Since [H_lambda,L,N_L]=0, their exact real-time relation, with time in seconds, is

    tau_lambda,L^t = gamma_(-mu t/hbar) composed alpha_lambda,L^t,
    tau_lambda^t   = gamma_(-mu t/hbar) composed alpha_lambda^t,
    tau_lambda^t(B_r)=exp(-i mu r t/hbar)alpha_lambda^t(B_r). (25a)

The infinite relation defines a strongly continuous automorphism group because physical dynamics and gauge commute. It is also the bounded-local-perturbation construction from free one-particle h-mu: V is neutral, so tau_0^t(V)=alpha_0^t(V), their interaction cocycles S(t) are IDENTICAL and gauge invariant, and tau_lambda^t(B)=S(t)†tau_0^t(B)S(t). Thus all physical alpha evolution, currents, quench work and S1 are unchanged; only the full-CAR equilibrium KMS group is tau. The full coupled free state is beta-KMS for tau_0, while its finite-volume density is exp(-beta K_0,L)/Z_0,L, K_0,L=dGamma(h_L-mu). The interacting finite Fock density is exp(-beta K_lambda,L)/Z_lambda,L and is positive normalized. The limiting state will be ordinary beta-KMS for tau, NOT in general for physical alpha on charged CAR.

Let kappa bound ||h_L-mu|| and ||h-mu|| uniformly. For complex free time, every finite-degree CAR monomial is entire. Since V is neutral, alpha_0^(-i hbar u)(V)=tau_0^(-i hbar u)(V) exactly; all chemical gauge factors cancel before any bound. The following unchanged display uses that equality, with u (or the integration variable tau) measured in inverse energy; its bound is justified using h-mu on its four CAR factors:

    V_E(tau)=alpha_0^(-i hbar tau)(V),
    ||V_E(tau)||<=w exp(4kappa tau), 0<=tau<=beta,
    M=beta w exp(4kappa beta).                              (25)

M is dimensionless. Entire analyticity here follows directly from the bounded one-particle exponential on each CAR generator; no unbounded infinite many-body Hamiltonian exponential is postulated. The imaginary-time Dyson solution

    Y(tau)=T_tau exp[-lambda integral_0^tau du V_E(u)]

converges in norm and in finite volume equals exp(tau K_0,L) exp(-tau K_lambda,L), by direct differentiation. For real lambda define, with tau=beta/2,

    omega_lambda(A)=omega_0(Y A Y†)/omega_0(Y Y†).            (26)

The infinite Y is the norm limit of the local free-polynomial cocycle; existence is proved quantitatively in section10. The numerator is positive for A>=0 because Y A Y† is positive. In finite volume cyclic trace gives exactly

    omega_0,L(Y_L A Y_L†)=Tr(e^-beta K_lambda,L A)/Z_0,L,
    D_L=omega_0,L(Y_L Y_L†)=Z_lambda,L/Z_0,L,
    exp(-beta|lambda|w)<=D_L<=exp(beta|lambda|w).             (27)

The partition bounds follow from eigenvalue min–max under the bounded perturbation lambda V. They are independent of lead volume. They pass to the local limit below, proving a genuinely nonzero denominator, positivity and normalization for (26), not merely convergence of formal imaginary-time symbols. This is the selected bounded local perturbation of the chosen free equilibrium state, not an assertion of all interacting states or uniqueness of a driven NESS.

## 10. Explicit local volume control and KMS proof

Here is a constructive fixed-beta limit including the state, not just Y. Replace each complex free orbital in V_E by its degree-N Taylor polynomial in h-mu. At |tau|<=beta its norm is at most exp(kappa beta), and its omitted norm is at most

    e_N=exp(kappa beta)(kappa beta)^(N+1)/(N+1)!.

All these polynomial orbitals lie in a finite set S_N: sites at most N hopping steps from the original finite central support. Their quartic kernel error is <=4w exp(3kappa beta)e_N. Truncate the cocycle Dyson expansion after K insertions. Uniformly for tau<=beta, writing a=|lambda|M, an approximation Y_app in that finite CAR algebra has error at most

    delta_Y=exp(a)a^(K+1)/(K+1)!
               +4|lambda|beta w exp(3kappa beta)e_N exp(2a).
                                                                    (28)

The first term is the simplex tail; for the second, telescope the two bounded nonunitary integral equations and apply their exponential norm bounds. The same approximation works identically in any volume whose boundary is farther than N steps. Norms of Y,Y_L are <=exp(a), and ||Y_app||<=exp(a)+delta_Y. This proves norm convergence of Y after K,N then volume, without pretending its orbitals remain finitely supported exactly.

It remains to control omega_0,L on S_N. On [-kappa,kappa], f_beta has Lipschitz constant beta/4. Its degree-q Bernstein polynomial has uniform error<=beta kappa/(4sqrt(q)): the rescaled binomial variance is<=1/(4q), and Cauchy–Schwarz bounds the mean displacement. If the boundary is farther than q from S_N, the compressed degree-q polynomials of h_L-mu and h-mu coincide by path locality. Thus their compressed free covariances differ in operator norm by at most

    eta_R<=beta kappa/(2sqrt(q)).                           (29)

This explicit, deliberately loose bound is for a fixed finite set, not the global infinite covariance norm. If S_N has D spin orbitals, expand its finite Fock density in the4^D Majorana/Pauli strings. A string has at most2D generators; its free expectation is a sum of at most(2D-1)!! signed pair products. Pair entries have modulus<=1 and differences<=4eta_R, so telescoping at most D factors gives the safe trace-norm bound

    ||omega_0,L-omega_0||_(CAR(S_N)) <= C_D eta_R,
    C_D=4^D 4D(2D-1)!!  (D>=1).                            (30)

The factor is intentionally large; norm2 is also a trivial cap. No numerical evaluation/convergence rate for an actual device is claimed. For any local A included in S_N put

    B_err=2delta_Y(2exp(a)+delta_Y)
                     +C_D eta_R(exp(a)+delta_Y)^2.

Approximating the two Y factors on both sides, then comparing the common Y_app free expectation by (30), bounds numerator difference by ||A||B_err and denominator difference by B_err. Using (27) and positivity |numerator_L|<=||A||D_L gives

    |omega_lambda,L(A)-omega_lambda(A)|
                <=2||A|| exp(beta|lambda|w) B_err.         (31)

For any desired precision choose K,N first, then q and a sufficiently distant boundary. This gives an actual local state limit; constants depend on beta,kappa,w/support and are not a uniform zero-temperature/long-time statement. Observables evolved for a fixed finite time can first be approximated by the local cut dynamics using (22)–(24), then use (31) on that finite algebra. Quasi-local approximations and bounded state norms give convergence on the full CAR algebra.

The ordinary full-CAR KMS statement must use tau_lambda. In finite volume it follows from the exact density exp(-beta K_lambda,L), NOT from a partitioned quench or physical-H Gibbs density at nonzero mu. Put b_beta=beta hbar, a positive time. Cyclic finite-dimensional trace, using commutation of exp(-beta K) with exp(i t K/hbar), gives the boundary identity omega_L(A tau_L^(t+i b_beta)(B))=omega_L(tau_L^t(B)A) for analytic B. For example at t=0, cyclically moving the last exp(beta K) in Tr(exp(-beta K) A exp(-beta K) B exp(beta K)) gives Tr(exp(-beta K) B A). There is no extra fermionic sign in this ordinary operator KMS identity; antiperiodic time-ordered fermion Green functions are a separate convention.

First establish the actual dynamics limit on the FULL algebra. For a local monomial X of m normalized CAR fields, enlarge the finite observation set in(22) to contain its support as well as V, and measure the boundary distance from that set. This only selects the local estimate, not a different physical graph or initial population. The resulting real-time orbital error epsilon_U(t,L) gives free monomial error at most m epsilon_U. Telescoping V's four fields gives4w epsilon_U, so Duhamel gives cocycle error at most4|lambda|w|t|epsilon_U/hbar and interacting monomial error at most epsilon_U[m+8|lambda|w|t|/hbar]. A finite local polynomial pays its coefficient absolute sum and largest degree. These bounds converge uniformly on compact real times; norm density and the automorphisms' norm1 extend convergence to every quasi-local element. The same bound holds for tau_L^t versus tau^t because the common real gauge gamma_(-mu t/hbar) is an isometry. No complex-time convergence of an extensive many-body exponential is required.

For a local B and epsilon>0 define the GRANDCANONICAL Gaussian analytic smearing

    B_epsilon=(sqrt(pi)epsilon)^-1 integral_R ds
                         exp(-s²/epsilon²) tau_lambda^s(B),
    tau_lambda^z(B_epsilon)=(sqrt(pi)epsilon)^-1 integral_R ds
                         exp(-(s-z)²/epsilon²)tau_lambda^s(B).
                                                                    (31a)

For real z the second formula follows by translating the integration variable and the group law. Uniformly dominated complex derivatives on compact z then give its entire continuation. If |Im z|<=Y, its norm is bounded by exp(Y²/epsilon²)||B||, uniformly in Re z. Finite-volume smears use the SAME epsilon and tau_L. For |Re z|<=T, |Im z|<=Y and R_cut>T, splitting the real integral at |s|=R_cut yields the explicit comparison

    ||tau_L^z(B_epsilon,L)-tau^z(B_epsilon)||
       <= exp(Y²/epsilon²){delta_B,L(R_cut)
                       +2||B|| eta_epsilon(T,R_cut)},
    delta_B,L(R_cut)=sup_(|s|<=R_cut)||tau_L^s(B)-tau^s(B)||,
    eta_epsilon(T,R_cut)<= epsilon exp(-(R_cut-T)²/epsilon²)
                                      /(sqrt(pi)(R_cut-T)).          (31b)

The two normalized shifted Gaussian tails obey this eta bound by integrating exp(-u²)<=u exp(-u²)/a for u>=a=(R_cut-T)/epsilon; no numerical evaluation is used. The inside integral has total mass at most1. Thus choose R_cut large first and volume next to obtain uniform convergence on each compact complex set. This proves entire-element convergence with fixed epsilon; it does NOT alone justify epsilon->0.

State convergence(31) extends to every fixed quasi-local element X: choose local X_loc and bound the two approximation errors by2||X-X_loc|| plus the local-state error. For X_L converging in norm to X add ||X_L-X||. Apply this to A tau_L^z(B_epsilon,L), using(31b) and a finite compact-z approximation net, to pass the full finite-volume boundary identity and analytic correlations to the infinite state. Write F_epsilon(z)=omega_lambda(A tau_lambda^z(B_epsilon)). Its lower boundary is omega_lambda(A tau_lambda^t(B_epsilon)); its upper boundary is omega_lambda(tau_lambda^t(B_epsilon)A). Both have norm bound ||A||||B_epsilon||<=||A||||B||. For each epsilon the Gaussian estimate also bounds F_epsilon throughout the entire horizontal strip0<=Im z<=b_beta, uniformly in Re z. The bounded-strip maximum principle therefore improves its bound to ||A||||B|| EVERYWHERE on that strip. One direct justification applies the ordinary maximum principle on growing rectangles to F(z) exp[-delta cosh(a_strip(z-i b_beta/2))], with0<a_strip<pi/b_beta and delta>0: the multiplier has modulus<=1 on both horizontal boundaries and tends uniformly to zero on the distant vertical boundaries. First let their distance grow, then delta decrease to zero. The same argument applies in every finite volume and to differences of two analytic smears.

Finally B_epsilon converges to B in norm as epsilon->0 by strong continuity and the approximate-identity Gaussian. For epsilon and epsilon' the analytic difference D=B_epsilon-B_epsilon' obeys the two KMS boundary identities already proved; the bounded-strip argument gives sup_strip |omega_lambda(A tau_lambda^z(D))|<=||A||||D||. Consequently the correlations are uniformly Cauchy on the CLOSED whole strip, with a bound independent of epsilon. Their limit is bounded and continuous on the strip, analytic in its interior, and has boundaries

    F_A,B(t)=omega_lambda(A tau_lambda^t(B)),
    F_A,B(t+i beta hbar)=omega_lambda(tau_lambda^t(B) A).   (31c)

This establishes ordinary beta-KMS on the FULL CAR algebra for tau_lambda. Local A and B suffice initially; norm approximation in each variable, with the same strip bounds, extends to all quasi-local A,B. This is the missing dense-element/strip-limit justification, not the false passage of an exp(b_beta²/epsilon²) bound to epsilon=0. Limits are finite beta, fixed local algebra/time and Gaussian scale, then volume, then analytic approximation; no zero-temperature/NESS/infinite-observation interchange is claimed.

The finite Gibbs states are gauge invariant and tau stationary. Gauge action is the same in every volume; compact real-time convergence and local-state convergence pass both properties to omega_lambda. Since alpha_lambda^t=gamma_(mu t/hbar) composed tau_lambda^t, the limiting state is also PHYSICAL-alpha stationary, although it is not ordinary alpha-KMS for charged fields at nonzero mu.

For a grade-r analytic B_r, the gauge relation extends to complex time as tau^z(B_r)=exp(-i mu r z/hbar)alpha^z(B_r). Substitution in(31c) gives the actual TWISTED physical-H boundary

    omega_lambda(A alpha_lambda^(t+i beta hbar)(B_r))
         =exp(-beta mu r)omega_lambda(alpha_lambda^t(B_r) A). (31d)

For a nonanalytic grade-r B_r, interpret this as a strip correlation identity: multiply F_A,B_r(z) in(31c) by exp(i mu r z/hbar), which has the stated physical lower boundary and twisted upper boundary. Its strip bound pays at most exp(beta|mu r|)||A||||B_r||. Charged Gaussian smears remain in their charge sector because gamma and tau commute. The contractive Fourier projection (2pi)^-1 integral_0^(2pi) dtheta exp(-ir theta)gamma_theta(B) selects each grade; finite sums of local charged monomials are norm dense in full CAR. Thus charged elements have not been dropped or redefined. The untwisted physical relation is recovered for neutral r=0 (including every measured current and V), or for mu=0, without setting mu=0 in the selected model.

A concrete nonzero-mu control exposes the old error on the actual graph. Already at lambda=0 and finite beta, the FULL coupled bounded graph has R=f_beta(h-mu) and

    exp(-beta h)(1-R)=exp(-beta mu)R,
    omega_0(c(f) alpha_0^(i beta hbar)(c†(f)))
                   =exp(-beta mu)<f,R f>,
    omega_0(c†(f)c(f))=<f,R f> >0 for f!=0.                (31e)

The first line follows directly from 1-f_beta(x)=exp(beta x)f_beta(x) and commuting functions of the SAME h. All AB/contact hoppings stay nonzero; any nonzero local f works, and bounded h with finite beta makes R bounded strictly between0 and1. For any mu!=0 the two sides differ, whereas tau_0^(i beta hbar)(c†(f)) restores equality. This is a full-graph infinite-lead control, not deleting the graph to isolate a favorable mode. The failure persists with the actual nonzero interaction in EVERY finite lead box: its faithful Gibbs state and grade+1 B=c_i† give omega_lambda,L(c_i alpha_lambda,L^(i beta hbar)(c_i†))=exp(-beta mu)omega_lambda,L(n_i), with omega_lambda,L(n_i)>0 by strict positive density. This last identity follows from the exact finite-volume tau relation and trace proof above, so it includes all original physical hoppings and lambda V, not an assumed free bubble. The tau-KMS identity instead has no chemical factor. Neutral-current physical evolution, equilibrium FDT/response, imaginary neutral-V cocycles and the verified S1 proof remain unchanged.

## 11. Explicit equilibrium initial orders, mixed contour and error

A useful independent imaginary-time expansion follows before taking volume limits from

    e^-beta K_lambda=e^-beta K_0
          T_tau exp[-lambda integral_0^beta du V_E(u)].

For any A define

    Q_0(A)=omega_0(A),
    Q_1(A)=-integral_0^beta du omega_0(V_E(u) A),
    Q_2(A)=integral_(0<u<v<beta) du dv
                                      omega_0(V_E(v)V_E(u) A),
    d_1=Q_1(1), d_2=Q_2(1),
    omega_1(A)=Q_1(A)-d_1 Q_0(A),
    omega_2(A)=Q_2(A)-d_1 Q_1(A)+(d_1²-d_2)Q_0(A).           (32)

Every expectation on the right is in the actual coupled free Gibbs covariance. The normalizing disconnected terms are essential. The equality with the positive state (26) follows from (27) in every volume and (31), not by declaring the ordered exponential positive. The first coefficient is the imaginary-time connected covariance; the second retains both two-interaction and normalization terms. Their norms obey ||omega_1||<=2M, ||omega_2||<=3M².

With real-time A_n from (8), the EQUILIBRIUM mean coefficients now are

    m_0=omega_0(A_0),
    m_1=omega_0(A_1)+omega_1(A_0),
    m_2=omega_0(A_2)+omega_1(A_1)+omega_2(A_0).               (33)

For the raw ordered product use O_0=A_0B_0, O_1=A_1B_0+A_0B_1, O_2=A_2B_0+A_1B_1+A_0B_2 and F_n=sum_(k=0)^n omega_k(O_(n-k)), followed by the SAME mean subtractions (9). Thus the initial, mixed real/imaginary and two-real-time orders all appear explicitly. They cannot be replaced by the fixed-quench coefficients.

The independent contour has in addition a vertical leg0->-i beta hbar with alpha_0^(-i hbar u)(V)=V_E(u). Since (-i lambda/hbar)dz=-lambda du there, its first and second insertions are exactly Q_1/Q_2; dividing by its vacuum amplitude gives d_1,d_2. Expanding placements between this leg and the six real-time placements (13) gives (33) and the displayed F_n. Thus the two derivations agree ALSO including the equilibrium initial four-point vertices and every normalization term. The free lead integration remains Gaussian on this full contour, but its initial coupled thermal correlations and central quartic vertices remain; no arbitrary finite-time initial term disappears. On the equilibrium vertical branch the full charged-CAR thermal evolution is generated by K_0=H_0-mu N, with its actual grandcanonical boundary. The displayed alpha_0^(-i hbar u)(V) is exactly tau_0^(-i hbar u)(V) because V is neutral, so every Q_n and mixed coefficient remains unchanged; this does not grant an untwisted physical-H boundary to a charged fermion field.

For an explicit all-real-lambda finite-beta error put a=|lambda|M and

    E_state=exp(beta|lambda|w){(2+2a+3a²)r_3(a)
                                           +4a³+(3/2)a^4}.
                                                                    (34)

Then ||omega_lambda-(omega_0+lambda omega_1+lambda²omega_2)||<=E_state. Proof: the numerator and denominator ordered series have coefficient bound ||A||M^n/n!, M^n/n!. Multiply the quadratic state polynomial by the exact denominator. Orders0–2 cancel; the degree3/4 terms are bounded by4a³+(3/2)a^4, its denominator tail by(1+2a+3a²)r_3(a), and the numerator tail by r_3(a). Divide by the true lower denominator exp(-beta|lambda|w) from (27). This is a genuine error, possibly large at physical lambda=1, not a convergence certification.

For x=2|lambda|wt/hbar define

    E(t)=E_state+(1+2a+3a²)r_3(x)
                         +a x²+3a²x+(3/2)a²x²,
    p_t=2a+x, q_t=3a²+2ax+x²/2, L_t=1+p_t+q_t.             (35)

Telescoping the normalized state with the real-time observable expansion proves mean error<=a_a E(t). Its raw ordered-product error is<=a_a a_b E(t+s), using x for t+s. The degree<=2 mean polynomial has magnitude<=a_a L_t. Comparing exact mean products with their quadratic product gives the explicit connected bound

    equilibrium connected error <=a_a a_b{
        E(t+s)+E(t)+L_t E(s)+p_t q_s+q_t p_s+q_t q_s}.       (36)

The asymmetric-looking bound is safe: use |m_B|<=a_b, telescope m_A-P_A then m_B-P_B, and bound the omitted cubic/quartic product coefficients. Probe integration multiplies the supremum of (36) on[0,T]^2 by ||f||_1||g||_1. State, beta, time and volume errors are distinct. This supplies actual first/second interacting equilibrium noise with an explicit remainder, not KMS invoked for a nonthermal quench.

## 12. Exact KMS noise/response, physical residuals and original BUILD

In (26)'s true gauge-invariant physical-alpha stationary state, ordered covariance has a positive matrix spectral measure. The full state is ordinary beta-KMS for grandcanonical tau by section10. Every measured current is charge neutral, so tau^t(I_a)=alpha^t(I_a); the chemical factor in(31d) is EXACTLY1 in this sector. KMS applied to these bounded physical currents therefore gives

    S^<(omega)=exp(-beta hbar omega) S^>(omega),
    S^sym=(1/2)coth(beta hbar omega/2)(S^>-S^<).             (37)

Detailed balance holds as a measure identity. The coth reconstruction is stated for omega!=0 (or probes separated from zero), not automatic ordinary densities. A possible elastic zero-frequency covariance atom is retained from the ACTUAL ordered covariance (9)/(26); KMS alone makes its greater/lesser difference zero and cannot recover its symmetrized weight by multiplying zero by singular coth. No absence of such an atom, regular interacting DC limit or interacting Landauer formula is asserted without additional proof. This retains every zero-mode contribution rather than setting it to zero. For an actual fixed-kernel contact flux Phi, J=-partial_Phi H_lambda is (7), T_ab=omega_lambda(partial²_Phi_a,Phi_b H_0). Duhamel of the exact interacting local dynamics gives

    chi_ab(z)=(i/hbar) integral_0^infinity dt e^(izt)
                       omega_lambda([I_a(t),I_b]),
    Y(z)=[chi(z)-T]/(iz), Im z>0,
    (Y+Y†)/2=(S^>-S^<)/(2hbar omega)                         (38)

at real nonzero frequencies in the distribution/probe sense. Thus S^sym=hbar omega coth(beta hbar omega/2)Y_H. All interaction vertex and initial pieces enter chi/noise; inserting only dressed free bubbles would contradict (15). The contact Hessian is not dispensable from the complex response. Local continuity/gauge invariance from [V,N_i]=0 imply the full charge-storage Ward identities, including contact/scalar equal-time derivatives, at each interaction order. Total external circuit displacement/screening/gate current has NOT been constructed by this bare-cut FDT.

Standard two-sided Fourier variance uses d omega/(2pi); ordinary-Hz substitution and a single positive-frequency fold follow as in the predecessor. Positive greater frequency remains absorption; no Planck-shaped Hawking excess follows. Unlike the free one-particle predecessor, interacting local currents can create many-particle transitions; NO uniform compact many-body frequency support is inferred from bounded one-particle h. Actual spectral tails and finite probes must be controlled. Neither pointwise calibrated spectrum nor nonempty usable device band is proved by the existence of these measures.

A concrete microscopic residual comparison is possible only on a common admitted carrier. Write the true projected antisymmetric pair tensor A_true and the density tensor A_D from (5). CAR monomials have norm<=1, hence the omitted finite-central quartic operator obeys

    ||delta V|| <= (1/4)sum_(alpha beta gamma delta)
                              |A_true-A_D|_(alpha beta;gamma delta),
    ||delta H_onebody|| <= ||delta h_onebody||_1.           (39)

These compare actual Wannier/exchange/normalization/band/static-screening errors WHEN those matrix elements are supplied. The radius/dielectric and boundary conditions used in (2) are selected inputs, not error-certified actual material values. Finite supports and compact geometry sets with a_min>0, positive sphere/gate separations and epsilon_min>0 make the integrals and their parameter derivatives finite; elementary differences of inverse distances in (3) then give actual coefficient errors, while approaching overlap/gate/cutoff singularities requires separate treatment.

For two full interacting Hamiltonians on the same Hilbert space with a genuinely bounded difference Delta_H and bounded current differences Delta_A,Delta_B, real-time Duhamel gives ||A(t)-A_tilde(t)||<=||Delta_A||+2|t|Delta_H||A_tilde||/hbar. The connected covariance telescoping bound is 2(b deltaA+a deltaB), plus3eta ab for a separately proved initial-state norm error (use compatible norm bounds for both carriers). If the true additional gate/bath dynamics is unbounded, (39) and this estimate do not apply globally by wish: specify a common invariant energy/domain or prove leakage/tail estimates and actual state/current residuals. None has been measured here. A finite-time matrix difference is not a proof of universal Born/on-shell/Markov accuracy.

The accepted collision construction has a different homogeneous parabolic/on-shell/semiclassical domain. No derived kinetic limit from this quantum contact model has been supplied. In a future justified local-FD reduction, the full equation retains -(partial_t+v partial_x+C)h_loc and in particular -beta C lambda_band delta mu_I, its Q projection and time/streaming sources. Pointwise mu_I=0 steady first-gradient22a is not a general reacting closure; Auger does not conserve imbalance. Semiclassical event noise cannot replace the ordered quantum vertex (15)/(37).

Remaining original work is substantive BUILD: actual material Wannier/band/exchange/dynamical dielectric/contact geometry and error inputs, interacting gated electron/hole/energy/momentum background and heated nozzle, transverse/finite-width/horizon conversion and partner/correlated/anomalous incoming state, genuine controlled kinetic/finite-coupling and long-time limits where required, physical screened charge/gate/displacement receiver transfer, absolute noise calibration and uncertainties, identifiable nonempty usable frequency band/sensitivity, and the FULL target's independent microscopic route agreement. This finite-time interacting carrier advances those routes but is not their device completion or a reduced charter. Source propagation, actual numerical/native/runtime validation, G4/G5/G11/full finding closure, all21/B1–B8/D12/main failures and human acceptance remain separate and unwaived. No infeasibility/deferral is declared.


## Carrying primary depth and source/protocol limits

Personally read official [Jauho–Wingreen–Meir v1](https://arxiv.org/pdf/cond-mat/9404027v1), actual interacting-central/contact setup and current6–15, plus AppendixA1–A5/B1–B7. These distinguish arbitrary central interactions from Gaussian noninteracting leads and retain initial lesser terms. They do not supply this electrostatic vertex, interacting noise or true device calibration. The April1994 identifier and generated August2013 title date are not equated. This is selected parsed passage depth, not the whole42pages or PDF pixels.

Personally read [Kamenev–Levchenko v3](https://arxiv.org/html/0901.3586v3), fermionic coherent trace/initial kernel93–98 and source115–123 context. Its discrete boundary and forward/backward signs support retaining initial-state normalization. Its continuum near-Fermi current replacement is not imported as our exact lattice vertex; our (11)–(15) derive their own signs and connected terms. No sigma-model/kinetic approximation or full-paper coverage is claimed.

Later lead-provided context prompted a personally bounded read of [Araki1973](https://ems.press/content/serial-article-files/41744?nt=1), §§3.1/3.2/4.1, physical-versus-modular time remark p177, and note added in proof p209. OCR obscures some mathematical symbols; no unread exact constant or unqualified corrected theorem is credited. The explicit finite-volume positivity/local-state/KMS proof (25)–(36) stands on its own derivation, not citation as completion. No46-page/pixel claim or local fulltext saving/admission.

The frozen r1 SOURCE_MODEL was genuinely saved at10:18:39 AFTER the acknowledged new analysis scratch; its actual protocol failure remains unwaived. Its original proof history and rejected acceptance remain immutable. Frozen r2 saved its fixed MODEL before new S1 mathematics at11:04:08, wrote the coherent successor at11:09:05 and received complete nonauthor review f74a104c. That review independently VERIFIED the same-time S1 proof but rejected whole-note acceptance for K1; lead disposition314c61bf retained the full physical model and mandated coherent repair. For this NEW r3 task the fixed same physical model, including arbitrary nonzero mu, was genuinely saved at2026-10-18T11:38:55.063759+00:00 BEFORE any new K1 mathematics. The grandcanonical/full-CAR, twisted physical-H, analytic-smearing/local-limit/dense-strip and actual charged countercontrol proofs were then independently rederived. Exact reversible spans and unchanged39-group/S1-body comparisons bind the whole successor to r2. No original compliance, process waiver, scientific acceptance or native execution follows. Fresh genuinely nonauthor WHOLE scientific verification and lead intake remain required, including unchanged carrying proofs, K1, verified S1, model selection and the original unwaived process failure. All earlier failed main/CI/Verify receipts and raw administrative exceptions remain.

<!-- END COMPLETE ORIGINAL CONSTRUCTION -->
