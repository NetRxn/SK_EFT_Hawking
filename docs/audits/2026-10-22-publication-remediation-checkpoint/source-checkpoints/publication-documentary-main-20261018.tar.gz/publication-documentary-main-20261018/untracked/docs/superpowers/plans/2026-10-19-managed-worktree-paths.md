# Implementation plan — managed-worktree path portability

Status: the existing portability mechanism is independently accepted in its original candidate;
this SOURCE137 integration is authorized for bounded SOURCE work only. Genuine whole nonauthor
source/original-intent review, current ROOT runtime/production controls, recorded closure and
integration remain owed. Earlier candidate receipts do not qualify this candidate.
Parent: publication inherited-main failure reconciliation, PREFIX_CONTEXT + CACHE_CONTEXT.
Owning [design](../specs/2026-10-19-managed-worktree-paths-design.md).
Existing owner: ADR-012 P10 and the canonical workspace resolver. Original finding and review
records remain in the accepted earlier candidate; this integration creates no second queue.

## P1. Accept or repair the specification

Publication lead independently challenges the complete design against ADR-012 P10 and the
existing canonical workspace owner. Use the actual baseline red receipts and current
source/history; do not accept a helper-name scan as evidence. Return corrections to this
specification author. Record a concrete accepted result before the implementation successor.
No source code, tests, closures or Git integration in this step.

## P2. Assign one coherent implementation package

The lead names an accepted owner and a fresh continuity packet for the isolated candidate,
including protected source/branch state, exact paths and nonauthor acceptance reviewer.
Do not assume the current specification assignment permits implementation. Keep source and
regression controls together so normalization cannot land without its missing-file refusals.
No Lean lane or cache/acquisition controller is required.

Prospective paths: existing `scripts/orchestrate.py::target_files`,
`tests/test_orchestrate.py`, `tests/test_phase6i_wave1.py` (cache function and controls),
`tests/test_architecture_claims.py` (new ADR sentence/runtime pin); extend the existing resolver
tests only if needed for the different managed layout. No new resolver/check/gate/ledger.
The ADR clarification and design/plan travel with the reviewed repair; existing findings remain
under their original lifecycle and single writer.

## P3. Implement the two consumer corrections

1. Normalize one exact leading logical repository prefix within the existing target parser.
   Resolve the resulting candidate inside the active checkout. Preserve canonical containment,
   file-existence, all-target enumeration/dedup, legacy contained spellings, file-conflict
   queuing and lane strength. Do not redirect to the canonical sibling or relax a guard.
2. Replace the cache test's ad hoc workspace parent walk with already imported
   `find_workspace()`. Keep checkout-local source state and the unchanged real missing/empty
   assertion and successful-state drift distinction. Remove a now-unused old root definition.
   Preserve the unrelated later-primary tmp_path extractor change on integration.
3. Bind the new ADR sentence to runtime results in the existing architecture-claims tests;
   pin sentence plus behavior, not just a helper name in source text.

## P4. Prove the repair without weakening the measurements

Record exact interpreter, candidate HEAD/source hashes and imports from the active candidate.
Use the prepared existing Python environment without dependency install/sync. Keep default
pytest selection semantics and record any broader run's actual scope.

Required controls are the design D3 table, including a canonical sibling with a distinct active
copy, mixed prefix/unprefixed/ranges/multipath dedup and missing/traversal/escape refusal;
cache nonempty, missing, empty, success-drift, null-path and state-root controls in canonical,
renamed linked and nested layouts. Call the existing cache invariant and real workspace resolver;
retarget module-location/filesystem and registry/state inputs, never fabricate a resolver result.
Assert actual candidate function origins. Do not implement another validator.
The current two original failure identities must be red with old behavior and green after
repair in the actual differently named managed checkout. Their green alone is insufficient.

Run at least the complete orchestrator file, resolver tests, existing architecture claim pins
and the entire Phase6i file with its new controls. Report every remaining failure at the actual
current candidate; earlier candidates' citation outcomes do not transfer automatically. Do not skip that assertion,
reduce registry coverage, forge a success record or raise a ceiling.

Use the existing seed journal for real production-artifact mutation, only in the allocated
checkout; preserve exact bytes/metadata and durable red/restore receipts. Do not seed the shared
literature cache or mutate another worker's candidate. If a production control cannot be run
within the allocated isolation, retain it as owed and return the concrete missing condition.

## P5. Author repair, independent verification, recorded closure

A genuinely nonauthor reviewer independently reads the whole source/test/docs diff and actual
red/green/restore receipts. Challenge canonical-sibling routing, active import witnesses,
existence/containment/multiplicity, file/lane composition and successful-state-only drift.
Return mandatory corrections to the author; an accepted specification or self-test is not this
review. Root runs appropriate existing change-scoped checks and required integrated gates.
Close only through the existing writer after the acceptance bar is actually met. Do not run
any closure writer or change a ratchet in this specification task.

## P6. Integrate at the first accepted repair checkpoint

The lead composes a reviewed ordinary Git checkpoint against the current integration base,
preserving NJL/ADW and accepted later-primary work. Inspect the final combined diff and qualify
that exact head; an isolated branch pass is not merged-main evidence. Follow the user's
minimum cadence of integrating completed milestones instead of retaining publication work
indefinitely in a worktree. Merge only after the existing required gate/review boundary.
Scientific bundle readiness and final human publication review remain independent.

## Termination evidence

The bounded SOURCE integration handback ends after the complete documented consumer repair,
original-control conservation, exact diffs, protected-state evidence and actual FIRST/FINAL.
Independent whole source/original-intent review and ROOT runtime/production receipts remain
required before qualification, followed by canonical closure and reviewed Git integration.


## Current SOURCE137 integration boundary

The assigned author first documents this integration, then applies only the accepted exact-prefix
normalization and canonical shared-workspace lookup to the existing consumers. Every original
control, helper, decorator, budget and assertion is conserved apart from the documented cache-root
representation migration. New controls exercise actual filesystem inputs and production function
objects; they do not substitute a resolver answer. Preserve all accepted scientific source posts,
all other default failures and retained post-run effects. No ratchet, generated count, review status,
registry, seed repair or canonical writer changes belong here.

The current author may perform passive AST/source/hash/diff checks only. No project imports, tests,
collection, production seeds, native work, Git writes or closure execute in this SOURCE assignment.
The handback records complete source/control conservation and actual continuity receipts; source
presence is not a runtime pass. ROOT allocates genuine nonauthor whole source/original-intent review
before running unchanged original test identities, full targeted modules and production0-1-0.
Whole default/full gates, original scientific BUILDs, canonical closure, main and human review remain
separate obligations. This current boundary supersedes earlier pending/accepted checkpoint wording
only for this candidate; historical earlier receipts remain unchanged in their owning artifacts.
