# Charged acoustic modes, actual current and noise normalization

Author: publication scientific lead. Independently accepted manual mathematical construction within the declared charged-acoustic model; physical and native acceptance remain open. Parent: E2 electrical readout and D1 independent response/noise BUILD. No project/model/mathsoftware/test execution, physical device calibration, native acceptance or canonical closure is supplied.

## 1. Actual source boundary and the selected physical carrier

I personally read the official [Safi–Schulz preprint](https://arxiv.org/pdf/cond-mat/9505079), v1,18May1995, entire carrying text pp2–9, including Hamiltonian2/current continuity, conductivities6–10 and contact/limit qualifications. Its wire/lead distinction prevents identifying a local acoustic admittance with an arbitrary measured terminal conductance. I also read [Lucas–Fong](https://arxiv.org/pdf/1710.08425), dated8January2018, the full carrying constitutive/mode discussion Eqs49–69, actual PDF pp18–22, plus the returned charge-neutral/transport passages. Intrinsic dissipative conductivity and convective charge current are distinct; at symmetric charge neutrality the sound sector need not carry charge. These are source constraints, not a transfer of either source's model to the target bilayer. No whole Lucas–Fong review/pixel inspection, publisher equivalence or local fulltext acquisition is claimed.

The mathematical results below are explicitly derived for a positive one-component barotropic charged acoustic Hamiltonian. They supply an actual current observable and response rather than choosing an effective channel count to force a prefactor. They do not establish that hot bilayer graphene is this one-component model, that its dissipative sigma_Q equals the conductance below, or that its horizon scattering/state is calibrated. The full original E2/D1 obligation remains.

Use SI quantities n>0 (line particle density, m^-1), m>0 (inertial mass), c>0 (sound speed), real signed carrier charge q, hbar>0. Let eta(x) be line density fluctuation and theta(x) a dimensionless phase, with [eta(x),theta(y)]=i delta(x-y). At zero flow define

H0=(1/2) integral_R [m*c²*eta²/n + hbar²*n*(partial_x theta)²/m] dx,
L=integral_R [-hbar*eta*partial_t theta]dx-H0,
v=hbar*partial_x theta/m,
I(x)=q*n*v=q*hbar*n*partial_x theta/m.                              (1)

Products/Hamiltonian are initially finite-mode normal ordered with zero modes fixed. The free infinite field is subsequently used only as a positive Gaussian state on smeared observables. eta=-hbar*n*theta_dot/(m*c²), hence eta_dot+n*v_x=0 and v_dot=-(c²/n)eta_x. Thus charge continuity is q*eta_dot+I_x=0. A phase action obtained by eliminating eta is
S_theta=(hbar²*n/(2m))integral[(theta_dot/c)²-theta_x²]dxdt.
No dissipative electronic conductivity appears in these identities. This is the quadratic expansion of a stable barotropic kinetic/compressional energy with dmu/dn=m*c²/n; its actual thermodynamic/electronic derivation is separately required.

## 2. Canonical modes, both chiralities and local current spectrum

On a periodic length L, k=2pi*j/L !=0, omega_k=c|k|, [b_k,b_l†]=delta_kl. A canonical expansion is

eta(x)=sum_k a_k [b_k exp(ikx)+b_k† exp(-ikx)],
theta(x)=-i sum_k d_k [b_k exp(ikx)-b_k† exp(-ikx)],
a_k=sqrt(n*hbar*|k|/(2m*c*L)),
d_k=sqrt(m*c/(2n*hbar*|k|*L)),
I(x)=q sum_k sign(k)*c*a_k [b_k exp(ikx)+b_k† exp(-ikx)].             (2)

Since a_k*d_k=1/(2L), the commutator is i[delta_L(x-y)-1/L], the correct fixed-total-charge sector. theta_dot gives (1); H0=sum hbar*omega_k*(b_k†b_k+1/2), up to the chosen normal ordering. The k=0 total charge/winding modes are fixed, not discarded from a transport limit without explanation. Take the infinite-length limit before a zero-frequency local response limit; a finite isolated ring has discrete lines/zero-mode transport, not a smooth dissipative terminal.

Choose real smooth compactly supported w(x), integral w dx=1, and I_w=integral w I dx. Put W(k)=integral w(x)exp(ikx)dx. Smoothness makes equal-time vacuum current variance and the retarded integrals below finite. States have zero first moment, diagonal stationary nonnegative occupations n_+(omega),n_-(omega) for k positive/negative, no mutual or anomalous correlations. Compact frequency windows avoid infrared particle-number or ultraviolet Fock-representation assertions. Define

S^>(omega)=integral_R dt exp(i*omega*t)<I_w(t) I_w(0)>,
S^<(omega)=S^>(-omega), S_sym=(S^>+S^<)/2,
G_ac=q²*n/(2m*c), F_w(omega)=|W(omega/c)|².

For omega>0, direct mode summation followed by sum_k -> L/(2pi)integral dk gives

S^>=hbar*omega*G_ac*F_w*[2+n_++n_-],
S^<=hbar*omega*G_ac*F_w*[n_++n_-],
S_sym=hbar*omega*G_ac*F_w*[1+n_++n_-],
S^>-S^<=2*hbar*omega*G_ac*F_w.                                     (3)

Each chirality contributes hbar*omega*G_ac*F_w*(n_s+1) to S^>, not the entire two-chirality vacuum. The factor follows from 2pi, density L/(2pi), |dk/domega|=1/c and current amplitude q²*n*hbar*c|k|/(2mL). G_ac has siemens units; every PSD has A²s. Reversing q changes current sign, not its auto spectrum. Both chiralities and fixed-total-charge zero-mode convention are essential to this normalization.

## 3. Retarded/Gaussian contour route, physical electromagnetic coupling and contact

This second calculation inverts the actual quadratic action and propagates its specified Gaussian covariance. It is not an assertion that two separately assigned noise formulas coincide. With R_AB(t)=-(i/hbar)theta(t)<[A(t),B(0)]>, the phase kernel and current response are

R_theta(k,z)=1/[M_theta*(z²-c²k²)], M_theta=hbar²*n/(m*c²), Im z>0,
R_II,w(z)=(q²*n*c²/m) integral dk/(2pi)
                         k²*|W(k)|²/(z²-c²k²),
Im R_II,w(omega+i0)=-omega*G_ac*F_w(omega), omega>0.                 (4)

The inverse follows directly from S_theta's Euler operator with the retarded boundary condition. The imaginary part uses Im[(omega+i0)²-c²k²]^-1=-pi*delta(omega²-c²k²) at positive omega. The two roots contribute integral k² delta(... )dk=omega/c³. This fixes the current spectral coefficient without a conductivity substitution.

For a real flux Phi(t) choose A(x,t)=Phi(t)w(x) and make minimal coupling hbar theta_x -> hbar theta_x-q A in H0. Then
H(Phi)=H0-Phi*I_w+(D_w/2)Phi²,
D_w=(q²*n/m) integral w²dx,
I_phys,w=-partial H/partial Phi=I_w-D_w*Phi.
For H'=-Phi I_w the Kubo change is delta<I_w>=-R_II,w*Phi in the R convention above. The integrated emf is V=-Phi_dot=i*omega*Phi for exp(-iomega t). Therefore

Y_w(omega)=i[R_II,w(omega+i0)+D_w]/omega,
Re Y_w=G_ac*F_w, R_II,w(0)=-D_w.                                  (5)

The contact is REAL and cancels the static pure-gauge vector-potential response; omitting it leaves an unphysical reactive term. The real dissipative part in (5) does not require equilibrium. A point current w=delta has an ultraviolet-divergent real contact; only its explicitly regularized/band-limited spectral limit may be used. Smooth w avoids that shortcut. This conjugate flux/current geometry is a defined local probe, not an unspecified two-contact experimental circuit.

To state the Gaussian contour calculation precisely, R^K_theta(t)=-(i/hbar)<{theta(t),theta(0)}>. For a stationary diagonal free-field Gaussian initial state, the homogeneous wave equation and equal-time covariance fix

R^K_theta(k,omega)=-i*pi/[M_theta*omega_k]
 *[(2n_k+1)delta(omega-omega_k)+(2n_-k+1)delta(omega+omega_k)].         (6)

This follows by solving the oscillator covariance initial-value problem, or equivalently inverting the quadratic closed-time-path kernel with that Gaussian boundary covariance. Apply (q*hbar*n/m)^2*k² and integrate |W|²dk/(2pi), then S_sym=(i*hbar/2)R^K_II,w: equation(3) results independently of the delta-function sum for the current. In a nonreciprocal state the positive-frequency distribution is 2n_k+1 and the negative-frequency one is -(2n_-k+1) multiplying R^R-R^A. There is no common thermal coth unless n_+=n_-=n_B. The underlying retarded kernel is state-independent; statistical covariance is additional physical input. No driven-system FDT was postulated to fill it.

At equilibrium n_+=n_-=n_B(omega,T), (3),(5) give S_sym=hbar*omega*ReY_w*coth(hbar*omega/(2k_B*T)). At T0 this is hbar*omega*ReY_w; at low frequency/positiveT it is 2k_B*T*ReY_w. These statements are proved for this positive Gaussian Hamiltonian/state, not for an arbitrary pumped graphene distribution.

## 4. Physical scattering state, loss vacuum and the conditional Hawking prefactor

At each positive frequency take independent canonical input modes u,v,l and an additional independent counterpropagating reference mode d. On a finite discretized band let a normalized outgoing channel be

b_+=sqrt(Gamma)[alpha*u+beta*v†]+sqrt(1-Gamma)*l,
0<=Gamma<=1, |alpha|²-|beta|²=1.                                    (7)

The bracket is a genuine two-mode Bogoliubov transformation, extendible by its partner mode; the last mixing is a passive loss beam splitter. Thus [b_+,b_+†]=1, NOT Gamma. Vacuum loss cannot be omitted. After tracing the partner and setting all inputs vacuum, the stationary local outgoing state has n_+=Gamma*|beta|², no anomalous local moment; b_-=d remains independent/vacuum. The local stationary state can be defined directly as that positive quasifree covariance on the measured frequency band. A global stationary horizon realization, spatial scattering normalization and thermal beta² remain separate construction requirements; no infinitely squeezed Fock-unitarity or positive-energy partner identification is asserted.

Set |beta|²=n_H only when the actual state/scattering construction justifies it. Against the matched Gamma-preserving beta0 vacuum reference, (3) gives

Delta S_sym^(two-sided angular argument)=hbar*omega*G_ac*F_w*Gamma*n_H.
For an ideal classical symmetrized one-sided spectrum per ordinary hertz,
S_1(f)=2*S_sym(2pi*f), f>0,
Delta S_1(f)=2*hbar*omega*G_ac*F_w*Gamma*n_H, omega=2pi*f.             (8)

There is NO extra2pi multiplier in S_1: d omega/(2pi)=df, and folding both frequency signs supplies the2. This establishes the target functional form for a specified charged channel, one populated direction and one-sided convention, with G_ac*F_w as its physical local dissipative conductance. It does not establish sigma_Q=G_ac*F_w for the target. If BOTH independent directions acquire Gamma*n_H, the excess doubles. A symmetrized two-sided label also changes the factor. The high-temperature equilibrium one-sided background is 4k_B*T*ReY_w, consistent with the same convention.

For independent nonvacuum populations n_u,n_v,n_l, the output has
n_+=Gamma[|alpha|²*n_u+|beta|²*(n_v+1)]+(1-Gamma)n_l.
Against a matched beta0 reference with the SAME ambient inputs, Delta n_+=Gamma*|beta|²*(n_u+n_v+1). Substituting vacuum n_H in a thermally occupied acoustic channel misses this stimulation. An unrelated electronic Johnson background may coexist only after its actual independent/correlated coupling is constructed. Source electrical temperature alone does not select the acoustic incoming state. Zero beta, Gamma0, q0 or T_H0 gives zero declared vacuum excess, while equilibrium/vacuum baseline remains as appropriate.

If the two measured directions have correlated occupations, let N_ij=<b_j†b_i> be their positive Hermitian spectral covariance, and u_w=(W(omega/c),-W(-omega/c)). Then
S_sym=hbar*omega*G_ac*u_w*(N+I/2)*u_w†.                              (9)
The diagonal formula is its special case. A detector collecting a partner/idler or reflected correlated branch must use its complete covariance/transfer, not discard offdiagonal terms. Stationarity with strictly positive asymptotic energies excludes single-band anomalous moments; driven/nonstationary sidebands require the full two-frequency covariance rather than a scalar stationary PSD.

## 5. Finite-band observable, source/probe errors and contact controls

For a real temporal filter h with square-integrable H and support in a compact symmetric band omega0<=|omega|<=Omega, omega0>0, define X=integral h(t)I_w(t)dt. Its actual variance is
Var X=integral d omega/(2pi)|H(omega)|²*S_sym(omega)
     =integral_0^infinity df |H(2pi*f)|²*S_1(f).                     (10)

Every expression is finite for bounded band occupations and smooth w; positivity follows from N>=0 and canonical half-vacuum. A stationary Gaussian field exists on these smeared observables. No current operator at a spatial/temporal point or infinite total phonon count is needed. Spectral-density quantities are distributions until paired with the specified window.

If w>=0 is normalized with variance sigma_x², then |W|² is the characteristic function of X-X' averaged over two independent copies of the spatial weight. Since 1-cos z<=z²/2,
0<=1-F_w(omega)<=min(1,omega²*sigma_x²/c²).                          (11)
This is a genuine quantitative spatial-averaging error; it is not a graphene hydrodynamic or greybody remainder. Replacing F_w by1 in the vacuum-excess (8) has absolute error at most 2*hbar*omega*G_ac*Gamma*n_H times the right side of(11), with ordinary-frequency one-sided convention.

More generally, on the same compact band suppose independently established bounds |ReY_actual-Y_model|<=epsilon_Y and |Delta n_actual-Delta n_model|<=epsilon_n, with nonnegative model values. For the independent single-direction current model the one-sided spectral error is bounded by
2*hbar*omega[epsilon_Y*Delta n_model+Y_model*epsilon_n+epsilon_Y*epsilon_n],
plus separately derived cross-covariance/background and projection errors. Multiplying this bound by |H|² and integrating df bounds the variance error. This is conditional error propagation, not evidence that those actual material/model bounds are available or small. One-sided linear-amplifier readout is also a receiver assumption; a quantum absorbing detector measures an ordered spectrum, requiring its own calibrated ordering/transfer. A simple FDT label cannot decide it.

The Galilean free spinless Fermi-gas limit n=k_F/pi,c=hbar*k_F/m gives G_ac=q²/(2pi*hbar)=q²/h exactly. This is a same-normalization limiting control, not a proof of arbitrary interacting-contact conductance. In Luttinger variables K=pi*hbar*n/(m*c), G_ac=K*q²/h. Real leads may fix a different effective conductance and produce frequency-dependent reflection; the source's contact result is a warning to solve that actual boundary problem.

## 6. Why intrinsic conductivity is not automatically acoustic charge coupling

The one-component model (1) has only one conserved particle density and the corresponding convective charge current. It does NOT include the independent electron-hole counterflow channel parametrized by intrinsic sigma_Q in a relativistic neutral fluid. A simple direct control follows from linearized charge conservation and the constitutive decomposition J^x=n0*delta v^x-sigma_Q*partial_x(delta mu-mu0*deltaT/T0), with units/charge convention chosen consistently. At charge-conjugation-symmetric neutrality, n0=mu0=0 and partial_T n|mu0=0. A pure energy/pressure sound perturbation with delta mu=delta n=0 then has delta J^x=0 at this order, even for sigma_Q>0. The independent diffusive charge perturbation still has nonzero electrical response. This does not prove absence of nonlinear, asymmetric, contact-induced or finite-density readout, and does not describe the actual biased bilayer without a separate derivation. It disproves a universal identification of sound-channel weight from intrinsic sigma_Q alone.

For the actual target we must construct its bilayer EOS/charge-energy eigenvectors and current overlap, screened interactions and transverse boundary modes; derive contact/lead/circuit response and finite-frequency dissipation/ordered noise; obtain physical spatial horizon and electrical transmission with normalization; identify incoming state, extra independent/correlated noise and detector ordering/transfer; and independently calibrate the covariance and error-controlled identifiable nonempty band. The D1 full fermionic scattering-current and microscopic Keldysh agreement duty remains, since the two calculations here share a specified acoustic Hamiltonian and do not supply those two original microscopic routes. Full native/software/validation/integration/canonical closure/main/publication/human gates remain open. No infeasibility or deferral is requested or concluded.

Complete original independent manual verification: [full review](reviews/E2_CHARGED_ACOUSTIC_CURRENT.md). Source selection and process scope: [original source/model contract](source-models/E2_CHARGED_ACOUSTIC_CURRENT.md). This records scoped mathematics, not native, physical, main or publication closure.
