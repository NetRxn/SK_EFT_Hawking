# Original E2 large-area response — construction

Public delivery of a complete fixed manual scientific artifact. This SOURCE137 composition is UNAPPLIED and UNRUN; its whole-source independent review and ROOT integration remain pending.

**Declared manual scope.** All sixteen sections on the full fixed CAR/contact family: AB geometry/image terms, finite depth-dependent contact tree cuts/tails, weak unbounded-onsite dynamics, thermodynamic states, source/weighted-response/Ward/f-sum/upper-half-plane domains. Infinitely many summable contacts retained.

**Original physical obligations.** No unweighted noise/elastic/static susceptibility/real-band bulk conductivity or phase/device calibration by inference. Actual Wannier/material/screening/contact/state/nozzle/current/readout and independent transport/noise errors remain owed. Original Q1/Q2 and failed reviewer history remain exact.

The construction author is publication_root7_current_review; the complete independent scientific review is by publication_main55_independent_review. Those prior scientific verdicts retain their exact stated scopes. This delivery adds no new mathematical, native, device or publication acceptance.

Public companion locators: [E2_ORIGINAL_GATED_BILAYER_LARGE_AREA_RESPONSE](E2_ORIGINAL_GATED_BILAYER_LARGE_AREA_RESPONSE.md), [fixed source model](source-models/E2_ORIGINAL_GATED_BILAYER_LARGE_AREA_RESPONSE.md), [full independent review](reviews/E2_ORIGINAL_GATED_BILAYER_LARGE_AREA_RESPONSE.md). Original plain filenames inside historical bodies are resolved through these companion locators; the exact bodies below have not been edited.


<!-- BEGIN SOURCE137-EXACT-E2_ORIGINAL_GATED_BILAYER_LARGE_AREA_RESPONSE-CONSTRUCTION -->
# Original gated interacting AB bilayer: large-area interaction, local dynamics, thermal states and physical response normalization

AUTHOR MANUAL SCIENCE — fresh genuinely nonauthor WHOLE scientific review and lead intake required. No model, project, helper, recipe, numerical/symbolic mathsoftware, test, native or runtime was executed. No production source was changed. This is a substantive component of the ORIGINAL large-area E2 physical bridge; it is not device/transport/window completion.

## 1. Fixed family and chronology

This is the deliberately NEW r4 correction, not a refresh of either stopped attempt. The original r4 FIRST ran once16:17:30.496186–16:17:31.015333 UTC, rc0/fresh with separate empty stderr. The complete actual immutable initial protection was saved16:18:10.002665 UTC (2ef14fece9498d74ba21fc90d383bdd237497e978e3606c7727575773df896bf), including ALL literal historical P7/N64/M3 states, the missing primary infra.md, all actual tracked/dirty/untracked states, raw/semantic indexes, HEAD/status/refs/admin and all eight initial output absences. Actual primary porcelain was ZERO; historical known paths are not relabelled dirty.

The new immutable SOURCE_MODEL was saved16:18:10.002875 UTC (6bac520a3349d8c68e9dbb6d70a5e734151cc32cc4d0fe4f5abc635679c5cf72), immediately after the frozen baseline and BEFORE any new corrective mathematics. Its complete original95,094-byte ce3c5733 enclosure and failed-r3MODEL419916fa enclosure are exact. The latter is historical unaccepted INPUT, not accepted weighted-tree proof. I stopped before new mathematics for independent lead protection intake. Lead receipt76823456bd697edeb487c12b1a56c19231c7ff2a3de42c61276080bb7a24c037 verified217 checks/zero failures and allowed MANUAL-SCOPE mathematics only; my acknowledgement was recorded16:20:21.334058 UTC BEFORE new r4 reasoning. Its one administrative-time UNKNOWN is unwaived. The baseline/model are immutable and no FIRST is repeated.

Failed r3 is FAILED AUTHOR PROCESS: its initial capture lacked the seventh historical primary absence although six other known files were tracked/protected. Its later absence capture and genuine model-before-math did not cure that initial gap. Its stopped analysis/no-proof record and original checks remain immutable; no admissible completed r3 proof is used. Prior failed NJL r1 preMODEL scratch and the older growth definition-read-first failure also remain unwaived. This new coherent author construction needs a fresh genuinely nonauthor whole review.

Historical r2 chronology, retained as such (NOT the current task's FIRST or baseline):
The genuine FIRST ran once 15:21:03.965408–15:21:04.280829 UTC, rc0, fresh=true, changed=[], empty separate stderr. Initial 42-input/full P-N-M protection ended15:21:16.166229. The new fixed SOURCE_MODEL was saved15:21:34.136139 UTC, SHA ce3c5733592845249a3d7e67805cd790b9eac747b31d28112ece7f93bd80e9a5, BEFORE any new geometry/packing/extension/normalization or other mathematical reasoning by this author. Its 95,094 bytes contain the entire original retarded MODEL dca1bfb1, r3 MODEL72df7302, growth MODEL5f9584a6, terminal MODEL1f9fc9d3 and HISTORICAL failed-r1 MODEL99fed34a byte-exact. The failed NJL r1 scratch interval after15:14:39.296075 and before15:16:46.107127 remains FAILED PROCESS, not proof, acceptance, model-first compliance or a waiver. Its fixed chart is input to be proved, not an accepted geometrical lemma.

The full prior interacting r3/growth/retarded constructions and independent reviews were personally read in earlier independent reviews; their exact pinned hashes match here. The current full original definitions, failed-attempt REPORT/process/construction/model/receipts and new packet were read before mapping/derivation. Reusing an unchanged source read is disclosed; it is not a claimed fresh proof of every unrelated bundle. Original pre-MODEL and definition-read-first failures remain unwaived. Source-author roles provide no scientific self-acceptance.

Retain the original two physical spins, q=-e, nonzero actual intralayer/vertical/contact hoppings, original finite-band semi-infinite contacts, grounded-plane rigid-cloud Coulomb density interaction and its physical self-image/background onsite terms, every finite beta>0 and real mu, physical lambda=1 and original real comparison lambda. All original independent lead temperatures beta_a/mu_a (and separately justified zero-temperature limits), partitioned/correlated initial states, quench sources, contact currents, Peierls Hessians, neutral and charged CAR sectors remain. No free, zero-interaction, mu=0, chosen favourable state/graph/material/window replaces this family.

An increasing-domain theorem necessarily concerns a CONSISTENT extension of these physical inputs to an infinite AB chart. Arbitrary unrelated finite samples do not define such an extension. Every finite original sample remains a pointwise member; a uniform constant below is only claimed when its stated infima/suprema in the actual supplied family are finite. They are parameters to measure/justify, not invented favourable numerical constants.

## 2. Physical AB geometry and evaluated counting

Use the prospective chart in the fixed historical input, up to rigid rotation/translation:
a1=(sqrt(3)b,0), a2=(sqrt(3)b/2,3b/2), delta=(0,b), b>0;
A1=(R,z1), B1=(R+delta,z1), A2=(R+delta,z2), B2=(R+2delta,z2),
R=m a1+n a2, z2=z1+d, z1,d>0. Retain the three intralayer nearest-neighbour bonds and actual vertical B1-A2 hopping. Finite restrictions include the original four-orbital path (up to rotation/choice of bond direction); no extra orbital/valley is inserted.

The cell area is
    Ac=|det(a1,a2)|=3 sqrt(3)b^2/2.                         (1)
For |m|,|n|<=L the exact cell count is Nc=(2L+1)^2, area Ac Nc, four spatial orbitals and EIGHT spin orbitals per complete cell. The spin is already in those eight; there is no further valley, layer or spin multiplier.

For counting, the projected union R+{0,delta,2delta} is a triangular lattice of spacing b. Indeed u=delta, v=a2-delta have |u|=|v|=b and u.v=b^2/2; a1=2v-u and a2=v+u, giving an index-three sublattice. The three cosets above exhaust it. The squared norm of m u+n v is b^2(m^2+mn+n^2), a positive integer times b^2 when nonzero. Thus projected distinct positions are separated by at least b. A projected point has at most TWO spatial orbitals: B1/A2 coincide in projection and are separated vertically by d. Both spins are counted later, not in this spatial packing.

Put disjoint planar discs of radius b/2 around projected points. For r in [nb,(n+1)b), n>=1, those discs lie in the annulus [(n-1/2)b,(n+3/2)b]. Dividing its area by pi b^2/4 gives 16n+8 distinct projected points; multiplicity two gives
    N_shell(n)<=32n+16 spatial orbitals,
    sum_(j:rho_ij>0) rho_ij^-3
      <= b^-3[32 sum n^-2+16 sum n^-3] <=88/b^3.           (2)
The last evaluations use sum n^-2<=2 and sum n^-3<=3/2 from the decreasing-function integrals. They are conservative ANALYTIC numbers, not computed lattice sums. Every vertically aligned partner is excluded from (2) and included explicitly below.

For K>=2, a radial tail rho>=Kb satisfies
    P(K):=b^-3[32/(K-1)+8/(K-1)^2],
    sum_(rho>=Kb) rho^-3 <= P(K).                         (3)
Here sum_(n>=K)n^-2<=1/(K-1) and sum n^-3<=1/[2(K-1)^2]. An arbitrary cutoff r uses K=floor(r/b) with the threshold rounded DOWN and K>=2; otherwise use88/b^3. No shell is skipped near the origin.

## 3. SAME image kernel, onsite, aligned pairs and uniform physical sums

Let ke=e^2/(4pi epsilon), epsilon>0, radius ai>0, zi>ai, all actual spheres disjoint. The original two harmonic mean-value averages and the uniform-sphere interior Poisson solution give EXACTLY
    Uii=ke[6/(5ai)-1/(2zi)],
    Uij=ke[1/Rij-1/Rij*], i!=j,
    ui=-ke/(4zi)-sum_j Uij nu_j.                          (4)
These are J coefficients, not a homogeneous continuum J m^2 kernel. The negative single-electron self-image remains; only the original bare individual self-energy is removed. The pair interaction is still onsite opposite-spin plus ALL intersite four-spin pairs.

For nonaligned planar separation rho>0,
    1/R-1/R* =4zi zj/[R R*(R+R*)] <=2zi zj/rho^3.         (5)
This follows by rationalizing the two square roots; positivity follows because R*>R. It is the actual grounded-image cancellation, not an assumed short-range cutoff. At rho=0 the possible other-layer site contributes
    Uvertical=ke[1/d-1/(z1+z2)] <=ke/d.                   (6)
It is positive, retained and not bounded by dividing by zero in (5).

With Z=z2, amin=inf ai>0 on the stated uniform domain, set
    U0=6ke/(5amin),
    Soff=ke/d+176ke Z^2/b^3,
    S=U0+Soff.
Then
    Uii<=U0, sum_(j!=i)Uij<=Soff, sum_j Uij<=S.            (7)
The tail outside rho>=Kb contains no aligned partner for K>=2 and obeys
    T_U(K)=2ke Z^2 P(K).                                 (8)
Equations (7)/(8) hold for all finite restrictions and their infinite consistent extension. They do not require a positive lower radius for OFFSITE sums; only U0 uses amin. Fixed finite radii, dielectric/heights/b/d have their original physical meanings. Taking ai->0 or epsilon->0 can make a family constant diverge; no fixed uniform bound over that unrestricted parameter family is asserted.

Assume the actual backgrounds satisfy nu*=sup|nu_i|<infinity and the actual external onsite energies have E*=sup|e_i^external|<infinity when using the uniform-energy theorem. Background sums in (4) then converge absolutely and |ui|<=ke/(4z1)+nu* S. If finite samples use background sums only over their own central region, their onsite correction to the full restriction is <=nu* times the missing U row; it is NOT silently declared the same finite Hamiltonian.

## 4. Incident energy, contacts and genuine representation/domain

For each spin orbital x, retain actual hopping row including all attachments. In the ideal chart with actual maxima gamma0*, gamma1*, central contact row V*=sup_i sum_a|v_ia| and finite lead row bound Rlead*, the original decomposition gives
    Rkin <= E*+ke/(4z1)+nu* S+3gamma0*+gamma1*+V*
on central sites, and the actual maximum lead endpoint/interior row on contacts. A homogeneous channel has interior |epsilon_a|+2|t_a| and endpoint |epsilon_a|+|t_a|+sum_i|v_ia|. Inhomogeneous bounded-degree contacts instead use their actual absolute row supremum, not merely a claimed finite bandwidth for unrelated growing samples. Define
    J_E=max(Rkin,Rlead*)+|lambda|(U0+2Soff).               (9)
There is ONE onsite opposite-spin partner and TWO spins at each other site. A Hermitian hopping pair has norm |hxy|, not2|hxy|; a density-pair term has norm |lambda|Uij. Thus (9) bounds the actual sup_x sum_(X contains x)||Phi_X||. Full contact counts/couplings remain in the row, not dropped to make it finite. A growing boundary may have many channels while this row stays bounded; a site with arbitrarily many fixed-strength channels violates (9)'s domain and retains only its original pointwise finite constant.

For a fixed supplied consistent infinite graph satisfying (9), every p-particle sector of the physical vacuum Fock representation has bounded kinetic operator norm<=p Rkin_total and BARE density interaction norm<=p(U0+2Soff)/2 (multiply by |lambda| for lambda V): in an occupied configuration its pair energy is half the sum of occupied incident coefficients. The sum over countably many positive pair coefficients is absolutely finite in each p sector. The sector operator H_p is bounded selfadjoint, and
    H=direct_sum_(p>=0) H_p,
    D(H)={Psi:sum_p ||H_p Psi_p||^2<infinity}              (10)
is selfadjoint; truncating sectors gives a core, and finitely supported configurations are dense cores inside each bounded sector. This is NOT a bounded global H, globally bounded V, finite infinite-lead number or infinite Gibbs trace. Thermal representations use the algebraic dynamics constructed next, not a vacuum normal-state substitution.

The actual vacuum-Fock implementation in (10) agrees with the algebraic limit: on each fixed p sector finite-box operators, extended by zero outside, converge strongly to H_p with a common O(p) bound. Their exponential series converge strongly on compact times. Thus conjugation of each local A has the same strong representation limit as its CAR-norm limit in section5. On the finite-particle core the commutator equals the bounded generator value from (11); closedness extends the domain relation. This is a representation/domain check, not a claim that a thermal state is normal on vacuum Fock space.

For local A on s spin orbitals, even interaction terms commute with disjoint CAR polynomials including odd A. Absolute connected-support tree sums replace the old FINITE clique:
    ||ad_H^n A|| <= ||A||(2J_E)^n(s)_n,
    ||delta_H^n A|| <= ||A||(2J_E/hbar)^n(s)_n,
    (s)_n=s(s+1)...(s+n-1).                              (11)
At depth j the sum of possible incident next terms is <=(s+j)J_E, with at most one added spin orbital. Countably many choices are absolutely summable by (9), so finite partial sums converge. The geometric support may be long range; no finite-range radius is assumed. The generator result below proves the actual commutator/domain meaning rather than using an arbitrary unbounded-operator product.

For literal F3 mapping only, (s)_n<=s^n n! gives commutatorNorm(n)=||delta_H^n A|| <=n!(2sJ_E/hbar)^n||A||. The corresponding ENERGY-commutator sequence uses2sJ_E, not the frequency scale. For physical site Q_i=q(n_iup+n_idown), sum the two one-mode bounds to obtain scale2J_E/hbar and reference norm2|q|. This is the actual original local charged-density operator on the declared domain. It does not assign calibrated D,tau,chi,a or CHHK epsilon to the DKM five-real tuple. The current Predicates F3 merely consumes such a numerical sequence/majorant; its all-frequency F4/F6 and other known source/API issues are not physically repaired by a growth bound. No MIR, six-family witness or physical platform classification is inferred.

## 5. Constructed norm local dynamics and finite cuts on the ENTIRE summable-contact domain

The uniform-energy domain is (9). Every finite central/contact restriction is an actual finite CAR automorphism. For local A on s spin orbitals its Taylor majorant is
    ||A|| sum_n (s)_n a^n/n! = ||A||(1-a)^(-s),
    a=2J_E |t|/hbar<1.                                  (12)
Every fixed-order countable interaction tree is absolutely summable. Its finite-restriction limit and (12)'s positive dominating series give a norm limit, uniformly on compact smaller time intervals. Finite-box isometry plus local approximation passes products, adjoints and short-time composition; the negative-time limit is the inverse. Iterating the small-time group gives all real times, with point-norm continuity. Differentiating the absolutely convergent series on a smaller disc proves local A belongs to every generator power and proves (11), rather than merely writing a formal commutator. This uses neither a bounded global V nor an extensive global Dyson w.

### 5a. Q2: physical decorated incidence, with the missing constant actually defined

Set Rexternal := E* = sup_i |e_i^external|, an ENERGY in J on central sites. Rlead* already includes the actual lead onsite and hopping/contact rows; it is not Rexternal and is not added a second time as a physical onsite term. A conservative bound convenient for a literal background restriction is
    Jbar=max(E*+ke/(4z1),Rlead*)+
         4nu* S+|lambda|(U0+2Soff)+3gamma0*+gamma1*+V*.
                                                               (13r)
Every term in (13r) has units J. Central hopping terms may overbound a lead row when added outside the maximum; that is deliberate safe overcounting, not a new interaction.

Decompose the actual Hamiltonian into countably labelled selfadjoint EVEN terms Phi_e. Each has a decorated support of at most TWO spin modes. Hopping/density terms use their actual modes. For each background contribution -Uij nu_j n_i,sigma, include virtual anchor j,up in that decorated support. This anchor does not introduce an extra physical operator or spin factor. Real-target background incidence is <=nu*S; virtual-anchor incidence, summing the two real target spins, is <=2nu*S. The displayed 4nu*S safely covers their union, including coincident onsite labels. External/self-image singleton terms, onsite opposite-spin terms and all actual lead hoppings are retained separately. Consequently
    sup_x sum_(e: x in decorated supp(e)) ||Phi_e|| <= Jbar.
It is THIS decomposition that is restricted by the finite set; one must not also keep a second background onsite sum already incorporated in Rkin. An alternative finite prescription retaining the full infinite-background onsite coefficient is a different onsite comparison, with its explicit discrepancy retained.

For a finite support set Y and central cutoff K>=2, keep all onsite/aligned terms and every electrostatic/background pair incident to Y with rho<Kb, plus the cutoff shell if desired. The omitted decorated-row energy is at most
    tau_U(K)=(4nu*+2|lambda|) T_U(K).                    (13s)
The quartic coefficient two counts the partner spins, not a valley. This is evaluated from (3)/(8), independent of any contact geometry. All omitted hopping/contact contributions use their ACTUAL absolute-row tail
    c_x(C)=sum_(hopping edge e incident to x, e not in C) |h_e|.
Finite central nearest neighbours, vertical hopping and a finite neighbourhood on each selected nearest-neighbour lead can be kept exactly. For a general summably attached endpoint or central site, absolute row summability guarantees a finite list C with c_x(C)<=tau_C. No uniform rate over arbitrary sequences with the same total row bound is asserted. The actual list plus an upper bound on its residual row is required DATA for a numerical certificate; mere convergence of an unspecified series is not a computed error bound.

### 5b. Q1: finite DEPTH-DEPENDENT weighted trees; no finite-ball assumption

The retained counterpopulation v_a=v0 2^(-a), a=1,2,..., attaches countably many nonzero homogeneous semi-infinite channels to one original central site. Its contact row is |v0| and its original unit-link radius-one ball is infinite. Thus the old instruction "choose finite Gamma containing that metric ball" is impossible on this admitted population. Neither bounded rows nor finite bandwidth implies properness of that graph metric. We retain every channel, both spins, actual interactions and every beta/mu/state; the repair is a quantitative finite approximation to this infinite population, not deletion of it.

Here is a construction for any supplied finite spin support X, s=|X|>=1, integer N>=0 and energy tolerance tau>0. Put S_0 equal to X, adding a physical partner spin when needed for a finite-box convention. At each depth j=0,...,N-1, S_j is a FINITE set. For each x in S_j choose a finite incident term list whose omitted norm row is <=tau, using (13s) and actual contact/hopping tails. Let K_j be the finite union of these lists; let S_(j+1) contain S_j and every decorated endpoint of every term in K_j. Whole-site/cell closure may be added but is not used to inflate the actual word support count. Let Gamma contain the finite union of all these endpoints. Complete a finite central-cell patch, a FINITE set of selected channels and their finite lead prefixes to obtain an admissible original finite restriction. Any extra internal terms in that restriction are kept. In particular Gamma need not, and generally cannot, contain every metric ball.

An accepted n-word, n<=N, chooses its (j+1)th interaction from K_j and meets the current decorated support. Induction places its current support inside S_j and every endpoint inside Gamma. Its actual word support size is <=s+j, because an incident term has at most two modes and adds at most one. The sets K_j are DEPTH DEPENDENT. We do NOT assert their global union is closed under all incident edges; using a late-depth selected edge prematurely would invalidate that tempting but unnecessary closure argument.

A word lost by restricting the full Hamiltonian to Gamma cannot be accepted. At its FIRST failed depth j the prefix is accepted and lies in S_j. The omitted next norm sum at this support is <=(s+j)tau. Prefix and suffix sums are bounded by the corresponding factors (s+l)Jbar. After 2^n from commutators, for each marked failed position the full word majorant is
    2^n (s)_n tau Jbar^(n-1) ||A|| .
Summing the n possible first-failure positions bounds every lost n-word, even when extra internal terms of Gamma generate other words. For n>N use the full Taylor tail. Absolute convergence permits all these countable positive sums and the word subtraction. Therefore, with a=2Jbar |t|/hbar<1,
    ||alpha_t(A)-alpha_Gamma,t(A)|| <= E(X,t;N,tau)
      :=||A||[ (tau/Jbar) s a/(1-a)^(s+1)
               + Tail_(s,N)(a)],
    Tail_(s,N)(a)=sum_(n>N) binomial(s+n-1,n) a^n.       (14r)
The same proof bounds the difference of nested finite restrictions, with the outer full row bounds; both contain the accepted word set. There is no factor proportional to the total area or number of discarded channels. If Jbar=0 the dynamics is constant and no division is used. At t=0 the error is zero. For a scalar identity (empty support) or zero A the comparison is direct and constant; divisions in the budget prescription are only used for nonzero A and s>=1.

This is a proved weighted-tree bound for the whole stated summable-row family. Its constructive finite sets exist by finite unions of absolutely summable incident rows. It supplies a quantitative certificate WHEN the actual selected row tails are supplied or analytically bounded. It does not promise an effective modulus from a bare black-box declaration that a series converges.

### 5c. Evaluated finite budget and the original infinite-contact control

For 0<a<=1/2, choose N>=2s. The ratio of consecutive Taylor terms at n>=N+1 is
    a(n+s)/(n+1)<=3/4.
Thus a wholly explicit bound is
    Tail_(s,N)(a)<=4 binomial(s+N,N+1) a^(N+1).          (14s)
Choose N large enough to make this <=epsilon/(2||A||), and
    tau <= epsilon Jbar (1-a)^(s+1)/(2||A|| s a).
Both choices are finite. There is no numerical engine, hidden grid change or discarded nominal sample in this statement. The binomial/exponential expression tends to zero for fixed finite s and a<1; it is an evaluated formula, not a finite-volume runtime receipt.

Allocate tau_U<=tau/2 and each hopping/contact row tail <=tau/2. Write w=4nu*+2|lambda|. Since K>=2 gives P(K)<=40/[b^3(K-1)], it suffices to choose
    K>=max(2,1+ceil(160 w ke Z^2/(b^3 tau))).            (14t)
Onsite and aligned terms are always kept. For v_a=v0 2^(-a), keeping the first m channels gives exactly
    sum_(a>m)|v_a|=|v0|2^(-m).
Hence m>=max(0,ceil(log_2(2|v0|/tau))) supplies the hopping half-budget when v0!=0; v0=0 is handled directly. Each newly reached endpoint is expanded by actual finite lead neighbours at subsequent depths. This is a real finite selection despite the infinite original radius-one ball. For multiple/multisite contacts use each finite frontier's actual row tails, retaining all its physical couplings in the infinite limit. A finite prefix of an arbitrary enumeration alone is not evidence of a small tail.

The sharper control from the original population is independent of this conservative l1 error estimate. For A=n_i,up, let d=sum_(a>m) v_a c_a/sigma_tail at the omitted first lead orbitals, where
    sigma_tail=(sum_(a>m)|v_a|^2)^(1/2)
              =|v0|2^(-m)/sqrt(3).
The CAR makes d a normalized single fermion mode. The omitted commutator is, up to an irrelevant phase,
    [H_missing,n_i,up]=sigma_tail(d^dagger c_i-c_i^dagger d).
On the one-particle two-mode subspace its two eigenvalues have absolute value sigma_tail; it vanishes on empty/doubly occupied sectors. Thus
    ||delta_H n_i,up-delta_cut n_i,up||
        =|v0|2^(-m)/(sqrt(3) hbar).                     (14u)
All density interactions commute with n_i,up and cannot cancel these orthogonal contact transitions. Nonzero bilayer hopping/other retained terms cancel between the compared derivatives, not between different physical models. This exact l2 derivative error is not misidentified as the l1 row budget for all support trees. Omitting infinitely many finite-strength contacts would leave an infinite row and is outside the uniform theorem; summably decaying nonzero contacts are fully inside it.

### 5d. All real times, nested cuts and honest state/filter transport

For any prescribed |T| choose p with 2Jbar|T|/(p hbar)<=1/2 and delta=T/p. Start B_0=A. At each step B_(j-1) is a bounded operator in a FINITE local CAR algebra, even though its finite evolution is not a one-site polynomial. Its finite support size s_j is used without pretending it equals the initial s. Select depth/order/tails by (14r)-(14t) for this actual finite support; choose nested Gamma_j containing the accepted words and all previous boxes; set B_j=alpha_Gamma_j,delta(B_(j-1)). With e_j the corresponding bound,
    ||alpha_T(A)-B_p||<=sum_j e_j,
    ||alpha_T(A)-alpha_Gamma_p,T(A)||<=2sum_j e_j.        (15r)
For the second inequality, telescope the same step product against the fixed outer automorphism; each nested finite comparison obeys (14r). No support/cardinality is kept fixed while a box grows. The choices are sequential: p is finite, each preceding support is fixed before the next finite selection, and arbitrarily small assigned e_j can be met.

One can first select arbitrarily small tau_U via K and tau_C via actual contact lists, then the finite propagation order N, or choose N then tails as above. A larger central restriction alone does not include omitted contact channels, and a longer selected lead alone does not reduce a Coulomb/background row. Complete-cell central closure, the number of selected contact channels, their actual lead depths, electrostatic/background cut, temporal step/order and filter/time cut are separate recorded controls. Enlarging any box while retaining all selected words preserves the stated bound; no monotonicity of the actual oscillatory response is inferred.

For a prescribed finite set of local observables and compact time interval apply the construction to all of their finite supports and use the maximum time in (14r)/(15r). These estimates imply compact-time local convergence along any cofinal restriction containing the selected finite sets. They do not give an error rate for omega_Gamma's choice of thermal phase or local state. Section13 retains that separate actual functional error and the true-UHP tail.

### 5e. What the OLD metric formula actually requires

The metric in the earlier candidate can still be used IF its requested ball is finite and a finite Gamma contains it. Assign contact/lead links length1 and direct central links EXACTLY 2+rho/b (the opposite-spin/local link has rho=0 and length2), then take the shortest-path metric; choose ell0=4 for the ideal short hoppings. Every assigned edge has length>=1. These explicit lengths, not an arbitrary upper-bound-only assignment, are used for the following proper-ball example. A long central edge of metric length>ell has rho>b(ell-2), so its decorated long-edge incident tail is
    Tbar(ell)=(4nu*+2|lambda|) T_U(floor(ell-2)),
    ell>ell0, floor(ell-2)>=2.                           (13m)
If Gamma CONTAINS the metric R-ball about X, all-short n-words cannot exit for n<=floor(R/ell). First marking a long edge gives
    ||alpha_t(A)-alpha_Gamma,t(A)||
      <=||A||[(Tbar/Jbar) s a/(1-a)^(s+1)
            +Tail_(s,floor(R/ell))(a)].                 (14m)
This implication is valid; existence of such finite Gamma is an ADDITIONAL proper-ball property. It holds, for example, on the actual ideal AB chart with finitely many finite-attachment nearest-neighbour leads per central site: from each vertex only finitely many assigned edges have length at most any fixed R (packing for central links, finite attachment for contacts). A path of length<=R+1 has at most floor(R+1) edges because each edge has length>=1. Iterating the finite neighbour sets finitely many times gives a finite set containing the radius-R ball, even if a shortest-path infimum were not attained. Each selected nearest-neighbour lead also has finite depth. Finite-attachment-degree is an example for this optional metric route, NOT a restriction of the full original family. On the v_a population (14m)'s finite-ball premise fails. Its valid replacement there is (14r), with explicitly controlled omitted hopping tails. Neither an abstract F-norm theorem nor a renamed "radius" repairs the old missing premise.


## 6. What remains true without a uniform lower radius

The original finite family never supplied amin>0 for arbitrary growing choices. A counterpopulation of smaller disjoint radii at distant sites makes Uii grow without bound, so neither (9) nor a uniform all-order scale follows automatically. This does not eliminate those samples or make their physics impossible.

For a consistent extension with bounded actual hopping/contact rows, bounded offsite incident sums (7), and each finite onsite coefficient, existence of local dynamics can still be constructed even when onsite/background energies are not uniformly bounded. Put all physical onsite operators into D_i=e_i N_i+lambda Uii n_iup n_idown, including the actual pointwise convergent background where it exists. The product of finite-dimensional onsite unitaries defines an isometric, strongly continuous local CAR group alpha_D on the norm completion (local continuity plus density). No infinite product operator or global onsite-energy norm is needed. On each PHYSICAL site, the remaining spin-summed hopping term has norm<=2|hij|, and the offsite density term has norm4|lambda|Uij. Thus
    Jres<=2 Roffhop+4|lambda|Soff                           (16)
per physical site is finite. In alpha_D's interaction picture these even terms retain their two physical-site support and EXACT norm. Their time-dependent nested commutator/simplex series has the same absolute tree bound (12) with physical-site support count, Jres and real-time simplex |t|^n/n!. The two-parameter composition and time-translation covariance follow from the finite onsite-plus-residual boxes; finite-step extension gives the autonomous physical alpha_H. For different finite-background prescriptions one must additionally retain the actual onsite-phase error. On a finite physical support Y, with Delta D_i=D_i-D_i,Gamma, the commuting onsite products obey
    ||alpha_D,t(A)-alpha_DGamma,t(A)||
       <=(2|t|/hbar)||A|| sum_(i in Y)||Delta D_i||,
and ||Delta D_i||<=2|Delta u_i| for a pure background discrepancy. First restrict the residual series to a finite collection of support trees and time simplex order; its error is bounded by the same positive summability majorant. On that FINITE collection all Delta D_i tend to zero, so the displayed phase estimate and telescoping the finitely many interaction-picture factors gives convergence; then remove the absolute tree tail. This proves qualitative compact-time local convergence even without a uniform onsite bound. A quantitative error must include those actual finite-support Delta D_i terms. It is NOT the earlier metric bound(14), nor the uniform-energy bound(14r), with unbounded onsite constants hidden inside a finite Jbar. Fixed pointwise background convergence is required; nonconvergent sums remain outside this statement.

The finite weighted-tree repair also applies here, without silently restoring a bound on D. Use PHYSICAL sites, the actual residual terms with incident Jres, and the depth-dependent lists of section5b. Keep the actual onsite conjugations exactly; conjugation preserves the support and norm of every residual term. A sufficient residual row tail is
    tau_res=2 c_hop+4|lambda| T_U(K).                    (16a)
For small a_res=2Jres|t|/hbar<1, the time-ordered simplex has volume |t|^n/n!, so the same first-failed-word argument bounds the BAD word contribution by
    B_res=(tau_res/Jres) s a_res/(1-a_res)^(s+1)
             +Tail_(s,N)(a_res).
This is independent of the possibly unbounded remote onsite energies. When Jres=0, residual dynamics is absent: set B_res=0 directly and retain only the onsite-phase comparison, without division by Jres.

Let Y be the FINITE union of endpoints of all accepted words of order<=N, and
    d_Y(Gamma)=sum_(i in Y)||D_i-D_i,Gamma||.
The new finite Gamma contains every accepted word endpoint. The full and restricted evolutions can each have additional bad words, whose combined norm is bounded by 2||A||B_res. On an accepted n-word, the outer onsite conjugation of A and n conjugated interaction factors have n+1 onsite comparisons. Duhamel for the finite commuting onsite products bounds each relative comparison by 2|t|d_Y/hbar. Multilinearity and the same tree weights yield the explicit bound
    ||alpha_t(A)-alpha_Gamma,t(A)||
      <=||A||[2 B_res+
        (2|t|d_Y(Gamma)/hbar)
          sum_(n=0)^N (n+1) binomial(s+n-1,n) a_res^n].
                                                               (16b)
For n=0 the comparison is the onsite evolution of A. This overcounts but cannot hide the background-phase error. A pure missing-background discrepancy has
    ||D_i-D_i,Gamma||<=2|Delta u_i|,
    |Delta u_i|<=sum_(j omitted)Uij |nu_j|.              (16c)
When |nu_j|<=nu*, (8) gives an explicit decreasing bound on (16c) for all i in fixed Y as the central background cut grows. For a merely pointwise convergent onsite prescription without a supplied modulus, existence still follows by first fixing N/tails/Y and then enlarging Gamma; a numerical error certificate requires its actual finite-Y phase bound. It is not supplied by the residual row sum.

All-time finite-step approximation is again possible, now using (16b) and actual finite-Y phase controls at each stage. A nested finite comparison includes BOTH finite onsite discrepancies against the common full D, or their directly bounded difference; it cannot drop the outer-box phase because the residual terms are the same. Under bounded-background absolute tails, enlarging the common outer cut decreases the bound for each previously fixed Y. Under pointwise-only convergence one must supply the requisite joint future-cut modulus or use the qualitative two-limit argument. This proves the retained weak-domain qualitative compact-time dynamics without promising an absent rate or higher generator moments.

This proves a larger dynamics domain than a uniform all-order operator-growth domain; it does NOT claim (11) under unbounded onsite coefficients. High generator derivatives can require weighted sums of remote onsite energies after a long interaction creates remote current factors. Such weighted domains need separate proof. Arbitrarily unbounded contact/hopping rows or nonconvergent background sums have not been admitted by a finite-box label; their actual compatibility/selfadjointness/dynamics remain an explicit additional construction. All finite original samples retain their exact dynamics and pointwise bounds.

## 7. Positive thermodynamic equilibrium states and chemical twist

Use the actual same finite central restrictions with finite contact boxes and full two-spin finite CAR Gibbs density
    rho_Gamma=exp[-beta(H_Gamma-mu N_Gamma)]/Z_Gamma.      (17)
It is finite, positive, normalized for every finite beta>0 and real mu and every original nonzero interaction/hopping. It need not be Wick or weakly coupled. Extend its expectations outside the box by any fixed positive even product state; local values inside are unchanged. The CAR algebra is separable. Diagonal extraction on a countable norm-dense set of local matrix units, followed by continuity, gives a weak-star convergent subsequence omega. Positivity, normalization, gauge invariance and all original local spin/charge definitions pass to that limit.

The local norm dynamics of sections5/6 gives the corresponding grandcanonical tau_t=gamma_(-mu t/hbar)alpha_H,t. Local finite-box dynamics converges uniformly on compact real-time intervals. To pass KMS, first use Gaussian analytic smears of local observables under tau. For any fixed smear width, the finite-box real-time Gaussian tails are uniformly bounded by isometry; compact-time convergence gives norm convergence of the smeared observables and their fixed closed-strip translates. Finite Gibbs cyclicity gives the strip of height beta hbar. The strip functions are bounded by ||A||||B||, as follows by the finite Gibbs trace Holder inequality on an intermediate line and the maximum principle; no area-divergent partition-function ratio is used. Subsequential locally uniform limits have the real-edge boundary omega(A tau_t B) and upper edge omega(tau_t B A). Equivalently apply the bounded-strip argument to the fixed analytic smears, then norm density of those smears in each fixed CAR element proves full tau-KMS. The Gaussian parameter is held fixed for the finite-volume limit; removing the smear is NOT taking an epsilon->0 bound that diverges first.

Hence at least one positive thermodynamic grandcanonical KMS state exists on the stated summable-dynamics domain, along actual finite prescriptions. On a charged grade-r B, gamma_theta(B)=exp(i r theta)B; the physical-H KMS boundary retains exp(-beta mu r), while neutral currents/densities obey the ordinary physical-H KMS. Physical stationarity follows from tau and gauge invariance, not from falsely calling full-CAR alpha_H KMS at mu!=0.

This is EXISTENCE/subsequence, not uniqueness, clustering, a selected material phase, translational invariance, bulk susceptibility, or a unique NESS. Different admissible distant boundary prescriptions or subsequences may select different KMS states. Gauge-invariant boundary interactions with uniform local bounds and support receding from any fixed region do not change the limiting LOCAL generator; they can still change the selected state. Arbitrary nonlocal boundary fields are not included by that sentence. Original finite-central/infinite-contact states remain the earlier unique local construction in their own domain, not asserted equal to every central thermodynamic state.

Original nonstationary preparations remain positive states on CAR (or weak-star subsequences of their actual finite preparations) evolved by alpha_H. Correlated initial higher moments are retained. Dynamics convergence plus local state convergence controls finite-time observables; no quench is reclassified as thermal, stationary, or Gaussian. There is no rate of state selection supplied by compactness: local restriction errors must be retained as actual state-functional differences.

## 8. Boundary energy scaling — density tails are not finite range

For the complete-cell parallelogram let n=2L+1. Removing an outer m-cell strip leaves at least (n-2m)^2 cells, so the removed count <=4mn. Each single depth layer contains <=8n cells (a conservative overcount), hence <=32n spatial sites. Distance from cells m layers inward to missing cells is at least (3b/2)m minus the bounded basis offsets; for m>=3 it exceeds b(m-2). The first FOUR layers (depths0,1,2,3) use Soff; only depths>=4 use (8). Consequently, for L>=4, define CutU_L=sum_(i inside,j outside)Uij. A proved conservative bound is
    CutU_L<=32 n [4Soff+
          (2ke Z^2/b^3)(32(1+log L)+16)].               (18a)
There are FOUR exceptional near layers (depths0,1,2,3). For m>=4 use (3) with K=m-2>=2; sum1/(m-3)<=1+log L and sum1/(m-3)^2<=2 give the displayed constants. An actual earlier manual attempt proposed32n[3Soff+(2keZ^2/b^3)(32(1+logL)+16)] as provisional(18), missing the depth3 layer. That expression is REJECTED and preserved here as failed-attempt history; only(18a) is asserted or used. The extra layer is not hidden in an O notation, and all original populations remain.

Thus CutU_L/(Ac n^2)=O(log L/L) with evaluated constants. With two spins, the norm of a cross-boundary quartic pair is<=4|lambda|Uij. Missing background one-body norm is<=2nu*Uij per inside site. These give per-area electrostatic/background boundary bounds (4|lambda|+2nu*)CutU_L/(Ac n^2); retaining exterior Hamiltonian terms is a different comparison, not a finite norm of the infinite total energy. Onsite terms in a common restriction have no crossing contribution. The first spatial moment of the r^-3 tail is logarithmically divergent in 2D, so replacing this by a claimed finite-range O(1/L) surface constant would be unjustified.

## 9. Physical electrochemical, spin, area and adjoint conventions

For actual finite real weights gi and in-plane wavevector k (m^-1) define
    A_k=q sum_(i in central,sigma) gi exp(-ik.rho_i)n_i,sigma,
    A_k^dagger=A_-k.                                     (19)
No k/-k inversion symmetry is assumed for an arbitrary state, contact or disorder. Hermitian cosine/sine components carry the full matrix cross channels. Full complex weights use their actual conjugate in the adjoint. There are four spatial orbitals and two spins per cell already; interacting noise sums all four spin-pair correlations and is not multiplied by two after evaluation.

A scalar voltage phi enters H_phi=+sum_i phi_i Q_i. For predecessor response H'=-f A the physical source is f_Q=-phi. The full-CAR mu is energy, and an electrochemical variation is delta mu=q delta V; q=-e is retained. Particle susceptibility and charge response differ by q factors; sheet density Q/A, extensive Fourier charge A_k, and source conjugacy are specified before dividing:
    chi_perarea(k,z)=chi_(A_k,A_-k)(z)/Area,
    M_perarea=M_(A_k,A_-k)/Area.                          (20)
Response of the averaged density to a uniform physical source is a 1/Area normalization of the extensive response. Covariance of TWO area-averaged operators is instead M/Area^2. A contact current is the original terminal current in amperes; it is not multiplied by Area or the number of cells.

Every finite-family response uses the original true-UHP Cauchy transform chi(z)=hbar^-1 int K(domega)/(omega-z), S^>=2pi M, bthermal=beta hbar, actual elastic E=M({0}) and the correct KMS matrix transpose/adjoint. All finite-beta, charged, null, elastic, probe and nonstationary two-time distinctions remain. Moment identities below do not alter those conventions.

## 10. Exact microscopic per-area f-sum and evaluated bounds

Density interactions and onsite terms commute with all Q_i. For any actual finite complex f, CAR gives
    F_Gamma(f):=omega([A_f^dagger,[H,A_f]])
      =-q^2 sum_(unordered hopping bonds i-j,sigma)
          |fi-fj|^2 omega(hij c_i^dagger c_j+h.c.) >=0,   (21)
in equilibrium, including ALL boundary/contact storage bonds, with f=0 outside its specified finite charge region. The positivity follows from omega-frequency times the signed equilibrium commutator measure, not an unsupported sign of each complex-phase bond expectation. In any state the exact RHS remains, but its total need not have the equilibrium sign. Per-spin bond norm is |hij|, yielding the state-independent upper bound q^2 sum_b,sigma |hij||fi-fj|^2. Its units are C^2 J. The integrated measure is
    int omega chi_AH(domega)/pi
       =F_Gamma(f)/hbar^2,
    int omega K_f(domega)=F_Gamma(f)/hbar.               (22)
Here chi_AH means the matrix anti-Hermitian spectral measure, not the entrywise imaginary part of arbitrary cross entries. Positive-frequency half of the full-line moment applies to a Hermitian channel; a complex k channel requires its -k adjoint and cannot silently use that half without the needed symmetry.

For gi=1 on complete central cells, the vertical aligned bilayer pair has fi=fj for IN-PLANE k, so its contribution is EXACTLY zero even though gamma1 and Uvertical remain nonzero. The three intralayer displacement vectors delta_j have length b and sum_j delta_j delta_j^T=(3b^2/2)1_2. Define Dj(k)=|1-exp(ik.delta_j)|^2. For a periodic/counting bulk sum or as an upper bound for an open complete-cell restriction,
    F_bulk(k)/Area <= (4q^2 gamma0*/Ac) sum_(j=1)^3 Dj(k)
       <= min(48q^2 gamma0*/Ac,
               6q^2 gamma0* b^2 |k|^2/Ac).             (23)
The factor4 is TWO layers times TWO spins. Equation23 is a BOUND; the actual f-sum is the interacting bond expectation (21), not saturation by -|h|. A genuine periodic finite flake needs its specified wrap phases; no periodicity is silently applied to the open contacts.

At an actual contact to a lead with f_lead=0, |fi-flead|=1. Its contribution obeys
    F_contact/Area <= 2q^2 sum_contacts |v_a|/Area.        (24)
For vector/multibond contacts retain each actual bond in the sum. Fixed finite contacts give O(1/Area); a uniformly weighted O(L) boundary set gives O(1/L); O(Area) contacts need not vanish. At k=0 central storage/contact response is not the conserved infinite total charge. The zero k bulk moment can vanish per area while elastic noise/compressibility do not.

Pure geometric missing intralayer bonds lie at boundary cells; at most4*8L boundary spatial sites times degree3 gives96L such bonds. Therefore a safe geometric error in (23)'s extensive numerator is
    192 q^2 gamma0* L max_j Dj(k),                       (25)
including both spins. This bounds missing TERMS, not differences of interacting state expectations. Comparing a finite state to a chosen infinite state adds the actual averaged local bond-functional mismatch; locality/compactness alone supplies no rate for it. Arbitrary nonuniform gi use exact (21) and their actual discrete gradients, including edge tapering; their bulk bound is not obtained by pretending gi=1.

## 11. Uniform higher weighted moments without static-variance inference

For a finite density sum with |fi|<=W, ad_H^n of each single-spin number has the absolutely summable tree bound (11). Its decorated ACTUAL operator support contains at most n+1 spin modes; density terms in A_f^dagger outside that support commute. Commuting the at most n+1 remaining number terms costs at most2|q|W(n+1). Sum over8Nc initial spin modes. For n>=1 this proves the genuine extensive bound
    |omega([A_f^dagger,ad_H^n A_f])|/Area
       <=(16q^2 W^2/Ac) (n+1)! (2J_E)^n.                (26)
It is independent of Area and state. The full signed spectral identity has the corresponding factor hbar^-n. For ODD n the equilibrium scalar quadratic-form integral int omega^n K_f is nonnegative and controls int |omega|^n |K_f|. Therefore for R>0, retaining BOTH signs and actual adjoints,
    M_f({|omega|>=R})/Area
       <= [16q^2 W^2 (n+1)! (2J_E/hbar)^n]
             /[Ac R^n (1-exp(-beta hbar R))], n odd.    (27)
The negative-frequency denominator has larger absolute value and is safely bounded by the same positive quantity. The same statement holds in matrix quadratic-form order after replacing W by the actual combined-channel maximum. Finite moments are not assumed from the finite one-particle band.

Optimizing an allowed odd n gives an explicit exponential WEIGHT tail, for example choose odd n with n+1<=R/(4J_E/hbar) and use (n+1)!<=(n+1)^(n+1). There is no pointwise PSD bound, physical CHHK optimal coefficient, or low-frequency noise-mass control here. Bounds (26)/(27) require the uniform all-order domain (9); they are not asserted from the weaker existence domain (16).

### 11a. A genuine subsequential per-area UHP RESPONSE, without a bulk-noise claim

More can be constructed than a bound alone. Densities commute at equal time, so int K_f=0. Set the POSITIVE weighted matrix measure nu_Gamma(domega)=omega K_Gamma(domega)/Area for a fixed finite family of real/complex finite density weights with a common stated W. Its diagonal mass is F_Gamma/(hbar Area). Positivity holds on both frequency half-lines because omega and K have the same sign; matrix cross entries are controlled by its trace. The odd third-moment estimate (26) bounds its high-frequency second moment uniformly and therefore makes these weighted measures tight. Finite-dimensional positive matrix measures admit a weakly convergent subsequence (extract scalar diagonal/real and imaginary cross integrals on a countable dense set of compact tests, then use positivity and tightness). For each fixed chosen finite set of in-plane k values the same extraction works jointly; a countable set of requested k/probes uses another diagonal subsequence, not a proved continuous-k bulk limit.

The exact equal-time zero then gives the SIGNED algebraic identity
    chi_Gamma(z)/Area=(1/(hbar z))
             int nu_Gamma(domega)/(omega-z), Im z>0,
    |chi_Gamma,ff(z)|/Area
             <=F_Gamma(f)/(hbar^2 Area |z| Im z).         (27a)
The sign follows from 1/(omega-z)+1/z=omega/[z(omega-z)]. Weak convergence of the finite positive nu measures passes their Cauchy transforms; on compact UHP sets the total-mass bound controls all derivatives, so convergence is locally uniform. This constructs an ACTUAL subsequential analytic per-area density response with its physical source/area normalization. It does not choose a unique thermodynamic response or prove it is the spatial Fourier transform of a clustering bulk state. It is based on the original actual interacting finite-volume Gibbs expectations (21), not a fitted response coefficient.

A zero-frequency atom of the LIMIT weighted nu may arise by accumulation of soft modes although every finite weighted nu has no zero atom. It must be retained in (27a). It is not the unweighted elastic atom E, and neither atom nor static chi is fixed by a positive first moment. At z approaching the real axis or zero the bound explicitly loses uniformity. No real-frequency error-controlled useful band or exchange of size/k/frequency limits follows from compact-UHP convergence. The original k-dependent state selection, total-noise/elastic limit, static Duhamel susceptibility and physical constitutive transport remain separate BUILD. If the weaker onsite-only existence domain of section6 is used without the higher weighted-moment premise, this tightness/higher-moment conclusion is NOT asserted automatically.

In particular these weighted bounds permit a narrow distribution whose weight grows near omega=0 while all positive weighted moments remain bounded. A simple positive elastic mass c_Gamma delta_0 contributes ZERO to K at every size, even if c_Gamma/Area diverges. KMS does not eliminate it. At nonzero omega a pair with detailed-balance-related weights at +/-epsilon can have increasing M mass with decreasing epsilon and still a bounded energy-weighted moment. Neither (22), (26) nor locality implies static Duhamel chi, total noise/variance per area, a finite elastic limit or the interchange k->0 and omega->0.

## 12. Current Hessian, physical boundary work and Ward identities

With actual bond line-integral flux Phi_b (Wb), keep h_b exp(iq Phi_b/hbar), I_b=-partial_Phi_b H, and the real Hessian T_bc=omega(partial_Phi_b partial_Phi_c H). Density interactions have NO such derivative for the fixed kernel, while the interacting expectation is unchanged in status. The predecessor exact graph incidence/storage identities hold in every finite box and for fixed local thermodynamic limits:
    delta Q=B I,
    -iz chi_QQ=B chi_IQ,
    -iz chi_QI=B(chi_II-T).                              (28)
Their equal-time contact/Hessian term is mandatory. Taking per-area sequences does not remove storage until its actual boundary sum is shown subextensive. A driven gate/dielectric and external displacement/receiver current add their own vertices and noise, still BUILD.

For uniform in-plane vector potential A and a direction e, Phi_b=A_e (e.ell_b), with actual physical bond displacement ell_b. The extensive current conjugate is J_e=sum_b (e.ell_b)I_b (A m), so J_e/Area is sheet-current density A/m. Its Hessian per area has units A^2/J, after the displacement/area dimensions cancel. EXACTLY,
    T_ee/Area= -q^2/(hbar^2 Area)
             sum_b,sigma (e.ell_b)^2 omega(H_bond,b).      (29)
In the chart, vertical projected displacement is zero and intralayer bulk satisfies
    |T_ee|/Area <=6q^2 gamma0* b^2/(hbar^2 Ac).           (30)
For a general finite direction/multichannel source use its actual line integrals and full matrix Hessian, not a guessed k times the terminal current. Physical contacts contribute at most2q^2 sum_a |v_a|(e.ell_a)^2/(hbar^2 Area); subextensive channel count ALONE does not suffice if their physical line-integral weights grow. The actual weighted boundary condition must be checked. Scalar potential, current response and electromotive voltage retain the signs of section9 and the predecessor. No Drude conductivity, D, tau or hydrodynamic pressure is extracted from the diamagnetic Hessian alone.

## 13. Limits, state errors, full covariance and retained retarded controls

For fixed local channels, section5's corrected weighted-tree alpha errors and the actual state restriction error eta_Gamma(Y)=||omega_Gamma|CAR(Y)-omega|CAR(Y)|| propagate to means and ordered two-time covariances. Approximate each evolved channel by a finite B with error e; a product difference is bounded by a e_B+b e_A+e_A e_B and the state term by eta(Y)||B_A||||B_B||. Centering requires additionally the actual two mean-product errors; no cross-spin or cross-channel term is omitted. Probe integration multiplies these norm bounds by the actual L1 filter products; finite-time Gaussian smearing retains its actual tail. For z in the upper half-plane, the response remainder at t>T is <=2 a b exp(-Im(z)T)/(hbar Im(z)). The finite-time part uses those same evolution/state differences. Arbitrarily long time or a real boundary value cannot be inferred by deleting this tail.

For clarity, here is a quantitative use of the repaired cuts rather than a reference to a radius that may not exist. For two original local channels A,B of norms a,b, choose the actual finite approximants B_A(t), B_B(s), with uniform errors e_A(t),e_B(s) from (14r)/(15r), or (16b) when that weaker domain is used. Let Y contain their finite supports. Define the actual local state restriction error
    eta_Gamma(Y)=||(omega_Gamma-omega)|CAR(Y)||.
A safe ordered uncentered-product error is
    E_AB(t,s)=a e_B(s)+b e_A(t)+e_A(t)e_B(s)
                +eta_Gamma(Y)(a+e_A(t))(b+e_B(s)).       (31r)
The two mean differences obey e_A+eta_Gamma(Y)(a+e_A) and the corresponding B expression. Add their mean-product telescoping bound for a centered covariance. All spin/cross-channel entries use the actual joint matrix; no independence is imposed. Positive Gram matrices hold for the true finite physical states, not for an arbitrary error-subtracted scalar fit.

For actual integrable two-time probes f,g, the bounded window contribution is <=integral |f(t)g(s)| E_AB, with the centered mean corrections when appropriate; outside-window tails use the actual L1 masses and the physical norm bound (<=4ab for a centered covariance). This is a filter error estimate, not a claim of pointwise real-frequency PSD accuracy. A causal response comparison on 0<=t<=T uses
    (1/hbar) integral_0^T exp(-eta t)
          [E_AB(t,0)+E_BA(0,t)] dt, eta=Im z>0.         (31s)
Each ONE true response's omitted time tail is <=2ab exp(-eta T)/(hbar eta); comparing two whole responses may require the sum of both tails, <=4ab exp(-eta T)/(hbar eta). Arbitrary mu, nonstationary two-time preparations, charge adjoints, actual source signs and state terms are retained. The equilibrium spectral/KMS interpretations require the actual equilibrium state, separately.

For extensive A_k=sum_x q f_x n_x, the valid error is the actual weighted sum over x,y of (31r)/(31s), followed by division by Area. One must not replace that double sum by a one-local-channel error or assume eta_Gamma(Y) decreases with area. If the sums are large the bound honestly fails to certify a useful accuracy; no sample, state, channel, k or band is discarded to make it small. The KMS/weighted-measure subsequences of sections7/11a prove existence and compact-UHP statements, not a computable phase-selection/state-error modulus, bulk compressibility or noise tightness.

For per-area EXTENSIVE channels, local errors cannot be treated as if the observable norm stayed fixed: sum their actual spatial weights and actual two-channel errors before dividing, or use the exact moment identities to control only WEIGHTED spectral tails. Matrix covariance positivity holds at every finite size. A thermodynamic unweighted matrix measure/elastic limit needs tightness/total-mass control or a demonstrated scaling theorem; none is supplied by (27) alone. All k adjoints and null/elastic directions remain. The original Duhamel positive-Hilbert projection, selfadjoint compression, exact current-force resolvent and Volterra memory/residual controls remain valid for each declared bounded finite channel in its actual equilibrium state; their C,v,F,r_eta are still state/probe functionals. No substitution of a formal bulk chi or a memory-flat useful band is made by taking a size limit.

## 14. Concrete controls and DATA UNRUN verification design

Manual nonzero controls: all ke>0/d>0 aligned entries in (6) survive; Uii>0 follows6/(5ai)>1/(2zi); the original actual contact transition with an opposite-spin central electron still gives [V,I_up] matrix element Uii |qv|/hbar. Gate cancellation in (5) persists at large planar distance, while removing the image term would produce a nonsummable1/r sheet sum. The both-spin original Hamiltonian/state family is never replaced by this control configuration.

Countercontrols: arbitrary small ai destroy uniform U0 but not the defined finite carrier; growing fixed-strength attachment rows destroy a uniform row bound, whereas infinite summably decaying degree does NOT; growing gate height prevents a common Z bound; omitted aligned sites would miss ke/d; doubling valleys would miscount (23); k=0 boundary storage need not vanish; elastic mass is independent of all K moments; no inversion symmetry identifies same-k oddness; arbitrary real mu does not give full-CAR physical-H KMS.

No controls or reference plans below were EXECUTED. A future independently authorized evaluator should:
1. Independently enumerate the actual AB coordinates for every original finite patch plus increasing complete cells and irregular boundaries, both spins and all actual contacts. Count shells/aligned pairs against (2)/(3), compare exact sphere/image coefficients with independently precision-bounded quadrature and closed (4), and check units. Include near-gate/disjoint-boundary radii, variable radii, nonzero backgrounds, nonzero complex phases, unequal layer/contact parameters and arbitrary beta/mu populations.
2. Compare exact finite-Hamiltonian commutators/current-Hessians against (21)/(22)/(28), including k and -k, generic complex channel matrices, BOTH spins' cross noise, onsite/intersite interactions, k0 storage, independent elastic and null blocks. Use independent high-precision spectral sums and finite-time commutator/contour evaluation, not a dressed bubble as reference.
3. Refine central cut, lead cut, time/filter cut and arithmetic precision INDEPENDENTLY using actual bounds (8)/(14r)/(14s)/(14t)/(15r)/(16b)/(18a)/(25); retain all original sample populations, actual nominal points and refusal/error budgets. State-subsequence or phase convergence must be measured/tested independently and is not certified by the cutoff bound.
4. Meaningful poisons must reject: image-sign flip, deleting aligned pairs, missing onsite self-image, missing spin cross channels, extra valley/area multiplier, wrong source sign, conjugate/adjoint corruption, dropping Hessian/storage, physical-H KMS at mu!=0, fake finite chi from (27), hidden infinite Gibbs trace/global w, and an asserted unique phase from subsequential existence. Report failing and passing cases separately.
5. Explicit Q1/Q2 controls: retain the actual infinite decaying-contact population v_a=v0 2^(-a) and all finite prefixes, verify its radius-one ball is infinite, compare the conservative l1 tail and exact l2 omitted-current norm(14u) without equating them, and compare first-failed-depth sums against(14r). Include finite-degree many-channel boundary families and fixed-strength divergent rows as distinct populations. Poison any claim that bounded total row alone gives a computable tail modulus or finite metric balls. Check that selected finite words really include each stage's virtual background anchors; a later-stage edge cannot be used to assert earlier support closure. Independently refine central cell closure, electrostatic/background K, actual contact tail/list, selected-channel lead depth, word order N, time steps, filters, arithmetic and actual state errors. Reject an undefined Rexternal, an identification with background-containing Rkin, and reinstating the rejected THREE-layer active boundary proof.
6. Without uniform onsite bounds, verify residual tails AND the actual finite-Y onsite-phase errors(16b)/(16c); poison deletion of those phases or promotion to uniform all-order generator moments. For responses compare both true-UHP tails when two complete responses are subtracted, all source/charge/area/adjoint signs, full complex/spin matrices and independent elastic/null directions. None of these plans are executed numerical or native evidence.
7. Before any future reversible corpus work, capture exact bytes, mode and nanosecond timestamps of every touched source/data/test/admin target with raw and semantic index/HEAD/status/refs separately; use isolated admitted ownership and restore EXACT original bytes/ns times only under the actual authorized process. This is a recipe DATA/UNRUN, not execution, source/G4/G5/G11/native/main evidence.

## 15. Actual remaining construction and full original objective

This r4 note supplies the retained image/packing constants, genuine summable local dynamics/domain, new finite weighted-tree/contact-tail error construction on the WHOLE stated summable-row domain with actual tail DATA, positive thermodynamic KMS existence and evaluated physical per-area WEIGHTED moment/Hessian/boundary bounds on their explicit actual-input domains. It does not supply the original full physical material/bulk-response target by renaming these components.

Remaining coherent substantive work: match actual radii/Wannier/exchange/dynamic dielectric/gate and contact data with quantified physical residuals; justify consistent material input bounds; select/control thermal phase and initial spectra, unweighted covariance/elastic/compressibility and momentum/area limits; derive actual low-k current-force decay and kinetic/memory coefficients with an error-small nonempty useful band; construct incoming horizon/nozzle state and the actual screened receiver/displacement/circuit/quantum measurement chain, independent microscopic routes and identifiable calibrated prediction. Neither f-sum nor high-frequency moment bounds fix chi,D,tau, physical MIR/CHHK uniqueness or a usable bandwidth. This is not infeasibility or an operator-approved deferral; the original scientific BUILD continues with a fresh independent whole-note reviewer.

Distinct polariton/BEC, one shared D1/E1/E2 dispersive-law task, all three L1 obligations, all21/B1-B8/D12, publication/native/G4/G5/G11/main/human gates remain unwaived. No actual installation, source merge or executed test is claimed.


## 16. Primary-source boundary

The historical r2 bounded primary-source cross-check was made AFTER the r2 model save and derivation; its exact unchanged personal reading is reused here, not claimed as a fresh r4 WEB visit: Nachtergaele–Sims–Young, arXiv:1810.02428v2, sections3.2/3.3, equations3.49–3.61 and theorem3.5/proof3.77–3.78, https://arxiv.org/html/1810.02428v2. It confirms the relevant distinction between onsite interaction pictures and local limits. Its general F-norm theorem is NOT invoked without checking that hypothesis on an arbitrary contact graph; the explicit CAR absolute-tree proof above supplies this note's constants and topology. No full text was saved or admitted, and no source statement supplies missing phase/transport calibration.

The r4 proof of(14r) is a new manual author derivation after the independently accepted documentary preflight. The former r3 unaccepted sketch is retained as historical input, never as sole verification or an independent proof. The whole corrected sixteen-section construction, including unchanged supported physical sections and all new domains/error uses, must receive fresh nonauthor scientific review. No model/test/mathsoftware/native/runtime was executed and no source was installed.

<!-- END SOURCE137-EXACT-E2_ORIGINAL_GATED_BILAYER_LARGE_AREA_RESPONSE-CONSTRUCTION -->

<!-- BEGIN SOURCE137-EXACT-E2_ORIGINAL_GATED_BILAYER_LARGE_AREA_RESPONSE-REPORT -->
# E2 large-area r4 — coherent manual AUTHOR repair, pending whole independent science review

The same original interacting gated AB-bilayer family now has a manual finite weighted-tree approximation and explicit omitted-contact error bound on its full stated summable-row domain, including infinitely many decaying-strength contacts. The former finite-ball recipe is retained only with its actual additional premise. The corrected external constant and four-layer carrying boundary proof are explicit. This is an AUTHOR construction, not independent acceptance, source delivery, runtime/native validation, physical device matching or completion of the original E2 prediction/readout programme.

The complete corrected CONSTRUCTION has all sixteen sections. All original nonzero bilayer/contact/interacting degrees of freedom, both physical spins, grounded-plane image/background terms, finite beta and arbitrary real mu, charged and neutral CAR, correlated/partitioned/quench preparations and original physical observables remain. Uniform theorems retain their actual input suprema; every original finite sample retains pointwise validity. No infinite-contact population, original parameter, state, channel or requested band has been deleted or made favourable.

## Q1: actual quantitative repair

Original whole-review c2f6cc39 correctly rejected the claim that bounded incident rows imply finite metric balls. In the retained v_a=v0 2^(-a) population, infinitely many nonzero channels attach to one central site and its unit-link radius-one ball is infinite, while the absolute row is |v0|. Coulomb long-edge tails alone contain none of these omitted SHORT edges.

Sections5a–5d construct finite, DEPTH-DEPENDENT incident-star lists. At each finite depth the current finite frontier gets actual electrostatic/background and hopping/contact row-tail budgets. Accepted n-step words, n<=N, are inside a finite union of endpoints, which can be closed to actual complete central cells, finite selected channel sets and finite lead prefixes. A lost word first fails one selected depth. Its omitted row is <=(s+j)tau; all remaining incident rows are <=(s+l)Jbar. Summing first failures and Taylor orders proves
    E<=||A||[(tau/Jbar) s a/(1-a)^(s+1)+Tail_(s,N)(a)],
    a=2Jbar|t|/hbar<1.                                  (14r)
This is a finite-set construction on the original summably infinite contact family. The proof never assumes the global union of selected terms is closed under every incident edge, or that later-stage selected terms can be used at an earlier depth without enlarging its allowed frontier.

The remainder is explicitly bounded by4 binomial(s+N,N+1)a^(N+1) for a<=1/2,N>=2s, using the term ratio<=3/4. Equation14t supplies a finite analytic electrostatic cutoff K from the evaluated gated tail. The actual geometric contact family has exact l1 tail |v0|2^(-m), hence an explicit finite m budget. The exact derivative control is separately derived by a CAR rotation:
    ||delta_H n_i,up-delta_cut n_i,up||
       =|v0|2^(-m)/(sqrt(3)hbar).                        (14u)
This l2 error cannot be cancelled by density interactions, and is not substituted for the conservative l1 tree budget. All other actual bilayer/contact terms remain in the compared Hamiltonians.

For arbitrary absolutely summable but otherwise unspecified rows, finite incident selections exist; a NUMERICAL certificate additionally needs the actual omitted-tail data or an analytic upper bound. A row-sum declaration alone does not give a universally effective modulus or uniform rate over all such sequences. This limitation is explicit, with no family reduction.

The optional proper-metric route is separately proved in5e. Assigned central edges have EXACT length2+rho/b, contact/lead edges length1; bounded-length neighbours are finite on the example with finite attachment degree. Since every edge length is at least1, finitely many expansion steps enclose a bounded ball. That example validates the original CONDITIONAL radius bound, not a new restriction on the full summable-contact family. The infinite-degree counterpopulation uses14r instead.

All-time bounds15r use finite time steps and the actual enlarged finite support at each step. Nested finite restrictions give sum e_j for the step product and2sum e_j for the fixed outer-box group. Central closure, electrostatic/background radius, selected contact lists and their actual tails, selected-channel lead depth, word order, time/filter cuts and actual state errors remain separate controls. The largest requested compact time is used without changing samples or hiding a nominal point.

The weaker unbounded-onsite family remains separate. Its residual incident sum and exact onsite conjugations give a finite-tree estimate16b with BOTH bad-word remainders and the actual finite-Y onsite-phase discrepancy. Unbounded remote onsite energies are not silently hidden in Jbar; no uniform higher generator moments are inferred from this weaker existence theorem. Pointwise-only phase convergence supplies qualitative existence, while quantitative use requires its finite-Y modulus. Zero residual J is treated directly without division.

Section13 now gives31r/s: actual local state-functional error, all cross-spin/complex channel product and mean errors, actual L1 probe integrals, and true-UHP finite-time response error. A comparison of two full responses retains both omitted time tails. Extensive channels require summing actual spatial pair errors BEFORE dividing by area; no local bound is relabelled as a uniform bulk error or a useful real-frequency band. State selection is not certified by the dynamics approximation.

## Q2 and whole carrying consistency

Rexternal is explicitly E*=sup|e_i^external| in joules, on central sites. Rlead* already includes actual lead onsite/hopping/contact rows. The new decorated Jbar13r separates external/self-image singleton, physical hopping, actual quartic and labelled virtual-anchor background terms. The background overcount4nu*S safely bounds real targets plus two-spin virtual-anchor incidence; no second background onsite energy is added from Rkin. The long-row tail13s retains4nu*+2|lambda| multiplying the evaluated TU(K).

The active boundary sentence now uses FOUR near layers, depths0,1,2,3, consistent with unchanged18a. The former THREE-layer provisional expression remains explicitly rejected historical analysis. Nothing promotes that failed estimate to a valid bound.

Whole-note self-audit also caught an inherited generic "growing attachment degree destroys a row bound" countercontrol. It now says growing FIXED-STRENGTH rows destroy a uniform row bound; infinite summably decaying degree does not. The sector norm now explicitly labels the bare V bound and multiplies it by |lambda| for lambda V. This is notation precision for the original real-lambda family, not a changed physical coupling. The old primary-source cross-check is honestly identified as historical r2 reading reused at the exact unchanged source, not falsely claimed to be a fresh visit after the new r4 model.

All carrying uses of the old unconditional radius recipe have been replaced by the weighted-tree estimate or explicitly qualified. The controls and DATA UNRUN recipe now include independent contact-tail refinement, the infinite-degree finite-ball poison, virtual-anchor/depth-order checks, undefined-constant/four-layer checks, actual weak-domain onsite phases and the two-response time-tail distinction. No test, reference recipe or mathematical software was executed.

## Complete retained science and domains

The corrected construction preserves the original evaluated AB packing and rigid-cloud/gate model, rather than installing a generic scalar overlap. It retains the cell area, four spatial/eight spin modes, projected triangular spacing and aligned pair, 88/b^3 bound, evaluated shell tail, actual ke image kernel, onsite self-image/background and nonzero interaction. It retains actual central/lead incident energy, Fock direct-sum selfadjoint/domain/core and all-order local generator estimates, alongside the weaker pointwise-onsite dynamics domain. No global extensive interaction norm or infinite Gibbs density is used.

It retains positive finite Gibbs states and actual thermodynamic subsequence existence, with grandcanonical tau-KMS, the charged chemical twist and ordinary physical-H KMS only for neutral observables. Gaussian analytic smearing holds its width fixed during the finite-volume limit. Neither uniqueness/clustering/selected phase nor a rate of state convergence follows. Nonequilibrium preparations remain their actual positive states, not thermal substitutions.

It retains the logarithmic electrostatic boundary-over-area bound with four exceptional layers, actual source charge/sign and spin/area/k-adjoint conventions, the microscopic interacting f-sum and contact storage, extensive higher weighted moments, actual subsequential compact-UHP per-area response and the independent low-frequency/elastic limitations. It retains actual Peierls currents, Hessian, physical displacement weights, Ward equal-time contact/storage terms and their state-dependent expectations. Countably many contacts are controlled by ACTUAL coupling sums, not count alone; growing line-integral weights need their own actual weighted sums. No static chi, unweighted noise/elastic mass, DC/real-axis convergence, bulk D/tau or physical useful band is inferred from those weighted moment bounds.

All sixteen sections are present. Static byte comparisons show sections2,3,7,9,10,11(including11a),12 are exact old-r2 text. Section4 is exact after the sole explicit bare-V/|lambda| norm precision. Section8 is exact after the sole active FOUR-layer sentence change, retaining the complete rejected attempt. Sections5/6/13 carry the substantive coherent Q1 error construction and propagation;1/14/15/16 carry honest process/scope/control/read-chronology reconciliation. These comparisons preserve the supported old science; they are not an independent verification of this author's proof.

## Actual process, immutable baseline and deviations

This is a deliberately NEW packet d5780efe after actual failed-r3 terminal. Original r4 FIRST ran exactly once16:17:30.496186–16:17:31.015333 UTC, five JSON argv entries, cwdN, rc0, fresh=true, changed=[], separate stderr empty. Exact raw receipt is first-check.json. No packet/check refresh or appended checksum argument occurred.

Immutable initial-protection.json2ef14f... was saved16:18:10.002665 UTC BEFORE the new model/mathematics. It contains the actual full baseline, including all tracked P5186/N4869/M4906, actual porcelain P0/N64/M3, ALL literal historical P7/N64/M3 paths including the missing primary infra.md, complete actual reference fullstates, raw indexes and semantic stages separately, HEAD/status/named refs, scoped administrative observations and all eight initial owned absences. Historical known coverage is not a dirtiness claim. The original baseline is never rewritten.

Immutable SOURCE_MODEL6bac52... was saved16:18:10.002875 UTC immediately afterward and BEFORE any new corrective mathematics. It contains one independent byte-exact original ce3c MODEL enclosure and one byte-exact failed419916 MODEL enclosure; the latter itself encloses ce3c once. Hence ce3c appears TWICE overall, once in each declared historical layer, not once overall. The full original family/objective was fixed prospectively.

I stopped for actual independent lead documentary preproof verification. Receipt76823456... checked217 items/zero failures and noted one UNKNOWN administrative-time event. ACK was recorded16:20:21.334058 UTC BEFORE new r4 mathematics. This is MANUAL-SCOPE PREFLIGHT ONLY, not science acceptance/source/native/runtime/main authorization or blanket quiescence. First complete construction save was16:28:24.505345 UTC after new reasoning. The original rejected r2, failed-r3 protection gap/unaccepted scratch and prior NJL preMODEL/growth definition-read-first failures remain unwaived and immutable.

The full actual r2 construction and whole c2f6cc39 review were personally reread in bounded complete scientific chunks. Full earlier interacting/terminal/growth/retarded notes and nonauthor reviews and primary/definition reads are reused only at their exact unchanged protected hashes; large raw JSON/base64 streams are parsed/compared rather than described as personally read scientific prose. Current report does not claim a new primary fulltext acquisition or holding admission.

Actual author errors during this task are retained, not refreshed away:
- A receipt-summary display accidentally included a large raw/current capture and clipped the output. No clipped prose is credited as full source reading.
- A postproof nonofficial prefinal comparison iterated a historical-matrix dictionary as though it were a path list, then raised KeyError for docs/ATLAS_HEATMAP.md before saving that intermediate capture. A following schema display attempted slicing that dictionary and failed before its planned record write. Both exact failures are retained. The immutable INITIAL baseline/model were unaffected; the lost intermediate dataset is not represented as preserved. A later fresh nonofficial prefinal capture was saved BEFORE comparison and correctly covers all historical matrix entries.
- The first static enclosure assertion expected one total occurrence of ce3c and failed because the exact failed model nests a second copy. The original false audit is retained. Corrected explicit counts show total2, nested1, outside-failed1 and failed-model1, with immutable hashes exact. This is a faulty selfcheck, not raw/model drift.
- No original FIRST or FINAL has been repeated to erase any failure. Any actual FINAL discrepancy and terminal movement will be recorded after this full report.

The corrected prefinal observation ended16:31:31.597755 UTC. All68 actual packet/reference fullstates, all P/N/M tracked and actual dirty/untracked states, raw/semantic indexes, HEAD/status/refs and all literal historical7/64/3 fullstates matched the immutable baseline. Two administrative DIRECTORY mtime/ctime changes are recorded, with other fields exact: primary gitdir and the publication checkout gitdir. Actor/cause UNKNOWN, no reset or lease/runtime inference. This is scoped source preservation, not an atomic global quiescence claim. The actual final receipt/terminal dataset will remain in the JSON evidence, not retroactively substituted for this prefinal observation.

## Disposition, next action and required evidence

Original objective: a physically matched interacting bilayer current/noise/large-area response and calibrated identifiable error-controlled nonempty prediction band. Existing finding/parent: Q1/Q2 in c2f6cc39 and publication-remediation-E2-D5-physical-bulk-interaction-state-normalization-BUILD. Accepted AUTHOR owner for this repair is publication_root7_current_review; lead retains scientific disposition responsibility. Next action is a fresh genuinely nonauthor WHOLE scientific review of this complete corrected note, model, retained science, all error domains, exact infinite-contact control and actual process, followed by lead intake. Required evidence is independent verification of the first-failed-depth construction, explicit row-tail/onsite-phase budgets, all-time/filter/state/response transport, full physical signs/units/source/area and retained countercontrols. This report does not self-accept the result.

Further physical construction remains owed: actual Wannier/radius/exchange/dynamic screening/gate/contact matching with residuals; consistent material bounds, selected phase/initial spectra and unweighted covariance/elastic/static susceptibility; low-k current-force decay and error-controlled memory/kinetic chi,D,tau; actual horizon/nozzle/incoming state and screened receiver/displacement/circuit/environment coupling; independent microscopic routes, calibration/identifiability and a nonempty usable physical band. Moment estimates and local cut error alone cannot satisfy these. No deferral/reduced scope/infeasibility or operator approval has been invented.

Distinct pumped polariton/BEC programmes, all21/B1–B8/D12, three distinct L1 obligations, the single shared D1/E1/E2 law, actual source/application/runtime/native/G4/G5/G11/main/human gates and the unanswered ADW execution question remain unchanged and unwaived. No actual source installation or runtime grant is supplied by this author package.

This full report is saved BEFORE the ONE original FINAL. Exact genuine terminal comparison, final return channels and immutable artifact hashes will be frozen in the eight assigned leaves afterward. Fresh whole review is still required.

<!-- END SOURCE137-EXACT-E2_ORIGINAL_GATED_BILAYER_LARGE_AREA_RESPONSE-REPORT -->
