# E1 thermal phonon conversion/backconversion: normalized vertex, actual energies and correlated noise

AUTHOR MANUAL CONSTRUCTION for the existing E1/D1 physical-reservoir/noise BUILD. Full independent manual scientific verification is recorded in the linked original review; physical and native acceptance remain open. This supplies an explicit source-qualified transition family, thermal second-order coefficients, an energy-resolved finite generator, conditional exact bosonic count reduction, quantitative approximation bounds and a conservative local forward/back dynamics. It does NOT identify calibrated dark states/matrix elements in the Falque device, prove a finite-coupling driven Markov/Floquet limit, compute its coupled measured spectrum or close the original detection band. Source selection/process limits are in [source/model contract](source-models/E1_THERMAL_PHONON_BACKCONVERSION.md). No software/model/native evaluation.

## 1. Source-qualified microscopic vertex and units

Fix an in-plane area A, thickness Z and volume V=AZ with periodic phonon modes Q=(q,k_z); phonon angular frequencies Omega_Q=u|Q|>0. Let rho_m be mass density and D_sigma an energy-valued deformation potential. Normalize three-dimensional excitonic mode spinors by sum_sigma integral_V |u_p,sigma|²=1 and similarly for orthonormal u_j,sigma. Write the retained excitonic field as X_sigma(x)=X_p u_p,sigma(x)a+sum_(j=1..J)u_j,sigma(x)d_j plus excluded modes, with dimensionless Hopfield amplitude X_p. a and d_j are canonical bosons; a normalized mode has a dimensionless occupation. The projected deformation-potential interaction is the Hermitian operator

H_ep=sum_Q sqrt[hbar|Q|/(2rho_m V u)] (b_Q+b_(-Q)†)
                     sum_sigma D_sigma integral_V exp(iQ.x) X_sigma†(x)X_sigma(x) dx.       (1)

Reality/inversion pairs make H_ep†=H_ep. The strain amplitude is dimensionless, so its density projection has energy units. Its OFF-DIAGONAL polariton-to-dark coefficient is

g_jQ=X_p sqrt[hbar|Q|/(2rho_m V u)]
                    sum_sigma D_sigma integral_V u_j,sigma*(x)u_p,sigma(x)exp(iQ.x)dx,
H_tr=sum_j [B_j C_j+B_j† C_j†], B_j=d_j†a,
C_j=sum_Q g_jQ(b_Q+b_(-Q)†).                                      (2)

For the displayed field convention the coefficient of B_j is g_jQ; changing a phase convention changes both it and its conjugate, never only one. These are actual energy- and particle-exchange Hamiltonian terms, not a density-noise rate relabeling. With no optical drive the total Hamiltonian is time independent, hence its total energy is conserved; Q_s=N+R commutes with H_tr exactly, N=a†a,R=sum d_j†d_j. Phonon number is not conserved. On-shell emission/absorption energies are derived below; no claim that H_ep separately commutes with the uncoupled energy is made.

The same projection also contains a†a and d_j†d_k diagonal/intrabranch terms; the accepted density-phonon note studies a different such projection. They cannot all be deleted from an actual material model. If u_j and u_p have pointwise orthogonal spin and the vertex is spin diagonal, g_jQ is IDENTICALLY zero for every Q. Nonzero conversion then requires actual spin admixture/spin-flip coupling or different allowed dark/localized states. Momentum-/localization-dark states can instead have nonzero finite-Q spatial overlaps. Falque optical darkness and Stepanov density Eq25 alone do not choose which case applies. The missing state/selection/matrix-element construction is a named physical duty, not a desired nonzero constant supplied here.

For two-dimensional normalized profiles integral_A |v_p|²=integral_A |v_j|²=1, polariton number density is |v_p(r)|²<N>; an excitonic density includes |X_p|². Dark density is sum_jk v_j* v_k<d_j†d_k>, reducing to a diagonal sum only for the stated absence of mode coherences. For an energy-area contact coefficient g_pD, a dispersive angular coefficient is chi_j=(g_pD/hbar)integral_A |v_p|²|v_j|². Equal chi_j=chi is an additional scalar-mode reduction; uniform delocalized profiles give an explicit1/A, localized profiles give their actual overlap integral. The finite-J symmetry does not replace this normalization by an assumed density-of-states number. J, X_p, g_pD, spin profiles and phonon confinement need target-device evidence.

## 2. Actual Bohr energies, free thermal bath and second-order transition coefficient

Use the accepted finite carrier Q_s<=L at fixed J, with diagonal LAB-FRAME angular Hamiltonian

K_0=omega_p N+(U/2)N(N-1)+chi NR+omega_D R.

All coefficients are real; the physical energy is hbar K_0. Only after its energies are fixed add the optical drive i hbar[F exp(-iomega_l t)a†-conj(F)exp(iomega_l t)a]. Rotating BOTH particle species by the same omega_l Q_s leaves every B_j transition energy invariant. Subtracting omega_l only from the cavity and leaving the dark reference untransformed would use a wrong bath energy.

For source |n;m_1,...,m_J>, n>=1,r=sum m_j, conversion B_j gives |n-1;...,m_j+1,...> with squared amplitude n(m_j+1). The released angular energy is

nu_nr=omega_p-omega_D+U(n-1)-chi(n-r-1).
E_initial-E_final=hbar nu_nr.                                      (3)

The conjugate pair has the SAME matrix element and opposite energy. Kerr/dispersive terms therefore alter the Bose factor; a fixed detuning or bare omega_D is not a universal transition frequency. Define nu_0=omega_p-omega_D and delta_L=(|U|+|chi|)(L-1) for L>=1. On all forward source states |nu_nr-nu_0|<=delta_L. The sufficient separated-downconversion hypothesis nu_0>delta_L makes every forward nu positive. This hypothesis is used for the simple R-block law below. General signed/degenerate transitions still have a full spectral generator, but need not retain that block reduction.

A thermal free phonon bath has <b_Q†b_Q'>=delta_QQ' n_B(Omega_Q), n_B(v)=[exp(beta hbar v)-1]^-1 for v>0. For a selected Hermitian channel V_j with C_j=V_j/sqrt(J), independently correlated and spectrally equivalent between j, define J_B(v)=sum_Q |g_Q|²delta(v-Omega_Q) and c(t)=lambda²<V_j(t)V_j(0)>/hbar². lambda is dimensionless coupling. This symmetric real-channel/orthogonal-bath reduction can be realized by appropriate bath subspaces, but is NOT implied by actual material overlaps(2). The common physical bath generally has a positive matrix spectrum, including j correlations. Equivalently decompose each C_j into Hermitian real/imaginary quadratures and use both B_j+B_j† and i(B_j-B_j†); the full positive spectral matrix must then be retained.

For the selected scalar channel, direct thermal contractions give

Gamma(v)=2pi lambda² J_B(v)[n_B(v)+1]/hbar²,
Gamma(-v)=2pi lambda² J_B(v)n_B(v)/hbar²,
Gamma(-v)=exp(-beta hbar v)Gamma(v), v>0.                           (4)

Gamma is a rate, J_B has energy²*time units. General Hermitian-channel matrix KMS is Gamma_ab(-v)=exp(-beta hbar v)Gamma_ba(v), not equality of arbitrarily chosen complex entries. The individual actual transition coefficient carries1/J under the declared symmetric reduction. In a common bath its matrix elements are products of the actual g_jQ; diagonal isotropy is a matching hypothesis, not an extra measured parameter.

For an initial number state and a free thermal bath, ordinary interaction-picture perturbation gives the second-order contribution (including lambda²) to its FORWARD transition probability at time t:

P_i→f^(2)(t)=lambda² n(m_j+1)/(J hbar²) sum_Q |g_Q|²
 [(n_B(Omega_Q)+1)|integral_0^t exp[i(Omega_Q-nu_nr)s]ds|²
       +n_B(Omega_Q)|integral_0^t exp[-i(Omega_Q+nu_nr)s]ds|²].        (5)

This is the coefficient/integrated second-order term, not an exact probability at finite coupling. For finite modes its coefficient is well-defined because Gaussian thermal moments and finite-L system operators are finite; continuum use requires the displayed correlation integrals to converge. The spectral identity |integral_0^t exp(ixs)ds|²/t→2pi delta(x), tested against regular spectral densities, produces(4). It is a distributional long-time rate extraction; it does not bound the Born, Markov, secular or driven Floquet error at a physical lambda. No pointwise delta substitution or finite-bath irreversible limit is asserted. The reverse coefficient interchanges emission/absorption using the conjugate matrix element.

At T0 and positive nu, Gamma(-nu)=0 and Gamma(nu) retains spontaneous emission. For uphill forward energy use the negative-frequency rate; it vanishes at T0, while its reverse can emit. At exactly zero energy never evaluate n_B(0). Use the LIMIT of the full spectral product if it exists: an Ohmic J_B(v)~eta v gives Gamma(0)=2pi lambda² eta k_BT/hbar³ for T>0 and0 at T0. Sub-/super-Ohmic or singular cases require their own limit/refusal. Degenerate zero-frequency operators must be grouped as a complete spectral block; a single real channel gives D[B+B†] there, generally mixing R coherences. It is not automatically D[B]+D[B†]. An additional phase-covariant two-quadrature bath can yield the latter, and must be specified if used.

## 3. A defined finite energy-resolved generator and conditional exact R-block law

For the finite K_0 spectral projectors P_E, form A_alpha(v)=sum_(E-E'=hbar v)P_E' S_alpha P_E for each Hermitian coupling S_alpha. Then [K_0,A_alpha(v)]=-v A_alpha(v). A positive thermal spectral matrix defines the finite GKSL dissipator sum_v,alpha,beta Gamma_alpha beta(v)[A_beta(v)rho A_alpha(v)†-{A_alpha(v)†A_beta(v),rho}/2]. Include the Hermitian Lamb shift K_LS=sum_v,alpha,beta s_alpha beta(v)A_alpha(v)†A_beta(v), where s(v) is the convergent principal-value transform (1/2pi)PV integral Gamma(w)/(v-w)dw or a declared renormalized value. Its finite-domain calibration/counterterm cannot be silently set to zero. This is an actual finite CPTP MODEL generator; no exact driven-interacting Davies derivation from(1) is claimed.

Under the separated-positive band, isotropic diagonal j spectrum and identical dispersive/dark energies, write P_rv for the cavity projection onto n with nu_nr=v and A_rv=a P_rv. The jumps are sqrt[Gamma(v)/J] B_j(v) and sqrt[Gamma(-v)/J] B_j(v)†, B_j(v)=d_j† a P_rv on source R=r. Add gamma0 D[a] and gamma_R sum_j D[d_j], gamma0,gamma_R>=0, and the actual truncated drive. Lamb shift is then a real function of N,R; keep it in K_r. For R-diagonal states define rho_r by partial dark trace. The exact block equation is

dot rho_r=-i[K_r,rho_r]+gamma0 D[a]rho_r+gamma_R[(r+1)rho_(r+1)-r rho_r]
 +sum_v Gamma(v){[1+(r-1)/J]A_(r-1),v rho_(r-1) A_(r-1),v†
                         -[1+r/J]{A_rv†A_rv,rho_r}/2}
 +sum_v Gamma(-v){[(r+1)/J]A_rv†rho_(r+1)A_rv
                         -[r/J]{A_(r-1),v A_(r-1),v†,rho_r}/2}.      (6)

At r0 terms requiring r-1 are ABSENT, not evaluated at negative occupations. Products are the actual maps between cavity supports n<=L-r; the raising optical drive retains its upper shell. Sum_j d_j d_j†=J+R gives forward coefficients; sum_j d_j†d_j=R gives reverse coefficients. The accepted tau_r=I_r/binomial(r+J-1,J-1) lifting is preserved by both directions using its two adjacent-sector identities, now with the same cavity spectral filters. These give a positive bosonic realization. With a nonisotropic common bath, sum_jk d_j†X d_k need not reduce to J+r and(6) need not close. If opposite-R transitions share a Bohr frequency, their common spectral jump can also generate R off-diagonal blocks; the general generator above remains, while(6) is not extrapolated.

With no optical drive or external losses, the finite Gibbs state of K_0, separately normalized within each fixed-Q_s sector, is invariant for the thermal conversion generator and its commuting Lamb shift: rho_beta A(v)=exp(beta hbar v)A(v)rho_beta and(4) cancel each conjugate transition pair. Directly, pi_f/pi_i=exp(beta hbar v) and pi_i Gamma(v)=pi_f Gamma(-v), including the same n(m_j+1). No unique thermal state across conserved Q sectors is inferred. Drive, radiative loss and dark death break this equilibrium check; their pumped steady state is not an equilibrium FDT state.

## 4. Constant local forward/back model, exact amplitude and number noise

Define the separate local approximation by replacing ALL filtered forward transitions with B_j and their conjugates:

L_j+=sqrt(gamma_+/J)a d_j†, L_j-=sqrt(gamma_-/J)a†d_j,
gamma_+=Gamma(nu_0), gamma_-=Gamma(-nu_0),                         (7)

for nu_0>0. This is a definite finite CPTP model, but flat rates alone do not equate it with the secular generator. Its exact R-block law is(6) with every A_rv replaced by a and the frequency sums replaced by gamma_±. Thus backward arrival is gamma_-(r+1)a†rho_(r+1)a/J and backward loss is-gamma_- r{N+1,rho_r}/(2J). On the common count space, its forward jump is sqrt(gamma_+)a S sqrt(1+R/J) and reverse jump sqrt(gamma_-/J)a†b, b|r>=sqrt(r)|r-1>. Both preserve Q_s. This identifies the correct ordering and stimulation rather than treating reverse events as coherent drive.

Put alpha=<a>, lambda_+=gamma_+[<N>+<NR>/J], lambda_-=gamma_-[<R>+<NR>]/J. Exact first moments are

<N>'=-gamma0<N>-lambda_++lambda_-+F exp(-iomega_l t)<a†>+conj(F)exp(iomega_l t)<a>,
<R>'=lambda_+-lambda_--gamma_R<R>.                                 (8)

At infinite ladders, or on the controlled finite-particle/moment passage,

alpha'=-(iomega_p+gamma0/2+gamma_+/2)alpha-iU<a(N-1)>
       -[i chi+(gamma_+-gamma_-)/(2J)]<aR>
       +F exp(-iomega_l t)+i<[K_LS,a]>.                            (9)

Use the corresponding rotating frequencies/drive only after the simultaneous-Q frame transformation. The forward dissipator contributes-gamma_+ a(1+R/J)/2, reverse contributes+gamma_- aR/(2J), and dark death contributes0. There is no additive coherent term proportional to<R> from spontaneous incoherent backconversion. For finite Q_s<=L, replace the drive term in(9) by F exp(-iomega_l t)[1-<(N+1)P_(Q_s=L)>]; all other displayed local terms retain their actual compressed-domain meaning. Number drift uses the actual compressed a and has no such replacement. For the spectral generator the exact amplitude term is sum_jv {Gamma(v)[B_j(v)†,a]B_j(v)+Gamma(v)B_j(v)†[a,B_j(v)]+Gamma(-v)[B_j(v),a]B_j(v)†+Gamma(-v)B_j(v)[a,B_j(v)†]}/(2J), plus Hamiltonian/loss terms. Its filters cannot in general be removed to give(9).

For either the spectral or local model under the stated R-block hypotheses, let lambda_± be the ACTUAL sums of jump intensities. The Lindblad product identity yields

D_NN=gamma0<N>+lambda_++lambda_-,
D_RR=gamma_R<R>+lambda_++lambda_-,
D_NR=D_RN=-(lambda_++lambda_-).                                    (10)

Both directions have the SAME anticorrelated outer product[[1,-1],[-1,1]]. At stationary R balance, gamma_R<R>=lambda_+-lambda_- and D_RR=2lambda_+, while D_NR=-(lambda_++lambda_-). With no death and thermal detailed balance, equal nonzero forward/reverse fluxes still give NONZERO conversion noise. Cancelling net drift is never cancellation of stochastic scattering. These are local observable quantum covariances, not literal fixed jumps of conditioned number means or a measured white PSD.

## 5. Precisely when the source stimulated terms cancel

For the local symmetric family, the net count conversion is

lambda_+-lambda_-=gamma_+<N>-(gamma_-/J)<R>
                         +[(gamma_+-gamma_-)/J]<NR>.              (11)

For ALL states the stimulated NR coefficient vanishes iff gamma_+=gamma_- (or the conversion is absent); for a particular state NR0 can make its expectation vanish accidentally. Equal channel-pair matrix elements alone do not imply equal thermal FORWARD and REVERSE rates: for a positive gap, KMS gives gamma_-/gamma_+=exp(-beta hbar nu_0) whenever gamma_+>0. At finite positive beta and gap and nonzero spectral weight equality is false. At T0 gamma_-=0, so forward bosonic stimulation certainly remains.

Stepanov Note1's density-of-states relation gamma_bk=gamma_in rho_pol/rho_R corresponds in THIS finite family to gamma_bk=gamma_-/J, gamma_in=gamma_+, with J interpreted as a specified ratio of participating mode counts only after the density/energy/mode windows are matched. Its cancellation is exact under equal pair coefficients in that kinetic reduction; it is not a proof that a finite-gap quantum thermal bath satisfies equality. A weak-pump neglect of NR is a DIFFERENT sufficient approximation. High THERMAL PHONON occupation gives an additional controlled approximate cancellation: set kappa=2pi lambda²J_B(nu_0)/hbar². Then gamma_+-gamma_-=kappa, and the uncancelled stimulated drift is kappa<NR>/J. Its fraction of the forward stimulated coefficient is1-exp(-beta hbar nu_0)<=beta hbar nu_0; relative to the summed conversion-noise coefficient it is tanh(beta hbar nu_0/2)<=beta hbar nu_0/2. No relative comparison is made at zero coupling/zero denominator.

Coherent-source reduction has the exact remainder

<R>'=gamma_+|alpha|²-(gamma_R+gamma_-/J)<R>
                +gamma_+ n_inc+[(gamma_+-gamma_-)/J]<NR>,
n_inc=<N>-|alpha|²>=0.                                            (12)

It is not fixed by an incident coherent pump. Higher Kerr/cavity-dark covariances remain in(9). At the same actual state, |stimulated remainder|<=|gamma_+-gamma_-|<Q_s²>/(4J); lambda_-<=gamma_- [<Q_s²>/4+<Q_s>]/J. Absolute bounds remain valid at zero reference rate. A relative error needs an independently supported positive reference. Dispersive/density calibration and all noise channels remain separate from these kinetic statements.

## 6. Quantified finite-band/locality error: secular loss cannot be hidden

On the finite carrier decompose B_j=sum_v B_j(v). The strictly secular dissipator contains sum_v Gamma(v)D[B_j(v)]/J, whereas gamma_+D[B_j]/J contains v!=w cross terms even if Gamma is perfectly flat. Therefore flat spectrum/occupation ALONE is insufficient to approximate a resolved interacting Davies model by(7); infinitesimally split frequencies and an infinite secular time need not have a uniform local limit. An exact computable operator bound is obtained from the coefficient matrices: for C_spec and C_loc on the finite list S_jmu=B_j(v),B_j(v)†,

||G_spec-G_loc||_(1→1)<=2sum_(j,mu,nu)|C_spec-C_loc|_(jmu,jnu)
                                      ||S_jmu||||S_jnu||+2||delta K_LS||.                 (13)

This is the expansion of each cross dissipator A rho B†-{B†A,rho}/2, whose norm is<=2||A||||B||. A common Hamiltonian cancels; an omitted/different Lamb shift contributes the displayed actual norm. CPTP Duhamel gives the same bound times t on a common initial density. The bound is explicit and need not be small. In the noninteracting U=chi0 single-gap case B_j has only one forward frequency and its conjugate, so the secular/local dissipators agree exactly. For interacting multiple gaps no artificial smallness is asserted.

There IS a nontrivial finite-time coarse-graining route, with an explicit error domain. Assume c integrable, C1=integral_R|c(v)|dv<infinity and define the positive Gram coefficients

G_tau(v,w)=tau^-1 integral_0^tau ds integral_0^tau du
                                      exp(ivs-iwu)c(s-u).           (14)

They define a finite CP dissipator including both bands (and the same stated Hamiltonian for comparison). Put m_tau=integral_|v|>tau |c(v)|dv+tau^-1 integral_|v|<=tau |v||c(v)|dv. For forward gaps in[nu_0-delta_L,nu_0+delta_L] with nu_0>delta_L,

|G_tau(v,w)-Gamma(nu_0)|<=2delta_L tau C1+m_tau

within the forward band, and the same with Gamma(-nu_0) in the reverse band. Proof: phase variation relative to exp[i nu_0(s-u)] is bounded by(|v-nu_0|s+|w-nu_0|u); and G_tau(nu_0,nu_0)=integral_-tau^tau(1-|z|/tau)exp(i nu_0 z)c(z)dz differs from Gamma by at most m_tau. Cross bands obey |G_tau(v,w)|<=C1/[tau(nu_0-delta_L)]: integrate the center-time phase first, bounded by2/|v-w|, then use |v-w|>=2(nu_0-delta_L).

Let M be the number of distinct forward gaps, b_L=(L+1)/2>=||B_j(v)||, and e_tau the maximum of these within-band and cross-band errors. With diagonal j spectra scaled1/J, summing cross-dissipator norms yields

||G_tau-G_local||_(1→1)<=8M² b_L² e_tau+2||delta K_LS||.             (15)

Thus a short bath-correlation scale, a window tau long relative to1/(nu_0-delta_L), but short relative to1/delta_L, plus flat thermal weights, can control a LOCAL model without declaring an interacting infinite-time secular generator local. This is a comparison between defined finite CP models, not yet a microscopic Born/Markov theorem. Degenerate zero gap and thresholds do not meet this domain.

The scalar thermal variation itself can be bounded: if kappa(v)=2pi lambda²J_B(v)/hbar² is Lipschitz with constant K1 on the positive band, bounded by kappa_max, and n_max=n_B(nu_0-delta_L), then for T>0

sup|Gamma(v)-gamma_+|<=delta_L[K1(n_max+1)+kappa_max beta hbar n_max(n_max+1)],
sup|Gamma(-v)-gamma_-|<=delta_L[K1 n_max+kappa_max beta hbar n_max(n_max+1)].

These follow from |n_B'|=beta hbar n_B(n_B+1). They are rate variation controls, not a substitute for the cross-frequency bound. At T0 on a positive band use n_B0 directly; no beta*0 product is evaluated by a limiting numerical convention.

Driving is another issue. On the finite carrier let B_drv=sup||K_drive(t)||<=2|F|sqrt(L). Duhamel gives ||S_driven(s)-S_0(s)||<=2s B_drv||S|| on a window[0,tau]. The same Gram-integral cross-dissipator estimate bounds the induced dissipator change by8tau B_drv C1 times the mean sum_j ||B_j+B_j†||²/J, hence<=32tau B_drv C1 b_L². Add any actual Lamb-shift change. This finite-window bound can be large and does not prove a global Floquet/weak-coupling reduction or a stationary driven bath law. Actual coupling, bath-memory, counterrotating/source-spin, nonstationary drive and higher-order reduced-dynamics errors still need construction before a physical validity band is accepted.

## 7. Reverse jumps preserve the strong local dynamics proof; finite-J and omission bounds

For constant finite gamma_±>=0, gamma0>0,gamma_R>0 and the diagonal K plus bounded-amplitude drive, both forward and reverse local jumps commute with Q_s. Here any retained diagonal K_LS must be one fixed real function, finite on each finite-Q shell and consistently restricted across cutoffs; if only a finite-L bath shift is known, its infinite extension is an additional stipulated model choice, not a physical derivation. They contribute EXACTLY zero to the adjoint action on exp(sQ_s); K_0 and diagonal K_LS also commute. Losses lower Q_s, and ONLY the drive crosses the upper shell. Therefore every accepted finite-Q Lyapunov/boundary hypothesis survives backconversion. With delta=min(gamma0,gamma_R), z=exp(s), c_s=(z-1)|F|²/delta,

Tr rho_t exp(sQ_s)<=M0(s)exp(c_s t),
M_stationary(s)<=exp[(4|F|²/delta²)(exp(s)-1)].                       (16)

The upper-shell discrepancy remains2|F|sqrt[(L+1)p_(Q_s=L)]. Exactly the accepted dense cutoff/CPTP contraction argument constructs a strongly continuous conservative local forward/back semigroup at fixed J and normal strongly invariant selected states with these tails. No domain-core equality, extension/stationary uniqueness, mixing or unbounded stochastic dilation is asserted. A time-dependent drive has the same moment/tail estimate using its amplitude bound, but no time-homogeneous stationary semigroup is then claimed; a rotating-Q frame restores a constant drive with consistently shifted energies. A fully energy-resolved infinite family requires its own consistent spectral/degenerate-block and Lamb-shift domain verification; the conditional finite-L R-law is not silently extended through gaps changing sign as L grows.

The common-register reverse jump satisfies A_-†A_-=(gamma_-/J)(N+1)R. On Q_s<=L, (N+1)R<=(L+1)²/4, so removing reverse conversion from the SAME finite model gives

||T_thermal,L(t)rho-T_forward,L(t)rho||_1<=gamma_- t(L+1)²/(2J).     (17)

The CP gain map has norm||sum L_-†L_-|| and its anticommutator has no larger norm; their sum gives factor2. This also holds for the physical J-mode finite model, not just register vectors. At gamma_-0 they agree exactly. Separately the accepted forward stimulation-to-isometry error is2gamma_+tL²/J. Adding these and BOTH cutoff errors yields on the SAME coarse register space, for rho0 supported Q_s<=M<=L,

||T_thermal,J(t)rho0-T_counter(t)rho0||_1
 <=4|F|t sqrt[(L+1)M0(s)]exp[(c_s t-sL)/2]
                 +2gamma_+tL²/J+gamma_-t(L+1)²/(2J).               (18)

Counter uses the SAME gamma_+, Hamiltonian and losses. If a nonpolynomial diagonal Lamb shift is retained, the counter here is its explicitly stipulated extension of the earlier polynomial model; the same Q-conservation, shell consistency and boundary proof just checked must be used, rather than calling it the identical earlier Hamiltonian. This comparison is not convergence between different unembedded physical Fock spaces, not a relative rate or uniform stationary-state error. Choose L and then J for an actual finite-time absolute budget. Under (16), the stimulated law error at the SAME stationary state obeys |gamma_+-gamma_-|exp[R_*(exp(s)-1)]/(2Js²), R_*=4|F|²/delta²; reverse intensity is bounded by gamma_- M_stationary(s)[1/(2s²)+1/s]/J. No derivative of a moment majorant is taken.

Zero coupling makes both conversions vanish. F0 and positive external losses give joint vacuum for this local family; the new thermal bath only exchanges an existing system particle and cannot create Q_s from vacuum. T0 removes uphill backconversion for the selected positive gap but not forward stimulation. In the finite equilibrium no-loss control both fluxes can be nonzero and exactly balance while noise persists. These are distinct controls, not a claim the pumped actual device is at equilibrium.

## 8. Full original physical repair and next substantive action

This derives the missing thermal reverse channel, the precise stimulated cancellation condition, correlated local noise, explicit lab-energy/mode normalization and finite-domain local/dilute/omission error routes for ONE selected carrier family. It does not derive the actual target's dark spin/localization wavefunctions/transition matrix, effective J or spectral isotropy, absolute strain/material overlaps/temperature, nonradiative loss and energy calibration. The new off-diagonal vertex is a physical construction target with explicit selection-rule countercase, not a measured consequence of Stepanov's diagonal density phonon term.

Next perform the material exciton-state/spin/phonon overlap calculation for the specified Falque geometry and all optically allowed/dark branches, determine the positive or signed Bohr band and full spectral matrix, then bound real bath-memory/weak-coupling/Floquet/Lamb-shift/backreaction and nonlinear/spatial-mode projection errors. Calibrate rates, mode/area densities, observation time and closure moments; carry all phonon/radiative/dark/pump channels and their cross-transfer through the actual horizon, polarization/aperture and detector/background. Compute the coupled spectrum and an identifiable nonempty error-controlled spontaneous/stimulated detection band. These are owed BUILDs under the unchanged E1/D1 charter, not deferred, proven impossible or replaced by a clamped Lorentzian. Fresh complete independent scientific review comes next; ROOT owns native/runtime/integration and canonical closure. No G4/G5/G11/bundle/main/human acceptance follows.

Complete original independent manual verification: [full review](reviews/E1_THERMAL_PHONON_BACKCONVERSION.md). Source selection and process scope: [original source/model contract](source-models/E1_THERMAL_PHONON_BACKCONVERSION.md). This records scoped mathematics, not native, physical, main or publication closure.
