# Complete original independent review — documentary delivery

The full original independent report follows. Administrative filesystem locators, where present, are replaced by precise public-safe Gitdir descriptions; no mathematical, verdict, source/process or preservation statement is shortened. The immutable original and exact inverse binding are retained in the source-composition evidence. This copy adds no new scientific/runtime/device acceptance.

<!-- BEGIN FULL ORIGINAL REVIEW -->

# Independent full scientific review — physical AB terminal Landauer/Keldysh construction

Verdict: **ACCEPT at the complete specified noninteracting microscopic-model/manual-science boundary. No mandatory mathematical defect found.** This is a genuinely nonauthor review of CONSTRUCTION.md SHA256 `e0a7713e66f3dbeef6acd0c02700bfe1ffa184ae232b958a3054cbc2911b55ed`, not execution, native validation, actual source application, full target-physics acceptance or publication closure. Lead intake remains separate.

I independently checked all twelve sections, all 37 numbered equations, and the intervening spectral, scattering, state, contour, response, control and error arguments. The equation count is a documentary inventory, not verification evidence in itself. I authored the separate collision construction and earlier eighteen-group Onsager construction; I authored none of this new terminal construction. My prior independent review of the microscopic seventeen-group ancestor and the independent eighteen-group review are immutable historical evidence at the exact packet hashes, not renewed self-acceptance. This review does not review or accept my collision work.

## 1. Carrier, current, gauge and work

The finite physical AB orbital graph plus finitely many bounded half-chain Jacobi operators defines a bounded selfadjoint one-particle Hamiltonian. Its CAR evolution and positive-contraction covariance make sense without an infinite many-body trace or finite whole-lead number. Finite-rank current bilinears are bounded local observables. Independent spin copies contribute two once; the actual lattice already includes valleys, and terminal current has no sheet-area factor.

For z=h_ij c_i†c_j, [H,n_i]=-z+z†, so q n_dot_i=-(iq/hbar)(z-z†). This verifies the outward convention in (3), the inward contact vertex (4), and sum I_a=Q_dot_C. Differentiating the Peierls coefficient gives partial_a H=-I; the scalar-potential commutator supplies I(phi_i-phi_j), establishing the stated local work identity. The infinite case is correctly restricted to relative/local balance plus energy flux, not an extensive kinetic-energy expectation.

I specifically checked the apparently delicate gauge convention. The +iq chi phase on annihilators gives c_i†c_j the factor exp[iq(chi_j-chi_i)/hbar]; the transformed Peierls coefficient has its inverse. In the time-dependent annihilator equation the extra term is -q chi_dot, agreeing with phi'=phi-chi_dot. There is no gauge-sign defect. Enlarging Q to contain every first lead site preserves the original measured cut and its Hessian; it does not replace the observable with the tail cut.

The product state is at the declared Q/tail partition. A thermal whole original chain is correlated across that artificial cut after enlargement. The note explicitly distinguishes these quenches and retains general initial cross blocks in section 8; no silent product-state equivalence is used.

## 2. Surface spectrum, energy/flux normalization and embedding

The sine transform has delta-k normalization; division by sqrt(dE/dk)=sqrt(2t sin k) gives the stated phi_E. Its first-site weight is sin k/(pi t), and either traveling component has particle flux 1/(2pi hbar). Thus the energy-normalized rather than unit-flux convention is consistent everywhere.

The continued-fraction equation t²g²-(z-epsilon)g+1=0 has the decaying root selected by 1/z asymptotics. Its square root must be continued from the upper half-plane with sqrt~z-epsilon; independent real signs would fail on the lower exterior band. On the band g=-e^{ik}/t, giving Gamma=2 sin k vv†/t and W W†=Gamma. The thermal lesser and greater source signs are +if Gamma and -i(1-f)Gamma. Closed bands retain their real embedding, while zero-velocity edges require limits. Units are G energy^-1, Gamma energy, W energy^1/2 and phi_E energy^-1/2.

## 3. Actual scattering solutions and unitarity

Solving the lead recurrence gives g_n1=-e^{ikn}/t. Adding that outgoing response to the incoming sine wave gives the phase convention in (9), including disconnected S=1. The central amplitude is Gv phi_E(1)=G W/sqrt(2pi). Algebra then gives S=1-iW†G W. The resolvent difference is -i G^r Gamma G^a, with the reversed factorization also valid. In S†S the linear resolvent difference cancels the quadratic W terms; the same calculation gives SS†. This proves the open-channel flux identity, not a cross-energy identity.

The partial density A_a=G^r Gamma_a G^a is 2pi u_a u_a†. Squaring off-diagonal channel amplitudes gives the stated Caroli trace with output/input indices in their stated order. Moving to enlarged Q changes the incoming reference phase but not the actual cut vertex, probabilities, local spectral density or subsequent observable.

## 4. Exhaustion, bound states, thresholds and nonvacuous AB regime

For this finite graph/finite-channel lead class, compressed resolvents are finite algebraic matrix functions of finitely many square roots. Away from their finitely many thresholds and pole/exceptional energies they have smooth boundary densities. Their asymptotics exclude an identically vanishing determinant. Stone inversion gives only ordinary continuous densities on those intervals and isolated atoms at the exceptions; a continuous singular measure cannot be supported on a finite set. Lead recurrence extends this finite-coordinate conclusion to the dense coordinate span. This justifies the absence of a hidden singular-continuous sector in this specified model class, rather than asserting it for arbitrary reservoirs.

An exterior bound eigenvector has tail (E-h_tail)^-1 V†u. Since Sigma'(E)=-V(E-h_tail)^-2V†, its full norm is u†(1-Sigma')u; this verifies the residue normalization and its sign. Orthonormal full bound states, including degenerate/compact dark cases, compress to the added w_s w_s† in (12). Threshold exceptions and embedded atoms must be retained. The incoming Cook argument is valid on smooth energy packets avoiding the finite exceptional set: their contact amplitudes are integrable in time by repeated integration by parts. Its stationary solutions produce the same local jump; the density identity exhausts the AC sector.

The four-orbital A1-B1-A2-B2 path is a genuine finite AB subgraph. Its row-sum bound gives ||h_C||<=gamma0+gamma1. With end couplings t and t>gamma0+gamma1, the exterior inverse denominator is positive above 2t and negative below -2t, strictly also at the edges. An interior eigenstate would have zero l2 lead tails, hence zero endpoints, and the three nonzero path hoppings force every component to vanish. The off-diagonal cofactor is the nonzero hopping product, so transmission is strictly positive throughout the open band. These statements establish a real nonempty mathematical conducting regime, not calibrated contact parameters.

There is no edge pole in that strict regime. Near an edge k=0 the normalized local wave amplitudes are O(sqrt(k)); multiplying their density by dE=O(k)dk yields an O(k²) endpoint integrand. Quadratic stationary phase gives |time|^-3/2, while the interior can be integrated by parts. The same holds at pi-k and for every fixed local coordinate. In particular U_QQ is L1, the actual hypothesis later used for the source limit. The tuned transparent uniform-chain control is a separate control and is not silently placed under this stricter edge estimate.

The opposite narrow-band dimer control also works: a central trial vector has Rayleigh value gamma1>2t, while the essential lead spectrum ends at 2t. The finite-rank perturbation therefore has a genuine discrete exterior eigenvalue. Nonzero contacts alone cannot justify unique NESS. Stationary bound occupations and nonstationary quench coherences in the note are correctly different objects.

## 5. Two-energy cut current, DC, heat and storage

The two factors of 1/sqrt(2pi) in u give M=(1/2pi)W†G^a j G^r W'; multiplying by h/q gives precisely the hbar/q factor in B (13). Hermitian reversal exchanges both energy and incoming labels. At equal energy lead continuity lets one evaluate the same cut in its incoming/outgoing waves; polarization gives the full matrix P_a-S†P_aS. This does not justify inserting two unequal-energy S matrices as the actual finite-band cut vertex.

The incoming diagonal expectation gives (16), with q=-e making the left charge current negative for larger left chemical potential. mu=qV restores positive electrical conductance. Row unitarity and two-terminal block trace identities give equal total left/right transmissions. The energy current factor E/q, reservoir heat J_E-mu I/q and maintained source work sum mu I/q have consistent units and signs; no inelastic heat is created inside the elastic graph by assertion.

The one-particle commutator j_sum=(iq/hbar)[h,P_C] gives i q(E-E')<u_E,P_C u_E'>/hbar, exactly (17). At E'=E+hbar omega this is -i omega times the stored-charge matrix. First-site storage must also accompany moving the reference cut. Stationary bound currents through a separating half-chain cut vanish by its bounded one-particle tail projection and eigen-equations, including degenerate polarization; this does not remove their finite-frequency transition noise.

## 6. Ordered, cross and bound-sector noise

The connected CAR contraction is f_c(1-f_d), with the occupied contraction subtracted from the anticommutator. Fourier integration of exp[i(E-E')t/hbar] contributes h delta(E'-E-hbar omega). This fixes (19)'s q²/h and its absorption convention. For a port coefficient vector the product of Hermitian-reversed vertices is an absolute square; the greater spectral matrix is Hermitian PSD. The lesser matrix is the transpose at negative frequency, and the symmetrized matrix remains PSD; complex cross entries need not themselves be positive.

The charge-storage identity propagates into the single and double terminal sums with -i omega and omega². A false two-energy unitarity cancellation is not used. Formula (20)'s 2pi delta(omega-DeltaE/hbar) reduces to h delta(E'-E-hbar omega) in the continuum; its mixed and discrete terms therefore have consistent normalization. A stationary R_b is diagonalizable jointly with h within degenerate eigenspaces. Noncommuting bound coherences require the retained finite-time representation and cannot be reported as an ordinary stationary PSD.

## 7. Thermal, partition, disconnect, transparent and unit controls

Block projection algebra yields thermal tau[f_L(1-f_L)+f_R(1-f_R)] plus tau(1-tau)(f_L-f_R)², so (21) follows from the same exact equal-energy current. In equilibrium f(1-f)=kBT(-f') gives the two-sided 2kBTG. At zero temperature only the bias window and partition factor remain. The tuned actual uniform AB/lead path has unit transmission by its recurrence; it still has finite-temperature and finite-frequency noise. Setting a true contact hopping to zero makes its actual vertex zero, removing all corresponding mean/cross spectra even if isolated central bound memory remains. Excluding E=0 from both lead bands removes zero-energy incoming transmission, not all possible bound transitions. No edge flux is created by division by zero velocity.

M has units A/J and B is dimensionless. q²dE/h is A²s; the variance measure is d omega/(2pi). Therefore S_Hz(f)=S_angular(2pi f), with no extra 2pi value factor. Folding a real auto quadrature once gives the one-sided 4kBTG. Positive greater frequency is absorption; zero-temperature equilibrium emission vanishes at negative frequency. No Bose/Planck Hawking excess, area or additional valley multiplier follows.

## 8. Independent initial-value lead elimination

Direct variation of constants in the tail equation gives (22), including the -i/hbar causal memory term and actual free tail source. With the note's dt/hbar transform, the time-domain -i theta U retarded propagator transforms to (E-h+i0)^-1; the energy-square time self-energy transforms to an energy self-energy. Lesser and greater source covariances reproduce (7) independently of S.

Inserting the exact x solution into its covariance gives the homogeneous U_QQ R_Q U_QQ† term plus the double causal source convolution (23). The four-block general covariance explicitly restores both Q-tail cross terms and a nonthermal-tail replacement. Langreth multiplication and the Dyson iteration retain the initial lesser term, rather than deleting a free on-shell delta by formal inversion.

For the strict AB regime, U_QQ tends to zero and is L1. The retarded source-mode integral converges uniformly to G^r(E) times its actual coupling; the half-chain spectral measure has finite weight and 0<=f<=1. Dominated convergence therefore produces (24) at fixed time difference as t0 tends to minus infinity. This proves the required stationary limit for the declared product preparation. General bound contacts instead retain nondecaying preparation information; the note does not promote (24) to a universal finite-band solution. Time-dependent hopping requires two-time convolution, as stated.

## 9. Independent contour bubble and constructive equality

A Peierls insertion internal to Q differentiates the same actual current. Connected Gaussian differentiation has the closed-loop Wick contraction Tr[j_a G^> j_b G^<]; the -i and +i definitions multiply to +1. The current Hessian belongs in response, not in the covariance of the undifferentiated measured currents. The mean -i Tr[jG^<] is also consistent.

Two inverse energy transforms and one ordinary time Fourier integral give hbar/(2pi) in (26). Substituting the independently obtained source partial densities (27) gives a factor (2pi)² and then h M^a M^b; M=qB/h leaves exactly q²/h (19). This is explicit finite-frequency same-carrier agreement, including the cross vertices, not naming two formalisms equivalent. Adding actual normalized bound spectral components and occupations recovers (20); nonstationary comparisons must use the same full initial covariance before Fourier transformation.

In the DC identity (28), Sigma_a^<G^>-Sigma_a^>G^< leaves f_a-f_b and the Caroli trace; q/hbar times dE/(2pi) is q dE/h. That steady identity does not replace the two-energy finite-frequency vertex. Moving first lead sites between partitions preserves the DC result and requires their stored charge for AC.

## 10. KMS, contact response, Ward identities and Landauer limit

At a common beta,mu the complete bound-free spectral covariance is f(h). With bound states the same claim additionally requires n_s=f(E_s). Number-conserving current transitions have no net chemical-potential factor. Interchanging their energies yields the detailed-balance factor exp(-beta hbar omega) and hence (29) with the stated zero-frequency/measure interpretation.

I independently checked the response sign: the perturbation is -I Phi, so Duhamel gives +(i/hbar)theta<[I(t),I(0)]>. Differentiating the measured current itself supplies -T Phi. V=-Phi_dot has Fourier factor i z Phi under the convention used here, giving Y=(chi-T)/(iz). The Hessian expectation is Hermitian in the port indices. Splitting the retarded commutator into positive/negative times gives the matrix anti-Hermitian part (S^>-S^<)/(2hbar), not an entrywise imaginary part. Thus the Hermitian dissipative admittance is that difference/(2hbar omega), and the equilibrium coth relation has exactly the coefficient in (31). All signs and dimensions agree with positive dissipated power.

At low frequency smooth positive-temperature bound-free dominated convergence is sufficient. Tr[(P-S†PS)²]=2(m-Tr S_aa†S_aa) yields the Landauer auto conductance from FDT; no unexplained Johnson prefactor is imposed. Threshold/T=0 orders are properly restricted. Differentiating finite-region continuity under the same source, including Hessian/scalar derivatives, gives the storage Ward identity. Finite segments retain an outer cut; infinite-region phase CAR automorphisms do not turn an extensive number into a bounded Kubo observable. These are bare physical bond ports, not a screened gate/displacement/receiver construction.

## 11. Every stated bound and its domain

Finite-rank Wick traces with contractions R,1-R and unitary evolution give |mean|<=g_s||j||_1 and |C_ab|<=g_s||j_a||_2||j_b||_2. Consequently an L1 real probe is bounded; its covariance is the Fourier quadratic form with w_hat_a(-omega)w_hat_b(omega). Telescoping the two windows proves (33). Auto spectral tails are actual positive omitted integrals; compact Hamiltonian transition support does not establish a usable smaller detection band.

I specifically checked the covariance ordering in (34). Starting from Tr[R U†j_a U(1-R)j_b] and using cyclicity plus [R,U]=0 gives exactly Tr[j_a U(1-R)j_b R U†]. It is not reversed occupation. Telescoping currents contributes deltaJ_a J_b+Jtilde_a deltaJ_b; the two state contractions contribute 2epsilon_R and the two propagators contribute 2|time|epsilon_h/hbar. This proves every coefficient of (34). The filtered bound requires the first difference-time moment, and the trace-norm mean estimate is also correct. Small Hamiltonian error alone does not control a changed stationary bound occupation, as explicitly warned.

The diagonal chain perturbation norm is bounded by max_a(|deltaepsilon|+2|deltat|); the Hermitian off-diagonal perturbation has norm ||deltaV||, giving (35). Fermi derivatives are beta f(1-f) and -(E-mu)f(1-f); the 1/4 constants hold along the stated interpolation, not uniformly at T=0. The full resolvent identity gives epsilon_h/eta² for eta>0. A positive embedding anti-Hermitian part yields ||G||<=2/gamma, while rank-two AB generally needs the separate compact minimum-singular-value option. The strict AB closed-band denominator is indeed nonsingular. No eta->0 or resonance/edge estimate is invented.

For finite leads on the same Hilbert space, no path of fewer than d steps reaches the changed bond. Subtracting the exponential series leaves 2 sum_{n>=d}x^n/n!<=2e^x x^d/d!, proving (37). The time horizon and current support are fixed before the length limit. Each local occupied/empty two-time propagator has two row-evolution errors, at most 2epsilon_U; their Wick product gives 4g_sJ_aJ_b epsilon_U, and the mean gives 2g_sL_a epsilon_U. Using the same compressed infinite initial state is essential. An independently prepared finite Gibbs state needs its own state error. Comparing a Wannier carrier with its block-diagonal complement has off-diagonal operator error ||K||, but physical current/preparation residuals must also be supplied. No source/software convergence or measured residual has been fabricated.

## 12. Sources, historical process and surviving obligations

Personally depth-read the official parsed primary passages of [Blanter–Buttiker v2](https://arxiv.org/pdf/cond-mat/9910158v2), pp10–13/current31 versus32, noise49–52/footnote4, and pp40–41/AC-storage caution. Their velocity reduction has assumptions and their PSD convention differs by two; the current note derives its own exact finite-band vertex and standard two-sided convention. This supports its caution, not physical screening or Hawking-state acceptance. This paragraph is a bounded source comparison, not a whole99-page/pixel read.

Personally depth-read [Jauho–Wingreen–Meir v1](https://arxiv.org/pdf/cond-mat/9404027v1), current/contour equations6–15, continuity/time-average discussion, AppendixA1–A5 and AppendixB1–B7. Their initial lesser term and noninteracting-lead requirement are retained here. Distinguish the arXiv April1994 identifier from the generated title-page August2013 date. No whole42-page/pixel reading, downloaded fulltext, holding admission or interacting target equivalence is claimed. The web tool references and selected ranges are preserved in evidence.

The frozen author first check is genuinely once at09:32:02 rc0, model save09:35:51 precedes that author's new derivation, and prior lead provisional planning remains an explicit earlier exception. Initial tracked-only dirty51N/2M and the later complete64N/3M capture before model are not conflated. The author final at09:52:15 is rc1/owned-files; it is not a fresh all-state green. Full author evidence retains22 reference pins, P5185/N4869/M4906 tracked states, raw and semantic indexes, complete dirty leaves, seven wider admin differences and a further P.git directory-stat difference. Cause/actor remain UNKNOWN. The original incorrect prefreeze 'no further admin' prose bytes are retained as base64 with verified original hash, and the corrected frozen report states the actual exception. Original display-label metadata corrections and narrower static-call UTC capture limits remain explicit. None is a scientific/model execution failure or a waiver of global administration drift.

This review's FIRST/initial and terminal protections are documented below and in the two machine-readable reviewer records. It preserves original failures, frozen inputs and author→independent review→lead intake→existing closure separation. Two oversized intermediate JSON displays were truncated; I subsequently extracted and checked the relevant structured metadata and original-report byte hash. Raw receipt payloads are stored evidence, not a claimed human reading of thousands of stage-index rows. No source/model/mathsoftware/tests/native/recipe execution or repository mutation occurred.

The original interacting gated-bilayer collision/imbalance/electrothermal/nozzle background, actual contact/Wannier/material errors, horizon mode conversion and actual correlated/anomalous incoming state, physical screened charge/gate/displacement receiver, absolute calibration/uncertainties and nonempty identifiable error-controlled usable band remain BUILD. The full target's independent two-route derivation remains owed; this note supplies it only for the explicitly declared noninteracting carrier. All21 bundles, B1–B8/D12, native/G4/G5/G11/full finding closure and main/human gates remain open. Existing main39FAIL/7035PASS/12SKIP, CI84of85/CI_SKIP failures, literal NJLVerifyFAIL4, safe candidate-notebook delivery and separate Lean receipts are not changed or reexecuted by this review. There is no infeasibility, deferral, reduced charter or bundle-green decision.

Mandatory scientific repairs: none found within this complete specified carrier contract. Actual implementation, source propagation, numerical/native checking, physical construction and lead intake remain separate required work.

## Reviewer preservation receipt

The actual pre-final terminal capture was 2026-10-18T10:05:53.195007+00:00 through10:05:54.453861+00:00. All24 reference fullstates; P5185/N4869/M4906 tracked fullstates; P0/N64/M3 known dirty leaves; raw-index bytes/fullstats; semantic-stage, HEAD, status, tracked-list and gitdir channels were exact to this reviewer's initial baseline. All15 actual optional-lock-disabled read-only Git subprocesses returned0 with separate raw channels. All431 captured administrative/ref/log/worktree fullstates were exact, including across the query interval. Captures are sequential observations, not an atomic snapshot or a claim about every uncaptured filesystem path. Earlier author and ancestor administrative exceptions remain, and these equalities do not erase them.

The complete substantive review and this actual preservation receipt precede the original once-only final. Its actual result will be appended without a refresh or second check.


Actual original FINAL: 2026-10-18T10:06:22.344539+00:00–10:06:22.562264+00:00, rc1, fresh=false, changed=[owned-files], separate stderr empty. It ran once on the unchanged original packet and is retained verbatim; no refresh/reissue. This is not a whole-tree/native/model PASS.

Post-original-final pure raw guard 2026-10-18T10:06:50.466304+00:00–2026-10-18T10:06:51.347174+00:00: Actual differences are retained in evidence.json; no cause or actor attribution, reset or rebaseline. No official check was repeated. The full manual scientific acceptance above remains scoped; lead intake and all original physical/native/main/closure work remain required.

<!-- END FULL ORIGINAL REVIEW -->
