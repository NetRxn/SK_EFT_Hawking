"""Real caller assurances for model assumptions versus physical UNKNOWN.

SOURCE DATA UNRUN. Numerical identities remain conditional model checks;
these tests do not establish physical EOS/current/dispersion/calibration.
"""
import json
from dataclasses import asdict

import pytest

from src.core.formulas import dispersive_correction
from src.graphene.bilayer_eos import (
    bilayer_impact_on_hawking, bulk_to_shear_ratio,
    conformal_symmetry_breaking_parameter,
)
from src.graphene.hawking_predictions import graphene_hawking_prediction
from src.graphene.platform_comparison import (
    all_platform_summaries, graphene_platform_summaries,
)


class TestPhysicalUnknownAndModelIdentity:
    @pytest.mark.parametrize("temperature", [100.0, 150.0, 300.0])
    def test_eos_physical_effects_are_unknown_not_false_success(self, temperature):
        result = bilayer_impact_on_hawking(temperature)
        for key in ("T_H_affected", "delta_disp_affected", "delta_diss_affected"):
            assert result[key] is None
            assert not isinstance(result[key], bool)
        assert result["physical_EOS_impact_status"] == "UNESTABLISHED"
        assert result["assessment_scope"] == "FIXED_SUPPLIED_INPUT_MODEL"
        assert result["model_T_H_record_affected"] is False
        assert result["model_delta_disp_record_affected"] is False
        assert result["model_delta_diss_record_affected"] is True
        assert "UNESTABLISHED" in result["summary"]
        assert "not a physical error bound" in result["summary"]

    @pytest.mark.parametrize("temperature", [100.0, 150.0, 300.0])
    def test_eos_numeric_recipe_is_preserved_as_an_estimate(self, temperature):
        result = bilayer_impact_on_hawking(temperature)
        cap = min(0.1, 15 * conformal_symmetry_breaking_parameter(temperature))
        assert result["zeta_over_eta"] == bulk_to_shear_ratio(temperature)
        assert result["zeta_over_eta"] == cap
        assert result["delta_diss"] == graphene_hawking_prediction(
            "Dean_bilayer_nozzle")["delta_diss"]
        assert result["delta_diss_upper"] == (
            result["delta_diss"] * (1.0 + result["zeta_over_eta"]))
        assert result["delta_diss_zeta_band_frac"] == cap

    def test_json_preserves_null_unknown_and_separate_model_booleans(self):
        result = json.loads(json.dumps(bilayer_impact_on_hawking()))
        assert result["T_H_affected"] is None
        assert result["delta_disp_affected"] is None
        assert result["delta_diss_affected"] is None
        assert result["physical_EOS_impact_status"] == "UNESTABLISHED"
        assert result["model_T_H_record_affected"] is False
        assert result["model_delta_diss_record_affected"] is True

    def test_platform_serialization_keeps_assumption_and_physical_status(self):
        summaries = all_platform_summaries()
        assert len(summaries) == 10
        assert sum(s.platform_type == "BEC" for s in summaries) == 3
        assert sum(s.platform_type == "polariton" for s in summaries) == 4
        assert sum(s.platform_type == "graphene" for s in summaries) == 3
        for summary in summaries:
            decoded = json.loads(json.dumps(asdict(summary)))
            assert decoded["assessment_scope"] == "ADOPTED_MODEL_COMPARISON"
            assert decoded["dispersion_category_basis"] == "ASSUMED_MODEL_TAG"
            for key in ("physical_dispersion_status", "physical_robustness_status",
                        "physical_detection_status"):
                assert decoded[key] == "UNESTABLISHED"

    def test_graphene_quantities_keep_canonical_fixed_input_identity(self):
        for summary in graphene_platform_summaries():
            prediction = graphene_hawking_prediction(summary.name)
            assert summary.T_H_K == prediction["T_H_K"]
            assert summary.delta_disp == prediction["delta_disp"]
            assert summary.delta_diss == prediction["delta_diss"]
            assert summary.D_adiabaticity == prediction["D"]
            assert summary.delta_disp == dispersive_correction(summary.D_adiabaticity)
            assert summary.dispersion_type == "subluminal"
            assert summary.physical_dispersion_status == "UNESTABLISHED"
