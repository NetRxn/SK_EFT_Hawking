"""Current E2 consumer checks; ideal numerical scope, no device acceptance."""
from decimal import Decimal
import pytest
from src.core.constants import K_B
from src.graphene.bilayer_eos import (
    bilayer_ideal_state_snapshot, bilayer_ideal_demonstration_cases,
)


def relative_close(ctx, actual, expected, budget="1e-35"):
    if expected == 0:
        assert actual == 0
    else:
        assert abs((actual - expected) / expected) < ctx.mpf(budget)


@pytest.mark.parametrize("case", [0, 1, 2, 3])
def test_full_snapshot_keeps_both_species_complete_tensors_and_actual_mode(case):
    _, snapshot = bilayer_ideal_demonstration_cases()[case]
    state, tensors, mode = snapshot["state"], snapshot["susceptibility"], snapshot["mode"]
    ctx = state["_context"]
    assert state["n_e"] > 0 and state["n_h"] > 0 and state["N"] > 0
    relative_close(ctx, state["n"], state["n_e"] - state["n_h"])
    relative_close(ctx, state["N"], state["n_e"] + state["n_h"])
    assert tensors["chi"].rows == tensors["H"].rows == 3
    for row in range(3):
        for column in range(3):
            relative_close(ctx, tensors["chi"][row, column], state["chi"][row, column])
            relative_close(ctx, tensors["H"][row, column], state["H"][row, column])
    relative_close(ctx, mode["rho_1"], mode["width"] * state["mass"] * state["N"])
    relative_close(ctx, mode["bulk_1"], 2 * mode["width"] * state["P"])
    relative_close(ctx, mode["Q_1"], -mode["charge_e"] * mode["width"] * state["n"])
    relative_close(ctx, mode["c_squared"], 2 * state["P"] / (state["mass"] * state["N"]))
    relative_close(ctx, mode["c"] * mode["c"], mode["c_squared"])
    relative_close(ctx, mode["G_ac"],
                   mode["Q_1"]**2 / (2 * mode["rho_1"] * mode["c"]))
    relative_close(ctx, mode["displacement_normalization"],
                   1 / ctx.sqrt(mode["rho_1"]))
    relative_close(ctx, mode["momentum_normalization"],
                   ctx.sqrt(mode["rho_1"]))
    relative_close(ctx, mode["displacement_normalization"] *
                   mode["momentum_normalization"], 1)
    relative_close(ctx, mode["current_velocity_coefficient"], mode["Q_1"])
    for index in range(3):
        relative_close(ctx, mode["density_compression_vector"][index],
                       -state["a"][index])
    assert snapshot["physical_matching_status"] == "BUILD"


def test_neutral_imbalance_and_charge_sign_are_not_erased():
    cases = bilayer_ideal_demonstration_cases()
    equilibrium, imbalanced, electron, hole = [x[1] for x in cases]
    assert equilibrium["state"]["n"] == imbalanced["state"]["n"] == 0
    assert equilibrium["mode"]["Q_1"] == imbalanced["mode"]["Q_1"] == 0
    assert imbalanced["state"]["N"] != equilibrium["state"]["N"]
    assert imbalanced["mode"]["c"] != equilibrium["mode"]["c"]
    assert electron["state"]["n"] > 0 > hole["state"]["n"]
    assert electron["mode"]["Q_1"] < 0 < hole["mode"]["Q_1"]
    assert electron["state"]["S"][0, 2] != 0
    assert electron["state"]["H"][0, 2] != 0


def test_width_scales_current_weight_without_changing_thermodynamic_state():
    from src.graphene.bilayer_eos import bilayer_effective_mass
    theta = Decimal(str(K_B)) * Decimal("150")
    args = (theta, theta / 2, Decimal("150"), bilayer_effective_mass())
    first = bilayer_ideal_state_snapshot(*args, width=Decimal("1e-6"))
    second = bilayer_ideal_state_snapshot(*args, width=Decimal("2e-6"))
    ctx = first["state"]["_context"]
    relative_close(ctx, second["mode"]["c"], first["mode"]["c"])
    for key in ("rho_1", "bulk_1", "Q_1", "G_ac"):
        relative_close(ctx, second["mode"][key], 2 * first["mode"][key])


def test_invalid_width_is_not_zero_filled_or_reported_as_measured_state():
    from src.graphene.bilayer_eos import bilayer_effective_mass
    with pytest.raises(ValueError):
        bilayer_ideal_state_snapshot(0, 0, 150, bilayer_effective_mass(), width=0)


def test_actual_ideal_figure_preserves_both_charge_signs_and_neutral_convective_zeros():
    from src.core.visualizations import fig_graphene_two_band_ideal_state
    fig = fig_graphene_two_band_ideal_state()
    assert len(fig.data) == 2
    assert len(fig.data[0].x) == len(fig.data[1].x) == 4
    assert all(value > 0 for value in fig.data[0].y)
    assert fig.data[1].y[0] == fig.data[1].y[1] == 0
    assert fig.data[1].y[2] < 0 < fig.data[1].y[3]
    assert "m/s" in fig.layout.yaxis.title.text
    assert "C/m" in fig.layout.yaxis2.title.text


def test_nondefault_SI_and_precision_reach_all_three_real_evaluators(monkeypatch):
    """Transparent call observation delegates to the real numerical APIs."""
    from src.core import formulas as api
    names = ("bilayer_two_band_state", "bilayer_two_band_susceptibility",
             "bilayer_locked_acoustic_parameters")
    originals = {name: getattr(api, name) for name in names}
    observed = []

    def observe(name, real):
        def call(*args, **kwargs):
            observed.append((name, args, dict(kwargs)))
            return real(*args, **kwargs)
        return call

    for name, real in originals.items():
        monkeypatch.setattr(api, name, observe(name, real))
    mu, mu_I, T, mass = (Decimal(value) for value in
                         ("2.3e-21", "8e-22", "173", "4.1e-32"))
    hbar, k_B, width, charge = (Decimal(value) for value in
                                ("1.11e-34", "1.49e-23", "2.4e-6", "1.7e-19"))
    common = dict(hbar=hbar, k_B=k_B, degeneracy=6,
                  rtol="1e-55", initial_dps=90, max_dps=720)
    snapshot = bilayer_ideal_state_snapshot(
        mu, mu_I, T, mass, width=width, charge_e=charge, **common)
    assert {name for name, _, _ in observed} == set(names)
    # Susceptibility and mode call the real state evaluator internally too.
    # Bind every such call, rather than inventing a direct-call cardinality.
    for name, args, kwargs in observed:
        assert args == (mu, mu_I, T, mass)
        assert all(kwargs[key] == value for key, value in common.items())
        if name == "bilayer_locked_acoustic_parameters":
            assert kwargs["width"] == width and kwargs["charge_e"] == charge
    expected = dict(mu=mu, mu_I=mu_I, T=T, mass=mass, hbar=hbar, k_B=k_B)
    states = [snapshot["state"], snapshot["susceptibility"]["state"],
              snapshot["mode"]["state"]]
    for state in states:
        ctx = state["_context"]
        for key, value in expected.items():
            assert state[key] == ctx.mpf(str(value))
        assert state["degeneracy"] == 6
        assert state["precision"]["rtol"] == common["rtol"]
        attempts = state["precision"]["attempts"]
        assert attempts[0]["dps"] == common["initial_dps"]
        assert all(attempt["dps"] <= common["max_dps"] for attempt in attempts)
        relative_close(ctx, state["mu"] * state["n"] +
                       state["mu_I"] * state["N"] + state["T"] * state["s"],
                       2 * state["P"], "1e-50")
    mode, state = snapshot["mode"], snapshot["state"]
    ctx = state["_context"]
    assert mode["width"] == ctx.mpf(str(width))
    assert mode["charge_e"] == ctx.mpf(str(charge))
    relative_close(ctx, mode["rho_1"], ctx.mpf(str(width)) * ctx.mpf(str(mass)) * state["N"])
    relative_close(ctx, mode["Q_1"], -ctx.mpf(str(charge)) * ctx.mpf(str(width)) * state["n"])
    relative_close(ctx, mode["G_ac"], mode["Q_1"]**2 /
                   (2 * mode["rho_1"] * mode["c"]))
    relative_close(ctx, mode["c"] * mode["c"], mode["c_squared"])
    relative_close(ctx, mode["displacement_normalization"],
                   1 / ctx.sqrt(mode["rho_1"]))
    relative_close(ctx, mode["momentum_normalization"], ctx.sqrt(mode["rho_1"]))
    relative_close(ctx, mode["displacement_normalization"] *
                   mode["momentum_normalization"], 1)
    relative_close(ctx, mode["current_velocity_coefficient"], mode["Q_1"])
    for index in range(3):
        relative_close(ctx, mode["density_compression_vector"][index], -state["a"][index])
    for row in range(3):
        for column in range(3):
            relative_close(ctx, snapshot["susceptibility"]["chi"][row, column],
                           state["chi"][row, column], "1e-50")
            relative_close(ctx, snapshot["susceptibility"]["H"][row, column],
                           state["H"][row, column], "1e-50")
    assert snapshot["requested_precision"] == {
        "rtol": "1e-55", "initial_dps": 90, "max_dps": 720}


def test_valid_unresolved_state_retains_ArithmeticError_not_ValueError_or_zero():
    # Exact accepted canonical refusal case, now through the real consumer.
    with pytest.raises(ArithmeticError, match="physical domain unchanged"):
        bilayer_ideal_state_snapshot(
            1, 2, 1, 1, hbar=1, k_B=1, width=1, charge_e=1,
            rtol="1e-100", initial_dps=20, max_dps=40)


def test_actual_platform_rows_and_rendered_cells_bind_all_original_qualifications():
    from pathlib import Path
    from scripts.paper_tables import render_table
    from scripts.paper_tables.sources import graphene_platform_comparison_rows
    from scripts.render_paper_tables import _load_spec
    from src.graphene.hawking_predictions import graphene_hawking_prediction
    from src.graphene.platform_comparison import bec_platform_summaries
    from src.core.constants import GRAPHENE_PLATFORMS
    import math

    rows = graphene_platform_comparison_rows()
    assert [row["geometry"] for row in rows] == [
        "Dean bilayer nozzle", "Monolayer 100nm", "Monolayer 50nm",
        "BEC Steinhauer reference"]
    dean, mono100, mono50, bec = rows
    for row, key in zip(rows[:3], ("Dean_bilayer_nozzle", "Monolayer_100nm", "Monolayer_50nm")):
        prediction = graphene_hawking_prediction(key)
        assert float(row["temperature"]) == pytest.approx(prediction["T_H_K"], rel=0.005)
        assert float(row["D"].split("$")[0]) == pytest.approx(prediction["D"], rel=0.005)
        assert float(row["ratio"].split("$")[0]) == pytest.approx(
            GRAPHENE_PLATFORMS[key]["omega_H_over_Gamma_mr"], rel=0.005)
    assert "$^*$" in mono50["D"]
    assert "$^*$" not in dean["D"] and "$^*$" not in mono100["D"]
    assert r"$^\dagger$" in dean["ratio"]
    assert all(r"$^\dagger$" not in row["ratio"] for row in rows[1:])
    assert r"$^\ddagger$" in bec["transmission"]
    assert all(r"$^\ddagger$" not in row["transmission"] for row in rows[:3])
    reference = next(item for item in bec_platform_summaries()
                     if item.name == "Steinhauer_Rb87")
    assert float(bec["temperature"]) == pytest.approx(reference.T_H_K, rel=0.005)
    assert float(bec["D"]) == pytest.approx(reference.D_adiabaticity, rel=0.005)
    assert float(bec["ratio"].split(" ")[0]) == pytest.approx(
        1 / (2 * math.pi * reference.delta_diss), rel=0.005)
    path = Path(__file__).resolve().parents[1] / "papers/paper16_graphene_sk_eft/tables.py"
    loaded = _load_spec(path, strict=True)
    assert loaded is not None
    rendered = render_table(loaded["tables"]["table_platforms"])
    body_rows = [line for line in rendered.splitlines()
                 if any(row["geometry"] in line for row in rows)]
    assert len(body_rows) == 4
    for actual, row in zip(body_rows, rows):
        assert all(str(row[field]) in actual for field in
                   ("geometry", "temperature", "D", "ratio", "transmission"))
    assert "$^*$" in body_rows[2]
    assert r"$^\dagger$" in body_rows[0]
    assert r"$^\ddagger$" in body_rows[3]
