"""Existing canonical table-renderer specifications, numerical values not cached."""
from scripts.paper_tables import Col
from scripts.paper_tables.sources import graphene_platform_comparison_rows, graphene_two_band_prerequisite_rows
TABLES = {
 "table_platforms": {"description": "Adopted platform references; different damping denominators labelled",
 "rows": graphene_platform_comparison_rows,
 "columns": [Col("geometry","Geometry","l"),Col("temperature","$T_H$ (K)"),
             Col("D","$D$"),Col("ratio",r"$\omega_H/\Gamma$"),Col("transmission","Transmission","l")]},
 "table_two_band": {"description": "Four illustrative ideal SI states; no Dean fit/noise calibration",
 "rows": graphene_two_band_prerequisite_rows,
 "columns": [Col("quantity","Quantity","l"),Col("unit","SI units","l"),
             Col("case0","Neutral eq."),Col("case1","Neutral imb."),
             Col("case2","Electron"),Col("case3","Hole")]}}
