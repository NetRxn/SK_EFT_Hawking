"""Finite current-source computation support for the existing graph producer.

No scientific module is imported or executed. Raw structural observations are
always unaccepted; repository review/source receipts independently govern the
projection into numerical VERIFIES edges. See ADR-009 D6.
"""
from __future__ import annotations

import ast
from collections import ChainMap
import copy
import hashlib
import json
import importlib.metadata
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path

SCHEMA = "computation-support/v1"
RAW = "UNACCEPTED_RAW"
STRONG = frozenset(("golden", "identity", "roundtrip"))
LIMITS = {"ast_nodes": 200000, "steps": 2000000, "loop": 256,
          "contexts": 4096, "expressions": 65536, "projections": 4096,"cfg_states":512}


def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()


def syntax(node):
    return ast.dump(node, include_attributes=False) if node is not None else ""


def public_population(source):
    """Enumerate functions before references; metadata does not create a proof."""
    tree = ast.parse(source)
    out, seen = [], set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith("_"):
            if node.name in seen:
                raise ValueError(f"duplicate public Formula: {node.name}")
            seen.add(node.name)
            doc = ast.get_docstring(node) or ""
            import re
            match = re.search(r"Lean:\s*([^\n]+)", doc)
            refs = [x.strip() for x in match.group(1).split(",")] if match else []
            category = "zero" if not refs else "none" if all(
                re.split(r'[—–(]',x.lower())[0].strip(" .") in ("none", "n/a", "not yet formalized") for x in refs) else "unresolved"
            out.append({"name": node.name, "line": node.lineno,
                        "refs": refs, "category": category, "source_sha256": digest(source.encode())})
    return out


@dataclass
class Value:
    expr: tuple = ("unknown",)
    data: object = None
    ref: int | None = None
    shape: tuple | None = None
    function: object = None
    defaults: dict = field(default_factory=dict)
    closure: dict = field(default_factory=dict)


def literal(value):
    if isinstance(value, bool) or value is None or isinstance(value, (str, int, float)):
        return Value(("literal", type(value).__name__, repr(value)), value)
    return Value(("unknown", "not a scalar"))


def dependencies(expr):
    result = set()
    if isinstance(expr, tuple):
        if expr and expr[0] in ("canonical", "private-canonical"):
            result.add(expr[1])
        for item in expr:
            if isinstance(item, tuple):
                result.update(dependencies(item))
    return result


class Budget(Exception):
    pass


class CanonicalIndex:
    """One source parse shared by the same producer's whole test roster."""
    def __init__(self,source):
        self.source=source;self.sha=digest(source.encode());self.tree=ast.parse(source)
        if sum(1 for _ in ast.walk(self.tree))>LIMITS['ast_nodes']:raise Budget('CANONICAL_AST_NODES')
        self.functions={n.name:n for n in self.tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
        self.function_hashes={name:digest(syntax(node).encode())for name,node in self.functions.items()}
        self.shapes=None


class Analysis:
    """One bounded binding/CFG/effect analysis; acceptance never runs its body."""
    def __init__(self, source, path, canonical_source="", questions=(), repository_root=None):
        self.source, self.path = source, path
        self.repository_root=Path(repository_root).resolve()if repository_root is not None else None
        self.module_environments={};self.loading_modules=set();self.repository_inputs={}
        self.node_origins={}
        self.sha = digest(source.encode())
        self.tree = ast.parse(source, filename=path)
        if sum(1 for _ in ast.walk(self.tree)) > LIMITS["ast_nodes"]:
            raise Budget("AST_NODES")
        self.node_origins.update({id(n):(path,self.sha)for n in ast.walk(self.tree)})
        self.heap, self.versions, self.next_ref = {}, {}, 0
        self.heap_epoch, self.expression_cache, self.dependency_cache = 0, {}, {}
        self.expression_nodes, self.node_cache = {}, {}
        self.env, self.records, self.diagnostics = {}, [], []
        self.steps, self.contexts = 0, 0
        self.stack, self.guards, self.case, self.current_test = [], [], {}, ""
        self.call_sites, self.active_refs = [], []
        self.pending_returns=[]
        self.numeric_contexts={};self.escaped_callbacks=set()
        self.global_refs=set();self.global_poisoned=set();self.repository_heap={};self.repository_versions={}
        self.questions = list(questions)
        canonical=canonical_source if isinstance(canonical_source,CanonicalIndex)else CanonicalIndex(canonical_source)
        self.canonical_sha=canonical.sha
        self.canonical_index=canonical
        self.projection_keys=set()
        self.canonical_functions=canonical.functions
        if canonical.shapes is None:canonical.shapes=self._shapes()
        self.shapes=canonical.shapes
        self.function_nodes = {n.name: n for n in self.tree.body if isinstance(n, ast.FunctionDef)}
        self.recursive = self._recursive_components()
        self._module()
        self.global_refs.update(self.heap.keys())

    def _recursive_components(self):
        graph = {name: {n.func.id for n in ast.walk(fn) if isinstance(n, ast.Call)
                       and isinstance(n.func, ast.Name) and n.func.id in self.function_nodes}
                 for name, fn in self.function_nodes.items()}
        recursive = set()
        for name in graph:
            todo, seen = list(graph[name]), set()
            while todo:
                item = todo.pop()
                if item == name:
                    recursive.add(name)
                    break
                if item not in seen:
                    seen.add(item); todo.extend(graph[item])
        return recursive

    def _shapes(self):
        """Current canonical return structure, not scientific output validation."""
        shapes = {}
        for _ in range(len(self.canonical_functions) + 1):
            changed = False
            for name, fn in self.canonical_functions.items():
                local = {}
                def shape(node):
                    if isinstance(node, ast.Name): return local.get(node.id)
                    if isinstance(node, ast.UnaryOp): return shape(node.operand)
                    if isinstance(node, ast.Call):
                        callee = node.func.attr if isinstance(node.func, ast.Attribute) else getattr(node.func, 'id', '')
                        if callee in self.canonical_functions: return shapes.get(callee)
                        if callee=='matrix'and len(node.args)==2 and all(isinstance(a,ast.Constant)and type(a.value)is int for a in node.args):return tuple(a.value for a in node.args)
                        if callee in ('matrix', 'diag') and node.args:
                            arg = node.args[0]
                            if isinstance(arg, (ast.List, ast.Tuple)):
                                n = len(arg.elts)
                                if callee == 'diag': return (n, n)
                                return (n, len(arg.elts[0].elts)) if n and isinstance(arg.elts[0], (ast.List, ast.Tuple)) else (n, 1)
                        if callee == 'eye' and node.args and isinstance(node.args[0], ast.Constant): return (node.args[0].value,) * 2
                    if isinstance(node, ast.Subscript):
                        base = shape(node.value)
                        if isinstance(base, dict) and isinstance(node.slice, ast.Constant): return base.get(node.slice.value)
                    if isinstance(node, ast.BinOp): return shape(node.left) or shape(node.right)
                    if isinstance(node, ast.Dict):
                        return {k.value: shape(v) for k, v in zip(node.keys,node.values) if isinstance(k,ast.Constant)}
                    return None
                def owned_nodes(node):
                    # A nested species helper has a distinct return contract;
                    # its dict cannot overwrite the enclosing state contract.
                    for child in ast.iter_child_nodes(node):
                        if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.Lambda,ast.ClassDef)):continue
                        yield child
                        yield from owned_nodes(child)
                for n in owned_nodes(fn):
                    if isinstance(n, ast.Assign):
                        for target in n.targets:
                            if isinstance(target, ast.Name): local[target.id] = shape(n.value)
                    elif isinstance(n, ast.Return):
                        result = shape(n.value)
                        if result and result != shapes.get(name): shapes[name] = result; changed = True
            if not changed: break
        return shapes

    def tick(self, amount=1):
        self.steps += amount
        if self.steps > LIMITS['steps']: raise Budget('FINITE_WORK_UNITS')

    def pack(self, value, depth=0):
        """Hash-cons immutable expression nodes; source evidence stays complete.

        A JSON DAG reference always resolves in expression_nodes. Each node is
        visited/charged once, even when Richardson refinement shares subtrees.
        Containers outside expressions retain their original keyed structure.
        """
        self.tick()
        if depth>128:raise Budget('EXPRESSION_DEPTH')
        if isinstance(value,tuple):
            old=self.node_cache.get(id(value))
            if old is not None and old[0] is value:return {'$expr':old[1]}
            payload=[self.pack(v,depth+1)for v in value]
            raw=json.dumps(payload,sort_keys=True,separators=(',',':'),default=str)
            self.tick((len(raw)+63)//64)
            key=hashlib.sha256(raw.encode()).hexdigest()
            if key not in self.expression_nodes:
                if len(self.expression_nodes)>=LIMITS['expressions']:raise Budget('EXPRESSION_NODES')
                self.expression_nodes[key]=payload
            self.node_cache[id(value)]=(value,key)
            return {'$expr':key}
        if isinstance(value,list):return [self.pack(v,depth+1)for v in value]
        if isinstance(value,dict):return {str(k):self.pack(v,depth+1)for k,v in value.items()}
        if isinstance(value,(str,bytes)):self.tick((len(value)+63)//64)
        return value

    def expression_key(self,value):
        return self.pack(value)['$expr']

    def encoded(self, value):
        packed=self.pack(value)
        raw=json.dumps(packed,sort_keys=True,separators=(',',':'),ensure_ascii=False,default=str)
        self.tick((len(raw)+63)//64)
        return raw

    def representation_expression(self,expr):
        todo=[expr];seen=set()
        while todo:
            item=todo.pop();self.tick()
            if not isinstance(item,tuple)or id(item)in seen:continue
            seen.add(id(item))
            if item[:1]in(('attribute',),('field',))and item[2]in('_mpf_','dps'):return True
            todo.extend(v for v in item if isinstance(v,tuple))
        return False

    def contains_token(self,expr,token):
        todo=[expr];seen=set()
        while todo:
            item=todo.pop();self.tick()
            if isinstance(item,str)and token in item:return True
            if isinstance(item,tuple)and id(item)not in seen:
                seen.add(id(item));todo.extend(item)
        return False

    def bound_digest(self, value):
        return hashlib.sha256(self.encoded(value).encode()).hexdigest()

    def symbols(self, expr):
        old=self.dependency_cache.get(id(expr))
        if old is not None and old[0] is expr:return old[1]
        found=set();todo=[expr];seen=set()
        while todo:
            item=todo.pop();self.tick()
            if not isinstance(item,tuple)or id(item)in seen:continue
            seen.add(id(item))
            if item and item[0]in('canonical','private-canonical'):found.add(item[1])
            todo.extend(v for v in item if isinstance(v,tuple))
        result=frozenset(found);self.dependency_cache[id(expr)]=(expr,result)
        return result

    def diagnostic(self, code, node=None, **details):
        if code=='WORK_BUDGET':
            # Fixed-size refusal fields, not a hidden continuation of analysis.
            fields={'reason':str(details.get('reason','unknown budget'))}
            case=copy.deepcopy(self.case)
        else:fields=self.pack(details);case=self.pack(self.case)
        record={'code':code,'visibility':RAW,'test':self.current_test,
                'path':self.path,'source_sha256':self.sha,
                'line':getattr(node,'lineno',None),'case':case,**fields}
        self.diagnostics.append(record)
        return Value(('unknown',code))

    def alloc(self, items, shape=None):
        self.next_ref += 1
        if self.next_ref > LIMITS['expressions']: raise Budget('EXPRESSION_ALLOCATIONS')
        self.heap[self.next_ref] = items
        self.versions[self.next_ref] = 0
        return Value(('allocation', self.next_ref), ref=self.next_ref, shape=shape)

    def items(self, value):
        return self.heap.get(value.ref)

    def expression(self, value):
        if value.ref is None: return value.expr
        cache_key=(self.heap_epoch,value.ref)
        if cache_key in self.expression_cache:return self.expression_cache[cache_key]
        entries = self.items(value)
        if entries is None:return self.diagnostic('MISSING_HEAP_CELL',reference=value.ref).expr
        self.tick(1 + len(entries))
        if isinstance(entries, dict):
            result=('mapping', tuple((repr(k), self.expression(v)) for k,v in entries.items()))
        else:result=('sequence', tuple(self.expression(x) for x in entries))
        self.expression_cache[cache_key]=result
        return result

    def joined(self, a, b):
        if self.expression_key(self.expression(a)) == self.expression_key(self.expression(b)): return a
        ai, bi = self.items(a), self.items(b)
        if isinstance(ai, dict) and isinstance(bi, dict) and ai.keys() == bi.keys():
            return self.alloc({k:self.joined(ai[k],bi[k]) for k in ai}, a.shape if a.shape == b.shape else None)
        if isinstance(ai,list) and isinstance(bi,list) and len(ai)==len(bi):
            return self.alloc([self.joined(x,y)for x,y in zip(ai,bi)],a.shape if a.shape==b.shape else None)
        exprs = {self.expression_key(x):x for x in (a.expr[1:] if a.expr[:1] == ('phi',) else (self.expression(a),))}
        exprs.update({self.expression_key(x):x for x in (b.expr[1:] if b.expr[:1] == ('phi',) else (self.expression(b),))})
        if len(exprs)>LIMITS['cfg_states']:raise Budget('CFG_JOIN_STATES')
        return Value(('phi', *(exprs[k]for k in sorted(exprs))), shape=a.shape if a.shape==b.shape else None)

    def function_value(self,node,env):
        positional=node.args.posonlyargs+node.args.args
        defaults={a.arg:self.expr(v,env)for a,v in zip(positional[-len(node.args.defaults):],node.args.defaults)}if node.args.defaults else{}
        defaults.update({a.arg:self.expr(v,env)for a,v in zip(node.args.kwonlyargs,node.args.kw_defaults)if v is not None})
        return Value(('function',getattr(node,'name','<lambda>'),getattr(node,'lineno',0)),function=node,defaults=defaults,closure=env)

    def local_bindings(self,node):
        names=set()
        def visit(item):
            if isinstance(item,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))and item is not node:
                names.add(item.name);return
            if isinstance(item,(ast.Lambda,ast.ListComp,ast.SetComp,ast.DictComp,ast.GeneratorExp))and item is not node:return
            if isinstance(item,ast.Name)and isinstance(item.ctx,(ast.Store,ast.Del)):names.add(item.id)
            if isinstance(item,(ast.Import,ast.ImportFrom)):
                names.update(a.asname or(a.name.split('.')[0]if isinstance(item,ast.Import)else a.name)for a in item.names)
            for child in ast.iter_child_nodes(item):visit(child)
        visit(node)
        return names

    def repository_module(self,module):
        if module in self.module_environments:return self.module_environments[module]
        if self.repository_root is None or not module or not all(p.isidentifier()for p in module.split('.')):return None
        if module in self.loading_modules:
            self.diagnostic('SCC_MODULE_IMPORT',module=module);return None
        stem=Path(*module.split('.'))
        paths=[self.repository_root/stem.with_suffix('.py'),self.repository_root/stem/'__init__.py']
        present=[p for p in paths if p.is_file()]
        if len(present)!=1:return None
        path=present[0];raw=path.read_bytes();source=raw.decode();tree=ast.parse(source,filename=str(path))
        if sum(1 for _ in ast.walk(tree))>LIMITS['ast_nodes']:raise Budget('HELPER_AST_NODES')
        relative=path.relative_to(self.repository_root).as_posix();sha=digest(raw)
        self.repository_inputs[relative]=sha;self.node_origins.update({id(n):(relative,sha)for n in ast.walk(tree)})
        start_ref=self.next_ref
        env={'__name__':literal(module)};self.loading_modules.add(module)
        self.module_body(tree.body,env)
        self.loading_modules.remove(module);self.module_environments[module]=env
        new_refs=range(start_ref+1,self.next_ref+1)
        for ref in new_refs:self.repository_heap[ref]=self.heap[ref];self.repository_versions[ref]=self.versions[ref]
        self.global_refs.update(new_refs)
        return env

    def module_body(self,body,env):
        for n in body:
            if isinstance(n,(ast.Import,ast.ImportFrom,ast.Assign,ast.AnnAssign)):
                self.statement(n,env)
            elif isinstance(n,ast.FunctionDef):env[n.name]=self.function_value(n,env)
            elif isinstance(n,ast.ClassDef):continue # lexical test containers
            elif isinstance(n,ast.Expr)and isinstance(n.value,ast.Constant):continue
            elif isinstance(n,ast.Expr)and isinstance(n.value,ast.Call):
                before=len(self.diagnostics);self.statement(n,env)
                if len(self.diagnostics)>before:env['__unsupported_module_effect__']=literal(True)
            else:
                env['__unsupported_module_effect__']=literal(True)
                self.diagnostic('UNSUPPORTED_MODULE_EFFECT',n)

    def _module(self):
        self.module_body(self.tree.body,self.env)

    def operator(self, op, a, b):
        ae,be=self.expression(a),self.expression(b)
        av,bv=a.data,b.data
        ai,bi=self.items(a),self.items(b)
        if op=='+'and isinstance(ai,list)and isinstance(bi,list):
            self.tick(len(ai)+len(bi));return self.alloc(ai+bi)
        if op=='*' and (av==0 or bv==0): return literal(0)
        if op=='+' and av==0:return b
        if op=='+' and bv==0:return a
        if op=='-' and self.expression_key(ae)==self.expression_key(be):
            if self.symbols(ae):self.diagnostic('ORACLE_ALIAS', actual_expression=ae)
            return literal(0)
        if op=='*' and av==1:return b
        if op=='*' and bv==1:return a
        if op in ('+','-','*','/','**') and type(av) in (int,Fraction) and type(bv) in (int,Fraction):
            try:
                if op=='**'and (abs(bv)>4096 or bv.denominator!=1 if isinstance(bv,Fraction)else abs(bv)>4096):raise Budget('EXACT_POWER_SIZE')
                self.tick(max(1,(len(str(av))+len(str(bv)))//64))
                result={'+':lambda:av+bv,'-':lambda:av-bv,'*':lambda:av*bv,'/':lambda:Fraction(av)/Fraction(bv),'**':lambda:av**bv}[op]()
                return Value(('number',str(result)),result)
            except (ZeroDivisionError,OverflowError,TypeError):pass
        shape = a.shape or b.shape
        if op=='*' and a.shape and b.shape: shape=(a.shape[0],b.shape[1])
        return Value((op,ae,be),shape=shape)

    def lookup(self, obj, key):
        self.projection_keys.add(repr(key))
        if len(self.projection_keys)>LIMITS['projections']:raise Budget('PROJECTION_KEYS')
        entries=self.items(obj)
        if entries is not None:
            try:
                if obj.shape and isinstance(entries,list) and isinstance(key,tuple):
                    return entries[key[0]*obj.shape[1]+key[1]]
                return entries[key]
            except (KeyError,IndexError,TypeError): return Value(('unknown','projection missing'))
        base=self.expression(obj)
        shape=None
        if base[:1] in (('canonical',),('private-canonical',)):
            contract=self.shapes.get(base[1],{})
            if isinstance(contract,dict):shape=contract.get(key)
        if isinstance(shape,dict): return Value(('field',base,key),data=shape)
        if shape is None and isinstance(obj.data,dict): shape=obj.data.get(key)
        return Value(('field',base,key),shape=shape if isinstance(shape,tuple) else None)

    def expr(self, n, env):
        self.tick()
        if n is None:return literal(None)
        if isinstance(n,ast.Constant):return literal(n.value)
        if isinstance(n,ast.Name):
            if n.id in env:return env[n.id]
            if n.id in {'abs','range','dict','set','frozenset','list','tuple','zip','next','sorted','str','max','min','print','ValueError','ArithmeticError','TypeError','AssertionError'}:return Value(('builtin',n.id))
            return Value(('unbound',n.id))
        if isinstance(n,(ast.List,ast.Tuple,ast.Set)):
            return self.alloc([self.expr(x,env)for x in n.elts])
        if isinstance(n,ast.Dict):
            result={}
            for key,val in zip(n.keys,n.values):
                if key is None:
                    items=self.items(self.expr(val,env))
                    if not isinstance(items,dict):return self.diagnostic('UNKNOWN_KWARGS',n)
                    result.update(items)
                else:result[self.expr(key,env).data]=self.expr(val,env)
            return self.alloc(result)
        if isinstance(n,ast.Attribute):
            obj=self.expr(n.value,env)
            if obj.expr[:1]==('numeric-context',)and n.attr=='dps':
                return self.numeric_contexts[obj.expr[1]].get('dps',Value(('unknown','CONTEXT_PRECISION_UNBOUND')))
            module_path=self.call_path(obj)
            if obj.expr[:1]==('module',)and not module_path.startswith('src.core.formulas'):
                members=self.repository_module(module_path)
                if members is not None and n.attr in members:return members[n.attr]
            if n.attr in ('rows','cols') and obj.shape:return literal(obj.shape[0 if n.attr=='rows'else 1])
            if n.attr=='T':return Value(('transpose',self.expression(obj)),shape=obj.shape[::-1] if obj.shape else None)
            return Value(('attribute',self.expression(obj),n.attr),function=(obj,n.attr))
        if isinstance(n,ast.Subscript):
            obj=self.expr(n.value,env)
            if isinstance(n.slice,ast.Slice):
                values=self.items(obj)
                return self.alloc(list(values)) if isinstance(values,list) else self.diagnostic('UNKNOWN_SLICE',n)
            key=self.expr(n.slice,env)
            if isinstance(n.slice,ast.Tuple): keydata=tuple(x.data for x in self.items(key))
            else:keydata=key.data
            if keydata is None and not isinstance(n.slice,ast.Constant):return self.diagnostic('UNKNOWN_PROJECTION',n)
            return self.lookup(obj,keydata)
        if isinstance(n,ast.BinOp):
            op={ast.Add:'+',ast.Sub:'-',ast.Mult:'*',ast.Div:'/',ast.Pow:'**',ast.BitOr:'set-union'}.get(type(n.op))
            a,b=self.expr(n.left,env),self.expr(n.right,env)
            if op=='set-union' and self.items(a)is not None and self.items(b)is not None:
                return self.alloc(list(self.items(a))+list(self.items(b)))
            return self.operator(op or 'unsupported',a,b)
        if isinstance(n,ast.UnaryOp):
            a=self.expr(n.operand,env)
            if isinstance(n.op,ast.Not):return literal(not a.data) if a.data is not None else Value(('not',self.expression(a)))
            return self.operator('*',literal(-1),a) if isinstance(n.op,ast.USub) else a
        if isinstance(n,ast.Compare):
            a,b=self.expr(n.left,env),self.expr(n.comparators[0],env)
            av,bv=a.data,b.data;op=type(n.ops[0]).__name__
            if op in ('Is','IsNot') and isinstance(n.comparators[0],ast.Constant) and n.comparators[0].value is None:
                if a.expr == literal(None).expr:return literal(op=='Is')
                if a.expr[:1] not in (('unknown',),('phi',),('unbound',)):return literal(op=='IsNot')
            if op in ('In','NotIn') and self.items(b) is not None:
                found=any(self.expression(a)==self.expression(v) for v in self.items(b))
                return literal(found if op=='In'else not found)
            known = av is not None and bv is not None
            if known:
                try:return literal({'Eq':lambda:av==bv,'NotEq':lambda:av!=bv,'Lt':lambda:av<bv,'LtE':lambda:av<=bv,'Gt':lambda:av>bv,'GtE':lambda:av>=bv,'Is':lambda:av is bv,'IsNot':lambda:av is not bv,'In':lambda:av in bv}.get(op,lambda:None)())
                except (TypeError,ValueError):pass
            return Value(('compare',op,self.expression(a),self.expression(b)))
        if isinstance(n,ast.BoolOp):
            vals=[]
            for item in n.values:
                value=self.expr(item,env);vals.append(value);known=self.truth(value)
                if (isinstance(n.op,ast.And)and known is False)or(isinstance(n.op,ast.Or)and known is True):break
            truth = [self.truth(v) for v in vals]
            if isinstance(n.op,ast.And) and False in truth:return literal(False)
            if isinstance(n.op,ast.Or) and True in truth:return literal(True)
            if all(v is not None for v in truth):return literal(all(truth)if isinstance(n.op,ast.And)else any(truth))
            return Value(('bool',type(n.op).__name__,*(self.expression(x)for x in vals)))
        if isinstance(n,ast.IfExp):
            c=self.expr(n.test,env)
            if type(c.data)is bool:return self.expr(n.body if c.data else n.orelse,env)
            return self.joined(self.expr(n.body,env),self.expr(n.orelse,env))
        if isinstance(n,ast.Lambda):
            return self.function_value(n,env)
        if isinstance(n,(ast.ListComp,ast.SetComp,ast.GeneratorExp,ast.DictComp)):
            result=[];pairs={}
            def expand(index,scope):
                if index==len(n.generators):
                    if isinstance(n,ast.DictComp):pairs[self.expr(n.key,scope).data]=self.expr(n.value,scope)
                    else:result.append(self.expr(n.elt,scope))
                    return
                gen=n.generators[index];seq=self.iterable(self.expr(gen.iter,scope),gen)
                for item in seq:
                    local=dict(scope);self.assign(gen.target,item,local)
                    conditions=[self.expr(x,local)for x in gen.ifs]
                    if any(c.data is False for c in conditions):continue
                    if any(c.data is None for c in conditions):self.guards.append(('conditional-generator',syntax(gen)))
                    expand(index+1,local)
                    if any(c.data is None for c in conditions):self.guards.pop()
            expand(0,dict(env));return self.alloc(pairs if isinstance(n,ast.DictComp)else result)
        if isinstance(n,ast.Call):return self.call(n,env)
        return self.diagnostic('UNSUPPORTED_OPERATION',n,operation=type(n).__name__)

    def truth(self, value):
        items=self.items(value)
        if items is not None:return bool(items)
        if value.expr == literal(None).expr:return False
        if value.data is not None:return bool(value.data)
        return None

    def iterable(self,v,node):
        values=self.items(v)
        if isinstance(values,dict):values=[literal(k)for k in values]
        if values is None and v.shape and v.shape[1]==1:
            values=[self.lookup(v,i)for i in range(v.shape[0])]
        if not isinstance(values,list):self.diagnostic('UNKNOWN_ITERATION',node);return []
        if len(values)>LIMITS['loop']:raise Budget('LOOP_DOMAIN')
        if not values:self.diagnostic('EMPTY_ITERATION',node)
        return list(values)

    def assign(self,target,v,env):
        if isinstance(target,ast.Name):env[target.id]=v;return
        if isinstance(target,(ast.Tuple,ast.List)):
            values=self.items(v)
            if not isinstance(values,list)or len(values)!=len(target.elts):
                for x in target.elts:self.assign(x,Value(('unknown','unpack')),env)
            else:
                for x,item in zip(target.elts,values):self.assign(x,item,env)
            return
        if isinstance(target,ast.Subscript):
            obj=self.expr(target.value,env);key=self.expr(target.slice,env);keydata=key.data
            if isinstance(target.slice,ast.Tuple):keydata=tuple(x.data for x in self.items(key))
            values=self.items(obj)
            if values is not None:
                try:
                    if obj.shape and isinstance(keydata,tuple):keydata=keydata[0]*obj.shape[1]+keydata[1]
                    updated=values.copy();updated[keydata]=v;self.tick(len(values))
                    if obj.ref in self.global_refs:
                        self.global_poisoned.add(obj.ref);updated[keydata]=Value(('unknown','GLOBAL_MUTABLE_EFFECT'))
                        self.diagnostic('GLOBAL_MUTABLE_EFFECT',target,reference=obj.ref)
                    self.heap[obj.ref]=updated;self.versions[obj.ref]+=1;self.heap_epoch+=1;return
                except (KeyError,IndexError,TypeError):pass
            self.diagnostic('UNKNOWN_STORE_EFFECT',target)
        elif isinstance(target,ast.Attribute):
            obj=self.expr(target.value,env)
            if target.attr=='dps':
                key=obj.expr[1]if obj.expr[:1]==('numeric-context',)else'ambient:'+self.call_path(obj)
                self.numeric_contexts.setdefault(key,{})['dps']=v
            else:self.diagnostic('UNKNOWN_ATTRIBUTE_EFFECT',target)

    def call(self,n,env):
        fn=self.expr(n.func,env);args=[];kw={}
        for item in n.args:
            if isinstance(item,ast.Starred):args.extend(self.iterable(self.expr(item.value,env),item))
            else:args.append(self.expr(item,env))
        for item in n.keywords:
            value=self.expr(item.value,env)
            if item.arg is None:
                mapping=self.items(value)
                if not isinstance(mapping,dict):return self.diagnostic('UNKNOWN_KWARGS',n)
                if set(mapping)&set(kw):return self.diagnostic('DUPLICATE_KEYWORD',n)
                kw.update(mapping)
            else:
                if item.arg in kw:return self.diagnostic('DUPLICATE_KEYWORD',n)
                kw[item.arg]=value
        path=self.call_path(fn)
        if path.startswith('src.core.formulas.'):
            name=path.rsplit('.',1)[-1]
            formal={};definition=self.canonical_functions.get(name)
            if definition is not None:
                parameters=definition.args.posonlyargs+definition.args.args
                if len(args)>len(parameters):return self.diagnostic('ARGUMENT_BINDING',n,callee=path)
                formal={p.arg:v for p,v in zip(parameters,args)}
                if formal.keys()&kw.keys():return self.diagnostic('DUPLICATE_KEYWORD',n,callee=path)
                all_parameters=parameters+definition.args.kwonlyargs
                permitted={p.arg for p in all_parameters}
                if set(kw)-permitted:return self.diagnostic('ARGUMENT_BINDING',n,callee=path)
                formal.update(kw)
                defaults=list(zip(parameters[-len(definition.args.defaults):],definition.args.defaults))if definition.args.defaults else[]
                defaults+=list(zip(definition.args.kwonlyargs,definition.args.kw_defaults))
                for parameter,default in defaults:
                    if parameter.arg not in formal and default is not None:
                        formal[parameter.arg]=literal(default.value)if isinstance(default,ast.Constant)else Value(('canonical-default',syntax(default)))
                if permitted-formal.keys():return self.diagnostic('ARGUMENT_BINDING',n,callee=path,missing=sorted(permitted-formal.keys()))
            inputs={'positional':[self.expression(x)for x in args], 'keywords':{k:self.expression(v)for k,v in kw.items()},
                    'formal':{k:self.expression(v)for k,v in formal.items()}}
            expr=('canonical',name,self.bound_digest([self.path,n.lineno,self.case,self.stack,inputs]),self.encoded(inputs),self.canonical_sha, self.canonical_index.function_hashes.get(name))
            if name.startswith('_'):expr=('private-canonical',*expr[1:])
            contract=self.shapes.get(name)
            def output(origin,shape):
                if isinstance(shape,dict):
                    value=self.alloc({key:output(('field',origin,key),sub)for key,sub in shape.items()})
                    return Value(origin,ref=value.ref,data=shape)
                return Value(origin,shape=shape)
            result=output(expr,contract)
            self.records.append(self.record(n,'CANONICAL_CALL',actual_binding=path,source_reference=ast.unparse(n.func),inputs=inputs,private=name.startswith('_'),producer_source_sha256=self.canonical_sha,producer_ast_sha256=self.canonical_index.function_hashes.get(name)))
            return result
        if isinstance(fn.function,(ast.FunctionDef,ast.Lambda)):
            return self.invoke(fn,args,kw,n)
        name=path.rsplit('.',1)[-1]
        numeric_path=path.startswith(('mpmath.','decimal.'))
        builtins={'abs','range','dict','set','frozenset','list','tuple','zip','next','sorted','str','max','min','print'}
        library_names={'mpf','Decimal','matrix','diag','eye','inverse','clone','exp','log','log1p','sqrt','det','quad','norm','nstr'}
        if name in library_names and not numeric_path:return self.diagnostic('UNSUPPORTED_CALL_OR_EFFECT',n,callee=path)
        if name in builtins and path!=name:return self.diagnostic('UNSUPPORTED_CALL_OR_EFFECT',n,callee=path)
        if name in ('mpf','Decimal')and args:
            a=args[0]
            if isinstance(a.data,(str,int)) and not isinstance(a.data,bool):
                try:
                    if isinstance(a.data,str):
                        import re
                        parts=re.split('[eE]',a.data)
                        if len(a.data)>4096 or(len(parts)>1 and abs(int(parts[-1]))>4096):raise Budget('EXACT_NUMERIC_SIZE')
                    return Value(('numeric-input',type(a.data).__name__,str(a.data)),Fraction(a.data))
                except ValueError:pass
            return Value(('cast',self.expression(a)),a.data,shape=a.shape)
        if path=='json.loads' and args and isinstance(args[0].data,str):
            try:return self.from_data(json.loads(args[0].data))
            except ValueError:return self.diagnostic('MALFORMED_REFERENCE_DATA',n)
        if name=='range' and all(type(a.data)is int for a in args):
            domain=range(*(a.data for a in args))
            try:cardinality=len(domain)
            except OverflowError:raise Budget('LOOP_DOMAIN')
            if cardinality>LIMITS['loop']:raise Budget('LOOP_DOMAIN')
            self.tick(len(domain));return self.alloc([literal(x)for x in domain])
        if name in ('dict',)and not args:return self.alloc(dict(kw))
        if name in ('set','frozenset','list','tuple'):
            values=self.iterable(args[0],n)if args else[]
            if name in('set','frozenset'):values=list({self.expression_key(self.expression(v)):v for v in values}.values())
            return self.alloc(values)
        if name=='zip':return self.alloc([self.alloc(list(x))for x in zip(*(self.iterable(a,n)for a in args))])
        if name=='next' and args:
            items=self.iterable(args[0],n)
            if len(items)!=1:return self.diagnostic('AMBIGUOUS_REFERENCE_SELECTION',n,count=len(items))
            return items[0]
        if name in ('sorted',)and args:
            items=self.iterable(args[0],n)
            if all(v.data is not None for v in items):
                try:items=sorted(items,key=lambda v:v.data)
                except TypeError:pass
            return self.alloc(items)
        if name=='append' and isinstance(fn.function,tuple):
            obj=fn.function[0];items=self.items(obj)
            if isinstance(items,list):
                self.escaped_callbacks.update(id(arg)for arg in args if arg.function is not None)
                self.tick(len(items)+len(args));self.heap[obj.ref]=items+args;self.versions[obj.ref]+=1;self.heap_epoch+=1;return literal(None)
        if name in ('matrix','diag','eye'):
            if name=='matrix' and len(args)==2 and all(type(a.data)is int for a in args):
                rows,cols=(a.data for a in args)
                if not 0<rows<=16 or not 0<cols<=16:raise Budget('MATRIX_SHAPE')
                return self.alloc([literal(0)for _ in range(rows*cols)],(rows,cols))
            if name=='eye' and args and type(args[0].data)is int:
                k=args[0].data
                if not 0<k<=16:raise Budget('MATRIX_SHAPE')
                return self.alloc([literal(int(i==j))for i in range(k)for j in range(k)],(k,k))
            if args:
                source=args[0];items=self.items(source)
                if name=='matrix' and source.shape:
                    rows,cols=source.shape
                    if not 0<rows<=16 or not 0<cols<=16:raise Budget('MATRIX_SHAPE')
                    return self.alloc([self.lookup(source,(i,j))for i in range(rows)for j in range(cols)],source.shape)
                if isinstance(items,list):
                    if name=='diag':
                        size=len(items);return self.alloc([items[i]if i==j else literal(0)for i in range(size)for j in range(size)],(size,size))
                    nested=[self.items(x)for x in items]
                    if items and all(isinstance(x,list)for x in nested):return self.alloc([v for row in nested for v in row],(len(items),len(nested[0])))
                    return self.alloc(list(items),(len(items),1))
        if name=='inverse' and args:return Value(('inverse',self.expression(args[0])),shape=args[0].shape)
        if name in ('print','dumps','nstr'):return Value(('diagnostic-sink',name))
        if name=='clone':
            key=self.bound_digest([self.path,n.lineno,self.case,self.stack,len(self.numeric_contexts)])
            self.numeric_contexts[key]={}
            return Value(('numeric-context',key))
        if name in ('abs','exp','log','log1p','sqrt','det','quad','max','min','norm'):
            if name=='quad':
                callback=args[0] if args else Value()
                if isinstance(callback.function,(ast.Lambda,ast.FunctionDef)):
                    summary=self.callback_summary(callback,set())
                    if id(callback)in self.escaped_callbacks:
                        self.diagnostic('DEFERRED_CALLBACK_ESCAPE',n,callback=summary)
                        return Value(('unknown','DEFERRED_CALLBACK_ESCAPE',summary))
                    return Value(('oracle',self.path,n.lineno,summary))
            return Value((name,*(self.expression(x)for x in args)),shape=args[0].shape if args else None)
        if name=='str'and args:return literal(str(args[0].data)) if args[0].data is not None else Value(('format',self.expression(args[0])))
        if path.startswith('pytest.raises'):return Value(('refusal-policy',path))
        for arg in args:
            if arg.ref is not None:
                todo=[arg.ref];seen=set()
                while todo:
                    ref=todo.pop();self.tick()
                    if ref in seen:continue
                    seen.add(ref);items=self.heap[ref]
                    values=items.values()if isinstance(items,dict)else items
                    todo.extend(v.ref for v in values if v.ref is not None)
                    self.heap[ref]={k:Value(('unknown','ESCAPED_STORE_EFFECT'))for k in items}if isinstance(items,dict)else[Value(('unknown','ESCAPED_STORE_EFFECT'))for _ in items]
                    self.versions[ref]=self.versions.get(ref,0)+1
                self.heap_epoch+=1
        return self.diagnostic('UNSUPPORTED_CALL_OR_EFFECT',n,callee=path)

    def call_path(self,v):
        e=v.expr
        if e[:1] in (('module',),('builtin',)):return e[1]
        if e[:1]==('numeric-context',):return 'mpmath'
        if e[:1]==('attribute',):return self.call_path(Value(e[1]))+'.'+e[2]
        return ''

    def callback_summary(self,callback,seen):
        self.tick();node=callback.function
        if id(node)in seen:
            self.diagnostic('SCC_CALLBACK_ESCAPE',node)
            return ('unknown','SCC_CALLBACK_ESCAPE')
        seen=seen|{id(node)}
        parameters={p.arg for p in node.args.posonlyargs+node.args.args+node.args.kwonlyargs}
        free={n.id for n in ast.walk(node)if isinstance(n,ast.Name)and isinstance(n.ctx,ast.Load)}-parameters-self.local_bindings(node)
        captured=[]
        for name in sorted(free):
            value=callback.closure.get(name,Value(('unbound',name)))
            summary=self.callback_summary(value,seen)if isinstance(value.function,(ast.FunctionDef,ast.Lambda))else self.expression(value)
            captured.append((name,summary))
        path,sha=self.node_origins.get(id(node),(self.path,self.sha))
        return ('callback',path,sha,syntax(node),tuple((k,self.expression(v))for k,v in sorted(callback.defaults.items())),tuple(captured))

    def from_data(self,data):
        if isinstance(data,dict):return self.alloc({k:self.from_data(v)for k,v in data.items()})
        if isinstance(data,list):return self.alloc([self.from_data(v)for v in data])
        return literal(data)

    def invoke(self,fn,args,kw,site):
        node=fn.function;name=getattr(node,'name','<lambda>')
        if any(isinstance(n,(ast.Global,ast.Nonlocal))for n in ast.walk(node)):return self.diagnostic('SCOPE_WRITE_EFFECT',site,helper=name)
        owner=self.node_origins.get(id(node),(self.path,self.sha))
        label=name if owner[0]==self.path else owner[0]+':'+name
        if fn.closure.get('__unsupported_module_effect__',literal(False)).data is True:return self.diagnostic('UNSUPPORTED_MODULE_EFFECT',site,helper=label)
        self.contexts+=1
        if self.contexts>LIMITS['contexts']:raise Budget('CALL_CONTEXTS')
        if (name in self.recursive and self.function_nodes.get(name)is node)or label in self.stack:return self.diagnostic('SCC_CYCLE',site,helper=label)
        scope=dict(fn.closure);parameters=node.args.posonlyargs+node.args.args
        for local in self.local_bindings(node):scope[local]=Value(('unbound',local))
        all_parameters=parameters+node.args.kwonlyargs
        for parameter in all_parameters:scope[parameter.arg]=Value(('unbound',parameter.arg))
        scope.update(fn.defaults)
        if len(args)>len(parameters)and not node.args.vararg:return self.diagnostic('ARGUMENT_BINDING',site,helper=name)
        bound={parameter.arg for parameter in parameters[:len(args)]}
        for parameter,value in zip(parameters,args):scope[parameter.arg]=value
        extra={};permitted={p.arg for p in all_parameters};posonly={p.arg for p in node.args.posonlyargs}
        for key,value in kw.items():
            if key in bound:return self.diagnostic('DUPLICATE_KEYWORD',site,keyword=key)
            if key in permitted and key not in posonly:scope[key]=value
            elif node.args.kwarg:extra[key]=value
            else:return self.diagnostic('ARGUMENT_BINDING',site,keyword=key)
        missing=[p.arg for p in all_parameters if scope[p.arg].expr[:1]==('unbound',)]
        if missing:return self.diagnostic('ARGUMENT_BINDING',site,helper=name,missing=missing)
        if node.args.kwarg:scope[node.args.kwarg.arg]=self.alloc(extra)
        if node.args.vararg:scope[node.args.vararg.arg]=self.alloc(args[len(parameters):])
        self.stack.append(label)
        self.pending_returns.append([])
        self.call_sites.append({'path':self.node_origins.get(id(site),(self.path,self.sha))[0], 'line':getattr(site,'lineno',None),'helper':label,'helper_source_sha256':owner[1]})
        self.active_refs.append({v.ref for v in list(args)+list(kw.values()) if v.ref is not None})
        try:
            if isinstance(node,ast.Lambda):return self.expr(node.body,scope)
            result,signal=self.block(node.body,scope)
            result=result if signal=='return'else literal(None)
            for prior in self.pending_returns[-1]:result=self.joined(prior,result)
            return result
        finally:
            self.stack.pop(); self.call_sites.pop(); self.active_refs.pop();self.pending_returns.pop()

    def record(self,node,code,**fields):
        return {'schema':SCHEMA,'visibility':RAW,'allowed_numerical_kinds':sorted(STRONG),'scientific_acceptance':'NOT_ESTABLISHED_FOR_CURRENT_SOURCE',
                'record_id':self.bound_digest([self.path,self.current_test,getattr(node,'lineno',0),self.case,self.stack,code,fields]),
                'path':self.path,'source_sha256':self.sha,'line':getattr(node,'lineno',None),
                'assertion_source':{'path':self.node_origins.get(id(node),(self.path,self.sha))[0],'sha256':self.node_origins.get(id(node),(self.path,self.sha))[1],'ast_sha256':digest(syntax(node).encode())},
                'test':self.current_test,'case':self.pack(self.case),'helper_chain':list(self.stack),
                'numeric_contexts':{key:{k:self.pack(self.expression(v))for k,v in values.items()}for key,values in self.numeric_contexts.items()},
                'guards':self.pack(self.guards),'call_sites':self.pack(self.call_sites),'disposition':code,**self.pack(fields)}

    def direct_output_slot(self,expr):
        while isinstance(expr,tuple)and expr:
            if expr[0]in('canonical','private-canonical'):return True
            if expr[0]in('field','cast'):expr=expr[1]
            else:return False
        return False

    def comparison(self,node,a,b,op,contract=None):
        ae,be=self.expression(a),self.expression(b);ad,bd=self.symbols(ae),self.symbols(be)
        code='BOUNDS_ONLY';details={}
        details['tolerance'] = str(b.data) if isinstance(b.data,(int,Fraction)) else None
        details['error_mode'] = None
        if op in ('Is','IsNot') or any(self.representation_expression(x)for x in(ae,be)):code='REPRESENTATION_ONLY'
        elif op in ('Eq','NotEq'):
            if bool(ad)^bool(bd):
                details['actual_operand']=ae if ad else be;details['expected_operand']=be if ad else ae
            code='DIRECT_RESIDUAL_STRUCTURE'if op=='Eq'and bool(ad)^bool(bd)else 'RELATION_ONLY_STRUCTURE'if op=='Eq'and ad|bd else 'BOUNDS_ONLY'
            if self.expression_key(ae)==self.expression_key(be) and ad|bd:code='ORACLE_ALIAS'
        elif op in ('Lt','LtE'):
            # Exact abs(difference) / absolute or relative residual shape.
            residual=ae[1] if ae[:1]==('abs',)and len(ae)==2 else None
            denom=None
            if residual and residual[:1]==('/',):residual,denom=residual[1:]
            if residual:details['error_mode']='relative'if denom is not None else 'absolute'
            if residual and residual[:1]==('-',):
                left,right=residual[1:];ld,rd=self.symbols(left),self.symbols(right)
                if self.expression_key(left)==self.expression_key(right):code='INSENSITIVE_RESULT'
                elif bool(ld)^bool(rd):
                    code='DIRECT_RESIDUAL_STRUCTURE';details['actual_operand']=left if ld else right;details['expected_operand']=right if ld else left
                    if denom is not None and self.symbols(denom):details['relative_conversion']='epsilon/(1-epsilon); finite nonzero canonical denominator and epsilon<1; exact claim budget matching required'
                elif ld|rd:code='ORACLE_CANONICAL_DEPENDENCY'
                else:code='INSENSITIVE_RESULT'
            elif residual and residual[:1] in (('literal',),('number',)):code='INSENSITIVE_RESULT'
        if any(any(self.contains_token(x,t)for t in('unknown','unbound','diagnostic-sink','format','fixture-or-parameter'))for x in(ae,be))and code!='REPRESENTATION_ONLY':
            code='UNSUPPORTED_DEPENDENCY'
        actual=details.get('actual_operand')
        if actual is not None:
            details['sensitivity']='direct-unit-slot'if self.direct_output_slot(actual)else 'source-reviewed-nonconstant-transform-required'
            if details['sensitivity']!='direct-unit-slot'and code=='DIRECT_RESIDUAL_STRUCTURE':code='RELATION_ONLY_STRUCTURE'
        role_questions=[]
        for question in self.questions:
            if question.get('path',self.path)!=self.path or question.get('test',self.current_test)!=self.current_test:continue
            if question.get('line',getattr(node,'lineno',None))!=getattr(node,'lineno',None):continue
            if question.get('call_site_line')and not any(c['line']==question['call_site_line']for c in self.call_sites):continue
            if 'case'in question and self.pack(question['case'])!=self.pack(self.case):continue
            actual=details.get('actual_operand')
            roles=[];todo=[actual];seen=set()
            while todo:
                item=todo.pop();self.tick()
                if not isinstance(item,tuple)or id(item)in seen:continue
                seen.add(id(item))
                if item[:1]==('field',):roles.append(item[2])
                todo.extend(v for v in item if isinstance(v,tuple))
            mismatch=question.get('output')is not None and question['output']not in roles
            if question.get('kind')is not None and question['kind']not in STRONG:self.diagnostic('UNSUPPORTED_REQUESTED_TEST_KIND',node,requested_kind=question['kind'])
            role_questions.append({'question':question,'actual_output_roles':roles,
                                   'status':'OUTPUT_ROLE_MISMATCH'if mismatch else 'STRUCTURAL_ROLE_MATCH_SCIENCE_UNACCEPTED'})
            if mismatch and code in('DIRECT_RESIDUAL_STRUCTURE','RELATION_ONLY_STRUCTURE'):code='OUTPUT_ROLE_MISMATCH'
        details['role_questions']=role_questions
        self.records.append(self.record(node,code,operator=op,actual_expression=ae,expected_expression=be,
                                        formula_ids=sorted(ad|bd),heap_versions={k:self.versions[k] for group in self.active_refs for k in group},contract=contract,**details))

    def assertion(self,node,env):
        expr=node.test
        if isinstance(expr,ast.Compare):
            values=[self.expr(expr.left,env)]+[self.expr(item,env)for item in expr.comparators]
            for index,operator in enumerate(expr.ops):self.comparison(node,values[index],values[index+1],type(operator).__name__)
            if isinstance(expr.left,ast.Name)and isinstance(expr.ops[0],ast.IsNot)and isinstance(expr.comparators[0],ast.Constant)and expr.comparators[0].value is None:
                v=env.get(expr.left.id)
                if v and v.expr[:1]==('phi',):
                    members=[x for x in v.expr[1:]if x!=literal(None).expr]
                    env[expr.left.id]=Value(('phi',*members),shape=v.shape)
        elif isinstance(expr,ast.BoolOp):
            for item in expr.values:self.assertion(ast.Assert(test=item),env)
        else:self.expr(expr,env);self.records.append(self.record(node,'POLICY_OR_UNSUPPORTED_ASSERTION'))

    def block(self,body,env):
        for n in body:
            value,signal=self.statement(n,env)
            if signal:return value,signal
        return literal(None),None

    def statement(self,n,env):
        self.tick()
        if isinstance(n,ast.Import):
            for a in n.names:env[a.asname or a.name.split('.')[0]]=Value(('module',a.name if a.asname else a.name.split('.')[0]))
        elif isinstance(n,ast.ImportFrom):
            members=None if (n.module or '').startswith('src.core.formulas')else self.repository_module(n.module or '')
            for a in n.names:
                if a.name=='*':self.diagnostic('UNSUPPORTED_STAR_IMPORT',n);continue
                env[a.asname or a.name]=members[a.name]if members is not None and a.name in members else Value(('module',(n.module or '')+'.'+a.name))
        elif isinstance(n,(ast.Assign,ast.AnnAssign)):
            v=self.expr(n.value,env)
            for target in n.targets if isinstance(n,ast.Assign)else[n.target]:self.assign(target,v,env)
        elif isinstance(n,ast.AugAssign):
            a=self.expr(n.target,env);b=self.expr(n.value,env);self.assign(n.target,self.operator({ast.Add:'+',ast.Sub:'-',ast.Mult:'*',ast.Div:'/',ast.BitOr:'set-union'}.get(type(n.op),'unknown'),a,b),env)
        elif isinstance(n,ast.Expr):self.expr(n.value,env)
        elif isinstance(n,ast.Assert):self.assertion(n,env)
        elif isinstance(n,ast.Return):return self.expr(n.value,env),'return'
        elif isinstance(n,ast.If):
            condition=self.expr(n.test,env)
            flag=self.truth(condition)
            if flag is not None:
                condition=literal(flag)
            if type(condition.data)is bool:
                dead=n.orelse if condition.data else n.body
                for x in ast.walk(ast.Module(body=dead,type_ignores=[])):
                    if isinstance(x,(ast.Assert,ast.Call)):self.diagnostic('UNREACHABLE_ASSERT',x,guard=syntax(n.test))
                return self.block(n.body if condition.data else n.orelse,env)
            # Persistent branch overlays copy only changed cells. Immutable
            # parent maps are shared, including the large source-reference DATA.
            left,right=dict(env),dict(env);heap0=self.heap;versions0=self.versions
            self.tick(len(env)*2)
            self.heap=ChainMap({},heap0);self.versions=ChainMap({},versions0)
            self.guards.append(syntax(n.test));lv,ls=self.block(n.body,left)
            leftheap=self.heap;leftversions=self.versions
            left_return=Value(self.expression(lv),data=lv.data,shape=lv.shape)if ls=='return'else None
            self.heap=ChainMap({},heap0);self.versions=ChainMap({},versions0);self.heap_epoch+=1
            self.guards[-1]='not '+syntax(n.test);rv,rs=self.block(n.orelse,right)
            rightheap=self.heap;rightversions=self.versions;self.guards.pop()
            right_return=Value(self.expression(rv),data=rv.data,shape=rv.shape)if rs=='return'else None
            if (ls=='return')!=(rs=='return')and (ls is None or rs is None):
                self.pending_returns[-1].append(left_return if ls=='return'else right_return)
                surviving=right if ls=='return'else left
                env.clear();env.update(surviving)
                self.heap=rightheap if ls=='return'else leftheap
                self.versions=rightversions if ls=='return'else leftversions;self.heap_epoch+=1
                return literal(None),None
            def changes(current,base):
                layers=[]
                while current is not base:
                    if not isinstance(current,ChainMap):raise Budget('HEAP_FORK_LINEAGE')
                    layers.append(current.maps[0]);current=current.maps[1]
                result={}
                for layer in reversed(layers):self.tick(len(layer));result.update(layer)
                return result
            lc,rc=changes(leftheap,heap0),changes(rightheap,heap0)
            self.heap=ChainMap({**lc,**rc},heap0)
            self.versions=ChainMap({},versions0);self.heap_epoch+=1
            for ref in lc.keys()|rc.keys():
                a,b=leftheap.get(ref),rightheap.get(ref)
                if a is None or b is None:continue # branch-local fresh identity
                self.tick(1+len(a)+len(b))
                if a is b:continue
                if type(a)is type(b)and(a.keys()==b.keys()if isinstance(a,dict)else len(a)==len(b)):
                    keys=a.keys()if isinstance(a,dict)else range(len(a))
                    merged={k:self.joined(a[k],b[k])for k in keys}
                    self.heap[ref]=merged if isinstance(a,dict)else list(merged.values())
                else:
                    self.diagnostic('BRANCH_HEAP_SHAPE_JOIN',n,reference=ref)
                    self.heap[ref]={}if isinstance(a,dict)else[]
                self.versions[ref]=max(leftversions.get(ref,0),rightversions.get(ref,0))+1
            self.heap_epoch+=1
            for key in set(left)|set(right):env[key]=self.joined(left.get(key,Value(('unbound',key))),right.get(key,Value(('unbound',key))))
            if ls==rs and ls:return self.joined(lv,rv),ls
        elif isinstance(n,ast.For):
            values=self.iterable(self.expr(n.iter,env),n)
            self.records.append(self.record(n,'ITERATION_DOMAIN', iterator=syntax(n.iter),
                                            cardinality=len(values), values=[self.expression(v)for v in values]))
            if isinstance(n.target,ast.Name):
                for access in ast.walk(ast.Module(body=n.body,type_ignores=[])):
                    if isinstance(access,ast.Subscript) and isinstance(access.slice,ast.Tuple):
                        obj=self.expr(access.value,env)
                        if obj.shape:
                            for dimension,key in enumerate(access.slice.elts):
                                if isinstance(key,ast.Name)and key.id==n.target.id and dimension<len(obj.shape):
                                    actual={v.data for v in values if type(v.data)is int}
                                    missing=set(range(obj.shape[dimension]))-actual
                                    if missing:self.diagnostic('INCOMPLETE_PROJECTION',n,dimension=dimension,missing=sorted(missing),shape=obj.shape)

            for v in values:
                self.assign(n.target,v,env);value,signal=self.block(n.body,env)
                if signal=='return':return value,signal
                if signal=='break':break
            else:return self.block(n.orelse,env)
        elif isinstance(n,ast.Break):return literal(None),'break'
        elif isinstance(n,ast.Continue):return literal(None),'continue'
        elif isinstance(n,ast.FunctionDef):
            env[n.name]=self.function_value(n,env)
        elif isinstance(n,ast.With):
            contexts=[self.expr(x.context_expr,env)for x in n.items]
            if any(v.expr[:1]!=('refusal-policy',)for v in contexts):
                self.diagnostic('UNSUPPORTED_WITH_EFFECT',n)
            else:
                self.guards.append(('expected-refusal',syntax(n)))
                self.block(n.body,env);self.guards.pop()
        elif isinstance(n,(ast.Pass,ast.Delete)):
            if isinstance(n,ast.Delete):
                for target in n.targets:
                    if isinstance(target,ast.Name):env[target.id]=Value(('unbound',target.id))
        elif isinstance(n,(ast.Global,ast.Nonlocal)):self.diagnostic('SCOPE_WRITE_EFFECT',n)
        else:self.diagnostic('UNSUPPORTED_STATEMENT',n,operation=type(n).__name__)
        return literal(None),None

    def tests(self, selected=None):
        """Analyze current finite parametrizations without running tests."""
        results={}
        module_heap=self.heap.copy();module_versions=self.versions.copy();module_max_ref=self.next_ref
        def walk(body,classes=()):
            for node in body:
                if isinstance(node,ast.ClassDef):yield from walk(node.body,classes+(node.name,))
                elif isinstance(node,ast.FunctionDef)and node.name.startswith('test_'):yield node,classes
        for fn,classes in walk(self.tree.body):
            if selected is not None and fn.name not in selected:continue
            name='::'.join(classes+(fn.name,));self.current_test=name
            self.steps=self.contexts=0;self.heap=module_heap.copy();self.versions=module_versions.copy();self.heap_epoch+=1;self.case={}
            self.next_ref=max([module_max_ref,*self.repository_heap]);self.expression_nodes={};self.node_cache={};self.dependency_cache={};self.expression_cache={};self.projection_keys=set()
            start=len(self.records);dstart=len(self.diagnostics);cases=[{}]
            for decorator in fn.decorator_list:
                if isinstance(decorator,ast.Call)and self.call_path(self.expr(decorator.func,self.env)).endswith('.parametrize')and len(decorator.args)>=2:
                    keys=self.expr(decorator.args[0],self.env).data
                    if not isinstance(keys,str):self.diagnostic('UNKNOWN_PARAMETRIZATION',decorator);continue
                    keys=[k.strip()for k in keys.split(',')];expanded=[]
                    for v in self.iterable(self.expr(decorator.args[1],self.env),decorator):
                        vals=self.items(v)if len(keys)>1 else[v]
                        if not isinstance(vals,list)or len(vals)!=len(keys):self.diagnostic('PARAMETER_SHAPE',decorator);continue
                        if len(expanded)+len(cases)>LIMITS['cfg_states']:raise Budget('CFG_PARAMETER_CASES')
                        expanded.extend({**case,**dict(zip(keys,vals))}for case in cases)
                    cases=expanded
            parameter_heap=self.heap.copy();parameter_versions=self.versions.copy();work=[]
            if not cases:self.diagnostic('EMPTY_PARAMETRIZATION',fn)
            for params in cases:
                self.steps = self.contexts = 0
                self.heap={**parameter_heap,**self.repository_heap};self.versions={**parameter_versions,**self.repository_versions};self.heap_epoch+=1
                for ref in self.global_poisoned:
                    items=self.heap.get(ref)
                    if items is not None:self.heap[ref]={k:Value(('unknown','GLOBAL_MUTABLE_EFFECT'))for k in items}if isinstance(items,dict)else[Value(('unknown','GLOBAL_MUTABLE_EFFECT'))for _ in items]
                self.tick(len(parameter_heap)*2)
                self.case={k:self.expression(v)for k,v in params.items()};scope=dict(self.env)
                fv=Value(('function',fn.name),function=fn,closure=scope)
                values=[]
                for a in fn.args.args:
                    values.append(params.get(a.arg,Value(('fixture-or-parameter',a.arg))))
                try:self.invoke(fv,values,{},fn)
                except Budget as exc:self.diagnostic('WORK_BUDGET',fn,reason=str(exc))
                work.append({'case':copy.deepcopy(self.case),'units':self.steps,'contexts':self.contexts,'expression_nodes':len(self.expression_nodes),'projection_keys':len(self.projection_keys)})
            # Output DAG has the already-enforced node/size bounds; preserve a
            # terminal budget refusal without trying to resume its counter.
            results[name]={'schema':SCHEMA,'visibility':RAW,'source_sha256':self.sha,'case_count':len(cases),
                           'candidates':self.records[start:],'diagnostics':self.diagnostics[dstart:],
                           'expression_nodes':dict(self.expression_nodes),'expression_nodes_digest':digest(self.expression_nodes),'repository_inputs':dict(self.repository_inputs),'finite_work':work}
        return results


def relative_path(root, name):
    """Reject machine-local and escaping acceptance dependencies."""
    path = Path(name)
    if path.is_absolute():
        raise ValueError('absolute computation evidence path')
    resolved = (Path(root) / path).resolve()
    if not resolved.is_relative_to(Path(root).resolve()):
        raise ValueError('escaping computation evidence path')
    return resolved


def source_closure(root, inputs):
    observed, errors = [], []
    seen = set()
    for row in inputs:
        name = row.get('path', '')
        if name in seen:
            errors.append('DUPLICATE_INPUT:' + name)
        seen.add(name)
        try:
            raw = relative_path(root, name).read_bytes()
            current = digest(raw)
            observed.append({'path': name, 'sha256': current, 'bytes': len(raw)})
            if current != row.get('sha256'):
                errors.append('SOURCE_CLOSURE_MISMATCH:' + name)
        except (OSError, ValueError) as exc:
            errors.append('SOURCE_INPUT_UNAVAILABLE:' + name + ':' + str(exc))
    return observed, errors


def population_projection(root, entry, paper_key=None):
    """Validate existing provenance against separately held canonical review evidence.

    No receipt is created or refreshed here. A ledger entry written by the existing
    closure writer must bind both independent review and ROOT intake digests.
    """
    coverage = entry.get('computation_coverage')
    result = {'schema': SCHEMA, 'visibility': RAW, 'accepted': False,
              'denials': [], 'claims': [], 'obligations': [], 'pairs': [],
              'observed_inputs': [], 'population_digest': None}
    if not isinstance(coverage, dict):
        result['denials'].append('REVIEW_ABSENT_OR_UNACCEPTED')
        return result
    population = coverage.get('population', {})
    result.update(claims=population.get('claims', []), obligations=population.get('obligations', []))
    errors = result['denials']
    try:
        review_ref, intake_ref = coverage['review'], coverage['intake']
        review_path = relative_path(root, review_ref['path'])
        intake_path = relative_path(root, intake_ref['path'])
        review_raw, intake_raw = review_path.read_bytes(), intake_path.read_bytes()
        if not all(str(ref['path']).startswith('papers/AutomatedReviews/') for ref in (review_ref, intake_ref)):
            raise ValueError('review/intake must live in the existing review system')
        if digest(review_raw) != review_ref['sha256'] or digest(intake_raw) != intake_ref['sha256']:
            errors.append('REVIEW_RECEIPT_DIGEST_MISMATCH')
        review, intake = json.loads(review_raw), json.loads(intake_raw)
        if (review.get('verdict') != 'accepted' or review.get('scope') != 'whole-computation-population'
                or not review.get('reviewer') or review.get('reviewer') == review.get('author')
                or intake.get('review_sha256') != digest(review_raw)
                or intake.get('verdict') != 'accepted' or not intake.get('reviewer')
                or intake.get('reviewer') == review.get('author')):
            errors.append('REVIEW_ABSENT_OR_UNACCEPTED')
        expected = review['expected_population']
        result['expected_claims']=expected.get('claims',[])
        result['obligations']=expected.get('obligations',[])
        result['role_questions']=expected.get('role_questions',[])
        if expected.get('schema')!='computation-coverage/v1' or not expected.get('bundle') or (paper_key is not None and expected['bundle']!=paper_key):
            errors.append('SOURCE_UNIVERSE_OR_SCHEMA_MISMATCH')
        versions=expected.get('library_versions',{});result['observed_library_versions']={}
        if not versions:errors.append('LIBRARY_CONTRACT_VERSIONS_UNBOUND')
        for distribution,version in versions.items():
            try:
                result['observed_library_versions'][distribution]=importlib.metadata.version(distribution)
                if result['observed_library_versions'][distribution]!=version:errors.append('LIBRARY_VERSION_MISMATCH:'+distribution)
            except importlib.metadata.PackageNotFoundError:errors.append('LIBRARY_UNAVAILABLE:'+distribution)
        result['library_versions']=versions
        if not expected.get('charter_obligations'):
            errors.append('ORIGINAL_SCIENTIFIC_OBJECTIVE_UNBOUND')
        if expected != population:
            errors.append('POPULATION_OR_BINDING_SET_MISMATCH')
        ledger = json.loads((Path(root) / 'docs/review_finding_supersessions.json').read_text())
        matched = [row for row in ledger.get('supersessions', [])
                   if row.get('finding_id') == review_ref.get('finding_id')]
        if len(matched) != 1:
            errors.append('CANONICAL_REVIEW_ACCEPTANCE_UNRECORDED')
        else:
            row = matched[0]
            if (row.get('status') not in ('fixed', 'accepted')
                    or row.get('superseded_by') != review_ref['path']
                    or digest(review_raw) not in row.get('evidence', '')
                    or digest(intake_raw) not in row.get('evidence', '')):
                errors.append('CANONICAL_REVIEW_ACCEPTANCE_UNRECORDED')
        observed, freshness = source_closure(root, expected.get('inputs', []))
        result['observed_inputs'] = observed
        errors.extend(freshness)
        result['population_digest'] = digest(expected)
        if intake.get('population_digest') != result['population_digest']:
            errors.append('INTAKE_POPULATION_MISMATCH')
        # Complete source coverage, including excluded prose/markup, is reviewed.
        input_paths = {row['path'] for row in expected.get('inputs', [])}
        required_roles={'manuscript','metadata','charter','producer','analyzer','library','test','oracle'}
        roles={row.get('role')for row in expected.get('inputs',[])}
        actual_analyzer=digest(Path(__file__).read_bytes())
        if not any(row.get('path')=='scripts/computation_analysis.py'and row.get('role')=='analyzer'and row.get('sha256')==actual_analyzer for row in expected.get('inputs',[])):
            errors.append('ANALYZER_SOURCE_MISMATCH')
        errors.extend('MISSING_SOURCE_ROLE:'+role for role in sorted(required_roles-roles))
        inventory=expected.get('inventory',[])
        if not inventory:errors.append('CURRENT_INVENTORY_UNASSESSED')
        inventory_paths=set()
        for group in inventory:
            directory=relative_path(root,group['directory'])
            actual=sorted(p.relative_to(Path(root)).as_posix()for p in directory.rglob(group['pattern'])if p.is_file())
            if actual!=sorted(group['paths']):errors.append('CURRENT_INVENTORY_MISMATCH:'+group['directory'])
            inventory_paths.update(actual)
            excluded={r['path']for r in group.get('excluded',[])if r.get('reason')}
            if set(actual)-input_paths-excluded:errors.append('INVENTORY_MEMBER_UNASSESSED:'+group['directory'])
        test_paths={row['path']for row in expected.get('inputs',[])if row.get('role')=='test'}
        if not test_paths or not test_paths<=inventory_paths:errors.append('TEST_SOURCE_ROSTER_UNASSESSED')
        documents = expected.get('documents', [])
        if not documents:
            errors.append('DOCUMENT_CLOSURE_UNASSESSED')
        for document in documents:
            name = document['path']
            raw = relative_path(root, name).read_bytes()
            if name not in input_paths:
                errors.append('UNPINNED_DOCUMENT:' + name)
            offset = 0
            for segment in document.get('partition', []):
                start, end = segment['start'], segment['end']
                if start != offset or not start <= end <= len(raw):
                    errors.append('SOURCE_PARTITION_INCOMPLETE:' + name)
                if digest(raw[start:end]) != segment.get('sha256'):
                    errors.append('SOURCE_SEGMENT_MISMATCH:' + name)
                if segment.get('kind')not in('claim','numerical','nonclaim'):errors.append('SOURCE_SEGMENT_KIND_UNASSESSED:'+name)
                if segment.get('kind')in('claim','numerical')and not segment.get('claims'):errors.append('SOURCE_SEGMENT_CLAIM_UNBOUND:'+name)
                if segment.get('kind') == 'nonclaim' and not segment.get('reason'):
                    errors.append('UNREVIEWED_NEGATIVE_DISPOSITION:' + name)
                offset = end
            if offset != len(raw): errors.append('SOURCE_PARTITION_INCOMPLETE:' + name)
            # Literal referenced companions belong to the same accepted closure.
            if name.endswith('.tex'):
                import re
                for target in re.findall(r'\\(?:input|include|includegraphics)(?:\[[^]]*\])?\{([^}]+)\}', raw.decode()):
                    base = str((Path(name).parent / target).as_posix())
                    candidates = [base] if Path(base).suffix else [base + ext for ext in ('.tex', '.pdf', '.png', '.svg')]
                    present = [candidate for candidate in candidates if relative_path(root, candidate).is_file()]
                    if len(present) != 1 or present[0] not in input_paths:
                        errors.append('COMPANION_CLOSURE_MISMATCH:' + base)
        ids, keys, obligations = set(), set(), {x['id']: x for x in expected.get('obligations', [])}
        document_map={d['path']:d for d in documents}
        for oid,obligation in obligations.items():
            if any(k not in obligation for k in('quantity','outputs','units','inputs','domain','budget','oracle','cells','original_build')):
                errors.append('SCIENTIFIC_OBLIGATION_INCOMPLETE:'+oid)
            if not obligation.get('cells')or len({digest(c)for c in obligation.get('cells',[])})!=len(obligation.get('cells',[])):
                errors.append('OBLIGATION_DOMAIN_MEMBERSHIP_UNASSESSED:'+oid)
            oracle=obligation.get('oracle',{})
            if not isinstance(oracle,dict)or not oracle.get('scientific_review')or not set(oracle.get('source_paths',[]))<=input_paths:
                errors.append('ORACLE_SCIENCE_OR_SOURCE_UNACCEPTED:'+oid)
            else:
                ref=oracle['scientific_review']
                if not isinstance(ref,dict):errors.append('ORACLE_REVIEW_RECEIPT_MALFORMED:'+oid)
                else:
                    raw=relative_path(root,ref['path']).read_bytes();accepted=json.loads(raw)
                    if (ref['path']not in input_paths or digest(raw)!=ref['sha256']
                        or accepted.get('verdict')!='accepted' or accepted.get('scope')!='scientific-oracle-contract'
                        or not accepted.get('reviewer')or accepted.get('reviewer')==accepted.get('author')
                        or accepted.get('contract')!=oracle.get('contract')
                        or accepted.get('source_paths')!=oracle.get('source_paths')):
                        errors.append('ORACLE_CONTRACT_STALE_OR_UNACCEPTED:'+oid)
            if not isinstance(obligation.get('domain'),dict)or (obligation['domain'].get('kind')!='finite'and not obligation['domain'].get('representativeness_contract')):
                errors.append('DOMAIN_REPRESENTATIVENESS_UNESTABLISHED:'+oid)
            if any(k not in c for c in obligation.get('cells',[])for k in('output','case','units','basis')):
                errors.append('SCIENTIFIC_CELL_UNDERSPECIFIED:'+oid)
        if len(obligations) != len(expected.get('obligations', [])):
            errors.append('DUPLICATE_OBLIGATION_ID')
        identity = expected.get('identity_map', {})
        for claim in expected.get('claims', []):
            key, cid = claim['key'], claim['id']
            if cid in ids or key in keys: errors.append('DUPLICATE_CLAIM_IDENTITY')
            ids.add(cid); keys.add(key)
            if ':q:'in cid and cid!=f"claim:{expected['bundle']}:q:{key}":errors.append('STABLE_CLAIM_KEY_MISMATCH:'+cid)
            if claim.get('disposition')not in('quantitative','noncomputational','unresolved-build'):errors.append('CLAIM_DISPOSITION_UNASSESSED:'+cid)
            if claim.get('disposition')in('quantitative','unresolved-build')and not claim.get('obligations'):errors.append('QUANTITATIVE_CLAIM_WITHOUT_OBLIGATION:'+cid)
            if claim.get('disposition')=='noncomputational'and not claim.get('reason'):errors.append('NEGATIVE_SCIENTIFIC_DISPOSITION_UNASSESSED:'+cid)
            if ':q:'not in cid:
                old=identity.get(cid,{})
                if (old.get('status')!='preserved'or old.get('current_id')!=cid
                        or old.get('key')!=key or old.get('old_text_sha256')!=digest(claim['text'].encode())):
                    errors.append('LEGACY_CLAIM_IDENTITY_UNBOUND:'+cid)
            for occurrence in claim.get('occurrences', []):
                name = occurrence['path']; raw = relative_path(root, name).read_bytes()
                start,end=occurrence['start'],occurrence['end']
                if not 0<=start<end<=len(raw):errors.append('CLAIM_SPAN_INVALID:'+cid)
                segments=document_map.get(name,{}).get('partition',[])
                if not any(g['start']<=start<end<=g['end']and cid in g.get('claims',[])for g in segments):errors.append('CLAIM_PARTITION_MEMBERSHIP_MISMATCH:'+cid)
                if name not in input_paths or digest(raw[start:end]) != occurrence['sha256']:
                    errors.append('CLAIM_OCCURRENCE_MISMATCH:' + cid)
            if not claim.get('occurrences'): errors.append('CLAIM_OCCURRENCE_UNASSESSED:' + cid)
            for oid in claim.get('obligations', []):
                if oid not in obligations: errors.append('MISSING_OBLIGATION:' + oid)
        for document in documents:
            for segment in document.get('partition',[]):
                if set(segment.get('claims',[]))-ids:errors.append('UNKNOWN_PARTITION_CLAIM:'+document['path'])
        preserved=[]
        for index,text in enumerate(entry.get('key_claims',[])):
            old_id=f"claim:{expected['bundle']}:{index}";old=identity.get(old_id,{})
            if old.get('old_text_sha256')!=digest(text.encode())or old.get('source_path')not in input_paths:
                errors.append('LEGACY_IDENTITY_HISTORY_UNBOUND:'+old_id)
            if old.get('status')=='preserved':
                preserved.append(old.get('current_id'))
                if old.get('current_id')not in ids:errors.append('LEGACY_IDENTITY_TARGET_ABSENT:'+old_id)
            elif old.get('status')!='retired'or not old.get('reason'):errors.append('LEGACY_IDENTITY_DISPOSITION_MISSING:'+old_id)
        if len(preserved)!=len(set(preserved)):errors.append('NONBIJECTIVE_LEGACY_CLAIM_IDENTITY')
        pairs = []
        for binding in expected.get('bindings', []):
            oid, cid, name = binding['obligation'], binding['claim'], binding['formula']
            if cid not in ids or oid not in obligations:
                errors.append('BINDING_MEMBERSHIP_MISMATCH:' + oid)
            elif oid not in next(c for c in expected['claims'] if c['id']==cid).get('obligations', []):
                errors.append('CLAIM_OBLIGATION_MISMATCH:' + oid)
            if binding.get('source_path')not in input_paths or not binding.get('producer_ast_sha256'):errors.append('PRODUCER_DEPENDENCY_IDENTITY_UNBOUND:'+oid)
            else:
                producer_source=relative_path(root,binding['source_path']).read_text()
                definitions=[f for f in ast.parse(producer_source).body if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef))and f.name==name]
                if (binding['source_path']!='src/core/formulas.py'or str(name).startswith('_')or len(definitions)!=1
                    or digest(syntax(definitions[0]).encode())!=binding['producer_ast_sha256']):errors.append('PRODUCER_SOURCE_IDENTITY_MISMATCH:'+oid)
            pairs.append({'claim': cid, 'formula': 'formula:' + name, 'obligation': oid})
        if len({(x['claim'],x['formula'],x['obligation']) for x in pairs}) != len(pairs):
            errors.append('DUPLICATE_SUPPORT_PAIR')
        result['pairs'] = pairs
        bound = {x['obligation'] for x in pairs}
        errors.extend('UNBOUND_OBLIGATION:' + oid for oid in obligations if oid not in bound)
        if sorted(set(entry.get('formulas', []))) != sorted({x['formula'].removeprefix('formula:') for x in pairs}):
            errors.append('FORMULA_PROJECTION_MISMATCH')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors.append('MALFORMED_OR_UNAVAILABLE_ACCEPTANCE:' + str(exc))
    result['accepted'] = not errors
    return result


def project_witnesses(projection, analyses, root):
    """Only reviewed exact per-obligation current candidates produce strong edges."""
    out, missing = [], []
    if not projection.get('accepted'):
        return out, [*projection.get('denials', [])]
    records = {record['record_id']: record for test in analyses for record in test.get('candidates', [])}
    for obligation in projection.get('obligations', []):
        witnesses = obligation.get('witnesses', [])
        matches = [];covered_cells=set()
        required_cells={digest(cell)for cell in obligation.get('cells',[])}
        for question in witnesses:
            record = records.get(question.get('record_id'))
            if not record: continue
            if (record['visibility'] != RAW or record['source_sha256'] != question.get('source_sha256')
                    or record['disposition'] not in ('DIRECT_RESIDUAL_STRUCTURE','RELATION_ONLY_STRUCTURE')
                    or question.get('kind') not in STRONG):
                continue
            fields = ('actual_expression','expected_expression','case','guards','helper_chain','formula_ids','numeric_contexts')
            if any(question.get(key) != record.get(key) for key in fields): continue
            if any(key not in obligation for key in ('quantity','outputs','units','inputs','domain','budget','oracle')): continue
            if question.get('obligation_digest') != digest({k:v for k,v in obligation.items() if k!='witnesses'}): continue
            if question.get('relation_scope') != obligation['outputs']: continue
            required_formulas={p['formula'].removeprefix('formula:')for p in projection.get('pairs',[])if p['obligation']==obligation['id']}
            if not required_formulas or not required_formulas<=set(record.get('formula_ids',[])):continue
            if record.get('disposition')=='RELATION_ONLY_STRUCTURE':
                transform=question.get('sensitivity_contract',{})
                if (not isinstance(transform,dict)or transform.get('kind')!='source-reviewed-nonconstant-transform'
                    or not transform.get('evidence_paths')or transform.get('domain')!=obligation.get('domain')):continue
                if question.get('kind')=='golden'and record.get('sensitivity')!='source-reviewed-nonconstant-transform-required':continue
            if record.get('tolerance') is None:
                if obligation['budget'].get('kind')!='exact'or obligation['budget'].get('value')!='0':continue
            if record.get('tolerance') is not None:
                try:
                    epsilon=Fraction(record['tolerance'])
                    required=Fraction(obligation['budget']['value'])
                    if record.get('relative_conversion'):
                        if not 0<epsilon<1:continue
                        epsilon=epsilon/(1-epsilon)
                    if obligation['budget']['kind'] != record.get('error_mode') or epsilon>required:continue
                except (KeyError,ValueError,TypeError,ZeroDivisionError):continue
            if record.get('relative_conversion') and question.get('relative_conversion') != record['relative_conversion']: continue
            if record.get('relative_conversion')and question.get('denominator_contract')not in('finite-nonzero-canonical','reviewed-symmetric-relative'):continue
            if record.get('relative_conversion')and not question.get('nonzero_domain'):continue
            if question.get('oracle_contract')!=obligation['oracle']:continue
            if any('expected-refusal'in str(g)for g in record.get('guards',[])):continue
            members=question.get('cells',[])
            member_ids={digest(cell)for cell in members}
            if not member_ids or not member_ids<=required_cells:continue
            if any(cell.get('case')!=record.get('case')for cell in members):continue
            analysis=next((test for test in analyses if record in test.get('candidates',[])),{})
            if question.get('expression_nodes_digest')!=analysis.get('expression_nodes_digest'):continue
            accepted_inputs={row['path']:row['sha256']for row in projection.get('observed_inputs',[])}
            if any(accepted_inputs.get(path)!=sha for path,sha in analysis.get('repository_inputs',{}).items()):continue
            if any(d.get('code')=='WORK_BUDGET'and d.get('case')==record.get('case')for d in analysis.get('diagnostics',[])):continue
            if record.get('role_questions')and any(q['status']=='OUTPUT_ROLE_MISMATCH'for q in record['role_questions']):continue
            covered_cells.update(member_ids)
            # No body/name/taint proxy grants oracle acceptance: the complete
            # independently reviewed obligation and exact record are pinned.
            matches.append({'record_id':record['record_id'],'path':record['path'],'test':record['test'],
                            'kind':question['kind'],'obligation':obligation['id'],
                            'population_digest':projection['population_digest'], 'source_sha256': record['source_sha256'],
                            'cells':members,'expression_nodes_digest':analysis.get('expression_nodes_digest'),
                            'witness_digest':digest(question)})
        if not matches or covered_cells!=required_cells or not required_cells:
            missing.append('UNCOVERED_OBLIGATION:' + obligation['id'])
            matches=[]
        out.extend(matches)
    return out, missing
