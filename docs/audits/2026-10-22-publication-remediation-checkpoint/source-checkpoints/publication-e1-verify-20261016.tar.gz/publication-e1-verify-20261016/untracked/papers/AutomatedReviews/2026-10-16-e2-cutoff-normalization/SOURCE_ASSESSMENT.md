# Cutoff normalization source assessment

At the pinned db72be9d baseline, the canonical function is sqrt(kappa*c_s/l_disp). The current Dean platform has kappa=2e12/s, c_s=4.4e5m/s and derived l_ee=50.92155051718431nm. Its temperature defines omega_H=kappa/(2pi). These give cutoff=4.1571005250476255e12/s, cutoff/omega_H=13.059916469723891 and adopted relative suppression (4 omega_H/cutoff)^2=9.380785038734933%. The fixed 51nm test fixture instead gives 13.049868058050327 and 9.395237028653139%; rounding does not explain 7.8.

Two independent source assessments agree. A stdlib reconstruction reproduces all 300 archived Fig104 thermal/Hawking/total trace points within floating precision. The numerical model and figure data are retained. This is no new evidence of physical transfer or calibrated detection.

The prior comment-based claims record and hardcoded (4/7.8)^2 receipt remain historical evidence of the defect's propagation. Their numerical acceptance is superseded within this finding's scope; their unrelated source/qualification improvements remain intact. The initial unexecuted proposed test band copying 7.8 was rejected by lead arithmetic review and preserved in ignored evidence.

Pre-application independent review accepted the exact-root fixture and ratio convention, required the touched comment to use Gamma0=0.99994 or omit it, and approved the canonical docstring update qualified to the encoded Dean/adopted model. The new 4 omega_H edge is about 202.64GHz and implies the old 85GHz inequality.

Actual baseline/red, focused execution and source/preservation records are captured separately; their execution is not asserted by this pre-implementation assessment. A fresh post-implementation review must inspect the exact source diff and raw results. The package does not mark stages green or close findings.

## Actual focused execution

The new finding's exact recomputation Verify was run before production edits and exited 1 specifically on the old manuscript cutoff claim, after printing the actual model ratio and suppression. The same command after the correction exited 0 and also checked the actual spectrum endpoint against the adopted graybody evaluator. Source origins were the isolated db72 candidate. Fixed-input and production-derived-input calculations remain distinct.

The named cutoff, graybody, physical-consistency, dimensional-consistency and spectrum-computation controls executed with 20 passed in 0.10 seconds. They used the existing interpreter, disabled pytest plugin autoload and cache, and created no seed journal. All 5,108 tracked candidate file bytes were unchanged by those runs. Non-docstring executable ASTs of formulas.py and wkb_spectrum.py match the original db72 source exactly.

The cutoff comment also corrects Gamma0 rounding to 0.99994, as required by independent pre-application review; no SNR estimate is asserted by the new comment. The canonical docstring now states that the calculation is under an adopted cutoff ansatz rather than establishing physical validity in graphene.

Original raw baseline/current Verify streams, actual commands/environments/source hashes, named pytest results and preservation evidence are retained in the primary ignored publication-e2-cutoff-implementation-20261016-r1 evidence directory. An initial continuity request used a candidate roadmap where the adapter requires a primary reference; its failure is retained, and the corrected packet/check passed before any production edit. An initial Verify draft failed syntax parsing before execution; that draft was preserved and the corrected command was parsed before baseline measurement. Neither preparation failure is represented as the scientific red baseline.

No compile, full claims workflow, derived-count regeneration, shared ledger write, Git delivery or whole-stage acceptance occurred. The extra test function may require the existing ROOT count writer later. All earlier erroneous review and closure records remain unchanged; lifecycle reconciliation of the old 26.3 literal is separate.
