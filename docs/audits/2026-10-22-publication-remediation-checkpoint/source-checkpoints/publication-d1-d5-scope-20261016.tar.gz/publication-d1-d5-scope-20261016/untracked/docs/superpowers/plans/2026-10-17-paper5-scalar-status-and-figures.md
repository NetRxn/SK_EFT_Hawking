# Paper 5 scalar status and Figures 4–5 implementation plan

**PROPOSED BOUNDED IMPLEMENTATION PLAN, DESIGN ONLY.** Exact proposed postimage of `docs/superpowers/plans/2026-10-17-paper5-scalar-status-and-figures.md`. Read the companion contract and exact existing ROOT grant first. No source code, test, pilot, rendering, registration probe or compiler has been run by this corrective design author. No ADR number or full-machinery acceptance is inferred.

**Installation status:** installed by the publication lead at 2026-10-17T05:16:21.077988+00:00 as the reviewed bounded implementation contract under the existing ROOT grant. Accepted design proposal SHA256 044393c666d4bcdf221ac7c6af44a4ac9ea0fad0a081cd88bac40ea481bdbbf3; accepted plan proposal SHA256 96625b4c283f5b4b0b09f3ef97519911381be86a9fb016f0d31daeceb8d2c403. Independent corrective science review SHA256 502afbb8c9ce1b346ca691c26e02ecc5d0aae3df1af536564da24535c53f773f; separate corrective intent review SHA256 7bc6e512d8ccf38ae2fd661e232457b88414fd260fbdcdc774457b1f15c12463. This records actual document installation before source implementation; it does not establish executed tests, physical validity, full architecture settlement or publication acceptance.

## Global constraints

After separate science/adversarial and intent reviews resolve mandatory issues, the lead installs the reviewed docs and implements the coherent unit under the existing ROOT grant; no further routine ROOT admission is required. Keep the canonical scalar potential, absolute guard, derivative, G_c, threshold convention, bounded optimizer method/objective/bounds/options, positive cutoff and energy comparison unchanged. No new stationarity epsilon or numerical solver is authorized. The real 100-row outcome remains unknown. Preserve existing NJL/source/formulas, M3 tests, Eq9, other visualizers, notebooks and three PNGs. Use the six source paths and two doc paths only. The exact preimages and deferred caller roster are in this proposal's evidence, not an instruction to copy whole files from another branch.

## File/task map

| File | Coherent change | Preservation/check |
|---|---|---|
| `src/adw/gap_equation.py` | Add trailing result status/diagnostics; validate intended scalar domain and report unresolved/nonselected outcomes; qualify legacy labels | Existing signatures/fields, formulas and minimizer decisions unchanged; normal subcritical/r=2 compatibility and actual controlled-minimizer tests |
| `src/adw/fluctuations.py` | Qualify assigned component/spin/mass interpretation in directly coupled docs/descriptions | Every count expression, enum value, numeric flag, public signature and structural-obstacle body unchanged |
| `src/core/visualizations.py` | Change only `fig_adw_phase_diagram` and `fig_adw_ng_mode_decomposition` | All other definitions exact against c475; Fig29 actual status-driven rows; Fig30 exact category/count pairing; both visible complete qualifications |
| `scripts/review_figures.py` | Extend existing two FigureSpecs and actual structural call with small selected consistency helper | Registry/maps/generic checks preserved; `physics_checks` strings remain prompts, not executable assertions |
| `tests/test_adw.py` | Append focused helper, producer and real review-seam tests below; correct only directly coupled descriptions if needed | All existing test bodies/assertions, M3 stationarity budgets, NJL tests and unrelated assertions remain exact |
| `papers/paper5_adw_gap/paper_draft.tex` | Qualify VI/VII and the two captions per D5 | Display math exact; Eq9 and all text outside those sections unchanged; no abstract/conclusion expansion |
| The named spec and plan | Settle reviewed contract and record later evidence without invented status | No unallocated architecture doc or ADR-number creation |

## 1. Review, re-pin and apply source unit

The lead receives the frozen corrective author artifacts and both separate reviews. Before implementation recheck the original allocation and candidate bytes; reconcile any actual preimage drift through the existing process rather than refreshing away this author packet or transplanting whole files. The grant already permits routine equivalent-detail resolution and installation of reviewed doc postimages before source code; no new doc-ownership/ADR approval step is imposed and no ADR number is assigned. Implementation should keep named decisions D1–D5 together because a status field unused by its selected consumer would leave the defect live.

Implement the helper first, then selected consumers and the existing review call, then paper/description wording. Retain raw optimizer diagnostics and distinguish actual no-search zero from unresolved supercritical results. Do not add a second check registry or allow an empty selected roster to pass. Keep the existing public API plus additive defaulted result fields; record all caller effects in the concise roster. Other producer/notebook caller migration remains explicitly deferred.

## 2. Focused tests of actual helper and consumers

Add tests in the existing `tests/test_adw.py`; no parallel validation framework. Tests must call the actual production helper/producer/review function. Controlled minimizer returns exercise its outcomes without claiming numerical validation. A monkeypatch of `minimize_scalar` is a fixture seam; label it accordingly, not a production-seeded mutation.

| Control | Required observation |
|---|---|
| Valid subcritical and exact represented equality | No minimizer call; real result has `threshold_zero`, false search flag, zero candidate, preserved legacy phase; actual producer plots zero only for these statuses |
| Actual successful finite selected candidate | Original callable/method/bounds/options are inspected by a minimizer spy; real helper selects only original negative-energy comparison; actual producer uses reported C/Lambda unchanged |
| False optimizer success, missing x/fun on failure | Real helper returns `unresolved_optimizer`; actual producer refuses with row/ratio/status; no genuinezero or partial figure |
| Successful but nonselected candidate (positive and exactly zero fun) | Legacy candidate can remain present; status is `unresolved_nonselection`; actual producer must not plot it as selected or zero |
| Nonfinite x/fun; finite out-of-window or below-cutoff candidate | Explicit unresolved candidate; no successful plotted result. Test both bound directions and cutoff equality |
| Exact lower/upper bound selected report | Finite candidate remains a qualified endpoint bounded candidate, metadata reflects exact relation; no invented stationarity threshold |
| Missing success or successful report missing x/fun; boolean/nonscalar/malformed present fields | Defined missing-field/protocol failures remain visible; never catch to a success |
| Invalid supplied domain | bool, non-real/nonscalar, nonfinite/nonpositive inputs and unrepresentable derived ratio/bounds refuse explicitly; do not silently turn positive input into zero |
| Optimizer/objective/tetrad exception | Actual exception propagates; the producer does not fabricate a zero or a successful figure |
| Missing result or legacy result without added metadata | Actual selected producer rejects the unsupported result; additive constructor compatibility is not figure acceptance |
| Mixed controlled rows through the real Fig29 | Keep actual 100-point ratios, Lambda=1/N_f=4 and exactly paired trace/meta evidence; one unresolved row refuses construction, no filtering/zero fill |
| Real Fig30 with unmodified actual classifier | Exact ID/count/order pairing and 16 total; assigned labels/metadata and complete qualification |
| Missing/duplicate/wrong-category count, bool/noninteger/negative or swapped counts | Actual producer/review seam rejects, even if a sorted multiset and generic finite-data check would pass |
| Real `run_structural_checks` route restricted to selected real spec in the test | It calls the actual selected producer, then the added helper, and emits ordinary errors for mutated row pairing, branch/status and category pairing. Restore registry after test; no production roster change |
| Remove only 'not' or another load-bearing clause from visible qualification | The complete-sentence check fails. A few surviving keywords cannot pass; line-break/whitespace-only variants can pass |

Use positive controls for both selected specs and a known-bad instance for every predicate. A test that deletes all mathematics, drops every row, changes the expected count to the observed count or asserts only a disclosure word is not sufficient. Tests of conditional category bookkeeping do not establish a physical spectrum. Preserve existing real numerical correspondence tests and the separate r=2 stationarity test; do not generalize its prior tolerance to all 100 ratios.

The exact currently authorized prospective selector roster, using the existing admitted interpreter and candidate-origin/cache boundary, is:

```text
-X pycache_prefix=<unique-initially-empty-run-directory> -B -m pytest -q \
  tests/test_adw.py::TestScalarStatusControlled \
  tests/test_adw.py::TestPaper5SelectedFiguresControlled \
  tests/test_adw.py::TestPaper5SelectedReviewControlled \
  tests/test_adw.py::TestNGModeClassification \
  tests/test_adw.py::TestVergelesModeCounting
```

Before this selected command, preflight the candidate's existing `.seed-journal` as absent or empty. The existing `tests/conftest.py` session-autouse fixture calls the candidate journal's repair routine; preserve that fixture. A populated/orphan journal needs its existing writer's reconciliation before this bounded run, so the test command does not perform an unallocated repair. Do not disable or replace normal fixtures. Use the existing admitted interpreter with the candidate as cwd, source-origin guards before canonical imports and an actually unique, initially empty pycache-prefix directory supplied in interpreter argv as shown, retaining `-B`. The angle-bracket path is a prospective runtime location to record, not a fabricated command receipt. These are bounded execution conditions under the existing grant, not a new framework or routine approval gate.

The first three are the planned new classes appended in the allocated test file; the last two are exact existing pure category-control classes. Do not substitute the whole module or broader GL/vestigial suites. All new classes use a shared autouse guard fixture that makes unexpected real `gap_equation.minimize_scalar` and potential/derivative evaluation fail immediately. Each case explicitly replaces the minimizer with a controlled return/exception or spy without evaluating the production potential. For the required objective-exception control only, the controlled minimizer may invoke the objective callable after the potential dependency is replaced with a sentinel that raises the expected exception; no actual potential evaluation is permitted. Real helper state/selection and the real selected producers still execute; fixtures do not become mathematical or physical oracles.

The real review-route test also restricts the registry to the two actual selected specs and guards background execution. Source shows that `run_structural_checks` eagerly constructs three transonic backgrounds before registry dispatch. Its local-imported `steinhauer_Rb87`, `heidelberg_K39`, `trento_spin_sonic` and `solve_transonic_background` dependencies must be patched at their actual source-module attributes to controlled sentinels/spies, restoring after each test. Unexpected real model solver calls fail; the selected producers and the actual structural function/helper call remain real. Assert the selected path is nonempty and record that background preparation was controlled, not validated. This is an existing test fixture seam, not a new workflow or a production-seeded claim.

These selected controls are already authorized after reviewed doc installation and implementation by the existing grant; no second routine admission is required. They are prospective, not pass receipts. Preserve all existing real minimizer/correspondence, r=2 stationarity, GL/vestigial and numerical compatibility tests unchanged for their later separately admitted numerical/model interval; controlled fixtures neither execute nor discharge those obligations. The full review script `--check` also belongs to a later wider producer/runtime/write interval: it generates real models and writes `structural_checks.json`. Do not run it as a source-only probe or pretend manifest strings execute.

## 3. Production-seeded red, exact restoration, green

Before shipping the new selected assertions, ROOT allocates an exclusive ordinary candidate interval and the existing `seed_journal` path. Seed the candidate's real production source, not a copied fixture or this proposal. Journal exact bytes and mtime, run a fresh admitted child through the real existing review seam, observe the intended error, restore through the journal, and observe green on the same assertion. Verify source hashes/mtime restoration even on failure. Never seed primary or another worker's tree, and never promote a cache or graph from this interval.

Use two bounded defects: (a) alter the real Fig29 producer's emitted row/trace pairing or zero/status encoding so the actual selected consistency check sees an unresolved supercritical/zero mismatch while generic finite-data/axis/trace checks can pass; (b) remove the load-bearing negation from the real Fig30 visible qualification. The real check's positive assertion must fail in the seeded child and succeed after exact restoration. A separate category-pairing source mutation is useful if (a) cannot be seeded without short-circuiting construction; choose and record the actual source anchor before seeding. Do not manufacture a numerical tolerance or claim stationarity from these controls. Controlled minimizer fixtures may keep this test bounded but cannot replace the real production artifact mutation or the actual check call.

Fresh execution must use ROOT's admitted existing interpreter and verified candidate source origin, with a unique initially empty pycache prefix in actual argv and bytecode writes disabled before canonical imports; a raw source SHA or `-B` alone is not proof of fresh code. Retain actual command, loaded source origin, row/issue output, exit status and journal restoration receipts. If a runtime boundary or source mutation is unadmitted, leave this obligation open; do not call fixture tests production-seeded evidence.

## 4. Registration, owning documents, preservation

The selected FigureSpecs and both existing function maps are already present; preserve them and demonstrate a nonempty selected path. Before shipping, run the architecture skill's live `registration_sites.py` probe for the actual touched check surface, record its applicability and reconcile every reported site. The small private helper is not a new validate.py gate; do not invent check names/ceilings or an unsupported 'registered' claim. If implementation instead creates a new registered check, ROOT must amend scope and satisfy its real registration/owner-document obligations first.

Re-read `END_TO_END_MAP.md` and `VALIDATION_ARCHITECTURE.md` §6. Their statements about inert manifest strings and missing physical certification remain true under this design. They must not be rewritten as physical validation. If another statement becomes false, obtain ROOT's explicit scope amendment for the owning doc and correct it in the same shipping unit. The named spec/plan are not substitutes for that obligation.

Static preservation evidence must compare full final pre/postimages, not merely diff line totals: only the two selected visualizer definitions differ against c475; all other visualizer definitions remain exact; potential/derivative/critical computation and other canonical sources remain exact; fluctuation arithmetic/enum/numeric data remain exact; old test bodies/assertions remain exact; all TeX display-math blocks remain exact, Eq9 and outside-VI/VII bytes remain exact; three PNGs, notebooks, NJL artifacts and other 17-path composed units remain exact. Preserve existing registrations/import behavior unless the explicit bounded helper integration needs a local test import. Any unexpected delta requires reconciliation before source acceptance.

## 5. Later actual row review, figure admission and safe checkpoint

ROOT owns the later actual 100-row scan and row-disposition manifest, selected exports, independent scientific/data and pixel reviews, actual paper5 compilation and promotion. Do not turn generation failure into an empty PNG or delete unresolved rows to obtain a render. If the original numerical search produces an unresolved row, keep the figure unpromoted and bring that concrete numerical question to ROOT as a separately scoped decision; no numerical fix is authorized by this source unit. Finite selected rows still need their restricted interpretation and stationarity remains unevaluated by this implementation.

Keep the three existing PNGs exact. Fig29/30 need separate raw export hashes, independent full/column-size visual review, correct source origins and figure/caption agreement before promotion. Use the repository's admitted canonical compilation route; do not run an in-place TeX build. Actual rendered correctness is not inferred from declared canvas dimensions or passing source tests.

Finish through existing closure writers and wave records only after the relevant source/runtime/independent/gate conditions really hold. Final human review remains distinct. ROOT coordinates safe normal checkpoints/main delivery; unresolved extra callers and unrelated gates must not be hidden by claiming bundle/portfolio G11 or G4 green. This design neither postpones parallel publication work nor grants an unsafe merge.
