# E2 ideal-sector numerical checkpoint

This checkpoint implements the positive proper-particle, isentropic,
irrotational relativistic conformal scalar in laboratory coordinates. It does
not complete the original bilayer-nozzle physical prediction. The publication
remediation lead owns that full BUILD and integration responsibility; a genuine
nonauthor scientific reviewer must verify each construction and its evidence
before the existing canonical closure writer may close its finding.

## Construction and implementation

For proper enthalpy density w=n*h, positive n,h,c and |v|<c, a²=1/2,
K=2*n⁴/(w²*c²), J=diag(c,1,1) and
Q=eta+(1-a²)U_flat*U_flat^T, the actual returned matrix is G=K*J^T*Q*J.
Its full determinant is -K³*c²/2 and its inertia is (-,+,+).
[CONSTRUCTION.md](CONSTRUCTION.md) supplies the action, conservation, field,
coordinate and model derivation, including the separate Galilean bilayer branch.
The existing Lean carrier theorems retain their conditional historical scope;
they do not prove this new physical matrix or its full formal obligations.

Balanced mantissas and integer binary exponents compensate physical/unit scales
before final rescaling. Accurate subnormals are accepted; unrepresentable or
unresolved coefficients/determinants request higher precision. The declared
binary64 consistency checks do not restrict the complete mathematical |v|<c
physical domain or supply a universal forward-error theorem.

## Current M67-M1 range repair and evidence boundary

Whole independent M67 review accepted the M59 module-opening and whole-roadmap
consistency repairs, but requested a substantive constructor range correction.
An unused materialized `h=w/n` can overflow even when all returned coefficients
and the actual reduced carrier are resolved. Positive finite `w,n` already imply
mathematical `h>0`; evaluating `K=2*n^4/(w²*c²)` from original inputs preserves
the physical ledger without requiring this unused intermediate to fit binary64.
The original positive-input, timelike, coefficient/subnormal accuracy and
cone/conditioning policies remain mandatory, including their unchanged budgets.

The explicit two-orientation represented-sonic case is
`w=2^1023,n=2^-2,c=2^-1022,v=±c/sqrt(2)`: `h=2^1025`, `K=2^-9`,
resolved signed-zero `Gtt` and nonzero accurately subnormal `Gtx`. Constructor
controls must compare full original-input coefficients, reduced determinant and
inertia, laboratory pullback and reduced inverse independently. The full helper
determinant `-2^-2072` genuinely lies outside binary64 and must separately refuse;
the physical unscaled inverse need not be a finite binary64 array.

M70 author source repair is present. The actual old constructor failed on both
orientations at the unused specific-enthalpy quotient before executable editing.
After repair, the complete focused cohort passed 470 cases with zero failures,
errors or skips: the original 466 ordered identities plus four new positive/
negative constructor-success and separate helper-refusal cases. Raw separate
channels, full XML and actual T source/test/cwd/root with the prepared interpreter
are retained in the ignored M70 author handback. This is scoped actual unit
evidence, not independent acceptance or a fresh production sensitivity campaign.

The earlier fourteen-control meanings remain; their negative-enthalpy recipe now
removes only the surviving positive-w guard, retaining the explicit `w=-1`
DID-NOT-RAISE oracle for both APIs. The old two-guard recipe is preserved as
historical evidence. A fifteenth unused-quotient production discriminator selects
only the two new constructor-positive cases; the correct helper refusal cannot
mask it. All fifteen current recipes are DATA/AST proposals, UNRUN, pending
genuine whole nonauthor scientific/source/actual-unit/control review and ROOT's
separately authorized healthy/red/exact-restored campaign. Finding 1.2 remains
open; this does not close SCI1 or canonical G4.

## Prior independently verified numerical evidence

On 21 October 2026, the original publication candidate passed the complete
466-case scientific cohort before and after fourteen production regressions.
The whole independent M53 review accepted the actual source-causal failures and
exact byte/fullmode/nsmtime restorations at this numerical prerequisite scope.
The earlier failed zero-control and ten-control harness attempts remain failed;
no counts are combined. This evidence predates the isolated main-based port and
is not a fresh result for this checkout.

| Production regression | Independently verified causal floor |
| --- | --- |
| Restore both historical metric functions | actual carrier, normalization, determinant and range |
| Restore the time-component c² denominator | actual coordinate carrier |
| Restore the mixed-component c² denominator | actual moving carrier |
| Replace proper-density n⁴ by n² | nonunit-density action normalization |
| Remove the Lorentz factor | moving carrier determinant/inertia |
| Remove laboratory c² from the determinant | full actual matrix versus helper |
| Bypass timelike-flow rejection | invalid beta=±2 must refuse |
| Bypass both positive enthalpy guards (historical; now the surviving positive-w guard) | same negative-action branch must refuse |
| Bypass cone/condition qualification | unresolved binary64 timelike direction |
| Multiply constructor scales in unsafe order | compensated finite physical coefficients |
| Form K³ before the helper compensation | compensated finite physical determinant |
| Bypass coefficient final-scale accuracy | unresolved subnormal K must refuse |
| Square n before normalization compensation | finite physical outputs at opposing scales |
| Bypass determinant final-scale accuracy | helper-only unresolved subnormal must refuse |

## Main-based qualification and remaining work

The detached checkpoint starts from main ce194cdc4bf939b108c17edc9530a7f0a14565f9.
Only the two reviewed formula functions and their exact scientific tests are
ported. Other formula implementations and all Lean, notebook and manuscript
sources are unchanged. The new checkout passed all 466 focused cases with no
failures, errors or skips and the same ordered identities as the independently
accepted publication-candidate cohort. Actual imported formulas, test, working
directory and pytest root were verified inside this checkout using the prepared
interpreter. Whole independent composition review, fresh production controls,
required scoped/full gates and ordinary protected Git delivery remain pending.

Reproduce the focused scientific cohort from this checkout with:

```
uv run python -m pytest tests/test_graphene_metric.py -q
```

Passing that cohort alone cannot close SCI1 or canonical G4. Next construct and
formally verify the selected material/mode, physical state/EOS/inertia/gate,
current and phase normalization, transport/dispersion, contacts/receiver and
incoming/background/correlated noise. Match independent microscopic routes and
exhibit an identifiable nonempty usable band with controlled errors. Propagate
the complete original notebooks, figures, temperature/profile helpers,
E2/D1/paper16 and source/claim metadata; obtain fresh execution and whole
scientific/pixel review. Shared dispersion remains once-owned; the distinct L1
builds are retained. Publication and final human review remain open.
