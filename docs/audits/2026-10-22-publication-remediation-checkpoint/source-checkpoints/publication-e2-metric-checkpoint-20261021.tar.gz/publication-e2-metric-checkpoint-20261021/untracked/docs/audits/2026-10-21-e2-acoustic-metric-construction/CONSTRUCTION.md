# E2 acoustic geometry: physical construction and repair contract

Status: independently reviewed ideal-sector construction prerequisite. The
relativistic numerical implementation and its source-causal controls have
independent prerequisite acceptance on the publication candidate. This isolated
main-based port has recorded focused unit evidence. M70 removes the unused
specific-enthalpy range restriction identified by M67 and records 470 focused
passes, preserving all original 466 cases; genuine whole independent review and
fresh current-source production controls remain pending. Full physical implementation, formal proofs, consumer propagation and the complete
material/current/noise/calibrated-band construction remain OPEN.
The publication remediation lead owns the full construction, implementation,
formal verification, consumer propagation and current validation. This document
does not close that work. The original bilayer-nozzle prediction, microscopic
route agreement and calibrated nonempty detection band remain required.

## 1. Source, model and coordinate ledger

The primary source is N. Bilić, *Relativistic Acoustic Geometry*,
[arXiv:gr-qc/9908002v1](https://arxiv.org/pdf/gr-qc/9908002v1), sections 2, 3 and A.
Its conserved density is particle number and its specific enthalpy is
`h = (energy density + pressure)/n`, not enthalpy per area. Its metric construction
is for perfect, isentropic, irrotational flow. The printed conformal calculation
uses three spatial dimensions. The two-dimensional calculation below is derived
explicitly rather than copying that conformal power. Source equation (28) has a
repeated printed index in its last product; the inverse below is checked by
matrix multiplication and uses two distinct free indices.

Use signature (-,+,+), a constant positive causal speed `c = v_F`, length
coordinates `X = (ct,x,y)`, `beta = v/c`, `a = c_s/c`, and
`gamma² = 1/(1-beta²)`. The relativistic branch requires `|beta| < 1`, `0 < a < 1`, and the
future-oriented timelike positive root
`h = +sqrt(-eta^{mu nu} partial_mu chi partial_nu chi) > 0`.
Choose `n = dP/dh > 0`, positive proper enthalpy density `w = n h`, and
finite regular coefficients on the region considered. Then
`P'' = n/(h a²) > 0`. These are physical branch hypotheses that the API,
formal proofs, tests and selected material state must establish. Proper
thermodynamic quantities must be distinguished from laboratory density. A velocity-dependent Lorentz factor cannot be dropped at
the conformal sound horizon `a = 1/sqrt(2)`.

Let `chi` be a potential with units energy times length and
`h U_mu = -partial_mu chi`, where `U = gamma(1,beta,0)` and
`eta(U,U) = -1`. With physical action
`S = integral dt d²x P(h) = (1/c) integral d³X P(h)`, the choice of field is fixed.
An additive shift `chi_new = chi + B` leaves its derivatives, `h`, current,
`f` and `G` unchanged. Multiplicative field reparameterization instead changes
the quadratic coefficient, and must be carried into current/noise couplings.

Let `psi` be the action-valued physical phase (`psi = hbar theta` for a
dimensionless phase `theta`), and fix `chi = c psi`. In laboratory coordinates,
`h² = (partial_t psi)² - c² |grad psi|²`. For this same physical action,
`f_psi = c² f_chi` and, in three spacetime dimensions,
`G_psi = c⁴ G_chi`. More generally, `chi_new = A chi` at fixed physical state
and action requires `h U_mu = -partial_mu chi_new/A`; then
`f_new = f_chi/A²` and `G_new = G_chi/A⁴`. Retaining
`h U_mu = -partial_mu chi_new` would change the background instead of merely
reparameterizing its field.

The number/current conjugate to `psi` in laboratory coordinates is
`(n gamma, c n U_spatial)`; the current conjugate to `chi` is this physical
current divided by `c`. Physical charge, external sources, propagators and
noise couplings must retain the same field map. This ideal potential-sector
ledger does not supply the full charged/CGL or terminal response. A conformal
metric is not an independently calibrated observable.

For a barotropic adiabatic branch, `dP = n dh` and
`a² = (n/h) dh/dn`. The existing API calls its `w` an enthalpy density; if that
meaning is retained, the mathematical relation `h = w/n` must actually be
used in the normalization. It need not be materialized as a binary64 intermediate:
positive finite `w,n` imply mathematical `h>0`, and the equivalent
`K=2*n^4/(w²*c²)` can compensate scales before final rescaling. Requiring an
unused separately representable quotient incorrectly rejects resolved metrics.
This does not relax input, returned-coefficient, subnormal-accuracy or actual
cone/conditioning checks. Relabelling `w` as a specific enthalpy without auditing
every caller is not an implementation.

## 2. Linearized conservation and the scalar action agree

Perturb the potential and impose the linearized normalization
`U_mu delta U^mu = 0`. The variations of `h` and `n U` give, up to the common
sign chosen for the potential,

```
delta h = U^mu partial_mu delta chi,
delta n = n delta h/(h a²),
f_X^{mu nu} = n/(h c) [eta^{mu nu} + (1-a^-2) U^mu U^nu],
partial_mu(f_X^{mu nu} partial_nu delta chi) = 0.
```

The same coefficient follows from the second variation of the specified
`P(h)` action: write `S_2 = -1/2 integral f_X^{mu nu} partial_mu delta chi
partial_nu delta chi`. In the rest frame its time kinetic coefficient is
positive. This is an independent conservation/action consistency calculation
within the specified ideal potential sector. It is not a derivation of the
full dissipative charged CGL action, a microscopic fermion determinant, or a
device terminal response. Those original matching requirements remain owned.

Set `F = eta^{-1} + (1-a^-2) U U^T` and
`Q = eta + (1-a²) U_flat U_flat^T`. Since `U^T eta U = -1`, direct rank-one
multiplication gives `F Q = Q F = I`. In the rest frame these matrices are
`diag(-a^-2,1,1)` and `diag(-a²,1,1)` respectively.

## 3. Full covariant matrix, determinant and signature

For longitudinal velocity, the complete dimensionless covariant carrier is

```
Q = [[gamma²(beta²-a²),        -gamma²(1-a²) beta, 0],
     [-gamma²(1-a²) beta, gamma²(1-a² beta²),    0],
     [0,                     0,                    1]].
```

This also equals `Lambda^T diag(-a²,1,1) Lambda`, with the ordinary longitudinal
Lorentz boost having block `[[gamma,-gamma beta],[-gamma beta,gamma]]`.
Consequently its inertia is exactly one negative and two positive eigenvalues
throughout the admitted domain, including supersonic `a < |beta| < 1`.

The longitudinal determinant expands to

```
gamma^4 [(beta²-a²)(1-a² beta²) - (1-a²)² beta²]
 = -a² gamma^4 (1-beta²)² = -a².
```

This establishes the full 3x3 determinant, not merely its sign at one point.
The old mixed carrier fails this identity and can become positive definite
at an admissible supersonic velocity. Merely changing its determinant helper
would preserve the wrong propagation problem.

## 4. Two-dimensional conformal normalization and laboratory pullback

Write `G_X = K Q`, `K > 0`. In three spacetime dimensions,

```
sqrt(-det G_X) G_X^-1 = sqrt(K) a F.
```

On the declared positive thermodynamic branch, the signed equality is
`sqrt(K) a = n/(h c) > 0`. Matching the actual coefficient in section 2 therefore fixes

```
K = [n/(h c a)]² = [n/(h c_s)]².
```

This follows from the chosen physical action and potential normalization.
The four-spacetime-dimensional source's first power is not applicable here.
If `w` denotes proper enthalpy density, the same expression is
`K = [n²/(w c_s)]²`. An input called net charge density cannot be silently used
as a positive conserved particle density at charge neutrality.

For laboratory coordinates `z=(t,x,y)`, use `J=diag(c,1,1)`:

```
G_lab = J^T G_X J,
G_lab^-1 = J^-1 G_X^-1 J^-T,
f_lab = det(J) J^-1 f_X J^-T,
det G_lab = -K³ c_s².
```

In particular,

```
G_lab/K = [[gamma²(v²-c_s²), -gamma²(1-a²)v, 0],
           [-gamma²(1-a²)v, gamma²(1-a² beta²), 0],
           [0,              0,                    1]].
```

The time-time, time-space and space-space entries now have the correct
relative velocity units for `(t,x,y)`. In the rest frame the operator is
`n/h [-partial_t²/c_s² + partial_x² + partial_y²]` for constant background.
All normalization factors, including the potential used in current couplings,
must follow this same ledger in Python, Lean and manuscript formulas.

## 5. Characteristics, horizon and the temperature consumer

For zero transverse wave number, the two laboratory characteristic velocities
are obtained by Lorentz transforming the rest-frame sound rays:

```
lambda_plus  = c (beta+a)/(1+a beta),
lambda_minus = c (beta-a)/(1-a beta).
```

They also solve the null quadratic of the actual covariant matrix. For flow in
the positive x direction, the counterpropagating branch stalls at `beta=a`.
Here `G_tt=0` and `G^{xx}=0`; `G^{00}` remains negative. The original research
report's inverse-time-component horizon criterion is not the criterion proved
by this construction.

For a stationary longitudinal profile with constant `c`, differentiating the
outgoing characteristic at its horizon gives the laboratory peeling scale

```
|partial_x lambda_minus|_H
  = |partial_x(v-c_s)|_H/(1-c_s²/c²).
```

This agrees with the relativistic flat-background surface-gravity expression
in the cited primary source under its stationary horizon/Killing assumptions.
For a conformal constant-speed branch the denominator is 1/2. This is not
permission to multiply the Dean bilayer prediction by two: that experiment's
parabolic-band hydrodynamics is a different physical branch. Temporal
normalization, profile, stationarity, field/state and asymptotic matching are
required before producing a Hawking temperature or detector spectrum.

## 6. The parabolic bilayer branch must be constructed separately

The actual source
[Geurs et al., arXiv:2509.16321v2](https://arxiv.org/html/2509.16321v2), supplement
S.2, models parabolic bands with mass `m*`, degeneracy `g=4` and constant density
of states `nu=g m*/(2 pi hbar²)`. Its fixed-entropy-per-particle derivative yields

```
c_FL² = 2P/(m* n),
P(T=0) = n²/(2nu),   c_FL²(T=0) = n/(m* nu).
```

For a local capacitive gate, the additional energy density is `e² n²/(2C)`
and the extra sound-speed square is `e² n/(m* C)`. Its finite-temperature
pressure/density expressions, actual thermal carrier mixture and experimental
gate regime must be matched to the selected operating point. An effective
number `v_F=sqrt(2)c_s` used by a plotting helper is not a measured relativistic
causal speed for this model.

For the ideal, barotropic, irrotational Galilean sector require `m* > 0`,
`n > 0`, `nu > 0`, finite positive `rho = m* n`, `c_s² > 0` and regular
thermodynamic coefficients on the selected state branch. Direct continuity and
Euler linearization in a velocity potential gives

```
S_2 = 1/2 integral dt d²x (rho/c_s²)
      [(partial_t phi + v partial_x phi)² - c_s² |grad phi|²],
rho = m* n.
```

Its laboratory covariant metric is

```
G_G = (rho/c_s)² [[-(c_s²-v²), -v, 0],[-v,1,0],[0,0,1]],
det G_G = -(rho/c_s)^6 c_s²,
lambda_plus/minus = v +/- c_s.
```

The 2+1 conformal power follows by matching the densitized inverse exactly as
in section 4. Its stationary counterpropagating peeling scale is
`|partial_x(v-c_s)|_H`, without the relativistic denominator. Gate nonlocality,
viscosity, charge/entropy/imbalance modes and dispersive corrections require
the corresponding coupled operator and error regime. They cannot be supplied
by replacing `c_s` in an unrelated ideal carrier.

## 7. Neutrality, density, state and the material boundary

The relativistic scalar derivation assumes the explicitly positive proper
particle/enthalpy branch and an adiabatic potential sector. Net electrical charge vanishes at the Dirac point.
A thermally populated fluid there cannot be given a nondegenerate metric by
inserting that zero into the particle formula or by adopting `n=1` as a
physical normalization. A possible entropy-potential reduction must be derived
from the neutral constitutive laws and its units/couplings, not asserted by
renaming the input. Finite charge also has entropy/vorticity/diffusive sectors;
their decoupling and subsequent dissipative/noise matching remain owed.

The accepted earlier charged-current, Onsager, microscopic AB-bilayer, collision
and terminal constructions remain prerequisites at their recorded hypotheses.
This correction must connect the actual chosen mode, proper/lab density,
equation of state, profile and physical current to them. It does not erase or
duplicate the separately owned shared D1/E1/E2 dispersive-law construction.

## 8. Required coherent implementation and independent evidence

1. Independently review every derivation above, including units, field/action
   normalization, relativistic versus parabolic model selection and the neutral
   sector. Correct this construction before executable or formal propagation if
   any identity or domain is wrong. The ideal-sector derivation has scoped
   independent acceptance; selected-device and full scientific acceptance remain open.
2. Bind the selected physical state/model explicitly in the numerical API.
   Construct actual covariant/inverse matrices, determinant and characteristic
   consumers coherently. Audit every `w`, `n`, `v_F`, `c_s`, time-coordinate and
   potential convention; preserve public-call compatibility only when it is
   scientifically meaningful and explicit.
3. In an admitted existing Lean lane, prove the actual 3x3/block determinant,
   inverse, coordinate congruence, Lorentzian inertia/characteristic/horizon and
   normalization identities. Keep the old correctly proved conditional carrier
   algebra with accurate interpretation; it is not the physical new theorem.
   Missing lane admission does not turn these proofs into optional work.
4. Compare the determinant of the actual matrix with its helper using reduced
   carriers and scale-aware bounds. Cover rest, subsonic, sonic and admissible
   supersonic flow, both velocity signs, distinct speeds, densities/enthalpies
   and conformal scales. Default absolute tolerance would hide the old error.
   Independently test inverse, signature, null speeds, coordinate pullback and
   model/domain refusals. Real source regressions must expose the original mixed
   denominator, wrong determinant and inappropriate model substitution.
5. Propagate the justified model and its actual numerical/formal evidence through
   both complete original notebooks, E2, D1 and paper16 consumers, source/claim
   mappings, figures, relevant temperature/profile helpers and owning roadmaps.
   Correct present completion labels and false theorem interpretations. Keep
   actual citations and primary editions; scientific acquisition is not a waiver.
6. Obtain fresh actual original notebook execution, numerical/formal/consumer
   checks and whole independent scientific/pixel review, then the canonical
   finding Verify/closure writer, required project gates and protected checkpoint
   integration. New outputs from a known inconsistent model cannot supply full
   scientific acceptance.
7. Finish physical mode/current/contact/transmission/noise/calibration matching,
   microscopic route agreement and a nonempty error-controlled usable band at
   the original E2 acceptance boundary. The ideal-sector construction is a
   substantive prerequisite, not replacement success for that objective.

Acceptance remains author repair, genuine independent verification and recorded
closure. No infeasibility, deferral, smaller charter, publication permission or
main/human acceptance is asserted by this author construction.
