# Existing notebook commit-hook routing — corrected implementation plan

Current coupled continuation: **H96 SOURCE authored after H95 whole REQUEST_CHANGES; fresh independent review pending; whole source/evidence acceptance and ROOT qualification remain pending**.
H85 accepted the prior source; H86 complete qualification remains FAILED at its recorded pin.
H87/ROOT accepted the failed-runtime diagnostic; H89/ROOT requested complete precode correction. This author
work is not independent source/runtime acceptance. Preserve every original H1–H6/H5 objective,
all five actual qualification obligations, all44 UNRUN source campaigns and scientific BUILDs.
Fresh whole nonauthor design/source review and separately authorized ROOT qualification remain
required before closure, entry activation, protected delivery or publication acceptance.

### Five-root fixture and preparation contract

ROOT alone prepares normal locked uv runtimes with an explicitly assigned writable task-local
UV_CACHE_DIR propagated through existing _env/_call. Preserve uv sync --locked, HOME, source,
lock/Rust/package inputs and actual prefix project-kernel installation/origins. Cache placement
is not setup success or67 scientific passes; missing permitted resources require literal failure
and separately authorized resolution. The hook installs nothing; this author task runs no UV/runtime build.

The actual source observer extracts cause_order with its production dependency closure and
invocation-local CAUSE_SEQUENCE=itertools.count(1), SIGNAL_CAUSE_ORDERS={}, SIGNAL_EVENTS=[]
and SIGNAL_CURSOR=0. Keep the inert process/signal boundary, native argument and history
oracles, local equal-clock order and honest persisted=false unit owner; no copied observer.

Known prewait blocking is an empty writable result BEFORE command os.write during the original
final-drain seam. The existing post-wait final-observation checkpoint may emit only its known
remaining suffix. An attempted write that raises or has invalid count stays UNKNOWN and fenced;
readiness or later phases never recover it. Keep all four original tail variants, exact8/10 bytes,
first.25/D15.25, capture.5, wait2/cost1.75, broken stdout independence and fixed2/5/15 windows.
Unconditionally restore borrowed seams and finish each Evidence owner once around assertions;
retain the original error plus later cleanup causes and verify actual event/root FD closure.
Do not call a not-admitted journal complete in the strict SAME reader.

The original before/within OS-capture controls retain all12 IDs and six full damage predicates.
Within interrupts RIGHT strictly before inheritedD while LEFT/native OS obligations stay partial,
then requires actual safe INT. A distinct exact-D complement calls original typed_native/check_time:
no late INT; KILL only with independently valid ownership, otherwise UNKNOWN/refusal. Exercise all
six original corruption predicates on that expiry journal too. No blanket2-to9 replacement,
completed capture substituted for partial capture, altered >= guard or extra window is permitted.

Preserve all1233 old IDs/order and every original assertion except these explicitly described
fixture-premise migrations. All44 exact causal recipes/selectors/restoration duties remain;
review any shifted anchor prospectively. Fresh healthy intended cohort, sole actual causal
artifact red, exact bytes/fullmode/nsmtime/index/admin restoration, empty durable seed journal
and same-ID healthy restored run are mandatory. Author units do not substitute for postreview
qualification, scientific/H5/full gates, recorded closure, protected delivery or human review.

Status: **Lifecycle refinement — operator-approved A, current fixture repair.** Keep the reviewed source-to-wire/native-control mechanism, process chronology and actual context-before-owner order. H86 full qualification is failed; H87/ROOT accepted its diagnostic construction requirements. H92/H93 accepted the exact controlled-error pressure pair and complete nonmasking callback/cleanup/postcleanup-receipt construction. H94 has now authored that coupled fixture source; author development is bounded evidence, with whole nonauthor source/actual-evidence review still pending. The producer and strict SAME reader remain exact. Fresh whole nonauthor design/source/original-intent review precedes separately authorized ROOT full native/runtime/production/scientific qualification. Author development is bounded evidence only; every original positive prerequisite, UNKNOWN/one-retry bound and scientific BUILD remains owed.
Spec: `../specs/2026-10-19-precommit-notebook-worktree-routing-design.md` H1–H6.
Finding: `papers/AutomatedReviews/2026-10-19-precommit-notebook-worktree-routing/infra.md` §1.1.
Retain all original H1–H6 objectives, existing source and failed receipts; no lifecycle, runtime, production or scientific acceptance follows from this plan.

## Global constraints

Root owns Git/index, isolated production seeding/restoration, primary entry rollout, existing
runtime preparation, owner docs/books, required gates, closure writer and protected delivery.
The implementation author owns only the assigned existing hook/tests/spec/plan and topology/QA
owner documents plus named ignored handback leaves. Integration
science source/tests/notebooks and B2 source/metadata belong to other active writers; no global
static-source/ref assertion, restoration or lease inference. Existing guards/order, sync skip,
source science and accepted author-bound executions remain. The current author uses only its explicit packet-selected existing inert/owned-native fixtures for bounded development checks. Required postreview/full qualification remains ROOT-owned; no package/kernel installation, actual notebook/kernel/pilot, authoritative Git/index/native service/book/closure change is authorized.

Use existing public script, locked uv runtime, ipykernel/Jupyter kernelspec and nbconvert/nbclient
configuration. No second resolver/selector/API/module, executor, service, gate, registry, cache
or ledger. Transparent child-scoped candidate import/kernel configuration is permitted with
actual origins; provenance masking and guard bypass are forbidden. Preserve every original
cell, metadata tags, notebook-directory asset semantics, scientific input and failed receipt.
No two-notebook exception, fake MC result, empty-data scientific PASS or tolerated cell error.

## Private allocation ownership coordinate

In the existing `_h4_inert`, retain the actual `TemporaryDirectory` object and its original
returned path. Bind the private-open guard's selected root by resolving only that path's
parent and preserving its allocated leaf name; pass the original returned path to the
unchanged Evidence constructor. Production ownership, canonical identity and no-follow
checks remain responsible for admitting the same allocated directory. The guard's separate
existing native-fixture prefix branch is unchanged. Do not broaden the
guard, change environment/temp-base settings, substitute a leaf, or edit caller/reader,
producer, sampled clocks, native controls, semantic oracles or budgets.

Add controls using the real allocator through both a direct parent and a real test-owned
parent alias, with independent lstat/fstat identity, exact allocation-object and FD cleanup
checks. Foreign same-basename directories, parent aliases to foreign directories and
symlinked leaves must fail through the unchanged guard/ownership checks with no new opened
FD or altered foreign contents. Keep the entire original positive/full population. This
source-only repair requires fresh whole nonauthor review followed by ROOT actual positive-
first, full runtime/native/production/scientific qualification; prior failed receipts stay.

### Startup-fault allocation precondition

The original top-level startup-fault fixture must allocate its actual temporary directory with
the existing production `pre-commit-notebooks-` prefix. Keep the actual TemporaryDirectory
object, its original returned path, default parent and cleanup lifetime. The delegated startup
allocator still checks the original production mkdtemp keyword arguments. This supplies a valid
allocation precondition to the unchanged private-root guard and actual Evidence ownership,
canonical-parent, descriptor-identity and no-follow checks. Do not broaden either guard or
normalize native identity. The events-open branch must retain the original OSError object and
all partial-owner, absent-events, closed-root-descriptor and cleanup assertions; the separate
root-allocation branch retains its original no-owner/raw-stderr/error-identity assertions. No
fake descriptor, clock, skipped case or weakened expected error may supply this precondition.
The source correction requires genuine whole nonauthor review and actual current qualification.

## Proposed typed Darwin identity continuation

**Python-observable Darwin identity domain (proposed; independent whole design acceptance required).**
The existing Evidence public snapshot and SAME reader retain an exact dict with
exactly dev,ino,rdev,mode,uid,gid and exact built-in integers, excluding booleans
and native int subclasses. Define D = {-1} union [0,2**31) union
[2**64-2**31,2**64-1), U = {-1} union [0,2**32-1), I = [0,2**64),
and M = [0,2**16), with half-open intervals. dev/rdev use D, uid/gid use U,
ino uses I and mode uses M. Compact root/events dev/inode pairs use D times I.
These are the images of the reviewed CPython conversions of modern Darwin
native fields, not their C storage intervals. In particular the middle device
gap, negative values below -1, unsigned64 maximum and unsigned32 uid/gid maximum
are refused; no blanket unsigned or signed interval is substituted.

Preserve every raw Python value verbatim through observation, JSON, baseline,
current and independent post-state. No abs, cast, bitmask, wrap, missing-attribute,
null or zero substitution is allowed. -1 is a representable observed component;
it alone supplies neither descriptor identity nor authority to mutate it.
Actual no-follow filesystem identity/uid/mode, descriptor/presentation controls,
baseline/current equality and independent receiver/post-state equality remain
separate requirements. Malformed or unavailable observations retain the actual
partial native result and original fault, with incomplete/null public identity.

The profile is derived from pinned official CPython v3.14.8 conversion source
and passively inspected installed aarch64 headers/configuration. Installed files,
version strings and upstream source do not attest the loaded binary or original
build SDK. ROOT must qualify that composition and all required actual positive
routes before runtime acceptance; a discrepancy requires a new coherent review,
never a broadened guessed domain or a route refusal called positive. Keep approved
A, framing, S/P/N/W, flags, process/error/deadline/cleanup and scientific duties
unchanged. Correct these owners before source, then obtain fresh whole independent
source review before ROOT original prerequisites/native/module/production controls.

1. Independently review the complete NI1–NI6, actual native failures, installed ABI
   declarations, current Evidence/SAME reader and all original controls. Disclose
   related authorship. Source permission is a separate deliberate grant.
2. Update topology, QA map, this plan and the original spec first, correcting the
   blanket identity schema in place. Extend only the existing producer and SAME
   reader with exact field-specific Python forward images. Preserve raw values and equality.
3. Map every old assertion/function/case/budget. Declare each necessary public/pair
   predicate migration; retain every other old source expression. Add decisive
   exact-type/key/range/boundary and in-range identity-change complements, including
   actual signed socket and upper-island PTY observations, gap/sentinel controls and recomputed-digest reader negatives.
4. Obtain fresh genuinely nonauthor whole source/original-intent acceptance. ROOT
   qualifies all original ownership/caller prerequisites and native routes, then the
   entire original-plus-additions module through its legitimate runtime preparation.
   A required route refusal is a failed positive, not an exemption or a skip.
5. ROOT separately executes actual producer-old-guard and SAME-reader-old-guard
   0/nonzero/restored0 sensitivities through existing durable source mutation custody.
   Bind intended guard location to actual Python values rejected by that guard;
   also qualify the superseded signed32 guard separately against high-device PTYs. Retain original
   scientific/error/flag/source/stream oracles and exact restoration, and preserve
   every prior failed receipt. Runtime helpers, seeds and stage selectors are DATA
   here; no source execution or native child is authorized by this design.
6. Original H5, ordinary common/manual/linked/subdirectory entry, candidate origins,
   strict once-only cells, actual original assets/MC data, current full gates,
   canonical closure and protected main/activation remain separately required.

## Phase A — whole design and literal intent review (R29 accepted; source review separate)

Read the finding, entire H1–H6, MODEL, this plan, both owner documents, fresh whole review and
root disposition plus retained prior reviews/FINALs. Inspect actual hook/Git/runtime owners,
Phase5b cell12, installed config/preprocessor/skip/error/kernel-discovery and lifecycle branches.
Challenge the full actual-parser→observer→every-hook-signal consumer chain, safe direct CLI
versus pending same-group children, true complete absence and bounded cleanup under uncertainty.
Assess indirect vendor kernel-group effects from CLI interruption using the exact installed
source handback. A universal vendor recipient guarantee is not supplied by the normal stack;
any unresolved original-intent contradiction needs a construction breakdown to root, never an
implicit waiver. Record whole adversarial verdict and literal operator-intent assessment before
implementation. Design review uses existing raw counterexamples and readonly source/AST. Implementation-author
validation is restricted to exact assigned new inert deterministic nodes and syntax, while actual
current native capability and the complete unfiltered runtime suite remain root-owned.

## Phase B — root owner-doc amendments and normal prepared runtime (owed)

Root serializes the accepted topology/QA/spec/plan together and its mechanism before
code; any separately owned ADR-D16 or architecture-claim change remains root-assigned. Preserve
current portability and ADW paragraphs.
Deliberately assign the coherent public-script/test implementation through a fresh packet.
Prepare the candidate's normal environment using existing uv sync --locked and existing
ipykernel install --prefix for kernel names derived from admitted notebook metadata. Capture
actual dependency/Rust build and environment/spec source evidence; no primary editable copy,
lock/source change or silent in-hook install. Existing prepared runtime receipts must be checked
at the current candidate; no preparation
is rerun merely because a design is revised. Missing or failed preparation is reported/refused,
not treated as working runtime.
If local/private common-hook changes are shown necessary, decompose that owner separately;
this plan grants no edit or public disclosure of its canonical source.

## Phase C — one coherent existing-hook repair (candidate source present; acceptance owed)

| Existing/future file | Work |
|---|---|
| scripts/pre-commit-notebooks.sh | H1 inherited Git-context/backlink validation; H2 NUL/index/raw-byte/mode admission; H3 per-notebook parent cwd + literal stdin, candidate runtime/import environment, effective strict CLI config admission and result/event postflight; H4 complete all-or-nothing native parser, immutable history/true absence, direct CLI plus fresh descendant signals, bounded native grace/drain/reap/first-failure/races |
| tests/test_pre_commit_notebooks.py | Preserve complete original semantic predicates/parameters/budgets and byte-prefix provenance; apply only independently reviewed necessary existing-reader/context/helper expression migrations under explicit ROOT amendment, then add actual parser→observer→root/descendant cleanup complements and full original real layouts/assets/imports/strictness/lifecycle/H5 controls |
| tests/test_architecture_claims.py (future assigned span) | Exact accepted mechanism sentence bound to actual behavior, never comment/source-count proxies |
| Existing architecture owners | The assigned topology/QA mechanism follows the candidate implementation; root intakes/serializes it and separately assigns any remaining ADR or executable architecture-claim changes before delivery |

Future root runtime allocations may use routine cheap fixture Git layouts without mutating shared indexes. This design allocation permits no fixture Git or test execution. Existing script remains
the sole execution entry; trait admission/JSON result checks do not become a new validator or
parallel execution engine. Python preprocessing/model/bootstrap is not added to original clean
notebooks. Do not infer child KernelSpecManager receives CLI config; use the existing verified
candidate-prefix path/spec route and real kernel origin witnesses. Runtime and production pilot
scope is root-owned and isolated from concurrently running scientific mutation tests.

Keep implementation coherent across the existing parser, observer, every signal consumer and
its call ordering. Malformed UTF-8/numeric/birth/state/partial-command/duplicate/blank/empty/
missing-witness/timeout/nonzero/stderr samples must not resolve history, extend ancestry or
admit descendant effects. Complete safe and complete true-absence samples must still work.
Assert positive identities and exact signal-attempt targets through actual helpers, not a
proxy predicate. Pending changed/reused/restored/unknown same-group and separate-group cases,
selected TERM/KILL and exhausted reconciliation must never gain a hook group bypass; unreaped
root-only INT/KILL and safely known descendants remain positive, reaped root and unrelated
same-command rows remain negative. Cover actual failure-cleanup ordering and first buffers,
not helpers alone. Unknown samples cannot prematurely abandon other safely established cleanup;
all phases retain their fixed budgets, genuine final absence and explicit residual obligations.

The original complete semantic test contract is conserved, including all original cases, strict 120s and
real normal/error/signal/spawn/detached/pipe/concurrency controls. Author tests may run only when
root explicitly grants them, using exact selected deterministic nodes; no wildcard selector can
silently enroll temporary Git or real-runtime fixtures. Source/helper success and design review
never substitute for root's full unfiltered real suite or H5. No new process service, modified
vendor manager/provisioner, runtime callback, registry, gate or generic executor is introduced.

## Coherent H4c repair sequence and exact evidence obligations

R14-1 and R14-2 are one repair: the report/stream transport must not block observation or
cleanup, and errors from that same IO layer must not bypass safe remaining cleanup or replace
the first failure. Do not ship either half alone. Existing hook report/process_rows/run and
invocation output ownership remain the only implementation owners. Candidate hook/tests and four describing documents form one coherent source handback; config and
all scientific sources remain conserved. Current source acceptance is still a separate review.

1. Fresh nonauthor review reads entire H1-H6/current implementation, R14 full raw controls,
   H4c1-7 and this plan, then separately assesses literal user intent. Review the finite-IO
   construction limit explicitly. If a universal hard-wall/durable-evidence requirement is
   asserted, stop that dependent implementation and send the concrete breakdown to root for
   an operator decision; do not self-waive or introduce a runner. Whole design acceptance and
   root intake precede any source grant. Prior R12 design acceptance is historical, not R15 acceptance.
2. Under a new root grant, extend the same unique invocation directory before first report;
   create private exclusive regular binary channels and ordered metadata; retain root on both
   success/refusal for owner collection. Implement bounded nonblocking summaries and exact
   per-stream suffix offsets, supported descriptor flags/restoration and deadline-aware
   incremental parse/encode/write. No full census/argv/history on stdout and no fixture-only
   drain workaround. Disk/descriptor failures are real nonzero outcomes, not discarded rows.
3. In that same source package, isolate the entire H4c5 operation matrix in existing run,
   preserve immutable first failure/actual channels, retain ordered typed later errors and
   continue every independently safe effect/final drain/wait/receipt/flag restoration. Preserve
   complete observation/identity and every original signal predicate. Keep15/5/2/2/2, ps2,
   reconciliation2, outer and per-cell120s budgets; no extra IO grace or science retry.
4. Before author execution, audit exact nodes/fixture call tree and receive its explicit
   grant. New deterministic tests must invoke actual formatter/sink/file-owner and actual
   run consumers, with independently specified expected raw bytes/effects. Required matrix
   is H4e/H4c5, including R14's valid1002-row prelaunch blocked-sink construction and all three
   actual drain/wait/tail failures. Use only granted inert boundaries; retain original94 complete-prefix provenance and58 controls; preserve every semantic predicate,
   parameter/budget and failed receipt. Original-interface edits require the explicit ROOT
   amendment and independent whole consumer-design acceptance below.
   A list emitter bypassing the real formatter is insufficient. Tests cannot silently enroll
   real Git/process/kernel fixtures with wildcard selection.
5. Freeze coherent source/docs/tests; fresh genuinely nonauthor WHOLE source review and root
   intake precede expensive runtime. No design-only or selected helper PASS accepts code.
   Root then measures native complete process observation and actual output filesystem/census/
   log volume/latency, runs the full unfiltered current original-plus-additions population, and original real normal/
   error/signal/timeout/spawn/detached/pipe/concurrent/race/residue controls. Include real supported
   callers that await a kernel witness before draining PIPE, normal manual terminal and file
   redirection, closed/slow/undrained outputs, late IO faults and exact safe cleanup. Do not
   alter callers to make the demonstrated ordering disappear. Real filesystem/process work
   remains root-owned; determinism alone is not native acceptance.
6. Complete unchanged H5 actual production/primary activation/journal poison+exact restore/
   clean GREEN/strictness controls and source/index conservation. Only current full gates,
   canonical closure writer, wave closeout and protected ordinary main delivery can ship.
   Missing original Phase5b MC data/relative consumer and every scientific BUILD remain owed.

Candidate implementation and scoped inert source controls are present; no whole source, native,
full-suite, H5, gate or closure acceptance is claimed by this plan. Root separately owns any unassigned ADR/architecture-claim registration
amendment. Disk-retention policy and unsupported output/IO capability are reviewable effects,
not hidden operational costs or exceptions to the original science.

## Coherent corrective package — producer and original consumers ship together

The old source and old migration proposal were independently rejected. The corrected spec's
P1–P4/C1–C3 are requirements, not acceptance receipts. ROOT assigns one coherent implementation
of existing hook plus existing test readers after genuine nonauthor whole design review and
separate literal-intent review. No half-package reaches full runtime or closure. H84 changes
only assigned fixtures and four docs under its accepted design; producer/SAME reader stay exact.
The original byte prefix remains immutable provenance; any future reader migration needs
separate explicit authority.
This amendment preserves every original case/oracle/budget; it does not accept failed tests.

| Finding and existing owner | Concrete source/consumer work after grant | Independent discriminator and required evidence |
|---|---|---|
| P1 — run final drain/wait/observation and emit_available | Relay actual suffixes before wait within final-drain time; start the existing final-observation window once BEFORE the independent post-wait relay, then charge census/receipt to its remainder. Separate wait deadline; no old drain deadline reused and no new grace. | Actual source run control with original timeout, final buffers at t+0.5 and returned wait consuming1.75 within its own2s. Writable tails remain exact/once before wait; second case proves no pre-wait syscall through empty readiness, then post-wait writability and exact remaining suffix once; attempted UNKNOWN is a separate strict negative. Broken stdout cannot hide stderr. Assert phase starts/remaining deadlines, raw segment files, exact public bytes/offsets, safe effects, wait and later final observation; retain first exception. |
| P2 — Evidence.fault/run.remember/top-level partial owner | Immutable typed first snapshot before reporting/cleanup; native descriptor args/errno, actual phase/time and command/fault IDs; exact typed builtin values/bytes, ordered later faults. Same object is rethrown/referenced, never replaced by fallback text. Partial construction tracks only acquired capabilities. | BadFirst('RAW_ORIGINAL') with broken str: inspect decoded CLOSED evidence and exact native args/errno/phase/time, first object identity and all safe effects. Also bytes/nested/float-negative-zero/nonfinite args, unsafe/opaque/cyclic argument explicit incompleteness, raw attribute/encode/write/close failures; retain true prefixes and nonzero status. Startup allocation/prepare/admission errors get actual envelope where possible; genuine no-owner case remains startup-unavailable, not fake retained complete evidence. |
| P3 — same Evidence/run/accept/available/report | One invocation-local command ID before each preflight; factual command_begin/launch/result/channel completion/command_end, selected actual environment and UTC/monotonic times; every segment/fault/observation/delivery range bound to the ID. Empty EOF evidence distinct from not-created/unknown. | Compare one A/B command with two A/empty and empty/B commands through ACTUAL owner/run: distinct IDs/boundaries and both full stream states. Include healthy nonwatched, start failure, repeated cumulative prefix, contradictory and partial buffer, close fault and missing outcome. Decode real files/hash/offset/complete records independently; no guessed adjacency, copied metadata or command-name dispatcher. |
| P4 — interrupted/run/top-level existing phase owner | Continuous signal latch across all running/cleanup/success-finalization/admission transitions; explicit safe checkpoints and fixed phase state, no handler IO or raise past obligations. Only final exit-commit after finalizers permits immediate nonzero. | Inject first/later caught signals immediately before the old flag assignment, before/after each independent CLI/descendant/drain/close/wait/observation/receipt/flag operation, successful finalization and status-to-exit. Assert original failure object/envelope or genuine first interruption, full remaining safe individual effects, one launch/no budget reset, truthful phase/time and actual nonzero. Late post-close signal remains explicitly incomplete; no fictitious on-disk record. ROOT authentic signal complements remain required. |
| C1 — existing raw assertions and _events reason expressions | Preserve actual raw stderr traceback/poison/sentinel once-only predicates and generic non-hook streams; only structured hook admission/refusal expressions use verified retained event fields. Bind command raw segments independently through P2/P3. | The original identity-route PIPE sentinel count stays exactly1 in actual raw stderr. Full original CellExecutionError/poison/timeout bytes remain in exact source channels; normal-TTY additions also prove their exact forward native presentation on actual wire; reason text or duplicate cumulative capture cannot satisfy them. Positive public-delivery ranges/raw files agree, malformed/overlapping/missing ranges refuse. |
| C2 — _call/_run/direct/lifecycle/concurrent actual context and one _events | Explicit pre-call source/env/time/PID-when-observed metadata, exact private root/file/marker validation and the complete disposition table. Generic command results untouched. No stale search/default empty/constructed replacement result. | Current bound empty/success/admission/command/start refusal positives; no-result/no-root/start EAGAIN/partial events/raw/marker and each source/root/time/PID/uid/mode/symlink/inode/truncation/ID corruption negative. Expected race uses actual matching pre-pin plus real nonzero movement. Corruption is infrastructure failure, not an expected science error. |
| C3 — semantic-final tests, source observer and same reader | Expose ALL events incl terminal_provisional; move only last-business predicates to its immediate predecessor on verified zero. Preserve exact old fields/oracles; extract actual nested closure/deadline/fault dependencies including actual cause_order and invocation-local CAUSE_SEQUENCE/SIGNAL_CAUSE_ORDERS, and represent full command in fixed512-character chunks. | All original45 functions/94 cases/159 test+13 helper predicates mapped individually in ignored design evidence. Provisional/semantic order and actual terminal-close/delivery/flags/exit negatives; actual source-only history/effect positives/negatives remain. Exact error prefix/args and full-command substring expressions migrate representation only. No filter table/shadow helper/copied observer algorithm. |

Implementation file authority is exact: existing scripts/pre-commit-notebooks.sh for P1–P4;
existing tests/test_pre_commit_notebooks.py for its original _events/_call/_run/direct/
concurrent/lifecycle/_source_observer/_observer_row interfaces and corresponding assertions,
plus meaningful discriminators. Four existing describing documents track the same contract.
Configuration, science/Lean/notebooks/dependencies, private guards and other writers' indexes
remain out of author scope. Any architecture-claim/ADR consequential correction needs a
separate explicit ROOT span; no unassigned writer is implied by this table.

Consumer implementation is gated by producer identity/envelope semantics, not postponed as an
independent future workaround. First correct and freeze those producer fields, then implement
the single existing reader against them in the SAME coherent package. AST-map every old
assertion to its exact new expression or byte-exact unchanged body, including _run's raw index/
notebook/mode checks, fixture lifecycle/sentinel/index/source/cell/origin/residue witnesses,
concurrent raw results, every parameter and timeout/wait/sleep call. The old semantic-final
queries are necessary interface edits, not relaxed success; the retained list still includes
the terminal record. Original source-observer error and full-command representation checks
must remain exact, not accidentally become substring membership in a tuple/list.

Before any author test, audit exact nodes/fixtures/call tree and obtain the explicit scope.
Inert controls invoke actual source owner/formatter/files/cleanup orchestration, with only
specified process/signal/clock/control boundaries inert. Source-only observer tests use their
explicit abstract producer boundary and cannot establish native parser or persistence truth.
Decode actual private-file evidence for P2/P3, not merely an exception object kept by pytest.
Keep all92 prior inert semantic cases/budgets and the original94 complete population. No new
runtime/Git/kernel fixture may enter a narrow run via wildcard. Retain every failed attempt,
source pin and raw channel; do not rebind an earlier PASS to later code.

Fresh genuine nonauthor WHOLE source review must inspect producer PLUS full reader/assertion
migration and every original H1–H6 duty. Independently reassess literal user intent. Only after
ROOT intake and final coherent freeze run the full unfiltered current186-plus-additions file,
real storage/native census/volume/latency, authentic callers awaiting kernel witness before
PIPE draining, manual/redirected/closed/slow callers, native transition signals/faults and all
original real lifecycle/race/residue cases. Then unchanged H5/primary activation/legitimate
original assets and MC data/current full gates/canonical closure/protected main/human remain.
No design, source/inert PASS or refused invocation is a scientific completion/absence waiver.

## Phase D — actual ordinary production pilot and both mandatory repair proofs (owed)

1. Capture actual old script, active index and candidate/primary differences and legitimate
   runtime prerequisites. Observe old-route real behavior under the existing common hook;
   preserve any separate runtime failure rather than label it a manufactured routing RED.
2. Roll independently reviewed public-script bytes to the real invoked primary entry through
   root Git discipline. Candidate-only changes cannot activate the common hook's old primary
   entry. Preserve all installed guard order and private scope.
3. Capture actual selected candidate kernel cwd=parent(notebook), sys.prefix/executable,
   loaded src/relevant-module origins and hashes using separate journalled witness runs;
   restore original cells/bytes, then run complete clean notebooks under the same normal route.
4. Prove M1 with a clearly non-scientific candidate-relative asset distinguished from primary
   and parent data AND actual candidate imports. Witness original Phase5b path/glob semantics.
   Legitimate absent MC data stays DATA_UNMEASURED/OWED; no invented JSON or empty-branch
   scientific acceptance. Do not replace this requirement with the two graphene notebooks.
5. Prove M2 through the real production script with failing skip-execution/custom-tag/
   raises-exception cells and ambient allow_errors/allow_error_names/skip/removal settings.
   Override or explicit refusal must keep poison RED; stale outputs cannot masquerade as
   fresh execution. Successful tagged cells must actually execute. Meaningful enforcement-pin
   mutation must expose a control failure. Journal and exact-restore notebook/config/script.
6. Candidate-only fully staged poison with primary good is RED. Restore every original
   working byte and all semantic index entries, then full clean normal-route GREEN. Run all
   remaining H5 filename/mode/source/error/signal/race/conservation cases; capture actual
   first-run failures, cell events and actual bounded cleanup/drain/reap/residue scoped to observed
   identities. Unknown or residual cleanup refuses and stays a root obligation under H4.

These are planned activities, not receipts. All production seeding uses seed_journal; index
staging/restoration is root-only. No environment-only GIT_DIR simulation replaces ordinary
common-hook evidence, no repeated execution for traceback, and no global-static assertion.

## Phase E — whole source verification, canonical closure and protected delivery (owed)

Run the full current Verify file plus existing architecture-claim/workspace tests, Bash
syntax and existing scoped verifier. Derive registration obligations with the existing skill
tool; no new check/floor/skip changes. Genuinely nonauthor reviewer assesses the entire final
source, H1–H6, runtime preparation and all production controls; root intake follows. Root runs
required current full integration gates and retains unrelated failures. Only then existing
closure writer, corrected owner documents, wave closeout and reviewed ordinary Git/main
checkpoint can close this infrastructure debt. Design acceptance alone is not source/pilot
acceptance, and no scientific deferral or publication/green status is granted.

## R30 accepted whole construction continuation — document before code

Apply the accepted R28/R29 D1–D5 refinements in the existing specification and both owner maps
BEFORE changing the existing hook or reader. Preserve all H1–H6 populations, helper inputs,
source instrumentation anchors, decorators, raw sentinels, deadlines and science predicates.
No new executor, runner, vendor patch, check registry, service or controller is introduced.

1. Evidence owns actual descriptor preflight for BOTH bounded references, actual native integer
   domains, supported512-byte pipes, exact accepted-start-byte terminal digest, independent
   short/unknown writes including BOTH NONO attempts and null unavailable accepted binding.
   The actual reader retains raw slices and every independent context/root/journal/raw witness.
2. Canonicalize the SAME actual allocated root inside Evidence with raw/canonical/opened inode,
   uid/mode/parent checks; preserve the literal top-level allocation fixture anchor.
3. Install each ORIGINAL phase deadline before phase publication/checkpoints/capture/effects.
   Keep FIRST terminal-error ownership and all existing15/5/2/drain/wait/observation windows;
   expired INT cannot skip separately scheduled required unreaped direct CLI KILL.
4. Add rc0-pending-EOF state only before terminal failure, with ONE existing15s tightening cap
   intersecting the original running deadline. Actual FIRST error+15 is further capped before
   nested capture. No fault erasure, prepopulated fake fault/grace, late-EOF backdating or reset.
5. Preserve the exact reviewed representation migration set: existing reader common-field pair
   equality and four large-census common-field checks become actual independent start witnesses
   PLUS exact raw-start terminal digest. Keep every other prior semantic obligation and complete
   original/case/assertion/helper/decorator/input/budget/anchor conservation sidecars.
6. Add production-owner controls for512 fit/insufficient/native-domain boundaries, recomputed
   malicious digest and independent witnesses/raw corruption, canonical same-inode positives and
   substitutions, short/unknown/late close/flags/signals, phase-entry capture costs, timely/exact/
   late/persistent/nonzero EOF with nested faults and both watch settings. Preserve all original
   unknown-state, first-object, exact channels, literal NONO and lifecycle fallback controls.

Under the completed R30 allocation only, the author could run explicitly selected INERT production-owner tests with external OS/IO/
clock seams, pure static checks and a safe own-pipe capability experiment under ROOT's packet.
Retain actual subset stdout/stderr/JUnit and every failed observer/test; no subset result is
native/full-suite acceptance. ROOT separately owns actual native/full suite plus additions,
H5/SDK/assets/MC/common-entry, real production0/1/0 with exact restoration, full gates and main.
Every native? remains an actual whole-sample unavailable fault. Later complete observations may
support only safely admitted cleanup within existing absolute budgets; prior faults cannot
become clean success. No retry/fallback/widening/alias or scientific waiver follows from R29.

The existing full-channel obligation also requires ordered pending returned-channel validation/capture at ONLY the original final-drain and shared final-observation remaining windows; retain first faults and contradictory-prefix refusal, with no new execution/query/communicate or capture grace.

## Proposed native control lease and late-error verification — design before code

F1–F6 together with T1–T9 in the existing specification are the complete proposed
continuation, pending genuine whole H1–H6 and literal-intent review and T9's explicit
received-byte-contract decision. This design packet runs no tests or new capability
experiment. Do not interpret the historical R30 validation permission as a present grant.

1. Review the actual raw pipe failure and pinned Apple primary source; retain installed-binary
   equivalence UNPROVEN. Preserve the original failed positive and all scope exceptions.
2. In the existing Evidence owner, snapshot BOTH original descriptors before any effect; retain
   full words, native controls, FD-local flags and identities. Model aliasing explicitly.
   Propose only the FIONBIO narrow nonblocking effect, complete before/effect/after raw-word
   equality, protected unowned controls, partially acquired leases and independent restoration
   followed by both-descriptor observation. No broad F_SETFL fallback or ignored history bit.
3. Retain original phase/fault/closure/signal/exit ownership and budgets. Persist setup facts in
   existing invocation fields, retain post-close observations in the same owner's memory.
   No third marker, new event/phase/runner/service/command/grace or reopened journal.
   T4 adds bounded actual write-accounting fields to existing command_end/provisional
   records; source and wire domains remain distinct.
4. Extend the SAME consumer's contextual restoration and T5 transport dispositions. Direct state witnesses
   must be actual retained shared-description observations; an ordinary exit2 is not one.
   Preserve every raw result and all protocol/source/time/root/journal/semantic-final checks.
5. Implement only after whole design acceptance, the T9 decision and a separate grant:
   enumerate each F5/T7 syscall-seam/own-pipe/framing/transport predicate
   migration against its exact original purpose and preserve all other original/current
   obligations, helpers/inputs/anchors/decorators/cases/budgets. An inert facade must model
   F_GETFD and narrow ioctl effects explicitly; it is never native qualification.
6. Run meaningful production-owner positive/negative and mutation complements for both initial
   states, aliases/separate opens, all protected controls, every partial effect/read/restore
   fault, wrong readback, identity/race, late signals and a genuine earlier first error.
   Observe real own-pipe state outside the owner even when its negative outcome is unchanged.
   Test a state-correct late query exception through the actual production fault owner; state
   the unchanged native observation limit rather than certify it from an ordinary negative.
7. ROOT separately admits actual descriptor-population/native child controls and complete
   original/full suites plus additions, scientific/H5/SDK/assets/MC/common-entry/production
   controls/current gates/main/closure. Unsupported redirects/TTYs remain failed positives,
   not exemptions. Every unknown ? sample remains an actual unavailable whole-sample fault.

No source/test/helper execution is authorized by this design, and no scientific/full-native
acceptance follows from the proposed capability or consumer construction.

The specification F3 route table and exact proposed isolated ROOT controls are prerequisites
for every required descriptor route: pipe/FIFO, redirected regular file with append/nonappend,
local socket and ordinary/raw owned PTY. The pinned VREG ioctl path accepts the narrow request;
no regular-file type exclusion is proposed. Installed driver/security and normal TTY framing
remain actual construction obligations. Capability probes require their exact executing assignment; author fixture units do not establish native frontdoor or full qualification.

Keep pre-capability terminal writes not-admitted/unknown rather than blocking, while retaining
both original short-write attempts when capability exists. Preserve the original late-read
fault control's phase so new checks do not move its fault earlier and make it vacuous.


## Whole normal-native transport repair — approved T1–T9 implementation package

R35 independently reviewed this design and literal intent, the operator explicitly chose A, and R36 grants coherent source implementation after document updates. The original literal received==source condition conflicts
with the measured unchanged normal TTY's LF processing. A marker-only change does not
repair command channels. The complete specification defines recommended option A and
lossless-encoding alternative B, with a specific operator question after whole design
and intent review. No choice, approval, runtime or source grant is inferred. Continue
independent scientific/publication BUILD work while that specific decision is pending.

### Design/review checkpoint

Recover the complete current producer, same reader, original H1–H6, every actual
assertion/helper/case mapping and frozen failed native histories. Review all four
documents together. Attack both real normal-TTY control binding and complete command
source-to-wire delivery, including shared descriptions and independent opens, partial
processing and unavailable observations. Independently assess the operator's wish for
ordinary usable hook routes and substantive scientific failures. Supply T9's concrete
contract question/recommendation and costs; review is not operator approval. No code
until whole design acceptance, disposition of that question and an explicit source grant.

### Coherent existing-owner implementation under the R36 grant

| Existing owner | Complete coupled obligation | Evidence preserved |
|---|---|---|
| Evidence.control_bytes/summary | T2 self-delimiting printable controls, no raw LF; actual-source and actual-received control-slice digest; unchanged keys, both original attempts/null/NONO/512 preflight | Exact attempted P/native returned N/accepted prefix, no fabricated received bytes or duplicate identity fields |
| Evidence.prepare/finish | Full F1–F4 dual baseline, narrow FIONBIO, partial acquisition and independent final both checks; T3 read-only actual presentation facts | Raw B/C/A entire-word oracle, initial NB/unowned controls, no shared termios change; every first/later native cause |
| Evidence.relay/run existing fields | Exact original S and raw relay, ordered actual write metadata in existing command_end/provisional records | Original source hashes/offsets/suffixes, actual syscall counts/unknown state, profile/position facts and original deadlines; no new event or runner |
| Same _events/context | T5 exact-boundary control slices, all independent witnesses, complete source and actual wire/group/file-image forward predicates | Original r.stdout/r.stderr/child/streams unchanged; no CR stripping, synthetic result, scanner filtering, alias inference or ordinary-negative fallback |
| Existing test/helpers | Complete T7 row-by-row migration plus T8 full source/native/complement matrix | Original literal identity-route errors/sentinel, current/original case inputs, masks/args/anchors/decorators/budgets, all H1–H3/process identity/history/signal meaning |
| Existing architecture documents | Correct every changed marker/raw-domain/control/consumer statement in the same reviewed checkpoint | Design/source/runtime/science/closure/main acceptance boundaries |

Both reference preflights must still fit the actual512-supported descriptor domain
before any child; removing the old final LF shrinks source framing by one byte, with
no extra public metadata. Actual received control slices remain unmodified hash input.
The journal remains private LF-complete JSON; native process-row LF framing is unchanged.
T4 source counts never become received wire counts. Actual merged capture is retained
as merged, with real group witnesses and global write order. File images require actual
initial bytes, append/position observations and complete final comparison; no data is
rewritten to manufacture a witness. Unexplained/unknown presentation is incomplete,
not a passing scientific refusal. Required default normal-TTY positives stay mandatory.

### Decisive controls and independent review

T8 retains every F1–F6 control and adds complete normal-mode marker AND raw-channel
positives for LF/CR/CRLF/tab/control/non-ASCII/invalid UTF8/error suffixes, separate
and real shared sinks, regular append/nonappend, FIFO/pipe/socket and ordinary PTY.
Also require full/closed/saturated/short/unknown counts, exact native bytes/profile/
write order and positions, tight/exhausted original phase boundaries, first and later
typed faults, both independent finalizers and safe cleanup. Raw PTY remains a distinct
comparison. No test may strip CR, alter live/shared terminal settings, fake a result,
move a late failure earlier or substitute source-only evidence for native behavior.

Sole production defect seeds must independently expose wrong identity-versus-ONLCR
presentation, altered marker digest, reserialization, missing raw source suffix,
wire corruption, missing/reordered/forged write rows, alias baseline after mutation,
wrong/no borrowed-control restoration and clobbered unowned controls. Preserve original
source/index and all unchanged oracles around each actual 0→nonzero→restored0 run.
Only ROOT's later authorized runtime packet can execute those experiments.

A fresh nonauthor whole source review must read the complete installed owner/reader/
controls and original obligations. Then ROOT runs actual full suites/additions and
all ordinary/native/H5/SDK/assets/MC/common-entry/science/production controls and
current full gates. Existing single-writer closure and reviewed main delivery follow
only their own acceptance. Predicted presentation, a primitive route pilot, an already
negative exit, an authored design or static counts cannot satisfy those later gates.

### H38 coherent chronology and original late-control repair

Update these four existing documents first. Extend the same reader with the complete
T4 write/native-before/native-after monotonic chain, actual command containment and
serial command/global-row ordering. Reconcile serial dual baselines, both setup effects
and the actual accepted-start observation pair without inventing missing timestamps.
Keep timezone-zero UTC samples bound to the original caller interval; only monotonic
values establish serial order. Preserve every old assertion and all original budgets.

Add actual-owner/SAME-reader unmodified positives and recomputed-digest numeric-only
negatives for overlapping/reversed/out-of-command/out-of-global-order observations,
including setup/start and missing/type complements, retaining source/P/N/W/profile facts.
Gate only the original 123456 callback activation to actual public-flags-verify:1 and
assert the real terminal/both-restores/first-fault/fd2-audit chronology. Preserve all old
values/oracles and distinct late-query/earlier-negative controls. Review every original
predicate/helper/control mapping independently; source presence/static populations are
UNRUN. Fresh nonauthor whole source/control/intent review precedes ROOT actual full
native/H5/science/production/current-gate qualification and existing closure/main delivery.

### H40 faithful actual pre-call fixture repair

Capture the existing actual _hook_context before the actual native Evidence(directory)
construction in _r36_native_case. Retain every original source/PID/time/native value,
argument, assertion, result and reader bound. Leave the producer, reader, warm-up owner,
57 H38 controls and all existing guard/native/scientific controls unchanged.

Add one actual-fixture call-order control: wrappers delegate the unchanged real context
and constructor, recording actual entry/return events and returned object identity. The
existing inspection hook checks order before reader decoding, independently of timestamp
inequalities, so coincident real clock samples cannot hide inversion. Then the original
SAME reader and actual post-state/private-source checks must still succeed. Preserve all
positive and mutation obligations; ROOT executes them only after fresh whole source/control/
original-intent review. No new clock, timestamp, budget, result adapter or runner is added.


## Coupled observation, custody, settlement and native-caller continuation

This continuation refines pre-admission diagnostics; it does not retry scientific
execution or recover a terminal fault. The existing producer and SAME reader remain
owners. Unsupported owned/pending/ancestor/visible descendant states still refuse.
A complete foreign-only graph proof may reserve one replacement of the same native
query inside the original single observation deadline. Both actual attempts, raw
channels, immutable protected scope, eligibility proof and original error/time stay
in the journal. No partial sample supplies authority. Missing scope/parents, cycles,
changed/pending protected PIDs, any other malformed field, time/storage failure or
persistent UNKNOWN refuses. A fresh strict replacement must complete capture,
parsing and required journal work before that deadline. The reader independently
reparses both raw samples and reconstructs the protected lineage/attempt chain.

The existing Evidence owner reserves ordered immutable event bytes and a cursor
before fallible event writes. An interrupted write resumes exactly its original
prefix before any higher receipt. Raw and typed-fault failures retain their original
incomplete records; separate linked completion records carry actual later capture
and persistence times. Later custody is never retroactive process admission.
Deferred work runs only in already scheduled descendant/final-drain/wait/observation
windows; terminal finish adds no deferred flush grace. A permanent failure remains
protocol-incomplete. Global fault IDs, native-attempt IDs, logical observation IDs
and successful-run observation counts have separate explicit bindings.

When the existing exited-CLI/open-pipe cap expires inside a native observation,
the retained actual return code/open-pipe state determines the cap cause. Earlier
terminal UNKNOWN, signal, raw or executor faults retain their object/time precedence.
The failed observation remains secondary when the cap was first; no reset grace or
late CLI effect follows. Pending command-failure custody uses existing later windows.

The real native fixture owns its named FIFO in a fresh private fixture directory,
registers cleanup immediately, closes endpoints before identity-bound unlink and
never unlinks a foreign/substituted identity. Its required helper construction must distinguish a cooperative healthy caller from an
undrained pressure caller. Cooperative native_ready consumes only actual owned
already-nonblocking receiver endpoints in bounded4096-byte reads, retains ordered
per-group pieces and concatenates the original post-owner drain once. Undrained
socket/shared-normal-PTY pressure callers perform zero receiver reads throughout
owner execution/readiness/cleanup; their actual select retains its original remainder.
A final-after-owner diagnostic drain cannot change earlier write admission. Actual
read activation/phase/count and owner outcome witness each premise; a policy label
alone is insufficient. Actual read/select return/error/timestamps remain evidence;
only actual select results supply writability. Charge the whole observed read-plus-select
interval once to the existing fixture clock, including exceptions before producer postchecks;
select receives only the original remainder. No deadline reset, overhead grace, writer flag,
buffer, terminal-mode, thread/process or producer API change is admitted. File/shared
routes retain actual images/description groups; normal PTY keeps ONLCR/CRLF-to-CRCRLF.
All52 original healthy routes and all49 dependent corruption prerequisites must genuinely
pass before corruption; expected refusals never replace them. Keep the independent real
concurrent caller and original deliberately undrained/full-pressure/capability negatives.
An absent/stopped/failed receiver retains raw bytes, honest incomplete/nonzero delivery,
other-channel independence and finite safe cleanup. Cooperating fixture scheduling imposes
no early-draining requirement on production launch/cleanup. Earlier deferred-read failures
remain failed history; if readiness still refuses, preserve it and obtain separately granted
causal diagnostics rather than invent a producer fix or weaken admission.

Whole source review must check the coupled state machine and each original assertion,
not merely counts. Original native cohorts and all four real-artifact producer/reader
sensitivities remain mandatory, with healthy baseline, intended causal failure,
exact restoration and the same healthy cohort. New queue/proof/cap/FIFO/drain mutations
supplement them. Preserve each actual fixture outcome separately; all44 actual source campaigns
remain UNRUN until genuine review and ROOT qualification.
The original scientific notebooks/cells/data/MC/assets/H1-H6/native/entry/full gates,
all publication BUILD obligations, protected-main and human review remain owed.


### Coupled chronology and receipt completion repair

Keep this as one existing-owner construction: first reserve/promote native UNKNOWN and real signal chronology, then bind emitted descendant effects to fresh current admissions, close the independent observation schema, and bind deferred typed/raw capture and post-journal commit to immutable original command/window evidence. Update the existing producer, SAME reader and real caller controls together. Preserve original budgets, frozen bytes, cursor order, typed native facts, strict UNKNOWN refusal and scientific execution.

Use the original phase schedule to freeze window beginnings and retain actual closures/admissions; do not add a timer, service, fallback identity, finish flush or new grace. Audit every actionable selector against frozen original XML and literal unrun additions, preserving historical proposals unchanged. Qualify both directions of actual parsing-time signal order, failed proof, stale signal admissions, required-field omissions, complete native-detail substitution and coordinated future/backdated/foreign-window forgeries.

After source-only construction, require whole nonauthor review and ROOT's actual original startup/ownership/native/full-plus-additions and real-artifact sensitivities. Restore source bytes/fullmode/nsmtime and raw/semantic index custody through the existing durable journal owner. A setup/collection error, broken baseline or source count is not evidence the intended guard fired. Full scientific H5 routes, publication, closure, protected main and human acceptance stay owed.


### Original native obligations and ordered semantic receipts

Before any fallible typed snapshot, the existing fault owner freezes the actual native capture obligations: BaseException.args has outer tuple shape, and an actual OSError requests filename, filename2 and strerror. Completion must discharge those exact obligations even when the initial capture had no field assignment. Every complete original value, including native details, stays exact; exception-name text never decides whether OS fields were owed.

The capture window beginning is reserved before a completion, and capture ends before actual completion-byte commit starts. The reader checks those original command/journal/identity/time relations. A later legal resume window may begin behind already pending completion bytes in the queue; only the capture window must precede the completion in journal order. No new timer, replay or finish grace follows.

Every observation binds supported actual phase and launch-state vocabulary, valid UTC/monotonic intervals within the original command, current pre/post-launch scope, and the logical summary to its final actual attempt's raw references and return code. Complete candidates that fail journal admission remain refusal-only with no effects. All original raw, parent-graph, ownership, native bool/type and single-deadline proofs remain required.

Controls must witness the operation they name: failed graph proof and second-query signal detection require actual proof/query activation and cause/count evidence. Parsing-time signals retain their honest earlier-checkpoint scope. A completion-write control first witnesses a reserved completion identity, then arms that exact completion's returned write or admission boundary; capture, serialization, prefix/event write, admission and rollback stay distinct. Healthy/intended-causal-red/exact-restored-healthy actual source sensitivities remain mandatory. Current fixture outcomes remain their recorded actual results; all44 source campaigns remain UNRUN pending whole review and ROOT qualification; all original H1-H6/H5/scientific/native/publication/main/human obligations remain full strength.


### Whole-module repair: authority, original bytes and scheduling

Current work is a source candidate requiring whole independent review and fresh
qualification. Historical failed runs remain failed. An unsupported native process
state in protected lineage must still refuse; neither a harness repair nor a later
healthy sample grants authority to that observation.

The extracted source fixture enters the actual command scope before calling a run
helper directly. Owner-only tests retain startup scope. The production command,
logical sequence, physical attempt, full identity and unexpired admission remain
required for every descendant effect. A fixture tap reads from the actual current
private Evidence owner and records its own unavailable-read diagnosis rather than
raising a second, unrelated path error. Physical query calls are recorded before a
fallible test-supplied boundary returns, so a failed second query remains an actual
second invocation. Scientific execution is never synthesized by these adapters.

Fault chronology uses original observation times and an invocation-local reservation
order to resolve equal-clock causes. A signal detected before an unsupported row
stays first; the opposite actual order stays opposite. This internal tie-breaker
neither rewrites raw native data nor changes the original first-fault grace.

A serializer failure may leave an available immutable original byte prefix. That
prefix is committed only under the existing deadline/cursor rules, never replayed
or reserialized; the incomplete record blocks all higher records and remains
protocol-incomplete. A later legal custody window may persist a frozen fault;
tests separately retain its original incomplete/unpersisted state and the later
linked completion instead of treating mutable final persistence as its past state.
Terminal finish grants no new deferred window.

Public command relay may wait for actual descriptor writability inside its original
remaining window before its first nonblocking write attempt. Start/terminal atomic
controls are unchanged. Readiness is scheduling only: it does not prove identity,
flags, a returned count or received bytes. Native snapshots, whole control words,
exact source counts, raw custody, normal-terminal presentation and independent
receiver evidence remain mandatory. A raised/invalid-count command write latches
UNKNOWN for that exact command/channel/public descriptor before fallible recording;
every later relay of that command channel refuses before another payload syscall.
Readiness, fresh descriptor facts and a later phase never recover its unknown count.
Only a trustworthy exact returned count permits the still-unaccepted original suffix
at an already scheduled checkpoint; zero is known but does not prove progress.
Independent start/terminal control attempts retain their original separate semantics.
There is no fabricated count, replay or enlarged deadline. Deliberately undrained
pressure remains a bounded negative; other-channel delivery and cleanup stay independent
of receiver cooperation.

Native fixture postconditions name the exact launched/captured cohort and exact
allowed cleanup effects. A legitimate refusal cannot be mislabeled full payload,
zero effects or completed scientific execution. Positive controls retain exact
payload, launch and no-unowned-effect assertions. Instrumentation targets a unique
run seam and preserves the original CLI identity/argv. Original scientific inputs,
all nonempty cells, assets, strict errors, process ownership, custody, caller routes,
production sensitivities, full gates, publication BUILD, main and human review remain
full strength. New fixture source requires independent review and qualification; actual source campaigns remain UNRUN.


## H79 — exact command UNKNOWN continuity, separate control attempts

H80 accepted the bounded H79 source; H81 actual full qualification remains FAILED.
The frozen H90 precode state was superseded by the H92 coupled design and H93 whole design acceptance/ROOT intake. H94 source is now authored, with whole independent source/evidence review and later ROOT qualification still separate;
source presence and author units are not accepted transport/scientific completion.
An attempted command payload write that raises or returns None/bool/negative/out-of-range
count may have emitted a real prefix. Retain that actual attempted source range/raw
capture, UNKNOWN returned count and global continuity, original first exception/object/time,
and fixed phase budgets. Latch the exact command ID/channel/public-fd scope before any
fallible diagnostic capture. Later cli-grace, existing cleanup checkpoints, final-drain
and final-observation calls may retain new raw bytes and truthful faults, but must not
issue another command payload syscall on that latched channel. Native writability or a
new snapshot does not recover a missing count. No new retry window or finish grace.

A valid exact short count advances only its accepted prefix; a later original checkpoint
may send only the remaining suffix. Zero stays a known count with zero progress and
unchanged offset. Independent other-channel tails, CLI/descendant cleanup, original
2/5/15/120 budgets, flags restoration and nonzero first-cause exit remain required.
The separate original start and terminal atomic control operations are not command suffix
retries: preserve both actual attempts, including original unknown prefix NONO/counts[2,2]
controls. Do not install a blanket public_write or whole-descriptor shutdown.

Add actual producer relay controls using an owned real sink/write seam: emit a nonempty
prefix then raise or return None/bool/invalid count, invoke the later original phases,
and prove exactly one command syscall, independently received exact prefix, UNKNOWN
binding, original cause/time/deadlines, safe other-channel tails/cleanup/flags. Pair exact
known short/zero/suffix positives and unchanged independent-control complements. A separate
real-production mutation removing the exact relay UNKNOWN fence must cause the intended
no-second-command-syscall assertion failure; all43 earlier recipes remain required. Every
sensitivity remains UNRUN until whole review/ROOT grant, then existing seed_journal healthy
-> sole actual source causal red -> exact bytes/fullmode/nsmtime restored healthy with
same IDs/raw channels/origins. Fixtures/assertions alone do not establish production proof.
Original H76 failed profile, H1-H6/H5 notebooks/data/assets/MC, independent SAME reader,
current native/common/manual routes, gates, protected Git/main and all21/B1-B8/D12 full
scientific/material/formal/publication/human objectives remain owed without reduced scope.

### H92/H93 accepted receiver, handled producer and fixture capture contract — H94 source authored, review pending

The H92 design corrected H91-M1 and received genuine whole H93 nonauthor DESIGN acceptance and ROOT intake before H94 code. H94 source is authored; it has not received independent source/actual-evidence acceptance or full qualification. H90/H91 and all failed runtime receipts remain frozen history.

The designated healthy pressure transport control uses the existing helper with
route="socket-shared", initial=False, earlier_error=True, original
payload=b"PRESSURE\r\n" * (1 << 17), default stderr_payload=None and cooperative
receiver policy. Its expected helper result is2 with the original nonzero CLI cause
first; healthy means full transport/source-wire/control/SAME and native restoration,
not successful science or hook result0. It uses the existing error's relay window,
not a fabricated success deadline. Preserve every original helper result expectation
`2 if earlier_error else 0`; deadline-free successful small cases need not call native_ready.

Both original socket-shared and normal-PTY-shared pressure negatives keep their
original payload, initial/error profiles, native modes, other channel and expected
AssertionError predicate, with explicit undrained policy. There are zero receiver reads
during owner execution/readiness/cleanup, while select still observes the original
native endpoint under its original remainder and single measured elapsed charge.
Final-after-owner diagnostic reads cannot change prior admission. Direct zero-read
assertions run outside every expected-error catch using actual preteardown trace;
an unrelated SAME refusal cannot establish the premise. The required healthy
pressure control independently requires positive actual during-owner bytes and full
source delivery. Opposite-policy real-source regressions must fail these direct
premise/delivery predicates, never merely raise an arbitrary error.

Initialize observation/acquisition/registration and independent producer-outcome / ESCAPING-fixture-latch / per-owner-finish states before the first fallible setup/finish/launch/open/snapshot. Preserve original handlers and cause/deadline ownership as follows.

### H91-M1 — original handled producer outcome and escaping fixture failure

Initialize TWO distinct local observations before fallible work: the producer's original handled outcome/cause and the fixture's write-once ESCAPING-error latch. This is no new owner/framework. Producer Evidence keeps its actual first object, typed native args, available original traceback, original observation phase/time/order/deadline and full history. Record actual run-caught problem, unexpected decision, each Evidence owner's finish-attempt state and finish's RETURNED value separately from an exception RAISED by finish. Never call Evidence.fault again to reconstruct/retime the producer cause or create another grace.

The fixture latch covers original exceptions escaping their original handled region, plus actual new capture/cleanup/emission failures. Reserve that exact object/native original traceback/monotonic observation time before formatting/native diagnostic/IO; later fixture faults preserve their own objects/TBs/native args/time/operation/order. The expected run producer Refusal handled by the original helper is DATA, not automatically an escaping fixture exception. Normal internally handled EAGAIN/EOF branches are likewise not fixture faults. This is actual original control-flow/owner classification, NOT an all-Refusal type whitelist: a preparation Refusal still escapes, a different producer Refusal cannot qualify healthy by type, and a later strict-SAME assertion still fails.

If the original earlier_error=True path completes all original byte/source/wire/control/native/SAME/effect/index/launch assertions, no fixture fault exists and cleanup/receipt succeed, return its ORIGINAL outcome/result2/problem unchanged. Original error=False result0 expectations remain. Do not promote handled producer to throw, change2 to0, suppress incomplete producer evidence or accept any expected-type exception. The designated pressure control additionally needs the actual inert rc7 executor-returncode cause FIRST with the original object/native args/time/deadline and full delivered bytes. Result2 alone is insufficient.

With that handled producer already present, a NEW capture/emitter/callback failure is an escaping FIXTURE fault. The same fixture object/native TB/time must escape after all independently safe cleanup/actual context exit/final receipt, while the producer first-cause record stays unchanged and separately retained. The producer problem neither hides the new fault nor becomes a fake fixture primary. An original escaping assertion plus two actual callback faults keeps the assertion primary and both callback objects/order secondary. With no escaping body fault, the first actual capture/cleanup/emission failure becomes fixture primary; neither success nor a handled result may then return.

Trace the ORIGINAL helper paths explicitly:

| Existing flow | At-most-once owner and return/raise requirement |
|---|---|
| Initial _h4_inert owner before replacement | d['owner'].finish(None) belongs to the first Evidence owner. Track NOT_ATTEMPTED→ENTERED→RETURNED(value) or RAISED(object/TB/time). Never call it again. A raise escapes as fixture primary and must not continue to create the actual native owner; a returned value remains an independently recorded return, preserving the original decision to proceed, never feeding it into the later owner's problem/result or fabricating result2. |
| Actual native owner setup/acquisition/prepare | Initialize local states before creation/open/register/snapshot. If owner does not exist there is no finish target; preserve safely acquired capability cleanup only. owner.prepare exception is an original escaping fixture error even if Refusal. Reserve it BEFORE original owner.fault or diagnostic IO, then independently attempt the existing owner.finish(error) path at most once when actually owned. A reporting failure cannot skip that original finish/other safe cleanup or replace the prepare object. Returned finish problem is data; raised finish is secondary to prepare. |
| Original run catch | Keep actual problem=error and the original handler's unexpected decision. The actual expected executor-returncode Refusal from inert rc7 remains handled and its producer record/deadline unchanged. A non-Refusal marked unexpected is destined to rethrow: reserve its actual fixture identity/TB/time at detection while preserving original post-run/finish cleanup before propagation. Normal inner EAGAIN/EOF handling is untouched. No generic type-based healthy classification. |
| Original success report | Keep actual_report('success') only in its original problem-is-None branch. An exception raised by it is an escaping fixture fault, not a manufactured handled producer outcome. |
| Actual owner.finish(problem) after run | Same actual owner as prepare; prepare-failure and post-run finish paths are mutually exclusive. Mark ENTERED before call and never retry after return OR raise, including partial close. A returned problem remains actual producer/outcome DATA and is retained separately from incoming problem. An actual raised finish exception escapes as fixture fault even when the producer problem was already handled. Preserve original finish order, native/public cleanup and full cause history. |
| Post-finish observation/inspect/full original assertions | Post snapshots, final-after-owner drain, inspect, _events and every original source/wire/effect/index/launch/native predicate remain. Their actual escaping error becomes fixture primary if none exists, even with handled producer. No second finish can rescue failed evidence; a returned problem cannot prove completeness. |
| Unexpected rethrow or valid original return | Preserve original unexpected object's saved native TB/time through cleanup. With no fixture latch and all predicates complete, return original dict/problem/result unchanged. Otherwise propagate exact first fixture object after actual context exits and final receipt handling, retaining producer cause independently. |

The first inert Evidence owner and the later actual native Evidence owner have separate finish states. The latter has mutually exclusive prepare-failure/post-run single-finish paths. A returned problem and a genuinely raised finish exception MUST remain distinct. Capture existing producer time/deadline facts before original finish resets its deadline field; do not replace its original command_cleanup_deadline/settlement cap or confuse fixture observation time with producer time. Record unresolved/partial states honestly; do not invent an owner or retry partially completed finish. Fixture diagnostic failures belong in the local fixture receipt/latch, not in a rewritten producer first cause.

Direct REAL-COMPOSITION paired controls, all prospective/UNRUN: require the designated cooperative socket-shared initial=False/earlier_error=True pressure helper actually RETURN its original outcome/result2, actual problem identical to the original executor-returncode first object from inert rc7, full source-wire/control/SAME/native restoration and positive actual during-owner read bytes. Record returned versus raised explicitly and assert returned/no fixture escape OUTSIDE generic expected-error credit. Keep the whole original52 matrix (26 expected2 and26 expected0). A sole future actual-source promotion-to-throw mutant must fail that exact helper-return/result2 predicate; Refusal is not an acceptable substitute result.

On the same genuine handled-producer path, independently induce actual capture, final-emitter and first original callback faults. Require their exact fixture object/native TB/time after cleanup, producer first object/record/time/deadline unchanged, all later independently safe callbacks attempted and actual existing stack empty. Add original escaping prepare/SAME/body assertion plus TWO real callback faults, and actual finish-returned-problem versus raised-finish and both owner states/partial entry/no-second-finish cases. Real owner/ExitStack/endpoints and source integration over complete acquisition/cleanup paths are required; a copied helper, isolated latch unit, artificial error list, already-result2 or any-error waiver is insufficient. Later accepted implementation must supply exact actual source anchors/inverses and genuine healthy→intended causal red→exact same-ID restored healthy evidence. No test/source/runtime grant or old44 retirement follows from this design.

Freeze already-read ordered bytes plus exact length/hash/base64, original argv/cwd/Popen PID and stored returncode, prior native observations and original witness path/read/parse/identity observations while resources remain owned. Never poll again merely for diagnostics. UNOBSERVED/null is distinct from actual returned empty bytes, EOF, partial prefix or TimeoutExpired.output/stderr=None. A diagnostic reference parse grants no SAME, absence or signal authority. Preserve producer original time/deadline and fixture actual first-escape object/TB/time separately before any diagnostic work.

Then independently attempt every original child cleanup and actually known identity-bound
witness action under its original order/identity/bounds. Guard each original ExitStack
callback at registration so its actual failure is captured immediately and cannot skip
later callbacks. Record acquisition versus registration, including partial pair setup;
clean only safely known acquired-but-unregistered capabilities once, never double-close
registered resources or invent FIFO identity. No second Evidence.finish, new signal
ownership, extra wait/poll/grace or global absence claim is admitted.

Run guarded explicit resources.close() on the actual existing stack, retaining each
callback failure and leaving the outer stack empty before final propagation. Hold the
escaping fixture exception through the actual outer context exit; an inner bare raise is insufficient
because a later callback could mask it. Callback guards retain individual faults, not
only the final close exception. Frozen preteardown facts plus separate cleanup outcomes
form a postcleanup receipt on the existing diagnostic sink. Emit only after all cleanup;
do not reobserve endpoints/witnesses after close. Emitter failure is secondary to the
held first escaping fixture cause and cannot prevent completed cleanup. A handled producer problem is independently retained and cannot hide an actual emitter failure. An unavailable sink is explicitly
unretained. With no escaping fixture body failure, the first capture/cleanup/emitter error becomes FIXTURE primary, including when original producer problem is handled.
After actual contexts/emission, propagate the same first FIXTURE object with its saved original traceback through the native traceback mechanism. If no fixture fault exists and all original predicates completed, return the unchanged original handled outcome/problem/result, including genuine earlier_error=True/result2. Never throw a producer problem merely because non-null, convert2 to0, call finish twice or accept incomplete source/SAME evidence.

Only the real native caller may query an otherwise unobserved post-state: at most once
for the actual still-owned shared writer, using existing _r36_native_snapshot under its
actual original tick+300 deadline. Existing final snapshots, missing/unowned writer,
unestablished deadline, exhausted time or unavailable capability mean zero new queries
and null/partial with reason. Check positive remaining time before and actual time after;
retain elapsed/error/partial/overrun, never retry/reset/query per logical fd/double debit.
Synchronous native calls have cooperative budgets; checks do not interrupt a blocked syscall
or establish a hard wall-clock guarantee. Overrun authorizes no further diagnostic/admission
work. The inert helper uses existing post observations and adds no query. This diagnostic
cannot repair the witness, admit SAME or grant another census/process observation.

Prospective controls cover both actual caller owners and the native helper: before launch,
partial acquisition/registration/initial snapshot, witness/partial-read/strict-reader faults,
first escaping fixture body error plus independent snapshot/emitter/two cleanup failures, no-escaping-body-error first
capture/emitter/cleanup failures, every later callback still attempted, exact first
object/TB/native args/time, immutable bytes before actual endpoint closure and final receipt
with cleanup outcomes. Use the real existing ExitStack and real owned endpoints, not fake
close or inner-finally-only proof; verify actual stack empties and endpoints close where safe.
No-time/unowned/existing-snapshot and query-error/overrun controls expose extra native work.
Bounded shared-seam units and source integration guards do not replace separately authorized
actual real-caller/kernel/witness/source-campaign qualification.

Three original lifecycle/corruption positive prerequisites remain OWED after correct
second-query UNKNOWN refusal. Exactly one completely proved foreign replacement, original
observer/firstcause/raw predicates and all fixed budgets remain; no filtering, normalization,
extra retry or green-seeking rerun. The missing normal-PTY cause remains UNKNOWN. None of the
five qualification failures is declared resolved by this design. Fresh whole nonauthor design
review/ROOT acceptance precede code release, then whole independent source review and separate
ROOT full/native/scientific qualification and all original plus new actual causal/restored
controls precede canonical closure/protected delivery/human publication acceptance.
Canonical OPEN/BUILD findings:
`papers/AutomatedReviews/2026-10-21-hook-native-fixture-premises/infra.md` §§1.1–1.2.


### H94 historical author evidence; H96 corrective work after H95 review

H93 whole nonauthor review accepted the complete H92 design and ROOT intaken that bounded design. H94 authored the prior coupled source candidate. H95 identified incomplete known-witness enrollment and unregistered LIFO; H96 authored the complete corrective construction, preserving: cooperative versus undrained receiver premise, original handled-producer result2 versus escaping fixture latch, precleanup observed-fact freezing, guarded actual callbacks and original child/known-witness actions, explicit empty original ExitStack/outer exit before final receipt and exact first-exception propagation. The optional shared-writer diagnostic uses only the existing positive tick+300 remainder; inert helper adds none. All original assertions, producer, strict SAME, native budgets, scientific objectives and old source-control obligations remain.

The original54 author baseline is 53PASS1FAIL (socket negative DID NOT RAISE); no failure is erased. Source implementation and bounded author development are complete and not independently accepted. Canonical findings remain OPEN/BUILD; full Verify and actual source campaigns, full-native/scientific qualification, closure and protected delivery remain ROOT-owned and owed. H86 three correct UNKNOWN positive prerequisites and missing PTY witness remain unresolved.


H94 terminal author evidence recorded 2026-10-21T19:46:29.941746+00:00. The measured receipts are in `outputs/continuity/hook-H93-complete-fixture-source-author-20261021-r94/runtime.json` and full raw/XML, with whole-source controls and images in `evidence.json`/`source-images.json`.

| Actual bounded receipt | Passed | Failed | Errors / skipped | State |
|---|---:|---:|---|---|
| Original unchanged baseline | 53 | 1 | 0 / 0 | Socket negative DID NOT RAISE; retained |
| Initial authored development | 84 | 0 | 0 / 0 | Retained source/raw/XML |
| Expanded development before inert fixture correction | 89 | 5 | 0 / 0 | Missing inert index-read fixture; all five complete bodies retained |
| Complete current development | 94 | 0 | 0 / 0 | Same expanded IDs, author evidence only |

The source extends the existing owner scopes rather than adding an executor or acceptance reader. Registration tracks a callback that appended before raising, so a pair closes once; original actual owner failure finish is attempted once when its already acquired root capability exists, and never retried after entry. Communicate attempts are recorded before invocation, keeping UNOBSERVED, native `None`, actual empty/EOF, and TimeoutExpired partials distinct. Frozen bytes precede original cleanup; individually guarded original callbacks run LIFO, actual stack exits precede final receipt, and a new capture/cleanup/emitter fault cannot hide behind a handled producer problem. The complete real-caller source is covered by source-binding guards and bounded helper/caller controls; real Popen/kernel/witness execution was not performed here.

Every historical original source recipe remains whole and UNRUN; the real-caller receive-omission recipe has an indentation-only current-source derivative, with the historical object preserved. New actual-artifact recipes and exact inverses are DATA/UNRUN. No protected entry or hook is loaded by this work. Full native/scientific/once-only/kernel/byte assertions, UNKNOWN/one-retry, original deadlines, all scientific BUILDs, canonical closure, main delivery and human review remain owed.


H94 final observational-source evidence supplement (2026-10-21T19:53:46.267290+00:00): the current same-ID bounded cohort again passed with passing-output JUnit logging. Independent test-observer teardown exports ONLY already-held precleanup/native/fault/callback data. It does not reobserve endpoints, retry a failed fixture emitter or admit a new budget. An actual export/undo failure is retained separately and propagates the already-held first fixture object/native traceback when present, otherwise its own first error, after the original monkeypatch cleanup attempt. This is diagnostic source behavior, not merely logging configuration; its source binding is checked, while deliberate export-failure source campaigns remain UNRUN. All prior source/runtime attempts and lost-passing-output limitations are retained. Final XML contains the complete passing observations; no transient private journal is claimed durable beyond the actual retained caller data. Whole source/actual-evidence review and ROOT full qualification remain pending.


### H96 complete H95-M1/M2 source repair — author complete, independent review pending

H95 whole nonauthor review/ROOT intake is REQUEST_CHANGES, not H94 source acceptance. Its two MAJOR obligations are coupled with the entire accepted H92/H93/H94 construction. In `_observe_real_hook_child`, enroll every actually obtained witness immediately in original file order before any next fallible witness operation; no new read/census/poll/retry/identity is granted. In `_H94FixtureCapture.register`, unwind acquired/unregistered callbacks in reverse acquisition order while keeping already registered callbacks on the same original ExitStack and preserving postappend detection/once-only original function+args.

Direct original-helper controls must independently fail second exists/read/parse/identity after the first obtained identity, cross the known safe stop with a secondary cleanup fault, preserve exact first object/native traceback/original observation time, partial UNOBSERVED facts, original child then known cleanup and remaining independently safe actions. Missing-first invents no identity; healthy and delayed observation retain original file order. Pair controls must cross both registration positions/pre-postappend and both actual post-real-close faults, require exact [second,first] original function/args/ordinal order once, same registration-first object/TB/time, both native descriptors EBADF, at-most-once finish and actual empty original stack/outer exit before receipt and propagation. Count-only/EBADF-only controls are insufficient.

The original94 bounded baseline is measured green before source repair; no full source/native/scientific acceptance follows. All44 historical+9 H94 actual source campaigns remain UNRUN; new exact actual-artifact causal recipes remain DATA until separate ROOT grant. Canonical findings stay OPEN/BUILD; full module/native/real notebooks/H1–H6, three UNKNOWN positive prerequisites, unknown normal-PTY witness cause, all21/B1–B8/D12 scientific/formal/calibrated-band/G4/main/human and protected entry duties remain owed. No service/backend/registry/Git/lease/book/closure authority is added.


H96 bounded author evidence recorded 2026-10-21T20:34:53.432355+00:00: unchanged original94 baseline PASS94; current original94 plus21 literal/direct-source controls PASS115/0FAIL/0ERROR/0SKIP with complete passing raw/XML receipts. Actual original witness helper controls preserve first-known enrollment through second exists/read/parse/identity faults (with and without a secondary safe-stop fault), no invented missing identity, healthy/delayed original order and remaining known cleanup. These use explicit inert index/launch/identity/reader boundaries, not genuine Popen/kernel/witness qualification. Actual original native-helper pair controls verify original function/args/ordinals [second,first] for both registration positions/pre-postappend, with and without both after-real-close faults, exact registration-first object/nativeTB/time, real EBADF, at-most-once finish and original empty-stack/outer-exit receipt. No budget, route, producer, SAME or original assertion was weakened. Whole source/evidence review remains pending; all53 old plus2 new actual source campaigns, full current module/native/real notebook/H1–H6/scientific/G4/main/human duties remain owed. Receipts and exact images/inverses are in `outputs/continuity/hook-H95-complete-cleanup-source-repair-author-20261021-r96/`.
