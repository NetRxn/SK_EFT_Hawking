# Existing notebook commit hook: candidate context and complete execution

Current coupled continuation: **H96 SOURCE authored after H95 whole REQUEST_CHANGES; fresh independent review pending; whole source/evidence acceptance and ROOT qualification remain pending**.
H85 accepted the prior source; H86 complete qualification remains FAILED at its recorded pin.
H87/ROOT accepted the failed-runtime diagnostic; H89/ROOT requested complete precode correction. This author
work is not independent source/runtime acceptance. Preserve every original H1–H6/H5 objective,
all five actual qualification obligations, all44 UNRUN source campaigns and scientific BUILDs.
Fresh whole nonauthor design/source review and separately authorized ROOT qualification remain
required before closure, entry activation, protected delivery or publication acceptance.

### Five-root fixture and preparation contract

ROOT alone prepares normal locked uv runtimes with an explicitly assigned writable task-local
UV_CACHE_DIR propagated through existing _env/_call. Preserve uv sync --locked, HOME, source,
lock/Rust/package inputs and actual prefix project-kernel installation/origins. Cache placement
is not setup success or67 scientific passes; missing permitted resources require literal failure
and separately authorized resolution. The hook installs nothing; this author task runs no UV/runtime build.

The actual source observer extracts cause_order with its production dependency closure and
invocation-local CAUSE_SEQUENCE=itertools.count(1), SIGNAL_CAUSE_ORDERS={}, SIGNAL_EVENTS=[]
and SIGNAL_CURSOR=0. Keep the inert process/signal boundary, native argument and history
oracles, local equal-clock order and honest persisted=false unit owner; no copied observer.

Known prewait blocking is an empty writable result BEFORE command os.write during the original
final-drain seam. The existing post-wait final-observation checkpoint may emit only its known
remaining suffix. An attempted write that raises or has invalid count stays UNKNOWN and fenced;
readiness or later phases never recover it. Keep all four original tail variants, exact8/10 bytes,
first.25/D15.25, capture.5, wait2/cost1.75, broken stdout independence and fixed2/5/15 windows.
Unconditionally restore borrowed seams and finish each Evidence owner once around assertions;
retain the original error plus later cleanup causes and verify actual event/root FD closure.
Do not call a not-admitted journal complete in the strict SAME reader.

The original before/within OS-capture controls retain all12 IDs and six full damage predicates.
Within interrupts RIGHT strictly before inheritedD while LEFT/native OS obligations stay partial,
then requires actual safe INT. A distinct exact-D complement calls original typed_native/check_time:
no late INT; KILL only with independently valid ownership, otherwise UNKNOWN/refusal. Exercise all
six original corruption predicates on that expiry journal too. No blanket2-to9 replacement,
completed capture substituted for partial capture, altered >= guard or extra window is permitted.

Preserve all1233 old IDs/order and every original assertion except these explicitly described
fixture-premise migrations. All44 exact causal recipes/selectors/restoration duties remain;
review any shifted anchor prospectively. Fresh healthy intended cohort, sole actual causal
artifact red, exact bytes/fullmode/nsmtime/index/admin restoration, empty durable seed journal
and same-ID healthy restored run are mandatory. Author units do not substitute for postreview
qualification, scientific/H5/full gates, recorded closure, protected delivery or human review.

Status: **Lifecycle refinement — operator-approved A, current fixture repair.** Keep the reviewed source-to-wire/native-control mechanism, process chronology and actual context-before-owner order. H86 full qualification is failed; H87/ROOT accepted its diagnostic construction requirements. H92/H93 accepted the exact controlled-error pressure pair and complete nonmasking callback/cleanup/postcleanup-receipt construction. H94 has now authored that coupled fixture source; author development is bounded evidence, with whole nonauthor source/actual-evidence review still pending. The producer and strict SAME reader remain exact. Fresh whole nonauthor design/source/original-intent review precedes separately authorized ROOT full native/runtime/production/scientific qualification. Author development is bounded evidence only; every original positive prerequisite, UNKNOWN/one-retry bound and scientific BUILD remains owed.
Finding: `papers/AutomatedReviews/2026-10-19-precommit-notebook-worktree-routing/infra.md` §1.1.
The existing hook and reader are the only implementation owners. The accepted H4c refinement below precedes its R30 source repair. Design acceptance, source acceptance,
real runtime controls and publication acceptance remain separate.

## Objective and actual evidence boundary

The existing notebook leg must execute each eligible staged notebook's admitted bytes in the
committing candidate, preserving its original notebook-directory relative assets, using actual
candidate project imports, and executing every original nonempty code cell with strict errors.
Primary same-named files, empty data branches, skipped cells and permitted errors cannot
substitute for the corresponding measurement. This is infrastructure BUILD supporting
publication qualification; original scientific constructions and publication gates remain owed.

The ordinary common entry can invoke the primary public script while validating a linked
candidate. Script origin, admitted input bytes, asset cwd, project imports, kernel origin and
actual strict cell execution therefore need distinct observations. The installed nbconvert
filename path sets the notebook parent as the execution directory; stdin must preserve that
coordinate explicitly. Original Phase5b synthesis cell12 reads Path("..")/docs/vestigial_mc_results.
A missing legitimate data directory remains DATA_UNMEASURED/OWED; a clean empty branch cannot
replace consumption of scientific inputs. Installed skip/error/config behavior requires the
explicit H3 configuration and fresh postflight evidence, rather than --execute or rc0 alone.
Exact source observations and failed receipts belong to the assigned reports; they are not
retroactively converted into runtime acceptance by this specification.

## Existing ownership and both layers

`scripts/pre-commit-notebooks.sh` already owns this commit leg. Preserve the installed local
common guard order and `pre-commit-sync.sh`'s inherited Git-dir/common-dir worktree skip.
Workspace `src/core/workspace.py` owns shared resources; ADR-012 P10's `target_files` owns
logical paths within a caller-selected active checkout. Continuity, repo-state and harness
helpers intentionally identify different contexts. They are not a second hook root resolver.
Extend the existing public script's Git-context selection; no new selector/API/module/service,
execution engine, readiness gate, registry or ledger is introduced. Private/local hook
canonical source remains outside authority and must not appear in public text.

The runtime owners already exist: the project's locked uv environment and declared ipykernel,
nbconvert, nbclient and Jupyter kernelspec/trait configuration. Root prepares them normally;
the hook never installs packages or kernels. Existing notebook_exec remains the later corpus
check with its own cache/resource policy. Agent-layer adversarial/claims/figure reviews judge
fidelity and substance, but do not themselves bind Jupyter child origins or actual execution.
Whole independent design and later whole source/control review remain mandatory. Scope keeps
scientific BUILD and accurate prior corrections at full strength.

## Decision H1 — recover and validate the committing checkout through Git

Resolve Git administrative identity BEFORE changing directories. For direct/manual invocation,
Git starts from the caller's current checkout, not the script's directory. For invocation by
the common hook, inherited Git administrative context remains authoritative even when cwd has
already changed to primary. Query Git's absolute per-worktree Git-dir and common-dir, refusing
Git errors, bare repositories and unavailable/ambiguous identity instead of treating them as
an empty staged population.

For an ordinary primary checkout, require a validated ordinary common Git directory and its
checkout. For a linked checkout, use Git's own per-worktree `gitdir` back-reference to that
checkout's `.git` marker, then validate the reciprocal marker, resolved common directory and
per-worktree identity with Git from the recovered checkout. A cwd-only `--show-toplevel`,
a directory basename, a fixed parent walk, a workspace sentinel, or the primary script path
is not this decider. Require the recovered top-level, marker and administrative identity to
agree. Reject missing/stale backlink, moved/deleted checkout, contradictory explicit work-tree
context, symlink escape and foreign administrative context; do not guess another checkout.

This extends the existing hook's root-selection leg, rather than a second general
checkout resolver. No hook environment variable is cleared or spoofed to bypass an inherited
context. The implementation reviewer must challenge relative and absolute Git-dir forms and
worktree paths with spaces. It must demonstrate the ordinary common-hook path; a manually
constructed environment alone is insufficient. Support remains ordinary primary repositories
and their Git-linked worktrees; an unsupported bare/separate-Git-dir layout refuses with an
explicit diagnostic rather than silently validating primary.

Record actual entry-script origin and hash, validated active checkout, Git administrative
identity, and actual executed project command. The existing common hook may still invoke the
primary copy of this public script. Do not label that source as the candidate script. There
is no dispatch to a second hook or new selector. For first rollout, root must place the
independently reviewed public-script repair at the existing invoked primary entry point before
crediting an ordinary common-hook pilot; candidate-only source cannot change an old primary
entry point. All local/private hook installation and guard changes remain outside this design.

## Decision H2 — eligible index population and exact notebook-byte admission

Read NUL-delimited paths/status from the active index with Git and check the command's actual
exit status before interpreting its population. Disable rename detection for this enumeration:
a rename is a deletion plus an addition and the added destination must execute. Added, copied
and modified regular `.ipynb` blobs are eligible; deletions are reported as deletions and are
not executed. Type changes, unmerged entries and nonregular notebook modes are refused. A
no-notebook commit reports a measured empty eligible population and exits without claiming
that any notebook ran. Do not count an enumeration error as that state.

Use literal NUL-delimited names throughout. Spaces, tabs, newlines, leading dashes and shell
metacharacters remain filenames, never shell arguments expanded by word splitting or eval.
For each eligible path, require canonical containment in the validated active checkout,
regular-file status, and an index stage-0 blob. An outward symlink or a missing working file
is a failure. A fully staged addition must be supported even though absent from HEAD.

Choose an explicit policy: **refuse partial notebook staging**. Compare the actual raw indexed
blob bytes to the current active working file, not merely its mtime, basename, code-cell hash
or Git's normalized diff. Only exact equality admits execution. Do not stage, overwrite,
normalize, clean or regenerate the notebook to make the condition hold. This avoids pretending
a working-file execution tested different staged bytes and avoids building a second index-tree
execution environment. Recheck the full eligible index identity and notebook input hashes
after execution; movement during the run withholds success.

## Decision H3 — notebook-relative assets, candidate imports and complete strict cells

### H3a. Preserve the original asset coordinate for every notebook

For active checkout A and admitted literal notebook file F, run the existing nbconvert CLI
from D=parent(F), the same directory used by filename-based execution. Feed the unchanged
admitted bytes via supported --stdin to avoid nbconvert glob interpretation of literal
filenames. Stdin contributes no filename-derived resource path, so the kernel inherits D.
This preserves notebook-relative assets for root and nested notebooks while leaving cells
unchanged. Project-root cwd is removed as a design choice; there is no staged-notebook or
basename exception. The CLI output basename/directory are explicit and invocation-unique.

Under this contract, the unmodified Phase5b cell12's Path("..")/docs expression reaches the
candidate docs directory. A real routing discriminator must read an explicitly non-scientific
asset in candidate while distinguishable primary/parent assets exist, with actual kernel cwd
and read bytes recorded. The original source consumer's directory/glob access must also be
witnessed. Do not invent MC JSON or call missing legitimate results a successful data read.
Its currently absent data is an explicit DATA_UNMEASURED/OWED pilot row until real results and
provenance exist. A clean execution of its empty branch establishes only that branch's
execution, never MC analysis or scientific input acceptance. Record the limitation beside
the runtime result; never silently use that branch as the asset-read positive control.

### H3b. Practical root-prepared candidate runtime, through existing owners

Before hook implementation/pilot acceptance, root prepares the candidate's ordinary project
virtualenv using existing `uv sync --locked` against its unchanged pyproject/uv.lock. Normal
Rust/dependency build needs belong to that existing root-owned preparation. Do not copy or
symlink primary's editable environment, edit the lockfile, silently install during a commit,
or invent an exception for an unavailable candidate .venv. Record real preparation
commands, origins and errors; unavailable preparation is nonzero refusal with the exact
preparation action, not successful execution. This design does not perform that preparation.

Use the candidate .venv/bin/python to invoke the existing nbconvert module. Root uses that
same interpreter and existing `ipykernel install --prefix <candidate .venv> --name <name>` to
prepare the Python kernel names requested by admitted notebook metadata, deriving names from
the actual selected notebooks rather than a parallel kernel list. Missing metadata uses the
existing Python default. Preserve the original metadata/name in input; reject an unsupported
language/name explicitly rather than substitute another runtime. The source-only current
corpus contains different project/Python kernel names, so pinning every file to python3 is
not a valid unexamined compatibility assumption.

For only the execution child and its existing metadata preflights, set PYTHONPATH exactly A
and JUPYTER_PATH to the candidate virtualenv's share/jupyter. Record original/effective values
and rationale; do not append an inherited primary import list. Existing jupyter_core.paths
places JUPYTER_PATH first; existing kernelspec lookup must actually resolve the admitted name
to the prepared candidate resource directory and absolute candidate interpreter argv. Use
existing kernelspec CLI metadata, require the real kernel.json, ordinary local provisioner,
no undeclared env/import override and unchanged spec bytes. Missing candidate kernel cannot
fall back to user/system/native primary. Do not assume a KernelSpecManager CLI pin propagates:
inspected KernelManager constructs that manager without forwarding the application's config.

A child-scoped empty invocation IPYTHONDIR isolates ambient user profile startup without
changing notebook cells or the user's directory. No Git guard/context variable is cleared or
spoofed. These are transparent normal candidate runtime settings, not provenance masking.
Actual in-kernel cwd, sys.prefix, executable, src and relevant module paths/hashes are required
in the root pilot. The virtualenv executable may be a normal base-Python symlink; sys.prefix
and loaded source distinguish environment ownership. Wrong primary origins are refused, not
relabeled. Keep original code, dependency versions and actual imports; no runtime callback,
bootstrap cell or second execution engine is introduced for clean execution.

Notebook execution uses active working project source, not a hermetic reconstruction of the
whole index. Before crediting commit-runtime binding, refuse unstaged/untracked importable
project source and unstaged project/lock divergence, including the actual imported source
population. Root must reserve the pilot/index/source/config scope against concurrent mutation.
Recheck observed source/spec/config identities after; endpoint hashes attest endpoints only,
not absence of arbitrary transient edits. Concurrent unrelated science is not called static.

### H3c. Enforce strict full-cell behavior through existing CLI traits

Do not infer full execution from --execute, source cell count, saved execution_count or rc0.
The existing NotebookExporter must have default_preprocessors set to only the existing
ExecutePreprocessor and additional preprocessors empty. This prevents ambient TagRemove,
RegexRemove or another preprocessor from deleting/altering cells before execution. Pin
NotebookExporter enabled and normal FilesWriter/output destination; no postprocessor.
Use the ordinary existing AsyncKernelManager; refuse custom managers/provisioners, callbacks
or extra kernel arguments outside the admitted standard runtime.

Pin these existing ExecutePreprocessor effective settings through explicit CLI configuration:
enabled=True, admitted kernel_name, timeout=120, force_raise_errors=True, allow_errors=False,
allow_error_names=[], raise_on_iopub_timeout=True, interrupt_on_timeout=False, record_timing=True,
extra_arguments=[] and skip_cells_with_tag="". The skip trait is a string, so preflight refuses
an original code-cell tags list containing the empty string. No admitted tag can therefore
match the skip predicate. Nonempty skip-execution/custom tags execute; raises-exception tags
cannot permit errors because force_raise_errors overrides that allowance. Do not modify or
strip tags/cells in the notebook. Preserve blank/whitespace-only code cells and report their
engine-defined non-executing status, without crediting them as kernel execution calls.

Installed JupyterApp/traitlets re-merge CLI config after file/environment config. Use the same
exact CLI/env/cwd with existing --show-config-json for preflight and pin/refuse effective
behavior before the one actual notebook execution. Unknown/configured preprocessors, cell
hooks, writers/postprocessors, managers, extra arguments or execution modifiers cannot pass
by omission from a hand-list. Admit only the explicit execution/exporter configuration and
required ordinary logging/output traits; unknown active configuration is a visible refusal.
Do not assume an empty --config file disables base/system/environment configuration. Pin DEBUG
logging for actual engine execution events; conflicting suppression or unknown config is
refused. Capture config inputs/effective values and recheck their observed identities. This
handles normal ambient configuration, not arbitrary hostile executable Python on the host.

After the one run, the existing hook inspects the separate executed result and actual engine
logs: complete original cell sequence/types/sources/tags and provided IDs remain; every
nonempty code cell has a fresh sequential kernel count, fresh record_timing input/reply/idle
observations within the actual run, corresponding ordered DEBUG execution events and no error
outputs. Originally absent optional IDs may be normalized in the temporary output by existing
nbformat, but no original provided ID or source may change. A skipped cell carrying stale
successful outputs/counts cannot satisfy this postflight. Counts alone are insufficient;
missing fresh events or altered/omitted cells is nonzero refusal. No custom executor replaces
nbconvert; these are admission/postflight checks inside its existing hook owner.

A missing runtime, config refusal, wrong source origin, kernel failure, timeout, cell error,
missing execution evidence or failed postflight returns nonzero. Capture the original run's
error and do not execute scientific code a second time just to print its traceback. Clean
original notebooks execute unchanged once after any separate witness/poison runs are restored.

## Decision H4 — complete observation, bounded cleanup and actual signal authority

**The complete observation, individual signal admission, native-control lease and coupled transport construction are the approved implementation contract. Historical rejected revisions remain rejected at their recorded pins. This candidate still requires whole source and actual native/runtime acceptance.**
It extends the existing process_rows/observe,
reconcile_identity, signal_job and signal_descendants consumers inside the existing run owner.
There is no new scanner, supervisor, executor, registry or alternate success path. Retain unique
per-invocation/per-notebook outputs, normal stdin execution, cumulative available buffers,
first-failure ownership and one scientific execution. The contract below concerns the hook's
own observations and issued signals; H4d exposes the installed library boundary explicitly.

### H4a. Admit a complete process observation before using absence

Use the existing native /bin/ps -ww -axo pid=,ppid=,pgid=,lstart=,stat=,command= query,
with child-scoped LC_ALL=C/LANG=C and its existing finite two-second subprocess timeout.
Capture its actual argv, observation sequence/time, rc and raw stdout/stderr bytes (including
partial bytes exposed by a timeout). Do not overwrite those channels with a success summary.
A failed launch, timeout, nonzero rc or nonempty diagnostic stderr is an unavailable sample.
No fallback query, command-name search or parser repair supplies a replacement population.

Decode stdout as strict UTF-8, never replacement decoding. Require nonempty LF-framed output
with a terminal LF; reject NUL, partial final rows and blank/interior empty rows. Parse every
row before committing any result: exactly the requested structured fields, followed by a
nonempty command field. Whitespace delimiting the native columns is format padding; retain
the entire remaining command field, including internal/trailing characters, without token
splitting, basename matching, lossy decoding or command normalization. Reject control bytes
that make row framing/field identity ambiguous. An unsupported command encoding or layout
refuses the observation; it does not cause that row to disappear.

PID/PPID/PGID fields must be ASCII decimal integers in native signed-pid range, without signs,
Unicode numeric substitutions or trailing text. Zero can describe an unselected kernel/parent
or group field; it is never a signal target or trusted invocation ancestor. PID keys must be
unique: duplicate equal rows are also invalid, not last-wins. Birth is the complete C-locale
weekday/month/day/HH:MM:SS/year field: validate the actual calendar date, time ranges and
weekday agreement, and retain all original birth tokens for equality. Missing/placeholder/
invalid birth information makes the whole sample unavailable. Validate STAT against the
supported native dialect, not merely a nonempty string. The inspected macOS ps manual defines
initial I/R/S/T/U/Z and its documented +, <, >, A, E, L, N, S, s, V, W, X modifiers. Unknown or
missing state characters refuse; a native dialect outside that measured grammar needs explicit
source/capability and runtime review before support is claimed. Z rows remain observable
identities but are never live signal targets. Do not silently drop unsupported native rows.

Require the hook observer's known live positive PID in the fully parsed table as a capability
and nonempty-population witness. Capture this PID locally; no process-name whitelist is used.
The native command's successful completion through EOF, valid framing, parsed entire population
and observer witness together admit a sample. A parseable subset, empty output, missing witness,
or unavailable row cannot establish absence. No partial dictionary escapes the parser on error;
owned identities, pending history, transitions and resolutions remain unchanged for that sample.
Record the exact refusal/row position and original raw bytes in invocation evidence.

This is a complete admitted stream from the native all-visible query, not a proof of an atomic
kernel snapshot, arbitrary host visibility or absence of unobserved transient processes. The
parser cannot prove that a trusted native producer secretly omitted an otherwise well-formed
row; that limitation must stay explicit. Only this admitted sample can resolve a retained PID
as absent, establish/extend ancestry or authorize a descendant signal. A structurally malformed
retained row must never become an absent-PID resolution. A subsequent valid sample can support
new cleanup decisions; prior TERMINAL observation failure remains recorded and prevents a clean success
claim for the invocation. Only the coupled continuation's fully proved foreign pre-admission diagnostic
may precede one strict replacement inside the original logical observation deadline; it remains recorded
without becoming terminal, and no unsupported sample itself supplies authority. No wait, command restoration or window reset manufactures absence.

### H4b. Keep root ownership and descendant identity authority distinct

The original unreaped Popen child is the hook's direct CLI target. Immediately before each
CLI interrupt/escalation, poll that original object. While it remains unreaped with poll None,
signal only its positive PID, using the existing signal_job owner. The hook has no killpg
route; a private session still isolates execution, but session/group membership grants no
signal authority. Reaped CLI roots are never signalled, and a later process reusing that PID
cannot reanchor lineage. A poll/signal error is retained as cleanup uncertainty; ProcessLookup
alone is neither descendant absence nor successful cleanup. Direct root ownership can permit
this narrow cleanup while a process-table sample is unavailable; it grants nothing over other
members of the CLI or kernel group.

For each descendant effect, use the existing observer and actual signal_descendants consumer.
Require a fresh admitted complete sample immediately before targeting the positive PID, its
immutable original birth and full command identity, recorded invocation ancestry, nonzombie
state and no unresolved identity_pending history. Refresh admission at the actual target, not
only when constructing an earlier selected set; record the sample and identity with each
attempt/error. Preserve exclusions and fixed deadlines while a target set changes. A supplied
selected set can narrow eligible targets but never waive a safety predicate. The same rules
cover every hook-issued INT/TERM/KILL route and cleanup caller; no group or indirect hook signal
may bypass them. There is no global kill, process-name/connection-file ownership rule or rescue
signal to an uncertain identity.

A changed command, later reused PID or restored A after A→B→A remains pending until a capable
complete sample actually omits that PID. The original identity record is not replaced. Uncertain
or zombie parents cannot establish ownership of new descendants. Unavailable observation prevents signal
admission for that decision without erasing any existing uncertainty. An exhausted finite
reconciliation window, CLI rc0, empty matching-command list, zombie state or restored command
is not resolution. Actual complete absence remains a positive resolution; later reuse reopens
uncertainty. Other safely admitted children remain cleanup obligations when one child is pending.

### H4c. One evidence owner, bounded transport and fault-isolated cleanup

#### H4c1. Allocate evidence before any control-path report or watched launch

Extend the existing invocation-unique `pre-commit-notebooks-` output owner, inside this public
script, rather than creating a logger service, new runner, registry, cache or cleanup engine.
Allocate its private root before the first report, Git population diagnostic or watched
preflight. Use the existing temporary-directory mechanism's unique creation, mode0700 and
exclusive regular mode0600 child files; no caller-selected shared filename, symlink or
append-to-another-invocation path. Reuse this root for current per-notebook result, profile,
connection and cache directories. Source/Git admission is unchanged. If root/file ownership,
creation or transport capability cannot be established, refuse before launching any command
owned by run. Retain the exact attempted root and failure where an independent channel works.
A failure during admission has no child to clean; it does not become an empty population.

Evidence consists of one ordered events file, each command's exact stdout/stderr files, and
one pair of exact binary stdout/stderr files per native observation, with small metadata
containing sequence, command/sample identifiers, actual argv, locale, times, returncode,
byte lengths/hashes, parse position/result and typed errors. Do not hex-encode a whole census
or serialize a population-sized parsed-PID list onto stdout. Binary files retain every byte,
including invalid encodings and timeout partial bytes; metadata does not replace them. Use
exclusive file creation and descriptor ownership validated at creation, never a pathname
reopen that could follow a swapped link. A short write advances only its actual offset; EINTR,
zero-progress, ENOSPC/EIO and failed flush/close have distinct recorded outcomes. No in-memory
or file segment is silently considered committed. Complete is set only after the full raw
channels and required metadata have been written and closed successfully; OS-cache completion
is not a power-loss durability/fsync guarantee. A terminal file cannot recursively certify its
own future close: its record distinguishes attempted/provisional state; only the in-memory
observed close result, carried in the bounded terminal summary after all evidence closes,
can certify that operation for this invocation. Failed terminal delivery leaves that acceptance
unestablished rather than inventing a final-close receipt. If a file operation fails, retain available
original bytes in memory and every already written exact prefix, record missing suffix ranges
and attempt the independent error/final receipt. Evidence-incomplete is nonzero refusal,
never an admitted absent process population. Do not delete failed or incomplete evidence.

**Command envelope (P3, within the same owner).** Before each `run` preflight or launch,
allocate a strictly increasing invocation-local command ID and persist `command_begin` with
that ID, factual argv/cwd, watch/timeout/input-byte identity, actual UTC/monotonic start and
the selected effective environment. Selection is the existing child-setting keys plus
LC_ALL/LANG, with presence distinct from an empty value; it is not guessed from a command
name. The existing execution_context retains original/effective override provenance. Bind the
actual launch attempt/result/Popen PID to that ID; distinguish not attempted, failed/creation
unknown and an actual returned Popen. No guessed child PID follows a failed Popen.

Each command raw capture, cumulative comparison, contradiction, missing range, fault,
observation made for that command, child receipt and public-delivery offset carries the same
ID plus channel and capture/phase ordinal. Channel segments carry actual byte ranges; repeated
cumulative buffers contribute only new proven suffixes. Retain contradictory/unverified
versions separately without appending them to the established stream. `command_end` records
actual start/end times, executor returncode or UNKNOWN, first/later fault IDs, drain/EOF and
reap outcomes, both raw-channel completion states and delivered/missing ranges. Empty observed
EOF channels have explicit zero-length closed binary evidence and the empty-byte hash; a
never-created/unknown stream is NOT an observed empty stream. A healthy nonwatched command
gets the same boundaries as a watched one. One A/B result and separate A/empty + empty/B
commands must remain distinguishable. ID gaps, duplicate boundaries, conflicting captures,
unclosed/missing channels and absent outcomes block complete evidence. All large fields stay
private and chunked within the active scheduling budget; no extra public marker or executor.

The invocation root is retained after either success or refusal until its invoking owner
collects it. Replace automatic TemporaryDirectory destruction of these records with the same
owner's explicit lifetime; this is a resource-retention change, not a new persistence service.
The initial and terminal summaries name that root. Root must measure disk use and integrate
collection into its existing run handoff; no silent deletion, per-sample truncation or new
background collector is authorized. A regular-file IO failure cannot guarantee that its own
error record will reach disk: keep independent in-memory and public attempts and report which
succeeded, without recursively reporting through the failed sink.

#### H4c2. Public output never gates launch, observation or safe cleanup

Replace synchronous print/flush at report and available-stream consumers with the same owner's
explicit byte delivery. One invocation-start summary and one terminal summary each fit one
atomic PIPE_BUF-sized record on a pipe; derive the descriptor's actual limit and refuse an
unrepresentable root/reference before launch. Summaries contain fixed fields, counts and the
start retained-root reference and terminal exact-start binding, never raw census, arbitrary full argv, exception traceback, cell
contents, descendant maps or growing history. Full fields remain in the owned evidence files.
This bounds the total normal control output per invocation, rather than merely each sample.
Admission/deletion/config/execution/children events still exist in the evidence file; they do
not become repeated public records. No public record is needed per recipient or census.

Capture both original descriptor control states before any mutation and establish supported nonblocking output capability before
launch. For pipes use direct os.write with O_NONBLOCK and a record no larger than the measured
atomic limit; do not perform a buffered text write/flush or blocking fallback. A full or closed
pipe is EAGAIN/EPIPE, not permission to wait for the caller. For ordinary terminal or redirected
regular-file output, retain exact descriptor/type/flag behavior and apply nonblocking delivery
where it is supported; regular-file syscall latency has the H4c7 limitation. Unsupported or
unobservable descriptor capability refuses before launch rather than guessing. Changing flags
can affect a shared open-file description: borrow only the nonblocking control and restore
its original state on every exit while protecting unowned controls under proposed F1–F6 below.
Retain full raw observations, record failure, and never change the parent's read descriptor or shared file content. Dup does
not create an independent open-file description and must not be described as isolation.
The normal vendor child receives its own existing PIPEs, not the hook's modified public sink.
Do not add a writer process/thread or require fixture callers to drain earlier.

An initial summary would-block/error refuses before child launch. Once execution has started,
public output failure becomes a later typed cleanup fault: it cannot prevent direct root or
independently safe descendant cleanup. Terminal summary failure withholds delivery acceptance
and exit remains nonzero. For non-atomic sinks, record the actual written prefix/offset and
incomplete record; do not claim an intact reference was received. Never retry in a wait loop
or enlarge a phase budget to make a sink accept data.

On failure, commit the first exception and all then-available command bytes to the evidence
owner before cleanup, and attempt nonblocking relay of their original per-channel suffixes.
That is the first-failure ordering; successful downstream display is not a prerequisite to
CLI INT. Each external stream has a separate delivery offset. Direct short writes advance
only the exact known accepted bytes; the unwritten suffix remains in its exact file and memory.
Retry a known-count suffix only at already scheduled cleanup checkpoints while the existing
phase has time and that sink is writable, never busy-spin or block. A raised/invalid-count
command write latches that command/channel/public-fd UNKNOWN and forbids all later payload
syscalls on it; readiness and phase changes cannot recover the unknown prefix. Attempt the
other stream independently and again after final drain, so a broken stdout cannot suppress
writable stderr or already collected tails. Every still-known available suffix is attempted
when writable within these existing checkpoints/budgets; finite
cleanup cannot promise eventual full display on a permanently blocked sink. Record remaining
ranges as delivery-incomplete with nonzero refusal, not data loss or successful full emission.
**Final-tail scheduling (P1).** Start final communicate's existing two-second window before
that operation. After it returns/captures bytes, attempt each available suffix immediately
before pipe-close/wait while that same drain window has time. Give original-root wait its
own existing two-second operation window; do not let it donate, reset or inherit a relay
window. Immediately after returned wait or wait failure, start the already-existing final
observation window ONCE, before its suffix relay. Attempt stdout and stderr independently
there, then perform the final census/reconciliation/children metadata using only its remaining
time. A relay fault on one stream cannot skip the other. Do not start another observation or
reporting grace after these writes. Earlier delivered offsets prevent duplicate display; a
late returned wait cannot erase tails already captured or charge the post-wait attempt to an
expired drain deadline. A delayed-wait control must prove exact writable tails both when the
pre-wait attempt had time and when pre-wait readiness proved no syscall before the existing
post-wait checkpoint gains capacity. Actual attempted UNKNOWN remains fenced; it is never
this positive premise. Keep one unconditional owner finish and seam restoration even if
a fixture assertion fails; preserve the original error and later cleanup causes.
IO/census share the existing final window: exhausted storage/output/observation is explicitly
incomplete/nonzero, never fake absence or a promise of unlimited log throughput. Keep all
original finite windows and their accounting; no scientific retry or larger fixture timeout.

Normal successful command channels still return unchanged for origin/config/DEBUG postflight;
this transport change must not mix diagnostic JSON into their raw bytes.

#### Accepted R28/R29 D1–D5 refinement of the existing owner

D1. Measure the ACTUAL public descriptor atomic capability, including the supported native
512-byte pipe case. Before any child, admit both the actual start and a conservative terminal
encoding within min(actual PIPE_BUF,4096); derive integer width from the actual native
file/counter domains and refuse overflow/unrepresentable capability rather than truncate,
wrap, increase the limit or add a writer. Recheck the actual terminal bytes. The start carries
event,evidence_root,root_identity,observer_pid,started_utc,entry_sha256. The terminal carries
event,start_sha256,failed,evidence_closed,root_descriptor_closed,fault_count,events_identity,
events_bytes,events_sha256,provisional_until_exit,flags_restoration_pending. start_sha256 binds
SHA256 of the EXACT complete actually accepted start bytes INCLUDING the prefix and complete
JSON object. Proposed T2 removes the framing LF, so the digest still covers every emitted
control byte and the exact actual received slice. This framing migration is authorized only by the independent whole design review, explicit operator A decision and separate R36 source grant; this document alone grants no execution. It is
not an independent witness or permission to fabricate duplicated terminal fields.

Retain attempted-start bytes/hash separately from an accepted binding. A short/unknown start
must not suppress the original independent terminal attempt: null unaccepted binding remains
explicit incomplete and can never satisfy the reader's required64-hex digest. Preserve both
short-write attempts, literal NONO, actual returned counts/prefixes/missing ranges/absolute
known-or-unknown offsets and fault identities; never retry/dump a marker. Actual close/flag/
signal failures remain nonzero after independent remaining operations, even after a seemingly
healthy provisional record. A clean actual zero remains necessary; an ordinary nonzero is not independent post-terminal
flag-restoration evidence. Proposed F4 specifies the separate observation boundary.

The single reader retains exact marker byte slices and strict distinct-key JSON/types/shapes,
requires exactly start then terminal and checks the digest over the first raw slice. It keeps
EVERY independent actual pre-call source/PID-when-known/time/temp-base/uid/mode/inode/no-follow
root/leaf witness, complete journal/raw hashes/ranges/command boundaries, first/later faults,
semantic-final state and actual exit. An attacker recomputing the pair digest must still fail
wrong independent witnesses. The accepted compact-reference migration replaced the old common-field pair comparison and
four large-census common-field assertions with independent actual start validation PLUS
exact-start terminal binding. Proposed T7 additionally enumerates framing/transport and
narrow-syscall migrations; it does not retroactively approve them or weaken other meanings.
No synthesized end-field aliases, normalized CompletedProcess, hidden event filtering or
permissive science/admission-negative fallback is authorized.

D2. Within the existing Evidence constructor preserve initial raw allocated-root lstat and
admit only the canonical path/open descriptor to the SAME allocated directory inode, expected
uid and0700 mode. Resolve the canonical parent alias, refuse leaf symlink/replacement/escape
or identity/mode/owner change, and retain raw attempted path on failure. Keep the literal
top-level tempfile allocation/source instrumentation anchor. The reader's canonical-root and
canonical-temp-parent protections remain unchanged; received references are never rewritten.

D3. Install each existing run/Evidence phase deadline BEFORE publishing the phase or its first
checkpoint/capture/report/effect. CLI grace uses the actual FIRST terminal fault+15 anchor;
TERM5/KILL2/final-drain2/wait2/shared-final-observation2 retain their original windows. No
phase fault restarts time. Expired INT admission cannot suppress the separately scheduled
required direct unreaped-root KILL; a reaped root remains unsignalable. Correctly budgeted
writable signal capture must persist in CLOSED evidence. Capture/storage failure stays
incomplete/nonzero while remaining independently safe operations continue; no cursor replay.

D4. Distinguish first rc0+pending EOF BEFORE a terminal error from a demonstrated inherited
pipe failure. Reserve ONE tightening cap from the existing15-second allowance intersected
with the ORIGINAL running deadline; continue only the existing communicate/required-observe
mechanism with actual remaining budget and exact cumulative channels. Admit timely EOF only
without a prior fault and subject to unchanged postflight/children checks; late EOF is not
backdated. A real first observation/capture/delivery/signal/nonzero fault owns its actual
object/time/typed args before fallible work, and its sole owner uses
MIN(actual first-fault+15,reserved cap) BEFORE nested capture. The optional tightening cap is
not a fabricated fault or prepopulated command_cleanup_deadline. On cap expiry no fresh15s
is granted: expired INT is skipped, required unreaped-root KILL and existing descendant/drain/
wait/observation phases remain. Preserve the original persistent-holder rc0/1 reason, exact
poison stderr/sentinel, one executor/original argv and actual witness absence predicates.
Startup/preflight/nonterminal-no-grace and zero-budget controls remain unchanged.

Unresolved full returned channels retain their ordered exact values until prefix validation can complete. Reattempt their original validation/capture only at the already scheduled final-drain and shared final-observation checkpoints, using those windows' actual remaining time. Never overwrite a contradictory prefix, erase the first fault, repeat execution/query/communicate merely to reconstruct bytes, or grant capture time.

D5 remains an explicit native qualification obligation. Every actual unsupported?/?E/?Es
sample remains an unavailable WHOLE native attempt. An owned, ambiguous or otherwise terminal
failure remains an actual retained fault. Only the coupled continuation's complete foreign-only
pre-admission proof permits one same-query replacement inside the same deadline; no parser widening,
row removal, alternate query, fallback, diagnostic erasure or absence alias is admitted. A genuinely
complete later sample may support safe cleanup only inside the existing absolute deadline
and retained identity history; it cannot erase that prior fault or make the same invocation
clean. Actual native producer capability investigation, independent source review and ROOT's
unfiltered full-native/H5/SDK/assets/MC/common-entry/production controls/full gates/main remain
owed. This construction is not a promise of native green or scientific infeasibility.

#### Approved native control lease and independent final observation

Status: whole H1–H6 and literal-intent design review accepted the coherent F1–F6/T1–T9 construction, and the operator chose A. R36 grants the six existing source/test/document owners implementation authority. Fresh whole source review and ROOT actual qualification remain mandatory. The original source/restoration failure remains failed at its recorded pin; a primitive capability pilot is not native qualification.

**F1. Borrow one control; retain the complete observation.** The intended obligation is to
return O_NONBLOCK to its independently captured initial state while preserving every unowned
control and descriptor identity. It is not to undo kernel write history. The pinned Apple
[flag definitions](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/sys/fcntl.h)
distinguish settable status controls from kernel history. Pinned
[write and ioctl paths](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/kern/sys_generic.c)
record a positive transfer in that history. Pinned
[F_GETFL/F_SETFL paths](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/kern/kern_descrip.c)
expose a broader status word than the controls F_SETFL changes, and identify a concurrency
limitation. These sources explain the observed mechanism; installed binary equivalence is
UNPROVEN. No literal history-bit exemption or arbitrary ignored-difference mask is proposed.

Use the existing Evidence prepare/finish owner. Before ANY mutation or public write, capture
B1 and B2: actual full F_GETFL words, F_GETFD values, fstat type/dev/inode/uid/mode and the
initial O_NONBLOCK Boolean for BOTH descriptors. Capture-before-mutation is essential when
stdout and stderr alias one open-file description. Equal inode metadata is not evidence of
aliasing; retain separate descriptor records and do not merge distinct opens of one file.
Validate exact integer types/ranges, native exported constants and writable access. Capability
records belong as additional fields of the existing invocation record, not a third marker or
new event. Store actual current/final observations in the same owner's memory after closure.

**F2. A narrow effect and a whole-word local oracle.** For the reviewed Darwin profile propose
the native FIONBIO ioctl, using the native exported request and an exact native-int Boolean
payload, to change only O_NONBLOCK. Its pinned generic ioctl path applies a bit-specific
atomic update before the underlying descriptor operation. This is an operation substitution
inside the existing owner, not a fallback backend. Do not replace it with os.set_blocking or
a current-word F_SETFL read/modify/write: those would reintroduce a broad mutable-word write.
A future other-platform profile requires its own primary API/capability evidence; platform
name, fstat kind, successful pure toggle or the pipe experiment alone admits no population.

Immediately before each actual narrow effect read the full current word C and the unchanged
descriptor witness; immediately after read A. When those observations exist, require EXACTLY
A == ((C & ~O_NONBLOCK) | desired_bit), over the ENTIRE returned word. No bits are excluded
from this local before/effect/after equality. During setup desired_bit is O_NONBLOCK. During
restoration desired_bit is Bi & O_NONBLOCK. Output history accumulated before restoration is
therefore preserved in C and A, rather than erased or hidden. Keep B,C,A and actual syscall
result/error separately; expected A is not a fabricated observation. Initial-already-nonblocking
descriptors require no control change, but still need actual capability/identity/readback.

Separately protect all other documented mutable controls and access mode against Bi throughout
the lease. For the reviewed Darwin profile the symbolic public control domain is O_APPEND,
O_ASYNC, O_FSYNC/O_SYNC, O_DSYNC and O_NONBLOCK, plus O_ACCMODE for access. Resolve values from
the admitted native API, deduplicate aliases and reject missing/invalid profile facts. This
domain comes from the pinned FCNTLFLAGS/access definitions; it is not the union of every O_*
open-time constant. A changed unowned control is a real fault; preserve its ACTUAL current
value, do not restore an old whole word over it. Every other raw status bit is retained and
protected by the full-word local effect equality, without claiming an interpretation of all
kernel-private bits. Unexplained changes within that effect window refuse. Between effect
windows, raw differences outside the documented control domain are diagnostic observations,
not proof of restored mutable controls or installed-source equivalence.

Register a potentially acquired lease BEFORE the ioctl because a syscall may change state and
then raise. Partial setup still attempts restoration independently for every possibly changed
descriptor. A failed current-word read latches the original actual error and leaves local
equality UNAVAILABLE; it does not suppress a safe narrow restore from a retained initial
Boolean when descriptor identity is still established. A replaced/unidentifiable descriptor
is never mutated as though it were the original. Failure on one descriptor cannot skip the
other. After both independent restore attempts, reread both acquired descriptors to catch
alias-order leaks, require their initial nonblocking states and protected controls, and retain
any failure. No effect retry, new phase, waiting loop, command, grace or reopened journal is
introduced. Existing public-flags-restore/verify operation ownership covers these finite checks.

F_GETFD/identity failures and unexpected control changes are real first/later faults. They do
not authorize changing the caller's descriptor flags, reopening a descriptor or overwriting
unowned controls. The original typed first object/arguments/time remains first before fallible
capture, even if all restore effects subsequently succeed. Existing independent finalizers,
closure order, late-signal latch and actual nonzero-on-fault decision remain. Endpoint checks
cannot prove no transient external mutation. The pinned source itself warns about concurrent
flag/ioctl effects; no mutex, dup or endpoint test proves exclusive external control. A detected
race refuses, and universal hostile/concurrent-mutator isolation is explicitly unproved.

**F3. Capability is per actual descriptor and operation.** Admit both actual public descriptors
before launch with the narrow effect/readback, type/identity/access observations and supported
native profile. Keep stdout's actual PIPE_BUF and both-reference preflight exactly as D1;
stderr needs its own control capability even though it carries no control marker. FIFO pipes
are the demonstrated flag-mechanism population, with complete narrow-operation qualification
still owed. Sockets, regular redirected files and TTYs each require actual positive and negative
capability evidence; no successful pipe or pure toggle qualifies them. Non-atomic output still
retains actual prefixes/offsets/incomplete status. Unsupported/missing/raising capability refuses
before launch with safe restoration of partially acquired leases. There is no silent broad
F_SETFL fallback. Required ordinary redirects/TTY/native H5 controls remain RED until they
actually satisfy the original behavior; refusal is not a waiver or a passing positive.
Filesystem/kernel latency retains H4c7's explicit limit. At each existing public-write
checkpoint, charge an actual identity/nonblocking-state verification to that operation's
existing remaining window before attempting os.write. A detected loss of capability is a
fault, never a blocking fallback. The read-to-write interval still cannot exclude a hostile
external flag mutator; do not advertise atomic isolation or a stronger hard-time guarantee.

If initial capability acquisition failed, still schedule the independent terminal-delivery
operation. Its actual write is admitted only by a current established nonblocking/identity
witness. False/unknown capability records a not-admitted write with actual count UNKNOWN;
it cannot trigger a potentially blocking syscall or fabricate accepted bytes. This does not
suppress either short-write attempt when capability exists: both original NONO effects and
null accepted binding stay exact. Genuine pre-capability failure remains protocol-incomplete.

Pinned dispatch assessment is per route, not inferred from a pipe:

| Actual route | Exact pinned dispatch and source result | Present evidence boundary |
|---|---|---|
| Anonymous pipe | Generic ioctl → pipeops.pipe_ioctl; [pipe handler](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/kern/sys_pipe.c) accepts FIONBIO. | R30's real F_SETFL/write history is measured; the proposed narrow operation is not yet measured. |
| Named FIFO | Vnode ioctl → VNOP_IOCTL → [fifo_ioctl](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/miscfs/fifofs/fifo_vnops.c) accepts this request. | Distinct route; no installed probe. |
| Redirected regular file | vnops.fo_ioctl → [vn_ioctl VREG](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/vfs/vfs_vnops.c) accepts FIONBIO before its unsupported-command branch. | Required positive remains required; the proposal does NOT reject VREG by type. Actual filesystem/security/readback/write behavior is still owed. |
| Socket | socketops.soo_ioctl → [soioctl](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/kern/sys_socket.c) updates socket nonblocking state. Filters/security can fail first. | Native flags alone do not expose every socket-internal state; actual nonblocking IO and complete delivery controls remain owed. |
| Standard PTY/TTY path | VCHR vn_ioctl → VNOP_IOCTL → [spec_ioctl](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/miscfs/specfs/spec_vnops.c) → device ioctl; [PTY registration](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/kern/tty_ptmx.c) selects ptyioctl; [ptyioctl](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/kern/tty_dev.c) reaches [ttioctl_locked](https://raw.githubusercontent.com/apple-oss-distributions/xnu/f6217f891ac0bb64f3d375211650a4c1ff8ca1ea/bsd/kern/tty.c), whose FIONBIO case succeeds. | This is not proof of arbitrary device/line-discipline behavior or the installed TTY. |
| Other descriptor/driver/profile | Actual dispatch and independently observed before/effect/after capability are required. | Unsupported capability refuses; no blanket backend fallback, no required-route exemption. |

The generic operation can change the file flag before a lower security/driver error; all rows
therefore require partial-effect restoration. Regular files do not become hard-nonblocking
storage merely because the flag changes. Ordinary TTY output processing can also transform
accepted bytes before a reader receives them. The pinned tty output path includes newline
translation; a raw-mode private PTY does not qualify every normal terminal mode. Preserve
actual received bytes and strict marker/digest predicates: no CR stripping, digest alias or
unannounced termios change. T2 supplies printable self-delimiting controls and T3–T6 separately
specify raw-source versus received-wire verification. A required normal-mode positive must
exercise BOTH through the real owner and same reader; refusal or a raw-mode PTY is not a
qualification substitute.
Installed binary build equivalence and actual route capability remain unproved by this table.

Propose the following isolated ROOT controls as DATA, not an execution grant here. Use only
fresh owned descriptors, native F_GETFL/F_GETFD/fstat/request facts, actual binary writes/reads
and a predeclared finite operation deadline; no native child/network peer/user TTY is needed
for the capability pilot. Restore/close only those owned resources. A capability pilot adds
no time or retry to the production hook.

* Anonymous pipe and named FIFO: actual initial blocking/nonblocking states, separate and
  dup-shared write descriptions; record B/C/A, native PIPE_BUF and exact payload/readback.
  Finite fill then one nonblocking full-sink write must refuse promptly and retain real counts.
* Fresh regular files: O_WRONLY and O_RDWR, both append and nonappend, both initial states;
  include dup-shared and independent opens of the same inode. Assert literal preexisting
  prefix/content, actual offset/append result, unchanged unowned controls and exact local
  effect/restoration words. A previously required redirect cannot be reclassified unsupported.
* Local socketpair: both initial states, positive exact payload and a finite saturated/closed
  peer complement. Observe actual IO through the OS rather than Python's cached socket timeout.
* Owned PTY pair: measure original line settings, test raw and ordinary output modes separately,
  capture EXACT master bytes and unchanged mode/flags afterward. Configuration changes for the
  isolated raw test are explicit caller-owned setup and exactly restored; the hook never changes
  termios. A normal-mode framing/digest failure stays RED for that required route.
* Invalid/read-only/closed/replaced descriptors and external-seam mutation-then-raise controls:
  assert exact typed refusal, no child, acquired-lease restoration and no mutation of a reused
  descriptor. Actual pipe/file state witnesses must reject omit/wrong restore independently
  in both clean and already-negative owners. The complete late-query fault control remains F4.

ROOT must then run original real hook caller/redirect/backpressure/manual/native controls and
full scientific H5 at the reviewed source, not substitute these isolated capability results.

**F4. Observe restoration independently of an earlier negative.** The start/terminal field
schemas, exact512 capability, accepted-start digest and all private raw-source witnesses remain.
Proposed T2 changes only public framing; T3–T7 explicitly propose the affected wire predicates.
Terminal still says restoration is pending. Healthy source-bound zero remains necessary for
clean acceptance; ordinary exit2 only proves a negative result. An ordinary negative, including
the unintended admission cases, never qualifies post-terminal flag restoration by exit alone.

Extend the SAME reader's context metadata with a separately validated restoration-observation
disposition, without fabricating events, aliases, result stdout or a CompletedProcess. Where
an actual independently retained shared open-file description exists, retain its real pre-call
control state and actual post-finish/post-child F_GETFL observation, native descriptor identity,
source/call/PID-where-known/time binding and observer errors. Assert initial O_NONBLOCK and all
protected controls independently of expected exit. Parent-held FD-local F_GETFD cannot prove
a dead child's FD-local flags; do not substitute that observation. Without such a witness,
state restoration independently UNOBSERVED. Existing source-invariant-plus-zero reasoning
remains explicitly distinct from direct state observation; ordinary negative disposition is
not silently promoted to flag-qualified. Protocol corruption still fails the original reader.

The decisive own-pipe control executes actual prepare/finish and real ioctl/F_GETFL/write/read,
then observes the SAME actual write end outside the owner BEFORE closing/draining it. Run both
a clean owner and an owner with an independently created earlier refusal. Require all exact
raw markers/private binding and post-state, original first object/args/time, both finalizers
and no process/effect creation. Seed omit-restore/wrong-bit/verification-fault mutations at
the actual production owner through the existing external OS seam, never a copied algorithm.
Omit-restore must fail the independent state predicate even when finish returns that same
earlier refusal and the synthetic exit remains2. The prior failing positive must actually
succeed under the reviewed semantic predicate; no xfail, skip or expected-failure inversion.

A complementary ROOT native caller may retain real redirected regular-file descriptors across
the real child and pass the actual child, actual read bytes and explicit call context to the
existing _events API. It must preserve the original timeout, raw data, cleanup safeguard,
source/index witnesses and child outcome; no replacement result or new runner. Pipe/socket/TTY
child observations require their own genuinely observed descriptor arrangement and unchanged
caller-order/backpressure controls, not an assumed inaccessible Popen write end. Native
qualification is limited to the arrangements actually measured.

A state-correct late verification exception can be invisible to an external post-state check
when an earlier error already fixed exit2. Preserve decisive source-owner controls that inject
the ACTUAL post-terminal read failure and assert its new typed fault row/time/order plus the
unchanged first object and the independently attempted second descriptor. Do not call that
inert source control a native child observation. With identical public bytes, a closed journal,
the same exit2 and the same post-state, those two native histories are observationally
indistinguishable. Native discrimination of every such zero-state-effect late exception would
require a separately reviewed exit/public-receipt contract change. T1–T9 propose a separate received-byte-domain change but preserve this
post-terminal observability boundary; it does not invent a post-close on-disk receipt.

**F5. Exact migration intent and adversarial complements.** Whole source/test changes are
for a later grant. T7 extends this list for the coupled framing/transport construction.
The narrow-control portion proposes these syscall-seam spelling migrations: _h4_inert's F_SETFL-only dispatch assertion becomes strict
F_GETFL/F_GETFD read dispatch plus actual FIONBIO/native-payload dispatch; the finalizer-verification test's explicit fd2 F_SETFL
tuple becomes the exact fd2 FIONBIO effect plus F_GETFL observation tuple. Retain the other
restoration-state assertions literally under their no-history inert inputs. Adapt only the
existing flags-set/restore fault injection seam to the real new operation, retaining each
fault's original type/args/no-child/independent-work predicate. The R30 own-pipe helper's old
after == original full-word assertion migrates to independent baseline Boolean/protected
controls AND exact observed current-to-after whole-word local equality, with raw B,C,A and
positive byte/digest/exit/readback oracles all required. Do not turn it into only a masked
Boolean check. Complete the same inert fdstat/descriptor-flag seam with explicit stable identity/access
fields and distinct descriptor-local flags; preserve its declared input semantics and make
shared-description versus same-inode-independent cases deliberate inputs, not guessed aliases.
Keep the original wrong-readback injection at its intended post-terminal verification
operation. New pre-write/readback checks must not accidentally move that old late fault into
terminal delivery; scope the same injected failure to its actual verification phase while
retaining all original fault/second-descriptor/closure predicates.
Existing required helper arguments, case populations, decorators, original budgets and
source instrumentation anchors remain. T6 adds optional actual transport witnesses to the
same context; T7 names every additional proposed representation migration. No unlisted
semantic relaxation is authorized.

Controls must cover initial false/true; separate descriptors; shared-description stdout/stderr;
distinct opens of the same inode; write-history present/absent and preexisting; every unowned
mutable control; malformed/missing native profile; each fstat/getfd/getfl/ioctl/readback failure
before/during/after a possibly acquired effect; mutation-then-raise; replacement/reused fd;
detected before/effect/after races; later verification failure with prior first error; first/
later signals at each existing finalizer boundary; full/closed/short/unknown output, both
NONO attempts, null accepted binding and complete protocol/raw corruption. Paired mutation
controls must show that no restoration, wrong desired state, clobbering unowned controls,
accepting wrong whole-word readback, alias-baseline-after-mutation and ignoring late fault
fail their independent predicates. No invented command or enlarged timeout earns a pass.

**F6. Whole H1–H6 conservation and acceptance.** H1 committing Git/admin/index/source admission,
H2 complete exact populations/bytes/races, H3 candidate interpreter/kernel/imports/original
assets/strict cells, H4 complete observations/identity/first faults/finite deadlines/full channels,
H5 actual production/science/native/SDK/assets/MC and H6 original consumers/review/closure remain
full strength. D1–D4's two compact references, independent witnesses, raw NONO accounting,
canonical same-inode allocation, deadlines-before-publication, one tightening cap and remaining
channel windows stay unchanged. D5's actual unsupported ? sample remains unavailable and
unusable as authority; terminal faults stay terminal. The coupled foreign pre-admission refinement
allows only its explicitly proved same-query replacement, never widening/fallback/absence alias
or scientific deferral.
The immutable original172/prior465 maps, all prior541 meanings, helper/input/anchor/decorator
and case/budget maps are required individually with the explicit F5 migration intent.
Genuine nonauthor WHOLE design plus literal-intent review, separate implementation grant,
whole source review, actual descriptor population controls, ROOT unfiltered native suite and
additions/H5/SDK/assets/MC/production/full gates/main/closure still precede acceptance.

#### H4c3. Complete census admission includes cost and evidence outcomes

The native ps two-second timeout is a subprocess bound, not a bound on arbitrary serialization,
parsing, reporting or storage. Start the current observation's deadline before launch; pass
only min(two seconds, remaining active phase time) to the subprocess when a phase is active.
Keep the original two-second maximum shared by all actual attempts, never a reset or extra allowance.
The only replacement is the coupled proof-bound foreign pre-admission continuation. Preserve raw channels first,
then parse the complete stream incrementally with deadline checks between bounded chunks/rows.
Use fixed chunks no larger than4096 bytes, an incremental strict UTF-8 decoder and framed
row validation: parse the bounded structured prefix as tokens, then retain the entire command
remainder in fixed relative chunks, including trailing bytes. A very long command field must
not hide a whole-line regex, split, join, JSON string or hex conversion between checks. Numeric
field lengths/ranges and birth/STAT validation remain bounded; an overlong unsupported prefix
refuses without losing its original raw file. Complete command comparison uses exact relative
chunks with deadline checks, not only a digest or basename; representation changes cannot alter
H4a/H4b identity semantics. Full displayed identities/histories use file references and chunked
encoding, never an implicit giant repr on the active path. Preserve the complete command
identity; reject a late/unsupported sample, never truncate it or drop rows. Raw native bytes
remain available even when interpretation overruns its budget. Serialization of full events
and large returned histories likewise uses incremental encoding with remaining-time checks;
small control summaries are generated separately. Record actual capture/parse/write/encode
start/end and failure, rather than calling a timeout parameter a throughput measurement.

No rows dictionary reaches observe, ancestry, pending resolution or signal admission until all
rows, witness, timing and required evidence records complete. A deadline or evidence failure
is UNKNOWN; it does not discharge pending history. If evidence fails during a live job,
keep the immutable original owned/pending state, refuse new descendant effects on that sample,
and continue other independently safe cleanup decisions. Direct unreaped CLI authority still
has its separate poll requirement. Observation work consumes the already active phase; expired
phases cannot issue signals based on an earlier sample. No cached-table, name, pidfile or
truncated-census fallback is introduced. A failed sample cannot count as a complete final
cleanup observation, even if a later raw file can be read by an operator.

#### H4c4. First terminal failure and available bytes have independent ownership

Keep the first actual execution/admission/interruption/cleanup failure object and its type,
message/arguments, errno when present, phase/time and available command channels immutable.
An rc1 or timeout is not replaced by a later communicate, poll, report or wait error. If cleanup
is the first failure after rc0, that actual cleanup error becomes first. Later faults are ordered
records referencing the original command and operation, never a catch-and-return-success path.
Capture a later exception's explicit output/stderr before moving on. Cumulative communicate
buffers must extend the previous exact prefix; a shorter/different buffer is a contradiction,
not authority to erase bytes. Retain both observed versions/segments and refuse the ordering
claim, while preserving the last established prefix and all genuinely available tails.

**Typed first-fault envelope (P2).** `Evidence.fault` and the existing `run.remember` are
the sole fault owners. On every first caught or deliberately constructed terminal error,
retain the original exception OBJECT and snapshot its immutable envelope BEFORE failure
reporting, public relay or cleanup. Initial run catch, timeout/rc refusal, observation failure,
Popen/mask restoration, successful-command finalization and top-level admission/startup all
use this same path; `failure = failure or error` without this snapshot is insufficient.
An envelope has invocation-local fault ordinal, command ID when any, actual operation/phase,
UTC/monotonic observation time, qualified exception type, exact available native args, errno
and any observed raw output/stderr references. Later faults have their own ordered IDs and
reference the same first ID; top-level rethrow of the same object references it rather than
rewriting the first snapshot. Formatting failure is a later fault, never the source of args.

Read native BaseException args/OSError errno through their safe native descriptors where
applicable, without calling a subclass's str/repr/property to recover values. Persist exact
builtin None/bool/int/str/bytes and nested exact builtin tuple/list/dict values with explicit
type tags; bytes use bounded lossless encoding, floats preserve their exact binary value
(including negative zero/nonfinite values), container type/order and key types survive.
Check scheduling budgets between bounded pieces. An opaque value, unsafe attribute access,
cycle or encoding/storage failure retains the actual original object/available prefix in
memory and marks the precise field/range incomplete; a type-name placeholder is not complete
argument evidence and opaque-object reconstruction is not promised. A broken `__str__` may
supply a bounded diagnostic fallback but must not erase `BadFirst("RAW_ORIGINAL")`'s native
argument from the decoded file. Snapshot/format/write faults themselves cannot replace the
first exception or skip safe effects. Persist before cleanup where the admitted sink works;
if that sink fails, preserve independent memory and available binary/file prefixes, make
independent error/final attempts and refuse complete evidence explicitly.

The same owner exposes partial construction state before fallible directory/file/prepare
steps so top-level failure can snapshot and finalize every actually acquired resource.
Unacquired descriptors are never invented or closed. If unique-root creation fails before an
owner exists, retain the real exception/envelope in the top-level memory path, actual rc/raw
independent output where available, and explicit startup/evidence-unavailable disposition.
There is no alternate root search or assertion that unavailable storage retained its own
failure. A partially usable owner attempts its own independent fault record; failure remains
incomplete and nonzero. No root/command/children record is fabricated for this case.

Maintain distinct state for command outcome, pipe EOF/drain, original-root reap, each child
identity, evidence-file completion and public delivery. A failed wait does not erase drain
success or already captured tails. EOF, CLI rc0, closed own pipes, ESRCH, rejected observation
or successful print are not descendant absence. Failures in formatting the error cannot erase
the error itself: retain typed raw exception attributes through an independent safe fallback,
without recursively invoking the failed formatter. Do not promise evidence under process-wide
MemoryError, SIGKILL, machine loss or a kernel call that never returns; see H4c7.

#### H4c5. Whole cleanup fault tree; continue every independent safe obligation

Use the existing run owner with per-operation fault isolation and an outer finally that attempts
remaining independent finalization. It is not enough to catch only TimeoutExpired at one wait.
Expected OS/buffer/serialization errors, and unexpected exceptions from these boundaries, must
be retained without escaping past the remaining cleanup; no broad handler may authorize a
signal, fabricate a successful result or swallow the terminal refusal. A later caught signal
must not restart cleanup. Maintain one deadline per phase, never refreshed by faults.

| Phase/operation | Fault disposition and independently safe next work |
|---|---|
| Evidence/control allocation, report before launch | Refuse without Popen if ownership/capability fails; attempt independent typed error/final reference and restore flags. |
| Popen and signal-mask restoration | Record whether child creation actually occurred; restore mask independently. If original Popen exists, its cleanup remains owed even if bookkeeping/reporting fails; no second launch. |
| Running communicate, timeout buffers, poll, observation | Commit first failure/available bytes; a poll error is unknown root state, not root signal authority. Enter cleanup once; keep original Popen and identity history. |
| Failure evidence/format/write/flush/relay | Record each available prefix/error independently, attempt both streams; continue root poll/INT and safe observations even when all output attempts fail. |
| CLI INT/poll/signal, fifteen-second grace communicate/observe | Poll failure skips that effect, signal failure records attempt not delivery. A communicate IO fault stops treating that drain as established but does not skip later safe root KILL, descendant phases or final drain/wait. Subsequent already scheduled capable operations may proceed within the same deadline. |
| Direct CLI KILL, descendant TERM five seconds and KILL two seconds | Preserve individual authority and a fresh complete per-recipient observation. A failed target/sink/sample cannot waive pending history or prevent later safely admitted siblings. No effect after phase expiry; errors do not reset budgets. |
| Final communicate two seconds | Timeout/IO/decoding/buffer fault retains actual available bytes, records drain UNKNOWN, then continues own-pipe close, original-root wait and final observation/receipt. A prior drain success stays distinct; never rerun the scientific command. |
| Close each owned stdin/stdout/stderr end | Attempt each independently when drain cannot be established; set supported nonblocking behavior on owned pipe descriptors before a close that could flush, never an unbounded buffered flush. Retain descriptor/object ownership, avoid unsafe raw-close followed by later object close on a reused descriptor. Failed close stays UNKNOWN; do not let one close skip the other two. |
| Original Popen wait two seconds | Timeout/OSError/other boundary error retains first failure and does not skip available suffix relay, final complete observation, evidence close or flag restoration. Record actual return/reap or UNKNOWN separately. |
| Final observation/reconciliation/children receipt | Preserve complete admission and the one two-second reconciliation window only where originally allowed. Failure is UNKNOWN, never empty. Record final owned/pending/errors/signals/drain/reap even if public report is unavailable; large data stays off control channel. |
| Each evidence flush/close, terminal summary, public flag restoration and outer teardown | Independent attempts, typed/raw faults and exact prefixes retained where possible. Do not recursively use a broken report sink, delete retained evidence or let directory cleanup replace first failure. Terminal status remains nonzero if any required operation is unresolved. |

**Caught-signal ownership (P4).** Extend the existing run/invocation phase state, rather
than adding a lifecycle layer. Establish signal ownership before the first fallible invocation
or command operation and retain it continuously across running, failure latch, CLI grace,
descendant phases, final drain, pipe closes, wait, final observation, command return/raise,
admission between commands and evidence/flag finalization. The handler only latches actual
signum/order/available time/phase in memory while any independent obligation remains; it does
not perform IO, raise through a cleanup block, reset deadlines or silently discard repeats.
This removes the current false-to-true CLEANUP_ACTIVE transition gap. During running, check
the latch after each returned observation/communicate/poll and before every subsequent launch;
the existing bounded communicate slice supplies interruption responsiveness. Between commands
and during admission, check before/after existing blocking boundaries and before more work.
The existing narrow Popen mask still binds the actual object before unmasking; check pending
signals within that same creation boundary. Do not broadly suppress or block native signals.

A first caught signal produces an actual interruption failure at a safe checkpoint. A prior
failure keeps its object/envelope; later signals become ordered later faults. Per-operation
isolation continues every still-safe root/descendant/finalization operation in the fixed
existing sequence. Success-path finalization is equally owned: signal at any inter-operation
point latches refusal while remaining closes/wait/observation/receipt/flag work proceeds.
The final exit decision requires no latched signal or fault. Only AFTER every remaining
independent finalizer is attempted does the existing top-level owner enter exit-commit; a
caught signal in the tiny status-to-exit interval must force actual nonzero exit there,
without unwinding past unfinished work or permitting a stale chosen zero. That late outcome
cannot retroactively write a closed evidence file: it remains a nonzero incomplete invocation,
never claimed fully recorded success. Uncatchable SIGKILL/process loss stays H4c7, not a new
universal guarantee. Tests must inject at the former transition, between every independently
safe cleanup/finalization operation, after otherwise-successful rc0 and at exit-commit; retain
first object, exact effects, once-only launch, fixed phase deadlines and nonzero status.

Each signal attempt records its precise authority, target, signum, sample/immutable identity when
applicable, phase/time and actual effect result. Failed attempts remain failed attempts; a record
cannot itself prove delivery. Unknown poll cannot be bypassed with killpg, send_signal fallback,
connection-file membership or command whitelist. H4a/H4b safety holds even when IO is failing.
This matrix applies equally to successful command finalization and all error/interruption paths;
an rc0 command that cannot finish evidence/drain/reap is a refusal, not an exempt fast path.

#### H4c6. Fixed scheduling deadlines and terminal result

Retain fifteen-second CLI grace, five-second descendant TERM, two-second descendant KILL,
two-second final communicate, two-second wait, original per-observation two seconds and one
nonresetting two-second identity reconciliation window. The normal strict per-cell120s and
original outer-command/fixture budgets remain. Start each existing phase before its first
operation and use only remaining time for new work. Capture, parsing, evidence, output and
signals consume that phase; no new reporting grace, retry, writer-drain allowance or timeout
increase is added. Check deadlines after operations as well as before each signal. One in-flight
kernel operation may exceed a scheduling window; do not call their sum a hard wall-clock bound.

Acceptance requires no first/later fault, complete required exact evidence, successful required
control delivery, complete final admitted observation, no observed live retained children,
no pending history, completed command drain and original-root reap. Any failure/UNKNOWN returns
nonzero preserving first failure. Record safe known survivors and pending/unknown identities as
root cleanup obligations; never treat nonzero refusal as accepted absence or leave-known-child
permission. Root must quarantine/inspect these actual identities through its existing owner,
not infer universal host quiescence from this hook's endpoint.

#### H4c7. Explicit construction limit; no silent relaxation

Nonblocking pipe writes remove the demonstrated caller-awaits-before-draining dependency.
They do not make arbitrary regular-file open/write/close, kernel process creation/reap, Python
allocation or installed vendor internals hard real-time. A filesystem may indefinitely stall
inside a syscall; with one thread in that call, the same process cannot simultaneously perform
cleanup. For any finite budget B, a sink that accepts no bytes for longer than B cannot both
receive an unbounded complete log and permit guaranteed termination by B. Finite memory cannot
retain an unbounded producer indefinitely either. Chunking/deadline checks prevent voluntary
unbounded loops, but cannot interrupt such a stuck syscall. O_NONBLOCK on a regular file, a
try/except, select readiness or an old passing runtime is not a proof to the contrary.

The practical construction uses the existing root-prepared local output filesystem, ordinary
native scheduling and measured returned IO, and fails visibly on encountered errors. Root must
measure output location/type/space, realistic full census/log sizes and IO/cleanup durations
before accepting that construction. Failure preserves every available exact byte; evidence
that cannot be stored or delivered is explicitly incomplete and blocks acceptance. No design
claim here guarantees complete durable evidence under disk failure or a universal fixed wall
bound over arbitrary OS faults. If the original requirement is interpreted to demand that
stronger guarantee, this same-process/no-new-runner construction is insufficient: the breakdown
above goes to root for the operator's explicit decision before implementation, with possible
isolation/operating-contract change requiring its own approved scope. This construction grants no
such relaxation, new runner, raised budget or waiver, and must not silently be implemented as
if that contradiction were already resolved.

### H4d. Preserve and expose the installed native lifecycle boundary

Keep the admitted ordinary AsyncKernelManager and local provisioner unchanged. The inspected
installed jupyter_client manager._async_signal_kernel delegates to provisioner.send_signal;
local_provisioner.LocalProvisioner.send_signal prefers os.killpg for its kernel group, and
kill/terminate delegate there. CLI interruption can therefore lead indirectly to vendor-owned
kernel-group effects. These internal recipients are not individually admitted by the hook's
observer. Replacing the hook's broad group signal does not make that stronger claim true.

The hook extends its own existing cleanup authority; it does not patch or wrap the library,
install a custom manager/provisioner or suppress normal nbclient cleanup. Its direct CLI SIGINT
must not be described as proof that vendor internals apply the hook's pending-history rule.
Whole source/runtime review must assess this exact composition against the original
H4 intent: normal native lifecycle and safe hook-issued signals are
both required, while universal vendor per-recipient admission is not supplied by the admitted
existing stack. If the composition cannot meet the required objective, report the concrete
construction gap and evidence to root; do not hide it with a narrower success label. Documenting
this trust boundary grants no waiver, readiness, closure or physical-scope reduction.

Root must measure original normal/error/signal/timeout/spawn/detached/pipe/concurrency outcomes,
actual identity transitions, attempts, cleanup/drain/reap and residue at the final reviewed source
and installed library versions, plus H5. No source audit, inert helper or old passing fixture
establishes native lifecycle acceptance. Exact installed source paths/hashes/branches and this
indirect-effect implication belong in the ignored design handback for the fresh reviewer.

### H4e. Test the complete composition without weakening original controls

Implementation acceptance requires controls through actual production helpers and cleanup
callers, with explicit expected identities/effects rather than an oracle derived from the
new parser. Keep every original semantic oracle, decorator, parameter and budget. The explicitly reviewed
existing-reader amendment below permits only necessary interface-expression/helper edits, with
immutable original byte provenance and exact per-assertion mapping; it grants no test waiver.
Required complements:

| Boundary | Required evidence after a deliberate implementation grant |
|---|---|
| Complete parser→observer | Good table; true absent retained PID with a valid observer witness; ordinary safe lineage; then independently malformed PID/PPID/PGID, out-of-range/signed/Unicode numeric, partial row/missing command, bad birth/calendar/weekday, bad STAT, invalid UTF-8/NUL/row framing, duplicate equal/conflicting PID, blank/empty/missing observer, stderr/nonzero/timeout/unavailable output. Invalid samples preserve owned/pending/transitions/resolutions, cannot extend ancestry or signal; later restored A must not launder pending history. |
| Root and descendant signal consumers | Direct unreaped CLI INT/KILL only, including denied observation; no root/group attempt after reap; safe observed descendants in same and separate groups handled; unrelated same-command rows excluded; pending changed/reused/A→B→A/unknown never targeted through INT/TERM/KILL/selected/default routes, before/after finite-window exhaustion; true complete absence resolves, later reuse reopens. No hook group attempt is permitted. |
| Actual formatter/sink and complete cleanup fault tree | Use the actual report formatter, byte writer and evidence owner, not a list-emitter substitution. Reproduce the full valid large census with an undrained finite sink; child launch and safe cleanup must not depend on draining. Assert exact raw binary files/metadata and bounded public bytes, plus healthy drained and ordinary manual/redirected controls. Inject allocation/open/short-write/zero-write/EINTR/EAGAIN/EPIPE/ENOSPC/EIO/serialization/flush/close/flag-restoration faults independently at preflight, running, grace, TERM, KILL and finalization. Preserve first error, every available suffix, safe sibling effects, independent final wait/receipt and honest UNKNOWN; exercise combined broken-stdout+writable-stderr and final-tail+wait-error branches. No artificial list sink, truncation or deadline extension can satisfy this. |
| Full cleanup ordering | First original error/available buffers, direct CLI INT before safe escalation, native grace retained, safely known siblings handled despite pending/unknown observations, finite phases do not restart, original root/pipe drain/reap and final capable observation required. A real safely known survivor or unknown remains a nonzero root cleanup obligation. |
| Real runtime and production | Full unfiltered original suite plus additions, actual normal/error/signal/outer and per-cell timeout/spawn/detached/pipe/concurrency, source/index races and all H5 controls at final reviewed hook/tests/vendor pins. Preserve actual first failures and native signal/residue evidence; inert/source controls are not these receipts. |

Tests that exercise only signal_descendants omit a real consumer. Tests that replace the
parser with an already-filtered dictionary cannot establish complete-observation admission.
Tests must independently hold the input population and required effects and call the actual
parser→observer→root/descendant decision path, including error cleanup ordering. Root owns
real fixtures/process observations and production seeding; inert source controls execute none.

The ordinary hook must not stage, overwrite, normalize or regenerate input notebooks/source.
Recheck the full eligible index and input/source/config/kernel-spec identity; observed movement
refuses. Root isolates production mutation scope and uses existing seed_journal for exact
tracked artifacts/semantic-index restoration. Killed runs need actual cleanup inspection.
Preserve another owner's changes; endpoint observations are not global-static assertions.

### Existing original-test reader: coherent proposed migration, not an implementation grant

This design deliberately proposes amending literal original-prefix preservation ONLY after
ROOT intakes genuine independent whole design and literal-intent acceptance. Retain the
original prefix/hash and every full original function/assertion/decorator/parameter/budget as
immutable handback provenance. Preserve all semantic predicates and strengthen protocol
checks; no xfail/deletion, wildcard enrollment, changed timeout, fake stdout, substituted
CompletedProcess, extra dispatcher or new reader beside `_events` is authorized. The full
per-original-assertion map belongs in ignored design evidence, not a parallel runtime registry.

**Actual call binding and one reader.** Extend existing `_call` with explicit optional hook
context passed by the actual hook callers (`_run`, direct hook calls and lifecycle/concurrent
call sites). Capture actual argv/cwd/effective environment/temp base, UTC interval, actual
entry path and its observed PRE-CALL bytes/hash/mode; retain PID only when an actual Popen
caller observed it. Attach metadata to the original result or pass the actual child/streams/
context explicitly to the single `_events`; preserve all raw result fields exactly. Existing
`_observe_real_hook_child`'s actual-result construction is not a license to make another
result or expand stdout. Generic Git/uv/kernel/path/refresh results stay raw and do not enter
hook decoding. No command-name inference supplies missing context. Both concurrent callers
capture distinct real PIDs/intervals/pre-pins and use this same reader rather than inline JSON.

`_events` returns ALL exact retained records in order, including terminal_provisional, and
exposes the explicit verification/disposition metadata on the actual call context. It never
filters new records into a legacy-looking list. Private events remain strict LF-complete
UTF8 JSON. Public controls use proposed T2 self-delimiting printable JSON with exact
marker/framing/schema and actual-slice digest; root/entry/PID/start-time witnesses remain
independently checked. Source data and received presentation retain distinct exact domains.
Without independent PID observation state only that the positive reported PID is consistent.
Bind the root to the actual temp base/current call window, never scan prior directories.
Open the exact immediate private root O_DIRECTORY|O_NOFOLLOW; verify uid/mode/dev/inode before
and after, open only validated regular private leaves relative to that fd with O_NOFOLLOW,
and verify identities/modes/full byte lengths/hash/close/completion/framing. Reject duplicate,
conflicting, malformed, partial, injected, stale, symlinked, moved, truncated or wrong-source
references and command/sample ID/channel gaps. Use P2/P3 command boundaries to validate raw
segments and completion, never adjacency or filename guessing. A same-user hostile process
is not authenticated by a pathname/hash; operating trust limits remain explicit.

**C2 disposition table — missing observation is never default empty success.**

| Actual observed state | Reader result and permitted assertion |
|---|---|
| No child/call result (launch itself raised or never attempted) | Explicit no-result with the actual exception/context/available channels; no events or rc are invented. Only its specifically assigned startup-negative control may accept that disposition. |
| Nonzero startup/evidence unavailable before a valid complete root/start | Explicit startup-unavailable, retaining actual rc/raw streams, attempted context and independently witnessed failed operation. No stale root lookup or inferred command/children/data consumption. |
| Root/owner partial; missing start; EAGAIN/partial public marker; incomplete events/raw/terminal protocol | Explicit protocol-incomplete/infrastructure failure; preserve the available prefix and UNKNOWN fields. A deliberately injected capability-negative control checks its actual failure witness. Ordinary admission/science refusal tests may NOT silently pass on this state. |
| Valid current bound nonzero admission refusal, no owned command launched | Return all verified events plus admission-refusal disposition, exact first envelope and actual nonzero exit. No children or command is required when none existed. No success/empty-science acceptance. |
| Valid bound command-start refusal | Require that actual command ID's failed/not-created boundary and typed fault; unknown/not-created channels stay distinct from empty EOF. No children receipt for an object that never existed. |
| Valid bound command/scientific refusal after actual child | Require actual matching command envelope/full available raw channels, typed first/later faults and genuine required children/drain/reap/delivery outcomes, with nonzero exit. Incomplete cleanup remains failure/UNKNOWN; neither refusal nor a reason string proves absence. |
| Fully verified zero success | Matching complete start/terminal, all records/raw boundaries/actual closes and required semantic-final state, zero exit, no first/later fault/signal/pending/raw/delivery/cleanup uncertainty. Then original success predicates may run. |

Default `_events` callers require a fully bound protocol appropriate to the expected admission
or child outcome; a negative/no-success predicate cannot accidentally accept startup corruption.
New startup/incomplete tests explicitly name the permitted non-acceptance disposition and its
actual operation witness; they do not fabricate records. For expected source-race tests the
start marker must match the ACTUAL pre-call pin. A later different source is accepted only as
genuine nonzero movement evidence with actual before/after bytes and the observed refusal;
never relabel the changed post-run hash as the entry source. A wrong/stale original pin is an
infrastructure error, not that expected race. Endpoint binding is not proof of no transients.

**C1 exact raw oracles.** Keep every original identity-transport stderr traceback/
CellExecutionError/poison and sentinel multiplicity assertion on the actual unchanged raw
public stderr. In particular PIPE_COMPANION_ORIGINAL_SENTINEL stays exactly one there.
For a normal TTY, proposed T3–T7 additionally require exact private original command bytes
AND exact independently checked native presentation of those bytes in the actual wire;
neither a reason string nor text-equivalence/CR removal replaces either domain. An alias
capture retains the actual merged stream and write order, never fabricated separate stderr. Independently
verify its associated exact command raw segments and actual delivered ranges. Partial writes
advance only real offsets; do not join duplicated buffers or force all healthy command logs
onto public output. Preserve generic raw Git/uv/kernel/path/refresh diagnostics unchanged.
Only predicates whose actual intent was a structured hook admission/refusal message migrate
from rich stdout to the corresponding verified retained error/reason/envelope. This includes
the signal caller's structured interruption reason, with actual nonzero status and observed
kernel death still required. Keep every exact expected literal and original fixture witness.

**C3 semantic finality without hiding the terminal protocol.** On a verified zero invocation,
require the original semantic `empty` or `success` record to immediately precede the sole
terminal_provisional record in the complete ordered events. Migrate only original `[-1]`
empty/success expressions to that explicit semantic-final position; check the provisional
record remains last and is consistent with the actual bounded terminal summary and exit.
Do not discard it, manufacture a success row or find an earlier convenient success. All
other original event membership/order/cardinality and negative-event oracles remain.

The terminal summary is delivered nonblocking only AFTER the actual evidence-file/root-close
attempts, while output capability is still established; it truthfully says flag restoration
is pending. The originally borrowed nonblocking control must then be restored, with complete
current-to-after raw-word validation and independent protected-control/descriptor checks under
proposed F1–F4. Actual zero exit at the bound reviewed source requires every restoration
and no newly latched fault/signal. The reader reports this as source-invariant-plus-actual-exit
verification, NOT a nonexistent post-close on-disk flag receipt. Native complements separately
observe real shared-descriptor controls; an already-nonzero negative without that witness is
independently UNOBSERVED for restoration, as F4 requires. Terminal delivery/close/restore/observation/late-signal
failure forces nonzero even if a prior provisional record looked successful. Source-bound
zero, complete files and actual marker delivery are jointly necessary; none alone suffices.
No third marker, blocking fallback, reopened evidence file or recursively self-certified close.

**Original source-only observer consumers.** Extend `_source_observer` in place to extract
actual current `run` initialization and the exact closure of observe/reconcile_identity/live/
cleanup_observe/signal_descendants, including remember, check_time, same_process, actual fault
owner, phase deadline/failure/cleanup_faults, actual cause_order and invocation-local
CAUSE_SEQUENCE=itertools.count(1), SIGNAL_CAUSE_ORDERS={}, SIGNAL_EVENTS=[] and SIGNAL_CURSOR=0. The explicit abstract
process_rows(samples, deadline) remains a deadline-aware inert observation boundary, not a
copied parser or successful filtered algorithm. Its fault path executes the actual extracted
Evidence fault logic with an explicitly incomplete in-memory unit owner; genuine private-file
persistence is proved by the separate actual Evidence controls, not this facade. Declare all
locals/dependencies before extraction, audit the call tree before the deliberate source-only
run, and never execute Popen/native signals through a hidden helper. `_observer_row` represents
the entire original command as exact fixed512-character chunks; births/PPID/PGID/state stay
literal inputs. Tests comparing error/history fields migrate only representation: exact
operation and raw original args/messages/counts remain separately asserted, not a substring
approximation. Actual serialized full-command substring assertions reconstruct exact chunks
in the TEST expression (including cross-chunk matches), never compare substring membership in
a chunk list. Keep changed/reused/restored/zombie/unknown/true-absence/later-reuse/safe-sibling/
selected-effect oracles and the nonresetting reconciliation window. No new observer algorithm.

Required independent controls include healthy current empty/success and complete admission/
command refusals; genuine pre-root/partial/start-refusal cases; wrong pre-pin/root/UID/mode/
symlink/inode/stale time/PID/framing/truncated/raw-ID/missing/duplicate/contradictory data;
actual source movement; complete provisional+semantic-final ordering; failed final close,
control delivery/flag restore/flag verification and late signals. A corrupted protocol never
becomes an expected scientific failure. Full original real fixtures/caller ordering remain
ROOT-owned after coherent code grant and genuine whole source review. No full native or H5
acceptance follows from proposed consumer design or preserved inert receipts.

## Decision H5 — actual production controls, including both review findings

These are acceptance requirements; exact-source receipts and remaining work are recorded separately.
Routine temporary Git-layout tests call the actual public
script; they do not reproduce its resolver/engine. Root additionally tests the existing real
common-hook chain in its assigned isolated production checkout with distinct candidate/primary
bytes. Preserve old-route actual behavior and any separate prerequisite failure; do not
manufacture a routing RED from a missing runtime. Real seeding uses seed_journal and root
Git ownership; fixture-only mutations cannot replace production evidence.

| Control | Required discriminator |
|---|---|
| Primary/manual/linked/subdir/common entry | Actual Git context, invocation source, admitted bytes and candidate child cwd/module hashes; ordinary installed guards and primary public entry run |
| Relative/absolute Git administration | Correct reciprocal identity after common-hook cd; contradictions/backlink loss/unsupported layout refuse without cwd or basename guess |
| Candidate-only poison with primary good | Real fully staged candidate failure gives RED; exact full notebook and semantic-index restore gives complete clean GREEN through the same ordinary route |
| Per-notebook assets AND imports (M1) | Kernel cwd is each candidate notebook parent; an explicitly non-scientific candidate asset's exact bytes are consumed rather than parent/primary bytes, while actual project module origins are candidate |
| Original Phase5b contract (M1) | Unmodified cell12 path/glob access targets candidate docs; actual legitimate MC data consumption is owed if absent, never invented or credited from its empty branch |
| Runtime preparation (M1) | Missing .venv/spec fails with root preparation instruction; prepared metadata-selected kernel resolves candidate prefix; conflicting primary editable/user kernel cannot substitute |
| Partial notebook staging | Failing index/passing work and converse refuse before kernel; fully staged addition succeeds; all other staged paths conserved |
| Literal population | Spaces/tabs/newlines/leading dash/metacharacters, multiple notebooks, rename destination and deletion handled without splitting/globbing; Git failure differs from empty population |
| Missing/unsafe/index cases | Absent working file, directory/type/symlink escape, unmerged stage, invalid Git context and foreign path refuse |
| Skip tags with actual failing cell (M2) | skip-execution and a custom nonempty skip tag cannot hide a fully staged failing cell; it executes and RED, or unsupported effective config explicitly refuses |
| Error tags/allowance (M2) | raises-exception, ambient allow_errors and allow_error_names cannot permit a real failing cell; production invocation remains RED |
| Ambient removal/skip config (M2) | Real config enabling TagRemove/Regex/custom preprocessor or custom skip cannot remove a poison and produce PASS; admitted CLI pins override it or effective-config admission refuses it |
| Fresh complete execution (M2) | Successful tagged original cells actually execute in order; omitted cell, stale counts/outputs, absent timing/events or missing result refuses despite CLI rc0 |
| Strict timeout/error | Missing kernel, IOPub timeout, execution timeout, ordinary error and signal are nonzero; no traceback rerun, no discarded per-notebook failure |
| Complete process observation (H4) | Actual native parser→observer rejects partial/invalid numeric/birth/state/UTF-8/command/duplicate/empty/missing-witness/failed streams; no false absence, ancestry or signal; complete safe and true-absence samples remain positive |
| Every hook signal effect (H4) | Root-only unreaped direct INT/KILL, reaped-root refusal, pending changed/reused/restored/unknown/scheduling exhaustion in same/separate groups, actual selected TERM/KILL and cleanup order; no hook group attempts or unrelated recipient |
| Concurrent/race/residue | Unique outputs, endpoint movement refusal and original normal/error/signal/timeout/spawn/detached/pipe/concurrency controls; actual bounded cleanup/drain/reap/residue and vendor boundary per H4; no unobserved-transient claim |
| Conservation | Original cells/tags/assets, rich outputs/input bytes, deps, public/private guard order, sync skip, other index entries, prior repairs, scientific objectives and failed receipts survive |

For M2, seed the tagged failure and config allowance into the actual production-script input
and normal configuration owner, not just a fixture helper. Prove at least one targeted removal
of a relevant enforcement pin makes a production discriminator fail, then exact restoration
restores correct behavior. Blank cells and missing scientific data keep explicit scopes rather
than inflating successful execution/data populations. No cell is removed or error ignored to
make the clean run pass. Record actual argv/env/config/kernel/cell events and all refusals.

## Decision H6 — whole rereview, owner amendments and delivery

A genuinely nonauthor reviewer must review the entire corrected finding/H1–H6/plan/MODEL and
current owner documents against actual sources, including the original asset consumer and installed
skip/error/config/kernel-discovery branches. Prior review REQUEST_CHANGES stays failed; self
assessment does not accept this revision. Perform intent-drift assessment against the user's
Git discipline and publication review/fix request. Both M1 and M2 must be built at full strength;
neither a two-notebook exception nor a strictness promise without a production discriminator
qualifies. Whole specification acceptance and root's scope grant precede this H4 implementation.
The resulting source still requires genuinely nonauthor whole review; changed design requires rereview.

Root serially applies the reviewed topology/QA/ADR execution-context and strict-cell contract
before code while preserving concurrent integration-owned paragraphs. Runtime preparation is
an explicit task in the same coherent repair, using existing uv/ipykernel/Jupyter owners; no
new engine, resolver/API/selector, kernel service, validate check, readiness gate, registry or
ledger. Root deliberately assigns implementation and independent review with fresh packets;
future roles are not accepted by being named in this document. All r1 public preimages and
frozen ignored refusal reports remain retained; do not replay or refresh their terminal result.

Implementation extends existing public script and focused tests/architecture claim pins.
Probe actual registration obligations with the existing architecture skill tool and explain
inapplicable new-check sites. Preserve caps/floors/CI_SKIP and every describing document in the
coherent checkpoint. Actual clean full candidate execution and strict production controls,
whole nonauthor source verification, root intake, required current full gates, existing
close_finding.py, updated wave closeout and protected ordinary Git/main delivery remain owed.
Deterministic source controls and syntax checks do not replace full native/runtime Verify. Source/design/runtime receipts are
distinct from scientific BUILD, main merge, new green bundle and human publication acceptance.



#### Operator-approved normal-native transport contract — T1–T9

**APPROVED DESIGN AND OPTION A; SOURCE/NATIVE ACCEPTANCE PENDING.** These decisions are coupled to F1–F6 and original H1–H6. R35 independently reviewed the complete construction and literal intent; the operator explicitly chose A, and R36 grants coherent implementation. The exact enumerated representation/predicate migration applies prospectively to this candidate. It never reinterprets frozen earlier bytes or their failed receipts.

**T1. Exact domains and the demonstrated boundary.** Distinguish:
S: exact original vendor stdout/stderr bytes, unchanged for postflight and retained in
private command raw files; P: exact bytes actually offered by this Evidence owner to a
public write; N: actual native returned count/error for that call, which counts P bytes;
W: exact bytes independently received at the sink/capture boundary. No alias among these
objects is allowed. D1's accepted-start digest binds actual complete P and, under T2's
admitted printable framing, the same actual received control slice W. Command source
hashes/counts/ranges always refer to S. Presentation hashes/counts, where recorded, are
separate predicted or observed values with explicit provenance, never relabelled S or N.

A supplied actual ordinary PTY measurement with OPOST|ONLCR accepted an LF-containing
payload and received an extra CR. Thus literal W==S for that payload, unchanged ordinary
terminal modes, raw relay and no reader normalization cannot all hold. This is a bounded
counterexample, not scientific impossibility or permission to waive a required route.
A marker-only repair leaves command traceback/sentinel presentation unresolved. T2 and
T3–T6 must be implemented/reviewed as one owner/consumer construction if T9 approves it.

**T2. Concrete printable controls and exact accepted-start binding.** Proposed framing is
`b"NOTEBOOK_HOOK " + compact_ASCII_JSON_object`, with NO trailing LF, CR, NUL, tab or other
raw control byte. Keep the current start and terminal required keys/types exactly; JSON
strings use the current ensure_ascii escaping and unique-key strict decoder. The complete
outer object is self-delimiting: a bounded byte scanner tracks string/escape state and
nested object/array depth until the matching final brace, then strict-decodes that exact
slice. No line splitting, whitespace normalization, reserialization for hashing or search
through arbitrary command bytes is permitted. Valid marker bytes lie in printable ASCII;
normal ONLCR has no LF on which to operate. A measured profile that alters these actual
bytes is a failed required transport, never an accepted approximate marker.

This removes one byte from each old marker; it adds no length prefix, field, version alias
or encoded root to the compact terminal. The actual start and conservative terminal
preflight still require each COMPLETE source record <=min(actual PIPE_BUF,4096), including
the supported512 case and actual integer/file domains. Actual terminal bytes are checked
again. No expansion estimate may replace that check. Current-call entry-source pin plus
explicit pre-call `control_framing="ascii-json-object-v2"` selects this proposed contract;
old LF receipts remain historical under their own exact old source/reader. Do not reinterpret
old bytes or infer a new framing from a convenient parse.

Hash the exact actual start P, prefix through closing brace. Commit accepted binding only
after actual returned N==len(P). Reader hashes the unchanged actual received start slice W;
require equality to terminal.start_sha256 and retain every independent current-call/root/
source/PID-when-known/time/uid/inode/journal witness. Recomputed malicious digests remain
insufficient. A short/unknown/raised start still schedules the original independent terminal
attempt, with null accepted binding. Preserve both attempted P values, returned native N,
accepted prefix/missing source ranges and known-or-unknown source offsets. Both two-byte
short effects remain literal NONO and source offsets0/2; no retry or third marker is added.
The terminal remains provisional until actual exit and the unchanged F4 finalizer evidence.

**T3. A forward presentation predicate, not inverse normalization.** Recommended option A
retains the raw relay: command P is exactly the corresponding S suffix, without encoding,
CR insertion/removal, replacement decoding or execution retry. In addition to F1's initial
descriptor facts, record actual read-only native presentation facts for BOTH descriptors
before launch in the existing invocation event. A descriptor profile includes fstat type/
dev/inode/rdev/uid/mode, access/control/FD-local facts; for a TTY, actual complete tcgetattr
values and actual line-discipline observation where available, with raw typed values,
observation time and errors. No tcsetattr, raw-mode switch or shared terminal mutation occurs.
The independently controlled caller captures its own actual arrangement/profile witnesses.
Per-write current identity/nonblocking/presentation checks and returned checks consume the
same operation's existing remaining window. Missing/inconsistent facts never mean identity.

For an independently established byte-stream sink (pipe/FIFO/socket) or file byte operation,
E_identity(x)=x. For the standard measured ordinary PTY profile with unchanged OPOST|ONLCR,
8-bit output and no other output translation/discard/column-dependent mode, the proposed
expected presentation is E_onlcr(x): replace EACH source0a with0d0a, leave every other byte
unchanged. This is a forward construction over actual S, never `W.replace(...)`, universal
newline decoding, CR stripping or a supplied producer hash accepted as an observation.
For example source0d0a predicts0d0d0a, distinct from source0a's0d0a; tab, NUL, control bytes,
invalid UTF8 and non-ASCII remain exact bytes under this specifically admitted profile.
E is injective on that source domain, but the reader need not invert it: compare actual W
to the complete independently computed E(S accepted ranges) byte for byte. Raw and wire
length/hash must be calculated separately. Normal terminal human presentation is retained;
identity-route original raw stdout/stderr predicates remain literally unchanged.

The pinned tty output implementation also has queue, FLUSHO, line-discipline and partial
processing branches. A returned source count is NOT an observation of received wire length.
Do not infer W from N in short/raised/unknown cases, assume an ONLCR-only equation for an
unmeasured state, or claim that one endpoint read excludes transient foreign mutation.
Actual extra/dropped/reordered wire bytes fail the exact forward comparison. Incomplete
native presentation remains UNKNOWN/protocol-incomplete/nonzero, with actual raw capture
retained. No hostile-mutator or hard syscall-latency guarantee is made. Default normal PTY
positives must genuinely pass the full owner/reader matrix; unusual/partial states and
capacity failures remain measured negatives, not replacements for those positives.

### NI1–NI6 — proposed Darwin native identity refinement

**Python-observable Darwin identity domain (proposed; independent whole design acceptance required).**
The existing Evidence public snapshot and SAME reader retain an exact dict with
exactly dev,ino,rdev,mode,uid,gid and exact built-in integers, excluding booleans
and native int subclasses. Define D = {-1} union [0,2**31) union
[2**64-2**31,2**64-1), U = {-1} union [0,2**32-1), I = [0,2**64),
and M = [0,2**16), with half-open intervals. dev/rdev use D, uid/gid use U,
ino uses I and mode uses M. Compact root/events dev/inode pairs use D times I.
These are the images of the reviewed CPython conversions of modern Darwin
native fields, not their C storage intervals. In particular the middle device
gap, negative values below -1, unsigned64 maximum and unsigned32 uid/gid maximum
are refused; no blanket unsigned or signed interval is substituted.

Preserve every raw Python value verbatim through observation, JSON, baseline,
current and independent post-state. No abs, cast, bitmask, wrap, missing-attribute,
null or zero substitution is allowed. -1 is a representable observed component;
it alone supplies neither descriptor identity nor authority to mutate it.
Actual no-follow filesystem identity/uid/mode, descriptor/presentation controls,
baseline/current equality and independent receiver/post-state equality remain
separate requirements. Malformed or unavailable observations retain the actual
partial native result and original fault, with incomplete/null public identity.

The profile is derived from pinned official CPython v3.14.8 conversion source
and passively inspected installed aarch64 headers/configuration. Installed files,
version strings and upstream source do not attest the loaded binary or original
build SDK. ROOT must qualify that composition and all required actual positive
routes before runtime acceptance; a discrepancy requires a new coherent review,
never a broadened guessed domain or a route refusal called positive. Keep approved
A, framing, S/P/N/W, flags, process/error/deadline/cleanup and scientific duties
unchanged. Correct these owners before source, then obtain fresh whole independent
source review before ROOT original prerequisites/native/module/production controls.

NI1. Derive the forward image before choosing its predicate. At official CPython
v3.14.8 commit 8e6e75d9102e39bed2a2b279203a396741180f12, Modules/posixmodule.c
SHA256 b21297c2dba7ab7accbeba17e5ba43a3d2bf632262ff113892f3f597f634aa3c,
stat/fstat use the same packing path. The device conversion preserves NODEV's
signed value and otherwise converts to unsigned long long. Darwin signed32 dev_t,
NODEV=-1 and unsigned-long-long width64 therefore produce exactly D. Negative
native values from -2**31 through -2 map to the upper island; native -1 maps to
Python -1. The uid/gid conversions map native unsigned32 maximum to -1 and preserve
other values, producing U. Unsigned64 inode and unsigned16 mode produce I and M.
See the immutable source at
https://github.com/python/cpython/blob/8e6e75d9102e39bed2a2b279203a396741180f12/Modules/posixmodule.c
and installed config/header provenance retained with the design evidence. This
is a source derivation, not binary attestation. H52's raw large PTY device witness
is consistent with the upper island; it does not establish every endpoint.

NI2. Extend public_snapshot in place; SAME _events.snapshot independently uses the
same mathematical image before mode/equality use. Compact filesystem pairs use
the identical device image and unsigned inode image. No new resolver, imported
validator, second writer or normalization pass is introduced. Native descriptor,
status, full terminal/line-discipline, private leaf and no-follow witnesses stay
unchanged. Darwin platform admission remains the existing coarse guard; it must
not be described as an ABI attestation. A version check alone would not prove
binary equivalence. ROOT's original runtime qualification owns that distinction.

NI3. Reject missing/extra keys, bool/null/string/float/native int subclass,
containers, under/overflow and every gap boundary. Retain actual missing-attribute
errors, partial fields and incomplete/null state. Preserve valid -1 and upper
island values exactly. Changed in-image dev/rdev/uid/gid or compact pair still
fails independent exact identity equality and forbids treating a replacement as
the original. Private JSON cannot encode a native int subclass; exact native
subclass rejection is tested at the actual producer seam, not fabricated in JSON.

NI4. Preserve every unaffected original assertion, function, decorator, case,
parameter, input, oracle and budget. Declare the public/pair numeric predicate
migrations and source-derived endpoint data correction. Keep the original native
matrix and whole current module, including normal ONLCR, mandatory. Existing
production-owner endpoint/type/missing controls and recomputed-digest SAME-reader
corruptions remain; add island/gap endpoints, unsigned sentinel rejection,
in-image changed identity and actual high-device PTY complements. Synthetic seam
endpoints prove the domain predicate only, not usable native descriptors.

NI5. ROOT separately seeds the accepted historical all-nonnegative producer and
SAME-reader guards into their actual respective artifacts through existing durable
seed_journal, one at a time. Each retains fresh complete original native52
baseline0, specifically causal nonzero, exact restored0 and empty journal residue.
Preserve bytes/fullmode/nsmtime, raw and semantic administration, journal/backup,
actual identities, unchanged independent witnesses, XML/streams/errors/origins.
Bind causal red to the actual raw values rejected by that old guard; do not assume
all device values are negative or insist that PTY upper-island values fail a
nonnegative poison. Also separately qualify the superseded signed32 producer and
reader guards against the high-island native PTY witnesses. Neither owner may
mask the other. No import/setup/SDK failure, existing red baseline or in-memory
copied evaluator counts as production sensitivity. Retain every historical failure.

NI6. After whole independent design acceptance and explicit source grant, update
all describing owners before code. Freeze the coherent producer/reader/control
package for fresh independent whole source and original-intent review. ROOT then
qualifies original ownership/caller prerequisites, complete original native
population and full current module through legitimate disposable locked-runtime
and prefix-kernel preparations, the separate real-source sensitivities and full
H5/scientific/SDK/assets/MC/current gates. No route exclusion, tolerance/clock/input
change, scientific deferral, activation, closure, main checkpoint or human
acceptance follows from this domain repair. Additional indispensable native/ABI
measurement needs a ROOT assignment; this design executes none.

**Exact private presentation fields (proposed).** Add public_transport to the existing
invocation record with exactly version:integer1, control_framing:string
ascii-json-object-v2, and profiles:list of exactly two Profile objects ordered fd1,fd2.
Profile has exactly id:int(1or2), fd:same int, sink_kind:pipe/fifo/socket/regular/tty/
unavailable, presentation:identity/onlcr/unavailable, before:Snapshot, complete:bool,
fault_id:positive-int-or-null. Snapshot has exactly started/ended:{utc:valid UTC string,
mono:finite nonnegative number}, identity:an exact dict with exactly dev,ino,rdev,mode,uid,gid, all exact built-in
integers; dev/rdev in D, ino in I, mode in M, uid/gid in U as defined in NI1,
status_flags:exact integer, descriptor_flags:exact integer, termios:null-or-
Termios, discipline:null-or-exact-integer, complete:bool and fault_id:positive-int-or-null.
An unavailable subobservation retains actual typed native result/error separately and
explicit null in place of an unknown field, never a guessed numeric zero. Nonbool exact
types, valid native numeric domains and all required keys apply. Stamps preserve actual
order; unavailable/invalid types or unordered spans cannot admit complete presentation.
Termios has exactly iflag,oflag,cflag,lflag,ispeed,ospeed:exact native integers, and
cc_native:the existing lossless typed_native snapshot of the ACTUAL native control array.
Capture its full native shape/length; do not coerce one-byte native bytes or integer
VMIN/VTIME values into a fictional uniform representation.

Known non-TTY descriptor types have termios/discipline null without a fake ioctl. TTY
requires actual tcgetattr and the actual platform line-discipline query, not an isatty
Boolean suppressing native errors. Proposed onlcr admission requires complete readouts,
standard pinned TTY discipline, exact output flags OPOST|ONLCR, CS8 output and no FLUSHO;
other translation/discard/unknown state is presentation-unavailable until its own complete
model/controls exist. This does not type-refuse a required normal PTY; its real positive
remains required. Native request/constants/shape are explicit source/API assumptions
requiring ROOT actual installed controls, not proof from a platform name. Snapshot and
Profile include no captured raw source/W, no identity alias and no authority to signal.

T4 write rows additionally require before_profile and after_profile:Snapshot-or-null,
with null only when that actual observation did not complete, plus both actual
observation fault IDs where applicable. profile_id refers to the original fd Profile;
current observations must agree on identity/required controls/presentation fields, not
merely reference an old producer claim. Compare borrowed O_NONBLOCK to the currently
required lease state, not blindly to an initially blocking baseline; compare unowned
controls to that baseline. Preserve raw status-word differences and F2's full local
effect oracle rather than treating all between-write kernel history as mutable control. Actual stdout/stderr snapshots are retained
separately even when a caller proves a shared description. No extra public field is added.

**T4. Ordered actual write evidence and real sink groups.** Per-channel final totals alone
cannot verify stdout/stderr sharing one sink. Extend the existing Evidence memory accounting
and existing command_end fields, not a new event/writer/ledger service, with ordered actual
public-write attempts. Each row has required keys: sequence:positive int; command_id:positive
int; fd:1or2; channel:0or1 with fd=channel+1; source_start/source_end:nonnegative ints with
end>=start; intended_bytes=end-start; source_sha256:64-lowerhex over the actual offered S
slice; profile_id:existing invocation-profile reference; started/ended UTC and monotonic
stamps; outcome:not-admitted/syscall-returned/syscall-raised; returned_count:int-or-null;
written_source_bytes:int-or-null; source_offset_before/source_offset_after:int-or-null;
fault_id:positive-int-or-null; regular_position_before/after:int-or-null. All nullable keys
are required. Captured raw inputs/errors remain the original safe typed envelopes. Register
an attempt before its actual effect; finalize it with actual values before fallible recording.
No new Popen, process-census query, communicate or public write is introduced to obtain
this evidence. Read-only descriptor/profile/position observations are explicit added native
operations inside the existing budget, with strict external-seam and failure controls.

For a valid returned count0<=N<=intended, written source prefix is S[start:start+N], and only
that source count advances the existing delivery offset. Zero still fails the original
progress predicate; invalid/noninteger/raised results leave count/continuity UNKNOWN, never
zero. No new attempts after exhausted time. Existing per-phase suffix checkpoints may retry
only an exact known-count still-undelivered source suffix. Once an attempted command count
is UNKNOWN, that command/channel/public-fd remains fenced against every later payload syscall,
independently of readiness/new observations/phase. Separate start/terminal controls retain
their own original attempts; no blanket public-write prohibition is permitted. Ordered
sequence is invocation-global; command IDs/channel boundaries and per-channel contiguous
prefixes remain independently checked. The sole start attempt precedes command writes;
terminal follows them. Existing terminal_provisional records the final ordered-write totals
and start-attempt accounting before journal close; terminal itself still follows the original
close attempts and requires no post-close journal mutation. A persistence fault leaves the
protocol incomplete; it cannot disappear because a wire comparison happens to match.

The caller context maps actual supplied fd arrangements to actual independently captured
sink groups. Separate pipe/socket/file captures remain separate. For a parent-created dup
or common PTY endpoint, retain the one ACTUAL merged capture and actual descriptor-creation/
Popen arguments; merge source write rows in their actual global order. Never split merged
bytes into a fabricated CompletedProcess.stdout/stderr or infer aliasing from equal inode.
Separate opens of one inode retain separate F1 baselines. For regular shared/independent
opens, compare the actual final file image to the initial independently captured image plus
ordered writes at actual observed positions; append placement is the returned end position
minus N, not a guessed original EOF. Observations use only no-position-change SEEK_CUR reads
where meaningful. Unknown/changed position or overlapping foreign writes leaves presentation
UNOBSERVED/incomplete. Preserve the full initial file prefix and every private S channel.
Actual destructive overlapping redirects cannot promise separately preserved public streams;
their precise initial/write/final-image predicate and cost are part of the T9 contract choice,
not an ordinary stream-positive waiver. Both append and nonappend required route controls
must include real byte-preserving positives and explicit overwrite/partial negatives.

**T4 chronology refinement (H38, following R37-M1).** Complete presentation requires
actual finite nonnegative monotonic stamps in this full order for every write:
write.started <= before.started <= before.ended <= after.started <= after.ended
<= write.ended. The entire write interval lies inside its actual command_begin/
command_end interval; serial command intervals and invocation-global write intervals
cannot overlap or run backwards. Both original baseline snapshots are serial and finish
before the first setup effect. Each setup before/after pair is ordered; fd1 setup's
after ends before fd2 setup's before starts. Both setup effects finish before the
accepted start's before snapshot; that before snapshot ends before its after begins.
The accepted start's after ends before the first command begins or writes. Only existing
actual observations establish these inequalities: start-control accounting has no new
invented outer write timestamp. Existing sequence/source/count/group/position predicates
remain independently required.

UTC strings are actual timezone-zero wall-clock samples bound to the caller's existing
pre-call/post-call UTC interval. Actual command start UTC must equal its command_begin
sample. Monotonic samples establish elapsed/order relationships; no wall-clock monotonicity
or equality between separate wall/monotonic clock domains is inferred. Missing, invalid,
unavailable or unordered observations leave the protocol incomplete. No fresh marker,
post-close write, synthesized stamp, reporting grace or clock/budget change is introduced.
Same-reader controls must retain an unmodified actual-owner positive, then recompute the
private-journal digest after numeric-only overlap, reversal, command-containment or global-
order corruption. Source/P/N/W, native profile facts, offsets, counts and positions remain
unchanged. Missing/type complements remain separately required.

**Actual pre-call caller window (H40, H39-M1).** The existing native fixture
must invoke the real _hook_context before constructing the actual Evidence owner.
Construction itself samples the producer's actual start UTC; recording caller start
after construction reverses the required caller-start <= producer-start <= caller-end
binding on an ordinary clock history. Preserve the original actual source pin, PID
assignment, caller end, native observations and every reader bound. Do not widen the
window, edit any sampled timestamp/start marker, fake a clock, replace a result or bypass
the same reader. The inert warm-up owner remains its existing separate setup object.

A source control must use this same actual native fixture, delegate original context and
owner construction unchanged, and observe their actual call/return sequence. Through the
existing pre-reader inspection hook, require context-call/context-return before owner-call/
owner-return and retain the actual returned object identities. This causal order predicate
is independent of numerical clock comparisons, so an inversion is rejected even if two
real UTC samples happen equal. Do not fabricate traces, force equal clocks or substitute
a mock constructor/result. Real owner/SAME-reader positives precede intended corruptions
and guard-seed qualification; source-present controls remain UNRUN until ROOT admission.

**Fixture private-allocation coordinate.** The existing inert fixture keeps the actual
TemporaryDirectory object and original allocator-returned path. Before the unchanged private-
open guard can run, bind its exact selected owner path to the resolved parent plus original
allocated leaf name. Supply the original allocator-returned path to the actual Evidence
constructor, preserving its own lstat/private ownership, canonical identity and no-follow
open checks. The guard's separately admitted existing native-fixture prefix branch remains
unchanged; a different allocation in the selected inert-root branch remains foreign. Do not
resolve a substituted leaf, broaden the path predicate, admit a foreign
root on a name/alias comparison, change TMPDIR/cwd/environment, or modify the producer,
caller, reader, clock samples, native profiles, output semantics or existing assertions.

Controls allocate real private directories through direct and real test-owned aliased
parents; retain the actual returned allocation and exercise the actual Evidence constructor
and original private-open guard. Independently bind lexical allocation, opened descriptor
and canonical directory identities and require actual descriptor cleanup. A different
allocation with the same basename, its parent alias, and symlinks at the leaf remain negative
controls with unchanged foreign bytes/identity and no newly owned descriptor. No copied
normalization formula or fake constructor result substitutes for these actual effects.
These controls and all dependent original positive/full/scientific routes remain UNRUN
until ROOT qualification after fresh whole nonauthor review. Existing failures remain dated.

**Startup-fault allocation precondition.** The original top-level startup-fault fixture must allocate its actual temporary directory with
the existing production `pre-commit-notebooks-` prefix. Keep the actual TemporaryDirectory
object, its original returned path, default parent and cleanup lifetime. The delegated startup
allocator still checks the original production mkdtemp keyword arguments. This supplies a valid
allocation precondition to the unchanged private-root guard and actual Evidence ownership,
canonical-parent, descriptor-identity and no-follow checks. Do not broaden either guard or
normalize native identity. The events-open branch must retain the original OSError object and
all partial-owner, absent-events, closed-root-descriptor and cleanup assertions; the separate
root-allocation branch retains its original no-owner/raw-stderr/error-identity assertions. No
fake descriptor, clock, skipped case or weakened expected error may supply this precondition.
The source correction requires genuine whole nonauthor review and actual current qualification.

**Original late wrong-readback boundary (H38, R37-M2).** The existing 123456 fd1/F_GETFL
fault activates only during actual public-flags-verify:1 after a complete terminal attempt
and both independent restore operations. Keep the old value and every original oracle,
including fd2's exact native-int FIONBIO tuple and F_GETFL/F_GETFD observations. Trace the
actual activation/first-fault phase, preceding terminal and both restores, and later fd2
audit; do not substitute an earlier fault followed by a later matching operation name.
The separate late-query exception, earlier negative, unknown-count and state-correct late-
error observation-limit controls remain distinct. No input reset, manufactured successful
terminal, timing change or expected-class-only replacement is permitted.

**T5. Same reader and source/received witnesses.** Extend the SAME _events context with optional
actual transport/profile/group/initial-file/post-state witnesses. Existing callers with actual
independent capture pipes retain their API and raw result fields. Native owned-PTY callers
pass the actual child, actual captured wire group(s) and pre-call context using the existing
child/streams/context entry. Any additional group data resides in context, never manufactured
r.stdout/r.stderr. Generic Git/runtime command results bypass hook decoding as before.

The reader parses the start only at the established start position of its actual sink (or
independently observed regular-file offset), then reads that exact no-follow private root
under all original checks. It may provisionally inspect the closed journal to compute the
expected ordered body, but trusts nothing until terminal journal identity/length/hash and
all independent witnesses pass. It consumes expected source/presentation lengths in order,
and parses terminal ONLY at the resulting exact boundary; it never scans command bytes for
marker-looking substrings or filters apparent events. Command output containing NOTEBOOK_HOOK,
braces/quotes/escapes, LF/CR or another plausible JSON marker remains opaque source data.
Require exactly two actual controls, no trailing/unaccounted bytes, source/entry invariance,
all old IDs/channel/fault/semantic-final/close/exit predicates and the full exact presentation.
No independently captured wire means delivery independently UNOBSERVED, never a forged zero.

Terminal hash binds actual control slices; command hashes bind exact S; complete received W
is retained separately by the caller. The same source sentinel/poison/traceback bytes and
multiplicity must hold in exact private S AND the exact expected presentation in actual W.
All current identity-route public-byte assertions stay exact. Do not substitute a reason
field, decoded text, a producer-provided expected hash or a negative exit for either check.
First/later exceptions, both independent known-count suffix checkpoints (UNKNOWN stays fenced), pending contradictory-buffer guards,
closed/short/unknown sinks, null failed-start binding and independent cleanup remain unchanged.
All profile/read/encoding/accounting work spends existing finite windows; no reporting grace,
production early-draining requirement, later-effect retry or hidden native child is admitted.
The owned healthy fixture may cooperatively consume actual receiver bytes at native_ready,
charging actual read/select cost once inside the inherited remainder; retain all52 healthy
requirements and separate original undrained/full-pressure refusals without reclassifying them.

**T6. Post-terminal state and observation limits.** F1–F4's dual initial baselines, acquisition
before ioctl, entire C→A raw-word oracle, unowned controls, independent restore attempts and
final both-descriptor checks remain mandatory. No new terminal mode is borrowed or restored.
The actual native post-state witness must still reject omitted/wrong restoration even with
an earlier negative scientific error/exit2. F_GETFD's descriptor-local limit remains separate.
A state-correct late verification query error after journal/terminal closure may remain
black-box indistinguishable in an already-negative invocation. The actual production-owner
fault control must assert its typed later cause/time/order, unchanged earliest object/args
and remaining fd2 work. That is not native proof of delivery of a new late receipt. Do not
mark full every-late-error observability complete, reopen files, add a marker or silently
accept that limitation as a waiver. Any further observable-contract change needs its own
whole construction/review within H6.

**T7. Exact authorized migrations and conservation.** R36 authorizes only the independently reviewed, operator-approved A implementation and enumerated migrations.
Keep the complete current assertion-source inventory and individual prior mappings. Every
row must retain its original purpose and exact unchanged source unless listed below; the
source implementation handback must link old/current/new spans and all actual case inputs.

| Existing owner/predicate or helper input | Proposed representation migration; preserved independent purpose |
|---|---|
| _events public LF-search loop and raw-slice extraction | T2 bounded self-delimiting object at exact T5 boundaries; actual received slices, strict JSON/types and no hidden command-byte filtering. Private journal LF parsing is unchanged. |
| _events actual raw stdout/stderr == delivered source-range assertions | Literally unchanged for default identity capture. Add explicit actual-sink forward E/source-range and actual merged/file-image predicates for independently witnessed contexts; never weaken to text equality. |
| Large-census public splitlines decoder and start digest slice | Consume actual T2 slices; keep every independent root/PID/time/source and actual-slice digest assertion. No synthetic terminal aliases. |
| Supported512 control's parts decoder/length/digest | Slice actual T2 objects; still exactly two, each <=512, full zero and exact journal/source/digest/no-child. |
| Corruption controls extracting/injecting LF markers | Build actual T2 framed negative bytes with original wrong witness/digest/null/duplicate cases; retain independent recomputed-pair rejection. No fake positive result. |
| Actual corruption tests locating root through splitlines | Parse actual first bounded T2 slice in the SAME reader contract, preserving real private corruption and original failure predicate. |
| _h4_inert flags dispatch and exact fd2 finalizer-effect tuple | F5 narrow FIONBIO/native-int plus explicit F_GETFL/F_GETFD/fstat facts; actual late failure remains at its original verification phase. |
| Required own-pipe whole-initial-word equality | F5 independent baseline Boolean/unowned controls plus entire actual C→A word equality, full actual raw streams/protocol/source/zero/readback; no ignored history mask. |
| Existing external fd facade/helper/context inputs | Preserve required signatures, old samples/clock/byte/exception inputs and source anchors; add optional actual presentation/group observations. Default inert profile is identity, never a facade calling real host descriptors. |
| H84 known-blocked tail, receiver timing and partial OS-capture fixtures | Preserve all old IDs/default calls/full assertions. Explicitly distinguish pre-syscall non-admission from attempted UNKNOWN, charge actual owned receiver read/select elapsed once to original clock/deadline, and keep within strictly-beforeD partial capture plus separate exact-D no-lateINT/safeKILL six-damage complement. No production API or reader migration. |
| Existing scientific raw stderr/poison/sentinel oracles | Preserve literal identity-route public oracles. Add normal-TTY source-and-forward-wire pairs with the SAME exact source bytes; original multiplicity/strict error/single-execution/kernel-residue predicates stay. |

A design handback carries every current assertion and original/prior linked row, including
unaffected rows, and every helper/case/fixture input. No aggregate count substitutes for that
map. Related non-assert decoding, corruption-fixture construction and syscall fault-condition
seams are enumerated as well. The inert extraction namespace must explicitly supply controlled native descriptor,
termios/line-discipline and narrow-ioctl facts used by the actual class; an unhandled
new operation fails instead of falling through to real host stdin/stdout/stderr.
The old actual process observer/parser/helper closure stays strict and separate.
No helper signature/decorator/parameter population, raw source
fixture, original clock/timeout/budget, known-witness fallback, source/index preservation or
H1–H3/H4 identity/history/signal predicate is dropped. New controls add complements; they do
not relabel old failed controls green or retune time to cover transport overhead.

**T8. Required complete native/source controls.** Through the real Evidence/run owner and SAME
reader, require clean and genuine earlier-error controls for separate and shared stdout/stderr
on pipe, named FIFO, socketpair, redirected regular/append files and the unchanged NORMAL PTY.
Raw PTY is a separate comparison, never normal-route qualification. Each actual caller retains
its before/after source/index, actual child/entry/call/root/identity/raw journal/wire witnesses
and independent post-state. Include initial NB false/true, two baselines before any mutation,
shared description and independent opens of one inode, protected append/access controls,
mutation-then-raise, descriptor replacement and every actual query/effect/readback failure.

Use exact source payloads covering bare LF, CR, CRLF, tab, NUL/EOT/backspace/escape/control,
non-ASCII and invalid UTF8, marker-looking bytes, complete tracebacks and original sentinels,
large multi-write suffixes and genuinely empty/not-created/UNKNOWN channels. A normal-mode
positive must verify both exact control digests AND exact source-to-received presentation;
assert its termios unchanged. Add a complement that intentionally predicts identity for
ONLCR output; it must fail without changing the actual W or source oracle. Corrupt only raw
wire CR, raw source LF, profile, write order, source count, group, file position, source hash,
root/source/PID/time/journal/witness/digest and each unique JSON/type field in turn. Raw wire
is never repaired in the fixture. All old duplicate/short/null/count/close/flag/signal and
NONO controls remain. Actual512/exact/one-byte-insufficient preflights stay decisive.

Run full, closed, finite saturated, short-prefix, raised/unknown-count and mutation-between-
observation cases with real counts and explicit observed/UNKNOWN wire ranges. At exhausted
admission no write is invented; final terminal attempt remains independent and capability-
gated. Include both streams broken separately, writable other stream, late returned IO at
each original phase boundary, prior negative plus wrong restore, state-correct typed late
query fault, contradictory returned suffix and direct known-witness cleanup. No new phase
or grace; original required direct CLI KILL and safe sibling/descendant cleanup remain.
Primitive route evidence supports only the measured primitive, not these owner/reader/native
or scientific controls. Actual unfiltered current suite/additions, H5/SDK/assets/MC,
installed common/manual/primary/linked/subdir and production0→nonzero→restored0/current
full-gate/main/closure work remains required after design/source review.

**T9. Concrete alternatives, recommendation and specific decision.** **Decision recorded: the operator explicitly chose A after R35 whole design and intent review; R36 grants implementation.** The alternatives and question below retain that decision's rationale and costs. B is not an automatic fallback. No further contract question is pending for this authorized A construction. Literal old W==S cannot
be preserved for the measured ordinary ONLCR LF case without changing one forbidden element.
Keep that exact failure and ask about the explicit contract, not whether to continue work.

* Recommended A is T2–T8: printable self-delimiting controls, unchanged raw command relay,
  full exact private source and independently admitted FORWARD native-presentation equality
  on actual wire. Normal tracebacks remain readable, identity-route bytes remain unchanged,
  and machine verification gains source/wire/order/profile witnesses. Costs: framing/parser
  migration, real write/group/position evidence, more bounded verification work and incomplete
  status where presentation cannot actually be established. Do not call a prediction measured
  delivery or qualify all terminal modes from the ordinary PTY example.
* Alternative B keeps T2 controls and changes ONLY TTY command relay to lossless printable
  uppercase hex: source chunk x becomes exactly x.hex().upper().encode('ascii'), at most
  CHUNK/2 source bytes per CHUNK wire write. No raw LF/control/non-ASCII remains to translate
  in the admitted ordinary profile. Record separate actual source and codec-wire offsets;
  a short odd wire prefix leaves a known pending half-byte, never advances an unaccepted full
  source byte, and resumes only at original suffix checkpoints. Reader compares the actual
  wire bytes to exact encoded S using the same ordered write/context evidence, never invents
  a decoded CompletedProcess. Source raw hashes/ranges/first errors/cleanup remain exact.
  Costs: double wire volume and encoding work under unchanged budgets, hex instead of readable
  terminal traceback/sentinel text, additional codec/partial-nibble oracles and explicit raw-
  output predicate migrations. This is a meaningful UX/byte-contract change, not an automatic
  substitute or permission for a new runner/writer.

After genuine whole design and separate intent review, ROOT should ask the operator exactly:
"May we adopt option A: preserve exact original command bytes in private evidence and raw
relay, retain exact marker binding, and verify normal-terminal output against its independently
measured native presentation, while keeping identity-route byte equality unchanged?"
The question is required because the old universal received-byte equality is not preserved;
no answer/approval is inferred here. If declined, B is a concrete further contract choice,
not silently selected. Science BUILD and independent publication work continue meanwhile.
Neither alternative or this question accepts the frozen source, native qualification,
late-error visibility, scientific claims, canonical closure, publication/main or human review.


## Coupled observation, custody, settlement and native-caller continuation

This continuation refines pre-admission diagnostics; it does not retry scientific
execution or recover a terminal fault. The existing producer and SAME reader remain
owners. Unsupported owned/pending/ancestor/visible descendant states still refuse.
A complete foreign-only graph proof may reserve one replacement of the same native
query inside the original single observation deadline. Both actual attempts, raw
channels, immutable protected scope, eligibility proof and original error/time stay
in the journal. No partial sample supplies authority. Missing scope/parents, cycles,
changed/pending protected PIDs, any other malformed field, time/storage failure or
persistent UNKNOWN refuses. A fresh strict replacement must complete capture,
parsing and required journal work before that deadline. The reader independently
reparses both raw samples and reconstructs the protected lineage/attempt chain.

The existing Evidence owner reserves ordered immutable event bytes and a cursor
before fallible event writes. An interrupted write resumes exactly its original
prefix before any higher receipt. Raw and typed-fault failures retain their original
incomplete records; separate linked completion records carry actual later capture
and persistence times. Later custody is never retroactive process admission.
Deferred work runs only in already scheduled descendant/final-drain/wait/observation
windows; terminal finish adds no deferred flush grace. A permanent failure remains
protocol-incomplete. Global fault IDs, native-attempt IDs, logical observation IDs
and successful-run observation counts have separate explicit bindings.

When the existing exited-CLI/open-pipe cap expires inside a native observation,
the retained actual return code/open-pipe state determines the cap cause. Earlier
terminal UNKNOWN, signal, raw or executor faults retain their object/time precedence.
The failed observation remains secondary when the cap was first; no reset grace or
late CLI effect follows. Pending command-failure custody uses existing later windows.

The real native fixture owns its named FIFO in a fresh private fixture directory,
registers cleanup immediately, closes endpoints before identity-bound unlink and
never unlinks a foreign/substituted identity. Its required helper construction must distinguish a cooperative healthy caller from an
undrained pressure caller. Cooperative native_ready consumes only actual owned
already-nonblocking receiver endpoints in bounded4096-byte reads, retains ordered
per-group pieces and concatenates the original post-owner drain once. Undrained
socket/shared-normal-PTY pressure callers perform zero receiver reads throughout
owner execution/readiness/cleanup; their actual select retains its original remainder.
A final-after-owner diagnostic drain cannot change earlier write admission. Actual
read activation/phase/count and owner outcome witness each premise; a policy label
alone is insufficient. Actual read/select return/error/timestamps remain evidence;
only actual select results supply writability. Charge the whole observed read-plus-select
interval once to the existing fixture clock, including exceptions before producer postchecks;
select receives only the original remainder. No deadline reset, overhead grace, writer flag,
buffer, terminal-mode, thread/process or producer API change is admitted. File/shared
routes retain actual images/description groups; normal PTY keeps ONLCR/CRLF-to-CRCRLF.
All52 original healthy routes and all49 dependent corruption prerequisites must genuinely
pass before corruption; expected refusals never replace them. Keep the independent real
concurrent caller and original deliberately undrained/full-pressure/capability negatives.
An absent/stopped/failed receiver retains raw bytes, honest incomplete/nonzero delivery,
other-channel independence and finite safe cleanup. Cooperating fixture scheduling imposes
no early-draining requirement on production launch/cleanup. Earlier deferred-read failures
remain failed history; if readiness still refuses, preserve it and obtain separately granted
causal diagnostics rather than invent a producer fix or weaken admission.

Whole source review must check the coupled state machine and each original assertion,
not merely counts. Original native cohorts and all four real-artifact producer/reader
sensitivities remain mandatory, with healthy baseline, intended causal failure,
exact restoration and the same healthy cohort. New queue/proof/cap/FIFO/drain mutations
supplement them. Preserve each actual fixture outcome separately; all44 actual source campaigns
remain UNRUN until genuine review and ROOT qualification.
The original scientific notebooks/cells/data/MC/assets/H1-H6/native/entry/full gates,
all publication BUILD obligations, protected-main and human review remain owed.


### Coupled continuation: exact schema and custody transition contract

`process_observation` retains its original logical sequence/raw/error fields and adds
one fixed start/deadline, immutable pre-call scope, ordered physical `attempts`, and
an `admitted_attempt` only for a fully parsed candidate. Each physical attempt has
its own monotonic identity, launch state (not-attempted/creation-unknown/returned/timeout),
raw references, original diagnostic object arguments/time and complete/foreign-proof
outcome. The private `command_end.observations_admitted` list records only actual
post-journal returns with sequence/attempt/command/commit-time/deadline; a complete
raw candidate without this receipt has no effect authority. `observations_refused`
links failed logical returns to actual fault IDs. Descendant signals retain the old
successful-run sample and add the precise post-journal authority receipt. SAME
recomputes the complete parent graph and retained/pending lineage from original raw
channels, verifies all scope/attempt/commit bindings and refuses protected UNKNOWN.

Evidence event state is RESERVED → FROZEN → WRITING(cursor) → COMPLETE. The ordered
reservation precedes the existing formatter. Immutable byte fragments and exact
actual-written cursor survive any returned-prefix/deadline fault. A formatter that
cannot finish retains its immutable partial image and explicit serialization error;
it cannot be regenerated from a changed object or bypassed by a higher record. Pure
reservation/formatting cost consumes the original deadline and never grants process
admission; the existing returned-operation scheduling limit still applies.
Deferred FROZEN/WRITING records can resume only at existing legal windows. A new
raw copy records `raw_completion(original, available, command, phase, actual time,
original-window deadline)` while preserving the original partial file and facts.
`fault_completion` preserves the original incomplete fault and adds its original
observed time plus actual later argument/errno/OS-field capture and legal-window time.
A `command_channel_pending` is diagnostic custody only; the original capture owner
revalidates cumulative prefixes and commits actual complete suffix records later.

SAME prevalidates the separate completion records against both original failure and
actual complete leaf identity/bytes/digest/prefix/times. Only then do its original
complete-envelope predicates evaluate the explicit effective view. Frozen initial
records stay in the returned journal; no incomplete fact is overwritten in storage
or converted to success by a Boolean. Permanent missing custody remains protocol-
incomplete. The original event whitelist gains only these explicit guarded record
kinds; each original assertion otherwise retains its expression and function context.
All source, actual-control and scientific acceptance boundaries above remain.


### Current observation and legal-custody proof closure

At the first unsupported row, reserve one exact Refusal and monotonic time before continuing complete-stream validation. Install the held diagnostic before foreign-proof work. When terminal evidence is needed, merge it with actual queued signals and parsing/native/IO faults by their detection times before formatting or sink costs. A later malformed row, failed proof or late replacement retains the original UNKNOWN, while an earlier actual signal remains first. A proved foreign-only diagnostic stays nonterminal only through successful replacement and journal admission under the same deadline.

Every current observation has the closed attempts/scope/start/end/deadline schema, with complete or refused disposition tied to the command end. Every actual descendant signal emits a copy of the current command/sequence/native-attempt admission and selected full identity; stale, absent, wrong-command or expired receipts cannot authorize an effect. Inert extracted source boundaries remain explicit and cannot produce native SAME acceptance.

The existing Evidence owner freezes custody-window beginnings before deferred work. Each beginning binds a unique window identity, originating command, phase, actual scheduling/opening times, unchanged configured budget and deadline. Run retains actual closing times and completion-admission receipts in command_end. A completion identifies its original command, capture window and capture interval; its post-journal admission identifies the actual commit/resume window and strict commit interval. The independent reader checks both against frozen beginnings, actual closures, command bounds and the original phase schedule. A completion can resume immutable event bytes in a later existing window, but cannot revise an earlier deadline or invent finish grace.

All already complete original typed arguments, errno, OS fields and requested native details are identical in a completion. Native-detail payloads are retained as exact safe builtins before deferred use; an unavailable snapshot stays incomplete rather than being reconstructed from a changed mutable value. Original raw file identity, close result, prefix, available length, cursor and hashes remain fixed. Current missing-field, native-detail substitution and coordinated future/backdated window corruptions are rejected even after journal length/digest rebinding.

Actual source-sensitivity campaigns stay UNRUN; retain recorded fixture outcomes. Preserve original H1–H6/H5 scientific intent, original complete selectors and oracles; add genuine single-owner producer/reader countercontrols with healthy baseline, intended nonzero assertion failure and exact restored healthy evidence before acceptance.


### Original native obligations and ordered semantic receipts

Before any fallible typed snapshot, the existing fault owner freezes the actual native capture obligations: BaseException.args has outer tuple shape, and an actual OSError requests filename, filename2 and strerror. Completion must discharge those exact obligations even when the initial capture had no field assignment. Every complete original value, including native details, stays exact; exception-name text never decides whether OS fields were owed.

The capture window beginning is reserved before a completion, and capture ends before actual completion-byte commit starts. The reader checks those original command/journal/identity/time relations. A later legal resume window may begin behind already pending completion bytes in the queue; only the capture window must precede the completion in journal order. No new timer, replay or finish grace follows.

Every observation binds supported actual phase and launch-state vocabulary, valid UTC/monotonic intervals within the original command, current pre/post-launch scope, and the logical summary to its final actual attempt's raw references and return code. Complete candidates that fail journal admission remain refusal-only with no effects. All original raw, parent-graph, ownership, native bool/type and single-deadline proofs remain required.

Controls must witness the operation they name: failed graph proof and second-query signal detection require actual proof/query activation and cause/count evidence. Parsing-time signals retain their honest earlier-checkpoint scope. A completion-write control first witnesses a reserved completion identity, then arms that exact completion's returned write or admission boundary; capture, serialization, prefix/event write, admission and rollback stay distinct. Healthy/intended-causal-red/exact-restored-healthy actual source sensitivities remain mandatory. Current fixture outcomes remain their recorded actual results; all44 source campaigns remain UNRUN pending whole review and ROOT qualification; all original H1-H6/H5/scientific/native/publication/main/human obligations remain full strength.


### Whole-module repair: authority, original bytes and scheduling

Current work is a source candidate requiring whole independent review and fresh
qualification. Historical failed runs remain failed. An unsupported native process
state in protected lineage must still refuse; neither a harness repair nor a later
healthy sample grants authority to that observation.

The extracted source fixture enters the actual command scope before calling a run
helper directly. Owner-only tests retain startup scope. The production command,
logical sequence, physical attempt, full identity and unexpired admission remain
required for every descendant effect. A fixture tap reads from the actual current
private Evidence owner and records its own unavailable-read diagnosis rather than
raising a second, unrelated path error. Physical query calls are recorded before a
fallible test-supplied boundary returns, so a failed second query remains an actual
second invocation. Scientific execution is never synthesized by these adapters.

Fault chronology uses original observation times and an invocation-local reservation
order to resolve equal-clock causes. A signal detected before an unsupported row
stays first; the opposite actual order stays opposite. This internal tie-breaker
neither rewrites raw native data nor changes the original first-fault grace.

A serializer failure may leave an available immutable original byte prefix. That
prefix is committed only under the existing deadline/cursor rules, never replayed
or reserialized; the incomplete record blocks all higher records and remains
protocol-incomplete. A later legal custody window may persist a frozen fault;
tests separately retain its original incomplete/unpersisted state and the later
linked completion instead of treating mutable final persistence as its past state.
Terminal finish grants no new deferred window.

Public command relay may wait for actual descriptor writability inside its original
remaining window before its first nonblocking write attempt. Start/terminal atomic
controls are unchanged. Readiness is scheduling only: it does not prove identity,
flags, a returned count or received bytes. Native snapshots, whole control words,
exact source counts, raw custody, normal-terminal presentation and independent
receiver evidence remain mandatory. A raised/invalid-count command write latches
UNKNOWN for that exact command/channel/public descriptor before fallible recording;
every later relay of that command channel refuses before another payload syscall.
Readiness, fresh descriptor facts and a later phase never recover its unknown count.
Only a trustworthy exact returned count permits the still-unaccepted original suffix
at an already scheduled checkpoint; zero is known but does not prove progress.
Independent start/terminal control attempts retain their original separate semantics.
There is no fabricated count, replay or enlarged deadline. Deliberately undrained
pressure remains a bounded negative; other-channel delivery and cleanup stay independent
of receiver cooperation.

Native fixture postconditions name the exact launched/captured cohort and exact
allowed cleanup effects. A legitimate refusal cannot be mislabeled full payload,
zero effects or completed scientific execution. Positive controls retain exact
payload, launch and no-unowned-effect assertions. Instrumentation targets a unique
run seam and preserves the original CLI identity/argv. Original scientific inputs,
all nonempty cells, assets, strict errors, process ownership, custody, caller routes,
production sensitivities, full gates, publication BUILD, main and human review remain
full strength. New fixture source requires independent review and qualification; actual source campaigns remain UNRUN.


## H79 — exact command UNKNOWN continuity, separate control attempts

H80 accepted the bounded H79 source; H81 actual full qualification remains FAILED.
The frozen H90 precode state was superseded by the H92 coupled design and H93 whole design acceptance/ROOT intake. H94 source is now authored, with whole independent source/evidence review and later ROOT qualification still separate;
source presence and author units are not accepted transport/scientific completion.
An attempted command payload write that raises or returns None/bool/negative/out-of-range
count may have emitted a real prefix. Retain that actual attempted source range/raw
capture, UNKNOWN returned count and global continuity, original first exception/object/time,
and fixed phase budgets. Latch the exact command ID/channel/public-fd scope before any
fallible diagnostic capture. Later cli-grace, existing cleanup checkpoints, final-drain
and final-observation calls may retain new raw bytes and truthful faults, but must not
issue another command payload syscall on that latched channel. Native writability or a
new snapshot does not recover a missing count. No new retry window or finish grace.

A valid exact short count advances only its accepted prefix; a later original checkpoint
may send only the remaining suffix. Zero stays a known count with zero progress and
unchanged offset. Independent other-channel tails, CLI/descendant cleanup, original
2/5/15/120 budgets, flags restoration and nonzero first-cause exit remain required.
The separate original start and terminal atomic control operations are not command suffix
retries: preserve both actual attempts, including original unknown prefix NONO/counts[2,2]
controls. Do not install a blanket public_write or whole-descriptor shutdown.

Add actual producer relay controls using an owned real sink/write seam: emit a nonempty
prefix then raise or return None/bool/invalid count, invoke the later original phases,
and prove exactly one command syscall, independently received exact prefix, UNKNOWN
binding, original cause/time/deadlines, safe other-channel tails/cleanup/flags. Pair exact
known short/zero/suffix positives and unchanged independent-control complements. A separate
real-production mutation removing the exact relay UNKNOWN fence must cause the intended
no-second-command-syscall assertion failure; all43 earlier recipes remain required. Every
sensitivity remains UNRUN until whole review/ROOT grant, then existing seed_journal healthy
-> sole actual source causal red -> exact bytes/fullmode/nsmtime restored healthy with
same IDs/raw channels/origins. Fixtures/assertions alone do not establish production proof.
Original H76 failed profile, H1-H6/H5 notebooks/data/assets/MC, independent SAME reader,
current native/common/manual routes, gates, protected Git/main and all21/B1-B8/D12 full
scientific/material/formal/publication/human objectives remain owed without reduced scope.

### H92/H93 accepted receiver, handled producer and fixture capture contract — H94 source authored, review pending

The H92 design corrected H91-M1 and received genuine whole H93 nonauthor DESIGN acceptance and ROOT intake before H94 code. H94 source is authored; it has not received independent source/actual-evidence acceptance or full qualification. H90/H91 and all failed runtime receipts remain frozen history.

The designated healthy pressure transport control uses the existing helper with
route="socket-shared", initial=False, earlier_error=True, original
payload=b"PRESSURE\r\n" * (1 << 17), default stderr_payload=None and cooperative
receiver policy. Its expected helper result is2 with the original nonzero CLI cause
first; healthy means full transport/source-wire/control/SAME and native restoration,
not successful science or hook result0. It uses the existing error's relay window,
not a fabricated success deadline. Preserve every original helper result expectation
`2 if earlier_error else 0`; deadline-free successful small cases need not call native_ready.

Both original socket-shared and normal-PTY-shared pressure negatives keep their
original payload, initial/error profiles, native modes, other channel and expected
AssertionError predicate, with explicit undrained policy. There are zero receiver reads
during owner execution/readiness/cleanup, while select still observes the original
native endpoint under its original remainder and single measured elapsed charge.
Final-after-owner diagnostic reads cannot change prior admission. Direct zero-read
assertions run outside every expected-error catch using actual preteardown trace;
an unrelated SAME refusal cannot establish the premise. The required healthy
pressure control independently requires positive actual during-owner bytes and full
source delivery. Opposite-policy real-source regressions must fail these direct
premise/delivery predicates, never merely raise an arbitrary error.

Initialize observation/acquisition/registration and independent producer-outcome / ESCAPING-fixture-latch / per-owner-finish states before the first fallible setup/finish/launch/open/snapshot. Preserve original handlers and cause/deadline ownership as follows.

### H91-M1 — original handled producer outcome and escaping fixture failure

Initialize TWO distinct local observations before fallible work: the producer's original handled outcome/cause and the fixture's write-once ESCAPING-error latch. This is no new owner/framework. Producer Evidence keeps its actual first object, typed native args, available original traceback, original observation phase/time/order/deadline and full history. Record actual run-caught problem, unexpected decision, each Evidence owner's finish-attempt state and finish's RETURNED value separately from an exception RAISED by finish. Never call Evidence.fault again to reconstruct/retime the producer cause or create another grace.

The fixture latch covers original exceptions escaping their original handled region, plus actual new capture/cleanup/emission failures. Reserve that exact object/native original traceback/monotonic observation time before formatting/native diagnostic/IO; later fixture faults preserve their own objects/TBs/native args/time/operation/order. The expected run producer Refusal handled by the original helper is DATA, not automatically an escaping fixture exception. Normal internally handled EAGAIN/EOF branches are likewise not fixture faults. This is actual original control-flow/owner classification, NOT an all-Refusal type whitelist: a preparation Refusal still escapes, a different producer Refusal cannot qualify healthy by type, and a later strict-SAME assertion still fails.

If the original earlier_error=True path completes all original byte/source/wire/control/native/SAME/effect/index/launch assertions, no fixture fault exists and cleanup/receipt succeed, return its ORIGINAL outcome/result2/problem unchanged. Original error=False result0 expectations remain. Do not promote handled producer to throw, change2 to0, suppress incomplete producer evidence or accept any expected-type exception. The designated pressure control additionally needs the actual inert rc7 executor-returncode cause FIRST with the original object/native args/time/deadline and full delivered bytes. Result2 alone is insufficient.

With that handled producer already present, a NEW capture/emitter/callback failure is an escaping FIXTURE fault. The same fixture object/native TB/time must escape after all independently safe cleanup/actual context exit/final receipt, while the producer first-cause record stays unchanged and separately retained. The producer problem neither hides the new fault nor becomes a fake fixture primary. An original escaping assertion plus two actual callback faults keeps the assertion primary and both callback objects/order secondary. With no escaping body fault, the first actual capture/cleanup/emission failure becomes fixture primary; neither success nor a handled result may then return.

Trace the ORIGINAL helper paths explicitly:

| Existing flow | At-most-once owner and return/raise requirement |
|---|---|
| Initial _h4_inert owner before replacement | d['owner'].finish(None) belongs to the first Evidence owner. Track NOT_ATTEMPTED→ENTERED→RETURNED(value) or RAISED(object/TB/time). Never call it again. A raise escapes as fixture primary and must not continue to create the actual native owner; a returned value remains an independently recorded return, preserving the original decision to proceed, never feeding it into the later owner's problem/result or fabricating result2. |
| Actual native owner setup/acquisition/prepare | Initialize local states before creation/open/register/snapshot. If owner does not exist there is no finish target; preserve safely acquired capability cleanup only. owner.prepare exception is an original escaping fixture error even if Refusal. Reserve it BEFORE original owner.fault or diagnostic IO, then independently attempt the existing owner.finish(error) path at most once when actually owned. A reporting failure cannot skip that original finish/other safe cleanup or replace the prepare object. Returned finish problem is data; raised finish is secondary to prepare. |
| Original run catch | Keep actual problem=error and the original handler's unexpected decision. The actual expected executor-returncode Refusal from inert rc7 remains handled and its producer record/deadline unchanged. A non-Refusal marked unexpected is destined to rethrow: reserve its actual fixture identity/TB/time at detection while preserving original post-run/finish cleanup before propagation. Normal inner EAGAIN/EOF handling is untouched. No generic type-based healthy classification. |
| Original success report | Keep actual_report('success') only in its original problem-is-None branch. An exception raised by it is an escaping fixture fault, not a manufactured handled producer outcome. |
| Actual owner.finish(problem) after run | Same actual owner as prepare; prepare-failure and post-run finish paths are mutually exclusive. Mark ENTERED before call and never retry after return OR raise, including partial close. A returned problem remains actual producer/outcome DATA and is retained separately from incoming problem. An actual raised finish exception escapes as fixture fault even when the producer problem was already handled. Preserve original finish order, native/public cleanup and full cause history. |
| Post-finish observation/inspect/full original assertions | Post snapshots, final-after-owner drain, inspect, _events and every original source/wire/effect/index/launch/native predicate remain. Their actual escaping error becomes fixture primary if none exists, even with handled producer. No second finish can rescue failed evidence; a returned problem cannot prove completeness. |
| Unexpected rethrow or valid original return | Preserve original unexpected object's saved native TB/time through cleanup. With no fixture latch and all predicates complete, return original dict/problem/result unchanged. Otherwise propagate exact first fixture object after actual context exits and final receipt handling, retaining producer cause independently. |

The first inert Evidence owner and the later actual native Evidence owner have separate finish states. The latter has mutually exclusive prepare-failure/post-run single-finish paths. A returned problem and a genuinely raised finish exception MUST remain distinct. Capture existing producer time/deadline facts before original finish resets its deadline field; do not replace its original command_cleanup_deadline/settlement cap or confuse fixture observation time with producer time. Record unresolved/partial states honestly; do not invent an owner or retry partially completed finish. Fixture diagnostic failures belong in the local fixture receipt/latch, not in a rewritten producer first cause.

Direct REAL-COMPOSITION paired controls, all prospective/UNRUN: require the designated cooperative socket-shared initial=False/earlier_error=True pressure helper actually RETURN its original outcome/result2, actual problem identical to the original executor-returncode first object from inert rc7, full source-wire/control/SAME/native restoration and positive actual during-owner read bytes. Record returned versus raised explicitly and assert returned/no fixture escape OUTSIDE generic expected-error credit. Keep the whole original52 matrix (26 expected2 and26 expected0). A sole future actual-source promotion-to-throw mutant must fail that exact helper-return/result2 predicate; Refusal is not an acceptable substitute result.

On the same genuine handled-producer path, independently induce actual capture, final-emitter and first original callback faults. Require their exact fixture object/native TB/time after cleanup, producer first object/record/time/deadline unchanged, all later independently safe callbacks attempted and actual existing stack empty. Add original escaping prepare/SAME/body assertion plus TWO real callback faults, and actual finish-returned-problem versus raised-finish and both owner states/partial entry/no-second-finish cases. Real owner/ExitStack/endpoints and source integration over complete acquisition/cleanup paths are required; a copied helper, isolated latch unit, artificial error list, already-result2 or any-error waiver is insufficient. Later accepted implementation must supply exact actual source anchors/inverses and genuine healthy→intended causal red→exact same-ID restored healthy evidence. No test/source/runtime grant or old44 retirement follows from this design.

Freeze already-read ordered bytes plus exact length/hash/base64, original argv/cwd/Popen PID and stored returncode, prior native observations and original witness path/read/parse/identity observations while resources remain owned. Never poll again merely for diagnostics. UNOBSERVED/null is distinct from actual returned empty bytes, EOF, partial prefix or TimeoutExpired.output/stderr=None. A diagnostic reference parse grants no SAME, absence or signal authority. Preserve producer original time/deadline and fixture actual first-escape object/TB/time separately before any diagnostic work.

Then independently attempt every original child cleanup and actually known identity-bound
witness action under its original order/identity/bounds. Guard each original ExitStack
callback at registration so its actual failure is captured immediately and cannot skip
later callbacks. Record acquisition versus registration, including partial pair setup;
clean only safely known acquired-but-unregistered capabilities once, never double-close
registered resources or invent FIFO identity. No second Evidence.finish, new signal
ownership, extra wait/poll/grace or global absence claim is admitted.

Run guarded explicit resources.close() on the actual existing stack, retaining each
callback failure and leaving the outer stack empty before final propagation. Hold the
escaping fixture exception through the actual outer context exit; an inner bare raise is insufficient
because a later callback could mask it. Callback guards retain individual faults, not
only the final close exception. Frozen preteardown facts plus separate cleanup outcomes
form a postcleanup receipt on the existing diagnostic sink. Emit only after all cleanup;
do not reobserve endpoints/witnesses after close. Emitter failure is secondary to the
held first escaping fixture cause and cannot prevent completed cleanup. A handled producer problem is independently retained and cannot hide an actual emitter failure. An unavailable sink is explicitly
unretained. With no escaping fixture body failure, the first capture/cleanup/emitter error becomes FIXTURE primary, including when original producer problem is handled.
After actual contexts/emission, propagate the same first FIXTURE object with its saved original traceback through the native traceback mechanism. If no fixture fault exists and all original predicates completed, return the unchanged original handled outcome/problem/result, including genuine earlier_error=True/result2. Never throw a producer problem merely because non-null, convert2 to0, call finish twice or accept incomplete source/SAME evidence.

Only the real native caller may query an otherwise unobserved post-state: at most once
for the actual still-owned shared writer, using existing _r36_native_snapshot under its
actual original tick+300 deadline. Existing final snapshots, missing/unowned writer,
unestablished deadline, exhausted time or unavailable capability mean zero new queries
and null/partial with reason. Check positive remaining time before and actual time after;
retain elapsed/error/partial/overrun, never retry/reset/query per logical fd/double debit.
Synchronous native calls have cooperative budgets; checks do not interrupt a blocked syscall
or establish a hard wall-clock guarantee. Overrun authorizes no further diagnostic/admission
work. The inert helper uses existing post observations and adds no query. This diagnostic
cannot repair the witness, admit SAME or grant another census/process observation.

Prospective controls cover both actual caller owners and the native helper: before launch,
partial acquisition/registration/initial snapshot, witness/partial-read/strict-reader faults,
first escaping fixture body error plus independent snapshot/emitter/two cleanup failures, no-escaping-body-error first
capture/emitter/cleanup failures, every later callback still attempted, exact first
object/TB/native args/time, immutable bytes before actual endpoint closure and final receipt
with cleanup outcomes. Use the real existing ExitStack and real owned endpoints, not fake
close or inner-finally-only proof; verify actual stack empties and endpoints close where safe.
No-time/unowned/existing-snapshot and query-error/overrun controls expose extra native work.
Bounded shared-seam units and source integration guards do not replace separately authorized
actual real-caller/kernel/witness/source-campaign qualification.

Three original lifecycle/corruption positive prerequisites remain OWED after correct
second-query UNKNOWN refusal. Exactly one completely proved foreign replacement, original
observer/firstcause/raw predicates and all fixed budgets remain; no filtering, normalization,
extra retry or green-seeking rerun. The missing normal-PTY cause remains UNKNOWN. None of the
five qualification failures is declared resolved by this design. Fresh whole nonauthor design
review/ROOT acceptance precede code release, then whole independent source review and separate
ROOT full/native/scientific qualification and all original plus new actual causal/restored
controls precede canonical closure/protected delivery/human publication acceptance.
Canonical OPEN/BUILD findings:
`papers/AutomatedReviews/2026-10-21-hook-native-fixture-premises/infra.md` §§1.1–1.2.


### H94 historical author evidence; H96 corrective work after H95 review

H93 whole nonauthor review accepted the complete H92 design and ROOT intaken that bounded design. H94 authored the prior coupled source candidate. H95 identified incomplete known-witness enrollment and unregistered LIFO; H96 authored the complete corrective construction, preserving: cooperative versus undrained receiver premise, original handled-producer result2 versus escaping fixture latch, precleanup observed-fact freezing, guarded actual callbacks and original child/known-witness actions, explicit empty original ExitStack/outer exit before final receipt and exact first-exception propagation. The optional shared-writer diagnostic uses only the existing positive tick+300 remainder; inert helper adds none. All original assertions, producer, strict SAME, native budgets, scientific objectives and old source-control obligations remain.

The original54 author baseline is 53PASS1FAIL (socket negative DID NOT RAISE); no failure is erased. Source implementation and bounded author development are complete and not independently accepted. Canonical findings remain OPEN/BUILD; full Verify and actual source campaigns, full-native/scientific qualification, closure and protected delivery remain ROOT-owned and owed. H86 three correct UNKNOWN positive prerequisites and missing PTY witness remain unresolved.


H94 terminal author evidence recorded 2026-10-21T19:46:29.941746+00:00. The measured receipts are in `outputs/continuity/hook-H93-complete-fixture-source-author-20261021-r94/runtime.json` and full raw/XML, with whole-source controls and images in `evidence.json`/`source-images.json`.

| Actual bounded receipt | Passed | Failed | Errors / skipped | State |
|---|---:|---:|---|---|
| Original unchanged baseline | 53 | 1 | 0 / 0 | Socket negative DID NOT RAISE; retained |
| Initial authored development | 84 | 0 | 0 / 0 | Retained source/raw/XML |
| Expanded development before inert fixture correction | 89 | 5 | 0 / 0 | Missing inert index-read fixture; all five complete bodies retained |
| Complete current development | 94 | 0 | 0 / 0 | Same expanded IDs, author evidence only |

The source extends the existing owner scopes rather than adding an executor or acceptance reader. Registration tracks a callback that appended before raising, so a pair closes once; original actual owner failure finish is attempted once when its already acquired root capability exists, and never retried after entry. Communicate attempts are recorded before invocation, keeping UNOBSERVED, native `None`, actual empty/EOF, and TimeoutExpired partials distinct. Frozen bytes precede original cleanup; individually guarded original callbacks run LIFO, actual stack exits precede final receipt, and a new capture/cleanup/emitter fault cannot hide behind a handled producer problem. The complete real-caller source is covered by source-binding guards and bounded helper/caller controls; real Popen/kernel/witness execution was not performed here.

Every historical original source recipe remains whole and UNRUN; the real-caller receive-omission recipe has an indentation-only current-source derivative, with the historical object preserved. New actual-artifact recipes and exact inverses are DATA/UNRUN. No protected entry or hook is loaded by this work. Full native/scientific/once-only/kernel/byte assertions, UNKNOWN/one-retry, original deadlines, all scientific BUILDs, canonical closure, main delivery and human review remain owed.


H94 final observational-source evidence supplement (2026-10-21T19:53:46.267290+00:00): the current same-ID bounded cohort again passed with passing-output JUnit logging. Independent test-observer teardown exports ONLY already-held precleanup/native/fault/callback data. It does not reobserve endpoints, retry a failed fixture emitter or admit a new budget. An actual export/undo failure is retained separately and propagates the already-held first fixture object/native traceback when present, otherwise its own first error, after the original monkeypatch cleanup attempt. This is diagnostic source behavior, not merely logging configuration; its source binding is checked, while deliberate export-failure source campaigns remain UNRUN. All prior source/runtime attempts and lost-passing-output limitations are retained. Final XML contains the complete passing observations; no transient private journal is claimed durable beyond the actual retained caller data. Whole source/actual-evidence review and ROOT full qualification remain pending.


### H96 complete H95-M1/M2 source repair — author complete, independent review pending

H95 whole nonauthor review/ROOT intake is REQUEST_CHANGES, not H94 source acceptance. Its two MAJOR obligations are coupled with the entire accepted H92/H93/H94 construction. In `_observe_real_hook_child`, enroll every actually obtained witness immediately in original file order before any next fallible witness operation; no new read/census/poll/retry/identity is granted. In `_H94FixtureCapture.register`, unwind acquired/unregistered callbacks in reverse acquisition order while keeping already registered callbacks on the same original ExitStack and preserving postappend detection/once-only original function+args.

Direct original-helper controls must independently fail second exists/read/parse/identity after the first obtained identity, cross the known safe stop with a secondary cleanup fault, preserve exact first object/native traceback/original observation time, partial UNOBSERVED facts, original child then known cleanup and remaining independently safe actions. Missing-first invents no identity; healthy and delayed observation retain original file order. Pair controls must cross both registration positions/pre-postappend and both actual post-real-close faults, require exact [second,first] original function/args/ordinal order once, same registration-first object/TB/time, both native descriptors EBADF, at-most-once finish and actual empty original stack/outer exit before receipt and propagation. Count-only/EBADF-only controls are insufficient.

The original94 bounded baseline is measured green before source repair; no full source/native/scientific acceptance follows. All44 historical+9 H94 actual source campaigns remain UNRUN; new exact actual-artifact causal recipes remain DATA until separate ROOT grant. Canonical findings stay OPEN/BUILD; full module/native/real notebooks/H1–H6, three UNKNOWN positive prerequisites, unknown normal-PTY witness cause, all21/B1–B8/D12 scientific/formal/calibrated-band/G4/main/human and protected entry duties remain owed. No service/backend/registry/Git/lease/book/closure authority is added.


H96 bounded author evidence recorded 2026-10-21T20:34:53.432355+00:00: unchanged original94 baseline PASS94; current original94 plus21 literal/direct-source controls PASS115/0FAIL/0ERROR/0SKIP with complete passing raw/XML receipts. Actual original witness helper controls preserve first-known enrollment through second exists/read/parse/identity faults (with and without a secondary safe-stop fault), no invented missing identity, healthy/delayed original order and remaining known cleanup. These use explicit inert index/launch/identity/reader boundaries, not genuine Popen/kernel/witness qualification. Actual original native-helper pair controls verify original function/args/ordinals [second,first] for both registration positions/pre-postappend, with and without both after-real-close faults, exact registration-first object/nativeTB/time, real EBADF, at-most-once finish and original empty-stack/outer-exit receipt. No budget, route, producer, SAME or original assertion was weakened. Whole source/evidence review remains pending; all53 old plus2 new actual source campaigns, full current module/native/real notebook/H1–H6/scientific/G4/main/human duties remain owed. Receipts and exact images/inverses are in `outputs/continuity/hook-H95-complete-cleanup-source-repair-author-20261021-r96/`.
