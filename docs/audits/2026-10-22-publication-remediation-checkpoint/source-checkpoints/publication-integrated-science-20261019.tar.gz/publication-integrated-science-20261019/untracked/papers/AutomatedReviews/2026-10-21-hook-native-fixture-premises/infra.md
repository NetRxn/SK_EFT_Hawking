# Native notebook-hook fixture premises and failure-capture construction

Review date: 2026-10-21. Status: OPEN / BUILD. H92/H93 whole design accepted and ROOT-intaken; H94 complete coupled source authored with bounded author development only. Fresh whole nonauthor source/actual-evidence acceptance and ROOT full qualification remain pending. H88 remains unfinished history; H86 full failed result and H87 diagnostic acceptance are not replaced.

### 1.1 — A shared cooperative receiver invalidates the deliberately undrained pressure premise

- **Severity:** major
- **Lane:** infra
- **Gate:** `notebook_exec`
- **Location:** `tests/test_pre_commit_notebooks.py::_r36_native_case` and `test_h65_deliberately_undrained_native_pressure_remains_protocol_incomplete`
- **Target:** explicit caller receiver premise in the existing helper and both original pressure routes; owning routing spec/plan and QA/topology.
- **Observed:** H86 socket-shared pressure negative DID NOT RAISE. Whole source unconditionally drains actual receivers at native_ready for both healthy and deliberately undrained callers. The passing PTY negative shares that same reachable receive path and does not establish the declared premise.
- **Required repair:** designate socket-shared, initial=False, earlier_error=True, original payload=b"PRESSURE\r\n" * (1 << 17), default stderr_payload=None and cooperative policy as the required healthy transport pair. Expected helper result2 retains the original CLI returncode7/first cause and full strict SAME/source-wire/native restoration; it is not hook/science result0 or a new success deadline. Preserve every original52 result expectation. Both original negative routes keep payload/error/native/other-channel/cleanup predicates with undrained policy and zero during-owner reads. Assert the actual zero-read premise outside all expected-error catches, even if SAME separately fails. Healthy transport independently requires positive actual during-owner bytes and full delivery. Forced cooperation/no-receiver actual-source regressions must fail their intended direct premise/delivery assertion, not any error; final-after-owner reads cannot repair prior admission.
- **Verify:** `python -B -m pytest -q -p no:cacheprovider tests/test_pre_commit_notebooks.py`
- **Verify status:** OWED — H88 historical original54 baseline is retained, and that interrupted task has no FINAL. H92 is design-only and runs no controls; any later author development needs its own exact grant. Full qualification and all actual44 production campaigns remain owed. H86 remains failed. Genuine whole nonauthor design/source review, full actual qualification, all causal controls and protected delivery are required before closure.

### 1.2 — A failed real-native witness can lose its only raw/endpoint evidence before teardown

- **Severity:** major
- **Lane:** infra
- **Gate:** `notebook_exec`
- **Location:** `tests/test_pre_commit_notebooks.py::test_r36_real_hook_native_sink_science_once_and_same_reader` and `_observe_real_hook_child`
- **Target:** failure-safe diagnostic observation inside original fixture ownership and cleanup, without changing admission or witness predicates.
- **Observed:** H86 normal-PTY success case fails its actual kernel-witness assertion before final wire/transport/native-state construction or raw emission; in-memory pieces are unretained after ExitStack. Its cause remains UNKNOWN. Three other failures retain correct UNKNOWN refusals, which do not satisfy original lifecycle/corruption-positive prerequisites.
- **Required repair:** initialize independent producer-outcome and ESCAPING-fixture-latch/finish/acquisition states before fallible setup/open/prepare/finish. Original expected run producer Refusal/result2 remains HANDLED DATA when all original source/wire/control/SAME/native predicates succeed; it is not thrown merely because non-null. Preserve producer actual first object/native args/TB where available/original phase/time/deadline/history independently. Fixture latch covers original exceptions escaping their original handled region and new capture/cleanup/emission faults; preserve SAME fixture object/native TB/time before fallible work. No all-Refusal whitelist: prepare Refusal and later strict-SAME AssertionError still escape; normal EAGAIN/EOF and actual internally handled producer outcome do not become fixture faults. Trace initial inert owner finish(None), actual prepare-failure finish(error) versus mutually exclusive post-run finish(problem), returned problem versus raised finish and original return/raise paths; each owner finish at most once, never retry partial entry. A handled producer cannot hide a real fixture fault or replace its primary; original escaping assertion plus two callbacks keeps assertion primary. Freeze actual precleanup ordered bytes/hash/base64/original argv/cwd/PID/stored rc/native/witness facts with truthful UNOBSERVED/EOF/None distinctions; no diagnostic poll. Independently guard every original child/known-identity action and each original ExitStack callback at registration, preserving LIFO/partial registration and later safe cleanup. Explicitly close/empty actual outer stack before propagation. Final existing-sink receipt combines frozen facts and actual cleanup outcomes after context exit; emitter fault is fixture-primary if no earlier fixture fault, even with handled producer, and cannot prevent cleanup. Propagate SAME fixture object/saved TB only after cleanup/emission; with no fixture fault/full original predicates, return original handled result2/problem unchanged. Optional once-owned-writer snapshot retains original positive tick+300 remainder, one shared query/no retry/per-fd/double debit/null when unavailable; cooperative checks are not hard interruption. Keep all receiver/UNKNOWN/one-retry/native/SAME/budget and five qualification obligations.
- **Direct composition controls:** actual designated error=True pressure helper must RETURN genuine result2 with original inert rc7/executor-returncode first object/time/deadline, complete SAME/native restoration and positive during-owner readbytes. Sole promotion-to-throw must fail explicit helper-return/result2 predicate OUTSIDE any expected-error credit. With same handled producer, actual capture/emitter/first callback fault must escape as that SAME fixture object/TB/time after all later safe callbacks, producer first record unchanged. Include original escaping assertion plus two callback failures, actual returned-versus-raised finish and both owner/partial states/no-second-finish. Real owner/ExitStack/endpoints/source integration required; latch-only/copy/any-error/result2 waiver insufficient. Exact future implementation anchors/inverses and actual healthy→causal red→same-ID restored healthy remain owed, with original52 expectations unchanged.
- **Verify:** `python -B -m pytest -q -p no:cacheprovider tests/test_pre_commit_notebooks.py`
- **Verify status:** OWED — bounded author capture controls are not real-kernel/full-module evidence, and no cause-specific PTY behavioral fix is established. The original pipe-holder/corruption baseline obligations remain open after correct exactly-one-replacement UNKNOWN refusal.

## Accepted assignment and closure boundary

Author: hook_coherent_whole_review, H94 SOURCE assignment after H93 genuine whole nonauthor DESIGN acceptance and ROOT intake. Prior H82/H85/H86/H88/H90/H92 involvement is disclosed; author cannot selfaccept. Complete receiver/handled-producer/first-fixture-fault/raw-capture/cleanup design is now in the three original owner paths. Next substantive action: genuine whole nonauthor source/original-intent/actual-evidence review of the complete six owners, all original controls and all failed author evidence, then ROOT intake and separately granted full native/scientific/source campaigns. Required evidence: H94 complete before/after source images/inverses, exact producer/SAME/original assertions/signatures, actual bounded raw/XML/IDs/origins, full current known custody and all original/new causal recipes. Findings remain OPEN/BUILD. No supersession/closure/book/chart/Git writer; all scientific/main/human gates remain full.


### H94 historical author evidence; H96 corrective work after H95 review

H93 whole nonauthor review accepted the complete H92 design and ROOT intaken that bounded design. H94 authored the prior coupled source candidate. H95 identified incomplete known-witness enrollment and unregistered LIFO; H96 authored the complete corrective construction, preserving: cooperative versus undrained receiver premise, original handled-producer result2 versus escaping fixture latch, precleanup observed-fact freezing, guarded actual callbacks and original child/known-witness actions, explicit empty original ExitStack/outer exit before final receipt and exact first-exception propagation. The optional shared-writer diagnostic uses only the existing positive tick+300 remainder; inert helper adds none. All original assertions, producer, strict SAME, native budgets, scientific objectives and old source-control obligations remain.

The original54 author baseline is 53PASS1FAIL (socket negative DID NOT RAISE); no failure is erased. Source implementation and bounded author development are complete and not independently accepted. Canonical findings remain OPEN/BUILD; full Verify and actual source campaigns, full-native/scientific qualification, closure and protected delivery remain ROOT-owned and owed. H86 three correct UNKNOWN positive prerequisites and missing PTY witness remain unresolved.


H94 terminal author evidence recorded 2026-10-21T19:46:29.941746+00:00. The measured receipts are in `outputs/continuity/hook-H93-complete-fixture-source-author-20261021-r94/runtime.json` and full raw/XML, with whole-source controls and images in `evidence.json`/`source-images.json`.

| Actual bounded receipt | Passed | Failed | Errors / skipped | State |
|---|---:|---:|---|---|
| Original unchanged baseline | 53 | 1 | 0 / 0 | Socket negative DID NOT RAISE; retained |
| Initial authored development | 84 | 0 | 0 / 0 | Retained source/raw/XML |
| Expanded development before inert fixture correction | 89 | 5 | 0 / 0 | Missing inert index-read fixture; all five complete bodies retained |
| Complete current development | 94 | 0 | 0 / 0 | Same expanded IDs, author evidence only |

The source extends the existing owner scopes rather than adding an executor or acceptance reader. Registration tracks a callback that appended before raising, so a pair closes once; original actual owner failure finish is attempted once when its already acquired root capability exists, and never retried after entry. Communicate attempts are recorded before invocation, keeping UNOBSERVED, native `None`, actual empty/EOF, and TimeoutExpired partials distinct. Frozen bytes precede original cleanup; individually guarded original callbacks run LIFO, actual stack exits precede final receipt, and a new capture/cleanup/emitter fault cannot hide behind a handled producer problem. The complete real-caller source is covered by source-binding guards and bounded helper/caller controls; real Popen/kernel/witness execution was not performed here.

Every historical original source recipe remains whole and UNRUN; the real-caller receive-omission recipe has an indentation-only current-source derivative, with the historical object preserved. New actual-artifact recipes and exact inverses are DATA/UNRUN. No protected entry or hook is loaded by this work. Full native/scientific/once-only/kernel/byte assertions, UNKNOWN/one-retry, original deadlines, all scientific BUILDs, canonical closure, main delivery and human review remain owed.


H94 final observational-source evidence supplement (2026-10-21T19:53:46.267290+00:00): the current same-ID bounded cohort again passed with passing-output JUnit logging. Independent test-observer teardown exports ONLY already-held precleanup/native/fault/callback data. It does not reobserve endpoints, retry a failed fixture emitter or admit a new budget. An actual export/undo failure is retained separately and propagates the already-held first fixture object/native traceback when present, otherwise its own first error, after the original monkeypatch cleanup attempt. This is diagnostic source behavior, not merely logging configuration; its source binding is checked, while deliberate export-failure source campaigns remain UNRUN. All prior source/runtime attempts and lost-passing-output limitations are retained. Final XML contains the complete passing observations; no transient private journal is claimed durable beyond the actual retained caller data. Whole source/actual-evidence review and ROOT full qualification remain pending.


### H96 complete H95-M1/M2 source repair — author complete, independent review pending

H95 whole nonauthor review/ROOT intake is REQUEST_CHANGES, not H94 source acceptance. Its two MAJOR obligations are coupled with the entire accepted H92/H93/H94 construction. In `_observe_real_hook_child`, enroll every actually obtained witness immediately in original file order before any next fallible witness operation; no new read/census/poll/retry/identity is granted. In `_H94FixtureCapture.register`, unwind acquired/unregistered callbacks in reverse acquisition order while keeping already registered callbacks on the same original ExitStack and preserving postappend detection/once-only original function+args.

Direct original-helper controls must independently fail second exists/read/parse/identity after the first obtained identity, cross the known safe stop with a secondary cleanup fault, preserve exact first object/native traceback/original observation time, partial UNOBSERVED facts, original child then known cleanup and remaining independently safe actions. Missing-first invents no identity; healthy and delayed observation retain original file order. Pair controls must cross both registration positions/pre-postappend and both actual post-real-close faults, require exact [second,first] original function/args/ordinal order once, same registration-first object/TB/time, both native descriptors EBADF, at-most-once finish and actual empty original stack/outer exit before receipt and propagation. Count-only/EBADF-only controls are insufficient.

The original94 bounded baseline is measured green before source repair; no full source/native/scientific acceptance follows. All44 historical+9 H94 actual source campaigns remain UNRUN; new exact actual-artifact causal recipes remain DATA until separate ROOT grant. Canonical findings stay OPEN/BUILD; full module/native/real notebooks/H1–H6, three UNKNOWN positive prerequisites, unknown normal-PTY witness cause, all21/B1–B8/D12 scientific/formal/calibrated-band/G4/main/human and protected entry duties remain owed. No service/backend/registry/Git/lease/book/closure authority is added.


### 1.3 — H95-M1 actual known witness is not enrolled before another witness can fail

- **Severity:** major
- **Lane:** infra
- **Gate:** `notebook_exec`
- **Location:** `tests/test_pre_commit_notebooks.py::_observe_real_hook_child`
- **Status:** OPEN / BUILD; H96 author source complete, whole verification pending.
- **Observed:** original assignment to `known` occurred only after the entire witness loop, so second exists/read/parse/identity failure could omit an already obtained first identity from cleanup. Inherited provenance does not discharge the complete-owner contract.
- **Repair:** immediate original ordered enrollment, no extra native observation/identity, direct original-helper second-boundary/secondary-cleanup/missing-first/healthy-order controls with exact first object/TB/time and actual ordered safe cleanup receipt.
- **Owner / reviewer:** H96 original author hook_coherent_whole_review; fresh genuine whole nonauthor review and ROOT full qualification/canonical writer. No author acceptance.
- **Verify:** `python -B -m pytest -q -p no:cacheprovider tests/test_pre_commit_notebooks.py` — full scope OWED; bounded author controls are separate evidence.

### 1.4 — H95-M2 unregistered first-pair fallback reverses original cleanup order

- **Severity:** major
- **Lane:** infra
- **Gate:** `notebook_exec`
- **Location:** `tests/test_pre_commit_notebooks.py::_H94FixtureCapture.register`
- **Status:** OPEN / BUILD; H96 author source complete, whole verification pending.
- **Observed:** first preappend registration failure left both capabilities acquired, and forward fallback closed first then second despite original ExitStack LIFO second then first. Existing once/EBADF controls missed this semantic gap.
- **Repair:** reverse acquired/unregistered fallback, keep registered/postappended callbacks on original stack, actual original-helper four registration boundaries crossed with two actual close failures and direct ordinal/args/order/primary/empty-stack evidence.
- **Owner / reviewer:** H96 original author; fresh whole nonauthor review and ROOT full qualification/canonical writer. All original purposes stay.
- **Verify:** `python -B -m pytest -q -p no:cacheprovider tests/test_pre_commit_notebooks.py` — full scope OWED; no production-seed campaign is executed here.


H96 bounded author evidence recorded 2026-10-21T20:34:53.432355+00:00: unchanged original94 baseline PASS94; current original94 plus21 literal/direct-source controls PASS115/0FAIL/0ERROR/0SKIP with complete passing raw/XML receipts. Actual original witness helper controls preserve first-known enrollment through second exists/read/parse/identity faults (with and without a secondary safe-stop fault), no invented missing identity, healthy/delayed original order and remaining known cleanup. These use explicit inert index/launch/identity/reader boundaries, not genuine Popen/kernel/witness qualification. Actual original native-helper pair controls verify original function/args/ordinals [second,first] for both registration positions/pre-postappend, with and without both after-real-close faults, exact registration-first object/nativeTB/time, real EBADF, at-most-once finish and original empty-stack/outer-exit receipt. No budget, route, producer, SAME or original assertion was weakened. Whole source/evidence review remains pending; all53 old plus2 new actual source campaigns, full current module/native/real notebook/H1–H6/scientific/G4/main/human duties remain owed. Receipts and exact images/inverses are in `outputs/continuity/hook-H95-complete-cleanup-source-repair-author-20261021-r96/`.
