# Notebook commit-hook execution context — source-measured infrastructure finding

Review date: 2026-10-19. Status: OPEN/BUILD. Corrected r2 design remains UNSETTLED and requires whole independent rereview.
No kernel, hook pilot, model, source implementation, test or closure was run by this author.

### 1.1 — The common notebook hook does not establish committing-checkout byte/runtime binding

- **Severity:** major
- **Lane:** infra
- **Gate:** `notebook_exec`
- **Location:** `scripts/pre-commit-notebooks.sh:13-44`
- **Observed:** the installed common hook changes to its primary checkout and invokes that
  checkout's public notebook script. The public script SHA256
  `66398d9774b1682e3eb380a06acb649c341c7498188c4f72e821183ffd05c283`
  derives root from its own file, reads staged names, then opens relative working files there.
  It also word-splits names, silently skips missing working notebooks and suppresses Git
  enumeration failures. Its two notebook-execution branches use the same fixed output and
  execute a failed notebook again for its error message.
- **Dated r1 discriminating evidence:** at integration HEAD
  `4a79d75ade7c4b289cb6c2a163bdf1888fc88929`, the actual index selects both
  `notebooks/Phase5w_GrapheneDiracFluid_Stakeholder.ipynb` and
  `notebooks/Phase5w_GrapheneDiracFluid_Technical.ipynb`. Their candidate staged/working hashes
  are respectively `d2726c0479a2ec8b50152ee577006a7788415e463d104969d8a891860ac24e36`
  and `b70e6ad6a00c86815ec6992bcf2a8ba60810937114eec62caa06cc8be2bda8d7`.
  Primary's same-named working hashes are respectively
  `6df1efd4f1adf002293d9d8d9ab9819d57a9842ae877d3e829513ac0c87d50d0`
  and `76336cea20a2bfbb17cd6f53dd6e19b58585015188b5b74f8d66b0fcd662dc13`.
  That r1 equality within candidate and inequality across checkouts was measured. Later
  authorized notebook executions changed working images; this is not a current equality claim.
  No actual child argv/cwd was captured by either design task.
- **Runtime boundary:** installed nbconvert sets kernel resource path to a filename input's
  directory; installed nbclient uses that path as kernel cwd. Changing shell cwd alone does
  not demonstrate candidate kernel source imports. Current staged notebooks import `src`
  directly. This is a source-level runtime contract diagnosis, not a measured failed kernel.
- **Impact:** a generic hook OK cannot be credited as verification of these candidate notebook
  bytes or imports. This does not establish that all hooks are broken or invalidate independent
  author candidate-bound full nbclient runs, original cells, outputs or cleanup. Root has
  expressly qualified earlier hook-credit statements while retaining those separate receipts.
- **Existing coverage and history:** the public notebook script's inspected history begins
  at commit `ff6846356f12ed44f93c8c5d78d25be1ece9ba91` with the same inspected source body.
  `pre-commit-sync.sh` already distinguishes inherited Git-dir/common-dir and warns about cwd
  after the common hook changes directory. Workspace discovery owns shared resources;
  ADR-012 P10 target normalization owns caller-selected active targets. Neither is a missing
  notebook validator to duplicate. Existing agents review artifact/backing fidelity, while
  this route still needs a whole independent infrastructure specification/control review.
- **Required repair:** extend the existing public notebook hook's active Git-context root
  selection, reciprocal worktree validation, NUL/index population and exact staged/working
  notebook admission. Preserve each original candidate notebook-directory asset context AND
  actual candidate imports using existing nbconvert plus a root-prepared candidate project
  runtime. Use transparent child-scoped import/kernel settings and actual origin witnesses;
  no project-root cwd substitution. Enforce full nonempty-code-cell and strict-error behavior
  against skip tags, raises-exception, ambient allowance/skip/removal configuration, stale
  outputs and omitted-cell success. Preserve single execution and unique output cleanup.
  Root rolls the reviewed public-script repair into its actual invoked primary entry point;
  changing only a linked candidate's script does not change an old common-hook call target.
  No private hook text/edit, new selector, resolver module, registry, gate or validator.
- **Conservation:** existing installed guard order and sync skip, original candidate notebook
  cells/outputs, numerical/source repairs, all other index entries and scientific BUILDs remain.
  Missing inputs, unsafe paths, partial notebook staging, wrong imports, skipped cells and
  tolerated errors must not become SKIP/PASS. Missing original MC data remains an explicit
  unmeasured scientific input; no invented result or empty optional-data branch is acceptance. No floor/cap/CI_SKIP/claim-strength waiver is part of this repair.
- **Verify:** `python -B -m pytest -q -p no:cacheprovider tests/test_pre_commit_notebooks.py`
- **Verify status:** PROSPECTIVE AND OWED — that new test file does not exist in the measured
  candidate; no successful result is claimed. Actual ordinary common-hook production
  RED/exact-restore/GREEN, real candidate kernel witnesses and independent whole review are
  additional acceptance evidence, not replaced by this command.

## Assignment, review and disposition

Original objective: publication checkpoint evidence must validate the committing candidate's
notebooks and project runtime under ordinary Git discipline. Exact missing construction:
existing-hook context and byte/runtime binding, with production refusal and restoration proof.
The publication lead accepted this design assignment and owns the overall repair, Git/index,
primary public entry rollout, required gates, canonical writer and protected main delivery.
The assigned author `publication_notebook_hook_design` accepted the design-only task after
both literal first continuity checks returned fresh with exit 0. No future implementer or
independent reviewer is represented as having accepted an undispatched task.

Prior genuinely nonauthor WHOLE design review bb118d82 requested mandatory changes M1/M2,
and root accepted both in disposition9976eed6. Original r1 design incorrectly changed all
kernel asset directories to project root and omitted enforcement of installed skip/error/config
semantics. The complete r2 specification/plan and new ignored owner proposal replace those
prospective contracts in place. All r1 preimages/reports/failures stay frozen. No implemented
fix, runtime success or accepted corrected design is asserted.

Next action: genuinely nonauthor whole rereview of the complete corrected unsettled
[specification](../../../docs/superpowers/specs/2026-10-19-precommit-notebook-worktree-routing-design.md),
[plan](../../../docs/superpowers/plans/2026-10-19-precommit-notebook-worktree-routing.md) and
ignored owner proposal against actual owners/sources/history. After accepted owner amendments,
root deliberately assigns the coherent implementation and real production pilot. Required
acceptance evidence includes original notebook-directory asset reads and candidate imports,
real normal prepared runtime, full-cell strict-error tag/config production discriminators,
all original notebook cells, actual kernel paths/hashes, old-route
and corrected-route controls, exact input/index restoration and a whole independent reviewer.

This is global infrastructure debt; no unrelated bundle attribution is invented. It enters the
existing finding/assignment/review system with supported heading/fields. Root must reconcile
any genuine open-major ratchet effect without raising ceilings. The existing closure writer
is the only supported closure channel. Filing, source correction, draft Git checkpoint,
whole-tree gates, main delivery and human publication are separate states. BUILD remains open.
