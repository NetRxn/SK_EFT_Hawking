"""Real public notebook-hook fixtures.

The cheap admission tests never prepare/install a runtime. The execution fixtures
are root-run: normal locked uv environments and prefix kernels in their own public
source copies. They invoke the actual script/nbconvert, never a fake executor.
Temporary fixture Git administration is distinct from the repository's live index.
The real installed-common-hook/production journal matrix remains separate.
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import time

import pytest

REPO = Path(__file__).resolve().parents[1]
HOOK = REPO / "scripts/pre-commit-notebooks.sh"


def _env():
    # Fixture isolation only. The production script preserves inherited context.
    env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")
           and k not in {"UV_PROJECT_ENVIRONMENT", "UV_PROJECT", "UV_WORKING_DIRECTORY",
                        "UV_CONFIG_FILE", "VIRTUAL_ENV", "CONDA_PREFIX"}}
    env.update(GIT_OPTIONAL_LOCKS="0", GIT_NO_LAZY_FETCH="1", GIT_CONFIG_NOSYSTEM="1",
               GIT_CONFIG_GLOBAL=os.devnull, PYTHONDONTWRITEBYTECODE="1")
    return env


def _call(argv, cwd, *, env=None, data=None, timeout=300, hook=None):
    context = None if hook is None else _hook_context(hook, argv, cwd, env or _env())
    start = dt.datetime.now(dt.timezone.utc).isoformat()
    try:
        r = subprocess.run([str(x) for x in argv], cwd=cwd, env=env or _env(),
                           input=data, capture_output=True, timeout=timeout)
    except BaseException as error:
        if context is not None:
            context.update(disposition="no-result", end_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                           actual_exception=error)
            error.hook_context = context
        raise
    row = dict(argv=[str(x) for x in argv], cwd=str(cwd), start_utc=start,
               end_utc=dt.datetime.now(dt.timezone.utc).isoformat(), rc=r.returncode,
               stdout_base64=base64.b64encode(r.stdout).decode(),
               stderr_base64=base64.b64encode(r.stderr).decode())
    print("NOTEBOOK_FIXTURE_PROCESS " + json.dumps(row), flush=True)
    if context is not None:
        context["end_utc"] = row["end_utc"]
        r.hook_context = context
        _events(r)
    return r


def _git(repo, *args, data=None):
    r = _call(["git", "--no-pager", "-c", "core.fsmonitor=false", *args], repo, data=data)
    assert r.returncode == 0, r.stderr.decode(errors="replace")
    return r.stdout


def _init(repo):
    repo.mkdir()
    empty = repo.parent / (repo.name + "-empty-hooks-template")
    empty.mkdir(exist_ok=True)
    _git(repo, "init", "--template=" + str(empty))
    _git(repo, "config", "user.name", "Notebook fixture")
    _git(repo, "config", "user.email", "notebook-fixture@example.invalid")
    _git(repo, "config", "core.hooksPath", str(empty))
    return repo


def _nb(code="assert True", *, tags=(), kernel="python3"):
    return dict(nbformat=4, nbformat_minor=5,
                metadata={"kernelspec": {"name": kernel, "language": "python", "display_name": kernel}},
                cells=[dict(id="fixture-cell", cell_type="code", metadata={"tags": list(tags)},
                            source=code, execution_count=None, outputs=[])])


def _write(repo, name, notebook):
    p = repo / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(notebook, indent=1) + "\n")
    return p


def _stage(repo):
    _git(repo, "add", "-A", "--", ".")


def _commit(repo):
    _stage(repo)
    _git(repo, "commit", "-m", "fixture baseline")


def _index(repo):
    p = repo / ".git"
    admin = p if p.is_dir() else Path(p.read_text().strip()[8:])
    if not admin.is_absolute():
        admin = repo / admin
    q = admin / "index"
    return q.read_bytes() if q.exists() else None


def _hook_context(script, argv, cwd, env):
    import tempfile
    path = Path(script).absolute().resolve()
    raw, mode = path.read_bytes(), stat.S_IMODE(path.stat().st_mode)
    return dict(entry=str(path), entry_bytes=raw, entry_pin=dict(sha256=hashlib.sha256(raw).hexdigest(), mode=mode),
                argv=[str(x) for x in argv], cwd=str(Path(cwd).resolve()), environment=dict(env),
                temp_base=str(Path(env.get("TMPDIR") or env.get("TEMP") or env.get("TMP") or tempfile.gettempdir()).resolve()),
                start_utc=dt.datetime.now(dt.timezone.utc).isoformat(), uid=os.getuid(), pid=None, disposition="no-result",
                control_framing="ascii-json-object-v2")


def _control_object(raw, at=0):
    """Take one bounded actual control slice at a supplied, established boundary."""
    assert type(raw) is bytes and type(at) is int and 0 <= at <= len(raw)
    assert raw[at:at + 14] == b"NOTEBOOK_HOOK ", "no complete current reference"
    beginning = at + 14
    assert raw[beginning:beginning + 1] == b"{", "control object missing"
    stack, quoted, escaped = [], False, False
    for last in range(beginning, min(len(raw), at + 4096)):
        c = raw[last]
        assert 32 <= c <= 126, "nonprintable public control"
        if quoted:
            if escaped:
                escaped = False
            elif c == 92:
                escaped = True
            elif c == 34:
                quoted = False
        elif c == 34:
            quoted = True
        elif c in (123, 91):
            stack.append(c)
        elif c in (125, 93):
            assert stack and stack.pop() == (123 if c == 125 else 91), "mismatched public control object"
            if not stack:
                return raw[at:last + 1], last + 1
        else:
            assert c != 32, "noncompact public control"
    raise AssertionError("incomplete or oversized public control")


def _events(r=None, *, child=None, streams=None, context=None, allow_incomplete=False):
    """Validate this actual call and return ALL retained records in their original order."""
    context = context if context is not None else getattr(r, "hook_context", None)
    assert context is not None, "missing explicit pre-call hook context"
    if child is None:
        assert r is not None
        stdout, stderr, rc = r.stdout, r.stderr, r.returncode
    else:
        assert streams is not None and child.pid == context["pid"]
        stdout, stderr, rc = streams[0], streams[1], child.returncode
    def incomplete(reason, state="protocol-incomplete"):
        context.pop("verification", None)
        context.pop("transport_verification", None)
        context.update(disposition=state, protocol_error=reason)
        if allow_incomplete: return []
        raise AssertionError(reason)
    try:
        def decode(raw):
            def unique(pairs):
                result = {}
                for key, value in pairs:
                    assert key not in result, "duplicate JSON key"
                    result[key] = value
                return result
            return json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=unique)
        assert sys.platform == "darwin", "unreviewed Darwin identity profile"
        assert context.get("control_framing") == "ascii-json-object-v2", "unbound current control framing"
        actual_transport = context.get("transport")
        control_wire = stdout if actual_transport is None else actual_transport["groups"][actual_transport["control_group"]]["wire"]
        at = 0 if actual_transport is None else actual_transport.get("control_offset", 0)
        if not control_wire[at:at + 14] == b"NOTEBOOK_HOOK ":
            return incomplete("no complete current reference", "startup-unavailable" if rc != 0 and
                              stderr == b"NOTEBOOK_HOOK_STARTUP_UNAVAILABLE\n" else "protocol-incomplete")
        start_bytes, start_end = _control_object(control_wire, at)
        last = start_end - 1
        assert last >= 0 and last + 1 - at <= 4096
        start = decode(start_bytes[14:])
        markers, marker_bytes = [start], [start_bytes]
        assert set(start) == {"event", "evidence_root", "root_identity", "observer_pid", "started_utc", "entry_sha256"}
        assert all(type(start[key]) is str for key in ("evidence_root", "started_utc", "entry_sha256"))
        assert type(start["observer_pid"]) is int and start["observer_pid"] > 0
        if context["pid"] is not None: assert start["observer_pid"] == context["pid"]
        assert start["entry_sha256"] == context["entry_pin"]["sha256"]
        assert dt.datetime.fromisoformat(context["start_utc"]) <= dt.datetime.fromisoformat(start["started_utc"]) <= dt.datetime.fromisoformat(context["end_utc"])
        root = Path(start["evidence_root"])
        assert root.is_absolute() and root.resolve() == root and root.parent == Path(context["temp_base"])
        assert root.name.startswith("pre-commit-notebooks-")
        def identity(st, mode, kind):
            assert kind(st.st_mode) and stat.S_IMODE(st.st_mode) == mode and st.st_uid == context["uid"] == os.getuid()
            return st.st_dev, st.st_ino
        expected = identity(root.lstat(), 0o700, stat.S_ISDIR)
        assert list(expected) == start["root_identity"]
        fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            assert identity(os.fstat(fd), 0o700, stat.S_ISDIR) == expected
            def leaf(name):
                assert type(name) is str and name not in ("", ".", "..") and "/" not in name
                before = os.stat(name, dir_fd=fd, follow_symlinks=False)
                pin = identity(before, 0o600, stat.S_ISREG)
                handle = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=fd)
                try:
                    assert identity(os.fstat(handle), 0o600, stat.S_ISREG) == pin
                    pieces = []
                    while True:
                        raw = os.read(handle, 4096)
                        if not raw: break
                        pieces.append(raw)
                    assert os.fstat(handle).st_size == sum(map(len, pieces)) == before.st_size
                finally:
                    os.close(handle)
                assert identity(os.stat(name, dir_fd=fd, follow_symlinks=False), 0o600, stat.S_ISREG) == pin
                return b"".join(pieces)
            journal = leaf("events.jsonl")
            assert journal and journal.endswith(b"\n")
            records = [decode(line) for line in journal.splitlines()]
            assert all(type(x) is dict and type(x.get("event")) is str for x in records)
            assert records[0]["event"] == "invocation" and records[0]["entry_pin"] == context["entry_pin"]
            assert records[0]["argv"] == ["-", context["argv"][1]] and records[0]["cwd"] == context["cwd"]
            assert records[0]["observer_pid"] == start["observer_pid"]
            provisional = [x for x in records if x["event"] == "terminal_provisional"]
            assert len(provisional) == 1 and records[-1] is provisional[0]
            # Custody completions are separate immutable facts in the closed
            # journal. Validate both initial failure and actual later completion
            # before exposing an effective envelope to the original predicates.
            import math
            initial_faults = {row["fault_id"]: row for row in records if row["event"] == "fault"}
            fault_completions, raw_completions = {}, {}
            allowed_custody = {"descendant-"+str(int(signal.SIGTERM)), "descendant-"+str(int(signal.SIGKILL)), "final-drain", "final-wait", "final-observation"}
            # Bind completions to frozen actual run scheduling and post-IO admission.
            window_budgets={"descendant-"+str(int(signal.SIGTERM)):5,"descendant-"+str(int(signal.SIGKILL)):2,
                            "final-drain":2,"final-wait":2,"final-observation":2}
            window_keys={"command_id","window_id","phase","scheduled_monotonic","opened_monotonic","budget","deadline"}
            starts={v["command_id"]:v for v in records if v["event"]=="command_begin"}
            ends={v["command_id"]:v for v in records if v["event"]=="command_end"}
            window_begins,windows,completion_admissions={},{},{}
            journal_position={id(value):position for position,value in enumerate(records)}
            window_positions={}
            for value in records:
                if value["event"]=="custody_window":
                    assert set(value)==window_keys|{"event"}
                    number=value["window_id"]
                    assert type(number)is int and number==len(window_begins)+1
                    window_begins[number]={key:value[key]for key in window_keys}
                    window_positions[number]=journal_position[id(value)]
            for cid,end in ends.items():
                assert type(end["custody_windows"])is list and type(end["custody_completions"])is list
                previous=starts[cid]["started_monotonic"];phases=[]
                for window in end["custody_windows"]:
                    assert set(window)==window_keys|{"closed_monotonic"}
                    number=window["window_id"]
                    assert type(number)is int and number>0 and type(window["command_id"])is int
                    assert number not in windows and {key:window[key]for key in window_keys}==window_begins[number]
                    assert journal_position[id(starts[cid])]<window_positions[number]<journal_position[id(end)]
                    assert window["command_id"]==cid and window["phase"]in window_budgets
                    phases.append(window["phase"])
                    assert window["budget"]==window_budgets[window["phase"]]
                    assert all(type(window[key])in(int,float)and math.isfinite(window[key])and window[key]>=0
                               for key in ("scheduled_monotonic","opened_monotonic","closed_monotonic","deadline","budget"))
                    assert starts[cid]["started_monotonic"]<=window["scheduled_monotonic"]<=window["opened_monotonic"]<window["deadline"]
                    assert previous<=window["opened_monotonic"]
                    assert window["deadline"]==window["scheduled_monotonic"]+window["budget"]
                    assert window["opened_monotonic"]<=window["closed_monotonic"]<=end["ended_monotonic"]
                    previous=window["closed_monotonic"];windows[number]=window
                expected_phases=list(window_budgets)
                assert len(phases)==len(set(phases))and phases==[phase for phase in expected_phases if phase in phases]
                if end["launch_state"]=="created":assert phases[-3:]==["final-drain","final-wait","final-observation"]
                else:assert not phases
                for admission in end["custody_completions"]:
                    assert set(admission)=={"command_id","completion_id","window_id","phase","started_monotonic","committed_monotonic","deadline"}
                    number=admission["completion_id"]
                    assert type(number)is int and number>0 and number not in completion_admissions
                    assert number==len(completion_admissions)+1
                    assert type(admission["window_id"])is int and type(admission["command_id"])is int
                    window=windows[admission["window_id"]]
                    assert admission["command_id"]==cid==window["command_id"]and admission["phase"]==window["phase"]
                    assert admission["deadline"]==window["deadline"]
                    assert all(type(admission[key])in(int,float)and math.isfinite(admission[key])for key in ("started_monotonic","committed_monotonic","deadline"))
                    assert window["opened_monotonic"]<=admission["started_monotonic"]<=admission["committed_monotonic"]<=window["closed_monotonic"]
                    assert admission["committed_monotonic"]<window["deadline"]
                    completion_admissions[number]=admission
            assert set(windows)==set(window_begins)
            seen_completions=set()
            def complete_native(value):
                assert type(value)is dict and value.get("complete")is True
                kind=value["type"]
                if kind=="none":assert set(value)=={"type","complete"}
                elif kind in {"bool","int","str"}:
                    assert set(value)=={"type","value","complete"}
                    assert type(value["value"])is {"bool":bool,"int":int,"str":str}[kind]
                elif kind=="float":
                    assert set(value)=={"type","bits","complete"}and re.fullmatch(r"[0-9a-f]{16}",value["bits"])
                elif kind=="bytes":
                    assert set(value)=={"type","bytes","hex_chunks","complete"}and type(value["bytes"])is int and value["bytes"]>=0
                    assert type(value["hex_chunks"])is list and all(type(chunk)is str and re.fullmatch(r"(?:[0-9a-f]{2})*",chunk)for chunk in value["hex_chunks"])
                    assert sum(len(chunk)//2 for chunk in value["hex_chunks"])==value["bytes"]
                else:
                    assert kind in {"tuple","list","dict"}and set(value)=={"type","items","complete"}and type(value["items"])is list
                    for item in value["items"]:
                        if kind=="dict":
                            assert type(item)is list and len(item)==2
                            complete_native(item[0]);complete_native(item[1])
                        else:complete_native(item)
            def native_fault_shape(value):
                obligations=value["capture_obligations"]
                assert type(obligations)is dict and set(obligations)=={"arguments_type","os_fields_requested"}
                assert obligations["arguments_type"]=="tuple"and type(obligations["os_fields_requested"])is bool
                assert type(value["native_details_requested"])is bool
                if value["complete"]:
                    if value["native_details_requested"]:complete_native(value["details"])
                    complete_native(value["arguments"])
                    assert value["arguments"]["type"]==obligations["arguments_type"]
                    complete_native(value["errno"])
                    expected={"filename","filename2","strerror"}if obligations["os_fields_requested"]else set()
                    assert type(value["os_fields"])is dict and set(value["os_fields"])==expected
                    for captured in value["os_fields"].values():complete_native(captured)
            for original in initial_faults.values():native_fault_shape(original)
            for position, row in enumerate(records):
                if row["event"] not in {"fault_completion", "raw_completion"}:
                    continue
                assert row["phase"] in allowed_custody
                assert type(row["completed_monotonic"]) in (int,float) and math.isfinite(row["completed_monotonic"]) and row["completed_monotonic"]>=0
                assert type(row["completion_deadline"]) in (int,float) and math.isfinite(row["completion_deadline"])
                assert row["completed_monotonic"] < row["completion_deadline"]
                completion_id=row["completion_id"]
                assert type(completion_id)is int and completion_id>0 and completion_id not in seen_completions
                assert completion_id==len(seen_completions)+1
                seen_completions.add(completion_id)
                assert type(row["window_id"])is int and type(row["command_id"])is int
                window=windows[row["window_id"]]
                assert row["command_id"]==window["command_id"]and row["phase"]==window["phase"]
                assert journal_position[id(starts[row["command_id"]])]<window_positions[row["window_id"]]<position<journal_position[id(ends[row["command_id"]])]
                assert row["completion_deadline"]==window["deadline"]
                assert type(row["capture_started_monotonic"])in(int,float)and math.isfinite(row["capture_started_monotonic"])
                assert window["opened_monotonic"]<=row["capture_started_monotonic"]<=row["completed_monotonic"]<=window["closed_monotonic"]
                committed=completion_admissions[completion_id]
                assert committed["command_id"]==row["command_id"]and row["completed_monotonic"]<=committed["committed_monotonic"]
                assert row["completed_monotonic"]<=committed["started_monotonic"]
                if row["event"] == "fault_completion":
                    assert set(row)=={"event","fault_id","original_observed_monotonic","completed_monotonic","completion_deadline","phase","arguments","errno","os_fields","details","native_details_requested","command_id","completion_id","window_id","capture_started_monotonic","capture_obligations"}
                    assert type(row["fault_id"])is int and type(row["native_details_requested"])is bool
                    number = row["fault_id"]
                    assert number in initial_faults and number not in fault_completions
                    original = initial_faults[number]
                    assert original["complete"] is False
                    assert row["command_id"]==original["command_id"]
                    assert row["native_details_requested"]==original["native_details_requested"]
                    assert row["capture_obligations"]==original["capture_obligations"]
                    native_fault_shape(dict(row, complete=True))
                    if row["native_details_requested"]and type(original["details"])is dict and original["details"].get("complete")is True:
                        assert row["details"]==original["details"]
                    assert records.index(original) < position
                    assert row["original_observed_monotonic"] == original["observed_monotonic"] <= row["completed_monotonic"]
                    complete_native(row["arguments"]);complete_native(row["errno"])
                    assert type(row["os_fields"])is dict and set(row["os_fields"])in (set(),{"filename","filename2","strerror"})
                    for value in row["os_fields"].values():complete_native(value)
                    if row["native_details_requested"]:complete_native(row["details"])
                    else:assert row["details"]==original["details"]
                    for key in ("arguments","errno"):
                        captured=original.get(key)
                        if type(captured)is dict and captured.get("complete")is True:assert captured==row[key]
                    for key,captured in original.get("os_fields",{}).items():
                        if captured.get("complete")is True:assert captured==row["os_fields"][key]
                    fault_completions[number] = row
                else:
                    assert set(row)=={"event","original","available","command_id","phase","completed_monotonic","completion_deadline","completion_id","window_id","capture_started_monotonic"}
                    original, completed = row["original"], row["available"]
                    assert original["complete"] is False and completed["complete"] is True
                    assert original["file"] not in raw_completions
                    assert completed["available_bytes"] == completed["bytes"] == original["available_bytes"]
                    full = leaf(completed["file"])
                    assert len(full) == completed["bytes"] and hashlib.sha256(full).hexdigest() == completed["sha256"]
                    assert list(identity(os.stat(completed["file"],dir_fd=fd,follow_symlinks=False),0o600,stat.S_ISREG)) == completed["identity"]
                    assert completed["closed"] and not completed["missing_ranges"]
                    if original["identity"] is not None:
                        assert original["closed"] is True, "original raw close remains UNKNOWN"
                        prefix = leaf(original["file"])
                        assert list(identity(os.stat(original["file"],dir_fd=fd,follow_symlinks=False),0o600,stat.S_ISREG)) == original["identity"]
                        assert len(prefix) == original["bytes"] and full.startswith(prefix)
                    else:
                        assert original["bytes"] == 0
                        with pytest.raises(FileNotFoundError):os.stat(original["file"],dir_fd=fd,follow_symlinks=False)
                    assert original["missing_ranges"] == ([[original["bytes"],original["available_bytes"]]] if original["bytes"] < original["available_bytes"] else [])
                    raw_completions[original["file"]] = row
            assert seen_completions==set(completion_admissions)
            files, commands, faults, samples = {}, {}, {}, []
            process_owned, process_pending, native_attempt_ids = {}, {}, []
            effect_authorities = {}
            admitted_samples, refused_samples = {}, {}
            for end in (value for value in records if value["event"] == "command_end"):
                for item in end["observations_admitted"]:
                    assert set(item) == {"command_id","sequence","attempt_id","committed_monotonic","deadline"}
                    assert item["command_id"] == end["command_id"] and type(item["sequence"]) is int
                    assert type(item["attempt_id"])is int and item["attempt_id"]>0
                    assert all(type(item[key])in(int,float)and math.isfinite(item[key])and item[key]>=0 for key in ("committed_monotonic","deadline"))
                    assert item["committed_monotonic"]<item["deadline"]
                    assert starts[end["command_id"]]["started_monotonic"]<=item["committed_monotonic"]<=end["ended_monotonic"]
                    assert item["sequence"] not in admitted_samples
                    admitted_samples[item["sequence"]] = item
                for item in end["observations_refused"]:
                    assert set(item) == {"command_id","sequence","fault_id"}
                    assert item["command_id"] == end["command_id"] and type(item["sequence"]) is int
                    assert type(item["fault_id"])is int and item["fault_id"]>0
                    assert item["sequence"] not in refused_samples and item["sequence"] not in admitted_samples
                    assert item["fault_id"] in initial_faults and initial_faults[item["fault_id"]]["command_id"] == end["command_id"]
                    refused_samples[item["sequence"]] = item
            def raw_ref(ref):
                if not ref["complete"]:
                    completion = raw_completions[ref["file"]]
                    assert completion["original"] == ref and completion["command_id"] == row["command_id"]
                    ref = completion["available"]

                name = ref["file"]; assert name not in files
                raw = leaf(name); files[name] = raw
                assert list(identity(os.stat(name,dir_fd=fd,follow_symlinks=False),0o600,stat.S_ISREG)) == ref["identity"]
                assert ref["bytes"] == len(raw) <= ref["available_bytes"]
                assert ref["complete"], "incomplete exact raw channel"
                assert ref["closed"] and not ref["missing_ranges"] and len(raw) == ref["available_bytes"]
                assert ref["sha256"] == hashlib.sha256(raw).hexdigest()
                return raw
            for row in records:
                event = row["event"]
                assert event in {"invocation", "admission", "deleted", "execution_context", "executed", "empty", "success",
                                 "refused", "fault", "terminal_provisional", "command_begin", "command_launch",
                                 "command_start_failed", "command_channel", "command_end", "contradictory_command_buffer",
                                 "children", "command_failure", "process_observation", "fault_completion", "raw_completion", "command_channel_pending", "custody_window"}
                if event == "fault":
                    if not row["complete"]:
                        initial = row
                        completed = fault_completions[row["fault_id"]]
                        row = dict(initial, complete=True, arguments=completed["arguments"], errno=completed["errno"],
                                   os_fields=completed["os_fields"], details=completed["details"], initial_fault=initial,
                                   custody_completed_monotonic=completed["completed_monotonic"])
                    assert row["fault_id"] == len(faults) + 1 and row["first_fault_id"] == 1
                    assert row["complete"], "typed failure envelope incomplete"
                    native_fault_shape(row)
                    assert row["command_id"] is None or row["command_id"] in commands
                    faults[row["fault_id"]] = row
                elif event == "command_channel_pending":
                    assert set(row)=={"event","command_id","phase","channel","capture","offset","end","available"}
                    assert type(row["channel"])is int and row["channel"]in(0,1)
                    assert all(type(row[key])is int and row[key]>=0 for key in ("capture","offset","end"))
                    assert rc != 0 and row["command_id"] in commands
                    assert row["available"]["complete"] is False
                    assert row["end"] == row["offset"] + row["available"]["bytes"]
                    raw_ref(row["available"])  # diagnostic custody, never a committed prefix
                elif event == "command_begin":
                    cid = row["command_id"]; assert cid == len(commands) + 1
                    commands[cid] = dict(begin=row, launch=None, end=None, channels=[b"", b""], captured=[False,False], children=[])
                elif event in ("command_launch", "command_start_failed", "command_channel", "command_end", "contradictory_command_buffer", "children", "command_failure"):
                    command = commands[row["command_id"]]; assert command["end"] is None
                    if event == "command_launch":
                        assert command["launch"] is None and row["state"] == "created" and row["pid"] > 0
                        command["launch"] = row
                    elif event == "command_channel":
                        i = row["channel"]; assert type(i) is int and i in (0,1)
                        raw = raw_ref(row["available"])
                        assert row["offset"] == len(command["channels"][i]) and row["end"] == row["offset"] + len(raw)
                        command["channels"][i] += raw; command["captured"][i] = True
                    elif event == "contradictory_command_buffer":
                        raw_ref(row["available"]); assert rc != 0
                    elif event == "children":
                        assert command["begin"]["watch"] and command["launch"] is not None
                        assert row["command_pid"] == command["launch"]["pid"] and not command["children"]
                        for effect in row["signals"]:
                            if effect["kind"] == "observed_descendant":
                                authority = effect["observation_authority"]
                                assert type(authority) is dict and admitted_samples[authority["sequence"]] == authority
                                assert authority["command_id"] == row["command_id"]
                                assert authority["committed_monotonic"] <= effect["observed_monotonic"]
                                assert effect["observed_monotonic"]<authority["deadline"]
                                assert effect["pid"] > 0 and effect["sample_scope"] == "successful_run_observation"
                                assert effect_authorities[authority["sequence"]][effect["pid"]] == effect["identity"]
                        command["children"].append(row)
                    elif event == "command_end":
                        command["end"] = row
                        assert row["fault_ids"] == [k for k,v in faults.items() if v["command_id"] == row["command_id"]]
                        if row["launch_state"] == "created" and command["begin"]["watch"]:
                            assert len(command["children"]) == 1
                        assert row["started_monotonic"] == command["begin"]["started_monotonic"] <= row["ended_monotonic"]
                        assert len(row["channels"]) == 2
                        for i, channel in enumerate(row["channels"]):
                            raw = command["channels"][i]
                            assert channel["channel"] == i and channel["bytes"] == len(raw)
                            assert channel["sha256"] == hashlib.sha256(raw).hexdigest()
                            n = channel["delivered_bytes"]; assert 0 <= n <= len(raw)
                            assert channel["missing_delivery_ranges"] == ([[n,len(raw)]] if channel["delivery_required"] and n < len(raw) else [])
                            if row["drain_complete"]: assert channel["state"] == "eof" and command["captured"][i]
                        if row["launch_state"] == "created":
                            assert command["launch"] is not None and row["pid"] == command["launch"]["pid"]
                        else: assert rc != 0 and row["pid"] is None
                elif event == "process_observation":
                    samples.append(row["sequence"]); assert samples[-1] == len(samples) and row["command_id"] in commands
                    for key in ("stdout_ref", "stderr_ref"):
                        if row[key] is not None: raw_ref(row[key])
                    if not row["complete"]: assert rc != 0
                    required={"event","sequence","command_id","phase","argv","locale","started_utc","returncode","stdout_ref","stderr_ref","complete","error","started_monotonic","deadline","scope","attempts","ended_utc","ended_monotonic"}
                    assert required<=set(row)<=required|{"parsed_rows","admitted_attempt","error_type","error_errno","row"}
                    assert type(row["complete"])is bool and type(row["attempts"])is list
                    assert type(row["sequence"])is int and row["sequence"]>0 and type(row["command_id"])is int and row["command_id"]>0
                    assert row["returncode"]is None or type(row["returncode"])is int
                    assert row["error"]is None or type(row["error"])is str
                    if "row"in row:assert type(row["row"])is int and row["row"]>=1
                    assert type(row["scope"])is dict and set(row["scope"])=={"command_id","cli_pid","cli_unreaped","owned","pending"}
                    assert row["scope"]["command_id"]==row["command_id"]
                    assert row["argv"]==["/bin/ps","-ww","-axo","pid=,ppid=,pgid=,lstart=,stat=,command="]
                    assert row["locale"]=={"LC_ALL":"C","LANG":"C"}
                    if not row["complete"]:
                        assert row["sequence"] in refused_samples
                    def observation_utc(value):
                        assert type(value)is str and re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?\+00:00",value)
                        parsed=dt.datetime.fromisoformat(value)
                        assert parsed.utcoffset()==dt.timedelta(0)
                        return parsed
                    cid=row["command_id"];begin=starts[cid];end=ends[cid]
                    first_utc,last_utc=observation_utc(row["started_utc"]),observation_utc(row["ended_utc"])
                    assert observation_utc(begin["started_utc"])<=first_utc<=last_utc<=observation_utc(end["ended_utc"])
                    assert dt.datetime.fromisoformat(context["start_utc"])<=first_utc<=last_utc<=dt.datetime.fromisoformat(context["end_utc"])
                    assert begin["watch"]is True
                    assert type(row["phase"])is str and row["phase"]in {"preflight","running","cli-grace","descendant-"+str(int(signal.SIGTERM)),"descendant-"+str(int(signal.SIGKILL)),"final-observation"}
                    assert journal_position[id(begin)]<journal_position[id(row)]<journal_position[id(end)]
                    assert begin["started_monotonic"]<=row["started_monotonic"]<=row["ended_monotonic"]<=end["ended_monotonic"]
                    if commands[cid]["launch"]is None:
                        expected_phase="preflight"
                        assert row["scope"]["cli_pid"]is None and row["scope"]["cli_unreaped"]is False
                    else:
                        active=[window for number,window in windows.items()if window["command_id"]==cid and window_positions[number]<journal_position[id(row)]]
                        if active:
                            current_window=max(active,key=lambda window:window_positions[window["window_id"]])
                            expected_phase=current_window["phase"]
                            assert current_window["opened_monotonic"]<=row["started_monotonic"]<=row["ended_monotonic"]<=current_window["closed_monotonic"]
                        else:
                            prior_failure=any(value["event"]=="command_failure"and value["command_id"]==cid and journal_position[id(value)]<journal_position[id(row)]for value in records)
                            expected_phase="cli-grace"if prior_failure else"running"
                    assert row["phase"]==expected_phase
                    # Independent complete raw parser; never use a producer
                    # hash, pre-labelled proof or returned row as authority.
                    def census(ref):
                        resolved = raw_completions.get(ref["file"], {}).get("available", ref)
                        data = files[resolved["file"]] if resolved["file"] in files else raw_ref(ref)
                        assert data and data.endswith(b"\n")
                        parsed, unknown = {}, []
                        months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
                        weekdays = ("Mon","Tue","Wed","Thu","Fri","Sat","Sun")
                        for line in data.decode("utf-8", "strict").split("\n")[:-1]:
                            values = line.split(None,9)
                            assert len(values) == 10 and all(re.fullmatch(r"[0-9]{1,10}", v) for v in values[:3])
                            pid, parent, group = map(int,values[:3])
                            assert all(0 <= n <= 2147483647 for n in (pid,parent,group)) and pid not in parsed
                            assert all(len(token) <= 32 for token in values[:9])
                            assert values[3] in weekdays and values[4] in months
                            assert re.fullmatch(r"[0-9]{1,2}",values[5]) and re.fullmatch(r"[0-9]{2}:[0-9]{2}:[0-9]{2}",values[6]) and re.fullmatch(r"[0-9]{4}",values[7])
                            hour,minute,second=map(int,values[6].split(":"))
                            born=dt.datetime(int(values[7]),months.index(values[4])+1,int(values[5]),hour,minute,second)
                            assert weekdays[born.weekday()]==values[3]
                            state,command=values[8:]
                            assert command and all(not(ord(c)<32 and c!="\t")and ord(c)!=127 for c in command)
                            if re.fullmatch(r"[IRSTUZ][+<>AELNSsVWX]*",state)is None:
                                assert re.fullmatch(r"\?[+<>AELNSsVWX]*",state)
                                unknown.append(pid)
                            parsed[pid]=dict(ppid=parent,pgid=group,birth=values[3:8],state=state,
                                            command=[command[k:k+512] for k in range(0,len(command),512)])
                        assert start["observer_pid"] in parsed and not parsed[start["observer_pid"]]["state"].startswith("Z")
                        return parsed,unknown
                    attempts=row["attempts"]
                    assert type(attempts)is list and 1<=len(attempts)<=2
                    final_attempt=attempts[-1]
                    assert row["returncode"]==final_attempt["returncode"]
                    assert row["stdout_ref"]==final_attempt["stdout_ref"]and row["stderr_ref"]==final_attempt["stderr_ref"]
                    if row["complete"]:
                        assert final_attempt["complete"]is True and row["error"]is None
                        assert "error_type"not in row and "error_errno"not in row
                    else:
                        assert type(row["error"])is str and row["error"]and type(row["error_type"])is str
                        assert "error_errno"in row
                        assert row["sequence"]not in admitted_samples
                        refused_fault=initial_faults[refused_samples[row["sequence"]]["fault_id"]]
                        actual_errno=(refused_fault if refused_fault["complete"]else fault_completions[refused_fault["fault_id"]])["errno"]
                        def json_native(value):
                            kind=type(value)
                            if value is None:return dict(type="none",complete=True)
                            if kind in(bool,int,str):return dict(type=kind.__name__,value=value,complete=True)
                            if kind is float:
                                import struct
                                return dict(type="float",bits=struct.pack(">d",value).hex(),complete=True)
                            assert kind in(list,dict)
                            items=([json_native(item)for item in value]if kind is list else
                                   [[json_native(key),json_native(item)]for key,item in value.items()])
                            return dict(type=kind.__name__,items=items,complete=True)
                        assert json_native(row["error_errno"])==actual_errno
                    if final_attempt["complete"]:
                        assert row["admitted_attempt"]==final_attempt["attempt_id"]and type(row["parsed_rows"])is int and row["parsed_rows"]>0
                    else:assert "admitted_attempt"not in row and "parsed_rows"not in row
                    assert all(type(row[key])in(int,float)and math.isfinite(row[key])and row[key]>=0 for key in ("started_monotonic","ended_monotonic","deadline"))
                    assert row["deadline"]<=row["started_monotonic"]+2
                    prior_end=row["started_monotonic"]
                    cid=row["command_id"]
                    previous_owned=process_owned.setdefault(cid,{})
                    previous_pending=process_pending.setdefault(cid,{})
                    scope=row["scope"]
                    assert type(scope["cli_unreaped"])is bool and type(scope["owned"])is dict and type(scope["pending"])is dict
                    assert scope["cli_pid"]is None or type(scope["cli_pid"])is int and scope["cli_pid"]>0
                    assert scope["cli_pid"]==(None if commands[cid]["launch"]is None else commands[cid]["launch"]["pid"])
                    assert scope["owned"]==previous_owned and scope["pending"]==previous_pending
                    assert row["started_monotonic"]<=row["ended_monotonic"]
                    for ordinal,attempt in enumerate(attempts,1):
                        required_attempt={"attempt_id","ordinal","started_monotonic","ended_monotonic","deadline","returncode","stdout_ref","stderr_ref","complete","error","error_type","error_monotonic","unknown_pids","foreign_proof","launch_state"}
                        assert required_attempt<=set(attempt)<=required_attempt|{"error_arguments","eligibility_error"}
                        assert type(attempt["complete"])is bool
                        assert type(attempt["launch_state"])is str and attempt["launch_state"]in {"not-attempted","creation-unknown","returned","timeout"}
                        if attempt["launch_state"]=="returned":assert type(attempt["returncode"])is int
                        else:assert attempt["returncode"]is None and attempt["complete"]is False
                        if row["complete"]and ordinal==len(attempts):
                            assert attempt["error"]is None and attempt["error_type"]is None and attempt["error_monotonic"]is None
                        if not attempt["complete"]and attempt["foreign_proof"]is None:
                            assert type(attempt["error"])is str and attempt["error"]and type(attempt["error_type"])is str
                            assert type(attempt["error_monotonic"])in(int,float)and math.isfinite(attempt["error_monotonic"])
                        assert attempt["returncode"]is None or type(attempt["returncode"])is int
                        assert attempt["error"]is None or type(attempt["error"])is str
                        assert attempt["error_type"]is None or type(attempt["error_type"])is str
                        assert attempt["error_monotonic"]is None or type(attempt["error_monotonic"])in(int,float)and math.isfinite(attempt["error_monotonic"])
                        assert type(attempt["unknown_pids"])is list and all(type(pid)is int and pid>0 for pid in attempt["unknown_pids"])
                        native_attempt_ids.append(attempt["attempt_id"])
                        assert type(attempt["attempt_id"])is int and attempt["attempt_id"]==len(native_attempt_ids)
                        assert type(attempt["ordinal"])is int and attempt["ordinal"]==ordinal and attempt["deadline"]==row["deadline"]
                        assert all(type(attempt[key])in(int,float)and math.isfinite(attempt[key])and attempt[key]>=0 for key in ("started_monotonic","ended_monotonic","deadline"))
                        assert prior_end<=attempt["started_monotonic"]<=attempt["ended_monotonic"]
                        assert attempt["ended_monotonic"]<=row["ended_monotonic"]
                        prior_end=attempt["ended_monotonic"]
                        if not attempt["complete"] and attempt["foreign_proof"]is None:
                            assert not row["complete"] and rc!=0 and ordinal==len(attempts) and attempt["error"]
                            continue
                        assert attempt["returncode"]==0 and attempt["launch_state"]=="returned"
                        errref=attempt["stderr_ref"]
                        resolved=raw_completions.get(errref["file"],{}).get("available",errref)
                        error_bytes=files[resolved["file"]] if resolved["file"]in files else raw_ref(errref)
                        assert error_bytes==b""
                        parsed,unknown=census(attempt["stdout_ref"])
                        scope=row["scope"]
                        assert type(scope)is dict and set(scope)=={"command_id","cli_pid","cli_unreaped","owned","pending"}
                        assert scope["command_id"]==cid and type(scope["cli_unreaped"])is bool
                        expected_cli=None if commands[cid]["launch"]is None else commands[cid]["launch"]["pid"]
                        assert scope["cli_pid"]==expected_cli
                        assert type(scope["owned"])is dict and type(scope["pending"])is dict
                        assert scope["owned"]==previous_owned and scope["pending"]==previous_pending
                        if attempt["foreign_proof"]is not None:
                            assert ordinal==1 and len(attempts)==2 and not attempt["complete"] and unknown
                            assert attempt["unknown_pids"]==unknown
                            assert attempt["error_type"]=="Refusal" and attempt["error_arguments"]==["unsupported native STAT"]
                            assert attempt["started_monotonic"]<=attempt["error_monotonic"]<=attempt["ended_monotonic"]
                            protected={start["observer_pid"]}|set(map(int,previous_owned))|set(map(int,previous_pending))
                            if expected_cli is not None:protected.add(expected_cli)
                            paths={}
                            for pid in parsed:
                                chain=[];current=pid
                                while current!=0:
                                    assert current in parsed and current not in chain
                                    chain.append(current);current=parsed[current]["ppid"]
                                paths[pid]=chain
                            assert all(not protected.intersection(paths[pid]) and all(pid not in paths.get(root,[])for root in protected)for pid in unknown)
                            proof=attempt["foreign_proof"]
                            assert set(proof)=={"observer_pid","protected_pids","unknown_pids","parent_paths","graph_rows","proved_monotonic"}
                            assert type(proof["observer_pid"])is int and proof["observer_pid"]==start["observer_pid"]
                            assert type(proof["protected_pids"])is list and all(type(pid)is int for pid in proof["protected_pids"]) and proof["protected_pids"]==sorted(protected)
                            assert proof["unknown_pids"]==unknown and proof["parent_paths"]=={str(pid):paths[pid]for pid in unknown}
                            assert proof["graph_rows"]==len(parsed)
                            assert attempt["error_monotonic"]<=proof["proved_monotonic"]<=attempt["ended_monotonic"]<row["deadline"]
                        else:
                            assert not unknown and attempt["unknown_pids"]==[] and ordinal==len(attempts)
                            if row["complete"]:
                                assert row["admitted_attempt"]==attempt["attempt_id"] and row["parsed_rows"]==len(parsed)
                                assert attempt["ended_monotonic"]<=row["ended_monotonic"]<row["deadline"]
                                admitted = admitted_samples.get(row["sequence"])
                                if admitted is None:
                                    assert rc != 0 and row["sequence"] in refused_samples
                                    continue  # complete raw census without journal admission has no authority
                                assert admitted["attempt_id"] == attempt["attempt_id"] and admitted["deadline"] == row["deadline"]
                                assert row["ended_monotonic"] <= admitted["committed_monotonic"] < row["deadline"]
                                if row["phase"]!="preflight":
                                    def same(left,right):return right is not None and left["birth"]==right["birth"] and left["command"]==right["command"]
                                    for key,old in previous_owned.items():
                                        current=parsed.get(int(key))
                                        if current is None:previous_pending.pop(key,None)
                                        elif not same(old,current):previous_pending[key]=current
                                    parents={expected_cli}if scope["cli_unreaped"]and expected_cli in parsed and not parsed[expected_cli]["state"].startswith("Z")else set()
                                    parents|={int(key)for key,old in previous_owned.items()if key not in previous_pending and same(old,parsed.get(int(key)))and not parsed[int(key)]["state"].startswith("Z")}
                                    changed=True
                                    while changed:
                                        changed=False
                                        for pid,current in parsed.items():
                                            if pid>0 and str(pid)not in previous_owned and current["ppid"]in parents:
                                                previous_owned[str(pid)]=current
                                                if not current["state"].startswith("Z"):parents.add(pid)
                                                changed=True
                                    effect_authorities[row["sequence"]] = {int(key):parsed[int(key)] for key,old in previous_owned.items()
                                        if key not in previous_pending and same(old,parsed.get(int(key))) and not parsed[int(key)]["state"].startswith("Z")}
                    if len(attempts)==2 and not row["complete"]:
                        original=attempts[0]
                        assert any(fault["operation"]=="process-observation-parse" and fault["observed_monotonic"]==original["error_monotonic"]for fault in faults.values())
            assert set(admitted_samples).isdisjoint(refused_samples)
            assert set(admitted_samples)|set(refused_samples)==set(samples)
            assert all(x["end"] is not None for x in commands.values())
            delivered = [b"".join(c["channels"][i][:c["end"]["channels"][i]["delivered_bytes"]]
                                  for c in commands.values()) for i in (0,1)]
            # The closed journal determines boundaries, never a search through source bytes.
            transport = records[0]["public_transport"]
            assert set(transport) == {"version", "control_framing", "profiles"}
            assert type(transport["version"]) is int and transport["version"] == 1
            assert transport["control_framing"] == context["control_framing"]
            assert type(transport["profiles"]) is list and len(transport["profiles"]) == 2
            profile_keys = {"id", "fd", "sink_kind", "presentation", "before", "complete", "fault_id"}
            snapshot_keys = {"started", "ended", "identity", "status_flags", "descriptor_flags", "termios", "discipline", "complete", "fault_id"}
            protected = os.O_ACCMODE
            for name in ("O_APPEND", "O_ASYNC", "O_FSYNC", "O_SYNC", "O_DSYNC"):
                protected |= getattr(os, name)
            profiles = {}
            def valid_stamp(stamp):
                import math
                assert type(stamp) is dict and set(stamp) == {"utc", "mono"}
                assert type(stamp["utc"]) is str and dt.datetime.fromisoformat(stamp["utc"]).utcoffset() == dt.timedelta(0)
                assert dt.datetime.fromisoformat(context["start_utc"]) <= dt.datetime.fromisoformat(stamp["utc"]) <= dt.datetime.fromisoformat(context["end_utc"]), "native UTC sample outside actual caller interval"
                assert type(stamp["mono"]) in (int,float) and math.isfinite(stamp["mono"]) and stamp["mono"] >= 0
            def snapshot(value, baseline=None, borrowed=False):
                import math
                import fcntl
                import struct
                assert type(value) is dict and set(value) == snapshot_keys
                assert value["complete"] is True and value["fault_id"] is None
                for key in ("started", "ended"):
                    stamp = value[key]
                    valid_stamp(stamp)
                    assert set(stamp) == {"utc", "mono"} and type(stamp["utc"]) is str
                    assert dt.datetime.fromisoformat(stamp["utc"]).utcoffset() == dt.timedelta(0)
                    assert type(stamp["mono"]) in (int, float) and math.isfinite(stamp["mono"]) and stamp["mono"] >= 0
                assert value["started"]["mono"] <= value["ended"]["mono"]
                identity_fields = value["identity"]
                assert type(identity_fields) is dict and set(identity_fields) == {"dev", "ino", "rdev", "mode", "uid", "gid"}, "invalid Darwin native identity keys"
                assert (all(type(n) is int for n in identity_fields.values())
                        and all(identity_fields[key] == -1 or 0 <= identity_fields[key] < (1 << 31)
                                or (1 << 64) - (1 << 31) <= identity_fields[key] < (1 << 64) - 1
                                for key in ("dev", "rdev"))
                        and 0 <= identity_fields["ino"] < (1 << 64)
                        and 0 <= identity_fields["mode"] < (1 << 16)
                        and all(-1 <= identity_fields[key] < (1 << 32) - 1 for key in ("uid", "gid"))), "invalid Darwin native identity domain"
                assert all(type(value[k]) is int and value[k] >= 0 for k in ("status_flags", "descriptor_flags"))
                assert all(value[k] <= (1 << (8*struct.calcsize("n")-1))-1 for k in ("status_flags", "descriptor_flags"))
                assert not value["descriptor_flags"] & ~fcntl.FD_CLOEXEC
                assert value["status_flags"] & os.O_ACCMODE in (os.O_WRONLY, os.O_RDWR)
                if borrowed:
                    assert value["status_flags"] & os.O_NONBLOCK
                if baseline is not None:
                    assert value["identity"] == baseline["identity"]
                    assert value["descriptor_flags"] == baseline["descriptor_flags"]
                    assert value["status_flags"] & protected == baseline["status_flags"] & protected
                    assert value["termios"] == baseline["termios"] and value["discipline"] == baseline["discipline"]
                return value
            for number, profile in enumerate(transport["profiles"], 1):
                assert type(profile) is dict and set(profile) == profile_keys
                assert type(profile["id"]) is type(profile["fd"]) is int and profile["id"] == profile["fd"] == number
                assert profile["complete"] is True and profile["fault_id"] is None
                assert profile["sink_kind"] in {"pipe", "fifo", "socket", "regular", "tty"}
                assert profile["presentation"] in {"identity", "onlcr"}
                snapshot(profile["before"])
                mode = profile["before"]["identity"]["mode"]
                assert (stat.S_ISFIFO(mode) if profile["sink_kind"] in {"pipe", "fifo"} else
                        stat.S_ISSOCK(mode) if profile["sink_kind"] == "socket" else
                        stat.S_ISREG(mode) if profile["sink_kind"] == "regular" else stat.S_ISCHR(mode))
                profiles[number] = profile
            lease = records[0]["public_control_lease"]
            assert set(lease) == {"protected_controls", "setup_effects"}
            assert type(lease["protected_controls"]) is int and lease["protected_controls"] == protected
            assert type(lease["setup_effects"]) is list and len(lease["setup_effects"]) == 2
            for descriptor, effect in enumerate(lease["setup_effects"], 1):
                assert set(effect) == {"fd", "desired_nonblocking", "before", "after", "attempted", "returned", "fault_ids", "complete"}
                assert type(effect["fd"]) is int and effect["fd"] == descriptor
                assert effect["desired_nonblocking"] is True and effect["complete"] is True and effect["fault_ids"] == []
                before = snapshot(effect["before"], profiles[descriptor]["before"])
                after = snapshot(effect["after"], profiles[descriptor]["before"], True)
                assert after["status_flags"] == before["status_flags"] | os.O_NONBLOCK
                assert effect["attempted"] is (not bool(before["status_flags"] & os.O_NONBLOCK))
                if effect["attempted"]:
                    assert effect["returned"]["type"] == "bytes" and effect["returned"]["bytes"] == 4 and effect["returned"]["complete"] is True
                    import struct
                    returned=effect["returned"]
                    assert set(returned)=={"type","bytes","hex_chunks","complete"}
                    assert type(returned["bytes"]) is int and type(returned["hex_chunks"]) is list
                    assert len(returned["hex_chunks"])==1 and returned["hex_chunks"][0]==struct.pack("i",1).hex()
                else:
                    assert effect["returned"] is None
                assert before["ended"]["mono"] <= after["started"]["mono"]
            assert max(profile["before"]["ended"]["mono"] for profile in profiles.values()) <= lease["setup_effects"][0]["before"]["started"]["mono"]
            assert profiles[1]["before"]["ended"]["mono"] <= profiles[2]["before"]["started"]["mono"], "overlapping native baselines"
            assert lease["setup_effects"][0]["after"]["ended"]["mono"] <= lease["setup_effects"][1]["before"]["started"]["mono"], "overlapping native setup effects"
            # Independent native contexts supply actual receiver groups and pre-call
            # open-description witnesses; equal inode never creates a group.
            if actual_transport is None:
                assert all(x["sink_kind"] in {"pipe", "fifo"} and x["presentation"] == "identity" for x in profiles.values())
                groups = {1: dict(fds=[1], kind="stream", wire=stdout), 2: dict(fds=[2], kind="stream", wire=stderr)}
                group_for = {1: 1, 2: 2}
                control_group = 1
            else:
                assert actual_transport["observed_call"] == dict(argv=context["argv"], cwd=context["cwd"], pid=context["pid"])
                groups = actual_transport["groups"]
                assert type(groups) is dict and groups
                group_for = {}
                for key, group in groups.items():
                    assert type(group["wire"]) is bytes and group["kind"] in {"stream", "file"}
                    assert type(group["fds"]) is list and group["fds"]
                    for descriptor in group["fds"]:
                        assert type(descriptor) is int and descriptor in (1, 2) and descriptor not in group_for
                        group_for[descriptor] = key
                    if len(group["fds"]) > 1:
                        assert set(group["description_groups"]) == set(group["fds"])
                        witness = group["description_witness"]
                        assert witness["observed_call"] == actual_transport["observed_call"]
                        if len(set(group["description_groups"].values())) == 1:
                            assert witness["creation"] in {"dup", "same-popen-endpoint"}
                        else:
                            assert group["kind"] == "file" and witness["creation"] == "independent-opens"
                            assert len(witness["actual_opens"]) == len(group["fds"])
                            assert group["file_image_witness"]["source"] == "actual-initial-and-final-file-images"
                    if group["kind"] == "file":
                        assert type(group["initial_image"]) is bytes
                        assert group["file_image_witness"]["source"] == "actual-initial-and-final-file-images"
                assert set(group_for) == {1, 2}
                control_group = actual_transport["control_group"]
                assert group_for[1] == control_group
                for descriptor, profile in profiles.items():
                    independent = actual_transport["profiles"][descriptor]
                    assert independent["source"] == "actual-pre-call-native-observation"
                    observed = independent["snapshot"]
                    assert observed["complete"] is True and observed["identity"] == profile["before"]["identity"]
                    assert observed["status_flags"] & (protected | os.O_NONBLOCK) == profile["before"]["status_flags"] & (protected | os.O_NONBLOCK)
                    assert observed["termios"] == profile["before"]["termios"] and observed["discipline"] == profile["before"]["discipline"]
            def presented(source, descriptor):
                profile = profiles[descriptor]
                if profile["sink_kind"] != "tty":
                    assert profile["presentation"] == "identity" and profile["before"]["termios"] is None and profile["before"]["discipline"] is None
                    return source
                import termios
                t = profile["before"]["termios"]
                assert type(t) is dict and set(t) == {"iflag", "oflag", "cflag", "lflag", "ispeed", "ospeed", "cc_native"}
                assert all(type(t[k]) is int and t[k] >= 0 for k in ("iflag", "oflag", "cflag", "lflag", "ispeed", "ospeed"))
                assert t["cc_native"]["complete"] is True
                cc = t["cc_native"]
                assert set(cc) == {"type", "items", "complete"} and cc["type"] in {"list", "tuple"}
                assert len(cc["items"]) == termios.NCCS
                for item in cc["items"]:
                    if item["type"] == "int":
                        assert set(item) == {"type", "value", "complete"} and type(item["value"]) is int and 0 <= item["value"] <= 255
                    else:
                        assert set(item) == {"type", "hex_chunks", "bytes", "complete"} and item["type"] == "bytes"
                        assert type(item["bytes"]) is int and item["bytes"] == 1
                        assert type(item["hex_chunks"]) is list and len(item["hex_chunks"]) == 1 and re.fullmatch("[0-9a-f]{2}", item["hex_chunks"][0])
                    assert item["complete"] is True
                assert profile["before"]["discipline"] == 0 and t["cflag"] & termios.CSIZE == termios.CS8
                assert not t["lflag"] & termios.FLUSHO
                if profile["presentation"] == "onlcr":
                    assert t["oflag"] == termios.OPOST | termios.ONLCR
                    return source.replace(b"\n", b"\r\n")
                assert not t["oflag"] & termios.OPOST
                return source
            for descriptor in profiles:
                assert presented(b"", descriptor) == b""
            start_attempts = provisional[0]["start_control_attempts"]
            assert len(start_attempts) == 1
            start_attempt = start_attempts[0]
            assert set(start_attempt) == {"attempt_id", "state", "raw_source_hex", "sha256", "intended_bytes", "stream_offset", "written_bytes", "complete", "before_profile", "after_profile", "regular_position_before", "regular_position_after"}
            assert type(start_attempt["attempt_id"]) is int and type(start_attempt["stream_offset"]) is int and start_attempt["stream_offset"] == 0
            assert type(start_attempt["complete"]) is bool and type(start_attempt["written_bytes"]) is type(start_attempt["intended_bytes"]) is int
            assert start_attempt["attempt_id"] == 1 and start_attempt["state"] == "start" and start_attempt["complete"]
            assert bytes.fromhex(start_attempt["raw_source_hex"]) == start_bytes
            assert start_attempt["sha256"] == hashlib.sha256(start_bytes).hexdigest()
            assert start_attempt["intended_bytes"] == start_attempt["written_bytes"] == len(start_bytes)
            for which in ("before_profile", "after_profile"):
                snapshot(start_attempt[which], profiles[1]["before"], True)
            assert lease["setup_effects"][1]["after"]["ended"]["mono"] <= start_attempt["before_profile"]["started"]["mono"] <= start_attempt["before_profile"]["ended"]["mono"] <= start_attempt["after_profile"]["started"]["mono"] <= start_attempt["after_profile"]["ended"]["mono"], "unordered native setup/start observations"
            previous_command_end = start_attempt["after_profile"]["ended"]["mono"]
            for command in commands.values():
                begin, finish = command["begin"], command["end"]
                valid_stamp(dict(utc=begin["started_utc"], mono=begin["started_monotonic"]))
                valid_stamp(dict(utc=finish["started_utc"], mono=finish["started_monotonic"]))
                valid_stamp(dict(utc=finish["ended_utc"], mono=finish["ended_monotonic"]))
                assert finish["started_utc"] == begin["started_utc"], "command UTC start binding differs"
                assert previous_command_end <= begin["started_monotonic"] <= finish["ended_monotonic"], "unordered serial command intervals"
                previous_command_end = finish["ended_monotonic"]
            bodies = {key: bytearray() for key in groups}
            file_images = {key: bytearray(group["initial_image"]) for key, group in groups.items() if group["kind"] == "file"}
            positions = {}
            def description_key(key, descriptor):
                return key, groups[key].get("description_groups", {descriptor: descriptor})[descriptor]
            def file_write(key, data, before, after, descriptor):
                import struct
                assert type(before) is int and type(after) is int and before >= 0 and after >= len(data)
                maximum=(1 << (8*struct.calcsize("n")-1))-1
                assert before <= maximum and after <= maximum
                cursor = description_key(key, descriptor)
                initial_position = actual_transport["profiles"][descriptor]["regular_position"]
                assert type(initial_position) is int and initial_position >= 0
                assert before == positions.get(cursor, initial_position), "unexplained shared-description position change"
                append = bool(profiles[descriptor]["before"]["status_flags"] & os.O_APPEND)
                place = after - len(data) if append else before
                assert place + len(data) <= len(groups[key]["wire"]), "position exceeds the actual complete file image"
                if not append:
                    assert after == before + len(data)
                image = file_images[key]
                if append:
                    assert place == len(image), "unexplained append placement"
                if place > len(image):
                    image.extend(b"\x00" * (place - len(image)))
                image[place:place + len(data)] = data
                positions[cursor] = after
                return place
            if groups[control_group]["kind"] == "file":
                place = file_write(control_group, start_bytes, start_attempt["regular_position_before"], start_attempt["regular_position_after"], 1)
                assert place == at
            rows = [row for c in commands.values() for row in c["end"]["public_writes"]]
            assert provisional[0]["public_write_count"] == len(rows)
            next_offsets = {(cid, channel): 0 for cid in commands for channel in (0, 1)}
            row_keys = {"sequence", "command_id", "fd", "channel", "source_start", "source_end", "intended_bytes", "source_sha256", "profile_id", "returned_count", "written_source_bytes", "source_offset_before", "source_offset_after", "fault_id", "started", "ended", "before_profile", "after_profile", "before_profile_fault_id", "after_profile_fault_id", "regular_position_before", "regular_position_after", "outcome"}
            previous_write_end = start_attempt["after_profile"]["ended"]["mono"]
            for sequence, row in enumerate(rows, 1):
                assert set(row) == row_keys and type(row["sequence"]) is int and row["sequence"] == sequence
                cid, channel, descriptor = row["command_id"], row["channel"], row["fd"]
                assert type(cid) is int and cid in commands and type(channel) is int and channel in (0, 1)
                assert type(descriptor) is type(row["profile_id"]) is int and descriptor == channel + 1 and row["profile_id"] == descriptor
                source = commands[cid]["channels"][channel]
                begin, finish = row["source_start"], row["source_end"]
                assert type(begin) is int and type(finish) is int and 0 <= begin <= finish <= len(source)
                assert type(row["intended_bytes"]) is int and row["intended_bytes"] == finish - begin <= 4096
                assert row["source_sha256"] == hashlib.sha256(source[begin:finish]).hexdigest()
                count = row["returned_count"]
                assert row["outcome"] == "syscall-returned" and type(count) is int and 0 <= count <= finish - begin
                assert row["written_source_bytes"] == count and row["source_offset_before"] == begin == next_offsets[cid, channel]
                assert row["source_offset_after"] == begin + count
                assert all(type(row[k]) is int for k in ("written_source_bytes", "source_offset_before", "source_offset_after"))
                assert row["fault_id"] is None or (type(row["fault_id"]) is int and row["fault_id"] in faults and faults[row["fault_id"]]["command_id"] == cid)
                valid_stamp(row["started"]); valid_stamp(row["ended"])
                assert row["before_profile_fault_id"] is row["after_profile_fault_id"] is None
                snapshot(row["before_profile"], profiles[descriptor]["before"], True)
                snapshot(row["after_profile"], profiles[descriptor]["before"], True)
                assert row["started"]["mono"] <= row["before_profile"]["started"]["mono"] <= row["after_profile"]["ended"]["mono"] <= row["ended"]["mono"]
                assert row["before_profile"]["ended"]["mono"] <= row["after_profile"]["started"]["mono"], "overlapping native write observations"
                assert commands[cid]["begin"]["started_monotonic"] <= row["started"]["mono"] <= row["ended"]["mono"] <= commands[cid]["end"]["ended_monotonic"], "native write outside actual command interval"
                assert previous_write_end <= row["started"]["mono"], "unordered invocation-global write intervals"
                previous_write_end = row["ended"]["mono"]
                next_offsets[cid, channel] += count
                piece = presented(source[begin:begin + count], descriptor)
                key = group_for[descriptor]
                if groups[key]["kind"] == "file":
                    file_write(key, piece, row["regular_position_before"], row["regular_position_after"], descriptor)
                else:
                    assert row["regular_position_before"] is row["regular_position_after"] is None
                    bodies[key].extend(piece)
            for cid, command in commands.items():
                for channel in (0, 1):
                    assert next_offsets[cid, channel] == command["end"]["channels"][channel]["delivered_bytes"]
            if groups[control_group]["kind"] == "file":
                key = description_key(control_group, 1)
                terminal_at = len(file_images[control_group]) if profiles[1]["before"]["status_flags"] & os.O_APPEND else positions[key]
            else:
                terminal_at = start_end + len(bodies[control_group])
            terminal_bytes, terminal_end = _control_object(control_wire, terminal_at)
            markers.append(decode(terminal_bytes[14:])); marker_bytes.append(terminal_bytes)
            assert len(markers) == 2 and [x["event"] for x in markers] == ["start", "terminal"]
            start, end = markers
            assert type(end.get("start_sha256")) is str and re.fullmatch(r"[0-9a-f]{64}", end["start_sha256"]) and end["start_sha256"] == hashlib.sha256(marker_bytes[0]).hexdigest(), "conflicting exact start reference"
            assert set(end) == {"event", "start_sha256", "failed", "evidence_closed", "root_descriptor_closed", "fault_count", "events_identity", "events_bytes", "events_sha256", "provisional_until_exit", "flags_restoration_pending"}
            assert re.fullmatch(r"[0-9a-f]{64}", start["entry_sha256"]) and re.fullmatch(r"[0-9a-f]{64}", end["events_sha256"])
            assert all(type(end[key]) is bool for key in ("failed", "evidence_closed", "root_descriptor_closed", "provisional_until_exit", "flags_restoration_pending"))
            assert all(type(end[key]) is int and end[key] >= 0 for key in ("fault_count", "events_bytes"))
            assert all(type(value) is list and len(value) == 2 and all(type(n) is int for n in value)
                       and (value[0] == -1 or 0 <= value[0] < (1 << 31)
                            or (1 << 64) - (1 << 31) <= value[0] < (1 << 64) - 1)
                       and 0 <= value[1] < (1 << 64)
                       for value in (start["root_identity"], end["events_identity"])), "invalid Darwin filesystem identity pair"
            assert list(identity(os.stat("events.jsonl", dir_fd=fd, follow_symlinks=False),0o600,stat.S_ISREG)) == end["events_identity"]
            assert len(journal) == end["events_bytes"] and hashlib.sha256(journal).hexdigest() == end["events_sha256"]
            assert end["evidence_closed"] and end["root_descriptor_closed"]
            assert end["provisional_until_exit"] and end["flags_restoration_pending"]
            if groups[control_group]["kind"] == "file":
                terminal_after = terminal_at + len(terminal_bytes)
                file_write(control_group, terminal_bytes, positions[description_key(control_group, 1)], terminal_after, 1)
            for key, group in groups.items():
                if group["kind"] == "file":
                    assert group["wire"] == bytes(file_images[key]), "actual final file image differs"
                else:
                    expected_wire = (start_bytes if key == control_group else b"") + bytes(bodies[key]) + (terminal_bytes if key == control_group else b"")
                    assert group["wire"] == expected_wire, "actual wire differs from independently constructed presentation"
            public_raw = control_wire[start_end:terminal_at]
            if actual_transport is None:
                assert stderr == delivered[1], "actual raw stderr differs from delivered command ranges"
                assert public_raw == delivered[0], "actual raw stdout differs from delivered command ranges"
            context["transport_verification"] = dict(disposition="identity-verified" if actual_transport is None else "actual-groups-forward-verified",
                exact_private_source=True, exact_received_controls=True, normalized_received_bytes=False)
            assert len(faults) == provisional[0]["fault_count"] == end["fault_count"]
            assert identity(root.lstat(), 0o700, stat.S_ISDIR) == expected
            assert identity(os.fstat(fd), 0o700, stat.S_ISDIR) == expected
        finally:
            os.close(fd)
        after = Path(context["entry"])
        context["source_after"] = dict(sha256=hashlib.sha256(after.read_bytes()).hexdigest(), mode=stat.S_IMODE(after.stat().st_mode))
        if rc == 0:
            assert not faults and not end["failed"] and not provisional[0]["failed"]
            assert provisional[0]["caught_signal"] is None and not provisional[0]["unavailable_raw_channels"]
            assert records[-2]["event"] in ("empty", "success") and context["source_after"] == context["entry_pin"]
            for command in commands.values():
                outcome = command["end"]
                assert outcome["returncode"] == 0 and outcome["drain_complete"] and outcome["reaped"] and not outcome["fault_ids"]
                assert all(x["state"] == "eof" and x["capture_complete"] and not x["missing_delivery_ranges"] for x in outcome["channels"])
                if command["begin"]["watch"]:
                    receipt = command["children"][0]
                    assert receipt["remaining_observed_live"] == [] and receipt["unresolved_identity_pids"] == []
                    assert not receipt["observation_errors"] and not receipt["cleanup_faults"] and receipt["drain_complete"]
                    assert receipt["caught_signal"] is None and not receipt["cleanup_intervention"]
            context["disposition"] = "verified-zero"
        else:
            assert faults and end["failed"] and provisional[0]["failed"]
            context["disposition"] = "admission-refusal" if not commands else "command-start-refusal" if any(x["end"]["launch_state"] != "created" for x in commands.values()) else "command-refusal"
            if context["source_after"] != context["entry_pin"]:
                assert any(x["event"] == "refused" and "entry script changed" in x["error"] for x in records)
        independently_observed = False
        if actual_transport is not None:
            witness = actual_transport["post_state"]
            assert witness["source"] == "retained-actual-open-descriptions-after-owner-return"
            assert witness["observed_call"] == actual_transport["observed_call"]
            assert set(witness["descriptors"]) == {1, 2}
            for descriptor, observed in witness["descriptors"].items():
                assert observed["description_witness"] == actual_transport["profiles"][descriptor]["description_witness"]
                assert observed["phase"] == "after-actual-owner-return"
                baseline = snapshot(actual_transport["profiles"][descriptor]["snapshot"])
                final = snapshot(observed["snapshot"], baseline)
                group_key=group_for[descriptor]
                if groups[group_key]["kind"] == "file":
                    assert type(observed["regular_position"]) is int
                    cursor=description_key(group_key,descriptor)
                    assert observed["regular_position"] == positions.get(cursor, actual_transport["profiles"][descriptor]["regular_position"])
                else:
                    assert observed["regular_position"] is None
                assert bool(final["status_flags"] & os.O_NONBLOCK) is bool(baseline["status_flags"] & os.O_NONBLOCK)
                assert dt.datetime.fromisoformat(context["start_utc"]) <= dt.datetime.fromisoformat(final["started"]["utc"])
                assert dt.datetime.fromisoformat(final["ended"]["utc"]) <= dt.datetime.fromisoformat(context["end_utc"])
            # This independent state witness detects wrong/missing restoration even
            # with an earlier nonzero. It cannot expose a state-correct late query
            # exception already hidden behind that same earlier nonzero.
            independently_observed = True
        context["verification"] = dict(source_invariant_and_actual_exit=True, actual_flags_independently_observed=independently_observed,
                                       state_correct_late_query_error_independently_observable=False,
                                       reported_pid_independently_observed=context["pid"] is not None)
        return records
    except (AssertionError, KeyError, ValueError, OSError, UnicodeError, TypeError) as error:
        return incomplete("hook evidence protocol: " + str(error))


def _run(repo, *, cwd=None, env=None, script=None, timeout=300):
    before = _index(repo)
    names = _git(repo, "ls-files", "-z").split(b"\0")
    notebooks = {os.fsdecode(n): ((repo / os.fsdecode(n)).read_bytes(),
                 stat.S_IMODE((repo / os.fsdecode(n)).stat().st_mode))
                 for n in names if n.endswith(b".ipynb") and (repo / os.fsdecode(n)).is_file()
                 and not (repo / os.fsdecode(n)).is_symlink()}
    r = _call(["bash", str(script or HOOK)], cwd or repo, env=env, timeout=timeout, hook=script or HOOK)
    assert _index(repo) == before, "hook changed raw fixture index"
    for n, (data, mode) in notebooks.items():
        assert (repo / n).read_bytes() == data
        assert stat.S_IMODE((repo / n).stat().st_mode) == mode
    return r


@pytest.fixture
def cheap_repo(tmp_path):
    repo = _init(tmp_path / "ordinary repo")
    (repo / "src").mkdir()
    (repo / "src/__init__.py").write_text("")
    (repo / "pyproject.toml").write_text("# admission-only fixture, never used for runtime setup\n")
    (repo / "uv.lock").write_text("# admission-only fixture\n")
    _commit(repo)
    return repo


def test_empty_primary_and_subdirectory_are_measured_without_runtime(cheap_repo):
    (cheap_repo / "nested").mkdir()
    for cwd in (cheap_repo, cheap_repo / "nested"):
        r = _run(cheap_repo, cwd=cwd)
        assert r.returncode == 0
        assert _events(r)[-2] == {"event": "empty", "measured_eligible_notebooks": 0}


def test_empty_linked_common_entry_relative_and_absolute_administration(cheap_repo, tmp_path):
    linked = tmp_path / "linked checkout"
    _git(cheap_repo, "worktree", "add", "--detach", str(linked), "HEAD")
    admin = Path((linked / ".git").read_text().strip()[8:])
    for value in (str(admin), os.path.relpath(admin, cheap_repo)):
        env = _env()
        env["GIT_DIR"] = value
        r = _run(linked, cwd=cheap_repo, env=env)
        assert r.returncode == 0
        assert next(x for x in _events(r) if x["event"] == "admission")["checkout"] == str(linked)


def test_git_failure_and_contradictory_context_are_not_empty_success(cheap_repo):
    for extra in ({"GIT_DIR": "/does-not-exist/not-a-repository"},
                  {"GIT_WORK_TREE": str(cheap_repo.parent)},
                  {"GIT_OBJECT_DIRECTORY": str(cheap_repo / ".git/objects")}):
        env = _env()
        env.update(extra)
        r = _run(cheap_repo, env=env)
        assert r.returncode != 0
        assert not any(x["event"] == "empty" for x in _events(r))


@pytest.mark.parametrize("staged_fails", [False, True])
def test_partial_staging_refuses_both_directions_before_runtime(cheap_repo, staged_fails):
    p = _write(cheap_repo, "notebooks/partial.ipynb", _nb("assert False" if staged_fails else "assert True"))
    _stage(cheap_repo)
    p.write_text(json.dumps(_nb("assert True" if staged_fails else "assert False")))
    r = _run(cheap_repo)
    assert r.returncode != 0 and "partial notebook staging refused" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")


@pytest.mark.parametrize("kind", ["missing", "symlink", "mode", "type", "unmerged"])
def test_unsafe_notebook_inputs_refuse_without_executor(cheap_repo, tmp_path, kind):
    p = _write(cheap_repo, "notebooks/unsafe.ipynb", _nb())
    if kind == "symlink":
        p.unlink()
        outside = tmp_path / "outside.ipynb"
        outside.write_text(json.dumps(_nb()))
        p.symlink_to(outside)
    _stage(cheap_repo)
    if kind == "missing":
        p.unlink()
    elif kind == "mode":
        _git(cheap_repo, "config", "core.fileMode", "false")
        p.chmod(p.stat().st_mode | stat.S_IXUSR)
    elif kind == "type":
        p.unlink()
        p.mkdir()
    elif kind == "unmerged":
        oid = _git(cheap_repo, "hash-object", "-w", "--stdin", data=json.dumps(_nb()).encode()).decode().strip()
        _git(cheap_repo, "update-index", "--force-remove", "--", "notebooks/unsafe.ipynb")
        _git(cheap_repo, "update-index", "--index-info",
             data=("100644 " + oid + " 1\tnotebooks/unsafe.ipynb\n100644 " + oid + " 2\tnotebooks/unsafe.ipynb\n").encode())
    r = _run(cheap_repo)
    assert r.returncode != 0
    assert not any(x["event"] == "execution_context" for x in _events(r))


def test_deletion_is_reported_and_not_executed(cheap_repo):
    _write(cheap_repo, "deleted.ipynb", _nb("assert False"))
    _commit(cheap_repo)
    _git(cheap_repo, "rm", "--", "deleted.ipynb")
    r = _run(cheap_repo)
    assert r.returncode == 0
    assert any(x == {"event": "deleted", "path": "deleted.ipynb"} for x in _events(r))
    assert _events(r)[-2]["event"] == "empty"


def test_empty_code_tag_is_explicit_refusal(cheap_repo):
    _write(cheap_repo, "empty-tag.ipynb", _nb(tags=[""]))
    _stage(cheap_repo)
    r = _run(cheap_repo)
    assert r.returncode != 0 and "empty code tag" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")


def _prepare_runtime(repo):
    # Actual root-run preparation, never a mock or copied editable environment.
    r = _call(["uv", "sync", "--locked"], repo, timeout=900)
    assert r.returncode == 0, r.stderr.decode(errors="replace")
    selected = [json.loads(p.read_text()) for p in (repo / "notebooks").glob("*.ipynb")]
    names = sorted({n.get("metadata", {}).get("kernelspec", {}).get("name", "python3") for n in selected})
    for name in names:
        r = _call([repo / ".venv/bin/python", "-B", "-m", "ipykernel", "install",
                   "--prefix", repo / ".venv", "--name", name], repo)
        assert r.returncode == 0, r.stderr.decode(errors="replace")


@pytest.fixture(scope="session")
def prepared_pair(tmp_path_factory):
    root = tmp_path_factory.mktemp("notebook-real-runtime")
    primary = _init(root / "primary checkout")
    for name in ("src", "rust"):
        shutil.copytree(REPO / name, primary / name,
                        ignore=shutil.ignore_patterns("target", "__pycache__", "*.pyc", "*.so", "*.pyd"))
    for name in ("pyproject.toml", "uv.lock", "README.md", ".gitignore"):
        shutil.copy2(REPO / name, primary / name)
    (primary / "scripts").mkdir()
    shutil.copy2(HOOK, primary / "scripts/pre-commit-notebooks.sh")
    # Metadata requested by these actual non-scientific fixture notebooks owns
    # preparation names; this is not a second production kernel registry.
    _write(primary, "notebooks/runtime-default.ipynb", _nb())
    project_names = sorted({json.loads(p.read_text()).get("metadata", {}).get("kernelspec", {}).get("name")
                            for p in (REPO / "notebooks").glob("*.ipynb")} - {None, "python3"})
    project_name = project_names[0] if project_names else "python3"
    _write(primary, "notebooks/runtime-project.ipynb", _nb(kernel=project_name))
    _commit(primary)
    linked = root / "linked checkout"
    _git(primary, "worktree", "add", "--detach", str(linked), "HEAD")
    _prepare_runtime(primary)
    _prepare_runtime(linked)
    return primary, linked, project_name


@pytest.fixture
def real_repo(prepared_pair):
    primary, linked, project_name = prepared_pair
    specs = {p: p.read_bytes() for repo in (primary, linked)
             for p in (repo / ".venv/share/jupyter/kernels").glob("*/kernel.json")}
    try:
        yield primary, linked, project_name
    finally:
        for p, data in specs.items():
            p.write_bytes(data)
        for repo in (primary, linked):
            _git(repo, "reset", "--hard", "HEAD")
            _git(repo, "clean", "-fd")


def _witness(repo):
    # Non-scientific route discriminator; no research result or MC JSON is made.
    (repo / "docs").mkdir(exist_ok=True)
    (repo / "docs/fixture-asset.txt").write_text("CANDIDATE NON-SCIENTIFIC ASSET")
    code = (
        "from pathlib import Path\nimport sys,json,hashlib,os,signal\nimport src.core.constants as C\n"
        "assert not ({signal.SIGINT,signal.SIGTERM,signal.SIGHUP} & signal.pthread_sigmask(signal.SIG_BLOCK, set()))\n"
        "asset=Path('..')/'docs'/'fixture-asset.txt'\n"
        "assert asset.read_text()=='CANDIDATE NON-SCIENTIFIC ASSET'\n"
        "p=Path('execution-count.txt');count=int(p.read_text()) if p.exists() else 0\n"
        "p.write_text(str(count+1))\n"
        "Path('witness.json').write_text(json.dumps({'cwd':str(Path.cwd()),'prefix':sys.prefix,"
        "'executable':sys.executable,'module':C.__file__,'module_sha256':hashlib.sha256(Path(C.__file__).read_bytes()).hexdigest(),"
        "'asset':asset.read_text(),'pid':os.getpid()}))\n")
    return code


@pytest.mark.parametrize("route", ["primary", "linked", "common-relative", "common-absolute", "linked-subdir"])
def test_real_route_assets_imports_single_execution_and_preservation(real_repo, route):
    primary, linked, _ = real_repo
    repo = primary if route == "primary" else linked
    code = _witness(repo)
    _write(repo, "notebooks/route.ipynb", _nb(code))
    _stage(repo)
    env, cwd = _env(), repo
    if route.startswith("common"):
        admin = Path((linked / ".git").read_text().strip()[8:])
        cwd = primary
        env["GIT_DIR"] = str(admin) if route == "common-absolute" else os.path.relpath(admin, primary)
    elif route == "linked-subdir":
        cwd = linked / "notebooks"
    r = _run(repo, cwd=cwd, env=env)
    assert r.returncode == 0, r.stdout.decode() + r.stderr.decode()
    witness = json.loads((repo / "notebooks/witness.json").read_text())
    assert witness["cwd"] == str(repo / "notebooks")
    assert Path(witness["prefix"]) == repo / ".venv"
    assert Path(witness["module"]) == repo / "src/core/constants.py"
    assert witness["module_sha256"] == hashlib.sha256((repo / "src/core/constants.py").read_bytes()).hexdigest()
    assert (repo / "notebooks/execution-count.txt").read_text() == "1"
    with pytest.raises(ProcessLookupError):
        os.kill(witness["pid"], 0)
    assert _events(r)[-2]["event"] == "success"


def test_real_literal_names_multiple_additions_and_rename_destination(real_repo):
    repo, _, _ = real_repo
    names = ["notebooks/with space.ipynb", "notebooks/tab\tname.ipynb", "notebooks/newline\nname.ipynb",
             "notebooks/-leading.ipynb", "notebooks/literal[star]*;$(no-shell).ipynb"]
    for name in names:
        _write(repo, name, _nb("assert 2+2==4"))
    _stage(repo)
    r = _run(repo)
    assert r.returncode == 0, r.stdout.decode() + r.stderr.decode()
    assert set(_events(r)[-2]["executed_notebooks"]) == set(names)
    _git(repo, "reset", "--hard", "HEAD")
    _git(repo, "clean", "-fd")
    _git(repo, "mv", "--", "notebooks/runtime-default.ipynb", "notebooks/renamed.ipynb")
    p = repo / "notebooks/renamed.ipynb"
    p.write_text(json.dumps(_nb("raise ValueError('RENAME_POISON')")))
    _stage(repo)
    r = _run(repo)
    assert r.returncode != 0 and "RENAME_POISON" in r.stderr.decode()
    assert any(x["event"] == "deleted" for x in _events(r))


@pytest.mark.parametrize("tags", [["skip-execution"], ["custom-skip"], ["raises-exception"]])
def test_real_tagged_poison_executes_once_and_fails_strictly(real_repo, tags):
    repo, _, _ = real_repo
    n = _nb("from pathlib import Path\np=Path('poison-observed.txt');p.write_text('ACTUALLY EXECUTED')\nraise ValueError('STRICT_POISON')", tags=tags)
    n["cells"][0].update(execution_count=1, outputs=[{"output_type": "stream", "name": "stdout", "text": "STALE SUCCESS"}])
    _write(repo, "notebooks/poison.ipynb", n)
    _stage(repo)
    r = _run(repo)
    assert r.returncode != 0
    assert (repo / "notebooks/poison-observed.txt").read_text() == "ACTUALLY EXECUTED"
    assert "CellExecutionError" in r.stderr.decode() and "STRICT_POISON" in r.stderr.decode()
    assert not any(x["event"] == "success" for x in _events(r))


@pytest.mark.parametrize("setting", [
    {"ExecutePreprocessor": {"allow_errors": True}},
    {"ExecutePreprocessor": {"allow_error_names": ["ValueError"]}},
    {"ExecutePreprocessor": {"skip_cells_with_tag": "custom-skip"}},
    {"TagRemovePreprocessor": {"enabled": True, "remove_cell_tags": ["custom-skip"]}},
    {"RegexRemovePreprocessor": {"enabled": True, "patterns": [".*"]}},
    {"NotebookExporter": {"preprocessors": ["nbconvert.preprocessors.TagRemovePreprocessor"]}},
])
def test_real_ambient_allowance_removal_or_skip_cannot_accept_poison(real_repo, tmp_path, setting):
    repo, _, _ = real_repo
    _write(repo, "notebooks/config-poison.ipynb", _nb(
        "from pathlib import Path\nPath('config-poison-ran.txt').write_text('ran')\nraise ValueError('CONFIG_POISON')",
        tags=["custom-skip", "raises-exception"]))
    _stage(repo)
    config = tmp_path / "jupyter"
    config.mkdir()
    (config / "jupyter_nbconvert_config.json").write_text(json.dumps(setting))
    env = _env()
    env["JUPYTER_CONFIG_DIR"] = str(config)
    r = _run(repo, env=env)
    assert r.returncode != 0
    ran = repo / "notebooks/config-poison-ran.txt"
    if ran.exists():
        assert ran.read_text() == "ran" and "CellExecutionError" in r.stderr.decode()
    else:
        assert "unsupported/conflicting effective configuration" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    assert not any(x["event"] == "success" for x in _events(r))


def test_real_successful_tags_blank_cell_and_requested_project_kernel(real_repo):
    repo, _, project_name = real_repo
    n = _nb("from pathlib import Path\nPath('tagged-ran.txt').write_text('first')", tags=["skip-execution"], kernel=project_name)
    n["cells"] += [
        dict(id="blank", cell_type="code", metadata={}, source=" \n", execution_count=None, outputs=[]),
        dict(id="last", cell_type="code", metadata={"tags": ["raises-exception", "custom-skip"]},
             source="from pathlib import Path\nassert Path('tagged-ran.txt').read_text()=='first'\nprint('second')",
             execution_count=None, outputs=[])]
    _write(repo, "notebooks/clean-tagged.ipynb", n)
    _stage(repo)
    r = _run(repo)
    assert r.returncode == 0, r.stdout.decode() + r.stderr.decode()
    row = next(x for x in _events(r) if x["event"] == "executed")
    assert row["executed_nonempty_code_indices"] == [0, 2] and row["blank_code_indices"] == [1]


@pytest.mark.parametrize("problem", ["source", "untracked", "lock", "kernel-argv", "kernel-env", "runtime"])
def test_real_runtime_source_and_kernel_admission_refusals(real_repo, problem):
    repo, _, _ = real_repo
    _write(repo, "notebooks/admission.ipynb", _nb())
    _stage(repo)
    hidden = None
    if problem == "source":
        with (repo / "src/__init__.py").open("a") as f:
            f.write("\n# unstaged source\n")
    elif problem == "untracked":
        (repo / "untracked.py").write_text("raise RuntimeError('must not import')\n")
    elif problem == "lock":
        with (repo / "uv.lock").open("a") as f:
            f.write("\n# unstaged lock\n")
    elif problem.startswith("kernel"):
        p = repo / ".venv/share/jupyter/kernels/python3/kernel.json"
        spec = json.loads(p.read_text())
        if problem == "kernel-argv":
            spec["argv"][0] = str(REPO / ".venv/bin/python")
        else:
            spec["env"] = {"PYTHONPATH": str(REPO)}
        p.write_text(json.dumps(spec))
    else:
        hidden = repo / ".runtime-hidden"
        (repo / ".venv").rename(hidden)
    try:
        r = _run(repo)
        assert r.returncode != 0
        assert not any(x["event"] == "executed" for x in _events(r))
        expected = {"source": "unstaged project source/lock divergence",
                    "untracked": "untracked importable source",
                    "lock": "unstaged project source/lock divergence",
                    "kernel-argv": "kernel interpreter is not candidate",
                    "kernel-env": "unsupported kernel language/environment",
                    "runtime": "missing ordinary candidate .venv"}
        assert expected[problem] in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    finally:
        if hidden:
            hidden.rename(repo / ".venv")


@pytest.mark.parametrize("fault,reason", [
    ("executed['cells'].pop()", "result omitted/added cells"),
    ("executed['cells'][0]['execution_count']=999", "execution count"),
    ("executed['cells'][0]['metadata']['execution']={}", "execution timing"),
    ("err=b''", "DEBUG execution event"),
])
def test_real_execution_result_faults_cannot_pass_postflight(real_repo, fault, reason):
    repo, _, _ = real_repo
    _write(repo, "notebooks/postflight.ipynb", _nb("assert 3==3"))
    script = repo / "scripts/pre-commit-notebooks.sh"
    text = HOOK.read_text()
    old = "    executed = json.loads(result.read_bytes())"
    assert text.count(old) == 1
    script.write_text(text.replace(old, old + "\n    " + fault))
    _stage(repo)
    r = _run(repo, script=script)
    assert r.returncode != 0 and reason in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")


def test_real_input_mode_only_race_refuses_after_actual_execution(real_repo):
    repo, _, _ = real_repo
    code = "from pathlib import Path\np=Path('mode-race.ipynb');p.chmod(p.stat().st_mode ^ 0o100)"
    p = _write(repo, "notebooks/mode-race.ipynb", _nb(code))
    _stage(repo)
    before_index, before_bytes = _index(repo), p.read_bytes()
    r = _call(["bash", HOOK], repo, hook=HOOK)
    assert r.returncode != 0 and "notebook changed during execution" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    assert p.read_bytes() == before_bytes and _index(repo) == before_index
    assert p.stat().st_mode & stat.S_IXUSR


def test_real_concurrent_invocations_have_distinct_outputs(real_repo):
    repo, _, _ = real_repo
    _write(repo, "notebooks/concurrent.ipynb", _nb("import time\ntime.sleep(.5)\nassert True"))
    _stage(repo)
    before = _index(repo)
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    context_a = _hook_context(HOOK, ["bash", str(HOOK)], repo, _env())
    context_b = _hook_context(HOOK, ["bash", str(HOOK)], repo, _env())
    a = subprocess.Popen(["bash", str(HOOK)], cwd=repo, env=_env(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    b = subprocess.Popen(["bash", str(HOOK)], cwd=repo, env=_env(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    context_a["pid"], context_b["pid"] = a.pid, b.pid
    outs = [a.communicate(timeout=300), b.communicate(timeout=300)]
    for child, streams in zip((a, b), outs):
        print("NOTEBOOK_FIXTURE_PROCESS " + json.dumps(dict(
            argv=["bash", str(HOOK)], cwd=str(repo), start_utc=started,
            end_utc=dt.datetime.now(dt.timezone.utc).isoformat(), pid=child.pid,
            rc=child.returncode, stdout_base64=base64.b64encode(streams[0]).decode(),
            stderr_base64=base64.b64encode(streams[1]).decode())), flush=True)
    assert a.returncode == b.returncode == 0, outs
    contexts = []
    for child, (out, err), context in zip((a, b), outs, (context_a, context_b)):
        context["end_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        rows = _events(child=child, streams=(out, err), context=context)
        contexts.append(next(x for x in rows if x["event"] == "execution_context"))
    assert contexts[0]["argv"] != contexts[1]["argv"]
    assert _index(repo) == before

@pytest.mark.parametrize("problem", ["missing-kernel", "language", "custom-startup"])
def test_real_missing_or_custom_kernel_is_not_substituted(real_repo, problem):
    repo, _, _ = real_repo
    n = _nb(kernel="not-prepared-fixture-kernel" if problem == "missing-kernel" else "python3")
    if problem == "language":
        n["metadata"]["kernelspec"]["language"] = "julia"
    elif problem == "custom-startup":
        p = repo / ".venv/share/jupyter/kernels/python3/kernel.json"
        spec = json.loads(p.read_text())
        spec["argv"].append("--InteractiveShellApp.exec_lines=[]")
        p.write_text(json.dumps(spec))
    _write(repo, "notebooks/kernel-policy.ipynb", n)
    _stage(repo)
    r = _run(repo)
    assert r.returncode != 0
    assert not any(x["event"] == "execution_context" for x in _events(r))
    expected = {"missing-kernel": "missing prepared candidate kernel",
                "language": "unsupported non-Python notebook",
                "custom-startup": "unsupported custom kernel startup"}
    assert expected[problem] in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")


@pytest.mark.parametrize("change", ["source", "notebook-bytes"])
def test_real_observed_input_race_cannot_be_success(real_repo, change):
    repo, _, _ = real_repo
    path = "../src/__init__.py" if change == "source" else "input-race.ipynb"
    code = ("from pathlib import Path\n"
            f"p=Path({path!r})\n"
            "p.write_bytes(p.read_bytes()+b' ')\n")
    _write(repo, "notebooks/input-race.ipynb", _nb(code))
    _stage(repo)
    before = _index(repo)
    r = _call(["bash", HOOK], repo, hook=HOOK)
    assert r.returncode != 0
    assert _index(repo) == before
    assert ("notebook changed during execution" if change == "notebook-bytes"
            else "unstaged project source/lock divergence") in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")


def test_real_signal_uses_normal_cleanup_and_reports_nonzero(real_repo):
    repo, _, _ = real_repo
    n = _nb("from pathlib import Path\nimport os,time\nPath('signal-kernel-pid.txt').write_text(str(os.getpid()))\ntime.sleep(60)")
    p = _write(repo, "notebooks/signal.ipynb", n)
    _stage(repo)
    before, raw = _index(repo), p.read_bytes()
    argv = ["bash", str(HOOK)]
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    context = _hook_context(HOOK, argv, repo, _env())
    child = subprocess.Popen(argv, cwd=repo, env=_env(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    context["pid"] = child.pid
    witness = repo / "notebooks/signal-kernel-pid.txt"
    deadline = time.monotonic()+60
    try:
        while not witness.exists() and child.poll() is None and time.monotonic()<deadline:
            time.sleep(.1)
        reached = witness.exists()
        kernel_pid = int(witness.read_text()) if reached else None
        if child.poll() is None:
            child.send_signal(signal.SIGTERM)
    finally:
        try:
            out, err = child.communicate(timeout=45)
        except subprocess.TimeoutExpired:
            child.terminate()
            out, err = child.communicate(timeout=30)
        print("NOTEBOOK_FIXTURE_PROCESS " + json.dumps(dict(
            argv=argv,cwd=str(repo),start_utc=started,end_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            pid=child.pid,rc=child.returncode,stdout_base64=base64.b64encode(out).decode(),
            stderr_base64=base64.b64encode(err).decode())),flush=True)
    assert reached, "real kernel did not reach signal witness"
    context["end_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    rows = _events(child=child, streams=(out, err), context=context)
    assert child.returncode != 0 and any("interrupted by signal" in x["error"] for x in rows if x["event"] == "refused")
    with pytest.raises(ProcessLookupError):
        os.kill(kernel_pid,0)
    assert _index(repo)==before and p.read_bytes()==raw


def test_real_pinned_120_second_timeout_is_error_and_kernel_is_gone(real_repo):
    repo, _, _ = real_repo
    _write(repo,"notebooks/timeout.ipynb",_nb(
        "from pathlib import Path\nimport os,time\nPath('timeout-kernel-pid.txt').write_text(str(os.getpid()))\ntime.sleep(130)"))
    _stage(repo)
    r=_run(repo,timeout=240)
    assert r.returncode != 0 and "CellTimeoutError" in r.stderr.decode()
    with pytest.raises(ProcessLookupError):
        os.kill(int((repo/"notebooks/timeout-kernel-pid.txt").read_text()),0)

def test_selected_index_must_belong_to_recovered_administration(cheap_repo, tmp_path):
    data = _index(cheap_repo)
    inside = cheap_repo/".git/fixture-alternate-index"
    outside = tmp_path/"foreign-index"
    for p in (inside,outside):
        p.write_bytes(data)
    for p,ok in ((inside,True),(outside,False)):
        env=_env();env["GIT_INDEX_FILE"]=str(p)
        r=_run(cheap_repo,env=env)
        assert (r.returncode==0)==ok
        if ok:
            assert next(x for x in _events(r) if x["event"]=="admission")["index_path"]==str(p)
        else:
            assert "outside selected Git administration" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")


@pytest.mark.parametrize("kind", ["backlink", "ordinary-symlink"])
def test_broken_or_foreign_reciprocal_identity_refuses(cheap_repo,tmp_path,kind):
    if kind=="backlink":
        linked=tmp_path/"stale-linked"
        _git(cheap_repo,"worktree","add","--detach",str(linked),"HEAD")
        admin=Path((linked/".git").read_text().strip()[8:])
        (admin/"gitdir").write_text(str(tmp_path/"missing-checkout/.git")+"\n")
        env=_env();env["GIT_DIR"]=str(admin)
        r=_call(["bash",HOOK],cheap_repo,env=env,hook=HOOK)
    else:
        foreign=tmp_path/"foreign-working"
        foreign.mkdir();(foreign/".git").symlink_to(cheap_repo/".git",target_is_directory=True)
        r=_call(["bash",HOOK],foreign,hook=HOOK)
    assert r.returncode!=0
    assert not any(x["event"]=="empty" for x in _events(r))


def test_ignored_first_party_module_is_not_unmeasured_source(real_repo):
    repo,_,_=real_repo
    _write(repo,"notebooks/ignored-source.ipynb",_nb("import src.ignored_fixture"))
    with (repo/".gitignore").open("a") as f:
        f.write("\nsrc/ignored_fixture.py\n")
    _stage(repo)
    (repo/"src/ignored_fixture.py").write_text("raise RuntimeError('not admitted')\n")
    r=_run(repo)
    assert r.returncode!=0 and "untracked ignored first-party source" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    assert not any(x["event"]=="execution_context" for x in _events(r))


def test_real_entry_script_movement_cannot_be_success(real_repo):
    repo,_,_=real_repo
    script=repo/"scripts/pre-commit-notebooks.sh"
    script.write_text(HOOK.read_text())
    n=_nb("from pathlib import Path\np=Path('../scripts/pre-commit-notebooks.sh')\np.write_bytes(p.read_bytes()+b'\\n')")
    _write(repo,"notebooks/script-race.ipynb",n)
    _stage(repo)
    before=_index(repo)
    r=_call(["bash",script],repo,hook=script)
    assert r.returncode!=0 and "entry script changed during execution" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    assert _index(repo)==before


def test_real_stat_only_index_movement_is_not_waived_by_equal_entries(real_repo):
    repo,_,_=real_repo
    n=_nb("from pathlib import Path\nimport subprocess,json\np=Path('index-race.ipynb');p.touch()\n"
          "r=subprocess.run(['git','-c','core.fsmonitor=false','update-index','--refresh'],capture_output=True,text=True)\n"
          "Path('refresh-result.json').write_text(json.dumps({'rc':r.returncode,'stdout':r.stdout,'stderr':r.stderr}))\n"
          "assert r.returncode==0, (r.stdout,r.stderr)")
    _write(repo,"notebooks/index-race.ipynb",n)
    _stage(repo)
    before=_index(repo);entries=_git(repo,"ls-files","--stage","-z")
    r=_call(["bash",HOOK],repo,hook=HOOK)
    assert json.loads((repo/"notebooks/refresh-result.json").read_text())["rc"]==0
    assert r.returncode!=0 and "raw active index changed" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    assert _index(repo)!=before and _git(repo,"ls-files","--stage","-z")==entries


def test_real_signal_at_spawn_keeps_owned_job_cleanup_boundary(real_repo):
    repo,_,_=real_repo
    _write(repo,"notebooks/spawn-signal.ipynb",_nb("assert True"))
    script=repo/"scripts/pre-commit-notebooks.sh"
    text=HOOK.read_text()
    old="\n                signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)"
    assert text.count(old)==1
    text=text.replace(old,"\n                if watch: os.kill(os.getpid(), signal.SIGTERM)"+old)
    script.write_text(text);_stage(repo)
    r=_run(repo,script=script)
    assert r.returncode!=0 and "interrupted by signal" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    children=[x for x in _events(r) if x["event"]=="children"]
    assert len(children)==1
    with pytest.raises(ProcessLookupError):
        os.kill(children[0]["command_pid"],0)

def test_real_normal_cargo_generated_source_is_not_first_party_input(real_repo):
    repo,_,_=real_repo
    generated=repo/"rust/target/fixture-build/out/generated.rs"
    generated.parent.mkdir(parents=True,exist_ok=True)
    generated.write_text("// generated Cargo dependency output, not imported first-party Python\n")
    _write(repo,"notebooks/cargo-output.ipynb",_nb(_witness(repo)))
    _stage(repo)
    # Normal .gitignore must leave the generated build output outside the index.
    assert b"rust/target/fixture-build/out/generated.rs" not in _git(repo,"ls-files","-z").split(b"\0")
    r=_run(repo)
    assert r.returncode==0, r.stdout.decode()+r.stderr.decode()
    assert (repo/"notebooks/execution-count.txt").read_text()=="1"
    assert _events(r)[-2]["event"]=="success"


def _relative_index_value(env,entry,selected):
    # Observe the ORIGINAL caller setup, with no hook/target overrides. A bare
    # basename reveals Git's actual relative-index base in this context; neither
    # ENTRY nor the selected worktree is guessed to be that base. This query
    # does not create/open a substitute index or search for an assertion bypass.
    probe="fixture-relative-index-base-probe"
    context=dict(env,GIT_INDEX_FILE=probe)
    r=_call(["git","--no-pager","-c","core.fsmonitor=false","rev-parse",
             "--path-format=absolute","--git-path","index"],entry,env=context)
    assert r.returncode==0,r.stderr.decode(errors="replace")
    observed=Path(os.fsdecode(r.stdout.removesuffix(b"\n")))
    assert observed.is_absolute() and observed.name==probe
    return os.path.relpath(selected,observed.parent)


@pytest.mark.parametrize("linked", [False,True])
@pytest.mark.parametrize("relative", [False,True])
def test_complete_population_from_subdirectory_refuses_only_missing_runtime(cheap_repo,tmp_path,linked,relative):
    repo=cheap_repo
    if linked:
        repo=tmp_path/"linked population"
        _git(cheap_repo,"worktree","add","--detach",str(repo),"HEAD")
    _write(repo,"outside.ipynb",_nb())
    _write(repo,"nested/inside.ipynb",_nb())
    _stage(repo)
    _git(repo,"config","diff.relative",str(relative).lower())
    entry=repo/"nested"
    admin=repo/".git" if not linked else Path((repo/".git").read_text().strip()[8:])
    selected=admin/"root-population-index"
    selected.write_bytes(_index(repo))
    env=_env();env["GIT_INDEX_FILE"]=_relative_index_value(env,entry,selected)
    selected_query=_call(["git","--no-pager","-c","core.fsmonitor=false","rev-parse","--path-format=absolute","--git-path","index"],entry,env=env)
    assert selected_query.returncode==0 and Path(selected_query.stdout.decode().strip())==selected
    before=selected.read_bytes()
    r=_run(repo,cwd=entry,env=env)
    admission=next(x for x in _events(r) if x["event"]=="admission")
    assert set(admission["eligible_notebooks"])=={"outside.ipynb","nested/inside.ipynb"}
    assert r.returncode==2 and "missing ordinary candidate .venv" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    assert selected.read_bytes()==before
    assert not any(x["event"]=="empty" for x in _events(r))


@pytest.mark.parametrize("kind", ["tracked","untracked","ignored"])
def test_source_populations_outside_entry_are_not_omitted(cheap_repo,kind):
    _write(cheap_repo,"nested/inside.ipynb",_nb())
    if kind=="ignored":
        (cheap_repo/".gitignore").write_text("src/ignored-outside.py\n")
    _stage(cheap_repo)
    if kind=="tracked":
        (cheap_repo/"src/__init__.py").write_text("# unstaged outside entry\n")
        reason="unstaged project source/lock divergence"
    else:
        (cheap_repo/("src/ignored-outside.py" if kind=="ignored" else "src/untracked-outside.py")).write_text("raise RuntimeError('outside entry')\n")
        reason="untracked ignored first-party source" if kind=="ignored" else "untracked importable source"
    r=_run(cheap_repo,cwd=cheap_repo/"nested")
    assert r.returncode==2 and reason in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    assert "missing ordinary candidate .venv" not in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")


@pytest.mark.parametrize("route", ["primary","linked","common-relative","common-absolute"])
def test_real_root_coordinate_population_with_relative_diff_and_poison(real_repo,route):
    primary,linked,_=real_repo
    repo=primary if route=="primary" else linked
    _write(repo,"outside.ipynb",_nb("from pathlib import Path\nPath('outside-executed.txt').write_text('once')"))
    _write(repo,"nested/inside.ipynb",_nb("from pathlib import Path\nPath('inside-executed.txt').write_text('once')"))
    _stage(repo);_git(repo,"config","diff.relative","true")
    env=_env();entry=repo/"nested";selected=None
    if route.startswith("common"):
        entry=primary/"manual-entry";entry.mkdir(exist_ok=True)
        admin=Path((linked/".git").read_text().strip()[8:])
        env["GIT_DIR"]=os.path.relpath(admin,entry) if route=="common-relative" else str(admin)
        selected=admin/"root-coordinate-index";selected.write_bytes(_index(repo))
        env["GIT_WORK_TREE"]=str(repo)
        env["GIT_INDEX_FILE"]=_relative_index_value(env,entry,selected)
        selected_query=_call(["git","--no-pager","-c","core.fsmonitor=false","rev-parse","--path-format=absolute","--git-path","index"],entry,env=env)
        assert selected_query.returncode==0 and Path(selected_query.stdout.decode().strip())==selected
        selected_before=selected.read_bytes()
    try:
        r=_run(repo,cwd=entry,env=env)
        assert r.returncode==0,r.stdout.decode()+r.stderr.decode()
        assert set(_events(r)[-2]["executed_notebooks"])=={"outside.ipynb","nested/inside.ipynb"}
        assert (repo/"outside-executed.txt").read_text()=="once"
        assert (repo/"nested/inside-executed.txt").read_text()=="once"
        if selected is not None:
            assert selected.read_bytes()==selected_before
        _write(repo,"outside.ipynb",_nb("raise ValueError('ROOT_COORDINATE_POISON')"));_stage(repo)
        if selected is not None:
            selected.write_bytes(_index(repo));selected_before=selected.read_bytes()
        r=_run(repo,cwd=entry,env=env)
        assert r.returncode!=0 and "ROOT_COORDINATE_POISON" in r.stderr.decode()
        assert "CellExecutionError" in r.stderr.decode()
        assert not any(x["event"]=="empty" for x in _events(r))
        if selected is not None:
            assert selected.read_bytes()==selected_before
    finally:
        _git(repo,"config","--unset","diff.relative")


def test_real_no_index_movement_positive_control(real_repo):
    repo,_,_=real_repo
    _write(repo,"notebooks/no-index-movement.ipynb",_nb("assert True"));_stage(repo)
    before=_index(repo);entries=_git(repo,"ls-files","--stage","-z")
    r=_run(repo)
    assert r.returncode==0,r.stdout.decode()+r.stderr.decode()
    assert _index(repo)==before and _git(repo,"ls-files","--stage","-z")==entries
    assert _events(r)[-2]["event"]=="success"


# Lifecycle fixtures below create only their own explicit Popen jobs. Fresh
# PID/birth/command identities guard fixture cleanup as well as production checks.
def _pid_identity(pid,repo):
    r=_call(["/bin/ps","-ww","-p",str(pid),"-o","pid=,lstart=,command="],repo)
    if r.returncode or not r.stdout.strip():
        return None
    fields=r.stdout.decode().strip().split(None,6)
    assert len(fields)==7 and int(fields[0])==pid
    return {"pid":pid,"birth":fields[1:6],"command":fields[6]}


def _stop_fixture(identity,repo):
    if identity and _pid_identity(identity["pid"],repo)==identity:
        try:
            os.kill(identity["pid"],signal.SIGKILL)
        except ProcessLookupError:
            pass


def _assert_absent(pid):
    deadline=time.monotonic()+5
    while time.monotonic()<deadline:
        try:
            os.kill(pid,0)
        except ProcessLookupError:
            return
        time.sleep(.1)
    pytest.fail("owned fixture child still has a process identity: "+str(pid))


# Local observations for the existing fixture owners; no process or SAME authority.
_H94_UNOBSERVED = object()


def _h94_freeze_value(value):
    """Copy observed native data without repr, polling or reading a capability."""
    if value is _H94_UNOBSERVED:
        return dict(state="unobserved", value=None)
    if type(value) is bytes:
        return dict(state="observed", type="bytes", bytes=len(value),
                    sha256=hashlib.sha256(value).hexdigest(), base64=base64.b64encode(value).decode())
    if value is None or type(value) in (bool, int, float, str):
        return dict(state="observed", type=type(value).__name__, value=value)
    if type(value) in (list, tuple):
        return dict(state="observed", type=type(value).__name__, items=[_h94_freeze_value(x) for x in value])
    if type(value) is dict:
        return dict(state="observed", type="dict", items=[[_h94_freeze_value(k), _h94_freeze_value(v)] for k,v in value.items()])
    return dict(state="observed", type=type(value).__module__+"."+type(value).__qualname__,
                value=None, unsupported=True)


def _h94_emit(receipt):
    print("NOTEBOOK_FIXTURE_RECEIPT "+json.dumps(receipt, separators=(",", ":")), flush=True)


class _H94FixtureCapture:
    """First escaping fixture fault, separate from original handled producer data."""
    def __init__(self, label):
        self.label=label;self.first=None;self.faults=[];self.cleanup=[];self.callbacks=[]
        self.finishes=[];self.producer=[];self.precleanup=None;self.optional_snapshot=None
        self.context=_H94_UNOBSERVED;self.observer_faults=[]
        self.outer_exited=False;self.stack_empty_after_close=False;self.receipt_retained=False;self.receipt=None

    def fault(self, operation, error):
        # Reserve actual identity/TB/time BEFORE formatting, callbacks or diagnostic IO.
        row=dict(operation=operation, object=error, traceback=error.__traceback__,
                 observed=time.monotonic(), arguments=BaseException.args.__get__(error))
        if self.first is None:self.first=row
        self.faults.append(row)
        return row

    def attempt(self, operation, function, *args, **kwargs):
        row=dict(operation=operation, entered=time.monotonic(), outcome="entered")
        self.cleanup.append(row)
        try:
            result=function(*args, **kwargs)
        except BaseException as error:
            fault=self.fault(operation,error)
            row.update(outcome="raised", fault_index=len(self.faults)-1, ended=fault["observed"])
            return _H94_UNOBSERVED
        row.update(outcome="returned", ended=time.monotonic())
        return result

    def register(self, resources, actions):
        """Adopt all acquired pair capabilities before any registration can fail."""
        rows=[dict(function=fn,args=args,state="acquired",calls=0,ordinal=len(self.callbacks)+n) for n,(fn,args) in enumerate(actions)]
        self.callbacks.extend(rows)
        def guarded(row):
            row["calls"]+=1;row["state"]="entered"
            self.attempt("callback:"+str(row["ordinal"]), row["function"], *row["args"])
            row["state"]="finished"
        for row in rows:
            def registered_guard(row=row):guarded(row)
            try:
                resources.callback(registered_guard)
                row["state"]="registered"
            except BaseException as error:
                self.fault("callback-registration",error)
                # callback() may have appended this exact guard before raising.
                if any(getattr(entry[1],"__wrapped__",None) is registered_guard for entry in resources._exit_callbacks):
                    row["state"]="registered"
                # Already registered rows remain on the original stack; never close twice.
                for unregistered in reversed(rows):
                    if unregistered["state"]=="acquired":guarded(unregistered)
                raise

    def finish(self, owner, incoming, label):
        row=dict(owner_id=id(owner),label=label,state="entered",incoming=incoming,
                 entered=time.monotonic())
        self.finishes.append(row)
        try:returned=owner.finish(incoming)
        except BaseException as error:
            self.fault("finish:"+label,error);row.update(state="raised",error=error)
            raise
        row.update(state="returned",returned=returned,ended=time.monotonic())
        return returned

    def producer_observed(self, owner, phase):
        # Preserve current producer facts before its original finish resets deadline.
        self.producer.append(dict(phase=phase,owner_id=id(owner),
            object_ids=[id(x) for x in owner.fault_objects],
            faults=_h94_freeze_value(owner.faults),
            deadline=_h94_freeze_value(owner.deadline),
            cleanup_deadline=_h94_freeze_value(getattr(owner,"command_cleanup_deadline",_H94_UNOBSERVED))))

    def freeze(self, facts):
        try:self.precleanup=_h94_freeze_value(facts)
        except BaseException as error:self.fault("capture-precleanup",error)

    def close_stack(self, resources):
        self.attempt("original-exitstack-close",resources.close)
        self.stack_empty_after_close=not resources._exit_callbacks

    def emit(self):
        def fault_data(row):
            return dict(operation=row["operation"], object_id=id(row["object"]),
                type=type(row["object"]).__module__+"."+type(row["object"]).__qualname__,
                arguments=_h94_freeze_value(row["arguments"]), observed=row["observed"],
                traceback=[dict(filename=tb.tb_frame.f_code.co_filename,
                    function=tb.tb_frame.f_code.co_name,line=tb.tb_lineno) for tb in self._trace(row["traceback"])])
        try:
            self.receipt=dict(label=self.label,precleanup=self.precleanup,producer=self.producer,
                finishes=[dict(owner_id=x["owner_id"],label=x["label"],state=x["state"],
                    incoming_id=id(x["incoming"]) if x["incoming"] is not None else None,
                    returned_id=id(x["returned"]) if x.get("returned") is not None else None,
                    error_id=id(x["error"]) if "error" in x else None) for x in self.finishes],
                faults=[fault_data(x) for x in self.faults],cleanup=list(self.cleanup),
                callbacks=[dict(state=x["state"],calls=x["calls"],function=getattr(x["function"],"__name__",None),
                    args=_h94_freeze_value(x["args"])) for x in self.callbacks],
                optional_snapshot=self.optional_snapshot,outer_exited=self.outer_exited,
                first_object_id=id(self.first["object"]) if self.first else None)
            _h94_emit(self.receipt)
            self.receipt_retained=True
        except BaseException as error:self.fault("final-receipt-emission",error)

    @staticmethod
    def _trace(tb):
        while tb is not None:
            yield tb;tb=tb.tb_next

    def propagate(self):
        if self.first is not None:
            raise self.first["object"].with_traceback(self.first["traceback"])


def _h94_owned_writer_snapshot(capture, writer, deadline, existing_final, still_owned):
    """One cooperative query under the existing real caller deadline, never a new budget."""
    row=dict(attempted=False,reason=None,started=None,ended=None,remaining_before=None,
             remaining_after=None,value=None,error_id=None,overrun=False)
    capture.optional_snapshot=row
    if existing_final is not _H94_UNOBSERVED:row["reason"]="original-final-observed";return
    if not still_owned or writer is None:row["reason"]="no-owned-writer";return
    if deadline is None:row["reason"]="deadline-unestablished";return
    began=time.monotonic();row["remaining_before"]=deadline-began
    if began>=deadline:row["reason"]="original-deadline-exhausted";return
    row.update(attempted=True,started=began)
    try:row["value"]=_h94_freeze_value(_r36_native_snapshot(writer))
    except BaseException as error:
        capture.fault("optional-owned-writer-snapshot",error);row["error_id"]=id(error)
    finally:
        ended=time.monotonic();row.update(ended=ended,remaining_after=deadline-ended,overrun=ended>deadline)


def _observe_real_hook_child(repo,script,*,interrupt=False):
    capture=_H94FixtureCapture("real-hook-pipe-observer")
    argv=["bash",str(script)];child=None;known=[];observed={};witness_observations=[]
    out=err=_H94_UNOBSERVED;communications=[];reached=False;completed=False;answer=None
    start=dt.datetime.now(dt.timezone.utc).isoformat();tick=time.monotonic()
    try:
        before=_index(repo)
        notebooks={p:p.read_bytes() for p in repo.rglob("*.ipynb") if ".venv" not in p.parts}
        context=_hook_context(script,argv,repo,_env())
        child=subprocess.Popen(argv,cwd=repo,env=_env(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        context["pid"]=child.pid
        deadline=time.monotonic()+50
        files=[repo/"notebooks/ordinary-child-pid.txt",repo/"notebooks/engine-kernel-pid.txt"]
        while child.poll() is None and time.monotonic()<deadline:
            for path in files:
                row=dict(path=str(path),exists=_H94_UNOBSERVED,raw=_H94_UNOBSERVED,identity=_H94_UNOBSERVED)
                witness_observations.append(row)
                row["exists"]=path.exists()
                if row["exists"] and path not in observed:
                    row["raw"]=path.read_text()
                    identity=_pid_identity(int(row["raw"]),repo);row["identity"]=identity
                    if identity is not None:
                        observed[path]=identity
                        known=[observed[entry] for entry in files if entry in observed]
            known=[observed[path] for path in files if path in observed]
            reached=len(known)==len(files)
            if reached:break
            time.sleep(.05)
        if interrupt and reached:
            time.sleep(.5)  # Let the actual hook's finite polling observe lineage.
            child.send_signal(signal.SIGTERM)
        communication=dict(outcome="entered",timeout=70,stdout=_H94_UNOBSERVED,stderr=_H94_UNOBSERVED)
        communications.append(communication)
        try:
            out,err=child.communicate(timeout=70)
            communication.update(outcome="returned",stdout=out,stderr=err)
        except subprocess.TimeoutExpired as error:
            communication.update(outcome="TimeoutExpired",stdout=error.output,stderr=error.stderr)
            out,err=error.output or b"",error.stderr or b""
            child.terminate()
            communication=dict(outcome="entered",timeout=35,stdout=_H94_UNOBSERVED,stderr=_H94_UNOBSERVED)
            communications.append(communication)
            try:
                out,err=child.communicate(timeout=35)
                communication.update(outcome="returned",stdout=out,stderr=err)
            except subprocess.TimeoutExpired as error:
                communication.update(outcome="TimeoutExpired",stdout=error.output,stderr=error.stderr)
                out,err=error.output or out,error.stderr or err
                child.kill()
                communication=dict(outcome="entered",timeout=5,stdout=_H94_UNOBSERVED,stderr=_H94_UNOBSERVED)
                communications.append(communication)
                try:
                    out,err=child.communicate(timeout=5)
                    communication.update(outcome="returned",stdout=out,stderr=err)
                except subprocess.TimeoutExpired as error:
                    communication.update(outcome="TimeoutExpired",stdout=error.output,stderr=error.stderr)
                    out,err=error.output or out,error.stderr or err
                    capture.attempt("timeout-stdout-close",child.stdout.close)
                    capture.attempt("timeout-stderr-close",child.stderr.close)
                    capture.attempt("timeout-child-wait",child.wait,timeout=5)
            pytest.fail("actual hook exceeded bounded lifecycle; original channels are retained")
        assert reached, "actual engine/child witnesses not reached"
        assert time.monotonic()-tick<65
        assert _index(repo)==before
        assert all(p.read_bytes()==raw for p,raw in notebooks.items())
        result=subprocess.CompletedProcess(argv,child.returncode,out,err)
        context["end_utc"]=dt.datetime.now(dt.timezone.utc).isoformat()
        result.hook_context=context
        _events(result)
        completed=True
        answer=result,known
    except BaseException as error:capture.fault("pipe-observer-body",error)
    finally:
        capture.attempt("precleanup-freeze",lambda: capture.freeze(dict(argv=argv,cwd=str(repo),start_utc=start,
            pid=_H94_UNOBSERVED if child is None else child.pid,
            stored_returncode=_H94_UNOBSERVED if child is None else child.returncode,
            stdout=out,stderr=err,communications=communications,
            witness_observations=witness_observations,known=known,reached=reached)))
        # Only original Popen and already known identity capabilities, independently guarded.
        if child is not None:
            running=capture.attempt("original-child-poll",child.poll)
            if running is None:
                capture.attempt("original-child-kill",child.kill)
                capture.attempt("original-child-wait",child.wait,timeout=5)
        if not completed:
            for identity in known:capture.attempt("original-known-witness",_stop_fixture,identity,repo)
        capture.outer_exited=True
    capture.emit()
    capture.propagate()
    return answer

def _child_program():
    return "import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(600)"


@pytest.mark.parametrize("ending", ["normal","poison","signal"])
def test_real_detached_ordinary_stubborn_child_is_owned_and_bounded(real_repo,ending):
    repo,_,_=real_repo
    program=_child_program();marker=str(repo/"ordinary-child-unique-marker")
    same_argv=[str(repo/".venv/bin/python"),"-c",program,marker]
    unrelated=subprocess.Popen(same_argv,cwd=repo,env=_env(),stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
    known=[]
    try:
        code=("from pathlib import Path\nimport os,sys,subprocess,time\n"
              "Path('engine-kernel-pid.txt').write_text(str(os.getpid()))\n"
              "p=Path('lifecycle-run-count.txt');p.write_text(str(int(p.read_text())+1 if p.exists() else 1))\n"
              "c=subprocess.Popen([sys.executable,'-c',"+repr(program)+","+repr(marker)+"],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)\n"
              "Path('ordinary-child-pid.txt').write_text(str(c.pid))\ntime.sleep(2)\n")
        if ending=="poison":code+="raise ValueError('OWNED_CHILD_ORIGINAL_ERROR')\n"
        if ending=="signal":code+="time.sleep(60)\n"
        _write(repo,"notebooks/owned-child.ipynb",_nb(code));_stage(repo)
        r,known=_observe_real_hook_child(repo,HOOK,interrupt=ending=="signal")
        assert r.returncode==2 and not any(x["event"]=="success" for x in _events(r))
        failures=[x for x in _events(r) if x["event"]=="command_failure"]
        assert len(failures)==1
        if ending=="poison":assert "CellExecutionError" in r.stderr.decode() and "OWNED_CHILD_ORIGINAL_ERROR" in r.stderr.decode()
        if ending=="signal":assert "interrupted by signal" in failures[0]["reason"]
        receipt=next(x for x in _events(r) if x["event"]=="children")
        pid=known[0]["pid"]
        assert str(pid) in receipt["descendants"]
        assert "kernel.json" not in "".join(receipt["descendants"][str(pid)]["command"])
        assert receipt["remaining_observed_live"]==[] and receipt["drain_complete"]
        assert any(x["pid"]==pid and x["signal"]==int(signal.SIGKILL) for x in receipt["signals"])
        assert all(x["pid"]!=unrelated.pid for x in receipt["signals"])
        assert unrelated.poll() is None
        assert (repo/"notebooks/lifecycle-run-count.txt").read_text()=="1"
        _assert_absent(pid)
    finally:
        for identity in known:
            _stop_fixture(identity,repo)
        unrelated.kill();unrelated.wait(timeout=5)


@pytest.mark.parametrize("poison", [False,True])
def test_real_exited_cli_with_inherited_pipe_holder_has_finite_drain(real_repo,poison):
    repo,_,_=real_repo
    marker=str(repo/"pipe-companion-unique-marker")
    # Test-only companion instrumentation. Exec preserves the actual CLI PID and
    # exact original nbconvert argv; no executor/result is stubbed or substituted.
    launcher=("import os,sys,json,subprocess,time\nfrom pathlib import Path\n"
              "argv=json.loads(sys.argv[1])\n"
              "c=subprocess.Popen([sys.executable,'-c',"+repr(_child_program())+","+repr(marker)+"],stdin=subprocess.DEVNULL,start_new_session=True)\n"
              "Path('ordinary-child-pid.txt').write_text(str(c.pid))\n"
              "print('PIPE_COMPANION_ORIGINAL_SENTINEL',file=sys.stderr,flush=True)\n"
              "time.sleep(1)\nos.execv(argv[0],argv)\n")
    script=repo/"scripts/pipe-lifecycle-hook.sh"
    text=HOOK.read_text();old="        signal_checkpoint()\n        started = time.monotonic()\n"
    assert text.count(old)==1
    replacement="        signal_checkpoint()\n        if watch: argv=[argv[0],'-B','-c',"+repr(launcher)+",json.dumps(argv)]\n        started = time.monotonic()\n"
    text=text.replace(old,replacement)
    script.write_text(text)
    code=("from pathlib import Path\nimport os,time\n"
          "Path('engine-kernel-pid.txt').write_text(str(os.getpid()))\n"
          "p=Path('pipe-run-count.txt');p.write_text(str(int(p.read_text())+1 if p.exists() else 1))\n"
          "time.sleep(1)\n")
    if poison:code+="raise ValueError('PIPE_ORIGINAL_ENGINE_ERROR')\n"
    _write(repo,"notebooks/pipe-holder.ipynb",_nb(code));_stage(repo)
    known=[]
    try:
        r,known=_observe_real_hook_child(repo,script)
        assert r.returncode==2
        failures=[x for x in _events(r) if x["event"]=="command_failure"]
        assert len(failures)==1 and "inherited pipes remain open" in failures[0]["reason"]
        assert failures[0]["initial_returncode"]==(1 if poison else 0)
        assert r.stderr.count(b"PIPE_COMPANION_ORIGINAL_SENTINEL")==1
        if poison:assert b"CellExecutionError" in r.stderr and b"PIPE_ORIGINAL_ENGINE_ERROR" in r.stderr
        receipt=next(x for x in _events(r) if x["event"]=="children")
        assert receipt["remaining_observed_live"]==[] and receipt["drain_complete"]
        assert (repo/"notebooks/pipe-run-count.txt").read_text()=="1"
        _assert_absent(known[0]["pid"])
    finally:
        for identity in known:
            _stop_fixture(identity,repo)


def test_literal_pathspec_environment_cannot_hide_root_population(cheap_repo):
    _write(cheap_repo,"outside-literal.ipynb",_nb());_stage(cheap_repo)
    entry=cheap_repo/"nested-entry";entry.mkdir()
    env=_env();env["GIT_LITERAL_PATHSPECS"]="1"
    r=_run(cheap_repo,cwd=entry,env=env)
    assert r.returncode==2 and "missing ordinary candidate .venv" in "\n".join(x["error"] for x in _events(r) if x["event"] == "refused")
    assert next(x for x in _events(r) if x["event"]=="admission")["eligible_notebooks"]==["outside-literal.ipynb"]


def _source_observer(samples):
    """Exercise actual stdlib observer helpers, never the hook/CLI/kernel.

    Explicit process-table samples and a finite deterministic clock stand in for
    observation, not execution. Signal attempts are recorded without OS signals.
    No production absence or notebook-runtime result follows from these tests.
    """
    import ast
    import copy
    from types import SimpleNamespace

    tree = ast.parse(HOOK.read_text().split("<<'PY'\n", 1)[1].rsplit("\nPY", 1)[0])
    definitions = {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    original_run = definitions["run"]
    helpers = {n.name: n for n in original_run.body if isinstance(n, ast.FunctionDef)}
    calls, killed, clock = [], [], SimpleNamespace(value=0.0)

    def process_rows(deadline=None):
        item = samples.pop(0) if len(samples) > 1 else samples[0]
        calls.append(item)
        if isinstance(item, BaseException):
            raise item
        return item

    def advance(seconds):
        clock.value += seconds

    first_helper = next(i for i,n in enumerate(original_run.body) if isinstance(n,ast.FunctionDef))
    setup = ast.parse("def observer(argv=(), cwd='/INERT', env=None, timeout=60):\n    pass\n").body[0]
    setup.body = copy.deepcopy(original_run.body[:first_helper])
    setup.body += ast.parse("p = SimpleNamespace(pid=1, returncode=None)").body
    setup.body += [copy.deepcopy(helpers[n]) for n in
                   ("phase", "checkpoint", "remember", "observe", "reconcile_identity", "live", "cleanup_observe", "signal_descendants")]
    setup.body += ast.parse("""
return dict(observe=observe, reconcile=reconcile_identity, live=live,
            cleanup_observe=cleanup_observe, signal=signal_descendants,
            owned=owned, pending=identity_pending, transitions=identity_transitions,
            resolutions=identity_resolutions, errors=observation_errors, signals=signals)
""").body
    module = ast.Module(body=[copy.deepcopy(definitions[n]) for n in
        ("Refusal", "require", "check_time", "error_text", "typed_native", "Evidence", "same_process", "signal_checkpoint", "cause_order")]
                            + [setup], type_ignores=[])
    import struct
    import itertools
    namespace = dict(process_rows=process_rows, SimpleNamespace=SimpleNamespace,
                     os=SimpleNamespace(kill=lambda pid, signum: killed.append((pid, signum))),
                     time=SimpleNamespace(monotonic=lambda: clock.value, sleep=advance),
                     dt=dt, struct=struct, CAUSE_SEQUENCE=itertools.count(1), SIGNAL_CAUSE_ORDERS={},
                     SIGNAL_EVENTS=[], SIGNAL_CURSOR=0, INVOCATION_PHASE="source-observer")
    exec(compile(ast.fix_missing_locations(module), str(HOOK) + ":observer-only", "exec"), namespace)
    # Explicitly incomplete memory owner: no private-file/native persistence claim.
    owner = namespace["Evidence"].__new__(namespace["Evidence"])
    owner.command_sequence=0; owner.command_id=None; owner.phase="inert-source-observer"; owner.deadline=None
    owner.faults=[]; owner.fault_objects=[]; owner.fault_records=[]; owner.first_fault_id=None
    owner.events=None; owner.closed=False
    namespace["EVIDENCE"]=owner
    observer=namespace["observer"]()
    observer["fault_owner"]=owner
    return observer, calls, killed, clock


def _observer_row(command="owned child", *, parent=1, birth="original", state="Rs"):
    return dict(ppid=parent, pgid=10, birth=[birth], state=state,
                command=tuple(command[i:i+512] for i in range(0,len(command),512)))


def _observer_table(child, **other):
    return {1: _observer_row("controller", parent=0), 10: child,
            **{int(pid): row for pid, row in other.items()}}


@pytest.mark.parametrize("command", ["different executable", "(python3.14)"])
def test_source_observer_command_transition_requires_actual_absence(command):
    original, changed = _observer_row(), _observer_row(command)
    empty = {1: _observer_row("controller", parent=0)}
    observer, calls, killed, clock = _source_observer(
        [_observer_table(original), _observer_table(changed), empty])
    observer["observe"]()
    rows = observer["observe"]()
    assert observer["live"](rows) == [] and observer["pending"] == {10: changed}
    rows = observer["reconcile"](rows)
    assert 10 not in rows and observer["pending"] == {} and not killed
    assert observer["transitions"] == [dict(pid=10, sample=2,
        original_identity=original, observed_identity=changed)]
    assert observer["resolutions"] == [dict(pid=10, sample=3,
        reason="PID absent from actual process observation", last_uncertain_identity=changed)]
    assert len(calls) == 3 and 0 < clock.value < 2 and not observer["errors"]


@pytest.mark.parametrize("change", ["command", "parenthesized-command", "birth", "zombie-command"])
def test_source_observer_live_or_reused_identity_is_not_empty_absence(change):
    original = _observer_row()
    changed = _observer_row("different executable" if change == "command" else
                            "(python3.14)" if change in ("parenthesized-command", "zombie-command") else
                            "owned child", birth="reused" if change == "birth" else "original",
                            state="Z" if change == "zombie-command" else "Rs")
    table = _observer_table(changed, **{"20": _observer_row("untrusted grandchild", parent=10)})
    observer, calls, killed, clock = _source_observer([_observer_table(original), table])
    observer["observe"]()
    rows = observer["reconcile"](observer["observe"]())
    assert observer["live"](rows) == [] and observer["pending"] == {10: changed}
    assert set(observer["owned"]) == {10} and observer["resolutions"] == []
    assert clock.value == pytest.approx(2) and len(calls) > 2
    previous_calls = len(calls)
    observer["reconcile"](rows)
    assert len(calls) == previous_calls and clock.value == pytest.approx(2)
    observer["signal"](signal.SIGTERM)
    assert not killed and not observer["signals"] and observer["pending"]


def test_source_observer_restored_command_does_not_discharge_pending_transition():
    original, changed = _observer_row(), _observer_row("different executable")
    restored = _observer_table(original, **{"20": _observer_row("untrusted new child", parent=10)})
    observer, _, killed, _ = _source_observer(
        [_observer_table(original), _observer_table(changed), restored])
    observer["observe"](); observer["observe"](); observer["observe"]()
    assert observer["pending"] == {10: changed} and observer["resolutions"] == []
    assert set(observer["owned"]) == {10} and not killed


def test_source_observer_safe_matched_lineage_signals_exclude_unrelated_same_command():
    original = _observer_row()
    table = _observer_table(original, **{"11": _observer_row(parent=0),
                                        "20": _observer_row("observed grandchild", parent=10)})
    observer, _, killed, _ = _source_observer([table])
    observer["observe"](); observer["signal"](signal.SIGTERM)
    assert set(observer["owned"]) == {10, 20} and observer["pending"] == {}
    assert set(killed) == {(10, signal.SIGTERM), (20, signal.SIGTERM)}
    assert {x["pid"] for x in observer["signals"]} == {10, 20}
    assert all(x["identity"] == table[x["pid"]] for x in observer["signals"])


def test_source_observer_observation_failure_cannot_resolve_identity():
    original, changed = _observer_row(), _observer_row("different executable")
    observer, _, killed, _ = _source_observer(
        [_observer_table(original), _observer_table(changed), OSError("OBSERVATION_UNAVAILABLE")])
    observer["observe"](); observer["observe"]()
    assert observer["cleanup_observe"]() is None
    assert observer["pending"] == {10: changed} and observer["resolutions"] == []
    observer["signal"](signal.SIGTERM)
    assert not killed and observer["errors"] == ["process observation: OBSERVATION_UNAVAILABLE"] * 2
    assert [x["arguments"] for x in observer["fault_owner"].faults] == [dict(type="tuple", items=[dict(type="str",value="OBSERVATION_UNAVAILABLE",complete=True)],complete=True)]
    assert not observer["fault_owner"].faults[0]["persisted"]


def test_source_observer_later_pid_reuse_reopens_uncertainty_after_real_absence():
    original, changed, reused = _observer_row(), _observer_row("changed"), _observer_row(birth="reused")
    observer, _, killed, _ = _source_observer([_observer_table(original), _observer_table(changed),
        {1: _observer_row("controller", parent=0)}, _observer_table(reused)])
    observer["observe"](); observer["observe"](); observer["observe"]()
    assert observer["pending"] == {} and len(observer["resolutions"]) == 1
    observer["observe"](); observer["signal"](signal.SIGTERM)
    assert observer["pending"] == {10: reused} and len(observer["transitions"]) == 2
    assert len(observer["resolutions"]) == 1 and not killed


@pytest.mark.parametrize("exhaust_window", [False, True])
@pytest.mark.parametrize("select_pid", [False, True])
def test_source_pending_restored_identity_blocks_both_signals(exhaust_window, select_pid):
    original, changed = _observer_row(), _observer_row("different executable")
    restored = _observer_table(original, **{"20": _observer_row("untrusted child", parent=10)})
    observer, calls, killed, clock = _source_observer(
        [_observer_table(original), _observer_table(changed), restored])
    observer["observe"](); observer["observe"]()
    rows = observer["observe"]()
    assert observer["live"](rows) == [10] and observer["pending"] == {10: changed}
    if exhaust_window:
        observer["reconcile"](rows)
    assert clock.value == pytest.approx(2 if exhaust_window else 0)
    previous_calls = len(calls)
    for signum in (signal.SIGTERM, signal.SIGKILL):
        observer["signal"](signum, {10} if select_pid else None)
    assert len(calls) == previous_calls + 2  # Both actual helpers refresh observation.
    assert killed == [] and observer["signals"] == []
    assert set(observer["owned"]) == {10} and observer["pending"] == {10: changed}
    assert len(observer["transitions"]) == 1 and observer["resolutions"] == []
    assert clock.value == pytest.approx(2 if exhaust_window else 0)


@pytest.mark.parametrize("kind", ["changed", "reused", "zombie", "unknown"])
def test_source_pending_unsafe_identity_blocks_term_and_kill(kind):
    original = _observer_row()
    changed = _observer_row("owned child" if kind == "reused" else "changed",
                            birth="reused" if kind == "reused" else "original",
                            state="Z" if kind == "zombie" else "Rs")
    samples = [_observer_table(original), _observer_table(changed)]
    if kind == "unknown":
        samples.append(OSError("PENDING_IDENTITY_OBSERVATION_UNAVAILABLE"))
    observer, _, killed, _ = _source_observer(samples)
    observer["observe"](); observer["observe"]()
    for signum in (signal.SIGTERM, signal.SIGKILL):
        observer["signal"](signum)
    assert not killed and not observer["signals"]
    assert observer["pending"] == {10: changed} and observer["resolutions"] == []
    if kind == "unknown":
        assert observer["errors"] == ["process observation: PENDING_IDENTITY_OBSERVATION_UNAVAILABLE"] * 2
        assert [x["operation"] for x in observer["fault_owner"].faults] == ["process observation"]
        assert observer["fault_owner"].faults[0]["arguments"] == dict(type="tuple",items=[dict(type="str",value="PENDING_IDENTITY_OBSERVATION_UNAVAILABLE",complete=True)],complete=True)
    else:
        assert observer["errors"] == []


def test_source_true_absence_preserves_history_and_fresh_owned_signal_admission():
    original, changed = _observer_row(), _observer_row("changed")
    empty = {1: _observer_row("controller", parent=0)}
    fresh = dict(empty)
    fresh.update({30: _observer_row("new owned child"), 11: _observer_row(parent=0)})
    observer, _, killed, _ = _source_observer(
        [_observer_table(original), _observer_table(changed), empty, fresh])
    observer["observe"](); observer["observe"](); observer["observe"]()
    assert not observer["pending"] and len(observer["resolutions"]) == 1
    observer["observe"]()
    for signum in (signal.SIGTERM, signal.SIGKILL):
        observer["signal"](signum)
    assert killed == [(30, signal.SIGTERM), (30, signal.SIGKILL)]
    assert not observer["pending"] and len(observer["transitions"]) == 1
    assert len(observer["resolutions"]) == 1 and set(observer["owned"]) == {10, 30}
    assert {row["pid"] for row in observer["signals"]} == {30}


def test_source_reuse_after_true_absence_blocks_both_signal_kinds():
    original, changed, reused = _observer_row(), _observer_row("changed"), _observer_row(birth="reused")
    observer, _, killed, _ = _source_observer([_observer_table(original), _observer_table(changed),
        {1: _observer_row("controller", parent=0)}, _observer_table(reused)])
    for _ in range(4):
        observer["observe"]()
    for signum in (signal.SIGTERM, signal.SIGKILL):
        observer["signal"](signum)
    assert not killed and not observer["signals"] and observer["pending"] == {10: reused}
    assert len(observer["resolutions"]) == 1 and len(observer["transitions"]) == 2


def test_source_safe_owned_lineage_allows_term_and_kill_excluding_unrelated():
    table = _observer_table(_observer_row(), **{"11": _observer_row(parent=0),
        "20": _observer_row("owned grandchild", parent=10)})
    observer, _, killed, _ = _source_observer([table])
    observer["observe"]()
    for signum in (signal.SIGTERM, signal.SIGKILL):
        observer["signal"](signum)
    assert len(killed) == 4 and set(killed) == {
        (10, signal.SIGTERM), (20, signal.SIGTERM), (10, signal.SIGKILL), (20, signal.SIGKILL)}
    assert observer["pending"] == {} and observer["transitions"] == []
    assert observer["resolutions"] == [] and {row["pid"] for row in observer["signals"]} == {10, 20}
    assert all(row["identity"] == table[row["pid"]] for row in observer["signals"])


# Inert H4 controls use the production parser/observer/effect helpers and, where
# stated, production run orchestration. Every native boundary is a local facade;
# no fixture repository, child process, kernel or real signal is created here.
def _h4_raw(*rows, witness=True):
    head = "99 0 99 Tue Oct 20 01:00:00 2026 Ss hook observer\n" if witness else ""
    return (head + "1 0 1 Tue Oct 20 01:00:00 2026 Ss owned CLI\n" + "".join(rows)).encode()


def _h4_child(pid=10, parent=1, group=1, command="owned child", birth="Tue Oct 20 01:00:00 2026", state="Rs"):
    return f"{pid} {parent} {group} {birth} {state} {command}\n"


def _h4_inert(samples, *, reaped=False, command=None):
    """Load actual source AST with explicit inert native boundaries only."""
    import ast
    import copy
    import io
    import re
    import codecs
    import itertools
    import fcntl
    import tempfile
    import stat
    import struct
    from types import SimpleNamespace

    tree = ast.parse(HOOK.read_text().split("<<'PY'\n", 1)[1].rsplit("\nPY", 1)[0])
    definitions = {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    run = definitions["run"]
    functions = [n for n in run.body if isinstance(n, ast.FunctionDef)]
    first_helper = next(i for i, n in enumerate(run.body) if isinstance(n, ast.FunctionDef))
    clock = SimpleNamespace(value=0.0)
    calls, effects, events, ordering = [], [], [], []
    samples = list(samples)

    def ps(argv, **kwargs):
        assert argv == ["/bin/ps", "-ww", "-axo", "pid=,ppid=,pgid=,lstart=,stat=,command="]
        assert kwargs["capture_output"] is True and 0 < kwargs["timeout"] <= 2
        item = samples.pop(0) if len(samples) > 1 else samples[0]
        call = dict(argv=argv, kwargs=kwargs, sample=None, returned=False)
        calls.append(call)  # invocation precedes a fallible native boundary
        try:
            if callable(item):
                item = item()
        except BaseException as error:
            call.update(error_type=type(error).__name__, error_arguments=error.args)
            raise
        call.update(sample=item if isinstance(item, bytes) else repr(item), returned=not isinstance(item, BaseException))
        if isinstance(item, BaseException):
            raise item
        rc, stdout, stderr = item if isinstance(item, tuple) else (0, item, b"")
        return SimpleNamespace(returncode=rc, stdout=stdout, stderr=stderr)

    def emit(event, **fields):
        # Tap only AFTER the actual production formatter and private file writer.
        namespace["actual_report"](event, **fields)
        observed = dict(event=event, **fields)
        for key in ("stdout", "stderr"):
            ref = observed.get(key + "_ref")
            if ref is not None:
                try:
                    observed[key + "_hex"] = (namespace["EVIDENCE"].root / ref["file"]).read_bytes().hex()
                except OSError as error:
                    # An observation tap cannot replace the actual producer fault.
                    # Missing custody stays missing; never fabricate empty bytes.
                    observed[key + "_hex"] = None
                    observed[key + "_tap_error"] = dict(type=type(error).__name__, arguments=error.args)
        events.append(observed)
        ordering.append(("report", event))

    class Buffer(io.BytesIO):
        def write(self, value):
            ordering.append(("buffer", bytes(value)))
            return super().write(value)

    class Child:
        pid = 1
        returncode = 0 if reaped else None
        stdin, stdout, stderr = io.BytesIO(), io.BytesIO(), io.BytesIO()

        def poll(self):
            ordering.append(("poll", self.returncode))
            return self.returncode

        def communicate(self, input=None, timeout=None):
            ordering.append(("communicate", timeout))
            assert timeout is not None and timeout > 0
            if command:
                return command(self, timeout)
            self.returncode = 0
            return b"original stdout", b"original stderr"

        def wait(self, timeout=None):
            ordering.append(("wait", timeout))
            assert timeout == 2
            if self.returncode is None:
                raise subprocess.TimeoutExpired(["INERT_CLI"], timeout)
            return self.returncode

    child = Child()

    def kill(pid, signum):
        assert pid > 0
        effects.append(dict(kind="pid", target=pid, signal=int(signum)))
        ordering.append(("signal", pid, int(signum)))
        if pid == 1 and signum == signal.SIGKILL:
            child.returncode = -9

    def killpg(pgid, signum):
        effects.append(dict(kind="group", target=pgid, signal=int(signum)))
        ordering.append(("group", pgid, int(signum)))

    def spawn(argv, **kwargs):
        ordering.append(("Popen", argv))
        assert kwargs["start_new_session"] is True
        # Exercise only the real mask-restoration closure, using inert mask API.
        kwargs["preexec_fn"]()
        return child

    def sleep(seconds):
        assert 0 <= seconds <= .1
        clock.value += seconds

    masks = []
    inert_signal = SimpleNamespace(SIGINT=signal.SIGINT, SIGTERM=signal.SIGTERM,
        SIGHUP=signal.SIGHUP, SIGKILL=signal.SIGKILL, SIG_BLOCK=signal.SIG_BLOCK,
        SIG_SETMASK=signal.SIG_SETMASK,
        pthread_sigmask=lambda how, values: masks.append((how, values)) or set())
    buffers = [Buffer(), Buffer()]
    temporary = tempfile.TemporaryDirectory(prefix="h4-inert-files-")
    allocated_path = Path(temporary.name)
    # Bind the guard to the owned allocation's canonical parent coordinate;
    # Evidence still validates the allocator's original leaf without following it.
    owner_path = allocated_path.parent.resolve(strict=True) / allocated_path.name
    # The historical flags map retains its logical mutable-control inputs.
    # Writable access and descriptor identity are separate explicit native facts.
    flags = {1: 0, 2: 0}
    descriptor_flags = {1: 0, 2: 0}
    identities = {fd: dict(st_mode=stat.S_IFIFO, st_dev=98, st_ino=100 + fd,
                           st_rdev=0, st_uid=os.getuid(), st_gid=os.getgid()) for fd in (1, 2)}
    descriptions = {1: 1, 2: 2}
    positions = {1: 0, 2: 0}
    owned_fds = set()
    terminal_attributes, disciplines = {}, {}
    def native_stat(fd, mode=None):
        assert fd in (1, 2), "unmodelled public descriptor"
        result = dict(identities[fd])
        if mode is not None: result["st_mode"] = mode
        return SimpleNamespace(**result)
    def fdwrite(fd, value):
        if fd in (1, 2):
            count = buffers[fd-1].write(value)
            for member in (1, 2):
                if descriptions[member] == descriptions[fd]:
                    positions[member] += count
            return count
        assert fd in owned_fds, "no write fallback to a host descriptor"
        return os.write(fd, value)
    def fdstat(fd):
        if fd in (1, 2): return native_stat(fd)
        assert fd in owned_fds, "no fstat fallback to a host descriptor"
        return os.fstat(fd)
    def fdopen(path, flags_value, mode=0o777, *, dir_fd=None):
        if dir_fd is None:
            actual = Path(path)
            assert actual == owner_path or actual.name.startswith("pre-commit-notebooks-"), "unmodelled private root"
        else:
            assert dir_fd in owned_fds and type(path) is str and "/" not in path
        handle = os.open(path, flags_value, mode, dir_fd=dir_fd)
        assert handle not in (1, 2)
        owned_fds.add(handle)
        return handle
    def fdclose(fd):
        assert fd in owned_fds, "no close fallback to a host descriptor"
        owned_fds.remove(fd)
        return os.close(fd)
    def fdconf(fd, name):
        assert name in ("PC_PIPE_BUF", "PC_FILESIZEBITS")
        if fd in (1, 2): return 65536
        assert fd in owned_fds, "no pathconf fallback to a host descriptor"
        return os.fpathconf(fd, name)
    def fdseek(fd, offset, how):
        assert fd in (1, 2) and offset == 0 and how == os.SEEK_CUR
        return positions[fd]
    def flags_call(fd, op, value=None):
        assert fd in (1, 2) and value is None, "unmodelled native flag operation"
        if op == fcntl.F_GETFL:
            return os.O_WRONLY | flags[fd]
        assert op == fcntl.F_GETFD
        return descriptor_flags[fd]
    import math
    import termios
    def narrow_ioctl(fd, request, payload):
        assert fd in (1, 2) and type(payload) is bytes and len(payload) == struct.calcsize("i")
        if request == termios.TIOCGETD:
            assert fd in terminal_attributes and fd in disciplines
            return struct.pack("i", disciplines[fd])
        assert request == termios.FIONBIO, "unmodelled native ioctl"
        desired = struct.unpack("i", payload)[0]
        assert desired in (0, 1)
        for member in (1, 2):
            if descriptions[member] == descriptions[fd]:
                flags[member] = (flags[member] & ~os.O_NONBLOCK) | (os.O_NONBLOCK if desired else 0)
        return payload
    def native_termios(fd):
        assert fd in terminal_attributes, "unmodelled native terminal observation"
        return terminal_attributes[fd]
    constants = ("O_RDONLY", "O_WRONLY", "O_RDWR", "O_CREAT", "O_EXCL", "O_DIRECTORY", "O_NOFOLLOW",
                 "O_NONBLOCK", "O_APPEND", "O_ASYNC", "O_FSYNC", "O_SYNC", "O_DSYNC", "O_ACCMODE", "SEEK_CUR")
    fake_os = SimpleNamespace(**{name: getattr(os, name) for name in constants},
        environ={"UNRELATED": "preserved"}, getpid=lambda: 99, getuid=os.getuid, getgid=os.getgid,
        kill=kill, killpg=killpg, open=fdopen, close=fdclose, write=fdwrite, fstat=fdstat,
        fpathconf=fdconf, lseek=fdseek,
        set_blocking=lambda *args: (_ for _ in ()).throw(AssertionError("unmodelled owned-pipe blocking operation")))
    native_terminal = SimpleNamespace(**{name: getattr(termios, name) for name in
        ("FIONBIO", "TIOCGETD", "CSIZE", "CS8", "FLUSHO", "OPOST", "ONLCR", "NCCS")}, tcgetattr=native_termios)
    namespace = dict(os=fake_os, fcntl=SimpleNamespace(fcntl=flags_call, ioctl=narrow_ioctl,
        F_GETFL=fcntl.F_GETFL, F_GETFD=fcntl.F_GETFD, F_SETFL=fcntl.F_SETFL, FD_CLOEXEC=fcntl.FD_CLOEXEC), termios=native_terminal, math=math,
        subprocess=SimpleNamespace(run=ps, Popen=spawn, PIPE="INERT_PIPE", TimeoutExpired=subprocess.TimeoutExpired),
        time=SimpleNamespace(monotonic=lambda: clock.value, sleep=sleep), signal=inert_signal,
        dt=dt, re=re, json=json, codecs=codecs, stat=stat, Path=Path, hashlib=hashlib, CHUNK=4096,
        root=child, sys=SimpleNamespace(platform="darwin", argv=["-",str(HOOK)], stdout=SimpleNamespace(buffer=buffers[0]), stderr=SimpleNamespace(buffer=buffers[1])),
        PROCESS_OBSERVATION_SEQUENCE=0, CLEANUP_ACTIVE=False, SIGNAL_SEEN=None,
        SIGNAL_EVENTS=[], SIGNAL_CURSOR=0, SIGNAL_CAUSE_ORDERS={}, CAUSE_SEQUENCE=itertools.count(1),
        select=SimpleNamespace(select=lambda read,write,error,timeout: ([],list(write),[])),
        INVOCATION_PHASE="inert", EXIT_COMMIT=False,
        struct=struct, SCRIPT_PIN=dict(sha256=hashlib.sha256(HOOK.read_bytes()).hexdigest(),mode=stat.S_IMODE(HOOK.stat().st_mode)),
        ENTRY=Path("/INERT"), argv=["INERT_CLI"], cwd="/INERT", env={}, timeout=60)
    factory = ast.parse("def helpers(argv=('INERT_CLI',), cwd='/INERT', env=None, timeout=60):\n    pass\n").body[0]
    factory.body = copy.deepcopy(run.body[:first_helper]) + ast.parse("p = root\nEVIDENCE.command_child_created = True").body
    factory.body += copy.deepcopy(functions)
    factory.body += ast.parse("return locals()").body
    module = ast.Module(body=[copy.deepcopy(definitions[n]) for n in
        ("Refusal", "require", "sha", "check_time", "error_text", "typed_native", "cause_order", "signal_checkpoint", "json_chunks", "Evidence", "report", "same_process", "process_rows", "run", "interrupted")] + [factory], type_ignores=[])
    exec(compile(ast.fix_missing_locations(module), str(HOOK) + ":H4-inert-only", "exec"), namespace)
    namespace["EVIDENCE"] = namespace["Evidence"](allocated_path)
    namespace["actual_report"] = namespace["report"]
    namespace["report"] = emit
    # Lazy fixture entry preserves every test's pre-prepare setup. It runs the
    # actual production capability owner, then the original extracted run once.
    # Explicit owner.prepare controls bypass this adapter entirely.
    actual_run = namespace["run"]
    def fixture_run(*args, **kwargs):
        if not namespace["EVIDENCE"].public_baselines:
            namespace["EVIDENCE"].prepare_public()
        return actual_run(*args, **kwargs)
    namespace["run"] = fixture_run
    helper = namespace["helpers"]()
    namespace["EVIDENCE"].command_sequence = 0
    namespace["EVIDENCE"].command_id = None
    namespace["EVIDENCE"].phase = "startup"
    def direct_entry(function):
        def scoped(*args, **kwargs):
            owner = namespace["EVIDENCE"]
            if owner.command_id is None:
                # Enter the original extracted closure's command, not a fabricated
                # admission. The actual producer must still create fresh receipts.
                owner.command_id = helper["command_id"]
                owner.command_sequence = helper["command_id"]
                owner.phase = namespace["INVOCATION_PHASE"] = "running"
            return function(*args, **kwargs)
        return scoped
    for name in ("observe", "cleanup_observe", "signal_descendants", "signal_job", "reconcile_identity"):
        helper[name] = direct_entry(helper[name])
    return dict(ns=namespace, helper=helper, calls=calls, effects=effects,
                events=events, ordering=ordering, child=child, clock=clock, masks=masks, buffers=buffers,
                files=temporary, owner=namespace["EVIDENCE"], flags=flags, descriptor_flags=descriptor_flags,
                native_stat=native_stat, identities=identities, descriptions=descriptions, positions=positions,
                terminal_attributes=terminal_attributes, disciplines=disciplines,
                actual_run=actual_run, fixture_run=fixture_run, owned_fds=owned_fds)


def _h4_trace(driver, label):
    print("NOTEBOOK_H4_INERT " + json.dumps(dict(label=label, effects=driver["effects"],
        native_calls=len(driver["calls"]), events=driver["events"],
        ordering=[list(x) if not any(isinstance(y, (bytes, set)) for y in x) else repr(x)
                  for x in driver["ordering"]], clock=driver["clock"].value), default=repr), flush=True)


def test_h4_partial_raw_observation_cannot_resolve_pending():
    a, b = _h4_raw(_h4_child()), _h4_raw(_h4_child(command="changed"))
    partial = _h4_raw("10 1 1 Tue Oct 20 01:00:00 2026\n")
    restored = _h4_raw(_h4_child(), _h4_child(20, 10, command="must not inherit ownership"))
    d = _h4_inert([a, b, partial, restored])
    h = d["helper"]
    h["observe"](); h["observe"]()
    before = json.loads(json.dumps({k: h[k] for k in
        ("owned", "identity_pending", "identity_transitions", "identity_resolutions")}))
    with pytest.raises(d["ns"]["Refusal"], match="process observation"):
        h["observe"]()
    assert json.loads(json.dumps({k: h[k] for k in before})) == before
    h["observe"](); h["signal_descendants"](signal.SIGTERM)
    assert set(h["owned"]) == {10} and set(h["identity_pending"]) == {10}
    assert not h["identity_resolutions"] and not d["effects"]
    refused = [x for x in d["events"] if x["event"] == "process_observation" and not x["complete"]]
    assert len(refused) == 1 and refused[0]["stdout_hex"] == partial.hex()
    _h4_trace(d, "partial raw row cannot become absence")


def test_h4_cli_interrupt_is_direct_despite_pending_group_child():
    a = _h4_raw(_h4_child())
    b = _h4_raw(_h4_child(command="changed"))
    restored = _h4_raw(_h4_child(), _h4_child(20, 10))
    d = _h4_inert([a, b, restored]); h = d["helper"]
    h["observe"](); h["observe"](); h["observe"]()
    for signum in (signal.SIGINT, signal.SIGKILL):
        h["signal_job"](signum)
    assert d["effects"] == [dict(kind="pid", target=1, signal=2), dict(kind="pid", target=1, signal=9)]
    assert set(h["identity_pending"]) == {10} and set(h["owned"]) == {10}
    assert not h["identity_resolutions"]
    _h4_trace(d, "CLI owns direct PID, not pending group")


_H4_BAD_RAW = [
    ("partial", _h4_raw("10 1 1 Tue Oct 20 01:00:00 2026\n")),
    ("pid-text", _h4_raw(_h4_child()).replace(b"10 1 1", b"notpid 1 1")),
    ("ppid-text", _h4_raw(_h4_child()).replace(b"10 1 1", b"10 nope 1")),
    ("pgid-text", _h4_raw(_h4_child()).replace(b"10 1 1", b"10 1 nope")),
    ("signed", _h4_raw(_h4_child()).replace(b"10 1 1", b"+10 1 1")),
    ("negative", _h4_raw(_h4_child()).replace(b"10 1 1", b"-10 1 1")),
    ("out-of-range", _h4_raw(_h4_child()).replace(b"10 1 1", b"2147483648 1 1")),
    ("unicode-numeric", _h4_raw(_h4_child()).replace(b"10 1 1", "١٠ 1 1".encode())),
    ("birth-calendar", _h4_raw(_h4_child(birth="Tue Feb 31 01:00:00 2026"))),
    ("birth-weekday", _h4_raw(_h4_child(birth="Mon Oct 20 01:00:00 2026"))),
    ("birth-time", _h4_raw(_h4_child(birth="Tue Oct 20 25:00:00 2026"))),
    ("birth-year", _h4_raw(_h4_child(birth="Tue Oct 20 01:00:00 nope"))),
    ("state-missing", _h4_raw("10 1 1 Tue Oct 20 01:00:00 2026\n")),
    ("state-unknown", _h4_raw(_h4_child(state="?"))),
    ("state-suffix", _h4_raw(_h4_child(state="RF"))),
    ("command-missing", _h4_raw("10 1 1 Tue Oct 20 01:00:00 2026 Rs\n")),
    ("utf8", _h4_raw(_h4_child()).replace(b"owned child", b"owned\xffchild")),
    ("NUL", _h4_raw(_h4_child(command="child\0tail"))),
    ("control", _h4_raw(_h4_child(command="child\x01tail"))),
    ("duplicate-equal", _h4_raw(_h4_child(), _h4_child())),
    ("duplicate-conflicting", _h4_raw(_h4_child(), _h4_child(command="conflict"))),
    ("partial-final", _h4_raw(_h4_child())[:-1]),
    ("blank-interior", _h4_raw(_h4_child()) + b"\n"),
    ("empty", b""),
    ("missing-witness", _h4_raw(_h4_child(), witness=False)),
    ("unrelated-malformed", _h4_raw(_h4_child(), "777 malformed unrelated row\n")),
    ("stderr", (0, _h4_raw(_h4_child()), b"native warning")),
    ("nonzero", (1, _h4_raw(_h4_child()), b"native failed")),
    ("timeout", subprocess.TimeoutExpired(["/bin/ps"], 2, output=b"PARTIAL", stderr=b"TIMEOUT")),
    ("unavailable", OSError("INERT_PS_UNAVAILABLE")),
]


@pytest.mark.parametrize("label,bad", _H4_BAD_RAW, ids=[x[0] for x in _H4_BAD_RAW])
def test_h4_invalid_whole_observation_preserves_history_and_refuses_effects(label, bad):
    a, b = _h4_raw(_h4_child()), _h4_raw(_h4_child(command="changed"))
    d = _h4_inert([a, b, bad]); h = d["helper"]
    h["observe"](); h["observe"]()
    saved = json.loads(json.dumps({k: h[k] for k in
        ("owned", "identity_pending", "identity_transitions", "identity_resolutions")}))
    assert h["cleanup_observe"]() is None
    for signum in (signal.SIGTERM, signal.SIGKILL):
        h["signal_descendants"](signum)
    assert json.loads(json.dumps({k: h[k] for k in saved})) == saved
    assert not d["effects"] and not h["identity_resolutions"] and len(h["observation_errors"]) == 3
    bad_events = [x for x in d["events"] if x["event"] == "process_observation" and not x["complete"]]
    assert len(bad_events) == 3 and all(x["error"] for x in bad_events)
    if label == "timeout":
        assert bad_events[0]["stdout_hex"] == b"PARTIAL".hex()
        assert bad_events[0]["stderr_hex"] == b"TIMEOUT".hex()
    _h4_trace(d, label)


def test_h4_complete_native_stream_and_true_absence_are_positive():
    a = _h4_raw(_h4_child(command="owned  µ child  "))
    b = _h4_raw(_h4_child(command="changed"))
    empty = _h4_raw()
    fresh = _h4_raw(_h4_child(30, group=300, command="fresh child"), _h4_child(11, parent=0))
    d = _h4_inert([a, b, empty, fresh]); h = d["helper"]
    rows = h["observe"]()
    assert rows[10]["command"] == ("owned  µ child  ",) and rows[10]["birth"] == ["Tue", "Oct", "20", "01:00:00", "2026"]
    h["observe"](); h["observe"](); h["observe"]()
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGKILL):
        h["signal_descendants"](signum)
    assert d["effects"] == [dict(kind="pid", target=30, signal=int(s))
                            for s in (signal.SIGINT, signal.SIGTERM, signal.SIGKILL)]
    assert set(h["owned"]) == {10, 30} and not h["identity_pending"] and len(h["identity_resolutions"]) == 1
    assert all(x["kwargs"]["env"] == {"UNRELATED": "preserved", "LC_ALL": "C", "LANG": "C"} for x in d["calls"])
    records = [x for x in d["events"] if x["event"] == "process_observation"]
    assert len(records) == len(d["calls"]) and all(x["complete"] for x in records)
    assert [x["sequence"] for x in records] == list(range(1, len(records) + 1))
    _h4_trace(d, "complete stream and actual absence")


@pytest.mark.parametrize("group", [1, 700])
@pytest.mark.parametrize("kind", ["changed", "restored", "reused", "unknown", "exhausted"])
def test_h4_every_descendant_effect_respects_pending_history(group, kind):
    a = _h4_raw(_h4_child(group=group))
    b = _h4_raw(_h4_child(group=group, command="changed", birth="Tue Oct 20 01:00:01 2026" if kind == "reused" else "Tue Oct 20 01:00:00 2026"))
    last = _h4_raw(_h4_child(group=group), _h4_child(20, 10, group)) if kind in ("restored", "exhausted") else b
    if kind == "unknown":
        last = OSError("INERT_OBSERVATION_DENIED")
    d = _h4_inert([a, b, last]); h = d["helper"]
    h["observe"](); rows = h["observe"]()
    if kind == "exhausted":
        h["reconcile_identity"](rows)
        assert d["clock"].value == pytest.approx(2)
    for selected in (None, {10, 20}):
        for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGKILL):
            h["signal_descendants"](signum, selected)
    assert not d["effects"] and set(h["identity_pending"]) == {10} and set(h["owned"]) == {10}
    assert not h["identity_resolutions"]
    _h4_trace(d, f"pending {kind} group {group}")


def test_h4_reaped_root_and_zombie_parent_never_grant_authority():
    a = _h4_raw(_h4_child(state="Z"), _h4_child(20, 10), _h4_child(11, parent=0))
    d = _h4_inert([a]); h = d["helper"]
    h["observe"]()
    assert set(h["owned"]) == {10}
    h["signal_descendants"](signal.SIGKILL)
    d["child"].returncode = 0
    h["signal_job"](signal.SIGINT); h["signal_job"](signal.SIGKILL)
    assert not d["effects"]
    other = _h4_inert([_h4_raw(_h4_child())], reaped=True)
    other["helper"]["observe"]()
    assert other["helper"]["owned"] == {}
    _h4_trace(d, "reaped root and zombie ancestry")


def test_h4_fresh_actual_target_and_safe_siblings_survive_one_bad_sample():
    a = _h4_raw(_h4_child(), _h4_child(20))
    b = _h4_raw(_h4_child(), _h4_child(20, command="changed"), _h4_child(30, 20))
    # Initial population, first fresh target, changed second target.
    d = _h4_inert([a, a, a, b]); h = d["helper"]
    h["observe"](); h["signal_descendants"](signal.SIGTERM)
    assert d["effects"] == [dict(kind="pid", target=10, signal=15)]
    assert h["signals"][0]["observation_sample"] == 3
    assert h["signals"][0]["sample_scope"] == "successful_run_observation"
    assert set(h["identity_pending"]) == {20} and set(h["owned"]) == {10, 20}
    # A single unavailable first-target observation cannot abort the safe sibling.
    sibling = _h4_inert([a, a, OSError("INERT_TRANSIENT"), a]); sh = sibling["helper"]
    sh["observe"](); sh["signal_descendants"](signal.SIGTERM)
    assert sibling["effects"] == [dict(kind="pid", target=20, signal=15)]
    assert sh["observation_errors"] and not sh["identity_pending"]
    _h4_trace(d, "fresh target race"); _h4_trace(sibling, "later safe sibling")


@pytest.mark.parametrize("ending", ["normal", "command-error", "timeout-safe", "timeout-pending", "timeout-transient", "timeout-term-transient", "timeout-kill-transient", "final-unknown", "preflight-unknown"])
def test_h4_actual_run_cleanup_order_is_inert_and_bounded(ending):
    holder = {}

    def command(child, timeout):
        d = holder["driver"]
        if ending.startswith("timeout") and child.returncode is None:
            d["clock"].value += min(.25, timeout)
            raise subprocess.TimeoutExpired(["INERT_CLI"], timeout, output=b"ORIGINAL_OUT", stderr=b"ORIGINAL_ERROR")
        child.returncode = child.returncode if child.returncode is not None else (1 if ending == "command-error" else 0)
        return b"ORIGINAL_OUT_TAIL", b"ORIGINAL_ERROR_TAIL"

    count, phase_bad = [0], [0]

    def table():
        count[0] += 1
        d = holder["driver"]
        if ending == "preflight-unknown" or (ending == "final-unknown" and count[0] >= 4):
            return b"malformed\n"
        rows = []
        if ending == "command-error" or ending.startswith("timeout"):
            post_root_kill = any(x["target"] == 1 and x["signal"] == 9 for x in d["effects"])
            before_term = not any(x["target"] == 10 and x["signal"] == 15 for x in d["effects"])
            bad_phase = ((ending == "timeout-term-transient" and post_root_kill and before_term)
                         or (ending == "timeout-kill-transient" and d["clock"].value >= 20.25))
            if bad_phase and phase_bad[0] < 2:
                phase_bad[0] += 1
                return b"malformed phase observation\n"
            killed = any(x["target"] == 10 and x["signal"] == 9 for x in d["effects"])
            if not killed:
                rows.append(_h4_child())
            if ending == "timeout-pending":
                rows.append(_h4_child(20, command="changed" if count[0] >= 3 else "pending original"))
            if ending == "timeout-transient" and count[0] == 3:
                return b"malformed\n"
        return _h4_raw(*rows)

    d = _h4_inert([table], command=command); holder["driver"] = d
    if ending == "normal":
        assert d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=0, watch=True) == (b"ORIGINAL_OUT_TAIL", b"ORIGINAL_ERROR_TAIL")
        assert not d["effects"]
    else:
        with pytest.raises(d["ns"]["Refusal"]):
            d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=0, watch=True)
        assert not any(x["kind"] == "group" for x in d["effects"])
        if ending == "preflight-unknown":
            assert not any(x[0] == "Popen" for x in d["ordering"])
        elif ending.startswith("timeout"):
            direct = [x for x in d["effects"] if x["target"] == 1]
            assert direct == [dict(kind="pid", target=1, signal=2), dict(kind="pid", target=1, signal=9)]
            assert any(x["target"] == 10 and x["signal"] == 9 for x in d["effects"])
            if ending in ("timeout-term-transient", "timeout-kill-transient"):
                assert phase_bad == [2]
                child_signals = [x["signal"] for x in d["effects"] if x["target"] == 10]
                assert child_signals == [15, 9]
            assert all(x["target"] != 20 for x in d["effects"])
            failure = next(x for x in d["events"] if x["event"] == "command_failure")
            assert failure["reason"] == "outer notebook command timeout"
            position = d["ordering"].index(("report", "command_failure"))
            assert any(x == ("buffer", b"ORIGINAL_ERROR") for x in d["ordering"][:position])
            assert d["buffers"][1].getvalue() == b"ORIGINAL_ERROR_TAIL"
            assert d["clock"].value <= 22.5
        else:
            assert not any(x["target"] == 1 for x in d["effects"])
        if ending != "preflight-unknown":
            children = [x for x in d["events"] if x["event"] == "children"]
            assert len(children) == 1
            if ending == "timeout-pending":
                assert children[0]["unresolved_identity_pids"] == [20]
            if ending == "final-unknown":
                assert children[0]["remaining_observed_live"] is None and children[0]["observation_errors"]
    _h4_trace(d, "actual run " + ending)


def test_h4_actual_absence_then_reuse_reopens_without_effect_authority():
    a = _h4_raw(_h4_child())
    changed = _h4_raw(_h4_child(command="changed"))
    absent = _h4_raw()
    reused = _h4_raw(_h4_child(birth="Tue Oct 20 01:00:01 2026"), _h4_child(20, 10))
    d = _h4_inert([a, changed, absent, reused]); h = d["helper"]
    for _ in range(4):
        h["observe"]()
    assert len(h["identity_resolutions"]) == 1 and len(h["identity_transitions"]) == 2
    assert set(h["owned"]) == {10} and set(h["identity_pending"]) == {10}
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGKILL):
        h["signal_descendants"](signum, {10, 20})
    assert not d["effects"]
    _h4_trace(d, "actual complete absence then later reuse")


@pytest.mark.parametrize("route", ["root-poll", "root-signal", "descendant-signal"])
def test_h4_actual_effect_failures_retain_target_authority_and_uncertainty(route):
    d = _h4_inert([_h4_raw(_h4_child())]); h = d["helper"]
    h["observe"]()

    def failed_kill(pid, signum):
        d["effects"].append(dict(kind="pid", target=pid, signal=int(signum), failed=True))
        raise OSError("INERT_SIGNAL_DENIED")

    def failed_poll():
        raise OSError("INERT_POLL_DENIED")

    d["ns"]["os"].kill = failed_kill
    if route == "root-poll":
        d["child"].poll = failed_poll
    if route == "descendant-signal":
        h["signal_descendants"](signal.SIGTERM)
        assert d["effects"] == [dict(kind="pid", target=10, signal=15, failed=True)]
        assert "pid=10 signal=15 sample=3" in h["observation_errors"][0]
    else:
        h["signal_job"](signal.SIGINT)
        assert d["effects"] == ([] if route == "root-poll" else [dict(kind="pid", target=1, signal=2, failed=True)])
        assert "pid=1" in h["observation_errors"][0]
    assert len(h["observation_errors"]) == 1 and not h["signals"]
    assert not h["identity_resolutions"] and set(h["owned"]) == {10}
    _h4_trace(d, "actual failed effect " + route)


# R17 controls audit only actual selected definitions. Real file syscalls act on
# their own private temporary root; all process/control/signal boundaries are inert.
def test_h4_file_backed_complete_large_census_has_bounded_actual_formatter_transport():
    raw = _h4_raw(*[_h4_child(pid=1000+i, parent=0, group=1000+i,
                             command="ordinary unrelated process argument " + "x"*100) for i in range(1000)])
    assert len(raw) == 177094  # Exact original R14 source-control population.
    d = _h4_inert([raw]); owner = d["owner"]
    write = d["ns"]["os"].write
    def finite_undrained(fd, value):
        if fd in (1, 2) and len(d["buffers"][fd-1].getvalue()) + len(value) > 65536:
            raise BlockingIOError("FINITE_65536_UNDRAINED")
        return write(fd, value)
    d["ns"]["os"].write = finite_undrained
    owner.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    assert d["ns"]["run"](["INERT_CLI"], "/INERT", {}, watch=True) == (b"original stdout", b"original stderr")
    assert owner.finish(None) is None
    public = d["buffers"][0].getvalue()
    first, boundary = _control_object(public)
    last, end_boundary = _control_object(public, boundary)
    assert end_boundary == len(public)
    messages = [json.loads(x.removeprefix(b"NOTEBOOK_HOOK ")) for x in (first, last)]
    assert [x["event"] for x in messages] == ["start", "terminal"]
    start, terminal = messages
    assert start["root_identity"] == list(owner.root_identity)
    assert start["observer_pid"] == 99 and start["started_utc"] == owner.started_utc
    assert start["entry_sha256"] == hashlib.sha256(HOOK.read_bytes()).hexdigest()
    assert start["evidence_root"] == str(owner.root)
    assert terminal["start_sha256"] == hashlib.sha256(first).hexdigest()
    assert messages[-1]["provisional_until_exit"] and messages[-1]["flags_restoration_pending"]
    assert not messages[-1]["failed"] and messages[-1]["evidence_closed"]
    assert len(public) < 4096 and not d["effects"]
    events = [json.loads(x) for x in (Path(d["files"].name)/"events.jsonl").read_bytes().splitlines()]
    observations = [x for x in events if x["event"] == "process_observation"]
    assert len(observations) == 4 and all(x["parsed_rows"] == 1002 and x["complete"] for x in observations)
    for row in observations:
        ref = row["stdout_ref"]
        assert (owner.root/ref["file"]).read_bytes() == raw
        assert ref["bytes"] == len(raw) and ref["sha256"] == hashlib.sha256(raw).hexdigest()
        assert (owner.root/row["stderr_ref"]["file"]).read_bytes() == b""
    assert d["flags"] == {1: 0, 2: 0}
    assert stat.S_IMODE(owner.root.stat().st_mode) == 0o700
    assert all(stat.S_IMODE(p.stat().st_mode) == 0o600 for p in owner.root.iterdir())
    print("NOTEBOOK_H4_FILES " + json.dumps(dict(rows=1002, raw_bytes=len(raw), public_bytes=len(public),
        events=len(events), effects=d["effects"], raw_sha256=hashlib.sha256(raw).hexdigest())))


@pytest.mark.parametrize("fault", ["short", "zero", "eintr", "enospc", "eio", "close", "open"])
def test_h4_actual_private_raw_file_faults_keep_exact_prefix_and_incomplete_status(fault):
    import errno
    d = _h4_inert([_h4_raw()]); o = d["owner"]; api = d["ns"]["os"]
    write, close, opened = api.write, api.close, api.open
    count = [0]
    def broken(fd, value):
        count[0] += 1
        if fault == "short" and count[0] == 1:
            return write(fd, value[:2])
        if fault == "short" and count[0] == 2:
            raise OSError(errno.EIO, "RAW_AFTER_PREFIX")
        if fault == "zero":
            return 0
        raise OSError(getattr(errno, {"eintr":"EINTR", "enospc":"ENOSPC"}.get(fault,"EIO")), "RAW_WRITE_FAULT")
    def bad_close(fd):
        close(fd)
        raise OSError(errno.EIO, "RAW_CLOSE_FAULT")
    def bad_open(*args, **kwargs):
        raise OSError(errno.EIO, "RAW_OPEN_FAULT")
    if fault == "close": api.close = bad_close
    elif fault == "open": api.open = bad_open
    else: api.write = broken
    ref = o.raw(b"ABCDEFGH", "probe.bin")
    api.write, api.close, api.open = write, close, opened
    assert not ref["complete"] and ref["available_bytes"] == 8 and ref["sha256"] is None
    expected = b"AB" if fault == "short" else b"ABCDEFGH" if fault == "close" else b""
    path = o.root/ref["file"]
    assert (path.read_bytes() if path.exists() else b"") == expected and ref["bytes"] == len(expected)
    assert o.faults and o.finish(None) is not None


@pytest.mark.parametrize("fault", ["eagain", "epipe", "short", "flags-get", "flags-set", "flags-restore"])
def test_h4_actual_nonblocking_control_capability_and_terminal_faults_refuse(fault):
    import errno
    d = _h4_inert([_h4_raw()]); o = d["owner"]; api=d["ns"]["os"]; fc=d["ns"]["fcntl"]
    write, flag, fstat, ioctl = api.write, fc.fcntl, api.fstat, fc.ioctl
    if fault == "short":
        from types import SimpleNamespace
        api.fstat = lambda fd: d["native_stat"](fd, mode=stat.S_IFREG) if fd == 1 else fstat(fd)
    def broken_write(fd, data):
        if fd == 1:
            if fault == "short": return write(fd, data[:2])
            raise OSError(errno.EAGAIN if fault == "eagain" else errno.EPIPE, "CONTROL_FAULT")
        return write(fd, data)
    def broken_flags(fd, op, value=None):
        if fault == "flags-get" and op == fc.F_GETFL:
            raise OSError(errno.EIO, "FLAGS_FAULT")
        return flag(fd,op,value)
    def broken_narrow(fd, op, value):
        import struct
        terminal = d["ns"]["termios"]
        desired = struct.unpack("i", value)[0] if op == terminal.FIONBIO else None
        if (fault == "flags-set" and desired == 1) or (fault == "flags-restore" and desired == 0):
            raise OSError(errno.EIO, "FLAGS_RESTORE_FAULT" if desired == 0 else "FLAGS_FAULT")
        return ioctl(fd, op, value)
    if fault in ("eagain", "epipe", "short"): api.write=broken_write
    else: fc.fcntl, fc.ioctl=broken_flags, broken_narrow
    if fault == "flags-restore":
        o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        assert o.finish(None) is not None
    else:
        with pytest.raises((OSError,d["ns"]["Refusal"])): o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        assert not any(x[0] == "Popen" for x in d["ordering"])
        assert o.finish(d["ns"]["Refusal"]("FIRST")) is not None
    assert not d["effects"]
    if fault == "short":
        assert len(o.control_writes) == 2 and o.atomic == 4096
        assert all(x["descriptor_mode"] == stat.S_IFREG for x in o.control_writes)
        for index, attempt in enumerate(o.control_writes):
            assert attempt["attempt_id"] == index + 1 and attempt["returned_value"] == 2
            assert attempt["written_bytes"] == attempt["offset"] == 2
            assert attempt["accepted_prefix"] == attempt["raw"][:2] == b"NO"
            assert attempt["missing_ranges"] == [[2, len(attempt["raw"])]] and not attempt["complete"]
            assert attempt["sha256"] == hashlib.sha256(attempt["raw"]).hexdigest()
            assert attempt["stream_offset"] == index * 2
            retained = next(x for x in o.faults if x["fault_id"] == attempt["fault_id"])
            assert retained["details"]["returned_count"] == 2 and retained["details"]["returned_count_known"]
            assert bytes.fromhex("".join(retained["details"]["raw_hex_chunks"])) == attempt["raw"]
            assert retained["details"]["accepted_prefix_hex"] == b"NO".hex()
        assert o.control_writes[0]["persisted"] and not o.control_writes[0]["events_closed"]
        assert not o.control_writes[1]["persisted"] and o.control_writes[1]["events_closed"]
        assert d["buffers"][0].getvalue() == b"NONO" and o.public_offsets[1] == 4
    api.write, fc.fcntl, api.fstat, fc.ioctl=write,flag,fstat,ioctl


@pytest.mark.parametrize("fault", ["grace-communicate", "grace-poll", "final-communicate", "final-wait", "late-tail-wait", "stdout", "stderr", "report", "mask-restore"])
def test_h4_actual_whole_cleanup_io_fault_tree_preserves_first_failure_and_safe_work(fault):
    holder, calls = {}, [0]
    def command(child, timeout):
        d=holder["d"]; calls[0]+=1
        if child.returncode is None:
            d["clock"].value += min(.25, timeout)
            if fault == "grace-communicate" and calls[0] > 1:
                raise OSError("GRACE_IO")
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"FIRST_OUT",stderr=b"FIRST_ERROR")
        if fault == "final-communicate": raise OSError("FINAL_IO")
        return b"FIRST_OUT_TAIL", b"FIRST_ERROR_TAIL"
    def table():
        d=holder["d"]
        killed=any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
        return _h4_raw(*([] if killed else [_h4_child()]))
    d=_h4_inert([table],command=command);holder["d"]=d
    def fail_wait(timeout=None): raise OSError("WAIT_IO")
    if fault in ("final-wait", "late-tail-wait"): d["child"].wait=fail_wait
    if fault == "grace-poll":
        poll=d["child"].poll; seen=[0]
        def fail_poll():
            seen[0]+=1
            if seen[0]==3: raise OSError("GRACE_POLL_IO")
            return poll()
        d["child"].poll=fail_poll
    if fault in ("stdout","stderr"):
        write=d["ns"]["os"].write
        def failed_stream(fd,value):
            if fd==(1 if fault=="stdout" else 2): raise OSError("BROKEN_PUBLIC_STREAM")
            return write(fd,value)
        d["ns"]["os"].write=failed_stream
    if fault=="report":
        actual=d["ns"]["report"]
        def failed_report(event,**fields):
            if event=="command_failure": raise OSError("REPORT_IO")
            return actual(event,**fields)
        d["ns"]["report"]=failed_report
    if fault=="mask-restore":
        original=d["ns"]["signal"].pthread_sigmask; seen=[0]
        def failed_mask(how,values):
            seen[0]+=1
            if seen[0]==3: raise OSError("MASK_RESTORE_IO")
            return original(how,values)
        d["ns"]["signal"].pthread_sigmask=failed_mask
    with pytest.raises((d["ns"]["Refusal"],OSError)) as raised:
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=0,watch=True)
    assert str(raised.value)==("MASK_RESTORE_IO" if fault=="mask-restore" else "outer notebook command timeout")
    assert any(x["target"]==1 and x["signal"]==9 for x in d["effects"])
    assert any(x["target"]==10 and x["signal"]==15 for x in d["effects"])
    assert any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
    assert not any(x["kind"]=="group" for x in d["effects"])
    assert len([x for x in d["events"] if x["event"]=="children"])==1
    if fault not in ("stdout","final-communicate"): assert d["buffers"][0].getvalue()==b"FIRST_OUT_TAIL"
    if fault not in ("stderr","final-communicate"): assert d["buffers"][1].getvalue()==b"FIRST_ERROR_TAIL"
    assert d["clock"].value<=22.5
    _h4_trace(d,"whole IO "+fault)


@pytest.mark.parametrize("fault", ["raw-file", "metadata", "cost-deadline"])
def test_h4_failed_evidence_never_resolves_pending_complete_sample(fault):
    a, b = _h4_raw(_h4_child()), _h4_raw(_h4_child(command="changed"))
    d=_h4_inert([a,b,_h4_raw()]);h=d["helper"]
    h["observe"]();h["observe"]()
    saved=json.loads(json.dumps({k:h[k] for k in ("owned","identity_pending","identity_transitions","identity_resolutions")}))
    write=d["ns"]["os"].write; opened=d["ns"]["os"].open
    def bad_open(*args,**kwargs): raise OSError("RAW_FILE_UNAVAILABLE")
    def bad_write(fd,value):
        if fault=="metadata" and fd==d["owner"].events: raise OSError("METADATA_UNAVAILABLE")
        if fault=="cost-deadline": d["clock"].value+=.5
        return write(fd,value)
    if fault=="raw-file":d["ns"]["os"].open=bad_open
    else:d["ns"]["os"].write=bad_write
    assert h["cleanup_observe"]() is None
    assert json.loads(json.dumps({k:h[k] for k in saved}))==saved
    assert not d["effects"] and h["identity_pending"] and not h["identity_resolutions"]
    d["ns"]["os"].write,d["ns"]["os"].open=write,opened


def test_h4_long_command_and_actual_chunked_json_preserve_full_identity_and_bytes():
    command="µ\t\\quoted\""*2000+" tail  "
    raw=_h4_raw(_h4_child(command=command));d=_h4_inert([raw])
    rows=d["helper"]["observe"]()
    assert rows[10]["command"]==tuple(command[i:i+512] for i in range(0,len(command),512))
    row=next(x for x in d["events"] if x["event"]=="process_observation")
    assert (d["owner"].root/row["stdout_ref"]["file"]).read_bytes()==raw
    large={"message":command,"list":[None,True,1,{"escaped":"\n\r\t\\"}]}
    largest=[0];write=d["ns"]["os"].write
    def measured(fd,value):
        largest[0]=max(largest[0],len(value));return write(fd,value)
    d["ns"]["os"].write=measured
    d["ns"]["actual_report"]("long-data",data=large)
    journal=(d["owner"].root/"events.jsonl").read_bytes().splitlines()
    assert json.loads(journal[-1])==dict(event="long-data",data=large)
    assert largest[0]<=4096


def test_h4_one_pipe_close_fault_does_not_skip_other_closes_wait_or_receipt():
    holder={};calls=[0]
    def command(child,timeout):
        calls[0]+=1
        if calls[0]==1:
            holder["d"]["clock"].value+=.25
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"FIRST",stderr=b"ERROR")
        raise OSError("COMMUNICATE_BROKEN")
    def table():
        d=holder["d"];killed=any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
        return _h4_raw(*([] if killed else [_h4_child()]))
    d=_h4_inert([table],command=command);holder["d"]=d;closed=[];blocking=[]
    class End:
        def __init__(self,index):self.index=index
        def fileno(self):return 900+self.index
        def close(self):
            closed.append(self.index)
            if self.index==0:raise OSError("FIRST_CLOSE_BROKEN")
    for i,name in enumerate(("stdin","stdout","stderr")):setattr(d["child"],name,End(i))
    d["ns"]["os"].set_blocking=lambda fd,value:blocking.append((fd,value))
    with pytest.raises(d["ns"]["Refusal"],match="outer notebook command timeout"):
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=0,watch=True)
    assert closed==[0,1,2] and blocking==[(900,False),(901,False),(902,False)]
    assert any(x[0]=="wait" for x in d["ordering"])
    receipt=next(x for x in d["events"] if x["event"]=="children")
    assert not receipt["drain_complete"] and any(x["operation"]=="pipe close:stdin" for x in receipt["cleanup_faults"])
    assert any(x["target"]==10 and x["signal"]==9 for x in d["effects"])


def test_h4_actual_encoding_failure_is_retained_without_recursive_report_success():
    d=_h4_inert([_h4_raw()]);o=d["owner"]
    with pytest.raises(TypeError,match="unsupported evidence field type"):
        d["ns"]["actual_report"]("bad-field",bad=object())
    assert o.faults and o.faults[0]["operation"]=="event:bad-field"
    assert (o.root/"events.jsonl").read_bytes().startswith(b'{"event":"bad-field"')
    assert o.finish(None) is not None and not d["effects"]


@pytest.mark.parametrize("during_cleanup", [False, True])
def test_h4_later_caught_signal_does_not_abandon_owned_cleanup(during_cleanup):
    if not during_cleanup:
        d=_h4_inert([_h4_raw()])
        with pytest.raises(d["ns"]["Refusal"],match="interrupted by signal"):
            d["ns"]["interrupted"](signal.SIGTERM,None)
            d["ns"]["signal_checkpoint"]()
        assert d["ns"]["SIGNAL_SEEN"]==signal.SIGTERM and not d["effects"]
        return
    holder={};calls=[0]
    def command(child,timeout):
        d=holder["d"];calls[0]+=1
        if calls[0]==2:d["ns"]["interrupted"](signal.SIGTERM,None)
        if child.returncode is None:
            d["clock"].value+=min(.25,timeout)
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"FIRST",stderr=b"ERROR")
        return b"FIRST_TAIL",b"ERROR_TAIL"
    def table():
        d=holder["d"];gone=any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
        return _h4_raw(*([] if gone else [_h4_child()]))
    d=_h4_inert([table],command=command);holder["d"]=d
    with pytest.raises(d["ns"]["Refusal"],match="outer notebook command timeout"):
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=0,watch=True)
    assert d["ns"]["SIGNAL_SEEN"]==signal.SIGTERM and not d["ns"]["CLEANUP_ACTIVE"]
    assert next(x for x in d["events"] if x["event"]=="children")["caught_signal"]==signal.SIGTERM
    assert any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
    assert any(x[0]=="wait" for x in d["ordering"])
    assert next(x for x in d["events"] if x["event"]=="command_failure")["reason"]=="outer notebook command timeout"


def test_h4_incomplete_or_contradictory_prefix_never_overwrites_retained_command_bytes():
    d=_h4_inert([_h4_raw()]);h=d["helper"]
    h["accept"](0,b"ORIGINAL")
    h["accept"](0,b"DIFFERENT_TAIL")
    assert h["channels"][0]==b"ORIGINAL"
    contradictions=[x for x in d["events"] if x["event"]=="contradictory_command_buffer"]
    assert len(contradictions)==1
    assert (d["owner"].root/contradictions[0]["available"]["file"]).read_bytes()==b"DIFFERENT_TAIL"
    check=d["ns"]["check_time"]
    def expired(deadline):raise d["ns"]["Refusal"]("COST_EXHAUSTED")
    d["ns"]["check_time"]=expired
    h["accept"](0,b"UNVERIFIED_LONGER")
    d["ns"]["check_time"]=check
    assert h["channels"][0]==b"ORIGINAL"
    assert d["owner"].pending_raw[-1]["data"]==b"UNVERIFIED_LONGER"
    assert any("command capture:0" in x for x in h["observation_errors"])


def test_h4_unformattable_first_exception_cannot_bypass_safe_cleanup():
    class BadFirst(OSError):
        def __str__(self):raise ValueError("EXCEPTION_FORMATTING_BROKEN")
    holder={};calls=[0]
    def command(child,timeout):
        d=holder["d"];calls[0]+=1
        if calls[0]==1:raise BadFirst("RAW_ORIGINAL")
        if child.returncode is None:
            d["clock"].value+=min(.25,timeout)
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"OUT",stderr=b"ERROR")
        return b"OUT_TAIL",b"ERROR_TAIL"
    def table():
        d=holder["d"];gone=any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
        return _h4_raw(*([] if gone else [_h4_child()]))
    d=_h4_inert([table],command=command);holder["d"]=d
    with pytest.raises(BadFirst) as original:
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},watch=True)
    assert original.value.args==("RAW_ORIGINAL",)
    assert any(x["target"]==1 and x["signal"]==9 for x in d["effects"])
    assert any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
    assert any(x["event"]=="children" for x in d["events"])


def test_h4_successful_command_final_wait_fault_remains_original_terminal_error():
    d=_h4_inert([_h4_raw()])
    def failed_wait(timeout=None):raise OSError("FIRST_FINAL_WAIT")
    d["child"].wait=failed_wait
    with pytest.raises(OSError,match="FIRST_FINAL_WAIT"):
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},watch=True)
    assert not d["effects"]
    receipt=next(x for x in d["events"] if x["event"]=="children")
    assert receipt["drain_complete"] and receipt["cleanup_faults"][0]["operation"]=="final wait"
    assert d["buffers"][0].getvalue()==b"original stdout" and d["buffers"][1].getvalue()==b"original stderr"


# Closed-file and native-boundary controls preserve the invocation evidence contract.
# Existing _h4_inert keeps process/control boundaries inert; storage is real.
def _h4_closed_records(driver, failure=None):
    result = driver["owner"].finish(failure)
    assert driver["owner"].closed and driver["owner"].root_closed
    raw = (driver["owner"].root/"events.jsonl").read_bytes()
    assert raw.endswith(b"\n")
    return result, [json.loads(line) for line in raw.splitlines()]


def _h84_tail_owner_cleanup(driver):
    """Finish this real Evidence owner once even if a fixture assertion fails."""
    import contextlib
    @contextlib.contextmanager
    def closing():
        owner=driver["owner"];api=driver["ns"]["os"];ready=driver["ns"]["select"]
        write,select=api.write,ready.select
        closed=dict(failure=None,original_error=None,cleanup_errors=[],finish_calls=0)
        driver["h84_cleanup"]=closed
        try:
            yield closed
        except BaseException as error:
            closed["original_error"]=error
            try:owner.fault("h84-fixture-assertion",error)
            except BaseException as later:closed["cleanup_errors"].append(later)
            raise
        finally:
            api.write,ready.select=write,select
            closed["finish_calls"]+=1
            try:closed["result"]=owner.finish(closed["failure"]or closed["original_error"])
            except BaseException as later:closed["cleanup_errors"].append(later)
            closed["events_closed"],closed["root_closed"]=owner.closed,owner.root_closed
            if closed["cleanup_errors"]:
                if closed["original_error"]is None:raise closed["cleanup_errors"][0]
                closed["original_error"].h84_cleanup_errors=tuple(closed["cleanup_errors"])
    return closing()


@pytest.mark.parametrize("prewait_blocked", [False, True])
@pytest.mark.parametrize("broken_stdout", [False, True])
def test_h4_delayed_returned_wait_preserves_independent_exact_final_tails(prewait_blocked, broken_stdout):
    holder = {}
    def command(child, timeout):
        d = holder["d"]
        if child.returncode is None:
            d["clock"].value += min(.25, timeout)
            raise subprocess.TimeoutExpired(["INERT_CLI"], timeout, output=b"OUT", stderr=b"ERROR")
        if d["owner"].phase == "final-drain": d["clock"].value += .5
        return b"OUT_TAIL", b"ERROR_TAIL"
    def table():
        d = holder["d"]
        gone = any(x["target"] == 10 and x["signal"] == 9 for x in d["effects"])
        return _h4_raw(*([] if gone else [_h4_child()]))
    d = _h4_inert([table], command=command); holder["d"] = d
    write = d["ns"]["os"].write; ready = d["ns"]["select"].select; wait_times = []; blocked = []; command_attempts = []
    def sink(fd, raw):
        if fd in(1,2):command_attempts.append((fd,d["owner"].phase,bytes(raw)))
        if fd == 1 and broken_stdout: raise BrokenPipeError("STDOUT_UNAVAILABLE")
        return write(fd, raw)
    def delayed_wait(timeout=None):
        assert timeout == 2
        wait_times.append(d["clock"].value)
        d["clock"].value += 1.75
        raise OSError("DELAYED_WAIT_ORIGINAL")
    def readiness(read,write,error,timeout):
        if prewait_blocked and d["owner"].phase=="final-drain":
            blocked.append((tuple(write),d["clock"].value,d["owner"].public_writes[-1]))
            return [],[],[]
        return ready(read,write,error,timeout)
    with _h84_tail_owner_cleanup(d)as closed:
        d["ns"]["os"].write = sink; d["ns"]["select"].select = readiness; d["child"].wait = delayed_wait
        with pytest.raises(d["ns"]["Refusal"], match="outer notebook command timeout") as first:
            d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=0, watch=True)
        closed["failure"]=first.value
        assert d["owner"].fault_objects[0] is first.value
        assert len(wait_times) == 1 and d["clock"].value - wait_times[0] == pytest.approx(1.75)
        assert d["buffers"][1].getvalue() == b"ERROR_TAIL"
        assert d["buffers"][0].getvalue() == (b"" if broken_stdout else b"OUT_TAIL")
        receipt = next(x for x in d["events"] if x["event"] == "children")
        assert receipt["public_delivered"] == ([0,10] if broken_stdout else [8,10])
        assert receipt["drain_complete"] and receipt["remaining_observed_live"] == []
        assert {x["target"] for x in d["effects"] if x["signal"] == 9} == {1,10}
        if prewait_blocked:
            assert blocked
            rows=[item[2]for item in blocked]
            assert rows and all(row["outcome"]=="not-admitted"and row["returned_count"]is None for row in rows)
            assert not any(phase=="final-drain"for _,phase,_ in command_attempts)
    assert closed["finish_calls"]==1 and closed["events_closed"]and closed["root_closed"]
    result=closed["result"]
    raw=(d["owner"].root/"events.jsonl").read_bytes()
    assert raw.endswith(b"\n")
    records=[json.loads(line)for line in raw.splitlines()]
    assert result is first.value
    assert any(x["event"] == "fault" and x["operation"] == "final wait" for x in records)


def test_h4_closed_first_fault_retains_native_typed_args_before_formatting_and_cleanup():
    class BadFirst(OSError):
        def __str__(self): raise ValueError("FORMAT_LATER")
    d = _h4_inert([_h4_raw()]); o = d["owner"]
    original = BadFirst("RAW_ORIGINAL", {b"key": (b"\x00\xff", -0.0, float("inf"), [None, True, 7])})
    row = o.fault("actual-original", original)
    result, records = _h4_closed_records(d, original)
    faults = [x for x in records if x["event"] == "fault"]
    assert result is original and o.fault_objects[0] is original
    assert faults[0]["fault_id"] == 1 and faults[0]["operation"] == "actual-original"
    assert faults[0]["phase"] == "startup" and faults[0]["observed_utc"] and faults[0]["observed_monotonic"] == 0
    assert faults[0]["arguments"]["items"][0] == dict(type="str",value="RAW_ORIGINAL",complete=True)
    pair = faults[0]["arguments"]["items"][1]["items"][0]
    assert pair[0] == dict(type="bytes",hex_chunks=["6b6579"],bytes=3,complete=True)
    assert pair[1]["type"] == "tuple" and pair[1]["items"][0]["hex_chunks"] == ["00ff"]
    assert pair[1]["items"][1]["bits"] == "8000000000000000"
    assert pair[1]["items"][2]["bits"] == "7ff0000000000000"
    assert pair[1]["items"][3]["type"] == "list"
    assert [x["operation"] for x in faults] == ["actual-original", "exception-formatting"]
    assert all(x["first_fault_id"] == 1 for x in faults) and row["persisted"]


@pytest.mark.parametrize("kind", ["opaque", "cycle"])
def test_h4_unsafe_native_arguments_are_explicitly_incomplete_in_closed_files(kind):
    d = _h4_inert([_h4_raw()]); value = object() if kind == "opaque" else []
    if kind == "cycle": value.append(value)
    error = ValueError("RAW_ORIGINAL", value)
    d["owner"].fault("unsafe-argument", error)
    result, records = _h4_closed_records(d,error)
    fault = next(x for x in records if x["event"] == "fault")
    assert result is error and not fault["complete"] and not fault["arguments"]["complete"]
    field = fault["arguments"]["items"][1]
    if kind == "cycle": field = field["items"][0]
    assert not field["complete"] and field["reason"] == ("cycle" if kind == "cycle" else "not an exact safe builtin")
    assert d["owner"].fault_objects[0] is error


@pytest.mark.parametrize("split", [False,True])
def test_h4_actual_command_boundaries_distinguish_empty_full_channels_and_no_output_failures(split):
    results = [(b"A",b""),(b"",b"B")] if split else [(b"A",b"B")]
    expected = list(results)
    def command(child, timeout):
        child.returncode = 0
        return results.pop(0)
    d = _h4_inert([_h4_raw()], command=command)
    for i, channels in enumerate(expected):
        d["child"].returncode = None
        assert d["ns"]["run"](["INERT_CLI",str(i)],"/INERT",{"LANG":"", "LC_ALL":"C"},watch=False) == channels
    result, rows = _h4_closed_records(d)
    assert result is None
    begins = [x for x in rows if x["event"] == "command_begin"]
    ends = [x for x in rows if x["event"] == "command_end"]
    assert [x["command_id"] for x in begins] == list(range(1,len(expected)+1))
    assert len(begins) == len(ends) == len(expected)
    for begin, end, channels in zip(begins,ends,expected):
        assert begin["selected_environment"]["LANG"] == dict(present=True,value="")
        assert begin["selected_environment"]["PATH"] == dict(present=False,value=None)
        assert end["launch_state"] == "created" and end["pid"] == 1 and end["returncode"] == 0
        assert end["drain_complete"] and end["reaped"] and not end["fault_ids"]
        for i, value in enumerate(channels):
            pieces = [x for x in rows if x["event"] == "command_channel" and x["command_id"] == begin["command_id"] and x["channel"] == i]
            assert pieces and b"".join((d["owner"].root/x["available"]["file"]).read_bytes() for x in pieces) == value
            assert all(x["available"]["closed"] and x["available"]["complete"] for x in pieces)
            assert end["channels"][i]["state"] == "eof" and not end["channels"][i]["delivery_required"]
    assert d["buffers"][0].getvalue() == d["buffers"][1].getvalue() == b""


def test_h4_actual_failed_launch_has_unknown_creation_and_no_invented_empty_eof():
    d = _h4_inert([_h4_raw()]); original = OSError("PARENT_POPEN_FAILED")
    def failed(*args,**kwargs): raise original
    d["ns"]["subprocess"].Popen = failed
    with pytest.raises(OSError) as caught: d["ns"]["run"](["INERT_CLI"],"/INERT",{})
    assert caught.value is original
    result, rows = _h4_closed_records(d,original)
    end = next(x for x in rows if x["event"] == "command_end")
    assert result is original and end["launch_state"] == "creation-unknown" and end["pid"] is None
    assert end["returncode"] is None and not end["drain_complete"] and not end["reaped"]
    assert [x["state"] for x in end["channels"]] == ["unknown","unknown"]
    assert not any(x["event"] in ("children","command_channel") for x in rows) and not d["effects"]


@pytest.mark.parametrize("phase", ["failure-transition","cli-grace","cli-kill","descendant-15","descendant-9","final-drain","final-wait","final-observation"])
def test_h4_signal_at_each_actual_cleanup_phase_keeps_first_error_and_safe_remaining_work(phase):
    holder = {}
    def command(child,timeout):
        d=holder["d"]
        if child.returncode is None:
            d["clock"].value += min(.25,timeout)
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"FIRST",stderr=b"ERROR")
        return b"FIRST_TAIL",b"ERROR_TAIL"
    def table():
        d=holder["d"];gone=any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
        return _h4_raw(*([] if gone else [_h4_child()]))
    d=_h4_inert([table],command=command);holder["d"]=d;seen=[]
    class Injected(type(d["owner"])):
        def __setattr__(self,key,value):
            super().__setattr__(key,value)
            if key=="phase" and value==phase and not seen:
                seen.append(value);d["ns"]["interrupted"](signal.SIGTERM,None)
    d["owner"].__class__=Injected
    with pytest.raises(d["ns"]["Refusal"],match="outer notebook command timeout") as first:
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=0,watch=True)
    assert seen==[phase] and d["owner"].fault_objects[0] is first.value
    assert {x["target"] for x in d["effects"] if x["signal"]==9}=={1,10}
    assert d["buffers"][0].getvalue()==b"FIRST_TAIL" and d["buffers"][1].getvalue()==b"ERROR_TAIL"
    assert len([x for x in d["ordering"] if x[0]=="Popen"])==1 and d["clock"].value<=22.5
    result, rows=_h4_closed_records(d,first.value)
    assert result is first.value and any(x["event"]=="fault" and x["operation"]=="caught-signal" for x in rows)


@pytest.mark.parametrize("phase", ["success-finalization","final-drain","final-wait","final-observation"])
def test_h4_signal_during_otherwise_successful_finalization_cannot_leave_zero(phase):
    d=_h4_inert([_h4_raw()]);seen=[]
    class Injected(type(d["owner"])):
        def __setattr__(self,key,value):
            super().__setattr__(key,value)
            if key=="phase" and value==phase and not seen:
                seen.append(value);d["ns"]["interrupted"](signal.SIGTERM,None)
    d["owner"].__class__=Injected
    with pytest.raises(d["ns"]["Refusal"],match="interrupted by signal") as first:
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},watch=True)
    result, rows=_h4_closed_records(d,first.value)
    assert result is first.value and seen==[phase] and not d["effects"]
    assert rows[-1]["event"]=="terminal_provisional" and rows[-1]["failed"]


@pytest.mark.parametrize("phase", ["terminal-provisional","events-close","root-descriptor-close","terminal-delivery","public-flags-restore:1","public-flags-verify:1","public-flags-restore:2","public-flags-verify:2"])
def test_h4_finalizer_signal_latch_attempts_every_acquired_close_and_flag_operation(phase):
    d=_h4_inert([_h4_raw()]);o=d["owner"];o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest());seen=[]
    class Injected(type(o)):
        def __setattr__(self,key,value):
            super().__setattr__(key,value)
            if key=="phase" and value==phase and not seen:
                seen.append(value);d["ns"]["interrupted"](signal.SIGTERM,None)
    o.__class__=Injected
    assert o.finish(None) is not None and seen==[phase]
    assert o.closed and o.root_closed and d["flags"]=={1:0,2:0}
    d["ns"]["EXIT_COMMIT"]=True
    with pytest.raises(SystemExit) as late: d["ns"]["interrupted"](signal.SIGHUP,None)
    assert late.value.code==2 and o.closed and o.root_closed


@pytest.mark.parametrize("corruption", ["source-pin","uid","stale-time","pid","temp-base","events-truncate","events-mode","events-inode","events-symlink","root-mode"])
def test_actual_current_hook_reader_rejects_corruption_before_negative_science_can_pass(cheap_repo,corruption):
    import copy
    r=_run(cheap_repo);assert r.hook_context["disposition"]=="verified-zero"
    root=Path(json.loads(_control_object(r.stdout)[0].removeprefix(b"NOTEBOOK_HOOK "))["evidence_root"])
    context=copy.deepcopy(r.hook_context);path=root/"events.jsonl";raw=path.read_bytes();mode=stat.S_IMODE(path.stat().st_mode)
    moved=root/"retained-original-events";old_root_mode=stat.S_IMODE(root.stat().st_mode)
    try:
        if corruption=="source-pin":context["entry_pin"]["sha256"]="0"*64
        elif corruption=="uid":context["uid"]+=1
        elif corruption=="stale-time":context["start_utc"]="9999-01-01T00:00:00+00:00"
        elif corruption=="pid":context["pid"]=2147483647
        elif corruption=="temp-base":context["temp_base"]=str(root)
        elif corruption=="events-truncate":path.write_bytes(raw[:-1])
        elif corruption=="events-mode":path.chmod(0o644)
        elif corruption in ("events-inode","events-symlink"):
            path.rename(moved)
            if corruption=="events-inode":path.write_bytes(raw);path.chmod(0o600)
            else:path.symlink_to(moved)
        else:root.chmod(0o755)
        with pytest.raises(AssertionError):_events(r,context=context)
        assert context["disposition"]=="protocol-incomplete"
        assert r.returncode==0 and r.stdout and not r.stderr
    finally:
        root.chmod(old_root_mode)
        if moved.exists():path.unlink();moved.rename(path)
        else:path.write_bytes(raw);path.chmod(mode)


@pytest.mark.parametrize("returncode", [0,7])
def test_h4_empty_returned_command_channels_have_closed_zero_length_evidence_even_on_error(returncode):
    def command(child,timeout):child.returncode=returncode;return b"",b""
    d=_h4_inert([_h4_raw()],command=command);error=None
    if returncode:
        with pytest.raises(d["ns"]["Refusal"]) as caught:d["ns"]["run"](["INERT_EMPTY"],"/INERT",{})
        error=caught.value
    else:assert d["ns"]["run"](["INERT_EMPTY"],"/INERT",{})==(b"",b"")
    result,rows=_h4_closed_records(d,error)
    assert result is error
    pieces=[x for x in rows if x["event"]=="command_channel"]
    assert [x["channel"] for x in pieces]==[0,1]
    assert all(x["offset"]==x["end"]==0 and x["available"]["closed"] and x["available"]["complete"] for x in pieces)
    assert all((d["owner"].root/x["available"]["file"]).read_bytes()==b"" for x in pieces)
    assert all(x["available"]["sha256"]==hashlib.sha256(b"").hexdigest() for x in pieces)
    end=next(x for x in rows if x["event"]=="command_end")
    assert end["returncode"]==returncode and end["drain_complete"] and end["reaped"]
    assert all(x["state"]=="eof" for x in end["channels"]) and not d["effects"]


@pytest.mark.parametrize("stream", ["stdin","stdout","stderr"])
def test_h4_signal_between_each_owned_pipe_close_keeps_other_ends_and_wait(stream):
    holder={};calls=[0]
    def command(child,timeout):
        d=holder["d"];calls[0]+=1
        if calls[0]==1:
            d["clock"].value+=.25
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"FIRST",stderr=b"ERROR")
        raise OSError("DRAIN_UNAVAILABLE")
    def table():
        d=holder["d"];gone=any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
        return _h4_raw(*([] if gone else [_h4_child()]))
    d=_h4_inert([table],command=command);holder["d"]=d;closed=[];seen=[]
    class End:
        def __init__(self,name,index):self.name,self.index=name,index
        def fileno(self):return 900+self.index
        def close(self):closed.append(self.name)
    for i,name in enumerate(("stdin","stdout","stderr")):setattr(d["child"],name,End(name,i))
    d["ns"]["os"].set_blocking=lambda fd,value:None
    class Injected(type(d["owner"])):
        def __setattr__(self,key,value):
            super().__setattr__(key,value)
            if key=="phase" and value=="pipe-close:"+stream and not seen:
                seen.append(value);d["ns"]["interrupted"](signal.SIGTERM,None)
    d["owner"].__class__=Injected
    with pytest.raises(d["ns"]["Refusal"],match="outer notebook command timeout") as caught:
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=0,watch=True)
    assert closed==["stdin","stdout","stderr"] and seen==["pipe-close:"+stream]
    assert any(x[0]=="wait" for x in d["ordering"]) and any(x["event"]=="children" for x in d["events"])
    assert d["owner"].fault_objects[0] is caught.value


def test_h4_actual_flag_restoration_verification_failure_is_nonzero_after_all_other_finalizers():
    import struct
    d=_h4_inert([_h4_raw()]);o=d["owner"];fc=d["ns"]["fcntl"]
    o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest());original=fc.fcntl;operations=[]
    ioctl=fc.ioctl;trace=[];activation=[]
    api=d["ns"]["os"];write=api.write
    def observed_write(fd, raw):
        returned=write(fd,raw)
        if fd in (1,2):trace.append((o.phase,"write-returned",fd,returned))
        return returned
    api.write=observed_write
    def observed_narrow(fd, operation, value):
        operations.append((fd, operation, value))
        returned=ioctl(fd, operation, value)
        trace.append((o.phase,"ioctl-returned",fd,operation,value))
        return returned
    fc.ioctl=observed_narrow
    def wrong(fd,operation,value=None):
        operations.append((fd,operation,value))
        trace.append((o.phase,"fcntl",fd,operation,value))
        if fd==1 and operation==fc.F_GETFL and o.phase=="public-flags-verify:1":
            activation.append(dict(index=len(trace)-1,phase=o.phase,fault_count=len(o.faults),
                terminal=[(x["state"],x["complete"],x["written_bytes"],x["intended_bytes"]) for x in o.control_writes],
                flags=dict(d["flags"]),restores=[(x["fd"],x["desired_nonblocking"],x["complete"]) for x in o.public_effects[-2:]]))
            return 123456
        return original(fd,operation,value)
    fc.fcntl=wrong
    failure=o.finish(None)
    assert failure is not None and o.closed and o.root_closed and d["flags"]=={1:0,2:0}
    assert (2,d["ns"]["termios"].FIONBIO,struct.pack("i",0)) in operations and (2,fc.F_GETFL,None) in operations
    assert (2,fc.F_GETFD,None) in operations
    assert any(x["operation"]=="public-flags-verify:1" for x in o.faults)
    assert len(activation)==1 and activation[0]["phase"]=="public-flags-verify:1" and activation[0]["fault_count"]==0
    assert activation[0]["terminal"]==[("start",True,o.control_writes[0]["intended_bytes"],o.control_writes[0]["intended_bytes"]),("terminal",True,o.control_writes[1]["intended_bytes"],o.control_writes[1]["intended_bytes"])]
    assert activation[0]["flags"]=={1:0,2:0} and activation[0]["restores"]==[(1,False,True),(2,False,True)]
    terminal_index=next(i for i,x in enumerate(trace) if x[:3]==("terminal-delivery","write-returned",1))
    restore_indices=[next(i for i,x in enumerate(trace) if x[:4]==("public-flags-restore:"+str(fd),"ioctl-returned",fd,d["ns"]["termios"].FIONBIO)) for fd in (1,2)]
    assert terminal_index < restore_indices[0] < restore_indices[1] < activation[0]["index"]
    assert o.faults[0]["operation"]==o.faults[0]["phase"]=="public-flags-verify:1" and o.fault_objects[0] is failure
    assert all(any(i>activation[0]["index"] and x[:4]==("public-flags-verify:2","fcntl",2,operation) for i,x in enumerate(trace)) for operation in (fc.F_GETFL,fc.F_GETFD))


@pytest.mark.parametrize("corruption", ["bytes","mode","inode","symlink","missing"])
def test_actual_command_raw_evidence_corruption_cannot_satisfy_a_negative_or_success_predicate(real_repo,corruption):
    import copy
    repo,_,_=real_repo
    _write(repo,"notebooks/raw-reader.ipynb",_nb("assert True"));_stage(repo)
    r=_run(repo);rows=_events(r);context=copy.deepcopy(r.hook_context);original_streams=(r.stdout,r.stderr)
    reference=next(x["available"] for x in rows if x["event"]=="command_channel" and x["available"]["bytes"])
    start=json.loads(_control_object(r.stdout)[0].removeprefix(b"NOTEBOOK_HOOK "));path=Path(start["evidence_root"])/reference["file"]
    raw=path.read_bytes();mode=stat.S_IMODE(path.stat().st_mode);retained=path.with_name("retained-original-raw")
    try:
        if corruption=="bytes":path.write_bytes(bytes([raw[0]^1])+raw[1:])
        elif corruption=="mode":path.chmod(0o644)
        else:
            path.rename(retained)
            if corruption=="inode":path.write_bytes(raw);path.chmod(0o600)
            elif corruption=="symlink":path.symlink_to(retained)
        with pytest.raises(AssertionError):_events(r,context=context)
        assert context["disposition"]=="protocol-incomplete"
        assert r.returncode==0 and (r.stdout,r.stderr)==original_streams
    finally:
        if retained.exists():
            if path.exists() or path.is_symlink():path.unlink()
            retained.rename(path)
        else:path.write_bytes(raw);path.chmod(mode)


@pytest.mark.parametrize("boundary", ["root-allocation","events-open"])
def test_h4_actual_top_level_startup_fault_uses_only_acquired_capabilities(boundary):
    import ast
    import copy
    import tempfile
    from types import SimpleNamespace
    d=_h4_inert([_h4_raw()]);namespace=d["ns"];old_owner=d["owner"]
    original=OSError(5,"STARTUP_RAW_ORIGINAL")
    source=HOOK.read_text().split("<<'PY'\n",1)[1].rsplit("\nPY",1)[0];tree=ast.parse(source)
    first=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and
               any(isinstance(t,ast.Name) and t.id=="terminal_failure" for t in n.targets))
    statements=ast.Module(body=copy.deepcopy(tree.body[first:]),type_ignores=[])
    opened=namespace["os"].open
    def exit_observed(code):raise SystemExit(code)
    with tempfile.TemporaryDirectory(prefix="pre-commit-notebooks-") as root:
        def allocate(**kwargs):
            assert kwargs==dict(prefix="pre-commit-notebooks-")
            if boundary=="root-allocation":raise original
            return root
        def open_observed(name,*args,**kwargs):
            if boundary=="events-open" and name=="events.jsonl":raise original
            return opened(name,*args,**kwargs)
        namespace.update(EVIDENCE=None,INVOCATION_PHASE="startup",EXIT_COMMIT=False,
                         tempfile=SimpleNamespace(mkdtemp=allocate),sys=SimpleNamespace(exit=exit_observed,argv=["-",str(HOOK)]))
        namespace["os"].open=open_observed
        try:
            with pytest.raises(SystemExit) as actual_exit:
                exec(compile(ast.fix_missing_locations(statements),str(HOOK)+":actual-startup-only","exec"),namespace)
            assert actual_exit.value.code==2 and not d["effects"]
            if boundary=="root-allocation":
                assert namespace["EVIDENCE"] is None and namespace["startup_fault_owner"]["error_object"] is original
                assert namespace["startup_fault_owner"]["arguments"]["items"][1]["value"]=="STARTUP_RAW_ORIGINAL"
                assert d["buffers"][1].getvalue()==b"NOTEBOOK_HOOK_STARTUP_UNAVAILABLE\n"
            else:
                partial=namespace["EVIDENCE"]
                assert partial.fault_objects[0] is original and partial.events is None
                assert partial.root_closed and not partial.closed and not partial.flags
                assert not (Path(root)/"events.jsonl").exists()
                with pytest.raises(OSError):os.fstat(partial.root_fd)
        finally:
            namespace["os"].open=opened
            old_owner.finish(None)


# R25 returned-boundary controls. Native operations remain explicit inert facades;
# the current production Evidence/run and original lifecycle helper execute intact.
@pytest.mark.parametrize("boundary", ["mask", "launch", "unmask", "launch-report"])
@pytest.mark.parametrize("late", [False, True])
def test_h4_positive_launch_admission_checks_every_returned_boundary(boundary, late):
    holder = {}; waits = []
    def command(child, timeout):
        d = holder["d"]; waits.append((d["owner"].phase, timeout, d["clock"].value))
        child.returncode = 0
        return b"EXACT_OUT", b"EXACT_ERR"
    d = _h4_inert([_h4_raw()], command=command); holder["d"] = d
    cost = 1.25 if late else .25
    mask = d["ns"]["signal"].pthread_sigmask; masks = []
    def returned_mask(how, values):
        masks.append(how); result = mask(how, values)
        if (boundary == "mask" and len(masks) == 1) or (boundary == "unmask" and len(masks) == 3):
            d["clock"].value += cost
        return result
    d["ns"]["signal"].pthread_sigmask = returned_mask
    spawn = d["ns"]["subprocess"].Popen
    def returned_launch(*args, **kwargs):
        child = spawn(*args, **kwargs)
        if boundary == "launch": d["clock"].value += cost
        return child
    d["ns"]["subprocess"].Popen = returned_launch
    report = d["ns"]["report"]
    def returned_report(event, **fields):
        report(event, **fields)
        if boundary == "launch-report" and event == "command_launch": d["clock"].value += cost
    d["ns"]["report"] = returned_report
    if late:
        with pytest.raises(d["ns"]["Refusal"], match="remaining scheduling deadline") as caught:
            d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=1)
        assert d["owner"].fault_objects[0] is caught.value
        assert not any(phase == "running" for phase, _, _ in waits)
        assert len([x for x in d["ordering"] if x[0] == "Popen"]) == (0 if boundary == "mask" else 1)
        if boundary == "mask":
            assert not waits and not d["effects"] and not d["owner"].command_child_created
            assert d["owner"].command_cleanup_deadline is None
            assert d["owner"].faults[0]["operation"] == "launch-admission"
            assert not d["owner"].faults[0]["complete"]  # Expired evidence remains explicit, with no added IO grace.
        else:
            end = next(x for x in d["events"] if x["event"] == "command_end")
            assert end["launch_state"] == "created"
    else:
        assert d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=1) == (b"EXACT_OUT", b"EXACT_ERR")
        assert waits == [("running", .25, .25)] and not d["effects"] and not d["owner"].faults
    assert masks[-1] == signal.SIG_SETMASK


@pytest.mark.parametrize("watch", [False, True])
def test_h4_positive_running_communicate_uses_only_actual_remaining_budget(watch):
    d = _h4_inert([_h4_raw()]); spawn = d["ns"]["subprocess"].Popen
    def returned_launch(*args, **kwargs):
        child = spawn(*args, **kwargs); d["clock"].value += .99; return child
    d["ns"]["subprocess"].Popen = returned_launch
    assert d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=1, watch=watch) == (b"original stdout", b"original stderr")
    waits = [x[1] for x in d["ordering"] if x[0] == "communicate"]
    assert waits == [pytest.approx(.01)] and not d["owner"].faults and not d["effects"]


@pytest.mark.parametrize("late_poll", [False, True])
def test_h4_post_poll_int_admission_preserves_separately_scheduled_required_cli_kill(late_poll):
    holder = {}; calls = []; original = OSError("FIRST_RUN_ERROR")
    def command(child, timeout):
        d = holder["d"]; calls.append(d["owner"].phase)
        if len(calls) == 1: raise original
        if child.returncode is None:
            d["clock"].value += timeout
            raise subprocess.TimeoutExpired(["INERT_CLI"], timeout, output=b"OUT", stderr=b"ERR")
        return b"OUT_TAIL", b"ERR_TAIL"
    d = _h4_inert([_h4_raw()], command=command); holder["d"] = d
    poll = d["child"].poll; observed = []
    def returned_poll():
        result = poll(); observed.append((d["owner"].phase, d["clock"].value))
        if len(observed) == 1 and late_poll: d["clock"].value = 15.1
        return result
    d["child"].poll = returned_poll
    kill = d["ns"]["os"].kill; effects = []
    def effect(pid, signum):
        effects.append((int(signum), d["owner"].phase, d["owner"].deadline, d["clock"].value))
        return kill(pid, signum)
    d["ns"]["os"].kill = effect
    with pytest.raises(OSError) as caught: d["ns"]["run"](["INERT_CLI"], "/INERT", {})
    assert caught.value is original and d["owner"].fault_objects[0] is original
    assert [x[0] for x in effects] == ([9] if late_poll else [2, 9])
    assert effects[-1][1:3] == ("cli-kill", None) and observed[0][0] == "cli-grace"
    assert d["buffers"][0].getvalue() == b"OUT_TAIL" and d["buffers"][1].getvalue() == b"ERR_TAIL"
    if late_poll:
        assert effects[-1][3] == 15.1
        assert any("owned CLI signal failed" in x["operation"] for x in d["owner"].faults)
    else: assert effects[-1][3] == 15


@pytest.mark.parametrize("capture_cost", [None, 0, 4])
def test_h4_nested_first_raw_fault_anchors_grace_before_returned_capture_and_report_cost(capture_cost):
    import errno
    holder = {}; commands = []; original = OSError(errno.EIO, "NESTED_FIRST_RAW_ERROR")
    def command(child, timeout):
        d = holder["d"]; commands.append(d["owner"].phase)
        if capture_cost is None:
            child.returncode = 0; return b"A_TAIL", b"B_TAIL"
        if child.returncode is None:
            d["clock"].value += 1 if len(commands) == 1 else timeout
            raise subprocess.TimeoutExpired(["INERT_CLI"], timeout, output=b"A", stderr=b"B")
        return b"A_TAIL", b"B_TAIL"
    d = _h4_inert([_h4_raw()], command=command); holder["d"] = d
    api = d["ns"]["os"]; write, close = api.write, api.close
    raw_fd = []; costs = []; anchors = []
    def returned_write(fd, data):
        if capture_cost is not None and fd not in (1, 2, d["owner"].events) and not raw_fd:
            raw_fd.append(fd); raise original
        if capture_cost and raw_fd and fd == d["owner"].events and "persist" not in costs:
            anchors.append(d["owner"].deadline); costs.append("persist"); d["clock"].value += 2
        return write(fd, data)
    def returned_close(fd):
        close(fd)
        if capture_cost and raw_fd and fd == raw_fd[0] and "close" not in costs:
            costs.append("close"); d["clock"].value += 1
    api.write, api.close = returned_write, returned_close
    report = d["ns"]["report"]
    def returned_report(event, **fields):
        report(event, **fields)
        if capture_cost and raw_fd and event == "command_channel" and "report" not in costs:
            costs.append("report"); d["clock"].value += 1
    d["ns"]["report"] = returned_report
    effect = api.kill; killed = []
    def record_kill(pid, signum):
        killed.append((int(signum), d["clock"].value)); return effect(pid, signum)
    api.kill = record_kill
    if capture_cost is None:
        assert d["ns"]["run"](["INERT_CLI"], "/INERT", {}) == (b"A_TAIL", b"B_TAIL")
        assert not d["owner"].faults and not killed
    else:
        with pytest.raises(OSError) as caught: d["ns"]["run"](["INERT_CLI"], "/INERT", {})
        assert caught.value is original and d["owner"].fault_objects[0] is original
        first = d["owner"].faults[0]
        assert first["operation"].startswith("raw:") and first["observed_monotonic"] == 1
        assert first["errno"]["value"] == errno.EIO and first["arguments"]["items"][1]["value"] == "NESTED_FIRST_RAW_ERROR"
        assert d["owner"].command_cleanup_deadline == first["observed_monotonic"] + 15 == 16
        assert killed == [(2, 5 if capture_cost else 1), (9, 16)]
        assert d["buffers"][0].getvalue() == b"A_TAIL" and d["buffers"][1].getvalue() == b"B_TAIL"
        assert commands[0] == "running" and commands[1] == "cli-grace"
        if capture_cost: assert anchors == [16] and costs == ["persist", "close", "report"]
    api.write, api.close = write, close


@pytest.mark.parametrize("returned", [None, True, "raised"])
def test_h4_control_write_unavailable_count_remains_unknown_without_retry(returned):
    import errno
    from types import SimpleNamespace
    d = _h4_inert([_h4_raw()]); o = d["owner"]; api = d["ns"]["os"]
    write, fstat = api.write, api.fstat; attempted = []; original = OSError(errno.EIO, "CONTROL_WRITE_FAILED")
    api.fstat = lambda fd: d["native_stat"](fd, mode=stat.S_IFREG) if fd == 1 else fstat(fd)
    def failed(fd, raw):
        if fd == 1:
            attempted.append(bytes(raw))
            if returned == "raised": raise original
            return returned
        return write(fd, raw)
    api.write = failed
    with pytest.raises((OSError, d["ns"]["Refusal"])) as caught: o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    assert len(attempted) == len(o.control_writes) == 1
    record = o.control_writes[0]
    assert record["raw"] == attempted[0] and record["sha256"] == hashlib.sha256(attempted[0]).hexdigest()
    assert record["written_bytes"] is record["offset"] is record["accepted_prefix"] is record["missing_ranges"] is None
    assert not record["complete"] and record["stream_offset"] == 0 and o.public_offsets[1] is None
    assert d["buffers"][0].getvalue() == b"" and record["persisted"]
    if returned == "raised": assert caught.value is original and o.fault_objects[0] is original
    else: assert record["returned_value"] is returned
    api.write, api.fstat = write, fstat
    assert o.finish(caught.value) is caught.value and not d["effects"]


@pytest.mark.parametrize("reader_fails", [False, True])
def test_actual_lifecycle_reader_failure_keeps_original_known_witness_safeguard(tmp_path, reader_fails):
    import ast
    import copy
    import tempfile
    from types import SimpleNamespace
    repo = tmp_path / "witness fixture"; (repo / "notebooks").mkdir(parents=True)
    (repo / "notebooks/ordinary-child-pid.txt").write_text("10")
    (repo / "notebooks/engine-kernel-pid.txt").write_text("20")
    notebook = repo / "notebooks/preserved.ipynb"; notebook.write_bytes(b"ORIGINAL_NOTEBOOK")
    driver = _h4_inert([_h4_raw()]); ns = driver["ns"]; stopped = []; launches = []; reads = []
    identities = {pid: dict(pid=pid, birth=["actual inert identity", pid], command="known witness " + str(pid)) for pid in (10, 20)}
    child = SimpleNamespace(pid=99, returncode=None)
    child.poll = lambda: child.returncode
    child.kill = lambda: pytest.fail("returned child must not be killed by fixture fallback")
    with tempfile.TemporaryDirectory(prefix="pre-commit-notebooks-") as root:
        ns["ENTRY"] = repo.resolve(); ns["sys"].argv = ["-", str(HOOK)]
        def context(script, argv, cwd, env):
            result = _hook_context(script, argv, cwd, env)
            owner = ns["Evidence"](Path(root).resolve()); ns["EVIDENCE"] = owner
            owner.prepare(result["entry_pin"]["sha256"])
            ns["actual_report"]("empty", measured_eligible_notebooks=0)
            assert owner.finish(None) is None
            return result
        def communicate(timeout=None):
            assert timeout == 70
            child.returncode = 0
            return (b"CORRUPTED_CURRENT_CONTROL_PREFIX" if reader_fails else driver["buffers"][0].getvalue(), b"")
        child.communicate = communicate
        def spawn(argv, **kwargs):
            launches.append((argv, kwargs)); return child
        def reader(result):
            reads.append(result)
            return _events(result)
        tree = ast.parse(Path(__file__).read_text())
        helper = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "_observe_real_hook_child")
        namespace = dict(dt=dt, time=SimpleNamespace(monotonic=lambda: 0, sleep=lambda _: pytest.fail("witnesses already exist")),
            _index=lambda _: b"ORIGINAL_INDEX", _hook_context=context, _env=_env,
            subprocess=SimpleNamespace(Popen=spawn, PIPE=subprocess.PIPE, CompletedProcess=subprocess.CompletedProcess, TimeoutExpired=subprocess.TimeoutExpired),
            _pid_identity=lambda pid, _: identities[pid], _stop_fixture=lambda identity, _: stopped.append(identity),
            _events=reader, pytest=pytest, json=json, base64=base64, signal=signal)
        exec(compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(helper)], type_ignores=[])),
                     str(HOOK) + ":actual-original-lifecycle-helper", "exec"), namespace)
        if reader_fails:
            with pytest.raises(AssertionError, match="no complete current reference"):
                namespace["_observe_real_hook_child"](repo, HOOK)
            assert stopped == [identities[10], identities[20]]
        else:
            result, known = namespace["_observe_real_hook_child"](repo, HOOK)
            assert result.hook_context["disposition"] == "verified-zero" and known == [identities[10], identities[20]]
            assert not stopped
        assert len(launches) == len(reads) == 1 and child.returncode == 0
        assert notebook.read_bytes() == b"ORIGINAL_NOTEBOOK"
    driver["owner"].finish(None)


@pytest.mark.parametrize("watch", [False, True])
@pytest.mark.parametrize("returned_cost", [.5, 1.25])
def test_h4_positive_returned_communicate_cost_cannot_leave_green_or_erase_exact_eof(watch, returned_cost):
    holder = {}; original = (b"EXACT_RETURNED_OUT", b"EXACT_RETURNED_ERR")
    def command(child, timeout):
        assert timeout == .25
        holder["d"]["clock"].value += returned_cost
        child.returncode = 0
        return original
    d = _h4_inert([_h4_raw()], command=command); holder["d"] = d
    if returned_cost > 1:
        with pytest.raises(d["ns"]["Refusal"], match="remaining scheduling deadline") as caught:
            d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=1, watch=watch)
        assert d["owner"].fault_objects[0] is caught.value
        assert tuple(b.getvalue() for b in d["buffers"]) == original
    else:
        assert d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=1, watch=watch) == original
        assert not d["owner"].faults and all(b.getvalue() == b"" for b in d["buffers"])
    end = next(x for x in d["events"] if x["event"] == "command_end")
    assert end["drain_complete"] and end["reaped"] and end["returncode"] == 0
    assert all(x["state"] == "eof" and x["capture_complete"] for x in end["channels"])
    assert not d["effects"] and len([x for x in d["ordering"] if x[0] == "Popen"]) == 1


@pytest.mark.parametrize("scope", ["startup", "preflight", "nonterminal"])
def test_h4_fault_without_live_command_terminal_ownership_does_not_invent_cleanup_grace(scope):
    d = _h4_inert([_h4_raw()]); o = d["owner"]; d["clock"].value = 5
    o.command_id = None if scope == "startup" else 1
    o.command_child_created = scope == "nonterminal"
    o.phase = "startup" if scope == "startup" else "preflight" if scope == "preflight" else "running"
    o.deadline = 60; original = OSError("ACTUAL_MEMORY_OR_PREFLIGHT_FAULT")
    row = o.fault("actual-" + scope, original, terminal=scope != "nonterminal")
    assert o.fault_objects[0] is original and row["observed_monotonic"] == 5
    assert o.command_cleanup_deadline is None and o.deadline == 60 and not d["effects"]
    assert o.finish(original) is original


@pytest.mark.parametrize("effect_cost", [.25, 16])
def test_h4_returned_cli_effect_cost_is_charged_without_suppressing_required_kill(effect_cost):
    holder = {}; calls = []; original = OSError("FIRST_BEFORE_SIGNAL")
    def command(child, timeout):
        d = holder["d"]; calls.append(d["owner"].phase)
        if len(calls) == 1: raise original
        if child.returncode is None:
            d["clock"].value += timeout
            raise subprocess.TimeoutExpired(["INERT_CLI"], timeout, output=b"OUT", stderr=b"ERR")
        return b"OUT_TAIL", b"ERR_TAIL"
    d = _h4_inert([_h4_raw()], command=command); holder["d"] = d; kill = d["ns"]["os"].kill
    def returned_effect(pid, signum):
        kill(pid, signum)
        if signum == signal.SIGINT: d["clock"].value += effect_cost
    d["ns"]["os"].kill = returned_effect
    with pytest.raises(OSError) as caught: d["ns"]["run"](["INERT_CLI"], "/INERT", {})
    assert caught.value is original and d["owner"].fault_objects[0] is original
    assert d["effects"] == [dict(kind="pid", target=1, signal=2), dict(kind="pid", target=1, signal=9)]
    faults = [x for x in d["owner"].faults if "owned CLI signal failed" in x["operation"]]
    if effect_cost > 15:
        assert len(faults) == 1 and faults[0]["details"]["outcome"] == "returned-after-deadline-or-record-fault"
        assert faults[0]["observed_monotonic"] == 16
    else: assert not faults
    assert d["buffers"][0].getvalue() == b"OUT_TAIL" and d["buffers"][1].getvalue() == b"ERR_TAIL"


# R30 controls execute production owners with explicit inert process/signal seams.
# Only the own-pipe variant uses real public descriptor IO; it creates no child.
def _r30_reference_case(*, command=False, actual_pipe=False):
    import tempfile
    import fcntl
    from types import SimpleNamespace
    d = _h4_inert([_h4_raw()])
    d["owner"].finish(None)
    for buffer in d["buffers"]:
        buffer.seek(0); buffer.truncate()
    d["r30_files"] = tempfile.TemporaryDirectory(prefix="pre-commit-notebooks-")
    context = _hook_context(HOOK, ["bash", str(HOOK)], REPO, os.environ)
    context["pid"] = 99  # Independently known explicit inert getpid boundary.
    d["ns"]["ENTRY"] = REPO.resolve()
    d["ns"]["EVIDENCE"] = d["owner"] = d["ns"]["Evidence"](Path(d["r30_files"].name))
    api, fc = d["ns"]["os"], d["ns"]["fcntl"]
    read_fd = write_fd = None
    if actual_pipe:
        read_fd, write_fd = os.pipe()
        write, fdstat, flags, ioctl = api.write, api.fstat, fc.fcntl, fc.ioctl
        api.write = lambda fd, raw: os.write(write_fd, raw) if fd == 1 else write(fd, raw)
        api.fstat = lambda fd: os.fstat(write_fd) if fd == 1 else fdstat(fd)
        api.fpathconf = lambda fd, name: os.fpathconf(write_fd if fd == 1 else fd, name)
        d["r30_pipe_flag_calls"] = []
        def actual_flags(fd, op, value=None):
            result = (fcntl.fcntl(write_fd, op) if value is None else fcntl.fcntl(write_fd, op, value)) if fd == 1 else flags(fd, op, value)
            d["r30_pipe_flag_calls"].append((fd,op,value,result,fcntl.fcntl(write_fd,fcntl.F_GETFL)))
            return result
        fc.fcntl = actual_flags
        d["r36_pipe_narrow_calls"] = []
        def actual_narrow(fd, request, payload):
            import struct
            if fd != 1: return ioctl(fd, request, payload)
            before = fcntl.fcntl(write_fd, fcntl.F_GETFL)
            value = fcntl.ioctl(write_fd, request, payload)
            after = fcntl.fcntl(write_fd, fcntl.F_GETFL)
            desired = struct.unpack("i", payload)[0]
            d["r36_pipe_narrow_calls"].append(dict(before=before, after=after, desired=desired, returned=value))
            assert request == d["ns"]["termios"].FIONBIO and desired in (0, 1)
            assert after == ((before & ~os.O_NONBLOCK) | (os.O_NONBLOCK if desired else 0))
            return value
        fc.ioctl = actual_narrow
        original_flags = fcntl.fcntl(write_fd, fcntl.F_GETFL)
    else:
        api.fpathconf = lambda fd, name: 512 if fd == 1 else os.fpathconf(fd, name)
    try:
        d["owner"].prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        if command:
            assert d["ns"]["run"](["INERT_CLI"], str(REPO.resolve()), {}, watch=False) == (b"original stdout", b"original stderr")
        d["ns"]["actual_report"]("empty", measured_eligible_notebooks=0)
        problem = d["owner"].finish(None)
        if actual_pipe:
            print("R30_OWN_PIPE_FLAGS " + json.dumps(dict(original=original_flags,owner=d["owner"].flags,calls=d["r30_pipe_flag_calls"],faults=d["owner"].faults,O_NONBLOCK=api.O_NONBLOCK),default=repr))
            protected = os.O_ACCMODE
            for name in ("O_APPEND", "O_ASYNC", "O_FSYNC", "O_SYNC", "O_DSYNC"):
                protected |= getattr(os, name)
            actual_after = fcntl.fcntl(write_fd, fcntl.F_GETFL)
            assert actual_after & (protected | os.O_NONBLOCK) == original_flags & (protected | os.O_NONBLOCK)
            assert len(d["r36_pipe_narrow_calls"]) == 2
            assert [row["desired"] for row in d["r36_pipe_narrow_calls"]] == [1, 0]
            os.close(write_fd); write_fd = None
            pieces = []
            while True:
                raw = os.read(read_fd, 4096)
                if not raw: break
                pieces.append(raw)
            public = b"".join(pieces)
        else:
            public = d["buffers"][0].getvalue()
    finally:
        if write_fd is not None: os.close(write_fd)
        if read_fd is not None: os.close(read_fd)
    context["end_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    result = SimpleNamespace(stdout=public, stderr=d["buffers"][1].getvalue(), returncode=2 if problem else 0, hook_context=context)
    return d, result


@pytest.mark.parametrize("actual_pipe", [False, True])
def test_r30_supported_512_complete_actual_owner_and_reader(actual_pipe):
    d, result = _r30_reference_case(actual_pipe=actual_pipe)
    records = _events(result)
    first, boundary = _control_object(result.stdout)
    last, final_boundary = _control_object(result.stdout, boundary)
    parts = [first, last]
    assert final_boundary == len(result.stdout)
    start, end = [json.loads(x.removeprefix(b"NOTEBOOK_HOOK ")) for x in parts]
    assert d["owner"].atomic == 512 and len(parts) == 2 and all(len(x) <= 512 for x in parts)
    assert result.returncode == 0 and result.hook_context["disposition"] == "verified-zero"
    assert end["start_sha256"] == hashlib.sha256(parts[0]).hexdigest() == d["owner"].accepted_start_sha256
    assert end["events_sha256"] == hashlib.sha256((d["owner"].root/"events.jsonl").read_bytes()).hexdigest()
    assert [x["event"] for x in records] == ["invocation", "empty", "terminal_provisional"]
    assert start["evidence_root"] == str(d["owner"].root) and d["owner"].root.resolve() == d["owner"].root
    assert not d["effects"] and not any(x[0] == "Popen" for x in d["ordering"])


@pytest.mark.parametrize("boundary", ["512", "exact", "terminal-minus-one", "start-minus-one"])
def test_r30_both_reference_preflight_uses_actual_counter_domains_before_launch(boundary):
    import struct
    d = _h4_inert([_h4_raw()]); o = d["owner"]
    o.entry_sha256 = hashlib.sha256(HOOK.read_bytes()).hexdigest()
    o.file_count_max = min(o.native_count_max, 2**os.fpathconf(o.events,"PC_FILESIZEBITS")-1)
    start = o.control_bytes("start")
    template = dict(failed=False, evidence_closed=False, root_descriptor_closed=False,
        fault_count=o.native_count_max, events_identity=o.leaf_identities["events.jsonl"],
        events_bytes=o.file_count_max, events_sha256="f"*64, provisional_until_exit=True, flags_restoration_pending=True)
    terminal = o.control_bytes("terminal", start_binding="f"*64, **template)
    cap = 512 if boundary == "512" else max(len(start),len(terminal)) if boundary == "exact" else len(terminal)-1 if boundary == "terminal-minus-one" else len(start)-1
    d["ns"]["os"].fpathconf = lambda fd, name: cap if fd == 1 else os.fpathconf(fd, name)
    assert o.native_count_max == (1 << (8*struct.calcsize("n")-1))-1
    if boundary in ("512", "exact"):
        o.prepare(o.entry_sha256)
        assert o.finish(None) is None
        assert len(o.control_writes) == 2 and all(x["complete"] and len(x["raw"]) <= cap for x in o.control_writes)
    else:
        with pytest.raises(d["ns"]["Refusal"], match="atomic budget") as original: o.prepare(o.entry_sha256)
        assert not o.control_writes and o.accepted_start_sha256 is None
        o.fault("prepare-capability", original.value)
        assert o.finish(original.value) is original.value
    assert not any(x[0] == "Popen" for x in d["ordering"]) and not d["effects"]


@pytest.mark.parametrize("key", ["fault_count", "events_bytes"])
@pytest.mark.parametrize("value", ["maximum", "overflow", "negative", "boolean"])
def test_r30_terminal_native_counter_domain_refuses_without_truncation(key,value):
    d = _h4_inert([_h4_raw()]); o = d["owner"]; o.atomic = 512
    o.file_count_max = min(o.native_count_max, 2**os.fpathconf(o.events,"PC_FILESIZEBITS")-1)
    fields = dict(failed=False,evidence_closed=False,root_descriptor_closed=False,fault_count=0,
        events_identity=o.leaf_identities["events.jsonl"],events_bytes=0,events_sha256="f"*64,
        provisional_until_exit=True,flags_restoration_pending=True)
    maximum = o.native_count_max if key == "fault_count" else o.file_count_max
    fields[key] = maximum if value == "maximum" else maximum+1 if value == "overflow" else -1 if value == "negative" else True
    if value == "maximum":
        raw = o.control_bytes("terminal",start_binding="f"*64,**fields)
        assert json.loads(raw.removeprefix(b"NOTEBOOK_HOOK "))[key] == maximum and len(raw) <= 512
    else:
        with pytest.raises(d["ns"]["Refusal"],match="native domain"): o.control_bytes("terminal",**fields)
    assert not o.control_writes and o.finish(None) is None


@pytest.mark.parametrize("bits", [0, -1, None, True])
def test_r30_unavailable_native_file_domain_cannot_launch(bits):
    d = _h4_inert([_h4_raw()]); o = d["owner"]
    d["ns"]["os"].fpathconf = lambda fd,name: 512 if fd == 1 else bits
    with pytest.raises(d["ns"]["Refusal"],match="native file counter domain") as first:
        o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    o.fault("file-domain",first.value)
    assert o.finish(first.value) is first.value and not any(x[0] == "Popen" for x in d["ordering"])
    assert o.closed and o.root_closed and d["flags"] == {1:0,2:0}


@pytest.mark.parametrize("corruption", ["digest","source","pid","time","root-identity","root-path","extra-start","extra-terminal","count-bool","flag-type","events-inode","events-bytes","cross-terminal","null-binding","duplicate-start"])
def test_r30_recomputed_pair_digest_cannot_replace_independent_current_witnesses(corruption):
    import copy
    d, result = _r30_reference_case()
    assert _events(result)[-2]["event"] == "empty"
    original = result.stdout
    first, boundary = _control_object(original)
    last, _ = _control_object(original, boundary)
    start,end = [json.loads(x.removeprefix(b"NOTEBOOK_HOOK ")) for x in (first, last)]
    if corruption == "source": start["entry_sha256"] = "0"*64
    elif corruption == "pid": start["observer_pid"] += 1
    elif corruption == "time": start["started_utc"] = "9999-01-01T00:00:00+00:00"
    elif corruption == "root-identity": start["root_identity"] = [0,0]
    elif corruption == "root-path": start["evidence_root"] = str(d["owner"].root.parent)
    elif corruption == "extra-start": start["invented_alias"] = "not a witness"
    elif corruption == "extra-terminal": end["evidence_root"] = start["evidence_root"]
    elif corruption == "count-bool": end["fault_count"] = False
    elif corruption == "flag-type": end["evidence_closed"] = "true"
    elif corruption == "events-inode": end["events_identity"][1] += 1
    elif corruption == "events-bytes": end["events_bytes"] += 1
    elif corruption == "cross-terminal":
        other, other_result = _r30_reference_case()
        _, boundary = _control_object(other_result.stdout)
        end = json.loads(_control_object(other_result.stdout, boundary)[0].removeprefix(b"NOTEBOOK_HOOK "))
    first = b"NOTEBOOK_HOOK "+json.dumps(start,separators=(",",":")).encode()
    end["start_sha256"] = "0"*64 if corruption == "digest" else None if corruption == "null-binding" else hashlib.sha256(first).hexdigest()
    damaged = copy.copy(result); damaged.hook_context = copy.deepcopy(result.hook_context)
    damaged.stdout = first+(first if corruption == "duplicate-start" else b"")+b"NOTEBOOK_HOOK "+json.dumps(end,separators=(",",":")).encode()
    with pytest.raises(AssertionError): _events(damaged)
    assert damaged.hook_context["disposition"] == "protocol-incomplete" and result.stdout == original
    assert result.returncode == 0 and not d["effects"]


@pytest.mark.parametrize("corruption", ["bytes","mode","inode","symlink","missing"])
def test_r30_production_owner_raw_artifact_corruption_cannot_pass_reader(corruption):
    d,result = _r30_reference_case(command=True)
    records = _events(result)
    reference = next(x["available"] for x in records if x["event"] == "command_channel" and x["available"]["bytes"])
    path = d["owner"].root/reference["file"]; raw = path.read_bytes()
    if corruption == "bytes": path.write_bytes(raw+b"WRONG")
    elif corruption == "mode": path.chmod(0o644)
    elif corruption in ("inode","symlink"):
        moved = path.with_name("retained-"+path.name);path.rename(moved)
        if corruption == "inode": path.write_bytes(raw);path.chmod(0o600)
        else:path.symlink_to(moved)
    else:path.unlink()
    with pytest.raises(AssertionError): _events(result)
    assert result.hook_context["disposition"] == "protocol-incomplete" and result.returncode == 0


@pytest.mark.parametrize("fault", ["parent-alias","leaf-symlink","mode","uid","resolve-replacement","open-replacement","escape"])
def test_r30_allocated_canonical_root_requires_same_private_inode(tmp_path,monkeypatch,fault):
    d = _h4_inert([_h4_raw()]); d["owner"].finish(None)
    parent = tmp_path/"actual";parent.mkdir();root=parent/"pre-commit-notebooks-owned";root.mkdir(mode=0o700)
    actual = root.stat(); requested = root
    if fault == "parent-alias":
        alias=tmp_path/"alias";alias.symlink_to(parent,target_is_directory=True);requested=alias/root.name
    elif fault == "leaf-symlink":
        alias=parent/"leaf-alias";alias.symlink_to(root,target_is_directory=True);requested=alias
    elif fault == "mode":root.chmod(0o755)
    elif fault == "uid":d["ns"]["os"].getuid=lambda:os.getuid()+1
    elif fault in ("resolve-replacement","escape"):
        resolve=Path.resolve;seen=[]
        def changed(path,*args,**kwargs):
            if path == parent and not seen:
                seen.append(True)
                if fault == "escape":
                    other=tmp_path/"foreign";other.mkdir();(other/root.name).mkdir(mode=0o700);return other
                root.rename(parent/"retained");root.mkdir(mode=0o700)
            return resolve(path,*args,**kwargs)
        monkeypatch.setattr(Path,"resolve",changed)
    elif fault == "open-replacement":
        opened=d["ns"]["os"].open;seen=[]
        def changed(path,*args,**kwargs):
            if Path(path)==root and not seen:
                seen.append(True);root.rename(parent/"retained");root.mkdir(mode=0o700)
            return opened(path,*args,**kwargs)
        d["ns"]["os"].open=changed
    owner=d["ns"]["Evidence"].__new__(d["ns"]["Evidence"]);d["ns"]["EVIDENCE"]=owner
    if fault == "parent-alias":
        owner.__init__(requested)
        assert owner.root == root.resolve() and owner.root_identity == (actual.st_dev,actual.st_ino)
        assert owner.allocated_root == requested and owner.root.lstat().st_uid == os.getuid()
        assert owner.finish(None) is None
    else:
        with pytest.raises(d["ns"]["Refusal"],match="ownership|identity") as first:owner.__init__(requested)
        assert owner.finish(first.value) is first.value
        if owner.root_fd is not None:
            with pytest.raises(OSError):os.fstat(owner.root_fd)
    assert not any(x[0] == "Popen" for x in d["ordering"]) and not d["effects"]


@pytest.mark.parametrize("phase,window", [("cli-grace",15),("descendant-15",5),("descendant-9",2),("final-drain",2),("final-wait",2),("final-observation",2)])
@pytest.mark.parametrize("exhausted", [False,True])
def test_r30_phase_publication_already_owns_its_original_deadline(phase,window,exhausted):
    holder={};seen=[]
    def command(child,timeout):
        d=holder["d"]
        if child.returncode is None:
            d["clock"].value += min(.25,timeout)
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"FIRST",stderr=b"ERROR")
        return b"FIRST_TAIL",b"ERROR_TAIL"
    def sample():
        d=holder["d"];gone=any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
        return _h4_raw(*([] if gone else [_h4_child()]))
    d=_h4_inert([sample],command=command);holder["d"]=d;o=d["owner"];effect_times=[]
    kill=d["ns"]["os"].kill
    def stamped_kill(pid,signum):
        effect_times.append((o.phase,o.deadline,d["clock"].value,pid,signum))
        return kill(pid,signum)
    d["ns"]["os"].kill=stamped_kill
    class Injected(type(o)):
        def __setattr__(self,key,value):
            super().__setattr__(key,value)
            if key=="phase" and value==phase and not seen:
                seen.append((self.deadline,d["clock"].value))
                d["clock"].value += window+1 if exhausted else .25
                d["ns"]["interrupted"](signal.SIGTERM,None)
    o.__class__=Injected
    original_fault=o.fault;signal_capture=[]
    def capture_fault(operation,error,**kwargs):
        row=original_fault(operation,error,**kwargs)
        if operation=="caught-signal":
            signal_capture.append(dict(fault_id=row["fault_id"],complete=row["complete"],
                persisted=row["persisted"],deadline=o.deadline,observed=row["observed_monotonic"]))
        return row
    o.fault=capture_fault
    with pytest.raises(d["ns"]["Refusal"],match="outer notebook command timeout") as first:
        d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=0,watch=True)
    deadline,tick=seen[0]
    assert deadline is not None and 0 < deadline-tick <= window
    assert o.fault_objects[0] is first.value and any(x["operation"]=="caught-signal" for x in o.fault_records)
    result,records=_h4_closed_records(d,first.value)
    assert result is first.value and o.closed and o.root_closed
    assert all(deadline is None or tick < deadline for _,deadline,tick,_,_ in effect_times)
    if exhausted:assert not any(name==phase for name,_,_,_,_ in effect_times)
    if not exhausted:
        assert any(x["event"]=="fault" and x["operation"]=="caught-signal" for x in records)
    else:
        frozen=next(x for x in signal_capture if x["observed"]>=deadline)
        assert frozen["deadline"]==deadline and not frozen["complete"] and not frozen["persisted"]
        later=next(x for x in o.fault_records if x["fault_id"]==frozen["fault_id"])
        if later["persisted"]:
            completion=next(x for x in records if x["event"]=="fault_completion"and x["fault_id"]==frozen["fault_id"])
            assert completion["completed_monotonic"]>=frozen["observed"]
            assert completion["completion_deadline"]>completion["completed_monotonic"]
            assert completion["phase"]!=phase


@pytest.mark.parametrize("watch", [False,True])
@pytest.mark.parametrize("kind", ["timely","exact","late","persistent","nonzero","raw-fault","signal","unknown","zero"])
def test_r30_rc0_pending_eof_preserves_cap_first_error_and_all_remaining_work(watch,kind):
    holder={};calls=[];unknown=[];bad_write=[];close_cost=[]
    def sample():
        d=holder["d"]
        if kind=="unknown" and watch and calls and d["owner"].phase=="running" and not unknown:
            unknown.append(True);return _h4_raw(_h4_child(state="?"))
        gone=any(x["target"]==10 and x["signal"]==9 for x in d["effects"]) or kind=="timely" and len(calls)>1
        return _h4_raw(*([] if gone else [_h4_child()]))
    def command(child,timeout):
        d=holder["d"];o=d["owner"];calls.append((o.phase,timeout,d["clock"].value))
        if len(calls)==1:
            d["clock"].value += min(.25,timeout);child.returncode=7 if kind=="nonzero" else 0
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"HEAD",stderr=b"ERR")
        if o.phase=="running":
            if kind=="persistent":
                d["clock"].value += timeout
                raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"HEAD",stderr=b"ERR")
            if kind in ("exact","late"):
                d["clock"].value=o.command_settlement_deadline+(0 if kind=="exact" else .125)
            else:d["clock"].value += .125
            if kind=="signal":d["ns"]["interrupted"](signal.SIGTERM,None)
        return b"HEAD_TAIL",b"ERR_TAIL"
    d=_h4_inert([sample],command=command);holder["d"]=d;o=d["owner"];api=d["ns"]["os"]
    if not watch:
        # No actual process observation can occur on the unobserved path.
        d["ns"]["subprocess"].run=lambda *a,**k: (_ for _ in ()).throw(AssertionError("UNEXPECTED_NATIVE_QUERY"))
    write,close=api.write,api.close
    def broken(fd,data):
        if kind=="raw-fault" and len(calls)>1 and o.phase=="running" and fd not in (1,2,o.events) and not bad_write:
            bad_write.append(fd);raise OSError("PENDING_RAW_FIRST")
        return write(fd,data)
    def charged_close(fd):
        result=close(fd)
        if fd in bad_write and not close_cost:close_cost.append(d["clock"].value);d["clock"].value += 4
        return result
    api.write,api.close=broken,charged_close
    successful = kind=="timely" or kind=="unknown" and not watch
    if successful:
        assert d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=60,watch=watch)==(b"HEAD_TAIL",b"ERR_TAIL")
        error=None
    else:
        with pytest.raises(OSError if kind=="raw-fault" else d["ns"]["Refusal"]) as first:d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=0 if kind=="zero" else 60,watch=watch)
        error=first.value
        assert o.fault_objects[0] is error
    assert sum(x[0]=="Popen" for x in d["ordering"])==1
    if kind in ("zero","nonzero"):
        assert o.command_settlement_deadline is None
    else:
        assert o.command_settlement_deadline==pytest.approx(15.25)
        if error:assert o.command_cleanup_deadline <= o.command_settlement_deadline
    if kind=="raw-fault":
        assert o.fault_records[0]["observed_monotonic"]==pytest.approx(.375)
        assert o.fault_records[0]["arguments"]["items"][0]["value"]=="PENDING_RAW_FIRST"
        assert o.command_cleanup_deadline==pytest.approx(15.25) and close_cost
    if kind=="persistent":assert "inherited pipes remain open" in str(error)
    if kind=="nonzero":assert "rc=7 but inherited pipes" in str(error)
    if kind=="unknown" and watch:
        assert unknown and o.fault_records[0]["operation"]=="process-observation-parse"
        assert any(x["event"]=="process_observation" and x["complete"] for x in d["events"])
    result,records=_h4_closed_records(d,error)
    assert result is error and o.closed and o.root_closed
    end=next(x for x in records if x["event"]=="command_end")
    assert end["reaped"] and end["drain_complete"] and end["returncode"]==(7 if kind=="nonzero" else 0)
    assert d["child"].returncode is not None and not any(x["kind"]=="group" for x in d["effects"])
    assert any(x["event"]=="command_channel" for x in records)


@pytest.mark.parametrize("outer", [1,60])
@pytest.mark.parametrize("watch", [False,True])
def test_r30_pending_eof_tightening_cap_intersects_original_outer_deadline(outer,watch):
    holder={};count=[]
    def command(child,timeout):
        d=holder["d"];count.append(timeout)
        if len(count)==1:
            d["clock"].value += .25;child.returncode=0
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"PREFIX",stderr=b"")
        d["clock"].value += min(.125,timeout);return b"PREFIX_TAIL",b""
    d=_h4_inert([_h4_raw()],command=command);holder["d"]=d
    assert d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=outer,watch=watch)==(b"PREFIX_TAIL",b"")
    assert d["owner"].command_settlement_deadline==min(outer,15.25)
    assert d["owner"].command_cleanup_deadline is None and not d["owner"].faults
    assert _h4_closed_records(d,None)[0] is None


@pytest.mark.parametrize("returned", [2,None,True,"raised"])
def test_r30_unaccepted_start_binding_keeps_both_independent_terminal_attempts(returned):
    d=_h4_inert([_h4_raw()]);o=d["owner"];api=d["ns"]["os"];write=api.write;seen=[]
    def broken(fd,raw):
        if fd!=1:return write(fd,raw)
        seen.append(bytes(raw))
        if returned=="raised":raise BrokenPipeError("CONTROL_START_AND_TERMINAL")
        if type(returned) is int:return write(fd,raw[:returned])
        return returned
    api.write=broken
    with pytest.raises((OSError,d["ns"]["Refusal"])) as first:o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    assert o.accepted_start_sha256 is None and o.attempted_start_sha256==hashlib.sha256(seen[0]).hexdigest()
    assert o.finish(first.value) is first.value and len(seen)==len(o.control_writes)==2
    terminal=json.loads(seen[1].removeprefix(b"NOTEBOOK_HOOK "))
    assert terminal["start_sha256"] is None and terminal["failed"] and not any(x[0]=="Popen" for x in d["ordering"])
    assert all(not x["complete"] and x["raw"]==seen[i] for i,x in enumerate(o.control_writes))
    if returned==2:
        assert d["buffers"][0].getvalue()==b"NONO" and [x["stream_offset"] for x in o.control_writes]==[0,2]
        assert all(x["accepted_prefix"]==b"NO" and x["missing_ranges"]==[[2,len(x["raw"])]] for x in o.control_writes)
    else:
        assert not d["buffers"][0].getvalue() and o.public_offsets[1] is None
        assert all(x["written_bytes"] is None and x["accepted_prefix"] is None and x["missing_ranges"] is None for x in o.control_writes)


@pytest.mark.parametrize("watch", [False,True])
@pytest.mark.parametrize("capture_cost", [4,16])
def test_r30_pending_first_capture_cost_never_reopens_reserved_grace(watch,capture_cost):
    holder={};calls=[];failed=[];closed=[]
    def sample():
        d=holder["d"];gone=any(x["target"]==10 and x["signal"]==9 for x in d["effects"])
        return _h4_raw(*([] if gone else [_h4_child()]))
    def command(child,timeout):
        d=holder["d"];calls.append(timeout)
        if len(calls)==1:
            d["clock"].value += .25;child.returncode=0
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"HEAD",stderr=b"ERR")
        if d["owner"].phase=="running":d["clock"].value += .125
        return b"HEAD_TAIL",b"ERR_TAIL"
    d=_h4_inert([sample],command=command);holder["d"]=d;o=d["owner"];api=d["ns"]["os"];write,close=api.write,api.close
    def broken(fd,data):
        if len(calls)>1 and o.phase=="running" and fd not in (1,2,o.events) and not failed:
            failed.append(fd);raise OSError("PENDING_FIRST_EXACT_ARGS")
        return write(fd,data)
    def charged(fd):
        result=close(fd)
        if fd in failed and not closed:closed.append(fd);d["clock"].value += capture_cost
        return result
    api.write,api.close=broken,charged
    with pytest.raises(OSError,match="PENDING_FIRST_EXACT_ARGS") as first:d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=60,watch=watch)
    row=o.fault_records[0]
    assert o.fault_objects[0] is first.value and row["observed_monotonic"]==.375
    assert row["arguments"]["items"][0]["value"]=="PENDING_FIRST_EXACT_ARGS" and row["persisted"]
    assert o.command_settlement_deadline==o.command_cleanup_deadline==15.25 and closed
    assert d["buffers"][0].getvalue()==b"HEAD_TAIL" and d["buffers"][1].getvalue()==b"ERR_TAIL"
    if capture_cost==16:assert not any(x["signal"]==int(signal.SIGINT) for x in d["effects"])
    result,records=_h4_closed_records(d,first.value)
    assert result is first.value and o.closed and o.root_closed
    assert next(x for x in records if x["event"]=="command_end")["reaped"]
    if watch:assert any(x["target"]==10 and x["signal"]==9 for x in d["effects"])


def test_r30_actual_long_allocated_root_refuses_before_launch(tmp_path):
    d=_h4_inert([_h4_raw()]);d["owner"].finish(None)
    parent=tmp_path/("a"*180)/("b"*180);parent.mkdir(parents=True)
    root=parent/"pre-commit-notebooks-long-owned";root.mkdir(mode=0o700)
    o=d["ns"]["Evidence"](root);d["ns"]["EVIDENCE"]=o
    d["ns"]["os"].fpathconf=lambda fd,name:512 if fd==1 else os.fpathconf(fd,name)
    with pytest.raises(d["ns"]["Refusal"],match="atomic budget") as first:o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    assert o.allocated_root==root and o.root_identity==(root.stat().st_dev,root.stat().st_ino)
    assert not o.control_writes and o.accepted_start_sha256 is None
    o.fault("actual-long-reference",first.value)
    assert o.finish(first.value) is first.value and o.closed and o.root_closed
    assert not any(x[0]=="Popen" for x in d["ordering"]) and not d["effects"]


@pytest.mark.parametrize("watch", [False,True])
def test_r30_deferred_channel_recovery_never_launders_contradictory_prefix(watch):
    holder={};calls=[];failed=[];charged=[]
    def command(child,timeout):
        d=holder["d"];calls.append(timeout)
        if len(calls)==1:
            d["clock"].value += .25;child.returncode=0
            raise subprocess.TimeoutExpired(["INERT_CLI"],timeout,output=b"HEAD",stderr=b"ERR")
        if d["owner"].phase=="running":d["clock"].value += .125
        return b"HEAD_TAIL",b"BAD_TAIL"
    d=_h4_inert([_h4_raw()],command=command);holder["d"]=d;o=d["owner"];api=d["ns"]["os"];write,close=api.write,api.close
    def broken(fd,data):
        if len(calls)>1 and o.phase=="running" and fd not in (1,2,o.events) and not failed:
            failed.append(fd);raise OSError("PENDING_BEFORE_CONTRADICTION")
        return write(fd,data)
    def cost(fd):
        result=close(fd)
        if fd in failed and not charged:charged.append(fd);d["clock"].value += 16
        return result
    api.write,api.close=broken,cost
    with pytest.raises(OSError,match="PENDING_BEFORE_CONTRADICTION") as first:d["ns"]["run"](["INERT_CLI"],"/INERT",{},timeout=60,watch=watch)
    assert o.fault_objects[0] is first.value and o.command_cleanup_deadline==o.command_settlement_deadline==15.25
    assert d["buffers"][0].getvalue()==b"HEAD_TAIL" and d["buffers"][1].getvalue()==b"ERR"
    assert any(x["error"]=="command cumulative buffer contradicts retained prefix" for x in o.faults)
    result,records=_h4_closed_records(d,first.value)
    assert result is first.value
    contradiction=next(x["available"] for x in records if x["event"]=="contradictory_command_buffer")
    assert (o.root/contradiction["file"]).read_bytes()==b"BAD_TAIL"
    assert not any(x["kind"]=="group" for x in d["effects"])


def _r36_native_snapshot(fd):
    """Independent direct native observation of a retained caller-owned resource."""
    import fcntl
    import struct
    import termios
    def stamp():
        return dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(), mono=time.monotonic())
    before = stamp()
    st = os.fstat(fd)
    identity = {key: getattr(st, "st_" + key) for key in ("dev", "ino", "rdev", "mode", "uid", "gid")}
    descriptor, status = fcntl.fcntl(fd, fcntl.F_GETFD), fcntl.fcntl(fd, fcntl.F_GETFL)
    terminal, discipline = None, None
    if stat.S_ISCHR(st.st_mode):
        attrs = termios.tcgetattr(fd)
        terminal = dict(zip(("iflag", "oflag", "cflag", "lflag", "ispeed", "ospeed"), attrs[:6]))
        terminal["cc_native"] = dict(type=type(attrs[6]).__name__, items=[
            dict(type="bytes", hex_chunks=[item.hex()], bytes=len(item), complete=True) if type(item) is bytes else
            dict(type="int", value=item, complete=True) for item in attrs[6]], complete=True)
        discipline = struct.unpack("i", fcntl.ioctl(fd, termios.TIOCGETD, struct.pack("i", 0)))[0]
    return dict(started=before, ended=stamp(), identity=identity, status_flags=status,
                descriptor_flags=descriptor, termios=terminal, discipline=discipline, complete=True, fault_id=None)


def _r36_native_case(route, initial=False, *, earlier_error=False, payload=None, stderr_payload=None, mutate=None, inspect=None, expected_effects=(), expected_launches=1, expected_capture="full", receiver_policy="cooperative"):
    capture=_H94FixtureCapture("r36-owned-native")
    d=None;owner=None;outcome=None;native={};groups={};independent={};post=_H94_UNOBSERVED
    received={};receive_trace=[];boundary_trace=[];result=None;context=_H94_UNOBSERVED
    try:
        """Actual owned native IO, original Evidence/run and SAME reader; no child/native ps."""
        import contextlib
        import errno
        import fcntl
        import socket
        import struct
        import tempfile
        import termios
        import tty
        from types import SimpleNamespace
        source = payload if payload is not None else b"LF\nCR\rCRLF\r\nTAB\tNUL\0EOT\x04BS\x08ESC\x1bCTRL\x01UTF8\xc3\xa9BAD\xffNOTEBOOK_HOOK {\"event\":\"terminal\"}END"
        error_source = b"ERR:" + source if stderr_payload is None else stderr_payload
        assert route in {"pipe", "pipe-shared", "fifo", "fifo-shared", "socket", "socket-shared", "file-separate", "file-append", "file-shared", "file-independent", "file-overwrite", "pty-normal", "pty-normal-shared", "pty-raw"}
        def command(child, timeout):
            child.returncode = 7 if earlier_error else 0
            return source, error_source
        if receiver_policy not in {"cooperative","undrained"}:raise ValueError("unknown receiver policy")
        d = _h4_inert([_h4_raw()], command=command)
        capture.finish(d["owner"],None,"initial-inert")
        marker=REPO/".git"
        admin=marker if marker.is_dir() else Path(marker.read_text().strip().removeprefix("gitdir: "))
        if not admin.is_absolute():admin=REPO/admin
        index_path=admin/"index";index_before=index_path.read_bytes()
        entry_before=(HOOK.read_bytes(),stat.S_IMODE(HOOK.stat().st_mode))
        with contextlib.ExitStack() as resources:
            try:
                d["r36_files"] = tempfile.TemporaryDirectory(prefix="pre-commit-notebooks-")
                directory = Path(d["r36_files"].name)
                d["ns"]["ENTRY"] = REPO.resolve()
                context = _hook_context(HOOK, ["bash", str(HOOK)], REPO, os.environ);context["pid"] = 99
                capture.context=context
                owner = d["ns"]["Evidence"](directory);d["owner"] = d["ns"]["EVIDENCE"] = owner
                observed_call = dict(argv=context["argv"], cwd=context["cwd"], pid=context["pid"])
                native, receivers, groups, group_for = {}, {}, {}, {}
                def owned(fd):
                    capture.register(resources,[(os.close,(fd,))])
                    return fd
                def endpoint(kind, number):
                    assert kind in {"pipe", "fifo", "socket", "pty-normal", "pty-raw"}
                    if kind == "pipe":
                        read, write = os.pipe();capture.register(resources,[(os.close,(read,)),(os.close,(write,))])
                    elif kind == "fifo":
                        path = directory / ("fifo-" + str(number));os.mkfifo(path, 0o600)
                        write = owned(os.open(path, os.O_RDWR | os.O_NONBLOCK))
                        read = owned(os.open(path, os.O_RDONLY | os.O_NONBLOCK))
                    elif kind == "socket":
                        receiver, sender = socket.socketpair()
                        capture.register(resources,[(receiver.close,()),(sender.close,())])
                        read, write = receiver.fileno(), sender.fileno()
                    else:
                        read, write = os.openpty();capture.register(resources,[(os.close,(read,)),(os.close,(write,))])
                        original = termios.tcgetattr(write)
                        capture.register(resources,[(termios.tcsetattr,(write,termios.TCSANOW,original))])
                        if kind == "pty-raw": tty.setraw(write, termios.TCSANOW)
                    fcntl.ioctl(read, termios.FIONBIO, struct.pack("i", 1))
                    return read, write
                file_route = route.startswith("file")
                shared = route.endswith("shared")
                if route == "file-separate":
                    for descriptor in (1, 2):
                        target = directory / ("separate-output-" + str(descriptor))
                        target.write_bytes(b"RETAINED_INITIAL_FILE\n")
                        native[descriptor] = owned(os.open(target, os.O_WRONLY))
                        os.lseek(native[descriptor], 0, os.SEEK_END)
                        key = "file-" + str(descriptor);group_for[descriptor] = key
                        groups[key] = dict(fds=[descriptor], kind="file", initial_image=target.read_bytes(),
                            file_image_witness=dict(source="actual-initial-and-final-file-images", path=str(target)))
                elif file_route:
                    path = directory / "actual-output";path.write_bytes(b"RETAINED_INITIAL_FILE\n")
                    append = route in {"file-append", "file-shared", "file-independent"}
                    first = owned(os.open(path, os.O_WRONLY | (os.O_APPEND if append else 0)))
                    os.lseek(first, 0, os.SEEK_END)
                    second = owned(os.dup(first)) if route == "file-shared" else owned(os.open(path, os.O_WRONLY | (0 if route == "file-overwrite" else os.O_APPEND)))
                    os.lseek(second, 0, os.SEEK_SET if route == "file-overwrite" else os.SEEK_END)
                    native = {1: first, 2: second};group_for = {1: "file", 2: "file"}
                    groups["file"] = dict(fds=[1, 2], kind="file", initial_image=path.read_bytes(),
                        description_groups={1: "first", 2: "first" if route == "file-shared" else "second"},
                        description_witness=dict(observed_call=observed_call, creation="dup" if route == "file-shared" else "independent-opens",
                                                 actual_opens=[str(path), str(path)]),
                        file_image_witness=dict(source="actual-initial-and-final-file-images", path=str(path)))
                else:
                    kind = route.removesuffix("-shared")
                    read, write = endpoint(kind, 1);native[1] = write;receivers["first"] = read;group_for[1] = "first"
                    if shared:
                        native[2] = owned(os.dup(write));group_for[2] = "first"
                        groups["first"] = dict(fds=[1, 2], kind="stream", description_groups={1: "first", 2: "first"},
                            description_witness=dict(observed_call=observed_call, creation="dup"))
                    else:
                        read2, write2 = endpoint(kind, 2);native[2] = write2;receivers["second"] = read2;group_for[2] = "second"
                        groups = {"first": dict(fds=[1], kind="stream"), "second": dict(fds=[2], kind="stream")}
                for descriptor in (1, 2):
                    desired = initial if type(initial) is bool else initial[descriptor]
                    fcntl.ioctl(native[descriptor], termios.FIONBIO, struct.pack("i", int(desired)))
                independent = {}
                for fd in (1,2):
                    independent[fd] = dict(source="actual-pre-call-native-observation", snapshot=_r36_native_snapshot(native[fd]),
                    regular_position=os.lseek(native[fd],0,os.SEEK_CUR) if file_route else None,
                    description_witness=dict(actual_fd=native[fd], creation="caller-owned", group=group_for[fd],
                        description=groups[group_for[fd]].get("description_groups", {fd: fd})[fd]))
                api, fc, terminal = d["ns"]["os"], d["ns"]["fcntl"], d["ns"]["termios"]
                private_write, private_stat, private_conf = api.write, api.fstat, api.fpathconf
                def native_flags(fd, operation, value=None):
                    assert fd in (1, 2) and operation in (fc.F_GETFL, fc.F_GETFD) and value is None
                    return fcntl.fcntl(native[fd], operation)
                effects = []
                def narrow(fd, request, value):
                    assert fd in (1, 2) and request in (termios.FIONBIO, termios.TIOCGETD)
                    before = fcntl.fcntl(native[fd], fcntl.F_GETFL)
                    returned = fcntl.ioctl(native[fd], request, value)
                    after = fcntl.fcntl(native[fd], fcntl.F_GETFL)
                    if request == termios.FIONBIO:
                        desired = struct.unpack("i", value)[0]
                        effects.append(dict(fd=fd, before=before, after=after, desired=desired, returned=returned))
                        assert after == ((before & ~os.O_NONBLOCK) | (os.O_NONBLOCK if desired else 0))
                    return returned
                api.write = lambda fd, raw: os.write(native[fd], raw) if fd in native else private_write(fd, raw)
                api.fstat = lambda fd: os.fstat(native[fd]) if fd in native else private_stat(fd)
                api.fpathconf = lambda fd, name: os.fpathconf(native[fd], name) if fd in native else private_conf(fd, name)
                api.lseek = lambda fd, offset, how: os.lseek(native[fd], offset, how)
                fc.fcntl, fc.ioctl = native_flags, narrow
                terminal.tcgetattr = lambda fd: termios.tcgetattr(native[fd])
                import select as actual_select
                received={key:[]for key in receivers}
                receive_trace=[];boundary_trace=[]
                d["h84_native_receive_trace"]=receive_trace;d["h84_native_boundaries"]=boundary_trace
                def receive_available(host_deadline=None,phase="during"):
                    for key,receiver in receivers.items():
                        while True:
                            if host_deadline is not None and time.monotonic()>=host_deadline:return False
                            began=time.monotonic()
                            try:raw=os.read(receiver,4096)
                            except OSError as error:
                                receive_trace.append(dict(group=key,fd=receiver,phase=phase,host_started=began,
                                    host_ended=time.monotonic(),outcome="raised",errno=error.errno,arguments=error.args))
                                if error.errno in(errno.EAGAIN,errno.EWOULDBLOCK):break
                                raise
                            receive_trace.append(dict(group=key,fd=receiver,phase=phase,host_started=began,
                                host_ended=time.monotonic(),outcome="returned",raw_hex=raw.hex(),count=len(raw)))
                            if not raw:break
                            received[key].append(raw)
                    return True
                def native_ready(read,write,error,timeout):
                    assert read==[] and error==[] and len(write)==1 and write[0]in native and timeout>0
                    descriptor=write[0];began=time.monotonic();tick=d["clock"].value
                    row=dict(fd=descriptor,native_fd=native[descriptor],host_started=began,
                        fixture_before=tick,original_timeout=timeout,select_attempted=False)
                    boundary_trace.append(row)
                    try:
                        drained=receive_available(began+timeout) if receiver_policy=="cooperative" else True
                        remaining=timeout-(time.monotonic()-began)
                        row["remaining_after_receive"]=remaining
                        if not drained or remaining<=0:
                            row["outcome"]="original-remainder-exhausted"
                            return [],[],[]
                        row["select_attempted"]=True
                        ready=actual_select.select([], [native[descriptor]], [], remaining)
                        row["actual_select_return"]=ready
                        row["outcome"]="returned"
                        return [], [descriptor] if ready[1]==[native[descriptor]] else [], []
                    except BaseException as error:
                        row["outcome"]="raised";row["error"]=(type(error).__name__,error.args)
                        raise
                    finally:
                        ended=time.monotonic();elapsed=ended-began
                        d["clock"].value+=elapsed
                        row.update(host_ended=ended,charged=elapsed,fixture_after=d["clock"].value)
                d["ns"]["select"].select=native_ready
                if mutate is not None: mutate(d, native)
                try:
                    owner.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
                except BaseException as error:
                    capture.fault("owner-prepare",error)
                    capture.attempt("prepare-fault-report",owner.fault,"native-fixture-prepare",error)
                    capture.attempt("prepare-producer-before-finish",capture.producer_observed,owner,"prepare-failure-before-finish")
                    capture.attempt("prepare-finish",capture.finish,owner,error,"actual-prepare-failure")
                    after_failure={}
                    for descriptor in (1,2):
                        try:after_failure[descriptor]=_r36_native_snapshot(native[descriptor])
                        except BaseException as later:
                            after_failure[descriptor]=dict(complete=False,type=type(later).__module__+"."+type(later).__qualname__,
                                arguments=d["ns"]["typed_native"](BaseException.args.__get__(later)))
                    capture.attempt("prepare-producer-after-finish",capture.producer_observed,owner,"prepare-failure-after-finish")
                    raise
                problem = None;unexpected=None
                try:
                    d["ns"]["run"](["INERT_CLI"], str(REPO.resolve()), {}, watch=False)
                except BaseException as error:
                    problem = error
                    if not isinstance(error,d["ns"]["Refusal"]):
                        unexpected=error;capture.fault("run-unexpected",error)
                if problem is None:capture.attempt("actual-success-report",d["ns"]["actual_report"],"success")
                capture.attempt("producer-before-actual-finish",capture.producer_observed,owner,"before-actual-finish")
                problem = capture.finish(owner,problem,"actual-post-run")
                capture.attempt("producer-after-actual-finish",capture.producer_observed,owner,"after-actual-finish")
                post = dict(source="retained-actual-open-descriptions-after-owner-return", observed_call=observed_call,
                    descriptors={fd: dict(description_witness=independent[fd]["description_witness"], phase="after-actual-owner-return",
                        regular_position=os.lseek(native[fd],0,os.SEEK_CUR) if file_route else None,
                        snapshot=_r36_native_snapshot(native[fd])) for fd in (1, 2)})
                if file_route:
                    for group in groups.values():
                        group["wire"] = Path(group["file_image_witness"]["path"]).read_bytes()
                else:
                    receive_available(phase="final")
                    for key in receivers:groups[key]["wire"]=b"".join(received[key])
                if unexpected is not None:raise unexpected
                context["transport"] = dict(observed_call=observed_call, groups=groups, control_group=group_for[1],
                    control_offset=len(groups[group_for[1]]["initial_image"]) if file_route else 0, profiles=independent, post_state=post)
                context["end_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
                result = SimpleNamespace(stdout=groups[group_for[1]]["wire"],
                    stderr=b"" if group_for[1] == group_for[2] else groups[group_for[2]]["wire"],
                    returncode=2 if problem else 0, hook_context=context)
                if inspect is not None: inspect(d, result)
                records = _events(result)
                ending = next(x for x in records if x["event"] == "command_end")
                assert expected_capture in {"full","not-created"}
                expected_sources=(source,error_source) if expected_capture=="full" else (b"",b"")
                if expected_capture=="not-created":
                    assert problem is not None and expected_launches==0
                    assert not any(row[0]=="communicate"for row in d["ordering"])
                    assert not any(row["event"]=="command_channel"for row in records)
                if expected_capture=="full":
                    assert ending["channels"][0]["bytes"] == len(source)
                    assert ending["channels"][0]["sha256"] == hashlib.sha256(source).hexdigest()
                    assert ending["channels"][1]["bytes"] == len(error_source)
                    assert ending["channels"][1]["sha256"] == hashlib.sha256(error_source).hexdigest()
                else:
                    assert all(row["bytes"]==0 and row["sha256"]==hashlib.sha256(b"").hexdigest()
                               and row["state"]=="not-created"for row in ending["channels"])
                for channel, expected_source in enumerate(expected_sources):
                    actual_source=b"".join((owner.root/row["available"]["file"]).read_bytes()
                        for row in records if row["event"]=="command_channel" and row["channel"]==channel)
                    assert actual_source==expected_source
                assert index_path.read_bytes()==index_before
                assert (HOOK.read_bytes(),stat.S_IMODE(HOOK.stat().st_mode))==entry_before
                if not expected_effects and expected_launches==1:
                    assert d["effects"] == [] and sum(x[0] == "Popen" for x in d["ordering"]) == 1
                assert d["effects"] == list(expected_effects)
                assert sum(x[0] == "Popen" for x in d["ordering"]) == expected_launches
                outcome = dict(driver=d, result=result, records=records, effects=effects, source=source, problem=problem)
            except BaseException as error:
                if capture.first is None or capture.first["object"] is not error:capture.fault("native-fixture-body",error)
            finally:
                # Constructor already owns its root fd even when endpoint setup failed.
                # Use the original failure finish once; never retry a partially entered finish.
                if owner is not None and not any(row["owner_id"]==id(owner) for row in capture.finishes):
                    failure=capture.first["object"] if capture.first else None
                    if failure is not None:
                        capture.attempt("setup-producer-before-finish",capture.producer_observed,owner,"setup-failure-before-finish")
                        capture.attempt("setup-failure-finish",capture.finish,owner,failure,"actual-prepare-failure")
                capture.attempt("precleanup-freeze",lambda: capture.freeze(dict(route=route,initial=initial,receiver_policy=receiver_policy,
                    argv=_H94_UNOBSERVED if context is _H94_UNOBSERVED else context["argv"],
                    cwd=_H94_UNOBSERVED if context is _H94_UNOBSERVED else context["cwd"],
                    pid=_H94_UNOBSERVED if context is _H94_UNOBSERVED else context["pid"],
                    stored_returncode=_H94_UNOBSERVED if result is None else result.returncode,
                    original_source=source,original_stderr=error_source,groups=groups,
                    actual_received_pieces=received if receive_trace else _H94_UNOBSERVED,read_attempts=receive_trace,readiness=boundary_trace,
                    independent_before=independent,actual_post=post)))
                capture.close_stack(resources)
        capture.outer_exited=True
    except BaseException as error:
        if capture.first is None or capture.first["object"] is not error:capture.fault("native-fixture-entry-or-exit",error)
    if d is not None:d["h94_fixture_capture"]=capture
    capture.emit()
    capture.propagate()
    return outcome

@pytest.mark.parametrize("route", ["pipe", "pipe-shared", "fifo", "fifo-shared", "socket", "socket-shared", "file-separate", "file-append", "file-shared", "file-independent", "pty-normal", "pty-normal-shared", "pty-raw"])
@pytest.mark.parametrize("initial", [False, True])
@pytest.mark.parametrize("earlier_error", [False, True])
def test_r36_actual_native_owner_same_reader_and_independent_restoration(route, initial, earlier_error):
    outcome = _r36_native_case(route, initial, earlier_error=earlier_error)
    owner, result, records = outcome["driver"]["owner"], outcome["result"], outcome["records"]
    assert result.returncode == (2 if earlier_error else 0)
    assert result.hook_context["verification"]["actual_flags_independently_observed"] is True
    assert result.hook_context["transport_verification"]["exact_private_source"] is True
    assert result.hook_context["transport_verification"]["normalized_received_bytes"] is False
    assert all(row["complete"] for row in owner.public_effects)
    assert all(row["after"]["status_flags"] == ((row["before"]["status_flags"] & ~os.O_NONBLOCK) |
        (os.O_NONBLOCK if row["desired_nonblocking"] else 0)) for row in owner.public_effects)
    assert all(not row["attempted"] for row in owner.public_effects) if initial else bool(outcome["effects"])
    assert owner.closed and owner.root_closed
    assert [x["command_id"] for x in records if x["event"] == "command_begin"] == [1]
    assert (outcome["problem"] is not None) is earlier_error


@pytest.mark.parametrize("fault", ["fstat", "getfd", "getfl", "ioctl", "ioctl-result", "mode", "descriptor-type", "status-type", "status-range", "termios", "discipline", "control-array"])
@pytest.mark.parametrize("descriptor", [1,2])
def test_r36_native_capability_faults_preserve_actual_first_and_do_not_launch(fault, descriptor):
    import errno
    import struct
    import termios
    d = _h4_inert([_h4_raw()]);o=d["owner"];api=d["ns"]["os"];fc=d["ns"]["fcntl"]
    actual = OSError(errno.EIO, "R36_NATIVE_" + fault)
    fdstat, flags, ioctl = api.fstat, fc.fcntl, fc.ioctl
    if fault == "fstat":
        def failed(fd):
            if fd == descriptor:raise actual
            return fdstat(fd)
        api.fstat=failed
    elif fault in {"getfd", "getfl", "descriptor-type", "status-type", "status-range"}:
        def failed(fd, operation, value=None):
            if fd == descriptor:
                if operation == (fc.F_GETFD if fault == "getfd" else fc.F_GETFL) and fault in {"getfd", "getfl"}:raise actual
                if operation == fc.F_GETFD and fault == "descriptor-type":return True
                if operation == fc.F_GETFL and fault == "status-type":return None
                if operation == fc.F_GETFL and fault == "status-range":return -1
            return flags(fd, operation, value)
        fc.fcntl=failed
    elif fault in {"ioctl", "ioctl-result"}:
        def failed(fd, request, payload):
            if fd == descriptor:
                if fault == "ioctl":raise actual
                return True
            return ioctl(fd, request, payload)
        fc.ioctl=failed
    elif fault == "mode":
        d["identities"][descriptor]["st_mode"] = stat.S_IFDIR
    else:
        d["identities"][descriptor]["st_mode"] = stat.S_IFCHR
        d["terminal_attributes"][descriptor] = [0, termios.OPOST | termios.ONLCR, termios.CS8, 0, 9600, 9600, [b"\0"] * termios.NCCS]
        d["disciplines"][descriptor] = 0
        if fault == "termios":
            def failed(fd):raise actual
            d["ns"]["termios"].tcgetattr=failed
        elif fault == "discipline":d["disciplines"][descriptor] = 1
        else:d["terminal_attributes"][descriptor][6][0] = b"TWO"
    with pytest.raises((OSError, d["ns"]["Refusal"])) as caught:o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    o.fault("prepare-capability", caught.value)
    assert o.fault_objects[0] is caught.value
    assert o.faults[0]["observed_monotonic"] == 0
    if fault in {"descriptor-type","status-type","status-range"}:
        observed=o.public_observations[-1]["snapshot"]
        assert observed["descriptor_flags" if fault=="descriptor-type" else "status_flags"] is None
        assert observed["complete"] is False
        details={key["value"]:value for key,value in o.faults[0]["details"]["items"]}
        native={key["value"]:value for key,value in details["native_results"]["items"]}
        result=native["descriptor_flags" if fault=="descriptor-type" else "status_flags"]
        assert result==dict(type="bool",value=True,complete=True) if fault=="descriptor-type" else result==dict(type="none",complete=True) if fault=="status-type" else result==dict(type="int",value=-1,complete=True)
    if fault in {"fstat", "getfd", "getfl", "ioctl", "termios"}:
        assert caught.value is actual and o.faults[0]["arguments"]["items"][1]["value"] == "R36_NATIVE_" + fault
    assert o.finish(caught.value) is caught.value
    assert not any(row[0] == "Popen" for row in d["ordering"]) and not d["effects"]
    assert o.closed and o.root_closed
    assert all(not value & os.O_NONBLOCK for value in d["flags"].values())


@pytest.mark.parametrize("initial", [False, True])
def test_r36_shared_baselines_precede_effects_and_final_audits_follow_both_restores(initial):
    d = _h4_inert([_h4_raw()]);o=d["owner"];fc=d["ns"]["fcntl"];trace=[]
    d["descriptions"][2]=d["descriptions"][1]
    d["identities"][2]=dict(d["identities"][1])
    d["flags"].update({1:os.O_NONBLOCK if initial else 0,2:os.O_NONBLOCK if initial else 0})
    flags,ioctl=fc.fcntl,fc.ioctl
    def get(fd, operation, value=None):
        trace.append(("read", fd, o.phase, operation));return flags(fd,operation,value)
    def effect(fd, operation, value):
        trace.append(("effect", fd, o.phase, operation));return ioctl(fd,operation,value)
    fc.fcntl,fc.ioctl=get,effect
    o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    assert all(bool(x["status_flags"] & os.O_NONBLOCK) is initial for x in o.public_baselines.values())
    if not initial:
        first=next(i for i,row in enumerate(trace) if row[0]=="effect")
        assert {row[1] for row in trace[:first] if row[0]=="read"} == {1,2}
    assert o.finish(None) is None
    assert d["flags"] == {1:os.O_NONBLOCK if initial else 0,2:os.O_NONBLOCK if initial else 0}
    audits=[row for row in trace if row[2].startswith("public-flags-verify:")]
    assert {row[1] for row in audits} == {1,2}
    assert not any(row[0]=="effect" for row in trace[trace.index(audits[0]):])
    if initial:assert not any(row[0]=="effect" for row in trace)


@pytest.mark.parametrize("fault", ["mutation-then-raise", "replacement", "prewrite-nb-loss", "unowned-control", "late-query"])
@pytest.mark.parametrize("earlier_error", [False, True])
def test_r36_native_effect_faults_keep_first_and_independent_second_work(fault, earlier_error):
    import errno
    import struct
    d=_h4_inert([_h4_raw()]);o=d["owner"];api=d["ns"]["os"];fc=d["ns"]["fcntl"]
    original=OSError(errno.EIO,"R36_EFFECT_FAULT");ioctl=fc.ioctl;flags=fc.fcntl;seen=[]
    if fault=="mutation-then-raise":
        first=None
        if earlier_error:
            o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
            first=d["ns"]["Refusal"]("ORIGINAL_SCIENTIFIC_ERROR");o.fault("original-scientific-error",first)
        def failed(fd,request,payload):
            result=ioctl(fd,request,payload)
            if fd==1 and not seen:seen.append(fd);raise original
            return result
        fc.ioctl=failed
        if first is None:
            with pytest.raises(OSError) as caught:o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
            assert caught.value is original and o.public_acquired[1] is True
            assert o.finish(original) is original and o.fault_objects[0] is original
        else:
            assert o.finish(first) is first and o.fault_objects[0] is first
            assert any(error is original for error in o.fault_objects)
            assert not d["flags"][2] & os.O_NONBLOCK
        assert not d["flags"][1] & os.O_NONBLOCK
        return
    o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    first=d["ns"]["Refusal"]("ORIGINAL_SCIENTIFIC_ERROR") if earlier_error else None
    if first is not None:o.fault("original-scientific-error",first)
    if fault=="replacement":d["identities"][1]["st_ino"]+=1
    elif fault=="prewrite-nb-loss":
        d["flags"][1]&=~os.O_NONBLOCK
        with pytest.raises(d["ns"]["Refusal"],match="nonblocking") as lost:
            o.relay(1,b"MUST_NOT_WRITE",[0,0],0,None)
        if first is None:first=lost.value
        assert d["buffers"][0].getvalue() == o.control_writes[0]["raw"]
    elif fault=="unowned-control":d["flags"][1]|=os.O_APPEND
    else:
        def failed(fd,operation,value=None):
            if fd==1 and operation==fc.F_GETFL and o.phase=="public-flags-verify:1":raise original
            return flags(fd,operation,value)
        fc.fcntl=failed
    def tracked(fd,request,payload):
        seen.append((fd,struct.unpack("i",payload)[0],o.phase));return ioctl(fd,request,payload)
    fc.ioctl=tracked
    problem=o.finish(first)
    assert problem is not None and o.closed and o.root_closed
    assert problem is o.fault_objects[0]
    assert any(fd==2 and phase=="public-flags-restore:2" for fd,_,phase in seen)
    assert not d["flags"][2] & os.O_NONBLOCK
    if first is not None:assert problem is first and o.fault_objects[0] is first
    if fault=="replacement":assert not any(fd==1 for fd,_,_ in seen)
    if fault=="unowned-control":assert d["flags"][1] & os.O_APPEND
    if fault=="late-query":
        assert any(error is original for error in o.fault_objects)
        later=next(row for error,row in zip(o.fault_objects,o.fault_records) if error is original)
        assert later["phase"]=="public-flags-verify:1" and later["observed_monotonic"]==0
        assert later["arguments"]["items"][1]["value"]=="R36_EFFECT_FAULT"
        assert not d["flags"][1] & os.O_NONBLOCK


@pytest.mark.parametrize("route", ["pipe-shared", "file-shared", "pty-normal-shared"])
def test_r36_prior_negative_does_not_hide_actual_missing_restore_from_same_reader(route):
    observed=[]
    def mutate(d,native):
        narrow=d["owner"].public_narrow
        def omit(fd,desired,deadline=None):
            if not desired:return None
            return narrow(fd,desired,deadline)
        d["owner"].public_narrow=omit
    def inspect(d,result):
        assert result.returncode==2
        state=result.hook_context["transport"]["post_state"]["descriptors"]
        assert all(row["snapshot"]["status_flags"] & os.O_NONBLOCK for row in state.values())
        assert d["owner"].fault_objects[0].args==("command failed once (not rerun): ['INERT_CLI'] rc=7",)
        observed.append(result)
    with pytest.raises(AssertionError):_r36_native_case(route,earlier_error=True,mutate=mutate,inspect=inspect)
    assert observed and observed[0].hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("payload", [b"", b"\n", b"\r", b"\r\n", b"\t\0\x04\x08\x1b\x01\xff\xc3\xa9", b'NOTEBOOK_HOOK {"event":"terminal","nested":["\\\""]}',
    b"Traceback (most recent call last):\nCellExecutionError: STRICT_POISON\nCONFIG_POISON RENAME_POISON ROOT_COORDINATE_POISON\nPIPE_COMPANION_ORIGINAL_SENTINEL\n"])
def test_r36_normal_pty_exact_private_source_and_forward_wire_complements(payload):
    outcome=_r36_native_case("pty-normal-shared",earlier_error=True,payload=payload,stderr_payload=b"")
    import copy
    actual=outcome["result"];damaged=copy.copy(actual);damaged.hook_context=copy.deepcopy(actual.hook_context)
    profile=damaged.hook_context["transport"]["profiles"][1]["snapshot"]
    assert profile["termios"] is not None
    group=damaged.hook_context["transport"]["groups"]["first"]
    if b"\n" in payload:
        assert payload.replace(b"\n",b"\r\n") in group["wire"]
        original=group["wire"];position=original.index(payload.replace(b"\n",b"\r\n"))
        group["wire"]=original[:position]+payload+original[position+len(payload.replace(b"\n",b"\r\n")):]
        with pytest.raises(AssertionError):_events(damaged)
        assert actual.hook_context["transport"]["groups"]["first"]["wire"]==original
    assert outcome["driver"]["owner"].public_profiles[1]["before"]["termios"]==profile["termios"]


def test_r36_actual_regular_multiwrite_source_suffixes_and_empty_channels():
    payload=(b"MULTI\n\r\n\xffNOTEBOOK_HOOK {}"*500)+b"TAIL"
    outcome=_r36_native_case("file-append",earlier_error=True,payload=payload,stderr_payload=b"")
    rows=outcome["driver"]["owner"].public_writes
    assert len(rows)>2 and [row["sequence"] for row in rows]==list(range(1,len(rows)+1))
    assert sum(row["written_source_bytes"] for row in rows if row["channel"]==0)==len(payload)
    assert all(row["source_end"]-row["source_start"]<=4096 for row in rows)
    assert outcome["records"][-1]["public_write_count"]==len(rows)


@pytest.mark.parametrize("name", ["O_APPEND", "O_ASYNC", "O_FSYNC", "O_SYNC", "O_DSYNC"])
@pytest.mark.parametrize("changed", [False, True])
def test_r36_every_protected_control_is_retained_and_foreign_change_is_not_overwritten(name, changed):
    d=_h4_inert([_h4_raw()]);o=d["owner"]
    bit=getattr(os,name);d["flags"][1]|=bit
    o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    baseline=o.public_baselines[1]["status_flags"]
    if changed:d["flags"][1]&=~bit
    problem=o.finish(None)
    assert bool(d["flags"][1]&bit) is (not changed)
    assert (problem is not None) is changed
    assert o.public_baselines[1]["status_flags"]==baseline
    assert o.public_baselines[1]["status_flags"]&os.O_ACCMODE==os.O_WRONLY
    assert not d["flags"][2]&os.O_NONBLOCK and o.closed and o.root_closed


@pytest.mark.parametrize("descriptor", [1,2])
@pytest.mark.parametrize("operation", ["fstat", "getfd", "getfl", "ioctl", "readback"])
def test_r36_each_restore_boundary_retains_fault_and_attempts_remaining_safe_work(descriptor, operation):
    import errno
    d=_h4_inert([_h4_raw()]);o=d["owner"];api=d["ns"]["os"];fc=d["ns"]["fcntl"]
    o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    first=d["ns"]["Refusal"]("ORIGINAL_SCIENTIFIC_ERROR");o.fault("original-scientific-error",first)
    error=OSError(errno.EIO,"RESTORE_BOUNDARY_"+operation);seen=[]
    fdstat,flags,ioctl=api.fstat,fc.fcntl,fc.ioctl
    phase="public-flags-restore:"+str(descriptor)
    def due(fd,kind):
        if fd==descriptor and o.phase==phase and kind==operation and not seen:seen.append(kind);return True
        return False
    def observed_stat(fd):
        if due(fd,"fstat"):raise error
        return fdstat(fd)
    def observed_flags(fd,op,value=None):
        if op==fc.F_GETFD and due(fd,"getfd"):raise error
        if op==fc.F_GETFL and due(fd,"getfl"):raise error
        if op==fc.F_GETFL and operation=="readback" and fd==descriptor and o.phase==phase:
            if "ioctl-complete" in seen and "readback-failed" not in seen:seen.append("readback-failed");raise error
        return flags(fd,op,value)
    def observed_ioctl(fd,request,value):
        if due(fd,"ioctl"):raise error
        result=ioctl(fd,request,value)
        if fd==descriptor and o.phase==phase and operation=="readback":seen.append("ioctl-complete")
        return result
    api.fstat,fc.fcntl,fc.ioctl=observed_stat,observed_flags,observed_ioctl
    assert o.finish(first) is first and o.fault_objects[0] is first
    assert any(item is error for item in o.fault_objects) and seen
    row=next(row for item,row in zip(o.fault_objects,o.fault_records) if item is error)
    assert row["phase"]==phase and row["arguments"]["items"][1]["value"]=="RESTORE_BOUNDARY_"+operation
    assert {item["phase"] for item in o.public_observations if item["phase"].startswith("public-flags-verify:")}=={"public-flags-verify:1","public-flags-verify:2"}
    if descriptor==1:assert not d["flags"][2]&os.O_NONBLOCK
    assert o.closed and o.root_closed and not d["effects"]


@pytest.mark.parametrize("corruption", ["wire-cr", "profile", "group", "post-nb", "post-identity", "post-time", "description", "file-position"])
def test_r36_same_reader_rejects_changed_independent_transport_witnesses(corruption):
    import copy
    outcome=_r36_native_case("file-shared" if corruption=="file-position" else "pty-normal-shared",earlier_error=True,payload=b"BOUND_SOURCE\nTAIL")
    result=outcome["result"];damaged=copy.copy(result);damaged.hook_context=copy.deepcopy(result.hook_context)
    transport=damaged.hook_context["transport"];group=transport["groups"][transport["control_group"]]
    original=group["wire"]
    if corruption=="wire-cr":
        position=group["wire"].index(b"BOUND_SOURCE\r\n")+len(b"BOUND_SOURCE")
        group["wire"]=group["wire"][:position]+group["wire"][position+1:]
    elif corruption=="profile":transport["profiles"][1]["snapshot"]["termios"]["oflag"]=0
    elif corruption=="group":group["fds"]=[1]
    elif corruption=="post-nb":transport["post_state"]["descriptors"][1]["snapshot"]["status_flags"]^=os.O_NONBLOCK
    elif corruption=="post-identity":transport["post_state"]["descriptors"][1]["snapshot"]["identity"]["ino"]+=1
    elif corruption=="post-time":transport["post_state"]["descriptors"][1]["snapshot"]["ended"]["utc"]="9999-01-01T00:00:00+00:00"
    elif corruption=="description":group["description_witness"]["creation"]="equal-inode-is-not-a-witness"
    else:transport["control_offset"]+=1
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"
    assert result.hook_context["transport"]["groups"][transport["control_group"]]["wire"]==original


def _r36_mutate_actual_method(driver, name, old, new):
    """A deliberate guard defect in the actual source method, only for mutation controls."""
    import ast
    import textwrap
    source=HOOK.read_text().split("<<'PY'\n",1)[1].rsplit("\nPY",1)[0]
    tree=ast.parse(source);owner=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=="Evidence")
    method=next(node for node in owner.body if isinstance(node,ast.FunctionDef) and node.name==name)
    original=textwrap.dedent(ast.get_source_segment(source,method))
    assert original.count(old)==1,"mutation anchor must name the current actual guard exactly once"
    namespace=dict(driver["ns"]);exec(compile(original.replace(old,new),str(HOOK)+":deliberate-R36-guard-mutant","exec"),namespace)
    setattr(driver["owner"],name,namespace[name].__get__(driver["owner"],type(driver["owner"])))


@pytest.mark.parametrize("seed", ["omit-restore", "wrong-desired", "unowned-overwrite", "whole-word", "late-second-baseline", "ignore-late-query", "skip-second", "reuse", "tty-identity"])
def test_r36_nine_deliberate_actual_guard_defects_are_killed(seed,monkeypatch):
    import struct
    if seed in {"omit-restore","wrong-desired","skip-second","unowned-overwrite"}:
        def mutate(d,native):
            narrow=d["owner"].public_narrow
            def broken(fd,desired,deadline=None):
                if not desired:
                    if seed=="omit-restore" or seed=="skip-second" and fd==2:return None
                    if seed=="wrong-desired":return narrow(fd,True,deadline)
                result=narrow(fd,desired,deadline)
                if seed=="unowned-overwrite" and not desired:
                    import fcntl
                    fcntl.fcntl(native[fd],fcntl.F_SETFL,fcntl.fcntl(native[fd],fcntl.F_GETFL)&~os.O_APPEND)
                return result
            d["owner"].public_narrow=broken
        route="file-shared" if seed=="unowned-overwrite" else "pipe" if seed=="skip-second" else "pipe-shared"
        with pytest.raises(AssertionError):_r36_native_case(route,earlier_error=True,mutate=mutate)
        return
    if seed=="tty-identity":
        import inspect
        source=inspect.getsource(_events)
        old='return source.replace(b"\\n", b"\\r\\n")'
        assert source.count(old)==1
        namespace=dict(globals());exec(compile(source.replace(old,"return source"),str(HOOK)+":deliberate-R36-reader-mutant","exec"),namespace)
        monkeypatch.setitem(globals(),"_events",namespace["_events"])
        with pytest.raises(AssertionError):_r36_native_case("pty-normal-shared",earlier_error=True,payload=b"MUST_FORWARD\n")
        return
    d=_h4_inert([_h4_raw()]);o=d["owner"];fc=d["ns"]["fcntl"]
    if seed=="whole-word":
        _r36_mutate_actual_method(d,"public_narrow",'require(after["status_flags"] == ((current["status_flags"] & ~os.O_NONBLOCK)\n                        | (os.O_NONBLOCK if desired else 0)), "whole public word equality failed")','require(True, "deliberately missing whole-word guard")')
        ioctl=fc.ioctl
        def history(fd,request,payload):
            result=ioctl(fd,request,payload);d["flags"][fd]^=1<<26;return result
        fc.ioctl=history
        faulted=False
        try:o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        except d["ns"]["Refusal"]:faulted=True
        with pytest.raises(AssertionError):
            assert faulted,"the unmutated guard must refuse the entire-word mismatch"
        o.finish(None)
    elif seed=="late-second-baseline":
        d["descriptions"][2]=d["descriptions"][1];d["identities"][2]=dict(d["identities"][1])
        # Deliberately move the real first effect into the second baseline read.
        snapshot=o.public_snapshot;seen=[]
        def late(fd,deadline=None):
            if fd==2 and not seen:
                seen.append(True);o.public_narrow(1,True)
            return snapshot(fd,deadline)
        o.public_snapshot=late
        o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        with pytest.raises(AssertionError):assert not o.public_baselines[2]["status_flags"]&os.O_NONBLOCK
        o.finish(None)
    elif seed=="reuse":
        o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        _r36_mutate_actual_method(d,"public_narrow",'if not identity_ok:', 'if False:')
        d["identities"][1]["st_ino"]+=1;ioctl=fc.ioctl;calls=[]
        def counted(fd,request,payload):calls.append(fd);return ioctl(fd,request,payload)
        fc.ioctl=counted;o.finish(None)
        with pytest.raises(AssertionError):assert 1 not in calls
    else:
        o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        first=d["ns"]["Refusal"]("EARLIER_ERROR");o.fault("earlier",first)
        flags=fc.fcntl;actual=OSError("ACTUAL_LATE_QUERY_ERROR")
        def fail_query(fd,operation,value=None):
            if fd==1 and operation==fc.F_GETFL and o.phase=="public-flags-verify:1":raise actual
            return flags(fd,operation,value)
        fc.fcntl=fail_query
        # Omit the actual final query. The existing owner control must detect
        # missing typed query cause despite an unchanged earlier negative.
        snapshot=o.public_snapshot
        def missing(fd,deadline=None):
            if fd==1 and o.phase=="public-flags-verify:1":return o.public_effects[-2]["after"],None
            return snapshot(fd,deadline)
        o.public_snapshot=missing;o.finish(first)
        with pytest.raises(AssertionError):assert any(item is actual for item in o.fault_objects)
        assert o.fault_objects[0] is first


@pytest.mark.parametrize("kind", ["full", "closed", "raised-after-prefix", "none-after-prefix", "bool-after-prefix"])
def test_r36_actual_pipe_capacity_and_unknown_effects_preserve_wire_and_null_binding(kind):
    import errno
    import fcntl
    import struct
    import termios
    read_fd,write_fd=os.pipe();reader_open=True
    d=_h4_inert([_h4_raw()]);o=d["owner"];api=d["ns"]["os"];fc=d["ns"]["fcntl"]
    write,fdstat,conf,flags,ioctl=api.write,api.fstat,api.fpathconf,fc.fcntl,fc.ioctl
    original=fcntl.fcntl(write_fd,fcntl.F_GETFL);capacity=[];observed=[]
    try:
        fcntl.ioctl(write_fd,termios.FIONBIO,struct.pack("i",1))
        if kind=="full":
            for _ in range(4096):
                try:capacity.append(os.write(write_fd,b"F"*4096))
                except BlockingIOError:break
            else:pytest.fail("bounded own-pipe setup did not reach actual saturation")
            assert capacity and all(type(n) is int and n>0 for n in capacity)
        elif kind=="closed":os.close(read_fd);reader_open=False
        fcntl.ioctl(write_fd,termios.FIONBIO,struct.pack("i",0))
        def actual_write(fd,raw):
            if fd!=1:return write(fd,raw)
            if kind.endswith("after-prefix"):
                n=os.write(write_fd,raw[:2]);observed.append(n)
                assert n==2
                if kind=="raised-after-prefix":raise OSError(errno.EIO,"ACTUAL_PREFIX_THEN_RAISE")
                return None if kind=="none-after-prefix" else True
            return os.write(write_fd,raw)
        api.write=actual_write
        api.fstat=lambda fd:os.fstat(write_fd) if fd==1 else fdstat(fd)
        api.fpathconf=lambda fd,name:os.fpathconf(write_fd,name) if fd==1 else conf(fd,name)
        fc.fcntl=lambda fd,operation,value=None:fcntl.fcntl(write_fd,operation) if fd==1 else flags(fd,operation,value)
        fc.ioctl=lambda fd,request,value:fcntl.ioctl(write_fd,request,value) if fd==1 else ioctl(fd,request,value)
        with pytest.raises((OSError,d["ns"]["Refusal"])) as first:o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        assert o.finish(first.value) is first.value
        assert len(o.control_writes)==2 and o.accepted_start_sha256 is None
        assert o.fault_objects[0] is first.value and o.closed and o.root_closed
        assert all(row["written_bytes"] is None and row["missing_ranges"] is None for row in o.control_writes)
        assert o.public_offsets[1] is None
        protected=o.protected_controls|os.O_NONBLOCK
        assert fcntl.fcntl(write_fd,fcntl.F_GETFL)&protected==original&protected
        if reader_open:
            fcntl.ioctl(read_fd,termios.FIONBIO,struct.pack("i",1));pieces=[]
            while True:
                try:raw=os.read(read_fd,4096)
                except BlockingIOError:break
                if not raw:break
                pieces.append(raw)
            wire=b"".join(pieces)
            assert wire==(b"F"*sum(capacity) if kind=="full" else b"NONO")
            if kind.endswith("after-prefix"):assert observed==[2,2]
        assert not any(row[0]=="Popen" for row in d["ordering"]) and not d["effects"]
    finally:
        os.close(write_fd)
        if reader_open:os.close(read_fd)


def test_r36_entire_local_word_guard_rejects_changed_history_without_masking():
    d=_h4_inert([_h4_raw()]);o=d["owner"];fc=d["ns"]["fcntl"];ioctl=fc.ioctl;seen=[]
    def changed(fd,request,payload):
        result=ioctl(fd,request,payload)
        if not seen:seen.append(fd);d["flags"][fd]^=1<<26
        return result
    fc.ioctl=changed
    with pytest.raises(d["ns"]["Refusal"],match="whole public word equality") as first:o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    assert o.public_effects[0]["before"]["status_flags"]^o.public_effects[0]["after"]["status_flags"]==os.O_NONBLOCK|(1<<26)
    assert o.fault_objects[0] is first.value
    assert o.finish(first.value) is first.value
    assert not d["flags"][1]&os.O_NONBLOCK and not d["flags"][2]&os.O_NONBLOCK


def test_r36_independent_opens_one_inode_keep_distinct_original_nonblocking_states():
    outcome=_r36_native_case("file-independent",initial={1:False,2:True})
    profiles=outcome["driver"]["owner"].public_baselines
    assert profiles[1]["identity"]["ino"]==profiles[2]["identity"]["ino"]
    assert not profiles[1]["status_flags"]&os.O_NONBLOCK and profiles[2]["status_flags"]&os.O_NONBLOCK
    post=outcome["result"].hook_context["transport"]["post_state"]["descriptors"]
    assert not post[1]["snapshot"]["status_flags"]&os.O_NONBLOCK and post[2]["snapshot"]["status_flags"]&os.O_NONBLOCK
    assert outcome["result"].returncode==0


def _r36_rebind_corrupted_private_journal(outcome, edit):
    """Adversarial fixture: recompute only the malicious journal's terminal digest."""
    import copy
    actual=outcome["result"];damaged=copy.copy(actual);damaged.hook_context=copy.deepcopy(actual.hook_context)
    owner=outcome["driver"]["owner"];journal=owner.root/"events.jsonl"
    records=[json.loads(line) for line in journal.read_bytes().splitlines()]
    edit(records)
    raw=b"".join(json.dumps(row,separators=(",",":"),ensure_ascii=True).encode()+b"\n" for row in records)
    journal.write_bytes(raw)
    terminal=owner.control_writes[-1]["raw"]
    end=json.loads(terminal.removeprefix(b"NOTEBOOK_HOOK "))
    end.update(events_bytes=len(raw),events_sha256=hashlib.sha256(raw).hexdigest())
    replacement=b"NOTEBOOK_HOOK "+json.dumps(end,separators=(",",":"),ensure_ascii=True).encode()
    group=damaged.hook_context["transport"]["groups"][damaged.hook_context["transport"]["control_group"]]
    assert group["wire"].endswith(terminal)
    group["wire"]=group["wire"][:-len(terminal)]+replacement
    return damaged


@pytest.mark.parametrize("field", ["sequence", "command_id", "fd", "channel", "source_start", "source_end", "intended_bytes", "source_sha256", "profile_id", "returned_count", "written_source_bytes", "source_offset_before", "source_offset_after", "fault_id", "started", "ended", "before_profile", "after_profile", "before_profile_fault_id", "after_profile_fault_id", "regular_position_before", "regular_position_after", "outcome"])
@pytest.mark.parametrize("damage", ["missing", "wrong-type"])
def test_r36_every_ordered_write_field_is_checked_against_actual_wire(field,damage):
    outcome=_r36_native_case("file-shared",earlier_error=True,payload=b"SOURCE\nOPAQUE_NOTEBOOK_HOOK {}")
    def edit(records):
        row=next(item for item in records if item["event"]=="command_end")["public_writes"][0]
        if damage=="missing":del row[field]
        else:row[field]=True
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("section,field", [("profile", key) for key in ("id", "fd", "sink_kind", "presentation", "before", "complete", "fault_id")]+[("snapshot", key) for key in ("started", "ended", "identity", "status_flags", "descriptor_flags", "termios", "discipline", "complete", "fault_id")]+[("termios",key) for key in ("iflag","oflag","cflag","lflag","ispeed","ospeed","cc_native")])
def test_r36_every_native_profile_field_is_required_after_recomputed_digest(section,field):
    outcome=_r36_native_case("pty-normal-shared",earlier_error=True,payload=b"SOURCE\n")
    def edit(records):
        profile=records[0]["public_transport"]["profiles"][0]
        target=profile if section=="profile" else profile["before"] if section=="snapshot" else profile["before"]["termios"]
        del target[field]
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("damage", ["order", "source-count", "source-hash", "source-lf", "position", "started-utc", "ended-mono", "extra-row-key"])
def test_r36_order_source_positions_and_typed_intervals_cannot_be_forged(damage):
    outcome=_r36_native_case("file-shared",earlier_error=True,payload=b"SOURCE\nOPAQUE",stderr_payload=b"SECOND\r\n")
    def edit(records):
        end=next(item for item in records if item["event"]=="command_end");rows=end["public_writes"]
        if damage=="order":rows.reverse()
        elif damage=="source-count":rows[0]["returned_count"]+=1
        elif damage=="source-hash":rows[0]["source_sha256"]="0"*64
        elif damage=="position":rows[0]["regular_position_after"]+=1
        elif damage=="started-utc":rows[0]["started"]["utc"]="NOT_A_TIME"
        elif damage=="ended-mono":rows[0]["ended"]["mono"]=-1
        elif damage=="extra-row-key":rows[0]["invented_alias"]=rows[0]["source_sha256"]
        else:
            channel=next(item for item in records if item["event"]=="command_channel" and item["channel"]==0)
            path=outcome["driver"]["owner"].root/channel["available"]["file"]
            raw=path.read_bytes().replace(b"\n",b"\r");path.write_bytes(raw)
            channel["available"]["sha256"]=hashlib.sha256(raw).hexdigest()
            end["channels"][0]["sha256"]=hashlib.sha256(raw).hexdigest()
            rows[0]["source_sha256"]=hashlib.sha256(raw).hexdigest()
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("profile", ["flusho", "ocrnl", "onocr", "tab-expand", "seven-bit", "unknown-line", "invalid-speed", "unknown-platform", "missing-fionbio"])
def test_r36_unsupported_native_profiles_are_actual_refusals_not_identity_fallback(profile):
    import termios
    d=_h4_inert([_h4_raw()]);o=d["owner"];terminal=d["ns"]["termios"]
    if profile=="unknown-platform":d["ns"]["sys"].platform="UNREVIEWED"
    elif profile=="missing-fionbio":terminal.FIONBIO=None
    else:
        d["identities"][1]["st_mode"]=stat.S_IFCHR
        attrs=[0,termios.OPOST|termios.ONLCR,termios.CS8,0,9600,9600,[b"\0"]*termios.NCCS]
        d["terminal_attributes"][1]=attrs;d["disciplines"][1]=0
        if profile=="flusho":attrs[3]|=termios.FLUSHO
        elif profile=="seven-bit":attrs[2]=termios.CS7
        elif profile=="unknown-line":d["disciplines"][1]=999
        elif profile=="invalid-speed":attrs[4]=True
        else:attrs[1]|=getattr(termios,{"ocrnl":"OCRNL","onocr":"ONOCR","tab-expand":"OXTABS"}[profile])
    with pytest.raises(d["ns"]["Refusal"]) as first:o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    o.fault("native-profile",first.value)
    assert o.finish(first.value) is first.value
    assert not any(row[0]=="Popen" for row in d["ordering"]) and not d["effects"]


def test_r36_actual_destructive_nonappend_overlap_is_incomplete_not_stream_success():
    seen=[]
    def inspect(d,result):
        group=result.hook_context["transport"]["groups"]["file"]
        assert not group["wire"].startswith(group["initial_image"])
        assert d["owner"].fault_objects[0].args==("command failed once (not rerun): ['INERT_CLI'] rc=7",)
        seen.append(result)
    with pytest.raises(AssertionError):_r36_native_case("file-overwrite",earlier_error=True,inspect=inspect)
    assert seen and seen[0].hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("route", ["pipe", "fifo", "socket", "file", "append", "pty-normal"])
@pytest.mark.parametrize("poison", [False,True])
def test_r36_real_hook_native_sink_science_once_and_same_reader(real_repo,route,poison):
    """ROOT-only native control: actual hook, kernel, exact merged capture and witnesses."""
    capture=_H94FixtureCapture("real-hook-owned-native")
    child=None;known=[];qualified=False;writer=None;deadline=None;pieces=_H94_UNOBSERVED
    initial=_H94_UNOBSERVED;final=_H94_UNOBSERVED;position=_H94_UNOBSERVED;final_position=_H94_UNOBSERVED
    read_observations=[];witness_observations=[];context=_H94_UNOBSERVED;argv=_H94_UNOBSERVED
    try:
        import contextlib
        import tempfile
        import errno
        import fcntl
        import socket
        import struct
        import termios
        repo,_,_=real_repo
        code="from pathlib import Path\nimport os\np=Path('r36-science-count.txt')\np.write_text(str(int(p.read_text())+1) if p.exists() else '1')\nPath('r36-kernel-pid.txt').write_text(str(os.getpid()))\n"
        code += "raise ValueError('R36_NATIVE_SCIENCE_POISON')" if poison else "assert True"
        notebook=_write(repo,'notebooks/r36-native.ipynb',_nb(code));_stage(repo)
        notebook_before=notebook.read_bytes();index_before=_index(repo)
        argv=['bash',str(HOOK)];env=_env();context=_hook_context(HOOK,argv,repo,env)
        child=None;known=[];result_records=None;qualified=False
        with contextlib.ExitStack() as resources:
            try:
                def owned(fd):capture.register(resources,[(os.close,(fd,))]);return fd
                path=repo/'r36-caller-output.bin'
                if route in {'file','append'}:
                    path.write_bytes(b'INITIAL_FILE_PREFIX\n')
                    writer=owned(os.open(path,os.O_WRONLY|(os.O_APPEND if route=='append' else 0)))
                    os.lseek(writer,0,os.SEEK_END);reader=None;initial_image=path.read_bytes();kind='file'
                elif route=='socket':
                    received,sent=socket.socketpair();capture.register(resources,[(received.close,()),(sent.close,())])
                    reader,writer=received.fileno(),sent.fileno();kind='stream'
                elif route=='fifo':
                    fifo_root = Path(tempfile.mkdtemp(prefix="r36-caller-owned-"))
                    capture.register(resources,[(fifo_root.rmdir,())])  # nonrecursive: a foreign replacement is never deleted
                    fifo=fifo_root/'r36-caller-fifo';os.mkfifo(fifo,0o600)
                    created = fifo.lstat()
                    def remove_owned_fifo():
                        current = fifo.lstat()
                        assert not fifo.is_symlink() and stat.S_ISFIFO(current.st_mode)
                        assert (current.st_dev,current.st_ino,current.st_mode)==(created.st_dev,created.st_ino,created.st_mode)
                        fifo.unlink()
                    capture.register(resources,[(remove_owned_fifo,())])
                    writer=owned(os.open(fifo,os.O_RDWR|os.O_NONBLOCK));reader=owned(os.open(fifo,os.O_RDONLY|os.O_NONBLOCK));kind='stream'
                    fcntl.ioctl(writer,termios.FIONBIO,struct.pack('i',0))
                elif route=='pty-normal':
                    reader,writer=os.openpty();capture.register(resources,[(os.close,(reader,)),(os.close,(writer,))]);kind='stream'
                    # Keep the actual default slave termios unchanged throughout.
                elif route=='pipe':
                    reader,writer=os.pipe();capture.register(resources,[(os.close,(reader,)),(os.close,(writer,))]);kind='stream'
                else:raise AssertionError('unmodelled actual native caller route')
                if reader is not None:fcntl.ioctl(reader,termios.FIONBIO,struct.pack('i',1))
                initial={}
                for fd in (1,2):initial[fd]=_r36_native_snapshot(writer)
                position={fd:os.lseek(writer,0,os.SEEK_CUR) if kind=='file' else None for fd in (1,2)}
                child=subprocess.Popen(argv,cwd=repo,env=env,stdin=subprocess.DEVNULL,stdout=writer,stderr=writer,start_new_session=True)
                context['pid']=child.pid
                tick=time.monotonic();deadline=tick+300
                pieces=[]
                def receive_available():
                    if reader is None:
                        return
                    while time.monotonic()<deadline:
                        row=dict(outcome="entered",raw=_H94_UNOBSERVED)
                        read_observations.append(row)
                        try:
                            raw=os.read(reader,4096);row.update(outcome="returned",raw=raw)
                        except OSError as error:
                            row.update(outcome="raised",arguments=error.args,errno=error.errno)
                            if error.errno in (errno.EAGAIN,errno.EWOULDBLOCK):return
                            if route=='pty-normal' and error.errno==errno.EIO and child.poll() is not None:return
                            raise
                        if not raw:return
                        pieces.append(raw)
                    raise AssertionError('original caller receive budget exhausted')
                while child.poll() is None and time.monotonic()<deadline:
                    receive_available()
                    witness=repo/'notebooks/r36-kernel-pid.txt'
                    observation=dict(path=str(witness),exists=witness.exists(),raw=_H94_UNOBSERVED,identity=_H94_UNOBSERVED)
                    witness_observations.append(observation)
                    if observation['exists'] and not known:
                        try:
                            observation['raw']=witness.read_text()
                            identity=_pid_identity(int(observation['raw']),repo)
                            observation['identity']=identity
                        except (FileNotFoundError,ValueError) as error:
                            observation['error_arguments']=error.args;identity=None
                        if identity is not None:known.append(identity)
                    time.sleep(.025)
                remaining=deadline-time.monotonic()
                assert remaining>0,'original caller wait budget exhausted'
                child.wait(timeout=remaining)
                assert len(known)==1,'actual kernel identity witness was not obtained'
                final={}
                for fd in (1,2):final[fd]=_r36_native_snapshot(writer)
                final_position={fd:os.lseek(writer,0,os.SEEK_CUR) if kind=='file' else None for fd in (1,2)}
                if kind=='file':wire=path.read_bytes()
                else:
                    receive_available()
                    wire=b''.join(pieces)
                call=dict(argv=context['argv'],cwd=context['cwd'],pid=child.pid)
                description=dict(actual_fd=writer,creation='same-popen-endpoint',group='actual-merged',description='same-writer')
                group=dict(fds=[1,2],kind=kind,wire=wire,description_groups={1:'same-writer',2:'same-writer'},
                    description_witness=dict(observed_call=call,creation='same-popen-endpoint'))
                if kind=='file':group.update(initial_image=initial_image,file_image_witness=dict(source='actual-initial-and-final-file-images',path=str(path)))
                context['transport']=dict(observed_call=call,groups={'actual-merged':group},control_group='actual-merged',
                    control_offset=len(initial_image) if kind=='file' else 0,
                    profiles={fd:dict(source='actual-pre-call-native-observation',snapshot=initial[fd],regular_position=position[fd],description_witness=description) for fd in (1,2)},
                    post_state=dict(source='retained-actual-open-descriptions-after-owner-return',observed_call=call,
                        descriptors={fd:dict(description_witness=description,phase='after-actual-owner-return',snapshot=final[fd],regular_position=final_position[fd]) for fd in (1,2)}))
                context['end_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
                result_records=_events(child=child,streams=(wire,b''),context=context)
                assert child.returncode==(2 if poison else 0)
                assert context['verification']['actual_flags_independently_observed'] is True
                assert (repo/'notebooks/r36-science-count.txt').read_text()=='1'
                assert notebook.read_bytes()==notebook_before and _index(repo)==index_before
                for descriptor in (1,2):
                    assert initial[descriptor]['termios']==final[descriptor]['termios'] and initial[descriptor]['discipline']==final[descriptor]['discipline']
                    assert initial[descriptor]['status_flags']&(os.O_NONBLOCK|os.O_ACCMODE)==final[descriptor]['status_flags']&(os.O_NONBLOCK|os.O_ACCMODE)
                if poison:
                    channels=[row for row in result_records if row['event']=='command_channel']
                    root=Path(json.loads(_control_object(wire,context['transport']['control_offset'])[0].removeprefix(b'NOTEBOOK_HOOK '))['evidence_root'])
                    exact_error=b''.join((root/row['available']['file']).read_bytes() for row in channels if row['channel']==1)
                    assert b'CellExecutionError' in exact_error and b'R36_NATIVE_SCIENCE_POISON' in exact_error
                    assert context['transport_verification']['normalized_received_bytes'] is False
                for identity in known:assert _pid_identity(identity['pid'],repo) is None
                qualified=True
            except BaseException as error:capture.fault("real-native-body",error)
            finally:
                capture.attempt("precleanup-freeze",lambda: capture.freeze(dict(argv=argv,cwd=str(repo),
                    pid=_H94_UNOBSERVED if child is None else child.pid,
                    stored_returncode=_H94_UNOBSERVED if child is None else child.returncode,
                    raw_pieces=pieces,read_observations=read_observations,witness_observations=witness_observations,
                    known=known,initial=initial,final=final,position=position,final_position=final_position)))
                capture.attempt("optional-snapshot-construction",_h94_owned_writer_snapshot,capture,writer,deadline,final,writer is not None)
                if child is not None:
                    running=capture.attempt("original-child-poll",child.poll)
                    if running is None:
                        current=capture.attempt("original-owned-child-identity",_pid_identity,child.pid,repo)
                        if current is not _H94_UNOBSERVED and current is not None:
                            capture.attempt("original-owned-child-stop",_stop_fixture,current,repo)
                        capture.attempt("original-child-wait",child.wait,timeout=2)
                if not qualified:
                    for identity in known:capture.attempt("original-known-witness",_stop_fixture,identity,repo)
                capture.close_stack(resources)
        capture.outer_exited=True
    except BaseException as error:
        if capture.first is None or capture.first["object"] is not error:capture.fault("real-native-entry-or-exit",error)
    capture.emit()
    capture.propagate()

@pytest.mark.parametrize("phase", ["before","after"])
@pytest.mark.parametrize("native_value", [None,True,-1,"bad",10**100])
def test_r36_unavailable_native_position_is_null_and_keeps_actual_returned_source_count(phase,native_value):
    def command(child,timeout):child.returncode=7;return b'OUT',b'ERR'
    d=_h4_inert([_h4_raw()],command=command);o=d['owner'];api=d['ns']['os']
    d['identities'][1]['st_mode']=stat.S_IFREG
    seek=api.lseek;calls=[]
    def unavailable(fd,offset,how):
        if fd==1:
            calls.append((fd,offset,how))
            if phase=='before' or len(calls)%2==0:return native_value
        return seek(fd,offset,how)
    api.lseek=unavailable
    with pytest.raises(d['ns']['Refusal'],match='command failed once') as first:d['ns']['run'](['INERT_CLI'],'/INERT',{},watch=False)
    assert o.fault_objects[0] is first.value
    row=o.public_writes[0]
    assert row['regular_position_'+phase] is None
    assert row['written_source_bytes']==3 and row['source_offset_after']==3 if phase=='after' else row['written_source_bytes'] is None and row['source_offset_after'] is None
    fault=next(item for item in o.faults if item['operation']=='public-position-'+phase+':1')
    native={key['value']:value for key,value in fault['details']['items']}['returned_native']
    expected=d['ns']['typed_native'](native_value)
    assert native==expected
    assert o.finish(first.value) is first.value and o.closed and o.root_closed
    assert not d['effects']


@pytest.mark.parametrize("damage,reason", [
    ("before-after-overlap", "overlapping native write observations"),
    ("before-after-reversed", "hook evidence protocol"),
    ("write-before-command", "native write outside actual command interval"),
    ("write-after-command", "native write outside actual command interval"),
    ("global-write-overlap", "unordered invocation-global write intervals"),
    ("global-write-reversed", "unordered invocation-global write intervals"),
    ("baseline-overlap", "overlapping native baselines"),
    ("setup-overlap", "overlapping native setup effects"),
    ("setup-start-overlap", "unordered native setup/start observations"),
    ("start-overlap", "unordered native setup/start observations"),
    ("command-before-start", "unordered serial command intervals"),
    ("command-UTC-binding", "command UTC start binding differs"),
    ("UTC-outside-caller", "native UTC sample outside actual caller interval"),
])
def test_h38_same_reader_numeric_chronology_corruptions_keep_actual_source_counts_and_profile_facts(damage,reason):
    import copy
    import time
    def actual_clock(d,native):
        # Existing external clock seam: positive stamps are made by production
        # methods using this actual clock, never patched into a passing journal.
        d["ns"]["time"].monotonic=time.monotonic
    outcome=_r36_native_case("file-shared",earlier_error=True,payload=b"CHRONOLOGY_SOURCE\nOPAQUE",stderr_payload=b"SECOND_CHANNEL\r\n",mutate=actual_clock)
    actual=outcome["result"];context=actual.hook_context
    assert context["disposition"]=="command-refusal" and context["verification"]["actual_flags_independently_observed"]
    original_streams=(actual.stdout,actual.stderr)
    original_records=copy.deepcopy(outcome["records"])
    source_files={row["available"]["file"]:(outcome["driver"]["owner"].root/row["available"]["file"]).read_bytes()
        for row in original_records if row["event"]=="command_channel"}
    def without_clock(value):
        if type(value) is dict:
            return {k:without_clock(v) for k,v in value.items() if k not in {"started","ended","started_monotonic","ended_monotonic","started_utc","ended_utc"}}
        if type(value) is list:return [without_clock(v) for v in value]
        return value
    def edit(records):
        invocation=records[0];lease=invocation["public_control_lease"];profiles=invocation["public_transport"]["profiles"]
        end=next(x for x in records if x["event"]=="command_end")
        begin=next(x for x in records if x["event"]=="command_begin")
        rows=end["public_writes"];first,second=rows[:2]
        start=records[-1]["start_control_attempts"][0]
        assert len(rows)==2 and first["ended"]["mono"] < second["started"]["mono"]
        assert first["before_profile"]["ended"]["mono"] < first["after_profile"]["started"]["mono"] < first["after_profile"]["ended"]["mono"]
        if damage=="before-after-overlap":
            first["before_profile"]["ended"]["mono"]=first["after_profile"]["ended"]["mono"]
            # Both snapshots and the formerly accepted outer predicate remain true.
            assert first["started"]["mono"] <= first["before_profile"]["started"]["mono"] <= first["after_profile"]["ended"]["mono"] <= first["ended"]["mono"]
            assert first["before_profile"]["started"]["mono"] <= first["before_profile"]["ended"]["mono"]
        elif damage=="before-after-reversed":
            for edge in ("started","ended"):
                first["before_profile"][edge]["mono"],first["after_profile"][edge]["mono"]=first["after_profile"][edge]["mono"],first["before_profile"][edge]["mono"]
        elif damage=="write-before-command":
            first["started"]["mono"]=start["after_profile"]["ended"]["mono"]
            assert first["started"]["mono"] < begin["started_monotonic"]
        elif damage=="write-after-command":
            first["ended"]["mono"]=context["transport"]["post_state"]["descriptors"][1]["snapshot"]["ended"]["mono"]
            assert first["ended"]["mono"] > end["ended_monotonic"]
        elif damage in {"global-write-overlap","global-write-reversed"}:
            targets=[second] if damage=="global-write-overlap" else [first,second]
            donors=[copy.deepcopy(first)] if damage=="global-write-overlap" else [copy.deepcopy(second),copy.deepcopy(first)]
            for target,donor in zip(targets,donors):
                for edge in ("started","ended"):
                    target[edge]["mono"]=donor[edge]["mono"]
                    for profile in ("before_profile","after_profile"):
                        target[profile][edge]["mono"]=donor[profile][edge]["mono"]
            assert first["ended"]["mono"] > second["started"]["mono"]
        elif damage=="baseline-overlap":profiles[0]["before"]["ended"]["mono"]=profiles[1]["before"]["ended"]["mono"]
        elif damage=="setup-overlap":lease["setup_effects"][0]["after"]["ended"]["mono"]=lease["setup_effects"][1]["after"]["ended"]["mono"]
        elif damage=="setup-start-overlap":lease["setup_effects"][1]["after"]["ended"]["mono"]=start["before_profile"]["ended"]["mono"]
        elif damage=="start-overlap":start["before_profile"]["ended"]["mono"]=start["after_profile"]["ended"]["mono"]
        elif damage=="command-before-start":
            begin["started_monotonic"]=end["started_monotonic"]=profiles[0]["before"]["ended"]["mono"]
        elif damage=="command-UTC-binding":end["started_utc"]=context["start_utc"]
        else:
            first["started"]["utc"]=(dt.datetime.fromisoformat(context["start_utc"])-dt.timedelta(seconds=1)).isoformat()
        assert without_clock(records)==without_clock(original_records)
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    assert (actual.stdout,actual.stderr)==original_streams and (damaged.stdout,damaged.stderr)==original_streams
    assert all((outcome["driver"]["owner"].root/name).read_bytes()==raw for name,raw in source_files.items())
    with pytest.raises(AssertionError,match=reason):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"
    assert "verification" not in damaged.hook_context and "transport_verification" not in damaged.hook_context


@pytest.mark.parametrize("location", ["baseline", "setup-before", "setup-after", "start-before", "start-after", "write-start", "write-end", "write-before", "write-after", "command-start", "command-end"])
@pytest.mark.parametrize("damage", ["missing", "bool", "nonfinite", "UTC-naive"])
def test_h38_same_reader_chronology_missing_and_type_complements(location,damage):
    outcome=_r36_native_case("file-shared",earlier_error=True,payload=b"SOURCE\n",stderr_payload=b"SECOND\n")
    assert outcome["result"].hook_context["verification"]["actual_flags_independently_observed"]
    def edit(records):
        invocation=records[0];effects=invocation["public_control_lease"]["setup_effects"]
        end=next(x for x in records if x["event"]=="command_end");row=end["public_writes"][0]
        start=records[-1]["start_control_attempts"][0]
        if location in {"command-start","command-end"}:
            target=next(x for x in records if x["event"]=="command_begin") if location=="command-start" else end
            key=("started_utc" if location=="command-start" else "ended_utc") if damage=="UTC-naive" else ("started_monotonic" if location=="command-start" else "ended_monotonic")
        else:
            target={"baseline":invocation["public_transport"]["profiles"][0]["before"]["started"],
                "setup-before":effects[0]["before"]["started"],"setup-after":effects[0]["after"]["ended"],
                "start-before":start["before_profile"]["started"],"start-after":start["after_profile"]["ended"],
                "write-start":row["started"],"write-end":row["ended"],"write-before":row["before_profile"]["started"],"write-after":row["after_profile"]["ended"]}[location]
            key="utc" if damage=="UTC-naive" else "mono"
        if damage=="missing":del target[key]
        elif damage=="bool":target[key]=True
        elif damage=="nonfinite":target[key]=float("inf")
        else:target[key]="2026-10-20T00:00:00"
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("route", ["pipe", "file-shared", "pty-normal-shared"])
@pytest.mark.parametrize("earlier_error", [False, True])
def test_h40_actual_native_caller_context_precedes_real_owner_even_if_clock_samples_coincide(monkeypatch,route,earlier_error):
    context_impl,inert_impl=_hook_context,_h4_inert
    calls,contexts,owners=[],[],[]
    def observed_context(*args,**kwargs):
        calls.append("context-call")
        actual=context_impl(*args,**kwargs)
        contexts.append(actual)
        calls.append("context-return")
        return actual
    def observed_inert(*args,**kwargs):
        driver=inert_impl(*args,**kwargs)
        # The unchanged warm-up owner already exists. Observe the actual native
        # owner's constructor without substituting its class, fields or samples.
        constructor=driver["ns"]["Evidence"]
        def observed_owner(root):
            calls.append("owner-call")
            actual=constructor(root)
            owners.append((constructor,actual))
            calls.append("owner-return")
            return actual
        driver["ns"]["Evidence"]=observed_owner
        return driver
    monkeypatch.setitem(globals(),"_hook_context",observed_context)
    monkeypatch.setitem(globals(),"_h4_inert",observed_inert)
    inspections=[]
    def inspect_actual(driver,result):
        # This existing hook runs before SAME-reader decoding. The causal
        # predicate observes actual calls and never compares or edits clocks:
        # old inversion fails here even if its two genuine samples are equal.
        assert calls==["context-call","context-return","owner-call","owner-return"]
        assert len(contexts)==len(owners)==1 and contexts[0] is result.hook_context
        constructor,owner=owners[0]
        assert owner.__class__ is constructor and owner is driver["owner"] is driver["ns"]["EVIDENCE"]
        assert result.hook_context["pid"]==99 and result.hook_context["entry_bytes"]==HOOK.read_bytes()
        assert dt.datetime.fromisoformat(result.hook_context["start_utc"]) <= dt.datetime.fromisoformat(owner.started_utc) <= dt.datetime.fromisoformat(result.hook_context["end_utc"])
        inspections.append((driver,result))
    outcome=_r36_native_case(route,earlier_error=earlier_error,payload=b"ACTUAL_CONTEXT_SOURCE\nCRLF\r\n",stderr_payload=b"ACTUAL_CONTEXT_ERROR\n",inspect=inspect_actual)
    result=outcome["result"]
    assert inspections==[(outcome["driver"],result)]
    assert result.returncode==(2 if earlier_error else 0) and result.hook_context["disposition"]==("command-refusal" if earlier_error else "verified-zero")
    assert result.hook_context["verification"]["source_invariant_and_actual_exit"] and result.hook_context["verification"]["actual_flags_independently_observed"]
    assert result.hook_context["transport_verification"]["exact_private_source"] and result.hook_context["transport_verification"]["exact_received_controls"]


@pytest.mark.parametrize("parent_kind", ["canonical", "parent-alias"])
def test_h43_actual_owned_allocation_parent_alias_preserves_identity_and_fd_cleanup(monkeypatch, tmp_path, parent_kind):
    import tempfile
    real_parent = tmp_path / "physical-parent"
    real_parent.mkdir(mode=0o700)
    real_parent = real_parent.resolve(strict=True)
    alias = tmp_path / "owned-parent-alias"
    alias.symlink_to(real_parent, target_is_directory=True)
    selected_parent = real_parent if parent_kind == "canonical" else alias
    constructor = tempfile.TemporaryDirectory
    allocations, allocated_stats = [], []
    def allocate_actual(*args, **kwargs):
        assert args == () and kwargs == {"prefix": "h4-inert-files-"}
        # Delegate the actual allocator; its actual returned path carries the
        # selected real parent spelling. No TMPDIR or global environment edit.
        actual = constructor(*args, dir=selected_parent, **kwargs)
        allocations.append(actual)
        allocated_stats.append(Path(actual.name).lstat())
        return actual
    monkeypatch.setattr(tempfile, "TemporaryDirectory", allocate_actual)
    driver = None
    try:
        driver = _h4_inert([_h4_raw()])
        owner, allocation = driver["owner"], allocations[0]
        allocated = Path(allocation.name)
        opened = os.fstat(owner.root_fd)
        canonical = owner.root.lstat()
        original = allocated_stats[0]
        assert len(allocations) == 1 and driver["files"] is allocation
        assert owner.allocated_root == allocated and allocated.parent == selected_parent
        assert owner.root.parent == real_parent and owner.root.name == allocated.name
        assert owner.root == allocated.resolve(strict=True) and not allocated.is_symlink()
        assert (opened.st_dev, opened.st_ino) == (canonical.st_dev, canonical.st_ino) == (original.st_dev, original.st_ino) == owner.root_identity
        assert opened.st_uid == canonical.st_uid == original.st_uid == os.getuid()
        assert opened.st_mode == canonical.st_mode == original.st_mode and stat.S_ISDIR(opened.st_mode) and stat.S_IMODE(opened.st_mode) == 0o700
        assert (owner.allocated_root != owner.root) is (parent_kind == "parent-alias")
        assert owner.events in driver["owned_fds"] and owner.root_fd in driver["owned_fds"] and len(driver["owned_fds"]) == 2
        assert stat.S_IMODE((owner.root / "events.jsonl").stat().st_mode) == 0o600
        assert driver["effects"] == [] and driver["calls"] == []
    finally:
        try:
            if driver is not None:
                assert driver["owner"].finish(None) is None
                assert driver["owner"].closed and driver["owner"].root_closed and driver["owned_fds"] == set()
        finally:
            for allocation in allocations:
                allocation.cleanup()
    assert all(not Path(allocation.name).exists() for allocation in allocations)


@pytest.mark.parametrize("foreign_kind", ["foreign", "foreign-parent-alias", "owned-leaf-symlink", "foreign-leaf-symlink"])
def test_h43_original_private_guard_refuses_foreign_roots_and_substituted_leaves(tmp_path, foreign_kind):
    driver = _h4_inert([_h4_raw()])
    owner = driver["owner"]
    foreign_parent = tmp_path / "foreign-parent"
    foreign_parent.mkdir(mode=0o700)
    # The same leaf spelling is insufficient: this is a different real allocation.
    foreign = foreign_parent / owner.root.name
    foreign.mkdir(mode=0o700)
    marker = foreign / "foreign-bytes"
    marker.write_bytes(b"FOREIGN_ROOT_MUST_REMAIN_UNTOUCHED\x00\xff")
    before = foreign.lstat()
    files_before = {p.name: p.read_bytes() for p in foreign.iterdir()}
    if foreign_kind == "foreign-parent-alias":
        alias = tmp_path / "foreign-parent-alias"
        alias.symlink_to(foreign_parent, target_is_directory=True)
        selected = alias / foreign.name
    elif foreign_kind.endswith("leaf-symlink"):
        selected = tmp_path / "substituted-owned-leaf"
        selected.symlink_to(owner.root if foreign_kind == "owned-leaf-symlink" else foreign, target_is_directory=True)
    else:
        selected = foreign
    owned_before = set(driver["owned_fds"])
    journal_before = (owner.root / "events.jsonl").read_bytes()
    try:
        if foreign_kind.endswith("leaf-symlink"):
            assert selected.is_symlink()
            with pytest.raises(driver["ns"]["Refusal"], match="private invocation output ownership unavailable"):
                driver["ns"]["Evidence"](selected)
        else:
            assert selected.samefile(foreign) and not selected.samefile(owner.root)
            with pytest.raises(AssertionError, match="unmodelled private root"):
                driver["ns"]["Evidence"](selected)
        after = foreign.lstat()
        assert (after.st_dev, after.st_ino, after.st_uid, after.st_mode, after.st_mtime_ns) == (before.st_dev, before.st_ino, before.st_uid, before.st_mode, before.st_mtime_ns)
        assert {p.name: p.read_bytes() for p in foreign.iterdir()} == files_before
        assert driver["owned_fds"] == owned_before and (owner.root / "events.jsonl").read_bytes() == journal_before
        assert owner is driver["ns"]["EVIDENCE"] and owner.root_identity == (os.fstat(owner.root_fd).st_dev, os.fstat(owner.root_fd).st_ino)
        assert driver["effects"] == [] and driver["calls"] == []
    finally:
        try:
            assert owner.finish(None) is None
            assert owner.closed and owner.root_closed and driver["owned_fds"] == set()
        finally:
            driver["files"].cleanup()


# Exact Darwin native identity controls; the original full native matrix remains required.
_H48_IDENTITY_LIMITS = [
    ("dev", -1, (1 << 64) - 2),
    ("rdev", -1, (1 << 64) - 2),
    ("ino", 0, (1 << 64) - 1),
    ("mode", 0, (1 << 16) - 1),
    ("uid", -1, (1 << 32) - 2),
    ("gid", -1, (1 << 32) - 2),
]


@pytest.mark.parametrize("field,low,high", _H48_IDENTITY_LIMITS)
@pytest.mark.parametrize("descriptor", [1, 2])
@pytest.mark.parametrize("edge", ["low", "high", "below", "above", "bool", "false-bool", "null", "string", "float", "int-subclass"])
def test_h48_actual_snapshot_typed_field_boundaries(field, low, high, descriptor, edge):
    class IntSubclass(int):
        pass
    value = {"low": low, "high": high, "below": low - 1, "above": high + 1,
             "bool": True, "false-bool": False, "null": None, "string": "0", "float": 0.0,
             "int-subclass": IntSubclass(0)}[edge]
    driver = _h4_inert([_h4_raw()]); owner = driver["owner"]
    driver["identities"][descriptor]["st_" + field] = value
    expected = {key: driver["identities"][descriptor]["st_" + key]
                for key in ("dev", "ino", "rdev", "mode", "uid", "gid")}
    row, error = owner.public_snapshot(descriptor)
    if edge in {"low", "high"}:
        assert error is None and row["complete"] is True
        assert row["identity"] == expected and type(row["identity"][field]) is int
        assert row["identity"][field] == value
    else:
        assert type(error) is driver["ns"]["Refusal"] and row["complete"] is False
        assert row["identity"] is None and owner.fault_objects[0] is error
        assert owner.faults[0]["operation"] == "public-native-observation:" + str(descriptor)
    assert not driver["effects"] and not any(x[0] == "Popen" for x in driver["ordering"])
    assert owner.finish(error) is error
    assert owner.closed and owner.root_closed and not driver["owned_fds"]


@pytest.mark.parametrize("field,low,high", _H48_IDENTITY_LIMITS)
@pytest.mark.parametrize("damage", ["missing", "extra", "below", "above", "bool", "false-bool", "null", "string", "float", "null-container", "list-container"])
def test_h48_same_reader_rejects_typed_identity_corruption_after_digest_rebind(field, low, high, damage):
    # The complete actual-owner positive runs BEFORE the intended private corruption.
    outcome = _r36_native_case("file-shared", earlier_error=True, payload=b"H48_SOURCE\n")
    def edit(records):
        target = records[0]["public_transport"]["profiles"][0]["before"]["identity"]
        if damage == "missing":
            del target[field]
        elif damage == "extra":
            target["unowned_extra_identity"] = 0
        elif damage in {"null-container", "list-container"}:
            records[0]["public_transport"]["profiles"][0]["before"]["identity"] = None if damage == "null-container" else list(target)
        else:
            target[field] = {"below": low - 1, "above": high + 1, "bool": True, "false-bool": False,
                             "null": None, "string": "0", "float": 0.0}[damage]
    damaged = _r36_rebind_corrupted_private_journal(outcome, edit)
    with pytest.raises(AssertionError, match="invalid Darwin native identity"):
        _events(damaged)
    assert damaged.hook_context["disposition"] == "protocol-incomplete"
    assert outcome["result"].hook_context["transport_verification"]["exact_private_source"] is True


@pytest.mark.parametrize("field", ["dev", "rdev"])
def test_h48_changed_in_range_signed_identity_does_not_authorize_restore(field):
    import struct
    driver = _h4_inert([_h4_raw()]); owner = driver["owner"]
    owner.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    old = dict(owner.public_baselines[1]["identity"])
    driver["identities"][1]["st_" + field] = -1
    ioctl = driver["ns"]["fcntl"].ioctl; effects = []
    def recorded(fd, request, payload):
        effects.append((fd, struct.unpack("i", payload)[0], owner.phase))
        return ioctl(fd, request, payload)
    driver["ns"]["fcntl"].ioctl = recorded
    with pytest.raises(driver["ns"]["Refusal"], match="identity") as first:
        owner.public_narrow(1, False)
    assert owner.public_baselines[1]["identity"] == old
    assert owner.finish(first.value) is first.value
    assert not any(fd == 1 for fd, _, _ in effects)
    assert any(fd == 2 and phase == "public-flags-restore:2" for fd, _, phase in effects)
    assert not driver["flags"][2] & os.O_NONBLOCK
    assert owner.closed and owner.root_closed and not driver["effects"]


@pytest.mark.parametrize("route", ["socket", "socket-shared"])
@pytest.mark.parametrize("initial", [False, True])
@pytest.mark.parametrize("earlier_error", [False, True])
def test_h48_real_signed_socket_identity_is_preserved_through_same_reader(route, initial, earlier_error):
    outcome = _r36_native_case(route, initial, earlier_error=earlier_error)
    owner, context = outcome["driver"]["owner"], outcome["result"].hook_context
    for descriptor in (1, 2):
        before = context["transport"]["profiles"][descriptor]["snapshot"]["identity"]
        after = context["transport"]["post_state"]["descriptors"][descriptor]["snapshot"]["identity"]
        # This current-host NODEV capability witness retains the actual Python -1;
        # future changed host behavior requires new evidence, never normalization.
        assert type(before["dev"]) is int and before["dev"] == -1
        assert owner.public_baselines[descriptor]["identity"] == before == after
        assert owner.public_profiles[descriptor]["before"]["identity"] == before
    assert context["transport_verification"]["exact_private_source"] is True
    assert context["transport_verification"]["normalized_received_bytes"] is False


@pytest.mark.parametrize("field", ["dev", "ino", "rdev", "mode", "uid", "gid"])
@pytest.mark.parametrize("descriptor", [1, 2])
def test_h48_missing_actual_native_attribute_stays_unavailable_without_effect(field, descriptor):
    driver = _h4_inert([_h4_raw()]); owner = driver["owner"]
    del driver["identities"][descriptor]["st_" + field]
    row, error = owner.public_snapshot(descriptor)
    assert type(error) is AttributeError and row["complete"] is False and row["identity"] is None
    assert owner.fault_objects[0] is error
    assert not driver["effects"] and not any(x[0] == "Popen" for x in driver["ordering"])
    assert owner.finish(error) is error
    assert owner.closed and owner.root_closed and not driver["owned_fds"]


@pytest.mark.parametrize("damage", ["null", "string", "short", "long", "dev-low", "dev-high", "dev-bool", "dev-float", "ino-low", "ino-high", "ino-bool", "ino-float"])
def test_h48_same_reader_compact_filesystem_pair_domain_is_independent_of_digest(damage):
    import copy
    outcome = _r36_native_case("file-shared", earlier_error=True, payload=b"H48_PAIR_SOURCE\n")
    actual = outcome["result"]; damaged = copy.copy(actual)
    damaged.hook_context = copy.deepcopy(actual.hook_context)
    owner = outcome["driver"]["owner"]; terminal = owner.control_writes[-1]["raw"]
    end = json.loads(terminal.removeprefix(b"NOTEBOOK_HOOK "))
    pair = list(end["events_identity"])
    if damage in {"null", "string", "short", "long"}:
        pair = {"null": None, "string": "identity", "short": pair[:1], "long": pair + [0]}[damage]
    elif damage.startswith("dev-"):
        pair[0] = {"dev-low": -(1 << 31) - 1, "dev-high": 1 << 31,
                   "dev-bool": True, "dev-float": 0.0}[damage]
    else:
        pair[1] = {"ino-low": -1, "ino-high": 1 << 64,
                   "ino-bool": False, "ino-float": 0.0}[damage]
    end["events_identity"] = pair
    replacement = b"NOTEBOOK_HOOK " + json.dumps(end, separators=(",", ":"), ensure_ascii=True).encode()
    transport = damaged.hook_context["transport"]; group = transport["groups"][transport["control_group"]]
    assert group["wire"].endswith(terminal)
    group["wire"] = group["wire"][:-len(terminal)] + replacement
    with pytest.raises(AssertionError, match="invalid Darwin filesystem identity pair"):
        _events(damaged)
    assert damaged.hook_context["disposition"] == "protocol-incomplete"
    assert actual.hook_context["transport"]["groups"][transport["control_group"]]["wire"].endswith(terminal)


# CPython forward-image complements: DATA here; ROOT executes the original module.
_H53_DEVICE_IMAGE_CASES = [
    (-1, True), (0, True), ((1 << 31) - 1, True),
    ((1 << 64) - (1 << 31), True), ((1 << 64) - 2, True),
    (-2, False), (-(1 << 31), False), (1 << 31, False), (1 << 32, False),
    ((1 << 64) - (1 << 31) - 1, False), ((1 << 64) - 1, False), (1 << 64, False),
]


@pytest.mark.parametrize("field", ["dev", "rdev"])
@pytest.mark.parametrize("descriptor", [1, 2])
@pytest.mark.parametrize("value,accepted", _H53_DEVICE_IMAGE_CASES)
def test_h53_actual_snapshot_device_forward_image_islands_and_gaps(field, descriptor, value, accepted):
    driver = _h4_inert([_h4_raw()]); owner = driver["owner"]
    driver["identities"][descriptor]["st_" + field] = value
    row, error = owner.public_snapshot(descriptor)
    if accepted:
        assert error is None and row["complete"] is True
        assert type(row["identity"][field]) is int and row["identity"][field] == value
    else:
        assert type(error) is driver["ns"]["Refusal"] and row["complete"] is False and row["identity"] is None
        assert owner.fault_objects[0] is error
    assert not driver["effects"] and not any(x[0] == "Popen" for x in driver["ordering"])
    assert owner.finish(error) is error
    assert owner.closed and owner.root_closed and not driver["owned_fds"]


@pytest.mark.parametrize("field", ["uid", "gid"])
@pytest.mark.parametrize("value,accepted", [(-1, True), (0, True), ((1 << 32) - 2, True), (-2, False), ((1 << 32) - 1, False), (1 << 32, False)])
def test_h53_actual_snapshot_user_group_conversion_sentinel_image(field, value, accepted):
    driver = _h4_inert([_h4_raw()]); owner = driver["owner"]
    driver["identities"][1]["st_" + field] = value
    row, error = owner.public_snapshot(1)
    if accepted:
        assert error is None and row["complete"] is True and row["identity"][field] == value
    else:
        assert type(error) is driver["ns"]["Refusal"] and row["identity"] is None and row["complete"] is False
        assert owner.fault_objects[0] is error
    assert not driver["effects"] and not any(x[0] == "Popen" for x in driver["ordering"])
    assert owner.finish(error) is error
    assert owner.closed and owner.root_closed and not driver["owned_fds"]


@pytest.mark.parametrize("field", ["dev", "rdev"])
@pytest.mark.parametrize("value", [-2, 1 << 31, (1 << 64) - (1 << 31) - 1, (1 << 64) - 1, 1 << 64])
def test_h53_same_reader_rejects_device_image_gaps_after_digest_rebind(field, value):
    outcome = _r36_native_case("file-shared", earlier_error=True, payload=b"H53_SOURCE\n")
    def edit(records):
        records[0]["public_transport"]["profiles"][0]["before"]["identity"][field] = value
    damaged = _r36_rebind_corrupted_private_journal(outcome, edit)
    with pytest.raises(AssertionError, match="invalid Darwin native identity domain"):
        _events(damaged)
    assert damaged.hook_context["disposition"] == "protocol-incomplete"
    assert outcome["result"].hook_context["transport_verification"]["exact_private_source"] is True


@pytest.mark.parametrize("field", ["dev", "rdev", "uid", "gid"])
def test_h53_same_reader_changed_in_image_identity_still_requires_equality(field):
    outcome = _r36_native_case("file-shared", earlier_error=True, payload=b"H53_EQUALITY\n")
    def edit(records):
        records[0]["public_transport"]["profiles"][0]["before"]["identity"][field] = -1
    original = outcome["result"].hook_context["transport"]["profiles"][1]["snapshot"]["identity"][field]
    assert original != -1
    damaged = _r36_rebind_corrupted_private_journal(outcome, edit)
    with pytest.raises(AssertionError):
        _events(damaged)
    assert damaged.hook_context["disposition"] == "protocol-incomplete"
    assert "invalid Darwin native identity" not in damaged.hook_context["protocol_error"]
    assert outcome["result"].hook_context["transport_verification"]["exact_private_source"] is True


@pytest.mark.parametrize("route", ["pty-normal", "pty-normal-shared", "pty-raw"])
@pytest.mark.parametrize("initial", [False, True])
@pytest.mark.parametrize("earlier_error", [False, True])
def test_h53_real_pty_upper_device_image_is_preserved_through_same_reader(route, initial, earlier_error):
    outcome = _r36_native_case(route, initial, earlier_error=earlier_error)
    owner, context = outcome["driver"]["owner"], outcome["result"].hook_context
    for descriptor in (1, 2):
        before = context["transport"]["profiles"][descriptor]["snapshot"]["identity"]
        after = context["transport"]["post_state"]["descriptors"][descriptor]["snapshot"]["identity"]
        assert type(before["dev"]) is int and (1 << 64) - (1 << 31) <= before["dev"] < (1 << 64) - 1
        assert owner.public_baselines[descriptor]["identity"] == before == after
        assert owner.public_profiles[descriptor]["before"]["identity"] == before
    assert context["transport_verification"]["exact_private_source"] is True
    assert context["transport_verification"]["normalized_received_bytes"] is False


@pytest.mark.parametrize("value,in_image", [(-2, False), (1 << 31, False), ((1 << 64) - (1 << 31) - 1, False), ((1 << 64) - 1, False), (-1, True)])
def test_h53_compact_filesystem_device_image_and_actual_identity_remain_separate(value, in_image):
    import copy
    outcome = _r36_native_case("file-shared", earlier_error=True, payload=b"H53_PAIR\n")
    actual = outcome["result"]; damaged = copy.copy(actual)
    damaged.hook_context = copy.deepcopy(actual.hook_context)
    terminal = outcome["driver"]["owner"].control_writes[-1]["raw"]
    end = json.loads(terminal.removeprefix(b"NOTEBOOK_HOOK "))
    assert end["events_identity"][0] != value
    end["events_identity"][0] = value
    replacement = b"NOTEBOOK_HOOK " + json.dumps(end, separators=(",", ":"), ensure_ascii=True).encode()
    transport = damaged.hook_context["transport"]; group = transport["groups"][transport["control_group"]]
    assert group["wire"].endswith(terminal)
    group["wire"] = group["wire"][:-len(terminal)] + replacement
    with pytest.raises(AssertionError):
        _events(damaged)
    assert damaged.hook_context["disposition"] == "protocol-incomplete"
    assert ("invalid Darwin filesystem identity pair" not in damaged.hook_context["protocol_error"]) is in_image
    assert actual.hook_context["transport"]["groups"][transport["control_group"]]["wire"].endswith(terminal)


# Coupled continuation controls. These use the existing actual-source inert
# boundary; they are SOURCE/UNRUN and never native-host qualification.
def _h65_source_scope(driver, owned=None, pending=None):
    owner=driver["owner"]
    owner.command_id=1;owner.phase="running"
    owner.process_scope=dict(command_id=1,cli_pid=1,cli_unreaped=True,
        owned={} if owned is None else owned,pending={} if pending is None else pending)
    return owner


def test_h65_foreign_only_observation_replacement_keeps_both_attempts_one_deadline():
    foreign=_h4_raw(_h4_child(70,parent=0,state="?Es"))
    d=_h4_inert([foreign,_h4_raw()]);o=_h65_source_scope(d)
    rows=d["ns"]["process_rows"]()
    sample=next(row for row in d["events"]if row["event"]=="process_observation")
    assert 70 not in rows and len(d["calls"])==2 and not o.faults and not d["effects"]
    assert sample["sequence"]==1 and len(sample["attempts"])==2 and sample["complete"]
    first,last=sample["attempts"]
    assert not first["complete"] and first["error_arguments"]==["unsupported native STAT"]
    assert first["foreign_proof"]["protected_pids"]==[1,99]
    assert first["deadline"]==last["deadline"]==sample["deadline"]==2
    assert sample["admitted_attempt"]==last["attempt_id"] and o.process_admissions[-1]["sequence"]==1
    assert first["stdout_ref"]["file"]!=last["stdout_ref"]["file"]


@pytest.mark.parametrize("case",["cli","observer","retained","pending","ancestor","mixed","cycle","missing-parent","trailing","missing-scope"])
def test_h65_protected_or_unproved_unknown_never_retries_or_confers_authority(case):
    unknown=_h4_child(70,parent=0,state="?")
    sample=_h4_raw(unknown);owned={};pending={}
    identity=dict(ppid=1,pgid=1,birth=["Tue","Oct","20","01:00:00","2026"],state="Rs",command=["owned child"])
    if case=="cli":sample=sample.replace(b"Ss owned CLI",b"? owned CLI")
    if case=="observer":sample=sample.replace(b"Ss hook observer",b"? hook observer")
    if case in {"retained","pending"}:
        sample=_h4_raw(_h4_child(10,parent=0,state="?",command="changed executable"))
        (owned if case=="retained" else pending)["10"]=identity
    if case=="ancestor":sample=sample.replace(b"99 0 99",b"99 70 99")
    if case=="mixed":sample+=_h4_child(10,state="?").encode()
    if case=="cycle":sample=_h4_raw(_h4_child(70,parent=71,state="?"),_h4_child(71,parent=70))
    if case=="missing-parent":sample=_h4_raw(_h4_child(70,parent=700,state="?"))
    if case=="trailing":sample+=b"bad trailing row"
    d=_h4_inert([sample,_h4_raw()]);o=_h65_source_scope(d,owned,pending)
    if case=="missing-scope":o.process_scope=None
    with pytest.raises(d["ns"]["Refusal"]):d["ns"]["process_rows"]()
    assert len(d["calls"])==1 and not d["effects"] and not o.process_admissions
    assert o.fault_records[0]["operation"]=="process-observation-parse"


@pytest.mark.parametrize("ending",["persistent","late","native-error"])
def test_h65_failed_replacement_keeps_original_unknown_object_time_and_budget(ending):
    foreign=_h4_raw(_h4_child(70,parent=0,state="?"));holder={}
    def replacement():
        if ending=="persistent":return foreign
        if ending=="late":holder["d"]["clock"].value=2;return _h4_raw()
        raise OSError("REPLACEMENT_NATIVE_FAILURE")
    d=_h4_inert([foreign,replacement]);holder["d"]=d;o=_h65_source_scope(d)
    with pytest.raises(d["ns"]["Refusal"]):d["ns"]["process_rows"]()
    assert len(d["calls"])==2 and not d["effects"] and not o.process_admissions
    assert o.fault_records[0]["operation"]=="process-observation-parse"
    assert o.fault_records[0]["observed_monotonic"]==0
    assert o.fault_records[0]["arguments"]["items"][0]["value"]=="unsupported native STAT"
    assert o.command_cleanup_deadline<=15


def test_h65_partial_event_cursor_resumes_original_bytes_before_higher_receipts():
    d=_h4_inert([_h4_raw()]);o=d["owner"];o.command_id=1;api=d["ns"]["os"];write=api.write
    o.deadline=.25;hit=[]
    def partial(fd,raw):
        if fd==o.events and not hit:
            hit.append(True);n=write(fd,raw[:1]);d["clock"].value=.25;return n
        return write(fd,raw)
    api.write=partial
    with pytest.raises(d["ns"]["Refusal"]):o.event("empty",dict(ordinal=1,payload="ORIGINAL_CURSOR"))
    first=(o.root/"events.jsonl").read_bytes()
    assert hit and first==b"{" and o.custody[0]["chunk"]>=1
    api.write=write;d["clock"].value=.5;o.phase="final-observation";o.deadline=2.5
    o.begin_custody_window("final-observation",.5,2.5,2)
    o.settle_custody(o.deadline)
    o.event("empty",dict(ordinal=2,payload="HIGHER"))
    raw=(o.root/"events.jsonl").read_bytes();records=[json.loads(line)for line in raw.splitlines()]
    assert raw.startswith(first) and records[0]==dict(event="empty",ordinal=1,payload="ORIGINAL_CURSOR")
    assert records[-1]==dict(event="empty",ordinal=2,payload="HIGHER")
    assert not o.custody and not o.deferred_faults
    initial=[row for row in records if row["event"]=="fault"]
    completed=[row for row in records if row["event"]=="fault_completion"]
    assert initial and all(row["complete"] is False and row["persisted"] is False for row in initial)
    assert {row["fault_id"]for row in completed}=={row["fault_id"]for row in initial}


def test_h65_permanent_private_sink_failure_does_not_receive_finish_grace():
    d=_h4_inert([_h4_raw()]);o=d["owner"];api=d["ns"]["os"];write=api.write
    original=OSError("PERMANENT_EVENT_FAILURE")
    def broken(fd,raw):
        if fd==o.events:raise original
        return write(fd,raw)
    api.write=broken;o.deadline=1
    with pytest.raises(OSError)as caught:o.event("empty",dict(payload="NEVER_DROPPED"))
    assert caught.value is original and o.custody
    before=(o.root/"events.jsonl").read_bytes()
    assert o.finish(original)is original
    assert o.closed and o.root_closed and o.custody
    assert (o.root/"events.jsonl").read_bytes()==before


@pytest.mark.parametrize("earlier",[False,True])
def test_h65_expired_settlement_census_preserves_chronological_actual_first_cause(earlier):
    d=_h4_inert([_h4_raw()]);o=_h65_source_scope(d)
    cap_error=d["ns"]["Refusal"]("command exited rc=0 but inherited pipes remain open")
    o.command_settlement_deadline=.5
    o.settlement_state=dict(returncode=0,open_pipes=True,observed_monotonic=0,error=cap_error)
    prior=d["ns"]["Refusal"]("EARLIER_OWNED_UNKNOWN")
    if earlier:o.fault("process-observation-parse",prior,observed_monotonic=.25)
    d["clock"].value=.5
    later=d["ns"]["Refusal"]("LATER_CENSUS_DEADLINE")
    o.fault("process-observation-subprocess",later)
    assert o.fault_objects[0]is(prior if earlier else cap_error)
    assert o.fault_records[0]["observed_monotonic"]==(.25 if earlier else .5)
    assert o.command_cleanup_deadline<=.5 and not d["effects"]



def _h65_watched_native_foreign_case():
    from types import SimpleNamespace
    def setup(driver,native):
        query=driver["ns"]["subprocess"].run;seen=[]
        def foreign(argv,**kwargs):
            if not seen:
                seen.append(True)
                return SimpleNamespace(returncode=0,stdout=_h4_raw(_h4_child(70,parent=0,state="?Es")),stderr=b"")
            return query(argv,**kwargs)
        driver["ns"]["subprocess"].run=foreign
        original=driver["ns"]["run"]
        def watched(*args,**kwargs):
            kwargs["watch"]=True
            return original(*args,**kwargs)
        driver["ns"]["run"]=watched
    return _r36_native_case("file-shared",earlier_error=True,payload=b"H65_FOREIGN_PROOF\n",mutate=setup)


@pytest.mark.parametrize("damage",["protection","ancestry","protected-raw","deadline","attempt-drop","scope","admission-drop","admission-time"])
def test_h65_same_reader_independently_rejects_rebound_foreign_proof_or_authority(damage):
    outcome=_h65_watched_native_foreign_case()
    def edit(records):
        sample=next(row for row in records if row["event"]=="process_observation"and len(row["attempts"])==2)
        first=sample["attempts"][0]
        if damage=="protection":first["foreign_proof"]["protected_pids"]=[]
        elif damage=="ancestry":first["foreign_proof"]["parent_paths"]["70"]=[70,99]
        elif damage=="protected-raw":
            reference=first["stdout_ref"]
            path=outcome["driver"]["owner"].root/reference["file"]
            raw=path.read_bytes();assert raw.count(b"70 0 1 ")==1
            forged=raw.replace(b"70 0 1 ",b"70 99 1 ")
            path.write_bytes(forged)
            reference.update(bytes=len(forged),available_bytes=len(forged),sha256=hashlib.sha256(forged).hexdigest())
            first["foreign_proof"]["parent_paths"]["70"]=[70,99]
        elif damage=="deadline":first["deadline"]+=2
        elif damage=="attempt-drop":sample["attempts"].pop(0)
        elif damage=="scope":sample["scope"]["pending"]={"70":dict(ppid=0,pgid=1,birth=[],state="?",command=["foreign"])}
        else:
            end=next(row for row in records if row["event"]=="command_end"and row["command_id"]==sample["command_id"])
            admission=next(item for item in end["observations_admitted"]if item["sequence"]==sample["sequence"])
            if damage=="admission-drop":end["observations_admitted"].remove(admission)
            else:admission["committed_monotonic"]=sample["deadline"]
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"
    assert outcome["result"].hook_context["transport_verification"]["exact_private_source"] is True



@pytest.mark.parametrize("route",["socket-shared","pty-normal-shared"])
def test_h65_deliberately_undrained_native_pressure_remains_protocol_incomplete(route):
    # Actual native endpoints and original owner/reader; no synthetic count or
    # relaxed scientific-failure oracle. This is intentionally an unhealthy sink.
    with pytest.raises(AssertionError,match="protocol|syscall-raised|incomplete"):
        _r36_native_case(route,earlier_error=True,payload=b"PRESSURE\r\n"*(1<<17),receiver_policy="undrained")


@pytest.mark.parametrize("substituted",[False,True])
def test_h65_actual_fifo_teardown_refuses_foreign_replacement(tmp_path,substituted):
    import ast
    import copy
    tree=ast.parse(Path(__file__).read_text())
    caller=next(node for node in tree.body if isinstance(node,ast.FunctionDef)and node.name=="test_r36_real_hook_native_sink_science_once_and_same_reader")
    cleanup=next(node for node in ast.walk(caller)if isinstance(node,ast.FunctionDef)and node.name=="remove_owned_fifo")
    fifo=tmp_path/"owned-fifo";os.mkfifo(fifo,0o600);created=fifo.lstat()
    if substituted:
        fifo.rename(tmp_path/"retained-original-fifo")
        os.mkfifo(fifo,0o600)
    namespace=dict(fifo=fifo,created=created,stat=stat)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(cleanup)],type_ignores=[])),str(HOOK)+":actual-owned-FIFO-cleanup-only","exec"),namespace)
    current=fifo.lstat()
    if substituted:
        with pytest.raises(AssertionError):namespace["remove_owned_fifo"]()
        assert fifo.lstat()==current and stat.S_ISFIFO(current.st_mode)
    else:
        read=os.open(fifo,os.O_RDONLY|os.O_NONBLOCK);write=os.open(fifo,os.O_WRONLY|os.O_NONBLOCK)
        os.close(write);os.close(read)
        namespace["remove_owned_fifo"]()
        assert not fifo.exists()



def test_h65_earlier_signal_time_precedes_a_later_held_foreign_diagnostic():
    d=_h4_inert([_h4_raw()]);o=_h65_source_scope(d)
    unknown=d["ns"]["Refusal"]("unsupported native STAT")
    actual_signal=d["ns"]["Refusal"]("interrupted by signal 15")
    o.pre_admission_diagnostic=(unknown,.5)
    o.fault("caught-signal",actual_signal,observed_monotonic=.25)
    assert o.fault_objects[0]is actual_signal and o.fault_objects[1]is unknown
    assert o.fault_records[0]["observed_monotonic"]==.25
    assert o.fault_records[1]["observed_monotonic"]==.5
    assert not d["effects"]



def _h65_completed_raw_native_case():
    def setup(driver,native):
        owner=driver["owner"];api=driver["ns"]["os"];write=api.write;hit=[]
        def returned_prefix_then_deadline(fd,raw):
            if fd not in (1,2,owner.events) and not hit:
                hit.append(fd)
                count=write(fd,raw[:1])
                driver["clock"].value=owner.deadline
                return count
            return write(fd,raw)
        api.write=returned_prefix_then_deadline
    return _r36_native_case("file-shared",payload=b"H65_RAW_COMPLETION\n",mutate=setup)


@pytest.mark.parametrize("damage",["prefix-length","completion-time","digest","missing-completion"])
def test_h65_same_reader_checks_both_original_and_completed_raw_after_digest_rebind(damage):
    outcome=_h65_completed_raw_native_case()
    assert any(row["event"]=="raw_completion"for row in outcome["records"])
    def edit(records):
        completion=next(row for row in records if row["event"]=="raw_completion")
        if damage=="completion-time":completion["completion_deadline"]=completion["completed_monotonic"]
        elif damage=="digest":completion["available"]["sha256"]="0"*64
        elif damage=="missing-completion":records.remove(completion)
        else:
            original=completion["original"];original["bytes"]+=1
            original["missing_ranges"]=[[original["bytes"],original["available_bytes"]]]
            pending=next(row for row in records if row["event"]=="command_channel_pending"and row["available"]["file"]==original["file"])
            pending["available"]=dict(original);pending["end"]=pending["offset"]+original["bytes"]
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"
    assert outcome["result"].hook_context["transport_verification"]["exact_private_source"] is True



def test_h65_expired_pending_event_cannot_flush_in_terminal_finish():
    d=_h4_inert([_h4_raw()]);o=d["owner"];api=d["ns"]["os"];write=api.write;hit=[]
    o.deadline=.25
    def expired(fd,raw):
        if fd==o.events and not hit:
            hit.append(True);count=write(fd,raw[:1]);d["clock"].value=.25;return count
        return write(fd,raw)
    api.write=expired
    with pytest.raises(d["ns"]["Refusal"])as original:o.event("empty",dict(payload="NO_FINISH_GRACE"))
    api.write=write
    before=(o.root/"events.jsonl").read_bytes()
    assert before==b"{" and o.custody
    assert o.finish(original.value)is original.value
    assert (o.root/"events.jsonl").read_bytes()==before
    assert o.closed and o.root_closed and o.custody


@pytest.mark.parametrize("signal_position",["before-unknown","after-unknown"])
@pytest.mark.parametrize("ending",["failed-proof","trailing-malformed","replacement-error"])
def test_h69_actual_parser_reserves_unknown_and_merges_handler_chronology(signal_position,ending):
    raw=_h4_raw(_h4_child(70,parent=700 if ending=="failed-proof"else 0,state="?Es"),
                _h4_child(71,parent=0))
    if ending=="trailing-malformed":raw+=b"bad trailing row"
    d=_h4_inert([raw,OSError("H69_SECOND_QUERY_FAILURE")]);o=_h65_source_scope(d)
    original=d["ns"]["require"];seen=[];injected=[]
    def require(condition,message):
        if message=="unsupported native STAT"and condition and not seen:
            d["clock"].value=.25;seen.append(True)
            if signal_position=="before-unknown":
                d["ns"]["interrupted"](signal.SIGTERM,None);injected.append(True)
        elif message=="duplicate PID"and seen and not injected:
            d["clock"].value=.75
            d["ns"]["interrupted"](signal.SIGTERM,None);injected.append(True)
        return original(condition,message)
    d["ns"]["require"]=require
    with pytest.raises(d["ns"]["Refusal"]):d["ns"]["process_rows"]()
    causes=[row for row in o.fault_records if row["operation"]in{"caught-signal","process-observation-parse"}]
    assert seen and injected and len(causes)>=2
    # These parsing-time signals are detected by the valid post-parse checkpoint;
    # the old ending labels do not claim proof/second-query activation.
    assert len(d["calls"])==1
    assert not any(row["operation"]=="process-observation-foreign-proof"for row in o.fault_records)
    unknown=next(row for row in causes if row["operation"]=="process-observation-parse")
    caught=next(row for row in causes if row["operation"]=="caught-signal")
    assert unknown["observed_monotonic"]==.25
    assert caught["observed_monotonic"]==(.25 if signal_position=="before-unknown"else .75)
    assert causes[0]is(caught if signal_position=="before-unknown"else unknown)
    assert o.fault_objects[o.fault_records.index(unknown)].args==("unsupported native STAT",)
    assert not o.process_admissions and not d["effects"]
    assert o.command_cleanup_deadline==causes[0]["observed_monotonic"]+15


@pytest.mark.parametrize("damage",["none","missing","stale-sequence","wrong-command","wrong-attempt","late","changed-identity"])
def test_h69_actual_signal_uses_fresh_committed_current_observation(damage):
    d=_h4_inert([_h4_raw(_h4_child())]);o=_h65_source_scope(d)
    h=d["helper"];original=d["ns"]["process_rows"]
    def query(*args,**kwargs):
        rows=original(*args,**kwargs)
        admission=o.process_admissions[-1]
        if damage=="missing":o.process_admissions.pop()
        elif damage=="stale-sequence":admission["sequence"]-=1
        elif damage=="wrong-command":admission["command_id"]+=1
        elif damage=="wrong-attempt":admission["attempt_id"]-=1
        elif damage=="late":d["clock"].value=admission["deadline"]
        elif damage=="changed-identity":
            rows[10]["birth"]=["Wed","Oct","21","01:00:00","2026"]
        return rows
    if damage=="changed-identity":
        # Establish the original actual retained identity before the changed sample.
        h["reconcile_identity"](h["observe"]())
    d["ns"]["process_rows"]=query
    if damage in{"missing","stale-sequence","wrong-command","wrong-attempt","late"}:
        h["signal_descendants"](signal.SIGTERM,deadline=2)
        assert not d["effects"]and o.fault_records and h["observation_errors"]
    else:
        h["signal_descendants"](signal.SIGTERM,deadline=2)
        receipts=h["signals"]
        if damage=="changed-identity":assert not receipts and not d["effects"]
        else:
            assert len(receipts)==1 and d["effects"]==[dict(kind="pid",target=10,signal=int(signal.SIGTERM))]
            receipt=receipts[0];authority=receipt["observation_authority"]
            assert authority==o.process_admissions[-1]
            assert authority["command_id"]==o.command_id and authority["sequence"]==d["ns"]["PROCESS_OBSERVATION_SEQUENCE"]
            assert authority["attempt_id"]==o.native_attempt_sequence
            assert authority["committed_monotonic"]<=receipt["observed_monotonic"]<authority["deadline"]
            assert receipt["identity"]["birth"]==["Tue","Oct","20","01:00:00","2026"]


@pytest.mark.parametrize("field",["attempts","scope","started_monotonic","ended_monotonic","deadline","argv","locale","complete","returncode","stdout_ref","stderr_ref","error","started_utc","ended_utc","phase","sequence","command_id"])
@pytest.mark.parametrize("late",[False,True])
def test_h69_same_reader_requires_every_current_observation_field_even_with_late_commit(field,late):
    outcome=_h65_watched_native_foreign_case()
    def edit(records):
        row=next(item for item in records if item["event"]=="process_observation"and len(item["attempts"])==2)
        if late:
            end=next(item for item in records if item["event"]=="command_end"and item["command_id"]==row["command_id"])
            admission=next(item for item in end["observations_admitted"]if item["sequence"]==row["sequence"])
            admission["committed_monotonic"]=row["deadline"]
        del row[field]
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("field",["attempt_id","ordinal","started_monotonic","ended_monotonic","deadline","returncode","stdout_ref","stderr_ref","complete","error","error_type","error_monotonic","unknown_pids","foreign_proof","launch_state"])
@pytest.mark.parametrize("ordinal",[0,1])
def test_h69_same_reader_requires_each_actual_attempt_field(field,ordinal):
    outcome=_h65_watched_native_foreign_case()
    def edit(records):
        sample=next(row for row in records if row["event"]=="process_observation"and len(row["attempts"])==2)
        del sample["attempts"][ordinal][field]
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("damage",["future-pair","backdated","foreign-command","wrong-phase","unknown-window","budget","capture-before-open","commit-after-close","missing-commit","missing-window","changed-window-begin"])
def test_h69_same_reader_binds_complete_raw_to_actual_original_command_and_windows(damage):
    outcome=_h65_completed_raw_native_case()
    assert any(row["event"]=="raw_completion"for row in outcome["records"])
    def edit(records):
        completion=next(row for row in records if row["event"]=="raw_completion")
        end=next(row for row in records if row["event"]=="command_end"and row["command_id"]==completion["command_id"])
        window=next(row for row in end["custody_windows"]if row["window_id"]==completion["window_id"])
        admission=next(row for row in end["custody_completions"]if row["completion_id"]==completion["completion_id"])
        if damage=="future-pair":completion.update(completed_monotonic=end["ended_monotonic"]+100,completion_deadline=end["ended_monotonic"]+101)
        elif damage=="backdated":completion.update(capture_started_monotonic=-1,completed_monotonic=-.5)
        elif damage=="foreign-command":completion["command_id"]+=1
        elif damage=="wrong-phase":completion["phase"]="final-wait"if completion["phase"]!="final-wait"else"final-drain"
        elif damage=="unknown-window":completion["window_id"]+=1000
        elif damage=="budget":window["budget"]+=1;window["deadline"]+=1;completion["completion_deadline"]+=1
        elif damage=="capture-before-open":completion["capture_started_monotonic"]=window["opened_monotonic"]-.1
        elif damage=="commit-after-close":admission["committed_monotonic"]=end["ended_monotonic"]+1
        elif damage=="missing-commit":end["custody_completions"].remove(admission)
        elif damage=="missing-window":end["custody_windows"].remove(window)
        else:
            begin=next(row for row in records if row["event"]=="custody_window"and row["window_id"]==window["window_id"])
            begin["scheduled_monotonic"]+=1
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


def _h69_native_details_completion_case():
    def setup(driver,native):
        owner=driver["owner"];typed=driver["ns"]["typed_native"];communicate=driver["child"].communicate;hit=[]
        def capture(value,deadline=None,*args,**kwargs):
            if type(value)is tuple and value==("H69_NATIVE_ARGUMENTS",)and not hit:
                hit.append(True);driver["clock"].value=deadline
            return typed(value,deadline,*args,**kwargs)
        driver["ns"]["typed_native"]=capture
        once=[]
        def command(*args,**kwargs):
            if not once:
                once.append(True)
                error=driver["ns"]["Refusal"]("H69_NATIVE_ARGUMENTS")
                owner.fault("h69-native-details",error,native_details=dict(native_results=dict(observed=17)))
                raise error
            return communicate(*args,**kwargs)
        driver["child"].communicate=command
    return _r36_native_case("file-shared",earlier_error=True,payload=b"H69_NATIVE_DETAILS\n",mutate=setup,
        expected_effects=(dict(kind="pid",target=1,signal=int(signal.SIGKILL)),))


def test_h69_same_reader_preserves_already_complete_original_native_details():
    outcome=_h69_native_details_completion_case()
    original=next(row for row in outcome["records"]if row["event"]=="fault"and row["operation"]=="h69-native-details")
    completion=next(row for row in outcome["records"]if row["event"]=="fault_completion"and row["fault_id"]==original["fault_id"])
    assert original["details"]["complete"]and original["details"]==completion["details"]
    def edit(records):
        row=next(item for item in records if item["event"]=="fault_completion"and item["fault_id"]==original["fault_id"])
        row["details"]={"type":"int","value":18,"complete":True}
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("damage",["missing","stale-sequence","wrong-command","wrong-attempt","late","changed-identity"])
def test_h69_same_reader_rejects_unsupported_descendant_signal_claim(damage):
    # A genuine healthy complete owner/reader call precedes a rebound false claim.
    # This is negative receipt validation, never a claim of a real native signal.
    outcome=_h65_watched_native_foreign_case()
    def edit(records):
        children=next(row for row in records if row["event"]=="children")
        end=next(row for row in records if row["event"]=="command_end"and row["command_id"]==children["command_id"])
        authority=dict(end["observations_admitted"][-1])
        effect=dict(kind="observed_descendant",pid=10,signal=int(signal.SIGTERM),
            identity=dict(ppid=1,pgid=1,birth=["Tue","Oct","20","01:00:00","2026"],state="Rs",command=["UNOBSERVED_TARGET"]),
            observation_sample=1,sample_scope="successful_run_observation",observation_authority=authority,
            observed_monotonic=authority["committed_monotonic"],phase="final-observation",outcome="syscall-returned")
        if damage=="missing":del effect["observation_authority"]
        elif damage=="stale-sequence":authority["sequence"]-=1
        elif damage=="wrong-command":authority["command_id"]+=1
        elif damage=="wrong-attempt":authority["attempt_id"]+=1
        elif damage=="late":effect["observed_monotonic"]=authority["deadline"]
        else:effect["identity"]["birth"][2]="21"
        children["signals"].append(effect)
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"



def test_h69_deferred_native_details_use_immutable_original_safe_builtin_snapshot():
    d=_h4_inert([_h4_raw()]);o=_h65_source_scope(d);o.phase="final-wait";o.deadline=.25
    error=d["ns"]["Refusal"]("H69_IMMUTABLE_DETAIL")
    raw=dict(native_results=dict(observed=17));typed=d["ns"]["typed_native"];hit=[]
    def capture(value,deadline=None,*args,**kwargs):
        if type(value)is tuple and value==("H69_IMMUTABLE_DETAIL",)and not hit:
            hit.append(True);d["clock"].value=deadline
        return typed(value,deadline,*args,**kwargs)
    d["ns"]["typed_native"]=capture
    first=o.fault("h69-original-details",error,native_details=raw)
    assert first["details"]["complete"]and not first["complete"]
    original=json.loads(json.dumps(first["details"]))
    raw["native_results"]["observed"]=99
    d["clock"].value=.5;o.phase="final-observation";o.deadline=2.5
    o.begin_custody_window("final-observation",.5,2.5,2);o.settle_custody(2.5)
    records=[json.loads(line)for line in(o.root/"events.jsonl").read_bytes().splitlines()]
    completion=next(row for row in records if row["event"]=="fault_completion"and row["fault_id"]==first["fault_id"])
    assert completion["details"]==original
    assert completion["command_id"]==1 and o.custody_completions
    assert o.custody_completions[-1]["committed_monotonic"]<2.5


@pytest.mark.parametrize("boundary",["capture","format","journal"])
def test_h69_actual_completion_must_commit_inside_existing_window_without_finish_grace(boundary):
    d=_h4_inert([_h4_raw()]);o=_h65_source_scope(d)
    o.phase="final-wait";o.deadline=.25;d["clock"].value=.25
    first=o.fault("h69-window-budget",d["ns"]["Refusal"]("H69_WINDOW_BUDGET"))
    d["clock"].value=.5;o.phase="final-observation";o.deadline=2.5
    o.begin_custody_window("final-observation",.5,2.5,2)
    if boundary=="capture":
        typed=d["ns"]["typed_native"]
        def capture(value,deadline=None,*args,**kwargs):
            d["clock"].value=2.5
            return typed(value,deadline,*args,**kwargs)
        d["ns"]["typed_native"]=capture
    elif boundary=="format":
        chunks=d["ns"]["json_chunks"]
        def format(value):
            if type(value)is dict and value.get("event")=="fault_completion":d["clock"].value=2.5
            yield from chunks(value)
        d["ns"]["json_chunks"]=format
    else:
        write=d["ns"]["os"].write
        def journal(fd,raw):
            result=write(fd,raw)
            if fd==o.events:d["clock"].value=2.5
            return result
        d["ns"]["os"].write=journal
    with pytest.raises(d["ns"]["Refusal"]):o.settle_custody(2.5)
    assert not o.custody_completions
    before=(o.root/"events.jsonl").read_bytes();o.deadline=None
    with pytest.raises(d["ns"]["Refusal"]):o.settle_custody(None)
    assert(o.root/"events.jsonl").read_bytes()==before and not o.custody_completions
    assert first["observed_monotonic"]==.25


@pytest.mark.parametrize("damage",["sample-bool-id","sample-bool-returncode","attempt-bool-returncode","scope-unreaped-type","scope-owned-type","scope-cli-type","sample-reversed-time","attempt-after-sample"])
def test_h69_closed_current_schema_checks_native_types_and_full_intervals(damage):
    outcome=_h65_watched_native_foreign_case()
    def edit(records):
        row=next(item for item in records if item["event"]=="process_observation"and len(item["attempts"])==2)
        if damage=="sample-bool-id":row["sequence"]=True
        elif damage=="sample-bool-returncode":row["returncode"]=False
        elif damage=="attempt-bool-returncode":row["attempts"][-1]["returncode"]=False
        elif damage=="scope-unreaped-type":row["scope"]["cli_unreaped"]=1
        elif damage=="scope-owned-type":row["scope"]["owned"]=[]
        elif damage=="scope-cli-type":row["scope"]["cli_pid"]=True
        elif damage=="sample-reversed-time":row["ended_monotonic"]=row["started_monotonic"]-1
        else:row["attempts"][-1]["ended_monotonic"]=row["ended_monotonic"]+1
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("operation",["failed-proof","second-query"])
def test_h71_actual_failed_operation_signal_has_reachable_activation_and_original_unknown(operation):
    from types import SimpleNamespace
    foreign=_h4_raw(_h4_child(70,parent=700 if operation=="failed-proof"else 0,state="?Es"))
    d=_h4_inert([foreign,_h4_raw()]);o=_h65_source_scope(d)
    original_require=d["ns"]["require"];query=d["ns"]["subprocess"].run
    queries=[];proof_failures=[];second_failures=[]
    def require(condition,message):
        if operation=="failed-proof"and message=="foreign UNKNOWN parent graph incomplete or cyclic"and not condition:
            proof_failures.append(message);d["clock"].value=.75
            d["ns"]["interrupted"](signal.SIGTERM,None)
        return original_require(condition,message)
    def actual_query(*args,**kwargs):
        queries.append(len(queries)+1)
        if operation=="second-query"and len(queries)==2:
            second_failures.append(True);d["clock"].value=.75
            d["ns"]["interrupted"](signal.SIGTERM,None)
            raise OSError(5,"H71_ACTUAL_SECOND_QUERY_FAILURE")
        return query(*args,**kwargs)
    d["ns"]["require"]=require;d["ns"]["subprocess"].run=actual_query
    with pytest.raises(d["ns"]["Refusal"]):d["ns"]["process_rows"]()
    assert queries==([1]if operation=="failed-proof"else[1,2])
    assert bool(proof_failures)==(operation=="failed-proof")and bool(second_failures)==(operation=="second-query")
    first=o.fault_records[0]
    assert first["operation"]=="process-observation-parse"and first["observed_monotonic"]==0
    assert o.fault_objects[0].args==("unsupported native STAT",)
    assert o.command_cleanup_deadline==15 and not o.process_admissions and not d["effects"]
    signal_fault=next(row for row in o.fault_records if row["operation"]=="caught-signal")
    assert signal_fault["observed_monotonic"]==.75
    sample=next(row for row in d["events"]if row["event"]=="process_observation")
    assert len(sample["attempts"])==len(queries)and not sample["complete"]
    if operation=="failed-proof":
        assert sample["attempts"][0]["eligibility_error"]["error"]==proof_failures[0]
        assert any(row["operation"]=="process-observation-foreign-proof"for row in o.fault_records)
    else:
        assert sample["attempts"][0]["foreign_proof"]is not None
        native=next(row for row in o.fault_records if row["operation"]=="process-observation-subprocess")
        assert native["arguments"]["items"]==[dict(type="int",value=5,complete=True),dict(type="str",value="H71_ACTUAL_SECOND_QUERY_FAILURE",complete=True)]


def _h71_os_completion_native_case(interruption):
    assert interruption in("before","within","expiry")
    def setup(driver,native):
        owner=driver["owner"];communicate=driver["child"].communicate;typed=driver["ns"]["typed_native"];hit=[]
        def capture(value,deadline=None,*args,**kwargs):
            if interruption in("within","expiry")and value=="RIGHT"and not hit:
                hit.append(True)
                if interruption=="within":
                    driver["clock"].value=deadline-.5
                    raise driver["ns"]["Refusal"]("H84_PARTIAL_RIGHT_BEFORE_DEADLINE")
                driver["clock"].value=deadline
            return typed(value,deadline,*args,**kwargs)
        driver["ns"]["typed_native"]=capture;once=[]
        def command(*args,**kwargs):
            if not once:
                once.append(True)
                first=driver["ns"]["Refusal"]("H71_ORIGINAL_FIRST_CAUSE")
                owner.fault("h71-first-cause",first)
                error=OSError(5,"H71_NATIVE_OS","LEFT",None,"RIGHT")
                owner.fault("h71-native-os",error,snapshot=interruption!="before",native_details=dict(native_results=dict(observed=17)))
                raise first
            return communicate(*args,**kwargs)
        driver["child"].communicate=command
    return _r36_native_case("file-shared",earlier_error=True,payload=b"H71_NATIVE_OS\n",mutate=setup,
        expected_effects=(dict(kind="pid",target=1,signal=int(signal.SIGKILL if interruption=="expiry"else signal.SIGINT)),))


@pytest.mark.parametrize("interruption",["before","within"])
@pytest.mark.parametrize("damage",["arguments-int","arguments-list","os-missing","os-extra","os-wrong-set","obligation-cleared"])
def test_h71_same_reader_discharges_original_native_capture_obligations(interruption,damage):
    outcome=_h71_os_completion_native_case(interruption)
    _h84_check_native_capture_obligations(outcome,interruption,damage)


def _h84_check_native_capture_obligations(outcome,interruption,damage):
    original=next(row for row in outcome["records"]if row["event"]=="fault"and row["operation"]=="h71-native-os")
    completion=next(row for row in outcome["records"]if row["event"]=="fault_completion"and row["fault_id"]==original["fault_id"])
    assert not original["complete"]and original["capture_obligations"]==dict(arguments_type="tuple",os_fields_requested=True)
    assert completion["arguments"]["type"]=="tuple"and set(completion["os_fields"])=={"filename","filename2","strerror"}
    if interruption=="within":assert original["os_fields"]["filename"]==completion["os_fields"]["filename"]
    def edit(records):
        row=next(value for value in records if value["event"]=="fault_completion"and value["fault_id"]==original["fault_id"])
        if damage=="arguments-int":row["arguments"]=dict(type="int",value=18,complete=True)
        elif damage=="arguments-list":row["arguments"]=dict(type="list",items=row["arguments"]["items"],complete=True)
        elif damage=="os-missing":row["os_fields"]={}
        elif damage=="os-extra":row["os_fields"]["extra"]=dict(type="none",complete=True)
        elif damage=="os-wrong-set":row["os_fields"]={"filename":row["os_fields"]["filename"]}
        else:row["capture_obligations"]["os_fields_requested"]=False
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


def _h71_timed_completion_native_case(resume=False):
    def setup(driver,native):
        owner=driver["owner"];api=driver["ns"]["os"];write=api.write;reserve=owner.reserve_event
        begin=owner.begin_custody_window;additional_debt=[]
        raw_failure=[];target=[];write_seen=[];trace=[]
        def original_window(*args,**kwargs):
            result=begin(*args,**kwargs)
            if not additional_debt:
                additional_debt.append(True)
                row=owner.fault("h71-explicit-unavailable-capture",driver["ns"]["Refusal"]("H71_SECOND_COMPLETION_DEBT"),snapshot=False)
                assert not row["complete"]
                trace.append(dict(operation="second-completion-debt",fault_id=row["fault_id"]))
            return result
        owner.begin_custody_window=original_window
        driver["h71_completion_trace"]=trace
        def reserved(event,fields,fault_row=None):
            host_started=time.monotonic()
            item=reserve(event,fields,fault_row)
            host_ended=time.monotonic()
            if event in("fault_completion","raw_completion")and not target:
                target.append(fields["completion_id"])
                assert item["completion"]["completion_id"]==target[0]
                assert host_ended>host_started
                trace.append(dict(operation="reserved",completion_id=target[0],window_id=fields["window_id"],completed=fields["completed_monotonic"],host_started=host_started,host_ended=host_ended))
                # Charge the actually observed reservation duration, no invented gap.
                driver["clock"].value+=host_ended-host_started
            return item
        def returned(fd,raw):
            if fd not in(1,2,owner.events)and not raw_failure:
                raw_failure.append(True);count=write(fd,raw[:1]);driver["clock"].value=owner.deadline;return count
            item=owner.custody[0]if owner.custody else None
            selected=fd==owner.events and target and item is not None and item["completion"]is not None and item["completion"]["completion_id"]==target[0]
            if selected and not write_seen:
                write_seen.append(True);before=owner.offsets[fd];host_started=time.monotonic()
                count=write(fd,raw[:1]if resume else raw);host_ended=time.monotonic()
                assert host_ended>host_started
                trace.append(dict(operation="actual-returned-write",completion_id=target[0],returned=count,offset_before=before,window_id=owner.active_custody_window["window_id"],host_started=host_started,host_ended=host_ended))
                driver["clock"].value=owner.deadline if resume else driver["clock"].value+(host_ended-host_started)
                return count
            return write(fd,raw)
        owner.reserve_event=reserved;api.write=returned
    return _r36_native_case("file-shared",earlier_error=True,payload=b"H71_ORDERED_COMPLETION\n",mutate=setup)


@pytest.mark.parametrize("damage",["capture-after-commit-start","capture-window-after-completion","command-before-begin","completion-id-order","admission-id-order"])
def test_h71_same_reader_checks_actual_capture_commit_gap_and_journal_order(damage):
    outcome=_h71_timed_completion_native_case();trace=outcome["driver"]["h71_completion_trace"]
    target=next(row for row in trace if row["operation"]=="reserved")["completion_id"]
    completion=next(row for row in outcome["records"]if row["event"]in{"fault_completion","raw_completion"}and row["completion_id"]==target)
    end=next(row for row in outcome["records"]if row["event"]=="command_end"and row["command_id"]==completion["command_id"])
    admission=next(row for row in end["custody_completions"]if row["completion_id"]==target)
    assert completion["completed_monotonic"]<admission["started_monotonic"]<admission["committed_monotonic"]
    assert any(row["operation"]=="actual-returned-write"and row["returned"]>0 for row in trace)
    def edit(records):
        row=next(value for value in records if value["event"]in{"fault_completion","raw_completion"}and value["completion_id"]==target)
        finish=next(value for value in records if value["event"]=="command_end"and value["command_id"]==row["command_id"])
        admitted=next(value for value in finish["custody_completions"]if value["completion_id"]==target)
        if damage=="capture-after-commit-start":row["completed_monotonic"]=(admitted["started_monotonic"]+admitted["committed_monotonic"])/2
        elif damage=="capture-window-after-completion":
            window=next(value for value in records if value["event"]=="custody_window"and value["window_id"]==row["window_id"])
            # Keep the original fault and completion-ID order intact; move only
            # its capture beginning behind the already captured completion.
            records.remove(window);records.insert(records.index(row)+1,window)
        elif damage=="command-before-begin":
            begin=next(value for value in records if value["event"]=="command_begin"and value["command_id"]==row["command_id"])
            records.remove(row);records.insert(records.index(begin),row)
        elif damage=="completion-id-order":row["completion_id"]+=1000;admitted["completion_id"]+=1000
        else:finish["custody_completions"]=list(reversed(finish["custody_completions"]))
    if damage=="admission-id-order":assert len(end["custody_completions"])>=2
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


def test_h71_later_existing_window_resumes_completion_before_its_own_queued_window_begin():
    outcome=_h71_timed_completion_native_case(resume=True);records=outcome["records"]
    trace=outcome["driver"]["h71_completion_trace"];target=next(row for row in trace if row["operation"]=="reserved")["completion_id"]
    completion=next(row for row in records if row["event"]in{"fault_completion","raw_completion"}and row["completion_id"]==target)
    end=next(row for row in records if row["event"]=="command_end"and row["command_id"]==completion["command_id"])
    admission=next(row for row in end["custody_completions"]if row["completion_id"]==target)
    capture_begin=next(row for row in records if row["event"]=="custody_window"and row["window_id"]==completion["window_id"])
    resume_begin=next(row for row in records if row["event"]=="custody_window"and row["window_id"]==admission["window_id"])
    assert completion["window_id"]!=admission["window_id"]
    assert records.index(capture_begin)<records.index(completion)<records.index(resume_begin)
    assert completion["completed_monotonic"]<=admission["started_monotonic"]<=admission["committed_monotonic"]<admission["deadline"]
    assert outcome["result"].hook_context["transport_verification"]["exact_private_source"]is True
    assert outcome["result"].hook_context["disposition"]!="protocol-incomplete"


@pytest.mark.parametrize("boundary",["capture","serialization","partial-cursor","write-return","admission-rollback"])
def test_h71_actual_completion_boundaries_activate_exact_reservation_before_deadline_fault(boundary):
    d=_h4_inert([_h4_raw()]);o=_h65_source_scope(d);o.phase="final-wait";o.deadline=2
    # Unavailable capture is independent of the deadline equality under test.
    error=d["ns"]["Refusal"]("H71_STABLE_INCOMPLETE_CAPTURE")
    first=o.fault("h71-independent-capture-failure",error,snapshot=False)
    assert not first["complete"]and first["arguments"]is None
    d["clock"].value=.5;o.phase="final-observation";o.deadline=2.5
    o.begin_custody_window("final-observation",.5,2.5,2)
    target=[];trace=[];armed=[];reserve=o.reserve_event;write=d["ns"]["os"].write;window=o.custody_window
    class Admissions(list):
        def append(self,item):trace.append(("append",item["completion_id"]));return super().append(item)
        def pop(self,*args):
            item=super().pop(*args);trace.append(("rollback",item["completion_id"]));return item
    o.custody_completions=Admissions()
    def reserved(event,fields,fault_row=None):
        item=reserve(event,fields,fault_row)
        if event=="fault_completion"and fields["fault_id"]==first["fault_id"]:
            target.append(fields["completion_id"]);trace.append(("reserved",fields["completion_id"]))
            assert item["completion"]["completion_id"]==target[0]and not first["complete"]
        return item
    o.reserve_event=reserved
    if boundary=="capture":
        typed=d["ns"]["typed_native"]
        def capture(value,deadline=None,*args,**kwargs):
            if type(value)is tuple and value==error.args:
                trace.append(("capture",first["fault_id"]));d["clock"].value=2.5
            return typed(value,deadline,*args,**kwargs)
        d["ns"]["typed_native"]=capture
    elif boundary=="serialization":
        chunks=d["ns"]["json_chunks"]
        def encode(value):
            if type(value)is dict and value.get("event")=="fault_completion"and value["fault_id"]==first["fault_id"]and not armed:
                item=o.custody[-1];number=value["completion_id"]
                assert item["completion"]["completion_id"]==number
                armed.append(number);trace.append(("serialization-reserved",number));d["clock"].value=2.5
            yield from chunks(value)
        d["ns"]["json_chunks"]=encode
    elif boundary in{"partial-cursor","write-return"}:
        def returned(fd,raw):
            item=o.custody[0]if o.custody else None
            selected=target and fd==o.events and item is not None and item["completion"]is not None and item["completion"]["completion_id"]==target[0]
            at_target=selected and(boundary=="partial-cursor"or item["chunk"]==len(item["chunks"])-1)
            if at_target and not armed:
                armed.append(target[0]);before=o.offsets[fd]
                count=write(fd,raw[:1]if boundary=="partial-cursor"else raw)
                trace.append(("actual-completion-return",target[0],count,before));d["clock"].value=2.5;return count
            return write(fd,raw)
        d["ns"]["os"].write=returned
    else:
        def actual_window(deadline):
            result=window(deadline);item=o.custody[0]if o.custody else None
            if target and item is not None and item["completion"]is not None and item["completion"]["completion_id"]==target[0]and item["chunk"]==len(item["chunks"])and not armed:
                armed.append(target[0]);trace.append(("complete-byte-commit",target[0]));d["clock"].value=2.5
            return result
        o.custody_window=actual_window
    with pytest.raises(d["ns"]["Refusal"]):o.settle_custody(2.5)
    assert not first["complete"]and not o.custody_completions
    if boundary=="capture":assert not target and trace==[("capture",first["fault_id"])]
    else:
        assert target and armed==[target[0]]
        assert any(row[0]in{"serialization-reserved","actual-completion-return","complete-byte-commit"}and row[1]==target[0]for row in trace)
        if boundary=="admission-rollback":assert("append",target[0])in trace and("rollback",target[0])in trace
        elif boundary=="partial-cursor":
            pending=next(item for item in o.custody if item["completion"]is not None and item["completion"]["completion_id"]==target[0])
            assert pending["deferred"]and(pending["chunk"]>0 or pending["cursor"]>0)
    raw=(o.root/"events.jsonl").read_bytes()
    if boundary in{"write-return","admission-rollback"}:
        committed=[json.loads(line)for line in raw.splitlines()]
        assert any(row["event"]=="fault_completion"and row["completion_id"]==target[0]for row in committed)
    o.deadline=None
    with pytest.raises(d["ns"]["Refusal"]):o.settle_custody(None)
    assert(o.root/"events.jsonl").read_bytes()==raw and not o.custody_completions



def _h71_observation_native_case(kind):
    if kind=="admitted":return _h65_watched_native_foreign_case()
    from types import SimpleNamespace
    def setup(driver,native):
        run=driver["ns"]["run"];query=driver["ns"]["subprocess"].run;event=driver["owner"].event;queries=[];hit=[]
        def watched(*args,**kwargs):kwargs["watch"]=True;return run(*args,**kwargs)
        def actual_query(*args,**kwargs):
            queries.append(True)
            if kind=="refused"and len(queries)==2:return SimpleNamespace(returncode=0,stdout=b"H71_MALFORMED_AFTER_LAUNCH\n",stderr=b"")
            return query(*args,**kwargs)
        def recorded(name,fields):
            result=event(name,fields)
            if kind=="candidate-refused"and name=="process_observation"and fields["phase"]!="preflight"and fields["complete"]and not hit:
                hit.append(fields["sequence"]);driver["clock"].value=fields["deadline"]
            return result
        driver["ns"]["run"]=watched;driver["ns"]["subprocess"].run=actual_query;driver["owner"].event=recorded
    return _r36_native_case("file-shared",earlier_error=True,payload=b"H71_LOGICAL_OBSERVATION\n",mutate=setup,
        expected_effects=(dict(kind="pid",target=1,signal=int(signal.SIGINT)),))


def _h71_clone_complete_native_ref(outcome,reference,suffix):
    # A different real private leaf keeps mode/identity/content/digest valid.
    # The intended false relation is exclusively final-attempt summary equality.
    owner=outcome["driver"]["owner"];raw=(owner.root/reference["file"]).read_bytes()
    path=owner.root/("h71-forged-summary-"+suffix);fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        offset=0
        while offset<len(raw):
            count=os.write(fd,raw[offset:]);assert count>0;offset+=count
    finally:os.close(fd)
    value=dict(reference);native=path.stat()
    value.update(file=path.name,identity=[native.st_dev,native.st_ino],bytes=len(raw),available_bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),closed=True,complete=True,missing_ranges=[],error=None)
    return value


@pytest.mark.parametrize("cohort",["admitted","refused","candidate-refused"])
@pytest.mark.parametrize("damage",["summary-returncode","summary-stdout","summary-stderr","phase-bool","phase-unsupported","phase-supported-wrong","utc-invalid","utc-reversed","utc-before-command","utc-after-command","launch-bool","launch-unsupported","logical-error","logical-errno"])
def test_h71_same_reader_binds_actual_observation_semantics_and_dispositions(cohort,damage):
    outcome=_h71_observation_native_case(cohort)
    def target(records):
        refused={item["sequence"]for row in records if row["event"]=="command_end"for item in row["observations_refused"]}
        return next(row for row in records if row["event"]=="process_observation"and
                    (row["complete"]and row["sequence"]not in refused if cohort=="admitted"else
                     not row["complete"]if cohort=="refused"else row["complete"]and row["sequence"]in refused))
    original=target(outcome["records"])
    if cohort=="candidate-refused":
        assert original["complete"]and not any(item["sequence"]==original["sequence"]for row in outcome["records"]if row["event"]=="command_end"for item in row["observations_admitted"])
    def edit(records):
        row=target(records);attempt=row["attempts"][-1]
        if damage=="summary-returncode":row["returncode"]=7 if attempt["returncode"]!=7 else 8
        elif damage=="summary-stdout":row["stdout_ref"]=_h71_clone_complete_native_ref(outcome,attempt["stdout_ref"],"stdout")
        elif damage=="summary-stderr":row["stderr_ref"]=_h71_clone_complete_native_ref(outcome,attempt["stderr_ref"],"stderr")
        elif damage=="phase-bool":row["phase"]=True
        elif damage=="phase-unsupported":row["phase"]="unowned-phase"
        elif damage=="phase-supported-wrong":row["phase"]="running"if row["phase"]=="preflight"else"preflight"
        elif damage=="utc-invalid":row["started_utc"]="invalid-UTC"
        elif damage=="utc-reversed":row["started_utc"]=(dt.datetime.fromisoformat(row["ended_utc"])+dt.timedelta(seconds=1)).isoformat()
        elif damage=="utc-before-command":
            begin=next(value for value in records if value["event"]=="command_begin"and value["command_id"]==row["command_id"])
            row["started_utc"]=(dt.datetime.fromisoformat(begin["started_utc"])-dt.timedelta(seconds=1)).isoformat()
        elif damage=="utc-after-command":
            end=next(value for value in records if value["event"]=="command_end"and value["command_id"]==row["command_id"])
            row["ended_utc"]=(dt.datetime.fromisoformat(end["ended_utc"])+dt.timedelta(seconds=1)).isoformat()
        elif damage=="launch-bool":attempt["launch_state"]=True
        elif damage=="launch-unsupported":attempt["launch_state"]="unproved-launch"
        elif damage=="logical-error":row["error"]="CONTRADICTORY_COMPLETE"if row["complete"]else None
        else:
            if row["complete"]:row["error_errno"]=18
            else:row["error_errno"]=18 if row["error_errno"]!=18 else 19
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("cohort",["admitted","refused","candidate-refused"])
def test_h71_actual_supported_observation_dispositions_keep_exact_admission_boundary(cohort):
    outcome=_h71_observation_native_case(cohort);records=outcome["records"]
    admitted={item["sequence"]for row in records if row["event"]=="command_end"for item in row["observations_admitted"]}
    refused={item["sequence"]for row in records if row["event"]=="command_end"for item in row["observations_refused"]}
    samples=[row for row in records if row["event"]=="process_observation"]
    assert admitted.isdisjoint(refused)and admitted|refused=={row["sequence"]for row in samples}
    if cohort=="admitted":assert any(row["complete"]and row["sequence"]in admitted for row in samples)
    elif cohort=="refused":assert any(not row["complete"]and row["sequence"]in refused for row in samples)
    else:assert any(row["complete"]and row["sequence"]in refused and row["sequence"]not in admitted for row in samples)
    assert outcome["result"].hook_context["transport_verification"]["exact_private_source"]is True



def test_h71_same_reader_keeps_post_journal_admission_inside_actual_command():
    outcome=_h65_watched_native_foreign_case()
    def edit(records):
        end=next(row for row in records if row["event"]=="command_end")
        admission=end["observations_admitted"][-1]
        assert end["ended_monotonic"]<admission["deadline"]
        admission["committed_monotonic"]=(end["ended_monotonic"]+admission["deadline"])/2
    damaged=_r36_rebind_corrupted_private_journal(outcome,edit)
    with pytest.raises(AssertionError):_events(damaged)
    assert damaged.hook_context["disposition"]=="protocol-incomplete"


@pytest.mark.parametrize("first", ["signal", "unknown"])
def test_h77_actual_parser_preserves_both_equal_clock_detection_orders(first):
    raw=_h4_raw(_h4_child(70,parent=0,state="?Es"),_h4_child(71,parent=0))
    d=_h4_inert([raw]);o=_h65_source_scope(d);require=d["ns"]["require"];seen=[];sent=[]
    def intercepted(condition,message):
        if message=="unsupported native STAT" and condition and not seen:
            seen.append(True);d["clock"].value=.25
            if first=="signal":d["ns"]["interrupted"](signal.SIGTERM,None);sent.append(True)
        elif message=="duplicate PID" and seen and not sent:
            d["ns"]["interrupted"](signal.SIGTERM,None);sent.append(True)
        return require(condition,message)
    d["ns"]["require"]=intercepted
    with pytest.raises(d["ns"]["Refusal"]):d["ns"]["process_rows"]()
    causes=[row for row in o.fault_records if row["operation"]in{"caught-signal","process-observation-parse"}]
    assert seen and sent and len(d["calls"])==1 and not d["effects"]
    assert len(causes)==2 and all(row["observed_monotonic"]==.25 for row in causes)
    assert [row["operation"]for row in causes]==(["caught-signal","process-observation-parse"]if first=="signal"else["process-observation-parse","caught-signal"])
    assert o.first_fault_id==causes[0]["fault_id"] and o.command_cleanup_deadline==15.25
    assert not o.process_admissions


def test_h77_direct_source_helper_enters_original_scope_without_bypassing_admission():
    d=_h4_inert([_h4_raw(_h4_child())]);o=d["owner"]
    assert o.command_id is None and o.phase=="startup" and not o.process_admissions
    rows=d["helper"]["observe"]()
    admission=o.process_admissions[-1]
    assert o.command_id==d["helper"]["command_id"]==admission["command_id"]==1
    assert admission["sequence"]==d["ns"]["PROCESS_OBSERVATION_SEQUENCE"]
    assert admission["attempt_id"]==o.native_attempt_sequence and admission["committed_monotonic"]<admission["deadline"]
    assert rows[10]["ppid"]==1 and not d["effects"]


def test_h77_serializer_failure_retains_only_original_prefix_without_replay():
    d=_h4_inert([_h4_raw()]);o=d["owner"]
    with pytest.raises(TypeError)as first:d["ns"]["actual_report"]("h77-bad",bad=object())
    prefix=(o.root/"events.jsonl").read_bytes()
    assert prefix.startswith(b'{"event":"h77-bad"') and not prefix.endswith(b"\n")
    assert o.custody and not o.custody[0]["serialization_complete"]
    cursor=(o.custody[0]["chunk"],o.custody[0]["cursor"])
    o.finish(first.value)
    assert(o.root/"events.jsonl").read_bytes()==prefix
    assert(o.custody[0]["chunk"],o.custody[0]["cursor"])==cursor
    assert not o.custody[0]["serialization_complete"] and o.closed and o.root_closed


@pytest.mark.parametrize("ready", [False,True])
def test_h77_actual_relay_requires_readiness_inside_original_window_before_syscall(ready):
    d=_h4_inert([_h4_raw()]);o=d["owner"];o.prepare_public();o.command_id=1;o.deadline=2
    queried=[];write=d["ns"]["os"].write;public=[]
    def observed_write(fd,raw):
        if fd in(1,2):public.append((fd,bytes(raw)))
        return write(fd,raw)
    def readiness(read,fds,error,timeout):
        queried.append((list(read),list(fds),list(error),timeout));d["clock"].value=2
        return [],list(fds)if ready else[],[]
    d["ns"]["os"].write=observed_write;d["ns"]["select"].select=readiness
    offsets=[0,0]
    with pytest.raises(d["ns"]["Refusal"]):o.relay(1,b"H77_ORIGINAL_BYTES\n",offsets,0,2)
    assert queried==[([],[1],[],2)] and not public and offsets==[0,0]
    row=o.public_writes[0]
    assert row["outcome"]=="not-admitted" and row["returned_count"]is None and row["written_source_bytes"]is None
    assert o.fault_records and o.command_cleanup_deadline is None


def test_h77_actual_native_preflight_refusal_has_no_fabricated_command_or_payload():
    from types import SimpleNamespace
    def setup(driver,native):
        run=driver["ns"]["run"]
        def watched(*args,**kwargs):kwargs["watch"]=True;return run(*args,**kwargs)
        driver["ns"]["run"]=watched
        driver["ns"]["subprocess"].run=lambda *args,**kwargs:SimpleNamespace(returncode=0,stdout=b"H77_MALFORMED_NATIVE\n",stderr=b"")
    outcome=_r36_native_case("file-shared",payload=b"H77_MUST_NOT_EXECUTE\n",mutate=setup,
        expected_launches=0,expected_capture="not-created")
    assert outcome["problem"]is not None and not outcome["driver"]["effects"]
    finish=next(row for row in outcome["records"]if row["event"]=="command_end")
    assert finish["launch_state"]=="not-attempted" and not finish["observations_admitted"]
    assert all(row["state"]=="not-created"for row in finish["channels"])
    assert any(not row["complete"]for row in outcome["records"]if row["event"]=="process_observation")
    assert outcome["result"].hook_context["transport_verification"]["exact_private_source"]is True


# H79 controls execute only under a later explicit ROOT runtime grant. The owned
# pipe provides independently received bytes; process/query boundaries stay inert.
def _h79_owned_command_sink(driver, logical_fd):
    import contextlib
    import fcntl
    import struct
    import termios
    from types import SimpleNamespace
    @contextlib.contextmanager
    def owned():
        api, fc, owner = driver["ns"]["os"], driver["ns"]["fcntl"], driver["owner"]
        read_fd, write_fd = os.pipe()
        original_flags = fcntl.fcntl(write_fd, fcntl.F_GETFL)
        originals = dict(write=api.write, fstat=api.fstat, fpathconf=api.fpathconf,
                         flags=fc.fcntl, ioctl=fc.ioctl)
        try:
            fcntl.ioctl(read_fd, termios.FIONBIO, struct.pack("i", 1))
            api.write = lambda fd, raw: os.write(write_fd, raw) if fd == logical_fd else originals["write"](fd, raw)
            api.fstat = lambda fd: os.fstat(write_fd) if fd == logical_fd else originals["fstat"](fd)
            api.fpathconf = lambda fd, name: os.fpathconf(write_fd, name) if fd == logical_fd else originals["fpathconf"](fd, name)
            fc.fcntl = lambda fd, operation, value=None: fcntl.fcntl(write_fd, operation) if fd == logical_fd else originals["flags"](fd, operation, value)
            fc.ioctl = lambda fd, request, value: fcntl.ioctl(write_fd, request, value) if fd == logical_fd else originals["ioctl"](fd, request, value)
            def received():
                pieces = []
                while True:
                    try:
                        raw = os.read(read_fd, 4096)
                    except BlockingIOError:
                        break
                    if not raw:
                        break
                    pieces.append(raw)
                return b"".join(pieces)
            yield SimpleNamespace(fd=write_fd, received=received, original_flags=original_flags,
                                  flags=lambda: fcntl.fcntl(write_fd, fcntl.F_GETFL), actual_write=api.write)
        finally:
            try:
                if not owner.root_closed:
                    owner.finish(owner.fault_objects[0] if owner.fault_objects else driver["ns"]["Refusal"]("H79 owned control aborted"))
            finally:
                api.write, api.fstat, api.fpathconf = originals["write"], originals["fstat"], originals["fpathconf"]
                fc.fcntl, fc.ioctl = originals["flags"], originals["ioctl"]
                try:
                    os.close(write_fd)
                finally:
                    os.close(read_fd)
    return owned()


@pytest.mark.parametrize("logical_fd", [1, 2])
@pytest.mark.parametrize("kind", ["raised", "none", "bool", "negative", "oversized"])
def test_h79_actual_command_prefix_unknown_fences_all_later_phase_syscalls(logical_fd, kind):
    import errno
    d = _h4_inert([_h4_raw()]); o = d["owner"]; payload = b"H79_EXACT_COMMAND_BYTES\n"
    with _h79_owned_command_sink(d, logical_fd) as sink:
        o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
        initial_wire = sink.received()
        o.command_id = 1; o.command_child_created = True; o.phase = "running"; o.deadline = 2
        d["clock"].value = .25
        reference = o.raw(payload, "h79-captured-command.bin", o.deadline)
        calls = []; prefix_error = OSError(errno.EIO, "H79_ACTUAL_COMMAND_PREFIX_THEN_RAISE")
        def prefix_then_unknown(fd, raw):
            if fd != logical_fd or o.command_id != 1:
                return sink.actual_write(fd, raw)
            calls.append((o.phase, fd, bytes(raw), o.deadline))
            assert os.write(sink.fd, raw[:2]) == 2
            if kind == "raised":
                raise prefix_error
            return {"none": None, "bool": True, "negative": -1, "oversized": len(raw) + 1}[kind]
        d["ns"]["os"].write = prefix_then_unknown
        offsets = [0, 0]
        with pytest.raises((OSError, d["ns"]["Refusal"])) as first:
            o.relay(logical_fd, payload, offsets, logical_fd - 1, 2)
        assert len(calls) == 1 and calls[0] == ("running", logical_fd, payload, 2)
        row = o.public_writes[0]
        assert row["command_id"] == 1 and row["channel"] == logical_fd - 1
        assert row["source_start"] == row["source_offset_before"] == 0
        assert row["source_end"] == row["intended_bytes"] == len(payload)
        assert row["source_sha256"] == hashlib.sha256(payload).hexdigest()
        assert row["returned_count"] is row["written_source_bytes"] is row["source_offset_after"] is None
        assert o.public_offsets[logical_fd] is None and offsets == [0, 0]
        assert o.command_write_unknown[(1, logical_fd, logical_fd - 1)] is first.value
        assert o.fault_objects[0] is first.value and o.fault_records[0]["observed_monotonic"] == .25
        assert o.command_cleanup_deadline == 15.25
        if kind == "raised":
            assert first.value is prefix_error and row["outcome"] == "syscall-raised"
        else:
            assert row["outcome"] == "syscall-returned"
        observations = len(o.public_observations)
        for phase, now, deadline in (("cli-grace", .5, 15.25), ("cli-grace", 1, 15.25),
                                     ("final-drain", 15.25, 17.25), ("final-observation", 17.25, 19.25)):
            o.phase = phase; o.deadline = deadline; d["clock"].value = now
            with pytest.raises((OSError, d["ns"]["Refusal"])) as later:
                o.relay(logical_fd, payload + b"LATER_CAPTURE", offsets, logical_fd - 1, deadline)
            # This is the decisive real-producer retry oracle, before secondary
            # object/schema checks: a sole fence-removal seed must fail here.
            assert len(calls) == 1, "UNKNOWN command channel issued a second payload syscall"
            assert later.value is first.value and offsets == [0, 0]
            assert len(o.public_writes) == 1 and len(o.public_observations) == observations
            assert o.command_cleanup_deadline == 15.25 and o.public_offsets[logical_fd] is None
        assert sink.received() == payload[:2]
        assert (o.root / reference["file"]).read_bytes() == payload and reference["complete"]
        other_fd = 3 - logical_fd; other = b"H79_OTHER_CHANNEL_TAIL\n"
        o.relay(other_fd, other, offsets, other_fd - 1, o.deadline)
        assert d["buffers"][other_fd - 1].getvalue().endswith(other)
        assert offsets[logical_fd - 1] == 0 and offsets[other_fd - 1] == len(other)
        o.command_id = None
        assert o.finish(first.value) is first.value
        assert o.closed and o.root_closed and len(o.control_writes) == 2
        assert o.control_writes[-1]["state"] == "terminal" and o.control_writes[-1]["outcome"] == "syscall-returned"
        assert o.public_offsets[logical_fd] is None and o.fault_objects[0] is first.value
        assert sink.flags() & (o.protected_controls | os.O_NONBLOCK) == sink.original_flags & (o.protected_controls | os.O_NONBLOCK)
        assert not d["effects"] and not any(item[0] == "Popen" for item in d["ordering"])
        assert initial_wire.startswith(b"NOTEBOOK_HOOK ") if logical_fd == 1 else initial_wire == b""


@pytest.mark.parametrize("logical_fd", [1, 2])
@pytest.mark.parametrize("kind", ["raised", "none", "bool", "negative", "oversized"])
def test_h79_actual_run_unknown_channel_preserves_other_tail_cleanup_and_deadlines(logical_fd, kind):
    import errno
    holder = {}; original = OSError(errno.EIO, "H79_ORIGINAL_CLI_FAILURE")
    original.output, original.stderr = b"FIRST_OUT", b"FIRST_ERROR"
    def command(child, timeout):
        d = holder["driver"]
        if child.returncode is None:
            d["clock"].value += min(.25, timeout)
            raise original
        return b"FIRST_OUT_TAIL", b"FIRST_ERROR_TAIL"
    def table():
        d = holder["driver"]
        killed = any(item["target"] == 10 and item["signal"] == 9 for item in d["effects"])
        return _h4_raw(*([] if killed else [_h4_child()]))
    d = _h4_inert([table], command=command); holder["driver"] = d; o = d["owner"]
    with _h79_owned_command_sink(d, logical_fd) as sink:
        o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest()); sink.received()
        writes, relays = [], []; actual_relay = o.relay
        def observed_relay(fd, data, offsets, index, deadline):
            relays.append((o.phase, fd, deadline))
            return actual_relay(fd, data, offsets, index, deadline)
        o.relay = observed_relay
        def prefix_then_unknown(fd, raw):
            if fd != logical_fd or o.command_id is None:
                return sink.actual_write(fd, raw)
            writes.append((o.command_id, o.phase, bytes(raw), o.deadline))
            assert os.write(sink.fd, raw[:2]) == 2
            if kind == "raised":
                raise OSError(errno.EIO, "H79_ACTUAL_LATER_COMMAND_WRITE_FAILURE")
            return {"none": None, "bool": True, "negative": -1, "oversized": len(raw) + 1}[kind]
        d["ns"]["os"].write = prefix_then_unknown
        with pytest.raises(OSError) as caught:
            d["ns"]["run"](["INERT_CLI"], "/INERT", {}, timeout=60, watch=True)
        assert caught.value is original and o.fault_objects[0] is original
        assert len(writes) == 1, "UNKNOWN command channel issued a second payload syscall"
        expected = b"FIRST_OUT" if logical_fd == 1 else b"FIRST_ERROR"
        assert writes[0] == (1, "cli-grace", expected, 15.25)
        assert sink.received() == expected[:2]
        assert o.public_offsets[logical_fd] is None
        assert o.fault_records[0]["observed_monotonic"] == .25 and o.command_cleanup_deadline == 15.25
        target_relays = [row for row in relays if row[1] == logical_fd]
        assert {row[0] for row in target_relays} >= {"cli-grace", "final-drain", "final-observation"}
        assert all(row[2] == 15.25 for row in target_relays if row[0] == "cli-grace")
        assert any(item["target"] == 1 and item["signal"] == 9 for item in d["effects"])
        assert any(item["target"] == 10 and item["signal"] == 15 for item in d["effects"])
        assert any(item["target"] == 10 and item["signal"] == 9 for item in d["effects"])
        assert not any(item["kind"] == "group" for item in d["effects"])
        assert d["clock"].value <= 22.5
        other_fd = 3 - logical_fd
        assert d["buffers"][other_fd - 1].getvalue().endswith(b"FIRST_ERROR_TAIL" if other_fd == 2 else b"FIRST_OUT_TAIL")
        end = next(row for row in d["events"] if row["event"] == "command_end")
        assert end["channels"][logical_fd - 1]["bytes"] == len(b"FIRST_OUT_TAIL" if logical_fd == 1 else b"FIRST_ERROR_TAIL")
        assert end["channels"][logical_fd - 1]["delivered_bytes"] == 0
        assert end["channels"][logical_fd - 1]["missing_delivery_ranges"] == [[0, end["channels"][logical_fd - 1]["bytes"]]]
        assert o.finish(caught.value) is original and o.closed and o.root_closed
        assert sink.flags() & (o.protected_controls | os.O_NONBLOCK) == sink.original_flags & (o.protected_controls | os.O_NONBLOCK)
        assert len([item for item in d["ordering"] if item[0] == "Popen"]) == 1


@pytest.mark.parametrize("kind", ["short", "zero"])
def test_h79_actual_known_count_keeps_only_unaccepted_suffix_eligible(kind):
    d = _h4_inert([_h4_raw()]); o = d["owner"]; payload = b"H79_KNOWN_COUNT_SUFFIX\n"
    with _h79_owned_command_sink(d, 1) as sink:
        o.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest()); sink.received()
        o.command_id = 1; o.command_child_created = True; o.phase = "running"; o.deadline = 2
        calls = []
        def actual_known_count(fd, raw):
            if fd != 1 or o.command_id != 1:
                return sink.actual_write(fd, raw)
            calls.append(bytes(raw))
            if len(calls) == 1:
                n = os.write(sink.fd, raw[:2] if kind == "short" else b"")
                d["clock"].value = 2  # Original window expires AFTER its exact count.
                return n
            return os.write(sink.fd, raw)
        d["ns"]["os"].write = actual_known_count; offsets = [0, 0]
        with pytest.raises(d["ns"]["Refusal"]) as first:
            o.relay(1, payload, offsets, 0, 2)
        known = 2 if kind == "short" else 0
        assert offsets == [known, 0] and o.public_offsets[1] == len(o.control_writes[0]["raw"]) + known
        row = o.public_writes[0]
        assert row["returned_count"] == row["written_source_bytes"] == known
        assert row["source_offset_after"] == known and not o.command_write_unknown
        assert sink.received() == payload[:known]
        o.phase = "final-drain"; o.deadline = 4
        o.relay(1, payload, offsets, 0, 4)
        assert calls == [payload, payload[known:]] and offsets == [len(payload), 0]
        assert sink.received() == payload[known:]
        assert o.public_writes[1]["source_start"] == known
        assert not o.command_write_unknown and o.fault_objects[0] is first.value
        o.command_id = None
        assert o.finish(first.value) is first.value and len(o.control_writes) == 2
        assert o.control_writes[-1]["outcome"] == "syscall-returned" and o.public_offsets[1] is not None
        assert sink.flags() & (o.protected_controls | os.O_NONBLOCK) == sink.original_flags & (o.protected_controls | os.O_NONBLOCK)


@pytest.mark.parametrize("damage",["arguments-int","arguments-list","os-missing","os-extra","os-wrong-set","obligation-cleared"])
def test_h84_exact_expiry_native_capture_keeps_no_late_int_and_full_obligations(damage):
    outcome=_h71_os_completion_native_case("expiry")
    driver=outcome["driver"];owner=driver["owner"]
    assert owner.fault_objects[0].args==("H71_ORIGINAL_FIRST_CAUSE",)
    assert owner.fault_records[0]["observed_monotonic"]==0 and owner.command_cleanup_deadline==15
    assert driver["effects"]==[dict(kind="pid",target=1,signal=int(signal.SIGKILL))]
    _h84_check_native_capture_obligations(outcome,"within",damage)


@pytest.mark.parametrize("cleanup_fault",[False,True])
def test_h84_failed_tail_assertion_closes_actual_owner_and_preserves_errors(cleanup_fault):
    d=_h4_inert([_h4_raw()]);owner=d["owner"];api=d["ns"]["os"];ready=d["ns"]["select"]
    owner.prepare(hashlib.sha256(HOOK.read_bytes()).hexdigest())
    assert owner.flags and owner.entry_sha256
    write,select=api.write,ready.select
    original=d["ns"]["Refusal"]("H84_ORIGINAL_COMMAND_FAILURE")
    owner.fault("h84-original",original)
    assertion=AssertionError("H84_ACTUAL_ASSERTION_FAILURE");later=OSError("H84_CLEANUP_QUERY_FAILURE")
    with pytest.raises(AssertionError)as raised:
        with _h84_tail_owner_cleanup(d)as closed:
            closed["failure"]=original
            api.write=lambda fd,raw:write(fd,raw)
            ready.select=lambda *args:select(*args)
            if cleanup_fault:
                validate=owner.public_validate
                def fail_verify(fd,*args,**kwargs):
                    if owner.phase=="public-flags-verify:1":raise later
                    return validate(fd,*args,**kwargs)
                owner.public_validate=fail_verify
            raise assertion
    assert raised.value is assertion and closed["result"]is original
    assert closed["finish_calls"]==1 and owner.closed and owner.root_closed
    assert api.write is write and ready.select is select
    assert owner.fault_objects[0]is original and assertion in owner.fault_objects
    assert (later in owner.fault_objects)==cleanup_fault
    raw=(owner.root/"events.jsonl").read_bytes()
    records=[json.loads(line)for line in raw.splitlines()]
    assert any(row["event"]=="fault"and row["operation"]=="h84-fixture-assertion"for row in records)
    for fd in(owner.events,owner.root_fd):
        with pytest.raises(OSError):os.fstat(fd)


def test_h84_observer_chronology_sequences_are_invocation_local():
    first=[]
    for _ in range(2):
        observer,_,killed,_=_source_observer([OSError("H84_LOCAL_CHRONOLOGY")])
        assert observer["cleanup_observe"]()is None and not killed
        owner=observer["fault_owner"]
        assert owner.faults and not owner.faults[0]["persisted"]
        first.append(observer["observe"].__globals__["cause_order"]())
    assert first==[2,2]


@pytest.mark.parametrize("route",["pipe","socket","pty-normal-shared"])
def test_h84_actual_receiver_pieces_and_once_only_original_time_charge(route):
    outcome=_r36_native_case(route,earlier_error=True)
    driver=outcome["driver"];trace=driver["h84_native_receive_trace"];boundaries=driver["h84_native_boundaries"]
    assert trace and boundaries
    for row in boundaries:
        assert row["charged"]==row["host_ended"]-row["host_started"]>=0
        assert row["fixture_after"]-row["fixture_before"]==pytest.approx(row["charged"],abs=1e-12)
        if row["select_attempted"]:
            assert 0<row["remaining_after_receive"]<=row["original_timeout"]
            assert row["actual_select_return"][1]==[row["native_fd"]]
    groups=outcome["result"].hook_context["transport"]["groups"]
    for group,value in groups.items():
        actual=[bytes.fromhex(row["raw_hex"])for row in trace if row["group"]==group and row["outcome"]=="returned"]
        assert b"".join(actual)==value["wire"]
    assert any(row["phase"]=="during"and row.get("count",0)>0 for row in trace)


def _h94_test_observe(monkeypatch):
    captures=[];receipts=[];original=_H94FixtureCapture.__init__
    def observed(self,label):
        original(self,label);captures.append(self)
    monkeypatch.setattr(_H94FixtureCapture,"__init__",observed)
    monkeypatch.setitem(globals(),"_h94_emit",receipts.append)
    original_undo=monkeypatch.undo
    def undo_with_held_observations():
        pending=None
        def retain_observer_failure(operation,error):
            nonlocal pending
            row=dict(operation=operation,object=error,traceback=error.__traceback__,
                     observed=time.monotonic(),arguments=BaseException.args.__get__(error))
            for capture in captures:capture.observer_faults.append(row)
            if pending is None:
                originals=[capture.first for capture in captures if capture.first is not None]
                pending=min(originals,key=lambda first:first["observed"]) if originals else row
        # Independent test-observer output AFTER the test, not a retry of a failed
        # production/fixture emitter and never an endpoint/process reobservation.
        try:
            for capture in captures:
                faults=[dict(object_id=id(row["object"]),operation=row["operation"],
                    observed=row["observed"],arguments=_h94_freeze_value(row["arguments"]),
                    traceback=[dict(function=tb.tb_frame.f_code.co_name,line=tb.tb_lineno,
                        filename=tb.tb_frame.f_code.co_filename) for tb in capture._trace(row["traceback"])])
                    for row in capture.faults]
                print("H94_TEST_HELD_OBSERVATION "+json.dumps(dict(label=capture.label,
                    precleanup=capture.precleanup,receipt=capture.receipt,
                    fixture_faults=faults,first_object_id=id(capture.first["object"]) if capture.first else None,
                    callbacks=[dict(state=row["state"],calls=row["calls"],args=_h94_freeze_value(row["args"])) for row in capture.callbacks],
                    outer_exited=capture.outer_exited,stack_empty=capture.stack_empty_after_close,
                    receipt_retained=capture.receipt_retained,optional_snapshot=capture.optional_snapshot),
                    separators=(",",":")),flush=True)
        except BaseException as error:retain_observer_failure("test-observer-export",error)
        finally:
            try:original_undo()
            except BaseException as error:retain_observer_failure("original-monkeypatch-undo",error)
        if pending is not None:
            raise pending["object"].with_traceback(pending["traceback"])
    monkeypatch.setattr(monkeypatch,"undo",undo_with_held_observations)
    return captures,receipts


def _h94_test_unfreeze(value):
    if value["state"]=="unobserved":return _H94_UNOBSERVED
    kind=value["type"]
    if kind=="bytes":return base64.b64decode(value["base64"])
    if kind=="dict":return {_h94_test_unfreeze(k):_h94_test_unfreeze(v) for k,v in value["items"]}
    if kind in ("list","tuple"):
        items=[_h94_test_unfreeze(x) for x in value["items"]]
        return tuple(items) if kind=="tuple" else items
    return value["value"]


def _h94_test_closed(capture):
    import errno
    fds=[row["args"][0] for row in capture.callbacks if row["function"] is os.close]
    assert fds
    for fd in fds:
        with pytest.raises(OSError) as closed:os.fstat(fd)
        assert closed.value.errno==errno.EBADF
    assert all(row["calls"]==1 and row["state"]=="finished" for row in capture.callbacks)
    assert capture.outer_exited and capture.stack_empty_after_close


@pytest.mark.parametrize("route,policy",[("socket-shared","cooperative"),("socket-shared","undrained"),("pty-normal-shared","undrained")])
def test_h94_actual_pressure_return_and_receiver_premise_outside_error_credit(monkeypatch,route,policy):
    captures,receipts=_h94_test_observe(monkeypatch);outcome=None;escaped=None
    try:
        outcome=_r36_native_case(route,initial=False,earlier_error=True,
            payload=b"PRESSURE\r\n"*(1<<17),receiver_policy=policy)
    except BaseException as error:escaped=error
    assert len(captures)==len(receipts)==1
    capture=captures[0]
    assert capture.precleanup is not None,"actual precleanup observation receipt missing"
    facts=_h94_test_unfreeze(capture.precleanup)
    during=[row for row in facts["read_attempts"] if row["phase"]=="during"]
    actual_read_bytes=sum(row.get("count",0) for row in during if row["outcome"]=="returned")
    assert capture.outer_exited and capture.stack_empty_after_close
    if policy=="undrained":
        # Direct intended premise precedes and is independent of generic refusal credit.
        assert during==[] and actual_read_bytes==0,"undrained receiver performed during-owner reads"
        assert isinstance(escaped,AssertionError) and re.search("protocol|syscall-raised|incomplete",str(escaped))
        assert outcome is None
    else:
        assert during and actual_read_bytes>0,"cooperative pressure receiver did not read actual during-owner bytes"
        assert escaped is None,"healthy transport must RETURN original handled result2, never throw"
        assert outcome is not None and outcome["result"].returncode==2
        owner=outcome["driver"]["owner"];first=owner.fault_objects[0]
        assert outcome["problem"] is first
        assert first.args==("command failed once (not rerun): ['INERT_CLI'] rc=7",)
        assert capture.first is None and capture.receipt_retained
        assert outcome["result"].hook_context["transport_verification"]["exact_private_source"]
        assert outcome["result"].hook_context["verification"]["actual_flags_independently_observed"]
        assert capture.finishes[0]["label"]=="initial-inert" and capture.finishes[1]["label"]=="actual-post-run"
        assert all(x["state"]=="returned" for x in capture.finishes)
        assert capture.producer[0]["object_ids"][0]==id(first)
        assert _h94_test_unfreeze(capture.producer[0]["cleanup_deadline"])==owner.command_cleanup_deadline
        assert all(row["charged"]==pytest.approx(row["host_ended"]-row["host_started"]) for row in facts["readiness"])


@pytest.mark.parametrize("earlier_error",[False,True])
@pytest.mark.parametrize("where",["capture","emitter","callback"])
def test_h94_actual_handled_producer_never_hides_new_fixture_fault(monkeypatch,earlier_error,where):
    captures,receipts=_h94_test_observe(monkeypatch)
    actual=OSError(5,"H94_REAL_"+where);drivers=[];native_fds=[]
    def observe(driver,native):drivers.append(driver);native_fds.extend(native.values())
    if where=="capture":
        def fail(self,facts):raise actual
        monkeypatch.setattr(_H94FixtureCapture,"freeze",fail)
    elif where=="emitter":
        def fail(receipt):raise actual
        monkeypatch.setitem(globals(),"_h94_emit",fail)
    else:
        register=_H94FixtureCapture.register;installed=[]
        def register_real(self,stack,actions):
            if not installed:
                fn,args=actions[0]
                def close_then_fail(*values):fn(*values);raise actual
                actions=[(close_then_fail,args)]+actions[1:];installed.append(True)
            return register(self,stack,actions)
        monkeypatch.setattr(_H94FixtureCapture,"register",register_real)
    with pytest.raises(OSError) as caught:
        _r36_native_case("pipe-shared",earlier_error=earlier_error,mutate=observe)
    capture=captures[0]
    assert caught.value is actual and capture.first["object"] is actual
    assert capture.first["traceback"] is not None and capture.first["observed"]<=time.monotonic()
    assert capture.outer_exited and capture.stack_empty_after_close
    assert all(row["calls"]==1 for row in capture.callbacks)
    for fd in native_fds:
        with pytest.raises(OSError):os.fstat(fd)
    owner=drivers[0]["owner"]
    if earlier_error:
        assert owner.fault_objects[0].args==("command failed once (not rerun): ['INERT_CLI'] rc=7",)
        assert capture.producer[0]["object_ids"][0]==id(owner.fault_objects[0])
        assert _h94_test_unfreeze(capture.producer[0]["cleanup_deadline"])==owner.command_cleanup_deadline
    else:assert owner.fault_objects==[]
    assert capture.receipt_retained is (where!="emitter")
    assert [row["label"] for row in capture.finishes]==["initial-inert","actual-post-run"]
    assert all(row["state"]=="returned" for row in capture.finishes)


@pytest.mark.parametrize("body",["inspect","prepare","reader"])
def test_h94_actual_primary_survives_two_original_callback_faults_and_outer_exit(monkeypatch,body):
    captures,receipts=_h94_test_observe(monkeypatch)
    first=AssertionError("H94_ORIGINAL_ESCAPING_"+body)
    later=[OSError(5,"H94_CALLBACK_0"),OSError(5,"H94_CALLBACK_1")]
    register=_H94FixtureCapture.register;installed=[];closed=[];drivers=[]
    def registered(self,stack,actions):
        replaced=[]
        for fn,args in actions:
            if len(installed)<2 and fn is os.close:
                actual=later[len(installed)];installed.append(actual)
                def close_then_raise(*values,fn=fn,actual=actual):
                    fn(*values);closed.append(values[0]);raise actual
                replaced.append((close_then_raise,args))
            else:replaced.append((fn,args))
        return register(self,stack,replaced)
    monkeypatch.setattr(_H94FixtureCapture,"register",registered)
    def mutate(driver,native):
        drivers.append(driver)
        if body=="prepare":
            def fail(*args):raise first
            driver["owner"].prepare=fail
    def inspect(driver,result):
        if body=="inspect":raise first
    if body=="reader":
        def fail(*args,**kwargs):raise first
        monkeypatch.setitem(globals(),"_events",fail)
    with pytest.raises(AssertionError) as caught:
        _r36_native_case("pipe-shared",earlier_error=True,mutate=mutate,inspect=inspect)
    capture=captures[0]
    assert caught.value is first and capture.first["object"] is first
    assert capture.first["traceback"] is not None
    assert capture.outer_exited and capture.stack_empty_after_close
    assert [x["object"] for x in capture.faults if x["object"] in later]==list(reversed(later))
    assert len(closed)==2 and len(capture.callbacks)>=3
    assert all(row["calls"]==1 for row in capture.callbacks)
    for row in capture.callbacks:
        if row["args"] and type(row["args"][0]) is int:
            with pytest.raises(OSError):os.fstat(row["args"][0])
    assert receipts[0]["outer_exited"] and len(receipts[0]["faults"])>=3
    assert capture.precleanup is not None
    expected="actual-prepare-failure" if body=="prepare" else "actual-post-run"
    assert [row["label"] for row in capture.finishes]==["initial-inert",expected]


@pytest.mark.parametrize("mode",["initial-raise","initial-return-problem","prepare-raise","finish-raise","finish-return-problem"])
def test_h94_actual_distinct_owner_finish_return_raise_and_at_most_once(monkeypatch,mode):
    captures,receipts=_h94_test_observe(monkeypatch);actual=OSError(5,"H94_FINISH_"+mode);calls=[]
    inert=_h4_inert;drivers=[]
    def actual_driver(*args,**kwargs):
        d=inert(*args,**kwargs);drivers.append(d)
        if mode.startswith("initial"):
            finish=d["owner"].finish
            def initial(value):
                calls.append("initial");returned=finish(value)
                if mode=="initial-raise":raise actual
                return actual
            d["owner"].finish=initial
        return d
    monkeypatch.setitem(globals(),"_h4_inert",actual_driver)
    def mutate(d,native):
        if mode=="prepare-raise":
            def prepare(*args):raise actual
            d["owner"].prepare=prepare
        finish=d["owner"].finish
        def actual_finish(value):
            calls.append("actual");returned=finish(value)
            if mode=="finish-raise":raise actual
            return returned
        d["owner"].finish=actual_finish
    outcome=None;escaped=None
    try:outcome=_r36_native_case("pipe-shared",earlier_error=mode=="finish-return-problem",mutate=mutate)
    except BaseException as error:escaped=error
    capture=captures[0]
    if mode in {"initial-raise","prepare-raise","finish-raise"}:
        assert escaped is actual and capture.first["object"] is actual
        assert outcome is None
    else:
        assert escaped is None and outcome is not None
        assert outcome["result"].returncode==(2 if mode=="finish-return-problem" else 0)
        assert capture.first is None
    assert len({row["owner_id"] for row in capture.finishes})==len(capture.finishes)
    assert all(row["state"] in {"returned","raised"} for row in capture.finishes)
    if mode=="initial-raise":assert len(capture.finishes)==1 and calls==["initial"]
    else:
        assert len(capture.finishes)==2 and capture.outer_exited and capture.stack_empty_after_close
        assert calls.count("actual")==1
        assert capture.finishes[0]["returned"] is actual if mode=="initial-return-problem" else capture.finishes[0]["returned"] is None


@pytest.mark.parametrize("failure_index",[0,1])
@pytest.mark.parametrize("after_append",[False,True])
def test_h94_actual_pair_partial_registration_closes_both_capabilities_once(monkeypatch,failure_index,after_append):
    import contextlib
    captures,receipts=_h94_test_observe(monkeypatch);actual=OSError(5,"H94_REGISTER")
    callback=contextlib.ExitStack.callback;calls=[];acquired=[];pipe=os.pipe
    def observe_pipe():
        pair=pipe();acquired.extend(pair);return pair
    def fail_registration(self,*args,**kwargs):
        calls.append(args)
        if len(calls)-1==failure_index:
            if after_append:callback(self,*args,**kwargs)
            raise actual
        return callback(self,*args,**kwargs)
    monkeypatch.setattr(os,"pipe",observe_pipe)
    monkeypatch.setattr(contextlib.ExitStack,"callback",fail_registration)
    with pytest.raises(OSError) as caught:_r36_native_case("pipe-shared")
    capture=captures[0]
    assert caught.value is actual and capture.first["object"] is actual
    assert len(acquired)==2 and all(row["calls"]==1 for row in capture.callbacks)
    for fd in acquired:
        with pytest.raises(OSError):os.fstat(fd)
    assert capture.outer_exited and capture.stack_empty_after_close
    assert len(capture.finishes)==2 and capture.finishes[1]["label"]=="actual-prepare-failure"
    assert capture.finishes[1]["state"]=="returned"


@pytest.mark.parametrize("state",["no-writer","no-deadline","exhausted","already-final","once","query-error","overrun"])
def test_h94_actual_owned_snapshot_original_deadline_zero_or_one_no_retry(monkeypatch,state):
    import contextlib
    captures,receipts=_h94_test_observe(monkeypatch)
    capture=_H94FixtureCapture("owned-snapshot-control");calls=[];actual=OSError(5,"H94_SNAPSHOT")
    with contextlib.ExitStack() as resources:
        read,writer=os.pipe();resources.callback(os.close,read);resources.callback(os.close,writer)
        implementation=_r36_native_snapshot
        def observe(fd):
            calls.append(fd)
            if state=="query-error":raise actual
            value=implementation(fd)
            if state=="overrun":time.sleep(.02)
            return value
        monkeypatch.setitem(globals(),"_r36_native_snapshot",observe)
        deadline=None if state=="no-deadline" else time.monotonic()+(-1 if state=="exhausted" else .005 if state=="overrun" else 10)
        existing={} if state=="already-final" else _H94_UNOBSERVED
        _h94_owned_writer_snapshot(capture,writer,deadline,existing,state!="no-writer")
    row=capture.optional_snapshot
    expected=state in {"once","query-error","overrun"}
    assert row["attempted"] is expected and len(calls)==(1 if expected else 0)
    assert row["overrun"] is (state=="overrun")
    if state=="query-error":assert capture.first["object"] is actual and row["error_id"]==id(actual)
    elif state=="once":assert row["remaining_after"]<row["remaining_before"] and row["value"] is not None
    else:assert capture.first is None


def test_h94_observed_native_null_empty_eof_and_timeout_fields_remain_distinct():
    raw=dict(unseen=_H94_UNOBSERVED,empty=b"",native_none=None,
             timeout_stdout=None,timeout_stderr=b"",pieces=[b"A\0",b"\xff\r\n"],eof=b"")
    capture=_H94FixtureCapture("raw-state-control");capture.freeze(raw)
    frozen=capture.precleanup;restored=_h94_test_unfreeze(frozen)
    assert restored==raw
    assert _h94_freeze_value(_H94_UNOBSERVED)!=_h94_freeze_value(None)!=_h94_freeze_value(b"")
    assert restored["pieces"]==[b"A\0",b"\xff\r\n"] and b"".join(restored["pieces"])==b"A\0\xff\r\n"


@pytest.mark.parametrize("owner",["_r36_native_case","_observe_real_hook_child","test_r36_real_hook_native_sink_science_once_and_same_reader"])
def test_h94_actual_owner_source_binds_full_acquisition_capture_cleanup_and_outer_exit(owner):
    import ast
    source=Path(__file__).read_text();tree=ast.parse(source)
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==owner)
    text=ast.get_source_segment(source,node)
    observer=ast.get_source_segment(source,next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="_h94_test_observe"))
    assert 'retain_observer_failure("test-observer-export",error)' in observer
    assert 'originals=[capture.first for capture in captures if capture.first is not None]' in observer
    assert 'raise pending["object"].with_traceback(pending["traceback"])' in observer
    assert observer.index("try:original_undo()")<observer.index('raise pending["object"]')
    assert text.index("capture=_H94FixtureCapture(")<text.index("    try:")
    assert "capture.freeze(" in text and "capture.emit()" in text and "capture.propagate()" in text
    assert text.index("capture.freeze(")<text.index("capture.emit()")<text.index("capture.propagate()")
    assert "stored_returncode=" in text and "child.returncode" in text if owner!="_r36_native_case" else "result.returncode" in text
    if owner!="_observe_real_hook_child":
        assert "capture.register(resources," in text
        assert "capture.close_stack(resources)" in text
        assert text.index("capture.freeze(")<text.index("capture.close_stack(resources)")
        assert text.index("capture.close_stack(resources)")<text.index("capture.outer_exited=True")<text.index("capture.emit()")
        assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=="resources" and n.func.attr=="callback" for n in ast.walk(node))
    else:
        assert 'capture.attempt("original-child-kill",child.kill)' in text
        assert 'capture.attempt("original-child-wait",child.wait,timeout=5)' in text
        assert 'capture.attempt("original-known-witness",_stop_fixture,identity,repo)' in text
        assert 'communication.update(outcome="TimeoutExpired",stdout=error.output,stderr=error.stderr)' in text
    if owner=="test_r36_real_hook_native_sink_science_once_and_same_reader":
        assert text.count("_h94_owned_writer_snapshot,")==1 and "tick+300" in text
        assert "timeout=2" in text and "remove_owned_fifo" in text and "fifo_root.rmdir" in text
    if owner=="_r36_native_case":
        assert "_h94_owned_writer_snapshot" not in text
        assert 'receiver_policy=="cooperative"' in text
        assert 'capture.finish(d["owner"],None,"initial-inert")' in text
        assert 'capture.finish(owner,problem,"actual-post-run")' in text
        assert 'capture.finish,owner,error,"actual-prepare-failure"' in text


def test_h94_actual_escaping_body_capture_emitter_and_two_cleanup_faults_keep_complete_order(monkeypatch):
    captures,receipts=_h94_test_observe(monkeypatch)
    original=AssertionError("H94_FIRST_ASSERTION")
    capture_error=OSError(5,"H94_CAPTURE_AFTER_FIRST")
    callback_errors=[OSError(5,"H94_CLOSE_FIRST"),OSError(5,"H94_CLOSE_SECOND")]
    emit_error=OSError(5,"H94_EMIT_AFTER_CLEANUP")
    register=_H94FixtureCapture.register;freeze=_H94FixtureCapture.freeze;selected=[];drivers=[]
    def wrapped(self,stack,actions):
        replaced=[]
        for function,args in actions:
            if function is os.close and len(selected)<2:
                error=callback_errors[len(selected)];selected.append(error)
                def real_close_then_fault(*values,function=function,error=error):function(*values);raise error
                replaced.append((real_close_then_fault,args))
            else:replaced.append((function,args))
        return register(self,stack,replaced)
    def frozen_then_fault(self,facts):
        # Actual bytes are frozen while original endpoints still exist.
        for row in self.callbacks:
            if row["args"] and type(row["args"][0]) is int:os.fstat(row["args"][0])
        freeze(self,facts);raise capture_error
    def emitted_after_cleanup(receipt):
        assert receipt["outer_exited"] and all(row["calls"]==1 for row in receipt["callbacks"])
        raise emit_error
    def observe(driver,native):drivers.append(driver)
    def inspect(driver,result):raise original
    monkeypatch.setattr(_H94FixtureCapture,"register",wrapped)
    monkeypatch.setattr(_H94FixtureCapture,"freeze",frozen_then_fault)
    monkeypatch.setitem(globals(),"_h94_emit",emitted_after_cleanup)
    with pytest.raises(AssertionError) as caught:
        _r36_native_case("pipe-shared",earlier_error=True,mutate=observe,inspect=inspect)
    capture=captures[0]
    assert caught.value is original and capture.first["object"] is original
    assert [row["object"] for row in capture.faults]==[original,capture_error,*reversed(callback_errors),emit_error]
    assert all(a["observed"]<=b["observed"] for a,b in zip(capture.faults,capture.faults[1:]))
    assert capture.outer_exited and capture.stack_empty_after_close and not capture.receipt_retained
    assert capture.precleanup is not None
    facts=_h94_test_unfreeze(capture.precleanup)
    assert facts["actual_received_pieces"] is not _H94_UNOBSERVED
    assert b"".join(facts["actual_received_pieces"]["first"])
    assert drivers[0]["owner"].fault_objects[0].args==("command failed once (not rerun): ['INERT_CLI'] rc=7",)
    for row in capture.callbacks:
        if row["args"] and type(row["args"][0]) is int:
            with pytest.raises(OSError):os.fstat(row["args"][0])


@pytest.mark.parametrize("snapshot_number",[1,2])
def test_h94_actual_preparation_snapshot_failure_keeps_partial_observation_and_finishes_owner(monkeypatch,snapshot_number):
    captures,receipts=_h94_test_observe(monkeypatch);snapshot=_r36_native_snapshot;calls=[]
    actual=OSError(5,"H94_INITIAL_SNAPSHOT")
    def observed(fd):
        calls.append(fd)
        if len(calls)==snapshot_number:raise actual
        return snapshot(fd)
    monkeypatch.setitem(globals(),"_r36_native_snapshot",observed)
    with pytest.raises(OSError) as caught:_r36_native_case("pipe-shared")
    capture=captures[0];_h94_test_closed(capture)
    assert caught.value is actual and capture.first["object"] is actual
    assert len(calls)==snapshot_number  # No inert-helper optional native query.
    assert len(capture.finishes)==2 and capture.finishes[1]["label"]=="actual-prepare-failure"
    facts=_h94_test_unfreeze(capture.precleanup)
    assert len(facts["independent_before"])==snapshot_number-1
    assert facts["actual_received_pieces"] is _H94_UNOBSERVED
    assert facts["argv"]==["bash",str(HOOK)] and facts["pid"]==99


@pytest.mark.parametrize("mode",["before-launch","communicate-error","native-timeout-none","witness-read","reader-and-cleanup"])
def test_h94_inert_original_pipe_observer_failure_boundaries_retain_native_states(monkeypatch,tmp_path,mode):
    # Direct original caller execution at inert launch/identity boundaries only;
    # this does not qualify real Popen/kernel/witness/SAME or the full native gate.
    from types import SimpleNamespace
    captures,receipts=_h94_test_observe(monkeypatch);actual=OSError(5,"H94_OBSERVER_"+mode)
    later=[OSError(5,"H94_CHILD_KILL"),OSError(5,"H94_KNOWN_0")];actions=[]
    notebooks=tmp_path/"notebooks";notebooks.mkdir()
    for name,pid in [("ordinary-child-pid.txt",101),("engine-kernel-pid.txt",102)]:
        (notebooks/name).write_text(str(pid))
    child=SimpleNamespace(pid=12345,returncode=None,communications=0)
    def communicate(timeout):
        child.communications+=1
        if mode=="communicate-error":raise actual
        if mode=="native-timeout-none" and child.communications==1:
            raise subprocess.TimeoutExpired(["bash",str(HOOK)],timeout,output=None,stderr=b"")
        child.returncode=0;return b"RAW\0\xff",b""
    def kill():
        actions.append("kill")
        if mode=="reader-and-cleanup":raise later[0]
    def wait(timeout):actions.append(("wait",timeout));child.returncode=0;return 0
    child.poll=lambda:child.returncode
    child.communicate=communicate;child.kill=kill;child.wait=wait
    child.terminate=lambda:actions.append("terminate")
    def launch(*args,**kwargs):
        actions.append("launch")
        if mode=="before-launch":raise actual
        return child
    def identity(pid,repo):return dict(pid=pid,command="INERT-KNOWN",lstart="INERT")
    def stop(ident,repo):
        actions.append(("known",ident["pid"]))
        if mode=="reader-and-cleanup" and ident["pid"]==101:raise later[1]
    def reader(*args,**kwargs):
        if mode=="reader-and-cleanup":child.returncode=None
        raise actual
    # This is an inert caller boundary, never a Git fixture or Git acceptance.
    monkeypatch.setitem(globals(),"_index",lambda repo:b"H94_INERT_INDEX_READ")
    monkeypatch.setattr(subprocess,"Popen",launch)
    monkeypatch.setitem(globals(),"_pid_identity",identity)
    monkeypatch.setitem(globals(),"_stop_fixture",stop)
    monkeypatch.setitem(globals(),"_events",reader)
    if mode=="witness-read":
        original_read=Path.read_text
        def read_text(path,*args,**kwargs):
            if path==notebooks/"ordinary-child-pid.txt":raise actual
            return original_read(path,*args,**kwargs)
        monkeypatch.setattr(Path,"read_text",read_text)
    with pytest.raises((OSError,pytest.fail.Exception)) as caught:_observe_real_hook_child(tmp_path,HOOK)
    capture=captures[0];facts=_h94_test_unfreeze(capture.precleanup)
    assert capture.outer_exited and capture.first["object"] is caught.value
    if mode=="before-launch":
        assert caught.value is actual and facts["pid"] is _H94_UNOBSERVED
        assert facts["stdout"] is _H94_UNOBSERVED and facts["communications"]==[]
        assert not any(row["operation"].startswith(("original-child", "original-known")) for row in capture.cleanup)
    elif mode=="communicate-error":
        assert caught.value is actual and facts["communications"][0]["outcome"]=="entered"
        assert facts["communications"][0]["stdout"] is _H94_UNOBSERVED
        assert "kill" in actions and ("wait",5) in actions
    elif mode=="native-timeout-none":
        assert facts["communications"][0]["outcome"]=="TimeoutExpired"
        assert facts["communications"][0]["stdout"] is None and facts["communications"][0]["stderr"]==b""
        assert facts["communications"][1]["outcome"]=="returned"
        assert isinstance(caught.value,pytest.fail.Exception)  # Original bounded-lifecycle oracle.
        assert "terminate" in actions
    elif mode=="witness-read":
        assert caught.value is actual and facts["witness_observations"][0]["exists"] is True
        assert facts["witness_observations"][0]["raw"] is _H94_UNOBSERVED
    else:
        assert caught.value is actual and facts["stdout"]==b"RAW\0\xff" and facts["stderr"]==b""
        assert [row["object"] for row in capture.faults]==[actual,*later]
        assert ("wait",5) in actions and ("known",102) in actions
        assert receipts[0]["faults"][-1]["object_id"]==id(later[1])


def _h96_test_first(capture,actual,seen):
    assert capture.first is seen and capture.first["object"] is actual
    assert capture.first["traceback"] is not None
    nodes=list(capture._trace(actual.__traceback__))
    assert any(tb is capture.first["traceback"] for tb in nodes)
    assert capture.first["observed"]==seen["observed"]
    assert all(row["entered"]>=seen["observed"] for row in capture.cleanup)
    assert capture.outer_exited


@pytest.mark.parametrize("boundary",["exists","read","parse","identity"])
@pytest.mark.parametrize("cleanup_fault",[False,True])
def test_h96_original_observer_first_known_enrolled_before_second_fault(monkeypatch,tmp_path,boundary,cleanup_fault):
    # The actual original observer is called; only its explicit inert launch/index/
    # identity/reader boundaries are substituted. No actual process is invented.
    from types import SimpleNamespace
    captures,receipts=_h94_test_observe(monkeypatch)
    observation_error=OSError(5,"H96_SECOND_"+boundary);later=OSError(5,"H96_KNOWN_AFTER_SAFE_ACTION")
    directory=tmp_path/"notebooks";directory.mkdir()
    first_path=directory/"ordinary-child-pid.txt";second_path=directory/"engine-kernel-pid.txt"
    first_path.write_text("101");second_path.write_text("H96_INVALID_PID" if boundary=="parse" else "102")
    first_identity=dict(pid=101,command="H96_INERT_KNOWN_FIRST",lstart="H96_INERT_START")
    actions=[];first_rows=[];child=SimpleNamespace(pid=12345,returncode=None)
    child.poll=lambda:child.returncode
    def kill():actions.append(("child-kill",child.pid))
    def wait(timeout):actions.append(("child-wait",timeout));child.returncode=0;return 0
    child.kill=kill;child.wait=wait
    def no_communicate(*args,**kwargs):raise AssertionError("second-witness fault must precede communicate")
    child.communicate=no_communicate
    def identity(pid,repo):
        actions.append(("identity",pid))
        if pid==101:return first_identity
        assert pid==102 and boundary=="identity"
        raise observation_error
    def stop(actual,repo):
        assert actual is first_identity
        actions.append(("known-safe-stop",actual["pid"]))
        if cleanup_fault:raise later
    fault=_H94FixtureCapture.fault
    def first_observed(self,operation,error):
        row=fault(self,operation,error)
        if self.first is row:first_rows.append(row)
        return row
    exists=Path.exists;read=Path.read_text
    def actual_exists(path):
        if path==second_path and boundary=="exists":raise observation_error
        return exists(path)
    def actual_read(path,*args,**kwargs):
        if path==second_path and boundary=="read":raise observation_error
        return read(path,*args,**kwargs)
    monkeypatch.setattr(Path,"exists",actual_exists);monkeypatch.setattr(Path,"read_text",actual_read)
    monkeypatch.setattr(_H94FixtureCapture,"fault",first_observed)
    monkeypatch.setitem(globals(),"_index",lambda repo:b"H96_INERT_INDEX_READ")
    monkeypatch.setattr(subprocess,"Popen",lambda *args,**kwargs:child)
    monkeypatch.setitem(globals(),"_pid_identity",identity);monkeypatch.setitem(globals(),"_stop_fixture",stop)
    with pytest.raises((OSError,ValueError)) as caught:_observe_real_hook_child(tmp_path,HOOK)
    capture=captures[0];facts=_h94_test_unfreeze(capture.precleanup)
    actual=caught.value
    if boundary=="parse":assert type(actual) is ValueError and actual.args==("invalid literal for int() with base 10: 'H96_INVALID_PID'",)
    else:assert actual is observation_error
    _h96_test_first(capture,actual,first_rows[0])
    assert facts["known"]==[first_identity],"already obtained first identity missing from actual cleanup knowledge"
    assert facts["witness_observations"][0]["identity"]==first_identity
    second=facts["witness_observations"][1]
    assert second["exists"] is _H94_UNOBSERVED if boundary=="exists" else second["exists"] is True
    assert second["raw"] is _H94_UNOBSERVED if boundary in {"exists","read"} else second["raw"]==("H96_INVALID_PID" if boundary=="parse" else "102")
    assert second["identity"] is _H94_UNOBSERVED
    cleanup=[row for row in actions if row[0] in {"child-kill","child-wait","known-safe-stop"}]
    assert cleanup==[("child-kill",12345),("child-wait",5),("known-safe-stop",101)],"original child then actually known witness cleanup order/count differs"
    assert [row["object"] for row in capture.faults]==([actual,later] if cleanup_fault else [actual])
    assert receipts[0]["outer_exited"] and receipts[0]["faults"][0]["observed"]==first_rows[0]["observed"]
    assert capture.receipt_retained
    print("H96_KNOWN_DIRECT_CONTROL "+json.dumps(dict(boundary=boundary,cleanup_fault=cleanup_fault,
        cleanup_actions=cleanup,identity_actions=actions,first_object_id=id(actual),first_observed=first_rows[0]["observed"],
        first_traceback=[dict(function=tb.tb_frame.f_code.co_name,line=tb.tb_lineno) for tb in capture._trace(first_rows[0]["traceback"])],
        known=facts["known"],second_observation=_h94_freeze_value(second),secondary_object_ids=[id(x["object"]) for x in capture.faults[1:]])),flush=True)


@pytest.mark.parametrize("mode",["missing-first","healthy-order","delayed-first","both-known-first-cleanup-fault"])
def test_h96_original_observer_no_invented_witness_and_remaining_known_order(monkeypatch,tmp_path,mode):
    from types import SimpleNamespace
    captures,receipts=_h94_test_observe(monkeypatch);actions=[];observations=[];first_rows=[]
    actual=OSError(5,"H96_ORIGINAL_"+mode);later=OSError(5,"H96_SAFE_FIRST_CLEANUP")
    directory=tmp_path/"notebooks";directory.mkdir();first_path=directory/"ordinary-child-pid.txt";second_path=directory/"engine-kernel-pid.txt"
    if mode!="missing-first":first_path.write_text("101")
    second_path.write_text("102")
    identities={pid:dict(pid=pid,command="H96_INERT_"+str(pid),lstart="H96_INERT_START")for pid in (101,102)}
    child=SimpleNamespace(pid=12345,returncode=None);child.poll=lambda:child.returncode
    def kill():actions.append(("child-kill",12345))
    def wait(timeout):actions.append(("child-wait",timeout));child.returncode=0;return 0
    def communicate(timeout):child.returncode=0;return b"H96_OBSERVED\0",b""
    child.kill=kill;child.wait=wait;child.communicate=communicate
    def identify(pid,repo):observations.append(pid);return identities[pid]
    def stop(identity,repo):
        assert identity is identities[identity["pid"]]
        actions.append(("known-safe-stop",identity["pid"]))
        if identity["pid"]==101:raise later
    def reader(*args,**kwargs):
        if mode=="both-known-first-cleanup-fault":child.returncode=None;raise actual
        return []  # Explicit inert reader result, never real SAME qualification.
    exists=Path.exists;first_probes=[]
    def exists_at_boundary(path):
        if mode=="missing-first" and path==second_path:raise actual
        if mode=="delayed-first" and path==first_path:
            first_probes.append(path)
            if len(first_probes)==1:return False
        return exists(path)
    fault=_H94FixtureCapture.fault
    def first_observed(self,operation,error):
        row=fault(self,operation,error)
        if self.first is row:first_rows.append(row)
        return row
    monkeypatch.setattr(_H94FixtureCapture,"fault",first_observed)
    monkeypatch.setattr(Path,"exists",exists_at_boundary)
    monkeypatch.setitem(globals(),"_index",lambda repo:b"H96_INERT_INDEX_READ")
    monkeypatch.setattr(subprocess,"Popen",lambda *args,**kwargs:child)
    monkeypatch.setitem(globals(),"_pid_identity",identify);monkeypatch.setitem(globals(),"_stop_fixture",stop)
    monkeypatch.setitem(globals(),"_events",reader)
    if mode in {"missing-first","both-known-first-cleanup-fault"}:
        with pytest.raises(OSError) as caught:_observe_real_hook_child(tmp_path,HOOK)
        assert caught.value is actual
    else:
        result,known=_observe_real_hook_child(tmp_path,HOOK)
        assert known==[identities[101],identities[102]] and known[0] is identities[101] and known[1] is identities[102]
        assert result.returncode==0 and actions==[]
    capture=captures[0];facts=_h94_test_unfreeze(capture.precleanup)
    if mode=="missing-first":
        assert observations==[] and facts["known"]==[]
        assert facts["witness_observations"][0]["exists"] is False
        assert actions==[("child-kill",12345),("child-wait",5)]
        _h96_test_first(capture,actual,first_rows[0])
    elif mode=="both-known-first-cleanup-fault":
        assert facts["known"]==[identities[101],identities[102]]
        assert actions==[("child-kill",12345),("child-wait",5),("known-safe-stop",101),("known-safe-stop",102)]
        assert [row["object"] for row in capture.faults]==[actual,later]
        _h96_test_first(capture,actual,first_rows[0])
    else:
        assert facts["known"]==[identities[101],identities[102]] and capture.first is None
        assert observations==([102,101] if mode=="delayed-first" else [101,102])
    assert capture.outer_exited and capture.receipt_retained
    print("H96_KNOWN_ORDER_CONTROL "+json.dumps(dict(mode=mode,actual_observation_order=observations,cleanup_actions=actions,known=facts["known"],first_object_id=id(capture.first["object"]) if capture.first else None)),flush=True)


@pytest.mark.parametrize("failure_index",[0,1])
@pytest.mark.parametrize("after_append",[False,True])
@pytest.mark.parametrize("close_faults",[False,True])
def test_h96_original_native_pair_cleanup_true_lifo_with_registration_and_close_faults(monkeypatch,failure_index,after_append,close_faults):
    import contextlib
    import errno
    captures,receipts=_h94_test_observe(monkeypatch)
    registration=OSError(5,"H96_ORIGINAL_REGISTRATION");later=[OSError(5,"H96_CLOSE_0"),OSError(5,"H96_CLOSE_1")]
    original_callback=contextlib.ExitStack.callback;original_pipe=os.pipe;original_attempt=_H94FixtureCapture.attempt
    acquired=[];registration_calls=[];actual_cleanup=[];first_rows=[]
    def pipe():pair=original_pipe();acquired.extend(pair);return pair
    def callback(self,*args,**kwargs):
        registration_calls.append(args)
        if len(registration_calls)-1==failure_index:
            if after_append:original_callback(self,*args,**kwargs)
            raise registration
        return original_callback(self,*args,**kwargs)
    def original_close_attempt(self,operation,function,*args,**kwargs):
        if operation.startswith("callback:"):
            ordinal=int(operation.split(":",1)[1])
            assert function is os.close and len(args)==1 and kwargs=={}
            actual_cleanup.append(dict(function=function.__module__+"."+function.__qualname__,args=list(args),ordinal=ordinal))
            if close_faults:
                def close_then_raise(*values):function(*values);raise later[ordinal]
                return original_attempt(self,operation,close_then_raise,*args)
        return original_attempt(self,operation,function,*args,**kwargs)
    original_fault=_H94FixtureCapture.fault
    def first_observed(self,operation,error):
        row=original_fault(self,operation,error)
        if self.first is row:first_rows.append(row)
        return row
    monkeypatch.setattr(os,"pipe",pipe);monkeypatch.setattr(contextlib.ExitStack,"callback",callback)
    monkeypatch.setattr(_H94FixtureCapture,"attempt",original_close_attempt)
    monkeypatch.setattr(_H94FixtureCapture,"fault",first_observed)
    with pytest.raises(OSError) as caught:_r36_native_case("pipe-shared")
    capture=captures[0];_h96_test_first(capture,registration,first_rows[0])
    assert caught.value is registration and len(acquired)==2
    assert [row["ordinal"] for row in actual_cleanup]==[1,0],"actual original acquired/unregistered callback order is not LIFO"
    assert [row["args"][0] for row in actual_cleanup]==[acquired[1],acquired[0]],"actual callback arguments differ from reverse acquired capabilities"
    assert all(row["function"]==os.close.__module__+"."+os.close.__qualname__ for row in actual_cleanup)
    assert all(row["calls"]==1 and row["state"]=="finished" for row in capture.callbacks)
    for descriptor in acquired:
        with pytest.raises(OSError) as closed:os.fstat(descriptor)
        assert closed.value.errno==errno.EBADF
    assert [row["object"] for row in capture.faults]==([registration,later[1],later[0]] if close_faults else [registration])
    assert len({row["owner_id"] for row in capture.finishes})==len(capture.finishes)
    assert len(capture.finishes)==2 and capture.finishes[1]["label"]=="actual-prepare-failure"
    assert capture.stack_empty_after_close and capture.outer_exited and capture.receipt_retained
    assert receipts[0]["outer_exited"] and [row["calls"] for row in receipts[0]["callbacks"]]==[1,1]
    assert receipts[0]["faults"][0]["object_id"]==id(registration)
    assert receipts[0]["faults"][0]["observed"]==first_rows[0]["observed"]
    print("H96_LIFO_DIRECT_CONTROL "+json.dumps(dict(failure_index=failure_index,after_append=after_append,
        close_faults=close_faults,acquired=acquired,actual_original_cleanup=actual_cleanup,
        primary_object_id=id(registration),primary_observed=first_rows[0]["observed"],
        secondary_objects=[id(row["object"])for row in capture.faults[1:]],
        secondary_operations=[row["operation"]for row in capture.faults[1:]],outer_exited=capture.outer_exited,
        stack_empty=capture.stack_empty_after_close,finishes=[dict(owner_id=row["owner_id"],label=row["label"],state=row["state"])for row in capture.finishes])),flush=True)


def test_h96_original_owner_source_binds_incremental_enrollment_and_reverse_fallback():
    import ast
    tree=ast.parse(Path(__file__).read_text())
    observer=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="_observe_real_hook_child")
    conditional=next(n for n in ast.walk(observer) if isinstance(n,ast.If) and ast.unparse(n.test)=="identity is not None")
    assignments=[n for n in conditional.body if isinstance(n,ast.Assign)]
    assert [ast.unparse(n.targets[0])for n in assignments]==["observed[path]","known"]
    assert ast.unparse(assignments[1].value)=="[observed[entry] for entry in files if entry in observed]"
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="_H94FixtureCapture")
    register=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=="register")
    fallback=next(n for n in ast.walk(register)if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=="unregistered")
    assert ast.unparse(fallback.iter)=="reversed(rows)"
    assert "resources._exit_callbacks" in ast.unparse(register)
