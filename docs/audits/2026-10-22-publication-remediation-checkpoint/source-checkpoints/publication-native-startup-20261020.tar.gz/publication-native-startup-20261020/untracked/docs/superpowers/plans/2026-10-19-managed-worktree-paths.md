# Implementation plan — managed-worktree path portability

Status: consumer corrections and their original real-source controls have bounded independent
source/runtime acceptance. Additional positive registry-rule coverage is authored SOURCE only;
fresh whole nonauthor review and actual new-control qualification remain owed. Preserve the
original live-queue conditional coverage gap and all whole-project acceptance obligations.
Parent scope: accepted full corrective qualification design, active-target and shared-cache roots.
Owning [design](../specs/2026-10-19-managed-worktree-paths-design.md).
Historical original findings and review are pinned in immutable commit
`9edf7c8fa3a4495c0508615371a9240c5c5dae11`; they are read-only provenance, not current closure.

## P1. Accept or repair the specification

Publication lead independently challenges the complete design against ADR-012 P10 and the
existing canonical workspace owner. Use the actual baseline red receipts and current
source/history; do not accept a helper-name scan as evidence. Return corrections to this
specification author. Record a concrete accepted result before the implementation successor.
No source code, tests, closures or Git integration in this step.

## P2. Assign one coherent implementation package

The lead names an accepted owner and a fresh continuity packet for the isolated candidate,
including protected source/branch state, exact paths and nonauthor acceptance reviewer.
Do not assume the current specification assignment permits implementation. Keep source and
regression controls together so normalization cannot land without its missing-file refusals.
No Lean lane or cache/acquisition controller is required.

Prospective paths: existing `scripts/orchestrate.py::target_files`,
`tests/test_orchestrate.py`, `tests/test_phase6i_wave1.py` (cache function and controls),
`tests/test_architecture_claims.py` (new ADR sentence/runtime pin); extend the existing resolver
tests only if needed for the different managed layout. No new resolver/check/gate/ledger.
The current ADR clarification, spec and plan travel with the bounded consumer/test repair.
The historical finding and review files remain references and are not copied as new acceptance.

## P3. Implement the two consumer corrections

1. Normalize one exact leading logical repository prefix within the existing target parser.
   Resolve the resulting candidate inside the active checkout. Preserve canonical containment,
   file-existence, all-target enumeration/dedup, legacy contained spellings, file-conflict
   queuing and lane strength. Do not redirect to the canonical sibling or relax a guard.
2. Replace the cache test's ad hoc workspace parent walk with already imported
   `find_workspace()`. Keep checkout-local source state and the unchanged real missing/empty
   assertion and successful-state drift distinction. Remove a now-unused old root definition.
   Preserve the unrelated later-primary tmp_path extractor change on integration.
3. Bind the new ADR sentence to runtime results in the existing architecture-claims tests;
   pin sentence plus behavior, not just a helper name in source text.

## P4. Prove the repair without weakening the measurements

Record exact interpreter, candidate HEAD/source hashes and imports from the active candidate.
Use the prepared existing Python environment without dependency install/sync. Keep default
pytest selection semantics and record any broader run's actual scope.

Required controls are the design D3 table, including a canonical sibling with a distinct active
copy, mixed prefix/unprefixed/ranges/multipath dedup and missing/traversal/escape refusal;
cache nonempty, missing, empty, success-drift, null-path and opposing active/foreign state in
canonical, named managed and nested layouts. Call the existing cache invariant and real
canonical resolver; retarget filesystem/module-location and registry/state inputs, never replace
the resolver return or implement another validator. Assert candidate module/code origins and
complete iteration. Retain once-only prefix and contained parent-spelling controls.
The current two original failure identities must be red with old behavior and green after
repair in the actual differently named managed checkout. Their green alone is insufficient.

Run at least the complete orchestrator file, resolver tests, existing architecture claim pins
and the entire Phase6i file with its complete existing controls. Report every actual current
failure; earlier candidates' citation outcomes do not qualify this candidate. Do not skip any assertion,
reduce registry coverage, forge a success record or raise a ceiling.

Use the existing seed journal for real production-artifact mutation, only in the allocated
checkout; preserve exact bytes/metadata and durable red/restore receipts. Do not seed the shared
literature cache or mutate another worker's candidate. If a production control cannot be run
within the allocated isolation, retain it as owed and return the concrete missing condition.

## P5. Author repair, independent verification, recorded closure

A genuinely nonauthor reviewer independently reads the whole source/test/docs diff and actual
red/green/restore receipts. Challenge canonical-sibling routing, active import witnesses,
existence/containment/multiplicity, file/lane composition and successful-state-only drift.
Return mandatory corrections to the author; an accepted specification or self-test is not this
review. Root runs appropriate existing change-scoped checks and required integrated gates.
Close only through the existing writer after the acceptance bar is actually met. No closure writer or ratchet change belongs to this source-composition assignment.

## P6. Integrate at the first accepted repair checkpoint

The lead composes a reviewed ordinary Git checkpoint against the current integration base,
preserving NJL/ADW and accepted later-primary work. Inspect the final combined diff and qualify
that exact head; an isolated branch pass is not merged-main evidence. Follow the user's
minimum cadence of integrating completed milestones instead of retaining publication work
indefinitely in a worktree. Merge only after the existing required gate/review boundary.
Scientific bundle readiness and final human publication review remain independent.

## Termination evidence

This source handback ends after the coherent existing consumer/test/doc composition, exact
FIRST/FINAL and protected-state evidence. Actual current runtime, independent evidence review,
supported closure and reviewed Git integration remain separate root-owned transitions.


## P7. Add positive writer and nonwriter coverage without replacing the live queue

Document Decision D5 before appending controls in tests/test_orchestrate.py. Keep every existing
function, assertion, parameter, marker and byte prefix, including the conditional live-queue
registry-rule test. Preserve the current consumer implementation and accepted original controls.

Use actual canonical review Markdown and real target files under tmp_path, retargeting only
existing planner/extractor filesystem roots. Let the actual extractor mint identities and parse
all lanes, Verify fields and dependencies; let the actual planner discover its temporary
planning-only inventory, classify/group/rank/apply capacity and conflict guards, and return
registry_rule. Assert import/code origins and complete expected input/output populations.
Never substitute the plan, rule producer, graph extractor, resolver or output with a mock.

Require positive dispatched lean/substrate/pyrust and prose/research/infra populations under
adequate capacity. Writer rules must prohibit editing and carry both actual shared-registry
paths plus the report-to-lead responsibility; nonwriter rules must be absent. Test blocked,
unrouted, untargeted, missing-Verify and overlapping-file inputs and constrained capacity with
complete ID conservation. Temporary inventory markers are isolated test data, not real Lean
worktree admission or an instruction to acquire/create a live slot.

After genuine whole nonauthor source/control review, the runtime owner runs the existing
complete four modules with added cases and unchanged default markers. Retain every actual
outcome: the original live-queue skip and slow deselection remain coverage limits, never passes.
The accepted original target/cache source sensitivities need not repeat absent changed source,
failure or new concern. Run the new producer sensitivity sequences separately through the
existing seed journal in the allocated candidate: remove a writer lane from the production
registry_note guard; omit each registry from its actual returned note; broadcast the note to a
nonwriter. Preserve all test inputs/oracles and use the unchanged new positive selector for
strict baseline PASS, intended assertion FAIL/no error or skip, exact source restoration,
empty journal and restored PASS. Record the complete raw child/source/journal evidence.

No project imports/helpers/tests/collection, production mutation, native/controller/build,
closure writer or Git mutation belongs to this source-author step. The source handback must
contain complete additive diffs, original byte/AST conservation and exact production recipe
preimages/postimages. Independent source review precedes actual runtime and whole evidence
review. Full bare both-testpath/default/slow qualification, appropriate verify_scope/merge gate/
ExtractDeps, owner-drained loading/normal native, scientific BUILD, literal Verify/existing
closure, protected coherent checkpoint/main and final human acceptance remain separate.

## Current coverage checkpoint — whole qualification withheld

Existing consumer source and original real-production sensitivities retain their accepted
scopes. New deterministic registry-rule coverage is SOURCE only; it does not turn the original
live-queue conditional skip into a pass or establish a new complete profile. All original
findings, scientific charters and positive live-writer coverage remain active until their own
required evidence is obtained. Proceed through the existing review/fix/closure and integration
owners; a blocked native step does not suspend independent scientific work.
