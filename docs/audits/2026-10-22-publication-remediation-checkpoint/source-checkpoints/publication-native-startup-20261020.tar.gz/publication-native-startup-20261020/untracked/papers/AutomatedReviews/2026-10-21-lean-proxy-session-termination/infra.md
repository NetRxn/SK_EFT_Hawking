# Genuine Lean proxy session termination — source candidate, acceptance open

## Findings

### 1.1 — 🔴 Idle DELETE initializes an absent backend and successful DELETE can resurrect its client ID

- **Severity:** major
- **Lane:** infra
- **Gate:** bundle_readiness
- **Location:** `scripts/lean_slots/proxy.py` Handler._handle and SessionBroker.
- **Observed (historical NS73 native source):** Actual qualification returned initialize200, notification202, tools-list200/no lean_build and correct unleased tool403, followed by DELETE503 and a distinct cleanup503 on an idle backend. Whole qualification failed. That historical source lazily initialized for DELETE, applied stale-session retry and did not retire successful client IDs; the source candidate below does not retroactively repair those receipts. Earlier attempts and errors must remain evidence.
- **Evidence:** Proxy source SHA256 e04b980848636221b6b1e8126203496894feacd7291d9ec978acee2cdca59de5; original separate failures at2026-10-21T08:57:36Z. ROOT retains complete immutable raw runtime/cleanup receipts. NS81 subsequently authored the candidate and recorded285PASS/1originalSKIP at proxy5441ae3a/tests e49e5a88, preserving all240 original ordered outcomes plus46 new cases. NS83 corrective source/new controls are UNRUN and pending whole nonauthor review. All16 production sensitivities plus3 ingress remain UNRUN; NS66 full8292PASS22FAIL10SKIP and the original NS73 failures remain. No private identifiers or paths are copied here.
- **Expected:** Full S-Q ordinary restart transparency AND genuine explicit cleanup in the existing front door: idle local termination, actual mapped forwarding, no re-adoption of a closed client token for that proxy lifetime, coherent concurrency and retained ambiguous/partial establishment outcomes. B2 recovery/success must not erase unresolved B1 or known notready candidates. Actual DELETE send/result must be bound to its unique close owner/epoch/target and immutable pre-send covered attempt/allocation-generation cohort. A late candidate with equal backend token is not covered and remains503/LIVE until a separate explicit cleanup; two preexisting eligible equal-value bindings retain the one-DELETE positive. Logical session cleanup does not establish tool completion/physical teardown. GET receiving a stream must not circularly prevent mapped DELETE. Existing timeout180 is relative, not a total wall promise; retain explicit HEAD/full-conformance limits.
- **Fix:** Coherent document-first ST-9–ST-16 in existing ADR/spec/plan/guide, whole nonauthor design review, explicitly accepted source author, whole source/control review, actual new node collection and complete original+new suites/production-seeded red-restored-green controls, ROOT separate canonical/native qualification. Keep original H04/H13 parameters, real prewarmed mapping/200/body/forwarding/raw header oracles and terminal404. Preserve all attempt/candidate/first-error history and truthful aggregate cleanup. Add real Handler/Broker paired equal-value controls and a sole actual production overbroad-acknowledgement red/restored-green obligation; retain all original controls; no false204/200 on residual unknown, no405 waiver, global unknown404, new service or lease/controller authority.
- **Verify:** `.venv/bin/python -B -m pytest tests/test_lean_slots.py::test_st_term_idle_minted_delete_no_backend tests/test_lean_slots.py::test_st_term_no_resurrection_and_collision tests/test_lean_slots.py::test_st_term_mapped_forward_and_buffered_ownership tests/test_lean_slots.py::test_st_term_lost_initialize_recovery_delete_retains_unknown tests/test_lean_slots.py::test_st_term_known_candidate_recovery_delete tests/test_lean_slots.py::test_st_term_get_ends_only_after_mapped_delete tests/test_lean_slots.py::test_st_term_pending_establish_and_generation tests/test_lean_slots.py::test_st_term_preexisting_same_backend_value_one_delete_covers_known_attempts tests/test_lean_slots.py::test_st_term_late_same_backend_value_not_covered_by_prior_delete tests/test_lean_slots.py::test_st_term_operation_late_close_retains_result tests/test_lean_slots.py::test_st_term_operation_first_cause_and_later_close_errors tests/test_lean_slots.py::test_st_term_pending_establish_failure_cleanup tests/test_lean_slots.py::test_st_term_second_delete_has_independent_send_witness -q -p no:cacheprovider`

All nine selectors above existed/collected at NS81's pin; fresh NS83 collection/execution and its new close-history/cleanup selectors remain required. Their source presence is not current runtime, independent or native acceptance. Naming required nodes makes absence fail rather than old-suite false green. This focused Verify is necessary, not sufficient: the existing plan requires the COMPLETE original+new suite, all causal production mutation/restoration evidence, genuine independent whole review, broader gates and ROOT LO-5/native qualification. Author repair -> independent verification -> designated closure writer remains mandatory. All scientific/main/publication/human obligations remain owed; no source-only or narrow test closure is claimed.


### NS83 corrective source contract — pending whole independent review

Ordinary POST/finite-tool/GET tickets retain the actually observed backend
result or stream state separately from frontdoor write and every owned
connection-close disposition. Record a request/receive/write failure when
observed; preserve that immutable first cause when a distinct later close fails.
A late close never erases an already observed result, supplies tool completion
from DELETE/EOF, reopens a logical token or replaces the earlier cause. Close
each owned forwarding connection once and finish its operation accounting once
in a nested finally, including a close exception. A stale-retry close relinquishes
that exact connection before attempting close, so failure cannot trigger a
second close or an unowned replacement. Unexpected failures remain propagated;
recording is not a broad suppression or a second authority.

The pending-establishment control owns every created worker, barrier and direct
ticket from creation through all failing assertion/join paths. Its unconditional
cleanup releases all owned barriers first, attempts every join even after an
earlier join raises, and waits for actual owned-worker quiescence before returning
to fixture/monkeypatch teardown or another seed. A diagnostic watchdog is not
permission to abandon a live worker. Finish only the actual direct ticket with
its observed result/error (or honestly undispatched fixture-owner abort);
expected503 worker errors remain recorded rather than being mistaken for a
cleanup success failure. Retain the original assertion as primary; attach cleanup
faults separately and never skip a later worker/ticket. This is test resource
custody, not a production timeout, fake admission result or mathematical receipt.

Additional real Handler/external-transport source controls:
- test_st_term_operation_late_close_retains_result: actual POST, finite tool and
  GET result/EOF followed by owned close OSError; original result/raw response,
  immutable first cause, close disposition, one close/finish and no resurrection.
- test_st_term_operation_first_cause_and_later_close_errors: actual request,
  headers/body or frontdoor failure followed by a distinct close failure; retain
  every error in order, original result where observed and retirement separately.
- test_st_term_pending_establish_failure_cleanup: deterministic earlier assertion
  failures and a join fault in the real pending-establishment scenario; retain
  every worker/ticket handle and prove no live owned worker or pending direct
  ticket before fixture teardown/source restore/next seed.

These additions and the revised full source are UNRUN at NS83. Later ROOT uses
existing seed_journal: healthy -> sole production omission of actual operation
close-history attachment -> intended history/result oracle red -> exact
bytes/fullmode/nsmtime restore -> same green. Preserve all16 old production
recipes and3 ingress sensitivities. For old-epoch/publication controls first
prove the intended causal red and the unconditional cleanup's actual quiescence
receipt; no restoration/next-seed progression may assume a watchdog means drain.
No test/assertion mutation, fabricated receipt or pre-admission exception
qualifies. Genuine whole nonauthor source/control review, actual original+new
qualification, broader gates, separately admitted ROOT LO-5/native and normal
protected delivery/closure remain owed. All original scientific/main/human
objectives and failed native/project profiles remain unchanged.

The original nine decisive selectors remain the prefix of Verify; three NS83 source-control selectors extend it. All current NS83 tests are UNRUN. For future failing pending-establishment sensitivity, capture the actual ST_TERM_OWNED_CLEANUP JSON with tee-sys/full XML output and require every owned worker stopped/direct ticket DONE before seed restoration, fixture teardown or another seed; a diagnostic timeout is not quiescence.

## Independent second DELETE send and owner witness

Closing admission has distinct new-work and second-cleanup obligations. Preserve
all original combined concurrency assertions, and additionally require
`test_st_term_second_delete_has_independent_send_witness`: hold only the first
actual backend DELETE response, then invoke a second real Handler DELETE before
any new-work assertion. An incorrectly sent second request must receive an
immediate external response rather than block on the first request's fixture
barrier. Record actual backend sends, both close owner/epoch records, response
status and the first worker's pending state before assertions. Healthy source
requires second503, one actual DELETE, the same first owner/epoch, first200 after
release and later404 without another send.

Use the existing unconditional owned cleanup helper in finally, releasing and
joining the first actual worker on every assertion failure. Preserve the original
assertion and separately retain its real worker result/error and quiescence.
The shared CLOSING-guard production regression must select this independent node
as well as the original combined concurrency node. Actual duplicate-send/owner
trace and its precise assertion failure establish that branch; an earlier
new-work refusal failure or fixture watchdog cannot substitute. All other
source campaigns and original lifecycle/scientific requirements remain intact.

## Second DELETE observer schema and current qualification boundary

A retained closure receipt identifies its owner as `id`; a per-target backend
DELETE record separately stores `owner`. The independent second-send witness
must read `closures[*].id` together with each closure epoch and the record's
current `close_owner`/epoch. This observes the existing schema; it creates no
production field, lifecycle transition, substitute authority or altered oracle.

The first full run of this added witness failed at the mistaken closure-field
lookup before its trace could be emitted. It preserved every original ordered
identity/outcome and quiescent owned cleanup. That frozen observer failure remains
separate from the corrected source and its later actual qualification.
The observer repair must retain the actual first-only DELETE response barrier,
immediate response if an incorrect second send occurs, trace before second-branch
assertions, second503/one-send/same-owner-and-epoch checks, first200 after release,
terminal404 and unconditional first-worker cleanup. No earlier new-work assertion
or fixture watchdog can substitute for the independent second-close branch.

The corrected observer now has author evidence from the complete current
module: all original identities/outcomes retained, the new second-send witness
healthy and every owned cleanup quiescent. Its actual pre-assertion trace observes
one backend DELETE, second503, unchanged first owner/epoch and the first worker
still pending; first200 after release and terminal404 also pass. Existing scoped
source and earlier suite/policy evidence retain their exact prior pins. This is
actual author qualification pending genuine whole independent source/control/
evidence review, not native admission or canonical closure. All twenty production
sensitivity campaigns remain unrun and require that review plus separate ROOT
execution authority. The original lifecycle, scientific and delivery gates remain.

Current observer-repair author evidence: complete305 cases,304PASS and the same original workspace-configuration SKIP; original304 ordered identities/outcomes exact; one new healthy second-close node;15 actual cleanup receipts quiescent. The earlier303PASS/1newFAIL/1sameSKIP attempt remains frozen. No whole independent/current production-sensitivity/native acceptance or finding closure follows.
