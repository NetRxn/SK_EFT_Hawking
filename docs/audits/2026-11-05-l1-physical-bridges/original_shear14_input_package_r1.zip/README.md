# Prepared original N16 shear14 support preflight — NOT RUN

This package is a reviewable scientific input and static forecast, not a completed coefficient evaluator. Read CONSTRUCTION.md and INPUT_SPEC.json. The original unchanged source/archive pins are in UPSTREAM_PINS.json and upstream/. No scientific file has been imported, executed or tested during preparation; only ordinary AST/JSON/hash/zip bookkeeping occurred.

The source targets h14,2((Q_x11-Q_x22)^2). The exact later targets h14,2(q n0m1) andh13,5(n0m1) are separate. No run is needed for the proved-zero h15,1.

After independent actual review AND publication ROOT's explicit local-computation admission, the exact support-only command is:

```bash
python3 /private/tmp/l1-shear14-input-package-r1/prepare_support.py --spec /private/tmp/l1-shear14-input-package-r1/INPUT_SPEC.json --spec-sha256 644ae5d93b24ccffba2e6e49d9e5fbc3150c7b4da13ce0006529ba32041f1a1b --output /private/tmp/l1-shear14-support-output-r1.json --deadline-seconds 120
```

Prepared program SHA256: `7d11c450c97b2e2d63fee5f9cbc345850f2190cc5298e77e9b840e6f54f03107`; input SHA256 above. Any source/spec change needs deliberate re-review and a new exact command. The ignored continuity packet at primary `.codex/continuity/l1-shear14-input-r1.json` is a source snapshot, not admission; reconcile changed authority before running. Do not assume a checkpoint snapshot proves runtime availability.

The cap120seconds is a refusal limit, not measured timing. Static Green work is<=2383872integer multiply-adds plus<=18624candidate/site/edge checks; output<=18624records and40000000bytes. RSS and actual wall time remain unknown. Output is NECESSARY source support only, never a coefficient, Haar value, nonzero proof or full exact/modular run. No Lean/slot/build/process/controller operation is included.

A successful future receipt must verify the exact script/spec/output hashes, complete JSON status/counts, original source pins and independent result acceptance. A partial or refused file does not certify exhaustiveness. Full tensor joins and exact-versus-modular choice require a separate costed source/control construction and ROOT admission. Existing120000row/3000000product guards remain unchanged; no infrastructure or legacy source was modified.
