"""Prepared, NOT RUN: necessary original N16 shear14 input inventory only.

No coefficient, Haar moment, tensor factor or contracted amplitude is evaluated.
Execution requires the publication lead's separate local-computation admission.
"""
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path
import tempfile
import time


VERTICES = tuple(range(16))
AXES = tuple(range(4))
EDGES = tuple((v, d) for v in VERTICES for d in AXES if not v & (1 << d))
EPSILON = tuple(1 if v.bit_count() % 2 == 0 else -1 for v in VERTICES)
MAX_RECORDS = 18624
MAX_RECORD_BYTES = 2048
MAX_OUTPUT_BYTES = 40000000


def edge(v, d):
    return v & ~(1 << d), d


def edge_bit(v, d):
    root, axis = edge(v, d)
    return 1 << (4 * root + axis)


def epsilon4(values):
    return -1 if sum(a > b for i, a in enumerate(values) for b in values[i + 1:]) % 2 else 1


def classes():
    result = []
    for z in VERTICES:
        for k, l in itertools.combinations(AXES, 2):
            mu, nu = (d for d in AXES if d not in (k, l))
            load = [0] * 16
            load[z] += 2
            load[z ^ (1 << mu)] += 1
            load[z ^ (1 << nu)] += 1
            # Original H = D^dag C^dag B A. No anchor is identified.
            anchors = ((z, l, True), (z ^ (1 << l), k, True),
                       (z ^ (1 << k), l, False), (z, k, False))
            character = edge_bit(z, mu) ^ edge_bit(z, nu)
            for v, d, dagger in anchors:
                character ^= edge_bit(v, d)
            result.append({'id': len(result), 'center': z, 'curvature_plane': [k, l],
                           'frame_axes': [mu, nu], 'epsilon': epsilon4((k, l, mu, nu)),
                           'curvature_anchors_H_order': anchors, 'load': load,
                           'edge_character_hex': format(character, 'x')})
    assert len(result) == 96
    return result


def clock_check(start, limit):
    if time.monotonic() - start > limit:
        raise RuntimeError('Support-only inventory deadline exceeded; no complete output written')


def descriptor(m, first, second, case):
    coframes = {(v, d): m[v] + m[v ^ (1 << d)] for v, d in EDGES}
    assert all(n <= 2 for n in coframes.values())
    curvature = {}
    marked = 0
    for item in (first, second):
        z = item['center']
        for d in item['frame_axes']:
            coframes[edge(z, d)] += 1
            marked |= edge_bit(z, d)
        for v, d, dagger in item['curvature_anchors_H_order']:
            curvature[v, d] = curvature.get((v, d), 0) + 1
            marked |= edge_bit(v, d)
    for d in case['frame_axes']:
        coframes[edge(0, d)] += 1
        marked |= edge_bit(0, d)
    assert sum(coframes.values()) == 64 and sum(curvature.values()) == 8
    assignment_power = 0
    max_degree = 0
    paired_unmarked = []
    zero_unmarked = 0
    for (v, d), count in coframes.items():
        w = v ^ (1 << d)
        rv, rw = curvature.get((v, d), 0), curvature.get((w, d), 0)
        if (count + rv + rw) % 2:
            return None, 'paired_edge_parity'
        if count == 0:
            if rv % 2 or rw % 2:
                return None, 'individual_anchor_parity'
        else:
            assignment_power += count - 1
        max_degree = max(max_degree, count + rv, count + rw)
        if not marked & edge_bit(v, d):
            assert rv == rw == 0 and count in (0, 2)
            if count == 2:
                paired_unmarked.append(4 * v + d)
            else:
                zero_unmarked += 1
    assert max_degree <= 8
    doubles = sum(n == 2 for n in m)
    record = {
        'case': case['id'], 'class_pair': [first['id'], second['id']], 'm': m,
        'source_prefactor_numerator': case['outer_weight'],
        'occupation_pair_divisor_power_of_two': doubles + int(first['id'] == second['id']),
        'coframe_counts_edge_order': [coframes[e] for e in EDGES],
        'curvature_anchor_counts': [[v, d, n] for (v, d), n in sorted(curvature.items())],
        'necessary_binary_anchor_assignment_count': 1 << assignment_power,
        'anchor_degree_upper_bound': max_degree,
        'marked_edge_hex': format(marked, 'x'),
        'unmarked_paired_edge_ids': paired_unmarked,
        'unmarked_zero_edge_count': zero_unmarked,
    }
    assert len(json.dumps(record, separators=(',', ':'), sort_keys=True).encode()) <= MAX_RECORD_BYTES
    return record, 'retained_necessary_support'


def prepare(spec, seconds, start):
    g = spec['green']['distance_numerators']
    denominator = spec['green']['denominator']
    assert g == [103, -13, -9, 19, -25] and denominator == 384
    assert spec['target'] == {'a': 14, 'b': 2, 'insertion': 'q_squared'}
    cs = classes()
    records = []
    counts = {'pairs': 0, 'green_vectors': 0, 'reference_candidates': 0,
              'incompatible_checkerboard_rhs': 0, 'nonintegral_or_out_of_range': 0,
              'paired_edge_parity': 0, 'individual_anchor_parity': 0,
              'retained_necessary_support': 0}
    for i, j in itertools.combinations_with_replacement(range(96), 2):
        clock_check(start, seconds)
        counts['pairs'] += 1
        first, second = cs[i], cs[j]
        for case in spec['source_cases']:
            clock_check(start, seconds)
            rhs = [8 - case['load'][v] - first['load'][v] - second['load'][v] for v in VERTICES]
            if sum(EPSILON[v] * rhs[v] for v in VERTICES):
                counts['incompatible_checkerboard_rhs'] += 1
                continue
            assert sum(rhs) == 112
            vnum = [sum(g[(v ^ w).bit_count()] * rhs[w] for w in VERTICES) for v in VERTICES]
            counts['green_vectors'] += 1
            for reference in (0, 1):
                counts['reference_candidates'] += 1
                nums = [vnum[v] + (denominator * reference - vnum[0]) * EPSILON[v] for v in VERTICES]
                if any(n % denominator or n < 0 or n > 2 * denominator for n in nums):
                    counts['nonintegral_or_out_of_range'] += 1
                    continue
                m = [n // denominator for n in nums]
                assert m[0] == reference and sum(m) == 14
                assert all(4 * m[v] + sum(m[v ^ (1 << d)] for d in AXES) == rhs[v] for v in VERTICES)
                record, status = descriptor(m, first, second, case)
                counts[status] += 1
                if record is not None:
                    records.append(record)
                    if len(records) > MAX_RECORDS:
                        raise RuntimeError('Proved candidate record bound exceeded')
    assert counts['pairs'] == 4656 and counts['green_vectors'] <= 9312
    assert counts['reference_candidates'] <= MAX_RECORDS
    clock_check(start, seconds)
    return {'status': 'complete_necessary_support_inventory_only',
            'not_a_coefficient_or_nonzero_certificate': True,
            'classes': cs, 'edge_order': EDGES, 'source_cases': spec['source_cases'],
            'counts': counts, 'records': records,
            'elapsed_seconds': time.monotonic() - start}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--spec', type=Path, required=True)
    ap.add_argument('--spec-sha256', required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--deadline-seconds', type=float, default=120.0)
    args = ap.parse_args()
    if not 0 < args.deadline_seconds <= 120:
        raise ValueError('Prepared admission scope allows at most 120 seconds')
    start = time.monotonic()
    raw = args.spec.read_bytes()
    if hashlib.sha256(raw).hexdigest() != args.spec_sha256:
        raise ValueError('Input specification hash mismatch')
    spec = json.loads(raw)
    payload = prepare(spec, args.deadline_seconds, start)
    payload['source_head'] = spec['source_head']
    payload['input_spec_sha256'] = args.spec_sha256
    payload['program_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    data = (json.dumps(payload, separators=(',', ':'), sort_keys=True) + '\n').encode()
    if len(data) > MAX_OUTPUT_BYTES:
        raise RuntimeError('Support-only output byte bound exceeded')
    clock_check(start, args.deadline_seconds)
    if args.output.exists():
        raise FileExistsError(args.output)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.support-inventory-', dir=args.output.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        clock_check(start, args.deadline_seconds)
        os.link(temporary, args.output)
    finally:
        Path(temporary).unlink(missing_ok=True)
    print(json.dumps({'status': payload['status'], 'counts': payload['counts'],
                      'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                      'elapsed_support_seconds': payload['elapsed_seconds'],
                      'elapsed_total_seconds': time.monotonic() - start}, sort_keys=True))


if __name__ == '__main__':
    main()
