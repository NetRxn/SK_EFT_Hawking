"""Bounded exact full-tensor leading metric calculation; research only."""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import cache
from itertools import combinations_with_replacement, permutations, product
from math import factorial, prod
from pathlib import Path
import importlib
import sys

ROOT = Path(__file__).resolve().parent
ROW_CAP = 120_000
PAIR_CAP = 3_000_000
TREE = frozenset(((0, 0), (0, 1), (1, 1)))
Z8 = Fraction(1252309350145403, 2123366400)
L = S = M = MOMENT = None


def bind():
    global L, S, M, MOMENT
    if L is None:
        sys.path.insert(0, str(ROOT / 'science'))
        L = importlib.import_module('legacy')
        S = importlib.import_module('l1_interacting_support')
        M = importlib.import_module('l1_mixed_g1_support')
        MOMENT = importlib.import_module('l1_direct_a_haar').haar_moment


def bounded(axes, rows, degrees):
    count = sum(map(len, rows.values()))
    if count > ROW_CAP:
        raise RuntimeError(f'{count} factor row slots exceed cap {ROW_CAP}')
    return tuple(axes), rows, dict(degrees)


def cmul(a, b):
    return a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0]


def normalize(factor):
    axes, rows, degrees = factor
    closed = sum(255 << (8 * x) for x, n in degrees.items() if n == 8)
    assert all(0 < n <= 8 for n in degrees.values())
    if not closed:
        return factor
    moved = {}
    for key, row in rows.items():
        moved[key] = {}
        for mask, value in row.items():
            assert mask & closed == closed
            moved[key][mask ^ closed] = value
    return axes, moved, {x: n for x, n in degrees.items() if n < 8}


def contract(factors):
    """Unchanged capped join/choose; preserve both final integer components."""
    bind()
    pending = [normalize(f) for f in factors]
    if any(not f[1] for f in pending):
        return (0, 0), 0, 0
    result, peak, products = (1, 0), 0, 0
    while pending:
        group = [pending.pop()]
        labels, sites = set(group[0][0]), set(group[0][2])
        while True:
            neighbors = [i for i, f in enumerate(pending)
                         if labels.intersection(f[0]) or sites.intersection(f[2])]
            if not neighbors:
                break
            for i in reversed(neighbors):
                f = pending.pop(i)
                group.append(f)
                labels.update(f[0]); sites.update(f[2])
        exclusive = {leg for f in group for leg in f[0] if leg[0] == 'i'}
        peak = max(peak, *(sum(map(len, f[1].values())) for f in group))
        while len(group) > 1:
            _, i, j, degrees, opened = L.choose(group, exclusive)
            closed = sum(255 << (8 * x) for x, n in degrees.items() if n == 8)
            try:
                axes, rows, count = L.indexed_join(group[i], group[j], closed,
                                                   ROW_CAP, PAIR_CAP)
            except RuntimeError as exc:
                context = {'left_axes': group[i][0], 'right_axes': group[j][0],
                           'left_rows': sum(map(len, group[i][1].values())),
                           'right_rows': sum(map(len, group[j][1].values())),
                           'degrees': dict(degrees), 'closed_mask': closed}
                raise RuntimeError(f'{exc}; exact failing join inputs: {context}') from exc
            products += count
            if not rows:
                return (0, 0), peak, products
            peak = max(peak, sum(map(len, rows.values())))
            group[i] = axes, rows, opened
            group.pop(j)
        axes, rows, degrees = group[0]
        assert not axes and not degrees and set(rows) == {()} and set(rows[()]) == {0}
        result = cmul(result, rows[()][0])
    return result, peak, products


@cache
def haar_template(degree):
    bind()
    if degree % 2:
        return [((), {}, {})], 1
    if not degree:
        return [], 1
    divisor = L.haar_scale(degree)
    states = {(0,) * 8}
    factors = []
    for step in range(1, degree + 1):
        rows, next_states = {}, set()
        for state in sorted(states):
            for q in range(8):
                new = tuple(n + int(i == q) for i, n in enumerate(state))
                if sum(n % 2 for n in new) > degree - step:
                    continue
                key = (q, new) if step == 1 else (state, q, new)
                rows[key] = {0: (1, 0)}
                if len(rows) > ROW_CAP:
                    raise RuntimeError(f'{len(rows)} moment-chain row slots exceed cap {ROW_CAP}')
                next_states.add(new)
        axes = (('q', step - 1), ('s', step)) if step == 1 else (
            ('s', step - 1), ('q', step - 1), ('s', step))
        factors.append(bounded(axes, rows, {}))
        states = next_states
    rows = {}
    for state in sorted(states):
        weight = divisor * MOMENT(state[:4]) * MOMENT(state[4:])
        assert weight.denominator == 1
        if weight:
            rows[state,] = {0: (int(weight), 0)}
    factors.append(bounded((('s', degree),), rows, {}))
    return factors, divisor


def haar_chain(edge, legs):
    template, divisor = haar_template(len(legs))
    factors = []
    for axes, rows, degrees in template:
        moved = tuple(legs[i] if kind == 'q' else ('h', edge, i) for kind, i in axes)
        factors.append((moved, rows, degrees))
    return factors, divisor


@cache
def frame_table(site, axis, anchor, fixed):
    bind()
    rows = {}
    if fixed:
        for a in range(4):
            p = L.add(L.fixed_frame(site, axis, anchor, 0)[a],
                      L.fixed_frame(site, axis, anchor, 4)[a])
            if p:
                rows[a,] = L.sparse_int(p)
    else:
        for q in range(8):
            for a, p in enumerate(L.fixed_frame(site, axis, anchor, q)):
                if p:
                    rows[q, a] = L.sparse_int(p)
    return rows


@cache
def basis():
    bind()
    zero = (0,) * 4
    return tuple(L.diag(L.quat(tuple(int(k == q) for k in range(4))) if q < 4 else L.quat(zero),
                        L.quat(tuple(int(k + 4 == q) for k in range(4))) if q >= 4 else L.quat(zero))
                 for q in range(8))


@cache
def curvature_table(fixed):
    bind()
    rows = {}
    gs = L.diag(1, 1, -1, -1)
    blocks = {(a, b): (L.gamma[a] * L.gamma[b] - L.gamma[b] * L.gamma[a]) * gs
              for a in range(4) for b in range(4) if a != b}
    free = tuple(i for i in range(4) if not fixed[i])
    for values in product(range(8), repeat=len(free)):
        assigned = dict(zip(free, values))
        u = [L.eye(4) if fixed[i] else basis()[assigned[i]] for i in range(4)]
        h = u[3].H * u[2].H * u[1] * u[0]
        delta = h - h.H
        if delta == L.zeros(4):
            continue
        for (a, b), block in blocks.items():
            z = (delta * block).trace().expand()
            if z:
                re, im = z.as_real_imag()
                assert re.is_Integer and im.is_Integer
                rows[values + (a, b)] = {0: (int(re), int(im))}
    return bounded(tuple(range(len(free) + 2)), rows, {})[1]


def epsilon(values):
    return (-1) ** sum(a > b for i, a in enumerate(values) for b in values[i + 1:])


def assemble(component, anchors, determinant, word, tree=TREE):
    """Build a complete unintegrated word; tree is fixed before inspecting results."""
    bind()
    factors, edges, incidences = [], defaultdict(list), Counter()
    frame_count = curvature_count = serial = 0

    def internal():
        nonlocal serial
        serial += 1
        return 'i', serial

    def occurrence(edge):
        nonlocal serial
        incidences[edge] += 1
        if edge in tree:
            return None
        serial += 1
        leg = 'q', serial
        edges[edge].append(leg)
        return leg

    def frame(site, axis, anchor, index):
        nonlocal frame_count
        leg = occurrence((anchor, axis))
        axes = (index,) if leg is None else (leg, index)
        degrees = Counter((site, S.forward(site, axis)))
        factors.append(bounded(axes, frame_table(site, axis, anchor, leg is None), degrees))
        frame_count += 1

    if component is not None:
        shared = internal()
        for axis, anchor in zip(component, anchors):
            frame(0, axis, anchor, shared)
    if determinant is not None:
        site, *ds = determinant
        indices = tuple(internal() for _ in range(4))
        factors.append(bounded(indices, {p: {0: (epsilon(p), 0)}
                                         for p in permutations(range(4))}, {}))
        for axis, anchor, index in zip(range(4), ds, indices):
            frame(site, axis, anchor, index)
    for site, k, l, u, v in word:
        mu, nu = (d for d in range(4) if d not in (k, l))
        a, b = internal(), internal()
        frame(site, mu, u, a); frame(site, nu, v, b)
        physical = ((site, k), (S.forward(site, k), l),
                    (S.forward(site, l), k), (site, l))
        legs = tuple(occurrence(e) for e in physical)
        fixed = tuple(leg is None for leg in legs)
        sign = epsilon((k, l, mu, nu))
        rows = curvature_table(fixed)
        if sign == -1:
            rows = {key: {0: (-value[0][0], -value[0][1])} for key, value in rows.items()}
        factors.append(bounded(tuple(leg for leg in legs if leg is not None) + (a, b), rows, {}))
        curvature_count += 1
    assert all(n % 2 == 0 for n in incidences.values())
    degree_sum = Counter()
    for f in factors:
        degree_sum.update(f[2])
    assert dict(degree_sum) == {x: 8 for x in range(4)}
    haar_divisor = 1
    for edge, legs in sorted(edges.items()):
        hs, divisor = haar_chain(edge, tuple(legs))
        factors.extend(hs); haar_divisor *= divisor
    label_counts = Counter(leg for f in factors for leg in f[0])
    assert all(n == 2 for n in label_counts.values())
    multiplicity = prod(factorial(n) for n in Counter(word).values())
    divisor = 4 ** (frame_count + curvature_count) * haar_divisor * multiplicity
    metadata = {'frames': frame_count, 'curvature_quarters': curvature_count,
                'haar_divisor': haar_divisor, 'multiplicity_factorial': multiplicity,
                'link_degrees': [[list(e), n, e in tree] for e, n in sorted(incidences.items())],
                'factors': len(factors), 'initial_rows': sum(sum(map(len, f[1].values())) for f in factors)}
    return factors, divisor, metadata


def census_all():
    bind()
    pairs, triples = [], defaultdict(list)
    for size in (2, 3):
        for indices in combinations_with_replacement(range(len(S.TERMS)), size):
            parity, counts = M.s2_signature(indices)
            if max(counts) > 8:
                continue
            if size == 2:
                pairs.append((indices, parity, counts))
            else:
                triples[parity, counts].append(indices)
    ordered = {}
    for size in (2, 3):
        states = Counter()
        for indices in product(range(len(S.TERMS)), repeat=size):
            parity, counts = M.s2_signature(indices)
            if max(counts) <= 8:
                states[parity, counts] += 1
        ordered[size] = states
    output, receipts = {}, []
    determinants = tuple(M.determinant_terms())
    for mu in range(4):
        for nu in range(mu, 4):
            entries, ordered_count, reconstructed = [], 0, 0
            for left, right in product(S.t_terms(0, mu), S.t_terms(0, nu)):
                source_parity = left[0] ^ right[0]
                source_degrees = Counter(left[1] + right[1])
                target = tuple(8 - source_degrees[x] for x in range(4))
                for dp, dc, det in determinants:
                    for prefix, pp, pc in pairs:
                        rem = tuple(t - a - b for t, a, b in zip(target, dc, pc))
                        if min(rem) < 0:
                            continue
                        for suffix in triples.get((source_parity ^ dp ^ pp, rem), ()):
                            if prefix[-1] <= suffix[0]:
                                indices = prefix + suffix
                                mult = prod(factorial(n) for n in Counter(indices).values())
                                reconstructed += factorial(5) // mult
                                entries.append(((left[2], right[2]), det, indices))
                    for (pp, pc), n in ordered[2].items():
                        rem = tuple(t - a - b for t, a, b in zip(target, dc, pc))
                        if min(rem) >= 0:
                            ordered_count += n * ordered[3].get((source_parity ^ dp ^ pp, rem), 0)
            assert reconstructed == ordered_count
            if (mu, nu) in ((2, 2), (3, 3)):
                assert len(entries) == 192
            assert len(entries) == len(set(entries))
            output[mu, nu] = entries
            receipts.append({'component': [mu, nu], 'support': len(entries),
                             'ordered_words': ordered_count})
    return output, receipts
