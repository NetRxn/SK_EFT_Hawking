"""Preserve consumed source, streams and terminal metadata for one scientific attempt."""
from argparse import ArgumentParser
from pathlib import Path
from time import monotonic
from collections import Counter
from fractions import Fraction
from math import factorial, lcm, prod
import hashlib
import json
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
NAMES = ('leading.py', 'controls.py', 'calculate.py', 'run.py',
         'test_scientific_controls.py', 'legacy-binding.json', 'LEADING_METRIC_RESPONSE_DESIGN.md')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def readback(output, records, preparation, complete):
    """Stdlib exact traversal/arithmetic validation, without importing the producer."""
    support_bytes = (output / 'support.json').read_bytes()
    assert hashlib.sha256(support_bytes).hexdigest() == preparation['support_sha256']
    roster = json.loads(support_bytes)
    expected_components = [[mu, nu] for mu in range(4) for nu in range(mu, 4)]
    assert [r['component'] for r in roster] == expected_components
    assert [r['component'] for r in preparation['components']] == expected_components
    tree = {tuple(e) for e in preparation['tree']}
    target = [r for r in records if r['event'] in ('word-start', 'word', 'component')]
    at, results = 0, []
    z8 = Fraction(1252309350145403, 2123366400)

    def scale(degree):
        assert degree >= 0 and degree % 2 == 0
        return lcm(*(prod(range(4, 4 + left, 2)) * prod(range(4, 4 + degree - left, 2))
                     for left in range(0, degree + 1, 2)))

    for item, count in zip(roster, preparation['components']):
        component, entries = item['component'], item['entries']
        assert count['support'] == len(entries)
        sums = [Fraction(0), Fraction(0)]
        for ordinal, (anchors, det, indices) in enumerate(entries):
            expected = {'component': component, 'ordinal': ordinal, 'anchors': anchors,
                        'determinant': det, 'indices': indices}
            start, word = target[at:at + 2]
            at += 2
            assert start['event'] == 'word-start' and word['event'] == 'word'
            for key, value in expected.items():
                assert start[key] == word[key] == value
            assert word['frames'] == 16 and word['curvature_quarters'] == 5
            mult = prod(factorial(n) for n in Counter(indices).values())
            assert word['multiplicity_factorial'] == mult
            edges = word['link_degrees']
            assert len({tuple(e) for e, _, _ in edges}) == len(edges)
            assert all(fixed == (tuple(e) in tree) for e, _, fixed in edges)
            haar = prod(scale(d) for _, d, fixed in edges if not fixed)
            assert haar == word['haar_divisor']
            divisor = 4 ** 21 * haar * mult
            assert divisor == word['divisor']
            values = [Fraction(v, divisor) for v in word['raw']]
            assert len(values) == 2 and values == list(map(Fraction, word['value']))
            assert word['peak'] <= 120000
            for i in range(2):
                sums[i] += values[i]
        assert sums[1] == 0
        record = target[at]
        at += 1
        assert record['event'] == 'component' and record['component'] == component
        assert record['words'] == len(entries)
        assert Fraction(record['q_prime']) == sums[0]
        assert Fraction(record['normalized_g2_cubed_slope']) == sums[0] / z8
        results.append({k: v for k, v in record.items() if k != 'event'})
    assert at == len(target) and results == complete['results']
    assert Fraction(preparation['Z8']) == Fraction(complete['Z8']) == z8
    return results


def expired(signum, frame):
    raise TimeoutError('Scientific parent/readback absolute deadline exceeded')


def arm(deadline):
    remaining = deadline - monotonic()
    if remaining <= 0:
        raise TimeoutError('Scientific parent/readback deadline already exhausted')
    signal.setitimer(signal.ITIMER_REAL, remaining)


def main():
    parser = ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=False)
    consumed = output / 'consumed'
    consumed.mkdir()
    started = monotonic()
    parent_deadline = started + 2465
    signal.signal(signal.SIGALRM, expired)
    pins = {}
    argv = [sys.executable, '-B', str(consumed / 'calculate.py'), '--out', str(output)]
    receipt = {'argv': argv, 'exit_code': None, 'timeout': False,
               'parent_cap': 2465, 'driver_success': False}
    phase = 'source-snapshot'
    try:
        arm(parent_deadline)
        paths = [ROOT / n for n in NAMES] + sorted((ROOT / 'science').iterdir())
        for path in paths:
            if not path.is_file():
                continue
            name = path.relative_to(ROOT).as_posix()
            target = consumed / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())
            pins[name] = digest(target)
        receipt['consumed_sha256'] = pins
        phase = 'scientific-child'
        with (output / 'stdout').open('w') as out, (output / 'stderr').open('w') as err:
            try:
                receipt['exit_code'] = subprocess.run(
                    argv, stdout=out, stderr=err,
                    timeout=max(0.001, parent_deadline - monotonic())).returncode
            except subprocess.TimeoutExpired:
                receipt['timeout'] = True
        receipt['parent_seconds_before_readback'] = monotonic() - started
        if not receipt['timeout'] and receipt['exit_code'] == 0:
            phase = 'warm-clock'
            clock_path = output / 'warm-clock.json'
            assert clock_path.stat().st_size <= 4096
            clock = json.loads(clock_path.read_text())
            assert clock['warm_cap'] == 1800 and started <= clock['warm_started'] <= monotonic()
            warm_deadline = clock['warm_started'] + 1800
            arm(min(parent_deadline, warm_deadline))
        phase = 'post-child-provenance'
        receipt['source_unchanged'] = all(digest(consumed / n) == h for n, h in pins.items())
        for stream in ('stdout', 'stderr'):
            receipt[stream + '_sha256'] = digest(output / stream)
        if receipt['timeout'] or receipt['exit_code'] != 0 or not receipt['source_unchanged'] or (output / 'stderr').stat().st_size:
            raise RuntimeError('Scientific child failed; no accepted coefficient')
        phase = 'exact-readback'
        records = [json.loads(line) for line in (output / 'stdout').read_text().splitlines()]
        assert records[-1]['event'] == 'complete'
        preparation = next(r for r in records if r['event'] == 'preparation')
        assert preparation['source_sha256'] == pins and preparation['cold_seconds'] < 600
        complete = records[-1]
        assert complete['source_unchanged'] is True and len(complete['results']) == 10
        assert complete['warm_started'] == clock['warm_started']
        assert complete['warm_seconds_before_final_emission'] < 1800
        readback(output, records, preparation, complete)
        receipt['parent_seconds_with_readback'] = monotonic() - started
        receipt['whole_warm_seconds_with_readback'] = monotonic() - clock['warm_started']
        assert receipt['parent_seconds_with_readback'] < 2465
        assert receipt['whole_warm_seconds_with_readback'] < 1800
        phase = 'final-evidence'
        (output / 'author-acceptance.json').write_text(json.dumps(
            {'status': 'complete execution; independent data/scientific acceptance still required',
             'results': complete['results'],
             'whole_warm_seconds_with_parent_readback': receipt['whole_warm_seconds_with_readback']},
            indent=2, sort_keys=True) + '\n')
        receipt['driver_success'] = True
        (output / 'exit.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
        assert monotonic() < min(parent_deadline, warm_deadline)
        print(json.dumps({'output': str(output), 'exit': receipt['exit_code'], 'independent_review': 'owed'}), flush=True)
        assert monotonic() < min(parent_deadline, warm_deadline)
    except BaseException as exc:
        signal.setitimer(signal.ITIMER_REAL, 0)
        receipt['driver_success'] = False
        receipt['driver_failure'] = {'phase': phase, 'type': type(exc).__name__, 'message': str(exc)}
        receipt['timeout'] = receipt['timeout'] or isinstance(exc, TimeoutError)
        receipt['parent_seconds_on_failure'] = monotonic() - started
        for stream in ('stdout', 'stderr'):
            if (output / stream).exists():
                receipt[stream + '_sha256'] = digest(output / stream)
        if (output / 'author-acceptance.json').exists():
            (output / 'author-acceptance.json').replace(output / 'author-acceptance-rejected.json')
        (output / 'exit.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    main()
