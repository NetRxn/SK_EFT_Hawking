"""Frozen source-exact scientific function transport; see legacy-binding.json."""
from collections import Counter, defaultdict
from functools import cache
from itertools import combinations, product
from math import comb, prod, lcm
from l1_direct_b_haar import R, I, eye, zeros, diag, pauli, gamma, bilinear, add, scale, wedge
from l1_interacting_support import forward

bases=tuple((tuple(int(i==k) for i in range(4)),
             tuple(int(i+4==k) for i in range(4))) for k in range(8))

def quat(q):
    return q[0]*eye(2)-I*sum((p*x for p,x in zip(pauli,q[1:])),zeros(2))


def adj(q):
    return (q[0],*(-x for x in q[1:]))


@cache
def fixed_frame(site,axis,link_site,coordinate):
    left,right=bases[coordinate]
    U=diag(quat(left),quat(right));Ud=diag(quat(adj(left)),quat(adj(right)))
    end=forward(site,axis)
    if end==site:
        d=Ud-U
        return tuple(bilinear(g*d+d*g,site,site) for g in gamma)
    if link_site==site:
        return tuple(add(bilinear(g*Ud,site,end),scale(bilinear(U*g,end,site),-1)) for g in gamma)
    assert link_site==end
    return tuple(add(bilinear(Ud*g,end,site),scale(bilinear(g*U,site,end),-1)) for g in gamma)


def sparse_int(poly):
    ans={}
    for mask,value in poly.items():
        assert value.is_ground
        z=value.const()
        ans[mask]=(int(z.x),int(z.y))
    return ans


def indexed_join(left, right, closed, row_cap, pair_cap):
    """Join exact gamma labels and closing-byte complements before multiplying."""
    axes, lr, _ = left
    other, rr, _ = right
    shared = tuple(label for label in axes if label in other)
    ai = tuple(axes.index(x) for x in shared)
    bi = tuple(other.index(x) for x in shared)
    au = tuple(i for i, x in enumerate(axes) if x not in shared)
    bu = tuple(i for i, x in enumerate(other) if x not in shared)
    out_axes = tuple(axes[i] for i in au) + tuple(other[i] for i in bu)
    table = defaultdict(list)
    for key, row in rr.items():
        label = tuple(key[i] for i in bi)
        tail = tuple(key[i] for i in bu)
        for mask, (r, i) in row.items():
            table[label, mask & closed].append(
                (tail, mask, preceding_parity(mask), r, i)
            )
    count = 0
    result = defaultdict(dict)
    allocated = 0
    for key, row in lr.items():
        label = tuple(key[i] for i in ai)
        tail = tuple(key[i] for i in au)
        for a, (r, i) in row.items():
            for rhs, b, p, s, j in table.get((label, closed ^ (a & closed)), ()):
                if a & b:
                    continue
                count += 1
                if count > pair_cap:
                    raise RuntimeError(
                        f"{count} exact compatible products exceed cap {pair_cap}"
                    )
                dest = tail + rhs
                output = result[dest]
                mask = (a | b) ^ closed
                sign = 1 - 2 * ((a & p).bit_count() & 1)
                if mask not in output:
                    allocated += 1
                    if allocated > row_cap:
                        raise RuntimeError(
                            f"{allocated} live row slots exceed cap {row_cap}"
                        )
                re, im = output.get(mask, (0, 0))
                output[mask] = re + sign * (r * s - i * j), im + sign * (r * j + i * s)
    rows = {k: {m: v for m, v in row.items() if any(v)} for k, row in result.items()}
    return out_axes, {k: row for k, row in rows.items() if row}, count


def choose(factors, exclusive):
    candidates = []
    for i, j in combinations(range(len(factors)), 2):
        a, b = factors[i], factors[j]
        labels, other = set(a[0]), set(b[0])
        if not labels & other and not a[2].keys() & b[2].keys():
            continue
        degrees = Counter(a[2])
        degrees.update(b[2])
        assert all(d <= 8 for d in degrees.values())
        opened = {x: d for x, d in degrees.items() if d < 8}
        bound = prod(4 if label in exclusive else 10 for label in labels ^ other)
        bound *= prod(comb(8, d) for d in opened.values())
        candidates.append((bound, i, j, degrees, opened))
    return min(candidates)


def preceding_parity(mask):
    # Exclusive prefix parity of the right factor at every generator.
    for shift in (1, 2, 4, 8, 16, 32, 64):
        mask ^= mask << shift
    return mask << 1


def haar_scale(degree):
    """Common denominator for normalized Spin(4) moments on a single link."""
    def sphere_scale(n):
        return prod(range(4, 4 + n, 2))

    return lcm(*(sphere_scale(left) * sphere_scale(degree - left)
                 for left in range(0, degree + 1, 2)))

