"""Independent tiny exact controls; no target word is evaluated here."""
from fractions import Fraction
from time import monotonic
import signal
import unittest

from leading import bind, contract, haar_chain
import run as scientific_driver


class ExactControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        bind()

    def scalar_moment(self, coordinates):
        legs = tuple(('q', i) for i in range(len(coordinates)))
        factors, divisor = haar_chain(('test',), legs)
        factors += [((leg,), {(q,): {0: (1, 0)}}, {})
                    for leg, q in zip(legs, coordinates)]
        value, _, _ = contract(factors)
        self.assertEqual(value[1], 0)
        return Fraction(value[0], divisor)

    def test_scaled_second_moment(self):
        self.assertEqual(self.scalar_moment((0, 0)), Fraction(1, 4))
        self.assertEqual(self.scalar_moment((0, 1)), 0)

    def test_two_independent_chiral_spheres(self):
        self.assertEqual(self.scalar_moment((0, 0, 4, 4)), Fraction(1, 16))
        self.assertEqual(self.scalar_moment((0, 0, 1, 1)), Fraction(1, 24))

    def test_eighth_degree(self):
        self.assertEqual(self.scalar_moment((0,) * 6), Fraction(5, 64))
        self.assertEqual(self.scalar_moment((0,) * 8), Fraction(7, 128))
        self.assertEqual(self.scalar_moment((0,) * 4 + (4,) * 4), Fraction(1, 64))
        self.assertEqual(self.scalar_moment((0, 0, 1, 1, 4, 4, 5, 5)), Fraction(1, 576))

    def test_wedge_sign_closure_and_imaginary_preservation(self):
        factors = [
            ((), {(): {(1 << 0) | (1 << 2): (1, 0),
                       (1 << 0) | (1 << 1): (1, 0)}}, {0: 2}),
            ((), {(): {(1 << 1) | (1 << 3): (0, 1)}}, {0: 2}),
            ((), {(): {(1 << 4) | (1 << 5): (1, 0)}}, {0: 2}),
            ((), {(): {(1 << 6) | (1 << 7): (1, 0)}}, {0: 2}),
        ]
        value, _, _ = contract(factors)
        self.assertEqual(value, (0, -1))

    def test_parent_absolute_deadline_interrupts_cpu_work(self):
        previous = signal.getsignal(signal.SIGALRM)
        try:
            signal.signal(signal.SIGALRM, scientific_driver.expired)
            with self.assertRaises(TimeoutError):
                scientific_driver.arm(monotonic() + 0.02)
                while True:
                    pass
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous)


if __name__ == '__main__':
    unittest.main()
