"""Independent source/action controls for the full leading metric calculation."""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations_with_replacement, permutations, product
from math import prod
from pathlib import Path
import json
import subprocess
import sys

import leading as C


def addpairs(dst, row, weight=1):
    for mask, (r, i) in row.items():
        a, b = dst.get(mask, (0, 0))
        dst[mask] = a + weight * r, b + weight * i
    return {mask: value for mask, value in dst.items() if any(value)}


def fixtures(left_seed, right_seed, tree):
    L = C.L
    matrices, coordinates = {}, {}
    for site, axis in product(range(4), repeat=2):
        edge = site, axis
        if edge in tree:
            qs = (1, 0, 0, 0, 1, 0, 0, 0)
        else:
            l = (left_seed + site + axis) % 4
            r = (right_seed + 2 * site + 3 * axis) % 4
            qs = tuple(int(j == l) for j in range(4)) + tuple(int(j == r) for j in range(4))
        matrices[edge] = L.diag(L.quat(qs[:4]), L.quat(qs[4:]))
        coordinates[edge] = qs
    return matrices, coordinates


def frames():
    L, checked = C.L, 0
    for tree in (frozenset(), C.TREE):
        for sl, sr in product(range(4), repeat=2):
            matrices, coordinates = fixtures(sl, sr, tree)
            for site, axis in product(range(4), repeat=2):
                y = C.S.forward(site, axis)
                u, v = matrices[site, axis], matrices[y, axis]
                for a, gamma in enumerate(L.gamma):
                    direct = L.add(L.bilinear(gamma * u.H, site, y),
                                   L.scale(L.bilinear(u * gamma, y, site), -1),
                                   L.scale(L.bilinear(gamma * v, site, y), -1),
                                   L.bilinear(v.H * gamma, y, site))
                    assembled = {}
                    for _, _, anchor in C.S.t_terms(site, axis):
                        fixed = (anchor, axis) in tree
                        table = C.frame_table(site, axis, anchor, fixed)
                        if fixed:
                            assembled = addpairs(assembled, table.get((a,), {}))
                        else:
                            for q, weight in enumerate(coordinates[anchor, axis]):
                                if weight:
                                    assembled = addpairs(assembled, table.get((q, a), {}), weight)
                    assert assembled == L.sparse_int(direct)
                    checked += 1
    return checked


def exact_pair(z):
    re, im = z.expand().as_real_imag()
    return F(int(re.p), int(re.q)), F(int(im.p), int(im.q))


def curvature():
    L = C.L
    gam5 = L.diag(1, 1, -1, -1)
    tv = [[2 + 3 * mu - a + 2 * int(mu == a) for a in range(4)] for mu in range(4)]
    tm = [sum((value * g for value, g in zip(row, L.gamma)), L.zeros(4)) for row in tv]
    checks, poison_differences = 0, 0
    for tree in (frozenset(), C.TREE):
        qs, matrices = {}, {}
        for site, axis in product(range(4), repeat=2):
            edge = site, axis
            ch = []
            for chirality in range(2):
                v = (site + 1, axis + 2, chirality + 1)
                norm = sum(x * x for x in v)
                ch += [F(1 - norm, 1 + norm), *(F(2 * x, 1 + norm) for x in v)]
            qs[edge] = tuple(ch) if edge not in tree else (1, 0, 0, 0, 1, 0, 0, 0)
            matrices[edge] = L.diag(L.quat(qs[edge][:4]), L.quat(qs[edge][4:]))

        def hol(site, k, l, closed):
            a, b = matrices[site, k], matrices[C.S.forward(site, k), l]
            c, d = matrices[C.S.forward(site, l), k], matrices[site, l]
            return d.H * c.H * b * a if closed else a * b * c.H * d.H

        for site in range(4):
            direct = sum((C.epsilon(p) * (hol(site, p[0], p[1], True) * tm[p[2]] * tm[p[3]] * gam5).trace()
                          for p in permutations(range(4))), L.I * 0) / 4
            poison = sum((C.epsilon(p) * (hol(site, p[0], p[1], False) * tm[p[2]] * tm[p[3]] * gam5).trace()
                          for p in permutations(range(4))), L.I * 0) / 4
            result = [F(0), F(0)]
            for k in range(4):
                for l in range(k + 1, 4):
                    mu, nu = (d for d in range(4) if d not in (k, l))
                    edges = ((site, k), (C.S.forward(site, k), l),
                             (C.S.forward(site, l), k), (site, l))
                    fixed = tuple(e in tree for e in edges)
                    free = tuple(e for e in edges if e not in tree)
                    for key, polynomial in C.curvature_table(fixed).items():
                        *coords, a, b = key
                        weight = F(C.epsilon((k, l, mu, nu)) * tv[mu][a] * tv[nu][b], 4)
                        weight *= prod_values(qs[e][q] for e, q in zip(free, coords))
                        r, i = polynomial[0]
                        result[0] += weight * r; result[1] += weight * i
            assert tuple(result) == exact_pair(direct)
            poison_differences += exact_pair(direct) != exact_pair(poison)
            checks += 1
    assert poison_differences
    return {'full24_checks': checks, 'literal_order_poison_differences': poison_differences}


def prod_values(values):
    result = 1
    for value in values:
        result *= value
    return result


def moments():
    def sphere(counts):
        if any(n % 2 for n in counts):
            return F(0)
        return F(prod(prod(range(1, n, 2)) for n in counts),
                 prod(range(4, 4 + sum(counts), 2)))

    def sequence(qs):
        template, divisor = C.haar_template(len(qs))
        assert divisor == {2: 4, 4: 48, 6: 192, 8: 11520}[len(qs)]
        state, raw = (0,) * 8, 1
        for i, q in enumerate(qs):
            new = tuple(n + int(j == q) for j, n in enumerate(state))
            key = (q, new) if i == 0 else (state, q, new)
            row = template[i][1].get(key)
            if not row:
                raw = 0
                break
            assert row == {0: (1, 0)}
            state = new
        if raw:
            r, im = template[-1][1].get((state,), {0: (0, 0)})[0]
            assert im == 0
            raw *= r
        counts = tuple(qs.count(j) for j in range(8))
        expected = sphere(counts[:4]) * sphere(counts[4:])
        assert F(raw, divisor) == expected

    comparisons = 0
    for degree in (2, 4):
        for qs in product(range(8), repeat=degree):
            sequence(qs); comparisons += 1
    multisets, nonzero = 0, 0
    for qs in combinations_with_replacement(range(8), 8):
        sequence(qs); sequence(tuple(reversed(qs)))
        comparisons += 2; multisets += 1
        nonzero += all(qs.count(q) % 2 == 0 for q in range(8))
    assert multisets == 6435 and nonzero == 330
    return {'sequence_comparisons': comparisons, 'degree8_multisets': multisets,
            'degree8_nonzero_multisets': nonzero, 'degree8_zero_multisets': multisets - nonzero}


def determinant(directory):
    """Compare predetermined rows with the unchanged accepted dual-lift C++ source."""
    source = C.ROOT / 'science/l1_mixed_g1_determinant_tensor.cpp'
    binary, output = directory / 'determinant-control', directory / 'determinant-control.rows'
    with (directory / 'determinant-compile.stderr').open('w') as err:
        subprocess.run(['c++', '-std=c++20', '-O3', str(source), '-o', str(binary)],
                       stdout=subprocess.DEVNULL, stderr=err, check=True, timeout=90)
    with output.open('w') as out, (directory / 'determinant-control.stderr').open('w') as err:
        subprocess.run([str(binary)], stdout=out, stderr=err, check=True, timeout=240)
    rows = sorted(tuple(map(int, line.split())) for line in output.read_text().splitlines())
    assert len(rows) == 50176 and all(len(row) == 4 for row in rows)
    assert max(max(abs(row[2]), abs(row[3])) for row in rows) == 128
    assert Counter(row[0] >> 12 for row in rows) == {0: 12544, 1: 12544, 2: 12544, 3: 12544}
    selected = [rows[i] for i in (0, 5000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 50175)]
    for packed, mask, real, imag in selected:
        mode = packed >> 12
        coords = tuple((packed >> shift) & 7 for shift in (9, 6, 3, 0))
        anchors = (2 if mode & 2 else 3, 1 if mode & 1 else 3, 3, 3)
        indices = tuple(('i', a) for a in range(4))
        factors = [(indices, {p: {0: (C.epsilon(p), 0)} for p in permutations(range(4))}, {})]
        degrees = Counter()
        for axis, (anchor, q) in enumerate(zip(anchors, coords)):
            leg = 'q', axis
            degree = Counter((3, C.S.forward(3, axis)))
            degrees.update(degree)
            factors.append(((leg, indices[axis]), C.frame_table(3, axis, anchor, False), dict(degree)))
            factors.append(((leg,), {(q,): {0: (1, 0)}}, {}))
        complement = ((1 << 32) - 1) ^ mask
        factors.append(((), {(): {complement: (1, 0)}}, {x: 8 - degrees[x] for x in range(4) if degrees[x] < 8}))
        result, _, _ = C.contract(factors)
        sign = (-1) ** sum((mask >> a & 1) and (complement >> b & 1)
                          for a in range(32) for b in range(a))
        assert result == (sign * real, sign * imag)
    return {'cpp_rows': len(rows), 'independent_row_comparisons': len(selected), 'maximum_component': 128}


def run(directory, emit):
    directory.mkdir(exist_ok=True)
    C.bind()
    # These controls are individually gated; no target data runs on a failed assertion.
    with (directory / 'tiny-tests.stdout').open('w') as out, (directory / 'tiny-tests.stderr').open('w') as err:
        subprocess.run([sys.executable, '-B', str(C.ROOT / 'test_scientific_controls.py')],
                       stdout=out, stderr=err, check=True, timeout=120)
    emit({'event': 'control-tiny-tests', 'passed': True})
    emit({'event': 'control-haar-moments', **moments()})
    emit({'event': 'control-frames', 'comparisons': frames()})
    emit({'event': 'control-curvature', **curvature()})
    emit({'event': 'control-determinant', **determinant(directory)})
    word = tuple((x, 0, 1, x, x) for x in range(4) for _ in range(2))
    factors, divisor, metadata = C.assemble(None, None, None, word)
    raw, peak, products = C.contract(factors)
    assert raw[1] == 0
    value = F(raw[0], divisor)
    assert value == 104978
    emit({'event': 'control-normalization-word', 'value': str(value),
          'raw': raw, 'divisor': divisor, 'peak': peak, 'products': products, **metadata})
