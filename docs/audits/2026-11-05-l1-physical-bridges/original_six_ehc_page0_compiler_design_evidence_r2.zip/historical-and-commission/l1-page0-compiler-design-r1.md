# Original page-0 rational compiler implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task AFTER ROOT commissions implementation. No scientific execution is authorized by this design.

**Goal:** Construct the COMPLETE original page-0 coefficient tensor, with exact source-separated arrays, fixed rational duals and provable finite arithmetic bounds, preserving the original aggregate.

**Architecture:** Compile the original six quarter-coframes, two outside V pairs and two original curvature traces into signed epsilon/delta matching graphs. Use the original quaternion completeness identities to remove internal-vector sums, then evaluate degree-two binary-spin graphs by their two possible cycle seeds. Extract coefficients in the explicit integral eight-element endpoint bases with diagonal Gram duals.

**Tech stack:** Proposed isolated one-off Python scientific package, integer Gaussian arithmetic and fixed-width artifact serialization. No dependency, harness, controller, Lean slot, production formula module or repository test-infrastructure change is proposed. No program has been written or run.

**Spec:** Exact mathematical design in `/private/tmp/l1-page0-rational-compiler-math-design-r1.md`; original-source/test specification in `/private/tmp/l1-page0-compiler-source-test-design-r1.md`; optional full-core ordering in `/private/tmp/l1-factorized-w-complete-core-ordering-r1.md`. These three immutable reports travel with this plan. This lead plan fixes the combined interface and priority between their conventions; independent ACTUAL review is required.

## Global constraints

- Source6830c734218ed094f632092bd372ad9a263a2711; parentpublicationROOT01a13f67/L1-physical-observable-boundary. Executor01a1ac65 alone writes primary LAB_NOTEBOOK/INDEX; ROOT owns queue/roadmaps/runtime/intake/integration/gates/final human publication approval.
- Retain h12,6=8*3^8*2^-40 sum W*Ccore, both original source endpoint sums, twenty quarter-coframes/six EHC/four D/twenty independent core anchors, all original phases/top and both kernels/contact obligations. This package computes one complete conditional page, not the scalar aggregate.
- Design/independent review only. All preceding scientific admissions are SPENT. No import/help/test/evaluator/scientific table/mask/Haar/network run, code implementation or resource request follows from a continuity snapshot.
- Use canonical representative copy coordinates C01,C02,C03 and exact chi-dependent complement reconstruction. No Hodge input half, full-Z substitution, extra2^6, source average, free-edge1/8 or aggregate factor inside page0.
- Numerical endpoint basis normalization is the math report's INTEGRAL tilde basis, not the prospective source report's abstract normalized scalar-type names. Same-chi order: tildeF_L11,12,22; tildeF_R11,12,22; own-triplet path; opposite-triplet path. Different-chi order: four scalar-side vector flavours11,12,21,22, then the four(1,1)-side flavours in that order.
- All side internal labels and both central fundamental indices survive through exact basis reconstruction. Full ordered A,B basis domain1792 equals packed symmetric domain1120 ONLY with off-diagonal multiplicity2. Auxiliary conjugate Gram extraction is algebraic and does not change the original top or physical norm.

## Review focus

1. Endpoint gamma placement can make a source term different from its opposite endpoint. Preserve Q0/Q4 separately and check both against an independent source oracle.
2. Copy representatives, unnormalized Hodge sums and ordered Z have different conversion factors. Pin their exact identities and nonzero local canaries.
3. Odd-overlap, site/category sorting and dagger pullbacks can change signs. Verify original-site top and exact source words before reducing matching graphs.
4. Structural zeros do not imply surviving coefficients are nonzero; mutation detection needs nonzero LOCAL canaries even if the entire page vanishes.
5. A graph-count or output-byte ceiling does not bound Python/RSS/walltime or the independent oracle cost. Count compiler arithmetic and all future tests separately; no fit is claimed.

## Files and responsibilities if implementation is later commissioned

Prepare a NEW exclusive private package directory; exact invocation/output destination and hashes will be frozen only after code exists and passes independent static/science review. Proposed names within that directory:

- `page0_compiler.py`: frozen source descriptors, integral bases/dual certificates, canonical branch compiler, matching evaluator, three-array producer and exact artifact reader.
- `PAGE0_COMPILER_SPEC.json`: exact source/body pins, basis/order/normalization version, counts/bounds, artifact contract and refusal/completion rules.
- `test_page0_compiler.py`: source-bound primitive, basis, branch, mutation and complete-artifact tests. This is a scientific package companion, not new repository test infrastructure.
- `README.md`: exact future command, test scope and conditional scientific acceptance boundary.

No new code, invocation, resource profile or output admission is approved here.

## Fixed interfaces and output

`build_integral_basis(face_pair, endpoint)` returns the eight source-bound polynomial intertwiners in the fixed order, their diagonal Gram norms and exact reconstruction/dual maps, with all actual endpoint epsilon/transposes retained.

`iter_source_branches(source_endpoint)` emits the source-bound typed rank-channel grammar:2560 branches per source,5120 total. `expand_matchings(branch)` includes the rational P4 channel expansions,4096 terms per source/8192 total. No generated support result is assumed.

`compile_matching(branch, representatives, endpoint_basis_terms)` emits only scalar Gaussian weight and a degree-two signed binary-index graph. It uses the two full commutators, original category/top sign and quaternion completeness rules in the math report, with no hidden magnetic-index loop.

`evaluate_matching(graph)` returns the EXACT Gaussian integer sum by multiplying/summing both seed values on each closed cycle. Graph size has the math report's128-factor ceiling. No floating arithmetic or generalized tensor engine is needed.

`compile_page0()` returns arrays named `Q0`, `Q4`, `sum`, each FULL length2304, common denominator D=2^32*3^6. Flat index is `((((2*chi0+chi4)*3+r0)*3+r4)*8+i)*8+j`, with chiL0/chiR1, representativesr0/r4=0,1,2 and endpoint labels0..7. Store every exact zero. `sum[k]=Q0[k]+Q4[k]` for ALL2304 entries.

Each complex numerator has signed256-bit real and imaginary components:32 little-endian two's-complement bytes apiece,64B/coordinate. Each array147456B; all three442368B numeric payload. Common denominator and ordering version are explicit metadata; never infer a denominator or drop imaginary parts. Arbitrary Python integers while accumulating, exact range checks before serialization, no wrapping/clipping. Numeric payload excludes manifests, program/input bodies, buffers, indices and interpreter/RSS.

Source-separated arithmetic does not triple the matching workload. The2^23 graph ceiling covers both source endpoints jointly; the final array sum adds2304 Gaussian additions/4608 component additions. Each source must include864 structural zeros and the sum576, verified from typed slots rather than a stored favorable mask. All remaining entries may also vanish.

## Fixed matching records and exact integer schedule

`SourceBranch` is the ordered tuple `(chi0,chi4,source_endpoint,source_allocation,left_case,left_rank,right_case,right_rank,direction_bits)`. Direction bits use the labelled slot order T10^X,T10^Y,T50^Z,T50^W,sourceT1,sourceT2, as in the source report. The math report gathers commuting compact occurrences source-first before side/curvature occurrences; this is a SEPARATE moment-leg ordering and does not reorder direction-bit labels or original odd bilinear words. Cases/ranks are those of the source/math grammar; source endpoint is0 or4, direction_bits is0..63. No unordered duplicate suppression is permitted.

A compiled graph has a source/output key, a Gaussian-integer `weight`, named binary-spin vertices and lexicographically identified monomial edges. An edge is `(u,v,flip,phase0,phase1)` meaning `x_v=x_u XOR flip` and edge value `i^(phase0)` when x_u=0 or `i^(phase1)` when x_u=1. Phases are0..3. A reversed traversal must recover x_u before evaluating that original directed phase; it must not assume epsilon symmetry. Every vertex has degree2, counting both ends of a self-loop. Empty graph contributes1; a delta self-loop contributes2 and an epsilon self-loop0. Any surviving open/branching vertex is a compiler error, not an invitation to silently call a generic tensor evaluator.

For each unvisited cycle take the smallest vertex/edge ID, propagate EACH of its two seed values, and multiply the recorded edge phases. An inconsistent closing seed contributes0. Sum the two consistent seed products and multiply this factor into the other cycle factors and `weight`. This is the exact component sum for a closed degree-two graph, including signs and zero traces.

Use one common integer schedule. D=2^32*3^6 equals `4^6 *4 *576 *576^2`. For a term the denominator is six coframe quarters, the TWO normalized curvature commutators, the product of actual P2/P4 rational weights, and the two declared basis norms. The Haar denominator divides576 and each norm divides576; their product therefore divides D. Compute exact integer `D/term_denominator` and multiply the original Gaussian source signs/phases, completeness2^k, expanded moment/basis coefficients and directed graph sum. No floating value, per-term approximate division or unrecorded basis normalization is allowed. This schedule is intentionally overcleared and requires no per-cell rational reduction.

Result archive proposal: exactly `Q0.i256le`, `Q4.i256le`, `sum.i256le` and `MANIFEST.json`. The three bodies have the fixed sizes above; manifest records schema `l1-page0-rational/v1`, exact source/program/spec/input pins, basis/order version, denominator exponents{2:32,3:6}, all body byte counts/SHA256, source-separated branch/matching/graph counters, all range/zero/array-sum checks and explicit completion/refusal status. A refused or partial artifact cannot carry completed status. The proposed manifest bound65536B and total ZIP_STORED bound1MiB safely exceed442368B numeric payload plus four-member overhead; these are design guards, not an accepted execution profile. Readback requires the exact member set, CRC, all hashes, unique labels, full ranges and source-sum identity. No artifact has been generated.

## Complete scientific cost and width contract

The exact math report freezes at most2^23 matching graphs across ALL coordinates/source endpoints, at most128 two-leg factors per graph, and a conservative2^18 bounded-width arithmetic/index operation charge per leaf. Explicit basis/Gram/dual certificate setup costs at most2^33 and source/output setup and sum at most2^20. Thus the complete scientific operation envelope is2^41+2^33+2^20, excluding separately bounded external I/O/hash/codec/tool overhead. This is a very large conservative ceiling, not timing, machine instructions or a claim that any previous resource profile fits. The factor grammar totals92 before the safe128 cap; vector completeness cannot increase it. Optional basis storage114688B plus4096B typed graph workspace and442368B arrays gives561152B typed numeric/workspace data, excluding all interpreter/allocator/manifest/index overhead and RSS.

Every common-denominator numerator term is bounded by the cycle factor2^128, completeness2^9, Haar integer weight16 and dual weight1296. Basis/moment symmetrizations are explicitly expanded in the graph roster; no uncharged coefficient remains. All matching-leaf prefix sums and final/source-sum components are below2^175, so signed256 checks cover intermediates as well as serialized outputs. The math report's exact proofs, rather than a final cancellation assumption, govern these bounds.

Current raw report pins (all manual, no scientific execution):

- Mathematical compiler33882B SHA256547549bd17d1a77f3d0aec76e115d9ec48f60786e85b19894c5734d7c32385f6.
- Source/test design20734B SHA256dbed26a344ed16e58e818fd5c41463ddcf24b07eaf8607ff02a42d0a2d0ccf6d.
- Optional factorized-G ordering16913B SHA25607d20c021bbc1c1b22453a8ec6f7cc406a6598b6ece15ddebeb4862a33cef5ef.
- Independent prospective oracle-bound audit9039B SHA2569d4e61969b89a6d3c28362ee7dff9af186e2a94756f1c656da881703b343eeaf. Its acceptance is conditional on the explicit diagonal-Gram/norm-divisibility facts now supplied by the mathematical basis; it is not an ACTUAL review of that basis.

The oracle auditor read the original3620B last-section text SHA2561f7c4a0a9a6dff53e9130df3ab8cfc219dd8bdf52fd7f812d54b8d87956c57b3. That exact section is preserved separately. The combined plan clarifies the required fact that EVERY norm divides576; minimum norm16 alone would not suffice. Fresh ACTUAL reviews must read the complete current combined plan and all source reports, not infer acceptance from the prospective audit.

## Implementation tasks and acceptance checks

### Task1 — Source and integral-basis certificates

- [ ] Freeze the six literal quarter T factors, both original H words, both source terms, original-site/field conversion and representative-copy reconstruction exactly as the source report specifies.
- [ ] Implement the explicit integral epsilon/q formulas and exact Gram duals from the math report, including separate unequal(L,R)/(R,L) endpoint pullbacks. No unspecified CG/pivot routine.
- [ ] Test every8x8 Gram entry: same-chi diagonal32,16,32,32,16,32,48,576; different-chi diagonal16,16,16,16,576,576,576,576. All off-diagonals zero; check D*B=I, complete basis reconstruction and1792-full/1120-packed equivalence.
- [ ] Pin the quaternion completeness/transpose/conjugate/epsilon identities coefficientwise, and representative-vs-Hodge-sum/full-Z factors with the original nonzero192 control. A basis/copy normalization mismatch must stop the package.

### Task2 — Complete grammar and graph evaluator

- [ ] Implement the displayed5120 grammar, source-separated2560/2560, and8192 expanded matching roster, without selecting a favorable chirality/source/copy entry.
- [ ] Independently test the broader14848/pre-exterior grammar and the original parity/source/top equations; every discarded branch requires its proved odd/top constraint, not a hardcoded zero answer.
- [ ] Implement the math report's completeness replacements and exact degree-two graph cycles, enforcing factor/edge bounds and exact original signs. Validate graph results against direct binary-index sums on all primitive graph classes used by the compiler, including zero and complex phases.
- [ ] Track started/completed branches, matching counts and emitted graph attempts; reject any counter/descriptor/bound disagreement as incomplete. The2^23 graph ceiling is a prospective upper bound, not an expected exact count or measured support.

### Task3 — Complete page arrays and independent scientific checks

- [ ] Produce ALL2304 coefficients for EACH source and their exact sum. Enforce typed864/864/576 zero obligations and all copy/chirality labels, without declaring other coordinates nonzero.
- [ ] Test source schema and the exact isolated canaries in the source report: wrong-central-dagger F02+2/-2, source-edge endpoint+1/8 versus1/4/0 mutations, ordered-Z192/384, Hodge2x versusx and double4x, jointP4 value1/3 versus false independentP2 zero, mixed-physical-1/8 versus same-endpoint kernel, and all original quarters/world/gamma5 signs.
- [ ] Retain the independent complete oracle specification: rational24-cell Haar moments plus tagged20-generator Pfaffian and formal central matrix-unit probes. Compare Q0,Q4,sum in all2304 labels when a separately reviewed, bounded oracle implementation is admitted. An exact local quaternion-moment alternative may be chosen only with its own complete factorization/cost proof.
- [ ] Record oracle costs separately. The naive12-group quadrature already needs24^12 evaluations per literal probe; combining it with45158400 raw magnetic cells and a finite tagged-Pfaffian evaluator is an explicit huge bound, not an eligible run. Full oracle equality is NOT claimed completed or inexpensive. Independent proof of the complete compiler and its primitive/source conformance does not invent a measured end-to-end oracle result.

### Task4 — Artifact, static review and later execution boundary

- [ ] Freeze exact code/spec/package hashes and all original body pins; check source/candidate continuity and a new exclusive output path. Include the graph/width bound proofs and exact source/core scope in the package.
- [ ] Test artifact roundtrip at all three2304-element arrays: exact byte lengths/order/denominator, all-zero values, signed boundaries, truncation, overflow, wrongversion/labels/duplicate or missing payload, checksum/counter mismatch and partial/refused output. Invalid/incomplete output is never a page certificate or zero result.
- [ ] Obtain fresh independent mathematics, original-source and static code reviews. Tests themselves are scientific execution and require ROOT's explicit exact-command admission; this plan does not grant it.
- [ ] Only then propose a concrete guarded command/profile to ROOT, including all test costs and the chosen actual oracle scope. Time/RSS/limb-cost, completion/readback and independent actual-output review remain additional gates. No retry, enlarged cap or helper run follows automatically from refusal.

## Optional full-core ordering and precise residual boundary

The separate ordering report retains SAME signed kappa/lambda across BOTH endpoint triples, joins page0 then page1, and compiles the central source tensor once per six-face assignment before the copy joins. Its central forced-chirality refinement leaves rank-product sum100 over all64 assignments, without dropping source choices. The primary factorized-G post-input ordering ceiling is85320272257 Q(i) products, with1792656 live scalar coordinates before compiler/metadata/limb overhead. A rigorously equivalent compiled-W variant is slightly cheaper and is not substituted for the requested G-factorized primary tree.

This is a conditional ordering result, NOT a complete-core cost qualification: page1/page3 and endpoint-closure compilers remain uncosted. The report exposes180781056 endpoint-vector input coefficient slots; their generation is not one arithmetic operation per slot. The complete cost is the page/closure compiler bills PLUS the displayed assembly ceiling, plus exact arithmetic/bookkeeping. No runtime request or complete-core fit can rest on the conditional number. All adverse original tests remain binding. The full aggregate value/sign/nonzero, physical TT/positive boundary-product-adjoint-seam/causal transfer, matter/transport/calibration/B3 and limits stay OPEN.

## Frozen literal end-to-end oracle and adverse cost

For completeness, the default independent full oracle is the deliberately literal route below. It is specified rather than silently replaced by a cheaper correlated compiler. An optimization would be a NEW design/review, not an implicit choice here.

1. Visit both source endpoints separately and every45158400 raw magnetic probe of the locked page (all four face pairs/nine representative pairs/two hub masks/two central entry pairs/two symmetric side pairs). Restore packed-side off-diagonal multiplicities exactly for subsequent dual projection.
2. For each probe, evaluate the original expression at the Cartesian product of the24-cell quadrature for ALL12 independent chiral noncentral anchor groups. Do not share anchors, set U=V or import the main parity grammar. Each group has degree at most4; the source report's second/fourth/odd moment proof certifies this quadrature.
3. Sum the four outside curvature vector labels and common source gamma label explicitly: at most4^5 choices. Extract the product of ten literal bilinears by10-tag polarization: sum over the2^10 tag subsets with sign(-1)^(10-|S|), using Pf(sum_(f in S) A_f). Homogeneous degree10 ensures that exactly the all-ten-tag coefficient survives. The source report's theta^t A theta/2 convention fixes matrix signs and avoids10!.
4. Evaluate EACH20x20 Pfaffian independently by lexicographic perfect matchings, with its standard permutation sign and ten entry products. There are19!! matchings; a safe400*19!! elementary Gaussian-integer operation ceiling covers products, parity and accumulation without any pivot assumptions. This is an exterior/Pfaffian oracle, not the main binary-spin cycle implementation.
5. Accumulate quadrature weights, reconstruct the full magnetic tensor and apply the explicitly frozen dual independently to obtain ALL2304 coordinates for Q0 and Q4; check every value and their sum. No random subset, favorable entry or norm-only check replaces this comparison.

A complete literal arithmetic ceiling BEFORE the final dual projection is therefore

2*45158400*24^12*4^5*2^10*400*(19!!)

elementary exact operations, with small fixed matrix-setup factors/additions to be charged separately in code. This astronomical bound is decisive adverse evidence: the literal oracle is NOT proposed for resource admission. No timing/RSS inference follows. A future cheaper oracle or proof-certificate substitute must be expressly reviewed and its actual validation scope recorded; the existence of this oracle cannot be advertised as an executed full test.

An explicit conservative exact-integer oracle envelope also exists. Scale every tagged field matrix by8; each of its ten summands has entry component less than2^10, so each subset-sum complex entry has magnitude less than2^15. A Pfaffian numerator is then bounded by2^180 (ten entries and19!!<2^30), tag polarization by2^190, two scaled curvature traces by another2^20, the4^5 gamma sum by2^10 and quadrature accumulation by24^12<2^56. Thus a raw probe numerator is less than2^276. Two1792-coordinate endpoint projections add at most2^22 summands, basis coefficient product at most2^4 and common-dual weight below2^11 (each listed diagonal norm divides576, so each576/norm is an integer at most36), giving less than2^313 per source,2^314 for the sum. A clearing denominator is

8^10 *8^2 *24^12 *576^2 =2^48*3^4*24^12.

These bounds use intentionally generous trace/field-entry envelopes. Arbitrary integers or signed512-bit checked arithmetic suffice for this mathematical oracle; its arithmetic time remains adverse. They do not alter the main compiler's common denominator or signed256 contract.
