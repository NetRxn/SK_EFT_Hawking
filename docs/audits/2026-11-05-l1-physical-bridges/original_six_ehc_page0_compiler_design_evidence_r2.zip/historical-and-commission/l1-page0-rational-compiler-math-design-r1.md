# Complete original page0 rational matching compiler: manual design

Independent DESIGN ONLY, l1-sixehc-page0-compiler-r1, parent publicationROOT01a13f67/L1-physical-observable-boundary; assigned source6830c734218ed094f632092bd372ad9a263a2711. FIRST primary packet check returned exit0, fresh=true, changed=[]. Sole notebook writer remains Executor01a1ac65. Own ONLY this report, preserving all earlier reports and all peer/source/repository/notebook files. Read the commission, current notebook, accepted covariant-page proof/acceptance, exact orientation annotation and pinned original authorities. No current peer compiler analysis was consulted. No executable/code/import/CAS/table/mask/moment/Haar/tensor/network generation, test/build/Lean/native/slot/controller/harness action occurred. Every identity/count below is manual; this is not a program or output certificate.

Conclusion: a COMPLETE elementary rational page0 compiler can be specified. It has no undefined CG/pivot/tensor-contraction primitive: its basis, duals, raw source grammar and matching-loop evaluation are explicit below. A safe complete ceiling is2^23 closed binary-spin matching graphs, each with at most128 two-leg factors, and at most2^41+2^33+2^20 declared primitive operations, with setup explicitly included. All final and prefix Gaussian numerators are bounded by2^175 with common denominator D=2^32*3^6; signed256-bit components are safe. Three full2304-entry source/source/sum arrays take442368 numeric bytes. These are constructive conservative bounds, NOT measured timing/RSS, a120-second fit, execution admission or a complete-core cost. Any optimized implementation needs fresh independent proof/code/spec review before ROOT considers an invocation.

## 1. Exact target, anchors and source ordering

Retain the accepted original full scalar

 h12,6=8*3^8*2^-40 sum_(samekappa beta,gamma) W_beta,gamma Ccore_beta,gamma.

Page0 is only one factor of the literal eight-site/twenty-anchor/six-unit-EHC/four-D/20-quarter-T/12-V core. All original source endpoints, gamma/world/top signs and shared fields remain. Neither a favorable coefficient nor a page is substituted for that full scalar.

Name the SIX distinct page anchors

 a=Omega_(0,0), b=Omega_(4,0), c=Omega_(0,2), d=Omega_(4,2),
 e=Omega_(1,0), f=Omega_(5,0),

and retain CENTRAL U=Omega_(1,2), V=Omega_(5,2) as OPEN variables. The two page faces are EXACTLY

 H0=c† b† U a, H4=d† a† V b.                                 (1)

U,V here are UNDAGGERED; they are different labels from the daggered source-edge c,d. The accepted orientation annotation is binding. This compiler integrates a,b,c,d,e,f only, with independent original Spin4 Haar; no U/V integration or endpoint identification occurs.

For any site z and neighbor y=z xor e_mu use the literal coframe

 T_zmu^A=[bar_z gamma_A (Omega_zmu†-Omega_ymu) psi_y
          -bar_y (Omega_zmu-Omega_ymu†) gamma_A psi_z]/4.      (2)

Thus the side coframes T10 use e†-a and T50 use f†-b. Source Q0=sum_A(T02^A)^2 uses c†-d; source Q4=sum_A(T42^A)^2 uses d†-c. These are computed SEPARATELY. No Q0/Q4 equality, cache interchange or same-endpoint/mixed-endpoint gamma commutation is assumed.

Copy colors use q_A=(-i sigma1,-i sigma2,-i sigma3,I), E12=+1 and K_a=i q_a. The accepted V copy order is V0=M+N,V1=i(M-N),V2=B-P,V3=i(B+P). At each outside site store the THREE representative canonical pair values with (a,b)=(0,r+1),r=0,1,2. For fixed face chirality the lock supplies the other three canonical values by the unnormalized basis

 H0^s=01+s23, H1^s=02-s13, H2^s=03+s12,
 s=+ for faceL, s=- for faceR.                               (3)

The stored coordinate is the representative value C_(0,r+1), not the sum with its complement. Therefore canonical reconstruction is sum_r H_r^s*C_(0,r+1), with NO1/2 or1/4. If an implementation instead evaluates Hodge sums it must divide by2 per outside site; that is a different input convention. This design never replaces a full ordered F_AB V_a^A V_b^B by full ordered F_AB Z_ab^AB without the required1/2. R already contains canonical antisymmetric reconstruction and supplies no extra2^6.

For fixed face chiralities (chi0,chi4) and representatives r,s, the exact page word is the partial integral of

 Q_end *[-F^chi0_IJ(H0) V_(0,0)^I V_(0,r+1)^J]
       *[-F^chi4_KL(H4) V_(4,0)^K V_(4,s+1)^L]
       *T10^A T10^B T50^C T50^D,                            (4)

summing I,J,K,L and the source's internal index. A,B,C,D remain open. The two displayed minus signs are the original class world epsilons epsilon0213. Keep them separately in the phase bookkeeping even though their product is+. This order is legal because every moved coframe/V/class factor is even. Within each bilinear its original odd order is retained.

Use the FULL curvature commutator, including diagonal cancellation:

 F^L_IJ(H)=Tr[H(q_I q_J†-q_J q_I†)]/2,
 F^R_IJ(H)=-Tr[H(q_I† q_J-q_J† q_I)]/2.                     (5)

There are four ordered commutator terms across the two faces and an overall denominator4. No diagonal raw trace is falsely set to zero. Equation(4) includes all six coframe quarters, denominator4^6, and both whole EHC factors. No already-extracted22-free-edge1/8, mixed C, bulk192 or aggregate8*3^8*2^-40 factor belongs in this page.

## 2. Field coordinates and open-central pullback

At every page site use the signed fundamental-spinor modes

 L1=barL, L2=psiL^T E, R1=E barR^T, R2=psiR,
 Phi=(L11,L12,L21,L22,R11,R12,R21,R22).                       (6)

The first four-mode top and last four-mode top equal the original tauL,tauR with POSITIVE signs. Field conversions are barL=L1, psiR=R2, psiL=E L2, barR=-E R1. They are explicit signed monomial spin maps, never a change of the original Berezin functional. Each site full top is Phi1...Phi8 with positive sign.

Cut U_(r5,c1) V_(r1,c5). Convert their actual matrix legs to fundamental dummy slots ordered by FACE(0 then4): at hub1 use E_(u,c1) and delta_(v,r1); at hub5 use delta_(u',r5) and E_(v',c5). For example E(g^-1)^T=gE converts the U-column covector at1 to a fundamental spinor. Equivalently the converted coefficient tensor is

 Ptilde_(u,v;u',v')=sum E_(u,c1) delta_(v,r1)
                           delta_(u',r5) E_(v',c5)
                           Praw_(r5,c1;r1,c5).               (7)

These are real orthogonal pullbacks, so the same E arrays implement inverse coefficient extraction. They preserve all transposes/signs. At both hubs the first dummy chirality is chi0 and second chi4. For unequal(R,L), evaluate the unequal(L,R) basis below with its two commuting dummy slots exchanged: (u_L,v_R)=(second,first). NO fermionic swap is made; the field polynomial is always in L-before-R order. For equal R use the explicitly transposed vector matrix specified next.

The hub field coordinate basis is the28 canonical two-forms Phi_i Phi_j,i<j. Its auxiliary Hermitian coefficient inner product declares these coordinates orthonormal. It is NOT the signed exterior top or a physical state. Original odd signs enter before this coordinate inner product through(2),(4),(6).

## 3. Integral intertwiner basis and EXACT diagonal Gram dual

Use FULL ordered internal vector indices A,B=0..3. The ambient magnetic domain at one hub is28*16*4=1792, with symmetry in A,B. Packing A<=B instead gives1120 entries but the metric MUST weight offdiagonal entries by2. The design uses1792 to avoid ambiguity.

Put S_A=q_A E, so sum_A S_A,iα conjugate(S_A,kβ)=2delta_ik delta_αβ. For equal chi=L set S^chi=S; for equal chi=R set S^chi_A,iα=S_A,αi. First spin index is then chi, second opposite chi. Define integral polynomial forms (NO hidden1/2):

 Ftilde_chi,pr=sum_ik E_ik Phi_chi,p i Phi_chi,r k, p<=r,
 Stilde_chi,ik=sum_pr E_pr Phi_chi,p i Phi_chi,r k.

Ftilde is symmetric in flavour, Stilde symmetric in spin. These are twice the corresponding normalized forms in some earlier type-label descriptions; the following numerical formulas and norms govern THIS compiler.

EQUAL(chi,chi) basis order m=0..7:

 m0..2: Ftilde_L,(11,12,22) delta_AB E_uv;
 m3..5: Ftilde_R,(11,12,22) delta_AB E_uv;
 m6: delta_AB sum_ik Stilde_chi,ik E_iu E_kv;
 m7: sum_(r,s,i,k,α,β) Stilde_oppchi,rs E_rα E_sβ
       (S^chi_A,iα S^chi_B,kβ+S^chi_B,iα S^chi_A,kβ) E_iu E_kv. (8)

Their full1792-coordinate Hermitian Gram is EXACTLY diagonal with

 g=(32,16,32,32,16,32,48,576).                               (9)

UNEQUAL(L,R) basis: for p,q in order11,12,21,22 let Xpq,mα=L_pm R_qα. First list all FOUR scalar-world paths, then all FOUR(1,1)-world paths:

 m0..3: delta_AB sum_mα Xpq,mα E_mu E_αv;
 m4..7: sum_(m,α,i,k,β,γ) Xpq,mα
          (E_mi E_uk+E_mk E_ui)(E_αβ E_vγ+E_αγ E_vβ)
          S_A,iβ S_B,kγ.                                   (10)

Its Gram is diag(16,16,16,16,576,576,576,576). UNEQUAL(R,L) uses the dummy-slot exchange in(7); the field order remains X=L R. This fixes coefficient order rather than silently interleaving the two paths per flavour.

All64 Gram entries per case are fixed, not just their diagonals. Cross-flavour entries vanish by disjoint canonical field support; scalar and triplet fields are orthogonal; different L/R triplets are orthogonal; scalar versus(1,1) world paths are orthogonal by the internal trace. Explicitly Ftilde norms are4,2,4 and Stilde's sum over ordered spin indices has norm12. Scalar world delta has norm4 and E has norm2, giving32,16,32. Formula m6 gives12*4=48. For m7 the S map contributes factor4 to a two-vector norm; symmetric two-spinor epsilon maps have squared norm12 on each of the two spin factors, giving4*12*12=576. The unequal scalar path gives4field/dummy matches times4world trace=16; its two symmetric spin factors similarly give576. The complex-conjugate auxiliary Gram uses the actual q phases; it is not sharp reversal or a positive exterior top. The signed permutation(6) and endpoint maps(7) are unitary for THIS auxiliary coordinate metric, so do not change these norms.

For fixed ambient cell, every basis entry is a Gaussian integer of magnitude<=4. This follows directly from(8)-(10): fixed field mask selects at most two Stilde spin assignments; the displayed symmetrizations give at most four unit-phase products. No CG/pivot selection remains. All g_m divide576. With the pulled-back page tensor, exact coefficient extraction is

 p_mn = [sum_(all1792cells at each hub) conjugate(I_m I_n) Ptilde]
        /(g_m g_n).                                       (11)

The sum is evaluated by the graph algorithm, NOT by a1792² array. Its common dual denominator is576²; multiply each numerator by integer576²/(g_m g_n). Since min g=16 this integer is at most1296<2^11. The basis formulas form a complete8-dimensional invariant basis by the accepted covariance/type proof, so(11) reconstructs the entire page and does not project away a physical component.

## 4. Coefficient order and full source arrays

Use face-pair order LL,LR,RL,RR; r0,r4=0,1,2; m1,m5=0..7 as above. Flatten by

 index=((((facepair*3+r0)*3+r4)*8+m1)*8+m5).

This is2304 complex coefficients. Produce THREE complete arrays in order Q0,Q4,sum, all with the SAME denominator D below and all zero coordinates retained. The producer accumulates Q0/Q4 separately, then performs2304 exact Gaussian additions for sum. There is no third scientific evaluation. Same-chi Q0 has hub1 degree2 opposite chi and hub5 degree2 chi; Q4 swaps them. Each endpoint therefore permits one4-by4 basis block per equal-face sector. Each individual source array has864 structural zeros; their union in the sum leaves576 structural zeros. The remaining1728 sum coordinates are potential support, NOT claimed nonzero.

## 5. COMPLETE source/anchor/chirality matching roster

Gather all occurrences per actual anchor/chirality in the fixed factor order: source coframes first, then side coframes T10^A,T10^B,T50^C,T50^D, then curvature words H0,H4 left to right. Compact entries commute, so this gather introduces no odd permutation. Original odd lists remain in(4) and their own bilinear order.

On source edge c,d there is one curvature on each anchor. Center parity forces one coframe on each, two assignments. Its coframe compact group MUST equal that curvature's group; otherwise each group has odd degree and Haar is zero. Retain both source endpoints and all2^6 forward/backward choices of the six coframes.

On each side edge, one active anchor has two curvatures and its partner none. If the two face chiralities agree at chi, all necessary options are:
 - both coframes active in chi: one P4 with TWO invariant channels;
 - both active in opposite chi: two independent P2 groups, ONE channel;
 - both partner in L or both partner in R: ONE channel each.
Before exterior saturation this gives5 channels per side. Different face chiralities permit only both active with one coframe in each group, TWO orders/channels, and forbid an inactive partner choice. This gives the valid loose14848-channel roster, preserving the earlier looser1048576 bound.

Now use actual endpoint gamma order and outside2L2R. T10/F_y compact group chi puts its OUTSIDE field in chi and HUB field in opposite chi, for either anchor; T50 is identical with the original labels. Source Q0 in the equal-face case supplies outside0 two opposite-chi fields and outside4 two chi fields. Thus left side must have both coframes chi, giving3 channels(P4 two + partner one), and right side both opposite chi, giving2 channels(active/partner P2). Q4 reverses them. Each equal-face block has

 (3*2+2*3)*2source assignments*64directions=1536 channels.

Each differing-face block has2side orders each, two source endpoints/assignments and64directions, giving1024. ALL four blocks total5120, with2560 per source endpoint. None is presumed locally nonzero after flavour/top tests.

Use Haar2=EE^T/2 and Haar4=AA^T/4+JJ^T/12 with A=E12E34,B=E13E24,J=2B-A. Equal-face exterior saturation allows at most ONE side P4; the opposite side is P2-by-P2 or two separate P2s. Differing-face pages have no P4. Expand J left/right as the FOUR matchings AA,AB,BA,BB with weights1,-2,-2,4. The equal-face count per block becomes3072 after this expansion, the differing-face counts remain1024. ALL source epsilon-matching terms therefore number at most

 2*3072+2*1024=8192, with4096 per source endpoint.            (12)

This is a complete grammar count, not a generated inventory. A future implementation must retain full source/anchor/group labels and verify these partition counters; it must not multiply both5120 rank channels and8192 matching channels.

## 6. Finite category pruning and exact output-basis scope

For each source matching term the field categories are known without choosing spin bits. Work in Phi categories Lflavour1,Lflavour2,Rflavour1,Rflavour2. At each outside site the full top requires exactly TWO occurrences in each category; otherwise zero. Convert coframe fields by(6), keeping its E/sign maps. At a hub two remaining fields determine their chirality/flavour pattern.

Each external V_a has TWO natural Wpq=Lp q_A Rq supports, selected by the nonzero entries of K_a. For fixed representative V0 V_(r+1), sum over ALL r as follows. Let(nL1,nR1) be the flavour1 counts required of the two V factors after the four coframe fields are known:

 r0 (V1 offdiagonal): possible pairs(2,0),(1,1),(0,2), at most two ordered supports;
 r1/r2 (V2/V3 diagonal): possible pairs(2,1),(1,0),(1,2),(0,1), one support per r.

The two sets are disjoint. Therefore at most TWO total(r,support) choices survive at EACH outside site, at most FOUR for both. This includes every one of the9 external representative coordinate pairs, not a selected channel. A simpler bound4per outside is safe but unnecessarily loose.

The fixed two hub field categories permit at most TWO basis labels per hub: in same-chi fields, one scalar flavour label and possibly its spin-triplet label; in different-chi fields, one vector flavour with its two world paths. Thus at most FOUR(m1,m5) pairs require a graph evaluation per source/support choice; all other entries remain explicitly stored zeros or receive other branches. This is not a global deletion of additional output coordinates.

For each surviving basis label, expand its displayed epsilon terms and the canonical field coefficient pairing

 <Phi_i Phi_j, Phi_k Phi_l>=delta_ik delta_jl-delta_il delta_jk.

After the known flavour categories are matched, at most FOUR epsilon diagrams remain per hub (m7:two Stilde assignments times two vector orders; unequal(1,1):two-by-two symmetrizations). Scalars and m6 use no more. This is an auxiliary COORDINATE inner product, not Wick factorization of the original physical state. All actual exterior signs were retained by(4),(6).

## 7. Eliminate EVERY internal vector sum algebraically

Keep both full commutators in(5), four branches and denominator4. For the actual quaternion basis use the exact finite identities

 sum_A q_A,ij q_A,kl=2 E_ik E_jl,
 sum_A q_A,ij conjugate(q_A,kl)=2 delta_ik delta_jl.           (13)

Conjugate/conjugate is the conjugate of the first identity; daggers are conjugate transposes, with their ACTUAL indices. Each external curvature index I,J,K,L occurs in exactly two q factors (one from its curvature commutator, one from its V). The source's contracted index occurs in its two coframe gammas. Each side A/B/C/D occurs either in its coframe and a basis S=qE, or is joined to its partner by a scalar-world delta and then occurs in the two coframe gammas. Hence every vector sum is removed by(13), no4^9 loop. There are at most9 such pair eliminations, so the absolute scalar multiplier is at most2^9. Their epsilon/delta maps retain every transpose/complex conjugation, including those of the conjugated Gram basis in(11).

This use of completeness is coefficientwise, not a new compact average or scalar K substitution. Retaining the commutator is essential: replacing it by q_I q_J† without the other term would generally introduce an incorrect diagonal/symmetric part.

## 8. Explicit elementary graph evaluator; no unspecified tensor primitive

Each surviving discrete term now consists entirely of scalar Gaussian phases/weights and TWO-LEG monomial matrices E,delta and their signed/transposed/conjugated variants. One may retain a literal q variant internally before(13), but after all vector eliminations there need be no free q label. For reference q0 has rowbit->opposite column with phase-i; q1 does the same with phase-(-1)^row; q2 preserves the bit with phase-i(-1)^row; q3 is identity. E flips the bit with phase(-1)^row. All coefficients are exact roots of unity times the recorded integer matching weight.

A frozen factor grammar builds an IR with one two-port matrix per factor. Original matrix multiplication/trace identifies successive ports; dagger conversion U†_ij=sum_ab E_ia E_jb U_ba adds its TWO E factors and reverses the occurrence's row/column ports. Gather each actual chiral compact occurrence in the fixed order of section5. For degree2 connect row ports and column ports by E. For degree4 choose its A/J channel and recorded row/column matching pairs12/34 or13/24; the J weights were explicitly expanded in(12). No compact matrix element remains unintegrated on a,b,c,d,e,f.

Outside-field top: stable-sort the ordered Phi field list by site/category only. Reject unless each outside category has exactly two fields, connect their spin ports by E in their retained relative order, and multiply by the sorting parity. Eight E factors implement the two outside tops. For hubs use the displayed two-term coefficient pairing against the conjugated basis polynomial, rejecting flavour mismatches as in section6. No exterior-mask table is needed. Adapt central ports by(7). The expression is scalar after(11), so every spin port has exactly ONE partner wire. Check this invariant explicitly. The resulting two-valent tensor network is a disjoint union of closed cycles, not a generic tensor network.

Evaluate cycles without enumerating all spin assignments. Start at the least unvisited factor, seed its first port by bit0 then bit1. Traverse a factor using its monomial row/column rule, multiply its unit phase, then follow the unique wire to the next factor. Entering a factor through column uses its inverse bit map with phase evaluated at the resulting row. Return to the initial port; keep that seed's phase only if its bit agrees. Add the two kept phases and multiply the cycle values. Mark the factors visited; repeat in factor order. This is exactly the sum over that connected component's binary indices. Each component has at most TWO consistent assignments. Its absolute value is<=2, and the product of at most128 components has absolute value<=2^128. No unproved CG compilation, general matrix inverse, stabilizer/Gauss-sum assumption, exponential spin loop or random sample remains.

Safe factor ceiling, before any identity simplification:
 - original gamma/vector q factors:6coframes+4V+4curvature=14;
 - field-to-Phi E maps:at most12;
 - compact dagger maps:at most24;
 - Haar row/column pairing factors:12;
 - central endpoint adapters:2;
 - outside tops:8;
 - hub field coefficient delta maps:4;
 - BOTH maximal basis formulas:16.

Total92 two-leg factors. The vector eliminations replace paired q factors by at most two E/deltas each, so do not increase this count. Use a conservative cap128. There are at most256 ports; wires form a perfect matching and at most128 cycles, including possible self-loops. This is why2^128 is a valid conservative cycle bound; it does not require every cycle to have length>=2.

The IR can use256 uint16 partner-port entries(512B),128 uint8 matrix codes(128B),128 uint8 visited flags(128B), plus fixed branch/field lists; a4096B typed workspace allowance suffices for this explicit streaming representation, excluding the accumulators, stack/interpreter/allocator/RSS. Do not retain all diagrams or grow an unbounded dictionary. Original word/field sorting has at most20field positions and190 pair comparisons. Graph traversal has at most256 factor visits across the two seeds. A conservative per-leaf charge is2^18 elementary bounded-width integer/bit/compare/array operations. One explicit bounded implementation uses at most512 descriptor/port assignments,128 factor appends,9 completeness rewrites each charged64 operations,400 category/sort comparisons each charged8 operations,256 port connections each charged16 operations, and256 cycle-factor visits each charged32 operations. Together with256 scalar weight/accumulator operations and fewer than4096 branch/basis/field-match operations, the total is below2^15;2^18 leaves ample fixed-array bookkeeping slack. All port labels address a fixed256-entry array; no search/hash-table growth or unbounded symbolic simplifier is allowed. Complex Gaussian arithmetic is charged by its constituent integer operations, not as a free tensor primitive. A future implementation must exhibit those loops rather than hide arbitrary contraction behind this charge.

## 9. COMPLETE operation, denominator and integer-width bounds

Combining ALL source matching terms8192, all surviving representative-copy/support choices4, all active hub basis pairs4, both hub epsilon expansions4² and both commutators4 gives

 N_graph <=8192*4*4*16*4=2^23.                               (14)

This bound covers BOTH original source endpoints and every one of the full2304 target coordinates. It is not a per-coordinate cost and must not be multiplied by2304 again. The earlier safe bounds5120channels,14848pre-exterior and1048576raw invariant channels remain historical looser scopes, not competing coefficients.

Basis/certificate setup is charged separately. The four ordered chirality cases have4*8*1792=57344 ambient basis entries. A completely literal pointwise evaluator of(8)-(10) loops over at most six binary spin indices, four flavour assignments, the two field coefficient pairings and two displayed vector orders, multiplying at most ten unit Gaussian/epsilon/delta factors per term. Charging2^16 elementary operations per entry bounds this below2^32. It does not invoke CG generation or a pivot oracle. All four complete64-entry Grams require4*64*1792 Gaussian multiply/add terms, fewer than2^23 elementary integer operations at a ten-operation charge. Exact dual-norm/reconstruction identities and fixed endpoint-sign permutations have finite fixed loops within an additional2^20. A conservative combined setup/certificate allowance is2^33 operations. Basis entries are bounded by4 and Grams by576 independently of this evaluator; reject any mismatch. Optional full basis storage is57344Gaussian signed8 cells=114688B, not mandatory for on-the-fly graph production.

Source/category/output initialization, the bounded8192-term roster and final source-array sum have an additional2^20 allowance outside leaves; branch work repeated per leaf is already charged there. Thus an explicit conservative operation envelope is

 2^23*2^18 +2^33+2^20 =2^41+2^33+2^20.

This includes scientific elementary arithmetic/index setup and graph accumulation, but not arbitrary external I/O/hash/tool overhead. It is large, not a timing/RSS forecast or a claim that the old120-second profile fits. Exact256-bit arithmetic has a specified width; the count is not machine instructions. A future code/spec must separately bound codec/manifest/hash/readback bytes and overhead, and exhibit the fixed scientific loops.

The twelve noncentral compact occurrences have even nonzero degrees2/4. If k groups have degree4, the number of degree2 groups is6-2k. Before the exterior improvement k<=2, and actual surviving page0 has k<=1. Their P2/P4 channel denominator divides2^6*3²=576. In the expanded matching convention576 times ANY individual Haar branch coefficient has absolute value<=16 (with k<=1 the sharper maximum is12). There is no unspecified rational moment denominator.

All six coframe quarters contribute4096. Full curvature commutators contribute4. Dual extraction contributes a divisor g_m g_n of576². No Hodge normalization denominator occurs with the representative convention(3). Therefore ONE common exact denominator is

 D=576*4096*4*576²=2^32*3^6 <2^42.                           (15)

It is kept globally; no gcd simplification or denominator-dependent coordinate ordering is needed.

For each matching leaf, its numerator at scaleD is a Gaussian integer bounded by the product

 2^128(cycle value) *2^9(completeness) *16(Haar scale)
        *1296(dual scale) <2^152.

Copy/support phases, class/world/field-sort signs and symmetrizer branch coefficients have already been explicitly expanded; they have unit magnitude except the accounted P4 weights. Prefix accumulation over at most2^23 leaves gives a bound<2^175 for each component, indeed for the sum of absolute contributions over all coordinates of BOTH endpoint arrays. Their final sum is covered by the same total-leaf bound. Cycle products, intermediate scalar multiplication and every accumulator prefix remain within this bound; it is not merely a final cancellation estimate. Signed256-bit real and imaginary components are safe. Arbitrary integers with explicit pre-serialization bounds are also valid. No reliance on an unverified128-bit optimization is needed.

Each endpoint/sum array has2304 Gaussian numerators, real then imaginary, with fixed signed256-bit components:147456B per array. Three arrays total442368B. The common denominator fits uint64. Two-source scientific work is already included in(14); sum adds2304 Gaussian additions(4608 component additions), no third evaluation. Working typed data may retain all three arrays, the optional114688B basis certificate and4096B graph workspace: total561152B. These byte counts exclude code/metadata/manifest/source pins/interpreter/allocator/RSS, which remain UNKNOWN. Do not label this total as peakRSS.

## 10. Source-bound COMPLETE test and acceptance plan

No test is executed by this report. A future reviewed program/spec should freeze and require the following exact checks under a NEW ROOT admission; refusal is incomplete, not a zero coefficient.

1. Original-source word audit: literal anchors(1), all three coframes(2), EHC world epsilons and FULL commutators(5), V0/Vr representatives and original top/order(4),(6). Distinguish central U,V from source-edge c,d. Test both source endpoints independently. No historical dagger typo is imported.
2. Basis audit for ALL four ordered face-chirality cases: all64 Gram entries including every zero, integral norms(9)-(10), entries<=4, full1792 versus packed1120 with offdiagonal metric2, exact endpoint dual adapters and R/L dummy swap. Scalar/triplet normalization is the TILDE formula here, overriding shorthand normalized type labels. Verify inverse Gram times Gram is identity and coefficient reconstruction is exact in the complete invariant subspace, not one diagonal sample.
3. Exact primitive identities: every Pauli/q phase and transpose, both completeness identities(13), normalizedP2/P4 with1122control1/3, rationalA/J factorization and dagger identity(2) with original endpoint indices. Adverse sign controls include an E² closed cycle trace-2, identity cycle2, and transpose/complex-conjugate variants. These test the matching engine, not a physical positive trace.
4. Exterior-coordinate audit: signed Phi substitutions and positive local tops; original odd word sorting; two-form coefficient delta determinant; all outside category counts; complete representative Hodge reconstruction including its complementary signs, full orderedFZ half convention, and no invented2^6. Compare the exact matching evaluation with explicitly expanded SMALL primitive cases only if that separately proposed test execution is admitted.
5. Complete grammar partitions: original source/anchor/chirality/endpoint labels,5120rank channels,8192expanded matching terms, separateendpoint2560/4096 counts. Zero local/chiral branches may be recorded, never treated as an evaluated full amplitude. Verify at most one P4, complete commutators, port-perfect-matching invariant, <=128factors, <=2^23graphs, coefficient/prefix width and all counters.
6. FULL2304coordinate outputs Q0,Q4,sum, sourceendpointzero masks864each and576summed, no deletion of permitted coordinates or presumed nonzero support1728. Sum must equal the two independently produced endpoint arrays slotwise. Other endpoint relations require an actual gamma/top/source proof; no caching by an assumed translation is permitted.
7. Retain accepted adverse/source controls: mixed physical coefficient-1/8(scale32:-4), fundamental source-edge tensor coefficient+delta_il delta_jk/8(1111:+1/8), actualt192, completeR/B/W signs and normalization. They guard against a scalarK substitute or universalQ-sum annihilator. They do NOT hardcode a page answer or sign the aggregate. Future end-to-end checks must bind the exact component to its actual source word rather than relabeling these primitive controls as page values.

A complete direct end-to-end original-page oracle, if commissioned, must have its OWN finite elementary algorithm/cost and separate test admission. Reconstructing the entire magnetic page is not a cheap test merely because the invariant output has2304 entries. An astronomical literal quadrature/Pfaffian or raw-expansion oracle may establish a formal test domain but is not included in, or eligible for a run under, the compiler operation envelope. This report claims manual correctness of the complete algorithm, not that full-page numerical tests have passed.

A concrete artifact codec/manifest, exact code, accepted source pins, deterministic counters/output caps, cooperative deadline/refusal semantics and independent ACTUAL math/source/static reviews remain to be prepared before any ROOT request. There is no present invocation, new code, generated basis/table, output, timing or RSS evidence. The algorithm is complete at mathematical elementary-operation level; a program must implement THIS grammar and bound, or receive a revised design/review rather than silently switching to dense tensors.

## 11. Whole-core and physical boundary

This constructs only the complete original page0 coefficient family. Pages1/3, actual central jointP4/source contraction, canonical Hodge pullbacks and weighted W pairing still need their own complete compiler/order bounds. The inherited huge complete-core ordering is not qualified by the small page0 output or this operation envelope. Full h12,6/A01 value/sign/nonzero and fullcorefit remain UNKNOWN. No isolated negative W coordinate, canceled32-sector word or selected positive component is a substitute.

The accepted original128-mode/64-anchor theory, sixEHC/fourD/twoendpointsource sums, quarters/gamma/world/top, both kernels, uncapped Delta/reflection/source/normalization/Bopp/Dlog contacts and SAME Lambda/tail remain binding. Auxiliary Hermitian basis duals and moment invariant Grams are algebraic tools, not physical boundary-product-adjoint/seam/causal transfer or a new state. TT/Ward/projector/pole, physical positivity/transport/matterEM/calibration/B3/N4/limits remain OPEN. ROOT owns queue/roadmap/intake/integration/gates/runtime/nativeLean/publication approval.

## 12. Continuity and exact scope

FIRST adapter command was `python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/l1-sixehc-page0-compiler-r1.json` from the assigned checkout. The commission and accepted pageproof/acceptance/orientation/current notebook were read; prior proofs/roadmaps/governing scope are preserved. Only this private design report was written. Final SAME result and report SHA/bytes are returned with delivery. No source drift may be refreshed away, and no packet is execution or completion authority.
