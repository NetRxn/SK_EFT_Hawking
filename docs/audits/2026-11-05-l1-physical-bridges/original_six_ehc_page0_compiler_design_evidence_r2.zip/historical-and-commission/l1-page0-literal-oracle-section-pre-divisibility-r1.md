## Frozen literal end-to-end oracle and adverse cost

For completeness, the default independent full oracle is the deliberately literal route below. It is specified rather than silently replaced by a cheaper correlated compiler. An optimization would be a NEW design/review, not an implicit choice here.

1. Visit both source endpoints separately and every45158400 raw magnetic probe of the locked page (all four face pairs/nine representative pairs/two hub masks/two central entry pairs/two symmetric side pairs). Restore packed-side off-diagonal multiplicities exactly for subsequent dual projection.
2. For each probe, evaluate the original expression at the Cartesian product of the24-cell quadrature for ALL12 independent chiral noncentral anchor groups. Do not share anchors, set U=V or import the main parity grammar. Each group has degree at most4; the source report's second/fourth/odd moment proof certifies this quadrature.
3. Sum the four outside curvature vector labels and common source gamma label explicitly: at most4^5 choices. Extract the product of ten literal bilinears by10-tag polarization: sum over the2^10 tag subsets with sign(-1)^(10-|S|), using Pf(sum_(f in S) A_f). Homogeneous degree10 ensures that exactly the all-ten-tag coefficient survives. The source report's theta^t A theta/2 convention fixes matrix signs and avoids10!.
4. Evaluate EACH20x20 Pfaffian independently by lexicographic perfect matchings, with its standard permutation sign and ten entry products. There are19!! matchings; a safe400*19!! elementary Gaussian-integer operation ceiling covers products, parity and accumulation without any pivot assumptions. This is an exterior/Pfaffian oracle, not the main binary-spin cycle implementation.
5. Accumulate quadrature weights, reconstruct the full magnetic tensor and apply the explicitly frozen dual independently to obtain ALL2304 coordinates for Q0 and Q4; check every value and their sum. No random subset, favorable entry or norm-only check replaces this comparison.

A complete literal arithmetic ceiling BEFORE the final dual projection is therefore

2*45158400*24^12*4^5*2^10*400*(19!!)

elementary exact operations, with small fixed matrix-setup factors/additions to be charged separately in code. This astronomical bound is decisive adverse evidence: the literal oracle is NOT proposed for resource admission. No timing/RSS inference follows. A future cheaper oracle or proof-certificate substitute must be expressly reviewed and its actual validation scope recorded; the existence of this oracle cannot be advertised as an executed full test.

An explicit conservative exact-integer oracle envelope also exists. Scale every tagged field matrix by8; each of its ten summands has entry component less than2^10, so each subset-sum complex entry has magnitude less than2^15. A Pfaffian numerator is then bounded by2^180 (ten entries and19!!<2^30), tag polarization by2^190, two scaled curvature traces by another2^20, the4^5 gamma sum by2^10 and quadrature accumulation by24^12<2^56. Thus a raw probe numerator is less than2^276. Two1792-coordinate endpoint projections add at most2^22 summands, basis coefficient product at most2^4 and common-dual weight below2^11, giving less than2^313 per source,2^314 for the sum. A clearing denominator is

8^10 *8^2 *24^12 *576^2 =2^48*3^4*24^12.

These bounds use intentionally generous trace/field-entry envelopes. Arbitrary integers or signed512-bit checked arithmetic suffice for this mathematical oracle; its arithmetic time remains adverse. They do not alter the main compiler's common denominator or signed256 contract.
