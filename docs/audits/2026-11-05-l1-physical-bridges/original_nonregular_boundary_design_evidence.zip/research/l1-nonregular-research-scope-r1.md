# Bounded W1 nonregular boundary quantization research scope

Research/design only. Primary question: for a pure quartic/octic Grassmann
lattice gravity action with compact independent Spin(4) links and three-slice
locality, which established discrete nonregular constraint/quantization or
boundary-state construction supplies a source-defined physical domain,
product, adjoint and positive form? Identify exact mathematical hypotheses,
what the source actually constructs, and applicability gaps; do not assume
a familiar CAR or regular kinetic inverse. Exact original metric/source first
and mixed-second contacts must be preserved. A formal variational relation,
BRST/BFV cohomology, real amplitude, ordinary trace, or positive sampling
weight must not be mistaken for a positive physical state.

Accepted input26bf5596/fc5bf408a fixes the original finite action/source,
actual transfer and gauge/center trace, failed full-symbol positivity route,
zero-body bare continuum inverse and unmatched source-unitarity transport.
No new physical construction is authorized. A concrete prospective brief
needs renewed independent source/architecture review before implementation;
any executable proposal separately needs exact runtime admission. Alternative
controlled scaling route stays open. Publication ROOT owns all L1 readiness.

Tier0 lead directly read: original Diakonov/Vergeles/CGL bodies and accepted
construction notebook; existing Phase5 hybrid bag, Majorana8 research reports
and Phase6a microscopic coefficient report. The older bag reports change to
nearest-neighbor squared channels/auxiliary bilinear models and do not supply
the unchanged full-action boundary norm. Their sign/sampling claims are not
physical positivity certificates. The coefficient report's inherited strong
OS/phase assumptions are superseded for this assignment by exact accepted
qualification; no axiom or mean-field assumption is adopted from it. Local
code/roadmap search found no explicit nonregular quantization implementation
in searched terms, not proof of global absence.

Scout task is primary-source breadth reconnaissance of known constructions.
Report exact theorem/domain/regularity/measure/adjoint/positivity hypotheses
and what new lemmas/premises a same-original-model application would require.
Focus discrete variational/constraint quantization, treatment of irregular
constraints, and any boundary quantization prescription that might actually
supply a positive inner product. Lead vets load-bearing bodies directly.
No altered action or favorable state/domain/source, no derivation or evaluator.
