# N16 normalization/physical-image certificate: literature and substrate reconciliation

Read-only intake `L1-N16-certificate-literature-intake`, parent publication-L1-normalization-physical-image-certificate. Packet `l1-n16-certificate-literature-intake-r1.json` fresh at entry; source `7f8cf17b443e23fd253ab59be3047bb23c69c60e`. Read current primary L1FixedControls notebook, held primary text and actual source declarations. This scratch report is the sole written artifact. No scientific imports, matrix evaluation, jobs, tests, builds, Lean/LSP calls, slot/process action or candidate/Git/notebook changes. Publication retains canonical findings, integration and ordinary L1 readiness.

Held sources:

- `/private/tmp/l1-vergeles2025-source.txt`, S.N. Vergeles, *Unitarity of 4D Lattice Theory of Gravity*, held2025v2 text,808 lines; packet SHA25697138211cd522b7de771334be2250fd5f887eac6790d0f9eae36f583828ddedb.
- `/private/tmp/l1-diakonov2011-source.txt`, Diakonov2011, especially sectionsV–VI/discussion; packet SHA256f2d9851cc3fb1e2d92b8a940656c1cc3c0c9ad5b8136960b7d6acb1cf2ce6de3.

D=`docs/audits/2026-10-17-publication-substance-construction/`; B=`docs/audits/2026-11-05-l1-physical-bridges/`.

## 1. Vergeles: relevant precedent with explicit nontransferable premises

SectionII.A defines an orientable FOUR-DIMENSIONAL SIMPLICIAL complex, independent bosonic edge connection Omega and tetrad e, and vertex Dirac variables. Equation(2.1), text lines102–132, explicitly declares {Omega,e} independent. The bounded Euclidean tetrad integral |e|<1, compact Spin(4) measure and independent fermion integral appear in partition(2.9). The action(2.3) contains gravity(2.4), separate Dirac action(2.5) with bilinearTheta(2.6), and cosmological action(2.8). These are not identical to the N16 hypercubic theory in which every coframe is the original four-block fermion composite and no independent e is integrated.

SectionII.B, equations(2.16)–(2.26), text234–300, specifies deformations of connection AND tetrad integration contours, changes gamma/spinor conventions, and obtains a Minkowski Spin(3,1) oscillatory exp(iA). It derives formal conjugation of action terms with gamma0 and explicitly distinguishes formal action Hermiticity from Hermiticity with a defined scalar product. This is not the unchanged compact Euclidean Haar/Berezin integral with periodic time signs. A source/measure/contour and observable correspondence would be required before using it for that integral.

SectionsIII–IV use local simplicial evolution between spatial complexes Sigma and Sigma', with preserved degrees of freedom and a gauge-fixed measure; the first local move replaces one vertex and its neighborhood. The gauge discussion uses noncompact Spin(3,1), tree/cycle fixing and residual independent cycles. This supplies useful geometry/gauge lessons, not a ready two-interface Nt2 hypercubic thermal kernel.

Crucial IV assumptions, equations(4.1)–(4.10), text458–555:

- (4.1) specifies a gauge-fixed boundary scalar product including tetrad, connection and fermionic integration.
- (4.3) ASSUMES an orthonormal basis for this scalar product.
- (4.4) restricts to normalizable states with finite sum of squared coefficients.
- (4.5) imposes finite matrix elements of the local action.
- (4.6)–(4.7) relate the adjoint to the reversed local move and use a gauge identification to return to the original operator.
- (4.8) ASSUMES a complete eigenfunction ONB with finite REAL eigenvalues for that Hermitian operator.
- (4.9)–(4.10) then express its unit-modulus phases and preservation of the assumed norm under exp(iA).

Therefore the reusable logical structure is: define the ACTUAL physical scalar product/domain; establish its positive Hilbert-space meaning and appropriate Hermitian generator; identify the evolution kernel with that operator; then norm preservation follows. It does not license assuming an ONB in the unknown N16 reflection form to prove that same form positive, and does not supply a Euclidean reflection-positivity theorem for the compact periodic N16 functional.

Important nuance: the paper DOES discuss composite tetrads. SectionVI, equation(6.1), text675–710, explicitly proposes replacing e by the specific fermion bilinearTheta and states that the conclusions remain for that modified model. It notes Berezin integration simplifies convergence, but still identifies unresolved Minkowski gauge fixing/noncompact gauge-volume issues. Thus it would be inaccurate to dismiss this source as never considering composites. What remains missing for us is a correspondence from that particular simplicial Minkowski modification, its field content, gauge-fixed state space, boundary conditions and adjoint, to the actual hypercubic Euclidean four-block coframe, closed plaquette, periodic N16 theta and required observable algebra. Equation(6.1) alone does not establish those identifications.

The paper's discussion of variable-degree-of-freedom evolution also leaves a conditional issue: preservation in the specified local moves is central to its stated result. No result here transfers it to a different move/constraint space by citation alone. This intake neither refutes the paper nor establishes all its analytic domain assumptions; it records what the held primary actually uses.

## 2. Diakonov: actual action, measure, sources and infrared boundary

Held primary sectionV, text411–704, is directly relevant to the original N16 source:

- SectionV.A, equations(13)–(17), defines compact link matrices and ordered plaquettes with local gauge transport.
- SectionV.D, equation(23), gives the forward/backward composite tetrad with parameteralpha. The text selects alpha=1/2 by the intended inner/world inversion behavior. This is the original symmetric four-block coframe, retaining both temporal anchor families at Nt2; it is not an independent bosonic frame.
- SectionV.E, equations(24),(25), gives the epsilon determinant cosmological interaction and curvature/coframe-pair EHC interaction. Inserting the composites cancels lattice-spacing factors; S4 has eight fermions and S2 four.
- SectionV.F, equations(26),(27), fixes eight independent Grassmann generators/site, the nonzero oriented top integral, and normalized compact product Haar.
- Equation(28) specifies exp(g1Scosm+g2SEHC+optional explicitly supplied higher terms), dimensionless couplings and finite-volume well-definedness. Our adopted N16 keeps the stated two action terms, original signs and closed ordering. The current source contract supplies the independent physical composite J and transported coframe j; no physical metric-source normalization or our scalar determinant is derived merely by equation(28).

SectionVI, text705–802, explicitly says the bare action has no bilinear propagator, only multi-fermion vertices. It discusses prospective self-consistent mean fields, then exact Taylor/Berezin saturation followed by link integration into local gauge-invariant fermion combinations and closed loops. The stated loop derivation is schematic, with details deferred. Whether sufficiently long loops and the expected infrared gravitational behavior occur is left to the coupling-dependent loop entropy/energy analysis; it is not established there. The discussion, text874–898, repeats that long-range/Einstein correspondence is a question to investigate.

The primary's “Sign Problem is solved” wording in the discussion concerns finite well-behaved Berezin integration irrespective of the exponent's sign, as its preceding text explains. It must not be converted without proof into nonnegative Monte Carlo bag weights, positive normalized metric moments, Euclidean reflection positivity, nonzero finite fullZ, or a positive Hilbert-space state. Finiteness and measure-preserving gauge invariance do not imply any of those statements. Likewise its natural inversion motivation foralpha does not supply the full antilinear theta, physical image or periodic trace interpretation of our accepted boundary identity.

## 3. Actual conditional Lean substrate

### FermionBag4D.lean

Read `lean/SKEFTHawking/FermionBag4D.lean` actual statements, not its physical-summary prose:

- `so4_one_link_factor` assumes both dimensions equal2 and proves the numerical reciprocal1/4. It does not integrate the complete curvature/frame incident-link tensor of original N16.
- `so4_effective_coupling_pos` assumes g_EH>0 and a positive divisor. It proves positivity of their quotient, not a complete Peter–Weyl reduction of the original action.
- `eight_fermion_weight_full_occ`, `bond_weight_positive`, `fermion_bag_weight_bounded` prove positivity/bounds for SPECIFIED ordinary real exponential factors. A nilpotent original action weight, its determinant/Hermite representation or its full integrated bag weight is not identified with those factors by these declarations.
- `fermion_bag_weight_positive` at98–100 assumes w_site>0 and w_bond>0, then proves their product positive. Its comment labels this a bag basis, but the theorem does not derive those factors or hypotheses for the original N16 model.
- `metric_correlator_nonneg` at132–134 assumes `m4>=m2^2` and deduces `m4-m2^2>=0`. It does not prove the Cauchy–Schwarz premise for a signed Haar/Berezin expectation or establish a measure/state to which ordinary probabilistic Cauchy–Schwarz applies.
- `partition_function_log_finite` assumes Z>0 before constructing logZ. Binder/window declarations similarly assume their moment/crossing inequalities.

These lemmas are reusable arithmetic AFTER actual factor/moment/state correspondence and their hypotheses are supplied. They cannot lift the original sign problem, prove full nonzero normalization, or certify our physical-image Gram by importing a physical-sounding namespace/comment. No fresh Lean elaboration/build/LSP/type-admission or theorem-absence claim is made.

### QuantumNetwork/MixedState.lean

`lean/SKEFTHawking/QuantumNetwork/MixedState.lean:35–36` defines `IsDensityOperator rho` as `rho.PosSemidef AND rho.trace=1`. The actual declaration does not constructrho from the gravity functional. `psdSqrt` at528 and `psdSqrt_posSemidef`, `psdSqrt_isHermitian`, `psdSqrt_mul_self` at532–546 take a supplied PosSemidef witness and provide the concrete square-root identities. `traceNorm_density_eq_one` at163 assumes IsDensityOperator. These APIs can support finite matrix factorization/Gram proofs once the actual positive normalized matrix and observable map are constructed. Supplying positivity as a binder cannot certify the missing positivity of the original N16 form.

A source-level caution is also visible in `src/emergent_gravity/vergeles_unitarity.py`: its docstring asserts that Vergeles establishes an ADW NG two-point positivity claim, while its implemented checks test an input alpha's positivity/range and scalar formula matching. Those checks do not evaluate the original source-dependent N16 two-point function or derive a spin-2 projection. The held primary's actual assumptions/correspondence must govern any reuse. This observation is reported for the publication owner's existing scientific reconciliation; no code fix or independent new ledger was created.

## 4. Current accepted N16 physical-image target; avoid duplication

`B/N16_TEMPORAL_BOUNDARY_IDENTITY.md` (source82197710; packet bound) is ALREADY independently accepted as manual source-level correspondence. Its sections1–5 retain full S4 signed Hermite W, both periodic time interfaces, original M blocks, source jets and contacts, and all remaining bosonic/exterior integrations. Do not recreate that identity as the next certificate.

Section6 specifies the actual candidate theta and the full even gauge-invariant half algebra A_+, with a full exterior reflection matrixS. The derived form is

`H(F,G)=I[exp(S_g) theta(F)G]/Z`,

represented through `B_CA(w,z)=[K(z,kappa w;0)S^-1]_(A,C)/Z` on `f0(A_+)`. This is the exact source-matched target. ThetaS4=S4 is established, but thetaS2 invariance is not assumed. ThetaS2 noninvariance ALONE is not a negative witness: its difference could annihilate the tested physical image. The actual normalized pairing must be evaluated/identified there.

The identity/reviews explicitly leave fullZ, actual kernel values, Hermiticity, positivity and periodic thermal/transfer interpretation open. They distinguish the physical image from the ambient boundary coefficient space. A negative ambient vector with no actual preimage F in the required algebra is not a physical counterexample. A few positive minors do not certify the whole required algebra.

The newest notebook, lines155–157, records the next finite-image/Hermite-degree64 idea as PROSPECTIVE and NOT ACCEPTED. The current boundary identity section7 gives safe polynomial bounds, but explicitly does not truncate arbitrary physical half-observables. In the bounded relevant notebook/identity/review/source reads, I found accepted boundary correspondence and supporting matrix/Gram APIs, but no already accepted whole-physical-image finite-projection certificate to reuse unchanged. This is an intake boundary, not a proof of source/history/Lean nonexistence. No broad harness search was performed.

## 5. Requirements for the prospective finite certificate

1. Preserve the actual action, sources and theta image. Work from the accepted boundary identity and the original closed periodic fullS4 action; retain all64 physical links,128 Grassmann generators,256auxiliary coordinates, both interfaces, full contacts and every source-required observable. Specify the coupling/source domain prospectively. Do not discard an unfavorable observable by selecting a convenient subspace.

2. Prove the proposed GLOBAL total-Hermite-degree64 reduction as a Gaussian-annihilator statement, not an assumption about independent halfweights. For observables independent of artificial h, the full Berezin-integrated exp(h.T) with insertions has h degree at most64 because each h consumes one fermion bilinear. Hence high total Hermite modes of the full signed weight may be annihilated against that actual finite test space. The proof must handle products of all site weights, both arguments/contacts and source jets, and preserve all U-dependent coefficients. Degree64 truncation of each W_x separately and a global orthogonal total-degree projection are different operations; multiplying individually projected factors can reintroduce errors. This is a proof target, not an already computed certificate.

3. Construct a FINITE projection/quotient that preserves H(F,G) for EVERY F,G in the required A_+, and prove its image is exactly the claimed finite physical image. An auxiliary Gaussian projection alone does not bound arbitrary physical spatial-link polynomial observables. Use actual finite kernel degree, Haar polynomial relations/orthogonal moments and exterior occupancy to justify the finite moment space. The projection must preserve gauge invariance/equivariance and be compatible with theta/kappa; a convenient coefficient truncation or ambient vector projection need not preserve the physical image. Establish the annihilator in BOTH arguments and all linear relations, rather than choosing favorable directions.

4. Produce actual physical representatives for a spanning set. If Fi span the entire projected image and every relation is a two-sided null relation of the form, prove `H(F,G)=c(F)^* M c(G)` with M_ij=H(Fi,Fj). Include the constant observable and show H(1,1)=1 wherever fullZ!=0. A list of all ambient monomials only suffices if its physical gauge-invariant image and representative map are proved. Ambient positivity can be sufficient, but an ambient negative direction needs a verified physical preimage to become a witness.

5. Keep full nonzero normalization separate from positivity. A complete exact fullZ value, rigorous complete signed-remainder bound, or a complete nonzero good-prime residue with denominator/correspondence proof can certify nonvanishing. A zero residue, positive selected word, fixed-real-h determinant norm, Haar Gram positivity or conditional Lean exponential lemma cannot. A nonzeroZ certificate alone does not show Z>0 or a physical state, and pureg2 G remains0 wherever normalized by the already accepted all-volume parity.

6. State the actual matrix endpoint. To certify the declared finite image, prove M Hermitian and positive semidefinite on the complete image/quotient, with the actual normalization and source map. To disprove it, supply an explicit F (or finite physical combination) whose normalized H is nonreal/non-Hermitian or negative under the stated real-domain conventions; track all coefficient and source preimages. ThetaS2 noninvariance or an unphysical negative coefficient vector is not sufficient. A physical positive state also requires the periodic boundary/trace interpretation and observable product/adjoint correspondence; matrix positivity alone does not establish continuum or real-time dynamics.

7. Reuse MixedState/PSD square-root APIs only downstream of these premises. Independent producer-separated math review must check finite projection/annihilator/gauge/image/normalization identities; independent physics/source review must check the required observable algebra, original action, source/adjoint/boundary interpretation and domain. The result remains finite N16 evidence. Controlled volume/continuum/source-selection limits, physical body and matter matching, B3 gradient normalization/chi range, tensor pole/light cone and retarded transport remain open. New numerical/native execution requires separate admitted source/resource/slot contracts.

No statement here imports Vergeles's assumed Minkowski Hilbert structure or conditional FermionBag4D/MixedState positivity as the missing N16 certificate. The next useful deliverable is the actual source-matched finite-image reduction and its complete certificate/witness conditions, not another proof of generic positive factors and not selected k4 accumulation.
