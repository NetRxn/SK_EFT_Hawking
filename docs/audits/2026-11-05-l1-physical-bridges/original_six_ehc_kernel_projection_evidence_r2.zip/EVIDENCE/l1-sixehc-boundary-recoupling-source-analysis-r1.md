# Independent source check: pair recoupling and complete projected bulk

Task l1-sixehc-aggregate-kernel-r1; source9ac8bd5680cfaa774fb4e24b79a32593b07e49bc; parent publicationROOT01a13f67/L1-physical-observable-boundary. Own this private report only; preserve prior reports. FIRST same-packet check returned exit0, fresh=true, changed=[]. This is manual proof/source analysis, with no generated R/B/W, masks, moments, code import/execution or tests. No new peer report was read. The lead supplied explicit candidate H/V/t formulas as mathematical inputs, not an adopted verdict; they are checked below.

ACCEPT the recoupled bulk preparation and scalar prefactor with the literal conventions below. No complete fundamental-core tensor, aggregate amplitude, sign, cost fit or runtime permission is established.

## Check the new mixed-H and top normalization

Use E12=+1, q_A=(-i sigma1,-i sigma2,-i sigma3,I), and the original bars-before-psis/chiral-top orientation. Define

M^A=bar_R q_A† psi_L, N^A=bar_L q_A psi_R,
B^A=bar_R q_A† E bar_L^T=bar_L q_A E bar_R^T,
P^A=psi_L^T E q_A psi_R.

The equality in B follows from the held quaternion/epsilon intertwiner and the odd bar swap; it is not a commutation of gamma through a link. Applying normalized SU2 second moments to the literal unequal-endpoint F_x,F_y gives

H_xy^(AB)=M_x^A M_y^B+N_x^A N_y^B-B_x^A P_y^B-P_x^A B_y^B.  (1)

One way to audit the four structures is to retain both chiral groups in F_xF_y: forward/backward terms give half of MM or NN per permitted group, combining to unit coefficients; forward/forward terms contract the two dagger matrices by epsilon and give -BP; backward/backward gives -PB. Cross-group linear means vanish. The original gamma index A stays at x and B at y. Equation(1) also reproduces the independently checked coefficient -1 of bar_x,L2 bar_x,R1 psi_y,L2 psi_y,R1 in H^33: it comes from -B_x^3 P_y^3. Its physical P=H/8 coefficient is -1/8, not a same-endpoint scalar K pattern.

For V=(M+N, i(M-N), B-P, i(B+P)), direct expansion gives

H_xy^(AB)=(1/2)sum_a eta_a V_x,a^A V_y,a^B,
eta=(+1,-1,+1,+1).                                      (2)

Indeed the first two V products combine to2(MM+NN), and the last two to-2(BP+PB). These V are sharp-Hermitian in the held adjoint. This is algebraic gauge-covariant multiplicity space, not a positive physical norm.

The literal natural-basis oriented contraction is

I M^A N^B B^C P^D=-Tr(q_A q_C† q_B q_D†).                  (3)

For an explicit sign audit, the unsorted factor types are (barR,psiL,barL,psiR,barR,barL,psiL,psiR). Sorting to tau_L tau_R requires odd parity, and pairing the local two-component tops with E reduces the result to the stated minus trace. For four distinct labels, the quaternion trace is -2 epsilon_ABCD; for example A,B,C,D=0,1,2,3 gives trace-2. Therefore epsilon contraction in the natural(M,N,B,P) basis is48. The V change of basis has determinant(-2i)(2i)=4. Thus the exact held top constant is

I epsilon_ABCD V_a^A V_b^B V_c^C V_d^D=192 epsilon_abcd.    (4)

This checks t=192 and C_H=eta/2, including their normalizations. All original physical free-edge pairs are H/8=(1/16)sum eta V V.

## Both ends are antisymmetric, with actual site/slot order

The bulk's six outer boundary pairs were already alternating. The CORE pairs also alternate: at0/4 the two free coframe slots are the EHC complementary frames1,3 and their coefficient F_CD is antisymmetric; at3/7 the two free D slots are axes0,3; at9/13 they are axes0,1. The V factors are degree2 and commute. Exchanging their multiplicity labels and dummy internal vector indices therefore changes the F_CD or D epsilon sign once. Source/curvature factors are untouched. This proves pair antisymmetry even before the remaining core integration.

Fix each pair in ascending WORLD slot order, and its stored color pair a<b. Use lower bulk triple(2,8,11), upper bulk(6,12,15), lower core(0,3,9), upper core(4,7,13). Alternative orders such as(2,11,8)/(6,15,12) are permitted only with explicit matching permutations of B, D and R, not a silent transposition.

The twelve cross edges are exactly two6-cycles:

0–2–3–11–9–8–0,
4–6–7–15–13–12–4.

They are related by xor4, preserving every world slot. Let E_alpha(i,j) be the unscaled integer antisymmetric basis, +1 at (a,b), -1 at (b,a), zero otherwise for alpha=(a<b).

For the lower cycle label its consecutive edge colors a,b,c,d,e,f. The ORIGINAL slots give the explicit contraction

R_(alpha2,alpha8,alpha11; beta0,beta3,beta9)
 =sum_(a..f) E_alpha2(b,a) E_alpha8(e,f) E_alpha11(d,c)
                  E_beta0(a,f) E_beta3(b,c) E_beta9(e,d).  (5)

The upper R has identical convention under xor4. Each side has6^3=216 labels. Equation(5), rather than an abstract six-cycle, fixes the nontrivial orientation sign.

A useful manual control is R(all alpha=all beta=(0,1))=-2. There are exactly two alternating edge-colorings; each contributes minus in the displayed world-slot convention. A convention reporting +2 must declare its compensating pair orientation changes before it can be compared. No sign may be silently removed on the ground that there are two cycles.

For each fixed alpha triple its three E factors have2^3=8 assignments; these specify one beta triple and sign if all core pairs have distinct colors, otherwise zero. Consequently row nonzero count<=8 and row absolute coefficient sum<=8. The same argument from core to bulk gives the column bounds. Each entry has magnitude<=8 and at most1728 raw signed contributions build the complete R. Both literal copies cost<=3456 contributions. These are manual upper bounds, not generated sparse tables.

## Why recoupling includes the orientation sums

A stored alternating tensor T_alpha reconstructs its ordered tensor as sum_alpha T_alpha E_alpha(i,j), without a1/2. Substitute this identity at ALL six bulk and ALL six core boundary vertices into the original twelve ordered edge-color sums. The six contractions per cycle are exactly(5). Therefore R_lower tensor R_upper automatically sums every allowed edge orientation, including the2^6 pair orientations that appeared explicitly when closing against an arbitrary ordered core tensor.

There is NO additional2! in R, in the core stored values or in the final scalar. This does not contradict the previous warning: that warning concerned multiplying a stored alternating bulk tensor directly by a core tensor without the E-basis reconstruction/ordered contractions. If instead a normalized exterior basis is chosen, BOTH R and its dual convention must change consistently.

## D, full scalar factor and exact matrix expression

Absorb the four incident eta matrices at EVEN bulk vertices10,6,12,15. Their determinant is-1, so the four vertices contribute(-1)^4=+1. The only remaining eta factors are on boundary edges ending at ODD bulk sites2,8,11. On an unordered pair alpha=(a<b) the second compound of eta is the sign eta_a eta_b. Thus D is diagonal on the lower bulk triple, with D_alpha the product of these three signs. There is no remaining eta on upper bulk sites6,12,15; it has already been absorbed at those even vertices.

Let B be the complete46656-cell pure-book tensor from the previous source report, in the pair order declared here. Then the complete projected bulk attached to the core pair grouping is

W=R_lower^T D B R_upper.                                  (6)

The physical free-edge factor is16^-22, from all22 mixed pairs in(2). Eight bulk tops give192^8=3^8*2^48. Therefore their total magnitude factor is

192^8 *16^-22 =3^8*2^-40.                                (7)

Equivalently, using H/8 with C_H=eta/2, the four even determinant absorptions give t^8 det(C_H)^4/8^22=3^8*2^-34; the three remaining odd pair-compounds each contribute1/4, giving the same2^-40. These are two derivations of the SAME factor, not factors to multiply together.

Define Ccore_beta as the literal eight-core-site oriented-top integral with the twenty remaining core coframes still carrying ORIGINAL quarters, actual four D singles3/7/9/13, all six unit EHC epsilon/gamma/holonomy factors, source(Q0+Q4)(Q1+Q5), and both independent anchors on all ten curved edges. Replace ONLY the twelve free-edge core-end coframe slots by the V factors in their original internal world slots. Evaluate its six stored beta pairs at a<b in the world-slot convention above. It contains no remaining free-edge C_H or1/8 factors; all22 physical pair factors are already in(7). It is not a generated tensor in this review.

With precisely that definition, the original coefficient is

h12,6=8*3^8*2^-40 sum_beta W_beta Ccore_beta.               (8)

The outer8 is the accepted source-sector coefficient, not a new local normalization. Equation(8) retains the exact fundamental core, shared fields and weighted trace indices; it is not an adjoint R replacement or a physical projection.

## Complete bounded bulk certificate and remaining frontier

The complete B has46656 cells, <=32 signed attempts/cell and |B|<=32, giving1492992 attempts. Each of the two216x216 sparse R transforms costs at most46656*8=373248 multiply-adds, hence746496 total. D is a sign operation. Adding both R constructions gives the complete structural ceiling

1492992+746496+3456=2242944 attempts/products.              (9)

It includes ALL projected bulk boundary cells, rather than one favorable slice. Using only the looser facts<=8 nonzero R entries per row/column and coefficient magnitude<=8 gives |W|<=32*(8*8)^2=131072. Exact signed32-bit output has46656*4=186624 numeric bytes, with bounded separately declared metadata; exact accumulation and pre-serialization checks remain required. A stronger bound follows from the row/column absolute-sum<=8 fact, but is not needed to justify signed32. Negative values and the R=-2 control must be preserved. Actual elapsed/RSS and implementation overhead are UNKNOWN. No program, table or runtime request is produced here.

This is a COMPLETE bounded projected-bulk target, conditional on freezing the literal definitions/controls and independently reviewing prepared code/spec before any ROOT admission. It does not cost Ccore: all64 curvature-chiral assignments, actual spinor/anchor indices, local odd masks, correlated fourth moments and shared-field top closures remain there. The scalar(8) is not evaluated; neither W nor Ccore alone determines its sign. A final core plan still needs complete index/slice coverage, intermediate row/product/width bounds and refusal semantics. No guard increase, generic engine, favorable subset, retry or false partial-zero claim is authorized.

All original h=1 denominator/uncapped reflection/source/Bopp/log contacts, time0/1 placement, Lambda/tail premises and physical TT/projector/positive-boundary/product/adjoint/seam/causal propagation/matter/EM/calibration/B3 obligations remain open. This source-exact recoupling is an algebraic finite-coefficient advance, not a physical state construction.

Final fresh packet result and own hash/bytes accompany delivery. Only this report was written; prior reports and all science/notebook files were preserved.
