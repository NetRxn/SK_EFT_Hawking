# Independent signed mixed-endpoint control

Task l1-sixehc-amplitude-plan-r1; source8efe7d579f993b18b807aea75cd600f494b67cc1. Own this private report only. FIRST packet check returned exit0, fresh=true, changed=[]. No current sector actual verdict was read. No table, chirality inventory, executable/import, moment program, test or scientific run was performed. This is a manual two-term original second-moment derivation, not an amplitude result.

ACCEPT the stated control: for x<y, internal A=B=3 with q3=I2, the coefficient of

M=barpsi_(x,L2) barpsi_(x,R1) psi_(y,L2) psi_(y,R1)

in the physical original pair P_xy^33=Haar[T_x^3 T_y^3] is -1/8. Consequently its coefficient in32 P_xy^33 is -4.

## Literal endpoint and chirality check

Original normalization construction section3 equations2–3 specifies, for independent anchored Spin(4) variables U,V,

F_x^3(U)=barpsi_x gamma3 U† psi_y-barpsi_y U gamma3 psi_x,
F_y^3(U)=barpsi_x U† gamma3 psi_y-barpsi_y gamma3 U psi_x,
T_x^3=(F_x^3(U)-F_x^3(V†))/4,
T_y^3=(F_y^3(U)-F_y^3(V†))/4.

Gamma3=[[0,I2],[I2,0]] with L the upper chiral block. Hence the positive first term of F_x is

barpsi_(x,L) U_R† psi_(y,R) + barpsi_(x,R) U_L† psi_(y,L),

whereas the positive first term of F_y is

barpsi_(x,L) U_L† psi_(y,R) + barpsi_(x,R) U_R† psi_(y,L).

The chiral distinction between gamma3 U† and U† gamma3 is essential. The latter is not obtained by commuting gamma through the link. Negative terms contain a bar at y and a psi at x, so cannot contribute to M. No contraction or field elimination turns them into M.

The only U_L contribution to M is

[barpsi_(x,R1) (U_L†)12 psi_(y,L2)]
[barpsi_(x,L2) (U_L†)21 psi_(y,R1)].

To put it in the displayed held order, move barpsi_(x,L2) past psi_(y,L2) and barpsi_(x,R1): two swaps, sign+. Normalized SU2 Haar gives integral (U†)12 (U†)21=-1/2. Thus this contribution is -M/2.

The only U_R contribution is

[barpsi_(x,L2) (U_R†)21 psi_(y,R1)]
[barpsi_(x,R1) (U_R†)12 psi_(y,L2)].

Move barpsi_(x,R1) left past psi_(y,R1), then put psi_(y,L2) before psi_(y,R1): two swaps, sign+. Its moment is again -1/2, so it contributes -M/2. This is the ordinary epsilon second moment, including the dagger; it can also be read directly from U=[[a,b],[-bar b,bar a]], where (U†)12(U†)21=-|b|² and integral|b|²=1/2. This is a symbolic identity, not numerical integration.

Cross-chiral products have zero mean because the L/R Haar factors are independent and their individual linear means vanish. No other field index can produce this fixed monomial. Therefore coeff_M H_xy^33=-1.

## Physical two-anchor normalization

For the physical pair, cross-anchor terms have zero mean independently. The U term and the V† term have identical Haar integrals by Haar inversion invariance. Their signs in the product are both positive. The coframe quarters give

P_xy^33=(1/16)(H_xy^33+H_xy^33)=H_xy^33/8.

Thus coeff_M P=-1/8. The factor2/16 has already counted both independent anchors. Applying another factor2, another quarter, a same-endpoint delta K substitution or a local top sign would be an error. This is an open polynomial coefficient with site bars before psis, not a saturated top expectation. In particular this monomial could not occur in the same-endpoint scalar K, whose endpoint chirality pattern differs; it is a useful control of actual mixed-endpoint structure.

The proposed future dense physical mixed table has16 ordered AB entries times28 degree-two masks at x times28 at y =12544 possible cells. A conservative literal numerator expansion has at most32 terms in each F, hence16*32²=16384 raw products before moment/overlap elimination. These are preparation counts, not generated tables, measured time/RSS, full-network cost or permission to execute. Scale32 is compatible with the physical second-moment/quarter denominator and the control gives the exact nonzero entry -4; a full implementation must freeze the complete basis/index ordering, original gamma phases and scale proof, then receive independent static review and ROOT admission.

This control certifies neither positive H nor an amplitude sign. It preserves all independent anchor/chirality indices, full source contacts and the physical boundary obligations. Final continuity result and report SHA/bytes are supplied in delivery. No notebook, source or peer-owned file was changed.
