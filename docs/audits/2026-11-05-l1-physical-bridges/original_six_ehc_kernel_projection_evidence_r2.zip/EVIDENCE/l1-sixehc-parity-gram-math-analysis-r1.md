# Exact parity blocks, Gram compression and a signed projected scalar

Independent MANUAL PREP/PROOF analysis for l1-sixehc-aggregate-kernel-r1, parent publicationROOT01a13f67/L1-physical-observable-boundary, source9ac8bd5680cfaa774fb4e24b79a32593b07e49bc. FIRST SAME check of the assigned primary packet returned exit0, fresh=true, changed=[]. Own only this new private report. Both earlier mixed-kernel and boundary-recoupling reports are preserved unchanged. No peer new report was read. No scientific execution/import/Haar/moment/tensor/mask/CAS generation, test/build/Lean/native/slot/controller/Git action or source/notebook/repository/packet write occurred. All statements below are manual mathematics, requiring independent ACTUAL review before canonical adoption.

ACCEPT the refinement. The exact projected boundary tensor has eight parity blocks containing5856 ordered cells in total. It is a signed Gram matrix blockwise. A complete proposed T/R/G/W certificate has a safe204672 logical-attempt bound, final |W|<=512 and signed16 payload11712 bytes. In the fully specified original boundary ordering, the core star triple beta=((0,1),(0,2),(0,3)) has W_beta,beta=-2. This is an actual projected-weight identity proved manually, not a computed full aggregate amplitude or physical positivity/no-go conclusion. Correlated core coefficients and the full scalar remain UNKNOWN.

## 1. Fixed conventions and exact source boundary

Retain the accepted original identity

 h12,6=8 I Haar[(Q0,22+Q4,22)(Q1,22+Q5,22) Pi*],
 Pi*=(prod_{z notin{0,1,4,5}}D_z) E0,02 E4,02 E1,12 E5,12 E1,23 E5,23.

Keep the original64 independent anchors,128 odd variables, gamma/quarter/top/world signs, sources, both kernels and uncapped reflection/normalization/Bopp/log contacts. The preceding manual report derives physical mixed Pxy=Hxy/8 with Hxy=sum C_ab Vx,a Vy,b, C=diag(1,-1,1,1)/2, local oriented top t=192. Color labels0,1,2,3 here refer to V1,V2,V3,V4 respectively; hence eta=(1,-1,1,1) has its negative at color1.

Outer sites are{2,6,8,10,11,12,14,15}. Bulk lower pair slots are at(2,11,8), upper at(6,15,12), all in increasing local world order. Core lower pair slots are at(0,3,9), upper at(4,7,13). A canonical pair a<b is represented by E_(a,b)[i,j]=delta_ia delta_jb-delta_ib delta_ja. The exact oriented cycle map R is the one in the preceding report, with lower cycle edge colors c0,...,c5 along0--2--3--11--9--8--0:

 R_alpha,beta=sum_c E_alpha1[c1,c0] E_alpha2[c3,c2] E_alpha3[c4,c5]
                         E_beta1[c0,c5] E_beta2[c1,c2] E_beta3[c4,c3]. (1)

Upper is the identical translated map. These orders are essential to the scalar sign below. Reconstruction uses canonical antisymmetric products, with no additional2! or2^6 factor. All22 physical mixed-edge1/8 factors and the three odd-leaf Lambda² C factors give the original outer scalar3^8*2^-40, with their remaining eta-pair signs carried by D. The actual curved core remains the literal eight-site/twenty-anchor/20T+12V object defined previously.

## 2. Complete parity blocks, by combinatorial proof

For a canonical pair alpha let mask(alpha)=unit_a xor unit_b in four color bits. For an ordered triple define kappa(alpha)=xor of its three pair masks. Only even-weight masks occur:0,1111 and the six weight-two masks.

At every bulk epsilon, each of the four colors occurs once. There are eight bulk vertices, so the total multiplicity of each color is even. Internal edges count their color twice. Therefore the twelve boundary colors must have even total count, proving

 B_alpha,delta=0 unless kappa(alpha)=kappa(delta).               (2)

In the six-cycle map every edge color is counted once on the bulk side and once on the core side. Thus nonzero R_alpha,beta implies kappa(alpha)=kappa(beta). This is a termwise necessary identity, not cancellation inferred from a numerical tensor.

The216 ordered triples split into n0=24, n1111=24 and n_pair=28 for EACH of six pairs. Regard the three pair labels as edges of K4 counted modulo2. Kappa0 requires three distinct edges forming a triangle:4*3!=24. Kappa1111 requires three distinct edges forming a star:4*3!=24. For fixed odd-degree endpoints a,b, the weight-two block has one triple all equal to ab; fifteen triples with two copies of one of the five other edges and one ab; and twelve ordered triples from the two length-three simple paths joining a,b. Total1+15+12=28. These exhaust repetitions and distinct-edge cases.

Consequently the projected W has only

 sum_k n_k²=24²+24²+6*28²=5856

potential ordered cells. Its other40800 entries vanish identically by parity, without generating a catalogue.

The lower odd-bulk eta sign is

 D_alpha=(-1)^(kappa(alpha)_bit1).

It is constant on each block, denoted D_kappa. This matters: it may commute through the parity-preserving recoupling as a block scalar, rather than remaining an uncontrolled sign inside a sum.

## 3. Exact half-bulk tensor and Gram identity

For a canonical pair define J_alpha[p,s]=epsilon_{p s a b}. The three length-three paths are indexed by their outer axis d=0,1,3; their middle edge has world axis2. A triple alpha in bulk order(2,11,8) corresponds to path labels

 alpha_d0=alpha2, alpha_d1=alpha3, alpha_d3=alpha1.

For lambda=(c,s0,s1,s3), define

 T_lambda,alpha=sum_{p0,p1,p3}
 epsilon_{p0 p1 c p3} product_{d=0,1,3} J_(alpha_d)[p_d,s_d].   (3)

The world-slot permutation signs at the three leaves are(-,+,-) for path axes(3,1,0); their product on each half is+. Thus (3) uses the literal original half-bulk orientation, not an unspecified square root of B. Summing the common central color c and three path-middle colors s_d glues the two identical halves and proves

 B=T^T T.                                                     (4)

All quantities are real integers; T is not a physical Hilbert embedding.

Each J has exactly two nonzero ordered(p,s) assignments, each of magnitude1. Fix alpha and choose the three p's: at most2³=8 choices. Each choice uniquely determines all three s's. If the p's are not distinct the hub epsilon kills it; if distinct, exactly one c remains and its coefficient is+/-1. Different choices cannot give the same lambda, since each s_d uniquely determines its complementary p_d for fixed alpha_d. Therefore T has entries0,+/-1 and at most8 nonzeros per column, with no duplicate contribution at an entry. This immediately sharpens |B_alpha,delta|<=8, by overlap of two columns or Cauchy--Schwarz.

Using mask(alpha_d)=1111 xor unit_p_d xor unit_s_d and the hub's three distinct p's gives

 kappa(alpha)=unit_c xor unit_s0 xor unit_s1 xor unit_s3.       (5)

Thus T has compatible row blocks. Among the256 possible lambda tuples, m0=40 (four equal colors or two copies of each of two colors), m1111=24 (each color once), and m_pair=32 for each weight-two mask. For fixed pair a,b the latter count is8 from multiplicities(3a,1b)/(1a,3b), plus24 from one a, one b and two copies of either of the other two colors. Counts40+24+6*32=256 exhaust the row domain.

Block-dense T storage has sum m_k n_k=40*24+24*24+6*32*28=6912 entries, not256*216. Formula(3) constructs its actual sparse values in at most216*8=1728 candidate choices.

## 4. Projected Gram, full cost and safe integer bounds

R has at most8 raw signed contributions in every row AND every column, hence row/column l1 norm<=8 after aggregation. Let G=TR, restricted to the matching parity blocks. The exact projected bulk therefore satisfies

 W_kappa = D_kappa G_kappa^T G_kappa.                          (6)

The eight blocks are positive or negative semidefinite as ordinary real coefficient matrices according to D_kappa. They are not positive physical boundary forms; their color coefficients will still contract with a different correlated original core tensor. No physical time/reflection/product/adjoint statement follows from (6).

A complete bounded preparation/certificate algorithm can use:

 - T construction:216*8=1728 choices;
 - R construction:216*8=1728 cycle color choices;
 - G=TR: at most216*8*8=13824 signed products using raw R contributions and sparse T columns;
 - ALL ordered Gram entries:sum_k m_k n_k²
   =40*24²+24*24²+6*32*28²=187392 products.

Total204672 logical choices/products. This includes ALL blocks and ALL ordered output cells; no symmetry factor or favorable subset is assumed. Row initialization, schema/manifest/serialization and interpreter operations are additional. The total is not measured timing, machine-instruction count, RSS or runtime permission. A future exact program/spec must freeze the implementation bounds and receive independent static review plus a new ROOT admission.

Since a T column has norm<=sqrt8 and every R column has l1<=8,

 ||G_column||<=8sqrt8,
 |W_beta,gamma|<=512.                                        (7)

Equivalently use |B|<=8 and both R column l1 bounds in R^T D B R. This also bounds the sum of absolute scalar terms in a Gram accumulation by512 via Cauchy--Schwarz; it is not merely a final post-cancellation bound. G entries have absolute value<=8. Unbounded integer accumulation with explicit serialization checks is preferable, but signed16 suffices for these mathematical coefficients and final W.

The full5856-cell W payload is11712 signed16 numeric bytes. Block-dense T and G each have6912 entries and fit signed8 by their respective bounds1 and8, totaling13824 further numeric bytes. Combined T/G/W numeric payload is25536 bytes, excluding sparse R indices, tuple maps, manifests, buffers and interpreter storage. RSS and complete curved-core cost remain UNKNOWN. No B matrix need be materialized in this route.

## 5. Exact signed scalar W_beta,beta=-2

Take the CORE triple beta=((0,1),(0,2),(0,3)) in vertex order(0,3,9), identically upstairs. It has kappa1111 and D_kappa=-1. This is a definite tensor coordinate in the original ordered boundary, not an arbitrary basis projection chosen to claim a full amplitude sign.

Fixing its three E factors in (1) gives8 candidate cycle assignments. Requiring unequal colors in each bulk pair leaves exactly two:

 - (c0,c1,c2,c3,c4,c5)=(0,2,0,3,0,1), producing bulk alpha=((0,2),(0,3),(0,1));
 - (c0,c1,c2,c3,c4,c5)=(1,0,2,0,3,0), producing bulk alpha=((0,1),(0,2),(0,3)).

For each, the product of all six ordered E signs is-1. Thus R_column,beta has exactly two entries-1, at A=((0,1),(0,2),(0,3)) and B=((0,2),(0,3),(0,1)). There are no contributions from stars of other centers.

In lambda=(c;s0,s1,s3) notation, evaluate (3) with the held path ordering:

 T_A: (0;3,1,2) -> -1, (0;1,2,3) -> +1;
 T_B: (0;2,3,1) -> +1, (0;1,2,3) -> -1.

All other entries vanish. For example T_A at p=(1,2,3), c=0 has hub epsilon epsilon1203=+1 and J02[1,3],J03[2,1],J01[3,2] all negative, giving-1. This fixes the otherwise delicate world/transpose sign without an executed tensor calculation.

It follows that G_column,beta=-T_A-T_B has exactly two nonzeros: +1 at(0;3,1,2) and-1 at(0;2,3,1). Its squared norm is2. Equation(6) proves the exact scalar

 W_beta,beta=-2.                                             (8)

This confirms a nonzero projected boundary weight analytically, with its actual negative block sign. It does NOT prove that the actual core component at beta is nonzero, that all other contractions have the same sign, or that the complete scalar is negative. A single component must not replace the sum over5856 core boundary cells.

## 6. Exact next frontier and decision

Using the literal original core coefficients defined in the preceding report, the full coefficient is still

 h12,6=8*3^8*2^-40 sum_{beta,gamma} W_beta,gamma C_core,beta,gamma. (9)

Parity now restricts this sum to matching kappa blocks, and W is signed Gram blockwise. Neither core positivity nor a Gram-square pairing with G has been proved. The core preserves the six unit EHC factors, sources(Q0+Q4)(Q1+Q5), D3/D7/D9/D13, twenty internal coframe quarters, twelve inserted V components, twenty independent curved anchors and the full eight-site top. Shared fields and joint normalized degree-four Haar moments remain essential. No marginal/independent second-moment approximation is admissible.

Recommendation: freeze the analytic closed-kernel/recoupling/parity-Gram proof for fresh ACTUAL review. The exact scalar(8) already meets a substantive projected-support target without execution. If all projected weights are needed for the next core design, prepare the complete5856-entry block certificate via T/R/G, with the stated basis/orders, (8), prior R all-pairs01=-2 control, and prior pure-B0/2 controls. It is a concrete small first computation proposal; it has not been executed or admitted. Then design the complete original core pairing with exact local chiral/exterior support and correlated Haar weights. The5856-entry output shape does not by itself bound constructing the core coefficients or its worst intermediate joins.

The sign/value/nonzero/zero status of h12,6 remains UNKNOWN. All physical TT/Ward/projector/pole, positive boundary-product-adjoint-seam/causal transfer, microscopic matter/EM/transport/calibration/B3 and limit obligations remain OPEN. A negative projected coordinate is not a full physical no-go; a signed Gram coefficient block is not an original physical state.

## 7. Continuity and preservation

Only this assigned report was written. The FIRST adapter command was `python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/l1-sixehc-aggregate-kernel-r1.json` from the assigned checkout. Final SAME check, exact report SHA/bytes and unchanged earlier-report hashes are supplied with delivery. No new runtime or publication authority is inferred.
