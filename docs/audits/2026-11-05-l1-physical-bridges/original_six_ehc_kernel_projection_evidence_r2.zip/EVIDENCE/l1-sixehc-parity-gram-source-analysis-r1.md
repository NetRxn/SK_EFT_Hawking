# Independent source check: parity blocks and signed Gram bulk

Task l1-sixehc-aggregate-kernel-r1; source9ac8bd5680cfaa774fb4e24b79a32593b07e49bc; parent publicationROOT01a13f67/L1-physical-observable-boundary. Own ONLY this report; prior reports, source and notebook preserved. FIRST fresh packet check returned exit0, fresh=true, changed=[]. No new peer report read. This is manual finite combinatorial proof/source analysis: no R/B/T/G/W table, chirality/mask/moment/network inventory or scientific executable was generated/evaluated/run.

ACCEPT the parity/Gram refinement with the literal basis/world ordering fixed in the previous boundary-recoupling report. The complete projected-bulk work ceiling is204672 candidate attempts/products, the signed output domain5856 cells, and one exact diagonal control is-2. These are mathematical bounds and manual scalar certificates, not elapsed/RSS or execution admission. The correlated fundamental core remains uncomputed and without a complete contraction-cost qualification.

## Exact parity and completeness

Use colors0,1,2,3, eta=(+1,-1,+1,+1), and unscaled E_alpha for alpha=(a<b). Let kappa(alpha0,alpha1,alpha3) be XOR of the three pair incidence bitmasks. It has even weight, so there are8 possible syndromes.

At any original bulk epsilon vertex the four incident colors are all distinct. Each internal color appears twice when all bulk vertices are counted, so the XOR of the twelve boundary colors is zero. Therefore B_alpha,beta=0 unless kappa(alpha)=kappa(beta). The same edge-count argument applies to the six-cycle R, since each edge color appears in two E factors, proving R preserves kappa. This is a multiplicity-color constraint, not a new physical chirality selection or spacetime momentum.

The216 ordered triples of unordered pairs have sector sizes:

- kappa0:24, the4 triangle edge sets times6 orders.
- kappa1111:24, the4 star edge sets times6 orders.
- each of6 two-color syndromes:28. For a fixed endpoint pair there is one triple of that repeated edge, fifteen triples consisting of another edge twice plus that edge once, and twelve distinct-edge path triples (two three-edge paths times6 orders).

Hence total216 and sum n_kappa²=24²+24²+6*28²=5856. This accounts for every projected boundary triple once; it is not selected support from a generated table.

The leftover boundary eta signs in the literal lower-bulk slots2,8,11 are D_kappa=(-1)^(kappa's color1 bit). They are constant within a sector. The slots may be permuted consistently with B/R, but the syndrome is unchanged. The upper even-bulk eta factors were already absorbed through four determinant identities.

## Exact Gram factorization without a boundary normalization change

Retain the three path directions d=0,1,3 and central direction2. Define

T_(lambda,alpha)=sum_(p0,p1,p3)
 epsilon_(p0,p1,c,p3) product_(d=0,1,3) J_alpha_d[pd,sd],
lambda=(c,s0,s1,s3), J_(a<b)[p,s]=epsilon_(p,s,a,b).

Each J has exactly two entries. Three J choices give at most8 candidates per alpha. A nonzero central epsilon requires the three p's distinct, and c is their unique missing color; no extra4-loop is needed. Each retained lambda is unique for these choices and its T entry is+1 or-1. Thus each T column has at most8 entries and squared norm<=8.

Summing over lambda joins the two outer vertices along each path and the common central edge. The actual central world slot orders are the same on both sides. Outer slot permutation signs were respectively-,+,- on EACH half, whose product per half is+. Thus the original pure-book tensor is exactly B=T^T T, without a hidden world sign or pair normalization.

At each J, pair-mask alpha equals1111 XOR unit(p) XOR unit(s); combine the three J identities with the central epsilon identity. This gives

kappa(alpha)=unit(c) XOR unit(s0) XOR unit(s1) XOR unit(s3).

Consequently T has the same syndrome blocks. Counting all256 lambda tuples gives row-sector sizes m0=40 (four equal colors, or two copies of each of two colors), m1111=24 (all four distinct), and m_pair=32 for each of6 pairs. For a specified pair a,b, the latter consist of8 words of type3a1b/1a3b plus24 words with one a, one b and two copies of a different color. These m's are safe complete row domains even where the actual T row is zero.

With R the literal world-ordered cycle tensor in the prior report, let G=T R. Then

W_kappa=D_kappa G_kappa^T G_kappa.                         (1)

This uses R's parity preservation to commute the sector sign. It is a signed Gram identity in formal boundary multiplicity coordinates. It is NOT positivity of the original measure, physical boundary, matter Hilbert state or complete source amplitude; the actual core still has to be contracted against W.

## Literal manual diagonal control -2

Use the same lower cycle edge colors a=0–2,b=2–3,c=3–11,d=11–9,e=9–8,f=8–0, with boundary pair slots ascending in world axes. Core triple beta at sites(0,3,9) is((0,1),(0,2),(0,3)). The source-exact cycle formula is

R=sum E_alpha2(b,a) E_alpha8(e,f) E_alpha11(d,c)
           E_beta0(a,f) E_beta3(b,c) E_beta9(e,d).

Each core E permits two orientations. Nonzero bulk pairs exclude equal adjacent colors. These conditions leave exactly two assignments; their bulk triples in order(2,8,11) are

alphaI=((0,2),(0,1),(0,3)),
alphaII=((0,1),(0,3),(0,2)),

and both cycle signs are-1. This is a short manual orientation argument, not generated support.

In T use path order(0,1,3), so the noncentral colors of these two star triples are respectively(3,1,2) and(2,3,1). Each T column has two entries, both with c=0. They share lambda=(0;1,2,3): T_alphaI=-1 and T_alphaII=+1 there. The other entries are lambda=(0;2,3,1) with T_alphaI=+1 and lambda=(0;3,1,2) with T_alphaII=-1. Multiplying both columns by their R coefficient-1 cancels the shared lambda and leaves the two unique G entries-1 and+1. Thus ||G_beta||²=2.

This beta is a star, so kappa=1111 and its color1 bit is1. Equation(1) therefore gives the exact scalar

W_beta,beta=-2.                                          (2)

Changing pair/world conventions requires an explicit corresponding basis map; it does not justify changing this scalar in the declared convention. No claim is made that Ccore_beta is nonzero or that this negative formal entry signs the complete coefficient.

## Complete cost bounds and exact output widths

The old complete2242944 bound remains a valid fallback, but the Gram route bypasses materializing B and its1492992 construction attempts.

T construction:216 columns times at most8 candidate choices=1728. Complete R construction:216 rows times at most8 core-orientation assignments=1728. Build both from their explicit formulas; upper/lower R are identical by xor4, so there is no need to build a duplicate table. If an implementation chooses to build two copies instead, its additional1728 operations must be declared rather than hidden.

For G=TR, each alpha column of T and alpha row of R have at most8 entries, so at most216*8*8=13824 products. The complete syndrome-compatible G domain has

sum m_kappa*n_kappa=40*24+24*24+6*32*28=6912 cells.

The full Gram stage, retaining ordered output cells within each block, costs at most

sum m_kappa*n_kappa²
 =40*24²+24*24²+6*32*28²=187392 products.

Total1728+1728+13824+187392=204672 candidate attempts/products. This counts all8 syndrome blocks and all5856 retained W cells; off-block zero is certified by parity. It is a structural arithmetic count, not every interpreter instruction or a timing claim. Sparse construction and source/basis hash/readback/serialization guards remain to be specified before any run.

T entries are0,+1,-1. R column absolute coefficient sum<=8. Therefore each G column satisfies ||G_beta||2<=8*sqrt8, and by Cauchy every absolute Gram entry is<=512, including off-diagonal entries. D changes only signs. Signed16 W output is sufficient:5856 cells times2 bytes=11712 numeric bytes, with separately bounded schema/metadata. Exact integer accumulation and bound checks precede serialization; final cancellation is not a license for narrow overflow. G entries separately obey magnitude<=8; a simple Gram accumulator bound40*8²=2560 is also safe for32-bit intermediates. Actual zero counts, compression ratios, walltime and RSS remain UNKNOWN because no tables were generated.

## Source completeness and remaining physical boundary

No extra2^6 or2! is introduced here. B and Ccore store alternating tensors at a<b and reconstruct their full ordered tensors with the unscaled E basis. The cycle R performs the six ordered edge-color sums and already counts the orientations. Gram factorization and parity blocking operate AFTER that exact convention, so they do not alter its dual pairing. The previous H=eta V V/2, t192 and all22 physical H/8 factors still yield

h12,6=8*3^8*2^-40 sum_beta W_beta Ccore_beta.

Ccore still contains the eight actual curved vertices, all20 independent anchors, twenty original quarter coframes, four D singles and six full EHC epsilon/gamma traces, both endpoint-summed sources, and the twelve replaced free coframe slots as literal V's. The64 fundamental chiral assignments/local odd constraints/correlated second and fourth moments are not evaluated or costed by204672. A projected-bulk certificate can be complete while full amplitude cost/value/sign remains UNKNOWN.

Recommend freezing and ACTUAL-reviewing this proof and scalar(2), with explicit pair/triple orders, before deciding whether even the bounded bulk table needs runtime. If code is later useful, exact prepared-byte review and new ROOT admission remain mandatory. No native/Lean/slot/controller/process changes, generic engine, cap increase, retry or science run follows from this report. All original denominator/reflection/source/contact/Lambda/tail and physical TT/positive-boundary/product/adjoint/seam/causal propagation/matter/EM/calibration/B3 requirements remain unchanged.

FINAL same-packet status and own SHA/bytes accompany delivery.
