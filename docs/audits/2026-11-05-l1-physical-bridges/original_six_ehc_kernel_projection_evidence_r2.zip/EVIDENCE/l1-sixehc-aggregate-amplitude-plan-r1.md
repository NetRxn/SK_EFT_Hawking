# Original twelve–six signed amplitude: analytic reduction and bounded next route

Executor01a1ac65; parent publication ROOT01a13f67; source
8efe7d579f993b18b807aea75cd600f494b67cc1. PREPARATION / next research design only.
No new scientific execution is requested or admitted by this document. Original
128-mode/64-independent-anchor uncapped h=1 model, actual time0/1 source family,
full EHC/coframe/gamma/top/weights/factorials and current roadmap remain binding.

## Selected approach and completed proof boundary

ROOT selected analytic32-sector proof before spending runtime on a representative
word. [The complete signed reduction](ORIGINAL_SIX_EHC_SIGNED_SECTOR_REDUCTION.md)
and its independent ACTUAL mathematics/source reports establish the following
separately from an amplitude evaluation:

- 32 doubled/divisor512 records have the SAME original unweighted kernel after
 actual both-endpoint FULL-Q correlated elimination, exact partial epsilons and
 a source-free anchor/field/top change of variables. Their16(+8)/16(-8) weights
 cancel, without evaluating that kernel or dropping either adjoint remainder.
- 8 of12 distinct/unit-divisor rows cancel by explicit spatial-axis permutation
 with actual opposite source weights and original world/field signs.
- Remaining4 map by translations to16(A4+A5), with A4 andA5 still distinct.
 Spatial translation on the common background then proves the ONE exact frontier

 h12,6=8 I_all Haar_all[(Q0,22+Q4,22)(Q1,22+Q5,22) Pi_*],
 Pi_*=(prod_(z notin{0,1,4,5})D_z)
       E_(0,02)E_(4,02)E_(1,12)E_(5,12)E_(1,23)E_(5,23).

All44 original records are accounted exactly once by cancellations or mapped
sums. This is neither A4=A5 nor an assumed averaged physical source. Actual
first endpoints0/4 are time0, second endpoints1/5 are time1. The aggregate's
value/sign/nonzero status remains UNKNOWN. A full zero would descend the
original coefficient roster; it would not imply the full response is zero.

The alternatives considered were: an original four-edge M/C witness calculation,
a direct all44 expansion, and analytic sector/orbit reduction first. The first
has a small rigorous primitive but evaluates a sector now known to cancel;
it remains a disputed-identity control if needed. The second has no defensible
current global join budget and would duplicate work eliminated by proof.
ROOT chose the analytic route. This document recommends the next local and
recoupling preparation after that proof, not an unapproved whole-network run.

## Exact remaining graph and local degree

Ten curved undirected edges touch{0,1,3,4,5,7,9,13}. Their carrying fundamental
holonomy factors are SIX unit EHC classes; they cannot be replaced by arbitrary
adjoint norms R or a generic positive kernel. The central1–5 anchors each have
three curvature occurrences. Two coframes on that edge split one to each anchor
by individual center parity. Outer curved pairs have1+1 or2+0 curvature and two
coframes. In every surviving per-chirality term the degree is even and<=4.
Thus original normalized S3 second/fourth moments suffice for this FIXED target;
this does not lower global10/8 guards for other scientific words.

Every curvature-free edge has one coframe centered at EACH endpoint. Their22
physical pair tensors are P_xy^(AB)=H_xy^(AB)/8 with

 H_xy^(AB)=Haar_U[F_x^A(U) F_y^B(U)],
 F_x^A=bar_x gamma_A Udagger psi_y−bar_y U gamma_A psi_x,
 F_y^B=bar_x Udagger gamma_B psi_y−bar_y gamma_B U psi_x.

They are not delta_AB K/8. The unequal gamma ordering is precisely what the
original single-chirality Fierz controls must retain. Product Haar factorizes
only on independent compact variables with shared exterior fields kept intact.
Six class traces allow64 logical chiral choices, carrying their actual gamma5
and world signs; no choice or sum has been evaluated here.

## Concrete bounded first local computation to PREPARE

The recommended first exact computational certificate is the FULL original
physical mixed-endpoint P_xy^(AB) table, not a sign of a cancelled witness.
It is needed by BOTH A4,A5 and by their proved aggregate. Freeze actual Euclidean
gammas/Paulis, U/V independent anchors, both chiralities, two-endpoint16-generator
order and the embedding into the original128-generator top before coding.
No old N4 model or import-time scientific helper is an authority for it.

Ordered A,B have16 choices. Degree2 at each eight-mode endpoint gives28*28
possible exterior cells per AB, hence12544 Gaussian-rational coefficients.
A full F endpoint has at most32 quaternion/field terms; a direct16*(32)^2
second-moment expansion has at most16384 raw coefficient products. Cross-group
means and odd/overlapping masks are zero by the original identities. The physical
two-anchor factor is2/16=1/8, and normalized single-group second moments give
another1/4. Consequently scale32 clears the physical table; its Gaussian-integer
coefficient l1 norm is bounded by1024 before cancellation. A frozen signed16
real/imag array therefore has50176 numeric bytes. These are proposed exact
algebraic bounds, not generated table sizes, timing, RSS or a whole-network fit.
Use arbitrary integers while accumulating and check bounds before serialization;
do not infer intermediate safety merely from a final cancellation.

Required independent controls for the future exact implementation:

1. FULL original same-endpoint tensor delta_AB K/8 with its both-anchor1/8,
   unweighted Q→K/2, no extra coframe quarter or mean-field substitution.
2. Opposite-endpoint index/field relabeling and complete Gaussian-integer wedge
   sign, with original gamma placement retained. A source-derived nonzero control
   has been independently checked manually: for x<y, A=B=3, coefficient of
   bar_x,L2 bar_x,R1 psi_y,L2 psi_y,R1 in physical P_xy^33 is−1/8, hence−4 in32P.
   The two allowed chiral first-term products each reorder with sign+ and Haar
   Udagger12 Udagger21=−1/2; cross-chiral means vanish. It distinguishes a true
   mixed kernel from the scalar K, which has a different endpoint chirality.
   This control is a proposed original test input, not an executed table.
3. Gauge-covariant vector-copy completeness and exact local top convention;
   if a four-vector multiplicity basis is used, its actual C_ab and t must be
   computed/proved from this table, not chosen for convenience or positivity.
4. Exact dense axis/mask/chirality ordering, row/scale/endianness/version,
   actual source/code/spec pins, full expected output and independent source
   readback. Table equality alone does not prove a full amplitude sign.

A future program should be a small private stdlib exact Gaussian-integer
certificate, with exact output/manifest caps derived from the chosen schema,
cooperative deadline and no retry. Code/spec/basis/controls must receive fresh
independent science and static review BEFORE ROOT considers an invocation.
No program/spec or guard request is prepared by this plan; there is no current
runtime admission. The completed support admission is consumed.

## Complete aggregate route and explicit refusal frontier

The eight sites outside the curved vertex set form a bulk region with10 internal
mixed-H edges and12 external mixed-H legs. An uncompressed multiplicity-four
boundary tensor has4^12=16777216 entries before core spinor/mask data. It must NOT
be materialized under a120000-row primitive cap or hidden behind a larger guard.
This count is a dense-shape warning, not a lower bound on compressed contraction.
The complete all-linear normalization's positive cube-square proof does not
prove positivity of this defect network.

Retain the8 local alternating epsilon vertices and10 C edges as a factorized
network, attach every22 original mixed-H edge, and keep the curved8 vertices'
actual D/EHC/source/ordered-field data. Derive and freeze representation recoupling
or a complete boundary slice partition before any full-network command. At each
curved anchor integrate the joint polynomial using exact normalized second/fourth
moments, preserving class-chirality and fundamental spinor indices, active/
partner daggers and local exterior masks. Neither repeated second moments nor
a diagonal full-Q adjoint annihilator replaces the correlated fundamental data.

Possible next boundaries, each requiring its own concrete reviewed cost:
- a source-exact four-vector C/t basis certificate to compress the bulk;
- one fundamental weighted edge block with all external indices fixed;
- a compressed bulk tensor or a specified complete set of boundary-color slices;
- correlated core closure and exact signed assembly of the endpoint-summed word.

For every proposed join/slice, declare the full open-index domain, local mask
count, compatible-pair ceiling, intermediate rows, exact coefficient widths,
output bytes and complete set of slices. Total work counts ALL64 class-chirality
choices and all original source terms, not one favorable block. Any cap overflow
is an incomplete result; no larger guard, auto retry, partial zero or favourable
subset is authorized. Raw numerical rational is preferable for small primitives;
modular full-sign reconstruction additionally needs a proven common denominator
and signed bound for the full final coefficient and every actual intermediate.

Current precise frontier: the local degree and mixed-H primitive domains are
bounded analytically, but a COMPLETE aggregate contraction tree, join widths,
actual elapsed and peakRSS remain UNKNOWN. Therefore this is a costed first
primitive and complete source-exact route with an explicit unqualified global
frontier, not a defensible full-amplitude execution request. Further analytic
recoupling may eliminate computations before runtime is spent.

## Continuity, evidence and physical requirements

Use the existing Phase6a/5d/6e and ROOT queue; the44-row scientific correspondence
is not a second routing ledger. The lead owns primary L1FixedControls notebooks;
workers read and report. A fresh assignment packet never grants a lease, build,
review acceptance or execution. Preserve original c0 and other targets; old N4
120k/3m refusal figures and this support child's1.506s are not forecasts here.

The unconditioned h=1 source denominator/both kernels/full Delta/reflection jets,
Bopp/Dlog/source-normalization contacts, positive Z and fixed Lambda/tail remain.
Even an eventual exact aggregate sign is a finite original-observable result;
it would not construct physical TT/Ward/projector/pole, positive boundary/product/
adjoint/seam/causalV, calibrated matter/EM/light/transport/time/scales/B3/N4/limits.
No source scope reduction or favourable physical premise is adopted. ROOT owns
further approval, intake/integration/roadmaps/gates/closure/native/Lean slots and
final human publication approval. No repository machinery or tests are altered.
