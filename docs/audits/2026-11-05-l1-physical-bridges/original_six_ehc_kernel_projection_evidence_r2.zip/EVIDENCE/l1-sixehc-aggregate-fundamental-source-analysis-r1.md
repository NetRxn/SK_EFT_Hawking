# Original aggregate: fundamental obstruction and compressed bulk certificate

Task l1-sixehc-aggregate-kernel-r1; parent publicationROOT01a13f67/L1-physical-observable-boundary. Current source9ac8bd5680cfaa774fb4e24b79a32593b07e49bc. FIRST explicit primary packet check returned exit0, fresh=true, changed=[]. Read the packet, latest sole-writer notebook/commission and source-bound aggregate plan, alongside the held original coframe/gamma/Haar/top and six-class construction. No new peer report was read. Ownership is this private report only; no notebook/repository/peer edits. Everything below is manual source analysis; no executable/import, mask/moment/network table generation or scientific computation was run.

Conclusion: ACCEPT PREPARATION of a complete compressed bulk epsilon certificate, with the exterior-dual normalization condition below. It has a genuinely bounded domain and two manually verified scalar controls. The endpoint-summed source has a nonzero fundamental coefficient, so a universal fundamental annihilator is unavailable. Complete correlated-core contraction cost remains UNKNOWN and is not hidden in the bulk bound.

## Exact source and anchor attachment

The accepted source aggregate is h12,6=8 I Haar[(Q0,22+Q4,22)(Q1,22+Q5,22)Pi*]. Pi* contains12 D singles outside holes{0,1,4,5} and six unit EHC classes a=(0,02),b=(4,02),c=(1,12),d=(5,12),e=(1,23),f=(5,23). This is a derived coefficient identity with the original time0 edge0–4 and time1 edge1–5, not a replacement physical source or equality of the two component amplitudes.

Writing Omega_(z,i) explicitly, the six ORIGINAL ordered holonomies are

Ha=Omega_(0,2)† Omega_(4,0)† Omega_(1,2) Omega_(0,0),
Hb=Omega_(4,2)† Omega_(0,0)† Omega_(5,2) Omega_(4,0),
Hc=Omega_(1,2)† Omega_(5,1)† Omega_(3,2) Omega_(1,1),
Hd=Omega_(5,2)† Omega_(1,1)† Omega_(7,2) Omega_(5,1),
He=Omega_(1,3)† Omega_(9,2)† Omega_(5,3) Omega_(1,2),
Hf=Omega_(5,3)† Omega_(13,2)† Omega_(1,3) Omega_(5,2).

Each EHC has its complementary coframe directions and original world epsilon, with F_CD(H)=Tr[H gamma_[C gamma_D] gamma5]. The full four-world-placement quarter cancellation already belongs to that EHC definition. Individual coframe quarters remain. Six independent choices of the chiral trace block give64 logical assignments; they are not generated here. Keep the actual gamma5 sign, gamma_[C gamma_D] block and holonomy order for each assignment. No R(H) adjoint-norm replacement is available for these unit classes.

On edge0–4 the two source anchors occur once each in Ha/Hb, both dagger. On central1–5 the anchors Omega_(1,2),Omega_(5,2) each occur three times, with respective ordered appearances (+,dagger,+) from(a,c,e) and(b,d,f). The other1+1 edges are3–7, using Omega_(3,2),Omega_(7,2) without dagger, and9–13, using Omega_(9,2)†,Omega_(13,2)†. The remaining six outer edges have two curvature appearances on one anchor and zero on its independent partner. This records actual anchors; coincident undirected squares do not identify compact variables.

Each edge has two coframes. Independent center parity forces one onto each anchor on3+3 and1+1 edges. On2+0 edges both coframes lie on one anchor. After the64 chiral trace choices are made, every surviving per-SU2 degree is even and at most4: central total4 per anchor;1+1 total2;2+0 at most4. Coframe gamma placement changes chirality routing but not occurrence degree. Thus exact S3 second/fourth moments suffice for THIS aggregate, while the previous global10/8 guards remain unchanged for other words.

## New manual scalar obstruction to endpoint-sum annihilation

Original endpoint numerators are F_x^A(U)=bar_x gamma_A U† psi_y-bar_y U gamma_A psi_x and F_y^A(U)=bar_x U† gamma_A psi_y-bar_y gamma_A U psi_x. Actual coframes are [F_u(U)-F_u(V†)]/4 for u=x,y. In a fixed chiral group L, their positive first terms are a q_A† U† b for F_x, with a=bar_(x,R), b=psi_(y,L), and bar_(x,L) U† q_A psi_(y,R) for F_y. The two gamma placements cannot be interchanged.

On actual source edge0–4 set U=Omega_(0,2), V=Omega_(4,2). Consider the exact polynomial tensor

S_(ij;kl)=Haar[(Q_x,22+Q_y,22)(U_L†)ij(V_L†)kl].

Its coefficient of M=bar_(x,R1)bar_(x,R2)psi_(y,L1)psi_(y,L2) is

coeff_M S_(ij;kl)=delta_il delta_jk /8.                 (A)

Proof: anchor parity removes the same-anchor square terms; the physical Qx pair contributes -1/8 sum_A F_x^A(U)F_x^A(V†). Only the two positive first terms can make M. Their second moments are integral(U†)pq(U†)ij=epsilon_pi epsilon_qj/2 and integral V_mn(V†)kl=delta_ml delta_nk/2. Here epsilon12=+1 and the dagger/dagger moment follows Haar inversion invariance. More unambiguously, for i=j=k=l=1 the first moment fixes p=q=2 and the second fixes r=l=1, each with factor1/2. The actual q_A† completeness gives sum_A(q_A†)s2(q_A†)t1=-2 epsilon_st. Reordering the two odd bilinears to bars-before-psis then gives -M before the -1/8 factor, hence +M/8. The covariant index calculation yields(A). Negative F terms contain bars at y/psis at x. Qy in this fixed L assignment uses x,L and y,R, so cannot contribute to M. Other chiral means vanish against the fixed L curvature entries.

The scalar value +1/8 at indices1111 is therefore a fully manual nonzero control. It obstructs a UNIVERSAL zero identity for endpoint-summed Q against arbitrary fundamental boundary data. It does not prove that this component survives the actual six trace contractions, exterior saturation or complete aggregate. The already accepted mixed-endpoint control -1/8 concerns a different unweighted monomial and remains consistent.

The source-edge0–4 weighted tensor is itself a finite useful optional primitive: four curvature-chirality choices times16 fundamental external-index choices times at most784 degree-two endpoint mask pairs gives at most50176 dense cells. A deliberately conservative full numerator budget is64 blocks times2 endpoint choices times4 internal A choices times32² F products times4 matrix-entry quaternion terms =2097152 candidate products. Scale32 clears the resulting physical second-moment tensor. This is a source-bound optional certificate, not an execution request or the full central kernel. The six-curvature-occurrence central source edge still has a much larger external-index domain; fixing its external indices/chiral assignment first gives a small block, not proof of whole-contraction fit.

## Complete compressed BULK epsilon domain

Let B={2,6,8,10,11,12,14,15}. Its10 internal edges form a three-square book sharing10–14:

10–2–6–14 (outer direction3),
10–8–12–14 (outer direction1),
10–11–15–14 (outer direction0),
plus shared10–14 (direction2).

Each of the six outer vertices has two boundary legs; central10 and14 have none. All22 free edges are actual mixed-endpoint H_xy/8. Do not replace them by delta_AB K/8. The held gauge-covariant multiplicity-four identity is H_xy^(AB)=sum_ab C_ab V_x,a^A V_y,b^B, oriented EVEN endpoint first, and I_x epsilon_ABCD V_a^A V_b^B V_c^C V_d^D=t epsilon_abcd. No positivity, nonsingularity or numerical value of C or t is assumed here.

The EVEN bulk vertices are10,6,12,15. Absorb the four incident row-C factors into each of their epsilon tensors. The determinant identity gives (det C)^4 without inverses and remains valid when C is singular. The eight original complete D top contractions supply t^8. All bulk-incident C factors are thereby consumed except the six boundary edges terminating at ODD bulk vertices2,8,11. Their even endpoints are core vertices0,3,9. Hence their two-at-a-time action on antisymmetric pairs is the corresponding second compound matrix, with EVEN/core labels as rows and ODD/bulk labels as columns. Do not silently transpose a nonsymmetric C. The full physical pair normalization still has8^-22, including boundary edges; absorbing C does not absorb that physical factor.

At each outer bulk vertex its two boundary slots are antisymmetric, so their independent color coordinate is an unordered pair alpha=(a<b) from four colors: six choices. Let J_alpha[p,s]=epsilon_(p s a b). This matrix has exactly two signed nonzero entries, with p,s the complementary colors. Along a path the two outer vertices give W_(alpha,beta)=J_alpha J_beta^T, which has at most two nonzero(p,q) entries. This is zero, a signed rank-one matrix, or a two-entry diagonal matrix; this classification follows directly from complementary-pair support and does not require generated tables.

The internal directions at both outer vertices are d,2; the boundary directions are the remaining two world axes in ascending order. The permutations taking these slots to world order have equal signs on both ends of the path, so their product is+. For d=3,1,0 those individual signs are respectively -, +, -. Central epsilons both have the SAME world slots: epsilon_(p0,p1,c,p3) epsilon_(q0,q1,c,q3), where c is the shared direction2 color. This specifies signs beyond an abstract graph isomorphism.

Thus the COMPLETE pure epsilon bulk domain has6^6=46656 independent boundary-pair cells. For each cell, three W matrices supply at most2³ index choices and c at most4, giving at most32 signed summands per cell. The complete direct ceiling is1492992 summand attempts. Every summand is0,+1 or-1, so |B_cell|<=32. This count is independent of unknown C/t and does not omit a favorable channel. It is below120000 rows/3000000 candidate products structurally; actual storage/code/runtime/admission remain separate. An int8 signed pure-B table suffices numerically under this proved bound, with fixed ordering and bounded metadata, but exact integer accumulation and bound checks remain necessary.

Two decisive manual scalar controls are available BEFORE any run:

1. If every alpha,beta is the same pair, all three path p colors lie in one two-color complement. A central epsilon requires three distinct p colors, so the coefficient is0.
2. Match alpha=beta on each path, using the three pairs(0,1),(0,2),(0,3) in any fixed association to d=0,1,3. Each W is the positive diagonal projector onto its complement. All p/q avoid0, so only c=0 can survive. Exactly two assignments of the remaining three distinct colors avoid their respective excluded colors; q=p, and the two central epsilon signs square to+. The coefficient is2.

This is a complete, bounded and nontrivial scalar/tensor target for the next preparation. It replaces the unqualified dense4^12 bulk boundary proposal with a source-exact antisymmetric projection; it is not a proof that the attached curved core is small.

## Essential exterior-dual normalization condition

The46656-cell table stores the ORIGINAL ordered tensor evaluated at a<b in each boundary pair. It does not sum both permutations. J_alpha=epsilon_psab has no extra2! and the compound matrix entry is the minor C_ac C_bd-C_ad C_bc with the declared orientation, again no extra2!.

When closing against an arbitrary ordered core pair tensor T_ab, the original ordered sum equals sum_(a<b) B_ab (T_ab-T_ba). If the core pair tensor is already antisymmetric this is2 sum_(a<b) B_ab T_ab. Six such pairs can therefore produce2^6 in a naive antisymmetric-array convention. Either carry explicit exterior-dual coordinates T_ab-T_ba or freeze a normalized basis/dual pairing throughout. Suppressing this closure factor would change the original amplitude. It must not be patched by inserting factorials into the stored B table, C minors or source weights.

## Remaining projected support and cost frontier

At bulk sites the four V factors are degree2 vector copies and their original top contraction is exactly the epsilon above. At each of the six noncentral curved vertices there are two free-edge V factors, leaving local degree4 for curved/source factors; the two free factors carry one L and one R variable each. Thus the residual curved word must provide precisely two L and two R variables there. At central1 and5 no free edges occur; their residual factors must supply four L and four R variables each. These are exact local chirality/exterior constraints to apply BEFORE Haar products. They do not by themselves enumerate viable64 assignments or prove a nonzero top. Overlap signs must still be computed in the original bar/psi ordering.

The projected bulk has46656 boundary cells, but attachment to the core includes the three compound-C actions, actual fundamental trace spinor indices, source sums and chiral/exterior constraints. No finite whole-core join count or execution fit is proved by46656 or1492992 alone. A valid complete contraction design must specify each core open index, exact projected local mask space, total slices covering all64 chiral trace choices and all source placements, all intermediate products/rows and exact coefficient widths. A failed or partial slice is not zero. C/t may vanish or compress the system further, but their new proof is not assumed from another agent.

Recommended next boundary: freeze and independently ACTUAL-review the mixed-H/C/t identity, the source fundamental scalar(A), and this complete pure-book antisymmetric projection with its0/2 controls and dual normalization. Prepare the bounded bulk certificate only if an executable certificate is still useful; all current science work is proof/manual. The correlated core remains the explicit next obstruction until its projected indices and full contraction budget are derived. No generic engine, guard raise, automatic retry, native slot or execution is authorized.

All original full-Z/uncapped-reflection/source/Bopp/log contacts, both source times, Lambda/tail and physical projector/positive-boundary/product/adjoint/seam/causal propagation/matter/EM/calibration/B3 obligations remain. A bulk coefficient2 or local fundamental1/8 is not a full aggregate sign, a positive state or physical tensor mode.

Evidence: same primary authority/notebook packet; accepted44 TSV4d7456c8f95ca49347c34c275aa8e08cc5ec689effed039534bd5b8f37e7a14b; original six-EHC construction8c54423fd506ae3065da2804a39b1892ad6f18a730313e9e8ad17210b1ba9020, equations2,12–21; original normalization construction sections3–5 for literal mixed endpoints and multiplicity-four top; the current accepted signed-sector result is bound by the packet, and the aggregate preparation plan was read as an original input, not a new peer verdict. FINAL SAME and own SHA/bytes accompany delivery.
