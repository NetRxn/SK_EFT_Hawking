# Exact six-cycle boundary recoupling of the original aggregate

Independent MANUAL PREP/PROOF analysis, task l1-sixehc-aggregate-kernel-r1, parent publicationROOT01a13f67/L1-physical-observable-boundary; source9ac8bd5680cfaa774fb4e24b79a32593b07e49bc. FIRST SAME primary packet check returned exit0, fresh=true, changed=[]. Own only this new private report. The earlier /private/tmp/l1-sixehc-mixed-kernel-math-analysis-r1.md is preserved unchanged (SHA43e89955493d282cd510a773b87f245e7cdd814c99e0ea910058368d687a9562,15585B). No peer new report was read, no source/notebook/repository/packet was edited, and no scientific code/import/Haar/moment/tensor/mask/CAS generation, test, native/Lean/build/slot/controller or Git action occurred.

ACCEPT the proposed recoupling as a manual mathematical route, with the precise leg orders and reconstruction convention below. Both core and bulk have six canonical bivector boundary slots. Their attachment is an exact product of two sparse six-cycle maps. The projected bulk W has a complete46656-entry domain and a prospective2242944-attempt construction bound. In fact |W|<=2048 follows from the raw-contribution bound, sharpening the proposed safe131072 bound. A complete original core evaluation and aggregate sign/value remain UNKNOWN; this is not runtime admission or actual computational output acceptance.

## 1. Source-exact fixed objects

Retain the accepted44-record signed reduction literally:

 h12,6=8 I Haar[(Q0,22+Q4,22)(Q1,22+Q5,22) Pi*],
 Pi*=(prod_{z notin{0,1,4,5}}D_z) E0,02 E4,02 E1,12 E5,12 E1,23 E5,23.

Axes use bit values1,2,4,8 for world0,1,2,3. No source profile is averaged as a physical premise. The fixed core vertices are{0,1,3,4,5,7,9,13}; outer vertices are{2,6,8,10,11,12,14,15}. The22 curvature-free mixed pairs retain their original physical normalization Hxy/8. Use the manually derived local basis and constants from the preserved report:

 Hxy^{AB}=sum_ab C_ab Vx,a^A Vy,b^B,
 C=diag(1,-1,1,1)/2, t=192,
 I epsilon_ABCD Va^A Vb^B Vc^C Vd^D=t epsilon_abcd.

The pure outer epsilon tensor B has six canonical pair slots, |B|<=32 and shape6^6. Absorb four C at each even outer vertex10,6,12,15; the remaining boundary matrices are six individual C on odd leaves2,8,11, equivalently THREE Lambda² C factors. Their diagonal eta-pair signs can be isolated into D, eta=(1,-1,1,1), with the physical scalar prefactor3^8*2^-40. This convention retains all22 factors1/8. It excludes every actual curved-edge/source/EHC coefficient and the overall aggregate factor8.

## 2. Core antisymmetry is an actual polynomial identity

The two boundary world slots at each core attachment vertex are:

 core0 and4: axes(1,3),
 core3 and7: axes(0,3),
 core9 and13: axes(0,1),

all listed in increasing world order. At0/4 these are the two coframe slots of E0,02/E4,02, complementary to its curvature plane02. Its internal coefficient F_CD is antisymmetric, being contracted through the original world/internal epsilon and curvature factor. Consequently sum_CD F_CD V_a^C V_b^D changes sign under a<->b: commute the even V factors and rename C,D. This never moves gamma through a link, replaces a curvature factor by its mean, or assumes that F_CD is independent of compact variables. Source Q at axis2 and all remaining factors multiply this identity unchanged.

At3/7/9/13 the two exterior boundary legs belong to the same single D vertex. Holding its other two internal slots fixed, the D epsilon is antisymmetric in the two boundary internal indices. The same even-polynomial interchange proves antisymmetry in their multiplicity labels. Shared odd fields with other factors can kill terms but cannot spoil a polynomial identity. Curvature holonomies, EHC spinor indices and source insertions are retained. The claim is before Haar/Berezin integration, not a symmetry inferred from a scalar expectation.

Thus the complete core boundary tensor, after integrating its actual shared fields/curved anchors or before that integration as a formal coefficient object, is independently antisymmetric in these SIX disjoint pairs. Its canonical shape is6^6=46656. This is an upper bound on independent output shape, not a bound on constructing its entries or closing the curved core. It does not assert a positive core form or a complete Fourier/chirality truncation.

## 3. Exact leg orders on the two boundary cycles

The twelve boundary edges form two disjoint cycles:

 lower:0--2--3--11--9--8--0,
 upper:4--6--7--15--13--12--4.

For the lower cycle write c0 through c5 for the color on successive edges0--2,2--3,3--11,11--9,9--8,8--0. With each vertex's boundary slots ordered by increasing original world axis, the BULK pairs at vertices(2,11,8) have ordered colors

 (c1,c0), (c3,c2), (c4,c5),

and the CORE pairs at vertices(0,3,9) have ordered colors

 (c0,c5), (c1,c2), (c4,c3).                                    (1)

The upper cycle is exactly the same list with every vertex xor4, and its bulk/core pair orders are(6,15,12)/(4,7,13). For example leaf2's boundary axes are0 toward3 and1 toward0; leaf8's are0 toward9 and3 toward0. This fixes the signs that an unoriented cycle picture would not determine.

If B was originally stored with its three paths ordered by axes(0,1,3), its lower leaf order was(11,8,2). To use this report's lower order(2,11,8), permute the three canonical pair slots accordingly: old tuple=(new second,new third,new first). Apply the identical permutation upstairs. This is a coordinate permutation, not an additional sign, since whole pair factors are even. It must be explicit in any future schema.

Define the canonical antisymmetric basis for a<b by

 E_(a,b)[i,j]=delta_ia delta_jb-delta_ib delta_ja.

With lower alpha=(alpha1,alpha2,alpha3) at(2,11,8) and beta=(beta1,beta2,beta3) at(0,3,9), define the EXACT integer attachment map

 R_alpha,beta = sum_{c0,...,c5=0}^3
 E_alpha1[c1,c0] E_alpha2[c3,c2] E_alpha3[c4,c5]
 E_beta1[c0,c5] E_beta2[c1,c2] E_beta3[c4,c3].                  (2)

The upper map is the identical numerical R with the identical translated ordering. Formula(2) itself is a safe source-bound definition; it prevents any global sign ambiguity in a differently oriented graphical recoupling convention.

## 4. No hidden factorial in pairing the two tensors

An antisymmetric tensor T_ij reconstructs as sum_{a<b} T_ab E_(a,b)[i,j]. Thus expansion of BOTH bulk and core using their actual canonical coefficients and contraction over the original six edge colors gives exactly(2). There is no1/2 in that canonical reconstruction and no extra2! to append afterward. Ordered assignments, including their signs, are already counted in R. For example a doubled direct pair closure sum_ij E_alpha[i,j]E_beta[i,j]=2 delta_alpha,beta; its factor2 is generated by the two ordered assignments, not an independently supplied normalization.

The six slots at bulk vertices and the six slots at core vertices pair DIFFERENT legs into pairs. Therefore their contraction is not six independent pairwise2delta contractions. It is exactly the two cycle maps R tensor R. Using a diagonal pair attachment would lose the physical connectivity.

An additional signed orientation control fixes (2): take all six canonical pairs equal to(0,1). There are exactly two alternating colorings of the cycle. For (c0,c1,c2,c3,c4,c5)=(0,1,0,1,0,1), the three bulk signs are(-,-,+) and the core signs(+,-,+), giving product-1. Reversing all colors gives another-1. Thus this R entry is -2, not +2. This also checks that cycle attachment cannot be replaced by a positive diagonal pair norm.

## 5. Rigorous sparse domains and arithmetic bounds

There are216 ordered triples alpha and216 triples beta. For fixed alpha, each of its three E factors allows exactly two ordered color assignments. These give8 assignments to all six edge colors, with no colors left unspecified. Each assignment determines either one beta triple and a sign, or zero if one of the core ordered pairs has equal colors. Thus every R row has at most8 RAW signed contributions, at most8 nonzero entries after aggregation, and row absolute sum<=8. The same reasoning fixing beta instead gives column absolute sum<=8 and at most8 raw/nonzero contributions. This is valid with the precise asymmetric-looking orders(1); no geometric transpose symmetry is needed for the bound.

Consequently a sparse representation can retain at most1728 raw entries per R. Coefficients are integers of absolute value<=8. Two complete map preparations need at most2*216*8=3456 color-assignment checks; numerically the two maps agree, so building only one is also legitimate if its role/order is frozen. Sparse aggregation may reduce the size but is not assumed in the guard.

Arrange B as a216-by216 matrix, lower bulk tuple first and upper tuple second, in the explicit new ordering. D is diagonal on its lower row index, with

 D_alpha = product_{r=1}^3 eta_(alpha_r,first) eta_(alpha_r,second),

because the odd-bulk leaves are exactly2,11,8. After stripping the three1/4 factors, D is a sign. The complete projected bulk is

 W=R^T D B R.                                                 (3)

For each of216 untouched upper columns, left multiplication uses at most1728 sparse entries:373248 products. Right multiplication costs the same. Together at most746496 exact signed integer products/accumulations. Including the prior full B bound1492992 and both R preparations3456 gives the proposed total2242944 logical attempts. Initialization/metadata/publication/interpreter costs are additional; this is not a wall-time prediction or total machine instruction bound. A concrete future cooperative timer/byte guard needs a separately reviewed implementation.

A sharper coefficient bound follows without generating any entries:

 |W_beta,gamma|
 <=32 (sum_alpha |R_alpha,beta|)(sum_delta |R_delta,gamma|)
 <=32*8*8=2048.                                               (4)

The proposed bound32*8^4=131072 is also safe, but it separately maximizes entry count and entry size even though their product is bounded by the SAME eight raw contributions. Signed16 payload for all46656 W entries is93312 numeric bytes; signed32 is186624 bytes. Either is safe for final W. Intermediate X=R^T D B has |X|<=256. Even direct accumulator absolute-sum bounds are<=256 and2048 respectively, since the sparse l1 bounds apply before cancellation; integer16 is therefore safe for these mathematical operations, although using unbounded integers and checking before serialization remains clearer. B/X/W together in signed16 need279936 numeric bytes, excluding sparse maps, indexes, metadata, buffers, interpreter/RSS. A streamed layout may use less; no measured resource claim is made.

## 6. Exact aggregate scalar after projection, and the next boundary

Define C_core,beta,gamma as the actual canonical core coefficient tensor using the ordered vertex pairs(0,3,9)/(4,7,13), original world slots, shared exterior variables, six unit EHC faces, curved coframe/source quarters, Q endpoint sum, original normalized joint Haar moments and original core top orientation. The symbol C_core is distinct from the4-by4 mixed kernel matrix C. It is NOT an arbitrary positive tensor and its values have not been computed. More explicitly its eight sites retain D3,D7,D9,D13, all six unit EHC classes, and the full source product(Q0+Q4)(Q1+Q5). Replace ONLY the twelve external free-coframe slots by the specified V components. Leave all twenty remaining internal T factors with their actual quarters, and every EHC epsilon/gamma5/dagger/source unchanged. These twenty T factors carry40 odd variables, while the twelve V carry24; the total64 is exactly the original eight-site top degree. The ten curved edges retain twenty independent anchors. No further mixed C or1/8 factor belongs in this core definition because all22 curvature-free physical pair factors have already been included in the outer prefactor and boundary map.

With these definitions and the earlier bulk scalar convention, the exact resulting coefficient is

 h12,6 = 8*3^8*2^-40 sum_{beta,gamma} W_beta,gamma C_core,beta,gamma. (5)

There is no additional2^6. Equation(2) already performs the original ordered color closures on all twelve boundary edges. The scalar in(5) is not a completed numerical result: the correlated core calculation remains unknown.

This gives a genuinely stronger next certificate than an isolated local table: a COMPLETE projected weight for every independent admissible core boundary component, with a concrete small integer payload and exact cost bound. A future program can implement only B/R/W, freeze all216-tuple and canonical-pair orderings and signs, check the earlier B controls0/2, certify the R raw-contribution partitions and both row/column l1 bounds, serialize W and independently verify its manifests. No program is written/executed here. Independent ACTUAL proof/code/spec review and NEW ROOT admission remain necessary before any scientific invocation.

After that certificate, the decisive remaining scalar is the full pairing(5), rather than a favorable W entry or a canceled witness. Core antisymmetry supplies an exact output shape but not a feasible core contraction tree: original joint degree-four Haar data, chiral assignments, exterior masks and shared fields still need a complete index/join/numerator/denominator and resource bound. A nonzero W, including nonzero pure bulk controls, cannot prove nonzero core overlap; cancellations may still force zero. Any full zero would descend the accepted coefficient roster, not prove the full response zero.

The original64-anchor/128-generator theory, both-step/uncapped Delta/source/denominator/Bopp/Dlog contacts and physical TT/Ward/projector/pole/positive boundary-product-adjoint-seam/causal transfer/matter-EM/calibration/B3 obligations remain unchanged and OPEN. Neither the signed multiplicity kernel nor recoupling is a physical positivity construction or a global no-go.

## 7. Continuity and ownership

The only write was this assigned new report. FIRST adapter command was `python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/l1-sixehc-aggregate-kernel-r1.json` from the assigned checkout. Final SAME fresh result and exact report SHA/bytes are returned with delivery. This report preserves the earlier frozen report and all peer/source/notebook files; it grants no runtime or publication acceptance.
