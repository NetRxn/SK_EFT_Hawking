# Source-exact mixed endpoint kernel and bounded bivector bulk route

Independent PREPARATION / manual mathematical analysis, task l1-sixehc-aggregate-kernel-r1, parent publicationROOT01a13f67/L1-physical-observable-boundary. Source 9ac8bd5680cfaa774fb4e24b79a32593b07e49bc. FIRST assigned primary continuity check returned exit0, fresh=true, changed=[]. Own only this private report; no other new peer plan/report was consulted. The pinned source-control file was read as a proposed original coefficient calculation and independently challenged below. No scientific program, import, moment/tensor/mask/Haar generation, CAS, test, native/Lean/build/slot/controller or Git operation occurred. All new equations here are manual derivations, offered for independent ACTUAL review before canonical adoption.

Conclusion: ACCEPT the analytic route with the explicit kernel/basis/top and bulk reconstruction below. The complete 12544-cell local table is unnecessary for deriving this kernel. A genuinely bounded next bulk certificate is available: 46656 signed integer entries, at most1492992 small color attempts, plus source-derived controls. This is not a complete aggregate contraction budget, amplitude evaluation, sign theorem or runtime permission. The original correlated curved core remains the material unqualified frontier.

## 1. Original authority and unchanged target

Read the pinned aggregate plan, source-control file, current primary notebook commission and original normalization construction, with the accepted signed-sector reduction/current continuity references. The governing scientific/ownership/runtime contracts remain those of AGENTS/CLAUDE/WAVE/CODEX_CONTINUITY and the current Phase6a/5d/6e roadmaps; no new routing ledger or physical premise is introduced. The normalization construction sections3/5 fixes the actual endpoint order, two independent anchors, four-vector multiplicity and original top; it leaves its numerical C,t unevaluated. This report evaluates those two algebraic constants without executing science.

The accepted coefficient identity is retained literally:

 h12,6 = 8 I_all Haar_all[(Q0,22+Q4,22)(Q1,22+Q5,22) Pi*],
 Pi*=(prod_{z notin{0,1,4,5}}D_z)
 E0,02 E4,02 E1,12 E5,12 E1,23 E5,23.

It accounts for all44 necessary records through already accepted cancellations/maps; it is not an averaged physical source assumption. Its sign/value/nonzero status is UNKNOWN. All64 independent anchors, original gamma/quarter/world/top signs, both kernels, uncapped reflection defect and source/normalization/Bopp/log contacts remain. The positive all-linear c16 proof cannot be transferred to this defect network.

## 2. Closed signed mixed kernel

Use E=[[0,1],[-1,0]], E12=+1, q_A=(-i sigma1,-i sigma2,-i sigma3,I), and gamma_A=[[0,q_A],[q_A†,0]], with L upper and R lower. At each site define four degree-two vector polynomials, keeping the displayed odd order:

 M^A=bar_R q_A† psi_L,
 N^A=bar_L q_A psi_R,
 B^A=bar_R q_A† E bar_L^T,
 P^A=psi_L^T E q_A psi_R.

P in this paragraph is a local pair vector, not the physical edge kernel. Pseudoreality gives B^A=bar_L q_A E bar_R^T after the single odd interchange. The four supports are different (two mesons, barred pair, unbarred pair), so these vector copies are independent. They exhaust the multiplicity-four vector isotypic space of the original local degree-two exterior algebra; they introduce no auxiliary fields.

For the actual two placements

 Fx^A=bar_x gamma_A U† psi_y - bar_y U gamma_A psi_x,
 Fy^B=bar_x U† gamma_B psi_y - bar_y gamma_B U psi_x,

one obtains the COMPLETE original polynomial identity

 Hxy^{AB}=integral_U Fx^A Fy^B
          = Mx^A My^B + Nx^A Ny^B - Bx^A Py^B - Px^A By^B.       (1)

Here is a direct sign derivation, rather than commuting gamma through U. For active L,

 Fx,L^A=bar_xR q_A† U_L† psi_yL - bar_yL U_L q_A psi_xR,
 Fy,L^B=bar_xL U_L† q_B psi_yR - bar_yR q_B† U_L psi_xL.

Normalized SU2 moments are integral U_ij U_kl=E_ik E_jl/2 and integral U_ij conjugate(U_kl)=delta_ik delta_jl/2; dagger versions follow by their actual transposed indices. The forward-forward product moves psi_y through bar_x once, giving -Bx Py/2. In the forward-backward term the initial minus and regrouping odd variables (a,b,c,d)->(a,d,c,b), an odd permutation, cancel; the Kronecker moment yields +Mx My/2. Backward-forward similarly gives +Nx Ny/2. Backward-backward gives -Px By/2 after its epsilon contraction and regrouping. Active R gives the SAME four terms/2, by q†=-E q^T E and the fixed odd pair orientations. Cross-chiral products vanish by independent mean-zero Haar factors. Thus (1) contains both chiralities and all four endpoint selections.

For independent original anchors U,V,

 Tx=[Fx(U)-Fx(V†)]/4, Ty=[Fy(U)-Fy(V†)]/4,
 physical Pxy^{AB}=integral Tx^A Ty^B=Hxy^{AB}/8.                (2)

Cross-anchor terms vanish; the two same-anchor terms agree under Haar inversion and both have plus sign. The factor2/16 has been used exactly once. The same-endpoint delta_AB K/8 is a different kernel and cannot substitute for (1).

A signed endpoint control fixes a sensitive orientation. For A=B=3, Bx contains -bar_xL2 bar_xR1, and Py contains -psi_yL2 psi_yR1. Therefore the coefficient of bar_xL2 bar_xR1 psi_yL2 psi_yR1 in H is -1, exclusively from -Bx Py. It is -1/8 in physical P and -4 in32P. Equivalently each original chirality contributes Haar U†12 U†21=-1/2 with regrouping sign+. This agrees with the proposed control without using that file as proof, and distinguishes the two gamma placements.

## 3. Actual real Hermitian C and oriented top t

Under the accepted sharp reversal, M#=N and B#=-P. Choose the unscaled Hermitian basis

 V1=M+N, V2=i(M-N), V3=B-P, V4=i(B+P).

Equation(1) becomes exactly

 Hxy^{AB}=sum_ab C_ab Vx,a^A Vy,b^B,
 C=(1/2)diag(1,-1,1,1), det C=-1/16.                          (3)

These are actual source-derived coefficients; the signature is a multiplicity coefficient signature, not a physical spacetime metric or Hilbert Gram. All vector components remain even exterior polynomials.

The original local top is

 tau=bar_L1 bar_L2 bar_R1 bar_R2 psi_L1 psi_L2 psi_R1 psi_R2,
 I tau=1.

The coefficient t in I epsilon_ABCD Va^A Vb^B Vc^C Vd^D=t epsilon_abcd is

 t=192.                                                        (4)

For a fully signed control of (4), first use natural order(M,N,B,P). Direct expansion and endpoint regrouping give

 I M^A N^B B^C P^D = -Tr(q_A q_C† q_B q_D†).

One way to track its sign: the odd sequence (barR,psiL,barL,psiR,barR,barL,psiL,psiR) regroups to (barL,barL,barR,barR,psiL,psiL,psiR,psiR) with9 inversions; contractions of the two explicit E tensors supply the remaining sign in the trace formula. For distinct A,B,C,D the trace equals -2 epsilon_ABCD in the held q orientation. For example q0 q2† q1 q3† has trace-2. Hence the natural top contraction is 2*24=48. In the world-antisymmetrized product V1 V2 V3 V4, the first pair reduces to -2i M N and the last to +2i B P, giving net4. Thus t=4*48=192. No unspecified local orientation or arbitrary basis scaling remains.

As a consistency specialization, the all-linear normalization formula becomes A_L=3^16*2^-32 N_Q4. This only specializes the previously accepted nonnegative normalization class. It does not evaluate N_Q4 or prove positivity of the six-EHC aggregate.

## 4. Exact outer graph and six-bivector compression

The curved core has vertices{0,1,3,4,5,7,9,13}. The eight outer D vertices are{2,6,8,10,11,12,14,15}. Their ten internal edges form three length-three paths and one shared central edge:

 10--2--6--14 (path axis3, middle axis2),
 10--8--12--14 (path axis1, middle axis2),
 10--11--15--14 (path axis0, middle axis2),
 10--14 (axis2).

The six intermediate vertices each carry two boundary legs, giving12 total. The two hubs have no boundary legs. Local world-slot epsilon makes each leaf's boundary-color pair antisymmetric. Consequently the independent boundary shape is (Lambda^2 R4)^tensor6 with6^6=46656 entries, not a dense4^12 array.

Absorb all four C factors at each EVEN outer vertex10,6,12,15 into its local epsilon. This uses the determinant identity, giving (det C)^4. All eight local tops give t^8. Internal edges then identify colors. Exactly SIX individual C factors remain on the boundary legs of ODD leaves2,8,11; equivalently three Lambda^2 C transformations. Even leaves6,12,15 have already absorbed their boundary factors. Counting six bivector slots as six Lambda^2 C factors would double-count half the edge matrices.

For the pure epsilon bulk, choose at every leaf a canonical color pair alpha=(a,b), a<b, and J_alpha[p,s]=epsilon_{p s a b}. On each path the middle color is summed, so

 W_{alpha,beta}[p,q]=sum_s J_alpha[p,s] J_beta[q,s]
                  =(J_alpha J_beta^T)[p,q].                    (5)

Held world-slot signs require checking. Ordering the two internal slots as(path axis k, middle axis2), followed by the two increasing remaining axes, gives permutations [3,2,0,1], [1,2,0,3], [0,2,1,3]. Their signs are -, +, - respectively. The two leaves of each path use the SAME permutation, so their signs multiply to+. At the hubs retain world order(0,1,2,3), with central color in slot2. No global sign is discarded.

For six canonical pairs, the bulk integer B is the sum of the product of the three W entries and the two hub epsilons, sharing the central color. This is a closed finite formula with no exterior/core/link table. Each J has two nonzero entries and each W has at most two nonzero(p,q) entries, each +/-1. Therefore one B entry needs at most2^3*4=32 color attempts. The full proposed certificate needs at most46656*32=1492992 attempts, and |B|<=32. A signed8 dense array has46656 numeric bytes; a signed16 choice has93312 bytes. Index metadata/manifest/runtime overhead/RSS are additional and UNKNOWN. The intermediate W data can be stored as sparse lists (36 ordered alpha,beta pairs, at most2 entries each), avoiding a pairwise dense contraction. These are prospective exact bounds, not measured performance or admission.

Two manually fixed controls:
- If all three paths have alpha=beta equal to the SAME pair, three hub path colors must lie in its two-dimensional complementary plane. The hub epsilon vanishes, hence B=0.
- Set alpha=beta on each path, with pairs(0,1),(0,2),(0,3) assigned to path axes0,1,3 respectively. The three complementary planes admit exactly two distinct-color triples at the hubs; the central color is0, the two hub epsilons have identical signs, and W diagonals are+1. Thus B=2. The block is not identically zero, though this proves nothing about its contraction with the actual core.

Reconstruction has no hidden2! factor. For a canonical pair a<b at two distinct boundary slots, reconstruct with the antisymmetrized product X_a Y_b-X_b Y_a, where X,Y retain their actual core world/vector slots. Then sum over the six canonical pairs. Do not use2X_aY_b and do not discard the second assignment: X and Y generally belong to different core sites or different world slots. The three odd-leaf boundary transformations are precisely the minors Lambda^2 C, not independently selected signs.

With the explicit diagonal C, Lambda^2 C has diagonal entries eta_a eta_b/4, eta=(1,-1,1,1). Thus the complete outer-region prefactor is

 t^8(det C)^4/8^22 =3^8*2^-34,

with three Lambda^2 C factors still written, or 3^8*2^-40 times B and the three corresponding eta-pair signs if their1/4 factors are stripped. This includes all22 physical mixed-edge1/8 factors. It includes NO curved-edge coframe quarters, EHC coefficients, core determinant epsilons, source normalization or the overall accepted aggregate factor8; those remain in the original core.

## 5. Decisive next certificate and complete closure boundary

Recommend freezing the CLOSED identities(1)-(4) first for independent ACTUAL review, then preparing a small exact bulk certificate implementing(5) and the hub contraction, with the0/2 controls and canonical reconstruction. Its full output domain/bounds are stated above; this is substantially smaller than a dense12-leg boundary or the unnecessary12544-cell mixed table. Exact integer entries can be generated without a scientific exterior/Haar library, but no such program has been written or run here. Program/spec/static review and a NEW ROOT admission remain necessary.

The analytic B=2 control is a decisive nonzero bulk scalar: a proposed universal bulk annihilation is false. It is NOT a scalar projection of the complete aggregate with justified sign. The actual core may annihilate this sector or cancel it against others. In particular C's negative multiplicity direction and the original EHC/world/gamma5 signs forbid treating the compressed bulk as a positive physical projection. Positive c16 arguments do not resolve this.

The complete source-exact route attaches each of the six antisymmetric boundary pairs to its actual two core coframe slots, preserves all six unit EHC faces and four endpoint-expanded source words, and integrates each curved anchor jointly with normalized second/fourth moments. The central1--5 anchors have curvature3+one coframe each; the other curved anchors have1+1 or2+0 patterns. Actual surviving chiral degrees are<=4 for this target. Keep all64 logical EHC chirality assignments before proven zeros, partner/dagger order and shared exterior fields. The12 original all-distinct records have already been mapped/cancelled only by accepted exact identities, not by the bulk certificate.

A rigorous next core proposal can exploit the six Lambda^2 boundary channels and fixed degree-four moments; it must specify every core open index, local mask sector, intermediate join/domain, exact denominator/numerator bound and all slices. The46656-entry bulk certificate alone does not bound these joins. No complete core contraction tree or full aggregate cost is established here. A 46656-entry bulk can be retained as a factorized six-bivector object or streamed by boundary pairs; multiplying it blindly by a dense curved-core tensor would reintroduce the unqualified frontier.

Avoid known blind alleys: same-endpoint delta K substitutions on mixed edges; independent second moments at an anchor with four occurrences; FULL-Q annihilation when its supposedly absent partner actually carries curvature; a single favorable chirality or canceled32-sector witness; assuming endpoint-averaged sources make every individual source word equal; positive c16 square as defect positivity; unqualified4^12 materialization; and treating output bytes as RSS or old support timings as tensor forecasts.

The mathematically new closed local C,t and bounded compressed bulk are substantive preparation. Aggregate sign/value, a complete exact correlated-core algorithm/resource guard, physical TT/Ward/projector/pole, positive physical boundary product/adjoint/seam/causal transfer, matter/EM/transport/calibration/B3 and limiting claims remain OPEN. No broader physical no-go follows from a coefficient factorization or multiplicity signature.

## 6. Bookkeeping and final boundary

Only this report was written. Sources and notebook were read only; peer work was preserved. The FIRST adapter command was `python3 scripts/codex_continuity.py check PRIMARY/.codex/continuity/l1-sixehc-aggregate-kernel-r1.json` from the assigned checkout, with PRIMARY expanded to the supplied absolute primary path. Final SAME check and report SHA/bytes are returned with delivery. No new source acceptance or runtime qualification is implied by this analysis.
