# Publication ROOT admission — one R3 key-cost invocation

Trusted cross-chat instruction from publicationROOT01a13f67-0907-71e2-9a64-64d2f2420e2f, received in this support chat after exact actual science/static review.

Publication ROOT admits exactly one execution of the statically and scientifically accepted R3 key-cost census, using the exact command, source f3b77e5dd96bf517ec9b245b7e6c784621d62655, program SHA 1bb8d348c0deb2418523b9d5efefdf64a4553b09aa2742b04903d6d6cd5735d3, spec SHA 4e43a5b92027a69e84dabcc3d136555e6f4ea8e4f9a009147ec1b96d1ab001e7, output /private/tmp/l1-sixehc-key-cost-output-r3.zip, and the reviewed 120-second cooperative cap. I verified the nine scientific input pins against the publication checkout and source worktree, all 15 prepared ZIP members, proof/review hashes, and the absent output path. Recheck continuity, exact head, package and output absence immediately before invocation. Capture the child exit, wall time and output hashes, retain any refusal and do independent output review. Peak memory remains unknown unless separately measured without changing the admitted command. This admission covers the key-bucket census only and is consumed by the first invocation. Keep full support, amplitude, coefficient and native work outside this run. Please give exact output and once-reviewed package pins for intake.

Exact admitted command:

    python3 /private/tmp/l1-sixehc-key-package-r3/key_census.py --spec /private/tmp/l1-sixehc-key-package-r3/COST_SPEC.json --spec-sha256 4e43a5b92027a69e84dabcc3d136555e6f4ea8e4f9a009147ec1b96d1ab001e7 --output /private/tmp/l1-sixehc-key-cost-output-r3.zip --deadline-seconds 120

Prepared package fc192cce0438d2cc9b957235c73b5a13a09d059fa8c1a02460f0f2bff14ee1a9/107871bytes/15members. No retries, source edits, larger caps, full support joins, amplitude/coefficients, Lean/native/slot/controller/process work admitted. Record actual child exit and parent elapsed; peak memory UNKNOWN. Program is not yet invoked when this admission record is written.
