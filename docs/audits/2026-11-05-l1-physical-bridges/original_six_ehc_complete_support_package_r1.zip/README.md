# Original six-EHC complete necessary support — prepared R1

Status: PREPARED, NOT RUN. This private scientific program has not been imported,
invoked for help, tested, or executed. Static preparation is not runtime admission.
ROOT owns explicit execution admission, native/Lean capacity, integration, and
publication acceptance. Prior key-census admission is consumed and does not cover
this program. No repository harness or test infrastructure is changed.

## Exact candidate

- Source checkout HEAD: `555a8819ed9fe9016c38f6478931240fa8920dab`.
- Program: `complete_support.py`, 37573 bytes, SHA256
  `56838abada05054996841f221595cd3c79881b46641379225fad0078d707206f`.
- Spec: `SUPPORT_SPEC.json`, 5377 bytes, SHA256
  `8f818f811cbfd776b2e95b5c083b21dc59866bb3f1d159efad14273468e9dbd6`.
- `UPSTREAM_PINS.json` repeats the thirteen exact scientific input pins from the spec.
- Native key-census ZIP: SHA256
  `bdaad6aaac75c337ed5f1bf59501fde081094d837e0bfac78f8bfcc655ac41a7`,
  inherited source `f3b77e5dd96bf517ec9b245b7e6c784621d62655`.
- Prospective design: `/private/tmp/l1-sixehc-full-support-proposal-r1.md` and
  `/private/tmp/l1-sixehc-full-support-residue-addendum-r1.md`.

Independent mathematical, original-source, and static code/guard reviews are
pending on these exact bytes. A revision must preserve these bytes and their
reviews; it requires fresh hashes and deliberate reconciliation.

## Scientific boundary

The target remains original uncapped h=1, actual distinct times 0 and 1 at the
fixed model point, bidegree (12,6). The 96 full EHC descriptors are regenerated
with original epsilon, frame/curvature directions, anchored holonomy order and
daggers. All sixteen reduced source cases are retained with their own endpoint,
axis, gamma data and weight 8*eta(d)*(+1 for axis2, -1 for axis3). Equal source
load or equal integrality fingerprint never identifies source polynomials.
No additional raw 1/2 is inserted after source reduction.

The inherited key census supplies measured domain bounds, not middle class
labels. The program regenerates all 152096 sorted triples and compares both the
full `<BBBI` digest and unsigned sorted lossy native cost multiset. The canonical
first-three/last-three split visits all 302624 six-class key candidates once,
accounting for all 4841984 source cases and 9683968 logical root references.

For combined class Green numerator E and source numerator b, define
R_E(v)=(E(v)-epsilon(v)E(0)) mod384 and
F_c(v)=-(b(v)-epsilon(v)b(0)) mod384 for v=1..15. Their equality is equivalent to
integrality of both possible root occupations. A nonmatch rejects exactly two
logical references with a mathematical certificate; every matching case is
processed separately with roots0 and1. Each remaining occupation is checked
against range0..2, total12, all original sixteen site equations, cut character,
paired parity and individual-anchor allocation necessity. The latter is exactly
paired total parity when n>=1, and individual even curvature counts when n=0.
This does not test local exterior/chiral support or Haar amplitudes.

Both source cases2 and6 must contain the actual generated known witness
(1,1,11,11,21,21), doubles at5,6,9,10,12,15, root0, sourceweight-8,
epsilon product+1, divisor512 and curvature paritymask0. The program does not
insert a witness to satisfy this assertion.

## Fixed records and reconstruction

Each retained reference is one 32-byte little-endian `<8BIhbBIQI` record:

| Offset | Field |
|---|---|
| 0..5 | six sorted full class IDs, uint8 each |
| 6 | source case ID, uint8 |
| 7 | record version1, uint8 |
| 8..11 | occupation m(v) at bits2v..2v+1, uint32, values0..2 |
| 12..13 | reduced source weight +/-8, signed16 |
| 14 | EHC epsilon product +/-1, signed8, diagnostic only |
| 15 | root m(0), uint8, 0 or1 |
| 16..19 | factorial divisor 2^(number of doubles)*product(class multiplicity!), uint32 |
| 20..27 | curvature anchor parity, bit4v+axis, uint64 |
| 28..31 | reserved0, uint32 |

The full class and source catalogues in the manifest reconstruct exact loads,
frame counts, curvature counts, endpoint/gamma metadata and ordered daggered
holonomies. The parity mask is an additional invariant, not a replacement for
those catalogues. EHC epsilon is already in each full polynomial; the saved
product must not be multiplied a second time. The divisor is at most46080;
quarter factors and Haar denominators remain in their literal polynomials.
No factorial12!/6!, coefficient value, sign or physical transfer is inferred.

## Proposed guard profile — not admitted

- One invocation, cooperative deadline at most120 seconds. This is refusal
  checking, not hard preemption of a Python sort or OS I/O.
- At most9683968 records /309886976 binary bytes; manifest <=1000000 bytes;
  ZIP_STORED overhead <1024 bytes; container <=320000000 decimal bytes.
- Numeric array payload6083840 bytes. Python bucket indices, temporary sort,
  metadata and buffers are additional. Peak RSS is UNKNOWN and no fit is claimed.
- Read-only free-disk preflight >=1073741824 bytes. Refuse if absent; no cleanup
  or environment repair is authorized.
- Stream output and verification in chunks <=65536 bytes, no full output row
  list and no second uncompressed output file.
- Final output must be a new direct child of canonical `/private/tmp`, `.zip`.
  Parent-only resolution, final lexists guard and exclusive same-filesystem hard
  link preserve an existing file or symlink. Private staging is removed; complete
  publication is performed only after all coverage, byte, hash and witness checks.
- On refusal, bounded stderr includes completed counters, current/last pair,
  logical-record prefix hash and successfully-returned-write prefix hash. Such
  prefixes do not constitute complete support and are not resumable. No retry.
- The caller must record actual child return code, complete elapsed time,
  stdout/stderr and final output hash. Peak memory remains null/UNKNOWN without
  a separately authorized qualification.

Proposed invocation, NOT EXECUTED and requiring separate ROOT admission:

```sh
python3 /private/tmp/l1-sixehc-full-support-package-r1/complete_support.py \
  --spec /private/tmp/l1-sixehc-full-support-package-r1/SUPPORT_SPEC.json \
  --spec-sha256 8f818f811cbfd776b2e95b5c083b21dc59866bb3f1d159efad14273468e9dbd6 \
  --output /private/tmp/l1-sixehc-full-support-output-r1.zip \
  --deadline-seconds 120
```

Before invocation, ROOT must accept the exact reviewed bytes and guard profile.
The lead must reconcile a fresh continuity packet, HEAD/clean state, thirteen
input pins, exact program/spec/package hashes and absent final output. An actual
output requires independent mathematics and original-source/output review and a
qualified checkpoint. A complete necessary inventory still leaves all local
Haar contractions, cancellations, full coefficient sign, physical TT projector,
positive boundary/adjoint reconstruction and publication acceptance open.
