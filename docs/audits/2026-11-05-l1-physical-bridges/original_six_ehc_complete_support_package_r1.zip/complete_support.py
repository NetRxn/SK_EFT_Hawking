"""PREPARED, NOT RUN: complete NECESSARY original 12,6 source/site/anchor support.
Separate exact-byte reviews, ROOT profile acceptance and execution admission required.
No Haar, local chiral masks, amplitudes, coefficients, Lean or native-slot work.
"""
import argparse
from array import array
from bisect import bisect_right
from collections import Counter
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile
import time
import zipfile

N = 152096
EXPECTED_BUCKETS = 23234
EXPECTED_PAIRS = 302624
MAX_BUCKET = 151
MAX_BUCKET_PAIRS = 2936
CASES = 16
LOGICAL_CASES = 4841984
LOGICAL_REFS = 9683968
CHUNK = 65536
MAX_JSON = 1000000
MAX_ARCHIVE = 320000000
MIN_FREE = 1073741824
RECORD = struct.Struct('<8BIhbBIQI')
RECORD_VERSION = 1
MAX_RECORDS = LOGICAL_REFS
MAX_BINARY = 309886976
GREEN = (103, -13, -9, 19, -25)
EPS = tuple(1 if v.bit_count() % 2 == 0 else -1 for v in range(16))
NEIGHBORS = tuple(tuple(v ^ (1 << d) for d in range(4)) for v in range(16))
FACT = (1, 1, 2, 6, 24, 120, 720)
SOURCE_HEAD = '555a8819ed9fe9016c38f6478931240fa8920dab'
NATIVE_HEAD = 'f3b77e5dd96bf517ec9b245b7e6c784621d62655'
NATIVE_ZIP_SHA = 'bdaad6aaac75c337ed5f1bf59501fde081094d837e0bfac78f8bfcc655ac41a7'
NATIVE_MANIFEST_SHA = '5110bc1a2d3ca393629c040dbc13c07578ef36f9819931507481878afc6d6271'
NATIVE_PACKED_SHA = 'a61397f230781794b4c54975486948254d28bf64505402691fa298db4711f8b9'
NATIVE_LABELED_SHA = '61ac89331b24687c1355c16b88ec80d690c9b41df698409687aaefecefd2abf6'
FULL_ENCODING = {
 'triple_labels': '(a<<14)|(b<<7)|c; 7 bits each',
 'labeled_digest': 'struct<BBBI in canonical triple generation order',
 'native_cost_digest': 'unsigned-sorted(key<<14)|(a<<7)|c, little-endian uint32, multiplicity retained',
 'record_struct': '<8BIhbBIQI', 'record_bytes': 32, 'record_version': 1,
 'occupation_bits': 'vertex v at bits2v..2v+1; only0,1,2',
 'curvature_parity_bit': '4*anchor_vertex+axis',
 'class_epsilon': 'diagnostic only; epsilon remains inside full E_alpha polynomial',
 'record_order': 'key increasing; q generation order; p(max,fulltuple) prefix; case ID increasing; root0 then1',
 'publication': 'single ZIP_STORED; direct canonical/private/tmp child; exclusive same-filesystem hard link',
 'refusal': 'no complete support; bounded stderr counters/logical and returned-write prefix hashes; own stage removed',
 'scope': 'complete necessary source/site/cut/paired and individual anchor support only'
}
LIMITS = {'max_seconds': 120, 'triples': N, 'buckets': EXPECTED_BUCKETS,
 'canonical_pairs': EXPECTED_PAIRS, 'max_bucket_triples': MAX_BUCKET,
 'max_bucket_pairs': MAX_BUCKET_PAIRS, 'logical_cases': LOGICAL_CASES,
 'logical_references': LOGICAL_REFS, 'record_bytes': 32, 'max_records': MAX_RECORDS,
 'max_binary_bytes': MAX_BINARY, 'max_json_bytes': MAX_JSON,
 'max_archive_bytes': MAX_ARCHIVE, 'min_free_bytes': MIN_FREE, 'chunk_bytes': CHUNK}

EDGES = tuple((v, d) for v in range(16) for d in range(4) if not v & (1 << d))

EDGE_INDEX = {edge: i for i, edge in enumerate(EDGES)}

PARENT = {v: (v ^ (v & -v), (v & -v).bit_length() - 1) for v in range(1, 16)}

TREE = frozenset(EDGE_INDEX[(p, d)] for p, d in PARENT.values())

NON_TREE = tuple(i for i in range(32) if i not in TREE)

TARGET = {'a': 12, 'b': 6, 'test': '1', 'time_pair': [0, 1],
          'first_axis': 2, 'second_axes': [2, 3],
          'eta_spatial_axis': 1, 'reduced_weight': '8*eta(d)*(1 if nu==2 else -1)'}

NATIVE_ENCODING = {'edge_order': 'root increasing then axis increasing, root bit axis zero',
            'class_order': 'base increasing then lexicographic k<l',
            'tree': 'clear least set bit; root 0', 'syndrome_bits': '17 non-tree edges in edge order',
            'parity_bit': 17, 'record': '(key<<14)|(minlabel<<7)|maxlabel',
            'byte_order': 'little', 'sort': 'unsigned integer nondecreasing',
            'multiplicity': 'preserve every triple including equal packed records',
            'scope': 'lossy cost multiset; middle labels must be regenerated for full support',
            'publication': 'single ZIP_STORED container via exclusive same-filesystem hard link'}

def no_duplicate_json(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('Duplicate JSON key')
        out[key] = value
    return out

def edge_index(v, axis):
    return EDGE_INDEX[(v & ~(1 << axis), axis)]

def key_of(character):
    potential = [0] * 16
    for vertex in range(1, 16):
        parent, axis = PARENT[vertex]
        potential[vertex] = potential[parent] ^ ((character >> edge_index(parent, axis)) & 1)
    syndrome = 0
    for bit, index in enumerate(NON_TREE):
        vertex, axis = EDGES[index]
        value = ((character >> index) & 1) ^ potential[vertex] ^ potential[vertex ^ (1 << axis)]
        syndrome |= value << bit
    return syndrome | ((sum(potential) & 1) << 17)

def classes():
    result = []
    for z in range(16):
        for k, l in itertools.combinations(range(4), 2):
            mu, nu = tuple(axis for axis in range(4) if axis not in (k, l))
            anchors = ((z, l, True), (z ^ (1 << l), k, True),
                       (z ^ (1 << k), l, False), (z, k, False))
            character = (1 << edge_index(z, mu)) ^ (1 << edge_index(z, nu))
            for vertex, axis, dagger in anchors:
                character ^= 1 << edge_index(vertex, axis)
            load = [0] * 16
            load[z] += 2
            load[z ^ (1 << mu)] += 1
            load[z ^ (1 << nu)] += 1
            order = (k, l, mu, nu)
            epsilon = -1 if sum(order[a] > order[b] for a in range(4) for b in range(a + 1, 4)) % 2 else 1
            result.append({'id': len(result), 'center': z, 'curvature': [k, l],
                           'frames': [mu, nu], 'epsilon': epsilon, 'load': load,
                           'anchors_H_order': anchors, 'character_hex': format(character, '08x'),
                           'key': key_of(character)})
    if len(result) != 96 or len(EDGES) != 32 or len(TREE) != 15 or len(NON_TREE) != 17:
        raise RuntimeError('Original descriptor count mismatch')
    return result

def source_cases():
    result = []
    for displacement in range(8):
        vertex = 1 | (displacement << 1)
        eta = -1 if displacement & 1 else 1
        for nu in (2, 3):
            result.append({'id': len(result), 'times': [0, 1],
                           'source_vertices': [0, vertex], 'source_axes': [2, nu],
                           'spatial_displacement': displacement,
                           'weight': 8 * eta * (1 if nu == 2 else -1)})
    return result

class Refusal(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise Refusal(message)


def digest_path(path, check):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while True:
            chunk = stream.read(CHUNK)
            if not chunk:
                break
            hasher.update(chunk)
            check()
    return hasher.hexdigest()


def small_bytes(path):
    require(Path(path).stat().st_size <= MAX_JSON, 'Small-input byte guard')
    data = Path(path).read_bytes()
    require(len(data) <= MAX_JSON, 'Small-input byte guard after read')
    return data


def json_shape(value):
    return json.loads(json.dumps(value, sort_keys=True))


def triple_labels(word):
    return (word >> 14) & 127, (word >> 7) & 127, word & 127


def run(args, state):
    started = time.monotonic()
    require(0 < args.deadline_seconds <= 120, 'Deadline positive and at most120seconds')

    def deadline():
        require(time.monotonic() - started <= args.deadline_seconds, 'Cooperative deadline; incomplete support')

    raw_spec = small_bytes(args.spec)
    require(hashlib.sha256(raw_spec).hexdigest() == args.spec_sha256, 'Exact spec hash mismatch')
    spec = json.loads(raw_spec.decode('utf-8'), object_pairs_hook=no_duplicate_json)
    required = {'schema_version', 'task', 'source_head', 'repo_root', 'code_sha256',
                'input_pins', 'target', 'native_key_path', 'native_zip_sha256',
                'native_manifest_sha256', 'native_packed_sha256', 'native_labeled_sha256',
                'native_source_head', 'native_encoding', 'encoding', 'limits'}
    require(set(spec) == required and spec['schema_version'] == 1 and spec['task'] == 'l1-sixehc-complete-support-r1', 'Spec identity/schema mismatch')
    require(spec['source_head'] == SOURCE_HEAD and spec['native_source_head'] == NATIVE_HEAD, 'Current/native source identity mismatch')
    require(spec['target'] == TARGET and spec['encoding'] == FULL_ENCODING and spec['native_encoding'] == NATIVE_ENCODING and spec['limits'] == LIMITS, 'Frozen scientific/profile contract mismatch')
    require(spec['native_zip_sha256'] == NATIVE_ZIP_SHA and spec['native_manifest_sha256'] == NATIVE_MANIFEST_SHA and spec['native_packed_sha256'] == NATIVE_PACKED_SHA and spec['native_labeled_sha256'] == NATIVE_LABELED_SHA, 'Native pin contract mismatch')
    require(digest_path(__file__, deadline) == spec['code_sha256'], 'Exact program bytes mismatch')
    repo = Path(spec['repo_root']).resolve(strict=True)
    require(isinstance(spec['input_pins'], dict) and spec['input_pins'], 'Scientific input pins absent')
    for relative, expected in spec['input_pins'].items():
        path = (repo / relative).resolve(strict=True)
        require(path.is_relative_to(repo), 'Input outside assigned repo')
        require(digest_path(path, deadline) == expected, 'Scientific input pin mismatch')
    native_path = Path(spec['native_key_path']).resolve(strict=True)
    require(native_path.is_relative_to(repo) and digest_path(native_path, deadline) == NATIVE_ZIP_SHA, 'Exact inherited native key ZIP mismatch')
    requested = Path(os.path.abspath(args.output))
    output = requested.parent.resolve(strict=True) / requested.name
    require(output.parent == Path('/private/tmp') and output.suffix == '.zip' and not os.path.lexists(output), 'Output must be a NEW direct/private/tmp ZIP, no final symlink')
    free_before = shutil.disk_usage('/private/tmp').free
    require(free_before >= MIN_FREE, 'Read-only disk preflight refusal; no repair attempted')
    require(array('I').itemsize == 4 and array('h').itemsize == 2 and RECORD.size == 32, 'Platform packing item sizes mismatch')

    with zipfile.ZipFile(native_path) as zipped:
        require(set(zipped.namelist()) == {'COST_RECORDS_LE32.bin', 'MANIFEST.json'} and len(zipped.namelist()) == 2, 'Native key member set mismatch')
        require(zipped.getinfo('MANIFEST.json').file_size <= MAX_JSON, 'Native manifest byte cap')
        raw_native = zipped.read('MANIFEST.json')
        require(hashlib.sha256(raw_native).hexdigest() == NATIVE_MANIFEST_SHA, 'Native manifest hash mismatch')
        native = json.loads(raw_native.decode('utf-8'), object_pairs_hook=no_duplicate_json)
        hasher = hashlib.sha256()
        packed_bytes = 0
        with zipped.open('COST_RECORDS_LE32.bin') as member:
            while True:
                chunk = member.read(CHUNK)
                if not chunk:
                    break
                packed_bytes += len(chunk)
                hasher.update(chunk)
                deadline()
        require(packed_bytes == 608384 and hasher.hexdigest() == NATIVE_PACKED_SHA, 'Native cost multiset hash/size mismatch')
    require(native['source_head'] == NATIVE_HEAD and native['target'] == TARGET and native['encoding'] == NATIVE_ENCODING, 'Native source/profile/encoding mismatch')
    require(native['status'] == 'complete_triple_key_cost_census_only' and native['triples'] == N and native['canonical_key_pairs'] == EXPECTED_PAIRS and native['key_buckets'] == EXPECTED_BUCKETS and native['largest_bucket_triples'] == MAX_BUCKET and native['largest_bucket_canonical_pairs'] == MAX_BUCKET_PAIRS, 'Native measured domain mismatch')
    require(native['full_labeled_triples_in_canonical_generation_order_sha256'] == NATIVE_LABELED_SHA, 'Native full-label digest pin mismatch')
    for relative, pin in native['input_pins'].items():
        require(spec['input_pins'].get(relative) == pin, 'Native scientific body lineage mismatch')

    descriptors = classes()
    cases = source_cases()
    require(json_shape(descriptors) == native['classes'] and json_shape(cases) == native['target_cases'], 'Regenerated full class/source metadata mismatch')
    require(json_shape(EDGES) == native['edges'] and sorted(TREE) == native['tree_edge_indices'] and list(NON_TREE) == native['non_tree_edge_indices'], 'Regenerated edge/tree basis mismatch')
    require(all(case['times'] == [0, 1] and case['source_vertices'][0] == 0 and case['source_vertices'][1] & 1 for case in cases), 'Source times/endpoints not adjacent-time target')
    class_char = [int(item['character_hex'], 16) for item in descriptors]
    class_green = []
    for item in descriptors:
        z = item['center']
        mu, nu = item['frames']
        values = [2 * GREEN[(v ^ z).bit_count()] + GREEN[(v ^ (z ^ (1 << mu))).bit_count()] + GREEN[(v ^ (z ^ (1 << nu))).bit_count()] for v in range(16)]
        require(all(abs(value) <= 412 for value in values), 'Class Green bound failure')
        require(sum(EPS[v] * item['load'][v] for v in range(16)) == 0 and sum(item['load']) == 4, 'Class original load balance failure')
        class_green.append(values)
    source_loads = []
    source_greens = []
    source_edges = []
    case_map = {}
    case_fingerprints = []
    for case in cases:
        endpoints = []
        edges = []
        load = [0] * 16
        for vertex, axis in zip(case['source_vertices'], case['source_axes']):
            neighbor = vertex ^ (1 << axis)
            endpoints.extend((vertex, neighbor))
            edges.append(edge_index(vertex, axis))
            load[vertex] += 2
            load[neighbor] += 2
        require(len(set(edges)) == 2 and sum(load) == 8 and sum(EPS[v] * load[v] for v in range(16)) == 0, 'Source spatial edge/load balance failure')
        values = [2 * sum(GREEN[(v ^ endpoint).bit_count()] for endpoint in endpoints) for v in range(16)]
        require(all(abs(value) <= 824 for value in values), 'Source Green bound failure')
        fingerprint = tuple(-(values[v] - EPS[v] * values[0]) % 384 for v in range(1, 16))
        case_map.setdefault(fingerprint, []).append(case['id'])
        case_fingerprints.append(list(fingerprint))
        source_loads.append(load)
        source_greens.append(values)
        source_edges.append(edges)
    require(sorted(case for group in case_map.values() for case in group) == list(range(16)), 'Source fingerprint map dropped a case')
    require(case_fingerprints[2] == case_fingerprints[6], 'Endpoint-distinct source fingerprint control mismatch')

    labels = array('I')
    keys = array('I')
    triple_green = array('h')
    cost_words = array('I')
    buckets = {}
    labeled_hasher = hashlib.sha256()
    for index, (a, b, c) in enumerate(itertools.combinations_with_replacement(range(96), 3)):
        key = descriptors[a]['key'] ^ descriptors[b]['key'] ^ descriptors[c]['key']
        require(0 <= key < (1 << 18), 'Triple key outside18bits')
        word = (a << 14) | (b << 7) | c
        require(0 <= word < (1 << 21), 'Full label packing outside21bits')
        labels.append(word)
        keys.append(key)
        cost_words.append((key << 14) | (a << 7) | c)
        buckets.setdefault(key, []).append(index)
        labeled_hasher.update(struct.pack('<BBBI', a, b, c, key))
        for vertex in range(16):
            value = class_green[a][vertex] + class_green[b][vertex] + class_green[c][vertex]
            require(abs(value) <= 1236, 'Triple Green signed16 bound failure')
            triple_green.append(value)
        if index % 1024 == 0:
            deadline()
    require(len(labels) == len(keys) == N and len(triple_green) == N * 16 and len(buckets) == EXPECTED_BUCKETS, 'Regenerated labeled domain counts mismatch')
    require(labeled_hasher.hexdigest() == NATIVE_LABELED_SHA, 'Regenerated full middle-label digest mismatch')
    sorted_cost = sorted(cost_words)
    regenerated_cost_hasher = hashlib.sha256()
    for index, word in enumerate(sorted_cost):
        regenerated_cost_hasher.update(struct.pack('<I', word))
        if index % 4096 == 0:
            deadline()
    require(regenerated_cost_hasher.hexdigest() == NATIVE_PACKED_SHA, 'Regenerated native cost ordering/multiset mismatch')
    del sorted_cost, cost_words
    require(max(map(len, buckets.values())) == MAX_BUCKET, 'Regenerated maximum bucket mismatch')
    typed_payload = len(labels) * labels.itemsize + len(keys) * keys.itemsize + len(triple_green) * triple_green.itemsize
    require(typed_payload == 6083840, 'Typed payload accounting mismatch')
    stats = state['stats']
    stats.update({'buckets_completed': 0, 'pairs_started': 0, 'pairs_completed': 0,
                  'logical_cases_started': 0, 'logical_cases_completed': 0,
                  'logical_references_started': 0, 'nonintegral_cases_rejected': 0,
                  'matching_cases_evaluated': 0, 'actual_roots_evaluated': 0,
                  'logical_ref_rejections': {'integrality': 0, 'range': 0, 'cut': 0, 'individual_anchor': 0},
                  'records': 0, 'binary_bytes_logical': 0, 'binary_bytes_returned_writes': 0,
                  'records_by_case': [0] * 16, 'records_by_root': [0, 0],
                  'max_bucket_pairs_observed': 0, 'max_coframes_edge_tested': 0,
                  'max_anchor_curvature_tested': 0, 'max_anchor_degree_upper_source_tested': 0,
                  'max_anchor_degree_upper_nonsource_tested': 0})
    logical_digest = hashlib.sha256()
    flushed_digest = hashlib.sha256()
    state['logical_digest'] = logical_digest
    state['flushed_digest'] = flushed_digest
    witness_cases = set()
    required_witness_m = tuple(2 if v in (5, 6, 9, 10, 12, 15) else 0 for v in range(16))
    staging = Path(tempfile.mkdtemp(prefix='.l1-sixehc-support-staging-', dir=output.parent))
    buffer = bytearray()
    try:
        archive = staging / 'OUTPUT.zip'
        with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_STORED, allowZip64=False) as zipped:
            info = zipfile.ZipInfo('SUPPORT_RECORDS_LE.bin', date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            with zipped.open(info, 'w') as binary_out:
                def flush():
                    if buffer:
                        require(binary_out.write(buffer) == len(buffer), 'Short support stream write')
                        flushed_digest.update(buffer)
                        stats['binary_bytes_returned_writes'] += len(buffer)
                        buffer.clear()
                        deadline()

                def emit(class_ids, case_id, m, root, divisor, epsilon_product, curvature_mask):
                    require(tuple(sorted(class_ids)) == class_ids and len(class_ids) == 6 and all(0 <= label < 96 for label in class_ids), 'Record full-label validation failure')
                    require(0 <= case_id < 16 and root in (0, 1) and m[0] == root and all(value in (0, 1, 2) for value in m), 'Record case/root/occupation invalid')
                    weight = cases[case_id]['weight']
                    require(weight in (-8, 8) and epsilon_product in (-1, 1) and 0 < divisor <= 46080 and 0 <= curvature_mask < (1 << 64), 'Record signed scalar/mask invalid')
                    m_bits = sum(value << (2 * vertex) for vertex, value in enumerate(m))
                    values = (*class_ids, case_id, RECORD_VERSION, m_bits, weight, epsilon_product, root, divisor, curvature_mask, 0)
                    packed = RECORD.pack(*values)
                    require(RECORD.unpack(packed) == values, 'Exact record roundtrip failure')
                    require(stats['records'] < MAX_RECORDS, 'Output record ceiling exceeded')
                    logical_digest.update(packed)
                    buffer.extend(packed)
                    stats['records'] += 1
                    stats['binary_bytes_logical'] += RECORD.size
                    stats['records_by_case'][case_id] += 1
                    stats['records_by_root'][root] += 1
                    require(stats['binary_bytes_logical'] <= MAX_BINARY, 'Output binary byte ceiling exceeded')
                    if len(buffer) >= CHUNK:
                        flush()
                    if class_ids == (1, 1, 11, 11, 21, 21) and tuple(m) == required_witness_m and case_id in (2, 6):
                        require(root == 0 and divisor == 512 and weight == -8 and epsilon_product == 1 and curvature_mask == 0, 'Known original witness scalar mismatch')
                        witness_cases.add(case_id)

                for key in sorted(buckets):
                    indices = buckets[key]
                    require(len(indices) <= MAX_BUCKET, 'Bucket grouping cap exceeded; incomplete')
                    p_order = sorted(indices, key=lambda idx: (labels[idx] & 127, labels[idx]))
                    maxima = [labels[idx] & 127 for idx in p_order]
                    bucket_pairs = sum(bisect_right(maxima, (labels[q_index] >> 14) & 127) for q_index in indices)
                    require(bucket_pairs <= MAX_BUCKET_PAIRS, 'Canonical bucket pair cap exceeded; incomplete')
                    stats['max_bucket_pairs_observed'] = max(stats['max_bucket_pairs_observed'], bucket_pairs)
                    completed_here = 0
                    for q_index in indices:
                        q_labels = triple_labels(labels[q_index])
                        prefix = bisect_right(maxima, q_labels[0])
                        for p_position in range(prefix):
                            p_index = p_order[p_position]
                            p_labels = triple_labels(labels[p_index])
                            class_ids = p_labels + q_labels
                            require(p_labels[-1] <= q_labels[0] and keys[p_index] == keys[q_index] == key, 'Canonical class split/key mismatch')
                            stats['pairs_started'] += 1
                            require(stats['pairs_started'] <= EXPECTED_PAIRS, 'Global canonical pair cap exceeded; incomplete')
                            stats['logical_cases_started'] += 16
                            stats['logical_references_started'] += 32
                            state['position'] = {'key': key, 'classes': class_ids, 'case': None, 'root': None}
                            deadline()
                            p_offset, q_offset = p_index * 16, q_index * 16
                            combined = [int(triple_green[p_offset + v]) + int(triple_green[q_offset + v]) for v in range(16)]
                            fingerprint = tuple((combined[v] - EPS[v] * combined[0]) % 384 for v in range(1, 16))
                            matches = case_map.get(fingerprint, ())
                            nonmatches = 16 - len(matches)
                            stats['nonintegral_cases_rejected'] += nonmatches
                            stats['logical_cases_completed'] += nonmatches
                            stats['logical_ref_rejections']['integrality'] += 2 * nonmatches
                            if matches:
                                class_load = [0] * 16
                                frame_counts = [0] * 32
                                curvature_counts = [0] * 64
                                total_character = 0
                                epsilon_product = 1
                                for label in class_ids:
                                    item = descriptors[label]
                                    for vertex in range(16):
                                        class_load[vertex] += item['load'][vertex]
                                    for axis in item['frames']:
                                        frame_counts[edge_index(item['center'], axis)] += 1
                                    for vertex, axis, dagger in item['anchors_H_order']:
                                        curvature_counts[4 * vertex + axis] += 1
                                    total_character ^= class_char[label]
                                    epsilon_product *= item['epsilon']
                                class_divisor = 1
                                for multiplicity in Counter(class_ids).values():
                                    class_divisor *= FACT[multiplicity]
                                curvature_mask = sum((value & 1) << index for index, value in enumerate(curvature_counts))
                                for case_id in matches:
                                    state['position']['case'] = case_id
                                    b_case = source_greens[case_id]
                                    vnum = [384 - combined[v] - b_case[v] for v in range(16)]
                                    require(all(abs(value) <= 3680 for value in vnum), 'Green vnum bound failure')
                                    numerators0 = [vnum[v] - EPS[v] * vnum[0] for v in range(16)]
                                    require(all(value % 384 == 0 for value in numerators0), 'Fingerprint equivalence/integrality invariant failed')
                                    base_m = [value // 384 for value in numerators0]
                                    rhs = [8 - class_load[v] - source_loads[case_id][v] for v in range(16)]
                                    require(sum(rhs) == 96 and sum(EPS[v] * rhs[v] for v in range(16)) == 0, 'Original RHS total/checkerboard invariant failed')
                                    stats['matching_cases_evaluated'] += 1
                                    for root in (0, 1):
                                        state['position']['root'] = root
                                        stats['actual_roots_evaluated'] += 1
                                        require(all(abs(numerators0[v] + 384 * root * EPS[v]) <= 7744 for v in range(16)), 'Occupation numerator bound failure')
                                        m = [base_m[v] + root * EPS[v] for v in range(16)]
                                        if any(value < 0 or value > 2 for value in m):
                                            stats['logical_ref_rejections']['range'] += 1
                                            continue
                                        require(m[0] == root and sum(m) == 12, 'Original occupation root/total invariant failed')
                                        require(all(4 * m[v] + sum(m[w] for w in NEIGHBORS[v]) == rhs[v] for v in range(16)), 'DIRECT original16site equations failed')
                                        occupation_cut = 0
                                        for edge, (vertex, axis) in enumerate(EDGES):
                                            if (m[vertex] + m[vertex ^ (1 << axis)]) & 1:
                                                occupation_cut ^= 1 << edge
                                        if occupation_cut != total_character:
                                            stats['logical_ref_rejections']['cut'] += 1
                                            continue
                                        individual_ok = True
                                        source_edge_set = source_edges[case_id]
                                        for edge, (vertex, axis) in enumerate(EDGES):
                                            neighbor = vertex ^ (1 << axis)
                                            cosmological = m[vertex] + m[neighbor]
                                            n = cosmological + frame_counts[edge] + (2 if edge in source_edge_set else 0)
                                            c_u = curvature_counts[4 * vertex + axis]
                                            c_v = curvature_counts[4 * neighbor + axis]
                                            require(cosmological <= 2 and n <= 8, 'Original edge/site upper-bound invariant failed')
                                            require((n + c_u + c_v) % 2 == 0, 'PAIRED anchor parity contradicts actual cut check')
                                            degree_upper = max(n + c_u, n + c_v)
                                            source_edge = edge in source_edge_set
                                            require(degree_upper <= (10 if source_edge else 8), 'GLOBAL original moment-degree upper bound failed')
                                            stats['max_coframes_edge_tested'] = max(stats['max_coframes_edge_tested'], n)
                                            stats['max_anchor_curvature_tested'] = max(stats['max_anchor_curvature_tested'], c_u, c_v)
                                            field = 'max_anchor_degree_upper_source_tested' if source_edge else 'max_anchor_degree_upper_nonsource_tested'
                                            stats[field] = max(stats[field], degree_upper)
                                            if n == 0 and (c_u % 2 or c_v % 2):
                                                individual_ok = False
                                        if not individual_ok:
                                            stats['logical_ref_rejections']['individual_anchor'] += 1
                                            continue
                                        doubles = sum(value == 2 for value in m)
                                        divisor = (1 << doubles) * class_divisor
                                        require(doubles <= 6 and divisor <= 46080, 'Exact factorial upper-bound invariant failed')
                                        emit(class_ids, case_id, m, root, divisor, epsilon_product, curvature_mask)
                                    stats['logical_cases_completed'] += 1
                            stats['pairs_completed'] += 1
                            completed_here += 1
                            state['last_completed_pair'] = {'key': key, 'classes': class_ids}
                    require(completed_here == bucket_pairs, 'Whole bucket canonical pair count mismatch')
                    stats['buckets_completed'] += 1
                flush()
                require(stats['buckets_completed'] == EXPECTED_BUCKETS and stats['pairs_started'] == stats['pairs_completed'] == EXPECTED_PAIRS and stats['max_bucket_pairs_observed'] == MAX_BUCKET_PAIRS, 'INCOMPLETE canonical bucket/pair coverage')
                require(stats['logical_cases_started'] == stats['logical_cases_completed'] == LOGICAL_CASES and stats['logical_references_started'] == LOGICAL_REFS, 'INCOMPLETE logical source/reference coverage')
                require(stats['actual_roots_evaluated'] == 2 * stats['matching_cases_evaluated'] and stats['logical_ref_rejections']['integrality'] == 2 * stats['nonintegral_cases_rejected'], 'Logical versus evaluated-reference accounting mismatch')
                require(stats['records'] + sum(stats['logical_ref_rejections'].values()) == LOGICAL_REFS, 'Terminal reference partition incomplete')
                require(sum(stats['records_by_case']) == sum(stats['records_by_root']) == stats['records'], 'Per-source/root retained counter mismatch')
                require(witness_cases == {2, 6}, 'Missing actual generated known necessary witness/source endpoint case')
                require(not buffer and stats['binary_bytes_logical'] == stats['binary_bytes_returned_writes'] == RECORD.size * stats['records'] and logical_digest.hexdigest() == flushed_digest.hexdigest(), 'Streamed support bytes/hash incomplete')
            deadline()
            manifest = {
                'status': 'complete_necessary_source_site_cut_paired_individual_anchor_support_only',
                'task': spec['task'], 'source_head': SOURCE_HEAD, 'inherited_native_source_head': NATIVE_HEAD,
                'program_sha256': spec['code_sha256'], 'spec_sha256': args.spec_sha256,
                'input_pins': spec['input_pins'], 'native_zip_sha256': NATIVE_ZIP_SHA,
                'native_manifest_sha256': NATIVE_MANIFEST_SHA, 'native_packed_sha256': NATIVE_PACKED_SHA,
                'regenerated_full_labeled_sha256': labeled_hasher.hexdigest(),
                'target': TARGET, 'native_encoding': NATIVE_ENCODING, 'encoding': FULL_ENCODING, 'limits': LIMITS,
                'classes': descriptors, 'target_cases': cases, 'edges': EDGES,
                'case_integrality_fingerprints_v1_to15_mod384': case_fingerprints,
                'counters': stats, 'required_witness_cases_found': sorted(witness_cases),
                'records_member': {'name': 'SUPPORT_RECORDS_LE.bin', 'bytes': stats['binary_bytes_logical'], 'records': stats['records'], 'sha256': logical_digest.hexdigest()},
                'typed_numeric_payload_bytes': typed_payload, 'additional_memory': 'Python bucket/index/sort/native metadata/ZIP buffers; NOT RSS-qualified',
                'disk_free_before_science': free_before,
                'elapsed_seconds_before_manifest_and_publish': time.monotonic() - started,
                'peak_memory': None, 'resource_qualification': 'UNKNOWN',
                'deadline_kind': 'cooperative_refusal_not_hard_preemption', 'deadline_seconds': args.deadline_seconds,
                'local_chiral_exterior_support': 'NOT_RUN', 'haar_or_amplitude': 'NOT_RUN', 'coefficient': 'NOT_RUN',
                'physical_transfer': 'OPEN', 'admission': 'caller must supply separate explicit ROOT authority'
            }
            raw_manifest = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode('utf-8')
            require(len(raw_manifest) <= MAX_JSON, 'Final manifest byte cap exceeded; incomplete')
            zipped.writestr('MANIFEST.json', raw_manifest)
        deadline()
        size = archive.stat().st_size
        overhead = size - stats['binary_bytes_logical'] - len(raw_manifest)
        require(0 <= overhead < 1024 and size <= MAX_ARCHIVE, 'Final container cap/overhead mismatch; incomplete')
        with zipfile.ZipFile(archive) as zipped:
            require(len(zipped.namelist()) == 2 and set(zipped.namelist()) == {'SUPPORT_RECORDS_LE.bin', 'MANIFEST.json'}, 'Final exact member set mismatch')
            for name, expected_bytes, expected_sha in (
                ('SUPPORT_RECORDS_LE.bin', stats['binary_bytes_logical'], logical_digest.hexdigest()),
                ('MANIFEST.json', len(raw_manifest), hashlib.sha256(raw_manifest).hexdigest())):
                info = zipped.getinfo(name)
                require(info.file_size == expected_bytes and info.compress_type == zipfile.ZIP_STORED, 'Final member size/compression mismatch')
                hasher, length = hashlib.sha256(), 0
                with zipped.open(name) as member:
                    while True:
                        chunk = member.read(CHUNK)
                        if not chunk:
                            break
                        length += len(chunk)
                        hasher.update(chunk)
                        deadline()
                require(length == expected_bytes and hasher.hexdigest() == expected_sha, 'Streaming member hash/CRC readback failed')
        archive_hash = digest_path(archive, deadline)
        deadline()
        os.link(archive, output)
        state['published_by_this_run'] = True
    finally:
        shutil.rmtree(staging)
    print(json.dumps({'status': manifest['status'], 'output': str(output), 'container_sha256': archive_hash,
                      'container_bytes': size, 'manifest_sha256': hashlib.sha256(raw_manifest).hexdigest(),
                      'records_sha256': logical_digest.hexdigest(), 'records': stats['records'],
                      'pairs_completed': stats['pairs_completed'], 'logical_references': LOGICAL_REFS,
                      'peak_memory': None, 'haar_or_amplitude': 'NOT_RUN', 'coefficient': 'NOT_RUN'}, sort_keys=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec', required=True)
    parser.add_argument('--spec-sha256', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--deadline-seconds', required=True, type=float)
    args = parser.parse_args()
    state = {'published_by_this_run': False, 'stats': {}, 'position': None, 'last_completed_pair': None}
    try:
        run(args, state)
    except Exception as error:
        status = 'ERROR_AFTER_COMPLETE_PUBLICATION' if state['published_by_this_run'] else 'REFUSED_INCOMPLETE_NO_COMPLETE_OUTPUT_FROM_THIS_RUN'
        receipt = {'status': status, 'published_by_this_run': state['published_by_this_run'],
                   'error': str(error), 'counters': state['stats'], 'position': state['position'],
                   'last_completed_pair': state['last_completed_pair'],
                   'logical_record_prefix_sha256': state['logical_digest'].hexdigest() if 'logical_digest' in state else None,
                   'successfully_returned_write_prefix_sha256': state['flushed_digest'].hexdigest() if 'flushed_digest' in state else None,
                   'prefix_is_not_resumable_support': True, 'coefficient': 'NOT_RUN', 'peak_memory': None}
        raw = json.dumps(receipt, sort_keys=True)
        # Stats are fixed-size counters; cap failure reporting as well.
        if len(raw.encode('utf-8')) > MAX_JSON:
            raw = json.dumps({'status': status, 'error': 'Refusal receipt cap', 'coefficient': 'NOT_RUN'})
        print(raw, file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
