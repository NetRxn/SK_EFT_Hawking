# Original physical mandates versus adopted N16 state premises

Read-only source/charter intake, task `L1-original-premise-correspondence-source-intake`, parent publication-L1-original-state-premise-correspondence. Packet `l1-original-premise-correspondence-intake-r1.json` fresh at entry; source `6905caf8ad86d769472c1adb6c83d7529c975d35`. Read the referenced primary notebook, Phase6a/PR115 charters, held primary bodies and current accepted scope records. Only this scratch report was written. No scientific evaluator/CAS/matrix/Haar work, tests/builds, Lean, slots/controller, Git/candidate/notebook changes. This is not a proof review of the lead's new robustness derivation.

## Main correspondence finding

The original programme positively requires a genuine metric/source/state/dynamics construction, and the inspected primary bodies positively motivate composite fermion geometry and an eventual physical operator/state interpretation. The adopted finite periodic2^4 algebra/reflection test is a concrete, source-correct research construction with a now accepted incompatibility on its declared full algebra. Those are different levels of statement.

In the actual passages inspected, the original physical mandates are NOT identified by a demonstrated correspondence with all of these additional candidate premises simultaneously: this particular finite periodic N16 size/boundary; the entire formal even gauge-invariant Grassmann half-polynomial algebra as the physical operator algebra; the exact candidate geometric theta as the physical adjoint; and a positive normalized reflection reconstruction for that same finite functional. This is a bounded missing demonstrated map, not a proof that such correspondence is impossible, never existed elsewhere, or that the original theory excludes these premises.

No replacement algebra, quotient, adjoint, boundary condition, action term or special coupling is proposed here. The current witness cannot be removed by an unsupported restriction. Conversely the witness's adopted premises cannot be silently promoted into universal original-theory axioms merely because the finite action has the correct microscopic ingredients.

## 1. Owning charters: what is actually mandatory

`docs/roadmaps/Phase6a_Roadmap.md`, CURRENT L1 charter lines3–12, requires the actual metric operator/source/projector, regulator and normalization, independently stable domain, physical propagating modes/matter coupling and transport. B3's order-Lambda-squared normalization and [0.1,10] are to be DERIVED; no fitted source, chi=1 or tiny damping can substitute. Historical Wave2 identified-mode/software milestones do not satisfy these physical obligations.

PR115's owning roadmap at `/Users/johnroehm/Documents/Codex/2026-11-05/task-2/delivery/docs/roadmaps/L1_Physical_Bridges_Roadmap.md`, W1 “Physical source/state reconstruction” (around62–82), explicitly says to fix the regulated action, source variation, OPERATOR ALGEBRA, gauge/constraints, spatial/time boundaries, reality convention and STATE, then DERIVE their source-to-metric map/domain. Its accepted outcomes are an actual state/transfer/reconstruction with positive physical correlators and controlled regulator dependence, or a scoped impossibility/counterexample under precisely named assumptions. It requires physical justification of any changed source/projection/continuation and forbids replacing a state with a stipulated positive covariance.

Thus actual physical positivity and faithful source correspondence are mandatory ENDPOINTS for a positive W1 construction. The charter does not declare every finite Euclidean polynomial presentation automatically to be the physical Hilbert-space algebra with the candidate theta. It explicitly makes that identification a research obligation. A scoped negative result is admissible without equating it to final original-L1 impossibility or publication closure.

W2 consumes W1's ACTUAL state/source and uses the same normalized functional with all contacts, units, tensor/projector and stability information. W3 needs constrained spin2 dynamics and a same-background matter/light reference; W4 needs causal real-time/observational matching. These remain full-strength. No premise distinction grants a deferral/reduction or a new model choice.

## 2. Diakonov2011v1: positive support and limits

Primary: [1109.0091v1](https://arxiv.org/abs/1109.0091v1), held `/private/tmp/l1-diakonov2011-source.txt`.

- SectionI, text roughly42–54: Euclidean-first quantization is explicitly motivated despite physical Minkowski signature. The text regards a well-defined Euclidean theory as important for large fluctuations, thermodynamics and tunneling and anticipates Wick rotation. This is positive motivation for an honest Euclidean regulator. It is not a proof of a particular finite reflection-positive reconstruction or its physical adjoint.
- SectionV.D equation(23), held585–609: the covariant composite tetrad has a family of forward/backward discretizations labeledalpha. The author calls alpha=1/2 natural because of the intended inner/world vector behavior under P and T inversions. This positively supports preserving the original symmetric four endpoint terms and taking inversion covariance seriously. It does NOT identify our entire antilinear Grassmann theta/form with a physical operator adjoint or prove the FULL action's state positivity.
- SectionV.E equations(24),(25), held626–664: determinant cosmological and curvature/tetrad-pair EHC interactions are explicit. SectionV.F equations(26),(27), held669–689: eight Grassmann variables/site, fixed top Berezin extraction and normalized compact chiral Haar are explicit. Equation(28), held690–703, has dimensionless g1,g2 and exp(+action), with an ellipsis allowing specified higher-derivative terms. It says the finite-volume integral is well-defined and finite. That statement is not nonzero fullZ, nonnegative bag weights or reflection positivity.
- SectionVI, held705–802: there is explicitly no bare bilinear propagator; the theory is multifermion. Taylor/saturation/gauge-invariant monomial/loop organization is discussed. Mean-field/long-loop infrared emergence remains an analysis to perform, not a demonstrated state/continuum map.

Our two-term closed-action comparison retains the actually adopted S4+S2 interactions and the accepted full endpoint/plaquette correspondence. The primary's ellipsis does not authorize silently adding interactions to evade a result for that fixed two-term action. Equally, a result for that specified action does not establish a theorem about EVERY higher-term completion contemplated by equation(28).

Neither these passages nor finite-volume finiteness specify that the unique intended physical regulator is periodic2x2x2x2 or prove that the finite periodic fermion integral is an ordinary Gibbs trace. The source's Euclidean-first and naturalalpha statements are real support for the candidate's motivation, but weaker than the required state/adjoint/boundary correspondence.

## 3. Volovik2312.09435v2: the physical metric is an expectation

Primary: [2312.09435v2](https://arxiv.org/abs/2312.09435v2), held `/private/tmp/l1-volovik-vestigial-source.txt`; header verifies v2.

SectionIII, equations(18)–(22), held170–200, explicitly distinguishes:

- the fermionic bilinear operator Ehat and ordinary tetrad order parameter e=<Ehat>, equation(18);
- a proposed vestigial phase with <Ehat>=0 but `g_mu,nu=eta_ab <Ehat_mu^a Ehat_nu^b>` nonzero, equation(19);
- a proposed sequence disorder->metric GR->tetrad ECSK, equation(20);
- tetradic plus connected-quartet metric pieces, equations(21),(22), and different possible fermion/boson couplings.

This supplies a concrete positive physical mandate: derive an ORDINARY expectation-valued metric and its matter/source significance. It does not identify that metric with a nilpotent configuration polynomial or with an externally added positive body. The existing `B/PHYSICAL_MATCHING_DECOMPOSITION.md:2–3` already reconciles this distinction and the actual missing G/A/B/D/matter map; it should be reused, not replaced with an assumed body.

The displayed primary equations do not specify our finite N16 periodic source ensemble, full formal half-Grassmann algebra, candidate geometric theta, or a proof that all its high-degree monomials have the same operator-product/adjoint meaning. They also do not exclude high composite physical observables. The exact insertion/product/adjoint map must be demonstrated rather than settled by the word “operator.” The contraction eta_ab and intended spacetime interpretation also require the actual Euclidean/physical matching; an N4 Euclidean SPD result is not automatically a Lorentzian metric conclusion.

## 4. Vergeles2506.00036v2: unitarity precedent, not an inherited N16 Hilbert space

Primary: [2506.00036v2](https://arxiv.org/abs/2506.00036v2), held `/private/tmp/l1-vergeles2025-source.txt`.

SectionsII–III specify a simplicial model, independent edge tetrad/connection in(2.1), gravity/Dirac/cosmological terms(2.3)–(2.9), and a contour continuation to Minkowski Spin(3,1) in(2.16)–(2.26). Local time moves preserve degrees of freedom and use gauge fixing. These are concrete state-construction ingredients, not the unchanged compact periodic hypercubic Euclidean functional.

SectionIV(4.1) defines the boundary scalar product; (4.3) assumes an ONB; (4.4) normalizable states; (4.5) finite local-action matrix elements; (4.6)–(4.7) an adjoint/reversed-move gauge identification; (4.8) a complete real-eigenvalue eigenbasis; and (4.10) norm preservation under the resulting exp(iA). These assumptions cannot be inherited to prove positivity of the N16 form whose physical correspondence is the present question.

The crucial nuance is sectionVI(6.1), held675–710: the paper EXPLICITLY extends its discussion to replacing tetrads by the stated fermion bilinearTheta and says its conclusions remain, while retaining gauge/noncompact-volume issues. It is inaccurate to treat the source as exclusively independent-tetrad. This is positive motivation to investigate a composite-state construction. It still does not provide the specific action/contour/time-boundary/algebra/adjoint/source map from that modification to our finite Euclidean N16 candidate.

No conclusion about the paper's global validity is drawn here. The limited finding is that its exhibited Minkowski Hilbert/evolution premises do not identify our chosen finite reflection form by citation alone.

## 5. CGL1511.03646v3: actual operator-state convention

Primary: [1511.03646v3](https://arxiv.org/abs/1511.03646v3), held `/private/tmp/l1-crossley2017-source.txt`.

SectionI.B equation(1.7), held299–306, is an ACTUAL operator generating functional `Tr[U1 rho0 U2dagger]` with external metric/current sources. SectionI.F equation(1.60), held818–837, takes `rho0=exp[-beta0(H-mu0 Q)]/Z0`, with Z0 the corresponding TRACE, then derives KMS(1.61)/quadratic FDT(1.62), with the stated neutral-operator and later PT assumptions.

Thus a physical thermal interpretation needs positive normalized state, actual evolution/adjoint and source operator products, not merely a finite integral with periodic time or formal KMS parameter. This is a real endpoint to match. CGL does not identify its H, density matrix, operator algebra or thermal contour with original N16 g1,g2/Grassmann theta through these equations. No missing physical map is supplied by invoking an effective RPA or beta>0 lemma.

## 6. Adopted premises versus original mandates: precise ledger of correspondence

| Premise | Positive support and present status | Bounded correspondence still required |
| --- | --- | --- |
| Composite fermionic coframe; actual S4/S2 and compact finite Euclidean measure | Direct DiakonovV23–28 plus accepted closed-source correspondence | Physical continuum/state/source interpretation; finite existence is not positivity/nonzeroZ |
| Symmetricalpha1/2 and sensible P/T behavior | Explicit DiakonovV.D motivation | Entire action/source/graded adjoint and physical reflection form, beyond one coframe's covariance |
| Finite periodic all-extended2^4 | Explicitly frozen in accepted N16 research contracts, with both interfaces and original signs | Its relationship to intended physical time/state/thermal trace and controlled regulator/limit |
| Full even gauge-invariant formal half algebra A_+ | Explicitly adopted in `B/N16_TEMPORAL_BOUNDARY_IDENTITY.md:6`; complete image retained in later contract | Actual physical operator/insertion/product/adjoint and constraint correspondence; primaries do not by themselves equate these full presentations |
| Geometric antilinear theta with R=gamma0, both interfaces | Explicit candidate in temporal identity: mathematically derived source-boundary correspondence | Identification with physical adjoint/state reconstruction; thetaS2 invariance is not assumed or substituted |
| Nonzero normalized positive physical functional/state | Mandatory for a positive W1 branch and CGL/metric expectation use | Actual fullZ/nonempty domain and state/reconstruction; neither can be stipulated by a definition |
| Full physical-image saturation incompatibility | Accepted current scoped result for its original-action/N16/full-A_+/theta premises | Scope propagation via demonstrated original-theory correspondence; it is not automatically a universal theory impossibility |

The formal Grassmann presentation makes its own products and nilpotence exact. A physical-operator claim additionally needs the correctly matched insertion/product/contact prescription. This is a missing DEMONSTRATED correspondence in the passages inspected, not a suggestion to change the algebra or remove the witness. It would be equally unjustified to assume every formal product is already the physical operator product, or to assert that high composites are nonphysical merely because they cause an obstruction.

## 7. Consequence for the current scientific route, without choosing a replacement

`B/N16_SATURATION_STATE_OBSTRUCTION.md` and its acceptance retain the full original action, adopted periodic interfaces/theta/algebra, and explicit actual-image witnesses. Their result is not just thetaS2 noninvariance or an ambient negative vector. It establishes incompatibility of nonzero normalization AND Hermitian PSD for that declared form at its stated finite real-coupling domain, without needing to compute fullZ. This report does not review or extend that proof, and does not cancel the separately open full normalization/N4 tensor assignments.

The next correspondence work should state exactly which original physical identification would REQUIRE that declared form on those witnesses, or which premise is merely a candidate construction whose physical matching remains to be demonstrated. Evidence, not naming, must carry that implication. If a required physical image does include the witnesses with the stated products/adjoint, the scoped failure becomes directly load-bearing for that intended branch. If that implication has not been established, the honest outcome is the present scoped construction breakdown plus a still-open physical map, not an automatic successful alternative or a universal no-go.

A genuine future fork exists only when that mapping analysis exposes incompatible REQUIRED original premises or a scientifically necessary change to a previously adopted physical model. It must then go through Publication ROOT with the exact source/assumption/result and original full-strength obligations preserved. This intake proposes no particular change and asks no operator question. Static source/charter diligence and the lead's independent robustness derivation can proceed without a new evaluation, favorable restriction or model substitution.

No absence claim follows from a text search. The bounded conclusion rests on the actual equations/charter passages above and the explicit acceptance limits of the current N16 construction. Publication ROOT retains source/manuscript/Visser/claims/gates/integration, operator disposition and end-to-end L1 readiness.
