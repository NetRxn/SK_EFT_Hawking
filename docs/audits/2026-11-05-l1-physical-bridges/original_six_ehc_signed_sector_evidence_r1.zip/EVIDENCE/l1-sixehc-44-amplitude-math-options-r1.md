# Mathematical options for all44 signed amplitudes

Recommendation: formalize and independently review the analytic sector cancellations below BEFORE spending runtime on a single doubled-class witness. They give a plausible complete reduction of the44-term coefficient to TWO genuinely distinct all-linear amplitudes. The reusable four-edge M/C construction is rigorously small and useful as a fallback/control, but could evaluate a sector that cancels from the full answer. No amplitude, local table, mask inventory or new scientific program was evaluated here.

Task l1-sixehc-amplitude-plan-r1; source8efe7d579f993b18b807aea75cd600f494b67cc1; parent publicationROOT01a13f67/L1-physical-observable-boundary. Author/notebook writerExecutor01a1ac65; reviewer independent. FIRST tool action explicitly checked the primary SAME packet: fresh=true,changed=[]. Read the FULL original construction, especially equations12–21, accepted44-output source contract, latest primary notebook/authorities and literal44-row TSV. TSV7854bytes,SHA2564d7456c8f95ca49347c34c275aa8e08cc5ec689effed039534bd5b8f37e7a14b. No current peer plan report read. Own file only; no repo/notebook/other edits. Manual source reasoning and fixed artifact text/hash/continuity reads only; no science script/import/local-mask/moment/tensor/Haar/CAS generation or evaluation, no test/native/Lean/slot/controller action.

Status: this is a preparation/source-analysis report. The NEW analytic propositions below are derived manually for a separate frozen proof and independent actual review; they are not yet an adopted canonical coefficient theorem. In particular no full h12,6sign/value or future execution authority is claimed.

## 1. Exact44-term accounting

Let A_i denote the UNWEIGHTED original integral of the literal sourceQpair, D-occupation word and six FULL EHC polynomials in zero-based TSV rowi. It excludes the stored source weight/divisor but includes every coframe quarter, gamma phase, class epsilon, holonomy and field-top sign. Then h12,6=sum_i(w_i/d_i)A_i. Diagnostic epsilon is not multiplied again.

There are32 doubled-class rows with divisor512 and12 all-distinct rows with divisor1. The latter are rows2–9,14–15,38–39. Equal loads/source edges are not amplitude equalities: endpoint gamma placement, active anchor versus partner and daggers must be transported explicitly. All44 remain in the ledger until a proved exact equality or zero removes them. The accepted necessary inventory does not prove any local chiral/Haar amplitude nonzero.

For the32 doubled rows, positive-weight indices are10,11,12,13,20,21,24,25,28,29,32,33,34,35,40,41; negative indices are0,1,16,17,18,19,22,23,26,27,30,31,36,37,42,43. Their weights are respectively+8and-8, all divisors512. This is literal artifact accounting, not an amplitude computation.

## 2. Manual common-amplitude proof route for ALL32 doubled rows

This section supplies the missing source-dependent proof, rather than assuming equal amplitudes from similar diagrams.

### Loads force two holes and one bridge

Each row has three distinct EHC classes each squared. Their character iszero, so occupation parity is constant. At total12 it is even, giving six independent double centers. A mixed-parity independent set ofQ4 has size at most5 by the already proved neighbor-union argument, so these six lie in one checkerboardA. They leave two missing vertices x,z inA.

A spatial source edge has oneAendpoint. It cannot touch a selected double center, already saturated at8. Thus itsAendpoint is one of the holes. Distinct source times force one hole in each time slice, with one source incident to each. The two same-parity holes have Hamming distance2or4.

If they were antipodes(distance4), residual loads at all their neighbors would be2, so a squared EHC center(load4) could only be a hole. Each hole would need central residual6after its sourceQload2, but hole-centered squared classes supply central multiples4and no hole-neighbor contribution from anotherAcenter. This is impossible. Therefore x,z differ along two axesI,J, one of which is time0. Their common neighbors are b=x+I=z+J and b'=x+J=z+I, both of the other checkerboardB. Residual loads are8at each hole,4atb,b',2at four unique leaves,zero elsewhere.

A squared EHC can be centered only atx,z,b,b'. Atb or b' its two frame spokes must go to the two holes because every otherAvertex has residualzero. Let a_x,a_z be numbers of pair-classes centered at the holes, and b_count,c_count those at the common neighbors. Source load2at each hole gives2a_x+b_count+c_count=3 and the same equation fora_z. There are three pair-classes total, and b_count,c_count<=1. Thus necessarily a_x=a_z=1 and exactly one common neighbor carries the third pair-class. Call that bridgeb. Its frame directions areI,J; its curvature plane is the complementary{K,L}.

The bridge center uses its entire capacity4, so neither source nor hole frame can point to it. If Sx,Sz are the spatial source directions at the holes, Sx!=I andSz!=J. At each hole the two EHC frame directions are exactly the complement of its bridge direction and source direction. Consequently the hole curvature planes are(I,Sx),(J,Sz). This is determined by actual loads, not a chosen curvature sector.

### At least one full curvature norm can be formed first

The bridge face cannot contain either hole: its directionsK,L excludeI,J. A frame edge atx can lie on the other hole's curvature face only if Sz=I; analogously a frame atz can be blocked only if Sx=J. Both conditions would make the two sources meet at b', and would also require one source to use time0. Either contradicts the actual distinct-time spatial source geometry. Thus at least one squared hole class has both frame-edge pairs curvature-free and may be integrated FIRST to its COMPLETE R(H)=sumF_CD². If the other hole class was blocked, deleting the first curvature face frees its frame pairs. There is no cyclic elimination dependency.

Its own source edge appears only in that hole face. It cannot appear in the bridge face. To also appear in the other hole face would require BOTH Sz=I andSx=J, the forbidden case. Therefore its active anchor is unique to its ownR, and the independent partner occurs in no other curvature factor. These are exactly the hypotheses of the accepted entrywise FULL-Q Fourier annihilator; all other link/field indices remain external.

The source may be centered at the HOLE OR at its other endpoint. This does not permit silently settingQx=Qy. Apply the actual full-Q identity at the stated source center, using its original gamma placement. If the active anchor is the source's partner, change that group variable to its dagger and use the inverse/transposed adjoint identity. Both coframe minus signs cancel in the pair; no chirality or field label is discarded. The accepted unweighted same-endpoint tensor then givesQsource->Kedge/2for either endpoint. Thus the two hole norms can be eliminated successively asR->24andQ->K/2, with original partners retained. This is correlated integration, not independent averaging.

### Universal residual, factors and allowed relabeling

After the two hole faces are removed, only the bridge curvature square remains. Its two adjacentAvertices b+K,b+L are selected cosmological doubles; the opposite corner isB. Those twoD²centers give partial epsilon2times the literal Gram onK,L. The other four double centers are fully paired and give24^4. The bridge EHC frame pairs become free and leaveRbridge. Counting coframes gives26ordinary pair kernels8^-26, two sourceKhalves1/4, two partial epsilon factors4and two removed norms24². Hence EVERY unweighted doubled row reduces to

 U=8^-26*24^6 I Haar_C4[(prod_outside28 K_e)R(H_bridge)G_(b+K)G_(b+L)].

All moved factors areeven. Pair kernels already contain both quarters/anchors. The residualGrams retain their quarters and subtraction; everyKedge occurs once. Class world epsilons are squared, as are originalDworld-orientation signs.

The bridge planeK,L is PURELY SPATIAL because the hole separation contains time0. A spatial-axis permutation FIXINGtime0 maps its complementary spatial direction to1and its plane to2,3. Translation mapsbto canonical vertex1; it may exchange the two time slices, but no source is being relabeled before integration. ALL sourceQfactors have already been removed by their actual endpoint identities. This is a change of variables of the residual bare coefficient integral, not invariance of the original Fourier profile under arbitrary time/spatial permutations.

The relabeling bijects all64anchors and field sites. Eight-variable site blocks commute, so top sign ispositive. If plane ordering reverses, HbecomesHdag at the same base, butR(Hdag)=R(H). Exchanging the residual Gram axes leavesGunchanged. K is the same symmetric original scalar on all edges. Thus the residualUis indeed one common unweighted amplitude, without evaluating it or treating a full physical source as time/spatial-rotation invariant.

The32-sector coefficient is therefore U*(16*8-16*8)/512=0, IF this complete source-bound proof is adopted after its independent formal review. No Cchi or W numerical computation is needed for that cancellation. The raw case2formula had coefficient-1/2/512=-2^-10; replacing its scalar by reduced-8/512=-2^-6 is the correct convention change, not another factor applied toU.

## 3. Additional exact row maps within the12 all-distinct terms

Here are concrete maps, not endpoint-equality assumptions. Let pi exchange SPATIAL axes1and3, fixingtime0andaxis2. It transforms a fullDby det(pi)=-1 and a complete canonical EHC class by the SAME determinant sign after curvature/frame ordering is restored. There are12Dand6EHCfactors, so total sign(-1)^18=+. Site-top and Haar signs arepositive. SourceQaxes2remain2; their actual vertices transform. The original eta profile is NOT asserted invariant; its already expanded numeric row weights are retained.

Direct label/vertex maps are:

- row2 -> row14 and row3 -> row15;
- row6 -> row38 and row7 -> row39.

For example (1,11,21,25,35,45) maps to(1,9,25,33,59,83), while source vertices0,3/7 map to0,9/13. The other pair maps(3,17,19,27,41,43)to(5,29,51,55,75,79). Occupation holes transform consistently. Divisors are1and native weights are opposite(-8,+8), so these eight rows cancel pairwise under the exact unweighted equalities.

The remaining rows are4,5,8,9, all weight+8anddivisor1. Literal time translatione0maps row4torow8: it maps class multiset(1,9,11,25,33,35)to(3,5,7,27,29,31)and swaps the two evenQsource factors at vertices0,1. Translatione0+e2maps row5torow9, swapping source vertices0,5. The same four empty sites{0,1,4,5} are permuted and all twelve single occupations preserved. These are genuine periodic translations of fields AND anchored links, not geometricEHCreflection; no dagger is silently substituted. Therefore A8=A4,A9=A5.

Combining this with the32proof gives the exact candidate reduced target

 h12,6=16(A4+A5).

A4andA5 MUST REMAIN DISTINCT. They differ by which endpoint of the same second source edge carriesQ:Q1,22versusQ5,22. They are not related by the above translation while keeping the first source fixed. Different gamma/active-anchor placement is exactly the issue seen in acceptednu!=mu. No claim that either amplitude or their sum is nonzero,positive orzero is made. This reduction accounts for EVERY one of44rows and is the most useful formal manual checkpoint to pursue first.

## 4. Rigorous small M primitive and four-edge C fallback

Independently of the sector proof, a strong local reduction for original equation20is valid. Weight one active chiral group byD1. Cross-anchor terms have zero independent-partner mean; the both-partner term multiplies meanD1=0. Mixed activeL/Rterms vanish after integrating the other group. Only TWOcoframes from the chosen active chirality remain:

 M_AB;rs=(1/16)int_SU2 F_chi,A(U)F_chi,B(U)D1_rs(U^epsilon).

For active partnerVuseW=Vdag: the two coframe minus signs cancel andepsilon flips. Equivalently transpose the adjoint indices. Endpoint reversal changes actual center/neighbor field and gamma labels; it is an explicit polynomial transport, not equality of global row amplitudes.

WriteF_chi,A(U)=sum_i f_Ai u_i for real quaternion coordinatesi0..3. For the held monomial Pauli blocks, each f_Ai is a sum of at mostFOURbilinear field monomials with Gaussian-unit coefficients. WriteD1_rs=sum_ij d_rs,ij u_i u_j with a symmetric traceless integer4x4matrixd. Eachdhas four nonzero entries: for diagonalrs the four diagonal signs, for offdiagonalrs the spatial crosspair and time/spatial crosspair. The S3fourth-moment formula gives, without generating a table,

 M_AB;rs=(1/192)sum_ij d_rs,ij f_Ai f_Bj.

The trace(d)term vanishes, and symmetry supplies the factor2from the other pairings. This fixes the exact common Gaussian-rational denominator192. M is symmetricABand fullmetrictrace sum_A M_AA=0. The existing actual coframe-component control has(-1,-1,+1,+1)/48 in its stated word order, so the corresponding192-cleared entries must be(-4,-4,+4,+4). These are valuable independent normalization/sign controls.

A selected active chirality uses four odd coordinates at EACH relevant endpoint and has degree2at each. Its field basis therefore has only binomial(4,2)^2=36monomials, not a general128-generator polynomial. Storing10symmetricABcomponents,9adjoint entries,36field coefficients and2chiralities gives6480Gaussian-integer numerators. Each coefficient's absolute bound is64before division192 (four dterms times at most4*4bilinear products). Signed16real/imag storage is safe:25920numeric bytes. A direct table construction has at most10*9*2*64=11520monomial coefficient products. These are static algebraic bounds, not an evaluated table or timing/RSS.

In the existing four-edge Jchi, both edges incident to5or9have coframes centered there. The selected field chirality at5,9is oppositechi; at neighbors1,13it ischi, regardless of active/partner inversion. Thus the four-M/Gamma contraction is EXACTLY one scalar Cchi times tau_(1,chi)tau_(13,chi)tau_(5,oppchi)tau_(9,oppchi). The full degree4space at each chosen four-variable corner is one-dimensional. A six-dimensional degree2form basis and its signed complement pairing suffice; no physical singlet projection or extra norm is imposed.

The proposed324-entry vertex construction is valid: external form6at1and13and two adjoint indices3give324entries. Gamma has36nonzero components; summing an internal adjoint3and a complementary local form6uses at most324*36*3*6=209952coefficient products per vertex. Two vertices, two chiralities and final324products per chirality give840456products; with the primitive table, total<=851976. After clearing2Gammaand192Mdenominators, vertex integer magnitude<648*2*64²<2^23and final scalar magnitude<324*2^46<2^55. Gaussian pairs fit signed32atvertices andsigned64atfinalC; denominator4*192^4is exact. Vertex numeric payload for four324-entry Gaussian-int32arrays is10368bytes; combined primitive/vertex payload36288bytes,excluding metadata/temporaryobjects. No actual value/sign or measuredmemory follows.

There is also an exact positive constrained-loop interpretation, after orientation is proved as just above. LetW_C,chi sum the accepted two-factor weights over configurations whose entire residual square has that selected fixed chiral color. Its fixed-color square coefficient is3(-2)^4=48,not96; summing the two colors would double-count aJchi. Therefore

 Jchi=(Cchi/48)*2^32 W_C,chi.

Each constrained term has the original positive even-loop sign. Complementing the two-factor exchanges the colors,soW_C,L=W_C,R=:W_C>0and2W_C<=W. A coordinate-plane two-factor supplies a compatible configuration. Thus the raw witness is a combination ofWandW_Cwith the actualCchi,not a generic positive Gram. This lemma makes Cchi a genuinely decisive scalar for that raw control, but it need not be computed for a32sector that cancels exactly. Do not spend admission on it solely to obtain an isolated negative component.

## 5. What changes for the all-distinct rows

The12all-distinct rows have twelve SINGLE Dcenters,unit divisor and nonzero anchored curvature parity. Their free edges generally have one coframe from each endpoint. The correct unweighted kernel is the ORIGINAL mixed H_xy^(AB)/8, not delta_AB K/8. The positive all-Ktwo-factor proof cannot simply be reused. This is the main blind alley in treating all44as repeated copies of the doubled witness.

After the exact row maps above, both remaining amplitudes A4,A5 have the same ten-edge/three-square geometry on{0,1,3,4,5,7,9,13}. Their six classes are(1,9,11,25,33,35),each once. The common edge1-5has three curvature occurrences on EACH anchor; sourceedge0-4and far edges3-7,9-13have one on EACH anchor. On those odd/odd edges,center parity forces one coframe onto each anchor; the two-anchor cross term has its original minus and CANNOT be discarded as two independent means. On the six other core edges the active curvature count is2and its partner0,so the coframes are both on one anchor. These selected moments need degrees at most4per active chiral group after the actual center allocations, but chirality assignments of six EHCtraces can mix; the one-chirality Mtable alone is not a complete representation.

There are22curvature-free edges. For these all-linear words their coframes are mixed-endpoint; retain fullH_xyand every source/gamma index. Eight exterior vertices lie outside the curved book and carry intactD. The accepted four-vector-copy decomposition ofH_xyand local alternating epsilon identity can reduce that outer region, but its actual Cmatrix/tvalue or direct signed polynomial coefficients must come from the original moment,not chosen parameters. A blind dense tensor on its12boundary edges has4^12=16777216multiplicity-color entries before other labels,already exceeding the old120000row guard. This is a concrete width warning,not a runtime forecast. Keep the region factorized or derive a further analytic contraction.

A useful bounded first ORIGINAL primitive for these remaining rows is the unweighted mixed-endpoint H_xy table itself. Each fixedF_x^AorF_y^Bhas at most32coordinate-bilinear terms across both chiralities. The second moment isdelta/4and the pair kernel adds1/8,so a denominator32Gaussian-integer table is sufficient. A direct AB16construction has<=16*32²=16384term products. Field degree2at each full eight-variable endpoint gives28²monomials,or12544ordered-ABcoefficients. A conservative numerator bound1024allows signed16Gaussian pairs,50176numeric bytes. This is a source-specific primitive with known same-endpointdeltaKand mixedendpointtranspose/field-relabel controls,not a new generic engine. No table was generated here.

For complete A4+A5, additionally freeze the actual core edge tensors with1or3fundamental curvature factors on each anchor,retaining ordered matrix indices,chiral assignments,source endpointand exterior masks. With six EHCtraces there are at most2^6explicit chiral choices before exact zeros,not permission to choose a favorable one. Apply original S3second/fourth moments with exact gamma phases; combine local exterior signs before any coefficient sum. A full two-amplitude contraction still lacks measured/qualified factor and join bounds. No claim that small local moments imply a small globaljoin is made.

## 6. Alternatives and recommended sequence

1. FIRST freeze a manual proof package for the32common-amplitude cancellation and the explicit12-row maps, with separate independent actual checks. It is potentially more decisive than a new scalar/table job and requires no execution. Preserve the full44ledger and all source/weight/top maps as above. If any dependency/orbit proof fails,leave those rows distinct and retain the original44-term expression.

2. If accepted,the full next exact target is the COMBINED16(A4+A5),not a signed sample. Prepare its original mixedH_xyand core fundamental-moment factors,complete field/chiral basis and guarded contraction tree. The bounded mixedH_xyprimitive (<=16384products,50176numeric bytes) is the most relevant first exact computation for that route. It resolves an actual original bulk tensor needed by both amplitudes. It is not itself a full sign certificate; the full combinedtarget must be completed or explicitly refused.

3. If a bounded contrast/control is desired before the harder all-distinct network,the twoCchi scalars are an explicit <=851976product fallback with small numeric payload. Freeze all basis/dagger/gamma/top conventions and controls first. They evaluate the known raw four-edge remainder only; do not misreport them as fullh12,6. Avoid spending runtime here if the doubledsector cancellation is already adopted and the scalar has no further diagnostic purpose.

4. A direct generic44-row exterior expansion remains a correctness fallback,not a defensible first execution. Even a crude term bound16*24^12*12^6*512^6*256^64perrow is finite but hopeless as a preparation budget; polynomial cancellation/independent Haar means cannot be used to invent a smaller join count. Modular arithmetic reduces integer growth,not combinatorial width,and zero residues alone do not prove zero. Full signed weights and denominators must reconcile across every row or proved symmetry orbit.

No scientific code/spec or invocation is prepared by this report. Numeric payload/operation counts are conservative algebraic bounds,NOT measured walltime/RSS,full artifact size or approved guards. A decisive full computation requires exact frozen factor/code bytes,source and mathematical/static review,completion/refusal criteria and NEWROOTadmission. Previous admissions are spent.

All uncapped h=1both-kernel/reflectionDelta0/source/normalization/Bopp/log contacts and conditional physical positivity premises remain. A coefficient sign at this finite graph does not supply physicalTT/Wardprojection,pole/residue,positive boundary/product/adjoint/seam/causalV,calibration,matter/EM/light/transport,time/scales,B3/N4orcontrolledlimits. Prior witnesses,c0frontier anddistinct targets persist. ROOTretains canonical intake/integration/closure/runtime authority. Final SAME freshness and report hash/bytes returned separately.

## Final aggregate refinement: one word, with both source times preserved

The lead's final endpoint-average refinement is valid by an explicit ordinary translation, without equating endpoint metric polynomials pointwise. Define

Pi*= [product_(z notin{0,1,4,5}) D_z]
 E_(0,02) E_(4,02) E_(1,12) E_(5,12) E_(1,23) E_(5,23),
L(X)=I_all Haar_all[X Pi*].

Then A4=L(Q0,22 Q1,22), A5=L(Q0,22 Q5,22). Translation xor4 (spatial direction2) preserves Pi*: it swaps0/4and1/5in its three EHC pairs, permutes the twelve single Dcenters within their complement and relabels all original anchors bijectively. World directions and internal gammas are not rotated, no holonomy is independently inverted and no source endpoint formula is changed without the actual translation. Eight-generator site blocks give a positive top sign, and all action/source polynomials areeven. It mapsQ0<->Q4andQ1<->Q5.

Therefore
A4+A5=L[Q0(Q1+Q5)]=L[Q4(Q1+Q5)]
 = (1/2)L[(Q0+Q4)(Q1+Q5)],
where allQare the original diagonal22metrics. Combined with the complete row cancellations and maps derived above, the exact prospective aggregate target is

h12,6=8 I_all Haar_all[(Q0,22+Q4,22)(Q1,22+Q5,22) Pi*].

The factor8is16from the four remaining weighted rows times the exact averaging1/2. It is NOT an additional use of the original Fourier/polarization raw1/2, already incorporated in the native reduced weights. The first source edge remains on originaltime0(0–4), the second on originaltime1(1–5). IndividualA4andA5stay distinct until this proven integral average.

This is now the recommended single combined amplitude frontier if the preceding40-row cancellation proof is formally frozen and independently accepted. It is an equality of expanded coefficient integrals with original fields,links,gamma orders and weights. It does not change the originalq_tsource, introduce a favorable physical endpoint average, justify positivity or evaluate the aggregate. The local mixed-endpoint/curvature partner warnings and full contraction-cost unknowns in section5still apply. The boundedM/Cfallback remains useful as a control only; no runtime should be spent on a canceled sector solely to manufacture a sign. Final SAME check is performed after this addendum.
