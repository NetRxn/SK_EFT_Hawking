# Next L1 construction: same-action sixteen-site source/state feasibility

Assessment only, following publication request at checkpoint a5d536600 and
Executor source bd5b4d471. No new run, slot, cap, action, scope or deferral is
authorized. Use existing PR115 W1/W2 sequencing and the current remediation
planner. Publication owns all L1 readiness; Executor supports bounded science.

## Recommendation

Prioritize a **complete-action, source-correct time-cut representation and
normalization/state feasibility certificate on the all-extended 2^4 regulator**.
The deliverable is a derived correspondence for the original closed action,
not a new generic contraction engine or another selected-word campaign. Start
from the existing full-action determinant/Wick identity, retain the S4 coupling
and actual metric/action source insertions, and identify whether the resulting
physical observable functional admits the required positive state. A scoped
counterexample on a required observable span is an equally valid research
outcome; it is not original publication acceptance or operator deferral.

The first milestone is the exact representation/source/reflection contract,
reviewed before any evaluation. The decisive second milestone is a proof of
nonzero FULL normalization and positivity/reconstruction on that contract,
or a source-matched negative witness. These belong to existing W1, not a
parallel routing ledger. Bounded here means one specified finite regulator,
action/source and scientific acceptance question; feasibility is not promised.

## Reusable source and its limits

- `L1_RETARDED_SPECTRAL_INTERFACE.md`, “Full action-word support and aggregation”:
  accepted formal Wick/determinant identity, review b92bfa301; actual coframe
  matrices, full 64x64 checkerboard determinant control and joint local Taylor/
  Haar controls. The full fixed-real-auxiliary determinant factors into chiral
  squared norms. This does NOT make its indefinite-covariance Wick expectation
  positive. The local interleaved cuts are controls, not a full sixteen-site sum.
- `l1_extended_wick_det_control.py`, `l1_extended_wick_checkerboard_control.py`,
  `l1_wick_haar_paired.cpp`, `l1_wick_haar_cut_crt.py`: source correspondence,
  exact local pairing/Haar and rational reconstruction substrate. Reuse their
  actual identities and negative lessons; do not rerun local examples as a
  substitute for the missing full functional.
- `COMMON_SOURCE_MATTER_INTERFACE.md` and `PHYSICAL_MATCHING_DECOMPOSITION.md`:
  same-functional metric/action derivatives, all contacts, G/A/B/D blocks,
  conditional Legendre map, matter reweighting and units. These are accepted
  interfaces, not a constructed positive body, state or microscopic matter map.
- Existing N4 closed dressed pair and literal negative Gram controls test
  source/state correspondence. Neither transfers numerically to N16. Existing
  scalar 2^4 temporal Green function is a free-scalar comparison, not the gravity
  transfer kernel. Haar moment PSD/rank35 is not physical reflection positivity.
- `QuantumNetwork/MixedState.lean` supplies IsDensityOperator and psdSqrt;
  the prepared PR115 thermal Gram package is supporting algebra. It cannot
  construct the actual density operator or source identification by assuming
  positivity. This assessment inspected source declarations, not LSP/Lean
  elaboration, admission or absence of other substrate.

## Exact missing step

Write the original tetrads as bilinears in the 128 generators, with a formal
auxiliary variable per actual bilinear. The determinant of their 64x64 fermion
matrix generates the complete Berezin integral. Apply the finite differential
operators representing the actual closed S2, S4 and Q/action sources, then the
joint Haar integral over ALL physical links, with original factorials and
orientation. The quadratic S2/source part recovers the existing Wick identity;
S4 is quartic in tetrads and requires its explicit higher differential
insertions. An indefinite Gaussian covariance alone is not the full nonzero-g1
action. This extension is a proposed exact algebraic representation, not a
performed calculation or claimed newly absent theorem.

Derive the time-cut boundary kernel from that SAME expression: full chiral
indices, independent directed links, reflection/order/conjugation rules,
fermionic orientation and gauge/constraint treatment. Retain the observable
algebra required by the metric and intended matter coupling; selecting only
positive directions after inspecting a Gram matrix is not a physical quotient.
The time-local source insertions and coincident contacts must reproduce the
derivatives of this common partition functional, rather than be fitted to a
positive two-time scalar pair. Specify boundary conditions explicitly, keeping
the current periodic regulator unless a physical change is authorized.

The scientific certificate must address two distinct questions:

1. Is full Z nonzero on a prospectively specified domain? A complete exact sum
   or rigorous signed remainder bound can certify this. A positive selected
   word, finite k4 coverage, fixed-auxiliary determinant norm or gauge average
   cannot. At g1=0 this requires the actual full Z32 coefficient; near that slice
   it also requires control of the remaining finite polynomial.
2. Does the original functional on the required algebra admit the claimed
   positive thermal/reflection/transfer representation? Derive its matrix or
   reflection-cone factorization and nontrivial normalization; test the full
   retained mixed span. Nonzero Z alone is insufficient. Simply setting rho to
   T^2/Tr(T^2) does not identify the actual two-time correlations if T is signed.
   A finite negative Gram minor defeats the stated representation/domain, but
   finitely many positive minors do not prove positivity on the whole algebra.

No positivity promise follows from the source. Keep couplings symbolic or fix
a domain prospectively from physical input; do not choose a favorable coupling.
At pure g2 the accepted all-volume parity already gives literal G=0, including
N16 wherever normalized. Thus proving Z32 alone cannot supply a nonzero metric
body. Nonzero-g1/source-selected/matter constructions need their own retained
terms and limits; the N4 cubic/quartic truncation does not extend to N16.

## Acceptance and downstream purpose

Independent math review should check the complete-action determinant identity,
orientation, full source derivatives/contacts, time-cut correspondence and
nonzero-domain/positivity certificate. Independent physics review must check
that the retained source, state, observable algebra, matter interpretation and
regulator actually realize the intended L1 theory. Exact known local/N4
controls are correspondence checks only; prospective resource bounds and source
review precede any admitted evaluation. No infrastructure work is proposed.

This is the earliest candidate that could genuinely supply W1 inputs to W2.
Once established, derive the normalized momentum-dependent G/A/B/D response,
not just the static dressed Hessian. Identify the tensor/field projection,
spacing/cutoff, source normalization and contacts before extracting the
dimension-two gradient coefficient and dimensionless chi. A dimensionless strain
static Hessian per four-volume is dimension four, not automatically the original
Lambda-squared B3. The [0.1,10] interval must be a result on an independently
stable domain; source/unit rescaling cannot enforce it.

Matter remains a genuine bridge: M=B0+lambda Q has an assumed positive body
and is not the literal collective G. At lambda=1 its body vanishes; adding B0
or combining N4 gravity with an N16 scalar kernel cannot certify the intended
microscopic coupling. Any alternative collective effective matter approximation
must derive its matching/error, scale calibration and feedback, or obtain an
explicit physical decision before changing the model. W3 then still owes a
constrained propagating spin-2 pole and same-background matter/light cone;
W4 still owes causal spectrum, physical-band transport and controlled errors.
Neither a positive state nor a static susceptibility determines those by itself.

## Full tensor obligation remains distinct

Executor still owns the open full N4 c tensor construction. Its two attempts
failed the original row cap; no nonempty coefficient was completed in attempt2.
The reviewed Dirac-loop design remains unimplemented. The exact all-coupling
N00/N11 zero settles this regulator's strict Euclidean SPD route without those
remaining contractions, but does not complete or cancel them. They could still
characterize an indefinite finite response or verify a future factorization.
Their marginal direct value for the original physical bridge is lower than the
N16 common-functional state/normalization question. Any scheduling disposition
belongs in the existing planner; any actual deferral/reduction goes to the
operator. No original B3/state/tensor/matter/transport requirement is reduced.
