# Lead primary-source recheck — research only

20 November2026. Supporting L1-PHYS-INSERTION-05 actual manual construction; not a new construction or applicability verdict. No evaluator, computation, source model or dictionary change.

Vergeles2506.00036v2, https://arxiv.org/html/2506.00036v2 : inspected II.1(1)-(9), II.2(16)-(21), IV.1(42)-(49), V(58)-(59), VI(60) and references. The proof assumes an orthonormal wavefunction basis, finite action matrix elements and a complete action eigenbasis. Its initial tetrads are independent bosonic variables; the conclusion claims a composite replacement but retains gauge/volume issues. These inspected passages do not discharge the original benchmark's positive cut/domain or integration hypotheses. This rechecks the existing qualification, not a full new audit or a no-go theorem.

Diakonov1109.0091v1, https://arxiv.org/html/1109.0091v1 : inspected V.3(29)-(31), V.4(32), V.5(33)-(34) and nearby action/measure text. The symmetric composite tetrad, independent anchored gauge transformation and original action remain the relevant source inputs. No new physical ordering or adjoint prescription is inferred here. This is selected-passage verification, not a fresh full-paper read.

The archival explorer independently found the accepted ORIGINAL_LORENTZ_COMPOSITE_CYCLE body/acceptance, with a genuine composite Wick/source transport and scoped bare-Haar convergence obstruction. That accepted body, rather than an early broad literature summary, is the source to read for a continuation. The constructor was sent the direct primary URLs and these limits. Any hypothesis used in the actual result must be independently read/rebound to the pinned source, with no promotion from snippets, abstract or a sympathetic citation.
