# Original Nt=2 coframe, temporal matrix blocks and source support

Read-only leaf intake for `L1-N16-temporal-source-intake`, parent publication-L1-adopted-N16-boundary-construction. Packet `l1-n16-temporal-source-intake-r1.json` fresh at entry; candidate `942c50adb2fef3633e28fff34e54c0d793854d80`. Read the newest primary L1FixedControls notebook: ROOT adopted SOURCE-ONLY first milestone; Executor derives, then independent math/physics review before any evaluation proposal. This scratch report is the only written file. No scientific/project imports, matrix evaluation, computation/test/build/contraction jobs, source/Git/notebook/slot edits or process operations.

D = `docs/audits/2026-10-17-publication-substance-construction/`; B = `docs/audits/2026-11-05-l1-physical-bridges/`.

## 1. Both temporal interfaces are required; expected blocks are correct

Use sites x=(t,r), t=0,1, r in the eight-point spatial2^3 lattice, original PERIODIC fermion hopping signs, time axis0, and independent physical links

`V0(r)=U_((0,r),0)`, `V1(r)=U_((1,r),0)`.

Although forward and backward temporal endpoints coincide as vertices at Nt=2, the two geometric directed positive links are independent integration variables. They must not be identified as V1=V0dagger, V1=V0, or treated as a single doubled edge. There are eight V0 and eight V1, in addition to48 spatial Spin(4) links.

The original four-block coframe is `D/ADW_EXACT_AUXILIARY_IDENTITY.md:17–25`, equation(1); the explicit matrix assembly is equation(9), lines71–77. `D/l1_full_action_reference.py:77–100` records the same forward/backward blocks BEFORE its quotient extraction, with signs +,-,-,+ and quarter. `D/l1_extended_opposed_source.py:frame,action_frame` (14–31) distinguishes the two anchors on an extended axis. These are source facts, not matrix controls executed here.

For each internal A, direct substitution into equation(1) gives

`T_(0,r;0,A) = (1/4)[barpsi_0 gamma_A (V0dagger-V1) psi_1 + barpsi_1 (V1dagger-V0) gamma_A psi_0]`,

`T_(1,r;0,A) = (1/4)[barpsi_1 gamma_A (V1dagger-V0) psi_0 + barpsi_0 (V0dagger-V1) gamma_A psi_1]`.

All fields in these formulas have the same spatial r. In the second formula the first gamma placement differs from the first formula's barpsi_1 term, and similarly on the barpsi_0 term. One cannot replace the two temporal coframes by one object unless an additional identity for their ACTUAL weights is established.

Let h_(t,r;mu,A) be the real auxiliary coframe variables in the accepted Hermite representation, and abbreviate h_tA=h_(t,r;0,A). With

`D(r)=V0(r)dagger-V1(r)`, `E(r)=V1(r)dagger-V0(r)=-D(r)dagger`,

the temporal off-diagonal spinor blocks are exactly

`M01(r,r')=delta_(r,r') (1/4) sum_A [h_0A gamma_A D(r) + h_1A D(r) gamma_A]`,

`M10(r,r')=delta_(r,r') (1/4) sum_A [h_0A E(r) gamma_A + h_1A gamma_A E(r)]`.

These agree with the proposed formulas. No spatial hopping contributes to M01/M10. For real h and the actual Hermitian Euclidean gammas, M10=-M01dagger by E=-Ddagger, preserving the order of factors under dagger. This is a manual algebraic identity, not an assertion that the signed full auxiliary functional is positive.

## 2. Canonical64x64 matrix and orientation

Each time slice contains eight sites and32 Dirac components. After one explicit simultaneous row/column permutation that groups sites by time, the matrix is

`M_time = [[K0, B], [C, K1]]`, with `B=M01`, `C=M10`.

The32x32 Kt are the ORIGINAL spatial hopping matrices. They are generally NONZERO. Each is assembled from mu=1,2,3 in the same equation(9), using h_(t,r;mu,A), spatial forward/backward anchors and spatial links at time t. For real h and unitary links Kt is anti-Hermitian, and C=-Bdagger, but no invertibility of Kt is assumed. A Schur-complement formula involving Kt^-1 is therefore not a universally valid cut identity.

The common64x64 checkerboard identity in `D/l1_extended_wick_checkerboard_control.py:matrix,indices` uses TOTAL site parity `(t+r1+r2+r3) mod2`, then internal chirality. Spatial hoppings also flip that parity. It does not split the matrix into time0 versus time1 and does not justify setting K0=K1=0. Its chosen axis-specific h weights and fixed unit links are an exact control for its stated block structure, not the general source-dependent matrix itself.

Each half has64 Grassmann generators:32 barred plus32 unbarred. Preserve the source's eight-generator-per-site orientation. A simultaneous row/column site permutation preserves det M; its two permutation determinants multiply to1. Moving entire eight-generator site blocks also has even sign. A temporal boundary expansion into individual fermionic monomials still requires its actual graded reordering signs; the absence of a global site-block sign does not erase local exterior signs or define an antilinear reflection.

## 3. Actual source support relative to the cut

At an undeformed site x=(t,r), a spatial Ti (i=1,2,3) uses fermions and spatial links ONLY at time t. It still involves two independent spatial anchors because every spatial length is2. T0 uses one fermion at each time and both independent temporal link families as above.

For local literal Q at base x:

| Component | Grassmann support across(time t,other time) | Cut classification |
| --- | --- | --- |
| Qij, i,j spatial | degree(4,0) | Half-local |
| Q0i | degree(3,1) | Boundary-supported/crossing |
| Q00 | degree(2,2) | Boundary-supported/crossing |

The contracted internal sum does not alter these support statements, which hold termwise and for all source anchors. Off-diagonal components count ONCE in the independent symmetric source basis from `B/PHYSICAL_MATCHING_DECOMPOSITION.md:2`. A factor2 belongs only to an explicitly defined double-index contraction convention, not to this basis.

Half-local Qij may still have correlations mediated by the entire other slice. More generally the deformed Qij(j) is half-local only if the prescribed coframe/source map preserves the spatial subspace; a world deformation mixing spatial and temporal coframes changes that support. The actual source path and its first/second jets must be stated.

The physical action derivative j is generally crossing even for the existing traceless spatial coframe shear. Curvature planes involving time carry plaquette links from both slices; complementary coframes can include T0; S4 itself contains one T0 before any special source derivative cancellation. The existing determinant-one traceless shear makes S4 invariant, but this special cancellation does not remove crossing S2 curvature/coframe terms. `D/L1_RETARDED_SPECTRAL_INTERFACE.md`, “Candidate curvature-dressed operator from coframe shear” (376–409), and `B/COMMON_SOURCE_MATTER_INTERFACE.md:4–5` distinguish action variation from a half-local literal Q source.

For physical composite J and dressed j, keep the complete same-functional jets and contacts in `B/PHYSICAL_MATCHING_DECOMPOSITION.md:2`, namely `G=<Q>`, `A=Cov(Q,Q)`, `B=<Q_j>+Cov(Q,X)`, `D=<S_jj>+Cov(X,X)`. An arbitrary boundary cut does not permit dropping Q_j or S_jj. If changing variables between a deformed-coframe hopping representation and a deformed action-coefficient representation, apply the source dependence consistently; do not insert the same coframe deformation in both places and double-count it. Auxiliary h, physical J, and a measure-Jacobian J are distinct.

## 4. Full Hermite weights are not independent half amplitudes

The accepted full-S4 identity is `D/ADW_EXACT_AUXILIARY_IDENTITY.md:36–82`, especially equations(4)–(7),(9)–(10). W_x(h_x,U) is built from ALL original local action coefficients p_(x,alpha)(U), including original S4 and S2. Real Gaussian h_x measures factor by site, but the signed W_x coefficients depend on plaquettes. Site indexing of W_x does not imply support only on that time slice's spatial links.

For a temporal-spatial plane(0,i), write L_t,i(r)=U_((t,r),i). In the accepted rightmost-first CLOSED order the plaquette based at(t,r) is

`P_(t,r;0i)=L_t,i(r)dagger V_t(r+i)dagger L_(1-t),i(r) V_t(r)`.

This follows from reversing the four ordered factors `(U_x0,U_(x+0),i,U_(x+i),0dagger,U_xidagger)` in `D/l1_full_action_reference.py:coefficient`; it retains the basepoint convention of the accepted closed source. Both time slices' spatial links appear in one coefficient. The t=0 and t=1 temporal faces involve their respective independent V0/V1 families. The reversed plane/inverse order must follow its own recorded orientation rather than treating these matrices as commuting scalars.

Consequently defining W_t=product_(r) W_(t,r) gives an exact algebraic product W0W1, but W0 and W1 are generally BOTH functions of spatial links on BOTH times and crossing temporal variables. It is invalid to integrate them as independent functions of disjoint half variables or call them conjugate half amplitudes merely because h0 and h1 Gaussian measures factor. W_x's S4 part is quartic in the formal local X variables; the S2 plaquette coefficients in the SAME full W_x create the displayed cross-slice dependence. Removing those coefficients or replacing signed W with absolute values changes the theory.

A valid conditional half-kernel can retain every shared variable/exterior boundary index until the proved last-incidence closure. Its remaining integrations, source insertions and signed weight must then be included before claiming equality with the fullZ or physical pairing. There are128 auxiliary h coordinates per half,256 total; half-local auxiliary labels do not imply half-local physical coframes or interactions.

## 5. Reflection conventions: actual substrate and a necessary Nt=2 distinction

`B/N16_SOURCE_STATE_CONSTRUCTION_CONTRACT.md`, especially “Exact missing step” and “Proposed owner, next action and reviewed acceptance contract”, explicitly requires that the antilinear/graded reflection and both periodic interfaces be DERIVED. Its acceptance is assessment/design only, not an existing proved temporal reflection kernel. The newest notebook adopts precisely this missing source-level step. In the bounded paths/history inspected, there is no accepted complete two-interface reflection map to import unchanged. That is an inventory observation, not a proof of repository-wide, literature or Lean nonexistence.

The accepted R=gamma3 internal Pin transformation in `B/COLLECTIVE_BODY_PARITY.md` exchanges chiral factors at each site and proves degree/coupling selection. It does not exchange time slices and is NOT the required temporal Osterwalder–Schrader involution. The scalar temporal thermal control `D/l1_scalar_temporal_spectral_control.py` and spectral-interface “Exact temporal transfer control for the scalar probe” supply a free-scalar comparison, not a fermionic reflection map for the original action. Gauge projection/closed-word tree fixing likewise grants no reflection positivity.

A special Nt=2 ambiguity must be resolved explicitly. The vertex permutation t->1-t is also the one-step translation on this two-point set, but their lifted actions on directed physical edges differ:

- Orientation-preserving one-step translation swaps V0 and V1 (and swaps spatial-link slices).
- A geometrically ORIENTATION-REVERSING temporal reflection lifted from `theta(t)=1-t` sends a positive time link at x to the dagger of the positive link anchored at `theta(x)-e0`. At Nt=2 that anchor is again t, so the geometric link rule is `V_t(r) -> V_t(r)dagger` within the SAME interface family; spatial links map from slice t to slice1-t without a temporal orientation reversal.

These are statements of two possible geometric lifts, not a completed antilinear fermion/source reflection or proof that either preserves the full original action. The full reflection must additionally specify barred/unbarred interchange, complex conjugation, spinor matrix, graded product order, source pullback and all plaquette/basepoint/gamma5 signs. A vertex swap alone does not fix them, and a translation cannot silently stand in for time reflection. No choice of reflection matrix or action-invariance sign is asserted here without the remaining derivation.

Finally, periodic fermion boundary conditions are the adopted source contract. An ordinary positive thermal trace usually uses a different coherent-state temporal boundary convention; translating between the actual periodic Grassmann functional and a trace or graded trace requires an explicit derivation. Introducing an antiperiodic seam or a selected boundary-state insertion is a physical change unless its equivalence is proved and authorized. This intake does not claim the periodic functional is impossible to realize positively; it identifies the matching requirement.

## Review targets retained

The expected M01/M10 formulas need no correction under the original periodic contract. Necessary safeguards are the nonzero spatial diagonal blocks in the TIME decomposition; both independent interface families; source support distinction; the cross-slice dependence of full signed W; and an explicit directed-edge/graded reflection convention rather than a bare Nt2 vertex swap. These are source-level facts and prospective proof obligations, not a full boundary identity, nonzero normalization certificate, positive state, matrix computation or publication/Lean closure.
