# Independent source analysis: covariant pages and complete typed output

Task l1-sixehc-covariant-page-r1; parent publicationROOT01a13f67/L1-physical-observable-boundary; current assigned sourceb37efd926d47e5284b5284f89490c7b5e1529064. FIRST explicit primary packet check returned exit0, fresh=true, changed=[]. Read current sole-writer notebook/commission, FULL accepted ORIGINAL_SIX_EHC_CORE_CHIRAL_FIERZ.md and its acceptance, FULL accepted ORIGINAL_SIX_EHC_MIXED_ENDPOINT_KERNEL.md, and original six-holonomy/coframe bindings. No current mathworker draft/verdict read. Only this private report is owned/written; preserve source/notebook/others. Manual analysis only: no generated page, intertwiner, mask, Haar/moment/network table, code/import/test or scientific execution.

Disposition: ACCEPT the8/12/9 representation-space bounds and the2304/16200/16200 complete typed OUTPUT shapes under the explicit open-index conventions below. They are not actual nonzero ranks, compiler bounds or whole-join qualification. A historical source-audit prose correction is necessary: page0 contains U,V WITHOUT daggers. The accepted original holonomy formulas already give the correct order; no changed scientific source or model is proposed.

## Literal central factors and historical correction

Set U=Omega_(1,2), V=Omega_(5,2). Original H_(z,kl)=Omega_(z,l)† Omega_(z+l,k)† Omega_(z+k,l) Omega_(z,k) gives

page0:
 H_(0,02)=Omega_(0,2)† Omega_(4,0)† U Omega_(0,0),
 H_(4,02)=Omega_(4,2)† Omega_(0,0)† V Omega_(4,0);
page1:
 H_(1,12)=U† Omega_(5,1)† Omega_(3,2) Omega_(1,1),
 H_(5,12)=V† Omega_(1,1)† Omega_(7,2) Omega_(5,1);
page3:
 H_(1,23)=Omega_(1,3)† Omega_(9,2)† Omega_(5,3) U,
 H_(5,23)=Omega_(5,3)† Omega_(13,2)† Omega_(1,3) V.

Thus pages0,1,3 retain respectively(U,V), (U†,V†), (U,V). All twenty anchors remain independent; no gauge fixing, link identification, reversal of gamma order or averaged central link is introduced. Each face's chiral block belongs to the original gamma_[C gamma_D] gamma5 trace; the original world epsilon and its sign remain.

The immutable earlier ORIGINAL_SIX_EHC_CORE_CHIRAL_FIERZ_SOURCE_REVIEW_R1.md lines107–109 incorrectly describes page0's central entries as U†,V†. This is a prose error in that audit, contradicted by the original literal holonomies above. Record this correction in the next acceptance/history; preserve the old report. The local Fierz identity and accepted separator dimensions did not depend on replacing these entries by daggers, and the main accepted proof does not adopt that incorrect pair of page0 entries. A new compiler must bind to the displayed originals, not that audit sentence.

Under the original local gauge transformation, Omega_(x,i) transforms as g_(x+i) Omega_(x,i) g_x^-1. For central U this is g5 U g1^-1; V is g1 V g5^-1. U† and V† transform in the opposite directions. Their actual free hub indices are therefore fundamental or dual depending on the factor/endpoint. A dagger DOES NOT interchange L/R; SU2 pseudoreality identifies a dual with the same-chirality fundamental by E. In matrix form U†=-E U^T E. Use the two explicit E pullbacks and their sign for every inverse entry; never silently change the holonomy to U or drop individual endpoint maps. Page1 has two daggers, but their local index/sign maps still matter even when a global pair of minus signs cancels.

## Covariance of partial-page integration

Each page integrates its six NONcentral anchors and the two outside-site original odd tops, retaining both central fundamental factors, hub fields and interpage internal-vector indices. Haar bi-invariance permits changing every integrated anchor by the actual endpoint gauge matrices. The outside-site Grassmann volume/top is invariant because Spin4's chiral fundamental and dual determinants are1. The original coframe/gamma tensors, internal epsilon and gamma5 traces are equivariant. Therefore the resulting partial integral is an intertwiner for the two independent hub groups at1 and5, with the central open indices in their actual dual representations. It is not invariant if those indices are held numerically fixed without transformation. Covariance is preserved by retaining them, rather than by fixing U,V to identity.

Original Q_(z,22)=sum_A T_(z,2)^A T_(z,2)^A contracts the INTERNAL gamma-vector index completely. It is a Spin4 scalar at its base site. World axis2 is fixed, but is not an internal-vector spurion. Consequently page0's actual Q0+Q4 and the separately retained central Q1+Q5 do not obstruct local hub covariance. They must remain full endpoint sums with their unequal original gamma orders. A fixed gamma component T^A T^A without summing A would not justify the same argument.

Page0's two side coframes at each hub are the SAME world-edge coframe appearing in two different EHC factors. Their even product is symmetric in its two internal-vector labels, regardless of how these labels later contract with other pages. Hence its side representation is Sym² vector=(0,0) direct-sum(1,1). This uses neither equality of face chiralities nor exchange of the EHC classes. The other pages retain one curvature adjoint label of their own face at each base hub and one side-coframe vector label, giving triplet_chi tensor vector. Those labels are genuine interpage data. Replacing them by scalars would be wrong; reconstructing them through a COMPLETE intertwiner basis is valid.

## Hub exterior representation and explicit output basis

In the accepted signed-permutation variables, the hub degree-one space is

W=(1/2,0) tensor C²_flavour,L direct-sum(0,1/2) tensor C²_flavour,R.

Thus its original degree-two exterior space H=Lambda²W is exactly

six scalar copies: three Sym² flavour,L and three Sym² flavour,R;
one(1,0) triplet: Lambda² flavour,L;
one(0,1) triplet: Lambda² flavour,R;
four vector(1/2,1/2) copies: flavour,L tensor flavour,R.

Dimension6+3+3+4*4=28. This is the full original eight-mode exterior space, not a physical subspace or new field algebra. Its scalar and vector copy labels must be retained; dimensions below INCLUDE them.

For one face pair with ordered chiralities chi,chi', convert the two actual central endpoint indices by their fixed E maps to C_chi,chi'=fund_chi tensor fund_chi'. If chi=chi', it is scalar direct-sum triplet_chi; if different it is one vector. Flipping dagger orientation changes the E pullbacks, not this list.

A complete rational typed basis can be fixed using epsilon contractions and symmetric spinor tensors, without normalized square-root Clebsch coefficients. Use the original six scalar H basis vectors, its single left/right triplets and four vector flavour copies; retain explicit copy indices. Select every following allowed coupling once and define its dual by the actual chosen tensor-basis Gram inverse. Do not assume an orthonormal physical norm or replace this dual by a positive state.

PAGE0, same chi:
 - side scalar times central scalar -> each of6 H scalar copies;
 - side scalar times central triplet_chi -> H triplet_chi;
 - side(1,1) times central triplet_chi -> H triplet_oppositechi, contracting the chi spin1 pair to spin0.
These are6+1+1=8 independent maps.

PAGE0, different chi:
 - side scalar times central vector -> each of4 H vector copies;
 - side(1,1) times central vector -> each of4 H vector copies, taking1 tensor1/2 to1/2 in both groups.
These are4+4=8. The latter channel cannot be discarded merely because the side symmetric traceless tensor alone has no H counterpart.

For PAGE1 or PAGE3, at the base hub let the own-face curvature chirality be chi. Its side representation is

triplet_chi tensor vector = vector direct-sum higher_chi,
higher_L=(3/2,1/2), higher_R=(1/2,3/2).

Same face-pair chirality gives central scalar+triplet_chi. Allowed couplings are side vector times central scalar ->4 H vector copies; side vector times central triplet_chi ->4 H vector copies; higher_chi times central triplet_chi ->4 H vector copies. Total12. Higher_chi times central scalar has no H image.

Different face-pair chirality gives central vector. Side vector times central vector gives6 H scalar copies plus one H triplet of EACH chirality, total8. Higher_chi times central vector gives one additional H triplet_chi. Total9. At the other hub of a different-chirality face pair, chi is the OTHER face's chirality: the additional triplet therefore switches L/R. Its numerical dimension remains9, but its typed basis is not the same set of output labels.

These lists exhaust the SU2xSU2 tensor-product decompositions; each allowed irreducible coupling has multiplicity1 before the stated H copies. They provide complete8/12/9 Hom spaces, not only a dimension guess. Some actual source-specific coefficients in these spaces may vanish. No claim of attained page rank or nonzero scalar is made.

## Copy Hodge constraints and complete shapes

At page0's two outside EHC sites0 and4, the accepted local Fierz identity locks curvature L to copy self-dual and R to copy anti-self-dual. For each FIXED face chirality, retain its three actual Hodge copy coordinates. The two face chiralities are independently ordered, so there are4 choices,3² copy coordinates and8 intertwiners at each hub:

page0 output ceiling4*3²*8²=2304 scalar coefficients.

Pages1/3 outside sites3/7 or9/13 have a D insertion. Both copy Hodge sectors remain,6 coordinates per site. There are two same-chirality blocks with12 maps at each hub and two different-chirality blocks with9 maps at each hub:

page1 or page3 output ceiling6²*(2*12²+2*9²)=16200.

These are complete coefficient shapes in a FIXED intertwiner basis, not the full magnetic-index arrays. Magnetic central, side-vector/triplet and hub-exterior indices are reconstructed by the declared intertwiners. If these reconstructions are absent, the small numbers omit material indices and do not qualify a page object. Conversely, multiplying these output counts again by every magnetic dimension would undo the proposed representation compression.

The three page output shapes total34704 coefficients before all source-specific zeros. They retain all64 combinations of the six face chiralities through the four ordered choices on each page. They do not identify pages, source endpoints, copy Hodge orientations or internal-vector recouplings. Hodge conversion mixes canonical copy kappa and kappa xor1111; the accepted W5856 weights must be transported exactly or paired through signed canonical reconstructions. No block can be dropped by treating the copy Hodge lock as an independent physical chirality projection.

## Central normalized joint Haar projector

For four SAME-chirality fundamental occurrences, after the original dagger E pullbacks, let A=E12 E34 and B=E13 E24 as four-spinor invariant tensors. Schouten gives the third pairing as B-A. Their ordinary invariant-tensor Gram matrix is[[4,2],[2,4]]; its inverse is[[1/3,-1/6],[-1/6,1/3]]. Therefore the actual normalized Haar invariant projector is

P4=(A outer A+B outer B)/3-(A outer B+B outer A)/6.

This is the full joint fourth-moment projector. It cannot be replaced by a product of two second moments. For a2L+2R central occurrence assignment use P2,L tensor P2,R, with P2=(E outer E)/2; odd counts in either group vanish. The existing center-parity proof still supplies exactly one original coframe per central anchor against its three curvature factors. Keep the actual source coframe's gamma, sign and dagger before applying the projector.

This invariant-tensor formula is a rational exact primitive, not a generated matrix or evaluated page. Its tensor-basis dual normalization is part of the formula. The epsilon identifications of every dagger must be applied at the actual corresponding endpoints; normalized Haar alone cannot repair an incorrect page0 U†/V† substitution.

## Output shape is not a construction or join bound

Covariance proves that a completed page can be represented by the stated small coefficient lists. It does not bound the work required to derive those coefficients from the original odd/link polynomials. A full compiler needs explicit rational intertwiners and duals, original coframe and curvature component maps, both source endpoint terms, outside-site oriented top contraction, all page Haar denominators and exact coefficient widths, plus a complete intermediate row/product bound. A raw diagram count excludes expansion, projection and cancellation work; none is admitted by2304 or16200.

The final join must retain the three pages' reconstructed interpage vector/triplet contractions, both hub exterior products with their original inversion signs, central Q1+Q5 and the correlated U,V fourth projectors, all face gamma5/world epsilons and the actual canonical/Hodge transport of W. It requires its own complete contraction tree and bounds. Three pages contribute hub degree6; central source degree2 supplies the actual complement to the original degree8 hub top. Typed intertwiner compression does not make these exterior pairings positive or automatic.

Recommend using this complete typed output and rational central-projector proof as the next construction specification, with the historical dagger correction recorded. Do not request a full page/core run until all construction/intermediate/closure bounds are supplied and independently reviewed. Actual page support/value/sign, complete compiler and join costs, walltime/RSS remain UNKNOWN. No runtime, native/Lean/slot/controller or harness authority follows.

All original full uncapped denominator/reflection/source/Bopp/log contacts, both time0/1 sources, Lambda/tail, physical TT/projector/pole/positive-boundary/product/adjoint/seam/causal propagation/matter/EM/transport/calibration/B3 obligations remain unchanged. Internal representation/Hodge and invariant tensor Gram operations are algebraic source bookkeeping, not a physical metric or state.

FINAL fresh same-packet result and own SHA/bytes accompany delivery. Source changes require pausing finalization rather than refreshing away drift.
