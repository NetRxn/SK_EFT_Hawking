# Public recoupling research: lead primary-source intake

**Source tier:** web-sourced Tier1, bounded public known-result search; only the
specific primary statements below have been lead-checked. No paper parameter,
axiom, physical state, book amplitude or execution admission is imported.
**Fetched / checked:**2026-11-20 via in-team Terra scout and direct lead web reads.
**Sources:** Freidel–Krasnov arXiv:hep-th/9807092v2 (primary);
Collins–Sniady arXiv:math-ph/0402073v1 (primary).

The scout's initial useful lead is exact invariant-channel Haar recoupling. Lead
opened the actual PDFs and read the relevant primary sections directly. In the
opened Freidel–Krasnov v2, AppendixC has normalized Haar in(140), invariant-basis
projector in(141), inverse duality immediately after it, and four-factor graphical
resolution in(147); PDFpages54–55. Initial scout locators C2/C6/C8 do not match
that opened version and are NOT adopted as verified locators. Attempted diagram
screenshots returned cache misses; the textual projector/duality statements and
full AppendixC were available and read. No repository/tool repair was attempted.

[Freidel–Krasnov, Spin Foam Models and the Classical Action Principle, v2](https://arxiv.org/pdf/hep-th/9807092v2):
normalized Haar of representation tensor products resolves into invariant
intertwiners; inverse factors require explicit SU2 duality. The four-leg case
can be recoupled through intermediate representation labels. This supports a
method, not the present fermionic book value or its resource fit. For four
fundamentals, singlet and triplet pair coupling give two invariant channels.
The latter specialization is the lead's elementary representation inference.

[Collins–Sniady, Integration with Respect to the Haar Measure on Unitary,
Orthogonal and Symplectic Group, v1](https://arxiv.org/pdf/math-ph/0402073v1):
section2.2 equation6/Proposition2.2 describes the normalized Haar twirl as a
conditional expectation/orthogonal projection. Section2.4 equation11 is a
balanced U(d) moment formula; it is not adopted as an unrestricted SU2 formula
for unbalanced fundamental and dagger factors. Its permutation method is only
an orientation/cross-check lead unless determinant-one duality is kept.

## Self-contained manual four-fundamental proposal

This is an ORIGINAL manual specialization for future independent review, not an
executed table or a claim that the cited paper computes the core. With E12=+1,
let A_(i1i2i3i4)=E_i1i2 E_i3i4 and B_(i1i2i3i4)=E_i1i3 E_i2i4.
Their invariant Gram is[[4,2],[2,4]], inverse[[1/3,-1/6],[-1/6,1/3]].
Thus normalized integral U^tensor4 is

 P4=(AA^t+BB^t)/3−(AB^t+BA^t)/6.

Equivalently I0=A/2,I1=(B−A/2)/sqrt3 are orthonormal. Rank2 is complete because
(1/2 tensor1/2)=(0 directsum1), and two such pairs form a singlet only through
0⊗0 or1⊗1. Convert EVERY dagger with actual index duality before usingP4:
Udagger_ij=sum_ab E_ia E_jb U_ba. Haar2 isE⊗E/2. Do not convert two conjugate
occurrences into independently averaged matrices; gather all2/4 factors for the
same group, leaving their exterior coefficients/open spinor indices external.
At fixed fundamental indices, P4 row1122/column1122 is1/3, consistent with the
unit-quaternion moment of |U11|^4. This is an analytic sign/normalization control,
not a new integration run. Raw unnormalized A/B avoids square-root coefficients.

For the present core every surviving actual SU2 degree is0,2,4, so this is a
potential small-channel replacement for external dense spinor labels. Binding
all actual anchor/partner/dagger and Grassmann order to those channels, deriving
complete page/core factor counts and independent ACTUAL source review remain
necessary. A two-channel local projector alone does not prove whole-core fit,
coefficient sign or physical positivity. No scientific program/import/test/Haar/
moment/mask/tensor/network execution or new runtime admission occurred.
