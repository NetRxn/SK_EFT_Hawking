# Independent prospective mathematics and guard review: full necessary support

Verdict: ACCEPT DESIGN WITH CONDITIONS below, for preparation and subsequent exact-byte review only. The proposed domain, Green bounds, fixed record format and worst output envelope are mathematically consistent. This is not acceptance of an unwritten program, a completed support census, a120second/RSS fit or execution admission. ROOT must separately accept the frozen program/profile and explicitly admit any run.

Task l1-sixehc-full-support-design-r1; parent publication ROOT01a13f67/L1-physical-observable-boundary. Current source555a8819ed9fe9016c38f6478931240fa8920dab. Author/sole primary notebook writer Executor01a1ac65; reviewer independent. FIRST action checked the NEW SAME primary packet: fresh=true,changed=[]. Read full proposal SHA256b1c725f70a2feb3df6431148dc089ae936aced535ed2e1c352b9813ef93553f4, latest primary notebook/intake/commission, pinned authorities/roadmaps and accepted original construction/native cost references. No other reviewer verdict read. Own report only. Manual/static text/continuity bookkeeping; no scientific execution/import/class or key regeneration/inventory/replay/evaluator/test/build/Lean/Git/runtime/controller/source/notebook action.

## 1. Completeness and exact provenance

The accepted native key data bind152096triples,23234nonempty buckets,302624canonical key-surviving six-multisets and maximum2936pairs per bucket. Full support must REGENERATE the original triple middle labels and verify the canonical generation digest61ac89331b24687c1355c16b88ec80d690c9b41df698409687aaefecefd2abf6, sorted lossy cost multiset SHAa61397f230781794b4c54975486948254d28bf64505402691fa298db4711f8b9and all descriptors/source/input pins. Observed zero packed collisions does not permit inference of middle labels or deduplication.

Orderingpwithin each key by(maxlabel,fulltuple) and iterating its prefixmaxp<=minq preserves the unique first-three/last-three split. Each canonical six-multiset appears once. Every key, including zero-pair buckets, must be accounted for. All302624pairs,16actual time0/time1source cases and2root references remain the complete logical domain:4841984cases and9683968potential references. These are necessary filters only, not full local chiral/exterior/Haar support.

The current documentation head555and the native census's historical scientific headf3b77are distinct provenance facts. The frozen full-support specification should bind both the current continuity/input-body pins and the exact inherited native artifact/descriptor contract, rather than silently replacing the native head or falsely requiring an old documentation head to be current. Scientific input-body equality and actual authority must be checked before any new invocation.

## 2. Exact Green linearity and ranges

The radial numerator row sum is
103+4(-13)+6(-9)+4(19)-25=48,
so uniform8maps to384. Since max absolute radial numerator is103, a single EHC load gives |a_alpha(v)|<=2*103+103+103=412. A triple sum is at most1236. The twoQsource loads give |b_c(v)|<=2*4*103=824. Therefore
|vnum|<=384+1236+1236+824=3680.
For reference r=0or1, |384r-vnum0|<=4064 and the complete numerator is bounded by7744. All signed16storage/arithmetic limits proposed are safely below32767; intermediate accumulation should still use exact Python integers or a separately proven nonwrapping representation.

The first source atroot0supplies load2, forcing4m0<=6and m0in{0,1}. The root adjustment adds384r epsilon_v, so divisibility of vnum_v-epsilon_vvnum0 by384is independent ofr. Checking it once per case is correct. It does not remove the two logical reference cases: a proven integrality failure rejects BOTH, and reporting must distinguish logical rejected references from roots actually evaluated. Likewise a checkerboard/RHS failure can reject a case without pretending its unexecuted numerical roots were tried.

The proposed reconstruction is exact Green linearity, not a floating approximation. For every surviving root retain range0..2,m0,r,total12,all16site equations and actual cut/key constraints. The sum RHS96 follows from128capacity minus24EHCload minus8source load. No key match substitutes for the integer equations or later anchor conditions.

## 3. Storage envelope is payload, not RSS

TwoNuint32arrays require1216768bytes; oneN*16signed16array requires4867072bytes, total6083840bytes. The values fit the claimed signed and unsigned widths. Explicit runtime itemsize checks2and4are necessary because a language array type is not itself a portable byte-size guarantee. Three full labels fit21bits inuint32; actual class/key ranges must be checked, not truncated into fields.

This total excludes the native input bytes/JSON,96class and16source vectors, bucket offsets, sort/index containers, Python object overhead, temporary projections needed to reconcile the cost hash, ZIP buffers and verification state. The proposal correctly keeps RSSUNKNOWN. An implementation should document each additional container and avoid NPython16-tuples when the typed vector array suffices. Sorting/hashing needs its own bounded dataflow; do not accidentally allocate another all-vector Python structure while computing a digest.

The full-labeled digest must be computed in the original canonical triple generation order, before a different bucket/max sort. Reconciliation of the sorted lossy packed hash is separate and multiplicity-preserving. Both must match the inherited artifact; a matching global count alone is insufficient.

## 4. Necessary anchor filters and exact weights

The original per-edge coframe counts and all64anchored curvature occurrence counts must be reconstructed from the actual six labels,source case andoccupation. Individual parity test is correct: for n=0both curvature counts must beeven; for n>=1the interval of possible anchor choices has both parities, so total parity suffices for NECESSARY existence. This is not a chiral/mask or nonzero-moment test.

Counts must also enforce the proven global target degree bound10on source edges and8elsewhere; same-time overlap bound12belongs only to a separate control. An implementation's bound assertion needs to use true occurrence counts, not merely the saved parity mask.

The exact scalar is w_case/[prod_zm_z! prod_alphan_alpha!]. At sum m12,m0..2the cosmological divisor is at most2^6. For six EHC factors the class factorial product is at most6!, so the combined divisor is at most46080. These are positive integers and fitu32. No extra12!or6!is retained, no raw1/2is multiplied into reduced±8weights, and complete class epsilon signs stay inside the polynomial. The proposed diagnostic epsilon product must not be applied as an additional scalar sign.

Full labels and the frozen complete class/source catalogues reconstruct every anchor multiplicity,dagger,gamma order andclass sign. Saving only an anchor parity mask is acceptable as a redundant diagnostic, not as a replacement for those data or proof of an amplitude. No row coalescing by load,key or signed scalar is justified.

## 5. Fixed32-byte record and known witness

The standard little-endian format <8BIhbBIQI is EXACTLY32bytes without native alignment:

- bytes0..5: sorted six classIDs, each0..95;
- byte6: caseID0..15; byte7: frozen format version;
- bytes8..11: sixteen2-bit occupations, values0..2only;
- bytes12..13: signed source weight±8;
- byte14: signed diagnostic class epsilon product±1;
- byte15: root reference0or1,equal to storedm0;
- bytes16..19: positive exact factorial divisor<=46080;
- bytes20..27:64-bit actual curvature-anchor parity mask;
- bytes28..31: reserved zero.

The actual program/spec must freeze the occupation bit order,anchor-bit indexing,record traversal order and version value. Unsigned packing is not validation: out-of-range labels,occupation3or inconsistent root/divisor/mask must cause refusal. Reserved bits must remainzero. A future reader needs the frozen source/class catalogs and exact formula interpreting the record, not merely a binary struct string.

The required witness is correct: classIDs(1,1,11,11,21,21) correspond to the three doubled classes previously proved,case2has vertices0,3andaxes2,2with reduced weight-8. Occupations2at5,6,9,10,12,15and0elsewhere give root0,cosmological divisor64andclass divisor8,combined512. Every class occurs twice,so diagnostic epsilon+1andcurvature paritymask0. Its record weight is-8/512=-2^-6,consistent with the reducedcase convention and distinct from oldraw-2^-10. This is necessary support,not an amplitude value. The completed output must contain this exact record; absence requires refusal or an explicit implementation defect,not a successful empty census.

## 6. Complete counters and refusal semantics

Freeze a disjoint counter partition across all302624pairs and4841984cases. For each pair/case,the two logical references must be accounted for as retained or a PROVED rejection category,even if an integrality/RHS shortcut avoids evaluating them individually. Keep actual arithmetic/root-evaluation counters separately,so no fabricated execution count is reported. Explain precedence when several rejection reasons apply. A complete status requires pair/case/reference totals and their partitions to reconcile EXACTLY,plus catalog hashes,required witness and record counts.

Every valid canonical tuple/case/root produces at most one record. Thus9683968is a rigorous absolute output ceiling; it is not a measured retained count. One source case/root is not discarded because another has the same load or physical-looking field support. A timeout,byte cap,mismatch,missing witness or overflow makes the result INCOMPLETE; it cannot certify a coefficient zero or prefix coverage as full support.

A refusal receipt should bound its size and define precisely its processed counters and prefix hash. If buffers contain records not yet written,the receipt must distinguish a processed logical prefix from bytes actually flushed or published. No ambiguous resume token or automatic retry follows. Checkpointable shards require a separately frozen coverage/deduplication/resume contract first.

## 7. Worst output, streaming and guard boundary

The absolute record ceiling times32is309886976bytes. With manifest<=1000000and fixed two-member overhead<1024,the staged container is below310888000bytes. Proposed320000000decimal bytes,approximately305MiB,is therefore a safe larger NEWscience-artifact profile. It is not a derived old guard entitlement or an infrastructure cap change. Independent acceptance of this bounded design does not replace ROOT's resource/profile decision or later execution admission.

The stream design is sound if records go directly to one own staged ZIP_STORED member with incremental count/hash and no full retained-row list. All verification must also be streaming: avoid whole archive.read_bytes(),whole member.read()or a second uncompressed copy at the309MBworstcase. Use bounded chunks for container/member hashes,CRC/readback and any postwrite validation. Fix member names/comments/extra fields or enforce actual final archive cap regardless of overhead assumptions. Do not materialize the full artifact in a BytesIO buffer.

Exclusive hard-link publication from own same-filesystem staging,with the final component un-followed,lexists refusal and direct/private/tmpparent,can reuse the accepted R3contract. Publish only after every complete-domain/counter/hash/witness/size check. Existing destinations and unrelated evidence stay untouched; clean only own staging. A successful hardlink does not claim crash-fsync durability. Caller must inspect actual exit and output if termination occurs around publication.

120seconds is a proposed COOPERATIVE refusal limit,not a measured fit or hard preemption. Check after bounded candidate intervals and I/O,but do not claim control over a built-in sort or blocking filesystem call. The old0.2895second key census does not predict9.68million source/reference-filter work or worst output serialization. Walltime/RSS/disk throughput remainUNKNOWN. A read-only free-space check can refuse before launch,without host repair. Staging plus final hardlink shares one data inode; avoid a separate full uncompressed file. Required remaining disk margin and refusal policy belong in the exact prepared spec.

## Disposition

ACCEPT this guard DESIGN WITH CONDITIONS for preparing exact code/spec. The arithmetic/packing/output maxima are correct and the necessary-support completeness contract is coherent. Before an execution request,freeze actual source/body/native pins,all byte/iteration/counter/serialization rules and bounded refusal receipts; obtain independent ACTUALmath/source/static-dataflow reviews and ROOT's explicit profile/admission approval. No code was written or run by this review.

This stage does not certify local chirality/exterior support,Haar amplitudes,raw or fullcoefficient sign/nonzero,physical projection or a complete positive transfer. Original full Z/Lambda/Lclear/tail,uncappedDelta0,both kernels and allsource/normalization/contact laws remain. FullTT/Ward projector,pole,residue,boundary/product/adjoint/seam/causalV,calibration,matter/EM/light/transport,time/scales,B3/N4andcontrolledlimits remain open;priorwitnesses andc0frontier persist. ROOTretains canonical intake/integration/closure/runtime authority. FIRST/final SAME and report SHA/bytes are returned separately.

## Prospective algebraic refinement: pair-level integrality fingerprints

The proposed case-fingerprint optimization is VALID and exactly equivalent to the divisibility test for both roots. For E(v)=a_p(v)+a_q(v), define the15-entry residue vector R_E(v)=E(v)-epsilon_v E(0) mod384 forv=1..15. For each frozen source case define f_c(v)=-(b_c(v)-epsilon_v b_c(0)) mod384. Since vnum=384-E-b_c,

vnum(v)-epsilon_v vnum(0)
 =384(1-epsilon_v)-[E(v)-epsilon_vE(0)]-[b_c(v)-epsilon_vb_c(0)].

The uniform term is divisible by384, and the additional reference adjustment is384r epsilon_v. Hence ALL occupation numerators are integral for either root if and only if R_E=f_c. The root0entry is automatically integral. No range,site,checkerboard/cut or anchor sufficiency is asserted by this congruence.

Precompute the16source fingerprints as a dictionary to LISTS OF ALL ORIGINALcaseIDs. A collision is allowed and is not a reason to merge/drop sourcecases,gamma orders,times,weights or factorials. Every matching ID still gets its own complete site/range/root/cut/anchor checks and its own signed records. Every nonmatching case is rejected by the exact proof for BOTH logical references; counter partitions must record these as proved integrality rejections and distinguish them from roots actually evaluated. The canonical pair/bucket domain and potential9683968references are unchanged.

One15-vector per canonical pair replaces a repeated per-case congruence scan. The quoted roughly77million versus4.5million modulo entries are prospective loop-count comparisons, not benchmarked walltime or a120second-fit claim. Source fingerprint tables are small fixed data; pair vectors remain exact integers within the already proved bounds. Freeze the sign,modulus,vertex order,all-IDlist semantics and the equivalence proof in the actual spec/code, then independently review the concrete dataflow. No source fingerprints or scientific keys were generated by this review. This refinement strengthens the prepared design without changing its no-execution/admission boundary.
