# Exact integrality fingerprint and streaming refinements

Within l1-sixehc-full-support-design-r1, source555a8819ed9fe9016c38f6478931240fa8920dab. This mathematical addendum refines the frozen proposal without executing any science or changing its16-case/32-reference logical domain. It requires the independent prospective/actual proof and exact implementation review; it is not admission.

Let E(v)=a_p(v)+a_q(v), B_c(v)=b_c(v), epsilon_v checkerboard. Then

 vnum_c(v)=384-E(v)-B_c(v),
 vnum_c(v)-epsilon_v vnum_c(0)
 =384(1-epsilon_v)-[E(v)-epsilon_vE(0)]-[B_c(v)-epsilon_vB_c(0)].

The uniform term and root adjustment384r epsilon are multiples384. Rootv0integralityisautomatic. Thus BOTH reference candidates are integral IFF the15nonroot pair residues R_E(v)=[E(v)-epsilon_vE0]mod384 match the source fingerprint F_c(v)=-[B_c(v)-epsilon_vB_c0]mod384. Precompute a dictionary fingerprint→LIST OF ALL16sourcecaseIDs. For each full canonical pair calculate ONE15-entry residue tuple and look it up; all nonmatching cases are proved-integrality rejects, each contributingTWOLOGICALreference rejections. Every matching case ID retains its own endpoint/gamma/sourceweight and receives allrange/root/direct16site/sum/cut/paired+individualanchor checks. Nevercombineweightsorselectonerepresentativewhenfingerprintscoincide.

Concrete source guard:case2(Q0,22 Q3,22)andcase6(Q0,22 Q7,22)bothuse the second undirected edge3–7 and haveequal load/fingerprint, buttheiractualsecondendpointgamma/anchorplacementsareDIFFERENT. BothIDs/weight−8mustremain. This is algebraic grouping of necessary-integrality tests, NOT quotienting observables or matching amplitudes. Counterpartitionretains4841984logicalcases/9683968logicalrefs, and actualcomputedmatchingcases/root-evaluations are reported separately. No measured speedup is claimed.

Freeze full triple label packing(a<<14)|(b<<7)|c, all7bit labels. Native full-labeled generation digest uses exactstruct<BBBI (a,b,c,key),7bytes per triple in combinations_with_replacement canonical GENERATION order. Native lossy cost hash uses unsigned-sorted(key<<14)|(a<<7)|c serialized<I; this ordering is distinct from later bucket maxima/fulltuple join ordering. Reconcile BOTH before filtering. No middle label is inferred from lossycost words.

The accepted R3 PUBLICATIONcontract may be reused (directprivate_tmpchild, nofollowfinal, exclusivehardlink), but its whole-file archive.read_bytes()/ZipFile.read(binary) MUST NOTbe copied forpotential309MBsupportoutput. Stream ALLlargefile hashing, ZIP member verification/CRC and exactsize/hash checks in boundedchunks (e.g.65536bytes);manifestbounded<=1MBmaybereadwhole. Streamfixed32byterecordsdirectlyintoZIP_STORED;neverretainalloutputrowsora seconduncompressedcopy. Guard RSSUNKNOWN despite6MBtypedpayload; Pythonbucket/index/sort/objectandZipbuffersneedexplicitimplementationaccounting.

A120scooperativetimeout/packing/byte/count/refusalmustpublishNOcomplete-supportcontainer. Preserveboundedrefusalreceiptonstderr/callerlogs withprocessedbucket/pair/case/reference counts andcurrentprefixhash,withoutclaimingprefixcoverswholecoefficient. Noautorerun/resumeorcapincrease. Ifresumableshardsdesired,freezeexplicitcanonicalcoverage/resumeproofandgetseparateadmissionfirst. Thisrefinementdoesnotraiseoldcapsorrequestexecution.
