# Bounded COMPLETE source/load/anchor-support specification — proposal for guard review

Task l1-sixehc-full-support-design-r1; parent publicationROOT01a13f67/L1-physical-observable-boundary. Lead/notebook writerExecutor01a1ac65. New source555a8819ed9fe9016c38f6478931240fa8920dab, accepted construction/nativecost checkpoint, clean/pushed/remoteverified. ROOT requested this specification IN PARALLEL with finishing output reviews/checkpoint; no further execution admitted. All current actual output reviews now ACCEPT; prior R3 one-shot admission SPENT. This is a PROPOSAL, not implemented code or independent guard acceptance. Mathematical/source/static review and ROOT guard/admission remain required before any run.

## Exact existing input and scope

Originalh1h12,6q0q1/SAMEg*/Lambda/k/source/time/64anchors/128odd unchanged. NativeR3 ZIPbdaad6aaac75c337ed5f1bf59501fde081094d837e0bfac78f8bfcc655ac41a7/687079B; manifest5110bc1a2d3ca393629c040dbc13c07578ef36f9819931507481878afc6d6271; packedLE32a61397f230781794b4c54975486948254d28bf64505402691fa298db4711f8b9/608384B. N152096triples/23234keys/max151triples/max2936canonicalpairs/S302624,16cases/tworefpotential9683968. Full-labeled generation digest61ac89331b24687c1355c16b88ec80d690c9b41df698409687aaefecefd2abf6. ROOT independently reconciledSfromexistingpackedrows;supportteamdidnotreplaycensus. Currentwork mustREGENERATEFULLmiddlelabels,notinferfromlossypackeddata.

Stagecompleteness is NECESSARY SOURCE/SITE/PAIRED+INDIVIDUALANCHOR support ONLY. It does NOTcertifylocalchiralmask/Haaramplitude/nonzero/fullcoefficient. Alllocalpolynomials/signedmomentcontractions/GramadjointtermsNOTRUN. Same-timecontrolindicesmuststaydistinct;current16targetcasesSTRICTtimepair0,1. Signedsourceweight±8alreadyincludesreduction;NOraw1/2again. FullEHCepsilonstaysINSIDEclasspolynomial,diagnosticproductrecordednotmultipliedtwice. ExactfullZ/Lambda/Lclear/tail/uncappedDelta/bothkernel/physicalTTpositiveVtransportB3obligationsunchanged.

## Regenerate and reconcile full canonical domain

Useexactsamecanonical96class/32edge/tree/18bitkeycontract. Generatefullsorted(a,b,c) tripleswithmultiplicity. Independentlyreconcile N, completefulllabeleddigest,costpackedMULTISETsha,all96descriptors/16targetcases/inputs. Comparekeybucketcountsandcanonicalpairmax/globalSwithnativeR3;anydiscrepancyREFUSE. No omittedmiddlelabels orlabelmergingbyload/key. Storefulltriplelabelpack21bitsinuint32array andexactkeys18bitsinuint32array. Anyuseofpackedlossykeycatalogueforlabelreconstructionisprohibited.

Within each key bucket orderpby(maxlabel,fulltuple) withmultiplicity; for everyqcomputeadmissibleprefixp.max<=q.min anditerateonlythatprefix. ThisUNIQUEfirst3/last3splitcoversall302624sixmultisets ONCE. Processeverykeyincludingzeropairbuckets;perbucketpaircount<=2936,totalpairsEXACT302624,totalcandidatecasesEXACT4841984,potentialrootrefsEXACT9683968. Anycap/refusalbeforecompletionmuststateINCOMPLETE;notcoefficientzero.

## Exact Green linearity and finite typed storage

K=4I+Adj,Gnumdistance[103,-13,-9,19,-25]/384. RowsumGnum=48soGnum*uniform8=384. Forclassalphaat z/framesmu,nu, precomputea_alpha(v)=2g(v,z)+g(v,z+mu)+g(v,z+nu),absolute<=412. Foractualsourcecasec, b_c(v)=2[g(v,first)+g(v,firstneighbor)+g(v,second)+g(v,secondneighbor)],abs<=824. Triplepstorea_p=sum3a,abs<=1236. Withpairp,q,
 vnum_c(v)=384-a_p(v)-a_q(v)-b_c(v),abs<=3680.
 m_v(r)=[vnum_v+(384r-vnum0)epsilon_v]/384,r0,1.
Everyfirstsourceatroot0load2forcesr<=1. Allvaluesexactintegers; triplea_pfitsSIGNED16bit, numeratorrangeabs<=7744fitsSIGNED16bit. Integralityof(vnum_v−epsilon_vvnum0)mod384isINDEPENDENTofr;checkoncepercaseandifbadrejectBOTHrefsbyproof,countbothlogicalrefrejections. Range/root/cut/site checksremainforeachpotentialvalidr. Do notturnoptimizationintoomittedlogicalrefs.

Typedbufferscanboundscientificpayload: twoNuint32arrays labels/keys=1216768bytes, oneN*16signed16vectorarray=4867072bytes, total6083840bytes (requiringruntimeitemsizes2/4). Additionalbucketindex/sortcontainers/ZIPbuffers/exactPythonobjectoverheadmustbeaccounted; RSSUNMEASURED. O(N)typed payloadisNOTpeak-memorycertificate. AvoidstoringPython16-tuplesofintsforeachtriplewherebufferssuffice; no scientificlibrary/helperimport/dependencyworkneeded.

## Complete necessary filters and exact signed record

Checkcheckerboardrhscompatibility,sumrhs96,integrality/range0..2,m0/ref,sum12,EVERY16siteequation,same18bit/fullcutδmcharacter;thenoriginaledgecoframecountsandseparate64anchorcurvaturecounts. Individualanchorconditionexistj∈[0,n_e]withj+cUeven,n_e−j+cVeven:ifn0botheven,otherwisepairedtotalparity. Localchirality/HaarzerosNOTtested. Allcosmo/EHC/sourcecountsretainactualindices/anchors/daggers;globaldegree<=10forsourceedges/8others;same-timeoverlap12notthistarget. Assertnativeobserveddegree<=provenboundsorREFUSE.

Exactrecordweightw_c/[prod_zm_z!prod_alphan_alpha!]. m0..2,sum12⇒cosmodivisor<=2^6;sumclassmultiplicity6⇒classdivisor<=6!;combined<=46080. Noextra12!or6!,norraw1/2. ProposedFIXED32BYTELErecord:
 offsets0..5 sixclassIDs(u8);6caseID(u8);7formatversion(u8);
 8..11occupations2bit×16(u32);12..13sourceweight(i16,±8);
 14class_epsilon_product(i8,diagnostic±1);15rootreference(u8);
 16..19factorialdivisor(u32);20..27actualcurvature-anchorparitymask(u64);
 28..31reservedu32zero.
 Thisisstructformat<8BIhbBIQI,32bytes. Completeclass/sourcecataloguereconstructsfullanchors/counts/gammawords;storedmaskisparitydiagnostic,NOTreplacementoffullcurvaturemultiplicity. EHCepsilonsremaininsideEpolynomials,notappliedagaintow. Everyrecorddistinctcanonicaltuple/case/occupation; no signedamplitudecoalescing/dedup.

KnownnecessarywitnessMUSTbeincluded: classIDs(1,1,11,11,21,21),case2(d1,nu2,sourcevertices0/3),m2at5,6,9,10,12,15,m00,sourceweight−8,epsilonproduct+1,factorialdivisor512,curvatureparitymask0. Thisisthenecessaryloadrecord,NOTamplitudevalue. MissingwitnessorallotherinvariantsrequiresREFUSAL,neverasuccessfulzeroinventory.

## Proposed caps, stream and guard acceptance question

Finiteabsoluterecordceiling=9683968(no morethanoneperpotentialref). At32bytes worstbinary309886976bytes. Manifest<=1000000bytes andfixedtwo-memberZIPoverhead<1024givecontainer<310888000bytes; proposeexplicitMAX_ARCHIVE_BYTES320000000 decimal (approx305MiB),notanoldguardincreaseorinfrastructurechange:NEWscienceprofilemustreceiveindependent/ROOTguardacceptance. DoNOTreuse2MBkeycensuscaporthinkitqualifiesfullsupport. StreamrecordsDIRECTLYintoownstagedZIP_STOREDmemberwhilehashing/counting;donotstoreallrowsinmemory orbuildanother309MBuncompressedcopy. Noamplitudegenerated. Hardlinkpublishonecontaineronlyafterallbucket/pair/case/ref/checksums/witness/countpartitionsfinish;reuseacceptedR3directchild/private_tmp/nofinalsymlink/exclusive-linkpublicationcontract.

CooperativetimecapPROPOSAL120seconds,notmeasuredfit/hardpreemption. CheckatboundedcandidateintervalsandafterI/O; anytimeout/byte/count/packingrefusalproducesNOCOMPLETEsupportclaim,andretainboundedrefusalreceiptwithprocessedcounts/prefixhash. Noautomaticretry/guardraise. IfROOTpreferscheckpointablebucketshards,deriveexplicitcoverage/resumecontractBEFOREexecution;acappedprefixisnotcompletedinventory. ExistingR3statsareonlykey-stagecost;runtime/RSSforthe9.68mrootdomainUNKNOWN. Read-onlyfreediskcheckcanrefusetherunbeforestartifspaceinsufficient;nohost/harnessrepair.

RequiredGUARDreviewbeforeexecutionrequest: fixed32byteformat/ranges/sourceweights/epsilonconvention;label/digestregenerationandALLdomaincounterpartition;typedbufferoverheadandstreamboundedoutput;320MBworstartifactacceptability;120scooperativerefusalscopeandprefixpreservation;sourcewitness;staticprogramme/nativepackagingreview. Thenprepareexactcode/spec/hashpackage,independentACTUALmath/source/staticreviewsandROOTexplicitadmission. No nextinvocationcurrentlyauthorized.
