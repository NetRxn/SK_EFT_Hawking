# ROOT bounded execution request — complete necessary support R1

Requested by Executor01a1ac65, source555a8819ed9fe9016c38f6478931240fa8920dab,
clean checkpoint; no candidate import/run/help/test has occurred. Prior key-census
admission consumed; this request has no authority until explicitly admitted.

Independent exact-preparation reviews all ACCEPT, lead fully read:
- /private/tmp/l1-sixehc-full-support-implementation-math-r1.md,
  14546B, SHA25629bdfb8cee1b74c1b735d4aceb9a43e81061590ff07bd2cf4b6ababd154a6929.
- /private/tmp/l1-sixehc-full-support-implementation-source-r1.md,
  14658B, SHA256da7794ab22c5b4e88fc8722c0a1eca32c002ac297ded935e0aa49b11af486783.
- /private/tmp/l1-sixehc-full-support-static-code-review-r1.md,
  8401B, SHA25677b23d26a882ffaa08e6cd89f24ec686da9a1ba357fd5198475acd92af458f4f.

Prepared package /private/tmp/l1-sixehc-full-support-package-r1.zip:
63411B, SHA2561c0943bc5d86379244d4367cc105fc6e79e67eb0217bd554eea89865dcebe78d,
five members, CRC and exact member byte equality checked. Construction/README
accepted by both substantive reviewers and static guard reviewer. Programme:
37573B, SHA25656838abada05054996841f221595cd3c79881b46641379225fad0078d707206f;
spec5377B, SHA2568f818f811cbfd776b2e95b5c083b21dc59866bb3f1d159efad14273468e9dbd6.

Request explicit ROOT acceptance of NEW profile and ONE invocation:

python3 /private/tmp/l1-sixehc-full-support-package-r1/complete_support.py --spec /private/tmp/l1-sixehc-full-support-package-r1/SUPPORT_SPEC.json --spec-sha256 8f818f811cbfd776b2e95b5c083b21dc59866bb3f1d159efad14273468e9dbd6 --output /private/tmp/l1-sixehc-full-support-output-r1.zip --deadline-seconds 120

Profile: at most302624 canonical pairs/4841984 cases/9683968 logical references;
records<=9683968, binary<=309886976B, manifest<=1000000B, overhead<1024B,
ZIP_STORED container<=320000000B. Read-only1GiB free-disk preflight; no repair.
65536B streaming output AND final verification;6,083,840B typed numeric arrays,
additional Python objects/sort/metadata/ZIP allocation unmeasured, peak RSSUNKNOWN.
120 seconds COOPERATIVE only, no hard preemption of sorting/I/O. These are safe
logical/output bounds, not observed fit or elapsed/RSS predictions.

Fresh primary implementation-r3 packet checks match; a separate fresh runtime
packet and exact clean HEAD/program/spec/package/thirteen-body-pins/output-
absence prechecks are required immediately before execution. No slot/controller,
Lean, environment/dependency or harness mutation. Caller directly captures child
return code, total elapsed, logs and output hash, with memoryNULL/UNKNOWN; no
optional resource wrapper. No automatic retry, resume, cap increase or helper
scientific run. Refusal is a recorded incomplete result, not a zero census.

All full middle labels are regenerated and both native hashes reconciled. Exact
fingerprint rejection accounts for both logical roots while retaining every
matching source ID. Direct original site/cut/paired/individual anchor checks and
both source2/6 generated witnesses precede complete-counter publication.
Exclusive direct/private/tmp hardlink publication protects existing final names;
only own staging is cleaned. Minor accepted diagnostic limitation: on refusal
before a new root loop, advisory position.root may still name the previous
case's root; counters and last-completed-pair remain separate and no prefix is
resumable. No crash/fsync or external interruption receipt guarantee is claimed.

Requested output scope: complete NECESSARY source/site/cut/paired/individual-
anchor support ONLY. Local chiral/exterior support, correlated Haar amplitudes,
signed coefficient/sign and original physical positive boundary/adjoint/TT/
causal reconstruction remain NOT_RUN/OPEN. A successful run still requires
independent ACTUAL output reviews, qualified checkpoint and ROOT intake.
