# Prospective original-source / guard review — complete six-EHC support design R1

**ACCEPT this PREPARATION design with the implementation/guard conditions below.** It is source complete for the declared NECESSARY site/cut/paired+individual-anchor stage, and its record/range/output bounds are coherent. This does not admit execution, accept a not-yet-written program, certify120-second/RSS feasibility, or establish chiral/Haar/amplitude support.

## FIRST continuity, source and custody

FIRST action was the existing adapter SAME check of primary `.codex/continuity/l1-sixehc-full-support-design-r1.json` from the assigned checkpoint. Exit0, `fresh:true`, `changed:[]`, task `l1-sixehc-full-support-design-r1`. Current source `555a8819ed9fe9016c38f6478931240fa8920dab`. FULL proposal read; SHA256 `b1c725f70a2feb3df6431148dc089ae936aced535ed2e1c352b9813ef93553f4`.

Read the latest primary notebook commission/intake clarification (writer Executor01a1ac65), governing scope and existing Phase6a/5d/6e boundaries. The original scientific definitions and accepted key-cost/native result are those directly inspected in the preceding actual source reviews. The native input catalogue belongs to its f3b77 scientific input base; the current555 preparation checkpoint and its body-pin reconciliation must remain distinct historical identities. No scientific source definition changes by this design. No other review verdict was read.

Only this private report is authored. No scientific executable/import, class/key/triple regeneration, source inventory/replay, Haar/tensor/Gram/coefficient/CAS/matrix program, test/build, Lean, controller/process/Git/slot or source/notebook/packet mutation occurred. Manual/static reasoning and ordinary text/hash/continuity bookkeeping only. Previous key-census admission remains spent.

## 1. Exhaustive canonical domain and original source cases

The full input is the accepted native key catalogue:152096 triples,23234 buckets,302624 canonical pairs. The design correctly requires regeneration of ALL middle labels and exact reconciliation of the full-labeled canonical generation digest, multiplicity-preserving native packed multiset hash,96 complete class descriptors,16 original source cases and body pins. No inference from packed min/max or observed zero packed collisions is acceptable.

The future program must freeze the21-bit full-triple layout and the exact full-labeled digest encoding used by R3, not merely name them. The native packed hash must be reconciled in its native sorted(key,min,max) order; the proposed JOIN ordering(maxlabel,fulltuple) is different and must not be expected to have the same byte stream. Both catalogue identities can be checked without deduplicating labels or lossy words.

Within each key bucket, sorting p by(maxlabel,fulltuple) and iterating the max<=q.min prefix reproduces the unique first3/last3 split. It covers every302624 pair once. Processing all23234 buckets, including zero-pair buckets, and reconciling pair maxima/total with native data protects against silently omitted groups. The domain totals are correct:16S=4841984 cases and32S=9683968 logical root references. These are the exhaustive source-domain ceilings, not retained-support counts.

All16 TARGET cases stay strictly time0,1; they keep the true source endpoint/gamma indices, first axis2 and second axis2/3, eta and reduced weights+/-8. Same-time controls remain a different explicitly labeled profile and cannot be silently inserted in this adjacent-time record stream. The product source normalizer1/2 is already absorbed by the accepted even-slot reduction; it must NOT be applied again to+/-8. No cap test replaces h=1.

## 2. Exact Green linearity and unpruned checks

The proposed linear shortcut is correct. The distance-numerator row sum is103-52-54+76-25=48, so uniform8 maps to384. Class load2 at z plus1 at its two frame neighbors gives a_alpha; source load2 at each of four endpoints gives b_case. Their sums give exactly `vnum=384-a_p-a_q-b_case` with the correct repeated-endpoint multiplicity when source endpoints coincide in a separate control profile.

Absolute bounds412 for a class,1236 for a triple,824 for a source case and3680 for vnum are conservative by the original integer coefficients. Adding the reference term gives abs mnum<=3680+384+3680=7744. These fit signed16. For the declared target each first source supplies2 at0, so m0<=1 and references0,1 are complete. The divisibility test `(vnum(v)-epsilon(v)vnum(0)) mod384` is independent of reference. Rejecting a nonintegral case can therefore reject BOTH logical references by proof, provided the counters explicitly account for2.

After optimization, the FULL original independent checks must remain: checkerboard compatibility and sumrhs96; every occupation integer0..2 and root; summ12; every one of16 site equations using ACTUAL original class/source loads and adjacency; actual cut equality; paired and separate-anchor occurrence parity. Do not use the optimized numerator alone as its own scientific validation or omit direct original endpoint checks. If an asserted invariant/proved bound fails, REFUSE rather than silently drop a term as if it were a certified scientific zero.

The18-bit key is necessary, not sufficient for that record. For no coframes both curvature-anchor counts must be even; with at least1 coframe the paired total parity admits an allocation. This establishes only necessary anchor-center existence. Local chirality, exterior masks, actual assignment amplitudes, Haar zeros and signed cancellations are outside this stage. Call the result COMPLETE NECESSARY SOURCE/SITE/CENTER support, not complete physical or nonzero polynomial support.

The global degree bounds10 on adjacent-time source edges/8 elsewhere are preserved. The quantity checked before any anchor assignment should be stated as a SAFE upper bound, e.g. max(n_edge+c_U,n_edge+c_V), not a measured chosen-chirality moment. Same-time overlapping controls need12 and must not inherit the adjacent-time bound. No coefficient or primitive/join evaluation is authorized by this guard.

## 3.32-byte reconstructible signed record

The format `<8BIhbBIQI` is exactly32 bytes with standard little-endian/no padding: six class IDs, case ID and version occupy0..7; m encoding8..11; signed weight12..13; signed diagnostic epsilon14; root15; factorial divisor16..19;64-bit curvature parity20..27; reserved zero28..31. Six IDs below96, case below16, weight+/-8 and epsilon+/-1 fit their fields.16 two-bit occupations fit uint32; code3 is INVALID, never a third allowed occupation. Reference0/1 must agree with encoded m0. Freeze the exact version and per-vertex/anchor-bit ordering in the final spec.

The complete class/source catalogues plus these labels/m reconstruct actual endpoint gamma words, all original anchors/daggers, multiplicities and full source polynomial. Curvature parity bits are diagnostic only: full curvature counts must still be reconstructed from labels for validation/moments. Do not replace multiplicities with parity in later signed assembly.

At most6 cosmological doubles give divisor2^6; class multiplicities summing6 have factorial product<=6!=720. Thus the combined divisor<=46080 fits uint32. It must be the EXACT product, not only range-checked. There is no extra12!,6! or raw1/2. Product of class epsilons is useful validation, but E_alpha already contains its world epsilon, so this diagnostic must NOT be multiplied again into the record's source weight or final E product. No signed-amplitude coalescing or deduplication by equal loads/keys is licensed.

The known witness is correctly bound: IDs(1,1,11,11,21,21) are full classes0/02,1/23,3/12 doubled; case2 is source vertices0,3/axes2,2 with eta negative and weight-8. m2 at5,6,9,10,12,15, m0=0; factorial divisor2^6*2^3=512; full-class epsilon product+1 and curvature parity0. Its record weight is-8/512 in the reduced convention, distinct from the old raw-1/2/512 word. It MUST survive necessary filters. Missing it or finding all data invalid under inconsistent checks is a REFUSAL, not an accepted zero inventory. Inclusion does not prove amplitude nonzero.

## 4. Counter partition, streaming and output guard conditions

All9683968 logical references must fall into EXACTLY ONE mutually exclusive terminal status: a proved necessary rejection or an emitted accepted record. Optimized once-per-case incompatibility/divisibility rejection must add TWO logical-reference outcomes while keeping performed-case computations separately intelligible. Pair/case/ref totals, per-bucket accounting, record count and streamed byte count must reconcile globally before COMPLETE publication. A prefix processed fast is not an exhaustive inventory.

The absolute output bound is valid: at most9683968 records*32=309886976 binary bytes. Manifest<=1000000 and fixed two-member stored-ZIP overhead<1024 give container<310888000, safely below the proposed320000000-byte cap. This is a NEW private science-profile artifact guard, not an enlargement of old120000-row/3000000-product tensor guards or a repository infrastructure change. ROOT must explicitly accept this new profile before an execution request/run; this reviewer accepts its finite bounded design only.

The typed payload estimate is correct: twoN uint32 arrays1216768 bytes and N*16 signed16 vectors4867072 bytes, total6083840, PROVIDED runtime item sizes are exactly4/2 and integer checks precede narrowing. Sorting indices/buckets, Python objects, compression/ZIP and I/O buffers are extra. RSS remains unmeasured and must not be advertised as this payload total.

Records should stream directly to the own staged ZIP_STORED binary member, with rolling hash/count, without an accumulated record list or a second309MB binary copy. IMPORTANT: reuse R3's exclusive publication CONTRACT, NOT its small-output whole-file readback implementation. An `archive.read_bytes()` or `ZipFile.read(large_member)` final check would reintroduce the large copy the design excludes. Final container/member hashing, CRC/readback and size checks must use bounded streaming chunks; names/member count must be exact and the published artifact represent completed counters only.

Reuse the proven private_tmp direct-child/no-final-symlink/exclusive-hardlink behavior, same-filesystem private staging and caught-after-publication state qualification. No preexisting evidence may be overwritten. If a file/directory/symlink races publication, link must fail without replacement. Atomic appearance does not claim crash-fsync durability. The future native caller must capture actual child exit/parent elapsed and distinguish published-complete from refused output.

## 5. Cooperative refusal and source-preserving preparation boundary

A120-second cooperative cap is defensible as a proposed refusal boundary, not a measured fit or hard wall-clock/RSS guarantee. Freeze concrete bounded check intervals during catalogue, bucket/case/ref processing and chunked I/O, including before/after final verification/publication. Built-in operations can cross a deadline until control returns; describe that honestly. The proposed complete domain may refuse under this cap, and a refused prefix is not coefficient/support zero.

Specify in the prepared artifacts whether a refused partial stream is deleted or retained under an unmistakably INCOMPLETE name. A bounded receipt with processed bucket/case/ref counts, deterministic last position and prefix hash can preserve the audit; a hash alone is not a resumable dataset. Never publish a partial file under a COMPLETE output status. Any checkpointable sharding/resume scheme needs its OWN coverage/assembly contract before execution, not automatic retry or cap growth.

A read-only disk-space refusal is permissible in the eventual preflight. Its threshold must cover staged worst container plus declared headroom, and it must not trigger host cleanup/repair. The proposed stream avoids duplicate uncompressed copies but not disk exhaustion or Python memory overhead; do not infer either resource qualification from old key-stage timing.

The next allowed action after prospective acceptance is preparation of exact code/spec/hash/package followed by independent ACTUAL science/static review and ROOT guard/admission. NO program exists here for actual acceptance or execution, and no scientific work beyond static design was run. All source/class/tree/catalogue/time/record/guard changes must be pinned for that later review.

## Scientific boundary and final SAME

The complete source/support stage still leaves local masks/Haar/amplitude/nonzero/full h12,6 and A01 sign/value UNKNOWN. The four-edge raw-word prescription, residual adjoint terms, original positive Z/Lambda/Lclear/tail, BOTH step placements, weighted Bopp/log source contacts, full UNCAPPED Delta/reflected denominator/boundary jets and physical projector/positive V/calibration/transport/B3 obligations remain unchanged. A necessary support count cannot close a physical or publication gate. Existing roadmap/planner/intake/integration/runtime/c0/slots and final authority stay ROOT-owned.

ACCEPT design/guard preparation with the conditions above; no scientific execution or automatic320MB/120s admission follows.

Final fresh SAME check (including addendum) returned exit0, `fresh:true`, `changed:[]`, task `l1-sixehc-full-support-design-r1`. This confirms unchanged inputs only, not scientific execution or completion authority.

## Prospective addendum — exact case-integrality fingerprint

The proposed algebraic lookup refinement is VALID without scientific execution. Let E(v)=a_p(v)+a_q(v). Since vnum_c(v)=384-E(v)-b_c(v),

`vnum_c(v)-epsilon_v vnum_c(0) =384(1-epsilon_v)-[E(v)-epsilon_v E(0)]-[b_c(v)-epsilon_v b_c(0)]`.

The uniform term and reference384r epsilon vanish modulo384. Root0 imposes the tautology0, so integrality for BOTH root references is equivalent to matching the15 nonroot residues R_E to minus the corresponding b_case residues. The map must use the exact full residue tuple (or an injectively encoded equivalent), not a collision-prone truncated hash alone.

Precompute fingerprint to a LIST of ALL actual case IDs. No case representative, merged weight or coalesced gamma endpoint is allowed. In particular case2 has Q_(3),22 and case6 has Q_(7),22; their second source edge is the same undirected3-7 and their loads/fingerprints coincide, but their original endpoint gamma/anchor placements differ. Both must be kept and later emitted separately if their full necessary checks pass.

For every native canonical pair, all16 logical cases and32 logical references remain accounted for. A nonmatching case contributes TWO proved nonintegrality rejections; EVERY matching case still computes its actual source-specific numerator/occupations and passes range, direct original site/cut/paired/individual-anchor/global-bound checks. Lookup, case and root counters must distinguish logical coverage from physically performed arithmetic; no false claim of running omitted Green evaluations is permitted. The native S domain, output/cap32S bound, full signed record identities and downstream local-mask/Haar/amplitude UNKNOWN status are unchanged. This is an exact optimization condition for future code preparation, not a new measurement or execution admission.
