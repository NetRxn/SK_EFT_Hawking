# N16 high-degree state-gap candidate: original full-action source check

Read-only task `L1-N16-saturation-witness-source-intake`, parent publication-L1-actual-physical-image-state-gap. Packet `l1-n16-saturation-source-intake-r1.json` fresh at entry; source `4aca534a28d05233b2394fdd7b210ea68c43a3e4`. Newest primary L1FixedControls notebook records this as a MANUAL CANDIDATE, not an accepted obstruction or evaluation. This scratch report is the sole written artifact. No scientific imports/evaluation, matrix/CAS calculation, jobs/tests/builds, Lean, Git/candidate/notebook/slot edits or process operations.

D=`docs/audits/2026-10-17-publication-substance-construction/`; B=`docs/audits/2026-11-05-l1-physical-bridges/`.

## Summary

The proposed half-degree selection and full world-order curvature coefficient are correct for the ORIGINAL zero-source undeformed N16 closed action. The proposed spatial links are simultaneously compatible, leave T1 at x nonzero, kill T2/T3 at x, and realize the asserted Spin(4) curvature H23 with R01=-4,R10=4. Those are source/algebra facts. They do NOT yet establish that the subsequent temporal-Haar/Berezin projected V6 or the actual mixed reflection entry is nonzero, nor that fullZ is nonzero.

## 1. Exact half-degree selection

The governing original coframe is `D/ADW_EXACT_AUXILIARY_IDENTITY.md:17–25`, equation(1), with original periodic links and quarter. The actual four forward/backward blocks also appear in `D/l1_full_action_reference.py:frame` (77–100). The accepted `B/N16_TEMPORAL_BOUNDARY_IDENTITY.md:1–2` retains both temporal anchor families V0,V1; half0 and half1 each have64 Grassmann generators.

At j=J=0, spatial Ti, i=1,2,3, has BOTH fermionic endpoints in its base time slice. It has Grassmann half degree(2,0) for a half0 base and(0,2) for half1. T0 has one generator in each slice, hence degree(1,1), regardless of temporal anchor or which barred/unbarred block is chosen. The curvature coefficient contains ordinary links, not Grassmann generators, so it cannot alter these degrees.

Original S2 has a pair of DISTINCT world coframes because of the world epsilon. Therefore its only half-degree types are

`(4,0), (3,1), (1,3), (0,4)`.

There is no T0*T0 channel and hence no(2,2) S2 term. The original S4 determinant has exactly one T0 and three spatial T's, so its only types are `(7,1)` or `(1,7)`. This is valid termwise for all internal labels, directed anchors, both temporal interfaces, all spatial plaquettes and the ORIGINAL full action sum. It does not rely on a selected action-word family, conditional Haar reduction or approximate phase.

For a homogeneous degree62 even half-observable F in the declared algebra A_+, thetaF has degree62 in the other half. Thus thetaF*F leaves(2,2) to reach the full top. Its total remaining degree is4. Identity leaves unsaturated generators, S2 has no(2,2), and S4 or any action product has too much degree. Consequently

`I[exp(g1 S4+g2 S2) theta(F) F]=0`

identically as a RAW polynomial, without assuming reflection invariance of S2 or nonzero normalization. This is conditional on actual homogeneous Grassmann degree62, zero sources/matter terms and the adopted original action; link-polynomial coefficient functions do not change the argument.

For F62 and G58, with thetaF in half1 and G in half0, remaining half degree is(6,2) and total8. The ONLY possible action terms of total8 are g1 S4 and g2^2 S2^2/2. S4 has neither required half type. The only pair of S2 half types summing to(6,2) is `(3,1)+(3,1)`. Therefore the raw mixed entry is EXACTLY the appropriate projection of the FULL `g2^2 S2^2/2!`, with BOTH vertices of the crossing T0*Ti type based in half0. No higher S2, S4, mixed g1g2 or independent same-slice action term can contaminate it. These are positive-degree polynomial saturation identities, not a small-coupling truncation.

If thetaF leaves its only two unsaturated half1 generators at y=(1,r), each surviving T0 must put its half1 generator at y. Original T0 changes time without changing spatial coordinate. Therefore BOTH crossing vertices have the UNIQUE half0 base x=(0,r). They can still use every spatial i and every internal/anchor channel at that base; these must all be retained before any cancellation or chosen link specialization. If other-half holes are distributed across different sites, this same-base conclusion would need modification.

## 2. Full four-world-order reduction: no missing factor2

Original S2 at a base x is equation(2) of `D/ADW_EXACT_AUXILIARY_IDENTITY.md:26–30`:

`(1/4) sum_(kappa,lambda,mu,nu,A,B) epsilon(kappa,lambda,mu,nu) Tr[H_(kappa,lambda) gamma_A gamma_B gamma5] T_mu^A T_nu^B`.

The full original24 world orders and original quarter are also explicit in `D/l1_full_action_reference.py:coefficient` (102–140). For fixed spatial i, let k<l be the complementary pair of spatial axes and epsilon_i=epsilon(k,l,0,i). Set H=H_kl in the CLOSED basepoint ordering. Reversing the plane gives H_lk=H_kl^dagger. All T coefficients are even and commute.

The FOUR world tuples for this unordered coframe/curvature partition are `(k,l,0,i)`, `(k,l,i,0)`, `(l,k,0,i)`, `(l,k,i,0)`. The two coframe orders, after relabeling A/B in one, produce the commutator. The two curvature orders produce H-Hdagger. Their exact sum is

`X_x = sum_(i=1..3,A,B) R_iAB(x) T_0^A(x) T_i^B(x)`,

`R_iAB = epsilon_i/4 Tr[(H_kl-H_kl^dagger) [gamma_A,gamma_B] gamma5]`.

This expression ALREADY includes the two world coframe orders and two plane orientations. There is no additional2 multiplier, derivative tag, opposite-slice weight, shear difference or replacement of the exponential2! factor. Internal A,B are still summed over all ordered pairs; antisymmetry is in the explicitly displayed commutator.

The consumed accepted source `/private/tmp/l1-leading-metric-response-20261105-r1/attempt-2-domain-order-r1/consumed/leading.py:curvature_table` (210–232) independently records precisely `(H-H.H)*[gamma_a,gamma_b]*gamma5`, with H=`u3.H*u2.H*u1*u0`; `assemble` assigns the epsilon and retains the original curvature quarter in its divisor. It is an N4 evaluator and not a new N16 computation, but its untagged local full-world-order coefficient agrees with the manual source reduction. The full reference also makes literal-versus-closed ordering explicit; the old literal coefficient cannot be substituted.

## 3. Compatible spatial link specialization and actual surviving channel

Fix x=(0,r). Specify these INDEPENDENT positive-anchor spatial links:

`U_(x,1)=-I`, `U_(x+e1,1)=I`,

`U_(x,2)=U_(x+e2,2)=I`,

`U_(x,3)=U_(x+e3,3)=I`,

`U_(x+e2,3)=H`, `U_(x+e3,2)=I`,

where `H=gamma0 gamma1 gamma5` and all unrelated links can remain separately specified. None of these anchors/directions conflicts. In particular `(x+e2,3)` is distinct from the TWO coframe-T3 anchors `(x,3),(x+e3,3)` and from the TWO T2 anchors `(x,2),(x+e2,2)`. The all-extended length2 geometry identifies forward/backward endpoints but does not identify these different directions or anchor variables. Temporal V0,V1 are unaffected and remain independent.

Since x-ei=x+ei on the length2 spatial torus, equation(1) shows two identity anchors cancel the forward/backward terms exactly. Thus T2(x)=T3(x)=0 as full coframe polynomials. For z=x+e1, the central link choices give instead

`T1^A(x) = (1/2)[-barpsi_x gamma_A psi_z + barpsi_z gamma_A psi_x]`,

which is nonzero as a polynomial in independent endpoint generators. This is an exact manual substitution retaining the physical coframe quarter, not a matrix evaluation.

The CLOSED plaquette in plane23 is

`H23(x)=U_(x,3)^dagger U_(x+e3,2)^dagger U_(x+e2,3) U_(x,2)=H`.

Other curvature planes may also be affected by the link assignment. They need not vanish: their crossing action terms multiply T2 or T3 at x, which do vanish. Hence X_x reduces exactly to its i=1/plane23 channel at this spatial point; no action channel was discarded before using the proved coframe identities.

### Clifford check of H and R

The ACTUAL Euclidean basis is `D/l1_full_action_reference.py:13–20`: gamma_A^dagger=gamma_A, gamma_A^2=I, anticommutation for distinct A, and gamma5=gamma0 gamma1 gamma2 gamma3=diag(1,1,-1,-1). Therefore

`H=gamma0 gamma1 gamma5=-gamma2 gamma3`, `H^dagger=-H`, `H^2=-I`.

It is a valid Spin(4) element: it is `exp[-(pi/2) gamma2 gamma3]`, an exponential of a real Euclidean bivector, not an arbitrary U4 matrix. It also commutes with gamma5 as required for the chiral blocks. The central -I is likewise in Spin(4). Thus the link specialization stays inside the original compact group.

For i=1,k=2,l=3, epsilon(2,3,0,1)=+1. Using the Clifford trace identity `Tr(gamma0 gamma1 gamma_A gamma_B)=4(-delta_0A delta_1B+delta_0B delta_1A)`, the FULL coefficient reduces to

`R_1,AB=4(-delta_0A delta_1B+delta_0B delta_1A)`.

Consequently `R_1,01=-4`, `R_1,10=+4` and every other internal pair is zero. In the proposal's “R23” notation this means the coefficient belonging to curvature PLANE23, not that coefficients of all other curvature planes vanish separately. At this point

`X_x=-4 T0^0 T1^1 +4 T0^1 T1^0`.

All these trace statements are manual consequences of the displayed Clifford identities; no explicit matrix/CAS calculation was run.

## 4. What remains to make an actual physical witness

The compatible spatial configuration proves the asserted local curvature tensor is nonzero and isolates a nonzero source CHANNEL. It does not alone prove X_x^2, its required hole component, its joint temporal Haar average, or the resulting V6 is nonzero. A nonzero polynomial before integrating temporal links can still have zero mean. Those are precisely the remaining noncancellation steps of the proposed route.

An actual witness still needs: a concrete gauge-invariant homogeneous F62 with the specified scalar-hole dual and the exact theta signs; the complete projected V6 from ALL surviving X_x^2/2 channels, anchors and both temporal links; proof V6 is not identically zero as a spatial-link/exterior coefficient polynomial AFTER the required temporal projection; an actual even gauge-invariant G58 constructed from its correctly conjugated Berezin dual; and an exact mixed-entry/sign identity, with positive AUX coefficient/Haar norm distinguished from physical state positivity. The dual map must respect the original orientation, gauge action and admissible physical algebra. No favorable ambient vector is enough.

If the zero-norm/nonzero-overlap identity is established, it obstructs a positive semidefinite/Hermitian reflection form on the stated full physical algebra wherever the normalized functional exists and the mixed coefficient is nonzero. Full nonzeroZ and a nonempty normalized coupling domain remain separate. At g2=0 the prospective mixed term vanishes by its g2^2 factor, so that boundary must not be silently included. This report chooses no coupling and claims neither a normalized-state obstruction nor a global/Lorentzian/continuum no-go.

## 5. Existing work / duplication boundary

The accepted N16 temporal and physical-image contracts already identify actual raw entries and the need for physical preimages, not ambient negative vectors. The newest notebook introduces degree62/58 only as the new unaccepted candidate. Bounded reads of those actual contracts/reviews and narrow Git message history did not locate an accepted duplicate of this high-degree N16 saturation witness. This is not a proof of historical, mathematical or Lean nonexistence. The older N4 cubic support/state-body results have collapsed-direction premises and are not a duplicate or an N16 input for this argument.

Source findings above support proceeding to the manual projection/noncancellation proof under independent review. They authorize no coefficient evaluation, code/job, matrix control, native proof, slot or publication claim.
