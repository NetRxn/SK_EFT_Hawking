# Original L1 coupling/state/thermal conventions: source-body diligence

Task `L1-original-coupling-state-convention-intake`, parent publication-L1-symbolic-normalization-and-convention-diligence. Packet `l1-original-convention-intake-r1.json` fresh at entry; source `8440c44fe9263d0070002895b5186bca32f4f1a9`. Read newest primary L1FixedControls notebook and the pinned original/current source bodies. This scratch report is the only written artifact. No scientific imports, matrix evaluation, jobs/tests/builds, Git/candidate/notebook/slot changes, manuscript/citation/Visser repair or operator question.

## Conclusion: original effective hypotheses do not yet select a microscopic thermal branch

The inspected owning texts explicitly fix an EFFECTIVE susceptibility/speed-law programme and thermal SK hypotheses. They do not themselves identify those hypotheses with a particular domain of microscopic g1,g2 or an ordinary Gibbs trace of the unchanged finite periodic N16 functional. This is a source-specific missing correspondence, not a global claim that no such theory/state exists. There is useful original information to retain; the correct action now is to continue full normalization SYMBOLICALLY, not choose a favorable domain or ask the operator to invent a missing map.

A later evaluation/physical-state specialization may require a genuine branch decision, but only after scientific diligence has turned the missing map into concrete, evidence-backed alternatives. That decision is not needed for the finite polynomial/common-denominator/good-prime identities currently being derived.

## Pinned bodies and exact conventions

### Original programme and charter

`/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-5z/Post-SK-EFT Research Program Strategy.md`, section4 / heading6a.2 (the intended original GW subprogramme), requires predicting GW speed/dispersion from vestigial susceptibility and making the second-sound identification quantitative. It names existing VestigialSusceptibility, VestigialGravity, SecondOrderSK and Volovik two-fluid inputs. It specifies the observational comparison and a correctness push, not microscopic g1/g2 values, an N16 Hamiltonian, a lattice-temperature map or a periodic trace convention.

`docs/roadmaps/Phase6a_Roadmap.md`, CURRENT charter lines3–12, keeps actual metric operator/source/projector, regulator, normalization, stable domain, physical mode/matter and transport maps OPEN BUILD. It explicitly requires [0.1,10] as a derived result under independently justified conditions and prohibits choosing chi=1 or tiny damping to pass the observation. The historical Wave2/TrackB body (roughly187–245) motivates the identified-mode calculation and original paper25; its historical SHIPPED status does not override the top charter's scientific boundary. Neither body selects a microscopic g1/g2 phase or proves that the finite periodic comparison is a physical thermal trace.

### Original paper25 and current publication snapshot

Original/local body: `papers/paper25_gravitational_waves/paper_draft.tex`, especially “Vestigial-susceptibility identification” and “The leading-order c_GW formula”, lines143–179. It uses `chi_RPA=chi0/(1-gamma_star chi0)`, asserts a natural susceptibility comparison range and transfers a second-sound motivation into `c_GW=c sqrt(chi_vest)`. Even these stronger historical derivation claims supply no explicit map from g1,g2 to chi0/gamma_star/temperature or a canonical microscopic state. The range is not a pair of original action couplings.

Current read-only snapshot: `/private/tmp/l1-publication-convention-body.tex`, pin `/private/tmp/l1-publication-convention-pin.json`: publication branch `codex/publication-l1-checkpoint-20261103`, head `ab097b381aec6658217bb7237c2dc1ba82bbc174`, path `papers/L1/paper_draft.tex`, SHA256ba39d45207c8c100f85a4a0712b33d9490d6c7b268e7534a82ecbf0bac958c4f. Its body lines52–86 explicitly treats spin2 identification and susceptibility-dependent speed as assumptions; lines152–178 says chi0/gamma_star are unevaluated inputs, normalization undetermined and [0.1,10] adopted rather than derived. This is stronger disclosure of the same missing matching, not an additional state prescription. Snapshot custody does not certify the manuscript as scientifically accepted, and no text was edited here.

### Actual RPA/Kubo/KMS Lean declarations

`lean/SKEFTHawking/VestigialSusceptibility.lean`, namespace W6Ext, lines296–379:

- `KuboViscosity` stores zeta and a positivity witness; `kubo_zeta_pos` unpacks that input.
- `chi_RPA` at320 is the ordinary real rational function `chi0/(1-gamma_star*chi0)`.
- `chi_RPA_closed_form` at327 assumes the denominator is nonzero.
- `chi_RPA_sign_stable` at338 assumes chi0>0 AND gamma_star*chi0<1. It does NOT additionally require gamma_star>=0. It proves the modeled resummation positive in that stated effective region; it does not derive a microscopic phase/domain or identify gamma_star with g1 or g2.
- FDT/Kubo sign lemmas assume T>=0 or T>0 and a nonnegative imaginary susceptibility/integrated response. Those variables are effective inputs, not a computed lattice state or T(g1,g2).

`lean/SKEFTHawking/SKDoubling.lean:112–170` defines SKAction and normalization/positivity predicates, then `KMSSymmetry(action,beta)` as a SUPPLIED transform/specification and invariance proposition. It describes beta=1/T. `firstOrderDissipativeAction` at250 takes ordinary transport coefficients and beta; `firstOrder_positivity` at270 requires beta>0 and the coefficient structure's nonnegativity premises. The “normalization” predicate is the SK equal-branch action condition; it is not the unnormalized microscopic Z(g1,g2) being nonzero.

`lean/SKEFTHawking/SecondOrderSK.lean:160–205` builds a1+1D BEC extended-field effective action with two real second-order transport inputs and beta-dependent noise partners, followed by algebraic KMS constraints. Its later `FullSecondOrderKMS` and uniqueness declarations impose specified FDR/coefficient relations and beta>0 hypotheses. No declaration read here constructs a positive density operator/thermal trace for original N16 or determines these coefficients from that action. These are source reads only, with no LSP/elaboration or theorem-absence claim.

The effective condition T>0 thus does not mean “choose Nt=2 and call it positive temperature,” and `gamma_star chi0<1` does not mean “choose g2 positive” or any unproved g1/g2 inequality.

## Primary physical source bodies

### Volovik2601.00639v1: de Sitter thermodynamics, not N16 temperature

Held `/private/tmp/l1-volovik2026-source.txt`, header explicitly arXiv2601.00639v1, January2,2026. SectionsI–II, text38–105, set up the de Sitter two-fluid model: gravitational normal component with stiff equation of state w_n=1, superfluid/dark-energy component w_s=-1, equal densities and opposite pressures in the stated equilibrium background. T=H/pi is the temperature of that de Sitter heat bath; H is its Hubble parameter. The source distinguishes local thermodynamic entropy/temperature from horizon quantities and states it omits the instability/decay toward Minkowski in this discussion.

SectionIII equations(6)–(10), text108–139, uses those thermodynamic relations and the Landau second-sound formula to get s2=c. SectionIV text148–176 discusses possible scalar/helicity0/Goldstone interpretations rather than deriving the ordinary two spin2 graviton identification. These bodies fix model-specific physical content; they provide neither g1/g2, beta in lattice units, an N16 Hamiltonian, nor the equality of the original periodic Berezin partition with the corresponding de Sitter thermal state. Setting beta=pi/H and identifying Nt*a_t with it requires an additional actual background/time/source matching argument, not the temperature formula alone.

### Crossley–Glorioso–Liu1511.03646v3: explicit thermal density matrix premise

Held `/private/tmp/l1-crossley2017-source.txt`, header arXiv1511.03646v3, January27,2017, body sectionI.F “Thermal ensemble and KMS conditions” (the requested thermal subsection; PDF uses letterF), text818–858. Equation(1.60) EXPLICITLY TAKES

`rho0=exp[-beta0(H-mu0 Q)]/Z0`, `Z0=Tr exp[-beta0(H-mu0 Q)]`.

It then derives the KMS relation(1.61), using neutrality of stress/current operators under Q, and quadratic FDT(1.62). It discusses further time-reversal/PT assumptions for the local Z2 relation(1.63)–(1.64). Its abstract separately says the general EFT applies around a general density matrix, with additional local KMS imposed for a thermal density matrix. Thus original thermal SK has a genuine Gibbs-density premise to reproduce. One cannot inherit that premise for N16 merely by using an SK/KMS effective coefficient formula.

In particular, H and Q here are operators on the physical state space. They are not g1/g2, the coframe auxiliary h, a source Jacobian or the nilpotent metricQ. The chemical potential convention is specified in(1.60); our microscopic comparison must identify a conserved charge if invoking it. The source does not set a nonzero chemical potential or conserved charge for the adopted N16 model.

### Diakonov2011: original microscopic finite functional

Held `/private/tmp/l1-diakonov2011-source.txt`, sectionV, equations(23)–(28). Equation(23) with alpha=1/2 fixes the symmetric coframe; (24),(25) fix the determinant and EHC interactions; (26),(27) fix the oriented Berezin and normalized compact Haar integrations. Equation(28), text690–703, has exponent `+g1 sum scosm +g2 sum sEHC+...`, dimensionless couplings and finite-volume well-definedness. Its finite Berezin expansion does not require an ordinary positive Boltzmann exponent for convergence. The body does not impose the claimed effective RPA stability domain as a microscopic g1/g2 restriction, or prove a positive physical Gibbs state for this finite integral. SectionsVI/discussion leave long-loop/infrared/mean-field behavior to further analysis.

Our PERIODIC all-extended N16 time contract is a prospectively fixed finite research comparison, documented in the accepted N16 source identity. The primary's general finite hypercubic integral does not by itself identify that particular finite periodic functional with ordinary Tr exp(-betaH), a de Sitter equilibrium background or the physical zero-source phase. Formal variables g1,g2 may remain symbolic; choosing a real physical subdomain must be declared and justified independently.

### Vergeles distinction retained

The previously read held Vergeles2506.00036v2 body II–IV concerns Minkowski simplicial contour/gauge evolution with an assumed ONB, normalizability, finite generator matrix elements and complete real-eigenvalue basis. VI(6.1) does explicitly extend discussion to composite tetrads, so it must not be dismissed as exclusively independent-tetrad. Neither that extension nor unitary exp(iA) evolution is an ordinary finite-temperature Gibbs/periodic-N16 trace identification. The action/boundary/adjoint/state correspondence remains necessary. No new manuscript repair or source-wide absence claim follows from this distinction.

## What can proceed now; exact later fork if necessary

Proceed with the original signed finite action and full normalization polynomial/common denominator over symbolic g1,g2. Domain statements can have the honest form “for real couplings satisfying the PROVED nonzero fullZ condition”; formal good-prime nonvanishing and a conditional neighborhood bound from a future complete Z32 certificate do not need a physical thermal-state selection. Parameterizing by x=g1/g2² imposes g2!=0 as an algebraic chart condition, not a derived physical phase; handle g2=0 separately in raw polynomial statements. A pureg2 enabling denominator certificate cannot produce literal G, which remains0 under the accepted all-volume parity.

No operator question is required for those mathematical steps. Do not select g1/g2 by positivity of a sampled Gram or fit beta, the source, susceptibility or damping to the observed speed window.

A genuine later physical fork arises ONLY if the original microscopic-to-state/time/adjoint map cannot be derived under the preserved periodic contract and a physical certificate/evaluation requires specialization. The concrete alternatives would be:

1. Construct the state, constrained observable algebra, Hamiltonian/adjoint and ordinary thermal trace correspondence for the EXISTING original action/boundary/source, including a temperature/time-scale and coupling-domain map consistent with CGL/physical matching.
2. Keep the existing functional as finite Euclidean algebraic evidence with source-matched normalization/RP or a scoped negative witness, while explicitly retaining the still-missing ordinary thermal/real-time bridge.
3. If evidence motivates a changed thermal boundary condition, contour, source-selected limit or state preparation, propose the exact physical change and its changed correspondence/controls for a separate operator disposition before adopting it.

These alternatives are not an operator prompt now, nor permission to reduce the original goal. A failure for one fixed reflection/state interpretation is not a global impossibility result. The current symbolic work and whole-physical-image certificate remain valuable independent necessities. Publication ROOT retains original B3/state/mode/matter/transport acceptance, manuscript/citation/Visser repairs, and any eventual evidence-backed physical fork decision.
