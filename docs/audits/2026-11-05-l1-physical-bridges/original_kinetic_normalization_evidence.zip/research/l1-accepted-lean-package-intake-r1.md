# One accepted-construction Lean package: exact signed auxiliary source identity

Recommendation to ROOT: formalize the accepted ORIGINAL finite signed Hermite auxiliary transform with source insertions, rather than another scalar positive-weight/phase-enum lemma or a physical CAR/metric theorem whose dictionary is still unmatched. This is a single coherent bounded mathematical package supporting the actual microscopic source/response critical path. No slot, implementation, substrate absence claim or whole-roadmap delegation is implied.

## Exact accepted input / candidate boundary

Owned source base: codex/l1-common-source-interface-20261105, d95370a95128599ef9dbecb4bd3105b55f0019d4. Accepted source: docs/audits/2026-10-17-publication-substance-construction/ADW_EXACT_AUXILIARY_IDENTITY.md, SHA e74fc4b792d59d19f88917f8f0365a2336583ca0abc5cac1403917b98ebd3cd8. Its header records scoped manual acceptance and independent review SHA75727aa9418997ab8dac30f5c66a789f5fad5c04ffb2d64a8344bbaf7e007103; this is not physical-state/RHMC or publication acceptance.

The already accepted full J/prescribed C2 j extension is N16_TEMPORAL_BOUNDARY_IDENTITY.md, SHA82197710fb69018810f321dff0ef9f14f9556e47a5b8fab6725b26d1b4c58c49, and the original source-contact coefficients are ORIGINAL_GRADED_CONSTRAINT_RELATION.md SHA07054c34ffa7edb9ee141bef0f45a5396047ca14b534563df400119c6f31ce6c. These are accepted inputs from the cumulative original model. Do NOT consume the active, not-yet-accepted kinetic/current result as a hypothesis for this package.

## Mathematical theorem to prove, not assume

For original128-generator exterior algebra and homogeneous degree2 commuting coframes T_i, any product of65 coframes vanishes. At a site there are16 components and
 S_x(X)=g1 det(X)+g2 original_curvature_quadratic(X)+literal_J_quartic_fermion_source(X),
where the degree in commuting coframes is4 or2 (metric source is degree2 in X). A(j) is the prescribed linear coframe mixing. M=64 at V16.

For every sigma>0 construct the actual coefficients
 P_x(X)=[exp(S_x(X)) exp(-sigma^2 sum_i X_i^2/2)]_(total degree<=64)
        =sum_alpha p_alpha X^alpha,
 W_x(h)=sum_alpha p_alpha sigma^(-|alpha|) product_i He_alpha_i(h_i/sigma).

The main theorem is a COEFFICIENTWISE integral identity in the exterior algebra:
 integral_(h in R16, Gaussian_sigma) W_x(h) exp_nil(sum_i h_i T_i)
                                    =exp_nil(S_x(T)).

Here exp_nil and all truncations are explicitly finite polynomial sums with factorial coefficients. Gaussian averaging must be the actual product Gaussian moment functional, proved equal to the coefficient integrals; it cannot be an uninterpreted linear map assumed to satisfy the desired identity. W may be signed/complex. Sigma cancels for every permitted value. No assumption of positive determinant/Pfaffian/bag weight or fitted scalar potential appears.

The first nontrivial proof brick is the finite Hermite coefficient identity
 E[He_a(Z) Z^k]/k! = [x^k](x^a exp(x^2/2))
with explicit factorial/parity values, for all required a,k, tensorized over16 components. This is an identity of actual Gaussian moments; generalizing only the existing moments through degree4 is insufficient for M64. Use polynomial Hermite recurrence or the actual Gaussian integration-by-parts/derivative theorem with integrability/boundary control. This is search-guided design, not a claim about which API compiles.

The original specialization MUST define the coframes from the FOUR ordered hopping terms, BOTH directed temporal anchors and original closed curvature coefficients. Prove the degree65 vanishing from exterior grading/basis support; don't assume it as a free model equivalence or leave the action/coframe map uninstantiated. Pointwise in the actual compact link variables is a valuable bounded endpoint: it avoids pretending an auxiliary covariance proves Haar positivity. Original Haar/Berezin integration can then be transported by a proved finite coefficient linearity statement, with measure/integrability obligations explicit.

## Essential source/observable acceptance

Carry the same identity over the C2 coefficient jet ring R[epsilon,delta]/(epsilon^2,delta^2), retaining the source s_alpha s_beta+s_alphabeta contact and BOTH interface placements when later sewn. This is a finite source-jet identity, not a generic assertion that response is a derivative. Prove multiplication by any original test before coefficient extraction preserves the equality.

Include the signed-weight Gaussian integration-by-parts observable correction from accepted auxiliary Eq11, in its undivided form:
 E[W h_i exp_nil(h.T)]
       =sigma^2 E[(partial_i W+W T_i) exp_nil(h.T)].

This directly prevents the physically incorrect shortcut <T>=<h>/sigma^2 that loses partial_i W. It must not divide by W at its zeros. A formal theorem assuming the source identity or the correction as a hypothesis would not count. Full result acceptance is actual constructed auxiliary equality, source-jet/insertion preservation and this correction for the original coframe specialization; local progress may report a smaller first brick honestly. Physical metric calibration, positivity, dynamics, B3 and controlled limits remain unproved.

## Existing modules and source search evidence

Read actual files at owned d95370a95:
* QuantumNetwork/GaussianMoments.lean imports Gaussian.Real, Variance, Integral.Gamma, Lebesgue.Integral, Group.Integral and GaussianIntegral. Existing `integral_sq_gaussianReal`, `integral_gaussian_weight`, `integral_pow_two_mul_gaussian`, `integral_pow_four_mul_gaussian`, `integral_odd_mul_gaussian` provide analytic examples and base moments, not all required orders. Last owning commit99ba1a11414cf424f66e5478285b64b2275c2bd0.
* QuantumNetwork/GaussianWick.lean imports GaussianMoments plus Integral.Pi, Haar.InnerProductSpace and EuclideanDist. `gaussInt_monomial` is already arbitrary finite-index coordinate factorization. `moment_eq_wval`/wval are degree<=4-specific; do not misuse their beyond4 default as higher moments. History68e774ebc05bd6d397d02869b7cfd63e6f0f7c03 and finite-index generalization52218731d06c84e18559192f6eac95def617ce6c.
* GoltermanShamir.lean imports exterior algebra and proves finite-dimensional substrate. Reuse definitions/API where apt, not its assumptions as a physical state/positivity construction. Its general `FermionicFockSpace` nomenclature does not identify the original physical CAR.
* FermionBag4D.lean/GaugeFermionBag.lean were inspected as potential neighbors. Their positive scalar Boltzmann/product hypotheses and scalar gauge identities do not instantiate the unchanged original multifermion functional or this source identity. They are not sufficient backing for this package. No repair to those modules is commissioned here.
* VestigialSusceptibility.lean imports ADWMechanism and Mathlib and proves scalar bubble/RPA conclusions under assumptions; it does not supply the exact signed auxiliary/source transport theorem. Avoid importing its effective-physics interpretation into the new microscopic identity.

The owned disposable worktree has no .lake/packages/mathlib directory. No repair/cache build is needed for a READ-ONLY recommendation. I searched the existing PRIMARY checkout's actual pinned Mathlib source files instead, without running any backend:
* Mathlib/RingTheory/Polynomial/Hermite/Basic.lean: `Polynomial.hermite` is explicitly PROBABILISTS' Hermite; `hermite_succ`, `coeff_hermite_explicit`, `coeff_hermite_of_odd_add`, `coeff_hermite_of_even_add`, `coeff_hermite` exist in source.
* Mathlib/RingTheory/Polynomial/Hermite/Gaussian.lean: `Polynomial.deriv_gaussian_eq_hermite_mul_gaussian`, `hermite_eq_deriv_gaussian` exist. This file proves derivative relations, not by itself the required moment/integral identity.
* Mathlib/Algebra/MvPolynomial/{Basic,Degrees,Eval}.lean; Mathlib/LinearAlgebra/ExteriorAlgebra/{Basic,Basis,Grading}.lean exist. ExteriorAlgebra/Basis has basis multiplication for intersecting/disjoint supports, suitable for the actual nilpotence proof. Precise import/declaration types must be checked in the admitted LSP lane.

Suggested responsibility is new scientific modules under SKEFTHawking/ADW/ (e.g. HermiteAuxiliary and OriginalAuxiliarySource), reusing existing Gaussian factorization rather than a parallel integration API. Exact file layout is ROOT's implementation choice; no files or import roots were created here.

## Toolchain, candidate pins and verification boundary

Owned lean-toolchain: leanprover/lean4:v4.32.0.
Mathlib81a5d257c8e410db227a6665ed08f64fea08e997.
Physlib c48433678e8fb6306ebcd48453300c8e16058a62.
REPL manifest68a3b3a059787a7db44fb1e6281e4a657efee470 (lakefile v4.32.0).
Do not bump or repair the matched dependencies for this task.

Search evidence: direct rg --files and scoped rg on existing modules/imports/declarations; direct sed source reads; Git path history; manifest/toolchain reads. Applying the Lean4 skill in READ-ONLY discovery mode. The matching exposed wt1 tools explicitly say no active lease/backend; no tool was invoked against it, no slot was acquired and no missing-substrate claim was made. This is source-level recommendation, NOT LSP/type verification, proof completion or build evidence. ROOT's admitted lane must reconcile current source/candidate and use LSP/type/import/history discovery before implementation or declaring a gap. Its primary controller owns slot acquisition/preparation and authoritative builds.

Acceptance: non-tautological exact identity and actual original specialization/source insertion/correction; independent statement/physics review, kernel-pure proofs (no sorry, new axioms, native_decide or maxHeartbeats), relevant project gates and ordinary checkpoint integration under ROOT. No physical state/metric/B3 closure inferred. If capacity or the physical critical path favors finishing the unmatched physical dictionary first, this is a useful bounded enabling stream, not a reason to delay that dictionary for a separate speculative formalization program.
