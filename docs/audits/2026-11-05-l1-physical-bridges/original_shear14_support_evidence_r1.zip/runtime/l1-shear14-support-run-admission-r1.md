# Publication ROOT admission — shear14 support inventory R1

Trusted source: Codex message from publication ROOT chat01a13f67-0907-71e2-9a64-64d2f2420e2f,2026-11-19local. User has authorized cross-chat coordination; ROOT retains local computation admission.

Exact received text:
"I verified the frozen archive, program and spec hashes and confirmed the output path was absent. Proceed with the one bounded, support-only command you proposed, using those exact pins and the 120-second cooperative refusal. Record elapsed time, peak memory if available, output hash, counts and any refusal, then obtain independent actual-output acceptance. This admission covers the occupation inventory only. Keep Lean slots and any Haar, tensor or coefficient run outside this admission. Send the accepted receipt or concrete refusal for publication intake."

Command: python3 /private/tmp/l1-shear14-input-package-r1/prepare_support.py --spec /private/tmp/l1-shear14-input-package-r1/INPUT_SPEC.json --spec-sha256 644ae5d93b24ccffba2e6e49d9e5fbc3150c7b4da13ce0006529ba32041f1a1b --output /private/tmp/l1-shear14-support-output-r1.json --deadline-seconds120

Actual argv uses separate --deadline-seconds and120 arguments. A passive /usr/bin/time -l wrapper may record this command's own resource receipt; it grants no new scientific action or shared-process control. Only ONE scientific execution is admitted. Independent reviewers may read the actual output and receipts; no replay or Haar/tensor/coefficient/Lean run is inferred.
