# Four-site full cubic metric numerator and quartic partition support

Read-only intake for `L1-fulltensor-cubic-support-codebase-intake`, parent publication-L1-leading-metric-response. Packet `l1-leading-metric-cubic-intake-r1.json` checked fresh at entry; source `e4a9bc95d14d2c807bc2bf71e3a08ce204d7b1d4`. The sole notebook writer remains Executor01a1ac65. This worker owns this scratch report only. No project/scientific import, coefficient calculation, tensor contraction, compilation, scientific job, slot/process operation, candidate edit or Git mutation occurred. One standalone standard-library support enumeration was run, as authorized; it computes degrees and binary center parities only.

D below means `docs/audits/2026-10-17-publication-substance-construction/`. Current source helpers are in `/private/tmp/l1-leading-metric-response-20261105-r1/leading.py`; they were read, not imported.

## Result

For the actual periodic2x2x1x1 four-site regulator, original fixed Haar/Berezin measure, closed action `g1 S4+g2 S2`, and each of the ten literal local components `Q_mu,nu(0)=sum_a T_mu^a T_nu^a` (off-diagonal counted once), the raw coefficient

`I[Q_mu,nu S4^3 S2]/3!`

is exactly zero by support/center parity. Similarly `I[S4^4]/4!` is zero. These statements hold for every actual source anchor and every determinant/S2 label, with no favorable signs, couplings, projections or coefficient values chosen. There are degree-compatible cubic words for eight components, so site degree alone is NOT the full argument. No counterexample survives the collapsed-link parity test.

Combining these identities with the already accepted degree/Pin rule gives exact polynomial truncations at this regulator:

`q_mu,nu(x)=c_mu,nu x`, `z(x)=Z8+z2 x^2`, `x=g1/g2^2`,

where `c=I[Q S4 S2^5]/5!`, `z2=I[S4^2 S2^4]/(2!4!)`, and `Z8=1252309350145403/2123366400` is the accepted FULL pure-g2 denominator. Neither c nor z2 is computed here. Where g2!=0 and the FULL denominator is nonzero,

`G_mu,nu = (g1/g2^3) c_mu,nu / (Z8+z2 g1^2/g2^4)`.

This is an exact finite polynomial/rational form, rather than a claimed nonzero body or a determined physical coupling domain. No claim that z2 is nonzero, real, positive or known is required. Raw coefficients remain meaningful without division; normalization does not exist at zeros of Z.

## Actual definitions and the center-parity premise

`D/l1_interacting_support.py:6–34` fixes sites0,1,2,3, axes0,1,2,3 and `forward(x,d)=x^(1<<d)` for d<2, x otherwise. A source T term for extended d has endpoints x and `x XOR (1<<d)`, with independent anchor x or that neighbor. A collapsed T term for d=2,3 has endpoints(x,x) and the unique selflink(x,d). In particular the actual code is `x ^ (1 << d)`, not exponentiation. `link(x,d)=1<<(4*x+d)` names an independent geometric link's binary parity charge. `action_terms()` takes the plaquette parity XOR the two complementary coframe parities. This is the actual52-label S2 support, not a continuum approximation.

For clarity: under multiplication of one full Spin(4) link by its central element(-I_L,-I_R), both U and Udagger change sign, normalized Haar is invariant, and every occurrence is linear in that link's quaternion coordinates. A product with an odd number of occurrences of this independent link therefore integrates to zero. This changes the integration variable of one link; it need not be an invariance of the full action. The world/basepoint ordering of a closed plaquette affects matrix amplitudes but not this occurrence parity. The new `leading.py:assemble` records all four plaquette occurrences separately, while its `curvature_table` forms the closed product and inverse difference; both have identical occurrence parity.

The physical collapsed coframe is not zero: `D/l1_equal_time_shared_quadratic_pair.py:fixed_frame` and `leading.py:frame_table` use `gamma*(Ud-U)+(Ud-U)*gamma`, which is odd under that selflink center flip. The argument does not silently drop collapsed directions or replace their matrices with a continuum derivative.

`D/l1_mixed_g1_support.py:12–20` constructs every S4 anchor label by selecting one T in each of the four axes. There are16 labels: four centers with four extended anchor choices each. Actual epsilon assembly is in `D/l1_mixed_g1_determinant_tensor.cpp:determinant` and `leading.py:assemble` (270–276): one coframe in EACH world axis, internal epsilon sum. Every term has the same site degrees and link parity for its fixed label.

## Proof of the full cubic zero

Each S4 term centered at x has site degree6 at x and degree1 at each extended neighbor x XOR1 and x XOR2. The degree6 consists of two degrees from each collapsed T2/T3 and one from each of T0/T1. Changing an extended anchor never changes these endpoint degrees. A repeated S4 center supplies at least12 degrees at that site and is identically zero in an algebra with only8 generators there, before any Q/S2 multiplication. Therefore every potentially surviving cubic uses three DISTINCT centers.

At center x, its T2 and T3 each contribute one odd collapsed selflink, (x,2) and(x,3). Its other two T factors use extended links. Thus three distinct centers produce SIX distinct odd collapsed selflinks. There is no cancellation between different centers' selflinks.

Each actual source Q has two T factors, so it changes the parity of at most TWO collapsed selflinks, independently of its anchors and internal indices. More precisely:

| Component type | Maximum odd collapsed charges from Q |
| --- | ---: |
| 00,01,11 | 0 |
| 02,03,12,13 | 1 |
| 22,33 | 0 (same collapsed selflink occurs twice) |
| 23 | 2 |

The actual S2 plane cases have at most THREE odd collapsed charges:

| Curvature plane k,l | Odd collapsed charges |
| --- | ---: |
| 0,1 | 2: complementary coframes in axes2,3 at the base |
| One extended and one collapsed axis | 3: two distinct collapsed plaquette selflinks at adjacent extended endpoints, plus the other collapsed coframe at the base |
| 2,3 | 0: each collapsed plaquette link occurs twice; complementary coframes are extended |

This follows directly from `action_terms()`'s four plaquette links and complementary `t_terms`, including all anchor choices. Reversing/antisymmetrizing the plaquette leaves this count unchanged. Q and one S2 together can change at most2+3=5 collapsed parity bits. They cannot cancel a six-bit odd pattern. Consequently at least one independent Haar link has an odd integrand, and every candidate cubic word has zero integral. No calculation of its Gaussian coefficients or integration signs is necessary. The bound is deliberately uniform; actual components often have a stronger deficit.

## Proof of the quartic partition zero

Four S4 factors again require distinct centers because repeated center degree>=12 vanishes. All four sites are then determinant centers. Their collapsed T2/T3 factors create EIGHT distinct odd selflinks, each occurring exactly once. There is no Q or S2 in this degree32 term to balance even one of them. Each degree-compatible word has zero Haar integral. This establishes the quartic g1 coefficient's vanishing; it does not establish a value or sign for the quadratic coefficient.

## Independent standard-library support enumeration

A standalone Python3 heredoc reconstructed exactly the displayed definitions with `Counter`, `itertools.product`, `combinations`, `combinations_with_replacement`, and `json`. It imported NO repository module and evaluated NO matrix, Grassmann coefficient or contraction. Its signature for endpoint list E and occurrence list L was `(XOR_(x,d in L) 1<<(4*x+d), tuple(Counter(E)[x] for x in range(4)))`. It generated:

- all16 S4 labels by crossing the actual t_terms in four directions;
- all52 S2 labels with the actual four plaquette occurrences and complementary coframes;
- all23 ordered source-anchor products across the ten symmetric Q components (anchors for the two factors are independent, even for a repeated axis);
- every unordered S4 triple from those16 labels (816 before pruning), then every source-anchor product and S2 label; exact site degree32/saturation and XOR parity were checked;
- every unordered S4 quadruple (3876 before pruning), checking site saturation and link parity.

Observed output:

| Q | Anchor products | Cubic site-saturation candidates | Collapsed-parity survivors | Full-link parity survivors |
| --- | ---: | ---: | ---: | ---: |
| 00 | 4 | 0 | 0 | 0 |
| 01 | 4 | 256 | 0 | 0 |
| 02 | 2 | 512 | 0 | 0 |
| 03 | 2 | 512 | 0 | 0 |
| 11 | 4 | 0 | 0 | 0 |
| 12 | 2 | 512 | 0 | 0 |
| 13 | 2 | 512 | 0 | 0 |
| 22 | 1 | 256 | 0 | 0 |
| 23 | 1 | 256 | 0 | 0 |
| 33 | 1 | 256 | 0 | 0 |

For every site-degree-compatible determinant triple the script asserted exactly three centers and SIX odd collapsed bits. The maximum odd collapsed S2 count was3. Quartic partition:256 site-saturating determinant multisets, zero full-link-parity survivors, with assertions of four distinct centers and EIGHT odd collapsed bits for all256. Process exited0. These are support counts, never coefficient/nonzero-amplitude counts. Multiset multiplicities and internal coefficients cannot rescue a term individually zero under a Haar change of variable; no factorial value was needed for these zeros.

## Existing results and nonduplication

`D/L1_RETARDED_SPECTRAL_INTERFACE.md:1710–1731` and history `e83800bc6`, `2bf362444` already establish a cubic zero for the SELECTED mixed composite/dressed observable. `D/l1_mixed_g1_support.py:cubic_support` explicitly filters the lone S2 label by nonzero `tags()` (opposite slice/mixed plane) and uses the collapsed diagonal/shear target `(4,8,8,8)`. The additional site-degree proof in `2bf362444` excludes that tagged S2 because of its allowed center. This argument does not cover arbitrary untagged S2: the new degree-only counts for Q22 are256, not zero. The full cubic conclusion agrees, but needs the collapsed-link argument above to extend to all ten Qs. Do not reuse the older tagged support count as the new census.

The parity sections at spectral-interface312–320 and the accepted `COLLECTIVE_BODY_PARITY.md` give possible numerator degrees1,3 and possible partition degrees0,2,4. They are necessary degree/Pin bounds, not prior proof that degree3 or4 is nonzero. Current `LEADING_METRIC_RESPONSE_DESIGN.md:191–194` retains d_i and z4 as conservative possible coefficients; the present argument, after independent review, can simplify them to0 without changing the target numerator calculation. Bounded text/path/history reads did not locate a previously accepted fullten-component cubic or S4-fourth collapsed-link proof. This is not a proof of historical or formal-substrate nonexistence.

## Consequence of accepted empty leading00 support

The accepted leading SOURCE census is the full untagged `leading.py:census_all` (311–365), crossing the actual two source t_terms, all16 determinant labels, and all five-S2 multisets, with an independent ordered-count check. `docs/audits/2026-11-05-l1-physical-bridges/LEADING_METRIC_ATTEMPT1_DATA_REVIEW.md:28–34` records the complete necessary-support counts `[0,32,0,0,0,0,0,192,64,192]` and accepts00's completed empty-roster diagnostic. The notebook reports the second attempt reproducing that empty00 support. A failed contraction is not being treated as zero.

Taking that accepted census completeness as premise gives c00=0 (also c11=0 and the recorded other empty components). Together with the full cubic zero, the FULL local raw00 metric numerator is identically0 for every g1,g2 on this four-site uncoupled action. Thus G00=0 wherever the full normalized expectation exists. No unknown higher-order numerator term can restore it: Pin/saturation permit only degrees1 and3, now both zero.

A real Euclidean strictly positive-definite matrix must have G00>0, so such a normalized tensor cannot be Euclidean SPD in the declared coordinate basis. This is a finite-regulator obstruction to that specific Euclidean body property, not a Lorentzian degeneracy theorem. A symmetric matrix can have zero diagonal and nonzero off-diagonal entry (for example the2x2 block[[0,b],[b,0]] is nondegenerate and indefinite if b!=0). Nothing here proves G01 vanishes, fixes its coefficient, or supplies Lorentzian physical reconstruction. Nor may ordinary expectation-value positivity be assumed for this signed/complex Berezin functional. The result does not assert the full tensor is positive semidefinite or infer an entire zero row from G00=0.

The collapsed-link counting relies on axes2,3 having length1 and therefore does NOT transfer to the all-extended2^4 geometry, general N, thermodynamic/source-selected phases, matter determinant backreaction or another action/regulator. Full tensor q1 contractions, z2, physical matching, nonzero-domain analysis, native Lean admission and publication closure remain open. Independent mathematical and physics review is required before treating this intake as accepted scientific construction.
