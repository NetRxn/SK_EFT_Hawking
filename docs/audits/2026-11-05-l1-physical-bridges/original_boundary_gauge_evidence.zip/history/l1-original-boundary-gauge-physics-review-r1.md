# Independent physics/source review — original boundary and gauge reduction R1

Verdict: **ACCEPT, scoped manual result only.** No necessary correction identified.

Reviewed candidate: `/private/tmp/l1-original-boundary-gauge-r1.md`.
SHA256: `ceaed166e56e11e5a943bb6ef8528171bd4a42cc2d13f7050921260a03750461`.
Managed checkout head recorded by the packet: `d421925e2552a28b4744a4eccda2262110b82b69`.

The primary continuity packet `l1-original-boundary-gauge-physics-review-r1.json` was checked before substantive review and checked again immediately before this report. Both checks returned `fresh: true`, `changed: []`. The final check expressly grants no execution or completion authority. I read the assigned notebook, roadmap/authority material, frozen brief and its two pre-work approvals, accepted transfer/source construction, original gauge/coframe material, and the candidate. The notebook records both brief approvals before derivation. This review uses static reading and manual algebra only; no scientific evaluator, matrix/Haar/exterior calculation, test, build, runtime, controller, slot or Git operation was performed.

## Source support and exact boundary compression

The endpoint law agrees with Diakonov V, equations (20)–(22): spinors transform at their vertices and an oriented link transforms with the target action on the left and source inverse on the right. The symmetric original coframe in equation (23), its forward plaquette support, and the accepted full-action transfer construction support the candidate’s more precise weight dependence

`w_t = w_t(X_a, X_b, X_c; v_a, v_b)`.

In particular, the outgoing temporal coordinate `v_c` of the new output slice is absent. The temporal coframe uses the incoming and outgoing links at the middle slice; a time-space plaquette uses the middle-slice temporal anchors and spatial links on the adjacent slice. A prescribed world-frame source changes coefficients and contacts, without introducing an additional temporal endpoint. This conclusion applies to all the retained source derivative vertices; it is not a restriction to spatial metric insertions.

The retained boundary `(X_a, X_b, v_a)` contains both endpoint fields and their temporal connector. The auxiliary embedding `E` as functions constant in the unused output temporal coordinate is isometric for normalized compact Haar measure, and `P_out = EE*` is an auxiliary orthogonal range projection. Crucially, the candidate uses `P_out T = T`; it does not assert the generally unjustified right identity `T P_out = T`. Thus `TE = EL` and the two-step compression follow without deleting dependence on the temporal coordinate used by the input weight.

The reduced two-step kernel integrates the intermediate `v_b` jointly through the product of the two original weights. It does not independently average each weight. On closing the trace, the 56 boundary links comprise two sets of 24 spatial anchors and eight retained temporal connectors; the eight intermediate connectors supply the other temporal interface. This retains all 64 original anchors and both interfaces of the two-slice periodic regulator. The accepted Berezin ordering and parity grading remain in the transfer and supertrace. Commutation of the grading with `E`, together with the left range identity for the closed product, supports the stated supertrace compression. The ordinary-trace comparison remains the earlier comparison closure, not a newly selected physical boundary condition.

The same argument applies to full two-step source vertices and their contact derivatives. Spatial pair multipliers commute with the unused-coordinate projection; crossing insertions remain source vertices rather than being replaced by spatial multiplication. Therefore this reduction preserves the original source traces, including the crossing and contact terms.

## Gauge laws and the meaning of the invariant space

The connector transformation `v_a → g_b v_a g_a†` is essential and is retained. Left and right endpoint pullbacks commute on a connector. Compact Haar invariance and the finite Grassmann coefficient representation make these unitary auxiliary actions; preservation of the top form supports the changes of variables used in the Ward identities.

The three node roles are correctly distinguished. Averaging the discarded old node gives `L P_1 = L`; averaging the newly introduced node gives `P_2 L = L`; covariance at the carried node gives `P_1 L = L P_2`. These are not interchangeable one-step statements. In particular, the candidate does not assume that the entire one-step range is invariant under both boundary groups.

For `Π = P_1 P_2`, these identities imply `ΠL = LΠ = LP_2`. Applied to a complete two-step product, they imply support on `Π` from both sides: the new-node invariance of the earlier factor and old-node averaging of the later factor remove the intervening projectors. This reasoning applies to the full gauge-invariant source derivative weights as well as the zero-source weight. Consequently restricting a closed two-step trace to this auxiliary invariant space does not select a favorable sector or discard an original gauge-invariant contribution.

The source claims remain kinematic. Compact gauge invariance is not a construction of the full gravitational constraint space, a diffeomorphism or Hamiltonian constraint solution, or a physical positive projector. Reusing the existing Reynolds/image construction is appropriate; there is no claim to have newly established its prior source identities.

## Witnesses, physical scope and authorization

The original gauge-invariant `F` and `G` depend on spatial links and fermions and are independent of the unused outgoing connector. They survive the `E` compression and lie in the compact gauge-invariant auxiliary space. Their corresponding invariant pair multipliers commute with the averaging projections. The candidate therefore preserves their original full-action pairings, including the previously established zero diagonal and nonzero mixed polynomial. This is preservation of that earlier obstruction on its stated algebra; it is not a new conclusion about a physical adjoint, metric-only observable algebra, or every possible physical construction.

The reduced expression `D_raw,g = Γ L_1 L_0` has the original trace `Z`. Division by a nonzero `Z` gives an auxiliary trace-one representation, but neither Hermiticity nor positive semidefiniteness follows. The candidate does not infer a Gibbs state, a physical density operator, a new CAR dictionary, or a physical source/product/adjoint correspondence. No normalization value or nonempty normalized parameter domain is newly certified.

The result stays within the dual-approved manual brief. Full normalization, the original physical state and source correspondence, continuum/limit control, `c0`, the independently owned N4 work, B3, matter, tensor, light-cone and transport requirements remain open. ROOT retains ordinary L1 and publication readiness ownership. No original goal is cancelled or reduced by this acceptance.

This acceptance authorizes no scientific execution. A future executable producer requires its own exact independently reviewed source/input/command/control/cap/evidence proposal and fresh exact controller canary and resource admission before execution. None is supplied or granted by this report.
