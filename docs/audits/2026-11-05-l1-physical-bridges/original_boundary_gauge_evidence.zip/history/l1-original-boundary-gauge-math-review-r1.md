# Independent mathematics result review: original boundary/gauge construction r1

**ACCEPT the actual manual boundary-coordinate compression, local compact-gauge Ward laws and complete trace/source/witness preservation. No necessary mathematical correction found.** This constructs a kinematic gauge boundary representation. It supplies neither all gravitational constraints nor a physical adjoint, positive state, nonzero partition or positivity repair.

Frozen candidate `/private/tmp/l1-original-boundary-gauge-r1.md` SHA256 **ceaed166e56e11e5a943bb6ef8528171bd4a42cc2d13f7050921260a03750461**, independently confirmed using stdlib pathlib/hashlib. Parent source d421925e2552a28b4744a4eccda2262110b82b69 is unchanged. Only this report is written.

## Exact unused-coordinate support and isometry

The original symmetric coframe at base layer b uses fermions in a,b,c and temporal anchors v_a,v_b. A temporal curvature plaquette at b uses v_b and spatial links b,c; spatial curvature uses only b. None uses v_c. Linear world-frame sources combine these SAME coframes, and literal Q is polynomial in them. Thus the full positive-degree exponent, its finite exponential and all prescribed first/mixed-second J/j derivatives are independent of v_c. This is a source-level support argument over the entire original action including S4, not a statement inferred from its zero-source trace.

B is the original pair auxiliary space with64 link anchors and128 exterior generators. H keeps both spatial/fermion slices and the internal temporal connector, giving56 link anchors and the SAME128 exterior generators. Because omitted-link Haar is normalized, adding a constant v_b coefficient defines an isometry E. Its adjoint integrates only v_b, so E*E=I and P_out=EE* is the conditional-Haar orthogonal projector. It acts trivially on exterior parity.

The output of T_t is independent of v_c, giving P_out T_t=T_t. Hence T_t E=E L_t for L_t=E*T_tE, with the displayed formula integrating spatial a links and v_a and extracting the a top. An arbitrary input can depend on v_b, which the transfer uses as an output connector; T_t P_out=T_t does NOT follow and is not asserted. The same LEFT range identity holds for each derivative vertex because its exact weight has the same unused coordinate.

## Two-step kernel and trace preservation

Composition gives L1L0=E*T1 P_out T0E=E*KE using only P_out T0=T0. The intermediate connector v_b belongs to BOTH weights and is therefore integrated jointly in their product. No Haar factor is replaced by independent occurrence moments or removed. Polynomial finite-exterior expansion and compact-coordinate separation retain the accepted finite-rank argument.

In the periodic trace, boundary data integrate the two sets of24 spatial links and8 v_a links, with the additional8 jointly integrated v_b links in the kernel. Identifying X_c=X_a,X_d=X_b,v_c=v_a thus recovers exactly64 original physical anchors and both temporal interfaces. There are no independent duplicate temporal endpoints after gluing.

For finite-rank K, P_out K=K. Therefore Tr_B(Gamma K)=Tr_B(EE* Gamma K)=Tr_H(E*Gamma KE)=Tr_H(Gamma_H E*KE), since E preserves parity. This proves the supertrace equality without a right-range assumption. The ordinary trace proof is the same without Gamma, preserving the compared AP closure. No new Grassmann integration is introduced by the bosonic-coordinate isometry: the accepted even128-generator complement signs and positive exchange of64-generator blocks remain exactly the original signs.

For M_O with coefficients depending only on the spatial link/Grassmann pair data, M_O E=E M_O^red and it commutes with P_out. The same cyclic argument gives Str_B(KM_O)=Str_H[(L1L0)M_O^red]. This includes spatial Q multipliers and old full-half-algebra reflection tests. Each product of two original source vertices has the left-range property; the full first/mixed-second trace derivatives are sums of these products. Thus all original contacts and both cross-layer terms survive, not only Z at zero sources. Crossing temporal metric terms remain kernel vertices and joint connector integrations rather than being refactored as half-local multipliers.

## Endpoint gauge representations and the three distinct laws

The actual Diakonov endpoint law is psi_x->g_x psi_x, barpsi_x->barpsi_x g_xdagger, U_xmu->g_(x+mu) U_xmu g_xdagger. Applied to the retained internal connector, v_a->g_b v_a g_adagger. Both endpoint groups are represented. Their right/left actions on the connector commute, as do their actions on the disjoint slice data.

The induced pullbacks R1,R2 are unitary: compact Haar is invariant under left/right translations, spatial-link endpoint actions preserve its product measure, and the Dirac/barred-dual actions induce unitary exterior representations. Their determinants are1 and preserve the oriented Berezin top. Normalized compact averages P1,P2 are therefore commuting orthogonal projectors. Their product Pi is the mandated local compact-gauge invariant projector on this auxiliary boundary, not a physically selected positive sector.

I checked the node-by-node transfer reasoning:

- Discarded node a transforms only integrated spatial/fermion a data and the a endpoint of integrated v_a. Changing those integration variables, with the invariant weight and determinant-one top, yields L R1(g)=L and thus L P1=L.
- New node c transforms output spatial/fermion c data and the c endpoint of the output connector v_b. The input has no c variable. Full weight invariance therefore gives R2(g)L=L and hence P2L=L.
- Carried node b is output FIRST and input SECOND. Simultaneously transforming X_b and the appropriate endpoints of v_a,v_b leaves the full weight invariant. Changing integrated v_a transports its left endpoint action into the input function, giving R1(g)L=L R2(g), and hence P1L=L P2.

No independent gauge transformation of an omitted dangling endpoint was assumed. Every prescribed J/j term is a gauge scalar under the same original node action; its derivative weights obey the same changes of variables. Therefore all three laws apply to every source vertex, not merely the unsourced transfer.

## Two-step Gauss support and traces on H_g

The laws imply Pi L=P1P2L=P1L=L P2 and L Pi=L P1P2=L P2. Hence Pi commutes with L, though L need not itself have wholly invariant range. For ANY two such transfer/source vertices A1,A0,

Pi A1A0=A1P2A0=A1A0,
A1A0Pi=A1A0P2=A1P1A0=A1A0.

Thus the two-step product already equals Pi(A1A0)Pi. Taking its trace or supertrace on H_g=Pi H changes no value. Gamma commutes with Pi because the original gauge action preserves exterior parity. All derivative-product terms share the same support.

Gauge-invariant spatial multiplication commutes with the endpoint actions/Pi. Such insertion products likewise remain Pi supported on both sides with their original traces. This is not a multiplicative quotient of all noninvariant polynomials, nor a solution of additional diffeomorphism/Hamiltonian constraints.

## Existing invariant witnesses and scientific scope

The accepted F62/G58 are nonzero gauge-invariant spatial-link/fermion polynomials. Embedding either into either boundary slice adds no connector dependence. Each endpoint gauge action fixes it, so Pi fixes it; E simply adds a constant unused-link coordinate. Applying the invariant multiplier to the constant invariant vector yields the same nonzero polynomial. Neither coordinate elimination nor the Gauss projector removes it.

For O=theta(F)F or theta(F)G the exact trace compression applies, and O commutes with Pi. Therefore the original zero diagonal and nonzero g2²a full mixed entry are preserved. No negative direction or original pairing is silently lost. The construction cannot turn the already obstructed full reflection form into a positive form.

The result provides exact Z(J,j)=Str_Hg[(L1L0)|Hg] and the raw trace object D_raw,g=Gamma(L1L0)|Hg. Where fullZ!=0, its algebraic normalization has trace1 and the preserved insertion identities. Hermiticity, PSD, a physical metric adjoint/product or a positive state do not follow. The auxiliary coefficient norm and compact gauge constraint do not solve the original physical reconstruction by themselves. No CAR/contact prescription from the one-mode control is imported.

FullZ/c0 nonvanishing, N4 full tensor, original B3 normalization/range, physical matter/tensor/light and causal transport remain OPEN and owned. The AP trace is only the unchanged comparison. No action/source/boundary/coupling/state or model is selected for positivity; no universal original-theory/continuum no-go is claimed. ROOT retains all ordinary L1 readiness, consumer/manuscript/claims/repairs/reviews/gates/integration and operator disposition. Manual result acceptance is separate from native/kernel/full-wave, canonical publication and human acceptance.

## Approved brief adherence and actual actions

The primary notebook explicitly records BOTH written architecture/process and original-source APPROVE reports read/accepted with fresh checks BEFORE candidate derivation. I read that entry, the separate source brief review and the frozen approved brief context. This result stays within its manual boundary/source/gauge/intertwining/trace/witness target and supplies no new evaluator, ledger, controller or machinery. Brief approval was not used as result certification. This independent result review supplies only the mathematical acceptance above.

No executable producer, command/caps/canary proposal or runtime admission is supplied. Future implementation/source-data execution still requires its own exact reviewed producer/source/input/command/control/evidence/resource contract plus fresh exact controller canary/resource admission BEFORE execution. This report grants none.

FIRST action: python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/l1-original-boundary-gauge-math-review-r1.json from /Users/johnroehm/.codex/worktrees/l1-coupled-fixed-controls/.publication-l1-checkpoint-20261103. Result fresh:true, changed:[]. Repeated the SAME check immediately before writing this report, again fresh:true, changed:[].

Other actual commands were read-only cat/sed/tail for full candidate/packet, designated primary notebook, roadmap/authorities, original transfer/action/gauge-source excerpts and brief-source review, plus stdlib pathlib/hashlib candidate digest. All algebra above was MANUAL. No implementation/evaluator/CAS/matrix/Haar/exterior script, scientific data/control/test/build/job/Lean/LSP/slot/controller/canary/resource probe, Git/process/harness/configuration action or candidate/source/notebook/repository edit occurred. Only this external report was written.
