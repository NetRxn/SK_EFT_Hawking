# Original transfer boundary space and local gauge constraint

Manual construction under the prospectively approved brief SHA256
8da3af1cdfc6a652a7f507436e8443b6459b1c911baab874e286900b6c068863.
Independent architecture/process and original-source written APPROVE reports
were read and accepted, with fresh checks, BEFORE this candidate derivation.
This is not source-data execution. No producer, controller canary, resource
admission, scientific evaluator, CAS/Haar test, build or native/slot job exists
or is granted. Separate independent mathematical/physics result review is owed.

## 1. Reuse the original operators and their actual support

Use the exact d421 original-action/source construction975ad00d and its
independent reviews. Its pair Hilbert space B contains full layers q_a,q_b:

    q_t=(X_t,v_t),
    X_t=(24 spatial Spin(4) anchors,64 Grassmann generators),
    v_t=(8 outgoing temporal Spin(4) anchors).

The full transfer and periodic trace are

    (T_t Phi)(b,c)=I_a integral Haar_a w_t(a,b,c) Phi(a,b),
    K=T1 T0,        Z(J,j)=Str_B K=Tr_B(Gamma K).

Gamma is fixed exterior parity, and the positive coefficient/Haar norm is
auxiliary. No physical state or adjoint is inherited from that norm.

More precisely than three-slice locality, the ORIGINAL weight has support

    w_t=w_t(X_a,X_b,X_c;v_a,v_b),

and DOES NOT depend on v_c. Temporal coframes at base b use v_a,v_b and
fermions a,b,c. Temporal plaquettes at b use v_b and spatial links b,c,
never v_c. Spatial terms are at b. Literal Q and prescribed world-frame
sources mix these coframes but add no link endpoint. Thus this statement
holds for the full source-dependent weight, including S4, and every first/
mixed-second source vertex. No term is removed for its sign or cost.

## 2. Boundary coordinate reduction derived from transfer range

Define the smaller AUXILIARY boundary Hilbert space H from

    z_ab=(X_a,X_b,v_a),
    H=L2(Spin(4)^56, normalized Haar) tensor Lambda(C^128).

The internal temporal connector v_a remains. Define the isometry E:H->B
by making a function independent of the unused outgoing v_b. Its adjoint
E* is conditional normalized Haar integration over v_b. Hence P_out=E E*
is the orthogonal expectation on that coordinate and E*E=1. This is fixed
by an unused transfer coordinate, not a chosen physical positive sector.

Since T_t outputs no v_c dependence, EXACTLY

    P_out T_t=T_t,
    L_t=E* T_t E,          T_t E=E L_t.                       (range)

The same holds with T_t replaced by each original source derivative vertex.
Explicitly, with v_b now the connector in the OUTPUT pair,

    (L_t phi)(X_b,X_c,v_b)
       =I_a integral dHaar(u_a^spatial) dHaar(v_a)
           w_t(X_a,X_b,X_c;v_a,v_b) phi(X_a,X_b,v_a).          (L)

There is NO assertion T_t P_out=T_t on arbitrary B wavefunctions. An input
may depend on v_b, which is a used connector in the output. The valid range
identity is the LEFT identity above; it suffices for the construction.

For two steps,

    L1 L0=E* T1 P_out T0 E=E* K E.                            (compress)

Its kernel from z_ab to z_cd is the full polynomial

    k_red=integral dHaar(v_b)
       w1(X_b,X_c,X_d;v_b,v_c) w0(X_a,X_b,X_c;v_a,v_b).        (joint)

The intermediate v_b must be integrated JOINTLY in both weights; no
independent-moment factorization is made. The kernel is finite rank by the
accepted polynomial separation argument. All original links remain: a
periodic trace identifies X_c=X_a, X_d=X_b, v_c=v_a and integrates the56
boundary link coordinates PLUS the8 intermediate connectors, recovering
the SAME64 original anchors. Both periodic temporal interfaces survive.

E commutes with exterior parity. For finite-rank K with P_out K=K, cyclicity
of the trace gives

    Str_B K=Str_H(E* K E)=Str_H(L1 L0).                       (trace)

The ordinary trace is preserved as well, so the accepted AP comparison
closure is unchanged; no physical boundary is selected. Every product of two
source vertices satisfies the same range argument. Thus the COMPLETE
functional and its first/mixed-second source jets, including all contacts,
have the same reduced trace, not just the zero-source normalization.

For a bounded pair multiplication O depending only on spatial links and
Grassmann fields, P_out commutes with M_O and M_O E=E M_O^red. Therefore
Str_B(K M_O)=Str_H[(L1 L0) M_O^red]. This includes the original spatial
metric insertions and every old full-half-algebra reflection test
O=theta(F)G. Crossing temporal sources instead use their unchanged vertex
products in (joint); they are not incorrectly made half-local multipliers.

## 3. The ORIGINAL endpoint gauge action on the new boundary

Use Diakonov V(20)-(22), not a guessed independent action on dangling links:

    psi_x -> g_x psi_x,       barpsi_x -> barpsi_x g_x-dagger,
    U_(x,mu) -> g_(x+mu) U_(x,mu) g_x-dagger.

On z_ab both endpoints of the INTERNAL connector are represented. Let
G_a,G_b each be the original product Spin(4) over the eight sites of that
slice. They act on their own spinors and spatial links; the connector has

    v_a(r) -> g_b(r) v_a(r) g_a(r)-dagger.

These two group actions commute. Their pullbacks R1(g_a),R2(g_b) on H
are unitary in the existing auxiliary norm: compact left/right Haar
translations preserve link measure, and Dirac/dual spinor transformations
induce unitary exterior representations. Their determinants preserve the
original oriented Berezin top. No state positivity or gauge fixing is used.

Let P1,P2 be normalized group averages of R1,R2. They are commuting
orthogonal projectors; Pi=P1 P2 projects onto this boundary's local compact
gauge invariants. This is only its derived KINEMATIC gauge constraint, not
all gravitational constraints or a physical Hilbert/state identification.

The original weight and ALL prescribed J/j derivative weights are invariant
under the independent node groups at a,b,c. Applying the action in (L), with
change of integrated a fields/links where needed, proves THREE distinct laws:

    L_t P1=L_t,           P2 L_t=L_t,
    P1 L_t=L_t P2.                                           (Ward)

The first averages the discarded OLD node; the second imposes invariance
at the NEW node. In the third, output first node b is the SAME carried node
as input second node b; the connector's left/right endpoint laws and Haar
change of variables give its intertwining. There is no assumption that
independent transformations of an omitted endpoint act trivially on a used
connector. The same equations hold BEFORE averaging, with the corresponding
unitary carried-node representations, and for every source vertex.

In particular Pi L_t=L_t Pi=L_t P2, although L_t need not have full invariant
range after just one step. For ANY two transfer/source vertices A1,A0
satisfying (Ward),

    Pi A1 A0=A1 A0,          A1 A0 Pi=A1 A0.                  (Gauss)

For the first equality, Pi A1=A1 P2 and P2 A0=A0. For the second,
A0 Pi=A0 P2=P1 A0 and A1 P1=A1. Hence all required two-step products are
ALREADY supported on Pi H, rather than being repaired by a favorable
projection. Gamma commutes with Pi because the gauge action preserves
Grassmann parity. The exact reduced traces and ALL source jets can therefore
be taken on Pi H without changing their original values.

Gauge-invariant spatial multipliers commute with Pi. Their trace/source
identities descend with the SAME operators and contacts. This derivation
does not make Pi a multiplicative quotient of arbitrary noninvariant
polynomials, and does not declare additional diffeomorphism/Hamiltonian
constraints solved. The original compact benchmark is unchanged; no
Minkowski/noncompact gauge assumptions are imported.

## 4. Preserve the known invariant witnesses and the original functional

The accepted F62 and G58 are gauge-invariant half polynomials in spatial
links and fermions, independent of outgoing or internal temporal links.
Their vectors embedded in either slice of H are fixed by Pi, and E simply
adds a constant unused-link factor. Multiplication of the invariant vacuum
1 by either gives the same nonzero polynomial; neither is removed by a
Gauss projector or coordinate elimination. Their pair insertions
theta(F)F and theta(F)G satisfy the exact trace identity of section2.

Consequently the original raw zero diagonal and nonzero g2^2*a mixed entry
remain unchanged, at the original scope. This construction cannot turn that
ENTIRE obstructed reflection pairing into a positive one. No negative sector
has been dropped, and no positive state/no-go for the original physical
theory is inferred from the boundary gauge reduction.

## 5. Concrete boundary trace/source map and the remaining physical state

There is now an exact original-action operator representation on the
kinematic gauge space H_g=Pi H:

    Z(J,j)=Str_(H_g)[(L1 L0)|_(H_g)],
    D_raw,g=Gamma (L1 L0)|_(H_g),       Tr D_raw,g=Z.

Spatial metric source multipliers and all crossing/contact derivative
vertices are the reductions of the original ones. Where full Z!=0,
D_raw,g/Z has trace1 and reproduces their stated trace identities. Nothing
in this proof gives Hermiticity, PSD, physical metric adjoints or a positive
state. A regular source-derived boundary/constraint map has been built; the
physical product/adjoint/state and controlled regulator/continuation
correspondence must still be constructed. The coefficient norm is auxiliary.

The fixed positive fermion control's CAR/star/source contacts are not
imported. The old nilpotent-wedge versus physical-adjoint issue is not
resolved merely by restricting to gauge invariants. No physical source,
action, boundary, matter term, coupling or state is selected for positivity.
Full Z/c0, N4 tensor, original B3 range/normalization, tensor/matter/light
and causal transport remain OPEN. ROOT retains ALL ordinary L1 readiness,
consumer/manuscript/claims/repairs/reviews/gates/integration/operator ownership.

The pre-work brief approvals authorize only this manual source construction
and separate result reviews. They are not source-data, controller canary,
resource, slot, native or execution admission. Any future implementation/
source-data proposal must independently pin its exact producer, source/input,
command, controls/canary, output/evidence, parent-child and resource caps and
receive the required review plus fresh exact controller canary/resource
admission BEFORE execution. No such proposal or admission is supplied here.

Independent math review must check the LEFT-only range identity, isometry/
compression/finite-rank trace signs, joint temporal Haar, endpoint unitary
actions and all three Ward laws, two-step Gauss support, source/contact and
witness preservation. Independent physics/source review must check the
originally derived constraint scope and no positive-sector/model selection.
Manual acceptance remains distinct from kernel/full-wave/publication/human
acceptance; no scientific evaluation or infrastructure change has occurred.
