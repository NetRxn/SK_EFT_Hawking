# L1-PHYS-FORCE-02 — original two-force physical reconstruction charter R1

**Status: frozen prospective charter, no construction or implementation.**
Task l1-original-two-force-physical-r1; parent publicationROOT01a13f67/L1-physical-observable-boundary. Lead and sole primary-notebook writer Executor01a1ac65. Source donor6ffc9db4c59a7762c892bac8afb90bf415e6f1fa; publication ROOT reports exact absorption into remote checkpoint75b1430ca. Work here remains on the clean donor support branch. ROOT's November20 commission is the acceptance authority for this charter. No new scientific premise, runtime, Lean slot or model change is granted.

## 1. Scientific target and first construction route

Derive, from the original unaveraged kernel and matching relation, a common physical domain, product, normalized positive state, adjoint and source-dependent cut maps representing the two retained forces and the transfer. An accepted result is either that actual construction, or the first failed REQUIRED identity of the specified route, with an exact original witness and constructive continuation. An uncompleted search is an open result, not a failure theorem.

The initial route is **cyclic reconstruction of the original two-sided insertion correspondence**, keeping original compact memory until composition. Start with actual kernel insertions and their typed ordered compositions, and seek their physical representation together, rather than first adopting a one-sided endpoint quotient, CAR norm, guessed geometric half-pairing or free pair of new modes. Source evaluation and composition are inputs; the physical product and involution are outputs to prove. This route is a proposal for research, not a claim that a positive cyclic representation exists.

Alternative approaches were considered. Repeating a projected endpoint polarization would discard the accepted crossed forces. A direct geometric OS invocation has an unmet reflection-invariance premise and an already failed fixed half-pairing. Choosing an auxiliary coefficient/CAR norm gives neither the matched state nor physical adjoint. Feshbach/Schur elimination would require a physical split and invertibility not presently supplied. Thus this charter begins with the full two-sided correspondence; it permits no inverse of a nilpotent source or an unproved block. A proposed reduction must be derived and independently reviewed, not silently selected for positivity.

## 2. Exact inherited inputs; no new computation at charter stage

Read the complete accepted donor construction and acceptance, both actual reports and archive manifest; original graded relation, one-slice kernel, kinetic normalization especially (30)–(31), coherent bridge, original physical metric/matter map and EHC source adjoint, with their scoped acceptances. Read the current primary L1FixedControls notebook and Phase6a roadmap; use the existing publication planner/ROOT queue, not another routing ledger. The Terra scout is conditional method research, not an actual construction or review of this charter. Jaffe-Janssens/Feshbach assumptions are not automatically hypotheses of this model.

The current accepted source-lift result supplies, on the unsewn triple of independent slices a,b,c with shared b exactly once,

 B_-=(X_a,X_b,v_a), B_+=(X_b,X_c,v_b),
 d=2 R_-·R_+,
 m_a=2(V_a R_-)·R_+, m_c=2 R_-·(V_c R_+),
 V_s[h]F=I_a integral dH_a exp(s_s) h F, L_s=V_s[1].

Here V_a is the even Euler on four old unbarred components, V_c the even new local phase variation, not physical symmetries assumed by name. H=span_C{1,m_a,m_c} is the span of their actual images modulo the original matching evaluation relations. H is a generating insertion space, NOT a presumed algebra, three-dimensional Hilbert space, independent pair of modes, or closed reflection sector. If actual linear relations or new generated words appear, retain and prove them.

Retained functions are UNSCALED actual matching functions, not only alpha m. Keep all compact coordinates, original invariant momentum directions/free shared covector where used, inherited chirality/top/quarter conventions, and the original insertion order. No compact average, diagonal grouping, gauge-sector restriction, boundary alteration, cutoff or fitted channel is permitted as a replacement.

The known classical projected-image obstructions, incoming -4 Berezin contact, exact first open values (i/4,-1/4), mixed (-g2/2,-ig2/2), and identities with the retained forces are accepted inputs, not new accomplishments of this charter. The new construction must consume them and their original test domains. It must not claim success by relabeling those necessary identities as physical (30)–(31).

## 3. Carrier, products, domains and possible reduction

Begin on the original dense coefficient test algebras: finite exterior polynomials with compact polynomial coefficients, and their admitted C2 source families. Record input/output/reverse cut type on every kernel and every composition. Compose only matching cuts, integrating the shared connector in the inherited order. The three slices remain independent until the prescribed composition/sewing. Each step has its own force labels m_(sigma,k) and its own action centre; periodic old/new identification is performed afterwards and is not used to simplify a force before insertion.

Build the ordered word/module carrier generated by these original V_s[h], endpoint cap tests and the reflected correspondences, imposing the actual matching/substitution and integration identities. This is a source carrier for a candidate representation; formal concatenation or Berezin convolution must not be called the physical observable product by declaration. In particular external caps are tests, not automatically positive physical observables or one-sided multiplication operators.

The FIRST required descent identity for any proposed maps is independence of the force-inserted output from the represented input: if I_i,s F=I_i,s F', then I_o,s V_s[h](F-F')=0 for h=1,m_a,m_c, in all required contexts. Check both orientations and all source jets. The corresponding relation must remain valid after further admitted insertions and both periodic closures. A cyclic/null quotient is allowed only if its nulls are stable under every represented operation, source derivative and physical involution and preserve all required original cap/sewn moments. Defining a null space as the kernel of L alone is prohibited by the accepted gu control. One may use the full original operational null relation (all admitted word/cap contexts) as a faithful comparison, but must prove any claimed smaller quotient and positivity; a tautological quotient is not a positive state construction.

For success, explicitly give a common dense physical domain D, its carrier/quotient and source identifications, an associative unital product star_s on the generated observable domain, an antilinear involution sharp_s with reversed product law, and normalized omega_s satisfying omega_s(A^sharp star_s A)>=0. Derive these from original ordering/composition and matching moments; prove constraints/nulls and domains are compatible. State whether operations are bounded; if unbounded, give invariant cores and adjoint/closure domains actually required. No global self-adjointness or unitary dynamics follows from a finite symbolic dictionary. Source variation must use specified C2 identifications/cores or explicit domain-derivative terms.

## 4. Exact forward and separately reverse identity

For every h in H and every admitted original cap F, derive physical operations T_s[h] and cut maps with

 I_o,s V_s[h]=T_s[h] I_i,s,       T_s[1]=T_s.                 (F)

Linearity in actual h and every original relation must survive. T_s[h] is to be constructed in the derived product/state/domain, not defined merely by naming the right side of (F). Do not assert T[h]=O[h] T or T O[h] for the bilocal force without deriving that factorization. Require a common physical representation across both steps and force words so that the next composition is meaningful.

Independently require, on the actual reversed domains,

 I_rev,o,s V_s^theta[h]=T_s[h]^(dagger_phys) I_rev,i,s.       (R)

Transport the fixed bilinear transpose through the actual antilinear cut reflection; keep separate coefficient adjoint, geometric reflection and derived physical dagger. Preserve reflected/inverted independent anchors, transported backward temporal curvature and original order. The original real alpha source reflects positively, local beta shear negatively at the reflected centre. Both (F) and (R) must use the original EHC defect exp(Delta_s), including Delta_0, and the matched source pullbacks and denominators. The construction must explain any change between geometric theta and physical sharp through derived maps/pairing; neither theta-invariant action nor equality of forward/reverse weights may be assumed.

## 5. Concrete joint state/product and two-interface acceptance tests

For both steps k=0,1 retain each force at its own action centre. Let K_s=L_1,s L_0,s. The specified original amplitude seam is Str K_s=Tr(Gamma K_s)=Z_s. On an original neighborhood with Z_s nonzero, all four ordered targets are

 A_sigma,tau(s)=Str(V_1,s[m_(sigma,1)] V_0,s[m_(tau,0)])/Z_s,
                       sigma,tau in {a,c}.                 (C)

Also require the corresponding unit/force entries with either h=1, and the original inserted cap versions before taking the closed seam. Derive exactly how the physical state applied to the ordered represented composition gives (C), with whatever physical seam is actually derived. Omega(T1[m_sigma] star T0[m_tau]) is a claim only after domains, product and seam are defined; a possible representation with a boundary functional or separate transfer weight must specify and prove its state/normalization. The forward-forward array (C) is NOT a Gram matrix and carries NO inherited positivity/sign condition. Positivity is tested on A^sharp star A in the actual derived algebra, with actual reversed orientation and its defect, not by requiring (C) positive entrywise or PSD.

Matching only four numbers is insufficient: require equality as a cap-dependent original kernel functional on the declared test domain and for the generated words needed for products/adjoints and null stability. A restriction of admissible caps must be source-justified, carry the retained-force witnesses and required physical tetrad/source tests, and preserve the commissioned moments; killing a known witness by fiat is not a physical null quotient. No amplitude is replaced by an auxiliary positive marginal, positive effect or added background.

## 6. Literal sources and ALL first/mixed contacts

Use alpha=J_(r,00), r=(b,spatial origin), and beta with A_z=I+beta delta_zr E01. All other metric sources vanish and frames are identity. Keep source profiles centred at their actual step; put a zero profile to zero only after locating all placements. The accepted full original vertices are s_alpha=R², s_beta=E_beta, s_alpha,beta=2 R·T1. The mixed kernel vertex is R² E_beta+2 R·T1. Retained m_a,m_c have zero coordinate source jets here; their physical realizations and maps can have nonzero jets. Preserve original Bopp scalar/bilinear contacts and transported contraction normalization.

For K_1 K_0, differentiate both factors: mixed=K_1,alpha,beta K_0+K_1,alpha K_0,beta+K_1,beta K_0,alpha+K_1 K_0,alpha,beta. Use this for every ordered force/unit entry, not only L1L0. Derive both source-weighted and explicit insertion jets and every moving cap/map/product/state/adjoint contact. For each h, the first and mixed equations from (F) include all product-rule placements on both sides; likewise (R) with actual source/domain transport. The h=1 equations must reproduce kinetic (30)–(31) and its four mixed placements on each side.

For each numerator N (including all cap and force entries), n=N/Z obeys n_j=(N_j-n Z_j)/Z and n_alpha,beta=(N_alpha,beta-n Z_alpha,beta-n_alpha Z_beta-n_beta Z_alpha)/Z. Reversed/reflected tests retain their own conjugate/reflected partition and exp(Delta_s) derivatives, including both cross-weight terms and Delta_0. Preserve matrix-log/Bopp contacts only on their established domains; no score substitutes for the physical quartet. If a source-dependent calibration is introduced, derive its own jets rather than choosing a favorable normalization.

## 7. Result types, adverse controls and constructive continuation

SUCCESS requires the explicit physical objects, derivations and all (F),(R),(C)/unit/cap/jet matches above at the stated scope. It does not alone fix calibration, causal/light/matter dynamics, B3/N4 or publication. State any generated word/completion limits precisely.

FAILED REQUIRED IDENTITY requires: specify the proposed source-native representation/descent/product/state/adjoint identity; exhibit an admissible exact original cap/word/link test with nonzero discrepancy (or violated positive-state quadratic form) and prove Berezin/Haar/domain/sign/support exclusions; distinguish first from mixed, unsewn from sewn, and graph from integrated witness. A single compact point is not an integrated quantum witness without the justified continuity/Haar argument. The failure is of this specific route/identity, not every reconstruction. Provide the actual extra retained word, relation, state datum or domain condition needed for the next construction and show why that continuation addresses the displayed failure. Do not stop at repeating known geometric Gram, scalar-score, auxiliary cycle projector or endpoint nonflatness failures.

Retain all inherited adverse controls in their separate algebras: compact f lost by averaging despite L(t)f=tTheta_b; open Phi3/4/closed0; Lu=0 but gu=-2e and omega(e)=1/Z; specified geometric F60/G52 isotropic nonradical pair; failed coefficient grouping; instrument negative seam effect/added positive background. They test proposed identifications, not a mandate to treat each auxiliary test as a physical observable. Preserve A01's conditional same-source positive-adjoint requirement independently. No page0/h12,6/A01 precondition is imposed here. If a new coefficient is needed, first give its exact target and why it is necessary; no scientific evaluation is authorized.

## 8. Work packages, prospective review and stop boundary

- [ ] Prospective independent mathematics: test whether the proposed correspondence route and first descent/product/state identities are defined, noncircular and falsifiable; verify typed compositions, quotient/positivity distinctions, domain/jet/seam obligations and bounded result criterion. Report APPROVE or REVISE with concrete corrections.
- [ ] Prospective independent original source: rebind all forces, source/anchor/order/normalization and both sewings to accepted original bodies; detect a hidden model/premise/sector/denominator change, a repeated old failure or an illegitimate physical identification. Report APPROVE or REVISE with concrete corrections.
- [ ] Lead reads complete reports; preserve every revision and settle all material corrections. Only a frozen charter receiving BOTH prospective approvals is ready for ROOT intake.
- [ ] STOP and report charter/reviews before any scientific construction, implementation or execution, per ROOT commission. A later constructor must receive a new explicit assignment and continuity snapshot. Actual construction review will be by a distinct fresh pair; prospective approval accepts no result.

Private deliverables only: this charter /private/tmp/l1-two-force-physical-charter-r1.md, independent /private/tmp/l1-two-force-physical-{math,source}-prospective-r1.md and frozen review packet. Lead owns primary notebook/index, then a portable charter/review checkpoint if accepted; ROOT owns roadmap/queue/gates/absorption/main/final human approval. Workers read notebooks, do not write them. No scientific program/import/test/CAS/Lean/native/slot/controller/process/harness/dependency action. Ordinary source/PDF reads, file hashes/JSON/ZIP/continuity bookkeeping are allowed. Scientific content of this charter is prospective, not a claim that (F),(R),(C) or physical positivity has been constructed.
