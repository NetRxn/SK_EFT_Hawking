"""Single gated scientific traversal; launched only after independent source review."""
from argparse import ArgumentParser
from pathlib import Path
from time import monotonic
from fractions import Fraction
import ast
import hashlib
import json
import signal
import sys

ROOT = Path(__file__).resolve().parent
CORE = ('leading.py', 'controls.py', 'calculate.py', 'run.py',
        'test_scientific_controls.py', 'legacy-binding.json', 'LEADING_METRIC_RESPONSE_DESIGN.md',
        'ELIMINATION_ORDER_REPAIR_R1.md')


def source_paths():
    return [ROOT / n for n in CORE] + sorted((ROOT / 'science').iterdir())


def fingerprint():
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in source_paths() if p.is_file()}


def verify_binding():
    binding = json.loads((ROOT / 'legacy-binding.json').read_text())
    for name, expected in binding['copied'].items():
        assert hashlib.sha256((ROOT / 'science' / name).read_bytes()).hexdigest() == expected
    path = ROOT / 'science/legacy.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == binding['legacy_sha256']
    module = ast.parse(path.read_text())
    functions = {node.name: node for node in module.body if isinstance(node, ast.FunctionDef)}
    for name, entry in binding['extracted'].items():
        assert ast.dump(functions[name], include_attributes=False) == entry['ast']
    assignment = next(node for node in module.body if isinstance(node, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == 'bases' for t in node.targets))
    assert ast.dump(assignment, include_attributes=False) == binding['bases_assignment']['ast']


def expired(signum, frame):
    raise TimeoutError('Prospectively fixed scientific whole-stage deadline exceeded')


def emit(record):
    print(json.dumps(record, sort_keys=True, separators=(',', ':')), flush=True)


def main():
    parser = ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    cold_started = monotonic()
    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, 600)
    try:
        if sys.flags.optimize:
            raise RuntimeError('Exact scientific controls require Python assertions enabled')
        pins = fingerprint()
        verify_binding()
        import leading as C
        import controls
        C.bind()
        controls.run(args.out / 'controls', emit)
        roster, counts = C.census_all()
        serial_roster = [{'component': list(component),
                          'entries': [[list(anchors), list(det), list(word)] for anchors, det, word in entries]}
                         for component, entries in roster.items()]
        roster_bytes = (json.dumps(serial_roster, sort_keys=True, separators=(',', ':')) + '\n').encode()
        (args.out / 'support.json').write_bytes(roster_bytes)
        assert fingerprint() == pins
        import sympy
        emit({'event': 'preparation', 'components': counts,
              'support_sha256': hashlib.sha256(roster_bytes).hexdigest(), 'source_sha256': pins,
              'cold_seconds': monotonic() - cold_started, 'python': sys.version,
              'sympy': sympy.__version__, 'python_optimize': sys.flags.optimize,
              'elimination_order': C.ORDER_ID, 'Z8': str(C.Z8), 'tree': sorted(C.TREE)})
        assert monotonic() - cold_started < 600
        warm_started = monotonic()
        signal.setitimer(signal.ITIMER_REAL, 1800)
        (args.out / 'warm-clock.json').write_text(json.dumps(
            {'warm_started': warm_started, 'warm_cap': 1800}, sort_keys=True) + '\n')
        emit({'event': 'target-start', 'warm_started': warm_started, 'warm_cap': 1800})
        results = []
        for component, entries in roster.items():
            total = [Fraction(0), Fraction(0)]
            for ordinal, (anchors, determinant, indices) in enumerate(entries):
                assert monotonic() - warm_started < 1800
                descriptor = {'component': list(component), 'ordinal': ordinal,
                              'anchors': list(anchors), 'determinant': list(determinant),
                              'indices': list(indices)}
                emit({'event': 'word-start', **descriptor})
                word = tuple(C.S.TERMS[i][2] for i in indices)
                factors, divisor, metadata = C.assemble(component, anchors, determinant, word)
                assert metadata['frames'] == 16 and metadata['curvature_quarters'] == 5
                raw, peak, products = C.contract(factors)
                value = [Fraction(raw[0], divisor), Fraction(raw[1], divisor)]
                for i in range(2):
                    total[i] += value[i]
                emit({'event': 'word', **descriptor, 'raw': raw, 'divisor': divisor,
                      'value': list(map(str, value)), 'peak': peak, 'products': products,
                      **metadata})
                assert monotonic() - warm_started < 1800
            assert total[1] == 0
            record = {'component': list(component), 'words': len(entries),
                      'q_prime': str(total[0]), 'normalized_g2_cubed_slope': str(total[0] / C.Z8)}
            results.append(record)
            emit({'event': 'component', **record})
        assert len(results) == 10
        assert fingerprint() == pins
        emit({'event': 'complete', 'results': results, 'Z8': str(C.Z8),
              'warm_started': warm_started, 'warm_seconds_before_final_emission': monotonic() - warm_started,
              'source_unchanged': True, 'scope': 'finite uncoupled N4 enabling control; no physical matching or B3 closure'})
        assert monotonic() - warm_started < 1800
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    main()
