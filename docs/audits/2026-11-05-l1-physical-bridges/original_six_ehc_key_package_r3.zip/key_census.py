"""PREPARED, NOT RUN. Original 12,6 necessary-key COST census only.

Execution requires separate publication ROOT admission of exact code/spec bytes.
No six-class products, source-load solutions, Haar tensors or amplitudes run.
"""
import argparse
from bisect import bisect_right
import hashlib
import itertools
import json
from pathlib import Path
import os
import shutil
import struct
import sys
import tempfile
import time
import zipfile

TRIPLES = 152096
PACKED_BYTES = 608384
RAW_SIX = 1267339920
MAX_JSON_BYTES = 1000000
MAX_ARCHIVE_BYTES = 2000000
EDGES = tuple((v, d) for v in range(16) for d in range(4) if not v & (1 << d))
EDGE_INDEX = {edge: i for i, edge in enumerate(EDGES)}
PARENT = {v: (v ^ (v & -v), (v & -v).bit_length() - 1) for v in range(1, 16)}
TREE = frozenset(EDGE_INDEX[(p, d)] for p, d in PARENT.values())
NON_TREE = tuple(i for i in range(32) if i not in TREE)
TARGET = {'a': 12, 'b': 6, 'test': '1', 'time_pair': [0, 1],
          'first_axis': 2, 'second_axes': [2, 3],
          'eta_spatial_axis': 1, 'reduced_weight': '8*eta(d)*(1 if nu==2 else -1)'}
ENCODING = {'edge_order': 'root increasing then axis increasing, root bit axis zero',
            'class_order': 'base increasing then lexicographic k<l',
            'tree': 'clear least set bit; root 0', 'syndrome_bits': '17 non-tree edges in edge order',
            'parity_bit': 17, 'record': '(key<<14)|(minlabel<<7)|maxlabel',
            'byte_order': 'little', 'sort': 'unsigned integer nondecreasing',
            'multiplicity': 'preserve every triple including equal packed records',
            'scope': 'lossy cost multiset; middle labels must be regenerated for full support',
            'publication': 'single ZIP_STORED container via exclusive same-filesystem hard link'}
LIMITS = {'max_seconds': 120, 'triples': TRIPLES, 'packed_bytes': PACKED_BYTES,
          'max_json_bytes': MAX_JSON_BYTES, 'max_archive_bytes': MAX_ARCHIVE_BYTES, 'top_buckets': 20}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def no_duplicate_json(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('Duplicate JSON key')
        out[key] = value
    return out


def edge_index(v, axis):
    return EDGE_INDEX[(v & ~(1 << axis), axis)]


def key_of(character):
    potential = [0] * 16
    for vertex in range(1, 16):
        parent, axis = PARENT[vertex]
        potential[vertex] = potential[parent] ^ ((character >> edge_index(parent, axis)) & 1)
    syndrome = 0
    for bit, index in enumerate(NON_TREE):
        vertex, axis = EDGES[index]
        value = ((character >> index) & 1) ^ potential[vertex] ^ potential[vertex ^ (1 << axis)]
        syndrome |= value << bit
    return syndrome | ((sum(potential) & 1) << 17)


def classes():
    result = []
    for z in range(16):
        for k, l in itertools.combinations(range(4), 2):
            mu, nu = tuple(axis for axis in range(4) if axis not in (k, l))
            anchors = ((z, l, True), (z ^ (1 << l), k, True),
                       (z ^ (1 << k), l, False), (z, k, False))
            character = (1 << edge_index(z, mu)) ^ (1 << edge_index(z, nu))
            for vertex, axis, dagger in anchors:
                character ^= 1 << edge_index(vertex, axis)
            load = [0] * 16
            load[z] += 2
            load[z ^ (1 << mu)] += 1
            load[z ^ (1 << nu)] += 1
            order = (k, l, mu, nu)
            epsilon = -1 if sum(order[a] > order[b] for a in range(4) for b in range(a + 1, 4)) % 2 else 1
            result.append({'id': len(result), 'center': z, 'curvature': [k, l],
                           'frames': [mu, nu], 'epsilon': epsilon, 'load': load,
                           'anchors_H_order': anchors, 'character_hex': format(character, '08x'),
                           'key': key_of(character)})
    if len(result) != 96 or len(EDGES) != 32 or len(TREE) != 15 or len(NON_TREE) != 17:
        raise RuntimeError('Original descriptor count mismatch')
    return result


def source_cases():
    result = []
    for displacement in range(8):
        vertex = 1 | (displacement << 1)
        eta = -1 if displacement & 1 else 1
        for nu in (2, 3):
            result.append({'id': len(result), 'times': [0, 1],
                           'source_vertices': [0, vertex], 'source_axes': [2, nu],
                           'spatial_displacement': displacement,
                           'weight': 8 * eta * (1 if nu == 2 else -1)})
    return result


def run(args, publication_state):
    started = time.monotonic()
    if not 0 < args.deadline_seconds <= 120:
        raise ValueError('Deadline must be positive and at most120seconds')

    def deadline():
        if time.monotonic() - started > args.deadline_seconds:
            raise RuntimeError('Cooperative census deadline; no complete output published')

    raw_spec = Path(args.spec).read_bytes()
    if sha(raw_spec) != args.spec_sha256:
        raise ValueError('Exact spec hash mismatch')
    spec = json.loads(raw_spec.decode('utf-8'), object_pairs_hook=no_duplicate_json)
    required = {'schema_version', 'task', 'source_head', 'repo_root', 'code_sha256',
                'input_pins', 'target', 'encoding', 'limits'}
    if set(spec) != required or spec['schema_version'] != 1 or spec['task'] != 'l1-sixehc-key-cost-r3':
        raise ValueError('Spec identity/schema mismatch')
    if spec['target'] != TARGET or spec['encoding'] != ENCODING or spec['limits'] != LIMITS:
        raise ValueError('Frozen source/encoding/limit contract mismatch')
    if spec['source_head'] != 'f3b77e5dd96bf517ec9b245b7e6c784621d62655':
        raise ValueError('Assigned scientific input head mismatch')
    if sha(Path(__file__).read_bytes()) != spec['code_sha256']:
        raise ValueError('Exact program bytes mismatch')
    repo = Path(spec['repo_root']).resolve(strict=True)
    if not isinstance(spec['input_pins'], dict) or not spec['input_pins']:
        raise ValueError('Input pins missing')
    for relative, expected in spec['input_pins'].items():
        path = (repo / relative).resolve(strict=True)
        if not path.is_relative_to(repo) or sha(path.read_bytes()) != expected:
            raise ValueError('Original scientific input pin mismatch')
        deadline()

    requested = Path(os.path.abspath(args.output))
    # Resolve ancestors only: never follow the requested final component.
    output = requested.parent.resolve(strict=True) / requested.name
    if output.parent != Path('/private/tmp') or os.path.lexists(output) or not output.parent.is_dir() or output.suffix != '.zip':
        raise ValueError('Output must be a new ZIP file directly under /private/tmp')
    descriptors = classes()
    deadline()
    records = []  # MULTISET: equal packed words MUST remain separate records.
    labeled_digest = hashlib.sha256()
    for counter, (a, b, c) in enumerate(itertools.combinations_with_replacement(range(96), 3), 1):
        key = descriptors[a]['key'] ^ descriptors[b]['key'] ^ descriptors[c]['key']
        if not 0 <= key < (1 << 18):
            raise RuntimeError('Key exceeds18bits')
        record = (key << 14) | (a << 7) | c
        records.append(record)
        labeled_digest.update(struct.pack('<BBBI', a, b, c, key))
        if counter % 1024 == 0:
            deadline()
    if len(records) != TRIPLES:
        raise RuntimeError('Incomplete triple catalogue')
    records.sort()  # Never set()/deduplicate: different middle labels can collide.
    deadline()
    total_pairs = 0
    distinct_records = 0
    bucket_count = 0
    largest_bucket = 0
    largest_pair_bucket = 0
    top = []
    position = 0
    while position < TRIPLES:
        key = records[position] >> 14
        end = position + 1
        while end < TRIPLES and records[end] >> 14 == key:
            end += 1
        bucket = records[position:end]
        maxima = sorted(record & 127 for record in bucket)
        pairs = sum(bisect_right(maxima, (record >> 7) & 127) for record in bucket)
        total_pairs += pairs
        distinct_records += sum(index == 0 or record != bucket[index - 1] for index, record in enumerate(bucket))
        bucket_count += 1
        largest_bucket = max(largest_bucket, len(bucket))
        largest_pair_bucket = max(largest_pair_bucket, pairs)
        top.append({'key': key, 'triples': len(bucket), 'canonical_pairs': pairs})
        top.sort(key=lambda item: (-item['canonical_pairs'], -item['triples'], item['key']))
        del top[20:]
        position = end
        deadline()
    if position != TRIPLES or not 96 <= total_pairs <= RAW_SIX:
        raise RuntimeError('Canonical key-pair census bounds mismatch')
    binary = b''.join(struct.pack('<I', record) for record in records)
    if len(binary) != PACKED_BYTES:
        raise RuntimeError('Packed byte count mismatch')
    deadline()
    manifest = {
        'status': 'complete_triple_key_cost_census_only',
        'not_full_support_or_coefficient': True,
        'requires_middle_label_regeneration_for_full_join': True,
        'task': spec['task'], 'source_head': spec['source_head'],
        'program_sha256': spec['code_sha256'], 'spec_sha256': args.spec_sha256,
        'input_pins': spec['input_pins'], 'target': TARGET, 'encoding': ENCODING,
        'edges': EDGES, 'tree_edge_indices': sorted(TREE), 'non_tree_edge_indices': NON_TREE,
        'classes': descriptors, 'target_cases': source_cases(),
        'triples': TRIPLES, 'distinct_packed_records': distinct_records,
        'packed_collisions_retained': TRIPLES - distinct_records,
        'key_buckets': bucket_count, 'largest_bucket_triples': largest_bucket,
        'largest_bucket_canonical_pairs': largest_pair_bucket,
        'canonical_key_pairs': total_pairs,
        'prospective_target_case_reference_checks': 32 * total_pairs,
        'top_buckets': top,
        'packed_file': {'name': 'COST_RECORDS_LE32.bin', 'bytes': len(binary), 'sha256': sha(binary)},
        'full_labeled_triples_in_canonical_generation_order_sha256': labeled_digest.hexdigest(),
        'elapsed_seconds_before_manifest_and_publish': time.monotonic() - started,
        'peak_memory': None, 'resource_qualification': 'UNKNOWN',
        'deadline_kind': 'cooperative_refusal_not_hard_preemption',
        'deadline_seconds': args.deadline_seconds,
        'complete_six_class_support': 'NOT_RUN', 'haar_or_amplitude': 'NOT_RUN',
    }
    raw_manifest = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode('utf-8')
    if len(raw_manifest) > MAX_JSON_BYTES:
        raise RuntimeError('Manifest byte cap exceeded')
    staging = Path(tempfile.mkdtemp(prefix='.l1-sixehc-key-staging-', dir=output.parent))
    try:
        archive = staging / 'OUTPUT.zip'
        with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_STORED) as zipped:
            zipped.writestr('COST_RECORDS_LE32.bin', binary)
            zipped.writestr('MANIFEST.json', raw_manifest)
        if archive.stat().st_size > MAX_ARCHIVE_BYTES:
            raise RuntimeError('Container byte cap exceeded')
        with zipfile.ZipFile(archive) as zipped:
            if zipped.testzip() is not None or set(zipped.namelist()) != {'COST_RECORDS_LE32.bin', 'MANIFEST.json'}:
                raise RuntimeError('Staged container integrity mismatch')
            if zipped.read('COST_RECORDS_LE32.bin') != binary or zipped.read('MANIFEST.json') != raw_manifest:
                raise RuntimeError('Staged container exact readback mismatch')
        archive_sha256 = sha(archive.read_bytes())
        deadline()
        # Same-filesystem hard link is ATOMIC and EXCLUSIVE even if a target
        # file, directory or symlink appears after the earlier existence check.
        os.link(archive, output)
        publication_state['published_by_this_run'] = True
    finally:
        shutil.rmtree(staging)
    print(json.dumps({'status': manifest['status'], 'output': str(output),
                      'container_sha256': archive_sha256,
                      'manifest_sha256': sha(raw_manifest), 'packed_sha256': sha(binary),
                      'triples': TRIPLES, 'canonical_key_pairs': total_pairs,
                      'peak_memory': None, 'full_support': 'NOT_RUN', 'coefficient': 'NOT_RUN'}, sort_keys=True))



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec', required=True)
    parser.add_argument('--spec-sha256', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--deadline-seconds', required=True, type=float)
    args = parser.parse_args()
    publication_state = {'published_by_this_run': False}
    try:
        run(args, publication_state)
    except Exception as error:
        status = 'ERROR_AFTER_COMPLETE_PUBLICATION' if publication_state['published_by_this_run'] else 'REFUSED_NO_COMPLETE_OUTPUT_FROM_THIS_RUN'
        print(json.dumps({'status': status, 'published_by_this_run': publication_state['published_by_this_run'], 'error': str(error),
                          'full_support': 'NOT_RUN', 'coefficient': 'NOT_RUN'}, sort_keys=True), file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
