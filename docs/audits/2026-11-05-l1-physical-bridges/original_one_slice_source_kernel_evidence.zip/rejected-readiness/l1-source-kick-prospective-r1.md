# Original spatial-source canonical-kick reconstruction — prospective admission R1

Status: proposed mathematical/source investigation, not an approved physical candidate or a new scientific result. Executor 01a1ac65 owns this brief. ROOT 01a13f67 owns ordinary L1/publication/source formalization and all integration/runtime admission. This proposal requests independent prospective mathematical and original-source review before any substantive construction. Reviewers must return REVISE if the proposed route lacks an original-grounded physical representation; permission to investigate an unspecified positive form is not approval of a candidate.

## Commission and current acceptance boundary

ROOT accepted the exact metric-only sewing failure in commit fadff561ef34f420ee41cfefefcde93d8619c368 and requested one next substantive ORIGINAL noncommuting product/adjoint/constraint or controlled-limit source/operator attempt. It must retain the original action, sources, coupling/domain/matter/scale requirements, the metric witness and distinct temporal contact below. Repeating compact Haar elimination, the old preconstraint/IBP identities, a representation inventory, an arbitrary positive cone, or another optional coefficient norm is insufficient.

The current primary proof/build activity is ROOT-owned. This proposal requests no Lean slot, scientific evaluator, build, test, controller, reset, dependency, or infrastructure action. If admitted, the first construction is manual mathematical/source work only; later formalization requires exact proof-ready obligations and separately coordinated admission. Reviewer output is private; do not edit the repository, lead's notebook, this frozen brief, or the other review.

## Exact original inputs

Use the accepted periodic Q4/Nt2 benchmark with 16 sites, 128 independent odd coordinates, 64 independently anchored Spin(4) links, original quarter coframe, all determinant/EHC terms, closed plaquette Ddag Cdag B A, exp(+S), both time interfaces and all literal metric/frame source coordinates. No replacement link history, matter species, kinetic term, boundary condition or selected curvature component.

Read the accepted files in docs/audits/2026-11-05-l1-physical-bridges/:

- ORIGINAL_GRADED_CONSTRAINT_RELATION.md: full force graph, projected-ideal distinctions, ordered source IBP contacts; in particular equations (11)–(14), (19)–(21).
- ORIGINAL_BOUNDARY_GAUGE_CONSTRAINT.md and ORIGINAL_BOUNDARY_ONLY_OPERATORS.md: actual boundary coordinates, two-move composition, gauge/unused-coordinate distinctions, auxiliary adjoint versus Berezin transpose.
- ORIGINAL_KINETIC_NORMALIZATION_CORRESPONDENCE.md: zero-source continuum velocity form, original scale/current correspondence and unresolved physical equations (30)–(31), including derivatives of both boundary maps.
- ORIGINAL_MICROSCOPIC_METRIC_COHERENT_BRIDGE.md: already constructed coherent/Bopp/normal/Weyl contacts and the distinction from a physical CAR norm.
- ORIGINAL_METRIC_SEWING_DOMAIN_CONSTRUCTION.md and its acceptance record: exact actual metric failure and temporal contact. Preserve all scope limits.
- NONREGULAR_BOUNDARY_RESEARCH.md and NEXT_ORIGINAL_CONSTRUCTION_DESIGN.md: previously inspected constrained quantization prerequisites, not new results.

The additional compact-specific scout report /private/tmp/l1-next-operator-primary-intake-r1.md is supporting research awaiting lead primary-body vetting. It may be used to identify hypotheses to inspect, not as an independently accepted theorem about this model. Compact induction inherits a represented product/adjoint/positive form; the old-spatial preconstraint alone does not prove a common projector commutes with transfer. Do not repeat that compression as a new physical construction.

Original primary sources retain their existing custody pins and versioned equation references in the accepted inputs: Diakonov 1109.0091v1, Volovik 2312.09435v2 and Vergeles 2506.00036v2. The latter's assumed spectral/domain structures are not a quantization prescription for the compact Euclidean benchmark. Do not add a physical point, tetrad condensate, invertible c-number kinetic matrix or uncontrolled continuum limit.

## Proposed route and the premise requiring admission

The candidate to assess is a constrained, source-transported boundary representation derived from the ORIGINAL spatial metric potential, rather than positivity of the exterior geometric sewing form. At zero frame, the literal spatial source polynomial at the middle slice has the form

    V_J(X_b) = sum_(r,i<=j, i,j spatial) J_(b,r,ij) Q_(b,r,ij).

It has no temporal coframe or temporal link. The proposed first step is to derive, from the complete original finite action, precisely how this term transports the two-boundary cotangent relation, its pre/post ideals and the full transfer. An anticipated shared-momentum shear and potential insertion are QUESTIONS TO PROVE, not new accepted formulas here. Treating them as a new physical result without a product/adjoint/source interpretation would fail this proposal.

The substantive target is an actual positive boundary representation and induced adjoint of the action-carrying shared/new compact-link AND odd sector, with a source-dependent transport map fixed by that source-induced canonical relation. It must specify the starting physical test domain, represented noncommuting algebra, adjoint and compatible positive rigging/quotient form, and show why they follow from the original action/source or an applicable reconstruction theorem. The original symplectic form's zero body forbids assuming an ordinary inverse; it does not prove every constrained quantization impossible. The exact unused input momentum-zero block is not enough.

This R1 has NOT supplied such a starting physical representation. The particular admission question is whether the unchanged kinetic form for these potential sources, together with the exact source-induced cotangent transport, determines one without adding an independent physical premise. Unchanged primary constraints may still coexist with source-dependent secondary constraints, domains and inner products. Reviewers must audit that distinction and must not approve a common physical Hilbert space or seam identification merely because the source is a potential.

If an original-grounded representation can be specified in a corrected brief, construction would have to produce actual maps I_in,J, I_out,J and T_phys,J satisfying the accepted equation (30), compatible with original two-interface sewing and physical adjoints. It must represent the ORIGINAL metric source through the derivative of this equation, including derivatives of I on both sides and all mixed contacts. A formal diagram with unknown I, a coefficient-Fock norm declared physical, or an arbitrary source-dependent similarity chosen to fit answers is not a result.

## Finite-source sewing diagnostic — conditional, not a physical premise

One possible diagnostic of the proposed common-boundary realization is a finite real spatial-source kernel. IF the original reconstruction actually derives a common Hilbert space, a source-independent sewing trace and a self-adjoint Hilbert–Schmidt Euclidean step A(J), with

    Z(J_a,J_b) = Tr[A(J_b) A(J_a)],

then its finite-source Gram matrices must be positive semidefinite. This implication does not require A(J) positive, affine in J, mutually commuting, or positive source-deformed states. Exact finite-dimensional polynomial source coefficients could then be tested by finite coefficient-extraction combinations, rather than imposing high differentiability on the physical source family or identifying exterior powers with operator powers.

This is ONLY a conditional diagnostic. The original three-slice transfer has overlapping pair boundaries; neither the displayed two-step trace nor a common self-adjoint step has been derived. Source-dependent boundary maps, physical inner products, seam operators or source contacts may invalidate that factorization. The existing geometric metric failure already prohibits merely restating that factorization as a universal reconstruction. Any new accepted result must derive a distinct actual canonical source/operator structure or specify the original-grounded obstruction to that structure. A finite-source reformulation of the old negative Gram alone does not meet the commission.

## Nonnegotiable tests and contacts

Carry the SAME accepted metric elements F60 and G52, with mu=1125/4, through the actual noncommuting/source map (not an assumed ordinary physical power). The original raw pairings are

    P(F60,F60)=0,
    P(F60,G52)=P(G52,F60)=(3645/2) mu^6 g2^4.

For real g2!=0 this excludes positivity of the defined exterior geometric pairing. It does not exclude all noncommuting products or all physical dynamics. The old a14 coefficient and K/K_R module identities remain unevaluated; do not claim otherwise.

Separately carry the two literal temporal sources J_(0,x),00 and J_(0,y),00 on the accepted exceptional edge:

    ell[theta F60 F60 Q00_x Q00_y]=(6075/2) mu^6.

The normalized mixed jet is that coefficient divided by Z on Z!=0 because the base and first numerators vanish, not because Z is constant. Temporal/frame sources can change kinetic structure and cannot be inferred from the spatial-source shear. The full J/frame C2 family, A_alpha/A_alphabeta, four two-step placements and I-map derivatives remain obligations. Spatial-only success is not full physical-source closure.

Retain accepted field/coupling/source covariance and the distinction between mathematical nonzero Z and a physically calibrated regime. No favorable lambda, added matter scale, c_Q, c_E, hbar, lattice time, gauge-fixed condensate or metric order/signature may be chosen as a physical conclusion.

## Alternatives considered and admission decision

1. Compact old-spatial Haar reduction alone: useful kinematic input but no physical adjoint/state; rejected as the new target.
2. Bare common-Hilbert finite-source Gram alone: mathematically conditional, risks repeating the accepted geometric obstruction; rejected as the new target.
3. Source-derived canonical transport of the action-carrying sector into an actual positive constrained representation: the intended substantive route, but its physical representation is presently unspecified. Admit only after reviewers identify a precise original-grounded prescription and the lead freezes its construction in a corrected brief.

No controlled-limit alternative is asserted here. If the proposed route cannot supply that starting datum, return REVISE with the exact missing premise and the most narrowly justified next original-source question. Do not rename generic missing representation data as an implementation plan or infer a global no-go.

## Review outputs and explicit verdict

Math reviewer: /private/tmp/l1-source-kick-math-prospective-r1.md. Source/physics reviewer: /private/tmp/l1-source-kick-source-prospective-r1.md. Independently read the whole frozen brief and actual accepted inputs; run the packet check FIRST and FINAL. No scientific evaluator, Lean/backend/build/controller/process operations. Notebook writer is Executor only.

Report APPROVE only if the exact proposed original construction is implementation-ready without an added physical premise, naming the actual representation/adjoint prescription and original evidence. Otherwise report REVISE, separate valid conditional mathematics from unsupported physical requiredness, identify duplication, and specify the minimal next source/physics decision. No scientific construction starts under this R1 merely because a review was requested. ROOT integration and final human publication approval remain distinct.
