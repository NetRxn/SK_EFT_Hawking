# Required review boundary

Publication ROOT required freezing the exact candidate and obtaining fresh independent actual mathematics/source reviews before classification. Decisive issue: whether a composable original cap connector in fixed R3 forces the same middle-letter grading at every iterate representing U_ma*U_ma. A nilpotent raw kernel or auxiliary identification alone is insufficient. Keep noncommuting source/cap identities, whole-core positive implication, and complement continuation separate. If typing is not established, retain exact witness at its accepted scope and continue the constructive route.

Both final ACTUAL reports accept the raw-kernel lemma/witness and conditional positive-core certificate; neither establishes TYP or failure of full R3. Full physical reconstruction remains OPEN. Base R²/E_beta/2R·T1 symbols denote zero-source jets; the source review supplies exact finite-plane derivatives. No scientific execution or physical closure.
