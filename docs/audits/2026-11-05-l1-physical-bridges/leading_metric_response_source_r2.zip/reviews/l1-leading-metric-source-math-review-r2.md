# Independent mathematical SOURCE re-review: leading metric r2

**ACCEPT this source revision for a bounded scientific control/target ATTEMPT, conditional on fresh resource admission and every scientific control passing first. Both r1 BLOCKs are resolved; no necessary source correction remains.** This is static source acceptance only. No scientific import, fixture, C++ compilation, control, contraction or target job was executed by this reviewer; neither a tensor result nor actual deadline feasibility is certified.

Exact14-file source-candidate-pins.json SHA256 **d6efcd03049d968fb247e5e2beca1ebc6948cb2f2495c04608312c4b16a0d5a6**. Accepted design remains405a556e38abaa97d8d297fdb593cb80813caf4fa7e9b6ef58a022c24491317d. Current changed source hashes are:

- leading.pyfba5e69d31c1066cb350744f0eb3ab698aae7de7cd37d1fbad1282b4b74b0ac7
- controls.py4b283af2cdb59dbc63f75ae222894da79abd0a0ce68544cbfc2b183d85e3109d
- calculate.py907af07bd4968de9d91b3c033725ea07f77db2482086e41097edda7bef800a92
- run.py8821afb651c6c78df245cbb822f32f6fc45ca453851a617d312eb00eb9ee6f0e
- test_scientific_controls.pybe84c5a65cc8b275c99bc9ae4d3576e24fb7ccec997044b9a105ce1b3bd5c866

## Preserved original and complete actual delta

Independently verified all14 current source/design/helper hashes against the new manifest. Opened source-r1-blocked-evidence.zip, verified its CRC and all14 old files against the frozen original manifest058a6ce2e240eb5935fd4af1dc261f131c1083e91a5f41ebbd65121c9bdebb3a. The archive's embedded manifest matches that exact hash, and the archive SHA256 isaf4ea57524fd42372a0d31b877c5245ec0b8fc7c389b965066fb60ba984d6a85. Original r1 report and evidence remain unchanged.

Read the revised source and complete diffs. Stdlib AST comparison identifies ONLY these changed function bodies: leading.haar_template, controls.moments, calculate.main and run.main; run adds arm/expired and the test file adds the real-interrupt test. All other source functions, accepted design, legacy-binding, six copied scientific files and extracted legacy.py are unchanged. The r1 checks of actual parent source bytes, eight extracted ASTs, bases assignment and helper/global import closure therefore remain applicable without rerunning scientific code.

The sole producer change is the additional row-count check immediately after inserting a deterministic Haar transition row. It conservatively fails as soon as a layer exceeds120000; it changes no allowed row, coordinate domain, terminal value or scale. Target contract_prepared-equivalent assembly/census/normalization, physical/internal/source factors and arithmetic remain unchanged.

## Repair1: complete degree8 controls

controls.moments now loops over combinations_with_replacement(range(8),8), evaluates each ordered multiset and its reverse, and compares the actual scaled-chain path with the independently written product-S3 moment formula. The source asserts6435 total multisets and330 all-even/nonzero multisets, returning the logically forced6105 zero cases explicitly. Complete ordered degree2/4 domains remain. Thus the missing degree8 odd-count/zero-terminal paths are now in the control domain rather than inferred from the330 nonzero cases. These controls are source-verified, not executed here.

The added scientific fixture installs the ACTUAL driver expired handler, arms the ACTUAL arm helper for20milliseconds, enters a CPU loop, requires TimeoutError and restores/disarms its signal state in finally. It imports the driver without invoking main and evaluates no target word. This is a meaningful prospective native interrupt check rather than a mocked time predicate. Actual passing evidence remains owed when the admitted controls run.

## Repair2: interruptible parent/readback budgets

run.py initializes receipt, phase, argv and pins before the guarded try, then arms an absolute2465second parent deadline BEFORE consumed-source copying. The subprocess receives only that deadline's remaining time; snapshots, child wait and post-child operations share the original allowance. Source-parse/readback no longer gets an unbounded acceptance path outside the alarm.

calculate.py writes a tiny warm-clock.json immediately after starting the ONE1800second target timer. On successful child exit, run.py reads that bounded<=4096byte receipt FIRST, validates its cap and monotonic timestamp, and arms min(parent_deadline,warm_started+1800) before source/stream hashing, stdout parsing or exact arithmetic readback. Missing, oversized or malformed clocks refuse rather than supplying a new warm allowance. The complete event must use the same timestamp. No deadline reset to a fresh1800 occurs in the parent.

After exact full-roster/arithmetic readback, the receipt records parent_seconds_with_readback and whole_warm_seconds_with_readback; both must satisfy their original limits. Final acceptance/exit writing, stdout flush and final absolute checks still occur under the same tightened alarm. This is actual interruptible coverage of the existing operations, rather than only the late elapsed assertions that blocked r1. All600cold/ONE1800wholewarm/2465parent limits and120000-row/3000000-compatible-product caps remain unchanged.

## Exception and alarm lifecycle

The success path can reach clock/warm_deadline uses only after child success, clock validation and alarm tightening. Timeout/nonzero child paths go through the explicit failure refusal before any such use. Receipt/phase/pins are initialized before possible source-copy failures; no unbound-variable success/failure route was found.

A subprocess TimeoutExpired marks timeout and leaves exit_code None; a parent SIGALRM raises TimeoutError into the guarded region and is recorded as a timeout. Source drift, stderr, missing complete output, arithmetic mismatch or any assertion/other exception also reaches the failure handler. It resets driver_success:false, records failure phase/type/message and failure elapsed, preserves available stream hashes, renames any preliminary author-acceptance file to author-acceptance-rejected and writes the failure receipt before reraising. Original raw streams/consumed sources are retained. It does not catch a scientific failure into zero or claim that a child completion line alone establishes driver success.

The handler disarms the scientific alarm for terminal failure-evidence preservation; that bookkeeping is not an additional scientific computation or accepted readback allowance. The outer finally disarms on every exit. On success the alarm remains active through final output. A late exception after preliminary success metadata rewrites it as driver failure and rejects the preliminary acceptance, so eventual data review must require driver_success and terminal success, not just a complete-looking stdout record. No native alarm/cleanup behavior is claimed newly measured by this source inspection.

## Preserved producer mathematics and admission boundary

The r1 independent source derivations still establish: all ten components and complete ordered-anchor/16S4/52S2 sorted2+3 support with its separate ordered-state check; source Q contraction once; determinant epsilon24 without an extra24; original CLOSED full-world curvature quarter; sixteen frame quarters plus five curvature quarters; exact repetition factorials; occurrence-distinct legs with every label twice; one joint two-chiral-S3 integer moment scale per unfixed physical link; full4^21*productD*product multiplicity! divisor; both Gaussian integer components and correct initially closed8-generator bytes/disconnected-group multiplication. No math domain or normalization changed in r2.

The previously reviewed gauge-tree proof applies to EACH complete anchored Q/S4/S2 word after internal sums, with actual endpoint spinors/barred-column transforms and determinant-one Berezin Jacobian. Full identity uses both chiral scalar bases, leaves opposite directed links independent, and removes fixed-link Haar scales. No fixed gamma or selected tensor projection was introduced.

Exact Eq1 frame, full24-world curvature/literal-poison, predetermined old C++ S4 row and104978 normalization-word controls are unchanged and still mandatory BEFORE any target data.104978 remains a convention/control word, not the full denominator. Exact all-ten traversal/reality/sum/commonZ8 parent readback is unchanged. Partial support, exceptions, timeouts or caps receive no coefficient/zero credit; no unchanged failure retry, cap increase or channel omission is authorized.

Source acceptance permits only the prospectively reviewed attempt after publication/resource reconciliation, with control failure stopping the target. It does not establish that any control or target fits its limits, any coefficient/nonzero body/sign, a positive state, a16site denominator, physical B3 scale/window, tensor/matter-light propagation, retarded transport, Lean theorem/absence/admission, main or publication readiness.

## Authority and actual actions

First action and final action immediately before writing this report were `python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/l1-leading-metric-source-review-r2.json` from the assigned checkout; both returned fresh:true/changed:[]. Read r2 packet, current notebook repair entry, revised code/diffs and unchanged accepted design/roadmap/authority context. Two `python3 -B -` stdlib-only pathlib/ast/zipfile/json/hashlib/difflib audits checked manifests/archive/original bytes and the complete changed-function set. No candidate function was called by those audits.

No scientific imports, fixtures/tests, C++ compile, controls, target/contraction/job, Git, build/Lean, slots, process/harness/configuration action or source/notebook/repository edit occurred. Only this r2 report was written.
