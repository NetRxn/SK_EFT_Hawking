# Independent mathematical design review: full leading collective metric r1

**BLOCK for one narrow Haar-scale normalization repair. No other necessary mathematical correction found.** The intended occurrence/count-chain factorization is exact, but the frozen text equates an INTEGER-SCALED chain with an unscaled Haar moment without stating the compensating divisor. This must be explicit before assembly/source implementation or target execution.

Candidate `/private/tmp/l1-leading-metric-response-20261105-r1/LEADING_METRIC_RESPONSE_DESIGN.md`, SHA256 **5af026ea836172f8f83098e0bbdffd8bac1ea746c4b6b4ae80fef44e521ac097**. Inventory86fe1061125efd641433c7327b4bb99f48a7dbd6dd9c95b1f111b36d3a43a71e and current accepted parity/matching construction were read. Parent/source state6dbeeb6fd3441cad1a64b44ea63ec26af9edada2 remains clean and untouched.

## Necessary repair: scaled chain versus normalized Haar integral

**Candidate124–138, especially133–135, and the final word normalization contract.** The terminal weight is specified as D_d times the exact joint moment, with unit deterministic transitions. Therefore for a fixed ordered coordinate sequence its summed chain is D_d*moment, NOT the original moment asserted at135. No explicit division by one D_d per unfixed physical link appears elsewhere in the frozen design. The frame/curvature divisor4^21 is expressly described as before Haar/factorials and does not discharge this missing equality.

A concrete countercontrol is a single link with two repeated plus-sector coordinate0 occurrences. The normalized S3 moment is1/4 and D2=4. There is exactly one state path, with terminal integer weight1. Its raw chain sum is1, not1/4. The missing global scale is thus visible at degree2, without any tensor contraction. A mixed-sector degree4 check is E[q+0² q-0²]=1/16, so D4=48 gives raw3; again division by48 is necessary.

Required repair: explicitly define the integer chain as D_d*moment and recover the physical moment by dividing EACH unfixed physical-link D_d exactly once. With integer frame/curvature/epsilon/source/chain factors and sorted S2 multiset w, a complete word contribution must be recorded as

`R_w / [4^21 * product_(unfixed physical links ell) haar_scale(d_ell) * product_r multiplicity_r(w)!]`,

where R_w is the exact Gaussian-integer whole graph contraction. Sum all source-anchor branches, S4 labels and words; then use the common Z8 and stated g2 normalization. Gauge-fixed tree links have their identity occurrences substituted and no residual Haar chain or D_d denominator. If instead Fraction-valued unscaled terminal moments are used, do NOT divide by D_d again. Preserve a per-word degree/scale receipt and a degree2 normalized1/4 control. No new physics, changed action prefactor or raised cap is required.

## Target, full support and factorials: correct

At N4 the top degree is32. A quartic literal Q and degree8 S4 leave20 degrees, hence exactly five S2 factors. The g1 derivative of the exponential supplies S4 once, with no extra determinant factorial; the remaining coefficient is I[Q S4 S2^5]/5!. This is c=q'(0), distinct from the old tagged dressed/composite mixed coefficient. With G=g2^-1 q(g1/g2²)/z(g1/g2²), q odd and z even, the exact linear derivative is c/(g2³ Z8), including negative real g2 correctly. There is no linear denominator term. The accepted full four-site Z8 is reused, not replaced by the selected104978 word. Sixteen-site normalization remains expressly separate.

Static read of interacting_support confirms52 labels: at each of four centers the six curvature planes have complementary-frame anchor multiplicities1+4+4*2=13. These are support signatures, not amplitudes. determinant_terms gives4 centers times2 axis0 anchors times2 axis1 anchors times1 times1=16 S4 labels. Every source branch must use the Cartesian product of the actual two t_terms lists, as the design states. Q22/Q33 each have one local branch; extended and mixed sources have different site/parity signatures. Equal-axis cross-anchor terms are ordered source branches and occur twice; no silent half-factor is justified.

A globally sorted five-multiset has exactly one prefix of length2 and suffix of length3 satisfying the declared ordering. Conversely every valid split with that ordering reconstructs one sorted multiset. Matching the residual degree and physical-link parity therefore enumerates all necessary support without tagged-word exclusions. Ordered S2 expansion has5!/product multiplicity! occurrences of a multiset; dividing by5! gives the specified1/product multiplicity!. S4 remains one separate insertion. The prospective comparison to the untagged192 local-source roster is appropriate; no new support census was executed in this review.

## Closed curvature and powers of four: correct

Read the actual full-world closed trace convention, fixed_frame owner and determinant convention. For each canonical k<l and complementary mu<nu, the four world permutations (swap k,l and/or mu,nu) have coefficients proportional to

`+Tr(H gamma_a gamma_b gamma5)`,
`-Tr(H gamma_b gamma_a gamma5)`,
`-Tr(H† gamma_a gamma_b gamma5)`,
`+Tr(H† gamma_b gamma_a gamma5)`.

Coframes are even, so reversing the two frame factors introduces no additional Grassmann sign. The opposite oriented CLOSED plaquette is H†. The sum is exactly epsilon*Tr[(H-H†)(gamma_a gamma_b-gamma_b gamma_a)gamma5]/4. Six canonical planes times four orderings cover the original24 world permutations. The action quarter is retained explicitly and is not inferred from trace simplifications.

Q has2 physical T factors, S4 has4 and the five S2 vertices have10:16 frame quarters total. Five curvature-action quarters then give4^(16+5)=4^21 before Haar scales and multiset factorials. The physical determinant is sum_internal_epsilon T0 T1 T2 T3: its24 epsilon entries ARE the determinant, with no extra24 or S4 quarter. The original selected determinant tensor is a control only on its matching geometry, not a precomputed arbitrary S4 builder.

## Occurrence Haar chain: proof after the scale repair

Every individual appearance of a physical link must retain a separate coordinate leg. An ordered tuple(q1,...,qd) determines exactly one path c_t=sum_(s<=t)e_qs from the fixed zero state. All unit transitions along that path multiply to1. Summing internal state indices therefore returns its terminal value exactly once. With the proposed integer terminal that value is D_d*moment; dividing by D_d recovers the normalized original tensor. Many distinct coordinate sequences can end in the same count vector, but they remain distinct assignments of occurrence legs; their combinatorial multiplicity is already present in the external index sums. No extra multinomial belongs at the terminal.

The moment is the product of the two independent four-coordinate S3 sphere moments. Multiple appearances of the SAME physical link are jointly counted once in this tensor; they are not separately Haar-averaged per vertex. This distinguishes the construction from an invalid independent-occurrence approximation or an eight-sphere distribution. D_d=haar_scale(d) is an exact common denominator, as confirmed by the actual helper definition.

If a partial state has more odd coordinates than remaining occurrences, not all odd counts can be flipped to even; pruning it is exact. Any sequence with a nonzero all-even terminal must pass that test at every intermediate point, so it is never removed. This is a support feasibility rule, not an amplitude/cancellation heuristic. Each occurrence label connects one factor to one transition; each state label connects adjacent transitions or the terminal/boundary. Thus all legs remain twice-used, compatible with the existing pairwise indexed_join semantics.

I independently evaluated the factorial/Dirichlet S3 moments over all8-coordinate count multisets at degrees2,4,6,8:36/330/1716/6435 cases, least common denominators4/48/192/11520 respectively. This tiny stdlib algebra also exhibited the degree2 raw1 versus normalized1/4 discrepancy. It is not an actual target graph or scientific assembly run.

## Existing join, optional tree and resource controls

Read indexed_join/choose/eliminate/components directly. The proposed reuse preserves actual coordinate equality, closing-byte complement, disjoint Grassmann support, Gaussian-integer wedge parity and the120000 allocated-row/3000000 compatible-product refusal guards. The4/10 expression only ranks joins and must not truncate larger state domains. Retaining both Gaussian components is necessary until reality of the final assembled tensor is actually established; the existing per-word imaginary assertion is not such a proof.

The optional tree links connect0--1,0--2,1--3 and form a spanning tree without fixing opposite directed anchors. Before adoption, the source review must prove each COMPLETE anchor/S4/S2 word is invariant under the full endpoint Spin(4)/spinor change. Individually anchored T blocks transform as vectors at their action/source center; internal delta/epsilon and the closed trace may then give word invariance after ALL internal sums. A fixed-gamma component is not individually invariant. Substituting full DiracI4 requires both chiral scalar bases0+4 in every fixed occurrence, not one chosen quaternion coordinate. Under that proven word-level change, normalized tree Haar volume and spinor Berezin Jacobian are1. Without it the design correctly omits fixing rather than assuming it.

Controls and refusal behavior are appropriate design prerequisites: complete source/internal/anchor checks, original full-world curvature comparison, S4 convention/control, direct joint moment/count-chain checks, nontrivial signed Grassmann closure controls and the accepted104978 normalization WORD including(2!)^4. That word is a convention control, not fullZ8. Source review remains required before execution.

The prospective600 preparation/control plus ONE1800second ENTIREten-component budget fits inside the2465second parent allowance, with fresh resource admission and output/readback included. These are prospective caps, not demonstrated feasibility. Build and join row/product bounds are not waived by a sparse factorization. An exception, timeout, cap or incomplete traversal cannot become zero; complete ten-entry/anchor/S4/word evidence and independent data/physics acceptance remain required. There is no mathematical necessity to raise caps or silently omit channels.

## Full tensor norm and remainder: correct

The inherited exterior coefficient norm is submultiplicative and bounds every physical T component by16. Therefore ANY one local component, diagonal or not, has ||Q_mu,nu||<=sum_a||T_mu^a||||T_nu^a||<=4*16². No old plus projection or additional site sum is needed. The accepted four-site action estimates4*24*16^4 and4*24*16*16² are both below2^24. Each z/c/d coefficient is a normalized-Haar top coefficient with at most eight factors bounded by2^24, divided by action factorials. Hence B=2^192 safely bounds c_i,d_i,z2,z4.

Parity/saturation give q_i=c_i x+d_i x³ and z=Z8+z2x²+z4x⁴. For |x|<=r<=1, |z-Z8|<=B r²(1+r²)<=Z8/2, so |z|>=Z8/2. Exact subtraction gives numerator x³[Z8 d_i-c_i z2-c_i z4x²] over g2 Z8 z. Taking moduli yields exactly the displayed remainder with2|x|³[Z8B+|c_i|B(1+r²)]/(|g2|Z8²). This is a finite local rational bound, not a physical phase/domain certificate or a prediction that any c_i is nonzero.

## Commands, continuity and boundary

First action and final action immediately before writing this report were `python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/l1-leading-metric-design-review-r1.json` from the assigned worktree; both returned fresh:true/changed:[]. Read packet, full design, kernel inventory, designated notebook entry and accepted parity/roadmap authority context. Static source reads covered support/determinant/fixed_frame/haar_moment/haar_scale/original action/norm and indexed-join owners.

One `python3 -B -` stdlib Fraction/math/itertools/collections/pathlib/hashlib command checked the tiny moment multiset scales, all six formal four-world-order identities, a three-label sorted2+3/factorial partition control(21 multisets/243 ordered words), and candidate hash. No project science import, support/target contraction, compilation, Git, Lean/build, slot, process/harness/configuration action or source/notebook/repository edit occurred. Only this report was written.

The narrow normalization repair requires source-pinned re-review. Mathematical design acceptance after repair would still be separate from actual source/data/runtime/physical acceptance. No positive body, state, sixteen-site denominator, B3 scale/window, tensor/matter cone, real-time transport, Lean theorem, settled no-go, absence claim or publication closure follows here.
