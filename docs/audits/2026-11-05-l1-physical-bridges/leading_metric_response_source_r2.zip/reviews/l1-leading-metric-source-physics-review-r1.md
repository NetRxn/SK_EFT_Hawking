# Independent physics SOURCE review r1 — full leading metric

**BLOCK scientific execution pending one mandatory control-coverage repair.** No additional physical/action-factor error found. The frozen implementation's degree-eight moment control tests330 all-even multisets and their reversals, rather than ALL6435 degree-eight multisets required by the accepted design. Exercise the6105 odd-count zero cases too, against the independent moment formula, without changing target mathematics. Re-review the repaired exact source before execution. No controls were executed in this review.

First action and final pre-report action: assigned primary l1-leading-metric-source-review-r1.json checks from the same isolated checkout, both fresh:true/changed:[]. Read packet, current notebook, accepted design405a556e, entire leading.py/controls.py/calculate.py/run.py/test_scientific_controls.py, extracted legacy source/binding, copied primitive imports and old C++ determinant construction. Reviewed scientific changes against the prior action, collective and physical acceptance contracts. The proposed repository owned path is still missing; actual reviewed sources are scratch-only.

## Concrete required repair

`controls.py:moments` enumerates all degree2/4 ordered sequences, then combinations-with-replacement of FOUR coordinates doubled into length8. This covers precisely330 all-even length8 multisets, with one reversed sequence each. It never exercises the6105 remaining degree8 multisets containing odd coordinate counts. The existing tiny controls contain lower-degree zero cases but do not close the accepted all-degree8-multisets control requirement. The implementation's pruning strongly suggests those moments vanish, but source expectation is not executed control evidence. Replace/add an enumeration of all combinations-with-replacement(range(8),8), compare each sequence and reverse with the independent two-sphere formula, and record/assert6435total,330nonzero,6105zero. This is a bounded completeness repair; it does not permit partial target data or relaxed design wording.

## Target, source and physical factors

Static census loops all mu<=nu in fixed order, every ordered source anchor pair, every determinant label and every sorted five-S2 multiset via a unique2+3split. Its independently ordered count-state tally checks factorial reconstruction; local22/33 assert192. There is no old coframe tag, old mixed selected population, fitted zero, off-diagonal isotropy assumption or omitted source channel. Target sums exact raw/divisor contributions for all ten components and refuses incomplete traversal/imaginary totals. The old mixed-15/2048 is not substituted for qprime.

Physical frame numerators use the unchanged extracted fixed_frame. Divisor includes one quarter per actual frame, one quarter per S2, one joint Haar scale per unfixed physical link, and the S2 multiplicity factorial. Target metadata asserts16frames/fivequarters, hence4^21 before Haar/factorials. S4 is its24-entry internal epsilon determinant with no extra24 or quarter. The source contracts equal internal indices once. Reduced curvature uses the closed H=d†c†ba, H-H† and internal gamma commutator; the planned control compares it with all24world permutations on rational noncommuting chiral fixtures and poisons literal ordering. It retains both Gaussian integer components.

Haar chains implement a deterministic occurrence-count history and terminal D_d*moment_left*moment_right. Assembly divides D_d once per unfixed physical link, excludes tree links, uses scale1forunused links and checks all leg incidences are exactly2. This preserves shared-link correlations and the distinct two-chiral-sphere measure; no low-degree cubature or independent-per-occurrence average is used. Full accepted Z8 is the exact constant1252309350145403/2123366400;104978remains only an end-to-end normalization WORD control. Z32 is neither computed nor assumed.

The code calculates dimensionless c and c/Z8, retaining original symbolic g1 through the reported g2-cubed slope convention. Accepted design keeps physical Z_G/a² and source J_lat=a²Z_GJ_phys symbolic, with off-diagonal coordinate counted once. No fitted sign, body, physical source calibration, positive state, matter matching or interval is inferred from the numerical target.

## Word covariance and fixed tree

The tree edges(0,0),(0,1),(1,1) connect the four sites without a cycle. Each individual directed-anchor coframe pair transforms as an internal vector at its base site; its two terms retain their actual transported fermion endpoints. Thus a same-internal-index Q contraction is invariant even before anchor summation. Each full S4 anchor term contracts four such vectors with epsilon; each full closed S2 anchor term contracts its conjugation-covariant plaquette and two coframes with gamma5. These are invariant under the local Spin(4) transformations, whose Dirac matrices commute with gamma5 and have orientation-preserving internal vector action. Products of these individually complete factors remain invariant per enumerated word. Normalized Haar and fixed Berezin orientation therefore permit the declared spanning-tree substitution; no selected component/gamma restriction is involved.

Actual fixed frame code sums quaternion scalar bases0and4, giving FULL Dirac identity. Curvature fixed slots use4x4identity. Every occurrence of each fixed physical link is removed from Haar legs and no D divisor is attached. This is the word-level covariance required for the optional design tree, not a claim that an individual coordinate monomial is invariant.

## Controls, failures and receipts

Frame controls cover every site/direction/internal component and anchor assembly, with/without the tree, against the four-term expression. Tiny tests exercise distinct chiral moments,6/8-degree values, nontrivial wedge/closing sign and preservation of an imaginary output. The S4 control compiles the byte-identical old selected determinant source, checks50176rows/four12544populations/max128, and compares12predetermined sorted rows with the new exact frame/epsilon assembly on the actual matching center/anchor domain. It does not assert that these12rows alone certify every new determinant geometry. The full104978control checks joint frame/curvature/Haar/Grassmann/factorial conventions before target traversal. Each is gated by assertions/check=True. The degree8zero coverage repair above remains mandatory.

Source verification happens under the600s cold timer before scientific imports. Controls plus complete support preparation share that allowance. A single1800s timer covers the ENTIRE ten-component traversal, per-word start descriptors, contractions/emissions, source readback and final total; it is not reset per word. The2465s parent launches from exclusive consumed copies, preserves raw streams/exit/source metadata and refuses nonzero/timeout/stderr/drift. Each word-start records component/ordinal/anchors/determinant/indices; cap errors append exact join axes/rows/degrees/closing mask. Cap/deadline/exception failures propagate, never become zero. Actual empty exact tables alone return algebraic zero.

Parent stdlib readback checks all roster descriptors/order, signed raw/divisor arithmetic, Haar scales, factorials, full component sums, exact imaginary cancellation and accepted normalization. The source fingerprints cover all consumed scientific sources/design/binding and are checked after preparation/contraction. A completion-looking line alone is insufficient if later deadline/status fails; final data acceptance must inspect terminal metadata. No runtime/cap feasibility, loaded-module observation, source control success or coefficient is established by static review. Fresh resource admission and separate independent data/mathematical/physics review remain required.

## Exact frozen pins and static verification

All14entries of source-candidate-pins.json independently SHA256-verified; manifest SHA256058a6ce2e240eb5935fd4af1dc261f131c1083e91a5f41ebbd65121c9bdebb3a. Main pins:

- leading.py6b49459c6267e71a79612506b01051495bd755190af6e3ddd323d3a064f4b21b
- controls.py454fb42241040a3d21ccbb9de2f6c85562e242b35308fd5f99ff28d849528589
- calculate.py95620f79f50dec034c2eec531f5711fd2db89f384447379e1f286b60e09b5b86
- run.py72ae8bf809d7646a980014ad479c4378a6aeab289187e511dd4fb77399dea5c7
- test_scientific_controls.pya5345a548536bb55b4c017a911ccfb222c5da38954034e2a7e3f39b6a71db3d8
- legacy-binding.jsonf44bbd98a0db28ebdde8cdecca0573b258be09517761647c2fd642651b453edc
- science/legacy.pyc2424499909f51afd3d1044f673fcd5d8cb00fb1bab01f93e442b193ca5f5101

All copied helper/C++bytes match their actual repository originals. Independently compared every one of the eight extracted function ASTs with BOTH its binding AST and actual pinned original source: identical. Inspected copied import closure; no unresolved local dependency was identified. No module was imported to establish this. Remaining exact helper/design hashes are the verified immutable14-entry manifest, retained unchanged by this review.

Only stdlib AST/hash/JSON and static source inspection plus required continuity checks were executed. No unit/control/C++compile/scientific import/preparation/contraction, Git/build/Lean/slot/harness/process or repository/candidate/notebook mutation occurred. Only this report was written. Broader B3/body/state/matter/tensor/transport/Lean/main/publication obligations remain unchanged. SOURCE acceptance after repair will still not be DATA acceptance.
