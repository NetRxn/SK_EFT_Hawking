# Independent physics SOURCE repair review r2

**ACCEPT the repaired frozen source for its bounded prospective execution contract.** The r1 degree-eight control-coverage blocker is resolved. The separate mathematical review's parent/readback deadline repair is present and preserves failure refusal. No additional physical/source error found. This is SOURCE acceptance only: no control success, scientific coefficient, runtime feasibility or DATA acceptance is established. Fresh publication resource admission and independent mathematical acceptance remain required before execution.

Current14-file manifest source-candidate-pins.json SHA256d6efcd03049d968fb247e5e2beca1ebc6948cb2f2495c04608312c4b16a0d5a6. Independently rehashed every entry and parsed each edited Python source. Current principal pins:

- leading.pyfba5e69d31c1066cb350744f0eb3ab698aae7de7cd37d1fbad1282b4b74b0ac7
- controls.py4b283af2cdb59dbc63f75ae222894da79abd0a0ce68544cbfc2b183d85e3109d
- calculate.py907af07bd4968de9d91b3c033725ea07f77db2482086e41097edda7bef800a92
- run.py8821afb651c6c78df245cbb822f32f6fc45ca453851a617d312eb00eb9ee6f0e
- test_scientific_controls.pybe84c5a65cc8b275c99bc9ae4d3576e24fb7ccec997044b9a105ce1b3bd5c866

First action and final pre-report action were the assigned primary l1-leading-metric-source-review-r2.json checks from the same isolated checkout; both fresh:true/changed:[]. Read the repaired source and complete parent driver. Independently opened source-r1-blocked-evidence.zip with stdlibzipfile and verified all14archived source bytes against its original frozen manifest. The original r1 physics BLOCK and r1 source remain preserved. Compared exact source deltas and confirmed accepted design405a556e, binding and ALL copied/extracted science files remain byte-identical. Prior r1 word covariance/action/source analysis therefore remains applicable without a new convention or target change.

## Required coverage repair

`controls.moments` now traverses combinations_with_replacement(range(8),8), evaluates each multiset and its reverse through the chain, and compares raw/divisor to the independently written product of two sphere moment formulas. It asserts6435total/330all-even cases and reports6105zero cases. Thus the missing odd-count degree-eight controls are genuinely in the execution path, rather than a report-only count. Existing complete ordered degree2/4 sequences and tiny moment/wedge tests remain. This source inspection is not a claim that any control has run or passed.

## Parent/readback and cap repair

Parent SIGALRM now starts before consumed-source copying and remains armed over child execution, source hashes, stream parsing, exact roster/arithmetic readback, final evidence and final output. On successful child return, the bounded4096-byte warm-clock sidecar is validated and the timer is tightened to min(parent start+2465, child warm start+1800) BEFORE post-child provenance/parse/readback. The sidecar's clock must agree with the completion stream. If the warm allowance is already exhausted, arm() refuses immediately. Child retains600s preparation and one1800s whole-target timer; no word/component reset is introduced.

The new20ms unit fixture targets the actual parent arm()/expired() CPU interruption path and restores its own handler. It is a proposed test, not observed evidence in this review. Incremental moment-chain row insertion now raises immediately on exceeding120000; it does not prune a physical state or return a zero coefficient. All original join120000row/3000000product guards remain unchanged.

Any exception or deadline failure marks driver_successfalse, records phase/type/message and timing, preserves stream hashes, and renames a preliminary author acceptance artifact to author-acceptance-rejected.json before rethrowing. This keeps a completion-looking child line or previously written preliminary artifact from being standalone acceptance evidence. Failure-evidence preservation after disabling a fired timer is cleanup, not continued scientific work or successful readback. Final DATA review must require driver_successtrue, terminal success, exact pins, raw streams and full roster/readback; child exit0 alone remains insufficient.

## Unchanged physical/source scope

All ten local symmetric Q components, ordered source anchors, all16determinant labels and untagged five-S2 multiset census remain unchanged. No old mixed tag, off-diagonal zero or fitted sign is introduced. Original Tquarter/S4epsilon/full24-worldclosedS2quarter and fullZ8 normalization remain unchanged; the corrected one-D-per-unfixed-link divisor and both-chiral identity tree substitution remain unchanged. The word-level gauge covariance argument in r1 still applies. S4matching12rows and104978normalization-WORD controls remain mandatory, and104978does not replace fullZ8. FullZ32 remains unknown.

Original symbolic g1, physical Z_G/a²/J source convention and finite uncoupled N4 enabling scope are retained. No coefficient/body/nondegeneracy, positive state, matter source match, extended-regulator denominator, B3 interval, tensor/matter cone, real-time transport, Lean or publication acceptance is inferred. There is no retry/cap-raise/omitted-channel permission.

Executed only required continuity checks and stdlib AST/hash/JSON/ZIP/text comparisons. No scientific import, unit/control/compile/support/contraction job, Git, source/candidate/notebook/repository/slot/build/harness mutation occurred. Only this r2 review report was written. Independent mathematical verdict and later actual execution/data evidence remain distinct gates.
