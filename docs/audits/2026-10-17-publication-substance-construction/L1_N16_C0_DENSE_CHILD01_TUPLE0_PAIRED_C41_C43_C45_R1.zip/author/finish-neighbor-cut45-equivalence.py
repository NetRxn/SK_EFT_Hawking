from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations
from pathlib import Path
import pickle
import shutil
import subprocess
import sys
import time

parent = Path(__file__).resolve().parent
source_drivers = parent / 'heavy47-inner'
cut = int(sys.argv[1])
scratch = parent / f'probe{cut}-inner'
shards = 8
known_statuses = []
for receipt in ('primary.tsv', 'rescue.tsv'):
    if (scratch/receipt).exists():
        for line in (scratch/receipt).read_text().splitlines():
            idx, status, *_ = line.split('\t')
            known_statuses.append((int(idx), int(status)))
statuses = dict(known_statuses)
assert sorted(statuses) == list(range(9))
assert set(statuses.values()) <= {0, 2}

def forecast(factors, pair):
    a, A, _ = factors[pair[0]]
    b, B, _ = factors[pair[1]]
    common = tuple(axis for axis in a if axis in b)
    if not common:
        return None
    ia = tuple(a.index(axis) for axis in common)
    ib = tuple(b.index(axis) for axis in common)
    counts = Counter(tuple(row[i] for i in ib) for row in B)
    ordered = sorted(A)
    return [sum(counts[tuple(row[i] for i in ia)]
                for row in ordered[len(ordered)*s//shards:len(ordered)*(s+1)//shards])
            for s in range(shards)]

def solve_status(idx):
    possibilities = list(scratch.glob(f'*-dense-label-rescue-{idx}-1-reduced.pkl'))
    assert len(possibilities) == 1, possibilities
    p = possibilities[0]
    with p.open('rb') as stream:
        factors = pickle.load(stream)['factors']
    if len(factors) == 3:
        return p.name,'triangle-shards.py',(),()
    if len(factors) != 4:
        raise ValueError((idx,len(factors),p))
    candidates = [(pair, counts) for pair in combinations(range(4),2)
                  if (counts := forecast(factors,pair)) is not None]
    pair, counts = min(candidates,key=lambda row:(sum(row[1]),max(row[1]),row[0]))
    assert max(counts) <= 8_000_000
    return p.name,'close-four-shards.py',pair,counts

assert cut == 45 and statuses[7] == 2
assert (scratch/'slice-7-equivalence.out').is_file()
plans = {idx:solve_status(idx) for idx,status in statuses.items() if status==2 and idx!=7}
for name in ('triangle-shards.py','close-four-shards.py','sum-shards.py'):
    shutil.copyfile(source_drivers/name,scratch/name)
with (scratch/'terminal-plan.tsv').open('x') as receipt:
    for index,(path,script,pair,counts) in sorted(plans.items()):
        print(index,path,script,pair,counts,sep='\t',file=receipt)

def run(task):
    index, shard = task
    path, script, pair, counts = plans[index]
    if script == 'triangle-shards.py':
        args = [path,str(shard),str(shards)]
    else:
        args = [path,'--pair',*map(str,pair),'--shard',str(shard),str(shards)]
    start=time.monotonic()
    with (scratch/f'slice-{index}-shard-{shard}.out').open('xb') as receipt:
        subprocess.run([sys.executable,script,*args],stdout=receipt,stderr=subprocess.STDOUT,
                       cwd=scratch,timeout=130,check=True)
    return index,shard,round(time.monotonic()-start,3)

with ThreadPoolExecutor(max_workers=2) as pool, (scratch/'shard-timing.tsv').open('x') as times:
    for result in pool.map(run, ((idx,s) for idx in sorted(plans) for s in range(shards))):
        print(*result,sep='\t',file=times,flush=True)
for index in plans:
    with (scratch/f'slice-{index}-shard-sum.out').open('xb') as receipt:
        subprocess.run([sys.executable,'sum-shards.py',str(index),str(shards)],
                       stdout=receipt,cwd=scratch,check=True)
caps = list(parent.glob(f'*-dense-label-sum{cut}-reduced.pkl'))
assert len(caps)==1,caps
with caps[0].open('rb') as stream:
    matched=pickle.load(stream)['matched']
template=(source_drivers/'sum-case47.py').read_text()
assert template.count('2280960')==1
template=template.replace('2280960',str(matched))
target_line = "    triangle=Path(f'slice-{i}-shard-sum.out')"
assert template.count(target_line)==1
extra = "    if i==7:\n        candidates.append(Path('slice-7-equivalence.out'))\n"
template=template.replace(target_line,extra+target_line)

retally=f'sum-case{cut}.py'
with (scratch/retally).open('x') as f:
    f.write(template)
with (scratch/f'author-case{cut}.tsv').open('xb') as receipt:
    subprocess.run([sys.executable,retally],stdout=receipt,cwd=scratch,check=True)
print(cut,(scratch/f'author-case{cut}.tsv').read_text().splitlines()[-1],flush=True)
