import argparse
from fractions import Fraction
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys

parser=argparse.ArgumentParser()
parser.add_argument('restored_root',type=Path)
parser.add_argument('checker_dir',type=Path)
args=parser.parse_args()
archive=Path(__file__).resolve().parent
sys.path.insert(0,str(args.checker_dir.resolve()))
spec=spec_from_file_location('checker',args.checker_dir/'verify-witnesses.py')
checker=module_from_spec(spec)
spec.loader.exec_module(checker)

source=args.restored_root/'probe41-inner'/'slice-7.pkl'
target=args.restored_root/'probe45-inner'/'slice-7.pkl'
proof=archive/'author'/'45'/'slice-7-witness.pkl.gz'
assert sha256(source.read_bytes()).hexdigest()=='18e18115c2e69d173bb80021c04032aa167176457b2d1fb5b6c5027195b934a1'
assert sha256(target.read_bytes()).hexdigest()=='00101c64996a61e8b1e309c208d6ed0230d4ada5647e6e7ba51265c6cb0c20d4'
assert sha256(proof.read_bytes()).hexdigest()=='02656a5af88ce32d13ca374e7a4f4f35ac08a8e37b0172c8dd11688da7ed07bd'
assert checker.verify(source,target,proof,True)==(7,17,550,35,280870,32444)
a=archive/'author'
prior=a/'41'/'author-case41.tsv'
assert sha256(prior.read_bytes()).hexdigest()=='ed78de33588d8e37299f16ccfd55680f467a3f221583efab9cf975216fff0c5c'
row=next(x.split('\t') for x in prior.read_text().splitlines() if x.startswith('7\t'))
assert row[1:3]==['80','497664']
re,im=map(Fraction,row[3:5])
scale=checker.N*16*4**64
raw=re*scale,im*scale
assert all(n.denominator==1 for n in raw)
source_audit=(archive/'independent'/'41'/'audit.out').read_text()
assert f'PASS independent paired case 41 slice 7 (80,) 497664 exact normalized {re} {im}' in source_audit
current=(a/'45'/'slice-7-equivalence.out').read_text()
assert f'raw Gaussian numerator {raw[0]} {raw[1]} factor denominator {checker.N}' in current
assert f'exact normalized real {re} imaginary {im}' in current
print('Complete signed row equivalence for cut 45 inner80 with independently accepted cut 41 source')
print('exact normalized real',re,'imaginary',im)
