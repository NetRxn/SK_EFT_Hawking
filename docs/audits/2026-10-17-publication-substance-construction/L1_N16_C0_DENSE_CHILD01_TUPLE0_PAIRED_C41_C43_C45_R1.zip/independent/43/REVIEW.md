# Independent review of paired outer coordinate 43

The independently verified signed contribution of outer coordinate `(24,(2,))` in group128 descendant `(0,1)`, tuple 0 is `-1000730277528745670596611/2596148429267413814265248164610048 + 0i`. The raw Gaussian subtotal is `(-85022336643374434227239152407501989670736609570944839708061990912,0)` over factor denominator `40512224221827380280140849737629696`. The common positive external normalization `1/(16*4^64)` is applied once. This acceptance covers outer coordinate 43.

The named continuity revision matched publication checkpoint `fe9c541837a515e4bfd09bee3039443673626c12`. The two disjoint binary-selector inputs use the accepted hashes and share six environment factors. The independent census recovers all 48 coordinates and 6,427,904 compatible products per original branch. A condition-first signed constructor indexed the opposite factor and reconstructed every one of the seven combined tables using 212,688 products per branch. Their sum has 154,656 retained pair rows. The original constructor, outer reduction and refusal reproduced byte for byte. The combined input SHA-256 is `70593dc9a86c628589952c276248ae7cfc7e98279530bf933c81cdf73f3a7b49` and the retained cap SHA-256 is `c4e4401a9f6f690d3c53b4957c7a23e95dec6e0f4a9fb1ed12084343c5f11a94`. Independent reconstruction took 2.65 s. Constructor, reduction and refusal readbacks took 2.041, 9.394 and 2.950 s wall respectively.

The inner census recovered nine disjoint coordinates with 2,280,960 compatible products. Every exact inverse lift recovered the original conditioned rows, keys, axes, signed Gaussian coefficients and denominators. The 5 generic terminals were verified with independent sparse Gaussian contraction. The alternate schedules were slice 2 used triangle pivot 1, with author pivot 0, slice 3 used triangle pivot 1, with author pivot 0, slice 7 used four-factor pair (1, 2), with author pair (1, 3) and slice 8 used four-factor pair (1, 2), with author pair (1, 3). All 32 author shard receipts passed exact interval coverage and independent candidate-work counts. An independent contraction in each original shard interval matched every raw Gaussian pair and normalized pair. These additional replays took 94.735555 summed wall seconds. The signed ledger gives the route, raw value, projected work and observed work per slice.

The 53 generic inner commands across 22 stages reproduced each log and saved checkpoint byte, preserving all 17 refusals. Their summed wall duration was 322.426079 s under concurrent execution. The independent terminal replays used 107,412,096 products and 90.443866 summed wall seconds. The author terminal receipts record 138,831,097 products. Terminal work totals exclude generic work performed before a refusal. The signed ledger and timing tables preserve per-slice measurements.

Verify the portable receipts from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B tools/ledger-metrics.py 43 | cmp - signed-ledger.tsv
python3 -B tools/summarize.py | cmp - summary.out
python3 -B tools/audit-shard-raw.py | cmp - shard-raw-ledger.tsv
```

The three operand inventories bind the original binary and text files on the author scratch path. Full recalculation of the binary lineage requires those pinned files. The portable manifest contains the selected receipts, hashes, timings, authority checks and review scripts.
