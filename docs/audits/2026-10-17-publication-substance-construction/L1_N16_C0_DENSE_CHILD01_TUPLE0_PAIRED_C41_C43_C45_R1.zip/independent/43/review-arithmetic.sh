#!/usr/bin/env bash
set -euo pipefail
p=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe43-inner
until test -f "$p/terminal-plan.tsv" && test -s "$p/wall-timing.tsv" &&
      test "$(wc -l < "$p/primary.tsv")" -eq 9; do sleep 5; done
python3 -B rescue-source-pins.py 43 > rescue-source-pins.out
python3 -B -u replay-all.py 43 0 1 2 3 4 5 6 7 8 > replay-timing.tsv

until test -s "$p/author-case43.tsv" && test "$(wc -l < "$p/author-case43.tsv")" -eq 10; do sleep 5; done
python3 -B freeze-inputs.py 43
for prefix in source paired inner; do
  shasum -a 256 -c "$prefix-operands.sha256" > "$prefix-operands-verify.out"
done
/usr/bin/time -p python3 -B audit.py 43 > audit.out 2> audit.time
python3 -B verify-shard-coverage.py 43 > shard-coverage.out
python3 -B ledger-metrics.py 43 > signed-ledger.tsv
