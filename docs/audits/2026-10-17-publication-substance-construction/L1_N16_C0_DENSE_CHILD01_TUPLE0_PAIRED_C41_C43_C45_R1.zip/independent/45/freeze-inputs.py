from hashlib import file_digest
from pathlib import Path
from shutil import copyfile
from sys import argv

case=int(argv[1])
root=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
pair=root/'tuple0-pair-equivalence'
inner=pair/f'probe{case}-inner'
report=Path.cwd()
tracked={'.out','.roster','.tsv','.py'}
paired=[p for p in sorted(pair.iterdir()) if p.is_file() and
        (p.stem.endswith(str(case)) or f'sum{case}-' in p.name or p.name in
         ('sum-branches.py','sum-branches-checked.py','reduce-label-frontier.py','contract-reduced-label.py'))]
paired.extend((pair/'checkpoint/quotient.py',))
inner_paths=[p for p in sorted(inner.iterdir()) if p.is_file() and p.suffix in tracked|{'.pkl'}]
inner_paths.extend((inner/'checkpoint/quotient.py',inner/'slice-7-witness.pkl.gz'))
sources=[*sorted(root.glob('row-cap-physical-slice-dense-label-tuple0-branch-*-reduced.pkl')),
         root/'tuple0-branch0-pilot/pilot.roster']
assert len(sources)==3 and (inner/f'author-case{case}.tsv') in inner_paths
for label,base,paths in (('paired',pair,paired),('inner',inner,inner_paths),('source',root,sources)):
    with (report/f'{label}-operands.sha256').open('w') as manifest:
        for path in paths:
            with path.open('rb') as source:
                digest=file_digest(source,'sha256').hexdigest()
            print(digest,path,sep='  ',file=manifest)
            if path.suffix in tracked:
                target=report/'author-receipts'/label/path.relative_to(base)
                target.parent.mkdir(exist_ok=True,parents=True)
                copyfile(path,target)
