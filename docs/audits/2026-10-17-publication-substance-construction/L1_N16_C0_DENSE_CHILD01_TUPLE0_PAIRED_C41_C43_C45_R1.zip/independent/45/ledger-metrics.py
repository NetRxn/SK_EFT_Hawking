from fractions import Fraction
from pathlib import Path
from re import search
from sys import argv

author = Path('author-receipts/inner')
rows = (author/f'author-case{argv[1]}.tsv').read_text().splitlines()
methods = {r.split('\t')[0]:r.split('\t')[1] for r in Path('replay-timing.tsv').read_text().splitlines()}
print('slice','inner_coordinate','matched_outer_products','method','raw_real','raw_imaginary','norm_real','norm_imaginary','review_products','review_probes','review_wall_seconds','author_terminal_products','author_terminal_probes',sep='\t')
raw_sums=[0,0]
for row in rows[:-1]:
    index, cut, count, re, im, receipt = row.split('\t')
    method = methods[index]
    replay = Path(f'slice-{index}-triangle-replay.out' if method=='triangle' else f'slice-{index}-four-replay.out' if method=='four' else f'slice-{index}-replay.out').read_text()
    x,y,d = map(int,search(r'raw(?: scalar numerator)? (-?\d+) (?:imaginary )?(-?\d+) factor denominator (\d+)',replay).groups())
    assert d==40512224221827380280140849737629696
    assert (Fraction(x,d*16*4**64),Fraction(y,d*16*4**64))==tuple(map(Fraction,(re,im)))
    raw_sums[0]+=x
    raw_sums[1]+=y
    if method in ('triangle','four'):
        if method=='triangle':
            products,seconds=search(r'Gaussian products (\d+) wall seconds (\S+)',replay).groups()
            probes=search(r'independent pivot \d+ probes (\d+)',replay)[1]
        else:
            products,probes,seconds=search(r'total products (\d+) total probes (\d+) seconds (\S+)',replay).groups()
        if receipt=='slice-7-equivalence.out':
            assert index=='7' and method=='four'
            author_work=[]
        else:
            author_work = [tuple(map(int,search(r'closure products (\d+) retained outer matches (\d+) closure probes (\d+)',
                              (author/f'slice-{index}-shard-{i}.out').read_text()).groups())) for i in range(8)]
        author_products=sum(p+2*m for p,m,_ in author_work)
        author_probes=sum(q for _,_,q in author_work)
    else:
        products,seconds=search(r'independent matched products (\d+) wall seconds (\S+)',replay).groups()
        probes='-'
        author_products=search(r'matched products (\d+)',(author/receipt).read_text())[1]
        author_probes='-'
    print(index,cut,count,method,x,y,re,im,products,probes,seconds,author_products,author_probes,sep='\t')
assert tuple(Fraction(n,d*16*4**64) for n in raw_sums)==tuple(map(Fraction,rows[-1].split('\t')[1:]))
print('subtotal','-','-','-',*raw_sums,*rows[-1].split('\t')[1:],sep='\t')
