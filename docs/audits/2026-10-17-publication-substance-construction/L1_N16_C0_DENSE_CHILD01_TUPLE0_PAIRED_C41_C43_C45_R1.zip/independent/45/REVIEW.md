# Independent review of paired outer coordinate 45

The independently verified signed contribution of outer coordinate `(129,(2,))` in group128 descendant `(0,1)`, tuple 0 is `-266847350733101695525209/649037107316853453566312041152512 + 0i`. The raw Gaussian subtotal is `(-90685715405550629225743508361128689353451475050990193923023962112,0)` over factor denominator `40512224221827380280140849737629696`. The common positive external normalization `1/(16*4^64)` is applied once. This acceptance covers outer coordinate 45.

The named continuity revision matched publication checkpoint `fe9c541837a515e4bfd09bee3039443673626c12`. The two disjoint binary-selector inputs use the accepted hashes and share six environment factors. The independent census recovers all 48 coordinates and 6,427,904 compatible products per original branch. A condition-first signed constructor indexed the opposite factor and reconstructed every one of the seven combined tables using 212,688 products per branch. Their sum has 154,656 retained pair rows. The original constructor, outer reduction and refusal reproduced byte for byte. The combined input SHA-256 is `202dc1476a231040010a469d30e961ce1369d9e9867f7b745824b30ce52c0604` and the retained cap SHA-256 is `96e4a6d5a1ded80f474b4b89f9030615624bee8e59428a2b3cd8cf8544fdd176`. Independent reconstruction took 2.36 s. Constructor, reduction and refusal readbacks took 1.815, 8.421 and 2.975 s wall respectively.

The inner census recovered nine disjoint coordinates with 2,280,960 compatible products. Every exact inverse lift recovered the original conditioned rows, keys, axes, signed Gaussian coefficients and denominators. The 5 generic terminals were verified with independent sparse Gaussian contraction. The alternate schedules were slice 2 used triangle pivot 1, with author pivot 0, slice 3 used triangle pivot 1, with author pivot 0 and slice 8 used four-factor pair (1, 2), with author pair (1, 3). All 24 author shard receipts passed exact interval coverage and independent candidate-work counts. An independent contraction in each original shard interval matched every raw Gaussian pair and normalized pair. Slice 7 used no author shards. Its inherited cut 41 term was audited by matching the original conditioned seven-factor inputs with an exact row and edge-sign witness, then separately evaluating the exact cut 45 four-factor terminal from pair (1,2). These additional replays took 47.073643 summed wall seconds. The signed ledger gives the route, raw value, projected work and observed work per slice.

The 53 generic inner commands across 22 stages reproduced each log and saved checkpoint byte, preserving all 17 refusals. Their summed wall duration was 302.922885 s under concurrent execution. The independent terminal replays used 107,412,096 products and 69.025244 summed wall seconds. The author terminal receipts record 110,329,489 products. Terminal work totals exclude generic work performed before a refusal. The signed ledger and timing tables preserve per-slice measurements. The first byte comparison reached an author rescue before its receipt existed. The checker resumed the already-recorded stages and required the final author bytes to match before acceptance. Timings cover command execution.

Verify the portable receipts from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B tools/ledger-metrics.py 45 | cmp - signed-ledger.tsv
python3 -B tools/summarize.py | cmp - summary.out
python3 -B tools/audit-shard-raw.py | cmp - shard-raw-ledger.tsv
```

The three operand inventories bind the original binary and text files on the author scratch path. Full recalculation of the binary lineage requires those pinned files. The portable manifest contains the selected receipts, hashes, timings, authority checks and review scripts.
