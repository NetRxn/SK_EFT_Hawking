#!/usr/bin/env bash
set -euo pipefail
base=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe45-inner
test "$(wc -l < "$base/terminal-plan.tsv" | tr -d ' ')" = 3
python3 -B -u replay-all.py 45 2 3 4 5 6 8 > replay-rescue-final.tsv 2> replay-rescue-final-messages.out
python3 -B -u replay-author-raw.py > shard-raw-timing.tsv
