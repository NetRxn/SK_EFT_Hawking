from collections import Counter, defaultdict
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads
from re import MULTILINE, search
from sys import argv

N = 40512224221827380280140849737629696

def verify(left_path,right_path,witness,with_signs):
    perm,old_axes,new_axes,maps,*charge = loads(decompress(witness.read_bytes()))
    assert len(charge)==int(with_signs)
    negative = {edge:set(values) for edge,values in charge[0].items()} if charge else {}
    L,R=[loads(path.read_bytes())['factors'] for path in (left_path,right_path)]
    assert sorted(perm)==list(range(len(R))) and len(L)==len(R)
    R=[R[i] for i in perm]
    assert set(old_axes)==set(new_axes)==set(maps)
    assert set(negative)<=set(maps)
    for factors, scopes in ((L,old_axes),(R,new_axes)):
        assert prod(d for _,_,d in factors)==N
        assert all(n==2 for n in Counter(axis for ws,_,_ in factors for axis in ws).values())
        for i,(axes,_,_) in enumerate(factors):
            configured=[q for edge,ws in scopes.items() if i in edge for q in ws]
            assert len(axes)==len(set(configured))==len(configured) and set(axes)==set(configured)
        for (i,j),edge_axes in scopes.items():
            assert 0<=i<j<len(factors)
            assert edge_axes and set(edge_axes)==set(factors[i][0]) & set(factors[j][0])
    for edge,m in maps.items():
        assert len(m)==len(set(m.values()))
        assert set(negative.get(edge,())) <= set(m)
    seen=defaultdict(set)
    checked=flipped=0
    for i,((axes,A,d),(targets,B,e)) in enumerate(zip(L,R,strict=True)):
        assert len(A)==len(B) and d==e
        edges=[]
        for edge in sorted(maps):
            if i in edge:
                here=tuple(axes.index(w) for w in old_axes[edge])
                there=tuple(targets.index(w) for w in new_axes[edge])
                edges.append((edge,here,there))
        for row,(x,y) in A.items():
            candidate=[None]*len(targets)
            sign=1
            for edge,here,there in edges:
                local=tuple(row[p] for p in here)
                mapped=maps[edge][local]
                for k,value in zip(there,mapped,strict=True):
                    candidate[k]=value
                seen[edge].add(local)
                if local in negative.get(edge,()):
                    sign=-sign
            assert (x or y) and B[tuple(candidate)]==(sign*x,sign*y)
            flipped+=sign<0
            checked+=1
        # Full domain bijection makes the row map injective on the axis cover.
        # Equal table sizes and every exact target lookup then establish surjectivity.
    assert all(seen[edge]==set(m) for edge,m in maps.items())
    return len(L),len(maps),sum(map(len,maps.values())),sum(map(len,negative.values())),checked,flipped


source=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
left=source/'probe41-inner/slice-7.pkl'
right=source/'probe45-inner/slice-7.pkl'
cert=Path('slice-7-equivalence-witness.pkl.gz')
for p,h in ((left,'18e18115c2e69d173bb80021c04032aa167176457b2d1fb5b6c5027195b934a1'),
            (right,'00101c64996a61e8b1e309c208d6ed0230d4ada5647e6e7ba51265c6cb0c20d4'),
            (cert,'02656a5af88ce32d13ca374e7a4f4f35ac08a8e37b0172c8dd11688da7ed07bd')):
    assert sha256(p.read_bytes()).hexdigest()==h
    print('SHA256',h,p)
a,b=(loads(p.read_bytes()) for p in (left,right))
condition=({k:v for k,v in s['conditioning']} for s in (a,b))
x,y=condition
assert x['G',0,4,2]==17 and y['G',0,4,2]==129
assert {k:v for k,v in x.items() if k!=('G',0,4,2)}=={k:v for k,v in y.items() if k!=('G',0,4,2)}
assert x['G',0,1,2]==80 and x['J',1,4,2]==(2,)
assert a['label_partition']==b['label_partition'] and a['physical_cut']==b['physical_cut']
statistics=verify(left,right,cert,True)
assert statistics[0]==7 and statistics[4]==280870
print('PASS raw witness factors edges values sign-values rows sign-rows',*statistics)
if '--raw-only' in argv:
    raise SystemExit(0)
checkpoint=Path('/private/tmp/l1-paired41-independent.v7HlhJ')
manifest=checkpoint/'review-manifest.sha256'
catalog={name.removeprefix('./'):digest for digest,name in (r.split(maxsplit=1) for r in manifest.read_text().splitlines())}
prior=checkpoint/'slice-7-four-replay.out'
assert sha256(prior.read_bytes()).hexdigest()==catalog[prior.name]
print('accepted review manifest',sha256(manifest.read_bytes()).hexdigest(),manifest)
print('accepted exact prior term',catalog[prior.name],prior)
pattern=r'exact normalized real (\S+) imaginary (\S+)'
values=lambda p:tuple(map(Fraction,search(pattern,p.read_text()).groups()))
receipt=source/'probe45-inner/slice-7-equivalence.out'
direct=Path('slice-7-four-replay.out')
report=receipt.read_text()
prior_manifest_sha=sha256(manifest.read_bytes()).hexdigest()
ledger_path=source/'probe41-inner/author-case41.tsv'
prior_ledger_sha=sha256(ledger_path.read_bytes()).hexdigest()
assert f'accepted source review manifest {prior_manifest_sha}' in report
assert f'source ledger {prior_ledger_sha}' in report
assert sha256(left.read_bytes()).hexdigest() in report
assert sha256(right.read_bytes()).hexdigest() in report
assert sha256(cert.read_bytes()).hexdigest() in report
assert values(prior)==values(receipt)==values(direct)
raw=tuple(map(int,search(r'^raw (-?\d+) (-?\d+) factor denominator (\d+)$',direct.read_text(),MULTILINE).groups()))
source_raw=tuple(map(int,search(r'raw Gaussian numerator (-?\d+) (-?\d+) factor denominator (\d+)',report).groups()))
assert raw==source_raw and raw[2]==N
assert tuple(Fraction(n,N*16*4**64) for n in raw[:2])==values(direct)
print('PASS exact raw equivalence values and external normalization',*raw)
print('PASS exact cut 41 prior value matches cut 45 certificate receipt and independent alternate pair',*values(direct))
