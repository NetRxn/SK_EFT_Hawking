#!/usr/bin/env bash
set -euo pipefail
base=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe45-inner
python3 -B freeze-inputs.py 45
for group in source paired inner; do
  shasum -a 256 -c "$group-operands.sha256" > "$group-operands-verify.out"
done
cat replay-{primary,rescue-initial,rescue-final,equivalence-direct}.tsv | sort -k1,1n > replay-timing.tsv
test "$(wc -l < replay-timing.tsv | tr -d ' ')" = 9
python3 -B verify-equivalence.py > equivalence-verify.out
python3 -B audit.py 45 > audit.out
python3 -B verify-shard-coverage.py 45 > shard-coverage.out
for attempt in {1..60}; do
  if [ "$(wc -l < shard-raw-timing.tsv | tr -d ' ')" = 3 ]; then break; fi
  sleep 1
done
test "$(wc -l < shard-raw-timing.tsv | tr -d ' ')" = 3
python3 -B audit-shard-raw.py > shard-raw-ledger.tsv
test "$(wc -l < shard-raw-ledger.tsv | tr -d ' ')" = 25
python3 -B ledger-metrics.py 45 > signed-ledger.tsv
python3 -B rescue-source-pins.py 45 > rescue-source-pins.out
python3 -B - "$base" <<'PY' > terminal-inventory.tsv
import sys
from hashlib import sha256
from pathlib import Path
from pickle import loads
from terminal_plan import plans
author=Path(sys.argv[1])
seen=set()
print('slice','coordinate','terminal','sha256','factors','rows',sep='\t')
term=plans(author)
for row in (author/'author-case45.tsv').read_text().splitlines()[:-1]:
    i,coord,_,_,_,result=row.split('\t')
    if result=='slice-7-equivalence.out':
        assert i=='7' and int(i) not in term
        p=author/'row-cap-physical-slice-dense-label-rescue-7-1-reduced.pkl'
    else:
        p=term[int(i)][0] if int(i) in term else author/f'label-{result.removesuffix("-contract.out")}-reduced-frontier.pkl'
    raw=p.read_bytes()
    v=sha256(raw).hexdigest()
    assert v not in seen
    seen.add(v)
    s=loads(raw)
    conditions=dict(s['conditioning'])
    assert (conditions['G',0,4,2],conditions['J',1,4,2],conditions['G',0,1,2])==(129,(2,),int(coord))
    print(i,coord,p.name,v,len(s['factors']),sum(len(rows) for _,rows,_ in s['factors']),sep='\t')
assert len(seen)==9
PY
for attempt in {1..90}; do
  test ! -s inner-lineage-errors.out
  if [ "$(cut -f1 inner-lineage.tsv | sort -u | wc -l | tr -d ' ')" = 9 ]; then break; fi
  sleep 1
done
test "$(cut -f1 inner-lineage.tsv | sort -u | wc -l | tr -d ' ')" = 9
python3 -B finalize.py 45
shasum -a 256 review-manifest.sha256
