from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
from validation.checks import prose_lean_refs as refs

root = Path(sys.argv[1])
bundles = {}
for code in refs.BUNDLE_CODES:
    base = root / "base/papers" / code / "paper_draft.tex"
    candidate = root / "candidate/papers" / code / "paper_draft.tex"
    original = base.read_text()
    migrated = candidate.read_text()
    base_tables = list(refs._bundle_table_sources(base, original))
    new_tables = list(refs._bundle_table_sources(candidate, migrated))
    assert all(err is None for _, _, err in base_tables + new_tables)
    expected = Counter(token for token, _ in refs._prose_verbatim_tokens(original))
    got = Counter(token for token, _ in refs._prose_verbatim_tokens(migrated))
    for path, content, _ in new_tables:
        assert path.parts[0] == "tables"
        got.update(token for token, _ in refs._prose_verbatim_tokens(content, macro_source=migrated))
    assert expected == got, code
    bundles[code] = {"occurrences": sum(got.values()), "distinct": len(got),
                     "occurrence_fingerprint": hashlib.sha256(json.dumps(got, sort_keys=True).encode()).hexdigest(),
                     "base_direct": len(base_tables), "candidate_direct": len(new_tables)}
summary = {"bundles": bundles, "totals": {key: sum(row[key] for row in bundles.values())
                                          for key in ("occurrences", "base_direct", "candidate_direct")}}
print(json.dumps(summary, indent=2))
