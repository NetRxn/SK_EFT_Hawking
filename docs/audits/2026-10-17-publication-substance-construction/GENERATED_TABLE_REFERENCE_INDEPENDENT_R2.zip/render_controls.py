import json
from pathlib import Path
import subprocess
import sys

from validation.checks.prose_lean_refs import _direct_table_inputs

workspace = Path(sys.argv[1])
cases = {
    "canonical": r"\input{tables/witness}",
    "dot_path": r"\input{./tables/witness}",
    "newif": r"\newif\ifreviewflag\input{tables/witness}",
    "false_branch": r"\iffalse\input{tables/witness}\fi",
    "ordinary_if_named_macro_before_input": r"\ifthenelse{1=1}{True}{False}\input{tables/witness}",
    "ordinary_if_named_macro_in_skipped_branch": r"\iffalse\ifthenelse{1=1}{True}{False}\else\input{tables/witness}\fi",
    "macro_argument_discard": r"\newcommand{\discardreview}[1]{}\discardreview{\input{tables/witness}}",
    "definition_inside_skipped_branch": r"\iffalse\def\discardreview{\fi\input{tables/witness}\iffalse}\fi",
    "live_constructed_definition": r"\expandafter\def\csname reviewinput\endcsname{\input{tables/witness}}\reviewinput",
}
receipts = {}
for name, body in cases.items():
    source = (
        "\\documentclass{article}\n\\usepackage{ifthen}\n\\begin{document}\nBaseline.\n"
        + body + "\n\\end{document}\n"
    )
    (workspace / (name + ".tex")).write_text(source)
    built = subprocess.run(
        ["pdflatex", "-halt-on-error", "-interaction=batchmode", name + ".tex"],
        cwd=workspace, capture_output=True,
    )
    rendered = None
    if built.returncode == 0:
        pdf = subprocess.check_output(["pdftotext", str(workspace / (name + ".pdf")), "-"], text=True)
        rendered = "VISIBLE INDEPENDENT WITNESS" in pdf
        (workspace / (name + ".txt")).write_text(pdf)
    receipts[name] = {
        "tex_exit": built.returncode,
        "visible_witness": rendered,
        "reader_events": list(_direct_table_inputs(source)),
    }
print(json.dumps(receipts, indent=2))
