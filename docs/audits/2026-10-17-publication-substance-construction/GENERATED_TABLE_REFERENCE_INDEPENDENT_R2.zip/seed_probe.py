from contextlib import ExitStack
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from seed_journal import outstanding, seeded_mutation

scratch = Path(sys.argv[1]).resolve()
draft = Path("papers/D9/paper_draft.tex").resolve()
table = Path("papers/D9/tables/exact.tex").resolve()
saved = {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in (draft, table)}
old_journal = outstanding(include_live=True)
old = r"\lean{diamondDist\_dephasing\_eq}"
new = r"\lean{d9\_independent\_r2\_missing\_probe}"
tag = "unresolved:D9:d9_independent_r2_missing_probe"

def table_mutation(contents):
    assert contents.count(old) == 1
    assert contents[:contents.index(old)].count("\n") + 1 == 9
    return contents.replace(old, new)

def draft_mutation(contents):
    usepackage = r"\usepackage{graphicx}"
    direct = r"\input{tables/exact.tex}"
    adverse = r"\iffalse\ifthenelse{1=1}{True}{False}\else" + direct + r"\fi"
    assert contents.count(usepackage) == contents.count(direct) == 1
    return contents.replace(usepackage, usepackage + "\n" + r"\usepackage{ifthen}").replace(direct, adverse)

receipts = {}
for case in ("canonical", "skipped_macro_branch"):
    with ExitStack() as guard:
        guard.enter_context(seeded_mutation(table, table_mutation, reason=f"independent D9 R2 {case}"))
        if case != "canonical":
            guard.enter_context(seeded_mutation(draft, draft_mutation, reason="independent D9 if-named macro probe"))
        result = subprocess.run([sys.executable, "-B", "scripts/validate.py", "--check",
            "prose_theorem_reference_coverage", "--json"], capture_output=True, text=True)
        (scratch / f"{case}-cli.json").write_text(result.stdout)
        (scratch / f"{case}-cli.stderr").write_text(result.stderr)
        check = json.loads(result.stdout)["checks"]["prose_theorem_reference_coverage"]
        matching = [d for d in check["details"] if d["name"] == tag]
        if case == "canonical":
            assert result.returncode == 1 and not check["passed"] and check["measured"]
            assert len(matching) == 1 and not matching[0]["passed"] and not matching[0]["warning"]
            assert "papers/D9/tables/exact.tex:9" in matching[0]["message"]
        else:
            assert result.returncode == 0 and check["passed"] and check["measured"] and not matching
        render_dir = scratch / ("render-" + case)
        render_dir.mkdir()
        render = subprocess.run(["pdflatex", "-halt-on-error", "-interaction=batchmode",
            f"-output-directory={render_dir}", draft.name], cwd=draft.parent, capture_output=True)
        (render_dir / "stdout.log").write_bytes(render.stdout + render.stderr)
        visible = None
        if render.returncode == 0:
            text = subprocess.check_output(["pdftotext", "-layout", str(render_dir / "paper_draft.pdf"), "-"], text=True)
            (render_dir / "draft.txt").write_text(text)
            visible = "d9_independent_r2_missing_probe" in text
        receipts[case] = {"cli_exit": result.returncode, "passed": check["passed"], "measured": check["measured"],
                          "finding": matching, "tex_exit": render.returncode, "visible_seed": visible}
    assert outstanding(include_live=True) == old_journal
    for p, (data, mtime) in saved.items():
        assert p.read_bytes() == data
        assert p.stat().st_mtime_ns == mtime
receipts["restoration"] = {str(p.relative_to(Path.cwd())): {"sha256": sha256(data).hexdigest(),
    "mtime_ns": mtime} for p, (data, mtime) in saved.items()}
receipts["journal_restored"] = True
print(json.dumps(receipts, indent=2))
