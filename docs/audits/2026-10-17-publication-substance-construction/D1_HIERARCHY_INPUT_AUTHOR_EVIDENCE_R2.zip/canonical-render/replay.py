from contextlib import nullcontext
from pathlib import Path
import re
import shutil
import subprocess
import sys

from seed_journal import seeded_mutation

root = Path.cwd()
destination = Path(sys.argv[1])
destination.mkdir()
draft = root / "papers/D1/paper_draft.tex"
original = draft.read_bytes()
label = rb"\label{tab:hierarchy}"
start = original.rfind(rb"\begin{table*}", 0, original.index(label))
end = original.index(rb"\end{table*}", start) + len(rb"\end{table*}")
assert 0 <= start < original.index(label) < end
seeded = original[:start] + rb"\iffalse" + b"\n" + original[start:end] + b"\n" + rb"\fi" + original[end:]
for case, mutation in (
    ("active", nullcontext()),
    ("whole-float-inactive", seeded_mutation(draft, seeded, reason="D1 rendered hierarchy absence control")),
    ("restored", nullcontext()),
):
    out = destination / case
    out.mkdir()
    expected_present = case != "whole-float-inactive"
    with mutation:
        returns = {}
        for name, args in (
            ("numeric", ["scripts/validate.py", "--check", "d1_hierarchy_table"]),
            ("compile", ["scripts/compile_bundle_pdf.py", "D1", "--force"]),
        ):
            proc = subprocess.run([sys.executable, *args], text=True, stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT)
            (out / f"{name}.log").write_text(proc.stdout)
            returns[name] = proc.returncode
            if name == "numeric" or expected_present:
                assert proc.returncode == 0, proc.stdout
            else:
                assert proc.returncode == 1 and "tex_errors=0" in proc.stdout, proc.stdout
        pdf = root / "papers/D1/paper_draft.pdf"
        shutil.copyfile(pdf, out / "paper_draft.pdf")
        subprocess.run(["pdftotext", "-layout", str(pdf), str(out / "pdf.txt")], check=True)
        lines = (out / "pdf.txt").read_text().splitlines()
        row_patterns = (
            r"Rb BEC \(Steinhauer/de Nova\).*8\.53.*2\.38",
            r"K BEC \(Heidelberg, projected\).*7\.32.*1\.59",
            r"spin-sonic BEC \(Trento\).*9\.89.*1\.41",
        )
        rows = [[line.strip() for line in lines if re.search(pattern, line)] for pattern in row_patterns]
        assert all(len(row) == int(expected_present) for row in rows), rows
        (out / "rows.txt").write_text("\n".join(row[0] for row in rows if row) + "\n")
        print(case, returns, "row_matches", [len(row) for row in rows], flush=True)
    assert draft.read_bytes() == original
