# D1 generated hierarchy binding revision

The R1 implementation identifies an input token even when TeX skips it.
The generated branch will instead require a direct canonical input as the
entire post-label body. The pre-label float content will accept only optional
standard placement, centering, and one balanced caption. Within that caption,
retain the control words used by the current D1 prose and math and ordinary
escaped punctuation. This keeps pre-label command redefinitions and conditional
or deferred input out of the supported local syntax. The historical inline
branch and the numerical comparisons remain unchanged. The repository's
compiler and PDF row evidence cover rendering and the outer TeX context.
