"""Exact bounded quartic controls for the original fixed-center R10 seam."""
from collections import defaultdict
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
from pathlib import Path
import json
import random
import sys

HERE = Path(__file__).parent
spec = spec_from_file_location("r10_quartic_inputs", HERE / "publication-task4-continuation-powers-r10.py")
r10 = module_from_spec(spec)
sys.modules[spec.name] = r10
spec.loader.exec_module(r10)
r5, r6, r7, r8 = r10.r5, r10.r6, r10.r7, r10.r8
Q, P, E, SLOTS = r10.Q, r10.P, r10.E, r10.SLOTS
ZERO = Q(0)
ONE = Q(1)
POWER = (4, 0)

class Admission:
    def __init__(self, cap):
        self.cap = cap
        self.peak = 0

    def check(self, requested):
        if requested > self.cap:
            raise RuntimeError(f"quartic local cap: prospective {requested}, cap {self.cap}")
        self.peak = max(self.peak, requested)

def add_term(table, key, coefficient, paths, admission, fixed=0):
    old = table.get(key)
    if old is None:
        admission.check(fixed + len(table) + 1)
        table[key] = coefficient, paths
    else:
        table[key] = old[0] + coefficient, old[1] + paths

def split(center):
    first = center & -center
    rest = [1 << i for i in range(center.bit_length()) if (1 << i) & (center ^ first)]
    for three in combinations(rest, 3):
        half = first | sum(three)
        yield half, center ^ half

def partitioned_quartic(vertices, wanted, center, work, admission):
    """Join distinct complementary center halves; retain one live pair at a time."""
    assert center.bit_count() == 8
    output = {}
    two_bit_buckets = defaultdict(list)
    for state in vertices:
        mask, _ = state
        cm = mask & center
        assert cm.bit_count() == 2
        admission.check(len(vertices) + len(wanted) + sum(map(len, two_bit_buckets.values())) + 1)
        # Store the key only; signed coefficients live in vertices.
        two_bit_buckets[cm].append(state)
    fixed = len(vertices) + len(wanted) + sum(map(len, two_bit_buckets.values()))
    # wanted is passed by the caller, and already counted above. Its exact
    # keys partition the requested quartic coefficients.
    for left_center, right_center in split(center):
        def pairs(half_center, other):
            half = {}
            for first_center, first_keys in two_bit_buckets.items():
                if first_center & half_center != first_center:
                    continue
                second_center = half_center ^ first_center
                if first_center > second_center:
                    continue
                for am, ak in first_keys:
                    av, an = vertices[am, ak]
                    for bm, bk in two_bit_buckets.get(second_center, ()):
                        work.charge("quartic_half_pairs")
                        if am & bm:
                            continue
                        mask, symbols = am | bm, tuple(sorted(ak + bk))
                        for tm, tk in wanted:
                            work.charge("quartic_half_projection")
                            if mask & tm == mask and r5.subtract(tk, symbols) is not None:
                                break
                        else:
                            continue
                        ab = r5.mask_sign(am, bm)
                        ba = r5.mask_sign(bm, am)
                        bv, bn = vertices[bm, bk]
                        value = av * bv * Fraction(ab + ba, 2)
                        add_term(half, (mask, symbols), value, 2 * an * bn,
                                 admission, fixed + len(output) + len(other))
            return half

        left = pairs(left_center, ())
        if not left:
            del left
            continue
        right = pairs(right_center, left)
        if not right:
            del left, right
            continue
        # Index by the complete pair key. The residual target determines
        # at most one partner for each left coefficient and target.
        for tm, tk in wanted:
            for (lm, lk), (lv, ln) in left.items():
                work.charge("quartic_complement_tests")
                if lm & tm != lm:
                    continue
                rk = r5.subtract(tk, lk)
                if rk is None:
                    continue
                rm = tm ^ lm
                match = right.get((rm, rk))
                if match is None:
                    continue
                rv, rn = match
                lr, rl = r5.mask_sign(lm, rm), r5.mask_sign(rm, lm)
                value = lv * rv * Fraction(lr + rl, 6)
                add_term(output, (tm, tk), value, 2 * ln * rn,
                         admission, fixed + len(left) + len(right))
        del left, right
    return output

def direct_coefficients(vertices, wanted, center, work, admission):
    """Independent recursion over ordered raw exterior factors.

    At every recursion level the factor that owns the lowest surviving
    center bit is unique. The ordered draws of an unordered disjoint
    factor collection all have the same sign, so anchoring on that bit
    counts the collection once with the exponential weight already
    absorbed. No half-table or pair symmetry enters this oracle.
    """
    index = defaultdict(list)
    indexed = 0
    for state, (value, _) in vertices.items():
        if not value:
            continue
        mask, _ = state
        bits = mask & center
        assert bits.bit_count() == 2
        while bits:
            bit = bits & -bits
            admission.check(len(vertices) + len(wanted) + indexed + 1)
            index[bit].append(state)
            indexed += 1
            bits ^= bit
    result = {}
    memo = {}
    def coeff(mask, key):
        state = mask, key
        bits = mask & center
        if not bits:
            return ONE if not mask and not key else ZERO
        if state in memo:
            return memo[state]
        value = ZERO
        for vm, vk in index[bits & -bits]:
            work.charge("direct_anchored_factors")
            if vm & mask != vm:
                continue
            suffix = r5.subtract(key, vk)
            if suffix is not None:
                rest = mask ^ vm
                vv = vertices[vm, vk][0]
                value += vv * coeff(rest, suffix) * r5.mask_sign(vm, rest)
        # Cache only if capacity permits. Recursion remains exact when a
        # memo state is streamed instead. Account the one temporary state.
        live = len(vertices) + len(wanted) + indexed + len(result) + len(memo)
        if live + 6 <= admission.cap:
            admission.check(live + 6)
            memo[state] = value
        return value

    for mask, key in wanted:
        # Reserve one output row and five nested recursion frames.
        admission.check(len(vertices) + len(wanted) + indexed + len(result) + len(memo) + 6)
        result[mask, key] = coeff(mask, key)
    return result

def group_factors(target, coframes, traces, work):
    c = {key: r7.projection(poly, target, work) for key, poly in coframes.items()}
    for key, poly in traces.items():
        _, _, mu, nu, a, b = key
        h = r7.projection(poly, target, work)
        if c[mu, a] and c[nu, b] and h:
            yield key, (c[mu, a], c[nu, b], h)

def exterior_residuals(target, inputs, center, work, admission):
    cx, hx, _, _, contacts, cy, hy = inputs
    mask, symbols, slot = target
    d = r7.projection(contacts[slot], target, work)
    later = defaultdict(list)
    later_paths = 0
    for key, operands in group_factors(target, cy, hy, work):
        for ym, yk, _, yv in r10.stream_rows(operands, target, work):
            if ym & center:
                continue
            if later_paths + 1 > r10.LATER_CAP:
                raise RuntimeError(f"quartic later cap: prospective {later_paths + 1}")
            later[ym, yk].append((key, yv))
            later_paths += 1
    wanted = defaultdict(dict)
    records = 0
    for xkey, operands in group_factors(target, cx, hx, work):
        for xm, _, left, xv in r10.stream_rows((*operands, d), target, work):
            if xm & center:
                continue
            for ym, yk in later:
                work.charge("quartic_outer_tests")
                if xm & ym:
                    continue
                qm = mask ^ (xm | ym)
                qk = r5.subtract(left, yk)
                if qk is None or (qm & center) != center or qm.bit_count() != 16:
                    continue
                if qk.count(r10.G2) != 4 or len(qk) != 28:
                    continue
                pair = qm, qk
                grouped = wanted.get(pair)
                for ykey, yv in later[ym, yk]:
                    g = xkey, ykey
                    if grouped is None or g not in grouped:
                        prospective = records + 1 + len(wanted) + int(grouped is None)
                        admission.check(prospective)
                        records += 1
                        grouped = wanted[pair]
                    value = xv * yv * r5.mask_sign(xm, qm) * r5.mask_sign(xm | qm, ym)
                    prev = grouped.get(g)
                    grouped[g] = (value, 1) if prev is None else (prev[0] + value, prev[1] + 1)
    return wanted, records, later_paths

def production_vertices(target, inputs, wanted, work, admission, fixed):
    _, _, cw, choices, _, _, _ = inputs
    w = {key: r7.projection(poly, target, work) for key, poly in cw.items()}
    vertices = {}
    for key, (components, poly) in choices.items():
        if key[0] != 2 or not all(w[c] for c in components):
            continue
        trace = r7.projection(poly, target, work)
        for vm, vk, _, vv in r10.stream_rows((*[w[c] for c in components], trace), target, work):
            for qm, qk in wanted:
                work.charge("quartic_vertex_projection")
                if vm & qm == vm and r5.subtract(qk, vk) is not None:
                    add_term(vertices, (vm, vk), vv, 1, admission, fixed)
                    break
    return vertices

def raw_vertices(target, inputs, raw, work, admission, fixed):
    """Expand all original S2 orientations, including the canceled groups."""
    mask, symbols, _ = target
    from collections import Counter
    counts = Counter(symbols)
    _, _, cw, _, _, _, _ = inputs
    def restrict(poly):
        return r5.subset_factor(poly, mask, counts, work)
    w = {key: restrict(poly) for key, poly in cw.items()}
    rows = {}
    for raw_key, terms in raw.items():
        if raw_key[0] != 2:
            continue
        for term in terms:
            (_, mu, a), (_, nu, b) = term.components
            if not (w[mu, a] and w[nu, b]):
                continue
            partial = restrict(work.oracle_product(w[mu, a], w[nu, b]))
            trace = restrict(E(((0, term.coefficient * P.variable(r10.G2)),)))
            product = restrict(work.oracle_product(partial, trace))
            for vm, polys in product.terms:
                for vk, vv in polys.terms:
                    add_term(rows, (vm, vk), vv, 1, admission, fixed)
    return rows

def seeded_targets(inputs, d0, d1, work):
    """Reconstruct the frozen R10 RNG state and continue its target schedule."""
    cx, hx, cw, choices, _, cy, hy = inputs
    rng = random.Random(20261107)
    seen = set()
    for line in (HERE / "publication-task4-continuation-powers-r10.progress.jsonl").read_text().splitlines():
        row = json.loads(line)
        wanted = r6.decoded(row["target"])
        powers = tuple(row["powers"])
        d = d1 if row["direction"] else d0
        for core, _, attempt in r10.seed(powers, cx, hx, cw, choices, d, cy, hy, rng, work, seen):
            if core == wanted[:2]:
                assert attempt == row["attempt"]
                seen.add(core)
                break
        else:
            raise AssertionError(f"frozen R10 seed could not be reconstructed: {row['target']}")
    for slot, direction, d in ((SLOTS[0], 0, d0), (SLOTS[1], 0, d0), (SLOTS[1], 1, d1)):
        core, seeded, attempt = next(r10.seed(POWER, cx, hx, cw, choices, d, cy, hy, rng, work, seen))
        seen.add(core)
        yield (*core, slot), direction, seeded, attempt

def witness(target, seed, inputs, work):
    from collections import Counter
    from math import factorial, prod
    cx, hx, cw, choices, contacts, cy, hy = inputs
    xkey, wkeys, ykey = seed
    mask, symbols, slot = target
    xs = dict(group_factors(target, cx, {xkey: hx[xkey]}, work))
    ys = dict(group_factors(target, cy, {ykey: hy[ykey]}, work))
    if xkey not in xs or ykey not in ys:
        return ZERO, 0
    w = {key: r7.projection(poly, target, work) for key, poly in cw.items()}
    factors = []
    for key in wkeys:
        components, trace = choices[key]
        factors.extend(w[c] for c in components)
        factors.append(r7.projection(trace, target, work))
    contact = r7.projection(contacts[slot], target, work)
    later = {}
    admission = Admission(r10.LATER_CAP)
    for ym, yk, _, yv in r10.stream_rows(ys[ykey], target, work):
        add_term(later, (ym, yk), yv, 1, admission)
    weight = Fraction(1, prod(factorial(n) for n in Counter(wkeys).values()))
    value, paths = ZERO, 0
    for xm, _, remaining, xv in r10.stream_rows((*xs[xkey], *factors, contact), target, work):
        ym = mask ^ xm
        yv, n = later.get((ym, remaining), (ZERO, 0))
        if n:
            work.charge("quartic_seed_matches")
            value += xv * yv * r5.mask_sign(xm, ym) * weight
            paths += n
    return value, paths


def validate_target(target, direction, seed, attempt, center, inputs, raw, work, remaining):
    admission = Admission(r10.LOCAL_CAP)
    wanted, outer_records, later_paths = exterior_residuals(target, inputs, center, work, admission)
    fixed = len(wanted) + outer_records
    # Keep one copy of each retained artifact. Feed the pair constructor
    # the reserved budget for the other live outer records.
    local_budget = Admission(r10.LOCAL_CAP - outer_records)
    vertices = production_vertices(target, inputs, wanted, work, admission, fixed)
    local = partitioned_quartic(vertices, wanted, center, work, local_budget)
    del vertices
    local_peak = max(admission.peak, outer_records + local_budget.peak)
    direct_budget = Admission(r10.LOCAL_CAP - outer_records - len(local))
    direct = raw_vertices(target, inputs, raw, work, direct_budget, len(wanted))
    reference = direct_coefficients(direct, wanted, center, work, direct_budget)
    del direct
    for key in wanted:
        assert local.get(key, (ZERO, 0))[0] == reference[key], key
    output = r10.SignedOutput(remaining)
    for key, groups in wanted.items():
        value, paths = local.get(key, (ZERO, 0))
        if paths:
            for group, (outer, n) in groups.items():
                output.put(group, value * outer, paths * n)
    selected = output.table.get((seed[0], seed[2]), (ZERO, 0))
    seeded_value, seeded_paths = witness(target, seed, inputs, work)
    return {
        "target": r5.fingerprint(target), "direction": direction, "attempt": attempt,
        "seed": seed, "seeded_xy_sum": str(selected[0]), "seeded_xy_paths": selected[1],
        "seeded_coefficient": str(seeded_value), "seeded_paths": seeded_paths,
        "coefficients": [(k, str(v), n) for k, (v, n) in sorted(output.table.items())],
        "total": str(sum((v for v, _ in output.table.values()), ZERO)),
        "quartic_local_keys": len(wanted), "later_paths": later_paths,
        "local_peak": max(local_peak, outer_records + len(local) + direct_budget.peak),
        "output_records": len(output.table),
    }

def run_original():
    work = r5.Work(cap=r10.WORK_CAP, oracle_record_cap=r10.PAIR_CAP)
    reg, (_, _, w), inputs, raw, d0, d1 = r10.setup(work)
    center = 255 << (8 * reg.site_number(w))
    output = HERE / "publication-task4-continuation-quartic-r11.original.jsonl"
    used = 0
    with output.open("x") as receipt:
        for target, direction, seeded, attempt in seeded_targets(inputs, d0, d1, work):
            print(json.dumps(dict(target=r5.fingerprint(target), direction=direction,
                                  seed=seeded, attempt=attempt)), file=sys.stderr, flush=True)
            row = validate_target(target, direction, seeded, attempt, center, inputs, raw,
                                  work, r10.OUTPUT_CAP - used)
            used += row["output_records"]
            print(json.dumps(row), file=receipt, flush=True)
        print(json.dumps(dict(work=dict(work.counts), work_total=work.used, output_records=used)),
              file=receipt, flush=True)

if __name__ == "__main__":
    if sys.argv[1:] != ["--root-admitted-original"]:
        raise SystemExit("Original replay requires ROOT admission and explicit mode")
    run_original()
