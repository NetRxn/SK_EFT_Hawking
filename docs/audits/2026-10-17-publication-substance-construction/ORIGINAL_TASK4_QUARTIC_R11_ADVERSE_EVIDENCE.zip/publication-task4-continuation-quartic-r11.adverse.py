"""Bounded independent arithmetic checks for the R11 partition and direct oracle."""
from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
from pathlib import Path
import json
import random
import sys

path = Path(__file__).with_name("publication-task4-continuation-quartic-r11.py")
spec = spec_from_file_location("r11_adverse_candidate", path)
m = module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)
Q = m.Q
center = 255
full = 65535

def sign_by_permutation(masks):
    positions = [i for mask in masks for i in range(mask.bit_length()) if mask & (1 << i)]
    return (-1) ** sum(a > b for i, a in enumerate(positions) for b in positions[i+1:])

def brute(vertices, target):
    tm, tk = target
    out = Q(0)
    n = 0
    negative = 0
    for drawn in product(vertices.items(), repeat=4):
        occupied = 0
        masks = []
        symbols = []
        coefficient = Q(1)
        paths = 1
        for (mask, key), (value, k) in drawn:
            if mask & occupied:
                break
            occupied |= mask
            masks.append(mask)
            symbols.extend(key)
            coefficient *= value
            paths *= k
        else:
            if occupied == tm and Counter(symbols) == Counter(tk):
                sign = sign_by_permutation(masks)
                negative += sign == -1
                out += coefficient * sign
                n += paths
    return out * m.Fraction(1, 24), n, negative

rng = random.Random(20261107)
sym = [m.r10.S("fixture", (i,)) for i in range(3)]
observed_negative = observed_nonzero = observed_canceled = 0
op_total = 0
for case in range(64):
    vertices = {}
    cb = list(range(8))
    eb = list(range(8, 16))
    rng.shuffle(cb)
    rng.shuffle(eb)
    keys = []
    for i in range(4):
        mask = sum(1 << j for j in cb[2*i:2*i+2] + eb[2*i:2*i+2])
        key = (sym[i%2],)
        keys.extend(key)
        vertices[mask, key] = Q(i+1, case%5-2), i+1
    for i in range(2):
        # Externally overlapping and wrong-multiset controls are live
        # source rows with no possible contribution to the target.
        mask = sum(1 << j for j in cb[i:i+2]+[eb[i],eb[i+2]])
        vertices[mask, (sym[2],)] = Q(3, 5), 1
    if case % 8 == 0:
        k = next(iter(vertices))
        vertices[k] = Q(0), 2
    target = full, tuple(sorted(keys))
    wanted = {target: None}
    control = (full, tuple(sorted((sym[0],)*4)))
    wanted[control] = None
    work = m.r5.Work(cap=200_000)
    actual = m.partitioned_quartic(vertices, wanted, center, work, m.Admission(128))
    direct = m.direct_coefficients(vertices, wanted, center, work, m.Admission(128))
    for k in wanted:
        expected, paths, neg = brute(vertices, k)
        assert actual.get(k, (Q(0), 0)) == (expected, paths)
        assert direct[k] == expected
        observed_negative += neg
        observed_nonzero += bool(expected)
        observed_canceled += bool(paths and not expected)
    op_total += work.used
assert len(list(m.split(center))) == 35
assert observed_negative and observed_nonzero and observed_canceled
# The exact boundary is 4 vertex rows + one wanted row + first index row.
small = {(15, ()): (Q(1), 1), (51, ()): (Q(1), 1),
         (204, ()): (Q(1), 1), (240, ()): (Q(1), 1)}
# Valid masks for this prospective refusal have exactly two center bits.
small = {(3 | (3 << 8), ()): (Q(1), 1), (12 | (12 << 8), ()): (Q(1), 1),
         (48 | (48 << 8), ()): (Q(1), 1), (192 | (192 << 8), ()): (Q(1), 1)}
work = m.r5.Work(cap=100)
try:
    m.partitioned_quartic(small, {(full, ()): None}, center, work, m.Admission(5))
except RuntimeError as exc:
    assert str(exc) == "quartic local cap: prospective 6, cap 5"
    local_refusal = str(exc)
else:
    raise AssertionError("prospective local cap allowed allocation")
work = m.r5.Work(cap=0)
try:
    m.partitioned_quartic(small, {(full, ()): None}, center, work, m.Admission(128))
except RuntimeError as exc:
    assert str(exc) == "fiber work cap at 0 on quartic_half_pairs plus 1"
    work_refusal = str(exc)
else:
    raise AssertionError("prospective work cap allowed work")
print(json.dumps(dict(fixtures=64, coefficients=128, negative_ordered_draws=observed_negative,
    nonzero_coefficients=observed_nonzero, canceled_with_paths=observed_canceled,
    charged_operations=op_total, local_refusal=local_refusal, work_refusal=work_refusal),indent=2))
