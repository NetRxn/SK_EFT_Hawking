import importlib.util, sys
spec=importlib.util.spec_from_file_location('quartic_control', '/tmp/publication-task4-continuation-quartic-r11.py')
m=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)

# Feed two independent later groups that share a complete residual key.
# Candidate's original stream, projection, and residual aggregation run.
# Only the fixture's group-factor producer is substituted.
center=255
full_local=65535
x=1<<16
y=1<<17
xsrc,ysrc=object(),object()
slot=m.SLOTS[0]
term=tuple(sorted([m.r10.G2]*4+[m.r10.S('q',(i,)) for i in range(24)]))
target=(full_local|x|y,term,slot)
def groups(_target,source,_traces,_work):
    if source is xsrc:
        yield 'x', ([(x,(),m.ONE)],)
    else:
        assert source is ysrc
        for label in ('y0','y1'):
            yield label, ([(y,(),m.ONE)],)
m.group_factors=groups
work=m.r5.Work(cap=20)
admission=m.Admission(3)
inputs=(xsrc,None,None,None,{slot:m.E(((0,m.P.scalar(1)),))},ysrc,None)
wanted,records,later=m.exterior_residuals(target,inputs,center,work,admission)
assert (len(wanted),records,later,admission.peak)==(1,2,2,3)
assert work.counts['quartic_outer_tests']==1
assert set(next(iter(wanted.values())))=={('x','y0'),('x','y1')}
print('outer_fixture',dict(wanted_keys=len(wanted),group_records=records,later_paths=later,reported_local_peak=admission.peak,simultaneous_records=5,charged_outer_tests=work.counts['quartic_outer_tests'],signed_outer_updates=2))
