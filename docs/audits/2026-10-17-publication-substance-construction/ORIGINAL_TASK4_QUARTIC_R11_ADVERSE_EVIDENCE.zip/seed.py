import importlib.util, sys
spec=importlib.util.spec_from_file_location('quartic', '/tmp/publication-task4-continuation-quartic-r11.py')
m=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)
work=m.r5.Work(cap=1_500_000)
reg,(_,_,w),inputs,raw,d0,d1=m.r10.setup(work)
rows=list(m.seeded_targets(inputs,d0,d1,work))
print('seed schedule',[(target[2],direction,attempt) for target,direction,seed,attempt in rows],work.used,flush=True)
for target,direction,seed,attempt in rows:
    value,paths=m.witness(target,seed,inputs,work)
    print('witness only',target[2],direction,str(value),paths,work.used,flush=True)
