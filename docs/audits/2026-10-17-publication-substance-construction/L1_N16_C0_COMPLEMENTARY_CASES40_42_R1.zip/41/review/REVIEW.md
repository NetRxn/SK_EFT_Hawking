# Independent verification of complementary tuple 0 outer case 41

The exact normalized sum is
**-1000730277528745670596611/5192296858534827628530496329220096 + 0i**.

The original separator archive is pinned to publication checkpoint
f7ddcfd874f6f329fa10537ee38bb2bf2269834b and matches the worktree bytes.
The archive manifest verified. The decompressed complementary parent
SHA256 is 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It selects R(0,0,2,0,1)=1. Its rejected-pair histogram reconstructs the
complete 48-coordinate roster over 6,427,904 products. Case 33 is
(34, (2,)) with 212,688 pair products and an exact inverse lift of
430,572 compatible rows. The equal first-child case 41 scalar is from
selector 0. This review uses the selector-1 factors throughout.

Two outer row-cap stages reproduce the seven-factor inner parent
126b99c5bf5254803f3d35c891a52a920e41fe3b92086cfec9e984127a8c4e78.
The inner rejected-pair histogram reconstructs all nine distinct cuts
of G(0,1,2) over 2,280,960 products. Exact inverse lifts recover every
compatible Gaussian coefficient and denominator for each cut.
The 22 generic inner stages reproduce byte for byte, including
17 cap refusals and five exact terminals. The later capped rescue
inputs for slices 7 and 8 are preserved. The author four-factor
closures both use their corresponding rescue-0 capped operands.

| Slice | Inner coordinate | Projected pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 12 | 44,928 | -10738463415852486999195/2596148429267413814265248164610048 |
| 1 | 192 | 62,208 | -21046715139580744131/81129638414606681695789005144064 |
| 2 | 3 | 169,344 | -199499446306079983929915/2596148429267413814265248164610048 |
| 3 | 5 | 200,448 | -246275539103447893408635/5192296858534827628530496329220096 |
| 4 | 96 | 248,832 | -15112630443357465282639/649037107316853453566312041152512 |
| 5 | 144 | 248,832 | -15112630443357465282639/649037107316853453566312041152512 |
| 6 | 48 | 311,040 | 2562058026045506907513/649037107316853453566312041152512 |
| 7 | 80 | 497,664 | -27831576581786069610813/2596148429267413814265248164610048 |
| 8 | 160 | 497,664 | -27831576581786069610813/2596148429267413814265248164610048 |

Five final states pass independent direct sparse contraction. The
alternate triangles of slices 2 and 3 use pivot 1. Slice 2 covers
18,643,968 matching triples and uses 18,752,832 Gaussian products.
Slice 3 covers 19,975,680 triples and uses 20,092,320 products.
The two four-factor replays use independent pair (1,2) and closure
on (0,3), while the author's pair is (1,3). Each of the independent
replays forecasts 8,650,800 selected pair matches and uses 27,716,400
Gaussian products over 16 bounded shards, with at most 2,049,424
products per shard and 24,984 entries per block. The four alternate
replays agree with the author raw numerators and normalized values.
All 32 author shard receipts have complete disjoint row intervals
and sum exactly to the independently contracted values. All nine
terminal calculations use factor denominator
40512224221827380280140849737629696 and normalization 1/(16*4^64)
once.

The timing receipts record five outer commands, 53 inner commands,
nine independent terminal runs and the 32 original author shards.
The independent triangle runs took 13.178 s and 14.294 s. The
four-factor runs took 20.691 s and 21.05 s. These are observed
per-command elapsed times under concurrent scratch execution.

The relative review manifest includes copies of the author receipts.
The frozen-input inventory hashes the source operands required for
the replays.
