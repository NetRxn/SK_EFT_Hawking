from hashlib import sha256
from pathlib import Path
from pickle import loads

first=Path('/private/tmp/l1-open-roster-37-41.iS3wWH/row-cap-physical-slice-dense-label-case-40-2-reduced.pkl')
comp=Path('/private/tmp/l1-c0-complementary-cases24-47.XWr8Qj/tuple0-1/40/row-cap-physical-slice-dense-label-rescue-reduced.pkl')
p0,p1=[loads(p.read_bytes()) for p in (first,comp)]
selector=('R',0,0,2,0,1)
assert dict(p0['conditioning'])[selector]==0 and dict(p1['conditioning'])[selector]==1
assert p0['factors']!=p1['factors']
print('PASS distinct selector-0 and selector-1 inner factor tables')
for index,path in enumerate((first,comp)):
    print('selector',index,'SHA256',sha256(path.read_bytes()).hexdigest())
