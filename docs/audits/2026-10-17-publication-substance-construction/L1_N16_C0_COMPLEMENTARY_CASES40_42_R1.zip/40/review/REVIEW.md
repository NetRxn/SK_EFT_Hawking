# Independent verification of complementary tuple 0 outer case 40

The exact normalized sum is **-802289474534037328295697/5192296858534827628530496329220096 + 0i**.

The original archive is extracted at checkpoint bc45b03f4146c9fb821b7471b18f27b66ed92c05. Its manifest verifies and pins the decompressed selector-1 parent to SHA256 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d. Independent matching on the rejected pair reconstructs the complete 48-coordinate outer roster over 6,427,904 matched products. Case 40 is (34,(1,)) with 212,688 matched products and an exact inverse lift of 425,836 compatible rows. Selector-0 and selector-1 inner factor arrays differ.

Two outer row caps reproduce the seven-factor inner parent at SHA256 856787a718d592132c6f611d23cee70c9e365a336f1eb6ef9e1dfa50cfc1397f. The independently computed inner census gives 2,280,960 pair matches across nine distinct values of G(0,1,2), with maximum 497,664. Every nonzero network product must match on the selected pair. Nine exact inverse lifts recover every compatible input row, coefficient and denominator. The byte readback covers both outer cap/restart stages and all 22 generic inner stages, including 17 capped contractions and five exact terminals.

Five final states pass independent sparse contraction. The alternate triangles of slices 2 and 3 use pivot factor 1 and respectively 18,643,968 and 19,975,680 exact support triples. The independent arithmetic uses 18,752,832 and 20,092,320 Gaussian products. Slices 7 and 8 use pair (1,2), compared with author pair (1,3). Each alternate replay processes 6,593,616 outer pair matches and 27,595,440 Gaussian products in 12 bounded shards. Peak arithmetic per shard is 2,900,784 products and peak block state 24,984 entries. All four alternative arithmetic paths reproduce the author raw numerators exactly.

All 32 author shard receipts have complete disjoint intervals through the actual pivot tables. A separate support census reproduces each original interval's probe or pair-match count. Their raw sums agree with the corresponding independent terminal replays. All nine terminal values apply denominator 40512224221827380280140849737629696 and positive normalization 1/(16*4^64) once. The exact signed slice values are listed in audit.out.

The five outer commands total 28.089 s and the 53 inner commands total 331.661 s across two workers. Independent triangles took 13.446 s and 15.343 s, and independent four-factor replays took 19.760 s and 17.545 s. Each timing measures elapsed time per command during concurrent scratch execution.

The relative evidence manifest covers scripts, receipt copies and timings. The source archives are separately pinned. The full signed coefficient remains open.
