from ast import literal_eval
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from re import M,search
from zipfile import ZipFile

from exact_factors import read

with ZipFile('first-child.zip') as archive:
    raw=archive.read('partial-48.tsv')
    manifest={name.removeprefix('./'):h for h,name in map(str.split,archive.read('manifest.sha256').decode().splitlines())}
    assert sha256(raw).hexdigest()==manifest['partial-48.tsv']=='58cef3be160fa9a1178abd7fc646335b815b20f47fba71a849533d273813f0e6'
    cases={}
    for line in raw.decode().splitlines():
        fields=line.split('\t')
        if fields[0].isdigit():
            i,coord,re,im,_=fields
            assert int(i) not in cases
            cases[int(i)]=(literal_eval(coord),Fraction(re),Fraction(im))
assert set(cases)==set(range(48))
parents=[read('separator.zip',f'row-cap-physical-slice-dense-label-tuple0-{i}-reduced.pkl') for i in (0,1)]
assert parents[0]['conditioning'][:-1]==parents[1]['conditioning'][:-1]
for i,parent in enumerate(parents):
    assert parent['conditioning'][-1]==(('R',0,0,2,0,1),i)
assert parents[0]['factors']!=parents[1]['factors']
aggregate=Path('aggregate.out').read_text()
re,im=map(Fraction,search(r'^PASS exact case 42 subtotal (\S+) (\S+)$',aggregate,M).groups())
assert cases[42]==((36,(1,)),re,im)
print('PASS case 42 equals selector-0 scalar at matching coordinate; selector-1 arithmetic separately derived',re,im)
