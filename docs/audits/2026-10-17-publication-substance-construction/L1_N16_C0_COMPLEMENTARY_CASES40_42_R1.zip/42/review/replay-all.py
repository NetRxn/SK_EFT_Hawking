from pathlib import Path
from subprocess import run
from sys import argv,executable

from binding import ROOT, TERMINAL_INPUTS, records
replays=Path('replays')
replays.mkdir(exist_ok=True)
for i in (list(map(int,argv[1:])) or range(9)):
    if i in (2,3):
        script,args='triangle.py',[str(i)]
    elif i in (7,8):
        script,args='four.py',['42',str(i),'--pair','1','2']
    else:
        script,args='replay.py',[str(i),'0',str(ROOT/TERMINAL_INPUTS[i]),str(ROOT/records[i][-1])]
    with (replays/f'{i}-replay.out').open('wb') as out, (replays/f'{i}-replay.time').open('wb') as err:
        r=run(['/usr/bin/time','-p',executable,'-u',script,*args],stdout=out,stderr=err,timeout=120)
    assert r.returncode==0,(i,(replays/f'{i}-replay.time').read_text())
    print('PASS terminal replay',i,TERMINAL_INPUTS[i],flush=True)
