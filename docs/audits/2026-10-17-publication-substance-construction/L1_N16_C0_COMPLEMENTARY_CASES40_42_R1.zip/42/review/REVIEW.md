# Complementary tuple 0 outer case 42 independent exact review

The nine separate exact terminal replays sum to **-52600891516154856091647 / 324518553658426726783156020576256 + 0i**. This is outer case 42 of the selector-1 child of tuple 0 in dense group 128 descendant (0, 0). It matches the same coordinate's accepted selector-0 scalar and derives from its own distinct parent and exact inputs.

At publication checkpoint 264d6ced9db195c03b8c5de89bcd7b10652ae8bc, the original separator pins the eight-factor tuple0-1 parent to uncompressed SHA256 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d. Independent projected matching reproduces the full original 48-case roster and 6,427,904 pair matches. Case 42 is coordinate (36, (1,)), with 212,688 matches and 425,836 stored rows. An exact inverse lift recovers its restricted parent rows, axes, signed coefficients and denominators.

Both outer row caps are rebuilt from the pinned parent and produce the exact seven-factor inner restart with SHA256 c2d16c232c73adfcf5f22b58aa0ece57b5a3743abd3cfbcbd36b29c46141fe3e. The independent inner census on G(0,1,2) gives all nine supported coordinates with 2,280,960 products total, minimum 44,928 and maximum 497,664. Each conditioned child's inverse lift exactly recovers its source factor slices. The independent source and inverse-lift audit took 12.59 seconds. Clean execution of frozen author programs reproduces the cap/checkpoint bytes, reductions and terminal author receipts separately from the independent mathematical replays. All 19 cap snapshots verify, comprising 13 join refusals and six row refusals. The byte-for-byte lineage run took 186.90 seconds.

| Slice | Coordinate | Products in the inner census | Exact normalized real |
| --- | --- | --- | --- |
| 0 | 3 | 44928 | -8215595331806265617025/2596148429267413814265248164610048 |
| 1 | 192 | 62208 | -14394095842748134149/81129638414606681695789005144064 |
| 2 | 5 | 169344 | -86746711841561468706345/2596148429267413814265248164610048 |
| 3 | 12 | 200448 | -46724202631162597712535/649037107316853453566312041152512 |
| 4 | 96 | 248832 | -25625583662957547421905/1298074214633706907132624082305024 |
| 5 | 144 | 248832 | -25625583662957547421905/1298074214633706907132624082305024 |
| 6 | 48 | 311040 | 1291367012248039284243/324518553658426726783156020576256 |
| 7 | 80 | 497664 | -23158002405203453926611/2596148429267413814265248164610048 |
| 8 | 160 | 497664 | -23158002405203453926611/2596148429267413814265248164610048 |

All imaginary values are exactly zero. Slices 0, 1, 4, 5 and 6 use independent Gaussian-integer sparse joins. Slices 2 and 3 use alternate triangle pivot 1 in place of author pivot 0. Slices 7 and 8 use selected pair (1, 2) in place of author pair (1, 3), group exact products by the outgoing boundary, then compute the complementary closure. Each replay starts from its own frozen terminal input. Plain sparse schedules use 636,048 to 6,391,680 Gaussian products. The triangle replays use 18,643,968 and 19,975,680 supported triples, with 18,752,832 and 20,092,320 Gaussian products. The internal times are 11.64 and 11.83 seconds. Each four-factor replay visits 6,593,616 selected-pair matches and 18,564,576 complementary closure probes, using 27,595,440 Gaussian products in 12 bounded shards. Their internal elapsed times are 16.90 and 16.66 seconds. timings.tsv preserves per-slice work, output peaks and both internal and process elapsed times.

Independent projection histograms validate all 32 sorted pivot intervals across the four author shard stacks. They reproduce the exact probe or pair-match count per interval, and each shard stack's exact raw and normalized sum agrees with the independent signed replay. The independent shard census took 1.71 seconds.

Every replay preserves the exact raw scalar and combines the factor-denominator product 40512224221827380280140849737629696 with the positive external scale 1/(16*4^64) once. The committed selector-0 ledger confirms the matching value after the selector-1 computation. The final comparison uses the independently contracted selector-1 scalar and verifies that the two original parents are distinct.

## Reproduction

Retain inputs/, scripts/ and replays/ as relative directories. The separator.zip and first-child.zip archives can be restored from the pinned Git objects. The generated lineage directory can be recreated from the frozen inputs. Run the checks in a fresh copy, with no generated lineage/ directory.

```sh
sh verify-source-pins.sh
shasum -a 256 -c frozen-inputs.sha256
shasum -a 256 -c source-archives.sha256
python3 audit.py > audit.out
python3 verify-lineage.py outer 0 1 2 3 4 5 6 7 8 > verify-lineage.out
python3 replay-all.py > replay-all.out
python3 verify-shards.py > verify-shards.out
python3 timings.py > timings.tsv
python3 verify-cap-list.py > cap-list.out
python3 aggregate.py > aggregate.out
python3 compare-first.py > compare-first.out
```
