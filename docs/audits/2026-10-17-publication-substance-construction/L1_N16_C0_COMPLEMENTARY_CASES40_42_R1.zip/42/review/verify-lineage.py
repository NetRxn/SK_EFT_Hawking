from concurrent.futures import ThreadPoolExecutor
from gzip import decompress
from hashlib import sha256
from pathlib import Path
from shutil import copyfile
from subprocess import run
from sys import argv, executable
from zipfile import ZipFile

root = Path.cwd()
author = root/'inputs'
programs = root/'scripts'
lineage = root/'lineage'
archive_path = root/'separator.zip'
outer_name = 'row-cap-physical-slice-dense-label-tuple0-1-reduced.pkl'
outer_parent = lineage/outer_name
inner_name = 'row-cap-physical-slice-dense-label-rescue-reduced.pkl'
inner_parent = author/inner_name
main_programs = ('exact-multicut.py', 'reduce-label-frontier.py', 'contract-reduced-label.py',
                 'contract-peer.py', 'peer_pair.py', 'checkpoint/quotient.py')

def execute_job(index):
    directory = lineage/str(index)
    directory.mkdir(parents=True)
    (directory/'checkpoint').mkdir()
    for name in main_programs:
        copyfile(programs/name,directory/name)

    def verify(name):
        actual=(directory/name).read_bytes()
        target=(author/name).read_bytes()
        assert actual==target, (index,name,sha256(actual).hexdigest(),sha256(target).hexdigest())
        return sha256(actual).hexdigest()

    def invoke(program,args,receipt,status):
        with (directory/receipt).open('xb') as stream:
            completed=run([executable,'-u',program,*args],cwd=directory,stdout=stream,stderr=stream,timeout=240)
        assert completed.returncode==status,(index,program,args,completed.returncode,(directory/receipt).read_text())
        verify(receipt)

    def stage(initial, tag, reduce_receipt, contract_receipt, peer=False):
        invoke('reduce-label-frontier.py',[initial,tag],reduce_receipt,0)
        verify(f'label-{tag}-reduced-frontier.pkl')
        last=(author/contract_receipt).read_text().splitlines()[-1]
        if last.startswith(('open join cap','open row cap')):
            status=2
        else:
            assert last.startswith('exact normalized '),(index,last)
            status=0
        invoke('contract-peer.py' if peer else 'contract-reduced-label.py',[tag],contract_receipt,status)
        result=None
        if status:
            saved=list(directory.glob(f'*-cap-*-dense-label-{tag}-reduced.pkl'))
            if not saved:
                saved=list(directory.glob(f'join-cap-dense-label-{tag}-reduced.pkl'))
            assert len(saved)==1,(index,tag,saved)
            result=saved[0].name
            digest=verify(result)
            print('PASS frozen cap',index,tag,result,digest,last,flush=True)
        else:
            print('PASS exact author terminal stage',index,tag,last,flush=True)
        return result

    if index=='outer':
        assert outer_parent.is_file()
        invoke('exact-multicut.py',[str(outer_parent),'input.pkl','42'],'plan.out',0)
        verify('input.pkl')
        verify('input.roster')
        first=stage('input.pkl','primary','reduce.out','contract.out')
        assert first=='row-cap-physical-slice-dense-label-primary-reduced.pkl'
        second=stage(first,'rescue','rescue-reduce.out','rescue-contract.out',True)
        assert second==inner_name
        print('PASS outer cap/restart lineage recreated seven-factor inner parent',flush=True)
        return

    i=int(index)
    author_row=(author/'author-case42.tsv').read_text().splitlines()[i].split('\t')
    assert int(author_row[0])==i
    terminal=author_row[-1]
    tag=f'slice-{i}'
    initial=tag+'.pkl'
    invoke('exact-multicut.py',[str(inner_parent),initial,index],tag+'-plan.out',0)
    verify(initial)
    verify(tag+'.roster')
    saved=stage(initial,tag,tag+'-reduce.out',tag+'-contract.out')
    if terminal==tag+'-contract.out':
        assert saved is None
    else:
        assert saved is not None
        attempt=0
        while True:
            tag=f'rescue-{i}-{attempt}'
            receipt=tag+'-contract.out'
            saved=stage(saved,tag,tag+'-reduce.out',receipt,True)
            if receipt==terminal:
                assert saved is None
                break
            assert saved is not None
            if i in (2,3,7,8) and attempt==1:
                expected = (f'join-cap-dense-label-rescue-{i}-1-reduced.pkl' if i in (2,3)
                            else f'row-cap-physical-slice-dense-label-rescue-{i}-1-reduced.pkl')
                assert saved==expected
                assert terminal==f'slice-{i}-shard-sum.out'
                break
            attempt+=1
            assert attempt<=1
    print('PASS inner cap/restart lineage',i,terminal,flush=True)

lineage.mkdir(exist_ok=True)
if 'outer' in argv[1:]:
    with ZipFile(archive_path) as archive:
        raw=decompress(archive.read(outer_name+'.gz'))
    assert sha256(raw).hexdigest()=='9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d'
    outer_parent.write_bytes(raw)
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(execute_job,argv[1:]))
