from pathlib import Path
from re import M,findall,search

print('slice','schedule','Gaussian_products','support_measure','largest_join_or_shard_products',
      'peak_output_rows_or_block_entries','internal_seconds','process_seconds',sep='\t')
for i in range(9):
    log=(Path('replays')/f'{i}-replay.out').read_text()
    proc=(Path('replays')/f'{i}-replay.time').read_text()
    wall=search(r'^real (\S+)$',proc,M)[1]
    if i in (2,3):
        pivot,probes,triples,_,products,elapsed=search(r'^independent pivot (\d+) probes (\d+) triples (\d+) nonzero pivot rows (\d+) Gaussian products (\d+) wall seconds (\S+)$',log,M).groups()
        _,maximum=search(r'^closed final pivot shard .* peak (\d+) (\d+)$',log,M).groups()
        print(i,f'triangle_pivot_{pivot}',products,f'{probes}_probes/{triples}_triangles',maximum,'',elapsed,wall,sep='\t')
    elif i in (7,8):
        outer=search(r'^alternate pair \(1, 2\) forecast (\d+) ',log,M)[1]
        shards,_,maximum,_,peak,products,probes,elapsed=search(r'^complete shards (\d+) left rows (\d+) peak Gaussian products/shard (\d+) peak closure probes/shard (\d+) peak entries (\d+) total products (\d+) total probes (\d+) seconds (\S+)$',log,M).groups()
        print(i,'pair_1_2',products,f'{outer}_selected_matches/{probes}_closure_probes/{shards}_shards',maximum,peak,elapsed,wall,sep='\t')
    else:
        joins=[(int(n),int(rows)) for n,rows in findall(r'^independent join \d+ \d+ products (\d+) output rows (\d+) remaining \d+$',log,M)]
        candidates,elapsed=search(r'^exact normalized real .* independent matched products (\d+) wall seconds (\S+)$',log,M).groups()
        assert sum(n for n,_ in joins)==int(candidates)
        print(i,'plain_sparse',candidates,f'{len(joins)}_joins',max(n for n,_ in joins),max(rows for _,rows in joins),elapsed,wall,sep='\t')
