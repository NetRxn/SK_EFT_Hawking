#!/bin/sh
set -eu
test "$(git hash-object separator.zip)" = 02e33786d0bcd46e2314ad7fec1453595adcc815
test "$(git hash-object first-child.zip)" = 1690d42f0f5c2b9fe270cd1a088730431bbc2b5d
for input in exact-multicut.py reduce-label-frontier.py contract-reduced-label.py checkpoint/quotient.py; do
    unzip -p separator.zip "$input" | cmp - "scripts/$input"
done
for input in contract-peer.py peer_pair.py; do
    unzip -p first-child.zip "author45/$input" | cmp - "scripts/$input"
done
printf 'PASS both publication archive pins and six frozen lineage programs\n'
