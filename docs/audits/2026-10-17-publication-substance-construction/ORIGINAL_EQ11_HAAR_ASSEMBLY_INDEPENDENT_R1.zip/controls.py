from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import permutations
from math import factorial, prod
import json
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import (
    OriginalRegulator, QComplex as Q, Polynomial as P, Symbol, assemble_dirac,
    determinant_jet, determinant_polynomial, haar_polynomial, polynomial_substitute,
)
zero = (0, 0, 0, 0)
one = (1, 0, 0, 0)
qL, qR = (F(1,3), F(2,3), F(2,3), 0), (0, F(2,3), F(-1,3), F(2,3))
for left, right in ((qL,qR),(qR,qL)):
    block = original_spin4_link(left,right)
    recovered_blocks = []
    for offset, q in ((0,left),(2,right)):
        a,b = (block[offset][offset].evaluate({}),block[offset][offset+1].evaluate({}))
        recovered = a.real,b.imag,b.real,a.imag
        assert recovered == q and sum(x*x for x in recovered) == 1
        recovered_blocks.append(recovered)
    assert original_spin4_link(*recovered_blocks) == block
reg = OriginalRegulator((2,1,1,1), (-1,1,-1,1), 'metric_M')
per = OriginalRegulator(reg.extents, convention='source_C')
links = {(x,mu):original_spin4_link(*( (qL,qR) if (sum(x)+mu)%2 else (qR,qL)))
         for x,mu in reg.link_order}
twisted = {}
for (x,mu), u in links.items():
    sign = -1 if reg.boundary_signs[mu] == -1 and x[mu]+1 == reg.extents[mu] else 1
    twisted[x,mu] = tuple(tuple(sign*v for v in row) for row in u)
assert reg.step(zero,0)==(one,1) and reg.step(one,0)==(zero,-1)
assert reg.step(zero,0,-1)==(one,-1) and reg.step(one,0,-1)==(zero,1)
assert reg.step(zero,2)==(zero,-1) and reg.step(zero,2,-1)==(zero,-1)
gamma=(3,0,1,2)
w={(x,mu,a):Q(1+sum(x)+mu,F(a+1,7)) for x in reg.sites for mu in range(4) for a in range(4)}
physical={(x,mu,gamma[a]):v for (x,mu,a),v in w.items()}
twisted_assembly = assemble_dirac(reg,w,links)
assert twisted_assembly == assemble_dirac(per,physical,twisted)
assert twisted_assembly != assemble_dirac(per,physical,links)
assert twisted_assembly != assemble_dirac(per,w,twisted)

def moment(key):
    groups=defaultdict(Counter)
    for symbol in key:
        if symbol.family=="q":
            groups[symbol.index[:-1]][symbol.index[-1]] += 1
    weight=F(1)
    for g in groups.values():
        if any(p%2 for p in g.values()):
            return F()
        half=[p//2 for p in g.values()]
        weight*=F(prod(factorial(2*k)//factorial(k) for k in half),
                  4**sum(half)*factorial(1+sum(half)))
    return weight

def direct_slot(p, labels, values, integrate):
    out=Q()
    for key,c in p.terms:
        residual=Counter(s for s in key if s.family!="q")
        for label in labels:
            c*=residual[label]
            residual[label]-=1
            if not c: break
        if not c: continue
        for sym,n in residual.items():
            for _ in range(n):
                c*=values[sym]
        out+=c*(moment(key) if integrate else 1)
    return out

def independent_det(m):
    d=P()
    entries=dict(m.entries)
    for p in permutations(range(m.size)):
        sign=(-1)**sum(p[i]>p[j] for i in range(m.size) for j in range(i+1,m.size))
        term=P.scalar(sign)
        for i,j in enumerate(p):
            term*=entries.get((i,j),P())
        d+=term
    return d

out=[]
for convention in ("source_C","metric_M"):
    reg=OriginalRegulator((1,1,1,1), (-1,1,1,1), convention)
    slots=[(zero,0,0),(zero,1,2)]
    hs=[Symbol("h",i) for i in slots]
    js=[Symbol("J",i) for i in slots]
    points={hs[0]:Q(F(1,3)),hs[1]:Q(F(-2,5)),js[0]:Q(F(1,6), F(2,7)),js[1]:Q(F(4,9),F(3,8))}
    shift={a:P.variable(h)+P.variable(j) for a,h,j in zip(slots,hs,js)}
    mat=assemble_dirac(reg,shift)
    det=independent_det(mat)
    assert det==determinant_polynomial(mat) and len(det.terms)>0
    base=assemble_dirac(reg,{a:points[h]+points[j] for a,h,j in zip(slots,hs,js)})
    integrated=haar_polynomial(det)
    for ia,ib in ((0,0),(0,1),(1,0),(1,1)):
        inc=[assemble_dirac(reg,{slots[i]:1}) for i in (ia,ib)]
        jet=determinant_jet(base,inc)
        actual=[haar_polynomial(jet.at(k)).evaluate({}) for k in ((),(0,),(1,),(0,1))]
        a,b=hs[ia],hs[ib]
        direct=[direct_slot(det,l,points,True) for l in ((),(a,),(b,),(a,b))]
        moved=[direct_slot(integrated,l,points,False) for l in ((),(a,),(b,),(a,b))]
        assert actual == direct == moved
        assert all(direct)
        out.append({"convention":convention,"derivative_labels":[ia,ib],
                    "determinant_terms":len(det.terms),"raw_slots":[v.storage for v in actual]})
    # A raw derivative in h also differentiates the same shift as varying J.
    for i in range(2):
        assert direct_slot(det,(hs[i],),points,True)==direct_slot(det,(js[i],),points,True)
print(json.dumps({"chiral_inverse_cases":4,"boundary_axis_matrix_entries":len(twisted_assembly.entries),
                  "both_adverse_transports_detected":True,"exact_jets":out},indent=2))
