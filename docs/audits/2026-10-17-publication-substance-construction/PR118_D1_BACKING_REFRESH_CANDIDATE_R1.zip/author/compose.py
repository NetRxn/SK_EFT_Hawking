from collections import Counter, defaultdict
from pathlib import Path
import json,sys
from sentence_state import compute_sentence_id,validate_claims_review
source=Path(sys.argv[1])
artifact=Path('papers/D1/claims_review.json')
paper=Path('papers/D1/paper_draft.tex').read_text()
d=json.loads(artifact.read_text())
proposals=json.loads(source.read_text())
run='claims-reviewer-v2:bundle-D1:2026-11-07:scoped-backing-refresh'
by_prior=defaultdict(list)
for p in proposals:
    assert paper.count(p['quote'])==1
    start=paper[:paper.index(p['quote'])].count('\n')+1
    assert start==p['tex_line_start']
    assert start+p['quote'].count('\n')==p['tex_line_end']
    assert compute_sentence_id('D1',p['section'],p['quote'])==(p['id'],p['quote_normalized'],p['quote_hash'])
    evidence=p['backing']
    by_prior[p['prior_id']].append(dict(
        id=p['id'],raw_id_parts=dict(paper='D1',section_slug=p['id'].split(':')[2],
        quote_hash=p['quote_hash'],hash_algorithm='sha256_first_8'),
        section=p['section'],tex_line_start=p['tex_line_start'],tex_line_end=p['tex_line_end'],
        quote=p['quote'],quote_normalized=p['quote_normalized'],type=p['type'],
        finding_classes=[],chain_proposed=dict(links=evidence,completeness='full' if evidence else 'partial'),
        agent_verdict='PASS' if evidence else 'WARN',agent_notes=p['scope'],agent_run_id=run,
        gates_invoked=['Gate4_ComputationCorrectness' if p['type']=='numeric' else 'Gate5_LeanProofSubstance'],
        rewrite_of=p['prior_id'],tombstone=False,bundle_destination='D1',
    ))
old=d['sentences']
assert len(old)==14 and len(by_prior)==3 and all(k in {s['id'] for s in old} for k in by_prior)
d['sentences']=[new for s in old for new in by_prior.get(s['id'],[s])]
d['reviewer_run_id']=run
d['review_date']='2026-11-07T10:50:00Z'
d['reviewer_model']='codex'
d['review_round']=5
d['verdict']='yellow'
d['review_scope']={
    'mode':'scoped backing refresh',
    'source_commit':'9f8608351d9c5c94ed9d18df24ea2649087e8fd5',
    'historical_review_blob':'7d9c6d0a6ab35691777b2694c7010861108f3d83',
    'refreshed_rows':7,
    'carried_historical_rows':11,
    'replaced_historical_ids':list(by_prior),
    'notes':'The other rows, prior findings, round-4 notes, and cross-bundle consistency observations are carried as historical evidence. This scope does not reopen or close those findings or certify Stage 10 or Stage 13.',
}
summary=d['summary']
summary['total_sentences_walked']=7
summary['active_rows']=len(d['sentences'])
for field,key in [('by_type','type'),('by_verdict','agent_verdict')]:
    counts=Counter(s[key] for s in d['sentences'])
    summary[field]={k:counts[k] for k in dict.fromkeys((*summary[field],*counts))}
assert not validate_claims_review(d), validate_claims_review(d)
artifact.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
