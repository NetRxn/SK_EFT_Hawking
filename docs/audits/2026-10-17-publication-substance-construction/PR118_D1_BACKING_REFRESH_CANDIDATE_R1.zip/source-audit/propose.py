import json
from pathlib import Path
import sys
import sentence_state as ss

source=Path("papers/D1/paper_draft.tex").read_text().splitlines()
o=Path(sys.argv[1])
def wkb(*stems):
    return [("theorem","SKEFTHawking.WKBConnection."+s) for s in stems]
specs=[
    ("exact-wkb",1042,1046,None,None,"The modified-unitarity ansatz and its one parameter","formal-claim",wkb("ModifiedBogoliubov"),"Conditional carrier; the law is an input field. Scope is a Lean structure, not a theorem deriving modified unitarity."),
    ("exact-wkb",1083,1091,None,None,"The crossover frequency","theorem-ref",wkb("noiseFloor","noise_floor_eq_delta_diss","noise_floor_nonneg","noise_floor_zero_iff"),"Defined scalar floor and its elementary properties. Physical FDR is an input."),
    ("exact-wkb",1125,1130,"The corresponding inequality",None,"The crossover frequency","theorem-ref",wkb("noise_dominates_when_beta_small"),"Conditional quotient inequality with delta_k < 1 and supplied beta bound. The physical spectral crossover is not a Lean consequence of this statement."),
    ("polariton",1927,1932,"Assuming unit greybody factor","profile.","Exciton-polariton microcavities","numeric",[("formula","stimulated_hawking_gain")],"Unit-greybody adopted gain; log(3)/(2*pi)=0.17484957628 (0.08603 percent from printed 0.175). At the boundary G=0.5. No calibrated detection."),
    ("polariton",1934,1938,"For shot-noise-limited detection","in this ideal readout model.","Exciton-polariton microcavities","numeric",[("formula","stimulated_hawking_snr"),("theorem","SKEFTHawking.StimulatedHawking.detection_threshold")],"Ideal single-shot model: G=0.5 and N=100 give SNR=5. The theorem is sufficient for a supplied positive gain; it is not a physical device threshold."),
    ("graphene",1382,1387,"Of the ", "not by the fraction.","Graphene Dirac-fluid platform","numeric",[],"Deterministic count_theorem_reuse.classify gives 107/120=89.17%, 13 platform-specific. Machine ownership is docs/counts.tex via update_counts.py; no graph link kind for this census script, and the count does not certify physical transfer."),
    ("graphene",1387,1390,"The map performing the binding is",r"$c_s = v_F/\sqrt{2}$.","Graphene Dirac-fluid platform","theorem-ref",[("theorem","SKEFTHawking.DiracFluidWKB.toExactWKB"),("theorem","SKEFTHawking.DiracFluidWKB.soundSpeed")],"Algebraic parameter binding into ExactWKBParams. No scattering, boundary, or readout equivalence follows."),
]
rows=[]
for group,a,b,start,end,section,kind,links,scope in specs:
    q="\n".join(source[a-1:b])
    if start:
        q=q[q.index(start):]
    if end:
        q=q[:q.index(end)+len(end)]
    sid,norm,sha=ss.compute_sentence_id("D1",section,q)
    prior=f"sentence:D1:{group}:r4anchor"+str({"exact-wkb":2,"polariton":3,"graphene":4}[group])
    rows.append(dict(prior_id=prior,id=sid,quote_normalized=norm,quote_hash=sha,section=section,
                     tex_line_start=a,tex_line_end=b,quote=q,type=kind,
                     backing=[dict(kind=k,target=t) for k,t in links],scope=scope))
assert len(set(x["id"] for x in rows))==len(rows)
(o/"replacement-quotes.json").write_text(json.dumps(rows,indent=2)+"\n")
