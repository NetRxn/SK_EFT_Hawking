# PR118 D1 backing and review continuity audit

Scoped proposal on exact 9f8608351d9c5c94ed9d18df24ea2649087e8fd5. No writer or ledger was invoked. The five unresolved Lean targets belong to three May 6 round-4 anchor rows. These are stale graph inputs rather than five present-tense manuscript citations. The old PASS text is historical evidence and does not certify the current paper.

| Historical row | Unresolved link names | Current proposed scope |
| --- | --- | --- |
| exact-wkb:r4anchor2 | WKBSpectrum, GreybodyFactor, SpectralFloor | Conditional ModifiedBogoliubov carrier, scalar noise-floor definition and properties, conditional beta-small dominance |
| polariton:r4anchor3 | LKBDevice | Unit-greybody gain crossing and ideal single-shot requirement, both computationally reproduced |
| graphene:r4anchor4 | GrapheneDirac | Current deterministic inventory and the specific algebraic parameter map |

replacement-quotes.json records seven exact TeX spans, stable IDs from the canonical helper, eleven graph-resolved targets and the intended claim boundaries. The archive hash names the exact historical Git blob. Scope and statements were checked in source and the pinned catalog. The aggregate includes the WKBConnection, StimulatedHawking and DiracFluidWKB modules. Catalog readback shows no project axiom dependency for the proposed Lean links. This is source/catalog verification, with no new kernel run.

The old crossover estimate should not be attached to the quotient lemma. The latter requires a ModifiedBogoliubov inhabitant, delta_k below one and a supplied beta bound. The zero-frequency BEC greybody scalar belongs to a different current paragraph at D1 lines 1638–1648. QuasiOneDReduction.greybody_zero_freq_le_one and AndersonBFP2014Graybody resolve and could support a separate audit of that paragraph, not the old WKB anchor.

The unit-greybody crossing recomputes to 0.17484957628, gain one half at the boundary. An ideal 100-photon probe gives SNR five at that gain. The separate StimulatedHawking.detection_threshold theorem takes a positive gain and a lower bound on probe size and proves a sufficient scalar SNR bound. Cite it only for that direction. The modeled crossing remains backed by stimulated_hawking_gain and algebra. Current D1 expressly requires transfer and noise calibration. No universal threshold or historical improvement factor is reinstated.

The graphene counter classifies source statements and pinned catalog types against its registered platform-specific roots. It gives 107 of 120, 89.17 percent, with 13 platform-specific. This is a census, and the graph has no kind for its owning script. Record the deterministic receipt and macro lineage in notes. Keep that row partial if the graph requires backing links; a fabricated formula ratio target would be invalid. The named toExactWKB binding supplies distinct formal evidence for its own quote. It does not establish device-level scattering, dynamics or readout equivalence.

## Canonical author and acceptance route

Preserve the exact old claims_review.json at the immutable Git revision, the existing r1 archive, the audit events, findings arrays and prior finding dispositions. Replace only the three stale active anchor rows in a scoped claims-reviewer refresh, using current content hashes and rewrite_of pointing to the archived IDs where appropriate. Keep other row and finding provenance unchanged. Scope the new review run and summary to seven reviewed spans plus carried historical rows. Do not carry forward the May green verdict as a new verdict. No existing finding here is being adjudicated or closed. Semantic supersession requires its separate human disposition.

Validate the composed claims_review.json with the canonical schema. Compare the live link population with chain_canonicalize and the normal chain_backing_targets_resolve check. The read-only projection uses that resolver on identical source, with 111 portfolio unresolved links falling to 106 and D1 from five to zero. The proposed targets all resolve and the other bundles are unchanged. Treat the standing ceiling under the repository's down-only ratchet procedure only after the exact composed candidate is accepted and remeasured.

The canonical ingest dry-run and replay receipts show zero D1 prose_state sentences and zero inferred tombstones, despite 14 historical claims rows and one audit event. Ingest compares against human prose state, so it cannot infer historical row retirement in this case. Do not manufacture human-state records or a tombstone event. The live link iterator reads all chains in claims_review.json and does not skip tombstoned rows. Retire the stale rows from the active graph input via the normal review artifact and preserve their history in Git and rewrite lineage. After independent verification, the owning author can record the scoped ingest through the established workflow as appropriate. This audit supplies neither Stage 10 nor Stage 13 acceptance.
