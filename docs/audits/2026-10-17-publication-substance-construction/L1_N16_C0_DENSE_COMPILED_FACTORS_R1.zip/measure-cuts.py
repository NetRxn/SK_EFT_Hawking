from collections import defaultdict
from pathlib import Path
from ast import literal_eval as lit

schemas={}
for line in Path('schema.tsv').read_text().splitlines():
    name,labels,physical,n,rows,d=line.split('\t')
    schemas[name]=lit(labels),int(n),int(rows)
data=defaultdict(list)
for line in Path('block-index.tsv').read_text().splitlines():
    name,local,start,length,rows,d=line.split('\t')
    data[name].append((dict(zip(schemas[name][0],lit(local))),int(rows),int(length)))
assert len(data)==len(schemas)==88 and sum(map(len,data.values()))==2456
summaries=[]
for name in sorted(data):
    if not name.startswith('M'):
        continue
    counts=[]
    for key,_,_ in data[name]:
        rows=0
        size=0
        for factor in data.values():
            n=0
            for local,r,b in factor:
                if all(value==key[label] for label,value in local.items() if label in key):
                    # Compatible local rows only. Overlap on all other
                    # labels still has to be checked in the contraction.
                    rows+=r;size+=b;n+=1
            assert n
        counts.append((rows,size))
    summaries.append((max(r for r,_ in counts),sum(r for r,_ in counts),name,len(counts),max(b for _,b in counts)))
for peak,reused,name,slices,bytes_ in sorted(summaries):print(name,'slices',slices,'peak candidate rows',peak,'peak encoded bytes',bytes_,'sum candidate rows',reused)
