# Complete L1 dense labelled factor compilation

The independently verified original factor inputs are in
L1_N16_C0_DENSE_FACTOR_INPUTS_INDEPENDENT_R1 and the two preceding direct
factor checkpoints. The compiler calls the original signed factor
constructors on every local representation block. The 88 compiled
factor families contain 2,456 blocks, 47,769,624 rows, 424 physical axes
of incidence two, and 28 varying representation axes. Signed values
and denominators are preserved in each block. The large exact encoded
blocks remain in the local run tree and are pinned by checksum.

Run `python3 measure-cuts.py` to replay the single-site cut preflight
from the indexed row counts. It binds each possible site label tuple
and counts all compatible input rows before any further quotient merges.
The smallest measured peak is 17,018,646 candidate rows across 64
slices. This is an input count, not a bound on a signed intermediate or
a numerical result for the dense coefficient.
