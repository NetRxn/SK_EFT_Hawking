from ast import literal_eval as lit
from collections import Counter
from pathlib import Path
from fractions import Fraction
from math import lcm
import pickle

lines=Path('schema.tsv').read_text().splitlines()
assert len(lines)==88
wires=Counter(); labels_used=Counter()
stats=Counter()
with Path('block-index.tsv').open('w') as out:
    for line in lines:
        name,labels,physical,n,r,den=line.split('\t')
        labels,physical=lit(labels),lit(physical)
        n,r,den=map(int,(n,r,den))
        wires.update(physical)
        labels_used.update(labels)
        actual_rows=0
        actual_den=1
        seen=set()
        with Path(f'compiled/{name}.blocks').open('rb') as f:
            for _ in range(n):
                start=f.tell()
                local,axes,d,rows=pickle.load(f)
                stop=f.tell()
                assert len(local)==len(labels) and local not in seen
                assert set(axes)<=set(physical) and len(axes)==len(set(axes))
                assert d>0 and den%d==0
                seen.add(local)
                assert not rows or len(next(iter(rows)))==len(axes)
                print(name,local,start,stop-start,len(rows),d,sep='\t',file=out)
                actual_rows+=len(rows)
                actual_den=lcm(actual_den,d)
                stats['bytes']+=stop-start
            assert not f.read(1)
        assert actual_rows==r and actual_den==den
        stats['rows']+=r
        stats['blocks']+=n
assert set(wires.values())=={2}
assert stats['blocks']==2456
print(dict(stats),'physical axes',len(wires),'varying label axes',len(labels_used))
