# Complementary tuple 0 outer case 24 independent exact review

The nine separate exact terminal replays sum to **-70691890706351622304821 / 5192296858534827628530496329220096 + 0i**. This is outer case 24 of the selector-1 child of tuple 0 in dense group 128 descendant (0, 0). It matches the same coordinate's accepted selector-0 scalar and derives from its own distinct parent and exact inputs.

At publication checkpoint e7117dc4ac893ed733c2445296337e5020328442, the original separator pins the eight-factor tuple0-1 parent to uncompressed SHA256 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d. Independent projected matching reproduces the full original 48-case roster and 6,427,904 pair matches. Case 24 is coordinate (17, (3,)), with 118,160 matches and 401,772 stored rows. An exact inverse lift recovers its restricted parent rows, axes, signed coefficients and denominators.

Both outer row caps are rebuilt from the pinned parent and produce the exact seven-factor inner restart with SHA256 bed002089a24927c8c95bd123457766df88dfe93a593d6ceaddaeb71a46409c5. The independent inner census on G(0,1,2) gives all nine supported coordinates with 2,579,328 products total, minimum 195,456 and maximum 398,592. Each conditioned child's inverse lift exactly recovers its source factor slices. Clean execution of frozen author programs reproduces the cap/checkpoint bytes, reductions and terminal author receipts separately from the independent mathematical replays. All 13 cap snapshots verify, comprising six join refusals and seven row refusals. The byte-for-byte lineage run took 166.58 seconds. The source audit separately took 11.04 seconds.

| Slice | Coordinate | Products in the inner census | Exact normalized real |
| --- | --- | --- | --- |
| 0 | 12 | 195456 | -4047983651823933419325/2596148429267413814265248164610048 |
| 1 | 48 | 199296 | -453161112969562334757/649037107316853453566312041152512 |
| 2 | 96 | 199296 | -98787412176953354757/649037107316853453566312041152512 |
| 3 | 144 | 199296 | -98787412176953354757/649037107316853453566312041152512 |
| 4 | 192 | 199296 | -156913926114405537/2535301200456458802993406410752 |
| 5 | 3 | 394752 | -14352244652274241358835/2596148429267413814265248164610048 |
| 6 | 5 | 394752 | -25600563269250190407585/5192296858534827628530496329220096 |
| 7 | 80 | 398592 | -690905902408756861743/2596148429267413814265248164610048 |
| 8 | 160 | 398592 | -690905902408756861743/2596148429267413814265248164610048 |

All imaginary values are exactly zero. Slices 0, 1, 7 and 8 use independent plain sparse joins. A first plain run for slice 2 stopped at a forecast 29,708,160-product join after 8,103,640 completed products. The stop is preserved. Slices 2, 3 and 4 use exact support semijoins and ordinary Gaussian arithmetic with no proportional-slice quotient. Slices 2 and 3 each use 12,779,224 products; slice 4 uses 1,560,768.

The two three-factor contractions for slices 5 and 6 use independent pivot 1, compared with author pivot 0. Each full alternate replay covers 13,317,120 supported triangles using 13,394,880 Gaussian multiplications. Independent projection histograms validate all eight sorted pivot intervals for each original shard stack, with 82,784 author pivot rows per stack, and verify the exact raw and normalized shard sum against each alternate pivot replay. The shard census took 1.14 seconds.

Every replay preserves the exact raw scalar and combines the factor-denominator product 40512224221827380280140849737629696 with the positive external scale 1/(16*4^64) once. The committed selector-0 ledger is used only to compare the completed selector-1 result.

## Reproduction

Retain inputs/, scripts/ and replays/ as relative directories. The separator.zip and first-child.zip archives can be restored from the pinned Git objects. The generated lineage directory can be recreated from the frozen inputs. Run the checks in a fresh copy, with no generated lineage/ directory.

```sh
sh verify-source-pins.sh
shasum -a 256 -c frozen-inputs.sha256
shasum -a 256 -c source-archives.sha256
python3 audit.py > audit.out
python3 verify-lineage.py outer 0 1 2 3 4 5 6 7 8 > verify-lineage.out
python3 replay-all.py > replay-all.out
python3 verify-shards.py > verify-shards.out
python3 verify-cap-list.py > cap-list.out
python3 aggregate.py > aggregate.out
python3 compare-first.py > compare-first.out
```
