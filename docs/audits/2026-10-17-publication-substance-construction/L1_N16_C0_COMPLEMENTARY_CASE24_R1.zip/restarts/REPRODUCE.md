# Author restart states for complementary cases 24–47

Restore the exact selector-1 parent from the committed
L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip. Put the verified uncompressed file
row-cap-physical-slice-dense-label-tuple0-1-reduced.pkl in a clean parent
directory. It must match SHA256
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
Use trusted checkpoint data when deserializing.

In fresh scratch run python3 /path/to/run.py /path/to/template /path/to/parent.
The template directory must contain tuple0-1/ with the contents of control/.
The saved runner covers all 24 terms and preserves the seven-factor
row-cap output for each. Match the output SHA256s to restart-frontiers.tsv
and the source receipts. These are frozen author restart states rather
than independently accepted term values.
