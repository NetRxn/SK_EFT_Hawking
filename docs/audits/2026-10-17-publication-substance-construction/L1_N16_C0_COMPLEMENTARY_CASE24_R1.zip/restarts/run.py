from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shutil, subprocess, sys, time

base, census = map(Path, sys.argv[1:])
def run_family(family):
    parent=census/f'row-cap-physical-slice-dense-label-{family}-reduced.pkl'
    template=base/family
    for index in range(24,48):
        started=time.monotonic()
        dest=Path(family)/str(index)
        (dest/'checkpoint').mkdir(parents=True)
        for script in ('exact-multicut.py','reduce-label-frontier.py','contract-reduced-label.py','contract-peer.py','peer_pair.py','checkpoint/quotient.py'):
            shutil.copy2(template/script,dest/script)
        def run(script,args,log,allowed):
            with (dest/log).open('xb') as out:
                p=subprocess.run([sys.executable,'-u',script,*args],cwd=dest,stdout=out,stderr=subprocess.STDOUT,timeout=180)
            assert p.returncode in allowed,(family,index,script,p.returncode)
            return p.returncode
        run('exact-multicut.py',[str(parent),'input.pkl',str(index)],'plan.out',(0,))
        run('reduce-label-frontier.py',['input.pkl','primary'],'reduce.out',(0,))
        rc=run('contract-reduced-label.py',['primary'],'contract.out',(0,2))
        log='contract.out'
        if rc==2:
            [old]=list(dest.glob('*-dense-label-primary-reduced.pkl'))
            run('reduce-label-frontier.py',[old.name,'rescue'],'rescue-reduce.out',(0,))
            log='rescue-contract.out'
            rc=run('contract-peer.py',['rescue'],log,(0,2))
        print(family,index,rc,round(time.monotonic()-started,3),(dest/log).read_text().splitlines()[-1],sep='\t',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run_family, ('tuple0-1',)))
