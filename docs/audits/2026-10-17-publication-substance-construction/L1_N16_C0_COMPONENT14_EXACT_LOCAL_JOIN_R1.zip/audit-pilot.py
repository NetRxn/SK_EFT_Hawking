"""Bind the frozen negative throughput trial and show its scope."""
from argparse import ArgumentParser
from difflib import unified_diff
from hashlib import file_digest,sha256
from io import BytesIO
from pathlib import Path
from re import M,findall,search
from subprocess import check_output
from zipfile import ZipFile

HEAD='085be20e08752d1c77668c2e097fc7ed32e948b0'
ROOT='docs/audits/2026-10-17-publication-substance-construction'
PINS={
 'DENSE_COMPILED_FACTORS':'d66dc728ccb948a2630ea87b242564fba9b2c89ed51b3d9f3f100516f270ea42',
 'DENSE_GEOMETRY_COVER':'bf3bfef6484236edc5eca2961d705f9ee27cc17b857c9c69df89114e4d99b1b4',
 'DENSE_REUSE_PILOT':'c078c4fc4efc7ca903e17db526209e20a5692c260f202d837eac586a5a420416',
}
INPUTS={
    'contract-slice.py':'6c447671d2a34deabee6bb5593cab8f8f1c684782af974682f2183e8fe664849',
    'contraction.receipt':'e117e91715af4db5ae63912f1dc009f75e17546b29924c1ace4d68fa4d366d0a',
    'contraction.out':'2e8c56344ca86bb949e51d45c10cf8b1342eee6936e0cebeb195e9c59a32def6',
    'contraction.err':'eb8a6f7bbe3f85ab2b6669eb2eb7f79700a2270c85e9471e7fe10978ef8a97af',
    'pilot.out':'df19503b56caaff4edf14753bd4bf6cdc17e653e3bf2e71a405a2da38f461169',
    'pilot.time':'f39be7c4701345996012d3562a11de0af0c8a9463d19f75322a0170bff2a1f8c',
}
PREP='11a4aa7e219c2a727a8a118a9910a8665bef7ed135ebd5531b3d30d926cfb56b'
REFERENCE_REVIEW='21642edab45338ee4002960cbd1e9abfef23f9d8fdc73a44bfbb9202dc1cb4e5'
SEED='d13c8f9b3ac3dc97a903d02b8f210e07da2e53d0a6871ed13ea4b2a47f64cbd7'

def git_pins(repo):
    for name,digest in PINS.items():
        filename=f'{ROOT}/L1_N16_C0_{name}_R1.zip'
        raw=check_output(['git','-C',str(repo),'show',f'{HEAD}:{filename}'])
        assert sha256(raw).hexdigest()==digest
        print('committed source pin',name,digest)

def file_hash(p):
    with p.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()

def main(args):
    git_pins(args.repo)
    assert file_hash(args.prep)==PREP and file_hash(args.reference)==REFERENCE_REVIEW
    with ZipFile(args.prep) as f:
        for n in (1488,1490):
            raw=f.read(f'group-{n}/frontier.sha256').decode().split()[0]
            assert file_hash(args.sources/f'group-{n}/dense-saturated-frontier.pkl')==raw
    original=args.sources/'group-1490/cached-original-roster/L0'
    assert file_hash(original/'dense-saturated-frontier.pkl')==file_hash(args.pilot/'dense-saturated-frontier.pkl')==SEED
    assert (original/'run.py').read_bytes()==(args.pilot/'run.py').read_bytes()
    for name,digest in INPUTS.items():
        assert file_hash(args.pilot/name)==digest
    src=(original/'contract-slice.py').read_text()
    trial=(args.pilot/'contract-slice.py').read_text()
    switch='    for row,(x,y) in lr.items():\n        base=tuple(row[u] for u in left)\n        for tail,(a0,b0) in lookup[tuple(row[u] for u in li)]:\n'
    assert src.count(switch)==1
    pre,post=src.split(switch)
    assert trial.startswith(pre) and trial.endswith(post)
    middle=trial[len(pre):len(trial)-len(post)]
    assert "regroup_pinned_pair = (len(factors), i, j, work-matched) == (20, 0, 3, 2510784)" in middle
    assert 'assert matched == 1711360' in middle
    assert 'for shared_key in sorted(grouped_left.keys() & lookup.keys(),reverse=True):' in middle
    assert src.count('matched<=8_000_000')==2 and src.count('work+matched<=40_000_000')==2
    assert 'len(out)>=500000' in src
    (args.output/'grouped-native-only.patch').write_text(''.join(unified_diff(
        src.splitlines(keepends=True),trial.splitlines(keepends=True),
        fromfile='original-1490-L0',tofile='grouped-author-pilot')))
    output=(args.pilot/'contraction.out').read_text()
    assert output.count('grouped reverse traversal of the pinned signed pair 20 0 3 1711360')==1
    accepted=[tuple(map(int,m)) for m in findall(r'^join (\d+) (\d+) (\d+) axes (\d+)$',output,M)]
    assert accepted[-1]==(14,2411264,347904,41)
    assert (19,1711360,376960,21) in accepted
    assert all(n<=8_000_000 and rows<=500_000 for _,n,rows,_ in accepted)
    assert sum(n for _,n,_,_ in accepted)==8_689_056
    assert "('no admitted join', 14, 8689056)" in (args.pilot/'contraction.err').read_text()
    receipt=(args.pilot/'contraction.receipt').read_text()
    assert receipt=='child status 1\nelapsed seconds 64.624290\n'
    assert search(r'^real 64\.66$',(args.pilot/'pilot.time').read_text(),M)
    with ZipFile(args.reference) as z:
        accepted_clock=z.read('author/L0/solve.time')
        assert accepted_clock==(original/'../solve-L0.time').read_bytes()
        assert search(rb'^real 54\.38$',accepted_clock,M)
        (args.output/'accepted-1490-L0-original-solve.time').write_bytes(accepted_clock)
    for name in INPUTS:
        (args.output/f'grouped-{name}').write_bytes((args.pilot/name).read_bytes())
    print('pilot shares original signed seed and execution wrapper',SEED)
    print('only pinned product iteration changed; same 500000 rows, 8000000 pair, 40000000 total')
    print('author grouped pass admitted the local join, then status 1 at 14 factors and 8689056 accepted visits')
    print('author grouped child elapsed 64.624290 seconds; external real 64.66 seconds')
    print('accepted original whole L0 solve external real 54.38 seconds')
    print('scoped adverse observation, later product refusal retained; no grouped terminal')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('repo','sources','pilot','prep','reference','output'):
        p.add_argument(name,type=Path)
    main(p.parse_args())
