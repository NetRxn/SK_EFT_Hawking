"""Independent ordered-axis and Gaussian replay of one common L0 local join."""
from argparse import ArgumentParser
from ast import literal_eval
from collections import Counter,defaultdict
from hashlib import file_digest,sha256
from itertools import chain
from math import prod
from pathlib import Path
from pickle import load
from time import perf_counter
from zipfile import ZipFile

CAP_SHA={1488:'0dc54c4ca9924aba3fae210e359ae0482afb3725a6f397f787d3fbe55c03f431',
         1490:'164ff6614e5994a6303eea5c326602d2720b04a6e8faf609f000c6df341696b8'}
PREP_SHA={1488:'fecfd585146f77f7df8170e62004bd0df55ae163743319d2eecb38e9d3478118',
          1490:'2e5e972a63f5808a32faf2f50a64122f7b16b44c8f74f593870639d4cb3bf451'}
DEN={1488:1778314369133712165932108630458368,
     1490:395180970918602703540468584546304}
TARGET_SHA='57e9bc798f60c9aac5c6040580f4165a7f9ac58ffd9fc8fe242f94a11e2c1ca3'
PREP_RECEIPT='11a4aa7e219c2a727a8a118a9910a8665bef7ed135ebd5531b3d30d926cfb56b'
ROW_LIMIT=500_000
PAIR_LIMIT=8_000_000
TOTAL_LIMIT=40_000_000


def read(path,pin):
    with path.open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==pin
        f.seek(0)
        return load(f)


def verify_digest(path,pin):
    with path.open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==pin


def project(scope,subset):
    columns=tuple(scope.index(w) for w in subset)
    return lambda key:tuple(key[i] for i in columns)


def operand(root,group,prep):
    base=root/f'group-{group}'
    verify_digest(base/'dense-saturated-frontier.pkl',PREP_SHA[group])
    prefix=f'group-{group}/'
    raw_cut=prep.read(prefix+'selected-blocks.txt')
    raw_roster=prep.read(prefix+'original-roster.txt')
    assert raw_cut==(base/'selected-blocks.txt').read_bytes()
    assert raw_roster==(base/'original-roster.txt').read_bytes()
    selected_axes,selected_values,block_ids=literal_eval(raw_cut.decode())
    assert len(selected_axes)==len(selected_values)==16 and len(block_ids)==252
    open_axes,keys=literal_eval(raw_roster.decode())
    assert len(open_axes)==12 and len(keys)==8 and not (set(open_axes)&set(selected_axes))
    case=base/'cached-original-roster/L0'
    state=read(case/'row-cap-physical-slice-dense-branch.pkl',CAP_SHA[group])
    assert state['physical_cut']==(open_axes,keys[0])
    identity=((selected_axes,selected_values),(open_axes,keys[0]))
    factors=state['factors']
    assert len(factors)==20 and state['matched']==1_711_360
    pair=state['rejected_pair']
    i,j=pair
    a,x,d=factors[i]
    b,y,e=factors[j]
    assert prod(f[2] for f in factors)==DEN[group]
    assert all(n==2 for n in Counter(w for scope,_,_ in factors for w in scope).values())
    assert all(w[0]!='L' for scope,_,_ in factors for w in scope)
    assert (d,e)==(12,1)
    common=tuple(w for w in a if w in b)
    left=tuple(w for w in a if w not in b)
    right=tuple(w for w in b if w not in a)
    scope=left+right
    assert len(scope)==21 and len(set(scope))==len(scope)
    assert common and len(a)+len(b)==len(scope)+2*len(common)
    restrictions=defaultdict(list)
    for peer,(scope_peer,rows,_) in enumerate(factors):
        if peer in pair:
            continue
        part=tuple(w for w in scope if w in scope_peer)
        if part:
            fn=project(scope_peer,part)
            restrictions[part].append({fn(k) for k in rows})
    normalized={part:set.intersection(*clauses) for part,clauses in restrictions.items()}
    assert all(normalized.values()) and len(normalized)==8
    print('original scope',group,CAP_SHA[group],'pair',pair,'used before',state['used_before'],
          'original factor denominator',DEN[group],'distinct original cut and surviving completion',identity,
          'peer projections',sum(map(len,restrictions.values())),flush=True)
    return ((a,x,d),(b,y,e)),(common,left,right,scope),normalized,identity,state['used_before']


def exact_join(operands,wires,gates):
    t=perf_counter()
    (a,x,d),(b,y,e)=operands
    common,left,right,scope=wires
    lk,lo=project(a,common),project(a,left)
    rk,ro=project(b,common),project(b,right)
    left_prefixes=defaultdict(list)
    buckets=defaultdict(list)
    for k,z in x.items():
        left_prefixes[lo(k)].append((lk(k),complex_pair(z)))
    for k,z in y.items():
        buckets[rk(k)].append((ro(k),complex_pair(z)))
    left_join_hist=Counter(lk(k) for k in x)
    right_join_hist=Counter({k:len(v) for k,v in buckets.items()})
    forecast=sum(c*right_join_hist[k] for k,c in left_join_hist.items())
    assert forecast==1_711_360<=PAIR_LIMIT
    checks=[(project(scope,k),v) for k,v in gates.items()]
    output={}
    visited=supported=peak=0
    for prefix in sorted(left_prefixes):
        active={}
        finalized=len(output)
        for key,(ar,ai) in sorted(left_prefixes[prefix]):
            for tail,(br,bi) in buckets.get(key,()):
                visited+=1
                full=prefix+tail
                if not all(check(full) in allowed for check,allowed in checks):
                    continue
                supported+=1
                re,im=active.get(tail,(0,0))
                v=re+ar*br-ai*bi,im+ar*bi+ai*br
                if any(v):
                    active[tail]=v
                    peak=max(peak,finalized+len(active))
                    assert peak<=ROW_LIMIT
                else:
                    active.pop(tail,None)
        assert all(prefix+tail not in output for tail in active)
        output.update((prefix+tail,z) for tail,z in active.items())
    assert (visited,supported,len(output))==(1_711_360,1_688_320,376_960)
    return (scope,output,d*e),(forecast,visited,supported,peak,len(output),round(perf_counter()-t,6))


def complex_pair(z):
    assert len(z)==2 and all(type(q) is int for q in z) and any(z)
    return z


def canonical_hash(keys):
    h=sha256()
    for key in sorted(keys):
        h.update(repr(key).encode()+b'\n')
    return h.hexdigest()


def main(args):
    verify_digest(args.prep,PREP_RECEIPT)
    with ZipFile(args.prep) as prep:
        a,aw,ag,ak,av=operand(args.sources,1488,prep)
        b,bw,bg,bk,bv=operand(args.sources,1490,prep)
    assert ak[1]==bk[1] and ak[0][0]==bk[0][0] and ak[0][1]!=bk[0][1]
    assert sum(x!=y for x,y in zip(ak[0][1],bk[0][1],strict=True))==2
    assert a==b and aw==bw and ag==bg
    assert av+1_711_360<=TOTAL_LIMIT and bv+1_711_360<=TOTAL_LIMIT
    with (args.output/'peer-predicates.tsv').open('w') as f:
        print('output_axes','allowed_keys','canonical_allowed_keys_sha256',sep='\t',file=f)
        for k in sorted(ag):
            print(k,len(ag[k]),canonical_hash(ag[k]),sep='\t',file=f)
    result,receipt=exact_join(a,aw,ag)
    expected=read(args.pilot/'verified-common-join.pkl',TARGET_SHA)
    assert result==expected
    axis,rows,den=result
    h=canonical_hash(rows.items())
    print('same ordered paired inputs',len(a[0][1]),len(a[1][1]),
          'shared axes',len(aw[0]),'output axes',len(axis),'local denominator',den)
    print('eight normalized effective peer predicates match by axes and all allowed keys')
    print('independent left-output-prefix replay forecast/visits/supported/peak/final/seconds',*receipt)
    print('signed table exact author match',TARGET_SHA,'canonical keyed signed row digest',h)
    (args.output/'operand-scopes.tsv').write_text(''.join(
        f'{k}\t{v!r}\n' for k,v in zip(('shared','left_private','right_private','output_scope'),aw,strict=True)))


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('sources',type=Path)
    p.add_argument('pilot',type=Path)
    p.add_argument('prep',type=Path)
    p.add_argument('output',type=Path)
    args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    main(args)
