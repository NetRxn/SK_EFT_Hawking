# Independent exact local join audit for Groups 1488 and 1490, ordinal L0

**Accept equality of the specified local intermediate.** The scope is the
single captured signed pair contraction with its complete peer predicates.
The group scalar and the subsequent continuations retain their own inputs
and acceptance requirements.

The fresh continuity checkpoint is 085be20e08752d1c77668c2e097fc7ed32e948b0.
The replay verifies the immutable compiled, original cut and geometry
archives and binds the previously reviewed four-group preparation. The
original scope is distinct by two fixed outer cut coordinates, even though
the two original ordinal-zero completions have the same open 12-axis key.
The source denominator products and prior accepted work differ.

| Original group | Captured pair | Prior accepted product visits | Original factor denominator product | Native cap SHA-256 |
|---|---|---:|---:|---|
| 1488 | (1,3) | 2,143,692 | 1778314369133712165932108630458368 | 0dc54c4ca9924aba3fae210e359ae0482afb3725a6f397f787d3fbe55c03f431 |
| 1490 | (0,3) | 2,510,784 | 395180970918602703540468584546304 | 164ff6614e5994a6303eea5c326602d2720b04a6e8faf609f000c6df341696b8 |

Both captured frontiers have 20 factors. The selected operands match
row for row with the same ordered physical axes, signed Gaussian values,
23,904 and 6,464 stored operand rows, and denominators 12 and 1.
There are two shared physical axes and 21 ordered output axes. The
degree-two physical incidence specifies the same contracted and retained
axes in both parents. All eight effective peer predicates were normalized
by the ordered output axes they restrict, intersecting allowed sets
for repeated scopes. Every allowed set agrees exactly across the
two captures. Their canonical checksums are in peer-predicates.tsv.
This is an equality of all selected operands and the entire
recorded predicate conjunction.

Independent replay groups products by the left output prefix. It completes
each fixed prefix against all right rows with the same shared coordinates,
retains both Gaussian components and drops exact cancellations. Prefixes
are disjoint in the final output, so their order gives a different
accumulation schedule from the author's reverse shared-key iteration.
The replay checks all 1,711,360 compatible products, including 1,688,320
that satisfy the common peer conjunction. It reaches 377,005 transient
rows and retains 376,960 exact rows at denominator 12. Measured replay
elapsed is 4.423528 seconds. The measured peak stays inside the unchanged
500,000-row guard and the forecast is within the 8,000,000-product guard.
The complete ordered axes, denominator and all keyed signed rows match
the author's verified-common-join.pkl at SHA-256
57e9bc798f60c9aac5c6040580f4165a7f9ac58ffd9fc8fe242f94a11e2c1ca3.
The canonical sorted keyed signed-row digest is
f1dcbcb7b4dc4b0cbf3c74f3ca9a91bdf537007fbe726bec6bc5b80b1498c50c.

## Separate adverse throughput trial

The grouped author variant changes only the product iteration at the
pinned original Group 1490 pair on its original signed seed. The row,
pair-product and total-product limits remain 500,000, 8,000,000 and
40,000,000. The saved diff and the logs establish the early join through
the row guard, with the same 376,960 retained output rows. The variant
continues to a later no-admitted-product assertion at 14 factors after
8,689,056 accepted visits and exits child status 1. It records 64.624290
seconds of child elapsed time and 64.66 seconds external real time.
The independently reviewed original whole L0 solve used 54.38 seconds
external real time. The grouped run took longer and stopped at a
nonterminal guard. These are frozen observations of separate scoped runs.
No grouped scalar, continued reuse or performance gain is credited.

## Replay

Verify MANIFEST.sha256. Large exact cap and join pickle operands remain
external. The predecessor preparation and Group 1490 review archives
are bound by checksum. The two commands expect the original file layout.

    python3 -B replay.py AUTHOR_GROUP_ROOT GROUPED_PILOT PREPARATION.zip .
    python3 -B audit-pilot.py PUBLICATION AUTHOR_GROUP_ROOT GROUPED_PILOT PREPARATION.zip GROUP1490_REVIEW.zip .

The independently replayed local join and the adverse arm have separate
receipts. The grouped trial is checked from its frozen source and logs.
