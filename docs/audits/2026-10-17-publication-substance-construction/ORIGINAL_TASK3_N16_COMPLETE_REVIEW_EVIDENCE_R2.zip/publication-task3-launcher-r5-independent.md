# Independent N16 one-shot supervisor R5 and child R3 review

**ACCEPT exact R5/R3 launcher mechanisms at bounded mock scope.** All three R4 terminal blockers are repaired and their independent adverse controls now fail closed. This is the launcher review only. ROOT still owns the accepted source, admission, actual execution and result review.

Supervisor SHA256 `548e50bf77243fdda3032f56c139303f36496aac6a819eca34b9e6c30b71d6eb`. Child SHA256 `d2e368b92bff05edd1bec7d29bab100093b4c7cebbb6e39d431e007c04100dc3`, matches parent pin. First and final continuity checks returned SAME. Exact child R3 differs only by adding fixed reserve to terminal budget telemetry. Static AST retains one original pytest selector, `tests/test_original_coefficient_jets.py::test_full_original_f60_g52_and_contacts`, with explicit empty marker expression and no subprocess or fork path.

## Independent bounded mock results

The frozen supervisor body was used with only the output directory substituted into fresh temporary roots. All process, signal, clock and Git replies were mocked. Actual source files were read for hashes. The probe created no real scientific admission or process.

- Both fully valid positive scenarios returned 0 with quiet process group and positive observed RSS and thread count, including exactly 86,400 seconds of terminal monotonic wall. A terminal elapsed 86,401 and a zero elapsed time both returned 1 with the terminal wall reason. The child's valid shorter wall could not override the supervisor.
- The correct XML test name with a wrong module now returns 1, as does a skipped exact testcase. The correctly named single testcase in the exact module remains accepted.
- Above-limit products, modeled payload, checked integer bits and record counts independently return 1. A missing cost object, wrong fixed reserve and Boolean product count also fail. R5 checks exact fixed budget pins and typed bounds. The observed child must emit its real measured terminal cost for an eventual scientific receipt.
- Prior wrong result digest, over-cap native RSS and child wall, wrong PID and changed exact admission bytes all remain refused. Missing positive live samples fail. A normal leader exit with a lingering group probes, performs mocked TERM, rechecks quiescence and refuses acceptance. A quiet group is also probed on positive exit.
- In the concurrent mock the first entrant held the atomic one-shot token inside mock Popen. The second received FileExistsError and never reached Popen. Prior progress and stdout were preserved verbatim in independent preexisting-evidence controls. Neither produced a launch.

Probe and result log `/tmp/publication-task3-launcher-r5-independent.probe.py` and `.probe.log`. Continuity receipts `/tmp/publication-task3-launcher-r5-independent.{first,final}.json`. No real launch, source edit, Git operation, Lean, or admission.
