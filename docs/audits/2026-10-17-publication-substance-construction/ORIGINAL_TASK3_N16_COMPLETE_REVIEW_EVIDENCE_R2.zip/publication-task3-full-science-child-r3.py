"""One-off ROOT observation of the unchanged complete scientific pytest."""
from pathlib import Path
import os,sys,json,time,resource,signal,hashlib,pickle
P=Path('/Users/johnroehm/.codex/worktrees/l1-original-n16-python/SK_EFT_Hawking')
os.chdir(P);sys.path.insert(0,str(P))
if sys.flags.optimize:
 raise RuntimeError('scientific test requires enabled assertions')
pin_bytes=Path(sys.argv[1]).read_bytes()
if hashlib.sha256(pin_bytes).hexdigest()!=sys.argv[2]:
 raise RuntimeError('admission bytes changed before child verification')
pin_record=json.loads(pin_bytes)
PIN=pin_record['source']
assert set(PIN)=={'src/core/formulas.py','src/vestigial/original_coefficients.py','tests/test_original_coefficient_jets.py'}
def verify_source():
 for n,h in PIN.items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h
verify_source()
resource.setrlimit(resource.RLIMIT_CPU,(86400,86405))
from src.core import formulas as f
from src.vestigial import original_coefficients as o
assert Path(f.__file__).resolve()==P/'src/core/formulas.py';assert Path(o.__file__).resolve()==P/'src/vestigial/original_coefficients.py'
original=f.original_n16_metric_sewing_complete
state={'status':'starting','source':PIN,'pid':os.getpid(),'wall_started':time.time()};budget_ref=None;captured=[]
def snapshot(*unused):
 d=dict(state,wall_seconds=time.time()-state['wall_started'],native_self_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
 if budget_ref is not None:d['cost']={k:getattr(budget_ref,k) for k in ['limit','products','integer_products','integer_bit_limit','peak_integer_bits','storage_limit','fixed_reserve_bytes','peak_scalar_records','peak_payload_bytes']}
 p=Path('/tmp/publication-task3-full-science-progress-r1.json');q=p.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(p)
signal.signal(signal.SIGALRM,snapshot);signal.setitimer(signal.ITIMER_REAL,10,10)
def observed(reg,root,spatial_axis,*,budget):
 global budget_ref
 assert not captured and budget_ref is None
 assert budget.limit==70_000_000 and budget.storage_limit==2*1024**3 and budget.integer_bit_limit==1024
 budget_ref=budget;state['status']='scientific_producer_running';snapshot()
 try:
  result=original(reg,root,spatial_axis,budget=budget);captured.append(result);state['status']='producer_complete_original_assertions_pending';return result
 finally:snapshot()
f.original_n16_metric_sewing_complete=observed
import pytest
try:
 rc=int(pytest.main(['-m','','tests/test_original_coefficient_jets.py::test_full_original_f60_g52_and_contacts','-vv','-s','-p','no:cacheprovider','--junitxml=/tmp/publication-task3-full-science-r1.xml']))
 verify_source()
 if rc==0 and len(captured)!=1:
  raise RuntimeError('passed pytest requires exactly one complete producer result')
 state['pytest_exit_code']=rc;state['status']='terminal_pass' if rc==0 else 'terminal_failure'
 if captured:
  p=Path('/tmp/publication-task3-full-science-result-r1.pickle')
  with p.open('wb') as out:pickle.dump(captured[0],out,protocol=5)
  state['result_pickle_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();state['result_pickle_bytes']=p.stat().st_size
 snapshot()
finally:signal.setitimer(signal.ITIMER_REAL,0)
sys.exit(rc)
