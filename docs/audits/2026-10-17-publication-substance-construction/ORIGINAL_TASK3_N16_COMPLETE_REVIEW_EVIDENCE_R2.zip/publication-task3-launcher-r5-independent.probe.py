from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
import hashlib, json, os, pathlib, psutil, signal, subprocess, tempfile, threading, time
from unittest.mock import patch
Path=pathlib.Path
src=Path('/tmp/publication-task3-full-science-supervisor-r5.py').read_text()
child=Path('/tmp/publication-task3-full-science-child-r3.py').read_bytes()
pins={x:hashlib.sha256(Path(x).read_bytes()).hexdigest() for x in ['src/core/formulas.py','src/vestigial/original_coefficients.py','tests/test_original_coefficient_jets.py']}
H='dummy-head'
S='publication-task3-full-science-'
PID=77200
def scenario(kind, race=False):
    with tempfile.TemporaryDirectory(prefix='n16-supervisor-r5-mock-') as temp:
        base=Path(temp)
        (base/(S+'child-r3.py')).write_bytes(child)
        pin=base/(S+'admission.json')
        pin.write_text(json.dumps({'head':H,'source':pins}))
        original_pin=pin.read_bytes()
        if kind=='prior-progress': (base/(S+'progress-r1.json')).write_text('original progress')
        if kind=='prior-stdout': (base/(S+'r1.stdout')).write_text('original stdout')
        code=compile(src.replace("base=Path('/tmp')",f"base=Path({temp!r})"),'<frozen-supervisor-mock-output-root>','exec')
        entered, released=threading.Event(),threading.Event()
        launches=[]; groups=[]; queries=[]; clock=[0]; live_group=[kind=='linger']
        class Leader:
            def __init__(self,args):self.pid=PID;self.args=args;self.count=0
            def poll(self):
                self.count+=1
                if self.count==1 and kind not in ('linger','no-sample'):return None
                clock[0]={'over-wall':86401,'exact-wall':86400,'zero-wall':0}.get(kind,2)
                return 0
            def wait(self,timeout):return 0
        def popen(args,**kwargs):
            assert args[-1]==hashlib.sha256(original_pin).hexdigest()
            assert (base/(S+'launch-once.json')).exists()
            launches.append(args)
            if race:
                entered.set()
                assert released.wait(4)
            data=b'not unpickled in launcher: exact raw payload'
            receipt={'status':'terminal_pass','pytest_exit_code':0,'pid':PID,'source':pins,
                     'native_self_peak_rss_bytes':800000,'wall_seconds':1.25,
                     'cost': {'limit':70000000,'products':222,'integer_products':1024,
                         'integer_bit_limit':1024,'peak_integer_bits':123,'storage_limit':2**31,'fixed_reserve_bytes':128*2**20,
                         'peak_scalar_records':789,'peak_payload_bytes':140000000},
                     'result_pickle_sha256':hashlib.sha256(data).hexdigest(),'result_pickle_bytes':len(data)}
            name='test_full_original_f60_g52_and_contacts'
            classifier='tests.test_original_coefficient_jets'
            case_tail=''
            if kind=='corrupt-digest':receipt['result_pickle_sha256']='bad'
            if kind=='corrupt-rss':receipt['native_self_peak_rss_bytes']=2**31+1
            if kind=='corrupt-wall':receipt['wall_seconds']=86401
            if kind=='corrupt-pid':receipt['pid']=PID+1
            if kind=='corrupt-cost':receipt['cost']['products']=70000001
            if kind=='corrupt-records':receipt['cost']['peak_scalar_records']=120001
            if kind=='corrupt-modeled':receipt['cost']['peak_payload_bytes']=2**31+1
            if kind=='corrupt-bits':receipt['cost']['peak_integer_bits']=1025
            if kind=='corrupt-reserve':receipt['cost']['fixed_reserve_bytes']=0
            if kind=='corrupt-cost-type':receipt['cost']['products']=True
            if kind=='missing-cost':del receipt['cost']
            if kind=='wrong-class':classifier='other.module'
            if kind=='skipped-case':case_tail='<skipped />'
            if kind=='corrupt-pin':pin.write_bytes(original_pin+b' ')
            (base/(S+'progress-r1.json')).write_text(json.dumps(receipt))
            (base/(S+'r1.xml')).write_text(f'<testsuites><testsuite tests="1" failures="0" errors="0" skipped="0"><testcase name="{name}" classname="{classifier}">{case_tail}</testcase></testsuite></testsuites>')
            (base/(S+'result-r1.pickle')).write_bytes(data)
            return Leader(args)
        def observe(pid):
            assert pid==PID
            queries.append(pid)
            return SimpleNamespace(children=lambda recursive:[],memory_info=lambda:SimpleNamespace(rss=640000),num_threads=lambda:1)
        def group(pid,sig):
            assert pid==PID
            groups.append(sig)
            if sig==0:
                if live_group[0]:return
                raise ProcessLookupError
            if sig==signal.SIGTERM:live_group[0]=False;return
            raise AssertionError(sig)
        def run():
            try:exec(code,{'__name__':'__main__'})
            except SystemExit as e:return e.code
            except Exception as e:return type(e).__name__+': '+str(e)
        with patch.object(subprocess,'check_output',side_effect=lambda args,**kwargs:H+'\n' if args[1]=='rev-parse' else ''),patch.object(subprocess,'Popen',side_effect=popen),patch.object(psutil,'Process',side_effect=observe),patch.object(signal,'signal'),patch.object(os,'killpg',side_effect=group),patch.object(time,'monotonic',side_effect=lambda:clock[0]),patch.object(time,'sleep'),redirect_stdout(StringIO()):
            if race:
                with ThreadPoolExecutor(max_workers=2) as pool:
                    first=pool.submit(run)
                    assert entered.wait(4)
                    second=pool.submit(run).result(timeout=4)
                    released.set()
                    verdict=first.result(timeout=4),second
            else:verdict=run()
        result_path=base/(S+'supervisor-r5.json')
        result=json.loads(result_path.read_text()) if result_path.is_file() else {}
        if kind=='prior-progress':assert (base/(S+'progress-r1.json')).read_text()=='original progress'
        if kind=='prior-stdout':assert (base/(S+'r1.stdout')).read_text()=='original stdout'
        return verdict,len(launches),groups,result.get('termination_reason'),result.get('wall_seconds')
expected={
    'normal':(0,1,[0],None),
    'exact-wall':(0,1,[0],None),
    'zero-wall':(1,1,[0],'terminal supervisor wall limit exceeded'),
    'over-wall':(1,1,[0],'terminal supervisor wall limit exceeded'),
    'wrong-class':(1,1,[0],'original N16 pytest receipt is absent or did not pass exactly once'),
    **{kind:(1,1,[0],'child terminal exact budget evidence failed validation') for kind in
       ('corrupt-cost','corrupt-records','corrupt-modeled','corrupt-bits','corrupt-reserve','corrupt-cost-type','missing-cost')},
    'linger':(1,1,[0,signal.SIGTERM,0],'process group still active after leader exit'),
    'no-sample':(1,1,[0],'no positive live RSS/thread observation'),
    'corrupt-digest':(1,1,[0],'captured scientific result digest or size mismatch'),
    'corrupt-rss':(1,1,[0],'child terminal evidence failed validation'),
    'corrupt-wall':(1,1,[0],'child terminal evidence failed validation'),
    'corrupt-pid':(1,1,[0],'child terminal evidence failed validation'),
    'skipped-case':(1,1,[0],'original N16 pytest receipt is absent or did not pass exactly once'),
    'corrupt-pin':(1,1,[0],'scientific admission changed during execution'),
}
for kind,exp in expected.items():
    out=scenario(kind)
    assert out[:4]==exp,(kind,out,exp)
    print(kind,out)
out=scenario('normal',race=True)
assert out[0][0]==0 and out[0][1].startswith('FileExistsError') and out[1]==1
print('concurrent',out)
for kind in ('prior-progress','prior-stdout'):
    out=scenario(kind)
    assert out[1]==0
    print(kind,out)

