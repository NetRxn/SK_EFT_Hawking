"""One ROOT-admitted run; no restart, source edits or persistent pipeline."""
from pathlib import Path
import subprocess,os,json,time,signal,hashlib,sys,psutil
P=Path('/Users/johnroehm/.codex/worktrees/l1-original-n16-python/SK_EFT_Hawking');base=Path('/tmp');child=base/'publication-task3-full-science-child-r3.py';result=base/'publication-task3-full-science-supervisor-r5.json';assert not result.exists()
assert hashlib.sha256(child.read_bytes()).hexdigest()=='d2e368b92bff05edd1bec7d29bab100093b4c7cebbb6e39d431e007c04100dc3'
pin=base/'publication-task3-full-science-admission.json'
if sys.flags.optimize:
 raise RuntimeError('scientific supervision requires enabled assertions')
admission_bytes=pin.read_bytes()
admission_sha=hashlib.sha256(admission_bytes).hexdigest()
admission=json.loads(admission_bytes)
assert set(admission['source'])=={'src/core/formulas.py','src/vestigial/original_coefficients.py','tests/test_original_coefficient_jets.py'}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip()==admission['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=P,text=True)==''
for name,digest in admission['source'].items():
 assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest
# O_EXCL admission is intentionally consumed even if Popen fails. A second
# invocation cannot truncate receipts or start another process.
for name in ('progress-r1.json','r1.xml','result-r1.pickle','launch-r4.json','launch-r5.json'):
 if (base/('publication-task3-full-science-'+name)).exists():
  raise RuntimeError('prior N16 runtime evidence already exists: '+name)
launch_token=base/'publication-task3-full-science-launch-once.json'
with launch_token.open('x') as token:
 token.write(json.dumps({'owner_pid':os.getpid(),'admission_sha256':admission_sha,'source_head':admission['head']},indent=2)+'\n')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH=str(P))
for name in ['PYTHONOPTIMIZE','PYTEST_ADDOPTS','PYTEST_PLUGINS']:env.pop(name,None)
started=time.time();tick=time.monotonic();peak=0;maxthreads=0;reason=None;p=None;rc=None;cleanup_errors=[]
def interrupted(signum,frame):raise RuntimeError('supervisor interrupted by signal '+str(signum))
signal.signal(signal.SIGTERM,interrupted)
def valid_cost(cost):
 if not isinstance(cost,dict):
  return False
 fixed={'limit':70000000,'storage_limit':2*1024**3,'integer_bit_limit':1024,
        'fixed_reserve_bytes':128*1024**2}
 peaks={'products':70000000,'peak_payload_bytes':2*1024**3,
        'peak_integer_bits':1024,'peak_scalar_records':120000}
 return (all(type(cost.get(name)) is int and cost[name]==value for name,value in fixed.items())
         and all(type(cost.get(name)) is int and 0<cost[name]<=limit for name,limit in peaks.items())
         and type(cost.get('integer_products')) is int and cost['integer_products']>=0)
try:
 with (base/'publication-task3-full-science-r1.stdout').open('x') as out,(base/'publication-task3-full-science-r1.stderr').open('x') as err:
  p=subprocess.Popen(['/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python','-B',str(child),str(pin),admission_sha],cwd=P,env=env,stdout=out,stderr=err,start_new_session=True)
  proc=psutil.Process(p.pid)
  (base/'publication-task3-full-science-launch-r5.json').write_text(json.dumps({'pid':p.pid,'wall_started':started,'child_script_sha256':hashlib.sha256(child.read_bytes()).hexdigest(),'rss_limit_bytes':2*1024**3,'wall_limit_seconds':86400,'logical_product_limit':70000000,'integer_limit_bits':1024,'thread_limit':1,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),'command':p.args},indent=2)+'\n')
  while p.poll() is None:
   try:
    processes=[proc]+proc.children(recursive=True);rss=sum(x.memory_info().rss for x in processes);threads=sum(x.num_threads() for x in processes);peak=max(peak,rss);maxthreads=max(maxthreads,threads)
    if rss>2*1024**3:reason='resident-memory limit exceeded'
    if time.monotonic()-tick>86400:reason='wall-time limit exceeded'
    if len(processes)>1:reason='unexpected child process outside single-process scientific admission'
    if threads>1:reason='thread limit exceeded outside single-CPU scientific admission'
   except psutil.NoSuchProcess:
    if p.poll() is None:reason='live admitted child cannot be observed safely'
   if reason:break
   time.sleep(1)
except BaseException as exc:
 reason='supervision failed: '+type(exc).__name__+': '+str(exc)
finally:
 if p is not None:
  try:
   # A normally exited leader is still reaped and checked for lingering
   # members before the terminal receipt can certify quiescence.
   exited=p.poll() is not None
   try:os.killpg(p.pid,0);group_present=True
   except ProcessLookupError:group_present=False
   if exited and group_present and reason is None:
    reason='process group still active after leader exit'
   if group_present:
    # The process group is owned by this exact start_new_session launch.
    # Leader exit is NOT evidence that its group has become quiescent.
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    deadline=time.monotonic()+10
    while True:
     p.poll()  # reap an exited leader before testing group existence
     try:os.killpg(p.pid,0)
     except ProcessLookupError:break
     if time.monotonic()>=deadline:
      try:os.killpg(p.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      deadline=time.monotonic()+10
      while True:
       p.poll()
       try:os.killpg(p.pid,0)
       except ProcessLookupError:break
       if time.monotonic()>=deadline:raise RuntimeError('owned process group quiescence unconfirmed after KILL')
       time.sleep(0.05)
      break
     time.sleep(0.05)
   rc=p.wait(timeout=1)
   if rc==0 and not reason:
    if not (peak>0 and maxthreads==1):
     reason='no positive live RSS/thread observation'
    elif subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip()!=admission['head']:
     reason='scientific source HEAD changed during execution'
    elif hashlib.sha256(pin.read_bytes()).hexdigest()!=admission_sha:
     reason='scientific admission changed during execution'
    else:
     child_receipt=json.loads((base/'publication-task3-full-science-progress-r1.json').read_text())
     if (child_receipt.get('status')!='terminal_pass'
         or child_receipt.get('pytest_exit_code')!=0
         or child_receipt.get('pid')!=p.pid
         or child_receipt.get('source')!=admission['source']
         or not 0<child_receipt.get('native_self_peak_rss_bytes',0)<=2*1024**3
         or not 0<child_receipt.get('wall_seconds',0)<=86400):
      reason='child terminal evidence failed validation'
     elif not valid_cost(child_receipt.get('cost')):
      reason='child terminal exact budget evidence failed validation'
     else:
      import xml.etree.ElementTree as ET
      xml=ET.parse(base/'publication-task3-full-science-r1.xml')
      cases=xml.findall('.//testcase')
      if (len(cases)!=1 or cases[0].get('name')!='test_full_original_f60_g52_and_contacts'
          or cases[0].get('classname')!='tests.test_original_coefficient_jets'
          or any(cases[0].find(label) is not None for label in ('failure','error','skipped'))):
       reason='original N16 pytest receipt is absent or did not pass exactly once'
      else:
       result_path=base/'publication-task3-full-science-result-r1.pickle'
       with result_path.open('rb') as saved:
        result_digest=hashlib.file_digest(saved,'sha256').hexdigest()
       result_size=result_path.stat().st_size
       if (not result_size or result_size!=child_receipt.get('result_pickle_bytes')
           or result_digest!=child_receipt.get('result_pickle_sha256')):
        reason='captured scientific result digest or size mismatch'
  except BaseException as exc:
   cleanup_errors.append(type(exc).__name__+': '+str(exc));reason=reason or 'own-child cleanup failed'
 elapsed=time.monotonic()-tick
 if rc==0 and not reason and not 0<elapsed<=86400:
  reason='terminal supervisor wall limit exceeded'
 receipt={'exit_code':rc,'termination_reason':reason,'cleanup_errors':cleanup_errors,'sampled_peak_tree_rss_bytes':peak,'max_observed_threads':maxthreads,'wall_seconds':elapsed,'wall_started':started,'full_scientific_acceptance':False,'independent_result_review_required':True}
 try:result.write_text(json.dumps(receipt,indent=2)+'\n')
 except BaseException as exc:
  receipt['terminal_receipt_write_error']=type(exc).__name__+': '+str(exc);reason=reason or 'terminal receipt write failed'
 print(json.dumps(receipt,indent=2),flush=True)
raise SystemExit(rc if rc else int(reason is not None))
