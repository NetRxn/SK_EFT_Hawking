# Complete original N16 source resource repair R2

Scratch-only candidate against frozen 34d14897 with the installed R1
scientific source composition. First and final canonical continuity both
returned SAME. The three-file patch
/tmp/publication-task3-complete-source-author-r2.diff has SHA256
b001cb49206274858097d594b8156479e95d8d90fbc22798167dc8799485fc45.
It passes a read-only apply check. No actual checkout edit or Git write
occurred.

Geometry now receives a fixed bounded reservation before its first call,
then an actual returned-object storage check. The reservation covers the
fixed 16-site, 64-anchor original geometry, at most 16 × 7 grouped
vertices, and its short exact fill searches. Every direct reserve charges
the retained geometry. Auxiliary entry and both row constructions,
determinant layers, terminal copy, and projections charge the retained
geometry and direct result. The auxiliary cubic also keeps actual original
rows, current result rows, Gaussian cache, and radial table live in its
checks. Top and mixed calls retain the earlier literal table and, for
mixed, the computed fourth moment. All checks use the same budget and
reject an observed or reserved N16 record peak above 120,000.

Scalar stages charge geometry, both edge results, live temporal tables,
curvature cache and accumulated raw/loop outputs before the next
allocation. The temporal wedge reserves per operation with the actual
current frames, already derived common covariance, local basis and
retained wrapper state. Finished wedge polynomials and temporary
projection terms are released before another wedge. All science and
the original slow test are preserved. No normalization or physical
claim is added.

Three bounded regressions failed on R1 and passed on R2. They establish
refusal before geometry at a one-byte limit, retained geometry in the
real direct reserve and geometry plus direct result in the real
auxiliary entry reserve, and actual retained bytes in each tiny
determinant layer. The coefficient-jet regression passed 128 tests with
both complete tests deselected. The exact slow selector collected
test_full_original_f60_g52_and_contacts with no execution.

Bounded measured accounting:
- A two-row determinant, two scalar products, recorded 140,518,048
  modeled bytes alone and 140,550,946 with a 16,384-byte retained
  bytearray. Scalar output and record count were identical.
- Stopping at the actual first auxiliary row construction captured
  69,224 recursively measured retained bytes in the live argument and a
  4,096-record new reservation. Geometry plus the bounded direct edge
  peaked at 178,251,700 modeled bytes, 28,658 reserved or occupied
  scalar records and 2,535 products.
- These measurements are bounded allocation witnesses. No complete
  auxiliary table, N16 producer, full original one-site, or Lean run
  took place.

Existing independent scientific poison receipts remain unchanged: raw
core 3645/4 for one chirality omitted, 3240 with the negative area term
omitted, and 7290 with the combined factorial omitted. The original
full scalar test and selector are unchanged and unexecuted. ROOT owns
the launcher repair, independent review and runtime admission.

Raw evidence: /tmp/publication-task3-complete-source-author-r2.red.log,
 /tmp/publication-task3-complete-source-author-r2.green.log,
 /tmp/publication-task3-complete-source-author-r2.green-final.log,
 /tmp/publication-task3-complete-source-author-r2.collect.log,
 /tmp/publication-task3-complete-source-author-r2.metrics.py and .metrics.log,
 /tmp/publication-task3-complete-source-author-r2.final.json.
