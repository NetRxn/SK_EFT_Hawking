# Dense L1 site-factor assembly

All 976 local site tuples, covering all 16 original sites, were assembled
using the local rosters and edge bindings in L1_N16_C0_DENSE_EDGE_TEMPORAL_R1.
The local run retains 1,952 signed split-factor files. Their checksums
are listed here. The verifier checks complete rosters for site, edge and
temporal inputs and repeats all 176 prior single-site comparisons.

The binding control calls the original factor constructors for the dense
edge and temporal label blocks and records their exact wire layouts,
signed row hashes and denominators. This supplies numerical factor inputs
for the full signed join. That contraction remains open and the support
and factor counts do not subtract entries from the accepted residual.
