from ast import literal_eval
from pathlib import Path
from collections import Counter
import hashlib,os,sys

dense=Path(sys.argv[1])
script=Path(sys.argv[2])
sewn=Path.cwd()
os.environ['L1_PROFILE_CODES']='503841882182,1461451755920'
sys.argv=[sys.argv[0],str(dense),str(sewn),'-1']
source=script.read_text().split('factors=[f for t in range(2) for x in range(8)',1)[0]
exec(source)
shapes={v:k for k,v in patterns.items()}
stats=Counter()
def receipt(f,labels):
    assert len(set(f.wires))==len(f.wires)
    assert all(len(k)==len(f.wires) and any(z) for k,z in f.rows.items())
    assert f.denom>0
    digest=hashlib.sha256()
    for key,z in sorted(f.rows.items()):
        digest.update(repr((key,z)).encode('ascii')+b'\n')
    print(f.name,labels,f.wires,f.denom,len(f.rows),digest.hexdigest(),sep='\t')
    stats[f.name[0]+' blocks']+=1
    stats[f.name[0]+' rows']+=len(f.rows)
for line in (dense/'edge-bindings.tsv').read_text().splitlines():
    t,u,v,k,row,index=line.split('\t')
    t,u,v,k,index=map(int,(t,u,v,k,index))
    labels=literal_eval(row)
    states=dict(zip(((layer,x,k) for layer in range(2) for x in (u,v)),labels))
    a,b,left,right=shapes[index]
    plan={(t,u,k):left,(t,v,k):right}
    assert left==(a+b,*states[t,u,k],*states[1-t,u,k])
    assert right==(a+b,*states[t,v,k],*states[1-t,v,k])
    receipt(spatial_factor(t,u,v,k),labels)

for line in (dense/'temporal-bindings.tsv').read_text().splitlines():
    t,x,h,row,shape=line.split('\t')
    t,x,h=map(int,(t,x,h))
    labels=literal_eval(row)
    scope=tuple(sorted((t,y,k) for k in range(3) for y in (x,x^(1<<k))))
    states=dict(zip(scope,labels))
    assert len(states)==6
    assert literal_eval(shape)==tuple((v[h],bool(t^(x!=y))) for (_,y,k),v in sorted(states.items()) if v[h])
    receipt(temporal_factor(t,x,h),labels)
assert stats['E blocks']==184 and stats['T blocks']==320
print(dict(stats),file=sys.stderr)
