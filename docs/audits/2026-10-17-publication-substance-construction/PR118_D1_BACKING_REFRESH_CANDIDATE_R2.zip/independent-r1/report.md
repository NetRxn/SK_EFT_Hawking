# PR118 D1 backing refresh independent review

**REVISE for claims-review record provenance.** Exact base 9f8608351d9c5c94ed9d18df24ea2649087e8fd5 and candidate patch SHA-256 75d9468562ba0d5b87f0d2d53fa4a67421e24bfd861f6cf5a7993802bf53ffbc. Continuity packet publication-pr118-d1-backing-refresh-independent-r1 matched. Both input manifests verified. I applied the patch in an isolated exact-base clone with the delivery environment's Python 3.14.8. The full-index patch reproduction matched byte for byte.

1. Both refreshed graphene rows use the old descriptive label “Graphene Dirac-fluid platform” in the new section and ID fields. It does not occur as a heading in exact TeX. The claims-reviewer contract derives the section slug from the source heading. The exact parent heading is “The bilayer-graphene Dirac fluid” at 1290. The containing subsection is “The 2+1D acoustic metric and the quasi-one-dimensional reduction” at 1293–1294. Recompute the two IDs and raw ID parts from the chosen actual heading with the canonical helper. Preserve the archived predecessor via rewrite_of. The other five recorded headings are actual TeX headings. The two polariton rows use the real parent heading rather than their nearest subsection.
2. The live summary.agent_text still says “Verdict GREEN” and claims all four old anchor reproductions pass, including the obsolete 92% graphene result. The top-level yellow verdict, seven-span count and historical-scope note establish the author's intention, but the current summary field still presents May's contradictory outcome. Put the scoped six-PASS/one-WARN result and 11 carried historical rows in the active summary. Retain the original narrative in the immutable archived blob or label it explicitly as historical.

## Reproduced evidence

- The seven exact, unique TeX spans and line ranges match 1042–1046, 1083–1091, 1125–1130, 1382–1387, 1387–1390, 1927–1932, and 1934–1938. All IDs recompute from their supplied labels and normalized quotes. Item 1 concerns the two supplied labels.
- Scientific scope is consistent with Lean source and the pinned catalog. ModifiedBogoliubov carries the relation as a field. The floor facts concern the defined scalar. The beta-small implication requires the carrier, delta_k < 1 and the supplied beta bound. The two polariton passages are conditional model algebra, with normalized crossing 0.1748495762830299, G=0.5 and SNR=5 at N=100. The Lean detection lemma is a sufficient lower bound given positive gain. The reuse classifier reproduced 107/120 with 13 platform-specific, and the row remains WARN/partial. Its count records classification against registered roots. The separate graphene source binding sets c_s=v_F/sqrt(2) in ExactWKBParams.
- All 11 links resolve to exact canonical graph nodes. The nine Lean-linked catalog entries include a structure and definitions and carry zero project axiom dependencies. The source aggregate imports all three modules.
- Historical review blob 7d9c6d0a6ab35691777b2694c7010861108f3d83 and original SHA-256 fd7b6728fc3c2e0b2a430f66714c76a5afbfd96f4894f3c691c3f7eab135ab1b are recoverable from the exact base. The three retired active rows have 3/2/2 replacement links through rewrite_of. The eleven carried rows preserve decoded values and order. Archived r1, audit log, manuscript, all existing finding arrays/dispositions and tracked ledgers were unchanged.
- Canonical schema validation passed with 18 active rows. Canonical dry run reported zero tombstones and zero rewrite candidates. The one prior auto-closure and one candidate are historical counts carried in the input. Canonical prose-state check reported one historical event, zero sentences and no drift.
- Independent graph reconstruction showed 2,313 to 2,312 Lean links and 111 to 106 unresolved. Exactly five removed unresolved entries belonged to D1, which is now zero. The candidate changes only the ceiling constant, from 109 to 106. The no-memo canonical gate measured 106 against ceiling 106, with zero headroom. The six canonical backing tests passed, including one seeded dangling link past the ceiling, empty corpus, graph failure and source integrity. git diff --check passed.
- A seven-row ingest append can record the corrected run after its claim identities and summary are reconciled. This report concerns the two-file original candidate and its dry run. The separate proposed audit append was outside its reviewed patch scope. Evidence is scoped to source, pinned catalog, graph and the six backing tests. Fresh Lean-kernel, full-tree, Stage 10, Stage 13 and publication acceptance are outside the reviewed scope.

## Commands

In the isolated clone, Python resolves to the delivery worktree's .venv/bin/python.

```text
python3 scripts/codex_continuity.py check <primary packet>
shasum -a 256 -c manifest.sha256  [in each original input directory]
git apply --check <candidate.patch>
git apply <candidate.patch>
git diff --check
git diff --binary --full-index   [compared byte for byte to candidate.patch]
python scripts/sentence_state.py validate papers/D1/claims_review.json
python scripts/sentence_state.py ingest_agent_run papers/D1/claims_review.json --dry-run
python scripts/sentence_state.py rebuild_prose_state --paper D1 --check
python scripts/validate.py --check chain_backing_targets_resolve --no-memo --no-archive --json
python -m pytest -vv -o cache_dir=<scratch> tests/test_d5_reviews.py::TestChainBackingTargetsResolve
PYTHONPATH=scripts:src:. python <scratch>/verify.py
```

Candidate claims SHA-256 2be9ad3125e30eacd0527e28ce6ef3f3000c2176f9c3e8f7f7cb85698ad89982.
Candidate checks SHA-256 277af8ef677babbefd553691de2d0d0f48e61241eae59ad3e2809c6a0d7e23a5.
