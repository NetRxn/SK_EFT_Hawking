import hashlib
import json
import math
import re
import subprocess
from collections import Counter
from pathlib import Path

import chain_canonicalize as cc
import count_theorem_reuse
from core.formulas import stimulated_hawking_gain, stimulated_hawking_snr
import sentence_state
from validation.checks import reviews

def git(*args):
    return subprocess.check_output(["git", *args])

claim_path = "papers/D1/claims_review.json"
source = git("show", "HEAD:papers/D1/paper_draft.tex").decode()
assert source == Path("papers/D1/paper_draft.tex").read_text()
old_bytes = git("show", f"HEAD:{claim_path}")
old_blob = git("rev-parse", f"HEAD:{claim_path}").decode().strip()
assert old_blob == "7d9c6d0a6ab35691777b2694c7010861108f3d83"
assert hashlib.sha256(old_bytes).hexdigest() == "fd7b6728fc3c2e0b2a430f66714c76a5afbfd96f4894f3c691c3f7eab135ab1b"
assert git("cat-file", "blob", old_blob) == old_bytes
old = json.loads(old_bytes)
new = json.loads(Path(claim_path).read_bytes())
assert not sentence_state.validate_claims_review(old)
assert not sentence_state.validate_claims_review(new)
assert set(git("diff", "--name-only").decode().splitlines()) == {claim_path, "scripts/validation/checks/reviews.py"}
unchanged = [p for p in git("ls-files").decode().splitlines() if p.startswith("papers/D1/") or "supersession_ledger" in p]
for p in unchanged:
    if p != claim_path:
        assert Path(p).read_bytes() == git("show", f"HEAD:{p}"), p
a, b = [{r["id"]: r for r in d["sentences"]} for d in [old, new]]
assert len(a) == len(old["sentences"]) == 14 and len(b) == len(new["sentences"]) == 18
assert len(set(a) & set(b)) == 11 and all(a[i] == b[i] for i in a.keys() & b.keys())
assert [i for i in a if i in b] == [i for i in b if i in a]
archive = {"sentence:D1:exact-wkb:r4anchor2": 3, "sentence:D1:polariton:r4anchor3": 2, "sentence:D1:graphene:r4anchor4": 2}
assert set(a) - set(b) == set(archive) == set(new["review_scope"]["replaced_historical_ids"])
assert new["review_scope"]["source_commit"] == git("rev-parse", "HEAD").decode().strip()
assert new["review_scope"]["historical_review_blob"] == old_blob
assert new["verdict"] == "yellow"
assert {k for k in old.keys() | new.keys() if old.get(k) != new.get(k)} == {
    "reviewer_run_id", "review_date", "review_round", "reviewer_model", "verdict",
    "review_scope", "sentences", "summary",
}
assert {k for k in old["summary"].keys() | new["summary"].keys() if old["summary"].get(k) != new["summary"].get(k)} == {
    "total_sentences_walked", "by_type", "by_verdict", "active_rows",
}
assert new["summary"]["total_sentences_walked"] == 7 and new["summary"]["active_rows"] == 18
for k, attr in [("by_type", "type"), ("by_verdict", "agent_verdict")]:
    assert Counter(new["summary"][k]) == Counter(r[attr] for r in b.values())
replacements = [r for i, r in b.items() if i not in a]
assert Counter(r["rewrite_of"] for r in replacements) == archive
assert sorted((r["tex_line_start"], r["tex_line_end"]) for r in replacements) == [
    (1042, 1046), (1083, 1091), (1125, 1130), (1382, 1387), (1387, 1390), (1927, 1932), (1934, 1938),
]
assert Counter(r["agent_verdict"] for r in replacements) == {"PASS": 6, "WARN": 1}
for r in replacements:
    q = r["quote"]
    assert source.count(q) == 1
    offset = source.index(q)
    first_line = source.count("\n", 0, offset) + 1
    assert (first_line, first_line + q.count("\n")) == (r["tex_line_start"], r["tex_line_end"])
    assert r["section"] in source or r["section"] == "Graphene Dirac-fluid platform"
    assert sentence_state.compute_sentence_id("D1", r["section"], q) == (
        r["id"], r["quote_normalized"], r["raw_id_parts"]["quote_hash"],
    )
    assert r["agent_run_id"] == new["reviewer_run_id"] and r["tombstone"] is False
    print("exact", first_line, r["tex_line_end"], r["id"], r["agent_verdict"], flush=True)
idx = cc.GraphIndex()
catalog = {d["name"]:d for d in json.loads(Path("lean/lean_deps.json").read_bytes())}
added_links = [l for r in replacements for l in r["chain_proposed"]["links"]]
assert len(added_links) == 11 and len({(l["kind"], l["target"]) for l in added_links}) == 11
for l in added_links:
    kind, target = l["kind"], l["target"]
    res = cc.canonicalize_link(kind, target, idx)
    expected = ("formula:" if kind == "formula" else "lean:") + target
    assert res.status == "resolved" and res.target_id == expected, res
    print("resolved", kind, target, res.target_id)
    if kind == "theorem":
        d = catalog[target]
        assert not d["axiom_deps_project"]
        print("catalog", d["kind"], d["module"], d["type"].replace("\n", " "))
def scan(rows):
    total = 0
    bad = Counter()
    for p, sid, k, tgt in rows:
        if k in {"theorem", "lemma", "axiom"}:
            total += 1
            if cc.canonicalize_link(k, tgt, idx).status == cc.UNRESOLVABLE:
                bad[p, sid, tgt] += 1
    return total, bad
after_rows = list(cc._iter_links())
old_d1 = [("D1", r["id"], l["kind"], l["target"]) for r in a.values()
          for l in (r.get("chain_proposed") or {}).get("links", [])]
before_total, before = scan([r for r in after_rows if r[0] != "D1"] + old_d1)
after_total, after = scan(after_rows)
assert sum(before.values()) == 111 and sum(after.values()) == reviews.UNRESOLVED_CHAIN_LINK_CEILING == 106
assert not (after - before) and set((p, sid) for p, sid, _ in before - after) == {("D1", sid) for sid in archive}
assert not any(p == "D1" for p, _, _ in after)
assert before_total == 2313 and after_total == 2312, (before_total, after_total)
print(f"Lean link totals {before_total} -> {after_total}, unresolved {before.total()} -> {after.total()}")
for k, count in (before - after).items():
    print("removed_unresolved", *k, count)
c = count_theorem_reuse.classify()
assert c["totals"]["theorems"] == 120 and c["totals"]["reused"] == 107 and c["totals"]["platform_specific"] == 13
print("census", c["totals"])
r = math.log(3) / (2 * math.pi)
g = stimulated_hawking_gain(r, 1)
snr = stimulated_hawking_snr(r, 1, 100)
assert math.isclose(g, 0.5) and math.isclose(snr, 5)
print("polariton", r, g, snr)
