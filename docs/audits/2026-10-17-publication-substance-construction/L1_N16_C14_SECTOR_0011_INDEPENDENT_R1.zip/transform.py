from collections import defaultdict
from fractions import Fraction as Q
from functools import cache
from itertools import product
from math import gcd,prod
from pathlib import Path
import json,sys
import numpy as np
A=Path(sys.argv[1])
C=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
def rows(f):
    for line in f.open():yield json.loads(line)
def f(x):return tuple(map(f,x)) if isinstance(x,(tuple,list)) else x
def add(z,w):return z[0]+w[0],z[1]+w[1]
def mul(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def pair(z):
    a,b,c,d=z
    return Q(a,b),Q(c,d)
raw={};trace={}
for name,labels,tab in rows(A/'interior-rays.jsonl'):
    if name.startswith('trace'):trace[name]=(labels,{tuple(k):tuple(z) for k,z in tab})
    else:raw[name]=(labels,{j:{tuple(k):tuple(z) for k,z in v} for j,v in tab})
M={tuple(k):v for k,v in rows(A/'weighted-mask-amplitude-0011.jsonl')}
assert len(M)==1853
basis={};middles={}
for record in rows(A/'spoke-bases.jsonl'):
    name=record['name']
    cl=defaultdict(dict);rr=defaultdict(dict)
    for i,k,z in record['column']:cl[k][i]=pair(z)
    for k,i,z in record['row']:rr[k][i]=pair(z)
    mid={int(k):{(i,j):pair(z) for i,j,z in v} for k,v in record['coordinates'].items()}
    basis[name]=(cl,rr);middles[name]=mid
    assert len(cl)==len(rr)==10 and len(mid)==11
    # Recover complete matrices by fixed entry dot products, exact Gaussian rationals.
    for j,source in raw[name][1].items():
        result={}
        for u,v in product(range(16),repeat=2):
            value=(0,0)
            for (i,k),z in mid[j].items():
                value=add(value,mul(mul(cl[i].get(u,(0,0)),z),rr[k].get(v,(0,0))))
            a,b=divmod(u,4); c,d=divmod(v,4)
            key=(c,d,a,b) if name in 'CD' else (a,b,c,d)
            if any(value):result[key]=value
        assert result==source
print('all 44 exact Gaussian spoke matrices reconstructed entry-by-entry',flush=True)
selected=[set(),set()]
middletuples={}
for k in M:
    a,b,c,d,e,f0=k
    terms=list(product(*(middles[n][v].items() for n,v in zip('ABCD',(a,b,c,d),strict=True))))
    middletuples[k]=terms
    for v in terms:
        selected[0].add((e,*(i for (i,j),z in v)))
        selected[1].add((f0,*(j for (i,j),z in v)))
assert sum(map(len,middletuples.values()))==515801
expected=json.loads((A/'selected-basis-keys.json').read_text())
assert selected==[set(map(tuple,expected[k])) for k in ('left','right')]

coords=[
 (('a1_0','a0_0','q02_0','q03_0'),('a1_1','a0_1','q02_1','q03_1'),('q23_0','q12_0'),('q23_1','q12_1')),
 (('q01_2','q00_2','a2_2','a3_2'),('q01_3','q00_3','a2_3','a3_3'),('q40_2','q81_2'),('q40_3','q81_3'))]
def tensor(which,j):
    name=f'trace{2*which+j}'
    labels,table=trace[name]
    k=[labels.index(a) for a in coords[which][j]+coords[which][2+j]]
    ans=np.zeros((2,4,4,4,4,16),dtype=np.int64)
    for a,z in table.items():
        x,b,c,d,e,f0=(a[i] for i in k)
        ans[:,x,b,c,d,4*e+f0]=z
    return ans
def matrix(n,which,i):
    z=np.zeros((2,4,4),dtype=np.int64)
    for idx,t in basis[n][which][i].items():
        assert all(a.denominator==1 for a in t)
        r,c=divmod(idx,4)
        z[:,r,c]=list(map(int,t))
    return z
def split_bound(a):
    return sum(int(np.max(np.abs(i))) for i in a)
max_bound=0
@cache
def transform(which,ix):
    # Apply each 4×4 Gaussian basis matrix as a separate tensor mode,
    # then contract with the complete second source trace in one exact
    # 16×256 by 256×16 integer matrix product.
    global max_bound
    u=tensor(which,0)
    v=tensor(which,1).reshape(2,256,16)
    bound=split_bound(u)
    for axis,(name,key) in enumerate(zip('ABCD',ix,strict=True)):
        z=matrix(name,which,key)
        bound*=4*split_bound(z)
        assert bound<2**63
        F=lambda a,b:np.moveaxis(np.tensordot(a,b,axes=(axis,0)),-1,axis)
        re=F(u[0],z[0])-F(u[1],z[1])
        im=F(u[0],z[1])+F(u[1],z[0])
        u=np.stack((re,im))
    u=u.reshape(2,256,16)
    bound*=256*split_bound(v)
    max_bound=max(max_bound,bound)
    assert bound<2**63
    return np.stack((u[0].T@v[0]-u[1].T@v[1],u[0].T@v[1]+u[1].T@v[0]))
out=[{},{}]
for side,keys in enumerate(selected):
    table=raw['EF'[side]][1]
    for e,*ix in sorted(keys):
        H=transform(side,tuple(ix))
        value=(0,0)
        for (a,b,c,d),z in table[e].items():
            x=tuple(int(i) for i in H[:,4*a+c,4*b+d])
            value=add(value,mul(x,z))
        if any(value):out[side][e,*ix]=value
stored=[{},{}]
for side,k,z in rows(A/'selected-transforms.jsonl'):stored[side=='right'][tuple(k)]=tuple(z)
assert stored==out and list(map(len,out))==[480,468]
print('all selected trace transforms match via dense exact axis contractions; rigorous int64 max bound',max_bound,flush=True)

amplitude={}
for k,terms in middletuples.items():
    a,b,c,d,e,f0=k
    value=(0,0)
    for v in terms:
        z=mul(out[0].get((e,*(i for (i,j),z in v)),(0,0)),out[1].get((f0,*(j for (i,j),z in v)),(0,0)))
        for _,x in v:z=mul(z,x)
        value=add(value,z)
    assert all(Q(x).denominator==1 for x in value)
    if any(value):amplitude[k]=tuple(map(int,value))
assert len(amplitude)==1853 and amplitude=={tuple(k):tuple(v) for k,v in rows(A/'q-amplitudes-0011.jsonl')}
print('all 1853 exact source-contracted Q amplitudes match',flush=True)

# Two literal original-spoke controls, independent of the basis.
@cache
def direct_half(side,id,a,b):
    tab=raw['EF'[side]][1][id]
    spans=[[],[]]
    for j,p in enumerate((a,b)):
        name=f'trace{2*side+j}'
        labels,rr=trace[name]
        order=coords[side][j]+coords[side][2+j]
        idx=[labels.index(z) for z in order]
        for key,z in rr.items():
            q=tuple(key[i] for i in idx)
            if q[:4]==p:spans[j].append((q[4:],z))
    answer=(0,0)
    for ((p,q),z),((r,s),w) in product(*spans):
        answer=add(answer,mul(mul(z,w),tab.get((p,r,q,s),(0,0))))
    return answer
res=json.loads((A/'q-result.json').read_text())
for ctl in [c for i in range(2) for c in json.loads((A/f'raw-control-{i}.json').read_text())['controls']]:
    k=tuple(ctl['ray_key'])
    sides=[]
    for n,id in zip('ABCD',k[:4],strict=True):
        vs=[]
        for x,z in raw[n][1][id].items():
            if n in 'CD':x=x[2:]+x[:2]
            vs.append((x,z))
        sides.append(vs)
    value=(0,0)
    nonzero=0
    first=None
    for v in product(*sides):
        x=[q for q,z in v]
        a=direct_half(0,k[4],tuple(q[0] for q in x),tuple(q[1] for q in x))
        b=direct_half(1,k[5],tuple(q[2] for q in x),tuple(q[3] for q in x))
        if not(any(a) and any(b)):continue
        z=mul(a,b)
        for _,w in v:z=mul(z,w)
        value=add(value,z)
        if first is None:first=z
        nonzero+=1
    assert prod(map(len,sides))==ctl['original_spoke_products']==65536
    assert nonzero==ctl['nonzero_paths']==36864
    assert value==tuple(ctl['exact_numerator'])==amplitude[k]
    assert tuple(v-2*z for v,z in zip(value,first))==tuple(ctl['single_path_flip'])
print('both literal original-spoke controls and adverse single-path signs matched',flush=True)
mg=gcd(*M.values())
assert mg==res['mask_numerator_gcd']
normalized=tuple(sum((M[k]//mg)*amplitude[k][i] for k in M) for i in (0,1))
assert normalized==tuple(res['normalized_interior_scalar_numerator'])
graph=json.loads((C/'graph.json').read_text())
assert (graph['scalar_numerator_multiplier'],graph['external_exponential_divisor'])==(24**5,512)
den=graph['exact_denominator_before_exponential_divisor']
assert den==res['graph_denominator']
s=Q(mg*24**5,den*512)
final=tuple(v*s for v in normalized)
assert list(map(str,final))==res['weighted_exact_sector_value']
print('independent exact sector0011 scalar',*map(str,final),flush=True)
