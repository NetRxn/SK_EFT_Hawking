from collections import defaultdict
from fractions import Fraction as Q
from functools import cache
from itertools import product
from math import gcd,prod
from pathlib import Path
import json,sys
import numpy as np
A=Path(sys.argv[1])
C=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
def rows(f):
    for line in f.open():yield json.loads(line)
def f(x):return tuple(map(f,x)) if isinstance(x,(tuple,list)) else x
def add(z,w):return z[0]+w[0],z[1]+w[1]
def mul(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def pair(z):
    a,b,c,d=z
    return Q(a,b),Q(c,d)
raw={};trace={}
for name,labels,tab in rows(A/'interior-rays.jsonl'):
    if name.startswith('trace'):trace[name]=(labels,{tuple(k):tuple(z) for k,z in tab})
    else:raw[name]=(labels,{j:{tuple(k):tuple(z) for k,z in v} for j,v in tab})
M={tuple(k):v for k,v in rows(A/'weighted-mask-amplitude-0011.jsonl')}
assert len(M)==1853
basis={};middles={}
for record in rows(A/'spoke-bases.jsonl'):
    name=record['name']
    cl=defaultdict(dict);rr=defaultdict(dict)
    for i,k,z in record['column']:cl[k][i]=pair(z)
    for k,i,z in record['row']:rr[k][i]=pair(z)
    mid={int(k):{(i,j):pair(z) for i,j,z in v} for k,v in record['coordinates'].items()}
    basis[name]=(cl,rr);middles[name]=mid
    assert len(cl)==len(rr)==10 and len(mid)==11
    # Recover complete matrices by fixed entry dot products, exact Gaussian rationals.
    for j,source in raw[name][1].items():
        result={}
        for u,v in product(range(16),repeat=2):
            value=(0,0)
            for (i,k),z in mid[j].items():
                value=add(value,mul(mul(cl[i].get(u,(0,0)),z),rr[k].get(v,(0,0))))
            a,b=divmod(u,4); c,d=divmod(v,4)
            key=(c,d,a,b) if name in 'CD' else (a,b,c,d)
            if any(value):result[key]=value
        assert result==source
print('all 44 exact Gaussian spoke matrices reconstructed entry-by-entry',flush=True)
selected=[set(),set()]
middletuples={}
for k in M:
    a,b,c,d,e,f0=k
    terms=list(product(*(middles[n][v].items() for n,v in zip('ABCD',(a,b,c,d),strict=True))))
    middletuples[k]=terms
    for v in terms:
        selected[0].add((e,*(i for (i,j),z in v)))
        selected[1].add((f0,*(j for (i,j),z in v)))
assert sum(map(len,middletuples.values()))==515801
expected=json.loads((A/'selected-basis-keys.json').read_text())
assert selected==[set(map(tuple,expected[k])) for k in ('left','right')]

coords=[
 (('a1_0','a0_0','q02_0','q03_0'),('a1_1','a0_1','q02_1','q03_1'),('q23_0','q12_0'),('q23_1','q12_1')),
 (('q01_2','q00_2','a2_2','a3_2'),('q01_3','q00_3','a2_3','a3_3'),('q40_2','q81_2'),('q40_3','q81_3'))]
def tensor(which,j):
    name=f'trace{2*which+j}'
    labels,table=trace[name]
    k=[labels.index(a) for a in coords[which][j]+coords[which][2+j]]
    ans=np.zeros((2,4,4,4,4,16),dtype=np.int64)
    for a,z in table.items():
        x,b,c,d,e,f0=(a[i] for i in k)
        ans[:,x,b,c,d,4*e+f0]=z
    return ans
def matrix(n,which,i):
    z=np.zeros((2,4,4),dtype=np.int64)
    for idx,t in basis[n][which][i].items():
        assert all(a.denominator==1 for a in t)
        r,c=divmod(idx,4)
        z[:,r,c]=list(map(int,t))
    return z
def split_bound(a):
    return sum(int(np.max(np.abs(i))) for i in a)
max_bound=0
@cache
def transform(which,ix):
    # Apply each 4×4 Gaussian basis matrix as a separate tensor mode,
    # then contract with the complete second source trace in one exact
    # 16×256 by 256×16 integer matrix product.
    global max_bound
    u=tensor(which,0)
    v=tensor(which,1).reshape(2,256,16)
    bound=split_bound(u)
    for axis,(name,key) in enumerate(zip('ABCD',ix,strict=True)):
        z=matrix(name,which,key)
        bound*=4*split_bound(z)
        assert bound<2**63
        F=lambda a,b:np.moveaxis(np.tensordot(a,b,axes=(axis,0)),-1,axis)
        re=F(u[0],z[0])-F(u[1],z[1])
        im=F(u[0],z[1])+F(u[1],z[0])
        u=np.stack((re,im))
    u=u.reshape(2,256,16)
    bound*=256*split_bound(v)
    max_bound=max(max_bound,bound)
    assert bound<2**63
    return np.stack((u[0].T@v[0]-u[1].T@v[1],u[0].T@v[1]+u[1].T@v[0]))
def gauss_mat(a,b):
    return np.stack((a[0]@b[0]-a[1]@b[1],a[0]@b[1]+a[1]@b[0]))
def bmat(name,side):
    res=np.zeros((2,16,10),dtype=np.int64)
    for j,tab in basis[name][side].items():
        for k,z in tab.items():
            assert all(i.denominator==1 for i in z)
            res[:,k,j]=[int(i) for i in z]
    return res

initial=json.loads((A/'tensor-admission.json').read_text())
result=json.loads((A/'q-result.json').read_text())
frozen=[{},{}]
for side,k,z in rows(A/'selected-transforms.jsonl'):frozen[side=='right'][tuple(k)]=tuple(z)
receipts=[]
for side in (0,1):
    inputs=[tensor(side,j).reshape(2,256,16) for j in (0,1)]
    count=[np.count_nonzero(np.any(x,axis=0),axis=0) for x in inputs]
    for r in sorted({k[0] for k in selected[side]}):
        mat=np.zeros((2,16,16),dtype=np.int64)
        for (a,b,c,d),z in raw['EF'[side]][1][r].items():mat[:,4*a+c,4*b+d]=z
        source=int(sum(count[0][i]*count[1][j] for i,j in zip(*np.where(np.any(mat,axis=0)))))
        bound=16*16*split_bound(inputs[0])*split_bound(inputs[1])*split_bound(mat)
        assert bound<2**63
        value=gauss_mat(gauss_mat(inputs[0],mat),np.swapaxes(inputs[1],1,2))
        value=value.reshape((2,)+(4,)*8).transpose((0,1,5,2,6,3,7,4,8)).reshape(2,16,16,16,16)
        expected=[int(np.count_nonzero(np.any(value,axis=0)))]
        charges=source
        bounds=[]
        for axis,name in enumerate('ABCD'):
            step=bmat(name,side)
            active=np.any(value,axis=0)
            axis_support=np.count_nonzero(np.moveaxis(active,axis,0).reshape(16,-1),axis=1)
            basis_count=np.count_nonzero(np.any(step,axis=0),axis=1)
            charges+=int(np.dot(axis_support,basis_count))
            # Every input dimension apart from the current mode can be dense.
            bounds.append(int(np.count_nonzero(np.any(step,axis=0)))*prod(x for i,x in enumerate(active.shape) if i!=axis))
            bound*=16*split_bound(step)
            assert bound<2**63
            F=lambda a,b:np.moveaxis(np.tensordot(a,b,axes=(axis,0)),-1,axis)
            value=np.stack((F(value[0],step[0])-F(value[1],step[1]),F(value[0],step[1])+F(value[1],step[0])))
            expected.append(int(np.count_nonzero(np.any(value,axis=0))))
        for j,*ix in selected[side]:
            if j==r:assert tuple(int(x) for x in value[(slice(None),*ix)])==frozen[side].get((j,*ix),(0,0))
        record=dict(side=('left','right')[side],ray=r,source_pair_products=source,
                    transform_upper_bounds=bounds,prospective=source+sum(bounds),
                    actual_work=charges,nonzero_rows_by_stage=expected)
        receipts.append(record)
assert receipts==result['per_ray_chunks']
assert [{k:v for k,v in r.items() if k not in ('actual_work','nonzero_rows_by_stage')} for r in receipts]==initial['admitted_ray_partitions']
assert len(receipts)==22 and max(x['actual_work'] for x in receipts)==370624 and max(x['prospective'] for x in receipts)==813568
assert max(max(x['nonzero_rows_by_stage']) for x in receipts)==18432
pre=10+4+4+1853+2*sum(len(t) for _,t in trace.values())
assert pre==initial['initial_charged']
assert pre+sum(x['prospective'] for x in receipts)+515801==initial['prospective_aggregate']==17611304
assert pre+sum(x['actual_work'] for x in receipts)+515801==result['total_work']==6583496
assert max(x['prospective'] for x in receipts)<=initial['ray_cap']==4000000 and 17611304<initial['aggregate_cap']==24000000
print('all 22 exact partition counts, per-stage sizes, source-pair products and prospective arithmetic verified',flush=True)
