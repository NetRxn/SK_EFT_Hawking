from pathlib import Path
import json,sys
a=Path(sys.argv[1])
def j(n):return json.loads((a/n).read_text())
s=j('separation.json'); q=j('q-result.json')
assert s['meters']==dict(work=1173130,rows=8768,output=272971)
assert sum(s['work'].values())==1173130 and s['sampled_peak_rss_bytes']==64634880
assert sum((a/f).stat().st_size for f in ('interior-rays.jsonl','mask-weights.jsonl','weighted-mask-amplitude-0011.jsonl'))==272971
assert q['sampled_peak_rss']==37928960 and sum(q['work'].values())==6583496
assert '4000001, 4000000' in (a/'qcontract-refusal.log').read_text().splitlines()[-1]
for k in range(2):
    r=j(f'raw-control-{k}.json')
    assert sum(r['operations'].values())==r['charged']==78468<r['cap']==4_000_000
assert not q['other_sectors_evaluated'] and not q['full_representative_evaluated']
print('reported local caps, alternative refusal, byte totals, work and sampled RSS receipts verified')
