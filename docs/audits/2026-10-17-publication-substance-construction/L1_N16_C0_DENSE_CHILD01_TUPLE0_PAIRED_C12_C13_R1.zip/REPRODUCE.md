# L1 original paired cuts 12 and 13

Each distinct original outer coordinate of group 128, descendant (0,1), tuple 0 has 16 exact terms on its five-factor join-cap input. Restore the frozen 48-coordinate roster and branch operands from L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip at 383f42e573962e8f7f41c0111c82a59a605c73ff. Check source hashes and reproduce each outer pair and cap.

Re-run the 16-way partition from author/<cut>/frontier in fresh scratch. Use prepare.py on the corresponding frozen input, then run-cohort.py. The terminal runner l1-resolve-capped-triangles-12-13.py takes the frontier directory and advances each completed three-factor cap using the checked weighted interval forecast. Use sum-case2.py from each frontier directory and compare every signed ledger line. The positive external factor 1/(16*4^64) is applied once. Verify all recorded operand hashes.

Verify manifest.sha256 and each portable independent manifest. Run coverage-retally.py with the repository audit archive directory, including the C5_C6 package from the same checkpoint. Compare the full 48-coordinate ledger to coverage-ledger.tsv.
