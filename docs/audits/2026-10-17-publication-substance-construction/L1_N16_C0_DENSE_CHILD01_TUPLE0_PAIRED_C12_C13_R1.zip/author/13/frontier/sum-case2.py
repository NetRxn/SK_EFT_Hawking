from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

header=Path('prepare.out').read_text().splitlines()
roster=literal_eval(header[1].removeprefix('weighted roster '))
assert len(roster)==16 and sum(products for _,products in roster)==34_473_600
assert len(dict(roster))==16
first=int(header[2].split('projected')[0].rsplit(' ',2)[1])
lines=[line.split('\t') for line in Path('cohort.tsv').read_text().splitlines()]
assert [(int(label),int(products)) for label,products,*_ in lines]==roster
real=imaginary=Fraction()
for index,((label,products),(_,_,status,*_)) in enumerate(zip(roster,lines,strict=True)):
    assert status in ('0','2')
    folder=Path(str(label))
    filename='contraction.out' if status=='0' else 'sum-shards.out'
    path=folder/filename
    [pair]=re.findall(r'^exact normalized real (\S+) imaginary (\S+)',path.read_text(),re.M)
    re_i,im_i=map(Fraction,pair)
    real+=re_i
    imaginary+=im_i
    print(index,label,products,re_i,im_i,path.as_posix(),sep='\t')
print('sum',real,imaginary,sep='\t')
