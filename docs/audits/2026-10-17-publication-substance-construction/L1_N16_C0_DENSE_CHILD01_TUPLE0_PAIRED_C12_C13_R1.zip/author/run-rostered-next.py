from ast import literal_eval
import pickle
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
reference = root/'probe28-inner'
primary_scripts = ('run-primary.py','exact-multicut.py','reduce-label-frontier.py',
                   'contract-reduced-label.py','contract-peer.py','peer_pair.py','reduce-open.py')

def command(scratch, script, arguments, receipt, allowed=(0,), timeout=450):
    start=time.monotonic()
    with (scratch/receipt).open('xb') as out:
        run=subprocess.run([sys.executable,'-u',script,*arguments],cwd=scratch,stdout=out,
                           stderr=subprocess.STDOUT,timeout=timeout)
    if run.returncode not in allowed:
        raise RuntimeError((scratch,script,run.returncode))
    return run.returncode,round(time.monotonic()-start,3)

def solve(index):
    sub=root/f'probe{index}-inner'
    sub.mkdir()
    for script in primary_scripts:
        shutil.copyfile(reference/script,sub/script)
    shutil.copytree(reference/'checkpoint',sub/'checkpoint')
    shutil.copyfile(root/'probe1-inner'/'run-primary-selected.py',sub/'run-primary-selected.py')
    sample=root/f'combined-{index}.pkl'
    tag=f'sum{index}'
    timings=[]
    if index==29:
        assert sample.is_file()
        with sample.open('rb') as stream:
            digest=hashlib.file_digest(stream,'sha256').hexdigest()
        assert f'{digest}  {sample.name}' in (root/f'neighbor29-admitted.sha256').read_text().splitlines()
    else:
        timings.append(('combine',*command(root,'sum-branches-checked.py',[str(index)],f'combine-{index}.out')))
    timings.append(('reduce',*command(root,'reduce-label-frontier.py',[sample.name,tag],f'reduce-{index}.out')))
    cap_result=command(root,'contract-reduced-label.py',[tag],f'contract-{index}.out',(0,2))
    timings.append(('outer',*cap_result))
    if cap_result[0]==2:
        restarts=sorted(root.glob(f'*-dense-label-{tag}-reduced.pkl'))
        assert len(restarts)==1,restarts
        parent=restarts[0]
        with parent.open('rb') as stream:
            has_pair='rejected_pair' in pickle.load(stream)
        if has_pair:
            timings.append(('first',*command(sub,'run-primary-selected.py',[str(parent),'0'],'primary-first.tsv')))
            _,roster=literal_eval((sub/'slice-0.roster').read_text())
            assert len(roster)==len(dict(roster))
            if len(roster)>1:
                timings.append(('primary',*command(sub,'run-primary-selected.py',[str(parent),*map(str,range(1,len(roster)))],'primary-rest.tsv',timeout=750)))
            tests=(sub/'primary-first.tsv').read_text()
            if len(roster)>1:
                tests+=(sub/'primary-rest.tsv').read_text()
            with (sub/'primary.tsv').open('x') as out:
                out.write(tests)
            assert sorted(int(row.split('\t')[0]) for row in tests.splitlines())==list(range(len(roster)))
            assert all((sub/f'slice-{i}.roster').read_bytes()==(sub/'slice-0.roster').read_bytes() for i in range(len(roster)))
            caps=[row.split('\t')[0] for row in tests.splitlines() if row.split('\t')[1]=='2']
        else:
            print(index,'retained join cap',parent.name,flush=True)
            caps=[]
        if caps:
            timings.append(('rescue',*command(sub,'reduce-open.py',caps,'rescue.tsv')))
    with (sub/'wall-timing.tsv').open('x') as out:
        for label,status,secs in timings:
            print(label,status,secs,sep='\t',file=out)
    print(index,'generic stages terminal',timings,flush=True)

with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(solve,map(int,sys.argv[1:])))
