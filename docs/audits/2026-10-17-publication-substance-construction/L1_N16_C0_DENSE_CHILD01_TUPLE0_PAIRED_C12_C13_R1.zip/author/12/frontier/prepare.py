from collections import Counter
from hashlib import file_digest
from pathlib import Path
import pickle
import sys

source=Path(sys.argv[1])
with source.open('rb') as inp:
    digest=file_digest(inp,'sha256').hexdigest()
    inp.seek(0)
    state=pickle.load(inp)
factors=state['factors']
assert len(factors)==5 and 'rejected_pair' not in state
assert 'refusal' in state
axis=('G',1,0,2)
assert all(n==2 for n in Counter(w for a,_,_ in factors for w in a).values())
assert tuple(i for i,(a,_,_) in enumerate(factors) if axis in a)==(0,4)
left,right=factors[0],factors[3]
shared=tuple(w for w in left[0] if w in right[0])
li=tuple(left[0].index(w) for w in shared)
ri=tuple(right[0].index(w) for w in shared)
pair_counts=Counter(tuple(row[i] for i in ri) for row in right[1])
projected=Counter()
position=left[0].index(axis)
for row in left[1]:
    projected[row[position]]+=pair_counts[tuple(row[i] for i in li)]
projected=+projected
assert (len(projected),sum(projected.values()),max(projected.values()))==(16,31_075_200,2_599_200)
print('input sha256',digest)
print('weighted roster',sorted(projected.items()))
selected=max(projected,key=lambda k:(projected[k],-k))
print('fixed',axis,selected,'projected',projected[selected])
for i in (0,4):
    scope,rows,denominator=factors[i]
    pos=scope.index(axis)
    filtered={row[:pos]+row[pos+1:]:z for row,z in rows.items() if row[pos]==selected}
    assert len(filtered)==sum(row[pos]==selected for row in rows) and filtered
    factors[i]=scope[:pos]+scope[pos+1:],filtered,denominator
state['conditioning']=[*state['conditioning'],(axis,selected)]
with Path('selected.pkl').open('xb') as out:
    pickle.dump(state,out,protocol=5)
