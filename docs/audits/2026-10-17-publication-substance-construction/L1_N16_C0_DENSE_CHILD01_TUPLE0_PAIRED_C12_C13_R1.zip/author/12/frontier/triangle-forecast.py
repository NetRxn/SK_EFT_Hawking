from collections import Counter
from pathlib import Path
from pickle import load
import sys

for label in map(int,sys.argv[1:]):
    here=Path(str(label))
    state=next(here.glob('join-cap-*.pkl'))
    with state.open('rb') as inp:
        f=load(inp)['factors']
    assert len(f)==3
    A,B,C=f
    def project(row,ids):
        return tuple(row[k] for k in ids)
    def positions(source,target):
        return tuple(source.index(w) for w in sorted(set(source)&set(target)))
    ai,bi=positions(A[0],B[0]),positions(B[0],A[0])
    aj,cj=positions(A[0],C[0]),positions(C[0],A[0])
    bs=Counter(project(row,bi) for row in B[1])
    cs=Counter(project(row,cj) for row in C[1])
    costs=[min(bs[project(row,ai)],cs[project(row,aj)]) for row in sorted(A[1])]
    total=len(costs)
    for count in (1,2,4,8,16):
        bounds=[sum(costs[total*i//count:total*(i+1)//count]) for i in range(count)]
        if 2*max(bounds) <= 16_000_000:
            break
    assert 2*max(bounds)<=16_000_000
    print(label,total,sum(bounds),count,max(bounds),sep='\t',flush=True)
