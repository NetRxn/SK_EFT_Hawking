from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys,time

root=Path(__file__).resolve().parent
plan=[tuple(map(int,line.split('\t'))) for line in (root/'triangle-forecast.tsv').read_text().splitlines()]
assert len(plan)==8 and all((n,k,m)==(102240,2,4282464) for _,n,_,k,m in plan)
def work(job):
    label,part,count=job
    here=root/str(label)
    state=next(here.glob('join-cap-*.pkl'))
    started=time.monotonic()
    with (here/f'slice-{label}-shard-{part}.out').open('xb') as log:
        subprocess.run([sys.executable,'-B',str(root/'triangle-shards.py'),str(state),str(part),str(count)],
                       cwd=here,stdout=log,stderr=subprocess.STDOUT,timeout=75,check=True)
    return label,part,round(time.monotonic()-started,6)
with ThreadPoolExecutor(max_workers=2) as workers:
    for result in workers.map(work,((label,part,count) for label,_,_,count,_ in plan for part in range(count))):
        print(*result,sep='\t',flush=True)
for label,_,_,count,_ in plan:
    here=root/str(label)
    with (here/'sum-shards.out').open('xb') as log:
        subprocess.run([sys.executable,'-B',str(root/'sum-shards.py'),str(label),str(count)],
                       cwd=here,stdout=log,stderr=subprocess.STDOUT,check=True)
