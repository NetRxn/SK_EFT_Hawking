from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys,time

root=Path(sys.argv[1])
stop=time.monotonic()+800
seen=set()
while len(seen)<16 and time.monotonic()<stop:
    rows=[line.split('\t') for line in (root/'cohort.tsv').read_text().splitlines()
          if len(line.split('\t'))>=4]
    assert len({int(r[0]) for r in rows})==len(rows)
    for label,work,status,*_ in rows:
        if label in seen:
            continue
        if status=='0':
            seen.add(label)
            continue
        assert status=='2',(label,status)
        here=root/label
        [p]=list(here.glob('join-cap-*.pkl'))
        forecast=subprocess.check_output([sys.executable,'-B','triangle-forecast.py',label],cwd=root,text=True)
        j,n,total,k,max_probes=map(int,forecast.split())
        assert j==int(label) and 2*max_probes<=16_000_000
        started=time.monotonic()
        for part in range(k):
            with (here/f'slice-{label}-shard-{part}.out').open('xb') as out:
                subprocess.run([sys.executable,'-B',str(root/'triangle-shards.py'),str(p),str(part),str(k)],
                               stdout=out,stderr=subprocess.STDOUT,cwd=here,check=True,timeout=75)
        with (here/'sum-shards.out').open('xb') as out:
            subprocess.run([sys.executable,'-B',str(root/'sum-shards.py'),label,str(k)],
                           stdout=out,stderr=subprocess.STDOUT,cwd=here,check=True,timeout=30)
        print(j,n,total,k,max_probes,round(time.monotonic()-started,6),sep='\t',flush=True)
        seen.add(label)
    if len(seen)<16:
        time.sleep(2)
assert len(seen)==16,sorted(seen)
