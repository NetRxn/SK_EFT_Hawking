# Independent review of paired cut 13

The exact signed value of outer coordinate `(33,(2,))` in group128 descendant (0,1), tuple 0 is `3072782437024838439123/2596148429267413814265248164610048 + 0i`. Its raw Gaussian subtotal is `(261064493259593459350861257675526503526349422411462468662460416,0)` with factor denominator `40512224221827380280140849737629696`. Each term was normalized once by the positive external factor 1/(16*4^64). The fixed mode records independently yield total occupation 32, factorial contribution 16 and even phase exponent. The cut weights count compatible products and do not multiply the signed scalar.

The continuity packet matched checkpoint `6de0e90eecd746c9277149f348efce2f4aebf7d8`. The original selector branches each have 48 compatible outer coordinates and 6,427,904 matched products. The independent signed constructor recovered the exact seven-factor combined state with 106,344 products per branch and 77,328 signed pair rows. The combined state has SHA-256 `60547dc5897f3da017a3e554146247c270fa35e6eb8c00004410ede95f5ca365`. Byte replay recovered both retained joins, with 808,704 and 4,214,912 products, and the five-factor join refusal after 5,023,616 products. The cap SHA-256 is `0422e6d628e16755765f6ccff593759498bbd7af47c188fd6f9030a331e0c2b5`.

Both incident scopes of `G(1,0,2)` have the same 16 supported values. The independent histogram matches 34,473,600 weighted (0,3) pair products and verifies exhaustive, mutually exclusive coverage. Each of the 16 inverse lifts recovered the exact original rows, axes, denominators and Gaussian coefficients for both affected factors and the other three tables. Each ordinary preparation, reduction, contraction or refusal reproduced byte for byte, with 48 commands and 390.512527 summed command seconds. All 16 retained inner refusals are three-factor inputs that close exactly via the shard route.

The 0 generic terminals passed independent signed sparse contractions. The 16 triangles were contracted with an alternate pivot using the signed kernel, and all 32 author shard intervals were separately contracted to verify each raw Gaussian pair and normalized pair. The signed ledger is the sum of the distinct exact terms. Independent terminal routes performed 194,703,104 products and took 192.633087 summed command seconds. Independent replay of the author shard intervals took 141.226331 additional summed seconds. These timings are command durations from concurrent work. Both original caps and all inner refusal receipts are retained.

The portable manifest covers the exact ledger, the selected receipts, input hashes and verification scripts. Large original binary checkpoints are bound by the operand inventory. From this case directory, with the review scripts at its parent, run:

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B ../retally.py | cmp - signed-ledger.tsv
```
