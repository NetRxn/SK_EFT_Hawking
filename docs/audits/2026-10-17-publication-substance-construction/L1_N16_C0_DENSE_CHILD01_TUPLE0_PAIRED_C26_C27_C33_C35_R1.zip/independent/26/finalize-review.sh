#!/usr/bin/env bash
set -euo pipefail
python3 -B replay-all.py 5 6 > replay-jobs-triangles.tsv
cat replay-jobs-{primary,rescue-early,rescue-final,triangles}.tsv | sort -k1,1n > replay-jobs.tsv
test "$(wc -l < replay-jobs.tsv | tr -d ' ')" = 9
python3 -B freeze-inputs.py
shasum -a 256 -c paired-operands.sha256 > paired-operands-verify.out
shasum -a 256 -c inner-operands.sha256 > inner-operands-verify.out
python3 -B audit.py > audit.out
python3 -B verify-shard-coverage.py > shard-coverage.out
python3 -B - <<'PY_INNER' > terminal-plan-verify.out
from pathlib import Path
p=Path('author-receipts/inner/terminal-plan.tsv')
assert p.read_text().splitlines() == [
    f'{i}\tjoin-cap-dense-label-rescue-{i}-1-reduced.pkl\ttriangle-shards.py\t()\t()'
    for i in (5,6)
]
print('PASS terminal-plan paths match both bound three-factor checkpoints')
PY_INNER
python3 -B ledger-metrics.py > signed-ledger.tsv
python3 -B ../terminal-inventory.py 26 > terminal-inventory.tsv
cat lineage-{primary,rescue-early,rescue-final}.tsv | sort -s -k1,1n > lineage.tsv
cat lineage-*/stage-timing.tsv | sort -s -k1,1n > lineage-stage-timing.tsv
python3 -B - <<'PY'
from csv import DictReader
from pathlib import Path
s=[r.split('\t') for r in Path('lineage-stage-timing.tsv').read_text().splitlines()]
assert len(s)==45 and sum(r[2]=='2' for r in s)==11
assert len(Path('lineage.tsv').read_text().splitlines())==18
assert all(not f.read_text() for f in Path('.').glob('lineage-*-errors.out'))
with Path('signed-ledger.tsv').open() as f:
    rows=[r for r in DictReader(f,delimiter='\t') if r['slice']!='subtotal']
assert len(rows)==9
with Path('REVIEW.md').open('a') as report:
    elapsed = sum(float(r[-1]) for r in s)
    independent = sum(int(r['review_products']) for r in rows)
    author = sum(int(r['author_terminal_products']) for r in rows)
    wall = sum(float(r['review_wall_seconds']) for r in rows)
    print(f'\n**Pass.** All nine author terms and both raw eight-shard sums match independent exact replay. Independently counted shard intervals cover each pivot-0 input and reproduce every candidate probe count. The complete inner lineage reproduces 18 stages and 45 commands, including 11 caps. Every saved state and log matches byte for byte. The summed elapsed time is {elapsed:.3f} seconds. Independent terminal arithmetic used {independent:,} Gaussian products across {wall:.4f} summed seconds. The author terminal receipts record {author:,} products. The signed ledger reports these costs per terminal. This result covers only paired coordinate 25.',file=report)
PY
{
  find author-receipts -type f
  printf '%s\n' *.py *.sh *.out *.tsv *-operands.sha256 REVIEW.md ../terminal-inventory.py ../continuity.json continuity-readback.json
} | awk '!/^review-manifest/' | LC_ALL=C sort -u | xargs shasum -a 256 > review-manifest.sha256
shasum -a 256 -c review-manifest.sha256 > review-manifest-verify.out
shasum -a 256 review-manifest.sha256
wc -l review-manifest.sha256
tail -1 signed-ledger.tsv
