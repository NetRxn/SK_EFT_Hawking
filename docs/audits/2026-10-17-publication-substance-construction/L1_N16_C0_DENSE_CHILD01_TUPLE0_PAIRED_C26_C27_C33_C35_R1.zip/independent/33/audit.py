from ast import literal_eval
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

root=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe33-inner')
denominator=40512224221827380280140849737629696

def census(state,roster):
    axes,entries=literal_eval(roster.read_text())
    assert len(entries)==len(dict(entries))
    f=state['factors']
    assert set(Counter(w for scope,_,_ in f for w in scope).values())=={2}
    left,right=[f[i] for i in state['rejected_pair']]
    shared=sorted(set(left[0])&set(right[0]))
    lmatch=tuple(left[0].index(k) for k in shared)
    rmatch=tuple(right[0].index(k) for k in shared)
    lcut=tuple(left[0].index(k) for k in axes)
    left_count=Counter((tuple(row[p] for p in lmatch),tuple(row[p] for p in lcut)) for row in left[1])
    right_count=Counter(tuple(row[p] for p in rmatch) for row in right[1])
    weights=Counter()
    for (key,cut),n in left_count.items():
        if count:=n*right_count[key]:
            weights[cut]+=count
    assert weights==dict(entries) and sum(weights.values())==state['matched']
    return axes,weights,sorted(weights,key=lambda k:(weights[k],k))

def inverse_lift(state,axes,coordinate,path):
    fixed=dict(zip(axes,coordinate,strict=True))
    raw=path.read_bytes()
    child=pickle.loads(raw)
    assert child['conditioning']==state['conditioning']+list(fixed.items())
    assert child['label_partition']==state['label_partition']
    for (scope,rows,d),(small,cut_rows,e) in zip(state['factors'],child['factors'],strict=True):
        assert d==e and small==tuple(k for k in scope if k not in fixed)
        expected_rows={row:value for row,value in rows.items() if all(row[p]==fixed[k] for p,k in enumerate(scope) if k in fixed)}
        recovered={}
        for row,value in cut_rows.items():
            assignment=dict(zip(small,row,strict=True))
            assignment.update(fixed)
            recovered[tuple(assignment[k] for k in scope)]=value
        assert recovered==expected_rows
    print('PASS exact inverse lift',coordinate,sha256(raw).hexdigest(),sum(len(rows) for _,rows,_ in child['factors']))
    return child

def check_stage(path, child, length=None):
    raw=path.read_bytes()
    state=pickle.loads(raw)
    assert state['conditioning']==child['conditioning'] and state['label_partition']==child['label_partition']
    ff=state['factors']
    if length is not None:
        assert len(ff)==length
    assert set(Counter(w for scope,_,_ in ff for w in scope).values())=={2}
    assert all(d>0 and len(set(scope))==len(scope) and all(len(row)==len(scope) and len(value)==2 and any(value) and all(type(x) is int for x in value) for row,value in rows.items()) for scope,rows,d in ff)
    assert prod(d for _,_,d in ff)==denominator
    print('PASS stage',path.name,sha256(raw).hexdigest(),len(ff),sum(len(rows) for _,rows,_ in ff))
    return state

paired_dir=author.parent
raw_combined=(paired_dir/'combined-33.pkl').read_bytes()
assert sha256(raw_combined).hexdigest()=='9cb7e84ec99b02370d2322411da3ba7723afcd894af93eedb23d0597a2eb2a61'
combined=check_stage(paired_dir/'combined-33.pkl',pickle.loads(raw_combined),7)
assert dict(combined['conditioning'])['R',0,6,1,1,1]==1
assert dict(combined['conditioning'])['G',0,4,2]==34
assert dict(combined['conditioning'])['J',1,4,2]==(2,)
assert combined['binary_sum']=={'summed_index':('R',0,0,2,0,1),'values':(0,1),'coordinate':(34,(2,))}
assert ('R',0,0,2,0,1) not in dict(combined['conditioning'])
check_stage(paired_dir/'label-sum33-reduced-frontier.pkl',combined,7)
parent=paired_dir/'row-cap-physical-slice-dense-label-sum33-reduced.pkl'
inner=check_stage(parent,combined,7)
assert sha256(parent.read_bytes()).hexdigest()=='8e2290fd7c72c34a740373a5a63ff43454f711b518ad90825b01ec5c7ec7be59'
assert inner['matched']==2001024
print('PASS paired coordinate (34,(2,)) and 7-factor restart hash')
axes,weights,order=census(inner,author/'slice-0.roster')
assert axes==(('G',0,1,2),) and len(order)==9 and sum(weights.values())==2001024
print('PASS exhaustive nine-coordinate inner roster',axes,sum(weights.values()),min(weights.values()),max(weights.values()))
if '--cuts-only' in __import__('sys').argv[1:]:
    for i,coordinate in enumerate(order):
        assert (author/f'slice-{i}.roster').read_bytes()==(author/'slice-0.roster').read_bytes()
        child=inverse_lift(inner,axes,coordinate,author/f'slice-{i}.pkl')
        check_stage(author/f'label-slice-{i}-reduced-frontier.pkl',child)
    print('PASS all nine roster coordinates and signed inverse lifts')
    raise SystemExit(0)
ledger=(author/'author-case33.tsv').read_text().splitlines()
assert len(ledger)==10
hard={int(i): args for i,*args in
      (line.split('\t') for line in (author/'terminal-plan.tsv').read_text().splitlines())}
alt={int(i):(int(a),int(b)) for i,a,b in
     (line.split('\t') for line in (root/'alternate-pairs.tsv').read_text().splitlines())}
values=[]
signature=r'^(?:independent )?exact normalized real (\S+) imaginary (\S+)(?: |$)'
for i,row in enumerate(ledger[:-1]):
    n,coord,count,real,imag,receipt=row.split('\t')
    assert int(n)==i and order[i]==(int(coord),) and weights[order[i]]==int(count)
    assert (author/f'slice-{i}.roster').read_bytes()==(author/'slice-0.roster').read_bytes()
    sub=inverse_lift(inner,axes,order[i],author/f'slice-{i}.pkl')
    tag=receipt.removesuffix('-contract.out')
    for p in sorted(author.glob(f'label-rescue-{i}-*-reduced-frontier.pkl')):
        check_stage(p,sub)
    for p in sorted(author.glob(f'*-dense-label-rescue-{i}-*-reduced.pkl')):
        check_stage(p,sub)
    check_stage(author/f'label-slice-{i}-reduced-frontier.pkl',sub)
    for p in sorted(author.glob(f'*-dense-label-slice-{i}-reduced.pkl')):
        check_stage(p,sub)

    is_triangle=i in hard and hard[i][1] == "triangle-shards.py"
    is_four=i in hard and hard[i][1] == "close-four-shards.py"
    assert i not in hard or is_triangle or is_four
    if is_triangle or is_four:
        assert receipt==f'slice-{i}-shard-sum.out'
        terminal=author/hard[i][0]
        state=check_stage(terminal,sub,3 if is_triangle else 4)
        suffix='triangle' if is_triangle else 'four'
        replay=(root/f'slice-{i}-{suffix}-replay.out').read_text()
        if is_triangle:
            assert re.search(r'^independent pivot [12] ',replay,re.M)
        else:
            assert f'alternate pair {alt[i]}' in replay and alt[i] != literal_eval(hard[i][2])
        assert sha256(terminal.read_bytes()).hexdigest() in replay
        raw_sig=(r'^raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$' if is_triangle
                 else r'^raw (-?\d+) (-?\d+) factor denominator (\d+)$')
        raw_re,raw_im,d=map(int,re.search(raw_sig,replay,re.M).groups())
        assert d==denominator
        nrows=len(state['factors'][0 if is_triangle else literal_eval(hard[i][2])[0]][1])
        end=0
        sums=[0,0]
        work=[]
        probes=[]
        for k in range(8):
            log=(author/f'slice-{i}-shard-{k}.out').read_text()
            interval=re.search(r'^left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)$',log,re.M)
            lo,hi,total,ordinal,shard_count=map(int,interval.groups())
            assert lo==end==nrows*k//8 and hi==nrows*(k+1)//8 and (total,ordinal,shard_count)==(nrows,k,8)
            end=hi
            assert f"conditioning {sub['conditioning']} label partition {sub['label_partition']}" in log
            metrics=re.search(r'^closure products (\d+) retained outer matches (\d+) closure probes (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)$',log,re.M)
            products,retained,checks,x,y,scale=map(int,metrics.groups())
            assert scale==denominator
            if is_triangle:
                assert retained==0
            else:
                a,b=literal_eval(hard[i][2])
                assert f'left pair {a} {b} ' in log
            work.append(products+2*retained)
            probes.append(checks)
            assert max(work[-1],probes[-1])<=30_000_000
            sums[0]+=x
            sums[1]+=y
            assert tuple(map(Fraction,re.search(signature,log,re.M).groups()))==tuple(Fraction(v,denominator*16*4**64) for v in (x,y))
        assert end==nrows and tuple(sums)==(raw_re,raw_im)
        output=(author/receipt).read_text()
        assert f'complete shards 8 left rows {end} raw {raw_re} {raw_im} factor denominator {d}' in output
        assert f'maximum shard arithmetic {max(work)} maximum closure probes {max(probes)}' in output
        print('PASS eight full, disjoint author shard intervals and raw sum',i,end,raw_re,raw_im)
    else:
        terminal=author/f'label-{tag}-reduced-frontier.pkl'
        state=check_stage(terminal,sub)
        replay=(root/f'slice-{i}-replay.out').read_text()
        assert f"conditioning {sub['conditioning']} label partition {sub['label_partition']}" in replay
        raw_sig=r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$'
        raw_re,raw_im,d=map(int,re.search(raw_sig,replay,re.M).groups())
    exact=tuple(map(Fraction,re.search(signature,replay,re.M).groups()))
    assert exact==tuple(map(Fraction,re.search(signature,(author/receipt).read_text(),re.M).groups()))==tuple(map(Fraction,(real,imag)))
    assert d==denominator and tuple(Fraction(value,d*16*4**64) for value in (raw_re,raw_im))==exact
    values.append(exact)
    print('PASS independent paired case 33 slice',i,order[i],count,'exact normalized',*exact)
if '--cuts-only' in __import__('sys').argv[1:]:
    print('PASS all nine roster coordinates and signed inverse lifts')
    raise SystemExit(0)
label,*expected=ledger[-1].split('\t')
total=tuple(sum(column,Fraction(0)) for column in zip(*values,strict=True))
assert label=='sum' and total==tuple(map(Fraction,expected))
print('PASS exact paired case 33 sum',*total)
