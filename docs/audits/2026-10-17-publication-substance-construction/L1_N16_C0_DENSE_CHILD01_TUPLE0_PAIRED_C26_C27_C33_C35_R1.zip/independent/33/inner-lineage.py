from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import re
import shutil
import subprocess
import sys
from time import perf_counter

author = Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe33-inner')
parent = author.parent/'row-cap-physical-slice-dense-label-sum33-reduced.pkl'
cwd = Path.cwd()
scripts = ('exact-multicut.py', 'reduce-label-frontier.py', 'contract-reduced-label.py',
           'contract-peer.py', 'peer_pair.py', 'checkpoint/quotient.py')
primary_only = '--primary-only' in sys.argv
cases = [int(arg) for arg in sys.argv[1:] if arg != '--primary-only']
primary_status = {int(i): int(code) for i, code, _ in
                  (line.split('\t', 2) for line in (author/'primary.tsv').read_text().splitlines())}
assert set(primary_status)==set(range(9))
bindings = {str(i): f'slice-{i}-contract.out' for i, code in primary_status.items() if code == 0}
hard = {}
if not primary_only:
    bindings.update({index: stem+'-contract.out' for index,stem in
                    (line.split() for line in (cwd/'seeds.tsv').read_text().splitlines())})
    for line in (author/'terminal-plan.tsv').read_text().splitlines():
        i, pkl, *_ = line.split('\t')
        hard[i] = pkl
        bindings[i] = f'slice-{i}-shard-sum.out'
    assert set(bindings)==set(map(str,range(9)))

def check_file(actual, original):
    assert sha256(actual.read_bytes()).digest() == sha256(original.read_bytes()).digest(), actual

def verify(i):
    scratch = cwd/f'lineage-{i}'
    scratch.mkdir(exist_ok=True)
    (scratch/'checkpoint').mkdir(exist_ok=True)
    for name in scripts:
        if (scratch/name).is_file():
            check_file(scratch/name, author/name)
        else:
            shutil.copyfile(author/name, scratch/name)

    def invoke(program, args, log, exit_code=0, original=None):
        if (scratch/log).is_file():
            statuses=[int(code) for _, name, code, _ in
                      (line.split('\t') for line in (scratch/'stage-timing.tsv').read_text().splitlines())
                      if name == log]
            assert statuses == [exit_code]
            check_file(scratch/log,author/(original or log))
            return
        start = perf_counter()
        with (scratch/log).open('xb') as out:
            p = subprocess.run([sys.executable, '-u', program, *args], cwd=scratch,
                               stdout=out, stderr=subprocess.STDOUT, timeout=180)
        duration = perf_counter() - start
        with (scratch/'stage-timing.tsv').open('a') as out:
            print(i, log, p.returncode, f'{duration:.6f}', sep='\t', file=out)
        assert p.returncode==exit_code,(i,program,args,p.returncode)
        check_file(scratch/log,author/(original or log))

    def checked(name):
        check_file(scratch/name, author/name)

    tag = f'slice-{i}'
    initial = tag + '.pkl'
    invoke('exact-multicut.py',[str(parent),initial,str(i)],tag+'-plan.out')
    checked(initial)
    checked(tag+'.roster')
    stages = []
    while True:
        invoke('reduce-label-frontier.py',[initial,tag],tag+'-reduce.out')
        checked(f'label-{tag}-reduced-frontier.pkl')
        receipt = tag+'-contract.out'
        terminal = receipt == bindings.get(str(i))
        program = 'contract-peer.py' if tag.startswith('rescue') else 'contract-reduced-label.py'
        invoke(program,[tag],receipt,exit_code=0 if terminal else 2)
        stages.append((tag, (scratch/receipt).read_text().splitlines()[-1]))
        if terminal:
            break
        saves = list(scratch.glob(f'*-dense-label-{tag}-reduced.pkl'))
        assert len(saves)==1,(i,tag,saves)
        initial = saves[0].name
        checked(initial)
        if primary_only or initial == hard.get(str(i)):
            break
        tag=f'rescue-{i}-{len(stages)-1}'
    return i, stages

with ThreadPoolExecutor(max_workers=2) as pool:
    for index, stages in pool.map(verify,cases):
        for tag, end in stages:
            print(index, tag, 'byte-identical', end, sep='\t', flush=True)
