#!/usr/bin/env bash
set -euo pipefail
q=$PWD
a=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence
ref=/private/tmp/l1-comp47-independent.rZbJ4i/archive
mkdir -p paired-lineage/checkpoint
for name in reduce-label-frontier.py contract-reduced-label.py checkpoint/quotient.py; do
  cmp "$a/$name" "$ref/$name"
  cp "$ref/$name" "paired-lineage/$name"
done
cd paired-lineage
printf 'stage\tseconds\n' > "$q/pair-lineage-timing.tsv"
timed() {
  local stage=$1
  shift
  local TIMEFORMAT="$stage"$'\t%3R'
  { time "$@"; } 2>> "$q/pair-lineage-timing.tsv"
}
input="$a/combined-27.pkl"
for suffix in ''; do
  tag=sum27$suffix
  timed "reduce-27$suffix" python3 -u reduce-label-frontier.py "$input" "$tag" > "reduce-27$suffix.out"
  ret=0
  timed "contract-27$suffix" python3 -u contract-reduced-label.py "$tag" > "contract-27$suffix.out" || ret=$?
  test "$ret" = 2
  cap="row-cap-physical-slice-dense-label-$tag-reduced.pkl"
  for f in "label-$tag-reduced-frontier.pkl" "$cap" "reduce-27$suffix.out" "contract-27$suffix.out"; do
    cmp "$f" "$a/$f"
  done
  printf 'PASS %s byte-identical reduction, cap, and restart\n' "$tag"
  input=$cap
done
