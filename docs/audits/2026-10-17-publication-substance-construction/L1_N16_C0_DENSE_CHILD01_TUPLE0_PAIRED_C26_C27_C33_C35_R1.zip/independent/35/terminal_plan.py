from ast import literal_eval
from pickle import loads

def plans(base):
    result={}
    for line in (base/'terminal-plan.tsv').read_text().splitlines():
        i,name,program,pair,counts=line.split('\t')
        i=int(i)
        assert i not in result
        pair=literal_eval(pair)
        counts=literal_eval(counts)
        assert program in ('triangle-shards.py','close-four-shards.py')
        triangle=program=='triangle-shards.py'
        path=base/name
        state=loads(path.read_bytes())
        assert len(state['factors'])==(3 if triangle else 4)
        assert (bool(pair),bool(counts))==(not triangle,not triangle)
        result[i]=(path,triangle,pair,counts,state)
    return result
