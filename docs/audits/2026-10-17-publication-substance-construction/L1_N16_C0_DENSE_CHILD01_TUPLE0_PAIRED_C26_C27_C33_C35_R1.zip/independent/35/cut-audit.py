from ast import literal_eval
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

from sys import argv
outer=int(argv[1])
root=Path.cwd()
author=Path(f'/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe{outer}-inner')
denominator=40512224221827380280140849737629696

def census(state,roster):
    axes,entries=literal_eval(roster.read_text())
    assert len(entries)==len(dict(entries))
    f=state['factors']
    assert set(Counter(w for scope,_,_ in f for w in scope).values())=={2}
    left,right=[f[i] for i in state['rejected_pair']]
    shared=sorted(set(left[0])&set(right[0]))
    lmatch=tuple(left[0].index(k) for k in shared)
    rmatch=tuple(right[0].index(k) for k in shared)
    lcut=tuple(left[0].index(k) for k in axes)
    left_count=Counter((tuple(row[p] for p in lmatch),tuple(row[p] for p in lcut)) for row in left[1])
    right_count=Counter(tuple(row[p] for p in rmatch) for row in right[1])
    weights=Counter()
    for (key,cut),n in left_count.items():
        if count:=n*right_count[key]:
            weights[cut]+=count
    assert weights==dict(entries) and sum(weights.values())==state['matched']
    return axes,weights,sorted(weights,key=lambda k:(weights[k],k))

def inverse_lift(state,axes,coordinate,path):
    fixed=dict(zip(axes,coordinate,strict=True))
    raw=path.read_bytes()
    child=pickle.loads(raw)
    assert child['conditioning']==state['conditioning']+list(fixed.items())
    assert child['label_partition']==state['label_partition']
    for (scope,rows,d),(small,cut_rows,e) in zip(state['factors'],child['factors'],strict=True):
        assert d==e and small==tuple(k for k in scope if k not in fixed)
        expected_rows={row:value for row,value in rows.items() if all(row[p]==fixed[k] for p,k in enumerate(scope) if k in fixed)}
        recovered={}
        for row,value in cut_rows.items():
            assignment=dict(zip(small,row,strict=True))
            assignment.update(fixed)
            recovered[tuple(assignment[k] for k in scope)]=value
        assert recovered==expected_rows
    print('PASS exact inverse lift',coordinate,sha256(raw).hexdigest(),sum(len(rows) for _,rows,_ in child['factors']))
    return child

def check_stage(path, child, length=None):
    raw=path.read_bytes()
    state=pickle.loads(raw)
    assert state['conditioning']==child['conditioning'] and state['label_partition']==child['label_partition']
    ff=state['factors']
    if length is not None:
        assert len(ff)==length
    assert set(Counter(w for scope,_,_ in ff for w in scope).values())=={2}
    assert all(d>0 and len(set(scope))==len(scope) and all(len(row)==len(scope) and len(value)==2 and any(value) and all(type(x) is int for x in value) for row,value in rows.items()) for scope,rows,d in ff)
    assert prod(d for _,_,d in ff)==denominator
    print('PASS stage',path.name,sha256(raw).hexdigest(),len(ff),sum(len(rows) for _,rows,_ in ff))
    return state

paired_dir=author.parent
raw_combined=(paired_dir/f'combined-{outer}.pkl').read_bytes()
assert sha256(raw_combined).hexdigest()=='2309172f7f2ca9e397d4e8bd5bbccffa5728db675e2342e1d762e23950c75bb2'
combined=check_stage(paired_dir/f'combined-{outer}.pkl',pickle.loads(raw_combined),7)
assert dict(combined['conditioning'])['R',0,6,1,1,1]==1
assert dict(combined['conditioning'])['G',0,4,2]==36
assert dict(combined['conditioning'])['J',1,4,2]==(2,)
assert combined['binary_sum']=={'summed_index':('R',0,0,2,0,1),'values':(0,1),'coordinate':(36,(2,))}
assert ('R',0,0,2,0,1) not in dict(combined['conditioning'])
check_stage(paired_dir/f'label-sum{outer}-reduced-frontier.pkl',combined,7)
parent=paired_dir/f'row-cap-physical-slice-dense-label-sum{outer}-reduced.pkl'
inner=check_stage(parent,combined,7)
assert sha256(parent.read_bytes()).hexdigest()=='125f26640dc3a0297c1c1a2a75501c7058accf7a80d8ffa4eb4bd1e191e50139'
assert inner['matched']==2001024
print('PASS paired coordinate',(36,(2,)),'and 7-factor restart hash')
axes,weights,order=census(inner,author/'slice-0.roster')
assert axes==(('G',0,1,2),) and len(order)==9 and sum(weights.values())==2001024
print('PASS exhaustive nine-coordinate inner roster',axes,sum(weights.values()),min(weights.values()),max(weights.values()))
if '--cuts-only' in __import__('sys').argv[1:]:
    for i,coordinate in enumerate(order):
        assert (author/f'slice-{i}.roster').read_bytes()==(author/'slice-0.roster').read_bytes()
        child=inverse_lift(inner,axes,coordinate,author/f'slice-{i}.pkl')
        check_stage(author/f'label-slice-{i}-reduced-frontier.pkl',child)
    print('PASS all nine roster coordinates and signed inverse lifts')
    raise SystemExit(0)
