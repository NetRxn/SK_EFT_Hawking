# Independent review of paired outer coordinate 35

The independently verified signed contribution of outer coordinate `(36,(2,))` in group128 descendant `(0,1)`, tuple 0 is `-551838897558848576687769/2596148429267413814265248164610048 + 0i`. The raw Gaussian subtotal is `(-46884393901841666440988394105435327138694343285775237147732738048,0)` over factor denominator `40512224221827380280140849737629696`. The common positive external normalization `1/(16*4^64)` is applied once. This acceptance covers outer coordinate 35.

The named continuity revision matched publication checkpoint `5ce191247e8c364fdc964f37ae4116480c34104b`. The two disjoint binary-selector inputs use the accepted hashes and share six environment factors. The independent census recovers all 48 coordinates and 6,427,904 compatible products per original branch. A condition-first signed constructor indexed the opposite factor and reconstructed every one of the seven combined tables using 177,240 products per branch. Their sum has 128,880 retained pair rows. The original constructor, outer reduction and refusal reproduced byte for byte. The combined input SHA-256 is `2309172f7f2ca9e397d4e8bd5bbccffa5728db675e2342e1d762e23950c75bb2` and the retained cap SHA-256 is `125f26640dc3a0297c1c1a2a75501c7058accf7a80d8ffa4eb4bd1e191e50139`. Independent reconstruction took 2.70 s. Constructor, reduction and refusal readbacks took 2.026, 9.944 and 3.672 s wall respectively.

The inner census recovered nine disjoint coordinates with 2,001,024 compatible products. Every exact inverse lift recovered the original conditioned rows, keys, axes, signed Gaussian coefficients and denominators. The 5 generic terminals were verified with independent sparse Gaussian contraction. Hard slices used a distinct pivot for triangles and a distinct factor pair for four-factor contractions. All 32 author shard receipts passed exact interval coverage, independent candidate-work counts and signed raw arithmetic reconciliation. The signed ledger gives the route, raw value, projected work and observed work per slice.

The 53 generic inner commands across 22 stages reproduced each log and saved checkpoint byte, preserving all 17 refusals. Their summed wall duration was 335.897029 s under concurrent execution. The independent terminal replays used 97,133,424 products and 76.992794 summed wall seconds. The author terminal receipts record 135,008,925 products. Terminal work totals exclude generic work performed before a refusal. The signed ledger and timing tables preserve per-slice measurements.

Verify the portable receipts from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B tools/ledger-metrics.py 35 | cmp - signed-ledger.tsv
python3 -B tools/summarize.py | cmp - summary.out
```

The three operand inventories bind the original binary and text files on the author scratch path. Full recalculation of the binary lineage requires those pinned files. The portable manifest contains the selected receipts, hashes, timings, authority checks and review scripts.
