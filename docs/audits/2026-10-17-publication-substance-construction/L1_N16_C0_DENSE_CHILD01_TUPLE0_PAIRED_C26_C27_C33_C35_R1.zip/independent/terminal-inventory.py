from hashlib import sha256
from pathlib import Path
from pickle import loads
import sys

case=int(sys.argv[1])
roots={26:66,27:68}
td=Path(f'/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe{case}-inner')
checks=[]
print('case','inner_slice','coordinate','terminal_file','terminal_sha256','factors','stored_rows',sep='\t')
for line in (td/f'author-case{case}.tsv').read_text().splitlines()[:-1]:
    i, coordinate, _, _, _, receipt = line.split('\t')
    if 'shard-sum' in receipt:
        filename=f'join-cap-dense-label-rescue-{i}-1-reduced.pkl'
    else:
        filename=f'label-{receipt.removesuffix("-contract.out")}-reduced-frontier.pkl'
    data=(td/filename).read_bytes()
    digest=sha256(data).hexdigest()
    checkpoint=loads(data)
    conditions=dict(checkpoint['conditioning'])
    assert conditions['G',0,4,2]==roots[case] and conditions['J',1,4,2]==(3,)
    assert conditions['G',0,1,2]==int(coordinate)
    asserts=checkpoint['factors']
    print(case,i,coordinate,filename,digest,len(asserts),sum(len(r) for _,r,_ in asserts),sep='\t')
    checks.append(digest)
assert len(set(checks))==9
