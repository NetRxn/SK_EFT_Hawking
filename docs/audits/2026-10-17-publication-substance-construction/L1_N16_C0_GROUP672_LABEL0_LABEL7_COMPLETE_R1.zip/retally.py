from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

def source_roster():
    totals = {}
    expected = None
    for child in (1, 2, 3):
        receipt = Path(f'source/J{child}.out').read_text().strip()
        groups = re.fullmatch(r"(\('J', 1, 1, 2\)) (\[.*\]) (\(\d,\)) (\d+) (\d+)", receipt)
        assert groups is not None, receipt
        _, roster, label, matched, _ = groups.groups()
        roster = dict(literal_eval(roster))
        assert literal_eval(label) == (child,)
        assert int(matched) == roster[(child,)]
        totals[(child,)] = int(matched)
        if expected is None:
            expected = roster
        assert roster == expected
    assert totals == expected and sum(totals.values()) == 734_528
    return totals

def raw_child(child):
    if child == 1:
        body = Path('J1/RETALLY.txt').read_text()
        pattern = r'joint-L 7 J=\(1,\) exact raw numerator (\d+) imaginary (-?\d+) factor denominator (\d+)'
        results = re.findall(pattern, body)
        assert len(results) == 1
    else:
        body = Path(f'J{child}/terminal.out').read_text()
        pattern = r'triangle signed numerator [012] [012] [012] (\d+) (-?\d+) denominator (\d+)'
        results = re.findall(pattern, body)
        assert len(results) == 2 and results[0] == results[1]
    return tuple(map(int, results[0]))

if __name__ == '__main__':
    cohort = source_roster()
    vals = [raw_child(child) for child in (1, 2, 3)]
    denominators = {denominator for _, _, denominator in vals}
    assert len(denominators) == 1
    den = denominators.pop()
    sign_review = Path('source/original-label-review.md').read_text()
    assert str(den) in sign_review and 'sign +1' in sign_review and '1/(16*4^64)' in sign_review
    for (child,), (real, imag, _) in zip(cohort, vals, strict=True):
        print('J', child, 'partition match forecast', cohort[(child,)], 'raw', real, imag)
    real = sum(row[0] for row in vals)
    imag = sum(row[1] for row in vals)
    print('joint-L 7 exact raw', real, imag, 'factor denominator', den)
    print('factor-scope scalar', Fraction(real, den), Fraction(imag, den))
    print('normalized contribution', Fraction(real, den*16*4**64), Fraction(imag, den*16*4**64))

    lines = Path('source/joint-label-roster.tsv').read_text().splitlines()
    axes = literal_eval(lines[0].split('\t')[1])
    records = [line.split('\t') for line in lines[1:]]
    assert len(axes) == 12
    assert [int(record[0]) for record in records] == list(range(8))
    assert len({literal_eval(record[1]) for record in records}) == 8
    assert literal_eval(records[0][1]) != literal_eval(records[7][1])
    pilot = Path('source/L0-prepare.out').read_text().strip()
    assert pilot == f'group672 label selector 0 rows {records[0][2]} census 8'
    l0 = Path('L0/pass3.out').read_text()
    terminal = re.findall(r'exact raw scalar (\(.*\))', l0)
    assert len(terminal) == 1
    x, y = literal_eval(terminal[0])
    last_join = [line for line in l0.splitlines() if line.startswith('exact follow join ')][-1]
    join = literal_eval(last_join.removeprefix('exact follow join ').split(' remaining ')[0])
    assert join[5:8] == (1, 0, den)
    print('joint-L 0 exact raw', x, y, 'factor denominator', den)
    print('normalized contribution', Fraction(x, den*16*4**64), Fraction(y, den*16*4**64))
    print('verified L0 plus L7 subtotal', Fraction(x+real, den*16*4**64), Fraction(y+imag, den*16*4**64))
