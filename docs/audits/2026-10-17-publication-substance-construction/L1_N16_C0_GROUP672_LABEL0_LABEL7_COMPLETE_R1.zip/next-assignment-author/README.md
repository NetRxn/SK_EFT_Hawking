# Assignment 1 author restart and terminal

This separate author-only run selects assignment 1 of the original
group 672 label roster and evaluates its full conditioned cap.
Its scripts, receipts and exact operand hashes are frozen for independent
review. Its proposed value does not enter the accepted subtotal.
