# Original L1 group 672 joint label assignments 0 and 7

The original source partitions this group into eight disjoint joint-L
assignments. This record covers original assignments 0 and 7 in full.
Amplitudes from assignments 1 through 6 are still owed. Scope, exact
factor denominators and original occupation prefactor come from the
existing group 672 original-label route. The packed source receipts
retain the complete label roster and disjoint three-child roster of
assignment 7 from that checkpoint.

From a clean extraction, check the nested reviews, all member checksums,
and the normalized retally.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B retally.py | cmp - RETALLY.txt
```

The complete J=(1,) archive is a prerequisite and its exact retally is
included here. J=(2,), J=(3,), and joint-L assignment 0 were contracted
on their own original caps. The author scripts and independent
arithmetical replays are frozen with their checksums. Large factor tables
are pinned by hashes for reconstruction from the earlier original-label
evidence. Equal child values are separate exact outcomes.

The normalization is that of the original finite-model coefficient.
The physical metric/source construction and publication gates are
separate open obligations.
