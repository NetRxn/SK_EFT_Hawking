# L1 outer case 35 independent exact replay

All nine independently replayed results match their author ledger values. The exact subtotal is **-309249011481254844095997 / 2596148429267413814265248164610048 + 0i**.

The seven-factor parent hash is pinned in L1_N16_C0_CASES29_31_CLOSURE_R1 at checkpoint 54d0b4b21e8539db29cc2be5c7858cf025eb7ffc. The original 48-case roster assigns coordinate (24,(2,)) to index 35. Independent support matching on pair (0,4) recovers the nine possible values of G(0,1,2), with 2,001,024 total selected pair matches and maximum 435,456 per cut. Every nonzero network term requires a match on that pair. The inverse lifts cover all nine conditioned children, preserving exact coefficients, conditioning and denominators.

Slices 0, 1, 4, 5 and 6 replay from their ledger-selected frozen inputs using an independent Gaussian-integer sparse join routine within the 8M per join, 30M total and 1M accumulator-row caps. Slices 2 and 3 use pivot 1 instead of author pivot 0, summing the complementary inner product before multiplying by the pivot term. Each takes 18,643,968 probes and 18,752,832 Gaussian multiplications. Both exact raw numerators and normalized results match.

Slices 7 and 8 independently replay from their distinct saved frontiers with selected pair (1,2), compared with author pair (1,3). The independent reduction groups exact selected-pair products by outgoing boundary and computes a complementary dot product for each retained term. Each uses 7,892,640 selected pair matches and 23,812,992 Gaussian products in 15 disjoint bounded shards, at most 1,979,632 multiplications, 1,358,344 probes and 24,984 accumulated entries per shard. Earlier author join/row-cap receipts are preserved. The four author shard stacks were also checked for disjoint full row intervals against the actual pivot factor and for exact raw and normalized sums.

Each replay applies the common factor denominator and positive scale 1/(16*4^64) once. Earlier reductions to saved terminal frontiers rely on frozen lineage and previously reviewed exact algebra. This evidence accepts case 35 of one binary child of dense tuple 0. The full signed coefficient remains open.
