# Independent verification of L1 N16 outer case 38

The review pins publication checkpoint 54d0b4b21 and the seven-factor
parent identified in next-frontiers/inputs.sha256 within
L1_N16_C0_CASES29_31_CLOSURE_R1.zip. The archive manifest verified.
The checked parent SHA256 is
c86bdf17b1105dfb85f6812bb91ea8d457bd0971bdd8284986c2867469f66e1b.
The archived outer roster maps case 38 to (136, (1,)) on G(0,4,2) and
J(1,4,2), in the first binary child of tuple 0, descendant (0,0),
branch 128.

An independent histogram match on the rejected parent pair (0, 4)
regenerated the complete nine-value cut on G(0,1,2). The disjoint values
cover 2,001,024 matched pair products. Every nonzero complete network
summand must match that pair. Exact inverse lifts recover every compatible
parent row and Gaussian coefficient and preserve each factor denominator.
All terminal inputs retained complete conditioning and the label partition,
degree-two open axes and the positive denominator product.

| Slice | Cut value | Matched parent pair products | Independent normalized real |
|---|---:|---:|---:|
| 0 | 3 | 44,928 | -7579449762635066717835/2596148429267413814265248164610048 |
| 1 | 48 | 62,208 | -2639017884707118117/20282409603651670423947251286016 |
| 2 | 5 | 169,344 | -8052931203918957247185/649037107316853453566312041152512 |
| 3 | 12 | 169,344 | -9807872755256288789265/324518553658426726783156020576256 |
| 4 | 96 | 217,728 | -4844774857002515229609/649037107316853453566312041152512 |
| 5 | 144 | 217,728 | -4844774857002515229609/649037107316853453566312041152512 |
| 6 | 192 | 248,832 | 16698483434738761677/40564819207303340847894502572032 |
| 7 | 80 | 435,456 | -4753411275679919026065/1298074214633706907132624082305024 |
| 8 | 160 | 435,456 | -4753411275679919026065/1298074214633706907132624082305024 |

All imaginary parts are zero. The exact independent sum is
**-175295091928520234333475/2596148429267413814265248164610048 + 0i**.
The sum equals the separately verified case 34 result. The parent and each conditioned input retain distinct SHA256 identities.

Five direct sparse terminal replays passed. The two triangles in
slices 2 and 3 independently used pivot 1 in place of the author's
pivot 0. Each covers 18,643,968 matching triples and uses 18,752,832
Gaussian products, with at most 2,015,035 products in any shard.
The four-factor replays in slices 7 and 8 use initial pair (1,2),
with 6,138,720 candidate products, followed by closure on (0,3).
Each uses 23,692,032 Gaussian products across 11 shards, with at most
2,673,792 products per shard and 24,984 entries per block. The author
used initial pair (1,3). Both alternate orders agree with the author
raw numerators and normalized fractions. All independent arithmetic
uses the same factor denominator product
40512224221827380280140849737629696 and external normalization
1/(16*4^64), each applied once.

The author shard audit independently checked 32 successful receipts.
Each of the four sharded slices has eight disjoint author intervals
covering its complete pivot or left factor, and summed raw numerators
agree with the author summary and the full independent contraction.
The 17 generic cap refusals are bound to distinct frozen restart
states, including the later alternate capped attempts for slices 7
and 8. Intermediate lineage uses archived state and receipt checks
and byte identity of the common author scripts with the fully replayed
case 18 code. The new independent arithmetic qualifies case 38 and
its exact nine-term sum.
