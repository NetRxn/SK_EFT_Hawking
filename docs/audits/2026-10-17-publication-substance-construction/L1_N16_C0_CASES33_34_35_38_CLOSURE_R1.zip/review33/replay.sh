#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 audit.py > audit-archive.out
a=/private/tmp/l1-c0-case33.LzpgWn
tab=$(printf '\t')
while IFS="$tab" read -r index coord products real imag receipt; do
    if test "$index" = sum; then break; fi
    case "$index" in
      2|3) python3 -u triangle.py "$index" > "slice-$index-replay.out" ;;
      7|8) python3 -u four.py 33 "$index" --pair 1 2 > "slice-$index-replay.out" ;;
      *)
        stem=${receipt%-contract.out}
        python3 -u replay.py "$index" 0 "$a/label-$stem-reduced-frontier.pkl" "$a/$receipt" > "slice-$index-replay.out"
        ;;
    esac
done < "$a/author-case33.tsv"
python3 aggregate.py > aggregate.out
