# L1 N16 exact outer cases 33, 34, 35 and 38

Scientific source 51e7c745e and publication parent 54d0b4b21. These are distinct outer terms in the first binary child of tuple 0, descendant (0,0). Restore the seven-factor files `row-cap-physical-slice-dense-label-case-33-2-reduced.pkl` and `row-cap-physical-slice-dense-label-case-34-2-reduced.pkl` from `L1_N16_C0_CASES29_31_CLOSURE_R1.zip` via its `next-frontiers` instructions. Their SHA256s are `6aef5e61cf001e63726ea4520e06cdc78ad4e2d9e79a89b63eca8b8c0fc93d00` and `de99a688ad68f3ef21138b958ab310fb50ffe0e12b734a6e7a0871507571d6ff`. Deserialize only trusted checkpoint inputs.

In fresh scratch containing the respective author folder contents, run:

```bash
python3 -u run-primary.py /absolute/path/to/restored-parent.pkl >slices.tsv
python3 -u reduce-open.py 0 1 2 3 4 5 6 7 8 >rescue.tsv
shasum -a 256 -c /absolute/path/to/archive/frontiersN.sha256
python3 -u run-final-shards.py >final-shards.tsv
python3 sum-caseN.py
```

Replace N with the case number. For cases 35 and 38 the restored parent paths follow the same naming, with SHA256 8d9b2da04595729957525e01a43353ded3b1b6b4d969272c7e9f0b5d05d4a861 and c86bdf17b1105dfb85f6812bb91ea8d457bd0971bdd8284986c2867469f66e1b respectively. The two triangle closures use eight disjoint pivot-row intervals each. The four-factor closures use eight disjoint selected-pair intervals each. The terminal receipts and combined raw Gaussian sums are included. Read the independent reports for exact cut and terminal input bindings, and restore only named upstream duplicate ZIPs by their verified hashes when reproducing the review manifests. The cumulative retally reads the previous 36-case ledger without changing the prior values.

```bash
python3 verify-cases.py 33 34 35 38
python3 retally-48.py 33 34 35 38
```

The full child, signed coefficient and publication acceptance remain open.
