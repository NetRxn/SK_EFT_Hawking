from collections import Counter
from itertools import combinations, product
from math import comb
import json
from pathlib import Path

d=json.loads(Path('/tmp/publication-task4-split-support-r1.json').read_text())
N=16
totals=Counter()
for n2 in range(N+1):
    for n1 in range(N-n2+1):
        n0=N-n2-n1
        q=n1+2*n2
        p=32-2*q
        if p<0: continue
        m=n0+n1
        if m==0:
            count=int(p==0)
        else:
            count=sum((-1)**(i+j)*comb(n0,i)*comb(n1,j)*comb(p-5*i-3*j+m-1,m-1)
                      for i in range(n0+1) for j in range(n1+1) if p>=5*i+3*j)
        totals[q,p]+=comb(N,n2)*comb(N-n2,n1)*count
assert [[q,p,c] for (q,p),c in sorted(totals.items())]==d['unpruned_top_degree_slots']
assert sum(totals.values())==35_223_243_542_158
print('Independent multinomial and inclusion–exclusion matched all 17 slots and total')

sites=list(product(range(2),repeat=4))
axis=range(4)
def flip(x,j): return x[:j]+(1-x[j],)+x[j+1:]
scopes={x:({x,*[flip(x,j) for j in axis]},
           {(x,j) for j in axis}|{(flip(x,j),k) for j,k in product(axis,repeat=2)})
        for x in sites}
def union(seq,which): return set().union(*(scopes[x][which] for x in seq))
for name,rows in d['center_order_scopes'].items():
    processed=set()
    for row in rows:
        x=tuple(row['site'])
        def cut(c):
            done=processed|{c}
            pending=set(sites)-done
            f,q=(len(union(done,j)&union(pending,j)) for j in (0,1))
            return f,q,8*f+64*q
        if name=='greedy':
            assert x==min(set(sites)-processed,key=lambda c:(cut(c)[2],c))
        else:
            assert x==min(set(sites)-processed)
        assert cut(x)==(row['open_fermion_sites'],row['open_anchors'],row['ordering_score'])
        processed.add(x)
    assert processed==set(sites)
print('Independent four-bit scopes matched both schedules, their tie-breaking and all cuts')
# Supplement: exact minimax of the unsourced center-cut metric. No field keys
# or coupling assignments are generated; the subsets are just center schedules.
masks=[sum(1<<sites.index(x) for x in sites if y in scopes[x][0]) for y in sites]
assert all({x for x in sites if y in scopes[x][0]}=={x for x in sites if (y,k) in scopes[x][1]}
           for y in sites for k in axis)
size=1<<N
cuts=[sum(bool(mask&s) and (mask&s)!=mask for mask in masks) for s in range(size)]
best=[0]*size
prev=[0]*size
for s in range(1,size):
    remaining=s
    value=17
    while remaining:
        b=remaining&-remaining
        cost=max(cuts[s],best[s^b])
        if cost<value: value,prev[s]=cost,b
        remaining^=b
    best[s]=value
order=[]
s=size-1
while s:
    b=prev[s]
    order.append(sites[b.bit_length()-1])
    s^=b
print('Exact unsourced 2^16 center-schedule structural minimax:',best[-1],'sites,',
      4*best[-1],'anchors,',264*best[-1],'score')
print('One minimax order:',','.join(''.join(map(str,x)) for x in reversed(order)))
