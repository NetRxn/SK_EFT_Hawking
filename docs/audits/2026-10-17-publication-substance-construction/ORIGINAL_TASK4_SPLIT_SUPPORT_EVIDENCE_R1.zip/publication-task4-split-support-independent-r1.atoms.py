from itertools import product
from fractions import Fraction
from collections import Counter

from src.core import formulas as f
from src.vestigial import original_coefficients as o

reg=o.OriginalRegulator()
gens=reg.generator_order
def flip(x,i): return x[:i]+(1-x[i],)+x[i+1:]

def read_atom(x,mu,a):
    y=flip(x,mu)
    blocks=f.original_coframe_blocks(reg,(x,mu,a))
    assert tuple((b.anchor,b.bar_site,b.psi_site,b.weight) for b in blocks)==(
        ((x,mu),x,y,Fraction(1,4)), ((x,mu),y,x,Fraction(-1,4)),
        ((y,mu),x,y,Fraction(-1,4)), ((y,mu),y,x,Fraction(1,4)),
    )
    terms={}
    for mask,poly in o.assemble_coframe(reg,blocks).to_exterior(reg).terms:
        fields=[gens[i] for i in range(len(gens)) if mask>>i&1]
        assert len(fields)==2 and {v[0] for v in fields}=={x,y}
        assert {v[1] for v in fields}=={'bar','psi'}
        assert {v[2]//2 for v in fields}=={0,1}
        for key,c in poly.terms:
            sym,=key
            assert sym.family=='q' and not sym.conjugated
            assert sym.index[:2] in ((x,mu),(y,mu))
            assert sym.index[2] in ('L','R') and 0<=sym.index[3]<4
            assert (mask,sym.index) not in terms and c
            terms[mask,sym.index]=c
    assert len(terms)==64
    return terms

n=0
for x,mu,a in product(reg.sites,range(4),range(4)):
    read_atom(x,mu,a)
    n+=1
print(n,'source-exact coframe atoms checked for both based anchors, signed quarter, exterior and quaternion support')

x=reg.sites[0]
y=flip(x,0)
left=read_atom(x,0,0)
for name,right in [('opposite',read_atom(y,0,0)),('same',left)]:
    structural=set()
    full=Counter()
    for (m1,i),a in left.items():
        for (m2,j),b in right.items():
            if not m1&m2:
                exterior=m1|m2
                structural.add((exterior,tuple(sorted((i,j)))))
                if i==j:
                    parity=(sum((m2 & ((1<<k)-1)).bit_count() for k in range(128) if m1>>k&1))%2
                    full[exterior]+=((-1)**parity)*a*b*Fraction(1,4)
    kept={mask for mask,(i,j) in structural if i==j}
    nonzero={mask for mask,value in full.items() if value}
    assert nonzero<=kept and nonzero
    assert (len(structural),len(kept))=={'opposite':(2560,32),'same':(1520,20)}[name]
    print(name, 'exact Boolean keys',len(structural),'closed Boolean masks',len(kept),'nonzero signed masks',len(nonzero))
