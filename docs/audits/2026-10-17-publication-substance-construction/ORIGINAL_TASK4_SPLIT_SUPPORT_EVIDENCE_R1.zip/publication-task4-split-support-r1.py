"""Bounded Task4 structural probe. No full coefficient or frontier run."""
from collections import Counter
from itertools import permutations
from math import comb
import json
from src.core import formulas as f
from src.vestigial import original_coefficients as o

ALTS = tuple((q,p) for q in range(3) for p in range(5-2*q))
N = 16
W = 32
CAP = 200_000

def population():
    counts = {(0,0):1}
    for _ in range(N):
        nxt = Counter()
        for (q,p),count in counts.items():
            for dq,dp in ALTS:
                if 2*(q+dq)+p+dp <= W:
                    nxt[q+dq,p+dp] += count
        counts = nxt
    slots = [(q,p,counts[q,p]) for q,p in sorted(counts) if 2*q+p==W]
    assert len(slots)==17 and sum(n for _,_,n in slots)==35_223_243_542_158
    return slots

def qkey(key):
    out=Counter()
    for symbol in key:
        site,axis,chirality,coordinate=symbol.index
        assert symbol.family=="q" and not symbol.conjugated
        out[site,axis,chirality,coordinate]+=1
    return tuple(sorted(out.items()))

def join_qkeys(a,b):
    merged=Counter(dict(a))
    merged.update(dict(b))
    return tuple(sorted(merged.items()))

def coframe_support(reg,alpha):
    blocks=f.original_coframe_blocks(reg,alpha)
    expected={(alpha[0],alpha[1]), (reg.step(alpha[0],alpha[1],-1)[0],alpha[1])}
    assert {block.anchor for block in blocks}==expected
    exterior=o.assemble_coframe(reg,blocks).to_exterior(reg)
    mask_at_center=255<<(8*reg.site_number(alpha[0]))
    support=set()
    for mask,polynomial in exterior.terms:
        assert mask.bit_count()==2 and (mask&mask_at_center).bit_count()==1
        for key,_ in polynomial.terms:
            converted=qkey(key)
            assert len(converted)==1 and converted[0][1]==1
            assert converted[0][0][:2] in expected
            support.add((mask,converted))
    return support

def boolean_join(left,right):
    assert len(left)*len(right)<=CAP
    return {(a|b,join_qkeys(i,j)) for a,i in left for b,j in right if not a&b}

def signature(support,closed_anchors):
    # Zero sphere moments are pruned only at last occurrence. Equal keys
    # combine by Boolean union here, never by signed arithmetic.
    reduced=set()
    parity_rejected=0
    for mask,key in support:
        if any(count%2 for index,count in key if index[:2] in closed_anchors):
            parity_rejected+=1
            continue
        reduced.add((mask,tuple(item for item in key if item[0][:2] not in closed_anchors)))
    return len(reduced),parity_rejected

def incidence(reg):
    # Closed raw ordered curvature occurrence keeps the actual original
    # product order, including both dagger flags. Union is for scope only.
    table=[]
    for x in reg.sites:
        hop={}
        for mu in range(4):
            neigh=reg.step(x,mu)[0]
            opposite=reg.step(x,mu,-1)[0]
            assert neigh==opposite and x!=neigh
            hop[mu] = {(x,mu),(opposite,mu)}
        planes={}
        for k,l in permutations(range(4),2):
            a=(x,k)
            b=(reg.step(x,k)[0],l)
            c=(reg.step(x,l)[0],k)
            d=(x,l)
            ordered=((d,True),(c,True),(b,False),(a,False))
            support={anchor for anchor,_ in ordered}
            mu,nu=sorted(set(range(4))-{k,l})
            assert len(support)==4 and not (support&hop[mu] or support&hop[nu])
            assert len(support|hop[mu]|hop[nu])==8
            planes[k,l]=(ordered,(mu,nu))
        union=set().union(*hop.values(),*(set(a for a,_ in ordered) for ordered,_ in planes.values()))
        assert len(union)==20
        table.append((x,len(hop),len(planes),len(union)))
    return table

def weighted_center_order(reg):
    scopes={}
    for x in reg.sites:
        fermions={x,*[reg.step(x,mu)[0] for mu in range(4)]}
        links={(x,mu) for mu in range(4)}
        links.update((reg.step(x,mu,-1)[0],mu) for mu in range(4))
        links.update((reg.step(x,k)[0],l) for k,l in permutations(range(4),2))
        assert len(fermions)==5 and len(links)==20
        scopes[x]={("f",site) for site in fermions}|{("q",anchor) for anchor in links}

    def weight(resources):
        # 8-bit site mask, 8 per exponent for both chiral 4-tuples.
        # Purely a deterministic ordering score, not measured memory.
        return sum(8 if typ=="f" else 64 for typ,_ in resources)

    def schedule(greedy):
        pending=set(reg.sites)
        used=set()
        rows=[]
        while pending:
            def cut(x):
                rest=set().union(*(scopes[y] for y in pending-{x}))
                return (used|scopes[x])&rest
            chosen=min(pending,key=lambda x:(weight(cut(x)),x)) if greedy else min(pending)
            live=cut(chosen)
            rows.append({"site":chosen,"open_fermion_sites":sum(typ=="f" for typ,_ in live),
                        "open_anchors":sum(typ=="q" for typ,_ in live),"ordering_score":weight(live)})
            used.update(scopes[chosen])
            pending.remove(chosen)
        assert rows[-1]["ordering_score"]==0
        return rows
    return {"greedy":schedule(True),"lexicographic":schedule(False)}

def probe():
    reg=o.OriginalRegulator()
    x=reg.sites[0]
    table=incidence(reg)
    all_atoms={alpha:coframe_support(reg,alpha) for mu in range(4) for a in range(4)
               for alpha in [(x,mu,a)]}
    assert {len(v) for v in all_atoms.values()}=={64}
    # A real, complete component-pair frontier on one temporal/spatial
    # edge. The second pair is at the opposite endpoint. Closing the
    # two anchors early would incorrectly remove odd history that a
    # later coframe may make even.
    axis=0
    y=reg.step(x,axis)[0]
    left=all_atoms[x,axis,0]
    right=coframe_support(reg,(y,axis,0))
    both=boolean_join(left,right)
    anchors={(x,axis),(y,axis)}
    final,rejected=signature(both,anchors)
    assert len(both)>0 and 0<final<len(both)
    temporal_same=boolean_join(left,left)
    same_final,same_reject=signature(temporal_same,anchors)
    # Original ordered S2 branch has four distinct curvature anchors
    # (one fundamental entry apiece) disjoint from both coframe axes.
    # Probe the local Clifford/plaquette polynomial's actual nonzero
    # quaternion keys and carry them as a live factor without making
    # the join or prematurely integrating anything.
    k,l,mu,nu=2,3,0,1
    a,b=0,1
    anchors4=((x,k),(reg.step(x,k)[0],l),(reg.step(x,l)[0],k),(x,l))
    def link(anchor):
        site,direction=anchor
        return f.original_spin4_link(*(tuple(o.Polynomial.variable(o.Symbol(
            'q',(site,direction,chi,i))) for i in range(4)) for chi in ('L','R')))
    ordered_action=f.original_action_factors(reg,x,{anchor:link(anchor) for anchor in reg.link_order})
    raw_counts=Counter(term.t_degree for term in ordered_action)
    assert raw_counts=={4:24,2:384}
    grouped={}
    for term in ordered_action:
        if term.t_degree==2:
            key=tuple(sorted(term.components))
            grouped[key]=grouped.get(key,o.Polynomial())+term.coefficient
    assert len(grouped)==96
    assert all(bool(value)==(comps[0][2]!=comps[1][2]) for comps,value in grouped.items())
    gamma=reg.gamma
    products={(a,b):o.matrix_multiply(o.matrix_multiply(gamma[a],gamma[b]),reg.gamma5)
              for a in range(4) for b in range(4)}
    planes={}
    for (alpha,beta),value in grouped.items():
        _,d,a0=alpha
        _,e,b0=beta
        if (d,e) not in planes:
            k0,l0=sorted(set(range(4))-{d,e})
            plaquette_anchors=((x,k0),(reg.step(x,k0)[0],l0),(reg.step(x,l0)[0],k0),(x,l0))
            held={anchor:link(anchor) for anchor in plaquette_anchors}
            h=f.original_plaquette(reg,x,k0,l0,held)
            assert f.original_plaquette(reg,x,l0,k0,held)==o.matrix_dagger(h)
            planes[d,e]=(h,o.epsilon((k0,l0,d,e)))
        h,orientation=planes[d,e]
        c=products[a0,b0]
        simplified=sum((h[i][j]*c[j][i] for i in range(4) for j in range(4)),
                       o.Polynomial())*orientation if a0!=b0 else o.Polynomial()
        assert simplified==value
    u=f.original_plaquette(reg,x,k,l,{anchor:link(anchor) for anchor in anchors4})
    gamma=reg.gamma
    g=o.matrix_multiply(o.matrix_multiply(gamma[a],gamma[b]),reg.gamma5)
    trace=sum((u[i][j]*g[j][i] for i in range(4) for j in range(4)),o.Polynomial())
    terms={qkey(key) for key,_ in trace.terms}
    assert terms
    assert all({idx[:2] for idx,_ in key}==set(anchors4) and
               len({idx[2] for idx,_ in key})==1 and
               all(n==1 for _,n in key) for key in terms)
    cof=boolean_join(all_atoms[x,mu,a],all_atoms[x,nu,b])
    assert all(set(idx[:2] for idx,_ in key).isdisjoint(anchors4) for _,key in cof)
    # Disjoint anchor sets make this product bijective; count it without
    # allocating the Cartesian frontier. Materialize only a deterministic slice.
    live_s2=len(cof)*len(terms)
    sample=boolean_join(set(sorted(cof)[:16]),{(0,k) for k in terms})
    assert len(sample)==16*len(terms)
    closed,rejected_s2=signature(sample,set(anchors4))
    assert closed==0 and rejected_s2==len(sample)
    return {
        "carrier":reg.extents,"word":reg.word,"anchor_count":len(reg.link_order),
        "all_center_incidence_counts":table,"center_order_scopes":weighted_center_order(reg),
        "local_alternatives":ALTS,
        "local_unordered_vertex_multiset_counts_before_exterior_pruning":[
            {"q":q,"p":p,"center_T_degree":4*q+2*p,
             "raw_24_by_384":comb(24+q-1,q)*comb(384+p-1,p),
             "grouped_24_by_72":comb(24+q-1,q)*comb(72+p-1,p)}
            for q,p in ALTS],
        "all_center_assignments":len(ALTS)**N,
        "unpruned_top_degree_slots":population(),"unpruned_top_degree_total":35_223_243_542_158,
        "coframe_atom_support_counts":sorted({len(v) for v in all_atoms.values()}),
        "exact_one_center_action_grouping":{"ordered_s4":raw_counts[4],"ordered_s2":raw_counts[2],
            "canonical_s2_before_trace_cancellation":len(grouped),
            "canonical_nonzero_s2_after_trace_cancellation":sum(bool(value) for value in grouped.values()),
            "direct_group_vs_antisymmetrized_trace_agree":True},
        "opposite_endpoint_pair":{"input_pair_visits":len(left)*len(right),"after_exterior_union":len(both),
             "last_use_parity_rejects":rejected,"after_both_anchor_forgets":final},
        "same_endpoint_pair":{"after_exterior_union":len(temporal_same),
             "last_use_parity_rejects":same_reject,"after_both_anchor_forgets":same_final},
        "selected_original_s2_ordered_branch":{"world_order":(k,l,mu,nu),"components":(a,b),
             "exact_trace_monomial_support":len(terms),"coframe_pair_support":len(cof),
             "live_full_branch_support_from_disjoint_keys":live_s2,"materialized_sample":len(sample),"sample_closure_only_parity_rejects":rejected_s2,
             "isolated_terminal_count":closed},
        "join_cap":CAP,"scope":"bounded local support and exact degree-population DP only"
    }

if __name__=="__main__":
    print(json.dumps(probe(),indent=2))
