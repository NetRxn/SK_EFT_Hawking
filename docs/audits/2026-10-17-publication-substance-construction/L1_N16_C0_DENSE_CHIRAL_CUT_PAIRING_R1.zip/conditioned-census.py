"""Count the exact signed table support retained by each joint label."""
from collections import Counter
from itertools import product
from pathlib import Path
import pickle
import sys

for directory in map(Path, sys.argv[1:]):
    with (directory / "dense-saturated-frontier.pkl").open("rb") as stream:
        source = pickle.load(stream)
    factors = source["factors"]
    labels = tuple(sorted({axis for axes, _, _ in factors for axis in axes if axis[0] == "L"}))
    columns = [tuple((i, labels.index(axis)) for i, axis in enumerate(axes) if axis[0] == "L")
               for axes, _, _ in factors]
    counts = [Counter(tuple(row[i] for i, _ in indices) for row in table)
              for indices, (_, table, _) in zip(columns, factors, strict=True)]
    domains = [set() for _ in labels]
    for indices, tally in zip(columns, counts, strict=True):
        for row in tally:
            for value, (_, axis) in zip(row, indices, strict=True):
                domains[axis].add(value)
    records = []
    for values in product(*(sorted(domain) for domain in domains)):
        sizes = [tally[tuple(values[i] for _, i in indices)]
                 for indices, tally in zip(columns, counts, strict=True)]
        if all(sizes):
            records.append((values, sum(sizes), max(sizes)))
    assert len(factors) == 88 and len(labels) == 12
    print("group", source["branch"], "factors", len(factors), "labels", len(labels),
          "planned assignments", source["support"], "consistent after sweeps", len(records),
          "unconditioned rows", sum(len(rows) for _, rows, _ in factors), flush=True)
    print("axes", repr(labels), sep="\t", flush=True)
    for index, record in enumerate(records):
        print(index, *record, sep="\t", flush=True)
