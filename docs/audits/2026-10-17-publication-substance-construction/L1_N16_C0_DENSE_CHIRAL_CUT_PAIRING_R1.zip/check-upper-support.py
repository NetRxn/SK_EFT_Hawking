"""Compare frozen maximum-input support counts under ordered chirality exchange."""
from ast import literal_eval
from pathlib import Path

def report(group):
    summary, axes, *entries = Path(f"{group}-condition.out").read_text().splitlines()
    labels = literal_eval(axes.split("\t")[1])
    roster = {}
    for index, values, total, largest in (entry.split("\t") for entry in entries):
        key = literal_eval(values)
        assert int(index) == len(roster) and key not in roster
        roster[key] = int(total), int(largest)
    assert len(roster) == 8 and len(labels) == 12
    return summary, labels, roster

for a, b in ((934, 2937), (1673, 2198)):
    first, left_axes, left = report(a)
    second, right_axes, right = report(b)
    assert left_axes == right_axes
    changed = {tuple((q, p) for p, q in values): sizes for values, sizes in left.items()}
    assert changed == right
    print(first)
    print(second)
    print(a, b, len(left), "exact support-count matches by ordered chiral exchange")
