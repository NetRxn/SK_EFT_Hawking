"""Replay the cut partition under the independently accepted chiral exchange."""
from ast import literal_eval
from fractions import Fraction
from hashlib import file_digest
from math import lcm, prod
from pathlib import Path
import sys
from zipfile import ZipFile

archives = Path(sys.argv[1])
def archive(kind, expected):
    path = archives / f"L1_N16_C0_{kind}_R1.zip"
    with path.open("rb") as stream:
        assert file_digest(stream, "sha256").hexdigest() == expected, path
    return ZipFile(path)

def read(bundle, member):
    return bundle.read(member).decode().splitlines()

def flip(labels):
    return tuple((right, left) for left, right in labels)

def exchanged_family(name):
    if name.startswith("T"):
        return name[:-1] + str(1 - int(name[-1]))
    return name

with archive("DENSE_FACTOR_INPUTS_INDEPENDENT", "a9088fd54fbdb92c2a74fc7331f9793c950ba790cd5d89a8143f32af5fc93983") as checked:
    assert "15,488 two-member orbits" in checked.read("independent/REVIEW.md").decode()
with archive("DENSE_REUSE_PILOT", "c078c4fc4efc7ca903e17db526209e20a5692c260f202d837eac586a5a420416") as checked:
    plan = [line.split("\t") for line in read(checked, "census/cut-plan.tsv")]
    blocks = [line.split("\t") for line in read(checked, "census/block-index.tsv")]
    axes = literal_eval(checked.read("census/cut-axes.tsv").decode())

assert len(axes) == len(set(axes)) == 16
assert len(plan) == 3872 and len(blocks) == 2456
labels = [literal_eval(row[4]) for row in plan]
assert len(labels) == len(set(labels))
label_to_group = {key: group for group, key in enumerate(labels)}
block_fields = [(name, literal_eval(key)) for name, key, *_ in blocks]
assert len(block_fields) == len(set(block_fields))
block_by_field = {field: i for i, field in enumerate(block_fields)}
block_image = [block_by_field[exchanged_family(name), flip(key)] for name, key in block_fields]
assert all(block_image[j] == i for i, j in enumerate(block_image))
for i, j in enumerate(block_image):
    assert blocks[i][4:6] == blocks[j][4:6]

partner = [label_to_group[flip(key)] for key in labels]
assert all(j != i and partner[j] == i for i, j in enumerate(partner))
pairs = [(i, j) for i, j in enumerate(partner) if i < j]
assert len(pairs) * 2 == len(plan)
print("representative\tpartner\tassignments_each\tloaded_rows_each\tpreparation_denominator")
for i, j in pairs:
    one, other = plan[i], plan[j]
    assert (int(one[0]), int(other[0])) == (i, j)
    assert one[1:3] == other[1:3] and int(one[1]) == 8
    left_indices = literal_eval(one[5])
    right_indices = literal_eval(other[5])
    assert sorted(block_image[k] for k in left_indices) == sorted(right_indices)
    denominators = {}
    for k in left_indices:
        name = blocks[k][0]
        denominators[name] = lcm(denominators.get(name, 1), int(blocks[k][5]))
    assert len(denominators) == 88
    print(i, j, one[1], one[2], prod(denominators.values()), sep="\t")

receipts = (
    (128, "9000d548ccd03c538315e7c84d0ab79a468595aeb6a3110ff549fc7f032576e2", "verified-group128.tsv", "group128"),
    (672, "8a93fb0149c6f918542338f5550be24581c875b761977d6dae350b50adc71f7a", "RETALLY.txt", "normalized signed total"),
    (934, "8ec12dd30a63e16113cc022f4375e6b151db62142ca340c73bb53b5f1793531e", "AUTHOR_RETALLY.txt", "exact normalized"),
)
print("direct\tpaired\texact normalized real of each\timaginary")
accepted = set()
subtotal = Fraction(0)
for group, digest, member, tag in receipts:
    with archive(f"DENSE_GROUP{group}_COMPLETE", digest) as checked:
        line, = (line for line in read(checked, member)
                 if line.startswith((tag + "\t", tag + " ")))
    real, imaginary = line[len(tag):].split()
    assert Fraction(imaginary) == 0
    other = partner[group]
    assert {group, other}.isdisjoint(accepted)
    accepted.update((group, other))
    subtotal += 2 * Fraction(real)
    print(group, other, real, imaginary, sep="\t")

print("paired signed normalized subtotal before outer orbit weight", subtotal, 0)
print("paired signed normalized subtotal including outer orbit weight 48", 48 * subtotal, 0)
print("groups covered", len(accepted), "groups remaining", len(plan) - len(accepted))
print("unevaluated representative groups", len(pairs) - len(receipts))
