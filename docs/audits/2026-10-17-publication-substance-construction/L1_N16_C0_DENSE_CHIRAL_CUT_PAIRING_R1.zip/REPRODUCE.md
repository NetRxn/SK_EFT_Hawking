# Original dense profile cut symmetry and measured upper-stratum controls

The source is the original `N=16` EHC profile with occupation codes
`(503841882182, 1461451755920)`. The independently accepted dense factor
input archive already proves equal signed contributions for the 15,488
global gamma3 pairs in the 30,976 original representation assignments.
This checkpoint composes that result with the fixed numerical cut and
uses the three existing complete representative receipts.

Let `P_K` restrict a full representation assignment to the fixed
ordered 16 cut axes. The gamma3 involution `sigma` exchanges each
ordered `(p,q)` pair while keeping the physical position and world
indices. Thus `P_K(sigma r) = sigma(P_K(r))`. Changing variables in
the sum over a cut fiber maps it bijectively to the partner fiber with
the same original signed value. The original source check includes the
normalized product Haar factors, exterior top signs and the degree-32
EHC sign. The occupation prefactor `1/(16*4^64)` is common to both
fibers. At the table inventory level, the temporal family suffix also
exchanges with the chirality; the other family names stay fixed. Local
table row count and denominator comparisons corroborate the map.
The loader retains locally compatible blocks, including combinations
that cannot extend to a full source assignment. The twelve remaining
label axes enforce the exact original natural join. The
equality used here is at the level of the original projected scalar
sum, independent of the numerical quotient representation.

The 3,872 cut keys form 1,936 disjoint pairs. The original values for
Groups 128, 672 and 934 transfer to 3603, 3102 and 2937, respectively.
Each original group enters once. The signed subtotal restores the
external orbit weight 48 once only at profile composition. The
full coefficient residual cannot subtract the dense profile until its
remaining 1,933 distinct representatives have been resolved.

From clean extraction replay the pair map and retally. Pass the
repository publication audit directory containing the five pinned
upstream archives as `AUDIT_DIRECTORY`.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B pair-retally.py AUDIT_DIRECTORY | cmp - pair-retally.tsv
python3 -B check-upper-support.py | cmp - upper-support.out
```

## Maximum-input controls

Groups 934, 2937, 1673 and 2198 each load 3,436,540 signed input rows.
The latter three ran the original preparer serially once. The first
pair produces 1,298,202 post-sweep rows and the second 1,110,546.
Both pairs give matching conditioned row counts on all eight assignments
under the same ordered label exchange. The original logical sweep order
can visit a different row count within a pair. These runs quantify
preparation and support. They do not produce a new terminal scalar
by direct contraction.

The logs preserve the original preparer and census input identities.
Reconstruct the trusted compiled input directory from the earlier dense
factor input and reuse pilot records. Use matching `block-index.tsv`,
`schema.tsv`, `cut-axes.tsv`, `cut-plan.tsv`, `quotient.py` and
`prepare-branch.py`. In separate empty output directories, run
`python3 -B prepare-branch.py 2937` (or 1673 or 2198), then use the
included `conditioned-census.py` on those outputs. The only pickle
inputs are the locally generated frontiers from the frozen preparer.
The archive contains no binary frontier or compiled input.

## Group 1673 held-out contraction attempt

The author trial selected joint assignment 2, the smallest of the
eight by total signed row count. Its exact support roster agrees with
the preceding census. The original guard reached a 22-factor cap in
52.01 seconds. The transferred exact unsharded continuation reached
an 18-factor bounded stop in 42.17 seconds with 1,820,644 rows. These
are author measurements with no terminal scalar or independent
verification of the new frontiers.

The small author receipts and scripts in `1673/L2/` reconstruct the
saved frontiers from the prepared Group 1673 input. Run the copy of
`condition.py` with the prepared Group 1673 pickle and its recorded
hash. Run `run.py` from a new output directory with the included
`contract-slice.py`. Check the resulting cap hash. In the included
`unsharded.py`, set `ROOT` to the reproduced cap filepath and keep its
pinned hash and shape checks. Run from that directory alongside
`peer_pair_source.py`. The saved cap and continuation hashes are in
`local-frontiers.sha256`.
