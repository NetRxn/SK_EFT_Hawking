# Independent original N16 predecessor-roster review R7

**ACCEPT the exact cross-branch coefficient query for the selected
two-center raw S2 seam.** The fixed continuation coframe and original
contact pair are retained. Both centers have the complete original S2
roster. The represented product, signed cancellation and typed bounded
query are verified. Other continuation factors and centers, S4 and all
nine original site alternatives, global support, proved last incidences,
full Z and connected normalization remain owed.

## Authority and exact replay

The author first receipt was fresh at 212e9f91e. The original final
receipt reported only source drift. I verified that the complete
intervening diff to 0ce96127c contains just
FiniteGrassmannShiftedDiracBerezin.lean and the aggregate Lean import,
with both original Python source blobs unchanged. The reviewer packet
was fresh at intake and delivery, with byte-identical receipts.

The final author program reproduced every deterministic JSON field.
Its process peak RSS was 113,868,800 bytes in replay. The plane-marker
program reproduced its receipt byte for byte. The pre-reservation
receipt and final author JSON agree after removing observed RSS.
Charged work sums to 1,165,850 operations. The scoped oracle reported
34 prospective records at peak, and the later-factor arena held
10,240 records in 88 maps with no live indexes or readers. The
retained predecessor projection maximum was 36. This accounting
covers the named records, projections and typed operations. Fixed
source matrices, separately retained oracle objects and process
RSS have separate boundaries. The zero-work control refused before
the first projection without emitting a coefficient. The author's
earlier exploratory class-scope NameError remains preserved.

## Independent source and signed path checks

I rebuilt all 16 coframe maps at each center from the four signed
hopping blocks in the explicit global bar/psi basis. I independently
formed the original closed D† C† B A matrix and the oriented trace for
each world and internal pair. Every exact coframe and grouped trace
coefficient matched the author source. At both centers, each of the
72 unequal-internal groups has four equal signed quarters and 128
nonzero trace keys. In each of the 24 diagonal groups the nonzero
terms cancel in pairs under coframe reversal. The original even
coframe products commute. This accounts for the complete 384
ordered S2 terms per center. The separately selected future coframe
has 64 records and both exact contacts have 64 and 128 records.

The independent calculation filters each original operand by exact
mask and Counter containment. It enumerates forward combinations of
the five predecessor and three later factors, requiring disjoint
masks and exact final multisets. It forms each signed coefficient
by explicit basis inversion and keeps its derivative slot and
direction. It uses the author evaluator only for comparison and
does not use the author inverse split, subtraction or sign code
to construct the reference. For the 32 authored keys it reproduced
every signed predecessor/later table, raw path count, projection
count, final group subtotal and common-key sum.

The exact fixed predecessor restriction reproduces all 20 R6 tables
and path counts. The 12 new keys span all six predecessor planes in
both slots and include genuine direction-1 mixed paths. Thirteen
later-group subtotals cancel across distinct predecessor branches.
Five entire new target coefficients vanish despite nonzero branch
totals. These cancellations preserve signed provenance until its
addition into the shared physical key.

## Incidence and adverse controls

For every grouped trace I derived mandatory and possible anchor sets
from its actual independently computed monomials. They coincide on
the four distinct plaquette anchors. At either center each plane has
a mandatory marker absent from every other plane and coframe/contact
factor in this seam. Every raw target with a path recovers exactly
one plane per center. The marker and all observed predecessor/later
groups agree for all 32 keys. These raw markers do not establish a
last incidence after further factors or Haar projection.

A distinct mixed-slot target derived from an actual literal key
matched eight direction-0 paths in two predecessor branches, in
addition to the authored direction-1 cases. Wrong anchored J labels
in both slots and removing a mandatory curvature anchor all produce
zero paths in both calculations. The zero-work probe also refused
independently, with no charge or coefficient. My first exploratory
review compared independently ordered diagonal roster entries before
canonicalizing their order. The recorded assertion is retained. The
final script compares the same complete set in canonical order.

Evidence is under /tmp/task4-roster-review-r7- with suffixes first.json,
final.json, replay.json, planes-replay.json, signed.py, signed.json,
independent.stderr and independent.md. No checkout, Lean, slot or full
campaign actions occurred.
