# Original N16 Task4 predecessor roster R7

## Scientific boundary

The selected original source-C, closed-word N16 seam starts at
`x=(0,0,0,0)` and keeps the R6 continuation coframe
`T_{x+e2,2,0}`, literal source center `y=x+e0` and later S2 center
`y`. The new sum includes the complete predecessor S2 roster at
`x` in this seam. The later S2 factor also includes its entire
roster at `y`. This is an exact coefficient query of the specified
product. The fixed continuation coframe is a factor selected in
the prior seam. The result leaves the other factors and choices in
its originating action product, other centers, S4, all nine
site-alternative products, full Z and connected normalization open.

## Original roster and signed order

At each center the canonical `original_action_factors` gives 24 S4
and 384 S2 ordered terms. The S2 list ranges over all 24 ordered
world-axis permutations and all 16 internal pairs. The even exterior
coframes commute, so sort the two world coframe axes and carry their
internal indices with them. Each grouped key
`(k,l,mu,nu,a,b)` uses the sorted complementary curvature pair and
the sorted coframe pair. Each has four ordered source terms. Their
one-quarter weights are kept in the original coefficients. All 24
internal-diagonal keys have four nonzero trace terms that pair as
opposites and sum to zero. The other 72 have four equal signed
quarters. The trace sum has 128 quaternion monomials and exactly two
powers on each curvature axis. Every coframe has 64 signed records.
Each grouped trace carries exactly one original `g2`; there is no
additional orbit weight.

For a key `(mask, exact symbol multiset, raw slot)`, project each
operand by exterior-bit containment and symbol multiplicity. Stream
one predecessor branch at a time with exact residual multiset
subtraction and zero exterior intersections. The physical factors
are the two predecessor coframes, their associated trace, the
fixed continuation coframe and the contact. The trace is scalar
and every non-scalar factor has even exterior degree. Moving the
trace first leaves the exterior sign unchanged; the inversion count
still determines the sign of each individual ordered mask product.
Exactly one factor supplies each queried raw slot, so no jet
factorial is introduced. The contact slots are
`(0,) → J_(y,0,0) T_(y,0,0)` and
`(0,1) → J_(y,0,0) [T_(y,0,0)+T_(y,1,0)]`.

At the later center, the four remaining exterior bits have six
ordered two-bit splits. The complementary trace and coframe axes
force the symbol split for each later branch. The R5 exact fiber
evaluator tests all 72 choices. Every contributing path therefore
passes the projected operand tests and is enumerated with the
original labels. The full query accumulates signed coefficients
by later group and then sums over that group too. The predecessor
and later group labels are provenance only. Treating them as
physical key components would miss the cross-branch seam.

The separately expressed forward oracle uses Counter containment,
canonical ExteriorPolynomial multiplication and the canonical RawJet
slot construction. It independently materializes only target-compatible
branch products under explicit work and scratch record admission,
first evaluates those branch products separately and then adds the
projected predecessor prefixes before multiplying the later factor.
Both orders must give the same physical-key coefficient and the same
nonzero later group subtotals. The original R6 branch is an exact
restriction check on every saved target.

## Cost and remaining incidence

The fixed factor inputs outside the arena contain two sets of
`16·64 + 72·128` records, plus 64 continuation and 192 contact
records. The later map mirrors contain 10,240 separately tracked
records. The predecessor projection cache is bounded above by
`16·64 + 72·128 + 64 + 128 = 10,432` records per query. The signed
stream keeps five live factor levels and at most 72 by 72 group
subtotals. The forward oracle's 16,384-record cap prices the
prospective current product and the explicitly named retained
arguments. The fixed factors, other projection views and interpreter
arithmetic lie outside that cap. Source construction temporary
matrices and physical RSS are observed separately. Both evaluators
share an aggregate typed work cap. A query whose cap refuses has
no accepted coefficient.

For each operand the projected masks and actual anchor coordinate
keys are kept through the whole tested seam. A global evaluation
still needs a chosen original product order over all 16 sites,
actual source and frame/contact supports, per-site source and
coupling grades, and an incidence proof that each local eight-bit
mask or link quaternion moment is closed after its last possible
use. Other factors can reuse the same anchored coordinates and
exterior bits. Site/coupling exponents must respect
`2q+p≤4` and the nine alternatives at each site. Branch labels
cannot be retained as physical keys at projection. Each valid
projection must combine coincident signed residual keys before
declaring either support or normalization. Nothing in the measured
query bounds gives a bound for enumerating the full support.

Replay from primary using
`PYTHONPATH=. .venv/bin/python -B /tmp/publication-task4-predecessor-roster-r7.py`.
The same-named R6/R5/R4 scratch imports and R6 JSON are frozen inputs.
The first scratch attempt hit Python class-scope name lookup before
evaluating any target. The traceback is preserved separately.

## Measured reaggregation

The first exact replay over all 72 predecessor choices preserved all
20 R6 fixed-branch tables and found four reachable original
predecessor identities for each saved target. It spent 19,010,546
aggregate charged operations. Reusing the separately projected
later factors in the forward oracle preserved every recorded
deterministic field of those 20 results and reduced repeated scans.

The expanded test constructs 12 additional target keys from actual
source leaves, one for every curvature plane and raw slot. The
mixed target seeds use the direction-1 contact term. The bounded
search uses at most 96 draws per plane/slot and the actual maximum
was 23. Every selected key has two or more distinct predecessor
branches with nonzero signed totals. The complete forward and
streamed tables agree for all 32 targets, including all per-branch
nonzero later subtotals and the final common-key sum.

Across the additional targets, there are 13 exact later-group
cancellations between distinct predecessor branches. Five entire
new target coefficients vanish despite nonzero predecessor totals.
For the plane (1,2) literal target, the two predecessor totals are
−i/128 and +i/128. All four affected later-group subtotals cancel.
For the plane (0,3) mixed target, the two predecessor totals are
−i/512 and +i/512, and the affected later group vanishes. The
first saved literal control is constructive: +i/512, +i/1024 and
+i/1024 reach each of four later groups for +i/64 overall.
The four previously canceled mixed keys also still vanish. Retaining
branch identity in the key or replacing signed addition with Boolean
support would fail these controls.

The 32-target extension, before the wrong-source and work-cap
adverse controls, charged 1,105,908 operations, with a maximum
36 retained predecessor projection records and 34 prospective records
in the scoped forward product. The later arena had 10,240 live
records in 88 maps, with zero indexes or active readers at receipt.
The baseline and expanded first receipts retain native RSS separately
from coefficient residency.

The original first continuity check was fresh at primary 212e9f91e.
ROOT absorbed a separate reviewed Lean result at 0ce96127c. The
original packet then reported source drift. The full diff contains
exactly the Lean module and aggregate import, and both assigned
Python files have identical Git blobs. The original first, final
and source-diff receipts are preserved. This packet remains a
stale author pin for the independent reviewer to reconcile.

## Plane marker and adverse controls

Each nonzero original curvature monomial is homogeneous of degree
one in the coordinates at each of the four plaquette anchors.
The spin link entries are linear, conjugation preserves anchor
labels and each matrix product uses each of the four distinct
anchors once. Each coframe monomial carries one quaternion
coordinate at one of its two directed hopping anchors. The
separate plane receipt enumerates these exact support sets in
the original selected seam. For each of the six planes at either
center, the plane has at least one mandatory anchor not used by
another curvature plane at that center, any curvature plane at
the other center, or any coframe/contact factor here. Thus a full
raw key recovers both curvature planes whenever a path exists.
There is no collision between distinct planes at the same center
in this seam. The measured collisions instead occur between
different internal branches of the same plane. The marker receipt
checks all 32 raw keys against all their observed path branch
labels. This invariant uses exact, unprojected anchors and does
not persist automatically after Haar evaluation or further
original factors.

The final replay rejects a wrong anchored J label in both raw
slots with zero paths and agrees with the forward oracle. An
explicit zero-work control refuses before the first projection
check and emits no coefficient. The full result charges 1,165,850
operations and uses 34 prospective scoped oracle records. Its
native RSS is 113,999,872 bytes. A final version reserves
projected-later cache capacity before each multiplication using
the candidate pair upper bound. It reproduced every deterministic
field of the first replay with the adverse controls. Replay the
separate static check using
`python3 -B /tmp/publication-task4-predecessor-roster-r7.planes.py`
beside the saved final JSON.

Independent review is still required. No tracked source, Lean
slot, repository closure or complete N16 execution was changed
by this numerical assignment.
