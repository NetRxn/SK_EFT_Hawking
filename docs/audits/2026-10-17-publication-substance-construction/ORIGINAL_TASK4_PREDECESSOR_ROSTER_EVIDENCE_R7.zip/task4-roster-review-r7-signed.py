from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial
import importlib.util
import json
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

def load(label, path):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module

r4 = load("r4review", "/tmp/publication-task4-later-full-vertex-r4.py")
Q, P, S = o.QComplex, o.Polynomial, o.Symbol
reg = o.OriginalRegulator()
x, y = reg.sites[0], reg.step(reg.sites[0], 0)[0]
x2 = reg.step(x, 2)[0]
q = S("g2", ())
j = S("J", (y, 0, 0))
assert (reg.volume, reg.word, reg.convention) == (16, "closed", "source_C")

def tensor(alpha, *, slot=(), labels=()):
    # Rebuild the four signed bilinears directly from the block definition
    # and the globally ordered bar/psi basis. No author arena or ExteriorPolynomial.
    positions = {token: i for i, token in enumerate(reg.generator_order)}
    out = defaultdict(Q)
    blocks = f.original_coframe_blocks(reg, alpha)
    for b in blocks:
        for i, k in product(range(4), repeat=2):
            a, z = positions[b.bar_site, "bar", i], positions[b.psi_site, "psi", k]
            for key, value in b.matrix[i][k].terms:
                out[(1 << a | 1 << z, tuple(sorted((*labels, *key))), slot)] += value * b.weight * (-1 if a > z else 1)
    return {k: v for k, v in out.items() if v}

def trace_rows(site, k, l, mu, nu, a, b):
    # Direct closed matrix word D† C† B A, with original quaternion labels.
    anchors = (site,k), (reg.step(site,k)[0],l), (reg.step(site,l)[0],k), (site,l)
    links = [f.original_spin4_link(*(tuple(P.variable(S("q",(*z,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for z in anchors]
    A,B,C,D = links
    U = o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(D),o.matrix_dagger(C)),o.matrix_multiply(B,A))
    gamma = o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    poly = sum((U[i][k]*gamma[k][i] for i,k in product(range(4),repeat=2)),P()) * o.epsilon((k,l,mu,nu))
    return {(0,key,()): value for key,value in poly.terms}

def indices(mask):
    return [i for i in range(mask.bit_length()) if mask >> i & 1]

def multiply(left, right):
    out = defaultdict(Q)
    for (lm,lk,lj), lv in left.items():
        for (rm,rk,rj), rv in right.items():
            if lm & rm or len(lj) + len(rj) > 2:
                continue
            z = tuple(sorted(lj + rj))
            multiplicity = 1
            for i in set(z):
                multiplicity *= factorial(z.count(i)) // (factorial(lj.count(i)) * factorial(rj.count(i)))
            parity = sum(i > k for i,k in product(indices(lm),indices(rm))) % 2
            out[lm|rm,tuple(sorted(lk+rk)),z] += lv * rv * (-multiplicity if parity else multiplicity)
    return {k:v for k,v in out.items() if v}

def summed(*maps):
    out = defaultdict(Q)
    for d in maps:
        for k,v in d.items(): out[k] += v
    return {k:v for k,v in out.items() if v}

def slot_relabel(d, slot):
    return {(m,k,slot):v for (m,k,_),v in d.items()}

def snapshot(arena, handle):
    out = {}
    arena.scan(handle, lambda k,v:out.__setitem__(k,v))
    return out

from collections import Counter
from functools import lru_cache
from itertools import combinations

r7=load("r7review","/tmp/publication-task4-predecessor-roster-r7.py")
r4,r5=r7.r4,r7.r5
w=r5.Work(cap=20_000_000)
arena=r4.Arena(r4.Caps(100_000,65_536))

@lru_cache(maxsize=None)
def ordered_closed_word(site,k,l):
    sx=reg.step(site,k)[0]
    sy=reg.step(site,l)[0]
    anchors=((site,k),(sx,l),(sy,k),(site,l))
    ls=[f.original_spin4_link(*(tuple(P.variable(S("q",(*anchor,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for anchor in anchors]
    a,b,c,d=ls
    return o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(d),o.matrix_dagger(c)),o.matrix_multiply(b,a))

def direct_trace(site,k,l,mu,nu,a,b):
    mat=ordered_closed_word(site,k,l)
    gamma=o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    p=sum((mat[i][j]*gamma[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))
    return {(0,tuple(sorted((*k,q))),()):coef for k,coef in p.terms}

def raw_exact(e):
    return {(m,key,()):coef for m,poly in e.terms for key,coef in poly.terms}

C={}
H={}
source={}
diagonals={}
for site in (x,y):
    ac,ah,ad=r7.roster(reg,site,w)
    C[site]={(mu,a):tensor((site,mu,a)) for mu,a in product(range(4),repeat=2)}
    assert all(len(rows)==64 and rows==raw_exact(ac[key]) for key,rows in C[site].items())
    traces={}
    cancels=[]
    for mu,nu in combinations(range(4),2):
        k,l=[i for i in range(4) if i not in (mu,nu)]
        for a,b in product(range(4),repeat=2):
            tag=k,l,mu,nu,a,b
            main=direct_trace(site,k,l,mu,nu,a,b)
            flip_coframes=direct_trace(site,k,l,nu,mu,b,a)
            flip_curve=direct_trace(site,l,k,mu,nu,a,b)
            flip_both=direct_trace(site,l,k,nu,mu,b,a)
            if a==b:
                assert main and flip_coframes and flip_curve and flip_both
                assert not summed(main,flip_coframes) and not summed(flip_curve,flip_both)
                cancels.append(tag)
            else:
                assert len(main)==128 and main==flip_coframes==flip_curve==flip_both
                assert main==raw_exact(ah[tag])
                traces[tag]=main
    assert len(cancels)==24 and sorted(cancels)==ad
    assert len(traces)==72 and set(traces)==set(ah)
    H[site]=traces
    diagonals[site]=sorted(cancels)
    source[site]=ac,ah
F=tensor((x2,2,0))
D0=tensor((y,0,0),labels=(j,))
D1=tensor((y,1,0),labels=(j,))
D={(0,):D0,(0,1):summed(D0,D1)}
assert (len(F),len(D0),len(D[(0,1)]))==(64,64,128)
_,_,_,fa,_=r4.factors(reg)
assert F==raw_exact(fa)
# For running the author's evaluator on extra probes only.
yh={tag:arena.ingest(r4.rows(e)) for tag,e in source[y][1].items()}
yc={tag:arena.ingest(r4.rows(e)) for tag,e in source[y][0].items()}
Dj=P.variable(j)
DC={(0,):source[y][0][0,0]*Dj,(0,1):(source[y][0][0,0]+source[y][0][1,0])*Dj}
assert all(D[slot]==raw_exact(e) for slot,e in DC.items())
assert arena.metric()["live_records"]==10240 and arena.metric()["live_maps"]==88

# Infer actual anchor support from the independently constructed factors.
def anchors(row):
    return {(s.index[0],s.index[1]) for s in row[1] if s.family=="q"}
def anchor_union(factor):
    return set().union(*(anchors(row) for row in factor))
common=set().union(*(anchor_union(factor) for site in (x,y) for factor in C[site].values()),
                   anchor_union(F),*(anchor_union(d) for d in D.values()))
must={}
may={}
planes=list(combinations(range(4),2))
for site in (x,y):
    for plane in planes:
        factor_rows=[row for tag,d in H[site].items() if tag[:2]==plane for row in d]
        assert factor_rows and all(len(anchors(row))==4 for row in factor_rows)
        must[site,plane]=set.intersection(*(anchors(row) for row in factor_rows))
        may[site,plane]=set.union(*(anchors(row) for row in factor_rows))
        assert must[site,plane]==may[site,plane] and len(must[site,plane])==4
markers={}
for site in (x,y):
    for plane in planes:
        markers[site,plane]=must[site,plane]-common-set().union(
            *(v for k,v in may.items() if k!=(site,plane)))
        assert markers[site,plane]

def decode(d):
    def freeze(x):
        return tuple(map(freeze,x)) if isinstance(x,list) else x
    return int(d["mask_hex"],16),tuple(S(n,freeze(v)) for n,v in d["symbols"]),tuple(d["slot"])

def inv(L,R):
    return sum(i>k for i,k in product(indices(L),indices(R)))

def forward(key):
    mask,sy,slot=key
    powers=Counter(sy)
    def proj(d):
        return [(k,v,Counter(k[1])) for k,v in d.items() if k[0]&mask==k[0] and not Counter(k[1])-powers]
    cx={tag:proj(d) for tag,d in C[x].items()}
    cy={tag:proj(d) for tag,d in C[y].items()}
    hx={tag:proj(d) for tag,d in H[x].items()}
    hy={tag:proj(d) for tag,d in H[y].items()}
    ff,dd=proj(F),proj(D[slot])
    retained=sum(map(len,(*cx.values(),*hx.values(),ff,dd)))
    def terms(operands):
        for rows in product(*operands):
            union=0
            accumulated=Counter()
            coef=Q(1)
            for (m,_,_),v,c in rows:
                if union&m or (accumulated+c)-powers:
                    break
                coef*=v*(-1)**inv(union,m)
                union|=m
                accumulated+=c
            else:
                yield union,accumulated,coef,rows
    late={}
    for tag,trace in hy.items():
        _,_,mu,nu,a,b=tag
        generated=[(m,p,v) for m,p,v,_ in terms((cy[mu,a],cy[nu,b],trace))]
        if generated: late[tag]=generated
    out={}
    dirs=Counter()
    dirs_by_branch=defaultdict(Counter)
    for tag,trace in hx.items():
        _,_,mu,nu,a,b=tag
        group_sum={}
        paths=0
        for m,p,v,rows in terms((cx[mu,a],cx[nu,b],trace,ff,dd)):
            dkey=rows[-1][0]
            direction=1 if dkey in D1 else 0
            for group,factors in late.items():
                for m1,p1,v1 in factors:
                    if m&m1 or m|m1!=mask or p+p1!=powers:
                        continue
                    group_sum[group]=group_sum.get(group,Q(0))+v*v1*(-1)**inv(m,m1)
                    paths+=1
                    dirs[direction]+=1
                    dirs_by_branch[tag][direction]+=1
        if paths:
            out[tag]=(group_sum,paths)
    return out,retained,dirs,dirs_by_branch

def fmt(g):
    return [[list(k),str(v)] for k,v in sorted(g.items())]
def summarize(table):
    group_totals={}
    canceled=[]
    for group in H[y]:
        terms=[(tag,sub[group]) for tag,(sub,_) in table.items() if sub.get(group)]
        if not terms: continue
        value=sum((v for _,v in terms),Q(0))
        group_totals[group]=value
        if len(terms)>1 and not value:
            canceled.append([list(group),[[list(tag),str(v)] for tag,v in sorted(terms)]])
    return fmt(group_totals),sorted(canceled),sum(group_totals.values(),Q(0))

auth=json.load(open("/tmp/publication-task4-predecessor-roster-r7.json"))
r6doc=json.load(open("/tmp/publication-task4-complete-predecessor-r6.json"))
r6old={decode(row["output_key"]):row for row in r6doc["target_results"]}
assert [list(g) for g in sorted(H[x])]==auth["predecessor"]
assert [list(g) for g in sorted(H[y])]==auth["later"]
assert [list(g) for g in diagonals[x]]==auth["predecessor_canceled"]
assert [list(g) for g in diagonals[y]]==auth["later_canceled"]
results=[]
for row in auth["results"]:
    key=decode(row["target"])
    table,projected,directions,dirs_by_branch=forward(key)
    observed=sorted((g,n,fmt(v)) for g,(v,n) in table.items())
    expected=sorted((tuple(g),n,vals) for g,n,vals in row["branches"])
    assert observed==expected and projected==row["projected"]
    gt,canceled,total=summarize(table)
    assert gt==row["group_totals"] and str(total)==row["whole"]
    expected_cancel=sorted([group,sorted(values)] for group,values in row["canceled_groups"])
    assert canceled==expected_cancel
    if row["fixed_restriction_checked"]:
        r6row=r6old[key]
        group,paths=table.get(r7.FIXED,({},0))
        assert fmt(group)==r6row["full_group_sums"] and paths==r6row["full"]["later_raw_signed_paths"]
    else:
        branch=tuple(row["generated_from"])
        assert branch in table and sum(table[branch][0].values(),Q(0))
        assert key[2]!=(0,1) or dirs_by_branch[branch][1]
    support=anchors(key)
    recovered={site:[plane for plane in planes if markers[site,plane]&support] for site in (x,y)}
    assert len(recovered[x])==len(recovered[y])==1
    assert all(tag[:2]==recovered[x][0] and all(g[:2]==recovered[y][0] for g in sub)
               for tag,(sub,_) in table.items())
    results.append({"slot":key[2],"branches":len(table),"directions":dict(directions),
        "cancelled_groups":len(canceled),"total_zero":not total,"old":key in r6old})
assert len(results)==32 and sum(r["cancelled_groups"] for r in results)==13
assert sum(r["total_zero"] and not r["old"] for r in results)==5

# Use a literal reachable key in the mixed slot to check a separate
# direction-0 contribution. Verify both wrong source labels and one
# lost mandatory curvature anchor as impossible, through both evaluators.
keys=[decode(row["target"]) for row in auth["results"]]
literal=next(k for k in keys[20:] if k[2]==(0,))
new_key=(literal[0],literal[1],(0,1))
assert new_key not in keys
mix1=next(k for k in keys[20:] if k[2]==(0,1))
adverse=[]
for key in (literal,mix1):
    wrong=S("J",(reg.step(y,1)[0],0,0))
    adverse.append((key[0],tuple(sorted(wrong if s.family=="J" else s for s in key[1])),key[2]))
lost=next(s for s in literal[1] if s.family=="q" and (s.index[0],s.index[1]) in
          set().union(*(markers[x,p] for p in planes)))
reduced=list(literal[1]); reduced.remove(lost)
adverse.append((literal[0],tuple(reduced),literal[2]))
extras=[]
for index,key in enumerate([new_key,*adverse]):
    expected,projected,directions,_=forward(key)
    table,actual=r7.witness_table(key,*source[x],fa,DC,arena,yc,yh,w)
    assert table==expected and actual==projected
    assert (bool(expected) and bool(directions[0])) if index==0 else not expected
    extras.append({"key":r5.fingerprint(key),"branches":len(table),"directions":dict(directions)})
tiny=r5.Work(cap=0)
try:
    r7.witness_table(new_key,*source[x],fa,DC,arena,yc,yh,tiny)
except RuntimeError as exc:
    assert "work cap at 0" in str(exc) and tiny.used==0 and not tiny.counts
else:
    raise AssertionError("expected fail-closed work cap")
print(json.dumps({"roster":[{"center":site,"nonzero":len(H[site]),"diagonal":len(diagonals[site])} for site in (x,y)],
    "markers":[(site,plane,sorted(markers[site,plane])) for site in (x,y) for plane in planes],
    "authored_targets":results,"new_and_adverse":extras,"zero_cap_refusal":True},indent=2))
