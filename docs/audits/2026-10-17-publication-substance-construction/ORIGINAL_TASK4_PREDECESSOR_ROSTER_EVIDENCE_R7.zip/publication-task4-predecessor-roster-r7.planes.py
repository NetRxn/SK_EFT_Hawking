"""Source incidence proof for the raw selected seam, before any projection."""
from itertools import combinations
from pathlib import Path
import json

planes = tuple(combinations(range(4), 2))
x = (0, 0, 0, 0)


def step(site, axis):
    return tuple((v + (j == axis)) % 2 for j, v in enumerate(site))


def plaquette(site, plane):
    k, l = plane
    return {(site, k), (step(site, k), l), (step(site, l), k), (site, l)}


def coframe(site, axis):
    return {(site, axis), (step(site, axis), axis)}


y, w = step(x, 0), step(x, 2)
common = set().union(*(coframe(site, a) for site in (x, y) for a in range(4)),
                     coframe(w, 2), coframe(y, 0), coframe(y, 1))
anchors = {site: {plane: plaquette(site, plane) for plane in planes} for site in (x, y)}
markers = {}
for center, other in ((x, y), (y, x)):
    other_anchors = set().union(*anchors[other].values())
    markers[center] = {}
    for plane in planes:
        different = set().union(*(v for p, v in anchors[center].items() if p != plane))
        unique = anchors[center][plane] - common - other_anchors - different
        assert unique
        markers[center][plane] = unique

path = Path(__file__).with_name("publication-task4-predecessor-roster-r7.json")
receipt = json.loads(path.read_text())
assert receipt["regulator"]["extents"] == [2, 2, 2, 2]
assert receipt["centers"] == [list(x), list(y)]
assert receipt["fixed_future"] == [list(w), 2, 0]
for row in receipt["results"]:
    support = {(tuple(i[0]), i[1]) for family, i in row["target"]["symbols"] if family == "q"}
    xp = [p for p, keys in markers[x].items() if keys & support]
    yp = [p for p, keys in markers[y].items() if keys & support]
    assert len(xp) == len(yp) == 1
    for branch, _, groups in row["branches"]:
        assert tuple(branch[:2]) == xp[0]
        assert all(tuple(group[:2]) == yp[0] for group, _ in groups)
print(json.dumps(dict(
    source_factors="one q per plaquette anchor, one q per coframe monomial",
    branch_plane_markers=[
        (center, [(plane, sorted(keys)) for plane, keys in per_center.items()])
        for center, per_center in markers.items()
    ], checked_target_keys=len(receipt["results"]),
    scope="selected N16 raw seam; preserves exact anchored q symbols before projection"),
    indent=2))
