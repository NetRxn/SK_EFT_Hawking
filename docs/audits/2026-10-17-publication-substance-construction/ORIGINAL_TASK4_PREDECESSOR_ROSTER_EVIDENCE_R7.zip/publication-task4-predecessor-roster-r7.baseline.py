"""Exact bounded branch reaggregation for the selected original N16 seam."""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
import importlib.util
import json
import resource
import sys

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("r6_roster", HERE / "publication-task4-complete-predecessor-r6.py")
r6 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r6
spec.loader.exec_module(r6)
r5, r4 = r6.r5, r6.r4
Q, P, E, S = r6.Q, r6.P, r6.E, r6.S
G2, SLOTS = r6.G2, r6.SLOTS
FIXED = (2, 3, 0, 1, 0, 1)


def roster(reg, center, work):
    """Reduce raw ordered source terms by their even coframe products."""
    anchors = {(center, axis) for axis in range(4)}
    anchors |= {(reg.step(center, axis)[0], other)
                for axis, other in product(range(4), repeat=2) if axis != other}
    links = {
        anchor: r4.f.original_spin4_link(
            *(tuple(P.variable(S("q", (*anchor, hand, coord))) for coord in range(4))
              for hand in ("L", "R")))
        for anchor in sorted(anchors)
    }
    pieces = defaultdict(list)
    s4 = []
    for factor in r4.f.original_action_factors(reg, center, links):
        work.charge("raw_source_terms")
        if factor.t_degree == 4:
            s4.append(factor)
            continue
        first, second = sorted(factor.components)
        _, mu, a = first
        _, nu, b = second
        k, l = tuple(axis for axis in range(4) if axis not in (mu, nu))
        pieces[k, l, mu, nu, a, b].append(factor.coefficient)
    assert len(s4) == 24
    assert len(pieces) == 96 and all(len(items) == 4 for items in pieces.values())
    traces = {}
    canceled = []
    for key, items in sorted(pieces.items()):
        k, l, mu, nu, a, b = key
        total = sum(items, P())
        if a == b:
            assert not total and all(items)
            assert Counter(items) == Counter(-term for term in items)
            canceled.append(key)
            continue
        assert total and all(term == total * Fraction(1, 4) for term in items)
        assert len(total.terms) == 128
        assert all(Counter(symbol.index[1] for symbol in symbols) == {k: 2, l: 2}
                   for symbols, _ in total.terms)
        traces[key] = E(((0, total * P.variable(G2)),))
    assert len(traces) == 72 and len(canceled) == 24
    coframes = {(mu, a): r4.exterior(reg, (center, mu, a))
                for mu, a in product(range(4), repeat=2)}
    assert all(r5.count(e) == 64 for e in coframes.values())
    return coframes, traces, canceled


def projection(e, target, work):
    mask, symbols, _ = target
    selected = []
    for (m, key, slot), coefficient in r4.rows(e):
        work.charge("operand_projection_checks")
        assert not slot
        if m & mask == m and r5.subtract(symbols, key) is not None:
            selected.append((m, key, coefficient))
    return selected


def witness_table(target, x_coframes, x_traces, future, contact, arena,
                  later_coframes, later_traces, work):
    """Project the original factors, then stream signed paths branch by branch."""
    mask, symbols, slot = target
    C = {key: projection(e, target, work) for key, e in x_coframes.items()}
    H = {key: projection(e, target, work) for key, e in x_traces.items()}
    F = projection(future, target, work)
    D = projection(contact[slot], target, work)
    projected = sum(len(rows) for rows in (*C.values(), *H.values(), F, D))
    assert projected <= 16*64 + 72*128 + 64 + 128
    out = {}
    for branch, h in H.items():
        _, _, mu, nu, a, b = branch

        def descend(index, occupied, used, residual, value):
            if index == len(operands):
                work.charge("completed_predecessor_paths")
                callback((occupied, used, slot), value)
                return
            for m, key, coeff in operands[index]:
                work.charge("ordered_factor_candidates")
                if m & occupied:
                    continue
                remainder = r5.subtract(residual, key)
                if remainder is not None:
                    descend(index + 1, occupied | m, tuple(sorted(used + key)),
                            remainder, value * coeff * r5.mask_sign(occupied, m))

        def scan_predecessors(_, enter):
            nonlocal callback
            callback = enter
            descend(0, 0, (), symbols, Q(1))

        if not h:
            continue
        # Physical product order C · H · F · D. All non-scalar factors
        # have even exterior degree. There is one and only one raw slot.
        operands = (h, C[mu, a], C[nu, b], F, D)
        if not all(operands):
            continue
        callback = None

        class ReadView:
            get = staticmethod(arena.get)
            scan = staticmethod(scan_predecessors)

        group, _, _, paths, _ = r5.fiber(ReadView(), None, later_coframes,
                                         later_traces, target, work)
        if paths:
            out[branch] = (group, paths)
    return out, projected


def direct_table(target, x_coframes, x_traces, future, contact,
                 y_coframes, y_traces, work):
    """Independent forward ExteriorPolynomial oracle and Counter filtering."""
    mask, symbols, slot = target
    counts = Counter(symbols)
    px = {k: r5.subset_factor(e, mask, counts, work) for k, e in x_coframes.items()}
    hx = {k: r5.subset_factor(e, mask, counts, work) for k, e in x_traces.items()}
    ff = r5.subset_factor(future, mask, counts, work)
    dd = r5.subset_factor(contact[slot], mask, counts, work)
    result = {}
    summed = E()
    for branch, trace in hx.items():
        _, _, mu, nu, a, b = branch
        first, second = px[mu, a], px[nu, b]
        if not all((first, second, trace, ff, dd)):
            continue
        val = work.oracle_product(first, second, trace, ff, dd)
        val = work.oracle_product(val, trace, ff, dd)
        val = work.oracle_product(val, ff, dd)
        val = work.oracle_product(val, dd)
        val = r5.subset_factor(val, mask, counts, work)
        if not val:
            continue
        if r5.count(val) + r5.count(summed) > work.oracle_record_cap:
            raise RuntimeError("oracle summed prefix cap")
        summed += val
        jet = r4.o.RawJet((0, 1), (((), E()), (slot, val)))
        by_group = r5.direct(jet, y_coframes, y_traces, target, work)
        if by_group:
            result[branch] = by_group
    summed_jet = r4.o.RawJet((0, 1), (((), E()), (slot, summed)))
    common = r5.direct(summed_jet, y_coframes, y_traces, target, work)
    return result, common


def nonzero(mapping):
    return {key: value for key, value in mapping.items() if value}


def main():
    reg = r4.o.OriginalRegulator()
    x = reg.sites[0]
    y = reg.step(x, 0)[0]
    w = reg.step(x, 2)[0]
    work = r5.Work(cap=20_000_000)
    x_coframes, x_traces, x_diag = roster(reg, x, work)
    y_coframes, y_traces, y_diag = roster(reg, y, work)
    a, b, trace, future, _ = r4.factors(reg)
    assert (x_coframes[0, 0], x_coframes[1, 1], x_traces[FIXED]) == (
        a, b, trace * P.variable(G2))
    assert future == r4.exterior(reg, (w, 2, 0))
    j = P.variable(S("J", (y, 0, 0)))
    contact = {SLOTS[0]: y_coframes[0, 0] * j,
               SLOTS[1]: (y_coframes[0, 0] + y_coframes[1, 0]) * j}
    assert tuple(r5.count(contact[slot]) for slot in SLOTS) == (64, 128)
    arena = r4.Arena(r4.Caps(100_000, 65_536))
    yh = {key: arena.ingest(r4.rows(e)) for key, e in y_traces.items()}
    yc = {key: arena.ingest(r4.rows(e)) for key, e in y_coframes.items()}
    receipt = json.loads((HERE / "publication-task4-complete-predecessor-r6.json").read_text())
    results = []
    for old in receipt["target_results"]:
        target = r6.decoded(old["output_key"])
        table, projected = witness_table(target, x_coframes, x_traces, future,
                                         contact, arena, yc, yh, work)
        direct, common = direct_table(target, x_coframes, x_traces, future, contact,
                                      y_coframes, y_traces, work)
        assert {branch: nonzero(group) for branch, (group, _) in table.items()
                if nonzero(group)} == direct
        initial = {tuple(group): coeff for group, coeff in old["full_group_sums"]}
        actual = {group: str(value) for group, value in table.get(FIXED, ({}, 0))[0].items()}
        assert actual == initial
        total = defaultdict(lambda: Q(0))
        cross_cancellations = []
        for group in y_traces:
            summands = [(branch, values[group]) for branch, (values, _) in table.items()
                        if group in values and values[group]]
            if not summands:
                continue
            subtotal = sum((value for _, value in summands), Q(0))
            total[group] = subtotal
            if len(summands) > 1 and not subtotal:
                cross_cancellations.append((group, [(branch, str(value)) for branch, value in summands]))
        assert nonzero(total) == common
        whole = sum(total.values(), Q(0))
        results.append(dict(target=old["output_key"], projected=projected,
                            whole=str(whole), branches=[
                                (branch, paths, r6.format_groups(values))
                                for branch, (values, paths) in table.items()],
                            canceled_groups=cross_cancellations,
                            group_totals=r6.format_groups(total)))
    print(json.dumps(dict(regulator=dict(extents=reg.extents, word=reg.word,
                  convention=reg.convention), centers=(x,y), fixed_future=(w,2,0),
        raw_per_center={"s2":384,"s4":24,"s2_orientations_per_key":4},
        predecessor=list(x_traces), predecessor_canceled=x_diag, later=list(y_traces),
        later_canceled=y_diag, all_site_alternatives=r4.ALTERNATIVES,
        results=results, work=dict(work.counts), work_total=work.used,
        work_cap=work.cap, oracle_record_cap=work.oracle_record_cap,
        oracle_pair_peak=work.oracle_max_prospective_records, arena=arena.metric(),
        native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),indent=2))


if __name__ == "__main__":
    main()
