from hashlib import sha256
from pathlib import Path
from re import M, findall

def records(name):
    data=Path(name).read_text()
    raw=findall(r'^state (\S+) ([a-f0-9]{64}) \d+ \d+$',data,M)
    assert len(raw)==len(dict(raw))==20
    return dict(raw)
assert sha256(Path('case42-audit.out').read_bytes()).hexdigest()=='560be4d47c58ebc3186e77c5e7cf25ef25ae750c987fcfcf4f3f1401e40700b7'
earlier,later=map(records,('case42-audit.out','audit.out'))
assert earlier.keys()==later.keys()
assert set(earlier.values()).isdisjoint(later.values())
print('PASS all 20 audited case 42 and case 46 outer, inner and terminal state hashes are disjoint')
