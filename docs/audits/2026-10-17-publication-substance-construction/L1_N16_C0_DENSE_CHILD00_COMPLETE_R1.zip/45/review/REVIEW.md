# Independent verification of complementary tuple 0 outer case 45

The exact normalized sum is **-1000730277528745670596611/5192296858534827628530496329220096 + 0i**.

The original archive is extracted at checkpoint bc45b03f4146c9fb821b7471b18f27b66ed92c05. Its manifest verifies and pins the decompressed selector-1 parent to SHA256 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d. Independent matching on the rejected pair reconstructs the complete 48-coordinate outer roster over 6,427,904 matched products. Case 40 is (66,(2,)) with 212,688 matched products and an exact inverse lift of 430,572 compatible rows. Selector-0 and selector-1 inner factor arrays differ.

Two outer row caps reproduce the seven-factor inner parent at SHA256 21397906f83d4dc0fd37aa141a8bb3b558a08f1bc03f0fdda14479b02c85db7e. The independently computed inner census gives 2,280,960 pair matches across nine distinct values of G(0,1,2), with maximum 497,664. Every nonzero network product must match on the selected pair. Nine exact inverse lifts recover every compatible input row, coefficient and denominator. The byte readback covers both outer cap/restart stages and all 22 generic inner stages, including 17 capped contractions and five exact terminals.

Five final states pass independent sparse contraction. The alternate triangles of slices 2 and 3 use pivot factor 1 and respectively 18,643,968 and 19,975,680 exact support triples. The independent arithmetic uses 18,752,832 and 20,092,320 Gaussian products. Slices 7 and 8 use pair (1,2), compared with author pair (1,3). Each alternate replay processes 8,650,800 outer pair matches and 27,716,400 Gaussian products in 16 bounded shards. Peak arithmetic per shard is 2,049,424 products and peak block state 24,984 entries. All four alternative arithmetic paths reproduce the author raw numerators exactly.

All 32 author shard receipts have complete disjoint intervals through the actual pivot tables. A separate support census reproduces each original interval's probe or pair-match count. Their raw sums agree with the corresponding independent terminal replays. All nine terminal values apply denominator 40512224221827380280140849737629696 and positive normalization 1/(16*4^64) once. The exact signed slice values are listed in audit.out.

The five outer commands total 25.139 s and the 53 inner commands total 315.124 s across two workers. Independent triangles took 11.055 s and 11.401 s, and independent four-factor replays took 16.864 s and 16.820 s. Each timing measures elapsed time per command during concurrent scratch execution.

The relative evidence manifest covers scripts, receipt copies and timings. The source archives are separately pinned. The full signed coefficient remains open.
