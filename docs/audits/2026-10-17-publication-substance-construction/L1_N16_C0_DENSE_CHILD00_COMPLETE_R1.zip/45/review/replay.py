from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

author = Path('/private/tmp/l1-c0-complementary-cases24-47.XWr8Qj/tuple0-1/45')
jobs = []
for line in (author/'author-case45.tsv').read_text().splitlines():
    if line.startswith('sum\t'):
        continue
    index, axis, count, real, imaginary, receipt = line.split('\t')
    i = int(index)
    if i in (2,3,7,8):
        continue
    tag = receipt.removesuffix('-contract.out')
    jobs.append((i, author/f'label-{tag}-reduced-frontier.pkl', author/receipt))

def run(job):
    index, path, receipt = job
    for method in ('sparse-replay.py', 'sparse-support-replay.py'):
        log = Path(f'slice-{index}-{method.removesuffix(".py")}.out')
        with log.open('xb') as out:
            result = subprocess.run([sys.executable, '-u', method, str(index), 'terminal',
                                     str(path), str(receipt)], stdout=out,
                                    stderr=subprocess.STDOUT, timeout=60)
        print(index, method, result.returncode, log.name, sep='\t', flush=True)
        if result.returncode == 0:
            return
    print('Capture needed for',index, flush=True)

with ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(run,jobs))
