#!/usr/bin/env bash
set -euo pipefail
root=$PWD
mkdir -p source-lineage/checkpoint/independent
cp DENSE_CONDITIONED_SCALARS/author/{contract-second-cut-r2.py,quotient-nine-minimum.py} source-lineage/
cp DENSE_CONDITIONED_SCALARS/author/checkpoint/quotient.py source-lineage/checkpoint/
cp DENSE_CONDITIONED_SCALARS/author/checkpoint/independent/states.tsv source-lineage/checkpoint/independent/
gzip -cd DENSE_BINARY_REDUCTION/branch128-binary-0-frontier.pkl.gz > source-lineage/row-cap-physical-slice-dense-binary-zero-fixed.pkl
read -r expected _ < DENSE_BINARY_REDUCTION/frontiers-uncompressed.sha256
actual=$(shasum -a 256 source-lineage/row-cap-physical-slice-dense-binary-zero-fixed.pkl | cut -d ' ' -f1)
test "$actual" = "$expected"
cd source-lineage
rc=0
/usr/bin/time -p python3 -u contract-second-cut-r2.py 0 > descendant00.out 2> descendant00.time || rc=$?
test "$rc" = 2
cmp descendant00.out "$root/DENSE_CONDITIONED_SCALARS/author/contract-second-cut-r2-0.out"
python3 -u quotient-nine-minimum.py > quotient.out
cmp quotient.out "$root/DENSE_CONDITIONED_SCALARS/author/quotient-nine-minimum.out"
shasum -a 256 -c "$root/descendant00-parent.sha256"
