#!/usr/bin/env bash
set -euo pipefail
root=$PWD
cd label-lineage
run() {
    local log=$1
    local expected=$2
    local rc=0
    shift 2
    /usr/bin/time -p python3 -u "$@" > "$log" 2> "$log.time" || rc=$?
    test "$rc" = "$expected"
}
run prepare-0.out 0 prepare-label-tuple.py 0
run prepare-1.out 0 prepare-label-tuple.py 1
cmp prepare-1.out "$root/DENSE_LARGER_TUPLES_RESTART/prepare-label-tuple-1.out"
run reduce-0a.out 0 reduce-label-frontier.py label-tuple-0-frontier.pkl 0a
cmp reduce-0a.out "$root/DENSE_LARGER_TUPLES_RESTART/worker-reduce-0a.out"
run contract-0a.out 2 contract-reduced-label.py 0a
cmp contract-0a.out accepted-local-contract-0a.out
(cd "$root" && shasum -a 256 -c local-cap-0a.sha256)
run reduce-0b.out 0 reduce-label-frontier.py join-cap-dense-label-0a-reduced.pkl 0b
cmp reduce-0b.out "$root/DENSE_LARGER_TUPLES_RESTART/reduce-label-0b.out"
run contract-0b.out 2 contract-reduced-label.py 0b
cmp contract-0b.out "$root/DENSE_LARGER_TUPLES_RESTART/contract-reduced-label-0b.out"
gzip -cd "$root/DENSE_LARGER_TUPLES_RESTART/tuple0-restart.pkl.gz" | cmp - join-cap-dense-label-0b-reduced.pkl
printf 'PASS descendant (0,0) nine factors to committed tuple 0 restart by byte identity\n'
run reduce-1a.out 0 reduce-label-frontier.py label-tuple-1-frontier.pkl 1a
cmp reduce-1a.out "$root/DENSE_LARGER_TUPLES_RESTART/reduce-label-1a.out"
run contract-1a.out 2 contract-reduced-label.py 1a
cmp contract-1a.out "$root/DENSE_LARGER_TUPLES_RESTART/contract-reduced-label-1a.out"
gzip -cd "$root/DENSE_LARGER_TUPLES_RESTART/tuple1-restart.pkl.gz" | cmp - join-cap-dense-label-1a-reduced.pkl
printf 'PASS descendant (0,0) nine factors to committed tuple 1 restart by byte identity\n'
