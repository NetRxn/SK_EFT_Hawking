# Independent exact recombination of group 128 descendant (0,0)

The six independently bound, normalized tuple contributions sum to
**-17865027341916851312184266649/2658455991569831745807614120560689152 + 0i**.

| Tuple | Normalized real |
|---|---:|
| 0 | -3421066796274305094734655/649037107316853453566312041152512 |
| 1 | -940520760199586648427969/649037107316853453566312041152512 |
| 2 | 761799400259723226207/2658455991569831745807614120560689152 |
| 3 | 341130692358955201725/166153499473114484112975882535043072 |
| 4 | 6319960913952819098631/332306998946228968225951765070086144 |
| 5 | -10493250771659057325/1298074214633706907132624082305024 |

Every tuple's imaginary component is zero. The exact raw Gaussian real
numerator at the common normalization is
-1482244082493055556862783865532395571652463030634345892423288225792.

The main archives are pinned to publication commit
b7e35f57067f9cc621cc781a3f01640cb05cf8fe. The committed complementary
45-term prefix is pinned to c6f7c8939b98f5bda1f8aeef455f85cfb2407dcd.
Each archive was read from its Git blob, matched its checkout bytes
and passed its archive or review manifest. Replaying the committed
binary parent lineage yields the exact nine-factor (0,0) descendant
with SHA256 d12720858ba57cc926148f42e4cc53aa999a82ca2ba796fb2438b33c95ff7a2a.
Independent support enumeration finds six feasible tuples among all
256 observed-domain combinations, a subset of the eight original
projected label assignments. All six roster row-count vectors agree.
The two large tuple selections and all remaining branch operands
preserve their label assignments, preceding representative selectors
and the common denominator product. The selected large tuple inverse
lifts and clean reduction traces reproduce both committed restarts.

Tuple 0's binary selector R(0,0,2,0,1) occurs in exactly two factor
scopes, with exhaustive support {0,1} at both incidences and 6,427,904
pair products per value. Both inverse lifts and complete binary
reduction and cap lineages verified. Independent histograms on the
respective reduced parents regenerate the same complete 48-coordinate
roster on G(0,4,2) and J(1,4,2), including ordering by count then key.
The first ledger comes from the committed FIRST_CHILD_CLOSURE archive.
The complementary ledger was reassembled from the committed prefix and
fresh exact raw and rational witness checks for all 27 slices of
final cases 45–47. All three complete independent review manifests
verified. Both 48-term sums equal
-3421066796274305094734655/1298074214633706907132624082305024.

All 48 ordered pairs of normalized real and imaginary values agree
coordinate by coordinate across selector 0 and selector 1. This
observed arithmetic equality covers the 48 cases of this tuple,
profile, group and descendant. The two row-cap operands differ
at ordered factor tables 0 and 1 and retain different binary
conditioning. The evidence establishes equality of these scalar
vectors. A factor-level equivalence or a general source symmetry
would require additional proof.

Tuple 1's binary selector R(0,3,0,1,0) covers both values at both
incidences and 5,318,656 products per value. The independent
reconstruction of both six-factor children reran byte-identically
against the committed equality receipt. Their complete signed factor
tables and denominators match. The rejected-pair histograms each give
36 cases over 6,838,272 products on G(0,0,2) and J(1,4,2); the full
36-entry committed child ledger matches this support. Its exact sum C
was added twice for the two disjoint binary assignments.

The archived operands and independent raw receipts for tuples 2–5
match the accepted (0,0) entries individually. Independent decoding
of the fixed source profile (503841882182,1461451755920) gives phase +1,
occupation degree 32, factorial factor 16 and Haar factor 4^64.
All terms carry the common factor denominator
40512224221827380280140849737629696 and the external normalization
1/(16*4^64) exactly once. Exact rational and common-scale integer
sums agree. The recombination uses the accepted ledger values and
independent receipts directly, with no further normalization, orbit
weight or chirality multiplicity.

This closes one descendant. The other contributions to group 128
and the full signed coefficient remain separate.
