#!/usr/bin/env bash
set -euo pipefail
root=$PWD
cd tuple0-lineage
/usr/bin/time -p python3 -u exact-cut.py tuple0-restart.pkl tuple0 > cut.out 2> cut.time
cmp cut.out "$root/LARGER_TUPLE_SEPARATOR/tuple0-plan.out"
for bit in 0 1; do
    tag=tuple0-$bit
    /usr/bin/time -p python3 -u reduce-label-frontier.py "$tag.pkl" "$tag" > "$tag-reduce.out" 2> "$tag-reduce.time"
    rc=0
    /usr/bin/time -p python3 -u contract-reduced-label.py "$tag" > "$tag-contract.out" 2> "$tag-contract.time" || rc=$?
    test "$rc" = 2
    cmp "$tag-contract.out" "$root/LARGER_TUPLE_SEPARATOR/$tag-contract.out"
    name=row-cap-physical-slice-dense-label-$tag-reduced.pkl
    gzip -cd "$root/LARGER_TUPLE_SEPARATOR/$name.gz" | cmp - "$name"
    printf 'PASS exact tuple0 selector %s full reduction and row-cap lineage by byte identity\n' "$bit"
done
