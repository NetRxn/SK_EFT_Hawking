# Reproduce the independent descendant (0,0) retally

Restore the source ZIPs from the commits and Git blob IDs in
SOURCE_PINS.txt, check archives.sha256 and extract each ZIP into the
directory named by the suffix between L1_N16_C0_ and _R1.zip.
Check the individual archive manifests. TUPLE1_CHILD_EQUALITY uses
review-manifest.sha256.

In clean scratch, run bash replay-parent-lineage.sh. Restore the
committed preparation, reduction and contraction scripts, roster and
quotient helper from DENSE_CONDITIONED_SCALARS into label-lineage/
as shown by replay-label-lineage.sh, then run that script. Restore
the first and second tuple 0 binary inputs by running
replay-tuple0-lineage.sh with the committed tuple 0 restart and archived
drivers in tuple0-lineage/. The recorded timings cover the actual
clean scratch replay. The recovered numerical operands are omitted
from the relative manifest because they can be reconstructed.

Restore restart.zip and separator.zip beside the archived tuple 1
equality driver, rerun it and compare the result with its committed
verify.out. Store the rerun at tuple1-equality-replay/verify.out.
Then run python3 recombine.py from the evidence root. It verifies
the final complementary review manifests and emits the exact six-tuple
ledger and the coordinate-wise comparison.
