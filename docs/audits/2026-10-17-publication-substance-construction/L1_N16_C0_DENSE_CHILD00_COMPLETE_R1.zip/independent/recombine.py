from ast import literal_eval
from collections import Counter,defaultdict
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from itertools import product
from math import factorial,prod
from pathlib import Path
import csv
import pickle
import re

root=Path(__file__).resolve().parent
selector00=[(('R',1,3,0,2,1),0),(('R',0,6,1,1,1),0)]
std_den=40512224221827380280140849737629696
split0=('R',0,0,2,0,1)
split1=('R',0,3,0,1,0)
axes0=(('G',0,4,2),('J',1,4,2))
axes1=(('G',0,0,2),('J',1,4,2))

def digest(data):
    return sha256(data).hexdigest()

def manifest(path):
    return {name.removeprefix('./'):h for h,name in (row.split(maxsplit=1) for row in path.read_text().splitlines())}

def verify_files(file,base):
    hashes=manifest(file)
    for name,h in hashes.items():
        rel=Path(name)
        assert not rel.is_absolute() and '..' not in rel.parts
        assert digest((base/rel).read_bytes())==h,name
    return len(hashes)

def loaded(group,name,inventory='frontiers-uncompressed.sha256'):
    directory=root/group
    hashes=manifest(directory/inventory)
    raw=decompress((directory/f'{name}.gz').read_bytes())
    assert digest(raw)==hashes[name],name
    return pickle.loads(raw)

def sum_complex(values):
    return tuple(sum(v, Fraction(0)) for v in zip(*values,strict=True))

def factor_den(state):
    return prod(d for _,_,d in state['factors'])

def roster_census(state, pair, axes):
    f=state['factors']
    assert all(n==2 for n in Counter(w for scope,_,_ in f for w in scope).values())
    left,right=(f[i] for i in pair)
    shared=tuple(sorted(set(left[0])&set(right[0])))
    lp=tuple(left[0].index(w) for w in shared)
    rp=tuple(right[0].index(w) for w in shared)
    cp=tuple(left[0].index(w) for w in axes)
    left_groups=Counter((tuple(r[p] for p in lp),tuple(r[p] for p in cp)) for r in left[1])
    right_groups=Counter(tuple(r[p] for p in rp) for r in right[1])
    result=Counter()
    for (key,cut),n in left_groups.items():
        matches=n*right_groups[key]
        if matches:
            result[cut]+=matches
    return result

def expect_identity(state,i,assign,extra=()):
    assert state['conditioning']==selector00+sorted(assign.items())+list(extra)
    assert state['label_partition']=={'index':i,'count':6,'values':assign}
    assert factor_den(state)==std_den

def inverse_lift(parent,child,fixed):
    for (scope,rows,d),(small,new,e) in zip(parent['factors'],child['factors'],strict=True):
        assert d==e and small==tuple(w for w in scope if w not in fixed)
        wanted={row:v for row,v in rows.items()
                if all(row[p]==fixed[w] for p,w in enumerate(scope) if w in fixed)}
        positions=tuple((-1,fixed[w]) if w in fixed else (small.index(w),None) for w in scope)
        recovered={tuple(value if p==-1 else row[p] for p,value in positions):v for row,v in new.items()}
        assert recovered==wanted and len(recovered)==len(new)
        assert len(set(small))==len(small)

def verify_binary(state,axis,pair,count):
    f=state['factors']
    assert tuple(i for i,(scope,_,_) in enumerate(f) if axis in scope)==pair
    for i in pair:
        scope,rows,_=f[i]
        p=scope.index(axis)
        assert {r[p] for r in rows}=={0,1}
    census=roster_census(state,pair,(axis,))
    assert census=={(0,):count,(1,):count}
    print('PASS binary selector',axis,'two disjoint incidences',pair,'matches per bit',count)

def verify_norm():
    occupation_types=tuple(o for o in product(range(5),repeat=3) if sum(o)<=4)
    codes=(503841882182,1461451755920)
    layers=[tuple(occupation_types[(code>>(6*j))&63] for j in range(8)) for code in codes]
    counts=tuple(n for layer in layers for site in layer for n in site)
    deg=sum(counts)
    world=sum((3+k)*n for layer in layers for site in layer for k,n in enumerate(site))
    edges=[(u,v,(u^v).bit_length()-1) for u in range(8) for v in range(u+1,8) if (u^v).bit_count()==1]
    edges.sort(key=lambda e:(e[0],e[2]))
    cross=0
    for layer in layers:
        for pos,(u,v,k) in enumerate(edges):
            weight=sum(layer[u])+sum(layer[v])-layer[u][k]-layer[v][k]
            for x,y,j in edges[pos+1:]:
                other=sum(layer[x])+sum(layer[y])-layer[x][j]-layer[y][j]
                cross+=weight*other*sum(a>b for a in (u,v) for b in (x,y))
    den=prod(map(factorial,counts))
    assert (world,cross,deg,den)==(136,444,32,16)
    assert (-1)**((world+cross)%2)==1
    print('PASS source normalization profile',codes,'degree',deg,'sign +1 external denominator 16 * 4^64')
    return std_den*den*4**(2*deg)

def raw_pair(values,scale):
    z=tuple(x*scale for x in values)
    assert all(x.denominator==1 for x in z)
    return tuple(x.numerator for x in z)

scale=verify_norm()
def check_raw_sum(parts):
    direct=sum_complex(parts)
    integers=tuple(sum(v) for v in zip(*(raw_pair(f,scale) for f in parts),strict=True))
    assert direct==tuple(Fraction(r,scale) for r in integers)
    return direct

source=root/'source-lineage'/'nine-minimum-quotient-frontier.pkl'
raw=source.read_bytes()
assert digest(raw)==(root/'descendant00-parent.sha256').read_text().split()[0]
source_state=pickle.loads(raw)
assert source_state['conditioning']==selector00 and factor_den(source_state)==std_den
f=source_state['factors']
assert len(f)==9
labels=sorted({w for scope,_,_ in f for w in scope if w[0]=='L'})
assert len(labels)==8
domains=defaultdict(set)
support=[]
for scope,rows,_ in f:
    local=tuple(w for w in labels if w in scope)
    positions=tuple(scope.index(w) for w in local)
    counts=Counter(tuple(r[p] for p in positions) for r in rows)
    support.append((local,counts))
    for key in counts:
        for w,v in zip(local,key,strict=True):
            domains[w].add(v)
all_count=0
feasible={}
for r in product(*(sorted(domains[w]) for w in labels)):
    all_count+=1
    assignment=dict(zip(labels,r,strict=True))
    ks=[counts[tuple(assignment[w] for w in scope)] for scope,counts in support]
    if all(ks):
        feasible[r]=ks
original=defaultdict(dict)
for line in (root/'DENSE_CONDITIONED_SCALARS/author/checkpoint/independent/states.tsv').read_text().splitlines():
    i,t,x,k,p,q=map(int,line.split())
    original[i][('L',t,x,k)]=(p,q)
original_set={tuple(row[w] for w in labels) for row in original.values()}
assert all_count==256 and len(original_set)==8 and len(feasible)==6 and feasible.keys()<=original_set
plans=literal_eval((root/'DENSE_CONDITIONED_SCALARS/author/label-partition-roster.txt').read_text())
assert [i for _,i,_,_ in plans]==list(range(6))
assert [tuple(a[w] for w in labels) for _,_,a,_ in plans]==list(feasible)
for count,i,assignment,rows in plans:
    assert rows==feasible[tuple(assignment[w] for w in labels)] and count==sum(rows)
    print('PASS projected label roster',i,count,rows)
print('PASS exhaustive label roster',all_count,'Cartesian candidate states, 8 original projected, 6 feasible')

restart=[]
for i in (0,1):
    assign=plans[i][2]
    label=pickle.loads((root/f'label-lineage/label-tuple-{i}-frontier.pkl').read_bytes())
    expect_identity(label,i,assign)
    inverse_lift(source_state,label,assign)
    print('PASS label inverse lift',i,plans[i][0])
    state=loaded('DENSE_LARGER_TUPLES_RESTART',f'tuple{i}-restart.pkl')
    expect_identity(state,i,assign)
    restart.append(state)

verify_binary(restart[0],split0,(0,1),6427904)
verify_binary(restart[1],split1,(3,6),5318656)
for bit in (0,1):
    raw_cut=pickle.loads((root/f'tuple0-lineage/tuple0-{bit}.pkl').read_bytes())
    expect_identity(raw_cut,0,plans[0][2],[(split0,bit)])
    inverse_lift(restart[0],raw_cut,{split0:bit})
    print('PASS exact inverse lift of tuple0 binary branch',bit)

t00=[loaded('LARGER_TUPLE_SEPARATOR',f'row-cap-physical-slice-dense-label-tuple0-{b}-reduced.pkl') for b in (0,1)]
t01=[loaded('LARGER_TUPLE_SEPARATOR',f'row-cap-physical-slice-dense-label-tuple1-{b}b-reduced.pkl') for b in (0,1)]
for bit in (0,1):
    expect_identity(t00[bit],0,plans[0][2],[(split0,bit)])
    expect_identity(t01[bit],1,plans[1][2],[(split1,bit)])
    assert len(t00[bit]['factors'])==8 and len(t01[bit]['factors'])==6
assert t00[0]['factors']!=t00[1]['factors']
mismatches=[i for i,(f0,f1) in enumerate(zip(t00[0]['factors'],t00[1]['factors'],strict=True)) if f0!=f1]
assert mismatches
print('tuple0 binary selector',split0,'values 0 and 1; differing ordered factor tables',mismatches)

assert t01[0]['factors']==t01[1]['factors']
equality=(root/'tuple1-equality-replay/verify.out').read_bytes()
assert equality==(root/'TUPLE1_CHILD_EQUALITY/verify.out').read_bytes()
assert equality.endswith(b'PASS identical signed six-factor contractions and normalization; disjoint full tuple1 contraction is 2 x either child\n')
print('PASS tuple0 binary factor tables differ; tuple1 binary six-factor tables agree by independent complete reconstruction')

cut_axes,entries=literal_eval((root/'LARGER_TUPLE_SEPARATOR/pilot.roster').read_text())
assert cut_axes==axes0 and len(entries)==len(dict(entries))==48
counts=dict(entries)
for bit,val in enumerate(t00):
    found=roster_census(val,val['rejected_pair'],axes0)
    assert found==counts and sum(found.values())==val['matched']==6427904
    print('PASS tuple0 child',bit,'full 48-coordinate support',axes0,'pair products',sum(found.values()))
order=sorted(counts,key=lambda c:(counts[c],c))

def read_outer(file,n,trailing):
    data={}
    header=None
    open_rows=0
    for line in file.read_text().splitlines():
        f=line.split('\t')
        if f[0].isdigit():
            i=int(f[0])
            assert i not in data and 0<=i<n
            if len(f)==5:
                assert literal_eval(f[1])==order[i]
                re_part,im_part=f[2:4]
            else:
                assert len(f)==3
                re_part,im_part=f[1:]
            data[i]=(Fraction(re_part),Fraction(im_part))
        elif f[0]=='PARTIAL SUM':
            assert header is None and int(f[1])==n
            header=tuple(map(Fraction,f[2:]))
        elif f[0]=='OPEN':
            assert f==['OPEN',trailing]
            open_rows+=1
        else:
            assert f[0]=='case' and len(f)==4
    assert open_rows==1
    assert set(data)==set(range(n)) and len({order[i] for i in data})==n
    assert check_raw_sum(list(data.values()))==header
    return data

assert verify_files(root/'complementary-inputs.sha256',root)==4
first=read_outer(root/'FIRST_CHILD_CLOSURE/partial-48.tsv',48,'')
prior=read_outer(root/'COMPLEMENTARY_CASES43_44/retally.tsv',45,'45,46,47')
supplied=read_outer(root/'complementary-retally.tsv',48,'')
assert all(supplied[i]==r for i,r in prior.items())
verified=prior.copy()
norm_pattern=r'^(?:independent )?exact normalized real (\S+) imaginary (\S+)(?: |$)'
raw_pattern=r'\braw (?:scalar numerator )?(-?\d+) (?:imaginary )?(-?\d+) factor denominator (\d+)'
for i in (45,46,47):
    pack=root/f'final-reviews/{i}'
    verified_files=verify_files(pack/'review/review-manifest.sha256',pack/'review')
    print('PASS exact portable complementary case review manifest',i,verified_files)
    audit=(pack/'review/audit.out').read_text()
    assert f'PASS exact inverse lift {order[i]}' in audit
    assert f'pilot {order[i]} matched {counts[order[i]]} ' in (pack/'plan.out').read_text()
    axes,inner=literal_eval((pack/'slice-0.roster').read_text())
    assert axes==(('G',0,1,2),) and len(inner)==len(dict(inner))==9 and sum(n for _,n in inner)==2280960
    inner.sort(key=lambda x:(x[1],x[0]))
    ledger=(pack/f'author-case{i}.tsv').read_text().splitlines()
    assert len(ledger)==10
    terms=[]
    for k,line in enumerate(ledger[:-1]):
        j,v,work,re_part,im_part,_=line.split('\t')
        assert int(j)==k and inner[k]==((int(v),),int(work))
        paths=list((pack/'review').glob(f'slice-{k}-*-replay.out'))+list((pack/'review/replays').glob(f'{k}-replay.out'))
        seen=[]
        for path in paths:
            text=path.read_text()
            norm=re.search(norm_pattern,text,re.M)
            if not norm:
                continue
            r,b,d=map(int,re.search(raw_pattern,text).groups())
            assert d==std_den
            value=tuple(map(Fraction,norm.groups()))
            assert value==tuple(map(Fraction,(re_part,im_part))) and raw_pair(value,scale)==(r,b)
            seen.append(value)
        assert seen and len(set(seen))==1
        terms.append(seen[0])
    result=check_raw_sum(terms)
    assert ledger[-1].split('\t')==['sum',*map(str,result)]
    assert result==supplied[i]
    verified[i]=result
    print('PASS independent last complementary nine-term recombination',i,order[i],*result)
assert len(verified)==48 and verified==supplied
compare=[(order[i],first[i],verified[i]) for i in range(48)]
assert all(a==b for _,a,b in compare)
with (root/'tuple0-vector-comparison.tsv').open('w') as out:
    print('index','canonical_coordinate','selector_0_real','selector_0_imaginary','selector_1_real','selector_1_imaginary',sep='\t',file=out)
    for i,(coord,a,b) in enumerate(compare):
        print(i,repr(coord),*a,*b,sep='\t',file=out)
print('PASS equality of all 48 complete complex scalar pairs by canonical coordinates; distinct tensor operands')
a=check_raw_sum(list(first.values()))
b=check_raw_sum(list(verified.values()))
v0=check_raw_sum([a,b])

t1_counts=roster_census(t01[0],t01[0]['rejected_pair'],axes1)
assert t1_counts==roster_census(t01[1],t01[1]['rejected_pair'],axes1)
assert len(t1_counts)==36 and sum(t1_counts.values())==6838272
t1_order=sorted(t1_counts,key=lambda r:(t1_counts[r],r))
ledger1=list(csv.DictReader((root/'TUPLE1_COMPLETE/complete-ledger.tsv').open(),delimiter='\t'))
assert len(ledger1)==38
terms=[]
for i,row in enumerate(ledger1[:36]):
    assert row['kind']=='term' and int(row['index'])==i
    coordinate=int(row['G(0,0,2)']),(int(row['J(1,4,2)']),)
    assert coordinate==t1_order[i] and int(row['pair_products'])==t1_counts[coordinate]
    terms.append((Fraction(row['normalized_real']),Fraction(row['normalized_imaginary'])))
C=check_raw_sum(terms)
v1=check_raw_sum([C,C])
for row,kind,line in zip(ledger1[-2:],('shared-child-C','tuple1-2C'),(C,v1),strict=True):
    assert row['kind']==kind and (Fraction(row['normalized_real']),Fraction(row['normalized_imaginary']))==line
print('PASS tuple1 distinct binary children after verified factor equality',axes1,36,6838272,'C',*C,'2C',*v1)

fixed={0:v0,1:v1}
replay_names={2:'replay-tuple2.out',3:'replay-tuple3.out',4:'replay-tuple4.out',5:'replay-selected-five.out'}
table=list(csv.DictReader((root/'DENSE_CONDITIONED_SCALARS/accepted-conditioned-values.tsv').open(),delimiter='\t'))
for row in table:
    if row['internal_conditioning']!='0,0':
        continue
    i=int(row['label_tuple'])
    assert i in replay_names and i not in fixed
    state=loaded('DENSE_CONDITIONED_SCALARS',f'scalar-inputs/tuple{i}.pkl','scalar-inputs-uncompressed.sha256')
    expect_identity(state,i,plans[i][2])
    receipt=(root/'DENSE_CONDITIONED_SCALARS/independent'/replay_names[i]).read_text()
    assert f"conditioning {state['conditioning']} label partition {state['label_partition']}" in receipt
    value=Fraction(row['real']),Fraction(row['imaginary'])
    p,q,d=map(int,re.search(raw_pattern,receipt).groups())
    assert d==std_den and raw_pair(value,scale)==(p,q)
    assert tuple(map(Fraction,re.search(norm_pattern,receipt,re.M).groups()))==value
    fixed[i]=value
assert set(fixed)==set(range(6))
with (root/'descendant00-independent.tsv').open('w') as out:
    print('tuple','normalized_real','normalized_imaginary',sep='\t',file=out)
    for i in range(6):
        print(i,*fixed[i],sep='\t',file=out)
    ans=check_raw_sum([fixed[i] for i in range(6)])
    print('sum',*ans,sep='\t',file=out)
print('PASS exact tuple0 children and sum',*a,*b,*v0)
print('PASS exact descendant (0,0) six-tuple scalar',*ans,'raw Gaussian numerator',*raw_pair(ans,scale))
