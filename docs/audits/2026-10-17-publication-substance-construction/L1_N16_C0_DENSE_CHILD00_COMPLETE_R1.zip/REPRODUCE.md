# Complementary tuple 0 cut and dense profile pilot

The per-outer-case reviews name the frozen source and original selector-1
input. Rebuild each outer cut, nine inner cuts, inverse lifts and all saved
frontiers from those source pins. Replay triangles 2 and 3 and four-factor
slices 7 and 8 against their individual shard receipts. Use only trusted
serialized inputs.

Compare preceding-forty-five.tsv against the prior checkpoint's
retally.tsv. Run python3 verify-and-retally.py for the
independent signed arithmetic and cumulative result.

The complete complementary ledger contains all 48 normalized terms.
Run retally-descendant.py with the owning audit directory and retally.tsv
to recombine the two tuple 0 children, the accepted doubled tuple 1 child
and the existing exact tuples 2 to 5 of descendant (0,0).
Check both real and imaginary parts against descendant00.tsv.
These entries already include the external 1/(16*4^64) normalization.
