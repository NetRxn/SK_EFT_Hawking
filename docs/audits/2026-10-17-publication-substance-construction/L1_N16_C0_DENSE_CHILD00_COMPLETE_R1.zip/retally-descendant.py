from fractions import Fraction
from pathlib import Path
import argparse
from zipfile import ZipFile

parser = argparse.ArgumentParser()
parser.add_argument('audit_dir', type=Path)
parser.add_argument('complete_complementary', type=Path)
args = parser.parse_args()

def read_member(name, path):
    with ZipFile(args.audit_dir / name) as z:
        return z.read(path).decode()

def complete_roster(data, real_index, imag_index):
    entries = {}
    footer = None
    for line in data.splitlines():
        fields = line.split('\t')
        if fields[0].isdigit():
            index = int(fields[0])
            assert index not in entries
            entries[index] = Fraction(fields[real_index]), Fraction(fields[imag_index])
        if fields[0] == 'PARTIAL SUM':
            footer = fields
        if fields[0] == 'OPEN':
            assert fields[1:] in ([], [''])
    assert set(entries) == set(range(48))
    total = tuple(map(sum, zip(*entries.values())))
    assert footer == ['PARTIAL SUM', '48', *map(str,total)]
    return total

def add(*pairs):
    return tuple(map(sum, zip(*pairs)))

first = read_member('L1_N16_C0_FIRST_CHILD_CLOSURE_R1.zip', 'partial-48.tsv')
second = args.complete_complementary.read_text()
tuple0 = add(complete_roster(first,2,3), complete_roster(second,1,2))
ledger = read_member('L1_N16_C0_TUPLE1_COMPLETE_R1.zip','complete-ledger.tsv')
shared, doubled = [tuple(map(Fraction,line.split('\t')[5:7])) for line in ledger.splitlines()[-2:]]
assert add(shared,shared) == doubled
raw = read_member('L1_N16_C0_DENSE_CONDITIONED_SCALARS_R1.zip','accepted-conditioned-values.tsv')
tuples = {0: tuple0, 1: doubled}
for line in raw.splitlines()[1:]:
    child,index,real,imaginary,_ = line.split('\t')
    if child != '0,0':
        continue
    index = int(index)
    assert index not in tuples
    tuples[index] = Fraction(real), Fraction(imaginary)
assert set(tuples) == set(range(6))
for index in range(6):
    print('tuple',index,*tuples[index],sep='\t')
print('group128 descendant (0,0)',*add(*tuples.values()),sep='\t')
