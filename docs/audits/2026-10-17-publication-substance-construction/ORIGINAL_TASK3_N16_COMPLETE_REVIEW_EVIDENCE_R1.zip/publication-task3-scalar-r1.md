# Original N16 raw scalar/contact scratch implementation

The original assignment packet initially matched the combined candidate
on parent 043896cf. Removing the two fragments from scratch reproduced
the packet's exact source and test bytes. The final check reports the
expected owned-files and source staleness after ROOT's R2 checkpoint.
The initial assignment was not refreshed. Recomposition against clean
34d14897 passed a read-only apply check. Only formulas and coefficient-jet
tests change. The code calls ROOT's accepted shared N16 admission helper.
Bounded tests use local functions directly, with no helper shim needed.

- Original candidate patch: /tmp/publication-task3-scalar-r1.diff,
  SHA256 37fbfbaac1bd6d6e9b0eddd4546361e8910afdb6f514503d3fed3e99e501c4a2.
- Recomposition patch: /tmp/publication-task3-scalar-r1.recomposition.diff,
  SHA256 f9e6d3aa505501f485fa45cc178cc20127ef5f6b29d053e20fa7b24ee0835396.
- Independent insert fragments: /tmp/publication-task3-scalar-r1.formulas.fragment
  and /tmp/publication-task3-scalar-r1.tests.fragment.

The producer compares complete direct and independent auxiliary edge
outputs before using the direct coefficients. The comparison covers
both literal tables, both dual tables, basis labels and pairing,
radial moments and the fourth moment. The slow scientific test includes
all table oracles and the auxiliary minor and zero-support counts.

The raw reconstruction validates original based curvature anchors
against the geometric roster and actual plaquette order, checks both
curvature channels are independent and preserves both ordered coframe
terms. It constructs an exact symbolic Haar holonomy with both chiral
factors, computes the first and second moments of the entire ordered
vertex and checks the two independent single-vertex means for the
complete diagonal zero. Temporal TT is integrated from the original
symbolic coframes at both endpoints, with both independent anchors.
Projection verifies reconstruction of every exterior monomial in the
existing invariant basis. Contracting the entire curvature covariance
against this temporal TT retains the negative off-diagonal area term.
The two squared mixed curvature factors, with the exact geometric
exponential weight applied once, are sewn on the actual spatial and
temporal edges. The square enumerates both signed chirality sectors.
The reverse result uses the translated geometric roster and swaps the
active spatial cubic. The spectator fourth factors multiply the core.

The first temporal numerators are zero by empty original support.
Both mixed literal contacts require unit action and the exact active
anchors. The raw results retain symbolic g2. The complete interacting
Z and normalized result are both UNKNOWN. Formal correspondence,
full-Z construction, physical and publication acceptance remain open.

The bounded curvature and temporal controls initially failed for
missing helpers, then passed. The final bounded controls passed three
tests in 8.11 seconds. They verify the full signed covariance trace,
representative temporal basis entries, both signed sector totals,
and rejection of an omitted original curvature anchor. The exact
slow selector collected one test without execution:
tests/test_original_coefficient_jets.py::test_full_original_f60_g52_and_contacts.
The slow test checks both raw mixed directions, diagonal and both first
temporal zeros, both mixed contacts, homogeneity and resource ceilings.
No complete producer, auxiliary table, N16 or original one-site run
was performed. No checkout or Git mutation occurred. Actual bounded
full-run costs and a scoped scientific result require ROOT's review
and runtime admission.

Receipts: /tmp/publication-task3-scalar-r1.red.log,
 /tmp/publication-task3-scalar-r1.green-final.log,
 /tmp/publication-task3-scalar-r1.collect.log,
 /tmp/publication-task3-scalar-r1.final.json.
