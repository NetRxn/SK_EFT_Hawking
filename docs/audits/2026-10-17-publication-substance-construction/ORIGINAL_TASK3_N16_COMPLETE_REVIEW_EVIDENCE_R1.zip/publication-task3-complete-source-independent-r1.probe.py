from fractions import Fraction as F
from itertools import product
from src.core import formulas as f
from src.vestigial import original_coefficients as o

Q=o.QComplex
def times(m, scalar): return tuple(tuple(x*scalar for x in row) for row in m)
def transpose(m): return tuple(zip(*m,strict=True))
def mul(a,b):
    return tuple(tuple(sum((v*w for v,w in zip(row,col,strict=True)),Q()) for col in transpose(b)) for row in a)
def trace_by_half(a, G, t_y, b, t_x):
    chain=mul(mul(mul(mul(mul(mul(mul(a,G),t_y),G),transpose(b)),G),transpose(t_x)),G)
    return tuple(sum((chain[i][i] for i in half),Q()) for half in (range(3),range(3,6)))

for convention,axis in [('source_C',1),('metric_M',2)]:
    reg=o.OriginalRegulator(convention=convention)
    x=reg.sites[0]
    geo=f.original_metric_sewing_support(reg,x,axis)
    orders=[]
    active={(site,axis) for site in reg.sites} | {(site,reg.temporal_axis) for site in geo['core']}
    for case in ('diagonal','mixed_fg','mixed_gf'):
        for support in geo['cases'][case]['supports']:
            extracted=f._original_sewing_curvature_orders(reg,axis,support,active)
            orders.extend(order for _,order in extracted)
    assert len(orders)==8 and len(set(orders))==1
    with o.ExactBudget(1_000_000,512*1024**2) as b:
        d=f.original_direct_polar_edge(reg,axis,budget=b)
        mean, cov=f._original_sewing_curvature_moments(reg,axis,orders[0],b)
        assert all(z==Q(0) for z in mean.values())
        for a,j,c,l in product(range(4),repeat=4):
            assert cov[a,j,c,l]==Q(2*(int(a==c and j==l)-int(a==l and j==c)))
        assert f._original_sewing_spatial_factor(cov)==Q(6)
        # Remove the exchange term that produces -Q_0i^2.
        poison_cov={(a,j,c,l):Q(2*int(a==c and j==l)) for a,j,c,l in product(range(4),repeat=4)}
        assert f._original_sewing_spatial_factor(poison_cov)==Q(8)
        labels,G,T=f._original_sewing_temporal_covariance(reg,b)
        exact_T=tuple(tuple(Q(F(((1,0,0),(0,0,-2),(0,-2,0))[a%3][j%3],8)) if a//3!=j//3 else Q(0)
                            for j in range(6)) for a in range(6))
        assert T==exact_T and G==d.local_pairing and labels==d.labels
        for case,S0,S1 in [('mixed_fg',d.cubic_mixed,d.cubic_x),('mixed_gf',d.cubic_x,d.cubic_mixed)]:
            weight=geo['cases'][case]['supports'][0]['exponential_weight']
            t=times(T,Q(6))
            lr=tuple(v for _,v in f._original_sewing_square(labels,G,S0,S1,t,t))
            assert lr==trace_by_half(S0,G,t,S1,t)==(Q(3645),Q(3645))
            good=sum(lr,Q())*weight
            assert good==Q(F(3645,2))
            assert lr[0]*weight==good*F(1,2)
            assert sum(lr,Q())==good*4
            wrong_t=times(T,Q(8))
            wrong=tuple(v for _,v in f._original_sewing_square(labels,G,S0,S1,wrong_t,wrong_t))
            assert sum(wrong,Q())*weight==Q(3240)
        contact=times(T,Q(4))
        lr=tuple(v for _,v in f._original_sewing_square(labels,G,d.cubic_x,d.cubic_x,contact,contact))
        assert lr==trace_by_half(d.cubic_x,G,contact,d.cubic_x,contact)==(Q(F(6075,4)),Q(F(6075,4)))
    print(convention, 'all 256 covariance entries, temporal table, both directed mixed trace contractions, both chirality sectors and all three bounded value poisons; products',b.products)
