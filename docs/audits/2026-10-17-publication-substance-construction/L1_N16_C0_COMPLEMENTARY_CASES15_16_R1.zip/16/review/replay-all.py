from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

authors = {16: Path('/private/tmp/l1-c0-sibling-cases12-17.BlthJ1/tuple0-1/16')}
jobs = []
for case in (16,):
    author = authors[case]
    for line in (author/f'author-case{case}.tsv').read_text().splitlines():
        if line.startswith('sum\t'):
            continue
        index, axis, count, real, imaginary, receipt = line.split('\t')
        i = int(index)
        tag = receipt.removesuffix('-contract.out')
        path = author/f'label-{tag}-reduced-frontier.pkl'
        jobs.append((case, i, path, receipt, 'terminal'))
        if i in (4, 5):
            snapshot = author/f'post-quotient-slice-{i}.pkl'
            if snapshot.exists():
                jobs.append((case, i, snapshot, receipt, 'capture'))

def run(job):
    case, i, path, receipt, mode = job
    outpath = Path(f'slice-{i}-{mode}-replay.out')
    program = 'sparse-support-replay.py' if i in (4, 5) and mode=='terminal' else 'sparse-replay.py'
    with outpath.open('xb') as out:
        p = subprocess.run([sys.executable,'-u',program,str(i),mode,
                            str(path),str(authors[case]/receipt)],
                           stdout=out,stderr=subprocess.STDOUT,timeout=50)
    return case, i, mode, p.returncode

with ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(run,jobs):
        print(*result,sep='\t',flush=True)
        assert result[-1]==0
