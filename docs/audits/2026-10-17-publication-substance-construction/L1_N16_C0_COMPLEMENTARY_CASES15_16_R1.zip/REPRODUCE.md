# Complementary tuple 0 child cases 15 and 16

Restore the complementary parent from the separator archive pinned in
each review's SOURCE_PINS.txt. Recreate each outer cut with its case
index, then apply the primary and rescue reductions using that case's
archived author drivers. The seven-factor row-cap rescue checkpoint is
the input to run-primary.py. Follow it with reduce-open.py for inner
indices 0–8 and sum-caseN.py for the corresponding outer case index.
Verify the frontier hashes. Deserialize only trusted checkpoints.

The independent evidence verifies the outer and inner cuts, all ten
inverse lifts per case, exact cap lineage and terminal replays. Compare
preceding-fifteen.tsv to fifteen-term-retally.tsv from the committed
cases 13–14 archive. Run python3 verify-and-retally.py to reconcile each
of the eighteen inner values and the 17/48 cumulative sum.
