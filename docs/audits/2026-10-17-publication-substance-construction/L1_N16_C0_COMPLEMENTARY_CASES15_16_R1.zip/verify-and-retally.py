from fractions import Fraction
from pathlib import Path
from ast import literal_eval
import re

root=Path(__file__).resolve().parent

def checked_case(n):
    author=root/str(n)/'author'
    review=root/str(n)/'review'
    axes, roster=literal_eval((author/'slice-0.roster').read_text())
    assert axes==(('G',0,1,2),) and len(roster)==len(dict(roster))==9
    assert sum(n for _,n in roster)==1_021_248
    ordered=sorted(roster,key=lambda x:(x[1],x[0]))
    rows=[line.split('\t') for line in (author/f'author-case{n}.tsv').read_text().splitlines()]
    assert len(rows)==10
    total=[Fraction(),Fraction()]
    normalized=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
    raw=re.compile(r'raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)')
    for i,(index,key,products,x,y,receipt) in enumerate(rows[:-1]):
        assert int(index)==i and ((int(key),),int(products))==ordered[i]
        out=(review/f'slice-{i}-terminal-replay.out').read_text()
        a,b,d=map(int,raw.search(out).groups())
        values=Fraction(a,d*16*4**64),Fraction(b,d*16*4**64)
        assert values==tuple(map(Fraction,normalized.search(out).groups()))
        assert values==tuple(map(Fraction,normalized.search((author/receipt).read_text()).groups()))
        assert values==(Fraction(x),Fraction(y))
        for k,value in enumerate(values):
            total[k]+=value
    print('case',n,*total,sep='\t')
    assert rows[-1]==['sum',*map(str,total)]
    return tuple(total)

cases={}
for line in (root/'preceding-fifteen.tsv').read_text().splitlines():
    fields=line.split('\t')
    if fields[0].isdigit():
        i,x,y=fields
        assert int(i) not in cases
        cases[int(i)]=(Fraction(x),Fraction(y))
assert set(cases)==set(range(15))
for n in (15,16):
    cases[n]=checked_case(n)
assert set(cases)==set(range(17))
for i, (x,y) in sorted(cases.items()):
    print(i,x,y,sep='\t')
print('PARTIAL SUM',len(cases),*map(sum,zip(*cases.values())),sep='\t')
