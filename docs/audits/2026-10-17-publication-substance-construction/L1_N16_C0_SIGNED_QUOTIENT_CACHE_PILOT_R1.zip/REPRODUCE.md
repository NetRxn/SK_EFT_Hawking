# Bounded exact signed quotient-reuse experiment

The existing signed quotient runs with the original direction order.
The bounded memo key records the ordered immutable input table identities
and exactly the shared axes that are closed for that direction.
The exact closure rule preserves the physical and label boundaries.
The pilot owns the signed table dictionaries exclusively and exposes
them in read-only views. A caller retaining a mutable backing-dictionary
alias would invalidate the identity key. Both complete two-sweep outputs
are compared with the uncached operands pinned in the receipt.

Provide the pinned original plan, cut-axis list, block index and schema
from the previous dense-reuse pilot. Run the small controls in
quotient-pilot with Python 3. The paired run also needs the original
compiled inputs. The two baseline frontier paths are set in quotient-cache.py.
The reproduced check compares all 88 signed tables, axes and denominators
in each group. Timings are observed durations, and cache hit counts
apply to this row bound, policy, traversal and the tested groups.

The separate Group 934 assignment-4 experiment uses the pinned
Group 934 prepared original factor state. The label roster covers
the original eight assignments. The recorded assignments and operands
under group934-L4 belong only to the signed raw calculation for
assignment 4. The full group prefactor and total lie outside this record.

Run first-touch.py and first-touch-batch.py with the same plan, schema,
cut axes, block index, and original compiled sources. Those checks
derive the untouched pairs from the original order and run both directed
quotients on each exact class. They stream output shapes and counts.
The batch results are separate from measured bounded-cache hits.
