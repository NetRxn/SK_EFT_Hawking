from collections import OrderedDict
from itertools import combinations, count

from pathlib import Path
exec(Path("original-input.py").read_text())

serial = count()
input_ids = {}
memo = OrderedDict()
cache_rows = 0
max_cache_rows = 2_000_000

def wrap(factor):
    axes, rows, denominator = factor
    return next(serial), (axes, MappingProxyType(rows) if isinstance(rows, dict) else rows, denominator)

def tag_input(factor):
    # Original input assembly retains each published raw table object in its cache.
    if id(factor) not in input_ids:
        input_ids[id(factor)] = wrap(factor)
    return input_ids[id(factor)]

def step(left, right, degrees):
    global cache_rows
    a, x = left
    b, y = right
    # These are the only degree queries in the unchanged quotient.
    closed = tuple(axis for axis in x[0] if axis[0] != "L" and axis in y[0] and degrees[axis] == 2)
    key = (a,b,closed)
    weight = len(x[1])+len(y[1])
    if key in memo:
        result, _ = memo[key]
        memo.move_to_end(key)
        return result, weight
    u,v,_ = quotient(x,y,degrees)
    lu = left if u is x else wrap(u)
    rv = right if v is y else wrap(v)
    payload = (lu,rv)
    rows = sum(len(r[1][1]) for r in payload)
    if rows <= max_cache_rows:
        while cache_rows+rows > max_cache_rows:
            _,(_,removed) = memo.popitem(last=False)
            cache_rows -= removed
        memo[key] = payload,rows
        cache_rows += rows
    return payload,0

def check_group(group, baseline):
    with baseline.open("rb") as file:
        baseline_hash = file_digest(file,"sha256").hexdigest()
        file.seek(0)
        pinned=pickle.load(file)
    assert pinned["branch"]==group
    raw, loads, saved, load_time = source_group(group)
    degree = Counter(axis for scope, _, _ in raw for axis in scope)
    assert sum(axis[0]!="L" for axis in degree)==424
    assert set(n for axis,n in degree.items() if axis[0]!="L")=={2}
    links = [(i,j) for i,j in combinations(range(len(raw)),2)
             if any(axis[0]!="L" and axis in raw[j][0] for axis in raw[i][0])]
    start = perf_counter()
    work=skipped=hits=operations=0
    f = [tag_input(x) for x in raw]
    for _ in range(2):
        for i,j in links:
            for a,b in ((i,j),(j,i)):
                operations += 1
                work += len(f[a][1][1])+len(f[b][1][1])
                assert work <= 60_000_000
                (f[a], f[b]), avoided = step(f[a],f[b],degree)
                hits += bool(avoided)
                skipped += avoided
        assert all(factor[1][1] for factor in f)
    assert [factor for _,factor in f] == pinned["factors"]
    print("exact sweep replay",group,"baseline",baseline_hash,"input load seconds",round(load_time,6),
          "quotient seconds",round(perf_counter()-start,6),"calls",operations,"hits",hits,
          "input row visits",work,"cached row visits",skipped,"cached payload rows",cache_rows,
          "signed tables reproduced",len(f),"peak RSS bytes",getrusage(RUSAGE_SELF).ru_maxrss,flush=True)

def main():
    check_group(672,Path("/private/tmp/l1-dense-group672.EF30g6/corrected/dense-saturated-frontier.pkl"))
    check_group(934,Path("/private/tmp/l1-dense-group934-pilot.8QVoGy/dense-saturated-frontier.pkl"))

if __name__=="__main__":
    main()
