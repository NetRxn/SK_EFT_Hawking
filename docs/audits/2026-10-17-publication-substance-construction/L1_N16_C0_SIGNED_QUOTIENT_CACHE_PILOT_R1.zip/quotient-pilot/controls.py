from pathlib import Path
from runpy import run_path
from collections import Counter
s = run_path("quotient-cache.py")
wrap,step = s["wrap"],s["step"]
memo = s["memo"]
u,p,x = ("L",0),("G",0),("W",0)
a = wrap(((u,p,x), {(0,1,2):(2,0),(0,2,2):(0,4),(1,1,2):(2,0)}, 1))
b = wrap(((u,p), {(0,1):(3,0),(0,2):(5,0),(1,1):(7,0)}, 1))
closed = Counter({u:3,p:2,x:1})
open_ = Counter({u:3,p:3,x:1})
modified,c0 = step(a,b,closed)
untouched,c1 = step(a,b,open_)
assert c0==c1==0 and modified!=untouched and untouched==(a,b)
assert step(a,b,closed)==(modified,6)
assert step(a,b,open_)==(untouched,6)
assert len(memo)==2
changed = wrap((a[1][0], {**a[1][1],(0,2,2):(0,-4)}, a[1][2]))
assert step(changed,b,closed)[1]==0
assert step(b,a,closed)[1]==0
try:
    a[1][1][(0,2,2)]=(0,9)
except TypeError:
    pass
else:
    raise AssertionError("tagged input table is writable")
print("closed vs externally retained shared axis distinct; signed edit, reversed direction and read-only table controls pass")
