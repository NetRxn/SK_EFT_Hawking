from ast import literal_eval
from collections import Counter, defaultdict
from hashlib import file_digest
from math import lcm
from pathlib import Path
from time import perf_counter
from resource import RUSAGE_SELF, getrusage
from types import MappingProxyType
import pickle

schema = {}
for line in Path("schema.tsv").read_text().splitlines():
    name, labels, physical, _, _, denominator = line.split("\t")
    schema[name] = (literal_eval(labels), literal_eval(physical), int(denominator))
blocks = []
for line in Path("block-index.tsv").read_text().splitlines():
    name, key, start, size, rows, denominator = line.split("\t")
    blocks.append((name, literal_eval(key), *map(int, (start, size, rows, denominator))))
cut = literal_eval(Path("cut-axes.tsv").read_text())
cache = {}
digest = {}
quotient_text = Path("quotient.py").read_text().split("\nlocal_test()\n",1)[0]
exec(quotient_text)

def assemble(name, indices, keep):
    labels, physical, _ = schema[name]
    tables = [blocks[index] for index in indices]
    d = lcm(*(table[-1] for table in tables))
    coefficients = {}
    with Path(f"compiled/{name}.blocks").open("rb") as source:
        for family, key, offset, size, count, den in tables:
            assert family == name
            source.seek(offset)
            known, layout, denominator, rows = pickle.load(source)
            assert (known, denominator, len(rows), source.tell()) == (key, den, count, offset+size)
            extract = [layout.index(c) if c in layout else None for c in physical]
            tag = tuple(key[i] for i in keep)
            scale = d//den
            for row, (real, imag) in rows.items():
                dest = tag+tuple(row[i] if i is not None else 0 for i in extract)
                assert dest not in coefficients
                coefficients[dest] = real*scale, imag*scale
    assert len(coefficients) == sum(block[4] for block in tables)
    return tuple(labels[i] for i in keep)+physical, MappingProxyType(coefficients), d

def source_group(group):
    line = next(line for line in Path("cut-plan.tsv").read_text().splitlines() if line.startswith(f"{group}\t"))
    _, _, expected, _, labels, indices = line.split("\t")
    selected = dict(zip(cut, literal_eval(labels), strict=True))
    use = defaultdict(list)
    for i in literal_eval(indices):
        name, key, *_ = blocks[i]
        assert all(v==selected[w] for w,v in zip(schema[name][0],key) if w in selected)
        use[name].append(i)
    start = perf_counter()
    f = []
    saved = loads = 0
    for family, indexes in sorted(use.items()):
        retain = tuple(i for i,w in enumerate(schema[family][0]) if w not in selected)
        key = family, tuple(indexes), retain
        if key in cache:
            saved += len(cache[key][1])
        else:
            cache[key] = assemble(*key)
            loads += 1
        f.append(cache[key])
    assert len(f)==88 and sum(len(rows) for _,rows,_ in f)==int(expected)
    return f, loads, saved, perf_counter()-start

