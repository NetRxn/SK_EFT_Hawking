from ast import literal_eval
from collections import defaultdict
from hashlib import sha256
from itertools import combinations
from pathlib import Path

def read(name, expected=None):
    raw = Path(name).read_bytes()
    if expected is not None:
        assert sha256(raw).hexdigest()==expected
    return raw.decode()

cut = set(literal_eval(read("cut-axes.tsv")))
scope = {}
for line in read("schema.tsv").splitlines():
    family, labels, physical, *_ = line.split("\t")
    scope[family] = set(literal_eval(labels)+literal_eval(physical))-cut
blocks = [line.split("\t")[0] for line in read("block-index.tsv",
    "fcc47845f3e81de9f67fb593a4d53470a7ffddf876c512dbf0951433d7bb7f16").splitlines()]
selection = {}
for line in read("cut-plan.tsv",
    "28b9a0879fad79733a1ef85521b1c871841fd21714c461fba5ddf0438478ce2d").splitlines():
    group,*_,encoded = line.split("\t")
    if group not in ("672","934"):
        continue
    by_family = defaultdict(list)
    for index in literal_eval(encoded):
        by_family[blocks[index]].append(index)
    selection[group] = by_family
stable = {name for name in scope if selection["672"][name]==selection["934"][name]}
links = [(a,b) for a,b in combinations(sorted(scope),2) if any(w[0]!="L" for w in scope[a]&scope[b])]
stable_links = {(a,b) for a,b in links if a in stable and b in stable}
first = set()
seen = set()
for a,b in links:
    if a not in seen and b not in seen:
        first.add((a,b))
    seen.update((a,b))
print("shared raw families",len(stable),"shared raw pair links",len(stable_links),"out of",len(links))
print("both operands untouched",len(first),"shared among them",len(first&stable_links))
