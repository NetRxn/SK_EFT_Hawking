from collections import Counter, defaultdict
from pathlib import Path
from resource import RUSAGE_SELF, getrusage
from runpy import run_path
from time import perf_counter

loader = run_path("original-input.py")
topology = run_path(Path(__file__).with_name("first-touch.py"))
schema,cut = loader["schema"],set(loader["cut"])
blocks=loader["blocks"]
assemble, quotient = loader["assemble"],loader["quotient"]

ports = topology["scope"]
degrees = Counter(axis for scope in ports.values() for axis in scope)
first = sorted(topology["first"])
classes = {pair:Counter() for pair in first}
for line in Path("cut-plan.tsv").read_text().splitlines():
    by_family = defaultdict(list)
    for index in loader["literal_eval"](line.split("\t")[-1]):
        by_family[blocks[index][0]].append(index)
    for a,b in first:
        classes[a,b][tuple(by_family[a]),tuple(by_family[b])] += 1

def load(family, ids):
    labels,_,_ = schema[family]
    kept = tuple(i for i,axis in enumerate(labels) if axis not in cut)
    return assemble(family,ids,kept)

total_reference_rows = total_unique_rows = total_payload_rows = max_payload_rows = 0
start=perf_counter()
for (a,b), pairs in sorted(classes.items()):
    ref_rows = unique_rows = payload_rows = 0
    for (left,right), occurrences in sorted(pairs.items()):
        X,Y = load(a,left),load(b,right)
        before=len(X[1])+len(Y[1])
        x,y,_=quotient(X,Y,degrees)
        y,x,_=quotient(y,x,degrees)
        size=len(x[1])+len(y[1])
        assert set(X[0])==set(x[0]) and set(Y[0])==set(y[0])
        assert X[2]==x[2] and Y[2]==y[2]
        ref_rows += occurrences * before
        unique_rows += before
        payload_rows += size
        max_payload_rows=max(max_payload_rows,size)
    assert sum(pairs.values())==3872
    total_reference_rows += ref_rows
    total_unique_rows += unique_rows
    total_payload_rows += payload_rows
    print("pair",a,b,"unique pairs",len(pairs),"referenced input rows",ref_rows,
          "distinct input rows",unique_rows,"processed output rows",payload_rows,flush=True)
print("classes",sum(map(len,classes.values())),"references",len(first)*3872,
      "input rows by reference",total_reference_rows,"input rows once per class",total_unique_rows,
      "output rows across classes",total_payload_rows,"largest output pair rows",max_payload_rows,
      "elapsed seconds",round(perf_counter()-start,6),"peak RSS bytes",getrusage(RUSAGE_SELF).ru_maxrss,flush=True)
