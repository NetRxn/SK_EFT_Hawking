# Independent complete signed Group 158 review

The work-start continuity check accepted publication commit `b1caf1dfd346365feecbb143949f5b0366ae21bc`. The independently accepted component-3 preparation archive binds all 88 signed prepared factor families and both zero restrictions to `6a7caf1c65923c31a682a6deac768d90082a517e63b6dd392ae2f045843d0431`. The source has 468,132 stored rows after two accepted signed sweeps from 2,178,009 input rows. This review inherits that exact preparation.

I independently checked all 4,096 binary assignments on the 12 retained joint-L coordinates. The eight original indices preserve the same labels. Ordinals 1 and 3 each have 13 empty restricted factors and give exact zero. The six live ordinals are 0, 2, 4, 5, 6 and 7. For each of their conditioned signed rows I independently verified label restriction and inverse lifting to the prepared source, with the original factor denominator preserved.

The independent native traversal reconstructs signed joins and quotients, reproduces the guarded refusal, and compares the complete retained tables. The independent continuation replay inverts declared exact splits, checks complex phase and scale only on closed degree-two axes, and recomputes every retained signed join with alternate sparse traversal. Typed discarded continuation attempts are bound to the author logs and exact retained checkpoint journals; charged work is carried separately. All retained coefficients, scopes and denominators agree.

For L2’s triangle I independently verify the original interval row order and term counts for both author pivots. An alternate third-pivot traversal computes all 9,859,072 compatible signed Gaussian products once and reproduces both author sums. L7 also closes as a triangle. The third-pivot calculation audits both author covers of 18,284,544 compatible Gaussian products and binds the exact result only to the matching frozen pass-2 frontier after its independent retained replay.

## Exact composition and timing

All original group terms have zero imaginary part. The common factor denominator is `12003621991652557120041733255593984`. `scalar.tsv` retains all original assignments, exact numerators and their evidence hashes. `composition.tsv` gives the exact stored-factor value, the value after the positive physical prefactor, and the standalone weighted contribution. The component-3 geometry audit independently checks all 128 directed edges on the (K_{8,8}) component at multiplicity two and the original gamma3 partner 3573. It verifies the physical sign, divisor (2^{132}), and the single coefficient 192, which combines the occupation weight 48, chiral factor two and geometric selected-side factor two.

The author measurement ledger keeps the preparation, native guarded work, continuations, separately timed terminals, and any unsuccessful original attempt distinct. Solve walls and independent replay walls are separate receipts. L7’s separate author terminal duration comes from the solver’s monotonic clock, as no wrapper timing file was emitted. The measured-component sum describes this frozen group.

## Reproduction

Verify `review.sha256` and locate the unchanged frozen external binary operands listed under each `author/L*`. Run:

```sh
python3 -B source_review.py
python3 -B controls.py
for i in 0 2 4 5 6 7; do python3 -B prefix.py "$i"; done
python3 -B typed_refusals.py
python3 -B retally.py
```

If a triangle author terminal froze after its retained replay, `finish_triangle.py ORDINAL` reads the exact previously accepted endpoint and the frozen terminal evidence to complete that audit. The package contains independent scripts, pinned inputs, replay and refusal logs, and all exact signed ledgers. Large operands remain external and SHA256-pinned.
