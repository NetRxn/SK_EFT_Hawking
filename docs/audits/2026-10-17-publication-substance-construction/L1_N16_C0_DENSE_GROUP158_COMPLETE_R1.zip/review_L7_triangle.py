from pathlib import Path
from time import monotonic
from prefix import BASE,N,sha,read
from triangle_review import complete

p=BASE/'L7/pass2-result.pkl'
t=BASE/'L7/terminal.out'
assert sha(p)=='ca7853113b51d425386121fc97fb8795103be22d7f6ca7c12c6ac5f2ce000aec'
assert sha(t)=='cdf174866bf6b22301739fa880162cd212a11b53751af8e365c91eeec51c665d'
d=read(p)
factors=d['factors']
assert len(factors)==3
local=Path('author/L7')
for name in ('terminal.out','triangle.py'):
    (local/name).write_bytes((BASE/'L7'/name).read_bytes())
if (BASE/'L7/terminal.time').is_file():
    (local/'terminal.time').write_bytes((BASE/'L7/terminal.time').read_bytes())
print('frozen triangle endpoint scope',d['physical_cut'],sha(p),flush=True)
start=monotonic()
raw=complete(factors,(local/'terminal.out').read_text(),factors)
assert raw[1]==0
secs=round(monotonic()-start,6)
print('independent triangle wall seconds',7,secs,flush=True)
print('exact whole original L scalar',7,raw,N,'terminal',sha(p),'elapsed',secs,flush=True)
