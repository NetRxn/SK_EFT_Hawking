import json, sys
from pathlib import Path
from validation.checks import prose_lean_refs as refs
from validation._tex import _strip_tex_comments

source = Path(sys.argv[1]).read_text()
old = _strip_tex_comments(source)
new = refs._generated_reference_source(source)
assert len(source) == len(new)
assert [i for i, x in enumerate(source) if x == "\n"] == [
    i for i, x in enumerate(new) if x == "\n"
]
def selected(text):
    return {token: {"offset": offset, "line": source.count("\n", 0, offset) + 1}
            for token, offset in refs._prose_verbatim_tokens(text)
            if token.endswith(("_proof", "_fake"))}
before, after = selected(old), selected(new)
assert set(before) == {"escaped_percent_proof"}
assert set(after) == {"literal_percent_proof", "percent_delimiter_proof", "escaped_percent_proof"}
for name, item in after.items():
    original = r"\lean{" + name.replace("_", r"\_") + "}"
    assert source[item["offset"]:].startswith(original)
print(json.dumps({"before": before, "after": after, "newline_offsets_equal": True}, indent=2))
