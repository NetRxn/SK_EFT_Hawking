# Independent original N16 all-residual reaggregation review R5

**ACCEPT the exact full-key coefficient evaluator for the complete retained
754-row contact residual and the 72 grouped S2 choices at the selected
later center.** This verifies the represented signed sum and exact
queries under the measured scratch envelope. The other predecessor
partitions and R rows, later centers, all nine original coupling
alternatives, last-incidence closures, full denominator and connected
normalization remain open.

## Authority and replay

First and final reviewer continuity were fresh with no changes and
byte-identical. The authored final receipt reported source-only drift.
The complete primary diff from 0736fda2e to db527ae05 adds
GaussianHaarPolynomialStein.lean and changes its aggregate import only.
The original Python and the pinned authorities remain unchanged.

The exact author probe reproduced every deterministic JSON field.
Process peak RSS was 128,466,944 bytes in my replay. Its actual eager
K·W join refused at visit 64,145 before prospective live record 65,537.
It restored 14,578 live records and zero live indexes/readers. The
completed bounded probe returned 10,994 live factor records after 75,089
arena visits, with 166,487 separately charged work operations. Logical
factor counts exclude the parallel reference maps and transient
objects. Process RSS is observational and provides no admission bound.
The earlier exploratory failure on an assumed opposition between
group contributions is retained as adverse evidence, not a result.

## Independent signed construction and completeness

I reconstructed the original hopping blocks on the explicit ordered
bar/psi basis, the closed matrix word D† C† B A and oriented gamma
traces. The reference sign uses direct basis inversion counts.
The independently built C and R maps agreed termwise with the
author's maps. The two original predecessor C partitions and one
pinned squared-coordinate R row yield 209 literal and 545 mixed
contact records. All 754 matched. The 16 coframe maps and 72 grouped
trace maps matched independently coefficient-for-coefficient.
Each of the 24 diagonal choices consists of paired nonzero terms
canceling under coframe reversal.

For a full sorted target key, every forward contribution chooses
one eligible residual row of the matching raw slot. Exact multiset
subtraction leaves the factor symbols, and removing the residual mask
forces four remaining bits. Each orientation group forces each
quaternion symbol's factor from its world axis. Since each coframe
supplies exactly two bits, the six ordered splits exhaust all
disjoint placements. Conversely a successful triple of lookups gives
one disjoint forward product to exactly the same target, with the
residual versus coframe and inter-coframe inversion signs. The trace
is exterior degree zero and has no raw derivative labels. The proof
does not depend on any presumed sign cancellation. Group labels route
evaluation, while the full key carries all source labels and powers.

The independent oracle enumerated forward combinations of the four
source operands after filtering each operand by target mask and
multiset inclusion. It does not use the authored inverse subtraction,
mask splitting, signs or arena join. It matched all group subtotals
and signed path counts for the 12 authored targets. The six literal
targets each have four paths from one residual. Four mixed targets
each have six paths from two residuals. The other two mixed targets
each have 12 nonzero paths from four residuals in four groups. Each
group subtotal vanishes exactly on those two targets. Every mixed
path in these six controls uses the actual additional world-axis-1
contact.

## New independent controls

I independently generated eight reachable keys from a different
coframe plane, four literal and four true world-axis-1 mixed. None
coincide with the 12 authored keys. Each has exactly two nonzero
signed paths, one in each of two distinct groups, and sums to zero.
The inverse evaluator matched both signed group subtotals. These
eight controls establish cross-group cancellation separately from the
authored within-group residual cancellation cases.

Removing one occurrence of a repeated quaternion symbol, replacing
a retained occurrence with a different anchor identity, selecting an
unoccupied raw derivative slot, and clearing the exterior mask each
produced zero paths in both calculations. A unit-cap work ledger
rejected a second charge and retained its exact first-charge count.
These controls use the typed scratch interface and do not qualify
general public input admission.

## Remaining original construction

The accepted result answers requested coefficients of the represented
sum without eagerly materializing the output support. It gives no
global support count. Extend through actual original later operands
with exact signed convolution and proved site/Haar last incidence.
Keep the omitted original predecessor rows and alternatives in the
objective. Nothing in this review evaluates the full original Z or
its normalization. No repository, Lean or slot actions occurred.

Evidence uses /tmp/task4-reaggregation-review-r5- with suffixes
first.json, final.json, replay.json, author-deterministic.json,
independent.py and independent.json.
