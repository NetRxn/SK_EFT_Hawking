"""Exact signed original N16 target-key fibers at the selected later center."""
from collections import Counter
from dataclasses import dataclass, field
from fractions import Fraction
from itertools import combinations, product
import importlib.util
import json
from pathlib import Path
import resource
import sys

spec = importlib.util.spec_from_file_location(
    "r4_vertex", Path(__file__).with_name("publication-task4-later-full-vertex-r4.py"))
r4 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r4
spec.loader.exec_module(r4)
Q, P, E, S = r4.Q, r4.P, r4.E, r4.S
SLOTS = ((0,), (0, 1))
G2 = S("g2", ())


@dataclass
class Work:
    cap: int = 2_000_000
    used: int = 0
    counts: Counter = field(default_factory=Counter)
    oracle_record_cap: int = 16_384
    oracle_max_prospective_records: int = 0

    def charge(self, operation, amount=1):
        if type(amount) is not int or amount < 0 or self.used + amount > self.cap:
            raise RuntimeError(f"fiber work cap at {self.used} on {operation} plus {amount}")
        self.used += amount
        self.counts[operation] += amount

    def oracle_product(self, a, b, *retained):
        pairs = count(a)*count(b)
        # Output cannot have more coefficient records than contributing pairs.
        prospective = pairs+sum(count(e) for e in (a,b,*retained))
        if prospective > self.oracle_record_cap:
            raise RuntimeError(f"oracle scratch cap at prospective record {prospective}")
        self.oracle_max_prospective_records = max(self.oracle_max_prospective_records,prospective)
        self.charge("oracle_pair_admission",pairs)
        return a*b


def mask_sign(left, right):
    return -1 if sum((right & ((1 << i)-1)).bit_count()
                     for i in range(left.bit_length()) if left & (1 << i)) % 2 else 1


def subtract(total, part):
    """Sorted exact multiset subtraction, rejecting insufficient powers."""
    rest = []
    cursor = 0
    for symbol in total:
        if cursor < len(part) and part[cursor] == symbol:
            cursor += 1
        else:
            rest.append(symbol)
    return tuple(rest) if cursor == len(part) else None


def residual(reg, arena):
    """Return all R4-accepted raw contact rows before the seed selection."""
    x = reg.sites[0]
    y = reg.step(x, 0)[0]
    g = r4.factors(reg)
    a,b = (arena.ingest(r4.rows(e)) for e in g[:2])
    C,_ = arena.join(a,b)
    arena.drop(a)
    arena.drop(b)
    a,b = (arena.ingest(r4.rows(e)) for e in g[2:4])
    R,_ = arena.join(a,b,(C,))
    arena.drop(a)
    arena.drop(b)
    assert (arena.count(C),arena.count(R)) == (3584,8192)
    ybit = 1 << (8 * reg.site_number(y))
    axes = tuple(tuple(sorted((S('q',(x,0,'L',i)),S('q',(x,1,'L',0))))) for i in (1,2))
    Cs = tuple(arena.new_map() for _ in axes)

    def take_c(key,value):
        m,k,j = key
        if m & (255*ybit) == ybit and k in axes:
            arena.put(Cs[axes.index(k)],(m,tuple(sorted((*k,G2))),j),value)

    arena.scan(C,take_c)
    assert [arena.count(h) for h in Cs] == [3,3]
    R1 = arena.new_map()

    def take_r(key,value):
        if arena.count(R1) == 0 and any(key[1].count(s)==2 and s.index[:2]==(x,2) for s in set(key[1])):
            arena.put(R1,key,value)

    arena.scan(R,take_r)
    assert arena.count(R1) == 1
    arena.drop(C)
    arena.drop(R)
    b0,b1 = (r4.exterior(reg,(y,mu,0)) for mu in (0,1))
    j = P.variable(S('J',(y,0,0)))
    contact = arena.ingest(((m,k,slot),c) for slot,term in zip(SLOTS,(b0*j,(b0+b1)*j),strict=True)
                           for m,p in term.terms for k,c in p.terms)
    combined = arena.new_map()
    for h in Cs:
        out,_ = arena.join(h,contact,arena.retained(h,contact),complement=True)
        r4.add_handle(arena,combined,out)
        arena.drop(out)
    K,_ = arena.join(combined,R1,arena.retained(combined,R1),complement=True)
    ca,cb = (r4.as_exterior(r4.oracle_snapshot(arena,h)) for h in Cs)
    r = r4.as_exterior(r4.oracle_snapshot(arena,R1))
    raw_j = r4.o.RawJet((0,1),(((),P()),((0,),j)))
    raw_a = r4.o.RawJet((0,1),(((),b0),((1,),b0+b1)))
    direct_k = r4.o.RawJet.constant((ca+cb)*r)*raw_a*raw_j
    r4.assert_exact(arena,K,r4.from_raw(direct_k))
    assert [sum(len(p.terms) for _,p in direct_k.at(s).terms) for s in SLOTS] == [209,545]
    for h in (*Cs,R1,contact,combined):
        arena.drop(h)
    return K,direct_k


def source_roster(reg,y,arena,work):
    coframes = {}
    original_coframes = {}
    for mu,a in product(range(4),repeat=2):
        source = r4.exterior(reg,(y,mu,a))
        h = arena.ingest(r4.rows(source))
        assert arena.count(h) == 64
        for (mask,key,slot),_ in r4.rows(source):
            assert mask.bit_count()==2 and slot==() and len(key)==1
            assert key[0].family=='q' and key[0].index[1]==mu
        coframes[mu,a] = h
        original_coframes[mu,a] = source
    h_groups = {}
    original_h = {}
    diagonals = 0
    quarter = P.scalar(Fraction(1,4))
    for mu,nu in combinations(range(4),2):
        k,l = [i for i in range(4) if i not in (mu,nu)]
        for a,b in product(range(4),repeat=2):
            pieces = []
            for (i,j),(r,s) in product(((k,l),(l,k)),((mu,nu),(nu,mu))):
                ia,ib = (a,b) if (r,s)==(mu,nu) else (b,a)
                work.charge("original_oriented_trace")
                pieces.append(r4.closed_trace(reg,y,i,j,r,s,ia,ib)*quarter)
            h = sum(pieces,P())
            if a == b:
                assert all(pieces) and pieces[0] == -pieces[1] and pieces[2] == -pieces[3]
                assert not h
                diagonals += 1
                continue
            assert len(h.terms) == 128 and all(piece == h*quarter for piece in pieces)
            for key,_ in h.terms:
                assert len(key)==4 and all(s.family=='q' for s in key)
                assert Counter(s.index[1] for s in key)=={k:2,l:2}
            choice = (k,l,mu,nu,a,b)
            h *= P.variable(G2)
            original_h[choice] = E(((0,h),))
            h_groups[choice] = arena.ingest(r4.rows(original_h[choice]))
    assert len(h_groups) == 72 and diagonals == 24
    return coframes, h_groups, original_coframes, original_h


def masks_of_size_two(mask):
    bits = [1 << i for i in range(mask.bit_length()) if mask & (1 << i)]
    return (a|b for a,b in combinations(bits,2))


def fiber(arena,K,coframes,groups,target,work):
    """Exact inverse image of a complete output key under all groups."""
    target_mask,target_symbols,target_slot = target
    by_group = {}
    contributing_residuals = 0
    positive_real = negative_real = pure_imaginary = 0
    paths = 0
    kappas = 0

    def enter(key,value):
        nonlocal kappas, contributing_residuals, positive_real, negative_real, pure_imaginary, paths
        work.charge("residual_key_tests")
        km,ks,slot = key
        if slot != target_slot or km & target_mask != km:
            return
        left = subtract(target_symbols,ks)
        if left is None:
            return
        wm = target_mask ^ km
        if (wm.bit_count() != 4 or len(left) != 7 or left.count(G2) != 1
                or any(s.family != 'q' and s != G2 for s in left)):
            return
        kappas += 1
        split_masks = tuple(masks_of_size_two(wm))
        contributes = False
        for choice,trace in groups.items():
            work.charge("group_tests")
            k,l,mu,nu,a,b = choice
            sa = r4.axes_symbols(left,(mu,))
            sb = r4.axes_symbols(left,(nu,))
            hs = tuple(s for s in left if s == G2 or s.index[1] in (k,l))
            if len(sa) != 1 or len(sb) != 1 or len(hs) != 5:
                continue
            hc = arena.get(trace,(0,hs,()))
            if hc is None:
                continue
            for am in split_masks:
                work.charge("ordered_mask_split_tests")
                bm = wm ^ am
                ca = arena.get(coframes[mu,a],(am,sa,()))
                cb = arena.get(coframes[nu,b],(bm,sb,()))
                if ca is not None and cb is not None:
                    work.charge("nonzero_signed_paths")
                    signed = value*ca*cb*hc*(mask_sign(km,wm)*mask_sign(am,bm))
                    by_group[choice] = by_group.get(choice,Q(0))+signed
                    paths += 1
                    contributes = True
                    positive_real += signed.real > 0
                    negative_real += signed.real < 0
                    pure_imaginary += not signed.real and bool(signed.imag)
        contributing_residuals += contributes

    arena.scan(K,enter)
    return by_group,kappas,contributing_residuals,paths,(positive_real,negative_real,pure_imaginary)


def subset_factor(e,mask,symbols,work):
    rows = []
    for m,p in e.terms:
        work.charge("oracle_operand_mask_tests")
        if m & mask != m:
            continue
        kept = []
        for key,coef in p.terms:
            work.charge("oracle_operand_symbol_tests")
            # Counter inclusion is separate from the inverse evaluator's
            # sorted multiset subtraction.
            if not Counter(key)-symbols:
                kept.append((key,coef))
        if kept:
            rows.append((m,P(tuple(kept))))
    return E(tuple(rows))


def count(e):
    return sum(len(p.terms) for _,p in e.terms)


def direct(K,coframes,groups,target,work):
    """Forward canonical exterior oracle over a safe subset of each operand."""
    mask,symbols,slot = target
    total = Counter(symbols)
    k = subset_factor(K.at(slot),mask,total,work)
    by_group = {}
    for choice,H in groups.items():
        _,_,mu,nu,a,b = choice
        h = subset_factor(H,mask,total,work)
        if not h:
            continue
        pa = subset_factor(coframes[mu,a],mask,total,work)
        pb = subset_factor(coframes[nu,b],mask,total,work)
        w = work.oracle_product(pa,pb,k,h)
        del pa,pb
        v = work.oracle_product(w,h,k)
        del w,h
        out = work.oracle_product(k,v)
        del v
        value = next((coef for m,p in out.terms if m==mask for key,coef in p.terms if key==symbols),Q(0))
        if value:
            by_group[choice] = value
        del out
    return by_group


def candidate_keys(arena,K,coframes,groups,mixed_source_anchors,work):
    """Pick reachable exact output keys with guaranteed cross-group paths."""
    selected = (0,3,1,2,0,1)
    _,_,mu,nu,a,b = selected
    wa,_ = arena.join(coframes[mu,a],coframes[nu,b],
                      arena.retained(coframes[mu,a],coframes[nu,b]),complement=True)
    assert arena.count(wa) == 3584
    eager = r4.attempt(arena,K,wa,complement=True)
    qa = groups[selected]
    seeds = {}
    for other,qb in groups.items():
        if other[:4] != selected[:4] or other == selected:
            continue
        _,_,_,_,c,d = other
        wb,_ = arena.join(coframes[mu,c],coframes[nu,d],
                          arena.retained(coframes[mu,c],coframes[nu,d]),complement=True)
        hc = []
        def trace_overlap(key,coef):
            work.charge("candidate_trace_tests")
            alternative = arena.get(qb,key)
            if alternative is not None:
                hc.append((key,coef,alternative))

        arena.scan(qa,trace_overlap)
        if hc:
            try:
                def coframe_overlap(key,wcoef):
                    work.charge("candidate_coframe_tests")
                    wm,wq,_ = key
                    alt = arena.get(wb,key)
                    if alt is None:
                        return
                    def source(key2,kcoef):
                        work.charge("candidate_residual_tests")
                        km,ks,slot = key2
                        if km & wm or sum(tag[2] == slot for tag in seeds) >= 6:
                            return
                        if slot == (0,1) and not any(s.family=='q' and s.index[:2] in mixed_source_anchors for s in ks):
                            return
                        for (_,hq,_),hcoef,other_hcoef in hc[:4]:
                            key3 = (km|wm,tuple(sorted(ks+wq+hq)),slot)
                            seeds.setdefault(key3,(selected,other,wcoef*hcoef==-alt*other_hcoef))
                            if sum(tag[2] == slot for tag in seeds) >= 6:
                                return
                    arena.scan(K,source)
                    if len(seeds) == 12:
                        raise SearchComplete
                arena.scan(wa,coframe_overlap)
            except SearchComplete:
                pass
        arena.drop(wb)
        if len(seeds) == 12:
            break
    arena.drop(wa)
    assert Counter(k[2] for k in seeds) == {s:6 for s in SLOTS}
    return seeds,eager


class SearchComplete(Exception):
    pass


def fingerprint(key):
    mask,symbols,slot = key
    return dict(mask_hex=hex(mask),symbols=[(s.family,s.index) for s in symbols],slot=slot)


def value_string(q):
    return str(q)


def main():
    reg = r4.o.OriginalRegulator()
    y = reg.step(reg.sites[0],0)[0]
    arena = r4.Arena(r4.Caps(1_000_000,65_536))
    work = Work()
    K,direct_k = residual(reg,arena)
    coframes,groups,source_coframes,source_h = source_roster(reg,y,arena,work)
    kept = arena.metric()
    assert kept["live_records"] == 754+1024+9216
    mixed_source_anchors = ((y,1),(reg.step(y,1)[0],1))
    seeds,eager = candidate_keys(arena,K,coframes,groups,mixed_source_anchors,work)
    assert arena.metric()["live_records"] == kept["live_records"]
    results = []
    for key,(group_a,group_b,opposed) in seeds.items():
        per_group,candidates,residual_paths,paths,sign_counts = fiber(arena,K,coframes,groups,key,work)
        signed_nonzero = {choice:value for choice,value in per_group.items() if value}
        oracle = direct(direct_k,source_coframes,source_h,key,work)
        assert oracle == signed_nonzero
        assert group_a in per_group and group_b in per_group
        assert len(per_group) >= 2
        final = sum(per_group.values(),Q(0))
        results.append(dict(output_key=fingerprint(key),known_path_groups=(group_a,group_b),
                           known_opposite_group_terms=opposed,
                           candidate_uses_added_world_direction_1=key[2]==(0,1),
                           signed_paths=paths,
                           residual_candidates=candidates,residuals_with_paths=residual_paths,
                           groups_with_paths=len(per_group),groups_after_cancellation=len(oracle),
                           group_sums=[(g,value_string(v)) for g,v in sorted(per_group.items())],
                           path_sign_counts=dict(zip(("positive_real","negative_real","pure_imaginary"),sign_counts)),
                           total=value_string(final),total_cancels=not final,
                           direct_per_group_equal=True))
    print(json.dumps(dict(residual=(209,545),original_coframe_factors=len(coframes),
        original_nondiagonal_groups=len(groups),original_diagonal_groups_cancelled=24,
        grouped_label_metadata_entries=len(groups)+len(coframes),retained_factor_arena=kept,
        eager_KW_first_group_refusal=eager,after_controls_arena=arena.metric(),
        exact_common_output_keys=results,work_operations=dict(work.counts),work_total=work.used,
        work_cap=work.cap,oracle_record_cap=work.oracle_record_cap,
        oracle_max_prospective_records=work.oracle_max_prospective_records,
        oracle_reference_factor_records=754+1024+9216,
        all_original_alternatives=r4.ALTERNATIVES,
        native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_unit="bytes" if sys.platform=="darwin" else "KiB"),indent=2))


if __name__ == "__main__":
    main()
