from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial
import importlib.util
import json
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

def load(label, path):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module

r4 = load("r4review", "/tmp/publication-task4-later-full-vertex-r4.py")
Q, P, S = o.QComplex, o.Polynomial, o.Symbol
reg = o.OriginalRegulator()
x, y = reg.sites[0], reg.step(reg.sites[0], 0)[0]
x2 = reg.step(x, 2)[0]
q = S("g2", ())
j = S("J", (y, 0, 0))
assert (reg.volume, reg.word, reg.convention) == (16, "closed", "source_C")

def tensor(alpha, *, slot=(), labels=()):
    # Rebuild the four signed bilinears directly from the block definition
    # and the globally ordered bar/psi basis. No author arena or ExteriorPolynomial.
    positions = {token: i for i, token in enumerate(reg.generator_order)}
    out = defaultdict(Q)
    blocks = f.original_coframe_blocks(reg, alpha)
    for b in blocks:
        for i, k in product(range(4), repeat=2):
            a, z = positions[b.bar_site, "bar", i], positions[b.psi_site, "psi", k]
            for key, value in b.matrix[i][k].terms:
                out[(1 << a | 1 << z, tuple(sorted((*labels, *key))), slot)] += value * b.weight * (-1 if a > z else 1)
    return {k: v for k, v in out.items() if v}

def trace_rows(site, k, l, mu, nu, a, b):
    # Direct closed matrix word D† C† B A, with original quaternion labels.
    anchors = (site,k), (reg.step(site,k)[0],l), (reg.step(site,l)[0],k), (site,l)
    links = [f.original_spin4_link(*(tuple(P.variable(S("q",(*z,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for z in anchors]
    A,B,C,D = links
    U = o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(D),o.matrix_dagger(C)),o.matrix_multiply(B,A))
    gamma = o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    poly = sum((U[i][k]*gamma[k][i] for i,k in product(range(4),repeat=2)),P()) * o.epsilon((k,l,mu,nu))
    return {(0,key,()): value for key,value in poly.terms}

def indices(mask):
    return [i for i in range(mask.bit_length()) if mask >> i & 1]

def multiply(left, right):
    out = defaultdict(Q)
    for (lm,lk,lj), lv in left.items():
        for (rm,rk,rj), rv in right.items():
            if lm & rm or len(lj) + len(rj) > 2:
                continue
            z = tuple(sorted(lj + rj))
            multiplicity = 1
            for i in set(z):
                multiplicity *= factorial(z.count(i)) // (factorial(lj.count(i)) * factorial(rj.count(i)))
            parity = sum(i > k for i,k in product(indices(lm),indices(rm))) % 2
            out[lm|rm,tuple(sorted(lk+rk)),z] += lv * rv * (-multiplicity if parity else multiplicity)
    return {k:v for k,v in out.items() if v}

def summed(*maps):
    out = defaultdict(Q)
    for d in maps:
        for k,v in d.items(): out[k] += v
    return {k:v for k,v in out.items() if v}

def slot_relabel(d, slot):
    return {(m,k,slot):v for (m,k,_),v in d.items()}

def snapshot(arena, handle):
    out = {}
    arena.scan(handle, lambda k,v:out.__setitem__(k,v))
    return out

from collections import Counter
from itertools import combinations

r5 = load("r5review", "/tmp/publication-task4-all-residual-reaggregation-r5.py")
r4 = r5.r4
C = multiply(tensor((x,0,0)),tensor((x,1,1)))
R = multiply(trace_rows(x,2,3,0,1,0,1),tensor((x2,2,0)))
# Read the exact predecessor R row order from the accepted predecessor.
stage, ah, rh = r4.future_prefix(r4.Caps(200_000,65_536),r4.factors(reg))
assert C == snapshot(stage,ah) and R == snapshot(stage,rh)
rkey = next(k for k in snapshot(stage,rh) if any(s.family=="q" and s.index[:2]==(x,2)
                                             and k[1].count(s)==2 for s in k[1]))
firstbit = 1 << (8*reg.site_number(y))
labels = [tuple(sorted((S("q",(x,0,"L",a)), S("q",(x,1,"L",0))))) for a in (1,2)]
Cparts = [{(m,tuple(sorted((*k,q))),s):v for (m,k,s),v in C.items()
           if m & (255*firstbit) == firstbit and k==label} for label in labels]
assert [len(c) for c in Cparts]==[3,3]
pre = multiply(summed(*Cparts),{rkey:R[rkey]})
literal = slot_relabel(multiply(pre,tensor((y,0,0),labels=(j,))),(0,))
mix1 = slot_relabel(multiply(pre,tensor((y,1,0),labels=(j,))),(0,1))
mixed = summed(slot_relabel(literal,(0,1)),mix1)
K = summed(literal,mixed)
assert [len(literal),len(mixed),len(K)]==[209,545,754]
# The authored arena is the observed result under test, not the reference.
arena = r4.Arena(r4.Caps(1_000_000,65_536))
work = r5.Work()
handle,_ = r5.residual(reg,arena)
assert snapshot(arena,handle)==K
author_c,author_h,*_ = r5.source_roster(reg,y,arena,work)
assert arena.metric()["live_records"]==10994
T = {(mu,a):tensor((y,mu,a)) for mu,a in product(range(4),repeat=2)}
assert len(T)==16 and all(len(t)==64 and t==snapshot(arena,author_c[k]) for k,t in T.items())
H = {}
diagonals=0
for mu,nu in combinations(range(4),2):
    k,l = [i for i in range(4) if i not in (mu,nu)]
    for a,b in product(range(4),repeat=2):
        h0=trace_rows(y,k,l,mu,nu,a,b)
        group=k,l,mu,nu,a,b
        if a==b:
            for i,h in ((k,l),(l,k)):
                hp=trace_rows(y,i,h,mu,nu,a,a)
                hm=trace_rows(y,i,h,nu,mu,a,a)
                assert hp and hm and not summed(hp,hm)
            diagonals+=1
        else:
            for i,h in ((k,l),(l,k)):
                assert h0==trace_rows(y,i,h,mu,nu,a,b)
                assert h0==trace_rows(y,i,h,nu,mu,b,a)
            H[group]={(m,tuple(sorted((*key,q))),slot):coef for (m,key,slot),coef in h0.items()}
            assert len(H[group])==128 and H[group]==snapshot(arena,author_h[group])
assert len(H)==72 and diagonals==24
assert set(H)==set(author_h)

def decode(d):
    def freeze(x):
        return tuple(map(freeze,x)) if isinstance(x,list) else x
    return int(d["mask_hex"],16),tuple(S(name,freeze(value)) for name,value in d["symbols"]),tuple(d["slot"])

# Independent direct path enumeration. Retain only terms individually
# dividing the target. Join all forward combinations of four operands.
def reference(target):
    M,X,jj=target
    powers=Counter(X)
    def terms(d, slot=()):
        return [(key,v) for key,v in d.items() if key[2]==slot and key[0]&M==key[0] and not Counter(key[1])-powers]
    def parity(L,R):
        return sum(i>k for i,k in product(indices(L),indices(R)))
    ks=terms(K,jj)
    ts={key:terms(d) for key,d in T.items()}
    groups={}
    signed=[]
    resid=set()
    mix_count=0
    for (k,l,mu,nu,a,b),hd in H.items():
        group=(k,l,mu,nu,a,b)
        for (key,hc),(ka,ca),(kb,cb),(kh,cv) in product(ks,ts[mu,a],ts[nu,b],terms(hd)):
            km,ky,_=key
            am,ay,_=ka
            bm,by,_=kb
            hm,hy,_=kh
            assert hm==0
            if km&(am|bm) or am&bm or km|am|bm!=M or Counter(ky+ay+by+hy)!=powers:
                continue
            sign=(-1)**(parity(km,am)+parity(km,bm)+parity(am,bm))
            v=cv*ca*cb*hc*sign
            assert v
            groups[group]=groups.get(group,Q(0))+v
            signed.append(v)
            resid.add(key)
            mix_count+=key in mix1
    return groups,signed,resid,mix_count

doc=json.load(open("/tmp/publication-task4-all-residual-reaggregation-r5.json"))
authored=[]
zero=[]
for row in doc["exact_common_output_keys"]:
    key=decode(row["output_key"])
    observed=reference(key)
    groups,paths,resid,mixed_paths=observed
    assert [(list(g),str(v)) for g,v in sorted(groups.items())]==[(g,v) for g,v in row["group_sums"]]
    assert len(paths)==row["signed_paths"] and len(resid)==row["residuals_with_paths"]
    total=sum(groups.values(),Q(0))
    assert str(total)==row["total"] and (not total)==row["total_cancels"]
    assert key[2]!=(0,1) or mixed_paths
    if not total:
        assert groups and not any(groups.values()) and len(paths)==12
        assert any(v.imag>0 or v.real>0 for v in paths) and any(v.imag<0 or v.real<0 for v in paths)
        zero.append(key)
    authored.append({"slot":key[2],"paths":len(paths),"mixed_axis1_paths":mixed_paths,
                     "groups":len(groups),"residuals":len(resid),"cancels":not total})
assert len(zero)==2

# Use a different world plane and reverse key order. Reachable keys come
# from explicit independent forward products, with a separate typed
# zero query and a quaternion identity perturbation as adverse controls.
own=[]
authored_keys={decode(r["output_key"]) for r in doc["exact_common_output_keys"]}
for slot in ((0,),(0,1)):
    targets=[]
    for choice in reversed(H):
        k,l,mu,nu,a,b=choice
        if (mu,nu)==(1,2):
            continue
        for (mask,ky,js),value in reversed(K.items()):
            if js!=slot or slot==(0,1) and (mask,ky,js) not in mix1:
                continue
            for (am,ay,_),(bm,by,_) in product(reversed(T[mu,a]),reversed(T[nu,b])):
                if mask&(am|bm) or am&bm:
                    continue
                for _,hy,_ in list(H[choice])[-4:]:
                    key=mask|am|bm,tuple(sorted(ky+ay+by+hy)),slot
                    if key not in authored_keys and key not in targets:
                        targets.append(key)
                if targets:
                    break
            if targets:
                break
        if targets:
            break
    assert len(targets)==4
    own.extend(targets)
m,sy,slot=own[0]
removed=list(sy)
dup=next(s for s,n in Counter(sy).items() if s.family=="q" and n>=2)
removed.remove(dup)
alter=list(sy)
alter[alter.index(dup)]=S("q",(reg.sites[-1],dup.index[1],dup.index[2],dup.index[3]))
adverse=[(m,tuple(removed),slot),(m,tuple(sorted(alter)),slot),(m,sy,(1,)),(0,sy,slot)]
own_evidence=[]
for key in own+adverse:
    groups,paths,resid,mix_paths=reference(key)
    assert bool(paths)==(key in own)
    candidate,_,resid_count,count,_=r5.fiber(arena,handle,author_c,author_h,key,work)
    assert candidate==groups and resid_count==len(resid) and count==len(paths)
    assert key not in own or key[2]!=(0,1) or mix_paths
    own_evidence.append({"key":r5.fingerprint(key),"groups":len(groups),"paths":len(paths),
                         "residuals":len(resid),"mixed_axis1_paths":mix_paths,
                         "total":str(sum(groups.values(),Q(0)))})
counters=r5.Work(cap=1)
counters.charge("unit")
try:
    counters.charge("overflow")
except RuntimeError:
    assert counters.used==1 and counters.counts=={"unit":1}
else:
    raise AssertionError("work cap did not refuse")
print(json.dumps({"roster":{"residuals":len(K),"coframes":len(T),"groups":len(H),"diagonals":diagonals},
                  "authored_targets":authored,"independent_targets_and_adverse":own_evidence,
                  "work_cap_refused_without_charge":True},indent=2))
