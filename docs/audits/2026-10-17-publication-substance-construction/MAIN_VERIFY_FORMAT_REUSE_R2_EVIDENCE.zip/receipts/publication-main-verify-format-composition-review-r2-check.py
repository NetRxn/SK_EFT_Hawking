import ast, collections, contextlib, hashlib, json, os, pathlib, re, shlex, subprocess, sys, textwrap
from unittest.mock import patch
ROOT=pathlib.Path.cwd(); EV=pathlib.Path('/tmp/publication-main-verify-format-reuse-r2-evidence'); OUT=pathlib.Path('/tmp/publication-main-verify-format-composition-review-r2-independent.json')
a=json.loads(pathlib.Path('/tmp/publication-main-verify-format-reuse-r2.json').read_text())
def git(*args): return subprocess.check_output(['git',*args],text=True)
def sha(b): return hashlib.sha256(b).hexdigest()
paths=sorted({c['path'] for c in a['commands']}); before={p:git('show','HEAD:'+p) for p in paths}; after={p:(ROOT/p).read_text() for p in paths}
start={'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain=v1'),'diff':git('diff','--binary'),'index':sha(pathlib.Path(git('rev-parse','--git-path','index').strip()).read_bytes()),'ledger':sha((ROOT/'docs/review_finding_supersessions.json').read_bytes())}
assert start['head']==a['head']; assert sorted(line[3:] for line in start['status'].splitlines())==paths
assert start['diff']==(EV/'full.diff').read_text(); assert sha(start['diff'].encode())==a['full_diff_sha256']
records=[]
def cmd(block):
 if '```' in block: return textwrap.dedent(block.split('```',2)[1]).strip()
 return block[block.index('`')+1:block.rindex('`')]
def tree(payload):
 t=ast.parse(textwrap.dedent(payload))
 if len(t.body)==1 and isinstance(t.body[0],ast.Expr):
  v=t.body[0].value
  if isinstance(v,ast.Call) and isinstance(v.func,ast.Name) and v.func.id=='exec':
   assert len(v.args)==1 and isinstance(v.args[0],ast.Constant) and isinstance(v.args[0].value,str) and not v.keywords
   t=ast.parse(textwrap.dedent(v.args[0].value))
 return ast.dump(t,include_attributes=False)
for p in paths:
 assert before[p]==(EV/'before'/p).read_text(); assert after[p]==(EV/'after'/p).read_text()
 replay=before[p]; orig=git('show',a['original_donor']+'^:'+p); donor=git('show',a['original_donor']+':'+p); later=git('show',a['donor']+':'+p)
 for i,c in enumerate(a['commands']):
  if c['path']!=p: continue
  assert replay.count(c['before'])==1; assert c['before'] in orig; assert c['after'] in donor and c['after'] in later
  replay=replay.replace(c['before'],c['after'],1)
  x,y=cmd(c['before']),cmd(c['after']); t1,t2=shlex.split(x),shlex.split(y)
  syntax=subprocess.run(['/bin/sh','-n','-c',y],capture_output=True,text=True); assert syntax.returncode==0,syntax.stderr
  if c['kind']=='python_ast_exact':
   k1=t1.index('-c'); k2=t2.index('-c'); assert t1[:k1+1]==t2[:k2+1] and t1[k1+2:]==t2[k2+2:]; assert tree(t1[k1+1])==tree(t2[k2+1])
  else: assert t1==t2
  records.append({'index':i,'path':p,'kind':c['kind'],'syntax_exit':syntax.returncode,'before_sha256':sha(c['before'].encode()),'after_sha256':sha(c['after'].encode())})
 assert replay==after[p]
# Run exactly existing read-only consumers. No command strings executed.
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT)]
import build_graph
from validation.checks import reviews
assert pathlib.Path(build_graph.__file__).resolve()==ROOT/'scripts/build_graph.py'; assert pathlib.Path(reviews.__file__).resolve()==ROOT/'scripts/validation/checks/reviews.py'
original_read=pathlib.Path.read_text
def virtual_read(self,*args,**kwargs):
 try: rel=str(self.resolve().relative_to(ROOT))
 except ValueError: rel=''
 return before[rel] if rel in before else original_read(self,*args,**kwargs)
with patch.object(pathlib.Path,'read_text',virtual_read):
 bnodes=build_graph.extract_review_finding_nodes(); bgate=reviews.check_review_verify_is_one_command()
anodes=build_graph.extract_review_finding_nodes(); agate=reviews.check_review_verify_is_one_command()
bi={x['id']:x for x in bnodes}; ai={x['id']:x for x in anodes}; assert len(bnodes)==len(anodes)==1842 and bi.keys()==ai.keys()
verify=[]; detail=[]
for k,b in bi.items():
 n=ai[k]; bc=json.loads(json.dumps(b)); nc=json.loads(json.dumps(n))
 if bc['meta'].get('verify')!=nc['meta'].get('verify'): verify.append(k)
 if bc.get('detail')!=nc.get('detail'): detail.append(k)
 bc['meta'].pop('verify',None);nc['meta'].pop('verify',None);bc.pop('detail',None);nc.pop('detail',None); assert bc==nc,k
assert len(verify)==25 and len(detail)==15; assert set(verify)==set(a['changed_verify_ids']); assert set(detail)==set(a['changed_detail_ids'])
def serialize_result(r):
 return {'passed':r.passed,'details':[vars(d) for d in r.details]}
bg=serialize_result(bgate); ag=serialize_result(agate)
assert not bgate.passed and not agate.passed
assert '274 `Verify:` line(s) checked, 56 ' in str(bg); assert '274 `Verify:` line(s) checked, 3 ' in str(ag)
ingestion={p:sum(n['meta'].get('review_file')==p for n in anodes) for p in paths[-2:]}
# All metadata preserved already: inspect actual key values and use review-file matching below.
d8='papers/AutomatedReviews/2026-08-15-d8-stage10-redraft/D8.md'
if not (ROOT/d8).exists():
 matches=list((ROOT/'papers/AutomatedReviews').glob('*/D8.md')); matches=[p for p in matches if 'stage10' in str(p).lower()]; assert len(matches)==1; d8=str(matches[0].relative_to(ROOT))
assert (ROOT/d8).read_text()==git('show','HEAD:'+d8); assert sha((ROOT/d8).read_bytes())==a['unchanged_D8_sha256']
p=paths[0]
# D1 original 1.1 is before the first changed original 1.2 command; conserve its entire heading section.
s=before[p]; headings=list(re.finditer(r'^###\s+1\.1\b.*$',s,re.M)); assert len(headings)==1
st=headings[0].start(); en=re.search(r'^###\s+',s[headings[0].end():],re.M); end=headings[0].end()+en.start() if en else len(s)
section=s[st:end]; assert section in after[p]
end={'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain=v1'),'diff':git('diff','--binary'),'index':sha(pathlib.Path(git('rev-parse','--git-path','index').strip()).read_bytes()),'ledger':sha((ROOT/'docs/review_finding_supersessions.json').read_bytes())}; assert start==end
res={'verdict':'ACCEPT_EXACT_FORMATTING_COMPOSITION','head':start['head'],'status':start['status'],'full_diff_sha256':sha(start['diff'].encode()),'counts':dict(collections.Counter(c['kind'] for c in records)),'files':{p:{'before_sha256':sha(before[p].encode()),'after_sha256':sha(after[p].encode()),'blocks':sum(c['path']==p for c in records)} for p in paths},'commands':records,'finding_count_before':len(bnodes),'finding_count_after':len(anodes),'changed_verify_ids':verify,'changed_detail_ids':detail,'all_other_fields_equal':True,'canonical_before':bg,'canonical_after':ag,'imports':{'build_graph':build_graph.__file__,'reviews':reviews.__file__},'historical_ingestion':ingestion,'D8_path':d8,'D8_sha256':sha((ROOT/d8).read_bytes()),'D1_original_1_1_section_sha256':sha(section.encode()),'source_index_ledger_unchanged':True,'scientific_commands_executed':0}
OUT.write_text(json.dumps(res,indent=2)+'\n'); print(json.dumps({k:v for k,v in res.items() if k not in ['commands','changed_verify_ids','changed_detail_ids','files']},indent=2))
