"""Bounded original N16 complementary-mask continuation. Scratch only."""
from dataclasses import dataclass
from itertools import product
from math import comb
import json
import resource
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

Q, P, E, S = o.QComplex, o.Polynomial, o.ExteriorPolynomial, o.Symbol
INDICES = ((), (0,), (1,), (0, 0), (0, 1), (1, 1))
ALTERNATIVES = tuple((q,p) for q in range(3) for p in range(5-2*q))

class Refusal(ValueError):
    def __init__(self, kind, visits, live):
        self.kind, self.visits, self.live = kind, visits, live
        super().__init__(f'{kind} cap: visits={visits}, requested_live={live}')

@dataclass(frozen=True, slots=True)
class Caps:
    visits: int
    records: int

    def check(self):
        if type(self.visits) is not int or not 0 < self.visits <= 2_000_000:
            raise ValueError('visits must be a positive exact integer within the probe envelope')
        if type(self.records) is not int or not 0 < self.records <= 65_536:
            raise ValueError('records must be a positive exact integer within the probe envelope')

class Arena:
    """Track coefficient and mask-index logical slots, not Python heap bytes."""
    def __init__(self, caps):
        if type(caps) is not Caps:
            raise ValueError('exact scratch Caps required')
        caps.check()
        self.caps = caps
        self._maps = {}
        self._index_slots = {}
        self._serial = 0
        self._used = 0
        self._charged = {'buckets': 0, 'records': 0}
        self._live = 0
        self._peak = 0

    def _check(self):
        self.caps.check()
        if type(self._used) is not int or not 0 <= self._used <= self.caps.visits:
            raise ValueError('invalid consumed visit counter')
        if (set(self._charged) != {'buckets','records'}
                or any(type(v) is not int or v < 0 for v in self._charged.values())
                or sum(self._charged.values()) != self._used):
            raise ValueError('inconsistent charged visit ledger')
        if any(type(v) is not int or v < 0 for v in self._index_slots.values()):
            raise ValueError('invalid indexed storage accounting')
        known = sum(map(len,self._maps.values())) + sum(self._index_slots.values())
        if type(self._live) is not int or self._live != known:
            raise ValueError('invalid live-record counter')
        if type(self._peak) is not int or not self._live <= self._peak <= self.caps.records:
            raise ValueError('invalid peak-record counter')

    def _admit(self, extra):
        prospective = self._live+extra
        if prospective > self.caps.records:
            raise Refusal('records',self._used,prospective)

    def _update(self, delta):
        self._live+=delta
        self._peak=max(self._peak,self._live)

    def visit(self,kind='records'):
        self._check()
        if kind not in self._charged:
            raise ValueError('unknown visit accounting kind')
        if self._used >= self.caps.visits:
            raise Refusal('visits',self._used,self._live)
        self._used+=1
        self._charged[kind]+=1

    def _new_id(self):
        self._serial+=1
        return self._serial

    def new_map(self):
        self._check()
        h=self._new_id()
        self._maps[h]={}
        return h

    def put(self,h,key,c):
        self._check()
        m=self._maps[h]
        prior=m.get(key)
        value=c if prior is None else prior+c
        if value:
            if prior is None:
                self._admit(1)
                m[key]=value
                self._update(1)
            else:
                m[key]=value
        elif prior is not None:
            del m[key]
            self._update(-1)

    def ingest(self,rows):
        h=self.new_map()
        try:
            for key,c in rows: self.put(h,key,c)
        except BaseException:
            self.drop(h)
            raise
        return h

    def drop(self,h):
        self._check()
        self._update(-len(self._maps.pop(h)))

    def _new_index(self):
        self._check()
        h=self._new_id()
        self._index_slots[h]=0
        return h

    def _index_admit(self,h,extra):
        self._check()
        self._admit(extra)
        self._index_slots[h]+=extra
        self._update(extra)

    def _drop_index(self,h):
        self._check()
        self._update(-self._index_slots.pop(h))

    def retained(self,a,b):
        self._check()
        return tuple(sorted(set(self._maps)-{a,b}))

    def _check_join(self,a,b,retained):
        self._check()
        if type(a) is not int or type(b) is not int or a not in self._maps or b not in self._maps:
            raise ValueError('unowned operand')
        if type(retained) is not tuple or any(type(h) is not int or h <= 0 for h in retained):
            raise ValueError('retained must name exact positive owned handles')
        if len(set(retained))!=len(retained) or set(retained)!=set(self._maps)-{a,b}:
            raise ValueError('inconsistent retained live-map roster')

    def metric(self):
        self._check()
        return dict(visits=self._used,charged_by_kind=dict(self._charged),
                    live_records=self._live,peak_records=self._peak,
                    live_maps=len(self._maps),live_indexes=len(self._index_slots))

    def map(self,h):
        """Read-only view. Counting and modifying are owned by the arena."""
        from types import MappingProxyType
        self._check()
        return MappingProxyType(self._maps[h])

    def _bucket(self,h,shared,ticket):
        buckets={}
        for key,value in self._maps[h].items():
            mask=key[0]&shared
            if mask not in buckets:
                self._index_admit(ticket,1)
                buckets[mask]=[]
            self._index_admit(ticket,1)
            buckets[mask].append((key,value))
        return buckets

    def _product(self,out,litem,ritem):
        (lm,lk,lj),lc=litem
        (rm,rk,rj),rc=ritem
        if lm&rm or len(lj)+len(rj)>2:
            return
        slot=tuple(sorted(lj+rj))
        multiplier=1
        for label in set(slot):
            multiplier*=comb(slot.count(label),lj.count(label))
        sign=1
        bits=lm
        while bits:
            low=bits&-bits
            if (rm&(low-1)).bit_count()%2:
                sign=-sign
            bits^=low
        self.put(out,(lm|rm,tuple(sorted(lk+rk)),slot),lc*rc*(sign*multiplier))

    def join(self,a,b,retained=(),*,complement=False):
        self._check_join(a,b,retained)
        out=self.new_map()
        ticket=None
        stats=dict(bucket_checks=0, compatible_record_visits=0, record_visits=0,
                   shared_bits=0,index_records=0)
        try:
            if complement:
                union_a=union_b=0
                for mask,_,_ in self._maps[a]: union_a|=mask
                for mask,_,_ in self._maps[b]: union_b|=mask
                shared=union_a&union_b
                stats['shared_bits']=shared.bit_count()
                ticket=self._new_index()
                left=self._bucket(a,shared,ticket)
                right=self._bucket(b,shared,ticket)
                stats['index_records']=self._index_slots[ticket]
                for lm,rows in left.items():
                    for rm,cols in right.items():
                        self.visit('buckets')
                        stats['bucket_checks']+=1
                        if lm&rm: continue
                        for litem in rows:
                            for ritem in cols:
                                self.visit()
                                stats['compatible_record_visits']+=1
                                self._product(out,litem,ritem)
            else:
                for litem in self._maps[a].items():
                    for ritem in self._maps[b].items():
                        self.visit()
                        stats['record_visits']+=1
                        self._product(out,litem,ritem)
        except BaseException:
            self.drop(out)
            raise
        finally:
            if ticket is not None:
                self._drop_index(ticket)
        return out,stats

def exterior(reg,alpha):
    return o.assemble_coframe(reg,f.original_coframe_blocks(reg,alpha)).to_exterior(reg)

def rows(e):
    return (((mask,key,()),value) for mask,p in e.terms for key,value in p.terms)

def factors(reg):
    x=reg.sites[0]
    k,l,mu,nu,a,b=2,3,0,1,0,1
    anchor=(x,k)
    xk=reg.step(x,k)[0]
    anchors=(anchor,(xk,l),(reg.step(x,l)[0],k),(x,l))
    def link(site_axis):
        return f.original_spin4_link(*(tuple(P.variable(S('q',(*site_axis,chi,j)))
                                      for j in range(4)) for chi in ('L','R')))
    u=f.original_plaquette(reg,x,k,l,{z:link(z) for z in anchors})
    g=o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    trace=sum((u[i][j]*g[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))
    return (exterior(reg,(x,mu,a)),exterior(reg,(x,nu,b)),E(((0,trace),)),
            exterior(reg,(xk,k,0)),anchor)

def make_prefix(caps,actual):
    arena=Arena(caps)
    a,b=arena.ingest(rows(actual[0])),arena.ingest(rows(actual[1]))
    c,_=arena.join(a,b)
    arena.drop(a); arena.drop(b)
    t=arena.ingest(rows(actual[2]))
    return arena,c,t

def future_prefix(caps,actual):
    arena,c,t=make_prefix(caps,actual)
    future=arena.ingest(rows(actual[3]))
    d,_=arena.join(t,future,(c,))
    arena.drop(t); arena.drop(future)
    return arena,c,d

def attempt(arena,a,b,*,complement=False):
    before=arena.metric()
    try: arena.join(a,b,arena.retained(a,b),complement=complement)
    except Refusal as exc:
        after=arena.metric()
        assert after['live_records']==before['live_records']
        assert after['live_maps']==before['live_maps'] and not after['live_indexes']
        return dict(refused=exc.kind,at_visits=exc.visits,requested_live_records=exc.live,
                    released_partial_map_and_index=True,before=before,after=after)
    raise AssertionError('bounded refusal was required')

def oracle_input(reg,records,symbol):
    """Actual finite source phase labels, with one literal coefficient symbol."""
    phase_charges={}
    for i,(site,kind,_) in enumerate(reg.generator_order):
        v=reg.site_number(site)
        sign=1 if kind=='psi' else -1
        phase_charges[i]=tuple(sign*((v*(k+1)+k)%5-2) for k in range(5))
    for (mask,key,j),v in records:
        assert j==()
        indices=[i for i in range(mask.bit_length()) if mask>>i&1]
        a,b,aa,ab,bb=(sum(phase_charges[i][k] for i in indices) for k in range(5))
        vals=(Q(1),Q(0,a),Q(0,b),Q(-a*a,aa),Q(-a*b,ab),Q(-b*b,bb))
        for slot,m in zip(INDICES,vals,strict=True):
            if m:
                yield (mask,tuple(sorted((*key,symbol))),slot),v*m

def as_raw(records):
    return o.RawJet((0,1),tuple((slot,E(tuple(
        (mask,P(((key,value),))) for (mask,key,j),value in records.items() if j==slot
    ))) for slot in INDICES))

def from_raw(jet):
    return {(mask,key,slot):v for slot in INDICES for mask,poly in jet.at(slot).terms for key,v in poly.terms}

def oracle(reg,actual):
    stage,c,d=future_prefix(Caps(100_000,65_536),actual)
    cm,dm=stage.map(c),stage.map(d)
    # Preserve sectors with both compatible and incompatible masks. Prefer
    # right rows with at least one power on the shared actual anchor squared.
    anchor=actual[-1]
    selection=stage._new_index()
    chosen_right=[]
    for key,val in dm.items():
        if any(s.index[:2]==anchor and key[1].count(s)==2 for s in set(key[1])):
            if key[0] not in {k[0] for k,_ in chosen_right}:
                stage._index_admit(selection,1)
                chosen_right.append((key,val))
        if len(chosen_right)==6: break
    assert len(chosen_right)==6
    stage._index_admit(selection,len(chosen_right))
    right_masks=tuple(key[0] for key,_ in chosen_right)
    chosen_left=[]
    for key,val in cm.items():
        if any(key[0]&m for m in right_masks) and any(not key[0]&m for m in right_masks):
            if key[0] not in {k[0] for k,_ in chosen_left}:
                stage._index_admit(selection,1)
                chosen_left.append((key,val))
        if len(chosen_left)==8: break
    assert len(chosen_left)==8
    j_symbol=S('J',(reg.step(reg.sites[0],2)[0],2,0))
    l=stage.ingest(oracle_input(reg,chosen_left,S('g2',())))
    r=stage.ingest(oracle_input(reg,chosen_right,j_symbol))
    sizes=len(chosen_left),len(chosen_right)
    del chosen_left,chosen_right,right_masks,cm,dm
    stage._drop_index(selection)
    stage.drop(c); stage.drop(d)
    before=stage.metric()
    out,stats=stage.join(l,r,complement=True)
    exact=stage.map(out)
    reference=from_raw(as_raw(stage.map(l))*as_raw(stage.map(r)))
    assert exact==reference and exact
    assert any(len(slot)==2 and slot[0]==slot[1] for _,_,slot in exact)
    assert any(any(s.family=='q' and s.index[:2]==anchor and key.count(s)==2
                   for s in set(key)) for _,key,_ in exact)
    assert all(tuple(s for s in key if s.family!='q')==tuple(sorted((S('g2',()),j_symbol)))
               for _,key,_ in exact)
    return dict(nonzero_outputs=len(exact),output_by_raw_slot={
                    str(slot):sum(j==slot for _,_,j in exact) for slot in INDICES},
                output_shared_squared_coordinate=True,all_coefficients_match=True,
                left_base_slice=sizes[0],right_base_slice=sizes[1],literal_J_label=j_symbol.index,
                stats=stats,tracked_before_slice_join=before,tracked=stage.metric())

def guard_controls():
    invalid=(float('nan'),float('inf'),1.0,True,0,-1)
    for k in invalid:
        for c in (Caps(k,16),Caps(16,k)):
            try: Arena(c)
            except ValueError: pass
            else: raise AssertionError(k)
    atom=(((1,(),()),Q(1)),)
    later=(((2,(),()),Q(1)),)
    def arena():
        a=Arena(Caps(16,16))
        i,j,h=(a.ingest(atom),a.ingest(later),a.ingest(atom))
        return a,i,j,h
    bads=(lambda h:-1,lambda h:1.0,lambda h:False,lambda h:(),
          lambda h:(-1,),lambda h:(float('nan'),),lambda h:(h,h),
          lambda h:(h+100,),lambda h:(h,1),lambda h:[h])
    for bad in bads:
        a,i,j,h=arena()
        try: a.join(i,j,bad(h),complement=True)
        except ValueError: pass
        else: raise AssertionError(bad(h))
        assert a.metric()['visits']==0 and a.metric()['live_maps']==3
    corrupt=(('_used',-1),('_used',float('nan')),('_used',17),
             ('_used',True),('_live',-1),('_live',2),
             ('_peak',2),('_peak',float('nan')),('_peak',17))
    for field,value in corrupt:
        a,i,j,h=arena()
        setattr(a,field,value)
        try: a.join(i,j,(h,),complement=True)
        except ValueError: pass
        else: raise AssertionError((field,value))
    a,i,j,h=arena()
    a.visit()
    a._used=0  # Individually in range, inconsistent with the charged ledger.
    try: a.join(i,j,(h,),complement=True)
    except ValueError: pass
    else: raise AssertionError('in-range consumed-counter rollback')
    a,i,j,h=arena()
    a._index_slots[99]=-1
    try: a.join(i,j,(h,),complement=True)
    except ValueError: pass
    else: raise AssertionError('negative index slot state')
    for cap in (Caps(2,7),Caps(1,7),Caps(2,6)):
        a=Arena(cap)
        i,j=(a.ingest(atom),a.ingest(later))
        if cap==Caps(2,7):
            h,_=a.join(i,j,complement=True)
            assert dict(a.map(h))=={(3,(),()):Q(1)}
            assert a.metric()['visits']==2 and a.metric()['peak_records']==7
            try: a.visit()
            except Refusal as e: assert e.kind=='visits' and e.visits==2
            else: raise AssertionError('exact visit cap bypassed')
        else:
            r=attempt(a,i,j,complement=True)
            assert r['refused']==('visits' if cap.visits==1 else 'records')
    a=Arena(Caps(1,1))
    i=a.ingest(atom)
    h,_=a.join(i,i)
    assert not a.map(h) and a.metric()['peak_records']==1
    return dict(invalid_caps=2*len(invalid),invalid_retained=len(bads),
                corrupted_counter_states=len(corrupt)+2,exact_cap_and_overflow=True,
                aliased_operand_storage_counted_once=True)

def main():
    reg=o.OriginalRegulator()
    actual=factors(reg)
    reference=oracle(reg,actual)
    eager,c,t=make_prefix(Caps(200_000,32_768),actual)
    eager_counts=(len(eager.map(c)),len(eager.map(t)))
    eager_refusal=attempt(eager,c,t)
    eager.drop(c); eager.drop(t)
    del eager
    visit,c,t=make_prefix(Caps(8192,65_536),actual)
    visit_refusal=attempt(visit,c,t)
    visit.drop(c); visit.drop(t)
    del visit
    stage,c,d=future_prefix(Caps(200_000,65_536),actual)
    cm,dm=stage.map(c),stage.map(d)
    union_c=union_d=0
    for mask,_,_ in cm: union_c|=mask
    for mask,_,_ in dm: union_d|=mask
    shared=union_c&union_d
    histogram=stage._new_index()
    def histogram_of(mapping):
        counts={}
        for mask,_,_ in mapping:
            m=mask&shared
            if m not in counts:
                stage._index_admit(histogram,1)
                counts[m]=1
            else:
                counts[m]+=1
        return counts
    lc=histogram_of(cm)
    rc=histogram_of(dm)
    compatible=sum(n*m for a,n in lc.items() for b,m in rc.items() if not a&b)
    counts=len(cm),len(dm)
    buckets=len(lc),len(rc)

    x=reg.sites[0]
    axis0,axis1=0,1
    shared_site=255<<(8*reg.site_number(x))
    neighbor0=255<<(8*reg.site_number(reg.step(x,axis0)[0]))
    neighbor1=255<<(8*reg.site_number(reg.step(x,axis1)[0]))
    private_coframe_sites=neighbor0|neighbor1
    assert shared==shared_site
    assert not any(mask&private_coframe_sites for mask,_,_ in dm)
    assert all(slot==() and all(s.family=='q' and s.index[1] in (axis0,axis1)
                               for s in key) for _,key,slot in cm)
    assert all(slot==() and all(s.family=='q' and s.index[1] in (2,3)
                               for s in key) for _,key,slot in dm)
    # Recover the complete coframe record from the output's private
    # endpoint bits and its exact direction-0/1 quaternion multiset.
    recovered={}
    partitions={}
    for mask,key,_ in cm:
        recovery=(mask&private_coframe_sites,key)
        assert recovery not in recovered
        stage._index_admit(histogram,1)
        recovered[recovery]=mask
        partition=(mask&neighbor0,key)
        if partition not in partitions:
            stage._index_admit(histogram,1)
            partitions[partition]=(0,0)
        n,work=partitions[partition]
        partitions[partition]=(n+1,work+sum(v for m,v in rc.items() if not mask&m))
    assert len(recovered)==counts[0] and sum(w for _,w in partitions.values())==compatible
    selected=min(partitions,key=lambda key:(-partitions[key][1],key))
    selected_rows,selected_work=partitions[selected]
    partition_count=len(partitions)
    del cm,dm,lc,rc,recovered,partitions
    stage._drop_index(histogram)
    assert compatible and compatible<counts[0]*counts[1]
    continuation_refusal=attempt(stage,c,d,complement=True)

    # One complete recoverable output partition, with the entire
    # original shared-anchor right map retained. This is not a sample
    # within the partition, and it does not change the original key.
    sl=stage.ingest((key,value) for key,value in stage.map(c).items()
                    if (key[0]&neighbor0,key[1])==selected)
    assert len(stage.map(sl))==selected_rows
    before_partition=stage.metric()
    part,part_stats=stage.join(sl,d,(c,),complement=True)
    assert len(stage.map(part))==selected_work==part_stats['compatible_record_visits']
    assert all((mask&neighbor0,tuple(s for s in key if s.index[1] in (axis0,axis1)))==selected
               for mask,key,_ in stage.map(part))
    next_partition=dict(partition_count=partition_count,selected_left_records=selected_rows,
                        selected_complete_output_records=selected_work,
                        before=before_partition,after=stage.metric(),stats=part_stats)
    print(json.dumps(dict(local_alternatives=ALTERNATIVES,
      oracle=reference,typed_guards=guard_controls(),
      original_eager_records=eager_counts,original_eager_refusal=eager_refusal,
      original_eager_visit_refusal=visit_refusal,
      continuation=dict(records=counts,shared_bits=shared.bit_count(),
        exact_compatible_record_pairs_before_coalescing=compatible,
        distinct_full_output_keys_by_actual_projection_injectivity=compatible,
        exact_excluded_record_pairs=counts[0]*counts[1]-compatible,
        mask_buckets=buckets,mask_bucket_pair_checks=buckets[0]*buckets[1],
        unrestricted_materialization=continuation_refusal,complete_largest_recoverable_partition=next_partition),
      native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
      native_peak_unit='bytes' if sys.platform=='darwin' else 'KiB'),indent=2))
if __name__=='__main__':
    main()
