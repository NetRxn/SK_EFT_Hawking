from collections import Counter, defaultdict
from itertools import product
from math import factorial
import importlib.util
import json
import sys
from src.vestigial import original_coefficients as o

module = importlib.util.spec_from_file_location("r2author", "/tmp/publication-task4-shared-anchor-r2.py")
a = importlib.util.module_from_spec(module)
sys.modules[module.name] = a
module.loader.exec_module(a)
reg = o.OriginalRegulator()
x = reg.sites[0]
x2 = reg.step(x, 2)[0]
atom, second, curvature, future, anchor = a.factors(reg)
left_poly = atom * second
right_poly = curvature * future
left = dict(a.rows(left_poly))
right = dict(a.rows(right_poly))
def local_mask(site):
    return sum(1 << index for index, (s, _, _) in enumerate(reg.generator_order) if s == site)
root = local_mask(x)
private0 = local_mask(reg.step(x, 0)[0])
private1 = local_mask(reg.step(x, 1)[0])
private = private0 | private1
assert len(left) == 3584 and len(right) == 8192
assert all(not mask & private and not slot and all(s.family == 'q' and s.index[1] in (2, 3) for s in key)
           for mask, key, slot in right)
assert all(not slot and all(s.family == 'q' and s.index[1] in (0, 1) for s in key)
           for mask, key, slot in left)
recovery = {(mask & private, key): mask for mask, key, _ in left}
assert len(recovery) == len(left)
right_mask_counts = Counter(mask & root for mask, _, _ in right)
def right_compatible(mask):
    available = root & ~mask
    value = available
    total = right_mask_counts[value]
    while value:
        value = (value - 1) & available
        total += right_mask_counts[value]
    return total

partition = defaultdict(list)
work = Counter()
for row in left:
    mask, key, slot = row
    label = (mask & private0, key)
    partition[label].append(row)
    work[label] += right_compatible(mask)
select = min(work, key=lambda k: (-work[k], k))
assert len(partition) == 1024 and len(partition[select]) == 4
assert work[select] == 24576 and work.total() == 22020096

def indices(mask):
    return tuple(i for i in range(mask.bit_length()) if (mask >> i) & 1)

def direct(lhs, rhs):
    out = defaultdict(o.QComplex)
    for ((lm, lk, ls), lv), ((rm, rk, rs), rv) in product(lhs.items(), rhs.items()):
        li, ri = indices(lm), indices(rm)
        if set(li) & set(ri) or len(ls) + len(rs) > 2:
            continue
        s = tuple(sorted(ls + rs))
        factor = 1
        for label in set(s):
            factor *= factorial(s.count(label)) // (factorial(ls.count(label)) * factorial(rs.count(label)))
        neg = sum(i > j for i, j in product(li, ri)) % 2
        out[lm|rm,tuple(sorted(lk+rk)),s] += lv * rv * (-factor if neg else factor)
    return {k: v for k, v in out.items() if v}

selected = {row: left[row] for row in partition[select]}
expected = direct(selected,right)
stage = a.Arena(a.Caps(60_000,65_536))
left_handle = stage.ingest(left.items())
lh = stage.ingest(selected.items())
rh = stage.ingest(right.items())
part, details = stage.join(lh,rh,(left_handle,),complement=True)
assert expected == dict(stage.map(part))
assert len(expected) == 24576
assert stage.metric()['peak_records'] == 44562
for mask, key, _ in expected:
    low = tuple(s for s in key if s.index[1] in (0,1))
    high = tuple(s for s in key if s.index[1] in (2,3))
    lm = recovery[mask & private, low]
    assert (lm,low,()) in left and (mask ^ lm,high,()) in right

base_right = {}
for row in reversed(right):
    mask, key, _ = row
    if mask not in {m for m, _, _ in base_right} and any(
            sym.index[:2] == anchor and key.count(sym) == 2 for sym in key):
        base_right[row] = right[row]
        if len(base_right) == 6:
            break
base_left = {}
for row in reversed(left):
    mask, _, _ = row
    rs = tuple(m for m, _, _ in base_right)
    if (mask not in {m for m, _, _ in base_left} and any(mask & m for m in rs)
            and any(not mask & m for m in rs)):
        base_left[row] = left[row]
        if len(base_left) == 8:
            break
assert (len(base_left), len(base_right)) == (8, 6)
charged_left = dict(a.oracle_input(reg,base_left.items(),o.Symbol('g2',())))
charged_right = dict(a.oracle_input(reg,base_right.items(),o.Symbol('J',(x2,2,0))))
desired = direct(charged_left,charged_right)
probe = a.Arena(a.Caps(12_000,65_536))
i = probe.ingest(charged_left.items())
j = probe.ingest(charged_right.items())
k, _ = probe.join(i,j,complement=True)
assert desired == dict(probe.map(k))
assert set(slot for _,_,slot in desired) == set(a.INDICES)
assert any(s.index[:2] == anchor and key.count(s) == 2 for _,key,_ in desired
           for s in key if s.family == 'q')

# A failed complement join during bucket construction must restore live counts.
q = o.QComplex(1)
row = (((1,(),()),q),)
other = (((2,(),()),q),)
bounded = a.Arena(a.Caps(10,5))
u,v = bounded.ingest(row),bounded.ingest(other)
before = bounded.metric()
try:
    bounded.join(u,v,complement=True)
except a.Refusal as exc:
    assert exc.kind == 'records' and exc.visits == 0 and exc.live == 6
else:
    raise AssertionError('bucket allocation overflow was admitted')
after = bounded.metric()
assert all(before[key] == after[key] for key in ('visits','live_records','live_maps','live_indexes'))

# Document what the arena actually trusts outside the pinned calling discipline.
stale = a.Arena(a.Caps(10,1))
u = stale.ingest(row)
view = stale.map(u)
stale.drop(u)
v = stale.ingest(other)
assert stale.metric()['live_records'] == 1 and len(view) == len(stale.map(v)) == 1
for operation in ('map','drop'):
    alias = a.Arena(a.Caps(10,2))
    alias.ingest(row)
    getattr(alias,operation)(True)
serial = a.Arena(a.Caps(10,2))
serial.ingest(row)
serial._serial = 0
assert serial.new_map() == 1
try:
    serial.metric()
except ValueError:
    pass
else:
    raise AssertionError('serial collision left accounting falsely consistent')
print(json.dumps(dict(compatible=work.total(), rejected=len(left)*len(right)-work.total(),
                      partitions=len(partition), full_partition_exact_signed=len(expected),
                      full_partition_metric=stage.metric(), alternate_slice_signed=len(desired),
                      alternate_slice_slots={str(slot):sum(z==slot for _,_,z in desired) for slot in a.INDICES},
                      bucket_overflow_rollback=after,
                      promotion_limits=['escaped live map view','bool aliases in map/drop','serial collision only detected after mutation']),indent=2))
