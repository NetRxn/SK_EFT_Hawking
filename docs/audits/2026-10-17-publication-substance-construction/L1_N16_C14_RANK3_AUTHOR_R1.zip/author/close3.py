"""Exact factored original rank-3 S4 closure and final plane-01 trace sewing."""
from collections import defaultdict
from functools import cache
from itertools import permutations,product
from pathlib import Path
import json,sys

D=Path(__file__).parent
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
TWO=Path('/tmp/publication-c14-rank-zero-r1.gte6BM')
PRIOR=Path('/tmp/publication-c14-rank4-r1.i7hYiY')
sys.path.insert(0,str(STAR))
import cut

ZERO=(0,0)
A01=((0,2),(0,3),(2,3),(1,2))
LOCAL_DEN=64**2*768**2
CONTROL_DEN=LOCAL_DEN*4**2

def read(path):
    with path.open() as f:
        for s in f:
            cut.work('frozen_read')
            yield json.loads(s)

def addrow(tab,k,z,name):
    cut.reserve(name,k,tab)
    tab[k]=cut.add(tab.get(k,ZERO),z)

def parity(word):
    return (-1)**sum(a>b for i,a in enumerate(word) for b in word[i+1:])

def bits(site,mask):
    return [8*site+i for i in range(8) if mask>>i&1]

def edges():
    desc=cut.star_owners(cut.roster(),3)
    out=[]
    for d,n in zip(desc,(11,7,1,2),strict=True):
        axis,r,frames,traces=d
        assert r==n and frames==[('S4',3,0,axis),('S4',3,1,axis)]
        expected=[] if axis<2 else [('S2',0,j,(n,axis)) for j in (0,1)]
        assert traces==expected
        a,da,sa=cut.edge_tensor(d,3,False)
        b,db,sb=cut.edge_tensor(d,3,True)
        assert a==b and da==db and sa==sb
        assert (len(a),da,sa)==((48,64,16) if axis<2 else (14208,768,240))
        cut.write_rows(f'rank3-axis{axis}.jsonl',a)
        out.append(a)
        print('rank3 edge',axis,len(a),flush=True)
    return out,desc

def ordered_epsilon():
    out=defaultdict(dict)
    for f in cut.original_action_factors_cached(cut.REG.sites[3]):
        if f.t_degree==4:
            cut.work('ordered_epsilon_read')
            assert tuple(mu for _,mu,_ in f.components)==(0,1,2,3)
            a,b,c,d=(a for _,_,a in f.components)
            ((sym,z),)=f.coefficient.terms
            assert not sym and not z.imag and z.real==parity((a,b,c,d))
            cut.reserve('ordered_epsilon',(c,d),out[a,b])
            out[a,b][c,d]=int(z.real)
    assert len(out)==12 and {len(v) for v in out.values()}=={2}
    return out

def compact(e0,e1,source=None):
    out={}
    for (k,z),(j,w) in product(e0.items(),e1.items()):
        cut.work('compact_edge_pair')
        m,r11,a,b=k
        n,r7,c,d=j
        if m&n:
            continue
        if source is None:
            if a==c or b==d:
                continue
            first={(e,f):parity((a,c,e,f)) for e,f in permutations(sorted(set(range(4))-{a,c}))}
            second={(e,f):parity((b,d,e,f)) for e,f in permutations(sorted(set(range(4))-{b,d}))}
            sign=(-1)**cut.crossing(m,n)
        else:
            first=source.get((a,c),{})
            second=source.get((b,d),{})
            sign=parity(bits(3,m)+bits(11,r11)+bits(3,n)+bits(7,r7))
        for ((x,v),s),((y,t),u) in product(first.items(),second.items()):
            cut.work('compact_epsilon_pair')
            key=(m|n,x,y,v,t,r11,r7)
            addrow(out,key,cut.scale(cut.times(z,w),sign*s*u),'rank3_compact')
    return {k:z for k,z in out.items() if z!=ZERO}

def mask_projection(c,e2,e3):
    fused={k[0] for k in c}
    pairs={}
    for m,n in product(sorted({k[0] for k in e2}),sorted({k[0] for k in e3})):
        cut.work('site_projection')
        if m&n:
            continue
        t=255^(m|n)
        if t not in fused:
            continue
        sign=(-1)**(cut.crossing(t,m)+cut.crossing(t|m,n))
        assert sign==parity(bits(3,t)+bits(3,m)+bits(3,n))
        cut.reserve('rank3_projection',(t,m,n),pairs)
        pairs[t,m,n]=sign
    return pairs

def merge(e,site,oldfile):
    old={k[1] for k,z in read(oldfile)}
    new={k[1] for k in e}
    out={}
    for m,n in product(sorted(old),sorted(new)):
        cut.work('exterior_merge')
        if m&n:
            continue
        sign=(-1)**cut.crossing(m,n)
        assert sign==parity(bits(site,m)+bits(site,n))
        cut.reserve('exterior_merge',(m,n,m|n),out)
        out[m,n,m|n]=sign
    return out

def prior_trace():
    out=defaultdict(dict)
    for (u,v,a,b,r,s),z in read(TWO/'plane-01-trace.jsonl'):
        cut.reserve('trace_index',(r,s),out[u,v,a,b])
        out[u,v,a,b][r,s]=tuple(z)
    assert sum(map(len,out.values()))==1536
    return out

@cache
def raw_trace(k):
    u,v,a,b=k
    t={}
    for f in cut.raw_factors(cut.REG.sites[0],(0,1)):
        if any(x != (a if axis==0 else b) for _,axis,x in f.components):
            continue
        for symbols,z in f.coefficient.terms:
            cut.work('raw_original_trace')
            by={(cut.RANK[site],axis): i+4*(h=='R') for sym in symbols
                for site,axis,h,i in [sym.index]}
            assert set(by)==set(A01)
            x,y,r,s=(by[a] for a in A01)
            if (x,y)!=(u,v):
                continue
            zr,zi=z.real*4,z.imag*4
            assert zr.denominator==zi.denominator==1
            addrow(t,(r,s),(zr.numerator,zi.numerator),'raw_trace')
    return {k:z for k,z in t.items() if z!=ZERO}

def signs(old1,old2,local4,m2,m3,rem11,rem7,new1,new2):
    # Literal product of earlier open pairs, compact local axes 0/1
    # (already signed), followed by original rank3 axes 2/3.
    word=[]
    for site,m in ((1,old1),(2,old2),(5,3),(6,3),(9,3),(10,3),(13,3),(14,3)):
        word.extend(bits(site,m))
    word+=bits(3,local4)+bits(11,rem11)+bits(7,rem7)
    word+=bits(1,new1)+bits(3,m2)+bits(2,new2)+bits(3,m3)
    assert len(set(word))==len(word)
    return parity(word)

def compare(e0,e1,e2,e3,compact,projection,merges,ordered,trace):
    by2=defaultdict(list)
    by3=defaultdict(list)
    conditioned=(defaultdict(list),defaultdict(list))
    for e,index,fixed in ((e2,by2,conditioned[0]),(e3,by3,conditioned[1])):
        for (m,r,a,b,x,y),z in e.items():
            cut.work('index_degree4_component')
            cut.reserve('degree4_control_index',len(index[a,b]),{})
            index[a,b].append((m,r,x,y,z))
            cut.reserve('conditioned_degree4_index',len(fixed[a,b,r]),{})
            fixed[a,b,r].append((m,r,x,y,z))
    prekeys=defaultdict(list)
    for k,v in trace.items():
        for rs in v:
            cut.work('index_trace_control')
            if len(prekeys[rs])<6:
                cut.reserve('trace_witness_index',len(prekeys[rs]),{})
                prekeys[rs].append(k)
    merge_lookup=[]
    for m in merges:
        lookup=defaultdict(list)
        for (old,n,f),z in m.items():
            cut.work('index_merge_control')
            cut.reserve('merge_control_index',len(lookup[n]),{})
            lookup[n].append((old,f,z))
        merge_lookup.append(lookup)
    checked=[]
    seen=set()
    for (t,a,b,c,d,r11,r7),z in sorted(compact.items()):
        cut.work('select_compact_control')
        for (m,n,s0,s1,_),(p,q,r0,r1,_) in product(by2[a,b],by3[c,d]):
            cut.work('control_find_edge_context')
            if (t,m,p) not in projection or not merge_lookup[0][n] or not merge_lookup[1][q]:
                continue
            old1,fused1,_=merge_lookup[0][n][0]
            old2,fused2,_=merge_lookup[1][q][0]
            for k0,k1 in product(prekeys[r0,s0],prekeys[r1,s1]):
                cut.work('control_find_trace_context')
                spec=(old1,old2,fused1,fused2,r11,r7,k0,k1)
                if spec in seen or k0==k1:
                    continue
                cut.reserve('control_seen',spec,seen)
                seen.add(spec)
                sgn1=merges[0][old1,n,fused1]
                sgn2=merges[1][old2,q,fused2]
                t0,t1=trace[k0],trace[k1]
                result=alias=ZERO
                first=None
                paths=0
                for (tf,a,b,c,d,x,y),z in compact.items():
                    cut.work('fixed_compact_lookup')
                    if (x,y)!=(r11,r7):
                        continue
                    for (m,u,s0,s1,g),(p,v,r0,r1,h) in product(conditioned[0][a,b,n],conditioned[1][c,d,q]):
                        cut.work('factored_fixed_junction')
                        if (u,v)!=(n,q):
                            continue
                        sg=projection.get((tf,m,p),0)
                        if not sg:
                            continue
                        pref=cut.scale(cut.times(cut.times(z,g),h),sg*sgn1*sgn2)
                        v0=t0.get((r0,s0),ZERO)
                        v1=t1.get((r1,s1),ZERO)
                        v2=t1.get((r0,s0),ZERO)
                        val=cut.times(pref,cut.times(v0,v1))
                        alias=cut.add(alias,cut.times(pref,cut.times(v0,v2)))
                        if val!=ZERO:
                            paths+=1
                            if first is None:
                                first=val
                        result=cut.add(result,val)
                if result==ZERO:
                    continue
                rtrace0,rtrace1=raw_trace(k0),raw_trace(k1)
                assert rtrace0==t0 and rtrace1==t1
                direct=ZERO
                for (k,g),(l,h) in product(e0.items(),e1.items()):
                    cut.work('raw_fixed_first_edges')
                    m0,n0,a,b=k
                    m1,n1,c,d=l
                    if (n0,n1)!=(r11,r7) or m0&m1:
                        continue
                    eps0=ordered.get((a,c),{})
                    eps1=ordered.get((b,d),{})
                    for ((a2,a3),p0),((b2,b3),p1) in product(eps0.items(),eps1.items()):
                        cut.work('raw_fixed_epsilons')
                        for (m2,u,s0,s1,z2),(m3,v,r0,r1,z3) in product(conditioned[0][a2,b2,n],conditioned[1][a3,b3,q]):
                            cut.work('raw_fixed_last_edges')
                            if (u,v)!=(n,q) or (m2&m3) or (m0|m1)&(m2|m3):
                                continue
                            assert (m0|m1|m2|m3)==255
                            sg=signs(old1,old2,m0|m1,m2,m3,r11,r7,n,q)
                            sg*=parity(bits(3,m0)+bits(3,m1))
                            vv=cut.times(cut.times(g,h),cut.times(z2,z3))
                            vv=cut.times(vv,cut.times(rtrace0.get((r0,s0),ZERO),rtrace1.get((r1,s1),ZERO)))
                            direct=cut.add(direct,cut.scale(vv,sg*p0*p1))
                assert direct==result
                cut.reserve('control_result',len(checked),{})
                checked.append(dict(old_masks=[old1,old2],new_masks=[n,q],
                    fused_masks=[fused1,fused2],remote11=r11,remote7=r7,
                    trace0_fixed=k0,trace1_fixed=k1,signed_numerator=result,
                    false_occurrence_alias_numerator=alias,nonzero_factored_paths=paths,
                    adverse_single_path_flip_numerator=cut.add(result,cut.scale(first,-2)),
                    denominator=CONTROL_DEN))
                if len(checked)==4:
                    return checked
    raise AssertionError(('rank3 junction controls',len(checked)))

def graph():
    g=json.loads((PRIOR/'graph.json').read_text())
    repl={'remote1':'old_mask1','remote2':'old_mask2'}
    for k,v in g['factor_keys'].items():
        g['factor_keys'][k]=[repl.get(x,x) for x in v]
    g['factor_keys'].update(rank3_compact=['fused_mask3','S4_3_a2_0','S4_3_a2_1',
        'S4_3_a3_0','S4_3_a3_1','remote11','remote7'],
        rank3_edge2=['edge2_mask3','new_mask1','S4_3_a2_0','S4_3_a2_1','q12_0','q12_1'],
        rank3_edge3=['edge3_mask3','new_mask2','S4_3_a3_0','S4_3_a3_1','q23_0','q23_1'],
        rank3_projection=['fused_mask3','edge2_mask3','edge3_mask3'],
        merge_rank1=['old_mask1','new_mask1','remote1'],
        merge_rank2=['old_mask2','new_mask2','remote2'])
    g['boundary']=[x for x in g['boundary'] if x not in ('q12_0','q12_1','q23_0','q23_1')]+['remote11','remote7']
    g['combined_denominator']*=LOCAL_DEN
    g['semantics']+=' rank3_compact applies both ordered rank3 S4 epsilons. rank3_projection and both new exterior merges are signed factors. rank3_edge2 and rank3_edge3 jointly sew the last four original trace coordinate slots.'
    (D/'graph.json').write_text(json.dumps(g,indent=2)+'\n')
    return g['combined_denominator']

def main():
    cut.OUT=D
    cut.ROW_CAP=200_000
    cut.BYTE_CAP=128*1024*1024
    cut.rss()
    (e0,e1,e2,e3),owners=edges()
    eps=ordered_epsilon()
    c=compact(e0,e1)
    raw=compact(e0,e1,eps)
    assert c==raw and c
    p=mask_projection(c,e2,e3)
    m=(merge(e2,1,TWO/'zero-edge-3.jsonl'),merge(e3,2,TWO/'zero-edge-2.jsonl'))
    for name,t in (('rank3-compact',c),('rank3-projection',p),('merge-rank1',m[0]),('merge-rank2',m[1])):
        cut.write_rows(name+'.jsonl',t)
    print('compact/projection/merges',len(c),len(p),[len(x) for x in m],flush=True)
    trace=prior_trace()
    controls=compare(e0,e1,e2,e3,c,p,m,eps,trace)
    den=graph()
    cut.rss()
    out=dict(owners=owners,edge_rows=[len(x) for x in (e0,e1,e2,e3)],
        compact_rows=len(c),projection_rows=len(p),merge_rows=list(map(len,m)),
        local_denominator=LOCAL_DEN,graph_denominator=den,controls=controls,
        charged_operations=dict(cut.WORK),storage=dict(cut.STORE),rss_peak_bytes=cut.RSS_PEAK,
        cap=dict(rows=cut.ROW_CAP,work=cut.WORK_CAP,accounted_bytes=cut.BYTE_CAP,
                 serialized_bytes=cut.FILE_CAP,sampled_rss=cut.RSS_CEILING,scalar=cut.INT_LIMIT))
    (D/'result.json').write_text(json.dumps(out,indent=2)+'\n')
    print('validated',len(controls),'junctions',flush=True)

if __name__=='__main__':
    main()
