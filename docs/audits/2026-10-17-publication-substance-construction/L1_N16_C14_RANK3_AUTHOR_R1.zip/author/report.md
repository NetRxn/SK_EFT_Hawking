# Exact original N16 c14 rank-3 closure and final trace sewing

The authority is original periodic closed source_C at clean primary
27012c18fa374e8341e124b510abbedeedb18d29. The raw rank-3 edge and
trace work is independent of rank 4. The attached graph uses the
rank-4 package whose independent acceptance was frozen before this
handoff. The cut uses the zero-centered (01,01,23,23) representative
and keeps its external exponential divisor 512.

All eight rank-3 coframes belong to its own two original S4
occurrences. The degree-two axes 0 and 1 reach ranks 11 and 7
and have 48 rows each at denominator 64. The degree-four axes 2
and 3 reach ranks 1 and 2 and have 14,208 rows each at denominator
768. The last two ordered plane-01 trace slots attach at the
original directed anchors (1,2) and (2,3), respectively. Every
new Haar table matches the exact raw signed quarter-increment and
independent moment comparator. Each original trace occurrence
retains its distinct occurrence index.

The two degree-two edges and the two ordered rank-3 epsilons
give a 2,016-row compact factor. Its slots are the fused
rank-3 pair of pairs, ordered axis-2 components, ordered
axis-3 components, and open rank-11 and rank-7 masks. It
carries the signed ordering within the two degree-two edges.
A 108-row signed projection joins it to the other two rank-3
masks, requiring disjoint coverage of all eight generators.
Each exterior endpoint at ranks 1 and 2 has a complete 420-row
signed merge table, closing neither endpoint and retaining its
four-generator union. Serialized readback independently
reconstructs the complete compact and projection factors and
both exterior merges.

The graph consumes all four remaining q slots in the two
original plane-01 traces. The axes 2 and 3 supply q12 and q23,
respectively, while the original source trace table retains
its ordered key convention. The graph leaves the other
earlier factors factored, closes rank 3, and keeps the rank-1,
rank-2, rank-7 and rank-11 exterior masks. The denominator
multiplier for the new local factors is 2,415,919,104. The
combined graph denominator before 512 is
8,721,064,880,344,833,042,121,878,122,499,340,763,136.

## Exact controls and capacity

Four fixed junctions sum the complete matching new edge,
ordered epsilon, mask and plane-01 trace factors under the
declared fixed earlier trace keys and remote exterior masks.
A distinct route starts from the two degree-two edges, traverses
both original ordered S4 epsilons, re-extracts both raw ordered
plane-01 trace coefficients at fixed earlier labels, and uses
literal 128-position exterior signs. Both routes give, in order,
-3/32, 3/32, -3/32, and 3/32, each with 48 nonzero compact paths.
Reversing a single recorded path gives magnitude 23/256 instead
of 3/32. The attempted coordinate-reuse adverse case is inert
on these four slices, so the signed path negative is the
distinguishing control here. The raw trace calculation retains
separate slots and independently matches the accepted plane-01
coefficients. The earlier source-junction reviews include
distinguishing anchor and occurrence adverse controls.

The first fixed-junction schedule iterated degree-four rows
before restricting their actual remote masks and refused at
operation 4,000,001. Its run and code are retained. The
successful schedule indexes the actual remote masks before
iterating. It charged 468,048 operations against 4,000,000 and
138,800 cumulative entries against 200,000. It used 71,065,600
accounting bytes against 128 MiB and 784,688 exact serialized
bytes against 4 MiB. The checked integer cap is 2^61−1.
Sampled process peak RSS was 136,265,728 bytes under the
sampled 384 MiB guard. Accounting excludes source initialization,
interpreter overhead, secondary indexing and sorting, and
separate readback. No full graph boundary value or representative
coefficient was evaluated.

## Verified degree-two structure and batch route

Eight already built degree-two edge tables were read exactly.
Each has precisely 12 exterior mask pairs. For each pair there
are four nonzero entries with ordered component labels
(a,a), a=0,1,2,3, with equal exact signed numerators. There
are no off-diagonal entries. This is the criterion to check
for each remaining original raw degree-two edge.

When all four paired coframe edges of a site satisfy that
criterion, the two original ordered S4 component tuples are
identical. Their epsilon product is 1 exactly on the 24
permutations and vanishes elsewhere. Since every edge value
is independent of the component label at each allowed mask
pair, summing the two epsilons and their common component
tuple gives an exact factor of 24 for that site. This removes
component labels without changing exterior signs or masks.

| S4 site | Original degree-two edge tables still to verify |
| --- | --- |
| 5 | (5,13) axis 0, (1,5) axis 1, (5,7) axis 2 |
| 6 | (6,14) axis 0, (2,6) axis 1, (6,7) axis 3 |
| 9 | (1,9) axis 0, (9,13) axis 1, (9,11) axis 2 |
| 10 | (2,10) axis 0, (10,14) axis 1, (10,11) axis 3 |
| 15 | (7,15) axis 0, (11,15) axis 1, (13,15) axis 2, (14,15) axis 3 |

All sixteen listed edges need raw-source comparison. If the
criterion holds on them, these five sites admit the exact
component elimination and leave twelve-state signed exterior
edge tables. The remaining rank-1 and rank-2 exterior closures
then each need two degree-two pairs. Other axis arrangements,
representative values, c14, c0, complete denominator and
normalization remain open.
