"""Check serialized rank3 factor keys and exact diagonal-equal degree-two criterion."""
from collections import defaultdict
from itertools import permutations,product
from pathlib import Path
import json

D=Path(__file__).parent
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
R4=Path('/tmp/publication-c14-rank4-r1.i7hYiY')
R12=Path('/tmp/publication-c14-rank12-r1.ehXXAy')
TWO=Path('/tmp/publication-c14-rank-zero-r1.gte6BM')

def rows(p):
    return [json.loads(s) for s in p.read_text().splitlines()]

def tab(p):
    out={}
    for k,z in rows(p):
        assert tuple(k) not in out
        out[tuple(k)]=tuple(z) if isinstance(z,list) else z
    return out

def bits(m):
    return [i for i in range(8) if m>>i&1]

def sign(w):
    return (-1)**sum(x>y for i,x in enumerate(w) for y in w[i+1:])

def times(z,w):
    a,b=z
    c,d=w
    return a*c-b*d,a*d+b*c

def add(z,w):
    return z[0]+w[0],z[1]+w[1]

def scale(z,s):
    return s*z[0],s*z[1]

edge=[tab(D/f'rank3-axis{i}.jsonl') for i in range(4)]
c={}
orders=list(permutations(range(4)))
for (m,r,a,b),z in edge[0].items():
    for (n,s,x,y),w in edge[1].items():
        if m&n:
            continue
        for u in orders:
            if u[:2]!=(a,x):
                continue
            for v in orders:
                if v[:2]!=(b,y):
                    continue
                k=(m|n,u[2],v[2],u[3],v[3],r,s)
                c[k]=add(c.get(k,(0,0)),scale(times(z,w),sign(bits(m)+bits(n))*sign(u)*sign(v)))
assert c==tab(D/'rank3-compact.jsonl')
proj={}
for t in {k[0] for k in c}:
    for m in {k[0] for k in edge[2]}:
        for n in {k[0] for k in edge[3]}:
            w=bits(t)+bits(m)+bits(n)
            if len(set(w))==len(w)==8:
                proj[t,m,n]=sign(w)
assert proj==tab(D/'rank3-projection.jsonl')
for i in (1,2):
    old={k[1] for k,z in rows(TWO/f'zero-edge-{4-i}.jsonl')}
    new={k[1] for k in edge[i+1]}
    merged={(m,n,m|n):sign(bits(m)+bits(n)) for m,n in product(old,new) if not m&n}
    assert merged==tab(D/f'merge-rank{i}.jsonl')

def diagonal(p):
    out=defaultdict(dict)
    for (m,n,a,b),z in tab(p).items():
        assert a==b and z!=(0,0)
        out[m,n][a]=z
    assert len(out)==12
    assert all(set(v)==set(range(4)) and len(set(v.values()))==1 for v in out.values())
    return str(p)

verified=[diagonal(p) for p in (
    STAR/'edge-2.jsonl',STAR/'edge-3.jsonl',
    R4/'rank4-edge-axis2.jsonl',R4/'rank4-edge-axis3.jsonl',
    R12/'edge12-axis2.jsonl',R12/'edge12-axis3.jsonl',
    D/'rank3-axis0.jsonl',D/'rank3-axis1.jsonl')]
print(json.dumps(dict(compact_rows=len(c),projection_rows=len(proj),
    signed_merge_rows=[420,420],verified_diagonal_equal_tables=verified,
    remaining_pure_S4_sites={
      '5':[[5,13,0],[1,5,1],[5,7,2]],
      '6':[[6,14,0],[2,6,1],[6,7,3]],
      '9':[[1,9,0],[9,13,1],[9,11,2]],
      '10':[[2,10,0],[10,14,1],[10,11,3]],
      '15':[[7,15,0],[11,15,1],[13,15,2],[14,15,3]]},
    missing_edges=16),indent=2))
