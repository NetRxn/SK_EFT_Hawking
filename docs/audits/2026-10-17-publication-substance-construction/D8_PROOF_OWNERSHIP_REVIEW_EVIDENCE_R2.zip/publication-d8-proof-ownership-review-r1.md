# Independent D8 proof correspondence and ownership review R1

**REVISE D8 1.2. ACCEPT the scoped D8 1.1 and 1.3 source repairs.** The Read–Rezayi density arguments and the two actual theorem registrations are sound. The new length descriptions conflate the recurrence-level counter with the emitted word.

Initial continuity returned exit 0, `fresh=true`, `changed=[]` at clean MAIN `44a8eeb801591175894bd7e55ebc01965dafffc2`. I independently applied the exact `df5814508` donor patch for the charter, D8 manuscript and D8 metadata to copies of the current preimages. All three full postimages match the scratch packet. D9 is exactly one line changed, carrying the donor ownership sentence into the current continuation. No other text, metadata, figures, Lean files, counters, registry or ledger changes are present.

| Scratch postimage | SHA256 |
| --- | --- |
| Charter | `62110e70a1cf7e752346dd7447a9f303192d98eb4d92951bcf88714bb685e717` |
| D8 manuscript | `20b1d07c9ee77c0a5f47a511b692d40674611c23badf52f602e6ada69cf4c9e1` |
| D8 metadata | `f10d62af43f506664206edeba2454c994853c07c5be6948bb0fc893763768b9f` |
| D9 manuscript | `a5b27fcf3c4e842b996f585124c046ba406c2101129ba9320b99b894ee6742de` |

D8 1.1 removes the contradictory transfer of the Fibonacci-specific work. The charter retains D4's Fibonacci and topological scope and D8's general compilation role. Current D4 and proposed D8 apex sets have no full-name or short-name overlap. D8 1.3 treats the Kronecker-with-identity norm lemma as consumed from D9 certification rather than as D8's contribution. D9's rendered ownership statement and D8's existing companion prose agree.

For RR5 and RR7, the actual H_SU matrix is i/√2 times the real Hadamard sign matrix, and the two T matrices have diagonal phases exp(−iθ), exp(iθ) at θ=π/14,π/18. The trace is therefore √2 sin θ and its square is 1−cos(2θ). Finite order would force the trace and hence the cosine to be algebraic integers. RR5's Chebyshev factorization forces 2x³−x²−x=−1/4 at x=cos(π/7) because x+1 is nonzero. RR7's triple-angle identity forces 4x³−3x=1/2 at x=cos(π/9). The rational noninteger contradictions agree with the actual infinite-order proof route. The two Pauli analyses and density witnesses feed their distinct compiler instances.

Both proposed apex entries are the exact donor `…rr5_strict_constructive_tight` and `…rr7_strict_constructive_tight` names. Each actual type assumes 0<ε≤ε₀ and proves the matrix error of its respective compile word plus `skLength (skLevel_polylog ε) ≤ skLengthConst * (Real.log (1/ε)) ^ skLengthExponent`. The second conjunct has no dependency on the returned word. Calling it a compiler word-length bound in the new metadata and §IV paragraph presents more than these declarations prove. Preserve the recurrence apexes with precise wording and, for the full emitted-word claim, use the distinct unconditional concrete constructive theorems in the two BaseFinder modules after checking their actual types, constants and witness distinction. The metadata and proof index should preserve both forms without suggesting runtime executability. No missing-proof inference or Lean action was made.

I independently executed all three exact original Verify commands on current MAIN and scratch. Each returned exit 1 at baseline and exit 0 on the candidate, with empty stdout/stderr. The 1.2 command checks name presence and therefore misses the demonstrated statement mismatch. Donor `991da7cf8` preserves three historical closure receipts, but its 1.2 receipt cannot settle that mismatch. ROOT owns any adoption and canonical closure on the accepted composition.

I independently rasterized and inspected the pinned scratch D8 pp. 5 and 12 and D9 p. 13. The changed RR paragraphs, both wrapped new theorem names and D9 ownership text are visible and legible. The D8 pages still show nearby unchanged layout problems: Table II extends into the right column on p. 5 and existing long proof-index identifiers cross into the right-column table on p. 12. Those source blocks are unchanged by this packet. A compile receipt alone does not establish page-wide layout quality. D8 PDF SHA256 is `b1871d72b78f1a0ee76c9cdd8a4a456f3fe2e52350ce5bebe817ee5526e3c9c3`. D9 PDF SHA256 is `2986889d5eed40227b6e782092cdb221e1aa0b7ef8a4d2ff609115000919626b`. No repository edits, builds, ledger changes or Lean actions occurred.

Final continuity returned `fresh=true`, `changed=[]` for the same frozen candidate.
