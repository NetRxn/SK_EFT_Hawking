from concurrent.futures import ProcessPoolExecutor
from gzip import compress
from hashlib import sha256
from pathlib import Path
from pickle import dumps,loads
from runpy import run_path
from sys import path

root=Path(__file__).resolve().parent
prior=Path('/private/tmp/l1-paired-reuse-screen.ugYgXU')
path.insert(0,str(prior))
from edge_relabel import model
from signed_gauge import search_gauge
verify=run_path(str(prior/'verify-witnesses.py'))['verify']
early=(prior/'verify-early.py').read_text()
namespace={'dumps':dumps,'loads':loads}
exec(early[early.index('class MemoryOperand'):early.index('def initial')],namespace)

def find(target):
    members=[root/f'join-cap-dense-label-sum{i}-reduced.pkl' for i in (2,target)]
    inputs=[model(p) for p in members]
    witness,reason=search_gauge(*inputs)
    if witness is None:
        return target,'no map',repr(reason)
    payload=root/f'cut2-{target}-cap-map.pkl.gz'
    with payload.open('xb') as out:
        out.write(compress(dumps(witness,protocol=5),mtime=0))
    exact=members
    if reason[0]=='trim':
        prepared=[namespace['prune'](p) for p in members]
        assert prepared[0][1]==prepared[1][1]
        exact=[item[0] for item in prepared]
    counts=verify(*exact,payload,True)
    return target,reason[0],*(sha256(p.read_bytes()).hexdigest() for p in members),*counts,payload.name
if __name__=='__main__':
    with ProcessPoolExecutor(max_workers=2) as pool:
        for result in pool.map(find,(3,4)):
            print(*result,sep='\t',flush=True)
