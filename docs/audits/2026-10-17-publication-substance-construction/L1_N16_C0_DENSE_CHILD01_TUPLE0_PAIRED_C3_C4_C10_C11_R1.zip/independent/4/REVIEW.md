# Independent review of original paired cut 4

The subtotal for (65,(3,)) is **3196789373761759059327/2596148429267413814265248164610048 + 0i**. All 16 signed terms independently match the complete author ledger. This accepts one coordinate of descendant (0,1), tuple 0.

The original eight-factor operands are disjoint on R(0,0,2,0,1) and share all six environment factors, denominators and remaining conditions. Both pinned 48-coordinate rosters sum to 6,427,904 selected-pair products per branch. The coordinate contributes 70,896 selected-pair products per branch. Independent signed multiplication and addition reproduce the seven starting factors, retaining 51,552 nonzero pair rows. The full pair constructor, reduction and five-factor join cap reproduced byte for byte. Combined SHA256 is cf045aecc031b9639d6a313e08f381bc3da12a015515cd8103197c97232544a3. Restart SHA256 is ab42eb42a5daa8c132afcee4f6622b9fbd8c151b59cd5d92a49f4fb601d45a9f.

The raw coefficient magnitude check does not distinguish this cut from cut 2. The attempted signed-map search did not establish an exact witness. The separately contracted scalar equals cut 2, and all 16 terms were still computed on distinct pinned operands. The accepted route uses a complete one-axis partition on G(1,0,2). Independent support counting recovers all 16 compatible labels, eight with 622,800 projected matches and eight with 1,245,600. The 14,947,200 total matches agree with the source census. Each inverse lift preserves all compatible support, signed coefficients, and normalizers. All 48 author preparation, reduction and contraction stages reproduced byte for byte, including eight generic exact closures and eight saved three-factor triangles.

Each 1,245,600-match branch was independently closed by necessary-support pruning and width-aware sparse contraction. Every branch used 10,308,068 products, at most 7,992,720 per join, with up to 187,200 retained output rows. Each 622,800-match branch independently closed with triangle pivot 1, using 8,491,552 Gaussian products. For all 16 author pivot-0 shards, independent projection counts and raw signed sums agree. Each interval covers its part of the actual pivot support, with 102,240 rows and 8,564,928 author probes per branch across the two intervals. All raw numerators use the factor denominator 40512224221827380280140849737629696 and positive normalization 1/(16*4^64) once.

Scratch timings

- generic sum of elapsed seconds 218.500993.
- pruned products [10308068] seconds min/max/sum 8.9813 11.0624 78.7753.
- alt-triangle products [8491552] seconds min/max/sum 4.633 5.841 41.861.

The constructor took 1.512 seconds. Paired reduction and cap took 15.585 s. All 203 operand hash entries and portable manifest entries passed checksum readback.
