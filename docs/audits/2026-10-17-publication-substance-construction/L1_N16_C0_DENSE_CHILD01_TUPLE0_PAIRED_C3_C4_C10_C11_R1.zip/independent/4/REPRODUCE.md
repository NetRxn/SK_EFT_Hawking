# Reproduce original paired cut 4

Replace author paths with restored hash-equivalent paths when needed. The original author inputs and text receipts are recorded under author-receipts. Use fresh outputs.

Run python3 pair-route-audit.py, bash combine-readback.sh and bash pair-lineage.sh to verify the 48-term outer supports, signed paired coordinate and five-factor join-cap lineage. Run python3 cohort-cut-audit.py for the entire 16-label one-axis roster and exact inverse lifts, then python3 cohort-lineage.py to independently re-execute the selector with exact support followed by the author reduction and generic contraction. Run bash reproduce-cohort.sh to repeat all independent signed arithmetic, shard accounting and exact retally.

