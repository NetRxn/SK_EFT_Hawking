from hashlib import file_digest
from pathlib import Path
from shutil import copyfile
from subprocess import check_output,run
from sys import argv,executable

case=int(argv[1])
origin=Path(__file__).resolve().parent
dir=Path.cwd()
assert case==10
common_dir=dir/'tools'
common_dir.mkdir()
common=('audit.py','freeze-inputs.py','inner-lineage.py','ledger-metrics.py',
        'pin-sources.py','replay-all.py','rescue-source-pins.py','sparse-replay.py',
        'sparse-support-replay.py','summarize.py','triangle.py','verify-shard-coverage.py',
        'four.py','terminal_plan.py','audit-shard-raw.py','replay-author-raw.py',
        'triangle-author-raw.py','four-author-raw.py')
for name in common:
    copyfile(origin/name,common_dir/name)
metrics=check_output([executable,'-B',str(common_dir/'summarize.py')],text=True)
(dir/'summary.out').write_text(metrics)
with (dir/'inner-stage-timing.tsv').open('w') as out:
    print('slice','command_receipt','status','wall_seconds',sep='\t',file=out)
    for n in range(len((dir/'inner-roster.tsv').read_text().splitlines())):
        out.write((dir/f'lineage-{n}/stage-timing.tsv').read_text())
ledger=(dir/'signed-ledger.tsv').read_text().splitlines()[-1].split('\t')
sum_raw=(ledger[4],ledger[5])
real,imag=ledger[6:8]
route=(dir/'pair-route-audit.out').read_text().splitlines()[-1]
combined=route.split()[-1]
cuts=(dir/'cut-audit.out').read_text().splitlines()
cap=next(row.split()[3] for row in cuts if row.startswith('PASS stage row-cap-physical-slice-dense-label-sum'))
lineage_wall=metrics.splitlines()[1].split()[-1]
ind_products,author_products=metrics.splitlines()[2].split()[3::2]
replay_wall=metrics.splitlines()[3].split()[-1]
pair_time=(dir/'pair-route-audit.time').read_text().splitlines()[0].split()[1]
combine_time=(dir/'combine-timing.out').read_text().split()[0]
_,reduce_time,cap_time=(dir/'pair-lineage-timing.tsv').read_text().splitlines()
reduce_time,cap_time=reduce_time.split()[-1],cap_time.split()[-1]
g=20
_,commands,_,refusals,*_=metrics.splitlines()[1].split()
stages=metrics.splitlines()[0].split()[-1]
terms=(dir/'signed-ledger.tsv').read_text().splitlines()[1:-1]
term_methods={method:[int(row.split('\t')[0]) for row in terms if row.split('\t')[3]==method]
              for method in ('triangle','four')}
plan=[]
routes=[]
for row in plan:
    i,_,program,author_pair,_=row.split('\t')
    if program=='triangle-shards.py':
        pivot=next(line.split()[2] for line in (dir/f'slice-{i}-triangle-replay.out').read_text().splitlines() if line.startswith('independent pivot '))
        assert pivot=='1'
        routes.append(f'slice {i} used triangle pivot {pivot}, with author pivot 0')
    else:
        from ast import literal_eval
        from terminal_plan import alternate_pair, plans
        src=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe10-inner')
        state=plans(src)[int(i)][4]
        pair=alternate_pair(state['factors'],literal_eval(author_pair))
        routes.append(f'slice {i} used four-factor pair {pair}, with author pair {author_pair}')
routing='The alternate schedules were '+', '.join(routes[:-1])+' and '+routes[-1]+'.' if len(routes)>1 else ('The alternate schedule was '+routes[0]+'.' if routes else '')
author_shards=8*sum(map(len,term_methods.values()))
support=len(terms)
direct=support-sum(map(len,term_methods.values()))
assert author_shards==0
review=f"""# Independent review of paired outer coordinate {case}

The independently verified signed contribution of outer coordinate `({g},(1,))` in group128 descendant `(0,1)`, tuple 0 is `{real} + {imag}i`. The raw Gaussian subtotal is `({sum_raw[0]},{sum_raw[1]})` over factor denominator `40512224221827380280140849737629696`. The common positive external normalization `1/(16*4^64)` is applied once. This acceptance covers outer coordinate {case}.

The named continuity revision matched publication checkpoint `e0040b1522feb13ef39ec7ce905b35306e804362`. The two disjoint binary-selector inputs use the accepted hashes and share six environment factors. The independent census recovers all 48 coordinates and 6,427,904 compatible products per original branch. A condition-first signed constructor indexed the opposite factor and reconstructed every one of the seven combined tables using 106,344 products per branch. Their sum has 77,328 retained pair rows. The original constructor, outer reduction and refusal reproduced byte for byte. The combined input SHA-256 is `{combined}` and the retained cap SHA-256 is `{cap}`. Independent reconstruction took {pair_time} s. Constructor, reduction and refusal readbacks took {combine_time}, {reduce_time} and {cap_time} s wall respectively.

The inner census recovered {support} disjoint coordinates with {int((dir/'inner-products.txt').read_text()):,} compatible products. Every exact inverse lift recovered the original conditioned rows, keys, axes, signed Gaussian coefficients and denominators. The {direct} generic terminals were verified with independent sparse Gaussian contraction. {routing} All terminals completed in the bounded generic route. Each signed raw Gaussian pair and normalized pair was independently checked. The signed ledger gives the route, raw value, projected work and observed work per slice.

The {commands} generic inner commands across {stages} stages reproduced each log and saved checkpoint byte, preserving all {refusals} refusals. Their summed wall duration was {lineage_wall} s under concurrent execution. The independent terminal replays used {int(ind_products):,} products and {replay_wall} summed wall seconds. The author terminal receipts record {int(author_products):,} products. Terminal work totals exclude generic work performed before a refusal. The signed ledger and timing tables preserve per-slice measurements.

Verify the portable receipts from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B tools/ledger-metrics.py {case} | cmp - signed-ledger.tsv
python3 -B tools/summarize.py | cmp - summary.out
```

The three operand inventories bind the original binary and text files on the author scratch path. Full recalculation of the binary lineage requires those pinned files. The portable manifest contains the selected receipts, hashes, timings, authority checks and review scripts.
"""
(dir/'REVIEW.md').write_text(review)
root_files=[p for p in dir.iterdir() if p.is_file() and not p.name.startswith('review-manifest')]
receipt_files=(dir/'author-receipts').rglob('*')
timing_files=dir.glob('lineage-*/stage-timing.tsv')
paths=sorted({p for p in [*root_files,*receipt_files,*timing_files,*common_dir.glob('*.py')] if p.is_file()})
with (dir/'review-manifest.sha256').open('w') as out:
    for path in paths:
        with path.open('rb') as stream:
            digest=file_digest(stream,'sha256').hexdigest()
        print(digest,path.relative_to(dir),sep='  ',file=out)
with (dir/'review-manifest-verify.out').open('w') as receipt:
    run(['shasum','-a','256','-c','review-manifest.sha256'],stdout=receipt,check=True)
assert len((dir/'review-manifest-verify.out').read_text().splitlines())==len(paths)
print(case,real,imag,len(paths),sep='\t')
