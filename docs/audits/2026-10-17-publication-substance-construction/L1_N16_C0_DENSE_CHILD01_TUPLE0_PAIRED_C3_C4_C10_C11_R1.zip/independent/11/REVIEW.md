# Independent review of paired outer coordinate 11

The independently verified signed contribution of outer coordinate `(20,(2,))` in group128 descendant `(0,1)`, tuple 0 is `8732401333944633881667/2596148429267413814265248164610048 + 0i`. The raw Gaussian subtotal is `(741907367640693783398089545752104535844577473983056043273355264,0)` over factor denominator `40512224221827380280140849737629696`. The common positive external normalization `1/(16*4^64)` is applied once. This acceptance covers outer coordinate 11. Its scalar equals cut 23’s committed value, with different combined and capped factor tables independently verified.

The named continuity revision matched publication checkpoint `e0040b1522feb13ef39ec7ce905b35306e804362`. The two disjoint binary-selector inputs use the accepted hashes and share six environment factors. The independent census recovers all 48 coordinates and 6,427,904 compatible products per original branch. A condition-first signed constructor indexed the opposite factor and reconstructed every one of the seven combined tables using 106,344 products per branch. Their sum has 77,328 retained pair rows. The original constructor, outer reduction and refusal reproduced byte for byte. The combined input SHA-256 is `a47957617e9e0f8adf0471d22d738543b127304707b2ccdafc5b924b1dbc8311` and the retained cap SHA-256 is `83343f3fb6c30870a8daa262d4b7237b26c86eabfb462c27b07fba6d523d937c`. Independent reconstruction took 2.14 s. Constructor, reduction and refusal readbacks took 1.685, 7.389 and 3.061 s wall respectively.

The inner census recovered 9 disjoint coordinates with 1,021,248 compatible products. Every exact inverse lift recovered the original conditioned rows, keys, axes, signed Gaussian coefficients and denominators. The 9 generic terminals were verified with independent sparse Gaussian contraction.  All terminals completed in the bounded generic route. Each signed raw Gaussian pair and normalized pair was independently checked. The signed ledger gives the route, raw value, projected work and observed work per slice.

The 43 generic inner commands across 17 stages reproduced each log and saved checkpoint byte, preserving all 8 refusals. Their summed wall duration was 232.085349 s under concurrent execution. The independent terminal replays used 40,718,896 products and 55.482154 summed wall seconds. The author terminal receipts record 18,300,769 products. Terminal work totals exclude generic work performed before a refusal. The signed ledger and timing tables preserve per-slice measurements.

Verify the portable receipts from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B tools/ledger-metrics.py 11 | cmp - signed-ledger.tsv
python3 -B tools/summarize.py | cmp - summary.out
```

The three operand inventories bind the original binary and text files on the author scratch path. Full recalculation of the binary lineage requires those pinned files. The portable manifest contains the selected receipts, hashes, timings, authority checks and review scripts.
