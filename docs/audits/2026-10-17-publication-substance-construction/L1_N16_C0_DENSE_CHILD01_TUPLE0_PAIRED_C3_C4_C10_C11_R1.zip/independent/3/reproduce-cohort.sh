#!/usr/bin/env bash
set -euo pipefail
d=/private/tmp/l1-cut3-frontier.3jl7nf
for i in 17 24 34 36 66 68 129 136; do
 p="$d/$i/label-cut2-selected-reduced-frontier.pkl"
 if test "$i" = 17; then p="$d/label-cut2-selected-reduced-frontier.pkl"; fi
 python3 -u sparse-support-direct.py "$i" terminal "$p" > "label$i-pruned.out"
done
for i in 18 20 33 40 65 72 130 132; do
 python3 -u triangle.py "$i" join-cap-dense-label-cut2-selected-reduced.pkl > "label$i-alt-triangle.out"
done
python3 -u cohort-cut-audit.py > cohort-cut-audit.out
python3 -u cohort-terminal-audit.py > cohort-terminal-audit.out
