from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle

root=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
states=[pickle.loads((root/f'join-cap-dense-label-sum{i}-reduced.pkl').read_bytes())['factors'] for i in (2,3,4)]
def unit_orbit(xy):
    x,y=xy
    return max((x,y),(-x,-y),(y,-x),(-y,x))
def trim(factors):
    assert set(Counter(axis for scope,_,_ in factors for axis in scope).values())=={2}
    factors=list(factors)
    sizes=tuple(len(rows) for _,rows,_ in factors)
    while True:
        drops=0
        for i,j in combinations(range(len(factors)),2):
            left,right=[factors[k] for k in (i,j)]
            axes=sorted(set(left[0])&set(right[0]))
            if not axes:
                continue
            p,q=[tuple(scope.index(k) for k in axes) for scope,_,_ in (left,right)]
            allowed=set(tuple(r[k] for k in p) for r in left[1])&set(tuple(r[k] for k in q) for r in right[1])
            for f,pp in ((i,p),(j,q)):
                scope,rows,d=factors[f]
                current={row:g for row,g in rows.items() if tuple(row[k] for k in pp) in allowed}
                drops+=len(rows)-len(current)
                factors[f]=(scope,current,d)
        if not drops:
            break
    print('necessary supports',[a-len(rows) for a,(_,rows,_) in zip(sizes,factors,strict=True)])
    return factors

fs=[trim(state) for state in states]
for i,target in enumerate(fs[1:],3):
    for j,((a,r,d),(b,t,e)) in enumerate(zip(fs[0],target,strict=True)):
        s=Counter(map(unit_orbit,r.values()))
        u=Counter(map(unit_orbit,t.values()))
        print(i,j,'retained',len(r),len(t),'unit orbit equal',s==u,'differences',sum((s-u).values()),sum((u-s).values()))
