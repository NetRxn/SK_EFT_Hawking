from hashlib import sha256
from pathlib import Path
import sys

cut=int(sys.argv[1])
assert cut in (3,4)
component=40 if cut==3 else 65
shared=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
cwd=Path.cwd()
h=lambda path: sha256(path.read_bytes()).hexdigest()
audit=(cwd/'cohort-terminal-audit.out').read_text().splitlines()
sum_line=audit[-1].removeprefix(f'PASS full cut {cut} sum ')
assert len(sum_line.split())==2 and sum_line.split()[1]=='0'
value,_=sum_line.split()
inputs=sum(len(Path(name).read_text().splitlines())
           for name in ('paired-operands-verify.out','cohort-operands-verify.out'))
coord=f'({component},(3,))'
explain=(
    'The signed-map candidate from cut 2 fails on factor 3, where the coefficient magnitude distribution differs even under Gaussian unit rotations. Exact necessary-support pruning leaves this discrepancy in place.'
    if cut==3 else
    'The raw coefficient magnitude check does not distinguish this cut from cut 2. The attempted signed-map search did not establish an exact witness. The separately contracted scalar equals cut 2, and all 16 terms were still computed on distinct pinned operands.'
)
timings=(cwd/'cohort-timing.out').read_text()
pair_time=(cwd/'combine-timing.out').read_text().strip()
reduce,cap=[float(line.split('\t')[1]) for line in (cwd/'pair-lineage-timing.tsv').read_text().splitlines()[1:]]
text=f"""# Independent review of original paired cut {cut}

The subtotal for {coord} is **{value} + 0i**. All 16 signed terms independently match the complete author ledger. This accepts one coordinate of descendant (0,1), tuple 0.

The original eight-factor operands are disjoint on R(0,0,2,0,1) and share all six environment factors, denominators and remaining conditions. Both pinned 48-coordinate rosters sum to 6,427,904 selected-pair products per branch. The coordinate contributes 70,896 selected-pair products per branch. Independent signed multiplication and addition reproduce the seven starting factors, retaining 51,552 nonzero pair rows. The full pair constructor, reduction and five-factor join cap reproduced byte for byte. Combined SHA256 is {h(shared/f'combined-{cut}.pkl')}. Restart SHA256 is {h(shared/f'join-cap-dense-label-sum{cut}-reduced.pkl')}.

{explain} The accepted route uses a complete one-axis partition on G(1,0,2). Independent support counting recovers all 16 compatible labels, eight with 622,800 projected matches and eight with 1,245,600. The 14,947,200 total matches agree with the source census. Each inverse lift preserves all compatible support, signed coefficients, and normalizers. All 48 author preparation, reduction and contraction stages reproduced byte for byte, including eight generic exact closures and eight saved three-factor triangles.

Each 1,245,600-match branch was independently closed by necessary-support pruning and width-aware sparse contraction. Every branch used 10,308,068 products, at most 7,992,720 per join, with up to 187,200 retained output rows. Each 622,800-match branch independently closed with triangle pivot 1, using 8,491,552 Gaussian products. For all 16 author pivot-0 shards, independent projection counts and raw signed sums agree. Each interval covers its part of the actual pivot support, with 102,240 rows and 8,564,928 author probes per branch across the two intervals. All raw numerators use the factor denominator 40512224221827380280140849737629696 and positive normalization 1/(16*4^64) once.

Scratch timings

{''.join(f'- {line}.\n' for line in timings.splitlines())}
The constructor took {pair_time}. Paired reduction and cap took {reduce+cap:.3f} s. All {inputs} operand hash entries and portable manifest entries passed checksum readback.
"""
(cwd/'REVIEW.md').write_text(text)
