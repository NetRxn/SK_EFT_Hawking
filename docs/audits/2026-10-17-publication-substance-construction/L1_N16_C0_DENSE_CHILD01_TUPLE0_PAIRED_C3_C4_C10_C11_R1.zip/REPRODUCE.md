# L1 original paired cuts 3, 4, 10 and 11

These are four distinct original outer coordinates of group 128, descendant (0,1), tuple 0. Cuts 3 and 4 each have 16 exact terms beyond their five-factor join cap. Cuts 10 and 11 each have nine exact terms.

Restore the frozen 48-coordinate roster and operands from L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip at 383f42e573962e8f7f41c0111c82a59a605c73ff. Check source hashes. Reproduce each outer pair via sum-branches-checked.py and the generic reduction and contraction. The author bound runner is run-rostered-next.py. Each cut's outer-inputs.sha256 identifies its pair input and cap. For cuts 3 and 4 the whole-cap map search does not supply a verified witness, and the arithmetic is direct.

For cuts 3 and 4 invoke the scripts in author/<cut>/frontier from a clean scratch directory, starting with prepare.py on the corresponding frozen cap. Run the initial prepared term and then run-cohort.py for the full roster. Eight generic terms end at triangle caps. The eight complementary terms finish directly. Run triangle-forecast.py on the eight capped terms, finish-triangles.py and sum-case2.py. Each term's sign and positive denominator are retained. Verify the individual fingerprints against operands.sha256.

For cuts 10 and 11 run the actual nine-term roster and repeat their recorded two-stage reductions and bounded contractions. For each term cross-check the full support, inverse lift, exact numerator and common normalization. Run their individual sum-case<cut>.py. Compare all ledger lines.

Every term uses the positive external factor 1/(16*4^64) once. Verify manifest.sha256 and each independent portable manifest. Re-run coverage-retally.py with the repository audit archive directory and compare the consolidated 48-coordinate ledger line by line.
