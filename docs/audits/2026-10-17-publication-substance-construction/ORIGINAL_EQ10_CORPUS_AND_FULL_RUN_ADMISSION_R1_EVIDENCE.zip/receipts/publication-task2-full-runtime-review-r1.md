# Independent one-off Task2 full scientific runtime admission review R1

**Verdict: REVISE_RUNTIME before ROOT admission.** The child preserves the unchanged full scientific test and accepted source/cost scope. Two supervision defects remain: thread count is observed without any single-CPU/thread refusal, and supervisor failure can leave the admitted child running without external supervision or a terminal receipt. Both were demonstrated using tiny fake mechanisms without scientific execution. These require minimal edits to the ephemeral supervisor, not persistent pipeline infrastructure.

FIRST action: SAME packet check returned exit0,fresh=true,changed=[]. FINAL SAME check returned exit1,fresh=false,changed=[source]. I did not refresh the packet. The three scientific source/test files and BOTH runtime scripts still match the exact assigned hashes; broader primary source state changed while ROOT's independent canonical refresh was authorized. ROOT must reconcile/reissue before the revised runtime is accepted. I did not mutate primary source, Git, ledger, packet, notebook, counts, controller or any shared process.

## Actual inspection and preserved scientific contract

Read the assigned packet and ROOT notebook, both entire runtime scripts, and the entire original scientific test against this reviewer's complete R3 source/cost assessment. Scientific source hashes remain formulas d2eb079a84da6ab0c68aabb91640e9b29013bcf4b22104e816d68a804bd5c1b4, domain fb0ac84c5623f9fd2454561d007a4f973e0db5874f259fe5f395879a9b3a7df8, tests0b8fd40a3749090d30f8793cd6aaa103e3f841e070d6686701a64ad013c0ebf8. Runtime child SHA2564636af5ef3051d53ed0d1e5c0633dd32890826f8b16c8fd5fe068bbb79dd7d85; supervisor2c106f0ebf75635dbb2940fa18dca6cc967dc5f5888afaba505e9ce7b1561155.

The child checks all three source pins before imports, imports actual PRIMARY formulas/domain paths, wraps the ORIGINAL producer without replacing its return value, and invokes exactly the named existing full pytest with -m '' and cache provider disabled. The original full test remains lines113–140, ten assert statements, no skip/xfail/decorator. It uses an active250M ExactBudget,1024-bit ceiling and2GiB modeled storage. All3876/740 quartics, both actual words, v2/v3,94016 queries, complete direct/auxiliary polynomial equality, interacting denominator, observed172 OUTPUT, T/H populations and frame-route equality remain assertions. Accepted prospective225370240 is not substituted for an actual counter or used as a cutoff. Only one invocation is selected; no scientific preflight, automatic retry or restart is present.

The child stores the complete exact original result as protocol5 pickle after pytest returns, including when assertions fail after producer return; it hashes the retained bytes. Progress snapshots include actual budget products, integer products/height, scalar records and modeled payload, plus native self high-water RSS. The observer captures and returns the original object. No synthetic expected coefficient enters it. A producer exception does not create a completed result; supervisor exit status and retained partial progress must remain failure evidence.

Supervisor configures numerical thread pools1, disables pytest plugin autoload and bytecode, starts one process group, redirects stdout/stderr, records command/child hash/source HEAD, and samples tree RSS/wall/process count every second. RSS>2GiB, wall>86400seconds and an unexpected child process invoke TERM then bounded wait/KILL. No restart exists. These are sampled external guards, not a hard instantaneous RSS reservation. Child CPU rlimit(86400,86405) limits cumulative CPU seconds; it does not cap instantaneous CPU parallelism. Full scientific results still need independent result review. Current inherited PYTHONOPTIMIZE/PYTEST_ADDOPTS/PYTEST_PLUGINS were inspected and unset; no live environment-based assertion bypass was observed.

## Mandatory RUNTIME-1 — single-CPU protection is not enforced by observed thread count

Location: supervisor lines12–15. maxthreads is recorded, but only process count triggers refusal. Setting BLAS/OpenMP environment variables1 is useful preventative configuration, not enforcement of other threads or an instantaneous one-CPU limit. The cumulative CPU-time rlimit also permits multiple CPUs until totalCPU exhaustion.

Independent execution of the ORIGINAL supervisor body against a fake one-process/two-thread child returns exit0,termination_reason=null,max_observed_threads=2 and no termination signal. This does not assert that the actual scientific implementation used two CPUs; the scientific run has NOT occurred. It proves that the proposed guard permits a multi-thread event while declaring a single-CPU admission envelope.

Required minimal repair: enforce the intended oneCPU admission, for example refuse unexpected thread count>1 for this known single-thread exact Python worker, or an explicit equivalent OS CPU restriction where supported. Record the refusal and retain no-restart behavior. Rerun tiny single-thread positive and multi-thread adverse controls. No project pipeline or physics source change is needed.

## Mandatory RUNTIME-2 — unexpected supervisor failure abandons the running child

Location: launch/setup and monitor loop, supervisor lines8–24. There is no encompassing try/finally guaranteeing termination/reaping of its OWN child after a launch-receipt write failure, unexpected psutil/telemetry exception or interruption. Only the expected resource-reason branches perform cleanup. NoSuchProcess is the only handled monitoring exception.

Independent fake telemetry exception escapes the unchanged supervisor body with no TERM/KILL, no wait and no terminal receipt. In the real topology, the child was started in a NEW session/process group, so supervisor termination alone does not guarantee child termination. The admitted child could continue computing after external RSS/wall supervision disappears. Its CPU rlimit does not replace RSS or wall protection.

Required minimal repair: after Popen succeeds, own the child through a try/finally that terminates/reaps it whenever supervision exits abnormally or cannot establish safe telemetry; write an explicit failure receipt when possible. Handle the normal already-exited race without turning it into an orphan-cleanup error. Keep TERM/KILL limited to this exact launched process group, preserve partial evidence and never restart. Check tiny telemetry failure and launch-record failure, plus normal completion/resource refusals. This is ephemeral ROOT run custody, not a new lifecycle controller.

## Additional bounded implementation note

The wall guard uses time.time(), a civil clock that can step. Use time.monotonic() for elapsed wall-budget decisions and retain time.time() only for human timestamps. This small change makes the stated24hour watchdog independent of clock corrections; no scientific calculation is necessary to validate it.

## Actual mechanism evidence and limits

A reviewer-owned /tmp smoke executes the ORIGINAL supervisor AST body with imports/path initialization replaced by deterministic fake subprocess, psutil, signal and clock objects. No child subprocess, OS signal, sleep or project scientific import occurs. Outputs use unique /tmp directories, not ROOT's runtime filenames. Results:

- Single-thread/one-process normal completion: exit0,no signals.
- Two-thread/one-process completion: exit0,no signals — RUNTIME-1.
- Unexpected child process: failure exit1,TERM issued.
- RSS2GiB+1: failure exit1,TERM issued.
- Wall89900seconds: failure exit1,TERM issued.
- Unexpected telemetry exception: escaped exception,no signals,no terminal receipt — RUNTIME-2.

The smoke is a branch/mechanism test, not a native live-process/resource fit measurement. Actual source/test assertions were inspected statically and conserved by full-file hashes. I performed no scientific producer/test execution, Lean/build/controller action, canonical refresh, Git or source mutation. Only assigned reviewer /tmp reports/static receipts and tiny fake outputs were written. No other new runtime review verdict was consulted.

ROOT should repair the ephemeral supervisor, reconcile the changed primary source snapshot and obtain different/checkable reassessment before admitting the ONE complete scientific run. Full execution, actual complete result/counters/peak height/RSS/time and different scientific result review remain owed. No formal/physical/B3/main/publication acceptance follows from runtime admission.
