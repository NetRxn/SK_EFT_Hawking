"""One ROOT-admitted run; no restart, source edits or persistent pipeline."""
from pathlib import Path
import subprocess,os,json,time,signal,hashlib,psutil
P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');base=Path('/tmp');child=base/'publication-task2-full-science-child-r1.py';result=base/'publication-task2-full-science-supervisor-r2.json';assert not result.exists()
assert hashlib.sha256(child.read_bytes()).hexdigest()=='4636af5ef3051d53ed0d1e5c0633dd32890826f8b16c8fd5fe068bbb79dd7d85'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH=str(P))
for name in ['PYTHONOPTIMIZE','PYTEST_ADDOPTS','PYTEST_PLUGINS']:env.pop(name,None)
started=time.time();tick=time.monotonic();peak=0;maxthreads=0;reason=None;p=None;rc=None;cleanup_errors=[]
def interrupted(signum,frame):raise RuntimeError('supervisor interrupted by signal '+str(signum))
signal.signal(signal.SIGTERM,interrupted)
try:
 with (base/'publication-task2-full-science-r1.stdout').open('w') as out,(base/'publication-task2-full-science-r1.stderr').open('w') as err:
  p=subprocess.Popen([str(P/'.venv/bin/python'),'-B',str(child)],cwd=P,env=env,stdout=out,stderr=err,start_new_session=True)
  proc=psutil.Process(p.pid)
  (base/'publication-task2-full-science-launch-r2.json').write_text(json.dumps({'pid':p.pid,'wall_started':started,'child_script_sha256':hashlib.sha256(child.read_bytes()).hexdigest(),'rss_limit_bytes':2*1024**3,'wall_limit_seconds':86400,'logical_product_limit':250000000,'integer_limit_bits':1024,'thread_limit':1,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),'command':p.args},indent=2)+'\n')
  while p.poll() is None:
   try:
    processes=[proc]+proc.children(recursive=True);rss=sum(x.memory_info().rss for x in processes);threads=sum(x.num_threads() for x in processes);peak=max(peak,rss);maxthreads=max(maxthreads,threads)
    if rss>2*1024**3:reason='resident-memory limit exceeded'
    if time.monotonic()-tick>86400:reason='wall-time limit exceeded'
    if len(processes)>1:reason='unexpected child process outside single-process scientific admission'
    if threads>1:reason='thread limit exceeded outside single-CPU scientific admission'
   except psutil.NoSuchProcess:
    if p.poll() is None:reason='live admitted child cannot be observed safely'
   if reason:break
   time.sleep(1)
except BaseException as exc:
 reason='supervision failed: '+type(exc).__name__+': '+str(exc)
finally:
 if p is not None:
  try:
   if p.poll() is None:
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     p.wait(timeout=10)
   rc=p.wait(timeout=1)
  except BaseException as exc:
   cleanup_errors.append(type(exc).__name__+': '+str(exc));reason=reason or 'own-child cleanup failed'
 receipt={'exit_code':rc,'termination_reason':reason,'cleanup_errors':cleanup_errors,'sampled_peak_tree_rss_bytes':peak,'max_observed_threads':maxthreads,'wall_seconds':time.monotonic()-tick,'wall_started':started,'full_scientific_acceptance':False,'independent_result_review_required':True}
 try:result.write_text(json.dumps(receipt,indent=2)+'\n')
 except BaseException as exc:
  receipt['terminal_receipt_write_error']=type(exc).__name__+': '+str(exc);reason=reason or 'terminal receipt write failed'
 print(json.dumps(receipt,indent=2),flush=True)
raise SystemExit(rc if rc else int(reason is not None))
