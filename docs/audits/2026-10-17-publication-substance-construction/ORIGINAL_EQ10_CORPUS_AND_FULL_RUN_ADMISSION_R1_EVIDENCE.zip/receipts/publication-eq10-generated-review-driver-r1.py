import sys,json,pathlib,subprocess,collections
sys.path.insert(0,str(pathlib.Path('scripts').resolve()))
sys.path.insert(0,str(pathlib.Path('.').resolve()))
import update_counts as u,atlas_view as av,atlas_heatmap as ah,extract_lean_deps as ex
new=json.load(open('lean/lean_deps.json'))
old=json.loads(subprocess.check_output(['git','show','HEAD:lean/lean_deps.json']))
a={x['name']:x for x in old};b={x['name']:x for x in new}
counts=json.load(open('docs/counts.json'));at=json.load(open('lean/atlas_view.json'))
oldat=json.loads(subprocess.check_output(['git','show','HEAD:lean/atlas_view.json']))
res={}
res['deps_serialization_exact']=ex.serialize_deps(new)==pathlib.Path('lean/lean_deps.json').read_text()
res['deps_hash']={'computed':ex.compute_lean_hash(),'stored':pathlib.Path('lean/lean_deps.json.hash').read_text().strip()}
res['lean_counts_equal']=u.count_lean(u.LEAN_DEPS,preloaded=new)==counts['lean']
res['python_cheap_equal']=all(counts['python'][k]==v for k,v in u.count_python_cheap().items())
res['aristotle_equal']=u.count_aristotle()==counts['aristotle']
tmp=pathlib.Path('/tmp/publication-eq10-generated-counts-reproduced-r1.tex')
u.generate_tex(counts,tmp,deps=new)
res['tex_bytes_equal']=tmp.read_bytes()==pathlib.Path('docs/counts.tex').read_bytes()
rebuilt=av.build_atlas(new)
res['atlas_equal']=rebuilt==at
res['atlas_bytes_equal']=json.dumps(rebuilt,indent=2)==pathlib.Path('lean/atlas_view.json').read_text()
res['heatmap_bytes_equal']=ah.render(rebuilt)==pathlib.Path('docs/ATLAS_HEATMAP.md').read_text()
res['prior_declarations']=len(a);res['current_declarations']=len(b)
res['removed_declarations']=sorted(a.keys()-b.keys())
res['changed_records']={n:[k for k in a[n].keys()|b[n].keys() if a[n].get(k)!=b[n].get(k)] for n in a.keys()&b.keys() if a[n]!=b[n]}
res['added_by_module']=dict(collections.Counter(b[n]['module'] for n in b.keys()-a.keys()))
res['old_atlas_sizes']={k:len(v) for k,v in oldat.items() if isinstance(v,list)}
res['new_atlas_sizes']={k:len(v) for k,v in at.items() if isinstance(v,list)}
for key in ['unknowns','edges','frontier','obstructions']:
    x=set(json.dumps(z,sort_keys=True) for z in oldat[key]);y=set(json.dumps(z,sort_keys=True) for z in at[key])
    res[key+'_removed']=len(x-y);res[key+'_changed_set']=len(x^y)
oldnodes={x['fqn']:x for x in oldat['nodes']};newnodes={x['fqn']:x for x in at['nodes']}
res['removed_atlas_nodes']=sorted(oldnodes.keys()-newnodes.keys())
res['changed_atlas_nodes']=[n for n in oldnodes.keys()&newnodes.keys() if oldnodes[n]!=newnodes[n]]
res['old_atlas_summary']=oldat['summary'];res['new_atlas_summary']=at['summary']
exports=json.load(open('/tmp/publication-original-outer-haar-review-r1-kernel.json'))['exports']
prefix='SKEFTHawking.ADW.FiniteGrassmannDiracBerezin.'
res['missing_actual_exports']=[n for n in exports if prefix+n not in b]
res['actual_export_module_mismatch']=[n for n in exports if b[prefix+n]['module']!='SKEFTHawking.ADW.FiniteGrassmannDiracBerezin']
rs=[x for x in new if x['module']=='SKEFTHawking.ADW.FiniteGrassmannDiracBerezin']
res['new_module_project_axioms']=sorted(set(z for x in rs for z in x['axiom_deps_project']))
res['new_module_core_axioms']=sorted(set(z for x in rs for z in x['axiom_deps_core']))
res['new_module_timeouts']=[x['name'] for x in rs if x['name_deps_timed_out']]
from validation.checks import freshness,graph_atlas,lean_substrate,lean_statements
res['counts_stale']=freshness._counts_is_stale()
for fn in [graph_atlas.check_atlas_integrity,graph_atlas.check_atlas_hypothesis_discipline,lean_substrate.check_theorem_census_agrees]:
    r=fn();res[fn.__name__]=str(r)
pathlib.Path('/tmp/publication-eq10-generated-static-r1.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
