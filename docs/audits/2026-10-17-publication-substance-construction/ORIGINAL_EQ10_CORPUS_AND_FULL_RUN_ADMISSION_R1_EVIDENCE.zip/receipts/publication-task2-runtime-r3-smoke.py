import ast,json,hashlib,tempfile,types
from pathlib import Path
source=Path('/tmp/publication-task2-full-science-supervisor-r3.py').read_text();tree=ast.parse(source)
tree.body=[n for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom)) and n.lineno!=4]
class NoSuchProcess(Exception):pass
out=[]
for case in ('normal','threads','telemetry_exception','launch_receipt_failure','interrupt','SIGTERM','RSS','wall','unexpected_process','observability_live','observability_exit_race','cleanup_ProcessLookup','cleanup_timeout','leader_exit_with_descendant','TERM_ignored_group','quiescence_unconfirmed'):
 area=Path(tempfile.mkdtemp(prefix='task2-runtime-review-r3-'));calls=[];handlers={};state={'stopped':False,'polls':0,'waits':0,'group_alive':True}
 class FPath:
  def __init__(self,p):self.p=Path(p)
  def __truediv__(self,v):return FPath(self.p/v)
  def __str__(self):return str(self.p)
  def exists(self):return self.p.exists()
  def read_bytes(self):return self.p.read_bytes()
  def write_text(self,text):
   if case=='launch_receipt_failure' and 'launch-r2' in self.p.name:raise OSError('fake launch record failure')
   return self.p.write_text(text)
  def open(self,*a,**kw):return self.p.open(*a,**kw)
 class Child:
  pid=987654;args=['fake-child']
  def poll(self):
   state['polls']+=1
   if case=='normal' and state['polls']>1:state['stopped']=True;state['group_alive']=False
   if case=='leader_exit_with_descendant' and state['polls']>1:state['stopped']=True
   return 0 if state['stopped'] else None
  def wait(self,timeout=None):
   calls.append(['wait',timeout]);state['waits']+=1
   if case=='cleanup_timeout' and state['waits']==1:raise TimeoutError('fake TERM timeout')
   state['stopped']=True;return 0
 class Proc:
  def __init__(self,*a):pass
  def children(self,recursive=True):
   if case=='telemetry_exception':raise PermissionError('fake telemetry failure')
   if case=='interrupt':raise KeyboardInterrupt('fake keyboard interruption')
   if case=='SIGTERM':handlers[15](15,None)
   if case=='observability_live':raise NoSuchProcess()
   if case=='observability_exit_race':state['stopped']=True;state['group_alive']=False;raise NoSuchProcess()
   return [Proc()] if case in ('unexpected_process','leader_exit_with_descendant','TERM_ignored_group','quiescence_unconfirmed') else []
  def memory_info(self):return types.SimpleNamespace(rss=2*1024**3+1 if case=='RSS' else 1024)
  def num_threads(self):return 2 if case=='threads' else 1
 class Clock:
  n=0
  def time(self):return 100
  def monotonic(self):self.n+=1;return 0 if self.n==1 else 90000 if case=='wall' else self.n
  def sleep(self,n):pass
 def killpg(pid,sig):
  calls.append(['killpg',pid,sig])
  if case=='cleanup_ProcessLookup':state['stopped']=True;state['group_alive']=False;raise ProcessLookupError()
  if sig==0:
   if not state['group_alive']:raise ProcessLookupError()
   return
  if case=='quiescence_unconfirmed':return
  if sig==15 and case=='TERM_ignored_group':return
  state['group_alive']=False;state['stopped']=True
 def Popen(*a,**kw):
  if case=='cleanup_ProcessLookup' or case=='cleanup_timeout':pass
  return Child()
 # cleanup cases take the telemetry failure path to ensure a live-child cleanup.
 if case in ('cleanup_ProcessLookup','cleanup_timeout','TERM_ignored_group','quiescence_unconfirmed'):
  def failchildren(*a,**kw):raise OSError('trigger cleanup')
  Proc.children=failchildren
 env={'Path':Path,'subprocess':types.SimpleNamespace(Popen=Popen,check_output=lambda *a,**kw:'fake-head\n',TimeoutExpired=TimeoutError),'os':types.SimpleNamespace(environ={'PYTHONOPTIMIZE':'1','PYTEST_ADDOPTS':'--assert=plain','PYTEST_PLUGINS':'fake'},killpg=killpg),'json':json,'time':Clock(),'signal':types.SimpleNamespace(SIGTERM=15,SIGKILL=9,signal=lambda k,v:handlers.update({k:v})),'hashlib':hashlib,'psutil':types.SimpleNamespace(Process=Proc,NoSuchProcess=NoSuchProcess),'P':FPath(area),'base':FPath(area),'child':Path('/tmp/publication-task2-full-science-child-r1.py'),'result':FPath(area/'result.json')}
 try:exec(compile(tree,'original-R3-supervisor-body','exec'),env)
 except SystemExit as e:result={'exit':e.code,'receipt':json.loads((area/'result.json').read_text()),'calls':calls}
 except BaseException as e:result={'exception':type(e).__name__,'calls':calls}
 result['env_overrides_removed']=all(k not in env['env'] for k in ('PYTHONOPTIMIZE','PYTEST_ADDOPTS','PYTEST_PLUGINS'))
 out.append({'case':case,**result})
Path('/tmp/publication-task2-runtime-r3-smoke.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
