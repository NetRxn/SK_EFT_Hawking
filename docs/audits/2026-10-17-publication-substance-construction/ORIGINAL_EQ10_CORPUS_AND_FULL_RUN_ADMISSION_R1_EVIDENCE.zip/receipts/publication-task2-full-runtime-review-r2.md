# Independent Task2 one-off runtime review R2

**Verdict: REVISE_RUNTIME for one remaining RUNTIME-2 cleanup race.** R2 repairs single-thread enforcement, ordinary monitor/launch failures, interrupts, monotonic wall timing and assertion-override environment. A demonstrated leader-exit/descendant-survival race remains. The correction can stay entirely within the ephemeral supervisor; no persistent pipeline or scientific source change is requested.

FIRST SAME packet check: exit0,fresh=true,changed=[]. FINAL SAME check: exit0,fresh=true,changed=[]. No packet refresh or primary mutation occurred. ROOT's notebook explicitly reconciles R1 stale source as six completed canonical derivatives and freezes R2 through both reviews; that reconciliation is not a scientific run/result.

## Actual source and conserved acceptance

I read the complete R1 adverse report, ROOT R2 notebook/packet and entire actual R2 supervisor, against the unchanged child/full scientific test and my complete independently accepted R3 source/cost review. Independent file-reference hashes are in the JSON. The scientific files remain formulas d2eb079a84da6ab0c68aabb91640e9b29013bcf4b22104e816d68a804bd5c1b4, domain fb0ac84c5623f9fd2454561d007a4f973e0db5874f259fe5f395879a9b3a7df8, tests0b8fd40a3749090d30f8793cd6aaa103e3f841e070d6686701a64ad013c0ebf8. Original child SHA2564636af5ef3051d53ed0d1e5c0633dd32890826f8b16c8fd5fe068bbb79dd7d85 is checked by the supervisor itself; R1 supervisor is preserved.

The original full scientific test and all its assertions remain intact: single named pytest invocation, both actual words, both nonunit variances, complete3876/740 coefficient scope,94016 queries, complete direct/auxiliary polynomial and frame equality, actual interacting denominator and T/H output populations. The producer still receives250M/1024bit/2GiB ExactBudget, with the independently accepted225370240 prospective source bound separate from measured counters. Original result retention/pickle hash and actual budget/native RSS progress snapshots are unchanged. There is no scientific preflight, auto-restart or substitution of expected coefficients. Child/pytest success is not scientific independent acceptance.

R2 sets native numeric thread pools1 AND now refuses an observed aggregate thread count>1. It strips PYTHONOPTIMIZE/PYTEST_ADDOPTS/PYTEST_PLUGINS before launching the unchanged child. Its wall decision and elapsed receipt now use monotonic time. The whole launched-child lifetime is under try/except/finally; ordinary telemetry/launch-record exceptions, KeyboardInterrupt and SIGTERM produce failure reason and terminate/reap the live leader. Missing telemetry refuses if the leader remains alive, while an already-exited leader can be normally reaped. TERM timeout escalates to KILL, both with bounded waits. Failure receipts remain explicit and no restart occurs. These are sampled RSS/thread guards, not an instantaneous OS resource reservation.

## Remaining mandatory RUNTIME-2 residual — known descendant survives leader-exit race

Location: `/tmp/publication-task2-full-science-supervisor-r2.py:32` through40. Cleanup signals the admitted process GROUP only if `p.poll() is None`, which asks whether the group LEADER is still running. It does not establish whether the process group or known descendants are quiescent.

A concrete branch ordering remains possible:

1. Monitoring observes the leader plus an unexpected descendant; it sets a failure reason and breaks.
2. The leader exits before finally performs its next poll, but the descendant remains in the admitted group.
3. Finally sees an exited leader, skips both killpg calls and merely waits/reaps that leader. The known descendant receives no termination signal.

My new independent fake mechanism probe executes the ORIGINAL R2 supervisor AST body with this ordering. It returns failure exit1 with an explicit termination reason, but the ONLY cleanup call is `wait(1)`: no TERM/KILL to the group. Thus a failure receipt is honest yet admitted computation can remain alive without RSS/wall supervision. This is a residual of the prior own-child lifetime finding, not a new physics or pipeline obligation. It does not claim the fixed exact scientific producer currently spawns descendants; no scientific run occurred.

Required minimal repair: on abnormal termination, terminate/verify the owned admitted process group (and any known admitted descendants) even when its leader has already exited. Preserve exact own-group identity, ProcessLookupError races, bounded TERM/KILL escalation, reaping/failure evidence and no restart. Do not infer group quiescence solely from `p.wait()` or leader poll. Add the leader-exit/known-descendant adverse smoke plus existing no-child normal completion. An unconditional new controller or broader process cleanup is neither needed nor authorized.

## Actual bounded evidence

Reviewer script `/tmp/publication-task2-runtime-r2-smoke.py` executes the unmodified supervisor AST body with import/path setup replaced by deterministic fake process/clock/signal objects. It writes unique reviewer temporary paths and does not execute Popen, send OS signals, sleep, import project physics or call the scientific producer. It also injects all three assertion override environment variables and confirms they are removed.

Thirteen ordinary cases exercise the repaired paths: normal single-thread completion; excess threads; telemetry exception; launch receipt failure; KeyboardInterrupt; SIGTERM; RSS overrun; monotonic wall overrun; unexpected process; unobservable-live-child refusal; normal missing-process exit race; ProcessLookupError during cleanup; TERM timeout followed by KILL. Their expected exit/receipt/cleanup behavior holds. Excess process reason is overwritten by the later aggregate thread refusal because each process has a thread; it remains an explicit failure, not acceptance. The fourteenth leader-exit-with-descendant case exposes the residual above. These are mechanism results, not live native resource/timing receipts.

Full scientific execution/results/counters/peak height/RSS/time and different scientific result verification remain owed. ROOT alone owns admission/run/canonical disposition; no formal, physical/B3, main or publication acceptance is granted. No primary/source/Git/registry/ledger/notebook/packet/controller mutation or heavy execution occurred. No other new runtime review verdict was consulted. Only reviewer /tmp outputs were written.
