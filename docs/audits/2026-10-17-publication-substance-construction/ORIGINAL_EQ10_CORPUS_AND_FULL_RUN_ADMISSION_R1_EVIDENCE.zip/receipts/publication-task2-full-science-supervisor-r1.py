"""One ROOT-admitted run; no restart, source edits or persistent pipeline."""
from pathlib import Path
import subprocess,os,json,time,signal,hashlib,psutil
P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');base=Path('/tmp');child=base/'publication-task2-full-science-child-r1.py';result=base/'publication-task2-full-science-supervisor-r1.json';assert not result.exists()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH=str(P))
started=time.time();peak=0;maxthreads=0;reason=None
with (base/'publication-task2-full-science-r1.stdout').open('w') as out,(base/'publication-task2-full-science-r1.stderr').open('w') as err:
 p=subprocess.Popen([str(P/'.venv/bin/python'),'-B',str(child)],cwd=P,env=env,stdout=out,stderr=err,start_new_session=True);proc=psutil.Process(p.pid)
 (base/'publication-task2-full-science-launch-r1.json').write_text(json.dumps({'pid':p.pid,'wall_started':started,'child_script_sha256':hashlib.sha256(child.read_bytes()).hexdigest(),'rss_limit_bytes':2*1024**3,'wall_limit_seconds':86400,'logical_product_limit':250000000,'integer_limit_bits':1024,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),'command':p.args},indent=2)+'\n')
 while p.poll() is None:
  try:
   processes=[proc]+proc.children(recursive=True);rss=sum(x.memory_info().rss for x in processes);peak=max(peak,rss);maxthreads=max(maxthreads,sum(x.num_threads() for x in processes))
   if rss>2*1024**3:reason='resident-memory limit exceeded'
   if time.time()-started>86400:reason='wall-time limit exceeded'
   if len(processes)>1:reason='unexpected child process outside single-process scientific admission'
  except psutil.NoSuchProcess:pass
  if reason:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(1)
 rc=p.wait()
result.write_text(json.dumps({'exit_code':rc,'termination_reason':reason,'sampled_peak_tree_rss_bytes':peak,'max_observed_threads':maxthreads,'wall_seconds':time.time()-started,'full_scientific_acceptance':False,'independent_result_review_required':True},indent=2)+'\n');print(result.read_text());raise SystemExit(rc if rc else int(reason is not None))
