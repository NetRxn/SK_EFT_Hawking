import ast,json,hashlib,tempfile,types
from pathlib import Path
source=Path('/tmp/publication-task2-full-science-supervisor-r1.py').read_text()
tree=ast.parse(source)
# Execute the ORIGINAL supervisor body with imports/path setup replaced by fakes;
# no project/scientific import, subprocess, process signal or actual wait occurs.
tree.body=[n for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom)) and n.lineno!=4]
class NoSuchProcess(Exception):pass
class Denied(Exception):pass
out=[]
for case in ('single_thread','two_threads','child_process','RSS_overrun','wall_overrun','monitor_exception'):
 base=Path(tempfile.mkdtemp(prefix='task2-runtime-review-r1-'));calls=[]
 class Child:
  pid=987654;args=['fake-child']
  def __init__(self):self.polls=0
  def poll(self):self.polls+=1;return None if self.polls==1 else 0
  def wait(self,timeout=None):return 0
 class Proc:
  def __init__(self,*a):pass
  def children(self,recursive=True):
   if case=='monitor_exception':raise Denied('mock telemetry failure')
   return [Proc()] if case=='child_process' else []
  def memory_info(self):return types.SimpleNamespace(rss=2*1024**3+1 if case=='RSS_overrun' else 1024)
  def num_threads(self):return 2 if case=='two_threads' else 1
 class Clock:
  def __init__(self):self.n=0
  def time(self):self.n+=1;return 100 if self.n==1 else (90000 if case=='wall_overrun' else 101)
  def sleep(self,n):pass
 clock=Clock()
 env={'Path':Path,'subprocess':types.SimpleNamespace(Popen=lambda *a,**kw:Child(),check_output=lambda *a,**kw:'fake-head\n',TimeoutExpired=TimeoutError),'os':types.SimpleNamespace(environ={},killpg=lambda *a:calls.append(list(a))),'json':json,'time':clock,'signal':types.SimpleNamespace(SIGTERM=15,SIGKILL=9),'hashlib':hashlib,'psutil':types.SimpleNamespace(Process=Proc,NoSuchProcess=NoSuchProcess),'P':base,'base':base,'child':Path('/tmp/publication-task2-full-science-child-r1.py'),'result':base/'result.json'}
 try:exec(compile(tree,'original-supervisor-body','exec'),env)
 except SystemExit as e:result={'exit':e.code,'receipt':json.loads((base/'result.json').read_text()),'signals':calls}
 except Exception as e:result={'exception':type(e).__name__,'message':str(e),'signals':calls,'receipt_exists':(base/'result.json').exists()}
 out.append({'case':case,**result})
Path('/tmp/publication-task2-runtime-r1-smoke.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
