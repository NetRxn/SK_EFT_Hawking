from collections import Counter, defaultdict
from functools import reduce, cache
from fractions import Fraction
from types import SimpleNamespace
from importlib.util import module_from_spec, spec_from_file_location
from itertools import permutations
import json
from pathlib import Path
import sys

packet = Path(sys.argv[1])
spec = spec_from_file_location("exact_candidate", packet / "candidate.py")
m = module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)
work = m.r5.Work(cap=m.r10.WORK_CAP, oracle_record_cap=m.r10.PAIR_CAP)
reg, (x, y, w, z), inputs, z_inputs, inner_raws, d0, d1 = m.setup(work)
assert (x, y, w, z) == ((0,0,0,0),(1,0,0,0),(0,0,1,0),(1,0,1,0))
cx, _, cw, _, contacts, cy, _ = inputs
cz, _ = z_inputs
assert contacts[m.SLOTS[0]] == d0
assert contacts[m.SLOTS[1]] == d0 + d1 and d0 != d1
E, P, Q, S = m.E, m.P, m.Q, m.S

raw_sites = dict(zip((w, z), inner_raws, strict=True))
for grouped in raw_sites.values():
    assert Counter((k[0], len(v)) for k, v in grouped.items()) == {(2,4):96, (4,1):24}
    assert {k[1:] for k in grouped if k[0] == 4} == set(permutations(range(4)))

@cache
def links_at(site):
    anchors = {(site,a) for a in range(4)} | {
        (reg.step(site,a)[0],b) for a in range(4) for b in range(4) if a != b
    }
    return {anchor: m.r4.f.original_spin4_link(*(
        tuple(P.variable(S("q", (*anchor, hand, j))) for j in range(4))
        for hand in ("L", "R")
    )) for anchor in sorted(anchors)}

@cache
def plaquette(site, k, l):
    return m.r4.f.original_plaquette(reg, site, k, l, links_at(site))

def raw_terms(site, label):
    if site in raw_sites:
        return raw_sites[site][label]
    degree,k,l,mu,nu,a,b = label
    assert degree == 2
    mm = m.r4.o.matrix_multiply
    result = []
    for i,j in ((k,l),(l,k)):
        u = plaquette(site,i,j)
        for p,q,c,d in ((mu,nu,a,b),(nu,mu,b,a)):
            g = mm(mm(reg.gamma[c],reg.gamma[d]),reg.gamma5)
            trace = sum((u[row][col] * g[col][row] for row in range(4) for col in range(4)),P())
            coeff = trace * Fraction(m.r4.o.epsilon((i,j,p,q)),4)
            result.append(SimpleNamespace(t_degree=2,components=((site,p,c),(site,q,d)),
                                          coefficient=coeff))
    return result

rows = [json.loads(line) for line in (packet / "targets.jsonl").read_text().splitlines()]
assert len(rows)==6
rows=rows[-2:]
assert [(row['degrees'],row['direction']) for row in rows]==[([4,2],0),([4,2],1)]

for row in rows:
    target = row["target"]
    mask = int(target["mask_hex"], 16)
    def freeze(v):
        return tuple(map(freeze, v)) if isinstance(v, list) else v
    key = tuple(S(f, freeze(index)) for f,index in target["symbols"])
    counts = Counter(key)
    assert mask.bit_count() == 22
    assert Counter(s.family for s in key) == {"q":23, "J":1, "g1":1, "g2":3}
    assert [s.index for s in key if s.family == "J"] == [(y,0,0)]
    assert all(s.index[2] in ("L","R") for s in key if s.family == "q")
    slot = tuple(target["slot"])
    if "audit_refusal" in row:
        assert slot == m.SLOTS[1]
    peak_pairs = 0
    def project(poly):
        return E(tuple((em, P(tuple((k, v) for k, v in p.terms if not (Counter(k) - counts))))
                       for em, p in poly.terms if em & mask == em))
    def size(poly):
        return sum(len(p.terms) for _, p in poly.terms)
    def mul(a,b):
        global peak_pairs
        pairs = size(a)*size(b)
        assert pairs <= 4096, pairs
        peak_pairs = max(peak_pairs,pairs)
        return project(a*b)
    unit = E(((0,P.scalar(Q(1))),))
    def raw_vertex(site, coframes, label):
        total = E()
        terms = raw_terms(site,label)
        for item in terms:
            coframe_rows = [project(coframes[mu,a]) for _,mu,a in item.components]
            g = m.G2 if item.t_degree == 2 else m.G1
            trace = project(E(((0,item.coefficient*P.variable(g)),)))
            total += reduce(mul, (*coframe_rows,trace), unit)
        return total
    xl,wl,zl,yl = map(tuple, row["branch"])
    assert (wl[0],zl[0]) == tuple(row["degrees"])
    factors = (raw_vertex(x,cx,(2,*xl)), raw_vertex(w,cw,wl),
               raw_vertex(z,cz,zl), project(contacts[slot]), raw_vertex(y,cy,(2,*yl)))
    full = reduce(mul,factors,unit)
    exact = dict(dict(full.terms).get(mask,P()).terms).get(key,Q(0))
    assert str(exact) == row["witness"], (row["witness"],exact)
    print(json.dumps(dict(degrees=row["degrees"],direction=row["direction"],slot=slot,
                          refusal_sample=row.get("audit_refusal"), mask=target["mask_hex"],
                          witness=str(exact), peak_pair_attempts=peak_pairs,
                          raw_orientation_counts=[len(raw_terms(s,l)) for s,l in
                            ((x,(2,*xl)),(w,wl),(z,zl),(y,(2,*yl)))])), flush=True)
