import json
import candidate as m
p=m.accepted_parent()
keys=("kept","only_production_zero","only_oracle_zero","wrong")
a={keys[0]:(m.Q(1,2),4),keys[1]:(m.ZERO,7)}
b={keys[0]:(m.Q(1,2),99),keys[2]:(m.ZERO,2)}
total=p.compare_groups(a,b,m.r5.Work())
assert total==m.Q(1,2)
cases={}
for label,c,d in (
    ("missing_oracle_nonzero", {**a,keys[3]:(m.ONE,1)},b),
    ("missing_production_nonzero",a,{**b,keys[3]:(m.ONE,1)}),
    ("different_sign",a,{**b,keys[0]:(-m.Q(1,2),1)}),
):
    try:
        p.compare_groups(c,d,m.r5.Work())
    except AssertionError:
        cases[label]="refused"
    else:
        raise AssertionError(label)
print(json.dumps(dict(signed_total=str(total),zero_absence="accepted",adverse=cases)))
