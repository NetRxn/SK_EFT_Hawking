import contextlib, inspect, io, json, runpy
from itertools import combinations
from types import SimpleNamespace
from pathlib import Path

with contextlib.redirect_stdout(io.StringIO()):
    f=runpy.run_path(str(Path(__file__).with_name("synthetic.py")))
m=f["m"]
target=f["target"]
inputs=f["inputs"]
z_inputs=f["z_inputs"]
raws=(f["rw"],f["rz"])
label=f["s2_label"]
ry={k:list(v) for k,v in f["rx"].items()}
original=ry[label][0]
held={s for _, mu, a in original.components for (_,key,_),_ in m.r4.rows(f["cx"][mu,a]) for s in key}
q=sorted({s for s in target[1] if s.family=="q" and s not in held})
contact_q=next(s for s in q if s.index==("fixture",100))
alternatives=[tuple(sorted((contact_q,*xs))) for xs in list(combinations([s for s in q if s!=contact_q],3))[:35]]
for replacement in alternatives:
    key=next(k for k in ry if k!=label)
    del ry[key]
    ry[label].append(SimpleNamespace(components=original.components,
                                    coefficient=m.P(((replacement,m.ONE),))))
outer=(ry,f["ry"])
count=m.r5.count
old_add=m.E.__add__
old_check=m.base.Admission.check
last_checked={}
measurements=[]
def check(self,requested):
    frame=inspect.currentframe().f_back
    if frame.f_code.co_name=="outer":
        last_checked[id(frame)]=requested
    return old_check(self,requested)
def add(self,other):
    frame=inspect.currentframe().f_back
    result=old_add(self,other)
    if frame.f_code.co_name=="outer":
        loc=frame.f_locals
        actual=loc["used"]()+count(self)+count(other)+count(result)
        assert self is loc["vertex"] and other is loc["piece"]
        measurements.append((last_checked[id(frame)], actual, count(self),count(other),count(result)))
    return result
m.base.Admission.check=check
m.E.__add__=add
try:
    work=m.r5.Work(cap=200_000,oracle_record_cap=m.r10.PAIR_CAP)
    out,reported_peak=m.oracle(target,inputs,z_inputs,raws,outer,work,20,1,f["degrees"])
    maximum=max(measurements,key=lambda row:row[1])
    print(json.dumps(dict(reported_peak=reported_peak, observed_add_peak=maximum, monitored_adds=len(measurements), full_work=work.used)))
    m.r10.LOCAL_CAP=reported_peak
    work=m.r5.Work(cap=200_000,oracle_record_cap=m.r10.PAIR_CAP)
    out,second_peak=m.oracle(target,inputs,z_inputs,raws,outer,work,20,1,f["degrees"])
    assert second_peak==reported_peak and maximum[1]>reported_peak
    print(json.dumps(dict(cap=reported_peak, silent_overrun=maximum[1]-reported_peak, refusal=False)))
finally:
    m.E.__add__=old_add
    m.base.Admission.check=old_check
