from hashlib import sha256
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import candidate as m

valid=(m.PACKET/"targets.jsonl").read_bytes()
assert len(valid)==m.TARGET_BYTES and sha256(valid).hexdigest()==m.TARGET_DIGEST
m.accepted_parent=lambda: None
m.setup=lambda work:(None,(None,None,None,None),None,None,None,None,None)
m.baseline_controls=lambda *args:None
checked=0
def request(*args):
    global checked
    checked+=1
    raise RuntimeError("ledger reached the request loop")
m.checked_request=request
cases={"same_length_modified":b"X"+valid[1:], "truncated":valid[:-1], "oversized":valid+b"X"}
report={}
with TemporaryDirectory() as scratch:
    m.PACKET=Path(scratch)
    for name,altered in cases.items():
        (m.PACKET/"targets.jsonl").write_bytes(altered)
        try:
            m.run(False,StringIO())
        except AssertionError:
            report[name]="refused before request loop"
        else:
            raise AssertionError(name)
    (m.PACKET/"targets.jsonl").write_bytes(valid)
    try:
        m.run(False,StringIO())
    except RuntimeError as e:
        assert str(e)=="ledger reached the request loop"
        report["exact_ledger"]="admitted to request loop"
    else:
        raise AssertionError("control did not reach request loop")
    assert checked==1 and not (m.PACKET/"original.jsonl").exists()
print(json.dumps(report,indent=2))
