# L1 N16 sibling pilot receipts

The first two terms of the 48-term complementary tuple 0 child and the
36-term shared tuple 1 child passed independent replay. Restore the distinct
parent pickles from the tracked `L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip`
and verify its uncompressed hash manifest. Reproduce the term with the
copied author scripts. Use `exact-multicut.py PARENT input.pkl CASE`,
`reduce-label-frontier.py input.pkl TAG` and `contract-reduced-label.py TAG`.
TAG is pilot for case 0 and primary for case 1. When the first contraction
refuses, supply its preserved frontier to `reduce-label-frontier.py` with
tag rescue. Run `contract-peer.py rescue`. Author hashes bind the restored
inputs and frontiers. Pickle inputs must come from the trusted checkpoint.

The review directories preserve the separate control code, source pins and
terminal outputs. Their input manifests contain original scratch paths.
Restore the listed bytes from the pinned Git archives and regenerated
author states before running the review scripts against them. To check the
four author and independent raw/normalized value agreements and exact
partial sums, run `python3 verify-pilots.py` from this directory.
