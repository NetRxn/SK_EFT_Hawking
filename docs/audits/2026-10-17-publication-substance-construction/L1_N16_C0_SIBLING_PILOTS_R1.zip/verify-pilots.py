from fractions import Fraction
from pathlib import Path
import re

normalized=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
raw=re.compile(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)',re.M)
sizes={'tuple0-1':48,'tuple1-0b':36}
for family, size in sizes.items():
    x=y=Fraction()
    for n in (0,1):
        path=Path(family)/str(n)
        independent=(path/'review/replay.out').read_text()
        a,b,d=map(int,raw.search(independent).groups())
        match=tuple(map(Fraction,normalized.search(independent).groups()))
        author=tuple(map(Fraction,normalized.search((path/'author-exact.out').read_text()).groups()))
        assert (Fraction(a,d*16*4**64),Fraction(b,d*16*4**64))==match==author
        x+=match[0]
        y+=match[1]
        print(family,n,*match,sep='\t')
    print(family,f'2/{size}',x,y,sep='\t')
