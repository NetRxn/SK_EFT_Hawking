# Independent verification of tuple 0 complementary child case 0

The exact normalized scalar is
**1763518048972234363017/5192296858534827628530496329220096 + 0i**.

The source archive was read from publication checkpoint
16eabb4d372f0f7035fe09f78c9cba5ec2d028dd and matched the worktree bytes.
Its manifest verified and both decompressed binary parents matched the
archived pins. The complementary parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
Its binary selector R(0,0,2,0,1) is 1. The first-child parent has selector
0 and distinct factor tables. Only the complementary input contributes
to the arithmetic in this report.

The independent histogram reconstructs all 48 cut coordinates over
6,427,904 matched products of rejected parent factors (0,1).
Case 0 is (18, (3,)) on G(0,4,2) and J(1,4,2), with 70,896
projected pair products. Its exact inverse lift recovers all 397,908
rows with the archived parent Gaussian coefficients and per-factor
denominators. Every stored stage preserves the complete conditioning
and label partition, exact Gaussian coefficients and degree-two axes.

The independent sparse contraction from the five-factor, 74,030-row
rescue input uses no author functions or proportional quotients.
It evaluates 6,945,952 matched products with a largest join of
4,938,288 and 118,976 peak output rows. It applies the factor
denominator 40512224221827380280140849737629696 and external
normalization 1/(16*4^64) once. The replay agrees with the exact
author retry and records the unreduced Gaussian numerator.

Clean scratch execution reproduced the selected cut pickle, roster and
plan, both reductions, the cap-saved checkpoint, and both valid
contraction receipts byte for byte. The initial generic contraction
refused further joins at five factors after 2,618,560 completed products.
The initial rescue command stopped on a missing peer_pair module before
arithmetic. Its failure is frozen separately from the successful retry.

The verified contribution is one of the 48 terms in the complementary
binary child of tuple 0 in descendant (0,0), branch 128.
