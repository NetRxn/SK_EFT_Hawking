#!/usr/bin/env bash
set -euo pipefail
author=/private/tmp/l1-c0-sibling-pilots.zjA5u6/tuple0-1
census=/private/tmp/l1-c0-complementary-census.aRhHhn
root=$PWD
mkdir -p lineage/checkpoint
for script in exact-multicut.py reduce-label-frontier.py contract-reduced-label.py checkpoint/quotient.py; do
    if test "$script" = exact-multicut.py; then
        cmp "archive/$script" "$census/$script"
    else
        cmp "archive/$script" "$author/$script"
    fi
    cp "archive/$script" "lineage/$script"
done
known_peer=/private/tmp/l1-c0-case18.szXdBy
for script in contract-peer.py peer_pair.py; do
    cmp "$known_peer/$script" "$author/$script"
    cp "$author/$script" "lineage/$script"
done
cd lineage
gzip -cd "$root/archive/row-cap-physical-slice-dense-label-tuple0-1-reduced.pkl.gz" > parent.pkl
python3 -u exact-multicut.py parent.pkl input.pkl 0 > plan.out
cmp input.pkl "$author/input.pkl"
cmp input.roster "$census/tuple0-1-pilot.roster"
cmp plan.out "$census/tuple0-1.out"
printf 'PASS complementary cut pickle, roster and plan byte for byte\n'
python3 -u reduce-label-frontier.py input.pkl pilot > reduce.out
cmp reduce.out "$author/reduce.out"
cmp label-pilot-reduced-frontier.pkl "$author/label-pilot-reduced-frontier.pkl"
status=0
python3 -u contract-reduced-label.py pilot > contract.out || status=$?
test "$status" = 2
cmp contract.out "$author/contract.out"
cmp join-cap-dense-label-pilot-reduced.pkl "$author/join-cap-dense-label-pilot-reduced.pkl"
printf 'PASS initial reduction, capped join (exit 2), refusal receipt and checkpoint byte for byte\n'
python3 -u reduce-label-frontier.py join-cap-dense-label-pilot-reduced.pkl rescue > rescue-reduce.out
cmp rescue-reduce.out "$author/rescue-reduce.out"
cmp label-rescue-reduced-frontier.pkl "$author/label-rescue-reduced-frontier.pkl"
python3 -u contract-peer.py rescue > rescue-contract-retry.out
cmp rescue-contract-retry.out "$author/rescue-contract-retry.out"
printf 'PASS rescue reduction and exact retry (exit 0) byte for byte\n'
