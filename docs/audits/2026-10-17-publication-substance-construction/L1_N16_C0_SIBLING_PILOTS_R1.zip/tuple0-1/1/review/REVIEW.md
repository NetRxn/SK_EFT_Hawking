# Independent verification of tuple 0 complementary child case 1

The exact normalized scalar is
**3196789373761759059327/5192296858534827628530496329220096 + 0i**.
The unreduced Gaussian real numerator is
135800079410571790499916295614095429538649326201991043053780992,
and the unreduced imaginary numerator is zero.

The committed source archive at
77456b35690e20579620d6f54625554ad78a130f matches the worktree.
Its archive manifest and decompressed parent hashes verified.
The complementary parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It has binary selector R(0,0,2,0,1)=1 and distinct factor tables from
the first child at selector 0.

An independent histogram reconstructs all 48 cut coordinates over
6,427,904 matched products of rejected factors (0,1). Case 1 is
(20, (3,)) on G(0,4,2) and J(1,4,2), with 70,896 matched pair products.
The inverse lift recovers all 397,908 compatible parent rows and preserves
the exact Gaussian coefficients and per-factor denominators. The
five-factor terminal input holds 74,030 rows and has SHA256
734a7a296aabf25bf0ca14d58efcebcfb7e1c08cade6c5f5a0c4eb2663720aaa.

Two independent unquotiented sparse contractions from that input agree
on the raw numerators and normalized values. The greedy schedule starts
at pair (2,4) and uses 6,945,952 matched products. The alternate schedule
starts at pair (0,2) and uses 13,087,188 matched products. Both import
no author contraction code. They use the factor denominator product
40512224221827380280140849737629696 and external normalization
1/(16*4^64), each applied once.

Clean scratch author execution reproduced the cut pickle, roster, plan,
both reduced checkpoints, cap-saved state, and both contraction
receipts byte for byte. The initial generic contraction refused after
2,618,560 completed products at five factors. The subsequent rescue
aids the same conditioned case and produces the exact terminal receipt.
This review qualifies one of the complementary child's 48 terms.
