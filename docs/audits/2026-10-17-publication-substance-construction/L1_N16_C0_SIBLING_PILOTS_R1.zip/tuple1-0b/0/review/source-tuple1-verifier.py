from collections import Counter, defaultdict
from functools import reduce
from hashlib import sha256
from itertools import combinations, product
from math import factorial, gcd, prod
from operator import itemgetter
from pathlib import Path
from zipfile import ZipFile
import gzip
import pickle

CUT = ('R', 0, 3, 0, 1, 0)
DEN = 40512224221827380280140849737629696

def read(archive, name):
    with ZipFile(archive) as z:
        assert z.testzip() is None
        manifests = [{path.removeprefix('./'): h for h, path in map(str.split, z.read(f).decode().splitlines())}
                     for f in ('manifest.sha256', 'frontiers-uncompressed.sha256')]
        packed = z.read(name + '.gz')
        raw = gzip.decompress(packed)
        assert sha256(packed).hexdigest() == manifests[0][name + '.gz']
        digest = sha256(raw).hexdigest()
        assert digest == manifests[1][name]
        print('archive input', archive, name, digest, flush=True)
        return pickle.loads(raw)

def proj(axes, scope):
    positions = tuple(axes.index(axis) for axis in scope)
    return lambda row: tuple(row[i] for i in positions)

def add(u, v):
    return u[0]+v[0], u[1]+v[1]

def mul(u, v):
    return u[0]*v[0]-u[1]*v[1], u[0]*v[1]+u[1]*v[0]

def overlap(a, b):
    return tuple(axis for axis in a if axis in b)

def groups(factor, shared):
    axes, rows, _ = factor
    key = proj(axes, shared)
    tail = proj(axes, tuple(a for a in axes if a not in shared))
    indexed = defaultdict(dict)
    for row, coeff in rows.items():
        indexed[key(row)][tail(row)] = coeff
    return indexed

def combine(left, right, admitted=None):
    aa, _, da = left
    ba, _, db = right
    shared = overlap(aa, ba)
    axes = tuple(a for a in aa if a not in shared) + tuple(a for a in ba if a not in shared)
    A, B = groups(left, shared), groups(right, shared)
    count = sum(len(A[k])*len(B[k]) for k in A.keys() & B.keys())
    allowed = admitted or (lambda _: True)
    result = defaultdict(lambda: (0, 0))
    for k in A.keys() & B.keys():
        for ar, x in A[k].items():
            for br, y in B[k].items():
                key = ar+br
                if allowed(key):
                    result[key] = add(result[key], mul(x, y))
    return (axes, {r:v for r,v in result.items() if any(v)}, da*db), count

def quotient(factors, i, j):
    left, right = factors[i], factors[j]
    a, _, d = left
    b, _, e = right
    shared = overlap(a,b)
    if not shared:
        return 0
    assert all(axis[0] != 'L' for axis in shared)
    A, B = groups(left,shared), groups(right,shared)
    classes = {}
    qright = defaultdict(lambda: (0,0))
    qleft = {}
    support = sorted(A.keys() & B.keys())
    for key in support:
        pairs = sorted(A[key].items())
        common = gcd(*(entry for _, z in pairs for entry in z))
        phases = ((1,0),(0,1),(-1,0),(0,-1))
        unit = max(phases, key=lambda phase: mul(pairs[0][1],phase))
        signature = tuple((tail,mul((z[0]//common,z[1]//common),unit)) for tail,z in pairs)
        # Each original slice is this primitive vector times its exact Gaussian scale.
        scale = (common*unit[0],-common*unit[1])
        assert all(mul(norm,scale) == original for (_,norm),(_,original) in zip(signature,pairs,strict=True))
        label = classes.setdefault(signature,key)
        for tail, primitive in signature:
            qleft[label+tail] = primitive
        for tail, z in B[key].items():
            qright[label+tail] = add(qright[label+tail],mul(z,scale))
    if len(classes) == len(support) == len(B):
        return 0
    qright = {row:z for row,z in qright.items() if any(z)}
    factors[i] = (shared+tuple(axis for axis in a if axis not in shared),qleft,d)
    factors[j] = (shared+tuple(axis for axis in b if axis not in shared),qright,e)
    return len(support)-len(classes)

def reduce_factors(factors):
    domains = defaultdict(list)
    for axes, rows, _ in factors:
        for i,axis in enumerate(axes):
            domains[axis].append({r[i] for r in rows})
    fixed = {a for a, domains_here in domains.items() if len(domains_here[0])==1 and all(s==domains_here[0] for s in domains_here)}
    for i,(axes,rows,d) in enumerate(factors):
        outward = tuple(a for a in axes if a not in fixed)
        key = proj(axes,outward)
        reduced = {key(row):z for row,z in rows.items()}
        assert len(reduced)==len(rows)
        factors[i] = outward,reduced,d
    for _ in range(2):
        before = sum(len(r) for _,r,_ in factors)
        folded = 0
        for i,j in combinations(range(len(factors)),2):
            folded += quotient(factors,i,j) + quotient(factors,j,i)
        after = sum(len(r) for _,r,_ in factors)
        print('reduction',before,after,'folded',folded,'singleton wires',len(fixed),flush=True)
        if before==after and not folded:
            break

def prune(factors,focus=None):
    for i,j in combinations(range(len(factors)),2):
        if focus is not None and focus not in (i,j):
            continue
        a,A,d = factors[i]
        b,B,e = factors[j]
        shared = overlap(a,b)
        if not shared:
            continue
        ka,kb = proj(a,shared),proj(b,shared)
        allowed = set(map(ka,A)) & set(map(kb,B))
        factors[i] = a,{r:v for r,v in A.items() if ka(r) in allowed},d
        factors[j] = b,{r:v for r,v in B.items() if kb(r) in allowed},e

def reconstruct(factors):
    factors = list(factors)
    reduce_factors(factors)
    prune(factors)
    prune(factors)
    assert quotient(factors,3,6)+quotient(factors,6,3)==0
    a,_,_=factors[3]
    b,_,_=factors[6]
    outside = tuple(axis for axis in a+b if (axis in a) ^ (axis in b))
    checks=[]
    for i,(axes,rows,_) in enumerate(factors):
        if i in (3,6):
            continue
        edge=overlap(axes,outside)
        if edge:
            checks.append((proj(outside,edge), set(map(proj(axes,edge),rows))))
    joined,count=combine(factors[3],factors[6],lambda row: all(key(row) in allowed for key,allowed in checks))
    assert count==1114624 and len(joined[1])==222656
    print('independent exact join',count,'retained rows',len(joined[1]),flush=True)
    factors=[factor for i,factor in enumerate(factors) if i not in (3,6)] + [joined]
    prune(factors,5)
    assert quotient(factors,0,1)+quotient(factors,1,0)==0
    reduce_factors(factors)
    prune(factors)
    prune(factors)
    assert quotient(factors,0,1)+quotient(factors,1,0)==0
    return factors

def conditions(factors, value):
    cut = []
    for axes, rows, d in factors:
        if CUT not in axes:
            cut.append((axes, rows, d))
            continue
        i = axes.index(CUT)
        reduced = {r[:i]+r[i+1:]:z for r,z in rows.items() if r[i]==value}
        assert all(rows[r[:i]+(value,)+r[i:]]==z for r,z in reduced.items())
        cut.append((axes[:i]+axes[i+1:],reduced,d))
    return cut

def full_normalization():
    codes = (503841882182,1461451755920)
    occupation_types = [o for o in product(range(5),repeat=3) if sum(o)<=4]
    occupations = [[occupation_types[(code >> (6*site)) & 63] for site in range(8)] for code in codes]
    edges = [(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
    world = sum((3+k)*n for layer in occupations for site in layer for k,n in enumerate(site))
    cross = sum(weight*other*sum(u>v for u in edge for v in target)
                for layer in occupations
                for (index, (left,right,k)) in enumerate(edges)
                for (nleft,nright,nk) in edges[index+1:]
                for edge,target in [((left,right),(nleft,nright))]
                for weight in [sum(layer[left])+sum(layer[right])-layer[left][k]-layer[right][k]]
                for other in [sum(layer[nleft])+sum(layer[nright])-layer[nleft][nk]-layer[nright][nk]])
    coefficients = [n for layer in occupations for site in layer for n in site]
    order = sum(coefficients)
    sign=(-1)**((world+cross)%2)
    scalar = prod(map(factorial,coefficients))
    assert (sign,order,scalar)==(1,32,16)
    print('external normalization','world',world,'cross',cross,'sign',sign,'occupation degree',order,
          'factorial denominator',scalar,'Haar exponent',2*order,flush=True)

parent = read('restart.zip','tuple1-restart.pkl')
children = [read('separator.zip',f'row-cap-physical-slice-dense-label-tuple1-{i}b-reduced.pkl') for i in (0,1)]
A = parent['factors']
assert Counter(w for a,_,_ in A for w in a) == {w:2 for a,_,_ in A for w in a}
assert tuple(i for i,(a,_,_) in enumerate(A) if CUT in a)==(3,6)
for i in (3,6):
    axes,rows,_=A[i]
    assert {r[axes.index(CUT)] for r in rows} == {0,1}
shared=overlap(A[3][0],A[6][0])
left,right=groups(A[3],shared),groups(A[6],shared)
census=Counter()
for key in left.keys() & right.keys():
    census[key[shared.index(CUT)]] += len(left[key])*len(right[key])
assert census == {0:5318656,1:5318656}
C = [conditions(A,i) for i in (0,1)]
for i in (3,6):
    axes,rows,_=A[i]
    j=axes.index(CUT)
    lifts=[{r[:j]+(b,)+r[j:]:z for r,z in C[b][i][1].items()} for b in (0,1)]
    assert not lifts[0].keys() & lifts[1].keys()
    assert lifts[0] | lifts[1] == rows
print('disjoint exhaustive full cut; matching products',dict(census),flush=True)
for value,child in enumerate(children):
    assert child['conditioning'] == parent['conditioning'] + [(CUT,value)]
    assert child['label_partition'] == parent['label_partition']
    assert child['physical_cut'] == parent['physical_cut']
    assert child['rejected_pair']==(0,1) and child['matched']==6838272
    assert not any(CUT in a for a,_,_ in child['factors'])
    assert prod(d for _,_,d in child['factors'])==prod(d for _,_,d in A)==DEN
    assert len(child['factors'])==6
    assert reconstruct(C[value])==child['factors'], value
    print('PASS each saved factor reproduced from original cut', value,flush=True)
assert children[0]['factors']==children[1]['factors']
assert {k:v for k,v in children[0].items() if k!='conditioning'} == {k:v for k,v in children[1].items() if k!='conditioning'}
for i,(axes,rows,d) in enumerate(children[0]['factors']):
    digest=sha256(repr((axes,sorted(rows.items()),d)).encode()).hexdigest()
    print('identical factor',i,'axes',len(axes),'rows',len(rows),'denominator',d,'canonical repr SHA256',digest,flush=True)
full_normalization()
print('PASS identical signed six-factor contractions and normalization; disjoint full tuple1 contraction is 2 x either child',flush=True)
