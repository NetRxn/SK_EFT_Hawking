# Dense tuple 1 shared-child case 0 independent exact review

The exact normalized contribution is **-174464374284197572836177 / 10384593717069655257060992658440192 + 0i**. This verifies one term out of 36 for the shared child of tuple 1 in dense group 128 descendant (0, 0).

At checkpoint 16eabb4d372f0f7035fe09f78c9cba5ec2d028dd, the committed separator archive supplies the six-factor tuple1-0b parent with uncompressed SHA256 843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077. Independent matching on parent pair (0, 1) reproduces the complete 36-coordinate roster on axes G(0,0,2) and J(1,4,2), with 6,838,272 compatible products across all cases. Ordering by product count and then coordinates assigns index 0 to (17, (3,)) with 142,464 compatible products. The inverse lift reproduces the complete case 0 factor tables from the pinned parent, preserving rows, signed coefficients and denominators.

Separate exact code reconstructs the initial reduction, the completed 34,488-product join and the complete five-factor checkpoint saved on a later 2,657,280-product row-cap refusal. The same independent code then reconstructs the rescued terminal frontier, including all 72,808 rows, signed Gaussian coefficients and denominators. The 6.27-second lineage check carries the stopping receipt and never treats the refused join as completed.

The independent terminal schedule uses ordinary sparse joins without the author's quotient or peer projection passes. Its four joins consume 9,246,720 compatible products, with maximum 4,292,352 in one join and peak retained output of 238,464 rows. It returns the matching signed normalized value in 7.44 seconds. Both real and imaginary components use exact integer arithmetic, factor denominator 40512224221827380280140849737629696 and the previously verified positive scale 1/(16*4^64), applied once.

The equality of the two complete shared-child factor inputs and their normalization was independently established before this replay. This review verifies the indicated term from tuple1-0b; 35 terms remain outside this review. Compensating for the two disjoint children belongs to the later full tuple recombination.

Run python3 verify-lineage.py after restoring separator.zip from the pinned committed Git object. Run python3 replay.py 0 0 /private/tmp/l1-c0-sibling-pilots.zjA5u6/tuple1-0b/label-rescue-reduced-frontier.pkl receipt.out for the separate signed contraction. frozen-inputs.sha256 identifies the external author inputs used by these checks, and review-manifest.sha256 covers the review scripts and evidence.
