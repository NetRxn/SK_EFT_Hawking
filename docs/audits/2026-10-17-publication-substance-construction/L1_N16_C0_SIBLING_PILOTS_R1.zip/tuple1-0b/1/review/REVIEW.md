# Dense tuple 1 shared-child case 1 independent exact review

The exact normalized contribution is **-174464374284197572836177 / 10384593717069655257060992658440192 + 0i**. Case 1 matches case 0 in value. Its coordinate, conditioned input and rescued terminal checkpoint have separate identities.

The committed separator archive at 77456b35690e20579620d6f54625554ad78a130f pins the six-factor tuple1-0b shared-child input to uncompressed SHA256 843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077. Independent support matching on pair (0, 1) reconstructs the complete 36-case census on G(0,0,2) and J(1,4,2) with 6,838,272 compatible products. Ordering on match count and then coordinates assigns case 1 to (24, (3,)) with 142,464 matches. This reproduces the author's case selection and restores all conditioned axes, rows, denominators and signed coefficients in an exact inverse lift.

The separate lineage implementation reproduces the original reduction and a completed 34,488-product join, the saved state at the later 2,657,280-product refusal, and all 72,808 rescued terminal rows with exact coefficients and denominators. The lineage check took 6.35 seconds.

The independent terminal implementation uses ordinary sparse joins without the author's quotient or peer projection passes. Its four joins consume 9,246,720 compatible products, with at most 4,292,352 per join and 238,464 retained output rows. The exact signed replay took 7.88 seconds and matches both author scalar components. The common factor denominator is 40512224221827380280140849737629696 and the previously verified external scale is positive 1/(16*4^64), applied once.

The committed child-equality archive establishes literal equality of the two six-factor children from the disjoint coarser split. This review covers case 1 of 36 for their shared contraction in dense group 128 descendant (0, 0). The factor of two belongs to recombination of the full tuple, and this review verifies no other terms.

Run python3 verify-lineage.py with separator.zip restored from the committed Git object. Run python3 replay.py 1 0 /private/tmp/l1-c0-sibling-case1.njDWp3/tuple1-0b/label-rescue-reduced-frontier.pkl receipt.out for the terminal replay. Run python3 verify-distinct.py with child-equality.zip restored to check input identities and the inherited equality receipt. SOURCE_PINS.txt identifies both archives and the case inputs. frozen-inputs.sha256 and review-manifest.sha256 bind the external inputs and the review evidence.
