from hashlib import sha256
from pathlib import Path
from re import M, search
from zipfile import ZipFile

case0_hashes = {
    'input.pkl': '0dc119f89fcb375be6c8caef342ccfe687a06ae34c83a8807f6856b1ede93185',
    'label-rescue-reduced-frontier.pkl': '3f85f9eb94223807c0e811fa5abcc415ff5e8f23ebe39c746ab2ec48e46577f4',
}
lineage=Path('verify-lineage.out').read_text()
for name, first in case0_hashes.items():
    second = search(rf'^checkpoint {name} SHA256 ([0-9a-f]{{64}})',lineage,M)[1]
    assert first != second
    print('PASS distinct case 0 and case 1',name,first,second)
with ZipFile('child-equality.zip') as equality:
    found=equality.read('verify.out')
    assert found.endswith(b'PASS identical signed six-factor contractions and normalization; disjoint full tuple1 contraction is 2 x either child\n')
    print('PASS committed child equality receipt SHA256',sha256(found).hexdigest())
