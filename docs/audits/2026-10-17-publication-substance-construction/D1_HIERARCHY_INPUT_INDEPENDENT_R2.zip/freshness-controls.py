from pathlib import Path
import json
import subprocess
import sys
from seed_journal import seeded_mutation, outstanding
base = Path(sys.argv[1])
table = Path("papers/D1/tables/platform_hierarchy.tex")
initial = table.read_bytes()
def check(name):
    cmd = [sys.executable, "-B", "scripts/validate.py", "--check", "tables_fresh",
           "--check", "bundle_tables_use_pipeline", "--no-memo"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    (base / f"full-freshness-{name}.log").write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout
    assert "96 output files across 20 papers" in result.stdout, result.stdout
    return result.returncode
def wrap_row(text):
    row, = (line for line in text.splitlines() if "Steinhauer/de" in line)
    assert text.count(row) == 1
    return text.replace(row, "\\iffalse\n" + row + "\n\\fi")
base_rc = check("baseline")
with seeded_mutation(table, wrap_row, reason="independent canonical freshness companion to inactive generated row"):
    seeded = table.read_bytes()
    assert seeded != initial
    seed_rc = check("hidden-row")
    assert table.read_bytes() == seeded
restored_rc = check("restored")
assert table.read_bytes() == initial
assert not outstanding(include_live=True)
print(json.dumps({"baseline": base_rc, "hidden_row": seed_rc, "restored": restored_rc, "hidden_bytes_retained_through_checks": True}))
