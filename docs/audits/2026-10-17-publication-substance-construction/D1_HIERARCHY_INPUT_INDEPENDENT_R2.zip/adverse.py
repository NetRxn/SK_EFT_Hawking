from pathlib import Path
import hashlib, json, subprocess, sys
from seed_journal import seeded_mutation, outstanding

bundle = Path("papers/D1")
draft = bundle / "paper_draft.tex"
table = bundle / "tables/platform_hierarchy.tex"
pdf = bundle / "paper_draft.pdf"
evidence = Path(sys.argv[1])
expected = (
    ("Steinhauer/de Nova", "8.53", "2.38"),
    ("Heidelberg, projected", "7.32", "1.59"),
    ("spin-sonic BEC (Trento)", "9.89", "1.41"),
)

def one(s, original, replacement):
    assert s.count(original) == 1, original
    return s.replace(original, replacement)

def command(case, key, command):
    completed = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (evidence / f"{case}-{key}.log").write_text(completed.stdout)
    return completed.returncode

def numeric(case):
    return command(case, "numeric", [sys.executable, "-B", "scripts/validate.py", "--check", "d1_hierarchy_table"])

def compile_pdf(case):
    return command(case, "compile", [sys.executable, "-B", "scripts/compile_bundle_pdf.py", "D1", "--force"])

def visible(case):
    text = subprocess.check_output(["pdftotext", "-layout", pdf, "-"], text=True)
    (evidence / f"{case}-pdf.txt").write_text(text)
    return [sum(all(term in line for term in terms) for line in text.splitlines()) for terms in expected]

initial = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in (draft, table, pdf)}
results = {"active": (numeric("active"), 0, visible("active"))}
assert results["active"] == (0, 0, [1, 1, 1]), results
input_cmd = r"\input{tables/platform_hierarchy.tex}"
label = r"\label{tab:hierarchy}"
with seeded_mutation(draft, lambda s: one(s, input_cmd, r"\begingroup " + input_cmd + r"\endgroup"), reason="independent local unexpected prologue"):
    assert numeric("grouped-input") == 1
    results["grouped-input"] = 1
with seeded_mutation(draft, lambda s: one(s, label, r"\makeatletter\let\input\@gobble\makeatother" + "\n" + label), reason="independent active input override in local prologue"):
    assert numeric("let-shadow") == 1
    results["let-shadow"] = 1
with seeded_mutation(table, lambda s: one(s, "8.53", "9.53"), reason="independent exact numerical corruption"):
    assert numeric("cell-drift") == 1
    results["cell-drift"] = 1
def wrap_float(s):
    i = s.index(label)
    start = s.rindex(r"\begin{table", 0, i)
    stop = s.index(r"\end{table", i)
    stop = s.index("}", stop) + 1
    return s[:start] + "\\iffalse\n" + s[start:stop] + "\n\\fi" + s[stop:]
with seeded_mutation(draft, wrap_float, reason="independent composed D1 whole float in inactive branch"):
    results["whole-float-hidden"] = (numeric("whole-float-hidden"), compile_pdf("whole-float-hidden"), visible("whole-float-hidden"))
    assert results["whole-float-hidden"] == (0, 1, [0, 0, 0]), results
def wrap_row(s):
    row, = [line for line in s.splitlines() if "Steinhauer/de" in line]
    return one(s, row, "\\iffalse\n" + row + "\n\\fi")
with seeded_mutation(table, wrap_row, reason="independent generated-file row in inactive branch"):
    results["generated-row-hidden"] = (numeric("generated-row-hidden"), compile_pdf("generated-row-hidden"), visible("generated-row-hidden"))
    assert results["generated-row-hidden"] == (0, 0, [0, 1, 1]), results
results["restored"] = (numeric("restored"), compile_pdf("restored"), visible("restored"))
assert results["restored"] == (0, 0, [1, 1, 1]), results
assert not outstanding(include_live=True)
assert initial == {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in initial}
print(json.dumps({"cases": results, "restored_sha256": {str(k): v for k, v in initial.items()}}, indent=2))
