from collections import Counter
from hashlib import sha256
from pathlib import Path
import json,sys
sys.path.insert(0,"scripts")
from validation.checks import prose_lean_refs as refs

root=Path(sys.argv[1])
source={}
for name in refs.BUNDLE_CODES:
    old=root/"base/papers"/name/"paper_draft.tex"
    new=root/"composed/papers"/name/"paper_draft.tex"
    expected=Counter(t for t,_ in refs._prose_verbatim_tokens(old.read_text()))
    draft=new.read_text()
    actual=Counter(t for t,_ in refs._prose_verbatim_tokens(draft))
    table_set=list(refs._bundle_table_sources(new))
    for loc,table,error in table_set:
        assert error is None,(name,loc,error)
        actual.update(t for t,_ in refs._prose_verbatim_tokens(table,macro_source=draft))
    assert expected==actual,(name,expected-actual,actual-expected)
    source[name]=dict(tokens=sum(actual.values()),distinct=len(actual),owned=len(table_set),
                      occurrence_digest=sha256(json.dumps(actual,sort_keys=True).encode()).hexdigest())
totals={k:sum(v[k] for v in source.values()) for k in ("tokens","owned")}
assert len(source)==21 and totals=={"tokens":2540,"owned":84}
base=json.loads((root/"base-cli.json").read_text())["checks"]
new=json.loads((root/"composed-cli.json").read_text())["checks"]
assert base["prose_theorem_reference_coverage"]==new["prose_theorem_reference_coverage"]
print(json.dumps(dict(bundles=source,totals=totals,checker_equal=True),indent=2))
