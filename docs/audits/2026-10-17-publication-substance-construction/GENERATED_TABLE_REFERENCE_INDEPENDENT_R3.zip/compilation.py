from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, "scripts")
from compile_bundle_pdf import compile_one, recorded_table_inputs
from render_paper_tables import discover_specs, render_paper, spec_output_paths

root = Path(sys.argv[1]).resolve()
composed = Path.cwd()
report = {}
groups = ("D1","D2","D4","D6","D9","D10","I1")
before = {}
for bundle in groups:
    d = composed / "papers" / bundle
    before.update({str(p.relative_to(composed)): sha256(p.read_bytes()).hexdigest()
                   for p in spec_output_paths(d/"tables.py", strict=True)})
specs = discover_specs()
for bundle in groups:
    render_paper(bundle,specs[bundle])
assert all(sha256((composed/p).read_bytes()).hexdigest()==v for p,v in before.items())
lanes = [(composed/bundle_path,bundle) for bundle in groups
         for bundle_path in ("papers/" + bundle,)]
lanes.append((root/"base/papers/I1","I1-base"))
for paper, label in lanes:
    ok, msg, pages = compile_one(paper, force=True, keep=True)
    print(label,msg,flush=True)
    assert ok
    artifact = Path(msg.rsplit("artifacts kept: ",1)[1])
    recorder = artifact / "paper_draft.fls"
    (root / f"{label}.fls").write_bytes(recorder.read_bytes())
    try:
        opened = recorded_table_inputs(paper,recorder)
    except ValueError as error:
        assert label=="I1-base" and "unowned table inputs: tables/table1_stages.tex" in str(error)
        opened = str(error)
    report[label] = {"compile":msg.splitlines()[0],"opened":opened}
    if label == "D1":
        txt=subprocess.check_output(["pdftotext","-layout",str(paper/"paper_draft.pdf"),"-"],text=True)
        rows={}
        for label2, fragments in {
            "Steinhauer/de Nova":("8.53","2.38","disp"),
            "Heidelberg, projected":("7.32","1.59","diss"),
            "BEC (Trento)":("9.89","1.41","disp"),
        }.items():
            found=[ln.strip() for ln in txt.splitlines() if label2 in ln and all(fragment in ln for fragment in fragments)]
            assert len(found)==1,(label2,found)
            rows[label2]=found[0]
        report["D1"]["rows"]=rows
(root/"compile.json").write_text(json.dumps({"regenerated_bytes":before,"compiles":report},indent=2)+"\n")
