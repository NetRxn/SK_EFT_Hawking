from contextlib import ExitStack
from hashlib import sha256
import json,re,subprocess,sys
from pathlib import Path

sys.path.insert(0,"scripts")
from compile_bundle_pdf import compile_one, recorded_table_inputs
from seed_journal import outstanding, seeded_mutation

t=Path(sys.argv[1])
case=sys.argv[2]
d=Path("papers/D9/paper_draft.tex").resolve()
table=d.parent/"tables/exact.tex"
probe=f"d9_{case}_bad_ref"
base={p:(p.read_bytes(),p.stat().st_mtime_ns) for p in (d,table)}
prior=outstanding(include_live=True)
token=r"\lean{diamondDist\_dephasing\_eq}"
anchor=r"\input{tables/exact.tex}"
def transform(s):
    if case=="ifthen":
        assert s.count(anchor)==1
        return s.replace(anchor,r"\iffalse\ifthenelse{1=1}{A}{B}\else"+anchor+r"\fi").replace(
            r"\usepackage{graphicx}",r"\usepackage{graphicx}"+"\n"+r"\usepackage{ifthen}")
    return s
def seed(s):
    assert s.count(token)==1 and s[:s.index(token)].count("\n")==8
    q=r"\lean{"+probe.replace("_",r"\_")+"}"
    if case=="percent":
        q=r"\verb|%| "+q
    return s.replace(token,q)
with ExitStack() as stack:
    if case=="ifthen":
        stack.enter_context(seeded_mutation(d,transform,reason="D9 rendered conditional independent"))
    stack.enter_context(seeded_mutation(table,seed,reason=f"D9 registered theorem {case} independent"))
    p=subprocess.run([sys.executable,"-B","scripts/validate.py","--check","prose_theorem_reference_coverage","--json"],capture_output=True,text=True)
    (t/f"{case}-seed-cli.json").write_text(p.stdout)
    (t/f"{case}-seed-cli.stderr").write_text(p.stderr)
    check=json.loads(p.stdout)["checks"]["prose_theorem_reference_coverage"]
    findings=[item for item in check["details"] if probe in item["name"]]
    ok,msg,_=compile_one(d.parent,force=True,keep=True)
    rec=Path(msg.rsplit("artifacts kept: ",1)[1])/"paper_draft.fls"
    opens=recorded_table_inputs(d.parent,rec)
    text=subprocess.check_output(["pdftotext","-layout",str(d.with_suffix(".pdf")),"-"],text=True)
    visible=bool(re.search(r"[ _]+".join(probe.split("_")),text))
    (t/f"{case}-seed.fls").write_bytes(rec.read_bytes())
    (t/f"{case}-seed.pdf.txt").write_text("\n".join(line for line in text.splitlines() if "bad" in line)+"\n")
assert all((path.read_bytes(),path.stat().st_mtime_ns)==v for path,v in base.items())
assert prior==outstanding(include_live=True)
r=dict(case=case,exit=p.returncode,check_passed=check["passed"],findings=findings,compile=ok,compile_report=msg.splitlines()[0],opens=opens,probe_visible=visible,restored=True)
(t/f"{case}-seed.json").write_text(json.dumps(r,indent=2)+"\n")
print(r)
