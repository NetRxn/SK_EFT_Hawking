# L1 first scale-up author result and edge-generation limit

The first of four pinned cases (103607566400,1256282652690), weight 96,
has the exact author coefficient
20062028626454856719970703125/2535301200456458802993406410752.
All four necessary channels are covered by two original chirality
pairs. One representative has a nonzero exact result. The other
is zero after exact proportional slice elimination. The original
factorials, 64 coframe quarters and orientation signs are included.
No residual row has been removed. Independent verification is required.

The benchmark log separately records local Haar tables, edge planning,
site preparation and signed joins. All 24 edge tables in this case were
reused from hashed earlier patterns. The warm-reuse run took approximately
7.6 seconds for anchor tables plus edge planning, 6.7 seconds for site
assembly and 32.1 seconds for signed contraction. It does not establish
a cold factor-generation time or a whole-family throughput.

The three other cases initially refused prospective edge preparation at
23,003,136, 22,239,648 and 53,094,400 matched products. For the first of
these, the pivotal original edge table completed in four disjoint
first-owner-word partitions, with at most 5,750,784 matched products
and 10,336 retained rows per partition. There are 41,344 rows in the
complete table. Partitioning by the output word keeps every Gaussian
sum wholly inside its partition. The table hash is retained instead of
checking its 3.7 MB body into Git.

To replay, restore the scale preparations from the independent pilot
archive and the old/corrected signed factors as directed by their
checkpoints. Run benchmark.py in scratch with the prepared scaling
directory, old signed directory, corrected signed directory, exact
science checkout, and its Python interpreter. This legacy replay
expects the extracted nine-state anchor directory
l1-odd-joint-pilot.Q5JYqN beside the old signed directory. The later
benchmark_tiled.py accepts the nine-state anchor location explicitly.
The first-profile replay may be limited by retaining only its row in
the copied scaling/next-cases.out. Compare the exact value and the
hashed generated tables. Elapsed times will vary.

From the second case directory, the exact edge replay is:

```sh
python3 ../edge_tiled.py . 1 3 '(4, 0, 0, 0, 0)' '(4, 0, 0, 1, 1)' > tiled-edge0.out
mv edge-selected.tsv tiled-edge0.tsv
```

The separate tiled benchmark on remaining cases is still open.
