from pathlib import Path
from ast import literal_eval
from collections import defaultdict
from time import monotonic
from fractions import Fraction
from hashlib import sha256
import os,sys,shutil,subprocess

scratch=Path.cwd()
evidence,old,corrected,science,python=map(Path,sys.argv[1:])
os.environ['PYTHONPATH']=str(science)
os.environ['PYTHONDONTWRITEBYTECODE']='1'
def run(name,args,out):
    started=monotonic()
    with Path(out).open('w') as log:
        result=subprocess.run([str(name),*map(str,args)],stdout=log,stderr=subprocess.STDOUT)
    print('elapsed',out,round(monotonic()-started,2),'exit',result.returncode,flush=True)
    if result.returncode:raise RuntimeError((str(out),result.returncode))
def state_rows(path):
    rows=defaultdict(set)
    for line in path.read_text().splitlines():
        i,*row=map(int,line.split())
        rows[i].add(tuple(row))
    return {i:frozenset(row) for i,row in rows.items()}
def swap(s):return frozenset((t,x,k,r,l) for t,x,k,l,r in s)
def patterns(path):
    for row in path.read_text().splitlines():
        if row.startswith('pattern '):
            yield literal_eval(row[8:row.rindex(')')+1]),int(row.split()[-1])
seen={}
for donor in (old,corrected):
    for i,(key,_) in enumerate(patterns(donor/'edge-plan.out')):
        seen[key]=donor/'edge-batch'/f'{i:02}.tsv'
for record in (evidence/'next-cases.out').read_text().splitlines():
    a,b,w=map(int,record.split()[:3])
    item=evidence/'candidate-support'/f'{a}-{b}'
    os.environ['L1_PROFILE_CODES']=f'{a},{b}'
    work=scratch/item.name
    work.mkdir()
    os.chdir(work)
    print('profile',a,b,w,flush=True)
    for f in scratch.glob('*.py'):
        if f.name!='benchmark.py':shutil.copyfile(f,work/f.name)
    shutil.copyfile(old.parent/'l1-odd-joint-pilot.Q5JYqN'/'root.tsv','root.tsv')
    states=state_rows(item/'states.tsv')
    bystate={state:i for i,state in states.items()}
    assert len(bystate)==len(states)
    reps={i for i,state in states.items() if i<bystate[swap(state)]}
    assert 2*len(reps)==len(states)
    print('exchange pairs',len(reps),flush=True)
    for name in ('states.tsv','anchor-plan.tsv'):
        Path(name).write_text(''.join(line+'\n' for line in (item/name).read_text().splitlines() if int(line.split()[0]) in reps))
    Path('coframe-roster.tsv').symlink_to(old/'coframe-roster.tsv')
    try:
        run(python,['temporal.py'],'temporal.out')
        run(python,['spatial.py'],'spatial.out')
        run(sys.executable,['edge_plan.py','.'],'edge-plan.out')
        folder=Path('edge-batch')
        folder.mkdir()
        for i,(pattern,products) in enumerate(patterns(Path('edge-plan.out'))):
            path=folder/f'{i:02}.tsv'
            if pattern in seen:
                path.symlink_to(seen[pattern])
                continue
            if products>8_000_000:raise RuntimeError(('edge preflight',i,pattern,products))
            v1,v2,S,T=pattern
            run(sys.executable,['edge_exact.py','.',v1,v2,repr(S),repr(T)],f'edge-{i:02}.out')
            Path('edge-selected.tsv').replace(path)
            seen[pattern]=path.resolve()
        count=len(list(folder.glob('*.tsv')))
        new=len(list(Path('.').glob('edge-*.out')))-1
        print('edge factor count',count,'new',new,flush=True)
        run(sys.executable,['site_exact.py','.'],'site.out')
        value=Fraction()
        for case in sorted(reps):
            log=f'case-{case:03}.out'
            run(sys.executable,['quotient_pilot.py','.','.',case],log)
            last=Path(log).read_text().splitlines()[-1].split()
            if last[:2]==['EXACT','ZERO']:continue
            assert last[:3]==['EXACT','channel',str(case)] and Fraction(last[4])==0
            value+=Fraction(last[3])
        print('COMPLETE AUTHOR PROFILE',a,b,w,2*value,flush=True)
    except RuntimeError as error:
        print('PROFILE OPEN',a,b,error,flush=True)
    finally:
        os.chdir(scratch)
