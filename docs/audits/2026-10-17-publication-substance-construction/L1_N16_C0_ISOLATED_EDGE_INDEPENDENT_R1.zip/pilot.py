from fractions import Fraction as F
from math import factorial,prod
from classify import classify,coeff
from contract import value
from census import occupancy,profile,write
a,b=166856593410,8960795485785
admitted,overlap=classify()
row=next(t for t in overlap if t[:2]==(a,b))
assert row==(a,b,96,(((4,5,0),(2,2),(2,2),2,0),))
A,lA,eA=profile(a); B,lB,eB=profile(b)
roots=[n for m in occupancy(a)+occupancy(b) for n in m if n]
assert roots==[2]*16
edge=(4,5,0)
nonpilot=[n for e in A.keys()|B.keys() if e!=edge for n in A.get(e,(0,0))+B.get(e,(0,0)) if n]
assert len(nonpilot)+len(lA+lB)==12
assert all(not(A.get(e) and B.get(e)) and min(sum(eA.get(e,(0,0))),sum(eB.get(e,(0,0))))<4 for e in A.keys()|B.keys() if e!=edge)
coeff_other=prod(coeff(n,0,0) for n in tuple(nonpilot)+lA+lB)
divisor=prod(factorial(n) for n in roots)
assert F(coeff_other,divisor)==F(1,16)
u,v=value(a),value(b)
L,R=value(a,0),value(a,1)
assert L==R==F(2462520447,2097152)
assert value(a,0,reverse=True)==L
wrong=value(a,0,mutant=4)
assert wrong==F(397852479,2097152)
scalar=u*v
spin=(L+R)*v/F(16*3**7)
full=scalar+spin
assert scalar==F(6533759724910137236961,17592186044416)
assert full==F(52271073647433042742089,140737488355328)
assert full*96==F(156813220942299128226267,4398046511104)
print("pilot scalar",scalar,"spin contribution",spin,"original",full,"orbit weighted",full*96)
print("remaining isolated",len(overlap)-1,sum(r[2] for r in overlap)-96)
print("remaining temporal block",11802-len(admitted)-1,1014585-sum(r[2] for r in admitted)-96)
write("pilot.tsv",[(a,b,96,full,scalar,spin,wrong)])
from classify import degree,removed
from census import read
isolated_remaining=[(p,q,w) for p,q,w,tag in overlap if (p,q)!=(a,b)]
seen=removed|{(p,q) for p,q,w,f in admitted}|{(a,b)}
block_remaining=[(p,q,w) for p,q,w in (map(int,r) for r in read(degree+"/orbits.tsv")) if (p,q) not in seen]
assert (len(isolated_remaining),sum(r[2] for r in isolated_remaining))==(75,5664)
assert (len(block_remaining),sum(r[2] for r in block_remaining))==(11069,953019)
write("isolated-remaining.tsv",isolated_remaining)
write("block-remaining.tsv",block_remaining)
