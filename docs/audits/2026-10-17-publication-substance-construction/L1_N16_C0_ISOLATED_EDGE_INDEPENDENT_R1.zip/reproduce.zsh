#!/bin/zsh
set -euo pipefail
cd -- "${0:A:h}"
primary=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking
frozen=/private/tmp/l1-c0-isolated.TVUeNEzL
degree=/private/tmp/l1-c0-degree-independent.nEpHYJlb
q3=/private/tmp/l1-c0-q3-independent.t3DCmj20
core=/private/tmp/l1-c0-core-independent.xCQTska6
(cd "$primary"; python3 scripts/codex_continuity.py check .codex/continuity/l1-c0-isolated-edge-independent-r1.json) > continuity.out
verify() {
    local dir=$1 digest=$2 out=$3
    (cd "$dir"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > "$out"
    test "$(cut -d' ' -f1 < "$out" | head -1)" = "$digest"
}
verify "$frozen" 1ff77eb354e9adeebee846a519ef20e4d3499ccfcefca814c3a4f206db9d4c1f author-manifest.out
verify "$degree" 5975bed7abd9b5fa50ae8e7396d9c22d907d12c2b0953bc56c184a72052b59a5 degree-manifest.out
verify "$q3" 4da5f6dbe2d0cf97f2b1d81f9274d96d32eb3a3195f1ebca0c6a31723dce6622 q3-manifest.out
verify "$core" 3fb24f1cf80f9fcf0b78663c9a60e0c8e3d9ce4eefc49d4841f4b2012dc616ef core-manifest.out
export PYTHONDONTWRITEBYTECODE=1
PYTHONPATH="$primary" "$primary/.venv/bin/python" source.py > source.out
cmp source-edge.tsv "$frozen/coframes.tsv"
cmp source-edge.tsv "$frozen/edge_coframes.tsv"
awk '$1==1 {print $2 "\t" $3 "\t" $4}' "$frozen/grams.tsv" | cmp source-gram.tsv -
clang++ -O3 -std=c++20 -Wall -Wextra -Werror -fsanitize=undefined -fno-sanitize-recover=all edge.cpp -o edge
./edge
sort mixed.tsv | cmp - <(sort "$frozen/mixed.tsv")
python3 decorate.py > decorate.out
for f in adjoint.tsv bivectors.tsv; do sort "$f" | cmp - <(sort "$frozen/$f"); done
for f in decorated-{0,1}-{0,1}.tsv; do cmp "$f" "$frozen/$f"; done
python3 scalar_run.py > scalar.out
cmp scalar-values.tsv "$frozen/scalar-values.tsv"
python3 pilot.py > pilot.out
