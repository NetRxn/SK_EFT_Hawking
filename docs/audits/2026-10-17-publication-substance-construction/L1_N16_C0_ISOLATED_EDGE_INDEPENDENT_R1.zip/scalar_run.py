from fractions import Fraction as F
from classify import classify,canonical,write
from contract import value
admitted,overlap=classify()
codes={x for a,b,w,f in admitted for x in (a,b)}
layers={c:value(c) for c in sorted({canonical(c) for c in codes})}
for a in (166856593410,8960795485785):
    assert value(a)==layers[canonical(a)]
signed=[]
for a,b,w,f in admitted:
    z=layers[canonical(a)]*layers[canonical(b)]*f
    assert z>0
    signed.append((a,b,w,z))
subtotal=sum(w*z for a,b,w,z in signed)
assert subtotal==F(15291812481604689642179533548685571603119,1323453075832297505748418560)
print("scalar subtotal",subtotal)
write("scalar-values.tsv",signed)
