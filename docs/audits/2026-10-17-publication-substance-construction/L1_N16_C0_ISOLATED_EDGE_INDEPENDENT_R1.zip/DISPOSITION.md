# Scoped acceptance

Independent replay verifies the scalar-channel exclusion, 732 exact values, and the overlapping pilot. Full temporal-block and c0 acceptance remain open.
