# L1 original paired cuts 1, 2, 8 and 9

These are four distinct original outer coordinates of group 128, descendant (0,1), tuple 0. Each has a complete independent direct scalar replay. Cut 1 has 23 exact inner terms. Cut 2 has a separately reconstructed 16-term partition after an outer join-cap refusal. Cuts 8 and 9 each have nine exact inner terms.

Verify manifest.sha256 and the portable manifest in each independent review directory. ROOT verified the original review manifests before packaging. Machine-local continuity packets are retained locally.

Restore the two branch operands, full outer roster and signed pair scripts from L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip at 383f42e573962e8f7f41c0111c82a59a605c73ff. Verify branch hashes. Reproduce the signed outer pair with sum-branches-checked.py, reduce-label-frontier.py and contract-reduced-label.py. The paired cap and required intermediate hashes are in each outer-inputs.sha256.

For cut 1, run the original first nine slice invocations on the frozen outer cap, then use run-primary-selected.py with indices 9 through 22. Compare the complete saved 23-value support roster and all plan and contraction receipts. The two primary refusals at 21 and 22 use reduce-open.py followed by the two exact four-factor shard plans. The eight disjoint author intervals per term appear in each plan and receipt. Run sum-shards.py and sum-case1.py to reproduce every term. The common external normalization is applied once.

For cut 2, the original outer contract returned a five-factor join cap. The legacy row-cap slicing call fails because this checkpoint carries no rejected-pair field. The trace is retained. From a fresh author scratch directory, use the scripts in author/2/frontier to reproduce the complete 16-value G(1,0,2) conditioning, save the weighted roster, and contract all 16 terms. Eight finish through the generic path. The eight three-factor caps finish with two disjoint triangle shards. Use run-cohort.py, triangle-forecast.py and finish-triangles.py from the saved initial preparation and contraction state. Verify operands.sha256 before using a restart. Run sum-case2.py from the frontier directory.

For cuts 8 and 9, use run-primary.py with the frozen row cap and its quotient.py. Run reduce-open.py on the six refused slices in each primary.tsv and reproduce them to scalar. All nine terms use the same scalar convention once. The independent replay scripts can be run from scratch with their recorded source paths adapted to the restored author inputs.

For all four results, run each sum-case<cut>.py from its author directory (the frontier subdirectory for cut 2) and compare every line against the saved author ledger. Run coverage-retally.py with the repository audit archive directory as its argument, then compare all 48 rows against coverage-ledger.tsv.
