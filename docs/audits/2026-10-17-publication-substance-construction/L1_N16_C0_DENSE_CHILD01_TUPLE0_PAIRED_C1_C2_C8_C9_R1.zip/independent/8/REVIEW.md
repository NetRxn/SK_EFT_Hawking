# Independent review of paired outer coordinate 8

The independently verified signed contribution of outer coordinate `(18,(1,))` in group128 descendant `(0,1)`, tuple 0 is `11627739971317979867547/2596148429267413814265248164610048 + 0i`. The raw Gaussian subtotal is `(987896183859212288341210765002106713941956281365039941077172224,0)` over factor denominator `40512224221827380280140849737629696`. The common positive external normalization `1/(16*4^64)` is applied once. This acceptance covers outer coordinate 8.

The named continuity revision matched publication checkpoint `3c2d5779d2cd749d9835ef549b8ff93197a06d5d`. The two disjoint binary-selector inputs use the accepted hashes and share six environment factors. The independent census recovers all 48 coordinates and 6,427,904 compatible products per original branch. A condition-first signed constructor indexed the opposite factor and reconstructed every one of the seven combined tables using 106,344 products per branch. Their sum has 77,328 retained pair rows. The original constructor, outer reduction and refusal reproduced byte for byte. The combined input SHA-256 is `f0b0705c425651602bc23516b28f294e4c00a96a901786de5d34b0f41acc3e2c` and the retained cap SHA-256 is `9f97773b77613dc96b0a263c43449e255f8434ac5519aa58d1f804e1a1fc52d5`. Independent reconstruction took 2.13 s. Constructor, reduction and refusal readbacks took 1.594, 7.094 and 3.139 s wall respectively.

The inner census recovered 9 disjoint coordinates with 1,021,248 compatible products. Every exact inverse lift recovered the original conditioned rows, keys, axes, signed Gaussian coefficients and denominators. The 9 generic terminals were verified with independent sparse Gaussian contraction.  All terminals completed in the bounded generic route. Each signed raw Gaussian pair and normalized pair was independently checked. The signed ledger gives the route, raw value, projected work and observed work per slice.

The 43 generic inner commands across 17 stages reproduced each log and saved checkpoint byte, preserving all 8 refusals. Their summed wall duration was 204.9363 s under concurrent execution. The independent terminal replays used 37,350,920 products and 40.101836 summed wall seconds. The author terminal receipts record 16,869,729 products. Terminal work totals exclude generic work performed before a refusal. The signed ledger and timing tables preserve per-slice measurements.

Verify the portable receipts from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B tools/ledger-metrics.py 8 | cmp - signed-ledger.tsv
python3 -B tools/summarize.py | cmp - summary.out
```

The three operand inventories bind the original binary and text files on the author scratch path. Full recalculation of the binary lineage requires those pinned files. The portable manifest contains the selected receipts, hashes, timings, authority checks and review scripts.
