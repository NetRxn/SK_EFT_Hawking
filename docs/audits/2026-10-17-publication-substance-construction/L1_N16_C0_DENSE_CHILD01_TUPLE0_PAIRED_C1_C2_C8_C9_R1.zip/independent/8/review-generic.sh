#!/usr/bin/env bash
set -euo pipefail
a=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence
p="$a/probe8-inner"
cap=row-cap-physical-slice-dense-label-sum8-reduced.pkl
until test -s "$p/checkpoint/quotient.py" && test -s "$a/$cap" &&
      test -s "$a/contract-8.out" && tail -1 "$a/contract-8.out" | grep -q '^open row cap '; do
  sleep 5
done
(
  cd "$a"
  shasum -a 256 combined-8.pkl "$cap"
) > pair-pins.sha256
sed -nE 's/^open row cap 7 ([0-9]+) frontier saved$/\1/p' "$a/contract-8.out" > inner-products.txt
test -s inner-products.txt
python3 -B pin-sources.py > source-pins.out
python3 -B rescue-source-pins.py 8 > rescue-source-pins.out
/usr/bin/time -p python3 -B pair-route-audit.py > pair-route-audit.out 2> pair-route-audit.time
bash combine-readback.sh > combine-readback.out
bash pair-lineage.sh > pair-lineage.out

until test -s "$p/slice-0.roster" && test -s "$p/primary.tsv" &&
      test "$(wc -l < "$p/primary.tsv")" -eq "$(python3 -B -c 'from ast import literal_eval; from pathlib import Path; import sys; print(len(literal_eval(Path(sys.argv[1]).read_text())[1]))' "$p/slice-0.roster")"; do
  sleep 5
done
/usr/bin/time -p python3 -B audit.py 8 --cuts-only > cut-audit.out 2> cut-audit.time
python3 -B -u inner-lineage.py 8 $(cut -f1 inner-roster.tsv) > inner-lineage.tsv
