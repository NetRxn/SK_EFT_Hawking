# Independent review of original paired cut 2

The exact subtotal at (33,(3,)) is **3196789373761759059327/2596148429267413814265248164610048 + 0i**. All 16 distinct signed terms independently match the complete author ledger. This accepts the single paired coordinate in descendant (0,1), tuple 0.

Both pinned original branches have complete 48-coordinate support with 6,427,904 selected-pair products each. They are disjoint on R(0,0,2,0,1) and share all six environment factors and denominators. Independent restriction, multiplication and addition produce exactly the authored seven-factor tensor, with 70,896 selected-pair products per branch and 51,552 nonzero signed pair rows. Its SHA256 is 44f864d0a4455e6e351dfb6a2a213b7c7e469f5646895bf80a4347e37885943f. The constructor, reduction, join-cap text and five-factor restart reproduce byte for byte. The latter's SHA256 is cb5080c1f7bc2a019dfc8624708559f54de392adba3dc0a9a41d79ec88f8ddf8.

The first author planner requires rejected_pair metadata, which the five-factor join-cap checkpoint lacks. Its refusal is preserved. An independent direct replay also refused: the minimum first join forecasts 14,947,200 products, above the 8-million cap, and necessary-support pruning did not lower that unsliced minimum. The independent geometry forecast shows an optional finer 128-branch split. The accepted route uses the complete one-axis G(1,0,2) partition. Both factors carrying that axis share exactly 16 supported labels. Census recovered 14,947,200 projected matches, eight labels contributing 622,800 each and eight 1,245,600 each. All 16 independently checked inverse lifts preserve exact signed coefficients, disjoint labels, and denominators. All 48 generic preparation, reduction and contraction commands reproduced byte for byte, with eight exact scalar completions and eight saved terminal triangles.

The eight 1,245,600-match branches independently close under necessary-support pruning and a width-aware sparse schedule. An earlier unpruned replay for label 17 refused at an 8,743,200-product join. The corrected independent path uses 10,308,068 products per branch, at most 7,992,720 per join, and 187,200 maximum retained output rows. The eight 622,800-match branches independently close at alternate triangle pivot 1. Each uses 8,664,832 probes and 8,491,552 Gaussian products. All 16 author pivot-0 shard intervals, projected traffic, raw sums and normalized terms match independent checks. The replays were on each distinct operand, including labels whose scalars coincide. All signed raw numerators use the positive factor denominator 40512224221827380280140849737629696 and normalization 1/(16*4^64) once.

Measured scratch timings

- generic sum of elapsed seconds 221.113734.
- pruned products [10308068] seconds min/max/sum 9.1811 10.2152 76.5633.
- alt-triangle products [8491552] seconds min/max/sum 4.685 5.141 38.876.

The checked constructor took 1.489 s, and its paired reduction and cap took 15.633 s. All 210 input hash entries and all portable manifest entries passed checksum readback.
