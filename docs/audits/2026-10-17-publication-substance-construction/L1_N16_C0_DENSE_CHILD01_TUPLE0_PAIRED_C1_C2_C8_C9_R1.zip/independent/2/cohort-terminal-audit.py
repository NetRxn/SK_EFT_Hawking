from ast import literal_eval
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

author=Path('/private/tmp/l1-cut2-frontier.yuHMTh')
basis=40512224221827380280140849737629696
scale=basis*16*4**64
axis=('G',1,0,2)
signature=r'^exact normalized real (\S+) imaginary (\S+)'
numerators=r'^(?:independently computed )?raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$'
def exact(text):
    result=re.search(signature,text,re.M)
    assert result is not None
    return tuple(map(Fraction,result.groups()))

def projection(scope,shared):
    positions=tuple(scope.index(x) for x in shared)
    return lambda row:tuple(row[i] for i in positions)

roster=literal_eval((author/'prepare.out').read_text().splitlines()[1].removeprefix('weighted roster '))
forecast={int(i):tuple(map(int,values)) for i,*values in
          (line.split() for line in (author/'triangle-forecast.tsv').read_text().splitlines())}
lines=(author/'author-case2.tsv').read_text().splitlines()
assert len(lines)==len(roster)+1==17
vals=[]
for j,(label,count) in enumerate(roster):
    n,k,size,real,imag,receipt=lines[j].split('\t')
    assert (int(n),int(k),int(size))==(j,label,count)
    current=author if label==17 else author/str(label)
    selected=pickle.loads((current/'selected.pkl').read_bytes())
    metadata=f"conditioning {selected['conditioning']} label partition {selected['label_partition']}"
    assert dict(selected['conditioning'])[axis]==label
    path=current/('join-cap-dense-label-cut2-selected-reduced.pkl' if label in forecast else
                  'label-cut2-selected-reduced-frontier.pkl')
    raw=path.read_bytes()
    digest=sha256(raw).hexdigest()
    network=pickle.loads(raw)
    assert network['conditioning']==selected['conditioning']
    assert network['label_partition']==selected['label_partition']
    factors=network['factors']
    assert prod(d for _,_,d in factors)==basis
    assert set(Counter(k for axes, _, _ in factors for k in axes).values())=={2}
    result=(author/receipt).read_text()
    if label in forecast:
        assert len(factors)==3
        replay=Path(f'label{label}-alt-triangle.out').read_text()
        assert digest in replay
        assert re.search(r'^independent pivot 1 ',replay,re.M)
        pivot,pivot_rows,_=factors[0]
        counts=[]
        for scope,rows,_ in factors[1:]:
            shared=tuple(sorted(set(pivot)&set(scope)))
            projected=Counter(map(projection(scope,shared),rows))
            p=projection(pivot,shared)
            counts.append([projected[p(row)] for row in sorted(pivot_rows)])
        weights=[min(values) for values in zip(*counts,strict=True)]
        pivot_count,total,parts,peak=forecast[label]
        assert len(weights)==pivot_count==102240
        assert sum(weights)==total==8564928 and parts==2
        raw_parts=[]
        trips=0
        all_probes=[]
        for k in range(parts):
            lo,hi=pivot_count*k//parts,pivot_count*(k+1)//parts
            required=sum(weights[lo:hi])
            receipt_file=current/f'slice-{label}-shard-{k}.out'
            log=receipt_file.read_text()
            assert f'left row interval {lo} {hi} of {pivot_count} shard {k} of {parts}' in log
            assert metadata in log
            t,p,g=map(int,re.search(r'^triangle closure (\d+) nonzero-support triples (\d+) bounded probes products (\d+) output rows 1$',log,re.M).groups())
            assert p==required and g==2*t
            a,b,d=map(int,re.search(numerators,log,re.M).groups())
            assert d==basis and exact(log)==(Fraction(a,scale),Fraction(b,scale))
            raw_parts.append((a,b))
            all_probes.append(required)
            trips+=t
            print('PASS author shard',label,k,'raw',a,b,'interval',(lo,hi),'independent probes',required)
        assert max(all_probes)==peak
        assert trips==int(re.search(r'^independent pivot 1 probes \d+ triples (\d+)',replay,re.M)[1])
        a,b=map(sum,zip(*raw_parts,strict=True))
        assert f'complete shards 2 left rows {pivot_count} raw {a} {b} factor denominator {basis}' in result
        assert tuple(map(int,re.search(numerators,replay,re.M).groups()))==(a,b,basis)
    else:
        assert len(factors)==5
        replay=Path(f'label{label}-pruned.out').read_text()
        assert metadata in replay
        a,b,d=map(int,re.search(numerators,replay,re.M).groups())
        assert d==basis
    val=exact(replay)
    assert val==exact(result)==tuple(map(Fraction,(real,imag)))==(Fraction(a,scale),Fraction(b,scale))
    vals.append(val)
    print('PASS exact label',label,'products',count,'terminal SHA256',digest,'raw',a,b,'normalized',*val)
total=tuple(map(sum,zip(*vals,strict=True)))
end,*target=lines[-1].split('\t')
assert end=='sum' and total==tuple(map(Fraction,target))
print('PASS full cut 2 sum',*total)
