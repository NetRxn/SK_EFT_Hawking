from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess
import sys
from time import perf_counter

pair=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
source=pair/'join-cap-dense-label-sum2-reduced.pkl'
author=Path((pair/'cut2-frontier.path').read_text().strip())
stems={int(n):int(status) for n,_,status,*_ in
       (line.split('\t') for line in (author/'cohort.tsv').read_text().splitlines())}
assert len(stems)==16 and list(stems.values()).count(0)==list(stems.values()).count(2)==8
def check_file(a,b):
    assert sha256(a.read_bytes()).digest()==sha256(b.read_bytes()).digest(),(a,b)

def check(label,status):
    expected=author if label==17 else author/str(label)
    here=Path(f'lineage-{label}').resolve()
    here.mkdir()
    (here/'checkpoint').mkdir()
    for name in ('reduce-label-frontier.py','contract-peer.py','peer_pair.py','checkpoint/quotient.py'):
        check_file(author/name,expected/name)
        shutil.copyfile(expected/name,here/name)
    prep='prepare.py' if label==17 else 'prepare-selected.py'
    shutil.copyfile(author/prep,here/prep)
    args=[str(source)]+([] if label==17 else [str(label)])
    commands=((prep,args,'prepare',0),
              ('reduce-label-frontier.py',['selected.pkl','cut2-selected'],'reduction',0),
              ('contract-peer.py',['cut2-selected'],'contraction',status))
    times=[]
    for script,args,stage,code in commands:
        out=here/(stage+'.out')
        start=perf_counter()
        with out.open('xb') as output:
            p=subprocess.run([sys.executable,'-B',script,*args],stdout=output,stderr=subprocess.STDOUT,
                             cwd=here,timeout=180)
        times.append((stage,code,perf_counter()-start))
        assert p.returncode==code,(label,stage,p.returncode)
        check_file(out,expected/out.name)
    outputs=['selected.pkl','label-cut2-selected-reduced-frontier.pkl']
    if status==2:
        outputs.append('join-cap-dense-label-cut2-selected-reduced.pkl')
    for name in outputs:
        check_file(here/name,expected/name)
    return label,times

with ThreadPoolExecutor(max_workers=2) as pool:
    for label,times in pool.map(lambda kv:check(*kv),stems.items()):
        for stage,code,elapsed in times:
            print(label,stage,code,f'{elapsed:.6f}',sep='\t',flush=True)
