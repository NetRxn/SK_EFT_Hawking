from hashlib import sha256
from pathlib import Path
import shutil

pair=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
author=Path((pair/'cut2-frontier.path').read_text().strip())
replay=Path.cwd()
raw_names=('combined-2.pkl','label-sum2-reduced-frontier.pkl','join-cap-dense-label-sum2-reduced.pkl')
source_names=('combine-2.out','reduce-2.out','contract-2.out','sum-branches-checked.py','sum-branches.py',
              'reduce-label-frontier.py','contract-reduced-label.py','checkpoint/quotient.py',
              'cut2-frontier.path','cut2-five-factor-geometry.out')
shared=set(raw_names+source_names)
paired=[pair/name for name in sorted(shared)]
paired += [pair.parent/f'row-cap-physical-slice-dense-label-tuple0-branch-{i}-reduced.pkl' for i in (0,1)]
paired.append(pair.parent/'tuple0-branch0-pilot/pilot.roster')
for family, base, paths in (
    ('paired',pair,paired),
    ('cohort',author,sorted(p for p in author.rglob('*') if p.is_file() and p.suffix in ('.pkl','.out','.tsv','.py'))),
    ('refusal',pair/'probe2-inner',sorted((pair/'probe2-inner').glob('slice-*-plan.out'))+[
        pair/'probe2-inner/primary.tsv',pair/'probe2-inner/run-primary.py',
        pair/'probe2-inner/exact-multicut.py']),
):
    with Path(f'{family}-operands.sha256').open('w') as out:
        for source in paths:
            h=sha256(source.read_bytes()).hexdigest()
            print(h,source,sep='  ',file=out)
            if source.suffix!='.pkl':
                dest=source.relative_to(base) if source.is_relative_to(base) else Path('original-roster.roster')
                target=replay/'author-receipts'/family/dest
                target.parent.mkdir(exist_ok=True,parents=True)
                shutil.copyfile(source,target)
