#!/usr/bin/env bash
set -euo pipefail
a=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe1-inner
for i in {0..20}; do
 python3 -u sparse-replay.py "$i" terminal "$a/label-slice-$i-reduced-frontier.pkl" "$a/slice-$i-contract.out" > "slice-$i-replay.out"
done
while read -r i left right; do
 input="row-cap-physical-slice-dense-label-rescue-$i-1-reduced.pkl"
 python3 -u four.py "$input" "$i" --pair "$left" "$right" > "slice-$i-four-replay.out"
done < alternate-pairs.tsv
python3 terminal-timing.py > replay-timing.tsv
python3 audit.py > audit.out
python3 verify-shard-coverage.py > shard-coverage.out
