# Independent review of paired outer coordinate 9

The independently verified signed contribution of outer coordinate `(18,(2,))` in group128 descendant `(0,1)`, tuple 0 is `11776062496625468983377/2596148429267413814265248164610048 + 0i`. The raw Gaussian subtotal is `(1000497708927116036698305369304990488197585445351704364878659584,0)` over factor denominator `40512224221827380280140849737629696`. The common positive external normalization `1/(16*4^64)` is applied once. This acceptance covers outer coordinate 9.

The named continuity revision matched publication checkpoint `3c2d5779d2cd749d9835ef549b8ff93197a06d5d`. The two disjoint binary-selector inputs use the accepted hashes and share six environment factors. The independent census recovers all 48 coordinates and 6,427,904 compatible products per original branch. A condition-first signed constructor indexed the opposite factor and reconstructed every one of the seven combined tables using 106,344 products per branch. Their sum has 77,328 retained pair rows. The original constructor, outer reduction and refusal reproduced byte for byte. The combined input SHA-256 is `2b4f135923610a4371ddcf0be42c2d10c3cb2dceb8c9d01ff792b56d6c88d8f3` and the retained cap SHA-256 is `e4c9f949ae8f4245c843f83acada47be5ad54fc2a2e6c3c15a40e4ca6c74a6b8`. Independent reconstruction took 2.15 s. Constructor, reduction and refusal readbacks took 1.641, 7.241 and 3.128 s wall respectively.

The inner census recovered 9 disjoint coordinates with 1,021,248 compatible products. Every exact inverse lift recovered the original conditioned rows, keys, axes, signed Gaussian coefficients and denominators. The 9 generic terminals were verified with independent sparse Gaussian contraction.  All terminals completed in the bounded generic route. Each signed raw Gaussian pair and normalized pair was independently checked. The signed ledger gives the route, raw value, projected work and observed work per slice.

The 43 generic inner commands across 17 stages reproduced each log and saved checkpoint byte, preserving all 8 refusals. Their summed wall duration was 204.367494 s under concurrent execution. The independent terminal replays used 40,718,896 products and 43.446174 summed wall seconds. The author terminal receipts record 18,300,769 products. Terminal work totals exclude generic work performed before a refusal. The signed ledger and timing tables preserve per-slice measurements.

Verify the portable receipts from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B tools/ledger-metrics.py 9 | cmp - signed-ledger.tsv
python3 -B tools/summarize.py | cmp - summary.out
```

The three operand inventories bind the original binary and text files on the author scratch path. Full recalculation of the binary lineage requires those pinned files. The portable manifest contains the selected receipts, hashes, timings, authority checks and review scripts.
