from csv import DictReader
from pathlib import Path

def read(path):
    return [line.split('\t') for line in Path(path).read_text().splitlines()]

stages=read('inner-lineage.tsv')
ledger=read('author-receipts/inner/author-case9.tsv')
count=len(read('inner-roster.tsv'))
assert len(ledger)==count+1
assert sorted({int(r[0]) for r in stages})==list(range(count))
print('generic terminal stages',len(stages))
all_times=[]
for index in range(count):
    actual=[row for row in stages if int(row[0])==index]
    expected=len(actual)
    assert 1<=expected<=3 and all(row[2]=='byte-identical' for row in actual)
    last=actual[-1]
    receipt=ledger[index][-1]
    sharded=receipt.endswith('-shard-sum.out')
    assert last[3].startswith('open ' if sharded else 'exact normalized real ')
    if sharded:
        assert expected in (2,3)
    else:
        assert receipt==f'{last[1]}-contract.out'
    timing=read(f'lineage-{index}/stage-timing.tsv')
    assert len(timing)==1+2*expected
    assert int(timing[0][2])==0 and all(int(row[2])==0 for row in timing[1::2])
    assert [int(row[2]) for row in timing[2::2]]==[2]*(expected-1)+[2 if sharded else 0]
    all_times.extend(timing)
assert len(all_times)==count+2*len(stages)
assert sum(int(row[2])==2 for row in all_times)==len(stages)-sum(not r[-1].endswith('-shard-sum.out') for r in ledger[:-1])
print('commands',len(all_times),'refusals',sum(int(row[2])==2 for row in all_times),
      'summed command wall seconds',round(sum(float(row[3]) for row in all_times),6))
with Path('signed-ledger.tsv').open() as file:
    terms=list(DictReader(file,delimiter='\t'))[:count]
assert len(terms)==count and [int(row['slice']) for row in terms]==list(range(count))
assert sum(int(row['matched_outer_products']) for row in terms)==int(Path('inner-products.txt').read_text())
print('terminal products independent',sum(int(row['review_products']) for row in terms),
      'author',sum(int(row['author_terminal_products']) for row in terms))
print('terminal summed command wall seconds',round(sum(float(row[-1]) for row in read('replay-timing.tsv')),6))
print('normalized total',*read('signed-ledger.tsv')[-1][6:8])
