#!/usr/bin/env bash
set -euo pipefail
p=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe9-inner
until test -f "$p/terminal-plan.tsv" && test -s "$p/wall-timing.tsv" &&
      test -s inner-roster.tsv && test "$(wc -l < "$p/primary.tsv")" -eq "$(wc -l < inner-roster.tsv)"; do sleep 5; done
python3 -B rescue-source-pins.py 9 > rescue-source-pins.out
python3 -B -u replay-all.py 9 $(cut -f1 inner-roster.tsv) > replay-timing.tsv

until test -s "$p/author-case9.tsv" && test "$(wc -l < "$p/author-case9.tsv")" -eq "$(( $(wc -l < inner-roster.tsv) + 1 ))"; do sleep 5; done
python3 -B freeze-inputs.py 9
for prefix in source paired inner; do
  shasum -a 256 -c "$prefix-operands.sha256" > "$prefix-operands-verify.out"
done
/usr/bin/time -p python3 -B audit.py 9 > audit.out 2> audit.time
python3 -B verify-shard-coverage.py 9 > shard-coverage.out
python3 -B ledger-metrics.py 9 > signed-ledger.tsv
