Restore the original tables and root/spatial tensors using the
L1_N16_C0_DIRECTED_SQUARE_PILOT_R1.zip archive. Refer to the previous
L1_N16_C0_DIRECTED_SQUARE_MIXED_OWNER_R1.zip for the independently
reviewed mixed-matrices.tsv and frozen author mixed-owner inputs.
Place this package's mixed-owner-a directory in the restored author
root, place links in independent/ to those inputs as specified in
independent/REVIEW.md, verify both manifests and run its replay commands.
The new residual removes precisely the 14 accepted A-core rows.
