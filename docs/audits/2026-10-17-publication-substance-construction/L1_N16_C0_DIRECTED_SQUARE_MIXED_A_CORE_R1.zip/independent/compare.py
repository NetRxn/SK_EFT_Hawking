import ast
from collections import Counter
from fractions import Fraction as F
import json
from pathlib import Path
import re

def rows(path):
    return [tuple(map(int,l.split())) for l in Path(path).read_text().splitlines()]
def split(path):
    return [l.split() for l in Path(path).read_text().splitlines()]
def gaussian(s):
    literal=re.sub(r"Fraction\((-?\d+), (\d+)\)",r"'\1/\2'",s)
    return [tuple(map(F,pair)) for pair in ast.literal_eval(literal)]

before=rows('prior-owner-residual.tsv')
accepted={tuple(map(int,r[:3])) for r in split('prior-b-exact.tsv')}
assert len(accepted)==28 and sum(w for _,_,w in accepted)==2544
residual=rows('accepted-b-core-residual.tsv')
assert [r for r in before if r not in accepted]==residual
assert len(residual)==10382 and sum(r[2] for r in residual)==897147
p=Path('frozen/mixed-owner-a')
roster=json.loads((p/'directed-roster.json').read_text())
initial=split(p/'author-results.tsv')
combined=split(p/'author-combined.tsv')
refused_indices={7,12}
assert len(initial)==len(roster)==len(combined)==14
for n,(old,new) in enumerate(zip(initial,combined)):
    if n in refused_indices:
        assert old[3]=='REFUSED' and new[3]=='TILED'
    else:
        assert old==new and old[3]=='EXACT'
author_channels={}
author_values={}
author_limits=[]
for i,c in enumerate(roster):
    a,b=c['ids']
    key=(a,b,c['weight'])
    assert key==tuple(map(int,initial[i][:3]))==tuple(map(int,combined[i][:3]))
    assert key in residual and key not in accepted
    name=(f'case-{i:02}.out' if i not in refused_indices else f'tiled-{i}.out')
    out=(p/name).read_text()
    tail=out.splitlines()[-1].split()
    assert tuple(map(int,(tail[2],tail[3],tail[5])))==key
    assert F(tail[-1])==F(combined[i][-1])
    if i in refused_indices:
        refused=(p/f'case-{i:02}.out').read_text()
        assert refused.splitlines()[-1]==' '.join(initial[i][4:])
    channel=[]
    for q,r,v in re.findall(r'channel result \d (\(.*?\)) (\(.*?\)) scaled contribution (\S+)',out):
        remote,own=gaussian(f"[{q}, {r}]")
        channel.append((remote,own,F(v)))
    assert len(channel)==4
    author_channels[key]=channel
    author_values[key]=F(tail[-1])
    author_limits.append(tuple(max(map(int,re.findall(pattern,out)),default=0) for pattern in (
         r' site \d work (\d+)',r'populated rows (\d+)',r' matched (\d+) rows',
         r'triangle preflight (\d+)',r'resident input rows (\d+)')))

def compare(logs):
    cases=[];exact={};params=[];partitions=[];refusals=[]
    for path in logs:
        for l in Path(path).read_text().splitlines():
            fields=l.split()
            if fields[0]=='case':
                a,b,w,s,overlap=map(int,fields[1:6])
                cycl,forced=re.fullmatch(r'(\[.*\]) (\(.*\))',' '.join(fields[6:])).groups()
                cases.append(dict(ids=[a,b],weight=w,root_layer=s,cycle=ast.literal_eval(cycl),
                    forced_scalar_powers=list(ast.literal_eval(forced)),mixed_edges=overlap))
                key=(a,b,w)
                channels=[]
            elif fields[0] in ('0','1','2','3'):
                r,t=re.fullmatch(r'\d (\[.*\]) (\S+)',l).groups()
                x,y=gaussian(r)
                channels.append((x,y,F(t)))
            elif fields[0]=='total':
                assert key not in exact
                assert channels==author_channels[key],(key,channels,author_channels[key])
                exact[key]=F(fields[2])
                assert exact[key]==sum(t[2] for t in channels)==author_values[key]
            elif fields[0]=='layer':
                params.append(tuple(int(fields[i]) for i in (6,8,11,14)))
            elif fields[0]=='partition':
                k,x,y,n=map(int,re.match(r'partition (\d) \((\d), (\d)\) (\d+)',l).groups())
                assert (x,y)==tuple(cases[-1]['cycle'][i] for i in (1,3))
                assert n==(1,3,3,4)[k]**2
                partitions.append((key,k,n))
            elif l.startswith('guarded direct refusal'):
                refusals.append((key,l))
    assert cases==roster and len(exact)==14 and sum(w for _,_,w in exact)==1152
    print('maximum factor/work/site/initial',*[max(x) for x in zip(*params)])
    print('partitions',partitions)
    print('independent direct resource refusals',refusals)
    expected={(tuple(c['ids'])+(c['weight'],),k) for i,c in enumerate(roster) if i in refused_indices for k in (1,2,3)}
    assert expected<={(key,k) for key,k,_ in partitions}
    return exact
exact=compare(['cases-0.out','cases-7.out','cases-12.out'])
print('frozen author limits (site / factor / join / triangle / triangle input)',*[max(x) for x in zip(*author_limits)])
print('sign census',Counter((v>0)-(v<0) for v in exact.values()))
print('weights',Counter(w for _,_,w in exact))
print('mixed edges per representative',Counter(c['mixed_edges'] for c in roster))
subtotal=sum(w*v for (_,_,w),v in exact.items())
assert subtotal==sum(int(w)*F(v) for a,b,w,state,v in combined)
left=[r for r in residual if r not in exact]
assert len(left)==10368 and sum(w for _,_,w in left)==895995
probe=Path('refused-probe.out').read_text()
assert probe.count("guarded direct refusal 1 Refusal(('join products', 7409664))")==2
assert ('\n'.join(Path('census.out').read_text().splitlines()[1:])+'\n')==Path('prior-a-census.tsv').read_text()
print('new subtotal' ,subtotal,'remaining',len(left),sum(w for _,_,w in left))
Path('reviewed-exact.tsv').write_text(''.join('\t'.join(map(str,(*r,v)))+'\n' for r,v in exact.items()))
