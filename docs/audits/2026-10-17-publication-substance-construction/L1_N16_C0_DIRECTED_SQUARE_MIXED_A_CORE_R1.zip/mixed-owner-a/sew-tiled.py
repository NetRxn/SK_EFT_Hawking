import ast
import json
from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations, product
from math import factorial, prod
from pathlib import Path
import sys

# Reuse the frozen contraction and exact generator ordering without loading
# the retired scratch census paths at import time.
def frozen(path, names):
    definitions = ast.parse(Path("AUTHOR",path).read_text()).body
    keep = [node for node in definitions if isinstance(node, ast.FunctionDef) and node.name in names]
    exec(compile(ast.Module(body=keep,type_ignores=[]),path,"exec"),globals())

MAX_ROWS,MAX_PRODUCTS,MAX_BITS=150_000,2_000_000,384
frozen("coframe.py", {"sign"})
frozen("odd_network.py", {"zadd","triangle","contraction"})
cases=json.loads(Path("mixed-owner-a/directed-roster.json").read_text())
case=cases[int(sys.argv[1])]
assert case["root_layer"]==0 and len(set(case["cycle"]))==4
cycle=tuple(case["cycle"])
directed={tuple(sorted((u,v))):(u,v) for u,v in zip(cycle,cycle[1:]+cycle[:1])}
roster=[(a,b,c) for a in range(5) for b in range(5-a) for c in range(5-a-b)]
def decode(code): return [roster[code>>(6*x)&63] for x in range(8)]

S=defaultdict(list)
for line in Path("AUTHOR/edge.tsv").open():
    d,w,u,v,r,i=map(int,line.split())
    S[d].append((w,u,v,r,i))
M=[]
for line in Path("AUTHOR/mixed.tsv").open():
    M.append(tuple(map(int,line.split())))
T=defaultdict(list)
for line in Path("square-root-tensor.tsv").open():
    a,b,c,d,k,i,j,r,s=map(int,line.split())
    T[k].append(((a,b),(c,d),i,j,r,s))
scalar=[(u,v,r) for u,v,i,j,r,s in T[0] if (i,j,s)==(0,0,0)]
expected=[((a,a),(b,b),1) for a,b in product(range(4),repeat=2) if a!=b]
expected += [((a,b),(a,b),-2) for a,b in combinations(range(4),2)]
assert sorted(scalar)==sorted((u,v,2*r) for u,v,r in expected)
scalar=expected
def code(word):
    out=0
    for i in word:out=4*out+i
    return out

def calculate(m,side,k,reverse=False,mutation=None, fixed=None):
    fixed={} if fixed is None else fixed
    load=[[sum(row)-v for v in row] for row in m]
    fs=[]
    incidence=[[] for _ in m]
    scale=1
    for u in range(8):
        for axis in range(3):
            v=u^(1<<axis)
            if u>v:continue
            a,b=load[u][axis],load[v][axis]
            d=a+b
            if not d:continue
            assert d in (2,4) and (min(a,b)==0 or a==b==2)
            owner=int(b>0)
            e=(u,v)
            special=e in directed
            table={}
            if special:
                root,end=directed[e]
                anchor=int(root==v)
                if a==b==2:
                    for line in Path("mixed-owner/matrices.tsv").open():
                        h,channel,w,z,mask,i,j,r,s=map(int,line.split())
                        if (h,channel)!=(anchor,k):continue
                        p,q=(j,i) if root==u else (i,j)
                        if u in fixed and fixed[u]!=p or v in fixed and fixed[v]!=q:continue
                        if side==1:s=-s
                        key=((w,mask&255,p),(z,mask>>8,q))
                        assert key not in table
                        table[key]=(r,s)
                else:
                    for line in Path("square-spatial-matrices.tsv").open():
                        o,h,degree,channel,w,mask,i,j,r,s=map(int,line.split())
                        if (o,h,degree,channel)!=(owner,anchor,d,k):continue
                        # In both traces, the original matrix column is at the
                        # root and the row at the destination. The own branch
                        # uses its dagger, supplying complex conjugation.
                        p,q=(j,i) if root==u else (i,j)
                        if u in fixed and fixed[u]!=p or v in fixed and fixed[v]!=q:continue
                        if side==1:s=-s
                        key=((w if owner==0 else 0,mask&255,p),(w if owner==1 else 0,mask>>8,q))
                        assert key not in table
                        table[key]=(r,s)
                scale*=192*4**d
            elif a==b==2:
                for w,z,i,j,r,s in M:
                    table[((w,i,0),(z,j,0))]=(r,s)
                scale*=12288
            else:
                for w,i,j,r,s in S[d]:
                    mask=(i,j) if not owner else (j,i)
                    table[((w if not owner else 0,mask[0],0),(w if owner else 0,mask[1],0))]=(r,s)
                scale*=64 if d==2 else 12288
            assert table
            ids=(2*len(fs),2*len(fs)+1)
            if sum(len(f[1]) for f in fs)+len(table)>MAX_ROWS:
                raise RuntimeError(f"initial edge resident cap {side} {k} {u} {v}")
            fs.append((ids,table,f"e{u}{v}"))
            for index,x in enumerate(e):
                allowed=defaultdict(set)
                for key in table:
                    w,mask,p=key[index]
                    allowed[w,p].add(mask)
                incidence[x].append((ids[index],axis,d,e,allowed))
    width=(1,3,3,4)[k]
    for x,edges in enumerate(incidence):
        assert sum(e[2] for e in edges)==8
        special=[e for _,_,_,e,_ in edges if e in directed]
        rooted=next((e for e in special if directed[e][0]==x),None)
        assert len(special) in (0,2)
        edge_axis=lambda e:(e[0]^e[1]).bit_length()-1
        root_axis=edge_axis(rooted) if rooted else None
        labels={(((),(),()),0,0):(1,0)}
        for axis,n in enumerate(m[x]):
            if not n:continue
            j,l=[i for i in range(3) if i!=axis]
            assert n%2==0
            root=side==1 and axis==root_axis
            assert not root or n==2
            terms=T[k] if root else [(u,v,0,0,r,0) for u,v,r in scalar]
            for _ in range(n//2):
                nxt={}
                for (word,p,q),(a,b) in labels.items():
                    for u,v,i,h,c,d in terms:
                        out=list(word)
                        out[j]=tuple(sorted(out[j]+u));out[l]=tuple(sorted(out[l]+v))
                        zadd(nxt,(tuple(out),i if root else p,h if root else q), a*c-b*d,a*d+b*c)
                labels=nxt
        table={}
        work=0
        for (word,alpha,beta),(r,s) in labels.items():
            for remote_index in range(width if special and side==0 else 1):
                keys=[]
                available=[]
                for _,axis,_,e,allowed in edges:
                    p=0
                    if e in directed:
                        if side==0:p=remote_index
                        else:p=alpha if e==rooted else beta
                    w=code(word[axis])
                    keys.append((w,p))
                    available.append(allowed[w,p])
                if any(not group for group in available):continue
                order=sorted(range(len(edges)),key=lambda i:len(available[i]))
                front,last=order[:-1],order[-1]
                work+=prod(len(available[i]) for i in front)
                if work>MAX_PRODUCTS:raise RuntimeError(f"site trial cap {side} {k} {x}")
                for chosen in product(*(available[i] for i in front)):
                    mask=0
                    for a in chosen:
                        if a&mask:break
                        mask|=a
                    else:
                        final=255^mask
                        if final not in available[last]:continue
                        masks=[0]*len(edges)
                        for i,a in zip(front,chosen):masks[i]=a
                        masks[last]=final
                        phase,prev=1,0
                        for a in masks:
                            phase*=sign(prev,a);prev|=a
                        if x==mutation:phase=1
                        key=tuple((w,a,p) for (w,p),a in zip(keys,masks))
                        zadd(table,key,phase*r,phase*s)
        fs.append((tuple(e[0] for e in edges),table,f"s{x}"))
        if sum(len(f[1]) for f in fs)>MAX_ROWS:raise RuntimeError("layer resident cap")
        print("layer",side,"channel",k,"site",x,"work",work,"rows",len(table))
    r,i=contraction(fs,reverse)
    return F(r,scale),F(i,scale)

codes=tuple(case["ids"])
m=list(map(decode,codes[::-1]))
root_axes={(x,edge_axis) for x,y in directed.values() for edge_axis in [(x^y).bit_length()-1]}
assert all(m[1][x][axis]==2 for x,axis in root_axes)
factor=F(prod({0:1,2:2,4:10}[n] for side,rows in enumerate(m) for x,row in enumerate(rows)
              for axis,n in enumerate(row) if side==0 or (x,axis) not in root_axes),
         prod(factorial(n) for rows in m for row in rows for n in row))
total=F(0)
for k,width in enumerate((1,3,3,4)):
    if width==1:
        remote=calculate(m[0],0,k,reverse='reverse' in sys.argv)
    else:
        tiles=[calculate(m[0],0,k,reverse='reverse' in sys.argv,
                         fixed={cycle[0]:a,cycle[2]:b})
               for a,b in product(range(width),repeat=2)]
        remote=tuple(sum(z[i] for z in tiles) for i in range(2))
        print("partition",k,"vertices",cycle[0],cycle[2],"tiles",len(tiles),
              "total",remote,flush=True)
    own=calculate(m[1],1,k,reverse='reverse' in sys.argv,
                  mutation=0 if 'omit-site-sign' in sys.argv else None)
    raw=(remote[0]*own[0]-remote[1]*own[1],remote[0]*own[1]+remote[1]*own[0])
    assert raw[1]==0
    contribution=factor*raw[0]/width**4
    print("channel result",k,remote,own,"scaled contribution",contribution,flush=True)
    total+=contribution
print("square representative",*codes,"weight",case["weight"],"value",total)
