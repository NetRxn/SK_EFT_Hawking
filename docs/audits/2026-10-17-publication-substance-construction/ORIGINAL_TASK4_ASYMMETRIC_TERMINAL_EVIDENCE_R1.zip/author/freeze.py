"""Make an auditable minimal ledger from the already reviewed full receipts."""
from hashlib import sha256
import json
from pathlib import Path

source = Path("/tmp/publication-l1-pairing-r1.hy5gTm")
sources = {
    "chirality.jsonl": "6934ae7418c5885cb7b2579577299f5cb855960e643992873a903523c89e4b03",
    "double-chirality.jsonl": "e8c8489bce81a27526686e57d77750c15fb7a491e0cacf0c69090dd9b3c6cac0",
}
records = []
for name, digest in sources.items():
    data = (source / name).read_bytes()
    assert sha256(data).hexdigest() == digest
    for row in map(json.loads, data.splitlines()):
        if "candidate" in row:
            records.append({k: row[k] for k in (
                "candidate", "direction", "chosen_branch", "path",
                "residual_mask", "residual_value", "local_path_count",
            )})
assert [(r["candidate"]["slot"], r["direction"]) for r in records] == [([0],0),([0,1],0),([0,1],1)]
with Path(__file__).with_name("targets.jsonl").open("x") as out:
    for record in records:
        print(json.dumps(record, separators=(",", ":")), file=out)
