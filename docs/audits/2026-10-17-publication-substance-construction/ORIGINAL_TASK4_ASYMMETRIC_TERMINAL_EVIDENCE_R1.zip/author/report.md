# Original two-center asymmetric candidate

Author source pin 9e9ea25ad040c1cbf71dea9a3634bd36a3b9e6f9. Scratch source and
bounded controls are ready for independent admission review. The three
complete original coefficients and exclusive original output remain unrun.

## Exact inputs and retained contracts

`freeze.py` extracts exactly three candidates, their 13 ordered source
operands, label tuples, slots and directions, and fixed-outer local
expectations. It authenticates the two independently accepted full
preregistration receipts before parsing. The derived compact ledger is
7,229 bytes with SHA-256
`0e1a60438c5734144d31bcf9ebd1215ca7d389d23763e2f38fcc7c038f7553ac`.
The execution wrapper enforces both and checks each target's independent
slot, direction, exterior mask, and fixed-outer total and path count.
It recombines the full exact key from the operands, verifies exterior
disjointness and each operand's exact value in its labelled source
factor, and preserves the literal witness's repeated axis-zero quaternion
coordinate. Direction selects only the seed contact component. The two
mixed production/oracle requests both retain the original combined d0+d1
observable.

The wrapper imports R2 by exact digest. Production, original raw-oriented
oracle, 21 baseline identities, signed output records, and selected-branch
evaluation reuse R2 unchanged. The original result check compares the
exact coefficient for every outer group in either table, including an
absent group as zero, and checks that production's selected branch
matches its separately evaluated witness and path count. It retains the
requirement for at least one nonzero full total among the three requests.
A zero-complete outcome is a refusal, with the exact result and budget
summary still present for audit. The earlier three-zero original run
and predecessor prefix are independent immutable evidence in
`expected_inputs.sha256`.

The original logical limits remain 2,048 cumulative signed records
including the 696 accepted prefix, 8,192 local and later-path records
each, 16,384 oracle scratch records, and 20 million charged operations.
The input is bounded by exact byte count and decoded one row at a time.
A conservative reservation accounts for simultaneous raw JSON collections,
decoded symbols, support keys and transient hand check sets. It is
carried into local, witness, production and oracle checks and the
conversion phase. Each receipt is deleted before parsing the next target.
These are logical bounds and do not measure RSS or interpreter bytes.

## Bounded evidence

| Request | Fixed-outer ordered local sum | Local paths | Selected labelled witness | Witness paths |
| --- | ---: | ---: | ---: | ---: |
| Literal direction 0 | i/16 | 4 | −i/8192 | 2 |
| Mixed direction 0 | −1/16 | 4 | −1/8192 | 2 |
| Mixed direction 1 | 1/8 | 8 | −1/16384 | 1 |

The bounded actual run checked all 18 R9 and three R10 identities,
all 39 exact labelled source operands, the three fixed-outer sums,
and the three separately streamed selected-branch witnesses. It used
1,021,064 work charges. Each request carried 691 reserved records and
witness/local peaks were 716, 714 and 716. The cumulative prefix remained
696. Bounded mode did not call the complete candidate evaluator.

`synthetic.py` exercised the candidate wrapper on the exact previously
admitted small fixture. It matched the direct canonical complete sum
−1296 and the raw oracle group. It replayed the R2 adverse fixture
exactly, admitted absent-as-zero in both directions, rejected three
distinct nonzero signed-group mismatches and refused a too-small cap
before preregistration decode. Optimized Python execution refused
before inputs or original output. The first and final bounded runs
differ only in receipt field names to preserve R2's `target`, `branch`
and `reserved_path_records` output fields.

## Prospective ROOT-only original run

After independent source/cap admission, ROOT should verify source
continuity at the recorded primary pin and both checksum manifests
from this scratch directory. Use the exact primary Python environment
with assertions enabled and the primary source on PYTHONPATH. The single
proposed invocation, from the primary checkout, is:

```sh
env -u PYTHONOPTIMIZE PYTHONPATH=. .venv/bin/python -B "$candidate_directory/candidate.py" --root-admitted-original
```

Set `candidate_directory` to the actual frozen directory carrying this
report. The script exclusively creates `original.jsonl` there.
ROOT should freeze interpreter, command, start/stop, stdout/stderr and
exit evidence alongside that JSONL. No action is admitted by this
author report. Full two-center coefficients, a nonzero complete target,
broader allocation coverage, full Z, physical normalization and
publication acceptance remain separate.
