"""Original N16 two-center candidate using the independently reviewed target ledger."""
from fractions import Fraction
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from io import BytesIO
from pathlib import Path
import json
import re
import sys

HERE = Path(__file__).resolve().parent
PARENT = Path("/tmp/publication-task4-multicenter-s2s2-r2.py")
PARENT_DIGEST = "3e467a34ba1e2c774b3c2e1812c9fa34dd51ad94566602f7d3480f852d1e6ec5"
TARGET_DIGEST = "0e1a60438c5734144d31bcf9ebd1215ca7d389d23763e2f38fcc7c038f7553ac"
TARGET_BYTES = 7229
EXPECTED = (
    (0x25805500000001202C4066, (0,), 0, (0, 1, 1, 16), 4),
    (0x200000000E01E60002008000900099, (0, 1), 0, (-1, 16, 0, 1), 4),
    (0x1000D10DC0000004001B00025, (0, 1), 1, (1, 8, 0, 1), 8),
)

if not __debug__:
    raise SystemExit("Assertions must be enabled for bounded or admitted execution")
if __name__ == "__main__" and sys.argv[1:] not in (
    ["--bounded-controls"], ["--root-admitted-original"],
):
    raise SystemExit("Use --bounded-controls or a separately authorized --root-admitted-original")

assert sha256(PARENT.read_bytes()).hexdigest() == PARENT_DIGEST
spec = spec_from_file_location("accepted_two_center_r2", PARENT)
r2 = module_from_spec(spec)
sys.modules[spec.name] = r2
spec.loader.exec_module(r2)
base, r10, r5 = r2.base, r2.r10, r2.r5
Q, S, ZERO = r2.Q, r2.S, r2.ZERO

def target_lines(work):
    with (HERE / "targets.jsonl").open("rb") as inp:
        data = inp.read(TARGET_BYTES + 1)
    work.charge("asymmetric_ledger_input_bytes", len(data))
    assert len(data) == TARGET_BYTES and sha256(data).hexdigest() == TARGET_DIGEST
    return BytesIO(data)

def decode_operand(row):
    mask, symbols, coefficient = row
    match = re.fullmatch(
        r"QComplex\(storage=\((-?\d+), (\d+), (-?\d+), (\d+)\)\)", coefficient
    )
    assert match is not None
    rn, rd, im, idenom = map(int, match.groups())
    return int(mask, 16), tuple(S(f, idx) for f, idx in symbols), Q(
        Fraction(rn, rd), Fraction(im, idenom)
    )

def support(operands):
    mask = 0
    symbols = []
    for operand_mask, key, coefficient in operands:
        assert coefficient and not mask & operand_mask
        mask |= operand_mask
        symbols.extend(key)
    return mask, tuple(sorted(symbols))

def check_source_membership(operands, labels, inputs, z_inputs, d0, d1, direction, work):
    cx, hx, cw, ww, _, cy, hy = inputs
    cz, wz = z_inputs
    xkey, wkey, zkey, ykey = labels

    def outer(coframes, traces, label):
        _, _, mu, nu, a, b = label
        return coframes[mu, a], coframes[nu, b], traces[label]

    def center(coframes, choices, label):
        components, trace = choices[label]
        return (*(coframes[key] for key in components), trace)

    factors = (
        *outer(cx, hx, xkey), *center(cw, ww, wkey), *center(cz, wz, zkey),
        d0 if direction == 0 else d1, *outer(cy, hy, ykey),
    )
    for (mask, key, coefficient), factor in zip(operands, factors, strict=True):
        for (actual_mask, actual_key, actual_slot), value in r2.r4.rows(factor):
            work.charge("asymmetric_witness_source_rows")
            if (actual_mask, actual_key, actual_slot, value) == (mask, key, (), coefficient):
                break
        else:
            raise RuntimeError("preregistered operand absent from its original labelled factor")

def check_fixed_outer(residual, inputs, z_inputs, work, carry):
    _, _, cw, ww, _, _, _ = inputs
    cap = base.Admission(r10.LOCAL_CAP)
    left, left_count = r2.local_table(residual, cw, ww, work, cap, carry)
    right, right_count = r2.local_table(residual, *z_inputs, work, cap, carry + left_count)
    cap.check(carry + left_count + right_count)
    value, paths = ZERO, 0
    for _, _, coefficient, n in r2.complementary_join(
        left, right, residual[0], residual[1], work
    ):
        value += coefficient
        paths += n
    return value, paths, cap.peak

def checked_request(line, expected, inputs, z_inputs, d0, d1, w, z, work):
    # Budget the raw JSON collections before decode. Keep a conservative allowance
    # for simultaneous decoded source tuples, support keys, and hand check sets.
    cap = base.Admission(r10.LOCAL_CAP)
    carry = 3 * (line.count(b"[") + line.count(b"{")) + 64
    cap.check(carry)
    work.charge("asymmetric_request_decode", len(line))
    row = json.loads(line)
    target = r2.r6.decoded(row["candidate"])
    direction = row["direction"]
    assert (target[0], target[2], direction) == expected[:3]
    assert target[0].bit_count() == 18 and target[1].count(r2.G2) == 4
    labels = tuple(map(tuple, row["chosen_branch"]))
    operands = tuple(map(decode_operand, row["path"]))
    assert len(operands) == 13 and support(operands) == target[:2]
    check_source_membership(operands, labels, inputs, z_inputs, d0, d1, direction, work)
    shared = set(s for _, key, _ in operands[3:6] for s in key) & {
        s for _, key, _ in operands[6:9] for s in key
    }
    repeated = tuple(sorted(s for s in shared if s.family == "q"
                            and s.index[0] in (w, z) and s.index[1] == 0))
    assert target[2] != r2.SLOTS[0] or repeated
    local_mask, local_key = support(operands[3:9])
    assert local_mask == int(row["residual_mask"], 16)
    local, local_paths, local_peak = check_fixed_outer(
        (local_mask, local_key, target[2]), inputs, z_inputs, work, carry
    )
    assert local.storage == tuple(row["residual_value"]) == expected[3]
    assert local_paths == row["local_path_count"] == expected[4]
    value, paths, witness_peak = r2.selected_witness(
        target, inputs, z_inputs, labels, work, carry
    )
    assert value and paths
    # The decoded operands and sets go out of scope before production. Keep
    # the conservative reservation for the retained ledger row and target.
    row.update(
        fixed_outer_local_value=str(local), fixed_outer_local_paths=local_paths,
        repeated=r5.fingerprint((0, repeated, ()))["symbols"],
        witness=str(value), paths=paths, reserved_records=carry,
        witness_peak=max(cap.peak, local_peak, witness_peak),
    )
    return target, labels, value, paths, row

def compare_groups(production, oracle, work):
    total = ZERO
    for key, (coefficient, _) in production.items():
        work.charge("multicenter_reference_comparisons")
        assert coefficient == oracle.get(key, (ZERO, 0))[0]
        total += coefficient
    for key, (coefficient, _) in oracle.items():
        work.charge("multicenter_reference_comparisons")
        assert coefficient == production.get(key, (ZERO, 0))[0]
    return total

def evaluate(target, labels, value, paths, receipt, inputs, z_inputs, raws, work, capacity):
    carry = receipt["reserved_records"]
    result, peak, later, seeded, seeded_paths = r2.production(
        target, inputs, z_inputs, work, capacity, selected=labels, carry=carry
    )
    assert (seeded, seeded_paths) == (value, paths)
    ref, oracle_peak = r2.oracle(
        target, inputs, z_inputs, raws, work, capacity, carry + len(result.table)
    )
    total = compare_groups(result.table, ref.table, work)
    del ref
    conversion = carry + 3 * len(result.table)
    base.Admission(r10.LOCAL_CAP).check(conversion)
    work.charge("multicenter_receipt_rows", len(result.table))
    receipt.update(
        total=str(total), local_peak=max(peak, oracle_peak, receipt["witness_peak"], conversion),
        later_paths=later, output_records=len(result.table),
        table=[(key, str(v), p) for key, (v, p) in sorted(result.table.items())],
        work=work.used,
    )
    return bool(total)

def run(*, original, out):
    work = r5.Work(cap=r10.WORK_CAP, oracle_record_cap=r10.PAIR_CAP)
    _, (_, _, w, z), inputs, z_inputs, raws, d0, d1 = r2.setup(work)
    used = r2.output_prefix()
    identities = r2.identity_controls(inputs, z_inputs, work)
    print(json.dumps(dict(identity_controls=identities, work=work.used)), file=out, flush=True)
    nonzero = False
    for line, expected in zip(target_lines(work), EXPECTED, strict=True):
        target, labels, value, paths, receipt = checked_request(
            line, expected, inputs, z_inputs, d0, d1, w, z, work
        )
        if original:
            nonzero |= evaluate(
                target, labels, value, paths, receipt, inputs, z_inputs, raws, work,
                r10.OUTPUT_CAP - used,
            )
            used += receipt["output_records"]
        print(json.dumps(receipt), file=out, flush=True)
        del target, labels, value, paths, receipt
    print(json.dumps(dict(
        mode="original" if original else "bounded_controls",
        work=dict(work.counts), work_total=work.used,
        oracle_peak=work.oracle_max_prospective_records,
        prefix_output_records=r2.PREFIX, cumulative_output_records=used,
        any_complete_nonzero=nonzero if original else None,
    )), file=out, flush=True)
    if original and not nonzero:
        raise RuntimeError("all selected complete signed totals are zero")

if __name__ == "__main__":
    if sys.argv[1:] == ["--bounded-controls"]:
        run(original=False, out=sys.stdout)
    else:
        with (HERE / "original.jsonl").open("x") as stream:
            run(original=True, out=stream)
