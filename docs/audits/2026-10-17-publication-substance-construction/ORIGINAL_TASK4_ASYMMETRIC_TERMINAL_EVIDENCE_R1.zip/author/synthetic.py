"""Exercise the new wrapper on the established exact small fixture only."""
from contextlib import redirect_stdout
from io import StringIO
import json
import runpy

import candidate as m

legacy = StringIO()
with redirect_stdout(legacy):
    fixture = runpy.run_path("/tmp/publication-task4-multicenter-s2s2-r2.adverse.py")
from pathlib import Path
assert json.loads(legacy.getvalue()) == json.loads(
    Path("/tmp/publication-task4-multicenter-s2s2-r2.adverse.json").read_text()
)

work = m.r5.Work(cap=200_000, oracle_record_cap=m.r10.PAIR_CAP)
receipt = {"reserved_path_records": 73, "witness_peak": 73}
assert m.evaluate(
    fixture["target"], fixture["labels"], fixture["value"], 1, receipt,
    fixture["inputs"], fixture["z_inputs"], (fixture["rw"], fixture["rz"]), work, 20
)
assert receipt["total"] == str(fixture["value"])
assert receipt["output_records"] == receipt["later_paths"] == 1

assert m.compare_groups(
    {"present_zero": (m.ZERO, 1)}, {"only_oracle_zero": (m.ZERO, 0)}, work
) == m.ZERO

for production, reference in (
    ({"only_production": (m.Q(1), 1)}, {}),
    ({}, {"only_reference": (m.Q(1), 1)}),
    ({"shared": (m.Q(1), 1)}, {"shared": (m.Q(2), 1)}),
):
    try:
        m.compare_groups(production, reference, work)
    except AssertionError:
        pass
    else:
        raise AssertionError("missing nonzero signed-group mismatch refusal")

old = m.r10.LOCAL_CAP
try:
    m.r10.LOCAL_CAP = 3
    try:
        m.checked_request(b"{}", None, None, None, None, None, None, None, work)
    except RuntimeError as exc:
        assert str(exc).startswith("quartic local cap: prospective 67, cap 3")
        predecode = str(exc)
    else:
        raise AssertionError("missing preregistration decode refusal")
finally:
    m.r10.LOCAL_CAP = old
assert not m.HERE.joinpath("original.jsonl").exists()
print(json.dumps({
    "fixture_total": receipt["total"], "fixture_groups": receipt["table"],
    "fixture_local_peak": receipt["local_peak"],
    "legacy_adverse": "exact",
    "absent_zero_each_direction": True,
    "nonzero_mismatches_refused": 3,
    "predecode_refusal": predecode,
    "bounded_work": work.used,
}))
