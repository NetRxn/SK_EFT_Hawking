import ast
from collections import Counter
from datetime import datetime
from fractions import Fraction
from pathlib import Path
import json

d=Path('/tmp/publication-l1-asymmetric-candidate-r1.sL0Nfh')
def load(name):
    return [json.loads(x) for x in (d/name).read_text().splitlines()]
def freeze(x):
    return tuple(map(freeze,x)) if isinstance(x,list) else x
def exact(seq):
    return Fraction(*seq[:2]),Fraction(*seq[2:])
def coefficient(expr):
    a=ast.parse(expr,mode='eval').body
    assert isinstance(a,ast.Call) and a.func.id=='QComplex' and not a.args
    assert len(a.keywords)==1 and a.keywords[0].arg=='storage'
    return exact(ast.literal_eval(a.keywords[0].value))
def combine(lineage):
    mask=0
    syms=Counter()
    for m,k,v in lineage:
        bits=int(m,16)
        assert not mask&bits and coefficient(v)!=(0,0)
        mask|=bits
        syms.update(map(freeze,k))
    return mask,syms
def flip(lab):
    return lab[:-2]+(lab[-2]^1,lab[-1]^1)

rows=load('original.jsonl')
controls=load('controls.jsonl')
seeds=load('targets.jsonl')
assert len(rows)==len(controls)==5 and len(seeds)==3
assert rows[0]==controls[0]=={'identity_controls':{'R9':18,'R10':3},'work':984816}
assert (d/'original.exit').read_text().strip()=='0'
assert all(not (d/f'original.{s}').read_bytes() for s in ('stdout','stderr'))
version,flags=(d/'original.interpreter').read_text().splitlines()
assert version.startswith('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python 3.14.8 ')
assert flags=='__debug__ True optimize 0'
start,stop=(datetime.fromisoformat((d/f'original.{e}').read_text().strip()) for e in ('start','stop'))
assert (stop-start).total_seconds()==94

results=[]
for index,(row,seed,control) in enumerate(zip(rows[1:4],seeds,controls[1:4],strict=True)):
    assert {k:row[k] for k in control}==control
    assert row['target']==seed['candidate'] and row['branch']==seed['chosen_branch']
    assert all(row[k]==seed[k] for k in ('direction','path','residual_mask','residual_value','local_path_count'))
    mask,key=combine(row['path'])
    assert mask==int(row['target']['mask_hex'],16) and mask.bit_count()==18
    assert key==Counter(map(freeze,row['target']['symbols']))
    assert key[('g2',())]==4 and len(row['path'])==13
    residual,_=combine(row['path'][3:9])
    assert residual==int(row['residual_mask'],16) and residual.bit_count()==8
    assert coefficient(row['fixed_outer_local_value'])==exact(row['residual_value'])
    assert row['fixed_outer_local_paths']==row['local_path_count']
    groups={}
    for group,c,count in row['table']:
        x,empty,y=freeze(group)
        assert empty==() and len(x)==len(y)==6 and (x,y) not in groups
        assert type(count) is int and count>0
        groups[x,y]=(coefficient(c),count)
    total=tuple(sum((c[i] for c,_ in groups.values()),Fraction()) for i in (0,1))
    assert total==coefficient(row['total'])
    assert len(groups)==row['output_records']
    a,b,c,e=freeze(row['branch'])
    outer,outer_n=groups[a,e]
    counts=Counter(co for co,_ in groups.values())
    pattern=[[(Fraction(0),Fraction(-1,2048)),(Fraction(0),Fraction(0))],
             [(Fraction(1,2048),0),(Fraction(-1,2048),0),(0,0)],
             [(Fraction(3,4096),0),(Fraction(-3,4096),0)]][index]
    mult=[(6,6),(2,2,4),(2,2)][index]
    assert counts==Counter(dict(zip(pattern,mult,strict=True)))
    if index:
        for (x,y),(v,count) in groups.items():
            if v!=(0,0):
                assert groups[flip(x),y]==((-v[0],-v[1]),count)
                if index==2:
                    assert groups[x,flip(y)]==((-v[0],-v[1]),count)
    assert row['reserved_path_records']==691
    assert max(row['witness_peak'],691+3*len(groups))<=row['local_peak']<=8192
    assert 0<row['later_paths']<=8192
    results.append(dict(mask=row['target']['mask_hex'],slot=row['target']['slot'],direction=row['direction'],
                        total=list(map(str,total)),groups=len(groups),source_paths=sum(n for _,n in groups.values()),
                        nonzero_groups=sum(v!=(0,0) for v,_ in groups.values()),
                        selected_label_witness=list(map(str,coefficient(row['witness']))),
                        selected_label_paths=row['paths'],selected_outer_group=list(map(str,outer)),
                        selected_outer_group_paths=outer_n,local_peak=row['local_peak'],
                        later_paths=row['later_paths'],work=row['work']))
assert [r['total'] for r in results]==[['0','-3/1024'],['0','0'],['0','0']]
assert [r['groups'] for r in results]==[12,8,4]
assert [r['source_paths'] for r in results]==[96,64,48]
assert [r['nonzero_groups'] for r in results]==[6,4,4]
assert [r['selected_label_paths'] for r in results]==[2,2,1]
assert [r['local_peak'] for r in results]==[868,858,854]
assert [r['later_paths'] for r in results]==[12,10,12]
assert [r['work'] for r in results]==[1145330,1301965,1464110]
terminal=rows[-1]
assert terminal['mode']=='original' and terminal['any_complete_nonzero'] is True
assert sum(terminal['work'].values())==terminal['work_total']==1464110<=20_000_000
assert terminal['oracle_peak']==986<=16384
prod=sum(r['groups'] for r in results)
assert terminal['prefix_output_records']==696
assert terminal['cumulative_output_records']==696+prod==720<=2048
assert terminal['work']['multicenter_receipt_rows']==prod
assert terminal['work']['multicenter_reference_comparisons']==44
assert terminal['work']['multicenter_oracle_signed_updates']==40
print(json.dumps(dict(results=results,total_signed_groups=prod,source_paths=sum(r['source_paths'] for r in results),
                      oracle_comparisons=44,oracle_retained_groups=44-prod,oracle_signed_updates=40,
                      work=terminal['work_total'],oracle_peak=terminal['oracle_peak'],
                      prefix=696,cumulative_signed_records=720,wall_seconds=94),indent=2))
