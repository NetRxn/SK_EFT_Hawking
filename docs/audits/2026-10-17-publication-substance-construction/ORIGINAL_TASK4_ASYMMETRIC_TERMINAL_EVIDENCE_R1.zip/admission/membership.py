from contextlib import redirect_stdout
from io import StringIO
import json
from runpy import run_path

d="/tmp/publication-l1-asymmetric-candidate-r1.sL0Nfh"
m=run_path(d+"/candidate.py",run_name="candidate_membership_review")
with redirect_stdout(StringIO()):
    f=run_path("/tmp/publication-task4-multicenter-s2s2-r2.adverse.py")
inputs,z=f["inputs"],f["z_inputs"]
labels=f["labels"]
x,w,zz,y=labels
cx,hx,cw,ww,contacts,cy,hy=inputs
cz,wz=z
def outer(c,h,k):
    return c[k[2],k[4]],c[k[3],k[5]],h[k]
def center(c,h,k):
    operands,trace=h[k]
    return (*(c[i] for i in operands),trace)
contact=contacts[f["target"][2]]
factors=(*outer(cx,hx,x),*center(cw,ww,w),*center(cz,wz,zz),contact,*outer(cy,hy,y))
operands=[]
for fac in factors:
    (mask,key,slot),v=next(m["r2"].r4.rows(fac))
    assert not slot
    operands.append((mask,key,v))
work=m["r5"].Work(cap=100000)
m["check_source_membership"](operands,labels,inputs,z,contact,contact,0,work)
for position in (5,8,9):
    modified=list(operands)
    mask,key,_=modified[position]
    modified[position]=(mask,key,m["Q"](123456789))
    try:
        m["check_source_membership"](modified,labels,inputs,z,contact,contact,0,work)
    except RuntimeError as error:
        assert str(error)=="preregistered operand absent from its original labelled factor"
    else:
        raise AssertionError(position)
print(json.dumps({"matched_exact_operands":len(operands),"refused_altered_coefficients":[5,8,9],"work":work.used}))
