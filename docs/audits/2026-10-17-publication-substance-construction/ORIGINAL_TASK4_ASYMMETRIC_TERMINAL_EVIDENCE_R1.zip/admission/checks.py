import ast
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from unittest.mock import patch

d=Path("/tmp/publication-l1-asymmetric-candidate-r1.sL0Nfh")
seed=Path("/tmp/publication-l1-pairing-r1.hy5gTm")
m=run_path(str(d/"candidate.py"),run_name="candidate_review_only")
mod=m["run"].__globals__
keys=("candidate","direction","chosen_branch","path","residual_mask","residual_value","local_path_count")
accepted=[]
for name in ("chirality.jsonl","double-chirality.jsonl"):
    for row in map(json.loads,(seed/name).read_bytes().splitlines()):
        if "candidate" in row:
            accepted.append({k:row[k] for k in keys})
data=(d/"targets.jsonl").read_bytes()
assert len(data)==m["TARGET_BYTES"]==7229
assert sha256(data).hexdigest()==m["TARGET_DIGEST"]
assert list(map(json.loads,data.splitlines()))==accepted
assert b"".join((json.dumps(row,separators=(",",":"))+"\n").encode() for row in accepted)==data
assert len({json.dumps(row["candidate"],sort_keys=True) for row in accepted})==3
assert m["r2"].output_prefix()==696
assert (m["r10"].LOCAL_CAP,m["r10"].LATER_CAP,m["r10"].PAIR_CAP,m["r10"].OUTPUT_CAP,m["r10"].WORK_CAP)==(8192,8192,16384,2048,20000000)

def refuses(kind, op):
    try:
        op()
    except kind as error:
        return str(error)
    raise AssertionError("expected refusal")

auth_controls=[]
with TemporaryDirectory() as directory,patch.dict(mod,HERE=Path(directory)):
    ledger=Path(directory)/"targets.jsonl"
    for name,altered in (("same-length",b" "+data[1:]),("truncated",data[:-1]),("oversized",data+b"x"*50)):
        ledger.write_bytes(altered)
        work=m["r5"].Work(cap=100000)
        refuses(AssertionError,lambda:m["target_lines"](work))
        assert work.used==min(len(altered),len(data)+1)
        auth_controls.append((name,work.used))
    ledger.write_bytes(data)
    work=m["r5"].Work(cap=len(data)-1)
    msg=refuses(RuntimeError,lambda:m["target_lines"](work))
    assert "asymmetric_ledger_input_bytes" in msg and work.used==0
    auth_controls.append(("byte budget",msg))

silence=StringIO()
with redirect_stdout(silence):
    fixture=run_path("/tmp/publication-task4-multicenter-s2s2-r2.adverse.py")
assert json.loads(silence.getvalue())==json.loads(
    Path("/tmp/publication-task4-multicenter-s2s2-r2.adverse.json").read_text())
work=m["r5"].Work(cap=100000,oracle_record_cap=m["r10"].PAIR_CAP)
r={"reserved_path_records":73,"witness_peak":73}
arguments=tuple(fixture[k] for k in ("target","labels","value"))+(1,r)+tuple(
    fixture[k] for k in ("inputs","z_inputs"))+((fixture["rw"],fixture["rz"]),work)
assert m["evaluate"](*arguments,1) and r["output_records"]==1
assert r["total"]=="QComplex(storage=(-1296, 1, 0, 1))"
cap_failure=refuses(RuntimeError,lambda:m["evaluate"](*arguments,0))
assert "signed output cap" in cap_failure
for p,q in (({"only_p":(m["Q"](1),1)},{}),({},{"only_q":(m["Q"](1),1)}),
            ({"shared":(m["Q"](1),1)},{"shared":(m["Q"](2),1)})):
    refuses(AssertionError,lambda:m["compare_groups"](p,q,work))
assert m["compare_groups"]({"p":(m["ZERO"],10)},{"q":(m["ZERO"],2)},work)==m["ZERO"]

# Check the CLI's exclusive output creation structurally without entering the original CLI mode.
tree=ast.parse((d/"candidate.py").read_bytes())
node=tree.body[-1]
assert isinstance(node,ast.If) and isinstance(node.body[0],ast.If)
branch=node.body[0].orelse[0]
assert isinstance(branch,ast.With)
opening=branch.items[0].context_expr
assert ast.unparse(opening)=="(HERE / 'original.jsonl').open('x')"
assert ast.unparse(branch.body[0])=="run(original=True, out=stream)"
assert not (d/"original.jsonl").exists()

def terminal(outcomes):
    # The full evaluator and all source/roster work are replaced by finite stubs.
    capacities=[]
    out=StringIO()
    def consume(*args):
        capacity=args[-1]
        receipt=args[4]
        work=args[-2]
        i=len(capacities)
        capacities.append(capacity)
        receipt["output_records"]=i+1
        work.charge("synthetic_assigned",i+1)
        work.oracle_max_prospective_records=i+1
        return outcomes[i]
    with patch.object(m["r2"],"setup",lambda work:(None,(None,None,None,None),None,None,None,None,None)), \
         patch.object(m["r2"],"identity_controls",lambda *args:{"R9":18,"R10":3}), \
         patch.dict(mod,{"checked_request":lambda *args:(None,None,None,None,{}),"evaluate":consume}):
        if any(outcomes):
            m["run"](original=True,out=out)
        else:
            msg=refuses(RuntimeError,lambda:m["run"](original=True,out=out))
            assert msg=="all selected complete signed totals are zero"
    rows=list(map(json.loads,out.getvalue().splitlines()))
    assert capacities==[1352,1351,1349] and len(rows)==5
    assert rows[0]["identity_controls"]=={"R9":18,"R10":3}
    assert rows[-1]=={"mode":"original","work":{"asymmetric_ledger_input_bytes":7229,"synthetic_assigned":6},
                      "work_total":7235,"oracle_peak":3,"prefix_output_records":696,
                      "cumulative_output_records":702,"any_complete_nonzero":any(outcomes)}
    return rows[-1]

print(json.dumps({"ledger":{"targets":3,"bytes":7229,"adverse":auth_controls},
                  "direct_synthetic":{"total":r["total"],"signed_output_refusal":cap_failure},
                  "terminal_nonzero":terminal([False,True,False]),
                  "terminal_zero_refusal":terminal([False,False,False]),
                  "exclusive_open":"x","original_path_absent":True},indent=2))
