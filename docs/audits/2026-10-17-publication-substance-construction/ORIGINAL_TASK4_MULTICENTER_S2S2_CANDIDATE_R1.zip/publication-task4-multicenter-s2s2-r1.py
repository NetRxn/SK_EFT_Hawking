"""Bounded original N16 S2(w) S2(z) coefficient requests."""
from collections import Counter, defaultdict
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import random
import sys

HERE = Path(__file__).parent
spec = spec_from_file_location("two_center_r13", HERE / "publication-task4-continuation-quartic-r13.py")
base = module_from_spec(spec)
sys.modules[spec.name] = base
spec.loader.exec_module(base)
r10, r5, r6, r7, r4 = base.r10, base.r5, base.r6, base.r7, base.r10.r4
E, P, Q, S = r10.E, r10.P, r10.Q, r10.S
ONE, ZERO = Q(1), Q(0)
PREFIX = 696
R9_DIGEST = "d6434a1c026a214a501c9935d54b6bc7009ccd2c36513d0c08bac6953210a92f"
SLOTS = r10.SLOTS
G2 = r10.G2
IDENTITY = {(0, ()): {(): (ONE, 1)}}

def merge(table, key, value, paths):
    old = table.get(key)
    if old is None:
        table[key] = value, paths
    else:
        table[key] = old[0] + value, old[1] + paths

def setup(work):
    reg, (x,y,w), inputs, raw_w, d0, d1 = r10.setup(work)
    z = reg.step(w, 0)[0]
    assert z == reg.step(y, 2)[0]
    cz, raw_z, choices_z, _ = r10.r9.source_roster(reg, z, work)
    return reg, (x,y,w,z), inputs, (cz, choices_z), (raw_w, raw_z), d0, d1

def group_rows(target, coframes, traces, work, admission, used):
    yield from base.group_factors(target, coframes, traces, work, admission, used)

def local_table(target, coframes, choices, work, admission, reserved):
    traces = {key[1:]: poly for key, (_, poly) in choices.items() if key[0] == 2}
    table = {}
    count = 0
    for key, factors, projected in group_rows(
            target, coframes, traces, work, admission, lambda: reserved + count + len(table)):
        for mask, symbols, _, value in r10.stream_rows(factors, target, work):
            work.charge("multicenter_local_group_updates")
            state, label = (mask, symbols), (2,*key)
            labels = table.get(state)
            if labels is None or label not in labels:
                admission.check(reserved + projected + count + len(table)
                                + 1 + int(labels is None))
                count += 1
                if labels is None:
                    labels = table[state] = {}
            merge(labels, label, value, 1)
        del factors
    return table, count + len(table)

def complementary_join(left, right, mask, key, work):
    """Yield complete joined source labels, exact coefficient and path count."""
    for (lm, lk), llabels in left.items():
        work.charge("multicenter_complement_tests")
        if lm & mask != lm:
            continue
        rk = r5.subtract(key, lk)
        if rk is None:
            continue
        rm = mask ^ lm
        labels = right.get((rm, rk))
        if labels is None:
            continue
        sign = r5.mask_sign(lm, rm)
        for llabel, (lv, ln) in llabels.items():
            for rlabel, (rv, rn) in labels.items():
                work.charge("multicenter_complement_updates")
                yield llabel, rlabel, lv * rv * sign, ln * rn

def production(target, inputs, z_inputs, work, capacity, *, identity=False, selected=None, carry=0):
    mask, symbols, slot = target
    assert mask.bit_count() == (14 if identity else 18)
    assert symbols.count(G2) == (3 if identity else 4)
    cx, hx, cw, ww, contacts, cy, hy = inputs
    cap = base.Admission(r10.LOCAL_CAP)
    left, left_size = local_table(target, cw, ww, work, cap, carry)
    if identity:
        right, right_size = IDENTITY, 2
    else:
        right, right_size = local_table(target, *z_inputs, work, cap, carry + left_size)
    fixed = carry + left_size + right_size
    contact = base.projection(contacts[slot], target, work, cap, fixed)
    fixed += len(contact)
    later = defaultdict(list)
    paths = 0
    for ykey, factors, live in group_rows(target, cy, hy, work, cap, lambda: fixed + paths):
        for ym, yk, _, yv in r10.stream_rows(factors, target, work):
            work.charge("multicenter_later_paths")
            if paths + 1 > r10.LATER_CAP:
                raise RuntimeError(f"multicenter later path cap at prospective {paths+1}")
            cap.check(fixed + live + paths + 1)
            later[ym,yk].append((ykey,yv))
            paths += 1
        del factors
    output = r10.SignedOutput(capacity)
    seeded_value, seeded_paths = ZERO, 0
    residual_degree = 4 if identity else 8
    residual_symbol_degree = 7 if identity else 14
    for xkey, factors, live in group_rows(
            target, cx, hx, work, cap, lambda: fixed + paths + len(output.table)):
        for xm, _, remaining, xv in r10.stream_rows((*factors,contact), target, work):
            for (ym,yk), ylabels in later.items():
                work.charge("multicenter_outer_complement_tests")
                if xm & ym:
                    continue
                local_mask = mask ^ (xm | ym)
                if local_mask.bit_count() != residual_degree:
                    continue
                local_key = r5.subtract(remaining, yk)
                if local_key is None or len(local_key) != residual_symbol_degree:
                    continue
                sign = r5.mask_sign(xm, local_mask) * r5.mask_sign(xm|local_mask,ym)
                for wkey,zkey,local,n in complementary_join(left,right,local_mask,local_key,work):
                    for ykey, yv in ylabels:
                        work.charge("multicenter_final_signed_updates")
                        key = (xkey,(wkey,),ykey) if identity else (xkey,(),ykey)
                        cap.check(fixed + paths + live + len(output.table) + int(key not in output.table))
                        coeff = xv * local * yv * sign
                        output.put(key, coeff, n)
                        if (xkey,wkey,zkey,ykey) == selected:
                            seeded_value += coeff
                            seeded_paths += n
        del factors
    return output, cap.peak, paths, seeded_value, seeded_paths

def independent_sign(left, right):
    parity = 0
    while left:
        bit = left & -left
        parity ^= (right & (bit-1)).bit_count() & 1
        left ^= bit
    return -1 if parity else 1

def oracle(target, inputs, z_inputs, raws, work, capacity, carry):
    """Rebuild actual raw local orientations and canonical outer products."""
    mask, symbols, slot = target
    cx, hx, _, _, contacts, cy, hy = inputs
    cap = base.Admission(r10.LOCAL_CAP)
    cap.check(carry)
    left = base.raw_vertices(target, inputs, raws[0], work, cap, carry)
    cz, wz = z_inputs
    other = (None,None,cz,wz,None,None,None)
    right = base.raw_vertices(target, other, raws[1], work, cap, carry + len(left))
    reserve = carry + len(left) + len(right)
    target_counts = Counter(symbols)
    def restrict(poly, fixed):
        n = r5.count(poly)
        cap.check(fixed + n)
        return r5.subset_factor(poly, mask, target_counts, work)
    d = restrict(contacts[slot], reserve)
    reserve += r5.count(d)
    # Partition eager products into one exact canonical left row.
    # Each step reserves the distinct input/output and projection scratch.
    def product_at(a,b,fixed):
        out = E()
        ac,bc = r5.count(a),r5.count(b)
        for am,p in a.terms:
            for ak,av in p.terms:
                live = fixed + ac + bc + r5.count(out)
                prospective = live + 1 + 2*bc
                if prospective > work.oracle_record_cap:
                    raise RuntimeError(f"multicenter oracle cap at prospective {prospective}")
                work.oracle_max_prospective_records = max(work.oracle_max_prospective_records,prospective)
                cap.check(live+1+bc)
                work.charge("multicenter_oracle_pairs",bc)
                part = E(((am,P(((ak,av),))),)) * b
                projected = r5.subset_factor(part,mask,target_counts,work)
                updated = r5.count(projected)
                accumulated = live + r5.count(part) + r5.count(out) + 2*updated
                if accumulated > work.oracle_record_cap:
                    raise RuntimeError(f"multicenter oracle sum cap at prospective {accumulated}")
                work.oracle_max_prospective_records = max(work.oracle_max_prospective_records,accumulated)
                cap.check(accumulated)
                work.charge("multicenter_oracle_canonical_sums",updated)
                out += projected
                del part, projected
        return out
    def outer(coframes,traces,used,with_contact):
        for label,trace in traces.items():
            work.charge("multicenter_oracle_outer_branches")
            _,_,mu,nu,a,b = label
            fixed = used()
            p = restrict(coframes[mu,a],fixed)
            pc = r5.count(p)
            q = restrict(coframes[nu,b],fixed+pc)
            h = restrict(trace,fixed+pc+r5.count(q))
            if p == E() or q == E() or h == E():
                del p,q,h
                continue
            pair = product_at(p,q,fixed+r5.count(h))
            del p,q
            vertex = product_at(pair,h,fixed)
            del pair,h
            if with_contact:
                vertex = product_at(vertex,d,fixed-r5.count(d))
            if vertex != E():
                yield label,vertex
            del vertex
    later = {}
    later_size = 0
    for key, poly in outer(cy,hy,lambda:reserve+later_size,False):
        count = r5.count(poly)
        if later_size+count > r10.LATER_CAP:
            raise RuntimeError(f"multicenter oracle later cap at prospective {later_size+count}")
        cap.check(reserve+later_size+count)
        later[key] = poly
        later_size += count
        del poly
    out = r10.SignedOutput(capacity)
    for xkey, early in outer(cx,hx,lambda:reserve+later_size+len(out.table),True):
        for ykey, late in later.items():
            for (em,ek,_),ev in r4.rows(early):
                for (ym,yk,_),yv in r4.rows(late):
                    work.charge("multicenter_oracle_outer_pairs")
                    if em & ym:
                        continue
                    outer_counts = Counter(ek+yk)
                    if outer_counts - target_counts:
                        continue
                    sub = target_counts - outer_counts
                    if sum(sub.values()) != 14:
                        continue
                    required = mask ^ (em|ym)
                    if required.bit_count() != 8:
                        continue
                    for (lm,lk),(lv,_) in left.items():
                        work.charge("multicenter_oracle_raw_joins")
                        if lm & required != lm or not lv:
                            continue
                        lc = Counter(lk)
                        if lc - sub:
                            continue
                        rk = tuple(sorted((sub-lc).elements()))
                        rm = required ^ lm
                        rv,_ = right.get((rm,rk),(ZERO,0))
                        if rv:
                            key = (xkey,(),ykey)
                            cap.check(reserve+later_size+r5.count(early)+len(out.table)+int(key not in out.table))
                            work.charge("multicenter_oracle_signed_updates")
                            sign = (independent_sign(em,lm) * independent_sign(em|lm,rm)
                                    * independent_sign(em|lm|rm,ym))
                            out.put(key,ev*lv*rv*yv*sign)
        del early
    return out, cap.peak

def identity_controls(inputs, z_inputs, work):
    r9_bytes = (HERE/"publication-task4-continuation-vertices-r9.json").read_bytes()
    assert sha256(r9_bytes).hexdigest() == R9_DIGEST
    counts = Counter()
    for row in json.loads(r9_bytes)["targets"]:
        if row["degree"] != 2:
            continue
        out,*_ = production(r6.decoded(row["target"]),inputs,z_inputs,work,r10.OUTPUT_CAP,identity=True)
        base.Admission(r10.LOCAL_CAP).check(4*len(out.table))
        work.charge("multicenter_identity_receipt_rows",len(out.table))
        assert r10.as_r9(out) == row["groups"]
        counts["R9"] += 1
        del out
    r10_bytes = (HERE/"publication-task4-continuation-powers-r10.progress.jsonl").read_bytes()
    assert sha256(r10_bytes).hexdigest() == base.PREFIX_DIGEST
    for line in r10_bytes.splitlines():
        row = json.loads(line)
        if row["powers"] != [1,0]:
            continue
        out,*_ = production(r6.decoded(row["target"]),inputs,z_inputs,work,r10.OUTPUT_CAP,identity=True)
        base.Admission(r10.LOCAL_CAP).check(3*len(out.table))
        work.charge("multicenter_identity_receipt_rows",len(out.table))
        actual = [(key,str(value),n) for key,(value,n) in sorted(out.table.items())]
        assert base.json_identity(actual) == row["table"]
        counts["R10"] += 1
        del out
    assert counts == {"R9":18,"R10":3}
    return dict(counts)

def seed_candidates(inputs, z_inputs, slot, direction, d, rng, seen, work,w,z):
    cx,hx,cw,ww,_,cy,hy = inputs
    cz,wz = z_inputs
    def local(c, choices, label):
        components, trace = choices[label]
        return (*(c[key] for key in components),trace)
    def outer(c, h, label):
        _,_,mu,nu,a,b = label
        return c[mu,a],c[nu,b],h[label]
    wg = tuple(key for key in ww if key[0]==2)
    zg = tuple(key for key in wz if key[0]==2)
    xx,yy = tuple(hx),tuple(hy)
    for attempt in range(1,2049):
        work.charge("multicenter_seed_attempts")
        wk,zk = rng.choice(wg),rng.choice(zg)
        if direction == 0 and slot == SLOTS[0]:
            if 0 not in wk[3:5] or 0 not in zk[3:5]:
                continue
        xk,yk = rng.choice(xx),rng.choice(yy)
        polys = (*outer(cx,hx,xk),*local(cw,ww,wk),*local(cz,wz,zk),d,*outer(cy,hy,yk))
        mask = 0
        key = []
        lineage = []
        for poly in polys:
            view = base.IndexedRows(poly,work)
            for _ in range(16):
                work.charge("multicenter_seed_draws")
                (m,k,_),value = rng.choice(view)
                if not m&mask:
                    mask |= m
                    key.extend(k)
                    lineage.append((m,k,value))
                    break
            else:
                del view
                break
            del view
        else:
            shared = set(s for _,keypart,_ in lineage[3:6] for s in keypart) & {
                s for _,keypart,_ in lineage[6:9] for s in keypart}
            reciprocal = sorted(s for s in shared if s.family == "q" and s.index[0] in (w,z) and s.index[1] == 0)
            if slot == SLOTS[0] and not reciprocal:
                continue
            full = mask,tuple(sorted(key)),slot
            if full in seen:
                continue
            seen.add(full)
            # Convert the bounded 13-operand lineage to an immutable
            # receipt. The seed frame no longer owns an index view.
            yield full,direction,(xk,wk,zk,yk),attempt,reciprocal,lineage
    raise RuntimeError(f"multicenter structural seed cap reached for {slot} direction {direction}")

def selected_witness(target, inputs, z_inputs, selected, work, carry=0):
    """Complete labelled branch coefficient, independently of the full tables."""
    cx,hx,cw,ww,contacts,cy,hy = inputs
    cz,wz = z_inputs
    xk,wk,zk,yk = selected
    slot = target[2]
    cap = base.Admission(r10.LOCAL_CAP)
    live = carry
    def retain(poly):
        nonlocal live
        projected = base.projection(poly,target,work,cap,live)
        live += len(projected)
        return projected
    def outer(coframes,traces,label):
        _,_,mu,nu,a,b = label
        return retain(coframes[mu,a]),retain(coframes[nu,b]),retain(traces[label])
    def inner(coframes,choices,label):
        components,trace = choices[label]
        return (*(retain(coframes[c]) for c in components),retain(trace))
    x,w,z,y = outer(cx,hx,xk),inner(cw,ww,wk),inner(cz,wz,zk),outer(cy,hy,yk)
    d = retain(contacts[slot])
    later = {}
    ypaths = 0
    for ym,yk,_,yv in r10.stream_rows(y,target,work):
        work.charge("multicenter_witness_later_updates")
        ypaths += 1
        if ypaths > r10.LATER_CAP:
            raise RuntimeError(f"multicenter witness later path cap at {ypaths}")
        cap.check(live+len(later)+int((ym,yk) not in later))
        merge(later,(ym,yk),yv,1)
    value,paths = ZERO,0
    for pm,_,remaining,pv in r10.stream_rows((*x,*w,*z,d),target,work):
        ym = target[0] ^ pm
        if (ym,remaining) in later:
            work.charge("multicenter_witness_final_updates")
            yv,n = later[ym,remaining]
            value += pv*yv*r5.mask_sign(pm,ym)
            paths += n
    return value,paths,cap.peak

def witness_candidates(inputs,z_inputs,d0,d1,work,w,z,rejected):
    rng = random.Random(20261107)
    seen = set()
    for slot,direction,d in ((SLOTS[0],0,d0),(SLOTS[1],0,d0),(SLOTS[1],1,d1)):
        candidates = seed_candidates(inputs,z_inputs,slot,direction,d,rng,seen,work,w,z)
        for _ in range(12):
            target,_,selected,attempt,shared,lineage = next(candidates)
            reserved = len(lineage) + 1
            value,n,peak = selected_witness(target,inputs,z_inputs,selected,work,reserved)
            receipt = dict(target=r5.fingerprint(target),direction=direction,
                           branch=selected,attempt=attempt,repeated=r5.fingerprint((0,shared,()))["symbols"],
                           path=[(hex(m),[(s.family,s.index) for s in k],str(v)) for m,k,v in lineage],
                           witness=str(value),paths=n,witness_peak=peak,reserved_path_records=reserved)
            if value:
                assert n
                break
            rejected(receipt)
            del receipt
        else:
            raise RuntimeError(f"multicenter witness cap for slot {slot} direction {direction}")
        # Release the actual seed generator and its bounded path before
        # the coefficient evaluator. Carry the serialized receipt rows.
        candidates.close()
        del candidates,lineage
        yield target, selected, value, n, receipt

def output_prefix():
    frozen = (HERE/"publication-task4-continuation-quartic-r13.original.jsonl").read_bytes()
    expected = "822c1a3785f4ba68e8fe594bda0962ce4b5fbc6d3bdad3c6ae22ccd6a2d6b3a8"
    assert sha256(frozen).hexdigest() == expected
    receipt = [json.loads(line) for line in frozen.splitlines()]
    terminal = receipt[-1]
    assert terminal["prefix_output_records"] == 652
    assert sum(row["output_records"] for row in receipt[:-1]) == terminal["quartic_output_records"] == 44
    assert terminal["cumulative_output_records"] == PREFIX
    return PREFIX

def run_original():
    work = r5.Work(cap=r10.WORK_CAP,oracle_record_cap=r10.PAIR_CAP)
    reg,(x,y,w,z),inputs,z_inputs,raws,d0,d1 = setup(work)
    used = output_prefix()
    path = HERE/"publication-task4-multicenter-s2s2-r1.original.jsonl"
    with path.open("x") as out:
        identities = identity_controls(inputs,z_inputs,work)
        print(json.dumps(dict(identity_controls=identities,work=work.used)),file=out,flush=True)
        def log(row):
            print(json.dumps(row),file=sys.stderr,flush=True)
        nonzero = False
        for target,selected,value,n,receipt in witness_candidates(inputs,z_inputs,d0,d1,work,w,z,log):
            log(receipt)
            capacity = r10.OUTPUT_CAP-used
            carry = receipt["reserved_path_records"]
            result,peak,later,seeded,paths = production(target,inputs,z_inputs,work,capacity,
                                                       selected=selected,carry=carry)
            assert (seeded,paths) == (value,n)
            ref,oracle_peak = oracle(target,inputs,z_inputs,raws,work,capacity,carry+len(result.table))
            total = ZERO
            for key,(coefficient,_) in result.table.items():
                work.charge("multicenter_reference_comparisons")
                assert coefficient == ref.table.get(key,(ZERO,0))[0]
                total += coefficient
            for key,(coefficient,_) in ref.table.items():
                work.charge("multicenter_reference_comparisons")
                assert coefficient == result.table.get(key,(ZERO,0))[0]
            del ref
            nonzero |= bool(total)
            # Result conversion is a separate phase. Reserve the sorted
            # index and rendered rows while the signed table is still live.
            result_conversion = carry+3*len(result.table)
            base.Admission(r10.LOCAL_CAP).check(result_conversion)
            work.charge("multicenter_receipt_rows",len(result.table))
            receipt.update(total=str(total),local_peak=max(peak,oracle_peak,receipt["witness_peak"],result_conversion),
                           later_paths=later,output_records=len(result.table),
                           table=[(k,str(v),p) for k,(v,p) in sorted(result.table.items())],
                           work=work.used)
            used += len(result.table)
            print(json.dumps(receipt),file=out,flush=True)
            del result, receipt
        if not nonzero:
            raise RuntimeError("all selected complete signed totals are zero")
        print(json.dumps(dict(work=dict(work.counts),work_total=work.used,
                         oracle_peak=work.oracle_max_prospective_records,
                         prefix_output_records=PREFIX,cumulative_output_records=used)),file=out,flush=True)

if __name__ == "__main__":
    if sys.argv[1:] != ["--root-admitted-original"]:
        raise SystemExit("Original replay requires ROOT admission and explicit mode")
    run_original()
