"""Bounded original source witnesses and frozen one-center identity controls."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import sys
p=Path(__file__).with_name("publication-task4-multicenter-s2s2-r1.py")
spec=spec_from_file_location("two_center_witness_control",p)
m=module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)
work=m.r5.Work(cap=1_500_000,oracle_record_cap=m.r10.PAIR_CAP)
reg,(x,y,w,z),inputs,z_inputs,raws,d0,d1=m.setup(work)
identity=m.identity_controls(inputs,z_inputs,work)
accepted=[]
refused=[]
for target,selected,value,n,row in m.witness_candidates(inputs,z_inputs,d0,d1,work,w,z,refused.append):
    assert target[0].bit_count()==18 and value and n
    accepted.append(row)
assert len(accepted)==3 and accepted[0]["repeated"]
assert [row["direction"] for row in accepted]==[0,0,1]
print(json.dumps(dict(identity=identity,rows=accepted,rejected=refused,work=work.used,counts=dict(work.counts),
                     prefix=m.output_prefix(),work_cap=work.cap),indent=2))
