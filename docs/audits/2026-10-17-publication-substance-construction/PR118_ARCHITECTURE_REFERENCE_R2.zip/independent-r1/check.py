import architecture_inventory as a
from validate import check_architecture_inventory_fresh

result = check_architecture_inventory_fresh()
details = {d.name: d for d in result.details}
for name in ("inventory_fresh", "doc_refs_resolve"):
    d = details[name]
    print(name, d.passed, d.message)
print("hooks", [(entry["kind"], entry["event"]) for entry in a.hooks()])
