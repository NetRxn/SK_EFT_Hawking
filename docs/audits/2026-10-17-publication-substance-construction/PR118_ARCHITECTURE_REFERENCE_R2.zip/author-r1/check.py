from validate import check_architecture_inventory_fresh
r=check_architecture_inventory_fresh()
for d in r.details:
    if d.name in {'inventory_fresh','doc_refs_resolve'}:
        print(d.name,d.passed,d.message)
assert not r.passed
