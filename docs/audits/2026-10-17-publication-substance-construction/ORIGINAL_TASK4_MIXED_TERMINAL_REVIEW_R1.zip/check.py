from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import datetime as dt
import json, re, sys

root = Path(sys.argv[1])
def lines(name):
    return [json.loads(line) for line in (root / name).read_text().splitlines()]
def digest(name):
    return sha256((root / name).read_bytes()).hexdigest()
def freeze(x):
    return tuple(map(freeze, x)) if isinstance(x, list) else x
def scalar(s):
    match = re.fullmatch(r"QComplex\(storage=\((-?\d+), (\d+), (-?\d+), (\d+)\)\)", s)
    a,b,c,d = map(int, match.groups())
    return Fraction(a,b), Fraction(c,d)
def render(x):
    return list(map(str, x))
def add(coefficients):
    return tuple(map(sum, zip(*coefficients, strict=True)))
def reflect(label):
    return *label[:4], label[4] ^ 1, label[5] ^ 1

launch = json.loads((root / 'original.launch.json').read_text())
assert launch['assertions'] is True
assert launch['candidate'] == digest('candidate.py')
assert launch['ledger'] == digest('targets.jsonl')
assert launch['source'] == (root / 'original.post-head').read_text().strip()
assert launch['command'] == ['env','-u','PYTHONOPTIMIZE','PYTHONPATH=.','.venv/bin/python','-B',
                             str(root / 'candidate.py'),'--root-admitted-original']
assert (root / 'original.exit').read_text().strip() == '0'
assert all((root/f'original.{s}').stat().st_size == 0 for s in ('stdout','stderr','post-status'))
baseline, *requests, terminal = lines('original.jsonl')
before, *bounded, final_bounded = lines('bounded.jsonl')
targets = lines('targets.jsonl')
assert baseline == before == {"baseline":{"identity":{"R9":18,"R10":3},
                "s2s2_witnesses":3,"s2s2_signed_groups":24},"work":1034454}
assert len(requests) == len(bounded) == len(targets) == 6
expected = [((2,4),(0,),0),((2,4),(0,1),0),((2,4),(0,1),1),
            ((4,2),(0,),0),((4,2),(0,1),0),((4,2),(0,1),1)]
summary = []
total_records = 0
for row, frozen, control, key, raw in zip(requests,targets,bounded,expected,(root/'targets.jsonl').read_bytes().splitlines(),strict=True):
    assert all(row[name] == value for name,value in frozen.items() if name not in ('local_peak','reserved_path_records'))
    assert row['reserved_path_records'] == 3*(raw.count(b'[')+raw.count(b'{'))+96
    assert all(row[name] == value for name,value in control.items() if name not in ('work','local_peak'))
    target = row['target']
    degrees, slot, direction = key
    assert (tuple(row['degrees']), tuple(target['slot']), row['direction']) == key
    assert tuple(row['branch'][j][0] for j in (1,2)) == degrees
    assert len(row['path']) == 15 and 1<=row['attempt']<=2048 and 1<=row['qualified']<=12
    mask = 0
    symbols = Counter()
    for operand, syms, c in row['path']:
        operand = int(operand,16)
        assert operand & mask == 0 and any(scalar(c))
        mask |= operand
        symbols.update(map(freeze,syms))
    assert mask == int(target['mask_hex'],16) and mask.bit_count() == 22
    assert symbols == Counter(map(freeze,target['symbols']))
    assert Counter({family:sum(n for (f,_),n in symbols.items() if f==family)
               for family in ('J','g1','g2','q')}) == {'J':1,'g1':1,'g2':3,'q':23}
    if slot == (0,):
        w, z = (1,0,1,0), (0,0,1,0)
        def labels(path):
            return {q for _,syms,_ in path for q in map(freeze,syms)}
        wlast = 4 + degrees[0]
        common = labels(row['path'][3:wlast]) & labels(row['path'][wlast:5+sum(degrees)])
        repeated = {q for q in common if q[0]=='q' and q[1][0] in (w,z) and q[1][1]==0}
        assert repeated and repeated == set(map(freeze,row['repeated']))
    table = {freeze(g):(scalar(coeff), paths) for g,coeff,paths in row['table']}
    assert len(table) == len(row['table']) == row['output_records']
    assert all(isinstance(n,int) and n>0 for _,n in table.values())
    assert all(k[1] == () for k in table)
    coefficient = add([c for c,_ in table.values()])
    assert coefficient == scalar(row['total'])
    x,_,_,y = map(tuple,row['branch'])
    frames = [(x,(),y),(reflect(x),(),y),(x,(),reflect(y)),(reflect(x),(),reflect(y))]
    frame_rows = [table.get(g,((Fraction(),Fraction()),0)) for g in frames]
    assert frame_rows == list(zip(map(scalar,row['frame_coefficients']),row['frame_paths'],strict=True))
    assert 0 < row['later_paths'] <= 8192 and 0 < row['local_peak'] <= 8192
    assert row['local_peak'] >= row['witness_peak']
    assert row['local_peak'] >= row['reserved_path_records'] + 3*len(table)
    total_records += len(table)
    summary.append(dict(degrees=degrees,slot=slot,direction=direction,coefficient=render(coefficient),
                    nonzero_group_counts=dict(Counter(map(tuple,[render(c) for c,_ in table.values() if any(c)]))),
                    groups=len(table),zero_groups=sum(not any(c) for c,_ in table.values()),
                    production_paths=sum(n for _,n in table.values()),four_frame_sum=render(add([c for c,_ in frame_rows])),
                    local_peak=row['local_peak'],later_paths=row['later_paths'],discovery_work=row['work']))
    summary[-1]['nonzero_group_counts'] = [
        {"coefficient": k, "count": n} for k,n in summary[-1]['nonzero_group_counts'].items()]
assert terminal['mode'] == 'original' and final_bounded['mode'] == 'bounded_controls'
assert terminal['complete_nonzero'] == sum(any(map(Fraction,r['coefficient'])) for r in summary) == 3
assert final_bounded['cumulative_output_records'] == terminal['prefix_output_records'] == 720
assert terminal['cumulative_output_records'] == 720+total_records == 784 < 2048
assert terminal['work_total'] == sum(terminal['work'].values()) == 2323582 < 20_000_000
assert terminal['oracle_peak'] == 1081 < 16384
assert terminal['work']['multicenter_reference_comparisons'] == 124
assert terminal['work']['mixed_power_signed_receipt_rows'] == total_records
print(json.dumps(dict(rows=summary, terminal=terminal, digest=digest('original.jsonl'),
    duration_seconds=(dt.datetime.fromisoformat((root/'original.stop').read_text().strip()) -
                      dt.datetime.fromisoformat(launch['utc'])).total_seconds()),indent=2))
