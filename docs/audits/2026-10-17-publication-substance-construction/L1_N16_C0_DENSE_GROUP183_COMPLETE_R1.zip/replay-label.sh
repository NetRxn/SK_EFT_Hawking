#!/bin/bash
set -euo pipefail
n=$1
stage=$2
mode=$3
base="${L1_GROUP183_AUTHOR_ROOT:-/private/tmp/l1-geometry-component3-preparation.HJyusc/183/cached-original-roster}"
a="$base/L$n"
d="$PWD/author/L$n"
python3 -B configure.py "$n" "$stage" "$mode"
(
 cd "$a"
 cp ./*.py ./*.out contraction.err contraction.receipt joint-label-roster.tsv "$d/"
 shasum -a 256 ../../dense-saturated-frontier.pkl ./*.pkl
) > "$d/operand.sha256"
cp "$base/solve-L$n.out" "$d/solve.out"
cp "$base/solve-L$n.time" "$d/solve.time"
python3 -B -u source.py "$n" > "$d/native-replay.out"
if [[ "$n" == 4 || "${4:-}" == author-order ]]; then
 python3 -B -u verify.py "$n" --author-guard-order > "$d/replay-guarded.out"
else
 python3 -B -u verify.py "$n" > "$d/replay-guarded.out"
fi
if [[ "$mode" == triangle ]]; then
 python3 -B -u triangle_replay.py "$n" > "$d/triangle-replay.out"
 cp "$a"/{terminal.out,triangle.py} "$d/"
 if [[ -s "$a/terminal.time" ]]; then cp "$a/terminal.time" "$d/"; fi
 python3 -B audit_triangle.py "$n" > "$d/triangle-interval-audit.out"
fi
(cd "$a" && shasum -a 256 -c "$d/operand.sha256") > "$d/operand-verify.out"
