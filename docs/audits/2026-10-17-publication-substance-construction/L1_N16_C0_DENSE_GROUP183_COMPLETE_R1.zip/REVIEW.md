# Independent complete signed Group 183 review

The original eight Group 183 joint-L ordinals are covered. Ordinals 0, 2,
4, 5, 6 and 7 have independently replayed signed terminals. Ordinals 1 and 3
each have 13 empty prepared restrictions and give exact zero. The scalar
ledger retains all original tuples, exact Gaussian numerators and the
inherited factor denominator.

The work-start continuity packet was fresh at
b1caf1dfd346365feecbb143949f5b0366ae21bc. The accepted component-3
preparation pins the whole 88-factor prepared Group 183 parent at SHA-256
905c0318a1f347a9b8a11106ee41fd3bfdfa84f9edfee9ac2ad911dd9aa0c879.
The archive bound the disjoint eight-member original cut and the two
exact zeros. Group 183 is on component 3's accepted selected side
and its original gamma3 partner is Group 3548. The cover coefficient
is 192 from the occupation weight 48 and factors of two for the
gamma3 partner and the complete selected side.

## Guarded signed contraction

Every native replay independently enumerated the label support, lifted
every selected signed row into the prepared parent, and reconstructed
the retained exact cap tables. Each reviewer crossed the 500,000-row native
guard on the same pair. The continuation replay verifies complete signed
inverse splits, original degree-two wiring, exact quotient folds,
necessary peer projections, and each retained Gaussian coefficient
table. Continuation refusals preserve the prejoin state and original work
accounting. For author-order continuation replays, compatible product
order was reproduced to check the order-dependent cap visits and
supported product counts. L0 uses the reviewer's reverse accumulation
order. Its exact crossings and signed retained tables were independently
reproduced. Both the reported author and independent visit counts are
preserved in the refusal ledger.

L4 and L6 close by triangles. Exact independent third-pivot traversals
found 7,714,304 and 7,575,040 compatible signed products respectively,
using two disjoint intervals of at most 4,000,000 products for each.
They agree with both author pivot totals and the independently counted
author interval cover. L0, L2, L5 and L7 close as single empty-axis factors.

## Exact scalar and measured scope

The exact raw Gaussian sum is
(-872120103809124494616139686435418993740052653047043210608640, 0)
at factor denominator 395180970918602703540468584546304.
Its reduced prephysical real value is -2206887901970257579598300160.
Using the original physical divisor 16 × 4^64 once and coefficient 192
once gives **−6465491900303489002729395/83076749736557242056487941267521536 + 0i**.

Six native guarded scopes retain 14 to 22 factors. The review exercised
34 continuation row refusals across 17 retained passes. Product counts,
cut scope, refusal visits and timings are recorded separately.
Measured author components total 637.378503 seconds, comprising 25.45
seconds of preparation, 228.891094 native guarding, 366.190886 retained
continuation, and 16.846523 of separate triangle terminal work. L4's
extra terminal used its external real-time receipt. L6's used elapsed
process time captured in its terminal output. These measurements describe
the Group 183 workload.

## Reproduction

Verify the relative manifest and each archived original-operand
manifest. Large retained pickles remain in the checksum-bound external
operand tree. By default the scripts use the original author
cached-original-roster directory. Set L1_GROUP183_AUTHOR_ROOT to an
equivalently laid out replay tree. The six commands below regenerate
native, continuation and terminal replays into the local evidence
directory.

    python3 -B source-custody.py /path/to/publication-checkpoint
    bash replay-label.sh 0 4 scalar
    bash replay-label.sh 2 3 scalar author-order
    bash replay-label.sh 4 3 triangle author-order
    bash replay-label.sh 5 2 scalar author-order
    bash replay-label.sh 6 3 triangle author-order
    bash replay-label.sh 7 2 scalar author-order
    python3 -B retally.py /path/to/publication-checkpoint

The archive contains the actual independent replay logs and author
receipts used by retally.py. The scripts write evidence in their
local replay directory.
