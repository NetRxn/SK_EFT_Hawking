from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json
P=Path('/tmp');h=lambda p:sha256(p.read_bytes()).hexdigest();D=192**42*4**64*48**6*2**15;pins=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text())['principal_source_sha256'];bound={**pins,'evaluator':'2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'};data={};summary={};hashes={}
original={79:'l1-7981-control-preparation-r2-fixed79',81:'l1-7981-fixed81-r4'}
for word,handle in ((79,89214),(81,32967)):
 pre='l1-7981-exact-reuse-r12-fixed-equivalence-'+str(word);files=[P/(pre+s) for s in ('.out','.err','.exit.json')];out,err,ep=files;rs=[json.loads(l) for l in out.read_text().splitlines()];e=json.loads(ep.read_text());first,last=rs[0],rs[-1];bs=[r for r in rs if r['kind']=='fixed-equivalence-branch']
 assert e['actual_child_exit']==e['driver_exit']==0 and not e['parent_timeout'] and not err.read_bytes() and e['complete_branch_records']==225 and e['truncated_lines']==0
 assert e['limits']=={'cold':600,'WHOLE225baseline_and_reuse_warm':60,'parent':665,'row':120000,'pair':3000000} and e['parent_seconds']<665
 assert first['source_sha256']==last['source_sha256']==bound and len(bs)==first['branches']==last['branches']==225 and last['word']==word and last['prepared_objects_unchanged'] and last['all_raw_weight_fraction_divisor_peak_structural_flags_equal']
 assert last['cold_seconds']<600 and last['whole225_baseline_and_reuse_warm_seconds']<60 and last['baseline_seconds']+last['reuse_seconds']<=last['whole225_baseline_and_reuse_warm_seconds']
 old=[json.loads(l) for l in (P/(original[word]+'.out')).read_text().splitlines()];obs=[r for r in old if r['kind']=='exact-fixed-branch'];total=F()
 for i,(b,o) in enumerate(zip(bs,obs,strict=True)):
  assert b['branch']==i and b['word']==word
  for k in ('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows'):assert b[k]==o[k]
  assert b['divisor']==D and F(*b['coefficient'])==F(b['raw_numerator'],D);total+=F(*b['weight'])*F(*b['coefficient'])
  if b['algebraic_empty_preparation']:assert not b['reused_contraction'] and b['representative_branch'] is None and b['raw_numerator']==b['peak_rows']==0
  elif b['reused_contraction']:
   rep=bs[b['representative_branch']];assert not rep['reused_contraction'] and not rep['algebraic_empty_preparation'] and rep['branch']<i and (b['raw_numerator'],b['peak_rows'])==(rep['raw_numerator'],rep['peak_rows'])
  else:assert b['representative_branch']==i
 assert total==F(*last['coefficient'])==F(*old[-1]['coefficient']) and last['peak_rows']==max(b['peak_rows'] for b in bs)==old[-1]['peak_rows']
 unique=sum(not b['algebraic_empty_preparation'] and not b['reused_contraction'] for b in bs);assert unique==first['actual_unique_inputs']==last['actual_unique_inputs']
 summary[word]={'actual_handle':handle,'actual_child_driver_exit':[0,0],'coefficient':last['coefficient'],'peak_rows':last['peak_rows'],'nonempty':sum(not b['algebraic_empty_preparation'] for b in bs),'structural_empty':sum(b['algebraic_empty_preparation'] for b in bs),'actual_unique_inputs':unique,'successful_reuses':sum(b['reused_contraction'] for b in bs),'cold_seconds':last['cold_seconds'],'baseline_seconds':last['baseline_seconds'],'reuse_seconds':last['reuse_seconds'],'whole225_baseline_reuse_comparison_emission_seconds':last['whole225_baseline_and_reuse_warm_seconds'],'parent_seconds':e['parent_seconds']}
 data[word]=bs;hashes.update({str(p):h(p) for p in files})
for i,a in enumerate(data[79]):
 b=data[81][15*(i%15)+i//15]
 for k in ('weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows'):assert a[k]==b[k]
A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');assert all(h(A/n)==v for n,v in pins.items())
for name,field in (('l1-7981-fixed81-r4-transpose-verification.json','original_stream_sha256'),('l1-7981-unrestricted79-r6-failure-verification.json','original_receipt_sha256')):
 v=json.loads((P/name).read_text());assert all(h(Path(n))==v for n,v in v[field].items())
r={'scope':'Author actual r14 fixed equivalence and receipt reduction; independent review/acceptance still required','words':summary,'all450_records_match_original_raw_weight_D_fraction_peak_structural_flags':True,'all225_signed_role_transpose_arithmetic_equalities':True,'branch_map':'15i+j -> 15j+i','source_binding17':bound,'principal16_and_original_fixed_failed_streams_unchanged':True,'output_sha256':hashes,'new_evaluator_sha256':h(P/'l1-7981-evaluator-exact-reuse-r12.py'),'runner_sha256':h(P/'l1-7981-exact-reuse-r12-fixed-equivalence-runner.py'),'driver_sha256':h(P/'l1-7981-exact-reuse-r12-fixed-equivalence-driver.py'),'unrestricted':'NOT RUN','actual_unrestricted_classes_or_speedup':'UNKNOWN','portable_scope':234}
(P/'publication-7981-fixed-r14-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
