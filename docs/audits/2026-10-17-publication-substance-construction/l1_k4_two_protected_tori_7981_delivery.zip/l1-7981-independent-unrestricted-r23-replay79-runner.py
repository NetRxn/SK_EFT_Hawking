"""PREPARED ONLY: fresh independent full79 replay fromzero; separate ROOT admission required."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
import runpy,json,hashlib,signal,time
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
SOURCE=P/'l1-7981-evaluator-exact-reuse-r12.py';EXPECTED='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
BINDING={'l1_direct_b_haar.py': '535d4233a51b89e44f8b9d9b8d01ed624b659d68f1ee9e10ec14efea060900b1', 'l1_extended_four_face_gauge_join.py': '4ddfbc8731cc8c8f546b4347c28718fc3917e131d3a5f461fef19f67122ec91b', 'l1_extended_mixed_center_gamma.py': 'a3dcaffb79e59a174b3a2816d207d8ced22e2bd11a9e05b8c9ea07a20d9c158d', 'l1_extended_mixed_curvature_core.py': '24f640e140b8ab179779f8fc9f5029c2484d834a8f79d5f134991822d2010242', 'l1_extended_mixed_frame_moment.py': '3d1e8d1e1281e6a27223224cf0cbb7dc0545e9c7c035951a0adabd97d9cf3137', 'l1_extended_offset_square.py': '32373f84a267f266e29dea45fa4fe4dc49823be288f1e37dc168dabf06c1793d', 'l1_extended_offset_witness.py': 'e558b5a3211ee2ff62bd4f9d8b06c762ba26d3e041eb8a70280fee7464a4dd0f', 'l1_extended_offset_witness_k2.py': '1d10dc5705e89e8d16cc9e6991b7547b2d8b67bb52e257505aa04259c85455d7', 'l1_extended_offset_witness_k3.py': 'fa1ef180c87707c6e9a4a13410890b77b04c3620774587a81d00dd9b34e2c73d', 'l1_extended_offset_witness_k4.py': 'b2b6027c9a3f13dab49b9c72efd09ecc9dbf1e6bf3ab9903fdb008ac79fd12e0', 'l1_extended_offset_witness_k4_free_torus.py': 'ba82ce5abdcc35dc0e4d98fe52fef1f275837f7063074babfb2cd95c0ab24109', 'l1_extended_offset_witness_k4_peeled.py': '7eb0114dec24a2cc0674c2e3e3865ffc34d12924f131868d95ad121c62d31a4c', 'l1_extended_offset_witness_k4_single_square.py': '4fd18a9a852ce9c1d331f9462f4436d7d8d41f6cd10f408e0dfa2c3aca2729dd', 'l1_extended_offset_witness_k4_two_square.py': '1bd858308e4ba5be3d9d25ce1b0d0a8695600b7b030e45e765d923c60610e78b', 'l1_extended_opposed_source.py': '06e16f2f83062b1b123bf2a6ce7150522114a43c2af06fb117e73823a6bc42f5', 'l1_extended_two_mixed_centers.py': '6f950654cc6e2650246dcb55623040f22e5a3bda7a5ce74c4ab7f0eaf9f628b2'}
REFERENCE=P/'l1-7981-exact-reuse-unrestricted79-r16.out';REFERENCE_SHA256='ba80ef752c93ff9c9914d5d695ac7ed9f4d8b3603d3c5ae4d9e56d83b62c2c7a'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bound():
 assert sha(SOURCE)==EXPECTED and all(sha(A/n)==h for n,h in BINDING.items()) and sha(REFERENCE)==REFERENCE_SHA256
def emit(kind,**values):print(json.dumps(dict(kind=kind,**values),sort_keys=True),flush=True)
def protected(linked,other):
 yield F(1,256),dict.fromkeys(linked+other,tuple((i,i) for i in range(6)))
 for c in (0,3):
  ds=tuple((i,i) for i in range(c,c+3));yield F(-1,559872),dict.fromkeys(linked+other,ds)
  for pair in combinations_with_replacement(range(c,c+3),2):yield F(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:ds,other[1]:ds}
start=time.perf_counter();signal.alarm(600);bound()
# Prior raws are comparison assertions only: never passed to prepare, freeze or kernel/cache.
reference_records=[json.loads(line) for line in REFERENCE.read_text().splitlines()];reference=[r for r in reference_records if r['kind']=='exact-branch'];reference_final=reference_records[-1]
assert len(reference)==225 and reference_final['kind']=='exact-word' and reference_final['word']==79
weights=[w*v for w,c in protected((0,4),(8,12)) for v,d in protected((1,5),(9,13))];assert len(weights)==225 and sum(w<0 for w in weights)==52
s=runpy.run_path(str(SOURCE),run_name='independent_full79_replay');assert s['source_hashes']()=={**BINDING,'evaluator':EXPECTED}
row,g=s['data']()[79];D=g.divisor;assert D==192**42*4**64*48**6*2**15 and s['k2'].ROW_CAP==120000 and s['k2'].PAIR_CAP==3000000
prepared=s['prepare_branches'](g);assert len(prepared)==225
assert [w for w,p in prepared]==weights
frozen=s['freeze_prepared'](prepared,D);assert frozen.branches==225
cold=time.perf_counter()-start
emit('independent-replay-cold',word=79,restrictions={},branches=225,actual_unique_inputs=frozen.unique_inputs,seconds=cold,source_sha256=s['source_hashes'](),reference_sha256=REFERENCE_SHA256)
records=[];weighted=F();weighted_raw=F();peak=0;representatives=0;reuse=0
fields=('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows')
def compare_and_emit(record):
 global weighted,weighted_raw,peak,representatives,reuse
 i=len(records);assert i<225 and record['branch']==i and all(record[k]==reference[i][k] for k in fields)
 assert F(*record['weight'])==weights[i] and record['divisor']==D and F(*record['coefficient'])==F(record['raw_numerator'],D)
 rep=record['representative_branch']
 if record['algebraic_empty_preparation']:assert record['raw_numerator']==record['peak_rows']==0 and rep is None and not record['reused_contraction']
 elif record['reused_contraction']:
  reuse+=1;assert 0<=rep<i and not records[rep]['reused_contraction'] and all(records[rep][k]==record[k] for k in ('raw_numerator','divisor','coefficient','peak_rows'))
 else:representatives+=1;assert rep==i
 weighted+=weights[i]*F(*record['coefficient']);weighted_raw+=weights[i]*record['raw_numerator'];peak=max(peak,record['peak_rows']);records.append(record)
 emit('independent-replay-branch',word=79,**record)
signal.alarm(60);warm=time.perf_counter()
emit('independent-replay-warm-start',word=79,hard_limit_seconds=60,branches=225)
value,actual_peak=s['contract_frozen'](frozen,D,compare_and_emit)
assert len(records)==225 and value==weighted==F(*reference_final['coefficient']) and actual_peak==peak==reference_final['peak_rows']
assert weighted_raw.denominator==1 and weighted_raw.numerator==reference_final['raw_numerator'] and weighted_raw/D==value and representatives==frozen.unique_inputs
bound();final_binding=s['source_hashes']();assert final_binding=={**BINDING,'evaluator':EXPECTED}
warm_seconds=time.perf_counter()-warm;signal.alarm(0)
emit('independent-replay-exact-word',word=79,branches=225,restrictions={},coefficient=[value.numerator,value.denominator],raw_numerator=weighted_raw.numerator,divisor=D,peak_rows=peak,actual_unique_inputs=frozen.unique_inputs,representatives=representatives,reuse=reuse,cold_seconds=cold,whole225warm_seconds=warm_seconds,full_seconds=time.perf_counter()-start,all225_reference_equalities=True,source_sha256=final_binding,reference_sha256=REFERENCE_SHA256)
