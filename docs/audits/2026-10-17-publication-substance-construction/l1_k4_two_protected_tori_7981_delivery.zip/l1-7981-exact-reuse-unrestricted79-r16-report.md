# r16 unrestricted79 exact-reuse runner preparation

Prepared only; no scientific execution. Following completed r14 fixed-only runs, ROOT authorized this scratch preparation. Independent r15 original450/transpose acceptance, separate runner SOURCE review and fresh ROOT execution admission remain prerequisites.

The immutable reviewed r12 evaluator remains SHA256 `2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10`.

- Runner `/tmp/l1-7981-exact-reuse-unrestricted79-r16-runner.py`: `38180221e4b75e90fbe9425b346354cab0b4730264114fea1051d932fed9552c`.
- Driver `/tmp/l1-7981-exact-reuse-unrestricted79-r16-driver.py`: `12e2a0f51310e14d3932f4db0f84ab1f485956179057660bd80bd3271db40aea`.

The runner binds evaluator bytes and16 accepted literal sibling hashes BEFORE scientific import, then requires the actual full17 map after import and after execution. Existing reviewed evaluator context guards fingerprint/callables/caps at all cold/warm/kernel/callback boundaries. It selects only79 with restrict=None, prepares all225 from index0 once, audits each actual nonempty38-factor/32-label/site-degree8 graph and full center/source rows, freezes complete inputs cold, and emits the measured actual unique-input count without assuming154.

One60s WHOLE225 warm interval covers all private thaws, exact-cache lookups, successful representative eliminations, all225 own signed branch records, reduction and binding readback. No contraction occurs cold. Structural None, successful computed zero, cache reuse and raised failure remain distinct. Final `exact-word` is emitted only on complete successful return. Cold600, parent665 and120000row/3000000pair remain unchanged. The exclusive new output prefix is `/tmp/l1-7981-exact-reuse-unrestricted79-r16`; no output streams currently exist. Driver counter uses actual `exact-branch` records.

`*-verification.json` records stdlib syntax/hash/AST controls and actual new warm-block AST exercised with the actual reviewed frozen helper and explicit225 opaque dependency fixtures:225 original-index records, one successful unique elimination, exact hand-derived57 weighted result, correct measured fixture classes and alarms[60,0]. No scientific module was imported or factor table generated. This fixture proves orchestration only, not actual unrestricted classes, coefficient or speed.

Original r6 failed-pilot streams and all six r12 fixed stream hashes remain conserved. The runner never opens old raw outputs or loads the original218 partial values. The new source exact diff from old r6 runner is `*-runner-vs-r6.diff`. All actual unrestricted results, timing and60s feasibility remain UNKNOWN until reviewed and freshly admitted execution; portable234 remains unchanged.
