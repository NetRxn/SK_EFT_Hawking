# Independent unrestricted79 exact-reuse result review r18

**ACCEPT actual complete unrestricted79 pilot arithmetic and receipt within selected-word scope. No correction required.** This is one79 pilot, not79/81 class/portable acceptance. Portable coverage remains234/272.

First candidate continuity check `publication-7981-unrestricted-result-r18.json` exited0, fresh=true, changed=[]. Independent `/tmp/l1-7981-exact-reuse-unrestricted-result-review-r18-check.py` exited0 using stdlib exact Fraction/JSON/archive/hash analysis only. ROOT's intake was not used as acceptance evidence. No scientific import, preparation, moment, contraction/runtime, source/candidate/primary/notebook/Git/controller write occurred.

Actual30139 child/driver exits0, stderr empty, no parent timeout or truncated/nonJSON output. Exactly225 own-index branch records0…224 and one final `exact-word` are present. Source/runner/driver bytes match r17 accepted pins; initial accepted16 source fingerprints plus evaluator form the full17 binding. The reviewed runner's actual post-import/post-run complete-map assertions and helper guards completed successfully. Original600cold/60WHOLE225warm/665parent and120000row/3000000pair caps remain: cold32.4719955s, whole225warm40.6806241s, parent74.0087408s; peak5632.

All22515×15 protected weights and merged core domains were independently regenerated, including52 negative terms. Every original raw numerator/divisor/branch fraction is exact. The225 weighted fractions independently reduce to

`1165710661495982585955 / 35184372088832`,

with `D=192^42*4^64*48^6*2^15`; the weighted raw sum is integral and equals the final reported raw numerator. All225 preparations are nonempty,0 structuralNone;144 raw branch values are successfully computed zeros, not failure fallbacks. Each recorded graph retains38 factors,32 twice-used labels,15 action centers and degree8 at all16 physical sites, both explicit source polynomials and the actual anchor/frame-slot metadata.

The actual cold source reports154 complete frozen input classes. Telemetry independently reconciles154 first successful representatives plus71 later successful reuses: each reuse refers to an earlier first representative and has exactly its raw/D/fraction/peak, while retaining its own original branch index and weight. This is measured actual reviewed-source runtime telemetry, superseding the earlier154 metadata hypothesis. Complete nested factor keys are not emitted, so this receipt checker does not pretend to independently reserialize them from absent full action-row data; exact key equality is covered by accepted source and actual cache logic.

The immutable accepted controls archive SHA256`417bfddde7c86a3e6e5b0ae62dadc442a3cd25488dc6667954a4b791469d4f3e` preserves the ORIGINAL failed r6 attempt. Original old stdout/stderr/exit bytes still match the archive. All218 formerly complete branch records exactly match new raw/weight/D/fraction/peak/structural fields. All225 newly recorded cold core/center/source/row-count support diagnostics and geometry exactly match those from the original failed225 preparation. The prior child-14/driver1,218/225, no exact-word failure remains unchanged; it is not relabeled successful and its raw values were not used as cache inputs.

Recorded unrestricted center/support conservation is not an independent original-L/full-action-row reconstruction. Before crediting79/81 portable coverage, still obtain:

- Complete paired81 unrestricted result and225 transposed raw/weight/D/final/source-action-gamma covariance at79`15i+j`→81`15j+i`.
- Independent unrestricted original-L/full-row controls and independently accepted full79 replay, with exact source/normalization/physical-site conservation.
- Reviewed canonical sibling installation and actual portableCLI evidence, complete original-stream archive and independent class/union acceptance. A scratch evaluator with a candidate fallback is not installed portability evidence.

The minimal substantive next acceptance action is a reviewed, freshly ROOT-admitted bounded complete81 attempt fromindex0 with the same source guards/caps/whole225 limits, followed by independent transpose readback. Independent full-row/original-L and replay preparation can proceed separately within assigned scope. This report authorizes none of those runs. No fullk4/fullensemble/commonZ/physicalB3/modes/transport/main/publication obligation is waived.

Exact originals/new hashes, representative indices, reductions and limitations are in `/tmp/l1-7981-exact-reuse-unrestricted-result-review-r18.json`.

Return continuity check: exit1, fresh=false, changed=[source]. HEAD remains8a7ebf8ee361df8207f848088a94db2ec5bb9021; packet captured clean source, current status adds exactly ROOT-disclosed scripts/source_acquisition_register.py, scripts/validation/checks/citations.py and tests/test_d5_citations.py. All16 scientific sibling bytes were rechecked unchanged after this delta. No packet was refreshed. ROOT must reconcile/reissue this unrelated integration change before consuming the result acceptance.
