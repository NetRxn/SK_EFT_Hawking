from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
from math import prod,comb
import ast,json,hashlib
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rs=[json.loads(l) for l in (P/'l1-7981-unrestricted79-r6.out').read_text().splitlines()];prep=next(r for r in rs if r['kind']=='phase-complete');supports=prep['support_domains'];g=prep['geometry'];centers=supports[0]['prepared_graph']['center_support'];frame={r['center']:r['axes'] for r in centers};edges=defaultdict(list)
for q,axes in sorted(frame.items()):
 for a in axes:
  y=q^(1<<a);edges[min(q,y),max(q,y),a].append((q,a))
assert len(edges)==20;live=tuple(g['live_action_routing']['edge']);fixed={tuple(x['edge']) for x in g['fixed_action_routing']};exclusive={label for edge,labels in edges.items() if len(labels)==1 and edge not in fixed|{live} for label in labels}
sk=('square',0,'component');pk=('square',0,'probe');square=g['squares'][0][0]
factors=[(tuple((q,a) for a in axes)+((sk,) if q==square else ()),None,{}) for q,axes in sorted(frame.items())]
for edge,labels in sorted(edges.items()):
 lo,hi,a=edge;degree=2*len(labels);factors.append((tuple(labels)+((pk,) if edge==live else ()),None,{lo:degree,hi:degree}))
factors.append(((sk,pk),None,{}))
for q,a in g['sources']:factors.append(((),None,{q:2,q^(1<<a):2}))
assert len(factors)==38 and len(Counter(k for ks,r,ds in factors for k in ks))==32
# Execute only actual choose AST on symbolic axes/degrees; coefficient tables are None.
choose=next(n for n in ast.parse((A/'l1_extended_offset_witness_k2.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='choose');ns={'Counter':Counter,'combinations':combinations,'prod':prod,'comb':comb};exec(compile(ast.Module(body=[choose],type_ignores=[]),'<actual-choose-metadata-only>','exec'),ns)
pending=list(enumerate(factors));groups=[]
while pending:
 idx,f=pending.pop();group=[(idx,f)];labels=set(f[0]);sites=set(f[2])
 while neighbors:=[i for i,(idx,f) in enumerate(pending) if labels.intersection(f[0]) or sites.intersection(f[2])]:
  for i in reversed(neighbors):
   idx,f=pending.pop(i);group.append((idx,f));labels.update(f[0]);sites.update(f[2])
 groups.append(group)
plans=[];scans=0
for group in groups:
 work=[f for i,f in group];plan=[]
 while len(work)>1:
  scans+=len(work)*(len(work)-1)//2
  bound,i,j,degrees,opened=ns['choose'](work,exclusive);closed=sum(255<<(8*x) for x,d in degrees.items() if d==8);a,b=work[i][0],work[j][0];shared=set(a)&set(b);out_axes=tuple(k for k in a if k not in shared)+tuple(k for k in b if k not in shared)
  plan.append({'i':i,'j':j,'closed':closed,'axes':out_axes,'opened':opened,'candidate_bound':bound});work[i]=(out_axes,None,opened);work.pop(j)
 assert not work[0][0] and not work[0][2];plans.append(plan)
# Count exact recorded center table signatures and globally identical recorded center-table combinations.
patterns={q:set() for q in frame};global_signatures=set()
for s in supports:
 assert not s['structural_empty_preparation'];ss=s['prepared_graph']['center_support'];global_signatures.add(json.dumps(ss,sort_keys=True))
 for c in ss:patterns[c['center']].add(json.dumps(c['rows'],sort_keys=True))
bs=[r for r in rs if r['kind']=='exact-branch'];nonzero=[b['branch'] for b in bs if b['raw_numerator']];zeros=[b['branch'] for b in bs if not b['raw_numerator']]
result={'scope':'stdlib AST/metadata only; no scientific import/table preparation/contraction/profile','source_hashes':{n:sha(A/n) for n in ('l1_extended_offset_witness_k2.py','l1_extended_offset_witness_k3.py','l1_extended_offset_witness.py','l1_extended_mixed_frame_join.py')},'recorded225_nonempty_preparations':True,'recorded_completed_branches':len(bs),'recorded_nonzero_raw_branches':len(nonzero),'recorded_zero_raw_branches':len(zeros),'missing_branches':list(range(218,225)),'factor_signature_count_in_reconstructed_geometry':1,'factors':38,'connected_component_sizes':[len(x) for x in groups],'full_nonzero_path_join_count':sum(map(len,plans)),'full_nonzero_path_choose_candidate_pair_scans':scans,'225_full_path_upper_bound_scans':225*scans,'per_center_exact_recorded_table_signature_counts':{q:len(s) for q,s in patterns.items()},'global_recorded_center_table_combinations':len(global_signatures),'symbolic_plan':plans,'plan_input_order':[[idx for idx,f in group] for group in groups],'method':'Actual choose AST receives only None-row symbolic factors rebuilt from capturedframe/edge/source incidence, with actual component traversal order and output axes ordering. No indexed_join executed.'}
(P/'l1-7981-contraction-efficiency-r8-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('symbolic_plan','plan_input_order')},indent=2))
component_classes=[defaultdict(list) for group in groups];full_classes=defaultdict(list)
for b,s in enumerate(supports):
 cs={c['center']:c for c in s['prepared_graph']['center_support']};descriptors=[]
 for q,axes in sorted(frame.items()):descriptors.append(('center',q,cs[q]['rows']))
 for edge,labels in sorted(edges.items()):
  domains=[]
  for q,axis in labels:
   slot=frame[q].index(axis);domain=sorted({tuple(r['labels'][slot]) for r in cs[q]['rows']});domains.append(domain)
  descriptors.append(('edge',edge,labels,domains))
 descriptors.extend([('square-static',),('source-static',0),('source-static',1)])
 keys=[]
 for ci,group in enumerate(groups):
  key=json.dumps([descriptors[idx] for idx,f in group],sort_keys=True);component_classes[ci][key].append(b);keys.append(key)
 full_classes[json.dumps(keys)].append(b)
by_index={b['branch']:b for b in bs};pairschecked=0
for members in full_classes.values():
 known=[by_index[i] for i in members if i in by_index]
 if known:
  for b in known[1:]:assert b['raw_numerator']==known[0]['raw_numerator'];pairschecked+=1
result['exact_constructor_component_input_signature_counts']=[len(x) for x in component_classes];result['exact_constructor_full_input_signature_count']=len(full_classes);result['completed_raw_equalities_for_repeated_full_input_signature']=pairschecked;result['potential_complete_component_evaluations']=sum(map(len,component_classes));result['uncached_component_evaluations_no_component_zero_shortcut']=225*len(groups);result['full_input_equivalence_classes']=list(full_classes.values());result['component_input_equivalence_classes']=[list(c.values()) for c in component_classes]
(P/'l1-7981-contraction-efficiency-r8-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('exact_constructor_component_input_signature_counts','exact_constructor_full_input_signature_count','completed_raw_equalities_for_repeated_full_input_signature','potential_complete_component_evaluations','uncached_component_evaluations_no_component_zero_shortcut')}))
