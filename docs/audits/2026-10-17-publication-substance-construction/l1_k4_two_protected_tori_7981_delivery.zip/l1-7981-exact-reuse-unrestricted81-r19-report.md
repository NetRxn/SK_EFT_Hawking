# r19 unrestricted81 preparation and original-L checker pointer

Prepared only, no scientific import/preparation/contraction/profile or81 execution. ROOT reports the separate79 run completed and has independent r18 review underway; neither its coefficient nor class count was used as an81 expectation or runner input.

New runner `/tmp/l1-7981-exact-reuse-unrestricted81-r19-runner.py` SHA256 `24f17e3894a572ffc95ab96bbba052dc6795b175559dd6f64fd70c541ba0edda`.

New driver `/tmp/l1-7981-exact-reuse-unrestricted81-r19-driver.py` SHA256 `b9e973cc5a0c34a0959b2f5c38d8c63937fd89a14bbf24c5980fe7ad87d30bdf`.

The exact source-contract diff is `/tmp/l1-7981-exact-reuse-unrestricted81-r19-vs-r16.diff`. Only hardcoded word, phase/run-name/scope metadata and runner/output hash bindings change from immutable reviewed79 runner/driver. Reversing the precise word/phase substitutions restores the original79 runner AST. Reviewed evaluator2b852f and all16 literal pins remain identical. Initial BEFORE-import pins, complete17 guards, physicalanchor/slot assertions, source-ordered225 branches, unrestricted restrict=None, complete cold preparation/freeze/audit and actual warm exact reuse remain unchanged. Word81 selects its own actual geometry through `data()[81]`; no manually copied79 anchor, core or coefficient is supplied.

The new exclusive output prefix is `/tmp/l1-7981-exact-reuse-unrestricted81-r19`; streams do not exist. Limits remain600cold/ONE60WHOLE225warm/665parent,120000row/3000000pair. All225 own weights/indices/structural-zero/reuse/raw/divisor/fraction records remain emitted and a final result exists only after successful complete return. Actual81 input classes, support, coefficient and timing remain UNKNOWN. Signed role comparison with79 must use15i+j→15j+i after actual81 execution and independent receipt review, never as a substitute for it.

`*-verification.json` records compilation, exact reverse AST comparison, actual new warm-block AST with the actual reviewed frozen helpers and225 explicit stdlib opaque fixtures (225 word81 records, one fixture unique execution, exact hand-derived57 fixture sum, alarms[60,0]), and the actual driver's correct225 `exact-branch` counter. This is orchestration evidence only. No scientific runtime occurred and original79/r16/r12 files or streams were written. Separate SOURCE review and fresh ROOT admission remain required.

## Existing independent full-row reconstruction to extend later

Original checker: `/tmp/l1-7981-independent-fixed-review-r4-control.py`. It was independently source accepted and actually executed via `/tmp/l1-7981-independent-fixed-review-r4-driver.py`, terminal handle54211,9.411054s child/9.487840s parent. Acceptance is `/tmp/l1-7981-independent-fixed-review-r4-execution-r5.md`, with raw `.out/.err/.exit.json` and ROOT intake `/tmp/l1-7981-independent450-root-intake.json`. It reconstructs ALL450 FIXED prepared graphs from originalL, original node cubature for edge polynomials, quaternion-polarized square rows, original identity-frame source polynomials and full signed XOR1 row/key/site/degree/exclusive covariance. It does not contract scalars. Later r15 separately accepts actual fixed scalar/original archive receipt equivalence; its checker is `/tmp/l1-7981-exact-reuse-fixed-independent-r15-check.py`.

A genuine unrestricted extension still owes:

1. Remove the checker's hardcoded `gamma=((0,0),(1,1))` and fixed `restrictions`. Reconstruct every center's full original-L gamma table, with square-component/protected/peeled selectors and actual exclusive-label filtering; compare complete rows with actual unrestricted preparation, not only fixed support or row counts.
2. Build EACH action edge's full Cartesian domain from those reconstructed center rows using its actual frame slot. Preserve all square probes and actual livecenter0/anchor1, singleton fixedcenter1/anchor0 andcenter0/anchor1 routing; compare every full edge polynomial through existing independent original cubature. Reuse the already accepted original quaternion square/source reference functions by bound source, rather than replacing them with optimized evaluator helpers.
3. Check all225 branches for EACH actual word, full38 factors/32 labels twice/all16 degree8, both sources/omitted physical site, exact divisor/weights and structural outcome. No nonempty/class population may be assumed for81. Extend the existing signed full-factor normalize/translated comparison at the225 transpose, including all unrestricted row labels and masks.
4. Pin the reviewed r12 evaluator and accepted16 dependencies before imports and throughout admitted control execution, retain original caps/bounds and raw evidence. This is a separate independently reviewed/prepared/admitted scientific control; no new checker was written and no such execution occurred here.

No fullk4/commonZ/physicalB3/portable/publication acceptance follows.
