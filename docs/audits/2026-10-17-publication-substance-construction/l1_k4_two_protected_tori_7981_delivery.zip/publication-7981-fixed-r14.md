# r14 actual fixed79/81 baseline/reuse equivalence

Both admitted runs completed successfully, sequentially in one scientific CPU lane. Initial packet was fresh; notebook/queue and full r13 source acceptance were read. Executed exact primary venv commands from the candidate checkout: reviewed r12 driver79 (handle89214), then only after terminal success driver81 (handle32967). Child/driver exits0/0, empty stderr, no timeout or truncated output. No source, notebook, Git or controller changes and no unrestricted run occurred.

| Word | Cold seconds | Baseline seconds | Reuse seconds | Whole225 combined warm seconds | Parent seconds |
|---|---:|---:|---:|---:|---:|
|79|6.814431500|0.227561250|0.207046750|0.436610458|7.353565584|
|81|6.703900292|0.218586709|0.206998875|0.427673167|7.229694459|

Each run preserved600cold/ONE60combinedbaseline-and-reuse warm/665parent and120000row/3000000pair caps. All225 branch records per word completed. Each has25 nonempty and200 structural-empty preparations; actual full nonempty input count4, with21 successful cache reuses. Original prepared tables remained unchanged. Both fixed coefficients remain `10367035518435041776795 / 7709672958021817718820298555392`, peak564.

The read-only author reducer `/tmp/publication-7981-fixed-r14-verify.py` and machine result `/tmp/publication-7981-fixed-r14-verification.json` verify all450 actual records against archived ORIGINAL79/81 raw numerators, weights, divisors, fractions, peak and structural flags; exact final sums; successful representative/reuse metadata; all225 role-transpose arithmetic comparisons `15i+j -> 15j+i`; complete17-file runtime bindings; and unchanged16 siblings plus original fixed/failed-pilot stream hashes. This is author evidence, not independent acceptance. ROOT has assigned independent r15 original/transpose review; its acceptance remains the next gate.

New stdout hashes:

-79 `/tmp/l1-7981-exact-reuse-r12-fixed-equivalence-79.out`: `36065be4017e4da58453f3aebe68a791710945a77243b432b17461a941b3ca18`.
-81 `/tmp/l1-7981-exact-reuse-r12-fixed-equivalence-81.out`: `af38c4a9fdaf259c801d121ec7305d12935334e17a3466aef4daaf73706f8371`.

Terminal receipt hashes:

-79 `.exit.json`: `65d58f01c0dd2515c0224dbb60bd6477f59ce5e6c65d28b088ad01ad7365f6f0`.
-81 `.exit.json`: `d9ddd9eafc76841234cee5b12b00e90cbc8a08cf3fcb5e81f6db1b0068bc14c9`.

Both stderr SHA256 values are the empty-file hash. The machine result gives complete paths/hashes. Actual fixed timings do not establish unrestricted classes or speedup. The old unrestricted79 deadline failure remains unchanged; portable234 and all broader scientific/publication obligations remain open.
