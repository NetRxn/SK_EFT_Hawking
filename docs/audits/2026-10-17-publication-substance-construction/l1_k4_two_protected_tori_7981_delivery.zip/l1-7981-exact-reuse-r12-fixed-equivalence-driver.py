"""Prepared only. No execution without separate ROOT admission."""
from pathlib import Path
import sys,json,subprocess,time,hashlib
RUNNER=Path('/tmp/l1-7981-exact-reuse-r12-fixed-equivalence-runner.py');EXPECTED='5f4715c06105a3b42ceca1aaf1e9ecc3ab09ff044a90b1b105dca8b1892faddf'
EXE='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
def main():
 word=int(sys.argv[1]);assert word in (79,81);prefix='/tmp/l1-7981-exact-reuse-r12-fixed-equivalence-'+str(word)
 paths=[Path(prefix+s) for s in ('.out','.err','.exit.json')]
 assert hashlib.sha256(RUNNER.read_bytes()).hexdigest()==EXPECTED
 assert not any(p.exists() for p in paths)
 start=time.perf_counter();timeout=False;command=[EXE,'-B',str(RUNNER),str(word)]
 with paths[0].open('xb') as out,paths[1].open('xb') as err:
  process=subprocess.Popen(command,stdout=out,stderr=err)
  try:code=process.wait(timeout=665)
  except subprocess.TimeoutExpired:timeout=True;process.kill();code=process.wait()
 records=[];bad=0
 for line in paths[0].read_text(errors='replace').splitlines():
  try:records.append(json.loads(line))
  except ValueError:bad+=1
 status=124 if timeout else (0 if code==0 else 1)
 receipt={'actual_child_exit':code,'driver_exit':status,'parent_timeout':timeout,'parent_seconds':time.perf_counter()-start,'word':word,'complete_branch_records':sum(r.get('kind')=='fixed-equivalence-branch' for r in records),'truncated_lines':bad,'runner_sha256':EXPECTED,'limits':{'cold':600,'WHOLE225baseline_and_reuse_warm':60,'parent':665,'row':120000,'pair':3000000},'command':command,'scope':'Fixed baseline equivalence only'}
 paths[2].write_text(json.dumps(receipt,sort_keys=True)+'\n');print(json.dumps(receipt),flush=True);return status
if __name__=='__main__':raise SystemExit(main())
