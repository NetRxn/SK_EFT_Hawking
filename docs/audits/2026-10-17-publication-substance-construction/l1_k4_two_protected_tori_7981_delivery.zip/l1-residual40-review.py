from pathlib import Path
from collections import Counter,defaultdict,namedtuple
from fractions import Fraction as F
from itertools import combinations_with_replacement,product
from types import SimpleNamespace
import ast,json,hashlib,subprocess
P=Path('/tmp');repo=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103');rel='docs/audits/2026-10-17-publication-substance-construction/'
packet=json.loads(Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-l1-residual40-design-review-r1.json').read_text());commit=packet['source']['head'];assert commit=='16fde9b0803019d55d0b10250fed52e6258c1d42'
def blob(file):return subprocess.run(['git','show',commit+':'+rel+file],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
def sha(b):return hashlib.sha256(b).hexdigest()
source=P/'l1-residual40-author-source-r1.py';assert sha(source.read_bytes())=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98'
for path,h in json.loads((P/'l1-residual40-author-evidence-sha256.json').read_text()).items():assert sha(Path(path).read_bytes())==h
binding=json.loads((P/'l1-residual40-author-binding.json').read_text())['principal_source_sha256'];assert len(binding)==16 and all(sha(blob(f))==h for f,h in binding.items())
manifest=next(json.loads(l) for l in blob('l1_k4_census.out.txt').splitlines() if json.loads(l).get('kind')=='paired-k4-census');assert sha(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode())=='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b'
files=['l1_k4_core42_receipts.jsonl','l1_k4_remaining48_receipts.jsonl','l1_k4_peeled86_receipts.jsonl','l1_k4_single_square6_receipts.jsonl','l1_k4_free_torus30_receipts.jsonl','l1_k4_two_square8_receipts.jsonl'];populations={}
for f in files:
 out=[]
 for line in blob(f).splitlines():
  r=json.loads(line);w=r.get('word',r.get('index'));w=w['index'] if isinstance(w,dict) else w
  if w is not None:out.append(w)
 populations[f]=out
for f in ['l1_extended_offset_witness_k4_both_source_square_free_torus.py','l1_extended_offset_witness_k4_two_square_protected_torus.py','l1_extended_offset_witness_k4_two_protected_tori.py','l1_extended_offset_witness_k4_connected_source_square_torus.py']:
 tree=ast.parse(blob(f));populations[f]=list(next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EXPECTED_WORDS' for t in n.targets)))
n=Counter(w for v in populations.values() for w in v);assert len(n)==232 and set(n.values())=={1}
remaining=[r for r in manifest['rows'] if r['index'] not in n];assert len(remaining)==40 and Counter(tuple(r['axes']) for r in remaining)=={(2,2):26,(2,3):14}
def graph(row):
 frame={q:(0,1) for q in range(16) if q!=row['omitted']};frame.update({q:tuple(a) for q,a in row['changes']});sources=((0,row['axes'][0]),(1,row['axes'][1]));edges=defaultdict(list);faces={}
 for q,axes in sorted(frame.items()):
  for a in axes:
   y=q^(1<<a);edges[min(q,y),max(q,y),a].append((q,a))
  a,b=[a for a in range(4) if a not in axes];faces[q,a,b]={(q,a),(q^(1<<a),b),(q^(1<<b),a),(q,b)}
 protected=set(sources)|{(q,a) for l,h,a in edges for q in (l,h)};peeled=[]
 while faces:
  counts=Counter(e for b in faces.values() for e in b);remove=[f for f,b in faces.items() if any(counts[e]==1 and e not in protected for e in b)]
  if not remove:break
  for f in remove:peeled.append(f);del faces[f]
 degrees=Counter()
 for (l,h,a),labels in edges.items():
  for q in (l,h):degrees[q]+=2*len(labels)
 for q,a in sources:degrees[q]+=2;degrees[q^(1<<a)]+=2
 assert degrees==dict.fromkeys(range(16),8)
 return frame,sources,edges,faces,protected,peeled
selected=[];details=[];geometries={}
for r in remaining:
 frame,sources,edges,faces,protected,peeled=graph(r);squares=[f for f,b in faces.items() if b<=protected]
 if len(faces)!=9 or len(squares)!=1:continue
 square=squares[0]
 if not set(sources)<=faces[square]:continue
 others={f:b for f,b in faces.items() if f!=square}
 if any(f[1:]!=(2,3) for f in others):continue
 groups=[{f:b for f,b in others.items() if f[0]&3==c} for c in sorted({f[0]&3 for f in others})]
 if len(groups)!=2 or any(len(t)!=4 for t in groups):continue
 protected_t=[t for t in groups if set.union(*t.values())&protected];free_t=[t for t in groups if not set.union(*t.values())&protected]
 if len(protected_t)!=1 or len(free_t)!=1:continue
 pt,ft=protected_t[0],free_t[0];pb,fb=set.union(*pt.values()),set.union(*ft.values());shared=faces[square]&pb
 if len(shared)!=1 or not shared<=set(sources) or pb&protected!=shared:continue
 selected.append(r['index']);live=square[0],square[1];fixed=faces[square]-{live};shared,=shared
 assert len(edges)==20 and len(peeled)==6 and len(pb)==8 and len(fb)==8
 assert not fb&(pb|faces[square]) and pb&fixed=={shared} and live not in pb|fb and set(sources)<=fixed
 parent={}
 def root(q):
  while q in parent:q=parent[q]
  return q
 for q,a in fixed:
  x,y=root(q),root(q^(1<<a));assert x!=y;parent[x]=y
 fixedkeys={(min(q,q^(1<<a)),max(q,q^(1<<a)),a):int(q>q^(1<<a)) for q,a in fixed}
 l,h=sorted((live[0],live[0]^(1<<live[1])));le=l,h,live[1]
 labels=edges[le];assert labels==[(live[0]^(1<<live[1]),live[1])]
 fixaction={e:ls for e,ls in edges.items() if e in fixedkeys};assert len(fixaction)==1
 assert edges[4,5,0]==([(5,0)] if r['index']==110 else [(4,0)])
 torussites={f[0] for f in pt};freesites={f[0] for f in ft};assert not torussites&freesites and square[0] not in torussites|freesites
 assert labels[0][0] in torussites and edges[4,5,0][0][0] in torussites and r['omitted'] not in frame
 # Symbolic source/action/exterior incidence, including the omitted physical site.
 factors=[(tuple((q,a) for a in axes)+((('square',0,'component'),) if q==square[0] else ()),{}) for q,axes in sorted(frame.items())]
 for e,ks in sorted(edges.items()):
  l,h,a=e;factors.append((tuple(ks)+((('square',0,'probe'),) if e==le else ()),{l:2*len(ks),h:2*len(ks)}))
 factors.append(((('square',0,'component'),('square',0,'probe')),{}))
 for q,a in sources:factors.append(((),{q:2,q^(1<<a):2}))
 lab=Counter(k for ks,d in factors for k in ks);deg={q:sum(d.get(q,0) for ks,d in factors) for q in range(16)}
 assert len(factors)==38 and len(lab)==32 and set(lab.values())=={2} and deg==dict.fromkeys(range(16),8)
 assert r['omitted'] in {q^(1<<a) for q,a in sources} and all((min(q,q^(1<<a)),max(q,q^(1<<a)),a) not in edges for q,a in sources)
 omitted_action_degree=sum(d.get(r['omitted'],0) for ks,d in factors[15:35]);assert omitted_action_degree==6
 details.append({'word':r['index'],'omitted_action_center':r['omitted'],'omitted_site_incoming_action_degree':omitted_action_degree,'omitted_site_source_degree':2,'square':square,'live':live,'fixed_forest':sorted(fixed),'shared_source':shared,'protected_torus':sorted(pt),'free_torus':sorted(ft),'protected_centers':sorted(torussites),'free_centers':sorted(freesites),'live_action':labels,'fixed_action':[(e,l) for e,l in sorted(fixaction.items())],'fixed_anchor':fixedkeys[4,5,0],'E':20,'J':0,'peeled':6,'factor_count':38,'labels':32,'all_site_degrees8':True,'divisor':192**42*4**64*48**6*2**15})
 geometries[r['index']]=(r,graph(r))
assert selected==[110,153]
assert [r['index'] for r in remaining]==json.loads((P/'l1-residual40-author-geometry.json').read_text())['remaining40_roster']
r110=manifest['rows'][110];r153=manifest['rows'][153];assert r110['omitted']^1==r153['omitted'] and sorted((q^1,a) for q,a in r110['changes'])==sorted((q,a) for q,a in r153['changes'])
# Execute only AST-extracted pure geometry/data with stdlib graph stub, not module import.
tree=ast.parse(source.read_text());funcs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)};original={n.name:n for n in ast.parse((P/'l1-next42-author-source-r1.py').read_text()).body if isinstance(n,ast.FunctionDef)}
assert all(ast.dump(funcs[k],include_attributes=False)==ast.dump(original[k],include_attributes=False) for k in ('prepare','contraction'))
geomfields=next(ast.literal_eval(n.value.args[1]) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='Geometry' for t in n.targets))
ns={'Counter':Counter,'namedtuple':namedtuple,'hashlib':hashlib,'json':json,'IDENTITY':((1,0,0,0),(1,0,0,0)),'two':SimpleNamespace(base=graph),'k3':SimpleNamespace(witness=SimpleNamespace(SCALE=192)),'k4':SimpleNamespace(data=lambda:(manifest,{})),'Geometry':namedtuple('Geometry',geomfields)}
for key in ('geometry','data'):exec(compile(ast.Module(body=[funcs[key]],type_ignores=[]),str(source),'exec'),ns)
found=ns['data']();assert list(found)==selected
# Actual new Cartesian branch and solve ASTs tested with exact rational/domain stdlib stubs.
def protected_branches(linked,other):
 bs=linked+other;yield F(1,256),dict.fromkeys(bs,tuple((i,i) for i in range(6)))
 for c in (0,1):
  inds=range(c*3,c*3+3);ds=tuple((i,i) for i in inds);yield F(-1,559872),dict.fromkeys(bs,ds)
  for pair in combinations_with_replacement(inds,2):yield F(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:ds,other[1]:ds}
def free_branches(faces):
 bs=tuple(f[0] for f in faces);yield F(1,256),dict.fromkeys(bs,tuple((i,i) for i in range(6)))
 for c in (0,3):yield F(1,1679616),dict.fromkeys(bs,tuple((i,i) for i in range(c,c+3)))
ns.update(k2=SimpleNamespace(protected_branches=protected_branches,free_branches=free_branches),product=product,Fraction=F)
exec(compile(ast.Module(body=[funcs['branches']],type_ignores=[]),str(source),'exec'),ns)
branchproof=[]
for word,(r,g) in found.items():
 got=list(ns['branches'](g));want=[(w*fw,core|fc) for w,core in protected_branches(g.linked,g.other) for fw,fc in free_branches(g.free_tori[0])]
 assert len(got)==45 and got==want and all(len(d)==8 for w,d in got)
 branchproof.append({'word':word,'terms':45,'negative_terms':sum(w<0 for w,d in got),'eight_center_domains':True,'index_map':'3i+j -> 3i+j','all_weights_exact_fractions':all(isinstance(w,F) for w,d in got)})
 # Stub contraction proves solve visits each exact branch once and passes same restriction; no kernels.
 calls=[];restriction=object()
 def contraction(gg,core,rr):
  assert gg is g and rr is restriction and core==got[len(calls)][1];calls.append(core);return F(len(calls),7),len(calls)
 ns['contraction']=contraction;exec(compile(ast.Module(body=[funcs['solve']],type_ignores=[]),str(source),'exec'),ns)
 value,peak=ns['solve'](g,restriction);assert len(calls)==45 and peak==45 and value==sum((w*F(i+1,7) for i,(w,d) in enumerate(got)),F())
# Syntax failure was a draft assembly error; preserve exactly, do not reclassify as science.
failed=P/'l1-residual40-author-source-attempt1.py'
try:ast.parse(failed.read_text())
except SyntaxError:syntax_failure=True
else:raise AssertionError('reported invalid source parses')
result={'verdict':'ACCEPT scientific source/design only; direct/fixed execution remains unrun and requires ROOT authorization','pinned_immutable_source_commit':commit,'source_sha256':sha(source.read_bytes()),'principal16_hashes_match_immutable_git_blobs':True,'all_author_captured_evidence_hashes_match':True,'accepted_disjoint_union':232,'remaining40':[r['index'] for r in remaining],'remaining_same':26,'remaining_mixed':14,'unique_structural_family':selected,'geometry':details,'actual_geometry_data_AST_checked_using_stdlib_graph_stub':True,'prepare_contraction_AST_equal_accepted_d524':True,'branch_products':branchproof,'all45_solve_calls_checked_with_inert_stub':True,'XOR1_geometry_and_role_preserving_branch_order':True,'source_assembly_SyntaxError_preserved':syntax_failure,'no_scientific_import_or_preparation_or_controls_or_coefficients':True,'portable_scope':232,'new_coefficients':'110/153 and38other residual coefficients all owed','full_k4_sourceaction_commonZ_physicalB3_modes_transport':'OPEN'}
(P/'l1-residual40-review-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
