from pathlib import Path
import json,hashlib,ast
P=Path('/tmp');pins=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text())['principal_source_sha256'];pre='l1-7981-portable-cli-r31'
r='''"""Prepared actual installed CLI budget wrapper. Separate SOURCE review/admission required."""
from pathlib import Path
import sys,runpy,signal,time,json,hashlib
AUDIT=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction').resolve()
SCRIPT=AUDIT/'l1_extended_offset_witness_k4_source_sharing_square_two_protected_tori.py'
EXPECTED='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
MANIFEST='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b'
BINDING=%r

def emit(kind,**values):print(json.dumps(dict(kind=kind,**values),sort_keys=True),flush=True)
def _pin_installed():
 assert SCRIPT.is_file() and SCRIPT.resolve().parent==AUDIT
 assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest()==EXPECTED
 assert len(BINDING)==16
 for name,expected in BINDING.items():
  path=AUDIT/name
  assert path.resolve().parent==AUDIT and hashlib.sha256(path.read_bytes()).hexdigest()==expected
 manifest=next(json.loads(line) for line in (AUDIT/'l1_k4_census.out.txt').read_text().splitlines() if json.loads(line).get('kind')=='paired-k4-census')
 assert hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()==MANIFEST
 assert (AUDIT/'l1_extended_offset_witness_k3.py').is_file()
 return {'script':str(SCRIPT),'AUDIT':str(AUDIT),'source_sha256':{**BINDING,'evaluator':EXPECTED},'manifest_sha256':MANIFEST}
def _runtime_proof(namespace):
 proof=_pin_installed()
 assert namespace['__name__']=='__main__' and Path(namespace['__file__']).resolve()==SCRIPT
 assert namespace['AUDIT'].resolve()==AUDIT
 assert namespace['EXPECTED_MANIFEST_SHA256']==MANIFEST
 assert namespace['source_hashes']()=={**BINDING,'evaluator':EXPECTED}
 for name in BINDING:
  assert Path(sys.modules[name[:-3]].__file__).resolve().parent==AUDIT
 return proof

def main():
 mode=sys.argv[1];assert mode in ('census','fixed','79','81')
 full=mode in ('79','81');limit=600 if full else (30 if mode=='census' else 60)
 signal.alarm(limit);start=time.perf_counter();binding=_pin_installed()
 assert all(name[:-3] not in sys.modules for name in BINDING)
 args=[] if mode=='census' else ['--controls-only'] if mode=='fixed' else ['--word',mode]
 native_argv=[str(SCRIPT),*args];prior=sys.argv;state={'entries':0,'proof':None}
 emit('portable-cli-wrapper-start',mode=mode,native_argv=native_argv,initial_alarm_seconds=limit,**binding)
 def entry_budget(frame,event,arg):
  if event!='call' or frame.f_code.co_name!='contract_frozen' or frame.f_code.co_filename!=str(SCRIPT):return
  assert frame.f_globals['__name__']=='__main__' and state['entries']==0
  state['entries']+=1;sys.setprofile(None);signal.alarm(60)
  state['proof']=_runtime_proof(frame.f_globals)
 if full:sys.setprofile(entry_budget)
 try:
  sys.argv=native_argv
  namespace=runpy.run_path(str(SCRIPT),run_name='__main__')
  assert state['entries']==(1 if full else 0)
  proof=_runtime_proof(namespace)
  emit('portable-cli-wrapper-complete',mode=mode,native_argv=native_argv,warm_entry_hooks=state['entries'],actual_seconds=time.perf_counter()-start,**proof)
  signal.alarm(0)
 finally:
  sys.setprofile(None);sys.argv=prior
if __name__=='__main__':main()
'''%pins
runner=P/(pre+'-runner.py');runner.write_text(r);compile(r,str(runner),'exec');rh=hashlib.sha256(runner.read_bytes()).hexdigest()
d='''"""Prepared only: ROOT separately admits one actual installed CLI mode per process."""
from pathlib import Path
import sys,subprocess,time,json,hashlib
RUNNER=Path('/tmp/l1-7981-portable-cli-r31-runner.py');RUNNER_SHA256=%r
EXE='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
SOURCE_SHA256='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
def _validate(records,mode):
 assert records[0]['kind']=='portable-cli-wrapper-start' and records[-1]['kind']=='portable-cli-wrapper-complete'
 assert records[-1]['warm_entry_hooks']==(1 if mode in ('79','81') else 0)
 native=[r for r in records if not r['kind'].startswith('portable-cli-wrapper-')]
 summaries=[r for r in native if r['kind'] in ('source-sharing-square-two-protected-tori-census','fixed-label','exact-word')]
 for r in summaries:
  assert r['source_sha256']==records[-1]['source_sha256'] and r['source_sha256']['evaluator']==SOURCE_SHA256
  assert r['manifest_sha256']=='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b' and r['row_cap']==120000 and r['pair_cap']==3000000
 if mode=='census':
  assert len(native)==1 and summaries[0]['valid_words']==[79,81] and [x['word']['index'] for x in summaries[0]['entries']]==[79,81]
 elif mode=='fixed':
  branches=[r for r in native if r['kind']=='exact-fixed-branch'];assert len(branches)==450 and [r['word'] for r in summaries]==[79,81]
  for word in (79,81):assert [r['branch'] for r in branches if r['word']==word]==list(range(225))
  assert all(r['branches']==225 and r['coefficient']==[10367035518435041776795,7709672958021817718820298555392] for r in summaries)
 else:
  branches=[r for r in native if r['kind']=='exact-branch'];assert len(branches)==225 and [r['branch'] for r in branches]==list(range(225)) and all(r['word']==int(mode) for r in branches)
  assert len(summaries)==1;last=summaries[0]
  assert last['word']['index']==int(mode) and last['branches']==225 and last['coefficient']==[1165710661495982585955,35184372088832] and last['preparation_seconds']<600 and last['whole225_warm_seconds']<60
 return len(native),sum(r['kind']=='exact-branch' for r in native),sum(r['kind']=='exact-fixed-branch' for r in native)
def main():
 mode=sys.argv[1];assert mode in ('census','fixed','79','81');limit=665 if mode in ('79','81') else (30 if mode=='census' else 60)
 prefix='/tmp/l1-7981-portable-cli-r31-'+mode;out=Path(prefix+'.out');err=Path(prefix+'.err');end=Path(prefix+'.exit.json')
 assert hashlib.sha256(RUNNER.read_bytes()).hexdigest()==RUNNER_SHA256
 assert not any(p.exists() for p in (out,err,end))
 command=[EXE,'-B',str(RUNNER),mode];start=time.perf_counter();timeout=False
 with out.open('xb') as stdout,err.open('xb') as stderr:
  process=subprocess.Popen(command,stdout=stdout,stderr=stderr)
  try:code=process.wait(timeout=limit);reason='terminal'
  except subprocess.TimeoutExpired:timeout=True;process.kill();code=process.wait();reason='whole process timeout'
 status=124 if timeout else (0 if code==0 else 1);records=[];invalid=0;counts=(0,0,0)
 for line in out.read_text(errors='replace').splitlines():
  try:records.append(json.loads(line))
  except ValueError:invalid+=1
 counts=(sum(not r.get('kind','').startswith('portable-cli-wrapper-') for r in records),sum(r.get('kind')=='exact-branch' for r in records),sum(r.get('kind')=='exact-fixed-branch' for r in records))
 if code==0 and not timeout:
  try:assert invalid==0;_validate(records,mode)
  except (AssertionError,KeyError,TypeError,IndexError) as error:status=1;reason='terminal output validation failed: '+repr(error)
 receipt={'actual_child_exit':code,'driver_exit':status,'parent_timeout':timeout,'reason':reason,'mode':mode,'actual_parent_wall_seconds':time.perf_counter()-start,'whole_process_limit_seconds':limit,'full_word_phase_limits':{'cold':600,'WHOLE225warm':60,'parent':665} if mode in ('79','81') else None,'command':command,'runner_sha256':RUNNER_SHA256,'source_sha256':SOURCE_SHA256,'native_record_count':counts[0],'complete_unrestricted_branch_records':counts[1],'complete_fixed_branch_records':counts[2],'invalid_lines':invalid,'last_complete_record':records[-1]['kind'] if records else None}
 end.write_text(json.dumps(receipt,sort_keys=True)+'\\n');print(json.dumps(receipt),flush=True);return status
if __name__=='__main__':raise SystemExit(main())
'''%rh
driver=P/(pre+'-driver.py');driver.write_text(d);compile(d,str(driver),'exec');print('runner',rh);print('driver',hashlib.sha256(driver.read_bytes()).hexdigest())
