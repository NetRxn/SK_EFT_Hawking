# r24 scratch portable delivery preparation

Prepared only. Initial continuity packet checked fresh; ROOT subsequently disclosed producer-only checkpoint5b9323a1d, so the old packet is expected stale at return. No candidate/primary/notebook/Git/controller write, scientific import, preparation, contraction, profile or portable runtime occurred. Full450 unrestricted original-L/full-row checks, fresh independent79 replay, actual portable CLI/controls, archive and independent delivery acceptance remain owed. Current portable acceptance stays234/272.

## Exact portable source and patch

Postimage:
`/tmp/l1-7981-portable-preparation-r24-postimages/l1_extended_offset_witness_k4_source_sharing_square_two_protected_tori.py`.

It is BYTE-IDENTICAL to reviewed r12, SHA256 `2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10`. No scientific or CLI AST edits were needed. The actual source starts with its own resolved sibling AUDIT directory and takes the scratch absolute fallback only if canonical sibling k3 is absent. A stdlib fixture executed those actual AUDIT assignments/conditional in a relocated directory containing its k3 sibling and selected the relocated directory. Source import/path guards and accepted16 pins remain unchanged. This is source portability evidence, not an actual import or CLI run.

The install proposal `/tmp/l1-7981-portable-preparation-r24.patch` adds only the exact new requested repository path; SHA256 `86b28aace818aada5878207ff7b1d55cfca02418f03d9c465199dd7d17adf9b0`. It is not installed. Existing DIFFERENT four-word `l1_extended_offset_witness_k4_two_protected_tori.py` remains byte-unchanged at `6d8e93102b87f98ddea6e9fc1fe519245c6b9d993a78a783bb6161d1da5700eb`.

## Existing accepted class-union mechanism, not normalization coverage

The requested `l1_normalization_coverage.py` actually partitions6451 normalization transport multisets through `sector(parts)`; it has no selected-k4 registry or234 count. ROOT agreed to preserve it entirely. Its unchanged SHA256 is `966b785325d3cb41279193c232acaa6fce514687ac2b6d50e61d14f06da3f0c4`. No coverage-module postimage or replacement index is proposed.

The existing selected-k4 union is the scientific receipt mechanism in the accepted110/153 design/archives/interface:

- `/tmp/l1-residual40-review.py` reconstructs the original232 disjoint union by reading six existing JSONL receipt populations and actual `EXPECTED_WORDS` ASTs from four accepted family evaluators, against the immutable272 manifest.
- Accepted `l1_k4_shared_square_protected_free2_design_verification.json`, preserved also as `l1-residual40-review-verification.json` inside its94-member original archive, proves that232 union and identifies110/153 disjointly in its remaining40.
- `l1_k4_shared_square_protected_free2_verification.json` accepts the110/153 scientific class and replay while retaining232 until portable/archive acceptance. The final archive/composition verification and `L1_RETARDED_SPECTRAL_INTERFACE.md` then record accepted234/272 after those separate gates. No production coverage counter/module performs that promotion.

The new scratch class-union proposal reuses exactly this method: the same six receipt populations, the same four earlier evaluator AST populations, plus the actually accepted110/153 evaluator AST. It independently reproduces234 unique single-covered indices,140 same-axis/94 mixed-axis, on manifest digest `ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b`. Actual79/81 are disjoint and same-axis. A CONDITIONAL union, only if all remaining gates pass, would have236 entries,142 same/94 mixed,36 remaining (22same/14mixed). This is set arithmetic, not accepted coverage.161/163 remain among the uncomputed coupled-holonomy obligations.

Artifact `/tmp/l1-7981-portable-preparation-r24-class-union-proposal.json` explicitly retains current234 and labels236 conditional, with the complete existing class population sources and remaining indices; SHA256 `53adf4259c26f18edb6875b1e8528791378bf079c61a85ec004a927cf3fdff6c`. It is a scratch scientific verification proposal, not a new runtime index or installed acceptance record.

## Receipt and archive delivery shape

`/tmp/l1-7981-portable-preparation-r24-receipt-shape-proposal.json`, SHA256 `7b670f5ff94dbd5a654f60047f7c93f36da8916684d014ce0cdab7929a9b262d`, follows the accepted previous per-class verification layout: words, original raw/weight/divisor/coefficient/phase/parent/source/runner/driver bindings; independent replay; class/disjointness/subtotal and explicit pending portable scope. It is deliberately marked PROPOSED with unpopulated proof fields, and must not be installed or described as a verified receipt. The known paired coefficient is source-qualified to ROOT's r22 intake, not recomputed here. Its doubled same-axis subtotal uses exact Fraction arithmetic without extra shear or axis factors.

Use the existing per-class original-evidence ZIP plus manifest/independent archive-reader mechanism. Preserve every original source, driver, stdout/stderr/exit, failed original218/225 attempt, r10 rejected source/test evidence, r11 rejection, r12 correction, controls and subsequent successful runs/reviews. Do not rewrite the old failure or overwrite any original streams. A final archive acceptance must prove unique roster, CRC, byte count, SHA256 and equality to named original bytes, while canonical review copies remain exact accepted originals. The existing94-file110/153 archive and separate final-reader corrective archive are precedents for preserving evidence/checker mistakes independently, not a reason to copy their accepted status or hardcode this new archive's member count.

Future actual portable testing must use ROOT's separately reviewed bounded driver/admission. The copied evaluator main has the existing CLI semantics and reports phase durations; the existing admitted per-word scientific wrappers own hard600/60WHOLE225/665 enforcement. No new outer CLI timer mechanism was invented here, and no actual portable phase/whole-process result is claimed. Independent review must specify the intended existing CLI wrapper and actual budget before execution.

## Performed checks and remaining gates

`/tmp/l1-7981-portable-preparation-r24-build.py` uses only stdlib bytes/AST/JSON/Fraction/set operations. It compiled the exact source postimage, verified byte identity and all16 accepted sibling hashes, exercised actual AUDIT-first AST with an existence fixture, reconstructed the existing accepted234 receipt union and conditional disjoint addition, and wrote only r24 scratch postimages/patch/proposals. Machine evidence is `/tmp/l1-7981-portable-preparation-r24-verification.json`. Neither a scientific module nor a scientific CLI was executed.

Before ROOT installs/promotes anything: independent source/portable proposal review; complete unrestricted450 original-L/full-row and signed covariance acceptance; fresh independent complete79 replay; actual installed or independently isolated sibling-directory census/fixed/full CLI evidence; actual class union from canonical receipts; complete original-evidence archive and independent reader; final source/archive/interface composition review. Only then may ROOT change the existing interface/queue accepted count from234. Fullk4/commonZ/physicalB3/window/microscopic/transport/main/publication remain open.
