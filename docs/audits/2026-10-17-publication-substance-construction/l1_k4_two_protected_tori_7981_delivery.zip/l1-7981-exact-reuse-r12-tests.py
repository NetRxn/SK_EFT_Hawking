"""Real helper AST tests; only the forbidden scientific elimination dependency is replaced.
Breaks caught: duplicate reexecution, incomplete keys, stale nested aliases, context drift,
zero/error conflation, cross-attempt leakage, omitted records and changed weighted arithmetic.
"""
from pathlib import Path
from fractions import Fraction
from collections import namedtuple
from copy import deepcopy
import ast,types,unittest,sys,io,json
from contextlib import redirect_stdout
BASELINE='--baseline' in sys.argv
R10='--r10' in sys.argv
P=Path('/tmp');SOURCE=P/('l1-7981-evaluator-exact-reuse-r10.py' if R10 else 'l1-7981-evaluator-exact-reuse-r12.py');BASE=P/'l1-7981-evaluator-draft-r1.py'

def namespace(baseline=False):
 path=BASE if baseline else SOURCE
 names={'contract_prepared'} if baseline else {'EXPECTED_SIBLING_SHA256','FrozenPrepared','_reuse_context','_freeze_label','freeze_prepared','contract_frozen'}
 nodes=[n for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.Assign)) and ((isinstance(n,ast.FunctionDef) and n.name in names) or (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in n.targets)))]
 seen=[]
 def kernel(factors,exclusive):
  seen.append((deepcopy(factors),set(exclusive)))
  # This exact fixture dependency distinguishes key changes in real/imaginary coefficients.
  raw=sum(r+3*i for axes,rows,degrees in factors for poly in rows.values() for r,i in poly.values())
  return raw,9
 k2=types.SimpleNamespace(ROW_CAP=120000,PAIR_CAP=3000000,eliminate=object(),choose=object(),indexed_join=object(),preceding_parity=object())
 fingerprint={**json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text())['principal_source_sha256'],'evaluator':'e'*64}
 ns={'Fraction':Fraction,'namedtuple':namedtuple,'k3':types.SimpleNamespace(eliminate_components=kernel),'k2':k2,'source_hashes':lambda:dict(fingerprint),'test_fingerprint':fingerprint}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path)+'-AST','exec'),ns)
 if baseline:ns['freeze_prepared']=lambda p,d:p;ns['contract_frozen']=ns['contract_prepared']
 ns['seen']=seen;return ns

def graph(real=6,imag=0):return ([(((0,0),),{((0,0),):{1:(real,imag)}},{0:2})],12,{(0,0)})
def batch(g=None):return [(Fraction(2 if i%2==0 else -1),deepcopy(g if g is not None else graph())) for i in range(225)]

class ReuseTests(unittest.TestCase):
 def test_distinct_equal_graphs_execute_once_keep225_weights_and_peak(self):
  n=namespace(BASELINE);p=batch();before=deepcopy(p);records=[];f=n['freeze_prepared'](p,12);value,peak=n['contract_frozen'](f,12,records.append)
  self.assertEqual((value,peak),(Fraction(57),9));self.assertEqual(len(records),225);self.assertEqual(p,before)
  self.assertEqual(len(n['seen']),1,'Equal complete inputs must execute one successful contraction, not225')
  self.assertEqual([r['branch'] for r in records],list(range(225)));self.assertEqual(sum(r['reused_contraction'] for r in records),224)
 def test_every_key_dimension_change_is_distinct(self):
  # Missing any of these dimensions would let an incompatible mathematical input hit the cache.
  mutators={
   'real':lambda p:p[0][0][1][((0,0),)].update({1:(7,0)}),
   'imaginary_sign':lambda p:p[0][0][1][((0,0),)].update({1:(6,-1)}),
   'mask':lambda p:p[0][0][1].update({((0,0),):{2:(6,0)}}),
   'row_label':lambda p:p[0][0][1].update({((1,1),):p[0][0][1].pop(((0,0),))}),
   'axis':lambda p:p[0].__setitem__(0,(((1,1),),p[0][0][1],p[0][0][2])),
   'degree':lambda p:p[0][0][2].update({0:4}),
   'exclusive':lambda p:p[2].add((1,1)),
   'row_order':lambda p:p[0][0][1].update({((1,1),):{2:(1,0)}}),
  }
  for name,mutate in mutators.items():
   with self.subTest(name=name):
    n=namespace();p=batch();alt=deepcopy(p[1][1]);mutate(alt);p[1]=(p[1][0],alt);n['contract_frozen'](n['freeze_prepared'](p,12),12);self.assertEqual(len(n['seen']),2)
 def test_factor_axis_poly_and_degree_iteration_order_preserved(self):
  n=namespace();g=([(((2,0),(0,0)),{((2,2),(0,0)):{4:(2,0),1:(4,0)},((1,1),(0,0)):{8:(0,-1)}},{2:2,0:4}),((),{():{16:(1,0)}},{1:2})],12,{(2,0)})
  n['contract_frozen'](n['freeze_prepared'](batch(g),12),12);self.assertEqual(n['seen'][0][0],g[0])
  self.assertEqual(list(n['seen'][0][0][0][1]),list(g[0][0][1]));self.assertEqual(list(n['seen'][0][0][0][2]),[2,0]);self.assertEqual(list(next(iter(n['seen'][0][0][0][1].values()))),[4,1])
 def test_postfreeze_and_emitter_mutation_cannot_change_frozen_inputs(self):
  n=namespace();p=batch();f=n['freeze_prepared'](p,12);p[0][1][0][0][1][((0,0),)][1]=(1000,0)
  def emit(r):
   p[-1][1][0][0][1].clear();r['weight'][0]=999;r['coefficient'][0]=999
  self.assertEqual(n['contract_frozen'](f,12,emit),(Fraction(57),9));self.assertEqual(len(n['seen']),1)
 def test_private_materialization_prevents_dependency_mutating_originals(self):
  n=namespace();p=batch();before=deepcopy(p)
  def destructive(f,e):f[0][1].clear();f[0][2].clear();f.pop();e.clear();return 6,9
  n['k3'].eliminate_components=destructive;f=n['freeze_prepared'](p,12);self.assertEqual(n['contract_frozen'](f,12),(Fraction(57),9));self.assertEqual(p,before)
 def test_caps_and_kernel_context_drift_refused_on_cache_hit_and_after_callback(self):
  for field in ('ROW_CAP','PAIR_CAP','eliminate','choose','indexed_join','preceding_parity','kernel'):
   with self.subTest(field=field):
    n=namespace();f=n['freeze_prepared'](batch(),12)
    def emit(r):
     if field=='kernel':n['k3'].eliminate_components=lambda f,e:(99,99)
     else:setattr(n['k2'],field,object() if field not in ('ROW_CAP','PAIR_CAP') else 1)
    with self.assertRaises(AssertionError):n['contract_frozen'](f,12,emit)
    self.assertEqual(len(n['seen']),1)
  n=namespace();f=n['freeze_prepared'](batch(),12);n['k2'].ROW_CAP=1
  with self.assertRaises(AssertionError):n['contract_frozen'](f,12)
  self.assertEqual(n['seen'],[])
 def test_local_divisor_mismatch_refused_even_if_graph_would_hit(self):
  n=namespace();p=batch();bad=p[1][1];p[1]=(p[1][0],(bad[0],13,bad[2]))
  with self.assertRaises(AssertionError):n['freeze_prepared'](p,12)
  f=n['freeze_prepared'](batch(),12)
  with self.assertRaises(AssertionError):n['contract_frozen'](f,13)
 def test_zero_none_are_distinct_and_zero_peak_cached(self):
  n=namespace();p=[(Fraction(1),deepcopy(graph(0))) if i%2==0 else (Fraction(-2),None) for i in range(225)];records=[]
  self.assertEqual(n['contract_frozen'](n['freeze_prepared'](p,12),12,records.append),(Fraction(0),9));self.assertEqual(len(n['seen']),1)
  self.assertTrue(records[1]['algebraic_empty_preparation']);self.assertFalse(records[0]['algebraic_empty_preparation']);self.assertEqual(records[0]['peak_rows'],9);self.assertEqual(records[1]['peak_rows'],0)
 def test_exception_propagates_and_success_cache_does_not_cross_attempts(self):
  n=namespace();count=[]
  def fails(f,e):count.append(1);raise RuntimeError('cap exceeded')
  n['k3'].eliminate_components=fails;f=n['freeze_prepared'](batch(),12)
  for attempt in range(2):
   with self.assertRaisesRegex(RuntimeError,'cap exceeded'):n['contract_frozen'](f,12)
  self.assertEqual(len(count),2)
  n=namespace();f=n['freeze_prepared'](batch(),12);n['contract_frozen'](f,12);n['contract_frozen'](f,12);self.assertEqual(len(n['seen']),2)
 def test_hash_collision_uses_exact_descriptor_equality(self):
  n=namespace();p=batch();p[1]=(p[1][0],graph(6+sys.hash_info.modulus));f=n['freeze_prepared'](p,12);self.assertEqual(hash(f.entries[0][1]),hash(f.entries[1][1]));self.assertNotEqual(f.entries[0][1],f.entries[1][1]);n['contract_frozen'](f,12);self.assertEqual(len(n['seen']),2)
 def test_actual_baseline_arithmetic_records_equal_new_helper_with_mixed_inputs(self):
  old=namespace(True);new=namespace();p=batch();p[5]=(Fraction(-3,2),None);p[8]=(Fraction(7,3),graph(0));p[9]=(Fraction(-5,7),graph(3,-1));before=deepcopy(p);a=[];b=[]
  expected=old['contract_frozen'](p,12,a.append);actual=new['contract_frozen'](new['freeze_prepared'](p,12),12,b.append)
  self.assertEqual(actual,expected);self.assertEqual(p,before);self.assertEqual([{k:v for k,v in r.items() if k not in ('reused_contraction','representative_branch')} for r in b],a)
 def test_same_maps_with_changed_iteration_orders_do_not_share_inputs(self):
  n=namespace();g=([(((0,0),(1,0)),{((0,0),(1,1)):{1:(2,0),2:(4,0)},((1,1),(0,0)):{4:(0,1)}},{0:2,1:4}),((),{():{8:(1,0)}},{2:2})],12,{(0,0)})
  for dimension in ('factors','axes','rows','poly','degrees'):
   with self.subTest(dimension=dimension):
    p=batch(g);alt=deepcopy(g);axes,rows,degs=alt[0][0]
    if dimension=='factors':alt[0].reverse()
    elif dimension=='axes':alt[0][0]=(tuple(reversed(axes)),rows,degs)
    elif dimension=='rows':alt[0][0]=(axes,dict(reversed(list(rows.items()))),degs)
    elif dimension=='poly':rows[next(iter(rows))]=dict(reversed(list(rows[next(iter(rows))].items())))
    else:alt[0][0]=(axes,rows,dict(reversed(list(degs.items()))))
    p[1]=(p[1][0],alt);n=namespace();n['contract_frozen'](n['freeze_prepared'](p,12),12);self.assertEqual(len(n['seen']),2)
 def test_kernel_context_mutation_before_return_refused_not_cached(self):
  n=namespace();seen=[]
  def kernel(f,e):seen.append(1);n['k2'].PAIR_CAP=1;return 6,9
  n['k3'].eliminate_components=kernel;f=n['freeze_prepared'](batch(),12)
  with self.assertRaises(AssertionError):n['contract_frozen'](f,12)
  self.assertEqual(len(seen),1)
 def test_actual_main_uses_frozen_paths_and_emits_all225_branch_records(self):
  for args,kind,count in ((['--word','79'],'exact-branch',225),(['--controls-only'],'exact-fixed-branch',450)):
   with self.subTest(args=args):
    n=namespace();main=next(x for x in ast.parse(SOURCE.read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='main');exec(compile(ast.Module(body=[main],type_ignores=[]),'<actual-main-AST>','exec'),n)
    g=types.SimpleNamespace(divisor=12,frame={0:(0,1)});n.update({'data':lambda:{79:({'index':79},g),81:({'index':81},g)},'EXPECTED_WORDS':(79,81),'EXPECTED_MANIFEST_SHA256':'opaque','__doc__':'mock scientific preparation dependency','prepare_branches':lambda g,restrict=None:batch(),'describe':lambda row,g:{'index':row['index']},'perf_counter':lambda:1.,'json':json});n['k3'].witness=types.SimpleNamespace(FIXED_GAMMAS=((0,0),(1,1)))
    prior=sys.argv;out=io.StringIO()
    try:
     sys.argv=['source']+args
     with redirect_stdout(out):n['main']()
    finally:sys.argv=prior
    rs=[json.loads(l) for l in out.getvalue().splitlines()];self.assertEqual(sum(r['kind']==kind for r in rs),count);self.assertEqual(len(n['seen']),1 if count==225 else 2)
 def test_fingerprint_drift_before_warm_refused(self):
  for key in ('evaluator','l1_extended_offset_witness_k2.py'):
   with self.subTest(key=key):
    n=namespace();f=n['freeze_prepared'](batch(),12);n['test_fingerprint'][key]='a'*64
    with self.assertRaises(AssertionError):n['contract_frozen'](f,12)
    self.assertEqual(n['seen'],[])
 def test_fingerprint_drift_inside_kernel_refused_before_cache_insertion(self):
  n=namespace();calls=[]
  def kernel(f,e):calls.append(1);n['test_fingerprint']['evaluator']='a'*64;return 6,9
  n['k3'].eliminate_components=kernel;f=n['freeze_prepared'](batch(),12)
  with self.assertRaises(AssertionError):n['contract_frozen'](f,12)
  self.assertEqual(len(calls),1)
 def test_fingerprint_drift_inside_callback_refused_even_after_final_record(self):
  for boundary in (0,224):
   with self.subTest(boundary=boundary):
    n=namespace();f=n['freeze_prepared'](batch(),12);records=[]
    def emit(r):
     records.append(r)
     if r['branch']==boundary:n['test_fingerprint']['evaluator']='a'*64
    with self.assertRaises(AssertionError):n['contract_frozen'](f,12,emit)
    self.assertEqual(len(records),boundary+1)
 def test_unaccepted_dependency_fingerprint_refused_before_cold_snapshot(self):
  n=namespace();n['test_fingerprint']['l1_extended_offset_witness_k2.py']='a'*64
  with self.assertRaises(AssertionError):n['freeze_prepared'](batch(),12)
  self.assertEqual(n['seen'],[])
 def test_cold_class_count_measured_not_assumed154(self):
  n=namespace();p=batch();p[8]=(Fraction(1),None);p[9]=(Fraction(1),graph(7));f=n['freeze_prepared'](p,12);self.assertEqual(f.unique_inputs,2);self.assertEqual(f.branches,225)

if __name__=='__main__':
 if '--r10' in sys.argv:
  sys.argv.remove('--r10');suite=unittest.TestSuite(ReuseTests(name) for name in ('test_fingerprint_drift_before_warm_refused','test_fingerprint_drift_inside_kernel_refused_before_cache_insertion','test_fingerprint_drift_inside_callback_refused_even_after_final_record'));unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() or sys.exit(1)
 elif '--baseline' in sys.argv:
  sys.argv.remove('--baseline');unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([ReuseTests('test_distinct_equal_graphs_execute_once_keep225_weights_and_peak')])).wasSuccessful() or sys.exit(1)
 else:unittest.main(verbosity=2)
