from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from itertools import product,combinations,combinations_with_replacement
from hashlib import sha256
import ast,json,types,runpy,copy
P=Path('/tmp');stem='l1-7981-independent-runtime-source-review-r26';files={
'l1-7981-independent-unrestricted-r23-control.py':'47744003e2622fc437793f8f0e5988d4079fca864471b2db20be24cef53ae67d',
'l1-7981-independent-unrestricted-r23-control-driver.py':'b41e940369376f7d1ebcf6ea08ee829b8f32adb9d7fdbc7fc78a8626ad2abcec',
'l1-7981-independent-unrestricted-r23-replay79-runner.py':'d5a874fe5037778be8d086f749079ea51e008b872971daadb722371bb2563cec',
'l1-7981-independent-unrestricted-r23-replay79-driver.py':'f9f4d5941c53145b4424d75534e60edc4f502a64b9d7851d57803a970e6be46e'}
h=lambda p:sha256(p.read_bytes()).hexdigest();trees={}
for name,expected in files.items():
 p=P/name;assert h(p)==expected;trees[name]=ast.parse(p.read_text());compile(trees[name],str(p),'exec')
original=P/'l1-7981-independent-fixed-review-r4-control.py';assert h(original)=='8815633e951e5833157b9c324280aa19f0936d2133a436e1c25842f3b7c810a8'
funcs=lambda t:{n.name:n for n in t.body if isinstance(n,ast.FunctionDef)};cf=funcs(trees['l1-7981-independent-unrestricted-r23-control.py']);of=funcs(ast.parse(original.read_text()));names=('original_weights','gaussian','relocate','old_frame','anchor_integral','edge_reference','square_reference','shifted','normalize','translated');assert all(ast.dump(cf[n],include_attributes=False)==ast.dump(of[n],include_attributes=False) for n in names)
# Actual reconstruction subject; fixture original-L/cubature dependencies expose actual geometry slot/anchor decisions.
gammas={((0,0),(1,2)):2,((0,1),(2,2)):3};sq={((0,0),(1,2)):5,((0,1),(1,5)):-7};ident=((1,0,0,0),(1,0,0,0));g=types.SimpleNamespace(squares=((3,1,2),),lives=((3,1),),fixed_square={(3,1,2):{(1,2):ident,(3,2):ident,(7,1):ident}},fixed_edges={(1,5,2):0,(3,7,2):0,(5,7,1):1},joined_source={},edges={(1,3,1):[(1,1)],(3,7,2):[(7,2)],(5,7,1):[(5,1)],(0,1,0):[(1,0)]},frame={1:(0,1),3:(0,3),5:(0,1),7:(0,2)},sources=((0,2),(1,2)),divisor=12);seen=[]
def edge(labels,centers,fixed,anchor,probe):seen.append((labels,centers,fixed,anchor,probe));return {0:(sum(a+b for a,b in labels)+1,0)}
ns={'square_reference':lambda *args:sq,'k3':types.SimpleNamespace(square_factor=lambda *args:sq,witness=types.SimpleNamespace(center_weights=lambda domain:gammas)),'original_weights':lambda domain:gammas,'edge_reference':edge,'product':product,'source_ref':{1|(1<<8):(11,-2)}}
for name in ('relocate','reconstruct'):exec(compile(ast.Module(body=[cf[name]],type_ignores=[]),'<actual-r23-unrestricted-reconstruct-AST>','exec'),ns)
table=ns['reconstruct'](g,{})
assert table is not None;factors,D,exclusive=table;assert exclusive=={(1,0)} and len(factors[0][1])==1 and len(factors[1][1])==4
live=[x for x in seen if x[3] is not None];assert len(live)==2 and all(x[0]==((1,2),) and x[1]==(0,) and x[3]==1 for x in live) and {x[4] for x in live}=={(1,2),(1,5)}
assert any(x[1]==(1,) and x[2]==0 and x[0]==((1,2),) for x in seen) and any(x[1]==(0,) and x[2]==1 and x[0]==((2,2),) for x in seen)
assert len(factors[-2][1][()])==len(factors[-1][1][()])==1 and factors[-2][2]=={0:2,4:2} and factors[-1][2]=={1:2,5:2}
# Replay actual callback/controller, negative exact weights, independently hand-derived total1/2.
mod=runpy.run_path(str(P/'l1-7981-exact-reuse-r12-tests.py'),run_name='r26_stdlib_helper_fixture');rt=trees['l1-7981-independent-unrestricted-r23-replay79-runner.py'];rf=funcs(rt);warm=next(i for i,x in enumerate(rt.body) if isinstance(x,ast.Expr) and ast.unparse(x)=='signal.alarm(60)');outcomes=[]
for fail in (False,True):
 n=mod['namespace']();expected='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10';n['test_fingerprint']['evaluator']=expected
 if fail:
  def error(f,e):raise RuntimeError('exact pair cap fixture')
  n['k3'].eliminate_components=error
 weights=[F(1 if i%2==0 else -1) for i in range(225)];prepared=[(w,copy.deepcopy(mod['graph']())) for w in weights];frozen=n['freeze_prepared'](prepared,12);refs=[{'branch':i,'weight':[w.numerator,w.denominator],'raw_numerator':6,'divisor':12,'coefficient':[1,2],'algebraic_empty_preparation':False,'peak_rows':9} for i,w in enumerate(weights)];records=[];emitted=[];alarms=[];ticks=iter((1.,2.,3.));env={'F':F,'records':records,'weighted':F(),'weighted_raw':F(),'peak':0,'representatives':0,'reuse':0,'weights':weights,'reference':refs,'reference_final':{'coefficient':[1,2],'raw_numerator':6,'peak_rows':9},'D':12,'fields':('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows'),'emit':lambda kind,**kw:emitted.append({'kind':kind,**kw}),'signal':types.SimpleNamespace(alarm=alarms.append),'time':types.SimpleNamespace(perf_counter=lambda:next(ticks)),'s':n,'frozen':frozen,'cold':10.,'start':0.,'bound':lambda:None,'BINDING':{k:v for k,v in n['test_fingerprint'].items() if k!='evaluator'},'EXPECTED':expected,'REFERENCE_SHA256':'opaquecomparisonfixture'};exec(compile(ast.Module(body=[rf['compare_and_emit']],type_ignores=[]),'<actual-r23-replay-callback>','exec'),env)
 failure=None
 try:exec(compile(ast.Module(body=rt.body[warm:],type_ignores=[]),'<actual-r23-replay-warm>','exec'),env)
 except RuntimeError as error:failure=str(error)
 if fail:assert failure=='exact pair cap fixture' and not records and not any(r['kind']=='independent-replay-exact-word' for r in emitted) and alarms==[60]
 else:assert len(records)==225 and emitted[-1]['coefficient']==[1,2] and len(n['seen'])==1 and alarms==[60,0]
 outcomes.append({'failure':fail,'branches':len(records),'alarms':alarms,'final_result':not fail})
# Evaluate actual receipt source fields without invoking subprocesses; this exposes the demonstrated defect.
receipt_sources={}
for name in ('l1-7981-independent-unrestricted-r23-control-driver.py','l1-7981-independent-unrestricted-r23-replay79-driver.py'):
 t=trees[name];r=next(x.value for x in ast.walk(t) if isinstance(x,ast.Assign) and any(isinstance(y,ast.Name) and y.id=='receipt' for y in x.targets));value=next(v for k,v in zip(r.keys,r.values) if isinstance(k,ast.Constant) and k.value=='source_sha256');receipt_sources[name]=ast.literal_eval(value)
assert receipt_sources['l1-7981-independent-unrestricted-r23-control-driver.py']=='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7';assert receipt_sources['l1-7981-independent-unrestricted-r23-replay79-driver.py']=='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
result={'verdict':'REJECT current control-driver admission metadata; ACCEPT new control scientific-source and replay pair source scope only','mandatory_correction':'Control-driver receipt source_sha256 must bind actual r12 2b852f, not old e4a228; rebind reviewed driver hash/packet before execution','files_sha256':files,'original_fixed10_reference_ASTs_unchanged':list(names),'actual_reconstruction_fixture':{'full_center_domains':True,'exclusive_first_slot_filter':True,'global_second_gamma_live_center0_anchor1':True,'fixed_singletons_center1_anchor0_center0_anchor1':True,'two_distinct_source_polynomials_remapped':True},'actual_replay_negative_weight_success_and_error_fixtures':outcomes,'actual_driver_receipt_source_fields':receipt_sources,'scientific_imports_moments_preparations_runs':False,'no_own_r12_wrapper_reacceptance_claim':'Existing r13 source acceptance reused; this review concerns independent r23 reconstruction/orchestration only','performance':'Unmeasured; full-control600/665 and replay600/ONE60WHOLE225/665 unchanged','runtime_admission':'Not granted'};(P/(stem+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
