"""Stdlib actual-wrapper AST controls; scientific runpy is the opaque dependency."""
from pathlib import Path
from fractions import Fraction
from hashlib import sha256
import ast,types,unittest,io,json,copy,contextlib,subprocess,hashlib,tempfile
P=Path('/tmp');RUNNER=P/'l1-7981-portable-cli-r31-runner.py';DRIVER=P/'l1-7981-portable-cli-r31-driver.py'
class WrapperTests(unittest.TestCase):
 def wrapper(self,mode='79',failure=False,hook=True):
  t=ast.parse(RUNNER.read_text());fn=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='main');alarms=[];profiles=[];records=[];argv=['wrapper',mode];fake_sys=types.SimpleNamespace(argv=argv,modules={},setprofile=lambda f:profiles.append(f));script=Path('/installed/audit/portable.py');audit=script.parent;calls=[]
  def opaque_run(path,run_name):
   self.assertEqual((path,run_name),(str(script),'__main__'));self.assertEqual(fake_sys.argv,[str(script),'--word',mode] if mode in ('79','81') else [str(script)]+(['--controls-only'] if mode=='fixed' else []));calls.append(1)
   if mode in ('79','81') and hook:
    callback=profiles[-1]
    for event,name,file in [('return','contract_frozen',str(script)),('call','other',str(script)),('call','contract_frozen','/other/portable.py')]:callback(types.SimpleNamespace(f_code=types.SimpleNamespace(co_name=name,co_filename=file),f_globals={}),event,None)
    self.assertEqual(alarms,[600]);callback(types.SimpleNamespace(f_code=types.SimpleNamespace(co_name='contract_frozen',co_filename=str(script)),f_globals={'__name__':'__main__'}),'call',None)
   if failure:raise RuntimeError('opaque native failure')
   return {'opaque':'actual native globals'}
  env={'sys':fake_sys,'signal':types.SimpleNamespace(alarm=alarms.append),'runpy':types.SimpleNamespace(run_path=opaque_run),'SCRIPT':script,'AUDIT':audit,'BINDING':{'primitive.py':'opaque'},'_pin_installed':lambda:{'source_sha256':{'evaluator':'opaque'}},'_runtime_proof':lambda ns:{'AUDIT':str(audit),'source_sha256':{'evaluator':'opaque'}},'emit':lambda kind,**kw:records.append({'kind':kind,**kw}),'time':types.SimpleNamespace(perf_counter=lambda:1.)}
  exec(compile(ast.Module(body=[fn],type_ignores=[]),'<actual-wrapper-main-AST>','exec'),env)
  error=None
  try:env['main']()
  except (RuntimeError,AssertionError) as e:error=e
  return alarms,profiles,records,calls,error,fake_sys.argv,argv
 def test_full_word_hooks_only_actual_file_function_entry_then_disables(self):
  for word in ('79','81'):
   a,p,r,c,e,argv,prior=self.wrapper(word);self.assertIsNone(e);self.assertEqual(a,[600,60,0]);self.assertIsNone(p[-1]);self.assertEqual(r[-1]['warm_entry_hooks'],1);self.assertEqual(argv,prior);self.assertEqual(len(c),1)
 def test_census_and_fixed_keep_original_whole_process_limits(self):
  for mode,limit in (('census',30),('fixed',60)):
   a,p,r,c,e,argv,prior=self.wrapper(mode);self.assertIsNone(e);self.assertEqual(a,[limit,0]);self.assertEqual(r[-1]['warm_entry_hooks'],0);self.assertEqual(argv,prior)
 def test_missing_full_hook_refused_without_success_record(self):
  a,p,r,c,e,argv,prior=self.wrapper('79',hook=False);self.assertIsInstance(e,AssertionError);self.assertEqual(a,[600]);self.assertFalse(any(x['kind']=='portable-cli-wrapper-complete' for x in r))
 def test_native_exception_propagates_no_success_or_timer_restart(self):
  a,p,r,c,e,argv,prior=self.wrapper('79',failure=True);self.assertIsInstance(e,RuntimeError);self.assertEqual(a,[600,60]);self.assertFalse(any(x['kind']=='portable-cli-wrapper-complete' for x in r));self.assertEqual(argv,prior);self.assertIsNone(p[-1])

class ParentAndBindingTests(unittest.TestCase):
 def test_actual_preflight_files_and_relative_runtime_path_proof(self):
  t=ast.parse(RUNNER.read_text());nodes=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in ('_pin_installed','_runtime_proof')]
  with tempfile.TemporaryDirectory(prefix='l1-7981-portable-cli-r31-') as directory:
   audit=Path(directory).resolve();script=audit/'portable.py';script.write_bytes(b'opaque CLI file; never imported')
   pins={}
   for name in ['l1_extended_offset_witness_k3.py']+['primitive'+str(i)+'.py' for i in range(15)]:
    path=audit/name;path.write_bytes(name.encode());pins[name]=sha256(path.read_bytes()).hexdigest()
   manifest={'kind':'paired-k4-census','rows':['opaque']};(audit/'l1_k4_census.out.txt').write_text(json.dumps(manifest)+'\n');digest=sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest();expected=sha256(script.read_bytes()).hexdigest();modules={name[:-3]:types.SimpleNamespace(__file__=str(audit/name)) for name in pins};env={'Path':Path,'hashlib':hashlib,'json':json,'SCRIPT':script,'AUDIT':audit,'BINDING':pins,'EXPECTED':expected,'MANIFEST':digest,'sys':types.SimpleNamespace(modules=modules)};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual-preflight-and-path-proof-AST>','exec'),env)
   proof=env['_pin_installed']();self.assertEqual(proof['AUDIT'],str(audit));ns={'__name__':'__main__','__file__':str(script),'AUDIT':audit,'EXPECTED_MANIFEST_SHA256':digest,'source_hashes':lambda:{**pins,'evaluator':expected}};self.assertEqual(env['_runtime_proof'](ns)['source_sha256'],{**pins,'evaluator':expected})
   ns['AUDIT']=audit/'wrong'
   with self.assertRaises(AssertionError):env['_runtime_proof'](ns)
   ns['AUDIT']=audit;(audit/'primitive1.py').write_bytes(b'drift')
   with self.assertRaises(AssertionError):env['_pin_installed']()
 def test_actual_parent_timeout_kills_preserves_failure_receipt(self):
  t=ast.parse(DRIVER.read_text());main=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='main');files={};opened=[];waits=[];killed=[]
  class File:
   def __init__(self,path):self.path=str(path)
   def exists(self):return self.path in files
   def open(self,mode):
    selfmode=mode;opened.append((self.path,mode));return contextlib.nullcontext(io.BytesIO())
   def read_text(self,**kw):return json.dumps({'kind':'exact-branch','word':79,'branch':0})+'\n'
   def write_text(self,value):files[self.path]=value
  class Process:
   def wait(self,timeout=None):
    waits.append(timeout)
    if timeout is not None:raise subprocess.TimeoutExpired('opaque child',timeout)
    return -9
   def kill(self):killed.append(True)
  env={'Path':File,'sys':types.SimpleNamespace(argv=['driver','79']),'subprocess':types.SimpleNamespace(Popen=lambda *a,**kw:Process(),TimeoutExpired=subprocess.TimeoutExpired),'time':types.SimpleNamespace(perf_counter=lambda:1.),'json':json,'hashlib':hashlib,'RUNNER':RUNNER,'RUNNER_SHA256':sha256(RUNNER.read_bytes()).hexdigest(),'EXE':'opaque-primary-python','SOURCE_SHA256':'opaque-source','_validate':lambda r,m:(_ for _ in ()).throw(AssertionError('must not validate timeout'))};exec(compile(ast.Module(body=[main],type_ignores=[]),'<actual-parent-envelope-AST>','exec'),env)
  with contextlib.redirect_stdout(io.StringIO()):code=env['main']()
  receipt=json.loads(next(iter(files.values())));self.assertEqual(code,124);self.assertEqual(receipt['actual_child_exit'],-9);self.assertTrue(receipt['parent_timeout']);self.assertEqual(waits,[665,None]);self.assertEqual(killed,[True]);self.assertTrue(all(mode=='xb' for name,mode in opened));self.assertEqual(receipt['driver_exit'],124);self.assertEqual(receipt['complete_unrestricted_branch_records'],1)
 def test_actual_native_validation_accepts_protocol_and_refuses_incomplete_word(self):
  t=ast.parse(DRIVER.read_text());fn=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='_validate');env={'SOURCE_SHA256':'source'};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<actual-native-output-validator>','exec'),env);binding={'evaluator':'source'};manifest='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b';start={'kind':'portable-cli-wrapper-start'};complete={'kind':'portable-cli-wrapper-complete','warm_entry_hooks':1,'source_sha256':binding};branches=[{'kind':'exact-branch','word':79,'branch':i} for i in range(225)];summary={'kind':'exact-word','source_sha256':binding,'manifest_sha256':manifest,'row_cap':120000,'pair_cap':3000000,'word':{'index':79},'branches':225,'coefficient':[1165710661495982585955,35184372088832],'preparation_seconds':30.,'whole225_warm_seconds':40.}
  records=[start]+branches+[summary,complete];self.assertEqual(env['_validate'](records,'79'),(226,225,0))
  with self.assertRaises(AssertionError):env['_validate']([start]+branches[:-1]+[summary,complete],'79')
  summary['whole225_warm_seconds']=61.
  with self.assertRaises(AssertionError):env['_validate'](records,'79')

if __name__=='__main__':unittest.main(verbosity=2)
