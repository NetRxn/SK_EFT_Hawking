"""Prepared only: ROOT separately admits one actual installed CLI mode per process."""
from pathlib import Path
import sys,subprocess,time,json,hashlib
RUNNER=Path('/tmp/l1-7981-portable-cli-r31-runner.py');RUNNER_SHA256='ce33a04a2abf764b875b42797ce185ae10cabd6285640b147a3e338a0d8c6d8a'
EXE='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
SOURCE_SHA256='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
def _validate(records,mode):
 assert records[0]['kind']=='portable-cli-wrapper-start' and records[-1]['kind']=='portable-cli-wrapper-complete'
 assert records[-1]['warm_entry_hooks']==(1 if mode in ('79','81') else 0)
 native=[r for r in records if not r['kind'].startswith('portable-cli-wrapper-')]
 summaries=[r for r in native if r['kind'] in ('source-sharing-square-two-protected-tori-census','fixed-label','exact-word')]
 for r in summaries:
  assert r['source_sha256']==records[-1]['source_sha256'] and r['source_sha256']['evaluator']==SOURCE_SHA256
  assert r['manifest_sha256']=='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b' and r['row_cap']==120000 and r['pair_cap']==3000000
 if mode=='census':
  assert len(native)==1 and summaries[0]['valid_words']==[79,81] and [x['word']['index'] for x in summaries[0]['entries']]==[79,81]
 elif mode=='fixed':
  branches=[r for r in native if r['kind']=='exact-fixed-branch'];assert len(branches)==450 and [r['word'] for r in summaries]==[79,81]
  for word in (79,81):assert [r['branch'] for r in branches if r['word']==word]==list(range(225))
  assert all(r['branches']==225 and r['coefficient']==[10367035518435041776795,7709672958021817718820298555392] for r in summaries)
 else:
  branches=[r for r in native if r['kind']=='exact-branch'];assert len(branches)==225 and [r['branch'] for r in branches]==list(range(225)) and all(r['word']==int(mode) for r in branches)
  assert len(summaries)==1;last=summaries[0]
  assert last['word']['index']==int(mode) and last['branches']==225 and last['coefficient']==[1165710661495982585955,35184372088832] and last['preparation_seconds']<600 and last['whole225_warm_seconds']<60
 return len(native),sum(r['kind']=='exact-branch' for r in native),sum(r['kind']=='exact-fixed-branch' for r in native)
def main():
 mode=sys.argv[1];assert mode in ('census','fixed','79','81');limit=665 if mode in ('79','81') else (30 if mode=='census' else 60)
 prefix='/tmp/l1-7981-portable-cli-r31-'+mode;out=Path(prefix+'.out');err=Path(prefix+'.err');end=Path(prefix+'.exit.json')
 assert hashlib.sha256(RUNNER.read_bytes()).hexdigest()==RUNNER_SHA256
 assert not any(p.exists() for p in (out,err,end))
 command=[EXE,'-B',str(RUNNER),mode];start=time.perf_counter();timeout=False
 with out.open('xb') as stdout,err.open('xb') as stderr:
  process=subprocess.Popen(command,stdout=stdout,stderr=stderr)
  try:code=process.wait(timeout=limit);reason='terminal'
  except subprocess.TimeoutExpired:timeout=True;process.kill();code=process.wait();reason='whole process timeout'
 status=124 if timeout else (0 if code==0 else 1);records=[];invalid=0;counts=(0,0,0)
 for line in out.read_text(errors='replace').splitlines():
  try:records.append(json.loads(line))
  except ValueError:invalid+=1
 counts=(sum(not r.get('kind','').startswith('portable-cli-wrapper-') for r in records),sum(r.get('kind')=='exact-branch' for r in records),sum(r.get('kind')=='exact-fixed-branch' for r in records))
 if code==0 and not timeout:
  try:assert invalid==0;_validate(records,mode)
  except (AssertionError,KeyError,TypeError,IndexError) as error:status=1;reason='terminal output validation failed: '+repr(error)
 receipt={'actual_child_exit':code,'driver_exit':status,'parent_timeout':timeout,'reason':reason,'mode':mode,'actual_parent_wall_seconds':time.perf_counter()-start,'whole_process_limit_seconds':limit,'full_word_phase_limits':{'cold':600,'WHOLE225warm':60,'parent':665} if mode in ('79','81') else None,'command':command,'runner_sha256':RUNNER_SHA256,'source_sha256':SOURCE_SHA256,'native_record_count':counts[0],'complete_unrestricted_branch_records':counts[1],'complete_fixed_branch_records':counts[2],'invalid_lines':invalid,'last_complete_record':records[-1]['kind'] if records else None}
 end.write_text(json.dumps(receipt,sort_keys=True)+'\n');print(json.dumps(receipt),flush=True);return status
if __name__=='__main__':raise SystemExit(main())
