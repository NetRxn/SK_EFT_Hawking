from pathlib import Path
P=Path('/tmp');p=P/'l1-7981-exact-reuse-r10-tests.py';s=p.read_text();s=s.replace("BASELINE='--baseline' in sys.argv", "BASELINE='--baseline' in sys.argv\nR10='--r10' in sys.argv")
s=s.replace("SOURCE=P/'l1-7981-evaluator-exact-reuse-r10.py'", "SOURCE=P/('l1-7981-evaluator-exact-reuse-r10.py' if R10 else 'l1-7981-evaluator-exact-reuse-r12.py')")
s=s.replace("names={'contract_prepared'} if baseline else {'FrozenPrepared'", "names={'contract_prepared'} if baseline else {'EXPECTED_SIBLING_SHA256','FrozenPrepared'")
s=s.replace("ns={'Fraction':Fraction,'namedtuple':namedtuple,'k3':types.SimpleNamespace(eliminate_components=kernel),'k2':k2}","fingerprint={**json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text())['principal_source_sha256'],'evaluator':'e'*64}\n ns={'Fraction':Fraction,'namedtuple':namedtuple,'k3':types.SimpleNamespace(eliminate_components=kernel),'k2':k2,'source_hashes':lambda:dict(fingerprint),'test_fingerprint':fingerprint}")
s=s.replace("'source_hashes':lambda:{},", "")
at=" def test_cold_class_count_measured_not_assumed154(self):"
extra=''' def test_fingerprint_drift_before_warm_refused(self):
  for key in ('evaluator','l1_extended_offset_witness_k2.py'):
   with self.subTest(key=key):
    n=namespace();f=n['freeze_prepared'](batch(),12);n['test_fingerprint'][key]='a'*64
    with self.assertRaises(AssertionError):n['contract_frozen'](f,12)
    self.assertEqual(n['seen'],[])
 def test_fingerprint_drift_inside_kernel_refused_before_cache_insertion(self):
  n=namespace();calls=[]
  def kernel(f,e):calls.append(1);n['test_fingerprint']['evaluator']='a'*64;return 6,9
  n['k3'].eliminate_components=kernel;f=n['freeze_prepared'](batch(),12)
  with self.assertRaises(AssertionError):n['contract_frozen'](f,12)
  self.assertEqual(len(calls),1)
 def test_fingerprint_drift_inside_callback_refused_even_after_final_record(self):
  for boundary in (0,224):
   with self.subTest(boundary=boundary):
    n=namespace();f=n['freeze_prepared'](batch(),12);records=[]
    def emit(r):
     records.append(r)
     if r['branch']==boundary:n['test_fingerprint']['evaluator']='a'*64
    with self.assertRaises(AssertionError):n['contract_frozen'](f,12,emit)
    self.assertEqual(len(records),boundary+1)
'''
assert at in s;s=s.replace(at,extra+at)
s=s.replace("if '--baseline' in sys.argv:\n  sys.argv.remove('--baseline');", "if '--r10' in sys.argv:\n  sys.argv.remove('--r10');suite=unittest.TestSuite(ReuseTests(name) for name in ('test_fingerprint_drift_before_warm_refused','test_fingerprint_drift_inside_kernel_refused_before_cache_insertion','test_fingerprint_drift_inside_callback_refused_even_after_final_record'));unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() or sys.exit(1)\n elif '--baseline' in sys.argv:\n  sys.argv.remove('--baseline');")
(P/'l1-7981-exact-reuse-r12-tests.py').write_text(s)
