# r31 actual portable CLI budget preparation

Prepared only; independent nonauthor source review and fresh ROOT admission are required. Initial packet was fresh. Return check is stale with `changed=[source]`; it was not self-refreshed. ROOT disclosed terminal broad qualification and later evidence updates. No candidate/primary/notebook/Git write, scientific import, original-L calculation, factor preparation, contraction, actual portable CLI or profile execution occurred.

Runner `/tmp/l1-7981-portable-cli-r31-runner.py` SHA256 `ce33a04a2abf764b875b42797ce185ae10cabd6285640b147a3e338a0d8c6d8a`.

Parent `/tmp/l1-7981-portable-cli-r31-driver.py` SHA256 `57a31a2263b03090fac2510186da5c5a95a8cb038f73f69b082ba7890bfe9b62`.

Both are new scratch artifacts. The actual installed target is the requested `l1_extended_offset_witness_k4_source_sharing_square_two_protected_tori.py` in the canonical candidate audit directory. It is currently ABSENT. The wrapper will refuse execution before import unless ROOT installs byte-identical reviewed r12 SHA256 `2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10`. No installation was performed here.

## Actual entrypoint and phase budgets

The accepted previous110/153 CLI envelope supplies the existing exclusive streams/parent timeout/actual-exit/readback pattern. New parent admits exactly one selected mode per invocation: `census` with30s whole-process limit; `fixed` with60s whole-process limit; full79 or81 with665s parent. Each has a distinct `/tmp/l1-7981-portable-cli-r31-MODE` prefix and refuses existing stdout/stderr/receipt paths. No automatic subsequent mode executes after a failure.

The child pre-import guard pins actual installed evaluator bytes, all16 literal accepted sibling hashes and canonical272-manifest digest. It requires the installed script and siblings physically resolve within the same AUDIT directory and the k3 sibling is present. No principal scientific module may already be imported. Actual source bytes2b852f assign AUDIT from their own resolved directory first and skip the absolute fallback when this k3 premise holds. Post-import proof additionally checks the actual native globals' __file__/AUDIT, all16 module file parents, actual full17 source fingerprint and manifest constant. This establishes installed sibling-directory selection, rather than using the scratch absolute fallback.

The wrapper supplies exact native argv and calls `runpy.run_path(installed_path, run_name='__main__')`. It does not call helpers directly, rewrite source/ASTs or emulate main. Thus actual argparse, default census, fixed CLI loop or selected full-word main runs unchanged.

For full79/81,600s alarm starts before pins/imports/preparation. The only budget transition is a `sys.setprofile` callback selecting a Python `call` event whose code filename equals the exact installed file and code name is `contract_frozen`, with actual __main__ globals. At that actual entry it requires the first/only hook, disables profiling, arms60s and verifies installed runtime path/binding. All private thaws, cache/key lookups, exact representative kernels,225 native branch records, final native reduction/summary and wrapper final path/binding/readback remain under that same60s alarm. The callback never changes source, input objects or scientific functions. Native main's already reviewed single full-word call plus final hook-count1 assertion enforce this entry contract; no timer restarts per branch or representative. The alarm is canceled only after complete successful native return and alarm-covered wrapper-complete output. An exception propagates, clears profiling/restores argv in finally and produces no success record or fallback.

Census/fixed do not install the hook; their child alarms30/60 and parent limits30/60 preserve the existing accepted whole-process budgets. The fixed CLI executes BOTH actual225-word controls under one60s process envelope. Full79 and81 modes are coherent source selectors; each still requires its own ROOT admission.

The parent validates native census/fixed/full mode records and exact225/450 index populations, actual source/manifest/cap bindings, native final coefficient against the already accepted paired/fixed reference and reported full phase durations. This is an output check, never a numerical input. It records actual child status, driver status, timeout and all complete parsed branch counts even on partial failure. A timeout kills the child, preserves streams and writes failure; malformed terminal success becomes explicit validation failure. No error becomes a coefficient or zero.

## Actually performed source/fixture controls

Seven stdlib tests execute actual wrapper/parent/helper ASTs with opaque runpy/subprocess dependencies; scientific entrypoints are never imported. They verify actual runpy __main__/argv routing for79/81/census/fixed, false-event/false-file/false-function hook rejection,600→60 single transition/profile disable, missing-hook refusal, native exception propagation/no success, actual filesystem hash/manifest and relative runtime-path proofs, parent665 timeout/kill/failure receipt and native225 output validation/refusal of incomplete or over-budget summaries.

The parent timeout fixture exposed a real metadata bug during development: initially a failed child would report zero complete branches even if stdout held a complete partial row. `/tmp/l1-7981-portable-cli-r31-partial-counter-red.err` preserves the intended assertion RED0!=1. Counting was moved before status/validation checks; the final timeout fixture now correctly reports its one complete row while retaining timeout124/child−9. Original output is preserved.

An earlier filesystem fixture supplied an unresolved macOS temporary path where production AUDIT is resolved. Its path-equality assertion failed, preserved in `*-tests-r2.err`; the fixture was corrected to mirror the production resolved path. It was not a scientific defect or runtime attempt. Final `*-tests-r4.err` reports7 tests OK. Test source was written before wrapper implementation; no initial wrapper-wide pre-implementation red was recorded, and none is claimed. The later partial-counter change has its explicit observed red/green evidence.

`*-source-controls.py/.json` additionally compile scripts, verify parent→runner hash binding, actual single runpy main call, hook disable/alarm AST, all current16 immutable math hashes and canonical manifest digest, source2b852f unchanged and current target absence. Installed runtime/path validation remains unrun.

## Next gates and scope

Independent SOURCE review must accept these wrappers and their exact hashes before any execution. ROOT then owns actual installation after its current source freeze/state reconciliation and fresh per-mode admission. The new module/source/helper bytes remain unchanged. Actual census, fixed and full CLI outcomes/timing and path proof are UNKNOWN. Prior scientific/r12/failure streams are untouched. R24 receipt/class-union proposal and current portable234 do not become accepted236 through this preparation; archive/class/independent composition and remaining scientific/publication gates stay explicit.
