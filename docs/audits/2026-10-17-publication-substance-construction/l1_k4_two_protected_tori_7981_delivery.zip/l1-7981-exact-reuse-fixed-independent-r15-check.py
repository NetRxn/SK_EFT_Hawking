from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
import json,zipfile,hashlib,zlib,ast
P=Path('/tmp');R=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103');A=R/'docs/audits/2026-10-17-publication-substance-construction';sha=lambda b:hashlib.sha256(b).hexdigest();zp=A/'l1_k4_two_protected_tori_7981_controls.zip';m=json.loads((A/'l1_k4_two_protected_tori_7981_controls_manifest.json').read_text());assert sha(zp.read_bytes())==m['archive_sha256'];old={};original_hashes={}
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(m['files'])==62 and set(z.namelist())=={r['name'] for r in m['files']}
 for r in m['files']:
  b=z.read(r['name']);assert len(b)==r['bytes'] and sha(b)==r['sha256'] and zlib.crc32(b)==z.getinfo(r['name']).CRC;original_hashes[r['name']]=sha(b)
 for w,prefix in [(79,'l1-7981-control-preparation-r2-fixed79'),(81,'l1-7981-fixed81-r4')]:
  rs=[json.loads(l) for l in z.read(prefix+'.out').splitlines()];ex=json.loads(z.read(prefix+'.exit.json'));assert ex['actual_child_exit_code']==ex['driver_exit_code']==0 and not z.read(prefix+'.err');old[w]=(rs[1],rs[3:-1],rs[-1])
 accepted=json.loads(z.read('l1-7981-control-preparation-r2-binding.json'))['principal_source_sha256']
assert len(accepted)==16 and all(sha((A/n).read_bytes())==h for n,h in accepted.items());source=P/'l1-7981-evaluator-exact-reuse-r12.py';runner=P/'l1-7981-exact-reuse-r12-fixed-equivalence-runner.py';driver=P/'l1-7981-exact-reuse-r12-fixed-equivalence-driver.py';assert sha(source.read_bytes())=='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10' and sha(runner.read_bytes())=='5f4715c06105a3b42ceca1aaf1e9ecc3ab09ff044a90b1b105dca8b1892faddf' and sha(driver.read_bytes())=='6a586e024aa27e4a3535a534cf4c037543b7a19ef5f9585b6c60e428ee8310b4'
expected_binding={**accepted,'evaluator':sha(source.read_bytes())};D=192**42*4**64*48**6*2**15

def protected(linked,other):
 yield F(1,256),dict.fromkeys(linked+other,tuple((i,i) for i in range(6)))
 for c in (0,3):
  ds=tuple((i,i) for i in range(c,c+3));yield F(-1,559872),dict.fromkeys(linked+other,ds)
  for pair in combinations_with_replacement(range(c,c+3),2):yield F(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:ds,other[1]:ds}
weights=[w*v for w,c in protected((0,4),(8,12)) for v,d in protected((1,5),(9,13))];assert len(weights)==225 and sum(w<0 for w in weights)==52
fields=('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows');result={'packet':'publication-7981-fixed-independent-r15.json','first_check_exit':0,'first_check_fresh':True,'source_sha256':expected_binding['evaluator'],'original_archive_sha256':m['archive_sha256'],'original_archive62_entries_all_crc_size_sha':True,'words':{},'new_files':{}};new={}
for w in (79,81):
 prefix=P/f'l1-7981-exact-reuse-r12-fixed-equivalence-{w}';paths={n:Path(str(prefix)+s) for n,s in [('stdout','.out'),('stderr','.err'),('terminal','.exit.json')]};rs=[json.loads(l) for l in paths['stdout'].read_text().splitlines()];ex=json.loads(paths['terminal'].read_text());first,bs,last=rs[0],rs[1:-1],rs[-1]
 assert ex['actual_child_exit']==ex['driver_exit']==0 and not ex['parent_timeout'] and not paths['stderr'].read_bytes() and ex['truncated_lines']==0 and ex['complete_branch_records']==225 and ex['word']==w
 assert ex['runner_sha256']==sha(runner.read_bytes()) and ex['command']==['/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python','-B',str(runner),str(w)]
 assert ex['limits']=={'cold':600,'WHOLE225baseline_and_reuse_warm':60,'parent':665,'row':120000,'pair':3000000} and ex['parent_seconds']<665
 assert first['kind']=='phase-complete' and first['phase']=='cold-fixed-equivalence' and last['kind']=='fixed-equivalence-word' and first['word']==last['word']==w and first['source_sha256']==last['source_sha256']==expected_binding
 assert len(bs)==first['branches']==last['branches']==225 and first['actual_unique_inputs']==last['actual_unique_inputs']==4 and last['prepared_objects_unchanged'] and last['all_raw_weight_fraction_divisor_peak_structural_flags_equal'] and last['unrestricted']=='NOT RUN'
 assert first['seconds']==last['cold_seconds']<600 and 0<=last['baseline_seconds'] and 0<=last['reuse_seconds'] and last['baseline_seconds']+last['reuse_seconds']<=last['whole225_baseline_and_reuse_warm_seconds']<60
 op,ob,ol=old[w];total=F();raw=F();empty=zero=reused=representatives=0
 for i,(b,o,weight) in enumerate(zip(bs,ob,weights,strict=True)):
  assert b['kind']=='fixed-equivalence-branch' and b['word']==w and b['branch']==i and all(b[k]==o[k] for k in fields)
  assert F(*b['weight'])==weight and b['divisor']==D and F(*b['coefficient'])==F(b['raw_numerator'],D);total+=weight*F(*b['coefficient']);raw+=weight*b['raw_numerator']
  if b['algebraic_empty_preparation']:
   empty+=1;assert b['raw_numerator']==b['peak_rows']==0 and b['representative_branch'] is None and not b['reused_contraction']
  else:
   zero+=b['raw_numerator']==0
   if b['reused_contraction']:
    reused+=1;rep=b['representative_branch'];assert type(rep) is int and 0<=rep<i and not bs[rep]['reused_contraction'] and not bs[rep]['algebraic_empty_preparation'] and all(bs[rep][k]==b[k] for k in ['raw_numerator','divisor','coefficient','peak_rows'])
   else:representatives+=1;assert b['representative_branch']==i
 assert (225-empty,empty,zero,reused,representatives)==(25,200,0,21,4)
 assert raw.denominator==1 and raw.numerator==ol['raw_numerator'] and total==F(*last['coefficient'])==F(*ol['coefficient'])==F(10367035518435041776795,7709672958021817718820298555392)
 assert max(b['peak_rows'] for b in bs)==last['peak_rows']==ol['peak_rows']==564
 new[w]=bs;result['words'][str(w)]={'branches':225,'nonempty':25,'structural_empty':200,'computed_zero_nonempty':0,'negative_weights':52,'unique_actual_FIXED_inputs':4,'first_representatives':4,'reused_successes':21,'coefficient':last['coefficient'],'peak':564,'cold_seconds':last['cold_seconds'],'baseline_seconds':last['baseline_seconds'],'reuse_seconds':last['reuse_seconds'],'combined_whole225_warm_seconds':last['whole225_baseline_and_reuse_warm_seconds'],'parent_seconds':ex['parent_seconds'],'all225_original_branch_fields_and_finals_equal':True,'complete17_bindings_equal':True,'original_values_conserved_assertion':True}
 for n,p in paths.items():result['new_files'][str(p)]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
for i in range(15):
 for j in range(15):
  a,b=new[79][15*i+j],new[81][15*j+i];assert all(a[k]==b[k] for k in fields if k!='branch')
  x,y=old[79][0]['support_domains'][15*i+j],old[81][0]['support_domains'][15*j+i];assert {q^1:ds for q,ds in x['core_domains']}==dict(y['core_domains'])
  assert {c['center']^1:{k:v for k,v in c.items() if k!='center'} for c in x['center_support']}=={c['center']:{k:v for k,v in c.items() if k!='center'} for c in y['center_support']}
  assert sorted(q^1 for q in x['empty_center_sites'])==y['empty_center_sites']
  if x['prepared_graph'] is None:assert y['prepared_graph'] is None;continue
  yf={tuple(f['source']):f for f in y['prepared_graph']['source_factors']}
  for f in x['prepared_graph']['source_factors']:
   g=yf[f['source'][0]^1,f['source'][1]];translated=[]
   for v in f['polynomial']:
    mask=v['mask'];sgn=(-1)**sum(((mask>>(8*q))&255).bit_count()*((mask>>(8*(q^1)))&255).bit_count() for q in range(0,16,2));mm=sum(((mask>>(8*q))&255)<<(8*(q^1)) for q in range(16));translated.append((mm,sgn*v['real'],sgn*v['imag']))
   assert sorted(translated)==sorted((v['mask'],v['real'],v['imag']) for v in g['polynomial'])
result.update({'verdict':'ACCEPT complete450 actual fixed baseline/original-receipt equivalence and signed225 transpose within FIXED controls only','check_exit':0,'signed225_transpose_original_source_masks_core_centers':True,'all450_raw_weight_D_fraction_peak_structuralflags_and_finals_match_original':True,'original_prepared_objects':'Reviewed runtime assertion compares complete before/after values; source-reviewed cold snapshot/private thaw preserves originals. No new preparation occurred in this review.','required_corrections':[],'scientific_imports_preps_contractions_runs_in_this_review':False,'acceptance_limits':['Fourunique inputs measured FIXED ONLY, not unrestricted154 population','Fixed timings do not establish unrestricted performance','No new unrestricted run admitted, no unrestricted coefficient, no portable/class increase','Portable234, original failed218/225 attempt and broader scientific/main/publication obligations unchanged']})
(P/'l1-7981-exact-reuse-fixed-independent-r15.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'verdict':result['verdict'],'words':result['words'],'corrections':[]},indent=2))
