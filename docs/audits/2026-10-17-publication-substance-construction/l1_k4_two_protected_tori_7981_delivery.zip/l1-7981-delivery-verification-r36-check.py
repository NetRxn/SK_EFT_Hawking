from pathlib import Path
import ast,json,hashlib,zipfile
from fractions import Fraction as F
from collections import Counter
A=Path.cwd()/'docs/audits/2026-10-17-publication-substance-construction';P=Path('/tmp')
source=A/'l1_extended_offset_witness_k4_source_sharing_square_two_protected_tori.py';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(source)=='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
def read(prefix):
 rows=[json.loads(x) for x in Path(str(prefix)+'.out').read_text().splitlines()];exit=json.loads(Path(str(prefix)+'.exit.json').read_text());assert not Path(str(prefix)+'.err').read_bytes();return rows,exit
cli={};fields=('branch','weight','raw_numerator','divisor','coefficient','peak_rows','algebraic_empty_preparation','representative_branch','reused_contraction')
for mode in ('census','fixed','79','81'):
 rows,exit=read(P/('l1-7981-portable-cli-r31-'+mode));assert exit['actual_child_exit']==exit['driver_exit']==0 and not exit['parent_timeout'];proof=rows[-1];assert proof['kind']=='portable-cli-wrapper-complete' and Path(proof['script'])==source and Path(proof['AUDIT'])==A
 assert proof['source_sha256']['evaluator']==sha(source) and proof['warm_entry_hooks']==(1 if mode in ('79','81') else 0)
 cli[mode]={'exit':exit,'path_and_source_proof':proof}
 if mode in ('79','81'):
  branches=[x for x in rows if x['kind']=='exact-branch'];final=next(x for x in rows if x['kind']=='exact-word');pilot,_=read(P/('l1-7981-exact-reuse-unrestricted'+mode+'-r'+('16' if mode=='79' else '19')));old=[x for x in pilot if x['kind']=='exact-branch']
  assert len(branches)==len(old)==225 and all(all(x[k]==y[k] for k in fields) for x,y in zip(branches,old,strict=True))
  assert sum((F(*x['weight'])*x['raw_numerator']/x['divisor'] for x in branches),F())==F(*final['coefficient']) and max(x['peak_rows'] for x in branches)==5632
  assert final['coefficient']==[1165710661495982585955,35184372088832] and final['actual_unique_inputs']==154 and final['preparation_seconds']<600 and final['whole225_warm_seconds']<60
  cli[mode].update(native_final=final,all225_pilot_fields_equal=True)
 elif mode=='fixed':
  branches=[x for x in rows if x['kind']=='exact-fixed-branch'];assert len(branches)==450
  for w in (79,81):
   old,_=read(P/f'l1-7981-exact-reuse-r12-fixed-equivalence-{w}');old=[x for x in old if x['kind']=='fixed-equivalence-branch'];current=[x for x in branches if x['word']==w]
   assert len(current)==len(old)==225 and all(all(x[k]==y[k] for k in fields) for x,y in zip(current,old,strict=True))
  cli[mode]['all450_original_reconciled_fixed_fields_equal']=True
 else:
  census=next(x for x in rows if x['kind']=='source-sharing-square-two-protected-tori-census');assert census['valid_words']==[79,81]
manifest=next(json.loads(x) for x in (A/'l1_k4_census.out.txt').read_text().splitlines() if json.loads(x).get('kind')=='paired-k4-census');digest=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert digest=='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b';words={x['index']:x for x in manifest['rows']};assert len(words)==272
pop={}
for name in ('l1_k4_core42_receipts.jsonl','l1_k4_remaining48_receipts.jsonl','l1_k4_peeled86_receipts.jsonl','l1_k4_single_square6_receipts.jsonl','l1_k4_free_torus30_receipts.jsonl','l1_k4_two_square8_receipts.jsonl'):
 ids=[]
 for line in (A/name).read_text().splitlines():
  r=json.loads(line);i=r.get('word',r.get('index'));i=i['index'] if isinstance(i,dict) else i
  if i is not None:ids.append(i)
 pop[name]=ids
for name in ('l1_extended_offset_witness_k4_both_source_square_free_torus.py','l1_extended_offset_witness_k4_two_square_protected_torus.py','l1_extended_offset_witness_k4_two_protected_tori.py','l1_extended_offset_witness_k4_connected_source_square_torus.py','l1_extended_offset_witness_k4_shared_square_protected_free_tori.py'):
 t=ast.parse((A/name).read_text());pop[name]=list(next(ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='EXPECTED_WORDS' for x in n.targets)))
counts=Counter(i for ids in pop.values() for i in ids);assert len(counts)==234 and set(counts.values())=={1};before=set(counts);new={cli[str(w)]['native_final']['word']['index'] for w in (79,81)};assert new=={79,81} and not before&new
union=before|new;axes=Counter(tuple(words[i]['axes']) for i in union);assert axes=={(2,2):142,(2,3):94} and len(union)==236;remaining=sorted(set(words)-union);rem_axes=Counter(tuple(words[i]['axes']) for i in remaining);assert len(remaining)==36 and rem_axes=={(2,2):22,(2,3):14} and {161,163}<=set(remaining)
control,control_exit=read(P/'l1-7981-independent-unrestricted-r27-control');assert control_exit['actual_child_exit_code']==control_exit['driver_exit_code']==0 and control[-1]['branches']==450 and control[-1]['signed225_fullrow_covariance'] and control[-1]['scalar_contractions_run']==0
replay,replay_exit=read(P/'l1-7981-independent-unrestricted-r23-replay79');assert replay_exit['actual_child_exit_code']==replay_exit['driver_exit_code']==0 and replay[-1]['all225_reference_equalities']
coefficient=F(1165710661495982585955,35184372088832);subtotal=2*coefficient
verification={'status':'SUBMITTED for independent final delivery review; portable234 remains current until acceptance','source_sha256':sha(source),'manifest_sha256':digest,'previous_accepted_populations':pop,'previous_total':234,'qualifying_new_words':sorted(new),'class_disjoint':True,'candidate_total':236,'candidate_same':142,'candidate_mixed':94,'candidate_remaining':remaining,'remaining_same':22,'remaining_mixed':14,'coefficient_each':[coefficient.numerator,coefficient.denominator],'same_axis_subtotal_no_extra_factor':[subtotal.numerator,subtotal.denominator],'actual_portable_cli':cli,'independent_full450_originalL_fullrows':{'final':control[-1],'exit':control_exit},'fresh_full79_replay':{'final':replay[-1],'exit':replay_exit},'scope':'Complete selected family only. Fullk4/derivative-normalized source-action ensemble/commonZ/physical B3/modes/transport/main/human/publication remain open. Scoped source/runtime reviews and final archive acceptance are separate.'}
V=P/'l1-7981-delivery-verification-r36.json';V.write_text(json.dumps(verification,indent=2)+'\n')
