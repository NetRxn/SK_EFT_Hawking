"""PREPARED ONLY: independent original-L/full450 unrestricted prepared rows; NO scalar contractions."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
from itertools import product,combinations,combinations_with_replacement
from functools import cache
import runpy,hashlib,json,signal,time
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
SOURCE=P/'l1-7981-evaluator-exact-reuse-r12.py';EXPECTED='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
BINDING={'l1_direct_b_haar.py': '535d4233a51b89e44f8b9d9b8d01ed624b659d68f1ee9e10ec14efea060900b1', 'l1_extended_four_face_gauge_join.py': '4ddfbc8731cc8c8f546b4347c28718fc3917e131d3a5f461fef19f67122ec91b', 'l1_extended_mixed_center_gamma.py': 'a3dcaffb79e59a174b3a2816d207d8ced22e2bd11a9e05b8c9ea07a20d9c158d', 'l1_extended_mixed_curvature_core.py': '24f640e140b8ab179779f8fc9f5029c2484d834a8f79d5f134991822d2010242', 'l1_extended_mixed_frame_moment.py': '3d1e8d1e1281e6a27223224cf0cbb7dc0545e9c7c035951a0adabd97d9cf3137', 'l1_extended_offset_square.py': '32373f84a267f266e29dea45fa4fe4dc49823be288f1e37dc168dabf06c1793d', 'l1_extended_offset_witness.py': 'e558b5a3211ee2ff62bd4f9d8b06c762ba26d3e041eb8a70280fee7464a4dd0f', 'l1_extended_offset_witness_k2.py': '1d10dc5705e89e8d16cc9e6991b7547b2d8b67bb52e257505aa04259c85455d7', 'l1_extended_offset_witness_k3.py': 'fa1ef180c87707c6e9a4a13410890b77b04c3620774587a81d00dd9b34e2c73d', 'l1_extended_offset_witness_k4.py': 'b2b6027c9a3f13dab49b9c72efd09ecc9dbf1e6bf3ab9903fdb008ac79fd12e0', 'l1_extended_offset_witness_k4_free_torus.py': 'ba82ce5abdcc35dc0e4d98fe52fef1f275837f7063074babfb2cd95c0ab24109', 'l1_extended_offset_witness_k4_peeled.py': '7eb0114dec24a2cc0674c2e3e3865ffc34d12924f131868d95ad121c62d31a4c', 'l1_extended_offset_witness_k4_single_square.py': '4fd18a9a852ce9c1d331f9462f4436d7d8d41f6cd10f408e0dfa2c3aca2729dd', 'l1_extended_offset_witness_k4_two_square.py': '1bd858308e4ba5be3d9d25ce1b0d0a8695600b7b030e45e765d923c60610e78b', 'l1_extended_opposed_source.py': '06e16f2f83062b1b123bf2a6ce7150522114a43c2af06fb117e73823a6bc42f5', 'l1_extended_two_mixed_centers.py': '6f950654cc6e2650246dcb55623040f22e5a3bda7a5ce74c4ab7f0eaf9f628b2'}
REFERENCE_BINDING={'l1_normalization_opposed_fourth.py': 'e4df718d0ae922a477319b4efd902710c586d1bb73e50252f261c2cbf9941e69', 'l1_normalization_disjoint_sector.py': '5bb44725a1895eb2dfc2801aadc8b51946475893746dd7ec6790ba186b0f1300', 'l1_normalization_uniform_mixed_edge.py': '089d5bfd21e3bb2a25e2a914dadb261fab354888b9b7b1287a6b28b78e31768a'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(kind,**data):print(json.dumps(dict(kind=kind,**data),sort_keys=True),flush=True)
def bound():
 assert sha(SOURCE)==EXPECTED and len(BINDING)==16
 assert all(sha(A/n)==h for n,h in (BINDING|REFERENCE_BINDING).items())
start=time.perf_counter();signal.alarm(600);bound()
emit('independent450-unrestricted-start',source_sha256=EXPECTED,principal_source_sha256=BINDING,reference_source_sha256=REFERENCE_BINDING,inner_limit=600,scalar_contractions_run=0)
s=runpy.run_path(str(SOURCE),run_name='independent_7981_unrestricted_fullrows');assert s['source_hashes']()=={**BINDING,'evaluator':EXPECTED}
k2,k3=s['k2'],s['k3'];found=s['data']();context=s['_reuse_context']();assert list(found)==[79,81] and k2.ROW_CAP==120000 and k2.PAIR_CAP==3000000
from l1_direct_b_haar import R,add,scale,wedge
from l1_extended_opposed_source import frame,action_frame
from l1_normalization_opposed_fourth import nodes,L
from l1_normalization_uniform_mixed_edge import unit
# Independent quaternion polynomial reference, bound before executing function definitions only.
REFERENCE=P/'l1-7981-control-preparation-r2-quaternion-reference.py'
assert sha(REFERENCE)=='3520188b78f838b475814949104c8c64dc3c5dd3cff2ff57ba93024bdc642059'
# Select only mul/adj/hol/vector; no moments or reference eliminations are needed here.
import ast
rt=ast.parse(REFERENCE.read_text());exec(compile(ast.Module(body=[n for n in rt.body if isinstance(n,ast.FunctionDef) and n.name in ('mul','adj','hol','vector')],type_ignores=[]),str(REFERENCE),'exec'))
@cache
def original_weights(domain):
 out=Counter()
 for a,b,c,d in product(range(4),repeat=4):
  for i,u in L[a,c]:
   for j,v in L[b,d]:out[tuple(sorted((a,b))),tuple(sorted((c,d)))]+=u*v*(12*int(i==j) if domain is None else int(tuple(sorted((i,j))) in domain))
 return {k:v for k,v in out.items() if v}
def gaussian(poly,divisor=1):
 out={}
 for mask,v in poly.items():
  assert v.is_ground;re,im=int(v.const().x),int(v.const().y);assert re%divisor==im%divisor==0
  if re or im:out[mask]=(re//divisor,im//divisor)
 return out
def relocate(poly,sites):
 # Geometric local row relocation uses existing even-degree local convention.
 return {sum(((m>>(8*i))&255)<<(8*q) for i,q in enumerate(sites)):v for m,v in poly.items()}
@cache
def old_frame(anchor,center,left,right):
 t=action_frame(0,anchor^center,left,right)
 if center:return tuple(scale(relocate(v,(1,0)),-1) for v in t)
 return tuple(t)
RULE=tuple(nodes())
@cache
def anchor_integral(anchor,slots,fixed,probe):
 rule=(((2,0,0,0),(2,0,0,0),96),) if fixed else RULE;vals=[]
 for left,right,weight in rule:
  v={0:R.one}
  for center,gamma in slots:v=wedge(v,old_frame(anchor,center,tuple(left),tuple(right))[gamma])
  coords=tuple(left)+tuple(right);vals.append(scale(v,weight*(coords[probe[0]]*coords[probe[1]] if probe is not None else 1)))
 return add(*vals)
@cache
def edge_reference(labels,centers,fixed_anchor,probe_anchor,probe):
 slots=tuple((center,j) for center,pair in zip(centers,labels,strict=True) for j in pair);terms=[]
 for n in range(0,len(slots)+1,2):
  for chosen in combinations(range(len(slots)),n):
   terms.append(wedge(*(anchor_integral(a,tuple(slots[i] for i in range(len(slots)) if (i in chosen)==(a==0)),a==fixed_anchor,probe if a==probe_anchor else None) for a in (0,1))))
 # Original rule weights96 per anchor and reps2q vs canonical192 per anchor.
 # d raw coframes, and two additional quaternion powers for a probe.
 ratio=2**(len(slots)+(2 if probe is not None else 0)-2)
 assert ratio in (1,4);return gaussian(add(*terms),ratio)
@cache
def square_reference(square,live,fixed_items):
 fixed=dict(fixed_items);rows={};components=tuple(combinations_with_replacement(range(6),2));probes=tuple(combinations_with_replacement(range(8),2))
 for comp in components:
  def evalq(q):return vector(square,{**fixed,live:(q[:4],q[4:])},comp[0])*vector(square,{**fixed,live:(q[:4],q[4:])},comp[1])
  values={i:evalq(tuple(int(k==i) for k in range(8))) for i in range(8)}
  for a,b in probes:
   v=values[a] if a==b else evalq(tuple(int(k==a)+int(k==b) for k in range(8)))-values[a]-values[b]
   if v:rows[comp,(a,b)]=v
 return rows
identity=frame(0,False,unit(0),unit(0));source_ref=gaussian(scale(add(*(wedge(v,v) for v in identity)),192))
def reconstruct(g,core):
 square,=g.squares;live,=g.lives;sq=square_reference(square,live,tuple(sorted(g.fixed_square[square].items())));assert sq==k3.square_factor(square,live,g.fixed_square[square]);comps=sorted({comp for comp,p in sq});factors=[];choices={};empty_center=False
 liveedge=min(live[0],live[0]^(1<<live[1])),max(live[0],live[0]^(1<<live[1])),live[1]
 changed=set(g.fixed_edges)|set(g.joined_source)|{liveedge};exclusive={key for e,keys in g.edges.items() if len(keys)==1 and e not in changed for key in keys}
 for q,axes in sorted(g.frame.items()):
  keys=tuple((q,a) for a in axes);rows={}
  for comp in comps if q==square[0] else (None,):
   domain=(comp,) if comp is not None else core.get(q);key=None if domain is None else tuple(domain);weights=original_weights(key)
   assert weights==k3.witness.center_weights(domain)
   for gamma,weight in weights.items():
    if any(gamma[j][0]!=gamma[j][1] for j,k in enumerate(keys) if k in exclusive):continue
    rows[gamma+((comp,) if comp is not None else ())]={0:(weight,0)}
  if not rows:empty_center=True
  choices[q]=rows;factors.append((keys+((('square',0,'component'),) if q==square[0] else ()),rows,{}))
 if empty_center:return None
 for edge,keys in sorted(g.edges.items()):
  lo,hi,axis=edge;centers=tuple(int(q==hi) for q,a in keys);rows={}
  # These domains come only from independently reconstructed original-L center rows.
  domains=[sorted({row[g.frame[q].index(a)] for row in choices[q]}) for q,a in keys]
  for labels in product(*domains):
   for probe in sorted({p for comp,p in sq}) if edge==liveedge else (None,):
    local=edge_reference(labels,centers,g.fixed_edges.get(edge),int(live[0]==hi) if probe is not None else None,probe)
    if local:rows[labels+((probe,) if probe is not None else ())]=relocate(local,(lo,hi))
  if not rows:return None
  factors.append((tuple(keys)+((('square',0,'probe'),) if edge==liveedge else ()),rows,{lo:2*len(keys),hi:2*len(keys)}))
 factors.append(((('square',0,'component'),('square',0,'probe')),{key:{0:(v,0)} for key,v in sq.items()},{}))
 for q,a in g.sources:factors.append(((),{():relocate(source_ref,(q,q^(1<<a)))},{q:2,q^(1<<a):2}))
 return factors,g.divisor,exclusive

def shifted(poly):
 result={}
 for mask,(re,im) in poly.items():
  sign=(-1)**sum(((mask>>(8*q))&255).bit_count()*((mask>>(8*(q^1)))&255).bit_count() for q in range(0,16,2))
  m=sum(((mask>>(8*q))&255)<<(8*(q^1)) for q in range(16));result[m]=(sign*re,sign*im)
 return result

def normalize(factors):
 out=[]
 for keys,rows,degrees in factors:
  order=sorted(range(len(keys)),key=lambda i:repr(keys[i]));out.append((tuple(keys[i] for i in order),{tuple(labels[i] for i in order):poly for labels,poly in rows.items()},degrees))
 return sorted(out,key=lambda f:repr((f[0],sorted(f[2].items()))))

def translated(table):
 if table is None:return None
 factors,D,exclusive=table;out=[]
 for keys,rows,degrees in factors:
  newkeys=tuple((k[0]^1,k[1]) if isinstance(k[0],int) else k for k in keys)
  # Preserve key/row alignment here; normalize permutes both together.
  out.append((newkeys,{labels:shifted(poly) for labels,poly in rows.items()},{q^1:d for q,d in degrees.items()}))
 return normalize(out),D,{(q^1,a) for q,a in exclusive}
def protected(linked,other):
 yield Fraction(1,256),dict.fromkeys(linked+other,tuple((i,i) for i in range(6)))
 for c in (0,3):
  ds=tuple((i,i) for i in range(c,c+3));yield Fraction(-1,559872),dict.fromkeys(linked+other,ds)
  for pair in combinations_with_replacement(range(c,c+3),2):yield Fraction(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:ds,other[1]:ds}
expected=[(w*v,c|d) for w,c in protected((0,4),(8,12)) for v,d in protected((1,5),(9,13))]
retained79=[];summaries={};compared=0
for word,(row,g) in found.items():
 branches=list(s['branches'](g));assert branches==expected and len(branches)==225 and sum(w<0 for w,c in branches)==52
 nonempty=empty=0;center_rows=edge_rows=0
 for index,(weight,core) in enumerate(branches):
  assert s['_reuse_context']()==context;bound()
  expected_table=reconstruct(g,core);actual=s['prepare'](g,core)
  assert actual==expected_table
  if actual is None:empty+=1
  else:
   nonempty+=1;factors,D,exclusive=actual;counts=Counter(k for keys,rs,ds in factors for k in keys)
   assert D==192**42*4**64*48**6*2**15 and len(factors)==38 and len(counts)==32 and set(counts.values())=={2} and {q:sum(ds.get(q,0) for ks,rs,ds in factors) for q in range(16)}==dict.fromkeys(range(16),8)
   center_rows+=sum(len(rows) for keys,rows,ds in factors[:15]);edge_rows+=sum(len(rows) for keys,rows,ds in factors[15:35])
  if word==79:retained79.append(actual)
  else:
   i,j=divmod(index,15);sourceindex=15*j+i
   assert {q^1:d for q,d in branches[sourceindex][1].items()}==core and branches[sourceindex][0]==weight
   prior=translated(retained79[sourceindex]);current=None if actual is None else (normalize(actual[0]),actual[1],actual[2]);assert prior==current;compared+=1
  assert s['_reuse_context']()==context;bound()
  # Large expected reconstruction is not retained across branches or words.
  del expected_table
 summaries[word]={'branches':225,'nonempty':nonempty,'structural_empty':empty,'center_rows_checked':center_rows,'edge_rows_checked':edge_rows}
 emit('independent225-unrestricted-prepared',word=word,**summaries[word],all_original_L_fullrows_equal=True,scalar_contractions_run=0)
assert compared==225;bound();assert s['source_hashes']()=={**BINDING,'evaluator':EXPECTED};signal.alarm(0)
emit('independent450-unrestricted-complete',branches=450,words=summaries,all_fullcenter_weights_original_L=True,all_fullaction_rows_original_cubature=True,square_source_independent=True,signed225_fullrow_covariance=True,scalar_contractions_run=0,unrestricted_coefficients_run=0,seconds=time.perf_counter()-start,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP,source_sha256=EXPECTED)
