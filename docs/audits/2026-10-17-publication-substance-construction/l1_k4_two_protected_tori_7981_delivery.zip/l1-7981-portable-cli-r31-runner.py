"""Prepared actual installed CLI budget wrapper. Separate SOURCE review/admission required."""
from pathlib import Path
import sys,runpy,signal,time,json,hashlib
AUDIT=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction').resolve()
SCRIPT=AUDIT/'l1_extended_offset_witness_k4_source_sharing_square_two_protected_tori.py'
EXPECTED='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
MANIFEST='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b'
BINDING={'l1_direct_b_haar.py': '535d4233a51b89e44f8b9d9b8d01ed624b659d68f1ee9e10ec14efea060900b1', 'l1_extended_four_face_gauge_join.py': '4ddfbc8731cc8c8f546b4347c28718fc3917e131d3a5f461fef19f67122ec91b', 'l1_extended_mixed_center_gamma.py': 'a3dcaffb79e59a174b3a2816d207d8ced22e2bd11a9e05b8c9ea07a20d9c158d', 'l1_extended_mixed_curvature_core.py': '24f640e140b8ab179779f8fc9f5029c2484d834a8f79d5f134991822d2010242', 'l1_extended_mixed_frame_moment.py': '3d1e8d1e1281e6a27223224cf0cbb7dc0545e9c7c035951a0adabd97d9cf3137', 'l1_extended_offset_square.py': '32373f84a267f266e29dea45fa4fe4dc49823be288f1e37dc168dabf06c1793d', 'l1_extended_offset_witness.py': 'e558b5a3211ee2ff62bd4f9d8b06c762ba26d3e041eb8a70280fee7464a4dd0f', 'l1_extended_offset_witness_k2.py': '1d10dc5705e89e8d16cc9e6991b7547b2d8b67bb52e257505aa04259c85455d7', 'l1_extended_offset_witness_k3.py': 'fa1ef180c87707c6e9a4a13410890b77b04c3620774587a81d00dd9b34e2c73d', 'l1_extended_offset_witness_k4.py': 'b2b6027c9a3f13dab49b9c72efd09ecc9dbf1e6bf3ab9903fdb008ac79fd12e0', 'l1_extended_offset_witness_k4_free_torus.py': 'ba82ce5abdcc35dc0e4d98fe52fef1f275837f7063074babfb2cd95c0ab24109', 'l1_extended_offset_witness_k4_peeled.py': '7eb0114dec24a2cc0674c2e3e3865ffc34d12924f131868d95ad121c62d31a4c', 'l1_extended_offset_witness_k4_single_square.py': '4fd18a9a852ce9c1d331f9462f4436d7d8d41f6cd10f408e0dfa2c3aca2729dd', 'l1_extended_offset_witness_k4_two_square.py': '1bd858308e4ba5be3d9d25ce1b0d0a8695600b7b030e45e765d923c60610e78b', 'l1_extended_opposed_source.py': '06e16f2f83062b1b123bf2a6ce7150522114a43c2af06fb117e73823a6bc42f5', 'l1_extended_two_mixed_centers.py': '6f950654cc6e2650246dcb55623040f22e5a3bda7a5ce74c4ab7f0eaf9f628b2'}

def emit(kind,**values):print(json.dumps(dict(kind=kind,**values),sort_keys=True),flush=True)
def _pin_installed():
 assert SCRIPT.is_file() and SCRIPT.resolve().parent==AUDIT
 assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest()==EXPECTED
 assert len(BINDING)==16
 for name,expected in BINDING.items():
  path=AUDIT/name
  assert path.resolve().parent==AUDIT and hashlib.sha256(path.read_bytes()).hexdigest()==expected
 manifest=next(json.loads(line) for line in (AUDIT/'l1_k4_census.out.txt').read_text().splitlines() if json.loads(line).get('kind')=='paired-k4-census')
 assert hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()==MANIFEST
 assert (AUDIT/'l1_extended_offset_witness_k3.py').is_file()
 return {'script':str(SCRIPT),'AUDIT':str(AUDIT),'source_sha256':{**BINDING,'evaluator':EXPECTED},'manifest_sha256':MANIFEST}
def _runtime_proof(namespace):
 proof=_pin_installed()
 assert namespace['__name__']=='__main__' and Path(namespace['__file__']).resolve()==SCRIPT
 assert namespace['AUDIT'].resolve()==AUDIT
 assert namespace['EXPECTED_MANIFEST_SHA256']==MANIFEST
 assert namespace['source_hashes']()=={**BINDING,'evaluator':EXPECTED}
 for name in BINDING:
  assert Path(sys.modules[name[:-3]].__file__).resolve().parent==AUDIT
 return proof

def main():
 mode=sys.argv[1];assert mode in ('census','fixed','79','81')
 full=mode in ('79','81');limit=600 if full else (30 if mode=='census' else 60)
 signal.alarm(limit);start=time.perf_counter();binding=_pin_installed()
 assert all(name[:-3] not in sys.modules for name in BINDING)
 args=[] if mode=='census' else ['--controls-only'] if mode=='fixed' else ['--word',mode]
 native_argv=[str(SCRIPT),*args];prior=sys.argv;state={'entries':0,'proof':None}
 emit('portable-cli-wrapper-start',mode=mode,native_argv=native_argv,initial_alarm_seconds=limit,**binding)
 def entry_budget(frame,event,arg):
  if event!='call' or frame.f_code.co_name!='contract_frozen' or frame.f_code.co_filename!=str(SCRIPT):return
  assert frame.f_globals['__name__']=='__main__' and state['entries']==0
  state['entries']+=1;sys.setprofile(None);signal.alarm(60)
  state['proof']=_runtime_proof(frame.f_globals)
 if full:sys.setprofile(entry_budget)
 try:
  sys.argv=native_argv
  namespace=runpy.run_path(str(SCRIPT),run_name='__main__')
  assert state['entries']==(1 if full else 0)
  proof=_runtime_proof(namespace)
  emit('portable-cli-wrapper-complete',mode=mode,native_argv=native_argv,warm_entry_hooks=state['entries'],actual_seconds=time.perf_counter()-start,**proof)
  signal.alarm(0)
 finally:
  sys.setprofile(None);sys.argv=prior
if __name__=='__main__':main()
