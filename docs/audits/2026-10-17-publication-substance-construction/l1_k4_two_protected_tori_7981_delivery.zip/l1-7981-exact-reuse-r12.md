# Exact reuse r12: narrow r11 source-review corrections

Ready for independent r13 SOURCE review; no scientific runtime is admitted or performed. Initial r12 continuity check was fresh. All work used immutable scientific bytes, existing scratch receipts, stdlib source/AST operations and the actual helper tests with only forbidden scientific dependency fixtures. No mutable citation/constants/state read, candidate/primary/notebook/Git/controller write, scientific import, factor preparation, fixed/unrestricted contraction or profiling occurred.

New evaluator `/tmp/l1-7981-evaluator-exact-reuse-r12.py` SHA256 `2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10`. Its exact r10 diff is `/tmp/l1-7981-exact-reuse-r12-vs-r10.diff`. Source-control hashes and unchanged-input checks are in `/tmp/l1-7981-exact-reuse-r12-source-controls.json`. The rejected r10 source, tests, reports, diffs and future drivers remain byte-identical to their captured hashes; r11 reviewer artifacts were read only.

## Required source-hash binding

R11's rejection is confirmed: old `_reuse_context` never consulted the actual source fingerprint. The new source adds only the accepted16 literal sibling hashes and four narrow context lines: call actual unchanged `source_hashes`, require exactly those16 plus evaluator, assert all16 match accepted hashes, and include the complete actual17-file fingerprint in the existing context tuple. Its existing checks therefore validate source fingerprint cold, before warm, before each lookup, after a first unique kernel returns before insertion, and after each callback. Evaluator drift changes the captured fingerprint even though a self-referential literal evaluator hash cannot live inside its own file; the outer runner separately pins the expected new evaluator hash before imports. All guard work is inside the same existing cold/warm allowances.

No classifier, new algorithm or context framework was added. `_freeze_label`, `freeze_prepared` and `contract_frozen` ASTs remain identical to r10, including the complete ordered immutable descriptors, private first-unique inputs, exact equality, per-branch localD-before-lookup assertion, attempt-local successful-only raw/peak cache, structural None distinction, kernel/cap checks and225 own weighted records. All eleven original e4 nonmain scientific/baseline ASTs and all sixteen sibling bytes remain unchanged. The source helper's actual `source_hashes` AST is unchanged and reports the current r12 evaluator's own actual file hash.

## Test-first evidence

Before creating r12 production source, the new fingerprint tests ran actual r10 helper ASTs with a fake fingerprint provider as the sole new test dependency. `/tmp/l1-7981-exact-reuse-r12-fingerprint-red.err` records three tests/five expected assertion failures: evaluator and dependency drift before warm, evaluator drift inside the kernel, and drift in first/final callbacks were not refused. This reproduces r11's225-record provenance gap and is the intended RED.

One earlier test-file generation command had an author script `NameError: P is not defined` before it wrote the new test file. It did not execute tests, alter r10, or qualify as a red; the corrected generator is `/tmp/l1-7981-exact-reuse-r12-prepare-tests.py`. No other new unexpected test error occurred.

After the narrow implementation, `/tmp/l1-7981-exact-reuse-r12-green-r2.err` reports19 tests OK in0.313s: all15 old behavioral controls plus before-warm/inside-kernel/callback fingerprint drift and accepted-dependency rejection before cold snapshot. They execute actual new helper/main ASTs; the fingerprint provider is controlled test data, not a mock of the guard. The original15 r10 controls/files remain immutable. No source fingerprint is read through scientific imports by these tests.

The source checker confirmed accepted16 literal pins in both evaluator and runner, the runner pin assertion's AST position before actual `runpy.run_path`, unchanged11 baseline ASTs, unchanged freeze/private-input/cache ASTs, all captured r10 artifact hashes, sixteen sibling hashes, and original fixed79/81 and failed unrestricted79 stream hashes. No154 class or timing claim follows from these stdlib checks.

## New prepared fixed-equivalence package

`/tmp/l1-7981-exact-reuse-r12-fixed-equivalence-runner.py` SHA256 `5f4715c06105a3b42ceca1aaf1e9ecc3ab09ff044a90b1b105dca8b1892faddf` pins the evaluator hash and all accepted16 literal sibling file hashes BEFORE `runpy` imports any scientific module. After import it requires the full actual17-file map equal accepted16 plus the expected r12 evaluator hash. The actual optimized helper continues checking that map at every original context boundary; the runner also checks the complete binding after execution.

It retains one600cold interval for imports/preparation/freeze/snapshot and ONE60s WHOLE225 warm interval covering baseline, exact reuse, equality/reduction and all225 emitted records. New actual `baseline_seconds` and `reuse_seconds` separately meter the two calls; the combined warm time remains separately emitted. Neither call moved cold and neither receives a separate60s allowance. Original factor objects and all per-branch raw/weight/divisor/fraction/peak/structural flags remain compared.

`/tmp/l1-7981-exact-reuse-r12-fixed-equivalence-driver.py` SHA256 `6a586e024aa27e4a3535a534cf4c037543b7a19ef5f9585b6c60e428ee8310b4` binds that runner, accepts79/81 only, uses exclusive new r12 per-word output paths and665s parent. Original120000-row/3000000-pair caps and failure-preserving semantics remain. The runner-vs-r10 exact diff is `/tmp/l1-7981-exact-reuse-r12-runner-vs-r10.diff`. Both scripts were compiled only and remain NOT RUN.

Independent r13 source acceptance and fresh ROOT admission are still required for any scientific run. Full450 fixed baseline/original-receipt/transpose acceptance must precede a fresh complete225 unrestricted79 attempt. Actual full-input classes, memory cost, guard I/O cost and speedup are UNKNOWN. Portable234 and the original failed218/225 attempt remain unchanged; no class/portable/fullphysics/publication acceptance is inferred.
