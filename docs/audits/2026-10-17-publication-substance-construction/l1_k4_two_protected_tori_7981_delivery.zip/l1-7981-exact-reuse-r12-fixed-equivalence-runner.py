"""Prepared future fixed equivalence control; separate ROOT admission required."""
import sys,json,runpy,signal,time,hashlib
from pathlib import Path
from copy import deepcopy
P=Path('/tmp');SOURCE=P/'l1-7981-evaluator-exact-reuse-r12.py';EXPECTED='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
word=int(sys.argv[1]);assert word in (79,81)
start=time.perf_counter();signal.alarm(600)
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==EXPECTED
EXPECTED_SIBLINGS={'l1_direct_b_haar.py': '535d4233a51b89e44f8b9d9b8d01ed624b659d68f1ee9e10ec14efea060900b1', 'l1_extended_four_face_gauge_join.py': '4ddfbc8731cc8c8f546b4347c28718fc3917e131d3a5f461fef19f67122ec91b', 'l1_extended_mixed_center_gamma.py': 'a3dcaffb79e59a174b3a2816d207d8ced22e2bd11a9e05b8c9ea07a20d9c158d', 'l1_extended_mixed_curvature_core.py': '24f640e140b8ab179779f8fc9f5029c2484d834a8f79d5f134991822d2010242', 'l1_extended_mixed_frame_moment.py': '3d1e8d1e1281e6a27223224cf0cbb7dc0545e9c7c035951a0adabd97d9cf3137', 'l1_extended_offset_square.py': '32373f84a267f266e29dea45fa4fe4dc49823be288f1e37dc168dabf06c1793d', 'l1_extended_offset_witness.py': 'e558b5a3211ee2ff62bd4f9d8b06c762ba26d3e041eb8a70280fee7464a4dd0f', 'l1_extended_offset_witness_k2.py': '1d10dc5705e89e8d16cc9e6991b7547b2d8b67bb52e257505aa04259c85455d7', 'l1_extended_offset_witness_k3.py': 'fa1ef180c87707c6e9a4a13410890b77b04c3620774587a81d00dd9b34e2c73d', 'l1_extended_offset_witness_k4.py': 'b2b6027c9a3f13dab49b9c72efd09ecc9dbf1e6bf3ab9903fdb008ac79fd12e0', 'l1_extended_offset_witness_k4_free_torus.py': 'ba82ce5abdcc35dc0e4d98fe52fef1f275837f7063074babfb2cd95c0ab24109', 'l1_extended_offset_witness_k4_peeled.py': '7eb0114dec24a2cc0674c2e3e3865ffc34d12924f131868d95ad121c62d31a4c', 'l1_extended_offset_witness_k4_single_square.py': '4fd18a9a852ce9c1d331f9462f4436d7d8d41f6cd10f408e0dfa2c3aca2729dd', 'l1_extended_offset_witness_k4_two_square.py': '1bd858308e4ba5be3d9d25ce1b0d0a8695600b7b030e45e765d923c60610e78b', 'l1_extended_opposed_source.py': '06e16f2f83062b1b123bf2a6ce7150522114a43c2af06fb117e73823a6bc42f5', 'l1_extended_two_mixed_centers.py': '6f950654cc6e2650246dcb55623040f22e5a3bda7a5ce74c4ab7f0eaf9f628b2'}
AUDIT=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
# Pin immutable accepted dependencies BEFORE any scientific module import.
assert all(hashlib.sha256((AUDIT/name).read_bytes()).hexdigest()==expected for name,expected in EXPECTED_SIBLINGS.items())
s=runpy.run_path(str(SOURCE),run_name='fixed_equivalence_source');binding=s['source_hashes']();assert binding=={**EXPECTED_SIBLINGS,'evaluator':EXPECTED}
row,g=s['data']()[word];restriction=dict.fromkeys(g.frame,s['k3'].witness.FIXED_GAMMAS)
prepared=s['prepare_branches'](g,restriction);frozen=s['freeze_prepared'](prepared,g.divisor);original=deepcopy(prepared)
assert len(prepared)==frozen.branches==225 and s['k2'].ROW_CAP==120000 and s['k2'].PAIR_CAP==3000000
cold=time.perf_counter()-start
print(json.dumps({'kind':'phase-complete','phase':'cold-fixed-equivalence','word':word,'seconds':cold,'branches':225,'actual_unique_inputs':frozen.unique_inputs,'source_sha256':binding,'scope':'FIXEDgamma baseline versus exact reuse only'}),flush=True)
signal.alarm(60);warm=time.perf_counter();baseline=[];reused=[]
assert s['_reuse_context']()==frozen.context
baseline_start=time.perf_counter();a=s['contract_prepared'](prepared,g.divisor,baseline.append)
baseline_seconds=time.perf_counter()-baseline_start
reuse_start=time.perf_counter();b=s['contract_frozen'](frozen,g.divisor,reused.append)
reuse_seconds=time.perf_counter()-reuse_start
assert a==b and prepared==original and len(baseline)==len(reused)==225
fields=('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows')
for first,second in zip(baseline,reused,strict=True):
 assert all(first[k]==second[k] for k in fields)
 print(json.dumps({'kind':'fixed-equivalence-branch','word':word,**second}),flush=True)
elapsed=time.perf_counter()-warm;assert s['source_hashes']()==binding;signal.alarm(0)
print(json.dumps({'kind':'fixed-equivalence-word','word':word,'coefficient':[a[0].numerator,a[0].denominator],'peak_rows':a[1],'branches':225,'actual_unique_inputs':frozen.unique_inputs,'prepared_objects_unchanged':prepared==original,'all_raw_weight_fraction_divisor_peak_structural_flags_equal':True,'cold_seconds':cold,'whole225_baseline_and_reuse_warm_seconds':elapsed,'baseline_seconds':baseline_seconds,'reuse_seconds':reuse_seconds,'source_sha256':binding,'unrestricted':'NOT RUN'}),flush=True)
