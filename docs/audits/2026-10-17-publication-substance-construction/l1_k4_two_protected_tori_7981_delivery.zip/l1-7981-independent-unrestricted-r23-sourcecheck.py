from pathlib import Path
from fractions import Fraction as F
from itertools import product
from collections import Counter
import ast,json,hashlib,runpy,types,copy
P=Path('/tmp');control=P/'l1-7981-independent-unrestricted-r23-control.py';replay=P/'l1-7981-independent-unrestricted-r23-replay79-runner.py';files=[control,P/'l1-7981-independent-unrestricted-r23-control-driver.py',replay,P/'l1-7981-independent-unrestricted-r23-replay79-driver.py'];trees={p.name:ast.parse(p.read_text()) for p in files};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in files:compile(trees[p.name],str(p),'exec')
assert sha(P/'l1-7981-independent-fixed-review-r4-control.py')=='8815633e951e5833157b9c324280aa19f0936d2133a436e1c25842f3b7c810a8'
t=trees[control.name];funcs={n.name:n for n in t.body if isinstance(n,ast.FunctionDef)};calls=[n for n in ast.walk(t) if isinstance(n,ast.Call)];preps=[n for n in calls if ast.unparse(n.func)=="s['prepare']"];assert len(preps)==1 and len(preps[0].args)==2 and not preps[0].keywords
assert not any(any(x in ast.unparse(n.func) for x in ['contract_frozen','contract_prepared','eliminate_components']) for n in calls)
old=ast.parse((P/'l1-7981-independent-fixed-review-r4-control.py').read_text());oldf={n.name:n for n in old.body if isinstance(n,ast.FunctionDef)}
for name in ['original_weights','gaussian','relocate','old_frame','anchor_integral','edge_reference','square_reference','shifted','normalize','translated']:
 assert ast.dump(funcs[name],include_attributes=False)==ast.dump(oldf[name],include_attributes=False)
# Actual full reconstruction AST with explicit domain/cubature fixtures: covers all gammas,
# actual slot extraction, Cartesian rows and exclusive filtering, no scientific primitives run.
gammas={((0,0),(1,1)):5,((0,1),(2,2)):7,((3,3),(1,2)):11};sq={((0,0),(1,1)):2,((0,1),(2,2)):3};g=types.SimpleNamespace(squares=((0,0,1),),lives=((0,1),),fixed_square={(0,0,1):{}},fixed_edges={},joined_source={},edges={(0,1,0):[(0,0),(1,0)],(0,2,1):[(0,1)],(1,3,1):[(1,1)]},frame={0:(0,1),1:(0,1)},sources=(),divisor=12);seen=[]
def edge(labels,centers,fixed,anchor,probe):seen.append((labels,centers,anchor,probe));return {0:(sum(x+y for x,y in labels)+1,0)}
ns={'square_reference':lambda *a:sq,'k3':types.SimpleNamespace(square_factor=lambda *a:sq,witness=types.SimpleNamespace(center_weights=lambda d:gammas)),'original_weights':lambda d:gammas,'edge_reference':edge,'product':product,'source_ref':{0:(1,0)}}
for name in ('relocate','reconstruct'):exec(compile(ast.Module(body=[funcs[name]],type_ignores=[]),'<actual-full-reconstruction-fixture>','exec'),ns)
factors,D,exclusive=ns['reconstruct'](g,{})
assert len(factors[0][1])==6 and len(factors[1][1])==2 and [len(f[1]) for f in factors[2:5]]==[6,6,2] and exclusive=={(1,1)}
assert any(labels==((1,2),) and anchor==0 for labels,centers,anchor,probe in seen)
# Actual independent replay compare/emitter and warm controller + reviewed source helper AST.
mod=runpy.run_path(str(P/'l1-7981-exact-reuse-r12-tests.py'),run_name='r23_stdlib_helper_fixture');rt=trees[replay.name];callback=next(n for n in rt.body if isinstance(n,ast.FunctionDef) and n.name=='compare_and_emit');begin=next(i for i,n in enumerate(rt.body) if isinstance(n,ast.Expr) and ast.unparse(n)=='signal.alarm(60)');mock_results=[]
for failure in (False,True):
 n=mod['namespace']();expected=sha(P/'l1-7981-evaluator-exact-reuse-r12.py');n['test_fingerprint']['evaluator']=expected
 if failure:
  def raised(f,e):raise RuntimeError('original cap failure')
  n['k3'].eliminate_components=raised
 prepared=[(F(1),copy.deepcopy(mod['graph']())) for i in range(225)];frozen=n['freeze_prepared'](prepared,12);reference=[{'branch':i,'weight':[1,1],'raw_numerator':6,'divisor':12,'coefficient':[1,2],'algebraic_empty_preparation':False,'peak_rows':9} for i in range(225)];emitted=[];alarms=[];ticks=iter([1.,2.,3.]);env={'F':F,'records':[],'weighted':F(),'weighted_raw':F(),'peak':0,'representatives':0,'reuse':0,'weights':[F(1)]*225,'reference':reference,'reference_final':{'coefficient':[225,2],'raw_numerator':1350,'peak_rows':9},'D':12,'fields':('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows'),'emit':lambda kind,**kw:emitted.append({'kind':kind,**kw}),'signal':types.SimpleNamespace(alarm=alarms.append),'time':types.SimpleNamespace(perf_counter=lambda:next(ticks)),'s':n,'frozen':frozen,'cold':10.,'start':0.,'bound':lambda:None,'BINDING':{k:v for k,v in n['test_fingerprint'].items() if k!='evaluator'},'EXPECTED':expected,'REFERENCE_SHA256':'opaque-fixture'}
 exec(compile(ast.Module(body=[callback],type_ignores=[]),'<actual-replay-callback>','exec'),env);error=None
 try:exec(compile(ast.Module(body=rt.body[begin:],type_ignores=[]),'<actual-independent-replay-warm>','exec'),env)
 except RuntimeError as e:error=str(e)
 if failure:assert error=='original cap failure' and not any(r['kind']=='independent-replay-exact-word' for r in emitted) and alarms==[60]
 else:assert len(env['records'])==225 and emitted[-1]['coefficient']==[225,2] and len(n['seen'])==1 and alarms==[60,0]
 mock_results.append({'failure':failure,'records':len(env['records']),'alarms':alarms,'final':any(r['kind']=='independent-replay-exact-word' for r in emitted)})
for p in files:
 if p.name.endswith('driver.py'):
  txt=p.read_text();assert 'timeout=665' in txt and "open('xb')" in txt
  target=control if 'control-driver' in p.name else replay;assert sha(target) in txt
result={'status':'PREPARED ONLY; stdlib actual-AST source controls PASS','scientific_imports_preparations_moments_runs':False,'files_sha256':{str(p):sha(p) for p in files},'original_fixed_control_unchanged':True,'independent_primitives10_AST_unchanged':True,'full_unrestricted_reconstruction_actual_AST_fixture':{'square_center_rows':6,'ordinary_center_rows':2,'action_cartesian_rows':[6,6,2],'offdiagonal_global_slot1_live_exercised':True,'exclusive_filter_exercised':True},'actual_independent_replay_controller_and_emitter_mocks':mock_results,'admission':'Nonauthor source review and fresh ROOT runtime admission required','performance':'Unmeasured; original-L allrow cubature may fail600budget, must preserve any failure; no reduced row/branch scope permitted'};(P/'l1-7981-independent-unrestricted-r23-sourcecheck.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
