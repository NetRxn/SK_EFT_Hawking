from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from collections import defaultdict
import json,hashlib
P=Path('/tmp');R=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103');A=R/'docs/audits/2026-10-17-publication-substance-construction';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();binding=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text())['principal_source_sha256'];assert all(sha(A/n)==h for n,h in binding.items());source=P/'l1-7981-evaluator-exact-reuse-r12.py';assert sha(source)=='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10'
def protected(linked,other):
 yield F(1,256),dict.fromkeys(linked+other,tuple((i,i) for i in range(6)))
 for c in (0,3):
  ds=tuple((i,i) for i in range(c,c+3));yield F(-1,559872),dict.fromkeys(linked+other,ds)
  for pair in combinations_with_replacement(range(c,c+3),2):yield F(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:ds,other[1]:ds}
expected=[(w*v,c|d) for w,c in protected((0,4),(8,12)) for v,d in protected((1,5),(9,13))];D=192**42*4**64*48**6*2**15;records={};summaries={};files={}
for word,stem,runnerhash in [(79,'l1-7981-exact-reuse-unrestricted79-r16','38180221e4b75e90fbe9425b346354cab0b4730264114fea1051d932fed9552c'),(81,'l1-7981-exact-reuse-unrestricted81-r19','24f17e3894a572ffc95ab96bbba052dc6795b175559dd6f64fd70c541ba0edda')]:
 paths=[P/(stem+s) for s in ['.out','.err','.exit.json','-runner.py','-driver.py']];rs=[json.loads(l) for l in paths[0].read_text().splitlines()];ex=json.loads(paths[2].read_text());first,prep,warm=rs[:3];bs,last=rs[3:-1],rs[-1];assert ex['actual_child_exit_code']==ex['driver_exit_code']==0 and not ex['parent_timeout'] and not paths[1].read_bytes() and ex['complete_raw_branch_records']==225 and ex['truncated_or_nonJSON_lines']==0
 assert sha(paths[3])==runnerhash==first['runner_sha256']==last['runner_sha256']==ex['runner_sha256'] and first['source_sha256']==last['source_sha256']==ex['source_sha256']==sha(source) and first['principal_source_sha256']==binding
 assert ex['cold_limit_seconds']==600 and ex['whole225_warm_limit_seconds']==60 and ex['parent_wall_limit_seconds']==665 and ex['parent_seconds']<665 and prep['seconds']==last['preparation_seconds']<600 and last['whole225_warm_seconds']<60
 assert first['word']==prep['word']==last['word']==word and last['kind']=='exact-word' and last['restrictions']==prep['restrictions']=={} and len(bs)==len(prep['support_domains'])==225 and prep['row_cap']==120000 and prep['pair_cap']==3000000
 total=F();raw=F();classes=defaultdict(set);nrep=reuse=zeros=0
 for i,(b,s,(weight,domain)) in enumerate(zip(bs,prep['support_domains'],expected,strict=True)):
  assert b['kind']=='exact-branch' and b['word']==word and b['branch']==s['branch']==i and F(*b['weight'])==F(*s['weight'])==weight and b['divisor']==D and F(*b['coefficient'])==F(b['raw_numerator'],D)
  assert {q:tuple(tuple(p) for p in ds) for q,ds in s['core_domains']}==domain and not b['algebraic_empty_preparation'] and not s['structural_empty_preparation'];total+=weight*F(*b['coefficient']);raw+=weight*b['raw_numerator'];zeros+=b['raw_numerator']==0
  audit=s['prepared_graph'];assert audit['factors']==38 and audit['labels']==32 and audit['all_labels_twice'] and {int(q):d for q,d in audit['site_degrees'].items()}==dict.fromkeys(range(16),8) and len(audit['center_support'])==15 and len(audit['source_factors'])==2
  rep=b['representative_branch'];classes[rep].add(i)
  if b['reused_contraction']:reuse+=1;assert rep<i and not bs[rep]['reused_contraction'] and all(b[k]==bs[rep][k] for k in ['raw_numerator','divisor','coefficient','peak_rows'])
  else:nrep+=1;assert rep==i
 assert nrep==len(classes)==prep['actual_unique_inputs']==last['actual_unique_inputs']==154 and reuse==71 and zeros==144 and max(b['peak_rows'] for b in bs)==last['peak_rows']==5632
 assert total==F(*last['coefficient'])==F(1165710661495982585955,35184372088832) and raw.denominator==1 and raw.numerator==last['raw_numerator'] and last['divisor']==prep['divisor']==D
 records[word]=(prep,bs,last,classes);summaries[str(word)]={'branches':225,'classes':154,'reuse':71,'computedzeros':144,'structuralempty':0,'negativeweights':52,'coefficient':last['coefficient'],'peak':5632,'cold':last['preparation_seconds'],'whole225warm':last['whole225_warm_seconds'],'parent':ex['parent_seconds'],'actual_child_driver_exit':[0,0]};files.update({str(p):sha(p) for p in paths})
ap,ab,al,ac=records[79];bp,bb,bl,bc=records[81]
for i in range(15):
 for j in range(15):
  aa,bbidx=15*i+j,15*j+i;a,b=ab[aa],bb[bbidx];assert all(a[k]==b[k] for k in ['weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows']);x,y=ap['support_domains'][aa],bp['support_domains'][bbidx]
  assert {q^1:ds for q,ds in x['core_domains']}==dict(y['core_domains']);xx=x['prepared_graph'];yy=y['prepared_graph'];assert {int(q)^1:d for q,d in xx['site_degrees'].items()}=={int(q):d for q,d in yy['site_degrees'].items()}
  assert {c['center']^1:{k:v for k,v in c.items() if k!='center'} for c in xx['center_support']}=={c['center']:{k:v for k,v in c.items() if k!='center'} for c in yy['center_support']}
  yf={tuple(f['source']):f for f in yy['source_factors']}
  for f in xx['source_factors']:
   g=yf[f['source'][0]^1,f['source'][1]];shift=[]
   for v in f['polynomial']:
    mask=v['mask'];sign=(-1)**sum(((mask>>(8*q))&255).bit_count()*((mask>>(8*(q^1)))&255).bit_count() for q in range(0,16,2));mm=sum(((mask>>(8*q))&255)<<(8*(q^1)) for q in range(16));shift.append((mm,sign*v['real'],sign*v['imag']))
   assert sorted(shift)==sorted((v['mask'],v['real'],v['imag']) for v in g['polynomial']) and {int(q)^1:d for q,d in f['degrees'].items()}=={int(q):d for q,d in g['degrees'].items()}
# Mathematical class partitions may use different first representatives in source order.
trans=lambda k:15*(k%15)+k//15
assert {frozenset(trans(k) for k in group) for group in ac.values()}=={frozenset(group) for group in bc.values()}
ag,bg=ap['geometry'],bp['geometry'];assert ag['word']['omitted']^1==bg['word']['omitted'] and sorted((q^1,axes) for q,axes in ag['word']['changes'])==sorted((q,axes) for q,axes in bg['word']['changes']);assert sorted((q^1,axis) for q,axis in ag['joint_forest'])==sorted(tuple(e) for e in bg['joint_forest']);assert [[q^1,a,b] for q,a,b in ag['squares']]==bg['squares'] and [[q^1,a] for q,a in ag['lives']]==bg['lives'];assert al['raw_numerator']==bl['raw_numerator']
result={'verdict':'ACCEPT complete paired79/81 unrestricted receipts/arithmetic and recorded signed transpose; not full-row/replay/portable acceptance','packet':'publication-7981-unrestricted-pair-r22.json','first_check_exit':0,'first_check_fresh':True,'checker_exit':0,'words':summaries,'all450weight_domain_raw_D_fraction_final_reductions':True,'signed225raw_weight_peak_sourcepolynomial_core_center_degree_covariance':True,'actual154class_partitions_covariant':True,'full17source_bindings':{'accepted16':binding,'evaluator':sha(source)},'files_sha256':files,'required_corrections':[],'scientific_imports_preps_runs':False,'owed':['Independent actual unrestricted full450original-L/full prepared-row actionpolynomial covariance','Independent fresh full79 replay fromzero','Canonical portable installation/actualCLI/fullarchive/classunion acceptance'],'portable_coverage_unchanged':234};(P/'l1-7981-exact-reuse-unrestricted-pair-review-r22.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['full17source_bindings','files_sha256']},indent=2))
