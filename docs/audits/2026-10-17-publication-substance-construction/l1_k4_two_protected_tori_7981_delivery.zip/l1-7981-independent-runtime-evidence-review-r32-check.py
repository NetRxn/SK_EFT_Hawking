from pathlib import Path
from fractions import Fraction as F
import json,hashlib,ast
P=Path('/tmp');W=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research');A=W/'.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=P/'l1-7981-evaluator-exact-reuse-r12.py';sourceh='2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10';assert sha(source)==sourceh
r26=json.loads((P/'l1-7981-independent-runtime-source-review-r26.json').read_text());r28=json.loads((P/'l1-7981-independent-driver-review-r28.json').read_text());correction=json.loads((P/'l1-7981-independent-unrestricted-r27-driver-correction.json').read_text())
assert r26['verdict'].startswith('REJECT') and 'source_sha256' in r26['mandatory_correction'];assert r28['verdict'].startswith('ACCEPT') and r28['exact_only_two_text_changes']
for n,h in r26['files_sha256'].items():assert sha(P/n)==h,n
old=(P/'l1-7981-independent-unrestricted-r23-control-driver.py').read_text();new=(P/'l1-7981-independent-unrestricted-r27-control-driver.py').read_text()
assert new==old.replace("PREFIX='/tmp/l1-7981-independent-unrestricted-r23-control'","PREFIX='/tmp/l1-7981-independent-unrestricted-r27-control'").replace('e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7',sourceh)
assert sha(P/'l1-7981-independent-unrestricted-r27-control-driver.py')==r28['corrected_driver_sha256']==correction['new_driver_sha256']=='16a8d957f00015007f43dd3767dddb446f09b5c293de0e3a6ebd3bfd4ff3491b'
for key,fn in [('control_sha256','l1-7981-independent-unrestricted-r23-control.py'),('replay79_runner_sha256','l1-7981-independent-unrestricted-r23-replay79-runner.py'),('replay79_driver_sha256','l1-7981-independent-unrestricted-r23-replay79-driver.py')]: assert sha(P/fn)==r28[key]
def literal(p,name):
 for n in ast.parse(p.read_text()).body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets): return ast.literal_eval(n.value)
 raise AssertionError(name)
control=P/'l1-7981-independent-unrestricted-r23-control.py';replay=P/'l1-7981-independent-unrestricted-r23-replay79-runner.py'
binding=literal(control,'BINDING');refs=literal(control,'REFERENCE_BINDING');assert len(binding)==16 and len(refs)==3 and literal(replay,'BINDING')==binding
for n,h in (binding|refs).items():assert sha(A/n)==h,n
assert sha(P/'l1-7981-control-preparation-r2-quaternion-reference.py')=='3520188b78f838b475814949104c8c64dc3c5dd3cff2ff57ba93024bdc642059'
files=[source,control,replay,P/'l1-7981-independent-unrestricted-r23-control-driver.py',P/'l1-7981-independent-unrestricted-r27-control-driver.py',P/'l1-7981-independent-unrestricted-r23-replay79-driver.py',P/'l1-7981-independent-runtime-source-review-r26.json',P/'l1-7981-independent-driver-review-r28.json',P/'l1-7981-independent-unrestricted-r27-driver-correction.json']
def load(stem,runner,limitkey,lastkind,n):
 out=P/(stem+'.out');err=P/(stem+'.err');ex=P/(stem+'.exit.json');files.extend([out,err,ex])
 assert not err.read_bytes();rows=[json.loads(l) for l in out.read_text().splitlines()];assert len(rows)==n
 e=json.loads(ex.read_text());assert e['actual_child_exit_code']==e['driver_exit_code']==0 and e['parent_timeout'] is False and e['truncated_or_nonJSON_lines']==0
 assert e['cold_limit_seconds']==600 and e['parent_wall_limit_seconds']==665 and 0<e['parent_seconds']<665
 assert e['source_sha256']==sourceh and e['runner_sha256']==sha(runner)
 assert e['command']==[str(W/'SK_EFT_Hawking/.venv/bin/python'),'-B',str(runner)]
 assert e['last_complete_record_kind']==lastkind==rows[-1]['kind']
 return rows,e
cs,ce=load('l1-7981-independent-unrestricted-r27-control',control,None,'independent450-unrestricted-complete',4)
assert [r['kind'] for r in cs]==['independent450-unrestricted-start','independent225-unrestricted-prepared','independent225-unrestricted-prepared','independent450-unrestricted-complete']
start,end=cs[0],cs[-1];assert start['source_sha256']==end['source_sha256']==sourceh and start['principal_source_sha256']==binding and start['reference_source_sha256']==refs and start['inner_limit']==600
assert ce['whole225_fixed_warm_limit_seconds'] is None and ce['complete_raw_branch_records']==0 and 0<end['seconds']<600<665 and end['seconds']<ce['parent_seconds']
assert start['scalar_contractions_run']==end['scalar_contractions_run']==end['unrestricted_coefficients_run']==0
summaries={}
for word,r in zip((79,81),cs[1:3],strict=True):
 assert r['word']==word and r['branches']==r['nonempty']==225 and r['structural_empty']==0 and r['scalar_contractions_run']==0
 assert r['center_rows_checked']==53370 and r['edge_rows_checked']==211950 and r['all_original_L_fullrows_equal'] is True
 expected={k:r[k] for k in ('branches','nonempty','structural_empty','center_rows_checked','edge_rows_checked')};assert end['words'][str(word)]==expected;summaries[str(word)]=expected
assert end['branches']==450 and end['signed225_fullrow_covariance'] and end['all_fullaction_rows_original_cubature'] and end['all_fullcenter_weights_original_L'] and end['square_source_independent']
assert end['row_cap']==120000 and end['pair_cap']==3000000
# This control's detailed rows are asserted by independently reviewed source, not emitted.
# We check its exact binding and terminal path; never recast aggregate JSON as independent row serialization.
rs,re=load('l1-7981-independent-unrestricted-r23-replay79',replay,None,'independent-replay-exact-word',228)
assert re['whole225_warm_limit_seconds']==60 and re['complete_raw_branch_records']==225
cold,warm=rs[:2];bs=rs[2:-1];last=rs[-1]
assert cold['kind']=='independent-replay-cold' and warm['kind']=='independent-replay-warm-start' and warm['hard_limit_seconds']==60 and cold['word']==warm['word']==last['word']==79
assert cold['restrictions']==last['restrictions']=={} and cold['branches']==warm['branches']==last['branches']==len(bs)==225
assert cold['source_sha256']==last['source_sha256']=={**binding,'evaluator':sourceh}
ref=P/'l1-7981-exact-reuse-unrestricted79-r16.out';files.append(ref);refsha='ba80ef752c93ff9c9914d5d695ac7ed9f4d8b3603d3c5ae4d9e56d83b62c2c7a';assert sha(ref)==cold['reference_sha256']==last['reference_sha256']==refsha
prior=[json.loads(l) for l in ref.read_text().splitlines()];pbs=[r for r in prior if r['kind']=='exact-branch'];pf=prior[-1];assert len(pbs)==225 and pf['kind']=='exact-word'
# Independent ordered 15-branch one-sector weights: unrestricted then each triplet's
# signed diagonal term and its six unordered two-index terms. Tensor the two sectors.
sector=[F(1,256)]
for triplet in ((0,1,2),(3,4,5)):
 sector.append(F(-1,559872))
 for i in triplet:
  for j in triplet:
   if i<=j:sector.append(F(2 if i==j else 1,279936))
assert len(sector)==15;weights=[x*y for x in sector for y in sector];assert len(weights)==225
D=192**42*4**64*48**6*2**15;weighted=F();rawsum=F();representatives=[];reuses=[];zeros=[];negative=[];peak=0;fields=('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation','peak_rows','representative_branch','reused_contraction','word')
for i,(b,old,w) in enumerate(zip(bs,pbs,weights,strict=True)):
 assert b['kind']=='independent-replay-branch' and b['branch']==i and b['word']==79
 assert all(b[k]==old[k] for k in fields),(i,'pilot mismatch')
 assert F(*b['weight'])==w and b['divisor']==D and F(*b['coefficient'])==F(b['raw_numerator'],D)
 assert b['algebraic_empty_preparation'] is False
 rep=b['representative_branch'];assert isinstance(rep,int) and 0<=rep<=i
 if b['reused_contraction']:
  reuses.append(i);assert rep<i and not bs[rep]['reused_contraction'];assert all(bs[rep][k]==b[k] for k in ('raw_numerator','divisor','coefficient','peak_rows'))
 else:representatives.append(i);assert rep==i
 if b['raw_numerator']==0:zeros.append(i)
 if w<0:negative.append(i)
 weighted+=w*F(b['raw_numerator'],D);rawsum+=w*b['raw_numerator'];peak=max(peak,b['peak_rows'])
assert len(representatives)==cold['actual_unique_inputs']==last['actual_unique_inputs']==last['representatives']==154
assert len(reuses)==last['reuse']==71 and len(zeros)==144 and len(negative)==52 and peak==last['peak_rows']==pf['peak_rows']==5632
assert weighted==F(*last['coefficient'])==F(*pf['coefficient'])==F(1165710661495982585955,35184372088832)
assert rawsum.denominator==1 and rawsum.numerator==last['raw_numerator']==pf['raw_numerator'] and last['divisor']==pf['divisor']==D and rawsum/D==weighted
assert 0<cold['seconds']==last['cold_seconds']<600 and 0<last['whole225warm_seconds']<60 and last['full_seconds']<re['parent_seconds']<665
assert 0<=last['full_seconds']-(last['cold_seconds']+last['whole225warm_seconds'])<1
result={'verdict':'ACCEPT recorded independent full450 original-L/full-row completion and fresh full79 replay in selected-word scientific scope only','first_continuity_fresh':True,'r26_rejection_preserved_r27_exact_metadata_fix_r28_source_acceptance_bound':True,'all19_scientific_dependency_and_reference_hashes_current':True,'quaternion_reference_hash_current':True,'control':{'records':4,'word_summaries':summaries,'child_exit':ce['actual_child_exit_code'],'driver_exit':ce['driver_exit_code'],'seconds':end['seconds'],'parent_seconds':ce['parent_seconds'],'scalar_contractions':0,'signed225_covariance_completed_by_bound_source':True,'limits':[600,665,120000,3000000]},'replay':{'branch_records':225,'all225_pilot_fields_equal_including_representatives':True,'all225_independent_weights_raw_D_fraction_reductions':True,'weighted_exact_fraction':[weighted.numerator,weighted.denominator],'weighted_raw_integer':rawsum.numerator,'divisor':D,'representatives':154,'reuse':71,'computed_raw_zeros':144,'negative_weights':52,'peak':peak,'cold_seconds':last['cold_seconds'],'whole225warm_seconds':last['whole225warm_seconds'],'full_seconds':last['full_seconds'],'parent_seconds':re['parent_seconds'],'child_driver_exits':[re['actual_child_exit_code'],re['driver_exit_code']],'current_full17_bindings':True},'files_sha256':{str(p):sha(p) for p in files},'required_corrections':[],'portable_coverage_unchanged':234,'limits':['No independent full-table reserialization by this receipt checker: aggregate four-record control completion relies on its independently reviewed exact-hash source/assertions and successful terminal path','No new scientific import/preparation/contraction or rerun','Portable installation/actualCLI/classunion/complete archive/delivery acceptance still owed','Broader fullk4/commonZ/physicalB3/modes/transport/main/human/publication remain separate']}
(P/'l1-7981-independent-runtime-evidence-review-r32.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files_sha256'},indent=2))
