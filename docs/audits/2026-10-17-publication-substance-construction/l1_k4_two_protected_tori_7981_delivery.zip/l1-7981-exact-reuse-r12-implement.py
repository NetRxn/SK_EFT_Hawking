from pathlib import Path
from hashlib import sha256
import json,difflib
P=Path('/tmp');old=P/'l1-7981-evaluator-exact-reuse-r10.py';assert sha256(old.read_bytes()).hexdigest()=='981ebcc799966e4ad1491c47f7a22255d2982d6531e346b06cac95ff434fbc46';pins=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text())['principal_source_sha256'];assert len(pins)==16
s=old.read_text();s=s.replace("FrozenPrepared=namedtuple",'EXPECTED_SIBLING_SHA256='+repr(pins)+'\n\nFrozenPrepared=namedtuple',1)
s=s.replace(" assert k2.ROW_CAP==120000 and k2.PAIR_CAP==3000000\n functions=", " assert k2.ROW_CAP==120000 and k2.PAIR_CAP==3000000\n fingerprint=source_hashes()\n assert set(fingerprint)==set(EXPECTED_SIBLING_SHA256)|{'evaluator'}\n assert all(fingerprint[name]==expected for name,expected in EXPECTED_SIBLING_SHA256.items())\n functions=",1)
s=s.replace("return tuple((f,getattr(f,'__code__',None)) for f in functions)+(k2.ROW_CAP,k2.PAIR_CAP)","return tuple((f,getattr(f,'__code__',None)) for f in functions)+(k2.ROW_CAP,k2.PAIR_CAP,tuple(sorted(fingerprint.items())))",1)
new=P/'l1-7981-evaluator-exact-reuse-r12.py';compile(s,str(new),'exec');new.write_text(s)
(P/'l1-7981-exact-reuse-r12-vs-r10.diff').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),s.splitlines(keepends=True),fromfile=str(old),tofile=str(new))))
oldr=P/'l1-7981-exact-reuse-r10-fixed-equivalence-runner.py';r=oldr.read_text();r=r.replace('l1-7981-evaluator-exact-reuse-r10.py','l1-7981-evaluator-exact-reuse-r12.py').replace('981ebcc799966e4ad1491c47f7a22255d2982d6531e346b06cac95ff434fbc46',sha256(new.read_bytes()).hexdigest())
needle="assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==EXPECTED\ns=runpy.run_path"
replace="""assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==EXPECTED
EXPECTED_SIBLINGS=%r
AUDIT=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
# Pin immutable accepted dependencies BEFORE any scientific module import.
assert all(hashlib.sha256((AUDIT/name).read_bytes()).hexdigest()==expected for name,expected in EXPECTED_SIBLINGS.items())
s=runpy.run_path"""%pins
assert needle in r;r=r.replace(needle,replace)
r=r.replace("assert binding['evaluator']==EXPECTED", "assert binding=={**EXPECTED_SIBLINGS,'evaluator':EXPECTED}")
r=r.replace("a=s['contract_prepared'](prepared,g.divisor,baseline.append)\nb=s['contract_frozen'](frozen,g.divisor,reused.append)","assert s['_reuse_context']()==frozen.context\nbaseline_start=time.perf_counter();a=s['contract_prepared'](prepared,g.divisor,baseline.append)\nbaseline_seconds=time.perf_counter()-baseline_start\nreuse_start=time.perf_counter();b=s['contract_frozen'](frozen,g.divisor,reused.append)\nreuse_seconds=time.perf_counter()-reuse_start")
r=r.replace("'whole225_baseline_and_reuse_warm_seconds':elapsed,", "'whole225_baseline_and_reuse_warm_seconds':elapsed,'baseline_seconds':baseline_seconds,'reuse_seconds':reuse_seconds,")
runner=P/'l1-7981-exact-reuse-r12-fixed-equivalence-runner.py';runner.write_text(r);compile(r,str(runner),'exec')
d=(P/'l1-7981-exact-reuse-r10-fixed-equivalence-driver.py').read_text().replace('l1-7981-exact-reuse-r10-fixed-equivalence','l1-7981-exact-reuse-r12-fixed-equivalence').replace('c27e8a8d1b78355519c4ca6dd0d1f08fe17f624bcbb899997e7b3570698c2e99',sha256(runner.read_bytes()).hexdigest());driver=P/'l1-7981-exact-reuse-r12-fixed-equivalence-driver.py';driver.write_text(d);compile(d,str(driver),'exec')
(P/'l1-7981-exact-reuse-r12-runner-vs-r10.diff').write_text(''.join(difflib.unified_diff(oldr.read_text().splitlines(keepends=True),r.splitlines(keepends=True),fromfile=str(oldr),tofile=str(runner))))
