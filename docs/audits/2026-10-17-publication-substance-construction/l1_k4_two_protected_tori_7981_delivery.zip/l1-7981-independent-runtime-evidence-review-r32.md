# Independent full-row control and fresh79 runtime-evidence review r32

**ACCEPT recorded independent unrestricted450 original-L/full-row completion and fresh full79 replay within selected-word scientific scope. No correction required.** Portable coverage remains234/272; portable installation/actualCLI, class-union, complete archive and delivery acceptance remain owed.

First and final assigned continuity checks were fresh=true, changed=[]. No packet was refreshed. This review ran only the reviewer-owned stdlib JSON/Fraction/AST/hash checker; no scientific import, preparation, contraction, test, candidate/source/corpus/Git/notebook/writer mutation occurred. Exact hashes and derived results are in `/tmp/l1-7981-independent-runtime-evidence-review-r32.json`; checker is `/tmp/l1-7981-independent-runtime-evidence-review-r32-check.py`.

## Source and provenance chain

Confirmed preserved r26 rejection of the old control-driver evaluator metadata. Exact original driver remains SHA256b41e940369376f7d1ebcf6ea08ee829b8f32adb9d7fdbc7fc78a8626ad2abcec. Independently compared new r27 driver with old: only exclusive output prefix and evaluator source-hash correction differ. Corrected driver SHA25616a8d957f00015007f43dd3767dddb446f09b5c293de0e3a6ebd3bfd4ff3491b matches r27 correction and nonauthor r28 acceptance. The control source47744003e2622fc437793f8f0e5988d4079fca864471b2db20be24cef53ae67d, fresh replay runnerd5a874fe5037778be8d086f749079ea51e008b872971daadb722371bb2563cec and replay driverf9f4d5941c53145b4424d75534e60edc4f502a64b9d7851d57803a970e6be46e match r26/r28 accepted bytes.

The actual current evaluator matches r12 SHA2562b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10. All16 principal source files and three independent reference files match their literal accepted hashes, as does the independent quaternion reference. Cold/final replay full17-file maps agree exactly; pilot reference is bound to original79r16 stream ba80ef752c93ff9c9914d5d695ac7ed9f4d8b3603d3c5ae4d9e56d83b62c2c7a. Existing independently reviewed reconstruction source and r12 mechanism acceptance are reused; this receipt review is not self-reacceptance of that source proof.

## Actual independent full-row control

Parsed all four JSON records, in exact start/word79/word81/complete order. Word records each report225 nonempty branches, zero structural empty,53370 center rows and211950 action-edge rows. Both match the complete record's per-word objects; final450 count and signed225 full-row covariance completion are consistent. Source-bound terminal execution completed all original-L center-weight, original-cubature action-row and independent-square/source assertions with zero scalar contractions or unrestricted coefficients run.

Child/driver exit0; stderr empty; no timeout/nonJSON/truncation; last complete kind independent450-unrestricted-complete. Actual command/runner/evaluator metadata match accepted current bytes. Child99.28001829201821s and parent100.1142440829426s respect600/665 limits; row/pair caps120000/3000000 retained. ROOT reported terminal tool handle54075; independently inspected exit-file evidence is consistent with that report.

The control emits aggregate completion records, not all reconstructed table rows. Acceptance of actual full-row comparison therefore rests on the exact independently reviewed source's complete equality assertions and successful terminal path. This report does not falsely present those aggregate booleans as independently serialized/reconstructed450 tables.

## Fresh full79 replay: independent arithmetic

Parsed228 JSON records: cold, warm-start,225 own-index branch records, final. Every branch has the expected unique index/word and matches original79r16 weight, raw numerator, divisor, exact fraction, peak, structural flag, representative index and reused flag. Independently built the ordered15-weight one-sector vector from the unrestricted term plus each triplet's signed term/six unordered pairs, then its225 tensor-product weights. All recorded weights match;52 are negative.

For every branch independently checked Fraction(raw,D) equals the recorded fraction, with D=192**42*4**64*48**6*2**15. Recomputed all225 weighted raw and fractional sums: final exact value **1165710661495982585955/35184372088832**, equal to pilot and replay finals; weighted raw is an integer and divides by the same D to that value. All154 first representatives point to themselves;71 reused branches point backward to a successful first representative with identical raw/D/fraction/peak. Counted144 computed raw zeros, zero structural empty and peak5632. No conclusion comes merely from the recorded all225_reference_equalities boolean.

Cold34.59243716695346s, ONE WHOLE225 warm41.924018374993466s, full76.51700354192872s and parent77.54855445795693s are mutually consistent and below600/60/665. Child/driver exit0; stderr empty;225 complete branch count; no timeout/truncation/nonJSON; exact final kind/command/runner/evaluator/ref hashes. ROOT reported actual terminal handle75387. Accepted bound source preserves120000-row/3000000-pair caps and fromzero prepare/freeze, with prior raws used only in comparison callbacks and final assertions.

## Remaining boundary

This accepts the independently controlled selected-word evidence, supporting subsequent scientific-class consideration. It grants no portable credit or new runtime admission. Canonical portable install/actualCLI, class-union review, complete original evidence archive, delivery and their nonauthor acceptance remain required before234 changes. Earlier failed-pilot records stay failed. Fullk4/commonZ/physicalB3/modes/transport/main/human/publication obligations remain separate.
