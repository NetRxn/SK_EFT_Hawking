# Independent exact-reuse fixed controls r15

**ACCEPT complete450 actual fixed baseline/original-receipt equivalence and signed225 transpose. No correction required.** This accepts FIXED controls only; it does not admit an unrestricted run, establish an unrestricted coefficient or increase portable234.

First candidate continuity check `publication-7981-fixed-independent-r15.json` exited0, fresh=true, changed=[]. Independent checker `/tmp/l1-7981-exact-reuse-fixed-independent-r15-check.py` exited0 using stdlib JSON/ZIP/hash/CRC/Fraction analysis only. No scientific import, preparation, moment, contraction, test/runtime, source/candidate/primary/notebook/Git/controller write occurred. Only reviewer-prefixed checker/Markdown/JSON were written.

The ORIGINAL accepted62-member controls archive in the owning audit has SHA256 `417bfddde7c86a3e6e5b0ae62dadc442a3cd25488dc6667954a4b791469d4f3e`. Unique population, full manifest, all62 member sizes/SHA256/CRCs and `testzip()` were verified. Original fixed79/81 branch and preparation/source-support records were read from that immutable archive, not from the new runner's baseline assertions or author summaries.

For EACH word79 and81, every one of225 new complete branch records equals the corresponding ORIGINAL accepted raw numerator, exact weight, divisor, branch fraction, peak and structural-empty flag. Exact15×15 protected weights were independently regenerated, including52 negatives. Each word has25 nonempty/200 structural-empty preparations,0 computed zero nonempty branches, peak564; all branch indices remain0…224. Four actual distinct **FIXED** complete inputs produce4 successful first representatives and21 successful reuses; structuralNone records keep no representative and no reuse flag. Reused raw/fraction/D/peak equal their earlier first representative. All225 terms independently reduce to

`10367035518435041776795 / 7709672958021817718820298555392`,

with `D=192^42*4^64*48^6*2^15`. The weighted raw sums equal the ORIGINAL final raw numerators, and final fractions/peaks match both originals.

All225 new raw/weight/D/fraction/peak/structural comparisons hold at **79 branch15i+j→81 branch15j+i**. The original corresponding core domains, all center-support/empty-site records and full source-polynomial masks were independently translated by physicalXOR1, including Grassmann permutation signs; they agree. This preserves the prior independently accepted full450 original-L/full-row covariance evidence, rather than replacing it with a same-flat-index comparison.

Both actual child/driver exits are0; stderr empty, no timeout/truncation/nonJSON output,225 complete branch records per word. Both cold/final complete17 source fingerprints exactly equal accepted16 sibling pins plus r12 evaluator`2b852f30013c9edf0873275bdeb98c92f845bba27c3bd09aba71541678fb9f10`; current bytes and source-reviewed runner/driver hashes match. The runtime complete-value assertion verifies original prepared objects unchanged; reviewed immutable snapshot/private thaw source avoids writes to original nested tables. This review does not invent independent object-identity telemetry absent from the original streams.

|Word|Cold|Baseline warm|Reuse warm|Combined WHOLE225 warm|Parent|
|---|---:|---:|---:|---:|---:|
|79|6.814432s|0.227561s|0.207047s|0.436610s|7.353566s|
|81|6.703900s|0.218587s|0.206999s|0.427673s|7.229694s|

Both baseline and reuse calls, comparisons and225 emissions remain under the SAME single60s warm alarm. All cold work remains within600s, parent665s and120000row/3000000pair caps; no baseline or representative contraction moved cold, no additional warm preparation was introduced. Separate timings describe these fixed control attempts only. Four measured fixed inputs do not establish154 unrestricted classes or unrestricted deadline feasibility.

All source/terminal/stream hashes and detailed reductions are in `/tmp/l1-7981-exact-reuse-fixed-independent-r15.json`. ROOT still owns any new unrestricted79-fromindex0 admission. Original failed218/225 pilot remains preserved and unaccepted; no partial raw reuse or seven-branch shortcut follows. Fullk4/commonZ/physicalB3/modes/transport/main/publication remain open.
