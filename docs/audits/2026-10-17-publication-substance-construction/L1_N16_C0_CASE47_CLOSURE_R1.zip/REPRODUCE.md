# L1 N16 case 47 independent closure

The companion `L1_N16_C0_CASE47_AUTHOR_R1.zip` provides exact parent restoration, author cut and reduction, and all nine frozen receipts. Restore the exact author scratch before replaying the terminal inputs. The original seven-factor parent SHA256 is 3b2571cceebe7dda9b8b55c7569ab82b351267812f185266cac295419d405ad2. The archive's review records and scripts preserve the alternate closure and exact nine-cut tally.

The full case (68,(2,)) has exact real `-266847350733101695525209/1298074214633706907132624082305024` and imaginary part zero. It remains one outer term of the first binary child of tuple 0 in descendant (0,0), at original source 51e7c745e. Full signed coefficient, physical B3 and publication gate acceptance remain separate.

Run the separate independent script and exact aggregate using the bindings in the review. The author and reviewer schedules are preserved with their support cuts, resources, refusals and hashes.

From an extracted archive, `python3 independent/aggregate.py` reproduces the retally using the archived author receipts. The complete author and parent ZIPs are included unchanged because the independent verifier binds the audit directly to their manifests.
