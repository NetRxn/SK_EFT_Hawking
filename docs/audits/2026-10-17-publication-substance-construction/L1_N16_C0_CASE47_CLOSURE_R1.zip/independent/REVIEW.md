# L1 outer case 47 independent exact replay

The exact independently verified sum is **-266847350733101695525209/1298074214633706907132624082305024 + 0i**.

Checkpoint c43f3eac683a920e17f53892bb98ae1c3ab4fac2 pins the source and author experiment archives. The seven-factor parent hash matches the original reconstruction archive. The 48-case outer roster places coordinate (68, (2,)) at zero-based index 47. Independent support matching over the selected factor pair finds nine possible cut values of G(0,1,2), with 2,280,960 total pair matches and at most 497,664 on any cut. A nonzero network term requires a match on that pair. Inverse lifting each conditioned child recovers all compatible parent rows, exact Gaussian coefficients and unchanged denominators. All nine child hashes and replay terminal hashes match the author archive.

- Slices 0, 1, 4, 5 and 6 replay by independent ordinary sparse Gaussian joins from their pinned reduced inputs. They require respectively 672,192, 6,528,768, 2,677,656, 2,677,656 and 636,048 matched products. Their raw independent numerators reproduce all five normalized author receipts.
- Slices 2 and 3 use pivot factor 1, while the author shards pivot factor 0. The independent method first sums complement inner products and then multiplies by the pivot coefficient. It covers 18,643,968 and 19,975,680 probes respectively, and uses 18,752,832 and 20,092,320 exact Gaussian products.
- Slices 7 and 8 use alternate factor pair (1,2) instead of the author's (1,3). The independent method groups exact selected-pair products by the outgoing boundary within each disjoint block, then computes one complement dot product per retained boundary. The author instead evaluates cached complement values inside the pair loop. The two inputs are replayed separately, as are slices 4 and 5.

The standard sparse route limits work to 8M matched products per join, 30M overall and 1M output rows. Terminal triangle and four-factor replays use bounded deterministic shards and exact accumulators. Earlier author caps, including the row limits for slices 7 and 8, are retained as part of the lineage. The independent aggregate compares every result with the archive-pinned author receipt and checks the four author-sharded computations for full disjoint row-interval coverage and exact raw sums. The common factor denominator and positive scale 1/(16*4^64) are applied once.

The independent reconstruction starts at the checkpointed seven-factor parent for cut coverage and at the frozen terminal frontiers for scalar replay. Antecedent reductions rely on saved lineage and previously reviewed identities. This covers case 47 of the 48-case cut for one binary child of tuple 0. The complete signed coefficient remains open.

## Four-factor replay bounds

- Slice 7 had 8650800 selected outer matches. complete shards 16 left rows 20304 peak Gaussian products/shard 2049424 peak closure probes/shard 1457512 peak entries 24984 total products 27716400 total probes 18564576 seconds 16.705.
- Slice 8 had 8650800 selected outer matches. complete shards 16 left rows 20304 peak Gaussian products/shard 2049424 peak closure probes/shard 1457512 peak entries 24984 total products 27716400 total probes 18564576 seconds 17.198.
