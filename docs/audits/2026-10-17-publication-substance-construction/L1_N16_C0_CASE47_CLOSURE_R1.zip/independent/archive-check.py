from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
with ZipFile(root/'author-pinned.zip') as archive:
    assert archive.testzip() is None
    receipts = {name: digest for digest, name in (line.split() for line in archive.read('manifest.sha256').decode().splitlines())}
    assert all(sha256(archive.read(name)).hexdigest() == digest for name, digest in receipts.items())
    print('author archive internal manifest',len(receipts),'checksums verified')
for name in ('pinned.zip','author-pinned.zip'):
    print('archive',name,sha256((root/name).read_bytes()).hexdigest())
