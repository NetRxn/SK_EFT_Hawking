from ast import literal_eval
from collections import Counter
from pathlib import Path
import pickle

root = Path('/private/tmp/l1-tuple-separators.OxRDWT')
previous = Path('/private/tmp/l1-dense-resume.bbZW6V')

def load(path):
    return pickle.loads(path.read_bytes())

def audit(source, pair, fixed_axes, plan, children):
    parent = load(source)
    factors = parent['factors']
    degree = Counter(w for axes, _, _ in factors for w in axes)
    assert set(degree.values()) == {2}
    left, right = (factors[i] for i in pair)
    common = set(left[0]).intersection(right[0])
    ordered = tuple(sorted(common))
    buckets = Counter(tuple(dict(zip(right[0], row))[a] for a in ordered) for row in right[1])
    spectrum = Counter()
    for row in left[1]:
        assignment = dict(zip(left[0], row))
        multiplicity = buckets[tuple(assignment[a] for a in ordered)]
        if multiplicity:
            spectrum[tuple(assignment[a] for a in fixed_axes)] += multiplicity
    assert spectrum == plan
    for coordinate, path in children.items():
        fixed = dict(zip(fixed_axes, coordinate))
        child = load(path)
        assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
        assert child['label_partition'] == parent['label_partition']
        for (axes, rows, denominator), (small_axes, small_rows, small_denominator) in zip(factors, child['factors'], strict=True):
            assert denominator == small_denominator
            assert tuple(w for w in axes if w not in fixed) == small_axes
            expected = {row: value for row, value in rows.items()
                        if all(row[p] == fixed[w] for p,w in enumerate(axes) if w in fixed)}
            recovered = {}
            for row,value in small_rows.items():
                assignment = dict(zip(small_axes,row))
                assignment.update(fixed)
                recovered[tuple(assignment[w] for w in axes)] = value
            assert recovered == expected
    print(source.name, 'pair',pair,'cuts',fixed_axes,'cases',len(spectrum),
          'sum/max products',sum(spectrum.values()),max(spectrum.values()),'children audited',list(children),flush=True)

import hashlib
from math import prod
from zipfile import ZipFile
from binding import ROOT,TERMINAL_INPUTS

author=ROOT
source=Path('/private/tmp/l1-c0-pilot-next.Ssjz7H/row-cap-physical-slice-dense-label-case-47-2-reduced.pkl')
with ZipFile(Path(__file__).resolve().parent / 'pinned.zip') as archive:
    receipts = {name: digest for digest, name in
                (line.split() for line in archive.read('reconstructed-frontiers.sha256').decode().splitlines())}
    assert hashlib.sha256(source.read_bytes()).hexdigest() == receipts[source.name]
    assert (author/'slice-0.roster').read_bytes() == archive.read('author/second-47.roster')
outer_roster=root/'pilot.roster'
assert hashlib.sha256(outer_roster.read_bytes()).hexdigest()=='185ad83d0dc0b6dcaa311b65cbbc6fc8542a0b31120e8fc4fbf59d0e238b1c4c'
outer_axes,outer_items=literal_eval(outer_roster.read_text())
assert sorted(outer_items,key=lambda pair:(pair[1],pair[0]))[47][0]==(68,(2,))
parent=load(source)
assert tuple(dict(parent['conditioning'])[axis] for axis in outer_axes)==(68,(2,))
roster=author/'slice-0.roster'
axes,raw=literal_eval(roster.read_text())
assert all(literal_eval((author/f'slice-{i}.roster').read_text())==(axes,raw) for i in range(9))
counts=dict(raw)
assert len(counts)==len(raw)==9
order=sorted(counts,key=lambda coord:(counts[coord],coord))
assert order[:2]==[(3,),(48,)] and (counts[order[0]],counts[order[1]])==(44928,62208)
audit(source,parent['rejected_pair'],axes,counts,{order[i]:author/f'slice-{i}.pkl' for i in range(9)})
with ZipFile(Path(__file__).resolve().parent / 'author-pinned.zip') as archive:
    author_receipts = {name: digest for digest, name in
                (line.split() for line in archive.read('reconstructed-frontiers.sha256').decode().splitlines())}
    frozen = archive.read('author/author-case47.tsv')
    assert frozen == (author/'author-case47.tsv').read_bytes()
    for i in range(9):
        assert archive.read(f'author/slice-{i}.roster') == (author/f'slice-{i}.roster').read_bytes()
        assert hashlib.sha256((author/f'slice-{i}.pkl').read_bytes()).hexdigest() == author_receipts[f'slice-{i}.pkl']
for i,name in enumerate(TERMINAL_INPUTS):
    data=(author/name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == author_receipts[name]
    state=pickle.loads(data)
    child=load(author/f'slice-{i}.pkl')
    assert state['conditioning']==child['conditioning']
    assert state['label_partition']==child['label_partition']
    factors=state['factors']
    assert prod(d for _,_,d in factors)==40512224221827380280140849737629696
    assert all(d>0 and len(a)==len(set(a)) and all(len(k)==len(a) and len(v)==2 and any(v) and all(type(x) is int for x in v) for k,v in table.items())
               for a,table,d in factors)
    assert all(n==2 for n in Counter(w for a,_,_ in factors for w in a).values())
    assert Counter(w for a,_,_ in factors for w in a)
    print('replay input',i,order[i][0],counts[order[i]],name,hashlib.sha256(data).hexdigest(),len(factors),sum(len(r) for _,r,_ in factors),flush=True)
print('PASS canonical parent/roster identity, exact nine-coordinate coverage, all nine inverse lifts and terminal input metadata')
