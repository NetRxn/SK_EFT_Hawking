#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 archive-check.py > archive-check.out
python3 -u audit-all.py > audit-archive.out
a=/private/tmp/l1-c0-case47.QEs1Ry
while read -r slice stem; do
  python3 -u sparse-replay.py "$slice" 0 "$a/label-$stem-reduced-frontier.pkl" "$a/$stem-contract.out" > "slice-$slice-replay.out"
done <<'PLAN'
0 rescue-0-0
1 slice-1
4 rescue-4-0
5 rescue-5-0
6 rescue-6-1
PLAN
for slice in 2 3; do python3 -u triangle.py "$slice" > "slice-$slice-replay.out"; done
for slice in 7 8; do python3 -u four.py 47 "$slice" --pair 1 2 > "slice-$slice-replay.out"; done
python3 aggregate.py > aggregate.out
