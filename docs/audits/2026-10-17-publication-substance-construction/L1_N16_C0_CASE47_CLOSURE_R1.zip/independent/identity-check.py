from binding import ROOT, TERMINAL_INPUTS
from pickle import loads

for i,j in ((4,5),(7,8)):
    x,y = [loads((ROOT/TERMINAL_INPUTS[k]).read_bytes()) for k in (i,j)]
    print(i,j,'factor support equal by position',
          [u[0]==v[0] and u[1].keys()==v[1].keys() for u,v in zip(x['factors'],y['factors'],strict=True)],
          'factor tables equal by position',
          [u==v for u,v in zip(x['factors'],y['factors'],strict=True)])
