from collections import Counter, defaultdict
from itertools import product
from pathlib import Path
import json
import sys

from src.core.formulas import original_action_factors, original_coframe_blocks, original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol, assemble_coframe
reg=OriginalRegulator()
assert (reg.extents,reg.boundary_signs,reg.convention,reg.word)==((2,)*4,(1,)*4,'source_C','closed')
qbits={Symbol('q',(x,mu,h,i)):1<<j for j,(x,mu,h,i) in enumerate(
    (x,mu,h,i) for x,mu in reg.link_order for h in ('L','R') for i in range(4))}
links={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4))
    for h in ('L','R'))) for anchor in reg.link_order}
assert len(links)==64 and len(qbits)==512 and len(reg.generator_order)==128
records=json.loads(Path(sys.argv[1]).read_text())['sites']

def qmask(keys):
    result=0
    for key in keys:
        for symbol in key:
            result |= qbits[symbol]
    return result

domains={}
co_s={}; grouping={}
for record,x in zip(records,reg.sites,strict=True):
    assert tuple(record['site'])==x
    co={}
    for mu,a in product(range(4),repeat=2):
        ext=assemble_coframe(reg,original_coframe_blocks(reg,(x,mu,a),links)).to_exterior(reg)
        gscope=qscope=count=0
        for mask,coeff in ext.terms:
            gscope |= mask
            qscope |= qmask(key for key,_ in coeff.terms)
            count += len(coeff.terms)
        co[mu,a]=(gscope,qscope)
        co_s[x,mu,a]=ext.terms
        observed=next(z for z in record['coframes'] if tuple(z['components'])==(mu,a))
        assert (observed['terms'],observed['scope'])==(count,[gscope,qscope])
    group=defaultdict(dict)
    for raw,f in zip(record['raw_branches'],original_action_factors(reg,x,links),strict=True):
        axes=tuple(sorted((mu,a) for origin,mu,a in f.components if origin==x))
        assert len(axes)==f.t_degree
        target=group[f.t_degree,axes]
        g=0
        q=qmask(key for key,_ in f.coefficient.terms)
        for c in axes:
            g |= co[c][0]; q |= co[c][1]
        assert raw == json.loads(json.dumps([f.t_degree,axes,f.anchors,len(f.coefficient.terms),[g,q]]))
        for key,val in f.coefficient.terms:
            target[key]=target.get(key,0)+val
    nonzero={k:{m:v for m,v in row.items() if v} for k,row in group.items()}
    nonzero={k:row for k,row in nonzero.items() if row}
    assert Counter(degree for degree,_ in nonzero)=={2:72,4:24}
    assert {tuple(mu for mu,_ in axes) for degree,axes in nonzero if degree==2}=={
        (mu,nu) for mu in range(4) for nu in range(mu+1,4)}
    agg_g=agg_q=0
    for observed,((degree,axes),trace) in zip(record['grouped_branches'],sorted(nonzero.items()),strict=True):
        g=0; q=qmask(trace)
        for c in axes:
            g |= co[c][0]; q |= co[c][1]
        assert observed==json.loads(json.dumps([degree,axes,len(trace),[g,q]]))
        agg_g |= g; agg_q |= q
    assert record['structural_domain']==dict(fermion=agg_g,quaternion=agg_q)
    assert (agg_g.bit_count(),agg_q.bit_count())==(40,160)
    domains[x]=agg_g,agg_q
    grouping[x]=nonzero
    print(x,'exact signed source census',flush=True)

def boundary(taken):
    score=0
    for index in range(2):
        a=b=0
        for x in reg.sites:
            if x in taken: a |= domains[x][index]
            else: b |= domains[x][index]
        score += (a&b).bit_count()
    return score

assert max(boundary(set(reg.sites[:j])) for j in range(17))==640
taken=set(); history=[]
while len(taken)<16:
    score,x=min((boundary(taken|{x}),x) for x in set(reg.sites)-taken)
    taken.add(x); history.append(score)
assert max(history)==520
print('all source rows 6528 matched; lexical 640; greedy 520',flush=True)

# Reproduce narrow closure with sets of labeled masks, a grouping by shape
# different from the author ledger. Check complete coverage and even parity.
gm=(1<<0)|(1<<2)
qm=0x11
owners=sorted(x for x,(g,q) in domains.items() if (g&gm) or (q&qm))
expected=json.loads(Path(sys.argv[2]).read_text())
assert owners==list(map(tuple,expected['owners']))
def parity(key):
    q=0
    for symbol in key:
        q ^= qbits[symbol]
    return q&qm
def join(A,B):
    return {(g|h,q^r) for g,q in A for h,r in B if not(g&h)}
layer={(0,0,0,0)}
for step,x in enumerate(owners):
    co={(mu,a):{(g&gm,parity(key)) for g,p in co_s[x,mu,a] for key,_ in p.terms}
        for mu,a in product(range(4),repeat=2)}
    base={2:set(),4:set()}
    for (degree,axes),trace in grouping[x].items():
        sets=[co[axis] for axis in axes]
        while len(sets)>1:
            sets.append(join(sets.pop(0),sets.pop(0)))
        base[degree].update(join(sets[0],{(0,parity(key)) for key in trace}))
    lset=set()
    for p,q in product(range(5),range(3)):
        if 2*p+4*q<=8:
            out={(0,0)}
            for seed in [base[2]]*p+[base[4]]*q:
                out=join(out,seed)
            lset.update((p,q,g,h) for g,h in out)
    layer={(p+r,q+s,g|m,h^n) for p,q,g,h in layer for r,s,m,n in lset if not(g&m)}
    if step==len(owners)-1:
        assert all(all(any(domains[y][i]&bit for y in owners) for bit in (1<<j for j in range(mask.bit_length()) if mask>>j&1)) for i,mask in enumerate((gm,qm)))
        layer={(p,q,0,0) for p,q,g,h in layer if g==gm and h==0}
    assert len(layer)==expected['completed_layers'][step]['boundary_records']
assert sorted([p,q] for p,q,_,_ in layer)==expected['surviving_projected_grades']
print('narrow closure independently matched all five boundaries and all 120 final grades')
