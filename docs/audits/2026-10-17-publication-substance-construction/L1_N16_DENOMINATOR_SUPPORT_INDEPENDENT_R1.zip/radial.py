from collections import Counter
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
from math import factorial, comb
from pathlib import Path
import json
import sys

author = Path(sys.argv[1])
# Solve the single delta equation by distance, fixing Green value at distance 4.
# Row equation is 4u_d+d*u_{d-1}+(4-d)*u_{d+1}=delta_d0-(-1)^d/16.
u = [None] * 4 + [Fraction(0)]
for d in range(4, 0, -1):
    u[d-1] = (Fraction(-(-1)**d, 16)-4*u[d]-(4-d)*(u[d+1] if d<4 else 0))/d
assert 4*(u[0]+u[1]) == Fraction(15, 16)
den = 1
from math import lcm
for value in u:
    den = lcm(den, value.denominator)
kernel = tuple(int(den*x) for x in u)
print('delta kernel', den, kernel)
neighbors = [[i ^ (1 << d) for d in (3,2,1,0)] for i in range(16)]
sign = [(-1)**i.bit_count() for i in range(16)]
labels = [(x,d,e) for x in range(16) for d,e in combinations(range(4),2)]
vec = []
demands = []
for x,d,e in labels:
    y,z = neighbors[x][d], neighbors[x][e]
    b = [2*(i==x)+(i==y)+(i==z) for i in range(16)]
    g = [-2*kernel[(i^x).bit_count()]-kernel[(i^y).bit_count()]-kernel[(i^z).bit_count()] for i in range(16)]
    g = [value-sign[i]*g[0] for i,value in enumerate(g)]
    assert all(4*g[i]+sum(g[j] for j in neighbors[i]) == -den*b[i] for i in range(16))
    vec.append(tuple(g))
    demands.append(b)

# Enumerate each sorted multiset directly. Coordinate 1 rejects most
# candidates before other coordinates are constructed, without pair indexing.
got = set()
integral = visited = 0
split = Counter()
for ids in combinations_with_replacement(range(96),4):
    visited += 1
    a,b,c,d = map(vec.__getitem__,ids)
    if (a[1]+b[1]+c[1]+d[1]) % den:
        continue
    vals = tuple(sum(coordinate) for coordinate in zip(a,b,c,d))
    if any(value % den for value in vals):
        continue
    integral += 1
    base = [1+value//den for value in vals]
    p = Counter(labels[i][0] for i in ids)
    planes = tuple(labels[i] for i in ids)
    for q0 in range(3):
        q = tuple(value+sign[j]*(q0-1) for j,value in enumerate(base))
        if any(value<0 or 2*p[j]+4*value>8 for j,value in enumerate(q)):
            continue
        assert all(4*q[j]+sum(q[k] for k in neighbors[j])+sum(demands[i][j] for i in ids)==8 for j in range(16))
        assert sum(q)==14
        divisor = 1
        for v in (*Counter(ids).values(),*q):
            divisor *= factorial(v)
        got.add((planes,q,divisor))
        split[len(p)] += 1
assert visited == comb(99,4)
expected = []
for line in (author/'c14-occupancy-roster.jsonl').read_text().splitlines():
    row=json.loads(line)
    expected.append((tuple(map(tuple,row['planes'])),tuple(row['S4_occupations']),row['exponential_divisor']))
assert len(expected)==len(got)==len(set(expected))
assert got==set(expected)
print(json.dumps(dict(visited=visited,integral=integral,admissible=len(got),by_distinct_S2_centers=split,matched_roster=True),sort_keys=True))
