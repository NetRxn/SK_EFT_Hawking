"""Scratch bounded original N16 streamed frontier. No full coefficient run."""
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from math import comb
import json
import resource
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

Q = o.QComplex
P = o.Polynomial
E = o.ExteriorPolynomial
S = o.Symbol
INDICES = ((), (0,), (1,), (0, 0), (0, 1), (1, 1))
ALTERNATIVES = tuple((q,p) for q in range(3) for p in range(5-2*q))

class Limit(ValueError):
    def __init__(self, field, *, visits, live):
        self.field, self.visits, self.live = field, visits, live
        super().__init__(f'{field}: visits={visits}, live={live}')

@dataclass
class Caps:
    visits: int
    records: int
    used: int = 0
    peak: int = 0

    def __post_init__(self):
        for value, maximum in ((self.visits, 2_000_000), (self.records, 65_536)):
            if type(value) is not int or not 0 < value <= maximum:
                raise ValueError('positive exact integer limit within bounded probe envelope required')
        if type(self.used) is not int or type(self.peak) is not int or self.used or self.peak:
            raise ValueError('probe budgets start with zero exact accounting')

    def room(self, live):
        if live > self.records:
            raise Limit('records', visits=self.used, live=live)
        self.peak=max(self.peak,live)

    def visit(self, live):
        if self.used == self.visits:
            raise Limit('visits',visits=self.used,live=live)
        self.used+=1

def multiply(a,b,cap,*,retained=0):
    """C2 signed product, keyed by exact mask and all commuting source symbols.

    Factor selectors and unresolved component cursors are outer scope here:
    each invocation only compares leaves at the same stage of a fixed branch.
    """
    hold=len(a)+len(b)+retained
    cap.room(hold)
    out={}
    for (am,ak,aj),av in a.items():
        for (bm,bk,bj),bv in b.items():
            cap.visit(hold+len(out))
            if am&bm or len(aj)+len(bj)>2:
                continue
            j=tuple(sorted(aj+bj))
            multiplicity=1
            for t in set(j):
                multiplicity*=comb(j.count(t),aj.count(t))
            bits=am
            sign=1
            while bits:
                low=bits&-bits
                if (bm&(low-1)).bit_count()%2:
                    sign=-sign
                bits^=low
            key=(am|bm,tuple(sorted(ak+bk)),j)
            old=out.get(key)
            value=av*bv*(sign*multiplicity)+(old if old is not None else Q())
            if value:
                if old is None: cap.room(hold+len(out)+1)
                out[key]=value
            elif old is not None:
                del out[key]
    return out

def pack(jet):
    return {(mask,key,slot):c for slot in INDICES for mask,p in jet.at(slot).terms
            for key,c in p.terms}

def raw_const(e):
    return o.RawJet.constant(e)

def jet_from_slots(vals):
    return o.RawJet.from_slots(tuple(P.scalar(v) for v in vals))

def coefficient_factor(symbol):
    return raw_const(E(((0,P.variable(symbol)),)))

def add(*maps):
    # Used only for fixed small bounded conservation cases, not the over-cap join.
    out={}
    for mapping in maps:
        for key,value in mapping.items():
            q=out.get(key,Q())+value
            if q: out[key]=q
            elif key in out: del out[key]
    return out

def closed_anchor(terms,anchors):
    out={}
    for (mask,key,j),value in terms.items():
        removed=tuple(s for s in key if s.family=='q' and s.index[:2] in anchors)
        residue=tuple(s for s in key if not (s.family=='q' and s.index[:2] in anchors))
        weights=o.quaternion_key_moment(removed)
        k=(mask,residue,j)
        q=out.get(k,Q())+value*weights
        if q: out[k]=q
        elif k in out: del out[k]
    return out

def source_control(reg,x):
    y=reg.step(x,0)[0]
    # Site-varying exact phase with distinct first, mixed and repeated C2 slots.
    phase={x:jet_from_slots((0,1,2,0,1,0)),
           y:jet_from_slots((0,3,-1,2,-1,1))}
    charges={site:F(0) for site in reg.sites}
    charges[y]=F(3)
    positions={v:i for i,v in enumerate(reg.generator_order)}
    frame0=jet_from_slots((1,1,2,0,1,0))
    frame1=jet_from_slots((0,2,0,1,-1,0))

    def hopping(mu,a):
        actual=o.assemble_coframe(reg,f.original_coframe_blocks(reg,(x,mu,a)))
        direct=E(); slots={j:E() for j in INDICES}
        unsplit=raw_const(E())
        for (i,j),coefficient in actual.entries:
            xb,xp=reg.sites[i//4],reg.sites[j//4]
            bar=E.generator(positions[xb,'bar',i%4])
            psi=E.generator(positions[xp,'psi',j%4])
            e=bar*psi*coefficient
            delta=phase.get(xp,jet_from_slots((0,0,0,0,0,0)))-phase.get(xb,jet_from_slots((0,0,0,0,0,0)))
            iunit=Q(0,1)
            unsplit += raw_const(e)*o.exponential_jet(delta*iunit,P.scalar(1))
            slots[()]+=e
            for k in INDICES[1:]:
                c=delta.at(k)*iunit
                if len(k)==2: c-=delta.at((k[0],))*delta.at((k[1],))
                slots[k]+=e*c
        streamed=o.RawJet((0,1),tuple(slots.items()))
        assert pack(streamed)==pack(unsplit)
        return streamed,unsplit

    def exterior_scalar(jet):
        return o.RawJet((0,1),tuple((j,E(((0,v),))) for j,v in jet.entries))

    # Preserve the literal J,H,C identity as Symbols rather than family counts.
    def symbol(family,index,weight=None):
        base=coefficient_factor(S(family,index))
        return base if weight is None else base*weight

    left={};right={}
    cap=Caps(2_000_000,65_536)
    frame_a,frame_b=pack(exterior_scalar(frame0)),pack(exterior_scalar(frame1))
    for a in range(4):
        first,uf=hopping(0,a)
        second,us=hopping(1,a)
        ref=uf*frame0+us*frame1
        actual=add(multiply(pack(first),frame_a,cap),multiply(pack(second),frame_b,cap))
        assert actual==pack(ref)
        left[a]=(actual,ref)
        right[a]=(pack(us),us)
    literal_t=left[0]
    pairs=[multiply(left[a][0],right[a][0],cap) for a in range(4)]
    metric=add(*pairs)
    ref_metric=sum((left[a][1]*right[a][1] for a in range(4)),raw_const(E()))
    assert metric==pack(ref_metric)
    j=symbol('J',(x,0,0))
    h=symbol('H',(x,0,1))
    current_label=symbol('current',('chi-A',))
    split_t=multiply(literal_t[0],pack(j),cap)
    split_h=multiply(metric,pack(h),cap)
    reference_t=literal_t[1]*j
    reference_h=ref_metric*h
    assert split_t==pack(reference_t) and split_h==pack(reference_h)

    def phase_current(terms):
        out={}
        for (mask,key,slot),value in terms.items():
            charge=sum((charges[site] if kind=='psi' else -charges[site]
                        for i,(site,kind,_) in enumerate(reg.generator_order) if mask>>i&1),F(0))
            if charge: out[mask,key,slot]=value*Q(0,charge)
        return out

    current=multiply(phase_current(split_h),pack(current_label),cap)
    ref_current=o.apply_linear_map_jet(reference_h,lambda v:o.exterior_phase_derivative(v,reg,charges))*current_label
    assert current==pack(ref_current)
    assert current and all(any(k[-1]==slot for k in metric) for slot in INDICES)
    # A true Grassmann-degree-zero measure jet with one actual anchor.
    q0=S('q',(x,0,'L',0))
    measure=raw_const(E(((0,P.scalar(1)),)))+exterior_scalar(
        o.RawJet((0,1),(((0,),P.variable(q0)),((),P())))
    )
    def slots(terms):
        return {str(j):sum(key[-1]==j for key in terms) for j in INDICES}
    partitions=(('T',split_t,reference_t),('H',split_h,reference_h),
                ('V_chi_H',current,ref_current))
    with_measure={}
    # The three requested source sectors are disjoint in their exact
    # non-quaternion labels and this measure adds only q symbols.
    # Compare and discard one entire output partition at a time.
    source_signatures=[]
    for name,terms,ref in partitions:
        signature={tuple(symbol for symbol in key if symbol.family!='q')
                   for _,key,_ in terms}
        assert len(signature)==1 and not any(signature & old for old in source_signatures)
        source_signatures.append(signature)
        final=multiply(terms,pack(measure),cap)
        assert final==pack(ref*measure)
        with_measure[name]=slots(final)
        del final
    return {"all_raw_slots_equal_unsplit":True,"T":slots(split_t),"H":slots(split_h),
            "V_chi_H":slots(current),"with_measure_by_exact_source_sector":with_measure,
            "aggregate_join_visits":cap.used,"peak_records_for_one_join":cap.peak}

def breakout(reg,x):
    k,l,mu,nu,A,B=2,3,0,1,0,1
    def coframe(a):
        return pack(raw_const(o.assemble_coframe(reg,f.original_coframe_blocks(reg,a)).to_exterior(reg)))
    t0,t1=coframe((x,mu,A)),coframe((x,nu,B))
    cap=Caps(200_000,32_768)
    coframe_visits=len(t0)*len(t1)
    coframes=multiply(t0,t1,cap)
    del t0,t1
    a=(x,k)
    b=(reg.step(x,k)[0],l)
    c=(reg.step(x,l)[0],k)
    d=(x,l)
    def link(anchor):
        return f.original_spin4_link(*(tuple(P.variable(S('q',(*anchor,chi,i)))
                            for i in range(4)) for chi in ('L','R')))
    U=f.original_plaquette(reg,x,k,l,{a:link(a),b:link(b),c:link(c),d:link(d)})
    g=o.matrix_multiply(o.matrix_multiply(reg.gamma[A],reg.gamma[B]),reg.gamma5)
    curvature=sum((U[i][j]*g[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))
    trace=pack(raw_const(E(((0,curvature),))))
    assert len(coframes)==3584 and len(trace)==128
    assert all(all(s.index[:2] not in (a,b,c,d) for s in key) for _,key,_ in coframes)
    assert all({s.index[:2] for s in key}=={a,b,c,d} for _,key,_ in trace)

    def refuse(caps):
        try: multiply(coframes,trace,caps)
        except Limit as exc: return {"guard":exc.field,"used_visits":exc.visits,
                                     "attempted_live_records":exc.live,"retained_peak":caps.peak}
        raise AssertionError('bounded join should have refused')

    records=refuse(cap)
    visits=refuse(Caps(8_192,65_536))
    # Keep the complete coframe map and independent trace as a product
    # node. Absorb one actual future atom which shares the curvature
    # anchor. Check the regrouping on a bounded deterministic slice.
    future=coframe((reg.step(x,k)[0],k,0))
    future_cap=Caps(30_000,32_768)
    later=multiply(trace,future,future_cap,retained=len(coframes))
    assert later
    fkey=next(key for key in sorted(future) if any(s.index[:2]==a for s in key[1]))
    fsmall={fkey:future[fkey]}
    csmall=dict([item for item in sorted(coframes.items()) if not item[0][0]&fkey[0]][:8])
    assert len(csmall)==8
    left=multiply(multiply(csmall,trace,Caps(2_000_000,32_768)),fsmall,Caps(2_000_000,32_768))
    right=multiply(csmall,multiply(trace,fsmall,Caps(2_000_000,32_768)),Caps(2_000_000,32_768))
    assert left==right and len(left)==8*len(trace)
    # Independent same/opposite-anchor signed closure comparison on a complete
    # two-atom control. Never apply this closure to the above live branch.
    y=reg.step(x,0)[0]
    def dense(alpha):
        return o.assemble_coframe(reg,f.original_coframe_blocks(reg,alpha)).to_exterior(reg)
    pair=multiply(coframe((x,0,0)),coframe((y,0,0)),Caps(20_000,65_536))
    actual=closed_anchor(pair,{(x,0),(y,0)})
    ref={}
    for mask,p in (dense((x,0,0))*dense((y,0,0))).terms:
        value=sum((c*o.quaternion_key_moment(key) for key,c in p.terms),Q())
        if value: ref[mask,(),()]=value
    assert actual==ref and len(actual)==16
    return {"branch":(0,1),"grouped_world_order":(k,l,mu,nu),"components":(A,B),
            "coframe_join_visits":coframe_visits,"coframe_records":len(coframes),
            "trace_records":len(trace),"live_join_exact_product_from_disjoint_keys":len(coframes)*len(trace),
            "actual_record_breakout":records,"actual_visit_breakout":visits,
            "factorized_next_shared_anchor_join":{"visits":future_cap.used,"live_records":len(later),
                 "peak_records_including_retained_coframes":future_cap.peak,
                 "signed_regrouping_slice_records":len(left)},
            "signed_two_anchor_closure_nonzero_masks":len(actual)}

def main():
    for value in (float('nan'), float('inf'), 1.0, True, 0, -1, 2_000_001):
        try: Caps(value,1024)
        except ValueError: pass
        else: raise AssertionError(value)
    for value in (float('nan'),float('inf'), 1.0, False, 0, -1,65_537):
        try: Caps(1024,value)
        except ValueError: pass
        else: raise AssertionError(value)
    reg=o.OriginalRegulator()
    x=reg.sites[0]
    print(json.dumps({"local_alternatives":ALTERNATIVES,"source_conservation":source_control(reg,x),
                      "breakout":breakout(reg,x),"native_peak_rss":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                      "native_peak_unit":"bytes" if sys.platform=="darwin" else "KiB"},indent=2))

if __name__=='__main__':
    main()
