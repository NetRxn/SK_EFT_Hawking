import ast
from importlib.util import module_from_spec,spec_from_file_location
from pathlib import Path
import sys
p=Path('/tmp/publication-task4-streamed-frontier-r1.py')
spec=spec_from_file_location('pinned_streamed',p)
m=module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)
t=ast.parse(p.read_text())
f=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='source_control')
i=next(i for i,n in enumerate(f.body) if isinstance(n,ast.Assign) and
       isinstance(n.targets[0],ast.Name) and n.targets[0].id=='with_measure')
f.body[i:]=ast.parse("""
try:
    multiply(add(*(terms for _,terms,_ in partitions)), pack(measure), cap)
except Limit as exc:
    return (exc.field, exc.visits, exc.live, cap.peak)
raise AssertionError('unpartitioned experiment did not refuse')
""").body
ns=vars(m).copy()
exec(compile(ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[])),str(p),'exec'),ns)
reg=m.o.OriginalRegulator()
observed=ns['source_control'](reg,reg.sites[0])
assert observed==('records',967199,65537,65536),observed
print('Exact unpartitioned source/measure refusal replay:',observed)
