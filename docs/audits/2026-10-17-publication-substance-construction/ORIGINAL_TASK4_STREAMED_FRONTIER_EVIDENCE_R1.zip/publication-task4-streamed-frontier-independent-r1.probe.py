from fractions import Fraction as F
from importlib.util import module_from_spec,spec_from_file_location
from itertools import product
from math import factorial
import sys
spec=spec_from_file_location("author_frontier", "/tmp/publication-task4-streamed-frontier-r1.py")
m=module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)
Q=m.Q
S=m.S
def test_exception(fn,cls):
    try: fn()
    except cls as exc:return exc
    raise AssertionError('expected refusal')

# Independent sign via sorted generator sequence inversions and raw slots via
# ordinary Taylor coefficients, not the author's binomial implementation.
slots=((),(0,),(1,),(0,0),(0,1),(1,1))
x=(0,0,0,0)
q=S('q',(x,0,'L',0))
j=S('J',(x,0,0))
h=S('H',(x,0,1))
def derivative_factor(r): return factorial(r.count(0))*factorial(r.count(1))
a={(0b0101,(j,q),s):Q(n+1,n%2) for n,s in enumerate(slots)}
a.update({(0b0011,(h,),s):Q(2*n-1,1) for n,s in enumerate(slots)})
b={(0b1010,(q,),s):Q(3-n,2) for n,s in enumerate(slots)}
b.update({(0b0110,(q,),s):Q(n,1) for n,s in enumerate(slots)})
expected={}
for ((am,ak,u),av),((bm,bk,v),bv) in product(a.items(),b.items()):
    if am & bm or len(u+v)>2: continue
    combined=[i for i in range(8) if am>>i&1]+[i for i in range(8) if bm>>i&1]
    sign=(-1)**sum(combined[i]>combined[k] for i in range(len(combined)) for k in range(i+1,len(combined)))
    slot=tuple(sorted(u+v))
    key=(am|bm,tuple(sorted(ak+bk)),slot)
    taylor=av*bv*sign*F(1,derivative_factor(u)*derivative_factor(v))
    expected[key]=expected.get(key,Q())+taylor
expected={k:v*derivative_factor(k[2]) for k,v in expected.items() if v}
cap=m.Caps(144,200)
actual=m.multiply(a,b,cap,retained=5)
assert actual==expected and {k[-1] for k in actual}==set(slots)
assert cap.used==144 and cap.peak==len(a)+len(b)+5+len(actual)
# Actual product projectively retains labels and shared odd exponents until true
# last use. An isolated closed comparison tests that early projection loses it.
late=m.closed_anchor(actual,{(x,0)})
early=m.multiply(m.closed_anchor(a,{(x,0)}),m.closed_anchor(b,{(x,0)}),m.Caps(144,200))
assert late and not early

# Fresh bounded cap edge cases and internal accounting integrity.
for value in (float('nan'),float('inf'),float('-inf'),1.0,False,True,0,-1):
    test_exception(lambda:m.Caps(value,64),ValueError)
    test_exception(lambda:m.Caps(64,value),ValueError)
entry1={(1,(j,),()):Q(1)}
entry2={(2,(q,),()):Q(1)}
r=m.Caps(1,3)
assert len(m.multiply(entry1,entry2,r))==1 and r.used==1 and r.peak==3
r=m.Caps(1,2)
exc=test_exception(lambda:m.multiply(entry1,entry2,r),m.Limit)
assert (exc.field,exc.visits,exc.live,r.peak)==('records',1,3,2)
r=m.Caps(1,3)
exc=test_exception(lambda:m.multiply(entry1,{**entry2,(1,(),()):Q(1)},r),m.Limit)
# Input plus first output already exceeds 3, independently of visit cap.
assert (exc.field,exc.visits,exc.live)==('records',1,4)
r=m.Caps(1,4)
exc=test_exception(lambda:m.multiply(entry1,{**entry2,(1,(),()):Q(1)},r),m.Limit)
assert (exc.field,exc.visits,exc.live)==('visits',1,4)
# Explicitly record the scratch limitation, not a proposed production usage.
r=m.Caps(1,1)
assert len(m.multiply(entry1,entry2,r,retained=-2))==1
r=m.Caps(1,4)
r.used=2
assert len(m.multiply(entry1,entry2,r))==1 and r.used==3
print('all 6 raw slots exact vs Taylor oracle; both endpoint orders, source symbols and shared Haar powers conserved')
print('fresh-cap exact-boundary/attempted insertion/overlap visit probes passed')
print('scratch-only limitation confirmed: negative retained or a corrupted mutable used counter can bypass guards')
# At this selected regrouping at least three future centers retain each anchor.
all_sites=list(product(range(2),repeat=4))
def flip(site,j):return site[:j]+(1-site[j],)+site[j+1:]
future=set(all_sites)-{x,flip(x,2)}
curves=((x,2),(flip(x,2),3),(flip(x,3),2),(x,3))
future_refs={a:({a[0]}|{flip(a[0],j) for j in range(4)})&future for a in curves}
assert all(len(owners)>=3 for owners in future_refs.values())
print('future center incidence of each curvature anchor after the two selected centers:', list(map(len,future_refs.values())))
