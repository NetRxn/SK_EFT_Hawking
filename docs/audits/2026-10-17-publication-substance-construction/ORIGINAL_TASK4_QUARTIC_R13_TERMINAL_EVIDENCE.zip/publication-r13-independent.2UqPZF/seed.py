from collections import Counter
from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import random
import sys

path=Path('/tmp/publication-task4-continuation-quartic-r13.py')
spec=importlib.util.spec_from_file_location('r13_independent',path)
m=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)
frozen=Path('/tmp/publication-task4-continuation-powers-r10.progress.jsonl').read_bytes()
assert sha256(frozen).hexdigest()==m.PREFIX_DIGEST
prior=[json.loads(line) for line in frozen.splitlines()]
assert len(prior)==24 and sum(len(row['table']) for row in prior)==652
known=json.loads(Path('/tmp/publication-task4-continuation-quartic-r13.witness-control.json').read_text())
work=m.r5.Work(cap=2_500_000)
reg,(_,_,w),inputs,raw,d0,d1=m.r10.setup(work)
cx,hx,cw,choices,contacts,cy,hy=inputs
# Exact row order on actual distinct source storage. No cache across polynomials.
count=0
work_rows=m.r5.Work(cap=2_500_000)
for poly in (next(iter(cx.values())),next(iter(hx.values())),next(iter(cw.values())),
             next(iter(choices.values()))[1],contacts[m.SLOTS[1]]):
    frozen_rows=tuple(m.r10.r4.rows(poly))
    view=m.IndexedRows(poly,work_rows)
    assert view.terms is poly.terms and len(view)==len(frozen_rows)
    for i,want in enumerate(frozen_rows):
        assert view[i]==want
        count+=1
assert count>0
before=random.Random(20261107)
after=random.Random(20261107)
seen=set()
old_work=m.r5.Work(cap=250_000)
yielded=0
def candidates(powers,d):
    a=m.r10.seed(powers,cx,hx,cw,choices,d,cy,hy,before,old_work,seen)
    b=m.indexed_seed(powers,cx,hx,cw,choices,d,cy,hy,after,work,seen)
    return a,b
def compare(a,b):
    global yielded
    old=next(a)
    new=next(b)
    assert old==new and before.getstate()==after.getstate()
    locals=b.gi_frame.f_locals
    assert 'cache' not in locals and 'flat' not in locals
    assert not any(isinstance(value,m.IndexedRows) for value in locals.values())
    yielded+=1
    return new
for row in prior:
    expected=m.r6.decoded(row['target'])
    a,b=candidates(tuple(row['powers']),d1 if row['direction'] else d0)
    try:
        while True:
            core,seed,attempt=compare(a,b)
            if core==expected[:2]:
                assert attempt==row['attempt']
                assert m.json_identity(seed)==row['seeded']
                assert m.json_identity(m.r5.fingerprint((*core,expected[2])))==row['target']
                seen.add(core)
                break
    finally:
        a.close()
        b.close()
observed=[]
rejected=[]
for slot,direction,d in ((m.SLOTS[0],0,d0),(m.SLOTS[1],0,d0),(m.SLOTS[1],1,d1)):
    a,b=candidates(m.POWER,d)
    try:
        for _ in range(m.WITNESS_CANDIDATE_CAP):
            core,seed,attempt=compare(a,b)
            seen.add(core)
            target=(*core,slot)
            value,paths,peak=m.witness(target,seed,inputs,work,m.r10.LOCAL_CAP)
            row=dict(target=m.r5.fingerprint(target),direction=direction,seed=seed,attempt=attempt)
            if value:
                observed.append(dict(row,witness=str(value),paths=paths,peak=peak))
                break
            rejected.append(dict(row,zero_witness=str(value),witness_paths=paths,witness_peak=peak,work=work.used))
        else:
            raise AssertionError('witness retry cap')
    finally:
        a.close()
        b.close()
assert m.json_identity(observed)==known['rows']
assert m.json_identity(rejected)==known['rejected']
assert work.used==known['work']
print(json.dumps(dict(checked_actual_flat_rows=count,row_index_controls_work=work_rows.used,
    full_rng_state_matches=yielded,accepted=len(observed),rejected=len(rejected),
    witness_attempts=[row['attempt'] for row in observed],witness_coefficients=[row['witness'] for row in observed],
    witness_paths=[row['paths'] for row in observed],work=work.used,operations=dict(work.counts)),indent=2))
