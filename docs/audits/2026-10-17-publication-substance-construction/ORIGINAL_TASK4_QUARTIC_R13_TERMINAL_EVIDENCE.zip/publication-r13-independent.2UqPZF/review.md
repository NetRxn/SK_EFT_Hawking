# R13 independent original quartic admission review

**ADMIT one bounded original replay of the exact frozen candidate.**
Run with Python assertions enabled, current reviewed source and
unmodified predecessor inputs. ROOT owns execution. This is admission
to attempt the three original targets within the existing counters.
The full original coefficients and successful work fit remain open.

The R13, R10 and predecessor manifests verified. All author bounded
arithmetic and adverse controls reproduced byte-identically. The
independent continuation packet matched on exact primary
c75d4543292c5f754cb7c4877c6abf5b064b5280. No tracked changes, slot
actions or original coefficient evaluation were performed here.

## R12 seed cache corrected

R13 exposes a flat sequence length by summing the immutable
polynomial block lengths in the same order as r4.rows. Its indexed
read finds the first block containing the selected nonnegative
index and returns the same (mask, symbols, empty slot) and value.
Random.choice therefore invokes the same random index operation
on the same lengths. Random state, path ordering and branch
multiplicities are preserved. Every block count, block lookup
and selected row read is prospectively charged. The view holds
the original immutable coefficient tuple by reference, and the
current view is deleted before proceeding to the next operand
or yielding. This removes the previously observed 1,408–5,376
retained flattened coefficient records. The index-view reference
and constant-size transient returned row are not a copied
coefficient collection.

The unequal-block fixture independently checks five exact rows
and 96 matching random draws. Count, lookup and final selected-row
admission each fail at their exact low-work boundary. A separate
actual-source control additionally compares the old and new full
Random states at each target yield across the 24 accepted R10
requests and the three quartic witnesses including the canceled
request. It inspects each suspended new generator for any cache
or IndexedRows view and confirms all exact targets and seed labels
against the saved receipt.

## R11 repairs retained

The outer-path index and outer-group allocation share the named
local prospective bound. Two signed group updates incur two
charges. The raw canonical oracle counts the retained
production/outer rows and projected input rows when reserving
its prospective raw plus projected product scratch. The witness
phase precedes full candidate allocations and requires nonzero
exact signed value under a bounded retry. Both mixed requests
use d0+d1. The signed table carries 652 prior R10 records, leaving
1,396 under the 2,048 combined output cap.

All 64 arithmetic fixtures still pass, including coefficient and
path agreement for canceled rows. The 35 half-mask partitions
retain exact full-mask and commuting multiset checks with both
signed orders. The raw coefficient oracle remains independent
of the pair decomposition and shares the previously tested
outer grouping. Local 8,192 and raw oracle 16,384 are named
logical record caps. Work is capped at 20 million for this
new run. These counters do not measure native process RSS.

The independent actual-source replay matched 512 directly inspected
flat rows and 55 complete RNG-state comparisons at generated
targets. The three accepted witnesses at attempts 1, 7 and 5
had values 3/32768, -3/32768 and 1/32768, with 224, 320 and 72
paths. The one zero-witness rejection and its exact record also
matched. The witness-only diagnostic consumed 300,779 charges,
including 14,937 count-block, 20,679 lookup-block and 2,721 row-read
charges. No retained derived seed views were observed.

The sibling source, log, checksum readback and terminal packet
capture are the independent reproduction evidence.
