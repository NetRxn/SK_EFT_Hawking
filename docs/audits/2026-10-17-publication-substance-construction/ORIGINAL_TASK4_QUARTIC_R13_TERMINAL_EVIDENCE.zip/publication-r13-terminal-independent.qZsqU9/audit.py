from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,re

root=Path('/tmp')
base=root/'publication-task4-continuation-quartic-r13'
prefix=root/'publication-task4-continuation-powers-r10.progress.jsonl'
def load(s): return Path(str(base)+s).read_text()
def rows(text): return [json.loads(s) for s in text.splitlines()]
def coeff(s):
    m=re.fullmatch(r'QComplex\(storage=\((-?\d+), (\d+), (-?\d+), (\d+)\)\)',s)
    assert m,s
    a,b,c,d=map(int,m.groups())
    assert b>0 and d>0
    ar,ai=F(a,b),F(c,d)
    assert (ar.numerator,ar.denominator,ai.numerator,ai.denominator)==(a,b,c,d)
    return ar,ai
def time(s): return datetime.strptime(s.strip(),'%a %b %d %H:%M:%S UTC %Y').replace(tzinfo=timezone.utc)
assert load('.original.exit').strip()=='0' and not load('.original.stdout')
elapsed=(time(load('.original.stop'))-time(load('.original.start'))).total_seconds()
assert elapsed==84
actual=rows(load('.original.jsonl'))
control=json.loads(load('.witness-control.json'))
logged=rows(load('.original.stderr'))
log_accept=[r for r in logged if 'zero_witness' not in r]
log_reject=[r for r in logged if 'zero_witness' in r]
assert len(actual)==4 and len(logged)==4 and len(log_reject)==1
assert {k:v for k,v in log_reject[0].items() if k!='work'}=={k:v for k,v in control['rejected'][0].items() if k!='work'}
assert coeff(log_reject[0]['zero_witness'])==(0,0) and log_reject[0]['witness_paths']==384
summary=actual.pop()
out=[]
prior=rows(prefix.read_text())
assert sha256(prefix.read_bytes()).hexdigest()==control['prefix_digest']
assert len(prior)==24 and sum(len(r['table']) for r in prior)==652
fingerprints={json.dumps(r['target'],sort_keys=True) for r in prior}
assert len(fingerprints)==24
slots=[([0],0),([0,1],0),([0,1],1)]
for i,(record,chosen,log) in enumerate(zip(actual,control['rows'],log_accept,strict=True)):
    t=record['target']
    key=json.dumps(t,sort_keys=True)
    assert key not in fingerprints
    fingerprints.add(key)
    assert (t['slot'],record['direction'])==slots[i]
    assert all(record[k]==chosen[k]==log[k] for k in ('target','seed','attempt','direction'))
    assert int(t['mask_hex'],16).bit_count()==26
    assert Counter(s[0] for s in t['symbols'])=={'J':1,'g2':6,'q':37}
    assert len(record['seed'][1])==4 and all(k[0]==2 for k in record['seed'][1])
    witness=coeff(record['seeded_coefficient'])
    assert witness==(F([3,-3,1][i],32768),0) and record['seeded_coefficient']==chosen['witness']
    assert record['seeded_paths']==chosen['paths']==[224,320,72][i]
    groups={}
    for k,v,n in record['coefficients']:
        k=tuple(map(tuple,k))
        assert k not in groups and all(len(x)==6 for x in k)
        assert type(n) is int and n>0
        groups[k]=coeff(v),n
    assert list(groups)==sorted(groups)
    assert len(groups)==record['output_records']==[32,4,8][i]
    total=tuple(sum(v[j] for v,_ in groups.values()) for j in range(2))
    assert total==coeff(record['total'])==(0,0)
    xy_key=tuple(record['seed'][0]),tuple(record['seed'][2])
    assert groups[xy_key]==(coeff(record['seeded_xy_sum']),record['seeded_xy_paths'])
    nz=sum(bool(a or b) for (a,b),_ in groups.values())
    assert all(not b for (a,b),_ in groups.values())
    assert [4481,8068,5916][i]==record['local_peak']<=8192
    assert [20,4,4][i]==record['later_paths']<=8192
    assert [22,3,4][i]==record['quartic_local_keys']
    out.append(dict(slot=t['slot'],direction=record['direction'],attempt=record['attempt'],
        retained_groups=len(groups),nonzero_groups=nz,canceled_groups=len(groups)-nz,
        signed_real_histogram={str(k):v for k,v in sorted(Counter(a for (a,_),n in groups.values()).items())},
        path_sum=sum(n for _,n in groups.values()),seeded_group_paths=record['seeded_xy_paths'],
        seeded_group_coefficient=str(coeff(record['seeded_xy_sum'])[0]),witness=str(witness[0]),
        witness_paths=record['seeded_paths'],local_peak=record['local_peak'],
        later_paths=record['later_paths'],local_keys=record['quartic_local_keys']))
assert all(type(v) is int and v>0 for v in summary['work'].values())
assert sum(summary['work'].values())==summary['work_total']==6053034<=20_000_000
assert summary['oracle_peak']==4244<=16384
assert summary['prefix_output_records']==652
assert summary['quartic_output_records']==sum(r['retained_groups'] for r in out)==44
assert summary['cumulative_output_records']==652+44==696<=2048
assert summary['work']['quartic_center_splits']==105
assert summary['work']['quartic_direct_targets']==sum(r['local_keys'] for r in out)==29
assert summary['work']['quartic_receipt_rows']==44
assert summary['work']['quartic_later_rows']==sum(r['later_paths'] for r in out)==28
print(json.dumps(dict(terminal_exit=0,elapsed_seconds=elapsed,prefix_requests=len(prior),
                      scoped_requests=len(fingerprints),actual=out,summary=summary),indent=2))
