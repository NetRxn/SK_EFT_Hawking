from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json,re

def coeff(s):
    a,b,c,d=map(int,re.fullmatch(r'QComplex\(storage=\((-?\d+), (\d+), (-?\d+), (\d+)\)\)',s).groups())
    return F(a,b),F(c,d)
def mul(a,b): return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def key(x): return json.dumps(x,separators=(',',':'))
data=json.loads(Path('/tmp/publication-task4-multicenter-s2s2-r1.witness-control.json').read_text())
assert data['identity']=={'R9':18,'R10':3} and data['prefix']==696
assert data['work']==247822==sum(data['counts'].values())
assert len(data['rows'])==3 and len(data['rejected'])==1
seen=set()
out=[]
for row in [*data['rows'],*data['rejected']]:
    target=row['target']
    assert key(target) not in seen
    seen.add(key(target))
    path=row['path']
    assert len(path)==13 and row['reserved_path_records']==14
    terms=Counter()
    mask=0
    value=(F(1),F(0))
    for i,(mask_text,symbols,coefficient) in enumerate(path):
        m=int(mask_text,16)
        assert not mask&m
        assert m.bit_count()==(0 if i in (2,5,8,12) else 2)
        parity=sum(a>b for a,b in product(range(128),repeat=2) if (1<<a)&mask and (1<<b)&m)
        sign=(-1)**parity
        value=mul(value,tuple(sign*c for c in coeff(coefficient)))
        terms.update(map(key,symbols))
        mask|=m
    assert mask==int(target['mask_hex'],16) and mask.bit_count()==18
    assert terms==Counter(map(key,target['symbols']))
    families=Counter(family for family,_ in target['symbols'])
    assert families=={'q':25,'J':1,'g2':4}
    if target['slot']==[0]:
        left=Counter(key(s) for _,syms,_ in path[3:5] for s in syms)
        right=Counter(key(s) for _,syms,_ in path[6:8] for s in syms)
        shared=key(row['repeated'][0])
        assert shared in left and shared in right
        assert row['repeated'][0]==['q',[[0,0,1,0],0,'L',3]]
    if row['paths']==1:
        assert value==coeff(row['witness'])
    out.append(dict(slot=target['slot'], direction=row['direction'], attempt=row['attempt'], lineage_term=list(map(str,value)),
                    complete_branch=list(map(str,coeff(row['witness']))), paths=row['paths']))
print(json.dumps(out,indent=2))
