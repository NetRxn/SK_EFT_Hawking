from pathlib import Path
import importlib.util,json,sys
p=Path('/tmp/publication-task4-multicenter-s2s2-r1.py')
spec=importlib.util.spec_from_file_location('s2s2_liveness',p)
m=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)
def fixture(_inputs,_zi,slot,direction,*args):
    lineage=[(1<<i,(),m.ONE) for i in range(13)]
    yield (8191,(),slot), direction, ((),(),(),()), 1, [], lineage
def check(_target,_inputs,_zi,_selected,_work,carry):
    outer=sys._getframe(1).f_locals
    previous=outer.get('receipt')
    observed.append(dict(carry=carry,prior_serialized_rows=len((previous or {}).get('table',[])),
                         prior_witness_path_rows=len((previous or {}).get('path',[]))))
    return m.ONE,1,carry
m.seed_candidates=fixture
m.selected_witness=check
observed=[]
g=m.witness_candidates(None,None,None,None,None,None,None,lambda _:None)
*_, receipt=next(g)
receipt['table']=[(i,0,1) for i in range(1352)]
del receipt
*_, receipt=next(g)
assert observed[0]==dict(carry=14,prior_serialized_rows=0,prior_witness_path_rows=0)
assert observed[1]==dict(carry=14,prior_serialized_rows=1352,prior_witness_path_rows=13)
g.close()
old=json.loads(Path('/tmp/publication-task4-continuation-vertices-r9.json').read_text())['targets']
rows=sum(len(value_rows) for row in old for _,value_rows,_ in row['groups'])
headers=sum(len(row['groups']) for row in old)
r10=[json.loads(line) for line in Path('/tmp/publication-task4-continuation-powers-r10.progress.jsonl').read_text().splitlines()]
prefix=[dict(signed_rows=len(row['table']),reference_rows=len(row['reference'])) for row in r10 if row['powers']==[1,0]]
assert rows==1280 and headers==456 and len(prefix)==3
print(json.dumps(dict(witness_liveness=observed,r9_targets=len(old),r9_group_headers=headers,r9_value_rows=rows,r10_matched_decoded_rows=prefix),indent=2))
