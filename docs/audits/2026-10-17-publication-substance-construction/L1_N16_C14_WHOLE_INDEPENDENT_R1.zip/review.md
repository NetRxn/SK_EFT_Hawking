# Independent sector 0101 and full original c14 review

The subject is the original periodic closed source_C zero-source N16 denominator at clean primary 27012c18fa374e8341e124b510abbedeedb18d29. The frozen author manifest has SHA256 cd81f92d859f6f63f7b7860f737d737b89e44649c62ab70eaedf1dbd9e528b67. Its entries and all declared input digests verify.

## Independent sector arithmetic

For ordered LRLR sector 0101 of the zero-centered 01/23 representative, I loaded the original accepted source-bound graph, restricted each actual q slot by its occurrence, and only then relabeled its coordinate within chirality. The 36,608 Boolean tile rows and 100 bridge rows follow from the exact source predicates. Independent exact hash joins in canonical variable order reproduce every row of the eleven-join frontier. The 96 primitive signed interior rays reconstruct all original exterior slices. Prospectively counted numeric source joins total 1,611,776, under a 4,000,000 guard with exact row and scalar guards.

I independently derived each half response by joining the original masks and evaluating literal wedge signs. The 25 and 1,024 normalized signed half response tables, every signed response normalization, all 2,980 coalesced nonzero environment pairs, and the 43,024,384 direct prospective visits agree. The admitted weighted mask evaluation traversed all 3,293,184 exact signed products under a separate hard 4,000,000-product guard. It reproduces all 4,096 signed mask weights and 5,120 canceled keys. All four original fixed-mask controls match the literal top word and reverse sign with its orientation. The four complete direct weighted mask controls were independently recomputed across the original 178,150 environment rows, without the normalized half quotient, including their adverse one-product signs.

Independent exact rational fixed-entry reconstruction reproduces all 64 original spoke matrices. In a separate dense Gaussian-integer route I formed each trace-pair tensor from the literal source traces and applied exact axis transforms. I checked all 24 prospective axis orders, selected the deterministic minimum and reproduced each of the 32 author logical partition bounds, actual sparse-support visits and per-axis nonzero counts. The independent dense route was admitted separately under a conservative bound of 383,778,816 real products and checked signed 64-bit payloads and table sizes before use. It reproduces all 3,072 nonzero transforms on each side and the implied exact zeros. The author logical preflight of 30,943,250, actual total 12,336,146, maximum ray prospect 800,768, maximum ray actual work 219,296 and peak 9,216 nonzero intermediate rows match. The rejected earlier 24M schedule exceeded its stated cap. Sampled peak RSS and scoped byte and work receipts check out.

I independently streamed all 5,308,416 exact middle products in the two stated partitions of 3,999,456 and 1,308,960 under a hard 4,000,000-per-partition guard. Their complete selected keys exactly match both 14,848-entry supports. Clearing each middle denominator by two gives an integer calculation with exact cancellation of the common factor at the end. The 962,560 nonzero middle paths yield all 4,096 exact signed amplitudes. The independent joins, transform and original-control processes observed peak RSS of 205,209,600, 91,291,648 and 58,048,512 bytes, below their 384 MiB sampled guard.

The two independent original-spoke controls use the raw 16-by-16 matrices and original trace-pair arrays, without Gaussian basis coordinates. Their support counts give 2,876,416 compatible products each, below the 4,000,000 numeric guard. Independent exact Gaussian mode contraction gives +1,460,288,880,640 and -1,460,288,880,640. I found an actual contributing signed path in each whose reversal yields the exact recorded adverse numerators 1,460,255,326,208 and -1,460,297,268,248. The frozen author aggregate work is 4,316,522 per control under its separately admitted 6M cap.

The exact signed dot product has normalized numerator 5,699,868,278,390,784 + 0i and restored mask gcd 30,415,295,297,447,983,042,265,088. The inherited graph denominator, scalar 24^5 and original row factorial divisor 512 are applied once. The independently reproduced exact contribution is

`C0101 = 5065164171/4611686018427387904 + 0i`.

## Full mixed coefficient

I verified the manifests of the three preceding independent numerical sector reviews and the independent signed source transport. An explicit sector enumeration under the two occurrence swaps, plane exchange and global complement gives the orbit sizes 2, 8, 2 and 4. Summing all 16 exact sector contributions at the canonical zero-root arrangement gives 102294681665067/1152921504606846976. The independently verified exact parity table has 1,920 vanishing occupancy rows. Its three surviving axis arrangements each have 16 translations. Summing all 48 equivalent rows gives

`[g1^14 g2^4] Z = c14 = 306884044995201/72057594037927936 + 0i`.

The original 512 divisor is already present in the sector values. Reintroducing the unweighted sectors and dividing exactly once independently reproduces the same result.

**Frozen verdict** Accept the complete independently replayed sector 0101 and the full original mixed coefficient c14 for the stated zero-source periodic closed regulator. Terminal continuity is fresh and the primary checkout is clean. Pure c0, other unknown grades, the complete original denominator and normalization of observables remain outside this acceptance.
