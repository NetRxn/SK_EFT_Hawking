from collections import defaultdict
from fractions import Fraction as Q
from functools import cache
from itertools import product
from math import gcd,prod
from pathlib import Path
import json,sys,resource

def rss():
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    assert n<384*1024**2
    return n

import numpy as np
A=Path(sys.argv[1])
C=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
def rows(f):
    for line in f.open():yield json.loads(line)
def f(x):return tuple(map(f,x)) if isinstance(x,(tuple,list)) else x
def add(z,w):return z[0]+w[0],z[1]+w[1]
def mul(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def pair(z):
    a,b,c,d=z
    return Q(a,b),Q(c,d)
raw={};trace={}
for name,labels,tab in rows(A/'interior-rays.jsonl'):
    if name.startswith('trace'):trace[name]=(labels,{tuple(k):tuple(z) for k,z in tab})
    else:raw[name]=(labels,{j:{tuple(k):tuple(z) for k,z in v} for j,v in tab})
M={tuple(k):v for k,v in rows(A/'weighted-mask-amplitude-0101.jsonl')}
assert len(M)==4096
basis={};middles={}
for record in rows(A/'spoke-bases.jsonl'):
    name=record['name']
    cl=defaultdict(dict);rr=defaultdict(dict)
    for i,k,z in record['column']:cl[k][i]=pair(z)
    for k,i,z in record['row']:rr[k][i]=pair(z)
    mid={int(k):{(i,j):pair(z) for i,j,z in v} for k,v in record['coordinates'].items()}
    basis[name]=(cl,rr);middles[name]=mid
    assert (len(cl),len(rr))==((10,16) if name in 'AB' else (16,10)) and len(mid)==16
    # Recover complete matrices by fixed entry dot products, exact Gaussian rationals.
    for j,source in raw[name][1].items():
        result={}
        for u,v in product(range(16),repeat=2):
            value=(0,0)
            for (i,k),z in mid[j].items():
                value=add(value,mul(mul(cl[i].get(u,(0,0)),z),rr[k].get(v,(0,0))))
            a,b=divmod(u,4); c,d=divmod(v,4)
            key=(c,d,a,b) if name in 'CD' else (a,b,c,d)
            if any(value):result[key]=value
        assert result==source
print('all 64 exact Gaussian spoke matrices reconstructed entry-by-entry',flush=True)
coords=[
 (('a1_0','a0_0','q02_0','q03_0'),('a1_1','a0_1','q02_1','q03_1'),('q23_0','q12_0'),('q23_1','q12_1')),
 (('q01_2','q00_2','a2_2','a3_2'),('q01_3','q00_3','a2_3','a3_3'),('q40_2','q81_2'),('q40_3','q81_3'))]
def tensor(which,j):
    name=f'trace{2*which+j}'
    labels,table=trace[name]
    k=[labels.index(a) for a in coords[which][j]+coords[which][2+j]]
    ans=np.zeros((2,4,4,4,4,16),dtype=np.int64)
    for a,z in table.items():
        x,b,c,d,e,f0=(a[i] for i in k)
        ans[:,x,b,c,d,4*e+f0]=z
    return ans
def split_bound(a):return sum(int(np.max(np.abs(i))) for i in a)
from math import prod
def gm(a,b):
    return np.stack((a[0]@b[0]-a[1]@b[1],a[0]@b[1]+a[1]@b[0]))
def srcpair(side,e):
    X,Y=[tensor(side,j).reshape(2,256,16) for j in (0,1)]
    W=np.zeros((2,16,16),dtype=np.int64)
    for (a,b,c,d),z in raw['EF'[side]][1][e].items():W[:,4*a+c,4*b+d]=z
    bound=16**2*split_bound(X)*split_bound(Y)*split_bound(W)
    assert bound<2**63
    u=gm(gm(X,W),np.swapaxes(Y,1,2))
    return u.reshape((2,)+(4,)*8).transpose((0,1,5,2,6,3,7,4,8)).reshape(2,16,16,16,16)
for c in range(2):
    ctl=json.loads((A/f'raw-control-{c}.json').read_text())
    key=ctl['ray_key']
    L,R=srcpair(0,key[4]),srcpair(1,key[5])
    left=[tuple(map(int,t)) for t in np.argwhere(np.any(L,axis=0))]
    right=[tuple(map(int,t)) for t in np.argwhere(np.any(R,axis=0))]
    assert len(left)==ctl['left_nonzero']==9216 and len(right)==ctl['right_nonzero']==9216
    sparse=[]
    for n,k in zip('ABCD',key[:4],strict=True):
        table={}
        for (a,b,c0,d),z in raw[n][1][k].items():
            u,v=4*a+b,4*c0+d
            table[(v,u) if n in 'CD' else (u,v)]=z
        sparse.append(table)
    # Represent each right support as an incidence bitset with tuple
    # indices in independent lexicographic order.
    incidence=[[0]*16 for _ in range(4)]
    for index,point in enumerate(right):
        for a,v in enumerate(point):incidence[a][v]|=1<<index
    match=[]
    for i,t in enumerate(sparse):
        mask=[0]*16
        for u,v in t:mask[u]|=incidence[i][v]
        match.append(mask)
    plan=[]
    count=0
    for point in left:
        u,v,w,z=point
        k=match[0][u]&match[1][v]&match[2][w]&match[3][z]
        if k:
            count+=k.bit_count()
            plan.append((point,k))
    assert count==ctl['nonzero_literal_pairs']==2876416 and count<=4_000_000
    # Independently integrate the complete original 16×16 spoke matrices
    # by dense integer mode transforms, without Gaussian basis coordinates.
    T=L
    bound=split_bound(L)
    dense_work=4*4*16**5+4*16**4
    assert dense_work<18_000_000
    for a,t in enumerate(sparse):
        m=np.zeros((2,16,16),dtype=np.int64)
        for (i,j),z in t.items():m[:,i,j]=z
        bound*=16*split_bound(m)
        assert bound<2**63
        D=lambda x,y:np.moveaxis(np.tensordot(x,y,axes=(a,0)),-1,a)
        T=np.stack((D(T[0],m[0])-D(T[1],m[1]),D(T[0],m[1])+D(T[1],m[0])))
    assert bound*split_bound(R)*16**4<2**63
    total=(int((T[0]*R[0]-T[1]*R[1]).sum()),int((T[0]*R[1]+T[1]*R[0]).sum()))
    assert total==tuple(ctl['exact_numerator'])
    adverse=tuple(ctl['adverse_single_path_flip'])
    needed=tuple((x-y)//2 for x,y in zip(total,adverse))
    found=False
    visits=0
    for x,bits in plan:
        X=tuple(int(v) for v in L[(slice(None),*x)])
        while bits:
            low=bits&-bits
            bits^=low
            y=right[low.bit_length()-1]
            z=mul(X,tuple(int(v) for v in R[(slice(None),*y)]))
            for i,t in enumerate(sparse):z=mul(z,t[x[i],y[i]])
            visits+=1
            assert visits<=count<=4_000_000
            if z==needed:
                found=True
                break
        if found:break
    assert found and tuple(x-2*y for x,y in zip(total,needed))==adverse
    print('literal original-spoke support and independent dense exact sum',c,count,total,'single path adverse',adverse,'witness search visits',visits,flush=True)

print('independent original-spoke guard held; peak process RSS',rss(),flush=True)
