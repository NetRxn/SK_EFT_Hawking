from fractions import Fraction
from itertools import product
from pathlib import Path
import hashlib,json,sys
a,d=map(Path,sys.argv[1:])
accepted=[
 ('0000',Path('/tmp/publication-c14-sector0000-independent.6VAlQF'),'3cf86f98b6dc40274dd32d6232bba33474bd65afc0d255ee6fe7ff82a6cacc81'),
 ('0001',Path('/tmp/publication-c14-sector0001-independent.QJtgTH'),'3b33ae19b5f4a74cc7f57a7022cd36e9d1c6b7866fef0a60eef48f44d3c2710f'),
 ('0011',Path('/tmp/publication-c14-sector0011-independent.Nge7n6'),'6a921b9a2a83fc52df579dc3d638e0ce771f93bd44c22ed62ffaef8678741192')]
sym=Path('/tmp/publication-c14-sector-symmetry-independent.T8KFY4')
def verify(p,sha):
    manifest=p/'manifest.sha256'
    assert hashlib.sha256(manifest.read_bytes()).hexdigest()==sha
    for item in manifest.read_text().splitlines():
        digest,file=item.split(maxsplit=1)
        assert hashlib.sha256((p/file).read_bytes()).hexdigest()==digest
for _,p,sha in accepted:verify(p,sha)
verify(sym,'785ef658465fd0394f3ba3fe5f4fac546911a12e2f6113790f3b70d50a6fedea')
C={}
for key,p,_ in accepted:
    lines=(p/'transform.log').read_text().splitlines()
    tokens=next(line.split()[-2:] for line in lines if line.startswith(f'independent exact sector{key} scalar'))
    real,imag=map(Fraction,tokens)
    assert not imag
    C[key]=real
real,imag=map(Fraction,next(line.split()[-2:] for line in (d/'transform.log').read_text().splitlines() if line.startswith('independent exact C0101')))
assert not imag
C['0101']=real
def images(k):
    u,v,w,x=k
    return (v+u+w+x,u+v+x+w,w+x+u+v,''.join('0' if v=='1' else '1' for v in k))
assignment={}
orbit={}
for k,val in C.items():
    members=set();todo=[k]
    while todo:
        s=todo.pop()
        if s not in members:
            members.add(s)
            todo.extend(images(s))
    assert not(set(assignment)&members)
    for s in members:assignment[s]=val
    orbit[k]=len(members)
assert orbit=={'0000':2,'0001':8,'0011':2,'0101':4}
assert set(assignment)=={''.join(s) for s in product('01',repeat=4)}
can=sum(assignment.values())
# Independently reproduce surviving original row count from the frozen exact
# parity roster. Each translated row and each axis arrangement carries the
# same value by the source-exact verified orbit argument.
p=Path('/tmp/publication-c14-edge-parity-root-r2.N2b34r/result.json')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='390fdebb754ab1ce564c47bc5445a17b414017928e7b39993ef588f74d46ee3b'
parity=json.loads(p.read_text())
nodd=sum(x['rows'] for x in parity['counts'] if not x['even'])
neven=sum(x['rows'] for x in parity['counts'] if x['even'])
assert nodd==1920 and neven==48
assert [v['size'] for v in parity['translation_orbits']]==[16,16,16]
assert all(v['factorial_divisor']==512 for v in parity['translation_orbits'])
# Each accepted C already includes 512. Explicitly reinsert and divide
# once to independently check that no second factorial division occurred.
whole=sum(512*val for _ in range(neven) for val in assignment.values())/512
assert whole==neven*can
report=json.loads((a/'provisional-c14.json').read_text())
assert can==Fraction(report['canonical_zero_root_arrangement'])
assert whole==Fraction(report['provisional_c14'])
print(json.dumps(dict(sectors={k:str(v) for k,v in C.items()},orbit_sizes=orbit,canonical_root_sum=str(can),
                      parity_zero_rows=nodd,arrangements=3,translations=16,whole_c14=str(whole),imaginary_part='0',
                      external_factorial_divisor=512,divisor_applied_once=True),indent=2))
