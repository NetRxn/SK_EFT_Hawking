from pathlib import Path
import json,sys
a=Path(sys.argv[1])
def load(n):return json.loads((a/n).read_text())
u=load('result-0101-stop11.json'); m=load('mask-admission.json'); n=load('mask-numeric.json'); k=load('mask-check.json'); q=load('q-result.json')
assert u['total_work']==sum(u['work'].values())==1997159<4_000_000
assert m['preflight_meters']['work']==sum(m['preflight_work'].values())==1261802<4_000_000
assert n['meters']['work']==sum(n['work'].values())==3301309<4_000_000
assert n['meters']['output']==(a/'weighted-mask-amplitude-0101.jsonl').stat().st_size==187264
assert k['meters']['work']==sum(k['work'].values())==1615753<4_000_000
assert load('basis-preflight.json')['charged_visits']==550528
assert '38610962, 24000000' in (a/'q-tensor-refusal.log').read_text().splitlines()[-1]
assert '1440106, 2876416, 4000000' in (a/'raw-control-initial-refusal.log').read_text().splitlines()[-1]
assert sum(q['work'].values())==q['total_work']==12336146
assert (q['caps']['aggregate_work'],q['caps']['ray_work'],q['caps']['rows_per_table'],q['caps']['scalar'])==(40000000,4000000,200000,2**127-1)
assert q['sampled_peak_rss']==39616512<384*1024**2
assert not q['other_sectors_evaluated'] and not q['full_representative_evaluated']
for i in range(2):
    p=load(f'raw-control-{i}.json')
    assert sum(p['work'].values())==p['charged']==4316522<p['cap']==6000000
    assert p['nonzero_literal_pairs']==2876416<p['numeric_pair_cap']==4000000
print('all source/mask/transform/control work and payload caps, reported refusals, and sampled RSS/byte receipts checked')
