from collections import defaultdict
from fractions import Fraction as Q
from functools import cache
from itertools import product
from math import gcd,prod
from pathlib import Path
import json,sys,resource

def rss():
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    assert n<384*1024**2
    return n

import numpy as np
A=Path(sys.argv[1])
C=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
def rows(f):
    for line in f.open():yield json.loads(line)
def f(x):return tuple(map(f,x)) if isinstance(x,(tuple,list)) else x
def add(z,w):return z[0]+w[0],z[1]+w[1]
def mul(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def pair(z):
    a,b,c,d=z
    return Q(a,b),Q(c,d)
raw={};trace={}
for name,labels,tab in rows(A/'interior-rays.jsonl'):
    if name.startswith('trace'):trace[name]=(labels,{tuple(k):tuple(z) for k,z in tab})
    else:raw[name]=(labels,{j:{tuple(k):tuple(z) for k,z in v} for j,v in tab})
M={tuple(k):v for k,v in rows(A/'weighted-mask-amplitude-0101.jsonl')}
assert len(M)==4096
basis={};middles={}
for record in rows(A/'spoke-bases.jsonl'):
    name=record['name']
    cl=defaultdict(dict);rr=defaultdict(dict)
    for i,k,z in record['column']:cl[k][i]=pair(z)
    for k,i,z in record['row']:rr[k][i]=pair(z)
    mid={int(k):{(i,j):pair(z) for i,j,z in v} for k,v in record['coordinates'].items()}
    basis[name]=(cl,rr);middles[name]=mid
    assert (len(cl),len(rr))==((10,16) if name in 'AB' else (16,10)) and len(mid)==16
    # Recover complete matrices by fixed entry dot products, exact Gaussian rationals.
    for j,source in raw[name][1].items():
        result={}
        for u,v in product(range(16),repeat=2):
            value=(0,0)
            for (i,k),z in mid[j].items():
                value=add(value,mul(mul(cl[i].get(u,(0,0)),z),rr[k].get(v,(0,0))))
            a,b=divmod(u,4); c,d=divmod(v,4)
            key=(c,d,a,b) if name in 'CD' else (a,b,c,d)
            if any(value):result[key]=value
        assert result==source
print('all 64 exact Gaussian spoke matrices reconstructed entry-by-entry',flush=True)
coords=[
 (('a1_0','a0_0','q02_0','q03_0'),('a1_1','a0_1','q02_1','q03_1'),('q23_0','q12_0'),('q23_1','q12_1')),
 (('q01_2','q00_2','a2_2','a3_2'),('q01_3','q00_3','a2_3','a3_3'),('q40_2','q81_2'),('q40_3','q81_3'))]
def tensor(which,j):
    name=f'trace{2*which+j}'
    labels,table=trace[name]
    k=[labels.index(a) for a in coords[which][j]+coords[which][2+j]]
    ans=np.zeros((2,4,4,4,4,16),dtype=np.int64)
    for a,z in table.items():
        x,b,c,d,e,f0=(a[i] for i in k)
        ans[:,x,b,c,d,4*e+f0]=z
    return ans
def split_bound(a):return sum(int(np.max(np.abs(i))) for i in a)
from itertools import permutations
from collections import Counter
expected=json.loads((A/'selected-basis-keys.json').read_text())
selected=[set(map(tuple,expected[k])) for k in ('left','right')]
assert list(map(len,selected))==[14848,14848]
def gm(a,b):
    return np.stack((a[0]@b[0]-a[1]@b[1],a[0]@b[1]+a[1]@b[0]))
def bm(n,side):
    t=basis[n][side]
    z=np.zeros((2,16,len(t)),dtype=np.int64)
    for j,tab in t.items():
        for k,c in tab.items():
            assert all(v.denominator==1 for v in c)
            z[:,k,j]=list(map(int,c))
    return z
rawpair=[{},{}]
result=json.loads((A/'q-result.json').read_text())
admission=json.loads((A/'tensor-admission.json').read_text())
out=[{},{}]
receipts=[]
prospective=[]
# Precompute and enforce the entire original logical-partition admission.
dense_budget=0
for side in (0,1):
    B=[bm(n,side) for n in 'ABCD']
    def plan(order):
        dim=[16]*4
        vals=[]
        for i in order:
            vals.append(int(np.count_nonzero(np.any(B[i],axis=0)))*prod(x for j,x in enumerate(dim) if j!=i))
            dim[i]=B[i].shape[-1]
        return sum(vals),order,vals
    _,order,vals=min(plan(o) for o in permutations(range(4)))
    X,Y=[tensor(side,i).reshape(2,256,16) for i in (0,1)]
    N=[np.count_nonzero(np.any(t,axis=0),axis=0) for t in (X,Y)]
    for e in sorted({k[0] for k in selected[side]}):
        mat=np.zeros((2,16,16),dtype=np.int64)
        for (a,b,c,d),z in raw['EF'[side]][1][e].items():mat[:,4*a+c,4*b+d]=z
        n=int(sum(N[0][u]*N[1][v] for u,v in zip(*np.where(np.any(mat,axis=0)))))
        record=dict(side=('left','right')[side],ray=e,source_pair_products=n,axis_order=list(order),transform_upper_bounds=vals,prospective=n+sum(vals))
        assert record['prospective']<=4_000_000
        prospective.append((record,side,e,X,Y,mat,B))
        dim=[16]*4
        # Count every real contraction product in the independent dense route,
        # including zeros. Fixed-shape separate safety budget, enforced up front.
        dense_budget+=4*(256*16*16+256*256*16)
        for i in order:
            dense_budget+=4*16*B[i].shape[-1]*prod(x for j,x in enumerate(dim) if j!=i)
            dim[i]=B[i].shape[-1]
assert [q[0] for q in prospective]==admission['admitted_ray_partitions']
pre=10+4+4+4096+2*sum(len(t) for _,t in trace.values())
assert pre==admission['initial_charged']==10258
assert pre+sum(q[0]['prospective'] for q in prospective)+5308416==admission['prospective_aggregate']==30943250
assert 30943250<40_000_000 and dense_budget<650_000_000
for record,side,e,X,Y,mat,B in prospective:
    n=record['source_pair_products']
    bound=16*16*split_bound(X)*split_bound(Y)*split_bound(mat)
    assert bound<2**63
    T=gm(gm(X,mat),np.swapaxes(Y,1,2))
    T=T.reshape((2,)+(4,)*8).transpose((0,1,5,2,6,3,7,4,8)).reshape(2,16,16,16,16)
    assert prod(T.shape[1:])<=200000
    rss()
    rawpair[side][e]=T.copy()
    support=[int(np.count_nonzero(np.any(T,axis=0)))]
    for i in record['axis_order']:
        step=B[i]
        nz=np.any(T,axis=0)
        rows0=np.count_nonzero(np.moveaxis(nz,i,0).reshape(16,-1),axis=1)
        degrees=np.count_nonzero(np.any(step,axis=0),axis=1)
        n+=int(np.dot(rows0,degrees))
        bound*=16*split_bound(step)
        assert bound<2**63
        F=lambda a,b:np.moveaxis(np.tensordot(a,b,axes=(i,0)),-1,i)
        T=np.stack((F(T[0],step[0])-F(T[1],step[1]),F(T[0],step[1])+F(T[1],step[0])))
        support.append(int(np.count_nonzero(np.any(T,axis=0))))
        assert prod(T.shape[1:])<=200000
    assert n<=record['prospective']
    for r,*ix in selected[side]:
        if r==e:
            val=tuple(int(t) for t in T[(slice(None),*ix)])
            if any(val):out[side][e,*ix]=val
    receipts.append(dict(record,actual_work=n,nonzero_rows_by_stage=support))
assert receipts==result['per_ray_chunks']
assert max(r['actual_work'] for r in receipts)==219296
assert max(r['prospective'] for r in receipts)==800768
assert max(max(r['nonzero_rows_by_stage']) for r in receipts)==9216
stored=[{},{}]
for side,k,z in rows(A/'selected-transforms.jsonl'):stored[side=='right'][tuple(k)]=tuple(z)
assert out==stored and list(map(len,out))==[3072,3072]
print('all 32 partition plans, signed exact transforms and support/operation receipts match; dense independent prospect',dense_budget,flush=True)

# Stream the exact middle products under the same measured partition cap.
# Clear middle denominators by two each, then cancel the resulting 16
# exactly per ray. Do not materialize all middle products.
mid2={n:{j:[(i,k,tuple(int(2*v) for v in z)) for (i,k),z in t.items()] for j,t in b.items()} for n,b in middles.items()}
assert all((2*v).denominator==1 for m in middles.values() for t in m.values() for z in t.values() for v in z)
seen=[set(),set()]
amp={}
work=0
nz=0
last=0
begin=0
chunks=[]
for p,k in enumerate(M):
    a,b,c,d,e,f0=k
    raw_list=[mid2[n][j] for n,j in zip('ABCD',k,strict=False)]
    predicted=prod(map(len,raw_list))
    if work-last+predicted>4_000_000:
        chunks.append(dict(begin=begin,end_exclusive=p,prospective=work-last,actual=work-last))
        last=work;begin=p
    coeff=(0,0)
    for ((i0,j0,z0),(i1,j1,z1),(i2,j2,z2),(i3,j3,z3)) in product(*raw_list):
        L=(e,i0,i1,i2,i3); R=(f0,j0,j1,j2,j3)
        seen[0].add(L);seen[1].add(R)
        work+=1
        assert work-last<=4_000_000
        x=out[0].get(L);y=out[1].get(R)
        if x is None or y is None:continue
        v=mul(mul(x,y),mul(mul(z0,z1),mul(z2,z3)))
        assert any(v)
        nz+=1
        coeff=add(coeff,v)
        assert all(abs(v)<2**127 for v in coeff)
    assert all(v%16==0 for v in coeff)
    if any(coeff):amp[k]=tuple(v//16 for v in coeff)
chunks.append(dict(begin=begin,end_exclusive=len(M),prospective=work-last,actual=work-last))
assert chunks==result['middle_chunks'] and work==5308416 and nz==962560
assert seen==selected
assert amp=={tuple(k):tuple(z) for k,z in rows(A/'q-amplitudes-0101.jsonl')} and len(amp)==4096
assert pre+sum(r['actual_work'] for r in receipts)+work==result['total_work']==12336146
print('all 5,308,416 middle products and partition boundaries match; 962,560 nonzero paths and 4096 exact amplitudes',flush=True)
g=gcd(*M.values())
assert g==result['mask_numerator_gcd']
N=tuple(sum((M[k]//g)*amp[k][i] for k in M) for i in (0,1))
assert N==tuple(result['normalized_interior_scalar_numerator'])
H=json.loads((C/'graph.json').read_text())
assert H['exact_denominator_before_exponential_divisor']==result['graph_denominator']
assert (H['scalar_numerator_multiplier'],H['external_exponential_divisor'])==(24**5,512)
scale=Q(g*24**5,H['exact_denominator_before_exponential_divisor']*512)
final=tuple(v*scale for v in N)
assert list(map(str,final))==result['weighted_exact_sector_value']
print('independent exact C0101',*map(str,final),flush=True)

print('independent dense and middle prospective/measured guards held; peak process RSS',rss(),flush=True)
