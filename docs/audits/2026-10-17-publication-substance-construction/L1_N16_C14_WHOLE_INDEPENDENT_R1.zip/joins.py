from collections import Counter,defaultdict
from functools import cache
from itertools import product
from math import gcd,prod
from pathlib import Path
import json,sys,resource

def rss():
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    assert n<384*1024**2
    return n

A=Path(sys.argv[1])
def path(n):
    known={'core':'core-sewing-r1.P8b5DO','star':'edge-site-r1.nyn1YR','two':'rank-zero-r1.gte6BM',
           'sew':'shared-trace-r1.9tcmVn','r3':'rank3-r1.q1WfND','res':'residual-edge-r1.klcKMh'}
    return Path('/tmp/publication-c14-'+known[n])
def rows(f):
    with f.open() as s:
        for line in s:yield json.loads(line)
def load(f):return json.loads(f.read_text())
def f(x):return tuple(map(f,x)) if isinstance(x,(tuple,list)) else x
def plus(z,w):return z[0]+w[0],z[1]+w[1]
def mult(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def zz(x):return tuple(x) if isinstance(x,list) else (x,0)
graph=load(path('core')/'graph.json')
src={
 'rank8_edge0':('star','edge-0.jsonl'),'rank8_edge1':('star','edge-1.jsonl'),
 'rank0_edge1':('two','zero-edge-1.jsonl'),'rank0_edge2':('two','zero-edge-2.jsonl'),'rank0_edge3':('two','zero-edge-3.jsonl'),
 'trace0':('two','plane-01-trace.jsonl'),'trace1':('two','plane-01-trace.jsonl'),
 'trace2':('sew','trace-slices.jsonl'),'trace3':('sew','trace-slices.jsonl'),
 'partition_rank8':('star','site-factors.jsonl'),'partition_rank0':('two','zero-site-factors.jsonl'),
 'residual_edge':('res','residual-edge.jsonl'),'rank3_edge2':('r3','rank3-axis2.jsonl'),'rank3_edge3':('r3','rank3-axis3.jsonl'),
 'rank3_projection':('r3','rank3-projection.jsonl'),'merge_rank1':('r3','merge-rank1.jsonl'),'merge_rank2':('r3','merge-rank2.jsonl')}
def loadfactor(name,labels):
    if name in src:
        p,n=src[name]
        rr=((k,zz(z)) for k,z,*rest in rows(path(p)/n))
    else:
        rr=(([ *k,j],zz(z)) for j,t in rows(path('core')/graph['quotient_ray_files'][name]) for k,z in t)
    axes=tuple(sorted(labels))
    pos=[labels.index(k) for k in axes]
    out={}
    for k,z in rr:
        if any(v//4 != int(n[-1] in '13') for n,v in zip(labels,k,strict=True) if n[0]=='q'):continue
        key=tuple(k[i]%4 if labels[i][0]=='q' else k[i] for i in pos)
        assert key not in out
        out[key]=z
    return axes,out
factors={n:loadfactor(n,labels) for n,labels in graph['factor_keys'].items() if n not in ('conditional_tile','mask_bridge','coalesced_environment')}
rep=load(A/'result-0101-stop11.json')
assert {k:len(t) for k,(_,t) in factors.items()}==rep['input_sizes']

# Reconstruct two original Boolean constraints independently.
s8={tuple(k[:2]) for k,_,_ in rows(path('star')/'site-factors.jsonl')}
s0={k[0] for k,_ in rows(path('two')/'zero-site-factors.jsonl')}
edge0=defaultdict(set);edge1=defaultdict(set)
bridge=set()
for (m,n,a,b,u,v),z in rows(path('star')/'edge-0.jsonl'):
    edge0[m].add((u,v))
    if n in s0 and m in {j[0] for j in s8}:bridge.add((m,n))
for (m,n,a,b,u,v),z in rows(path('star')/'edge-1.jsonl'):edge1[m].add((u,v))
trace={tuple(k[:2]) for k,z in rows(path('sew')/'trace-slices.jsonl')}
tile={(m,n,*p,*q) for m,n in s8 for p,q in product(edge0[m],edge1[n]) if all((a,b) in trace for a,b in zip(p,q))}
assert bridge=={tuple(k[:2]) for k in rows(path('two')/'compatible-mask-bridge.jsonl')} and len(bridge)==100
assert tile=={tuple(k) for k in rows(path('sew')/'conditional-tiles.jsonl')} and len(tile)==36608

join_work=0
def join(A,B):
    global join_work
    la,a=A;lb,b=B
    shared=sorted(set(la)&set(lb))
    outer=tuple(sorted(set(la)^set(lb)))
    ai,bi=([L.index(k) for k in shared] for L in (la,lb))
    index=defaultdict(list)
    for r,z in b.items():index[tuple(r[j] for j in bi)].append((r,z))
    op=[(0,la.index(k)) if k in la else (1,lb.index(k)) for k in outer]
    prospect=sum(len(index.get(tuple(k[j] for j in ai),())) for k in a)
    assert join_work+prospect<=4_000_000
    out=defaultdict(lambda:(0,0))
    visit=0
    for k,z in a.items():
        for r,w in index.get(tuple(k[j] for j in ai),()):
            visit+=1
            key=tuple((k,r)[j][i] for j,i in op)
            assert key in out or len(out)<200000
            out[key]=plus(out[key],mult(z,w))
            assert all(abs(x)<2**127 for x in out[key])
    assert visit==prospect
    join_work+=visit
    rss()
    nonzero={k:z for k,z in out.items() if any(z)}
    return (outer,nonzero),visit,len(out)-len(nonzero)
for e in rep['exact_completed_joins']:
    l,r=e['left'],e['right']
    u,v=factors.pop(l),factors.pop(r)
    out,n,zero=join(u,v)
    assert (n,len(out[1]),zero)==(e['visits'],e['nonzero_rows'],e['cancelled_rows'])
    factors[f'({l}+{r})']=out
assert len(rep['exact_completed_joins'])==11
for name,labels,raw in rows(A/'frontier-0101-stop11.jsonl'):
    axes,tab=factors[name]
    perm=[labels.index(k) for k in axes]
    assert tab=={tuple(key[i] for i in perm):zz(z) for key,z in raw}
print('all eleven exact source-bound joins, full frozen frontier and both original Boolean implications verified',flush=True)

desc={'A':'(rank0_edge1+rank4_closure)','B':'(rank8_edge0+(rank8_edge3+(rank8_edge2+partition_rank8)))',
'C':'(rank0_edge2+merge_rank2)','D':'(rank0_edge3+merge_rank1)',
'E':'(rank3_edge3+(rank3_edge2+(rank3_compact+rank3_projection)))','F':'(residual_edge+(rank8_edge1+rank12_closure))'}
IR={n:(tuple(l),v) for n,l,v in rows(A/'interior-rays.jsonl')}
M={n:(tuple(l),v) for n,l,v in rows(A/'mask-weights.jsonl')}
masks={}
for n,name in desc.items():
    labels,t=factors[name]
    il,raw=IR[n]
    ml,mv=M[n]
    order=[(0,il.index(k)) if k in il else (1,ml.index(k)) for k in labels]
    r={i:{tuple(k):tuple(z) for k,z in rr} for i,rr in raw}
    assert len(r)==16
    for vals in r.values():
        nonz=[x for k in sorted(vals) for x in vals[k] if x]
        assert nonz[0]>0 and gcd(*nonz)==1
    reconstruct={}
    for mask,(ray,w) in mv:
        for k,z in r[ray].items():
            key=tuple((k,mask)[j][i] for j,i in order)
            assert key not in reconstruct
            reconstruct[key]=tuple(w*x for x in z)
    assert reconstruct==t
    masks[n]=(ml,[(tuple(k),r,w) for k,(r,w) in mv])
for n in ('trace0','trace1','trace2','trace3'):
    l,raw=IR[n]
    a,t=factors[n]
    p=[l.index(k) for k in a]
    assert t=={tuple(k[i] for i in p):tuple(z) for k,z in raw}
print('all 96 primitive interior rays reconstruct complete exterior slices with exact signed weights',flush=True)

# Project each half by directly matching all named internal masks. Cache
# raw mask pairs, not preprojected signed four-bit unions.
def index(n,boundary):
    lab,table=masks[n]
    out=defaultdict(list)
    for k,r,w in table:
        d=dict(zip(lab,k,strict=True))
        out[tuple(d[j] for j in boundary)].append((d,r,w))
    return out
IX={n:index(n,ls) for n,ls in {'A':('ray_rank4',),'B':('ray_rank10','ray_rank9'),'C':('remote2',),
 'D':('remote1',),'E':('ray_rank3',),'F':('ray_rank12',)}.items()}
def parity(ms):
    word=[i for m in ms for i in range(8) if m>>i&1]
    assert len(word)==len(set(word))
    return (-1)**sum(a>b for j,a in enumerate(word) for b in word[j+1:])
def partials(k,key):
    if k==0:
        a,b,c,d=key
        X,Z=defaultdict(list),defaultdict(list)
        for x,i,w in IX['A'][a,]:X[x['new_mask4']].append((x['m01'],i,w))
        for y,j,w in IX['B'][c,d]:Z[y['m81']].append((y['m00'],j,w))
        for h,s,w in IX['F'][b,]:
            for (n,i,x),(m,j,y) in product(X[h['new_mask4']],Z[h['m81']]):
                if not m&n:yield m,n,i,j,s,x*y*w
    else:
        a,b,c=key
        X,Z=defaultdict(list),defaultdict(list)
        for x,i,w in IX['C'][c,]:X[x['new_mask2']].append((x['m02'],i,w))
        for y,j,w in IX['D'][b,]:Z[y['new_mask1']].append((y['m03'],j,w))
        for h,s,w in IX['E'][a,]:
            for (m,i,x),(n,j,y) in product(X[h['new_mask2']],Z[h['new_mask1']]):
                if not m&n:yield m,n,i,j,s,x*y*w
frozen=[{},{}]
reverse=[{},{}]
for k,i,r in rows(A/'coalesced-mask-half-rays.jsonl'):
    frozen[k][i]={tuple(t):w for t,w in r}
    reverse[k][tuple((tuple(t),w) for t,w in r)]=i
assert list(map(len,frozen))==[25,1024]
@cache
def half(k,key):
    tab=defaultdict(int)
    for m,n,a,b,c,w in partials(k,key):
        tab[m|n,a,b,c]+=w*parity((m,n))
    return {k:z for k,z in tab.items() if z}
@cache
def ray(k,key):
    table=half(k,key)
    if not table:return None
    g=gcd(*table.values())
    if table[min(table)]<0:g=-g
    s=tuple((i,w//g) for i,w in sorted(table.items()))
    return reverse[k][s],g
env=list(rows(path('core')/'coalesced-environment.jsonl'))
grouped=defaultdict(int)
direct=n=0
@cache
def counts(k,i):
    return Counter(p[0] for p in frozen[k][i])
def size(i,j):
    L,R=counts(0,i),counts(1,j)
    return sum(x*R[255^m] for m,x in L.items())
for (a,b,c,d,e,p,q),w in env:
    l=ray(0,(a,b,d,e));r=ray(1,(c,p,q))
    if l is None or r is None:continue
    i,x=l;j,y=r
    n+=1
    direct+=size(i,j)
    grouped[i,j]+=w*x*y
grouped={k:w for k,w in grouped.items() if w}
assert n==39648 and direct==43024384 and len(grouped)==2980
assert grouped=={tuple(k):w for k,w in rows(A/'coalesced-mask-half-pairs.jsonl')}
assert sum(size(i,j) for i,j in grouped)==3293184<4_000_000
print('all normalized signed half response rays and coalesced environment pair weights verified; 43,024,384 direct vs 3,293,184 admitted',flush=True)
R={}
for i,tab in frozen[1].items():
    G=defaultdict(list)
    for (m,a,b,c),w in tab.items():G[m].append((a,b,c,w))
    R[i]=G
total=defaultdict(int)
work=0
for (i,j),w in grouped.items():
    for (m,a,b,f0),x in frozen[0][i].items():
        v=w*x*parity((m,255^m))
        for c,d,e,z in R[j][255^m]:
            work+=1
            assert work<=4_000_000
            if work%8192==0:rss()
            total[a,b,c,d,e,f0]+=v*z
            assert len(total)<=200000 and abs(total[a,b,c,d,e,f0])<2**127
assert work==3293184 and len(total)==9216
weighted={k:w for k,w in total.items() if w}
assert weighted=={tuple(k):w for k,w in rows(A/'weighted-mask-amplitude-0101.jsonl')} and len(weighted)==4096
for ctl in load(A/'mask-admission.json')['fixed_controls']:
    a,b,d,e,f0,p,q=ctl['boundary']
    tab=defaultdict(int)
    for (m,n,i,j,r,x),(u,v,k,l,s,y) in product(partials(0,(a,b,e,f0)),partials(1,(d,p,q))):
        if (m|n)&(u|v):continue
        tab[i,j,k,l,s,r]+=parity((m,n,u,v))*x*y
    tab={k:v for k,v in tab.items() if v}
    assert len(tab)==ctl['complete_nonzero_interior_ray_rows']
    assert tab[tuple(ctl['selected_ray_key'])]==ctl['mask_numerator']==-ctl['wrong_top_orientation_numerator']
@cache
def sub(which,key,rays):
    return {m:z for (m,*rest),z in half(which,key).items() if tuple(rest)==rays}
mask_work=0
for ctl in load(A/'mask-check.json')['controls']:
    i,j,k,l,s,r=ctl['key']
    result=0
    count=0
    values=set()
    for (a,b,c,d,e,p,q),w in env:
        mask_work+=1
        L=sub(0,(a,b,d,e),(i,j,r));R=sub(1,(c,p,q),(k,l,s))
        for m,x in L.items():
            mask_work+=1
            assert mask_work<=4_000_000
            y=R.get(255^m,0)
            if not(x and y):continue
            v=w*x*y*parity((m,255^m))
            count+=1
            result+=v
            values.add(v)
    assert result==ctl['exact_numerator']==weighted[i,j,k,l,s,r]
    assert count==ctl['direct_nonzero_products']
    assert (result-ctl['adverse_one_product'])//2 in values
assert mask_work==712600+236160
print('all 4096 signed mask weights, 5120 cancellations and eight literal/direct adverse controls verified',flush=True)

print('independent charged join and mask products',join_work,work,'peak process RSS',rss(),flush=True)
