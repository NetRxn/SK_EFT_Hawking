from csv import DictReader
from fractions import Fraction
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

pins = (
    ('author-results.zip', 'SHA256SUMS', 'd645ced175f53c45a39f24229c8129948b0ff07ac33b548caf99acb7d7bf88df'),
    ('review-1189.zip', 'review-manifest.portable.sha256', '6d969c7f09e9fc82638bd8e2c62305eff7d3243177e177a1fdbe4bce82abfc10'),
    ('review-1600.zip', 'review.sha256', '93522cf871b7ec59b82c2fa8a9b8df2aa73d7d374f3b8578c384230868654eaa'),
)

def archive(path, manifest, expected):
    contents = Path(path).read_bytes()
    assert sha256(contents).hexdigest() == expected
    packed = ZipFile(BytesIO(contents))
    assert packed.testzip() is None
    for line in packed.read(manifest).decode().splitlines():
        digest, name = line.split(maxsplit=1)
        assert sha256(packed.read(name)).hexdigest() == digest, name
    print(path, 'ZIP and member digests verified')
    return packed

def table(packed, name):
    return list(DictReader(packed.read(name).decode().splitlines(), delimiter='\t'))

author, low, upper = (archive(*pin) for pin in pins)
authored = {}
for line in author.read('AUTHOR_SUMMARY.txt').decode().splitlines():
    if line.startswith('Group '):
        group = int(line.split()[1].rstrip(':'))
        authored[group] = []
    elif line[:1].isdigit():
        idx, real, imag, den, *_ = line.split('\t')
        assert int(idx) == len(authored[group])
        authored[group].append((int(real), int(imag), int(den)))

weighted = []
for group, reviewed, member, denominator in (
    (1189, low, 'scalar.tsv', 'denominator'),
    (1600, upper, 'scalars.tsv', 'factor_denominator'),
):
    rows = table(reviewed, member)
    assert [int(row['ordinal']) for row in rows] == list(range(8))
    evidence = [(int(row['raw_real']), int(row['raw_imag']), int(row[denominator])) for row in rows]
    assert evidence == authored[group]
    exact = sum(Fraction(real, den) for real, _, den in evidence)
    assert all(imag == 0 for _, imag, _ in evidence)
    pair = exact * 2 * 48 / (16 * 4**64)
    weighted.append(pair)
    print(group, 'eight matching original signed scalars, weighted pair', pair)

assert weighted[0] == Fraction(table(low, 'retally.tsv')[0]['paired_weighted_real'])
upper_pair, = [row for row in table(upper, 'composition.tsv')
               if row['scope'] == 'pair_contribution_after_single_external_profile_weight']
assert weighted[1] == Fraction(upper_pair['exact_real'])
previous = -Fraction(220382679257727784386626225332146933, 87112285931760246646623899502532662132736)
print('previous 14-group weighted subtotal', previous)
print('new 18-group weighted subtotal', previous + sum(weighted))
