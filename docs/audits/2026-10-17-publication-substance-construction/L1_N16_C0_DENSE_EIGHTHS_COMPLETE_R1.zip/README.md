# Original L1 dense profile eighths pilots

The two independent reviews verify every original ordinal of Groups 1189 and 1600. The committed paired pilot identifies the source preparation and prior independent ordinal 0 evidence. The existing exact global chirality maps each eight-ordinal fiber to its partner, 2322 and 2273 respectively. All four original groups enter the partial sum with the same occupation weight convention.

The author and reviewers used exact Gaussian arithmetic, retaining fixed source orientation and normalization. Group 1189's additional triangle was checked at an independent third pivot. Group 1600's guard refusal and capture-only retry were independently reproduced under the original budgets.

Run `python3 -B verify.py` in this directory to verify the nested archives and each original scalar, and rebuild the before/after partial subtotal. The review archives carry their own signed replay instructions and operand hashes. The timing totals are sums of measured author components. They include the separate triangles and the recorded 1600 refusal, and exclude independent replay and unmeasured overhead. The numerical profile and original physical publication obligations remain open.
