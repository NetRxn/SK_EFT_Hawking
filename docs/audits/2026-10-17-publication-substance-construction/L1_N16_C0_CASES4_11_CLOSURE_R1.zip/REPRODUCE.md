# L1 N16 dense group 128 outer cases 4 through 11

The results are for the first binary child of tuple 0 in descendant (0,0), scientific source 51e7c745e and publication parent 73e9a015d. Each outer cut has a separate identity and exact replay. Coincident totals cannot substitute for an independent verification.

Verify and extract the parent as in `L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip`. The decompressed eight-factor parent `row-cap-physical-slice-dense-label-tuple0-0-reduced.pkl` has SHA256 5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867. Deserialize only trusted checkpoint inputs.

Copy the author Python files and the checkpoint directory to fresh scratch and run:

```bash
python3 -u run-batch.py /absolute/path/to/decompressed-parent.pkl 4 5 6 7 8 9 10 11 >batch.tsv
shasum -a 256 -c /absolute/path/to/archive/reconstructed-frontiers.sha256
```

Both 4 and 5 need three reduction and contraction cycles to close. Cases 6 through 11 need two cycles. The existing exact projection and quotient rules preserve each scalar. Author logs retain every row or join guard refusal and the original cap. The independent reports specify separate arithmetic orders, checks and the saved-lineage acceptance boundaries. This package covers these eight outer terms. The full tuple, full signed coefficient, physical susceptibility and publication gates remain open.

Run `python3 aggregate.py` in the extracted archive to check all eight decimals-free sums against the independent receipts. The frozen 8–11 reviewer manifest describes `pinned.zip`, which refers to the byte-identical upstream `L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip` (Git blob `02e33786d0bcd46e2314ad7fec1453595adcc815`). Use that file under the reviewer name when replaying its full manifest. The upstream file is stored once in the repository.

The next six open cases are 13, 14, 15, 17, 18 and 19. Reuse the author batch command with those indices to reconstruct their seven-factor prejoin frontiers. The terminal logs and expected frontiers are recorded under `next-frontiers`. Further exact partitions and independent closure are required for all six.
