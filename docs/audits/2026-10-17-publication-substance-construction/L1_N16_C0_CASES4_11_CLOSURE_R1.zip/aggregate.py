from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

root = Path(__file__).resolve().parent
author = root / 'author'
rows = {}
for line in (author/'batch.tsv').read_text().splitlines():
    index, state, result = line.split('\t')
    assert state == 'exact'
    assert int(index) not in rows
    rows[int(index)] = result
assert set(rows) == set(range(4,12))

def scalar(log):
    match = re.search(r'^exact normalized real (\S+) imaginary (\S+)',log,re.M)
    assert match
    return tuple(map(Fraction,match.groups()))

real = imaginary = Fraction(0)
for case in range(4,12):
    axes, roster = literal_eval((author/f'case-{case}.roster').read_text())
    ordered = sorted(roster,key=lambda entry:(entry[1],entry[0]))
    assert len(ordered)==48 and len(dict(ordered))==48
    coordinate, matches = ordered[case]
    assert (author/f'case-{case}-plan.out').read_text().splitlines()[-1].startswith(
        f'pilot {coordinate!r} matched {matches} stored rows ')
    base = root/('independent-4-7' if case<=7 else 'independent-8-11')
    log = base/(f'replay-{case}-{2 if case<=5 else 1}.out' if case<=7 else f'case-{case}-replay.out')
    result = scalar(log.read_text())
    assert result == scalar(rows[case])
    real += result[0]
    imaginary += result[1]
    print(case,coordinate,result[0],result[1],sep='\t')
print('subtotal',real,imaginary,sep='\t')
