# Independent verification of L1 N16 outer cases 4–7

The review pins publication candidate c43f3eac6 and the archived parent from
L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip. The archive SHA256 is
06772d72f61bcb361130dede255d0e84ba98735e62671c5d635029cfe5df7d63.
All archive manifest entries verified. The decompressed parent SHA256 is
5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867
and it is byte-identical to the frozen verified parent. The archive roster
SHA256 is 185ad83d0dc0b6dcaa311b65cbbc6fc8542a0b31120e8fc4fbf59d0e238b1c4c.

An independent histogram match over the rejected pair regenerated the full
48-case roster, with 6,427,904 total products and 70,896–212,688 products
per case. Each selected case has 70,896 products and order is by product
count followed by cut coordinate. Independently adding back the cut axes
G(0,4,2) and J(1,4,2) recovered every compatible row and exact coefficient
in every parent factor. Conditioning, representation-label partition,
degree-two axes and the positive factor denominator product were checked
for every reduced or cap-saved input.

The normalized real values share denominator
5192296858534827628530496329220096. All imaginary values are zero.

| Case | Cut coordinates | Exact real numerator | Final factors and rows | Independent matched products |
|---|---|---:|---:|---:|
| 4 | (65, (3,)) | 10046146121220966055407 | 4 and 84,654 | 3,698,504 |
| 5 | (72, (3,)) | 11479417446010490751717 | 4 and 84,654 | 3,698,504 |
| 6 | (130, (3,)) | 1763518048972234363017 | 5 and 74,030 | 6,945,952 |
| 7 | (132, (3,)) | 3196789373761759059327 | 5 and 74,030 | 6,945,952 |

The direct sparse Gaussian integer contraction independently chooses its
pair schedule, imports no author functions and uses no quotients. Cases
4–5 use a different join ordering from the author with largest join
2,119,440 products and peak output 102,128 rows. Cases 6–7 perform
the unquotiented joins with largest join 4,938,288 products and peak
output 118,976 rows. It applies the factor denominator
40512224221827380280140849737629696 and the external factor 1/(16*4^64)
exactly once. The replay logs retain the unreduced numerators.

The clean-scratch lineage runs use copies of the archived author scripts.
The batch executables were byte-identical to those scripts. They reproduce
the cut, complete roster, logs, reduced checkpoints and cap-saved inputs
byte for byte. This verifies author transformation lineage. The direct
sparse contraction independently verifies each final scalar. For cases 4–5
the row-cap and join-cap refusals occur at stages 0 and 1, respectively,
before stage 2 completes. For cases 6–7 the join-cap refusal occurs at stage
0 before stage 1 completes.

The scope is four separately conditioned cases of the first binary child
of tuple 0 in branch 128. The complete child, tuple, branch, profile and
c0 require further contributions.
