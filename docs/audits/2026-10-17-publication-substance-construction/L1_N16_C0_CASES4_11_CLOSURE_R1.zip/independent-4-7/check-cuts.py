from ast import literal_eval
from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import sys

source = Path('parent.pkl')
author = Path('/private/tmp/l1-open-roster-batch.wYFt0J')
roster = Path('archive/pilot.roster')
def load(path):
    return pickle.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

assert digest(source) == '5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867'
assert digest(roster) == '185ad83d0dc0b6dcaa311b65cbbc6fc8542a0b31120e8fc4fbf59d0e238b1c4c'
axes, entries = literal_eval(roster.read_text())
assert len(entries) == len(dict(entries)) == 48
parent = load(source)
factors = parent['factors']
assert set(Counter(axis for scope, _, _ in factors for axis in scope).values()) == {2}
i, j = parent['rejected_pair']
left, right = factors[i], factors[j]
shared = sorted(set(left[0]) & set(right[0]))
left_by_key = Counter()
right_by_key = Counter()
for scope, rows, _ in [left, right]:
    offsets = [scope.index(axis) for axis in shared]
    coordinate_offsets = [scope.index(axis) for axis in axes] if scope == left[0] else []
    for row in rows:
        key = tuple(row[p] for p in offsets)
        if scope == left[0]:
            coordinate = tuple(row[p] for p in coordinate_offsets)
            left_by_key[key, coordinate] += 1
        else:
            right_by_key[key] += 1
spectrum = Counter()
for (key, coordinate), multiplicity in left_by_key.items():
    products = multiplicity * right_by_key[key]
    if products:
        spectrum[coordinate] += products
assert spectrum == dict(entries)
sorted_cases = sorted(spectrum, key=lambda c: (spectrum[c], c))
assert sum(spectrum.values()) == 6427904
print('full roster', len(spectrum), 'sum/min/max',sum(spectrum.values()),min(spectrum.values()),max(spectrum.values()),'rejected pair', (i,j),'axes',axes)
for case, terminal in (map(int, x.split(':')) for x in sys.argv[1:]):
    coord = sorted_cases[case]
    fixed = dict(zip(axes, coord))
    stem = f'case-{case}'
    assert digest(author/f'{stem}.roster') == digest(roster)
    child_path = author/f'{stem}.pkl'
    child = load(child_path)
    assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
    assert child['label_partition'] == parent['label_partition']
    for (scope, rows, denominator), (restricted_scope, restricted_rows, restricted_denominator) in zip(factors, child['factors'], strict=True):
        assert denominator == restricted_denominator
        assert tuple(a for a in scope if a not in fixed) == restricted_scope
        expected = {row: value for row, value in rows.items()
                    if all(row[p] == fixed[a] for p, a in enumerate(scope) if a in fixed)}
        actual = {}
        for row, value in restricted_rows.items():
            expanded = dict(zip(restricted_scope, row))
            expanded.update(fixed)
            actual[tuple(expanded[a] for a in scope)] = value
        assert actual == expected
    print('verified exact inverse lift',case,coord,spectrum[coord],digest(child_path),sum(len(rows) for _,rows,_ in child['factors']))
    for phase in range(terminal+1):
        tag = f'{stem}-{phase}'
        reduced = author/f'label-{tag}-reduced-frontier.pkl'
        files = [reduced]
        refusals = [p for p in (author/f'row-cap-physical-slice-dense-label-{tag}-reduced.pkl',
                               author/f'join-cap-dense-label-{tag}-reduced.pkl') if p.is_file()]
        assert len(refusals) == int(phase != terminal)
        files.extend(refusals)
        for path in files:
            f = load(path)
            assert f['conditioning'] == child['conditioning']
            assert f['label_partition'] == child['label_partition']
            ff = f['factors']
            assert prod(d for _,_,d in ff) == 40512224221827380280140849737629696
            assert all(len(set(a))==len(a) and d>0 and all(len(k)==len(a) and any(v) and all(type(z) is int for z in v) for k,v in table.items()) for a,table,d in ff)
            assert set(Counter(w for a,_,_ in ff for w in a).values()) == {2}
            print('verified stage',path.name,digest(path),len(ff),sum(len(rows) for _,rows,_ in ff))
print('PASS roster, exact selected inverse lifts, and stage metadata and denominator')
