#!/usr/bin/env bash
set -euo pipefail
root=/private/tmp/l1-outer45-independent.M53W1i
author=/private/tmp/l1-open-roster-batch.wYFt0J
case=$1
terminal=$2
stem=case-$case
scratch="$root/lineage-$case"
mkdir "$scratch"
cp -R "$root/archive/checkpoint" "$scratch/"
cp "$root/archive/"{exact-multicut,reduce-label-frontier,contract-reduced-label}.py "$scratch/"
cd "$scratch"
input="$stem.pkl"
python3 -u exact-multicut.py "$root/parent.pkl" "$input" "$case" > "$stem-plan.out"
for name in "$input" "$stem.roster" "$stem-plan.out"; do
    cmp "$name" "$author/$name"
done
printf 'exact-multicut reproduced the initial cut, roster and planning log byte for byte\n'
for ((stage=0; stage<=terminal; stage++)); do
    tag="$stem-$stage"
    python3 -u reduce-label-frontier.py "$input" "$tag" > "$tag-reduce.out"
    cmp "label-$tag-reduced-frontier.pkl" "$author/label-$tag-reduced-frontier.pkl"
    ret=0
    python3 -u contract-reduced-label.py "$tag" > "$tag-contract.out" || ret=$?
    cmp "$tag-reduce.out" "$author/$tag-reduce.out"
    cmp "$tag-contract.out" "$author/$tag-contract.out"
    if (( stage == terminal )); then
        test "$ret" = 0
        tail -1 "$tag-contract.out"
    else
        test "$ret" = 2
        count=0
        for name in "row-cap-physical-slice-dense-label-$tag-reduced.pkl" "join-cap-dense-label-$tag-reduced.pkl"; do
            if test -f "$name"; then
                cmp "$name" "$author/$name"
                input="$name"
                count=$((count+1))
            fi
        done
        test "$count" = 1
        tail -1 "$tag-contract.out"
    fi
    printf 'stage %s byte-identical reduction, contraction log, and any saved frontier\n' "$stage"
done
