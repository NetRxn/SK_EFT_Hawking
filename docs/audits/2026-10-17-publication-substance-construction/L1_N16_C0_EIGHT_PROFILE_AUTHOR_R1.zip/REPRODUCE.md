# L1 eight-profile exact author batch

Run `python3 verify_author.py` to recompute the eight signed totals from the
terminal case logs and full four-assignment rosters. Reconstruct the roster
from the anchor plan and sparse state rows together. Each exchanged pair
contributes twice and each chirality-fixed assignment contributes once.

The first driver stopped at a fixed assignment. The second driver handled
fixed assignments represented in sparse state rows but omitted the all-scalar
assignment in two profiles. `complete-scalar.sh` evaluates those two
assignments, whose receipts and factor hashes are included. The earlier
incomplete totals are retained in batch-before-scalar.out for diagnosis.
Large raw factor tables remain in the local calculation tree.

All eight complete author coefficients await independent review.
