#!/bin/zsh
set -e
n=$PWD
for key in 139627958850-8960527077529 164324020825-8935831015554; do
    w="$n/$key-tiled"
    s="$w/scalar-fixed"
    mkdir "$s"
    cd "$s"
    cp "$w"/{site_split.py,compact-boundary.py,quotient_worklist.py} .
    for f in root.tsv rays edge-plan.out edge-batch temporal.tsv spatial.tsv; do ln -s "$w/$f" "$f"; done
    touch states.tsv
    awk '$1==0' "$n/candidate-support/$key/anchor-plan.tsv" > anchor-plan.tsv
    python3 - <<'PY'
from pathlib import Path
p=Path('site_split.py')
s=p.read_text()
key='    shapes[case,t,x,k]=tuple(value)'
assert s.count(key)==1
p.write_text(s.replace(key,key+'\n    states.setdefault(case,{})'))
PY
    export L1_PROFILE_CODES="${key/-/,}"
    python3 site_split.py . > site.out
    python3 quotient_worklist.py . . 0 > case-000.out
    tail -1 case-000.out
    cd "$n"
done
