from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import csv

def states(path,anchor):
    out=defaultdict(set,{int(line.split()[0]):set() for line in anchor.read_text().splitlines()})
    for line in path.read_text().splitlines():
        i,*row=map(int,line.split())
        out[i].add(tuple(row))
    return {i:frozenset(rows) for i,rows in out.items()}

def exchange(st):
    return frozenset((t,x,k,r,l) for t,x,k,l,r in st)

def results(path):
    out={}
    for line in path.read_text().splitlines():
        if line.startswith('COMPLETE AUTHOR PROFILE '):
            a,b,w,value=line.split()[3:]
            key=(int(a),int(b),int(w))
            assert key not in out
            out[key]=Fraction(value)
    return out

expected=results(Path('batch.out'))|results(Path('batch-fixed.out'))
profiles=[tuple(map(int,line.split())) for line in Path('next-cases.out').read_text().splitlines()]
assert len(profiles)==len(expected)==8
assert set(profiles)==set(expected)
with Path('author-exact.tsv').open('w') as out:
    writer=csv.writer(out,delimiter='\t',lineterminator='\n')
    writer.writerow(('left','right','weight','value','weighted'))
    for a,b,w in profiles:
        base=Path(f'{a}-{b}')
        all_states=states(base/'all-states.tsv',base/'all-anchor-plan.tsv')
        selected=states(base/'states.tsv',base/'anchor-plan.tsv')
        index={st:i for i,st in all_states.items()}
        assert len(all_states)==len(index)==4
        pairs={i:index[exchange(st)] for i,st in all_states.items()}
        assert set(selected)=={i for i,j in pairs.items() if i<=j}
        total=Fraction()
        for i,st in selected.items():
            assert st==all_states[i]
            final=(base/f'case-{i:03}.out').read_text().splitlines()[-1].split()
            if final[:2]==['EXACT','ZERO']:
                value=Fraction()
            else:
                assert final[:3]==['EXACT','channel',str(i)] and Fraction(final[4])==0
                value=Fraction(final[3])
            total+=(1 if pairs[i]==i else 2)*value
        assert total==expected[a,b,w]
        writer.writerow((a,b,w,total,w*total))
print('validated author roster, exchange multiplicity, and signed sums for',len(profiles),'profiles')
