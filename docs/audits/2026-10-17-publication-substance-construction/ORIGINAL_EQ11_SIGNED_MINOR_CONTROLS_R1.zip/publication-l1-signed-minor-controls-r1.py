from collections import Counter
from fractions import Fraction as F
from itertools import combinations, product
import json

from src.vestigial import original_coefficients as py

ZERO = (F(0), F(0))
ONE = (F(1), F(0))

def add(a, b):
    return a[0] + b[0], a[1] + b[1]

def mul(a, b):
    return a[0]*b[0] - a[1]*b[1], a[0]*b[1] + a[1]*b[0]

def scale(c, a):
    return c*a[0], c*a[1]

def wedge(left, right):
    result = {}
    for u, a in left.items():
        for v, b in right.items():
            if set(u) & set(v):
                continue
            inversions = sum(i > j for i in u for j in v)
            key = tuple(sorted(u + v))
            result[key] = add(result.get(key, ZERO), scale((-1)**inversions, mul(a,b)))
    return {k:v for k,v in result.items() if v != ZERO}

def original_top_from_rows(matrix, bars, psis):
    n = len(matrix)
    state = {tuple(bars) + tuple(n+j for j in psis):ONE}
    for i,row in enumerate(matrix):
        factors = {():ONE}
        factors.update({(i,n+j):v for j,v in enumerate(row) if v != ZERO})
        state = wedge(state, factors)
    # Berezin orientation is fixed by the diagonal pairs in the original
    # determinant theorem. Their reordering to global all-bar/all-psi
    # orientation has one crossing for every ordered pair of row indices.
    orientation = (-1)**sum(i < j for i in range(n) for j in range(n))
    return scale(orientation,state.get(tuple(range(2*n)),ZERO))

def matrices(n):
    dense = tuple(tuple((F((i+2*j)%5-2, i+j+1), F((2*i+j)%3-1,j+2))
                        for j in range(n)) for i in range(n))
    yield "dense", dense
    yield "rank-deficient", tuple(dense[0] for _ in range(n)) if n else dense
    yield "zero", tuple((ZERO,)*n for _ in range(n))
    yield "off-diagonal", tuple(tuple(ONE if j==(i+1)%n else ZERO
                                     for j in range(n)) for i in range(n))

cases = Counter()
for n in range(5):
    for kind,matrix in matrices(n):
        sparse = py.SparseMatrix(n, tuple(((i,j),py.QComplex(*value))
              for i,row in enumerate(matrix) for j,value in enumerate(row) if value!=ZERO))
        for k in range(n+1):
            for bars,psis in product(combinations(range(n), k),repeat=2):
                expected = original_top_from_rows(matrix,bars,psis)
                actual = py.complementary_insertion(sparse,bars,psis)
                assert actual == py.Polynomial.scalar(py.QComplex(*expected)), (n,kind,bars,psis)
                cases[k] += 1
for bars, psis in (((0,0),(0,1)), ((1,0),(0,1)), ((0,),(0,1)), ((4,),(0,))):
    try:
        py.complementary_insertion(py.SparseMatrix(4,()),bars,psis)
    except ValueError:
        pass
    else:
        raise AssertionError((bars,psis))
print(json.dumps({"cases_by_inserted_pairs":dict(sorted(cases.items())),
    "total":sum(cases.values()),"adverse_rejections":4,
    "oracle":"Independent exact rational-complex ordered exterior row products",
    "scope":"All equal-cardinality subsets for four matrix families at dimensions 0 through 4"},indent=2))
