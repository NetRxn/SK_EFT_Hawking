"""Audit independently reproduced preparations without assigning scalars to survivors."""
from ast import literal_eval
from csv import DictReader
from hashlib import file_digest
from pathlib import Path
from decimal import Decimal
from math import prod
from pickle import load
import json
import re

GROUPS=(1225,1255,1261,1278,1284,1296,1302)
SOURCE_BASE=Path('/private/tmp/l1-geometry-component98-preparation.iOKjDp')
ZERO_TRACE=Path('/private/tmp/l1-group1225-zero-witness.SKBLE4')

def sha(path):
    with path.open('rb') as f: return file_digest(f,'sha256').hexdigest()

def read(path):
    with path.open('rb') as f:return load(f)

def records(path):
    with Path(path).open() as f:return list(DictReader(f,delimiter='\t'))

def write(path,head,rows):
    with Path(path).open('w') as f:
        print(*head.split(),sep='\t',file=f)
        for row in rows:
            print(*row,sep='\t',file=f)

def main():
    comp,=[r for r in records('source-receipts/components.tsv') if r['id']=='98']
    assert comp['kind']=='K8,8' and int(comp['whole_pair_weight'])==192
    assert set(literal_eval(comp['selected_side']))=={1231,*GROUPS}
    assert len(literal_eval(comp['other_side']))==8
    prior,=records('source-receipts/accepted-1231-retally.tsv')
    assert prior['group']=='1231' and prior['component']=='98'
    assert len(Path('compiled-local-blocks-verify.log').read_text().splitlines())==88
    all_input=json.loads(Path('original-inputs.json').read_text())
    whole=[]
    totals=[]
    verdicts=[]
    for group in GROUPS:
        d=Path(f'group-{group}')
        a=Path('/private/tmp/l1-geometry-group1225.FBDsax') if group==1225 else SOURCE_BASE/str(group)
        assert (a/'compiled').resolve()==(SOURCE_BASE/'1255/compiled').resolve()
        info=json.loads((d/'result.json').read_text())
        assert info['group']==group and info['source_rows']==all_input[str(group)]['presweep_rows']
        frozen=a/'dense-saturated-frontier.pkl'
        assert sha(frozen)==info['prepared_sha256']==(d/'frontier.sha256').read_text().split()[0]
        assert (d/'preparation.out').read_bytes()==(a/'preparation.out').read_bytes()
        assert len((d/'preparer-verify.out').read_text().splitlines())==6
        axes,original=literal_eval((d/'original-roster.txt').read_text())
        assert len(axes)==12 and len(original)==len(set(original))==8
        restricted=records(d/'ordinal-roster.tsv')
        tuples=[literal_eval(r['original_joint_L_tuple']) for r in restricted]
        assert tuples==list(original)
        assert list(map(lambda r:int(r['original_ordinal']),restricted))==list(range(8))
        state=read(frozen)
        factors=state['factors']
        assert state['branch']==group and state['support']==8
        assert prod(den for _,_,den in factors)==info['denominator']==all_input[str(group)]['denominator']
        assert len(factors)==88 and sum(len(r) for _,r,_ in factors)==info['prepared_rows']
        vacant=info['global_empty_factors']
        first=info['first_empty']
        if vacant:
            whole.append(group)
            assert info['remaining_ordinals']==[] and info['proved_zero_ordinals']==list(range(8))
            assert first is not None
            if group==1225:
                assert first==[0,'M16','E141',992,2144,248,0,24,9360760]
                assert sha(ZERO_TRACE/'dense-saturated-frontier.pkl')==info['prepared_sha256']
        else:
            assert first is None
        for row in restricted:
            i=int(row['original_ordinal'])
            empty=literal_eval(row['empty_prepared_factors'])
            assert bool(empty)==(i in info['proved_zero_ordinals'])
            assert bool(empty)==(row['disposition']=='exact_zero')
            verdicts.append((group,i,row['original_joint_L_tuple'],row['source_selected_rows_before_sweeps'],
                             row['prepared_selected_rows'],row['largest_prepared_factor'],repr(empty),
                             row['disposition'],'0' if empty else '','0' if empty else '',info['denominator']))
        author_time=Decimal(re.search(r'(?m)^real ([\d.]+)',(d/'preparation.time').read_text())[1])
        totals.append((group,info['source_rows'],info['prepared_rows'],info['denominator'],info['prepared_sha256'],
                       len(vacant),repr(vacant),repr(first),repr(info['remaining_ordinals']),repr(info['proved_zero_ordinals']),
                       len(info['remaining_ordinals']),len(info['proved_zero_ordinals']),info['independent_seconds'],
                       author_time,'whole_group_zero' if vacant else 'prepared_source_only'))
    write('group-preparation.tsv','group source_rows prepared_rows denominator prepared_sha256 global_empty_count global_empty_factors first_empty remaining_original_ordinals zero_original_ordinals surviving_count zero_count independent_seconds author_seconds scope',totals)
    write('component-ordinal-roster.tsv','group original_ordinal original_labels presweep_rows prepared_rows largest_prepared_factor empty_prepared_factors disposition raw_real raw_imag denominator',verdicts)
    print('matched seven actual signed prepared tables; whole-group zeros',whole)
    print('original ordinals proved zero',sum(r[11] for r in totals),'remaining signed ordinals',sum(r[10] for r in totals))

if __name__=='__main__':
    main()
