#!/bin/bash
set -eu
for n in 1225 1255 1261 1278 1284 1296 1302; do
    d="group-$n"
    if [ "$n" = 1225 ]; then source='/private/tmp/l1-geometry-group1225.FBDsax'; else source="/private/tmp/l1-geometry-component98-preparation.iOKjDp/$n"; fi
    until [ -s "$source/frontier.sha256" ] && [ -s "$source/preparation.time" ]; do sleep 5; done
    cp "$source"/{preparation.out,preparation.time,frontier.sha256} "$d/"
    (cd "$source" && shasum -a 256 -c "$OLDPWD/source-receipts/preparer-inputs.sha256") > "$d/preparer-verify.out"
    /usr/bin/time -p python3 -B -u reduce.py "$n" > "$d/replay.out" 2> "$d/replay.time"
    tail -1 "$d/replay.out"
done
