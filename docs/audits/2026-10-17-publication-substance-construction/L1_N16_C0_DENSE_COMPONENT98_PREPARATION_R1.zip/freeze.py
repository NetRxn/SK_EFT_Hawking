"""Generate the portable preparation and zero-proof manifest."""
from hashlib import file_digest
from pathlib import Path

names=('REVIEW.md','continuity.json','continuity-packet.json','source-archives.tsv','original-inputs.json',
       'originals.py','originals.out','originals.time','reduce.py','replay-serial.sh','audit.py','audit.out',
       'group-preparation.tsv','component-ordinal-roster.tsv','freeze.py','compiled-local-blocks-verify.log',
       'chiral-verify.log','chiral-peer-verify.log','compiled-verify.log','geometry-verify.log',
       'geo-actual-verify.log','geo-candidate-verify.log','accepted-1231-verify.log')
files=[*(Path(n) for n in names),*Path('source-receipts').glob('*')]
files.extend(p for d in Path('.').glob('group-*') if d.is_dir() for p in d.glob('*') if p.is_file())
with Path('review-manifest.portable.sha256').open('w') as manifest:
    for source in sorted(files):
        with source.open('rb') as entry:
            checksum=file_digest(entry,'sha256').hexdigest()
        print(checksum,source,sep='  ',file=manifest)
