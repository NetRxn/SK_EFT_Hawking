"""Replay the original signed block loader and boundary-preserving quotient."""
from ast import literal_eval as lit
from collections import Counter, defaultdict
from hashlib import file_digest
from itertools import combinations
from math import gcd, lcm, prod
from pathlib import Path
from pickle import load
from time import monotonic
import json
import sys

GROUP=int(sys.argv[1])
OUT=Path(f'group-{GROUP}')
META=json.loads(Path('original-inputs.json').read_text())[str(GROUP)]
AUTHOR=(Path('/private/tmp/l1-geometry-group1225.FBDsax') if GROUP==1225 else
        Path('/private/tmp/l1-geometry-component98-preparation.iOKjDp')/str(GROUP))

def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()

def read_lines(name):
    return [row.split('\t') for row in (AUTHOR/name).read_text().splitlines()]

def select_rows():
    plan=read_lines('cut-plan.tsv')
    _,n,rows,size,cut_key,ids=plan[GROUP]
    assert tuple(map(int,plan[GROUP][:4]))==(GROUP,8,META['presweep_rows'],META['encoded_bytes'])
    axes=lit((AUTHOR/'cut-axes.tsv').read_text())
    key, chosen=lit(cut_key),lit(ids)
    assert (axes,key,chosen)==lit((OUT/'selected-blocks.txt').read_text())
    cut=dict(zip(axes,key,strict=True))
    schema={name:(lit(labels),lit(physical)) for name,labels,physical,*_ in read_lines('schema.tsv')}
    blocks=read_lines('block-index.tsv')
    by_family=defaultdict(list)
    for i in lit(ids):
        name,key,offset,bytes_,nrows,den=blocks[i]
        key=lit(key)
        labels,_=schema[name]
        assert all(cut[w]==v for w,v in zip(labels,key,strict=True) if w in cut)
        by_family[name].append((key,*map(int,(offset,bytes_,nrows,den))))
    factors=[]
    names=sorted(schema)
    assert len(names)==len(by_family)==88
    for name in names:
        labels,physical=schema[name]
        live=tuple(w for w in labels if w not in cut)
        project=projection(labels,live)
        family=by_family[name]
        total=lcm(*(d for *_,d in family))
        coeffs={}
        with (AUTHOR/f'compiled/{name}.blocks').open('rb') as stream:
            for key,start,bytes_,nrows,den in family:
                stream.seek(start)
                read_key,scope,read_den,table=load(stream)
                assert (read_key,read_den,len(table),stream.tell())==(key,den,nrows,start+bytes_)
                cols=tuple(scope.index(w) if w in scope else -1 for w in physical)
                multiplier=total//den
                prefix=project(key)
                for row,(a,b) in table.items():
                    projected=prefix+tuple(row[c] if c>=0 else 0 for c in cols)
                    assert projected not in coeffs and any((a,b))
                    coeffs[projected]=(a*multiplier,b*multiplier)
        factors.append((live+physical,coeffs,total))
    assert sum(len(r) for _,r,_ in factors)==int(rows)
    return names,factors

def projection(a,b):
    ix=tuple(a.index(k) for k in b)
    return lambda row: tuple(row[i] for i in ix)

def mul(x,y):
    return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]

def quotient(f,g,degree):
    a,F,dx=f
    b,G,dy=g
    edge=tuple(w for w in a if w in b)
    physical=tuple(w for w in edge if w[0]!='L' and degree[w]==2)
    if not physical:
        return f,g,0
    boundary=tuple(w for w in edge if w not in physical)
    assert all(w[0]!='L' and degree[w]==2 for w in physical)
    assert {w for w in edge if w[0]=='L'} <= set(boundary)
    u=tuple(w for w in a if w not in edge)
    v=tuple(w for w in b if w not in edge)
    shared_f,shared_g=projection(a,edge),projection(b,edge)
    boundary_key=projection(edge,boundary)
    free_f,free_g=projection(a,u),projection(b,v)
    active=set(map(shared_g,G))
    fibers=defaultdict(dict)
    for key,value in F.items():
        group=shared_f(key)
        if group in active:
            fibers[group][free_f(key)]=value
    classes=defaultdict(list)
    for key,table in fibers.items():
        coords=tuple(sorted(table))
        scale=gcd(*(n for pair in table.values() for n in pair))
        assert scale>0
        reduced=[tuple(n//scale for n in table[l]) for l in coords]
        unit=max(((1,0),(0,1),(-1,0),(0,-1)),key=lambda z:mul(reduced[0],z))
        primitive=tuple(mul(z,unit) for z in reduced)
        factor=scale*unit[0],-scale*unit[1]
        classes[(boundary_key(key),coords,primitive)].append((key,factor))
    if len(classes)==len(fibers)==len(active):
        return f,g,0
    left={}
    lookup={}
    for (same,coords,coeffs),members in classes.items():
        rep=min(key for key,_ in members)
        assert boundary_key(rep)==same
        left.update((rep+pos,z) for pos,z in zip(coords,coeffs,strict=True))
        for key,factor in members:
            assert boundary_key(key)==same
            assert all(fibers[key][k]==mul(z,factor) for k,z in zip(coords,coeffs,strict=True))
            lookup[key]=rep,factor
    right=defaultdict(lambda:[0,0])
    for key,z in G.items():
        mapped=lookup.get(shared_g(key))
        if mapped is not None:
            rep,scale=mapped
            x,y=mul(scale,z)
            row=right[rep+free_g(key)]
            row[0]+=x
            row[1]+=y
    # L labels remain in their original columns up to a reordering of axes.
    left_axes,right_axes=edge+u,edge+v
    assert set(left_axes)==set(a) and set(right_axes)==set(b)
    return (left_axes,left,dx),(right_axes,{k:tuple(z) for k,z in right.items() if any(z)},dy),len(fibers)-len(classes)

def tally(f,assignment):
    axes,rows,_=f
    fixed=tuple((i,assignment[w]) for i,w in enumerate(axes) if w in assignment)
    return sum(all(row[i]==v for i,v in fixed) for row in rows)

def run():
    start=monotonic()
    frontier=AUTHOR/'dense-saturated-frontier.pkl'
    digest=sha(frontier)
    assert digest==(AUTHOR/'frontier.sha256').read_text().split()[0]
    open_axes,roster=lit((OUT/'original-roster.txt').read_text())
    assignments=[dict(zip(open_axes,r,strict=True)) for r in roster]
    names,factors=select_rows()
    degree=Counter(w for a,_,_ in factors for w in a)
    assert {w for w in degree if w[0]=='L'}==set(open_axes)
    assert sum(w[0]!='L' for w in degree)==424 and all(degree[w]==2 for w in degree if w[0]!='L')
    denom=prod(d for _,_,d in factors)
    assert denom==META['denominator']
    before_local=[[tally(f,assignment) for f in factors] for assignment in assignments]
    assert all(n>0 for row in before_local for n in row)
    pairs=[(i,j) for i,j in combinations(range(len(factors)),2)
           if any(w[0]!='L' and w in factors[j][0] for w in factors[i][0])]
    print('loaded signed factors',len(factors),'rows',sum(len(r) for _,r,_ in factors),'denominator',denom,'pairs',len(pairs),flush=True)
    visits=0
    first_empty=None
    certified_sweeps=[]
    author=(AUTHOR/'preparation.out').read_text().splitlines()
    for sweep in range(2):
        removed=0
        before=sum(len(r) for _,r,_ in factors)
        for i,j in pairs:
            for a,b in ((i,j),(j,i)):
                left,right=factors[a],factors[b]
                visits+=len(left[1])+len(right[1])
                assert visits<=60_000_000
                x,y,c=quotient(left,right,degree)
                if first_empty is None and (not x[1] or not y[1]):
                    assert left[1] and right[1]
                    first_empty=(sweep,names[a],names[b],len(left[1]),len(right[1]),len(x[1]),len(y[1]),c,visits)
                    print('first globally empty factor',*first_empty,flush=True)
                removed+=c
                factors[a],factors[b]=x,y
        after=sum(len(r) for _,r,_ in factors)
        actual=f'sweep {sweep} rows {before} to {after} coalesced {removed} visits {visits}'
        print(actual,flush=True)
        assert actual==author[2+sweep]
        certified_sweeps.append((sweep,before,after,removed,visits))
        if any(not r for _,r,_ in factors):
            assert author[3+sweep]==f'exact zero by empty factor {GROUP}'
            break
    with frontier.open('rb') as f:
        target=load(f)
    assert (target['branch'],target['support'],target['used_before'])==(GROUP,8,0)
    assert factors==target['factors'] and prod(d for _,_,d in factors)==denom
    assert Counter(w for a,_,_ in factors for w in a)==degree
    global_empty=[name for name,(_,r,_) in zip(names,factors,strict=True) if not r]
    assert bool(global_empty)==(first_empty is not None)
    verdicts=[]
    with (OUT/'ordinal-roster.tsv').open('w') as f, (OUT/'original-labels.tsv').open('w') as ids:
        print('original_ordinal','original_joint_L_tuple','source_selected_rows_before_sweeps','prepared_selected_rows','largest_prepared_factor','empty_prepared_factors','disposition',sep='\t',file=f)
        for i,(key,assignment) in enumerate(zip(roster,assignments,strict=True)):
            local=[tally(q,assignment) for q in factors]
            empty=[name for name,n in zip(names,local,strict=True) if not n]
            assert set(global_empty)<=set(empty)
            verdicts.append((i,key,sum(before_local[i]),sum(local),max(local),empty))
            print(i,repr(key),sum(before_local[i]),sum(local),max(local),repr(empty),'exact_zero' if empty else 'needs_signed_terminal',sep='\t',file=f)
            print(i,repr(key),bool(empty),sep='\t',file=ids)
    alive=[i for i,_,_,_,_,e in verdicts if not e]
    zero=[i for i,_,_,_,_,e in verdicts if e]
    assert sorted(alive+zero)==list(range(8))
    with (OUT/'prepared-roster.tsv').open('w') as f:
        print('axes',repr(open_axes),sep='\t',file=f)
        for i,key,_,n,m,e in verdicts:
            if not e:
                print(i,repr(key),n,m,sep='\t',file=f)
    if global_empty:
        assert not alive and zero==list(range(8))
    result=dict(group=GROUP,prepared_sha256=digest,source_rows=META['presweep_rows'],prepared_rows=sum(len(r) for _,r,_ in factors),
                denominator=denom,global_empty_factors=global_empty,first_empty=first_empty,remaining_ordinals=alive,
                proved_zero_ordinals=zero,quotient_sweeps=certified_sweeps,
                independent_seconds=round(monotonic()-start,6))
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('independent preparation verified',json.dumps(result),flush=True)

if __name__=='__main__':
    run()
