"""Literal original coframe labels and one-coordinate chirality check."""
from itertools import product
from collections import Counter
import json,sys
sys.path.insert(0,'/tmp/publication-n16-denominator-support-r1.VjgwoR')
from preflight import REG,LINKS
from src.core.formulas import original_coframe_blocks
x=REG.sites[0]
records=Counter()
for mu,a in product(range(4),repeat=2):
    y=REG.step(x,mu)[0]
    for b in original_coframe_blocks(REG,(x,mu,a),LINKS):
        assert {b.bar_site,b.psi_site}=={x,y} and b.anchor in ((x,mu),(y,mu))
        for i,row in enumerate(b.matrix):
            for j,p in enumerate(row):
                for k,z in p.terms:
                    assert len(k)==1
                    q=k[0]
                    assert q.index[:2]==b.anchor
                    assert (i<2)!=(j<2)
                    remote=i if b.bar_site==y else j
                    assert q.index[2]==('L' if remote<2 else 'R')
                    records['raw_nonzero_coordinate_terms']+=1
        records['literal_quarter_increments']+=1
assert records['literal_quarter_increments']==64
print(json.dumps(dict(records,periodic_translation_preserves=True),indent=2))
