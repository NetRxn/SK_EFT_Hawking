"""Independent exact symbolic raw grouping and literal restricted c0 source check."""
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import combinations,product
import json,sys
sys.path.insert(0,'/tmp/publication-n16-denominator-support-r1.VjgwoR')
from preflight import REG,LINKS,RANK
from src.core.formulas import original_action_factors, original_coframe_blocks, original_plaquette
from src.vestigial.original_coefficients import Polynomial,QComplex,matrix_dagger,matrix_multiply

ROOT=REG.sites[0]
AX=range(4)
ZERO=QComplex()

def parity(word):
    return (-1)**sum(a>b for i,a in enumerate(word) for b in word[i+1:])

def trace(a,b):
    return sum((a[i][j]*b[j][i] for i in AX for j in AX),Polynomial())

def word_anchors(k,l):
    return ((ROOT,k),(REG.step(ROOT,k)[0],l),(REG.step(ROOT,l)[0],k),(ROOT,l))

raw=original_action_factors(REG,ROOT,LINKS)
assert Counter(f.t_degree for f in raw)=={2:384,4:24}
by=defaultdict(Polynomial)
counts=Counter()
for f in raw:
    if f.t_degree!=2:continue
    (_,u,a),(_,v,b)=sorted(f.components)
    by[u,v,a,b]+=f.coefficient
    counts[u,v,a,b]+=1
assert set(counts.values())=={4}
G={(a,b):matrix_multiply(matrix_multiply(REG.gamma[a],REG.gamma[b]),REG.gamma5)
   for a,b in product(AX,repeat=2)}
checked={}
for k,l in combinations(AX,2):
    u,v=sorted(set(AX)-{k,l})
    w=original_plaquette(REG,ROOT,k,l,LINKS)
    inv=original_plaquette(REG,ROOT,l,k,LINKS)
    assert inv==matrix_dagger(w)
    total=0
    for a,b in product(AX,repeat=2):
        t=trace(w,G[a,b])
        j=trace(inv,G[a,b])
        reduced=(t-j)*Fraction(parity((k,l,u,v)),2)
        assert by[u,v,a,b]==reduced
        if a==b:
            assert not reduced
        else:
            assert j==-t and reduced and reduced==-by[u,v,b,a]
        for key,z in reduced.terms:
            assert len(key)==4 and {s.index[:2] for s in key}==set(word_anchors(k,l))
            assert len({s.index[2] for s in key})==1
        total+=bool(reduced)
    checked[str((k,l))]=total
assert all(v==12 for v in checked.values())

r0,r1=REG.step(ROOT,0)[0],REG.step(ROOT,1)[0]
kept=[x for x in REG.generator_order if
      (x[0]==ROOT and x[1]=='bar') or (x[0]==r0 and x[1]=='psi' and x[2]<2) or
      (x[0]==r1 and x[1]=='psi' and x[2]>=2)]
assert len(kept)==8
pos={x:i for i,x in enumerate(kept)}
centers=[]
for x in REG.sites:
    axes=[]
    for mu in AX:
        y=REG.step(x,mu)[0]
        if any({a[0],b[0]}=={x,y} and a[1]=='bar' and b[1]=='psi' and (a[2]<2)!=(b[2]<2)
               for a,b in product(kept,repeat=2)):
            axes.append(mu)
    if len(axes)>=2:centers.append((x,axes))
assert centers==[(ROOT,[0,1])]

def frame(mu,a):
    out=[]
    for block in original_coframe_blocks(REG,(ROOT,mu,a),LINKS):
        for i,row in enumerate(block.matrix):
            for j,p in enumerate(row):
                pair=(block.bar_site,'bar',i),(block.psi_site,'psi',j)
                if all(k in pos for k in pair):
                    for k,z in p.terms:
                        assert len(k)==1
                        out.append((tuple(pos[t] for t in pair),k[0],z*block.weight))
    return out

def frame_pair(mu,a,b):
    t=defaultdict(QComplex)
    for (i,q,z),(j,w,v) in product(frame(mu,a),frame(mu,b)):
        if q!=w or len(set(i+j))!=4:continue
        sign=parity(i+j)
        k=tuple(sorted(i+j))
        t[k]=t[k]+z*v*Fraction(sign,4)
    return {k:v for k,v in t.items() if v}

pairs={(mu,a,b):frame_pair(mu,a,b) for mu,a,b in product((0,1),AX,AX)}
def curvature_pair(p,q):
    other=dict(q.terms)
    return sum((z*other[k]*Fraction(1,256) for k,z in p.terms if k in other),QComplex())

answer=QComplex()
for a,b,c,d in product(AX,repeat=4):
    for (i,z),(j,w) in product(pairs[0,a,c].items(),pairs[1,b,d].items()):
        if len(set(i+j))!=8:continue
        g=curvature_pair(by[0,1,a,b],by[0,1,c,d])
        answer+=z*w*g*Fraction(parity(i+j),2)
assert answer==QComplex(Fraction(3,4))
adverse=-answer
frobenius=sum((curvature_pair(p,p) for (u,v,a,b),p in by.items() if (u,v)==(0,1)),QComplex())
assert frobenius==QComplex(24)
result=dict(raw_S2_source_terms=384,periodic_center_plane_summands=16*len(checked),
            nonzero_grouped_components=checked,restricted_top=answer.storage,
            reversed_restricted_top=adverse.storage,curvature_trace_second_moment=frobenius.storage,
            contributing_center=[list(ROOT),[0,1]],kept=kept)
print(json.dumps(result,indent=2))
