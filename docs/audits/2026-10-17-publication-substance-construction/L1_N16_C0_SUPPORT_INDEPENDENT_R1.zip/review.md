# Independent original N16 pure-EHC support review

The reviewed object is the original periodic closed source_C at clean
primary 27012c18fa374e8341e124b510abbedeedb18d29. The author manifest
and governing continuity packet verify. The author package is
/tmp/l1-n16-c0-support.ob9Wnd6j. All reviewer changes are scratch-only.

## Signed source and restricted positive control

I independently grouped all 384 raw original ordered S2 factors at
the periodic root. For each of the six curvature planes I compared
the full symbolic coefficient to the direct signed trace of the
closed source word minus its inverse, including the factor 1/2 and
the world epsilon. The inverse word is exactly the conjugate
transpose at the same four distinct directed anchors. The diagonal
difference vanishes. The twelve off-diagonal components agree
with the forward trace times epsilon and are antisymmetric in
the internal component labels. All nonzero curvature monomials
have one coordinate at each of the four original anchors and all
four have the same chirality. Periodic site translation preserves
the source constructor, its signed increments and exact anchors.
This gives the 96 labeled center/plane summands and their ordered
exponential factorials. It does not identify reciprocal anchors.

I checked all 64 raw root coframe increments and 1,024 raw nonzero
coordinate terms. Each term contains a bar and a psi at opposite
endpoints with opposite spin chiralities. The coordinate's original
anchor is one of the two directed anchors of that edge, and its
chirality is the chirality of the remote spinor. These checks
reproduce the proposed incidence rule, including for reverse
bar/psi orientation. Their periodic translations have the same
local sign and chirality rules.

I independently evaluated the eight-generator restriction by
taking literal ordered raw quarter-increment words. The eligible
center and coframe axes are unique. I integrated a coframe pair
only when its actual anchor/chirality/coordinate labels matched,
and a curvature pair only when all four complete coordinate labels
matched. The respective pair moments are 1/4 and 1/256. I
accumulated all raw signed coefficients without conjugating one
factor. The curvature second moment is exactly 24 and the
restricted source top of S2 squared divided by two is exactly
3/4. Reversing the restricted top orientation gives -3/4.
This is a positive restricted source calculation. It is not
a sign or nonvanishing statement for the full original c0.

## Parity and arithmetic

I reproduce both concrete falsifiers. The first preserves the
32-occurrence degree-eight coframe profile but violates eight
undirected face-boundary equations. The second preserves that
profile and all undirected parity equations but has two distinct
odd anchors and no coframe occurrences at eight axis-3 edges.
The condition d >= a+b and d = a+b mod 2 is exactly the existence
condition for an allocation of coframe incidences between the two
anchors at that coarse degree level. It is necessary for the
original monomials. Actual source component, anchor, chirality
and coordinate compatibility still need to be imposed.

The four orientation/chirality incidence profiles are necessary.
Viewed only as a decomposition of an eight-regular bipartite
edge multigraph, they supply no additional pruning. Such a
multigraph decomposes into eight perfect matchings, which can
be grouped into four degree-two profiles. Their substantive
filtering requires coupling to center occupancy, actual anchor
choices, chiral parity and generator labels. The edge parity
matrix on the 96 occurrence parities has GF(2) rank 31; its
vertex-boundary image has rank 14. Thus there are 17 additional
linear parity conditions after the vertex parity equations.
This offers a bounded linear prefilter, not coefficient evaluation.

The accepted source norm gives |c0| <= 2^800. The common
Gaussian integer scale 2^224 times 192! times 32! has 1,527 bits.
Each term has 64 coframe quarters and 192 q coordinates.
For surviving terms, the sum of the half-degrees is 96, and
the sum of active half-degree-plus-one indices is at most
192. The product of their factorials therefore divides 192!.
The occupation factorial product divides 32!. This verifies
the scale and a strict 2^2327 bound on the absolute scaled
numerator. Complete exact modular output with a sufficiently
large modulus would certify zero. Any nonzero modular residue
at a good prime would certify nonvanishing, provided the
complete original coefficient was contracted. Neither
contraction is supplied by this package.

## Counts, refusal, and viable next preflight

A separate C++ implementation enumerates all 384 group elements
without relying on signed-cycle conjugacy classes. It reproduces
degree-two, degree-four and degree-eight profile counts
24,962, 20,126,899 and 109,621,610,869. The corresponding orbit
counts are 161, 59,404 and 287,954,372. The degree-eight identity
state peak is 2,200,689. The independent run completes with
622,554,013 charged visits across the three degrees and group
sweeps. The time utility was denied its system clock-rate
query after execution, so its detailed RSS line is unavailable.
I separately rebuilt and replayed the author's programs. Its
degree-eight identity run repeats 440,316,030 attempts and
41,332,390 admitted updates. The replay reports 139,739,136
bytes peak RSS and the Burnside replay reports 6,340,608 bytes.
The author's orbit-first 10M representative cap must refuse,
as must the proposed four-profile Cartesian expansion of
388,255,409,514,885,136 tuples. Those are schedule-specific
estimates, not lower bounds on a different contraction.

An independent coarse support pilot verifies the actual closure
dependencies. A coframe edge degree has two possible center
owners, a vertex saturation condition has five, a directed
curvature-anchor parity has four, and the combined two-anchor
edge predicate has eight. The pilot uses a deterministic
constraint-frontier order, the actual 210 local exponent vectors,
full partial coframe edge counts, partial site counts and all
64 original directed curvature parities. It retains 208
distinct projected states after center 0 and 10,312 after
center 1. The next center prospectively refuses its 120,001st
state, after 435,566 visits. No vertex or edge was yet at
last use. This is a coarse support pilot and carries no signed
exterior coefficients, chirality choices or individual q exponents.

The next exact preflight should exploit complete local vertex
constraints sooner. A bounded route is to condition a vertex
star on its saturation before extending the separator, combine
the 17 remaining linear edge parity constraints with exact
directed parity and remaining capacity, and merge only equivalent
frontier keys. The current center order already refuses before
last-use tests can act. Any chirality/coordinate or exact
signed extension needs fresh actual state and work admission.
Retain individual physical anchors throughout. No profile or
unmeasured signed DP should be admitted at whole-c0 scale.

**Frozen verdict.** Accept the signed source reduction, necessary
parity and orientation conditions with the stated coupling
qualification, both falsifiers, the exact restricted 3/4
control, arithmetic scale, and measured envelope/refusal
claims. The complete original 128-generator, full-Haar c0
value, sign and nonvanishing remain unresolved. The complete
denominator and normalization remain open.
