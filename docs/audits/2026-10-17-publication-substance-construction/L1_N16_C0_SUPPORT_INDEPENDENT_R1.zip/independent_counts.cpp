#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include <utility>
#include <vector>
using N=std::uint64_t;
using Edge=std::pair<int,int>;
using Perm=std::array<int,4>;
constexpr std::size_t state_cap=3'000'000;
std::size_t peak=0;
N visits=0;
constexpr N visit_cap=2'000'000'000;
void charge(){ if(++visits>visit_cap) std::abort(); }

N identity_count(int degree) {
    std::vector<int> sources, sinks;
    for(int v=15;v>=0;--v)
        (__builtin_popcount(v)%2 ? sources:sinks).push_back(v);
    std::array<int,16> ix{};
    for(int i=0;i<8;++i) ix[sinks[i]]=i;
    std::array<std::array<int,4>,8> neigh{};
    std::array<int,8> last{};
    for(int i=0;i<8;++i) for(int a=0;a<4;++a) {
        neigh[i][a]=ix[sources[i]^(1<<a)]; last[neigh[i][a]]=i;
    }
    std::array<N,8> pow{};
    pow[0]=1;
    for(int i=1;i<8;++i) pow[i]=pow[i-1]*N(degree+1);
    N start=0;
    for(int i=0;i<8;++i) start+=degree*pow[i];
    std::unordered_map<N,N> state{{start,1}};
    for(int i=0;i<8;++i) {
        std::unordered_map<N,N> next;
        for(auto [k,weight]:state) {
            std::array<int,4> lo{},hi{};
            for(int j=0;j<4;++j) {
                int v=neigh[i][j];
                hi[j]=(k/pow[v])%(degree+1);
                if(last[v]==i) lo[j]=hi[j];
            }
            for(int a=lo[0];a<=hi[0];++a)
            for(int b=lo[1];b<=hi[1];++b)
            for(int c=lo[2];c<=hi[2];++c) {
                charge();
                int d=degree-a-b-c;
                if(d<lo[3]||d>hi[3]) continue;
                N dest=k-a*pow[neigh[i][0]]-b*pow[neigh[i][1]]-
                         c*pow[neigh[i][2]]-d*pow[neigh[i][3]];
                if(!next.count(dest)&&next.size()==state_cap) std::abort();
                next[dest]+=weight;
            }
        }
        peak=std::max(peak,next.size());
        state.swap(next);
    }
    return state.at(0);
}

std::vector<Edge> make_edges(){
    std::vector<Edge> edges;
    for(int v=0;v<16;++v)for(int a=0;a<4;++a)if(!(v&(1<<a)))edges.emplace_back(v,v^(1<<a));
    return edges;
}
int image(int x,const Perm&p,int t){
    int y=0;
    for(int i=0;i<4;++i)y|=((x>>i)&1)<<p[i];
    return y^t;
}
N fixed_count(const std::vector<Edge>& edges,const Perm&p,int t,int r){
    std::array<int,32> map{};
    for(int i=0;i<32;++i){
        auto [a,b]=edges[i];
        a=image(a,p,t);b=image(b,p,t);if(a>b)std::swap(a,b);
        auto j=std::find(edges.begin(),edges.end(),Edge{a,b});
        if(j==edges.end())std::abort();
        map[i]=int(j-edges.begin());
    }
    using Profile=std::array<int,16>;
    std::vector<Profile> profiles;
    std::array<bool,32> seen{};
    for(int i=31;i>=0;--i)if(!seen[i]){
        Profile x{};
        for(int j=i;!seen[j];j=map[j]){
            seen[j]=true;
            ++x[edges[j].first];++x[edges[j].second];
        }
        profiles.push_back(x);
    }
    std::array<int,16> last{};
    for(int i=0;i<int(profiles.size());++i)
        for(int v=0;v<16;++v)if(profiles[i][v])last[v]=i;
    std::array<N,16> powers{};
    powers[0]=1;
    for(int v=1;v<16;++v)powers[v]=powers[v-1]*N(r+1);
    N start=0;
    for(auto u:powers)start+=r*u;
    std::unordered_map<N,N> layer{{start,1}};
    for(int i=0;i<int(profiles.size());++i){
        const auto& profile=profiles[i];
        std::vector<int> touch;
        N stride=0;
        for(int v=0;v<16;++v)if(profile[v]){
            touch.push_back(v);stride+=powers[v]*profile[v];
        }
        std::unordered_map<N,N> nx;
        for(auto [key,w]:layer){
            int high=r,low=0;
            for(int v:touch){
                int left=(key/powers[v])%(r+1);
                int mult=profile[v];
                high=std::min(high,left/mult);
                if(last[v]==i){
                    if(left%mult)high=-1;
                    low=std::max(low,left/mult);
                }
            }
            for(int z=low;z<=high;++z){
                charge();
                N dest=key-N(z)*stride;
                if(!nx.count(dest)&&nx.size()==state_cap)std::abort();
                nx[dest]+=w;
            }
        }
        peak=std::max(peak,nx.size());
        layer.swap(nx);
    }
    return layer.count(0)?layer.at(0):0;
}
int main(){
    const auto edges=make_edges();
    for(int r:{2,4,8}){
        auto id=identity_count(r);
        N sum=id;int n=1;
        Perm p{0,1,2,3};
        do for(int t=0;t<16;++t){
            if(p==Perm{0,1,2,3}&&t==0)continue;
            sum+=fixed_count(edges,p,t,r);++n;
        } while(std::next_permutation(p.begin(),p.end()));
        if(n!=384||sum%384)std::abort();
        std::cout<<r<<' '<<id<<' '<<sum/384<<' '<<n<<' '<<peak<<' '<<visits<<std::endl;
    }
}
