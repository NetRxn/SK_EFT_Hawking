"""Independent parity falsifiers and concrete joint support-frontier pilot."""
from collections import Counter,defaultdict
from itertools import combinations,product
from math import factorial
import json,resource

S=tuple(product((0,1),repeat=4))
IX={x:i for i,x in enumerate(S)}
AX=range(4)
P=tuple(combinations(AX,2))
def step(x,a):
    return tuple(v^(i==a) for i,v in enumerate(x))
def edge(x,a):
    return (min(x,step(x,a)),a)
E=tuple((x,a) for x in S for a in AX if x[a]==0)
EIX={v:i for i,v in enumerate(E)}
AR={(x,a):4*IX[x]+a for x in S for a in AX}
def face(x,k,l):
    return ((x,k),(step(x,k),l),(step(x,l),k),(x,l))

def profile(m):
    d=[0]*len(E)
    parity=0
    for x in S:
        for k,l in P:
            n=m[x,k,l]
            for a in set(AX)-{k,l}:
                d[EIX[edge(x,a)]]+=n
            if n%2:
                for anchor in face(x,k,l):
                    parity^=1<<AR[anchor]
    site=[sum(d[EIX[edge(x,a)]] for a in AX) for x in S]
    assert sum(m.values())==32 and site==[8]*16
    p=[];low=[]
    for i,(x,a) in enumerate(E):
        v=((parity>>AR[x,a])&1)+((parity>>AR[step(x,a),a])&1)
        if (d[i]-v)%2:p.append(i)
        if d[i]<v:low.append(i)
    return d,p,low

def falsifiers():
    a=Counter({(x,k,l):1 for x in S for k,l in ((0,1),(2,3))})
    b=a.copy()
    x=S[0]
    for k,l in ((0,1),(2,3)):b[x,k,l]-=1
    for k,l in ((0,2),(1,3)):b[x,k,l]+=1
    a0,p0,h0=profile(a);a1,p1,h1=profile(b)
    assert a0==a1==[2]*32 and not p0 and not h0 and len(p1)==8
    c=Counter({(x,2,3):2 for x in S})
    d=Counter({(x,2,3):2+(-1)**sum(x)*x[2] for x in S})
    c0,cp,ch=profile(c);d0,dp,dh=profile(d)
    assert c0==d0 and not cp and not dp and not ch and len(dh)==8
    assert all(E[i][1]==3 for i in dh)
    for n,a,b in product(range(9),range(2),range(2)):
        actual=any(j%2==a and (n-j)%2==b for j in range(n+1))
        assert actual==(n>=a+b and (n-a-b)%2==0)
    return dict(face_boundary_falsifier=len(p1),reciprocal_anchor_falsifier=len(dh),
                reciprocal_blocked_edges=[(IX[E[i][0]],E[i][1]) for i in dh])

def local_rows():
    counts=[v for v in product(range(5),repeat=6) if sum(v)<=4]
    assert len(counts)==210
    allrows=[]
    for x in S:
        rows=[]
        for ns in counts:
            edges=[0]*32
            vertices=[0]*16
            r=0
            for (k,l),n in zip(P,ns,strict=True):
                if n%2:
                    for a in face(x,k,l):r^=1<<AR[a]
                for a in set(AX)-{k,l}:
                    edges[EIX[edge(x,a)]]+=n
                    vertices[IX[x]]+=n
                    vertices[IX[step(x,a)]]+=n
            rows.append((sum(ns),tuple(edges),tuple(vertices),r))
        allrows.append(rows)
    return allrows

def pilot():
    records=local_rows()
    ed=[set() for _ in E]
    vtx=[set() for _ in S]
    ar=[set() for _ in AR]
    for i,rows in enumerate(records):
        for n,e,v,r in rows:
            for j,z in enumerate(e):
                if z:ed[j].add(i)
            for j,z in enumerate(v):
                if z:vtx[j].add(i)
            for j in range(64):
                if r>>j&1:ar[j].add(i)
    complete_edges=[ed[i]|ar[AR[x,a]]|ar[AR[step(x,a),a]] for i,(x,a) in enumerate(E)]
    assert set(map(len,ed))=={2} and set(map(len,vtx))=={5}
    assert set(map(len,ar))=={4} and set(map(len,complete_edges))=={8}
    todo=set(range(16))
    done=set()
    order=[]
    widths=[]
    while todo:
        def score(i):
            before=done|{i}
            live=lambda cols:sum(bool(c&before) and bool(c-before) for c in cols)
            return live(vtx)+live(complete_edges)+live(ar),live(vtx),live(complete_edges),live(ar),i
        n,v,e,a,i=min(map(score,todo))
        order.append(i);widths.append([v,e,a]);todo.remove(i);done.add(i)
    caps=dict(rows=120000,attempts=2_000_000)
    seen={(0,(0,)*32,(0,)*16,0)}
    attempted=0
    steps=[]
    refusal=None
    done=set()
    for i in order:
        done.add(i)
        closed_v=[j for j,x in enumerate(vtx) if x<=done]
        closed_e=[j for j,x in enumerate(complete_edges) if x<=done]
        new=set()
        for (n,e,v,r),(m,ee,vv,s) in product(seen,records[i]):
            if attempted==caps['attempts']:
                refusal=dict(kind='visits',site=i,prospective=attempted+1,cap=caps['attempts']);break
            attempted+=1
            if n+m>32:continue
            vv=tuple(a+b for a,b in zip(v,vv))
            if max(vv)>8 or any(vv[j]!=8 for j in closed_v):continue
            ee=tuple(a+b for a,b in zip(e,ee))
            rr=r^s
            good=True
            for j in closed_e:
                x,a=E[j]
                p=((rr>>AR[x,a])&1)+((rr>>AR[step(x,a),a])&1)
                if ee[j]<p or (ee[j]-p)%2:
                    good=False;break
            if not good:continue
            key=(n+m,ee,vv,rr)
            if key not in new and len(new)==caps['rows']:
                refusal=dict(kind='rows',site=i,prospective=len(new)+1,cap=caps['rows']);break
            new.add(key)
        if refusal:break
        seen=new
        steps.append(dict(center=i,rows=len(seen),cumulative_attempts=attempted,
                          closed_vertices=len(closed_v),closed_edges=len(closed_e)))
    return dict(physical_anchor_owner_counts=sorted(set(map(len,ar))),
         full_edge_predicate_owner_counts=sorted(set(map(len,complete_edges))),
         vertex_saturation_owner_counts=sorted(set(map(len,vtx))),weighted_center_order=order,
         frontier_counts_vertex_edge_anchor=widths,bounded_support_steps=steps,
         refusal=refusal,attempted=attempted,caps=caps,
         scope='total center counts, exact coframe edge degree, vertex degree, physical-anchor curvature parity only; no chirality allocations, masks, moments or coefficients',
         sampled_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)

def gf2_dimension(columns):
    pivots={}
    for m in columns:
        while m and m.bit_length() in pivots:
            m^=pivots[m.bit_length()]
        if m:pivots[m.bit_length()]=m
    return len(pivots)

def parity_ranks():
    e=[];v=[]
    for x in S:
        for k,l in P:
            u,w=sorted(set(AX)-{k,l})
            sites=(step(x,u),step(x,w))
            anchors=(*face(x,k,l),(x,u),(x,w))
            mask=0
            for a,b in anchors:mask^=1<<EIX[edge(a,b)]
            e.append(mask)
            v.append((1<<IX[sites[0]])^(1<<IX[sites[1]]))
    r=gf2_dimension(e);s=gf2_dimension(v)
    assert (r,s)==(31,14)
    return dict(edge_parity_rank=r,vertex_parity_rank=s,additional_edge_parity_after_vertex=s and r-s)

d=2**224*factorial(192)*factorial(32)
assert d.bit_length()==1527
assert (24962**4)==388255409514885136
print(json.dumps(dict(falsifiers=falsifiers(),common_scale_bits=d.bit_length(),
    scaled_magnitude_bound_bits=(d*2**800).bit_length(),parity_linear_ranks=parity_ranks(),pilot=pilot()),indent=2))
