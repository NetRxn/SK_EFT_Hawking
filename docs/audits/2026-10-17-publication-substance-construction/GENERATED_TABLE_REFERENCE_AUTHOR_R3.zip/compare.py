from collections import Counter
import hashlib,json,sys
from pathlib import Path
from validation.checks import prose_lean_refs as refs
from render_paper_tables import spec_output_paths

p=Path(sys.argv[1])
records={}
for bundle in refs.BUNDLE_CODES:
    old=p/"base/papers"/bundle/"paper_draft.tex"
    new=p/"tree/papers"/bundle/"paper_draft.tex"
    old_tokens=Counter(token for token,_ in refs._prose_verbatim_tokens(old.read_text()))
    source=new.read_text()
    got=Counter(token for token,_ in refs._prose_verbatim_tokens(source))
    table_count=0
    for name,text,err in refs._bundle_table_sources(new):
        assert err is None, err
        got.update(token for token,_ in refs._prose_verbatim_tokens(text,macro_source=source))
        table_count+=1
    assert old_tokens==got, bundle
    records[bundle]={"registered_outputs":table_count,"tokens":sum(got.values()),
                     "digest":hashlib.sha256(json.dumps(got,sort_keys=True).encode()).hexdigest()}
base=json.loads((p/"base-cli.json").read_text())["checks"]
tree=json.loads((p/"tree-cli.json").read_text())["checks"]
assert base==tree
assert sum(item["registered_outputs"] for item in records.values())==83
assert sum(item["tokens"] for item in records.values())==2540
print(json.dumps({"verdicts_equal":True,"bundles":records},indent=2))
