from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from compile_bundle_pdf import compile_one, recorded_table_inputs
from seed_journal import outstanding, seeded_mutation

out = Path(sys.argv[1])
draft = Path("papers/D9/paper_draft.tex").resolve()
table = draft.parent / "tables/exact.tex"
before = {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in (draft, table)}
journal = outstanding(include_live=True)
old_input = r"\input{tables/exact.tex}"
old_ref = r"\lean{diamondDist\_dephasing\_eq}"
probe = "d9_independent_r2_missing_probe"
assert draft.read_text().count(old_input) == table.read_text().count(old_ref) == 1
with ExitStack() as guard:
    guard.enter_context(seeded_mutation(
        draft, lambda s: s.replace(r"\usepackage{graphicx}",
            "\\usepackage{graphicx}\n\\usepackage{ifthen}").replace(
            old_input, r"\iffalse\ifthenelse{1=1}{True}{False}\else" + old_input + r"\fi"),
        reason="R3 D9 rendered else branch",
    ))
    guard.enter_context(seeded_mutation(
        table, lambda s: s.replace(old_ref, r"\lean{" + probe.replace("_", r"\_") + "}"),
        reason="R3 D9 registered artifact reference",
    ))
    result = subprocess.run([
        sys.executable, "-B", "scripts/validate.py", "--check",
        "prose_theorem_reference_coverage", "--json",
    ], text=True, capture_output=True)
    (out / "seeded-cli.json").write_text(result.stdout)
    (out / "seeded-cli.stderr").write_text(result.stderr)
    assert result.returncode == 1, result.stderr
    check = json.loads(result.stdout)["checks"]["prose_theorem_reference_coverage"]
    [detail] = [d for d in check["details"] if d["name"] == f"unresolved:D9:{probe}"]
    assert check["measured"] and not check["passed"] and not detail["passed"]
    assert "papers/D9/tables/exact.tex:9" in detail["message"]
    compile_pass, report, _ = compile_one(draft.parent, force=True, keep=True)
    assert compile_pass, report
    retained = Path(report.split("artifacts kept: ")[-1])
    recorder = retained / "paper_draft.fls"
    (out / "D9-seeded.fls").write_bytes(recorder.read_bytes())
    opened = recorded_table_inputs(draft.parent, recorder)
    assert "tables/exact.tex" in opened
    text = subprocess.check_output(["pdftotext", "-layout", str(draft.with_suffix(".pdf")), "-"],
                                   text=True)
    assert probe in text or probe.replace("_", " ") in text
    (out / "D9-seeded-pdf-excerpt.txt").write_text(
        "\n".join(line for line in text.splitlines() if probe in line or probe.replace("_", " ") in line) + "\n")
assert outstanding(include_live=True) == journal
assert all((p.read_bytes(), p.stat().st_mtime_ns) == value for p, value in before.items())
print(json.dumps({"exit": result.returncode, "finding": detail, "compile": report.splitlines()[0],
                  "opened": opened, "pdf_visible": True, "journal_restored": True,
                  "sha256_restored": {p.name: hashlib.sha256(v[0]).hexdigest()
                                      for p, v in before.items()}}, indent=2))
