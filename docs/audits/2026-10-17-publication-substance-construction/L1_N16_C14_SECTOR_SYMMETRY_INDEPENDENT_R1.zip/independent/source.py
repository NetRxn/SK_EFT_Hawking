from itertools import product
from src.core.formulas import original_action_factors, original_coframe_blocks, original_spin4_link, original_gamma, original_gamma5
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
R=OriginalRegulator()
assert (R.extents,R.boundary_signs,R.convention,R.word)==((2,)*4,(1,)*4,'source_C','closed')
links={a:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*a,h,k))) for k in range(4)) for h in ('L','R'))) for a in R.link_order}
sig=(-1,-1,-1,1)
assert all(original_gamma(a)[i^2][j^2]==original_gamma(a)[i][j]*sig[a] for a,i,j in product(range(4),repeat=3))
assert all(original_gamma5()[i^2][j^2]==-original_gamma5()[i][j] for i,j in product(range(4),repeat=2))
def pol(p,transform,s=1):
    return {tuple(sorted(transform(q) for q in k)):s*v for k,v in p.terms}
def flip(q):
    x,d,h,k=q.index
    return Symbol('q',(x,d,'L' if h=='R' else 'R',k))
assert all(pol(m[i][j],flip)==dict(m[i^2][j^2].terms) for m in links.values() for i,j in product(range(4),repeat=2))

perms=((1,0,2,3),(2,3,0,1),(0,2,1,3),(0,3,1,2))
def mapping(pi,x):
    y=[0]*4
    for d,v in enumerate(x):y[pi[d]]=v
    return tuple(y)
def parity(w):return (-1)**sum(a>b for i,a in enumerate(w) for b in w[i+1:])
def transformed_q(pi,q):
    x,d,h,k=q.index
    return Symbol('q',(mapping(pi,x),pi[d],h,k))
def cof(alpha):
    return original_coframe_blocks(R,alpha,links)
for pi,x,d,k in product(perms,R.sites,range(4),(-1,1)):
    y,s=R.step(x,d,k)
    assert R.step(mapping(pi,x),pi[d],k)==(mapping(pi,y),s)
coframe_count=0
for x,d,a in product(R.sites,range(4),range(4)):
    raw=cof((x,d,a))
    for b in raw:
        for i,j in product(range(4),repeat=2):
            assert pol(b.matrix[i][j],flip,sig[a])==dict(b.matrix[i^2][j^2].terms)
        coframe_count+=1
    for pi in perms:
        xp=mapping(pi,x)
        for b,c in zip(raw,cof((xp,pi[d],a)),strict=True):
            assert ((xp,pi[d],a),mapping(pi,b.bar_site),mapping(pi,b.psi_site),(mapping(pi,b.anchor[0]),pi[b.anchor[1]]),b.weight)==(c.alpha,c.bar_site,c.psi_site,c.anchor,c.weight)
            for i,j in product(range(4),repeat=2):
                assert pol(b.matrix[i][j],lambda q:transformed_q(pi,q))==dict(c.matrix[i][j].terms)
print('gamma, gamma5, all 64 based Spin4 links and',coframe_count,'actual signed coframe blocks transport exactly; signed hop maps exhaustive',flush=True)

root=R.sites[0]
factors=original_action_factors(R,root,links)
by={(f.t_degree,f.components,f.anchors):f.coefficient for f in factors}
assert len(by)==408
rows=0
for v in factors:
    rows+=len(v.coefficient.terms)
    if v.t_degree==2:
        a,b=(k for _,_,k in v.components)
        assert pol(v.coefficient,flip,-sig[a]*sig[b])==dict(v.coefficient.terms)
    for pi in perms:
        cf=tuple((mapping(pi,x),pi[d],a) for x,d,a in v.components)
        af=tuple((mapping(pi,x),pi[d]) for x,d in v.anchors)
        if v.t_degree==4:cf=tuple(sorted(cf))
        assert pol(v.coefficient,lambda q:transformed_q(pi,q),parity(pi))==dict(by[v.t_degree,cf,af].terms)
print('all 408 root raw source factors and',rows,'signed coefficient rows verify complement and four axis permutations',flush=True)
# The involutive component order permutation at each site crosses two
# four-generator blocks. Site relabeling is a permutation of eight blocks.
for pi in perms:
    site_perm=[R.site_number(mapping(pi,x)) for x in R.sites]
    assert parity([8*i+j for i in site_perm for j in range(8)])==1
assert parity([4,5,6,7,0,1,2,3])==1
print('all top Berezin signs positive',flush=True)
