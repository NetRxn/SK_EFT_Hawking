from pathlib import Path
from itertools import product
from collections import Counter,defaultdict
import json,sys
ENV=Path('/tmp/publication-c14-exterior-r1.jdckE6')
BATCH=Path('/tmp/publication-c14-s4-diagonal-r1.btrcpw')
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
TWO=Path('/tmp/publication-c14-rank-zero-r1.gte6BM')
SEW=Path('/tmp/publication-c14-shared-trace-r1.9tcmVn')
R12=Path('/tmp/publication-c14-rank12-r1.ehXXAy')
R3=Path('/tmp/publication-c14-rank3-r1.q1WfND')
RES=Path('/tmp/publication-c14-residual-edge-r1.klcKMh')
def rows(p):
    for s in p.open():yield json.loads(s)
def pair(v):return tuple(v) if isinstance(v,list) else (v,0)
def parity(mask):return (-1)**((mask&15).bit_count()*(mask>>4).bit_count())
def bm(m):return ((m&15)<<4)|(m>>4)
def sig(c):return 1 if c==3 else -1
def kind(k):
    if k[0]=='q':return 'q'
    if k[0]=='a' or k[:2]=='S4':return 'c'
    assert k[0]=='m' or 'mask' in k or k.startswith('remote'),k
    return 'm'
def transform(keys,k):
    y=[]; s=1
    for key,v in zip(keys,k,strict=True):
        t=kind(key)
        if t=='q':y.append(v^4)
        elif t=='m':y.append(bm(v));s*=parity(v)
        else:y.append(v);s*=sig(v)
    return tuple(y),s

g=json.loads((ENV/'graph.json').read_text())
files={
 'rank8_edge0':STAR/'edge-0.jsonl','rank8_edge1':STAR/'edge-1.jsonl',
 'rank8_edge2':BATCH/'s4-10-axis2-exterior.jsonl','rank8_edge3':BATCH/'s4-9-axis3-exterior.jsonl',
 'rank0_edge1':TWO/'zero-edge-1.jsonl','rank0_edge2':TWO/'zero-edge-2.jsonl','rank0_edge3':TWO/'zero-edge-3.jsonl',
 'trace0':TWO/'plane-01-trace.jsonl','trace1':TWO/'plane-01-trace.jsonl',
 'trace2':SEW/'trace-slices.jsonl','trace3':SEW/'trace-slices.jsonl',
 'partition_rank8':STAR/'site-factors.jsonl','partition_rank0':TWO/'zero-site-factors.jsonl',
 'residual_edge':RES/'residual-edge.jsonl','rank12_closure':R12/'rank12-closure.jsonl','rank4_closure':BATCH/'rank4-closure-exterior.jsonl',
 'rank3_compact':R3/'rank3-compact.jsonl','rank3_edge2':R3/'rank3-axis2.jsonl','rank3_edge3':R3/'rank3-axis3.jsonl',
 'rank3_projection':R3/'rank3-projection.jsonl','merge_rank1':R3/'merge-rank1.jsonl','merge_rank2':R3/'merge-rank2.jsonl',
 'conditional_tile':SEW/'conditional-tiles.jsonl','mask_bridge':TWO/'compatible-mask-bridge.jsonl'}
assert set(g['factor_keys'])==set(files)
for n,keys in g['factor_keys'].items():
    if n in ('conditional_tile','mask_bridge'):
        values={tuple(l[:len(keys)]) for l in rows(files[n])}
        assert {transform(keys,k)[0] for k in values}==values
        print(n,len(values),'exact complement Boolean support',flush=True)
        continue
    values={tuple(line[0]):pair(line[1]) for line in rows(files[n])}
    for k,z in values.items():
        kk,s=transform(keys,k)
        if n.startswith('trace'):s=-s
        assert values.get(kk)==tuple(s*v for v in z),(n,k,z,kk,values.get(kk),s)
    print(n,len(values),'exact signed complement rows',flush=True)
# Counterexample for naïve one-occurrence coordinate complement in
# an otherwise fixed quartic edge, without a source change of variables.
tab={tuple(k):pair(z) for k,z in rows(STAR/'edge-0.jsonl')}
counter=next((k,z,k[:-1]+(k[-1]^4,),tab.get(k[:-1]+(k[-1]^4,),(0,0)))
             for k,z in sorted(tab.items()) if k[:-1]+(k[-1]^4,) not in tab)
print('isolated q occurrence flip counterexample',counter,flush=True)

def orient(rows0):
    out={}
    for o,fs,z,paths in rows0:
        D={}
        for a,b,T in paths:
            p,q=tuple(a),tuple(b)
            v={(u,v):w for u,v,w in T}
            if p>q:
                p,q=q,p
                v={(v,u):z for (u,v),z in v.items()}
            D[p,q]=v
        out[o]=dict(fs),z,D
    return out
O=orient(rows(ENV/'exterior-orientations.jsonl'))
for o,(fixed,z,paths) in O.items():
    transformed={}
    for ((u,h),(v,k)),T in paths.items():
        P,Q=(u,h^1),(v,k^1)
        S={(bm(a),bm(b)):c for (a,b),c in T.items()}
        if P>Q:
            P,Q=Q,P
            S={(b,a):c for (a,b),c in S.items()}
        transformed[P,Q]=S
    assert O[o^65535]==({u:bm(m) for u,m in fixed.items()},z,transformed)
assert len(O)==2604
print('all 2604 original exterior orientation factors complement exactly',flush=True)

def perm(s,p):return tuple(s[j] for j in p)
def neighborhood(s):
    return (tuple(1-x for x in s),perm(s,(1,0,2,3)),perm(s,(0,1,3,2)),perm(s,(2,3,0,1)))
unseen=set(product(range(2),repeat=4))
all_orbits=[]
while unseen:
    todo=[min(unseen)]
    seen=set()
    while todo:
        v=todo.pop()
        if v in seen:continue
        seen.add(v);todo+=list(neighborhood(v))
    assert seen<=unseen
    unseen-=seen
    all_orbits.append([''.join(map(str,v)) for v in sorted(seen)])
assert [len(o) for o in all_orbits]==[2,8,2,4]
print('sector orbits',json.dumps(all_orbits),flush=True)
for order in ((1,0,2,3),(0,1,3,2)):
    def mapped_slot(k):
        if kind(k) in ('c','q') and not k.startswith('S4'):
            base,i=k.rsplit('_',1)
            return f'{base}_{order[int(i)]}'
        return k
    nrows=0
    for name,keys in g['factor_keys'].items():
        other=f'trace{order[int(name[-1])]}' if name.startswith('trace') else name
        dest=g['factor_keys'][other]
        transported=[mapped_slot(k) for k in keys]
        assert set(transported)==set(dest)
        perm=[transported.index(k) for k in dest]
        boolean=name in ('conditional_tile','mask_bridge')
        def records(name):
            return ({tuple(l[:len(keys)]):(1,0) for l in rows(files[name])} if boolean else
                    {tuple(line[0]):pair(line[1]) for line in rows(files[name])})
        tab=records(name)
        assert {tuple(k[i] for i in perm):z for k,z in tab.items()}==records(other)
        nrows+=len(tab)
    print('all frozen factor occurrence relabelings exact',order,'rows',nrows,flush=True)

roster=Path('/tmp/publication-n16-denominator-support-r1.VjgwoR/c14-occupancy-roster.jsonl')
def sig_row(row):
    return tuple(map(tuple,row['planes'])),tuple(row['S4_occupations']),row['exponential_divisor']
ROSTER={sig_row(r) for r in rows(roster)}
def rankpi(x,pi):
    return sum(((x>>(3-d))&1)<<(3-pi[d]) for d in range(4))
def transform_row(row,pi):
    planes,q,fac=row
    transported=tuple(sorted((rankpi(x,pi),*sorted((pi[a],pi[b]))) for x,a,b in planes))
    qq=[None]*16
    for x in range(16):qq[rankpi(x,pi)]=q[x]
    return transported,tuple(qq),fac
from itertools import permutations
for p in permutations(range(4)):
    assert {transform_row(row,p) for row in ROSTER}==ROSTER
orig=next(row for row in ROSTER if row[0]==((0,0,1),(0,0,1),(0,2,3),(0,2,3)) and row[-1]==512)
images={transform_row(orig,p) for p in permutations(range(4))}
assert len(images)==3
print('all 1968 directional rows preserved by each of 24 axis permutations; three distinct zero-root representatives form one orbit',flush=True)
# Anchorwise real-coordinate reflection tests exact coefficient conjugation.
# With the original plus-i Pauli matrix, q1/q3 change signs.
def conj_weight(keys,k):
    s=1
    for name,v in zip(keys,k,strict=True):
        t=kind(name)
        if t=='q':s*=(-1)**(v%2)
        elif t=='c':s*=(-1 if v in (0,2) else 1)
    return s
for name,keys in g['factor_keys'].items():
    if name in ('conditional_tile','mask_bridge'):continue
    for line in rows(files[name]):
        k,z=line[:2]
        a,b=pair(z)
        s=conj_weight(keys,k)
        assert (a,-b)==(s*a,s*b),(name,k,z,s)
print('coordinate reflection and component signs certify each sector coefficient is real',flush=True)
