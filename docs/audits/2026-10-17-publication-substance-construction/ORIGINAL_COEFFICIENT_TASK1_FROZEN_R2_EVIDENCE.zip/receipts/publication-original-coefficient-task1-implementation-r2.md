# Original coefficient Task1 repair R2

**Frozen for fresh COMPLETE independent science and algebra/error reviews.** All four R1 findings were reproduced with new failing tests and repaired in the same three owned PRIMARY paths. No Git/Lean/controller/build/cache/dependency/registry/notebook/roadmap mutation occurred.

## Actual red/green evidence

New tests against frozen R1 production: `23 failed, 24 deselected in 0.76s`, exit1. Final entire bounded suite plus dependency checks: `52 passed in 8.92s`, exit0. All47 Task1 tests (24 original plus23 new) and5 dependency cases pass. Maximum measured scalar products/test remains70016; one CPU/no cacheprovider was used. Raw logs and subprocess status receipts are preserved with hashes in JSON.

## SCIENCE1_ALG1

vanishes_above(tested_degree) is strictly tested_degree>degree_bound; boundary degree is retained. Original mirrored R1 assertion corrected, not deleted.

['V=1 periodic original four-block coframe, all actual valid unit Spin4 links i*sigma3: T4=24*Theta nonzero and T5=0; helper false4/true5.', 'N16 original centered coframe with same supplied valid links: T8=(315/2)*Theta_x*Theta_y nonzero and T9=0; helper false8/true9.']

local8 remains production_authorized=False; global4V/default64 unchanged.

## ALG2

SparseMatrix validates nonnegative exact integer size and in-range exact integer coordinates; canonicalizes duplicate coefficients by addition, removes exact zeros, coerces only exact coefficient-domain values, copies nested entries to immutable tuples; .at and .to_exterior consume the same canonical entries. Accessor indices are validated.

Symbol copies nested list/tuple indices recursively and rejects opaque/mutable key domains. BlockIncrement freezes alpha/sites/anchor and exact4x4 matrix; ActionFactor freezes components/anchors and coefficient; GeneratorLinkSupport freezes nested generator/site/anchor labels. Other supported certificate tuple fields are copied.

noncanceling and canceling duplicates, size/index/coefficient refusals, outer and nested caller mutation, hash stability and accessor/exterior agreement.

## ALG3

exact_matrix validates every row and coefficient before arithmetic. Multiply, dagger, add and scale preserve full rectangles. Supplied original coframe and plaquette links must be exact4x4.

() represents0x0; empty multiply/dagger/add returns(). Nonempty zero-width rows are intentionally refused because nested tuples cannot preserve their transpose dimension. Incompatible empty/nonempty products refuse.

ragged longer/shorter later rows, valid2x3 by3x2 product, rectangular complex dagger, zero-width/empty cases, malformed4x5/5x4/3x4/4x3 supplied links at both boundaries.

## ALG4

original_spin4_link checks each normalized coefficient polynomial equals its actual conjugate; nonreal QComplex i and complex J inputs refuse. No projection or complexified model substitution.

nonzero imaginary scalars/polynomials and J shifts rejected on either chirality; rational q/h and genuinely self-conjugate J+conjugate(J) combinations retained. Ambient real polynomial coordinates do not gain a new sphere-normalization requirement.

## Source and conservation

- `src/core/formulas.py`: `d027e9c502eef1a11d76974dcc12615f580eb3b13ba05f4d4897febf53a5c6b8` (509040 bytes).
- `src/vestigial/original_coefficients.py`: `e0246533578e91ad4c71b4b97624e69d9114bf51cff8a0a6f92fb71a1c0425d2` (27548 bytes).
- `tests/test_original_coefficients.py`: `15d64a3899ad078015864ae4354156c62bbe1bb6a4e8db3c5a398833865d885d` (25695 bytes).

The original500606-byte formulas prefix is byte-identical, SHA256 `7a1fff54dcdcd0d52ade2ef1cab136d66f2f1697b67bec8b278007d3a857a990`. R2 delta against the three exact frozen R1 sources is in `/tmp/publication-original-coefficient-task1-implementation-r2.diff`, SHA256 `4bbdc585202db0ff605e2dcc522a7e454f3d406fae1e4f7584b7832024fa0626`. `git diff --check` exit0. No source outside the three owned paths changed.

Same R2 packet first check fresh=true,changed=[],exit0. Final SAME check fresh=false,changed=[owned-files,source],exit1 as expected; all authority hashes conserved. No self-refresh. ROOT must reconcile these owned edits.

R2 actual symbolic Dirac construction still has512 matrix entries and32768 scalar coefficient slots, consuming70016 expanded products. Unique supplied object graph is9496710 bytes, within512MiB fixture cap; this is not RSS or a future contraction allocation.

## Scope and remaining work

No W/Haar/full original coefficient/fullZ/phase/campaign/GPU run. Bounded supplied-unit-link coframe powers and pure algebra/geometry are actual tests, not integrated coefficients. Full quaternion parametrization/M-C transport/local8/Eq9/Eq10 kernel bridges remain Stage2/3 obligations.

Explicit temporal_axis remains independent of unreflected source_C polynomial. Euclidean metric_M is M_N. Entrywise gamma equality after Executor S rotation does not identify WORLDcut P0/C3/N0 or full source/antilinear physical kernel maps; no physical certificate cross-consumption granted.

Task2: Full exact family-graded raw source jets/minors/Hermite W/Gaussian/Haar/contact/refusal APIs and separately admitted COMPLETE original one-site direct-vs-W4 functional:3876 quartics/740 support slots,4029 raw W terms/23504 queries, both words and variances2/3, full interacting denominator and T/H/frame jets. No generic odd metric or derivative-order pruning.

Task3: Separately admitted complete N16 invariant36-entry direct/minor tensors, full24-minor roster/projectors, both chirality loops and full F60/G52/contact/exclusion/anchor scope under70M resource review. Actual P0-C3/N0 physical map still owed.

Task4: Complete exact split-factor denominator/source frontier, viable independently qualified full allocation, full coefficients and certified nonzero normalization. Physical source/state/projector/calibration/adjoint/domain, B3 normalization/window, modes/matter/transport and controlled limits remain OPEN BUILD.

Fresh COMPLETE different independent science and algebra/error reviews, then ROOT explicit stale-owned-source reconciliation. Current bounded green is not independent/full-tree/native/main/publication acceptance.
