"""Exact sparse original-coframe/Dirac foundation on the declared finite torus.

Task1 supplies construction and structural certificates, not an integrated partition
function. Quaternion coordinates, sources and anchored links retain their identities.
No Haar/W evaluation or scientific work occurs at import time. Physics definitions
are imported lazily from core.formulas; generic sparse algebra lives here.
"""
from dataclasses import dataclass, field, fields, is_dataclass, replace
from contextvars import ContextVar
from fractions import Fraction
from itertools import product
from math import prod
import sys


_ACTIVE_COST = ContextVar('original_coefficient_scalar_cost', default=None)


def _freeze_label(value):
    """Copy nested label sequences; reject opaque/mutable key domains."""
    if isinstance(value, (tuple, list)):
        return tuple(_freeze_label(v) for v in value)
    if value is None or type(value) in (int, str, bool) or isinstance(value, Fraction):
        return value
    raise TypeError('labels require immutable scalar or nested sequence data')


def _rational(value):
    if isinstance(value, (int, Fraction)):
        return Fraction(value)
    raise TypeError('exact integer or Fraction required')


@dataclass(frozen=True, slots=True, init=False)
class QComplex:
    """Normalized exact complex scalar, stored as four integers (rn,rd,in,id)."""
    storage: tuple[int, int, int, int]

    def __init__(self, real=0, imag=0):
        if isinstance(real, QComplex) and imag == 0:
            object.__setattr__(self, 'storage', real.storage)
        else:
            r, i = _rational(real), _rational(imag)
            object.__setattr__(self, 'storage', (r.numerator, r.denominator, i.numerator, i.denominator))

    @property
    def real(self):
        return Fraction(*self.storage[:2])

    @property
    def imag(self):
        return Fraction(*self.storage[2:])

    def __bool__(self):
        return bool(self.storage[0] or self.storage[2])

    def __add__(self, other):
        if not isinstance(other, (QComplex, int, Fraction)):
            return NotImplemented
        other = QComplex(other)
        return QComplex(self.real + other.real, self.imag + other.imag)

    __radd__ = __add__

    def __neg__(self):
        return QComplex(-self.real, -self.imag)

    def __sub__(self, other):
        return self + -QComplex(other)

    def __mul__(self, other):
        if not isinstance(other, (QComplex, int, Fraction)):
            return NotImplemented
        other = QComplex(other)
        return QComplex(self.real * other.real - self.imag * other.imag,
                        self.real * other.imag + self.imag * other.real)

    __rmul__ = __mul__

    def conjugate(self):
        return QComplex(self.real, -self.imag)


@dataclass(frozen=True, slots=True, order=True)
class Symbol:
    """A commuting coordinate with its complete source/link identity."""
    family: str
    index: tuple
    conjugated: bool = False

    def __post_init__(self):
        if type(self.family) is not str or type(self.conjugated) is not bool:
            raise TypeError('symbol family and conjugation flag have invalid types')
        index = _freeze_label(self.index)
        if not isinstance(index, tuple):
            raise TypeError('symbol index must be a sequence')
        object.__setattr__(self, 'index', index)
        if self.family in ('q', 'h'):
            object.__setattr__(self, 'conjugated', False)

    def conjugate(self):
        # Only the declared quaternion and auxiliary coordinates are real.
        return self if self.family in ('q', 'h') else replace(self, conjugated=not self.conjugated)


@dataclass(slots=True)
class ScalarCost:
    """Counts individual complex scalar product-accumulations, not ring products."""
    limit: int
    products: int = 0
    _token: object = field(default=None, init=False, repr=False)

    def __enter__(self):
        if self._token is not None:
            raise ValueError('cost scope is already active')
        self._token = _ACTIVE_COST.set(self)
        return self

    def __exit__(self, exc_type, exc, traceback):
        _ACTIVE_COST.reset(self._token)
        self._token = None

    def consume(self):
        if self.products >= self.limit:
            raise ValueError('scalar product budget exceeded; no complete result')
        self.products += 1


def _collect(terms):
    out = {}
    for key, value in terms:
        out[key] = out.get(key, QComplex()) + value
    return tuple(sorted((k, v) for k, v in out.items() if v))


@dataclass(frozen=True, slots=True)
class Polynomial:
    """Finite exact polynomial; key is a sorted tuple of repeated real symbols.

    Each entry contains ONE QComplex scalar coefficient. Multiplication expands
    and optionally counts each scalar product. No sphere relation is assumed.
    """
    terms: tuple = ()

    def __post_init__(self):
        object.__setattr__(self, 'terms', _collect((tuple(sorted(k)), QComplex(v)) for k, v in self.terms))

    @classmethod
    def scalar(cls, value):
        return cls((((), QComplex(value)),)) if QComplex(value) else cls()

    @classmethod
    def variable(cls, symbol):
        return cls((((symbol,), QComplex(1)),))

    @staticmethod
    def coerce(value):
        return value if isinstance(value, Polynomial) else Polynomial.scalar(value)

    def __bool__(self):
        return bool(self.terms)

    def __add__(self, other):
        other = self.coerce(other)
        return Polynomial(self.terms + other.terms)

    __radd__ = __add__

    def __neg__(self):
        return Polynomial(tuple((k, -v) for k, v in self.terms))

    def __sub__(self, other):
        return self + -self.coerce(other)

    def __rsub__(self, other):
        return self.coerce(other) - self

    def multiply(self, other, cost=None):
        other = self.coerce(other)
        cost = _ACTIVE_COST.get() if cost is None else cost
        out = {}
        for a, av in self.terms:
            for b, bv in other.terms:
                if cost is not None:
                    cost.consume()
                key = tuple(sorted(a + b))
                out[key] = out.get(key, QComplex()) + av * bv
        return Polynomial(tuple(out.items()))

    def __mul__(self, other):
        return self.multiply(other)

    __rmul__ = __mul__

    def conjugate(self):
        return Polynomial(tuple((tuple(s.conjugate() for s in k), v.conjugate()) for k, v in self.terms))

    def evaluate(self, values):
        out = QComplex()
        for key, coefficient in self.terms:
            for symbol in key:
                value = QComplex(values[replace(symbol, conjugated=False)])
                if symbol.conjugated:
                    value = value.conjugate()
                cost = _ACTIVE_COST.get()
                if cost is not None:
                    cost.consume()
                coefficient *= value
            out += coefficient
        return out


def permutation_sign(values):
    if len(set(values)) != len(values):
        return 0
    return (-1) ** sum(a > b for i, a in enumerate(values) for b in values[i + 1:])


def epsilon(values):
    return permutation_sign(values) if sorted(values) == list(range(4)) else 0


def identity_matrix(n):
    return tuple(tuple(Polynomial.scalar(int(i == j)) for j in range(n)) for i in range(n))


def exact_matrix(value, shape=None):
    """Validate the entire rectangle and freeze exact polynomial entries.

    () denotes the unique represented 0x0 matrix. Nonempty zero-width rows
    are rejected: nested tuples cannot retain their missing transpose dimension.
    An optional shape is checked before arithmetic (Spin4 consumers use 4x4).
    """
    try:
        rows = tuple(tuple(row) for row in value)
    except TypeError as exc:
        raise ValueError('matrix must be a rectangular sequence of rows') from exc
    width = len(rows[0]) if rows else 0
    if rows and (width == 0 or any(len(row) != width for row in rows)):
        raise ValueError('matrix must be rectangular with nonzero row width')
    if shape is not None and (len(rows), width) != shape:
        raise ValueError(f'matrix must have exact shape {shape[0]}x{shape[1]}')
    return tuple(tuple(Polynomial.coerce(v) for v in row) for row in rows)


def matrix_add(a, b):
    a, b = exact_matrix(a), exact_matrix(b)
    if len(a) != len(b) or (a and len(a[0]) != len(b[0])):
        raise ValueError('matrix shapes differ')
    return tuple(tuple(x + y for x, y in zip(ar, br)) for ar, br in zip(a, b))


def matrix_scale(a, scalar):
    return tuple(tuple(v * scalar for v in row) for row in exact_matrix(a))


def matrix_multiply(a, b, cost=None):
    a, b = exact_matrix(a), exact_matrix(b)
    if not a or not b:
        if not a and not b:
            return ()
        raise ValueError('matrix product shapes differ')
    if len(a[0]) != len(b):
        raise ValueError('matrix product shapes differ')
    return tuple(tuple(sum((a[i][k].multiply(b[k][j], cost) for k in range(len(b))), Polynomial())
                       for j in range(len(b[0]))) for i in range(len(a)))


def matrix_dagger(a):
    a = exact_matrix(a)
    if not a:
        return ()
    return tuple(tuple(a[j][i].conjugate() for j in range(len(a))) for i in range(len(a[0])))


@dataclass(frozen=True, slots=True)
class OriginalRegulator:
    """Frozen original four-dimensional carrier; both directed L2 anchors survive."""
    extents: tuple = (2, 2, 2, 2)
    boundary_signs: tuple = (1, 1, 1, 1)
    convention: str = 'source_C'
    word: str = 'closed'
    temporal_axis: int | None = None

    def __post_init__(self):
        object.__setattr__(self, 'extents', tuple(self.extents))
        object.__setattr__(self, 'boundary_signs', tuple(self.boundary_signs))
        if len(self.extents) != 4 or any(type(n) is not int or n < 1 for n in self.extents):
            raise ValueError('four positive integer extents required')
        if len(self.boundary_signs) != 4 or any(type(s) is not int or s not in (-1, 1) for s in self.boundary_signs):
            raise ValueError('four paired real boundary signs required')
        if self.convention not in ('source_C', 'metric_M') or self.word not in ('printed', 'closed'):
            raise ValueError('explicit convention and word label required')
        if self.temporal_axis is None:
            object.__setattr__(self, 'temporal_axis', 3 if self.convention == 'source_C' else 0)
        if type(self.temporal_axis) is not int or self.temporal_axis not in range(4):
            raise ValueError('temporal axis must be an explicit integer in 0..3')

    @property
    def sites(self):
        return tuple(product(*(range(n) for n in self.extents)))

    @property
    def volume(self):
        return prod(self.extents)

    @property
    def gamma(self):
        from src.core.formulas import original_gamma
        return tuple(original_gamma(a, self.convention) for a in range(4))

    @property
    def gamma5(self):
        from src.core.formulas import original_gamma5
        return original_gamma5()

    @property
    def reflection_matrix(self):
        # This is cut metadata only; it supplies no physical adjoint or kernel map.
        return self.gamma[self.temporal_axis]

    @property
    def auxiliary_degree_bound(self):
        return 4 * self.volume

    @property
    def link_order(self):
        return tuple((x, mu) for x in self.sites for mu in range(4))

    @property
    def generator_order(self):
        local = (('bar', 0), ('bar', 1), ('psi', 0), ('psi', 1),
                 ('bar', 2), ('bar', 3), ('psi', 2), ('psi', 3))
        return tuple((x, kind, i) for x in self.sites for kind, i in local)

    def site_number(self, x):
        self.validate_site(x)
        n = 0
        for v, length in zip(x, self.extents):
            n = n * length + v
        return n

    def validate_site(self, x):
        if len(x) != 4 or any(type(v) is not int or not 0 <= v < n for v, n in zip(x, self.extents)):
            raise ValueError('site outside regulator')

    def step(self, x, mu, direction=1):
        self.validate_site(x)
        if mu not in range(4) or direction not in (-1, 1):
            raise ValueError('unit axis step required')
        raw = x[mu] + direction
        y = tuple(raw % self.extents[mu] if j == mu else v for j, v in enumerate(x))
        return y, self.boundary_signs[mu] if raw < 0 or raw >= self.extents[mu] else 1

    def reflect_site(self, x):
        self.validate_site(x)
        t = self.temporal_axis
        return tuple((1 - v) % self.extents[t] if j == t else v for j, v in enumerate(x))

    def reflected_anchor(self, anchor):
        x, mu = anchor
        y = self.reflect_site(x)
        if mu == self.temporal_axis:
            y = self.step(y, mu, -1)[0]
        return (y, mu), mu == self.temporal_axis


@dataclass(frozen=True, slots=True)
class ConventionTransport:
    """Entrywise M/C dictionary. Order is preserved within either word label."""
    source: str
    target: str

    def __post_init__(self):
        if self.source not in ('source_C', 'metric_M') or self.target not in ('source_C', 'metric_M'):
            raise ValueError('unknown convention')

    def axis(self, a):
        if a not in range(4):
            raise ValueError('invalid axis')
        if self.source == self.target:
            return a
        return (3, 0, 1, 2)[a] if self.source == 'metric_M' else (1, 2, 3, 0)[a]

    def site(self, x):
        out = [0] * 4
        for a, v in enumerate(x):
            out[self.axis(a)] = v
        return tuple(out)

    def anchor(self, anchor):
        x, mu = anchor
        return self.site(x), self.axis(mu)

    def composite(self, alpha):
        x, mu, a = alpha
        return self.site(x), self.axis(mu), self.axis(a)

    linear_label = composite
    auxiliary_label = composite
    phase_label = site

    def metric_pair(self, pair):
        return tuple(sorted(self.axis(i) for i in pair))

    def frame_pair(self, pair):
        return tuple(self.axis(i) for i in pair)

    def regulator(self, reg):
        if reg.convention != self.source:
            raise ValueError('transport source mismatch')
        return OriginalRegulator(self.site(reg.extents), self.site(reg.boundary_signs), self.target, reg.word, self.axis(reg.temporal_axis))

    def couplings(self, g1, g2):
        return g1, g2 if self.source == self.target else -g2

    def spinor(self, i):
        return i

    def chirality(self, label):
        return label

    def sigma2(self, v):
        return v

    def reflect_site(self, reg, x):
        return self.site(reg.reflect_site(x))

    def temporal_reflection_anchor(self, reg, anchor):
        reflected, dagger = reg.reflected_anchor(anchor)
        return self.anchor(reflected), dagger

    def berezin_sign(self, reg):
        # Site relabeling exchanges blocks of degree eight; spinor order is fixed.
        return permutation_sign(tuple(self.regulator(reg).site_number(self.site(x)) for x in reg.sites)) ** 8


@dataclass(frozen=True, slots=True)
class BlockIncrement:
    alpha: tuple
    bar_site: tuple
    psi_site: tuple
    anchor: tuple
    weight: Fraction
    matrix: tuple

    def __post_init__(self):
        for name in ('alpha', 'bar_site', 'psi_site', 'anchor'):
            object.__setattr__(self, name, _freeze_label(getattr(self, name)))
        object.__setattr__(self, 'weight', _rational(self.weight))
        object.__setattr__(self, 'matrix', exact_matrix(self.matrix, shape=(4, 4)))


@dataclass(frozen=True, slots=True)
class ActionFactor:
    t_degree: int
    components: tuple
    coefficient: Polynomial
    anchors: tuple = ()

    def __post_init__(self):
        object.__setattr__(self, 'components', _freeze_label(self.components))
        object.__setattr__(self, 'anchors', _freeze_label(self.anchors))
        object.__setattr__(self, 'coefficient', Polynomial.coerce(self.coefficient))


@dataclass(frozen=True, slots=True)
class GeneratorLinkSupport:
    """Complete structural generator/anchor labels before coefficient cancellation."""
    generators: tuple
    anchors: tuple
    sites: tuple

    def __post_init__(self):
        for name in ('generators', 'anchors', 'sites'):
            object.__setattr__(self, name, _freeze_label(getattr(self, name)))


def factor_support(reg, factor):
    """Support union of the original coframe blocks and ordered curvature path.

    This is an envelope; zero specialized coefficients do not delete incidence.
    In particular it does not make two occurrences of a shared link independent.
    """
    sites, anchors = set(), set(factor.anchors)
    for x, mu, a in factor.components:
        reg.validate_site(x)
        forward, backward = reg.step(x, mu)[0], reg.step(x, mu, -1)[0]
        sites.update((x, forward, backward))
        anchors.update(((x, mu), (backward, mu)))
    return GeneratorLinkSupport(tuple(g for g in reg.generator_order if g[0] in sites),
                                tuple(sorted(anchors)), tuple(sorted(sites)))


def legacy_quaternion_to_c(coordinates):
    """Old minus-i coordinates -> canonical plus-i, a Haar sphere isometry."""
    if len(coordinates) != 4:
        raise ValueError('four quaternion coordinates required')
    return (coordinates[0], *(-v for v in coordinates[1:]))


@dataclass(frozen=True, slots=True)
class SparseMatrix:
    size: int
    entries: tuple

    def __post_init__(self):
        if type(self.size) is not int or self.size < 0:
            raise ValueError('matrix size must be a nonnegative integer')
        out = {}
        for entry in self.entries:
            if len(entry) != 2:
                raise ValueError('matrix entry must contain coordinate and coefficient')
            key, value = entry
            key = tuple(key)
            if len(key) != 2 or any(type(i) is not int or not 0 <= i < self.size for i in key):
                raise ValueError('matrix coordinates must be in-range integer indices')
            out[key] = out.get(key, Polynomial()) + Polynomial.coerce(value)
        object.__setattr__(self, 'entries', tuple(sorted((k, v) for k, v in out.items() if v)))

    def at(self, i, j):
        if any(type(k) is not int or not 0 <= k < self.size for k in (i, j)):
            raise ValueError('matrix access requires in-range integer indices')
        return dict(self.entries).get((i, j), Polynomial())

    def to_exterior(self, reg):
        if self.size != 4 * reg.volume:
            raise ValueError('matrix/regulator size mismatch')
        positions = {g: i for i, g in enumerate(reg.generator_order)}
        out = ExteriorPolynomial()
        for (i, j), value in self.entries:
            a = positions[(reg.sites[i // 4], 'bar', i % 4)]
            b = positions[(reg.sites[j // 4], 'psi', j % 4)]
            out += ExteriorPolynomial.generator(a) * ExteriorPolynomial.generator(b) * value
        return out


def assemble_coframe(reg, increments):
    out = {}
    for b in increments:
        rb, cb = 4 * reg.site_number(b.bar_site), 4 * reg.site_number(b.psi_site)
        for i, row in enumerate(b.matrix):
            for j, v in enumerate(row):
                if v:
                    key = rb + i, cb + j
                    out[key] = out.get(key, Polynomial()) + v * b.weight
    return SparseMatrix(4 * reg.volume, tuple(sorted((k, v) for k, v in out.items() if v)))


def assemble_dirac(reg, h_plus_J=None, links=None):
    """Add all original blocks, retaining their shared h/J/link polynomials."""
    from src.core.formulas import original_coframe_blocks
    out = {}
    for x in reg.sites:
        for mu in range(4):
            for a in range(4):
                alpha = x, mu, a
                weight = (Polynomial.variable(Symbol('h', alpha)) + Polynomial.variable(Symbol('J', alpha))
                          if h_plus_J is None else Polynomial.coerce(h_plus_J.get(alpha, 0)))
                for key, value in assemble_coframe(reg, original_coframe_blocks(reg, alpha, links)).entries:
                    out[key] = out.get(key, Polynomial()) + weight * value
    return SparseMatrix(4 * reg.volume, tuple(sorted((k, v) for k, v in out.items() if v)))


@dataclass(frozen=True, slots=True)
class ExteriorPolynomial:
    """Bitmask exterior algebra over exact coefficient polynomials."""
    terms: tuple = ()

    def __post_init__(self):
        out = {}
        for key, value in self.terms:
            if type(key) is not int or key < 0:
                raise ValueError('nonnegative generator mask required')
            out[key] = out.get(key, Polynomial()) + value
        object.__setattr__(self, 'terms', tuple(sorted((k, v) for k, v in out.items() if v)))

    @classmethod
    def generator(cls, i):
        return cls(((1 << i, Polynomial.scalar(1)),))

    def __neg__(self):
        return ExteriorPolynomial(tuple((k, -v) for k, v in self.terms))

    def __add__(self, other):
        return ExteriorPolynomial(self.terms + other.terms)

    def __mul__(self, other):
        if not isinstance(other, ExteriorPolynomial):
            return ExteriorPolynomial(tuple((k, v * other) for k, v in self.terms))
        out = []
        for a, av in self.terms:
            for b, bv in other.terms:
                if a & b:
                    continue
                swaps = sum((b & ((1 << i) - 1)).bit_count() for i in range(a.bit_length()) if a & (1 << i))
                out.append((a | b, av * bv * (-1) ** swaps))
        return ExteriorPolynomial(tuple(out))


@dataclass(frozen=True, slots=True)
class LocalDegreeCertificate:
    center: tuple
    center_mask: int
    minimum_center_generators: int
    degree_bound: int
    checked_monomials: int
    production_authorized: bool = False

    def __post_init__(self):
        object.__setattr__(self, 'center', _freeze_label(self.center))

    def vanishes_above(self, degree):
        """Whether the tested power is strictly beyond the last allowed degree."""
        return degree > self.degree_bound


def local_degree_certificate(reg, center, coframes):
    reg.validate_site(center)
    mask = sum(1 << i for i, g in enumerate(reg.generator_order) if g[0] == center)
    minimum, checked = 8, 0
    for frame in coframes:
        for word, coefficient in frame.terms:
            if word.bit_length() > 8 * reg.volume or word.bit_count() != 2:
                raise ValueError('coframe must be homogeneous bilinear on regulator')
            n = (word & mask).bit_count()
            if n == 0:
                raise ValueError('noncentered frame has no center generator')
            minimum = min(minimum, n)
            checked += 1
    if not checked:
        raise ValueError('nonempty centered support required')
    return LocalDegreeCertificate(center, mask, minimum, min(4 * reg.volume, 8 // minimum), checked)


@dataclass(frozen=True, slots=True)
class StructuralCertificate:
    components: int
    block_increments: int
    scalar_slot_writes: int
    coframe_slots: int
    coordinate_terms: int
    dirac_slots: int
    dirac_row_populations: tuple
    independent_su2_factors: int

    def __post_init__(self):
        object.__setattr__(self, 'dirac_row_populations', tuple(self.dirac_row_populations))


def structural_certificate(reg):
    from src.core.formulas import original_coframe_blocks
    components = increments = writes = slots = terms = 0
    union = set()
    for x in reg.sites:
        for mu in range(4):
            for a in range(4):
                blocks = original_coframe_blocks(reg, (x, mu, a))
                components += 1
                increments += len(blocks)
                writes += sum(bool(v) for b in blocks for row in b.matrix for v in row)
                matrix = assemble_coframe(reg, blocks)
                slots += len(matrix.entries)
                terms += sum(len(v.terms) for _, v in matrix.entries)
                union.update(k for k, _ in matrix.entries)
    return StructuralCertificate(components, increments, writes, slots, terms, len(union),
                                 tuple(sum(i == row for i, _ in union) for row in range(4 * reg.volume)), 8 * reg.volume)


@dataclass(frozen=True, slots=True)
class DeterminantSupport:
    row_order: tuple
    column_order: tuple
    row_sign: int
    column_sign: int
    block_sizes: tuple
    layer_populations: tuple
    total_reachable_masks: int
    transitions_per_block: int
    transitions_all_blocks: int

    def __post_init__(self):
        for name in ('row_order', 'column_order', 'block_sizes', 'layer_populations'):
            object.__setattr__(self, name, tuple(getattr(self, name)))


def determinant_support(reg):
    """Signed four-block permutation and unsigned row-subset reachability.

    No determinant coefficient, Haar factorization or nonzero claim is made.
    A periodic torus is bipartite only when each extent is even.
    """
    if any(n % 2 for n in reg.extents):
        raise ValueError('periodic bipartite partition requires all even extents')
    groups = {}
    for parity, chirality in product(range(2), range(2)):
        groups[parity, chirality] = tuple(4 * reg.site_number(x) + i for x in reg.sites
                                        if sum(x) % 2 == parity for i in range(2 * chirality, 2 * chirality + 2))
    row_groups = ((0, 0), (1, 1), (0, 1), (1, 0))
    col_groups = ((1, 1), (0, 0), (1, 0), (0, 1))
    rows = sum((groups[g] for g in row_groups), ())
    cols = sum((groups[g] for g in col_groups), ())
    populations, edge_counts = [], []
    for rg, cg in zip(row_groups, col_groups):
        states, layers, transitions = {0}, [1], 0
        for row in groups[rg]:
            x = reg.sites[row // 4]
            neighbors = {reg.step(x, mu, direction)[0] for mu in range(4) for direction in (-1, 1)}
            choices = tuple(j for j, col in enumerate(groups[cg]) if reg.sites[col // 4] in neighbors)
            nxt = set()
            for mask in states:
                for j in choices:
                    if not mask & (1 << j):
                        transitions += 1
                        nxt.add(mask | (1 << j))
            states = nxt
            layers.append(len(states))
        populations.append(tuple(layers))
        edge_counts.append(transitions)
    if len(set(populations)) != 1:
        raise ValueError('directed block reachability differs; retain separate certificates')
    return DeterminantSupport(rows, cols, permutation_sign(rows), permutation_sign(cols),
                              tuple(len(groups[g]) for g in row_groups), populations[0], sum(populations[0]),
                              edge_counts[0], sum(edge_counts))


def recursive_size_bytes(value):
    """Unique live Python payload bytes, including nested dataclass slots/integers.

    Measures the supplied object graph, not RSS, allocator slack or future maps.
    Callers must additionally account for simultaneous inputs/outputs and resize.
    """
    seen = set()
    def visit(obj):
        if id(obj) in seen:
            return 0
        seen.add(id(obj))
        size = sys.getsizeof(obj)
        if isinstance(obj, dict):
            return size + sum(visit(k) + visit(v) for k, v in obj.items())
        if isinstance(obj, (tuple, list, set, frozenset)):
            return size + sum(visit(v) for v in obj)
        if is_dataclass(obj) and not isinstance(obj, type):
            return size + sum(visit(getattr(obj, f.name)) for f in fields(obj))
        return size
    return visit(value)
