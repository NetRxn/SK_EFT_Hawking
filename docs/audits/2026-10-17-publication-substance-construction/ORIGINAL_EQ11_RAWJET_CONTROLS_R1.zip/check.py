from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations_with_replacement, permutations
from random import Random
from src.vestigial import original_coefficients as source

rng=Random(3189)
num_fixtures=0
num_coefficients=0
nonzero_by_order=[0,0,0]
for n in range(5):
    for m in range(4):
        zero=(0,)*m
        keys=[()]+[(a,) for a in range(m)]+list(combinations_with_replacement(range(m),2))
        def exponent(key):
            return tuple(key.count(a) for a in range(m))
        def multiply(left,right):
            product=defaultdict(F)
            for i,x in left.items():
                for j,y in right.items():
                    key=tuple(a+b for a,b in zip(i,j))
                    if sum(key)<=2:
                        product[key]+=x*y
            return product
        for case in range(10):
            planes={k:{} for k in keys}
            for k in keys:
                for i in range(n):
                    for j in range(n):
                        if (case==0 and k==()) or (case==1 and k) or rng.randrange(3)==0:
                            continue
                        a=F(rng.randrange(-4,5),rng.randrange(1,5))
                        if a:
                            planes[k][i,j]=a
                if case==2 and n>=2:
                    for j in range(n):
                        planes[k].pop((1,j),None)
                        if (0,j) in planes[k]:
                            planes[k][1,j]=planes[k][0,j]
            def matrix(key):
                return source.SparseMatrix(n,tuple(planes[key].items()))
            # The raw oracle multiplies ordinary Taylor coefficients and uses
            # independent permutation signs. Diagonal raw slots correspond to 2!.
            expected=defaultdict(F)
            for pi in permutations(range(n)):
                inversions=sum(a>b for i,a in enumerate(pi) for b in pi[i+1:])
                product={zero:F((-1)**inversions)}
                for i,j in enumerate(pi):
                    entry={
                        exponent(k):planes[k][i,j]/(2 if len(k)==2 and k[0]==k[1] else 1)
                        for k in keys if (i,j) in planes[k]
                    }
                    product=multiply(product,entry)
                for k,v in product.items():
                    expected[k]+=v
            result=source.determinant_jet(matrix(()),tuple(matrix((a,)) for a in range(m)),
                        {k[::-1]:matrix(k) for k in keys if len(k)==2})
            assert result.indices()==tuple(keys)
            for k in keys:
                v=expected[exponent(k)]*(2 if len(k)==2 and k[0]==k[1] else 1)
                assert result.at(k)==source.Polynomial.scalar(v),(n,m,case,k,v,result.at(k))
                assert result.at(k[::-1])==source.Polynomial.scalar(v)
                num_coefficients+=1
                nonzero_by_order[len(k)]+=bool(v)
            num_fixtures+=1
print(dict(num_fixtures=num_fixtures, num_coefficients=num_coefficients, nonzero_by_order=nonzero_by_order))
