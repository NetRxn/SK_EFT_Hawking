from fractions import Fraction
from itertools import product
import json
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, QComplex, assemble_dirac

def gamma(a):
    pauli=(((0,1),(1,0)),((0,-1j),(1j,0)),((1,0),(0,-1)))
    q=[[-1j*x for x in row] for row in pauli[a]] if a<3 else ((1,0),(0,1))
    return tuple(tuple(q[i][j-2] if i<2<=j else complex(q[j][i-2]).conjugate() if j<2<=i else 0 for j in range(4)) for i in range(4))

def dag(a):
    return tuple(tuple(complex(a[j][i]).conjugate() for j in range(4)) for i in range(4))

def mul(a,b,i,j):
    return sum(a[i][k]*b[k][j] for k in range(4))

def signed(a,s):
    return tuple(tuple(s*x for x in row) for row in a)

def spin_link(k):
    values=(1,1j,-1,-1j)
    l,r=values[k%4],values[(k+1)%4]
    return tuple(tuple((l,l.conjugate(),r,r.conjugate())[i] if i==j else 0 for j in range(4)) for i in range(4))

def poly(z):
    return Polynomial.scalar(QComplex(Fraction(z.real),Fraction(z.imag)))

counts={'fixtures':0,'entries':0,'nonzero':0}
for dims, signs, convention in product(((1,1,1,1),(2,1,2,1),(3,2,1,1)),((1,1,1,1),(-1,1,-1,-1)),('source_C','metric_M')):
    reg=OriginalRegulator(dims,signs,convention)
    sites=list(product(*(range(d) for d in dims)))
    flat=[(x,i) for x in sites for i in range(4)]
    keys=list(product(sites,range(4)))
    u={key:spin_link(k) for k,key in enumerate(keys)}
    twists={(x,mu):signed(u[x,mu],signs[mu] if x[mu]==dims[mu]-1 else 1) for x,mu in keys}
    h={(x,mu,a):(s+3*mu+2*a)%11-5 for s,x in enumerate(sites) for mu,a in product(range(4),repeat=2)}
    actual=assemble_dirac(reg,h,{k:tuple(tuple(poly(z) for z in row) for row in v) for k,v in u.items()})
    hops=[]
    for (x,mu,a),w in h.items():
        f=tuple((v+1)%dims[j] if j==mu else v for j,v in enumerate(x))
        b=tuple((v-1)%dims[j] if j==mu else v for j,v in enumerate(x))
        g=gamma(a if convention=='source_C' else (3,0,1,2)[a])
        uf,ub=twists[x,mu],twists[b,mu]
        hops.extend(((x,f,w,g,dag(uf)),(f,x,-w,uf,g),(x,b,-w,g,ub),(b,x,w,dag(ub),g)))
    for i,(y,s) in enumerate(flat):
        for j,(z,t) in enumerate(flat):
            expected=sum(w*mul(a,b,s,t) for row,col,w,a,b in hops if row==y and col==z)/4
            assert actual.at(i,j)==poly(expected),(dims,signs,convention,i,j,expected)
            counts['entries']+=1
            counts['nonzero']+=bool(expected)
    counts['fixtures']+=1
print(json.dumps(counts))
