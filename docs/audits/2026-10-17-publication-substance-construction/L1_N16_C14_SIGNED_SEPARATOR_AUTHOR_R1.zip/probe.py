from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import product
import json, sys
from pathlib import Path

PRIOR = Path('/tmp/publication-n16-denominator-support-r1.VjgwoR')
sys.path.insert(0, str(PRIOR))
from preflight import REG, LINKS, RANK
from src.core.formulas import (
    original_action_factors, original_coframe_blocks, original_quaternion_haar_moment,
)
from src.vestigial.original_coefficients import (
    ExteriorPolynomial, Polynomial, QComplex, Symbol, assemble_coframe,
)

STATE_CAP = 8192
ATTEMPT_CAP = 2_000_000
SCALAR_PAYLOAD_BITS = 2048
CLOSED = {(REG.sites[i],0) for i in (0,8)}
POSITION = {g:i for i,g in enumerate(REG.generator_order)}
ATTEMPTS = Counter()
PEAK_ROWS = Counter()
PEAK_BITS = 0

def charge(phase, n=1):
    if ATTEMPTS.total()+n > ATTEMPT_CAP:
        raise RuntimeError(('prospective_attempts',phase,ATTEMPTS.total()+n,ATTEMPT_CAP))
    ATTEMPTS[phase] += n

def row_room(phase, n):
    if n > STATE_CAP:
        raise RuntimeError(('prospective_rows',phase,n,STATE_CAP))
    PEAK_ROWS[phase] = max(PEAK_ROWS[phase], n)

def payload(z):
    global PEAK_BITS
    bits = sum(x.bit_length() for x in z.storage)
    if bits > SCALAR_PAYLOAD_BITS:
        raise RuntimeError(('scalar_payload_bits',bits,SCALAR_PAYLOAD_BITS))
    PEAK_BITS = max(PEAK_BITS, bits)
    return z

def q(i,k):
    return Symbol('q',(REG.sites[i],0,'L',k))

def edge(x, mu):
    return (min(x, REG.step(x,mu)[0]),mu)

def trace_anchors(x, mu, nu):
    k,l = sorted(set(range(4))-{mu,nu})
    return ((x,k),(REG.step(x,k)[0],l),(REG.step(x,l)[0],k),(x,l))

def owner_specs(row):
    owners = []
    for x,mu,nu in row['planes']:
        x = REG.sites[x]
        dirs = tuple(d for d in (mu,nu) if edge(x,d)==(REG.sites[0],0))
        closed = tuple(a for a in trace_anchors(x,mu,nu) if a in CLOSED)
        if dirs or closed:
            owners.append((x,(mu,nu),dirs,closed))
    for i,n in enumerate(row['S4_occupations']):
        x = REG.sites[i]
        if edge(x,0)==(REG.sites[0],0):
            owners.extend((x,(0,1,2,3),(0,),()) for _ in range(n))
    return owners

def get_pattern(row):
    return tuple(sorted(Counter(i for i,_,_ in row['planes']).values()))

def edge_degrees(row):
    counts = Counter()
    for i,mu,nu in row['planes']:
        x = REG.sites[i]
        for a in ((x,mu),(x,nu),*trace_anchors(x,mu,nu)):
            counts[edge(*a)] += 1
    for x,n in zip(REG.sites,row['S4_occupations']):
        for mu in range(4):
            counts[edge(x,mu)] += n
    return counts

@lru_cache(None)
def raw_factors(site, axes):
    factors = [f for f in original_action_factors_cached(site)
               if len(f.components)==len(axes) and
               tuple(sorted(mu for _,mu,_ in f.components))==axes]
    for f in factors:
        if len(axes)==2:
            assert {edge(*a) for a in f.anchors} == {edge(*a) for a in trace_anchors(site,*axes)}
            for key,_ in f.coefficient.terms:
                assert Counter(s.index[:2] for s in key) == Counter(f.anchors)
        else:
            assert not f.anchors and all(not key for key,_ in f.coefficient.terms)
    return factors

@lru_cache(None)
def original_action_factors_cached(site):
    return original_action_factors(REG,site,LINKS)

@lru_cache(None)
def groups(site, axes):
    out = defaultdict(Polynomial)
    for f in raw_factors(site,axes):
        out[tuple(sorted(f.components))] += f.coefficient
    return [(k,v) for k,v in sorted(out.items()) if v]

@lru_cache(None)
def coframe(alpha):
    blocks = original_coframe_blocks(REG,alpha,LINKS)
    exterior = assemble_coframe(REG,blocks).to_exterior(REG)
    for _,p in exterior.terms:
        for key,_ in p.terms:
            assert len(key)==1 and edge(*key[0].index[:2])==edge(*alpha[:2])
    return exterior

@lru_cache(None)
def frame_options(alpha, required):
    out = []
    for mask,poly in coframe(alpha).terms:
        keys = [key for key,_ in poly.terms if required is None or key==(required,)]
        if keys:
            out.append((mask,keys[0]))
    return out

def trace_options(poly, closed_key):
    # Retain full exponents on closed anchors and fix the other exponents for this witness.
    return [key for key,_ in poly.terms if tuple(s for s in key if s.index[:2] in CLOSED)==closed_key][:1]

def find(specs, targets):
    def visit(index, used, history):
        if index==len(specs):
            return history
        site,axes,dirs,closed = specs[index]
        target_frames,target_trace = targets[index]
        assert tuple(sorted(target_frames))==dirs
        assert tuple(sorted(s.index[:2] for s in target_trace))==tuple(sorted(closed))
        for components, trace in groups(site,axes):
            charge('search_component')
            for trace_key in trace_options(trace, target_trace):
                options = [frame_options(a,target_frames.get(a[1])) for a in components]
                for frames in product(*options):
                    charge('search_frames')
                    mask = used
                    for word,_ in frames:
                        if mask & word:
                            break
                        mask |= word
                    else:
                        answer = visit(index+1,mask,history+[(components,frames,trace_key)])
                        if answer is not None:
                            return answer
        return None
    return visit(0,0,[])

def production(history):
    out = ExteriorPolynomial(((0,Polynomial.scalar(1)),))
    for components, frames, trace_key in history:
        coefficients = dict(groups(components[0][0],tuple(a[1] for a in components)))[components]
        trace = dict(coefficients.terms)[trace_key]
        value = ExteriorPolynomial(((0,Polynomial(((trace_key,trace),))),))
        for alpha,(mask,key) in zip(components,frames):
            charge('canonical_wedge')
            coeff = dict(dict(coframe(alpha).terms)[mask].terms)[key]
            value *= ExteriorPolynomial(((mask,Polynomial(((key,coeff),))),))
        out *= value
        row_room('canonical_output',sum(len(p.terms) for _,p in out.terms))
        for _,p in out.terms:
            for _,z in p.terms:
                payload(z)
    return out

def fpair(z):
    return (z.real,z.imag)

def times(z,w):
    a,b=z
    c,d=w
    return (a*c-b*d,a*d+b*c)

def add(z,w):
    return tuple(a+b for a,b in zip(z,w))

def raw_increment_options(alpha, mask, key):
    options = []
    for b in original_coframe_blocks(REG,alpha,LINKS):
        for i,row in enumerate(b.matrix):
            for j,poly in enumerate(row):
                bar = POSITION[(b.bar_site,'bar',i)]
                psi = POSITION[(b.psi_site,'psi',j)]
                if (1<<bar)|(1<<psi) != mask:
                    continue
                for k,z in poly.terms:
                    if key==k:
                        options.append(((bar,psi),tuple(b.weight*v for v in fpair(z))))
    return options

def raw_route(history):
    # Enumerate ordered orientations and literal ordered odd generators, then sign each full path.
    choices = []
    counts = []
    for components,frames,trace_key in history:
        restrictions = dict(zip(components,frames))
        axes = tuple(a[1] for a in components)
        options = []
        matching = present = 0
        for f in raw_factors(components[0][0],axes):
            if tuple(sorted(f.components)) != components:
                continue
            matching += 1
            z = dict(f.coefficient.terms).get(trace_key)
            if not z:
                continue
            present += 1
            for increments in product(*(raw_increment_options(a,*restrictions[a]) for a in f.components)):
                charge('raw_increment_paths')
                odd = []
                coeff = fpair(z)
                for word,w in increments:
                    odd.extend(word)
                    coeff = times(coeff,w)
                row_room('raw_operand_options',len(options)+1)
                options.append((tuple(odd),coeff))
        counts.append(dict(matching_orientations=matching,present_orientations=present,increment_paths=len(options)))
        choices.append(options)
    coeff = (Fraction(),Fraction())
    output_mask = None
    for path in product(*choices):
        charge('raw_complete_paths')
        word = sum((p[0] for p in path),())
        if len(set(word)) != len(word):
            continue
        mask = sum(1<<i for i in word)
        if output_mask is not None:
            assert output_mask == mask
        output_mask = mask
        z = (Fraction(1),Fraction())
        for _,w in path:
            z = times(z,w)
        inversions = sum(left>right for i,left in enumerate(word) for right in word[i+1:])
        coeff = add(coeff,z if inversions%2==0 else tuple(-v for v in z))
        payload(QComplex(*coeff))
    return output_mask,coeff,counts

def exponent_blocks(key, aliased=False):
    blocks = defaultdict(lambda:[0]*4)
    for s in key:
        site,axis,hand,k = s.index
        if (site,axis) in CLOSED:
            blocks[(REG.sites[0] if aliased else site,axis,hand)][k] += 1
    return blocks

def haar(blocks, canonical):
    value = Fraction(1)
    for exponents in blocks.values():
        if canonical:
            value *= original_quaternion_haar_moment(exponents)
            continue
        if any(n%2 for n in exponents):
            return Fraction()
        num = den = 1
        for n in exponents:
            for i in range(1,n,2):
                num *= i
        for i in range(4,4+sum(exponents),2):
            den *= i
        value *= Fraction(num,den)
    return value

def translation_source_control():
    # Source comparator for a nonidentity translation crossing periodic boundaries.
    # The general proof uses equivariance of these same constructors for every vector.
    def site(x):
        return REG.step(x,0)[0]

    def anchor(a):
        return (site(a[0]), a[1])

    def component(a):
        return (site(a[0]), *a[1:])

    def polynomial(poly):
        return {
            tuple(sorted(Symbol(sym.family,(site(sym.index[0]),*sym.index[1:]))
                         for sym in key)): value
            for key,value in poly.terms
        }

    x = REG.sites[0]
    y = site(x)
    left, right = original_action_factors_cached(x), original_action_factors_cached(y)
    raw_count, trace_rows = 0, 0
    for a,b in zip(left,right,strict=True):
        assert a.t_degree == b.t_degree
        assert tuple(map(component,a.components))==b.components
        assert tuple(map(anchor,a.anchors))==b.anchors
        assert polynomial(a.coefficient)==dict(b.coefficient.terms)
        raw_count += 1
        trace_rows += len(a.coefficient.terms)
    block_count = 0
    for mu,a in product(range(4),repeat=2):
        left = original_coframe_blocks(REG,(x,mu,a),LINKS)
        right = original_coframe_blocks(REG,(y,mu,a),LINKS)
        for u,v in zip(left,right,strict=True):
            assert component(u.alpha)==v.alpha and anchor(u.anchor)==v.anchor
            assert site(u.bar_site)==v.bar_site and site(u.psi_site)==v.psi_site
            assert u.weight==v.weight
            for row,actual in zip(u.matrix,v.matrix,strict=True):
                assert tuple(polynomial(p) for p in row)==tuple(dict(p.terms) for p in actual)
            block_count += 1
    return dict(translation=REG.sites[8],raw_factors=raw_count,trace_rows=trace_rows,
                signed_quarter_blocks=block_count)

def run():
    rows = [json.loads(line) for line in (PRIOR/'c14-occupancy-roster.jsonl').read_text().splitlines()]
    reps = {}
    hist = defaultdict(Counter)
    survivors = []
    def ordered(r):
        return (r['planes'],r['S4_occupations'])
    for r in rows:
        pattern = get_pattern(r)
        odd = sum(n%2 for n in edge_degrees(r).values())
        hist[pattern][odd] += 1
        if odd==0:
            survivors.append(r)
            if pattern!=(4,):
                raise AssertionError(pattern)
        if (pattern!=(4,) or odd==0) and (pattern not in reps or ordered(r)<ordered(reps[pattern])):
            reps[pattern] = r
    orbits = Counter()
    for r in survivors:
        centers = {i for i,_,_ in r['planes']}
        assert len(centers)==1 and r['exponential_divisor']==512
        center, = centers
        orbit = tuple((a,b) for _,a,b in r['planes'])
        representative = next(v for v in survivors if tuple((i,a,b) for i,a,b in v['planes'])==tuple((0,a,b) for a,b in orbit))
        assert all(r['S4_occupations'][i^center]==n for i,n in enumerate(representative['S4_occupations']))
        orbits[orbit] += 1
    assert len(orbits)==3 and all(n==16 for n in orbits.values())
    controls = [
        ('distinct-even',(1,1,1,1), [({0:q(0,0)},()),({0:q(0,0)},())], Fraction(1,4)),
        ('distinct-reciprocal',(1,1,1,1), [({0:q(0,0)},()),({0:q(8,0)},())], Fraction()),
        ('paired-odd',(2,2), [({0:q(0,0)},())]*3, Fraction()),
        ('single-center-mixed',(4,),[({0:q(0,0)},())]*2+[({},(q(0,1),))]*2, Fraction(1,24)),
    ]
    results = {}
    for name,pattern,targets,expected in controls:
        row = reps[pattern]
        specs = owner_specs(row)
        assert len(specs)==len(targets),(name,specs)
        history = find(specs,targets)
        assert history is not None, (name,ATTEMPTS)
        canonical = production(history)
        ((mask,poly),) = canonical.terms
        ((key,z),) = poly.terms
        rawmask,rawz,counts = raw_route(history)
        assert mask==rawmask and fpair(z)==rawz and z
        blocks = exponent_blocks(key)
        weight = haar(blocks,True)
        assert weight == haar(blocks,False) == expected
        raw_keys = tuple(sorted(sum((tuple(k) for _,frames,t in history for _,k in frames),()) +
                                sum((tuple(t) for _,frames,t in history),())))
        assert raw_keys==key
        if name=='distinct-reciprocal':
            assert haar(exponent_blocks(key,aliased=True),False) == Fraction(1,4)
        results[name] = dict(roster=row, owner_specs=specs, selected=[dict(components=c,
            frames=[(m,[s.index for s in k]) for m,k in f],trace=[s.index for s in t])
            for c,f,t in history], exterior_mask=mask, signed_coefficient=z.storage,
            open_key=[s.index for s in key if s.index[:2] not in CLOSED],
            closed_blocks=[(a,b) for a,b in sorted(blocks.items())], Haar=str(weight),
            result=payload(z*weight).storage, raw_counts=counts,
            alias_Haar=str(haar(exponent_blocks(key,aliased=True),False)))
        print(name, 'passed', 'Haar',weight,'coefficient',z.storage,flush=True)
    degrees = {str(orbit): dict(sorted(Counter(edge_degrees(
        next(r for r in survivors if tuple(tuple(p) for p in r['planes'])==
             tuple((0,*axes) for axes in orbit))).values()).items())) for orbit in orbits}
    assert all(d=={2:24,4:8} for d in degrees.values())
    return dict(survivors=survivors, translation=translation_source_control(),
                edge_degree_histograms=degrees, histogram={str(k):dict(v) for k,v in sorted(hist.items())},
                orbits={str(k):n for k,n in sorted(orbits.items())}, results=results,
                attempts=dict(ATTEMPTS),peak_rows=dict(PEAK_ROWS),scalar_bits=PEAK_BITS,
                caps=dict(attempts=ATTEMPT_CAP,logical_rows_per_table=STATE_CAP,
                          scalar_storage_total_bits=SCALAR_PAYLOAD_BITS))

if __name__=='__main__':
    output = run()
    Path(__file__).with_name('result.json').write_text(json.dumps(output,indent=2)+'\n')
