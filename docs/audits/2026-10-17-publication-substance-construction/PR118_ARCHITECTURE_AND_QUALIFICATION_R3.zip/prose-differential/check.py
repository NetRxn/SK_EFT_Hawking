import json
from dataclasses import asdict
from validate import check_bundle_sentence_length,check_numerical_literals,check_count_literals,check_spelled_out_census_figures
print(json.dumps({c.__name__:asdict(c()) for c in [check_bundle_sentence_length,check_numerical_literals,check_count_literals,check_spelled_out_census_figures]},indent=2))
