import sys
from validate import check_architecture_inventory_fresh
r = check_architecture_inventory_fresh()
print(r)
assert r.measured and r.passed == (sys.argv[1] == "pass")
d = {item.name: item for item in r.details}
assert d["doc_refs_resolve"].passed == (sys.argv[1] != "before")
if sys.argv[1] == "unconfigured":
    assert "Hooks — 7" in d["inventory_fresh"].message and "Hooks — 6" in d["inventory_fresh"].message
