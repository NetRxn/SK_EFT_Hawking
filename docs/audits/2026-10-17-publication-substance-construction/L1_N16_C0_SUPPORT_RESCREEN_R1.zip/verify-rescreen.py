from pathlib import Path
from collections import Counter
base_list=[tuple(map(int,l.split())) for l in Path('accepted-base.tsv').read_text().splitlines()]
base=set(base_list)
assert len(base)==len(base_list)==9611 and sum(w for _,_,w in base)==827799
targets=set()
for line in Path('prior-classifications.tsv').read_text().splitlines()[1:]:
    a,b,w,t,*_=line.split()
    key=int(a),int(b),int(w)
    if t=='REFUSED' and key in base:
        targets.add(key)
assert len(targets)==3714 and sum(w for _,_,w in targets)==311139
seen=set()
counts=Counter()
weights=Counter()
supports=[]
for line in Path('reclassified.tsv').read_text().splitlines():
    a,b,w,t,n,s,spin,power=line.split()
    key=tuple(map(int,(a,b,w)))
    assert key in targets and key not in seen
    seen.add(key)
    n,s,spin,power=map(int,(n,s,spin,power))
    assert t in {'REFUSED','EXACT_SUPPORT'}
    if t=='REFUSED':
        assert n==8193 and s==spin==power==0
        category='still capped'
    else:
        assert 0<n<=8192
        supports.append(s)
        category='zero support' if not s else 'within baseline' if s<=152 and spin<=2 and power<=3 else 'outside baseline'
    counts[category]+=1
    weights[category]+=key[2]
assert seen==targets
for group in sorted(counts):
    print(group,counts[group],weights[group])
print('largest exact support count',max(supports))
