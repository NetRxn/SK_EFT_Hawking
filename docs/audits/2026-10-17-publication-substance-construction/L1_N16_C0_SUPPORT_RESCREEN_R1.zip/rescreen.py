from pathlib import Path
from collections import Counter
from time import monotonic

exec(Path('component.py').read_text())
CAP=8192
prior=Path('accepted-base.tsv')
base={tuple(map(int,l.split())) for l in prior.read_text().splitlines()}
assert len(base)==9611 and sum(w for _,_,w in base)==827799
census=Path('prior-classifications.tsv')
rows=[l.split() for l in census.read_text().splitlines()[1:]]
targets=[(int(a),int(b),int(w)) for a,b,w,t,*_ in rows
         if t=='REFUSED' and (int(a),int(b),int(w)) in base]
assert len(set(targets))==len(targets)==3714
counts=Counter()
weights=Counter()
start=monotonic()
with Path('reclassified.tsv').open('x') as f:
    for i,(a,b,w) in enumerate(targets,1):
        tag,nodes,support,spin,power,_=solve_pilot(a,b)
        category='cap' if tag=='REFUSED' else 'zero' if not support else 'within baseline' if support<=152 and spin<=2 and power<=3 else 'outside baseline'
        counts[category]+=1
        weights[category]+=w
        print(a,b,w,tag,nodes,support,spin,power,sep='\t',file=f)
        if i%50==0 or i==len(targets):
            f.flush()
            print(i,dict(counts),dict(weights),round(monotonic()-start,2),flush=True)
