# L1 support rescreen after the initial node-cap refusals

Run `python3 verify-rescreen.py` to reconcile every row with the accepted
predecessor and the 3,714 old refusals. The two accepted higher-degree
coefficients were already outside this target group. In a fresh copy, remove
reclassified.tsv and run `python3 rescreen.py preflight source .` to rerun
the exact count under the 8,192-node cap. The recurrence propagates the same
constraints, multiplies counts across disconnected unresolved variable
groups with fixed boundary values, and sums counts over disjoint choices
of the next variable. Maximal degree is carried over the surviving branches.

The benchmark repeats the previous 30,976-assignment dense control.
Coverage and routing totals describe support only. A positive count still
requires evaluation of signed contractions, and a cap refusal remains open.

The full control matched the exact count and maximal degrees for all 5,927
profiles whose original capped search finished. The complete rescreen
returned 3,357 exact counts and 357 refusals. Its largest exact support
contains 335,872 assignments. This scale indicates why counting support
alone does not qualify the existing per-assignment numerical route.
