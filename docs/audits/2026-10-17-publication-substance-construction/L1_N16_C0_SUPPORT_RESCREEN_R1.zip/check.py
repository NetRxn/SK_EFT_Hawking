from pathlib import Path
from time import monotonic
from collections import Counter

s=Path('component.py').read_text()
exec(s)
rows=[l.split() for l in Path('prior-classifications.tsv').read_text().splitlines()[1:]]
start=monotonic()
checked=0
for a,b,w,tag,n,support,spin,power in rows[::73]:
    if tag!='EXACT_SUPPORT':
        continue
    out=solve_pilot(int(a),int(b))
    assert out[0]=='EXACT_SUPPORT' and out[2:5]==tuple(map(int,(support,spin,power))),(a,b,out,support,spin,power)
    checked+=1
print('matched original exact count and maximal degrees',checked,'seconds',round(monotonic()-start,2),flush=True)
for cap in (1024,8192,65536):
    CAP=cap
    start=monotonic()
    out=solve_pilot(503841882182,1461451755920)
    print(cap,out,round(monotonic()-start,2),flush=True)
    if out[0]=='EXACT_SUPPORT':
        assert out[2:5]==(30976,2,2)
        break
