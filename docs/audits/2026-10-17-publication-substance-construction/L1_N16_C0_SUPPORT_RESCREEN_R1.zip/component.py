from collections import Counter, defaultdict, deque
from itertools import product
from functools import cache
from math import prod
from pathlib import Path
import sys

preflight, source, frozen = sys.argv[1:]
p=Path(preflight)/'parity-cost.py'
sys.argv=[sys.argv[0],source,frozen]
env={'__file__':str(p)}
exec(p.read_text().split('\npending=',1)[0],env)
projection,profile,decode=(env[k] for k in ('projection','profile','occupancy'))
filt=projection.__wrapped__.__globals__['filter_constraint']

CAP=1024

def solve_pilot(a,b):
    graphs,forced,domains=projection(a,b,2)
    constraints=[]
    loads=[profile(c)[2] for c in (a,b)]
    temporal=defaultdict(list)
    for t,graph in enumerate(graphs):
        for (u,v,k),(p,q) in graph.items():
            for x,m in ((u,p),(v,q)):
                if m:
                    for y in (u,v):
                        temporal[t,y].append((t,x,k))
    constraints.extend(('time',0,tuple(group)) for group in temporal.values())
    for e in graphs[0].keys()|graphs[1].keys():
        u,v,k=e
        group=tuple((t,x,k) for x in (u,v) for t in range(2))
        constraints.append(('space',min(sum(load.get(e,(0,0))) for load in loads),group))
        for side,load in enumerate(loads):
            d=sum(load.get(e,(0,0)))
            constraints.append(('parity',d%2,group))
            if not d:
                constraints.append(('equal',0,group[:2]))
                constraints.append(('equal',0,group[2:]))
    neighbors=defaultdict(set)
    for i,(_,_,group) in enumerate(constraints):
        for name in group:neighbors[name].add(i)
    checked=0
    def reduce(state,scope):
        active=set(scope)
        q=deque(scope); queued=set(q)
        while q:
            i=q.popleft(); queued.remove(i)
            kind,limit,group=constraints[i]
            old=tuple(state[k] for k in group)
            if kind in ('time','space'):
                new=filt(kind,limit,old)
            else:
                choices=[
                    labels for labels in product(*old)
                    if (labels[0]==labels[1] if kind=='equal' else sum(p+q for p,q in labels)%2==limit)
                ]
                new=tuple(tuple(sorted(set(col))) for col in zip(*choices)) if choices else ()
            if not new or not all(new):return False
            for k,prev,after in zip(group,old,new):
                if prev==after:continue
                state[k]=after
                for j in sorted((neighbors[k]&active)-queued-{i}):
                    q.append(j);queued.add(j)
        return True
    @cache
    def solve(items,scope):
        nonlocal checked
        checked+=1
        if checked>CAP:
            raise RuntimeError('candidate node limit')
        state=dict(items)
        if not reduce(state,scope):
            return 0,0
        unresolved={k for k,v in state.items() if len(v)>1}
        fixed=max((max(v[0]) for v in state.values() if len(v)==1),default=0)
        if not unresolved:
            return 1,fixed
        live={i:set(constraints[i][2]) & unresolved for i in scope}
        live={i:group for i,group in live.items() if group}
        todo=set(unresolved)
        components=[]
        while todo:
            component={min(todo)}
            pending=list(component)
            while pending:
                k=pending.pop()
                for i in neighbors[k]:
                    new=live.get(i,set())-component
                    component.update(new)
                    pending.extend(new)
            todo-=component
            components.append(component)
        if len(components)>1:
            total=1
            maximum=fixed
            for group in components:
                ids=tuple(i for i,members in live.items() if members&group)
                names=group.union(*(set(constraints[i][2]) for i in ids))
                size,spin=solve(tuple((k,state[k]) for k in sorted(names)),ids)
                if not size:
                    return 0,0
                total*=size
                maximum=max(maximum,spin)
            return total,maximum
        key=min(unresolved,key=lambda k:(len(state[k]),-len(neighbors[k]),k))
        total=maximum=0
        for value in state[key]:
            trial=state|{key:(value,)}
            size,spin=solve(tuple(sorted(trial.items())),tuple(live))
            total+=size
            maximum=max(maximum,spin)
        return total,maximum

    try:
        total,maxspin=solve(tuple(sorted(domains.items())),tuple(range(len(constraints))))
    except RuntimeError as error:
        if str(error)!='candidate node limit':
            raise
        return ('REFUSED',checked,0,0,0,tuple(forced))
    maxpower=max(n for code in (a,b) for row in decode(code) for n in row)
    return ('EXACT_SUPPORT',checked,total,maxspin,maxpower,tuple(forced))
