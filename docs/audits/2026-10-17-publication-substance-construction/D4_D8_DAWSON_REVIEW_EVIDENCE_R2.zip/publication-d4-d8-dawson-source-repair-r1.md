# D4/D8 Dawson–Nielsen source repair

Author candidate on MAIN `e0551708938a2c4303892bc7f0ae9fb67670480c`. The revised assignment starts at SAME and the final check reports the expected `owned-files` and `source` staleness. HEAD and the semantic index digest match the baseline. Exact repository source changes are the ten rows with different hashes below. R1 had six nonexistent unqualified Lean paths. ROOT reissued R2 naming their actual FKLW paths before any edit.

## Primary-source attribution

The held full Dawson–Nielsen author preprint is quant-ph/0505030v2, 23 August 2005, SHA256 `4cd7033be2dd4265b228ff0a834d07715558b398b8fa16d8365392638fd4ea7e`. The published article's 2006 citation remains the existing bibliographic identity. I read the actual held preprint's page 1 and pp. 6–11 with `pdftotext -layout` and the complete independent adjudication.

Section 3 (Analysis), Eqs. (1)–(7), gives order-3/2 error contraction at sufficiently small base error, fivefold sequence-length growth and three recursive calls with pointer reuse of inverse subsequences. Printed p. 7 distinguishes Eq. (8), gate-sequence length with exponent `log 5/log(3/2) ≈ 3.97`, from Eq. (9), classical runtime with exponent `log 3/log(3/2) ≈ 2.71` under pointer reuse and with finite-precision arithmetic costs excluded. The source says an implementation without reuse instead scales as 3.97 in both measures. Section 5.1, printed p. 11, extends the exponents to fixed dimension with dimension-dependent constants and base approximation lookup construction cost.

D4 replaces the obsolete abstract-only TODO with direct primary attribution and distinguishes output length from runtime. D8 names the same primary source and both locators, retains Selinger and KMM, and states the depth asymptotic with the bounded offset that absorbs fixed base constants and integer rounding. The D8 bibliography already identifies the published article and its preprint, so the manuscript specifies the held version in the locator. The SU(2) auxiliary level-length and SU(d) actual emitted-word passages and theorem statements are outside the edit. The seven Lean files and the roadmap now use accurate locators. The touched comments that called 3/2 super-quadratic now use order 3/2 or superlinear.

## Scope and byte evidence

The lexer read the original and proposed UTF-8 bytes for every assigned Lean module. It walked nested /- … -/ comments and line comments, handled escaped ordinary string/character literals and quoted identifiers, and rejected unsupported literal patterns. It compared the complete ordered list of between-comment byte chunks, preserving whitespace, plus the full delimiter/kind sequence. Length-prefix framing records the identical chunk hashes without erasing boundaries. Each changed comment occupies a standalone block in the diff. No import, declaration, theorem, identifier, token, layout outside comments, proof body or numerical constant changed.

| Owned path | Before SHA256 | After SHA256 |
| --- | --- | --- |
| `docs/roadmaps/Phase6y_Roadmap.md` | `8ee7de0158e6b069c26c0f6ebcb5a8cd477a0512a69fb1f53d48d02d93133619` | `90556a2e7705ddeb0a27ad88251bc51354b98355be6a7d2a23e35799ebef3959` |
| `lean/SKEFTHawking/FKLW/CliffordCCZSU8Calibration.lean` | `840a26b1a1ff3d0bc212ca0b771dbe790afcdaa591e44ceb8f6585385a5e3057` | `38d399b5962a95314d9014cfb5d0ed49ade5850f1670bf963e7cd528a6ee3ee2` |
| `lean/SKEFTHawking/FKLW/GenericSUdHeadlineForm.lean` | `2193947bf3cbd2fe1bead71e9b2f1a6353832ab513866c3cbf0208e8d3e683eb` | `556134b9862856588c854640fa1e602abb07feaf9548f8095b0acca95ad6309a` |
| `lean/SKEFTHawking/FKLW/GenericSUdSKCompileBounds.lean` | `5d14b0e2a68ad04ab306efdeb4e76c1354dd9971ed8989eb94e607bbf0db4cc7` | `c36033bfb7af9d50678b08daa8c5238c9d76b1a9620d85ca806a2707101ec571` |
| `lean/SKEFTHawking/FKLW/GenericSUdSkHeadlineCascade2IngredientFinal.lean` | `0a5f5cc0dd9276bccace32f2bc5cc46ba361669bad7f5f3f4870f5ac94e32d7d` | `8a4ede7e5a44343a5efadb7f98fefdc104fa1357f29ee4b00481cf46610dcd64` |
| `lean/SKEFTHawking/FKLW/GenericSUdSkLengthExponent.lean` | `b363ef02110e9dfb6615e19959455d7eba78954e79bdd223e6e17d63a9fe59fa` | `3bcfbc925ab0d51429a8bc4c0e6ab46db3e3660a19e7ec17dfe4092a722611c4` |
| `lean/SKEFTHawking/FKLW/SolovayKitaevLengthBound.lean` | `a0382998322f36d8427fb59afeccd9d3ad520392e6a49db3b81b2749c4237750` | `604e249445e7e94579e42707586519b6b5fa07d45ee6bddc652c18a9b2bbfda4` |
| `lean/SKEFTHawking/FKLW/TrappedIonSU4Calibration.lean` | `32fc3ef3915b87a2692f8fe7506695dfcc7cfbf3057a398880ff55b980841262` | `0147240a8f2351729f433817094fcb93e08c4abbb9953d62f375e833655514bc` |
| `papers/D4/paper_draft.tex` | `13e4f2b18d9e720f8a63c733af69e83dafab07795a3e2a8dff1e8325a0498aa8` | `44fd81d9bcaa9605d8a093153c2df08cf36c092af9a9c2590b8037a28e1c988d` |
| `papers/D8/bibliography.bib` | `709d0a92da6689ca54e331c18c6e0758582f07512fa9293e586b8e6f784dd4ab` | `709d0a92da6689ca54e331c18c6e0758582f07512fa9293e586b8e6f784dd4ab` |
| `papers/D8/paper_draft.tex` | `f9244c5c8e575ea0385ccb5de70419776445c1c4fb9e1027a8a355bc09411892` | `62f9ee7d15d16b21713491e560fd004cf2130152bb66ebfd1420726f18315d78` |

The [complete unified diff](./publication-d4-d8-dawson-source-repair-r1.diff) and [machine-readable evidence](./publication-d4-d8-dawson-source-repair-r1.json) include the exact candidate scope. The JSON records the unchanged registry, Lean catalog and adjudicated formal dependencies, visualization producer, figure, historical findings, bundle metadata, ledger, source PDF and authority hashes. The full source-tree scan found the stale locator and original invalid grep only in the historical D8 finding record. No notebook or packet was refreshed.

## Proposed D8 1.4 Verify

The original historical line remains verbatim in its finding document.

```text
- **Verify:** `grep -c "Dawson-Nielsen exponent\|Dawson & Nielsen" lean/SKEFTHawking/FKLW/GenericSUdSkLengthExponent.lean` (currently non-zero at the ≈3.97 attribution site)
```

A correct Dawson–Nielsen attribution can satisfy that grep. For ROOT's replacement or refiling decision, the [single shell command](./publication-d4-d8-dawson-source-repair-r1.verify-proposed.command.txt) runs from the selected repository and resolves the held primary corpus through the canonical workspace resolver. The [readable Python proposal](./publication-d4-d8-dawson-source-repair-r1.verify-proposed.py) checks the full PDF SHA and cover identity, registry identity and separate length/runtime notes, both canonical real exponent literals, the current corrected locators and manuscript attributions, the D4 TODO removal, and alignment of the D8 Fig. 3 caption and producer on the word-length exponent. A mismatch exits nonzero. The script syntax was parsed without execution. This deterministic control covers attribution propagation. Independent semantic inspection supplies the source adjudication and compiled review.

D4 2.2 and D8 1.4 still require fresh independent review and ROOT's authorized closure decision. D8 1.8, the Fig. 3 schematic wording/constant and the D4 plotted precision regime remain separate. The author pass ran no historical or proposed scientific Verify, figure producer, compilation, Lean kernel or LSP, test suite, cache operation, network operation or publication gate.
