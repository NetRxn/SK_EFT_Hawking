# D4/D8 Dawson–Nielsen author revision R2

Revised the frozen candidate in response to the independent composition review. The D8 paragraph now says the theorem and per-alphabet instantiations use the same length exponent. It names the trapped-ion and Clifford+CCZ calibration aliases as consumers of the canonical SU(d) definition. The Lean docstrings also acknowledge that some headlines spell out the real logarithm ratio. Definitional equality applies to the two named SU(2) and SU(d) length exponent definitions. The level chooser uses their common denominator to set recursion depth.

Only D8 manuscript prose and comments in `GenericSUdSkLengthExponent.lean` changed in R2. Prior source attribution, fixed-d scope, separate runtime, and D4 TODO removal are preserved. All seven Lean modules have exactly the same ordered between-comment bytes and comment delimiters as Git HEAD. A nested-comment-aware scanner preserved literal boundaries and checked exact whitespace and code chunks before computing length-framed hashes. `git diff --check` passed for the full author scope.

## Portable attribution check

The [proposed single shell command](./publication-d4-d8-dawson-revision-r2.verify-proposed.command.txt) uses the standard library's `runpy.run_path` to load the existing workspace resolver without package initialization. It requires Python 3, Git, Poppler `pdftotext`, and the held pinned source. The [readable script](./publication-d4-d8-dawson-revision-r2.verify-proposed.py) checks the held artifact, registry, manuscript and formal-source anchors, and obsolete locator removal. Its assertions establish those deterministic invariants. Independent semantic and rendered review still assess complete claims and figure evidence.

I ran the identical command under a clean shell with PATH `/opt/homebrew/bin:/usr/bin:/bin`, without venv or inherited Python settings. The candidate [passed with exit 0](./publication-d4-d8-dawson-revision-r2.verify-positive.txt). A temporary `git archive` export of HEAD `e0551708938a2c4303892bc7f0ae9fb67670480c` failed [with exit 1 for the obsolete Dawson §3.3 locator](./publication-d4-d8-dawson-revision-r2.verify-negative-head.txt). The export used the same read-only Git common directory to locate the held source and was removed afterward. Both runs emitted a Git temp-directory fallback warning under the clean environment.

## Continuity and scope

The initial canonical check was SAME. Final staleness is expected and limited to the two R2 changes. HEAD, semantic index, status digest, previously dirty path set and authority hashes are identical to the R2 input packet. The full ten-path candidate and hashes are captured in the [complete diff](./publication-d4-d8-dawson-revision-r2.diff) and [evidence JSON](./publication-d4-d8-dawson-revision-r2.json).

| Owned path | Git HEAD SHA256 | R1 candidate SHA256 | R2 candidate SHA256 |
| --- | --- | --- | --- |
| `docs/roadmaps/Phase6y_Roadmap.md` | `8ee7de0158e6b069c26c0f6ebcb5a8cd477a0512a69fb1f53d48d02d93133619` | `90556a2e7705ddeb0a27ad88251bc51354b98355be6a7d2a23e35799ebef3959` | `90556a2e7705ddeb0a27ad88251bc51354b98355be6a7d2a23e35799ebef3959` |
| `lean/SKEFTHawking/FKLW/CliffordCCZSU8Calibration.lean` | `840a26b1a1ff3d0bc212ca0b771dbe790afcdaa591e44ceb8f6585385a5e3057` | `38d399b5962a95314d9014cfb5d0ed49ade5850f1670bf963e7cd528a6ee3ee2` | `38d399b5962a95314d9014cfb5d0ed49ade5850f1670bf963e7cd528a6ee3ee2` |
| `lean/SKEFTHawking/FKLW/GenericSUdHeadlineForm.lean` | `2193947bf3cbd2fe1bead71e9b2f1a6353832ab513866c3cbf0208e8d3e683eb` | `556134b9862856588c854640fa1e602abb07feaf9548f8095b0acca95ad6309a` | `556134b9862856588c854640fa1e602abb07feaf9548f8095b0acca95ad6309a` |
| `lean/SKEFTHawking/FKLW/GenericSUdSKCompileBounds.lean` | `5d14b0e2a68ad04ab306efdeb4e76c1354dd9971ed8989eb94e607bbf0db4cc7` | `c36033bfb7af9d50678b08daa8c5238c9d76b1a9620d85ca806a2707101ec571` | `c36033bfb7af9d50678b08daa8c5238c9d76b1a9620d85ca806a2707101ec571` |
| `lean/SKEFTHawking/FKLW/GenericSUdSkHeadlineCascade2IngredientFinal.lean` | `0a5f5cc0dd9276bccace32f2bc5cc46ba361669bad7f5f3f4870f5ac94e32d7d` | `8a4ede7e5a44343a5efadb7f98fefdc104fa1357f29ee4b00481cf46610dcd64` | `8a4ede7e5a44343a5efadb7f98fefdc104fa1357f29ee4b00481cf46610dcd64` |
| `lean/SKEFTHawking/FKLW/GenericSUdSkLengthExponent.lean` | `b363ef02110e9dfb6615e19959455d7eba78954e79bdd223e6e17d63a9fe59fa` | `3bcfbc925ab0d51429a8bc4c0e6ab46db3e3660a19e7ec17dfe4092a722611c4` | `85d3c42035e49228e78bdc9f4899d21dd7aa712c9f647ad35694cf29a84840cc` |
| `lean/SKEFTHawking/FKLW/SolovayKitaevLengthBound.lean` | `a0382998322f36d8427fb59afeccd9d3ad520392e6a49db3b81b2749c4237750` | `604e249445e7e94579e42707586519b6b5fa07d45ee6bddc652c18a9b2bbfda4` | `604e249445e7e94579e42707586519b6b5fa07d45ee6bddc652c18a9b2bbfda4` |
| `lean/SKEFTHawking/FKLW/TrappedIonSU4Calibration.lean` | `32fc3ef3915b87a2692f8fe7506695dfcc7cfbf3057a398880ff55b980841262` | `0147240a8f2351729f433817094fcb93e08c4abbb9953d62f375e833655514bc` | `0147240a8f2351729f433817094fcb93e08c4abbb9953d62f375e833655514bc` |
| `papers/D4/paper_draft.tex` | `13e4f2b18d9e720f8a63c733af69e83dafab07795a3e2a8dff1e8325a0498aa8` | `44fd81d9bcaa9605d8a093153c2df08cf36c092af9a9c2590b8037a28e1c988d` | `44fd81d9bcaa9605d8a093153c2df08cf36c092af9a9c2590b8037a28e1c988d` |
| `papers/D8/paper_draft.tex` | `f9244c5c8e575ea0385ccb5de70419776445c1c4fb9e1027a8a355bc09411892` | `62f9ee7d15d16b21713491e560fd004cf2130152bb66ebfd1420726f18315d78` | `26e9d142e1d5760b0dc918a5879e166f707a4cd2d6a8d383f911aa122725ea18` |

The original findings and Verify lines are historical evidence. This revision did not alter them or the supersession ledger. Finding authority, fresh independent review, compilation and closure remain with ROOT. D8 finding 1.8 and the schematic figure work remain separate.
