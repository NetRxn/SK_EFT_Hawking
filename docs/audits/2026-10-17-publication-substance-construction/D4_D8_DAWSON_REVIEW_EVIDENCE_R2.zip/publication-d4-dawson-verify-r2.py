from hashlib import sha256
from pathlib import Path
from runpy import run_path
from subprocess import check_output

common_dir = Path(check_output(
    ["git", "rev-parse", "--path-format=absolute", "--git-common-dir"],
    text=True,
).strip())
find_workspace = run_path("src/core/workspace.py")["find_workspace"]
pdf = find_workspace(common_dir.parent) / (
    "Lit-Search/Phase-1-and-Background/primary-sources/DawsonNielsen2006.pdf"
)
expected = "4cd7033be2dd4265b228ff0a834d07715558b398b8fa16d8365392638fd4ea7e"
if not pdf.is_file() or sha256(pdf.read_bytes()).hexdigest() != expected:
    raise SystemExit("Held Dawson–Nielsen v2 PDF is missing or differs from the reviewed source.")
print("Held Dawson–Nielsen v2 PDF matches the independently reviewed full source.")
