from collections import Counter
from hashlib import file_digest
from pathlib import Path
import pickle

source=Path('fold25/row-cap-physical-slice-dense-branch.pkl')
with source.open('rb') as stream:
    digest=file_digest(stream,'sha256').hexdigest()
    stream.seek(0)
    state=pickle.load(stream)
assert digest=='277b2bfb002805a7736cd9a27375853fcf9e68f19feae4b3c445a08ec0b8e3e8'
i,j=state['rejected_pair']
assert (i,j)==(2,5)
A,X,_=state['factors'][i]
B,Y,_=state['factors'][j]
shared=tuple(w for w in A if w in B)
def counts(scope,rows):
    columns=tuple(scope.index(w) for w in shared)
    return Counter(tuple(row[k] for k in columns) for row in rows)
hx,hy=counts(A,X),counts(B,Y)
support={key:hx[key]*hy[key] for key in hx.keys()&hy.keys()}
assert sum(support.values())==state['matched']==2734080
bins=[]
oversized=[]
for key,n in sorted(support.items(),key=lambda item:(-item[1],item[0])):
    if n>500_000:
        oversized.append((key,n,hx[key],hy[key]))
        continue
    slot=next((v for v in bins if v[0]+n<=500_000),None)
    if slot is None:
        bins.append([n,[key]])
    else:
        slot[0]+=n
        slot[1].append(key)
assert sum(n for n,_ in bins)+sum(item[1] for item in oversized)==state['matched']
print('operand SHA256',digest)
print('pair',i,j,'product total',state['matched'],'shared dimension',shared)
print('complete support count',len(support),'bounded blocks',len(bins),'oversized tuples',len(oversized))
for i,(n,keys) in enumerate(bins):
    print('block',i,'maximum rows',n,repr(keys))
for key,n,ni,nj in oversized:
    print('requires row shard',key,n,ni,nj)
