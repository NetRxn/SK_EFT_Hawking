from collections import Counter,defaultdict
from hashlib import file_digest
from math import prod
from pathlib import Path
import pickle
import sys

blocks=((81,88,193,200),(7,13,49,52,82,194),(11,14,50,56,84,196))
forecasts=(443520,374208,374208)
source=Path(sys.argv[1])
index=int(sys.argv[2])
with source.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='c9d0191ff8ab5addc47b539ef935ea6a509406f2a29e7b16c8eaa34c95301a08'
    stream.seek(0)
    state=pickle.load(stream)
factors=state['factors']
i,j=state['rejected_pair']
assert (i,j)==(2,6) and len(factors)==18
axis=('G',0,6,0)
degree=Counter(w for a,_,_ in factors for w in a)
assert all(n==2 for n in degree.values())
assert tuple(k for k,(a,_,_) in enumerate(factors) if axis in a)==(i,j)
A,X,d=factors[i]
B,Y,e=factors[j]
shared=tuple(w for w in A if w in B)
assert axis in shared
a=tuple(A.index(w) for w in shared)
b=tuple(B.index(w) for w in shared)
ap=tuple(k for k,w in enumerate(A) if w not in shared)
bp=tuple(k for k,w in enumerate(B) if w not in shared)
project=lambda row,cols: tuple(row[k] for k in cols)
rows=Counter()
hist=Counter(project(row,b) for row in Y)
for row in X:
    count=hist[project(row,a)]
    if count:
        rows[row[A.index(axis)]]+=count
assert len(set().union(*map(set,blocks)))==sum(map(len,blocks))==len(rows)
assert set(rows)==set().union(*map(set,blocks))
assert [sum(rows[k] for k in block) for block in blocks]==list(forecasts)
assert sum(rows.values())==state['matched']==1191936
selected=set(blocks[index])
R=defaultdict(list)
for row,v in Y.items():
    if row[B.index(axis)] in selected:
        R[project(row,b)].append((project(row,bp),v))
out={}
products=0
for row,(x,y) in X.items():
    if row[A.index(axis)] not in selected:
        continue
    prefix=project(row,ap)
    for suffix,(u,v) in R.get(project(row,a),()):
        products+=1
        key=prefix+suffix
        re,im=out.get(key,(0,0))
        updated=re+x*u-y*v,im+x*v+y*u
        if any(updated):
            out[key]=updated
        else:
            out.pop(key,None)
        assert len(out)<=500_000
assert products==forecasts[index]
axes=tuple(A[k] for k in ap)+tuple(B[k] for k in bp)
remaining=[f for k,f in enumerate(factors) if k not in (i,j)]
remaining.append((axes,out,d*e))
assert prod(f[2] for f in remaining)==prod(f[2] for f in factors)
assert all(n==2 for n in Counter(w for a,_,_ in remaining for w in a).values())
print('reconstructed roster',sorted(rows.items()),flush=True)
print('forced exact join',index,blocks[index],products,'output rows',len(out),'factors',len(remaining),flush=True)
with Path('dense-saturated-frontier.pkl').open('xb') as stream:
    pickle.dump(dict(factors=remaining,used_before=state['used_before']+products,
                     physical_cut=(state['physical_cut'],(axis,blocks[index]))),stream,protocol=5)
