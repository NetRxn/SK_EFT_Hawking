from pathlib import Path
import resource,subprocess,sys,time
started=time.monotonic()
with Path('contraction.out').open('xb') as out,Path('contraction.err').open('xb') as err:
    try:
        status=subprocess.run([sys.executable,'-B','../contract-slice.py'],
                              stdout=out,stderr=err,timeout=120).returncode
    except subprocess.TimeoutExpired:
        status=124
elapsed=time.monotonic()-started
rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
receipt=f'child_status {status}\nelapsed_seconds {elapsed:.6f}\npeak_child_rss_bytes {rss}\n'
Path('contraction.receipt').write_text(receipt)
print(receipt,end='')
print(Path('contraction.out').read_text().splitlines()[-1],flush=True)
assert status in (0,2,124),status
