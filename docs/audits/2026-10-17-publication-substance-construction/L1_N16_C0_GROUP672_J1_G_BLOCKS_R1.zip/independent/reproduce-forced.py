from collections import Counter,defaultdict
from hashlib import file_digest
from math import prod
from pathlib import Path
from pickle import dump,load
from time import perf_counter
from sys import argv

PARENT=Path('/private/tmp/l1-group672-original-label.dAv5G8/j1/row-cap-physical-slice-dense-branch.pkl')
HASH='c9d0191ff8ab5addc47b539ef935ea6a509406f2a29e7b16c8eaa34c95301a08'
DEN=576173855599322741762003196268511232
PAIR=(2,6)
WIRE=('G',0,6,0)
GROUPS=((81,88,193,200),(7,13,49,52,82,194),(11,14,50,56,84,196))
WORK=(443520,374208,374208)

def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()
def entry(path):
    with path.open('rb') as stream:
        return load(stream)

def pair_parts(i,j,left,right):
    common=tuple(sorted(set(left)&set(right)))
    a=tuple(left.index(x) for x in common)
    b=tuple(right.index(x) for x in common)
    v=tuple(k for k,w in enumerate(left) if w not in common)
    w=tuple(k for k,x in enumerate(right) if x not in common)
    return common,a,b,v,w

def project(row,positions):
    return tuple(row[k] for k in positions)

def verify_parent(st):
    fs=st['factors']
    assert len(fs)==18 and st['rejected_pair']==PAIR and st['matched']==1191936
    assert st['used_before']==4788816 and sum(len(r) for _,r,_ in fs)>500000
    assert st['physical_cut'][1]==(('J',1,1,2),(1,))
    assert st['physical_cut'][0][1]==((1,0),(1,0),(1,0),(0,1),(0,1),(1,0),(0,1),(0,1),(0,1),(0,1),(0,1),(0,1))
    counts=Counter(x for ws,_,_ in fs for x in ws)
    assert set(counts.values())=={2} and all(w[0]!='L' for w in counts)
    assert prod(d for _,_,d in fs)==DEN
    i,j=PAIR
    (S,A,da),(T,B,db)=fs[i],fs[j]
    scope,li,ri,_,_=pair_parts(i,j,S,T)
    p=scope.index(WIRE)
    first,second=(Counter(project(k,n) for k in rows) for rows,n in ((A,li),(B,ri)))
    hist=Counter()
    for key,count in first.items():
        if second[key]:
            hist[key[p]]+=count*second[key]
    assert sorted(value for group in GROUPS for value in group)==sorted(hist)
    assert tuple(sum(hist[k] for k in group) for group in GROUPS)==WORK
    assert sum(WORK)==st['matched']
    print('verified complete parent 16-value support',sorted(hist.items()),'matched',sum(hist.values()),flush=True)
    print('parent stored rows',sum(len(r) for _,r,_ in fs),'physical wires',len(counts),'fixed denominator',DEN,flush=True)
    return hist

def replay_block(st,n):
    started=perf_counter()
    fs=st['factors']
    i,j=PAIR
    (S,A,da),(T,B,db)=fs[i],fs[j]
    common,li,ri,v,w=pair_parts(i,j,S,T)
    ll,rr=S.index(WIRE),T.index(WIRE)
    p,q=set(GROUPS[n]),set(GROUPS[n])
    index=defaultdict(list)
    kept_a=kept_b=0
    for key,value in A.items():
        if key[ll] in p:
            index[project(key,li)].append((project(key,v),value))
            kept_a+=1
    out={}
    count=0
    for key,(c,d) in B.items():
        if key[rr] not in q: continue
        kept_b+=1
        right=project(key,w)
        for left,(a,b) in index.get(project(key,ri),()):
            target=left+right
            x,y=out.get(target,(0,0))
            z=x+a*c-b*d,y+a*d+b*c
            if any(z):
                out[target]=z
            else:
                out.pop(target,None)
            count+=1
    assert count==WORK[n] and 0<len(out)<=count<500000
    new=tuple(S[k] for k in v)+tuple(T[k] for k in w)
    assert WIRE not in new and not set(common)&set(new)
    output=[f for k,f in enumerate(fs) if k not in PAIR]+[(new,out,da*db)]
    assert len(output)==17
    assert set(Counter(w for ws,_,_ in output for w in ws).values())=={2}
    assert prod(d for _,_,d in output)==DEN
    print('forced block',n,'values',GROUPS[n],'selected rows',kept_a,kept_b,'matched products',count,
          'joined rows',len(out),'row peak upper bound',WORK[n],'joined axes',len(new),'joined denominator',da*db,
          'seconds',f'{perf_counter()-started:.6f}',flush=True)
    with Path(f'independent-forced-{n}.pkl').open('xb') as file:
        dump({'factors':output,'joint_block':GROUPS[n],'use_counts':count},file,protocol=5)
    print('independent block output sha256',n,sha(Path(f'independent-forced-{n}.pkl')),flush=True)

if __name__=='__main__':
    assert sha(PARENT)==HASH
    st=entry(PARENT)
    verify_parent(st)
    chosen=tuple(map(int,argv[1:])) or (0,1,2)
    for i in chosen:
        replay_block(st,i)
