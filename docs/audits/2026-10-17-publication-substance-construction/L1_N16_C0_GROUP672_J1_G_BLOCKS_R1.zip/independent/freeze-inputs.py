from hashlib import file_digest
from pathlib import Path
from shutil import copyfile

ROOT=Path('/private/tmp/l1-group672-g-blocks.qQMlwN')
anc=Path('/private/tmp/l1-group672-original-label.dAv5G8/j1')
items=['prepare.py','contract-slice.py','contract-with-join-cap.py','run.py','run-with-join-cap.py',
       'residual0-quotient.py','residual0-quotient.out','resumable-fold-2-5.pkl','resumable-fold-5-13.pkl']
for stage in ('block0','resume0','resume1','resume2','fold25'):
    path=ROOT/stage
    kind=sorted(path.iterdir())
    items.extend(str(p.relative_to(ROOT)) for p in kind if p.is_file())
with Path('input-operands.sha256').open('w') as manifest:
    for p in [ROOT/name for name in sorted(set(items))]+[anc/'row-cap-physical-slice-dense-branch.pkl']:
        with p.open('rb') as f:
            print(file_digest(f,'sha256').hexdigest(),p,sep='  ',file=manifest)
        if p.is_relative_to(ROOT) and p.suffix!='.pkl':
            local=Path('author-receipts')/p.relative_to(ROOT)
            local.parent.mkdir(parents=True,exist_ok=True)
            copyfile(p,local)
