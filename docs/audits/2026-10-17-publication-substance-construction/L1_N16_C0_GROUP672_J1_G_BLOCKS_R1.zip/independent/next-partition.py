from collections import Counter
from math import prod
from pathlib import Path
from re import fullmatch
from runpy import run_path

q=run_path('reproduce-forced.py')
entry,sha,DEN=(q[k] for k in ('entry','sha','DEN'))
home=Path('/private/tmp/l1-group672-g-blocks.qQMlwN')
author=home/'fold25'
receipt=(author/'contraction.receipt').read_text()
r=fullmatch(r'child_status (\d+)\nelapsed_seconds (\S+)\npeak_child_rss_bytes (\d+)\n',receipt)
assert (int(r[1]),float(r[2]),int(r[3]))==(2,18.193552,1414643712)
assert (author/'contraction.err').read_bytes()==b''
original=home/'resumable-fold-2-5.pkl'
assert sha(original)=='3ac148209a94939a4852b5cc799ae39975e37d69ec0267c43bbed488a75c68a5'
assert sha(author/'dense-saturated-frontier.pkl')==sha(original)
prior=entry(original)
output=author/'row-cap-physical-slice-dense-branch.pkl'
cap=entry(output)
assert cap['physical_cut']==prior['physical_cut'] and prior['used_before']==7277904
assert cap['used_before']==0 and cap['matched']==2734080 and cap['rejected_pair']==(2,5)
assert (author/'contraction.out').read_text().splitlines()[-2:]==[
    'quotient before join 16 2734080 2734080 slices 0',
    'open row cap 16 2734080 frontier saved']
assert cap['factors']==prior['factors']
factors=cap['factors']
assert len(factors)==16 and prod(d for _,_,d in factors)==DEN
print('PASS preserved fold row cap matches every independently checked folded input factor table')
print('selected fold rows',sum(len(r) for _,r,_ in factors),'status',r[1],'seconds',r[2],'peak bytes',r[3],
      'new cap sha256',sha(output))
i,j=cap['rejected_pair']
(a,A,_),(b,B,_)=factors[i],factors[j]
shared=tuple(w for w in a if w in b)
ascope=tuple(a.index(w) for w in shared)
bscope=tuple(b.index(w) for w in shared)
left=Counter(tuple(row[u] for u in ascope) for row in A)
right=Counter(tuple(row[u] for u in bscope) for row in B)
allats=left.keys()&right.keys()
weights={k:left[k]*right[k] for k in allats}
assert sum(weights.values())==2734080
assert len(weights)==12
print('quotient representative axes',shared,'atom forecasts',sorted(weights.items()))
budget=500000
heavy=[(key,work) for key,work in sorted(weights.items()) if work>budget]
assert len(heavy)==2
print('two full-tuple fibers exceed output bound',heavy)
# Partition a single factor linearly, assigning all right matches of a left row
# to the same part. Rows without a matching right atom make exactly zero.
eligible=[(row,z,right[tuple(row[k] for k in ascope)]) for row,z in sorted(A.items())
          if right[tuple(row[k] for k in ascope)]]
assert sum(n for _,_,n in eligible)==cap['matched']
blocks=[]
lo=0
acc=0
for i,(_,_,amount) in enumerate(eligible):
    assert 0<amount<=budget
    if acc+amount>budget:
        blocks.append((lo,i,acc))
        lo,acc=i,0
    acc+=amount
if acc:
    blocks.append((lo,len(eligible),acc))
assert len(blocks)==6
assert blocks[0][0]==0 and blocks[-1][1]==len(eligible)
assert all(left[1]==right[0] for left,right in zip(blocks,blocks[1:]))
assert sum(r[2] for r in blocks)==cap['matched']
from hashlib import sha256
from pickle import dumps
with Path('next-row-blocks.tsv').open('w') as ds:
    print('block','lo','high_exclusive','compatible_rows','matched_product_upper_bound','selected_rows_sha256',sep='\t',file=ds)
    for n,(low,high,count) in enumerate(blocks):
        digest=sha256(dumps(tuple((row,z) for row,z,_ in eligible[low:high]),protocol=5)).hexdigest()
        print(n,low,high,high-low,count,digest,sep='\t',file=ds)
        print('deterministic next left-row block',n,'interval',low,high,'first output rows upper bound',count,'selection SHA256',digest)
print('proved disjoint linear partition',len(blocks),'eligible left rows',len(eligible),
      'exact zero unmatched left rows',len(A)-len(eligible),'product sum',sum(c for _,_,c in blocks),
      'maximum',max(row[2] for row in blocks))
