from hashlib import sha256
from io import BytesIO
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile

p=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
commit='e0040b1522feb13ef39ec7ce905b35306e804362'
name='docs/audits/2026-10-17-publication-substance-construction/L1_N16_C0_GROUP672_ORIGINAL_LABEL_ROUTE_R1.zip'
def git(*args):
    return check_output(['git','-C',str(p),*args])
raw=git('show',f'{commit}:{name}')
assert sha256(raw).hexdigest()=='f741ba648e81dd1d08ac348715c5e0dc50f985b7908a937bb00e42446c68f85a'
assert raw==(p/name).read_bytes()
assert git('rev-parse',f'{commit}:{name}')==git('rev-parse',f'HEAD:{name}')
print('published archive',commit,git('rev-parse',f'{commit}:{name}').decode().strip(),sha256(raw).hexdigest())
with ZipFile(BytesIO(raw)) as z:
    fingerprint='c9d0191ff8ab5addc47b539ef935ea6a509406f2a29e7b16c8eaa34c95301a08'
    stage=Path('/private/tmp/l1-group672-original-label.dAv5G8/j1/row-cap-physical-slice-dense-branch.pkl')
    source=z.read('independent/input-operands.sha256').decode().splitlines()
    assert f'{fingerprint}  {stage}' in source
    assert sha256(stage.read_bytes()).hexdigest()==fingerprint
    print('published J1 cap',fingerprint,stage)
    line=z.read('independent/verify-j-status.out').decode()
    assert fingerprint in line and 'retained factors 18 cap projected products 1191936' in line
    for f in ('run.py','contraction.out','contraction.receipt','contract-slice.py'):
        assert z.read(f'author/j1/{f}')==(stage.parent/f).read_bytes()
        print('pinned J prior receipt',f)
    seen=z.read('independent/upstream-audit.out').decode()
    assert 'exact union covers W/G cases 260 out of 260 compatible local pair products 3563808 out of 3563808' in seen
    print('complete prior W/G coverage preserved at input boundary')
