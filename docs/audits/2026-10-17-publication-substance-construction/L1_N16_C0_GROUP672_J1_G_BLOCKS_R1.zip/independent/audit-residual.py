from collections import Counter
from itertools import combinations
from math import prod
from pathlib import Path
from re import fullmatch,search
from runpy import run_path
from sys import argv
from time import perf_counter

defs=run_path('reproduce-forced.py')
entry,sha,PARENT,HASH,DEN,WORK,GROUPS,WIRE=(defs[x] for x in ('entry','sha','PARENT','HASH','DEN','WORK','GROUPS','WIRE'))
ROOT=Path('/private/tmp/l1-group672-g-blocks.qQMlwN')
assert sha(PARENT)==HASH
parent=entry(PARENT)

def hist(a,x,scope):
    idx=tuple(a.index(k) for k in scope)
    return Counter(tuple(row[i] for i in idx) for row in x)

def forecasts(factors):
    found=[]
    for i,j in combinations(range(len(factors)),2):
        a,A,_=factors[i]
        b,B,_=factors[j]
        if shared:=tuple(w for w in a if w in b):
            x=hist(a,A,shared)
            y=hist(b,B,shared)
            candidates=sum(x[k]*y[k] for k in x.keys()&y.keys())
            found.append((candidates,i,j,len(set(a)^set(b)),len(shared),len(x.keys()&y.keys())))
    return sorted(found)

def verify(n,path):
    start=perf_counter()
    initial=entry(path/'dense-saturated-frontier.pkl')
    hist=entry(Path(f'independent-forced-{n}.pkl'))
    assert initial['factors']==hist['factors']
    assert initial['physical_cut']==(parent['physical_cut'],(WIRE,GROUPS[n]))
    assert initial['used_before']==parent['used_before']+WORK[n]
    logs=(path/'contraction.out').read_text().splitlines()
    elapsed=(path/'contraction.receipt').read_text()
    receipt=fullmatch(r'child_status (\d+)\nelapsed_seconds (\S+)\npeak_child_rss_bytes (\d+)\n',elapsed)
    assert receipt is not None
    status,seconds,rss=int(receipt[1]),float(receipt[2]),int(receipt[3])
    assert '(\'G\', 0, 6, 0)' in logs[0] and str(GROUPS[n]) in logs[0]
    assert f'factors 17 prior matched work {initial["used_before"]}' in logs[0]
    phases=[tuple(map(int,fullmatch(r'join (\d+) (\d+) (\d+) axes (\d+)',row).groups()))
            for row in logs if row.startswith('join ')]
    completed=sum(p[1] for p in phases)
    print('block',n,'directory',path.name,'status',status,'seconds',seconds,'peak child RSS bytes',rss,
          'completed joins',phases,'completed products this run',completed)
    if status==2:
        assert (path/'contraction.err').read_bytes()==b''
        assert [p[0] for p in phases]==list(range(16,16-len(phases),-1))
        if logs[-1].startswith('open join cap'):
            file=path/'join-cap-physical-slice-dense-branch.pkl'
            residual=entry(file)
            assert residual['completed_this_run']==completed
            assert residual['used_before']==initial['used_before']+completed
            assert residual['refusal']=='no eligible join within 8000000 per join and 40000000 total'
            message=f'open join cap {17-len(phases)} completed products {completed} frontier saved'
        else:
            file=path/'row-cap-physical-slice-dense-branch.pkl'
            residual=entry(file)
            assert residual['used_before']==completed
            message=f'open row cap {17-len(phases)} {residual["matched"]} frontier saved'
        assert message==logs[-1]
        assert len(residual['factors'])==17-len(phases)
        assert residual['physical_cut']==initial['physical_cut']
        assert set(Counter(a for scope,_,_ in residual['factors'] for a in scope).values())=={2}
        assert prod(d for _,_,d in residual['factors'])==DEN
        print('exact preserved residual scope',n,sha(file),len(residual['factors']),
              'remaining rows',sum(len(r) for _,r,_ in residual['factors']),'denominator',DEN,flush=True)
        candidates=forecasts(residual['factors'])
        if file.name.startswith('join'):
            assert len(candidates)>0
            assert all(projected>8000000 or completed+projected>40000000 for projected,*_ in candidates)
            print('independent admission guard',n,len(candidates),'linked pairs, smallest forecasts',
                  candidates[:8],flush=True)
        else:
            i,j=residual['rejected_pair']
            one,=[r[0] for r in candidates if r[1:3]==(i,j)]
            assert one==residual['matched']
            print('independent refused row-cap forecast',n,(i,j),one,flush=True)
    elif status==1:
        err=(path/'contraction.err').read_text()
        assert "AssertionError: ('no admitted join'" in err
        assert not list(path.glob('*cap-*.pkl'))
        print('original failure retained',n,'status 1, pass-boundary arithmetic without a serialized residual')
    elif status==124:
        print('bounded timeout retains the independently reconstructed 17-factor input',n)
    elif status==0:
        assert search(r'^exact normalized (-?\d+(?:/\d+)?) ',logs[-1])
        print('author exact scalar requires separately independent terminal arithmetic',n,logs[-1])
    else:
        raise AssertionError(status)
    print('independent audit seconds',n,f'{perf_counter()-start:.6f}',flush=True)

if __name__=='__main__':
    for item in argv[1:]:
        n,name=item.split(':')
        verify(int(n),ROOT/name)
