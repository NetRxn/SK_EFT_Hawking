from pathlib import Path
from runpy import run_path
from time import perf_counter
from sys import argv

engine=run_path('reproduce-forced.py')
get=lambda key: engine[key]
root=Path('/private/tmp/l1-group672-g-blocks.qQMlwN')
read=get('entry')
sha=get('sha')
parent=read(get('PARENT'))
assert sha(get('PARENT'))==get('HASH')

print('block','products','input_rows','factors','joined_denominator','joined_rows','sha256','wall_seconds',sep='\t')
for item in argv[1:] or ['0:resume0','1:resume1','2:resume2']:
    n,folder=item.split(':')
    n=int(n)
    tick=perf_counter()
    path=root/f'{folder}/dense-saturated-frontier.pkl'
    independently=read(Path(f'independent-forced-{n}.pkl'))
    author=read(path)
    expected=independently['factors']
    actual=author['factors']
    assert len(expected)==len(actual)==17
    assert expected==actual
    assert author['physical_cut']==(parent['physical_cut'],(get('WIRE'),get('GROUPS')[n]))
    assert author['used_before']==parent['used_before']+get('WORK')[n]==parent['used_before']+independently['use_counts']
    assert len(actual[-1][1])==get('WORK')[n]
    den=actual[-1][2]
    assert den==2304
    print(n,get('WORK')[n],sum(len(r) for _,r,_ in actual),len(actual),den,len(actual[-1][1]),sha(path),f'{perf_counter()-tick:.6f}',sep='\t',flush=True)
