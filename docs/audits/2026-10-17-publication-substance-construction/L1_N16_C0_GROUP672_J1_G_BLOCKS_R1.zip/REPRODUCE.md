# L1 group 672 assignment 7 J=(1,) G blocks and exact quotient

The three disjoint G(0,6,0) blocks completely cover the specified J child. Each reaches a saved 16-factor join cap. A signed quotient reduces the first block's refused pair to a smaller row-capped operand. The J scalar and whole-group scalar remain open.

Restore the reviewed J=(1,) 18-factor parent from L1_N16_C0_GROUP672_ORIGINAL_LABEL_ROUTE_R1.zip and its associated input archives. Check the parent SHA256 pinned in prepare.py. Run that script for each block in a fresh directory. It applies the complete weighted roster and forces the specified pair join using exact Gaussian integer arithmetic.

The initial block0 run exercises the older assertion on no admitted pair. Keep that failure evidence. Run the revised contract-with-join-cap.py through run-with-join-cap.py for each prepared block, using unchanged arithmetic and limits. The revised no-join branch preserves exact factors, scope and completed work as a restart. Match the saved output hashes against operands.sha256. Timing and peak child RSS are observations on the author host.

From a scratch reproduction of author/, run residual0-quotient.py on the saved first block's join cap. It evaluates a quotient that coalesces proportional slices and transfers their exact Gaussian factors to the other tensor. Check the resulting 2,734,080-product input against the recorded hash and run it as fold25/dense-saturated-frontier.pkl. The existing row cap applies. Re-run fold25-block-plan.py at its frozen row cap to check the complete next shared-tuple partition and identify the two tuples exceeding the single-join row ceiling. The independent next-row-blocks.tsv gives an exhaustive six-interval alternative over the left rows. These forecasts cover the next pair.

Verify manifest.sha256 and the independent portable manifest. Use the independent report and scripts to check operand provenance, inverse lifts, pair weights, exact quotient and all recorded scopes.
