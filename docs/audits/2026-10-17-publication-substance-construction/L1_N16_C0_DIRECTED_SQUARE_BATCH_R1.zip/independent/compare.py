import ast
from fractions import Fraction as F
import json
from pathlib import Path
import re

def rows(path):
    return [tuple(map(int,l.split())) for l in Path(path).read_text().splitlines()]

old=rows('INDEPENDENT/block-remaining.tsv')
pilot=(37086699520,8935831015554,48)
residual=rows('accepted-pilot-residual.tsv')
assert [r for r in old if r!=pilot]==residual
assert len(residual)==10457 and sum(r[2] for r in residual)==903771
prefix=Path('frozen/family-intake')
roster=json.loads((prefix/'directed-roster.json').read_text())
author=[l.split() for l in (prefix/'author-exact.tsv').read_text().splitlines()]
assert len(author)==len(roster)==6
a_channels={}
a_limits=[]
for idx,c in enumerate(roster):
    a,b=c['ids']
    key=(a,b,c['weight'])
    assert key==tuple(map(int,author[idx][:3]))
    assert (key in residual)==bool(idx)
    out=(prefix/f'case-{idx}.out').read_text()
    assert F(out.splitlines()[-1].split()[-1])==F(author[idx][-1])
    chan=[eval(z,{'__builtins__':{},'Fraction':F}) for z in
          (f'({m[0]}, {m[1]}, {str(F(m[2]).as_integer_ratio())})' for m in
           re.findall(r'channel result \d (\(.*?\)) (\(.*?\)) scaled contribution (\S+)',out))]
    a_channels[key]=[(q,r,F(*z)) for q,r,z in chan]
    assert len(chan)==4
    if idx:
        a_limits.append((
            max(map(int,re.findall(r' site \d work (\d+)',out))),
            max(map(int,re.findall(r'populated rows (\d+)',out))),
            max(map(int,re.findall(r' matched (\d+) rows',out))),
            max(map(int,re.findall(r'triangle preflight (\d+)',out))),
            max(map(int,re.findall(r'resident input rows (\d+)',out))),
        ))
def validate(path):
    cases=[];exact={};key=None;params=[]
    for l in Path(path).read_text().splitlines():
        p=l.split()
        if l.startswith('case '):
            a,b,w,s=map(int,p[1:5])
            cycl,forced=re.fullmatch(r'(\[.*\]) (\(.*\))',' '.join(p[5:])).groups()
            cases.append(dict(ids=[a,b],weight=w,root_layer=s,cycle=ast.literal_eval(cycl),
                              forced_scalar_powers=list(ast.literal_eval(forced))))
            key=(a,b,w)
            chan=[]
        elif p[0] in ('0','1','2','3'):
            r,t=re.fullmatch(r'\d (\[.*\]) (\S+)',l).groups()
            x,y=eval(r,{'__builtins__':{},'Fraction':F})
            chan.append((x,y,F(t)))
        elif p[0]=='total':
            assert len(chan)==4 and chan==a_channels[key]
            assert key!=pilot and key in residual and key not in exact
            exact[key]=F(p[2])
            assert exact[key]==sum(t[2] for t in chan)
        elif p[0]=='layer':
            params.append(tuple(int(p[p.index(s)+1]) for s in ('peak','work')
                                )+(int(p[-4]),int(p[-1])))
    assert cases==roster
    print(path,'maximum factor/work/site/initial',*[max(x) for x in zip(*params)])
    return exact
ordinary=validate('independent.out')
reverse=validate('reverse.out')
assert ordinary==reverse and len(ordinary)==5
assert all(v>0 for v in ordinary.values())
left=[r for r in residual if r not in ordinary]
assert len(left)==10452 and sum(r[2] for r in left)==903531
print('frozen per-case maxima (site / factor / join / triangle / triangle input)',a_limits)
print('added',len(ordinary),'orbits',sum(r[2] for r in ordinary),'labels',sum(r[2]*v for r,v in ordinary.items()))
print('residual',len(left),sum(r[2] for r in left))
Path('reviewed-exact.tsv').write_text(''.join('\t'.join(map(str,(*r,v)))+'\n' for r,v in ordinary.items()))
