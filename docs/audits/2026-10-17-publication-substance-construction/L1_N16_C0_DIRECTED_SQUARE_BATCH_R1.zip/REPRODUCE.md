Use the author and independent inputs from the sibling
L1_N16_C0_DIRECTED_SQUARE_PILOT_R1.zip archive on this checkpoint branch.
Restore them using that archive's REPRODUCE.md. Put links in independent/
to the prior independent pilot's AUTHOR, INDEPENDENT, frozen, root.tsv and
spatial.tsv paths. The prior frozen author root requires the family-intake
directory from that same archive. Verify the manifest and run the commands
in independent/REVIEW.md. This archive subtracts exactly the five new
accepted rows from the pilot residual.
