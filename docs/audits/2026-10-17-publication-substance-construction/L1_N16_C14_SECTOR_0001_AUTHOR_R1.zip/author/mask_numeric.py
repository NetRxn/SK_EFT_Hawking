"""Numerically join previously preflighted exact mask half tables."""
from collections import defaultdict
from pathlib import Path
import json
import separate as g

D=Path(__file__).parent

def main():
    g.rss()
    left={tuple(k):[(tuple(key),v) for key,v in rows]
          for k,rows in g.read(D/'left-halves.jsonl')}
    right={}
    for k,rows in g.read(D/'right-halves.jsonl'):
        by=defaultdict(list)
        for key,v in rows:
            by[key[0]].append((tuple(key),v))
        right[tuple(k)]=by
    out={}
    visit=0
    for (r4,r12,r3,r10,r9,m1,m2),w in g.read(g.CORE/'coalesced-environment.jsonl'):
        g.charge('exact_environment_key')
        for (mask,a,b,f),v in left[r4,r12,r10,r9]:
            for (other,c,d,e),z in right[r3,m1,m2].get(255^mask,()):
                g.charge('exact_weighted_mask_product')
                visit+=1
                key=(a,b,c,d,e,f)
                if key not in out:
                    g.reserve('coalesced_mask_amplitude')
                val=g.mul(g.mul(v,z),g.mul(w,g.cross(mask,other)))
                out[key]=g.add(out.get(key,0),val)
    assert visit==3401216
    count=0
    with (D/'weighted-mask-amplitude-0001.jsonl').open('wb') as f:
        for k,z in sorted(out.items()):
            if z:
                g.charge('serialize_mask_amplitude')
                g.emit(f,[k,z])
                count+=1
    g.rss()
    result=dict(products=visit,nonzero_mask_keys=count,cancelled_mask_keys=len(out)-count,
        work=dict(g.OPS),meters=dict(g.M),caps=g.CAPS,sampled_peak_rss_bytes=g.RSS)
    (D/'mask-numeric.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':
    main()
