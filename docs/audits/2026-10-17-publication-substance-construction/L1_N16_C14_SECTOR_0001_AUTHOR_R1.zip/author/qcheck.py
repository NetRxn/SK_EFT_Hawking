"""Separately capped exact mixed original-ray control."""
from pathlib import Path
import json,sys
import qcontract as q

D=Path(__file__).parent

def main(skip):
    q.CAP=4_000_000
    raw,source=q.source()
    data=q.traces(source)
    amp={tuple(k):tuple(z) for k,z in q.read(D/'q-amplitudes-0001.jsonl')}
    allkeys=[tuple(k) for k,z in q.read(D/'weighted-mask-amplitude-0001.jsonl')]
    witness=q.direct_controls(raw,data,amp,allkeys,skip=skip,count=1,gross_cap=2_000_000)
    q.rss()
    out=dict(controls=witness,charged=q.TOTAL,operations=dict(q.WORK),
        cap=q.CAP,sampled_peak_rss_bytes=q.PEAK)
    (D/f'raw-control-{skip}.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main(int(sys.argv[1]))
