# Exact mixed LLLR sector of original N16 c14

The pinned authority is original periodic closed source_C at clean
primary 27012c18fa374e8341e124b510abbedeedb18d29. This is ordered
chirality sector 0001 of the zero-centered (01,01,23,23) row. It
fixes original occurrences 0, 1, 2 to L and occurrence 3 to R.
The integer coordinate labels inside this fixed sector are
renumbered 0–3 after the chirality filter. The original anchor
and trace-slot identities remain distinct. The exact signed
sector contribution is zero, including original normalization.
No other sector or orbit value is inferred here.

## Exact original factors and mask side

The eleven original partial signed joins from the frozen LLLL
schedule complete on the actual mixed source factors. The mixed
A, B and F factors each split into sixteen primitive signed
interior rays, while C, D and E each have eleven. The canonical
mask-half Cartesian route refused at work visit 4,000,001.
Indexing the A/F join by its actual shared mask and B by the
next mask gave an exact prospective count of 3,401,216 numeric
products. It did not fit combined with the preflight's work.
The two exact preflighted half tables are retained, and a
separate bounded numerical stage reads and combines them.

The admitted mask stage uses 3,765,980 charged visits under
4,000,000, with 1,728 accumulated keys. It retains 832 nonzero
weights and removes 896 exact zeros. The literal rank-zero
word controls preserve the original sign of all four mask
slots. The mask numerator gcd is factored exactly into the
final rational normalization.

## Mixed trace transform

The shared exact Gaussian bases reconstruct all 54 spoke
rays. Mixed A and B have left common rank ten and right
common rank sixteen. Their middle matrices have six terms.
The other two spokes retain the LLLL ten-by-ten bases.
The selected mixed contraction has 168,192 middle products
and requires 1,218 left and 1,792 right transformed entries.

The first 4M aggregate schedule refused before numerical
evaluation with a conservative 22,067,214-visit bound.
The successful exact stage used a prospectively declared
24,000,000 aggregate bound and deterministic disjoint
basis-tuple chunks, each prospectively under 4,000,000.
All actual and predicted chunk counts are frozen in
`q-result.json`. The six actual chunk counts are 2,616,992,
3,437,120, 3,442,240, 3,435,072, 3,447,168 and 852,928.
The total measured work including planning and combination
is 19,091,694. The sampled peak process RSS is 24,444,928
bytes against the sampled 384 MiB guard. The transform uses
checked normalized 127-bit arithmetic payload and tracks
the stated table and visit guards.

All 832 nonzero mask weights have individually zero exact
interior amplitude. Serialized readback reconstructs every
spoke matrix and independently accumulates all 168,192
middle products. There are 9,216 nonzero middle paths, which
cancel exactly. It confirms the empty nonzero amplitude
table and the zero sector sum.

Two independent original-spoke checks each traverse 1,982,464
products and find 169,984 nonzero signed paths. Both sum to
zero exactly. Reversing one recorded path changes them to
+2,097,152 and -2,097,152 in numerator units. Each check
uses 2,063,690 charged visits under its own prospectively
declared 4,000,000 cap. The source graph denominator, scalar
24^5 and external divisor 512 remain unchanged.

The masks, all mixed basis chunks, the adverse controls,
refused alternative schedules and reproducible coefficients
are frozen. This is the mixed 0001 sector only. The full
representative, other arrangement values, c14, c0, complete
denominator and normalization remain open.
