"""Check frozen signed exact LLLR sector composition and basis reconstruction."""
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
from itertools import product
import json

D=Path(__file__).parent
ZERO=(0,0)
def lines(p):
    with p.open() as f:
        for x in f:
            yield json.loads(x)
def add(x,y):
    return x[0]+y[0],x[1]+y[1]
def mul(x,y):
    a,b=x
    c,d=y
    return a*c-b*d,a*d+b*c
def dec(k):
    a,b,c,d=k
    return Fraction(a,b),Fraction(c,d)

raw={}
middle={}
for name,labels,tab in lines(D/'interior-rays.jsonl'):
    if name in 'ABCD':
        raw[name]={j:{tuple(k):tuple(v) for k,v in rows} for j,rows in tab}
for b in lines(D/'spoke-bases.jsonl'):
    name=b['name']
    middle[name]={int(j):[(i,k,dec(z)) for i,k,z in terms] for j,terms in b['coordinates'].items()}
    col=defaultdict(list)
    row=defaultdict(list)
    for i,k,z in b['column']:
        col[k].append((i,dec(z)))
    for k,j,z in b['row']:
        row[k].append((j,dec(z)))
    for j,terms in b['coordinates'].items():
        exact={}
        for i,k,z in terms:
            w=dec(z)
            for a,x in col[i]:
                for c,y in row[k]:
                    e,f=divmod(a,4)
                    g,h=divmod(c,4)
                    t=(g,h,e,f) if b['transposed'] else (e,f,g,h)
                    exact[t]=add(exact.get(t,ZERO),mul(mul(x,w),y))
        assert {k:z for k,z in exact.items() if z!=ZERO}==raw[name][int(j)]

m={tuple(k):v for k,v in lines(D/'weighted-mask-amplitude-0001.jsonl')}
q={tuple(k):tuple(v) for k,v in lines(D/'q-amplitudes-0001.jsonl')}
assert q.keys()<=m.keys()
trans=defaultdict(dict)
for side,k,z in lines(D/'selected-transforms.jsonl'):
    assert tuple(k) not in trans[side]
    trans[side][tuple(k)]=tuple(z)
term_count=0
live_terms=0
for k in m:
    a,b,c,d,e,f=k
    z=ZERO
    for terms in product(*(middle[n][j] for n,j in zip('ABCD',(a,b,c,d),strict=True))):
        term_count+=1
        u=trans['left'].get((e,*(i for i,j,w in terms)),ZERO)
        v=trans['right'].get((f,*(j for i,j,w in terms)),ZERO)
        if ZERO in (u,v):
            continue
        live_terms+=1
        val=mul(u,v)
        for _,_,w in terms:
            val=mul(val,w)
        z=add(z,val)
    assert z==q.get(k,ZERO)
result=json.loads((D/'q-result.json').read_text())
scalar=tuple(sum(m[k]*q[k][i] for k in q) for i in (0,1))
assert scalar==tuple(result['mask_numerator_gcd']*v for v in result['normalized_interior_scalar_numerator'])
scale=Fraction(result['external_s4_multiplier'],result['graph_denominator']*result['external_row_divisor'])
assert [str(v*scale) for v in scalar]==result['weighted_exact_sector_value']
print(json.dumps(dict(exact_spoke_rays_reconstructed=sum(map(len,raw.values())),
    complete_mask_keys=len(m),exact_middle_terms=term_count,nonzero_middle_paths=live_terms,
    exact_nonzero_amplitude_rows=len(q),signed_sector_value=result['weighted_exact_sector_value']),indent=2))
