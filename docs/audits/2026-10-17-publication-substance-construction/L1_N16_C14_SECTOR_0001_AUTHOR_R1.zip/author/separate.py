"""Exact interior ray split and bounded exterior-mask join for LLLR."""
from collections import Counter,defaultdict
from functools import cache
from itertools import product
from math import gcd
from pathlib import Path
import json,resource

D=Path(__file__).parent
CORE=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
CAPS=dict(work=4_000_000,rows=200_000,output=32*1024**2,
          sampled_rss=384*1024**2,integer=(1<<127)-1)
M=Counter()
OPS=Counter()
RSS=0
PARTIAL={
  'A':'(rank0_edge1+rank4_closure)',
  'B':'(rank8_edge0+(rank8_edge3+(rank8_edge2+partition_rank8)))',
  'C':'(rank0_edge2+merge_rank2)',
  'D':'(rank0_edge3+merge_rank1)',
  'E':'(rank3_edge3+(rank3_edge2+(rank3_compact+rank3_projection)))',
  'F':'(residual_edge+(rank8_edge1+rank12_closure))',
}
ZERO=(0,0)
class Refused(Exception):
    pass

def rss():
    global RSS
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    RSS=max(RSS,n)
    if n>CAPS['sampled_rss']:
        raise Refused(('sampled_rss',n,CAPS['sampled_rss']))

def charge(k):
    n=M['work']+1
    if n>CAPS['work']:
        raise Refused(('prospective_work',k,n,CAPS['work']))
    M['work']=n
    OPS[k]+=1
    if n%2048==0:
        rss()

def reserve(k):
    n=M['rows']+1
    if n>CAPS['rows']:
        raise Refused(('prospective_rows',k,n,CAPS['rows']))
    M['rows']=n

def emit(f,x):
    line=json.dumps(x,separators=(',',':')).encode('ascii')+b'\n'
    n=M['output']+len(line)
    if n>CAPS['output']:
        raise Refused(('prospective_output_bytes',n,CAPS['output']))
    M['output']=n
    f.write(line)

def add(x,y):
    lim=CAPS['integer']
    if (x>0 and y>0 and x>lim-y) or (x<0 and y<0 and x<-lim-y):
        raise Refused(('prospective_integer_sum',lim))
    return x+y

def mul(x,y):
    if y and abs(x)>CAPS['integer']//abs(y):
        raise Refused(('prospective_integer_product',CAPS['integer']))
    return x*y

def read(path):
    with path.open() as f:
        for line in f:
            charge('read_input')
            yield json.loads(line)

def cross(a,b):
    swaps=0
    while a:
        k=a&-a
        swaps+=(b&(k-1)).bit_count()
        a^=k
    return (-1)**swaps

def literal(seq):
    word=[i for mask in seq for i in range(8) if mask>>i&1]
    assert len(word)==len(set(word))
    return (-1)**sum(a>b for i,a in enumerate(word) for b in word[i+1:])

def ray_split():
    by_name={n:(k,v) for n,k,v in read(D/'frontier-0001-stop11.jsonl')}
    assert set(PARTIAL.values())<=set(by_name)
    rays={}
    masks={}
    outstats={}
    with (D/'interior-rays.jsonl').open('wb') as fr,(D/'mask-weights.jsonl').open('wb') as fm:
        for name,n in PARTIAL.items():
            labels,rows=by_name[n]
            # q and a labels are entirely interior, while ray_rank labels
            # and exterior masks belong to the original mask network.
            iq=[i for i,k in enumerate(labels) if k[0] in 'qa']
            im=[i for i,k in enumerate(labels) if k[0] not in 'qa']
            by=defaultdict(dict)
            for key,z in rows:
                charge('split_exact_partial_row')
                a=tuple(key[i] for i in im)
                b=tuple(key[i] for i in iq)
                assert b not in by[a]
                by[a][b]=tuple(z)
            qids={}
            mask={}
            for k,v in sorted(by.items()):
                scalar=gcd(*(a for z in v.values() for a in z))
                if next(a for z in sorted(v) for a in v[z] if a)<0:
                    scalar=-scalar
                q=tuple((p,tuple(x//scalar for x in z)) for p,z in sorted(v.items()))
                assert {k:tuple(mul(scalar,x) for x in z) for k,z in q}==v
                if q not in qids:
                    reserve('interior_ray')
                    qids[q]=len(qids)
                reserve('signed_mask_weight')
                mask[k]=(qids[q],scalar)
            outstats[name]=dict(exact_partial_rows=len(rows),mask_slices=len(by),signed_interior_rays=len(qids))
            assert qids
            rays[name]=([labels[i] for i in iq],{j:dict(q) for q,j in qids.items()})
            masks[name]=([labels[i] for i in im],mask)
            emit(fr,[name,rays[name][0],[[j,q] for q,j in qids.items()]])
            emit(fm,[name,masks[name][0],sorted(mask.items())])
        for i in range(4):
            n=f'trace{i}'
            labels,rows=by_name[n]
            emit(fr,[n,labels,rows])
    return rays,masks,outstats

def index(mask):
    def grouping(name,keys):
        labels,table=mask[name]
        ids=[labels.index(k) for k in keys]
        rest=[i for i in range(len(labels)) if i not in ids]
        out=defaultdict(list)
        for k,(r,z) in table.items():
            charge('index_mask_factor')
            x=tuple(k[i] for i in ids)
            reserve('mask_index_record')
            out[x].append((tuple(k[i] for i in rest),r,z))
        return out
    return (
      grouping('A',('ray_rank4',)),grouping('B',('ray_rank10','ray_rank9')),
      grouping('C',('remote2',)),grouping('D',('remote1',)),
      grouping('E',('ray_rank3',)),grouping('F',('ray_rank12',)),
    )

@cache
def left_seed(ray4,ray12):
    out=defaultdict(list)
    f=defaultdict(list)
    for (s4,s81),q,z in INDEX[5][ray12,]:
        charge('left_seed_F_index')
        f[s4].append((s81,q,z))
    for (m01,n4),a,x in INDEX[0][ray4,]:
        for s81,q,z in f[n4]:
            charge('left_seed_A_F')
            reserve('left_seed_row')
            out[s81].append((m01,a,q,mul(x,z)))
    return out

@cache
def left(ray4,ray12,ray10,ray9):
    out={}
    seed=left_seed(ray4,ray12)
    for (m00,m81),b,y in INDEX[1][ray10,ray9]:
        for m01,a,f,x in seed[m81]:
            charge('left_half_candidates')
            if m00&m01:
                continue
            mask=m00|m01
            k=(mask,a,b,f)
            sg=cross(m00,m01)
            assert sg==literal((m00,m01))
            if k not in out:
                reserve('left_half_coeff')
            out[k]=add(out.get(k,0),mul(sg,mul(x,y)))
    return {k:z for k,z in out.items() if z}

@cache
def right(ray3,r1,r2):
    out={}
    for ((m02,n2),c,x),((m03,n1),d,y),((s2,s1),e,z) in product(
            INDEX[2][r2,],INDEX[3][r1,],INDEX[4][ray3,]):
        charge('right_half_candidates')
        if n1!=s1 or n2!=s2 or m02&m03:
            continue
        mask=m02|m03
        k=(mask,c,d,e)
        sg=cross(m02,m03)
        assert sg==literal((m02,m03))
        if k not in out:
            reserve('right_half_coeff')
        out[k]=add(out.get(k,0),mul(sg,mul(x,mul(y,z))))
    return {k:z for k,z in out.items() if z}

def supported(l,r):
    by=defaultdict(list)
    for k,z in r.items():
        by[k[0]].append((k,z))
    for k,z in l.items():
        for j,w in by.get(255^k[0],()):
            yield k,z,j,w

def evaluate(env):
    n=0
    positive=0
    per=Counter()
    for (r4,r12,r3,r10,r9,m1,m2),w in env:
        charge('mask_environment_preflight')
        l=left(r4,r12,r10,r9)
        r=right(r3,m1,m2)
        count=sum(1 for _ in supported(l,r))
        n+=count
        if count:
            positive+=1
        per[count]+=1
    if M['work']+len(env)+n>CAPS['work']:
        return None,dict(kind='prospective_weighted_mask_join',previous=M['work'],
             exact_pair_visits=n,environment_visits=len(env),cap=CAPS['work'])
    out={}
    for (r4,r12,r3,r10,r9,m1,m2),w in env:
        charge('mask_environment_join')
        l=left(r4,r12,r10,r9)
        r=right(r3,m1,m2)
        for (ml,a,b,f),x,(mr,c,d,e),y in supported(l,r):
            charge('exact_weighted_mask_join')
            assert ml|mr==255 and ml&mr==0
            k=a,b,c,d,e,f
            if k not in out:
                reserve('mask_amplitude_output')
            val=mul(w,mul(x,mul(y,cross(ml,mr))))
            out[k]=add(out.get(k,0),val)
    return {k:z for k,z in out.items() if z},dict(exact_pair_visits=n,
        environment_rows_with_matching_mask_halves=positive,matched_pairs_histogram=dict(per))

def fixed_checks(env):
    controls=[]
    # Independent literal traversal: no half-cache signs or site unions.
    # Select actual fixed boundaries for which at least one half pair exists.
    for k,w in env:
        charge('propose_mask_control')
        r4,r12,r3,r10,r9,m1,m2=k
        l=left(r4,r12,r10,r9)
        r=right(r3,m1,m2)
        if not any(supported(l,r)):
            continue
        lefts=[]
        rights=[]
        for ((m01,n4),a,x),((m00,m81),b,y),((s4,s81),f,z) in product(
                INDEX[0][r4,],INDEX[1][r10,r9],INDEX[5][r12,]):
            charge('literal_mask_left')
            if n4==s4 and m81==s81 and not m00&m01:
                lefts.append(((m00,m01),(a,b,f),mul(x,mul(y,z))))
        for ((m02,n2),c,x),((m03,n1),d,y),((s2,s1),e,z) in product(
                INDEX[2][m2,],INDEX[3][m1,],INDEX[4][r3,]):
            charge('literal_mask_right')
            if n1==s1 and n2==s2 and not m02&m03:
                rights.append(((m02,m03),(c,d,e),mul(x,mul(y,z))))
        raw={}
        for ((m00,m01),(a,b,f),x),((m02,m03),(c,d,e),y) in product(lefts,rights):
            charge('literal_full_mask_control')
            if (m00|m01)&(m02|m03):
                continue
            assert m00|m01|m02|m03==255
            q=(a,b,c,d,e,f)
            sign=literal((m00,m01,m02,m03))
            raw[q]=add(raw.get(q,0),mul(sign,mul(x,y)))
        ref={}
        for (ml,a,b,f),x,(mr,c,d,e),y in supported(l,r):
            charge('factored_fixed_mask_control')
            q=(a,b,c,d,e,f)
            ref[q]=add(ref.get(q,0),mul(cross(ml,mr),mul(x,y)))
        assert {k:z for k,z in raw.items() if z}=={k:z for k,z in ref.items() if z}
        nonzero={k:z for k,z in raw.items() if z}
        if not nonzero:
            continue
        q=min(nonzero)
        controls.append(dict(boundary=k,complete_nonzero_interior_ray_rows=len(nonzero),
            selected_ray_key=q,mask_numerator=nonzero[q],
            wrong_top_orientation_numerator=-nonzero[q],environment_numerator=w))
        if len(controls)==4:
            return controls
    raise AssertionError('four fixed mask controls required')

def main():
    global INDEX
    rss()
    _,masks,stats=ray_split()
    INDEX=index(masks)
    env=[(tuple(k),z) for k,z in read(CORE/'coalesced-environment.jsonl')]
    out,measure=evaluate(env)
    controls=fixed_checks(env)
    if out is None:
        left_keys={tuple(k[i] for i in (0,1,3,4)) for k,w in env}
        right_keys={tuple(k[i] for i in (2,5,6)) for k,w in env}
        for side,keys,fn in (('left',left_keys,left),('right',right_keys,right)):
            with (D/f'{side}-halves.jsonl').open('wb') as f:
                for k in sorted(keys):
                    charge('freeze_half_boundary')
                    emit(f,[k,sorted(fn(*k).items())])
    if out is not None:
        with (D/'weighted-mask-amplitude-0001.jsonl').open('wb') as f:
            for k,z in sorted(out.items()):
                charge('serialize_mask_amplitude')
                emit(f,[k,z])
    rss()
    report=dict(sector='0001',ray_split=stats,mask_join=measure,
      exact_mask_amplitude_rows=None if out is None else len(out),
      half_cache=[left.cache_info().currsize,right.cache_info().currsize],
      fixed_controls=controls,work=dict(OPS),meters=dict(M),caps=CAPS,
      sampled_peak_rss_bytes=RSS,interior_q_amplitude_evaluated=False)
    (D/'separation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':
    main()
