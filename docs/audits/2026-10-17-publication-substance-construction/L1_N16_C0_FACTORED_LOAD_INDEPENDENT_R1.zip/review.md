# Independent original N16 pure-EHC factored load and signed face review

The pinned source is original periodic closed source_C at clean
primary 27012c18fa374e8341e124b510abbedeedb18d29. I verified the author
manifest and prior independent support manifest before replay.
All code and evidence here are scratch-only.

## Coarse support and prospective admission

For a fixed center total M, the local directional loads are
nonnegative integers with sum 2M and maximum at most M. These
conditions characterize the degree vectors of a loopless
four-vertex multigraph of M edges. Subtracting one from its two
largest positive degrees preserves the same conditions at M-1.
Each full top site gets 2M generators from its centered factors
and the remaining 8-2M from the opposite parity centers. The
incoming constraints consequently separate by bipartite side.

A separate C++ residual-capacity implementation with descending
source order reproduced the exact uniform M=2 counts. It has
1,354,811 load assignments and 4,738,011 occupation assignments
per side. The squared totals are 1,835,512,845,721 and
22,448,748,236,121. Each side has 130,688 completed syndrome
keys, with 130,304 in their intersection. The join gives
198,840,165 undirected-parity matches and **87,055,413** matches
after checking the actual split-anchor condition. It admits
113,712,264 descriptor bytes under the 128 MiB cap and measured
133,758,976 bytes peak process RSS. The descriptors use a compact
three-word signed-support record, with the second actual directed
parity reconstructed from the syndrome and first-directed parity.

Matching the two undirected syndromes supplies total evenness.
For a nonempty coframe edge, this parity is enough to allocate
unresolved coframe counts between the distinct directed anchors.
For an empty edge, both directed curvature parities must vanish.
This gives precisely the recorded bit-mask join at this coarse
scope. It preserves the distinction between raw occupancy and
an exact source term. The opposite and same-chirality restricted
controls share the same coarse occupation, but the raw coframe
support admits 16 complete generator assignments for the
opposite pairs and zero for the same pairs. The previously
independently verified restricted signed value 3/4 is therefore
consistent with the independent zero falsifier.

The center-total upper envelope is 10,651,488,789. Independent
fixed-load XOR enumeration confirms 5,937 coarse survivors of
43,046,721 all-one-load occupations. The independent
272-perfect-matching enumeration gives 2,970 binary two-factors
and 8,820,900 all-even control pairs. The checker load and
occupation totals reproduce 5,396,234,781 and 360,186,646,596.
Rebuilt author replay gives the same uniform result and verifies
that the checker case refuses before allocating a histogram at
its measured 613,774,076,852 viable prefix transitions. These
are prospective bounds on the stated schedules, not evidence
about the full signed coefficient.

## Exact signed curvature face and fourth power

At each of the four roots of the original axes-2/3 face I
independently reconstruct the exact source product in literal
order D-dagger, C-dagger, B, A. The reversed curvature axes give
its inverse. Each original directed anchor occurs at two roots.
Every nonempty proper root subset leaves a singleton anchor.
Direct unsquared F01 contraction with the actual coordinate
labels gives zero in each chirality.

The literal source gamma trace vectors are real. Independent
local Haar gauge averaging of each rooted square gives the
stated Gram replacement. Conjugating a rooted closed product
acts only at its own base; normalized product Haar remains
invariant under the simultaneous endpoint actions on all
distinct links. The L/R cross term averages to zero, and the
within-chirality isotropic coefficient is
(4/3) times the squared vector part, equal to 1 minus one third
of the spin-one character.

The original adjoint word enforces four free equality classes
in the literal sixteen trace indices after eight independent
Schur pairings. Thus the full character moment is 1/81. Changing
one actual dagger in the independent index check gives 1/243,
which detects that ordering error. The correct face tensor is
the product of the four local sums of L/R Grams, plus the sum
of the two pure-chirality Gram products divided by 6561.
The F01-square control gives 104978/6561, and the mixed
F01 F23 control gives 2/6561 rather than the separate-root zero.

In the one full occupation with only curvature plane 23 and
multiplicity two per root, axes-2/3 curvature links are disjoint
from the axes-0/1 coframe links. The four curvature faces expand
to 81 terms. At each fixed choice the same local Gram pattern
appears in all four periodic coframe squares, with independent
original links and site generators. Permuting the eight-generator
site blocks has positive sign. Thus the stated product is
the fourth power of the signed one-square coefficient, weighted
by its curvature factors and divided once by (2!)^16. All 64
raw root quarter increments obey the exact coefficient-conjugate
and bar/psi exchange relation, with the reverse increment having
opposite weight. The real Gram tensors, four coframes per
center, and positive top involution make the square coefficient
real. The contribution of this single occupation is nonnegative.
No value or strict positivity of that contribution was evaluated.

## Next signed slice and its exact cap

The edge has two coframes from each endpoint. The ten unordered
component pairs and 70 degree-four masks give a valid 700-state
interface per endpoint because the coframe bilinears are even.
The vertex must sum the original ordered component assignments
for each unordered pair. Reusing one ordered Gram entry with
generic multiplicity would be wrong. For unordered (0,1) at
both axes, the four original Gram assignments in either
chirality are 0,-1,-1,0. The correct sum is -2; multiplying a
nonzero representative by four gives -4. This is an actual
source falsifier for that shortcut, and a requirement on any
compressed vertex implementation.

An independent bounded fourth-Haar edge pilot uses the complete
raw source quarter increments for the selected (0,1)/(0,1)
component block. It retains both anchors and both chiralities,
all 736 nonzero labeled quartic Haar coordinate tuples,
literal exterior signs and exact normalized moments. Each
component-pair exchange reproduces the entire four-row nonzero
mask output, including mask pair (102,102) at numerator -1408
with common denominator 12288. It uses 631,296 charged visits
under 2,000,000. All eight root/neighbor components have
exactly four raw bilinear entries per coordinate label. Hence
the planned full 100-pair edge has 18,841,600 raw product visits
before collision rejection, with at most 4,900 output mask
keys per component block. This supports a streamed, prospectively
bounded edge preflight. It does not measure the populated
whole edge, the vertex join size, or the full square. The
actual sparse signed square join still needs admission.

**Frozen verdict.** Accept the coarse counts and refusals,
original signed restricted controls, exact face tensor and
fourth-power reduction, and the 700 endpoint dimension bound
with the ordered vertex-symmetrization requirement above.
The full signed square, strict positivity of this occupation,
and the original full c0 value and sign remain open. Primary
continuity remains fresh and the checkout is clean.
