#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <tuple>
#include <unordered_map>
#include <vector>

using U=std::uint64_t; using W=std::uint32_t;
using H=std::array<int,4>;
struct Rec {W syndrome,a,p;};
struct Local {H h{}; W s=0,a=0,p=0;};
constexpr U leave_cap=5'000'000, work_cap=50'000'000, pair_cap=250'000'000;
constexpr std::size_t state_cap=300'000, bytes_cap=128*1024*1024;
int edge_id[16][4];
std::vector<std::pair<int,int>> axes;

std::vector<Local> options(int x,int m,bool loads) {
    std::vector<Local> out;
    auto walk=[&](auto&& self,int i,int n,Local b)->void{
        if(i==6){ if(!n)out.push_back(b); return; }
        auto [k,l]=axes[i];
        H co{}; int j=0;
        for(int a=0;a<4;++a)if(a!=k&&a!=l)co[j++]=a;
        W de=(W(1)<<edge_id[x][co[0]])|(W(1)<<edge_id[x][co[1]]);
        W s=de,a=0;
        for(auto [y,k0]:{std::pair{x,k}, {x^(1<<k),l},{x^(1<<l),k},{x,l}}) {
            W bit=W(1)<<edge_id[y][k0];
            s^=bit;
            if(!(y&(1<<k0)))a^=bit;
        }
        for(int z=0;z<=n;++z){
            self(self,i+1,n-z,b);
            b.h[co[0]]++;b.h[co[1]]++;
            b.s^=s;b.a^=a;b.p|=de;
        }
    };
    walk(walk,0,m,{});
    if(loads){
        std::map<H,Local> unique;
        for(auto z:out)unique.emplace(z.h,z);
        out.clear();
        for(auto [k,z]:unique)out.push_back(z);
    }
    return out;
}
struct Side {
    std::array<int,8> source{},sink{};
    std::array<std::array<int,4>,8> neighbor{};
    std::array<std::vector<Local>,8> opt{};
    std::array<int,8> last{};
    std::array<std::unordered_map<W,U>,8> memo{};
    struct Arc { W target; int option; };
    std::array<std::unordered_map<W,std::vector<Arc>>,8> viable{};
    U arc_count=0;
    W target=0; U trials=0,states=0,collected=0;
    Side(int parity,int m,bool loads,int target_center=2){
        for(int x=15,i=0,j=0;x>=0;--x)
            if(__builtin_popcount(x)%2==parity)source[i++]=x;
            else sink[j++]=x;
        std::array<int,16> idx{};
        for(int i=0;i<8;++i)idx[sink[i]]=i;
        for(int i=0;i<8;++i){
            opt[i]=options(source[i],m,loads);
            for(int a=0;a<4;++a){
                int z=idx[source[i]^(1<<a)];
                neighbor[i][a]=z; last[z]=i;
            }
        }
        int r=8-2*target_center;
        for(int i=0;i<8;++i)target|=W(r)<<(4*i);
    }
    bool advance(int i,W from,const Local& z,W& to)const{
        to=from;
        for(int a=0;a<4;++a){
            int j=neighbor[i][a],left=(from>>(4*j))&15;
            if(z.h[a]>left||(last[j]==i&&z.h[a]!=left))return false;
            to-=W(z.h[a])<<(4*j);
        }
        return true;
    }
    U count(int i,W from){
        if(i==8)return from==0;
        auto t=memo[i].find(from);
        if(t!=memo[i].end())return t->second;
        if(++states>state_cap)std::abort();
        U r=0;
        for(auto& z:opt[i]){
            if(++trials>work_cap)std::abort();
            W to;
            if(advance(i,from,z,to))r+=count(i+1,to);
        }
        return memo[i].emplace(from,r).first->second;
    }
    void compile(){
        for(int i=0;i<8;++i)
            for(auto [key,suffix]:memo[i]){
                if(!suffix)continue;
                auto& out=viable[i][key];
                for(int j=0;j<int(opt[i].size());++j){
                    if(++trials>work_cap)std::abort();
                    W to;
                    if(!advance(i,key,opt[i][j],to)||(i<7&&!memo[i+1].at(to)))continue;
                    if(++arc_count>1'000'000)std::abort();
                    out.push_back({to,j});
                }
            }
    }
    void gather(int i,W from,Rec sig,std::vector<Rec>& out){
        if(i==8){ if(from)std::abort(); out.push_back(sig); return; }
        for(const auto& v:viable[i].at(from)){
            if(++collected>work_cap)std::abort();
            const auto& z=opt[i][v.option];
            gather(i+1,v.target,{sig.syndrome^z.s,sig.a^z.a,sig.p|z.p},out);
        }
    }

};
int main(){
    for(int k=0;k<4;++k)for(int l=k+1;l<4;++l)axes.push_back({k,l});
    for(int x=0,i=0;x<16;++x)for(int a=0;a<4;++a)if(!(x&(1<<a)))
        edge_id[x][a]=edge_id[x^(1<<a)][a]=i++;
    for(bool loads:{true,false}){
        Side l(0,2,loads),r(1,2,loads);
        auto nl=l.count(0,l.target),nr=r.count(0,r.target);
        std::cout<<(loads?"load":"occupation")<<' '<<nl<<' '<<nr<<' '<<nl*nr<<std::endl;
        if(loads)continue;
        if(nl>leave_cap||nr>leave_cap||(nl+nr)*sizeof(Rec)>bytes_cap)std::abort();
        std::vector<Rec> a,b;a.reserve(nl);b.reserve(nr);
        l.compile();r.compile();
        l.gather(0,l.target,{},a);r.gather(0,r.target,{},b);
        if(a.size()!=nl||b.size()!=nr)std::abort();
        auto cmp=[](Rec x,Rec y){return std::tie(x.syndrome,x.a,x.p)<std::tie(y.syndrome,y.a,y.p);};
        std::sort(a.begin(),a.end(),cmp);std::sort(b.begin(),b.end(),cmp);
        auto bins_in=[](const auto& v){
            U n=0;
            for(std::size_t j=0;j<v.size();++j)if(!j||v[j].syndrome!=v[j-1].syndrome)++n;
            return n;
        };
        std::cout<<"distinct side syndromes "<<bins_in(a)<<' '<<bins_in(b)<<" arcs "<<l.arc_count<<' '<<r.arc_count<<std::endl;
        std::size_t i=0,j=0;U raw=0,exact=0,bins=0;
        while(i<a.size()&&j<b.size()){
            auto x=a[i].syndrome,y=b[j].syndrome;
            if(x<y){++i;continue;}
            if(y<x){++j;continue;}
            std::size_t s=i+1,t=j+1;
            while(s<a.size()&&a[s].syndrome==x)++s;
            while(t<b.size()&&b[t].syndrome==y)++t;
            if(raw+U(s-i)*(t-j)>pair_cap)std::abort();
            raw+=U(s-i)*(t-j);++bins;
            for(auto z=i;z<s;++z)for(auto w=j;w<t;++w)
                if(!((a[z].a^b[w].a)&~(a[z].p|b[w].p)))++exact;
            i=s;j=t;
        }
        std::cout<<"syndrome bins "<<bins<<" coarse pairs "<<raw<<" directed "<<exact
                 <<" descriptor bytes "<<(a.size()+b.size())*sizeof(Rec)
                 <<" viable prefixes "<<l.collected<<' '<<r.collected<<std::endl;
    }
    for(bool loads:{true,false}){
        Side a(0,4,loads,0),b(1,0,loads,4);
        auto n=a.count(0,a.target),m=b.count(0,b.target);
        std::cout<<"checker "<<(loads?"load":"occupation")<<' '<<n<<' '<<m<<' '<<n*m<<std::endl;
    }
}
