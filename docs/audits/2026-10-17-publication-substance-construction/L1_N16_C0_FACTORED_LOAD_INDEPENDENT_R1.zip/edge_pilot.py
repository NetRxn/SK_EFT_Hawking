"""Exact selected fourth-Haar source edge, bounded raw reference."""
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path
import json,sys,resource
sys.path.insert(0,'/tmp/publication-n16-denominator-support-r1.VjgwoR')
from preflight import REG,LINKS
from src.core.formulas import original_coframe_blocks

X=REG.sites[0]
Y=REG.step(X,0)[0]
P={g:i for i,g in enumerate(REG.generator_order)}
basis=tuple((s,0,h,j) for s in (X,Y) for h in ('L','R') for j in range(4))
CAP=2_000_000
ROW_CAP=4900
work=Counter()
def charge(k):
    if work.total()==CAP:
        raise RuntimeError(('prospective_edge_pilot_work',CAP+1,CAP))
    work[k]+=1
def add(x,y):
    return x[0]+y[0],x[1]+y[1]
def mul(x,y):
    a,b=x;c,d=y
    return a*c-b*d,a*d+b*c
def scale(x,n):
    return n*x[0],n*x[1]
def frame(s,a):
    table=defaultdict(list)
    for b in original_coframe_blocks(REG,(s,0,a),LINKS):
        for i,row in enumerate(b.matrix):
            for j,p in enumerate(row):
                for k,z in p.terms:
                    charge('source_bilinear')
                    assert len(k)==1
                    w=(4*b.weight*z.real,4*b.weight*z.imag)
                    assert all(x.denominator==1 for x in w)
                    pair=(P[b.bar_site,'bar',i],P[b.psi_site,'psi',j])
                    table[basis.index(k[0].index)].append((pair,tuple(int(x) for x in w)))
    assert set(table)==set(range(16))
    return table
def moment(coords):
    blocks=defaultdict(list)
    for q in coords:
        blocks[q//4].append(q%4)
    if len(blocks)==1:
        a,b,c,d=next(iter(blocks.values()))
        return 2*(int(a==b and c==d)+int(a==c and b==d)+int(a==d and b==c))
    if len(blocks)==2 and all(len(v)==2 and v[0]==v[1] for v in blocks.values()):
        return 3
    return 0
mom=[]
for q in product(range(16),repeat=4):
    charge('quartic_coordinate_assignment')
    m=moment(q)
    if m:mom.append((q,m))
assert len(mom)==736
frames={(s,a):frame(s,a) for s,a in product((X,Y),range(4))}
assert {len(v) for t in frames.values() for v in t.values()}=={4}
def full(components):
    out={}
    slots=tuple(frames[s,a] for s,a in zip((X,X,Y,Y),components,strict=True))
    for q,m in mom:
        for rows in product(*(t[x] for t,x in zip(slots,q,strict=True))):
            charge('literal_quartic_path')
            word=tuple(v for k,z in rows for v in k)
            if len(set(word))!=8:continue
            i=sum(1<<j for j in word if j<8)
            j=sum(1<<(u-64) for u in word if 64<=u<72)
            assert i.bit_count()==j.bit_count()==4
            value=(m,0)
            for _,z in rows:value=mul(value,z)
            sg=(-1)**sum(x>y for j,x in enumerate(word) for y in word[j+1:])
            k=i,j
            if k not in out and len(out)==ROW_CAP:
                raise RuntimeError(('prospective_mask_row',ROW_CAP+1,ROW_CAP))
            out[k]=add(out.get(k,(0,0)),scale(value,sg))
    return {k:z for k,z in out.items() if z!=(0,0)}
a=full((0,1,0,1))
b=full((1,0,0,1))
c=full((0,1,1,0))
assert a==b==c and a
print(json.dumps(dict(components=[[0,1],[0,1]],quarter_and_moment_denominator=48*4**4,
    quartic_nonzero_Haar_coordinates=len(mom),nonzero_exterior_mask_rows=len(a),
    row_witness=[min(a),a[min(a)]],pair_swaps_exactly_invariant=True,
    checked_work=dict(work),total_work=work.total(),cap=CAP,
    exact_prospective_all_symmetric_pair_products=100*len(mom)*4**4,
    per_symmetric_pair_mask_row_bound=70**2,full_tensor_executed=False,sampled_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),indent=2))
