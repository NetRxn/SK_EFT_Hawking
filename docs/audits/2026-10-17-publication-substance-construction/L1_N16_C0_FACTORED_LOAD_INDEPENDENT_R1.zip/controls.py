"""Independent coefficient-envelope and fixed-load support controls."""
from collections import Counter
from itertools import combinations,product
from math import comb
import json

poly=[1]
for _ in range(16):
    q=[0]*(len(poly)+4)
    for i,z in enumerate(poly):
        for j in range(5):q[i+j]+=z
    poly=q
assert poly[32]==10651488789

edges={(x,a):i for i,(x,a) in enumerate((x,a) for x in range(16) for a in range(4) if not x>>a&1)}
def bit(x,a):
    return 1<<edges[min(x,x^(1<<a)),a]
def synd(x,k,l):
    u,v=sorted(set(range(4))-{k,l})
    return bit(x,u)^bit(x,v)^bit(x,k)^bit(x^(1<<k),l)^bit(x^(1<<l),k)^bit(x,l)
choices=[(synd(x,0,1)^synd(x,2,3),synd(x,0,2)^synd(x,1,3),synd(x,0,3)^synd(x,1,2)) for x in range(16)]
def histogram(rows):
    d=Counter({0:1})
    for opts in rows:
        new=Counter()
        for k,z in d.items():
            for p in opts:new[k^p]+=z
        d=new
    return d
a,b=histogram(choices[:8]),histogram(choices[8:])
fixed=sum(n*b[k] for k,n in a.items())
assert fixed==5937 and sum(a.values())*sum(b.values())==43046721
even=[x for x in range(16) if x.bit_count()%2==0]
def match(i,seen,mask):
    if i==len(even):
        yield mask
        return
    x=even[i]
    for a in range(4):
        y=x^(1<<a)
        if not seen>>y&1:
            yield from match(i+1,seen|(1<<y),mask|bit(x,a))
ms=list(match(0,0,0))
assert len(ms)==272
two={a|b for a,b in combinations(ms,2) if not a&b}
assert len(two)==2970 and len(two)**2==8820900
print(json.dumps(dict(center_total_envelope=poly[32],all_ones_fixed_load_occupations=43046721,
    all_ones_fixed_load_directed=5937,perfect_matchings=len(ms),binary_two_factors=len(two),
    all_even_pairs=len(two)**2),indent=2))
