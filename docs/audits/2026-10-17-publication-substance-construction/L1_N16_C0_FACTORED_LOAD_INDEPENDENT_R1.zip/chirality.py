"""Verify the source support distinction of the two restricted controls."""
from itertools import product
import json,sys
sys.path.insert(0,'/tmp/publication-n16-denominator-support-r1.VjgwoR')
from preflight import REG,LINKS
from src.core.formulas import original_coframe_blocks
root=REG.sites[0]
def candidates(axis,remote_spin_chi):
    neighbor=REG.step(root,axis)[0]
    out=set()
    for a in range(4):
        for b in original_coframe_blocks(REG,(root,axis,a),LINKS):
            if b.bar_site!=root or b.psi_site!=neighbor:
                continue
            for i,row in enumerate(b.matrix):
                for j,p in enumerate(row):
                    if (j>=2)==remote_spin_chi and p:
                        out.add((i,j))
    return out
same=(candidates(0,False),candidates(1,False))
opposite=(candidates(0,False),candidates(1,True))
assert all({i for i,j in a}=={2,3} for a in same)
assert {i for i,j in opposite[1]}=={0,1}
def full(groups):
    l,r=groups
    return sum(len({a[0],b[0],c[0],d[0]})==4 and a[1]!=b[1] and c[1]!=d[1]
               for a,b,c,d in product(l,l,r,r))
assert full(same)==0 and full(opposite)>0
print(json.dumps(dict(same_chirality_complete_generator_assignments=full(same),
    opposite_chirality_complete_generator_assignments=full(opposite),
    same_source_coarse_occupation=True),indent=2))
