"""Independent signed face character moment, source involution and slice interface."""
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import combinations,product
from math import comb
import json,sys
sys.path.insert(0,'/tmp/publication-n16-denominator-support-r1.VjgwoR')
from preflight import REG,LINKS
from src.core.formulas import original_coframe_blocks, original_plaquette, original_spin4_link
from src.vestigial.original_coefficients import Polynomial, matrix_multiply, matrix_dagger

X=tuple((0,0,k,l) for k,l in product((0,1),repeat=2))
ANCH=tuple((x,i) for x in X for i in (2,3))
G={k:matrix_multiply(matrix_multiply(REG.gamma[k[0]],REG.gamma[k[1]]),REG.gamma5)
   for k in product(range(4),repeat=2)}
def tr(m,n):
    return sum((m[i][j]*n[j][i] for i in range(4) for j in range(4)),Polynomial())

def ordered(x):
    a=(x,2); b=(REG.step(x,2)[0],3); c=(REG.step(x,3)[0],2);d=(x,3)
    return ((d,1),(c,1),(b,0),(a,0))

def verify_source_words():
    coefficients=[]
    incidence=[]
    for x in X:
        factors=[matrix_dagger(LINKS[a]) if d else LINKS[a] for a,d in ordered(x)]
        m=matrix_multiply(matrix_multiply(matrix_multiply(*factors[:2]),factors[2]),factors[3])
        direct=original_plaquette(REG,x,2,3,LINKS)
        assert m==direct
        backward=original_plaquette(REG,x,3,2,LINKS)
        assert backward==matrix_dagger(m)
        f=(tr(m,G[0,1])-tr(backward,G[0,1]))*Fraction(1,2)
        tab={}
        for key,z in f.terms:
            assert len(key)==4 and {s.index[:2] for s in key}=={a for a,d in ordered(x)}
            chi,={s.index[2] for s in key}
            coords=tuple(sorted((ANCH.index(s.index[:2]),s.index[3]) for s in key))
            assert not z.imag and z.real.denominator==1
            tab[chi,coords]=int(z.real)
        assert len(tab)==128
        coefficients.append(tab)
        incidence.append({ANCH.index(a) for a,d in ordered(x)})
    assert Counter(a for s in incidence for a in s)=={a:2 for a in range(8)}
    for n in range(1,4):
        for rows in combinations(incidence,n):
            assert 1 in Counter(a for s in rows for a in s).values()
    sums={}
    for h in ('L','R'):
        total=0
        slots=[tuple(sorted(s)) for s in incidence]
        for values in product(range(4),repeat=8):
            z=1
            for k,row in zip(slots,coefficients,strict=True):
                z*=row.get((h,tuple((i,values[i]) for i in k)),0)
            total+=z
        sums[h]=total
    assert sums=={'L':0,'R':0}
    return sums

def character_power(adverse=False):
    # Enforce the literal Schur delta pairs in a graph of trace indices.
    # Flood-fill components rather than use a union-find implementation.
    ends=defaultdict(list)
    for i,x in enumerate(X):
        for j,(a,d) in enumerate(ordered(x)):
            q,r=(i,j),(i,(j+1)%4)
            if adverse and i==0 and j==0:
                d^=1
            ends[a].append((r,q) if d else (q,r))
    labels={(i,j) for i in range(4) for j in range(4)}
    adj={k:set() for k in labels}
    for a in ANCH:
        x,y=ends[a]
        for u,v in zip(x,y,strict=True):
            adj[u].add(v)
            adj[v].add(u)
    components=[]
    while labels:
        seed=min(labels)
        current={seed}
        pending=[seed]
        while pending:
            last=pending.pop()
            more=adj[last]-current
            current|=more
            pending.extend(more)
        labels-=current
        components.append(sorted(current))
    return Fraction(3)**(len(components)-8),components

def vectors():
    a=ANCH[0]
    from src.vestigial.original_coefficients import Symbol
    syms={h:tuple(Symbol('q',(*a,h,i)) for i in range(4)) for h in ('L','R')}
    m=original_spin4_link(*(tuple(Polynomial.variable(s) for s in syms[h]) for h in ('L','R')))
    out={}
    for a,b in G:
        row=dict(tr(m,G[a,b]).terms) if a!=b else {}
        for h,ss in syms.items():
            c=[row.get((s,),None) for s in ss]
            assert c[0] is None and all(q is None or not q.imag for q in c)
            out[a,b,h]=tuple(Fraction(0) if q is None else q.real/2 for q in c[1:])
    return out

def involution():
    checked=0
    x=REG.sites[0]
    for a,b in product(range(4),repeat=2):
        raw=original_coframe_blocks(REG,(x,a,b),LINKS)
        table={(t.bar_site,t.psi_site,t.anchor):t for t in raw}
        assert len(table)==4
        for (u,v,link),t in table.items():
            rev=table[v,u,link]
            assert t.weight==-rev.weight
            assert matrix_dagger(t.matrix)==rev.matrix
            checked+=1
    assert checked==64
    return checked

unsquared=verify_source_words()
char,components=character_power()
bad,_=character_power(True)
assert char==Fraction(1,81) and bad!=char
u=vectors()
def gram(a,b,c,d,h):
    return sum(x*y for x,y in zip(u[a,b,h],u[c,d,h],strict=True))
g11=tuple(gram(0,1,0,1,h) for h in ('L','R'))
g12=tuple(gram(0,1,2,3,h) for h in ('L','R'))
assert g11==(1,1) and g12==(-1,1)
def moment(q):
    return sum(q)**4 + char*(q[0]**4+q[1]**4)/3**4
square,cross=moment(g11),moment(g12)
assert square==Fraction(104978,6561) and cross==Fraction(2,6561)

# The (0,1)/(0,1) unordered pair interface must keep all ordered
# vertex assignments, rather than applying a uniform multiplicity to
# one of the possible pairings of their original S2 occurrence labels.
orders=((0,1),(1,0))
paired={}
for h in ('L','R'):
    vals=[gram(a,b,c,d,h) for (a,c),(b,d) in product(orders,repeat=2)]
    assert sorted(vals)==[-1,-1,0,0]
    paired[h]=dict(ordered_assignments=list(map(int,vals)),
                   compressed_correct=int(sum(vals)),
                   incorrect_generic_multiplicity=-4)
result=dict(actual_four_word_unsquared_numerators=unsquared,
    adjoint_character_moment=str(char),adjoint_index_components=components,
    wrong_single_dagger_character_moment=str(bad),
    diagonal_local_gram=list(map(str,g11)),mixed_local_gram=list(map(str,g12)),
    squared_control=str(square),mixed_control=str(cross),
    conjugate_exchange_checks=involution(),symmetric_vertex_pair_falsifier=paired,
    max_interface=comb(5,2)*comb(8,4))
print(json.dumps(result,indent=2))
