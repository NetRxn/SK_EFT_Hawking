"""Match all independently reviewed original signed terminals to author values."""
import csv
from pathlib import Path
import re
from zipfile import ZipFile

def read(archive):
    with ZipFile(Path("independent") / f"{archive}.zip") as bundle:
        return list(csv.DictReader(bundle.read("scalar.tsv").decode().splitlines(), delimiter="\t"))

observed = {}
layouts = (
    ("L0", "original_joint_L_index", "raw_real", "raw_imag", "inherited_factor_denominator"),
    ("L1", "assignment", "raw_re", "raw_im", "factor_denominator"),
    ("L2", "original_L_assignment", "raw_real", "raw_imag", "inherited_factor_denominator"),
    ("L3", "assignment", "raw_re", "raw_im", "factor_denominator"),
    ("L46", "original_joint_L_index", "raw_real", "raw_imag", "factor_denominator"),
    ("L5", "assignment", "raw_re", "raw_im", "factor_denominator"),
    ("L7", "assignment", "raw_re", "raw_im", "factor_denominator"),
)
for archive, label_key, real_key, imag_key, denominator_key in layouts:
    for item in read(archive):
        assert int(item.get("group", "1441")) == 1441
        label = int(item[label_key])
        assert label not in observed
        terminal_hash = item.get("terminal_sha256")
        if terminal_hash:
            assert terminal_hash in (Path(f"L{label}")/"checkpoints.sha256").read_text()
        real, imag, denominator = (int(item[k]) for k in (real_key, imag_key, denominator_key))
        if archive == "L46":
            assert label in (4, 6) and real == imag == 0
            assert int(item["closed_wires"]) == {4:56, 6:76}[label]
            assert int(item["first_zero_signed_products"]) == {4:153600, 6:4032}[label]
        observed[label] = real, imag, denominator

author = {}
for label, real, imaginary, den in re.findall(
    r"original joint-L (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)",
    Path("AUTHOR_RETALLY.txt").read_text(),
):
    assert int(label) not in author
    author[int(label)] = int(real), int(imaginary), int(den)
assert sorted(observed) == list(range(8))
assert observed == author and all(imaginary == 0 for _, imaginary, _ in observed.values())
for label, value in sorted(observed.items()):
    print(label, *value, sep="\t")
