# Original dense Group 1441 signed contraction

The original fixed representation cut and prepared eight-label roster
are bound to the source hash
`047d054c4a63a4a0277412f184cd94a198f119e66796e028f8342006a96f462a`
in the accepted Group 786 throughput archive. The lower-quartile
Group 1466 archive anchors independent original-source readbacks for
Group 1441 ordinals 1 and 5. The included independent scope covers all
eight original ordinals from the prepared input to their exact signed
outcomes.

Six assignments end in one empty-axis signed scalar. Original ordinals
4 and 6 reach networks with empty factor support after signed
continuation. They preserve the exact original factor denominator and
closed degree-two wire incidence. The later heuristic error is
preserved in each `full-scheduler.out`, independent of the exact
empty-factor terminal proof.

From clean extraction run

```sh
shasum -a 256 -c SHA256SUMS
python3 -B retally.py | cmp - AUTHOR_RETALLY.txt
python3 -B check-independents.py | cmp - INDEPENDENT_MATCH.tsv
```

Rebuild the prepared original source with the earlier throughput
recipe. Use each original label's `condition.py` against that source
and its hash, keeping `original-labels.tsv` in the parent directory.
Run `run.py` to reproduce the guarded input and set the path in
`unsharded.py` to that exact local input. Preserve the hash and
dimension checks. Run the numbered passes in sequence. For original
ordinals 4 and 6 stop at `pass2-result.pkl` and run
`python3 -B check-empty-terminal.py ORDINAL` from the archive root
with locally reproduced numerical states. Continue the six nonzero
ordinals through the included terminal passes. The independent review
packages provide their own exact source, guard and continuation replays.
The archive retains compact terminal evidence and pins the larger
signed tables for regeneration.

The earlier exact chirality map transfers the group value to Group
2710. The accepted original profile weight 48 is applied after group
normalization. The full signed coefficient and physical publication
acceptance remain open.
