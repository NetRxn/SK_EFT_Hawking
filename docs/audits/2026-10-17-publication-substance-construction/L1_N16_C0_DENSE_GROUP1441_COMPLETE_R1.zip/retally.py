"""Combine original ordered terminals and independently witnessed exact zeros."""
from ast import literal_eval
from fractions import Fraction
from itertools import product
from math import factorial, prod
from pathlib import Path
import re

def normalization():
    codes, = re.findall(r"a,b='(\d+)','(\d+)'",Path("contract-branch.py").read_text())
    roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
    occ=[[roster[(int(code)>>(6*x))&63] for x in range(8)] for code in codes]
    edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
    world=sum((3+k)*n for sector in occ for o in sector for k,n in enumerate(o))
    cross=0
    for sector in occ:
        weights=[(u,v,sum(sector[u])-sector[u][k]+sum(sector[v])-sector[v][k]) for u,v,k in edges]
        cross+=sum(edge[2]*other[2]*(u>v) for i,edge in enumerate(weights)
                   for other in weights[i+1:] for u in edge[:2] for v in other[:2])
    total=sum(n for sector in occ for o in sector for n in o)
    multiplier=prod(factorial(p) for sector in occ for o in sector for p in o)
    assert total==32 and multiplier==16 and (world,cross)==(136,444)
    return (-1)**((world+cross)%2),multiplier*4**(2*total)

def raw(label):
    p=Path(f"L{label}")
    if (p/"empty-terminal.out").is_file():
        header, empty, receipt = (p/"empty-terminal.out").read_text().splitlines()
        assert header.startswith(f"group 1441 original ordinal {label} checkpoint ")
        assert "empty signed factors" in empty
        match = re.fullmatch(r"exact empty-factor numerator 0 0 denominator (\d+)",receipt)
        assert match
        return 0,0,int(match[1])
    if (p/"terminal.out").is_file():
        entries=re.findall(r"triangle signed numerator [012] [012] [012] (-?\d+) (-?\d+) denominator (\d+)",(p/"terminal.out").read_text())
        assert len(entries)==2 and entries[0]==entries[1]
        return tuple(map(int,entries[0]))
    results=[]
    for log in sorted(p.glob("pass*.out")):
        lines=log.read_text().splitlines()
        for line in lines:
            if not line.startswith("exact raw scalar "):
                continue
            real,imaginary=literal_eval(line.removeprefix("exact raw scalar "))
            last=[s for s in lines if s.startswith("exact follow join ")][-1]
            row=literal_eval(last.removeprefix("exact follow join ").split(" remaining ")[0])
            assert row[5:7]==(1,0)
            results.append((real,imaginary,row[7]))
    value,=results
    return value

def tally():
    labels=[(int(i),literal_eval(key),literal_eval(zero)) for i,key,zero in
            (line.split("\t") for line in Path("original-labels.tsv").read_text().splitlines())]
    assert [i for i,_,_ in labels] == list(range(8))
    assert len({key for _,key,_ in labels})==8 and not any(zero for _,_,zero in labels)
    roster=Path("L0/joint-label-roster.tsv").read_bytes()
    assert [(int(i),literal_eval(key),False) for i,key,_,_ in
            (line.split("\t") for line in roster.decode().splitlines()[1:])]==labels
    for i,_,_ in labels:
        assert (Path(f"L{i}")/"joint-label-roster.tsv").read_bytes()==roster
    values=[raw(i) for i,_,_ in labels]
    denominator,={d for _,_,d in values}
    assert denominator==9484343302046464884971246029111296
    sign,norm=normalization()
    for i,(real,imaginary,den) in enumerate(values):
        assert imaginary==0
        print("original joint-L",i,"raw",real,imaginary,"factor denominator",den)
    total=sum(real for real,_,_ in values)
    print("raw total",total,0)
    print("exact normalized",Fraction(sign*total,denominator*norm),0)

if __name__=="__main__":
    tally()
