from collections import Counter,defaultdict
from hashlib import file_digest
from itertools import combinations,islice
from math import gcd,prod
from pathlib import Path
from pickle import dump,load
from time import perf_counter
from resource import getrusage,RUSAGE_SELF
from fractions import Fraction
from sys import argv

ROOT=Path('/private/tmp/l1-throughput-quartiles.garG6a/1441/L1/row-cap-physical-slice-dense-branch.pkl')
PIN='8e1a2e03d36a558931a049e384ce1a7de636ed9bf01a65d8cdd001bcabc612bf'
DEN=9484343302046464884971246029111296
UNIT=((1,0),(0,1),(-1,0),(0,-1))
ROWS=500_000
PAIR=8_000_000
TOTAL=40_000_000
WALL=180
def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open('rb') as f:return load(f)
def mul(p,q):
    a,b=p; x,y=q
    return a*x-b*y,a*y+b*x
def prim(vals):
    c=0
    for x,y in vals:
        c=gcd(c,x,y)
        if c==1:break
    u=max(UNIT,key=lambda u:mul(vals[0],u))
    assert c>0
    vec=tuple(mul((x//c,y//c),u) for x,y in vals)
    a=(c*u[0],-c*u[1])
    return vec,a
def pos(A,sub):return tuple(A.index(w) for w in sub)
def pull(row,ii):return tuple(row[i] for i in ii)

def split(factor,n,left):
    ax,X,d=factor
    right=tuple(w for w in ax if w not in left)
    xp=pos(ax,left); yp=pos(ax,right)
    bins=defaultdict(list)
    for r,z in X.items():bins[pull(r,xp)].append((pull(r,yp),z))
    seen={}
    A={};B={}
    for r,group in bins.items():
        group.sort()
        ys,zs=zip(*group)
        new,scale=prim(zs)
        signature=(ys,new)
        fresh=len(seen)
        code=seen.setdefault(signature,fresh)
        A[r+(code,)]=scale
        if code==fresh:
            for row,z in zip(ys,new,strict=True):B[(code,)+row]=z
    wire=('exact-fiber-split',n)
    return (left+(wire,),A,d),((wire,)+right,B,1),len(seen)

def certify(source,A,B):
    x,X,d=A; y,Y,e=B
    old,T,m=source
    wire=x[-1]
    assert wire==y[0] and wire not in old
    assert len(old)==len(x)+len(y)-2 and set(old)==set(x[:-1]+y[1:])
    assert set(x)&set(y)=={wire} and m==d*e
    group=defaultdict(list)
    for key,z in Y.items(): group[key[0]].append((key[1:],z))
    assert set(group)=={k[-1] for k in X}
    lift=pos(x[:-1]+y[1:],old)
    assert all(len(xi)==len(x) for xi in X)
    count=0
    for row,v in X.items():
        for tail,z in group[row[-1]]:
            k=pull(row[:-1]+tail,lift)
            assert T[k]==mul(v,z)
            count+=1
    # Every left key is unique and has one class, so restored keys cannot collide.
    assert len({row[:-1] for row in X})==len(X) and count==len(T)

def candidates(F,i):
    a,X,_=F[i]
    e=[(j,tuple(w for w in a if w in b)) for j,(b,_,_) in enumerate(F) if j!=i and set(a)&set(b)]
    if len(e)<2:return []
    ids=tuple(j for j,_ in e)
    total=set(ids)
    ix=[pos(a,w) for _,w in e]
    # Compact sampled projections only. Exact factorization is limited to three of the sampled candidates.
    trial=[]
    for row in islice(X,0,None,max(1,len(X)//1200)):
        trial.append(tuple(pull(row,x) for x in ix))
    d={j:n for n,j in enumerate(ids)}
    scores=[]
    queue=set()
    for t in ids:queue.add(frozenset((t,)))
    marginal=[len({r[i] for r in trial}) for i in range(len(e))]
    connected=[]
    for q,p in combinations(range(len(e)),2):
        both=len({(x[q],x[p]) for x in trial})
        # Keep the most correlated incident pairs as candidate blocks.
        connected.append((both/(marginal[q]*marginal[p]),p,q))
    for _,u,v in sorted(connected)[:min(10,len(connected))]:
        queue.add(frozenset((ids[u],ids[v])))
    orders=[ids,tuple(j for j,_ in sorted(e,key=lambda z:(-len(z[1]),z[0]))),
            tuple(j for j,_ in sorted(e,key=lambda z:min(a.index(w) for w in z[1])))]
    for rule in orders:
        for i0 in range(2,len(rule)-1):
            queue.add(frozenset(rule[:i0]))
    for side in sorted(queue,key=lambda x:tuple(sorted(x))):
        other=total-side
        if not other:continue
        p0=tuple(d[j] for j in ids if j in side)
        q0=tuple(d[j] for j in ids if j in other)
        n,m=len({pull(r,p0) for r in trial}),len({pull(r,q0) for r in trial})
        scores.append((n+m,max(n,m),n,tuple(sorted(side)),tuple(sorted(other))))
    opts=[]
    seen=set()
    for *_,ip,iq in sorted(scores):
        for choice in (ip,iq):
            if choice in seen:continue
            seen.add(choice)
            all_axes=set(w for j,ws in e if j in choice for w in ws)
            opts.append((choice,tuple(w for w in a if w in all_axes)))
            if len(opts)>=3:return opts
    return opts

def forecast(A,B):
    a,X,_=A;b,Y,_=B
    common=tuple(w for w in a if w in b)
    if not common:return None
    da=pos(a,common);db=pos(b,common)
    u=Counter(pull(r,da) for r in X);v=Counter(pull(r,db) for r in Y)
    return sum(n*v[k] for k,n in u.items()),len(a)+len(b)-2*len(common),len(u.keys()&v.keys())

class Stopped(Exception):pass
def join(A,B,cap,deadline,others):
    a,X,d=A;b,Y,e=B
    shared=tuple(w for w in a if w in b)
    ai,bi=pos(a,shared),pos(b,shared)
    ac=tuple(w for w in a if w not in shared)
    bc=tuple(w for w in b if w not in shared)
    ax,ix,jx=ac+bc,pos(a,ac),pos(b,bc)
    blocks=defaultdict(list)
    for row,z in X.items():blocks[pull(row,ai)].append((pull(row,ix),z))
    match=0
    values={}
    constraints=[]
    if cap>=500_000:
        for p,T,_ in others:
            subset=tuple(w for w in p if w in ax)
            if not subset:continue
            dest,pro=pos(ax,subset),pos(p,subset)
            constraints.append((dest,{pull(k,pro) for k in T}))
        constraints.sort(key=lambda t:(len(t[1]),-len(t[0])))
    for row,z in Y.items():
        tail=pull(row,jx)
        for head,v in blocks.get(pull(row,bi),()):
            match+=1
            assert match<=cap
            if match%32768==0 and perf_counter()>deadline:
                return None,match,'wall'
            both=head+tail
            if constraints and any(pull(both,c) not in copied for c,copied in constraints):continue
            r,t=mul(v,z);u,w=values.get(both,(0,0))
            pair=(r+u,t+w)
            if any(pair):values[both]=pair
            else:values.pop(both,None)
            if len(values)>ROWS:return None,match,'rows'
    assert cap==match
    return (ax,values,d*e),match,'complete'

def checkpoint(path,origin,live,steps,work,refused):
    assert prod(d for _,_,d in live.values())==DEN
    assert set(Counter(w for a,_,_ in live.values() for w in a).values()) in ({2},set())
    scope={**origin,'factors':list(live.values()),'factor_labels':tuple(live),
           'split_origin_sha256':PIN,'unsharded_trace':list(steps),'attempted_products':work,
           'refused_pairs':list(refused)}
    with Path(path).open('xb') as f:dump(scope,f,protocol=5)
    print('preserved checkpoint',path,sha(Path(path)),len(live),sum(len(T) for _,T,_ in live.values()),flush=True)
    return scope

def main():
    start=perf_counter()
    assert sha(ROOT)==PIN
    state=read(ROOT); F=state['factors']
    assert len(F)==20 and sum(len(T) for _,T,_ in F)==1355600
    assert len(Counter(w for a,_,_ in F for w in a))==255
    assert all(w[0]!='L' for a,_,_ in F for w in a)
    assert set(Counter(w for a,_,_ in F for w in a).values())=={2} and prod(d for _,_,d in F)==DEN
    assert state['used_before']==4301170
    print('exact original whole-G scope',state['physical_cut'],'input',PIN,flush=True)
    cur={}
    split_trace=[]
    for i,f in enumerate(F):
        rows=len(f[1])
        best=None
        for subset,left in candidates(F,i):
            X,Y,k=split(f,i,left)
            total=len(X[1])+len(Y[1])
            print('measured candidate',i,subset,'parent',rows,'children',len(X[1]),len(Y[1]),'classes',k,
                  'seconds',round(perf_counter()-start,6),flush=True)
            if best is None or total<best[0]:best=(total,X,Y,k,subset)
            if best[0]*6<=rows:break
        if best and best[0]*2<rows:
            _,X,Y,k,e=best
            certify(f,X,Y)
            cur[i,0]=X;cur[i,1]=Y
            split_trace.append((i,e,k,len(X[1]),len(Y[1]),X[2],Y[2]))
            print('verified exact whole-factor inverse',split_trace[-1],flush=True)
        else:cur[i,0]=f
    state=dict(state,primitive_splits=split_trace)
    checkpoint('split-frontier.pkl',state,cur,[],0,[])
    if 'split-only' in argv: return
    deadline=perf_counter()+WALL
    current={}
    for i,j in combinations(cur,2):
        result=forecast(cur[i],cur[j])
        if result:current[i,j]=result
    print('bounded exact initial forecasts',sorted((v,i,j) for (i,j),v in current.items())[:16],flush=True)
    trace=[]; rejected=[]; rejected_set=set(); work=0
    for step in range(40):
        if len(cur)==1 or perf_counter()>deadline:break
        options=[(n*(1+w)**2,n,w,i,j) for (i,j),(n,w,_) in current.items()
                 if i[0]!=j[0] and (i,j) not in rejected_set and 0<n<=PAIR and work+n<=TOTAL]
        if not options:break
        _,v,w,i,j=min(options)
        out,visited,why=join(cur[i],cur[j],v,deadline,[f for k,f in cur.items() if k not in (i,j)])
        work+=visited
        if out is None:
            rejected_set.add((i,j));rejected.append((i,j,v,visited,why))
            print('bounded refusal',rejected[-1],'cumulative',work,flush=True)
            if why=='wall':break
            continue
        assert len(out[0])==w
        name=(100+step,0)
        del cur[i],cur[j]
        current={k:v for k,v in current.items() if i not in k and j not in k}
        for k,f in cur.items():
            result=forecast(f,out)
            if result:current[k,name]=result
        cur[name]=out
        trace.append((i,j,name,visited,len(out[1]),len(out[0]),out[2]))
        print('exact accepted join',trace[-1],'remaining',len(cur),'cumulative attempts',work,flush=True)
    print('actual terminal pair forecasts',sorted((v,i,j) for (i,j),v in current.items())[:16],flush=True)
    checkpoint('unsharded-result.pkl',state,cur,trace,work,rejected)
    if len(cur)==1:
        a,T,d=next(iter(cur.values()))
        assert not a
        print('exact raw scalar',*T.get((),(0,0)))
    print('total process seconds',round(perf_counter()-start,6),
          'peak process RSS bytes',getrusage(RUSAGE_SELF).ru_maxrss,flush=True)

if __name__=='__main__':main()
