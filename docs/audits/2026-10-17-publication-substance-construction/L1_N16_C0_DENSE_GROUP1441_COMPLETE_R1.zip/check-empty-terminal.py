"""Verify exact zero from an empty factor in a fully closed signed network."""
from collections import Counter
from hashlib import file_digest
from math import prod
from pathlib import Path
import pickle
from sys import argv

label = int(argv[1])
pins = {
    4: "89fea913783d19108347a98e626f5a4ec082c1502808d7959d0b3121791908e3",
    6: "fd05e47ca44e6278dd461f8ca25a392effd0cb6ba879414e7ca03a970645b8d5",
}
with Path(f"L{label}/pass2-result.pkl").open("rb") as stream:
    digest = file_digest(stream, "sha256").hexdigest()
    assert digest == pins[label]
    stream.seek(0)
    state = pickle.load(stream)
directory = Path(f"L{label}")
with (directory/"dense-saturated-frontier.pkl").open("rb") as stream:
    seed = pickle.load(stream)
assert (seed["group"], seed["joint_label_index"]) == (1441, label)
assert seed["physical_cut"] == state["physical_cut"]
assert state["physical_cut"][1] == seed["complete_label_roster"][label]
for name, key in (("row-cap-physical-slice-dense-branch.pkl", "split_origin_sha256"),
                  ("unsharded-result.pkl", "pass2_pred_sha256")):
    with (directory/name).open("rb") as stream:
        assert file_digest(stream, "sha256").hexdigest() == state[key]
factors = state["factors"]
multiplicity = Counter(wire for axes, _, _ in factors for wire in axes)
assert all(count == 2 and wire[0] != "L" for wire, count in multiplicity.items())
empty = [factor for factor, (_, table, _) in zip(state["factor_labels"], factors, strict=True)
         if not table]
assert empty
denominator=prod(den for _,_,den in factors)
assert denominator == 9484343302046464884971246029111296
print("group",seed["group"],"original ordinal",label,"checkpoint",digest)
print("empty signed factors",empty,"closed wires",len(multiplicity))
print("exact empty-factor numerator",0,0,"denominator",denominator)
