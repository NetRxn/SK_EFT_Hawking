from fractions import Fraction
from pathlib import Path
import re, sys
cases={}
for line in Path(sys.argv[1]).read_text().splitlines():
    family,index,x,y=line.split('\t')
    if family=='tuple1-0b' and index.isdigit():
        cases[int(index)]=(Fraction(x),Fraction(y))
assert set(cases)=={0,1}
for index,x,y in re.findall(r'^PASS case (\d+) exact normalized (\S+) (\S+)',Path('aggregate.out').read_text(),re.M):
    assert int(index) not in cases
    cases[int(index)]=(Fraction(x),Fraction(y))
assert set(cases)==set(range(6))
for index, (x, y) in sorted(cases.items()):
    print(index,x,y,sep='\t')
print('PARTIAL SUM',len(cases),*map(sum,zip(*cases.values())),sep='\t')
