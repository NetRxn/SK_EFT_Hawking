# Shared tuple 1 child cases 2–5

Restore separator.zip and child-equality.zip from the exact Git blobs in
SOURCE_PINS.txt. Restore cases 2–5 author inputs with `sh rehydrate.sh` in
a clean directory. This reproduces all forty bytes-pinned input objects.
Use only trusted original archives when deserializing checkpoint data.
The verification scripts and outputs in REVIEW.md describe independent
lineage and terminal computations. A replay may report different timings.

The first two already-reviewed terms come from the committed
`L1_N16_C0_SIBLING_PILOTS_R1.zip`. Verify `pilot-totals.tsv` matches its
`exact-subtotals.tsv` and run `python3 retally-six.py pilot-totals.tsv`.
The six-term result is for one shared child, before doubling the complete sum.
