# Dense tuple 1 shared-child cases 2–5 independent exact review

The four independently replayed terms give exact subtotal **-195337984875805804028103 / 5192296858534827628530496329220096 + 0i**. The terms have distinct case inputs and distinct rescued checkpoint hashes, including where scalar values agree.

| Case | Coordinate | Exact normalized real | Imaginary |
| --- | --- | --- | --- |
| 2 | (33, (3,)) | 379732256596697227299/1298074214633706907132624082305024 | 0 |
| 3 | (34, (3,)) | -198375842928579381846495/10384593717069655257060992658440192 | 0 |
| 4 | (36, (3,)) | -198375842928579381846495/10384593717069655257060992658440192 | 0 |
| 5 | (40, (3,)) | 379732256596697227299/1298074214633706907132624082305024 | 0 |

At checkpoint 55743531f1b7b22cfd530bfe007ac639d91bd0b2, the original separator archive pins the six-factor tuple1-0b parent to uncompressed SHA256 843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077. The common projected census on parent pair (0, 1) independently recovers the 36 supported coordinates on G(0,0,2) and J(1,4,2), with 6,838,272 compatible products. Each indicated case has 142,464 of these products. The full roster and order match all four author records. The respective inverse lifts recover all restricted parent rows, signed coefficients and denominators.

The independent lineage check regenerates each initial reduction, each completed join, each exact checkpoint preserved after refusal, and each complete rescued terminal frontier. Cases 2 and 5 reach the row cap after 34,488 completed products and a later forecast of 2,536,320. Cases 3 and 4 reach it after 1,800,648 completed products and a later forecast of 2,557,632. The common verifier spent 29.83 seconds on the roster and four independent lineages.

The independent terminal replays use ordinary sparse Gaussian-integer joins with no author quotient or peer projections. Cases 2 and 5 each take 9,011,712 products and retain at most 238,464 rows, while cases 3 and 4 each take 512,496 products and retain at most 22,464 rows. The runtimes in case order were 7.37, 0.47, 0.47 and 7.75 seconds. Each exact raw scalar is retained before applying the common factor denominator and the positive external scale 1/(16*4^64) once.

The accepted child equality stays in force from the separate committed equality evidence. This review covers four terms of the 36-case shared child in dense group 128 descendant (0, 0). Full shared-child and tuple recombination remain open.

Keep the relative inputs/ directory with this evidence. Restore separator.zip and child-equality.zip from the committed objects identified in SOURCE_PINS.txt. Run shasum -a 256 -c frozen-inputs.sha256, python3 verify-lineage.py, sh replay-terminals.sh 2 3 4 5 and python3 verify-aggregate.py. The supplied review and input manifests use relative paths.
