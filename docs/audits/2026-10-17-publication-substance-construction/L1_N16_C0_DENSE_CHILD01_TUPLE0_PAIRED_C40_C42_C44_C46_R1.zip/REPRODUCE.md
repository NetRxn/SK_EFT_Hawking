# L1 original paired cuts 40, 42, 44 and 46

These are four distinct original outer coordinates of group 128, descendant (0,1), tuple 0. The source cuts 40 and 42 have complete independent direct replays. Cuts 44 and 46 each have six exact inherited inner values on independently verified signed tensor maps and three independently verified direct values. The full tuple and original signed coefficient remain open.

Check manifest.sha256 here and review-manifest.portable.sha256 in each independent review directory. ROOT verified the original review manifests before packaging. The machine-local continuity packets remain local.

Restore the two frozen branch operands, full outer roster and signed pair scripts from L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip at 383f42e573962e8f7f41c0111c82a59a605c73ff. Verify branch hashes. Reproduce each signed paired cut with sum-branches-checked.py, reduce-label-frontier.py and contract-reduced-label.py. The expected last status is 2, preserving a row-cap checkpoint. The pair, reduction and cap hashes are in each outer-inputs.sha256.

For 40 and 42, use run-primary.py against their frozen outer cap and quotient.py, then reduce-open.py for the refused slices. Contract the residuals with the saved triangle or four-factor plans. The plans use eight disjoint author intervals each. Run sum-shards.py and sum-case<cut>.py to reproduce every term in the exact ledger. The independent replay scripts can be run from scratch with their recorded source paths adapted to the restored author inputs.

For 44 and 46, generate all raw inner slices from the cap with exact-multicut.py and preserve their complete common roster. The direct slice indices 0, 2 and 3 use run-selected.py, reduce-open.py and the plans in the author directories. The six inherited values use the accepted source scalar after verifying all raw or support-pruned rows and signed edge labels. The source review manifests, author tables, raw tensor hashes and map files are linked in the exact reuse receipts.

Extract L1_N16_C0_PAIRED_TENSOR_EQUIVALENCE_R1.zip to a checker directory. Run python3 -B equivalence/verify-neighbor-raw.py <restored_root> <checker_directory> equivalence/map-neighbor-raw.tsv . from the extracted current package. The restored root contains directories probe{40,42,44,46}-inner with the recorded raw slices and rosters. Compare the verifier output with reuse-exact-readback.tsv. Then retally the nine terms in each target with sum-case<cut>.py and compare its output with the ledger. All terms include the common positive normalization 1/(16*4^64) exactly once.

Run coverage-retally.py with the repository audit archive directory as its argument. Compare every row with coverage-ledger.tsv. The subtotal covers the verified cuts.
