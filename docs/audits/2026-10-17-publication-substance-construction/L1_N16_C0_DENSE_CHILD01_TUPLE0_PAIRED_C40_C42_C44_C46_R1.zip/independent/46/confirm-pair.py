from hashlib import sha256
from pathlib import Path
from pickle import loads

root=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
candidate=loads(Path('independent-pair.pkl').read_bytes())
check=root/'combined-46.pkl'
raw=check.read_bytes()
target=loads(raw)
assert candidate==target
print('PASS author checkpoint matches every independently reconstructed signed factor table and all metadata',
      sha256(raw).hexdigest())
