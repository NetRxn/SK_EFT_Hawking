from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run
from sys import executable
from time import perf_counter

from terminal_plan import plans

author=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe44-inner')

def review(item):
    index,(source,triangle,pair,_,state)=item
    coordinate=str(dict(state['conditioning'])['G',0,1,2])
    if triangle:
        command=['triangle-author-raw.py',str(index),str(source),coordinate,'--author-shards']
    else:
        command=['four-author-raw.py','44',str(index),str(source),coordinate,
                 '--author-shards','--pair',*map(str,pair)]
    start=perf_counter()
    with Path(f'slice-{index}-shard-raw-replay.out').open('xb') as log:
        run([executable,'-B','-u',*command],stdout=log,stderr=log,check=True,timeout=200)
    return index,f'{perf_counter()-start:.6f}'

with ThreadPoolExecutor(max_workers=2) as workers:
    for result in workers.map(review,plans(author).items()):
        print(*result,sep='\t',flush=True)
