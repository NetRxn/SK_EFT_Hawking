from ast import literal_eval
from concurrent.futures import ProcessPoolExecutor
from gzip import open as compress
from hashlib import sha256
from pathlib import Path
from pickle import dump
from time import perf_counter

from edge_relabel import model
from signed_gauge import search_gauge

root=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
keys=(48,80,96,144,160,192)
swap={48:192,192:48}
def cuts(case):
    d=root/f'probe{case}-inner'
    axes,domain=literal_eval((d/'slice-0.roster').read_text())
    assert axes==(('G',0,1,2),)
    assert len(domain)==len(dict(domain))==9
    order=sorted(domain,key=lambda item:(item[1],item[0]))
    return {label[0]:(d/f'slice-{n}.pkl',count,n) for n,(label,count) in enumerate(order)}

def run(job):
    l,r,k,other,left,right,n=job
    start=perf_counter()
    proof,diagnostic=search_gauge(model(left),model(right))
    receipt=''
    if proof:
        p=Path('certs')/f'{l}-{r}-{k}-{other}.pkl.gz'
        with compress(p,'wb',compresslevel=1) as stream:
            dump(proof,stream,protocol=5)
        receipt=str(p)
    return l,r,k,other,n,bool(proof),*(sha256(p.read_bytes()).hexdigest() for p in (left,right)),f'{perf_counter()-start:.6f}',receipt,repr(diagnostic)
if __name__=='__main__':
    jobs=[]
    for l,r in ((40,44),(42,46)):
        left,right=cuts(l),cuts(r)
        assert len(left)==len(right)==9
        for k in keys:
            other=swap.get(k,k)
            x,n,_=left[k]
            y,m,_=right[other]
            assert n==m
            jobs.append((l,r,k,other,x,y,n))
    Path('certs').mkdir()
    print('left','right','left_inner','right_inner','products','verified','left_sha','right_sha','seconds','witness','diagnostic',sep='\t',flush=True)
    with ProcessPoolExecutor(max_workers=3) as pool:
        for row in pool.map(run,jobs):
            print(*row,sep='\t',flush=True)
