from csv import DictReader
from hashlib import sha256
from pathlib import Path
from pickle import dumps,loads
from runpy import run_path
from time import perf_counter

verify=run_path('verify-witnesses.py')['verify']
cuts=run_path('find-maps.py')['cuts']

class MemoryOperand:
    def __init__(self,factors):
        self._contents=dumps({'factors':factors},protocol=5)
    def read_bytes(self):
        return self._contents

def prune(path):
    factors=loads(path.read_bytes())['factors']
    scopes=[s for s,_,_ in factors]
    edges=[]
    for i,A in enumerate(scopes):
        for j,B in enumerate(scopes[:i]):
            shared=sorted(set(A)&set(B))
            if shared:
                edges.append((i,j,tuple(A.index(x) for x in shared),tuple(B.index(x) for x in shared)))
    def projection(row,indices):
        return tuple(row[p] for p in indices)
    while True:
        restrictions=[[] for _ in factors]
        for i,j,p,q in edges:
            left={projection(r,p) for r in factors[i][1]}
            right={projection(r,q) for r in factors[j][1]}
            if left != right:
                common=left&right
                if left!=common: restrictions[i].append((p,common))
                if right!=common: restrictions[j].append((q,common))
        if not any(restrictions):
            return MemoryOperand(factors),sum(len(r) for _,r,_ in factors)
        factors=[(axes,{row:z for row,z in values.items()
                       if all(projection(row,pos) in allowed for pos,allowed in checks)},den)
                 for (axes,values,den),checks in zip(factors,restrictions,strict=True)]

print('left','right','source_inner','target_inner','source_idx','target_idx','products','method','factors','edges','edge_values','negative_values','verified_rows','flipped_rows','source_original_rows','target_original_rows','source_sha256','target_sha256','certificate_sha256','checker_seconds','witness',sep='\t',flush=True)
with Path('raw-map-search.tsv').open() as f:
    rows=list(DictReader(f,delimiter='\t'))
assert len(rows)==12
for row in rows:
    a,b,k,h=map(int,(row['left'],row['right'],row['left_inner'],row['right_inner']))
    assert row['verified']=='True'
    x,n,i=cuts(a)[k]
    y,m,j=cuts(b)[h]
    assert n==m==int(row['products'])
    cert=Path(row['witness'])
    orig=[sum(len(d) for _,d,_ in loads(p.read_bytes())['factors']) for p in (x,y)]
    dx,dy=(sha256(p.read_bytes()).hexdigest() for p in (x,y))
    assert (dx,dy)==(row['left_sha'],row['right_sha'])
    start=perf_counter()
    if row['diagnostic'].startswith("('trim',"):
        L,lcount=prune(x)
        R,rcount=prune(y)
        assert lcount==rcount and all(lcount<c for c in orig)
        method='support-pruned'
    else:
        assert row['diagnostic'].startswith("('original',")
        L,R=x,y
        method='raw'
    stats=verify(L,R,cert,True)
    assert stats[0]==7 and stats[4]>0
    print(a,b,k,h,i,j,n,method,*stats,*orig,dx,dy,sha256(cert.read_bytes()).hexdigest(),f'{perf_counter()-start:.6f}',cert,sep='\t',flush=True)
