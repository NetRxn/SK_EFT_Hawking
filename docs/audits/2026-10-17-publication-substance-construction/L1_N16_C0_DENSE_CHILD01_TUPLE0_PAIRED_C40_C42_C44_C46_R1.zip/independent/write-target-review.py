from csv import DictReader
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from re import search
from sys import argv

target=int(argv[1])
source={44:40,46:42}[target]
outer={44:129,46:136}[target]
manifest=Path(argv[2])
def h(p): return sha256(p.read_bytes()).hexdigest()
rows=list(DictReader(Path('signed-ledger.tsv').open(),delimiter='\t'))
assert len(rows)==10
terms,agg=rows[:-1],rows[-1]
assert agg['slice']=='subtotal'
assert len([r for r in terms if r['route'].startswith('signed witness')])==6
assert sum(int(r['pair_products']) for r in terms)==2280960
times=[r.split('\t') for r in Path('native-stage-timing.tsv').read_text().splitlines()]
assert len(times)==19 and sum(r[2]=='2' for r in times)==7
assert len(Path('native-lineage.tsv').read_text().splitlines())==8
assert not Path('native-lineage-errors.out').read_text()
wall=sum(float(row[-1]) for row in times)
all_work=0
for n in (0,2,3):
    text=Path(f'slice-{n}-triangle-replay.out' if n else 'slice-0-replay.out').read_text()
    pattern=r'Gaussian products (\d+) wall seconds' if n else r'independent matched products (\d+)'
    all_work+=int(search(pattern,text)[1])
rawtimes=[float(search(r'^real (\S+)',Path(f'slice-{i}-shard-raw-replay.time').read_text())[1]) for i in (2,3)]
scope=[r for r in DictReader(Path('../bound-author-maps.tsv').open(),delimiter='\t') if int(r['target_cut'])==target]
assert len(scope)==6 and sum(int(r['checked_rows']) for r in scope)==1455404
assert {int(r['target_slice']) for r in scope}=={1,4,5,6,7,8}
pair_table=dict((name,hashcode) for hashcode,name in map(str.split,Path('pair-pins.sha256').read_text().splitlines()))
N=40512224221827380280140849737629696
assert tuple(Fraction(int(agg[k]),N*16*4**64) for k in ('raw_real','raw_imaginary'))==tuple(Fraction(agg[k]) for k in ('normalized_real','normalized_imaginary'))
review=f"""# Independent review of paired coordinate {target}

**Pass.** The signed contribution at outer coordinate `({outer},(1,))` is `{agg['normalized_real']} + {agg['normalized_imaginary']}i`. The raw Gaussian subtotal is `({agg['raw_real']},{agg['raw_imaginary']})`. The common factor denominator is `{N}`. Each term uses positive external normalization `1/(16*4^64)` once.

At continuity pin `2ebe664acce9ee0e3f8ec8b1f0b4133c45456a79`, the original operands have disjoint binary selector values and share six environment factors. The independent histogram recovers all 48 disjoint outer coordinates with 6,427,904 products per original branch. Conditioning each branch first and indexing the opposite factor gives 212,688 products per branch and 154,656 retained signed pair rows. The author seven-factor sum and its row cap match independent reconstruction and byte replay at SHA-256 `{pair_table[f'combined-{target}.pkl']}` and `{pair_table[f'row-cap-physical-slice-dense-label-sum{target}-reduced.pkl']}`. Independent inner census recovers all nine cuts and 2,280,960 compatible products. Every signed row, axis and denominator passes its exact inverse lift.

The six mapped terms reuse independently accepted cut {source} under identity on labels 80, 96, 144 and 160 and the swap 48↔192. At each swapped label, exact support-only pruning precedes the mapping. The verifier checked every row of the two seven-factor states under each exact shared-edge tuple and sign transformation, 1,455,404 retained rows per side across the six terms, and checked that the author witness objects are identical to the independently verified ones. Each signed edge value contributes the same sign at both ends, so the product is +1. The factor denominators are identical. The accepted source manifest is SHA-256 `{h(manifest)}`. Each source ledger and exact replay log match that manifest, and the target reuse receipts explicitly bind their own input, the accepted source, and their witness. All reused raw and normalized signed values agree with the accepted source.

The other three terms use independent signed sparse accumulation for slice 0 and triangle pivot 1 for slices 2 and 3. All 16 author raw and normalized shard pairs and disjoint intervals match independent calculations. The native terminal schedules used {all_work:,} Gaussian products. The individual shard replays took {sum(rawtimes):.2f} summed wall seconds. All 19 native lineage commands reproduce their logs and checkpoint bytes across eight stages, preserving seven refusals. Their summed elapsed time was {wall:.6f} seconds.

This result covers only paired coordinate {target}. The signed ledger identifies the accepted source, hashes and exact real and imaginary components of every term. The shared map manifest supports the exact transformations. The source inventories bind the binary checkpoints outside the review directory.
"""
Path('REVIEW.md').write_text(review)
