from csv import DictReader
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from re import search
from sys import argv

case=int(argv[1])
source={44:40,46:42}[case]
manifest=Path(argv[2]).resolve()
review=manifest.parent
base=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
target=base/f'probe{case}-inner'
origin=base/f'probe{source}-inner'
root=Path(__file__).resolve().parent
den=40512224221827380280140849737629696
scale=den*16*4**64
sha=lambda p:sha256(p.read_bytes()).hexdigest()
bound={name.removeprefix('./'):digest for digest,name in
       (line.split(maxsplit=1) for line in manifest.read_text().splitlines())}
assert len(bound)==len(manifest.read_text().splitlines())

def accepted(name):
    p=review/name
    assert sha(p)==bound[name]
    return p

def fractions(receipt):
    value=search(r'exact normalized real (\S+) imaginary (\S+)',receipt)
    return tuple(map(Fraction,value.groups()))

def raw_pair(text):
    value=search(r'raw(?: scalar numerator| Gaussian numerator)? (-?\d+) (?:imaginary )?(-?\d+) factor denominator (\d+)', text)
    x,y,d=map(int,value.groups())
    assert d==den
    return x,y

source_ledger=accepted(f'author-receipts/inner/author-case{source}.tsv')
assert source_ledger.read_bytes()==(origin/f'author-case{source}.tsv').read_bytes()
a=[line.split('\t') for line in source_ledger.read_text().splitlines()[:-1]]
b=(target/f'author-case{case}.tsv').read_text().splitlines()
assert len(a)==9 and len(b)==10
source_op=accepted('inner-operands.sha256')
source_hashes={Path(file).name:one for one,file in (row.split(maxsplit=1) for row in source_op.read_text().splitlines())}
table={}
with (root/'bound-author-maps.tsv').open() as file:
    for row in DictReader(file,delimiter='\t'):
        if int(row['target_cut'])==case:
            assert int(row['source_cut'])==source
            table[int(row['target_slice'])]=row
assert set(table)=={1,4,5,6,7,8}
manifest_sha=sha(manifest)
ledger_sha=sha(source_ledger)
print('slice','coordinate','pair_products','route','raw_real','raw_imaginary','normalized_real','normalized_imaginary',
      'author_receipt','source_slice','source_coordinate','source_manifest_sha256','witness_sha256',sep='\t')
total_raw=[0,0]
total_exact=[Fraction(0),Fraction(0)]
reused=0
for index,line in enumerate(b[:-1]):
    n,k,count,r,i,receipt=line.split('\t')
    values=tuple(map(Fraction,(r,i)))
    assert int(n)==index
    report=(target/receipt).read_text()
    assert fractions(report)==values
    donor_idx=donor_key=donor_manifest=witness_hash='-'
    if index in table:
        x=table[index]
        donor_idx=x['source_slice']; donor_key=x['source_coordinate']
        donor_manifest=manifest_sha
        assert (x['target_coordinate'],x['selected_products'])==(k,count)
        d_index,d_key,d_count,d_real,d_imag,_=a[int(donor_idx)]
        assert (d_index,d_key,d_count)==(donor_idx,donor_key,count)
        assert values==tuple(map(Fraction,(d_real,d_imag)))
        lfile=f'slice-{donor_idx}.pkl'
        rfile=f'slice-{n}.pkl'
        ls,rs=sha(origin/lfile),sha(target/rfile)
        assert (ls,rs)==(x['source_sha256'],x['target_sha256'])
        assert ls==source_hashes[lfile]
        witness=Path('author-maps')/x['author_witness']
        witness_hash=sha(witness)
        assert witness_hash==x['author_witness_sha256']
        for h in (ls,rs,manifest_sha,ledger_sha,witness_hash):
            assert h in report,(index,h,receipt)
        paths=[f'slice-{donor_idx}-{method}replay.out' for method in ('','four-','triangle-')]
        matches=[name for name in paths if name in bound]
        [direct]=matches
        prior=accepted(direct).read_text()
        assert fractions(prior)==values
        raw=raw_pair(prior)
        assert raw_pair(report)==raw
        route='signed witness '+x['boundary']
        reused+=1
    else:
        assert index in (0,2,3)
        if index==0:
            route='independent sparse'
            path=Path('slice-0-replay.out')
        else:
            assert receipt==f'slice-{index}-shard-sum.out'
            path=Path(f'slice-{index}-triangle-replay.out')
            route='independent pivot 1 triangle'
            assert 'independent pivot 1 ' in path.read_text()
        signed=path.read_text()
        assert fractions(signed)==values
        raw=raw_pair(signed)
    assert tuple(Fraction(x,scale) for x in raw)==values
    for p in range(2):
        total_raw[p]+=raw[p]
        total_exact[p]+=values[p]
    print(n,k,count,route,*raw,*values,receipt,donor_idx,donor_key,donor_manifest,witness_hash,sep='\t')
assert reused==6
label,re,im=b[-1].split('\t')
assert label=='sum' and tuple(total_exact)==tuple(map(Fraction,(re,im)))
print('subtotal','-','-','-',*total_raw,*total_exact,'-','-','-',manifest_sha,'-',sep='\t')
