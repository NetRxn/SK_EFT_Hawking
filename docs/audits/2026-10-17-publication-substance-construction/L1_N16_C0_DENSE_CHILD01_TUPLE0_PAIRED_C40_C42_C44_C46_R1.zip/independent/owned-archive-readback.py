from hashlib import sha256
from pathlib import Path
from subprocess import check_output

p=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
C='2ebe664acce9ee0e3f8ec8b1f0b4133c45456a79'
expected={'L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_C41_C43_C45_R1.zip':'9bac4390dcb994b731b3ff19f2e2d145644c19adf5143cb53d296e1d1c6b549a',
          'L1_N16_C0_PAIRED_TENSOR_EQUIVALENCE_R1.zip':'6cff252208e1c233a93c7f2d2f2ceb588d9531573f11be51040045b024ae2ec6'}
def git(*args):
    return check_output(['git','-C',str(p),*args])
for filename,digest in expected.items():
    rel=f'docs/audits/2026-10-17-publication-substance-construction/{filename}'
    exact=git('show',f'{C}:{rel}')
    assert sha256(exact).hexdigest()==digest
    assert exact==(p/rel).read_bytes()
    assert git('rev-parse',f'{C}:{rel}')==git('rev-parse',f'HEAD:{rel}')
    print('archive',filename,'sha256',digest,'blob',git('rev-parse',f'{C}:{rel}').decode().strip())
print('readback head',git('rev-parse','HEAD').decode().strip())
