from ast import literal_eval
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import factorial, prod
from itertools import combinations, product
from pathlib import Path
import pickle
import re

from sys import argv
from terminal_plan import plans
outer=int(argv[1])
root=Path.cwd()
author=Path(f'/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe{outer}-inner')
denominator=40512224221827380280140849737629696

def census(state,roster):
    axes,entries=literal_eval(roster.read_text())
    assert len(entries)==len(dict(entries))
    f=state['factors']
    assert set(Counter(w for scope,_,_ in f for w in scope).values())=={2}
    left,right=[f[i] for i in state['rejected_pair']]
    shared=sorted(set(left[0])&set(right[0]))
    lmatch=tuple(left[0].index(k) for k in shared)
    rmatch=tuple(right[0].index(k) for k in shared)
    lcut=tuple(left[0].index(k) for k in axes)
    left_count=Counter((tuple(row[p] for p in lmatch),tuple(row[p] for p in lcut)) for row in left[1])
    right_count=Counter(tuple(row[p] for p in rmatch) for row in right[1])
    weights=Counter()
    for (key,cut),n in left_count.items():
        if count:=n*right_count[key]:
            weights[cut]+=count
    assert weights==dict(entries) and sum(weights.values())==state['matched']
    return axes,weights,sorted(weights,key=lambda k:(weights[k],k))

def inverse_lift(state,axes,coordinate,path):
    fixed=dict(zip(axes,coordinate,strict=True))
    raw=path.read_bytes()
    child=pickle.loads(raw)
    assert child['conditioning']==state['conditioning']+list(fixed.items())
    assert child['label_partition']==state['label_partition']
    for (scope,rows,d),(small,cut_rows,e) in zip(state['factors'],child['factors'],strict=True):
        assert d==e and small==tuple(k for k in scope if k not in fixed)
        expected_rows={row:value for row,value in rows.items() if all(row[p]==fixed[k] for p,k in enumerate(scope) if k in fixed)}
        recovered={}
        for row,value in cut_rows.items():
            assignment=dict(zip(small,row,strict=True))
            assignment.update(fixed)
            recovered[tuple(assignment[k] for k in scope)]=value
        assert recovered==expected_rows
    print('PASS exact inverse lift',coordinate,sha256(raw).hexdigest(),sum(len(rows) for _,rows,_ in child['factors']))
    return child

def check_stage(path, child, length=None):
    raw=path.read_bytes()
    state=pickle.loads(raw)
    assert state['conditioning']==child['conditioning'] and state['label_partition']==child['label_partition']
    ff=state['factors']
    if length is not None:
        assert len(ff)==length
    assert set(Counter(w for scope,_,_ in ff for w in scope).values())=={2}
    assert all(d>0 and len(set(scope))==len(scope) and all(len(row)==len(scope) and len(value)==2 and any(value) and all(type(x) is int for x in value) for row,value in rows.items()) for scope,rows,d in ff)
    assert prod(d for _,_,d in ff)==denominator
    print('PASS stage',path.name,sha256(raw).hexdigest(),len(ff),sum(len(rows) for _,rows,_ in ff))
    return state

pair_pins={name:digest for digest,name in map(str.split,(root/'pair-pins.sha256').read_text().splitlines())}
paired_dir=author.parent
raw_combined=(paired_dir/f'combined-{outer}.pkl').read_bytes()
assert sha256(raw_combined).hexdigest()==pair_pins[f'combined-{outer}.pkl']
combined=check_stage(paired_dir/f'combined-{outer}.pkl',pickle.loads(raw_combined),7)
assert dict(combined['conditioning'])['R',0,6,1,1,1]==1
assert dict(combined['conditioning'])['G',0,4,2]==24
assert dict(combined['conditioning'])['J',1,4,2]==(1,)
assert combined['binary_sum']=={'summed_index':('R',0,0,2,0,1),'values':(0,1),'coordinate':(24,(1,))}
assert ('R',0,0,2,0,1) not in dict(combined['conditioning'])
check_stage(paired_dir/f'label-sum{outer}-reduced-frontier.pkl',combined,7)
parent=paired_dir/f'row-cap-physical-slice-dense-label-sum{outer}-reduced.pkl'
inner=check_stage(parent,combined,7)
assert sha256(parent.read_bytes()).hexdigest()==pair_pins[parent.name]
assert inner['matched']==int((root/'inner-products.txt').read_text())
print('PASS paired coordinate',(24,(1,)),'and 7-factor restart hash')
axes,weights,order=census(inner,author/'slice-0.roster')
assert axes==(('G',0,1,2),) and len(order)==9 and sum(weights.values())==inner['matched']
print('PASS exhaustive nine-coordinate inner roster',axes,sum(weights.values()),min(weights.values()),max(weights.values()))
if '--cuts-only' in __import__('sys').argv[1:]:
    for i,coordinate in enumerate(order):
        assert (author/f'slice-{i}.roster').read_bytes()==(author/'slice-0.roster').read_bytes()
        child=inverse_lift(inner,axes,coordinate,author/f'slice-{i}.pkl')
        check_stage(author/f'label-slice-{i}-reduced-frontier.pkl',child)
    print('PASS all nine roster coordinates and signed inverse lifts')
    raise SystemExit(0)
# Recompute the external sign and factorial normalization from the fixed
# occupation records and cube edges. Neither conditioning coordinate is used.
orbit_rows=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occupation=[]
for record in (503841882182,1461451755920):
    vertices=[]
    for vertex in range(8):
        record,digit=divmod(record,64)
        vertices.append(orbit_rows[digit])
    assert record==0
    occupation.append(vertices)
edges=[(u,v,(u^v).bit_length()-1) for u,v in combinations(range(8),2) if (u^v).bit_count()==1]
edges.sort(key=lambda edge:(edge[0],edge[2]))
total=sum(sum(row) for spin in occupation for row in spin)
factorials=prod(factorial(n) for spin in occupation for row in spin for n in row)
signed_world=sum((axis+3)*n for spin in occupation for row in spin for axis,n in enumerate(row))
cross=0
for spin in occupation:
    words=[]
    for u,v,k in edges:
        words.append((u,v,sum(spin[u])+sum(spin[v])-spin[u][k]-spin[v][k]))
    cross+=sum(m*n*sum(int(a>b) for a in (u,v) for b in (x,y))
               for (u,v,m),(x,y,n) in combinations(words,2))
phase=(-1)**((signed_world+cross)%2)
assert (total,factorials,phase)==(32,16,1)
external=Fraction(phase,factorials*4**(2*total))
assert external==Fraction(1,16*4**64)

print('PASS external phase and factorial weight',signed_world,cross,phase,factorials,total,external)
ledger=(author/f'author-case{outer}.tsv').read_text().splitlines()
assert len(ledger)==10
terminal_plan=plans(author)
values=[]
raw_values=[]
signature=r'^(?:independent )?exact normalized real (\S+) imaginary (\S+)(?: |$)'
for i,row in enumerate(ledger[:-1]):
    n,coord,count,real,imag,receipt=row.split('\t')
    assert int(n)==i and order[i]==(int(coord),) and weights[order[i]]==int(count)
    assert (author/f'slice-{i}.roster').read_bytes()==(author/'slice-0.roster').read_bytes()
    sub=inverse_lift(inner,axes,order[i],author/f'slice-{i}.pkl')
    tag=receipt.removesuffix('-contract.out')
    for p in sorted(author.glob(f'label-rescue-{i}-*-reduced-frontier.pkl')):
        check_stage(p,sub)
    for p in sorted(author.glob(f'*-dense-label-rescue-{i}-*-reduced.pkl')):
        check_stage(p,sub)
    check_stage(author/f'label-slice-{i}-reduced-frontier.pkl',sub)
    for p in sorted(author.glob(f'*-dense-label-slice-{i}-reduced.pkl')):
        check_stage(p,sub)

    if i in terminal_plan:
        assert receipt==f'slice-{i}-shard-sum.out'
        capture,triangle,pair,counts,_=terminal_plan[i]
        method='triangle' if triangle else 'four'
        state=check_stage(capture,sub,3 if triangle else 4)
        replay=(root/f'slice-{i}-{method}-replay.out').read_text()
        assert sha256(capture.read_bytes()).hexdigest() in replay
        raw_sig=r'^raw(?: scalar numerator)? (-?\d+) (?:imaginary )?(-?\d+) factor denominator (\d+)$'
        totals=[0,0]
        pivot_count=len(state['factors'][0 if triangle else pair[0]][1])
        end=0
        for k in range(8):
            log=(author/f'slice-{i}-shard-{k}.out').read_text()
            lo,hi,n,ordinal,shards=map(int,re.search(r'^left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)$',log,re.M).groups())
            assert lo==end==pivot_count*k//8 and hi==pivot_count*(k+1)//8 and (n,ordinal,shards)==(pivot_count,k,8)
            end=hi
            assert f"conditioning {sub['conditioning']} label partition {sub['label_partition']}" in log
            products,retained,probes,x,y,d=map(int,re.search(r'^closure products (\d+) retained outer matches (\d+) closure probes (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)$',log,re.M).groups())
            assert d==denominator and max(products+2*retained,probes)<=30000000
            if triangle:
                assert retained==0
            assert tuple(map(Fraction,re.search(signature,log,re.M).groups()))==tuple(Fraction(n,denominator)*external for n in (x,y))
            totals[0]+=x
            totals[1]+=y
        assert end==pivot_count
        expected_raw=tuple(map(int,re.search(raw_sig,replay,re.M).groups()))
        assert expected_raw==(*totals,denominator)
        assert f'complete shards 8 left rows {pivot_count} raw {totals[0]} {totals[1]} factor denominator {denominator}' in (author/receipt).read_text()
        print('PASS eight author shard intervals and signed totals',i,pivot_count,*totals)
    else:
        terminal=author/f'label-{tag}-reduced-frontier.pkl'
        state=check_stage(terminal,sub)
        replay=(root/f'slice-{i}-replay.out').read_text()
        assert f"conditioning {sub['conditioning']} label partition {sub['label_partition']}" in replay
        raw_sig=r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$'
    raw_re,raw_im,d=map(int,re.search(raw_sig,replay,re.M).groups())
    exact=tuple(map(Fraction,re.search(signature,replay,re.M).groups()))
    assert exact==tuple(map(Fraction,re.search(signature,(author/receipt).read_text(),re.M).groups()))==tuple(map(Fraction,(real,imag)))
    assert d==denominator and tuple(Fraction(value,d)*external for value in (raw_re,raw_im))==exact
    values.append(exact)
    raw_values.append((raw_re,raw_im))
    print('PASS independent paired case',outer,'slice',i,order[i],count,'exact normalized',*exact)
if '--cuts-only' in __import__('sys').argv[1:]:
    print('PASS all nine roster coordinates and signed inverse lifts')
    raise SystemExit(0)
label,*expected=ledger[-1].split('\t')
total=tuple(sum(column,Fraction(0)) for column in zip(*values,strict=True))
assert label=='sum' and total==tuple(map(Fraction,expected))
print('PASS exact paired case',outer,'sum',*total)

print('PASS raw subtotal',*(sum(col) for col in zip(*raw_values,strict=True)))
