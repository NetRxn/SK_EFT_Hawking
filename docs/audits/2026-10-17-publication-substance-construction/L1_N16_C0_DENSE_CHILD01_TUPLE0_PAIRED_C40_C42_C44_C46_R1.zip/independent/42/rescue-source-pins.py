from hashlib import sha256
from io import BytesIO
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile

root=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
from sys import argv
author=Path(f'/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe{argv[1]}-inner')
commit='2ebe664acce9ee0e3f8ec8b1f0b4133c45456a79'
refs = [
    ('MIDDLE23','author/inner',('contract-peer.py','peer_pair.py','reduce-open.py')),
    ('HEAVY47','author/pair/heavy47-inner',('close-four-shards.py','triangle-shards.py')),
]
for case, origin, scripts in refs:
    name=f'docs/audits/2026-10-17-publication-substance-construction/L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_{case}_R1.zip'
    raw=check_output(['git','-C',str(root),'show',f'{commit}:{name}'])
    assert raw==(root/name).read_bytes()
    print('archive',case,sha256(raw).hexdigest())
    with ZipFile(BytesIO(raw)) as archived:
        for script in scripts:
            seed=archived.read(f'{origin}/{script}')
            if not (author/script).exists():
                assert case=='HEAVY47'
                continue
            current=(author/script).read_bytes()
            assert seed == current, script
            print('exact',script,sha256(current).hexdigest())
