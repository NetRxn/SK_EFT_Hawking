from hashlib import sha256
from io import BytesIO
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile

publication=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
author=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
pair=author/'tuple0-pair-equivalence'
commit='2ebe664acce9ee0e3f8ec8b1f0b4133c45456a79'
directory='docs/audits/2026-10-17-publication-substance-construction'
def git(*cmd):
    return check_output(['git','-C',str(publication),*cmd])
def archive(name):
    rel=f'{directory}/{name}.zip'
    raw=git('show',f'{commit}:{rel}')
    assert raw==(publication/rel).read_bytes()
    print(commit,git('rev-parse',f'{commit}:{rel}').decode().strip(),sha256(raw).hexdigest(),rel)
    return ZipFile(BytesIO(raw))
with archive('L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_MIDDLE23_R1') as prev, archive('L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1') as sep:
    for name in ('sum-branches.py','sum-branches-checked.py'):
        assert prev.read(f'independent/author-receipts/paired/{name}')==(pair/name).read_bytes()
        print('archive exact',name)
    inventory=prev.read('independent/paired-operands.sha256').decode()
    for path in (*sorted(author.glob('row-cap-physical-slice-dense-label-tuple0-branch-*-reduced.pkl')),author/'tuple0-branch0-pilot/pilot.roster'):
        line=f'{sha256(path.read_bytes()).hexdigest()}  {path}'
        assert line in inventory.splitlines()
        print(line)
    for name in ('exact-multicut.py','reduce-label-frontier.py','contract-reduced-label.py','checkpoint/quotient.py'):
        for number in (42,):
            origin=pair/f'probe{number}-inner'/name
            assert sep.read(name)==origin.read_bytes()
            print('separator exact',number,name)
