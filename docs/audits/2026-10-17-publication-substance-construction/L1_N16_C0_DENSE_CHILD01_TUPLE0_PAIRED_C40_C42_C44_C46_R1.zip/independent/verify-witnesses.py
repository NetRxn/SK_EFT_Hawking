from collections import Counter, defaultdict
from csv import DictReader
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads

from sources import PAIRS, ledger, swap

N = 40512224221827380280140849737629696
SCALE = N * 16 * 4**64

def verify(left_path,right_path,witness,with_signs):
    perm,old_axes,new_axes,maps,*charge = loads(decompress(witness.read_bytes()))
    assert len(charge)==int(with_signs)
    negative = {edge:set(values) for edge,values in charge[0].items()} if charge else {}
    L,R=[loads(path.read_bytes())['factors'] for path in (left_path,right_path)]
    assert sorted(perm)==list(range(len(R))) and len(L)==len(R)
    R=[R[i] for i in perm]
    assert set(old_axes)==set(new_axes)==set(maps)
    assert set(negative)<=set(maps)
    for factors, scopes in ((L,old_axes),(R,new_axes)):
        assert prod(d for _,_,d in factors)==N
        assert all(n==2 for n in Counter(axis for ws,_,_ in factors for axis in ws).values())
        for i,(axes,_,_) in enumerate(factors):
            configured=[q for edge,ws in scopes.items() if i in edge for q in ws]
            assert len(axes)==len(set(configured))==len(configured) and set(axes)==set(configured)
        for (i,j),edge_axes in scopes.items():
            assert 0<=i<j<len(factors)
            assert edge_axes and set(edge_axes)==set(factors[i][0]) & set(factors[j][0])
    for edge,m in maps.items():
        assert len(m)==len(set(m.values()))
        assert set(negative.get(edge,())) <= set(m)
    seen=defaultdict(set)
    checked=flipped=0
    for i,((axes,A,d),(targets,B,e)) in enumerate(zip(L,R,strict=True)):
        assert len(A)==len(B) and d==e
        edges=[]
        for edge in sorted(maps):
            if i in edge:
                here=tuple(axes.index(w) for w in old_axes[edge])
                there=tuple(targets.index(w) for w in new_axes[edge])
                edges.append((edge,here,there))
        for row,(x,y) in A.items():
            candidate=[None]*len(targets)
            sign=1
            for edge,here,there in edges:
                local=tuple(row[p] for p in here)
                mapped=maps[edge][local]
                for k,value in zip(there,mapped,strict=True):
                    candidate[k]=value
                seen[edge].add(local)
                if local in negative.get(edge,()):
                    sign=-sign
            assert (x or y) and B[tuple(candidate)]==(sign*x,sign*y)
            flipped+=sign<0
            checked+=1
        # Full domain bijection makes the row map injective on the axis cover.
        # Equal table sizes and every exact target lookup then establish surjectivity.
    assert all(seen[edge]==set(m) for edge,m in maps.items())
    return len(L),len(maps),sum(map(len,maps.values())),sum(map(len,negative.values())),checked,flipped

def pins():
    out={}
    for row in Path('source-pins.tsv').read_text().splitlines():
        p=row.split('\t')
        if p[0]=='input':
            _,case,name,sha=p
            out[int(case),name]=sha
    return out

if __name__=='__main__':
    P=pins()
    rows={}
    for path,field in [('edge-screen.tsv','map'),('gauge-screen.tsv','map')]:
        with Path(path).open() as fh:
            rows[field,path]={(int(r['left']),int(r['right']),int(r['left_inner'])):r for r in DictReader(fh,delimiter='\t')}
    E=rows['map','edge-screen.tsv']
    G=rows['map','gauge-screen.tsv']
    print('left','right','left_inner','right_inner','role','factors','edges','edge_values',
          'negative_edge_values','exact_rows','flipped_rows','selected_products',
          'raw_real','raw_imaginary','normalized_real','normalized_imaginary',
          'left_sha256','right_sha256','certificate',sep='\t',flush=True)
    used=set()
    for l,r in PAIRS:
        A,B=ledger(l),ledger(r)
        assert len(A)==len(B)==9 and {swap.get(k,k) for k in A}==set(B)
        for k in sorted(A):
            t=swap.get(k,k)
            a,n,re,im=A[k]
            b,nr,real,imag=B[t]
            assert (n,re,im)==(nr,real,imag)
            direct=E[l,r,k]
            signed=direct['map']!='True'
            if signed:
                assert G[l,r,k]['map']=='True' and "'original'" in G[l,r,k]['diagnostic']
                w=Path(f'witnesses-gauge/terminal-{l}-{r}-{k}-{t}.pkl.gz')
            else:
                assert "'untrimmed'" in direct['diagnostic']
                w=Path(f'witnesses/{l}-{r}-{k}-{t}.pkl.gz')
            assert w not in used
            used.add(w)
            ha,hb=[sha256(f.read_bytes()).hexdigest() for f in (a,b)]
            assert (ha,hb)==(direct['left_sha256'],direct['right_sha256'])
            assert (ha,hb)==(P[l,a.name],P[r,b.name])
            statistics=verify(a,b,w,signed)
            raw=(re*SCALE,im*SCALE)
            assert all(z.denominator==1 for z in raw)
            print(l,r,k,t,'edge signs' if signed else 'direct',*statistics,n,*raw,re,im,ha,hb,w,sep='\t',flush=True)
        assert sum(v[2] for v in A.values())==sum(v[2] for v in B.values())
        assert sum(v[3] for v in A.values())==sum(v[3] for v in B.values())
    assert len(used)==36
