from csv import DictReader
from gzip import decompress
from hashlib import sha256
from pathlib import Path
from pickle import loads
from shutil import copyfile

base=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
observed={(r['left'],r['right'],r['source_inner'],r['target_inner']):r
          for r in DictReader(Path('exact-map-checks.tsv').open(),delimiter='\t')}
actual=(base/'map-neighbor-raw.tsv').read_text().splitlines()
assert len(actual)==len(observed)==12
print('source_cut','target_cut','source_coordinate','target_coordinate','source_slice','target_slice',
      'selected_products','boundary','source_sha256','target_sha256','factors','edges','edge_values',
      'negative_values','checked_rows','flipped_rows','author_witness','author_witness_sha256',
      'review_witness','review_witness_sha256',sep='\t')
for row in actual:
    a,b,k,h,i,j,n,mode,s,t,f,e,v,g,r,c,path=row.split('\t')
    expected=observed[a,b,k,h]
    assert path==f'map-{a}-{b}-{k}-{h}.pkl.gz'
    assert mode=={'raw':'original','support-pruned':'trim'}[expected['method']]
    ordinal=('source_idx','target_idx','products','source_sha256','target_sha256',
             'factors','edges','edge_values','negative_values','verified_rows','flipped_rows')
    assert tuple(expected[name] for name in ordinal)==(i,j,n,s,t,f,e,v,g,r,c)
    vendor=(base/path).read_bytes()
    reviewer=Path(expected['witness']).read_bytes()
    assert loads(decompress(vendor))==loads(decompress(reviewer))
    assert sha256(reviewer).hexdigest()==expected['certificate_sha256']
    local=Path(b)/'author-maps'/path
    local.parent.mkdir(parents=True,exist_ok=True)
    copyfile(base/path,local)
    print(row,sha256(vendor).hexdigest(),expected['witness'],sha256(reviewer).hexdigest(),sep='\t')
for target in ('44','46'):
    copyfile(base/'map-neighbor-raw.tsv',Path(target)/'author-maps/map-neighbor-raw.tsv')
