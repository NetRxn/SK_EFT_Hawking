"""Compare exact saved tensor states by edge-block bijections, without contracting."""
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import combinations, permutations
from math import prod
from pathlib import Path
from pickle import loads
from time import perf_counter

from sources import PAIRS, N, ledger, swap

def model(path):
    obj=loads(path.read_bytes())
    f=obj['factors']
    assert prod(d for _,_,d in f)==N
    assert set(Counter(a for axes,_,_ in f for a in axes).values())=={2}
    return f

def edge_model(factors):
    scopes=[set(axes) for axes,_,_ in factors]
    edge_scopes={}
    for a,b in combinations(range(len(factors)),2):
        shared=tuple(sorted(scopes[a]&scopes[b]))
        if shared:
            edge_scopes[a,b]=shared
    view=[]
    for i,(axes,table,den) in enumerate(factors):
        edges=tuple(e for e in edge_scopes if i in e)
        positions=tuple(tuple(axes.index(w) for w in edge_scopes[e]) for e in edges)
        assert sum(map(len,positions))==len(axes)
        out={tuple(tuple(row[p] for p in index) for index in positions):value for row,value in table.items()}
        assert len(out)==len(table)
        view.append((edges,out,den))
    return view,edge_scopes

def marginals(graph, colors, use_coefficient=True):
    signatures=defaultdict(lambda:defaultdict(Counter))
    for factor,(edges,rows,_) in enumerate(graph):
        for row,z in rows.items():
            context=tuple(colors[e][v] for e,v in zip(edges,row,strict=True))
            if not use_coefficient:
                z=z[0]*z[0]+z[1]*z[1]
            for k,(edge,value) in enumerate(zip(edges,row,strict=True)):
                signatures[edge][value][(factor,z,context[:k],context[k+1:])]+=1
    return {edge:{v:tuple(sorted(counts.items())) for v,counts in hist.items()}
            for edge,hist in signatures.items()}

def domains(graph):
    out=defaultdict(set)
    for edges,rows,_ in graph:
        for index,e in enumerate(edges):
            out[e].update(row[index] for row in rows)
    return out

def trim(graph):
    rows=[r for _,r,_ in graph]
    pos={e:[(i,es.index(e)) for i,(es,_,_) in enumerate(graph) if e in es]
         for e in domains(graph)}
    rounds=0
    while True:
        changed=False
        for (i,p),(j,q) in pos.values():
            one={r[p] for r in rows[i]}
            other={r[q] for r in rows[j]}
            if one==other: continue
            common=one&other
            if one!=common: rows[i]={r:z for r,z in rows[i].items() if r[p] in common}
            if other!=common: rows[j]={r:z for r,z in rows[j].items() if r[q] in common}
            changed=True
        if not changed: break
        rounds+=1
    return [(es,r,d) for (es,_,d),r in zip(graph,rows,strict=True)],rounds

def try_map(left,right,maps):
    for (es,A,d),(fs,B,e) in zip(left,right,strict=True):
        if len(A)!=len(B) or d!=e:
            return False
        assert es==fs
        for row,value in A.items():
            candidate=tuple(maps[edge][v] for edge,v in zip(es,row,strict=True))
            if B.get(candidate)!=value:
                return False
    return True

def candidate(left,right):
    la,ra=domains(left),domains(right)
    if set(la)!=set(ra):
        return None,'incidence'
    if any(len(la[e])!=len(ra[e]) for e in la):
        mismatch=tuple((e,len(la[e]),len(ra[e])) for e in la if len(la[e])!=len(ra[e]))
        return None,('edge-cardinality',mismatch)
    colorsA={e:dict.fromkeys(v,0) for e,v in la.items()}
    colorsB={e:dict.fromkeys(v,0) for e,v in ra.items()}
    for style in ('identity-first','lex'):
        substitutions={}
        for edge,col in colorsA.items():
            A=set(col); B=set(colorsB[edge])
            if style=='identity-first':
                shared=A&B
                m=dict(zip(sorted(A-shared),sorted(B-shared),strict=True))
                m.update({v:v for v in shared})
            else:
                m=dict(zip(sorted(A),sorted(B),strict=True))
            substitutions[edge]=m
        if try_map(left,right,substitutions):
            return substitutions,style
    for iteration in range(3):
        a=marginals(left,colorsA)
        b=marginals(right,colorsB)
        for edge in a:
            A=a[edge]
            B=b[edge]
            matching=Counter((colorsA[edge][v],s) for v,s in A.items())
            candidate=Counter((colorsB[edge][v],s) for v,s in B.items())
            if matching!=candidate:
                return None,('signed-marginal-refinement',iteration,edge,len(matching),len(candidate))
        for edge in a:
            patterns={}
            for M,S in ((colorsA,a),(colorsB,b)):
                for k in M[edge]:
                    value=(M[edge][k],S[edge][k])
                    M[edge][k]=patterns.setdefault(value,len(patterns))
        substitutions={}
        unique=0
        for edge,col in colorsA.items():
            A=defaultdict(set)
            B=defaultdict(set)
            for v,c in col.items(): A[c].add(v)
            for v,c in colorsB[edge].items(): B[c].add(v)
            m={}
            for color,vs in A.items():
                ws=B[color]
                if len(vs)==1: unique+=1
                common=vs&ws
                m.update(zip(sorted(vs-common),sorted(ws-common),strict=True))
                m.update({v:v for v in common})
            substitutions[edge]=m
        if try_map(left,right,substitutions):
            return substitutions,('signed-refinement',iteration,unique)
    return None,('undecided',unique,sum(map(len,colorsA.values())))

def search(left,right):
    L,LS=edge_model(left)
    sizes=lambda r:tuple((len(rows),den) for _,rows,den in r)
    old=sizes(L)
    if old==tuple((len(rows),den) for _,rows,den in right):
        perm_only=[tuple(range(len(L)))]
    else:
        perm_only=[]
    alternate=(p for p in permutations(range(len(L))) if p not in perm_only and
               old==tuple((len(right[i][1]),right[i][2]) for i in p))
    diagnostics=[]
    for perm in (*perm_only,*alternate):
        R,RS=edge_model([right[i] for i in perm])
        if tuple(es for es,_,_ in L)!=tuple(es for es,_,_ in R):
            diagnostics.append((perm,'incidence'))
            continue
        M,result=candidate(L,R)
        if M is not None:
            return (perm,LS,RS,M),('untrimmed',result,0,0,sizes(L),sizes(R))
        diagnostics.append((perm,'untrimmed',result))
        A,r=trim(L);B,s=trim(R)
        if r or s:
            M,result=candidate(A,B)
            if M is not None:
                return (perm,LS,RS,M),('trimmed',result,r,s,sizes(A),sizes(B))
            diagnostics.append((perm,'trimmed',result,sizes(A),sizes(B)))
    return None,diagnostics

if __name__=='__main__':
    import sys
    left,right,key=map(int,sys.argv[1:])
    keyR=swap.get(key,key)
    x,y=ledger(left)[key],ledger(right)[keyR]
    assert x[1:]==y[1:]
    start=perf_counter()
    result,diagnostics=search(model(x[0]),model(y[0]))
    print('case',left,right,key,keyR,'sha',*(sha256(v[0].read_bytes()).hexdigest() for v in (x,y)),flush=True)
    print('result',bool(result),diagnostics,'seconds',perf_counter()-start,flush=True)
    if result:
        p,s,t,m=result
        print('right factor order',p,flush=True)
        for edge,subs in sorted(m.items()):
            print('edge',edge,s[edge],t[edge],len(subs), list(subs.items()),flush=True)
