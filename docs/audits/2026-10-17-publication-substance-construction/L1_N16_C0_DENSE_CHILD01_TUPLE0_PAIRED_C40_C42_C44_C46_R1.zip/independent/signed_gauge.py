"""Find an exactly canceling sign on the endpoints of each shared edge value."""
from collections import Counter, defaultdict
from gzip import open as compress
from hashlib import sha256
from itertools import permutations
from pathlib import Path
from pickle import dump
from time import perf_counter

from edge_relabel import edge_model, domains, marginals, model, trim
from sources import ledger, swap

def magnitude(z):
    return z[0]*z[0]+z[1]*z[1]

def check_mapped_magnitudes(L,R,to):
    for (es,A,d),(fs,B,e) in zip(L,R,strict=True):
        assert es==fs and d==e
        if len(A)!=len(B):return False
        for row,coef in A.items():
            candidate=tuple(to[edge][v] for edge,v in zip(es,row,strict=True))
            z=B.get(candidate)
            if z is None or magnitude(coef)!=magnitude(z):
                return False
    return True

def recover(L,R,to):
    domains_left=domains(L)
    bitpos={(edge,v):i for i,(edge,v) in enumerate((edge,v) for edge in sorted(domains_left) for v in sorted(domains_left[edge]))}
    basis={}
    for (es,A,d),(fs,B,e) in zip(L,R,strict=True):
        assert es==fs and d==e
        for row,coef in A.items():
            target=tuple(to[edge][v] for edge,v in zip(es,row,strict=True))
            z=B[target]
            if z==coef:
                sign=0
            elif z==(-coef[0],-coef[1]):
                sign=1
            else:
                return None,'ratio is not a sign'
            edge_bits=sum(1<<bitpos[edge,v] for edge,v in zip(es,row,strict=True))
            while edge_bits:
                slot=edge_bits.bit_length()-1
                if slot not in basis:
                    basis[slot]=edge_bits,sign
                    break
                prior,value=basis[slot]
                edge_bits^=prior
                sign^=value
            if not edge_bits and sign:
                return None,'fixed map has inconsistent sign equations'
    assignment=0
    for p,(mask,sign) in sorted(basis.items()):
        flag=(assignment&mask).bit_count()%2
        if flag!=sign:
            assignment|=(1<<p)
    support={edge:tuple(v for v in sorted(values) if (assignment>>bitpos[edge,v])&1)
             for edge,values in domains_left.items()}
    for (es,A,d),(fs,B,e) in zip(L,R,strict=True):
        for row,coef in A.items():
            target=tuple(to[edge][v] for edge,v in zip(es,row,strict=True))
            mask=sum(1<<bitpos[edge,v] for edge,v in zip(es,row,strict=True))
            sign=(-1)**((assignment&mask).bit_count()%2)
            assert B[target]==(sign*coef[0],sign*coef[1])
    return support,('signs',len(bitpos),len(basis),assignment.bit_count())

def gauge(L,R):
    la,ra=domains(L),domains(R)
    if any(len(la[e])!=len(ra[e]) for e in la):
        return None,('edge-cardinality',tuple((e,len(la[e]),len(ra[e])) for e in la if len(la[e])!=len(ra[e])))
    colors=[{edge:dict.fromkeys(vals,0) for edge,vals in ds.items()} for ds in (la,ra)]
    tried=[]
    for iteration in range(4):
        for identity_first in (True,False):
            M={}
            for edge in la:
                A,B=(defaultdict(set),defaultdict(set))
                for group,index in ((A,0),(B,1)):
                    for v,c in colors[index][edge].items(): group[c].add(v)
                m={}
                for c,x in A.items():
                    y=B[c]
                    sharing=x&y if identity_first else set()
                    m.update({v:v for v in sharing})
                    m.update(zip(sorted(x-sharing),sorted(y-sharing),strict=True))
                M[edge]=m
            if check_mapped_magnitudes(L,R,M):
                charges,proof=recover(L,R,M)
                if charges is not None:
                    return (M,charges),(iteration,identity_first,proof)
                tried.append((iteration,identity_first,proof))
        sigs=[marginals(G,C,use_coefficient=False) for G,C in zip((L,R),colors,strict=True)]
        for edge in la:
            left,right=[Counter((C[edge][k],v) for k,v in S[edge].items()) for C,S in zip(colors,sigs,strict=True)]
            if left!=right:
                # Edges have fixed incidence. Record a full mismatching signature and multiplicities.
                key=next(k for k in left | right if left[k]!=right[k])
                return None,('magnitude-marginal-refinement',iteration,edge,left[key],right[key],key)
        for edge in la:
            canon={}
            for c,s in zip(colors,sigs,strict=True):
                for x in c[edge]:
                    key=c[edge][x],s[edge][x]
                    c[edge][x]=canon.setdefault(key,len(canon))
    return None,('undecided',tried)

def search_gauge(left,right):
    L,LS=edge_model(left)
    size=lambda f:tuple((len(r),d) for _,r,d in f)
    expected=size(L)
    logs=[]
    for perm in permutations(range(len(right))):
        R,RS=edge_model([right[i] for i in perm]) if expected==tuple((len(right[i][1]),right[i][2]) for i in perm) else (None,None)
        if R is None: continue
        if tuple(es for es,_,_ in L)!=tuple(es for es,_,_ in R): continue
        sol,trial=gauge(L,R)
        if sol is not None:
            return (perm,LS,RS,*sol),('original',trial)
        logs.append(('original',perm,trial))
        T,a=trim(L); U,b=trim(R)
        if a or b:
            sol,trial=gauge(T,U)
            if sol is not None:
                return (perm,LS,RS,*sol),('trim',trial)
            logs.append(('trim',perm,trial))
    return None,logs

if __name__=='__main__':
    import sys
    l,r,k=map(int,sys.argv[1:])
    rk=swap.get(k,k)
    left,right=ledger(l)[k],ledger(r)[rk]
    assert left[1:]==right[1:]
    t=perf_counter()
    proof,outcome=search_gauge(model(left[0]),model(right[0]))
    if proof:
        with compress(f'gauge-{l}-{r}-{k}-{rk}.pkl.gz','wb',compresslevel=1) as out:
            dump(proof,out,protocol=5)
    print(l,r,k,rk,bool(proof),perf_counter()-t,outcome,sep='\t')
