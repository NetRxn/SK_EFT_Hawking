from fractions import Fraction
from pathlib import Path

base=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
PAIRS=((28,30),(29,31),(32,36),(34,38))
N=40512224221827380280140849737629696
swap={48:192,192:48}
def ledger(i):
    d=base/f'probe{i}-inner'
    out={}
    for row in (d/f'author-case{i}.tsv').read_text().splitlines()[:-1]:
        idx,k,n,re,im,log=row.split('\t')
        if 'shard-sum' not in log:
            f=d/f'label-{log.removesuffix("-contract.out")}-reduced-frontier.pkl'
        elif i<32 or int(idx)<4:
            f=d/f'join-cap-dense-label-rescue-{idx}-1-reduced.pkl'
        else:
            f=d/f'row-cap-physical-slice-dense-label-rescue-{idx}-1-reduced.pkl'
        out[int(k)]=(f,int(n),Fraction(re),Fraction(im))
    return out
