from ast import literal_eval
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from pickle import dumps, loads
from runpy import run_path
import sys

root, checker, records, package = map(lambda s: Path(s).resolve(), sys.argv[1:])
sys.path.insert(0, str(checker))
base = run_path(str(checker/'verify-witnesses.py'))
early = (checker/'verify-early.py').read_text()
namespace = {'dumps':dumps,'loads':loads}
exec(early[early.index('class MemoryOperand'):early.index('def initial')],namespace)
prune = namespace['prune']

def operand(cut, index, label, matches):
    sub = root/f'probe{cut}-inner'
    axes, rows = literal_eval((sub/f'slice-{index}.roster').read_text())
    assert axes == (('G',0,1,2),)
    ordered = sorted(rows,key=lambda row:(row[1],row[0]))
    assert len(ordered)==len(dict(ordered))==9
    assert ordered[index]==((label,),matches)
    return sub/f'slice-{index}.pkl'

def digest(file):
    return sha256(file.read_bytes()).hexdigest()

covered = {}
for line in records.read_text().splitlines():
    left,right,k,h,i,j,matched,operation,left_digest,right_digest,*tail = line.split('\t')
    left,right,k,h,i,j,matched = map(int,(left,right,k,h,i,j,matched))
    assert (left,right) in ((40,44),(42,46))
    assert h=={48:192,192:48}.get(k,k)
    L,R=operand(left,i,k,matched),operand(right,j,h,matched)
    assert (digest(L),digest(R))==(left_digest,right_digest)
    exact = (L,R)
    if operation=='trim':
        first, nl=prune(L)
        second, nr=prune(R)
        assert nl==nr
        exact=first,second
    else:
        assert operation=='original'
    witness=records.parent/tail[-1]
    counts = base['verify'](*exact,witness,True)
    assert counts==tuple(map(int,tail[:-1]))
    table=package/'author'/str(left)/f'author-case{left}.tsv'
    row=table.read_text().splitlines()[i].split('\t')
    assert tuple(map(int,row[:3]))==(i,k,matched)
    review_manifest=package/'independent'/str(left)/'review-manifest.portable.sha256'
    assert review_manifest.is_file(),review_manifest
    real,imaginary=map(Fraction,row[3:5])
    raw=[value*base['SCALE'] for value in (real,imaginary)]
    assert all(value.denominator==1 for value in raw)
    assert h not in covered.setdefault(right,set())
    covered[right].add(h)
    print(f'cut {left} inner {k} -> cut {right} inner {h}',operation,*counts,sep='\t',flush=True)
    destination=root/f'probe{right}-inner'/f'slice-{j}-equivalence.out'
    text=(f'basis cut {left} inner {k}, candidate cut {right} inner {h}\n'
          f'input SHA256 {left_digest} {right_digest}\n'
          f'witness SHA256 {digest(witness)}\n'
          f'accepted source review manifest {digest(review_manifest)}\n'
          f'source ledger SHA256 {digest(table)}\n'
          f'boundary {operation}, exact factor/edge/value/negative/row/flipped counts {counts}\n'
          f'raw Gaussian numerator {raw[0]} {raw[1]} factor denominator {base["N"]}\n'
          f'exact normalized real {real} imaginary {imaginary}\n')
    if destination.is_file():
        assert destination.read_text()==text
    else:
        with destination.open('x') as stream:
            stream.write(text)
assert covered=={cut:{48,80,96,144,160,192} for cut in (44,46)},covered
