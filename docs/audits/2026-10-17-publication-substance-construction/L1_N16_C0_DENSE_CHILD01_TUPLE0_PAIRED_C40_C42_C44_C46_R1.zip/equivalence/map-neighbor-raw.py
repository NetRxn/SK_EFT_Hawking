from ast import literal_eval
from concurrent.futures import ProcessPoolExecutor
from gzip import compress
from hashlib import sha256
from pathlib import Path
from pickle import dumps
from runpy import run_path
from sys import path

root = Path(__file__).resolve().parent
prior = Path('/private/tmp/l1-paired-reuse-screen.ugYgXU')
path.insert(0, str(prior))
from edge_relabel import model
from signed_gauge import search_gauge

verify = run_path(str(prior/'verify-witnesses.py'))['verify']
namespace = {'dumps': dumps, 'loads': __import__('pickle').loads}
early = (prior/'verify-early.py').read_text()
exec(early[early.index('class MemoryOperand'):early.index('def initial')], namespace)
prune = namespace['prune']

def roster(cut):
    sub = root/f'probe{cut}-inner'
    axes, rows = literal_eval((sub/'slice-0.roster').read_text())
    assert axes == (('G',0,1,2),)
    ordered = sorted(rows, key=lambda row:(row[1],row[0]))
    return {label[0]:(i,n) for i,(label,n) in enumerate(ordered)}

def run(work):
    left, right, label, target = work
    i,n = roster(left)[label]
    j,m = roster(right)[target]
    assert n == m
    L,R = (root/f'probe{c}-inner'/f'slice-{k}.pkl' for c,k in ((left,i),(right,j)))
    witness, detail = search_gauge(model(L), model(R))
    if witness is None:
        return (*work,i,j,n,'no map',repr(detail))
    receipt = root/f'map-{left}-{right}-{label}-{target}.pkl.gz'
    with receipt.open('xb') as out:
        out.write(compress(dumps(witness,protocol=5),mtime=0))
    original = [sha256(p.read_bytes()).hexdigest() for p in (L,R)]
    operands = (L,R)
    if detail[0] == 'trim':
        l, nl = prune(L)
        r, nr = prune(R)
        assert nl == nr
        operands = (l,r)
    exact = verify(*operands,receipt,True)
    return (*work,i,j,n,detail[0],*original,*exact,receipt.name)

if __name__ == '__main__':
    targets = {48:192,192:48}
    tasks = [(left,right,label,targets.get(label,label)) for left,right in ((40,44),(42,46))
             for label in (48,80,96,144,160,192)]
    with ProcessPoolExecutor(max_workers=2) as workers:
        for result in workers.map(run,tasks):
            print(*result,sep='\t',flush=True)
