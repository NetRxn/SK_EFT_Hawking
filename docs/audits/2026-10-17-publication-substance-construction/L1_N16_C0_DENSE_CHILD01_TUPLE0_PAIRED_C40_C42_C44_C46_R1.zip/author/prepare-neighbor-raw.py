from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
reference = root/'probe28-inner'
primary_scripts = ('run-primary.py','exact-multicut.py','reduce-label-frontier.py',
                   'contract-reduced-label.py','contract-peer.py','peer_pair.py','reduce-open.py')

def command(scratch, script, arguments, receipt, allowed=(0,), timeout=450):
    start=time.monotonic()
    with (scratch/receipt).open('xb') as out:
        run=subprocess.run([sys.executable,'-u',script,*arguments],cwd=scratch,stdout=out,
                           stderr=subprocess.STDOUT,timeout=timeout)
    if run.returncode not in allowed:
        raise RuntimeError((scratch,script,run.returncode))
    return run.returncode,round(time.monotonic()-start,3)

def solve(index):
    sub=root/f'probe{index}-inner'
    sub.mkdir()
    for script in primary_scripts:
        shutil.copyfile(reference/script,sub/script)
    shutil.copytree(reference/'checkpoint',sub/'checkpoint')
    sample=root/f'combined-{index}.pkl'
    tag=f'sum{index}'
    timings=[]
    if index==29:
        assert sample.is_file()
        with sample.open('rb') as stream:
            digest=hashlib.file_digest(stream,'sha256').hexdigest()
        assert f'{digest}  {sample.name}' in (root/f'neighbor29-admitted.sha256').read_text().splitlines()
    else:
        timings.append(('combine',*command(root,'sum-branches-checked.py',[str(index)],f'combine-{index}.out')))
    timings.append(('reduce',*command(root,'reduce-label-frontier.py',[sample.name,tag],f'reduce-{index}.out')))
    cap_result=command(root,'contract-reduced-label.py',[tag],f'contract-{index}.out',(0,2))
    timings.append(('outer',*cap_result))
    if cap_result[0]==2:
        restarts=sorted(root.glob(f'*-dense-label-{tag}-reduced.pkl'))
        assert len(restarts)==1,restarts
        for i in range(9):
            timings.append((f'raw-slice-{i}',*command(sub,'exact-multicut.py',
                            [str(restarts[0]),f'slice-{i}.pkl',str(i)],f'slice-{i}-plan.out')))
        check = (sub/'slice-0.roster').read_bytes()
        assert all((sub/f'slice-{i}.roster').read_bytes()==check for i in range(9))
    with (sub/'wall-timing.tsv').open('x') as out:
        for label,status,secs in timings:
            print(label,status,secs,sep='\t',file=out)
    print(index,'generic stages terminal',timings,flush=True)

with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(solve,map(int,sys.argv[1:])))
