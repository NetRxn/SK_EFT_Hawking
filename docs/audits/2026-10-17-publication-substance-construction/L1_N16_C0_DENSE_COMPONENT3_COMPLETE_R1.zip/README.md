# Exact complete L1 component 3 contribution

The signed geometric cover selects eight representatives for this original
component. The reviewed preparation proves Groups 134 and 164 are exact
zeros. The six remaining groups have independently verified complete signed
values. For each selected group the coefficient 192 includes source weight
48 and both pairing factors. The component identity equates sums across
the two sides. Individual mirrored group values require separate evidence.

In the publication audit directory, use `shasum -a 256 -c INPUTS.sha256`
with this package's input manifest. From the extracted evidence directory,
run `python3 -B retally-component.py AUDIT_DIRECTORY | cmp - COMPONENT_3.tsv`.
The complete component has zero imaginary part. Other components and the
full coefficient remain open.
