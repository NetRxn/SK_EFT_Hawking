"""Recompose the original component 3 from reviewed representative evidence."""
from ast import literal_eval
from csv import DictReader
from fractions import Fraction
from io import BytesIO
from pathlib import Path
from sys import argv
from zipfile import ZipFile

audit = Path(argv[1])
overrides = dict((int(group), Path(path)) for group, path in (arg.split('=', 1) for arg in argv[2:]))

def rows(archive, member):
    return list(DictReader(archive.read(member).decode().splitlines(), delimiter='\t'))

def group_name(group):
    return f'L1_N16_C0_DENSE_GROUP{group}_COMPLETE_R1.zip'

with ZipFile(audit/'L1_N16_C0_DENSE_GEOMETRY_COVER_R1.zip') as root:
    with ZipFile(BytesIO(root.read('ACTUAL_REVIEW.zip'))) as review:
        with ZipFile(BytesIO(review.read('candidate.zip'))) as cover:
            component, = [row for row in rows(cover,'components.tsv') if row['id'] == '3']
            selected = literal_eval(component['selected_side'])
            mirror = literal_eval(component['other_side'])
            pairs = {int(line.split('\t')[0]): int(line.split('\t')[1])
                     for line in cover.read('gamma-pairs.tsv').decode().splitlines()[1:]}
            directed = len(pairs)
assert set(selected) == {128,134,158,164,183,189,201,207}
assert len(selected) == len(mirror) == 8 and len(set(selected+mirror)) == 16
assert directed == 1936 and len(set(selected+mirror+[pairs[g] for g in selected+mirror])) == 32
assert component['kind'] == 'K8,8' and component['whole_pair_weight'] == '192'

with ZipFile(audit/'L1_N16_C0_DENSE_COMPONENT3_PREPARATION_R1.zip') as prep:
    prepared = {int(row['group']): row for row in rows(prep, 'group-preparation.tsv')}
assert set(prepared) == set(selected)-{128}
zeros = {group for group, row in prepared.items() if row['scope']=='whole_group_zero'}
assert zeros == {134,164}
for group in zeros:
    assert literal_eval(prepared[group]['zero_original_ordinals']) == list(range(8))

def weighted_group(group):
    if group in zeros:
        return Fraction(0)
    with ZipFile(overrides.get(group,audit/group_name(group))) as receipt:
        if group == 128:
            whole, = [row for row in rows(receipt,'verified-group128.tsv') if row['scope']=='group128']
            assert Fraction(whole['imaginary']) == 0
            return Fraction(whole['exact real'])*192
        ledger = rows(receipt,'scalar.tsv')
        assert [int(row['ordinal']) for row in ledger] == list(range(8))
        total = Fraction()
        for row in ledger:
            real = int(row.get('raw_real',row.get('raw_re')))
            imag = int(row.get('raw_imag',row.get('raw_im')))
            den = int(row['factor_denominator'])
            assert den > 0 and den == int(prepared[group]['denominator']) and imag == 0
            if int(row['ordinal']) in (1,3):
                assert real == 0
            total += Fraction(real,den)
        return total*192/(16*4**64)

total = Fraction()
print('group\tcover_weight\tweighted_exact_real\tweighted_exact_imag')
for group in selected:
    value = weighted_group(group)
    total += value
    print(group,192,value,0,sep='\t')
print('original selected groups',','.join(map(str,selected)))
print('original mirror groups',','.join(map(str,mirror)))
print('original selected-side cover contribution',total,0)
