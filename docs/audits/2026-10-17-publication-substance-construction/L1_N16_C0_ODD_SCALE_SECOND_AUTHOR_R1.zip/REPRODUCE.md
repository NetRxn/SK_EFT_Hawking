# L1 second odd-root scale-up author result

The original representative (103607566400,1261652672530), weight 96,
has complete author coefficient
2622337373666858908717529296875/649037107316853453566312041152512.
Its 28 necessary-supported assignments form 14 exact chirality pairs.
Two representatives are positive, three negative and nine zero. See
author/pair-values.tsv for the signed values and author-exact.tsv for
the sum after doubling by the accepted exchange symmetry. The
source-normalized result includes original signs, 32 insertion
multiplicities and 64 coframe quarter factors. No residual row is
removed here. Independent reconstruction and acceptance are due.

The original unsplit site schedule stopped at channel 4 layer 1 site 3
after constructing every spatial edge table. The successful split
stores the root tensor and the endpoint-mask/wedge tensor separately
with three original coframe words shared. It projects each spatial
edge along a subset of its boundary index tuple (original endpoint
mask and coframe word), moving the exact Gaussian gains into the
adjacent wedge factor while leaving all other boundary indices open.
The original contraction is preserved with each quotient applied
successively. The remaining factors are contracted with the accepted
primitive-slice algorithm. Detailed logs record each zero and
each signed term.

The support-only control recognizes channel 5 exactly and reaches the
scan cap without deciding channel 4. A directed worklist for subsequent
proportional-slice updates reproduces a nonzero and a zero control.
This diagnostic does not replace the complete author batch replay.

## Replay

Restore the second-profile spatial edge-batch tables as described in
the first scale-up author archive. Verify anchor/edge-inputs.sha256
from its work directory. In a clean scratch directory copy author/*.py
and author/run_split.sh, link edge-plan.out to the one in anchor/, and
run python3 edge_rays.py on the restored edge-batch. Link rays as
edge-batch, then run sh run_split.sh with the path to anchor/. Verify
author/projected-tables.sha256 from scratch. The case logs describe
the replay of the 14 representative channels. The local time receipts
are observations from their recorded machine, and are not prerequisites
for exact arithmetic acceptance.
