"""Match independent signed terminals and structural zeros to original labels."""
from ast import literal_eval
import csv
from pathlib import Path
import re
from zipfile import ZipFile

def read(archive, member):
    with ZipFile(Path("independent") / f"{archive}.zip") as bundle:
        return list(csv.DictReader(bundle.read(member).decode().splitlines(), delimiter="\t"))

observed = {}
for archive, label_key, denominator_key in (
    ("L01", "original_L_assignment", "inherited_factor_denominator"),
    ("L3", "original_joint_L_index", "inherited_factor_denominator"),
    ("L4", "original_joint_L_index", "inherited_factor_denominator"),
    ("L26", "original_joint_L_index", "factor_denominator"),
):
    for item in read(archive, "scalar.tsv"):
        assert int(item["group"]) == 1466
        label = int(item[label_key])
        assert label not in observed
        observed[label] = tuple(int(item[k]) for k in ("raw_real", "raw_imag", denominator_key))

denominator, = {d for _, _, d in observed.values()}
original = {int(i):(literal_eval(key), literal_eval(zero)) for i, key, zero in
            (line.split("\t") for line in Path("original-labels.tsv").read_text().splitlines())}
for row in read("zeros", "zero-roster.tsv"):
    label = int(row["source_ordinal"])
    assert literal_eval(row["original_joint_L_tuple"]) == original[label][0]
    if original[label][1]:
        assert literal_eval(row["proved_raw_zero"]) == (0, 0)
        assert len(literal_eval(row["empty_factor_labels"])) == 7
        assert label not in observed
        observed[label] = 0, 0, denominator

author = {}
for label, real, imaginary, den in re.findall(
    r"original joint-L (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)",
    Path("AUTHOR_RETALLY.txt").read_text(),
):
    assert int(label) not in author
    author[int(label)] = int(real), int(imaginary), int(den)
assert sorted(observed) == list(range(8))
assert observed == author and all(imaginary == 0 for _, imaginary, _ in observed.values())
for label, row in sorted(observed.items()):
    print(label, *row, sep="\t")
