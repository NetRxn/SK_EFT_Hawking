# Original dense Group 1466 exact signed contraction

The lower-quartile group uses the original fixed representation cut and
the unchanged signed coframe contraction. Its prepared input is pinned
at `708b934e50ea4d7c051e8a59db7dd8ce1e8982ddd0b9850c7c198c87a0ac4c6b`.
The prior Group 786 archive and the independent zero-slice replay bind
this state to the original 2,448,742 signed rows and two exact sweeps.

The original ordinals are 0 through 7. The independent zero-slice
archive reproduces the loss of every row at the original restrictions
for ordinals 5 and 7. The other six have independent retained signed
contractions. Assignment 2 reaches three factors. The original per-run
cutoff skips its 32,342,016 products as a single evaluation. Each
author traversal partitions the original pivot rows into five disjoint
intervals, each with at most eight million matched products. Both
choices of pivot exhaust the same total and give the same real signed
numerator. The independent replay uses the third pivot and verifies
both author partitions separately.

From clean extraction run:

```sh
shasum -a 256 -c SHA256SUMS
python3 -B retally.py | cmp - AUTHOR_RETALLY.txt
python3 -B check-independents.py | cmp - INDEPENDENT_MATCH.tsv
```

To reproduce each live assignment, reconstruct the authenticated
prepared original Group 1466 state using the earlier throughput and
zero-slice archives. Use that pickle and its exact hash in `condition.py`
from each assignment's own empty directory. Keep the included
`original-labels.tsv` at the parent of those directories. Run `run.py`
to reproduce the guarded checkpoint, then set the cap path in
`unsharded.py` without changing the shape, denominator or hash check.
Follow the numbered passes. For L2 run `triangle-sharded.py` after pass
2, with the included original triangle helper. Frozen large checkpoint
hashes are recorded so their tables can be regenerated locally.

The independently verified signed chirality transfer maps the group
to Group 2684. The original normalized scalar and the outer profile
weight are distinct. The reference replays from upper-quartile Group
1441 in this archive cover original ordinals 1 and 5.
