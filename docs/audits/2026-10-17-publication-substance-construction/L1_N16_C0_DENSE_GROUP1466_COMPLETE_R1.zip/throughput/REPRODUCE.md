# Group 1466 continuation projection trial

Assignment 3 uses an independently verified original cap and continuation.
Two scratch replays use the same cap, signed operation order and numerical
guards. The experimental run replaces `pull` in `unsharded.py` with
the bounded projector in `projection.py`. The projector evaluates
the exact ordered integer index tuple behind the original helper.
The shape and ordering controls run with
`python3 -B projection-controls.py`.

Recreate separate empty directories with the author L3 scripts and
identical original cap source. Time the same unsharded stage and passes
2 and 3 with `/usr/bin/time -p`. The measured cap input and all split
and output fingerprints are in `continuation-comparison.tsv`.
Every checkpoint agrees byte for byte with the accepted baseline.
Elapsed continuation is 105.16 seconds in the baseline replay and
66.41 in the experimental replay. This is one paired observation for
one original assignment, from the signed cap onward. The measured
experiment leaves original preparation, guard and terminal evidence
unchanged.
