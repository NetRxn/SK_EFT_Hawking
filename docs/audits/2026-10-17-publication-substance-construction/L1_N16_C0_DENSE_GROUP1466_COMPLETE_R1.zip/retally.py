from ast import literal_eval
from fractions import Fraction
from itertools import product
from math import factorial, prod
from pathlib import Path
import re

def normalization():
    text = Path("contract-branch.py").read_text()
    codes = re.findall(r"a,b='(\d+)','(\d+)'",text)
    assert len(codes)==1
    a,b=map(int,codes[0])
    roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
    occ=[[roster[(code>>(6*x))&63] for x in range(8)] for code in (a,b)]
    edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
    world=sum((3+k)*n for sector in occ for o in sector for k,n in enumerate(o))
    cross=0
    for sector in occ:
        weights=[(u,v,sum(sector[u])-sector[u][k]+sum(sector[v])-sector[v][k]) for u,v,k in edges]
        cross+=sum(edge[2]*other[2]*(u>v) for i,edge in enumerate(weights)
                   for other in weights[i+1:] for u in edge[:2] for v in other[:2])
    total=sum(n for sector in occ for o in sector for n in o)
    mul=prod(factorial(p) for sector in occ for o in sector for p in o)
    assert total==32 and mul==16 and (world,cross)==(136,444)
    return (-1)**((world+cross)%2),mul*4**(2*total)

def raw(label):
    p=Path(f"L{label}")
    if (p/"terminal-sharded.out").is_file():
        ans=re.findall(r"triangle signed numerator [012] [012] [012] (-?\d+) (-?\d+) denominator (\d+)",(p/"terminal-sharded.out").read_text())
        assert len(ans)==2 and ans[0]==ans[1]
        return tuple(map(int,ans[0]))
    scalars=[]
    for f in sorted(p.glob("pass*.out")):
        lines=f.read_text().splitlines()
        hits=[s for s in lines if s.startswith("exact raw scalar ")]
        if not hits:continue
        assert len(hits)==1
        re_,im=literal_eval(hits[0].removeprefix("exact raw scalar "))
        last=[s for s in lines if s.startswith("exact follow join ")][-1]
        row=literal_eval(last.removeprefix("exact follow join ").split(" remaining ")[0])
        assert row[5:7]==(1,0)
        scalars.append((re_,im,row[7]))
    value, = scalars
    return value

def tally():
    label_rows = [(int(i), literal_eval(key), literal_eval(zero)) for i, key, zero in
                  (line.split("\t") for line in Path("original-labels.tsv").read_text().splitlines())]
    assert [i for i, _, _ in label_rows] == list(range(8))
    assert len({key for _, key, _ in label_rows}) == 8
    assert [i for i, _, zero in label_rows if zero] == [5, 7]
    expected = {i:key for i, key, zero in label_rows if not zero}
    stored = Path("L4/joint-label-roster.tsv").read_bytes()
    lines = stored.decode().splitlines()[1:]
    assert {int(i):literal_eval(key) for i, key, _, _ in (line.split("\t") for line in lines)} == expected
    for i in expected:
        assert (Path(f"L{i}")/"joint-label-roster.tsv").read_bytes() == stored
    values = {i:raw(i) for i in expected}
    denominator, = {t[2] for t in values.values()}
    assert denominator == 790361941837205407080937169092608
    sign, norm = normalization()
    for i, _, zero in label_rows:
        real, imaginary, inherited = (0, 0, denominator) if zero else values[i]
        assert imaginary == 0
        print("original joint-L", i, "raw", real, imaginary, "factor denominator", inherited)
    total = sum(r for r, _, _ in values.values())
    print("raw total", total, 0)
    print("exact normalized", Fraction(sign*total, denominator*norm), 0)

if __name__ == "__main__":
    tally()
