"""Test direction-0 contacts against the independently checkable direction-1 frame."""
import json
from pathlib import Path
import sys
import reverse_phase as r

def run():
    root=Path(__file__).resolve().parent
    p=r.p
    work=p.r5.Work(cap=p.r10.WORK_CAP,oracle_record_cap=p.r10.PAIR_CAP)
    _,sites,inputs,z_inputs,_,d0,d1=p.setup(work)
    parent=p.accepted_parent()
    phase_rows=[json.loads(line) for line in (root/"phase.jsonl").read_text().splitlines()]
    basis,=[row["witness"] for row in phase_rows if row.get("witness",{}).get("asymmetric")]
    assert basis["direction"]==1 and basis["degrees"]==[4,2]
    labels=tuple(map(tuple,basis["branch"]))
    lineage=tuple(map(parent.decode_operand,basis["path"]))
    seed_mask,seed_symbols,_=lineage[11]
    chirality,={s.index[2] for s in seed_symbols if s.family=="q"}
    occupied,symbols=parent.support((*lineage[:11],*lineage[12:]))
    # Persist only the tiny admitted target set, never full physical support.
    seen={p.r6.decoded(json.loads(line)["target"]) for line in (r.ROOT/"targets.jsonl").read_text().splitlines()}
    seen.update(p.r6.decoded(row["witness"]["target"]) for row in phase_rows if "witness" in row)
    count=0
    rejection={"wrong_chirality":0,"overlap":0,"duplicate":0}
    for attempt,((m,k,_),v) in enumerate(p.r4.rows(d0),1):
        work.charge("reverse_contact_replacement_rows")
        if m & occupied:
            rejection["overlap"]+=1
            continue
        if {s.index[2] for s in k if s.family=="q"}!={chirality}:
            rejection["wrong_chirality"]+=1
            continue
        target=(m|occupied,tuple(sorted(symbols+k)),r.SLOT)
        if target in seen:
            rejection["duplicate"]+=1
            continue
        seen.add(target)
        count+=1
        path=(*lineage[:11],(m,k,v),*lineage[12:])
        carry=r.FIXED + 35*len(seen) + 2*len(path)
        p.base.Admission(r.CAP_LIVE).check(carry)
        support=r.supports(target,labels,inputs,z_inputs,work,carry)
        assert support[0][0]
        row=r.row_for(target,labels,path,0,attempt,count,carry,support,inputs,z_inputs,sites,work)
        row.update(contact_chirality=chirality,basis_target=basis["target"]["mask_hex"])
        print(json.dumps(dict(witness=row)),flush=True)
        if row["asymmetric"] or count==r.CAP_WITNESSES:
            break
    print(json.dumps(dict(direction=0,attempt=attempt,signed_tests=count,work=work.used,
                          charges=dict(work.counts),rejections=rejection,prefix=p.PREFIX)),flush=True)

if __name__=="__main__":
    if sys.argv[1:]:
        raise SystemExit("Only bounded contact replacements are available")
    run()
