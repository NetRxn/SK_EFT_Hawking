from fractions import Fraction
from hashlib import sha256
import ast
import json
from pathlib import Path

d=Path(__file__).resolve().parent
parent=Path("/tmp/publication-task4-two-center-mixed-powers.BZXLVH")
prefix=(parent/"targets.jsonl").read_bytes()
candidate=(d/"candidate-targets.jsonl").read_bytes()
assert candidate.startswith(prefix)
old=[json.loads(line) for line in prefix.splitlines()]
new=[json.loads(line) for line in candidate[len(prefix):].splitlines()]
assert len(old)==4 and [row["direction"] for row in new]==[0,1]
assert len({json.dumps(row["target"],sort_keys=True) for row in old+new})==6
def q(value):
    rn,rd,imn,imd=ast.literal_eval(value.removeprefix("QComplex(storage=").removesuffix(")"))
    return Fraction(rn,rd),Fraction(imn,imd)

replay=[json.loads(line) for line in (d/"replay.jsonl").read_text().splitlines()]
assert len(replay)==10
assert replay[0]["prefix"]==720 and replay[0]["four_target_digest"]==sha256(prefix).hexdigest()
for row,bounded,raw in zip(new,replay[5:7],replay[7:9],strict=True):
    assert row["direction"]==bounded["direction"]==raw["raw_direction"]
    assert row["target"]==bounded["target"]
    assert row["witness"]==bounded["witness"]==raw["selected"]
    assert row["frame_coefficients"]==bounded["frame_coefficients"]==raw["frame_values"]
    assert row["frame_paths"]==bounded["frame_paths"]
    assert row["qualified"]<=12 and row["attempt"]<=2048 and row["asymmetric"]
totals=[[str(sum(x)) for x in zip(*(q(value) for value in row["frame_coefficients"]),strict=True)]
        for row in new]
assert totals==[["1/8192","0"],["0","-1/8192"]]
terminal=replay[-1]
assert terminal["target_sha256"]==sha256(candidate).hexdigest()
assert terminal["prefix"]==720 and terminal["retained_original_output_records"]==0
assert terminal["mode"]=="bounded" and terminal["reverse_count"]==2
assert 0<terminal["work"]<=20_000_000 and 0<terminal["oracle_peak"]<=16_384
assert all(0<row["peak"]<=8192 for row in replay[7:9])
print(json.dumps(dict(target_sha256=terminal["target_sha256"],target_bytes=len(candidate),
                      prior_targets=len(old),new_targets=len(new),fixed_frame_totals=totals,
                      prefix=terminal["prefix"],charged_operations=terminal["work"],
                      oracle_peak=terminal["oracle_peak"],
                      raw_local_peaks=[row["peak"] for row in replay[7:9]]),indent=2))
