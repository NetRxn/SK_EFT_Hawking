"""Recheck selected raw labels and the four fixed groups only."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys
import reverse_phase as r

p=r.p
ROOT=Path(__file__).resolve().parent

def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]

def main():
    work=p.r5.Work(cap=p.r10.WORK_CAP,oracle_record_cap=p.r10.PAIR_CAP)
    reg,sites,inputs,z_inputs,raws,d0,d1=p.setup(work)
    x,y,w,z=sites
    parent=p.accepted_parent()
    base=p.baseline_controls(parent,inputs,z_inputs,d0,d1,w,z,work)
    original=(r.ROOT/"targets.jsonl").read_bytes()
    assert sha256(original).hexdigest()==p.TARGET_DIGEST
    reverse=[record["witness"] for file in ("phase.jsonl","contact_replacements.jsonl")
             for record in rows(ROOT/file) if record.get("witness",{}).get("asymmetric")]
    reverse.sort(key=lambda row:row["direction"])
    assert reverse and len(reverse)==len({row["direction"] for row in reverse})
    targets=original+b"".join((json.dumps(row)+"\n").encode() for row in reverse)
    expected=(*p.REQUEST_KEYS,*((r.DEGREES,r.SLOT,row["direction"]) for row in reverse))
    print(json.dumps(dict(baseline=base, four_target_digest=p.TARGET_DIGEST, prefix=p.PREFIX)),flush=True)
    for line,identity in zip(targets.splitlines(keepends=True),expected,strict=True):
        target,labels,value,paths,receipt=p.checked_request(
            line,identity,parent,inputs,z_inputs,d0,d1,w,z,work
        )
        print(json.dumps(dict(direction=receipt["direction"],degrees=receipt["degrees"],
                              target=receipt["target"],witness=receipt["witness"],paths=paths,
                              frame_coefficients=receipt["frame_coefficients"],
                              frame_paths=receipt["frame_paths"],witness_peak=receipt["witness_peak"])),flush=True)
    outer=(p.r10.r9.source_roster(reg,x,work)[1],p.r10.r9.source_roster(reg,y,work)[1])
    for row in reverse:
        signed_frames, selected, peak=raw_frame_replay(row,inputs,z_inputs,raws,outer,work)
        assert list(map(str,signed_frames))==row["frame_coefficients"]
        assert str(selected)==row["witness"]
        print(json.dumps(dict(raw_direction=row["direction"], frame_values=list(map(str,signed_frames)),
                              selected=str(selected), peak=peak)),flush=True)
    print(json.dumps(dict(mode="bounded",prefix=p.PREFIX,retained_original_output_records=0,
                          reverse_count=len(reverse),target_sha256=sha256(targets).hexdigest(),
                          work=work.used,oracle_peak=work.oracle_max_prospective_records,
                          charges=dict(work.counts))),flush=True)
    (ROOT/"candidate-targets.jsonl").write_bytes(targets)

def raw_frame_replay(row,inputs,z_inputs,raws,outer,work):
    target=p.r6.decoded(row["target"])
    mask,symbols,slot=target
    counts=Counter(symbols)
    cx,_,cw,_,contacts,cy,_=inputs
    cz,_=z_inputs
    x,w,z,y=map(tuple,row["branch"])
    cap=p.base.Admission(p.r10.LOCAL_CAP)
    # Reserve frozen roster/receipt, four scalar results and recursion scratch.
    carry=row["reserved_path_records"]+128
    def count(e):
        return p.r5.count(e)
    def restrict(poly,fixed):
        cap.check(fixed+2*count(poly))
        return p.r5.subset_factor(poly,mask,counts,work)
    def mul(a,b,fixed):
        n,m=count(a),count(b)
        out=p.E()
        for (am,ak,_),av in p.r4.rows(a):
            live=fixed+n+m+2*count(out)
            cap.check(live+2*m+1)
            p.check_oracle(work,live+2*m+1)
            work.charge("reverse_raw_canonical_pairs",m)
            piece=restrict(p.E(((am,p.P(((ak,av),))),))*b,live)
            cap.check(live+2*count(piece))
            out+=piece
        return out
    def raw_vertex(coframes,terms,fixed):
        out=p.E()
        for term in terms:
            work.charge("reverse_raw_selected_orientations")
            degree=term.t_degree
            part=p.E(((0,p.P.scalar(p.ONE)),))
            for _,mu,a in term.components:
                coframe=restrict(coframes[mu,a],fixed+count(out)+count(part))
                part=mul(part,coframe,fixed+count(out))
            h=p.E(((0,term.coefficient*p.P.variable(p.G1 if degree==4 else p.G2)),))
            h=restrict(h,fixed+count(out)+count(part))
            piece=mul(part,h,fixed+count(out))
            cap.check(fixed+2*count(out)+2*count(piece))
            out+=piece
        return out
    def extract(e):
        return dict(dict(e.terms).get(mask,p.P()).terms).get(symbols,p.ZERO)
    def multiply_chain(factors,fixed):
        held=sum(map(count,factors))
        acc=p.E(((0,p.P.scalar(p.ONE)),))
        for factor in factors:
            acc=mul(acc,factor,fixed+held)
        return extract(acc)
    def from_raw_table(table):
        by_mask={}
        for (m,k),(v,_) in table.items():
            if v:
                by_mask.setdefault(m,[]).append((k,v))
        return p.E(tuple((m,p.P(tuple(rows))) for m,rows in by_mask.items()))
    contact=restrict(contacts[slot],carry)
    early=raw_vertex(cx,outer[0][(2,*x)],carry+count(contact))
    late=raw_vertex(cy,outer[1][(2,*y)],carry+count(contact)+count(early))
    fixed=carry+count(contact)+count(early)+count(late)
    w_label=raw_vertex(cw,raws[0][w],fixed)
    z_label=raw_vertex(cz,raws[1][z],fixed+count(w_label))
    selected=multiply_chain((early,w_label,z_label,contact,late),carry)
    del w_label,z_label
    wp=p.raw_center(target,cw,raws[0],work,cap,fixed,r.DEGREES[0])
    zp=p.raw_center(target,cz,raws[1],work,cap,fixed+len(wp),r.DEGREES[1])
    cap.check(fixed+2*len(wp)+2*len(zp))
    w_all,z_all=from_raw_table(wp),from_raw_table(zp)
    del wp,zp
    fixed+=count(w_all)+count(z_all)
    x_ref=raw_vertex(cx,outer[0][(2,*p.reflect(x))],fixed)
    y_ref=raw_vertex(cy,outer[1][(2,*p.reflect(y))],fixed+count(x_ref))
    held=count(early)+count(late)+count(x_ref)+count(y_ref)
    values=[multiply_chain((a,w_all,z_all,contact,b),carry+held)
            for a,b in ((early,late),(x_ref,late),(early,y_ref),(x_ref,y_ref))]
    return values,selected,cap.peak

if __name__=="__main__":
    if sys.argv[1:]:
        raise SystemExit("Only bounded checks are available")
    main()
