"""Bounded reverse mixed preflight under the established local and work caps."""
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import random
import sys

ROOT = Path("/tmp/publication-task4-two-center-mixed-powers.BZXLVH")
SOURCE = ROOT / "candidate.py"
assert sha256(SOURCE.read_bytes()).hexdigest() == "7ab511703e2d9ebd9e234093d2d2117254c715806495c9e8ea523d62f4a5caf1"
spec = spec_from_file_location("frozen_mixed_power_parent", SOURCE)
p = module_from_spec(spec)
sys.modules[spec.name] = p
spec.loader.exec_module(p)

DEGREES = (4, 2)
SLOT = p.SLOTS[1]
REVERSE = (DEGREES, SLOT)
CAP_ATTEMPTS = 2048
CAP_WITNESSES = 12
CAP_LIVE = p.r10.LOCAL_CAP
FIXED = 1536
SEEDS = (2026110704, 2026110705)

def choose_row(poly, occupied, rng, work):
    """Draw a row from the disjoint exterior incidence, without rejection draws."""
    total = 0
    chosen = None
    for mask, coefficients in poly.terms:
        work.charge("reverse_seed_incidence_blocks")
        if mask & occupied:
            continue
        count = len(coefficients.terms)
        total += count
        pos = rng.randrange(total)
        if pos < count:
            key, coefficient = coefficients.terms[pos]
            chosen = mask, key, coefficient
    return chosen

def seed(inputs, z_inputs, labels, contact, rng, work):
    factors = p.source_factors(inputs, z_inputs, labels, contact)
    # Seed the outer and contact incidence first, then consume W's four
    # coframes and Z's two coframes against the remaining exterior bits.
    order = (0,1,2,11,12,13,14,3,4,5,6,7,8,9,10)
    lineage = [None] * len(factors)
    mask = 0
    for i in order:
        item = choose_row(factors[i], mask, rng, work)
        if item is None:
            return None
        mask |= item[0]
        lineage[i] = item
    key = tuple(sorted(s for _, symbols, _ in lineage for s in symbols))
    return (mask, key, SLOT), tuple(lineage)

def unsigned_states(factors, target, work, cap, carry):
    """Retain only attainable exterior/multiset states, never signed sums."""
    mask, key, _ = target
    projected = []
    live = 0
    for poly in factors:
        rows = p.base.projection(poly, target, work, cap, carry + live)
        projected.append(rows)
        live += len(rows)
        if not rows:
            return set()
    result = set()
    def descend(i, used, remaining):
        if i == len(projected):
            state = used, remaining
            if state not in result:
                cap.check(carry + live + len(result) + 1 + len(projected))
                result.add(state)
            return
        for m, symbols, _ in projected[i]:
            work.charge("reverse_unsigned_operand_tests")
            if m & used:
                continue
            rest = p.r5.subtract(remaining, symbols)
            if rest is not None:
                descend(i+1, used | m, rest)
    cap.check(carry + live + len(projected))
    descend(0, 0, key)
    return result

def supports(target, labels, inputs, z_inputs, work, carry):
    """Compare feasible W/Z residual states across the four fixed frame pairs."""
    x,w,z,y = labels
    cap = p.base.Admission(CAP_LIVE)
    mask, key, _ = target
    contact = inputs[4][SLOT]
    # The selected source labels stay fixed during the unsigned screen.
    # Other inner labels can still contribute in the signed frame check.
    factors = p.source_factors(inputs, z_inputs, labels, contact)
    inner = unsigned_states(factors[3:11], target, work, cap, carry)
    result = []
    for a,b in ((x,y),(p.reflect(x),y),(x,p.reflect(y)),(p.reflect(x),p.reflect(y))):
        outer = p.source_factors(inputs, z_inputs, (a,w,z,b), contact)
        occupied = unsigned_states((*outer[:3],*outer[11:]),target,work,cap,
                                   carry+len(inner)+sum(map(len,result)))
        viable = set()
        for ext, leftover in inner:
            work.charge("reverse_unsigned_residual_matches")
            exterior = mask ^ ext
            symbols = p.r5.subtract(key, leftover)
            if (exterior, symbols) in occupied:
                cap.check(carry+len(inner)+sum(map(len,result))+len(occupied)+len(viable)+1)
                viable.add((ext, leftover))
        result.append(viable)
    sig = [sha256(repr(sorted(rows)).encode()).hexdigest() for rows in result]
    return [len(rows) for rows in result], sig, cap.peak

def row_for(target, labels, lineage, direction, attempt, qualified, carry, support, inputs, z_inputs, sites, work):
    p.validate_grades(target, DEGREES)
    _,_,w,z = sites
    value, paths, peak = p.selected_witness(target, inputs, z_inputs, labels, work, carry)
    frames, frame_paths, frame_peak = p.frame_controls(
        target, labels, inputs, z_inputs, DEGREES, work, carry
    ) if value else ([],[],0)
    asymmetric = bool(frames and frames[0] and frames[0]+frames[1]
                      and frames[0]+frames[2] and sum(frames,p.ZERO))
    shared = {s for _,part,_ in lineage[3:8] for s in part} & {
        s for _,part,_ in lineage[8:11] for s in part
    }
    repeated = tuple(sorted(s for s in shared if s.family=="q"
                            and s.index[0] in (w,z) and s.index[1]==0))
    work.charge("reverse_seed_receipt_rows", len(lineage))
    return dict(degrees=DEGREES, target=p.r5.fingerprint(target), direction=direction,
                branch=labels, attempt=attempt, qualified=qualified,
                repeated=p.r5.fingerprint((0,repeated,()))["symbols"],
                path=[(hex(m),[(s.family,s.index) for s in k],str(v)) for m,k,v in lineage],
                witness=str(value), paths=paths,
                local_peak=max(peak, frame_peak, support[2]), frame_coefficients=list(map(str,frames)),
                frame_paths=frame_paths, work=work.used, asymmetric=asymmetric,
                reserved_path_records=carry, incidence_counts=support[0],
                incidence_fingerprints=support[1])

def run():
    work = p.r5.Work(cap=p.r10.WORK_CAP, oracle_record_cap=p.r10.PAIR_CAP)
    _, sites, inputs, z_inputs, _, d0, d1 = p.setup(work)
    wk = tuple(k for k in inputs[3] if k[0]==4)
    zk = tuple(k for k in z_inputs[1] if k[0]==2)
    xk = tuple(k for k in inputs[1] if p.reflect(k) in inputs[1])
    yk = tuple(k for k in inputs[-1] if p.reflect(k) in inputs[-1])
    raw = (ROOT/"targets.jsonl").read_bytes()
    assert sha256(raw).hexdigest() == p.TARGET_DIGEST
    seen = {p.r6.decoded(json.loads(line)["target"]) for line in raw.splitlines()}
    for direction, d in enumerate((d0,d1)):
        tally = Counter()
        rng = random.Random(SEEDS[direction])
        qualified = 0
        for attempt in range(1,CAP_ATTEMPTS+1):
            work.charge("reverse_structural_seed_attempts")
            labels = tuple(rng.choice(pool) for pool in (xk,wk,zk,yk))
            candidate = seed(inputs,z_inputs,labels,d,rng,work)
            if candidate is None:
                tally["infeasible"] += 1
                continue
            target,lineage = candidate
            if target in seen:
                tally["duplicate"] += 1
                continue
            carry = FIXED + 35*len(seen) + 2*len(lineage)
            p.base.Admission(CAP_LIVE).check(carry)
            support = supports(target,labels,inputs,z_inputs,work,carry)
            counts, sig, _ = support
            assert counts[0], (target,labels)
            if sig[0] == sig[1] and sig[0] == sig[2]:
                tally["same_single_reflection_support"] += 1
                continue
            qualified += 1
            seen.add(target)
            row = row_for(target,labels,lineage,direction,attempt,qualified,carry,
                          support,inputs,z_inputs,sites,work)
            print(json.dumps({"witness":row}),flush=True)
            if row["asymmetric"]:
                tally["qualified"] += 1
                break
            if qualified == CAP_WITNESSES:
                tally["witness_cap"] += 1
                break
        else:
            tally["structural_cap"] += 1
        print(json.dumps(dict(direction=direction, attempt=attempt, signed_tests=qualified,
                              screen=dict(tally), work=work.used, prefix=p.PREFIX)),flush=True)
    print(json.dumps(dict(work=work.used, charges=dict(work.counts))),flush=True)

if __name__ == "__main__":
    if sys.argv[1:]:
        raise SystemExit("Only the bounded reverse preflight is available")
    run()
