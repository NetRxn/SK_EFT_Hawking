import json
from pathlib import Path
import reverse_phase as r

p=r.p
work=p.r5.Work(cap=p.r10.WORK_CAP,oracle_record_cap=p.r10.PAIR_CAP)
_,sites,inputs,z_inputs,_,d0,d1=p.setup(work)
parent=p.accepted_parent()
forward=[]
for line in (r.ROOT/"targets.jsonl").read_text().splitlines():
    row=json.loads(line)
    if row["degrees"]==[2,4] and row["target"]["slot"]==list(r.SLOT):
        forward.append(row)
assert [x["direction"] for x in forward]==[0,1]
sample_reverse=[]
for line in (r.ROOT/"discovery.rejected.jsonl").read_text().splitlines():
    row=json.loads(line)
    if row["degrees"]==[4,2] and row.get("target",{}).get("slot")==list(r.SLOT) and row.get("frame_coefficients"):
        if row["frame_coefficients"][0]!=str(p.ZERO) and row["direction"] not in {x["direction"] for x in sample_reverse}:
            sample_reverse.append(row)
assert [x["direction"] for x in sample_reverse]==[0,1]
for row in forward+sample_reverse:
    labels=tuple(map(tuple,row["branch"]))
    lineage=tuple(map(parent.decode_operand,row["path"]))
    phase,peak=r.seeded_frame_phase(inputs,z_inputs,labels,lineage,work,r.FIXED)
    a,ar,b,br=phase
    print(json.dumps(dict(degrees=row["degrees"],direction=row["direction"],phase=list(map(str,phase)),
                          phase_screen_accepts=bool(a and b and a+ar and b+br),known_four_frame=row["frame_coefficients"],
                          peak=peak)),flush=True)
print(json.dumps(dict(work=work.used,charges=dict(work.counts))),flush=True)
