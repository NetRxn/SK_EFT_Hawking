# Larger L1 tuples remain open

This is an author restart checkpoint for the two remaining tuples in the six-tuple descendant (0,0) of dense branch 128, profile (503841882182,1461451755920). Neither has a complete scalar.

The preceding independently accepted contribution archive is L1_N16_C0_DENSE_CONDITIONED_SCALARS_R1.zip at fe68d07643bc391a32a07e802afd1b19b75ab24b. It contains the accepted partition, original-source labels, numerical helpers and five exact replayed contributions, with the full remaining scientific obligations.

ROOT now owns tuples 0 and 1. The numerical worker completed tuple 0 preparation and its first exact reduction, ending at 703,664 rows. A fresh host process check showed no reduction or contraction running, and ROOT interrupted the worker turn before copying that saved state unchanged. ROOT continued tuple 0 and computed tuple 1. Both reached the existing product-limit boundary with exact prejoin frontiers preserved. The two exec handles were observed terminal with exit 2. No new numerical job was started after these bounded attempts.

Verify manifest.sha256 after extraction, decompress tuple*-restart.pkl.gz and verify frontiers-uncompressed.sha256. The frozen factor tables retain the complete conditioning list, denominator and label-partition metadata. verification.out states factor/row counts. No partly accumulated output was promoted into these frontiers.

For another exact reduction cycle, supply the chosen restart pickle to reduce-label-frontier.py with a fresh tag, then use contract-reduced-label.py with that tag. Obtain checkpoint/quotient.py from the preceding contribution archive at author/checkpoint/quotient.py. The unchanged numerical limits are 500,000 output rows, 8 million products per join and 40 million per invocation. The measured current frontier needs a further exact separator, a different bounded schedule or another justified algebraic reduction before the refused joins. An unchanged blind retry gives the same bounded refusal.

Independent acceptance of tuples 0 and 1 and their complete six-tuple sum remains required. The other internal-index siblings, group 128, full profile and original c0 are still open. The accepted residual remains 9,547 orbits and 821,655 labels. The operator has requested a portfolio and whole-L1 path-to-human-review assessment; the current canonical queue remains in force pending any explicit priority change.
