from ast import literal_eval
from pathlib import Path
import pickle
import sys

root=Path(__file__).resolve().parent
index=int(sys.argv[1])
plans=literal_eval((root/'label-partition-roster.txt').read_text())
total,_,selected,counts=next(plan for plan in plans if plan[1]==index)
with (root/'nine-minimum-quotient-frontier.pkl').open('rb') as handle:
    checkpoint=pickle.load(handle)
factors=[]
for axes,rows,denominator in checkpoint['factors']:
    conditions=[(position,selected[wire]) for position,wire in enumerate(axes) if wire in selected]
    positions=[position for position,wire in enumerate(axes) if wire not in selected]
    new_rows={tuple(row[position] for position in positions):z for row,z in rows.items()
              if all(row[position]==value for position,value in conditions)}
    assert len(new_rows)==sum(all(row[position]==value for position,value in conditions) for row in rows)
    factors.append((tuple(axes[position] for position in positions),new_rows,denominator))
assert [len(rows) for _,rows,_ in factors]==counts
checkpoint['factors']=factors
checkpoint['conditioning']=checkpoint['conditioning']+list(sorted(selected.items()))
checkpoint['label_partition']={'index':index,'count':len(plans),'values':selected}
with (root/f'label-tuple-{index}-frontier.pkl').open('xb') as handle:
    pickle.dump(checkpoint,handle,protocol=5)
print('prepared tuple',index,'rows',total,'partition count',len(plans),flush=True)
