from collections import defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path

def read(file):
    return [tuple(map(int,s.split())) for s in Path(file).read_text().splitlines()]
def add(a,b):
    return a[0]+b[0],a[1]+b[1]
def mul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def sign(m,n):
    return (-1)**sum(i>j for i,j in product(range(8),repeat=2) if (m>>i)&1 and (n>>j)&1)
z=(0,0)
grams=defaultdict(dict)
for t,i,j,v in read('grams.tsv'):
    if t==1: grams[i][j]=v
edges={(i,m,j,n):(r,s) for i,m,j,n,r,s in read('edge.tsv')}
assert len(edges)==3952 and sum(im != 0 for _,im in edges.values())==1600
assert all(edges[j,n,i,m]==w for (i,m,j,n),w in edges.items())
for k,expect in { (0,15,0,240):(2304,0), (3,149,5,166):(-352,0),
                  (0,85,1,102):(0,-704), (3,149,2,169):(0,352) }.items():
    assert edges[k]==expect
assert (0,15,0,15) not in edges
def table(edge_axis, *, transpose=False, conjugate=False, unsigned=False):
    out=defaultdict(dict)
    for (i,m,j,n),w in edges.items():
        if transpose: i,m,j,n=j,n,i,m
        # Edge terminates at a site: axis 0 before axis 1 in the vertex.
        comp=255^n
        phase=1 if unsigned else (sign(n,comp) if edge_axis==0 else sign(comp,n))
        for k,g in grams[j].items():
            val=(phase*g*w[0],phase*g*(-w[1] if conjugate else w[1]))
            start,end=(i,m),(k,comp)
            out[start][end]=add(out[start].get(end,z),val)
    return out
def compose(a,b):
    count=sum(len(b.get(k,{})) for row in a.values() for k in row)
    assert count<=50_000_000
    c=defaultdict(dict)
    for i,row in a.items():
        for k,av in row.items():
            for j,bv in b.get(k,{}).items():
                c[i][j]=add(c[i].get(j,z),mul(av,bv))
    return {i:{j:v for j,v in row.items() if v!=z} for i,row in c.items()},count
def contraction(axis_order, reverse_flags, *, mutation=None):
    steps=[table(ax,transpose=rev,conjugate=mutation=='conjugate' and i==0,
                unsigned=mutation=='unsigned' and i==0)
           for i,(ax,rev) in enumerate(zip(axis_order,reverse_flags))]
    # Cut at opposite sites, use the reversed key in the second path without conjugation.
    a,na=compose(*steps[:2])
    b,nb=compose(*steps[2:])
    out=z
    for i,row in a.items():
        for j,v in row.items():
            out=add(out,mul(v,b.get(j,{}).get(i,z)))
    return out,na,nb
orientation_a=contraction([0,1,0,1],[False,False,True,True])
orientation_b=contraction([1,0,1,0],[False,False,True,True])
signed=17512633766806290432,0
assert orientation_a[0]==orientation_b[0]==signed
mutations={m:contraction([0,1,0,1],[False,False,True,True],mutation=m)
           for m in ('conjugate','unsigned')}
assert all(r[0]!=signed for r in mutations.values()),mutations
for name,ans in (('clockwise',orientation_a),('counterclockwise',orientation_b),*mutations.items()):
    print(name, ans)
c=Fraction(signed[0],12288**4)
assert c==Fraction(1573101,2048)
print('square C*',c)
