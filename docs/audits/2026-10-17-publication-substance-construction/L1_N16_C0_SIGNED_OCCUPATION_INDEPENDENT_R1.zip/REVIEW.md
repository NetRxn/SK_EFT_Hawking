# Independent signed N16 fixed occupation review

## Verdict

PASS for the frozen signed fixed-occupation calculation at primary source 27012c18fa374e8341e124b510abbedeedb18d29. Both upstream manifests verified. The occupation is precisely two EHC factors from the rooted 23 plane at each of the 16 sites in the closed-word periodic regulator. Its signed square value is 1573101/2048. The full contribution of that single occupation is

    1079840342062317710103477257434903921 / 3101843146481947279097856.

## Original signs and Haar interface

Canonical to_exterior independently yields 512 normalized source monomials on each of the 16 coframe edges. Their complete records agree after relabeling the two actual anchors and two endpoints. The literal chiral traces and distinct internal-pair permutations give all 200 Gram cells, including zeros. The two symmetrized chiral Grams are identical and equal the quartic W. All 70 complementary degree-four exterior signs match the canonical exterior polynomial.

I enumerated four raw factors by complete even coordinate occupancy. One coordinate can occur four times, or two distinct coordinates twice each with six placements. Coordinates have full anchor and chiral labels. The source normalized moment function gives the exact edge scale 48×4^4=12288. This enumeration has no intermediate quadratic aggregation and reproduces the entire frozen 3952-entry edge table, with 1600 imaginary entries and all other cells zero. Literal controls include 3/16, −11/384, −11i/192, +11i/384 and a zero. Endpoint reversal is a transpose of the full two-endpoint tensor.

Independent square sewing uses two paths between opposite sites, ordering local exterior products by physical axis. The degree-four endpoint blocks are even, as are the eight-generator site tops. It gives the same exact numerator 17512633766806290432 + 0i in both directions. Conjugating only one edge instead produces 10992964121187581952. Omitting the exterior complement sign at only one vertex produces 2984649190048530432. These are adverse controls for preserving complex coefficients and wedge signs.

## Curvature, factorial and scope

Independently regrouped raw EHC source factors for all 16 roots using noncommuting exact unit quaternions. All 256 internal-pair values match epsilon times one half of the forward-minus-reversed trace; source also verifies the reverse word is the adjoint. The world epsilon squares. Four independent curvature faces cover 32 anchors and four coframe squares cover the other 32. Each site uses all eight generators. The same even-degree sign argument applies when reordering sites between squares.

At each root, independent Haar gauge conjugation averages a same-chirality pair to its Gram times 1−chi_ad(H)/3. This follows from isotropy of the three quaternion-vector coordinates and chi_ad=4 q0²−1. Cross-chirality vector means vanish. Every proper nonempty subset of adjoint insertions in one chirality leaves a singleton Haar anchor. For all four roots, contracting the two adjoint matrix occurrences per anchor gives four free index classes across eight adjoint Schur pairs, hence 1/81. The correlated term has a further 1/3^4, hence 1/6561. The unsymmetrized mixed F01 F23 Gram is (−1,+1), yielding the 2/6561 joint control despite a vanishing product of local means. With equal chiral Grams after symmetrization, each face therefore contributes 16+2/6561=104978/6561 times the common coframe quartics.

Direct 81-term expansion and the collapsed fourth power agree. The exponential contributes 32!/(2!)^16 labeled assignments divided by 32!, leaving (2!)^-16. The final weight is (104978/6561)^4 (1573101/2048)^4/(2!)^16. It is one strictly positive contribution. The other c0 occupations can have their own signs, and the full coefficient, its sign and denominator admissibility remain open.

## Resource and custody

Prospective raw cap 50 million, actual count 18,841,600 with 6,256,640 disjoint terms. At an adverse 18 million cap the prospective pass refused before contraction or output. The square paths count 247,232 products each before multiplication, below the same per-path cap. The integer edge bound 6×50 million is within signed 64-bit range, and the Python path products and final arithmetic use exact unbounded integers. The resource receipt records wall time and peak RSS for each stage; the maximum observed was 106,774,528 bytes for the raw edge computation. No repository source, registry or slot mutation.
