from collections import defaultdict,Counter
from fractions import Fraction as F
from itertools import product,permutations,combinations
from math import factorial,prod
from src.core.formulas import original_plaquette,original_action_factors,original_spin4_link
from src.vestigial.original_coefficients import (OriginalRegulator,Polynomial,matrix_multiply,
                                                 matrix_dagger,epsilon,identity_matrix)

r=OriginalRegulator()
faces={(i,j):[(i,j,k,l) for k,l in product(range(2),repeat=2)]
       for i,j in product(range(2),repeat=2)}
squares={(k,l):[(i,j,k,l) for i,j in product(range(2),repeat=2)]
       for k,l in product(range(2),repeat=2)}
assert len({x for f in faces.values() for x in f})==16
assert len({x for f in squares.values() for x in f})==16
def shift(x,mu):
    y,s=r.step(x,mu)
    assert s==1
    return y
def path(x,k,l):
    # Matrix multiplication read from left to right as implemented by closed.
    return [((x,l),True),((shift(x,l),k),True),((shift(x,k),l),False),((x,k),False)]
def tr_word(x,k,l,links):
    m=identity_matrix(4)
    for a,dag in path(x,k,l):
        m=matrix_multiply(m,matrix_dagger(links[a]) if dag else links[a])
    return m
# Noncommuting exact unit quaternions, chosen to make daggers nontrivial.
qs=[(F(1,2),F(1,2),F(1,2),F(1,2)),(F(3,5),F(4,5),0,0),
    (0,0,1,0),(0,0,0,-1),(F(5,13),0,F(12,13),0)]
links={a:original_spin4_link(qs[i%5],qs[(2*i+1)%5]) for i,a in enumerate(r.link_order)}
for x in r.sites:
    actual=original_plaquette(r,x,2,3,links)
    assert actual==tr_word(x,2,3,links)
    assert original_plaquette(r,x,3,2,links)==matrix_dagger(actual)
    H=actual
    grouped=defaultdict(Polynomial)
    for factor in original_action_factors(r,x,links):
        if factor.t_degree!=2: continue
        key=tuple(sorted(factor.components))
        if tuple(label[1] for label in key)!=(0,1):continue
        grouped[key[0][-1],key[1][-1]]+=factor.coefficient
    for a,b in product(range(4),repeat=2):
        M=matrix_multiply(matrix_multiply(r.gamma[a],r.gamma[b]),r.gamma5)
        def trace(u):
            Q=matrix_multiply(u,M)
            return sum((Q[i][i] for i in range(4)),Polynomial())
        expected=epsilon((2,3,0,1))*(trace(H)-trace(matrix_dagger(H)))*F(1,2)
        assert grouped[a,b]==expected
print('all 16 roots and 256 internal pairs reproduce original grouped EHC epsilon and trace factor')

all_curvature=set()
all_coframe=set()
for face in faces.values():
    shared=defaultdict(list)
    graph=defaultdict(set)
    for root in face:
        for n,(anchor,dagger) in enumerate(path(root,2,3)):
            ij=(root,n),(root,(n+1)%4)
            shared[anchor].append(ij[::-1] if dagger else ij)
    assert len(shared)==8 and all(len(inc)==2 for inc in shared.values())
    assert not all_curvature.intersection(shared)
    all_curvature.update(shared)
    for first,second in shared.values():
        for a,b in zip(first,second):
            graph[a].add(b); graph[b].add(a)
    remaining=set(graph)
    parts=[]
    while remaining:
        wave=[remaining.pop()]
        part=set(wave)
        while wave:
            for x in graph[wave.pop()] & remaining:
                remaining.remove(x);part.add(x);wave.append(x)
        parts.append(part)
    assert sorted(map(len,parts))==[4,4,4,4]
    # Every nonempty proper occupied root subset has at least one singleton.
    for n in (1,2,3):
        for subset in combinations(face,n):
            occupancy=Counter(anchor for x in subset for anchor,_ in path(x,2,3))
            assert 1 in occupancy.values()
for sq in squares.values():
    anchors={(x,axis) for x in sq for axis in (0,1)}
    assert len(anchors)==8 and not anchors & all_coframe
    all_coframe |= anchors
assert not all_curvature & all_coframe
assert all_curvature | all_coframe == set(r.link_order)
print('four disjoint curvature faces and four disjoint coframe squares, all 64 anchors accounted for')
# SO(3) Schur pair leaves four free index classes out of eight anchor pairs.
# At each root, conjugation averaging 4 qvec_a qvec_b yields
# 4/3 |qvec|² = 1 - (4*q0²-1)/3; cross-chirality expectation vanishes.
J=F(3)**(4-8)
weight=J/F(3**4)
scale=2**4+2*weight
assert (J,weight,scale)==(F(1,81),F(1,6561),F(104978,6561))
mixed=(-1+1)**4+weight*((-1)**4+1**4)
assert mixed==F(2,6561)
c=F(1573101,2048)
value=scale**4*c**4/F(factorial(2)**16)
assert value==F(1079840342062317710103477257434903921,3101843146481947279097856)
assert value==sum(prod((2**4,weight,weight)[i] for i in f)*c**4 for f in product(range(3),repeat=4))/F(factorial(2)**16)
assert factorial(32)//(factorial(2)**16)*F(1,factorial(32))==F(1,factorial(2)**16)
print('face scale',scale,'mixed control',mixed)
print('occupation',value)
