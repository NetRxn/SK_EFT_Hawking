import json,os,sys,time
from pathlib import Path
cmd,out,err=sys.argv[1:4]
args=[cmd,*sys.argv[4:]]
actions=[(os.POSIX_SPAWN_OPEN,1,out,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600),
         (os.POSIX_SPAWN_OPEN,2,err,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)]
start=time.monotonic()
pid=os.posix_spawn(cmd,args,os.environ,file_actions=actions)
child,status,rs=os.wait4(pid,0)
rc=os.waitstatus_to_exitcode(status)
print(json.dumps({"program":args[-1],"status":rc,"wall_seconds":round(time.monotonic()-start,6),
                  "darwin_maxrss_bytes":rs.ru_maxrss}))
assert pid==child and rc==0,(rc,Path(err).read_text())
