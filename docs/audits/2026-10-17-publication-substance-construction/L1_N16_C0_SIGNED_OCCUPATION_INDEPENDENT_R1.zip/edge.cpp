#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <cassert>
#include <cstdlib>
using Z=std::array<int64_t,2>;
Z mul(Z a,Z b) { return {a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]}; }
struct Term {unsigned bits; Z z;};
int sign(unsigned a, unsigned b) {
    unsigned p=0;
    for (unsigned bit=1; bit<(1u<<16); bit<<=1)
        if (b & bit) p += std::popcount(a & ~(bit|(bit-1)));
    return (p%2) ? -1 : 1;
}
int main(int argc,char **argv) {
    const uint64_t cap=argc==2 ? std::strtoull(argv[1],nullptr,10):50000000;
    if(cap>50000000) return 2;
    std::vector<Term> data[2][4][16];
    int s,c,q,re,im;
    unsigned mask;
    std::ifstream cof("coframes.tsv");
    while(cof>>s>>c>>mask>>q>>re>>im) data[s][c][q].push_back({mask,{re,im}});
    int moments[16][16]{};
    std::ifstream mom("moments.tsv");
    int r,w;
    while(mom>>q>>r>>w) moments[q][r]=w;
    std::vector<std::array<int,2>> pairs;
    for(int i=0;i<4;++i) for(int j=i;j<4;++j) pairs.push_back({i,j});
    std::vector<Z> result(10*10*65536);
    uint64_t candidates=0, disjoint=0;
    for(int pass=0;pass<2;++pass)
        for(int i=0;i<10;++i) for(int j=0;j<10;++j) {
            const auto [a,b]=pairs[i];
            const auto [c,d]=pairs[j];
            for(int q=0;q<16;++q) for(int r=q;r<16;++r) {
                assert(moments[q][r]>0 && moments[q][r]<=6);
                for(unsigned pick=0;pick<16;++pick) {
                    if(q==r ? (pick!=0) : (std::popcount(pick)!=2)) continue;
                    auto which=[&](int k){return (pick&(1u<<k)) ? r:q;};
                    const auto &A=data[0][a][which(0)], &B=data[0][b][which(1)];
                    const auto &C=data[1][c][which(2)], &D=data[1][d][which(3)];
                    if(!pass) {
                        candidates+=A.size()*B.size()*C.size()*D.size();
                        if(candidates>cap) {
                            std::cerr<<"refused before contraction at "<<candidates<<"; cap "<<cap<<"\n";
                            return 3;
                        }
                        continue;
                    }
                    for(auto x:A) for(auto y:B) for(auto z:C) for(auto t:D) {
                        const auto xy=x.bits|y.bits, zt=z.bits|t.bits;
                        if ((x.bits&y.bits)||(z.bits&t.bits)||(xy&zt)) continue;
                        ++disjoint;
                        auto val=mul(mul(x.z,y.z),mul(z.z,t.z));
                        int phase=sign(x.bits,y.bits)*sign(z.bits,t.bits)*sign(xy,zt);
                        Z &cell=result[(i*10+j)*65536+(xy|zt)];
                        cell[0]+=phase*moments[q][r]*val[0];
                        cell[1]+=phase*moments[q][r]*val[1];
                    }
                }
            }
        }
    std::cerr<<"prospective coordinate-occupancy candidates "<<candidates<<"; disjoint products "<<disjoint<<"\n";
    assert(disjoint<=candidates && 6*candidates<=INT64_MAX);
    for(int i=0;i<10;++i) for(unsigned m=0;m<256;++m) if(std::popcount(m)==4)
        for(int j=0;j<10;++j) for(unsigned n=0;n<256;++n) if(std::popcount(n)==4) {
            auto [x,y]=result[(i*10+j)*65536+(m|(n<<8))];
            if(x||y) std::cout<<i<<"\t"<<m<<"\t"<<j<<"\t"<<n<<"\t"<<x<<"\t"<<y<<"\n";
        }
}
