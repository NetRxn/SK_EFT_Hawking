from collections import Counter, defaultdict
from itertools import combinations_with_replacement, product, permutations
from fractions import Fraction
from pathlib import Path

from src.core.formulas import (original_coframe_blocks, original_spin4_link,
                               original_quaternion_haar_moment)
from src.vestigial.original_coefficients import (OriginalRegulator, Polynomial, Symbol,
                                                assemble_coframe, matrix_multiply, epsilon)

reg = OriginalRegulator()
assert reg.extents == (2,2,2,2) and reg.word == 'closed'
global_order = {g:i for i,g in enumerate(reg.generator_order)}
edge_types = {}
for axis in (0,1):
    for root in (x for x in reg.sites if x[axis] == 0):
        end = reg.step(root,axis)[0]
        sites = root,end
        start = [global_order[(x,'bar',0)] for x in sites]
        rows=[]
        for origin,x in enumerate(sites):
            for c in range(4):
                blocks = original_coframe_blocks(reg,(x,axis,c))
                assert Counter(b.anchor for b in blocks) == {(root,axis):2,(end,axis):2}
                ext = assemble_coframe(reg,blocks).to_exterior(reg)
                for full,pol in ext.terms:
                    mask = ((full>>start[0])&255) | (((full>>start[1])&255)<<8)
                    assert mask.bit_count() == full.bit_count() == 2
                    assert (mask & 255).bit_count() == (mask >> 8).bit_count() == 1
                    for (sym,),val in pol.terms:
                        y,k,chi,q = sym.index
                        assert k==axis
                        idx = 8*sites.index(y)+4*('LR'.index(chi))+q
                        real, imag = 4*val.real,4*val.imag
                        assert abs(real)+abs(imag)==1 and real.denominator==imag.denominator==1
                        rows.append((origin,c,mask,idx,int(real),int(imag)))
        assert Counter(r[:2] for r in rows)=={(x,c):64 for x,c in product(range(2),range(4))}
        edge_types[axis,root] = sorted(rows)
assert len(edge_types)==16 and len({tuple(r) for r in edge_types.values()})==1
coframes=next(iter(edge_types.values()))
def save(path,rows):
    Path(path).write_text(''.join('\t'.join(map(str,r))+'\n' for r in rows))
save('coframes.tsv',coframes)
print('canonical to_exterior exports agree for all',len(edge_types),'undirected edges:',len(coframes),'rows each')

site=reg.sites[0]
sym={chi:[Symbol('q',(site,2,chi,q)) for q in range(4)] for chi in 'LR'}
hol=original_spin4_link(*[[Polynomial.variable(s) for s in sym[chi]] for chi in 'LR'])
V={}
for i,j in product(range(4),repeat=2):
    Q=matrix_multiply(matrix_multiply(matrix_multiply(hol,reg.gamma[i]),reg.gamma[j]),reg.gamma5)
    tr=sum((Q[m][m] for m in range(4)),Polynomial())
    data=dict(tr.terms)
    if i==j: data={}
    assert all(key[0] in sym['L'][1:]+sym['R'][1:] for key in data)
    for chi in 'LR':
        z=[data[(s,)] for s in sym[chi][1:] if (s,) in data]
        assert len(z)==(i!=j) and all(v.imag==0 and abs(v.real)==2 for v in z)
        V[i,j,chi]=[data[(s,)].real//2 if (s,) in data else 0 for s in sym[chi][1:]]
ps=list(combinations_with_replacement(range(4),2))
raw={}
for chi,(r,(a,c)),(s,(b,d)) in product('LR',enumerate(ps),enumerate(ps)):
    raw[chi,r,s]=sum(sum(u*v for u,v in zip(V[x,y,chi],V[z,w,chi]))
                      for x,z in set(permutations((a,c))) for y,w in set(permutations((b,d))))
assert all(raw['L',r,s]==raw['R',r,s] for r,s in product(range(10),repeat=2))
def wg(a,c,b,d):
    return int(a==c and b==d)-int((a,c)==(b,d))*(1 if a==c else 2)
assert all(raw['L',r,s]==wg(a,c,b,d) for (r,(a,c)),(s,(b,d)) in product(enumerate(ps),repeat=2))
save('grams.tsv', [(t,r,s,v) for t in range(3) for r,s in product(range(10),repeat=2)
                  if (v:=raw['L',r,s]*(2 if t==0 else 1))])
print('chiral symmetrization matches W for all',len(raw),'entries')
assert epsilon((2,3,0,1))==1
assert epsilon((3,2,0,1))==-1
m=[]
for q,r in combinations_with_replacement(range(16),2):
    powers = [0]*16
    powers[q]+=2
    powers[r]+=2
    mom=Fraction(1)
    for g in range(4):
        mom*=original_quaternion_haar_moment(powers[4*g:4*g+4])
    z=48*mom
    assert z.denominator==1
    m.append((q,r,int(z)))
save('moments.tsv',m)
from src.vestigial.original_coefficients import ExteriorPolynomial
for mask in range(256):
    if mask.bit_count()!=4: continue
    c=255^mask
    v,w=ExteriorPolynomial(((0,Polynomial.scalar(1)),)),ExteriorPolynomial(((0,Polynomial.scalar(1)),))
    left=[i for i in range(8) if (mask>>i)&1]
    right=[i for i in range(8) if (c>>i)&1]
    for i in left: v*=ExteriorPolynomial.generator(i)
    for i in right: w*=ExteriorPolynomial.generator(i)
    direct=(-1)**sum(i>j for i,j in product(left,right))
    assert (v*w).terms==( (255,Polynomial.scalar(direct)), )
print('all 70 complement signs match canonical ExteriorPolynomial')
mixed=tuple(sum(a*b for a,b in zip(V[0,1,chi],V[2,3,chi])) for chi in 'LR')
assert mixed == (-1,1)
print('literal unsymmetrized F01*F23 chiral Gram:',mixed)
