from hashlib import sha256
from pathlib import Path
import subprocess


def git(*args):
    return subprocess.check_output(("git", *args))


def files(ref):
    rows = git("ls-tree", "-rz", ref, "--", "lean/SKEFTHawking", "lean/SKEFTHawking.lean")
    out = {}
    for row in rows.rstrip(b"\0").split(b"\0"):
        meta, name = row.split(b"\t", 1)
        if name.endswith(b".lean"):
            out[name] = meta.split()[-1]
    return out


def read_blobs(hashes):
    ordered = sorted(hashes)
    raw = subprocess.run(("git", "cat-file", "--batch"), input=b"\n".join(ordered)+b"\n",
                         capture_output=True, check=True).stdout
    pos = 0
    result = {}
    for expected in ordered:
        end = raw.index(b"\n", pos)
        digest, kind, size = raw[pos:end].split()
        assert digest == expected and kind == b"blob"
        n = int(size)
        result[digest] = raw[end+1:end+1+n]
        pos = end+2+n
    return result


def stamp(index, data):
    aggregate = b"lean/SKEFTHawking.lean"
    ordered = sorted((n for n in index if n != aggregate),
                     key=lambda name: Path(name.decode()).parts)
    ordered.append(aggregate)
    return sha256(b"".join(data[index[n]] for n in ordered)).hexdigest()[:16]


def without_comments(text):
    out = []
    i, depth = 0, 0
    while i < len(text):
        if text.startswith("/-", i):
            if not depth:
                out.append(" ")
            depth += 1
            i += 2
        elif depth:
            if text.startswith("-/", i):
                depth -= 1
                i += 2
            else:
                i += 1
        elif text.startswith("--", i):
            n = text.find("\n", i)
            i = len(text) if n == -1 else n
        elif text[i] == '"':
            j = i + 1
            while j < len(text) and text[j] != '"':
                j += 2 if text[j] == "\\" else 1
            out.append(text[i:j+1])
            i = j + 1
        else:
            out.append(text[i])
            i += 1
    assert depth == 0
    return [line.rstrip() for line in "".join(out).splitlines() if line.strip()]


old = "bf586aa77"
refs = [old, "HEAD^", "HEAD"]
indexed = [files(ref) for ref in refs]
assert indexed[1] == indexed[2]
assert indexed[0].keys() == indexed[2].keys()
data = read_blobs(set().union(*(set(index.values()) for index in indexed)))
for ref, index in zip(refs, indexed, strict=True):
    digest = stamp(index, data)
    expected = "be5f125717089b51" if ref == old else "fc377552dec9e27e"
    assert digest == expected, (ref, digest)
    print(ref, len(index), digest)
changed = [n for n, h in indexed[2].items() if h != indexed[0][n]]
assert len(changed) == 7
for n in sorted(changed):
    x = data[indexed[0][n]].decode()
    y = data[indexed[2][n]].decode()
    assert without_comments(x) == without_comments(y), n
    print(n.decode(), "unchanged non-comment source lines")
index_digests = {git("rev-parse", ref + ":lean/lean_deps.json").strip() for ref in refs}
assert len(index_digests) == 1
print("same tracked declaration JSON", index_digests.pop().decode())
assert Path("lean/lean_deps.json.hash").read_text() == "fc377552dec9e27e"
