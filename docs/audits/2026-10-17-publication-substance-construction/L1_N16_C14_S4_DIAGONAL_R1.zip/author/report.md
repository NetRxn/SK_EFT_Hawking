# Original N16 c14 pure-S4 component elimination

The pinned source is original periodic closed source_C at clean primary
27012c18fa374e8341e124b510abbedeedb18d29. All new source edge work is
independent of rank 3. The updated factor interface uses the rank-3
graph after its separate independent acceptance. This is the zero-centered
(01,01,23,23) representative, with external divisor 512.

## Original source and exact reduction

The five source centers 5, 6, 9, 10 and 15 each carry two original S4
occurrences, no centered S2 factor, and no curvature incidence on any
of their four paired coframe edges. Complete roster incidence identifies
all 20 edges and the two original owner slots for each. Four had already
been built. The other sixteen were recomputed from original source.
Their 48-row exact canonical tables match the separate signed raw
quarter-increment, literal exterior and invariant Haar route. Each
uses all sixteen degree-two Haar coordinate assignments before the
coframe filters and has denominator 64.

All 20 complete edge tables contain exactly 12 exterior mask pairs.
Every pair has four entries, one for each identical ordered component
assignment (a,a), and all four exact signed values agree. There are
no nonzero off-diagonal entries. Therefore the two ordered S4
component tuples at each of the five sites agree. The product of
their two original epsilons is one for each of 24 distinct-label
orders and zero otherwise. The mask value is independent of the
chosen order. Summing the source component labels gives a factor
24 per site and exactly 7,962,624 for all five. No exterior
coefficient, mask or sign is changed.

The 20 component-free tables are byte-identical, even with the
mixed endpoint directions recorded in the evidence. Each has
four signed numerators -16 and eight +8 at denominator 64.
The pair support and signed coefficient are invariant under
exchanging endpoints. Each endpoint contributes two generators
of one chirality, and the edge endpoints have opposite chirality.
These are exact table results for the stated original row,
not assumptions about other models or arrangements.

The already-attached rank-4 factor has exactly 16 equal label
variants for every underlying mask key. Its component-free
replacement retains one of those values per key, giving 504
rows instead of 8,064. The two older rank-8 degree-two factors
also replace their labelled tables with their exact 12-row
mask forms. These restrictions eliminate redundant labels
without summing them again. The 24 factors perform the
original component sums once. All sixteen pending exterior
tables remain in the graph as signed source factors with
actual endpoints and axes, prior to further site projection.
Their denominator multiplier is 64^16. The earlier factored
graph denominator is recorded separately. No site closure or
representative flattening was executed in this batch.

## Controls and capacity

The run reads all 24 signed ordered S4 source terms separately
at each of the five original sites. Four exact fixed-mask controls
per site independently traverse both occurrence orders, for
20 junctions. Each matches 24 times the exact signed product of
its four edge coefficients. Omitting one epsilon produces zero
from cancellation of the 12 positive and 12 negative orders.
Transposing two labels of only one original epsilon changes
the sign of every nonzero tested value. Serialized readback
independently expands every reduced table, all 8,064 original
rank-4 variants, and all 20 fixed epsilon junctions.

The successful batch charged 178,637 operations against
4,000,000 and 35,572 cumulative entries against 120,000.
It used 18,212,864 accounting bytes against 64 MiB and
32,092 serialized bytes against 4 MiB. The checked integer
magnitude limit is 2^61-1. Peak process RSS sampled during
the run was 167,821,312 bytes against the sampled 384 MiB
guard. The accounting excludes source initialization,
interpreter overhead, secondary indexing/sorting, separate
readback and manifest operations. These are local limits.

## Next exact exterior contraction

The outstanding exterior boundary is at ranks
1,2,5,6,7,9,10,11,13,14, and the pending graph also
includes unclosed rank 15. Rank 1 has its old four-generator
mask and pending edges to ranks 5 and 9. Rank 2 likewise
connects to ranks 6 and 10. Both admit compact signed local
projections. The remaining pending graph has 16 edges.
On the unweighted site graph, deterministic minimum-fill
eliminates 1,2,5,13,9,6,10,7,11,14,15 with peak
three later neighbors. This is structural only and does not
bound coefficient tables when the prior graph boundary
remains live. Use the common 12-row source table, condition
on actual fused masks and accumulate exact disjoint exterior
unions with their local signs. Compare the two rank-1/2
boundary closures to literal full-word projection before
attempting a larger joined elimination.

The full representative, other axis arrangements, c14, c0,
complete denominator and normalization remain open.
