"""Complete original degree-two Haar batch and exact pure-S4 label elimination."""
from collections import Counter, defaultdict
from itertools import product
from pathlib import Path
import json,sys

D=Path(__file__).parent
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
R4=Path('/tmp/publication-c14-rank4-r1.i7hYiY')
R12=Path('/tmp/publication-c14-rank12-r1.ehXXAy')
R3=Path('/tmp/publication-c14-rank3-r1.q1WfND')
sys.path.insert(0,str(STAR))
import cut

ZERO=(0,0)
CENTERS=(5,6,9,10,15)
EXISTING={
  (5,3):(R4/'rank4-edge-axis3.jsonl',4,5),
  (6,2):(R4/'rank4-edge-axis2.jsonl',4,6),
  (9,3):(STAR/'edge-3.jsonl',8,9),
  (10,2):(STAR/'edge-2.jsonl',8,10),
}

def read(p):
    with p.open() as f:
        for s in f:
            cut.work('frozen_read')
            yield json.loads(s)

def load(p):
    out={}
    for k,z in read(p):
        k=tuple(k)
        assert k not in out
        cut.reserve('loaded_exact_table',k,out)
        out[k]=tuple(z)
    return out

def diagonal(table):
    by=defaultdict(dict)
    for (m,n,a,b),z in table.items():
        cut.work('diagonal_label_check')
        assert a==b and z!=ZERO
        cut.reserve('diagonal_label_index',a,by[m,n])
        by[m,n][a]=z
    assert len(by)==12
    out={}
    for k,a in by.items():
        cut.work('equal_coefficient_check')
        assert set(a)=={0,1,2,3} and len(set(a.values()))==1
        cut.reserve('reduced_mask_pair',k,out)
        out[k]=a[0]
    return out

def source_eps(site):
    # Read both occurrence copies of the original ordered source S4
    # coefficient (all centers use the same explicit ordered constructor).
    out={}
    for f in cut.original_action_factors_cached(cut.REG.sites[site]):
        if f.t_degree!=4:
            continue
        cut.work('ordered_original_S4_source')
        assert tuple(mu for _,mu,a in f.components)==(0,1,2,3)
        assert all(x==cut.REG.sites[site] for x,mu,a in f.components)
        label=tuple(a for _,mu,a in f.components)
        ((symbol,z),)=f.coefficient.terms
        assert not symbol and not z.imag and z.real in (-1,1)
        sg=(-1)**sum(a>b for i,a in enumerate(label) for b in label[i+1:])
        assert int(z.real)==sg
        cut.reserve('source_epsilon',label,out)
        out[label]=sg
    assert len(out)==24
    return out

def exact_controls(site,original,reduced,eps):
    # Fixed exact exterior mask tuples. Enumerate all independently
    # ordered source terms, with the two occurrences kept separate.
    choices=[sorted(x) for x in reduced]
    out=[]
    for j in (0,4,8,11):
        masks=tuple(t[(j+3*i)%len(t)] for i,t in enumerate(choices))
        grouped=wrong_order=one_epsilon=ZERO
        for (p,s),(q,t) in product(eps.items(),repeat=2):
            cut.work('fixed_source_epsilon_pair')
            value=(1,0)
            for i,(a,b) in enumerate(zip(p,q,strict=True)):
                value=cut.times(value,original[i].get((*masks[i],a,b),ZERO))
            grouped=cut.add(grouped,cut.scale(value,s*t))
            one_epsilon=cut.add(one_epsilon,cut.scale(value,s))
            swapped=(q[1],q[0],q[2],q[3])
            wrong_order=cut.add(wrong_order,cut.scale(value,s*eps[swapped]))
        base=(1,0)
        for i,k in enumerate(masks):
            base=cut.times(base,reduced[i][k])
        expected=cut.scale(base,24)
        assert grouped==expected and grouped!=ZERO and wrong_order==cut.scale(grouped,-1)
        assert one_epsilon==ZERO
        cut.reserve('fixed_source_control',len(out),{})
        out.append(dict(site=site,ordered_masks=masks,signed_product_before_epsilon=base,
            exact_numerator=grouped,transposed_one_epsilon_numerator=wrong_order,
            omitted_one_epsilon_numerator=one_epsilon,denominator=64**4))
    return out

def reduce_prior():
    # Rank-4 closure contains diagonal-equal component labels of rank6
    # on axis2 and rank5 on axis3. Restrict to a representative label
    # rather than summing these slots again, since factor24 does the sum.
    raw=load(R4/'rank4-closure.jsonl')
    g=defaultdict(dict)
    for (m,n,r,a,b,s,c,d),z in raw.items():
        cut.work('verify_prior_rank4_label')
        assert a==b and c==d
        k=(m,n,r,s)
        cut.reserve('rank4_label_check',(a,c),g[k])
        g[k][a,c]=z
    out={}
    for k,variant in g.items():
        cut.work('verify_prior_rank4_reduction')
        assert set(variant)==set(product(range(4),repeat=2)) and len(set(variant.values()))==1
        cut.reserve('rank4_exterior_reduction',k,out)
        out[k]=variant[0,0]
    assert len(out)==504
    cut.write_rows('rank4-closure-exterior.jsonl',out)

def graph(pending):
    g=json.loads((R3/'graph.json').read_text())
    removal={'S4_6_a2_0','S4_6_a2_1','S4_5_a3_0','S4_5_a3_1',
             'S4_9_a3_0','S4_9_a3_1','S4_10_a2_0','S4_10_a2_1'}
    g['boundary']=[x for x in g['boundary'] if x not in removal]
    for f in ('rank4_closure','rank8_edge2','rank8_edge3'):
        g['factor_keys'][f]=[x for x in g['factor_keys'][f] if x not in removal]
    g['reduced_factor_files']={
       'rank4_closure':'rank4-closure-exterior.jsonl',
       'rank8_edge2':'s4-10-axis2-exterior.jsonl',
       'rank8_edge3':'s4-9-axis3-exterior.jsonl'}
    g['scalar_numerator_multiplier']=24**5
    g['pending_exterior_edges']=pending
    g['pending_exterior_denominator_multiplier']=64**len(pending)
    g['semantics']+=' The component-free factors include one separate scalar 24 per pure S4 site. Pending degree-two edges are exact signed exterior factors, with their rank and axis order recorded. They still require site exterior disjointness, saturation and signs before the overall coefficient is evaluated.'
    (D/'graph.json').write_text(json.dumps(g,indent=2)+'\n')

def main():
    cut.OUT=D
    cut.ROW_CAP=120_000
    cut.rss()
    counts={}
    pending=[]
    scopes={}
    all_controls=[]
    original={}
    reduced={}
    row=cut.roster()
    for s in CENTERS:
        cut.work('complete_site_roster')
        assert row['S4_occupations'][s]==2 and all(x!=s for x,_,_ in row['planes'])
        edges=cut.star_owners(row,s)
        original[s]=[]
        reduced[s]=[]
        for desc in edges:
            axis,neighbor,frames,traces=desc
            assert frames==[('S4',s,0,axis),('S4',s,1,axis)] and not traces
            stem=f's4-{s}-axis{axis}'
            if (s,axis) in EXISTING:
                source,first,second=EXISTING[s,axis]
                assert {first,second}=={s,neighbor}
                table=load(source)
                reused=True
            else:
                first,second=s,neighbor
                a,den,support=cut.edge_tensor(desc,s,False)
                b,den0,support0=cut.edge_tensor(desc,s,True)
                assert a==b and den==den0==64 and support==support0==16 and len(a)==48
                table=a
                cut.write_rows(stem+'-raw-complete.jsonl',table)
                reused=False
            simple=diagonal(table)
            cut.write_rows(stem+'-exterior.jsonl',simple)
            ident=(min(s,neighbor),max(s,neighbor),axis)
            assert str(ident) not in counts
            counts[str(ident)]=dict(site=s,axis=axis,mask_order=[first,second],
                nonzero_rows=len(table),exterior_rows=len(simple),
                reused_accepted_original_source_table=reused,
                denominator=64,exterior_signs=sorted({z for z in simple.values()}))
            if not reused:
                pending.append(dict(axis=axis,mask_order=[first,second],file=stem+'-exterior.jsonl',denominator=64))
            original[s].append(table)
            reduced[s].append(simple)
        print('verified raw four-edge incidence',s,flush=True)
    assert len(counts)==20 and len(pending)==16
    for s in CENTERS:
        eps=source_eps(s)
        all_controls.extend(exact_controls(s,original[s],reduced[s],eps))
        scopes[str(s)]=dict(original_occurrences=[0,1],distinct_orders=len(eps),
                            signed_mask_domain=12**4,component_multiplier=24)
        print('verified factor24',s,flush=True)
    reduce_prior()
    graph(pending)
    cut.rss()
    out=dict(site_controls=all_controls,edges=counts,site_factors=scopes,
        new_edges=len(pending),verified_pure_site_edges=len(counts),
        rank4_reduced_rows=504,combined_scalar_multiplier=24**5,
        charged_operations=dict(cut.WORK),storage=dict(cut.STORE),rss_peak_bytes=cut.RSS_PEAK,
        cap=dict(rows=cut.ROW_CAP,work=cut.WORK_CAP,accounted_bytes=cut.BYTE_CAP,
                 serialized_bytes=cut.FILE_CAP,sampled_rss=cut.RSS_CEILING,scalar=cut.INT_LIMIT))
    (D/'result.json').write_text(json.dumps(out,indent=2)+'\n')
    print('verified all pure S4 reductions',flush=True)

if __name__=='__main__':
    main()
