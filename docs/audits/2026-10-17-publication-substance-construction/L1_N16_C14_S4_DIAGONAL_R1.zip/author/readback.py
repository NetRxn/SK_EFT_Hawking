"""Independent exact table and component-free carrier readback."""
from collections import Counter,defaultdict
from itertools import permutations,product
from pathlib import Path
import json

D=Path(__file__).parent
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
R4=Path('/tmp/publication-c14-rank4-r1.i7hYiY')
KNOWN={(5,3):R4/'rank4-edge-axis3.jsonl',(6,2):R4/'rank4-edge-axis2.jsonl',
       (9,3):STAR/'edge-3.jsonl',(10,2):STAR/'edge-2.jsonl'}
SITES=(5,6,9,10,15)

def read(p):
    seen={}
    for line in p.read_text().splitlines():
        k,z=json.loads(line)
        assert tuple(k) not in seen
        seen[tuple(k)]=tuple(z)
    return seen

def prod(z,w):
    a,b=z
    c,d=w
    return a*c-b*d,a*d+b*c

def add(z,w):
    return z[0]+w[0],z[1]+w[1]

common=None
by_site={}
for s in SITES:
    exact=[]
    for a in range(4):
        original=KNOWN.get((s,a),D/f's4-{s}-axis{a}-raw-complete.jsonl')
        t=read(original)
        c=read(D/f's4-{s}-axis{a}-exterior.jsonl')
        assert len(c)==12 and len(t)==48
        assert t=={(*k,b,b):v for k,v in c.items() for b in range(4)}
        if common is None:
            common=c
        assert c==common
        exact.append(t)
    by_site[s]=exact
assert Counter(common.values())=={(-16,0):4,(8,0):8}
for (m,n),z in common.items():
    assert common[n,m]==z
    assert m.bit_count()==n.bit_count()==2
    assert (m<16)!=(n<16)

rank4=read(R4/'rank4-closure.jsonl')
red4=read(D/'rank4-closure-exterior.jsonl')
assert len(red4)==504
assert rank4=={(m,n,r,a,a,s,b,b):z for (m,n,r,s),z in red4.items()
              for a,b in product(range(4),repeat=2)}

def sign(p):
    return (-1)**sum(a>b for i,a in enumerate(p) for b in p[i+1:])

p=list(permutations(range(4)))
control=json.loads((D/'result.json').read_text())['site_controls']
for x in control:
    t=by_site[x['site']]
    masks=x['ordered_masks']
    ans=(0,0)
    for a,b in product(p,repeat=2):
        u=(sign(a)*sign(b),0)
        for i,(j,k) in enumerate(zip(a,b,strict=True)):
            u=prod(u,t[i].get((*masks[i],j,k),(0,0)))
        ans=add(ans,u)
    assert list(ans)==x['exact_numerator']

print(json.dumps(dict(exact_tables=20,identical_reduced_edge_tables=20,
    common_edge_rows=[[k,z] for k,z in sorted(common.items())],
    matched_component_free_rank4_rows=len(red4),replayed_fixed_controls=len(control),
    next_edge_structure=dict(each_endpoint_pairs_two_generators_one_chirality=True,
      opposite_chiralities_between_endpoints=True,endpoint_reversal_exactly_invariant=True)),indent=2))
