from collections import Counter, defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from fractions import Fraction
import json,sys
from src.core.formulas import original_action_factors, original_spin4_link, original_coframe_blocks
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
A,T,S,SE,P=map(Path,sys.argv[1:6])
def load(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def f(v): return tuple(map(f,v)) if isinstance(v,(tuple,list)) else v
def tbl(p):
    rr=f(rows(p)); t=dict(rr); assert len(rr)==len(t)
    return t
def co(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def add(z,w):return z[0]+w[0],z[1]+w[1]
def sign(w):return (-1)**sum(i>j for k,i in enumerate(w) for j in w[k+1:])
def pos(site,mask):return [8*site+i for i in range(8) if mask>>i&1]
R=OriginalRegulator()
index={x:i for i,x in enumerate(R.sites)}
positions={g:i for i,g in enumerate(R.generator_order)}
assert (R.extents,R.boundary_signs,R.convention,R.word)==((2,)*4,(1,)*4,'source_C','closed')
L={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in R.link_order}
M=load(A/'result.json')
G=load(A/'graph.json')
base=load(T/'graph.json')
C=load(P/'support-census.json')['sites']
row=load(S/'result.json')['row']
assert row['exponential_divisor']==512
acts=[]
for i,(x,*axes) in enumerate(row['planes']):
    anchors={tuple(sorted((index[tuple(y)],d) for y,d in aa)) for degree,comp,aa,n,_ in C[x]['raw_branches']
             if n and degree==2 and sorted(j for j,_ in comp)==axes}
    assert len(anchors)==1
    acts.append(('S2',x,i,tuple(axes),next(iter(anchors))))
acts += [('S4',x,i,tuple(range(4)),()) for x,n in enumerate(row['S4_occupations']) for i in range(n)]

def edge(rank,d):
    return frozenset((rank,index[R.step(R.sites[rank],d)[0]]))
def owner(rank,axis):
    E=edge(rank,axis)
    frames=[(s,x,i,d) for s,x,i,axes,_ in acts for d in axes if edge(x,d)==E]
    traces=[(s,x,i,(k,d)) for s,x,i,_,aa in acts for k,d in aa if edge(k,d)==E]
    return f(frames),f(traces)
fr,tr=owner(4,0)
assert f(M['edge'])==(0,12,fr,tr)
assert fr==(('S4',12,0,0),('S4',12,1,0))
assert tr==(('S2',0,2,(4,0)),('S2',0,3,(4,0)))

@cache
def moment(q):
    ns=Counter(q)
    if any(n%2 for n in ns.values()):return Fraction()
    return Fraction(prod(3 if n==4 else 1 for n in ns.values()),
        prod(j for n in Counter(i//4 for i in q).values() for j in range(4,4+n,2)))

def compute(site,axis,trace_slots,center):
    neighbor=next(iter(edge(site,axis)-{site}))
    ends=tuple(sorted((site,neighbor)))
    # The actual coframes all center at rank 12, including residual edge.
    alpha=defaultdict(list)
    qindex={(R.sites[x],axis,h,k):i for i,(x,h,k) in enumerate(product(ends,('L','R'),range(4)))}
    for component in range(4):
        for b in original_coframe_blocks(R,(R.sites[center],axis,component),L):
            for i,j in product(range(4),repeat=2):
                w=(positions[b.bar_site,'bar',i],positions[b.psi_site,'psi',j])
                for sy,z in b.matrix[i][j].terms:
                    assert len(sy)==1 and sy[0].index[:2]==b.anchor
                    c=(z.real*4*b.weight,z.imag*4*b.weight)
                    assert all(v.denominator==1 for v in c)
                    alpha[qindex[sy[0].index]].append((component,w,tuple(map(int,c))))
    support=0
    grouped=defaultdict(lambda:(0,0))
    weight_scale=48 if trace_slots else 4
    for q in product(range(16),range(16),*trace_slots):
        H=moment(q)*weight_scale
        if not H:continue
        assert H.denominator==1
        support+=1
        for (a,w,z),(b,v,t) in product(alpha[q[0]],alpha[q[1]]):
            word=w+v
            if len(set(word))!=4:continue
            local,remote=(sum(1<<(i%8) for i in word if i//8==x) for x in (site,neighbor))
            assert local.bit_count()==remote.bit_count()==2
            key=(local,remote,a,b,*q[2:])
            grouped[key]=add(grouped[key],tuple(int(H)*sign(word)*u for u in co(z,t)))
    nonzero={k:v for k,v in grouped.items() if any(v)}
    return nonzero,support,len(grouped)-len(nonzero)

from itertools import permutations
from src.vestigial.original_coefficients import epsilon
B,PRE,P4=map(Path,sys.argv[6:9])
m=load(B/'result.json')
existing={(5,3):(P4/'rank4-edge-axis3.jsonl',4,5),(6,2):(P4/'rank4-edge-axis2.jsonl',4,6),
          (9,3):(S/'edge-3.jsonl',8,9),(10,2):(S/'edge-2.jsonl',8,10)}
centers=(5,6,9,10,15)
raw={}
red={}
pending=[]
common=None
for c,d in product(centers,range(4)):
    e=edge(c,d)
    other=next(iter(e-{c}))
    fr,tr=owner(c,d)
    assert fr==tuple(('S4',c,j,d) for j in (0,1)) and not tr
    stem=f's4-{c}-axis{d}'
    if (c,d) in existing:
        p,first,second=existing[c,d]
    else:
        p=B/(stem+'-raw-complete.jsonl')
        first,second=c,other
        pending.append(dict(axis=d,mask_order=[first,second],file=stem+'-exterior.jsonl',denominator=64))
    assert {first,second}==e
    table,coordinate_support,zeros=compute(first,d,(),c)
    assert (len(table),coordinate_support,zeros)==(48,16,240)
    assert table==tbl(p)
    raw[c,d]=table
    masks={(u,v):z for (u,v,a,b),z in table.items() if a==b==0}
    assert len(masks)==12 and all(any(z) for z in masks.values())
    assert {(u,v,a,a):z for (u,v),z in masks.items() for a in range(4)}==table
    assert tbl(B/(stem+'-exterior.jsonl'))==masks
    expected=load(B/'result.json')['edges'][str((min(e),max(e),d))]
    assert expected['site']==c and expected['axis']==d and expected['mask_order']==[first,second]
    assert expected['reused_accepted_original_source_table']==((c,d) in existing)
    red[c,d]=masks
    if common is None:common=masks
    assert masks==common
assert len(pending)==16 and len(raw)==len(red)==20
assert len({(B/f's4-{c}-axis{d}-exterior.jsonl').read_bytes() for c,d in product(centers,range(4))})==1
assert Counter(common.values())=={(-16,0):4,(8,0):8}
assert common=={(n,m):z for (m,n),z in common.items()}
def ch(x):
    assert x.bit_count()==2
    assert (x&15==x) or (x&240==x)
    return x&15!=0
assert all(ch(u)!=ch(v) for u,v in common)
print('all 20 raw source maps and 20 byte-identical 12-row reductions verified, including endpoint order',flush=True)

o=tbl(P4/'rank4-closure.jsonl')
compressed=tbl(B/'rank4-closure-exterior.jsonl')
assert len(compressed)==504
assert {(m,n,r,a,a,s,b,b):z for (m,n,r,s),z in compressed.items() for a,b in product(range(4),repeat=2)}==o
print('all 8064 original rank4 variants exactly recover from 504 keys',flush=True)

orders=list(permutations(range(4)))
assert all(epsilon(k)==sign(k) for k in orders)
assert sum(epsilon(k) for k in orders)==0
assert sum(epsilon(k)**2 for k in orders)==24
for x in m['site_controls']:
    c=x['site']
    masks=f(x['ordered_masks'])
    rawcoeff=(1,0)
    for d,m0 in enumerate(masks):
        rawcoeff=co(rawcoeff,red[c,d][m0])
    out=swap=omit=(0,0)
    for p,q in product(orders,repeat=2):
        value=(1,0)
        for d,(a,b) in enumerate(zip(p,q,strict=True)):
            value=co(value,raw[c,d].get((*masks[d],a,b),(0,0)))
        mul=lambda s:tuple(s*v for v in value)
        out=add(out,mul(epsilon(p)*epsilon(q)))
        swap=add(swap,mul(epsilon(p)*epsilon((q[1],q[0],*q[2:]))))
        omit=add(omit,mul(epsilon(p)))
    assert out==f(x['exact_numerator'])==tuple(24*y for y in rawcoeff)
    assert omit==f(x['omitted_one_epsilon_numerator'])==(0,0)
    assert swap==f(x['transposed_one_epsilon_numerator'])==tuple(-y for y in out)
    assert x['denominator']==64**4
assert len(m['site_controls'])==20
print('20 exact junction controls and omission/one-occurrence epsilon sign adversaries matched',flush=True)

base=load(PRE/'graph.json')
g=load(B/'graph.json')
drop={'S4_6_a2_0','S4_6_a2_1','S4_5_a3_0','S4_5_a3_1','S4_9_a3_0','S4_9_a3_1','S4_10_a2_0','S4_10_a2_1'}
assert g['boundary']==[x for x in base['boundary'] if x not in drop]
assert g['factor_keys']=={k:[x for x in v if x not in drop] for k,v in base['factor_keys'].items()}
assert g['reduced_factor_files']=={'rank4_closure':'rank4-closure-exterior.jsonl','rank8_edge2':'s4-10-axis2-exterior.jsonl','rank8_edge3':'s4-9-axis3-exterior.jsonl'}
assert pending==g['pending_exterior_edges']
assert g['combined_denominator']==base['combined_denominator']
assert g['pending_exterior_denominator_multiplier']==64**16
assert g['external_exponential_divisor']==512
assert g['scalar_numerator_multiplier']==m['combined_scalar_multiplier']==24**5==7962624

# Unweighted minimum fill independent structural replay. Live external graph
# tensors are excluded. This does not price their coefficients.
adj=defaultdict(set)
for p in pending:
    u,v=p['mask_order']
    adj[u].add(v);adj[v].add(u)
order=[];peak=0
while adj:
    def key(u):
        ns=adj[u]
        return sum(y not in adj[x] for x in ns for y in ns if y>x),len(ns),u
    u=min(adj,key=key)
    order.append(u)
    ns=adj.pop(u)
    peak=max(peak,len(ns))
    for v in ns:
        adj[v].remove(u)
        adj[v].update(ns-{v})
assert order==[1,2,5,13,9,6,10,7,11,14,15] and peak==3
print('graph, source denominators, factor 24^5 and structural min-fill order matched',flush=True)

for site in (1,2):
    two=[p for p in pending if site in p['mask_order']]
    assert len(two)==2
    old={k[2] for k,_ in rows(PRE/f'merge-rank{site}.jsonl')}
    proposals=[]
    for k,l in product(common,repeat=2):
        a,b=(t[p['mask_order'].index(site)] for t,p in zip((k,l),two))
        if a&b:continue
        m=255^(a|b)
        if m in old:proposals.append((m,k,l))
    print('rank',site,'next paired raw proposals',144,'signed disjoint admissible',len(proposals),'old masks',len({p[0] for p in proposals}),flush=True)
