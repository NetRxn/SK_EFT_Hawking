from pathlib import Path
import json,sys
p=Path(sys.argv[1]);m=json.loads((p/'result.json').read_text())
s=m['storage'];c=m['cap']
assert sum(m['charged_operations'].values())==178637<c['work']==4_000_000
assert s['rows']==35572<c['rows']==120000
assert s['charged_bytes']==512*s['rows']==18212864<c['accounted_bytes']==64*1024**2
assert s['serialized_bytes']==sum(f.stat().st_size for f in p.glob('*.jsonl'))==32092<c['serialized_bytes']==4*1024**2
assert m['rss_peak_bytes']==167821312<c['sampled_rss']==384*1024**2
assert c['scalar']==2**61-1
print('scoped local work, cumulative rows, accounting and output bytes, and sampled RSS receipt checked')
