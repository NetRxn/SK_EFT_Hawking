# Independent complete signed Group 1302 review

The work-start continuity check accepted publication commit `5687ddabe554e47f7e7cb4b1e7ca88cb2cb2487f`. The verified component-98 preparation archive supplies all 88 signed prepared factor families and both exact zero restrictions. The prepared-source SHA256 `9f5051c6dbb4732ea9c9e0d5401881f998b54df579a7cc551e5857e279a9ca32` matches the checked source archive and the author-run operand. The preparation has 666,311 stored rows after two verified signed sweeps from 2,214,418 input rows. This review inherits the accepted preparation and begins at that exact source. The source reconciliation at `30f2fef8b65b5f20ab68444d59f68eefa275feec` rechecked all four assigned archive hashes. The changed paths concern Group 1296 acceptance, a prospective state design, and the disposition records. The acceptance-time r2 packet is fresh at that exact checkpoint, with no changed inputs.

I independently enumerated all 4,096 binary assignments on the 12 joint-L coordinates and checked the eight original indexed tuples. The six live ordinals remain 0, 1, 2, 3, 4 and 6. Original 5 and 7 each have 13 empty factor restrictions and give exact zero. The six live selections independently inverse-lift every conditioned signed row. All label scopes and denominators match the source.

Each native replay uses alternate sparse traversal and reproduces the row-cap refusal and all retained signed tables. For every continuation, the independent checker inversely reconstructs the exact declared splits, replays complex phase and scale over closed incidence-two axes, and recomputes all retained joins with reverse iteration and necessary peer projections. All retained factor scopes, signed coefficients and denominators match every frozen author state through six axis-empty terminals. Discarded continuation trials are preserved separately. Their exact typed records match both the author log and the frozen checkpoint journal, and their charged visits agree with the independently verified retained-work totals. The native guard threshold itself was separately reproduced for each live ordinal.

## Exact composition and timing

All eight signed values have zero imaginary part and share the inherited positive denominator `889157184566856082966054315229184`. The exact source labels, raw numerators, and terminal hashes are in `scalar.tsv`. `composition.tsv` gives the exact stored-factor value, the single group after the physical prefactor, and the standalone weighted contribution. The geometry audit checks component 98’s selected side, all 128 directed edges in its (K_{8,8}) support at multiplicity 2, and Group 1302’s exact chiral partner 2429. The verified physical phase is positive and the divisor is (2^{132}). The coefficient 192 applies exactly once, comprising the occupation weight 48, the chiral factor two and the selected-side factor two.

The timing ledger separates shared preparation, guarded native work, continuation, separate terminal work, and any original unsuccessful attempt. Per-ordinal solve wall time and independent replay time are listed separately. These are measurements for the frozen six routes and should be used at that scope.

## Reproduction

Verify `review.sha256` and locate the unchanged frozen external binary operands listed under each `author/L*`. Run:

```sh
python3 -B source_review.py
python3 -B controls.py
for i in 0 1 2 3 4 6; do python3 -B prefix.py "$i"; done
python3 -B typed_refusals.py
python3 -B retally.py
```

The package contains the replay scripts, final logs, checkpoint pins and exact signed ledgers. The large binary operands remain external and checksum-pinned.
