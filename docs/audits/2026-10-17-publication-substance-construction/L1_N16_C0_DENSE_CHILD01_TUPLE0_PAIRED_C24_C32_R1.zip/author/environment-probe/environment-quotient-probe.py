from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle
import time

namespace = {}
source = Path('checkpoint/quotient.py').read_text()
exec(source.split('\nlocal_test()\n',1)[0],namespace)
namespace['local_test']()
quotient = namespace['quotient']
with Path('combined-28.pkl').open('rb') as stream:
    factors = pickle.load(stream)['factors']
degree = Counter(axis for axes,_,_ in factors for axis in axes)

def products(a,b):
    shared = tuple(axis for axis in a[0] if axis in b[0])
    def hist(factor):
        axes, table, _ = factor
        indices = tuple(axes.index(axis) for axis in shared)
        return Counter(tuple(row[index] for index in indices) for row in table)
    left,right = hist(a),hist(b)
    return sum(mult*right[key] for key,mult in left.items())

for i,j in ((2,6),(2,3),(2,5)):
    started=time.monotonic()
    a,b=factors[i],factors[j]
    before=products(a,b)
    A,B,fold1=quotient(a,b,degree)
    B,A,fold2=quotient(B,A,degree)
    after=products(A,B)
    assert 0 <= after <= before
    print(i,j,before,after,len(A[1]),len(B[1]),fold1,fold2,round(time.monotonic()-started,3),sep='\t',flush=True)
