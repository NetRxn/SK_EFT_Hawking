from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
import time

indices = (5, 6)
shard_count = 8
assert {int(row.split('\t')[0]) for row in Path('rescue.tsv').read_text().splitlines()
        if row.split('\t')[1]=='2'} == set(indices)

def run(task):
    index, shard = task
    start = time.monotonic()
    receipt = Path(f'slice-{index}-shard-{shard}.out')
    source = f'join-cap-dense-label-rescue-{index}-1-reduced.pkl'
    with receipt.open('xb') as stream:
        subprocess.run([sys.executable,'triangle-shards.py',source,str(shard),str(shard_count)],
                       stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=90)
    return f'{index}\t{shard}\t{time.monotonic()-start:.3f}'

with ThreadPoolExecutor(max_workers=2) as pool, Path('shard-timing.tsv').open('x') as timing:
    for row in pool.map(run, ((i,s) for i in indices for s in range(shard_count))):
        print(row,file=timing,flush=True)
for index in indices:
    with Path(f'slice-{index}-shard-sum.out').open('xb') as stream:
        subprocess.run([sys.executable,'sum-shards.py',str(index),str(shard_count)],stdout=stream,check=True)
with Path('author-case24.tsv').open('xb') as stream:
    subprocess.run([sys.executable,'sum-case24.py'],stdout=stream,check=True)
print(Path('author-case24.tsv').read_text().splitlines()[-1])
