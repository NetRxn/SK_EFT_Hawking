from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run
from sys import executable

author = Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe24-inner')
def replay(row):
    i, coordinate, count, real, imaginary, receipt = row.split('\t')
    if 'shard-sum' in receipt:
        with Path(f'slice-{i}-triangle-replay.out').open('w') as log:
            r = run([executable,'-B','-u','triangle.py',i],stdout=log,check=True,timeout=120)
        return i,'triangle',r.returncode
    stage = receipt.removesuffix('-contract.out')
    state = author/f'label-{stage}-reduced-frontier.pkl'
    for method in ('sparse', 'sparse-support'):
        with Path(f'slice-{i}-{method}-replay.out').open('w') as log:
            r = run([executable,'-B','-u',f'{method}-replay.py',i,'0',str(state),str(author/receipt)],stdout=log,check=False,timeout=120)
        if r.returncode == 0:
            Path(f'slice-{i}-replay.out').write_bytes(Path(f'slice-{i}-{method}-replay.out').read_bytes())
            return i,method,r.returncode
    raise ValueError(i)

with ThreadPoolExecutor(max_workers=3) as workers:
    rows = (author/'author-case24.tsv').read_text().splitlines()[:-1]
    for result in workers.map(replay,rows):
        print(*result,sep='\t',flush=True)
