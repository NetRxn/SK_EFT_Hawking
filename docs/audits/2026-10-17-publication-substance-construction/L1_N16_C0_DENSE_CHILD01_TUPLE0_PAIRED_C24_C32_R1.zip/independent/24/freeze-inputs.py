from hashlib import sha256
from pathlib import Path
import shutil

root=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
author=root/'tuple0-pair-equivalence'
inner=author/'probe24-inner'
review=Path.cwd()
bases=(('paired',author),('inner',inner))
allowed={'.out','.roster','.tsv','.py'}
for dest,base in bases:
    manifest=review/f'{dest}-operands.sha256'
    paths=[]
    for source in sorted(base.iterdir()):
        if source.is_file() and (dest=='inner' or '24' in source.name or source.name in ('sum-branches.py','sum-branches-checked.py','reduce-label-frontier.py','contract-reduced-label.py')):
            if source.suffix in allowed|{'.pkl'}:
                paths.append(source)
    paths.append(base/'checkpoint/quotient.py')
    if dest=='paired':
        paths+=list(sorted(root.glob('row-cap-physical-slice-dense-label-tuple0-branch-*-reduced.pkl')))
        paths.append(root/'tuple0-branch0-pilot/pilot.roster')
    with manifest.open('w') as out:
        for source in paths:
            h=sha256(source.read_bytes()).hexdigest()
            print(h,source,sep='  ',file=out)
            if source.suffix in allowed:
                rel=source.relative_to(base) if source.is_relative_to(base) else Path('original-roster.roster')
                target=review/'author-receipts'/dest/rel
                target.parent.mkdir(exist_ok=True,parents=True)
                shutil.copyfile(source,target)
