from collections import Counter
from pathlib import Path
from pickle import loads
import re
ROOT=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe32-inner')
TERMINAL_INPUTS={index:(f'join-cap-dense-label-rescue-{index}-1-reduced.pkl' if index in (2,3) else
                        f'row-cap-physical-slice-dense-label-rescue-{index}-1-reduced.pkl') for index in (2,3,7,8)}


def projection(axes, edge):
    positions = tuple(axes.index(k) for k in edge)
    return lambda row: tuple(row[p] for p in positions)


for index in (2, 3, 7, 8):
    checkpoint = loads((ROOT / TERMINAL_INPUTS[index]).read_bytes())
    factors = checkpoint['factors']
    triangle = index in (2, 3)
    pivot = 0 if triangle else 1
    others = (1, 2) if triangle else (3,)
    left_axes, left_rows, _ = factors[pivot]
    ordered = sorted(left_rows)
    traffic = []
    for other in others:
        right_axes, right_rows, _ = factors[other]
        edge = tuple(sorted(set(left_axes) & set(right_axes)))
        left_key = projection(left_axes, edge)
        counts = Counter(map(projection(right_axes, edge), right_rows))
        traffic.append([counts[left_key(row)] for row in ordered])
    candidates = [min(counts) for counts in zip(*traffic, strict=True)]
    paths = sorted(ROOT.glob(f'slice-{index}-shard-[0-9]*.out'))
    assert len(paths) == 8
    total = 0
    author_triples = 0
    for shard, path in enumerate(paths):
        assert path.name == f'slice-{index}-shard-{shard}.out'
        lo, hi = len(ordered)*shard//8, len(ordered)*(shard+1)//8
        expected = sum(candidates[lo:hi])
        log = path.read_text()
        assert f'left row interval {lo} {hi} of {len(ordered)} shard {shard} of 8' in log.splitlines()
        assert f"conditioning {checkpoint['conditioning']} label partition {checkpoint['label_partition']}" in log.splitlines()
        if triangle:
            match = re.search(r'^triangle closure (\d+) nonzero-support triples (\d+) bounded probes products (\d+) output rows 1$', log, re.M)
            triples, probes, products = map(int, match.groups())
            assert probes == expected and products == 2*triples
            author_triples += triples
        else:
            assert f'left pair 1 3 candidate matches {expected} closure pair 0 2' in log.splitlines()
        total += expected
        print('PASS case', index, 'author shard', shard, 'pivot factor', pivot,
              'row interval', (lo, hi), 'independently counted', expected, 'probes' if triangle else 'pair matches')
    assert total == sum(candidates)
    if not triangle:
        assert total == 4704000
    if triangle:
        replay = Path(f'slice-{index}-triangle-replay.out').read_text()
        match = re.search(r'^independent pivot [12] probes \d+ triples (\d+) ', replay, re.M)
        assert int(match[1]) == author_triples
    print('PASS case', index, 'complete author shard coverage through', len(ordered), 'pivot rows; total', total)
