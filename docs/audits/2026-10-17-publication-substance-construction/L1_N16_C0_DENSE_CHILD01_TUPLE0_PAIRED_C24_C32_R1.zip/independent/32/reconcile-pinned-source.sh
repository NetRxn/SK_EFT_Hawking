#!/usr/bin/env bash
set -euo pipefail
publication=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103
original=6fe1c4495556d42962fae9e3b20cca8856fd0d5d
record=docs/audits/2026-10-17-publication-substance-construction/L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_MIDDLE23_R1.zip
hex=$(git -C "$publication" rev-parse "$original:$record")
current=$(git -C "$publication" rev-parse "HEAD:$record")
test "$hex" = "$current"
git -C "$publication" show "$original:$record" | cmp - "$publication/$record"
printf 'PASS unchanged committed and live archive %s %s\n' "$hex" "$record"
printf 'current head '
git -C "$publication" rev-parse HEAD
