#!/usr/bin/env bash
set -euo pipefail
cat lineage-*/stage-timing.tsv | sort -k1,1n > lineage-stage-timing.tsv
python3 - <<'PY'
from pathlib import Path
rows=[line.split('\t') for line in Path('lineage-stage-timing.tsv').read_text().splitlines()]
assert len(rows)==53 and sum(row[2]=='2' for row in rows)==17
assert len(Path('lineage.tsv').read_text().splitlines())==22
assert not Path('lineage-errors.out').read_text()
assert not Path('replay-errors.out').read_text()
with Path('REVIEW.md').open('a') as report:
    print(f'\nAll 53 commands for the 22 inner stages reproduced every log and saved checkpoint byte, including 17 documented refusals and five generic terminals. The sum of elapsed command times was {sum(float(row[-1]) for row in rows):.3f} seconds across concurrent replay workers.',file=report)
PY
{
  find author-receipts -type f
  printf '%s\n' *.py *.sh *.out *.tsv *-operands.sha256 REVIEW.md ../continuity.json continuity-readback.json ../pin-sources.py ../source-pins.out
} | awk '!/^review-manifest/' | LC_ALL=C sort -u | xargs shasum -a 256 > review-manifest.sha256
shasum -a 256 -c review-manifest.sha256 > review-manifest-verify.out
shasum -a 256 review-manifest.sha256
wc -l review-manifest.sha256
tail -1 signed-ledger.tsv
