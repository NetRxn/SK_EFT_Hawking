set -e
for stage in 2 3 4 5 6; do
    python3 -B ../next.py "$stage"
    python3 -B "pass$stage.py" > "pass$stage.out"
    tail -3 "pass$stage.out"
    n=$(awk '/preserved checkpoint pass[0-9]+-result.pkl/ {print $5}' "pass$stage.out")
    if [ "$n" -le 3 ]; then
        break
    fi
done
