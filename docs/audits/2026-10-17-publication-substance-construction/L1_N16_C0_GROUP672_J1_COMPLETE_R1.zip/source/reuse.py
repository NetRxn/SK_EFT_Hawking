from unsharded import *
import json

AXIS = ('G',0,4,1)
INPUTS = (
    (ROOT,PIN),
    (Path(str(ROOT).replace('/resume1/','/resume2/')), 'fa9044eab9475a86241c74fdc6d34ed3ef8c5c7d5b8950d80e62e46ae91a3145'),
)

def by_axis(factor):
    axes,rows,_ = factor
    i = axes.index(AXIS)
    fibers=defaultdict(dict)
    for k,v in rows.items():
        fibers[k[i]][k[:i]+k[i+1:]]=v
    return fibers

def primitive(items):
    k=tuple(sorted(items))
    v,u=prim([items[r] for r in k])
    assert all(mul(x,u)==items[r] for r,x in zip(k,v,strict=True))
    return tuple(zip(k,v,strict=True)),u

def group(factors):
    columns,rows=(by_axis(f) for f in factors)
    assert columns.keys()==rows.keys()
    result=defaultdict(list)
    for label in columns:
        left,scale1 = primitive(columns[label])
        right,scale2 = primitive(rows[label])
        result[left,right,mul(scale1,scale2)].append((label,scale1,scale2))
    return result

def main():
    for path,expected in INPUTS:
        assert sha(path)==expected
    first,second=[read(p)['factors'] for p,_ in INPUTS]
    incidences=[n for n,f in enumerate(first) if AXIS in f[0]]
    assert incidences==[9,14]
    assert len(first)==len(second)==16
    assert all(a==b for n,(a,b) in enumerate(zip(first,second,strict=True)) if n not in incidences)
    assert all(first[n][0]==second[n][0] and first[n][2]==second[n][2] for n in incidences)
    x,y=[group([a[n] for n in incidences]) for a in (first,second)]
    print('exact primitive support-and-signed-product classes',len(x),len(y),flush=True)
    if x.keys()!=y.keys():
        print('unmatched classes',len(x.keys()-y.keys()),len(y.keys()-x.keys()),flush=True)
        return
    assert all(len(x[k])==len(y[k]) for k in x)
    roster=[]
    for k in x:
        for a,b in zip(sorted(x[k]),sorted(y[k]),strict=True):
            roster.append((a,b))
    assert len(roster)==26
    print('exact common-axis bijection, Gaussian scales',json.dumps(sorted(roster)),flush=True)
if __name__=='__main__':
    main()
