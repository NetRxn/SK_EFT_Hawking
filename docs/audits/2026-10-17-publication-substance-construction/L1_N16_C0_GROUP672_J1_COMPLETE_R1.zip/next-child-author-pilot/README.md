# Next J=(2,) child, author restart

This author-only experiment starts at the pinned original 18-factor run cap
in the existing Group 672 original-label route. It keeps the entire
J=(2,) child together. The three passes preserve a signed six-factor
restart at the final checksum in operands.sha256. No scalar is recorded.
The inputs and results of this pilot are outside the reviewed J=(1,)
result, its support census and its retally. Independent review is owed.

Rebuild the pinned original input as directed by the original-label
route archive, then run unsharded.py, pass2.py and pass3.py in an empty
working directory containing these helper sources. Each pass expects the
prior pass's exact operand checksum and writes a new restart.
