# Exact group 672, joint-L assignment 7, J=(1,) contribution

This archive covers exactly one original J child of joint-L assignment 7.
The original disjoint G-axis partition is pinned through the original
partition review and its three source-bound roster receipts. All 16
allowed G-axis values contribute exactly once. The G0 receipt represents
the whole first block and already includes the earlier interval result.

From the extracted archive root, verify the member checksums and retally.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B retally.py | cmp - RETALLY.txt
```

The archive contains the signed arithmetic source, author receipts and the
two independent signed replays. The original G-block, original label route
and G0 complete archives in this audit directory are the upstream evidence.
Large operands are pinned by SHA-256 and can be rebuilt from the upstream
inputs and stage scripts. The simple direct relabeling test on G1 and G2
misses all 26 joint primitive fiber classes. Both signed scalars were
computed on their own source caps. Their equality is an outcome of those
calculations.

The original physical occupation prefactor 1/(16*4^64), with phase +1, is
applied once to the raw subtotal divided by the common factor denominator.
The scope ends at the exact coefficient contribution of this J child.
