from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

def only(pattern, text):
    match = re.findall(pattern, text)
    assert len(match) == 1, (pattern, match)
    return match[0]

def source_partition():
    covered = set()
    blocks = []
    initial_roster = None
    for index in range(3):
        body = Path(f'source/block{index}.out').read_text()
        roster_line, block_line = body.splitlines()
        roster = dict(literal_eval(roster_line.removeprefix('reconstructed roster ')))
        if initial_roster is None:
            initial_roster = roster
        assert roster == initial_roster
        number, block, products, rows = only(r'forced exact join (\d) (\(.*\)) (\d+) output rows (\d+) factors 17', block_line)
        values = set(literal_eval(block))
        assert str(index) == number and not covered & values
        assert int(products) == int(rows) == sum(roster[v] for v in values)
        covered.update(values)
        blocks.append(values)
    assert set(roster) == covered and len(covered) == 16
    assert sum(roster.values()) == 1_191_936
    return blocks

if __name__ == '__main__':
    blocks = source_partition()
    val = []
    first = Path('G0/triangle.out').read_text()
    pairs = re.findall(r'triangle signed numerator [012] [012] [012] (\d+) (-?\d+) denominator (\d+)', first)
    assert len(pairs) == 2 and pairs[0] == pairs[1]
    a, b, d = (int(x) for x in pairs[0])
    assert b == 0
    val.append(a)
    for f in ('G1/pass3.out','G2/pass4.out'):
        text = Path(f).read_text()
        body = only(r'exact raw scalar (\(.*\))', text)
        a,b = literal_eval(body)
        assert b == 0
        end = [line for line in text.splitlines() if line.startswith('exact follow join ')][-1]
        item = literal_eval(end.removeprefix('exact follow join ').split(' remaining ')[0])
        assert item[5:8] == (1, 0, d)
        val.append(a)
    proof = Path('source/original-partition-review.md').read_text()
    assert str(d) in proof and '1/(16*4^64)' in proof
    total = sum(val)
    for j,(labels,number) in enumerate(zip(blocks,val,strict=True)):
        print(f'G{j}', tuple(sorted(labels)), number)
    print('joint-L 7 J=(1,) exact raw numerator', total, 'imaginary', 0, 'factor denominator', d)
    print('factor-scope scalar', Fraction(total,d))
    print('normalized contribution', Fraction(total,d*16*4**64))
