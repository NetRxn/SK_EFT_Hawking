"""Read independent stage receipts and tally the eight original joint-L terms."""
from ast import literal_eval
from fractions import Fraction
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile
import csv
import json
import re
import sys

CHECKPOINT='c7fb091365d42c497c777c40e18c91027dc41c4f'
D=395180970918602703540468584546304
PHYSICAL=16*4**64
RUN_LABELS={0,1,2,3,4,6}


def cover(repo):
    path='docs/audits/2026-10-17-publication-substance-construction/L1_N16_C0_DENSE_GEOMETRY_COVER_R1.zip'
    raw=check_output(['git','-C',str(repo),'show',f'{CHECKPOINT}:{path}'])
    assert sha256(raw).hexdigest()=='bf3bfef6484236edc5eca2961d705f9ee27cc17b857c9c69df89114e4d99b1b4'
    with ZipFile(BytesIO(raw)) as z, ZipFile(BytesIO(z.read('ACTUAL_REVIEW.zip'))) as a, ZipFile(BytesIO(a.read('candidate.zip'))) as w:
        entries=[line.split('\t') for line in w.read('components.tsv').decode().splitlines()[1:]]
        match=[row for row in entries if 1284 in literal_eval(row[2])]
        assert len(match)==1 and match[0][:2]==['98','K8,8'] and int(match[0][-1])==192
        pairing=dict(tuple(map(int,line.split())) for line in w.read('gamma-pairs.tsv').decode().splitlines()[1:])
        assert pairing[1284]==2447
        assert 48*2*2==int(match[0][-1])
    return int(match[0][-1])


def write_table(path, rows):
    with Path(path).open('w',newline='') as out:
        writer=csv.writer(out,delimiter='\t',lineterminator='\n')
        writer.writerows(rows)


def extract(regex, text):
    return re.search(regex,text,re.M).groups()


def main(repo):
    weight=cover(repo)
    prepared=json.loads(Path('accepted-result.json').read_text())
    assert prepared['denominator']==D and set(prepared['remaining_ordinals'])==RUN_LABELS
    assert prepared['proved_zero_ordinals']==[5,7]
    roster=list(csv.DictReader(Path('ordinal-roster.tsv').open(),delimiter='\t'))
    assert {int(row['original_ordinal']) for row in roster}==set(range(8))
    scalars=[('ordinal','original_joint_L','disposition','terminal_sha256','raw_real','raw_imag','factor_denominator')]
    cap=[('ordinal','native_cap_sha256','factors','rows','wires','used_before','rejected_pair','projected_matches',
          'independent_crossing_visits','crossing_rows')]
    work=[('ordinal','pass','splits','joins','folds','retained_factors','finished_products','refused_visit_products')]
    timing=[('ordinal','author_whole_solve_s','author_native_s','author_passes_s','author_extra_terminal_wall_s',
             'independent_native_s','independent_passes_s','independent_extra_s')]
    rr=ii=0
    prep=float(extract(r'^real ([\d.]+)',Path('author-preparation.time').read_text())[0])
    guard=continuation=terminal=0.
    for row in roster:
        n=int(row['original_ordinal'])
        assert n==len(scalars)-1
        coord=literal_eval(row['original_joint_L_tuple'])
        if n not in RUN_LABELS:
            assert row['disposition']=='exact_zero' and len(literal_eval(row['empty_prepared_factors']))==13
            scalars.append((n,coord,'prepared empty restrictions',prepared['prepared_sha256'],0,0,D))
            continue
        d=Path('author')/f'L{n}'
        pins=json.loads((d/'pins.json').read_text())
        a=(d/'native-replay.out').read_text()
        cap.append((n,*extract(r'^independent exact native cap tables (\w+) (\d+) (\d+) (\d+) (\d+) (\(\d+, \d+\)) (\d+) (\d+) (\d+)',a)))
        native_review=float(extract(r'^native source and cap independent seconds ([\d.]+)',a)[0])
        alt=d/'replay-guarded.out'
        q=(alt if alt.exists() else d/'replay.out').read_text()
        authored=[(d/f'pass{i}.out').read_text() for i in range(1,pins['passes']+1)]
        receipts=re.findall(r'^stage counts (\d+) (\d+) (\d+) (\d+) (\d+) (\d+) (\d+)',q,re.M)
        assert len(receipts)==pins['passes']
        work.extend((n,*line) for line in receipts)
        refusal_total=sum(len(re.findall(r'^(?:bounded refusal|follow refused) ',x,re.M)) for x in authored)
        assert refusal_total==len(re.findall(r'^(?:independently crossed continuation row cap|bound wall refusal) ',q,re.M))
        assert not re.search(r'^bound wall refusal ',q,re.M)
        pass_review=sum(float(t) for t in re.findall(r'^independent stage wall seconds \d+ ([\d.]+)',q,re.M))
        w=float(extract(r'^real ([\d.]+)',(d/'solve.time').read_text())[0])
        g=float(extract(r'^elapsed seconds ([\d.]+)',(d/'contraction.receipt').read_text())[0])
        p=sum(float(extract(r'^(?:total process|follow) seconds ([\d.]+)',x)[0]) for x in authored)
        ex=tex=0.
        if pins['mode']=='triangle':
            extra=(d/'triangle-replay.out').read_text()
            xr,xi,den,tex=extract(rf'^whole original L{n} triangle raw (-?\d+) (-?\d+) (\d+) elapsed ([\d.]+)',extra)
            digest=extract(rf'^whole original L{n} exact terminal triangle ready (\w+) ',q)[0]
            audit=(d/'triangle-interval-audit.out').read_text()
            assert f'both author signed sums agree with independent third anchor {xr} {xi} {den}' in audit
            ex=float(extract(r'^real ([\d.]+)',(d/'terminal.time').read_text())[0])
        else:
            xr,xi,den=extract(rf'^whole original L{n} raw \((-?\d+), (-?\d+)\) (\d+) elapsed ',q)
            digests=re.findall(r'^exact all retained coefficient tables \d+ (\w+) ',q,re.M)
            digest=digests[-1]
            assert (int(xr),int(xi))==(pins['expected_raw'],pins['expected_imag'])
        xr,xi,den=map(int,(xr,xi,den))
        assert digest==pins['terminal_sha'] and den==D
        rr+=xr
        ii+=xi
        scalars.append((n,coord,pins['mode'],digest,xr,xi,den))
        timing.append((n,w,g,p,ex,native_review,pass_review,tex))
        guard+=g
        continuation+=p
        terminal+=ex
    assert ii==0
    for path,table in (('scalar.tsv',scalars),('native-caps.tsv',cap),('signed-work.tsv',work),('timing.tsv',timing)):
        write_table(path,table)
    print('Group',1284,'component',98,'original gamma3 partner',2447,'weight',weight)
    print('raw Gaussian sum',rr,ii,'factor denominator',D)
    print('raw reduced',Fraction(rr,D),Fraction(ii,D))
    print('physical divisor',PHYSICAL)
    print('physical unweighted',Fraction(rr,D*PHYSICAL),Fraction(ii,D*PHYSICAL))
    print('physical weighted',Fraction(weight*rr,D*PHYSICAL),Fraction(weight*ii,D*PHYSICAL))
    print('author measured seconds',*[round(x,6) for x in (prep,guard,continuation,terminal,prep+guard+continuation+terminal)])


if __name__=='__main__':
    main(Path(sys.argv[1]))
