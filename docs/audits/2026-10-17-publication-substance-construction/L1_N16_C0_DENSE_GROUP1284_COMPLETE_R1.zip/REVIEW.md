# Independent complete signed Group 1284 review

Verified the original eight joint-L ordinals of Group 1284. Ordinals 0, 1, 2,
3, 4 and 6 have independently replayed signed terminals. Ordinals 5 and 7
each have 13 empty prepared restrictions and give exact zero. The archived
scalar ledger retains every original tuple, exact Gaussian numerator and
inherited factor denominator.

The work-start continuity packet was fresh at
c7fb091365d42c497c777c40e18c91027dc41c4f. The read-only checkpoint
reconciliation to 3c5f16678354c87358e58afc14f6e201b397a46f verified
byte equality of all three assigned archives. The intervening commit
adds the completed Group 1261 archive and updates two disposition records.
Group 1284 is in the accepted selected side of component 98 and its
original gamma3 partner is Group 2447. Its coefficient 192 is the original
occupation weight 48 times the chirality and component-side factors.

## Signed contraction and refusal audit

The accepted component-98 preparation pins Group 1284's 88-factor parent at
SHA-256 e8d01b9b94abe52fe710612f794cc2f8f7ad186aface3a4bbb4d5a583c69aa9a.
The committed preparation roster binds all eight original coordinates and
the two zeros. Each native replay independently enumerated the label support,
lifted every selected signed row back to the prepared parent, reproduced the
guarded tables, and crossed the 500,000-row threshold on the pinned pair.
The six native refusals forecast 722,176 to 1,496,576 products. Saved caps
contain 13 to 27 factors and 386,672 to 774,776 rows.

Each continuation replay checked complete inverse signed splits,
degree-two physical incidence, exact quotient folds, necessary peer
projectors, and all signed retained tables. Every continuation row refusal
was independently exercised and preserved the prejoin state. For L4 an
alternate traversal of one refused pair completed below the cap. Transient
row count depends on the signed accumulation order. An independent replay
in author traversal order reached 500,001 rows after exactly 5,209,791
products for that pair, and after 743,126 for its other refusal. The L4
terminal and all retained tables matched under the audited order. The
remaining retained continuations use reverse Gaussian accumulation.
Prejoin rows, work records and measured timings are separate tables.

L0's terminal is a triangle. An independent third-pivot evaluation used
five disjoint intervals of at most 4,000,000 compatible products each.
Its exact 19,509,248-product result agrees with both author pivot sums.
The two author interval covers were each independently checked. Other
live ordinals close as single empty-axis factors.

## Exact weighted physical term

- Raw Gaussian sum (14073094687189883153400617560594148804422591009900652585287680, 0).
- Inherited factor denominator 395180970918602703540468584546304.
- Exact group scalar before the physical divisor 71223544263666405774708842715/2.
- Physical divisor applied once 16 × 4^64.
- Weighted physical Group 1284 contribution **213670632790999217324126528145/170141183460469231731687303715884105728 + 0i**.

Author measured components total 263.861660 seconds, including 26.52
shared preparation, 59.055534 native guarding, 154.916126 continuation,
and 23.37 separate dual-pivot L0 terminal. The six per-ordinal author
solve walls range from 27.51 to 47.67 seconds. This measures the Group
1284 workload and its stages.

## Reproduction

Check the relative manifest and the per-ordinal operand manifests. The
large retained pickles are original external replay operands identified
by checksum. The supplied scripts default to the original author's
cached-original-roster directory. Set L1_GROUP1284_AUTHOR_ROOT to an
equivalently laid out operand tree if needed. The timing receipt for
shared preparation is included. Run these commands from the archive
directory to replay the complete scope.

    bash replay-label.sh 0 2 triangle
    bash replay-label.sh 1 3 scalar
    bash replay-label.sh 2 3 scalar
    bash replay-label.sh 3 2 scalar
    bash replay-label.sh 4 2 scalar
    bash replay-label.sh 6 2 scalar
    python3 -B retally.py /path/to/publication-checkpoint

The scripts write evidence files under the local replay directory.
