import json,re,subprocess
from pathlib import Path
p=Path('papers/D1/claims_review.json')
original=subprocess.check_output(['git','show','HEAD:papers/D1/claims_review.json'],text=True)
candidate=json.loads(p.read_text())
old=json.loads(original)
decoder=json.JSONDecoder()
def field(name):
    m=re.search(r'^  "'+re.escape(name)+r'": ',original,re.M)
    assert m
    start=m.end()
    _,size=decoder.raw_decode(original[start:])
    return start,start+size
def pretty(obj,indent):
    return json.dumps(obj,ensure_ascii=False,indent=2).replace('\n','\n'+' '*indent)
edits=[]
for name in ('review_round','review_date','reviewer_model','reviewer_run_id','verdict','summary'):
    start,end=field(name)
    replacement=pretty(candidate[name],2)
    if name=='reviewer_run_id':
        replacement+=',\n  "review_scope": '+pretty(candidate['review_scope'],2)
    edits.append((start,end,replacement))
start,end=field('sentences')
j=start+1
for expected in old['sentences']:
    while original[j].isspace() or original[j]==',':j+=1
    row,length=decoder.raw_decode(original[j:])
    assert row==expected
    replacements=[r for r in candidate['sentences'] if r.get('rewrite_of')==row['id'] and r['agent_run_id']==candidate['reviewer_run_id']]
    if replacements:
        edits.append((j,j+length,',\n    '.join(pretty(r,4) for r in replacements)))
    j+=length
for a,b,replacement in sorted(edits,reverse=True):
    original=original[:a]+replacement+original[b:]
assert json.loads(original)==candidate
p.write_text(original)
