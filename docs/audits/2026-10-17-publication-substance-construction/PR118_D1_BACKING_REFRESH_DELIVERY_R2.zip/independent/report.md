# PR118 D1 backing refresh R2 independent review

**ACCEPT for the scoped source, backing ratchet and audit append.** Exact base 9f8608351d9c5c94ed9d18df24ea2649087e8fd5 and patch SHA-256 3ce03ff4b024be77ab0c8a30a72b0446f42ad57f79161689be74c0493243fac3. Continuity packet publication-pr118-d1-backing-refresh-independent-r2 matched. The input manifest verified. I applied the patch in a separate exact-base clone with the delivery environment's Python 3.14.8 and reproduced the full-index diff byte for byte. The patch touches only D1's claims record and audit log plus the ceiling constant.

- Both prior provenance findings are resolved. All seven rows use their nearest actual TeX heading, and canonical normalized quotes and raw ID parts reproduce their IDs. The two graphene rows use the acoustic-metric subsection and the two polariton rows use the attenuation subsection. The seven quote bodies, line ranges, backing, scope notes and verdicts match R1. The current summary records six scoped PASS results, one census WARN and eleven historical carries. The top-level verdict is yellow and both paper stages remain open. May's green verdict is recoverable from the exact historical blob 7d9c6d0a6ab35691777b2694c7010861108f3d83.
- Three archived rows retain 3/2/2 rewrite lineage. Eleven carried rows preserve decoded values and order. The historical archive, finding fields, dispositions, ledgers and manuscript preserve their exact input state. The prior audit line remains byte-identical.
- The scoped ingest contains exactly the seven refreshed rows, and its run ID and review time match the active claims artifact. Schema validation and dry run pass. I reran the canonical ingest with the candidate's timestamp injected and with its write paths rooted in a second isolated scratch directory. The resulting audit log matched byte for byte. The only appended event is re_audit, carrying zero prior and seven reviewed sentences, zero tombstones, zero auto-closures and zero candidates. The generated runtime state contains zero human sentences and an empty tombstoned-quotes map. Runtime lock and state files are outside the patch. Replay on the exact candidate reports two audit lines, zero sentences and no drift.
- All eleven links resolve to exact canonical graph node IDs. The nine Lean-linked catalog entries, including the carrier and definitions, have zero project axiom dependencies. R1's source-scope analysis remains applicable because each quote, backing target and condition is unchanged. Independent census and polariton recomputation reproduce 107 of 120, 13 platform-specific, the normalized crossing 0.1748495762830299 and ideal SNR five at 100 photons.
- The exact corpus has 2,312 Lean links and 106 unresolved, against 2,313 and 111 at base. The five removed unresolved entries are all in D1. The canonical no-memo validation measures 106 against ceiling 106. All six tests passed, including the seeded regression, zero headroom, empty corpus and unavailable graph. git diff --check passed.

Acceptance is limited to these exact three files, source and catalog readback, canonical audit mechanics, and the backing regression gate. Fresh kernel checking, full-tree qualification, Stage 10, Stage 13 and publication acceptance are outside this scope.

## Candidate postimage SHA-256

- papers/D1/claims_review.json 949ed5c090d4a18961b70bcd7eb077d6c9f6206e905ffd86820b349e5eae8d06
- papers/D1/audit_log.jsonl a3222613da3c58fb9f131cda12d07983138389592cf109b46f14b9093eb61092
- scripts/validation/checks/reviews.py 277af8ef677babbefd553691de2d0d0f48e61241eae59ad3e2809c6a0d7e23a5

## Commands

```text
python3 scripts/codex_continuity.py check <primary R2 packet>
shasum -a 256 -c manifest.sha256  [in candidate directory]
git apply --check <candidate.patch>
git apply <candidate.patch>
git diff --check
git diff --binary --full-index  [compared byte for byte to the candidate patch]
python scripts/sentence_state.py validate papers/D1/claims_review.json
python scripts/sentence_state.py validate <R2 scoped-run.json>
python scripts/sentence_state.py ingest_agent_run <R2 scoped-run.json> --dry-run
python scripts/sentence_state.py rebuild_prose_state --paper D1 --check
python scripts/validate.py --check chain_backing_targets_resolve --no-memo --no-archive --json
python -m pytest -vv -o cache_dir=<scratch> tests/test_d5_reviews.py::TestChainBackingTargetsResolve
PYTHONPATH=scripts:src:. python <scratch>/verify.py <R1 claims> <R2 scoped-run.json> <scratch>
```
