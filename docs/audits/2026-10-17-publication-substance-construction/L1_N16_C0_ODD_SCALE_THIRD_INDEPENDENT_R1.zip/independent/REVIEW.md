# Independent third odd-root scale-up review

**ACCEPT** original representative `(140684411270,558347329670)` at
weight 96. The exact signed source-normalized value is
`738592700474945089327640625/316912650057057350374175801344`.
Its weighted contribution is
`2215778101424835267982921875/9903520314283042199192993792`.
Removing this one independently reviewed residual row leaves
**9,640 unresolved orbits and 830,535 labels**. Full original c0
remains open.

The continuity snapshot checked fresh at both boundaries. The clean
pinned checkpoint `d56c49a802302e26250c88d48955af19afabc70c` matched
its tracked upstream. Its archived report manifest matches the
frozen input. I verified all 77 author archive entries, 820 local
factor hashes, 60 residual intake files and 34 preceding review
files. The exact residual extracted from the approved second-scale
archive matches the supplied intake copy byte-for-byte. The new
representative appears exactly once at its original weight and the
three earlier accepted odd-root representatives are absent.

## Original support and signs

An independent exhaustive pass through all 4,194,304 projected local
tuples checks the original temporal chirality singlets, degree bounds,
zero-load equalities and combined spatial center parity. Exactly
96 states survive. The 48 frozen representative states and their
single simultaneous chirality swaps cover those 96 exactly. All
2,304 anchor-plan rows match. The original gamma3 involution retains
each lattice anchor, preserves the product Haar law and the filled
eight-generator tops, and changes the sign of each elementary EHC
insertion. There are 32 insertions. Their product has positive
exchange sign, so every represented value must be counted twice.

The original multiplicities are 27 zeros, 13 ones, five twos and
three threes. This gives `(2!)⁵(3!)³=6912`; the two coframes per
original insertion require 4⁻⁶⁴ for the previously quarter-stripped
production inputs. I checked all 512 stripped coframes against the
canonical original block formula and all 768 canonical ordered EHC
coefficients against the folded time-first curvature order. The
separate EHC prefactor 1/4 cancels against the four equivalent
ordered contributions. No earlier scalar-root projection erases
the original multiplicity or its factorial. The original spatial
axis sums are (4,4,8) and (0,4,12). Both world epsilon products
and both cross-site wedge parities are positive. Independent
literal checks cover 64 generator layouts per layer. Within-site
mask inversion signs remain in the signed factor tables.

## Independent factor verification and its scope

- The literal source independently reconstructs all 1,718 nonzero
  root Fourier entries from 4,920 full entries, including all
  linear, quadratic and cubic projections present in the export.
- Exact coordinate Haar reconstruction matches 133 nonzero temporal
  rows from 1,041 candidates across 11 shapes and 1,238 nonzero
  spatial anchor rows from 22,806 candidates across 28 shapes.
- All 52 raw spatial edge shapes are wired to the original mask,
  word and matrix locations. Where earlier edge links are reused,
  I checked that the originating factor has the same exact pattern
  key. I reconstructed 59 signed targets directly from the
  original coframes and anchor moments, across all 52 edge patterns,
  keeping complex entries. Peak prospective target work is
  1,048,576 candidates. I did not regenerate every raw edge row.
- I independently rebuilt all 16 original signed site factors
  for each of cases 0, 6, 7, 26 and 47, including the negative case
  47 and the largest raw site factor in case 7. This represents
  80 site factors and 1,837,864 signed rows. Root coefficients are
  combined by their original complementary coframe words before
  checking the exact edge mask supports and doing the full wedge
  inversion. Checks reach 9,792 prospective root products,
  145,920 site complement trials and 379,136 retained rows.
  The remainder of the large raw site corpus is reused by hash
  and participates in the independent signed numerical replay.

The complete replay assembles each of the 48 original 72-factor
networks independently, with the original closed-plaquette wire
incidence and two occurrences of every nontrivial wire. Initial
row cardinalities and wire counts match the frozen logs. This is
the unsplit network of original signed factors. The independent
tuple-key quotient groups identical full primitive signed Gaussian
slices on the complete shared wire tuple and applies their exact
gains on the peer. The identity preserves every open boundary and
both factor denominators. The local implementation also passes 129
exact open-boundary replays, including signed cancellation and
unmatched two-index bonds.

## Signed results and resources

All 48 normalized values match `pair-exact.tsv`, including the
six cases available in both author schedule
logs and the 28 exact-zero cases. There are 19 positive values,
one negative, and 28 zeros. The negative case 47 is exactly
`-6891222485763146953125/316912650057057350374175801344`.
No term was replaced by an absolute value. Doubling the signed sum
accounts for all 96 supported channel states. All complete nonzero
values are real.

The independent network has at most 765,088 initial rows across
all factors. The largest admitted numerical join is 38,656 products
and the largest complete numerical path uses 101,973 products.
Its largest joined output has 16,896 rows. The most expensive
nonzero path charges 31,491,211 quotient and histogram row visits.
The reviewer checks work and Gaussian-integer coefficient height
before each arithmetic operation, keeps the sparse insertion cap,
and stops exact-zero channels at their verified empty factors. These
counts exclude original raw-edge generation. They do not give a
general batch throughput guarantee.

This accepts only the original representative given above. No
repository, manuscript or Lean state changed.

## Replay

Scratch uses the frozen general author input at `AUTHOR`, the verified
original factor directory at `TABLES`, the preceding independent
projection at `INDEPENDENT`, and the canonical quarter-stripped
coframes at `prior-coframes.tsv`. The approved second-scale archive's
`block-remaining.tsv` is copied as `residual.tsv`. Use clean science
candidate `51e7c745e` for the literal source controls.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 support.py > support.out
PYTHONDONTWRITEBYTECODE=1 python3 moments.py > moments.out
PYTHONDONTWRITEBYTECODE=1 python3 site-rebuild.py 0 6 7 26 47 > site-rebuild.out
PYTHONDONTWRITEBYTECODE=1 python3 edge-control.py > edge-control.out
PYTHONDONTWRITEBYTECODE=1 python3 quotient-control.py > quotient-control.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" normalization.py > normalization.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" root-rebuild.py > root-rebuild.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py $(seq 0 11) > cases-0.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py $(seq 12 23) > cases-12.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py $(seq 24 35) > cases-24.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py $(seq 36 47) > cases-36.out
python3 verify.py > verification.out
shasum -a 256 -c manifest.sha256
```
