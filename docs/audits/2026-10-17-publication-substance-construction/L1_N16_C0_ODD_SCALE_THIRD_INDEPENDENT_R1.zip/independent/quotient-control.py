from random import Random
from itertools import product
from replay import Table,Budget,reduce,join,forecast,pairs,z_times,z_add

rng=Random(218)
def test(A,B):
    L,R=pairs(A,B)
    orig=join(A,B,L,R,forecast(A,B,L,R))
    budget=Budget(10000)
    reduced=reduce(A,B,L,R,budget)
    if reduced is None: return
    C,D,_,_=reduced
    if not C.rows or not D.rows:
        assert not orig.rows
        return
    assert C.scale==A.scale and D.scale==B.scale
    new=join(C,D,L,R,forecast(C,D,L,R))
    assert orig.keys==new.keys and orig.scale==new.scale and orig.rows==new.rows

units=((1,0),(0,1),(-1,0),(0,-1))
for __ in range(128):
    # Two-coordinate bond interleaved with unrelated open columns.
    Ar={}
    Br={}
    for u in range(3):
        for v in range(3):
            if u==v==2:continue
            pattern=(((0,), (1,1)),((1,),(1,0))) if (u+v)&1 else (((1,),(2,-1)),((2,),(1,0)))
            mult=tuple(rng.randint(1,8)*n for n in rng.choice(units))
            for (i,),co in pattern:
                Ar[u,i,v]=z_times(mult,co)
            if (u,v)!=(0,1):
                for j in range(3):
                    if rng.randrange(4):
                        z=(rng.randrange(-4,5),rng.randrange(-4,5))
                        if any(z):Br[v,j,u]=z
    Br[2,0,2]=(2,5)
    test(Table(('A',),('x','a','y'),Ar,3),Table(('B',),('y','b','x'),Br,5))
A=Table(('A',),('x','a'),{(0,0):(3,6),(0,1):(0,9),(1,0):(12,-6),(1,1):(18,0)},7)
# The second primitive is -2i times the first. The partner values force cancellation.
B=Table(('B',),('x','b'),{(0,0):(0,2),(1,0):(1,0)},11)
test(A,B)
L,R=pairs(A,B)
assert not join(A,B,L,R,forecast(A,B,L,R)).rows
print('129 exact open-boundary controls, including signed cancellation and unmatched two-index bonds')
