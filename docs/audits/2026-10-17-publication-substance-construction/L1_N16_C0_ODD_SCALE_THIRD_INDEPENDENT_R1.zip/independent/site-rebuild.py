import os,sys
from ast import literal_eval
from collections import defaultdict
from functools import lru_cache
from itertools import product
from fractions import Fraction as F
from math import prod
from pathlib import Path

sys.path.insert(0,str(Path('INDEPENDENT').absolute()))
from census import occupancy
parse=lru_cache(maxsize=100_000)(literal_eval)
def plans(root):
    res=[]
    for row in (root/'edge-plan.out').read_text().splitlines():
        if row.startswith('pattern '):
            res.append(parse(row[8:row.rindex(')')+1]))
    assert len(res)==len(set(res))
    return res
table=Path('TABLES')
pattern=plans(table)
assert len(pattern)==52
supports={}
renamed_root={}
for j,pat in enumerate(pattern):
    source=table/'edge-batch'/f'{j:02}.tsv'
    if source.is_symlink():
        link=Path(os.readlink(source))
        origin=link.parent.parent
        if origin not in renamed_root:renamed_root[origin]=plans(origin)
        assert renamed_root[origin][int(link.stem)]==pat
    ab=(defaultdict(set),defaultdict(set))
    for l in source.open():
        p,q,mask,*_=l.split('\t')
        m=int(mask)
        ab[0][parse(p)].add(m&255)
        ab[1][parse(q)].add(m>>8)
    supports[pat]=ab
print('all 52 original edge patterns wired; checked reused source pattern IDs')
R=defaultdict(list)
for row in (table/'root.tsv').open():
    n,w,z,l,r,i,j,re,im=row.split('\t')
    R[int(n),int(l),int(r)].append((parse(w),parse(z),(int(i),int(j)),(F(re),F(im))))
states=defaultdict(dict)
for l in (table/'states.tsv').open():
    c,t,x,k,p,q=map(int,l.split())
    states[c][t,x,k]=p,q
plans_by_case=defaultdict(dict)
for l in (table/'anchor-plan.tsv').open():
    c,t,x,k,*fields=map(int,l.split())
    plans_by_case[c][t,x,k]=tuple(fields)

def mul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def add(a,b):
    return a[0]+b[0],a[1]+b[1]
def inversions(bits):
    return sum(x>y for i,x in enumerate(bits) for y in bits[i+1:])
def coordinates(site,m):
    items=[(k,n) for k,n in enumerate(m[site]) if n]
    return items
codes=(140684411270,558347329670)
total=0
for c,side,site in product(map(int,sys.argv[1:]),range(2),range(8)):
    plants=plans_by_case[c]
    occ=occupancy(codes[side])
    roots=coordinates(site,occ)
    basis=[R[n,*states[c].get((side,site,k),(0,0))] for k,n in roots]
    root_work=prod(map(len,basis))
    assert root_work<=2_000_000
    gathered=defaultdict(dict)
    for selection in product(*basis):
        words=[[],[],[]]
        ij=[]
        coefficient=(1,0)
        for (k,_),(p,q,m,z) in zip(roots,selection):
            a,b=[x for x in range(3) if x!=k]
            words[a].extend(p)
            words[b].extend(q)
            ij.extend(m)
            coefficient=mul(coefficient,z)
        w=tuple(tuple(sorted(v)) for v in words)
        ij=tuple(ij)
        gathered[w][ij]=add(gathered[w].get(ij,(0,0)),coefficient)
    candidates=[]
    for k in range(3):
        u,v=sorted((site,site^(1<<k)))
        a=sum(occ[u])-occ[u][k]
        b=sum(occ[v])-occ[v][k]
        p=(a,b,plants[side,u,k],plants[side,v,k])
        candidates.append(supports[p][int(v==site)])
    work=0
    final={}
    order=sorted(range(3),key=lambda k:(site&~(1<<k),k))
    for words,T in gathered.items():
        pool=[tab.get(w,()) for tab,w in zip(candidates,words)]
        if not all(pool):continue
        a,b,k=sorted(range(3),key=lambda i:len(pool[i]))
        work+=len(pool[a])*len(pool[b])
        assert work<=2_000_000
        for m,n in product(pool[a],pool[b]):
            if m&n:continue
            complement=255^(m|n)
            if complement not in pool[k]:continue
            masks=[0]*3
            masks[a],masks[b],masks[k]=m,n,complement
            bits=[v for q in order for v in range(8) if masks[q]>>v&1]
            assert sorted(bits)==list(range(8))
            phase=(-1)**inversions(bits)
            for ij,z in T.items():
                if not any(z):continue
                key=(words,tuple(masks),ij)
                assert key not in final and len(final)<450_000
                final[key]=(phase*z[0],phase*z[1])
    expected={}
    for l in (table/'site'/f'{c}-{side}-{site}.tsv').open():
        w,m,i,r,s=l.split('\t')
        key=parse(w),parse(m),parse(i)
        assert key not in expected
        expected[key]=(F(r),F(s))
    assert final==expected,(c,side,site,len(final),len(expected))
    total+=len(final)
    print(c,side,site,'raw root product',root_work,'site complement products',work,'exact rows',len(final),flush=True)
print('fully independent post-Haar site factor replay',total,'rows')
