# Third L1 odd-root scale-up independent acceptance

The archived independent report records coverage and limits for the third
profile. From this directory, verify the SHA-256 manifest and run
`python3 check-residual.py independent/reviewed-exact.tsv` to reproduce
the one-profile subtraction from the second accepted residual.

This is one original N16 profile at weight 96. Full c0 and physical B3
remain open.
