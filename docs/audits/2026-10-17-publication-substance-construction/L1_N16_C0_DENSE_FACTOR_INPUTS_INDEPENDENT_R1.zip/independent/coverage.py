from pathlib import Path
from collections import Counter
S={}
t=Counter()
for shard in range(0,976,244):
    totals=Counter()
    lines=(Path.cwd()/f'site-{shard}.out').read_text().splitlines()
    assert len(lines)==245
    for row in lines[:-1]:
        p=row.split()
        c,s,x=map(int,p[:3])
        assert c not in S and shard<=c<shard+244
        rp,mp,mr,cr=map(int,(p[i] for i in (5,8,11,14)))
        S[c]=s,x,rp,mp,mr,cr
        totals['mask rows']+=mr
        totals['root rows']+=cr
        for k,v in [('root products',rp),('mask trials',mp),('mask rows in block',mr),('root rows in block',cr)]:
            t[k]=max(t[k],v)
    for k,v in totals.items():t[k]+=v
    assert lines[-1]==f"exact split totals {totals['mask rows']} {totals['root rows']}"
assert set(S)==set(range(976))
assert {(s,x) for s,x,*_ in S.values()}=={(s,x) for s in range(2) for x in range(8)}
print('site factors',len(S)*2)
for k,v in sorted(t.items()):print(k,v)
