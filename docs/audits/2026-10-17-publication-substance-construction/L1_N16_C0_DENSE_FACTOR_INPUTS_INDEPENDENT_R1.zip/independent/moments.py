from ast import literal_eval as parse
from collections import defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations_with_replacement,product
from math import prod,comb
from pathlib import Path

import sys
T=Path('AUTHOR')
fund={
 (0,0):((0,1,0),(3,0,1)),
 (0,1):((2,1,0),(1,0,1)),
 (1,0):((2,-1,0),(1,0,1)),
 (1,1):((0,1,0),(3,0,-1)),
}
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def add(a,b):return a[0]+b[0],a[1]+b[1]
@cache
def sphere(keys):
    expo=tuple(keys.count(j) for j in range(4))
    if any(n&1 for n in expo):return F(0)
    return F(prod(prod(range(1,n,2)) for n in expo),prod(range(4,4+len(keys),2)))

@cache
def expansion(n,i,j,dagger):
    if n==0:
        assert (i,j)==(0,0)
        return (((),(1,0)),)
    def term(u,v):
        return tuple(((k,),((-1 if dagger and k else 1)*r,(-1 if dagger and k else 1)*s))
                     for k,r,s in fund[u,v])
    if n==1:return term(i,j)
    assert n in (2,3)
    out={}
    for a in range(n-j+1):
        b=i-a
        if not (0<=b<=j):continue
        p=comb(n-j,a)*comb(j,b)
        parts=(term(1,0),)*a+(term(0,0),)*(n-j-a)+(term(1,1),)*b+(term(0,1),)*(j-b)
        for factors in product(*parts):
            indices=tuple(sorted(k for w,z in factors for k in w))
            z=(p,0)
            for w,v in factors:z=mul(z,v)
            out[indices]=add(out.get(indices,(0,0)),z)
    return tuple((w,v) for w,v in sorted(out.items()) if any(v))

@cache
def integral(terms,word=()):
    answer=(0,0)
    for roster in product(*(expansion(n,i,j,d) for n,i,j,d in terms)):
        q=tuple(k for indices,z in roster for k in indices)
        moment=sphere(tuple(sorted(word+q)))
        if moment:
            z=(1,0)
            for _,step in roster:z=mul(z,step)
            answer=add(answer,(z[0]*moment,z[1]*moment))
    return answer

shapes={parse(l.split('\t')[-1]) for l in (T/'temporal-bindings.tsv').open()}
expected={}
checks=0
assert sum(prod((n+1)**2 for n,_ in shape) for shape in shapes)<=65536
for shape in sorted(shapes):
    domains=[range(n+1) for n,_ in shape]
    for rows,cols in product(product(*domains),repeat=2):
        terms=tuple((n,i,j,d) for (n,d),i,j in zip(shape,rows,cols))
        z=integral(terms)
        checks+=1
        if any(z):expected[shape,rows,cols]=z
actual={}
for l in (T/'temporal.tsv').open():
    shape,rows,cols,r,s=l.split('\t')
    k=(parse(shape),parse(rows),parse(cols))
    assert k not in actual
    actual[k]=(F(r),F(s))
assert actual==expected
print('independent temporal screen',len(shapes),'shapes',checks,'full entries',len(expected),'nonzero')

shapes={tuple(map(int,l.split()[4:])) for l in (T/'anchor-plan.tsv').open()}
assert sum(sum(comb(7+n,n) for n in range(h+1))*prod((j+1)**2 for j in tags) for h,*tags in shapes)<=1000000
expected={}
checks=0
for h,a,b,c,d in sorted(shapes):
    for n in range(h+1):
        for word in combinations_with_replacement(range(8),n):
            wl=tuple(i for i in word if i<4);wr=tuple(i-4 for i in word if i>=4)
            for i,j,I,J,k,l,K,L in product(*(range(n+1) for n in (a,a,b,b,c,c,d,d))):
                x=integral(((a,i,j,True),(c,k,l,False)),wl)
                y=integral(((b,I,J,True),(d,K,L,False)),wr)
                z=mul(x,y)
                checks+=1
                if any(z):
                    key=((h,a,b,c,d),word,(i,I),(j,J),(k,K),(l,L))
                    expected[key]=z
actual={}
for line in (T/'spatial.tsv').open():
    data=line.split('\t')
    key=tuple(map(parse,data[:6]))
    assert key not in actual
    actual[key]=tuple(map(F,data[6:]))
assert actual==expected
print('independent spatial moment screen',len(shapes),'shapes',checks,'full entries',len(expected),'nonzero')
