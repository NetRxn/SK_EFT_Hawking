set -eu
export PYTHONDONTWRITEBYTECODE=1
repo=/Users/johnroehm/.codex/worktrees/l1-original-n16-python/SK_EFT_Hawking
python=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python
export PYTHONPATH="$repo"
here=$PWD
for d in SITE AUTHOR DIRECT; do
    (cd "$d" && shasum -a 256 -c manifest.sha256) > "manifest-$d.out"
    unzip -p "$d-published.zip" manifest.sha256 | cmp - "$d/manifest.sha256"
done
(cd RAW && shasum -a 256 -c "$here/AUTHOR/edge-factors.sha256") > factors-edge.out
(cd RAW && shasum -a 256 -c "$here/SITE/site-factors.sha256") > factors-site.out
for f in anchor-plan.tsv edge-plan.out root.tsv spatial.tsv states.tsv temporal.tsv temporal-bindings.tsv edge-bindings.tsv temporal-labels.tsv; do
    cmp "AUTHOR/$f" "RAW/$f"
done
cmp RAW/locations.tsv SITE/locations.tsv
cmp RAW/locations.tsv AUTHOR/locations.tsv
python3 geometry-check.py > geometry-check.out
"$python" normalization.py > normalization.out
"$python" root-rebuild.py > root-rebuild.out
python3 edge-reconstruct.py 503841882182-1461451755920 > edges.out
"$python" edge-control.py 503841882182-1461451755920 > literal.out
python3 wire-check.py > wire-check.out
tail -n +3 wire-check.out | cmp - SITE/layouts.tsv
for start in 0 244 488 732; do
    python3 site-reconstruct.py 503841882182-1461451755920 "$start" "$((start+244))" > "site-$start.out"
done
python3 coverage.py > coverage.out
