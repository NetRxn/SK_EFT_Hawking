from ast import literal_eval as parse
from collections import defaultdict,Counter
from fractions import Fraction as F
from itertools import product
from math import prod
from pathlib import Path
from moments import integral,mul,add
import sys
profile=sys.argv[1]
T=Path('AUTHOR')
U=Path('RAW')


C=defaultdict(list)
for l in Path('prior-coframes.tsv').open():
    o,w,m,q,r,s=map(int,l.split())
    C[o,w].append((m,q,(r,s)))

def raw(shape,indices,wh):
    h,a,b,c,d=shape
    left=tuple(i for i in indices if i<4)
    right=tuple(i-4 for i in indices if i>=4)
    (u,U),(v,V),(x,X),(y,Y)=wh
    return mul(integral(((a,u,v,True),(c,x,y,False)),left),
               integral(((b,U,V,True),(d,X,Y,False)),right))

def literal(shape,line):
    ar,br,S,T=shape
    a,b,mask,X,Y,r,s=line.split('\t')
    words=(parse(a),parse(b))
    assert (len(words[0]),len(words[1]))==(ar,br)
    target=int(mask)
    roster=[[row for row in C[o,w] if row[0]&~target==0]
            for o in range(2) for w in words[o]]
    A=parse(X);B=parse(Y)
    count=prod(map(len,roster))
    stages=Counter({0:1})
    admitted=0
    for group in roster:
        nxt=Counter()
        for occupied,n in stages.items():
            for mask,_,_ in group:
                if not occupied&mask:nxt[occupied|mask]+=n
        admitted+=sum(nxt.values())
        assert admitted<=2_000_000
        stages=nxt
    assert set(stages)<={target}
    result=(0,0)
    seen=0
    def visit(level,occupied,indices,z):
        nonlocal result,seen
        if level==len(roster):
            assert occupied==target
            left=tuple(sorted(k for k in indices if k<8))
            right=tuple(sorted(k-8 for k in indices if k>=8))
            result=add(result,mul(z,mul(raw(S,left,A),raw(T,right,B))))
            return
        for mask,q,value in roster[level]:
            if occupied&mask:continue
            odd=sum((occupied>>(i+1)).bit_count() for i in range(16) if mask>>i&1)&1
            seen+=1
            visit(level+1,occupied|mask,indices+(q,),mul(z,tuple(-x for x in value) if odd else value))
    visit(0,0,(),(1,0))
    assert seen==admitted
    assert result==(F(r),F(s)),(shape,line,result)
    return count,admitted

total=0
peak=0
filtered_peak=0
for j,l in enumerate(x for x in (T/'edge-plan.out').read_text().splitlines() if x.startswith('pattern ')):
    shape=parse(l[8:l.rindex(')')+1])
    with (U/'raw-edges'/f'{j:02}.tsv').open() as f:
        keys=[next(f)]
        if keys[0].split()[-1]=='0':
            for line in f:
                if line.split()[-1]!='0':
                    keys.append(line);break
        for line in keys:
            q,v=literal(shape,line)
            filtered_peak=max(filtered_peak,v)
            total+=1
            peak=max(peak,q)
print('literal signed target rows',total,'from all covered edge shapes; peak direct product candidates',peak,"peak admitted prefixes",filtered_peak)
