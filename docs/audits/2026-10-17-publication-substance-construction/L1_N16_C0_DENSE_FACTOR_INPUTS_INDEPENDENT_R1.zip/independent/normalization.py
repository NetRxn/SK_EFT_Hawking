from collections import Counter,defaultdict
from fractions import Fraction as F
from itertools import product
from math import factorial,prod
from pathlib import Path
from random import Random
import sys
from src.core.formulas import (
    original_spin4_link, original_coframe_blocks, original_plaquette,original_action_factors,
)
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial as P, matrix_multiply as mm, assemble_coframe,
)
sys.path.insert(0,str(Path('INDEPENDENT').absolute()))
from census import occupancy

reg=OriginalRegulator()
coord=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),(F(1,2),)*4,(F(5,13),0,F(12,13),0))
coframe={}
base=reg.sites[0];end=reg.step(base,0)[0]
sites=(base,end)
def hit(mask):
    located=[]
    for i in range(8*reg.volume):
        if mask>>i&1:
            x=reg.sites[i//8]
            located.append(8*sites.index(x)+i%8)
    assert len(located)==2
    return sum(1<<k for k in located),(-1)**(located[0]>located[1])
for owner,a in product(range(2),range(4)):
    exterior=assemble_coframe(reg,original_coframe_blocks(reg,(sites[owner],0,a))).to_exterior(reg)
    for mask,v in exterior.terms:
        packed,phase=hit(mask)
        for (s,),z in v.terms:
            x,mu,chi,i=s.index
            assert mu==0
            q=8*sites.index(x)+4*(chi=='R')+i
            vals=(4*phase*z.real,4*phase*z.imag)
            assert all(x.denominator==1 for x in vals)
            coframe[owner,a,packed,q]=tuple(map(int,vals))
reference={}
for l in Path('prior-coframes.tsv').read_text().splitlines():
    o,a,m,q,re,im=map(int,l.split())
    assert (o,a,m,q) not in reference
    reference[o,a,m,q]=(re,im)
assert coframe==reference
print('quadratic coframe export rows checked from literal quarters',len(coframe))

def parity(order):
    return sum(x>y for i,x in enumerate(order) for y in order[i+1:])%2
def trace(M):return sum((M[i][i] for i in range(len(M))),P())
links={(x,k):original_spin4_link(coord[(k+reg.site_number(x)*3)%len(coord)],
                                coord[(2*k+reg.site_number(x))%len(coord)])
       for x in reg.sites for k in range(4)}
checks=0
for x in reg.sites:
    apparent=defaultdict(P)
    for f in original_action_factors(reg,x,links):
        if f.t_degree!=2:continue
        curvature_axes=(f.anchors[0][1],f.anchors[1][1])
        if 3 not in curvature_axes:continue
        k=curvature_axes[int(curvature_axes[0]==3)]
        apparent[k,tuple(sorted(f.components))]+=f.coefficient
    for k in range(3):
        u,v=(j for j in range(3) if j!=k)
        sign=(-1)**parity((3,k,u,v))
        H=original_plaquette(reg,x,3,k,links)
        for a,b in product(range(4),repeat=2):
            C=mm(mm(reg.gamma[a],reg.gamma[b]),reg.gamma5)
            value=sign*trace(mm(H,C)) if a!=b else P()
            assert apparent[k,((x,u,a),(x,v,b))]==value,(x,k,a,b)
            checks+=1
print('original four-order EHC phase and quarter cancellation controls',checks)

def wedgeex(mask,term):
    return sum((mask>>(i+1)).bit_count() for i in range(term.bit_length()) if term>>i&1)
rng=Random(91)
for line in Path('profiles.tsv').open():
    a,b,w=map(int,line.split())
    codes=(a,b)
    print('profile',*codes,w)
    powers=[n for code in codes for row in occupancy(code) for n in row]
    assert sum(powers)==32
    assert prod(factorial(n) for n in powers)>0
    for t,code in enumerate(codes):
        o=occupancy(code)
        eps_power=sum(n*parity((3,k,*[a for a in range(3) if a!=k]))
                      for m in o for k,n in enumerate(m))
        E=[]
        for u in range(8):
            for k in range(3):
                if u>>k&1:continue
                v=u^(1<<k);d=sum(o[u])+sum(o[v])-o[u][k]-o[v][k]
                E.append((u,v,d))
        chunks=[(x,d) for u,v,d in E for x in (u,v) if d]
        cross=sum(d*e for j,(x,d) in enumerate(chunks) for y,e in chunks[j+1:] if x>y)
        assert cross%2==eps_power%2==0
        for _ in range(64):
            pos=[rng.sample(range(8),8) for _ in range(8)]
            used=[0]*8
            local=[0]*8
            a=b=full=0
            for x,y,d in E:
                f=0
                for v in (x,y):
                    m=sum(1<<i for i in pos[v][used[v]:used[v]+d])
                    assert m.bit_count()==d
                    used[v]+=d
                    b+=wedgeex(local[v],m)
                    local[v]|=m
                    f|=m<<(8*v)
                a+=wedgeex(full,f)
                full|=f
            assert used==[8]*8 and (a-b-cross)%2==0 and full==(1<<64)-1
        print('layer',t,'axis sums',*(sum(r[k] for r in o) for k in range(3)),
              'world sign parity',eps_power%2,'cross-site parity',cross%2,'literal layouts',64)
    print('original multiplicities',sorted(Counter(powers).items()),'insertions',sum(powers),
          'factorial',prod(factorial(n) for n in powers),
          'quarter exponent',2*sum(powers))
