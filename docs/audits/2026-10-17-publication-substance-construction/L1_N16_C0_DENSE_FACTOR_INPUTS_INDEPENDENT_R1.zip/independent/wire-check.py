from ast import literal_eval
from collections import defaultdict,Counter
from fractions import Fraction
from functools import cache,lru_cache
from hashlib import sha256
from itertools import product
from math import lcm
from pathlib import Path
from support import occupancy

P=Path('RAW')
parse=lru_cache(maxsize=32768)(literal_eval)
O=[occupancy(a) for a in (503841882182,1461451755920)]

def wire(t,x,k,i,h):
    return 'R',t,x,k,i,h

def pair(t,x,k):
    return ('G',t,x,k),('W',t,x,k)

def dims(wires,spins):
    d=[]
    for w in wires:
        d.append(spins.get(w[1:4],(0,0))[w[-1]] if w[0]=='R' else -1)
    return tuple(d)

def layout(wires,sizes):
    return tuple(w for w,s in zip(wires,sizes) if s)

def geometry():
    F=defaultdict(list)
    for t,x in product(range(2),range(8)):
        X=f'M{t}{x}'
        Y=f'C{t}{x}'
        for k in range(3):
            F[X].append(('J',t,x,k))
            F[Y].append(('J',t,x,k))
            F[X].extend(pair(t,x,k))
            if O[t][x][k]:
                F[Y].extend(wire(t,x,k,i,h) for i in (4,0) for h in range(2))
                y=x^(1<<k)
                u=min(x,y)
                for o,cols in ((t,(0,1)),(1-t,(2,3))):
                    F[f'E{o}{u}{k}'].extend(wire(t,x,k,i,h) for i in cols for h in range(2))
                for v,cols in ((x,(3,4)),(y,(1,2))):
                    for h in range(2):
                        F[f'T{t}{v}{h}'].extend(wire(t,x,k,i,h) for i in cols)
    for t,u,k in product(range(2),range(8),range(3)):
        if not u>>k&1:
            F[f'E{t}{u}{k}'].extend(pair(t,u,k)+pair(t,u^(1<<k),k))
    for t,x,h in product(range(2),range(8),range(2)):
        F.setdefault(f'T{t}{x}{h}',[])
    incidence=defaultdict(list)
    for f,ws in F.items():
        assert len(ws)==len(set(ws))
        for w in ws:incidence[w].append(f)
    assert len(F)==88 and all(len(fs)==2 for fs in incidence.values())
    return F,incidence

all_factors,incidence=geometry()
print('max physical wires from original occupations',len(incidence),Counter(w[0] for w in incidence))
print('deleting each p=0 coordinate from both incidences preserves twofold joins exactly')
root_scope={}
temporal=defaultdict(list)
for l in Path('AUTHOR/temporal.tsv').open():
    S,rr,cc,r,i=l.split('\t')
    temporal[parse(S)].append((tuple(z for ij in zip(parse(rr),parse(cc)) for z in ij),Fraction(r),Fraction(i)))

def summarize(rows,ds):
    d=1
    entries={}
    for v,r,i in rows:
        assert len(v)==len(ds)
        for a,s in zip(v,ds):
            if s>=0:assert 0<=a<=s
        k=tuple(x for x,s in zip(v,ds) if s)
        assert k not in entries and (r or i)
        entries[k]=r,i
        d=lcm(d,r.denominator,i.denominator)
        assert len(entries)<=100_000
    h=sha256()
    for k,(r,i) in sorted(entries.items()):
        h.update((repr((k,(int(r*d),int(i*d))))+'\n').encode('ascii'))
    return d,len(entries),h.hexdigest()

@cache
def edge_digest(index,ds):
    def rows():
        for l in (P/'rays'/f'{index:02}.tsv').open():
            a,b,m,X,Y,r,i=l.split('\t')
            m=int(m)
            val=(m&255,parse(a),m>>8,parse(b))+tuple(v for ij in (*parse(X),*parse(Y)) for v in ij)
            yield val,Fraction(r),Fraction(i)
    return summarize(rows(),ds)

def emit(name,labels,w,dnr):
    if any(x[0]=='R' for x in w):
        assert set(w)<=set(all_factors[name])
    print(name,labels,w,*dnr,sep='\t')

for l in Path('AUTHOR/edge-bindings.tsv').open():
    t,u,v,k,row,i=l.split('\t')
    t,u,v,k,index=map(int,(t,u,v,k,i))
    tags=parse(row)
    s=dict(zip(((z,x,k) for z in range(2) for x in (u,v)),tags))
    w=pair(t,u,k)+pair(t,v,k)+tuple(wire(z,x,k,j,h) for x in (u,v) for z,cols in ((t,(0,1)),(1-t,(2,3))) for j in cols for h in range(2))
    ds=dims(w,s)
    name=f'E{t}{u}{k}'
    assert {x for x in all_factors[name] if x[0]!='R' or s.get(x[1:4],(0,0))[x[-1]]}==set(layout(w,ds))
    emit(name,tags,layout(w,ds),edge_digest(index,ds))

for l in Path('AUTHOR/temporal-bindings.tsv').open():
    t,x,h,row,shape=l.split('\t')
    t,x,h=map(int,(t,x,h))
    tags=parse(row)
    s=dict(zip(sorted((t,y,k) for k in range(3) for y in (x,x^(1<<k))),tags))
    states=[(y,k,q[h]) for (_,y,k),q in sorted(s.items()) if q[h]]
    S=tuple((n,bool(t^(x!=y))) for y,_,n in states)
    assert S==parse(shape)
    w=tuple(wire(t,y,k,j,h) for y,k,n in states for j in ((3,4) if x==y else (1,2)))
    ds=dims(w,s)
    name=f'T{t}{x}{h}'
    assert {v for v in all_factors[name] if s.get(v[1:4],(0,0))[v[-1]]}==set(w)
    if not S:assert temporal[S]==[((),Fraction(1),Fraction(0))]
    emit(name,tags,w,summarize(temporal[S],ds))
