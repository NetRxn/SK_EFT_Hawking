from ast import literal_eval as parse
from collections import defaultdict,Counter
from itertools import product
from pathlib import Path
from support import census,occupancy,spatial,profile

A=503841882182
B=1461451755920
Z=(0,0)
O=tuple(occupancy(c) for c in (A,B))
states=census(A,B)
G=[(u,u^(1<<k),k) for u,k in product(range(8),range(3)) if not u>>k&1]
def temporal_scope(t,x):
    return tuple(sorted((t,y,k) for k in range(3) for y in (x,x^(1<<k))))
def site_scope(x):
    return temporal_scope(0,x)+temporal_scope(1,x)
def edge_scope(u,v,k):
    return tuple((t,x,k) for t in range(2) for x in (u,v))

scopes={edge_scope(u,v,k) for u,v,k in G}|{site_scope(x) for x in range(8)}|{temporal_scope(t,x) for t,x in product(range(2),range(8))}
supported={axes:{tuple(s.get(q,Z) for q in axes) for s in states} for axes in scopes}
original=defaultdict(set)
for l in Path(f'DIRECT/{A}-{B}-local-labels.tsv').open():
    axes,vals=map(parse,l.split('\t'))
    assert vals not in original[axes]
    original[axes].add(vals)
assert original==supported and len(original)==36 and sum(map(len,original.values()))==740

locs=defaultdict(set)
stack={}
plan=set()
for l in Path('SITE/locations.tsv').open():
    i,t,x,data=l.split('\t')
    i,t,x=map(int,(i,t,x))
    data=parse(data)
    assert i not in stack and data not in locs[t,x]
    stack[i]=t,x,data
    locs[t,x].add(data)
for t,x in product(range(2),range(8)):assert locs[t,x]==supported[site_scope(x)]
assert len(stack)==976
expect_states=set()
spatial_shapes=set()
for i,(t,x,data) in stack.items():
    s=dict(zip(site_scope(x),data))
    expect_states.update((i,*k,*v) for k,v in s.items() if v!=Z)
    for k in range(3):
        u,v=sorted((x,x^(1<<k)))
        h=sum(sum(O[t][j])-O[t][j][k] for j in (u,v))
        for j in (u,v):
            shape=(h,*s[t,j,k],*s[1-t,j,k])
            plan.add((i,t,j,k,*shape))
            spatial_shapes.add(shape)
assert expect_states=={tuple(map(int,l.split())) for l in Path('AUTHOR/states.tsv').open()}
assert plan=={tuple(map(int,l.split())) for l in Path('AUTHOR/anchor-plan.tsv').open()}
assert len(plan)==5856
patterns=[]
for l in Path('AUTHOR/edge-plan.out').open():
    if l.startswith('pattern '):patterns.append(parse(l[8:l.rindex(')')+1]))
assert len(set(patterns))==len(patterns)==80
E=set()
for t in range(2):
    for u,v,k in G:
        axes=edge_scope(u,v,k)
        a,b=(sum(O[t][j])-O[t][j][k] for j in (u,v))
        for row in supported[axes]:
            z=dict(zip(axes,row))
            shapes=tuple((a+b,*z[t,j,k],*z[1-t,j,k]) for j in (u,v))
            E.add((t,u,v,k,row,patterns.index((a,b,*shapes))))
frozen_E=set()
for l in Path('AUTHOR/edge-bindings.tsv').open():
    t,u,v,k,row,i=l.split('\t')
    frozen_E.add((*map(int,(t,u,v,k)),parse(row),int(i)))
assert E==frozen_E and len(E)==184
T=set()
T_labels=set()
for t,x in product(range(2),range(8)):
    axes=temporal_scope(t,x)
    for row in supported[axes]:
        T_labels.add((t,x,axes,row))
        for h in range(2):
            sh=tuple((tag[h],bool(t^(x!=y))) for (_,y,k),tag in zip(axes,row) if tag[h])
            T.add((t,x,h,row,sh))
assert T=={(*map(int,z[:3]),parse(z[3]),parse(z[4])) for l in Path('AUTHOR/temporal-bindings.tsv').open() for z in [l.split('\t')]}
assert T_labels=={(*map(int,z[:2]),parse(z[2]),parse(z[3])) for l in Path('AUTHOR/temporal-labels.tsv').open() for z in [l.split('\t')]}
assert len(T)==320
for t,x in product(range(2),range(8)):
    assert temporal_scope(t,x) in supported
for u,v,k in G:assert edge_scope(u,v,k) in supported
print('exact local rosters, bindings',len(supported),sum(map(len,supported.values())),len(E),len(T),len(stack),len(plan))
print('occupation factorial and powers',Counter(d for occ in O for row in occ for d in row))
print('spatial moment shapes',len(spatial_shapes),'temporal moment shapes',len({r[-1] for r in T}))
loads=tuple(profile(code)[2] for code in (A,B))
for u,v,k in G:
    pair=tuple(sum(layer.get((u,v,k),(0,0))) for layer in loads)
    for row in supported[edge_scope(u,v,k)]:
        a,b,c,d=row
        assert spatial((a,c,b,d),pair)
keys={tuple(sorted(st.items())) for st in states}
fixed=0
wire_counts=Counter()
for st in states:
    current=tuple(sorted(st.items()))
    dual=tuple((k,(q,p)) for k,(p,q) in current)
    assert dual in keys
    fixed+=dual==current
    wire_counts[144+5*sum(bool(p)+bool(q) for (p,q) in st.values())]+=1
assert fixed==0
print('chirality involution fixed',fixed,'two-member orbits',len(states)//2)
print('assignment physical wire count distribution',sorted(wire_counts.items()))
print('recombination covers all primitive representation constraints by their original scopes')
