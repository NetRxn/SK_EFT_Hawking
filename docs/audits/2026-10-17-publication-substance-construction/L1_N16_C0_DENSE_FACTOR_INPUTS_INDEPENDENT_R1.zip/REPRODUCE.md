# Independent acceptance of dense L1 factor inputs

Verify the outer and independent manifests. The independent review accepts
the direct support rosters and all signed local factors, including their
exact normalization. It neither accepts a dense coefficient nor changes
the residual.

The author contraction control binds the physical and representation axes
to the 88 factor families. The compiler emits original per-label blocks and
keeps zero-padding of absent physical coordinates distinct from the irrep
labels. The exact E060–T160 control agrees with a Cartesian calculation,
summing a shared physical axis and retaining label equality on the boundary.
Greedy edge/temporal-only fusions did not reduce stored row count under the
checked admission bounds. The complete compiled network and final signed
contraction remain open.

The seven-assignment control preserves an exact frontier at the previous
row limit. One cut partitions it into six disjoint physical mask values.
The listed predicted bound applies to the join at that frontier. The
continuation can reach other limits before a complete coefficient is known.
Large underlying factor and frontier files remain local.
