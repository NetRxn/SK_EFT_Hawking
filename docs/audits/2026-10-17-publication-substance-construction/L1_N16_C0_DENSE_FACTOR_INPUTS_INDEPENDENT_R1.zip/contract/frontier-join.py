from collections import Counter,defaultdict
from fractions import Fraction
from math import factorial,lcm,prod
from pathlib import Path
import os,sys,types

folder=Path(sys.argv[1]).resolve()
a,b,w,expected=Path(sys.argv[2]).read_text().split()
expected_count=int(sys.argv[3])
os.environ['L1_PROFILE_CODES']=f'{a},{b}'
source=(folder/'compact-boundary.py').read_text().split('degree=Counter(',1)[0]
ids={int(l.split()[0]) for l in (folder/'anchor-plan.tsv').read_text().splitlines()}
assert len(ids)==expected_count
def read(case):
    m=types.ModuleType(f'_original_{case}')
    sys.modules[m.__name__]=m
    sys.argv=[sys.argv[0],str(folder),str(folder),str(case)]
    exec(source,m.__dict__)
    return m
cases=[read(i) for i in sorted(ids)]
active={k for case in cases for k in case.states
        if len({c.states.get(k,(0,0)) for c in cases})>1}
# Coalesce label axes with identical partitions of the full support.
# Each class maps bijectively to the retained axis on these states.
partitions={}
representative={}
def pattern(k):
    ids={}
    return tuple(ids.setdefault(c.states.get(k,(0,0)),len(ids)) for c in cases)
for k in sorted(active):
    representative[k]=partitions.setdefault(pattern(k),k)
def reduced(group):
    return {representative[k] for k in group&active}
active_axes=set(representative.values())
records=defaultdict(list)
def scope(f):
    kinds,*raw=f.name
    t,x,*tail=map(int,raw)
    if kinds in ('M','C'):
        return {(u,y,k) for u in range(2) for k in range(3) for y in (x,x^(1<<k))}
    if kinds=='T':
        return {(t,y,k) for k in range(3) for y in (x,x^(1<<k))}
    assert kinds=='E'
    k,=tail
    return {(u,y,k) for u in range(2) for y in (x,x^(1<<k))}
for c in cases:
    for f in c.factors:
        keys=tuple(sorted(reduced(scope(f))))
        labels=tuple(c.states.get(k,(0,0)) for k in keys)
        records[f.name].append((keys,labels,f))
def tagged(variants):
    ks=variants[0][0]
    assert all(keys==ks for keys,_,_ in variants)
    # Zero is the only value of a physical wire omitted in an irrep.
    physical=tuple(sorted({v for _,_,f in variants for v in f.wires}))
    den=lcm(*(f.denom for _,_,f in variants))
    by_label={}
    for _,label,f in variants:
        slots={wire:i for i,wire in enumerate(f.wires)}
        scale=den//f.denom
        block={tuple(row[slots[w]] if w in slots else 0 for w in physical):(r*scale,n*scale)
               for row,(r,n) in f.rows.items()}
        assert len(block)==len(f.rows)
        seen=by_label.setdefault(label,block)
        assert seen==block,(f.name,label)
    return tuple(('L',*k) for k in ks)+physical,{label+row:z for label,block in by_label.items() for row,z in block.items()},den
factors=[tagged(v) for v in records.values()]
# This control uses the full local views, whose natural join is exactly
# the four original supported states. Check that explicitly.
sv=[reduced(scope(e[0][2])) for e in records.values()]
domains={k:{c.states.get(k,(0,0)) for c in cases} for k in active_axes}
from itertools import product
axes=tuple(sorted(active_axes))
choices=prod(len(domains[k]) for k in axes)
assert choices<=65536
tables=[(tuple(sorted(group)),{tuple(c.states.get(k,(0,0)) for k in sorted(group)) for c in cases}) for group in sv if group]
supported=0
for combo in product(*(domains[k] for k in axes)):
    mapping=dict(zip(axes,combo))
    supported+=all(tuple(mapping[k] for k in kk) in relation for kk,relation in tables)
assert supported==len(ids)
print('bundle',len(factors),'representation axes',len(active_axes),'original axes',len(active),'initial rows',sum(len(r) for _,r,_ in factors),'support',supported,flush=True)

# Partition the exact global sum by one boundary representation label.
# Each branch fixes that axis in every incident factor.
label=min(active_axes,key=lambda k:(-len(domains[k]),k))
split_axis=('L',*label)
values=sorted(domains[label])
if os.environ.get('L1_LABEL_BRANCH')=='list':
    print('branches',len(values))
    raise SystemExit
i=int(os.environ['L1_LABEL_BRANCH'])
value=values[i]
grouped=[]
for keys,rows,den in factors:
    if split_axis not in keys:
        grouped.append((keys,rows,den))
        continue
    n=keys.index(split_axis)
    grouped.append((keys[:n]+keys[n+1:],
                    {row[:n]+row[n+1:]:z for row,z in rows.items() if row[n]==value},
                    den))
factors=grouped
print('branch',i,split_axis,value,'total branches',len(values),flush=True)

def hist(f,shared):
    axes,rows,d=f
    pos=tuple(axes.index(k) for k in shared)
    return Counter(tuple(row[i] for i in pos) for row in rows)
def score(i,j,factors,degree):
    a,b=factors[i],factors[j]
    shared=tuple(k for k in a[0] if k in b[0])
    union=set(a[0])|set(b[0])
    closed=sum(degree[k]==(2 if k in shared else 1) for k in union)
    # First pick by cheap size proxy. Compute exact work only for shortlisted joins.
    return len(a[1])*len(b[1])*(1+len(union)-closed),i,j,shared
def intersect_targets(factors, focus=None):
    from itertools import combinations
    pairs=[(i,j) for i,j in combinations(range(len(factors)),2)
           if focus is None or focus in (i,j)]
    for i,j in pairs:
        la,lr,_=factors[i]
        ra,rr,_=factors[j]
        shared=tuple(k for k in la if k in ra)
        if not shared:
            continue
        li=tuple(la.index(k) for k in shared)
        ri=tuple(ra.index(k) for k in shared)
        left={tuple(row[u] for u in li) for row in lr}
        right={tuple(row[u] for u in ri) for row in rr}
        if left!=right:
            allowed=left&right
            for rows,positions,found in ((lr,li,left),(rr,ri,right)):
                if allowed!=found:
                    for row in list(rows):
                        if tuple(row[u] for u in positions) not in allowed:
                            del rows[row]

peak=max(len(r) for _,r,_ in factors)
intersect_targets(factors)
intersect_targets(factors)
work=0
while len(factors)>1:
    degree=Counter(k for axes,_,_ in factors for k in axes)
    from itertools import combinations
    candidates=sorted(score(i,j,factors,degree) for i,j in combinations(range(len(factors)),2))
    linked=[x for x in candidates if any(k[0]!='L' for k in x[3])]
    candidates=linked or candidates
    costs=[]
    for _,i,j,shared in candidates:
        ah,bh=hist(factors[i],shared),hist(factors[j],shared)
        matched=sum(n*bh[k] for k,n in ah.items())
        union=set(factors[i][0])|set(factors[j][0])
        width=sum(degree[k]>(2 if k in shared else 1) for k in union)
        if matched<=8_000_000 and work+matched<=40_000_000:
            costs.append((matched*(1+width)**2,matched,i,j,shared))
            if len(costs)==12:
                break
    assert costs,('no admitted join',len(factors),work)
    _,matched,i,j,shared=min(costs)
    assert matched<=8_000_000 and work+matched<=40_000_000,('products',len(factors),matched,work)
    work+=matched
    la,lr,ld=factors[i]
    ra,rr,rd=factors[j]
    li=[la.index(k) for k in shared]
    ri=[ra.index(k) for k in shared]
    left=[u for u,k in enumerate(la) if degree[k]>(2 if k in shared else 1)]
    right=[u for u,k in enumerate(ra) if k not in la and degree[k]>1]
    keys=tuple(la[u] for u in left)+tuple(ra[u] for u in right)
    lookup=defaultdict(list)
    for row,z in rr.items():
        lookup[tuple(row[u] for u in ri)].append((tuple(row[u] for u in right),z))
    checks=[]
    if matched>250000:
        for index,(scope,rows,_) in enumerate(factors):
            if index in (i,j):
                continue
            shared_out=tuple(k for k in scope if k in keys)
            if not shared_out:
                continue
            source_positions=tuple(scope.index(k) for k in shared_out)
            positions=tuple(keys.index(k) for k in shared_out)
            projection={tuple(row[u] for u in source_positions) for row in rows}
            checks.append((positions,projection))
        checks.sort(key=lambda x:(len(x[1]),-len(x[0])))
    out={}
    for row,(x,y) in lr.items():
        base=tuple(row[u] for u in left)
        for tail,(a0,b0) in lookup[tuple(row[u] for u in li)]:
            k=base+tail
            if any(tuple(k[i] for i in axes) not in projection for axes,projection in checks):
                continue
            r,n=out.get(k,(0,0))
            z=r+x*a0-y*b0,n+x*b0+y*a0
            if any(z):
                if k not in out and len(out)>=500000:
                    import pickle
                    envelope={'factors':factors,'used_before':work-matched,
                              'rejected_pair':(i,j),'matched':matched,'support_branch':value}
                    tmp=Path(f'row-cap-branch-{os.environ["L1_LABEL_BRANCH"]}.tmp')
                    with tmp.open('xb') as handle:
                        pickle.dump(envelope,handle,protocol=5)
                    tmp.rename(tmp.with_suffix('.pkl'))
                    print('open row cap', len(factors), matched, 'frontier saved',flush=True)
                    raise SystemExit(2)
                out[k]=z
            else:
                out.pop(k,None)
    factors.pop(j)
    factors.pop(i)
    factors.append((keys,out,ld*rd))
    intersect_targets(factors,len(factors)-1)
    if len(factors)%8==0:
        intersect_targets(factors)
    peak=max(peak,len(out))
    print('join',len(factors),matched,len(out),'axes',len(keys),flush=True)
axes,scalar,den=factors[0]
assert not axes
c=cases[0]
world=sum((3+k)*n for row in c.occ for o in row for k,n in enumerate(o))
cross=0
for m in c.occ:
    weighted=[(u,v,sum(m[u])-m[u][k]+sum(m[v])-m[v][k]) for u,v,k in c.edges]
    cross+=sum(a[2]*b[2]*(u>v) for i,a in enumerate(weighted) for b in weighted[i+1:]
               for u in a[:2] for v in b[:2])
phase=(-1)**((world+cross)%2)
total=sum(n for m in c.occ for row in m for n in row)
assert total==32
norm=den*prod(factorial(p) for m in c.occ for o in m for p in o)*4**(2*total)
re,im=scalar.get((),(0,0))
actual=Fraction(phase*re,norm)
assert im==0
print('exact normalized',actual,'peak rows',peak,'matched products',work)
