from ast import literal_eval
from pathlib import Path
from collections import defaultdict,Counter
from math import lcm
import hashlib,os,pickle,sys,types

dense=Path(sys.argv[1]).resolve()
here=Path.cwd()
out=here/'compiled'
out.mkdir()
os.environ['L1_PROFILE_CODES']='503841882182,1461451755920'
fragment=Path('compact-boundary.py').read_text().split('factors=[f for t in range(2) for x in range(8)',1)[0]
sys.argv=[sys.argv[0],str(dense),str(here),'-1']
module=types.ModuleType('frozen_source')
sys.modules[module.__name__]=module
exec(fragment,module.__dict__)

def site_scope(x):
    return tuple(sorted((layer,y,k) for layer in range(2) for k in range(3) for y in (x,x^(1<<k))))
def t_scope(t,x):
    return tuple(sorted((t,y,k) for k in range(3) for y in (x,x^(1<<k))))
specs=defaultdict(list)
for line in (dense/'locations.tsv').read_text().splitlines():
    case,t,x,labels=line.split('\t')
    t,x,case=map(int,(t,x,case))
    labels=literal_eval(labels)
    for j,name in enumerate(('M','C')):
        specs[f'{name}{t}{x}'].append((site_scope(x),labels,(case,t,x,j)))
for line in (dense/'edge-bindings.tsv').read_text().splitlines():
    t,u,v,k,labels,index=line.split('\t')
    t,u,v,k,index=map(int,(t,u,v,k,index))
    scope=tuple((layer,x,k) for layer in range(2) for x in (u,v))
    specs[f'E{t}{u}{k}'].append((scope,literal_eval(labels),(t,u,v,k,index)))
for line in (dense/'temporal-bindings.tsv').read_text().splitlines():
    t,x,h,labels,shape=line.split('\t')
    t,x,h=map(int,(t,x,h))
    specs[f'T{t}{x}{h}'].append((t_scope(t,x),literal_eval(labels),(t,x,h,literal_eval(shape))))
assert Counter(name[0] for name in specs)=={'E':24,'T':32,'M':16,'C':16}
assert Counter({kind:sum(len(v) for k,v in specs.items() if k.startswith(kind)) for kind in 'EMCT'})=={'E':184,'T':320,'M':976,'C':976}
patterns={v:k for k,v in module.patterns.items()}
label_values=defaultdict(set)
for variants in specs.values():
    for axes,values,_ in variants:
        assert len(axes)==len(values)
        for wire,value in zip(axes,values):
            label_values[wire].add(value)
active={k for k,v in label_values.items() if len(v)>1}
wire_users=defaultdict(set)
locations=sorted(specs,key=lambda n:(n[0] in 'CM',n))
for name in locations:
    variants=specs[name]
    scope=variants[0][0]
    labels=tuple(('L',*k) for k in scope if k in active)
    physical=set()
    total=0
    maxblock=0
    den=1
    seen=set()
    with (out/(name+'.blocks')).open('wb') as dest:
        for keys,values,meta in variants:
            assert keys==scope
            module.states=dict(zip(keys,values))
            local=tuple(v for k,v in zip(keys,values) if k in active)
            assert local not in seen
            seen.add(local)
            if name[0] in 'MC':
                case,t,x,j=meta
                module.case=case
                # Build only the requested split factor. The source binding
                # definition controls the physical axes of both factors.
                f=module.site_pair(t,x)[j]
            elif name[0]=='E':
                t,u,v,k,index=meta
                a,b,left,right=patterns[index]
                module.plan={(t,u,k):left,(t,v,k):right}
                assert left==(a+b,*module.states[t,u,k],*module.states[1-t,u,k])
                assert right==(a+b,*module.states[t,v,k],*module.states[1-t,v,k])
                f=module.spatial_factor(t,u,v,k)
            else:
                t,x,h,_=meta
                f=module.temporal_factor(t,x,h)
            assert f.name==name and f.denom>0
            physical.update(f.wires)
            total+=len(f.rows)
            maxblock=max(maxblock,len(f.rows))
            den=lcm(den,f.denom)
            pickle.dump((local,f.wires,f.denom,f.rows),dest,protocol=5)
    for wire in physical:
        wire_users[wire].add(name)
    print(name,'blocks',len(variants),'rows',total,'peak block',maxblock,'labels',len(labels),'physical',len(physical),'denominator',den,flush=True)
    with Path('schema.tsv').open('a') as f:
        print(name,labels,tuple(sorted(physical)),len(variants),total,den,sep='\t',file=f)
assert all(len(users)==2 for users in wire_users.values())
print('wire incidence verified',len(wire_users),'physical axes',len(active),'varying representation axes',flush=True)
