from collections import Counter
from pathlib import Path
import pickle

with Path('row-cap-branch-0.pkl').open('rb') as f:
    obj=pickle.load(f)
F=obj['factors']; x,y=obj['rejected_pair']
A,L,_=F[x]; B,R,_=F[y]
shared=tuple(w for w in A if w in B)
la=[A.index(k) for k in shared]
rb=[B.index(k) for k in shared]
left=Counter(tuple(r[i] for i in la) for r in L)
right=Counter(tuple(r[i] for i in rb) for r in R)
options=[]
for axes,table,index,others in ((A,L,la,right),(B,R,rb,left)):
    for k,w in enumerate(axes):
        if w in shared or w[0]=='L':
            continue
        counts=Counter()
        for row in table:
            counts[row[k]]+=others[tuple(row[i] for i in index)]
        counts=Counter({value:n for value,n in counts.items() if n})
        assert sum(counts.values())==obj['matched']
        if len(counts)>1:
            options.append((max(counts.values()), len(counts),w,dict(sorted(counts.items()))))
assert options
admitted=[item for item in options if item[0]<=500000]
assert admitted
n,k,w,counts=min(admitted,key=lambda x:(x[1],x[0],x[2]))
domains=[]
for axes,table,_ in F:
    if w in axes:
        i=axes.index(w)
        domains.append({r[i] for r in table})
values=sorted(set.intersection(*domains))
assert set(counts)<=set.union(*domains)
print('cut',w,'valid slices',len(values),'max predicted products',n,'joint products',obj['matched'])
Path('cut.tsv').write_text(f'{w!r}\t{values!r}\n')
