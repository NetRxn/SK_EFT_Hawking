from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle

exec(Path('exact-pair-control.py').read_text().split("left,L,ld=load('E060')",1)[0])
import functools
load=functools.cache(load)
original={name for name in schema if name.startswith(('E','T'))}
fused={}
active=set(original)
def factor(name):
    return fused[name] if name in fused else load(name)
def specs(name):
    if name in fused:
        axes,rows,den=fused[name]
        return axes,len(rows)
    labels,physical,_,rows,_=schema[name]
    return labels+physical,rows
def merge(a,b,shared):
    left,L,ld=a
    right,R,rd=b
    closed={w for w in shared if w[0]!='L'}
    assert closed
    keep=tuple(w for w in left if w not in closed)+tuple(w for w in right if w not in left)
    li=tuple(left.index(w) for w in shared)
    ri=tuple(right.index(w) for w in shared)
    lp=tuple(left.index(w) for w in keep if w in left)
    rp=tuple(right.index(w) for w in keep if w not in left)
    buckets=defaultdict(list)
    for row,z in R.items():
        buckets[tuple(row[i] for i in ri)].append((tuple(row[i] for i in rp),z))
    work=sum(len(buckets.get(tuple(row[i] for i in li),())) for row in L)
    if work>150000:
        return None,work
    out={}
    limit=len(L)+len(R)
    for row,(x,y) in L.items():
        prefix=tuple(row[i] for i in lp)
        for tail,(a,b) in buckets.get(tuple(row[i] for i in li),()):
            key=prefix+tail
            r,i=out.get(key,(0,0))
            z=r+x*a-y*b,i+x*b+y*a
            if any(z):
                out[key]=z
            else:
                out.pop(key,None)
    if len(out)>=limit:
        return None,work
    return (keep,out,ld*rd),work

directory=Path('edge-temporal-reduced')
directory.mkdir()
seen=set()
steps=0
while True:
    choices=[]
    for x,y in combinations(sorted(active),2):
        if (x,y) in seen:
            continue
        a,na=specs(x); b,nb=specs(y)
        shared=tuple(k for k in a if k in b)
        if any(k[0]=='R' for k in shared):
            choices.append((na*nb,x,y,shared))
    if not choices:
        break
    _,x,y,shared=min(choices)
    seen.add((x,y))
    if len(seen)>180:
        break
    result,work=merge(factor(x),factor(y),shared)
    if result is None:
        continue
    steps+=1
    name=f'F{steps:02}'
    active.difference_update((x,y))
    active.add(name)
    fused[name]=result
    print('fused',x,y,name,'work',work,'rows',len(result[1]),flush=True)
    assert len(result[0])==len(set(result[0]))
    with (directory/f'{name}.block').open('wb') as f:
        pickle.dump(result,f,protocol=5)
with (directory/'active.tsv').open('w') as f:
    for name in sorted(active):
        axes,rows=specs(name)
        print(name,axes,rows,sep='\t',file=f)
prior=sum(specs(n)[1] for n in original)
final=sum(specs(n)[1] for n in active)
print('completed',steps,'pair contractions, edge-temporal factors',len(original),len(active),
      'rows',prior,final,'evaluated pairs',len(seen))
