from ast import literal_eval as lit
from collections import defaultdict
from pathlib import Path
from fractions import Fraction
import pickle

schema={}
for line in Path('schema.tsv').read_text().splitlines():
    name,labels,physical,blocks,rows,denom=line.split('\t')
    schema[name]=(lit(labels),lit(physical),int(blocks),int(rows),int(denom))

def load(name):
    labels,physical,nblocks,nrows,d=schema[name]
    entries={}
    with Path(f'compiled/{name}.blocks').open('rb') as f:
        for _ in range(nblocks):
            local,wires,den,rows=pickle.load(f)
            assert d%den==0 and set(wires)<=set(physical)
            order=[wires.index(w) if w in wires else None for w in physical]
            for r,(a,b) in rows.items():
                key=local+tuple(r[i] if i is not None else 0 for i in order)
                assert key not in entries
                entries[key]=a*(d//den),b*(d//den)
        assert not f.read(1)
    assert len(entries)==nrows
    return labels+physical,entries,d

left,L,ld=load('E060')
right,R,rd=load('T160')
shared=tuple(w for w in left if w in right)
closed={w for w in shared if w[0]!='L'}
assert len(closed)==1
axes=tuple(w for w in left if w not in closed)+tuple(w for w in right if w not in left)
li=tuple(left.index(w) for w in shared)
ri=tuple(right.index(w) for w in shared)
lp=tuple(left.index(w) for w in axes if w in left)
rp=tuple(right.index(w) for w in axes if w not in left)
buckets=defaultdict(list)
for row,z in R.items():
    buckets[tuple(row[i] for i in ri)].append((tuple(row[i] for i in rp),z))
out=defaultdict(lambda:(0,0))
n=0
for row,(a,b) in L.items():
    for part,(c,d) in buckets[tuple(row[i] for i in li)]:
        key=tuple(row[i] for i in lp)+part
        r,j=out[key]
        out[key]=r+a*c-b*d,j+a*d+b*c
        n+=1
out={key:z for key,z in out.items() if any(z)}
# Literal Cartesian control using row dictionaries and exact complex fractions.
reference=defaultdict(lambda:(Fraction(),Fraction()))
for row,(a,b) in L.items():
    lhs=dict(zip(left,row))
    for column,(c,d) in R.items():
        rhs=dict(zip(right,column))
        if any(lhs[w]!=rhs[w] for w in shared):
            continue
        x=lhs|rhs
        key=tuple(x[w] for w in axes)
        r,j=reference[key]
        reference[key]=r+Fraction(a*c-b*d,ld*rd),j+Fraction(a*d+b*c,ld*rd)
assert {k:v for k,v in reference.items() if any(v)}=={k:(Fraction(a,ld*rd),Fraction(b,ld*rd)) for k,(a,b) in out.items()}
print('edge E060 and temporal T160',len(L),len(R),'matches',n,'signed survivors',len(out),'closed',sorted(closed),'retained axes',len(axes))
with Path('contracted-pair.tsv').open('w') as f:
    print(axes,ld*rd,sep='\t',file=f)
    for key,(a,b) in sorted(out.items()):
        print(key,a,b,sep='\t',file=f)
