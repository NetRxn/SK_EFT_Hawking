from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial
import importlib.util
import json
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

def load(label, path):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module

r4 = load("r4review", "/tmp/publication-task4-later-full-vertex-r4.py")
Q, P, S = o.QComplex, o.Polynomial, o.Symbol
reg = o.OriginalRegulator()
x, y = reg.sites[0], reg.step(reg.sites[0], 0)[0]
x2 = reg.step(x, 2)[0]
q = S("g2", ())
j = S("J", (y, 0, 0))
assert (reg.volume, reg.word, reg.convention) == (16, "closed", "source_C")

def tensor(alpha, *, slot=(), labels=()):
    # Rebuild the four signed bilinears directly from the block definition
    # and the globally ordered bar/psi basis. No author arena or ExteriorPolynomial.
    positions = {token: i for i, token in enumerate(reg.generator_order)}
    out = defaultdict(Q)
    blocks = f.original_coframe_blocks(reg, alpha)
    for b in blocks:
        for i, k in product(range(4), repeat=2):
            a, z = positions[b.bar_site, "bar", i], positions[b.psi_site, "psi", k]
            for key, value in b.matrix[i][k].terms:
                out[(1 << a | 1 << z, tuple(sorted((*labels, *key))), slot)] += value * b.weight * (-1 if a > z else 1)
    return {k: v for k, v in out.items() if v}

def trace_rows(site, k, l, mu, nu, a, b):
    # Direct closed matrix word D† C† B A, with original quaternion labels.
    anchors = (site,k), (reg.step(site,k)[0],l), (reg.step(site,l)[0],k), (site,l)
    links = [f.original_spin4_link(*(tuple(P.variable(S("q",(*z,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for z in anchors]
    A,B,C,D = links
    U = o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(D),o.matrix_dagger(C)),o.matrix_multiply(B,A))
    gamma = o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    poly = sum((U[i][k]*gamma[k][i] for i,k in product(range(4),repeat=2)),P()) * o.epsilon((k,l,mu,nu))
    return {(0,key,()): value for key,value in poly.terms}

def indices(mask):
    return [i for i in range(mask.bit_length()) if mask >> i & 1]

def multiply(left, right):
    out = defaultdict(Q)
    for (lm,lk,lj), lv in left.items():
        for (rm,rk,rj), rv in right.items():
            if lm & rm or len(lj) + len(rj) > 2:
                continue
            z = tuple(sorted(lj + rj))
            multiplicity = 1
            for i in set(z):
                multiplicity *= factorial(z.count(i)) // (factorial(lj.count(i)) * factorial(rj.count(i)))
            parity = sum(i > k for i,k in product(indices(lm),indices(rm))) % 2
            out[lm|rm,tuple(sorted(lk+rk)),z] += lv * rv * (-multiplicity if parity else multiplicity)
    return {k:v for k,v in out.items() if v}

def summed(*maps):
    out = defaultdict(Q)
    for d in maps:
        for k,v in d.items(): out[k] += v
    return {k:v for k,v in out.items() if v}

def slot_relabel(d, slot):
    return {(m,k,slot):v for (m,k,_),v in d.items()}

def snapshot(arena, handle):
    out = {}
    arena.scan(handle, lambda k,v:out.__setitem__(k,v))
    return out

from collections import Counter
from itertools import combinations

r6=load("r6review","/tmp/publication-task4-complete-predecessor-r6.py")
r4,r5=r6.r4,r6.r5
a=r4.Arena(r4.Caps(1_000_000,65_536))
w=r5.Work()
hc,hr,hd,oc,orr,*_=r6.source(reg,a)
th,hh,*_=r5.source_roster(reg,y,a,w)
assert a.metric()["live_records"]==22215
C0=multiply(tensor((x,0,0)),tensor((x,1,1)))
C={(m,tuple(sorted((*key,q))),slot):coef for (m,key,slot),coef in C0.items()}
R=multiply(trace_rows(x,2,3,0,1,0,1),tensor((x2,2,0)))
D0=tensor((y,0,0),labels=(j,))
D1=tensor((y,1,0),labels=(j,))
D={(0,):D0,(0,1):summed(D0,D1)}
assert [len(C),len(R),len(D[(0,)]),len(D[(0,1)])]==[3584,8192,64,128]
assert C==snapshot(a,hc) and R==snapshot(a,hr)
assert all(d==snapshot(a,hd[slot]) for slot,d in D.items())
T={(mu,i):tensor((y,mu,i)) for mu,i in product(range(4),repeat=2)}
assert len(T)==16 and all(len(d)==64 and d==snapshot(a,th[key]) for key,d in T.items())
H={}
diagonals=0
for mu,nu in combinations(range(4),2):
    k,l=[i for i in range(4) if i not in (mu,nu)]
    for i,jj in product(range(4),repeat=2):
        h=trace_rows(y,k,l,mu,nu,i,jj)
        h_op=trace_rows(y,l,k,mu,nu,i,jj)
        flipped=trace_rows(y,k,l,nu,mu,jj,i)
        both=trace_rows(y,l,k,nu,mu,jj,i)
        if i==jj:
            assert h and h_op and flipped and both
            assert not summed(h,flipped) and not summed(h_op,both)
            diagonals+=1
        else:
            assert h==h_op==flipped==both and len(h)==128
            tag=k,l,mu,nu,i,jj
            H[tag]={(m,tuple(sorted((*sy,q))),s):v for (m,sy,s),v in h.items()}
            assert H[tag]==snapshot(a,hh[tag])
assert set(H)==set(hh) and len(H)==72 and diagonals==24

# Verify the exact old slice, using earlier accepted R4 ordering to
# identify its R term only. Original source coefficients come from C/R.
st,ch,rh = r4.future_prefix(r4.Caps(200_000,65_536),r4.factors(reg))
assert C0==snapshot(st,ch) and R==snapshot(st,rh)
seed_r=next(key for key in snapshot(st,rh)
            if any(s.family=="q" and s.index[:2]==(x,2) and key[1].count(s)==2 for s in key[1]))
old_r={seed_r:R[seed_r]}
ybit=1 << (8*reg.site_number(y))
c_labels={tuple(sorted((S("q",(x,0,"L",i)),S("q",(x,1,"L",0)),q))) for i in (1,2)}
old_c={k:v for k,v in C.items() if k[0] & (255*ybit)==ybit and k[1] in c_labels}
assert (len(old_c),len(old_r))==(6,1)
assert old_c==snapshot(a,oc) and old_r==snapshot(a,orr)

def decode(d):
    def freeze(x):
        return tuple(map(freeze,x)) if isinstance(x,list) else x
    return int(d["mask_hex"],16),tuple(S(n,freeze(v)) for n,v in d["symbols"]),tuple(d["slot"])

def forward(key, c, r):
    mask, sy, slot=key
    if slot not in D:
        return {}, Counter(), set(), set(), {}
    powers=Counter(sy)
    def filter_(d):
        return [(k,v,Counter(k[1])) for k,v in d.items() if k[0]&mask==k[0] and not Counter(k[1])-powers]
    projected={nm:filter_(d) for nm,d in (("C",c),("D",D[slot]),("R",r))}
    pre=[]
    for (kc,vc,pc),(kd,vd,pd),(kr,vr,pr) in product(*(projected[nm] for nm in ("C","D","R"))):
        m0,m1,m2=kc[0],kd[0],kr[0]
        if m0&m1 or (m0|m1)&m2 or (pc+pd+pr)-powers:
            continue
        key0=(kc,kd,kr)
        pre.append((key0,m0|m1|m2,pc+pd+pr,vc*vd*vr*(-1)**(
            inv(m0,m1)+inv(m0,m2)+inv(m1,m2))))
    groups={}
    origins=Counter()
    witnesses=set()
    paths=set()
    ts={k:filter_(d) for k,d in T.items()}
    for (k,l,mu,nu,i,jj),h in H.items():
        group=k,l,mu,nu,i,jj
        for (pk,pm,pp,pv),(ka,va,pa),(kb,vb,pb),(kh,vh,ph) in product(pre,ts[mu,i],ts[nu,jj],filter_(h)):
            ma,mb=ka[0],kb[0]
            assert kh[0]==0
            if pm&(ma|mb) or ma&mb or pm|ma|mb!=mask or pp+pa+pb+ph!=powers:
                continue
            value=pv*va*vb*vh*(-1)**(inv(pm,ma)+inv(pm,mb)+inv(ma,mb))
            assert value
            groups[group]=groups.get(group,Q(0))+value
            kc,kd,kr=pk
            extra=slot==(0,1) and kd in D1
            origins[kc not in old_c,kr not in old_r,extra]+=1
            witnesses.add(pk)
            path=(pk,group,ka,kb,kh)
            assert path not in paths
            paths.add(path)
    return groups,origins,witnesses,paths,{n:len(rows) for n,rows in projected.items()}

def inv(L,R):
    return sum(i>k for i,k in product(indices(L),indices(R)))

def fmt(g):
    return [[list(k),str(v)] for k,v in sorted(g.items())]

def compare(result, observed):
    groups,origins,witnesses,paths,projection=result
    assert len(paths)==observed["later_raw_signed_paths"]
    assert len(witnesses)==observed["predecessor_paths_with_later_contributions"]
    assert projection==observed["projected_operands"]
    assert [[*k,n] for k,n in sorted(origins.items())]==[list(entry) for entry in observed["origins"]]

auth=json.load(open("/tmp/publication-task4-complete-predecessor-r6.json"))
r5_receipt=json.load(open("/tmp/publication-task4-all-residual-reaggregation-r5.json"))
old_tables={decode(row["output_key"]):row["group_sums"] for row in r5_receipt["exact_common_output_keys"]}
rows=[]
for row in auth["target_results"]:
    key=decode(row["output_key"])
    full=forward(key,C,R)
    restricted=forward(key,old_c,old_r)
    g,og=full[0],restricted[0]
    assert fmt(g)==row["full_group_sums"] and fmt(og)==row["restricted_group_sums"]
    compare(full,row["full"]); compare(restricted,row["restricted"])
    if row["accepted_r5_target"]:
        assert fmt(og)==old_tables[key]
    else:
        wd=row["new_source_witness"]
        witness=tuple(decode(wd[name]) for name in ("C","D","R"))
        assert witness in full[2] and witness[0] not in old_c and witness[2] not in old_r
        assert key[2]!=(0,1) or witness[1] in D1
    total=sum(g.values(),Q(0))
    assert str(total)==row["full_total"] and (not total)==row["full_total_zero"]
    differs={k:v for k,v in g.items() if v}!={k:v for k,v in og.items() if v}
    assert differs==row["full_differs_from_restriction"]
    rows.append({"slot":key[2],"accepted_r5_target":row["accepted_r5_target"],
        "total_zero":not total,"full_paths":len(full[3]),"restricted_paths":len(restricted[3]),
        "full_nonzero_groups":sum(bool(v) for v in g.values()),
        "restricted_nonzero_groups":sum(bool(v) for v in og.values()),
        "changed":differs,"origins":[[*k,v] for k,v in sorted(full[1].items())]})
assert sum(r["changed"] for r in rows)==12
assert sum(r["accepted_r5_target"] and r["slot"]==(0,) and r["total_zero"] and r["restricted_nonzero_groups"]==4 for r in rows)==2
assert sum(not r["accepted_r5_target"] and r["slot"]==(0,1) and r["total_zero"] and r["full_paths"]==12 for r in rows)==2

# Build extra witnesses from a different source geometry and row order.
# Each key must have a specific forward path with both new C and new R.
seen={decode(r["output_key"]) for r in auth["target_results"]}
tag=(0,1,2,3,3,2)
_,_,mu,nu,i,jj=tag
W=multiply(T[mu,i],T[nu,jj])
wm,ws,_=next(reversed(W))
hkeys=list(reversed(H[tag]))[:3]
targets=[]
for slot, direction in (((0,),D0),((0,1),D1),((0,1),D0)):
    found=False
    for kc in reversed(C):
        if kc in old_c or kc[0]&wm: continue
        for kr in reversed(R):
            if kr in old_r or kr[0]&(kc[0]|wm): continue
            occ=kr[0]|kc[0]|wm
            for kd in reversed(direction):
                if kd[0]&occ: continue
                for _,hs,_ in hkeys:
                    key=(occ|kd[0],tuple(sorted(kc[1]+kr[1]+kd[1]+ws+hs)),slot)
                    assert key not in seen
                    targets.append((key,(kc,kd,kr)))
                found=True
                break
            if found: break
        if found: break
    assert found
k=next(key for key in sorted(seen) if any(s.family=="q" and n>=2 for s,n in Counter(key[1]).items()))
m,sy,slot=k
removed=list(sy)
squared=next(s for s,n in Counter(sy).items() if s.family=="q" and n>=2)
removed.remove(squared)
adverse=[(m,tuple(removed),slot),(m,sy,(1,)),(0,sy,slot)]
anchors=((y,1),(reg.step(y,1)[0],1))
controls=[]
for key,witness in targets+[(k,None) for k in adverse]:
    expected=forward(key,C,R)
    g,info=r6.evaluate(a,hc,hr,hd,oc,orr,th,hh,key,anchors,w)
    assert g==expected[0]
    if witness:
        assert witness in expected[2]
        assert key[2]!=(0,1) or any(origin[2]==(witness[1] in D1) for origin in expected[1])
        compare(expected,info)
    else:
        assert not expected[3] and info["later_raw_signed_paths"]==0
    controls.append({"key":r5.fingerprint(key),"has_path":bool(expected[3]),
        "group_sums":fmt(g),"paths":len(expected[3]),"witness_direction":(1 if witness[1] in D1 else 0) if witness else None,"origins":[[*k,v] for k,v in sorted(expected[1].items())]})
print(json.dumps({"roster":{"C":len(C),"R":len(R),"D":[len(d) for d in D.values()],
    "C_old":len(old_c),"R_old":len(old_r),"groups":len(H),"diagonals":diagonals},
    "author_target_results":rows,"extra_geometry":tag,"extra_and_adverse_controls":controls},indent=2))
