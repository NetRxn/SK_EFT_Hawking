# Independent original N16 complete predecessor review R6

**ACCEPT the exact full-key coefficient evaluator for the selected original
predecessor branch and its selected later center.** The complete C and R
operands replace the six-C/one-R restriction in this branch. Both raw
contact factors, all 72 grouped S2 choices and the typed bounded
convolution remain exact. This result evaluates requested coefficients
of the represented branch. Further original predecessor choices, other
centers, the nine original site alternatives, proved last incidences,
full Z and connected normalization remain open.

## Authority and replay

The exact author replay matched every deterministic JSON field at
primary 212e9f91e9c18d61e234c1144af7063efe4923db. Replay peak RSS was
120,324,096 bytes. The actual eager C·R probe stopped at visit 43,801
before prospective record 65,537 and restored all 22,215 live records
across 94 factor and restriction maps, with no live indexes or readers.
The successful bounded probe finished at 47,449 arena visits, peak
65,536 logical records, and 521,048 separately charged work operations.
The mirrored forward factors and arithmetic temporaries sit outside
the arena. Process RSS is observational. The authored exploratory
failure with an omitted RawJet value slot remains separate.

## Independent source and signed reconstruction

I rebuilt the original oriented block hopping increments on the
explicit globally ordered bar/psi basis, the closed D† C† B A trace and
the signs by direct basis inversion counts. Every coefficient in the
3,584-row C and 8,192-row R maps matched. The 64-row literal and 128-row
mixed contact maps matched, with the latter equal to the sum of the two
original world-direction blocks and the same exact J label. All 16
later coframe maps and 72 aligned nonzero trace maps matched. The 24
diagonal choices canceled their paired original trace pieces.

The full sorted target key requires every contributing operand's mask
and symbol multiset to fit inside it. The reference independently
filters with Counter inclusion and enumerates forward combinations
of C, D, R, the two later coframes and the trace. It counts the signed
path before addition, including its actual C/R restriction membership
and raw contact origin. It does not use the author inverse subtraction,
mask splitting, sign calculation or arena product to form reference
coefficients. Both R and D have exterior degree two, so the order change
between C·D·R and C·R·D preserves signs. Only D supplies the raw slot
at this seam. Every eligible predecessor tuple is streamed once, and
the later inverse key has exactly the six ordered two-bit splits and
the forced per-axis symbols. Distinct tuples may produce identical
keys, and summing their signed values is valid by linearity.

I compared every group subtotal and path count for all 20 authored
targets in both full and restricted form, as well as the per-operand
projection and contributing precursor counts. The exact old six C
rows and one R row recovered all 12 R5 tables, including zeros.
The full branch differs for 12 of the 20 keys. Two previously nonzero
literal outputs now cancel all four group subtotals against new C
paths. All eight new author keys have an explicitly verified path
using both a new C and a new R row. The four new mixed witnesses use
direction 1. Two of those mixed keys have 12 nonzero raw paths each
and exactly cancel all group subtotals.

## New directional and adverse controls

Nine independently generated reachable keys use a different later
coframe pair, with curvature axes 0 and 1 and coframe axes 2 and 3.
Each has an exact path with a new C and new R. Three are literal with
eight signed paths each, three are mixed direction 0 with eight
signed paths each, and three are mixed direction 1 with four signed
paths each. The independent forward and authored inverse matched
all subtotals and origin counts. The new controls are distinct from
the 20 authored targets and from each other.

A missing occurrence of a known squared quaternion coordinate, an
unoccupied derivative slot, and an empty exterior mask each gave
zero paths in both calculations. The first exploratory independent
script selected a new key without a square. The second compared
tuple-shaped live origins with list-shaped JSON origins. The final
script uses a verified square and normalizes the containers. Those
scratch failures are documented separately.

Both reviewer continuity checks were fresh, byte-identical, and
reported no changed inputs. No checkout, Lean or slot actions occurred.
The complete evidence prefix is /tmp/task4-predecessor-review-r6- with
suffixes first.json, final.json, replay.json, both-directions.py,
both-directions.json, independent-adverse.txt and independent.md.
