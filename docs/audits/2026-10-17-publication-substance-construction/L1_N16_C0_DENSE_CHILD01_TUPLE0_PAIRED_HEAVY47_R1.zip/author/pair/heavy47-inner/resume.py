from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from collections import Counter
import pickle
import shutil
import subprocess
import sys
import time
import os

drivers = Path('/private/tmp/l1-c0-case45.AcSqmg')
root = Path(__file__).resolve().parent

def run_case(case):
    os.chdir(root)
    assert not Path(f'author-case{case}.tsv').exists()
    indexes = (2, 3, 7, 8)
    assert {int(line.split('\t')[0]) for line in Path('rescue.tsv').read_text().splitlines()
            if line.split('\t')[1] == '2'} == set(indexes)
    for name in ('triangle-shards.py', 'close-four-shards.py', 'sum-shards.py'):
        if not Path(name).exists():
            shutil.copyfile(drivers / name, name)
        assert Path(name).read_bytes() == (drivers / name).read_bytes()
    with Path('four-pair-census.tsv').open('x') as report:
        for index in (7, 8):
            with Path(f'row-cap-physical-slice-dense-label-rescue-{index}-0-reduced.pkl').open('rb') as stream:
                factors = pickle.load(stream)['factors']
            assert len(factors) == 4
            axes_a, rows_a, _ = factors[1]
            axes_b, rows_b, _ = factors[3]
            shared = tuple(axis for axis in axes_a if axis in axes_b)
            a = tuple(axes_a.index(axis) for axis in shared)
            b = tuple(axes_b.index(axis) for axis in shared)
            census = Counter(tuple(row[i] for i in b) for row in rows_b)
            ordered = sorted(rows_a)
            counts = []
            for shard in range(8):
                lo, hi = len(ordered) * shard // 8, len(ordered) * (shard + 1) // 8
                counts.append(sum(census[tuple(row[i] for i in a)] for row in ordered[lo:hi]))
            assert max(counts) <= 8_000_000
            print(index, *counts, sum(counts), sep='\t', file=report)

    def run(task):
        index, shard = task
        start = time.monotonic()
        if index in (2, 3):
            command = ['triangle-shards.py', f'join-cap-dense-label-rescue-{index}-1-reduced.pkl', str(shard), '8']
        else:
            command = ['close-four-shards.py', f'row-cap-physical-slice-dense-label-rescue-{index}-0-reduced.pkl',
                       '--pair', '1', '3', '--shard', str(shard), '8']
        with Path(f'slice-{index}-shard-{shard}.out').open('xb') as receipt:
            subprocess.run([sys.executable, *command], stdout=receipt, stderr=subprocess.STDOUT, timeout=135, check=True)
        return f'{index}\t{shard}\t{time.monotonic() - start:.3f}'

    with ThreadPoolExecutor(max_workers=2) as pool, Path('shard-timing.tsv').open('xb') as timing:
        for row in pool.map(run, ((i, j) for i in indexes for j in range(8))):
            timing.write((row + '\n').encode())
            timing.flush()
    for index in indexes:
        with Path(f'slice-{index}-shard-sum.out').open('xb') as output:
            subprocess.run([sys.executable, 'sum-shards.py', str(index), '8'], stdout=output, check=True)
    pending = Path(f'author-case{case}.ready')
    with pending.open('xb') as output:
        subprocess.run([sys.executable, f'sum-case{case}.py'], stdout=output, check=True)
    closed = pending.rename(f'author-case{case}.tsv')
    print(case, closed.read_text().splitlines()[-1], flush=True)

for case in map(int, sys.argv[1:]):
    run_case(case)
