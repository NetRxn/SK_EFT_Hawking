from ast import literal_eval
from collections import Counter, defaultdict
import hashlib
from pathlib import Path
import pickle
import sys
import time

root=Path(__file__).resolve().parent.parent
inputs=[root/f'row-cap-physical-slice-dense-label-tuple0-branch-{i}-reduced.pkl' for i in (0,1)]
sources=[]
for path in inputs:
    with path.open('rb') as f:
        digest=hashlib.file_digest(f,'sha256').hexdigest()
        f.seek(0)
        data=pickle.load(f)
    assert data['rejected_pair']==(0,1) and data['matched']==6_427_904
    print(path.name,digest,flush=True)
    sources.append(data)
assert sources[0]['conditioning'][:-1]==sources[1]['conditioning'][:-1]
assert [src['conditioning'][-1] for src in sources]==[(('R',0,0,2,0,1),i) for i in (0,1)]
left,right=[s['factors'] for s in sources]
assert len(left)==len(right)==8 and left[2:]==right[2:]
roster=literal_eval((root/'tuple0-branch0-pilot'/'pilot.roster').read_text())
cuts,expected=roster
assert len(expected)==48 and sum(n for _,n in expected)==6_427_904 and max(n for _,n in expected)<=212688

def prepare(factors):
    (a,A,ad),(b,B,bd)=factors[:2]
    degree=Counter(axis for axes,_,_ in factors for axis in axes)
    shared=tuple(axis for axis in a if axis in b)
    assert all(degree[axis]==2 for axis in shared)
    assert set(cuts) <= set(a)-set(shared)
    apos=tuple(a.index(axis) for axis in shared)
    bpos=tuple(b.index(axis) for axis in shared)
    aout=tuple(i for i,axis in enumerate(a) if axis not in shared)
    bout=tuple(i for i,axis in enumerate(b) if axis not in shared)
    groups=defaultdict(list)
    lookup=defaultdict(list)
    positions=tuple(a.index(axis) for axis in cuts)
    for row,z in A.items():
        groups[tuple(row[i] for i in positions)].append((tuple(row[i] for i in apos),tuple(row[i] for i in aout),z))
    for row,z in B.items():
        lookup[tuple(row[i] for i in bpos)].append((tuple(row[i] for i in bout),z))
    return tuple(a[i] for i in aout)+tuple(b[i] for i in bout),ad*bd,groups,lookup
ax,d,L,R=prepare(left)
bx,e,M,S=prepare(right)
assert (ax,d)==(bx,e)
for group,lookup in ((L,R),(M,S)):
    supported={key:sum(len(lookup.get(join,())) for join,_,_ in rows)
               for key,rows in group.items()}
    assert {key:n for key,n in supported.items() if n} == dict(expected)

def contract(group,lookup,label,count):
    out={}
    done=0
    for join,head,(a,b) in group[label]:
        rows=lookup.get(join,())
        done+=len(rows)
        for tail,(c,d) in rows:
            k=head+tail
            x,y=out.get(k,(0,0))
            z=(x+a*c-b*d,y+a*d+b*c)
            if any(z):
                out[k]=z
            else:
                out.pop(k,None)
    assert done==count
    return out
offset=int(sys.argv[1]) if len(sys.argv)>1 else 0
take=int(sys.argv[2]) if len(sys.argv)>2 else 48
for key,count in sorted(expected,key=lambda row:(row[1],row[0]))[offset:offset+take]:
    start=time.monotonic()
    aa=contract(L,R,key,count)
    bb=contract(M,S,key,count)
    equal=aa==bb
    print(key,count,len(aa),len(bb),'equal',equal,
          'keys shared',len(aa.keys()&bb.keys()),'elapsed',f'{time.monotonic()-start:.4f}',flush=True)
    if not equal:
        raise SystemExit(3)
print('All selected exact pair tensors equal.',flush=True)
