# Reproduce the paired heavy outer coordinate 47 review

Use the existing Git archive pins in SOURCE_PINS.txt. Restore the original separator archive for its generic contraction and quotient code, and the accepted paired-pilot archive for the original sum-branches script. Restore the exact author inputs from preserved restart evidence. paired-operands.sha256 and inner-operands.sha256 identify all factor operands and receipts. Source and input paths in the review scripts refer to the original shared scratch paths. Replace those prefixes with the corresponding verified restored paths on another host. Use a fresh directory for jobs that write files in exclusive mode.

1. Run `python3 pair-route-audit.py` to reconstruct the pair sum independently and check all 48 original coordinates for both branches. Run `bash combine-readback.sh` to replay the exact original constructor bytes. Run `bash pair-lineage.sh` to replay the four heavy reductions and cap/restarts byte for byte.
2. Run `python3 -u inner-lineage.py 0 1 4 5 6 2 3 7 8` for the nine cut inputs and every generic saved inner stage. Then `python3 combine-stage-timing.py` combines the stage timings.
3. Run `python3 replay.py` for the five sparse terminals. Run `python3 triangle.py 2` and `python3 triangle.py 3` for the alternate pivots. Run `python3 four.py 47 7 --pair 1 2` and `python3 four.py 47 8 --pair 1 2` for the alternate four-factor replays. Capture the output filenames used by report-timing.py.
4. Run `python3 audit.py` for exact cut and scalar checks and `python3 verify-shard-coverage.py` for independently counted author shard traffic. review-manifest.sha256 binds scripts and copied author receipts.

The terminal author sharded programs are evaluated by independent arithmetic and audited receipts rather than duplicated author execution. The generic stage replay validates the complete byte-reproducible prefix to the four frozen terminal inputs.
