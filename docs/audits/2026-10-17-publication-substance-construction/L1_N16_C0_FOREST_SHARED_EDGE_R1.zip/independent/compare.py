from ast import literal_eval
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import re
import sys
def split(path,sep=None):
    return [l.split(sep) for l in Path(path).read_text().splitlines()]
def exact_results(path):
    result={}
    for a,b,w,status,z in split(path):
        assert status=='EXACT'
        key=(int(a),int(b),int(w))
        assert key not in result
        result[key]=F(z)
    return result
def census():
    for group,a,b,w,edge,plan in split('census.tsv','\t'):
        yield group,(int(a),int(b),int(w)),literal_eval(edge),literal_eval(plan)
def parse_fraction_list(raw):
    return [F(x) if isinstance(x,str) else x for x in literal_eval(
        re.sub(r'Fraction\((-?\d+), (\d+)\)',r"'\1/\2'",raw))]
group=sys.argv[1]
assert group in ('forest','dual')
scope=[(key,e,p) for g,key,e,p in census() if g==group]
counts=Counter()
for key,edge,steps in scope:
    for side,e,p,load in steps:
        counts['steps']+=1
        if sum(load[side])==2:counts['own-side support']+=1
        else:
            assert sum(load[1-side])==2
            counts['opposite-side only support']+=1
        counts[p]+=1
folder=Path('frozen/chain')
p=folder/('forest-reduction.tsv' if group=='forest' else 'leaf-dual-roster.tsv')
if group=='forest':
    plans=[(tuple(map(int,(a,b,w))),literal_eval(steps))
           for a,b,w,steps in split(p,'\t')]
    assert plans==[(key,[(l,*e) for l,e,p,load in steps]) for key,edge,steps in scope]
    paths=['forest-0.out','forest-110.out']
else:
    plans=[(tuple(map(int,(a,b,w))),literal_eval(edge),literal_eval(steps))
           for a,b,w,steps,edge in split(p,'\t')]
    assert plans==[(key,edge,[(l,e,p,list(load)) for l,e,p,load in steps])
                   for key,edge,steps in scope]
    paths=['dual-replayed-0.out','dual-replayed-44.out']
ans=exact_results(folder/('forest-author-results.tsv' if group=='forest' else 'leaf-dual-author-results.tsv'))
assert list(ans)==[key for key,edge,steps in scope]
seen={}
params=[]
tiles=Counter()
all_parts=Counter()
nontrivial_delta=0
n_partitions=0
for path in paths:
    for line in Path(path).read_text().splitlines():
        fields=line.split()
        if fields[0]=='exact':
            key=tuple(map(int,fields[1:4]))
            z=F(fields[4]);fact=F(fields[6])
            parts=parse_fraction_list(line.split(' parts ',1)[1])
            assert len(parts)==(1 if group=='forest' else 4)
            assert z==fact*sum(parts)==ans[key]
            if group=='dual':
                for k,v in enumerate(parts):all_parts[k,bool(v)]+=1
                nontrivial_delta+=key[2]*fact*sum(parts[1:])
            assert key not in seen
            seen[key]=z
        elif fields[0]=='layer':
            params.append(tuple(int(fields[i]) for i in (5,7,10,13)))
            if 'tiles' in fields:tiles[int(fields[-1])]+=1
        elif fields[0]=='partition':
            n_partitions+=1
assert seen==ans
print(group,'size',len(seen),'weight',sum(k[2] for k in seen),'weighted subtotal',sum(k[2]*v for k,v in seen.items()))
print('signs',Counter((v>0)-(v<0) for v in seen.values()))
print('leaf elimination counts',counts)
print('maximum factor / join / site / initial',*[max(t) for t in zip(*params)])
print('partitions',n_partitions,'layer repeat counts per number of tiles',dict(tiles))
if group=='dual':print('nonzero channel counts',all_parts,'nontrivial weighted increment',nontrivial_delta)
Path(f'{group}-reviewed-exact.tsv').write_text(''.join('\t'.join(map(str,(*k,v)))+'\n' for k,v in seen.items()))
