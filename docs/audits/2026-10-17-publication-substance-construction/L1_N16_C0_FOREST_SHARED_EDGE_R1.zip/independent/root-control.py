from collections import defaultdict
from pathlib import Path
import os
import sys
root=Path.cwd()
sys.path.insert(0,str(root/'DUAL'))
os.chdir('DUAL')
from contract import decorations
os.chdir(root)
literal=defaultdict(dict)
for r in Path('independent-root.tsv').read_text().splitlines():
    a,b,c,d,k,i,j,re,im=map(int,r.split())
    if k:
        literal[k][(a,b),(c,d),i,j]=(re,im)
for k,d in enumerate((3,3,4),start=1):
    actual={}
    for p,left,right,(r,i) in decorations(k-1):
        a,b=divmod(p,d)
        key=tuple(sorted(left)),tuple(sorted(right)),a,b
        q,j=actual.get(key,(0,0))
        actual[key]=q+r,j+i
    actual={k:v for k,v in actual.items() if any(v)}
    assert actual==literal[k]
    print('channel',k,'exact root Fourier coefficients',len(actual))
