# Independent review of the 88 leaf-reduced shared-edge representatives

**ACCEPT** the 88 original representatives in `dual-reviewed-exact.tsv`.
All are positive. Their 7,872 original labels contribute the weighted
subtotal `221876343558594683542449/2199023255552`. Subtracting only these
88 leaves 10,015 temporal orbits and 863,547 labels. Subtracting both
cohorts reviewed at this checkpoint leaves **9,796 orbits and 844,551
labels**. Full original c0 sign, value and nonvanishing remain open.

## Independent selection and leaf exactness

The continuity check was fresh. The checkpoint `55d40453c` matched its
tracked upstream. Its archived residual equals the preceding independent
residual after removing just the accepted 265 chains. The frozen author
cohort manifests and the nested accepted dual-overlap archive manifest
verified. The reviewer extracted that prior archive to scratch and loaded
its frozen algebra and signed tensors.

The census starts from the complete exact residual, decodes the original
occupations, and reapplies the two-chirality representation constraints.
It peels one eligible leaf at a time while preserving every original
coframe load. A root edge cannot be peeled if the same geometric edge
is live in the other connector. No shared edge is removed, including
when one of its vertices is also a leaf of its own connector. Both
peeling orders leave the same core, and the canonical order reproduces
all 180 author removal steps. All 88 remaining cores consist of one
identical edge in each connector, with powers (2,2) on both and exactly
two single-owner coframes in each spatial layer. The cohort is disjoint
from the 219 fully scalar forests.

For a leaf x with neighbor y, the original closed words are
A† V_y† B V_x and C† V_x† G V_y. For a fixed equal channel imposed by
leaf Schur orthogonality, the normalized conditional trace is
`tr(X D(V_y)† D(B) D(G) D(V_y) Y)/d`, with X and Y retaining the
own-anchor matrices D(A†) and D(C†) and the two rooted coefficient
matrices. Thus the opposite B/G anchors also carry one matrix each.
They are distinct independent link variables even on L=2. The absence
of the geometric edge from the other live connector ensures that no
other active root attaches representation factors to the same anchors.
A peeled edge has only scalar factors, so this holds throughout the
induction.

On a spatial side with exactly two coframes, a split between the two
anchors is odd under the simultaneous sign reversal of both chiral
quaternions at either anchor. Every representation from an even root
power is even under that transformation. The split vanishes. Putting
both coframes on one anchor leaves the other anchor as a bare nontrivial
matrix, whose mean also vanishes. This argument applies to the opposite
B/G anchors just as it does to the own A/C anchors, keeping the shared
central temporal variable intact. In this particular cohort all 180
removals already have two own-side coframes. The opposite side has
two coframes in 72 steps and four in 108. No accepted coefficient
depends on an opposite-only elimination.

## Channels on the remaining shared edge

After peeling, each connector is one isolated double-root edge.
Normalized Schur integration over its two temporal endpoints supplies
d⁻². Its own spatial layer retains a two-root matrix trace, with
one daggered matrix at each original anchor. Its opposite spatial
layer retains the corresponding character of the product of the
two actual anchor matrices. The other connector supplies precisely
that character on the first connector's own spatial anchors, and
conversely.

On each spatial layer the split of two coframes again vanishes under
anchored center parity. For a concentrated load, the empty anchor
pairs the own daggered representation and the opposite character's
undaggered representation. The normalized Schur integral forces
the same channel on both connectors and supplies d⁻¹ on each spatial
layer. There are four temporal and two spatial normalized factors
in total, hence d⁻⁶ in dimensions 3, 3 and 4. The occupied anchor
is integrated with both original matrices and both coframes using
the accepted independent decorated tensors, including complex
coefficients and the scale 3,072. The two adjoint and product root
expansions agree with all 162, 162 and 360 Fourier coefficients
from the prior independent literal Haar projection.

The scalar channel has dimension one and each of the four remaining
quadratic roots contributes its explicit factor 2. It therefore
multiplies the product of the undecorated layers by 16. All other
projected roots retain their 2 or 10 scalar factors as appropriate,
and the original factorial denominators are kept for all roots,
including the four live quadratics.

## Signed replay and limits

Each coefficient is reconstructed on the original geometric labels
with the full local signed wedge and separate left and right
decorations. The reviewer does not infer these values from canonical
spatial relabeling or from chirality equality. Full complex
matrix structure is retained through the corresponding accepted
decorated site representation index and exact Gaussian arithmetic.
The value sums the scalar, both adjoints and the product fundamental
channel in exact rationals.

The reviewer checks join work and coefficient height prospectively
and guards the original site complement and sparse row operations.
When an uncanonicalized direct schedule proposes more than 2 million
products, the reviewer restricts the two factors sharing a chosen
edge endpoint state by one generator-mask bit. Every matched term
has a unique bit and belongs to exactly one of the two complementary
branches. The original coefficient, wedge, source labels and
normalization remain identical in either branch. Additional
partitions apply the same argument to another unassigned bit and
sum all leaves exactly. These are bounded independent replays of
the original contractions. No refused arithmetic schedule is
executed beyond its cap.

All 88 independent values match the frozen author table. In 324 layer
evaluations across the two scratch shards, 310 execute as one guarded
contraction, six admit two tiles, and eight admit four tiles. The largest
admitted matched-product count is 1,923,072. Maximum factor rows, initial
resident rows, and site trials are respectively 64,512, 33,996 and
19,968. All prospective resources fit the chosen 150,000-row, 2-million
matched product and 384-bit caps.

Both adjoint contributions are nonzero in each case. Every complete
left × right fundamental contribution vanishes after signed sewing.
This statement concerns those complete products and does not imply a
zero decorated tensor or cancellation for other occupations. The exact
orbit-weighted increment from the two nontrivial adjoints is
`4227101746243873641/2199023255552`. Therefore the shared-edge cohort
cannot be evaluated by an all-scalar shortcut. The two accepted cohorts'
combined subtotal is `227954865061128808937738439/562949953421312`.
No repository, manuscript or Lean state changed.

## Scratch replay

The scratch directory uses the independent projection scripts at
`INDEPENDENT`, the frozen author input at `frozen`, the prior literal
Fourier export at `independent-root.tsv`, and the accepted dual-overlap
archive extracted as `DUAL`. The clean checkpoint archive
`L1_N16_C0_TWO_EDGE_CHAIN_R1.zip` supplies `block-remaining.tsv` at
`current-residual.tsv`. The previously reviewed chain assertions bind
that residual to `before-chain-residual.tsv` and `accepted-chain.tsv`.

```sh
(cd DUAL && shasum -a 256 -c manifest.sha256) > dual-manifest.out
PYTHONDONTWRITEBYTECODE=1 python3 root-control.py > root-control.out
PYTHONDONTWRITEBYTECODE=1 python3 cohorts.py census > census.tsv
PYTHONDONTWRITEBYTECODE=1 python3 cohorts.py opposite-control > opposite-control.out
PYTHONDONTWRITEBYTECODE=1 python3 cohorts.py forest 0 110 > forest-0.out
PYTHONDONTWRITEBYTECODE=1 python3 cohorts.py forest 110 219 > forest-110.out
PYTHONDONTWRITEBYTECODE=1 python3 cohorts.py dual 0 44 > dual-replayed-0.out
PYTHONDONTWRITEBYTECODE=1 python3 cohorts.py dual 44 88 > dual-replayed-44.out
python3 compare.py forest > forest-comparison.out
python3 compare.py dual > dual-comparison.out
shasum -a 256 -c manifest.sha256
```

The forest logs in this receipt were produced before adding the unused
partition fallback. Their exact rows and resource observations are
preserved. Replaying with the final script also prints `tiles 1` on
each forest layer line. The fallback remains unused for that cohort.
