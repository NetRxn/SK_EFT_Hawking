# Independent scalar forest review

**ACCEPT** the 219 original scalar forest coefficients in
`forest-reviewed-exact.tsv`. All are positive. The 18,996 original
labels add the weighted subtotal
`171154521110128569950871495/562949953421312`. Subtracting this cohort
alone from the pinned residual leaves 9,884 orbits and 852,423 labels.

The continuity check was fresh. The published checkpoint `55d40453c`
matched its tracked upstream. I extracted its exact residual and
verified that it equals the previous independent residual after
removing exactly the 265 accepted two-edge chains. The two author
cohort manifests and their nested inputs verified.

The independent census redid the original occupation decoding and
two-chirality support projection. Candidate forests have no shared
live edge between their two connector graphs. Every live edge has
the original paired powers (2,2) and two single-owner coframes on
its own spatial edge. Both leaf-order directions remove all edges,
and the canonical order reproduces all 880 frozen reduction steps.
Components of more than two edges and cases with both connector
graphs nonempty are included. The resulting roster is disjoint from
the separately reviewed shared-edge cohort.

At each leaf, the closed plaquette words pair the outgoing temporal
matrix and its dagger from the other root. Haar orthogonality forces
one common representation and contracts the shared leaf once. The
result still contains exactly one matrix of that representation at
each of the two distinct own-side anchors. Any nontrivial channel
has even parity under the simultaneous sign reversal of the two
chiral quaternions at either anchor. A split of the two coframes
oddly across the anchors therefore integrates to zero. A concentrated
load leaves an isolated bare nontrivial matrix at the other anchor,
whose normalized Haar mean is zero. A different active axis at the
same vertex has different spatial anchors. No active root in the
other connector can contribute an extra factor to those anchors
because the eliminated spatial edge is unshared. Thus removing the
two scalar roots leaves the temporal variables in the other roots
and leaves their original local coframes unchanged. Induction
eliminates all represented edges without requiring independent
integrals on a shared temporal variable.

The signed replay uses the independently accepted exact scalar
Gram components, moments with original edge denominator 64 or 12,288,
and full site wedge inversions. Each original quadratic contributes
2 and each quartic contributes 10 with its original factorial
still in the denominator. The 219 exact values all match the frozen
author table, without refusals. Reviewer prospective maxima are
64,512 factor rows, 1,114,112 matched joins, 7,680 site trials and
33,696 initial factor rows. Planned joins, closing work and integer
height are checked before multiplication.

The full original c0 sign, value and nonvanishing remain open.
No repository, manuscript or Lean state changed.
