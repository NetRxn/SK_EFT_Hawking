import ast,os,sys,inspect
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations_with_replacement,product
from math import factorial,prod
from pathlib import Path

sys.path.insert(0,str(Path("DUAL").absolute()))
scratch=Path.cwd()
os.chdir("DUAL")
from contract import same,mixed,integrate,final_three,occupancy,profile,local,enc,inv,decorated
D={(o,c):decorated(o,c) for o,c in product(range(2),range(3))}
source=ast.parse((scratch/"INDEPENDENT"/"project.py").read_text())
source.body=[node for node in source.body if isinstance(node,(ast.FunctionDef,ast.Import,ast.ImportFrom))]
exec(compile(source,"project.py","exec"))
os.chdir(scratch)

def read(path):
    return (tuple(map(int,row.split())) for row in Path(path).open())
def plus(a,b):return a[0]+b[0],a[1]+b[1]
def times(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def conj(a):return a[0],-a[1]
# Preserve the independent join schedule while checking the batch's tighter
# declared resource caps at the points where it launches arithmetic.
def tighten(text, pairs):
    for before,after in pairs:
        assert text.count(before)==1, before
        text=text.replace(before,after)
    return text

class Refusal(RuntimeError):
    pass
def guard(condition,resource):
    if not condition:
        raise Refusal(resource)
env=dict(integrate.__globals__)
env['guard']=guard
exec(tighten(inspect.getsource(final_three),[
    ('    choices=[]','    guard(sum(len(t) for _,t in fs)<=150000, ("closing resident rows",sum(len(t) for _,t in fs)))\n    choices=[]'),
    ('    assert cost<=8_000_000','    guard(cost<=2_000_000, ("closing products",cost))\n    height=sum(max((max(abs(x),abs(y)).bit_length()+1 for x,y in t.values()),default=0) for _,t in fs)\n    guard(height+cost.bit_length()<=384, "closing height")')
]),env)
exec(tighten(inspect.getsource(integrate),[
    ('        assert n<=5_000_000,(A,B,n)','        guard(n<=2_000_000, ("join products",n))\n        height=sum(max((max(abs(x),abs(y)).bit_length()+1 for x,y in t.values()),default=0) for t in (X,Y))\n        guard(height+n.bit_length()<=384, "join height")'),
    ('                collect(out,k,mul(z,w))','                guard(k in out or len(out)<150000, "join rows")\n                collect(out,k,mul(z,w))'),
    ('        assert peak<300_000','        guard(peak<=150_000, ("factor rows",peak))')
]),env)
integrate=env['integrate']
widths=(1,3,3,4)
def peel(graphs,loads,own_only=False,reverse=False):
    graphs=[dict(G) for G in graphs]
    steps=[]
    while True:
        choices=[]
        for layer,G in enumerate(graphs):
            deg=Counter(x for a,b,k in G for x in (a,b))
            for e,n in G.items():
                a,b,k=e
                if e in graphs[1-layer]:continue
                if not (deg[a]==1 or deg[b]==1):continue
                if own_only and n!=(2,2):continue
                if any(p not in (2,4) for p in n):continue
                load=tuple(loads[t].get(e,(0,0)) for t in range(2))
                if own_only and sorted(load[layer])!=[0,2]:continue
                if min(map(sum,load))!=2:continue
                choices.append((layer,e,n,load))
        if not choices:return steps,graphs
        layer,edge,powers,load=max(choices) if reverse else min(choices)
        assert edge not in graphs[1-layer]
        del graphs[layer][edge]
        steps.append((layer,edge,powers,load))

def classify(rows):
    for a,b,w in rows:
        codes=(a,b)
        if any(n%2 for code in codes for site in occupancy(code) for n in site):
            continue
        G,_,_=projection(*codes,2)
        if not any(G):continue
        loads=[profile(code)[2] for code in codes]
        if not (G[0].keys() & G[1].keys()):
            steps,remain=peel(G,loads,True)
            if not any(remain):
                assert steps
                assert not any(peel(G,loads,True,True)[1])
                yield 'forest',(a,b,w),steps,None
                continue
        steps,remain=peel(G,loads)
        if not steps:continue
        assert remain==peel(G,loads,False,True)[1]
        if len(remain[0])!=1 or remain[0]!=remain[1]:continue
        edge,=remain[0]
        if remain[0][edge]!=(2,2):continue
        if any(sorted(loads[s].get(edge,()))!=[0,2] for s in range(2)):continue
        yield 'dual',(a,b,w),steps,edge

def factors(code,decor):
    occ=occupancy(code);edges=profile(code)[2]
    incident=defaultdict(list)
    factors=[]
    den=1
    affected={}
    for edge,(a,b) in sorted(edges.items()):
        u,v,axis=edge
        d=a+b
        if decor and edge==decor[0]:
            channel=decor[1]
            assert d==2 and min(a,b)==0
            data=D[int(bool(b)),channel]
            affected[u]=affected[v]=(channel,axis)
            den*=3072
        elif a and b:
            assert (a,b)==(2,2)
            data=mixed
        else:
            data=same[d] if a else {(y,x):z for (x,y),z in same[d].items()}
        if not decor or edge!=decor[0]:den*=64 if d==2 else 12288
        wires=((u,v,0),(u,v,1))
        guard(sum(len(t) for _,t in factors)+len(data)<=150000, ('initial edge rows',code,u,v))
        factors.append((wires,data))
        for x,wire in zip((u,v),wires):
            slot=(0 if u==x else 1)
            avail=defaultdict(set)
            for row in data:
                w,m,i=row[slot]
                assert m.bit_count()==d
                avail[w,i].add(m)
            incident[x].append((wire,axis,avail,bool(decor and edge==decor[0])))
    max_site_work=0
    for x,row in enumerate(occ):
        choices=[]
        for (spin,words),z in local(row,*affected.get(x,(-1,-1))).items():
            choices.append((tuple(map(enc,words)),z,spin))
        table={}
        plans=[]
        for words,z,spin in choices:
            labels=[(words[a],spin if special else 0) for _,a,_,special in incident[x]]
            groups=[D.get(s,()) for (_,_,D,_),s in zip(incident[x],labels)]
            if not all(groups):continue
            order=sorted(range(len(groups)),key=lambda i:len(groups[i]))
            plans.append((groups,order,labels,z))
        work=sum(prod(len(groups[i]) for i in order[:-1]) for groups,order,_,_ in plans)
        guard(work<=2_000_000, ('site complement work',work))
        max_site_work=max(max_site_work,work)
        for groups,order,labels,z in plans:
            for prefix in product(*(groups[i] for i in order[:-1])):
                mask=0
                for a in prefix:
                    if mask&a:break
                    mask|=a
                else:
                    complement=255^mask
                    if complement not in groups[order[-1]]:continue
                    masks=dict(zip(order,(*prefix,complement)))
                    ordered=list(map(masks.__getitem__,range(len(masks))))
                    exponent=sum(inv(a,b) for i,a in enumerate(ordered) for b in ordered[i+1:])
                    signed=z if exponent%2==0 else (-z[0],-z[1])
                    key=tuple((w,m,i) for (w,i),m in zip(labels,ordered))
                    table[key]=plus(table.get(key,(0,0)),signed)
                    guard(len(table)<=150000, ('site factor rows',len(table)))
        factors.append((tuple(wire for wire,_,_,_ in incident[x]),{k:v for k,v in table.items() if any(v)}))
    guard(sum(len(t) for _,t in factors)<=150000, ('initial resident rows',sum(len(t) for _,t in factors)))
    return factors,den,max_site_work

def integrate_partitioned(network,reverse,cut=()):
    try:
        z,peak,work=integrate(network,reverse)
        return z,peak,work,1
    except Refusal as reason:
        options=[]
        for i,(scope,A) in enumerate(network):
            for j,(other,B) in enumerate(network):
                if j<=i:continue
                for v in set(scope)&set(other):
                    a,b=scope.index(v),other.index(v)
                    for bit in range(8):
                        if (v,bit) in cut:continue
                        aa=sum(k[a][1]>>bit&1 for k in A)
                        bb=sum(k[b][1]>>bit&1 for k in B)
                        score=min(aa,len(A)-aa)*min(bb,len(B)-bb)
                        if score:options.append((score,v,bit,i,j,a,b))
        if not options:raise
        _,v,bit,i,j,a,b=max(options)
        print('partition',cut,'because',reason,'wire',v,'mask bit',bit,flush=True)
        halves=[]
        for choice in (0,1):
            fs=network.copy()
            for pos,index in ((i,a),(j,b)):
                scope,table=fs[pos]
                fs[pos]=(scope,{k:z for k,z in table.items() if (k[index][1]>>bit&1)==choice})
            halves.append(integrate_partitioned(fs,reverse,(*cut,(v,bit))))
        z=plus(halves[0][0],halves[1][0])
        return z,max(row[1] for row in halves),max(row[2] for row in halves),sum(row[3] for row in halves)

@cache
def value(code,decor,reverse):
    network,den,sites=factors(code,decor)
    val,peak,work,tiles=integrate_partitioned(network,reverse)
    assert val[1]==0
    print('layer',code,'denominator',den,'peak',peak,'work',work,'site work',sites,
          'initial resident',sum(len(t) for _,t in network),'value',F(val[0],den),'decor',decor,'tiles',tiles,flush=True)
    return F(val[0],den)

def run(group,rows,start,stop,reverse):
    for index,(_, (a,b,w),steps,edge) in enumerate(rows):
        if not start<=index<stop:continue
        print('case',a,b,w,repr(edge),repr(steps),flush=True)
        powers=occupancy(a)+occupancy(b)
        base=value(a,None,reverse)*value(b,None,reverse)
        if edge:
            u,v,k=edge
            labels={(u,k),(v,k),(u+8,k),(v+8,k)}
            assert all(powers[x][ax]==2 for x,ax in labels)
        else:labels=set()
        factor=F(prod({0:1,2:2,4:10}[n] for x,row in enumerate(powers) for ax,n in enumerate(row)
                      if (x,ax) not in labels),prod(factorial(n) for row in powers for n in row))
        if group=='forest':
            z=factor*base
            parts=[base]
        else:
            parts=[16*base]
            for c,d in enumerate((3,3,4)):
                left=value(a,(edge,c),reverse);right=value(b,(edge,c),reverse)
                parts.append(left*right/d**6)
            z=factor*sum(parts)
        print('exact',a,b,w,z,'factor',factor,'parts',parts,flush=True)

def roster(path):
    return [tuple(map(int,row.split()[:3])) for row in Path(path).read_text().splitlines()]
res=roster('current-residual.tsv')
previous=roster('before-chain-residual.tsv')
prior=set(roster('accepted-chain.tsv'))
assert len(prior)==265 and [r for r in previous if r not in prior]==res
assert len(res)==10103 and sum(r[2] for r in res)==871419
cases=list(classify(res))
forest=[r for r in cases if r[0]=='forest']
dual=[r for r in cases if r[0]=='dual']
assert len(forest)==219 and sum(r[1][2] for r in forest)==18996
assert len(dual)==88 and sum(r[1][2] for r in dual)==7872
assert not ({r[1] for r in forest}&{r[1] for r in dual})
if sys.argv[1:]==['opposite-control']:
    from ast import literal_eval
    expected = set(r[1] for r in forest) | set(r[1] for r in dual)
    selected = []
    for a,b,w in res:
        if (a,b,w) in expected:continue
        if any(n%2 for code in (a,b) for row in occupancy(code) for n in row):continue
        graphs,_,_ = projection(a,b,2)
        loads=[profile(code)[2] for code in (a,b)]
        steps,remaining=peel(graphs,loads)
        for side,edge,powers,load in steps:
            if sum(load[side])!=2 and sum(load[1-side])==2:
                selected.append(((a,b,w),side,edge,powers,load))
    print('opposite-only legal removals outside admitted cohorts',len(selected),'profiles',len({r[0] for r in selected}))
    for row in selected[:3]:print(row)
    sys.exit()
if sys.argv[1:]==['census']:
    for group, r in (('forest',forest),('dual',dual)):
        for _,keys,steps,edge in r:print(group,*keys,repr(edge),repr(steps),sep='\t')
    sys.exit()
group=sys.argv[1]
rows=forest if group=='forest' else dual
run(group,rows,int(sys.argv[2]),int(sys.argv[3]),'reverse' in sys.argv)
