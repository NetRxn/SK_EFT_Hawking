from collections import Counter
from pathlib import Path

p=Path('family-intake/residual_shapes.py')
s={'__file__':str(p.resolve())}
exec(p.read_text().split('\nrows=',1)[0],s)
projection,occupancy=(s[k] for k in ("projection","occupancy"))
profile=s['module']['profile']

folder=Path("chain")
rows=[tuple(map(int,line.split())) for line in (folder/"current-residual.tsv").read_text().splitlines()]
prior={tuple(map(int,line.split()[:2]))
       for file in ("author-results.tsv","forest-author-results.tsv") for line in (folder/file).read_text().splitlines()}
assert (len(rows),sum(w for a,b,w in rows),len(prior))==(10368,895995,484)

census=Counter()
examples={}
finished=[]
partially=[]
for a,b,w in rows:
    if (a,b) in prior:
        continue
    if any(n%2 for row in occupancy(a)+occupancy(b) for n in row):
        continue
    full=projection(a,b,2)
    assert full is not None
    a_core,b_core=full[0]
    work=[dict(a_core),dict(b_core)]
    load=[profile(code)[2] for code in (a,b)]
    audit=[]
    while any(work):
        admitted=None
        for side,g in enumerate(work):
            degree=Counter(v for edge in g for v in edge[:2])
            for e in sorted(g):
                # Both root powers must be even and positive for the common
                # leaf representation and inversion arguments used here.
                if e in work[1-side] or min(degree[e[0]],degree[e[1]])!=1:
                    continue
                if any(n not in (2,4) for n in g[e]):
                    continue
                if min(sum(load[0].get(e,())),sum(load[1].get(e,())))!=2:
                    continue
                admitted=side,e
                break
            if admitted is not None:
                break
        if admitted is None:
            break
        side,e=admitted
        audit.append((side,e,work[side].pop(e),[load[i].get(e,()) for i in range(2)]))
    if audit:
        shape=tuple(sorted(map(len,work)))
        census[shape]+=w
        examples.setdefault(shape,[0,(a,b,w)])[0]+=1
        if not any(work):
            finished.append((a,b,w,audit))
        else:
            partially.append((a,b,w,audit,work))
for shape,n in census.most_common(12):
    print(shape,n,*examples[shape])
print("entirely reduced",len(finished),sum(w for a,b,w,audit in finished))
print("partially reduced",len(partially),sum(w for a,b,w,audit,shape in partially))
(folder/'leaf-extended-roster.tsv').write_text(''.join(f'{a}\t{b}\t{w}\t{audit!r}\n' for a,b,w,audit in finished))

eligible=[]
for a,b,w,audit,work in partially:
    if [len(g) for g in work]!=[1,1] or work[0].keys()!=work[1].keys():
        continue
    edge,=work[0]
    if work[0][edge]!=(2,2) or work[1][edge]!=(2,2):
        continue
    if any(sum(profile(x)[2].get(edge,()))!=2 for x in (a,b)):
        continue
    eligible.append((a,b,w,audit,edge))
print("dual-overlap table eligible",len(eligible),sum(row[2] for row in eligible))
(folder/'leaf-dual-roster.tsv').write_text(''.join(f'{a}\t{b}\t{w}\t{audit!r}\t{edge!r}\n' for a,b,w,audit,edge in eligible))
