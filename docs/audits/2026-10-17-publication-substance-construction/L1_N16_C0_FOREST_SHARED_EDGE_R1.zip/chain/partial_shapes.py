from collections import Counter
from pathlib import Path

scope={}
exec(Path("chain/leaf_scope.py").read_text().split("\nfor shape,n in census.most_common",1)[0],scope)
profile=scope["profile"]
counts=Counter()
samples={}
ids={}
for a,b,w,audit,graphs in scope["partially"]:
    if any(len(g)!=1 for g in graphs):
        continue
    edges=tuple(next(iter(g)) for g in graphs)
    equal=edges[0]==edges[1]
    profile_by_layer=[profile(c)[2] for c in (a,b)]
    signature=tuple(sorted((tuple(sorted(g[e])),tuple(sorted(profile_by_layer[t].get(e,()))))
                                    for t,(g,e) in enumerate(zip(graphs,edges))))
    key=(equal,signature)
    counts[key]+=w
    samples.setdefault(key,[]).append((a,b,w,edges))
for key,weight in counts.most_common():
    print(len(samples[key]),weight,samples[key][0],key)
