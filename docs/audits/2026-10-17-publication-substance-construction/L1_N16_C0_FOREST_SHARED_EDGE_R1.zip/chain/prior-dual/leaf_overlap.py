from ast import literal_eval
from collections import Counter
from contextlib import redirect_stdout
from fractions import Fraction as F
from functools import cache
from itertools import permutations,product
from math import factorial,prod
from pathlib import Path
from census import occupancy,profile,triples
from contract import value

source=Path("batch.py").read_text()
exec(source[source.index("@cache\ndef decorated_key"):source.index("\ndef terms(")])

def weight(a,b,edge):
    powers=occupancy(a)+occupancy(b)
    u,v,axis=edge
    live={(x,axis) for x in (u,v,8+u,8+v)}
    assert all(powers[x][k] in (2,4) for x,k in live)
    outside=prod({0:1,2:2,4:10}[n] for x,row in enumerate(powers)
                 for k,n in enumerate(row) if (x,k) not in live)
    return F(outside,prod(factorial(n) for row in powers for n in row))

@cache
def evaluate(key):
    return value(*key)

coeff_source=Path("classify.py").read_text()
exec(coeff_source[coeff_source.index("L=("):coeff_source.index("@cache\ndef canonical")])

def route(a,b,edge,powers,loads):
    factors=Counter()
    base=tuple(sorted((decorated_key(a,()),decorated_key(b,()))))
    occupied=[i for i,l in enumerate(loads) if any(l)]
    constant=prod(coeff(n,0,0) for pair in powers for n in pair)
    if not occupied:
        factors[base]+=sum(prod(coeff(n,i,j) for pair in powers for n in pair)
            / F(((2*i+1)*(2*j+1))**4) for i,j in product(range(3),repeat=2))
        return factors
    side,=occupied
    factors[base]+=constant
    x,y=edge[:2]
    for k in range(2):
        setting=(((x,y),k),)
        args=(setting,()) if side==0 else ((),setting)
        pair=tuple(sorted((decorated_key(a,args[0]),decorated_key(b,args[1]))))
        factors[pair]+=prod(3*coeff(n,1,0) for n in powers[1-side])/3**7
    return factors

rows=[]
for line in Path("../leaf-overlap-one-or-zero-roster.tsv").read_text().splitlines():
    a,b,w,steps,edge,powers,loads=line.split("\t")
    a,b,w=map(int,(a,b,w))
    steps,edge,powers,loads=map(literal_eval,(steps,edge,powers,loads))
    assert steps and all(profile(c)[2].get(edge,(0,0))==l for c,l in zip((a,b),loads))
    rows.append((a,b,w,edge,powers,loads))
assert len(rows)==152
with Path("../leaf-overlap-one-or-zero-contractions.out").open("w") as details, \
     Path("../leaf-overlap-one-or-zero-author.tsv").open("w") as out:
    for a,b,w,edge,powers,loads in rows:
        plan=route(a,b,edge,powers,loads)
        try:
            with redirect_stdout(details):
                z=weight(a,b,edge)*sum(c*evaluate(x)*evaluate(y) for (x,y),c in plan.items())
            status="EXACT"
        except RuntimeError as exc:
            if "cap" not in str(exc):
                raise
            status,z="REFUSED",str(exc)
        print(a,b,w,status,z,sep="\t",file=out,flush=True)
print("shared-edge author replay",len(rows),evaluate.cache_info())
