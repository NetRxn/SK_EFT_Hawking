from ast import literal_eval
from collections import Counter
from contextlib import redirect_stdout
from fractions import Fraction as F
from functools import cache
from itertools import permutations
from math import factorial,prod
from pathlib import Path
from census import occupancy,profile,triples
from contract import value

source=Path("batch.py").read_text()
exec(source[source.index("@cache\ndef decorated_key"):source.index("\ndef terms(")])

def weight(a,b,edge):
    powers=occupancy(a)+occupancy(b)
    u,v,axis=edge
    live={(x,axis) for x in (u,v,8+u,8+v)}
    assert all(powers[x][k]==2 for x,k in live)
    outside=prod({0:1,2:2,4:10}[n] for x,row in enumerate(powers)
                 for k,n in enumerate(row) if (x,k) not in live)
    return F(outside,prod(factorial(n) for row in powers for n in row))

@cache
def evaluate(key):
    return value(*key)

def route(a,b,edge):
    factors=Counter()
    base=tuple(sorted((decorated_key(a,()),decorated_key(b,()))))
    factors[base]+=16
    x,y=edge[:2]
    for k,d in enumerate((3,3,4)):
        setting=(((x,y),k),)
        pair=tuple(sorted((decorated_key(a,setting),decorated_key(b,setting))))
        factors[pair]+=F(1,d**6)
    return factors

rows=[]
for line in Path("../leaf-dual-roster.tsv").read_text().splitlines():
    a,b,w,steps,edge=line.split("\t")
    a,b,w=map(int,(a,b,w))
    steps=literal_eval(steps)
    edge=literal_eval(edge)
    assert steps and all(profile(c)[2][edge] in ((2,0),(0,2)) for c in (a,b))
    rows.append((a,b,w,edge))
assert len(rows)==88 and sum(row[2] for row in rows)==7872
with Path("../leaf-dual-contractions.out").open("w") as details, \
     Path("../leaf-dual-author-results.tsv").open("w") as out:
    for a,b,w,edge in rows:
        plan=route(a,b,edge)
        try:
            with redirect_stdout(details):
                z=weight(a,b,edge)*sum(c*evaluate(x)*evaluate(y) for (x,y),c in plan.items())
            status="EXACT"
        except RuntimeError as exc:
            if "cap" not in str(exc):
                raise
            status,z="REFUSED",str(exc)
        print(a,b,w,status,z,sep="\t",file=out,flush=True)
print("shared-edge author replay",len(rows),evaluate.cache_info())
