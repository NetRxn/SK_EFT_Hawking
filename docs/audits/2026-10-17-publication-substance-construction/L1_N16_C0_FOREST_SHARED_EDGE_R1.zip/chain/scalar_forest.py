from collections import Counter
from contextlib import redirect_stdout
from pathlib import Path

# Reuse arithmetic only. The chain and forest have separate frozen ledgers.
source=Path('chain/scalar_chain.py').read_text().split("\nfrom contextlib import redirect_stdout",1)[0]
scope={"__file__":str(Path("chain/scalar_chain.py").resolve())}
exec(source,scope)
decode,scalar_layer=(scope[key] for key in ('decode','scalar_layer'))
F,prod,factorial=(scope[key] for key in ('F','prod','factorial'))
p=Path('family-intake/residual_shapes.py')
ctx={'__file__':str(p.resolve())}
exec(p.read_text().split('\nrows=',1)[0],ctx)
projection,profile=ctx['projection'],ctx['module']['profile']

folder=Path('chain')
roster=[tuple(map(int,line.split('\t')[:3])) for line in (folder/'forest-census.tsv').read_text().splitlines()]
residual={(a,b):w for a,b,w in (tuple(map(int,line.split())) for line in (folder/'current-residual.tsv').read_text().splitlines())}
chains={tuple(map(int,line.split()[:2])) for line in (folder/'author-results.tsv').read_text().splitlines()}
assert len(roster)==219 and sum(w for a,b,w in roster)==18996
assert len({(a,b) for a,b,w in roster})==219
plans={}
for a,b,w in roster:
    assert residual[a,b]==w and (a,b) not in chains
    gs=projection(a,b,2)[0]
    assert not (gs[0].keys() & gs[1].keys())
    plan=[]
    for t,graph in enumerate(gs):
        active=dict(graph)
        local=profile((a,b)[t])[2]
        while active:
            deg=Counter(v for e in active for v in e[:2])
            e=next((e for e in sorted(active) if min(deg[e[0]],deg[e[1]])==1),None)
            assert e is not None,(a,b,t,active)
            assert active.pop(e)==(2,2)
            assert sorted(local[e])==[0,2]
            plan.append((t,*e))
    plans[a,b]=plan

with (folder/'forest-reduction.tsv').open('w') as reductions, \
     (folder/'forest-contractions.out').open('w') as details, \
     (folder/'forest-author-results.tsv').open('w') as results:
    for a,b,w in roster:
        print(a,b,w,repr(plans[a,b]),sep='\t',file=reductions)
        powers=[n for row in decode(a)+decode(b) for n in row]
        assert all(n%2==0 for n in powers)
        multiplier=F(prod({0:1,2:2,4:10}[n] for n in powers),prod(factorial(n) for n in powers))
        try:
            with redirect_stdout(details):
                value=multiplier*scalar_layer(a)*scalar_layer(b)
            status='EXACT'
        except RuntimeError as exc:
            if 'cap' not in str(exc):
                raise
            status,value='REFUSED',str(exc)
        print(a,b,w,status,value,sep='\t',file=results,flush=True)
print("forest replay",len(roster),scalar_layer.cache_info())
