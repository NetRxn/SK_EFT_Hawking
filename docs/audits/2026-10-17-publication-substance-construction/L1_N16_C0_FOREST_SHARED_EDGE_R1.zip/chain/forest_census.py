from collections import Counter
from pathlib import Path

p=Path('family-intake/residual_shapes.py')
s={'__file__':str(p.resolve())}
exec(p.read_text().split('\nrows=',1)[0],s)
projection,components,occupancy=(s[k] for k in ("projection","components","occupancy"))
profile=s['module']['profile']
rows=[tuple(map(int,line.split())) for line in Path("chain/current-residual.tsv").read_text().splitlines()]
assert (len(rows),sum(w for a,b,w in rows))==(10368,895995)
found=[]
stats=Counter()
for a,b,w in rows:
    if any(n%2 for row in occupancy(a)+occupancy(b) for n in row):
        continue
    graphs=projection(a,b,2)[0]
    if graphs[0].keys() & graphs[1].keys():
        continue
    admissible=True
    signature=[]
    for i,g in enumerate(graphs):
        local=profile((a,b)[i])[2]
        if any(pair!=(2,2) or sorted(local.get(edge,()))!=[0,2] for edge,pair in g.items()):
            admissible=False
            break
        sizes=[]
        for component in components(g):
            vertices={x for edge in component for x in edge[:2]}
            if len(component)!=len(vertices)-1:
                admissible=False
                break
            sizes.append(len(component))
        signature.append(tuple(sorted(sizes)))
        if not admissible:
            break
    if admissible and any(graphs):
        signature=tuple(sorted(signature))
        found.append((a,b,w,signature))
        stats[signature]+=w
chains={tuple(map(int,line.split()[:2])) for line in Path('chain/author-results.tsv').read_text().splitlines()}
assert sum((a,b) in chains for a,b,w,sig in found)==265
print("forest criterion",len(found),"representatives",sum(w for a,b,w,sig in found),"labels")
new=[(a,b,w,sig) for a,b,w,sig in found if (a,b) not in chains]
print("additional",len(new),"representatives",sum(w for a,b,w,sig in new),"labels")
for k,w in stats.most_common(12):
    print(k,sum(sig==k for a,b,z,sig in found),w)
Path('chain/forest-census.tsv').write_text(''.join(f'{a}\t{b}\t{w}\t{sig}\n' for a,b,w,sig in new))
