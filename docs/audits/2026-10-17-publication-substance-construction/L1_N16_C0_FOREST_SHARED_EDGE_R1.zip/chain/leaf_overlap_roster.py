from pathlib import Path

text=Path("chain/partial_shapes.py").read_text().split("\nfor key,weight in counts.most_common",1)[0]
exec(text)
base={(int(a),int(b)) for a,b in (line.split()[:2] for line in Path("chain/leaf-dual-roster.tsv").read_text().splitlines())}
chosen=[]
for a,b,w,audit,graphs in scope["partially"]:
    if (a,b) in base or [len(g) for g in graphs]!=[1,1] or graphs[0].keys()!=graphs[1].keys():
        continue
    edge,=graphs[0]
    powers=tuple(g[edge] for g in graphs)
    loads=tuple(profile(code)[2].get(edge,(0,0)) for code in (a,b))
    if any(n not in (2,4) for pair in powers for n in pair):
        continue
    occupied=[i for i,load in enumerate(loads) if any(load)]
    if len(occupied)>1 or any(tuple(sorted(loads[i]))!=(0,2) or powers[i]!=(2,2) for i in occupied):
        continue
    chosen.append((a,b,w,audit,edge,powers,loads))
assert (len(chosen),sum(r[2] for r in chosen))==(152,13632)
out=''.join(f'{a}\t{b}\t{w}\t{audit!r}\t{edge!r}\t{powers!r}\t{loads!r}\n'
            for a,b,w,audit,edge,powers,loads in chosen)
assert out==Path("chain/leaf-overlap-one-or-zero-roster.tsv").read_text()
print("152 representative rows and weights replayed")
