# L1 forest and shared-edge evidence

Only the two independently reviewed exact tables are removed from the frozen
base. The 152 one-or-zero occupied shared-edge author rows remain in the
residual pending independent review.

From the archive root, check the author manifests in chain/ and run:

```sh
python3 check_residual.py independent/forest-reviewed-exact.tsv independent/dual-reviewed-exact.tsv
```

Restore chain/current-residual.tsv, chain/author-results.tsv,
chain/scalar_chain.py, and family-intake/ from the sibling
L1_N16_C0_TWO_EDGE_CHAIN_R1.zip. For author replay, restore the directed-square
pilot's nested author inputs as directed in that archive's REPRODUCE.md.
Extract chain/prior-dual.zip into chain/prior-dual/ alongside leaf_dual.py and
leaf_overlap.py. Run chain/forest_census.py, chain/scalar_forest.py and
chain/leaf_scope.py from this root. Run leaf_dual.py and leaf_overlap.py
from chain/prior-dual/. Preserve the frozen outputs for comparison.

For independent replay, enter independent/, link frozen to .., link
INDEPENDENT to the restored independent author input directory containing
project.py, and extract ../chain/prior-dual.zip into DUAL/. Verify
manifest.sha256 and follow SHARED_EDGE_REVIEW.md. Log formatting in a new
forest replay differs as explained by the reviewer. Compare exact tables
and census against the frozen originals.
