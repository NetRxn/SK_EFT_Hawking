import ast,os,sys,inspect
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations_with_replacement,product
from math import factorial,prod
from pathlib import Path

sys.path.insert(0,str(Path("DUAL").absolute()))
scratch=Path.cwd()
os.chdir("DUAL")
from contract import same,mixed,integrate,final_three,occupancy,profile,local,enc,inv,decorated
D={(o,c):decorated(o,c) for o,c in product(range(2),range(3))}
source=ast.parse((scratch/"INDEPENDENT"/"project.py").read_text())
source.body=[node for node in source.body if isinstance(node,(ast.FunctionDef,ast.Import,ast.ImportFrom))]
exec(compile(source,"project.py","exec"))
os.chdir(scratch)

def read(path):
    return (tuple(map(int,row.split())) for row in Path(path).open())
def plus(a,b):return a[0]+b[0],a[1]+b[1]
def times(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def conj(a):return a[0],-a[1]
# Preserve the independent join schedule while checking the batch's tighter
# declared resource caps at the points where it launches arithmetic.
def tighten(text, pairs):
    for before,after in pairs:
        assert text.count(before)==1, before
        text=text.replace(before,after)
    return text

class Refusal(RuntimeError):
    pass
def guard(condition,resource):
    if not condition:
        raise Refusal(resource)
env=dict(integrate.__globals__)
env['guard']=guard
exec(tighten(inspect.getsource(final_three),[
    ('    choices=[]','    guard(sum(len(t) for _,t in fs)<=150000, ("closing resident rows",sum(len(t) for _,t in fs)))\n    choices=[]'),
    ('    assert cost<=8_000_000','    guard(cost<=2_000_000, ("closing products",cost))\n    height=sum(max((max(abs(x),abs(y)).bit_length()+1 for x,y in t.values()),default=0) for _,t in fs)\n    guard(height+cost.bit_length()<=384, "closing height")')
]),env)
exec(tighten(inspect.getsource(integrate),[
    ('        assert n<=5_000_000,(A,B,n)','        guard(n<=2_000_000, ("join products",n))\n        height=sum(max((max(abs(x),abs(y)).bit_length()+1 for x,y in t.values()),default=0) for t in (X,Y))\n        guard(height+n.bit_length()<=384, "join height")'),
    ('                collect(out,k,mul(z,w))','                guard(k in out or len(out)<150000, "join rows")\n                collect(out,k,mul(z,w))'),
    ('        assert peak<300_000','        guard(peak<=150_000, ("factor rows",peak))')
]),env)
integrate=env['integrate']
widths=(1,3,3,4)
def peel(graphs,loads,own_only=False,reverse=False):
    graphs=[dict(G) for G in graphs]
    steps=[]
    while True:
        choices=[]
        for layer,G in enumerate(graphs):
            deg=Counter(x for a,b,k in G for x in (a,b))
            for e,n in G.items():
                a,b,k=e
                if e in graphs[1-layer]:continue
                if not (deg[a]==1 or deg[b]==1):continue
                if own_only and n!=(2,2):continue
                if any(p not in (2,4) for p in n):continue
                load=tuple(loads[t].get(e,(0,0)) for t in range(2))
                if own_only and sorted(load[layer])!=[0,2]:continue
                if min(map(sum,load))!=2:continue
                choices.append((layer,e,n,load))
        if not choices:return steps,graphs
        layer,edge,powers,load=max(choices) if reverse else min(choices)
        assert edge not in graphs[1-layer]
        del graphs[layer][edge]
        steps.append((layer,edge,powers,load))

def classify(rows):
    for a,b,w in rows:
        codes=(a,b)
        if any(n%2 for code in codes for site in occupancy(code) for n in site):
            continue
        G,_,_=projection(*codes,2)
        if not any(G):continue
        loads=[profile(code)[2] for code in codes]
        steps,remain=peel(G,loads)
        if not steps:continue
        assert remain==peel(G,loads,False,True)[1]
        if len(remain[0])!=1 or remain[0].keys()!=remain[1].keys():continue
        edge,=remain[0]
        powers=tuple(G[edge] for G in remain)
        if any(n not in (2,4) for pair in powers for n in pair):continue
        load=tuple(t.get(edge,(0,0)) for t in loads)
        sides=[side for side,p in enumerate(load) if any(p)]
        if len(sides)>1:continue
        if any(sorted(load[side])!=[0,2] or powers[side]!=(2,2) for side in sides):continue
        yield (a,b,w),steps,edge,powers,load

def factors(code,decor):
    occ=occupancy(code);edges=profile(code)[2]
    incident=defaultdict(list)
    factors=[]
    den=1
    affected={}
    for edge,(a,b) in sorted(edges.items()):
        u,v,axis=edge
        d=a+b
        if decor and edge==decor[0]:
            channel=decor[1]
            assert d==2 and min(a,b)==0
            data=D[int(bool(b)),channel]
            affected[u]=affected[v]=(channel,axis)
            den*=3072
        elif a and b:
            assert (a,b)==(2,2)
            data=mixed
        else:
            data=same[d] if a else {(y,x):z for (x,y),z in same[d].items()}
        if not decor or edge!=decor[0]:den*=64 if d==2 else 12288
        wires=((u,v,0),(u,v,1))
        guard(sum(len(t) for _,t in factors)+len(data)<=150000, ('initial edge rows',code,u,v))
        factors.append((wires,data))
        for x,wire in zip((u,v),wires):
            slot=(0 if u==x else 1)
            avail=defaultdict(set)
            for row in data:
                w,m,i=row[slot]
                assert m.bit_count()==d
                avail[w,i].add(m)
            incident[x].append((wire,axis,avail,bool(decor and edge==decor[0])))
    max_site_work=0
    for x,row in enumerate(occ):
        choices=[]
        for (spin,words),z in local(row,*affected.get(x,(-1,-1))).items():
            choices.append((tuple(map(enc,words)),z,spin))
        table={}
        plans=[]
        for words,z,spin in choices:
            labels=[(words[a],spin if special else 0) for _,a,_,special in incident[x]]
            groups=[D.get(s,()) for (_,_,D,_),s in zip(incident[x],labels)]
            if not all(groups):continue
            order=sorted(range(len(groups)),key=lambda i:len(groups[i]))
            plans.append((groups,order,labels,z))
        work=sum(prod(len(groups[i]) for i in order[:-1]) for groups,order,_,_ in plans)
        guard(work<=2_000_000, ('site complement work',work))
        max_site_work=max(max_site_work,work)
        for groups,order,labels,z in plans:
            for prefix in product(*(groups[i] for i in order[:-1])):
                mask=0
                for a in prefix:
                    if mask&a:break
                    mask|=a
                else:
                    complement=255^mask
                    if complement not in groups[order[-1]]:continue
                    masks=dict(zip(order,(*prefix,complement)))
                    ordered=list(map(masks.__getitem__,range(len(masks))))
                    exponent=sum(inv(a,b) for i,a in enumerate(ordered) for b in ordered[i+1:])
                    signed=z if exponent%2==0 else (-z[0],-z[1])
                    key=tuple((w,m,i) for (w,i),m in zip(labels,ordered))
                    table[key]=plus(table.get(key,(0,0)),signed)
                    guard(len(table)<=150000, ('site factor rows',len(table)))
        factors.append((tuple(wire for wire,_,_,_ in incident[x]),{k:v for k,v in table.items() if any(v)}))
    guard(sum(len(t) for _,t in factors)<=150000, ('initial resident rows',sum(len(t) for _,t in factors)))
    return factors,den,max_site_work

def integrate_partitioned(network,reverse,cut=()):
    try:
        z,peak,work=integrate(network,reverse)
        return z,peak,work,1
    except Refusal as reason:
        options=[]
        for i,(scope,A) in enumerate(network):
            for j,(other,B) in enumerate(network):
                if j<=i:continue
                for v in set(scope)&set(other):
                    a,b=scope.index(v),other.index(v)
                    for bit in range(8):
                        if (v,bit) in cut:continue
                        aa=sum(k[a][1]>>bit&1 for k in A)
                        bb=sum(k[b][1]>>bit&1 for k in B)
                        score=min(aa,len(A)-aa)*min(bb,len(B)-bb)
                        if score:options.append((score,v,bit,i,j,a,b))
        if not options:raise
        _,v,bit,i,j,a,b=max(options)
        print('partition',cut,'because',reason,'wire',v,'mask bit',bit,flush=True)
        halves=[]
        for choice in (0,1):
            fs=network.copy()
            for pos,index in ((i,a),(j,b)):
                scope,table=fs[pos]
                fs[pos]=(scope,{k:z for k,z in table.items() if (k[index][1]>>bit&1)==choice})
            halves.append(integrate_partitioned(fs,reverse,(*cut,(v,bit))))
        z=plus(halves[0][0],halves[1][0])
        return z,max(row[1] for row in halves),max(row[2] for row in halves),sum(row[3] for row in halves)

@cache
def value(code,decor,reverse):
    network,den,sites=factors(code,decor)
    val,peak,work,tiles=integrate_partitioned(network,reverse)
    assert val[1]==0
    print('layer',code,'denominator',den,'peak',peak,'work',work,'site work',sites,
          'initial resident',sum(len(t) for _,t in network),'value',F(val[0],den),'decor',decor,'tiles',tiles,flush=True)
    return F(val[0],den)

@cache
def moment(m):
    if m%2:return F(0)
    return F(prod(range(1,m,2)),prod(range(4,m+4,2)))
characters=((1,),(0,2),(-1,0,4),(0,-4,0,8),(1,0,-12,0,16))
@cache
def projection_norm(power,twice_spin):
    t=characters[twice_spin]
    coeff=[0]*(2*power+1)
    from math import comb
    for n in range(power+1):coeff[2*n]=comb(power,n)*(-1)**n
    return sum(a*b*moment(i+j) for i,a in enumerate(coeff) for j,b in enumerate(t))

@cache
def coeff(n,p,q):
    if n==0:return int(p==q==0)
    if n==2:
        return F(4,3)*(projection_norm(1,p)*(q==0)+projection_norm(1,q)*(p==0))
    assert n==4
    return F(16,5)*(projection_norm(2,p)*(q==0)+projection_norm(2,q)*(p==0)) + F(32,3)*projection_norm(1,p)*projection_norm(1,q)

def run(rows,start,stop,reverse):
    for index,((a,b,w),steps,edge,powers,loads) in enumerate(rows):
        if not start<=index<stop:continue
        print('case',a,b,w,repr(edge),repr(powers),repr(loads),flush=True)
        power_flat=occupancy(a)+occupancy(b)
        u,v,k=edge
        marks={(u,k),(v,k),(u+8,k),(v+8,k)}
        assert tuple(power_flat[x][k] for x in (u,v,u+8,v+8))==sum(powers,())
        factor=F(prod({0:1,2:2,4:10}[n] for x,row in enumerate(power_flat) for ax,n in enumerate(row)
                      if (x,ax) not in marks),prod(factorial(n) for row in power_flat for n in row))
        base=value(a,None,reverse)*value(b,None,reverse)
        occupied=[i for i,l in enumerate(loads) if any(l)]
        if not occupied:
            parts=[base*prod(coeff(n,p,q) for n in sum(powers,()))/
                   ((p+1)*(q+1))**4 for p,q in product(range(5),repeat=2)]
        else:
            side,=occupied
            parts=[base*prod(coeff(n,0,0) for n in sum(powers,()))]
            empty=value((a,b)[1-side],None,reverse)
            for channel in (0,1):
                p,q=((2,0) if channel==0 else (0,2))
                d=(p+1)*(q+1)
                weight=prod(d*coeff(n,p,q) for n in powers[1-side])/d**7
                assert weight
                parts.append(weight*empty*value((a,b)[side],(edge,channel),reverse))
            assert all(coeff(n,1,1)==0 for n in powers[1-side])
        z=factor*sum(parts)
        print('exact',a,b,w,z,'factor',factor,'parts',parts,flush=True)

def roster(path):
    return [tuple(map(int,row.split()[:3])) for row in Path(path).read_text().splitlines()]
res=roster('current-residual.tsv')
previous=roster('frozen/base-residual.tsv')
forest=set(roster('frozen/independent/forest-reviewed-exact.tsv'))
dual=set(roster('frozen/independent/dual-reviewed-exact.tsv'))
assert len(forest)==219 and len(dual)==88 and not forest&dual
assert forest|dual<=set(previous) and [r for r in previous if r not in (forest|dual)]==res
assert len(res)==9796 and sum(r[2] for r in res)==844551
cases=list(classify(res))
assert len(cases)==152 and sum(r[0][2] for r in cases)==13632
if sys.argv[1:]==['census']:
    for (a,b,w),steps,e,powers,loads in cases:
        print(a,b,w,repr(steps),repr(e),repr(powers),repr(loads),sep='\t')
    sys.exit()
if sys.argv[1:]==['characters']:
    for n in (2,4):
        print(n,{(p,q):str(coeff(n,p,q)) for p,q in product(range(5),repeat=2) if coeff(n,p,q)})
    sys.exit()
run(cases,int(sys.argv[1]),int(sys.argv[2]),'reverse' in sys.argv)
