# Independent review of 152 one-or-zero occupied shared-edge cases

**ACCEPT** all 152 original representatives in `reviewed-exact.tsv`.
Every coefficient is positive and each original weight agrees with
the frozen roster. The 13,632 labels contribute
`56317687141862691681381500463/36028797018963968`.
Subtracting these rows once leaves **9,644 temporal orbits and 830,919
labels**. No admitted representative remains refused.

| Occupied spatial sides | Representatives | Original labels | Weighted signed subtotal |
| --- | ---: | ---: | --- |
| One | 123 | 11,808 | 23085942562784824736783587209/18014398509481984 |
| Zero | 29 | 1,824 | 10145802016293042207814326045/36028797018963968 |

## Inputs and independent census

The continuity snapshot checked fresh. The published checkpoint
`414a9cc17` matched its tracked upstream. Its archived exact residual
agrees byte for byte with the frozen review input and with the preceding
base after subtracting the disjoint 219 forest and 88 dual-occupied
shared-edge tables. I verified the eight new author input manifest
entries, the preceding independent manifest and the extracted,
previously accepted dual-overlap source and tensor manifest.

The independent census reapplies the two-chirality representation
support projection to the original occupations. It admits only all-even
occupations with at least one legal leaf removal. Each removed edge
must be absent from the other live connector, have paired positive
even root powers, be incident to a degree-one vertex, and have exactly
two coframes on one of its original spatial sides. It keeps all original
coframe loads. Reversing the removal priority leaves the same core.
The surviving graphs must consist of the same single double-root edge
in both connectors. Every surviving root power is two or four. At most
one spatial side may have any coframes. Where occupied, the spatial
side has two same-owner coframes and its two own root powers are two.

Roster, original weight, exact reduction schedule, remaining edge,
root powers and endpoint loads all match the frozen author rows.
The 281 actual removed edges each have powers (2,2) and two own-side
coframes. The opposite loads are four in 191 steps and two in 90.
As established in the previous proof, Schur pairing at a leaf retains
one matrix at each of two distinct spatial anchors on either side.
Two coframes split across those anchors give odd anchored center
parity. A concentrated load leaves an independent bare nontrivial
matrix with zero mean. The prohibition on a shared live edge is
essential to that local argument. Thus these removals preserve the
shared temporal-center integrand in all other active roots and retain
their coframes.

## Exact normalized channel weights

For a common channel D of dimension d, each of the two isolated
temporal connectors has two normalized Schur pairings, giving d⁻⁴
together. In a spatial layer the two connector traces give an
own-side matrix trace and the opposite connector's character on
the same anchored variables. With F and G the relevant transposed
root matrices, write the product there as
`tr(F D(A)† G D(C)†) tr(D(A)D(C))`.
When the C anchor is empty, its normalized pairing forces the
connector labels equal and gives
`tr(F D(A)† G D(A))/d`. If A too is empty, its conjugation Haar
gives `tr(F) tr(G)/d²` for the whole spatial layer.
If A contains both coframes its two matrices are retained in the
independently accepted decorated tensor. The (1,1) coframe split
vanishes by the simultaneous two-chirality parity at each actual
anchor. All roots involved have even powers, so both representation
factors on each anchor are even under that simultaneous change.

For an empty spatial layer, the character coefficient c(n,p,q) in a
root is its matrix trace divided by d, with p,q twice
the left and right spins and d=(p+1)(q+1), after separating the root's
Gram polynomial. I derived these coefficients from exact quaternion
moments. Write t=1−q₀² for the radial squared length of the imaginary
quaternion. A simple Clifford bivector has equal squared chiral
norms W. Averaging each independent imaginary direction gives for
the quadratic, after factoring W, `4(tL+tR)/3`. For the quartic,
after factoring W², the result is
`16(tL²+tR²)/5 + 32 tL tR/3`. Project these class functions onto
orthonormal SU(2) characters using the exact Haar moments of q₀.
The character recurrence is `χ_(j+1)=2 q₀ χ_j−χ_(j−1)`, starting
from 1 and 2q₀.

| Root power | Nonzero c(n,p,q) |
| --- | --- |
| 2 | c(0,0)=2, c(2,0)=c(0,2)=−1/3 |
| 4 | c(0,0)=10, c(2,0)=c(0,2)=−3, c(4,0)=c(0,4)=1/5, c(2,2)=2/3 |

The literal canonical quaternion/Clifford source checked all 300
entries for the six distinct internal basis bivectors, both powers,
and all twice-spin pairs through four. Those controls include
vanishing mixed fundamental traces. An independent direct
polynomial coordinate integration checked the single empty anchor
formula for general nonsymmetric sample matrices. Integrating both
anchors gives 80/9 in that sample, exactly the product of the two
traces divided by nine. Unequal adjoint chiralities and the split
odd-coframe control vanish.

- With one occupied side, the total normalized integral carries
  d⁻⁷ before inserting the two empty-side traces, namely four
  temporal and three spatial factors. Each empty-side trace has
  coefficient `d*c(n,p,q)`, giving
  `(d*c(n1,p,q))*(d*c(n2,p,q))/d⁷` times the decorated signed
  layer product. The only nontrivial common channels are the two
  adjoints of dimension three. The occupied degree-two expansion
  also has dimension-four product fundamental components, but
  their trace in the other layer is zero for both powers. The
  scalar uses the explicit factors from all four roots.
- With neither side occupied, four temporal and four spatial
  factors give d⁻⁸. All four root traces supply a factor d each.
  The common-channel coefficient is therefore
  `prod(c(n,p,q))/d⁴` times the ordinary signed layers. The replay
  evaluates all 25 twice-spin pairs through four. In every admitted
  no-coframe case one or more roots have power two, so the common
  nontrivial terms are exactly the two spin-one chiralities.

All original insertion factorials include the four surviving root
multiplicities and the eliminated scalar roots. Scalar and higher
character coefficients replace only the indicated curvature
factors. Every original spatial coframe, exact Haar scale, and
local Grassmann ordering remains in the signed layer calculation.

## Exact replay and resource bounds

The signed calculation runs the original labels independently, with
different left and right decorated site tensor terms. It neither
relabels the layers to the author's orbit codes nor identifies the
two adjoints by symmetry. All 152 final exact coefficients agree.
Both adjoint contributions are nonzero in each of the 152 cases.
The summed nontrivial weighted increments are
`509582495949712999138881/18014398509481984` for the one-side cases
and `284351000076505891382805/36028797018963968` for the zero-side cases.

The independent replay checks site-complement counts, join products
and height before starting each arithmetic phase, and checks the
sparse row limit before insertion. Its largest admitted counts are
64,512 populated factor rows, 1,548,288 matched ordinary or closing
products, 19,968 site trials and 33,996 initial resident rows.
Within seven original cases, 14 particular layer schedules require
between two and six tiles. The direct paths stop when a preflight
join-work limit or a sparse insertion row guard refuses. Each retry
restricts both factors sharing one endpoint state by the same
generator-mask bit. A matched state has exactly one value of that
bit, so the two restrictions are disjoint and exhaustive. A nested
partition chooses an unassigned bit. Each admitted tile keeps
its original coefficients and scales, and the exact signed sum
restores the full value. There are 285 computed layer schedules
across four shards, with 271 direct, twelve two-tile, one five-tile
and one six-tile. No refused product batch was run past its guard.

The acceptance is limited to these 152 residual rows with one or
zero occupied spatial sides. The remaining temporal block and
full original c0 sign, value and nonvanishing remain open. No
repository, manuscript or Lean state changed.

## Scratch replay

The scratch directory expects `frozen` pointing to the frozen review
input root, `INDEPENDENT` to the preceding projection scripts,
`DUAL` extracted from `frozen/chain/prior-dual.zip`, and
`current-residual.tsv` copied from `block-remaining.tsv` in the
published `L1_N16_C0_FOREST_SHARED_EDGE_R1.zip`. The literal control
uses the primary source checkout named by the continuity snapshot.

```sh
(cd DUAL && shasum -a 256 -c manifest.sha256) > dual-manifest.out
PYTHONDONTWRITEBYTECODE=1 python3 one-zero.py census > census.tsv
PYTHONDONTWRITEBYTECODE=1 python3 one-zero.py characters > characters.out
PYTHONPATH="$SOURCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$SOURCE_CHECKOUT/.venv/bin/python" literal-control.py > literal-control.out
PYTHONDONTWRITEBYTECODE=1 python3 one-zero.py 0 38 > cases-0.out
PYTHONDONTWRITEBYTECODE=1 python3 one-zero.py 38 76 > cases-38.out
PYTHONDONTWRITEBYTECODE=1 python3 one-zero.py 76 114 > cases-76.out
PYTHONDONTWRITEBYTECODE=1 python3 one-zero.py 114 152 > cases-114.out
python3 compare.py > comparison.out
shasum -a 256 -c manifest.sha256
```
