from ast import literal_eval
from collections import Counter,defaultdict
from fractions import Fraction as F
from pathlib import Path
import re

def asrows(p,sep=None):
    return [l.split(sep) for l in Path(p).read_text().splitlines()]
def triples(p):
    return [tuple(map(int,r[:3])) for r in asrows(p)]
def fraction_list(raw):
    return [F(x) for x in literal_eval(re.sub(r'Fraction\((-?\d+), (\d+)\)',r"'\1/\2'",raw))]
frozen=Path('frozen/chain')
author=[]
for a,b,w,p,e,n,l in asrows(frozen/'leaf-overlap-one-or-zero-roster.tsv','\t'):
    steps=literal_eval(p)
    author.append(((int(a),int(b),int(w)),[(s,k,m,tuple(v)) for s,k,m,v in steps],
                   literal_eval(e),literal_eval(n),literal_eval(l)))
roster=[]
for a,b,w,p,e,n,l in asrows('census.tsv','\t'):
    roster.append(((int(a),int(b),int(w)),literal_eval(p),literal_eval(e),literal_eval(n),literal_eval(l)))
assert roster==author and len(roster)==152
accepted_prior=set(triples('frozen/independent/forest-reviewed-exact.tsv'))|set(triples('frozen/independent/dual-reviewed-exact.tsv'))
residual=triples('current-residual.tsv')
assert len(accepted_prior)==307
assert not accepted_prior&set(residual)
expected={}
for a,b,w,s,z in asrows(frozen/'leaf-overlap-one-or-zero-author.tsv'):
    key=int(a),int(b),int(w)
    assert key not in expected and key in residual
    assert s=='EXACT'
    expected[key]=F(z)
assert list(expected)==[r[0] for r in roster]
cases={}
actual={}
n_parts=Counter()
n_tiles=Counter()
n_refusals=Counter()
counts=Counter()
subtotals=defaultdict(F)
counts_by_side=Counter()
spins=Counter()
nontrivial=defaultdict(F)
bounds=[]
for shard in (0,38,76,114):
    for l in Path(f'cases-{shard}.out').read_text().splitlines():
        p=l.split()
        if p[0]=='case':
            key=tuple(map(int,p[1:4]))
            assert key not in cases
            row=roster[len(cases)]
            assert key==row[0]
            cases[key]=row
            n=sum(bool(any(l)) for l in row[-1])
        elif p[0]=='exact':
            assert tuple(map(int,p[1:4]))==key and key not in actual
            v,f=F(p[4]),F(p[6])
            terms=fraction_list(l.split(' parts ',1)[1])
            assert len(terms)==(3 if n else 25)
            assert v==sum(terms)*f==expected[key],(key,v,expected[key])
            actual[key]=v
            subtotals[n]+=key[2]*v
            nontrivial[n]+=key[2]*f*sum(terms[1:])
            counts_by_side[n,'rows']+=1;counts_by_side[n,'labels']+=key[2]
            spins[n,tuple(i for i,z in enumerate(terms) if z)]+=1
            counts['positive' if v>0 else 'zero' if not v else 'negative']+=1
        elif p[0]=='layer':
            bounds.append(tuple(int(p[i]) for i in (5,7,10,13)))
            n_tiles[int(p[-1])]+=1
        elif p[0]=='partition':
            n_parts[key]+=1
            n_refusals[l.split(' because ',1)[-1].split(' wire ',1)[0]]+=1
assert actual==expected
assert sum(k[2] for k in actual)==13632
left=[r for r in residual if r not in actual]
assert len(left)==9644 and sum(r[2] for r in left)==830919
print('verified',len(actual),'signs',counts,'total weighted',sum(subtotals.values()))
print('side counts',counts_by_side)
print('side subtotals',dict(sorted(subtotals.items())),'nontrivial increments',dict(sorted(nontrivial.items())))
print('nonzero separate channels',spins)
print('max factor / join / site / initial',*[max(x) for x in zip(*bounds)])
print('evaluated layer schedules by tiles',n_tiles,'bounded refusable join reasons',n_refusals,'partitioned cases',len(n_parts))
print('remaining',len(left),sum(r[2] for r in left))
Path('reviewed-exact.tsv').write_text(''.join('\t'.join(map(str,(*k,v)))+'\n' for k,v in actual.items()))
