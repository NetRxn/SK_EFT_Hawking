import os
from fractions import Fraction as F
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from src.core.formulas import original_spin4_link as spin
from src.core.formulas import original_quaternion_haar_moment as sphere
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial as P, QComplex as Q, Symbol,
    matrix_multiply as mm, matrix_dagger as dagger,
)

reg=OriginalRegulator(temporal_axis=0)
U=(0,0,0,0)
V=(0,0,0,1)
def coords(site):
    return tuple(tuple(P.variable(Symbol('q',(site,1,chi,i))) for i in range(4))
                 for chi in ('L','R'))
def trace(A):
    return sum((A[i][i] for i in range(len(A))),P())
@cache
def moment(indices):
    return prod(sphere(tuple(indices.count((chi,i)) for i in range(4))) for chi in ('L','R'))
def integrate(poly,site):
    out=[]
    for key,z in poly.terms:
        selected=tuple(s.index[-2:] for s in key if s.index[0]==site)
        h=moment(selected)
        if h:out.append((tuple(s for s in key if s.index[0]!=site),z*h))
    return P(tuple(out))
def coefficient(poly):
    if not poly:return F(0)
    (key,z),=poly.terms
    assert not key and not z.imag
    return z.real

def multiply(a,b):
    assert len(a.terms)*len(b.terms)<=2_000_000
    return a*b

def chis(x):
    out=[P.scalar(1),2*x]
    for _ in range(3):out.append(2*x*out[-1]-out[-2])
    return out

q=coords(U)
gamma=reg.gamma
g5=reg.gamma5
u=spin(*q)
expected={
    2:{(0,0):F(2),(0,2):F(-1,3),(2,0):F(-1,3)},
    4:{(0,0):F(10),(0,2):F(-3),(0,4):F(1,5),(2,0):F(-3),(2,2):F(2,3),(4,0):F(1,5)},
}
char=tuple(chis(row[0]) for row in q)
checked=0
for a in range(4):
    for b in range(a+1,4):
        trace_poly=trace(mm(u,mm(mm(gamma[a],gamma[b]),g5)))
        assert trace_poly
        Q2=multiply(trace_poly,trace_poly)
        Q4=multiply(Q2,Q2)
        for n,power in ((2,Q2),(4,Q4)):
            out={}
            for p,r in product(range(5),repeat=2):
                result=coefficient(integrate(multiply(power,multiply(char[0][p],char[1][r])),U))
                if result:out[p,r]=result
                checked+=1
            assert out==expected[n],(a,b,n,out)
print('literal Clifford/character projections',checked,'all match exact class coefficients')

adj=[tuple(map(int,l.split())) for l in Path('DUAL/adjoint.tsv').read_text().splitlines()]
def rep(q):
    out=[[P() for _ in range(3)] for _ in range(3)]
    for i,j,a,b,c in adj:out[i][j]+=q[a]*q[b]*c
    return tuple(map(tuple,out))
def M(rows):
    return tuple(tuple(P.scalar(x) for x in r) for r in rows)

A,B=(rep(coords(site)[0]) for site in (U,V))
BR=rep(coords(V)[1])
X=M(((3,1,-2),(0,2,1),(2,4,5)))
Y=M(((6,0,3),(1,1,4),(4,2,1)))
own=trace(mm(mm(mm(X,dagger(A)),Y),dagger(B)))
cross=trace(mm(A,B))
one=integrate(multiply(own,cross),V)
target=trace(mm(mm(mm(X,dagger(A)),Y),A))*F(1,3)
assert one==target
two=coefficient(integrate(one,U))
assert two==coefficient(multiply(trace(X),trace(Y)))/9
assert not integrate(multiply(own,trace(mm(A,BR))),V)
qU=coords(U)[0][1]
qV=coords(V)[0][2]
assert not integrate(multiply(multiply(own,cross),multiply(qU,qV)),U)
print('adjoints empty-anchor one projection agrees polynomially, two anchors',two)
print('mismatched chirality and odd split controls vanish')
