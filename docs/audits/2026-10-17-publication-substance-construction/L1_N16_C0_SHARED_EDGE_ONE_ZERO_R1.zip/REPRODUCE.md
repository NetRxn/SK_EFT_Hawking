# Remaining one-shared-edge coefficients

Checkpoint 414a9cc17 and its L1_N16_C0_FOREST_SHARED_EDGE_R1.zip are the
candidate's accepted inputs. In this archive's root, confirm the base equals
that evidence archive's block-remaining.tsv. Subtract only the independent
exact table by running python3 check_residual.py independent/reviewed-exact.tsv.

For the independent replay, restore that prior archive and its declared
independent projection source. In independent/, use frozen for the extracted
prior archive, INDEPENDENT for the independent projection source and DUAL
for the extracted prior dual-overlap archive. Verify the independent manifest
before replay. Follow the independent review for the exact commands.

The preflight directory preserves author-only coverage measurements for
the next larger family. Its controls are estimates of channel-label
assignments. They do not establish the cost or value of a signed contraction.

The literal controls also replayed against clean science candidate 51e7c745e
with PYTHONPATH pointing to that candidate and the repository's existing
Python environment for NumPy. The documentation checkpoint contains the
review receipts and does not change that scientific source.
