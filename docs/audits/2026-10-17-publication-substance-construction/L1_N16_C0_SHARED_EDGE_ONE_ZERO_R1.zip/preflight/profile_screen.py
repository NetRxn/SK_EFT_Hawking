from collections import Counter
from pathlib import Path
import sys

base, residual, pending = map(Path, sys.argv[1:])
source = base / 'family-intake/directed_roster.py'
scope = {'__file__': str(source)}
exec(source.read_text().split('\nselected=[]', 1)[0], scope)
projection, occupancy = (scope[k] for k in ('projection', 'occupancy'))
pending_ids = {tuple(map(int, line.split()[:2])) for line in pending.read_text().splitlines()}
categories = Counter()
pairs_by_shape = Counter()
profiles = Counter()
for line in residual.read_text().splitlines():
    a, b, weight = map(int, line.split())
    if (a,b) in pending_ids:
        continue
    graphs, _, domains = projection(a,b,2)
    odd = any(p % 2 for row in occupancy(a) + occupancy(b) for p in row)
    edge_counts = tuple(sorted(map(len,graphs)))
    common = len(graphs[0].keys() & graphs[1].keys())
    scalar = 0 in edge_counts
    kind = ('odd' if odd else 'even', ('shared' if common else 'disjoint'), 'scalar-side' if scalar else 'two-live')
    categories[kind,'orbits'] += 1
    categories[kind,'labels'] += weight
    pairs_by_shape[kind,edge_counts] += weight
    if scalar:
        profiles[(a,b)[not bool(graphs[0])]] += weight
print('categories', sorted(categories.items()))
print('largest graph-count groups',pairs_by_shape.most_common(15))
print('largest one-live-side profiles',profiles.most_common(8))
