from collections import defaultdict
from itertools import product
from pathlib import Path
import sys

file=Path(sys.argv[2])/'parity-cost.py'
namespace={'__file__':str(file)}
exec(file.read_text().split('\npending=',1)[0],namespace)
projection,profile,screen=(namespace[k] for k in ('projection','profile','screen'))
for a,b in [(174372786201,71470441103490),(580896423965,9431048058457),(103607566400,1256282652690),(4473318154565,22370909184065)]:
    graphs,_,domains=projection(a,b,2)
    names=list(domains)
    constraints=[]
    temporal=defaultdict(list)
    for (t,x,k) in names:
        for y in (x,x^(1<<k)):
            temporal[t,y].append((t,x,k))
    for terms in temporal.values():
        constraints.append((tuple(names.index(name) for name in terms),0))
    for u,v,k in graphs[0].keys() | graphs[1].keys():
        anchored=[tuple(names.index(name) for name in names if name[1:]==(x,k)) for x in (u,v)]
        for code in (a,b):
            degree=sum(profile(code)[2].get((u,v,k),(0,0)))
            constraints.append((anchored[0]+anchored[1],degree%2))
            if degree==0:
                constraints.extend((term,0) for term in anchored)
    count=sum(all(sum(spins[i][0] for i in term)%2==rhs for term,rhs in constraints)
              for spins in product(*domains.values()))
    expected, raw, free = screen(a,b)
    assert count==expected,(a,b,count,expected)
    print(a,b,raw,count,free)
