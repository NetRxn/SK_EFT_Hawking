# L1 joint odd-root contraction preflight

Author-only planning against checkpoint 414a9cc17. The profile screen projects
the residual after hypothetical acceptance of the 152 already computed
cases. The projected residual is 9,644 orbits and 830,919 labels. Odd root
profiles with a shared connector edge account for 8,176 orbits and 717,129
labels. The largest paired edge counts (6,10) and (4,10) cover 106,656 and
84,576 labels, respectively.

The existing support projector gives allowed doubled-spin labels at each
root. Root power fixes the parity of the sum of its two doubled spins.
The parity of one chirality then determines the other. At a temporal
anchor the first-chirality sum must be even. At a pair of spatial anchors,
adding the two center equations eliminates the allocation of vector
coframes and gives a parity equal to their total degree modulo two.
With no coframes, both anchor equations hold separately. This is a
necessary support test. It leaves the spin triangle constraints and the
signed matrix contraction to subsequent work.

The GF(2) screen proposed no further zero cases in the pinned residual.
It nevertheless reduces the count of candidate channel assignments. In the
projected odd/shared class, 3,045 orbits covering 280,248 labels have fewer
than 1,024 remaining assignments by this count. With a bound of fewer than
16,384 assignments, the figures are 6,363 orbits and 579,732 labels.
These thresholds count representation labels before the remaining spin and
matrix constraints. They are neither a measured resource bound nor a signed
coefficient result. Four literal product controls independently enumerate the
stated first-chirality parity conditions and agree with the GF(2) counts.
Next test a prospectively capped exact signed contraction on a representative
of the frequently reused 256-assignment class (103607566400,1256282136720).
Compare reuse of connector/coframe components across that class before
selecting a broad batch.

Reproduce by passing the restored directed-square author scratch root
(with family-intake/directed_roster.py and INDEPENDENT/) and this checkpoint's
frozen extracted directory to the scripts. profile_screen.py also takes the
residual and pending author-table files explicitly. The source checkpoint's
residual is frozen and is not overwritten by these scripts.
