from collections import Counter, defaultdict
from pathlib import Path
import sys

base, frozen = map(Path,sys.argv[1:])
source = base / 'family-intake/directed_roster.py'
scope = {'__file__': str(source)}
exec(source.read_text().split('\nselected=[]', 1)[0], scope)
projection, occupancy, profile = (scope[k] for k in ('projection','occupancy','profile'))

def solve(equations):
    basis = {}
    for lhs, rhs in equations:
        while lhs:
            pivot = lhs.bit_length()
            if pivot not in basis:
                basis[pivot] = lhs,rhs
                break
            row, bit = basis[pivot]
            lhs ^= row
            rhs ^= bit
        if not lhs and rhs:
            return None
    return len(basis)

def screen(a,b):
    graphs, _, domains = projection(a,b,2)
    parity_vars = {}
    fixed = {}
    for name, labels in domains.items():
        choices = {p % 2 for p,q in labels}
        if len(choices) == 2:
            parity_vars[name] = 1 << len(parity_vars)
        else:
            fixed[name], = choices
    equations = []
    def add(names, rhs=0):
        mask=0
        for name in names:
            mask ^= parity_vars.get(name,0)
            rhs ^= fixed.get(name,0)
        equations.append((mask,rhs))
    for t,graph in enumerate(graphs):
        variables=defaultdict(list)
        for (u,v,k),(p,q) in graph.items():
            for x, power in ((u,p),(v,q)):
                if not power:
                    continue
                for y in (u,v):
                    variables[y].append((t,x,k))
        for names in variables.values():
            add(names)
    load = [profile(code)[2] for code in (a,b)]
    for u,v,k in graphs[0].keys() | graphs[1].keys():
        # Each directed spatial anchor receives the two root characters
        # from that anchor in opposite layers. Sum their center equations
        # to eliminate allocation of individual vector coframes.
        for layer in load:
            add(((t,x,k) for t in range(2) for x in (u,v)),sum(layer.get((u,v,k),(0,0)))%2)
            if not sum(layer.get((u,v,k),(0,0))):
                for x in (u,v):
                    add(((0,x,k),(1,x,k)))
    rank=solve(equations)
    return len(parity_vars),rank

hist=Counter()
zeros=[]
for row in (frozen/'block-remaining.tsv').read_text().splitlines():
    a,b,w=map(int,row.split())
    n,rank=screen(a,b)
    if rank is None:
        zeros.append((a,b,w))
    else:
        hist[n-rank]+=w
print('provisional parity-zero orbits and labels',len(zeros),sum(w for a,b,w in zeros))
print('survivor labels by free chirality bits',sorted(hist.items()))
print('first candidate zeros',zeros[:12])
