from collections import Counter
from fractions import Fraction as F
from itertools import permutations, product
from math import factorial,prod
from pathlib import Path
from core import decode,local
from family import isolated,edges,co

prior=Path('/private/tmp/l1-c0-core.1zohnyO1')
done={tuple(map(int,r.split()[:2])) for f in ('signed-orbits.tsv','zero-orbits.tsv') for r in (prior/f).read_text().splitlines()}
alive=[r for r in isolated if r[:2] not in done]
def local_id(m):return local.index(tuple(m))
perms=tuple(permutations(range(3)))
def canonical(code):
    m=decode(code)
    out=[]
    for perm in perms:
        axes=[sum(((v>>i)&1)<<perm[i] for i in range(3)) for v in range(8)]
        inds=[]
        for row in m:
            new=[0]*3
            for i,n in enumerate(row):new[perm[i]]=n
            inds.append(local_id(new))
        for shift in range(8):out.append(sum(n<<(6*(v^shift)) for n,v in zip(inds,axes)))
    return min(out)

def classify(r):
    a,b,w,A,B,ca,cb,la,lb=r
    if any(n%2 for row in A+B for n in row):return "odd",None
    ea,eb=edges(A),edges(B)
    if any(sum(v)>4 for v in list(ea.values())+list(eb.values())):return "edge-width",None
    f=F(1)
    for e in set(ca)|set(cb):
        pa,pb=ca.get(e,(0,0)),cb.get(e,(0,0))
        da,db=sum(ea.get(e,(0,0))),sum(eb.get(e,(0,0)))
        if sum(pa) and sum(pb):
            if da or db:return "overlapping-dual-core",None
            f*=sum(prod(co[n].get((x,y),0) for n in pa+pb)/F(((2*x+1)*(2*y+1))**4)
                    for x,y in product(range(3),repeat=2))
        else:
            if min(da,db)>=4:return "overlapping-single-core",None
            f*=prod(co[n][0,0] for n in pa+pb)
    for _,x,y in la+lb:f*=co[x+y][0,0]
    return "admitted",f/prod(factorial(n) for row in A+B for n in row)

census=Counter(); admitted=[]
for r in alive:
    t,f=classify(r);census[t]+=1
    if t=="admitted":admitted.append((r,f))
cache= {code:canonical(code) for code in {a for (r,f) in admitted for a in r[:2]}}
if __name__=="__main__":
    print("scalar scheduling census",dict(census))
    print("scalar admitted orbits",len(admitted),"labeled",sum(r[2] for r,_ in admitted),
          "unique original layer codes",len(cache),"canonical layer codes",len(set(cache.values())))
