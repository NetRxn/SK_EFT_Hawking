from core import *
from fractions import Fraction as F
from math import factorial, prod
from coframe import run
from functools import lru_cache
def edges(m):
    h=[[sum(r)-x for x in r] for r in m]
    return {(u,u^(1<<k)):(h[u][k],h[u^(1<<k)][k]) for u in range(8) for k in range(3)
            if u<(u^(1<<k)) and h[u][k]+h[u^(1<<k)][k]}
def excluded(A,B,ca,cb):
    c=set(ca)|set(cb)
    for m,own,other in ((A,ca,cb),(B,cb,ca)):
        overlap=set(edges(m))&c
        for v in range(8):
            if any(v in e for e in overlap):continue
            powers=[(a if v==e[0] else b) for e,(a,b) in own.items() if v in e]
            powers=[n for n in powers if n]
            if 1<=len(powers)<=2 and sum(powers)%2: return True
    return False
def singleton(c):return all(len(x)==1 for x in comps(c))
def is_disjoint(A,B,ca,cb):return not((set(edges(A))|set(edges(B)))&(set(ca)|set(cb)))
co={0:{(0,0):F(1)},2:{(0,0):F(2),(1,0):F(-1,3),(0,1):F(-1,3)},
    4:{(0,0):F(10),(1,0):F(-3),(0,1):F(-3),(2,0):F(1,5),(0,2):F(1,5),(1,1):F(2,3)}}
def core_factor(ca,cb):
    out=F(1)
    for e in sorted(set(ca)|set(cb)):
        n=(*ca.get(e,(0,0)),*cb.get(e,(0,0)))
        out*=sum(prod(co[m].get((a,b),0) for m in n)/F(((2*a+1)*(2*b+1))**4)
                 for a,b in product(range(3),repeat=2))
    return out

removed=[];eligible=[];isolated=[];disjoint=[];patterns=Counter()
for r in residual:
    a,b,w,A,B,ca,cb,la,lb=r
    if excluded(A,B,ca,cb):
        removed.append(r)
    if is_disjoint(A,B,ca,cb):
        disjoint.append(r)
    if not(singleton(ca) and singleton(cb)):continue
    isolated.append(r)
    for v in [*ca.values(),*cb.values()]:patterns[tuple(sorted(v))]+=1
    if not is_disjoint(A,B,ca,cb):continue
    if not all(n%2==0 for row in A+B for n in row):continue
    if not all(min(v)==0 for v in list(edges(A).values())+list(edges(B).values())):continue
    eligible.append(r)

if __name__=="__main__":
    print("exact curvature-only odd-root zeros",len(removed),sum(r[2] for r in removed))
    print("isolated edge-only residual family",len(isolated),sum(r[2] for r in isolated),"patterns",sorted(patterns.items()))
    print("all residual disjoint",len(disjoint),sum(r[2] for r in disjoint))
    print("isolated edge-only disjoint even coframe-single-owner family",len(eligible),sum(r[2] for r in eligible))
    print("isolated family isotropy zero overlap",len({r[:2] for r in removed}&{r[:2] for r in isolated}))
    for r in removed[:3]:print("zero source witness",r[:3],r[5:7])
    Path("zero-orbits.tsv").write_text("".join(f"{a}\t{b}\t{n}\n" for a,b,n,*_ in removed))
    cached=lru_cache(None)(run)
    output=[];total=F(0)
    for a,b,w,A,B,ca,cb,la,lb in eligible:
        cA,cB=cached(a),cached(b)
        pf=prod(2 if x+y==2 else 10 for _,x,y in la+lb)
        z=core_factor(ca,cb)*pf*cA*cB/prod(factorial(n) for row in A+B for n in row)
        print("signed orbit",a,b,w,z)
        output.append((a,b,w,z));total+=w*z
    print("family subtotal",total,"positive, zero, negative",
          sum(z>0 for a,b,w,z in output),sum(z==0 for a,b,w,z in output),sum(z<0 for a,b,w,z in output))
    Path("signed-orbits.tsv").write_text("".join(f"{a}\t{b}\t{w}\t{z}\n" for a,b,w,z in output))
    print("remaining complete degree-block orbit count",len(residual)-len(removed)-len(eligible),
          "remaining labeled",sum(r[2] for r in residual)-sum(r[2] for r in removed+eligible))
