from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path
from decorate import Q,moment
from decorate_lr import R

def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def scl(a,c):return (a[0]*c,a[1]*c)

@lru_cache(None)
def pair(a,b,c,d,extra):
    out=(F(0),F(0))
    for (i,j,r,s),(u,v,t,w) in product(R[a,b],R[c,d]):
        key=(i,j,u,v,*extra)
        L=tuple(sorted(k for k in key if k<4));Rkey=tuple(sorted(k-4 for k in key if k>=4))
        out=add(out,scl(mul((r,s),(t,-w)),moment(L)*moment(Rkey)))
    return out

def direct(owner,k):
    l,lo,hi,p1,p2=k
    a,b=divmod(p1,4);c,d=divmod(p2,4)
    A,B=divmod(l,4);mask=lo|(hi<<8)
    qterms=defaultdict(lambda:(0,0))
    for (u,q,r,i),(v,p,s,j) in product(Q[owner,A],Q[owner,B]):
        if u&v or u|v!=mask:continue
        sign=(-1)**sum((v&((1<<k)-1)).bit_count() for k in range(16) if u>>k&1)
        qp=tuple(sorted((q,p)))
        qterms[qp]=add(qterms[qp],scl(mul((r,i),(s,j)),sign))
    result=(F(0),F(0))
    for (q,p),x in qterms.items():
        if not any(x):continue
        L=tuple(v for v in (q,p) if v<8)
        Rq=tuple(v-8 for v in (q,p) if v>=8)
        # Independently integrate both anchors in chi(a c) D(a†) D(c†).
        # No equal-anchor or empty-anchor shortcut is used here.
        z=(F(0),F(0))
        for i,j in product(range(4),repeat=2):
            z=add(z,mul(pair(i,j,d,a,L),pair(j,i,b,c,Rq)))
        result=add(result,scl(mul(z,x),F(1,16)))
    return result

for owner in range(2):
    rows=[tuple(map(int,x.split())) for x in Path(f'decorated-{owner}-2.tsv').read_text().splitlines()]
    chosen=[[x for x in rows if x[-2] and not x[-1]][0],
            [x for x in rows if x[-1]][0],
            [x for x in rows if x[-1]][-1]]
    for l,u,v,p,q,r,i in chosen:
        got=direct(owner,(l,u,v,p,q))
        assert got==(F(r,3072*4),F(i,3072*4)),(got,r,i)
        print("raw shared two-anchor product-channel control",owner,(l,u,v,p,q),got)

vectors={}
for chi,a,b,i,s in (map(int,x.split()) for x in Path('bivectors.tsv').read_text().splitlines()):
    vectors[chi,a,b,i]=s
for a,b,i in product(range(4),range(4),range(3)):
    r=lambda c:1 if c==3 else -1
    assert vectors.get((0,a,b,i),0)==-r(a)*r(b)*vectors.get((1,a,b,i),0)
print("all source bivector chirality-swap phases verified")
