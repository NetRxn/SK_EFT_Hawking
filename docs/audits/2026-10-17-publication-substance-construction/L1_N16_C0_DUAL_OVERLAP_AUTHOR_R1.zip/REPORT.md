# Complete exact isolated temporal-edge family

The primary continuity packet `l1-c0-dual-overlap-author-r1.json`
checked fresh at `27012c18fa374e8341e124b510abbedeedb18d29`.
This scratch package uses the preceding isolated-edge and residual-core
packages read-only. Their frozen manifests reverified. In particular
the isolated-edge input manifest digest is
`1ff77eb354e9adeebee846a519ef20e4d3499ccfcefca814c3a4f206db9d4c1f`.
The preceding constructions and this extension retain separate
independent review status. No tracked file, prior artifact, notebook
or Lean slot was modified.

All **75** previously unresolved isolated dual-overlap orbits
are evaluated exactly, covering **5,664** labeled occupations.
All are positive. Together with earlier exact work, the declared
isolated temporal-edge family is complete. The larger n=16
temporal A-only/B-only block and the full c0 remain open.

## Channel census and exact shared-Haar projection

The residual census has 51 cases with coframes in only one
spatial layer on each overlapping dual core and 24 cases with
at least one dual core carrying coframes in both layers.
Every affected layer has exactly two same-endpoint coframes on
the edge. Where one layer has none, the occupied layer's two
roots have power (2,2) and the empty layer has even powers
two or four. Where both have coframes, all four roots have
power two. Every representative has one or two overlapping
dual cores. The other isolated edges are evaluated by the
prior exact scalar projection or the disjoint shared-character
contraction. No unused approximation is introduced.

For each connector apply the exact two-temporal-anchor Schur
formula from the previous package. For a representation j
of dimension d, it supplies one character of the spatial
anchor pair in the opposite layer, two spatial matrices in
its own layer, and a factor d^-2. Multiplying the two
connector formulas retains the single shared copy of each
spatial anchor. The two coframes in an occupied spatial
layer cannot split between its anchors. Indeed each power-two
root representation has chiral center parity either
(even,even) or (odd,odd). Combining the two connector
labels cannot cancel the parity of a single coframe
coordinate on an anchor, which is odd in exactly one
chirality. On an edge with an empty spatial layer,
orthogonality already matches the labels of the two
connectors there. In the occupied layer the same parity
argument then excludes split coframes. The empty anchor
in each occupied spatial layer enforces equality of the
two Schur labels by matrix orthogonality.

The retained conditional contributions are:

- **Scalar.** The root factors are 2 W for power two or
  10 W² for power four. They multiply the unchanged signed
  coframe layer contractions.
- **One occupied spatial layer.** The other layer's two
  empty anchors trace each root matrix, with two more
  orthogonality factors. Only single-chirality spin one
  survives beyond the scalar, since the product of two
  spin-half traces has zero conjugation average for these
  even powers. The spin-one root traces are −W for power
  two and −9 W² for power four. The occupied layer's empty
  anchor gives one further inverse dimension. The total
  nontrivial factor is d^-7 times the two empty-layer
  trace coefficients and the signed decorated coframe
  contraction in the occupied layer.
- **Both spatial layers occupied.** In addition to the
  scalar and the two spin-one labels, the spin-half times
  spin-half label is allowed. The single empty anchor of
  each spatial layer gives one inverse dimension. The
  two signed decorated layer contractions multiply with
  factor d^-6. This layer separation is derived after
  shared-anchor orthogonality. Separately averaging the
  original connector kernels would instead delete all
  of these nontrivial channels.

For clarity, let the two rooted matrix coefficient indices
in one layer be (alpha,beta) and (gamma,delta), and let
a,c be the actual directed anchors. Integrating c when
the coframes use a leaves
conj(D(a)[delta,alpha]) D(a)[gamma,beta]/d. Integrating a
when the coframes use c instead leaves
conj(D(c)[beta,gamma]) D(c)[alpha,delta]/d.
These are the two signed original alternatives. The
coframe moments retain the actual chirality and quaternion
coordinate labels on the occupied anchor.

## New product-representation source tensor and controls

The degree-two spin-one root projection from the prior
work is retained. The spin-half times spin-half matrix
is D=U_L⊗U_R, built from the literal canonical link.
If b_L,b_R are the original chiral coframe bivectors,
the cross term at a power-two root is
8(vec(q_L)·b_L)(vec(q_R)·b_R). Since
Tr((-i sigma_i)U)=2 q_i in the canonical source,
its coefficient on D is the tensor product of the two
imaginary-trace matrices, times two and the coframe
bivectors. The six trace identities are checked exactly
on source polynomials. The original 81 spin-one Schur
pair checks also rerun.

The new occupied-anchor product-channel moment has total
coordinate degree six, with denominator 16·192=3072
including the coframe quarters. Each endpoint orientation
preflights 565,248 products and collects 3,136 rows, of
which 960 have imaginary parts. The diagonal rotation
trace recovers the ordinary degree-two original edge
tensor entry by entry.

An independent direct raw Haar check expands
chi(a c) D(a†) D(c†) with the two original anchors still
distinct. It retains all coframe anchor alternatives and
does not use the empty-anchor shortcut. Six selected
entries across both endpoint orientations agree exactly
with the projected tensor and its inverse-dimension
factor. Examples include −1/64 and both signs of i/192.
Thus the product tensor was not replaced by its real
part or set to zero before sewing.

## Exact caching, measured width and tiled closure

The full 75-representative channel expansion reduces to
274 weighted cached terms and **25** distinct signed
coframe layer configurations. The cache uses the spatial
translations and axis permutations, with channel labels
transported with their actual edges. It also uses
simultaneous chirality exchange within a layer. Conjugation
by the source gamma_3 swaps the two SU(2) blocks and
reflects the internal vector labels. The bivector source
coefficients pick up the corresponding opposite signs,
which cancel in the even root products. The top changes
by the determinant of swaps of two two-dimensional
blocks, which is positive. The product channel's tensor
indices are permuted as well. The source check verifies
the bivector exchange phases. This is an invariance of a
complete decorated layer, rather than an assumption that
one selected channel label can be independently exchanged.

Each site partitions its original eight-generator top
among the degree-two and degree-four incident masks.
The initial all-partitions schedule exceeded its site
candidate cap for a product channel. The implemented
schedule chooses the sparsest incident mask pools first
and looks up the final mask as the exact complement.
Local inversion signs and complex coefficients are
retained. Sparse factor joins preflight matched products
and cap individual populated tables at 150,000 rows.
The final triangle closure has separate caps of four
million lookups and 150,000 resident input rows.

Two double-adjoint configurations exceeded the terminal
resident cap in both ordinary orders, at 194,112 rows.
The completed contraction tiles on the original shared
endpoint state numbered 17. It fixes generator-mask bit
0 to each of its two values. These restrictions partition
the exact finite sum, preserve all shared labels and
normalizations, and are added after contraction. The
two tiles require 148,176 and 56,304 resident triangle
rows and 1,880,064 and 626,688 lookups respectively.
For either channel the tile values are
2012212773/8388608 and 670737591/8388608, summing to
670737591/2097152. An independent partition using
generator bit 1 gives the same exact sum. One reversed
schedule for that alternative partition exceeded the
row cap. The ordinary-order bit-1 partition succeeded
within the same caps. No cap was raised to obtain the
value.

All seven cached layer contractions containing a product
channel have exact zero signed value. The direct
open-tensor controls above show that these zeros are
outcomes of the complete sewing, not a zero channel
input or a selection assumption. No global vanishing
theorem for that representation is claimed.

A reverse signed contraction checks a nonzero
two-adjoint layer. The one-active-vertex wedge omission
is an adverse orientation control and changes the
result. The full dispatcher reproduces the prior
overlapping pilot exactly. On the new two-overlap
representative (166856593410,166856593410), the actual
shared Haar gives 3493001097617547990681/281474976710656.
The independent-spatial scalar shortcut instead gives
54576062567037718281/4398046511104.

## Exact results and residual boundary

Every original exponential divisor m! is retained.
The original source coframe quarter and both normalized
anchor measures are already included in the edge
tensors. The prior orbit multiplicity is applied once
per complete representative.

The exact weighted subtotal for these final 75 orbits
is

```
1012068642997927782161928011277 / 1152921504606846976.
```

The 25-configuration run took about 22 seconds and
183 MB peak RSS. `exact.tsv` records the representative
values and orbit weights. `refused.tsv` is empty.

Joining the previous signed and exact-zero receipts
with this package produces a complete isolated-family
table. It contains **816 orbits and 67,590 labeled
occupations**, with **814 positive and two zero
orbits**. Its exact weighted subtotal is

```
2062712136557518696419296388255447513513827
/ 165431634479037188218552320000.
```

The full n=16 A-only/B-only temporal block still has
**10,994 unresolved orbits and 947,355 labeled coarse
survivors**. Those are the other temporal-core families,
not missing rows in this isolated-edge result.
No signed bound on those remaining occupations or
on the other connector-degree blocks has been derived.
The full c0 sign remains open.

## Reproduction

Use the exact primary checkout on PYTHONPATH with
its venv Python and PYTHONDONTWRITEBYTECODE=1 for
`spin_source.py`. Run `decorate_lr.py`,
`lr_control.py`, `batch.py`, `alternate_tile.py`,
`sign_control.py` and `totals.py` from this package.
The ordinary and spin-one tensor inputs come from
the frozen prior package. `census.py` replays the
75-representative geometry. `measure.py` records
the timing and RSS receipts. All outputs remain
scratch and require independent review.
