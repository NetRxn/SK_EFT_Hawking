from scalar import alive,classify
from family import edges
from collections import Counter
PILOT=(166856593410,8960795485785)
def situations(r):
    a,b,w,A,B,ca,cb,la,lb=r
    aa,bb=edges(A),edges(B)
    return [(e,ca[e],cb[e],aa.get(e,(0,0)),bb.get(e,(0,0))) for e in sorted(set(ca)&set(cb))
            if sum(aa.get(e,(0,0)))+sum(bb.get(e,(0,0)))]
def norm(e,A,B,u,v):
    t=[]
    for a,b,x,y in ((A,B,u,v),(B,A,v,u)):
        for z in (False,True):
            t.append((a[::-1],b[::-1],x[::-1],y[::-1]) if z else (a,b,x,y))
    return min(t)
res=[r for r in alive if classify(r)[0]!='admitted' and r[:2]!=PILOT]
assert len(res)==75 and sum(r[2] for r in res)==5664
if __name__=='__main__':
    c=Counter();o=Counter();examples={}
    for r in res:
        shape=tuple(sorted(norm(*x) for x in situations(r)))
        c[shape]+=1;o[shape]+=r[2]
        examples.setdefault(shape,r[:3])
    for k,v in c.most_common():print(v,o[k],k,examples[k])
