# Author evidence awaiting independent replay

All 75 remaining isolated dual-overlap cases are evaluated in this package. The complete isolated family table includes 816 orbits. The full temporal block and c0 remain open.
