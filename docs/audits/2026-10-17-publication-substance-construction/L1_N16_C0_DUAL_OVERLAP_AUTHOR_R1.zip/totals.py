from fractions import Fraction as F
from pathlib import Path
from family import isolated
base=Path('/private/tmp/l1-n16-c0-degree.1K9GzWW5')
leaf=Path('/private/tmp/l1-c0-q3-signed.1y0b5pA3')
core=Path('/private/tmp/l1-c0-core.1zohnyO1')
prev=Path('/private/tmp/l1-c0-isolated.TVUeNEzL')
isol={r[:2]:r[2] for r in isolated}
assert len(isol)==816 and sum(isol.values())==67590
def load(path):
    return {(int(a),int(b)):(int(w),F(x)) for a,b,w,x in (
        row.split() for row in path.read_text().splitlines())}
zero={(int(a),int(b)):(int(w),F(0)) for a,b,w in (
    row.split() for row in (core/'zero-orbits.tsv').read_text().splitlines())}
signed=[load(core/'signed-orbits.tsv'),load(prev/'scalar-values.tsv'),
        {(166856593410,8960795485785):(96,F(52271073647433042742089,140737488355328))},
        load(Path('exact.tsv'))]
catalog={}
for table in signed+[zero]:
    for k,(w,z) in table.items():
        if k not in isol:continue
        assert k not in catalog and isol[k]==w
        catalog[k]=(w,z)
assert set(catalog)==set(isol) and all(z>=0 for w,z in catalog.values())
print("complete isolated exact orbit and label totals",len(catalog),sum(w for w,z in catalog.values()))
print("isolated positive orbits",sum(z>0 for w,z in catalog.values()),
      "zero",sum(z==0 for w,z in catalog.values()))
print("complete isolated weighted subtotal",sum(w*z for w,z in catalog.values()))

known=set(zero)|set(load(base/'axis-values.tsv'))|set(load(leaf/'orbit-values.tsv'))
for table in signed:known|=set(table)
block={(int(a),int(b)):int(w) for a,b,w in (
    row.split() for row in (base/'orbits-slab.tsv').read_text().splitlines())}
assert known<=set(block)
left=set(block)-known
print("full temporal A-only/B-only residual",len(left),sum(block[k] for k in left))
Path("complete-isolated.tsv").write_text("".join(f"{a}\t{b}\t{w}\t{z}\n"
    for (a,b),(w,z) in sorted(catalog.items())))
