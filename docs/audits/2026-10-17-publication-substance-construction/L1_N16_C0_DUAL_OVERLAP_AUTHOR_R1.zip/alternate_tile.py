from fractions import Fraction as F
from network import network
key=(170078605314,(((2,3),0),((4,5),0)))
parts=[network(*key,tile=(17,1,b)) for b in (0,1)]
assert sum(parts)==F(670737591,2097152)
print("independent generator-bit-1 tiles",parts,"sum",sum(parts))
