from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations, product
from math import factorial, prod
from pathlib import Path
from core import decode

VERTEX_PRODUCTS=500_000
JOIN_PRODUCTS=2_000_000
ROW_CAP=150_000
MAX_BITS=256

E=defaultdict(list)
for d,word,u,v,r,i in (map(int,line.split()) for line in Path("edge.tsv").read_text().splitlines()):
    key=tuple((word>>(2*(d-1-k)))&3 for k in range(d))
    assert u.bit_count()==v.bit_count()==d and i==0
    E[key].append((u,v,r))
assert sum(map(len,E.values()))==428
W=[]
for a,b in product(range(4),repeat=2):
    if a!=b: W.append(((a,a),(b,b),1))
for a,b in combinations(range(4),2):
    W.append(((a,b),(a,b),-2))

def local(m):
    out={ ((),(),()):1 }
    for k,n in enumerate(m):
        assert n%2==0
        j,l=[a for a in range(3) if a!=k]
        for _ in range(n//2):
            nxt=Counter()
            for u,c in out.items():
                for a,b,z in W:
                    v=list(u)
                    v[j]=tuple(sorted(v[j]+a));v[l]=tuple(sorted(v[l]+b))
                    nxt[tuple(v)]+=c*z
            out={u:c for u,c in nxt.items() if c}
    return out

def sign(a,b):
    return (-1)**sum((b&((1<<i)-1)).bit_count() for i in range(8) if a>>i&1)

@lru_cache(None)
def fill(mask,degrees):
    if not degrees:return [()] if mask==0 else []
    want=degrees[0]
    if len(degrees)==1:
        return [(mask,)] if mask.bit_count()==want else []
    out=[]
    for slots in combinations([i for i in range(8) if mask>>i&1],want):
        sel=sum(1<<i for i in slots)
        for rest in fill(mask^sel,degrees[1:]):out.append((sel,*rest))
    return out

def factors(m,mutant=-1):
    h=[[sum(r)-x for x in r] for r in m]
    edges=[]
    inc=[[] for _ in m]
    scale=1
    for v in range(8):
        for k in range(3):
            w=v^(1<<k)
            if v>w or not(h[v][k]+h[w][k]):continue
            d=h[v][k]+h[w][k]
            assert d in (2,4) and min(h[v][k],h[w][k])==0
            owner=v if h[v][k] else w
            e=len(edges);edges.append((v,w,k,d,owner))
            inc[v].append(e);inc[w].append(e)
            scale*=64 if d==2 else 12288
    for v in range(8): assert sum(edges[e][3] for e in inc[v])==8
    all_factors=[]
    for v in range(8):
        owned=[e for e in inc[v] if edges[e][4]==v]
        incoming=[e for e in inc[v] if edges[e][4]!=v]
        assert len(owned)+len(incoming)==len(inc[v])
        ids=tuple(sorted(inc[v]))
        degrees=tuple(edges[e][3] for e in incoming)
        local_table=local(m[v])
        partition_count=max((len(fill(mask,degrees)) for mask in range(256) if mask.bit_count()==sum(degrees)),default=1)
        cap=sum(prod(len(E[labels[edges[e][2]]]) for e in owned)
                for labels in local_table)*max(1,partition_count)
        plans=[]
        planned=0
        for labels,z in local_table.items():
            choices=[E[labels[edges[e][2]]] for e in owned]
            if not incoming and len(owned)>=2:
                last=defaultdict(list)
                for item in choices[-1]:last[item[0]].append(item)
                planned+=prod(map(len,choices[:-1]))
                def prefixes(choices=choices,last=last):
                    for prefix in product(*choices[:-1]):
                        mask=0
                        for lo,_,_ in prefix:
                            if lo&mask:break
                            mask|=lo
                        else:
                            for item in last[255^mask]:yield (*prefix,item)
                plans.append((z,prefixes))
            else:
                planned+=prod(map(len,choices))*max(1,partition_count)
                plans.append((z,lambda choices=choices:product(*choices)))
        assert planned<=VERTEX_PRODUCTS,(v,planned,cap)
        out=Counter()
        products=0
        for z,plan in plans:
            for entries in plan():
                products+=1
                assert products<=VERTEX_PRODUCTS
                mask=0;c=z;remote={};own_masks={}
                for e,(lo,hi,x) in zip(owned,entries):
                    if mask&lo:break
                    mask|=lo;c*=x;remote[e]=hi;own_masks[e]=lo
                else:
                    for extras in fill(255^mask,degrees):
                        exterior={**own_masks,**dict(zip(incoming,extras))}
                        data={**remote,**dict(zip(incoming,extras))}
                        s=1;used=0
                        for e in ids:
                            s*=sign(used,exterior[e])
                            used|=exterior[e]
                        key=tuple(data[e] for e in ids)
                        out[key]+=c*(1 if v==mutant else s)
                        if len(out)>ROW_CAP: raise RuntimeError("vertex row cap")
        out={k:z for k,z in out.items() if z}
        print("vertex",v,"edge variables",ids,"unfiltered bound",cap,"preflight",planned,
              "actual emitted combinations",products,"rows",len(out))
        all_factors.append((ids,out))
    return all_factors,scale

def hist(a,shared):
    ids,table=a
    pick=tuple(ids.index(e) for e in shared)
    return Counter(tuple(k[i] for i in pick) for k in table)

def predict(a,b):
    shared=tuple(sorted(set(a[0])&set(b[0])))
    A,B=hist(a,shared),hist(b,shared)
    return sum(n*B[k] for k,n in A.items()),shared

def join(a,b,shared,work):
    assert work<=JOIN_PRODUCTS
    ha=max((abs(x).bit_length() for x in a[1].values()),default=0)
    hb=max((abs(x).bit_length() for x in b[1].values()),default=0)
    assert ha+hb+work.bit_length()<=MAX_BITS
    pa=[a[0].index(e) for e in shared];pb=[b[0].index(e) for e in shared]
    ids=tuple(sorted(set(a[0])^set(b[0])))
    keep=[(0,a[0].index(e)) if e in a[0] else (1,b[0].index(e)) for e in ids]
    groups=defaultdict(list)
    for k,z in b[1].items():groups[tuple(k[i] for i in pb)].append((k,z))
    out=Counter()
    for l,z in a[1].items():
        for r,w in groups[tuple(l[i] for i in pa)]:
            vals=(l,r)
            key=tuple(vals[s][i] for s,i in keep)
            out[key]+=z*w
            if len(out)>ROW_CAP:raise RuntimeError("join row cap")
    out={k:z for k,z in out.items() if z}
    print("join",a[0],b[0],"matched products",work,"frontier",ids,"rows",len(out))
    return ids,out

def run(code,mutant=-1,reverse=False):
    inputs,scale=factors(decode(code),mutant)
    if reverse:inputs.reverse()
    while len(inputs)>1:
        roster=[]
        for i,j in combinations(range(len(inputs)),2):
            w,s=predict(inputs[i],inputs[j])
            roster.append((not bool(s),w,i,j,s))
        _,w,i,j,s=min(roster)
        out=join(inputs[i],inputs[j],s,w)
        inputs=[x for k,x in enumerate(inputs) if k not in (i,j)]+[out]
    ids,final=inputs[0]
    assert not ids
    return F(final.get((),0),scale)

if __name__=="__main__":
    code=149259165705
    C=run(code)
    C2=run(code,reverse=True)
    wrong=run(code,mutant=0)
    assert C==C2 and C!=wrong
    print("canonical coframe Q3",C,"reverse-order",C2,"one wrong vertex",wrong)
    q=F(10**4)+F(2)+F(2,5**8)+F(16,3**12)
    exact=q*C**2/24**4
    assert exact>0
    print("shared curvature factor",q,"independent spatial control",10**4)
    print("original representative",exact,"orbit-weighted",24*exact)
