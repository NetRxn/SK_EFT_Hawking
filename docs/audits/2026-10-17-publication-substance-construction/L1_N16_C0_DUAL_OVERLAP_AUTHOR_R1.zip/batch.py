from collections import Counter
from contextlib import redirect_stdout
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import factorial,prod
from pathlib import Path
from core import decode,local
from family import co,edges
from scalar import perms,local_id
from census import res,situations
from network import network

@lru_cache(None)
def canonical(code,spec):
    m=decode(code)
    out=[]
    for perm in perms:
        axes=[sum(((v>>i)&1)<<perm[i] for i in range(3)) for v in range(8)]
        inds=[]
        for row in m:
            t=[0]*3
            for i,n in enumerate(row):t[perm[i]]=n
            inds.append(local_id(t))
        for shift in range(8):
            c=sum(n<<(6*(v^shift)) for n,v in zip(inds,axes))
            s=tuple(sorted((tuple(sorted((axes[u]^shift,axes[v]^shift))),j) for (u,v),j in spec))
            t=tuple((e,1-j if j<2 else j) for e,j in s)
            out.append((c,min(s,t)))
    return min(out)

def factors(r,scalar_only=False):
    a,b,w,A,B,ca,cb,la,lb=r
    ea,eb=edges(A),edges(B)
    mult=F(prod(co[x+y][0,0] for _,x,y in la+lb),prod(factorial(n) for row in A+B for n in row))
    options=[]
    for e in set(ca)|set(cb):
        pa,pb=ca.get(e,(0,0)),cb.get(e,(0,0))
        da,db=sum(ea.get(e,(0,0))),sum(eb.get(e,(0,0)))
        const=prod(co[n][0,0] for n in pa+pb)
        if not (sum(pa) and sum(pb)):
            assert min(da,db)<4
            mult*=const
        elif not (da or db):
            mult*=sum(prod(co[n].get((x,y),0) for n in pa+pb)/F(((2*x+1)*(2*y+1))**4)
                      for x,y in product(range(3),repeat=2))
        else:
            assert da in (0,2) and db in (0,2)
            row=[((),(),const)]
            if da and db:
                assert pa==pb==(2,2)
                row.extend(( ((e,j),),((e,j),),F(1,d**6)) for j,d in ((0,3),(1,3),(2,4)))
            elif da:
                assert pa==(2,2)
                wt=prod(3*co[n][1,0] for n in pb)/3**7
                row.extend((((e,j),),(),wt) for j in (0,1))
            else:
                assert pb==(2,2)
                wt=prod(3*co[n][1,0] for n in pa)/3**7
                row.extend(((),((e,j),),wt) for j in (0,1))
            options.append(row[:1] if scalar_only else row)
    keys=Counter()
    for choices in product(*options):
        left=tuple(sorted(x for row in choices for x in row[0]))
        right=tuple(sorted(x for row in choices for x in row[1]))
        factor=mult*prod(row[2] for row in choices)
        ka,kb=sorted((canonical(a,left),canonical(b,right)))
        keys[ka,kb]+=factor
    return keys
rosters={r[:2]:factors(r) for r in res}
configs=sorted({x for terms in rosters.values() for pair in terms for x in pair},
               key=lambda x:(len(x[1]),sum(j==2 for e,j in x[1]),x))
if __name__=='__main__':
    print("complete channel roster",len(configs),Counter(len(s) for a,s in configs),
          "compressed representative channel terms",sum(map(len,rosters.values())),flush=True)
    out={};refused={}
    for key in configs:
        try:
            value=network(*key)
            print("canonical channel",key,value,flush=True)
            out[key]=value
        except RuntimeError as e:
            print("untiled refusal",key,e,flush=True)
            if key[0]==170078605314 and key[1] in (
                (((2,3),0),((4,5),0)), (((2,3),0),((4,5),1))
            ):
                try:
                    tiles=[network(*key,tile=(17,0,v)) for v in (0,1)]
                    value=sum(tiles)
                    assert value==F(670737591,2097152)
                    out[key]=value
                    print("canonical tiled channel",key,tiles,value,flush=True)
                    continue
                except RuntimeError as error:
                    e=error
            refused[key]=str(e)
            print("capped channel",key,e,flush=True)
    weights={r[:2]:r[2] for r in res}
    exact=[];unknown=[]
    for (a,b),terms in rosters.items():
        w=weights[a,b]
        if any(k not in out for p in terms for k in p):
            unknown.append((a,b,w));continue
        z=sum(f*out[x]*out[y] for (x,y),f in terms.items())
        exact.append((a,b,w,z))
    from scalar import alive
    pilot=next(r for r in alive if r[:2]==(166856593410,8960795485785))
    z=sum(f*out[x]*out[y] for (x,y),f in factors(pilot).items())
    assert z==F(52271073647433042742089,140737488355328)
    print("prior overlapping pilot with complete dispatcher",z)
    target=next(r for r in res if r[:2]==(166856593410,166856593410))
    actual=sum(f*out[x]*out[y] for (x,y),f in factors(target).items())
    shortcut=sum(f*out[x]*out[y] for (x,y),f in factors(target,True).items())
    assert actual!=shortcut
    print("two-overlap representative with actual shared Haar",target[:3],actual,
          "scalar-only shortcut",shortcut)
    print("completed channel configurations",len(out),"refused",len(refused))
    print("exact orbits",len(exact),"labeled",sum(r[2] for r in exact),
          "signs",dict(Counter((x>0)-(x<0) for a,b,w,x in exact)))
    print("unresolved orbits",len(unknown),"labeled",sum(r[2] for r in unknown))
    print("exact weighted subtotal",sum(w*z for a,b,w,z in exact))
    Path("exact.tsv").write_text("".join(f"{a}\t{b}\t{w}\t{z}\n" for a,b,w,z in exact))
    Path("refused.tsv").write_text("".join(f"{a}\t{b}\t{w}\n" for a,b,w in unknown))
    Path("channels.tsv").write_text("".join(f"{a}\t{s}\t{out[a,s]}\n" for a,s in out))
