from collections import Counter
from pathlib import Path
from itertools import product
prior=Path('/private/tmp/l1-n16-c0-degree.1K9GzWW5')
local=[(a,b,c) for a in range(5) for b in range(5-a) for c in range(5-a-b)]
def decode(code):return [local[(code>>(6*v))&63] for v in range(8)]
def strip(m):
    edges={(u,u^(1<<k)):(m[u][k],m[u^(1<<k)][k]) for u in range(8) for k in range(3)
           if u<(u^(1<<k)) and (m[u][k] or m[u^(1<<k)][k])}
    removed=[]
    while edges:
        degree=Counter(v for e in edges for v in e)
        leaf=next((e for e,(a,b) in sorted(edges.items()) if min(degree[e[0]],degree[e[1]])==1 and min(a,b)==0),None)
        if leaf is None:break
        a,b=edges.pop(leaf);assert (a+b)%2==0
        removed.append((leaf,a,b))
    return edges,removed
def comps(edges):
    unused=set(v for e in edges for v in e);out=[]
    while unused:
        c={min(unused)}
        while True:
            d=c|{v for e in edges if c.intersection(e) for v in e}
            if d==c:break
            c=d
        unused-=c
        out.append({e:p for e,p in edges.items() if c.intersection(e)})
    return out
def shape(c):
    V=Counter(v for e in c for v in e)
    return (len(V),len(c),tuple(sorted(V.values())))
def ef(c):
    return tuple(sorted(tuple(sorted(pair)) for pair in c.values()))
old={tuple(map(int,row.split()[:2])) for row in (prior/'axis-values.tsv').read_text().splitlines()}
old|={tuple(map(int,row.split()[:2])) for row in Path('/private/tmp/l1-c0-q3-signed.1y0b5pA3/orbit-values.tsv').read_text().splitlines()}
residual=[]
for a,b,n in (map(int,row.split()) for row in (prior/'orbits-slab.tsv').read_text().splitlines()):
    if (a,b) in old:continue
    A,B=decode(a),decode(b)
    ca,la=strip(A);cb,lb=strip(B)
    residual.append((a,b,n,A,B,ca,cb,la,lb))
assert len(residual)==11889 and sum(r[2] for r in residual)==1020621
if __name__=='__main__':
    count=Counter(); efcount=Counter(); comps_count=Counter(); examples={}
    for a,b,n,A,B,ca,cb,la,lb in residual:
        types=tuple(sorted(tuple(sorted(shape(c) for c in comps(edges))) for edges in (ca,cb)))
        count[types]+=1
        examples.setdefault(types,(a,b,n,A,B,ca,cb,la,lb))
        for c in comps(ca)+comps(cb):
            comps_count[shape(c)]+=1
            efcount[(shape(c),ef(c))]+=1
    print('top shape pairs')
    for t,n in count.most_common(18):print(n,t)
    print('top components',comps_count.most_common(15))
    print('top labeled components',efcount.most_common(20))
    for t,n in count.most_common(6):print('example',t,examples[t])
