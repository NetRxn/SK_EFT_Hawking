from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import prod
from pathlib import Path
from coframe import sign

Q=defaultdict(list)
for x,a,m,q,r,i in (map(int,s.split()) for s in Path("edge_coframes.tsv").read_text().splitlines()):
    Q[x,a].append((m,q,r,i))
R=defaultdict(list)
for a,b,i,j,c in (map(int,s.split()) for s in Path("adjoint.tsv").read_text().splitlines()):
    R[a,b].append((i,j,c))

@lru_cache(None)
def moment(key):
    ex=[key.count(k) for k in range(4)]
    if any(k%2 for k in ex):return F(0)
    return F(prod(prod(range(1,k,2)) for k in ex),prod(range(4,4+len(key),2)))

@lru_cache(None)
def coefficient(a,b,c,d,q0,q1,schur_chi):
    i,j=q0%4,q1%4
    assert q0//4==q1//4
    extra=(i,j) if (q0//4)%2==schur_chi else ()
    separate=F(1) if extra else moment(tuple(sorted((i,j))))
    val=0
    for v,w,x in R[a,b]:
        for y,z,t in R[c,d]:
            val+=x*t*moment(tuple(sorted((v,w,y,z,*extra))))
    res=val*separate*192
    assert res.denominator==1
    return int(res)

def decorate(owner,chi):
    pairs=defaultdict(lambda:[0,0])
    for a in range(4):
      for b in range(a,4):
        for (u,q,r,i),(v,p,s,j) in product(Q[owner,a],Q[owner,b]):
            if u&v or q//4!=p//4:continue
            key=(4*a+b,(u|v)&255,(u|v)>>8,min(q,p),max(q,p))
            phase=(-1)**sum((v&((1<<i)-1)).bit_count() for i in range(16) if u>>i&1)
            pairs[key][0]+=(r*s-i*j)*phase
            pairs[key][1]+=(r*j+i*s)*phase
    pairs={k:z for k,z in pairs.items() if any(z)}
    assert all(sum(map(abs,z))<4096 for z in pairs.values())
    out=defaultdict(lambda:[0,0])
    assert len(pairs)*81<=1_000_000
    for (l,u,v,q,p),z in pairs.items():
        for a,b,c,d in product(range(3),repeat=4):
            r=coefficient(d,a,c,b,q,p,chi) if q<8 else coefficient(a,d,b,c,q,p,chi)
            if r:
                out[l,u,v,3*a+b,3*c+d][0]+=z[0]*r
                out[l,u,v,3*a+b,3*c+d][1]+=z[1]*r
    out={k:tuple(v) for k,v in out.items() if any(v)}
    plain=Counter()
    for d,l,m,n,r,i in (map(int,s.split()) for s in Path('edge.tsv').read_text().splitlines()):
        if d!=2:continue
        assert i==0
        plain[l,m,n] = r*48
    for d in range(3):
        contracted=defaultdict(lambda:[0,0])
        for (l,u,v,p,q),z in out.items():
            if p%4==0 and q==4*d:
                key=(l,u,v) if owner==0 else (l,v,u)
                contracted[key][0]+=z[0]; contracted[key][1]+=z[1]
        assert {k:tuple(z) for k,z in contracted.items() if any(z)}=={
            k:(z,0) for k,z in plain.items()}
    print('decorated owner',owner,'chi',chi,'quadratic records',len(pairs),'Haar rows',len(out))
    return out

if __name__=='__main__':
    for owner,chi in product(range(2),repeat=2):
        out=decorate(owner,chi)
        Path(f'decorated-{owner}-{chi}.tsv').write_text(''.join(
            '\t'.join(map(str,(*k,*v)))+'\n' for k,v in sorted(out.items())))
