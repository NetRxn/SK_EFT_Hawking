from fractions import Fraction as F
from network import network
key=(166856593410,(((2,3),0),((4,5),0)))
a=network(*key,reverse=True)
b=network(*key,mutant=4)
assert a==F(820840149,2097152) and a!=b
print("two-edge channel canonical reverse",a,"one active vertex wedge omission",b)
