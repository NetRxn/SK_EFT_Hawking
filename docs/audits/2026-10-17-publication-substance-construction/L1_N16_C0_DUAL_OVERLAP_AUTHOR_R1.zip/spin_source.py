from fractions import Fraction as F
from itertools import product
from pathlib import Path
from src.core.formulas import original_spin4_link, original_quaternion_haar_moment
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, QComplex, Symbol, matrix_multiply, matrix_dagger

reg=OriginalRegulator(temporal_axis=0)
x=(0,0,0,0)
q=[tuple(Symbol("q",(x,0,chi,i)) for i in range(4)) for chi in ("L","R")]
U=original_spin4_link(*(tuple(Polynomial.variable(s) for s in row) for row in q))
gamma=reg.gamma
b=[]
for A,B in product(range(4),repeat=2):
    if A==B:continue
    O=matrix_multiply(matrix_multiply(gamma[A],gamma[B]),reg.gamma5)
    f=sum((U[i][j]*O[j][i] for i,j in product(range(4),repeat=2)),Polynomial())
    for key,c in f.terms:
        s,=key
        assert c.imag==0 and abs(c.real)==2 and s.index[-1]>0
        b.append((int(s.index[-2]=="R"),A,B,s.index[-1]-1,int(c.real/2)))
assert len(b)==24
i=QComplex(0,1)
sigma=[((0,1),(1,0)),((0,-i),(i,0)),((1,0),(0,-1))]
u=tuple(tuple(U[a][c] for c in range(2)) for a in range(2))
r=[]
R={}
for a,c in product(range(3),repeat=2):
    p=matrix_multiply(matrix_multiply(matrix_multiply(sigma[a],u),sigma[c]),matrix_dagger(u))
    pol=(p[0][0]+p[1][1])*F(1,2)
    R[a,c]=pol
    for key,z in pol.terms:
        assert len(key)==2 and z.imag==0 and z.real.denominator==1
        r.append((a,c,*[s.index[-1] for s in key],int(z.real)))
def integrate(p):
    return sum(z.real*original_quaternion_haar_moment(tuple(sum(s.index[-1]==i for s in key)
               for i in range(4))) for key,z in p.terms)
for a,b1,c,d in product(range(3),repeat=4):
    assert integrate(R[a,b1]*R[c,d])==F(int(a==c and b1==d),3)
for a,c in product(range(3),repeat=2):
    v=Polynomial.variable(q[0][a+1])*Polynomial.variable(q[0][c+1])
    expected=2*(R[a,c]+R[c,a])*F(1,2)
    if a==c:
        expected+=sum((Polynomial.variable(s)*Polynomial.variable(s) for s in q[0]),Polynomial())
        expected-=sum((R[j,j] for j in range(3)),Polynomial())
    assert 4*v==expected
def write(name,rows):
    Path(name).write_text("".join("\t".join(map(str,v))+"\n" for v in rows))
write("bivectors.tsv",b)
write("adjoint.tsv",r)
print("literal bivectors",len(b),"adjoint terms",len(r),"degree-two projection and all 81 Schur pairs checked")

# Fundamental product representation and imaginary-coordinate extraction.
cross=[]
for a,b,c,d in product(range(2),repeat=4):
    pol=U[a][b]*U[c+2][d+2]
    for key,z in pol.terms:
        x,y=key
        assert x.index[-2]=="L" and y.index[-2]=="R"
        assert z.real.denominator==z.imag.denominator==1
        cross.append((2*a+c,2*b+d,x.index[-1],4+y.index[-1],int(z.real),int(z.imag)))
inv=[]
for i in range(3):
    for a,b in product(range(2),repeat=2):
        # Coefficient of U[a,b] in Tr(-i sigma_i U).
        z=QComplex(0,-1)*sigma[i][b][a]
        if z:inv.append((i,a,b,int(z.real),int(z.imag)))
write("fundamental-product.tsv",cross)
write("imaginary-trace.tsv",inv)
print("fundamental product source terms",len(cross),"imaginary-trace entries",len(inv))

for chi,i in product(range(2),range(3)):
    back=sum((U[a+2*chi][b+2*chi]*QComplex(r,s) for j,a,b,r,s in inv if i==j),Polynomial())
    assert back==2*Polynomial.variable(q[chi][i+1])
print("all six literal imaginary-coordinate trace identities checked")
