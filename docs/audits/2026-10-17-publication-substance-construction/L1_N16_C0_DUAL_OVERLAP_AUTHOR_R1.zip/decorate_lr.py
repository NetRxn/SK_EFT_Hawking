from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path
from decorate import Q,moment

R=defaultdict(list)
for a,b,i,j,r,s in (map(int,z.split()) for z in Path('fundamental-product.tsv').read_text().splitlines()):
    R[a,b].append((i,j,r,s))

@lru_cache(None)
def h(a,b,c,d,q0,q1):
    # D[a,b]^* D[c,d] on the occupied original anchor.
    rr=ii=F(0)
    for (u,v,r,i),(w,x,s,j) in product(R[a,b],R[c,d]):
        key=(u,v,w,x,q0%8,q1%8)
        l=tuple(sorted(k for k in key if k<4))
        Rq=tuple(sorted(k-4 for k in key if k>=4))
        z=192*moment(l)*moment(Rq)
        rr+=(r*s+i*j)*z;ii+=(r*j-i*s)*z
    assert rr.denominator==ii.denominator==1
    return int(rr),int(ii)

def make(owner):
    pairs=defaultdict(lambda:[0,0])
    for a in range(4):
        for b in range(a,4):
            for (u,q,r,i),(v,p,s,j) in product(Q[owner,a],Q[owner,b]):
                if u&v or q//4!=p//4:continue
                mask=u|v
                k=(4*a+b,mask&255,mask>>8,min(q,p),max(q,p))
                phase=(-1)**sum((v&((1<<i)-1)).bit_count() for i in range(16) if u>>i&1)
                pairs[k][0]+=(r*s-i*j)*phase;pairs[k][1]+=(r*j+i*s)*phase
    pairs={k:v for k,v in pairs.items() if any(v)}
    assert len(pairs)*4**4<=1_000_000
    out=defaultdict(lambda:[0,0])
    for (l,u,v,q,p),(r,i) in pairs.items():
        for a,b,c,d in product(range(4),repeat=4):
            x,y=h(d,a,c,b,q,p) if q<8 else h(b,c,a,d,q,p)
            if x or y:
                t=out[l,u,v,4*a+b,4*c+d]
                t[0]+=r*x-i*y;t[1]+=r*y+i*x
    out={k:tuple(v) for k,v in out.items() if any(v)}
    plain={}
    for d,l,m,n,r,i in (map(int,s.split()) for s in Path('edge.tsv').read_text().splitlines()):
        if d==2:plain[l,m,n]=(r*48,i*48)
    for d in range(4):
        chk=defaultdict(lambda:[0,0])
        for (l,u,v,a,b),z in out.items():
            if a%5==0 and b==5*d:
                x=chk[(l,u,v) if owner==0 else (l,v,u)]
                x[0]+=z[0];x[1]+=z[1]
        assert {k:tuple(v) for k,v in chk.items() if any(v)}==plain
    print('product channel owner',owner,'quadratic records',len(pairs),'preflight',len(pairs)*256,
          'collected rows',len(out),'imaginary rows',sum(v[1]!=0 for v in out.values()))
    return out
if __name__=='__main__':
    for owner in range(2):
        data=make(owner)
        Path(f'decorated-{owner}-2.tsv').write_text(''.join(
            '\t'.join(map(str,(*k,*v)))+'\n' for k,v in sorted(data.items())))
