from collections import defaultdict
from fractions import Fraction
from itertools import product
import json
from src.vestigial.original_coefficients import OriginalRegulator, assemble_dirac

# Work with exact Gaussian dyadics. Only add/multiply signed units and quarters.
def pauli(k):
    return (((0, 1), (1, 0)), ((0, -1j), (1j, 0)), ((1, 0), (0, -1)))[k]

def gamma(k):
    q = [[-1j * v for v in row] for row in pauli(k)] if k < 3 else ((1, 0), (0, 1))
    return [[q[i][j-2] if i < 2 <= j else q[j][i-2].conjugate() if j < 2 <= i else 0
             for j in range(4)] for i in range(4)]

def q_basis(chirality, component):
    basis = ((1, 0), (0, 1)) if component == 0 else [[1j * v for v in row] for row in pauli(component-1)]
    start = 0 if chirality == 'L' else 2
    return [[basis[i-start][j-start] if start <= i < start+2 and start <= j < start+2 else 0
             for j in range(4)] for i in range(4)]

def dagger(m):
    return [[m[j][i].conjugate() for j in range(4)] for i in range(4)]

def mul(a, b, i, j):
    return sum(a[i][k]*b[k][j] for k in range(4))

def key(family, index):
    return (family, index, False)

counts = dict(fixtures=0, entries=0, symbolic_terms=0, cancellations=0)
for dims, signs, convention in product(((1, 1, 1, 1), (2, 1, 2, 1), (3, 2, 1, 1)),
                                        ((1, 1, 1, 1), (-1, 1, -1, -1)),
                                        ('source_C', 'metric_M')):
    reg = OriginalRegulator(dims, signs, convention)
    sites = list(product(*(range(d) for d in dims)))
    offsets = {x: 4 * k for k, x in enumerate(sites)}
    expected = defaultdict(lambda: defaultdict(complex))
    for x, mu, a in product(sites, range(4), range(4)):
        f = tuple((v+1) % dims[j] if j == mu else v for j, v in enumerate(x))
        b = tuple((v-1) % dims[j] if j == mu else v for j, v in enumerate(x))
        sf = signs[mu] if x[mu] == dims[mu]-1 else 1
        sb = signs[mu] if x[mu] == 0 else 1
        g = gamma(a if convention == 'source_C' else (3, 0, 1, 2)[a])
        for c, k in product(('L', 'R'), range(4)):
            q = q_basis(c, k)
            for row, col, anchor, sign, left, right in (
                (x, f, x, sf, g, dagger(q)), (f, x, x, -sf, q, g),
                (x, b, b, -sb, g, q), (b, x, b, sb, dagger(q), g)):
                for i, j in product(range(4), repeat=2):
                    v = sign * mul(left, right, i, j) / 4
                    if v:
                        for family in ('h', 'J'):
                            monomial = frozenset((key(family, (x, mu, a)), key('q', (anchor, mu, c, k))))
                            expected[offsets[row]+i, offsets[col]+j][monomial] += v
    actual = assemble_dirac(reg)
    for i, j in product(range(4*len(sites)), repeat=2):
        terms = {frozenset((s.family, s.index, s.conjugated) for s in m): (v.real, v.imag)
                 for m, v in actual.at(i, j).terms}
        value = expected[i, j]
        oracle = {k: (Fraction(v.real), Fraction(v.imag)) for k, v in value.items() if v}
        assert terms == oracle, (dims, signs, convention, i, j, terms, oracle)
        counts['entries'] += 1
        counts['symbolic_terms'] += len(oracle)
        counts['cancellations'] += len(value) - len(oracle)
    counts['fixtures'] += 1
print(json.dumps(counts))
