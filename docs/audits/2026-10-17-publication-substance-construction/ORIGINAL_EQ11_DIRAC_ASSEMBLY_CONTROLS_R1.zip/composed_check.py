"""Exact dyadic unit-extent, coincidence, determinant and C2 controls."""
from fractions import Fraction
from itertools import permutations, product
from collections import defaultdict, Counter
import json
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, QComplex, assemble_dirac, determinant_jet,
)

I = 1j
Z = (0, 0, 0, 0)
GAMMA = (
    ((0,0,0,-I), (0,0,-I,0), (0,I,0,0), (I,0,0,0)),
    ((0,0,0,-1), (0,0,1,0), (0,1,0,0), (-1,0,0,0)),
    ((0,0,-I,0), (0,0,0,I), (I,0,0,0), (0,-I,0,0)),
    ((0,0,1,0), (0,0,0,1), (1,0,0,0), (0,1,0,0)),
)
LINKS = (
    ((I,0,0,0),(0,-I,0,0),(0,0,1,0),(0,0,0,1)),
    ((0,1,0,0),(-1,0,0,0),(0,0,I,0),(0,0,0,-I)),
    ((1,0,0,0),(0,1,0,0),(0,0,0,I),(0,0,I,0)),
    (((1+I)/2,(1+I)/2,0,0),((-1+I)/2,(1-I)/2,0,0),
     (0,0,-1,0),(0,0,0,-1)),
)
def comp(z):
    return QComplex(Fraction(z.real), Fraction(z.imag))

def mul(A,B,i,j):
    return sum(A[i][k]*B[k][j] for k in range(4))

def unit_hop(mu,a,signs,convention):
    # All four endpoints coincide. Factoring the four terms gives
    # sign*(gamma*(U†-U)+(U†-U)*gamma)/4 independently of scatter.
    g = GAMMA[a if convention == 'source_C' else (3,0,1,2)[a]]
    u = LINKS[mu]
    v = [[u[j][i].conjugate()-u[i][j] for j in range(4)] for i in range(4)]
    return [[signs[mu]*(mul(g,v,i,j)+mul(v,g,i,j))/4 for j in range(4)]
            for i in range(4)]

def det_slots(m,a,b):
    # Expand the ordinary polynomial det(M+t A+s B) directly by
    # Leibniz permutations. The diagonal raw second derivative is 2 c2.
    out = defaultdict(complex)
    for p in permutations(range(4)):
        sign = (-1)**sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))
        for selections in product(range(3),repeat=4):
            e = selections.count(1), selections.count(2)
            if sum(e) <= 2:
                term = sign
                for i,t in enumerate(selections):
                    term *= (m,a,b)[t][i][p[i]]
                out[e] += term
    return [out[0,0],out[1,0],out[0,1],2*out[2,0],out[1,1],2*out[0,2]]

total = Counter()
for convention, signs, trial in product(('source_C','metric_M'),((1,1,1,1),(-1,-1,-1,-1),(-1,1,-1,1)),range(5)):
    reg = OriginalRegulator((1,1,1,1),signs,convention)
    links = {(Z,mu): [[comp(v) for v in row] for row in u] for mu,u in enumerate(LINKS)}
    h = {(Z,mu,a): ((3*mu+2*a+trial)%5)-2 for mu,a in product(range(4),repeat=2)}
    J = {k: -v if trial == 0 else (1+I if k[1] == trial-1 else 0) for k,v in h.items()}
    weights = {k: h[k]+J[k] for k in h}
    actual = assemble_dirac(reg, {k:comp(v) for k,v in weights.items()}, links)
    hops = {k: unit_hop(k[1],k[2],signs,convention) for k in h}
    base = [[sum(weights[k]*hop[i][j] for k,hop in hops.items()) for j in range(4)] for i in range(4)]
    for i,j in product(range(4),repeat=2):
        assert actual.at(i,j)==Polynomial.scalar(comp(base[i][j])), (convention,signs,trial,i,j)
        total['entries']+=1
    for pair in (((Z,0,3),(Z,0,3)),((Z,0,3),(Z,3,1)),((Z,1,0),(Z,2,3))):
        inc = tuple(assemble_dirac(reg,{k:1},links) for k in pair)
        result = determinant_jet(actual, inc).slots()
        oracle = det_slots(base,*(hops[k] for k in pair))
        assert result==tuple(Polynomial.scalar(comp(v)) for v in oracle), (convention,signs,trial,pair)
        total['jet_cases']+=1
        total['jet_slots']+=len(oracle)
        total['nonzero_second_slots']+=sum(bool(v) for v in oracle[3:])
        total['nonzero_mixed_slots']+=bool(oracle[4])
        total['repeated_coordinates']+=pair[0]==pair[1]
        total['singular_value_cases']+=trial==0
print(json.dumps(total,sort_keys=True))
