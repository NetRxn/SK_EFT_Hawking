from collections import Counter,defaultdict
from fractions import Fraction
from math import factorial,lcm,prod
from pathlib import Path
import os,sys,types

folder=Path(sys.argv[1]).resolve()
a,b=(103607566400,9912822792210)
os.environ['L1_PROFILE_CODES']=f'{a},{b}'
source=(folder/'compact-boundary.py').read_text().split('degree=Counter(',1)[0]
ids={int(l.split()[0]) for l in (folder/'anchor-plan.tsv').read_text().splitlines()}
assert len(ids)==4
def read(case):
    m=types.ModuleType(f'_original_{case}')
    sys.modules[m.__name__]=m
    sys.argv=[sys.argv[0],str(folder),str(folder),str(case)]
    exec(source,m.__dict__)
    return m
cases=[read(i) for i in sorted(ids)]
active={k for case in cases for k in case.states
        if len({c.states.get(k,(0,0)) for c in cases})>1}
records=defaultdict(list)
def scope(f):
    kinds,*raw=f.name
    t,x,*tail=map(int,raw)
    if kinds in ('M','C'):
        return {(u,y,k) for u in range(2) for k in range(3) for y in (x,x^(1<<k))}
    if kinds=='T':
        return {(t,y,k) for k in range(3) for y in (x,x^(1<<k))}
    assert kinds=='E'
    k,=tail
    return {(u,y,k) for u in range(2) for y in (x,x^(1<<k))}
for c in cases:
    for f in c.factors:
        keys=tuple(sorted(active&scope(f)))
        labels=tuple(c.states.get(k,(0,0)) for k in keys)
        records[f.name].append((keys,labels,f))
def tagged(variants):
    ks=variants[0][0]
    assert all(keys==ks for keys,_,_ in variants)
    # Zero is the only value of a physical wire omitted in an irrep.
    physical=tuple(sorted({v for _,_,f in variants for v in f.wires}))
    den=lcm(*(f.denom for _,_,f in variants))
    by_label={}
    for _,label,f in variants:
        slots={wire:i for i,wire in enumerate(f.wires)}
        scale=den//f.denom
        block={tuple(row[slots[w]] if w in slots else 0 for w in physical):(r*scale,n*scale)
               for row,(r,n) in f.rows.items()}
        assert len(block)==len(f.rows)
        seen=by_label.setdefault(label,block)
        assert seen==block,(f.name,label)
    return tuple(('L',*k) for k in ks)+physical,{label+row:z for label,block in by_label.items() for row,z in block.items()},den
factors=[tagged(v) for v in records.values()]
# This control uses the full local views, whose natural join is exactly
# the four original supported states. Check that explicitly.
sv=[set(active&scope(e[0][2])) for e in records.values()]
domains={k:{c.states.get(k,(0,0)) for c in cases} for k in active}
from itertools import product
axes=tuple(sorted(active))
choices=prod(len(domains[k]) for k in axes)
assert choices<=65536
tables=[(tuple(sorted(group)),{tuple(c.states.get(k,(0,0)) for k in sorted(group)) for c in cases}) for group in sv if group]
supported=0
for combo in product(*(domains[k] for k in axes)):
    mapping=dict(zip(axes,combo))
    supported+=all(tuple(mapping[k] for k in kk) in relation for kk,relation in tables)
assert supported==len(ids)
print('bundle',len(factors),'representation axes',len(active),'initial rows',sum(len(r) for _,r,_ in factors),'support',supported,flush=True)

def hist(f,shared):
    axes,rows,d=f
    pos=tuple(axes.index(k) for k in shared)
    return Counter(tuple(row[i] for i in pos) for row in rows)
def score(i,j,factors,degree):
    a,b=factors[i],factors[j]
    shared=tuple(k for k in a[0] if k in b[0])
    union=set(a[0])|set(b[0])
    closed=sum(degree[k]==(2 if k in shared else 1) for k in union)
    # First pick by cheap size proxy. Compute exact work only for shortlisted joins.
    return len(a[1])*len(b[1])*(1+len(union)-closed),i,j,shared
def intersect_targets(factors, focus=None):
    from itertools import combinations
    pairs=[(i,j) for i,j in combinations(range(len(factors)),2)
           if focus is None or focus in (i,j)]
    for i,j in pairs:
        la,lr,_=factors[i]
        ra,rr,_=factors[j]
        shared=tuple(k for k in la if k in ra)
        if not shared:
            continue
        li=tuple(la.index(k) for k in shared)
        ri=tuple(ra.index(k) for k in shared)
        left={tuple(row[u] for u in li) for row in lr}
        right={tuple(row[u] for u in ri) for row in rr}
        if left!=right:
            allowed=left&right
            for rows,positions,found in ((lr,li,left),(rr,ri,right)):
                if allowed!=found:
                    for row in list(rows):
                        if tuple(row[u] for u in positions) not in allowed:
                            del rows[row]

peak=max(len(r) for _,r,_ in factors)
intersect_targets(factors)
intersect_targets(factors)
work=0
while len(factors)>1:
    degree=Counter(k for axes,_,_ in factors for k in axes)
    from itertools import combinations
    candidates=sorted(score(i,j,factors,degree) for i,j in combinations(range(len(factors)),2))
    linked=[x for x in candidates if x[3]]
    candidates=(linked or candidates)[:12]
    costs=[]
    for _,i,j,shared in candidates:
        ah,bh=hist(factors[i],shared),hist(factors[j],shared)
        matched=sum(n*bh[k] for k,n in ah.items())
        union=set(factors[i][0])|set(factors[j][0])
        width=sum(degree[k]>(2 if k in shared else 1) for k in union)
        costs.append((matched*(1+width)**2,matched,i,j,shared))
    _,matched,i,j,shared=min(costs)
    assert matched<=8_000_000 and work+matched<=40_000_000,('products',len(factors),matched,work)
    work+=matched
    la,lr,ld=factors[i]
    ra,rr,rd=factors[j]
    li=[la.index(k) for k in shared]
    ri=[ra.index(k) for k in shared]
    left=[u for u,k in enumerate(la) if degree[k]>(2 if k in shared else 1)]
    right=[u for u,k in enumerate(ra) if k not in la and degree[k]>1]
    keys=tuple(la[u] for u in left)+tuple(ra[u] for u in right)
    lookup=defaultdict(list)
    for row,z in rr.items():
        lookup[tuple(row[u] for u in ri)].append((tuple(row[u] for u in right),z))
    out={}
    for row,(x,y) in lr.items():
        base=tuple(row[u] for u in left)
        for tail,(a0,b0) in lookup[tuple(row[u] for u in li)]:
            k=base+tail
            r,n=out.get(k,(0,0))
            z=r+x*a0-y*b0,n+x*b0+y*a0
            if any(z):
                assert k in out or len(out)<500000,('rows',len(factors),matched)
                out[k]=z
            else:
                out.pop(k,None)
    factors.pop(j)
    factors.pop(i)
    factors.append((keys,out,ld*rd))
    intersect_targets(factors,len(factors)-1)
    if len(factors)%8==0:
        intersect_targets(factors)
    peak=max(peak,len(out))
    print('join',len(factors),matched,len(out),'axes',len(keys),flush=True)
axes,scalar,den=factors[0]
assert not axes
c=cases[0]
world=sum((3+k)*n for row in c.occ for o in row for k,n in enumerate(o))
cross=0
for m in c.occ:
    weighted=[(u,v,sum(m[u])-m[u][k]+sum(m[v])-m[v][k]) for u,v,k in c.edges]
    cross+=sum(a[2]*b[2]*(u>v) for i,a in enumerate(weighted) for b in weighted[i+1:]
               for u in a[:2] for v in b[:2])
phase=(-1)**((world+cross)%2)
total=sum(n for m in c.occ for row in m for n in row)
assert total==32
norm=den*prod(factorial(p) for m in c.occ for o in m for p in o)*4**(2*total)
re,im=scalar.get((),(0,0))
actual=Fraction(phase*re,norm)
assert im==0 and actual==Fraction('4981785870330086965576171875/316912650057057350374175801344')
print('exact normalized',actual,'peak rows',peak,'matched products',work)
