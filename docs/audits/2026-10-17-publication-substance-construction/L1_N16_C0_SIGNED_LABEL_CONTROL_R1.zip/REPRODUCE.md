# Signed representation-label contraction control

Run `python3 signed-label-join.py FULL_FOUR_ASSIGNMENT_RUN_DIRECTORY`
against the four frozen original input factors. The author run deliberately
emits actual factors for all four support states. Initial tensors are
tagged by the representation labels relevant to that factor. For repeated
local labels, the physical factors agree exactly and are inserted once.
Omitted physical indices are fixed to zero. The natural join of local
label supports is checked against the complete roster. Representation axes
whose partitions of the support are identical are identified bijectively.

The successful schedule prunes incompatible projected rows and prioritizes
joins that share physical indices. It carries signed complex integers and
exact denominators and closes labels at their last incidence. The final
scalar retains the original common normalization, phase, factorial and
quarter factors. The coefficient matches the existing independent result.

The earlier schedules hit the declared 500,000 intermediate row cap.
The successful schedule peaks at 147,200 rows and 10,066,196 matched products
on this control. It still generates original local factors from four
separately supplied support assignments. Dense generation without that
enumeration and an independent review of the new route remain outstanding.
