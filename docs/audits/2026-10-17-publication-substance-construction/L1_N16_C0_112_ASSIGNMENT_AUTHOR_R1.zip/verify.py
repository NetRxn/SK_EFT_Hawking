from collections import Counter,defaultdict
from fractions import Fraction
from pathlib import Path
def read(p):
    out=defaultdict(set)
    for row in Path(p).read_text().splitlines():
        i,*labels=map(int,row.split())
        out[i].add(tuple(labels))
    return {i:frozenset(state) for i,state in out.items()}
full=read('all-states.tsv')
by_state={state:i for i,state in full.items()}
assert len(full)==len(by_state)==112
reps={}
for i,state in full.items():
    partner=by_state[frozenset((t,x,k,r,l) for t,x,k,l,r in state)]
    assert i!=partner
    if i<partner:
        reps[i]=state
assert read('states.tsv')==reps and len(reps)==56
assert len(list(Path('.').glob('case-*.out')))==56
values={}
for i in reps:
    last=Path(f'case-{i:03}.out').read_text().splitlines()[-1].split()
    if last[:2]==['EXACT','ZERO']:
        values[i]=Fraction()
    else:
        assert last[:3]==['EXACT','channel',str(i)] and Fraction(last[4])==0
        values[i]=Fraction(last[3])
counts=Counter((v>0)-(v<0) for v in values.values())
assert counts=={1:26,0:14,-1:16}
total=2*sum(values.values())
assert total==Fraction(Path('projected.out').read_text().split()[-1])
print('signed representatives',dict(sorted(counts.items())))
print('author exact',total,'weighted',96*total)
