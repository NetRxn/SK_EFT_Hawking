from ast import literal_eval
from functools import lru_cache
parse=lru_cache(maxsize=131072)(literal_eval)
from collections import Counter,defaultdict
from dataclasses import dataclass,field
from fractions import Fraction
from functools import lru_cache
from itertools import product
from math import factorial,lcm,prod
from pathlib import Path
import sys

anchors, sewn=map(Path,sys.argv[1:3])
case=int(sys.argv[3])
mode=sys.argv[4] if len(sys.argv)>4 else 'least-work'
WORK=32_000_000
ROWS=800_000
TOTAL=100_000_000
ATTEMPT=4
REJECT_PRODUCTS=48_000_000
BITS=256
codes=tuple(map(int,__import__('os').environ['L1_PROFILE_CODES'].split(',')))
roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occ=[[roster[(code>>(6*x))&63] for x in range(8)] for code in codes]
states={}
for line in (anchors/'states.tsv').read_text().splitlines():
    c,t,x,k,p,q=map(int,line.split())
    if c==case:states[t,x,k]=p,q
edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
plan={}
for line in (anchors/'anchor-plan.tsv').read_text().splitlines():
    c,t,x,k,*shape=map(int,line.split())
    if c==case:plan[t,x,k]=tuple(shape)
patterns={}
for i,line in enumerate(l for l in (sewn/'edge-plan.out').read_text().splitlines() if l.startswith('pattern ')):
    text=line.removeprefix('pattern ')
    patterns[parse(text[:text.rindex(')')+1])]=i

@dataclass
class Factor:
    name:str
    wires:tuple
    rows:dict
    denom:int
    histograms:dict=field(default_factory=dict)

def bind(raw):
    fixed=[wire for wire in raw if wire is not None]
    assert len(set(fixed))==len(fixed),raw
    return tuple(fixed)

def factor(name,wires,entries):
    actual=bind(wires)
    rows={}
    d=1
    for v,(r,n) in entries:
        assert len(v)==len(wires)
        assert all(done is not None or x==0 for done,x in zip(wires,v)),(wires,v)
        k=tuple(x for done,x in zip(wires,v) if done is not None)
        assert len(rows)<ROWS and k not in rows
        R,N=Fraction(r),Fraction(n)
        d=lcm(d,R.denominator,N.denominator)
        rows[k]=R,N
    return Factor(name,actual,{k:(int(r*d),int(n*d)) for k,(r,n) in rows.items()},d)

def wire(t,x,k,i,h):
    return ('R',t,x,k,i,h) if states.get((t,x,k),(0,0))[h] else None

def matrix_wires(t,x,k,i):
    return tuple(wire(t,x,k,i,h) for h in range(2))

def matrix_indices(t,x,k,i):
    _,q=states.get((t,x,k),(0,0))
    return divmod(i,q+1)

def edgewords(t,x,k):
    return ('G',t,x,k),('W',t,x,k)

def site_pair(t,x):
    active=[k for k,p in enumerate(occ[t][x]) if p]
    bond=tuple(('J',t,x,k) for k in range(3))
    source=tuple(w for k in range(3) for w in edgewords(t,x,k))
    root=tuple(w for k in active for i in (4,0) for w in matrix_wires(t,x,k,i))
    def masks():
        for line in (sewn/f'site/{case}-{t}-{x}-mask.tsv').open():
            raw,word,msk,r,n=line.strip().split('\t')
            yield parse(raw)+tuple(y for m,w in zip(parse(msk),parse(word)) for y in (m,w)),(r,n)
    def kernel():
        for line in (sewn/f'site/{case}-{t}-{x}-root.tsv').open():
            raw,ij,r,n=line.strip().split('\t')
            ij=parse(ij)
            tail=tuple(v for k,(i,j) in zip(active,zip(ij[::2],ij[1::2])) for s in (i,j) for v in matrix_indices(t,x,k,s))
            yield parse(raw)+tail,(r,n)
    return (factor(f'M{t}{x}',bond+source,masks()),factor(f'C{t}{x}',bond+root,kernel()))

def spatial_factor(t,u,v,k):
    def load(x):return sum(occ[t][x])-occ[t][x][k]
    roster=load(u),load(v),plan[t,u,k],plan[t,v,k]
    i=patterns[roster]
    wires=edgewords(t,u,k)+edgewords(t,v,k)
    wires+=tuple(w for x in (u,v) for layer,ij in ((t,(0,1)),(1-t,(2,3))) for j in ij for w in matrix_wires(layer,x,k,j))
    def entries():
        for line in (sewn/f'edge-batch/{i:02}.tsv').open():
            w1,w2,m,A,B,r,n=line.split('\t')
            m=int(m)
            val=(m&255,parse(w1),m>>8,parse(w2))+tuple(v for pair in (*parse(A),*parse(B)) for v in pair)
            yield val,(r,n)
    return factor(f'E{t}{u}{k}',wires,entries())

temporal=defaultdict(list)
for line in (anchors/'temporal.tsv').read_text().splitlines():
    shape,rows,cols,r,n=line.split('\t')
    temporal[parse(shape)].append((tuple(v for ij in zip(parse(rows),parse(cols)) for v in ij),(r,n)))

def temporal_factor(t,x,h):
    roots=[]
    wires=()
    for (layer,y,k),spins in sorted(states.items()):
        n=spins[h]
        if layer!=t or not n or x not in (y,y^(1<<k)):continue
        is_other=x!=y
        roots.append((n,bool(t^is_other)))
        ij=(1,2) if is_other else (3,4)
        wires+=tuple(wire(t,y,k,i,h) for i in ij)
    return factor(f'T{t}{x}{h}',wires,temporal[tuple(roots)])

factors=[f for t in range(2) for x in range(8) for f in site_pair(t,x)]
factors.extend(spatial_factor(t,u,v,k) for t in range(2) for u,v,k in edges)
factors.extend(temporal_factor(t,x,h) for t in range(2) for x in range(8) for h in range(2))
degree=Counter(w for f in factors for w in f.wires)
assert set(degree.values())=={2}
if not all(f.rows for f in factors):
    print("EXACT ZERO empty input");sys.exit()
print('case',case,'source factors',len(factors),'wires',len(degree),'initial rows',sum(len(f.rows) for f in factors),flush=True)

def width(wire):
    if wire[0]=='G':return 8
    if wire[0] in ('W','J'):return 10
    return 2

@lru_cache(maxsize=4096)
def layout(wires):
    offset=0
    positions={}
    for wire in wires:
        n=width(wire)
        positions[wire]=(offset,n)
        offset+=n
    return positions,offset

def word(indices):
    assert len(indices)<=4 and all(0<=a<4 for a in indices)
    value=0
    for a in indices:value=4*value+a
    return (1<<(2*len(indices)))|value

def encode(wires,values):
    fields,_=layout(wires)
    result=0
    for w,v in zip(wires,values):
        offset,n=fields[w]
        x=word(v) if w[0] in ('W','J') else v
        assert 0<=x<1<<n
        result|=x<<offset
    return result

# Move one column at a time, with the destination's compact order.
@lru_cache(maxsize=4096)
def estimate(wires,requested):
    fields,_=layout(wires)
    offset=0
    code=[]
    for wire in requested:
        start,n=fields[wire]
        code.append((start,(1<<n)-1,offset))
        offset+=n
    return tuple(code)

def extract(key,recipe):
    out=0
    for pos,mask,shift in recipe:
        out|=((key>>pos)&mask)<<shift
    return out

for f in factors:
    packed={encode(f.wires,k):v for k,v in f.rows.items()}
    assert len(packed)==len(f.rows)
    f.rows=packed

def indices(A,B):
    return tuple(w for w in A.wires if w in B.wires)

def buckets(f,columns):
    # Keep at most one cached projection per factor. Greedy scheduling
    # can request many overlapping cuts and retaining them costs memory.
    if columns not in f.histograms:
        if len(f.histograms)>=(3 if len(f.rows)<100000 else 1):f.histograms.clear()
        recipe=estimate(f.wires,columns)
        f.histograms[columns]=Counter(extract(r,recipe) for r in f.rows)
    return f.histograms[columns]

def work(A,B,columns):
    a,b=buckets(A,columns),buckets(B,columns)
    if len(a)>len(b):a,b=b,a
    return sum(n*b[k] for k,n in a.items())

def join(A,B,columns,planned):
    assert planned<=WORK
    left=tuple(w for w in A.wires if w not in columns)
    right=tuple(w for w in B.wires if w not in columns)
    la,lb=estimate(A.wires,left),estimate(B.wires,right)
    ma,mb=estimate(A.wires,columns),estimate(B.wires,columns)
    _,shift=layout(left)
    groups=defaultdict(list)
    for k,v in B.rows.items():
        groups[extract(k,mb)].append((extract(k,lb)<<shift,v))
    ha=max(abs(v).bit_length() for z in A.rows.values() for v in z)
    hb=max(abs(v).bit_length() for z in B.rows.values() for v in z)
    if ha+hb+planned.bit_length()+1>BITS:raise RuntimeError('height cap')
    result={}
    for k,(a,b) in A.rows.items():
        start=extract(k,la)
        for end,(c,d) in groups.get(extract(k,ma),()):
            key=start|end
            if key not in result and len(result)>=ROWS:raise RuntimeError('row cap')
            r,n=result.get(key,(0,0))
            v=(r+a*c-b*d,n+a*d+b*c)
            if any(v):result[key]=v
            else:result.pop(key,None)
    return Factor(A.name+'+'+B.name,left+right,result,A.denom*B.denom)

def prune(fs, rounds=3):
    scanned=0
    removed=0
    for _ in range(rounds):
        columns=defaultdict(list)
        for i,f in enumerate(fs):
            for w in f.wires:columns[w].append(i)
        changed=False
        for i,j in sorted({tuple(ix) for ix in columns.values()}):
            A,B=fs[i],fs[j]
            cols=indices(A,B)
            ha,hb=buckets(A,cols),buckets(B,cols)
            for f,have,keep in ((A,ha,hb),(B,hb,ha)):
                if have.keys()<=keep.keys():continue
                scanned+=len(f.rows)
                if scanned>4_000_000:return removed
                recipe=estimate(f.wires,cols)
                rows={row:v for row,v in f.rows.items() if extract(row,recipe) in keep}
                if len(rows)==len(f.rows):continue
                changed=True
                removed+=len(f.rows)-len(rows)
                f.rows=rows
                f.histograms.clear()
                if not rows:return removed
        if not changed:break
    return removed

tally=0
step=0
scalars=[]
rejected=0
while factors:
    for f in factors[:]:
        if not f.wires:
            scalars.append(f)
            factors.remove(f)
    if not factors:break
    if step%8==0:
        removed=prune(factors)
        print('PRUNE',step,removed,flush=True)
        if any(not f.rows for f in factors):
            print('EXACT channel zero',case,'products',tally)
            sys.exit()
    columns=defaultdict(list)
    for i,f in enumerate(factors):
        for w in f.wires:columns[w].append(i)
    pairs=sorted({tuple(x) for x in columns.values()})
    assert all(len(v)==2 for v in pairs)
    forecasts=[]
    for i,j in pairs:
        A,B=factors[i],factors[j]
        cols=indices(A,B)
        n=work(A,B,cols)
        openw=len(A.wires)+len(B.wires)-2*len(cols)
        score=(n,openw) if mode=='least-work' else (n*(1+openw),openw)
        forecasts.append((score,n,i,j,cols))
    C=None
    for attempt,(_,n,i,j,cols) in enumerate(sorted(forecasts)):
        if attempt>=ATTEMPT or n>WORK or tally+n>TOTAL:break
        A,B=factors[i],factors[j]
        # Upper bound for both success work and an abandoned sparse join.
        if rejected+n>REJECT_PRODUCTS:break
        try:
            C=join(A,B,cols,n)
            break
        except RuntimeError as e:
            rejected+=n
            print('SKIP',str(e),step,n,A.name,B.name,flush=True)
    if C is None:
        print('REFUSED step',step,'least products',min(x[1] for x in forecasts),
              'tally',tally,'rejected upper bound',rejected,'left',len(factors),flush=True)
        sys.exit(3)
    tally+=n
    print(step,A.name,B.name,n,'wires',len(C.wires),'rows',len(C.rows),flush=True)
    if not C.rows:
        print('EXACT channel zero',case,'products',tally,flush=True)
        sys.exit()
    factors.pop(j);factors.pop(i);factors.append(C)
    step+=1
r,n=1,0
denom=prod(factorial(p) for m in occ for o in m for p in o)
for f in scalars:
    a,b=f.rows[0]
    r,n=r*a-n*b,r*b+n*a
    denom*=f.denom
assert n==0
print('EXACT channel',case,Fraction(r,denom),'products',tally)
