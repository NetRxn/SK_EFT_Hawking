from collections import defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import Polynomial, Symbol, haar_polynomial

CAP=65536
Q=tuple(Polynomial.variable(Symbol('q',(0,3,'L',j))) for j in range(4))
U=original_spin4_link(Q,(1,0,0,0))
V=tuple(tuple(U[i][j] for j in range(2)) for i in range(2))

@cache
def rep(n, inverse):
    W=V
    if inverse:
        q=(Q[0],-Q[1],-Q[2],-Q[3])
        matrix=original_spin4_link(q,(1,0,0,0))
        W=tuple(tuple(matrix[i][j] for j in range(2)) for i in range(2))
    if n==0:return ((Polynomial.coerce(1),),)
    if n==1:return W
    assert n==2
    (a,b),(c,d)=W
    return ((a*a,a*b,b*b),(2*a*c,a*d+b*c,2*b*d),(c*c,c*d,d*d))

@cache
def projector(roster):
    factors=[rep(n, inverse) for n,inverse in roster]
    dimensions=tuple(map(len,factors))
    assert prod(dimensions)**2<=CAP
    indices=list(product(*(range(d) for d in dimensions)))
    values={}
    for out,inc in product(indices,repeat=2):
        z=Polynomial.coerce(1)
        for mat,i,j in zip(factors,out,inc):
            z*=mat[i][j]
        h=haar_polynomial(z)
        if h.terms:
            ((key,value),)=h.terms
            assert not key
            values[out,inc]=(value.real,value.imag)
    return prod(dimensions)**2,values

if __name__ == "__main__":
    assert len(projector(((1,False),))[1])==0
    assert len(projector(((1,False),(1,True)))[1])==4
    assert len(projector(((2,False),(2,True)))[1])==9
    states={int(row.split()[0]):[] for row in Path('anchor-plan.tsv').read_text().splitlines()}
    for row in Path('states.tsv').read_text().splitlines():
        case,t,x,k,l,r=map(int,row.split())
        states[case].append((t,x,k,l,r))
    plans={}
    for i,stateset in states.items():
        for t in range(2):
            for x in range(8):
                for chi in (0,1):
                    roots=[]
                    for side,y,k,l,r in stateset:
                        if side!=t or x not in (y,y^(1<<k)):
                            continue
                        n=(l,r)[chi]
                        if n:
                            roots.append((n,bool(t^(x!=y))))
                    plans[i,t,x,chi]=tuple(roots)
    unique=set(plans.values())
    proposed=sum(prod(n+1 for n,_ in key)**2 for key in unique)
    assert proposed<=CAP
    rows=0
    for (case,t,x,chi),key in plans.items():
        count,values=projector(key)
        assert values
        rows+=len(values)
        print(case,t,x,chi,key,count,len(values))
    print('shapes',len(unique),'literal entries',proposed,'emitted uses',rows,'max entries',max(projector(k)[0] for k in unique))
    with Path('temporal.tsv').open('w') as out:
        for shape in sorted(unique):
            for (row,column),(r,i) in sorted(projector(shape)[1].items()):
                print(repr(shape),repr(row),repr(column),r,i,sep='\t',file=out)
