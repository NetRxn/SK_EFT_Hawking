from pathlib import Path
from collections import defaultdict
s=Path('run.py').read_text()
exec(s[s.index('def state_rows'):s.index('def patterns')])
case=Path('candidate-support/139627958850-8960527077529')
roster=state_rows(case/'states.tsv')
assert len(roster)==4 and roster[0]==frozenset(),sorted(roster)
by_state={s:i for i,s in roster.items()}
assert sum(i==by_state[swap(s)] for i,s in roster.items())==2
