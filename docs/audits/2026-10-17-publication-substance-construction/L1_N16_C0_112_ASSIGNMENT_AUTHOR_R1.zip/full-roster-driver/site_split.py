from ast import literal_eval
from collections import defaultdict
from fractions import Fraction
from itertools import product
from math import prod
from pathlib import Path
import sys

base=Path(sys.argv[1])
CAP=2_000_000
roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occupations=[[roster[(code>>(6*x))&63] for x in range(8)] for code in tuple(map(int,__import__('os').environ['L1_PROFILE_CODES'].split(',')))]
states=defaultdict(dict)
for line in (base/'states.tsv').read_text().splitlines():
    case,t,x,k,p,q=map(int,line.split())
    states[case][t,x,k]=p,q
spectra=defaultdict(lambda: defaultdict(list))
for line in (base/'root.tsv').read_text().splitlines():
    power,P,Q,left,right,i,j,r,n=line.split('\t')
    spectra[int(power),int(left),int(right)][literal_eval(P),literal_eval(Q)].append((int(i),int(j),Fraction(r),Fraction(n)))
moments={}
aliases={}
for i,line in enumerate(x for x in Path('edge-plan.out').read_text().splitlines() if x.startswith('pattern ')):
    text=line.removeprefix('pattern ')
    pattern=literal_eval(text[:text.rindex(')')+1])
    table=[defaultdict(set),defaultdict(set)]
    A=[{},{}]
    for side in range(2):
        for line in Path(f'rays/{i:02}-{side}.tsv').open():
            w,m,v,n,r,j=line.rstrip('\n').split('\t')
            word=literal_eval(w)
            mask=int(m)
            table[side][word].add(mask)
            A[side][word,mask]=((literal_eval(v),int(n)),int(r),int(j))
    moments[pattern]=table
    aliases[pattern]=A
shapes={}
for line in (base/'anchor-plan.tsv').read_text().splitlines():
    case,t,x,k,*value=map(int,line.split())
    shapes[case,t,x,k]=tuple(value)
    states.setdefault(case,{})

def wedge(a,b):
    return -1 if sum((b&((1<<i)-1)).bit_count() for i in range(8) if a>>i&1)%2 else 1

out=Path("site")
out.mkdir()
cache={}
selection=tuple(map(int,sys.argv[2:]))
for case,state in sorted(states.items()):
    for t,m in enumerate(occupations):
        for x,occupation in enumerate(m):
            if selection and selection!=(case,t,x)[:len(selection)]:continue
            edge_order=sorted(range(3),key=lambda k:(min(x,x^(1<<k)),k))
            sets=[]
            maps=[]
            incident=[]
            for k in range(3):
                y=x^(1<<k)
                u,v=sorted((x,y))
                u_load=sum(m[u])-m[u][k]
                v_load=sum(m[v])-m[v][k]
                key=u_load,v_load,shapes[case,t,u,k],shapes[case,t,v,k]
                sets.append(moments[key][int(x==v)])
                maps.append(aliases[key][int(x==v)])
                incident.append((key,int(x==v)))
            active=[(k,p,state.get((t,x,k),(0,0))) for k,p in enumerate(occupation) if p]
            slot=tuple(occupation),tuple(active),tuple(edge_order),tuple(incident)
            name=f'{case}-{t}-{x}'
            if slot in cache:
                for kind in ('mask','root'):
                    (out/f'{name}-{kind}.tsv').symlink_to(f'{cache[slot]}-{kind}.tsv')
                print(case,t,x,'reused',cache[slot],flush=True)
                continue
            alternatives=[sorted(spectra[p,*b]) for k,p,b in active]
            words=defaultdict(list)
            for reps in product(*alternatives):
                word=[[],[],[]]
                for (k,p,_),(a,b) in zip(active,reps):
                    j,h=[i for i in range(3) if i!=k]
                    word[j].extend(a);word[h].extend(b)
                words[tuple(tuple(sorted(a)) for a in word)].append(reps)
            matched=0; work=0; matrix_work=0
            mask_sums={}
            for word in sorted(words):
                pools=[sets[k].get(w,()) for k,w in enumerate(word)]
                if not all(pools):continue
                order=sorted(range(3),key=lambda k:len(pools[k]))
                u,v,z=order
                work+=len(pools[u])*len(pools[v])
                if work>CAP:raise RuntimeError((case,t,x,work))
                for a,b in product(pools[u],pools[v]):
                    if a&b:continue
                    if (255^(a|b)) in pools[z]:
                        matched+=1
                        masks=[0,0,0]
                        masks[u],masks[v],masks[z]=a,b,255^(a|b)
                        phase=1
                        used=0
                        for k in edge_order:
                            phase*=wedge(used,masks[k])
                            used|=masks[k]
                        assert used==255
                        r,i=phase,0
                        canonical=[]
                        for k in range(3):
                            slot,a,b=maps[k][word[k],masks[k]]
                            canonical.append(slot)
                            r,i=r*a-i*b,r*b+i*a
                        key=word,tuple(canonical)
                        a,b=mask_sums.get(key,(0,0))
                        value=a+r,b+i
                        if any(value):mask_sums[key]=value
                        else:mask_sums.pop(key,None)
            root_cache={}
            plans=[]
            for (word,canonical),phase in mask_sums.items():
                if word not in root_cache:
                    rows=defaultdict(lambda:(Fraction(0),Fraction(0)))
                    for reps in words[word]:
                        matrix_plans=[spectra[p,*label][w] for (_,p,label),w in zip(active,reps)]
                        for local in product(*matrix_plans):
                            r,n=Fraction(1),Fraction(0)
                            indices=[]
                            for i,j,c,d in local:
                                r,n=r*c-n*d,r*d+n*c
                                indices.extend((i,j))
                            k=tuple(indices)
                            a,b=rows[k]
                            rows[k]=a+r,b+n
                    root_cache[word]={k:z for k,z in rows.items() if any(z)}
                matrix_work+=len(root_cache[word])
                keys,masks=zip(*canonical)
                plans.append((keys,masks,phase,root_cache[word]))
            print('preflight',case,t,x,'projected masks',len(mask_sums),'matrix choices',matrix_work,'cached root rows',sum(map(len,root_cache.values())),flush=True)
            key=name
            cache[slot]=name
            assert len(mask_sums)<=CAP and sum(map(len,root_cache.values()))<=CAP
            with (out/f'{key}-mask.tsv').open('w') as index:
                for (word,canonical),(r,i) in sorted(mask_sums.items()):
                    keys,masks=zip(*canonical)
                    print(word,keys,masks,r,i,sep='\t',file=index)
            with (out/f'{key}-root.tsv').open('w') as index:
                for word,matrix in sorted(root_cache.items()):
                    for row,(r,i) in sorted(matrix.items()):
                        print(word,row,r,i,sep='\t',file=index)
