# L1 scale-up to 112 supported assignments

Run `python3 verify.py` to replay the author sum from all 56 exact logs
and the full support roster. The initially failed driver joined raw edge
indices with projected site indices. The corrected run used the projected
edge indices and retained the failed case-007 output as a diagnostic.
The separate edge reconstruction validates the quotient against all
379,560 raw signed rows across 54 tables. The large factor tables remain
in the local run tree and are identified by hash.

Independent review must precede any subtraction from the accepted residual.

The full-roster driver in full-roster-driver/ is verified separately on the
two four-assignment cases with scalar fixed points. Its control first failed
on the prior sparse-roster driver and passed after using anchor IDs in the
driver, site preparation and temporal preparation. The normal driver then
reproduced both previously corrected author totals.
