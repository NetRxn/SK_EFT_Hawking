from pathlib import Path
from fractions import Fraction
import subprocess,sys
ids=sorted({int(row.split()[0]) for row in Path('states.tsv').read_text().splitlines()})
total=Fraction()
signs=[0,0,0]
for i in ids:
    log=Path(f'case-{i:03}.out')
    with log.open('w') as out:
        subprocess.run([sys.executable,'quotient_worklist.py','.','.',str(i)],stdout=out,stderr=subprocess.STDOUT,check=True)
    fields=log.read_text().splitlines()[-1].split()
    if fields[:2] == ['EXACT','ZERO']:
        value=Fraction()
    else:
        assert fields[:3]==['EXACT','channel',str(i)] and Fraction(fields[4])==0,fields
        value=Fraction(fields[3])
    total+=value
    signs[(value>0)-(value<0)+1]+=1
    print(i,value,flush=True)
print('COMPLETE AUTHOR PROFILE',len(ids),signs,2*total,flush=True)
