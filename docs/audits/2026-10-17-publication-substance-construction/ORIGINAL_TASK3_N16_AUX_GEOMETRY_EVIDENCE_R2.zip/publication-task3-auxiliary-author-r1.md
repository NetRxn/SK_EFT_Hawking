# Original N16 independent auxiliary polar edge author delivery

The scratch implementation is based on the three exact Python blobs shared
by pushed `4672e9fec` and the pinned primary. The source checkout and Git
state were left untouched. First and final continuity checks matched.

## Construction

`original_auxiliary_polar_edge` reconstructs the h/k blocks from the original
gamma entries. The xy block uses h times the column radius and k times the
row radius. The yx block uses h times the row radius and k times the column
radius, with the original negative sign. The two-anchor comparison checks
those placements at unequal radii and when the right radius vanishes.

The literal insertion roster derives every bar and psi deletion and its
ordinary-minor sign from the n, b and p monomials. A Boolean perfect-matching
recurrence on the actual remaining matrix entries supplies the structural
support check. Unequal deletion counts exclude the unequal charge cases.
Both matrices recover 12 signed ordinary minors and 30 excluded test entries.
Number tests sum all four principal minors, and the remaining four supported
tests use the signed off-principal minors.

The determinant recurrence uses packed row-subset and exponent keys and
independent Gaussian monomial projections (6,0), (4,2), and (8,0).
Signed minors first accumulate into each literal test, then any nonzero
odd radial power is rejected before normalized S3 radial moments are applied.
The factorial scale is computed from the selected degrees. The result
carries each literal 36-entry table, its dual-basis counterpart, the oriented
top value and exact support counts. It uses no accepted numeric coefficient as
producer input. The coframe has an existing formal reference. The full
auxiliary determinant correspondence is still a formal obligation.

## Resource envelope

Every DP scalar multiply uses existing active exact arithmetic and bills
one product. Previously used columns are skipped before multiplication.
For polynomial order k, the layer reserve is
C(n,k) C(k+v−1,v−1) (k+1), for n retained rows and v auxiliary coordinates.
The new reserve and the old layer are considered before creating the next
dictionary, and terminal exponent-only copying has a separate reservation.
Only one minor is live. The row guard enforces at most 16 monomials per row.
The maximum adjacent-layer records are 4,641 for the unmixed minor, 53,262
for the mixed minor, and 35,280 for the top. The largest with the additional
4,096-slot fixed reserve is 57,358, below the reviewed 120,000-slot ceiling.
The conservative actual roster bounds are 225,792, 1,820,448 and 2,783,232
attempted scalar-product transitions per corresponding determinant, or
27,338,112 across the 12 unmixed and 12 mixed minors and one top, before
moment/projector overhead. The R2 plan's looser total remains valid.
The public function rejects invalid and out-of-range cap values before
allocation and checks mutable fixed-reserve and consumed-product state.

## Bounded verification

- Initial red controls failed for 16 missing entry points.
- First green iteration found a test-oracle swap between two p/b row labels
  and exposed that canonical gamma entries are constant Polynomials. The
  corrected test roster follows the declared (L n/b/p, R n/b/p) order,
  and the producer converts each constant gamma entry to the exact scalar.
- The negative control replacing the xy k-block radius with the h-block
  radius fails the original-anchor comparison.
- Final bounded regression passed 77 tests and deselected the complete
  small-carrier calculation. No full auxiliary coefficient table, full N16
  calculation, Lean command or publication gate ran.
- The complete patch SHA256 is
  `68f30fde3a02557df431a6a623db22fef1eb3d0206c1fb37aa481e6a3d944ad9`.

## Composition seams

The patch has only three additive hunks. If the direct candidate already
occupies the same adjacent insertion points, insert the exact
`publication-task3-auxiliary-author-r1.formulas.fragment` immediately before
`def original_one_site_action_coefficients(reg,links,*,route):`, insert
`publication-task3-auxiliary-author-r1.algebra.fragment` immediately before
`def _freeze_exact_metadata(value):`, and append the exact
`publication-task3-auxiliary-author-r1.tests.fragment`. The auxiliary code
does not depend on direct helper names or Symbol radial conventions.
ROOT owns composition, independent review and scientific admission.
