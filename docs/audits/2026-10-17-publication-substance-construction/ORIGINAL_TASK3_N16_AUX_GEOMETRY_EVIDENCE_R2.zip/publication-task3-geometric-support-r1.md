# Original N16 metric sewing geometric support

Scratch-only author candidate on continuity-pinned Python bytes. The two-file
patch is /tmp/publication-task3-geometric-support-r1.diff, SHA256
f3b3c21f6f54e09e978e565d20af69c6c81aaa6c4cd54ccad55fb125e9a656c5.
It passes a read-only git apply --check against the current N16 checkout.
The patch changes the existing original coframe/action section and inserts
the tests near the start of the coefficient-jet file. It leaves the direct
and auxiliary implementation locations untouched.

The calculation derives local top capacities from OriginalRegulator's
generator roster. It shares exact original hop and plaquette incidence with
the existing numerical source. Matching edges, spectator roots and every
based anchor are constructed from the actual length-two steps. The action
inventory covers all sites, the four-coframe cosmological vertex, and all
ordered Einstein–Cartan world terms. It groups the ordered terms of a single
coframe pair as one action channel and keeps their orders and plaquette
anchors as separate data for later coefficient work. It eliminates channels
that exceed any remaining site capacity and enumerates each filling multiset
once. Its exponential weight is the reciprocal product of multiplicity
factorials. The reverse mixed case translates the entire metric word. The
full anchor permutation is reported so a consumer can verify the translation
on the original anchored measure.

Derived outputs include six spectator matching edges and their twelve
separate anchors, two opposite-slice/opposite-position diagonal candidates,
and the single mixed multiplicity of two vertices at each of the two centers
on the active slice, in either direction. Both plaquette orientations and
both coframe orders survive per center. The two curvature channels use
disjoint anchor sets and are disjoint from all active coframe anchors.
There are 28 active anchors for the mixed pair. Each individual literal
first temporal insertion leaves an empty action roster. Both mixed literal
contacts leave the unit action term, with 20 temporal and 16 spatial active
anchors respectively. The diagonal roster is structurally nonempty; its
vanishing still needs the independent linear Haar cancellation.

Four new checks failed because the geometry API was absent and then passed.
The bounded coefficient-jet regression passed 61 tests and deselected the
admitted full one-site test. A separate bounded control covered all 48
slice-zero roots and matching axes across both named conventions. At fixed
exact quaternion inputs it also compared original action factors, both
ordered plaquette words and signed coframe increments to the primary
baseline. Final continuity returned SAME, with no changed input.

Raw receipts:
- /tmp/publication-task3-geometric-support-r1.red.log
- /tmp/publication-task3-geometric-support-r1.green.log
- /tmp/publication-task3-geometric-support-r1.bounded.log
- /tmp/publication-task3-geometric-support-r1.controls.py
- /tmp/publication-task3-geometric-support-r1.controls.log
- /tmp/publication-task3-geometric-support-r1.final.json

No actual checkout edit, Git mutation, Lean, full coefficient computation,
physical result or publication closure. ROOT owns independent review and
integration. The production successor still must derive the two curvature
covariances, complete temporal factors and signed scalar loop, assemble the
raw coefficients and pass their full admission and scientific review.
