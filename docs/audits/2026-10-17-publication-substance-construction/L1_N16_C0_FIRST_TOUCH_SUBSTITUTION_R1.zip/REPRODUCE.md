# Substitution at the original ordered sweep position

This experiment uses the original two signed quotient sweeps, including
their original order. At the first occurrence of a pair with neither
operand previously touched, the driver checks that both starting tables
are the original immutable inputs. It computes or retrieves the ordered
two-direction result with the full signed family and closed-axis key.
All remaining operations run the original quotient.

The pinned plan, index, compiled operands, schema and original loader and
quotient come from the existing dense-reuse and signed quotient pilots.
Run the Group 786 preparer independently with the original loader.
Provide the three uncached exact saved frontiers in order as arguments
to substitute.py. The experiment compares each full signed set with its
corresponding independent baseline. Small timings cover only the measured
scope. The payload-row limit neither bounds full memory nor constitutes
full-profile performance evidence.
