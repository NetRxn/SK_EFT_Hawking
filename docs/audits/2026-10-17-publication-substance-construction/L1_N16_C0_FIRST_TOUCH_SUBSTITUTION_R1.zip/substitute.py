from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path
from resource import RUSAGE_SELF, getrusage
from runpy import run_path
from sys import argv
from time import perf_counter
import pickle

loader = run_path("original-input.py")
audit = run_path("first-touch.py")
literal_eval, schema, cut, blocks = (loader[k] for k in ("literal_eval","schema","cut","blocks"))
assemble, quotient = (loader[k] for k in ("assemble","quotient"))
first = audit["first"]
records = {int(row[0]): row for line in Path("cut-plan.tsv").read_text().splitlines()
           if (row := line.split("\t"))}
raw_pool = {}
outputs = {}
payload_rows = 0
LIMIT = 2_000_000

def input_keys(group):
    _,_,nrows,_,encoded,indices = records[group]
    fixed = dict(zip(cut,literal_eval(encoded),strict=True))
    selected = defaultdict(list)
    for index in literal_eval(indices):
        family,label,*_ = blocks[index]
        assert all(v == fixed[a] for a,v in zip(schema[family][0],label) if a in fixed)
        selected[family].append(index)
    keys = []
    for family,ls in sorted(selected.items()):
        retained = tuple(i for i,a in enumerate(schema[family][0]) if a not in fixed)
        keys.append((family,tuple(ls),retained))
    return keys,int(nrows)

def verify_group(group, path):
    global payload_rows
    start = perf_counter()
    keys,nrows = input_keys(group)
    for key in keys:
        if key not in raw_pool:
            raw_pool[key] = assemble(*key)
    immutable = tuple(raw_pool[key] for key in keys)
    assert len(immutable)==88 and sum(len(f[1]) for f in immutable)==nrows
    degree = Counter(a for scope,_,_ in immutable for a in scope)
    assert all(v==2 for a,v in degree.items() if a[0]!="L")
    assert sum(a[0]!="L" for a in degree)==424
    pairs = [(i,j) for i,j in combinations(range(len(immutable)),2)
             if any(a[0]!="L" and a in immutable[j][0] for a in immutable[i][0])]
    if path.is_file():
        with path.open("rb") as stream:
            baseline_hash=loader["file_digest"](stream,"sha256").hexdigest()
            stream.seek(0)
            baseline=pickle.load(stream)
        assert baseline["branch"]==group
    else:
        baseline_hash="independent-in-process"
        control=list(immutable)
        control_start=perf_counter()
        for sweep in range(2):
            for i,j in pairs:
                control[i],control[j],_=quotient(control[i],control[j],degree)
                control[j],control[i],_=quotient(control[j],control[i],degree)
            assert all(f[1] for f in control)
        baseline={"factors": control}
        print("legacy exact sweep",group,"seconds",round(perf_counter()-control_start,6),flush=True)
    F=list(immutable)
    sweeps=perf_counter()
    hits=misses=0
    hashes=0
    work=0
    for sweep in range(2):
        for i,j in pairs:
            if sweep==0 and (keys[i][0],keys[j][0]) in first:
                assert F[i] is immutable[i] and F[j] is immutable[j]
                closed=tuple(a for a in F[i][0] if a in F[j][0] and a[0]!="L" and degree[a]==2)
                key = keys[i],keys[j],closed
                if key in outputs:
                    F[i],F[j],visited = outputs[key]
                    hits+=1
                    hashes += visited
                else:
                    x,y=F[i],F[j]
                    visited=len(x[1])+len(y[1])
                    x,y,_=quotient(x,y,degree)
                    visited+=len(x[1])+len(y[1])
                    y,x,_=quotient(y,x,degree)
                    rows=len(x[1])+len(y[1])
                    assert payload_rows+rows<=LIMIT
                    outputs[key]=x,y,visited
                    payload_rows+=rows
                    F[i],F[j]=x,y
                    misses+=1
                work+=visited
            else:
                work+=len(F[i][1])+len(F[j][1])
                F[i],F[j],_=quotient(F[i],F[j],degree)
                work+=len(F[i][1])+len(F[j][1])
                F[j],F[i],_=quotient(F[j],F[i],degree)
            assert work<=60_000_000
        assert all(f[1] for f in F)
    assert hits+misses==11
    assert F==baseline["factors"]
    print("substitution exact",group,"matched signed tables",len(F),"hits",hits,"computed classes",misses,
          "avoided row visits",hashes,"guarded visits",work,"retained batch output rows",payload_rows,
          "sweep seconds",round(perf_counter()-sweeps,6),"total seconds",round(perf_counter()-start,6),
          "peak RSS bytes",getrusage(RUSAGE_SELF).ru_maxrss,"baseline",baseline_hash,flush=True)

assert len(argv)==4
for group,path in zip((672,786,934),map(Path,argv[1:]),strict=True):
    verify_group(group,path)
