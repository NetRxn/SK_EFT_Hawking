from fractions import Fraction as F
from itertools import permutations
from math import factorial
import json,sys,tracemalloc
from src.vestigial.original_coefficients import *
from src.core.formulas import original_spin4_link,original_coframe_blocks
rows=[]
def fixture(name, fn):
 tracemalloc.start()
 with ScalarCost(1_000_000) as cost:
  result=fn()
 current,peak=tracemalloc.get_traced_memory()
 tracemalloc.stop()
 assert peak<512*1024*1024
 rows.append(dict(name=name,scalar_products=cost.products,peak_traced_python_allocation_bytes=peak,result=result if isinstance(result,(str,int)) else "assertions passed"))
def dense_det():
 reg=OriginalRegulator((1,1,1,1))
 # Full complex, singular, and nontrivial triangular controls independently via Leibniz.
 for seed in range(5):
  a=tuple(tuple(QComplex((i+2)*(j+1)-seed, (i-j)*(seed+1)) for j in range(4)) for i in range(4))
  if seed==4:
   a=tuple(tuple(QComplex(i+1,j-2) if i<=j else QComplex() for j in range(4)) for i in range(4))
  d=QComplex()
  for perm in permutations(range(4)):
   t=QComplex(permutation_sign(perm))
   for i,j in enumerate(perm): t=t*a[i][j]
   d+=t
  m=SparseMatrix(4,tuple(((i,j),a[i][j]) for i in range(4) for j in range(4)))
  form=m.to_exterior(reg); power=ExteriorPolynomial(((0,Polynomial.scalar(1)),))
  for _ in range(4): power=power*form
  top=dict(power.terms).get(255,Polynomial())
  assert top*F(1,factorial(4))==Polynomial.scalar(d)
 return '5 full exact complex determinant/Berezin controls'
def symbolic():
 j=Polynomial.variable(Symbol('J',(0,))); k=Polynomial.variable(Symbol('J',(1,))); h=Polynomial.variable(Symbol('h',(0,)))
 a=(j+QComplex(1,2)*h)*(k.conjugate()-j)
 assert a.conjugate().conjugate()==a
 assert a.conjugate()==(j+QComplex(1,2)*h).conjugate()*(k.conjugate()-j).conjugate()
 vals={Symbol('J',(0,)):QComplex(F(2,3),F(3,4)),Symbol('J',(1,)):QComplex(5,-2),Symbol('h',(0,)):F(7,5)}
 assert a.conjugate().evaluate(vals)==a.evaluate(vals).conjugate()
 # Duplicate/cancel coefficients with genuinely complex source dependence.
 payload=[[[0,0],j],[[0,0],j.conjugate()],[[1,1],h],[[1,1],-h]]
 m=SparseMatrix(4,payload); before=m.entries; payload.clear()
 assert m.entries==before and m.at(0,0)==j+j.conjugate() and m.at(1,1)==Polynomial()
 assert m.to_exterior(OriginalRegulator((1,1,1,1))).terms==((5,j+j.conjugate()),)
 return 'complex sources, conjugation, duplicate/cancellation and mutation'
def unit_links():
 # Rational sphere points; all matrix algebra remains exact.
 for q in ((F(3,5),F(4,5),0,0),(F(1,3),F(2,3),F(2,3),0),(0,0,0,1)):
  u=original_spin4_link(q,(1,0,0,0))
  assert matrix_multiply(matrix_dagger(u),u)==identity_matrix(4)
  assert matrix_multiply(u,matrix_dagger(u))==identity_matrix(4)
 for z in (QComplex(0,1),Polynomial.variable(Symbol('J',(0,)))):
  try: original_spin4_link((z,0,0,0),(1,0,0,0))
  except ValueError: pass
  else: raise AssertionError('nonreal accepted')
 return 'rational unit Spin4 links unitary in both orders; nonreal refusal'
def bounds():
 reg=OriginalRegulator((1,1,1,1)); g=ExteriorPolynomial.generator
 f=[g(0)*g(2),g(1)*g(3),g(4)*g(6),g(5)*g(7)]
 c=local_degree_certificate(reg,(0,0,0,0),f); p=ExteriorPolynomial(((0,Polynomial.scalar(1)),))
 for x in f:p=p*x
 assert p.terms==((255,Polynomial.scalar(1)),)
 assert not c.vanishes_above(4) and c.vanishes_above(5)
 # Every width is checked before arithmetic, including later rows.
 for bad in (((1,), (2,3)), ((1,2),(3,))):
  for fn in (lambda:matrix_dagger(bad),lambda:matrix_scale(bad,2),lambda:matrix_multiply(((1,1),),bad)):
   try:fn()
   except ValueError:pass
   else:raise AssertionError('ragged accepted')
 x=Polynomial.variable(Symbol('h',(0,)))
 cost=ScalarCost(3)
 try:(x+1).multiply(x+1,cost)
 except ValueError:pass
 else:raise AssertionError('budget not refused')
 assert cost.products==3
 return 'boundary degree4 nonzero, strict refusal and rectangle checks'
def storage_fixture():
 m=assemble_dirac(OriginalRegulator())
 size=recursive_size_bytes(m)
 slots=sum(len(v.terms) for _,v in m.entries)
 assert len(m.entries)==512 and slots==32768 and size<512*1024*1024
 return f'512 entries; 32768 scalar slots; actual object graph {size} bytes (not RSS)'
for n,f in [('storage',storage_fixture),('dense_det',dense_det),('symbolic',symbolic),('unit_links',unit_links),('bounds',bounds)]:fixture(n,f)
print(json.dumps({'imports':__import__('src.vestigial.original_coefficients',fromlist=['x']).__file__,'fixtures':rows},indent=2))
