from ast import literal_eval as parse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import (
    OriginalRegulator,Polynomial as P,Symbol, matrix_multiply as mm,
    matrix_dagger,haar_polynomial,
)

reg=OriginalRegulator()
Q=tuple(tuple(P.variable(Symbol('q',((0,0,0,0),0,chi,i))) for i in range(4)) for chi in ('L','R'))
U=original_spin4_link(*Q)
Ud=matrix_dagger(U)
g=reg.gamma
def trace(X):
    return sum((X[i][i] for i in range(len(X))),P())
L={(a,b):trace(mm(U,mm(mm(g[a],g[b]),reg.gamma5))) for a,b in product(range(4),repeat=2) if a!=b}
expected={}
checks=0
def read_value(z):
    if not z:return 0,0
    (w,x),=z.terms
    assert not w
    return x.real,x.imag
for n in (1,3):
    basis=defaultdict(P)
    assert len(L)**n<=2048
    for keys in product(L,repeat=n):
        a,b=zip(*keys)
        w=tuple(sorted(a)),tuple(sorted(b))
        coef=P.scalar(1)
        for k in keys:coef*=L[k]
        basis[w]+=coef
    assert len(basis)*8<=10000
    for (a,b),coef in basis.items():
        for p,q in ((1,0),(0,1)):
            h=0 if p else 2
            for i,j in product(range(2),repeat=2):
                z=read_value(haar_polynomial(coef*Ud[i+h][j+h])*2)
                checks+=1
                if any(z):expected[n,a,b,p,q,i,j]=z
actual={}
for l in Path('TABLES/root.tsv').read_text().splitlines():
    n,a,b,p,q,i,j,r,s=l.split('\t')
    n,p,q,i,j=map(int,(n,p,q,i,j))
    if n not in (1,3):continue
    k=n,parse(a),parse(b),p,q,i,j
    assert k not in actual
    actual[k]=F(r),F(s)
assert actual==expected
print('independent literal linear/cubic fundamental root projections',checks,'allocated entries',len(expected),'nonzero')
