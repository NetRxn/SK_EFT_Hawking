# Independent review of the first odd-root scale-up coefficient

**ACCEPT** the original representative `(103607566400,1256282652690)`
at weight 96. The exact independent, source-normalized coefficient is
`20062028626454856719970703125/2535301200456458802993406410752`.
Its weighted increment is
`60186085879364570159912109375/79228162514264337593543950336`.
Recording this single row leaves **9,642 unresolved orbits and 830,727
labels** in the temporal block. Full original c0 remains open.

Continuity checked fresh at start and final readback. The clean pinned
checkpoint `fa9e8bfd35c8598b93716f9daa623f4771ee9737` matched its tracked
upstream. Its checked-in author archive manifest agrees with the frozen
copy. I verified the 26-file author package, 56 signed local factor
entries, 46-file exact-pilot intake and preceding 22-file independent
pilot review. The residual extracted from the pinned exact-pilot
archive agrees byte for byte with the frozen intake residual. It contains
this scale-up representative exactly once at weight 96. It excludes
the already accepted pilot with the other B occupation.

## Support, pairing and source normalization

I reran the original occupation decoder and two-chirality projection.
Exact enumeration of all 65,536 projected tuples checks the independent
left and right temporal singlets, the spatial load bound and
equalities at empty anchors, and the corrected combined center parity.
Four assignments survive and all use the fundamental in either
chirality at every nontrivial root. They are precisely the two
frozen representative rows and their simultaneous chiral swaps.
All 96 retained anchor-plan rows match. The original gamma3
conjugation exchanges the chiral factors of the Haar product law,
preserves the local eight-generator tops, and multiplies each original
EHC insertion by −1. The occupation has 32 insertions, so each pair
has equal signed coefficients. This relation is exact and involves
no identification between the two different pairs.

The original powers contain 32 zeros, eight ones and eight threes.
Every original insertion factorial is kept, giving `(3!)⁸=1679616`.
Each of the 32 insertions has two original coframes. The row source
used in this scale-up strips one quarter from each coframe, and I
reproduced all 512 such raw terms from the canonical literal source
with the quarters removed. The restored factor is 4⁻⁶⁴. Separately,
768 original ordered EHC controls check that the four curvature/coframe
orderings remove the explicit action prefactor 1/4 when reduced to
a time-first component. The per-layer axis sums are (12,0,4) and
(4,0,12). The world epsilon product and the fixed cross-site wedge
parity are positive in each layer. The source checks include 64
literal Grassmann layout decompositions per layer. Reordering
complete eight-slot site tops across the layers adds an even sign.

## Independent factor preparation and exact contraction

The independent computation reconstructs the following from exact
coordinate integration or the literal source:

- All 864 nonzero linear/cubic root coefficients used by the
  fundamental channels, across 2,400 full Fourier entries.
- All temporal and spatial Haar moment rows for the two representative
  cases. The checks cover 577 full temporal entries across seven
  shapes and 9,021 full spatial entries across 15 shapes. They match
  all 89 and 543 nonzero rows, respectively.
- Every row of all 32 signed site factors. The independent assembler
  first combines original root coefficient entries and component words,
  then meets the original edge mask supports and keeps the explicit
  within-site inversion sign. The 735,408 Gaussian-rational rows match
  exactly, with at most 9,792 root products, 27,648 mask complement
  trials and 58,752 retained rows at a site.
- The pattern IDs and input hashes for all 24 reused spatial-edge
  factors. I separately checked 26 literal signed entries across
  those 24 patterns, including imaginary targets when present,
  against the original coframes and independently evaluated anchor
  moments. The largest planned direct target expansion has
  1,048,576 candidates. I did not regenerate every row of the
  24 spatial-edge tables from their raw source on this pass.

Both 72-factor networks are rebuilt on their original labels. Each
wire has two occurrences and uses the established original
closed-word incidence. Initial counts match the frozen author receipts,
with 176 wires and 395,338 rows in each network. The reviewer
executes the independent tuple-key quotient and exact Gaussian
join algorithm previously validated against open-boundary arithmetic.
It groups only identical full primitive signed slices on all shared
wire coordinates and weights the peer exactly by their original
Gaussian multipliers. Work, site trial, row and integer height guards
control the actual operations.

| Pair representative | Exact normalized channel value |
| --- | --- |
| 0 | 20062028626454856719970703125/5070602400912917605986812821504 |
| 1 | 0 |

Pair 0 completes with 3,165 matched products after quotient reductions,
at most 336 in any join. The independent charged scan tally is
3,348,993, with a single-factor peak of 58,752 rows. Pair 1
reaches an empty quotient on S04 and E041. Their shared bond tuple
has no matched support after the exact preceding transformations.
This proves the channel zero with no inferred sign or missing
partner. Both results agree exactly with the frozen author
receipts. Multiplying the sum by two accounts for all four
necessary-supported states.

This review accepts this one original coefficient. The use of
24 earlier spatial-edge tables gives no cold full factor-generation
timing. The three other scale-up profiles and their factor work
remain outside this receipt. No repository, manuscript or Lean
state changed.

## Replay

Scratch expects `AUTHOR` to be the frozen first-profile author
package, `TABLES` to point to its hashed signed factors,
`INDEPENDENT` to the previous independent decoder and projection,
`prior-coframes.tsv` to the accepted canonical raw export, and
`residual.tsv` to be the accepted exact-pilot archive's
`block-remaining.tsv`. Use the clean science checkout
`51e7c745e` for the literal controls.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 support.py > support.out
PYTHONDONTWRITEBYTECODE=1 python3 moments.py > moments.out
PYTHONDONTWRITEBYTECODE=1 python3 site-rebuild.py > site-rebuild.out
PYTHONDONTWRITEBYTECODE=1 python3 edge-control.py > edge-control.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" root-rebuild.py > root-rebuild.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" normalization.py > normalization.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py 0 > case-0.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py 1 > case-1.out
python3 verify.py > verification.out
shasum -a 256 -c manifest.sha256
```
