from ast import literal_eval as parse
from collections import defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations_with_replacement,product
from math import prod,comb
from pathlib import Path

T=Path('TABLES')
fund={
 (0,0):((0,1,0),(3,0,1)),
 (0,1):((2,1,0),(1,0,1)),
 (1,0):((2,-1,0),(1,0,1)),
 (1,1):((0,1,0),(3,0,-1)),
}
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def add(a,b):return a[0]+b[0],a[1]+b[1]
@cache
def sphere(keys):
    expo=tuple(keys.count(j) for j in range(4))
    if any(n&1 for n in expo):return F(0)
    return F(prod(prod(range(1,n,2)) for n in expo),prod(range(4,4+len(keys),2)))

@cache
def expansion(n,i,j,dagger):
    if n==0:
        assert (i,j)==(0,0)
        return (((),(1,0)),)
    assert n==1
    return tuple(((k,),((-1 if dagger and k else 1)*r,(-1 if dagger and k else 1)*s)) for k,r,s in fund[i,j])

@cache
def integral(terms,word=()):
    answer=(0,0)
    for roster in product(*(expansion(n,i,j,d) for n,i,j,d in terms)):
        q=tuple(k for indices,z in roster for k in indices)
        moment=sphere(tuple(sorted(word+q)))
        if moment:
            z=(1,0)
            for _,step in roster:z=mul(z,step)
            answer=add(answer,(z[0]*moment,z[1]*moment))
    return answer

states=defaultdict(list)
for l in (T/'states.tsv').open():
    c,t,x,k,p,q=map(int,l.split())
    states[c].append((t,x,k,(p,q)))
shapes=set()
for rows in states.values():
    for t,x,c in product(range(2),range(8),range(2)):
        shapes.add(tuple((label[c],bool(t^(x!=y))) for l,y,k,label in rows
                         if l==t and x in (y,y^(1<<k)) and label[c]))
expected={}
checks=0
assert sum(prod((n+1)**2 for n,_ in shape) for shape in shapes)<=65536
for shape in sorted(shapes):
    domains=[range(n+1) for n,_ in shape]
    for rows,cols in product(product(*domains),repeat=2):
        terms=tuple((n,i,j,d) for (n,d),i,j in zip(shape,rows,cols))
        z=integral(terms)
        checks+=1
        if any(z):expected[shape,rows,cols]=z
actual={}
for l in (T/'temporal.tsv').open():
    shape,rows,cols,r,s=l.split('\t')
    k=(parse(shape),parse(rows),parse(cols))
    assert k not in actual
    actual[k]=(F(r),F(s))
assert actual==expected
print('independent temporal screen',len(shapes),'shapes',checks,'full entries',len(expected),'nonzero')

shapes={tuple(map(int,l.split()[4:])) for l in (T/'anchor-plan.tsv').open()}
assert sum(sum(comb(7+n,n) for n in range(h+1))*prod((j+1)**2 for j in tags) for h,*tags in shapes)<=250000
expected={}
checks=0
for h,a,b,c,d in sorted(shapes):
    for n in range(h+1):
        for word in combinations_with_replacement(range(8),n):
            wl=tuple(i for i in word if i<4);wr=tuple(i-4 for i in word if i>=4)
            for i,j,I,J,k,l,K,L in product(*(range(n+1) for n in (a,a,b,b,c,c,d,d))):
                x=integral(((a,i,j,True),(c,k,l,False)),wl)
                y=integral(((b,I,J,True),(d,K,L,False)),wr)
                z=mul(x,y)
                checks+=1
                if any(z):
                    key=((h,a,b,c,d),word,(i,I),(j,J),(k,K),(l,L))
                    expected[key]=z
actual={}
for line in (T/'spatial.tsv').open():
    data=line.split('\t')
    key=tuple(map(parse,data[:6]))
    assert key not in actual
    actual[key]=tuple(map(F,data[6:]))
assert actual==expected
print('independent spatial moment screen',len(shapes),'shapes',checks,'full entries',len(expected),'nonzero')
