from fractions import Fraction as F
from pathlib import Path

key=(103607566400,1256282652690,96)
residual=[tuple(map(int,l.split())) for l in Path('residual.tsv').read_text().splitlines()]
assert len(residual)==len(set(residual))==9643 and sum(w for a,b,w in residual)==830823
assert [r for r in residual if r[:2]==key[:2]]==[key]
assert not any(r[:2]==(103607566400,1256282136720) for r in residual)
values=[]
for n in range(2):
    own=Path(f'case-{n}.out').read_text().splitlines()
    frozen=Path(f'AUTHOR/first/case-{n:03}.out').read_text().splitlines()
    a=own[0].split()
    b=frozen[0].split()
    assert (a[1],a[3],a[5],a[8])==(b[1],b[4],b[6],b[9])
    if n==0:
        assert frozen[-1].startswith('EXACT channel 0 ')
        assert F(frozen[-1].split()[4])==0
        target=F(frozen[-1].split()[3])
    else:
        assert frozen[-1]=='EXACT ZERO through proportional slices'
        assert any(l.startswith('empty quotient ') for l in own)
        target=F(0)
    tag,case,amount=own[-1].split()
    assert tag=='EXACT' and int(case)==n and F(amount)==target
    values.append(F(amount))
two_pairs=2*sum(values)
author=next(l for l in Path('AUTHOR/benchmark.out').read_text().splitlines()
            if l.startswith('COMPLETE AUTHOR PROFILE '))
assert tuple(map(int,author.split()[3:6]))==key and F(author.split()[-1])==two_pairs
assert values[0]>0 and values[1]==0 and two_pairs>0
print('pair representatives',*values)
print('source-normalized representative',two_pairs)
print('weight-96 increment',96*two_pairs)
rest=[r for r in residual if r!=key]
assert len(rest)==9642 and sum(w for a,b,w in rest)==830727
print('residual after exactly one subtraction',len(rest),sum(w for a,b,w in rest))
Path('reviewed-exact.tsv').write_text('\t'.join(map(str,(*key,two_pairs)))+'\n')
