from ast import literal_eval
from collections import defaultdict
from fractions import Fraction
from math import gcd,lcm
from pathlib import Path
import sys

def phase_rotate(r,i,n):
    return ((r,i),(-i,r),(-r,-i),(i,-r))[n]

def normalize(rows,side):
    grouped=defaultdict(list)
    for key,val in rows.items():
        word=key[side]
        mask=(key[2]>>(8*side))&255
        rest=(key[1-side],(key[2]>>(8*(1-side)))&255,*key[3:])
        grouped[word,mask].append((rest,*val))
    reduced={}
    aliases={}
    signatures={}
    for bond,terms in grouped.items():
        terms.sort()
        g=0
        for _,r,i in terms:
            g=gcd(g,gcd(r,i))
            if g==1:break
        assert g
        _,r,i=terms[0]
        unit=max(range(4),key=lambda n:phase_rotate(r,i,n))
        signature=tuple((k,*phase_rotate(r//g,i//g,unit)) for k,r,i in terms)
        alias=signatures.setdefault(signature,bond)
        aliases[bond]=(alias,*phase_rotate(g,0,-unit%4))
    for signature,(word,mask) in signatures.items():
        for (v,n,x,y),r,i in signature:
            key=(word,v,mask|(n<<8),x,y) if side==0 else (v,word,n|(mask<<8),x,y)
            reduced[key]=(r,i)
    assert len(reduced)<=len(rows)
    return reduced,aliases

def read(path):
    raw={}
    scale=1
    for line in path.open():
        *key,r,i=line.rstrip('\n').split('\t')
        key=tuple(map(literal_eval,key))
        a,b=Fraction(r),Fraction(i)
        assert key not in raw and (a or b)
        raw[key]=(a,b)
        scale=lcm(scale,a.denominator,b.denominator)
    return {k:(int(r*scale),int(i*scale)) for k,(r,i) in raw.items()},scale

def save(path,rows,scale):
    with path.open('w') as f:
        for key,(r,i) in sorted(rows.items()):
            print(*key,Fraction(r,scale),Fraction(i,scale),sep='\t',file=f)

out=Path('rays')
out.mkdir()
for path in sorted(Path(sys.argv[1]).glob('*.tsv')):
    rows,scale=read(path)
    old=len(rows)
    traces=[]
    for side in range(2):
        rows,aliases=normalize(rows,side)
        traces.append(len(aliases))
        with (out/f'{path.stem}-{side}.tsv').open('w') as f:
            for (word,mask),((newword,newmask),r,i) in sorted(aliases.items()):
                print(word,mask,newword,newmask,r,i,sep='\t',file=f)
    save(out/path.name,rows,scale)
    print(path.stem,old,len(rows),*traces,flush=True)
