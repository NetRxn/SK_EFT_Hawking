#!/bin/sh
set -eu
export L1_PROFILE_CODES=103607566400,1261652672530
/usr/bin/time -p python3 site_split.py "$1" > all-split-sites.out 2> all-split-sites.time
# The states file contains only the chosen chirality representatives.
for id in $(cut -f1 "$1/states.tsv" | sort -nu)
do
  /usr/bin/time -p python3 quotient_pilot.py "$1" . "$id" > "split-$id.out" 2> "split-$id.time" || test "$?" = 3
  tail -1 "split-$id.out"
done
