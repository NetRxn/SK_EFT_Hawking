from collections import Counter
from contextlib import ExitStack
from pathlib import Path
import sys

out=Path('shards')
out.mkdir()
counts=Counter()
with ExitStack() as stack:
    writers={(o,d):stack.enter_context((out/f'{o}-{d}.tsv').open('w'))
             for o in range(2) for d in range(1,5)}
    for row in Path(sys.argv[1]).open():
        o,w,*_=row.split('\t',2)
        key=int(o),(len(w)+1)//2
        assert key in writers
        writers[key].write(row)
        counts[key]+=1
for k,n in sorted(counts.items()):
    print(*k,n)
