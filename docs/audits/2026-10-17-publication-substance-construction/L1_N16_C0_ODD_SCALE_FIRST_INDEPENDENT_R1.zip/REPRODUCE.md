# L1 first-scale independent acceptance and author remedies

The independent receipt accepts one original weight-96 representative
(103607566400,1256282652690). The exact coefficient and source
normalization are in independent/REVIEW.md. Follow its replay commands
using the earlier frozen author archive. Use the published residual
once, and run python3 check-residual.py independent/reviewed-exact.tsv
to regenerate block-remaining.tsv. Nothing else is subtracted.

The remaining files are author diagnostics and controls. The second
profile generated all 43 edge tables after exact word partitions.
Its ordinary site assembly refused at channel 4, layer 1, site 3.
Rather than materialize its complete product of generator masks and
root matrix coefficients, the alternative stores two factors. Their
shared index is the triple of original coframe words. One factor
contains original wedge signs and projected endpoint masks and words.
The other contains the original root matrix coefficients. The
original site factor is their exact contraction over the shared
triple. Proportional edge slices on the indexed endpoint mask/word
pair are transferred into the first site factor, leaving all other
shared matrix indices open. This is the same exact proportional-slice
identity used in the accepted pilot.

At that site, the projected split holds 135,840 mask rows and 68,448
root rows instead of expanding 4,965,120 planned products. The
complete channel 4 replays to an exact zero on the split network.
As a positive and negative control, both split-network results on
the accepted first scale case match its independently reviewed
coefficients. These controls do not accept the second coefficient
or its remaining channels. Its split batch was still running at
checkpoint time. The third profile had prepared all 52 edge tables.

Recover the uncompressed signed edge factors and anchor tables by
the author benchmark receipt. In site-split/ scratch, use
edge_rays.py on the appropriate edge-batch directory, link rays as
edge-batch, and link the original edge-plan.out into the scratch
directory. Set L1_PROFILE_CODES to the exact pair of comma-delimited
original occupancy codes. Run site_split.py with the anchor directory
and optional case, layer and site selectors. Then run quotient_pilot.py
with the anchor directory, scratch directory and case ID. For the
targeted result use the second profile and case 4. For the two
positive/zero controls use the first profile and cases 0 and 1.

The edge-index control shards the unmodified coframe rows by owner and
degree. Concatenating the shards in owner/degree order recovers their
original bytes. The indexed and unindexed (2,2) control edge tables
are byte-identical. The observed 7.07 vs 3.58 seconds are one
same-machine timing pair and do not predict full batch time.
