# L1 paired middle-cost coordinate 23 and additional cost probes

The reviewed middle-cost case is outer coordinate 23, (132,(2,)), of descendant (0,1), tuple 0. Its exact scalar is 8732401333944633881667/2596148429267413814265248164610048 + 0i. The three additional cost probes (24, 28 and 32) and the support census are author work. They give bounded restart costs, with no independent subtotal claimed.

First verify manifest.sha256 here and the preserved review manifest from independent/. Run python3 sum-case23.py from author/inner/ and compare the complete ledger to author-case23.tsv. Compare independent/audit.out for the separate signed retally and full roster verification.

Use the two exact original branch operands and pair scripts in L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip at 383f42e573962e8f7f41c0111c82a59a605c73ff. Verify the compressed operands and each decompressed hash before loading. In that archive's author/pair/ directory, run the existing pair constructor with index 23, reduce-label-frontier.py combined-23.pkl sum23, and contract-reduced-label.py sum23. Return code 2 is the bounded refusal. Match the three saved hashes in author/outer-inputs.sha256 (relative to the pair directory).

In a fresh directory copying the author/inner/ drivers and checkpoint/quotient.py, run:

    python3 run-primary.py /absolute/path/to/row-cap-physical-slice-dense-label-sum23-reduced.pkl > primary.tsv
    python3 reduce-open.py 0 2 3 6 7 8 > rescue.tsv
    python3 sum-case23.py > author-case23.tsv

Check the exact outputs (ignoring elapsed times), frozen operands and final signed result. For the alternate three-factor replay of cuts 4 and 5, first capture their three-factor inputs with capture-three.py slice-4 and capture-three.py slice-5 in this directory. Match the printed output to the original author contract output and validate three-inputs.sha256. The independent review also completes both cuts directly from their seven-factor inputs via a separate schedule.

To repeat the outer probes use the pinned pair scripts and the same command sequence with indices 24, 28 and 32 and tags sum24, sum28 and sum32. Run exact-multicut.py on each cap with output outer-<index>-pilot.pkl and selection 0. Match probes/operands.sha256. The retained label partition has nine supported cuts for all three. Their projected downstream rollover is distinct from the initial pair counts. The support census uses the same pinned branch inputs and original layout using probes/paired-support-census.py in the author/pair/ location. Its digest covers each ordered axis, positive factor denominator, count and support row. Equal or proportional coefficient re-use after a coordinate permutation is outside this scoped identity census.

For the independent exact replays, use the instructions shipped with the independent review. Preserve those evidence bytes. Substitute the restored author scratch path in any review script copies used for replay.

Probe 28 also ran the nine primary cuts from its recorded seven-factor cap. Use the same inner scripts and run-primary.py procedure above. The one exact author cut and eight saved refusals are in probes/28-inner/. No outer subtotal is credited for that probe.
