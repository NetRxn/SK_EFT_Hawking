from ast import literal_eval
from collections import Counter, defaultdict
import hashlib
from pathlib import Path
import pickle
import sys
import time

root=Path(__file__).resolve().parent.parent
inputs=[root/f'row-cap-physical-slice-dense-label-tuple0-branch-{i}-reduced.pkl' for i in (0,1)]
sources=[]
for path in inputs:
    with path.open('rb') as f:
        digest=hashlib.file_digest(f,'sha256').hexdigest()
        f.seek(0)
        data=pickle.load(f)
    assert data['rejected_pair']==(0,1) and data['matched']==6_427_904
    print(path.name,digest,flush=True)
    sources.append(data)
assert sources[0]['conditioning'][:-1]==sources[1]['conditioning'][:-1]
assert [src['conditioning'][-1] for src in sources]==[(('R',0,0,2,0,1),i) for i in (0,1)]
left,right=[s['factors'] for s in sources]
assert len(left)==len(right)==8 and left[2:]==right[2:]
roster=literal_eval((root/'tuple0-branch0-pilot'/'pilot.roster').read_text())
cuts,expected=roster
assert len(expected)==48 and sum(n for _,n in expected)==6_427_904 and max(n for _,n in expected)<=212688

def prepare(factors):
    (a,A,ad),(b,B,bd)=factors[:2]
    degree=Counter(axis for axes,_,_ in factors for axis in axes)
    shared=tuple(axis for axis in a if axis in b)
    assert all(degree[axis]==2 for axis in shared)
    assert set(cuts) <= set(a)-set(shared)
    apos=tuple(a.index(axis) for axis in shared)
    bpos=tuple(b.index(axis) for axis in shared)
    aout=tuple(i for i,axis in enumerate(a) if axis not in shared)
    bout=tuple(i for i,axis in enumerate(b) if axis not in shared)
    groups=defaultdict(list)
    lookup=defaultdict(list)
    positions=tuple(a.index(axis) for axis in cuts)
    for row,z in A.items():
        groups[tuple(row[i] for i in positions)].append((tuple(row[i] for i in apos),tuple(row[i] for i in aout),z))
    for row,z in B.items():
        lookup[tuple(row[i] for i in bpos)].append((tuple(row[i] for i in bout),z))
    return tuple(a[i] for i in aout)+tuple(b[i] for i in bout),ad*bd,groups,lookup
ax,d,L,R=prepare(left)
bx,e,M,S=prepare(right)
assert (ax,d)==(bx,e)
for group,lookup in ((L,R),(M,S)):
    supported={key:sum(len(lookup.get(join,())) for join,_,_ in rows)
               for key,rows in group.items()}
    assert {key:n for key,n in supported.items() if n} == dict(expected)

def contract(group,lookup,label,count):
    out={}
    done=0
    for join,head,(a,b) in group[label]:
        rows=lookup.get(join,())
        done+=len(rows)
        for tail,(c,d) in rows:
            k=head+tail
            x,y=out.get(k,(0,0))
            z=(x+a*c-b*d,y+a*d+b*c)
            if any(z):
                out[k]=z
            else:
                out.pop(k,None)
    assert done==count
    return out

def restrict(axes,rows,denom):
    constrain=tuple((i,fixed[axis]) for i,axis in enumerate(axes) if axis in fixed)
    keep=tuple(i for i,axis in enumerate(axes) if axis not in fixed)
    conditioned={tuple(row[i] for i in keep):value for row,value in rows.items()
                 if all(row[i]==wanted for i,wanted in constrain)}
    assert len(conditioned)==sum(all(row[i]==wanted for i,wanted in constrain) for row in rows)
    return tuple(axes[i] for i in keep),conditioned,denom


print("index	label	pair_products_one_branch	branch0_rows	branch1_rows	combined_rows	common_factor_rows	sha256	seconds",flush=True)
for index,(key,count) in enumerate(sorted(expected,key=lambda row:(row[1],row[0]))):
    start=time.monotonic()
    left_terms=contract(L,R,key,count)
    right_terms=contract(M,S,key,count)
    combined=dict(left_terms)
    for row,(a,b) in right_terms.items():
        x,y=combined.get(row,(0,0))
        value=(x+a,y+b)
        if any(value):
            combined[row]=value
        else:
            combined.pop(row,None)
    fixed=dict(zip(cuts,key))
    factors=[restrict(ax,combined,d),*(restrict(*factor) for factor in left[2:])]
    sizes=[len(table) for _,table,_ in factors]
    if all(sizes):
        degree=Counter(axis for axes,_,_ in factors for axis in axes)
        assert all(count==2 for count in degree.values())
        digest=hashlib.sha256()
        for axes,table,denom in factors:
            digest.update(repr((axes,denom,len(table))).encode())
            for row in sorted(table):
                digest.update(repr(row).encode())
        result=digest.hexdigest()
    else:
        result='ZERO'
    print(index,repr(key),count,len(left_terms),len(right_terms),sizes[0],','.join(map(str,sizes[1:])),result,round(time.monotonic()-start,3),sep='	',flush=True)
