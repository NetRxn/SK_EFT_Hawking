#!/usr/bin/env bash
set -euo pipefail
a=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/middle23-inner
while read -r i stem; do
  ret=0
  python3 -u sparse-replay.py "$i" terminal "$a/label-$stem-reduced-frontier.pkl" "$a/$stem-contract.out" > "slice-$i-replay.out" 2>&1 || ret=$?
  case "$i" in
    4|5)
      test "$ret" = 1
      rg -q 'assert len\(out\)<=1000000' "slice-$i-replay.out"
      python3 -u sparse-support-replay.py "$i" terminal "$a/label-$stem-reduced-frontier.pkl" "$a/$stem-contract.out" > "slice-$i-support-replay.out"
      python3 -u triangle.py "$i" > "slice-$i-triangle-replay.out"
      ;;
    *) test "$ret" = 0 ;;
  esac
done < seeds.tsv
python3 terminal-timing.py > replay-timing.tsv
python3 audit.py > audit.out
