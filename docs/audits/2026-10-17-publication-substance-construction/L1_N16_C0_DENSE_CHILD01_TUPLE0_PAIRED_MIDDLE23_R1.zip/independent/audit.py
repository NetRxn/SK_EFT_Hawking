from ast import literal_eval
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

root=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/middle23-inner')
denominator=40512224221827380280140849737629696

def census(state,roster):
    axes,entries=literal_eval(roster.read_text())
    assert len(entries)==len(dict(entries))
    f=state['factors']
    assert set(Counter(w for scope,_,_ in f for w in scope).values())=={2}
    left,right=[f[i] for i in state['rejected_pair']]
    shared=sorted(set(left[0])&set(right[0]))
    lmatch=tuple(left[0].index(k) for k in shared)
    rmatch=tuple(right[0].index(k) for k in shared)
    lcut=tuple(left[0].index(k) for k in axes)
    left_count=Counter((tuple(row[p] for p in lmatch),tuple(row[p] for p in lcut)) for row in left[1])
    right_count=Counter(tuple(row[p] for p in rmatch) for row in right[1])
    weights=Counter()
    for (key,cut),n in left_count.items():
        if count:=n*right_count[key]:
            weights[cut]+=count
    assert weights==dict(entries) and sum(weights.values())==state['matched']
    return axes,weights,sorted(weights,key=lambda k:(weights[k],k))

def inverse_lift(state,axes,coordinate,path):
    fixed=dict(zip(axes,coordinate,strict=True))
    raw=path.read_bytes()
    child=pickle.loads(raw)
    assert child['conditioning']==state['conditioning']+list(fixed.items())
    assert child['label_partition']==state['label_partition']
    for (scope,rows,d),(small,cut_rows,e) in zip(state['factors'],child['factors'],strict=True):
        assert d==e and small==tuple(k for k in scope if k not in fixed)
        expected_rows={row:value for row,value in rows.items() if all(row[p]==fixed[k] for p,k in enumerate(scope) if k in fixed)}
        recovered={}
        for row,value in cut_rows.items():
            assignment=dict(zip(small,row,strict=True))
            assignment.update(fixed)
            recovered[tuple(assignment[k] for k in scope)]=value
        assert recovered==expected_rows
    print('PASS exact inverse lift',coordinate,sha256(raw).hexdigest(),sum(len(rows) for _,rows,_ in child['factors']))
    return child

def check_stage(path, child, length=None):
    raw=path.read_bytes()
    state=pickle.loads(raw)
    assert state['conditioning']==child['conditioning'] and state['label_partition']==child['label_partition']
    ff=state['factors']
    if length is not None:
        assert len(ff)==length
    assert set(Counter(w for scope,_,_ in ff for w in scope).values())=={2}
    assert all(d>0 and len(set(scope))==len(scope) and all(len(row)==len(scope) and len(value)==2 and any(value) and all(type(x) is int for x in value) for row,value in rows.items()) for scope,rows,d in ff)
    assert prod(d for _,_,d in ff)==denominator
    print('PASS stage',path.name,sha256(raw).hexdigest(),len(ff),sum(len(rows) for _,rows,_ in ff))
    return state

paired_dir=author.parent
raw_combined=(paired_dir/'combined-23.pkl').read_bytes()
assert sha256(raw_combined).hexdigest()=='a9b579de9cdd9606516aa707bf151015b84f223d959ef959c306e26a63b0acd1'
combined=check_stage(paired_dir/'combined-23.pkl',pickle.loads(raw_combined),7)
assert dict(combined['conditioning'])['R',0,6,1,1,1]==1
assert dict(combined['conditioning'])['G',0,4,2]==132
assert dict(combined['conditioning'])['J',1,4,2]==(2,)
assert combined['binary_sum']=={'summed_index':('R',0,0,2,0,1),'values':(0,1),'coordinate':(132,(2,))}
assert ('R',0,0,2,0,1) not in dict(combined['conditioning'])
check_stage(paired_dir/'label-sum23-reduced-frontier.pkl',combined,7)
parent=paired_dir/'row-cap-physical-slice-dense-label-sum23-reduced.pkl'
inner=check_stage(parent,combined,7)
assert sha256(parent.read_bytes()).hexdigest()=='1172fb4e082182638c2ae5c3bc0298cd6f69275479b52883d9f237bb0bcb1c7d'
assert inner['matched']==1021248
print('PASS paired coordinate (132,(2,)) and 7-factor restart hash')
axes,weights,order=census(inner,author/'slice-0.roster')
assert axes==(('G',0,1,2),) and len(order)==9 and sum(weights.values())==1021248
print('PASS exhaustive nine-coordinate inner roster',axes,sum(weights.values()),min(weights.values()),max(weights.values()))
ledger=(author/'author-case23.tsv').read_text().splitlines()
assert len(ledger)==10
values=[]
signature=r'^(?:independent )?exact normalized real (\S+) imaginary (\S+)(?: |$)'
for i,row in enumerate(ledger[:-1]):
    n,coord,count,real,imag,receipt=row.split('\t')
    assert int(n)==i and order[i]==(int(coord),) and weights[order[i]]==int(count)
    assert (author/f'slice-{i}.roster').read_bytes()==(author/'slice-0.roster').read_bytes()
    sub=inverse_lift(inner,axes,order[i],author/f'slice-{i}.pkl')
    tag=receipt.removesuffix('-contract.out')
    for p in sorted(author.glob(f'label-rescue-{i}-*-reduced-frontier.pkl')):
        check_stage(p,sub)
    for p in sorted(author.glob(f'*-dense-label-rescue-{i}-*-reduced.pkl')):
        check_stage(p,sub)
    check_stage(author/f'label-slice-{i}-reduced-frontier.pkl',sub)
    for p in sorted(author.glob(f'*-dense-label-slice-{i}-reduced.pkl')):
        check_stage(p,sub)

    terminal=author/f'label-{tag}-reduced-frontier.pkl'
    state=check_stage(terminal,sub)
    if '--cuts-only' in __import__('sys').argv[1:]:
        continue
    if i in (4,5):
        capture=author/f'captured-three-slice-{i}.pkl'
        state=check_stage(capture,sub,3)
        replay=(root/f'slice-{i}-triangle-replay.out').read_text()
        assert sha256(capture.read_bytes()).hexdigest() in replay
        raw_sig=r'^raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$'
    else:
        replay=(root/f'slice-{i}-replay.out').read_text()
        assert f"conditioning {sub['conditioning']} label partition {sub['label_partition']}" in replay
        raw_sig=r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$'
    raw_re,raw_im,d=map(int,re.search(raw_sig,replay,re.M).groups())
    exact=tuple(map(Fraction,re.search(signature,replay,re.M).groups()))
    assert exact==tuple(map(Fraction,re.search(signature,(author/receipt).read_text(),re.M).groups()))==tuple(map(Fraction,(real,imag)))
    assert d==denominator and tuple(Fraction(value,d*16*4**64) for value in (raw_re,raw_im))==exact
    values.append(exact)
    print('PASS independent paired heavy case 23 slice',i,order[i],count,'exact normalized',*exact)
if '--cuts-only' in __import__('sys').argv[1:]:
    print('PASS all nine roster coordinates and signed inverse lifts')
    raise SystemExit(0)
label,*expected=ledger[-1].split('\t')
total=tuple(sum(column,Fraction(0)) for column in zip(*values,strict=True))
assert label=='sum' and total==tuple(map(Fraction,expected))
print('PASS exact paired heavy case 23 sum',*total)
