from collections import Counter
from decimal import Decimal
from pathlib import Path

print('slice\tstage_receipt\texit_code\twall_seconds')
rows=[]
for i in range(9):
    log=Path(f'lineage-{i}/stage-timing.tsv')
    for line in log.read_text().splitlines():
        ordinal,name,code,seconds=line.split('\t')
        assert int(ordinal)==i and Decimal(seconds)>0
        assert code in ('0','2') and (code=='0' or name.endswith('-contract.out'))
        rows.append((ordinal,name,code,seconds))
assert len(rows)==43 and len({x[:2] for x in rows})==43
assert Counter(code for _,_,code,_ in rows)==Counter({'0':35,'2':8})
assert sum(name.endswith('-plan.out') for _,name,_,_ in rows)==9
assert sum(name.endswith('-reduce.out') for _,name,_,_ in rows)==17
assert sum(name.endswith('-contract.out') for _,name,_,_ in rows)==17
for row in rows:
    print(*row,sep='\t')
