from pathlib import Path
import re
print('slice\tmethod\tproducts\tseconds\treceipt')
for i in range(9):
    methods=('support','triangle') if i in (4,5) else ('plain',)
    for method in methods:
        file=Path(f'slice-{i}-{method}-replay.out' if method!='plain' else f'slice-{i}-replay.out')
        log=file.read_text()
        if method=='triangle':
            p=r'^independent pivot 1 .* Gaussian products (\d+) wall seconds (\S+)$'
        else:
            p=r'^exact normalized real .* independent matched products (\d+) wall seconds (\S+)$'
        products,secs=re.search(p,log,re.M).groups()
        if i in (4,5):
            numerator=re.search(r'^(?:PASS )?raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',log,re.M).groups()
            other='triangle' if method=='support' else 'support'
            coscalar=re.search(r'^(?:PASS )?raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',Path(f'slice-{i}-{other}-replay.out').read_text(),re.M).groups()
            assert numerator==coscalar
        print(i,method,products,secs,file.name,sep='\t')
