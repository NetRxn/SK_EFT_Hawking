#!/usr/bin/env bash
set -euo pipefail
scratch=$PWD
author=/private/tmp/l1-child01-tuples234.cugnpQ
mkdir -p combination/run combination/tuple0-branch0-pilot
for i in 0 1; do
 name="row-cap-physical-slice-dense-label-tuple0-branch-$i-reduced.pkl"
 ln -s "$author/$name" "combination/$name"
done
ln -s "$author/tuple0-branch0-pilot/pilot.roster" combination/tuple0-branch0-pilot/pilot.roster
cp "$author/tuple0-pair-equivalence/sum-branches-checked.py" combination/run/sum-branches.py
cd combination/run
TIMEFORMAT='%3R seconds'
{ time python3 -u sum-branches.py 23 > combine-23.out; } 2> "$scratch/combine-timing.out"
for file in combined-23.pkl combine-23.out; do cmp "$file" "$author/tuple0-pair-equivalence/$file"; done
printf 'PASS exact original paired constructor bytes and receipt\n'
