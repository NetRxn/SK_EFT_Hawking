from ast import literal_eval
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from math import lcm
from pathlib import Path
from re import M, findall, search
from zipfile import ZipFile

from exact_factors import groups, overlap, proj, read

def total(items):
    return tuple(sum(group, Fraction(0)) for group in zip(*items, strict=True))

def bind_prior_transport():
    prior = Path('prior-18-31')
    manifest = (prior/'review-manifest.sha256').read_bytes()
    assert sha256(manifest).hexdigest() == 'a280398a544c82ff6ad98da0b774e5322a3079a62e05588a690bcbdddb542d1f'
    hashes = {name: digest for digest,name in map(str.split, manifest.decode().splitlines())}
    for name in ('verify-lineage.out','aggregate.out'):
        assert sha256((prior/name).read_bytes()).hexdigest() == hashes[name]
    return prior

def read_earliest():
    with ZipFile('cases12-17.zip') as archive:
        data = archive.read('eighteen-term-retally.tsv')
        manifest = archive.read('manifest.sha256').decode()
        hashes = {name.removeprefix('./'): digest for digest,name in map(str.split,manifest.splitlines())}
        assert sha256(data).hexdigest() == hashes['eighteen-term-retally.tsv']
        assert hashes['eighteen-term-retally.tsv'] == '91148f8baff61ec1ccbccc76bbb65aee23ea9618556075a4d8ab3d91b3c277f6'
    rows = [line.split('\t') for line in data.decode().splitlines()]
    assert len(rows)==19 and rows[-1][:2]==['PARTIAL SUM','18']
    ids=[int(row[0]) for row in rows[:-1]]
    assert ids==list(range(18))
    values={int(i):(Fraction(x),Fraction(y)) for i,x,y in rows[:-1]}
    assert total(values.values())==tuple(map(Fraction,rows[-1][2:]))
    return values

def read_replays(directory, indices, order, source_counts):
    aggregate=(directory/'aggregate.out').read_text()
    lineage=(directory/'verify-lineage.out').read_text()
    value_rows=findall(r'^PASS case (\d+) exact normalized (\S+) (\S+) products \d+ peak rows \d+ seconds \S+$',aggregate,M)
    assert [int(row[0]) for row in value_rows]==list(indices)
    values={int(i):(Fraction(x),Fraction(y)) for i,x,y in value_rows}
    cuts=findall(r'^PASS case (\d+) (.+) cut rows and inverse lifts \d+$',lineage,M)
    assert [int(row[0]) for row in cuts]==list(indices)
    assert all(literal_eval(coordinate)==order[int(index)] for index,coordinate in cuts)
    assert all(source_counts[order[index]]==213696 for index in indices)
    hashes=[(int(i),h) for i,h in findall(r'^checkpoint (\d+) input\.pkl SHA256 ([0-9a-f]{64}) rows \d+$',lineage,M)]
    assert [i for i,h in hashes]==list(indices) and len({h for _,h in hashes})==len(indices)
    subtotal=search(r'^PASS (?:14|four)-case subtotal (\S+) (\S+)$',aggregate,M)
    assert subtotal and tuple(map(Fraction,subtotal.groups()))==total(values.values())
    return values,hashes

def source_roster():
    parent = read('separator.zip','row-cap-physical-slice-dense-label-tuple1-0b-reduced.pkl', verbose=False)
    left,right=parent['factors'][:2]
    assert parent['label_partition']['index']==1 and parent['rejected_pair']==(0,1)
    assert parent['conditioning'][-1]==(('R',0,3,0,1,0),0)
    axes=(('G',0,0,2),('J',1,4,2))
    shared=overlap(left[0],right[0])
    lookup=groups(right,shared)
    join_key=proj(left[0],shared)
    cut_key=proj(left[0],axes)
    counts=Counter()
    for row in left[1]:
        products=len(lookup.get(join_key(row),()))
        if products:
            counts[cut_key(row)]+=products
    raw=(Path('inputs')/'32/input.roster').read_bytes()
    assert sha256(raw).hexdigest() == '43f06ca587f6c9d857377f667d7699e90db3fb5c93d6ed41e03c193f45685a30'
    raw_axes,rows=literal_eval(raw.decode())
    assert raw_axes==axes and len(rows)==len(counts)==36 and dict(rows)==counts
    assert sum(counts.values())==parent['matched']==6838272
    order=sorted(counts,key=lambda label:(counts[label],label))
    expected=[(g,(3,)) for g in (17,24,33,34,36,40,65,66,68,72,129,136)]
    expected += [(g,(j,)) for g,_ in expected for j in (1,2)]
    assert order==expected
    return order,counts

def verify_equality():
    with ZipFile('child-equality.zip') as archive:
        raw=archive.read('verify.out')
        assert sha256(raw).hexdigest() == '57c285e387b01c7831d55874ac0ed7abf6a6c1eacc877819212ed524c7398d4a'
    assert raw.endswith(b'PASS identical signed six-factor contractions and normalization; disjoint full tuple1 contraction is 2 x either child\n')

verify_equality()
order,counts=source_roster()
prior = bind_prior_transport()
first=read_earliest()
middle,middle_hashes=read_replays(prior,range(18,32),order,counts)
last,last_hashes=read_replays(Path('.'),range(32,36),order,counts)
assert len({digest for _,digest in middle_hashes+last_hashes})==18
assert set(first).isdisjoint(middle) and set(middle).isdisjoint(last) and set(first).isdisjoint(last)
values=first|middle|last
assert set(values)==set(range(36))
assert all(y==0 for _,y in values.values())

child=total(values.values())
full=tuple(2*component for component in child)
for numerator_index in range(2):
    components=[value[numerator_index] for value in values.values()]
    denominator=lcm(*(v.denominator for v in components))
    sum_numerator=sum(v.numerator*(denominator//v.denominator) for v in components)
    assert child[numerator_index] == Fraction(sum_numerator,denominator)
    assert full[numerator_index] == Fraction(2*sum_numerator,denominator)

print('kind','index','G(0,0,2)','J(1,4,2)','pair_products','normalized_real','normalized_imaginary','receipt',sep='\t')
for i in range(36):
    g, (j,) = order[i]
    source=('committed_0_17' if i in first else 'independent_18_31' if i in middle else 'independent_32_35')
    print('term',i,g,j,counts[order[i]],*values[i],source,sep='\t')
print('shared-child-C',36,'','',sum(counts.values()),*child,'complete_36_term_sum',sep='\t')
print('tuple1-2C','','','','',*full,'accepted_disjoint_child_equality',sep='\t')
