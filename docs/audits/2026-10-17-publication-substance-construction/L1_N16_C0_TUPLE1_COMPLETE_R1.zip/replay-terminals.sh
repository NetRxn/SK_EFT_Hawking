#!/bin/sh
set -eu
for index in "$@"; do
    mkdir -p "replays/$index"
    /usr/bin/time -p python3 -u replay.py "$index" 0 "inputs/$index/label-rescue-reduced-frontier.pkl" "inputs/$index/rescue-contract.out" > "replays/$index/replay.out" 2> "replays/$index/replay.time"
done
