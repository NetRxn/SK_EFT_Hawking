from collections import Counter, defaultdict
from functools import reduce
from hashlib import sha256
from itertools import combinations, product
from math import factorial, gcd, prod
from operator import itemgetter
from pathlib import Path
from zipfile import ZipFile
import gzip
import pickle

CUT = ('R', 0, 3, 0, 1, 0)
DEN = 40512224221827380280140849737629696

def read(archive, name, verbose=True):
    with ZipFile(archive) as z:
        assert z.testzip() is None
        manifests = [{path.removeprefix('./'): h for h, path in map(str.split, z.read(f).decode().splitlines())}
                     for f in ('manifest.sha256', 'frontiers-uncompressed.sha256')]
        packed = z.read(name + '.gz')
        raw = gzip.decompress(packed)
        assert sha256(packed).hexdigest() == manifests[0][name + '.gz']
        digest = sha256(raw).hexdigest()
        assert digest == manifests[1][name]
        if verbose:
            print('archive input', archive, name, digest, flush=True)
        return pickle.loads(raw)

def proj(axes, scope):
    positions = tuple(axes.index(axis) for axis in scope)
    return lambda row: tuple(row[i] for i in positions)

def add(u, v):
    return u[0]+v[0], u[1]+v[1]

def mul(u, v):
    return u[0]*v[0]-u[1]*v[1], u[0]*v[1]+u[1]*v[0]

def overlap(a, b):
    return tuple(axis for axis in a if axis in b)

def groups(factor, shared):
    axes, rows, _ = factor
    key = proj(axes, shared)
    tail = proj(axes, tuple(a for a in axes if a not in shared))
    indexed = defaultdict(dict)
    for row, coeff in rows.items():
        indexed[key(row)][tail(row)] = coeff
    return indexed

def combine(left, right, admitted=None):
    aa, _, da = left
    ba, _, db = right
    shared = overlap(aa, ba)
    axes = tuple(a for a in aa if a not in shared) + tuple(a for a in ba if a not in shared)
    A, B = groups(left, shared), groups(right, shared)
    count = sum(len(A[k])*len(B[k]) for k in A.keys() & B.keys())
    allowed = admitted or (lambda _: True)
    result = defaultdict(lambda: (0, 0))
    for k in A.keys() & B.keys():
        for ar, x in A[k].items():
            for br, y in B[k].items():
                key = ar+br
                if allowed(key):
                    result[key] = add(result[key], mul(x, y))
    return (axes, {r:v for r,v in result.items() if any(v)}, da*db), count

def quotient(factors, i, j):
    left, right = factors[i], factors[j]
    a, _, d = left
    b, _, e = right
    shared = overlap(a,b)
    if not shared:
        return 0
    assert all(axis[0] != 'L' for axis in shared)
    A, B = groups(left,shared), groups(right,shared)
    classes = {}
    qright = defaultdict(lambda: (0,0))
    qleft = {}
    support = sorted(A.keys() & B.keys())
    for key in support:
        pairs = sorted(A[key].items())
        common = gcd(*(entry for _, z in pairs for entry in z))
        phases = ((1,0),(0,1),(-1,0),(0,-1))
        unit = max(phases, key=lambda phase: mul(pairs[0][1],phase))
        signature = tuple((tail,mul((z[0]//common,z[1]//common),unit)) for tail,z in pairs)
        # Each original slice is this primitive vector times its exact Gaussian scale.
        scale = (common*unit[0],-common*unit[1])
        assert all(mul(norm,scale) == original for (_,norm),(_,original) in zip(signature,pairs,strict=True))
        label = classes.setdefault(signature,key)
        for tail, primitive in signature:
            qleft[label+tail] = primitive
        for tail, z in B[key].items():
            qright[label+tail] = add(qright[label+tail],mul(z,scale))
    if len(classes) == len(support) == len(B):
        return 0
    qright = {row:z for row,z in qright.items() if any(z)}
    factors[i] = (shared+tuple(axis for axis in a if axis not in shared),qleft,d)
    factors[j] = (shared+tuple(axis for axis in b if axis not in shared),qright,e)
    return len(support)-len(classes)

def reduce_factors(factors):
    domains = defaultdict(list)
    for axes, rows, _ in factors:
        for i,axis in enumerate(axes):
            domains[axis].append({r[i] for r in rows})
    fixed = {a for a, domains_here in domains.items() if len(domains_here[0])==1 and all(s==domains_here[0] for s in domains_here)}
    for i,(axes,rows,d) in enumerate(factors):
        outward = tuple(a for a in axes if a not in fixed)
        key = proj(axes,outward)
        reduced = {key(row):z for row,z in rows.items()}
        assert len(reduced)==len(rows)
        factors[i] = outward,reduced,d
    for _ in range(2):
        before = sum(len(r) for _,r,_ in factors)
        folded = 0
        for i,j in combinations(range(len(factors)),2):
            folded += quotient(factors,i,j) + quotient(factors,j,i)
        after = sum(len(r) for _,r,_ in factors)
        print('reduction',before,after,'folded',folded,'singleton wires',len(fixed),flush=True)
        if before==after and not folded:
            break

def prune(factors,focus=None):
    for i,j in combinations(range(len(factors)),2):
        if focus is not None and focus not in (i,j):
            continue
        a,A,d = factors[i]
        b,B,e = factors[j]
        shared = overlap(a,b)
        if not shared:
            continue
        ka,kb = proj(a,shared),proj(b,shared)
        allowed = set(map(ka,A)) & set(map(kb,B))
        factors[i] = a,{r:v for r,v in A.items() if ka(r) in allowed},d
        factors[j] = b,{r:v for r,v in B.items() if kb(r) in allowed},e
