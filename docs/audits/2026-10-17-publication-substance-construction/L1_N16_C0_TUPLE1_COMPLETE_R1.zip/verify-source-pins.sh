#!/bin/sh
set -eu
test "$(git hash-object separator.zip)" = 02e33786d0bcd46e2314ad7fec1453595adcc815
test "$(git hash-object child-equality.zip)" = 500c32b4c546a1f2fe76330642b38680994fe439
test "$(git hash-object cases12-17.zip)" = 763a7e83600e772977fb60db354c6c06eb0d4dca
printf 'PASS all three publication checkpoint archive pins\n'
