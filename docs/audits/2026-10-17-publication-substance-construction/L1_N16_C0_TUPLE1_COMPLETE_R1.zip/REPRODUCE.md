# Shared tuple 1 child and full tuple 1 contribution

Restore separator.zip, child-equality.zip and cases12-17.zip from the exact
Git blobs in SOURCE_PINS.txt. The copied prior-18-31 review files match the
separate cases 18–31 archive. In fresh scratch first run sh rehydrate.sh
and verify frozen-inputs.sha256. Then run python3 retally-complete.py, and compare every row with complete-ledger.tsv.
It reenumerates the original cut and independently reconciles all 36
normalized complex terms once. Only then does it double the child
for the equal, disjoint second child.

The rehydration restores the final four author restart objects. Follow REVIEW.md for independent lineage and
terminal replays. Load only trusted checkpoint pickles. The scope is one
full tuple contribution in descendant (0,0), not the entire dense group.
