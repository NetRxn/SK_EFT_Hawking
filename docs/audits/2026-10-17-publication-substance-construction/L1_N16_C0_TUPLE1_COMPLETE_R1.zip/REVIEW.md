# Complete dense tuple 1 shared-child exact review

The complete 36-term shared-child contraction is **C = -940520760199586648427969 / 1298074214633706907132624082305024 + 0i**. The two disjoint coarse children have equal normalized contractions, so the full tuple 1 contribution is **2C = -940520760199586648427969 / 649037107316853453566312041152512 + 0i**. This closes tuple 1 in dense group 128 descendant (0, 0), at the normalized conditioned contribution level.

## Cases 32–35

| Case | Coordinate | Exact normalized real | Imaginary |
| --- | --- | --- | --- |
| 32 | (129, (1,)) | -267084693321160233475629/10384593717069655257060992658440192 | 0 |
| 33 | (129, (2,)) | -91090968698095074444159/2596148429267413814265248164610048 | 0 |
| 34 | (136, (1,)) | -267084693321160233475629/10384593717069655257060992658440192 | 0 |
| 35 | (136, (2,)) | -91090968698095074444159/2596148429267413814265248164610048 | 0 |

Their exact subtotal is **-631448568113540531252265 / 5192296858534827628530496329220096 + 0i**.

At publication checkpoint e544530980988bc585053d99c21959f501a3d607, the original separator archive pins the six-factor tuple1-0b parent to uncompressed SHA256 843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077. Matching on its refused pair (0, 1) reproduces 36 supported coordinates on G(0,0,2) and J(1,4,2). Each last case has 213,696 compatible products, and its inverse lift recovers the parent slice with every original axis, row, exact signed coefficient and factor denominator.

The independent lineage implementation recreates the first reduction, preliminary joins of 44,964 and 3,042,432 products, and the exact frontier at each later row cap. The refused forecasts are 5,524,480 for cases 32 and 34 and 4,392,960 for 33 and 35. Each rescued terminal table and input identity verifies separately. The lineage ran in 54.51 seconds. Exact terminal replays use ordinary sparse Gaussian-integer joins with a different schedule and no author quotient or peer projection passes. They take 570,240 or 573,360 products and peak at 25,920 retained rows, with 0.52–0.53 seconds per case. The per-case logs record each raw complex scalar and the single application of the factor denominator and positive external normalization 1/(16*4^64).

## Complete ledger and recombination

The independent retally derives all 36 case identities from the original parent factor tables and the shared roster, sorted by compatible pair count and then coordinate. It checks that the roster accounts for 6,838,272 compatible products, with 12 cases at 142,464 products and 24 at 213,696. The pair counts establish coverage and do not multiply term scalars.

The ledger uses committed eighteen-term-retally.tsv for 0–17, the verified prior review aggregate for 18–31 and the new independent aggregate for 32–35. The first ledger's internal archive hash and subtotal verify. Both newer blocks carry exact matching coordinate and cut hash evidence, and all their 18 cut hashes are distinct. The prior 18–31 report and lineage are bound to their verified manifest. The script requires each of the 36 indices exactly once, verifies each block subtotal and confirms the rational addition with a common-denominator calculation.

The committed exact child equality verifies that the split into the two coarse children is disjoint and exhaustive, with equal factor tables and the same external normalization. The complete ledger records C and 2C on separate rows. The latter counts each coarse child once and applies no second external normalization. The result is scoped to tuple 1 in the named descendant.

## Reproduction

Retain the relative inputs/, replays/ and prior-18-31/ directories. Restore separator.zip, child-equality.zip and cases12-17.zip from the committed Git blobs in SOURCE_PINS.txt. Run these commands from the evidence root.

```sh
sh verify-source-pins.sh
shasum -a 256 -c frozen-inputs.sha256
shasum -a 256 -c retally-inputs.sha256
python3 verify-lineage.py > verify-lineage.out
sh replay-terminals.sh 32 33 34 35
python3 verify-aggregate.py > aggregate.out
python3 retally-complete.py | cmp - complete-ledger.tsv
```

The replay logs contain observed elapsed times, so new runs can change report hashes. Check the preserved evidence with the supplied review manifest before replaying in a fresh copy.
