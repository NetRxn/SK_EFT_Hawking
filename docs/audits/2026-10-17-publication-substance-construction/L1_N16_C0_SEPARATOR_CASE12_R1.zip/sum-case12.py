from fractions import Fraction
from pathlib import Path
import re

root=Path(__file__).resolve().parent
sources=['0-1','1-0','2-1','3-2','preclosure-4','preclosure-5','6-2','7-1','8-1']
pattern=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
total=[Fraction(0),Fraction(0)]
lines=['index\treal\timaginary']
for i,(source,row) in enumerate(zip(sources,(root/'case12-batch.out').read_text().splitlines(),strict=True)):
    index,state,author=row.split('\t',2)
    assert (int(index),state)==(i,'exact')
    report=root/'independent'/f'replay-{source}.out'
    observed=tuple(map(Fraction,pattern.search(report.read_text()).groups()))
    expected=tuple(map(Fraction,pattern.search(author).groups()))
    assert observed==expected
    total=[left+right for left,right in zip(total,observed,strict=True)]
    lines.append(f'{i}\t{observed[0]}\t{observed[1]}')
assert total==[Fraction(9389273727582799968537,5192296858534827628530496329220096),Fraction(0)]
(root/'case12-values.tsv').write_text('\n'.join(lines)+'\n')
print('complete case 12 exact real',total[0],'imaginary',total[1])
