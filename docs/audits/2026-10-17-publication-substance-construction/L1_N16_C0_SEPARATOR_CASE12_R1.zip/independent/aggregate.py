from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import hashlib
import pickle
import re

scratch=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-peer-pair.e9j13C')
axes,rows=literal_eval((author/'case12-probe.roster').read_text())
roster=sorted(rows,key=lambda pair:(pair[1],pair[0]))
assert len(roster)==len({coords for coords,_ in roster})==9
assert 'PASS full nine-case' in (scratch/'check-cuts.out').read_text()
receipts={}
for row in (author/'case12-batch.out').read_text().splitlines():
    case,status,scalar=row.split('\t')
    assert int(case) not in receipts and status=='exact'
    receipts[int(case)]=scalar
assert set(receipts)==set(range(9))
expected_stages=(1,0,1,2,0,0,2,1,1)
real=Fraction()
imaginary=Fraction()
print('case\tcoordinate\treal\timaginary\treplay stage\tproducts\tlargest join\tpeak rows\tinput SHA256')
for case, (coordinate, _) in enumerate(roster):
    stage=expected_stages[case]
    is_late=case in (4,5)
    replay_log=(scratch/(f'replay-preclosure-{case}.out' if is_late else f'replay-{case}-{stage}.out')).read_text()
    replay_input=author/(f'preclosure-case-{case}-{stage}.pkl' if is_late else f'label-case-{case}-{stage}-reduced-frontier.pkl')
    input_bytes=replay_input.read_bytes()
    digest=hashlib.sha256(input_bytes).hexdigest()
    state=pickle.loads(input_bytes)
    assert tuple(dict(state['conditioning'])[axis] for axis in axes)==coordinate
    if is_late:
        early=pickle.loads((author/f'label-case-{case}-{stage}-reduced-frontier.pkl').read_bytes())
        assert state['conditioning']==early['conditioning']
        assert state['label_partition']==early['label_partition']
    found=re.search(r'^exact normalized real (\S+) imaginary (\S+) independent matched products (\d+) wall',replay_log,re.M)
    assert found
    re_raw,im_raw,products=found.groups()
    r,i=map(Fraction,(re_raw,im_raw))
    wanted=re.fullmatch(r'exact normalized real (\S+) imaginary (\S+) peak rows \d+ matched products \d+',receipts[case])
    assert (r,i)==tuple(map(Fraction,wanted.groups()))
    joins=[tuple(map(int,match)) for match in re.findall(r'^independent join \d+ \d+ products (\d+) output rows (\d+) remaining ',replay_log,re.M)]
    peak_products=max(cost for cost,_ in joins)
    peak_rows=max(rows for _,rows in joins)
    assert peak_products<=8000000 and peak_rows<=1000000 and int(products)<=30000000
    print(case,coordinate,r,i,'three-factor' if is_late else 'direct',products,peak_products,peak_rows,digest,sep='\t')
    real+=r
    imaginary+=i
print('TOTAL',real,imaginary,sep='\t')
