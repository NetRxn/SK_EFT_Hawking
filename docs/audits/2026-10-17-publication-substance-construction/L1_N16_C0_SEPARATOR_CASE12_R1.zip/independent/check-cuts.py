from ast import literal_eval
from collections import Counter
from pathlib import Path
import pickle

root = Path('/private/tmp/l1-tuple-separators.OxRDWT')
previous = Path('/private/tmp/l1-dense-resume.bbZW6V')

def load(path):
    return pickle.loads(path.read_bytes())

def audit(source, pair, fixed_axes, plan, children):
    parent = load(source)
    factors = parent['factors']
    degree = Counter(w for axes, _, _ in factors for w in axes)
    assert set(degree.values()) == {2}
    left, right = (factors[i] for i in pair)
    common = set(left[0]).intersection(right[0])
    ordered = tuple(sorted(common))
    buckets = Counter(tuple(dict(zip(right[0], row))[a] for a in ordered) for row in right[1])
    spectrum = Counter()
    for row in left[1]:
        assignment = dict(zip(left[0], row))
        multiplicity = buckets[tuple(assignment[a] for a in ordered)]
        if multiplicity:
            spectrum[tuple(assignment[a] for a in fixed_axes)] += multiplicity
    assert spectrum == plan
    for coordinate, path in children.items():
        fixed = dict(zip(fixed_axes, coordinate))
        child = load(path)
        assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
        assert child['label_partition'] == parent['label_partition']
        for (axes, rows, denominator), (small_axes, small_rows, small_denominator) in zip(factors, child['factors'], strict=True):
            assert denominator == small_denominator
            assert tuple(w for w in axes if w not in fixed) == small_axes
            expected = {row: value for row, value in rows.items()
                        if all(row[p] == fixed[w] for p,w in enumerate(axes) if w in fixed)}
            recovered = {}
            for row,value in small_rows.items():
                assignment = dict(zip(small_axes,row))
                assignment.update(fixed)
                recovered[tuple(assignment[w] for w in axes)] = value
            assert recovered == expected
    print(source.name, 'pair',pair,'cuts',fixed_axes,'cases',len(spectrum),
          'sum/max products',sum(spectrum.values()),max(spectrum.values()),'children audited',list(children),flush=True)

root=Path('/private/tmp/l1-peer-pair.e9j13C')
source=root/'row-cap-physical-slice-dense-label-case12-reduced.pkl'
axes, raw=literal_eval((root/'case12-probe.roster').read_text())
counts=dict(raw)
assert len(axes)==1 and len(counts)==9 and len(raw)==9
order=sorted(counts,key=lambda coord:(counts[coord],coord))
children={}
for index, coordinates in enumerate(order):
    childfile=root/f'case-{index}.pkl'
    if not childfile.is_file():
        continue
    # File completeness is checked by loading the entire pickle.
    if not (root/f'case-{index}-0-reduce.out').is_file():
        continue
    assert literal_eval((root/f'case-{index}.roster').read_text()) == (axes,raw)
    children[coordinates]=childfile
    child=load(childfile)
    for log in root.glob(f'case-{index}-*-contract.out'):
        lines=log.read_text().splitlines()
        if not lines or not lines[-1].startswith('exact normalized real '):
            continue
        stage=log.name.split('-')[2]
        final=load(root/f'label-case-{index}-{stage}-reduced-frontier.pkl')
        assert final['conditioning']==child['conditioning']
        assert final['label_partition']==child['label_partition']
    print('case',index,coordinates,'matched',counts[coordinates],flush=True)
assert len(children)==9
audit(source,load(source)['rejected_pair'],axes,counts,children)
print('PASS full nine-case projection coverage and inverse lifting with coefficients, denominator and conditioning intact')
