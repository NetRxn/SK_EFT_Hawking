# L3 fixed-G Schwarzschild transfer

The two source paths reproduce byte-for-byte and the exact candidate PDF rebuilds in four pages at 3040 declared word equivalents. Both author and reviewer focused thermodynamics runs passed 58 tests. The candidate remains an unapplied publication checkpoint. The canonical Lean declaration catalog lacks both newly cited names, and its source fallback is not native evidence. The physical ADW/acoustic matches and full L3 acceptance remain open.
