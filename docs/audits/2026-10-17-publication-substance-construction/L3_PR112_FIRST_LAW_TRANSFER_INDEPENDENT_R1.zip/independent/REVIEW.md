# L3 fixed-G Schwarzschild first-law transfer | independent review

**Verdict.** Pass for exact donor source transfer, bounded manuscript statement,
and PDF reproduction. Hold for authoritative native build, extraction, and
catalog-backed composition. This independently reviewed transfer covers the
fixed-coupling Schwarzschild family and its algebraic varying-coupling
control. The classified ADW exterior and acoustic first-law matching remain
open, as do the other physical laws under L3 finding 2.1.

## Custody and Git application

The primary continuity packet l3-firstlaw-transfer-independent-r1 reported
`fresh: true` and `changed: []`. The transfer manifest SHA-256 is
6a3b3c5da84b6a5d1ebb6e0111364276a30480dd33e34fc29c92c4b9b8c8675d.
All eight entries verified using `shasum -a 256 -c transfer-manifest.sha256`.

I exported both target paths from exact PR112 base
e4c2212143de0bb0bd6fa19357af7a0926e29e43 using Git archive into isolated
scratch. I regenerated path-scoped diffs from the parent of Lean donor
d006634b171222be7cfde9becb2332d317058cfd and from the parent of prose donor
d4543e0fe2f56e58ce99f0bddada70a514dc6f51. Each diff was byte-identical
to its donor patch in the package. The PR112 Lean preimage was
byte-identical to the Lean donor preimage. Independent `git apply --check`,
`git apply`, and `cmp` reproduced both transferred files. The postimage of
`ExactSolutions.lean` also matched the complete Lean donor blob. A second
scratch export applied the manifest-covered source.patch and reproduced
both postimages. That patch rebases the prose hunk's index and line
coordinates to PR112 and carries the same body as the prose donor. This
verifies the two adopted paths. The donors' separate change-log edits and
the historical prose donor PDF are outside this transfer. The base catalog
and candidate catalog compare byte-for-byte equal.

## Mathematical and manuscript scope

In ExactSolutions the geometric mass m gives A=16πm² and κ=1/(4m).
Thus dA=32πm dm and κ dA/(8πG)=dm/G wherever m,G are nonzero.
The fixed-G theorem assumes G>0, M(t)>0, and HasDerivAt of physical M
at t. Substitution m=GM gives dm=G dM and the stated identity. The
Lean proposition includes the area derivative as a conjunct.
The varying-G control assumes positivity at t and derivatives of
both coupling and mass. Then dm=G dM+M dG, giving the stated area term
dM+M dG/G. A nonzero dG supplies a genuine adverse case to extending
the fixed-coupling identity without its hypothesis. The source theorem
is an identity along the Schwarzschild algebraic family of profiles.
Its premises and conclusion do not involve a dynamical field equation
or a physical varying-coupling work law.

The applied prose separates the existing mechanical slot from the
Schwarzschild identity. It specifies differentiability, positive
physical mass at evaluation, fixed positive coupling, geometric
mass m=GM, and the two relevant profiles. It presents the varying-G
formula as an algebraic area control. It requires area and surface
gravity matching for the classified emergent branch and a separate
energy balance for the acoustic branch. The adjacent existing text
also leaves physical first-law identification, microscopic action,
exterior and mass matching, and acoustic energy and entropy balances
open. A future application to the classified branch must establish
fixed-coupling applicability and the mass and surface gravity
normalizations in addition to matching the profiles.

## Rebuilt PDF and length

I regenerated the PDF in isolated scratch using the independently
transferred TeX and exact PR112 counts and figure inputs. I matched
those three inputs byte-for-byte with the frozen tree, used the frozen
PDF's creation timestamp for TeX's source-date epoch, and ran three
pdflatex passes with the repository's stable trailer configuration.
The freshly built PDF is byte-identical to the frozen candidate, SHA-256
3a54b449725b4a58c73c7783172b0ca41afb47aa01fe8c2dbe9248f9d07dab0c.
The fresh final log has zero overfull boxes, TeX errors, and unused
global class options. The package's incidental in-tree paper_draft.log
does list intermediate overfull boxes. The isolated final-pass log
and exact byte match establish the final PDF outcome.

Independent pdfinfo found four US-letter pages. The fresh text
extraction matched the candidate layout. I rendered and inspected all
four pages. The two theorem names, equations, and matching qualifications
are legible in the first column of page 3. One line introducing the
paragraph sits at the foot of page 2 and continues on page 3. This is
a minor page-break blemish without clipping, collision, or missing
content. The project measure reproduces 2,740 extracted tokens plus
300 for one figure, giving 3,040 against the declared 3,750 ceiling,
with 710 word equivalents of headroom.

A fresh scoped run of tests/test_bh_thermodynamics.py with pytest cache
and bytecode writes disabled passed 58 tests. It checks the focused
Python substrate. No Lean compile/extraction was attempted in this review.

## Catalog hold

Independent JSON parsing checked exact names and every final name segment.
Both manuscript-cited declarations are absent in base and candidate:

- SKEFTHawking.ExactSolutions.schwarzschild_fixed_G_firstLaw
- SKEFTHawking.ExactSolutions.schwarzschild_varying_G_area_control

The new public area-profile derivative helper is also absent, while
the neighboring prior area identity is present as a positive control.
I tested the actual candidate scanner on both manuscript occurrences.
Each resolves as UNRESOLVED_SHALLOW with the catalog-only lookup and
PRIVATE after the deep source-declaration fallback, despite the
declarations being public in source. The corpus-wide prose-check log
exits 1 for separate D10 and legacy-ratchet findings. Its lack of an L3
error follows from the fallback and supplies no native extraction
evidence. Acceptance requires an authoritative exact-candidate build,
catalog extraction/readback of the named records, and reconciliation
of affected manuscript counts and consumer evidence. This review grants
no stage or finding closure.

Shared sources, Git refs, the notebook, and Lean slots were untouched.
