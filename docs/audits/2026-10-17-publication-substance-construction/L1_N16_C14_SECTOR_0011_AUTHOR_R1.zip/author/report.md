# Exact LLRR sector of original N16 c14

The pinned authority is original periodic closed source_C at clean
primary 27012c18fa374e8341e124b510abbedeedb18d29. This is ordered
chirality sector 0011 of the zero-centered (01,01,23,23) row.
It fixes original trace occurrences 0 and 1 to L and 2 and 3 to
R. Each q coordinate is relabeled 0–3 within its fixed chirality
while its original anchor and occurrence remain distinct.
The exact sector contribution is
1598276428965/72057594037927936 + 0i, with the original row
divisor 512 and separate S4 multiplier 24^5 applied once.

## Original factor and mask stages

The frozen eleven-join LLLL partial schedule runs on the actual
0011 factors and retains the original labels and signed source
order. The original tile and bridge supports are independently
reconstructed. Eleven signed primitive rays per mixed interior
factor reconstruct all exterior mask slices exactly. The actual
mask stage fits its 4,000,000-operation cap. It joins 139,229
complementary rank-zero products and retains 1,853 nonzero
six-ray weights, with 1,173,130 charged visits, 8,768 tracked
rows and 272,971 serialized bytes. The fixed rank-zero controls
use the literal eight-generator word and reverse sign when
the top orientation is reversed.

## Admitted exact tensor schedule

The earlier selected-output planning route refused prospectively
at operation 4,000,001. The replacement uses a different exact
route. For each E or F ray, join the two original source trace
tables first on their residual coordinate labels. Accumulate
the signed trace-pair tensor on four paired spoke coordinates.
Apply the four exact sparse Gaussian basis transforms in
sequence, then keep only the selected basis entries for that
ray. This operates on original source coefficients, rather
than inferring a value from another sector.

The recorded admission is 17,611,304 aggregate visits under a
24,000,000 bound. All 22 ray partitions are individually
prospectively bounded by 813,568 visits under 4,000,000.
Their actual maximum was 370,624 visits. The largest nonzero
intermediate table had 18,432 rows under 200,000. The whole
tensor transform and scalar combination used 6,583,496 visits
and a sampled peak RSS of 37,928,960 bytes. The guards cover
the stated source products, exact sparse axis visits, normalized
integer payload and sampled RSS. Metadata and interpreter
auxiliary allocations are outside the row count. Every ray's
prospective and measured visits and table sizes are frozen.

Serialized readback reconstructs all 44 exact spoke matrices,
evaluates all 515,801 middle products, and independently
combines all 1,853 signed mask and amplitude rows. It reproduces
the exact scalar after normalization. Two distinct exact
original-spoke controls each traverse 65,536 products and
match 36,864 nonzero contributions. The two numerators are
2,415,919,104 and 86,973,087,744. Reversing one contributing
sign changes them to 2,415,788,032 and 86,967,975,936. Each
comparison uses 78,468 visits under its own 4,000,000 cap.

This package evaluates 0011 only. It does not infer 0101 or
apply sector orbit weights. The full representative, other
arrangements, c14, c0, complete denominator and normalization
remain outside this evidence.
