from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import json
from src.core import formulas as f
from src.vestigial import original_coefficients as o

baseline=json.loads(Path('/tmp/publication-task4-multicenter-plan-r1.json').read_text())
r=o.OriginalRegulator()
P,Q,E,S=o.Polynomial,o.QComplex,o.ExteriorPolynomial,o.Symbol
zero=Q(0)
def ident(v): return json.loads(json.dumps(v))
def toggle(s,axis): return tuple(v^(i==axis) for i,v in enumerate(s))
def site(s): return tuple(int(v) for v in s)
x=(0,0,0,0)
w=site(toggle(x,2))
y=site(toggle(x,0))
z=site(toggle(y,2))
sites=dict(x=x,y=y,w=w,z=z)
assert ident(sites)==baseline['sites']
assert r.extents==(2,)*4 and r.boundary_signs==(1,)*4 and r.word=='closed' and r.convention=='source_C'
A=range(4)
def geometry(s):
    star={s,*[site(toggle(s,i)) for i in A]}
    coframe={(p,i) for i in A for p in (s,site(toggle(s,i)))}
    curvature={(s,i) for i in A}|{(site(toggle(s,j)),i) for i in A for j in A if i!=j}
    return star,coframe,curvature,coframe|curvature
labels=('shared_exterior_sites','shared_coframe_anchors','shared_curvature_anchors','shared_total_anchors')
for a,b in combinations(sites,2):
    expected={label:sorted(left&right) for label,left,right in zip(labels,geometry(sites[a]),geometry(sites[b]),strict=True)}
    assert ident(expected)==baseline['pairs'][a+b]
alts=tuple((a,b) for b in range(3) for a in range(5-2*b))
assert len(alts)==9 and len(tuple(product(alts,repeat=2)))==81
pairs=sorted(product(alts,repeat=2),key=lambda v:(sum(2*a+4*b for a,b in v),v))
grades=Counter((aw+az,bw+bz) for ((aw,bw),(az,bz)) in pairs)
assert grades[1,0]==2 and grades[2,0]==3
assert all(2*a+4*b<=8 for a,b in alts)
assert all((1+6*a+4*b)%2 for a,b in grades)

def coframe(c,axis,flavor):
    return o.assemble_coframe(r,f.original_coframe_blocks(r,(c,axis,flavor))).to_exterior(r)
def rows(e):
    return {(mask,symbols):v for mask,p in e.terms for symbols,v in p.terms}
def indices(mask): return [i for i in range(mask.bit_length()) if (1<<i)&mask]
def sign(a,b): return (-1)**sum(i>j for i,j in product(indices(a),indices(b)))
def freeze(v): return tuple(freeze(t) for t in v) if isinstance(v,list) else v
def decode(ks): return tuple(S(fam,freeze(idx)) for fam,idx in ks)

u=coframe(w,0,0)
v=coframe(z,0,0)
left,right=rows(u),rows(v)
assert len(left)==len(right)==64
whole=defaultdict(lambda:zero)
overlaps=0
for (m,ks),(n,ls) in product(left,right):
    if m&n:
        overlaps+=1
        continue
    whole[m|n,tuple(sorted(ks+ls))]+=left[m,ks]*right[n,ls]*sign(m,n)
assert {k:v for k,v in whole.items() if v}==rows(u*v)
cf=baseline['coframe_control']
assert str(whole[int(cf['exact_mask'],16),decode(cf['exact_symbols'])])==cf['exact_coefficient']
ml,mr=map(lambda s:int(s,16),cf['overlap_masks'])
kl,kr=map(decode,cf['overlap_symbols'])
assert left[ml,kl] and right[mr,kr] and ml&mr
assert E(((ml,P(((kl,left[ml,kl]),))),))*E(((mr,P(((kr,right[mr,kr]),))),))==E()

def anchor_matrix(anchor):
    s,axis=anchor
    return f.original_spin4_link(*[
        tuple(P.variable(S('q',(s,axis,hand,i))) for i in A)
        for hand in ('L','R')])
def epsilon(q):
    return (-1)**sum(q[i]>q[j] for i in range(4) for j in range(i+1,4))
def matrix_product(factors):
    a=o.identity_matrix(4)
    for b in factors: a=o.matrix_multiply(a,b)
    return a
def grouped_trace(s):
    traces=[]
    for k,l in ((0,1),(1,0)):
        a,b,c,d=map(anchor_matrix,((s,k),(site(toggle(s,k)),l),(site(toggle(s,l)),k),(s,l)))
        plaquette=matrix_product((o.matrix_dagger(d),o.matrix_dagger(c),b,a))
        for mu,nu,cf,df in ((2,3,0,1),(3,2,1,0)):
            complete=matrix_product((plaquette,r.gamma[cf],r.gamma[df],r.gamma5))
            traces.append(sum((complete[i][i] for i in A),P())*F(epsilon((k,l,mu,nu)),4))
    t=sum(traces,P())
    assert len(t.terms)==128 and all(tr*4==t for tr in traces)
    return dict(t.terms)

t=baseline['curvature_path']
raw=grouped_trace(w)[decode(t['trace_symbols'][0])]*grouped_trace(z)[decode(t['trace_symbols'][1])]
occupied=0
for c,axis,flavor,mask,key in zip((w,w,z,z),(2,3,2,3),(0,1,0,1),t['coframe_masks'],t['coframe_symbols'],strict=True):
    mask=int(mask,16)
    assert not occupied&mask
    raw*=rows(coframe(c,axis,flavor))[mask,decode(key)]*sign(occupied,mask)
    occupied|=mask
assert occupied==int(t['exterior_mask'],16) and str(raw)==t['branch_path_coefficient']
shared=set(decode(t['trace_symbols'][0]))&set(decode(t['trace_symbols'][1]))
assert decode(t['repeated'])[0] in shared
print(json.dumps(dict(topology_pairs=6,power_pairs=len(pairs),request_identities=len(pairs)*3,coframe_candidate_pairs=len(left)*len(right),overlap_pairs=overlaps,
    nonzero_coframe_coefficients=len(rows(u*v)),coframe_exact_value=cf['exact_coefficient'],
    curvature_branch_value=str(raw),curvature_trace_rows_per_center=128,full_two_center_coefficients=0),indent=2))
