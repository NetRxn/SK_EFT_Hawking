# Complementary tuple 0 outer case 28 independent exact review

The nine separate exact terminal replays sum to **-603848671539328985994783 / 5192296858534827628530496329220096 + 0i**. This is outer case 28 of the selector-1 child of tuple 0 in dense group 128 descendant (0, 0). It matches the same coordinate's accepted selector-0 scalar and derives from its own distinct parent and exact inputs.

At publication checkpoint e7117dc4ac893ed733c2445296337e5020328442, the original separator pins the eight-factor tuple0-1 parent to uncompressed SHA256 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d. Independent projected matching reproduces the full original 48-case roster and 6,427,904 pair matches. Case 28 is coordinate (34, (3,)), with 141,792 matches and 403,656 stored rows. An exact inverse lift recovers its restricted parent rows, axes, signed coefficients and denominators.

Both outer row caps are rebuilt from the pinned parent and produce the exact seven-factor inner restart with SHA256 c8415453628018189a5c56ce3a47bde00a9e98d707f4fb10f7114ebca46d066d. The independent inner census on G(0,1,2) gives all nine supported coordinates with 2,911,488 products total, minimum 195,456 and maximum 465,024. Each conditioned child's inverse lift exactly recovers its source factor slices. The source audit took 14.88 seconds. Clean execution of frozen author programs reproduces the cap/checkpoint bytes, reductions and terminal author receipts separately from the independent mathematical replays. All 15 cap snapshots verify, comprising six join refusals and nine row refusals. The byte-for-byte lineage run took 190.46 seconds.

| Slice | Coordinate | Products in the inner census | Exact normalized real |
| --- | --- | --- | --- |
| 0 | 12 | 195456 | -5692727247760044234855/2596148429267413814265248164610048 |
| 1 | 192 | 199296 | -7741476545915524167/81129638414606681695789005144064 |
| 2 | 96 | 232512 | -2164765870170958229109/162259276829213363391578010288128 |
| 3 | 144 | 232512 | -2164765870170958229109/162259276829213363391578010288128 |
| 4 | 48 | 265728 | 1846598470298593469829/649037107316853453566312041152512 |
| 5 | 3 | 394752 | -131056210396553359661415/2596148429267413814265248164610048 |
| 6 | 5 | 461184 | -143949272609465419525695/5192296858534827628530496329220096 |
| 7 | 80 | 465024 | -15533460303436396556379/2596148429267413814265248164610048 |
| 8 | 160 | 465024 | -15533460303436396556379/2596148429267413814265248164610048 |

All imaginary values are exactly zero. Slices 2 and 3 use exact support semijoins followed by ordinary Gaussian-integer contraction. Slices 0, 1, 4, 7 and 8 use plain independent sparse joins. Each replay of slice 2 or 3 uses 1,386,280 products, and each replay of slice 7 or 8 uses 8,543,036.

The two three-factor contractions for slices 5 and 6 use independent pivot 1, compared with author pivot 0. Each full alternate replay covers 13,317,120 supported triangles using 13,394,880 Gaussian multiplications. Independent projection histograms validate all eight sorted pivot intervals for each original shard stack, with 82,784 author pivot rows per stack, and verify the exact raw and normalized shard sum against each alternate pivot replay. The shard census took 1.31 seconds.

Every replay preserves the exact raw scalar and combines the factor-denominator product 40512224221827380280140849737629696 with the positive external scale 1/(16*4^64) once. The committed selector-0 ledger is used only to compare the completed selector-1 result.

## Reproduction

Retain inputs/, scripts/ and replays/ as relative directories. The separator.zip and first-child.zip archives can be restored from the pinned Git objects. The generated lineage directory can be recreated from the frozen inputs. Run the checks in a fresh copy, with no generated lineage/ directory.

```sh
sh verify-source-pins.sh
shasum -a 256 -c frozen-inputs.sha256
shasum -a 256 -c source-archives.sha256
python3 audit.py > audit.out
python3 verify-lineage.py outer 0 1 2 3 4 5 6 7 8 > verify-lineage.out
python3 replay-all.py > replay-all.out
python3 verify-shards.py > verify-shards.out
python3 verify-cap-list.py > cap-list.out
python3 aggregate.py > aggregate.out
python3 compare-first.py > compare-first.out
```
