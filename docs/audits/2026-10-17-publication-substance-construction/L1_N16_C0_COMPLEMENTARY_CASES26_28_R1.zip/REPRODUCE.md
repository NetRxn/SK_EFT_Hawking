# Complementary tuple 0 outer cases 26 and 28

Restore each original selector-1 parent using the review source pins.
Run the corresponding author outer cut, reduction, and primary/rescue
contractions to rebuild the seven-factor row-cap parent. Run run-primary.py
and reduce-open.py for the nine inner coordinates. Triangles 5 and 6 use
the eight disjoint shards and sum-shards.py for each inner index. Consult
the individual author and reviewer receipts and match their exact restart
hashes. Use trusted checkpoint inputs when deserializing.

Compare preceding-twenty-six.tsv with twenty-six-term-retally.tsv from the
committed case 25 archive. Run python3 verify-and-retally.py to check all
eighteen signed values and the cumulative exact subtotal. The two new
terms are cases 26 and 28. Case 27 remains open at this checkpoint.

In the case 25 archive, the last two numeric fields in the audit output
after the slice coordinate must be read with its review table. On the two
triangle PASS lines, the displayed count 8 is the number of shards. The
number of projected products is 394,752 per inner cut, as independently
verified in the roster and recorded in the report. The calculation and
normalized values are unaffected. Original review bytes are preserved.
