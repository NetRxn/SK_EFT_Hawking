"""Verify the two author anchor covers against exact input and the independent third sum."""
from ast import literal_eval
import re
from triangle_replay import CASE, DIR, BASE, N, PIN, PINS, build, file_digest, load

def main():
    assert CASE in (0,5)
    replay=(DIR/'extra-replay.out').read_text()
    real,imag,den=map(int,re.search(rf'(?m)^whole original L{CASE} triangle raw (-?\d+) (-?\d+) (\d+) elapsed ',replay).groups())
    assert den==N and imag==0
    count=int(re.search(rf'(?m)^independent third anchor forecast {CASE} \d+ (\d+)$',replay)[1])
    forecast=(DIR/'terminal.out').read_text()
    terminal=(DIR/'terminal-sharded.out').read_text() if CASE==5 else forecast
    assert count==(12_367_104 if CASE==0 else 25_559_040)
    assert 0<count<=40_000_000
    if CASE==5:
        assert not re.search(r'^triangle signed numerator',forecast,re.M) and count>20_000_000
    with (BASE/f'pass{PINS["passes"]}-result.pkl').open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==PIN
        f.seek(0)
        factors=load(f)['factors']
    with (DIR/'author-triangle-audit.tsv').open('w') as out:
        print('anchor','start','stop','triplets','author_raw_real','author_raw_imag',sep='\t',file=out)
        for anchor,a,b in ((0,1,2),(1,0,2)):
            declared=re.search(rf'(?m)^triangle forecast {anchor} {a} {b} (\d+) chunks (\[.*\]) seconds ',forecast)
            assert int(declared[1])==count
            intervals=literal_eval(declared[2])
            shards=[tuple(map(int,z)) for z in re.findall(
                rf'(?m)^triangle shard {anchor} {a} {b} (\d+) (\d+) (\d+) (-?\d+) (-?\d+)$',terminal)]
            if CASE==5:
                assert [row[:3] for row in shards]==intervals
                assert (sum(row[3] for row in shards),sum(row[4] for row in shards))==(real,imag)
            else:
                assert not shards and 2*count<=40_000_000
            X,px,py,L,R=build(factors,anchor,a,b)
            actual=idx=running=0
            assert intervals[0][0]==0
            for i,key in enumerate(X):
                running+=len(L.get(px(key),{}).keys() & R.get(py(key),{}).keys())
                lo,hi,expected=intervals[idx]
                assert running<=8_000_000
                if i+1==hi:
                    assert 0<running==expected
                    actual+=running
                    print(anchor,lo,hi,expected,*(shards[idx][3:] if shards else ('','')),sep='\t',file=out)
                    idx+=1
                    running=0
                    if idx<len(intervals): assert intervals[idx][0]==hi
            assert idx==len(intervals) and running==0 and actual==count and intervals[-1][1]==len(X)
            signed=re.search(rf'(?m)^triangle signed numerator {anchor} {a} {b} (-?\d+) (-?\d+) denominator (\d+)(?: seconds .*)?$',terminal)
            assert tuple(map(int,signed.groups()))==(real,imag,den)
    print('independently checked both author interval covers, compatible signed products per anchor',count)
    print('both author signed sums agree with independent third anchor',real,imag,den)

if __name__=='__main__':
    main()
