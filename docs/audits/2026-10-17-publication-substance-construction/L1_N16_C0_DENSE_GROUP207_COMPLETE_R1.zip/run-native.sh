#!/bin/sh
set -eu
label="$1"
source="/private/tmp/l1-geometry-component3-preparation.HJyusc/207/cached-original-roster/L${label}"
result="author/L${label}"
python3 -B configure.py "$label"
cp "$source"/{contraction.out,contraction.receipt,contraction.err,condition.py,joint-label-roster.tsv,preparation.out} "$result/"
if test "$label" = 0; then
    for f in contraction.out contraction.receipt contraction.err contract-slice.py; do
        cp "$source/$f" "$result/original-$f"
        cp "$source/budget-rescue/$f" "$result/$f"
    done
    diff -u "$result/original-contract-slice.py" "$result/contract-slice.py" > "$result/capture-source.diff" || test "$?" = 1
fi
/usr/bin/time -p python3 -B -u source.py "$label" > "$result/native-replay.out" 2> "$result/native-replay.time"
