"""Evaluate each disjoint interval of the pinned signed triangle."""
from itertools import islice
from pathlib import Path
from time import perf_counter
from triangle import DEN, PAIR, TOTAL, graph, prod, read, sha, visit

path = Path("pass2-result.pkl")
assert sha(path) == "845ad54054da24d4f228aa82dfe2e32677d77a547a64b601befb246f9f7b7374"
factors = read(path)["factors"]
assert len(factors) == 3 and prod(den for _, _, den in factors) == DEN

start = perf_counter()
receipts = []
for pivot in ((0, 1, 2), (1, 0, 2)):
    tables = graph(factors, *pivot)
    count, _, _, plan = visit(tables)
    assert count == 25559040 and count <= TOTAL
    assert plan[0][0] == 0 and plan[-1][1] == len(tables[0])
    assert all(left[1] == right[0] for left, right in zip(plan, plan[1:]))
    values = []
    for lo, hi, expected in plan:
        assert 0 <= expected <= PAIR
        rows = dict(islice(tables[0].items(), lo, hi))
        actual, real, imaginary, chunks = visit((rows, *tables[1:]), True)
        assert actual == expected and chunks == [(0, hi - lo, expected)]
        values.append((actual, real, imaginary))
        print("triangle shard", *pivot, lo, hi, *values[-1], flush=True)
    n, x, y = map(sum, zip(*values, strict=True))
    assert n == count
    receipts.append((n, x, y))
    print("triangle signed numerator", *pivot, x, y, "denominator", DEN, flush=True)
assert receipts[0] == receipts[1]
print("elapsed", perf_counter() - start, flush=True)
