#!/bin/bash
set -eu
label="$1"
stage="$2"
a="/private/tmp/l1-geometry-component3-preparation.HJyusc/207/cached-original-roster/L${label}"
d="author/L${label}"
original="$a"
if [ "$label" = 0 ]; then a="$a/budget-rescue"; fi
parent=$(realpath "$original/../../dense-saturated-frontier.pkl")
if [ "$#" = 3 ]; then python3 -B configure.py "$label" "$stage" "$3"; else python3 -B configure.py "$label" "$stage"; fi
review="$PWD"
(
    cd "$a"
    shasum -a 256 "$parent" ./*.pkl
    if [ "$label" = 0 ]; then shasum -a 256 ../dense-saturated-frontier.pkl; fi
    cp ./*.py ./*.out contraction.err contraction.receipt "$review/$d/"
) > "$d/complete-operands.sha256"
cp "$original/../solve-L${label}.out" "$d/solve.out"
cp "$original/../solve-L${label}.time" "$d/solve.time"
(cd "$a" && shasum -a 256 -c "$review/$d/complete-operands.sha256") > "$d/operands-verify.out"
/usr/bin/time -p python3 -B -u verify.py "$label" > "$d/replay.out" 2> "$d/replay.time"
