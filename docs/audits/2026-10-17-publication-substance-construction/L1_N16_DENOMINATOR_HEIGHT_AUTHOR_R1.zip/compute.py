from math import factorial, prod
import json

def primes_up_to(n):
    return [p for p in range(2,n+1) if all(p%d for d in range(2,1+int(p**0.5)))]

def valuation(n, p):
    out = 0
    while n:
        n //= p
        out += n
    return out

def haar_bound(k):
    return 2**k * prod(p**(k//(p-1)) for p in primes_up_to(k+1))

def validate_height(k):
    for p in primes_up_to(k+1):
        # Unbounded number of chiral groups gives a safe envelope. A maximizing
        # partition uses at most k positive groups, within the original 128.
        dp = [0] + [-1] * k
        for t in range(1,k+1):
            dp[t] = max(dp[t-size] + valuation(size+1,p) for size in range(1,t+1))
        assert all(m == t//(p-1) for t,m in enumerate(dp)), (k,p)

old = factorial(32) * 4**96 * (2**96*factorial(97))**128
result = []
for m in range(17):
    p = 32-2*m
    k = 96-4*m
    validate_height(k)
    denom = factorial(m)*factorial(p)*4**(64+p)*haar_bound(k)
    assert old % denom == 0
    assert (2*denom*2**800).bit_length() <= (2*old*2**800).bit_length()
    result.append({"S4_power":m,"S2_power":p,"half_quaternion_degree_bound":k,
        "denominator_bits":denom.bit_length(),
        "good_primes_gt":k+1,
        "modulus_target_bits":(2*denom*2**800).bit_length(),
        "sufficient_number_primes_gt_2pow60":((2*denom*2**800).bit_length()+59)//60})
assert all(result[0]["denominator_bits"] >= r["denominator_bits"] for r in result)
common=factorial(32)*4**96*haar_bound(96)
for r in result:
    m,p,k=r["S4_power"],r["S2_power"],r["half_quaternion_degree_bound"]
    assert common % (factorial(m)*factorial(p)*4**(64+p)*haar_bound(k))==0
print(json.dumps({"existing_common_denominator_bits":old.bit_length(),
                  "new_common_denominator_bits":common.bit_length(),
                  "existing_crt_primes_bound":((2*old*2**800).bit_length()+59)//60,
                  "new_common_crt_primes_bound":((2*common*2**800).bit_length()+59)//60,
                  "per_coefficient":result},indent=2))
