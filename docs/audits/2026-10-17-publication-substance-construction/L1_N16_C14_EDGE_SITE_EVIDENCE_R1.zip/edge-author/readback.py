"""Independent serialized factored output checks with literal full wedge words."""
from collections import defaultdict
from itertools import product
from pathlib import Path
import json
import math

ROOT = Path(__file__).parent
meta = json.loads((ROOT/'result.json').read_text())
site = meta['closed_site_rank']
edges = meta['edges']
boundary = [defaultdict(dict) for _ in edges]
slices = [defaultdict(list) for _ in edges]
for axis in range(4):
    path = ROOT/f'edge-{axis}.jsonl'
    for raw in path.read_text().splitlines():
        key,pair = json.loads(raw)
        local,external,*others = key
        outside=(external,*others)
        assert local.bit_count()==external.bit_count()==2
        assert local not in boundary[axis][outside] and any(pair)
        boundary[axis][outside][local]=tuple(pair)
        slices[axis][local].append(outside)
    assert sum(map(len,boundary[axis].values()))==edges[axis]['nonzero_rows']
    assert {str(k):len(v) for k,v in slices[axis].items()} == edges[axis]['local_mask_slices']

def ids(site,mask):
    return [8*site+i for i in range(8) if mask>>i&1]

def sign(parts,extras):
    word=[]
    for axis,(part,external) in enumerate(zip(parts,extras,strict=True)):
        word.extend(sorted(ids(site,part)+ids(edges[axis]['neighbor'],external)))
    if len(set(word))!=len(word):
        return 0
    return (-1)**sum(x>y for i,x in enumerate(word) for y in word[i+1:])

rows={}
visits=0
for line in (ROOT/'site-factors.jsonl').read_text().splitlines():
    parts,s,c=json.loads(line)
    parts=tuple(parts)
    assert parts not in rows
    assert s==sign(parts,[3,3,3,3])
    assert c==math.prod(len(slices[i][p]) for i,p in enumerate(parts))
    rows[parts]=s
    visits+=c
assert len(rows)==meta['exact_factored_site_terms'] and visits==meta['flat_product_visits']

def accum(parts,coeffs,sign_):
    r,i=1,0
    for a,b in coeffs:
        r,i=r*a-i*b,r*b+i*a
    return (r*sign_,i*sign_)

checks=[]
for parts in list(rows)[::53]:
    fixed=[slices[axis][p][0] for axis,p in enumerate(parts)]
    independent_options=[tuple(b[k].items()) for b,k in zip(boundary,fixed,strict=True)]
    independent=(0,0)
    for combo in product(*independent_options):
        p,z=zip(*combo)
        v=accum(p,z,sign(p,[k[0] for k in fixed]))
        independent=tuple(a+b for a,b in zip(independent,v))
    factored=(0,0)
    for p,s in rows.items():
        z=[b[k].get(t,(0,0)) for b,k,t in zip(boundary,fixed,p,strict=True)]
        v=accum(p,z,s)
        factored=tuple(a+b for a,b in zip(factored,v))
    assert independent==factored
    checks.append(dict(open_labels=fixed,numerator=independent,
                       denominator=math.prod(e['exact_denominator'] for e in edges)))
assert any(any(x['numerator']) for x in checks)
print(json.dumps(dict(signed_partitions=len(rows),flattened_visits=visits,
                      fixed_boundary_checks=checks),indent=2))
