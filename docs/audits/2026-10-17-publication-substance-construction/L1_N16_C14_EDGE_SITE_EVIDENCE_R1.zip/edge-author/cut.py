"""Exact factored local contraction for the original c14 01/23 representative."""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import cache
from itertools import combinations, permutations, product
import json, resource, sys
from pathlib import Path

OUT = Path(__file__).parent
SEAM = Path('/tmp/publication-c14-signed-r1.YJ2sFv')
sys.path.insert(0,str(SEAM))
from probe import (REG, RANK, LINKS, POSITION, coframe, owner_specs,
                   original_action_factors_cached, original_coframe_blocks,
                   original_quaternion_haar_moment, trace_anchors, edge, raw_factors)

WORK_CAP = 4_000_000
ROW_CAP = 100_000
BYTE_CAP = 64*1024*1024
FILE_CAP = 4*1024*1024
RSS_CEILING = 384*1024*1024
INT_LIMIT = (1<<61)-1
WORK, STORE = Counter(),Counter()
RSS_PEAK = 0

class Refused(Exception):
    pass

def rss():
    global RSS_PEAK
    n = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    RSS_PEAK = max(RSS_PEAK,n)
    if n > RSS_CEILING:
        raise Refused(('observed_process_peak_RSS', n, RSS_CEILING))

def work(name):
    n = WORK.total()+1
    if n > WORK_CAP:
        raise Refused(('charged_operations',name,n,WORK_CAP))
    WORK[name] += 1
    if n%1024==0:
        rss()

def reserve(name,key,table):
    if key not in table:
        n = STORE['rows']+1
        b = STORE['charged_bytes']+512
        if n>ROW_CAP or b>BYTE_CAP:
            raise Refused(('prospective_tracked_storage',name,n,b,ROW_CAP,BYTE_CAP))
        STORE['rows'], STORE['charged_bytes'] = n,b

def safe(*values):
    if any(abs(n)>INT_LIMIT for n in values):
        raise Refused(('checked_exact_scalar_limit',INT_LIMIT))
    return values

def minus(z):
    return (-z[0],-z[1])

def scale(z,n):
    if n and max(map(abs,z)) > INT_LIMIT//abs(n):
        raise Refused(('prospective_scalar_multiply',INT_LIMIT))
    return safe(z[0]*n,z[1]*n)

def times(z,w):
    bound = max(map(abs,z))*max(map(abs,w))
    if bound>INT_LIMIT//2:
        raise Refused(('prospective_complex_multiply',INT_LIMIT))
    return safe(z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0])

def add(z,w):
    for a,b in zip(z,w):
        if (a>0 and b>0 and a>INT_LIMIT-b) or (a<0 and b<0 and a< -INT_LIMIT-b):
            raise Refused(('prospective_complex_add',INT_LIMIT))
    return safe(z[0]+w[0],z[1]+w[1])

def crossing(left,right):
    swaps=0
    while left:
        low=left & -left
        swaps += (right & (low-1)).bit_count()
        left -= low
    return swaps % 2

def independent_crossing(left,right):
    return sum(j<i for i in range(left.bit_length()) if left>>i&1
               for j in range(right.bit_length()) if right>>j&1) % 2

def labels(anchor0,anchor1):
    return [(x,mu,h,k) for x,mu in (anchor0,anchor1) for h in ('L','R') for k in range(4)]

def scaled4(z):
    a,b=z.real*4,z.imag*4
    assert a.denominator==b.denominator==1
    return safe(a.numerator,b.numerator)

@cache
def component_rows(center,mu,is_raw):
    y=REG.step(center,mu)[0]
    label_idx={s:i for i,s in enumerate(labels((min(center,y),mu),(max(center,y),mu)))}
    out={}
    def emit(a,m,k,z):
        assert len(k)==1 and k[0].index in label_idx
        work('extract_raw_increment' if is_raw else 'extract_canonical')
        key=(label_idx[k[0].index],a,m)
        reserve('component',key,out)
        out[key]=add(out.get(key,(0,0)),z)
    for a in range(4):
        alpha=(center,mu,a)
        if not is_raw:
            for m,p in coframe(alpha).terms:
                for k,z in p.terms:
                    emit(a,m,k,scaled4(z))
            continue
        for block in original_coframe_blocks(REG,alpha,LINKS):
            for i,row in enumerate(block.matrix):
                for j,p in enumerate(row):
                    i0=POSITION[(block.bar_site,'bar',i)]
                    j0=POSITION[(block.psi_site,'psi',j)]
                    m=(1<<i0)|(1<<j0)
                    pref=4*block.weight*(-1 if i0>j0 else 1)
                    assert pref in (1,-1)
                    for k,z in p.terms:
                        w=z.real*pref,z.imag*pref
                        assert all(x.denominator==1 for x in w)
                        emit(a,m,k,tuple(x.numerator for x in w))
    assert all(v!=(0,0) for v in out.values())
    return out

def roster():
    row = json.loads((SEAM/'result.json').read_text())['results']['single-center-mixed']['roster']
    assert row['planes']==[[0,0,1],[0,0,1],[0,2,3],[0,2,3]]
    return row

def star_owners(row,site_rank):
    incident=[]
    x=REG.sites[site_rank]
    for mu in range(4):
        e=edge(x,mu)
        y=REG.step(x,mu)[0]
        frame,trace=[],[]
        for occurrence,(i,a,b) in enumerate(row['planes']):
            center=REG.sites[i]
            for axis in (a,b):
                if edge(center,axis)==e:
                    frame.append(('S2',i,occurrence,axis))
            hits=[(RANK[s],k) for s,k in trace_anchors(center,a,b) if edge(s,k)==e]
            assert len(hits)<=1
            if hits:
                trace.append(('S2',i,occurrence,hits[0]))
                for f in raw_factors(center,(a,b)):
                    assert [(RANK[s],k) for s,k in f.anchors if edge(s,k)==e]==hits
        for i,n in enumerate(row['S4_occupations']):
            if n and edge(REG.sites[i],mu)==e:
                frame.extend(('S4',i,occurrence,mu) for occurrence in range(n))
        assert len(frame)==2 and len(trace) in (0,2)
        incident.append((mu,RANK[y],frame,trace))
    return incident

def moment_primary(keys):
    blocks=[[0]*4 for _ in range(4)]
    for q in keys:
        blocks[q//4][q%4]+=1
    ans=Fraction(1)
    for b in blocks:
        ans *= original_quaternion_haar_moment(b)
    return ans

def moment_raw(keys):
    # S3 rotationally invariant tensor via Kronecker pairings at a fixed
    # anchor/chirality. Pairings cannot connect two independent blocks.
    blocks=defaultdict(list)
    for q in keys:
        blocks[q//4].append(q%4)
    result=Fraction(1)
    for v in blocks.values():
        if len(v)==2:
            result *= Fraction(int(v[0]==v[1]),4)
        elif len(v)==4:
            a,b,c,d=v
            result *= Fraction(int(a==b and c==d)+int(a==c and b==d)+int(a==d and b==c),24)
        else:
            return Fraction()
    return result

def edge_tensor(desc, site_rank, is_raw):
    mu,neighbor,frames,traces=desc
    # Trace legs are open coordinate values of the original literal trace
    # factors, linked by original occurrence ID. No independent-factor split.
    center=REG.sites[frames[0][1]]
    assert frames[1][1]==frames[0][1]
    rows=component_rows(center,mu,is_raw)
    by_q=defaultdict(list)
    for (q,a,mask),z in rows.items():
        by_q[q].append((a,mask,z))
    ends=sorted((site_rank,neighbor))
    trace_sets=[]
    for _,_,_,(i,axis) in traces:
        assert mu==axis
        start=8*ends.index(i)
        trace_sets.append(range(start,start+8))
    degree=2+len(traces)
    denom=48 if degree==4 else 4
    target_bits=0xff<<(8*site_rank)
    outer_bits=0xff<<(8*neighbor)
    out={}
    support=0
    for keys in product(range(16),range(16),*trace_sets):
        work('coordinate_raw' if is_raw else 'coordinate_canonical')
        weight=(moment_raw if is_raw else moment_primary)(keys)*denom
        if not weight:
            continue
        assert weight.denominator==1
        support+=1
        qa,qb,*qt=keys
        for (a,left,z),(b,right,w) in product(by_q[qa],by_q[qb]):
            work('bilinear_raw' if is_raw else 'bilinear_canonical')
            if left & right:
                continue
            mask=left|right
            at=(mask&target_bits)>>(8*site_rank)
            other=(mask&outer_bits)>>(8*neighbor)
            assert at.bit_count()==other.bit_count()==2
            sign=(independent_crossing if is_raw else crossing)(left,right)
            v=scale(times(z,w),(-1 if sign else 1)*weight.numerator)
            key=(at,other,a,b,*qt)
            reserve('edge_tensor',key,out)
            out[key]=add(out.get(key,(0,0)),v)
    for k in tuple(k for k,v in out.items() if v==(0,0)):
        del out[k]
    return out,denom*16,support

def emit(f,row):
    data=json.dumps(row,separators=(',',':')).encode('ascii')+b'\n'
    prospective=STORE['serialized_bytes']+len(data)
    if prospective>FILE_CAP:
        raise Refused(('prospective_serialized_bytes',prospective,FILE_CAP))
    f.write(data)
    STORE['serialized_bytes']=prospective

def write_rows(name,rows):
    # Writes one row at a time, capped tracked bytes are for live table entries.
    with (OUT/name).open('wb') as f:
        for key in sorted(rows):
            work('serialized_edge_row')
            emit(f,[key,rows[key]])

def partitions(counts):
    out={}
    for a,b,c in product(*(sorted(v) for v in counts[:3])):
        work('site_mask_partition')
        if a&b or a&c or b&c:
            continue
        d=255^(a|b|c)
        if d not in counts[3]:
            continue
        parts=(a,b,c,d)
        sign=sum(crossing(x,y) for i,x in enumerate(parts) for y in parts[i+1:])%2
        reserve('site_factored',parts,out)
        out[parts]=(-1 if sign else 1)
    # Independently enumerate each ordered partition via 8! literal words.
    seen=set()
    for labels_ in permutations(range(8)):
        work('site_independent_permutation')
        if any(labels_[i]>labels_[i+1] for i in (0,2,4,6)):
            continue
        parts=tuple((1<<labels_[i])|(1<<labels_[i+1]) for i in (0,2,4,6))
        if any(part not in count for part,count in zip(parts,counts,strict=True)):
            continue
        assert parts not in seen
        reserve('site_raw_partition',parts,seen)
        seen.add(parts)
        inversion=sum(x>y for i,x in enumerate(labels_) for y in labels_[i+1:])
        assert out[parts] == (-1 if inversion%2 else 1)
    assert set(out)==seen
    return out

def main():
    row=roster()
    site_rank=8
    owners=star_owners(row,site_rank)
    rss()
    counts=[]
    edge_results=[]
    for d in owners:
        mu=d[0]
        canonical,den,support=edge_tensor(d,site_rank,False)
        independent,den0,support0=edge_tensor(d,site_rank,True)
        assert canonical==independent and den==den0 and support==support0 and canonical
        write_rows(f'edge-{mu}.jsonl',canonical)
        count=Counter(k[0] for k in canonical)
        counts.append(count)
        edge_results.append(dict(axis=mu,neighbor=d[1],coframes=d[2],open_trace_legs=d[3],
            exact_denominator=den,support_before_bilinear_filters=support,
            nonzero_rows=len(canonical),local_mask_slices=dict(sorted(count.items()))))
        print('edge',mu,len(canonical),den,support,flush=True)
    factored=partitions(counts)
    flattened=0
    first=None
    with (OUT/'site-factors.jsonl').open('wb') as f:
        for p,s in sorted(factored.items()):
            work('serialized_site_factor')
            n=1
            for i,k in enumerate(p):
                n*=counts[i][k]
            if first is None and flattened+n>WORK_CAP:
                first=dict(partition=p,previous_products=flattened,partition_products=n,
                           prospective_products=flattened+n,work_cap=WORK_CAP)
            flattened+=n
            emit(f,[p,s,n])
    rss()
    metadata=dict(row=row,closed_site_rank=site_rank,edges=edge_results,
      exact_factored_site_terms=len(factored),flat_product_visits=flattened,
      flat_refusal=first,charged_operations=dict(WORK),monitored_storage=dict(STORE),
      rss_peak_bytes=RSS_PEAK,cap=dict(work=WORK_CAP,rows=ROW_CAP,
          accounted_bytes=BYTE_CAP,serialized_bytes=FILE_CAP,peak_rss_ceiling=RSS_CEILING,integer_magnitude=INT_LIMIT))
    (OUT/'result.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print('site',len(factored),flattened,first,flush=True)

if __name__=='__main__':
    main()
