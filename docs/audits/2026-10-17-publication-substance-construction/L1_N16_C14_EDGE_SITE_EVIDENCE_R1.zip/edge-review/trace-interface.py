from collections import Counter, defaultdict
from itertools import product
from src.core.formulas import original_action_factors, original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
r=OriginalRegulator()
s=r.sites[0]
anchors=((s,0),(r.sites[8],1),(r.sites[4],0),(s,1))
L={a:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*a,h,k))) for k in range(4)) for h in ('L','R'))) for a in r.link_order}
signed={}
raw=0
for f in original_action_factors(r,s,L):
    axes=tuple(sorted(d for _,d,_ in f.components))
    if axes!=(2,3):
        continue
    assert set(f.anchors)==set(anchors)
    internal=tuple(a for _,_,a in sorted(f.components))
    raw+=1
    for key,z in f.coefficient.terms:
        slot={q.index[:2]:q.index[2:] for q in key}
        assert tuple(sorted(slot))==tuple(sorted(anchors)) and len(key)==4
        fixed=tuple(slot[a] for a in anchors)
        k=(*internal,*fixed)
        signed[k]=signed.get(k,0)+z
result={k:z for k,z in signed.items() if z}
bins=Counter(k[2:4] for k in result)
assert set(bins)<=set(product(product(('L','R'),range(4)),repeat=2))
assert all(h0==h1 and h1==h2 and h2==h3 for _,_,(h0,_),(h1,_),(h2,_),(h3,_) in result)
print('checked actual signed original plane 23 trace over anchors (0,0),(8,1),(4,0),(0,1)')
print('raw branches',raw,'joint signed rows',len(result),'conditioned seam pairs',len(bins),'max rows per seam pair',max(bins.values()))
print('each original trace requires same chirality across all four anchors; conditioned on joint e0/e1 coordinate pair')
