from pathlib import Path
from collections import Counter
import json,sys
p=Path(sys.argv[1])
def bins(axis):
    counts=Counter()
    for key,_ in map(json.loads,(p/f'edge-{axis}.jsonl').read_text().splitlines()):
        m,_,_,_,a,b=key
        assert 0<=a<8 and 0<=b<8
        counts[m,a//4,b//4]+=1
    return counts
a,b=map(bins,range(2))
pairs={tuple(k[:2]) for k,_,_ in map(json.loads,(p/'site-factors.jsonl').read_text().splitlines())}
visits=sum(a[x,h,k]*b[y,h,k] for x,y in pairs for h in range(2) for k in range(2))
assert len(pairs)==108 and visits==17020928
print('direct mask-conditioned axes-0/1 pair products after shared trace chirality filters',len(pairs),visits)
