from collections import Counter
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace
import ast,json,sys
a=Path(sys.argv[1])
m=json.loads((a/'result.json').read_text())
assert sum(m['charged_operations'].values())==406096
assert 512*m['monitored_storage']['rows']==m['monitored_storage']['charged_bytes']==38322176
files=[*(a/f'edge-{i}.jsonl' for i in range(4)),a/'site-factors.jsonl']
assert sum(f.stat().st_size for f in files)==m['monitored_storage']['serialized_bytes']==715296
assert m['rss_peak_bytes']==115572736<m['cap']['peak_rss_ceiling']==384*1024*1024
assert m['monitored_storage']['rows']==74848<m['cap']['rows']
tree=ast.parse((a/'cut.py').read_text())
wanted={'Refused','work','rss','reserve','safe','times','add','scale','emit'}
ns=dict(Counter=Counter,json=json,WORK=Counter(),STORE=Counter(),RSS_PEAK=0,
    WORK_CAP=2,ROW_CAP=2,BYTE_CAP=1024,FILE_CAP=4,INT_LIMIT=127,
    RSS_CEILING=7,resource=SimpleNamespace(RUSAGE_SELF=0,getrusage=lambda _:SimpleNamespace(ru_maxrss=8)))
exec(compile(ast.Module([n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted],[]),'frozen guards','exec'),ns)
def refuses(fn,tag):
    try: fn()
    except ns['Refused'] as e:
        assert e.args[0][0]==tag
    else: raise AssertionError(tag)
for i in range(2):
    ns['work']('charged')
    ns['reserve']('retained',i,{})
refuses(lambda:ns['work']('charged'),'charged_operations')
refuses(lambda:ns['reserve']('retained',2,{}),'prospective_tracked_storage')
b=BytesIO()
ns['emit'](b,0)
refuses(lambda:ns['emit'](b,[0]),'prospective_serialized_bytes')
refuses(lambda:ns['scale']((70,0),2),'prospective_scalar_multiply')
refuses(lambda:ns['times']((90,0),(2,0)),'prospective_complex_multiply')
refuses(lambda:ns['add']((-123,0),(-5,0)),'prospective_complex_add')
refuses(ns['rss'],'observed_process_peak_RSS')
assert ns['WORK']=={'charged':2}
assert ns['STORE']=={'rows':2,'charged_bytes':1024,'serialized_bytes':2}
assert b.getvalue()==b'0\n'
print('guard controls passed for work, cumulative retained rows/bytes, serialized bytes, integer scale/product/addition, sampled RSS')
print('frozen accounting 406096 visits, 74848 retained insertions, 38322176 accounted bytes, 715296 serialized bytes, 115572736 author-observed peak RSS')
