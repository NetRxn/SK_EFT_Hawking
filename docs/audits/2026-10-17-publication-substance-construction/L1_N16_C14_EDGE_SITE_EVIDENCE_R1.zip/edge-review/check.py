from collections import defaultdict, Counter
from fractions import Fraction
from functools import cache
from itertools import combinations, product
from math import prod
from pathlib import Path
import json,sys

from src.core.formulas import original_coframe_blocks, original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol

author=Path(sys.argv[1])
support=Path(sys.argv[2])
M=json.loads((author/'result.json').read_text())
C=json.loads((support/'support-census.json').read_text())['sites']
readback=json.loads((author/'readback.json').read_text())
reg=OriginalRegulator()
site=reg.sites[M['closed_site_rank']]
index={x:i for i,x in enumerate(reg.sites)}
pos={g:i for i,g in enumerate(reg.generator_order)}
assert index[site]==8
assert (reg.extents,reg.boundary_signs,reg.convention,reg.word)==((2,)*4,(1,)*4,'source_C','closed')
links={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in reg.link_order}
def freeze(v):
    return tuple(map(freeze,v)) if isinstance(v,(tuple,list)) else v
assert any(json.loads(line)==M['row'] for line in (support/'c14-occupancy-roster.jsonl').read_text().splitlines())

def edge_id(x,d):
    return tuple(sorted((x,reg.step(x,d)[0])))
def curvature_anchors(x,axes):
    sets=set()
    for degree,c,anchors,terms,_ in C[index[x]]['raw_branches']:
        if degree==2 and tuple(d for d,_ in c)==axes and terms:
            sets.add(tuple(sorted((tuple(y),d) for y,d in anchors)))
    assert len(sets)==1
    return next(iter(sets))

def derive_descriptors():
    instances=[('S2',i,j,(a,b),curvature_anchors(reg.sites[i],(a,b))) for j,(i,a,b) in enumerate(M['row']['planes'])]
    instances += [('S4',i,j,(0,1,2,3),()) for i,n in enumerate(M['row']['S4_occupations']) for j in range(n)]
    desc=[]
    for d in range(4):
        hit=edge_id(site,d)
        neighbor=next(x for x in hit if x!=site)
        frame=[]
        trace=[]
        for family,i,j,axes,anchors in instances:
            for a in axes:
                if edge_id(reg.sites[i],a)==hit:
                    frame.append((family,i,j,a))
            for x,a in anchors:
                if edge_id(x,a)==hit:
                    trace.append((family,i,j,(index[x],a)))
        desc.append((d,index[neighbor],tuple(frame),tuple(trace)))
    return desc
desc=derive_descriptors()
assert desc==[(e['axis'],e['neighbor'],freeze(e['coframes']),freeze(e['open_trace_legs'])) for e in M['edges']]
assert {x[:3] for x in desc[0][3]}=={x[:3] for x in desc[1][3]}=={('S2',0,2),('S2',0,3)}

def mul(z,w):
    return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def inv(word):
    return -1 if sum(a>b for j,a in enumerate(word) for b in word[j+1:])%2 else 1
def addto(out,key,z,s=1):
    x,y=out.get(key,(0,0))
    out[key]=x+s*z[0],y+s*z[1]

def one_frame(c,d,qindex):
    source=defaultdict(list)
    for a in range(4):
        for b in original_coframe_blocks(reg,(c,d,a),links):
            for i,j in product(range(4),repeat=2):
                word=(pos[b.bar_site,'bar',i],pos[b.psi_site,'psi',j])
                for k,z in b.matrix[i][j].terms:
                    assert len(k)==1 and k[0].index[:2]==b.anchor
                    scalar=(z.real*b.weight*4,z.imag*b.weight*4)
                    assert all(q.denominator==1 for q in scalar)
                    source[qindex[k[0].index]].append((a,word,tuple(int(q) for q in scalar)))
    return source

@cache
def sphere(word):
    counts=Counter(word)
    if any(v%2 for v in counts.values()):
        return Fraction()
    num=prod(3 if v==4 else 1 for v in counts.values())
    denom=prod(j for n in Counter(q//4 for q in word).values() for j in range(4,4+n,2))
    return Fraction(num,denom)

edges=[]
zero_rows=[]
for d,neighbor,frames,traces in desc:
    x=reg.sites[neighbor]
    qindex={(y,d,h,k):q for q,(y,h,k) in enumerate(product(sorted((site,x)),('L','R'),range(4)))}
    f0,f1=(one_frame(reg.sites[i],axis,qindex) for _,i,_,axis in frames)
    qsets=[tuple(q for (x,d,h,k),q in qindex.items() if index[x]==i and d==axis) for _,_,_,(i,axis) in traces]
    meta=M['edges'][d]
    scale=meta['exact_denominator']//16
    observed={}
    coordinate_support=0
    for qs in product(range(16),range(16),*qsets):
        H=sphere(qs)*scale
        if not H:
            continue
        assert H.denominator==1
        coordinate_support+=1
        for (a,w,z),(b,t,u) in product(f0.get(qs[0],()),f1.get(qs[1],())):
            word=w+t
            if len(set(word))<4:
                continue
            pmask=lambda rank:sum(1<<(i%8) for i in word if i//8==rank)
            key=(pmask(8),pmask(neighbor),a,b,*qs[2:])
            assert key[0].bit_count()==key[1].bit_count()==2
            addto(observed,key,mul(z,u),inv(word)*int(H))
    zero_rows.append(sum(z==(0,0) for z in observed.values()))
    observed={k:v for k,v in observed.items() if any(v)}
    serialized=dict(map(freeze,map(json.loads,(author/f'edge-{d}.jsonl').read_text().splitlines())))
    assert coordinate_support==meta['support_before_bilinear_filters']
    assert observed==serialized and len(observed)==meta['nonzero_rows']
    assert Counter(str(k[0]) for k in observed)==meta['local_mask_slices']
    print('edge',d,len(observed),'exact zero prunings',zero_rows[-1],'coordinate assignments',coordinate_support,flush=True)
    edges.append(observed)

counts=[Counter(k[0] for k in e) for e in edges]
def partitions(remaining,axis=0,word=()):
    if not remaining:
        masks=tuple(sum(1<<j for j in pair) for pair in word)
        yield masks,inv(sum(word,())),prod(c[m] for c,m in zip(counts,masks,strict=True))
        return
    for pair in combinations(remaining,2):
        if sum(1<<j for j in pair) in counts[axis]:
            yield from partitions(tuple(i for i in remaining if i not in pair),axis+1,word+(pair,))
actual=sorted(partitions(tuple(range(8))))
claimed=list(map(freeze,map(json.loads,(author/'site-factors.jsonl').read_text().splitlines())))
assert actual==claimed and len(actual)==240
total=sum(v for _,_,v in actual)
running=0
first=None
cap=M['cap']['work']
for p,s,n in actual:
    if first is None and running+n>cap:
        first=dict(partition=list(p),previous_products=running,partition_products=n,prospective_products=running+n,work_cap=cap)
    running+=n
assert total==M['flat_product_visits']==2559967232
assert first==M['flat_refusal']
print('site exact partitions',len(actual),'flat bound',total,'first refusal',first,flush=True)

for r in readback['fixed_boundary_checks']:
    outside=freeze(r['open_labels'])
    choices=[[(k[0],z) for k,z in e.items() if k[1:]==h] for e,h in zip(edges,outside,strict=True)]
    out=(0,0)
    for pair in product(*choices):
        word=[]
        for (mask,_),boundary,(_,neighbor,_,_) in zip(pair,outside,desc,strict=True):
            block=[8*8+i for i in range(8) if mask>>i&1]
            block.extend(8*neighbor+i for i in range(8) if boundary[0]>>i&1)
            word.extend(sorted(block))
        if len(set(word))!=16:
            continue
        acc=(1,0)
        for _,z in pair:
            acc=mul(acc,z)
        out=tuple(x+inv(word)*y for x,y in zip(out,acc))
    assert list(out)==r['numerator']
    assert prod(e['exact_denominator'] for e in M['edges'])==r['denominator']
print('all five literal full-word fixed boundary controls matched',flush=True)
