from validate import check_numerical_literals
r = check_numerical_literals()
print(r.passed, r.measured)
for d in r.details:
    if "inline literals across papers" in d.message:
        print(d.message)
