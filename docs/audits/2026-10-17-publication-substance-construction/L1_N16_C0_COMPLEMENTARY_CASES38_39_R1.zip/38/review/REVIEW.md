# Independent verification of complementary tuple 0 outer case 38

The exact normalized sum is
**-175295091928520234333475/2596148429267413814265248164610048 + 0i**.

The original separator archive is pinned to publication checkpoint
f7ddcfd874f6f329fa10537ee38bb2bf2269834b and matches the worktree bytes.
The archive manifest verified. The decompressed complementary parent
SHA256 is 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It selects R(0,0,2,0,1)=1. Its rejected-pair histogram reconstructs the
complete 48-coordinate roster over 6,427,904 products. Case 33 is
(136, (1,)) with 177,240 pair products and an exact inverse lift of
423,946 compatible rows. The equal first-child case 38 scalar is from
selector 0. This review uses the selector-1 factors throughout.
Complementary case 34 has the same scalar at (24, (1,)) and
has a separate seven-factor inner parent.

Two outer row-cap stages reproduce the seven-factor inner parent
306aff126ead8baab1e676d084dc718b2790fc77978b56e6d0b96b2b55d538ea.
The inner rejected-pair histogram reconstructs all nine distinct cuts
of G(0,1,2) over 2,001,024 products. Exact inverse lifts recover every
compatible Gaussian coefficient and denominator for each cut.
The 22 generic inner stages reproduce byte for byte, including
17 cap refusals and five exact terminals. The later capped rescue
inputs for slices 7 and 8 are preserved. The author four-factor
closures both use their corresponding rescue-0 capped operands.

| Slice | Inner coordinate | Projected pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 3 | 44,928 | -7579449762635066717835/2596148429267413814265248164610048 |
| 1 | 48 | 62,208 | -2639017884707118117/20282409603651670423947251286016 |
| 2 | 5 | 169,344 | -8052931203918957247185/649037107316853453566312041152512 |
| 3 | 12 | 169,344 | -9807872755256288789265/324518553658426726783156020576256 |
| 4 | 96 | 217,728 | -4844774857002515229609/649037107316853453566312041152512 |
| 5 | 144 | 217,728 | -4844774857002515229609/649037107316853453566312041152512 |
| 6 | 192 | 248,832 | 16698483434738761677/40564819207303340847894502572032 |
| 7 | 80 | 435,456 | -4753411275679919026065/1298074214633706907132624082305024 |
| 8 | 160 | 435,456 | -4753411275679919026065/1298074214633706907132624082305024 |

Five final states pass independent direct sparse contraction. The
alternate triangles of slices 2 and 3 use pivot 1. Each covers
18,643,968 matching triples and uses 18,752,832 Gaussian products.
The two four-factor replays use independent pair (1,2) and closure
on (0,3), while the author's pair is (1,3). Each of the independent
replays forecasts 6,138,720 selected pair matches and uses 23,692,032
Gaussian products over 11 bounded shards, with at most 2,673,792
products per shard and 24,984 entries per block. The four alternate
replays agree with the author raw numerators and normalized values.
All 32 author shard receipts have complete disjoint row intervals
and sum exactly to the independently contracted values. All nine
terminal calculations use factor denominator
40512224221827380280140849737629696 and normalization 1/(16*4^64)
once.

The timing receipts record five outer commands, 53 inner commands,
nine independent terminal runs and the 32 original author shards.
The independent triangle runs took 14.743 s and 14.388 s. The
four-factor runs took 18.35 s and 18.599 s. These are observed
per-command elapsed times under concurrent scratch execution.

The relative review manifest includes copies of the author receipts.
The frozen-input inventory hashes the source operands required for
the replays.
