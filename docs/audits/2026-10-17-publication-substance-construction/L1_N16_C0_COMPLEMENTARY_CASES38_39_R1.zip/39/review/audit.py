from ast import literal_eval
from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads
from zipfile import ZipFile

from binding import ROOT,TERMINAL_INPUTS,records
from exact_factors import DEN,groups,overlap,proj,read

selector=('R',0,0,2,0,1)

def state(name):
    raw=(ROOT/name).read_bytes()
    s=loads(raw)
    factors=s['factors']
    assert set(Counter(w for a,_,_ in factors for w in a).values())=={2}
    assert prod(d for _,_,d in factors)==DEN
    assert all(d>0 and len(a)==len(set(a)) and all(len(r)==len(a) and len(z)==2 and any(z) and all(type(k) is int for k in z) for r,z in rows.items()) for a,rows,d in factors)
    print('state',name,sha256(raw).hexdigest(),len(factors),sum(len(rows) for _,rows,_ in factors),flush=True)
    return s

def census(parent,raw,expected_size,axes):
    roster,rows=literal_eval(raw.decode())
    assert roster==axes
    la,ra=(parent['factors'][i] for i in parent['rejected_pair'])
    shared=overlap(la[0],ra[0])
    lookup=groups(ra,shared)
    matched,condition=proj(la[0],shared),proj(la[0],axes)
    counts=Counter()
    for row in la[1]:
        n=len(lookup.get(matched(row),()))
        if n:
            counts[condition(row)]+=n
    assert len(rows)==len(counts)==expected_size
    assert counts==dict(rows) and sum(counts.values())==parent['matched']
    print('PASS complete',expected_size,'coordinate roster SHA256',sha256(raw).hexdigest(),
          'pair',parent['rejected_pair'],'products',sum(counts.values()),min(counts.values()),max(counts.values()),flush=True)
    return sorted(counts,key=lambda x:(counts[x],x)),counts

def lift(parent,child,axes,coordinate):
    fixed=dict(zip(axes,coordinate,strict=True))
    assert child['conditioning']==parent['conditioning']+list(fixed.items())
    assert child['physical_cut']==parent['physical_cut']
    assert child['label_partition']==parent['label_partition']
    for (w,r,d),(q,small,e) in zip(parent['factors'],child['factors'],strict=True):
        assert d==e and q==tuple(k for k in w if k not in fixed)
        expected={row:z for row,z in r.items() if all(row[j]==fixed[k] for j,k in enumerate(w) if k in fixed)}
        recovered={}
        for row,z in small.items():
            assignment=dict(zip(q,row,strict=True))|fixed
            recovered[tuple(assignment[k] for k in w)]=z
        assert recovered==expected
    print('PASS exact inverse lift',coordinate,flush=True)

parent=read('separator.zip','row-cap-physical-slice-dense-label-tuple0-1-reduced.pkl')
assert parent['conditioning'][-1]==(selector,1)
with ZipFile('separator.zip') as archive:
    assert archive.read('pilot.roster')==(ROOT/'input.roster').read_bytes()
outer_axes=(('G',0,4,2),('J',1,4,2))
outer,counts=census(parent,(ROOT/'input.roster').read_bytes(),48,outer_axes)
assert outer[39]==(136,(2,)) and counts[outer[39]]==177240
cut=state('input.pkl')
lift(parent,cut,outer_axes,outer[39])
inner=state('row-cap-physical-slice-dense-label-rescue-reduced.pkl')
assert inner['conditioning']==cut['conditioning'] and len(inner['factors'])==7
axes=(('G',0,1,2),)
raw=(ROOT/'slice-0.roster').read_bytes()
assert all((ROOT/f'slice-{i}.roster').read_bytes()==raw for i in range(9))
order,counts=census(inner,raw,9,axes)
for i,(index,coord,matches,_,_,receipt) in enumerate(records):
    assert i==int(index) and order[i]==(int(coord),) and counts[order[i]]==int(matches)
    sliced=state(f'slice-{i}.pkl')
    lift(inner,sliced,axes,order[i])
    terminal=state(TERMINAL_INPUTS[i])
    assert terminal['conditioning']==sliced['conditioning']
    assert terminal['label_partition']==sliced['label_partition']
    assert terminal['physical_cut']==sliced['physical_cut']
    assert all(k not in dict(sliced['conditioning']) for a,_,_ in terminal['factors'] for k in a)
    print('PASS terminal binding',i,coord,TERMINAL_INPUTS[i],receipt,flush=True)
print('PASS all 48/9 source roster, all ten inverse lifts and nine terminal conditioning bindings',flush=True)
