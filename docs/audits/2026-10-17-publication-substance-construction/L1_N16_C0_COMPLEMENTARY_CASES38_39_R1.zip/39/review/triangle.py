from collections import Counter, defaultdict
from fractions import Fraction
from math import prod
from pathlib import Path
import hashlib
import pickle
import re
import time
import sys
from binding import ROOT,TERMINAL_INPUTS

root=ROOT
case=int(sys.argv[1])
started=time.monotonic()
input_bytes=(root/TERMINAL_INPUTS[case]).read_bytes()
checkpoint=pickle.loads(input_bytes)
factors=checkpoint['factors']
assert len(factors)==3
assert all(len(axes)==len(set(axes)) and rows and scale>0 for axes,rows,scale in factors)
assert all(count==2 and axis[0]!='L' for axis,count in Counter(w for a,_,_ in factors for w in a).items())
fixed=dict(checkpoint['conditioning'])
assert (fixed['G',0,4,2],fixed['J',1,4,2],fixed['G',0,1,2])==(136,(2,),{2:5,3:12}[case])
assert fixed['R',0,0,2,0,1]==1
denominator=prod(d for _,_,d in factors)
assert denominator==40512224221827380280140849737629696
def indices(a, b):
    axes=factors[a][0]
    return tuple(axes.index(w) for w in sorted(set(axes)&set(factors[b][0])))
def key(row, positions):
    return tuple(row[p] for p in positions)
def adjacency(a,pivot,other):
    front,back=indices(a,pivot),indices(a,other)
    rows=defaultdict(dict)
    assert len(front)+len(back)==len(factors[a][0])
    for row,value in factors[a][1].items():
        outside,inside=key(row,front),key(row,back)
        assert inside not in rows[outside]
        rows[outside][inside]=value
    return rows
def mul(a,b):
    x,y=a
    u,v=b
    return x*u-y*v,x*v+y*u
choices=[]
for pivot,a,b in ((1,0,2),(2,0,1)):
    left,right=adjacency(a,pivot,b),adjacency(b,pivot,a)
    left_key,right_key=indices(pivot,a),indices(pivot,b)
    forecast=sum(min(len(left.get(key(row,left_key),())),len(right.get(key(row,right_key),())))
                 for row in factors[pivot][1])
    choices.append((forecast,pivot,a,b))
    print('pivot forecast',pivot,forecast,flush=True)
forecast,pivot,a,b=min(choices)
assert forecast>=0
left,right=adjacency(a,pivot,b),adjacency(b,pivot,a)
lk,rk=indices(pivot,a),indices(pivot,b)
assert len(lk)+len(rk)==len(factors[pivot][0])
matched=products=nonzero=probes=real=imaginary=0
shard_probes=shard_products=peak_probes=peak_products=0
shard_started=time.monotonic()
for row,coefficient in factors[pivot][1].items():
    u=left.get(key(row,lk),{})
    v=right.get(key(row,rk),{})
    count=min(len(u),len(v))
    if shard_probes+count>2_000_000:
        peak_probes=max(peak_probes,shard_probes)
        peak_products=max(peak_products,shard_products)
        print('closed pivot shard',shard_probes,shard_products,flush=True)
        shard_probes=shard_products=0
        shard_started=time.monotonic()
    assert count<=2_000_000
    shard_probes+=count
    probes+=count
    subtotal_real=subtotal_imaginary=0
    for common in u.keys()&v.keys():
        rr,ii=mul(u[common],v[common])
        subtotal_real+=rr
        subtotal_imaginary+=ii
        matched+=1
        products+=1
        shard_products+=1
        assert shard_products<=30_000_000
    if subtotal_real or subtotal_imaginary:
        rr,ii=mul(coefficient,(subtotal_real,subtotal_imaginary))
        real+=rr
        imaginary+=ii
        nonzero+=1
        products+=1
        shard_products+=1
    assert shard_probes<=30_000_000 and shard_products<=30_000_000 and time.monotonic()-shard_started<60
peak_probes=max(peak_probes,shard_probes)
peak_products=max(peak_products,shard_products)
print("closed final pivot shard",shard_probes,shard_products,"peak",peak_probes,peak_products)
assert probes==forecast
scale=denominator*16*4**64
answer=Fraction(real,scale),Fraction(imaginary,scale)
text=(root/f'slice-{case}-shard-sum.out').read_text()
raw=re.search(r' raw (-?\d+) (-?\d+) factor denominator (\d+)',text,re.M)
assert raw and tuple(map(int,raw.groups()))==(real,imaginary,denominator)
terminal=re.search(r'^exact normalized real (\S+) imaginary (\S+)$',text,re.M)
assert terminal and tuple(map(Fraction,terminal.groups()))==answer
print('input SHA256',hashlib.sha256(input_bytes).hexdigest())
print('independent pivot',pivot,'probes',probes,'triples',matched,'nonzero pivot rows',nonzero,'Gaussian products',products,'wall seconds',round(time.monotonic()-started,3))
print('raw scalar numerator',real,'imaginary',imaginary,'factor denominator',denominator)
print('exact normalized real',answer[0],'imaginary',answer[1])
