# Complementary tuple 0 outer case 39 independent exact review

The nine separate exact terminal replays sum to **-309249011481254844095997 / 2596148429267413814265248164610048 + 0i**. This is outer case 39 of the selector-1 child of tuple 0 in dense group 128 descendant (0, 0). It matches the same coordinate's accepted selector-0 scalar and derives from its own distinct parent and exact inputs.

At publication checkpoint f7ddcfd874f6f329fa10537ee38bb2bf2269834b, the original separator pins the eight-factor tuple0-1 parent to uncompressed SHA256 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d. Independent projected matching reproduces the full original 48-case roster and 6,427,904 pair matches. Case 39 is coordinate (136, (2,)), with 177,240 matches and 428,682 stored rows. An exact inverse lift recovers its restricted parent rows, axes, signed coefficients and denominators.

Both outer row caps are rebuilt from the pinned parent and produce the exact seven-factor inner restart with SHA256 78ce57598af6cd8fc30a278f7bb3e4e706086f2eabdeb02469dc641b446a9bf5. The independent inner census on G(0,1,2) gives all nine supported coordinates with 2,001,024 products total, minimum 44,928 and maximum 435,456. Each conditioned child's inverse lift exactly recovers its source factor slices. The independent source and inverse-lift audit took 14.56 seconds. Clean execution of frozen author programs reproduces the cap/checkpoint bytes, reductions and terminal author receipts separately from the independent mathematical replays. All 19 cap snapshots verify, comprising 13 join refusals and six row refusals. The byte-for-byte lineage run took 190.34 seconds.

| Slice | Coordinate | Products in the inner census | Exact normalized real |
| --- | --- | --- | --- |
| 0 | 3 | 44928 | -11110915873446200016345/2596148429267413814265248164610048 |
| 1 | 48 | 62208 | -2011362180249495969/10141204801825835211973625643008 |
| 2 | 5 | 169344 | -3451458467456410661775/162259276829213363391578010288128 |
| 3 | 12 | 169344 | -33843346116668590909995/649037107316853453566312041152512 |
| 4 | 96 | 217728 | -4663776247126866816363/324518553658426726783156020576256 |
| 5 | 144 | 217728 | -4663776247126866816363/324518553658426726783156020576256 |
| 6 | 192 | 248832 | 6720855919829297127/5070602400912917605986812821504 |
| 7 | 80 | 435456 | -4480890652576321243803/649037107316853453566312041152512 |
| 8 | 160 | 435456 | -4480890652576321243803/649037107316853453566312041152512 |

All imaginary values are exactly zero. Slices 0, 1, 4, 5 and 6 use independent Gaussian-integer sparse joins. Slices 2 and 3 use alternate triangle pivot 1 in place of author pivot 0. Slices 7 and 8 use selected pair (1, 2) in place of author pair (1, 3), group exact products by the outgoing boundary, then compute the complementary closure. Each replay starts from its own frozen terminal input. Plain sparse schedules use 636,048 to 6,528,768 Gaussian products. Each triangle uses 18,643,968 supported triples and 18,752,832 Gaussian products, with 12.84 and 12.53 seconds inside those replays. Each four-factor replay visits 7,892,640 selected-pair matches and 15,536,640 complementary closure probes, using 23,812,992 Gaussian products in 15 bounded shards. Their internal elapsed times are 17.25 and 16.74 seconds. timings.tsv preserves per-slice work, output peaks and both internal and process elapsed times.

Independent projection histograms validate all 32 sorted pivot intervals across the four author shard stacks. They reproduce the exact probe or pair-match count per interval, and each shard stack's exact raw and normalized sum agrees with the independent signed replay. The independent shard census took 1.70 seconds.

Every replay preserves the exact raw scalar and combines the factor-denominator product 40512224221827380280140849737629696 with the positive external scale 1/(16*4^64) once. The committed selector-0 ledger confirms the matching value after the selector-1 computation. The final comparison uses the independently contracted selector-1 scalar and verifies that the two original parents are distinct.

## Reproduction

Retain inputs/, scripts/ and replays/ as relative directories. The separator.zip and first-child.zip archives can be restored from the pinned Git objects. The generated lineage directory can be recreated from the frozen inputs. Run the checks in a fresh copy, with no generated lineage/ directory.

```sh
sh verify-source-pins.sh
shasum -a 256 -c frozen-inputs.sha256
shasum -a 256 -c source-archives.sha256
python3 audit.py > audit.out
python3 verify-lineage.py outer 0 1 2 3 4 5 6 7 8 > verify-lineage.out
python3 replay-all.py > replay-all.out
python3 verify-shards.py > verify-shards.out
python3 timings.py > timings.tsv
python3 verify-cap-list.py > cap-list.out
python3 aggregate.py > aggregate.out
python3 compare-first.py > compare-first.out
```
