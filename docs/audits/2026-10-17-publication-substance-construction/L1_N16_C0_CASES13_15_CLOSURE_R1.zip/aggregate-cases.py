from fractions import Fraction
from pathlib import Path
import re

root = Path(__file__).resolve().parent
normalized=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
raw=re.compile(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',re.M)
total_real=total_imaginary=Fraction()
for case, author, reviewer in (
    (13,'author','independent'), (14,'case14-author','case14-independent'),
    (15,'case15-author','case15-independent'),
):
    author=root/author
    reviewer=root/reviewer
    lines=[line.split('\t') for line in (author/f'author-case{case}.tsv').read_text().splitlines()]
    assert len(lines)==10 and [int(line[0]) for line in lines[:-1]]==list(range(9))
    sx=sy=Fraction()
    for index,coord,matches,x,y,author_log in lines[:-1]:
        suffix = ('terminal-replay' if case==14 else
                  'capture-replay' if index in ('4','5') else 'replay')
        log=(reviewer/f'slice-{index}-{suffix}.out').read_text()
        observed=tuple(map(Fraction,normalized.search(log).groups()))
        nx,ny,d=map(int,raw.search(log).groups())
        scale=d*16*4**64
        assert observed==(Fraction(nx,scale),Fraction(ny,scale))==(Fraction(x),Fraction(y))
        assert observed==tuple(map(Fraction,normalized.search((author/author_log).read_text()).groups()))
        sx+=observed[0]
        sy+=observed[1]
    assert lines[-1]==['sum',str(sx),str(sy)]
    total_real+=sx
    total_imaginary+=sy
    print(case,sx,sy,sep='\t')
print('subtotal',total_real,total_imaginary,sep='\t')
