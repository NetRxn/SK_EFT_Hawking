# Independent verification of L1 N16 outer case 14

The verified seven-factor parent is bound by the input hash in
L1_N16_C0_CASES4_11_CLOSURE_R1.zip at publication checkpoint 0294108b4.
The archive manifest passes. The parent SHA256 is
47ab3fc344295e647d600bb8590d3134c99eb6c9a57fc6596b1b82def35a11e5.
The archived outer roster binds case 14 to (40, (1,)) on
G(0,4,2) and J(1,4,2). This is in the first binary child of tuple 0,
descendant (0,0), branch 128.

An independent histogram match on the rejected parent pair (0, 4)
regenerated the complete nine-value G(0,1,2) cut. Its 1,021,248 pair
products range from 13,824 to 225,504 per value. A nonzero full
network term must appear in that pair match. The nine values are
disjoint and cover that support. An exact inverse lift for each value
recovered all compatible parent rows, Gaussian coefficients and factor
denominators. The terminal inputs preserve the complete conditioning and
representation-label partition, all open axes have degree two, and the
factor denominator product is 40512224221827380280140849737629696.

| Slice | G(0,1,2) value | Matched products in rejected parent pair | Independent terminal products | Exact normalized real |
|---|---:|---:|---:|---:|
| 0 | 3 | 13,824 | 90,864 | -11685140226577673415/1298074214633706907132624082305024 |
| 1 | 192 | 23,328 | 1,189,248 | 960746576681676897/81129638414606681695789005144064 |
| 2 | 5 | 60,480 | 643,104 | -1235404845747698074155/5192296858534827628530496329220096 |
| 3 | 12 | 91,584 | 272,592 | -2028411939483503527275/2596148429267413814265248164610048 |
| 4 | 96 | 112,752 | 874,608 | -11051962176191080095/1298074214633706907132624082305024 |
| 5 | 144 | 112,752 | 874,608 | -11051962176191080095/1298074214633706907132624082305024 |
| 6 | 48 | 155,520 | 363,456 | 1417258427640987305745/649037107316853453566312041152512 |
| 7 | 80 | 225,504 | 9,058,092 | 706946219039124820413/1298074214633706907132624082305024 |
| 8 | 160 | 225,504 | 9,058,092 | 706946219039124820413/1298074214633706907132624082305024 |

The terminal independent arithmetic imports no author functions, uses
exact Gaussian-integer sparse products and applies 1/(16*4^64) once.
It agrees with each author receipt and the author TSV. The imaginary
parts are all zero. The independently accumulated case sum is
**11627739971317979867547/5192296858534827628530496329220096 + 0i**.
The audit records the input and hashes independently for each cut,
including those with the same scalar.

For slices 4 and 5 the greedy direct replay initially refused a join
forecast of 29,708,160 after 8,730,328 products. The retained failure
logs describe that schedule. Two bounded independent routes subsequently
succeeded. One starts from each captured three-factor post-quotient state.
The other starts from the full seven-factor reduced input, uses support
intersection on shared axes before each join, and matches 8,352,280
products, with a largest join of 4,817,664 for each slice. Support
intersection discards a row only if its shared-axis assignment occurs in
no row of a factor that must agree with it. This direct replay performs no
proportional quotient.

The unchanged author scripts in clean scratch reproduced the cut, reduction,
cap-saved restart inputs and direct or rescue receipts byte for byte.
The slice 4 and 5 captures also reproduced the saved state and original
terminal log byte for byte. This checks author transformation lineage
from the pinned parent and retains each earlier cap refusal. The exact
independent multiplication checks the final contractions separately.
The completed sum covers outer case 14. The other contributions to the
48-case child, tuple, branch, profile and signed c0 remain separate.
