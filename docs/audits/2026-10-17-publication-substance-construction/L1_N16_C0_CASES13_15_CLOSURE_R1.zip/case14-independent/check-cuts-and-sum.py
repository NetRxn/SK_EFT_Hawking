from ast import literal_eval
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

author = Path('/private/tmp/l1-c0-case14.PA1alo')
source = Path('/private/tmp/l1-open-roster-next.56OPQR/row-cap-physical-slice-dense-label-case-14-2-reduced.pkl')

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def load(path):
    return pickle.loads(path.read_bytes())

for line in Path('archive-binding.out').read_text().splitlines():
    expected, name = line.split()
    local = {'next-frontiers/input-hashes.sha256':'prior-input-hashes.sha256',
             'next-frontiers/case-14.roster':'outer.roster'}[name]
    assert digest(Path(local)) == expected
expected, name = Path('parent-digest.out').read_text().split()
assert name == source.name and digest(source) == expected
parent = load(source)
factors = parent['factors']
assert len(factors) == 7
degree = Counter(axis for scope, _, _ in factors for axis in scope)
assert set(degree.values()) == {2}
axes_outer, outer_roster = literal_eval(Path('outer.roster').read_text())
assert len(outer_roster) == len(dict(outer_roster)) == 48
coord_outer = sorted(outer_roster,key=lambda x:(x[1],x[0]))[14][0]
assert tuple(dict(parent['conditioning'])[a] for a in axes_outer) == coord_outer
axes, entries = literal_eval((author/'slice-0.roster').read_text())
assert axes == (('G',0,1,2),)
assert len(entries) == len(dict(entries)) == 9
i, j = parent['rejected_pair']
left, right = factors[i], factors[j]
shared = sorted(set(left[0]) & set(right[0]))
assert degree[axes[0]] == 2 and axes[0] in left[0] and axes[0] not in shared
right_positions = [right[0].index(a) for a in shared]
right_summary = Counter(tuple(row[p] for p in right_positions) for row in right[1])
left_positions = [left[0].index(a) for a in shared]
cut_positions = [left[0].index(a) for a in axes]
spectrum = Counter()
for row in left[1]:
    multiplicity = right_summary[tuple(row[p] for p in left_positions)]
    if multiplicity:
        spectrum[tuple(row[p] for p in cut_positions)] += multiplicity
assert spectrum == dict(entries)
ordered = sorted(spectrum, key=lambda c:(spectrum[c],c))
print('parent',source.name,expected,'outer cut',axes_outer,coord_outer)
print('nine-cut census', 'pair', (i,j), 'cut', axes[0], 'count', len(spectrum), 'sum/min/max',sum(spectrum.values()),min(spectrum.values()),max(spectrum.values()))
author_lines = (author/'author-case14.tsv').read_text().splitlines()
assert len(author_lines) == 10
parts = []
for case, line in enumerate(author_lines[:-1]):
    index, value, count, expected_re, expected_im, receipt = line.split('\t')
    assert int(index) == case
    coord = ordered[case]
    assert coord == (int(value),) and spectrum[coord] == int(count)
    assert literal_eval((author/f'slice-{case}.roster').read_text()) == (axes,entries)
    fixed = dict(zip(axes,coord))
    child_path = author/f'slice-{case}.pkl'
    child = load(child_path)
    assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
    assert child['label_partition'] == parent['label_partition']
    for (scope, rows, denominator), (restricted_scope, restricted_rows, restricted_denominator) in zip(factors, child['factors'], strict=True):
        assert denominator == restricted_denominator
        assert tuple(a for a in scope if a not in fixed) == restricted_scope
        expected = {row: val for row, val in rows.items()
                    if all(row[p] == fixed[a] for p, a in enumerate(scope) if a in fixed)}
        actual = {}
        for row, val in restricted_rows.items():
            expanded = dict(zip(restricted_scope, row))
            expanded.update(fixed)
            actual[tuple(expanded[a] for a in scope)] = val
        assert actual == expected
    tag = receipt.removesuffix('-contract.out')
    final = author/(f'post-quotient-slice-{case}.pkl' if case in (4,5) else f'label-{tag}-reduced-frontier.pkl')
    final_state = load(final)
    assert final_state['conditioning'] == child['conditioning']
    assert final_state['label_partition'] == child['label_partition']
    ff = final_state['factors']
    assert prod(d for _,_,d in ff) == 40512224221827380280140849737629696
    assert all(len(set(a))==len(a) and d>0 and all(len(k)==len(a) and len(v)==2 and any(v) and all(type(z) is int for z in v) for k,v in table.items()) for a,table,d in ff)
    assert set(Counter(w for a,_,_ in ff for w in a).values()) == {2}
    author_result = re.fullmatch(r'exact normalized real (\S+) imaginary (\S+) peak rows \d+ matched products \d+', (author/receipt).read_text().splitlines()[-1])
    text = Path(f'slice-{case}-terminal-replay.out').read_text()
    assert 'PASS raw scalar numerator' in text
    result = re.search(r'^exact normalized real (\S+) imaginary (\S+) independent matched products (\d+) wall seconds \S+$', text, re.M)
    assert re.search(r'^conditioning '+re.escape(str(child['conditioning']))+' label partition '+re.escape(str(child['label_partition']))+r'$',text,re.M)
    assert result.groups()[:2] == author_result.groups() == (expected_re,expected_im)
    parts.append(tuple(map(Fraction, result.groups()[:2])))
    print('PASS slice',case,value,count,'child sha',digest(child_path),'terminal',final.name,'sha',digest(final), 'factors/rows',len(ff),sum(len(r) for _,r,_ in ff),'products',result[3],'exact',result[1],result[2])
author_sum = author_lines[-1].split('\t')
assert author_sum[0]=='sum'
sum_re, sum_im = map(sum, zip(*parts, strict=True))
assert (sum_re,sum_im) == tuple(map(Fraction, author_sum[1:]))
print('PASS exact case 14 sum',sum_re,'imaginary',sum_im)
