from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

author = Path('/private/tmp/l1-c0-case14.PA1alo')
source = 'author-case14.tsv'
jobs = []
for line in (author/source).read_text().splitlines():
    if line.startswith('sum\t'):
        continue
    idx, axis, count, real, imaginary, receipt = line.split('\t')
    i = int(idx)
    tag = receipt.removesuffix('-contract.out')
    name = f'label-{tag}-reduced-frontier.pkl'
    if i in (4, 5):
        jobs.append((i, name, receipt, 'direct'))
        name = f'post-quotient-slice-{i}.pkl'
    jobs.append((i, name, receipt, 'terminal'))

def run(job):
    i, name, receipt, mode = job
    outpath = Path(f'slice-{i}-{mode}-replay.out')
    with outpath.open('xb') as out:
        p = subprocess.run([sys.executable,'-u','sparse-replay.py',str(i),mode,
                            str(author/name),str(author/receipt)],
                           stdout=out,stderr=subprocess.STDOUT,timeout=50)
    return i, mode, p.returncode

with ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(run,jobs):
        print(*result,sep='\t',flush=True)
