from pathlib import Path
from ast import literal_eval
from fractions import Fraction
import re

axes, roster = literal_eval(Path('slice-0.roster').read_text())
assert axes == (('G',0,1,2),)
ordered = sorted(roster,key=lambda item:(item[1],item[0]))
assert len(ordered) == len(dict(ordered)) == 9
assert sum(n for _,n in ordered)==1_021_248
real = imaginary = Fraction()
for i,(label,matches) in enumerate(ordered):
    assert literal_eval(Path(f'slice-{i}.roster').read_text()) == (axes,roster)
    assert Path(f'slice-{i}-plan.out').read_text().splitlines()[-1].startswith(
        f'pilot {label!r} matched {matches} stored rows ')
    candidates = [Path(f'slice-{i}-contract.out'), *sorted(Path('.').glob(f'rescue-{i}-*-contract.out'))]
    outputs = [(p,re.search(r'^exact normalized real (\S+) imaginary (\S+)',p.read_text(),re.M))
               for p in candidates]
    [(path,match)] = [(p,m) for p,m in outputs if m]
    re_i, im_i = map(Fraction,match.groups())
    real += re_i
    imaginary += im_i
    print(i,label[0],matches,re_i,im_i,path.name,sep='\t')
print('sum',real,imaginary,sep='\t')
