# L1 N16 group 128 exact cases 13 and 14

This is outer coordinate (33,(2,)) in the first binary child of tuple 0, descendant (0,0), scientific source 51e7c745e. Publication parent 0294108b4. Restore the seven-factor parent `row-cap-physical-slice-dense-label-case-13-2-reduced.pkl` from the instructions and saved lineage in `L1_N16_C0_CASES4_11_CLOSURE_R1.zip`. Its SHA256 is 199cb334fcbe81fd71a366521c086fd3733aee762cdfd1926e05a1b63b34fd82. Deserialize only trusted checkpoint inputs.

Copy the author Python files and checkpoint directory into fresh scratch. Run:

```bash
python3 -u run-primary.py /absolute/path/to/row-cap-physical-slice-dense-label-case-13-2-reduced.pkl >slices.tsv
python3 -u reduce-open.py 0 2 3 6 7 8 >rescue.tsv
python3 -u capture-quotient.py slice-4
python3 -u capture-quotient.py slice-5
shasum -a 256 -c /absolute/path/to/archive/reconstructed-frontiers.sha256
python3 sum-case13.py
```

The cut partitions all 1,021,248 compatible pair matches over nine distinct values of G(0,1,2). Initial direct contraction closes slices 1, 4 and 5. The support and quotient reductions on changed frontiers close all six remaining slices without final row sharding. The author logs preserve every refusal and exact accepted stage. The complete exact sum is 8732401333944633881667/5192296858534827628530496329220096 with zero imaginary part. The aggregate of the full signed coefficient and the physical susceptibility remain open.

For case 14, the outer coordinate is (40,(1,)). Use `case14-author`, `sum-case14.py` and `case14-frontiers.sha256` in place of the case 13 counterparts. The parent is `row-cap-physical-slice-dense-label-case-14-2-reduced.pkl`, SHA256 47ab3fc344295e647d600bb8590d3134c99eb6c9a57fc6596b1b82def35a11e5. The same nine-slice reduction sequence applies. The case 14 exact subtotal is 11627739971317979867547/5192296858534827628530496329220096 with zero imaginary part.

The independent archives preserve the original reviewer paths. The case 13 reviewer names the Git archive `L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip` as `original.zip` and `L1_N16_C0_CASES4_11_CLOSURE_R1.zip` as `pinned.zip`; the reviewed bytes are stored once upstream. The capture scripts add serialization after the final quotient for slices 4 and 5. They reproduce the original author terminal logs byte for byte and give the reviewers separate reduced inputs after the earlier sparse replays refused their guards. Run `python3 independent/aggregate-archive.py` from the extracted archive to repeat the case 13 retally using only the included receipts. The independent reports provide the full arithmetic replay bindings.

Case 15 follows the case 13 procedure with `case15-author`, `sum-case15.py` and `case15-frontiers.sha256`. Use parent `row-cap-physical-slice-dense-label-case-15-2-reduced.pkl` with SHA256 06388c2b99f8d844ffefe87673396106e145448f9b8699c27fd0da76a854e013. Its coordinate is (40,(2,)). The exact case subtotal is 11776062496625468983377/5192296858534827628530496329220096 with zero imaginary part. Keep the exact input identity separate for each case. Run `python3 aggregate-cases.py` to check the 27 retained independent raw replays and their author receipts and reproduce the three-case subtotal. Case 14 additionally has a bounded support-only replay from both seven-factor states for slices 4 and 5 and a byte-identical complete lineage replay. For the independent manifests, restore any named ZIP by copying the identical pinned upstream archive under the reviewer basename.
