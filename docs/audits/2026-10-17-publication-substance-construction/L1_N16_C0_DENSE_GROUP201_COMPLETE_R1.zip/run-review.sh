#!/bin/bash
set -eu
a=/private/tmp/l1-geometry-component3-preparation.HJyusc/201/cached-original-roster
for label in 0 2 4 5 6 7; do
    d="author/L$label"
    until test -s "$a/solve-L$label.time" && test -s "$d/native-replay.out" &&
        tail -1 "$d/native-replay.out" | grep -q 'native source and cap independent seconds'; do
        sleep 3
    done
    read -r stage n < <(awk '/^preserved checkpoint pass[0-9]+-result.pkl/ { name=$3; gsub(/[^0-9]/,"",name); print name, $5 }' "$a/L$label"/pass*.out | tail -1)
    if [[ "$n" = 1 ]]; then
        /bin/bash run-continuation.sh "$label" "$stage"
    elif [[ "$n" = 3 ]]; then
        /bin/bash run-continuation.sh "$label" "$stage" triangle
        /usr/bin/time -p python3 -B -u triangle_replay.py "$label" > "$d/extra-replay.out" 2> "$d/extra-replay.time"
        until test -s "$a/L$label/terminal.time"; do sleep 3; done
        cp "$a/L$label/terminal.out" "$a/L$label/terminal.time" "$d/"
        python3 -B -u audit_triangle.py "$label" > "$d/triangle-audit.out"
    else
        printf 'L%s unknown terminal topology %s\n' "$label" "$n"
        exit 2
    fi
    tail -1 "$d/replay.out"
done
