"""Recount each original ordinal directly in the signed prepared factor tables."""
from ast import literal_eval
from collections import Counter
from csv import DictReader
from hashlib import file_digest
from math import prod
from pathlib import Path
from pickle import load

def main():
    root=Path('/private/tmp/l1-geometry-component3-preparation.HJyusc/201')
    prefix=Path('source-receipts')
    pin=(prefix/'frontier.sha256').read_text().split()[0]
    names=sorted(line.split('\t',1)[0] for line in (root/'schema.tsv').read_text().splitlines())
    with (root/'dense-saturated-frontier.pkl').open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==pin
        stream.seek(0)
        state=load(stream)
    assert (state['branch'],state['support'])==(201,8)
    factors=state['factors']
    assert len(factors)==len(names)==88
    denominator=prod(d for _,_,d in factors)
    assert denominator==889157184566856082966054315229184
    axis,roster=literal_eval(Path('original-roster.txt').read_text())
    assert len(axis)==12 and len(set(roster))==8
    projections=[]
    for name,(space,rows,_) in zip(names,factors,strict=True):
        fixed=[(i,axis.index(w)) for i,w in enumerate(space) if w in axis]
        projections.append((name,tuple(j for _,j in fixed),
                            Counter(tuple(row[i] for i,_ in fixed) for row in rows)))
    zeros=[]
    print('ordinal','original_tuple','total_selected_rows','largest_factor','empty_factors','denominator',sep='\t')
    with Path('zero-roster.tsv').open() as f:
        for ordinal,(key,receipt) in enumerate(zip(roster,DictReader(f,delimiter='\t'),strict=True)):
            counts=[(name,table[tuple(key[j] for j in fixed)]) for name,fixed,table in projections]
            empty=[name for name,n in counts if not n]
            total=sum(n for _,n in counts)
            maximum=max(n for _,n in counts)
            assert int(receipt['original_ordinal'])==ordinal
            assert literal_eval(receipt['original_joint_L_tuple'])==key
            assert int(receipt['prepared_selected_rows'])==total
            assert int(receipt['largest_prepared_factor'])==maximum
            assert literal_eval(receipt['empty_prepared_factors'])==empty
            assert (receipt['disposition']=='exact_zero')==bool(empty)
            if empty: zeros.append(ordinal)
            print(ordinal,repr(key),total,maximum,repr(empty),denominator,sep='\t')
    assert zeros==[1,3]
    
if __name__=='__main__':
    main()
