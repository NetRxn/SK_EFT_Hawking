#!/bin/bash
set -eu
label="$1"
stage="$2"
a="/private/tmp/l1-geometry-component3-preparation.HJyusc/201/cached-original-roster/L${label}"
d="author/L${label}"
if [ "$#" = 3 ]; then python3 -B configure.py "$label" "$stage" "$3"; else python3 -B configure.py "$label" "$stage"; fi
review="$PWD"
(
    cd "$a"
    shasum -a 256 ../../dense-saturated-frontier.pkl ./*.pkl
    cp ./*.py ./*.out contraction.err contraction.receipt joint-label-roster.tsv "$review/$d/"
) > "$d/complete-operands.sha256"
cp "$a/../solve-L${label}.out" "$d/solve.out"
cp "$a/../solve-L${label}.time" "$d/solve.time"
(cd "$a" && shasum -a 256 -c "$review/$d/complete-operands.sha256") > "$d/operands-verify.out"
/usr/bin/time -p python3 -B -u verify.py "$label" > "$d/replay.out" 2> "$d/replay.time"
