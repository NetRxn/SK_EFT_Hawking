from ast import literal_eval
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

root=Path(__file__).resolve().parent
source=root/'archive'
author=Path('/private/tmp/l1-c0-sibling-cases12-17.BlthJ1/tuple0-1/14')
selector=('R',0,0,2,0,1)
denominator=40512224221827380280140849737629696
pins={name:digest for digest,name in (line.split() for line in (source/'frontiers-uncompressed.sha256').read_text().splitlines())}
def load_parent(i):
    name=f'row-cap-physical-slice-dense-label-tuple0-{i}-reduced.pkl'
    raw=decompress((source/f'{name}.gz').read_bytes())
    assert sha256(raw).hexdigest()==pins[name]
    if i==1:
        assert raw==(root/'parent.pkl').read_bytes()
        assert pins[name]=='9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d'
    return pickle.loads(raw)

first,complement=map(load_parent,(0,1))
assert first['conditioning'][:-1]==complement['conditioning'][:-1]
assert first['conditioning'][-1]==(selector,0) and complement['conditioning'][-1]==(selector,1)
assert first['factors']!=complement['factors']
def census(state,roster):
    axes,entries=literal_eval(roster.read_text())
    assert len(entries)==len(dict(entries))
    f=state['factors']
    assert set(Counter(w for scope,_,_ in f for w in scope).values())=={2}
    left,right=[f[i] for i in state['rejected_pair']]
    shared=sorted(set(left[0])&set(right[0]))
    lmatch=tuple(left[0].index(k) for k in shared)
    rmatch=tuple(right[0].index(k) for k in shared)
    lcut=tuple(left[0].index(k) for k in axes)
    left_count=Counter((tuple(row[p] for p in lmatch),tuple(row[p] for p in lcut)) for row in left[1])
    right_count=Counter(tuple(row[p] for p in rmatch) for row in right[1])
    weights=Counter()
    for (key,cut),n in left_count.items():
        if count:=n*right_count[key]:
            weights[cut]+=count
    assert weights==dict(entries) and sum(weights.values())==state['matched']
    return axes,weights,sorted(weights,key=lambda k:(weights[k],k))

def inverse_lift(state,axes,coordinate,path):
    fixed=dict(zip(axes,coordinate,strict=True))
    raw=path.read_bytes()
    child=pickle.loads(raw)
    assert child['conditioning']==state['conditioning']+list(fixed.items())
    assert child['label_partition']==state['label_partition']
    for (scope,rows,d),(small,cut_rows,e) in zip(state['factors'],child['factors'],strict=True):
        assert d==e and small==tuple(k for k in scope if k not in fixed)
        expected_rows={row:value for row,value in rows.items() if all(row[p]==fixed[k] for p,k in enumerate(scope) if k in fixed)}
        recovered={}
        for row,value in cut_rows.items():
            assignment=dict(zip(small,row,strict=True))
            assignment.update(fixed)
            recovered[tuple(assignment[k] for k in scope)]=value
        assert recovered==expected_rows
    print('PASS exact inverse lift',coordinate,sha256(raw).hexdigest(),sum(len(rows) for _,rows,_ in child['factors']))
    return child

def check_stage(path, child, length=None):
    raw=path.read_bytes()
    state=pickle.loads(raw)
    assert state['conditioning']==child['conditioning'] and state['label_partition']==child['label_partition']
    ff=state['factors']
    if length is not None:
        assert len(ff)==length
    assert set(Counter(w for scope,_,_ in ff for w in scope).values())=={2}
    assert all(d>0 and len(set(scope))==len(scope) and all(len(row)==len(scope) and len(value)==2 and any(value) and all(type(x) is int for x in value) for row,value in rows.items()) for scope,rows,d in ff)
    assert prod(d for _,_,d in ff)==denominator
    print('PASS stage',path.name,sha256(raw).hexdigest(),len(ff),sum(len(rows) for _,rows,_ in ff))
    return state

assert (source/'pilot.roster').read_bytes()==(author/'input.roster').read_bytes()
axes,weights,order=census(complement,source/'pilot.roster')
assert len(order)==48 and sum(weights.values())==6427904
assert order[14]==(40,(1,)) and weights[order[14]]==106344
print('PASS original complementary 48-coordinate roster',axes,order[14],weights[order[14]])
cut=inverse_lift(complement,axes,order[14],author/'input.pkl')
for file in ('label-primary-reduced-frontier.pkl','row-cap-physical-slice-dense-label-primary-reduced.pkl',
             'label-rescue-reduced-frontier.pkl'):
    check_stage(author/file,cut)
inner=check_stage(author/'row-cap-physical-slice-dense-label-rescue-reduced.pkl',cut,7)
axes,weights,order=census(inner,author/'slice-0.roster')
assert axes==(('G',0,1,2),) and len(order)==9 and sum(weights.values())==1021248
print('PASS exhaustive nine-coordinate inner roster',axes,sum(weights.values()),min(weights.values()),max(weights.values()))
ledger=(author/'author-case14.tsv').read_text().splitlines()
assert len(ledger)==10
values=[]
signature=r'^exact normalized real (\S+) imaginary (\S+)(?: |$)'
for i,row in enumerate(ledger[:-1]):
    n,coord,count,real,imag,receipt=row.split('\t')
    assert int(n)==i and order[i]==(int(coord),) and weights[order[i]]==int(count)
    assert (author/f'slice-{i}.roster').read_bytes()==(author/'slice-0.roster').read_bytes()
    sub=inverse_lift(inner,axes,order[i],author/f'slice-{i}.pkl')
    tag=receipt.removesuffix('-contract.out')
    for p in sorted(author.glob(f'label-rescue-{i}-*-reduced-frontier.pkl')):
        check_stage(p,sub)
    for p in sorted(author.glob(f'*-dense-label-rescue-{i}-*-reduced.pkl')):
        check_stage(p,sub)
    check_stage(author/f'label-slice-{i}-reduced-frontier.pkl',sub)
    for p in sorted(author.glob(f'*-dense-label-slice-{i}-reduced.pkl')):
        check_stage(p,sub)
    terminal=author/f'label-{tag}-reduced-frontier.pkl'
    state=check_stage(terminal,sub)
    replay=(root/f'slice-{i}-terminal-replay.out').read_text()
    assert f"conditioning {sub['conditioning']} label partition {sub['label_partition']}" in replay
    exact=tuple(map(Fraction,re.search(signature,replay,re.M).groups()))
    assert exact==tuple(map(Fraction,re.search(signature,(author/receipt).read_text(),re.M).groups()))==tuple(map(Fraction,(real,imag)))
    r,j,d=map(int,re.search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',replay,re.M).groups())
    assert d==denominator and tuple(Fraction(value,d*16*4**64) for value in (r,j))==exact
    values.append(exact)
    print('PASS independent complementary case 14 slice',i,order[i],count,'exact normalized',*exact)
label,*expected=ledger[-1].split('\t')
total=tuple(sum(column,Fraction(0)) for column in zip(*values,strict=True))
assert label=='sum' and total==tuple(map(Fraction,expected))
print('PASS exact complementary case 14 sum',*total)
