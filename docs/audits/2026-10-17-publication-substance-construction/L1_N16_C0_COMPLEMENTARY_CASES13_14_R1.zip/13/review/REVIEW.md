# Independent verification of complementary tuple 0 outer case 13

The exact normalized sum is
**8732401333944633881667/5192296858534827628530496329220096 + 0i**.

The original separator archive was read from publication checkpoint
d10807a717f151e578dd0553f49a4aa3dce5d5ec and matches the worktree bytes.
Its manifest verified. The decompressed complementary parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d
and its selector R(0,0,2,0,1) is 1. Its own rejected-pair histogram
regenerates the full original 48-coordinate roster over 6,427,904
matches and binds outer case 13 to (33, (2,)), with 106,344 products.
The inverse lift recovers 425,622 compatible parent rows and their exact
Gaussian coefficients and denominators. First-child case 17 has the same
scalar at (65, (2,)) under selector 0. Its arithmetic is separate.

The two outer row-cap stages reproduce byte for byte from the pinned
parent and yield the seven-factor inner parent SHA256
b50f14d73a53cf076a652c9433a3b8c3375a3f77e306a2a7a0e1cebbc61c2531.
Independent histogram matching on its rejected pair regenerates the
exhaustive nine-coordinate census on G(0,1,2) over 1,021,248 products.
Every complete-network term must use one of those distinct matched
assignments. Exact inverse lifts recover each of the nine slice inputs.
Clean scratch execution reproduces all 17 inner author cycles including
the eight cap-saved inputs and the nine exact terminal receipts.
All saved states preserve the full conditioning, label partition and
positive denominator product.

| Slice | Inner coordinate | Matched parent pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 12 | 13,824 | -13032407422419487515/649037107316853453566312041152512 |
| 1 | 192 | 23,328 | 1669637420808380919/81129638414606681695789005144064 |
| 2 | 3 | 60,480 | -2598085356367818257325/2596148429267413814265248164610048 |
| 3 | 5 | 91,584 | -3978996321950902163835/5192296858534827628530496329220096 |
| 4 | 96 | 112,752 | -726531867151510973265/1298074214633706907132624082305024 |
| 5 | 144 | 112,752 | -726531867151510973265/1298074214633706907132624082305024 |
| 6 | 48 | 155,520 | 2214160403452587964269/649037107316853453566312041152512 |
| 7 | 80 | 225,504 | 375246408916886009589/649037107316853453566312041152512 |
| 8 | 160 | 225,504 | 375246408916886009589/649037107316853453566312041152512 |

All nine independent terminal replays use exact Gaussian integer
products. The full seven-factor inputs for slices 4 and 5 use a support-only
semijoin on shared axes followed by plain sparse products. That schedule
does not apply proportional quotients and uses 8,367,384 products per
slice, with largest join 4,817,664. All nine imaginary values are zero.
The arithmetic applies factor denominator product
40512224221827380280140849737629696 and external normalization
1/(16*4^64) once. Exact Fraction addition gives the reported sum.

The review manifest uses relative paths and includes verified copies of
the author receipts. The frozen inputs inventory records every author
checkpoint needed to repeat the verification.
