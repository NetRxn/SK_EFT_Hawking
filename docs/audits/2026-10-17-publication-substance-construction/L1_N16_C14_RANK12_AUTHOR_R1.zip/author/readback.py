"""Independently check the frozen factor projection, merge and adverse slots."""
from itertools import permutations, product
from collections import Counter, defaultdict
from pathlib import Path
import json

D=Path(__file__).parent
PREV=Path('/tmp/publication-c14-residual-edge-r1.klcKMh')
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')

def load(p):
    with p.open() as f:
        for row in f:
            yield json.loads(row)

def table(p):
    out={}
    for k,z in load(p):
        assert tuple(k) not in out
        out[tuple(k)]=tuple(z) if isinstance(z,list) else z
    return out

def times(x,y):
    a,b=x
    c,d=y
    return a*c-b*d,a*d+b*c

def add(x,y):
    return x[0]+y[0],x[1]+y[1]

def sign(w):
    return (-1)**sum(a>b for i,a in enumerate(w) for b in w[i+1:])

def bits(m):
    return [i for i in range(8) if m>>i&1]

zero=(0,0)
e2=table(D/'edge12-axis2.jsonl')
e3=table(D/'edge12-axis3.jsonl')
assert len(e2)==len(e3)==48
assert all(k[2]==k[3] for t in (e2,e3) for k in t)
compact={}
for (p,r,a,b),x in e2.items():
    for (q,s,d,e),y in e3.items():
        word=bits(p)+bits(q)
        if len(word)!=len(set(word)):
            continue
        remain=set(range(8))-set(word)
        m=sum(1<<i for i in remain)
        wedge=sign(sorted(remain)+word)
        for labels in permutations(range(4)):
            if labels[2:]!=(a,d):
                continue
            for labels1 in permutations(range(4)):
                if labels1[2:]!=(b,e):
                    continue
                k=(m,labels[0],labels1[0],labels[1],labels1[1],r,s)
                z=times(x,y)
                compact[k]=add(compact.get(k,zero),tuple(wedge*sign(labels)*sign(labels1)*v for v in z))
assert compact==table(D/'rank12-compact.jsonl')
a={}
for (m,n,fused),sg in load(PREV/'merge-rank12.jsonl'):
    assert sg==sign(bits(m)+bits(n))
    for k,z in compact.items():
        if k[0]!=fused:
            continue
        key=(m,n,*k[1:])
        assert key not in a
        a[key]=tuple(sg*v for v in z)
assert a==table(D/'rank12-closure.jsonl')
wrong=0
witness=None
for k,z in sorted(a.items()):
    m,n,a00,a01,a10,a11,r,s=k
    wrongz=a.get((m,n,a00,a01,a11,a10,r,s),zero)
    if z!=wrongz:
        wrong+=1
        if witness is None:
            witness=dict(key=k,correct=z,swapped_axis1_occurrence=wrongz)
assert wrong and witness is not None

old=defaultdict(dict)
res=defaultdict(dict)
for (m,n,c,d,q,s),z in load(STAR/'edge-1.jsonl'):
    old[m,q,s][n,c,d]=tuple(z)
for (m,n,c,d,q,s),z in load(PREV/'residual-edge.jsonl'):
    res[m,q,s][n,c,d]=tuple(z)
checks=[]
for ctl in json.loads((D/'result.json').read_text())['controls']:
    left=old[tuple(ctl['old_edge_boundary'])]
    right=res[tuple(ctl['residual_edge_boundary'])]
    r,s=ctl['remote_masks']
    z=wrongz=zero
    for ((m,c,d),x),((n,e,f),y) in product(left.items(),right.items()):
        q=times(x,y)
        z=add(z,times(q,a.get((m,n,e,f,c,d,r,s),zero)))
        wrongz=add(wrongz,times(q,a.get((m,n,e,f,d,c,r,s),zero)))
    assert list(z)==ctl['signed_numerator']
    checks.append(dict(numerator=z,swapped_axis1_occurrence_numerator=wrongz))
print(json.dumps(dict(compact_rows=len(compact),attached_rows=len(a),
    axis2_axis3_components_diagonal=True,
    rows_changed_by_axis1_swap_among_existing_keys=wrong,
    local_axis1_swap_witness=witness,junction_readback=checks),indent=2))
