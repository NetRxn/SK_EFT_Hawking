"""Exact local original S4×S4 closure at rank 12."""
from collections import Counter, defaultdict
from itertools import permutations, product
from pathlib import Path
import json, sys

OUT=Path(__file__).parent
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
PRIOR=Path('/tmp/publication-c14-residual-edge-r1.klcKMh')
sys.path.insert(0,str(STAR))
import cut

ZERO=(0,0)
LOCAL_DEN=64**2
JUNCTION_DEN=768**2*LOCAL_DEN

def load(path):
    with path.open() as f:
        for line in f:
            cut.work('read_frozen_rows')
            yield json.loads(line)

def signed_rows(name,rows):
    cut.write_rows(name,rows)

def edges():
    owners=cut.star_owners(cut.roster(),12)
    out=[]
    for desc,neighbor in zip(owners[2:],(14,13),strict=True):
        axis,actual,frames,traces=desc
        assert actual==neighbor and not traces
        assert frames==[('S4',12,0,axis),('S4',12,1,axis)]
        a,den,support=cut.edge_tensor(desc,12,False)
        b,den0,support0=cut.edge_tensor(desc,12,True)
        assert a==b and den==den0==64 and support==support0==16 and len(a)==48
        signed_rows(f'edge12-axis{axis}.jsonl',a)
        out.append(a)
    return out

def epsilon(order):
    assert len(set(order))==4
    return (-1)**sum(a>b for i,a in enumerate(order) for b in order[i+1:])

def source_eps():
    table=defaultdict(dict)
    source=cut.original_action_factors_cached(cut.REG.sites[12])
    for f in source:
        if f.t_degree!=4:
            continue
        cut.work('read_ordered_S4')
        assert tuple(mu for _,mu,a in f.components)==(0,1,2,3)
        a,b,c,d=(a for _,mu,a in f.components)
        ((symbols,z),)=f.coefficient.terms
        assert not symbols and not z.imag and z.real in (1,-1)
        cut.reserve('ordered_S4',(a,b),table[c,d])
        table[c,d][a,b]=int(z.real)
    assert len(table)==12 and {len(d) for d in table.values()}=={2}
    return table

def literal_word(fused,m2,m3,r14,r13,transpose=False):
    def labels(i,m):
        return [8*i+k for k in range(8) if m>>k&1]
    word=[]
    for i,m in ((1,3),(2,3),(4,15),(9,3),(10,3),(12,fused)):
        word+=labels(i,m)
    word+=labels(12,m2)+labels(14,r14)+labels(12,m3)+labels(13,r13)
    if len(set(word))!=len(word):
        return 0
    if transpose:
        word=[97 if v==96 else 96 if v==97 else v for v in word]
    return (-1)**sum(a>b for i,a in enumerate(word) for b in word[i+1:])

def compact(edge2,edge3,ordered=None,adverse=False):
    out={}
    for (k,z),(l,w) in product(edge2.items(),edge3.items()):
        cut.work('raw_edge_pair' if ordered is not None else 'canonical_edge_pair')
        m2,r14,a20,a21=k
        m3,r13,a30,a31=l
        if m2&m3:
            continue
        fused=255^(m2|m3)
        if ordered is not None:
            sign=literal_word(fused,m2,m3,r14,r13)
            assert sign and literal_word(fused,m2,m3,r14,r13,True)==-sign
            a0=ordered.get((a20,a30),{})
            a1=ordered.get((a21,a31),{})
        else:
            if adverse:
                a30,a31=a31,a30
            sign=(-1)**(cut.crossing(fused,m2)+cut.crossing(fused|m2,m3))
            if a20==a30 or a21==a31:
                continue
            a0={(x,y):epsilon((x,y,a20,a30))
                for x,y in permutations(sorted({0,1,2,3}-{a20,a30}))}
            a1={(x,y):epsilon((x,y,a21,a31))
                for x,y in permutations(sorted({0,1,2,3}-{a21,a31}))}
        for ((a00,a10),s),((a01,a11),t) in product(a0.items(),a1.items()):
            cut.work('raw_epsilon_pair' if ordered is not None else 'canonical_epsilon_pair')
            key=(fused,a00,a01,a10,a11,r14,r13)
            value=cut.scale(cut.times(z,w),sign*s*t)
            cut.reserve('rank12_compact',key,out)
            out[key]=cut.add(out.get(key,ZERO),value)
    zero_count=sum(z==ZERO for z in out.values())
    return {k:v for k,v in out.items() if v!=ZERO},zero_count

def merge_compact(compact):
    by_fused=defaultdict(list)
    for k,v in compact.items():
        cut.work('index_compact')
        cut.reserve('compact_index',len(by_fused[k[0]]),{})
        by_fused[k[0]].append((k[1:],v))
    out={}
    for (m,n,fused),sign in load(PRIOR/'merge-rank12.jsonl'):
        for k,v in by_fused.get(fused,()):
            cut.work('attach_prior_merge')
            key=(m,n,*k)
            assert key not in out
            cut.reserve('rank12_attached',key,out)
            out[key]=cut.scale(v,sign)
    return out

def old_edges():
    old=defaultdict(dict)
    residual=defaultdict(dict)
    for (m81,old12,a10,a11,u,v),z in load(STAR/'edge-1.jsonl'):
        key=(m81,u,v)
        inner=(old12,a10,a11)
        cut.reserve('index_old_edge',inner,old[key])
        old[key][inner]=tuple(z)
    for (new4,new12,a00,a01,u,v),z in load(PRIOR/'residual-edge.jsonl'):
        key=(new4,u,v)
        inner=(new12,a00,a01)
        cut.reserve('index_residual_edge',inner,residual[key])
        residual[key][inner]=tuple(z)
    return old,residual

def full_junction_sign(m,n,m2,m3,r14,r13,transpose=False):
    # Original staged order at rank 12: old axis1, then residual axis0,
    # then axis2/axis3. Whole pairs from other sites give even crossings.
    if m&n or (m|n)&(m2|m3) or m2&m3:
        return 0
    fused=m|n
    def labels(i,mask):
        return [8*i+k for k in range(8) if mask>>k&1]
    word=(labels(1,3)+labels(2,3)+labels(4,3)+labels(9,3)+labels(10,3)+
          labels(12,m)+labels(4,12)+labels(12,n)+labels(12,m2)+labels(14,r14)+
          labels(12,m3)+labels(13,r13))
    assert len(word)==len(set(word)) and fused|m2|m3==255
    if transpose:
        word=[97 if v==96 else 96 if v==97 else v for v in word]
    return (-1)**sum(a>b for i,a in enumerate(word) for b in word[i+1:])

def controls(e2,e3,ordered,attached,bad):
    old,res=old_edges()
    reverse_old=defaultdict(list)
    reverse_res=defaultdict(list)
    for table,index in ((old,reverse_old),(res,reverse_res)):
        for k,group in table.items():
            for j in group:
                cut.work('index_junction_controls')
                cut.reserve('junction_reverse',len(index[j]),{})
                index[j].append(k)
    seen=set()
    results=[]
    for (m,n,a00,a01,a10,a11,r14,r13),z in sorted(attached.items()):
        cut.work('propose_junction_control')
        if not reverse_old[m,a10,a11] or not reverse_res[n,a00,a01]:
            continue
        for l,r in product(reverse_old[m,a10,a11][:3],reverse_res[n,a00,a01][:3]):
            cut.work('try_junction_control')
            key=l,r,r14,r13
            if key in seen:
                continue
            cut.reserve('junction_control_seen',key,seen)
            seen.add(key)
            total=wrong=ZERO
            live_terms=0
            first_term=None
            for (k0,x),(k1,y) in product(old[l].items(),res[r].items()):
                cut.work('compact_fixed_junction')
                m,a10,a11=k0
                n,a00,a01=k1
                bkey=(m,n,a00,a01,a10,a11,r14,r13)
                scale=cut.times(x,y)
                value=cut.times(scale,attached.get(bkey,ZERO))
                if value!=ZERO:
                    live_terms+=1
                    if first_term is None:
                        first_term=(bkey,value)
                total=cut.add(total,value)
                wrong=cut.add(wrong,cut.times(scale,bad.get(bkey,ZERO)))
            if not live_terms:
                continue
            raw=ZERO
            for (k,z),(j,w) in product(e2.items(),e3.items()):
                cut.work('literal_edge_pair_control')
                m2,x14,a20,a21=k
                m3,x13,a30,a31=j
                if (x14,x13)!=(r14,r13) or m2&m3:
                    continue
                for ((a00,a10),s),((a01,a11),t) in product(
                        ordered.get((a20,a30),{}).items(),ordered.get((a21,a31),{}).items()):
                    cut.work('literal_epsilon_pair_control')
                    for m in sorted({k0[0] for k0 in old[l]}):
                        cut.work('literal_old_mask_control')
                        x=old[l].get((m,a10,a11),ZERO)
                        if x==ZERO or m&(m2|m3):
                            continue
                        n=255^(m|m2|m3)
                        y=res[r].get((n,a00,a01),ZERO)
                        if y==ZERO:
                            continue
                        sign=full_junction_sign(m,n,m2,m3,r14,r13)
                        assert full_junction_sign(m,n,m2,m3,r14,r13,True)==-sign
                        term=cut.times(cut.times(x,y),cut.times(z,w))
                        raw=cut.add(raw,cut.scale(term,sign*s*t))
            assert raw==total
            cut.reserve('junction_controls',len(results),{})
            results.append(dict(old_edge_boundary=l,residual_edge_boundary=r,
                remote_masks=(r14,r13),signed_numerator=total,
                nonzero_compact_paths=live_terms,first_compact_path=first_term,
                swapped_axis3_occurrence_numerator=wrong,
                adverse_single_path_sign_numerator=cut.add(total,cut.scale(first_term[1],-2)),
                denominator=JUNCTION_DEN))
            if len(results)==4:
                return results
    raise AssertionError(('insufficient nonzero junction controls',len(results)))

def graph():
    g=json.loads((PRIOR/'graph.json').read_text())
    del g['factor_keys']['merge_rank12']
    g['factor_keys']['rank12_closure']=['old_mask12','new_mask12',
        'S4_12_a0_0','S4_12_a0_1','S4_12_a1_0','S4_12_a1_1','remote14','remote13']
    interior={'remote12','S4_12_a0_0','S4_12_a0_1','S4_12_a1_0','S4_12_a1_1'}
    g['boundary']=[k for k in g['boundary'] if k not in interior]+['remote14','remote13']
    g['combined_denominator']*=LOCAL_DEN
    g['semantics']+=' rank12_closure replaces merge_rank12 and incorporates the two new Haar edges, the rank-12 top wedge projection, and both original ordered S4 epsilons.'
    (OUT/'graph.json').write_text(json.dumps(g,indent=2)+'\n')
    return g['combined_denominator']

def main():
    cut.OUT=OUT
    cut.ROW_CAP=120_000
    cut.rss()
    e2,e3=edges()
    eps=source_eps()
    result,zero=compact(e2,e3)
    raw,zero0=compact(e2,e3,eps)
    assert raw==result and zero0==zero
    bad,_=compact(e2,e3,adverse=True)
    a=merge_compact(result)
    b=merge_compact(raw)
    assert a==b
    wrong=merge_compact(bad)
    signed_rows('rank12-compact.jsonl',result)
    signed_rows('rank12-closure.jsonl',a)
    print('exact compact',len(result),'attached',len(a),'adverse',len(wrong),
          'adverse table differences',sum(a.get(k,ZERO)!=wrong.get(k,ZERO)
                                          for k in a.keys()|wrong.keys()),flush=True)
    ctl=controls(e2,e3,eps,a,wrong)
    den=graph()
    cut.rss()
    meta=dict(edge_rows=[len(e2),len(e3)],compact_rows=len(result),zero_pruned=zero,
        attached_rows=len(a),adverse_rows=len(wrong),closure_denominator=LOCAL_DEN,
        graph_denominator=den,controls=ctl,charged_operations=dict(cut.WORK),
        storage=dict(cut.STORE),rss_peak_bytes=cut.RSS_PEAK,
        cap=dict(rows=cut.ROW_CAP,work=cut.WORK_CAP,accounted_bytes=cut.BYTE_CAP,
                 serialized_bytes=cut.FILE_CAP,sampled_rss=cut.RSS_CEILING,scalar=cut.INT_LIMIT))
    (OUT/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('passed fixed junction checks',len(ctl),flush=True)

if __name__=='__main__':
    main()
