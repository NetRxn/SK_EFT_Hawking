# Original N16 c14 exact rank-12 S4 closure

The pinned authority is the original periodic closed source_C at clean
primary 27012c18fa374e8341e124b510abbedeedb18d29. This increment attaches to
the independently accepted residual edge graph of the zero-centered
(01,01,23,23) representative. The representative exponential divisor
512 stays external.

The two remaining edges of rank 12 run along axes 2 and 3 to ranks
14 and 13. The full roster gives two rank-12 S4 coframe owners on
each and no curvature owners. The exact raw signed quarter-increment
and independent Haar moment comparator reproduces all 48 nonzero
rows at denominator 64 on each edge. Each edge retains a two-generator
mask at both endpoints and both ordered S4 components. Both component
pairs happen to be diagonal throughout these exact edge tables.

## Exact compact and attached factors

For a pair of non-overlapping axis-2/3 rank-12 masks, take their
unique four-generator complement. This is the fused rank-12 mask
of the accepted older graph. Apply the exterior permutation sign
and two ordered original S4 epsilon factors. Each epsilon independently
completes the fixed axis-2/3 component tuple with the two remaining
labels in both axis-0/1 orders. Accumulate signed Gaussian integer
coefficients and retain both exterior masks at ranks 14 and 13.

The resulting compact factor has 2,016 nonzero rows at denominator
4,096. The key is
`[fused12,a0_occ0,a0_occ1,a1_occ0,a1_occ1,remote14,remote13]`.
A separate route reconstructs the original 24 ordered S4 source
factors and computes each literal full exterior sign. It agrees on
the complete table. Serialized readback independently enumerates
both epsilon permutations, every edge pair and its local exterior
word and matches the compact output.

The already accepted rank-12 merge factor is absorbed into the
compact factor, with its own signed old/new exterior order. The
attached factor has 12,096 nonzero rows and replaces the earlier
rank-12 merge. Each row begins with `[old12,new12]` in place of
`fused12`, with the other slots unchanged. The factor graph then
sums both rank-12 mask slots and all four axis-0/1 component slots.
This closes all eight rank-12 generators and both original rank-12
S4 epsilon tensors, retaining rank-14/rank-13 masks. The graph's
combined exact denominator is 881,306,922,499,064,668,360,802,304
before the external divisor. The earlier graph stays factored.

## Signed checks and capacity

Four fixed local junctions sum the entire matching old axis-1,
residual axis-0 and new rank-12 compact factors. The independent
literal route traverses the two raw epsilon terms and all compatible
old masks without using the attached factor. All four complete
junction values are 3/512, from 12 nonzero compact paths apiece.
Reversing one recorded path gives 5/1,024. Transposing the first
two rank-12 generators reverses the full literal top-word sign.

An initial axis-3 occurrence-swap negative found no distinguishing
slice. It is inert on this whole local factor because the two
axis-3 labels agree in every edge row. A separate axis-1 swap
changes 6,048 of the 12,096 existing local keys, with the recorded
witness changing -1/8 to zero. The four tested junction slices
are invariant under that axis-1 swap; the local witness and the
junction sign adverse case test distinct boundaries.

The successful run charged 162,921 operations against 4,000,000
and 107,424 cumulative table entries against 120,000. It used
55,001,088 accounting bytes against 64 MiB and 458,752 serialized
bytes against 4 MiB. The sampled process peak RSS was 138,297,344
bytes under a sampled 384 MiB guard. Scalar products and additions
are prospectively bounded by the checked integer limit. The table
accounting excludes interpreter overhead, source construction,
secondary indexing/sorting and separate readback. This is local
capacity evidence and supplies no full representative admission.

Rank 4 still carries a four-generator boundary. Its remaining
edges along axes 2 and 3 reach ranks 6 and 5 and are degree two.
Their S4 component slots belong to separate original sites and
stay open at a rank-4 closure. The other representative arrangements,
whole representative values, c14, c0, full denominator and
normalization remain open.
