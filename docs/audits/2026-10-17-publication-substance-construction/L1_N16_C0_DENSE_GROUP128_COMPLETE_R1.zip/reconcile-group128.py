from ast import literal_eval
from csv import DictReader
from fractions import Fraction as Q
from io import StringIO
from pathlib import Path
from zipfile import ZipFile
import re
import sys

root=Path(__file__).resolve().parent
audit=Path(sys.argv[1])
source=root/'author/outer2/author-outer2-complete.tsv'
a=list(DictReader(source.open(),delimiter='\t'))
assert len(a)==37 and a[-1]['ordinal']=='total'
author={int(row['ordinal']):row for row in a[:-1]}
assert tuple(author)==tuple(range(36))
d=root/'independent/direct/accepted-24.tsv'
peer=list(DictReader(d.open(),delimiter='\t'))
expected=set(range(20))|{22,23,24,25}
assert len(peer)==25 and peer[-1]['ordinal']=='subtotal'
assert {int(row['ordinal']) for row in peer[:-1]}==expected
factor=40512224221827380280140849737629696
norm=factor*16*4**64
values={}
for row in peer[:-1]:
    i=int(row['ordinal'])
    assert literal_eval(row['coordinate'])==literal_eval(author[i]['coordinate'])
    assert int(row['weighted_products'])==int(author[i]['projected'])
    q=Q(int(row['raw_real']),norm)
    assert q==Q(row['normalized_real'])
    assert int(row['raw_imag'])==Q(row['normalized_imag'])==0
    values[i]=q
assert sum(values.values())==Q(peer[-1]['normalized_real']) and Q(peer[-1]['normalized_imag'])==0

unsharded=root/'independent/unsharded'
anchors=(20,26,27,30,32,33)
for i in anchors:
    trace=(unsharded/f'arithmetic-{i}.out').read_text()
    leaves=re.findall(rf'^exact signed leaf {i} (-?\d+) (-?\d+) (\d+) ([-\d/]+) ([-\d/]+) ',trace,re.M)
    assert len(leaves)==1
    r,im,d,re_q,im_q=leaves[0]
    assert int(d)==factor and int(im)==Q(im_q)==0
    q=Q(int(r),norm)
    assert q==Q(re_q)
    values[i]=q
pairs={21:20,28:26,29:27,31:30,34:32,35:33}
joint=(unsharded/'maps.out').read_text()
records=re.findall(r'^PASS exact raw signed transfer (\d+) (\d+) rows ',joint,re.M)
assert len(records)==6 and {int(r):int(l) for l,r in records}==pairs
for dst,src in pairs.items():
    values[dst]=values[src]
assert set(values)==set(author)
for i,row in author.items():
    assert Q(row['real'])==values[i] and Q(row['imaginary'])==0
outer2=sum(values.values())
assert outer2==Q(a[-1]['real']) and Q(a[-1]['imaginary'])==0

def member(name,entry):
    with ZipFile(audit/f'L1_N16_C0_DENSE_{name}_R1.zip') as z:
        return z.read(entry).decode('utf-8',errors='strict')
known=list(DictReader(StringIO(member('BRANCH1_LABEL0_OUTER67','known-group128.tsv')),delimiter='\t'))
by_scope={p['original scope']:Q(p['exact real']) for p in known if p['imaginary']=='0'}
partial=by_scope.pop('known subtotal')
assert sum(by_scope.values())==partial
assert set(by_scope)=={'branch0'}|{f'branch1 L{i}' for i in range(1,6)}|{
    f'branch1 L0 outer{i}' for i in (0,1,6,7)}
assert by_scope['branch1 L0 outer6']==by_scope['branch1 L0 outer7']==outer2
# The distinct source scopes 2, 3, 4, and 5 each occur once. Their equality
# follows from the raw signed maps at that boundary, not the equal 6 value.
scope=list(DictReader(StringIO(member('BRANCH1_LABEL0_REUSE','verified-scope.tsv')),delimiter='\t'))
assert [int(r['anchor']) for r in scope]==[0,0,2,2,2,2,6,6]
for i in range(2,6):
    by_scope[f'branch1 L0 outer{i}']=outer2
branch0=by_scope['branch0']
branch1=sum(v for k,v in by_scope.items() if k.startswith('branch1 '))
assert branch0==branch1
total=branch0+branch1
assert total==partial+4*outer2
print('scope','exact real','imaginary',sep='\t')
print('outer2',outer2,0,sep='\t')
print('branch0',branch0,0,sep='\t')
print('branch1',branch1,0,sep='\t')
print('group128',total,0,sep='\t')
