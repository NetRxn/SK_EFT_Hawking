# L1 original N16 group 128 complete signed contraction

The final numerical source is pinned at `54c99ad95`. Earlier archive
boundaries pin both original first-index branches, all six L assignments,
and the disjoint eight outer cases of assignment 0. The only remaining
contraction at this revision was the independently reviewed representative
2, with verified transfers to 3, 4 and 5. All four original cases enter once.

The final representative's source roster contains 36 distinct G/J cases.
Two independent frozen scopes account for 24 direct/triangle/four-factor
values and 12 values from unsharded exact contraction and signed reuse.
In the latter scope all six exact primitive factorizations preserve the
source coefficients and denominators. The proof for one anchor proceeds
through an exact Gaussian fiber fold followed by a bounded complementary
closure. Its reviewed adverse pairing is retained. Each signed map is
checked over the original endpoint rows. Normalization occurs once per
term.

From the extracted root, the following commands replay the author arithmetic
and independently accepted row retally. Pass the repository publication audit
directory at the pinned revision as `AUDIT_DIRECTORY`.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B author/outer2/retally-outer2.py author/outer2 author/triangles author/four-factor author/unsharded author/anchor30 author/map20 author/anchor30 | cmp - author/outer2/author-outer2-complete.tsv
python3 -B reconcile-group128.py AUDIT_DIRECTORY | cmp - verified-group128.tsv
```

The review manifests retain the scripts, small signed witnesses and source
pins for reconstruction of the larger immutable operands. This closure is
for original group 128, one part of the original N16 coefficient. The full
profile and physical susceptibility remain open.
