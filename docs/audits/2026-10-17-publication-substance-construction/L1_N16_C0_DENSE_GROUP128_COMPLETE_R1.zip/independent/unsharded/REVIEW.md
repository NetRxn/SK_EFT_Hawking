# Independent exact L1 group-128 closure

At candidate 54c99ad95, the independently recomposed complete signed group
128 result is `-17865027341916851312184266649/664613997892457936451903530140172288 + 0i`.
The outer-2 subtotal within original branch 1, L assignment 0, is
`-8720661076882492896855/10141204801825835211973625643008 + 0i`.
The value agrees numerically with independently computed outer 6. The two
were bound to distinct source lineages and evaluated separately.

The accepted archive pins original G(0,5,1)=49 outer-2 raw selection
and its eight-factor row cap. Independent histograms exhaust 36 disjoint
pairs on (G(0,0,2), J(1,4,2)), with 4,558,848 selected products. The
support weights are workload counts. Every scoped selector inverse
lift reconstructs the signed coefficients and inherited denominator exactly.
Byte replay independently repeated the original outer-2 partition, seven
reducers and seven cap-producing contractions, matching their serialized
outputs and stage stdout. The peer's immutable ledger and manifest cover
the other 24 original coordinates.

Six exact unsharded anchors (20, 26, 27, 30, 32, 33) were recomputed by a
second Gaussian integer implementation. All 42 primitive two-part splits
were directly inverted. Fresh private class indices have identical finite
domains at both endpoints and disappear on contraction. Product counts equal
the original support in every inverse, and maps preserve the zero complement.
Every guarded stage recomputed both Gaussian components, with reversed
factor iteration and canonical axis order. The terminal hash-bound state
reconstructs exactly from the initial split and listed joins.

Anchor 30 was reduced to four factors. Independent ray quotient grouped
by ratios and selected minimal-content representatives with exact Gaussian
divisibility. The complete resulting scalar and the original folded
operand's scalar coincide under independent complementary-pair evaluation.
The two (1,2) runs each visited 3,569,184 pair rows and consumed 25,455,204
and 25,449,462 probes. The attempted distinct (2,3) orientation was
refused before enumeration at 23,763,456 projected pair rows, above the
8 million bound. The accepted alternative stayed within the unchanged
8-million pair and 30-million probe limits. The original refusal is retained.

Six independently checked signed raw maps transfer each anchor to one
distinct target. Each map bijects incidence-bundle values at both endpoints
and on the compatible intersection. The two Gaussian components of every
signed row compare exactly, each denominator is preserved and each edge
sign occurs twice in the closed product. The 12 scoped raw values sum to
`-143296484677465785143715867085249536187610301385560223660225069056 + 0i`.
Reconstructed occupation and phase impose the common external positive
normalization 1/(16*4^64) once on the factor denominator
40512224221827380280140849737629696.

The 12 scoped values and peer's 24 complementary values each agree with their
author terms. The whole-36 ledger retains each raw term and provenance. The
group ledger then uses archived recorded independent results for original
branch 0, branch 1 L1–L5, and L0 outer 0, 1, 6, 7. Archived exact maps bind
the fresh outer-2 result to distinct original outer coordinates 3, 4 and 5.
Every original outer ordinal is counted once, and both original first-index
branch totals compare exactly. This is the signed result for group 128.
Other groups and any later physical claims require separate evidence.

The portable archive includes the review code, full signed ledgers, signed
witnesses and byte receipts. The binary source, split, pilot and cap files
are required separately for a fresh replay and identified in the operand
manifest. The bounded aborted pair and its original independent code are
kept alongside the successful replay.
