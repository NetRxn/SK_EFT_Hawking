from collections import defaultdict
from gzip import decompress
from hashlib import sha256
from math import prod
from pickle import loads
from time import monotonic
from paths import row,high,extra,pairs,N

def load(path):
    raw=path.read_bytes()
    return loads(raw),sha256(raw).hexdigest()

def scope(factors):
    by_wire=defaultdict(list)
    by_edge=defaultdict(set)
    for i,(a,rows,d) in enumerate(factors):
        assert len(a)==len(set(a)) and rows and d>0
        for w in a:by_wire[w].append(i)
    for w,p in by_wire.items():
        assert len(p)==2
        by_edge[tuple(p)].add(w)
    return dict(by_edge)

for u,v in pairs:
    now=monotonic()
    a,ha=load(row/f's{u}.pkl')
    b,hb=load(row/f's{v}.pkl')
    file=(extra if u==20 else high)/f'witness-select-{u}-{v}.pkl.gz'
    packed=file.read_bytes()
    perm,old,new,links,negative=loads(decompress(packed))
    A,B=a['factors'],b['factors']
    assert perm==tuple(range(len(A))) and len(B)==len(A)==8
    assert a['physical_cut']==b['physical_cut']
    assert prod(d for _,_,d in A)==prod(d for _,_,d in B)==N
    assert scope(A)=={e:set(w) for e,w in old.items()}
    assert scope(B)=={e:set(w) for e,w in new.items()}
    assert set(old)==set(new)==set(links)==set(negative) and len(old)==21
    translations={e:{tuple(k):(tuple(t),-1 if k in set(negative[e]) else 1)
                     for k,t in links[e].items()} for e in links}
    left_dom=defaultdict(dict)
    right_dom=defaultdict(dict)
    total=flips=0
    for i,((ox,X,d),(oy,Y,e)) in enumerate(zip(A,B,strict=True)):
        plan=[(edge,tuple(ox.index(k) for k in old[edge]),tuple(oy.index(k) for k in new[edge]))
              for edge in sorted(links) if i in edge]
        assert d==e and len(X)==len(Y)
        assert sorted(pos for _,p,_ in plan for pos in p)==list(range(len(ox)))
        assert sorted(pos for _,_,q in plan for pos in q)==list(range(len(oy)))
        actual=set()
        for r,(x,y) in X.items():
            out=[None]*len(oy)
            phase=1
            for edge,p,q in plan:
                left=tuple(r[pos] for pos in p)
                right,sign=translations[edge][left]
                phase*=sign
                for j,k in zip(q,right,strict=True):out[j]=k
            mapped=tuple(out)
            assert mapped not in actual and Y[mapped]==(phase*x,phase*y)
            actual.add(mapped)
            flips+=phase<0
        assert actual==Y.keys()
        for edge,p,q in plan:
            left_dom[edge][i]={tuple(k[j] for j in p) for k in X}
            right_dom[edge][i]={tuple(k[j] for j in q) for k in Y}
        total+=len(actual)
    for edge,T in links.items():
        left,right=left_dom[edge],right_dom[edge]
        assert set(left)==set(right)==set(edge)
        assert set(T)==set.union(*left.values())
        assert len(set(T.values()))==len(T) and set(T.values())==set.union(*right.values())
        assert set(negative[edge])<=set(T) and len(set(negative[edge]))==len(negative[edge])
        assert {T[k] for k in set.intersection(*left.values())}==set.intersection(*right.values())
        assert all({T[k] for k in left[i]}==right[i] for i in edge)
    print('PASS exact raw signed transfer',u,v,'rows',total,'edge values',sum(map(len,links.values())),
          'flipped rows',flips,'hashes',ha,hb,sha256(packed).hexdigest(),
          'seconds',round(monotonic()-now,6),flush=True)
