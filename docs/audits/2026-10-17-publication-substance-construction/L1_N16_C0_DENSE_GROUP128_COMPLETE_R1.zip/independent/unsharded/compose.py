from ast import literal_eval
from csv import DictReader
from fractions import Fraction as Q
from hashlib import file_digest,sha256
from io import StringIO
from pathlib import Path
from re import search,M
from zipfile import ZipFile
from paths import row,outer,anchors,pairs,N,norm

def sha(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
here=Path.cwd()
audit=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
peer=Path('/private/tmp/l1-branch1-L0-outer2-direct-independent.Nn45e9')
assert sha(peer/'review-manifest.sha256')=='c03ce28abbbcc2925340519af436689025fc1f005817e4300369a7c0cda7912f'
hash_line=next(x.split() for x in (peer/'review-manifest.sha256').read_text().splitlines() if x.endswith('accepted-24.tsv'))
assert hash_line[0]==sha(peer/'accepted-24.tsv')
author=list(DictReader((row/'author-outer2-complete.tsv').read_text().splitlines(),delimiter='\t'))
scope,points=literal_eval((row/'s0.roster').read_text())
assert scope==(('G',0,0,2),('J',1,4,2)) and len(dict(points))==len(points)==36
ordered=sorted(points,key=lambda p:(p[1],p[0]))
core={}
method={}
for i in anchors:
    text=Path(f'arithmetic-{i}.out').read_text()
    match=search(rf'^exact signed leaf {i} (-?\d+) (-?\d+) (\d+) (\S+) (\S+) original joins (\d+) seconds (\S+)$',text,M)
    assert match is not None,(i,text)
    a,b,d=map(int,match.groups()[:3])
    assert d==N and (Q(a,norm),Q(b,norm))==tuple(map(Q,match.groups()[3:5]))
    core[i]=(a,b)
    method[i]='independent primitive splits and reversed joins'
maps=Path('maps.out').read_text()
for a,b in pairs:
    assert search(rf'^PASS exact raw signed transfer {a} {b} ',maps,M)
    assert ordered[a][1]==ordered[b][1] and ordered[a][0]!=ordered[b][0]
    core[b]=core[a]
    method[b]=f'exact raw signed transfer from {a}'
assert len(core)==12
checked=list(DictReader((peer/'accepted-24.tsv').read_text().splitlines(),delimiter='\t'))
assert len(checked)==25 and checked[-1]['ordinal']=='subtotal'
claimed=[]
values=dict(core)
for item in checked[:-1]:
    i=int(item['ordinal'])
    assert i not in values
    assert ordered[i]==(literal_eval(item['coordinate']),int(item['weighted_products']))
    a,b=int(item['raw_real']),int(item['raw_imag'])
    vals=(Q(a,norm),Q(b,norm))
    assert vals==tuple(Q(item[k]) for k in ('normalized_real','normalized_imag'))
    values[i]=(a,b)
    method[i]='independent peer '+item['method']
    claimed.append((a,b))
assert tuple(map(sum,zip(*claimed,strict=True)))==tuple(int(checked[-1][k]) for k in ('raw_real','raw_imag'))
assert set(values)==set(range(36))
group=[]
with Path('outer2-independent.tsv').open('x') as out:
    print('ordinal','coordinate','products','method','raw_real','raw_imag','real','imag',sep='\t',file=out)
    for i,(k,n) in enumerate(ordered):
        r=author[i]
        a,b=values[i]
        answer=Q(a,norm),Q(b,norm)
        assert (int(r['ordinal']),literal_eval(r['coordinate']),int(r['projected']))==(i,k,n)
        assert answer==tuple(Q(r[key]) for key in ('real','imaginary'))
        print(i,k,n,method[i],a,b,*answer,sep='\t',file=out)
        group.append(answer)
    ans=tuple(map(sum,zip(*group,strict=True)))
    assert ans==tuple(Q(author[-1][k]) for k in ('real','imaginary'))
    print('total','','','','','',*ans,sep='\t',file=out)
print('outer2 six exact anchors and six transfers raw subtotal',*tuple(map(sum,zip(*core.values(),strict=True))))
print('outer2 exact complete signed 36-term subtotal',*ans)
seen={}
def archived(suffix,member):
    path=audit/f'L1_N16_C0_DENSE_{suffix}_R1.zip'
    seen[path.name]=sha(path)
    with ZipFile(path) as z:
        return z.read(member).decode()
def val(name,member,key):
    [t]=[x.split('\t')[1:3] for x in archived(name,member).splitlines() if x.split('\t')[0]==key]
    return tuple(map(Q,t))
scope=list(DictReader(StringIO(archived('BRANCH1_LABEL0_REUSE','verified-scope.tsv')),delimiter='\t'))
assert [int(x['outer']) for x in scope]==list(range(8))
assert [int(x['anchor']) for x in scope]==[0,0,2,2,2,2,6,6]
raw_maps=archived('BRANCH1_LABEL0_REUSE','reuse/outer2-to-3-5/verify.out')
for i in (3,4,5):
    line=search(rf'^2\t{i}\t[^\n]+',raw_maps,M)[0].split('\t')
    assert line[10]==sha(outer/'s2.pkl') and line[11]==sha(outer/f's{i}.pkl')
outer_ledger={i:tuple(Q(scope[i][k]) for k in ('real','imaginary')) for i in (0,1)}
outer_ledger.update({i:ans for i in range(2,6)})
outer_ledger.update({i:val('BRANCH1_LABEL0_OUTER67','verified-values.tsv',f'outer-{i}') for i in (6,7)})
assert set(outer_ledger)==set(range(8))
labels={0:tuple(map(sum,zip(*outer_ledger.values(),strict=True)))}
labels.update({i:val(f'BRANCH1_LABEL{i}','verified-composition.tsv','total') for i in (1,2)})
labels.update({i:val('BRANCH1_LABELS345','verified-exact-values.tsv',str(i)) for i in (3,4,5)})
b0=val('CHILD01_PAIRED_COMPLETE_BRANCH0','recombined.tsv','first-index branch0')
b1=tuple(map(sum,zip(*labels.values(),strict=True)))
g128=tuple(a+b for a,b in zip(b0,b1,strict=True))
assert g128==(Q(-17865027341916851312184266649,664613997892457936451903530140172288),Q(0))
with Path('group128-independent.tsv').open('x') as o:
    print('scope','real','imag',sep='\t',file=o)
    for i,x in sorted(outer_ledger.items()):print(f'original branch1 L0 outer{i}',*x,sep='\t',file=o)
    for i,x in sorted(labels.items()):print(f'original branch1 L{i} total',*x,sep='\t',file=o)
    print('original branch1 total',*b1,sep='\t',file=o)
    print('original branch0 total',*b0,sep='\t',file=o)
    print('group 128 total',*g128,sep='\t',file=o)
with Path('composition-inputs.sha256').open('x') as o:
    for name,h in sorted(seen.items()):print(h,name,sep='  ',file=o)
print('exact group 128',*g128)
