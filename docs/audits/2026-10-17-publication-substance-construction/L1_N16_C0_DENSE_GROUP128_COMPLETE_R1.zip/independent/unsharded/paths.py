from pathlib import Path
prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
def path(key):
    return Path((prep/f'{key}.path').read_text().strip())
outer=path('label0-roster')
row=path('label0-row8')
small=path('label0-outer2-unsharded')
high=Path('/private/tmp/l1-group128-branch1-label0-outer2-high-author.usb6eT')
extra=path('label0-outer2-map20')
anchors=(20,26,27,30,32,33)
pairs=((20,21),(26,28),(27,29),(30,31),(32,34),(33,35))
N=40512224221827380280140849737629696
norm=N*16*4**64
