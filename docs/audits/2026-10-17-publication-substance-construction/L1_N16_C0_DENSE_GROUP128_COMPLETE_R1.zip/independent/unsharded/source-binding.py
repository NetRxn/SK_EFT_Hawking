from pathlib import Path
from hashlib import sha256
from itertools import product
from math import factorial,prod
from zipfile import ZipFile
from paths import outer,N,norm
base=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
archive=base/'L1_N16_C0_DENSE_BRANCH1_LABEL0_REUSE_R1.zip'
assert sha256(archive.read_bytes()).hexdigest()=='8620faa764075ad31673ed01e851b64bdbea06f262d885b305d306251aa992a4'
with ZipFile(archive) as z:
    inventory=dict((name,h) for h,name in (r.split(maxsplit=1) for r in z.read('reuse/outer2-to-3-5/operands.sha256').decode().splitlines()))
for p in (outer/'s2.pkl',outer/'slice2/row-cap-physical-slice-dense-branch.pkl'):
    h=sha256(p.read_bytes()).hexdigest()
    assert inventory[str(p)]==h
    print('accepted original input pin',h,p)
basis=sorted((a,b,c) for a,b,c in product(range(5),repeat=3) if a+b+c<=4)
codes=(503841882182,1461451755920)
occ=[[basis[(code//64**r)%64] for r in range(8)] for code in codes]
world=sum((axis+3)*n for layer in occ for row in layer for axis,n in enumerate(row))
cross=0
for layer in occ:
    prev=[]
    for u in range(8):
        for axis in range(3):
            if u&(1<<axis):continue
            v=u+(1<<axis)
            count=sum(layer[r][j] for r in (u,v) for j in range(3) if j!=axis)
            cross+=sum(count*m*sum(x>y for x in (s,t) for y in (u,v)) for s,t,m in prev)
            prev.append((u,v,count))
p=[n for layer in occ for row in layer for n in row]
assert (world,cross,sum(p),prod(map(factorial,p)))==(136,444,32,16)
assert (-1)**(world+cross)==1 and norm==N*prod(map(factorial,p))*4**(sum(p)*2)
print('normalization phase +1, occupation 32, factorial 16, fourths exponent 64, denominator',norm)
