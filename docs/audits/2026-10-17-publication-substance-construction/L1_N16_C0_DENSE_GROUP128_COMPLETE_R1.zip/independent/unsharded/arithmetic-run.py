from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
from paths import anchors
def run(i):
    with Path(f'arithmetic-{i}.out').open('xb') as f:
        p=subprocess.run([sys.executable,'-u','arithmetic.py',str(i)],stdout=f,stderr=subprocess.STDOUT,timeout=150)
    print(f'{i}\t{p.returncode}',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run,anchors))
