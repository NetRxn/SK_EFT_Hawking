from collections import Counter,defaultdict
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from math import gcd,prod
from pathlib import Path
from pickle import loads
from re import search
from sys import argv
from time import monotonic
from paths import row,small,high,N,norm

started=monotonic()
def read(p):
    b=p.read_bytes()
    return loads(b),sha256(b).hexdigest()
def mul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def positions(a,b):
    col=tuple(a.index(w) for w in b)
    return lambda key:tuple(key[j] for j in col)
def verify(f):
    assert all(s and d>0 and len(a)==len(set(a)) and all(any(v) for v in s.values()) for a,s,d in f)
    assert set(Counter(w for a,_,_ in f for w in a).values())<= {2}
    assert prod(d for _,_,d in f)==N
def join(f,g):
    a,x,d=f; b,y,e=g
    shared=tuple(sorted(set(a)&set(b)))
    external=tuple(sorted(set(a)^set(b)))
    aa=tuple(w for w in external if w in a)
    bb=tuple(w for w in external if w in b)
    P,Q=positions(a,shared),positions(b,shared)
    A,B=positions(a,aa),positions(b,bb)
    order=positions(aa+bb,external)
    hist=Counter(map(P,x))
    forecast=sum(hist[Q(k)] for k in y)
    assert forecast<=8_000_000
    buckets=defaultdict(list)
    for key,value in x.items():
        buckets[P(key)].append((A(key),value))
    out={}
    work=0
    for k,v in y.items():
        right=B(k)
        for left,z in buckets.get(Q(k),()):
            dest=order(left+right)
            old=out.get(dest,(0,0))
            rr,ii=mul(v,z)
            value=(old[0]+rr,old[1]+ii)
            if any(value): out[dest]=value
            else: out.pop(dest,None)
            work+=1
            assert len(out)<=1_000_000
            if work%32768==0: assert monotonic()-started<90
    assert work==forecast
    return (external,out,d*e),work
def eq(x,y):
    a,r,d=x; b,s,e=y
    return d==e and set(a)==set(b) and {positions(a,b)(k):v for k,v in r.items()}==s
def primitive(vectors):
    # Represent a Gaussian ray by Hermitian ratios to its first nonzero entry.
    keys=sorted(vectors)
    a,b=vectors[keys[0]]
    n=a*a+b*b
    return tuple((k,Fraction(r*a+s*b,n),Fraction(s*a-r*b,n))
                 for k in keys for r,s in (vectors[k],))
def scale_ratio(v,w):
    a,b=v;c,d=w
    n=a*a+b*b
    q,r=divmod(c*a+d*b,n)
    s,t=divmod(d*a-c*b,n)
    assert (r,t)==(0,0) and mul((q,s),v)==w
    return q,s
def fold(f,g):
    a,x,d=f;b,y,e=g
    common=tuple(sorted(set(a)&set(b)))
    if not common:return f,g,0
    al=tuple(w for w in a if w not in common);bl=tuple(w for w in b if w not in common)
    p,q,s,t=positions(a,common),positions(b,common),positions(a,al),positions(b,bl)
    L,R=defaultdict(dict),defaultdict(dict)
    for k,v in x.items(): L[p(k)][s(k)]=v
    for k,v in y.items(): R[q(k)][t(k)]=v
    classes=defaultdict(list)
    for k in L.keys()&R.keys():
        classes[primitive(L[k])].append(k)
    if len(classes)==len(L)==len(R): return f,g,0
    X,Y={},{}
    for keys in classes.values():
        # Pick a representative of minimal content; all observed rays admit its scale.
        anchor=min(keys,key=lambda k:(gcd(*(n for z in L[k].values() for n in z)),k))
        A=L[anchor]
        first=min(A)
        for k,value in A.items(): X[anchor+k]=value
        for key in keys:
            h=scale_ratio(A[first],L[key][first])
            assert {k:mul(h,z) for k,z in A.items()}==L[key]
            for k,value in R[key].items():
                dest=anchor+k
                rr,ii=mul(h,value); old=Y.get(dest,(0,0))
                Y[dest]=(old[0]+rr,old[1]+ii)
    return (common+al,X,d),(common+bl,{k:v for k,v in Y.items() if any(v)},e),len(L.keys()&R.keys())-len(classes)
def closure(f,I):
    J=tuple(j for j in range(4) if j not in I)
    factors=[f[j] for j in (*I,*J)]
    scopes=[u[0] for u in factors]
    def common(i,j):return tuple(sorted(set(scopes[i])&set(scopes[j])))
    def index(i,edge,out):
        scope,rows,_=factors[i]
        p,q=positions(scope,edge),positions(scope,out)
        assert len(edge)+len(out)==len(scope)
        result=defaultdict(dict)
        for k,val in rows.items():
            outer,inner=q(k),p(k)
            assert inner not in result[outer]
            result[outer][inner]=val
        return result
    left=common(0,1);right=common(2,3)
    X,Y=index(0,left,common(0,2)+common(0,3)),index(1,left,common(1,2)+common(1,3))
    U,V=index(2,right,common(0,2)+common(1,2)),index(3,right,common(0,3)+common(1,3))
    # Reindex the selected pair by its inner wire; use support blocks for the complement.
    def invert(table,n):
        out=defaultdict(list)
        for outer,inner in table.items():
            for k,z in inner.items():out[k].append((outer[:n],outer[n:],z))
        return out
    X,Y=invert(X,len(common(0,2))),invert(Y,len(common(1,2)))
    forecast=sum(len(X[k])*len(Y[k]) for k in X.keys()&Y.keys())
    assert forecast<=8_000_000,(I,forecast)
    probes=0;products=0
    @lru_cache(maxsize=120000)
    def dot(a,b):
        nonlocal probes,products
        AA,BB=U.get(a,{}),V.get(b,{})
        probes+=min(len(AA),len(BB))
        assert probes<=30_000_000
        rr=ii=0
        for v in AA.keys()&BB.keys():
            x,y=mul(AA[v],BB[v]);rr+=x;ii+=y;products+=1
        return rr,ii
    real=imag=visits=0
    for k in X.keys()&Y.keys():
        for a,b,z in X[k]:
            for c,d,w in Y[k]:
                u,v=mul(mul(z,w),dot(a+c,b+d));real+=u;imag+=v;visits+=1
                if visits%32768==0:assert monotonic()-started<90
    assert visits==forecast
    print('independent complementary closure',I,J,visits,probes,products,dot.cache_info(),flush=True)
    return real,imag
i=int(argv[1])
origin=row/f'slice{i}'/'row-cap-physical-slice-dense-branch.pkl'
p,q=(high/'unsharded-split30.pkl',high/'unsharded-pilot30.pkl') if i==30 else tuple(small/str(i)/f'unsharded-{x}.pkl' for x in ('split','pilot'))
original,h=read(origin)
split,hs=read(p)
pilot,hp=read(q)
assert split['split_source_sha256']==pilot['split_source_sha256']==h
assert split['physical_cut']==pilot['physical_cut']==original['physical_cut']
verify(original['factors']);verify(split['factors'])
print('source split pilot SHA256',i,h,hs,hp,flush=True)
stage=dict(zip(split['factor_labels'],split['factors'],strict=True))
for j,f in enumerate(original['factors']):
    a,b=stage[(j,0)],stage[(j,1)]
    wire=set(a[0])&set(b[0])
    assert wire=={('exact-fiber-split',j)}
    assert not wire&set(f[0])
    assert a[2]==f[2] and b[2]==1
    left=positions(a[0],tuple(wire));right=positions(b[0],tuple(wire))
    assert set(map(left,a[1]))==set(map(right,b[1]))
    x,n=join(b,a)
    assert eq(x,f) and n==len(f[1])==len(x[1])
    print('independent split inverse',j,n,f[2],flush=True)
t=0
for a,b,c,n,m,k in pilot['trace']:
    x,cost=join(stage.pop(b),stage.pop(a))
    assert (cost,len(x[1]),len(x[0]))==(n,m,k)
    t+=cost
    assert t<=30_000_000
    stage[c]=x
    print('independent reversed row join',a,b,c,cost,m,k,flush=True)
assert tuple(stage)==pilot['factor_labels'] and all(eq(f,g) for f,g in zip(stage.values(),pilot['factors'],strict=True))
f=list(stage.values())
verify(f)
if i!=30:
    assert len(f)==1 and not f[0][0] and f[0][2]==N
    ans=f[0][1][()]
else:
    assert len(f)==4 and len(pilot['trace'])==10
    try:
        for sweep in range(2):
            for u,v in combinations(range(4),2):
                a,b,x=fold(f[u],f[v]);b,a,y=fold(b,a)
                f[u],f[v]=a,b
                if x or y:print('independent exact fold',sweep,u,v,x,y,flush=True)
    except AssertionError:
        print('non-divisible representative refused; use primitive gcd version',flush=True)
        raise
    verify(f)
    authored,hf=read(high/'unsharded-pilot30-fold.pkl')
    assert authored['fold_predecessor']==hp and len(authored['factors'])==4
    print('fold operand identity',hf,'independent row figures',[len(z) for _,z,_ in f],
          'authored',[len(z) for _,z,_ in authored['factors']],flush=True)
    ans=closure(f,(2,3))
    assert ans==closure(authored['factors'],(1,2))
print('exact signed leaf',i,*ans,N,*[Fraction(z,norm) for z in ans], 'original joins',t,
      'seconds',round(monotonic()-started,6),flush=True)
