from hashlib import file_digest
from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile, ZIP_DEFLATED
from paths import row,outer,small,high,extra,anchors,pairs
p=Path.cwd()
peer=Path('/private/tmp/l1-branch1-L0-outer2-direct-independent.Nn45e9')
author={
    'original': [outer/'s2.pkl',outer/'s2.roster',*sorted((outer/'slice2').glob('*'))],
    'roster': [row/'author-outer2-complete.tsv',row/'s0.roster',row/'checkpoint/quotient.py',
               row/'reduce-label-frontier.py',row/'contract-with-peer.py',row/'exact-multicut.py',row/'peer_pair.py',
               *[row/f's{i}.pkl' for pair in pairs for i in pair],
               *[row/f's{i}.roster' for pair in pairs for i in pair],
               *[row/f'label-s{i}-reduced-frontier.pkl' for i in anchors]],
    'high': [high/f for f in ['split30.out','fold30.out','close30-12.out','close30-01.out',
                              'unsharded-split30.pkl','unsharded-pilot30.pkl','unsharded-pilot30-fold.pkl',
                              'split30.py','fold30.py','close30.py','close30-20m-refusal.out']],
    'peer':[peer/'accepted-24.tsv',peer/'review-manifest.sha256'],
}
for i in anchors:
    author[f'source-{i}']=sorted((row/f'slice{i}').glob('*'))
    if i!=30: author[f'split-{i}']=sorted((small/str(i)).glob('*'))
author['split-methods']=[small/'split.py',small/'shape.py']
author['signed-witnesses']=[(extra if i==20 else high)/f'witness-select-{i}-{j}.pkl.gz' for i,j in pairs]
def digest(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
with (p/'operands.sha256').open('x') as out:
    for cat,paths in author.items():
        for src in paths:
            if not src.is_file():continue
            print(digest(src),src,sep='  ',file=out)
            if src.suffix=='.pkl':continue
            save=p/'author-receipts'/cat/src.name
            save.parent.mkdir(parents=True,exist_ok=True)
            copyfile(src,save)
paths=[p/x for x in (
    'paths.py','source-binding.py','source-binding.out','support.py','support.out','maps.py','maps.out',
    'arithmetic.py','arithmetic-initial.py','arithmetic-run.py','arithmetic.tsv',
    'compose.py','compose.out','composition-inputs.sha256','outer2-independent.tsv','group128-independent.tsv',
    'lineage.py','lineage.out','operands.sha256','REVIEW.md','freeze.py')]
paths.extend(sorted(p.glob('arithmetic-*.out')))
paths.extend(sorted(q for q in (p/'author-receipts').rglob('*') if q.is_file()))
manifest=p/'review.sha256'
with manifest.open('x') as out:
    for file in paths:print(digest(file),file.relative_to(p),sep='  ',file=out)
with ZipFile('portable-review.zip','x',ZIP_DEFLATED,compresslevel=6) as z:
    for file in [*paths,manifest]:z.write(file,file.relative_to(p))
