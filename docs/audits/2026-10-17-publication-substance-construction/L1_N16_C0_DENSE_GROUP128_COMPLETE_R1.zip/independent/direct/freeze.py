from hashlib import file_digest
from pathlib import Path
from shutil import copyfile

base=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
def path(name): return Path((base/f'label0-{name}.path').read_text().strip())
row,tri,four,seed=(path(name) for name in ('row8','outer2-triangles','outer2-four-factor','roster'))
scopes={*range(20),22,23,24,25}
triangles={*range(12,20),23,25}
receipts=Path('author-receipts')
receipts.mkdir()
bins=set()
def save(source,target):
    if source.suffix=='.pkl':
        bins.add(source)
        return
    dest=receipts/target
    dest.parent.mkdir(parents=True,exist_ok=True)
    copyfile(source,dest)
def generic(root,label,ids):
    for name in ('exact-multicut.py','reduce-label-frontier.py','contract-with-peer.py','peer_pair.py','checkpoint/quotient.py','run-with-peer.py'):
        save(root/name,Path(label)/name)
    for i in ids:
        for item in (root/f'slice{i}').iterdir():
            if item.is_file():
                save(item,Path(label)/f'slice{i}'/item.name)
        for stem in (f's{i}.pkl',f's{i}.roster',f'label-s{i}-reduced-frontier.pkl'):
            save(root/stem,Path(label)/stem)
generic(seed,'original', [2])
generic(row,'outer2',sorted(scopes))
for i in set(range(36))-scopes:
    for name in (f's{i}.pkl',f's{i}.roster'):
        save(row/name,Path('outer2')/name)
for i in (22,24):
    root=four/str(i)
    generic(root,f'nested-{i}',range(16))
    for name in ('partition-input.pkl','plan.out','select-pair.py'):
        save(root/name,Path(f'nested-{i}')/name)
save(tri/'forecast.tsv',Path('triangles/forecast.tsv'))
save(tri/'triangle-shards.py',Path('triangles/triangle-shards.py'))
for i in triangles:
    for item in (tri/str(i)).iterdir():
        if item.is_file():
            save(item,Path(f'triangles/{i}')/item.name)
with Path('serialized-source-operands.sha256').open('w') as f:
    for path in sorted(bins):
        with path.open('rb') as operand:
            print(file_digest(operand,'sha256').hexdigest(),path,sep='  ',file=f)
