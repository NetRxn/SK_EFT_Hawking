from collections import Counter
from fractions import Fraction
from hashlib import file_digest
from pathlib import Path
from pickle import loads
from re import M, findall, search

base=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
def path(name): return Path((base/f'label0-{name}.path').read_text().strip())
row,tri,four,seed=(path(name) for name in ('row8','outer2-triangles','outer2-four-factor','roster'))
N=40512224221827380280140849737629696
scale=N*16*4**64
triangles={*range(12,20),23,25}
scopes={*range(12),*triangles,22,24}
steps={name:(mode,h) for name,mode,h in map(str.split,Path('arithmetic-index.tsv').read_text().splitlines())}
lineage={name:(h,s,t,u) for name,h,s,t,u in map(str.split,Path('lineage.tsv').read_text().splitlines())}
assert len(steps)==54 and len(lineage)==57
assert set(lineage)=={'origin-2',*[f'outer-{i}' for i in sorted(scopes)],*[f'nested-{i}-{j}' for i in (22,24) for j in range(16)]}

def hash(path):
    with path.open('rb') as f: return file_digest(f,'sha256').hexdigest()
assert lineage['origin-2'][:2]==(hash(seed/'label-s2-reduced-frontier.pkl'),hash(seed/'slice2/row-cap-physical-slice-dense-branch.pkl'))
def raw(text):
    x,y,d=map(int,search(r'^(?:PASS )?raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',text,M).groups())
    assert d==N
    return x,y
def scalar(text):
    x,y=search(r'^exact normalized (?:real )?(\S+)(?: imaginary (\S+))?',text,M).groups()
    return Fraction(x),Fraction(y or 0)
def actual(tag):
    mode,h=steps[tag]
    d=Path('arithmetic')/tag
    file=mode+'.out'
    text=(d/file).read_text()
    assert f'input SHA256 {h}' in text
    a,b=raw(text)
    assert scalar(text)==(Fraction(a,scale),Fraction(b,scale))
    timing=[j.split('\t') for j in (d/'timing.tsv').read_text().splitlines()]
    seconds=next(float(t) for name,s,t in timing if name==mode and s=='0')
    work=int(search(r'(?:independent matched products |Gaussian products )(\d+)',text)[1])
    return (a,b),h,work,seconds

def direct(tag,d,i,stage):
    r,h,w,t=actual(tag)
    assert h==lineage[stage][0]==hash(d/f'label-s{i}-reduced-frontier.pkl')
    log=(d/f'slice{i}/contraction.out').read_text()
    assert scalar(log)==tuple(Fraction(x,scale) for x in r)
    return r,h,w,t

def projection(scope,shared):
    ix=tuple(scope.index(w) for w in shared)
    return lambda row:tuple(row[k] for k in ix)

def triangle(i):
    tag=f'triangle-{i}'
    r,h,w,t=actual(tag)
    d=tri/str(i)
    operand=d/'join-cap-input.pkl'
    assert h==hash(operand)==lineage[f'outer-{i}'][1]
    assert h==hash(row/f'slice{i}/join-cap-physical-slice-dense-branch.pkl')
    fs=loads(operand.read_bytes())['factors']
    assert len(fs)==3
    base,table,_=fs[0]
    projections=[]
    for scopes,rows,_ in fs[1:]:
        common=tuple(w for w in base if w in scopes)
        projections.append((projection(base,common),Counter(map(projection(scopes,common),rows))))
    traffic=[min(freq[select(row)] for select,freq in projections) for row in sorted(table)]
    author_forecast={int(index):tuple(map(int,r)) for index,*r in (line.split('\t') for line in (tri/'forecast.tsv').read_text().splitlines())}
    n,total,shards,max_load=author_forecast[i]
    assert (n,total,shards)==(len(table),sum(traffic),2)
    expected=[sum(traffic[n*j//2:n*(j+1)//2]) for j in range(2)]
    assert max(expected)==max_load
    compare=(Path('arithmetic')/tag/'triangle-author-raw.out').read_text()
    assert f'input SHA256 {h}' in compare and raw(compare)==r
    receipts=findall(r'^independent author shard (\d+) row interval (\d+) (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)$',compare,M)
    assert len(receipts)==2
    for j,receipt in enumerate(receipts):
        ordinal,lo,hi,x,y,den=map(int,receipt)
        other=(d/f'shard-{j}.out').read_text()
        assert (ordinal,lo,hi,den)==(j,n*j//2,n*(j+1)//2,N)
        assert f'left row interval {lo} {hi} of {n} shard {j} of 2' in other
        assert raw(other)==(x,y) and scalar(other)==(Fraction(x,scale),Fraction(y,scale))
        actual_traffic=int(search(r'closure probes (\d+) raw',other)[1])
        product_line=search(r'^triangle closure (\d+) nonzero-support triples (\d+) bounded probes products (\d+) output rows 1$',other,M)
        triples,probes,products=map(int,product_line.groups())
        assert actual_traffic==probes==expected[j] and products==2*triples
    assert tuple(sum(int(receipt[k]) for receipt in receipts) for k in (3,4))==r
    return r,h,w,t

items=[]
leaves=[]
with Path('arithmetic-leaves.tsv').open('w') as f:
    print('kind','ordinal','inner','raw_real','raw_imag','normalized_real','normalized_imag','source_sha256','replay_products','elapsed_seconds',sep='\t',file=f)
    def leaf(kind,i,j,result):
        r,h,w,t=result
        leaves.append(result)
        print(kind,i,j,*r,*(Fraction(x,scale) for x in r),h,w,f'{t:.6f}',sep='\t',file=f)
        return r
    for i in sorted(scopes):
        if i<12:
            kind='direct'
            value=leaf(kind,i,'-',direct(f'direct-{i}',row,i,f'outer-{i}'))
        elif i in triangles:
            kind='triangle'
            value=leaf(kind,i,'-',triangle(i))
        else:
            kind='nested'
            d=four/str(i)
            assert lineage[f'outer-{i}'][1]==hash(row/f'slice{i}/join-cap-physical-slice-dense-branch.pkl')
            values=[leaf(kind,i,j,direct(f'nested-{i}-{j}',d,j,f'nested-{i}-{j}')) for j in range(16)]
            value=tuple(sum(x[k] for x in values) for k in (0,1))
        items.append((i,kind,value))
assert len(leaves)==54 and len(items)==24
roster={int(i):(coord,n) for i,coord,n in (r.split('\t') for r in Path('outer-roster.tsv').read_text().splitlines())}
with Path('accepted-24.tsv').open('w') as f:
    print('ordinal','coordinate','weighted_products','method','raw_real','raw_imag','normalized_real','normalized_imag',sep='\t',file=f)
    for i,kind,value in items:
        print(i,*roster[i],kind,*value,*(Fraction(x,scale) for x in value),sep='\t',file=f)
    total=tuple(sum(x[k] for _,_,x in items) for k in (0,1))
    print('subtotal','-','-','-',*total,*(Fraction(x,scale) for x in total),sep='\t',file=f)
print('PASS all 24 scoped signed terms and 20 independent author shard raw pairs')
print('scope outer2 subtotal',*(Fraction(x,scale) for x in total))
print('independent terminal total work',sum(row[2] for row in leaves),'summed wall seconds',round(sum(row[3] for row in leaves),6))
