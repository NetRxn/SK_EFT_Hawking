from ast import literal_eval
from collections import Counter
from hashlib import file_digest,sha256
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import loads
from re import M,search
from subprocess import check_output
from zipfile import ZipFile

base=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
def path(name): return Path((base/f'label0-{name}.path').read_text().strip())
row,tri,four,outer=(path(n) for n in ('row8','outer2-triangles','outer2-four-factor','roster'))
original='e7c97c008170ad43f0a4a27205d68143d8d6256a'
repo='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103'
locator=original+':docs/audits/2026-10-17-publication-substance-construction/L1_N16_C0_DENSE_BRANCH1_LABEL0_REUSE_R1.zip'
N=40512224221827380280140849737629696
parents=Path('source-receipts')
parents.mkdir(exist_ok=True)
archive_path=Path('pinned-reuse.zip')
if not archive_path.exists():
    archive_path.write_bytes(check_output(['git','-C',repo,'show',locator]))
blob=check_output(['git','-C',repo,'rev-parse',locator],text=True).strip()
assert check_output(['git','hash-object',str(archive_path)],text=True).strip()==blob
def digest(p):
    with p.open('rb') as f: return file_digest(f,'sha256').hexdigest()
with ZipFile(archive_path) as z:
    prefix='independent/raw-map/'
    receipt='inputs/accepted-source-and-outer.out'
    man=z.read(prefix+'review-manifest.sha256')
    checked={n:h for h,n in map(str.split,man.decode().splitlines())}
    data=z.read(prefix+receipt)
    assert sha256(data).hexdigest()==checked[receipt]
    (parents/'prior-raw-map-manifest.sha256').write_bytes(man)
    (parents/'accepted-source-and-outer.out').write_bytes(data)
    norm='inputs/accepted-normalization.out'
    val=z.read(prefix+norm)
    assert sha256(val).hexdigest()==checked[norm]
    (parents/'accepted-normalization.out').write_bytes(val)
    m=search(r'^PASS exact lifted case 2 49 89856 ([a-f0-9]{64}) ([a-f0-9]{64})$',data.decode(),M)
    assert m
    assert [digest(p) for p in (outer/'s2.pkl',outer/'label-s2-reduced-frontier.pkl')]==list(m.groups())
print('PASS prior accepted outer2 signed lift and reduction binding',blob,*m.groups(),flush=True)

def read(p):
    raw=p.read_bytes()
    state=loads(raw)
    assert prod(d for _,_,d in state['factors'])==N
    assert all(n==2 for n in Counter(w for axes,_,_ in state['factors'] for w in axes).values())
    assert state['physical_cut']==((('R',1,3,0,2,1),1),('complete-L-assignment',0))
    return state,sha256(raw).hexdigest()

def hist(a,b,axes):
    c=tuple(w for w in a[0] if w in b[0])
    li,ri=[[s.index(w) for w in c] for s in (a[0],b[0])]
    ci=[a[0].index(w) for w in axes]
    rhs=Counter(tuple(k[i] for i in ri) for k in b[1])
    h=Counter()
    for k in a[1]:
        if n:=rhs[tuple(k[i] for i in li)]:
            h[tuple(k[i] for i in ci)]+=n
    return h

def check_roster(label,parent,dir,number):
    fs=parent['factors']
    i,j=parent['rejected_pair']
    cuts,table=literal_eval((dir/'s0.roster').read_text())
    want=hist(fs[i],fs[j],cuts)
    assert len(want)==len(table)==number and want==dict(table) and sum(want.values())==parent['matched']
    for axis in cuts:
        assert sum(axis in f[0] for f in fs)==2
    order=sorted(want,key=lambda k:(want[k],k))
    output=Path(f'{label}-roster.tsv')
    with output.open('w') as stream:
        for i,key in enumerate(order):
            print(i,key,want[key],sep='\t',file=stream)
    print('PASS complete roster',label,cuts,len(table),sum(want.values()),max(want.values()),flush=True)
    for i,key in enumerate(order):
        live=dir/f's{i}.pkl'
        selected,digest_here=read(live)
        assert (dir/f's{i}.roster').read_bytes()==(dir/'s0.roster').read_bytes()
        fixed=dict(zip(cuts,key,strict=True))
        assert selected['conditioning']==parent.get('conditioning',[])+list(fixed.items())
        meta=lambda s:{k:v for k,v in s.items() if k not in ('factors','conditioning')}
        assert meta(selected)==meta(parent)
        for (a,left,d),(b,right,e) in zip(fs,selected['factors'],strict=True):
            assert d==e and b==tuple(w for w in a if w not in fixed)
            positions=tuple(a.index(w) for w in fixed if w in a)
            values=tuple(fixed[w] for w in a if w in fixed)
            external=tuple(a.index(w) for w in b)
            tests=[(a.index(w),v) for w,v in fixed.items() if w in a]
            restricted={tuple(k[j] for j in external):z for k,z in left.items() if all(k[j]==v for j,v in tests)}
            assert restricted==right
        print('PASS exact inverse lift',label,i,key,want[key],digest_here,flush=True)

source=outer/'slice2/row-cap-physical-slice-dense-branch.pkl'
state,root_sha=read(source)
assert state['rejected_pair']==(0,2) and state['matched']==4558848
assert state['used_before']==1807872 and len(state['factors'])==8
print('outer2 cap SHA256',root_sha,flush=True)
check_roster('outer',state,row,36)
for i in (22,24):
    operand=row/f'slice{i}/join-cap-physical-slice-dense-branch.pkl'
    state,src_sha=read(operand)
    actual,input_sha=read(four/str(i)/'partition-input.pkl')
    assert len(state['factors'])==4
    assert {k:v for k,v in actual.items() if k not in ('rejected_pair','matched')}==state
    costs=[]
    for a,b in combinations(range(4),2):
        if set(state['factors'][a][0])&set(state['factors'][b][0]):
            costs.append((sum(hist(state['factors'][a],state['factors'][b],()).values()),(a,b)))
    assert min(costs)==(actual['matched'],actual['rejected_pair'])==(9909504,(0,3))
    print('PASS exact cap-to-partition lineage',i,src_sha,input_sha,flush=True)
    check_roster(f'nested-{i}',actual,four/str(i),16)
