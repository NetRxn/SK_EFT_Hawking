from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest
from os import link
from pathlib import Path
from shutil import copyfile
from subprocess import run
from sys import executable
from time import perf_counter

base=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
def path(name): return Path((base/f'label0-{name}.path').read_text().strip())
row,four,outer=(path(n) for n in ('row8','outer2-four-factor','roster'))
root=Path('lineage').resolve()
root.mkdir()
def digest(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()
common=('checkpoint/quotient.py','contract-with-peer.py','peer_pair.py','reduce-label-frontier.py')
def command(cwd,argv,receipt,code):
    start=perf_counter()
    with receipt.open('xb') as log:
        p=run([executable,'-B','-u',*argv],cwd=cwd,stdout=log,stderr=log,timeout=180)
    assert p.returncode==code,(cwd,receipt,p.returncode,code)
    return perf_counter()-start

def frozen_pair(tag,source,index,reproduce_cap):
    cwd=root/tag
    cwd.mkdir()
    source_file=source/f'label-s{index}-reduced-frontier.pkl'
    live=source/f'slice{index}'
    for name in common:
        dest=cwd/name
        dest.parent.mkdir(exist_ok=True,parents=True)
        copyfile(source/name,dest)
    seconds=command(cwd,['reduce-label-frontier.py',str(source/f's{index}.pkl'),f's{index}'],cwd/'reduce.out',0)
    rebuilt=cwd/source_file.name
    assert digest(rebuilt)==digest(source_file)==digest(live/'dense-saturated-frontier.pkl')
    assert digest(cwd/'reduce.out')==digest(live/'reduce.out')
    cap_seconds=0
    cap_hash='-'
    if reproduce_cap:
        work=cwd/'work'
        work.mkdir()
        link(rebuilt,work/'dense-saturated-frontier.pkl')
        cap_seconds=command(work,['../contract-with-peer.py'],cwd/'contraction.out',2)
        assert digest(cwd/'contraction.out')==digest(live/'contraction.out')
        [expected]=live.glob('*cap-physical-slice-dense-branch.pkl')
        cap_hash=digest(work/expected.name)
        assert cap_hash==digest(expected)
    return tag,digest(rebuilt),cap_hash,f'{seconds:.6f}',f'{cap_seconds:.6f}'

caps={*range(12,20),22,23,24,25}
direct={*range(12),*caps}
jobs=[('origin-2',outer,2,True)]+[(f'outer-{i}',row,i,i in caps) for i in sorted(direct)]
jobs.extend((f'nested-{i}-{j}',four/str(i),j,False) for i in (22,24) for j in range(16))
with ThreadPoolExecutor(max_workers=3) as pool:
    for stage in pool.map(lambda job:frozen_pair(*job),jobs):
        print(*stage,sep='\t',flush=True)
