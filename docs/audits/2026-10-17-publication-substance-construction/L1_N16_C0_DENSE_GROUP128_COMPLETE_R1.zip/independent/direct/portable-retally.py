from collections import defaultdict
from csv import DictReader
from fractions import Fraction
from pathlib import Path
from re import M,search

def rows(path):
    with Path(path).open() as f:
        return list(DictReader(f,delimiter='\t'))

N=40512224221827380280140849737629696
scale=N*16*4**64
root=Path('author-receipts')
leaves=rows('arithmetic-leaves.tsv')
expected={*range(20),22,23,24,25}
triangles={*range(12,20),23,25}
ordinals=defaultdict(set)
weighted={int(i):(key,n) for i,key,n in (r.split('\t') for r in Path('outer-roster.tsv').read_text().splitlines())}
raw_totals=defaultdict(lambda:[0,0])
indices={tag:(kind,h) for tag,kind,h in map(str.split,Path('arithmetic-index.tsv').read_text().splitlines())}
assert list(weighted)==list(range(36)) and sum(int(n) for k,n in weighted.values())==4558848
for row in leaves:
    i=int(row['ordinal'])
    j=row['inner']
    kind=row['kind']
    assert j not in ordinals[i]
    ordinals[i].add(j)
    tag=f'{kind}-{i}' if j=='-' else f'{kind}-{i}-{j}'
    mode,h=indices[tag]
    assert h==row['source_sha256']
    text=(Path('arithmetic')/tag/(mode+'.out')).read_text()
    assert 'input SHA256 '+h in text
    raw=tuple(map(int,search(r'^(?:PASS )?raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',text,M).groups()))
    assert raw==(int(row['raw_real']),int(row['raw_imag']),N)
    real,imag=(Fraction(a,scale) for a in raw[:2])
    assert (real,imag)==(Fraction(row['normalized_real']),Fraction(row['normalized_imag']))
    if kind=='triangle':
        assert i in triangles and j=='-'
        # Each original shard has its own signed value in the manifest.
        recovered=[0,0]
        for s in range(2):
            author=(root/f'triangles/{i}/shard-{s}.out').read_text()
            m=search(r'^raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',author,M)
            a,b,d=map(int,m.groups())
            assert d==N
            replay=(Path('arithmetic')/tag/'triangle-author-raw.out').read_text()
            r=search(fr'^independent author shard {s} row interval \d+ \d+ raw (-?\d+) (-?\d+) factor denominator (\d+)$',replay,M)
            assert tuple(map(int,r.groups()))==(a,b,d)
            recovered[0]+=a
            recovered[1]+=b
        assert tuple(recovered)==raw[:2]
    else:
        d=(root/f'outer2/slice{i}' if kind=='direct' else root/f'nested-{i}/slice{j}')
        txt=(d/'contraction.out').read_text()
        a,b=search(r'^exact normalized (?:real )?(\S+)(?: imaginary (\S+))?',txt,M).groups()
        assert (real,imag)==(Fraction(a),Fraction(b or 0))
    for k in (0,1):
        raw_totals[i][k]+=raw[k]
assert len(leaves)==54 and set(raw_totals)==expected
for n,covered in ordinals.items():
    assert covered==({str(i) for i in range(16)} if n in (22,24) else {'-'})
outer=rows('accepted-24.tsv')
assert len(outer)==25
assert [int(row['ordinal']) for row in outer[:-1]]==sorted(expected)
for row in outer[:-1]:
    i=int(row['ordinal'])
    assert (row['coordinate'],row['weighted_products'])==weighted[i]
    value=tuple(map(int,(row['raw_real'],row['raw_imag'])))
    assert value==tuple(raw_totals[i])
    assert tuple(Fraction(k,scale) for k in value)==tuple(map(Fraction,(row['normalized_real'],row['normalized_imag'])))
total=tuple(sum(r[k] for r in raw_totals.values()) for k in (0,1))
subtotal=tuple(Fraction(k,scale) for k in total)
last=outer[-1]
assert last['ordinal']=='subtotal' and total==tuple(map(int,(last['raw_real'],last['raw_imag'])))
assert subtotal==tuple(map(Fraction,(last['normalized_real'],last['normalized_imag'])))
print('PASS portable scope 24 of 36 original outer2 coordinates',*subtotal)
