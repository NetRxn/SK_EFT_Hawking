from csv import DictReader
from fractions import Fraction
from pathlib import Path

def records(path):
    with Path(path).open() as stream: return list(DictReader(stream,delimiter='\t'))

roster={int(i):(key,int(n)) for i,key,n in (line.split('\t') for line in Path('outer-roster.tsv').read_text().splitlines())}
author=records('author-receipts/outer2/author-outer2-complete.tsv')
assert len(author)==37
for i,row in enumerate(author[:-1]):
    assert int(row['ordinal'])==i
    assert roster[i]==(row['coordinate'],int(row['projected']))
mine=records('accepted-24.tsv')
assert len(mine)==25 and mine[-1]['ordinal']=='subtotal'
scope=sorted({*range(20),22,23,24,25})
assert [int(row['ordinal']) for row in mine[:-1]]==scope
for row in mine[:-1]:
    i=int(row['ordinal'])
    their=author[i]
    assert tuple(map(Fraction,(their['real'],their['imaginary'])))==tuple(map(Fraction,(row['normalized_real'],row['normalized_imag'])))
print('PASS author exact arithmetic matches all 24 reviewed ordinals in complete 36-roster')
print('reviewed exact subtotal',mine[-1]['normalized_real'],mine[-1]['normalized_imag'])
