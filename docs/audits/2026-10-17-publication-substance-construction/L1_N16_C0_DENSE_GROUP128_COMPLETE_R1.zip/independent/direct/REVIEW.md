# Independent 24-term review of L0 outer ordinal 2

The exact signed subtotal of the 24 reviewed terms of group 128, branch 1, L assignment 0, outer ordinal 2 is `−34116270427375673691357/162259276829213363391578010288128 + 0i`. The reviewed ordinals are 0–19 and 22–25. Ordinals 20, 21, and 26–35 remain with their separately assigned reviewers.

The r1 continuity packet matched `e7c97c008170ad43f0a4a27205d68143d8d6256a`. The refreshed r2 packet matched `54c99ad9573dceaa52bee195632015262b69db98`. The committed raw-map evidence binds the original outer-2 value `G(0,5,1)=49`, its exact signed lift, and the reduced input. Byte replay from that input recovers the eight-factor cap after 1,807,872 products. Its pair (0,2) gives all 36 indexed `(G(0,0,2), J(1,4,2))` coordinates and 4,558,848 compatible pair products, with 312,576 in the largest coordinate. The independent inverse checks recover every selected raw signed row in the 36-member roster. Weighted counts are contraction work and carry no extra coefficient.

The review verified twelve direct terminals by independent signed sparse contraction and ten triangles by an alternate pivot. Each of the 20 author triangle shard intervals has an independent raw Gaussian replay as well as an exact projection-traffic check. The two four-factor caps at 22 and 24 admit the same 16-value `G(1,0,2)` split, with 9,909,504 products each. Their actual cap and partition sources, all 32 inverse lifts, and all 32 separate terminals were checked. The selected direct, triangle and nested leaves give 54 independent terminal contractions and 193,768,880 products. Summed terminal command duration was 206.131247 s under concurrent execution.

All 57 scoped reduction logs and checkpoints, including the original source reduction, passed byte replay. All 13 required caps also passed byte replay, which binds the original selected inputs to the terminal checkpoints. The 24 final values each match the author's completed ledger. Factor denominator `40512224221827380280140849737629696` and the common positive external factor `1/(16*4^64)` were applied once per signed raw numerator. The exact raw subtotal is `(-46376452787350212595364612427149828866267058594123429287406075904,0)`.

The compact manifest includes the independent ledgers and selected source receipts. The serialized source inventory records the large operands by original path and SHA-256. The original committed reference archive is identified in `pinned-archive.sha256`.

Run from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B portable-retally.py | cmp - portable-retally.out
python3 -B author-check.py | cmp - author-check.out
```
