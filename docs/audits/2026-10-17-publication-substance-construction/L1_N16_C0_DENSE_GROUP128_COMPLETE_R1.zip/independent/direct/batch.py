from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest
from pathlib import Path
from subprocess import run
from sys import executable
from time import perf_counter

base=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
def path(name): return Path((base/f'label0-{name}.path').read_text().strip())
row,tri,four=(path(name) for name in ('row8','outer2-triangles','outer2-four-factor'))
out=Path('arithmetic')
out.mkdir()
jobs=[(f'direct-{i}',i,row/f'label-s{i}-reduced-frontier.pkl',row/f'slice{i}/contraction.out') for i in range(12)]
jobs.extend((f'nested-{i}-{j}',j,four/str(i)/f'label-s{j}-reduced-frontier.pkl',four/str(i)/f'slice{j}/contraction.out') for i in (22,24) for j in range(16))
jobs.extend((f'triangle-{i}',i,tri/str(i)/'join-cap-input.pkl',None) for i in (*range(12,20),23,25))

def call(folder,program,args):
    start=perf_counter()
    with (folder/f'{program}.out').open('xb') as log:
        r=run([executable,'-B','-u',program+'.py',*args],stdout=log,stderr=log,check=False,timeout=180)
    seconds=perf_counter()-start
    with (folder/'timing.tsv').open('a') as out:
        print(program,r.returncode,f'{seconds:.6f}',sep='\t',file=out)
    return r.returncode

def review(job):
    tag,index,operand,receipt=job
    folder=out/tag
    folder.mkdir()
    with operand.open('rb') as f:
        digest=file_digest(f,'sha256').hexdigest()
    if receipt:
        args=[str(index),'0',str(operand),str(receipt)]
        for method in ('sparse-support-replay','sparse-replay'):
            if call(folder,method,args)==0:
                return tag,method,digest
        raise AssertionError(f'both independent schedules refused or disagreed: {tag}')
    assert call(folder,'triangle',[str(index),str(operand)])==0
    assert call(folder,'triangle-author-raw',[str(index),str(operand),str(index),'2','--author-shards'])==0
    return tag,'triangle',digest

with ThreadPoolExecutor(max_workers=4) as pool:
    for row in pool.map(review,jobs):
        print(*row,sep='\t',flush=True)
