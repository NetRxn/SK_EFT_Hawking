from ast import literal_eval
from fractions import Fraction as Q
from pathlib import Path
import re
import sys

base,tri,four,unsharded,case30,raw20,rawhigh=map(Path,sys.argv[1:])
D=40512224221827380280140849737629696
norm=D*16*4**64
triangles=set(range(12,20))|{23,25}
mapping={21:20,28:26,29:27,31:30,34:32,35:33}

def roster(parent):
    raw=(parent/'s0.roster').read_bytes()
    axes,cells=literal_eval(raw.decode())
    assert len(cells)==len(dict(cells)) and cells
    return axes,raw,sorted(cells,key=lambda x:(x[1],x[0]))
def child(parent,raw,i,k,n):
    assert (parent/f's{i}.roster').read_bytes()==raw
    d=parent/f'slice{i}'
    assert f'pilot {k!r} matched {n} stored rows ' in (d/'partition.out').read_text()
    return d,(d/'contraction.receipt').read_text().splitlines()[0]
def exact(d,state):
    assert state=='child_status 0'
    s=(d/'contraction.out').read_text().splitlines()[-1]
    return Q(re.fullmatch(r'exact normalized ([-\d/]+) peak rows \d+ matched products \d+',s)[1])
def sharded(i):
    forecast={int(r[0]):tuple(map(int,r[1:])) for r in (line.split() for line in (tri/'forecast.tsv').read_text().splitlines())}
    rows,probes,parts,worst=forecast[i]
    pos=traffic=signed=0
    for part in range(parts):
        trace=(tri/str(i)/f'shard-{part}.out').read_text()
        a,b,t,k,q=map(int,re.search(r'left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)',trace).groups())
        assert a==pos and b>a and t==rows and k==part and q==parts
        pos=b
        traffic+=int(re.search(r'triangle closure \d+ nonzero-support triples (\d+) bounded probes',trace)[1])
        re_num,im_num,den=map(int,re.search(r'raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)',trace).groups())
        assert im_num==0 and den==D
        signed+=re_num
    assert pos==rows and traffic==probes
    return Q(signed,norm)
def scalar_unsharded(i):
    if i==30:
        line=(case30/'close30-12.out').read_text().splitlines()[0]
        r,im,den,re_q,im_q=re.search(r' raw (-?\d+) (-?\d+) normalization (\d+) normalized ([-\d/]+) ([-\d/]+)$',line).groups()
        assert int(den)==norm
    else:
        text=(unsharded/str(i)/'split.out').read_text()
        r,im,re_q,im_q=re.search(rf'^EXACT full representative {i} \((-?\d+), (-?\d+)\) normalized ([-\d/]+) ([-\d/]+)$',text,re.M).groups()
    result=Q(int(r),norm)
    assert result==Q(re_q) and int(im)==Q(im_q)==0
    return result

axes,raw,terms=roster(base)
assert axes==(('G',0,0,2),('J',1,4,2))
assert len(terms)==36 and sum(n for _,n in terms)==4_558_848
result={}
print('ordinal','coordinate','projected','method','real','imaginary',sep='\t')
for i,(k,n) in enumerate(terms):
    here,state=child(base,raw,i,k,n)
    if i<12:
        q,method=exact(here,state),'direct'
    elif i in triangles:
        assert state=='child_status 2'
        q,method=sharded(i),'bounded triangle'
    elif i in (22,24):
        assert state=='child_status 2'
        d=four/str(i)
        _,r,sub=roster(d)
        assert len(sub)==16 and sum(m for _,m in sub)==9_909_504
        q=sum(exact(*child(d,r,j,t,m)) for j,(t,m) in enumerate(sub))
        method='16 exact slices'
    elif i in mapping:
        anchor=mapping[i]
        maps=raw20 if i==21 else rawhigh
        assert (maps/f'witness-select-{anchor}-{i}.pkl.gz').is_file()
        q,method=result[anchor],f'signed raw map from {anchor}'
    else:
        assert state=='child_status 2'
        q,method=scalar_unsharded(i),'exact primitive fiber factorization'
    assert (q*norm).denominator==1
    result[i]=q
    print(i,k,n,method,q,0,sep='\t')
print('total','','','',sum(result.values()),0,sep='\t')
