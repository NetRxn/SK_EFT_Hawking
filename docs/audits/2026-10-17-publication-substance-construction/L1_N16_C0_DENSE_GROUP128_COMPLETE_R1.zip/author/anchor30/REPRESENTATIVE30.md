# Full unsharded exact representative 30

Within group 128 first-index branch 1, original assignment 0, outer G(0,5,1)=49, the original (G(0,0,2),J(1,4,2))=(17,(3,)) coordinate has exact normalized scalar **-16446994911411972152769/324518553658426726783156020576256 + 0i**. Its raw Gaussian numerator is **(-11178731928312361537005199699652700150610845993287452932528144384, 0)**.

The final continuity packet is fresh at 54c99ad9573dceaa52bee195632015262b69db98, with the source archive and operand bytes unchanged. The original publication pin and full 36-coordinate roster, selected signed inverse lift, and cap ownership are in MAPS.md and verify.out. Replaying the original multicut, reduction, and contraction from the eight-factor outer cap produces the same row-cap file and receipt. The exact seven-factor input has SHA256 86ff1d0b2d60daf821a9cfbf50b410e9d6c96be45404979eea5a41b06b04ad16. The former generic run ended at pair (0,4) with 2,296,512 projected products.

## Exact changes of representation and measured route

Each factor is split across one partition of its original incident edges. Every left key belongs to the unique class of its primitive right-fiber vector. The left child stores the Gaussian scale for its key and class. The right child stores the primitive vector for that class. The fresh class edge has degrees one at each child and the same full finite domain at both. The original denominator is on the first child and the second has denominator one. Direct inverse contraction rebuilds every original row and exactly covers the zero complement. No original physical wire is conditioned or partitioned.

The seven split levels have 30, 48, 32, 45, 6, 216 and 8 class values, respectively. All seven inverse splits were repeated using reverse traversal and two separate integer accumulators. The 14-factor unsharded representation contains 29,649 stored rows. Ten guarded exact sparse joins consume 2,498,084 products and produce one four-factor operand in 16.61 s including the split search. Independent reverse traversal reproduces every coefficient of those ten joins and the exact four-factor operand table. The largest kept join output is 329,184 rows. Its minimum unquotiented next pair costs 22,394,880 products.

Two sweeps of exact Gaussian quotient fold merge sections in counts 168, 72 and 36 and lower the two smallest candidate pair costs to 2,965,248 and 3,569,184. Each primitive coefficient-to-scale recomposition is verified. All factors maintain their original denominator product. The exact alternative quotient code independently gives the same fold counts, arities, row counts and denominators. Some stored row coordinates differ after axis alignment. Each representation retains its own exact quotient proof and terminal scalar. Its exact scalar matches the main representation's two closures. An initial strict representation comparison is kept as a separate diagnostic.

Two complementary-pair closures accumulate the full scalar. Each computes an exact Gaussian dot product on the complement fibers when the pair's outward coordinate may match, without materializing a large intermediate. The two tested pair orientations agree on both raw components.

| Pair and complement | Pair products | Complement probes | Measured seconds | Peak process RSS bytes |
| --- | ---: | ---: | ---: | ---: |
| (0,1) × (2,3) | 2,965,248 | 24,463,296 | 5.813725 | 179,781,632 |
| (1,2) × (0,3) | 3,569,184 | 9,112,032 | 3.540976 | 196,984,832 |

The first orientation's initial 20-million-probe guard refused at 20,000,061 probes after 2,572,163 pair products. The terminal rerun uses a 30-million-probe guard. The second orientation stays below the former guard. Both keep the pair-visit limit of 8 million and cache at most 120,000 complement dots. Timings refer to local runs and exclude from the terminal pairs the earlier original stage and exact rewrites.

The common factor denominator is 40512224221827380280140849737629696, with the original positive external factor 1/(16×4^64). Both closures evaluate the same full coordinate. Its contribution has unit weight. The exact map 30→31 independently supports reuse for the separate original coordinate (34,(3,)). The five top maps and the secondary nested26 package carry their own scope and manifests. This package claims only representative 30 and its exact certified transfer.

## Rerun

Run source-route30.py in a fresh copy to bind the original seven-factor refusal. Run split30.py, fold30.py, close30.py 1 2 and close30.py 0 1 from the reviewer directory with the pinned raw operands. Run verify30.py for the separate inverse splits, all ten reversed joins and the alternative Gaussian quotient receipt. The author path used no additional physical slicing.
