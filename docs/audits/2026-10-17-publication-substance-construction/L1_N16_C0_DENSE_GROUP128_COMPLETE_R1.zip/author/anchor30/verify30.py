from split30 import *
from fractions import Fraction
from time import perf_counter
from shutil import copyfile

P=Path('unsharded-split30.pkl')
Q=Path('unsharded-pilot30.pkl')
Z=Path('unsharded-pilot30-fold.pkl')
origin=R/'slice30/row-cap-physical-slice-dense-branch.pkl'
t0=perf_counter()
p,q=map(read,(P,Q))
s=read(origin)
assert p['split_source_sha256']==q['split_source_sha256']==sha(origin)
assert p['physical_cut']==q['physical_cut']==s['physical_cut']
stages=dict(zip(p['factor_labels'],p['factors'],strict=True))

def reverse(F,G):
    A,X,d=F;B,Y,e=G
    both=tuple(w for w in B if w in A)
    px=pos(A,both);py=pos(B,both)
    sa=tuple(w for w in A if w not in both); sb=tuple(w for w in B if w not in both)
    ix=pos(A,sa); iy=pos(B,sb)
    buckets=defaultdict(list)
    for key,value in Y.items():
        buckets[pull(key,py)].append((pull(key,iy),value))
    u=defaultdict(int);v=defaultdict(int)
    count=0
    for row,(x,y) in X.items():
        front=pull(row,ix)
        for other,(a,b) in buckets[pull(row,px)]:
            count+=1
            k=front+other
            u[k]+=x*a-y*b
            v[k]+=x*b+y*a
    ans={k:(x,v[k]) for k,x in u.items() if x or v[k]}
    return (sa+sb,ans,d*e),count

for i,src in enumerate(s['factors']):
    out,count=reverse(stages[i,0],stages[i,1])
    a,X,d=out;b,Y,e=src
    assert set(a)==set(b) and d==e and {pull(k,pos(a,b)):z for k,z in X.items()}==Y
    print('independent complete split recomposition',i,count,len(Y),d,flush=True)
for i,j,k,ct,rows,width in q['trace']:
    out,n=reverse(stages.pop(i),stages.pop(j))
    assert (n,len(out[1]),len(out[0]))==(ct,rows,width)
    stages[k]=out
    print('independent reverse arithmetic join',i,j,k,n,rows,width,out[2],flush=True)
assert tuple(stages)==q['factor_labels'] and list(stages.values())==q['factors']
assert len(stages)==4 and len(q['trace'])==10
target=read(Z)
qcode=R/'checkpoint/quotient.py'
copyfile(qcode,'quotient-source.py')
src=qcode.read_text().split('\nlocal_test()\n',1)[0]
scope={}
exec(src,scope)
scope['local_test']()
fold=scope['quotient']
F=list(stages.values())
degree=Counter(w for a,_,_ in F for w in a)
assert set(degree.values())=={2}
for sweep in range(2):
    for i,j in combinations(range(4),2):
        A,B=F[i],F[j]
        a,b,m=fold(A,B,degree)
        b,a,n=fold(b,a,degree)
        F[i],F[j]=a,b
        if m+n:print('alternate exact folded pair',sweep,i,j,m,n,flush=True)
assert prod(d for _,_,d in F)==N
print('exact authored alternate quotient and retention dimensions',[(len(a),len(t),d) for a,t,d in F],flush=True)
print('independent quotient dimensions',[(len(a),len(t),d) for a,t,d in target['factors']],flush=True)
scope_reindexed=[]
for (a,X,d),(b,Y,e) in zip(F,target['factors'],strict=True):
    assert d==e and set(a)==set(b)
    reordered={pull(k,pos(a,b)):z for k,z in X.items()}
    scope_reindexed.append(reordered==Y)
print('alternate tables equal after aligning named axes',scope_reindexed,flush=True)
from close30 import closure
assessed=closure(F,(1,2),(0,3))
claimed=(-11178731928312361537005199699652700150610845993287452932528144384,0)
assert assessed[:2]==claimed
print('signed split and ten independent join tables agree',sha(P),sha(Q),flush=True)
print('independent quotient',sha(Z),'alternate supported quotient gives independently checked same raw scalar',*assessed,
      'elapsed seconds',round(perf_counter()-t0,6),flush=True)

