from shape import *

from ast import literal_eval
from collections import defaultdict
from math import prod
from gzip import decompress
from pickle import loads
from time import perf_counter
from sys import argv

D=40512224221827380280140849737629696

def lift(parent,selected,fixed):
 for (a,X,d),(b,Y,e) in zip(parent,selected,strict=True):
  assert d==e and b==tuple(w for w in a if w not in fixed)
  check=tuple((p,fixed[w]) for p,w in enumerate(a) if w in fixed)
  if not check:
   assert a==b and X==Y
   continue
  want={r:z for r,z in X.items() if all(r[k]==v for k,v in check)}
  actual={}
  for r,z in Y.items():
   key=list(r)
   for k,v in check:key.insert(k,v)
   k=tuple(key)
   assert k not in actual
   actual[k]=z
  assert actual==want

def certify(parent_path,root,indices):
 parent=read(parent_path)
 F=parent['factors']
 assert set(Counter(w for a,_,_ in F for w in a).values())=={2} and prod(d for _,_,d in F)==D
 axes,roster=literal_eval((root/'s0.roster').read_text())
 l,r=parent['rejected_pair']
 a,X,_=F[l]; b,Y,_=F[r]
 shared=tuple(w for w in b if w in a)
 assert set(axes)<=set(a)-set(shared)
 xi=tuple(a.index(w) for w in shared)
 yi=tuple(b.index(w) for w in shared)
 xx=tuple(a.index(w) for w in axes)
 rhs=Counter(tuple(k[p] for p in yi) for k in Y)
 tally=Counter()
 for k in X:
  n=rhs[tuple(k[p] for p in xi)]
  if n:tally[tuple(k[p] for p in xx)]+=n
 assert len(roster)==len(dict(roster)) and tally==dict(roster)
 assert sum(tally.values())==parent['matched']
 ordered=sorted(tally,key=lambda v:(tally[v],v))
 print('exact complete roster',parent_path,sha(parent_path),axes,len(tally),sum(tally.values()),flush=True)
 for n in indices:
  child=root/f's{n}.pkl'
  o=read(child)
  vals=dict(zip(axes,ordered[n],strict=True))
  assert o['physical_cut']==parent['physical_cut']
  assert o['conditioning']==parent.get('conditioning',[])+list(vals.items())
  assert (root/f's{n}.roster').read_bytes()==(root/'s0.roster').read_bytes()
  lift(F,o['factors'],vals)
  print('exact signed raw inverse lift',n,ordered[n],tally[ordered[n]],sha(child),flush=True)
 return ordered,tally

def actual_edges(F):
 incidence=defaultdict(list)
 for i,(ax,_,d) in enumerate(F):
  assert d>0 and len(ax)==len(set(ax))
  for w in ax:incidence[w].append(i)
 edges=defaultdict(set)
 for w,v in incidence.items():
  assert len(v)==2
  edges[tuple(v)].add(w)
 return dict(edges)

def verify(l,r,witness):
 left,_=factors('select',l)
 right,_=factors('select',r)
 perm,old,new,maps,flip=loads(decompress(witness.read_bytes()))
 assert perm==tuple(range(len(left))) and len(left)==len(right)
 assert set(old)==set(new)==set(maps)==set(flip)
 for graph,scopes in ((left,old),(right,new)):
  assert prod(d for _,_,d in graph)==D
  assert actual_edges(graph)=={e:set(v) for e,v in scopes.items()}
 for e,m in maps.items():
  assert len(m)==len(set(m.values()))
  assert set(flip[e])<=set(m) and len(flip[e])==len(set(flip[e]))
 lhs=defaultdict(dict); rhs=defaultdict(dict)
 rows=neg=0
 for i,((a,X,d),(b,Y,e)) in enumerate(zip(left,right,strict=True)):
  assert d==e and len(X)==len(Y)
  ports=[]
  for edge,M in maps.items():
   if i not in edge:continue
   aa=tuple(a.index(w) for w in old[edge])
   bb=tuple(b.index(w) for w in new[edge])
   k=tuple(flip[edge])
   ports.append((edge,aa,bb,M,set(k)))
  got={}
  for row,z in X.items():
   key=[None]*len(b)
   sigma=1
   for edge,aa,bb,M,signs in ports:
    p=tuple(row[j] for j in aa)
    q=M[p]
    for j,v in zip(bb,q,strict=True):
     assert key[j] is None
     key[j]=v
    if p in signs:sigma=-sigma
   y=tuple(key)
   assert None not in y and y not in got and all(type(v) is int for v in z) and any(z)
   got[y]=tuple(sigma*v for v in z)
   rows+=1
   neg+=sigma<0
  assert got==Y
  for e,aa,bb,M,signs in ports:
   lhs[e][i]={tuple(row[j] for j in aa) for row in X}
   rhs[e][i]={tuple(row[j] for j in bb) for row in Y}
 changed=amb=0
 for e,M in maps.items():
  i,j=e
  assert set(M)==lhs[e][i]|lhs[e][j] and set(M.values())==rhs[e][i]|rhs[e][j]
  for n in e:assert {M[k] for k in lhs[e][n]}==rhs[e][n]
  changed+=sum(k!=v for k,v in M.items())
  assert old[e]==new[e]
  for i,_ in enumerate(old[e]):
   f=defaultdict(set)
   for k,v in M.items():f[k[i]].add(v[i])
   amb+=any(len(s)>1 for s in f.values())
 assert rows==sum(len(rows) for _,rows,_ in left)
 return len(left),len(maps),sum(map(len,maps.values())),changed,amb,sum(map(len,flip.values())),rows,neg



if __name__=='__main__':
    parent=Path((A/'label0-row8.path').read_text().strip())/'slice26/row-cap-physical-slice-dense-branch.pkl'
    assert read(parent)['matched']==2037312
    order,counts=certify(parent,R,range(8))
    assert order==[(20,0),(20,1),(40,0),(40,1),(24,0),(24,1),(36,0),(36,1)]
    print('left','right','factors','edges','values','changed_values','noncomponentwise_wires','negative_values','rows','flipped_rows','left_sha256','right_sha256','witness_sha256','seconds',sep='\t',flush=True)
    for l,r in ((0,1),(0,2),(0,3),(4,5),(4,6),(4,7)):
        t=perf_counter()
        assert counts[order[l]]==counts[order[r]]
        w=Path(f'witness-select-{l}-{r}.pkl.gz')
        results=verify(l,r,w)
        assert results[0:2]==(7,17)
        print(l,r,*results,sha(R/f's{l}.pkl'),sha(R/f's{r}.pkl'),sha(w),round(perf_counter()-t,6),sep='\t',flush=True)
