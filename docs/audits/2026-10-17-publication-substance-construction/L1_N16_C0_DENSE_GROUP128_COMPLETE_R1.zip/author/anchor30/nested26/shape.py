from pathlib import Path
from pickle import load
from collections import Counter,defaultdict
from itertools import combinations
from hashlib import file_digest
A=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
R=Path((A/'label0-outer2-row7-cohort.path').read_text().strip())/'26'
def read(p):
 with p.open('rb') as f:return load(f)
def sha(p):
 with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def factors(stage,c):
 path={'cap':R/f'slice{c}/row-cap-physical-slice-dense-branch.pkl',
       'reduce':R/f'label-s{c}-reduced-frontier.pkl',
       'select':R/f's{c}.pkl'}[stage]
 return read(path)['factors'],sha(path)
def rshape(A,B):
 out=[]
 for i,((a,X,d),(b,Y,e)) in enumerate(zip(A,B,strict=True)):
  if set(a)!=set(b):out.append((i,'different axes',set(a)^set(b)));continue
  sigma=tuple(b.index(w) for w in a)
  if a!=b:Y={tuple(row[p] for p in sigma):z for row,z in Y.items()}
  common=X.keys()&Y.keys()
  coeff=sum(X[k]==Y[k] for k in common)
  u=sum(X[k]==tuple(-x for x in Y[k]) for k in common)
  out.append((i,len(a),len(X),len(Y),len(common),coeff,u, d==e))
 return out
if __name__=='__main__':
 for st in ('cap','reduce','select'):
  X,h=factors(st,2)
  for c in (3,4,5):
   Y,hh=factors(st,c)
   print(st,c,h,hh,rshape(X,Y),flush=True)
