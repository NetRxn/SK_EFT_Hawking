from shape import *
from shutil import copyfile
from subprocess import run,STDOUT
from sys import executable
from time import perf_counter

w=Path('source-route30')
(w/'checkpoint').mkdir(parents=True)
for f in ('reduce-label-frontier.py','contract-with-peer.py','peer_pair.py','checkpoint/quotient.py','exact-multicut.py'):
    copyfile(R/f,w/f)
p=Path((A/'label0-roster.path').read_text().strip())/'slice2/row-cap-physical-slice-dense-branch.pkl'
def exec_check(py,args,out,rc):
    start=perf_counter()
    with (w/out).open('xb') as f:
        result=run([executable,'-B',py,*args],cwd=w,stdout=f,stderr=STDOUT,timeout=120)
    assert result.returncode==rc
    assert sha(w/out)==sha(R/'slice30'/out)
    print('source stage',py,out,'status',rc,'seconds',round(perf_counter()-start,6),flush=True)
exec_check('exact-multicut.py',[str(p),'s30.pkl','30'],'partition.out',0)
for n in ('s30.pkl','s30.roster'):assert sha(w/n)==sha(R/n)
exec_check('reduce-label-frontier.py',['s30.pkl','s30'],'reduce.out',0)
assert sha(w/'label-s30-reduced-frontier.pkl')==sha(R/'label-s30-reduced-frontier.pkl')
(w/'dense-saturated-frontier.pkl').symlink_to((w/'label-s30-reduced-frontier.pkl').resolve())
exec_check('contract-with-peer.py',[],'contraction.out',2)
name='row-cap-physical-slice-dense-branch.pkl'
assert sha(w/name)==sha(R/'slice30'/name)
print('complete selected source to seven-factor refusal byte replay',sha(w/name),flush=True)
