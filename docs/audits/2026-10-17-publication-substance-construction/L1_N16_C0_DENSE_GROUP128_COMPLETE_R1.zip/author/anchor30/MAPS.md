# Exact high-child maps within assignment 0, outer cut 2

The final continuity packet is fresh at 54c99ad9573dceaa52bee195632015262b69db98. The original reuse archive matches its e7c97c008170ad43f0a4a27205d68143d8d6256a bytes and all pinned operands pass readback. At that original checkpoint, the committed assignment-0 reuse archive pins original outer value G(0,5,1)=49, its signed selection, and its eight-factor row cap. Independent histograms recover all 36 next (G(0,0,2), J(1,4,2)) coordinates and 4,558,848 matched products. The raw selected rows and coefficients for each of high children 26–35 inverse-lift onto the appropriate rows of that common parent.

| Donor | Target | Donor original coordinate | Target original coordinate | Products per child | Signed rows per operand | Edge values |
| --- | --- | --- | --- | ---: | ---: | ---: |
| 26 | 28 | (24,(1,)) | (36,(1,)) | 207,360 | 503,944 | 817 |
| 27 | 29 | (24,(2,)) | (36,(2,)) | 207,360 | 512,264 | 817 |
| 30 | 31 | (17,(3,)) | (34,(3,)) | 208,384 | 454,026 | 815 |
| 32 | 34 | (17,(1,)) | (34,(1,)) | 312,576 | 504,146 | 817 |
| 33 | 35 | (17,(2,)) | (34,(2,)) | 312,576 | 512,466 | 817 |

In each exact map, all eight factor positions are fixed while edge values are reindexed. The 21 actual edge bundles have degree two. The complete source and target local domains are bijective at both endpoints. Every source coefficient pair reconstructs the exact target row. The witness covers zero complement by complete support bijection. All individual denominators agree. Each witness has 264 changed bundle values and zero edge charges or row sign flips. The eight-factor denominator product is unchanged at 40512224221827380280140849737629696. The already adopted external normalization enters once, with unit weight per distinct cut coordinate.

The high selected scopes split into five tested exact pairs. A donor's accepted terminal scalar may be used once for its target and once for its own original coordinate. The raw input row counts differ across the five donor classes, so this raw same-arity factor bijection does not identify those classes. No high-child numerical scalar is asserted in this map package.

Run verify.py to regenerate the source, roster, inverse-lift, full-row and witness hash receipts. Reproduce individual witness search in scratch with constraints.py select DONOR TARGET. The searches use exact ray marginals and direct candidate row/sign verification. All five frozen search logs and complete witnesses are included.
