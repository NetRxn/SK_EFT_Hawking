from shape import *
from math import gcd,prod
from itertools import combinations
from time import perf_counter
from pickle import dump
from sys import argv

N=40512224221827380280140849737629696
EXPECTED='619f63bc4b2e997b4efd2ac8c10d9fdac1d1a0e1ff5b4ce06319d06df9eeab30'
UNIT=((1,0),(0,1),(-1,0),(0,-1))
def mul(p,q):
    a,b=p; x,y=q
    return a*x-b*y,a*y+b*x
def primitive(vals):
    c=gcd(*(v for (x,y) in vals for v in (x,y)))
    unit=max(UNIT,key=lambda u:mul(next(a for a in vals if any(a)),u))
    vals_new=tuple(mul((x//c,y//c),unit) for x,y in vals)
    scale=(c*unit[0],-c*unit[1])
    assert c>0
    return vals_new,scale
def pos(A,scope):return tuple(A.index(w) for w in scope)
def pull(row,ii):return tuple(row[i] for i in ii)
def split(raw,i,left,verify=False):
    ax,X,d=raw
    right=tuple(w for w in ax if w not in left)
    xp=pos(ax,left); yp=pos(ax,right)
    bins=defaultdict(list)
    for r,z in X.items():bins[pull(r,xp)].append((pull(r,yp),z))
    seen={}
    A={};B={}
    for r,group in bins.items():
        group.sort()
        ys,zs=zip(*group)
        new,scale=primitive(zs)
        signature=(ys,new)
        n=len(seen)
        code=seen.setdefault(signature,n)
        A[r+(code,)]=scale
        if code==n:
            for row,z in zip(ys,new,strict=True):B[(code,)+row]=z
    wire=('exact-fiber-split',i)
    if verify:
        joint=left+right
        ix=pos(joint,ax)
        reg=defaultdict(list)
        for k,z in B.items():reg[k[0]].append((k[1:],z))
        actual={}
        for k,z in A.items():
            for t,e in reg[k[-1]]:
                target=pull(k[:-1]+t,ix)
                assert target not in actual
                actual[target]=mul(z,e)
        assert actual==X
        assert {r[-1] for r in A}=={r[0] for r in B}==set(range(len(seen)))
    return (left+(wire,),A,d),((wire,)+right,B,1),len(seen)
def compatible(A,B):
    a,X,_=A;b,Y,_=B
    shared=tuple(w for w in a if w in b)
    if not shared:return None
    px=pos(a,shared);py=pos(b,shared)
    u=Counter(pull(k,px) for k in X)
    v=Counter(pull(k,py) for k in Y)
    return sum(n*v[k] for k,n in u.items()),len(set(a)^set(b)),len(u.keys()&v.keys())
def score_split(F,i):
    a,X,d=F[i]
    peer={j:tuple(w for w in a if w in b) for j,(b,_,_) in enumerate(F) if j!=i and set(a)&set(b)}
    I=tuple(peer)
    best=None
    for u in range(1,len(I)):
        for js in combinations(I,u):
            if u==len(I)//2+1 and len(I)%2: pass
            S=set(w for j in js for w in peer[j])
            K=tuple(w for w in a if w in S)
            X1,X2,n=split(F[i],i,K)
            old=len(X); new=len(X1[1])+len(X2[1])
            comp=(new,max(len(X1[1]),len(X2[1])),n,js,K)
            best=min(best,comp) if best is not None else comp
    return best
def joined(A,B,cap):
    a,X,d=A;b,Y,e=B
    common=tuple(w for w in a if w in b)
    p=pos(a,common);q=pos(b,common)
    x=tuple(i for i,w in enumerate(a) if w not in common)
    y=tuple(i for i,w in enumerate(b) if w not in common)
    axes=pull(a,x)+pull(b,y)
    blocks=defaultdict(list)
    for k,z in X.items():blocks[pull(k,p)].append((pull(k,x),z))
    rows={};hit=0
    for k,z in Y.items():
        tail=pull(k,y)
        for head,w in blocks[pull(k,q)]:
            hit+=1
            assert hit<=cap
            t=head+tail
            u,v=mul(z,w)
            m,n=rows.get(t,(0,0))
            if u+m or v+n:rows[t]=(u+m,v+n)
            else:rows.pop(t,None)
            if len(rows)>500000:return None,hit
    return (axes,rows,d*e),hit

if __name__=='__main__':
    t=perf_counter()
    case=int(argv[1])
    expected=argv[2]
    p=R/f'slice{case}/row-cap-physical-slice-dense-branch.pkl'
    h=sha(p);assert h==expected
    S=read(p);F=S['factors']
    assert S['matched']==int(argv[3]) and S['rejected_pair']==tuple(map(int,argv[4:6]))
    assert prod(d for _,_,d in F)==N and len(F)==7
    jobs=range(7)
    results={}
    for i in jobs:
        best=score_split(F,i)
        results[i]=best
        print('best local split',i,len(F[i][1]),best[:4],'time elapsed',round(perf_counter()-t,6),flush=True)
    if len(results)!=len(F):raise SystemExit(0)
    labels={}
    for i,f in enumerate(F):
        rows=len(f[1])
        if results[i][0]*2<rows:
            a,b,n=split(f,i,results[i][-1],True)
            labels[i,0]=a;labels[i,1]=b
            print('exact signed split inverse',i,len(a[1]),len(b[1]),n,'D pair',a[2],b[2],flush=True)
        else:labels[i,0]=f
    assert prod(d for _,_,d in labels.values())==N
    assert set(Counter(w for ax,_,_ in labels.values() for w in ax).values())=={2}
    print('whole unsharded split state',len(labels),'factors',sum(len(r) for _,r,_ in labels.values()),'rows',h,flush=True)
    # No projection on any original physical wire. Every decision is over the complete representative.
    finish={**S,'factors':list(labels.values()),'factor_labels':tuple(labels),'split_source_sha256':h}
    for a in ('rejected_pair','matched'):finish.pop(a)
    with Path('unsharded-split.pkl').open('xb') as f:dump(finish,f,protocol=5)
    C={}
    for i,j in combinations(labels,2):
        score=compatible(labels[i],labels[j])
        if score:C[i,j]=score
    print('unsharded exact top pair counts',sorted((v,i,j) for (i,j),v in C.items())[:20],flush=True)
    refused=set()
    work=0
    record=[]
    for step in range(20):
        if len(labels)==1:break
        entries=[(ct*(w+1)**2,ct,w,i,j) for (i,j),(ct,w,_) in C.items() if i[0]!=j[0] and
                 (i,j) not in refused and 0<ct<=8000000 and ct+work<=20000000]
        if not entries:break
        _,ct,w,i,j=min(entries)
        result,actual=joined(labels[i],labels[j],ct)
        if result is None:
            refused.add((i,j));work+=actual
            print('row cap',i,j,'width',w,'forecast',ct,'actual visited',actual,flush=True)
            continue
        assert ct==actual and len(result[0])==w
        work+=actual
        name=(step+7,0)
        labels.pop(i);labels.pop(j)
        C={key:z for key,z in C.items() if i not in key and j not in key}
        for k,R0 in labels.items():
            scr=compatible(R0,result)
            if scr:C[k,name]=scr
        labels[name]=result
        record.append((i,j,name,actual,len(result[1]),w))
        print('exact guarded unsharded join',record[-1],'remaining',len(labels),'cumulative visited',work,'seconds',perf_counter()-t,flush=True)
        if perf_counter()-t>180:break
    exact=(next(iter(labels.values())) if len(labels)==1 else None)
    if exact:
        assert exact[0]==() and exact[2]==N
        z=exact[1].get((),(0,0))
        from fractions import Fraction
        print('EXACT full representative',case,z,'normalized',*[Fraction(n,N*16*4**64) for n in z],flush=True)
    else:
        print('residual factor count',len(labels),'verified per-stage trace',record,'next exact forecasts',sorted((v,i,j) for (i,j),v in C.items())[:15],flush=True)
    with Path('unsharded-pilot.pkl').open('xb') as f:
        dump({**finish,'factors':list(labels.values()),'factor_labels':tuple(labels),'trace':record},f,protocol=5)
    print('elapsed total',round(perf_counter()-t,6),flush=True)
