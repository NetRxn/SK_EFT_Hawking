from fractions import Fraction as F
from itertools import product
from src.core.formulas import original_spin4_link, original_plaquette, original_quaternion_haar_moment
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, QComplex, Symbol, matrix_multiply, matrix_dagger,
)
reg=OriginalRegulator(temporal_axis=0)
x=(0,0,0,0); y=reg.step(x,1)[0]; X=reg.step(x,0)[0]; Y=reg.step(y,0)[0]
gamma=reg.gamma
O={(a,b):matrix_multiply(matrix_multiply(gamma[a],gamma[b]),reg.gamma5)
   for a,b in product(range(4),repeat=2) if a!=b}
def trace(H,O):
    return sum((H[i][j]*O[j][i] for i,j in product(range(4),repeat=2)),Polynomial())
def val(p):
    if not p:return QComplex()
    (key,c),=p.terms
    assert not key
    return c
def fixed(l,r):return original_spin4_link(l,r)
units=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),
       (F(1,2),)*4,(F(3,5),0,F(4,5),0))
sym={}
for v in (x,y):
    sym[v,0]=original_spin4_link(*[
        tuple(Polynomial.variable(Symbol("q",(v,0,chi,i))) for i in range(4))
        for chi in ("L","R")])
moment=original_quaternion_haar_moment((2,0,0,0))**2
for k,offset in enumerate((0,1,3)):
    if not k:
        A=B=C=D=fixed(units[0],units[0])
    elif k==1:
        A=fixed(units[5],units[4]);B=C=D=fixed(units[0],units[0])
    else:
        A,B,C,D=[fixed(units[(t+offset)%6],units[(2*t+offset)%6]) for t in range(4)]
    links={**sym,(x,1):A,(X,1):B,(y,1):C,(Y,1):D}
    h=original_plaquette(reg,x,0,1,links); j=original_plaquette(reg,y,0,1,links)
    p,q=trace(h,O[0,1]),trace(j,O[0,1])
    ps,qs=dict(p.terms),dict(q.terms)
    for key in set(ps)|set(qs):
        assert len(key)==2 and {s.index[0] for s in key}=={x,y}
        assert len({s.index[2] for s in key})==1
    direct=sum((c*qs[key] for key,c in ps.items() if key in qs),QComplex())*moment
    schur=QComplex()
    Ar,Cr=matrix_dagger(A),matrix_dagger(C)
    BD=matrix_multiply(B,D)
    for block in ((0,1),(2,3)):
        character=sum((val(BD[i][i]) for i in block),QComplex())
        pair=QComplex()
        for a,b,g,d in product(block,repeat=4):
            pair+=val(O[0,1][b][a])*val(O[0,1][d][g])*val(Ar[a][d])*val(Cr[g][b])
        schur+=pair*character*F(1,4)
    assert direct==schur
    if not k:assert direct==QComplex(-2)
    print("conditional two-root original F01 first powers",k,direct.storage,
          "polynomial supports",len(ps),len(qs),"matched keys",len(ps.keys()&qs.keys()),
          "Schur equals raw Haar")

# Verify a half-turn around the normal to two imaginary directions
# flips all antisymmetric original components at each rooted holonomy.
g=fixed(units[2],units[2])
for q in (fixed(units[1],units[3]),fixed(units[3],units[1])):
    reflected=matrix_multiply(matrix_multiply(g,q),matrix_dagger(g))
    assert all(trace(reflected,o)==-trace(q,o) for o in O.values())
print("curvature-only root common half-turn flips both vector rosters")

for m in range(5):
    shapes=[(p,q) for p in range(m+1) for q in range(m+1-p) if (m-p-q)%2==0]
    print("degree",m,"irreps",len(shapes),"matrix components",sum(((p+1)*(q+1))**2 for p,q in shapes),
          "maximum irrep dimension",max((p+1)*(q+1) for p,q in shapes))
