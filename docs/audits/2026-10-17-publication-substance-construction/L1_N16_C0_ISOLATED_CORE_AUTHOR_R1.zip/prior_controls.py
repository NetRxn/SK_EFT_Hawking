from fractions import Fraction as F
from coframe import run
from family import excluded, core_factor
from core import decode, strip
A=run(279173922820)
B=run(289913962500)
assert A==F(3598425,8192)**2 and B==F(2811130160625,134217728)
print("previous leaf controls reproduced by new site join",A,B)
a,b=8935713546370,8935713546370
a,b=decode(a),decode(b)
ca,cb=strip(a)[0],strip(b)[0]
assert not excluded(a,b,ca,cb)
assert core_factor(ca,cb)==F(104978,6561)**4
print("previous signed uniform curvature scale retained",core_factor(ca,cb))
