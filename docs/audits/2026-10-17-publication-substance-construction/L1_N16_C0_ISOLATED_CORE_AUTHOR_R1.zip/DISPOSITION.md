# Author evidence pending independent review

The exact isolated-core pilot, six-orbit subtotal, and 81-orbit zero table are frozen for replay. Full c0 remains open.
