# Residual temporal-core census and exact isolated-edge signed family

The primary packet `l1-c0-residual-core-author-r1.json` checked fresh
at `27012c18fa374e8341e124b510abbedeedb18d29`. The previous degree
and coframe-Q3 packages were reverified by their frozen manifests
and used read-only. In particular this result depends on their
original cut, geometric support, exact leaf elimination and signed
coframe source conventions. No tracked file, prior package,
notebook, controller or Lean slot was modified.

In the 11,889 remaining orbits of the complete n=16 temporal
A-only/B-only block, this work proves 81 further exact zeros and
evaluates six further positive orbits with shared original Haar.
The full block and full c0 remain open.

## Residual graph census and exact zeros

At fixed geometric occupancy, a temporal edge carries its two
rooted curvature multiplicities. The already derived single-root
leaf rule integrates one original connector anchor exactly, giving
the corresponding isotropic Haar moment with no curvature link
dependence. Its surviving coframe polynomial is retained.
The residual graphs are computed after removing such leaves
in a deterministic order. The package retains all orbit weights.

The most common individual residual connected component is an
isolated edge, with 8,142 appearances across all layers and
representatives. Four-cycles appear 6,328 times. The most common
large shape has eight vertices and ten edges, with 3,757
appearances. The complete paired census is in `core.out`.
There are **816** residual orbits with no connected component
other than isolated edges, covering **67,590** labeled occupations.
Their isolated components have rooted powers (1,3), (2,2),
(2,4) or (4,4). There are 41 residual orbits where every remaining
curvature spatial edge is disjoint from the coframe edges in
both layers, covering 2,694 labels.

A stronger exact zero test applies even with curvature and
coframe overlap elsewhere. At a vertex in a given layer, suppose
none of its incident residual curvature spatial links can occur
in a coframe. Gauge-transform just the curvature network at that
vertex. All incident used curvature spatial and temporal anchors
participate in the transform. Haar is invariant and all coframes
are unchanged, including those in the leaf moments. Every other
rooted holonomy is unchanged, and the holonomies rooted at this
vertex are conjugated. If there are one or two occupied rooted
directions and their total power is odd, the Haar gauge
average is zero. For each chirality, choose a half-turn about
a normal to the at most two imaginary quaternion vectors.
It negates both vectors without changing their lengths.
Right-invariance of the gauge average gives the common sign
minus on the odd total integrand. This proof allows separate
orientations in the two independent SU(2) chiralities and
does not assume a source state.

The conservative incidence test applied to the frozen orbit
table certifies **81 exact zero orbits**, covering **5,700**
labeled occupations. Two zero orbits belong to the isolated-edge
family. The canonical trace control verifies the common
half-turn on all antisymmetric Clifford components for two
independent imaginary directions. The previous nonzero uniform
profile is not removed by the test. `zero-orbits.tsv` records
the complete certified set. This count does not claim the
remaining orbits are all nonzero.

## Exact conditional shared-Haar factor for the isolated-edge family

For one isolated edge write a,c for the two original directed
spatial anchors of layer A, b,d for those of layer B, and U,V
for the independent forward temporal anchors in the connector.
The closed rooted words are

```
H_x = a† V† b U
H_y = c† U† d V.
```

For one Spin(4) irreducible representation j, use its unitary
matrix D_j and dimension d_j. Expand a rooted function as
f(H)=sum_j sum_(alpha,beta) F_j[alpha,beta] D_j(H)[alpha,beta],
and similarly for g with coefficients G. The coefficients may
be even coframe polynomials, with the spatial links held fixed.
Integrate the two actual temporal anchors by matrix
orthogonality. The exact contribution in representation j is

```
chi_j(b d) / d_j^2
 * sum_(alpha,beta,gamma,delta)
     F_j[alpha,beta] G_j[gamma,delta]
     D_j(a†)[alpha,delta] D_j(c†)[gamma,beta].
```

The U integral equates the b-column and d-row indices and
the two adjacent root indices. The V integral closes the
remaining b,d pair into the displayed trace. Distinct
irreducibles vanish under either anchor integral. This is a
conditional identity, so it retains the shared spatial
matrix factors exactly. Different isolated temporal edges
have independent connector anchors. Their spatial factors
can still be used by both connector kernels or by coframes
and are multiplied before the original spatial Haar.

A root of degree m≤4 has only irreducible labels
(p/2,q/2) with p+q≤m and parity p+q=m modulo two. This
follows from tensor powers of the two fundamental
representations for the quaternion coordinates.
The exact ambient matrix-component counts for degrees
0 through 4 are 1, 8, 35, 112, 294, and a single
representation has dimension at most 9. These are
representation bounds, not measured populated source
tensor widths for all 816 orbits.

The exact canonical control expands the two F01 factors
in the actual temporal quaternion coordinates at fixed
spatial links. Direct coordinate Haar agrees with the
Schur formula for all three link profiles, giving −2,
−11/10 and zero. The largest raw root support in those
controls has 24 terms, with eight matched temporal keys.
At the identity spatial point each single-root mean is
zero, while their joint mean is −2. This is an actual
adverse conditional Haar control, not a sign claim for a
complete occupation.

## Signed evaluation of the tractable subfamily

For the coframe/curvature-disjoint subset, root gauge
averaging acts independently on the curvature variables.
For an even root power 0,2,4 its scalar character polynomial
is the one in the prior signed degree report. In the
isolated-edge family the displayed Schur formula for
characters reduces to

```
chi_j(a c) chi_j(b d) / d_j^2
```

times the two root coefficients. If only one connector
has this edge, complete spatial Haar keeps only the
trivial representation. If both connectors use the edge,
their spatial characters have the same arguments in
reversed layer order. The shared spatial Haar pairs
characters with the same representation and gives one
by normalized character orthogonality. The full
four-root denominator is therefore d_j^4. No spatial
character is separately averaged in that case.

The complete tractable subfamily defined by isolated
residual edges, no curvature/coframe spatial overlap,
all root powers even and all coframes on each edge
centered at one endpoint has six orbits and 336 labeled
occupations. It has no overlap with the certified zeros.
The signed coframe contraction is fully evaluated for
all six, not just the named representative.

Each degree-two or degree-four edge uses its original
two directed anchors and source quarter coefficients.
`edge.cpp` collects exact same-endpoint edge tensors,
with 48 and 380 nonzero entries respectively. Crossed
pair grouping and endpoint reversal give identical
entries. The largest edge moment join count is
1,476,800 against a cap of 50 million. The edge
denominators are 64 and 12288. The corresponding
vertex polynomial is a product of W powers from the
actual centered temporal planes. All coframes are
Grassmann-even, so one may sort the internal direction
labels within each local monomial.

A site factor consumes its owned edges' internal
labels and local masks, leaving the remote masks of
owned edges and the local masks of other edges as
boundary variables. Rejection on overlapping local
masks and signed completion to the original eight-mask
top preserve the original exterior orientation. In
particular a vertex with no incoming edge masks can
look up the last owned edge by the exact complementary
mask. The worst unfiltered site bound is 656,640.
That schedule refused its 500,000 cap. Complement
lookup gives 54,720 prefix trials and 26,400 emitted
combinations for that site. The complete measured
family has at most 420 populated factor or join rows
and 472 products in any site-factor join. The
signed sparse natural join predicts exact matched
products before expansion, caps them at two million,
caps tables at 150,000 rows and checks integer
height. Actual resident memory and timings are in
the receipts. No higher-width mixed-owner edge
tensor was attempted.

The independent join ordering agrees on the named
coframe Q3 value. Omitting a single site's wedge
sign gives a different exact value. The site method
also reproduces the prior checkerboard two-square
and octagon controls. Its source-sign and
denominator rules are the same ones used in the
earlier leaf-reduced subclass.

## Named original shared-core representative

The representative is `(149259165705,149259165705)`
with orbit multiplicity 24. Both layers have one
isolated (4,4) core on spatial edge (2,3). Their
other temporal roots are removed by the exact leaf
rule. The two coframe layers have the same signed
coefficient. It is 11696130675/2097152 in either
join order. The single-vertex omission gives
2308323825/2097152.

The shared original curvature factor on this edge
is

```
10^4 + 2 + 2/5^8 + 16/3^12
= 2076356601844132/207594140625.
```

The 2 term is from the two single-chirality spin-one
channels. The 2/5^8 term is from spin two in either
chirality and the last term from spin one in both.
Independent spatial averaging would give 10^4 and
miss all three corrections. There are eight leaf
roots of power two across both layers. Their factor
2^8 cancels their eight 2! divisors. The four
power-four roots retain all four 4! factors. The
exact original representative is therefore

```
2639406503532607427501217/2814749767106560000 > 0.
```

Its 24-member orbit contributes
7918219510597822282503651/351843720888320000.
All six measured orbit values are positive, with
the exact weighted subtotal

```
3957259417708218600393632457/5629499534213120000.
```

`signed-orbits.tsv` binds their representative
codes, orbit weights and exact original values.

## Remaining work and reproduction

This intake leaves **11,802** unresolved orbits
with **1,014,585** coarse labeled survivors in the
declared temporal degree block. Its sign and the
full c0 sign remain unknown. The next expansion
of the 816-orbit isolated-edge family should keep
the measured Schur connector tensors and integrate
their spatial factors with mixed-owner coframe
edge tensors. The maximum occupied source widths
for that step have yet to be measured. Multi-edge
temporal cores require additional contractions.
The complete result awaits independent review.

Build `edge.cpp` with
`clang++ -std=c++20 -O3 -Wall -Wextra -Werror edge.cpp -o edge`
and run it in the package directory to generate
`edge.tsv`. Run the Python census, family,
coframe and prior controls in that directory.
The source-backed `shared_core.py` uses the exact
primary on PYTHONPATH, its existing venv Python,
and PYTHONDONTWRITEBYTECODE=1. The previous
representative and slice inputs are read-only.
`measure.py` captures run timing and peak RSS.
