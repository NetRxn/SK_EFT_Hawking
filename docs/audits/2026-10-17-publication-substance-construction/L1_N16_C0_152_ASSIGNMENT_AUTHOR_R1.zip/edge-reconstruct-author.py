from ast import literal_eval
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
from math import prod

parse=lru_cache(maxsize=75_000)(literal_eval)
def read_edge(p):
    out={}
    for l in Path(p).open():
        w0,w1,m,A,B,r,s=l.split('\t')
        m=int(m)
        key=((parse(w0),m&255),(parse(w1),m>>8),parse(A),parse(B))
        assert key not in out
        z=(F(r),F(s))
        assert any(z)
        out[key]=z
    return out
def aliases(p):
    out={}
    for l in Path(p).open():
        w,m,v,n,r,s=l.split('\t')
        k=(parse(v),int(n))
        z=(int(r),int(s))
        assert any(z)
        out.setdefault(k,[]).append(((parse(w),int(m)),z))
    keys=[k for rows in out.values() for k,z in rows]
    assert len(keys)==len(set(keys))
    return out
def mul(x,y):
    return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]

checks=0
size=0
for path in sorted(Path('raw-edges').glob('*.tsv')):
    j=path.stem
    base=read_edge(path)
    new=read_edge(f'rays/{j}.tsv')
    A,B=(aliases(f'rays/{j}-{i}.tsv') for i in range(2))
    assert set(A)=={k[0] for k in new} and set(B)=={k[1] for k in new}
    assert {x for rows in A.values() for x,z in rows}=={k[0] for k in base}
    assert {y for rows in B.values() for y,z in rows}=={k[1] for k in base}
    forecast=sum(len(A[x])*len(B[y]) for x,y,_,_ in new)
    assert forecast==len(base)<=100_000
    seen=set()
    for (x,y,rawL,rawR),matrix in new.items():
        for q,g in A[x]:
            for r,h in B[y]:
                native=(q,r,rawL,rawR)
                assert native not in seen
                seen.add(native)
                assert base[native]==mul(mul(g,h),matrix),(j,native,base[native],matrix,g,h)
    assert seen==base.keys()
    checks+=len(seen)
    size+=1
    print(j,'original rows',len(base),'quotient rows',len(new),'reconstructed',len(seen),flush=True)
assert size==67
print('validated exact full signed spatial reconstruction for',size,'tables and',checks,'rows')
