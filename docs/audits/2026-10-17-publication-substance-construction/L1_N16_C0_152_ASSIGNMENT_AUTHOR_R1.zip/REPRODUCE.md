# L1 scale-up to 152 supported assignments

Run `python3 verify.py` to recompute the signed author coefficient from all
76 exact logs and its 152-assignment roster. The projected-edge driver ran
the full profile end to end. The separate inverse-quotient check
reconstructed all 295,444 signed rows in 67 raw edge tables.
Large local factors are identified by SHA-256. The archive contains
the author result, pending independent review.
