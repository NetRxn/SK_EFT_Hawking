# Original dense Group 786 exact signed contraction

The fixed original dense representation cut, accepted chirality map
and Group 786 preparation are pinned in the prior dense-pairing and
first-touch substitution archives. Group 786's frozen prepared source
hash is
`64aea132ade7050e2680b6982d5e8e720e27df75c71fcd59e7f919482d24ee5b`.
Each assigned original joint-L label is a distinct member of the
eight-state original roster.

Independent replays check source conditioning, guarded outputs, and all
retained continuation stages. Seven assignments end in one exact
axis-empty signed factor. Assignment 5 uses a full triangle sum at its
original three-factor frontier. Two author anchors and an independent
third pivot all include the same 10,450,944 compatible products with
the same signed result. Original orientation, occupation multiplier
and inherited Group 786 denominator are retained. The prior exact
chirality proof transfers the normalized value to Group 3212. The
profile multiplier 48 is external to each group value.

Run from a clean extraction:

```sh
shasum -a 256 -c SHA256SUMS
python3 -B retally.py | cmp - AUTHOR_RETALLY.txt
python3 -B check-independents.py | cmp - INDEPENDENT_MATCH.tsv
```

To reconstruct the author run, execute each label's `condition.py`
against the verified prepared Group 786 source and its recorded hash.
Use empty directories. The included `run.py` calls `contract-slice.py`
to rebuild the signed guard. Set the path in each `unsharded.py` to that
reproduced cap while retaining its hash and shape checks. The numbered
pass files reproduce the signed continuations in order. For assignment 5
run `triangle.py --evaluate` after pass 2. The manifests pin the rerun
checkpoints. The independent retally archive contains the small terminal
factors and the triangle receipt. Larger checkpoint data is reconstructed
from the original compiled inputs.

The local performance trial in `throughput` compares two exact
continuation stages. Both split and output states match byte for byte.
The independent Group 1466 zero-slice receipt in the same directory
covers its original ordinals 5 and 7. Its other six assignments are
separate. Neither throughput evidence section changes the Group 786
retally or portfolio publication gate state.

The throughput directory also includes the separate independent Group
1466 original ordinal 4 source-through-terminal review. It supplies one
nonzero signed scalar. The other five original assignments still need
individual acceptance before Group 1466 and its partner can enter the
dense group ledger.
