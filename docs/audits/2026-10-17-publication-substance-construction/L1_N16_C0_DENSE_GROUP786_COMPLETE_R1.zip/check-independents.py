"""Join every independent Group 786 terminal to the same author assignment."""
from pathlib import Path
import csv
import re
from zipfile import ZipFile

observed = {}
layouts = (
    ("L0", "original_joint_L_index", "raw_real", "raw_imag", "inherited_factor_denominator"),
    ("L2", "original_L_assignment", "raw_real", "raw_imag", "inherited_factor_denominator"),
    ("L134", "original_L_assignment", "raw_real", "raw_imag", "inherited_factor_denominator"),
    ("L56", "assignment", "raw_re", "raw_im", "factor_denominator"),
    ("L7", "assignment", "raw_re", "raw_im", "factor_denominator"),
)
for tag, label_key, real, imag, denominator in layouts:
    with ZipFile(Path("independent") / f"{tag}.zip") as bundle:
        receipts = csv.DictReader(bundle.read("scalar.tsv").decode().splitlines(), delimiter="\t")
        for receipt in receipts:
            assert receipt.get("group", "786") == "786"
            label = int(receipt[label_key])
            assert label not in observed
            fingerprint = receipt.get("terminal_sha256", receipt.get("terminal_state_sha256"))
            if fingerprint:
                assert fingerprint in (Path(f"L{label}") / "checkpoints.sha256").read_text()
            observed[label] = tuple(int(receipt[key]) for key in (real, imag, denominator))

author = {}
for label, real, imag, denominator in re.findall(
    r"original joint-L (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)",
    Path("AUTHOR_RETALLY.txt").read_text(),
):
    assert int(label) not in author
    author[int(label)] = int(real), int(imag), int(denominator)
assert sorted(observed) == list(range(8))
assert observed == author and all(imag == 0 for _, imag, _ in observed.values())
for label, value in sorted(observed.items()):
    print(label, *value, sep="\t")
