# Exact local projection performance trial

Profiling the frozen Group 786 assignment 0 pass 3 assigned 19.31
of 29.79 profiler seconds to ordered row projection and its generator.
The trial replaces only the continuation helper `pull` with the
bounded memoized C-level projection in `projection.py`. It preserves
the original position order, repeated positions and empty/singleton
tuple shape. Sections outside the continuation stage keep their
original implementation.

For each archived baseline stage and input pin in `comparisons.tsv`,
make separate empty replay directories and copy the author stage and
helper scripts. Replace the single `pull` definition in
`unsharded.py` in the experiment copy with `projection.py`. Run
`/usr/bin/time -p python3 -B passN.py` with the pinned predecessor
file name. Compare both split and terminal checkpoint SHA-256 digests.
The reported measurement runs each order twice, and every original
and experimental split and result agree byte for byte. Synthetic
controls compare 4,681 ordered projections, including repeated
positions and empty and singleton outputs.

L0 pass 3 takes 12.51 and 12.13 elapsed seconds in the original
implementation and 9.08 and 9.15 in the candidate. L7 pass 2 takes
38.75 and 38.60 seconds originally and 24.20 and 24.32 in the candidate.
The observed savings apply to these exact continuation stages.
Full group cost, the guard and broad profile throughput are outside
this measurement.
