from functools import lru_cache
from operator import itemgetter

@lru_cache(maxsize=4096)
def projector(indices):
    if not indices:
        return lambda row: ()
    take = itemgetter(*indices)
    if len(indices) == 1:
        return lambda row: (take(row),)
    return take

def pull(row, ii):
    return projector(ii)(row)
