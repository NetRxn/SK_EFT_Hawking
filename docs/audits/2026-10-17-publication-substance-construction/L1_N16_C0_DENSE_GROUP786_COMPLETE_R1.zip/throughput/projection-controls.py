from itertools import product

from projection import projector, pull

row = (1, ("L", 1), (3, 4), 5)
count = 0
for size in range(5):
    for positions in product(range(-4, 4), repeat=size):
        assert pull(row, positions) == tuple(row[i] for i in positions)
        count += 1
assert count == 4681 and projector.cache_info().currsize <= 4096
print(count, "ordered projection controls")
