# L1 odd-root pair reduction and signed support pruning

Candidate 51e7c745e, corrected support checkpoint 41460c92b. This is author
evidence for the pilot (103607566400,1256282136720), weight 96. The pilot
remains unresolved. Nothing is subtracted from the global residual.

Simultaneous chirality exchange is conjugation by the original gamma_3.
It swaps the quaternion blocks and permutes the eight local generators
by (0 4)(1 5)(2 6)(3 7), a permutation of sign +1 at each site.
Each coframe component gains its gamma-conjugation sign s_a.
The curvature trace gains -s_a s_b since gamma_5 changes sign.
Paired coframes therefore leave only one minus per EHC insertion.
The total exponent is 32, so each complete channel equals its exchanged
channel. Independent normalized product Haar is invariant under the
exchange. The actual coframe and bivector source tables match all
512 and 24 row transformations. The 36 corrected channel tuples form
18 distinct pairs. The table pairs.tsv relates these to legacy IDs.

Nineteen new spatial factor patterns execute under the existing
per-pattern cap. The exact label keys reuse 23 old patterns. There are
144 newly assembled signed site factors. The nine entirely new
representatives each admit an empty factor under exact support pruning,
before multiplying any matched pairs. The pruning operates on the
whole shared index tuple of two factors. A row with no row in the
other factor with that tuple cannot occur in a full contraction.
Repeated application is exact even if some filters are skipped for
resource bounds. The nine zeros plus five earlier signed zero
contractions account for 14 pairs. Four pairs retain unresolved exact
joins. The pair ledger does not require any assumption about their signs.

For the first hard representative (legacy case 5, corrected case 32),
an adaptive exact schedule plus support pruning reaches 11 remaining
factors, then hits the 300,000-row cap. The G(0,5,0) endpoint-mask domain
is exactly {16,32,64,128}. Selecting one value on both occurrences
gives disjoint terms summing to the original result across all four
values. The first tile (mask 16) hits the same row cap under the tested
schedule after 4,308,892 admitted products. No tile coefficient is
available. A more focused boundary split, compressed factor storage,
or new exact contraction order is required. Raising coverage by guessing
an omitted or refused coefficient is outside this calculation.

## Replay

OLD is the old author anchor archive from e9678295f. SEWN is its
regenerated signed factors from dc706134e, including its coframe roster.
CORRECTED is corrected-support from 41460c92b. AUTHOR is the restored
previous square author inputs. The new-anchors directory has the
nine frozen states and anchor plan to be assembled. Use a clean scratch
directory and retain supplied logs for comparison.

```sh
python3 exchange.py "$OLD/states.tsv" "$CORRECTED/states.tsv" "$AUTHOR/coframes.tsv" "$AUTHOR/bivectors.tsv"
ln -s "$SEWN/coframe-roster.tsv" .
python3 edge_plan.py new-anchors > edge-plan.out
python3 reuse_edges.py "$SEWN" > reuse.out
python3 site_exact.py new-anchors > site.out
sh run_new.sh
shasum -a 256 -c regenerated-tables.sha256
python3 tiled5.py "$OLD" "$SEWN" 5 list
python3 tiled5.py "$OLD" "$SEWN" 5 16 > tile5-16.out
```

The last command returns 3 for a budget refusal. The deterministic
table manifests are for regenerated outputs and do not include the
large scratch factor tables in the Git archive.

A second test fixed both G(0,5,0)=16 and G(0,7,2)=7. It progressed to
10 factors and then encountered a least next join of 9,584,640 products.
The two source domains give at most 80 distinct slices before full
support checks. The second test does not establish a viable global
schedule or an exact value.
