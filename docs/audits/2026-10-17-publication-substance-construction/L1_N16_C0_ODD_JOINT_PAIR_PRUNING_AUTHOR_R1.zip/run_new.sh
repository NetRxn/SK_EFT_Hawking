#!/bin/sh
set -eu
for case in 4 5 8 9 10 12 13 14 15
do
  python3 semijoin.py new-anchors . "$case" > "corrected$case.out" || test "$?" = 3
done
