from pathlib import Path
from collections import defaultdict
import sys

prior,current,coframes,bivectors=map(Path,sys.argv[1:])
def states(path):
    out=defaultdict(set)
    for row in path.read_text().splitlines():
        i,*rest=map(int,row.split())
        out[i].add(tuple(rest))
    return {i:frozenset(x) for i,x in out.items()}
def swap(state):
    return frozenset((t,x,k,r,l) for t,x,k,l,r in state)
def sign(a):
    return 1 if a==3 else -1
def transform(mask):
    assert (mask&255).bit_count()==(mask>>8).bit_count()==1
    return sum(1<<(i^4) for i in range(16) if mask>>i&1)
C={(o,a,m,q):(r,i) for o,a,m,q,r,i in (map(int,row.split()) for row in coframes.read_text().splitlines())}
for (o,a,m,q),(r,i) in C.items():
    assert C[o,a,transform(m),q^4]==(sign(a)*r, sign(a)*i)
V={(h,a,b,j):s for h,a,b,j,s in (map(int,row.split()) for row in bivectors.read_text().splitlines())}
for (h,a,b,j),s in V.items():
    assert V[h^1,a,b,j]==-sign(a)*sign(b)*s
print('source exchange controls',len(C),'coframe rows',len(V),'bivector rows')
old=states(prior)
new=states(current)
ids={state:i for i,state in new.items()}
seen=set()
with Path('pairs.tsv').open('w') as out:
    for i,state in sorted(new.items()):
        if i in seen:continue
        j=ids[swap(state)]
        assert i!=j
        seen.update((i,j))
        chosen=next((k for k,s in old.items() if s==state or s==swap(state)),None)
        if chosen is None:primary=i
        else:primary=ids[old[chosen]]
        secondary=j if primary==i else i
        print(primary,secondary,chosen if chosen is not None else '-',sep='\t',file=out)
assert len(seen)==36
print('exchange pairs',len(seen)//2)
