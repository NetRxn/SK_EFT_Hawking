from ast import literal_eval as parse
from collections import Counter,defaultdict
from dataclasses import dataclass,field
from fractions import Fraction
from itertools import product
from math import factorial,lcm,prod
from pathlib import Path
import sys

anchors, sewn=map(Path,sys.argv[1:3])
case=int(sys.argv[3])
mode=sys.argv[4] if len(sys.argv)>4 else 'least-work'
WORK=4_000_000
ROWS=300_000
TOTAL=30_000_000
ATTEMPT=4
REJECT_PRODUCTS=8_000_000
BITS=256
codes=(103607566400,1256282136720)
roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occ=[[roster[(code>>(6*x))&63] for x in range(8)] for code in codes]
states={}
for line in (anchors/'states.tsv').read_text().splitlines():
    c,t,x,k,p,q=map(int,line.split())
    if c==case:states[t,x,k]=p,q
edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
plan={}
for line in (anchors/'anchor-plan.tsv').read_text().splitlines():
    c,t,x,k,*shape=map(int,line.split())
    if c==case:plan[t,x,k]=tuple(shape)
patterns={}
for i,line in enumerate(l for l in (sewn/'edge-plan.out').read_text().splitlines() if l.startswith('pattern ')):
    text=line.removeprefix('pattern ')
    patterns[parse(text[:text.rindex(')')+1])]=i

@dataclass
class Factor:
    name:str
    wires:tuple
    rows:dict
    denom:int
    histograms:dict=field(default_factory=dict)

def bind(raw):
    fixed=[wire for wire in raw if wire is not None]
    assert len(set(fixed))==len(fixed),raw
    return tuple(fixed)

def factor(name,wires,entries):
    actual=bind(wires)
    rows={}
    d=1
    for v,(r,n) in entries:
        assert len(v)==len(wires)
        assert all(done is not None or x==0 for done,x in zip(wires,v)),(wires,v)
        k=tuple(x for done,x in zip(wires,v) if done is not None)
        assert len(rows)<ROWS and k not in rows
        R,N=Fraction(r),Fraction(n)
        d=lcm(d,R.denominator,N.denominator)
        rows[k]=R,N
    return Factor(name,actual,{k:(int(r*d),int(n*d)) for k,(r,n) in rows.items()},d)

def wire(t,x,k,i,h):
    return ('R',t,x,k,i,h) if states.get((t,x,k),(0,0))[h] else None

def matrix_wires(t,x,k,i):
    return tuple(wire(t,x,k,i,h) for h in range(2))

def matrix_indices(t,x,k,i):
    _,q=states.get((t,x,k),(0,0))
    return divmod(i,q+1)

def edgewords(t,x,k):
    return ('G',t,x,k),('W',t,x,k)

def site_factor(t,x):
    active=[k for k,p in enumerate(occ[t][x]) if p]
    wires=tuple(w for k in range(3) for w in edgewords(t,x,k))
    wires+=tuple(w for k in active for i in (4,0) for w in matrix_wires(t,x,k,i))
    def entries():
        for line in (sewn/f'site/{case}-{t}-{x}.tsv').open():
            letters,masks,indices,r,n=line.split('\t')
            values=tuple(v for mask,word in zip(parse(masks),parse(letters)) for v in (mask,word))
            indices=parse(indices)
            values+=tuple(v for k,(i,j) in zip(active,zip(indices[::2],indices[1::2])) for slot in (i,j) for v in matrix_indices(t,x,k,slot))
            yield values,(r,n)
    return factor(f'S{t}{x}',wires,entries())

def spatial_factor(t,u,v,k):
    def load(x):return sum(occ[t][x])-occ[t][x][k]
    roster=load(u),load(v),plan[t,u,k],plan[t,v,k]
    i=patterns[roster]
    wires=edgewords(t,u,k)+edgewords(t,v,k)
    wires+=tuple(w for x in (u,v) for layer,ij in ((t,(0,1)),(1-t,(2,3))) for j in ij for w in matrix_wires(layer,x,k,j))
    def entries():
        for line in (sewn/f'edge-batch/{i:02}.tsv').open():
            w1,w2,m,A,B,r,n=line.split('\t')
            m=int(m)
            val=(m&255,parse(w1),m>>8,parse(w2))+tuple(v for pair in (*parse(A),*parse(B)) for v in pair)
            yield val,(r,n)
    return factor(f'E{t}{u}{k}',wires,entries())

temporal=defaultdict(list)
for line in (anchors/'temporal.tsv').read_text().splitlines():
    shape,rows,cols,r,n=line.split('\t')
    temporal[parse(shape)].append((tuple(v for ij in zip(parse(rows),parse(cols)) for v in ij),(r,n)))

def temporal_factor(t,x,h):
    roots=[]
    wires=()
    for (layer,y,k),spins in sorted(states.items()):
        n=spins[h]
        if layer!=t or not n or x not in (y,y^(1<<k)):continue
        is_other=x!=y
        roots.append((n,bool(t^is_other)))
        ij=(1,2) if is_other else (3,4)
        wires+=tuple(wire(t,y,k,i,h) for i in ij)
    return factor(f'T{t}{x}{h}',wires,temporal[tuple(roots)])

factors=[site_factor(t,x) for t in range(2) for x in range(8)]
factors.extend(spatial_factor(t,u,v,k) for t in range(2) for u,v,k in edges)
factors.extend(temporal_factor(t,x,h) for t in range(2) for x in range(8) for h in range(2))
degree=Counter(w for f in factors for w in f.wires)
assert set(degree.values())=={2}
assert all(f.rows for f in factors)
print('case',case,'source factors',len(factors),'wires',len(degree),'initial rows',sum(len(f.rows) for f in factors),flush=True)

def take(row,positions):
    return tuple(row[i] for i in positions)

def indices(A,B):
    shared=tuple(w for w in A.wires if w in B.wires)
    left=tuple(A.wires.index(w) for w in shared)
    right=tuple(B.wires.index(w) for w in shared)
    return left,right

def buckets(f,positions):
    if positions not in f.histograms:
        f.histograms[positions]=Counter(take(r,positions) for r in f.rows)
    return f.histograms[positions]

def work(A,B,p,q):
    a,b=buckets(A,p),buckets(B,q)
    if len(a)>len(b):a,b=b,a
    return sum(n*b[k] for k,n in a.items())

def join(A,B,p,q,planned):
    assert planned<=WORK
    pkeep=tuple(i for i in range(len(A.wires)) if i not in p)
    qkeep=tuple(i for i in range(len(B.wires)) if i not in q)
    result_wires=take(A.wires,pkeep)+take(B.wires,qkeep)
    groups=defaultdict(list)
    for k,v in B.rows.items():
        groups[take(k,q)].append((take(k,qkeep),v))
    ma=max(abs(v).bit_length() for z in A.rows.values() for v in z)
    mb=max(abs(v).bit_length() for z in B.rows.values() for v in z)
    if ma+mb+planned.bit_length()+1>BITS:raise RuntimeError('height cap')
    result={}
    for k,(a,b) in A.rows.items():
        start=take(k,pkeep)
        for end,(c,d) in groups.get(take(k,p),()):
            key=start+end
            if key not in result and len(result)>=ROWS:raise RuntimeError('row cap')
            r,n=result.get(key,(0,0))
            v=(r+a*c-b*d,n+a*d+b*c)
            if any(v):result[key]=v
            else:result.pop(key,None)
    return Factor(A.name+'+'+B.name,result_wires,result,A.denom*B.denom)

def prune(fs, rounds=3):
    scanned=0
    removed=0
    for _ in range(rounds):
        columns=defaultdict(list)
        for i,f in enumerate(fs):
            for w in f.wires:columns[w].append(i)
        changed=False
        for i,j in sorted({tuple(ix) for ix in columns.values()}):
            A,B=fs[i],fs[j]
            p,q=indices(A,B)
            ha,hb=buckets(A,p),buckets(B,q)
            for left,pool,keep in ((A,p,hb),(B,q,ha)):
                if buckets(left,pool).keys()<=keep.keys():continue
                scanned+=len(left.rows)
                if scanned>4_000_000:return removed
                rows={row:v for row,v in left.rows.items() if take(row,pool) in keep}
                if len(rows)==len(left.rows):continue
                changed=True
                removed+=len(left.rows)-len(rows)
                left.rows=rows
                left.histograms.clear()
                if not rows:return removed
        if not changed:break
    return removed

group=set('E051 S07 E060 T160 S05 E012'.split())
counts=Counter(w for f in factors if f.name in group for w in f.wires)
print('boundary',tuple(w for w,n in counts.items() if n==1))
for w,n in counts.items():
    if n!=1:continue
    if w[0]!='G':continue
    f=next(f for f in factors if f.name in group and w in f.wires)
    c=f.wires.index(w)
    pop=Counter(row[c] for row in f.rows)
    choices=[]
    for i in range(8):
        a=sum(count for mask,count in pop.items() if mask>>i&1)
        if a and a!=len(f.rows):choices.append((abs(len(f.rows)-2*a),i,a,len(f.rows)-a))
    if choices:print(f.name,w,min(choices))
