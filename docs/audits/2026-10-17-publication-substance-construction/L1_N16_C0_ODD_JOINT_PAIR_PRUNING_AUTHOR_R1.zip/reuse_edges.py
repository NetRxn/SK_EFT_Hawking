from pathlib import Path
from ast import literal_eval
from hashlib import sha256
import subprocess
import sys

old=Path(sys.argv[1])
def patterns(path):
    for row in path.read_text().splitlines():
        if not row.startswith('pattern '):continue
        boundary=row.rindex(')')
        yield literal_eval(row[8:boundary+1]),int(row.split()[-1])
before={pattern:i for i,(pattern,_) in enumerate(patterns(old/'edge-plan.out'))}
out=Path('edge-batch')
out.mkdir()
for i,(key,work) in enumerate(patterns(Path('edge-plan.out'))):
    path=out/f'{i:02}.tsv'
    a,b,s,t=key
    if key in before:
        path.symlink_to(old/'edge-batch'/f'{before[key]:02}.tsv')
        mode=f'reused {before[key]:02}'
    else:
        assert work<=4_000_000,(i,key,work)
        run=subprocess.run([sys.executable,'edge_exact.py','new-anchors',str(a),str(b),repr(s),repr(t)],capture_output=True,text=True)
        if run.returncode:print(i,'REFUSED',run.stderr,flush=True);continue
        Path('edge-selected.tsv').replace(path)
        mode=run.stdout.strip()
    print(i,work,mode,sha256(path.read_bytes()).hexdigest(),flush=True)
