from fractions import Fraction as F
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from src.core.formulas import original_spin4_link as spin, original_plaquette as plaq
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial as P, QComplex as Q, Symbol,
    matrix_multiply as mm, matrix_dagger as dagger,
)
from src.core.formulas import original_quaternion_haar_moment as sphere

reg=OriginalRegulator(temporal_axis=0)
shape=(1,3,3,4)
origin=(0,0,0,0)
sites={v:(0,*((v>>i)&1 for i in range(3))) for v in (2,4,6)}
gamma=reg.gamma
O=mm(mm(gamma[0],gamma[1]),reg.gamma5)
def trace(A):
    return sum((A[i][i] for i in range(len(A))),P())
def polynomial(coords):
    return tuple(tuple(P.variable(Symbol('q',(coords,0,chi,i))) for i in range(4))
                 for chi in ('L','R'))
def read(path):
    return (tuple(map(int,line.split())) for line in Path(path).open())
R=list(read('INDEPENDENT/adjoint.tsv'))
D=list(read('INDEPENDENT/fundamental-product.tsv'))

def rep(coords,k):
    if k==0:return ((P.scalar(1),),)
    d=shape[k]
    rows=[[P() for _ in range(d)] for _ in range(d)]
    if k<3:
        q=coords[k-1]
        for i,j,a,b,c in R:rows[i][j]+=P.coerce(q[a])*P.coerce(q[b])*c
    else:
        q=coords[0]+coords[1]
        for i,j,a,b,r,s in D:rows[i][j]+=P.coerce(q[a])*P.coerce(q[b])*Q(r,s)
    return tuple(map(tuple,rows))

@cache
def moment(keys):
    return prod(sphere(tuple(keys.count((chi,i)) for i in range(4))) for chi in ('L','R'))

def integrate(p,site):
    out=[]
    for key,z in p.terms:
        variables=tuple(s.index[-2:] for s in key if s.index[0]==site)
        m=moment(variables)
        if m:out.append((tuple(s for s in key if s.index[0]!=site),z*m))
    return P(tuple(out))

def multiply(a,b):
    n=len(a.terms)*len(b.terms)
    assert n<=2_000_000
    return a*b,n

# Independently extract each Fourier entry by normalized Haar projection
# of the literal spin trace, including complex conjugation.
q=polynomial(origin)
source=trace(mm(spin(*q),O))
source,_=multiply(source,source)
tensors=[]
for k,d in enumerate(shape):
    mat=rep(q,k)
    T=[]
    for i in range(d):
        row=[]
        for j in range(d):
            p,_=multiply(source,mat[j][i].conjugate())
            row.append(integrate(p,origin)*d)
        T.append(tuple(row))
    tensors.append(tuple(T))

samples=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),(F(1,2),)*4,(F(3,5),0,F(4,5),0))
edges=((2,6,3),(4,6,2))
qtime={x:polynomial(x) for x in sites.values()}
def scalar(p):
    assert not p or len(p.terms)==1 and p.terms[0][0]==()
    return p.terms[0][1] if p else Q()

for profile in (0,1):
    links={(x,0):spin(*q) for x,q in qtime.items()}
    literal=[]
    reduced=[]
    works=[]
    for e,(i,j,axis) in enumerate(edges):
        x,y=sites[i],sites[j]
        coords=[]
        for r,(v,opposite) in enumerate(product((x,y),range(2))):
            current=(samples[(1+r+2*e)%6],samples[(1+2*r+e)%6]) if profile else (samples[0],)*2
            coords.append(current)
            links[(reg.step(v,0)[0] if opposite else v,axis)]=spin(*current)
        roots=[]
        for v in (x,y):
            L=trace(mm(plaq(reg,v,0,axis,links),O))
            sq,n=multiply(L,L)
            works.append(n);roots.append(sq)
        edge,n=multiply(*roots)
        works.append(n)
        literal.append(integrate(edge,x))

        reduced_edge=P()
        for k,d in enumerate(shape):
            A,B,C,D2=[rep(anchor,k) for anchor in coords]
            U=rep(qtime[y],k)
            X=mm(tensors[k],dagger(A))
            Y=mm(tensors[k],dagger(C))
            # tr(P W)tr(Q W†) -> tr(P Q)/d for one leaf W.
            left=mm(mm(X,dagger(U)),B)
            right=mm(mm(D2,U),Y)
            reduced_edge+=trace(mm(left,right))*F(1,d)
        reduced.append(reduced_edge)
    raw,n=multiply(*literal);works.append(n)
    shared,n=multiply(*reduced);works.append(n)
    direct=scalar(integrate(raw,sites[6]))
    reduced_exact=scalar(integrate(shared,sites[6]))
    mutant=prod(scalar(integrate(p,sites[6])) for p in reduced)
    assert direct==reduced_exact
    if profile:assert direct!=mutant
    print(profile,direct.storage,reduced_exact.storage,mutant.storage,
          'peak work',max(works),'raw leaf rows',[len(x.terms) for x in literal])
