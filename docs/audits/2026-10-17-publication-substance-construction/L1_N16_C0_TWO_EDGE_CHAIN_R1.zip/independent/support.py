from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import product
from math import prod
from pathlib import Path

def read(p):
    return (tuple(map(int,row.split())) for row in Path(p).open())
def add(a,b):
    return a[0]+b[0],a[1]+b[1]
def times(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
@cache
def sphere(word):
    counts=Counter(word)
    if any(n&1 for n in counts.values()):return F(0)
    return F(prod(prod(range(1,n,2)) for n in counts.values()),prod(range(4,4+len(word),2)))
@cache
def haar(word):
    return prod(sphere(tuple(i%4 for i in word if i//4==g)) for g in range(4))
source=defaultdict(list)
coframe=defaultdict(list)
adj=defaultdict(list)
for o,d,m,q,r,s in read('INDEPENDENT/source-edge.tsv'):
    coframe[o,d].append((m,q,(r,s)))
for a,b,i,j,c in read('INDEPENDENT/adjoint.tsv'):
    source[i,j].append((a,b,c))
    adj[a,b].append((tuple(sorted((i,j))),c))
ordinary={}
for d,s,w,l,h,r,i in read('INDEPENDENT/edge-moments.tsv'):
    if s==0:
        factor=2880 if d==2 else 240
        ordinary[int(d==4),w,0,l,h]=(factor*r,factor*i)
for u,v,l,h,r,s in read('INDEPENDENT/mixed.tsv'):
    ordinary[2,u,v,l,h]=(240*r,240*s)
scalar=defaultdict(dict)
degree2=defaultdict(dict)
controls={}
rows=0
for chi,owner,kind,i,j,p,q,u,v,mask,re,im in read('frozen/chain/paired.tsv'):
    rows+=1
    assert i//4==j//4==chi and p//4==q//4==chi+2
    controls.setdefault((chi,owner,kind),((i,j,p,q),u,v,mask,(re,im)))
    if i==j and p==q:
        a,b=mask&255,mask>>8
        if owner:a,b=b,a
        left,right=(16*u+v,0) if kind==1 else (u,v)
        index=kind,left,right,a,b
        table=scalar[chi,owner]
        table[index]=add(table.get(index,(0,0)),(re,im))
    if kind==0:
        table=degree2[chi,owner,u]
        for (a,b,r),(c,d,s) in product(source[i%4,j%4],source[p%4,q%4]):
            idx=mask,a,b,c,d
            table[idx]=add(table.get(idx,(0,0)),(re*r*s,im*r*s))
print('paired moment rows',rows)
for chi,owner in product(range(2),repeat=2):
    ref={key:z for key,z in ordinary.items() if owner==0 or key[0]!=2}
    actual={k:z for k,z in scalar[chi,owner].items() if any(z)}
    assert actual==ref,(chi,owner,len(actual),len(ref))
    assert not any(any(z) for (c,o,u),t in degree2.items() if (c,o)==(chi,owner) for z in t.values())
    print('identity',chi,owner,len(actual),'nontrivial degree-two matrices zero')
assert all(kind!=0 for _,_,kind,*rest in read('frozen/chain/paired-matrices.tsv'))

for (chi,o,k),(coords,u,v,mask,want) in controls.items():
    factors=[(o,u//4),(o,u%4)]
    if k:
        other=1-o if k==2 else o
        factors.extend(((other,v//4),(other,v%4)))
    actual=(F(0),F(0))
    rs=[[t for t in coframe[f] if not (t[0]&~mask)] for f in factors]
    assert prod(map(len,rs))<=2_000_000
    for terms in product(*rs):
        m=0;n=0;z=(1,0)
        for bits,q,c in terms:
            if m&bits:break
            n+=sum((m>>(j+1)).bit_count() for j in range(16) if bits>>j&1)
            m|=bits
            z=times(z,c)
        else:
            assert m==mask
            h=(-1)**n*haar(tuple(sorted(coords+tuple(q for _,q,_ in terms))))*11520
            actual=add(actual,(z[0]*h,z[1]*h))
    assert actual==want,(chi,o,k,actual,want)
print('independent literal paired nonzero target checks',len(controls))

@cache
def moment(cells):
    poly={():1}
    for cell in sorted(cells):
        nxt=defaultdict(int)
        for (w,n),(q,c) in product(poly.items(),adj[cell]):
            nxt[tuple(sorted(w+q))]+=n*c
        poly=nxt
    return sum((n*sphere(w) for w,n in poly.items() if n),F(0))
central={}
for c,d,i,j,k,l,a,b,e,f,z in read('frozen/chain/central.tsv'):
    key=(c,d,i,j,k,l,a,b,e,f)
    assert key not in central
    central[key]=F(z,90)
checked=0
for c,d in product(range(3),repeat=2):
    dw=(1 if c==0 else 3,1 if d==0 else 3)
    for (i,j,k,l),(a,b,e,f) in product(product(range(dw[0]),repeat=4),product(range(dw[1]),repeat=4)):
        left=((k,j),(l,i)) if c else ()
        right=((e,b),(f,a)) if d else ()
        value=(moment(tuple(sorted(left+right))) if c==d else
               moment(tuple(sorted(left)))*moment(tuple(sorted(right))))
        assert value==central.get((c,d,i,j,k,l,a,b,e,f),0)
        checked+=1
print('independent central coordinate controls',checked,'nonzero',len(central))
