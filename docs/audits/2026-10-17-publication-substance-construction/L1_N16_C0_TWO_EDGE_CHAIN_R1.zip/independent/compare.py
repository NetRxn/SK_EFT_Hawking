from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import re
def rows(p):
    return [line.split() for line in Path(p).read_text().splitlines()]
residual=[tuple(map(int,r)) for r in rows('current-residual.tsv')]
author=rows('frozen/chain/author-results.tsv')
keys=[tuple(map(int,r[:3])) for r in author]
assert len(set(keys))==len(keys)==265 and all(r[3]=='EXACT' for r in author)
assert all(k in residual for k in keys)
expect=dict(zip(keys,(F(r[4]) for r in author)))
tallies=[]
census=[]
actual={}
layers={}
for index in (0,70,140,210):
    for r in rows(f'cases-{index}.out'):
        if r[0]=='case':census.append(tuple(map(int,r[1:4])))
        elif r[0]=='exact':
            k=tuple(map(int,r[1:4]))
            factor,a,b,z=map(F,r[4:8])
            assert factor*a*b==z==expect[k] and k not in actual,k
            for code,value in zip(k[:2],(a,b)):
                assert layers[code]==value
            actual[k]=z
        elif r[0]=='layer':
            code=int(r[1]);value=F(r[15])
            if code in layers:assert layers[code]==value
            layers[code]=value
            tallies.append(tuple(int(r[i]) for i in (5,7,10,13)))
assert list(actual)==census==keys
left=[r for r in residual if r not in actual]
assert len(left)==10103 and sum(r[2] for r in left)==871419
assert len(layers)==183
print('cases',len(actual),'labels',sum(k[2] for k in actual),'unique scalar layers',len(layers))
print('weighted subtotal',sum(k[2]*v for k,v in actual.items()))
print('signs',Counter((v>0)-(v<0) for v in actual.values()))
print('weights',Counter(k[2] for k in actual))
print('max factor / join / site / initial',*[max(t) for t in zip(*tallies)])
log=Path('frozen/chain/case-contractions.out').read_text()
for pattern in (r' site \d work (\d+)',r'populated rows (\d+)',r' matched (\d+) rows',r'triangle preflight (\d+)',r'resident input rows (\d+)'):
    print(pattern,max(map(int,re.findall(pattern,log)),default=0))
print('remaining',len(left),sum(k[2] for k in left))
Path('reviewed-exact.tsv').write_text(''.join('\t'.join(map(str,(*k,v)))+'\n' for k,v in actual.items()))
