import ast,os,sys,inspect
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations_with_replacement,product
from math import factorial,prod
from pathlib import Path

sys.path.insert(0,str(Path("INDEPENDENT").absolute()))
scratch=Path.cwd()
os.chdir("INDEPENDENT")
from contract import same,mixed,integrate,final_three,occupancy,profile,local,enc,inv
source=ast.parse(Path("project.py").read_text())
source.body=[node for node in source.body if isinstance(node,(ast.FunctionDef,ast.Import,ast.ImportFrom))]
exec(compile(source,"project.py","exec"))
os.chdir(scratch)

def read(path):
    return (tuple(map(int,row.split())) for row in Path(path).open())
def plus(a,b):return a[0]+b[0],a[1]+b[1]
def times(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def conj(a):return a[0],-a[1]
# Preserve the independent join schedule while checking the batch's tighter
# declared resource caps at the points where it launches arithmetic.
def tighten(text, pairs):
    for before,after in pairs:
        assert text.count(before)==1, before
        text=text.replace(before,after)
    return text

class Refusal(RuntimeError):
    pass
def guard(condition,resource):
    if not condition:
        raise Refusal(resource)
env=dict(integrate.__globals__)
env['guard']=guard
exec(tighten(inspect.getsource(final_three),[
    ('    choices=[]','    guard(sum(len(t) for _,t in fs)<=150000, ("closing resident rows",sum(len(t) for _,t in fs)))\n    choices=[]'),
    ('    assert cost<=8_000_000','    guard(cost<=2_000_000, ("closing products",cost))\n    height=sum(max((max(abs(x),abs(y)).bit_length()+1 for x,y in t.values()),default=0) for _,t in fs)\n    guard(height+cost.bit_length()<=384, "closing height")')
]),env)
exec(tighten(inspect.getsource(integrate),[
    ('        assert n<=5_000_000,(A,B,n)','        guard(n<=2_000_000, ("join products",n))\n        height=sum(max((max(abs(x),abs(y)).bit_length()+1 for x,y in t.values()),default=0) for t in (X,Y))\n        guard(height+n.bit_length()<=384, "join height")'),
    ('                collect(out,k,mul(z,w))','                guard(k in out or len(out)<150000, "join rows")\n                collect(out,k,mul(z,w))'),
    ('        assert peak<300_000','        guard(peak<=150_000, ("factor rows",peak))')
]),env)
integrate=env['integrate']
widths=(1,3,3,4)
def select(rows):
    for a,b,w in rows:
        codes=(a,b)
        if any(n%2 for code in codes for site in occupancy(code) for n in site):
            continue
        graphs,forced,domains=projection(*codes,2)
        present=[side for side,G in enumerate(graphs) if G]
        if len(present)!=1:continue
        side=present[0]
        graph=graphs[side]
        if len(graph)!=2 or set(graph.values())!={(2,2)}:continue
        degree=Counter(x for u,v,k in graph for x in (u,v))
        if sorted(degree.values())!=[1,1,2]:continue
        center=next(x for x in degree if degree[x]==2)
        edges=[profile(code)[2] for code in codes]
        assert all(sorted(edges[side][e])==[0,2] for e in graph)
        assert all(sorted(load) in ([0,2],[0,4],[2,2])
                   for geometry in edges for load in geometry.values())
        yield codes,w,side,center,tuple(graph),forced

def factors(code):
    occ=occupancy(code);edges=profile(code)[2]
    incident=defaultdict(list)
    factors=[]
    den=1
    for edge,(a,b) in sorted(edges.items()):
        u,v,axis=edge
        d=a+b
        if a and b:
            assert (a,b)==(2,2)
            data=mixed
        else:
            data=same[d] if a else {(y,x):z for (x,y),z in same[d].items()}
        den*=64 if d==2 else 12288
        wires=((u,v,0),(u,v,1))
        guard(sum(len(t) for _,t in factors)+len(data)<=150000, ('initial edge rows',code,u,v))
        factors.append((wires,data))
        for x,wire in zip((u,v),wires):
            slot=(0 if u==x else 1)
            avail=defaultdict(set)
            for row in data:
                w,m,i=row[slot]
                assert m.bit_count()==d
                avail[w,i].add(m)
            incident[x].append((wire,axis,avail))
    max_site_work=0
    for x,row in enumerate(occ):
        choices=[]
        for (_,words),z in local(row,-1,-1).items():
            choices.append((tuple(map(enc,words)),z))
        table={}
        plans=[]
        for words,z in choices:
            labels=[(words[a],0) for _,a,_ in incident[x]]
            groups=[D.get(s,()) for (_,_,D),s in zip(incident[x],labels)]
            if not all(groups):continue
            order=sorted(range(len(groups)),key=lambda i:len(groups[i]))
            plans.append((groups,order,labels,z))
        work=sum(prod(len(groups[i]) for i in order[:-1]) for groups,order,_,_ in plans)
        guard(work<=2_000_000, ('site complement work',work))
        max_site_work=max(max_site_work,work)
        for groups,order,labels,z in plans:
            for prefix in product(*(groups[i] for i in order[:-1])):
                mask=0
                for a in prefix:
                    if mask&a:break
                    mask|=a
                else:
                    complement=255^mask
                    if complement not in groups[order[-1]]:continue
                    masks=dict(zip(order,(*prefix,complement)))
                    ordered=list(map(masks.__getitem__,range(len(masks))))
                    exponent=sum(inv(a,b) for i,a in enumerate(ordered) for b in ordered[i+1:])
                    signed=z if exponent%2==0 else (-z[0],-z[1])
                    key=tuple((w,m,i) for (w,i),m in zip(labels,ordered))
                    table[key]=plus(table.get(key,(0,0)),signed)
                    guard(len(table)<=150000, ('site factor rows',len(table)))
        factors.append((tuple(wire for wire,_,_ in incident[x]),{k:v for k,v in table.items() if any(v)}))
    guard(sum(len(t) for _,t in factors)<=150000, ('initial resident rows',sum(len(t) for _,t in factors)))
    return factors,den,max_site_work

@cache
def value(code,reverse):
    network,den,sites=factors(code)
    val,peak,work=integrate(network,reverse)
    assert val[1]==0
    print('layer',code,'denominator',den,'peak',peak,'work',work,'site work',sites,
          'initial resident',sum(len(t) for _,t in network),'value',F(val[0],den),flush=True)
    return F(val[0],den)

def run(rows,start,stop,reverse):
    for index,(codes,w,side,center,edges,forced) in enumerate(select(rows)):
        if not start<=index<stop:continue
        print('case',*codes,w,side,center,edges,forced,flush=True)
        powers=[n for code in codes for v in occupancy(code) for n in v]
        factor=F(prod({0:1,2:2,4:10}[n] for n in powers),prod(factorial(n) for n in powers))
        a,b=(value(code,reverse) for code in codes)
        print('exact',*codes,w,factor,a,b,factor*a*b,flush=True)

def roster(path):
    return [tuple(map(int,row.split()[:3])) for row in Path(path).read_text().splitlines()]

rows=roster('current-residual.tsv')
previous=roster('before-a-residual.tsv')
prior=roster('accepted-a-exact.tsv')
assert len(rows)==10368 and sum(r[2] for r in rows)==895995
assert len(prior)==14 and [r for r in previous if r not in set(prior)]==rows
cases=list(select(rows))
assert len(cases)==265 and sum(r[1] for r in cases)==24576
print('cohort',len(cases),sum(r[1] for r in cases),
      'core-layer count',dict(Counter(r[2] for r in cases)))
if sys.argv[1:]==['census']:
    for (a,b),w,side,center,edges,forced in cases:
        print(a,b,w,side,center,edges,forced)
    sys.exit()
start=int(sys.argv[1]) if len(sys.argv)>1 else 0
stop=int(sys.argv[2]) if len(sys.argv)>2 else 265
run(rows,start,stop,'reverse' in sys.argv)
