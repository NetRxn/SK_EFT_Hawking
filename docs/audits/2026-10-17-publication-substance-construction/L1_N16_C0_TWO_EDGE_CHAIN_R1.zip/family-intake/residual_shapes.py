from collections import Counter
from pathlib import Path

folder=Path(__file__).parent
p=folder/"directed_roster.py"
module={"__file__":str(p)}
exec(p.read_text().split("\nselected=[]",1)[0],module)
projection,occupancy=(module[k] for k in ("projection","occupancy"))

def components(graph):
    left=set(graph)
    while left:
        members=set(min(left)[:2])
        while True:
            grown=members.union(*(e[:2] for e in left if members.intersection(e[:2])))
            if members==grown:
                break
            members=grown
        edges={e:graph[e] for e in left if members.intersection(e[:2])}
        left.difference_update(edges)
        yield edges

def shape(edges):
    deg=Counter(v for e in edges for v in e[:2])
    weights=tuple(sorted(tuple(sorted(p)) for p in edges.values()))
    if len(edges)==4 and set(deg.values())=={2}:
        roots={u if a else v for (u,v,_),(a,b) in edges.items()}
        name="double" if any(a and b for a,b in edges.values()) else ("directed" if len(roots)==4 else "zigzag")
    else:
        name=f"{len(deg)}v{len(edges)}e"
    return name,weights

rows=[tuple(map(int,line.split())) for line in (folder/"accepted-residual.tsv").read_text().splitlines()]
assert (len(rows),sum(w for a,b,w in rows))==(10410,899691)
groups=Counter()
counts=Counter()
examples={}
for a,b,w in rows:
    projected=projection(a,b,2)
    assert projected is not None
    parts=tuple(tuple(sorted(shape(g) for g in components(layer))) for layer in projected[0])
    key=(tuple(sorted(parts)),all(n%2==0 for row in occupancy(a)+occupancy(b) for n in row))
    groups[key]+=w
    counts[key]+=1
    examples.setdefault(key,(a,b,w))
assert sum(groups.values())==899691 and sum(counts.values())==10410
for key,w in groups.most_common(24):
    print(w,counts[key],examples[key],key)
