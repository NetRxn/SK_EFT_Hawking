#define main reference_main
#include "slice_reference.cpp"
#undef main
#include <map>
#include <span>
#include <set>

// The four independent S3 variables are distinguished by anchor and chirality.
int scaled_moment(std::span<const int> indices) {
    std::array<int,16> exponent{};
    for(int i:indices) ++exponent.at(i);
    int numerator=1,denominator=1;
    for(int group=0;group<4;++group){
        int degree=0;
        for(int i=4*group;i<4*group+4;++i){
            if(exponent[i]%2) return 0;
            degree+=exponent[i];
            for(int k=1;k<exponent[i];k+=2) numerator*=k;
        }
        for(int k=0;k<degree;k+=2) denominator*=4+k;
    }
    if(11520*numerator%denominator) throw std::runtime_error("Haar scale is not integral");
    return 11520*numerator/denominator;
}
int bucket(unsigned p){
    if(!p)return 0;
    if(std::popcount(p)!=2)return -1;
    int a=std::countr_zero(p),b=std::countr_zero(p&(p-1));
    return 1+16*a+b;
}
unsigned qmask(int p){
    if(!p)return 0;
    --p;return (1U<<(p/16))|(1U<<(p%16));
}

int main(){
    const auto src=read_coframes();
    using Group=std::map<unsigned,std::vector<Quad>>;
    std::array<std::array<std::array<Group,257>,16>,2> table;
    std::vector<int> words;
    for(int a=0;a<4;++a)for(int b=a;b<4;++b)words.push_back(4*a+b);
    for(int owner=0;owner<2;++owner)for(int word:words){
        auto rows=square_pair(src[owner][word/4],src[owner][word%4]);
        for(int p=0;p<257;++p)
            for(const auto& row:rows[p]) table[owner][word][p][row.mask].push_back(row);
    }
    std::set<std::pair<int,int>> pairs;
    std::ifstream source("adjoint.tsv");
    int row,col,i,j,z;
    while(source>>row>>col>>i>>j>>z)pairs.insert({i,j});
    if(pairs.size()!=10)throw std::runtime_error("adjoint coordinate roster");

    // Fixed channel, both anchors. Kind 0 is quadratic, 1 is same-owner
    // quartic, 2 is mixed-owner quartic ordered lower owner then upper owner.
    for(int chi=0;chi<2;++chi)for(int owner=0;owner<2;++owner)
        for(int kind=0;kind<3;++kind){
        if(kind==2&&owner==1)continue;
        auto visit=[&](std::array<int,4> q,auto first,auto second){
            unsigned mask=0;
            for(int x:q)mask^=1U<<x;
            for(int u:words){
                if(kind==0){
                    int p=bucket(mask);
                    if(p>=0)for(const auto& [m,X]:table[owner][u][p])first(u,X);
                }else for(int v:words){
                    if(kind==1&&v/4<u%4)continue;
                    for(int p=0;p<257;++p){
                        int t=bucket(qmask(p)^mask);
                        if(t<0)continue;
                        for(const auto& [m,X]:table[owner][u][p])
                            for(const auto& [n,Y]:table[kind==2?1-owner:owner][v][t])
                                if(!(m&n))second(u,v,X,Y);
                    }
                }
            }
        };
        auto groups=[&](auto handle){
            for(auto [i,j]:pairs)for(auto [a,b]:pairs)
                handle(std::array{i+4*chi,j+4*chi,a+8+4*chi,b+8+4*chi});
        };
        U64 total=0,peak=0;
        groups([&](auto q){
            U64 work=0;
            visit(q,[&](int,const auto& X){work+=X.size();},
                 [&](int,int,const auto& X,const auto& Y){work+=U64(X.size())*Y.size();});
            total+=work;peak=std::max(peak,work);
        });
        if(total>50'000'000||I128(11520)*64*64*64*64*peak>=(I128(1)<<62))
            throw std::runtime_error("prospective paired moment cap");
        U64 count=0,peak_rows=0;
        groups([&](auto q){
            std::map<unsigned,Z> values;
            auto append=[&](unsigned key,Z value){
                if(!values.contains(key)&&values.size()>=150000)
                    throw std::runtime_error("paired row cap");
                values[key]+=value;
            };
            visit(q,[&](int u,const auto& X){
                for(const auto& x:X)append((u<<20)|x.mask,
                    x.value*scaled_moment(std::array{q[0],q[1],q[2],q[3],x.a,x.b}));
            },[&](int u,int v,const auto& X,const auto& Y){
                for(const auto& x:X)for(const auto& y:Y){
                    if(x.mask&y.mask)throw std::runtime_error("mask partition");
                    int m=scaled_moment(std::array{q[0],q[1],q[2],q[3],x.a,x.b,y.a,y.b});
                    append((u<<20)|(v<<16)|x.mask|y.mask,
                           x.value*y.value*(sign(x.mask,y.mask)*m));
                }
            });
            peak_rows=std::max(peak_rows,U64(values.size()));
            for(const auto& [key,v]:values)if(v){
                ++count;
                std::cout<<chi<<' '<<owner<<' '<<kind;
                for(int x:q)std::cout<<' '<<x;
                std::cout<<' '<<(key>>20)<<' '<<((key>>16)&15)<<' '
                         <<(key&65535)<<' '<<v.re<<' '<<v.im<<'\n';
            }
        });
        std::cerr<<chi<<' '<<owner<<' '<<kind<<" products "<<total
                 <<" peak coordinate products "<<peak<<" rows "<<count
                 <<" peak allocated "<<peak_rows<<'\n';
    }
}
