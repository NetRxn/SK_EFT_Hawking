from collections import defaultdict
from contextlib import ExitStack
from itertools import groupby
from pathlib import Path
from tempfile import TemporaryDirectory

ROW_CAP=150_000
PRODUCT_CAP=2_000_000
source=defaultdict(list)
for line in Path("AUTHOR/adjoint.tsv").open():
    row,col,i,j,c=map(int,line.split())
    source[tuple(sorted((i,j)))].append((row,col,c))
assert len(source)==10 and sum(map(len,source.values()))==24

def records():
    with Path("chain/paired.tsv").open() as f:
        for line in f:
            values=tuple(map(int,line.split()))
            yield values[:3],values[3:]

directory=Path("chain")
with (directory/"paired-matrices.tsv").open("w") as output:
    for (chi,owner,kind),group in groupby(records(),key=lambda r:r[0]):
        with TemporaryDirectory(dir=directory,prefix="paired-partition-") as paths:
            word_paths={}
            planned=defaultdict(int)
            with ExitStack() as files:
                opened={}
                for _,rec in group:
                    i,j,p,q,u,v,mask,re,im=rec
                    a=source[i%4,j%4]
                    b=source[p%4,q%4]
                    planned[u]+=len(a)*len(b)
                    if planned[u]>PRODUCT_CAP:
                        raise RuntimeError(("prospective word product cap",chi,owner,kind,u,planned[u]))
                    if u not in opened:
                        word_paths[u]=Path(paths)/str(u)
                        opened[u]=files.enter_context(word_paths[u].open("w"))
                    opened[u].write(" ".join(map(str,rec))+"\n")
            peak=live=products=0
            for u,path in sorted(word_paths.items()):
                accum={}
                measured=0
                for line in path.open():
                    i,j,p,q,word,v,mask,re,im=map(int,line.split())
                    assert word==u
                    for a,b,c in source[i%4,j%4]:
                        for d,e,f in source[p%4,q%4]:
                            key=v,mask,a,b,d,e
                            prev=accum.get(key)
                            if prev is None:
                                if len(accum)>=ROW_CAP:
                                    raise RuntimeError(("word row cap",chi,owner,kind,u))
                                prev=0,0
                            n=c*f
                            accum[key]=prev[0]+n*re,prev[1]+n*im
                            measured+=1
                assert measured==planned[u]
                products+=measured
                peak=max(peak,len(accum))
                for key,z in sorted(accum.items()):
                    if any(z):
                        output.write(" ".join(map(str,(chi,owner,kind,u,*key,*z)))+"\n")
                        live+=1
            print(chi,owner,kind,"words",len(word_paths),"products",products,
                  "peak tile products",max(planned.values()),"peak allocated rows",peak,
                  "nonzero",live,flush=True)
