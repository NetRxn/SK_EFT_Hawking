from collections import Counter
from fractions import Fraction as F
from functools import cache
from itertools import product
from math import prod
from pathlib import Path

pairs=(((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2)))
matrix_terms={}
for line in Path("AUTHOR/adjoint.tsv").open():
    a,b,i,j,r=map(int,line.split())
    m=matrix_terms.setdefault((a,b),Counter())
    m[tuple(sorted((i,j)))]+=r
assert len(matrix_terms)==9

@cache
def sphere(word):
    exp=tuple(word.count(i) for i in range(4))
    if any(n%2 for n in exp):
        return F(0)
    return F(prod(prod(range(1,n,2)) for n in exp),prod(range(4,4+len(word),2)))

@cache
def coordinate(variables):
    poly={():1}
    for cell in variables:
        nxt=Counter()
        for w,v in poly.items():
            for u,r in matrix_terms[cell].items():
                nxt[tuple(sorted(w+u))]+=v*r
        poly={k:v for k,v in nxt.items() if v}
    return sum((c*sphere(word) for word,c in poly.items()),F(0))

def agree(values,pairing):
    return all(values[i]==values[j] for i,j in pairing)

def orthogonal(variables):
    if not variables:return F(1)
    rows,cols=zip(*variables)
    if len(variables)==2:return F(int(rows[0]==rows[1] and cols[0]==cols[1]),3)
    assert len(variables)==4
    return sum((F(4 if i==j else -1,30)
                for i,p in enumerate(pairs) for j,q in enumerate(pairs)
                if agree(rows,p) and agree(cols,q)),F(0))

n=0
for size in (2,4):
    for variables in product(sorted(matrix_terms),repeat=size):
        assert coordinate(tuple(sorted(variables)))==orthogonal(variables),variables
        n+=1
print(n,"exact ordered coordinate controls agree with the orthogonal Gram formula")

def states(channel):
    width=1 if channel==0 else 3
    return product(range(width),repeat=4)

with Path("chain/central.tsv").open("w") as out:
    for c,d in product(range(3),repeat=2):
        live=0
        for (i,j,k,l),(a,b,e,f) in product(states(c),states(d)):
            left=((k,j),(l,i)) if c else ()
            right=((e,b),(f,a)) if d else ()
            value=orthogonal(left+right) if c==d else orthogonal(left)*orthogonal(right)
            if value:
                scaled=value*90
                assert scaled.denominator==1
                out.write(" ".join(map(str,(c,d,i,j,k,l,a,b,e,f,scaled.numerator)))+"\n")
                live+=1
        print(c,d,live,"nonzero central coefficients")
