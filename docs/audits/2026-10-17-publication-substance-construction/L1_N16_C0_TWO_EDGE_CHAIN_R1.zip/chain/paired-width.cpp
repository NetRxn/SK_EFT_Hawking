#define main reference_main
#include "slice_reference.cpp"
#undef main
#include <map>
#include <set>

using BucketCounts=std::array<std::map<unsigned,U64>,257>;
using Tables=std::array<std::array<BucketCounts,16>,2>;

int bucket(unsigned p){
    if(!p)return 0;
    if(std::popcount(p)!=2)return -1;
    return 1+16*std::countr_zero(p)+std::countr_zero(p&(p-1));
}
unsigned parity(int bucket){
    if(!bucket)return 0;
    --bucket;
    return (1U<<(bucket/16))|(1U<<(bucket%16));
}

int main(){
    const auto src=read_coframes();
    Tables P;
    std::vector<int> words;
    for(int a=0;a<4;++a)for(int b=a;b<4;++b)words.push_back(4*a+b);
    for(int owner=0;owner<2;++owner)for(int w:words){
        auto rows=square_pair(src[owner][w/4],src[owner][w%4]);
        for(int p=0;p<257;++p)for(const auto& row:rows[p])++P[owner][w][p][row.mask];
    }
    std::array<std::set<std::pair<int,int>>,4> pairs;
    pairs[0].insert({0,0});
    std::ifstream spin("adjoint.tsv"),cross("fundamental-product.tsv");
    int a,b,i,j,r,s;
    while(spin>>a>>b>>i>>j>>r)for(int k=0;k<2;++k)
        pairs[k+1].insert({i+4*k,j+4*k});
    while(cross>>a>>b>>i>>j>>r>>s)pairs[3].insert({i,j});
    if(pairs[1].size()!=10||pairs[2].size()!=10||pairs[3].size()!=16)
        throw std::runtime_error("paired representation roster");

    // Edge support counts share all distinct lower/upper quaternion pairs
    // with the same parity and then expand only disjoint masks.
    for(int k=0;k<4;++k){
        std::map<unsigned,U64> parities;
        for(auto [i0,j0]:pairs[k])for(auto [i1,j1]:pairs[k]){
            unsigned mask=(1U<<i0)^(1U<<j0)^(1U<<(i1+8))^(1U<<(j1+8));
            ++parities[mask];
        }
        for(int owner=0;owner<2;++owner)for(int kind=0;kind<3;++kind){
            if(kind==2&&owner==1)continue;
            U64 total=0,max_pair=0,max_tile=0;
            for(const auto& [mask,multiplicity]:parities){
                U64 work=0;
                for(int u:words){
                    U64 tile=0;
                    if(kind==0){
                        const int p=bucket(mask);
                        if(p>=0)for(const auto& [m,n]:P[owner][u][p])tile+=n;
                    }else{
                        for(int v:words){
                            // Same-owner quartics use a sorted four-letter word.
                            if(kind==1&&v/4<u%4)continue;
                            for(int p=0;p<257;++p){
                                int q=bucket(parity(p)^mask);
                                if(q<0)continue;
                                for(const auto& [m,n]:P[owner][u][p])
                                    for(const auto& [o,z]:P[kind==2?1-owner:owner][v][q])
                                        if(!(m&o))tile+=n*z;
                            }
                        }
                    }
                    work+=tile;
                    max_tile=std::max(max_tile,tile);
                }
                total+=work*multiplicity;
                max_pair=std::max(max_pair,work);
            }
            std::cout<<"channel "<<k<<" owner "<<owner<<" kind "<<kind
                     <<" coordinate pair combinations "<<pairs[k].size()*pairs[k].size()
                     <<" parity groups "<<parities.size()<<" products "<<total
                     <<" max coordinate pair "<<max_pair<<" max pair-first-word "<<max_tile<<'\n';
        }
    }
}
