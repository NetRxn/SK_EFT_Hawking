from fractions import Fraction as F
from itertools import product
from math import prod
from pathlib import Path
from functools import lru_cache

# Reuse the source-pinned representation and conditional-root controls.
source=Path("AUTHOR/square_control.py").read_text().split("\nq2=list",1)[0]
source=source.replace('Path("','Path("AUTHOR/')
env={}
exec(source,env)
reg=env['reg']
P,Q,S=env['Polynomial'],env['QComplex'],env['Symbol']
link,plaquette=env['original_spin4_link'],env['original_plaquette']
rep,fmat,dagger,transpose,tr,mm=(env[k] for k in ('rep','fmat','dagger','transpose','tr','mm'))
haar=env['original_quaternion_haar_moment']
O=env['O']
def polynomial_rep(q,k,d):
    if k==0:
        return ((P.scalar(1),),)
    out=[[P() for _ in range(d)] for _ in range(d)]
    if k in (1,2):
        for a,b,i,j,r in env['R']:
            out[a][b]+=q[k-1][i]*q[k-1][j]*r
    else:
        flat=q[0]+q[1]
        for a,b,i,j,r,s in env['D']:
            out[a][b]+=flat[i]*flat[j]*Q(r,s)
    return tuple(map(tuple,out))
coords=env['coords']

def point(vertex):
    return (0,*((vertex>>k)&1 for k in range(3)))

@lru_cache(None)
def weight(indices):
    return prod(haar(tuple(indices.count((chir,i)) for i in range(4))) for chir in ('L','R'))

def integrate(poly, site):
    terms=[]
    for keys,z in poly.terms:
        selected=tuple((key.index[-2],key.index[-1]) for key in keys if key.index[0]==site)
        rest=tuple(key for key in keys if key.index[0]!=site)
        moment=weight(selected)
        if moment:
            terms.append((rest,z*moment))
    return P(tuple(terms))

def checked_product(a,b):
    work=len(a.terms)*len(b.terms)
    if work>2_000_000:
        raise RuntimeError(('polynomial product cap',work))
    return a*b,work

def scalar(p):
    assert len(p.terms)<=1 and not any(k for k,z in p.terms)
    return p.terms[0][1] if p else Q()

chain=((2,6,3),(4,6,2))
center=point(6)
V={point(v):tuple(tuple(P.variable(S('q',(point(v),0,c,i))) for i in range(4))
                  for c in ('L','R')) for v in (2,4,6)}
for profile in range(2):
    links={(x,0):link(*q) for x,q in V.items()}
    fixed={}
    for j,(left,right,axis) in enumerate(chain):
        for k,(v,side) in enumerate(product((left,right),range(2))):
            q=(coords[(1+k+2*j)%len(coords)],coords[(1+2*k+j)%len(coords)]) if profile else (coords[0],)*2
            x=point(v)
            if side:x=reg.step(x,0)[0]
            links[x,axis]=link(*q)
            fixed[v,side,axis]=q
    literal,reduced=[],[]
    work=[]
    for leaf,v,axis in chain:
        x,y=point(leaf),point(v)
        assert y==reg.step(x,axis)[0]
        roots=[]
        for u in (x,y):
            H=plaquette(reg,u,0,axis,links)
            L=sum((H[a][b]*O[b][a] for a,b in product(range(4),repeat=2)),P())
            square,n=checked_product(L,L)
            roots.append(square)
            work.append(n)
        product_at_edge,n=checked_product(*roots)
        work.append(n)
        literal.append(integrate(product_at_edge,x))

        value=P()
        for k,d in enumerate((1,3,3,4)):
            a,b=rep(fixed[leaf,0,axis],k),rep(fixed[leaf,1,axis],k)
            c,g=rep(fixed[v,0,axis],k),rep(fixed[v,1,axis],k)
            VV=polynomial_rep(V[y],k,d)
            X=mm(transpose(fmat(k)),dagger(a))
            Y=mm(transpose(fmat(k)),dagger(c))
            # Haar at the independent leaf pairs U with U† and gives d^-1.
            value+=tr(mm(mm(mm(mm(Y,X),dagger(VV)),mm(b,g)),VV))*F(1,d)
        reduced.append(value)
    direct_poly,n=checked_product(*literal); work.append(n)
    reduced_poly,n=checked_product(*reduced); work.append(n)
    full=scalar(integrate(direct_poly,center))
    schur=scalar(integrate(reduced_poly,center))
    separate=prod(scalar(integrate(q,center)) for q in reduced)
    assert full==schur
    print("profile",profile,"literal",full.storage,"Schur",schur.storage,
          "independent-center mutant",separate.storage,"peak products",max(work),
          "leaf rows",[len(p.terms) for p in literal],"central rows",len(reduced_poly.terms))
    if profile: assert full!=separate
