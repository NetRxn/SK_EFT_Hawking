from collections import defaultdict
from pathlib import Path

totals=defaultdict(lambda:(0,0))
for line in Path("chain/paired.tsv").open():
    chi,owner,kind,i,j,p,q,u,v,mask,re,im=map(int,line.split())
    assert i//4==j//4==chi and p//4==q//4==chi+2
    if i!=j or p!=q:
        continue
    lo,hi=mask&255,mask>>8
    if kind==1:
        u=16*u+v
        v=0
    if owner==1:lo,hi=hi,lo
    key=(chi,owner,kind,u,v,lo,hi)
    r,s=totals[key]
    totals[key]=r+re,s+im

existing={}
for line in Path("AUTHOR/edge.tsv").open():
    d,w,lo,hi,r,s=map(int,line.split())
    scale=2880 if d==2 else 240
    existing[0 if d==2 else 1,w,0,lo,hi]=(scale*r,scale*s)
for line in Path("AUTHOR/mixed.tsv").open():
    u,v,lo,hi,r,s=map(int,line.split())
    existing[2,u,v,lo,hi]=(240*r,240*s)
for chi in range(2):
    for owner in range(2):
        wanted={k:v for k,v in existing.items() if not owner or k[0]!=2}
        actual={k:v for (c,o,*parts),v in totals.items()
                if c==chi and o==owner and any(v) for k in (tuple(parts),)}
        assert actual==wanted,(chi,owner,len(actual),len(wanted))
        print(chi,owner,len(actual),"identity contractions match prior scalar exactly")
