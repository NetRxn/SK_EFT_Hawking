Restore the sibling directed-square pilot archive. Put its AUTHOR/ and
INDEPENDENT/ source directories and sew_square_pilot.py in this archive's
root. The files in chain/ and family-intake/ are frozen author inputs
and outputs, with manifests checked from the archive root. In independent/,
link INDEPENDENT to ../INDEPENDENT and frozen to the archive root. Follow
independent/REVIEW.md for reproduction. The new residual subtracts precisely
265 independently accepted rows. It excludes the pending forest and
shared-edge cohorts.
