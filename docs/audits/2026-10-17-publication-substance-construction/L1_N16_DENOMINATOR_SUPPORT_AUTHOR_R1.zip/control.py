"""Executable controls for structural Boolean semantics and prospective refusals."""
from itertools import product
import json
import preflight as p

# Repeated shared coordinate cancels in parity, independently of the two
# matrix/chiral indices. Reversed directed anchor is a separate coordinate.
s=[p.Symbol("q",(x,0,h,0)) for x in p.SEPARATOR for h in ("L","R")]
assert len({p.BASIS[x] for x in s})==4
union,parity=p.key_masks((s[0],s[0],s[1],s[2]))
assert parity==sum(1<<p.BASIS[x] for x in s[1:3])
assert union==sum(1<<p.BASIS[x] for x in s[:3])

# Independent explicit tuples compare projected semiring operations. Keep
# both directed physical coordinates as distinguishable bit identities.
a={(1,1),(2,4)}
b={(1,2),(4,1)}
expected={(x+y,q^r) for (x,q),(y,r) in product(a,b) if x&y==0}
budget=p.Budget()
assert budget.multiply(a,b,len(a)+len(b),"overlap/parity")==expected
assert budget.joins==4 and budget.peak==7
assert (5,0) in expected and (1,3) not in expected

p.STATE_CAP=6
try:
    p.Budget().multiply(a,b,len(a)+len(b),"records")
except p.Refusal as exc:
    assert exc.details==dict(phase="records",kind="logical_support_records",prospective=7,cap=6)
else:
    raise AssertionError("record cap")
p.STATE_CAP=8192
p.JOIN_CAP=3
try:
    p.Budget().multiply(a,b,len(a)+len(b),"pairs")
except p.Refusal as exc:
    assert exc.details==dict(phase="pairs",kind="attempted_pairs",prospective=4,cap=3)
else:
    raise AssertionError("pair cap")
print(json.dumps(dict(distinct_anchored_chiral_labels=4,possible_pairs=4,
    retained_pairs=len(expected),both_prospective_refusals=True)))
