"""Independent direct c14 support control using rational elimination and a full scan."""
from collections import Counter
from fractions import Fraction
from itertools import combinations_with_replacement
from math import factorial,prod
from pathlib import Path
import json,sys

from preflight import REG,RANK

N=16
D=384
SITE_IDS=tuple(range(N))
NEIGHBORS=tuple(tuple(RANK[REG.step(site,mu)[0]] for mu in range(4)) for site in REG.sites)


def invert():
    # Fix q_0 and solve the 15×15 principal minor directly. No Walsh transform.
    coords=SITE_IDS[1:]
    matrix=[[Fraction(4*(i==j)+int(j in NEIGHBORS[i])) for j in coords]+
            [Fraction(i==j) for j in coords] for i in coords]
    for j in range(N-1):
        pivot=next(i for i in range(j,N-1) if matrix[i][j])
        matrix[j],matrix[pivot]=matrix[pivot],matrix[j]
        matrix[j]=[value/matrix[j][j] for value in matrix[j]]
        for i in range(N-1):
            if i!=j:
                weight=matrix[i][j]
                matrix[i]=[a-weight*b for a,b in zip(matrix[i],matrix[j])]
    return [row[N-1:] for row in matrix]


def adjusted(site,a,b,inverse):
    demand=[0]*N
    demand[site]=2
    demand[NEIGHBORS[site][a]]+=1
    demand[NEIGHBORS[site][b]]+=1
    solved=[Fraction(0)]+[-D*sum(k*v for k,v in zip(row,demand[1:])) for row in inverse]
    assert all(q.denominator==1 for q in solved)
    exact=tuple(int(x) for x in solved)
    assert all(4*exact[x]+sum(exact[y] for y in NEIGHBORS[x])==-D*demand[x] for x in SITE_IDS)
    return exact


def main():
    out=Path(sys.argv[1])
    labels=[(x,a,b) for x in SITE_IDS for a in range(4) for b in range(a+1,4)]
    inv=invert()
    raw=[adjusted(*label,inv) for label in labels]
    modular=[[v[k]%D for v in raw] for k in range(1,N)]
    first,second,*remaining=modular
    observed=set()
    passed=0
    visits=0
    for a,b,c,d in combinations_with_replacement(range(96),4):
        visits+=1
        if ((first[a]+first[b]+first[c]+first[d])%D
            or (second[a]+second[b]+second[c]+second[d])%D):
            continue
        if any((row[a]+row[b]+row[c]+row[d])%D for row in remaining):
            continue
        passed+=1
        p=Counter(labels[i][0] for i in (a,b,c,d))
        planes=tuple(labels[i] for i in (a,b,c,d))
        delta=[(raw[a][x]+raw[b][x]+raw[c][x]+raw[d][x])//D for x in SITE_IDS]
        for q0 in range(3):
            q=tuple(v+(q0 if x.bit_count()%2==0 else 2-q0)
                    for x,v in enumerate(delta))
            if all(v>=0 and 2*p[x]+4*v<=8 for x,v in enumerate(q)):
                observed.add((planes,q))
    assert visits==3_764_376 and passed==1320
    seen=0
    with (out/"c14-occupancy-roster.jsonl").open() as receipt:
        for line in receipt:
            item=json.loads(line)
            planes=tuple(map(tuple,item["planes"]))
            q=tuple(item["S4_occupations"])
            assert (planes,q) in observed
            observed.remove((planes,q))
            assert sum(q)==14
            expected=prod(factorial(n) for n in (*Counter(planes).values(),*q))
            assert expected==item["exponential_divisor"]
            seen+=1
    assert seen==1968 and not observed
    print(json.dumps(dict(direct_quadruple_visits=visits,integer_completions=passed,
                          exact_roster_records=seen,independent_linear_solver="15x15 Fraction principal minor")))


if __name__=="__main__":
    main()
