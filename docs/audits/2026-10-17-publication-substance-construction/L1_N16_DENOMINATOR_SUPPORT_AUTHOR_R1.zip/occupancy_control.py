"""Complete pure-S4 occupancy control and all nine projected incidence profiles."""
from collections import Counter
from itertools import combinations_with_replacement
from pathlib import Path
import json,sys

from preflight import REG, RANK, ALTS


def pure_cosmological(neighbors):
    # Count every structurally feasible occupation, pruning only constraints
    # whose reachable interval cannot contain the original eight-site count.
    completed=[]
    attempted=0
    values=[None]*16

    def walk(i):
        nonlocal attempted
        if i==16:
            completed.append(tuple(values))
            return
        for m in range(3):
            attempted+=1
            values[i]=m
            for x,nn in enumerate(neighbors):
                local=tuple(values[n] for n in nn)
                existing=(4*(values[x] or 0))+sum(t or 0 for t in local)
                available=(8 if values[x] is None else 0)+2*local.count(None)
                if existing>8 or existing+available<8:
                    break
            else:
                walk(i+1)
        values[i]=None
    walk(0)
    assert set(completed)=={
        (1,)*16,
        tuple(2*(sum(x)%2==0) for x in REG.sites),
        tuple(2*(sum(x)%2==1) for x in REG.sites),
    }
    return attempted,completed


def main():
    base=Path(sys.argv[1])
    source=json.loads((base/"support-census.json").read_text())
    neighbors=[[RANK[REG.step(x,axis)[0]] for axis in range(4)] for x in REG.sites]
    plane_sets=[]
    for i,s in enumerate(source["sites"]):
        assert tuple(s["site"])==REG.sites[i]
        for cof in s["coframes"]:
            mu,_=cof["components"]
            x,y=i,neighbors[i][mu]
            assert cof["scope"][0]==(0xff << (x*8))|(0xff << (y*8))
        planes=set()
        for deg,components,_,_ in s["grouped_branches"]:
            directions=tuple(sorted(mu for mu,_ in components))
            if deg==4:
                assert directions==(0,1,2,3)
            else:
                assert len(directions)==2 and directions[0]<directions[1]
                planes.add(directions)
        assert len(planes)==6
        plane_sets.append(planes)
    assert all(x==plane_sets[0] for x in plane_sets)
    attempted,completions=pure_cosmological(neighbors)
    local=[]
    for p,q in ALTS:
        profiles=set()
        for planes in combinations_with_replacement(sorted(plane_sets[0]),p):
            c=Counter(axis for plane in planes for axis in plane)
            profiles.add(tuple(q+c[axis] for axis in range(4)))
        assert all(sum(r)==2*p+4*q for r in profiles)
        local.append(dict(power=(p,q),site_occupation=2*p+4*q,
                          neighbor_occupations=sorted(profiles)))
    report=dict(pure_g1=dict(attempted=attempted,complete_allowed_classes=completions),
                local_power_profiles=local,
                boundary="Exact directional incidence after projecting component/fermion chirality/quaternion labels; support profiles can cancel or fail other constraints.")
    (base/"occupancy-control.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(dict(pure_g1_attempts=attempted,complete_allowed_classes=len(completions),
                          local_power_profiles=[(a["power"],len(a["neighbor_occupations"])) for a in local])))


if __name__=="__main__":
    main()
