"""Bounded complete directional occupancy enumeration for original g1^14 g2^4."""
from collections import Counter, defaultdict
from itertools import combinations_with_replacement
from hashlib import sha256
from math import comb, factorial, prod
from pathlib import Path
import json,sys

from preflight import REG,RANK,Budget,Refusal

N=16
D=384
PLANE_COUNT=4
SIGNS=tuple((-1)**x.bit_count() for x in range(N))
H=tuple(tuple((-1)**(x & character).bit_count() for x in range(N))
        for character in range(N))
LAMBDA=tuple(8-2*x.bit_count() for x in range(N))
NEIGHBORS=tuple(tuple(RANK[REG.step(site,mu)[0]] for mu in range(4)) for site in REG.sites)


def directions(source):
    actual=[]
    for row in source["sites"]:
        site=tuple(row["site"])
        assert len(site)==4
        local={tuple(sorted(mu for mu,_ in c)) for degree,c,*_ in row["grouped_branches"] if degree==2}
        assert len(local)==6 and all(len(p)==2 and p[0]<p[1] for p in local)
        actual.extend((RANK[site],a,b) for a,b in sorted(local))
    assert len(actual)==96
    return actual


def vector(site,a,b):
    """D times a particular correction to q_x=1, then remove its q_0 entry."""
    demand=[0]*N
    demand[site]=2
    demand[NEIGHBORS[site][a]]=1
    demand[NEIGHBORS[site][b]]=1
    transformed=[sum(c*n for c,n in zip(ch,demand)) for ch in H]
    assert transformed[-1]==0
    v=tuple(-sum((24//eigen)*n*ch[x] for eigen,n,ch in zip(LAMBDA,transformed,H) if eigen)
            for x in range(N))
    assert all(4*v[x]+sum(v[y] for y in NEIGHBORS[x])==-D*demand[x] for x in range(N))
    assert sum(v)==-D//2
    return tuple(v[x]-SIGNS[x]*v[0] for x in range(N))


def main():
    out=Path(sys.argv[1])
    source=json.loads((out/"support-census.json").read_text())
    labels=directions(source)
    raw=[vector(*label) for label in labels]
    residues=[tuple(n%D for n in v) for v in raw]
    coords=tuple(range(1,N))
    budget=Budget()
    groups=Counter()
    for a,b in combinations_with_replacement(range(len(raw)),2):
        budget.step("partition histogram")
        groups[(residues[a][1]+residues[b][1])%D]+=1
    unique_pairs=sum(groups.values())
    assert unique_pairs==4656
    survivors=0
    feasible=0
    checked=0
    q0_counts=Counter()
    pattern_types=Counter()
    examples=[]
    receipt=(out/"c14-occupancy-roster.jsonl").open('x')
    for part,count in sorted(groups.items()):
        opposite=(-part)%D
        if opposite not in groups:
            continue
        index=defaultdict(list)
        records=0
        retained=2*len(raw)+len(groups)
        for a,b in combinations_with_replacement(range(len(raw)),2):
            budget.step("build pair bucket")
            if (residues[a][1]+residues[b][1])%D != opposite:
                continue
            key=tuple((residues[a][k]+residues[b][k])%D for k in coords)
            budget.reserve("build pair bucket",retained+records+1+int(key not in index))
            records+=1+int(key not in index)
            index[key].append((a,b))
        assert sum(map(len,index.values()))==groups[opposite]
        for a,b in combinations_with_replacement(range(len(raw)),2):
            budget.step("probe pair bucket")
            if (residues[a][1]+residues[b][1])%D != part:
                continue
            key=tuple((-residues[a][k]-residues[b][k])%D for k in coords)
            for c,d in index.get(key,()):
                budget.step("canonical pair join")
                if b>c:
                    continue
                survivors+=1
                quads=(a,b,c,d)
                p=Counter(labels[j][0] for j in quads)
                if any(v>4 for v in p.values()):
                    continue
                delta=tuple(sum(raw[j][x] for j in quads)//D for x in range(N))
                assert all(sum(raw[j][x] for j in quads)%D==0 for x in range(N))
                good=0
                for q0 in range((8-2*p[0])//4+1):
                    budget.step("checkerboard completion")
                    q=tuple(1+(q0-1)*SIGNS[x]+delta[x] for x in range(N))
                    if any(t<0 or 2*p[x]+4*t>8 for x,t in enumerate(q)):
                        continue
                    assert sum(q)==14
                    demand=[0]*N
                    for i in quads:
                        u,mu,nu=labels[i]
                        demand[u]+=2
                        demand[NEIGHBORS[u][mu]]+=1
                        demand[NEIGHBORS[u][nu]]+=1
                    assert all(4*q[x]+sum(q[y] for y in NEIGHBORS[x])+demand[x]==8 for x in range(N))
                    assert feasible < 2048, "c14 streamed metadata roster cap"
                    multiplicities=Counter(quads)
                    exp_divisor=prod(factorial(n) for n in (*multiplicities.values(),*q))
                    receipt.write(json.dumps(dict(planes=[labels[j] for j in quads],
                        S4_occupations=q,exponential_divisor=exp_divisor),
                        separators=(",",":"))+"\n")
                    feasible+=1
                    good+=1
                    q0_counts[q0]+=1
                    pattern_types[tuple(sorted(p.values()))]+=1
                    if len(examples)<6:
                        examples.append(dict(planes=[labels[j] for j in quads],S4_occupations=q))
                checked+=bool(good)
        del index
    receipt.close()
    digest=sha256((out/"c14-occupancy-roster.jsonl").read_bytes()).hexdigest()
    report=dict(roster_sha256=digest,roster_records=feasible,roster_record_cap=2048,
          g1_power=14,g2_power=4,actual_center_plane_labels=len(raw),
          complete_unordered_multisets=comb(len(raw)+3,4),unordered_pair_records=unique_pairs,
          bucket_count=len(groups),largest_bucket=max(groups.values()),
          integral_modular_quadruples=survivors,quadruples_with_legal_occupancy=checked,
          compatible_plane_multiset_and_s4_occupation_pairs=feasible,
          number_by_q0=dict(q0_counts),multiplicity_class=[[k,n] for k,n in sorted(pattern_types.items())],
          work=budget.joins,peak_logical_records=budget.peak,examples=examples,
          scope="Complete site directional occupation constraint. Exterior chirality/label collisions and quaternion parity/support and cancellation remain to qualify. No coefficient evaluated.")
    assert sum(q0_counts.values())==feasible
    assert checked>0 and survivors>=checked
    (out/"c14-walsh.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
