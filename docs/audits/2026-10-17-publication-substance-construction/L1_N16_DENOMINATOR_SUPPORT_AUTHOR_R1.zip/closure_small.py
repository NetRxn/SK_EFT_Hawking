"""Small original support control with actual completed last-use closures."""
from pathlib import Path
import json,sys
from closure_control import X,RANK,owner_domain,factors,measure


def main():
    p=Path(sys.argv[1])
    source=json.loads((p/"support-census.json").read_text())["sites"]
    center_bar0_and_psi0=(1|4) << (8*RANK[X])
    outgoing_left0_and_right0=0x11 << (32*RANK[X])
    actual={site:factors(site) for site in owner_domain(source,center_bar0_and_psi0,outgoing_left0_and_right0)}
    result=measure(center_bar0_and_psi0,outgoing_left0_and_right0,source,actual)
    assert result["refused"] is None and len(result["completed_layers"])==5
    assert result["completed_layers"][-1]["closed_fermion"]==center_bar0_and_psi0
    assert result["completed_layers"][-1]["closed_q"]==outgoing_left0_and_right0
    (p/"last-use-small.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
