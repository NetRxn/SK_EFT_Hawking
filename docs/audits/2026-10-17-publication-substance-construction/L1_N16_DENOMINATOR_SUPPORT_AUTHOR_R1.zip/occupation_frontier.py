"""All-center directional occupancy upper envelope, with last-use site saturation."""
from pathlib import Path
import json,sys

from preflight import REG,RANK,Budget,Refusal


def packs(site, rows):
    neighbors=[RANK[REG.step(site,axis)[0]] for axis in range(4)]
    n=RANK[site]
    lanes=[]
    for row in rows:
        p,q=row["power"]
        d=row["site_occupation"]
        for profile in row["neighbor_occupations"]:
            # Center and four neighbors are distinct on the periodic N16 cube.
            occupancy=(d<<(4*n))|sum(value<<(4*j) for j,value in zip(neighbors,profile))
            lanes.append((p,q,occupancy))
    return lanes


def site_scope(site):
    return {RANK[site],*(RANK[REG.step(site,axis)[0]] for axis in range(4))}


def run(order, rows, name, *, pure=False, target=None):
    state={(0,0,0)}
    past=set()
    budget=Budget()
    layers=[]
    refusal=None
    try:
        for i,site in enumerate(order):
            local=packs(site,rows)
            if target is not None:
                local=[item for item in local if item[0]<=target[0] and item[1]<=target[1]]
            if pure:
                local=[item for item in local if item[0]==0]
            seen=past|site_scope(site)
            future=set().union(*(site_scope(v) for v in order[i+1:]))
            close=(seen-future)-(past-set().union(*(site_scope(v) for v in order[i:])))
            frontier=seen&future
            keep=sum(15<<(4*j) for j in frontier)
            close_mask=sum(15<<(4*j) for j in close)
            close_value=sum(8<<(4*j) for j in close)
            prospective=0
            next_rows=set()
            for p,q,old in state:
                for a,b,part in local:
                    budget.step(f"{name} phase {i+1}")
                    combined=old+part
                    if combined&close_mask != close_value:
                        continue
                    # Nibble carry cannot occur on legal states, as 8+8=16.
                    # Test each candidate lane before treating packed addition
                    # as exact, including closed lanes.
                    if any(((old>>(4*j))&15)+((part>>(4*j))&15)>8 for j in seen):
                        continue
                    r,s=p+a,q+b
                    if target is not None and (r>target[0] or s>target[1]):
                        continue
                    d=2*r+4*s
                    if d>64 or d+8*(15-i)<64:
                        continue
                    prospective+=1
                    budget.insert(next_rows,(r,s,combined&keep),len(state)+len(local),f"{name} phase {i+1}")
            state=next_rows
            past=seen
            layers.append(dict(site=site,frontier_sites=sorted(frontier),closed_sites=sorted(close),
                local_profiles=len(local),accepted_pair_visits=prospective,boundary_records=len(state)))
        assert all(occ==0 and 2*p+4*q==64 for p,q,occ in state)
    except Refusal as e:
        refusal=e.details
    return dict(name=name,pure_g1_only=pure,target=target,steps=layers,peak_records=budget.peak,attempted_pairs=budget.joins,
            surviving_couplings=sorted((p,q) for p,q,_ in state) if refusal is None else None,
            refusal=refusal)


def main():
    d=Path(sys.argv[1])
    source=json.loads((d/"support-census.json").read_text())
    rows=json.loads((d/"occupancy-control.json").read_text())["local_power_profiles"]
    weighted=tuple(tuple(x) for x in source["order"]["weighted"]["order"])
    occupancy=[]
    for x in REG.sites:
        for a,b in zip(REG.sites,REG.sites[1:]):
            assert RANK[a]+1==RANK[b]
    occupancy=[run(weighted,rows,"full projected weighted order"),
               run(REG.sites,rows,"full projected lexical order"),
               run(weighted,rows,"pure projected weighted order",pure=True),
               run(weighted,rows,"targeted c14 weighted order",target=(4,14)),
               run(weighted,rows,"targeted c0 weighted order",target=(32,0))]
    assert occupancy[2]["surviving_couplings"]==[(0,16)]
    (d/"occupation-frontier.json").write_text(json.dumps(occupancy,indent=2)+"\n")
    print(json.dumps(occupancy,indent=2))


if __name__=="__main__":
    main()
