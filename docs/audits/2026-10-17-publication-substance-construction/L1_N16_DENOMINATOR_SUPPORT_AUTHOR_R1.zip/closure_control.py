"""Last-use Boolean contraction of the exact owners of one N16 site/anchor."""
from collections import defaultdict
from pathlib import Path
import json
import sys

from preflight import (REG, RANK, LINKS, X, Budget, Refusal, Polynomial,
                       original_action_factors, cof_rows, scope_union, local_support, powers)


def owner_domain(census, gm, qm):
    owned = {}
    for row in census:
        m = row["structural_domain"]
        g,q = m["fermion"]&gm,m["quaternion"]&qm
        if g or q:
            owned[tuple(row["site"])] = (g,q)
    return owned


def factors(site):
    coframes={(mu,a):cof_rows(site,mu,a) for mu in range(4) for a in range(4)}
    grouped=defaultdict(Polynomial)
    for factor in original_action_factors(REG,site,LINKS):
        # Same even local component identity used in the full census.
        components=tuple(sorted((mu,a) for _,mu,a in factor.components))
        grouped[factor.t_degree,components] += factor.coefficient
    return coframes,{k:v for k,v in grouped.items() if v}


def weighted_order(owned):
    todo = sorted(owned)
    visited=[]
    order=[]
    while todo:
        def key(site):
            pg,pq=scope_union((*owned[x],0) for x in [*visited,site])
            ng,nq=scope_union((*owned[x],0) for x in todo if x!=site)
            return (pg&ng).bit_count()+(pq&nq).bit_count(),site
        _,site=min(map(key,todo))
        todo.remove(site)
        visited.append(site)
        order.append(site)
    return order


def measure(gm,qm,source,actual):
    owners=owner_domain(source,gm,qm)
    sites=weighted_order(owners)
    budget=Budget()
    layers=[]
    out={(0,0):{(0,0)}}
    previous=(0,0)
    already_closed=(0,0)
    try:
        for i,site in enumerate(sites):
            live=sum(map(len,out.values()))
            sub=Budget()
            sub.peak,sub.joins=budget.peak,budget.joins
            old_reserve=sub.reserve
            sub.reserve=lambda phase,n:old_reserve(phase,live+n)
            cof,traces=actual[site]
            seed=local_support(cof,traces,gm,qm,sub)
            local=powers(seed,sub,0,[])
            budget.peak,budget.joins=sub.peak,sub.joins
            del seed,sub
            g,q=owners[site]
            seen=(previous[0]|g,previous[1]|q)
            future=scope_union((*owners[x],0) for x in sites[i+1:])
            close_g=seen[0]&~future[0]&~already_closed[0]
            close_q=seen[1]&~future[1]&~already_closed[1]
            next_rows={}
            retained=live+sum(map(len,local.values()))
            for (a,b),left in out.items():
                for (c,d),right in local.items():
                    grade=(a+c,b+d)
                    rows=next_rows.setdefault(grade,set())
                    for m,u in left:
                        for n,v in right:
                            budget.step(f"closure step {i+1}")
                            if m & n or ((m|n)&close_g)!=close_g or (u^v)&close_q:
                                continue
                            cand=((m|n)&~close_g,(u^v)&~close_q)
                            others=sum(len(values) for k,values in next_rows.items() if k!=grade)
                            budget.insert(rows,cand,retained+others,f"closure step {i+1}")
            out={k:v for k,v in next_rows.items() if v}
            layers.append(dict(site=site,local_count=sum(map(len,local.values())),
                closed_fermion=close_g,closed_q=close_q,
                frontier_fermion=(seen[0]&future[0]).bit_count(),
                frontier_q=(seen[1]&future[1]).bit_count(),
                boundary_records=sum(map(len,out.values())),coupling_grades=len(out)))
            already_closed=(already_closed[0]|close_g,already_closed[1]|close_q)
            previous=seen
            del next_rows,local
        assert previous==already_closed==(gm,qm)
        assert all(states=={(0,0)} for states in out.values())
        refusal=None
    except Refusal as exc:
        if "sub" in locals():
            budget.peak,budget.joins=sub.peak,sub.joins
        refusal=exc.details
    return dict(occupancy_mask=gm,parity_mask=qm,owners=sites,completed_layers=layers,
                surviving_projected_grades=sorted(out) if refusal is None else None,
                refused=refusal,peak_records=budget.peak,attempted_pairs=budget.joins)


def main():
    p=Path(sys.argv[1])
    source=json.loads((p/"support-census.json").read_text())["sites"]
    gm=0xff << (8*RANK[X])
    shift=32*RANK[X]
    qfull=0xff<<shift
    qsample=0x11<<shift
    actual={s:factors(s) for s in owner_domain(source,gm,qfull)}
    lanes=[measure(gm,q,source,actual) for q in (qfull,qsample)]
    (p/"last-use.json").write_text(json.dumps(lanes,indent=2)+"\n")
    print(json.dumps(lanes,indent=2))


if __name__=="__main__":
    main()
