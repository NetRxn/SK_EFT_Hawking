"""Bounded support of the original closed N16 action, without denominator evaluation."""
from collections import Counter, defaultdict
from hashlib import sha256
from itertools import product
from pathlib import Path
import json
import sys

from src.core.formulas import (
    original_action_factors, original_coframe_blocks, original_spin4_link,
)
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, Symbol, assemble_coframe,
)

REG = OriginalRegulator()
ALTS = tuple(sorted(
    ((p, q) for p, q in product(range(5), range(3)) if 2*p + 4*q <= 8),
    key=lambda pq: (2*pq[0]+4*pq[1], pq),
))
assert len(ALTS) == 9
RANK = {site: i for i, site in enumerate(REG.sites)}
BASIS = {
    Symbol("q", (site, axis, hand, k)): ((RANK[site] * 4 + axis) * 2 + side) * 4 + k
    for site, axis in REG.link_order
    for side, hand in enumerate(("L", "R"))
    for k in range(4)
}
LINKS = {
    anchor: original_spin4_link(*[
        tuple(Polynomial.variable(Symbol("q", (*anchor, hand, k))) for k in range(4))
        for hand in ("L", "R")
    ])
    for anchor in REG.link_order
}
GENERATOR_DOMAIN = (1 << 128)-1
QUATERNION_DOMAIN = (1 << 512)-1
STATE_CAP = 8192
JOIN_CAP = 20_000_000


def bits(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length()-1
        mask ^= low


def scope(g, q):
    return [g, q]


def key_masks(key):
    union, parity = 0, 0
    for s in key:
        bit = 1 << BASIS[s]
        union |= bit
        parity ^= bit
    return union, parity


def poly_rows(poly):
    return [(key, key_masks(key)) for key, _ in poly.terms]


def cof_rows(site, mu, a):
    blocks = original_coframe_blocks(REG, (site,mu,a), LINKS)
    exterior = assemble_coframe(REG, blocks).to_exterior(REG)
    return [(mask, union, parity) for mask, p in exterior.terms
            for _, (union,parity) in poly_rows(p)]


def scope_union(rows):
    g,q = 0,0
    for mask, union, _ in rows:
        g |= mask
        q |= union
    return g,q


def collect():
    census = []
    retained = {}
    scope_domains = {}
    for site in REG.sites:
        coframes = {(mu,a):cof_rows(site,mu,a) for mu,a in product(range(4),repeat=2)}
        co_scopes = {k:scope_union(rows) for k,rows in coframes.items()}
        raw = original_action_factors(REG,site,LINKS)
        counts = Counter(x.t_degree for x in raw)
        assert counts == {2:384,4:24}
        grouped = defaultdict(Polynomial)
        raw_scopes = []
        for factor in raw:
            # Degree-two coframes are even. Commuting them into a canonical
            # order groups only identical original local component monomials.
            components = tuple(sorted((mu,a) for _,mu,a in factor.components))
            grouped[factor.t_degree,components] += factor.coefficient
            co_scope = scope_union(row for c in components for row in coframes[c])
            trace = poly_rows(factor.coefficient)
            raw_trace_scope = scope_union((0,mask,p) for _,(mask,p) in trace)[1]
            raw_scopes.append([factor.t_degree,components,factor.anchors,len(trace),
                               scope(co_scope[0], co_scope[1] | raw_trace_scope)])
        nonzero = {k:v for k,v in grouped.items() if v}
        assert Counter(degree for degree, _ in nonzero) == {2:72,4:24}
        split = []
        for (degree,components), trace in sorted(nonzero.items()):
            trace_rows = poly_rows(trace)
            trace_mask = scope_union((0,m,p) for _,(m,p) in trace_rows)[1]
            outer = scope_union(row for c in components for row in coframes[c])
            split.append([degree,components,len(trace_rows),scope(outer[0],outer[1]|trace_mask)])
        combined = scope_union((row[3][0],row[3][1],0) for row in split)
        scope_domains[site] = combined
        census.append(dict(site=site,raw_count=dict(counts),grouped_nonzero_count={2:72,4:24},
            coframes=[dict(components=k,terms=len(v),scope=co_scopes[k]) for k,v in coframes.items()],
            raw_branches=raw_scopes,grouped_branches=split,
            structural_domain=dict(fermion=combined[0],quaternion=combined[1]),
            original_source_zero=True,local_coupling_powers=ALTS))
        if site in SEPARATOR:
            retained[site] = coframes, nonzero
    assert scope_union((*v,0) for v in scope_domains.values())==(GENERATOR_DOMAIN,QUATERNION_DOMAIN)
    return census, retained, scope_domains


def ordering(scopes):
    # Deterministic greedy site contraction. Measure the intersection of
    # processed and future scopes, not an optimizer's claimed lower bound.
    def union(sites):
        return scope_union((*scopes[s],0) for s in sites)
    def score(live):
        return live[0].bit_count()+live[1].bit_count()
    def run(greedy):
        todo = list(REG.sites)
        done = []
        frontiers = []
        while todo:
            def choose(s):
                left = union([*done,s])
                right = union([x for x in todo if x!=s])
                live = left[0]&right[0],left[1]&right[1]
                return score(live),s,live
            selected = min(map(choose,todo)) if greedy else choose(todo[0])
            value,site,live = selected
            todo.remove(site)
            done.append(site)
            frontiers.append(dict(site=site,occupancy_bits=live[0].bit_count(),
                chiral_parity_bits=live[1].bit_count(),weighted_log2=value,
                live_fermion_mask=live[0],live_quaternion_mask=live[1]))
        return dict(order=done, peak=max(x["weighted_log2"] for x in frontiers),steps=frontiers)
    return dict(weighted=run(True),lexical=run(False),
                model="complete site factors, split source incidences unioned at each still-live site selector")


class Refusal(Exception):
    def __init__(self, phase, kind, requested, cap):
        self.details=dict(phase=phase,kind=kind,prospective=requested,cap=cap)
        super().__init__(str(self.details))


class Budget:
    def __init__(self):
        self.peak,self.joins = 0,0

    def reserve(self, phase, records):
        if records>STATE_CAP:
            raise Refusal(phase,"logical_support_records",records,STATE_CAP)
        self.peak=max(self.peak,records)

    def step(self, phase):
        prospective=self.joins+1
        if prospective>JOIN_CAP:
            raise Refusal(phase,"attempted_pairs",prospective,JOIN_CAP)
        self.joins=prospective

    def insert(self, out, key, retained, phase):
        if key not in out:
            self.reserve(phase,retained+len(out)+1)
            out.add(key)

    def multiply(self, a,b,retained,phase):
        out=set()
        self.reserve(phase,retained)
        for g,q in a:
            for h,r in b:
                self.step(phase)
                if not g & h:
                    self.insert(out,(g|h,q^r),retained,phase)
        return out


def local_support(coframes,traces,gm,qm,budget):
    # Both masks are retained exactly within the chosen projection. If a
    # fermion bit is projected out, its collisions are deliberately ignored.
    # q parity is an XOR homomorphism; discarding parity never kills a path.
    co = {}
    for name,rows in coframes.items():
        co[name]=set()
        retained=sum(len(v) for k,v in co.items() if k!=name)
        for g,_,p in rows:
            budget.insert(co[name],(g&gm,p&qm),retained,"coframe projection")
    fixed=sum(map(len,co.values()))
    seeds={2:set(),4:set()}
    for (degree,components),poly in sorted(traces.items()):
        trace=set()
        for key,_ in poly.terms:
            budget.insert(trace,(0,key_masks(key)[1]&qm),
                          fixed+sum(map(len,seeds.values())),f"S{degree} trace")
        a=trace
        for i,c in enumerate(components):
            retained=fixed+sum(map(len,seeds.values()))+len(trace)+(len(a) if a is not trace else 0)
            a=budget.multiply(a,co[c],retained,f"S{degree} component {i+1}")
        for pair in a:
            budget.insert(seeds[degree],pair,fixed+sum(len(v) for k,v in seeds.items() if k!=degree)+len(a)+len(trace),
                          f"S{degree} source union")
        del a,trace
    return seeds


def powers(seeds,budget,base_count,power_ledger):
    # Fold a power from its earlier power, preserving exact local
    # multiplicities as labels, not combining equal total-degree grades.
    one={(0,0)}
    results={(0,0):one}
    for p,q in ALTS:
        if (p,q)==(0,0):
            continue
        prior=(p-1,q) if p else (p,q-1)
        source=seeds[2 if p else 4]
        results[p,q]=budget.multiply(results[prior],source,
            base_count+sum(map(len,seeds.values()))+sum(map(len,results.values())),
            f"local power {(p,q)}")
        power_ledger.append(dict(power=(p,q),states=len(results[p,q])))
    return results


def lane(retained,gm,qm,name,private_g,private_q):
    budget=Budget()
    counts={}
    layer={}
    completed=[]
    report=dict(name=name,fermion_mask=gm,quaternion_mask=qm,
                exact_retained_fermion_bits=gm.bit_count(),exact_retained_quaternion_parity_bits=qm.bit_count(),
                state_cap=STATE_CAP,join_cap=JOIN_CAP,
                private_projection=dict(fermion_mask=private_g,quaternion_mask=private_q),
                completed=completed,local_counts=counts)
    try:
        for site in SEPARATOR:
            co,traces=retained[site]
            sub=Budget()
            sub.peak,sub.joins=budget.peak,budget.joins
            base=sum(len(items) for v in layer.values() for items in v.values())
            # Reserve an already completed center for every internal check.
            # The wrapper closes over immutable live count for this phase.
            old_reserve=sub.reserve
            sub.reserve=lambda phase,n:old_reserve(phase,base+n)
            seed=local_support(co,traces,gm,qm,sub)
            ledger=[]
            counts[str(site)]=dict(S2=len(seed[2]),S4=len(seed[4]),powers=ledger)
            layer[site]=powers(seed,sub,0,ledger)
            budget.peak,budget.joins=sub.peak,sub.joins
            del seed,sub
            completed.append(site)
        live=sum(len(items) for v in layer.values() for items in v.values())
        out={}
        for (p,q),a in layer[SEPARATOR[0]].items():
            for (r,s),b in layer[SEPARATOR[1]].items():
                key=(p+r,q+s)
                if key not in out:
                    out[key]=set()
                for g,u in a:
                    for h,v in b:
                        budget.step("pair join")
                        if g & h or ((g|h)&private_g)!=private_g or (u^v)&private_q:
                            continue
                        candidate=((g|h)&~private_g,(u^v)&~private_q)
                        others=sum(len(z) for k,z in out.items() if k!=key)
                        budget.insert(out[key],candidate,live+others,"pair projection")
        report["pair_by_couplings"]=[dict(p=q[0],q=q[1],states=len(value))
                                      for q,value in sorted(out.items())]
    except Refusal as exc:
        report["refusal"]=exc.details
        if "sub" in locals():
            budget.peak,budget.joins=sub.peak,sub.joins
    report.update(peak_records=budget.peak,attempted_pairs=budget.joins)
    return report


X=REG.sites[0]
Y=REG.step(X,0)[0]
SEPARATOR=(X,Y)
PAIR_G=sum(0xff << (8*RANK[s]) for s in SEPARATOR)
PAIR_Q=sum(0xff << ((4*RANK[s])*8) for s in SEPARATOR)


def main():
    dest=Path(sys.argv[1])
    census,retained,scopes=collect()
    full_order=ordering(scopes)
    outside=scope_union((*v,0) for s,v in scopes.items() if s not in SEPARATOR)
    # A retained coordinate can be closed exactly only after its final owner.
    lanes=[]
    for name,gm,qm in (
        ("adjacent-center all exterior and full chiral parity",GENERATOR_DOMAIN,QUATERNION_DOMAIN),
        ("adjacent-center exact endpoint occupancy and reciprocal anchor parity",PAIR_G,PAIR_Q),
        ("adjacent-center exact endpoint occupancy and two distinguished chiral parity coordinates",
         PAIR_G,(1 << (RANK[X]*32)) | (1 << (RANK[Y]*32+4))),
    ):
        lanes.append(lane(retained,gm,qm,name,gm&~outside[0],qm&~outside[1]))
    raw=dict(regulator=dict(extents=REG.extents,boundary=REG.boundary_signs,word=REG.word,
                            convention=REG.convention,temporal_axis=REG.temporal_axis),
             bit_labels=dict(generators=REG.generator_order,
               quaternion=[s.index for s,i in sorted(BASIS.items(),key=lambda item:item[1])]),
             sites=census,order=full_order,separator=SEPARATOR,lanes=lanes)
    dest.write_text(json.dumps(raw,separators=(",",":"))+"\n")
    print(json.dumps(dict(raw_branch_count=sum(sum(r["raw_count"].values()) for r in census),
        per_site_scope={f"{g.bit_count()}/{q.bit_count()}" for g,q in scopes.values()} if False
             else sorted({(g.bit_count(),q.bit_count()) for g,q in scopes.values()}),
        weighted_peak=full_order["weighted"]["peak"],lexical_peak=full_order["lexical"]["peak"],
        lanes=lanes),indent=2))


if __name__=="__main__":
    main()
