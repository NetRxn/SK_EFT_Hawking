from pathlib import Path
import json,sys
a=Path(sys.argv[1])
def read(n):return json.loads((a/n).read_text())
p=read('q-admission.json');q=read('q-admission-refusal.json')
assert p['exact_basis_candidates']==[291072,291072] and p['prospective_worst_case']==3507156<4_000_000
assert q['exact_basis_candidates']==[504576,497664] and q['prospective_worst_case']==6051828>4_000_000
s=read('separation.json'); r=read('q-result.json')
assert sum(s['work'].values())==s['meters']['work']==1576066
assert s['meters']['rows']==6908
assert s['meters']['output']==sum((a/n).stat().st_size for n in ('interior-rays.jsonl','mask-weights.jsonl','weighted-mask-amplitude-0000.jsonl'))==207867
assert s['sampled_peak_rss_bytes']==63635456
assert sum(r['work'].values())==r['total_work']==3442116 and r['sampled_peak_rss']==23003136
assert not r['other_sectors_evaluated'] and not r['full_representative_evaluated']
assert (r['mask_numerator_gcd']*r['normalized_interior_scalar_numerator'][0]).bit_length()>127
u=read('result-0000.json'); v=read('result-0000-m003.json')
assert len(u['exact_completed_joins'])==14 and u['refusal']['prospective']==4102097
assert v['refusal']['prospective']==200001 and v['refusal']['kind']=='rows'
print('reported alternative refusals, successful metered work, bytes/RSS and necessary normalization payload bound checked')
