from collections import Counter,defaultdict
from functools import cache
from itertools import product
from math import gcd,prod
from pathlib import Path
import json,sys
A=Path(sys.argv[1])
def path(n):
    known={'core':'core-sewing-r1.P8b5DO','star':'edge-site-r1.nyn1YR','two':'rank-zero-r1.gte6BM',
           'sew':'shared-trace-r1.9tcmVn','r3':'rank3-r1.q1WfND','res':'residual-edge-r1.klcKMh'}
    return Path('/tmp/publication-c14-'+known[n])
def rows(f):
    with f.open() as s:
        for line in s:yield json.loads(line)
def load(f):return json.loads(f.read_text())
def f(x):return tuple(map(f,x)) if isinstance(x,(tuple,list)) else x
def plus(z,w):return z[0]+w[0],z[1]+w[1]
def mult(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def zz(x):return tuple(x) if isinstance(x,list) else (x,0)
graph=load(path('core')/'graph.json')
src={
 'rank8_edge0':('star','edge-0.jsonl'),'rank8_edge1':('star','edge-1.jsonl'),
 'rank0_edge1':('two','zero-edge-1.jsonl'),'rank0_edge2':('two','zero-edge-2.jsonl'),'rank0_edge3':('two','zero-edge-3.jsonl'),
 'trace0':('two','plane-01-trace.jsonl'),'trace1':('two','plane-01-trace.jsonl'),
 'trace2':('sew','trace-slices.jsonl'),'trace3':('sew','trace-slices.jsonl'),
 'partition_rank8':('star','site-factors.jsonl'),'partition_rank0':('two','zero-site-factors.jsonl'),
 'residual_edge':('res','residual-edge.jsonl'),'rank3_edge2':('r3','rank3-axis2.jsonl'),'rank3_edge3':('r3','rank3-axis3.jsonl'),
 'rank3_projection':('r3','rank3-projection.jsonl'),'merge_rank1':('r3','merge-rank1.jsonl'),'merge_rank2':('r3','merge-rank2.jsonl')}
def loadfactor(name,labels):
    if name in src:
        p,n=src[name]
        rr=((k,zz(z)) for k,z,*rest in rows(path(p)/n))
    else:
        rr=(([ *k,j],zz(z)) for j,t in rows(path('core')/graph['quotient_ray_files'][name]) for k,z in t)
    axes=tuple(sorted(labels))
    pos=[labels.index(k) for k in axes]
    out={}
    for k,z in rr:
        if any(v>=4 for n,v in zip(labels,k,strict=True) if n[0]=='q'):continue
        key=tuple(k[i] for i in pos)
        assert key not in out
        out[key]=z
    return axes,out
factors={n:loadfactor(n,labels) for n,labels in graph['factor_keys'].items() if n not in ('conditional_tile','mask_bridge','coalesced_environment')}
rep=load(A/'result-0000-stop11.json')
assert {k:len(t) for k,(_,t) in factors.items()}==rep['input_sizes']

# Reconstruct two original Boolean constraints independently.
s8={tuple(k[:2]) for k,_,_ in rows(path('star')/'site-factors.jsonl')}
s0={k[0] for k,_ in rows(path('two')/'zero-site-factors.jsonl')}
edge0=defaultdict(set);edge1=defaultdict(set)
bridge=set()
for (m,n,a,b,u,v),z in rows(path('star')/'edge-0.jsonl'):
    edge0[m].add((u,v))
    if n in s0 and m in {j[0] for j in s8}:bridge.add((m,n))
for (m,n,a,b,u,v),z in rows(path('star')/'edge-1.jsonl'):edge1[m].add((u,v))
trace={tuple(k[:2]) for k,z in rows(path('sew')/'trace-slices.jsonl')}
tile={(m,n,*p,*q) for m,n in s8 for p,q in product(edge0[m],edge1[n]) if all((a,b) in trace for a,b in zip(p,q))}
assert bridge=={tuple(k[:2]) for k in rows(path('two')/'compatible-mask-bridge.jsonl')} and len(bridge)==100
assert tile=={tuple(k) for k in rows(path('sew')/'conditional-tiles.jsonl')} and len(tile)==36608

def join(A,B):
    la,a=A;lb,b=B
    shared=sorted(set(la)&set(lb))
    outer=tuple(sorted(set(la)^set(lb)))
    ai,bi=([L.index(k) for k in shared] for L in (la,lb))
    index=defaultdict(list)
    for r,z in b.items():index[tuple(r[j] for j in bi)].append((r,z))
    op=[(0,la.index(k)) if k in la else (1,lb.index(k)) for k in outer]
    out=defaultdict(lambda:(0,0))
    visit=0
    for k,z in a.items():
        for r,w in index.get(tuple(k[j] for j in ai),()):
            visit+=1
            key=tuple((k,r)[j][i] for j,i in op)
            out[key]=plus(out[key],mult(z,w))
    nonzero={k:z for k,z in out.items() if any(z)}
    return (outer,nonzero),visit,len(out)-len(nonzero)
for e in rep['exact_completed_joins']:
    l,r=e['left'],e['right']
    u,v=factors.pop(l),factors.pop(r)
    out,n,zero=join(u,v)
    assert (n,len(out[1]),zero)==(e['visits'],e['nonzero_rows'],e['cancelled_rows'])
    factors[f'({l}+{r})']=out
assert len(rep['exact_completed_joins'])==11
for name,labels,raw in rows(A/'frontier-0000-stop11.jsonl'):
    axes,tab=factors[name]
    perm=[labels.index(k) for k in axes]
    assert tab=={tuple(key[i] for i in perm):zz(z) for key,z in raw}
print('all eleven exact source-bound joins, full frozen frontier and both original Boolean implications verified',flush=True)

desc={'A':'(rank0_edge1+rank4_closure)','B':'(rank8_edge0+(rank8_edge3+(rank8_edge2+partition_rank8)))',
'C':'(rank0_edge2+merge_rank2)','D':'(rank0_edge3+merge_rank1)',
'E':'(rank3_edge3+(rank3_edge2+(rank3_compact+rank3_projection)))','F':'(residual_edge+(rank8_edge1+rank12_closure))'}
IR={n:(tuple(l),v) for n,l,v in rows(A/'interior-rays.jsonl')}
M={n:(tuple(l),v) for n,l,v in rows(A/'mask-weights.jsonl')}
masks={}
for n,name in desc.items():
    labels,t=factors[name]
    il,raw=IR[n]
    ml,mv=M[n]
    order=[(0,il.index(k)) if k in il else (1,ml.index(k)) for k in labels]
    r={i:{tuple(k):tuple(z) for k,z in rr} for i,rr in raw}
    assert len(r)==11
    for vals in r.values():
        nonz=[x for k in sorted(vals) for x in vals[k] if x]
        assert nonz[0]>0 and gcd(*nonz)==1
    reconstruct={}
    for mask,(ray,w) in mv:
        for k,z in r[ray].items():
            key=tuple((k,mask)[j][i] for j,i in order)
            assert key not in reconstruct
            reconstruct[key]=tuple(w*x for x in z)
    assert reconstruct==t
    masks[n]=(ml,[(tuple(k),r,w) for k,(r,w) in mv])
for n in ('trace0','trace1','trace2','trace3'):
    l,raw=IR[n]
    a,t=factors[n]
    p=[l.index(k) for k in a]
    assert t=={tuple(k[i] for i in p):tuple(z) for k,z in raw}
print('all 66 primitive interior rays reconstruct complete exterior slices with exact signed weights',flush=True)

# Project each half by directly matching all named internal masks. Cache
# raw mask pairs, not preprojected signed four-bit unions.
def index(n,boundary):
    lab,table=masks[n]
    out=defaultdict(list)
    for k,r,w in table:
        d=dict(zip(lab,k,strict=True))
        out[tuple(d[j] for j in boundary)].append((d,r,w))
    return out
IX={n:index(n,ls) for n,ls in {'A':('ray_rank4',),'B':('ray_rank10','ray_rank9'),'C':('remote2',),
 'D':('remote1',),'E':('ray_rank3',),'F':('ray_rank12',)}.items()}
@cache
def left(a,b,c,d):
    tab=defaultdict(int)
    for (x,i,w),(y,j,z),(f0,k,v) in product(IX['A'][a,],IX['B'][c,d],IX['F'][b,]):
        if x['new_mask4']==f0['new_mask4'] and y['m81']==f0['m81'] and not (x['m01']&y['m00']):
            tab[(y['m00'],x['m01'],i,j,k)]+=w*z*v
    return dict(tab)
@cache
def right(a,b,c):
    tab=defaultdict(int)
    for (x,i,w),(y,j,z),(e,k,v) in product(IX['C'][c,],IX['D'][b,],IX['E'][a,]):
        if x['new_mask2']==e['new_mask2'] and y['new_mask1']==e['new_mask1'] and not (x['m02']&y['m03']):
            tab[(x['m02'],y['m03'],i,j,k)]+=w*z*v
    return dict(tab)
@cache
def signs(m):
    w=tuple(i for p in m for i in range(8) if p>>i&1)
    assert len(w)==len(set(w))==8
    n=sum(a>b for i,a in enumerate(w) for b in w[i+1:])
    return (-1)**n
@cache
def maskmap(leftkey,rightkey):
    ls,rs=left(*leftkey),right(*rightkey)
    out=defaultdict(int)
    for (m,n,a,b,f0),z in ls.items():
        for (p,q,c,d,e),w in rs.items():
            if (m|n)&(p|q):continue
            out[a,b,c,d,e,f0]+=z*w*signs((m,n,p,q))
    return {k:v for k,v in out.items() if v}
mask=defaultdict(int)
checked={}
env=path('core')/'coalesced-environment.jsonl'
for k,w in rows(env):
    a,b,c,d,e,p,q=k
    v=maskmap((a,b,d,e),(c,p,q))
    for kk,z in v.items():mask[kk]+=w*z
    checked[tuple(k)]=len(v)
mask={k:v for k,v in mask.items() if v}
assert len(mask)==401 and mask=={tuple(k):v for k,v in rows(A/'weighted-mask-amplitude-0000.jsonl')}
for c in load(A/'separation.json')['fixed_controls']:
    a,b,d,e,f0,p,q=c['boundary']
    v=maskmap((a,b,e,f0),(d,p,q))
    assert len(v)==c['complete_nonzero_interior_ray_rows'] and v[tuple(c['selected_ray_key'])]==c['mask_numerator']==-c['wrong_top_orientation_numerator']
print('all 178150 environment rows independently bound; complete 401 signed weights and four mask controls matched',flush=True)
