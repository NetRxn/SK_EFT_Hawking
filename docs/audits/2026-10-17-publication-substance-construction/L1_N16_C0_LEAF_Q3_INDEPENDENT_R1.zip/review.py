from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations, product
from math import gcd, prod
from pathlib import Path

def rows(name):
    return [line.split() for line in Path(name).read_text().splitlines()]

def complement_sign(mask):
    # Active labels are ordered first-word then second-word. The second
    # word is the complement, so inversion count is the sum of distances
    # of the first word's positions from their positions in a merged top.
    return (-1)**(sum(i for i in range(8) if mask>>i&1)-6)

directed=defaultdict(lambda:defaultdict(dict))
for direction,label,a,b,r,i in rows("edge.tsv"):
    label,a,b,r,i=map(int,(label,a,b,r,i))
    assert a.bit_count()==b.bit_count()==4 and (r or i)
    assert b not in directed[direction][label,a]
    directed[direction][label,a][b]=(r,i)
assert directed["active-first"]==directed["active-last"]
assert sum(map(len,directed["active-first"].values()))==380

# E from the incident edges has been generated at both endpoint orientations.
# Contract an active site directly as a join of complementary local masks
# and symmetric quartic internal labels, retaining the complex Gaussian
# integer until every term for the output pair has been accumulated.
def active_segment(signing):
    real,imag=Counter(),Counter()
    work=0
    for a,b,c in (map(int,line) for line in rows("gram2.tsv")):
        for left_mask in range(256):
            if left_mask.bit_count()!=4: continue
            L=directed["active-last"].get((a,left_mask),{})
            R=directed["active-first"].get((b,255^left_mask),{})
            weight=c*(complement_sign(left_mask) if signing else 1)
            for u,v in product(L,R):
                ar,ai=L[u];br,bi=R[v]
                real[u,v]+=weight*(ar*br-ai*bi)
                imag[u,v]+=weight*(ar*bi+ai*br)
                work+=1
    assert all(v==0 for v in imag.values()) and work==7344
    real={k:v for k,v in real.items() if v}
    assert len(real)==38 and all(real[v,u]==x for (u,v),x in real.items())
    return real

canonical=active_segment(True)
mutated=active_segment(False)
assert canonical.keys()==mutated.keys()
changed={k for k in canonical if canonical[k]!=mutated[k]}
assert len(changed)==16 and all(canonical[k]==-mutated[k] for k in changed)
assert (canonical[53,197],mutated[53,197])==(-424673280,424673280)
for name,table in (("transfer.tsv",canonical),("transfer-no-active-wedge.tsv",mutated)):
    Path(name).write_text("".join(f"{u}\t{v}\t{x}\t0\n" for (u,v),x in sorted(table.items())))

scale=gcd(*canonical.values())
q=F(scale,(4**4*48)**2)
assert q==F(45,128)
def inactive_segment(table):
    tr=defaultdict(dict)
    for (u,v),x in table.items():
        assert x%scale==0
        tr[255^u][v]=complement_sign(255^u)*(x//scale)
    return tr
normal=inactive_segment(canonical)
bad=inactive_segment(mutated)
assert all(x>0 for r in normal.values() for x in r.values())

def walk_trace(kernels):
    masses=Counter()
    def visit(start,vertex,coeff,depth):
        if depth==len(kernels):
            if vertex==start:masses[coeff]+=1
            return
        for end,value in kernels[depth].get(vertex,{}).items():
            visit(start,end,coeff*value,depth+1)
    for start in kernels[0]: visit(start,start,1,0)
    return sum(weight*number for weight,number in masses.items()),sum(masses.values()),masses

t2,n2,_=walk_trace([normal]*2)
t4,n4,m4=walk_trace([normal]*4)
wrong,nwrong,mwrong=walk_trace([bad,normal,normal,normal])
print("canonical transfer support",len(canonical),"scale",q)
print("closed walk normalized trace and count",t2,n2,t4,n4,"negative",sum(n for x,n in m4.items() if x<0))
print("adverse active-sign entries",len(changed),"entry 53,197",canonical[53,197],mutated[53,197])
print("one bad active orientation trace",wrong,"closed walks",nwrong,
      "negative",sum(n for x,n in mwrong.items() if x<0),"cycle",wrong*q**4)
assert (t2,t4,n4,wrong)==(3554,1371074,326,846786)
assert walk_trace([bad]*4)[0]==t4
assert all(walk_trace([normal]*i+[bad]+[normal]*(3-i))[0]==wrong for i in range(4))
cycles={4:t2*q*q,8:t4*q**4}
print("canonical coframe cycle factors",cycles)
Path("cycles.tsv").write_text("".join(f"{n}\t{v}\n" for n,v in cycles.items()))

# On S3, one coordinate has second moment 1/4 and fourth 1/8.
# The coframe traces multiply both chiral coordinates by 2, and the
# source check found the same symmetric chiral Gram for each chirality.
m2=2**2*F(1,4)
m4=2**4*F(1,8)
root_factor=m4+m4+6*m2*m2
assert root_factor==10

triples=[(a,b,c) for a,b,c in product(range(5),repeat=3) if a+b+c<=4]
def decode(code):
    return tuple(triples[(code>>(6*v))&63] for v in range(8))
edge_list=[(v,v^(1<<k),k) for v in range(8) for k in range(3) if not v>>k&1]
@cache
def removable(m):
    edges={(v,w):k for v,w,k in edge_list if m[v][k] or m[w][k]}
    while edges:
        count=Counter(x for pair in edges for x in pair)
        gone={pair for pair,k in edges.items() if min(count[v] for v in pair)==1
              and any(m[v][k]==0 for v in pair)}
        if not gone:return False
        for pair in gone:
            k=edges.pop(pair)
            assert sum(m[v][k] for v in pair) in (2,4)
    return True

@cache
def coframe_components(m):
    # Form connected components by merging the endpoint sets in each
    # nonzero coframe edge. A finite simple two-regular component is a
    # cycle. Its alternating active-inactive incidence is checked here.
    active={v for v in range(8) if sum(m[v])}
    assert len(active)==4 and all(sorted(m[v])==[0,0,4] for v in active)
    components=[{v} for v in range(8)]
    degree=Counter()
    for v,w,k in edge_list:
        nv,nw=sum(m[v])-m[v][k],sum(m[w])-m[w][k]
        if not (nv or nw):continue
        assert sorted((nv,nw))==[0,4] and ((v in active)!=(w in active))
        degree.update((v,w))
        union=components[v]|components[w]
        for node in union:components[node]=union
    assert sorted(degree.values())==[2]*8
    found=tuple(sorted({tuple(sorted(c)) for c in components}))
    assert all(len(c) in cycles for c in found)
    return found

orbit_path="/private/tmp/l1-c0-degree-independent.nEpHYJlb/orbits.tsv"
data=[]
orbits_by_shape,labels_by_shape=Counter(),Counter()
for a,b,n in (map(int,line) for line in rows(orbit_path)):
    A,B=decode(a),decode(b)
    axes={k for m in A+B for k in range(3) if m[k]}
    if len(axes)==1 or not (removable(A) and removable(B)):continue
    cA,cB=coframe_components(A),coframe_components(B)
    shape=tuple(sorted(map(len,cA+cB)))
    weight=F(root_factor,24)**8*prod(cycles[s] for s in shape)
    assert weight>0
    data.append((a,b,n,weight))
    orbits_by_shape[shape]+=1
    labels_by_shape[shape]+=n
    if (a,b)==(279173922820,289913962500):
        print("named pilot components",cA,cB,"representative",weight,"orbit",weight*n)
assert len(data)==12 and sum(n for a,b,n,x in data)==312
for shape in sorted(orbits_by_shape):
    print("cycle shape",shape,"orbits",orbits_by_shape[shape],"labels",labels_by_shape[shape])
print("exact mixed weighted subtotal",sum(n*x for a,b,n,x in data))
print("remaining temporal curvature block",11923-12-22,1021224-312-291)
Path("orbit-values.tsv").write_text("".join(f"{a}\t{b}\t{n}\t{x}\n" for a,b,n,x in data))
previously_signed={(279173922820,977108729870),(279173922820,61572886094720)}
new=[(n,x) for a,b,n,x in data if (a,b) not in previously_signed]
assert len(new)==10 and sum(n for n,x in new)==288
print("new-only signed subtotal",sum(n*x for n,x in new))
