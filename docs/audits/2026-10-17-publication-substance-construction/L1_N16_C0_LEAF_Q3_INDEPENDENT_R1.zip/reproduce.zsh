#!/bin/zsh
set -euo pipefail
cd -- "${0:A:h}"
primary=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking
frozen=/private/tmp/l1-c0-q3-signed.1y0b5pA3
prior=/private/tmp/l1-c0-degree-independent.nEpHYJlb
(cd "$primary"; python3 scripts/codex_continuity.py check .codex/continuity/l1-c0-coframe-q3-independent-r1.json) > continuity.out
(cd "$frozen"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > author-manifest.out
(cd "$prior"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > prior-manifest.out
test "$(cut -d' ' -f1 < author-manifest.out | head -1)" = 71b3f60da0018aafb899c4b9c407eb0fe55c01c4dbcbe2ebe778dd490001658f
test "$(cut -d' ' -f1 < prior-manifest.out | head -1)" = 5975bed7abd9b5fa50ae8e7396d9c22d907d12c2b0953bc56c184a72052b59a5
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$primary" "$primary/.venv/bin/python" source.py > source.out
cmp source-edge.tsv "$frozen/edge_coframes.tsv"
awk '$1==1 {print $2 "\t" $3 "\t" $4}' "$frozen/grams.tsv" | cmp source-gram.tsv -
clang++ -O3 -std=c++20 -Wall -Wextra -Werror -fsanitize=undefined -fno-sanitize-recover=all edge.cpp -o edge
./edge > edge.out
python3 review.py > review.out
for f in transfer.tsv transfer-no-active-wedge.tsv orbit-values.tsv cycles.tsv; do cmp "$f" "$frozen/$f"; done
