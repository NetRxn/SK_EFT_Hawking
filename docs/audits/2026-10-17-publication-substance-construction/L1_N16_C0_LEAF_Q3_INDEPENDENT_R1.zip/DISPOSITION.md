# Scoped acceptance

Accepted after independent reproduction of all 12 fully leaf-reduced mixed orbits, original normalization, and sign-sensitive control. Compare the separate L1_N16_C0_LEAF_Q3_AUTHOR_R1.zip. The residual block and full c0 remain open.
