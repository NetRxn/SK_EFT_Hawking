"""Recompose original component 14 from independently reviewed signed evidence."""
from ast import literal_eval
from csv import DictReader
from fractions import Fraction
from io import BytesIO
from pathlib import Path
import re
from sys import argv
from zipfile import ZipFile

audit = Path(argv[1])
overrides = {int(group):Path(path) for group,path in (arg.split('=',1) for arg in argv[2:])}

def rows(archive, member):
    return list(DictReader(archive.read(member).decode().splitlines(), delimiter='\t'))

with ZipFile(audit/'L1_N16_C0_DENSE_GEOMETRY_COVER_R1.zip') as saved:
    with ZipFile(BytesIO(saved.read('ACTUAL_REVIEW.zip'))) as review:
        with ZipFile(BytesIO(review.read('candidate.zip'))) as cover:
            component, = [row for row in rows(cover,'components.tsv') if row['id']=='14']
            selected = literal_eval(component['selected_side'])
            mirror = literal_eval(component['other_side'])
            pairs = {int(line.split('\t')[0]):int(line.split('\t')[1])
                     for line in cover.read('gamma-pairs.tsv').decode().splitlines()[1:]}
assert selected == [1416,1418,1442,1444,1466,1468,1488,1490]
assert len(selected)==len(mirror)==8 and len(set(selected+mirror))==16
assert len(pairs)==1936 and len(set(selected+mirror+[pairs[g] for g in selected+mirror]))==32
assert component['kind']=='K8,8' and component['whole_pair_weight']=='192'

def weighted_group(group):
    archived = audit/f'L1_N16_C0_DENSE_GROUP{group}_COMPLETE_R1.zip'
    with ZipFile(overrides.get(group,archived)) as z:
        if group==1466:
            source=z.read('AUTHOR_RETALLY.txt').decode().splitlines()
            ledger=[tuple(map(int,m.groups())) for line in source if
                    (m:=re.fullmatch(r'original joint-L (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)',line))]
        else:
            ledger=[(int(row['ordinal']),int(row.get('raw_real',row.get('raw_re'))),
                     int(row.get('raw_imag',row.get('raw_im'))),int(row['factor_denominator']))
                    for row in rows(z,'scalar.tsv')]
    assert [i for i,_,_,_ in ledger]==list(range(8))
    assert all(imag==0 and den>0 for _,_,imag,den in ledger)
    assert all(real==0 for i,real,_,_ in ledger if i in (5,7))
    unweighted=sum(Fraction(real,den) for _,real,_,den in ledger)/(16*4**64)
    if group==1466:
        assert source[-1]==f'exact normalized {unweighted} 0'
    return unweighted*192

print('group\tcover_weight\tweighted_exact_real\tweighted_exact_imag')
total=Fraction(0)
for group in selected:
    value=weighted_group(group)
    total+=value
    print(group,192,value,0,sep='\t')
print('original selected groups',','.join(map(str,selected)))
print('original mirror groups',','.join(map(str,mirror)))
print('original selected-side cover contribution',total,0)
