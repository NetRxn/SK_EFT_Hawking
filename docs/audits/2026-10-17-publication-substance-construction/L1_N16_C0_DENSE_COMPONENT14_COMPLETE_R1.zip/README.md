# Exact complete L1 component 14 contribution

The accepted signed geometric cover selects eight original groups for this
component. All eight groups have independently verified signed evidence.
The cover weight 192 includes occupation weight 48 and both pairing
factors. The component identity equates side sums. Individual omitted
mirror-group values require separate evidence.

From the publication audit directory, run `shasum -a 256 -c INPUTS.sha256`
with this package's input manifest. From the extracted evidence directory,
run `python3 -B retally-component.py AUDIT_DIRECTORY | cmp - COMPONENT_14.tsv`.
The imaginary part is zero. The full signed coefficient remains open.
