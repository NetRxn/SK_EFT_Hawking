import copy
import json
from pathlib import Path

from scripts.validation.checks import bundles_readiness as b

compose = Path('/private/tmp/l1-pr117-compose.e0MWQO')
b._H.PAPERS_DIR = compose / 'papers'
reference = json.loads((b._H.PAPERS_DIR / 'L1' / 'bundle_metadata.json').read_text())
candidate = copy.deepcopy(reference)
target = candidate['length_target']
target['source'] = ('APS Physical Review Letters author guide and APS Length Guide. Core ceiling is 3750 word equivalents, '
                    'including caption text and display math. Figures and tables use APS size formulas. References are excluded. '
                    'The repository size check reports an internal proxy. '
                    'https://journals.aps.org/prl/authors · https://journals.aps.org/authors/length-guide')
abstract = target['abstract_ceiling']
abstract['source'] = ('APS legacy PRL Information for Contributors (600 characters including spaces). '
                      'https://journals.aps.org/prl/info/infoL.html')
abstract['source_note'] = ('Keep the declared local ceiling pending human confirmation of current submission requirements. '
                           'The current PRL author page asks for a concise abstract and links to general APS style guidance, '
                           'which gives a word-based recommendation. https://journals.aps.org/authors/style-basics')
assert set(target) == set(reference['length_target'])
assert set(abstract) == set(reference['length_target']['abstract_ceiling'])
assert abstract['source_verified'] is False
assert abstract['ceiling'] == 600 and abstract['unit']=='characters'
assert target['ceiling']==3750 and target['unit']=='word_equivalents'
source = b._read_metadata
observed = []
for label, value in (('baseline',reference),('provenance-corrected',candidate)):
    b._read_metadata = lambda code: value if code=='L1' else source(code)
    p=b._H.PAPERS_DIR / 'L1' / 'paper_draft.tex'
    plain=b.abstract_plain_text(p.read_text())
    size, unit, note=b._measure_manuscript('L1')
    assert len(plain) <= abstract['ceiling'] and size is not None and size <= target['ceiling']
    record=(len(plain), size, unit, abstract['source_verified'])
    print(label, record, note)
    observed.append(record)
assert observed[0] == observed[1]
Path('length-target-candidate.json').write_text(json.dumps(target,indent=2,ensure_ascii=False)+'\n')
