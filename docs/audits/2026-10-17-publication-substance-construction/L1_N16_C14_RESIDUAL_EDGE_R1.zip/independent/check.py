from collections import Counter, defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from fractions import Fraction
import json,sys
from src.core.formulas import original_action_factors, original_spin4_link, original_coframe_blocks
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
A,T,S,SE,P=map(Path,sys.argv[1:])
def load(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def f(v): return tuple(map(f,v)) if isinstance(v,(tuple,list)) else v
def tbl(p):
    rr=f(rows(p)); t=dict(rr); assert len(rr)==len(t)
    return t
def co(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def add(z,w):return z[0]+w[0],z[1]+w[1]
def sign(w):return (-1)**sum(i>j for k,i in enumerate(w) for j in w[k+1:])
def pos(site,mask):return [8*site+i for i in range(8) if mask>>i&1]
R=OriginalRegulator()
index={x:i for i,x in enumerate(R.sites)}
positions={g:i for i,g in enumerate(R.generator_order)}
assert (R.extents,R.boundary_signs,R.convention,R.word)==((2,)*4,(1,)*4,'source_C','closed')
L={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in R.link_order}
M=load(A/'result.json')
G=load(A/'graph.json')
base=load(T/'graph.json')
C=load(P/'support-census.json')['sites']
row=load(S/'result.json')['row']
assert row['exponential_divisor']==512
acts=[]
for i,(x,*axes) in enumerate(row['planes']):
    anchors={tuple(sorted((index[tuple(y)],d) for y,d in aa)) for degree,comp,aa,n,_ in C[x]['raw_branches']
             if n and degree==2 and sorted(j for j,_ in comp)==axes}
    assert len(anchors)==1
    acts.append(('S2',x,i,tuple(axes),next(iter(anchors))))
acts += [('S4',x,i,tuple(range(4)),()) for x,n in enumerate(row['S4_occupations']) for i in range(n)]

def edge(rank,d):
    return frozenset((rank,index[R.step(R.sites[rank],d)[0]]))
def owner(rank,axis):
    E=edge(rank,axis)
    frames=[(s,x,i,d) for s,x,i,axes,_ in acts for d in axes if edge(x,d)==E]
    traces=[(s,x,i,(k,d)) for s,x,i,_,aa in acts for k,d in aa if edge(k,d)==E]
    return f(frames),f(traces)
fr,tr=owner(4,0)
assert f(M['edge'])==(0,12,fr,tr)
assert fr==(('S4',12,0,0),('S4',12,1,0))
assert tr==(('S2',0,2,(4,0)),('S2',0,3,(4,0)))

@cache
def moment(q):
    ns=Counter(q)
    if any(n%2 for n in ns.values()):return Fraction()
    return Fraction(prod(3 if n==4 else 1 for n in ns.values()),
        prod(j for n in Counter(i//4 for i in q).values() for j in range(4,4+n,2)))

def compute(site,axis,trace_slots):
    neighbor=next(iter(edge(site,axis)-{site}))
    ends=tuple(sorted((site,neighbor)))
    # The actual coframes all center at rank 12, including residual edge.
    alpha=defaultdict(list)
    qindex={(R.sites[x],axis,h,k):i for i,(x,h,k) in enumerate(product(ends,('L','R'),range(4)))}
    for component in range(4):
        for b in original_coframe_blocks(R,(R.sites[12],axis,component),L):
            for i,j in product(range(4),repeat=2):
                w=(positions[b.bar_site,'bar',i],positions[b.psi_site,'psi',j])
                for sy,z in b.matrix[i][j].terms:
                    assert len(sy)==1 and sy[0].index[:2]==b.anchor
                    c=(z.real*4*b.weight,z.imag*4*b.weight)
                    assert all(v.denominator==1 for v in c)
                    alpha[qindex[sy[0].index]].append((component,w,tuple(map(int,c))))
    support=0
    grouped=defaultdict(lambda:(0,0))
    weight_scale=48 if trace_slots else 4
    for q in product(range(16),range(16),*trace_slots):
        H=moment(q)*weight_scale
        if not H:continue
        assert H.denominator==1
        support+=1
        for (a,w,z),(b,v,t) in product(alpha[q[0]],alpha[q[1]]):
            word=w+v
            if len(set(word))!=4:continue
            local,remote=(sum(1<<(i%8) for i in word if i//8==x) for x in (site,neighbor))
            assert local.bit_count()==remote.bit_count()==2
            key=(local,remote,a,b,*q[2:])
            grouped[key]=add(grouped[key],tuple(int(H)*sign(word)*u for u in co(z,t)))
    nonzero={k:v for k,v in grouped.items() if any(v)}
    return nonzero,support,len(grouped)-len(nonzero)

edge4,s,z=compute(4,0,(range(8),range(8)))
edge_wrong,ss,zz=compute(4,0,(range(8,16),range(8,16)))
assert edge4==tbl(A/'residual-edge.jsonl') and len(edge4)==len(edge_wrong)==14208
assert (s,ss,z,zz)==(240,240,3584,3584)
print('actual and wrong-anchor raw edge tables 14208 rows each; 240 assignments; 3584 exact drops',flush=True)

star_masks={p[1] for p,_,_ in rows(S/'site-factors.jsonl')}
zero_masks={p[1] for p,_ in rows(T/'zero-site-factors.jsonl')}
old4={k[1] for k,_ in rows(T/'zero-edge-1.jsonl') if k[0] in zero_masks}
old12={k[1] for k,_ in rows(S/'edge-1.jsonl') if k[0] in star_masks}
merges=[]
for rank,old,col in ((4,old4,0),(12,old12,1)):
    table={(p,q,p|q):sign(pos(rank,p)+pos(rank,q)) for p,q in product(old,{k[col] for k in edge4}) if not p&q}
    assert table==tbl(A/f'merge-rank{rank}.jsonl') and len(table)==420
    merges.append(table)
for (m4,n4,_),a in merges[0].items():
    for (m12,n12,_),b in merges[1].items():
        word=sum((pos(i,m) for i,m in ((1,3),(2,3),(4,m4),(9,3),(10,3),(12,m12),(4,n4),(12,n12))),[])
        assert len(set(word))==len(word)==16 and sign(word)==a*b
print('both 420-row signed disjoint-mask joins complete; all 176400 whole-word signs checked',flush=True)

relabel={'remote4':'old_mask4','remote12':'old_mask12'}
expected={k:[relabel.get(a,a) for a in v] for k,v in base['factor_keys'].items()}
expected.update(residual_edge=['new_mask4','new_mask12','S4_12_a0_0','S4_12_a0_1','q40_2','q40_3'],
     merge_rank4=['old_mask4','new_mask4','remote4'],merge_rank12=['old_mask12','new_mask12','remote12'])
assert expected==G['factor_keys']
assert set(G['boundary'])==set(base['boundary'])-{'q40_2','q40_3'}|{'S4_12_a0_0','S4_12_a0_1'}
assert G['combined_denominator']==base['combined_denominator']*768==215162822875748210049024
assert G['external_exponential_divisor']==512
print('factored graph bindings and all open boundary labels matched',flush=True)

trace=defaultdict(lambda:(0,0))
anchors=((0,0),(8,1),(4,0),(0,1))
for fac in original_action_factors(R,R.sites[0],L):
    comps=sorted(fac.components)
    if tuple(d for _,d,_ in comps)!=(2,3):continue
    a,b=(i for _,_,i in comps)
    for sy,z in fac.coefficient.terms:
        q={(index[s.index[0]],s.index[1]):s.index[3]+4*(s.index[2]=='R') for s in sy}
        assert len(q)==4 and set(q)==set(anchors)
        u,v,w,t=(q[k] for k in anchors)
        re,im=z.real*4,z.imag*4
        assert re.denominator==im.denominator==1
        key=(u,v,a,b,w,t)
        trace[key]=add(trace[key],(int(re),int(im)))
assert {k:z for k,z in trace.items() if any(z)}==tbl(SE/'trace-slices.jsonl')
for c in M['exact_signed_source_junction_controls']:
    ext=(c['new_mask4'],c['new_mask12'],*c['s4_rank12_axis0_components'])
    k0,k1=(c['trace2_fixed'],c['trace3_fixed'])
    t0={u:trace[(*k0[:4],u,k0[4])] for u in range(8)}
    t1={u:trace[(*k1[:4],u,k1[4])] for u in range(8)}
    word=sum((pos(i,m) for i,m in ((4,c['old_mask4']),(12,c['old_mask12']),(4,ext[0]),(12,ext[1]))),[])
    s=sign(word)
    outs=[]
    for E,offset,alias in ((edge4,0,False),(edge_wrong,8,False),(edge4,0,True)):
        v=(0,0)
        for u,w in product(range(8),repeat=2):
            p=co(co(t0[u],t1[u if alias else w]),E.get((*ext,u+offset,w+offset),(0,0)))
            v=add(v,tuple(s*x for x in p))
        outs.append(v)
    assert outs==[f(c[k]) for k in ('signed_numerator','wrong_anchor_numerator','false_occurrence_alias_numerator')]
    assert c['denominator']==768*4**2==12288
    print('control',c['chirality_sector'],outs,flush=True)

for ctrl in load(T/'result.json')['partition_and_seam_restricted_controls']:
    m4=ctrl['new_remote_masks'][0]
    m12=ctrl['old_edge_boundary'][0][0]
    q=f(ctrl['residual_plane23'])
    assert (m4,m12,q)==(192,80,(0,0))
    options=[k for k in edge4 if k[-2:]==q and not(k[0]&m4 or k[1]&m12)]
    assert len(options)==28 and len({(m4|k[0],m12|k[1]) for k in options})==5
print('restricted lift confirmed on 28 rows and five fused masks per original fixed restriction',flush=True)

for d in (2,3):
    fr,tr=owner(12,d)
    assert fr==tuple(('S4',12,i,d) for i in range(2)) and not tr
    table,support,drop=compute(12,d,())
    assert len(table)==48 and support==16 and drop==240
    print('next rank12 edge',d,'neighbor',sorted(edge(12,d)-{12})[0],'source-only exact support',len(table),'at denominator 64',flush=True)
