from pathlib import Path
import json,sys
p=Path(sys.argv[1])
m=json.loads((p/'result.json').read_text())
assert sum(m['charged_operations'].values())==492705<m['cap']['work']==4000000
s=m['storage']
assert s['rows']==73246<m['cap']['rows']==120000
assert s['charged_bytes']==s['rows']*512==37501952<m['cap']['accounted_bytes']==64*1024**2
assert s['serialized_bytes']==sum((p/f).stat().st_size for f in ('residual-edge.jsonl','merge-rank4.jsonl','merge-rank12.jsonl'))==367028<m['cap']['serialized_bytes']==4*1024**2
assert m['rss_peak_bytes']==117981184<m['cap']['sampled_rss']==384*1024**2
assert m['cap']['scalar']==2**61-1
print('author scoped meters, caps and exact output sizes matched')
