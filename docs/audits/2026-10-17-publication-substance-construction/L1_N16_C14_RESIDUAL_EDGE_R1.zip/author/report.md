# Original N16 c14 residual Haar edge

The pinned source is the periodic closed source_C at clean primary
27012c18fa374e8341e124b510abbedeedb18d29. This is an exact factored local
increment to the accepted rank-zero/rank-eight graph for the zero-centered
(01,01,23,23) representative. The full representative and the external
exponential divisor 512 stay outside the local computation.

The original edge on axis 0 joins site ranks 4 and 12. Its only coframe
owners are the two original S4 occurrences centered at rank 12. Its
only curvature owners are the independent S2 trace occurrences 2 and
3 centered at rank 0, both using the original directed anchor (4,0).
The reciprocal (12,0) is a distinct Haar factor. Both directed anchors
and both chiralities were integrated using their independent normalized
S3 moments.

The exact signed sparse edge has 14,208 nonzero rows at denominator
768. It uses all 240 incidence-admissible quartic Haar assignments.
The row keys are two exterior masks (rank 4, rank 12), the ordered
rank-12 S4 axis-0 component pair, and the two trace coordinates in
original occurrence order. The q codes are L0–L3 and R0–R3 at (4,0).
The independent route reconstructs the four raw quarter increments,
counts literal Grassmann inversions, and uses anchor-preserving
Kronecker pairings for Haar moments. It agrees on every edge row.

There are 420 signed mask merge rows at each endpoint. They join the
previous and added two-generator masks when disjoint and retain the
four-generator union. All 176,400 pairs of merge rows were checked
against literal full source exterior words. Entire two-generator
blocks from distinct sites cross with even sign. This leaves the
local old/new inversion at each affected site.

The updated `graph.json` sews the new tensor into the original two
trace slots and the two exterior joins. It eliminates the two q40
slots, replaces both old two-generator boundary masks by their
four-generator unions, and adds the ordered rank-12 S4 axis-0
component pair. The axis-1 S4 slots remain open and distinct.
Both merge factors are signed coefficients. The complete factored
local denominator before external factorials is
215,162,822,875,748,210,049,024. No remaining S4 epsilon or further
site closure was applied.

## Exact signed controls and bounded XOR result

Fixing the open trace components and other three coordinates in
each trace, the two distinct routes contract the entire remaining
q40 product against a selected edge exterior split and component
pair. The second route extracts the matching ordered raw trace
entries at the fixed source keys and obtains both endpoint signs
from the complete exterior word. These are junction controls. They
do not evaluate all earlier conditional factors at a fixed graph
boundary. Serialized readback independently recomputes each result.

| Ordered trace chirality | Exact junction | Wrong reciprocal anchor | False occurrence reuse |
| --- | ---: | ---: | ---: |
| LL | 1/48 | -1/48 | 0 |
| LR | -i/64 | i/64 | 0 |
| RL | -i/64 | i/64 | 0 |
| RR | 1/48 | -1/48 | 0 |

The reciprocal-anchor negative replaces the two original trace
attachments with (12,0) and recomputes the complete edge factor.
It leaves both Haar factors independent. The false reuse negative
feeds occurrence 2's actual coordinate into occurrence 3's
original trace coefficient.

For each of the three previously accepted restricted XOR-2 controls,
the fixed q40 pair is (0,0) and the old masks at ranks 4/12 are
192/80. Each control admits 28 compatible residual edge rows over
five fused exterior mask pairs. On each such fixed restriction
the prior sign-reversing pairing survives multiplication by the
new edge and merge factors. Those factors do not depend on the
four plane-23 coframe components flipped by the pairing. This is
a lift on precisely the prior restricted path supports. It does
not establish a pairing or a zero on the full joined graph.

## Capacity and continuation

The run charged 492,705 operations against 4,000,000 and 73,246
cumulative tracked entries against 120,000. It used 37,501,952
accounting bytes against 64 MiB and 367,028 serialized bytes against
4 MiB. The checked integer magnitude cap was 2^61−1. The sampled
process peak RSS was 117,981,184 bytes under a sampled 384 MiB
guard. Source construction, caches, auxiliary table indexing and
sorting, and separate readback are outside the charged counters
as appropriate. The measured RSS is not an OS-enforced limit.

A viable next cut is rank 12. Both remaining incident edges on
axes 2 and 3 are degree two and attach to ranks 14 and 13. Their
paired coframes belong to the same two original rank-12 S4
occurrences as the open axis-0 and axis-1 component slots. Attach
both ordered epsilon factors and eliminate rank-12 masks and
components before remote boundary expansion. Rank 4 still has
two other incident pairs and stays open. The other representative
arrangements, c14, c0, full denominator and normalization remain open.
