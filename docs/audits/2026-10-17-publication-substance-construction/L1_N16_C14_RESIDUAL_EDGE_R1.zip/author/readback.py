"""Read frozen local junction and quantify only the supported restricted lift."""
from collections import Counter, defaultdict
from pathlib import Path
import json

ROOT=Path(__file__).parent
TWO=Path('/tmp/publication-c14-rank-zero-r1.gte6BM')
SEWN=Path('/tmp/publication-c14-shared-trace-r1.9tcmVn')

def load(path):
    with path.open() as f:
        for line in f:
            yield json.loads(line)

edge={}
for k,v in load(ROOT/'residual-edge.jsonl'):
    m,n,a,b,u,q=k
    assert m.bit_count()==n.bit_count()==2
    assert 0<=a<4 and 0<=b<4 and 0<=u<8 and 0<=q<8 and any(v)
    assert tuple(k) not in edge
    edge[tuple(k)]=tuple(v)
assert len(edge)==14208

def sign(x,y):
    return (-1)**sum(i>j for i in range(8) if x>>i&1 for j in range(8) if y>>j&1)

merges=[]
for site in (4,12):
    table={}
    for (old,new,union),s in load(ROOT/f'merge-rank{site}.jsonl'):
        assert old&new==0 and union==old|new and union.bit_count()==4
        assert s==sign(old,new)
        table[old,new]=s
    assert len(table)==420
    merges.append(table)

trace=defaultdict(dict)
for (u,v,a,b,r,s),z in load(SEWN/'trace-slices.jsonl'):
    trace[u,v,a,b,s][r]=tuple(z)

def times(x,y):
    a,b=x
    c,d=y
    return a*c-b*d,a*d+b*c

state=json.loads((ROOT/'result.json').read_text())
for c in state['exact_signed_source_junction_controls']:
    p=(c['new_mask4'],c['new_mask12'],*c['s4_rank12_axis0_components'])
    t0,t1=trace[tuple(c['trace2_fixed'])],trace[tuple(c['trace3_fixed'])]
    s=merges[0][c['old_mask4'],p[0]]*merges[1][c['old_mask12'],p[1]]
    out=(0,0)
    for q,x in t0.items():
        for r,y in t1.items():
            a,b=times(times(x,y),edge.get((*p,q,r),(0,0)))
            out=out[0]+s*a,out[1]+s*b
    assert list(out)==c['signed_numerator']

lifts=[]
for control in json.loads((TWO/'result.json').read_text())['partition_and_seam_restricted_controls']:
    old4=control['new_remote_masks'][0]
    old12=control['old_edge_boundary'][0][0]
    qpair=tuple(control['residual_plane23'])
    compatible=Counter()
    for m,n,a,b,u,v in edge:
        if (u,v)==qpair and (old4,m) in merges[0] and (old12,n) in merges[1]:
            compatible[(old4|m,old12|n)]+=1
    assert compatible
    lifts.append(dict(original_fixed_qpair=qpair,old_masks=[old4,old12],
        compatible_residual_edge_rows=compatible.total(),fused_mask_pairs=len(compatible),
        scope='only original fixed restrictions; residual factor is unchanged by their accepted XOR-2 pairing'))

print(json.dumps(dict(nonzero_edge_rows=len(edge),merge_tables=[len(v) for v in merges],
                      rechecked_controls=4,restricted_xor_lifts=lifts),indent=2))
