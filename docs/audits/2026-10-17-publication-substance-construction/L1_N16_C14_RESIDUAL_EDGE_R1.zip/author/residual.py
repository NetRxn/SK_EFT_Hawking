"""Complete residual c14 Haar edge and exact boundary sewing."""
from collections import Counter, defaultdict
from functools import cache
from itertools import product
from pathlib import Path
import json, sys

OUT=Path(__file__).parent
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
SEWN=Path('/tmp/publication-c14-shared-trace-r1.9tcmVn')
TWO=Path('/tmp/publication-c14-rank-zero-r1.gte6BM')
for p in (STAR,SEWN):
    sys.path.insert(0,str(p))
import cut

ZERO=(0,0)
TRACE_ANCHORS=((0,0),(8,1),(4,0),(0,1))
DENOMINATOR=768*4**2

def load(path):
    with path.open() as f:
        for line in f:
            cut.work('read_frozen_row')
            yield json.loads(line)

def description():
    desc=cut.star_owners(cut.roster(),4)[0]
    axis,neighbor,frames,traces=desc
    assert (axis,neighbor)==(0,12)
    assert frames==[('S4',12,0,0),('S4',12,1,0)]
    assert traces==[('S2',0,2,(4,0)),('S2',0,3,(4,0))]
    return desc

def edge_tensor():
    desc=description()
    canonical,den,support=cut.edge_tensor(desc,4,False)
    raw,den0,support0=cut.edge_tensor(desc,4,True)
    assert canonical==raw and den==den0==768 and support==support0==240
    assert all(k[4]<8 and k[5]<8 for k in canonical)
    cut.write_rows('residual-edge.jsonl',canonical)

    # Deliberate wrong source anchor. Compute the complete alternate
    # comparator without identifying the two original Haar factors.
    axis,neighbor,frames,traces=desc
    wrong_desc=(axis,neighbor,frames,[(*t[:3],(12,0)) for t in traces])
    wrong,wrong_den,wrong_support=cut.edge_tensor(wrong_desc,4,True)
    assert wrong_den==den and wrong_support==support
    assert all(k[4]>=8 and k[5]>=8 for k in wrong)
    return desc,canonical,raw,wrong

def old_mask_domains():
    # Include only masks occurring in the accepted complete factored
    # graph. New edge tensors preserve all coefficient rows regardless.
    mask8={p[1] for p,_,_ in load(STAR/'site-factors.jsonl')}
    mask0={p[1] for p,_ in load(TWO/'zero-site-factors.jsonl')}
    old12={k[1] for k,_ in load(STAR/'edge-1.jsonl') if k[0] in mask8}
    old4={k[1] for k,_ in load(TWO/'zero-edge-1.jsonl') if k[0] in mask0}
    return old4,old12

def masksites(keys):
    return [{k[i] for k in keys} for i in (0,1)]

def full_word_sign(old4,old12,new4,new12):
    # Add the residual edge to the accepted open exterior order.
    # Include arbitrary actual-size pairs at all four unchanged sites.
    def word(site,mask):
        return [8*site+i for i in range(8) if mask>>i&1]
    old=[]
    for site,mask in sorted(((4,old4),(12,old12),(1,3),(2,3),(9,3),(10,3))):
        old.extend(word(site,mask))
    total=old+word(4,new4)+word(12,new12)
    if len(set(total))!=len(total):
        return 0
    return (-1)**sum(a>b for i,a in enumerate(total) for b in total[i+1:])

def merge_tables(edge):
    merged=[]
    for site,old_masks,new_masks in zip((4,12),old_mask_domains(),masksites(edge),strict=True):
        table={}
        for old,new in product(sorted(old_masks),sorted(new_masks)):
            cut.work('mask_merge_candidate')
            if old&new:
                continue
            k=(old,new,old|new)
            cut.reserve('merge_table',k,table)
            table[k]=(-1)**cut.crossing(old,new)
        cut.write_rows(f'merge-rank{site}.jsonl',table)
        merged.append(table)
    for (a,b,_),za in merged[0].items():
        for (c,d,_),zb in merged[1].items():
            cut.work('literal_global_merge_sign')
            assert full_word_sign(a,c,b,d)==za*zb
    return merged

def trace_groups():
    t=defaultdict(dict)
    for (u,v,a,b,r,s),z in load(SEWN/'trace-slices.jsonl'):
        key=(u,v,a,b,s)
        cut.reserve('trace_slice',r,t[key])
        t[key][r]=tuple(z)
    return t

@cache
def raw_trace_fixed(key):
    u,v,a,b,s=key
    out={}
    for f in cut.raw_factors(cut.REG.sites[0],(2,3)):
        if any(aa != (a if mu==2 else b) for _,mu,aa in f.components):
            continue
        for symbols,z in f.coefficient.terms:
            cut.work('raw_trace_source_scan')
            coords={(cut.RANK[x],mu): k+4*(h=='R') for symbol in symbols for x,mu,h,k in [symbol.index]}
            assert set(coords)==set(TRACE_ANCHORS)
            q0,q1,r,q3=(coords[anchor] for anchor in TRACE_ANCHORS)
            if (q0,q1,q3)!=(u,v,s):
                continue
            real,imag=z.real*4,z.imag*4
            assert real.denominator==imag.denominator==1
            cut.reserve('raw_trace_slice',r,out)
            out[r]=cut.add(out.get(r,ZERO),(real.numerator,imag.numerator))
    return {r:z for r,z in out.items() if z!=ZERO}

def compare(edge,raw,wrong,merges):
    traces=trace_groups()
    by_q=defaultdict(list)
    for k,t in traces.items():
        for q in t:
            cut.work('index_trace_control')
            # Limit witness proposals, not the coefficient under test.
            if len(by_q[q])<4:
                cut.reserve('trace_control_index',len(by_q[q]),{})
                by_q[q].append(k)
    edge_by_ext=defaultdict(dict)
    for (m,n,a,b,u,v),z in edge.items():
        key=(m,n,a,b)
        cut.reserve('edge_control_index',(u,v),edge_by_ext[key])
        edge_by_ext[key][u,v]=z
    by_new=[]
    for table in merges:
        index=defaultdict(list)
        for (old,new,union),z in table.items():
            cut.work('index_merge_control')
            cut.reserve('merge_control_index',len(index[new]),{})
            index[new].append((old,union,z))
        by_new.append(index)
    controls=[]
    seen=set()
    sectors=set()
    for m,n,a,b,u,v in sorted(edge):
        cut.work('control_candidate_edge')
        sector=(u//4,v//4)
        if sector in sectors:
            continue
        ext=(m,n,a,b)
        if not by_new[0][m] or not by_new[1][n]:
            continue
        old4,fused4,sign4=by_new[0][m][0]
        old12,fused12,sign12=by_new[1][n][0]
        sign=sign4*sign12
        assert sign==full_word_sign(old4,old12,m,n)
        for left,right in product(by_q[u],by_q[v]):
            cut.work('control_candidate_trace')
            if left==right or (ext,left,right) in seen:
                continue
            cut.reserve('control_seen',(ext,left,right),seen)
            seen.add((ext,left,right))
            t0,t1=traces[left],traces[right]
            direct=bad_anchor=bad_alias=ZERO
            for (q0,q1),z in edge_by_ext[ext].items():
                cut.work('canonical_junction')
                t=cut.scale(cut.times(t0.get(q0,ZERO),t1.get(q1,ZERO)),sign)
                direct=cut.add(direct,cut.times(z,t))
                bad_anchor=cut.add(bad_anchor,cut.times(wrong.get((*ext,q0+8,q1+8),ZERO),t))
                bad_alias=cut.add(bad_alias,cut.times(z,cut.scale(cut.times(t0.get(q0,ZERO),t1.get(q0,ZERO)),sign)))
            if direct==ZERO or bad_anchor==direct:
                continue
            r0,r1=raw_trace_fixed(left),raw_trace_fixed(right)
            assert r0==t0 and r1==t1
            ref=ZERO
            for (q0,z0),(q1,z1) in product(r0.items(),r1.items()):
                cut.work('literal_raw_junction')
                term=cut.times(z0,cut.times(z1,raw.get((*ext,q0,q1),ZERO)))
                ref=cut.add(ref,cut.scale(term,full_word_sign(old4,old12,m,n)))
            assert ref==direct
            cut.reserve('control_record',len(controls),{})
            controls.append(dict(trace2_fixed=left,trace3_fixed=right,
                old_mask4=old4,new_mask4=m,fused_mask4=fused4,
                old_mask12=old12,new_mask12=n,fused_mask12=fused12,
                s4_rank12_axis0_components=(a,b),signed_numerator=direct,
                denominator=DENOMINATOR,wrong_anchor_numerator=bad_anchor,
                false_occurrence_alias_numerator=bad_alias,chirality_sector=sector))
            sectors.add(sector)
            break
        if len(sectors)==4:
            break
    assert len(sectors)==4 and any(c['signed_numerator']!=c['false_occurrence_alias_numerator'] for c in controls)
    return controls

def graph():
    source=json.loads((TWO/'graph.json').read_text())
    replacements={'remote4':'old_mask4','remote12':'old_mask12'}
    for name,labels in source['factor_keys'].items():
        source['factor_keys'][name]=[replacements.get(v,v) for v in labels]
    source['factor_keys'].update(
        residual_edge=['new_mask4','new_mask12','S4_12_a0_0','S4_12_a0_1','q40_2','q40_3'],
        merge_rank4=['old_mask4','new_mask4','remote4'],
        merge_rank12=['old_mask12','new_mask12','remote12'],
    )
    source['boundary']=[v for v in source['boundary'] if v not in ('q40_2','q40_3')]
    source['boundary']+=['S4_12_a0_0','S4_12_a0_1']
    source['combined_denominator']*=768
    source['semantics']+=' Merge factors carry the signed wedge of the old pair and the new pair at each of ranks 4 and 12.'
    (OUT/'graph.json').write_text(json.dumps(source,indent=2)+'\n')
    return source['combined_denominator']

def main():
    cut.OUT=OUT
    cut.ROW_CAP=120_000
    cut.rss()
    desc,edge,raw,wrong=edge_tensor()
    merges=merge_tables(edge)
    controls=compare(edge,raw,wrong,merges)
    denominator=graph()
    cut.rss()
    meta=dict(edge=desc,nonzero_edge_rows=len(edge),wrong_anchor_rows=len(wrong),
        merge_rows=[len(m) for m in merges],combined_denominator=denominator,
        exact_signed_source_junction_controls=controls,
        charged_operations=dict(cut.WORK),storage=dict(cut.STORE),rss_peak_bytes=cut.RSS_PEAK,
        cap=dict(rows=cut.ROW_CAP,work=cut.WORK_CAP,accounted_bytes=cut.BYTE_CAP,
                 serialized_bytes=cut.FILE_CAP,sampled_rss=cut.RSS_CEILING,scalar=cut.INT_LIMIT))
    (OUT/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('exact edge',len(edge),'merge rows',[len(m) for m in merges],'checks',len(controls),flush=True)

if __name__=='__main__':
    main()
