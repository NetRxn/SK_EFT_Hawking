from itertools import product
from pathlib import Path
import json,sys
a,star,previous=map(Path,sys.argv[1:])
def tbl(p): return {tuple(k):tuple(v) for k,v in map(json.loads,p.read_text().splitlines())}
def mul(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
old=tbl(star/'edge-1.jsonl')
res=tbl(previous/'residual-edge.jsonl')
out=tbl(a/'rank12-closure.jsonl')
for ctl in json.loads((a/'result.json').read_text())['controls']:
    left=[(m,b,c,z) for (p,m,b,c,u,v),z in old.items() if [p,u,v]==ctl['old_edge_boundary']]
    right=[(n,d,e,z) for (p,n,d,e,u,v),z in res.items() if [p,u,v]==ctl['residual_edge_boundary']]
    R,S=ctl['remote_masks']
    got=[mul(mul(x,y),out.get((m,n,d,e,c,b,R,S),(0,0))) for (m,b,c,x),(n,d,e,y) in product(left,right)]
    assert [sum(q[i] for q in got) for i in range(2)]==ctl['signed_numerator']
print('axis1 occurrence swap independently unchanged on all four fixed junction slices')
