from collections import Counter, defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from fractions import Fraction
import json,sys
from src.core.formulas import original_action_factors, original_spin4_link, original_coframe_blocks
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
A,T,S,SE,P=map(Path,sys.argv[1:6])
def load(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def f(v): return tuple(map(f,v)) if isinstance(v,(tuple,list)) else v
def tbl(p):
    rr=f(rows(p)); t=dict(rr); assert len(rr)==len(t)
    return t
def co(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def add(z,w):return z[0]+w[0],z[1]+w[1]
def sign(w):return (-1)**sum(i>j for k,i in enumerate(w) for j in w[k+1:])
def pos(site,mask):return [8*site+i for i in range(8) if mask>>i&1]
R=OriginalRegulator()
index={x:i for i,x in enumerate(R.sites)}
positions={g:i for i,g in enumerate(R.generator_order)}
assert (R.extents,R.boundary_signs,R.convention,R.word)==((2,)*4,(1,)*4,'source_C','closed')
L={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in R.link_order}
M=load(A/'result.json')
G=load(A/'graph.json')
base=load(T/'graph.json')
C=load(P/'support-census.json')['sites']
row=load(S/'result.json')['row']
assert row['exponential_divisor']==512
acts=[]
for i,(x,*axes) in enumerate(row['planes']):
    anchors={tuple(sorted((index[tuple(y)],d) for y,d in aa)) for degree,comp,aa,n,_ in C[x]['raw_branches']
             if n and degree==2 and sorted(j for j,_ in comp)==axes}
    assert len(anchors)==1
    acts.append(('S2',x,i,tuple(axes),next(iter(anchors))))
acts += [('S4',x,i,tuple(range(4)),()) for x,n in enumerate(row['S4_occupations']) for i in range(n)]

def edge(rank,d):
    return frozenset((rank,index[R.step(R.sites[rank],d)[0]]))
def owner(rank,axis):
    E=edge(rank,axis)
    frames=[(s,x,i,d) for s,x,i,axes,_ in acts for d in axes if edge(x,d)==E]
    traces=[(s,x,i,(k,d)) for s,x,i,_,aa in acts for k,d in aa if edge(k,d)==E]
    return f(frames),f(traces)
fr,tr=owner(4,0)
assert f(M['edge'])==(0,12,fr,tr)
assert fr==(('S4',12,0,0),('S4',12,1,0))
assert tr==(('S2',0,2,(4,0)),('S2',0,3,(4,0)))

@cache
def moment(q):
    ns=Counter(q)
    if any(n%2 for n in ns.values()):return Fraction()
    return Fraction(prod(3 if n==4 else 1 for n in ns.values()),
        prod(j for n in Counter(i//4 for i in q).values() for j in range(4,4+n,2)))

def compute(site,axis,trace_slots):
    neighbor=next(iter(edge(site,axis)-{site}))
    ends=tuple(sorted((site,neighbor)))
    # The actual coframes all center at rank 12, including residual edge.
    alpha=defaultdict(list)
    qindex={(R.sites[x],axis,h,k):i for i,(x,h,k) in enumerate(product(ends,('L','R'),range(4)))}
    for component in range(4):
        for b in original_coframe_blocks(R,(R.sites[12],axis,component),L):
            for i,j in product(range(4),repeat=2):
                w=(positions[b.bar_site,'bar',i],positions[b.psi_site,'psi',j])
                for sy,z in b.matrix[i][j].terms:
                    assert len(sy)==1 and sy[0].index[:2]==b.anchor
                    c=(z.real*4*b.weight,z.imag*4*b.weight)
                    assert all(v.denominator==1 for v in c)
                    alpha[qindex[sy[0].index]].append((component,w,tuple(map(int,c))))
    support=0
    grouped=defaultdict(lambda:(0,0))
    weight_scale=48 if trace_slots else 4
    for q in product(range(16),range(16),*trace_slots):
        H=moment(q)*weight_scale
        if not H:continue
        assert H.denominator==1
        support+=1
        for (a,w,z),(b,v,t) in product(alpha[q[0]],alpha[q[1]]):
            word=w+v
            if len(set(word))!=4:continue
            local,remote=(sum(1<<(i%8) for i in word if i//8==x) for x in (site,neighbor))
            assert local.bit_count()==remote.bit_count()==2
            key=(local,remote,a,b,*q[2:])
            grouped[key]=add(grouped[key],tuple(int(H)*sign(word)*u for u in co(z,t)))
    nonzero={k:v for k,v in grouped.items() if any(v)}
    return nonzero,support,len(grouped)-len(nonzero)

from itertools import permutations
B=Path(sys.argv[6])
meta=load(B/'result.json')
readback=load(B/'readback.json')
full=[compute(12,d,()) for d in (2,3)]
edge2,edge3=(s[0] for s in full)
assert all((len(v),q,n)==(48,16,240) for v,q,n in full)
assert [edge2,edge3]==[tbl(B/f'edge12-axis{d}.jsonl') for d in (2,3)]
assert all(a==b for E in (edge2,edge3) for _,_,a,b in E)
for d,neighbor in ((2,14),(3,13)):
    fr,tr=owner(12,d)
    assert fr==tuple(('S4',12,i,d) for i in range(2)) and not tr and edge(12,d)=={12,neighbor}
print('rank12 source ownership and both complete 48-row degree-two edge tables matched',flush=True)

# Read the actual 24 original ordered S4 source coefficients, then index
# by their tail labels for lookup. This directly tests convention/sign.
epsilon={}
for v in original_action_factors(R,R.sites[12],L):
    if v.t_degree!=4:continue
    assert tuple(d for _,d,_ in v.components)==(0,1,2,3)
    assert all(site==R.sites[12] for site,_,_ in v.components)
    order=tuple(a for _,_,a in v.components)
    assert order not in epsilon
    ((key,z),)=v.coefficient.terms
    assert not key and not z.imag and z.real==sign(order)
    epsilon[order]=int(z.real)
assert set(epsilon)==set(permutations(range(4)))
tails=defaultdict(list)
for (a,b,c,d),s in epsilon.items():tails[c,d].append((a,b,s))

compact=defaultdict(lambda:(0,0))
proposal_count=0
# Alternative explicit complete loops: ordered original epsilon factors
# are conditioned by the selected edge tails and sign uses the full open word.
for ((m,r,c0,c1),x),((n,s,d0,d1),y) in product(edge2.items(),edge3.items()):
    if m&n:continue
    fmask=255^(m|n)
    word=pos(12,fmask)+sorted(pos(12,m)+pos(14,r))+sorted(pos(12,n)+pos(13,s))
    assert len(set(word))==len(word)==12
    sg=sign(word)
    assert sign([97 if i==96 else 96 if i==97 else i for i in word])==-sg
    z=co(x,y)
    for (a0,b0,s0),(a1,b1,s1) in product(tails[c0,d0],tails[c1,d1]):
        proposal_count+=1
        k=(fmask,a0,a1,b0,b1,r,s)
        compact[k]=add(compact[k],tuple(sg*s0*s1*t for t in z))
assert len(compact)==2016 and all(any(v) for v in compact.values())
assert dict(compact)==tbl(B/'rank12-compact.jsonl')
merges=tbl(A/'merge-rank12.jsonl')
attached={}
byfused=defaultdict(list)
for (m,n,fused),s in merges.items():
    assert not m&n and fused==m|n and s==sign(pos(12,m)+pos(12,n))
    byfused[fused].append((m,n,s))
for (fused,*labels),z in compact.items():
    for m,n,s in byfused[fused]:
        key=(m,n,*labels)
        assert key not in attached
        attached[key]=tuple(s*v for v in z)
assert len(attached)==12096 and attached==tbl(B/'rank12-closure.jsonl')
print('ordered source epsilons',len(epsilon),'proposals',proposal_count,'compact',len(compact),'attached',len(attached),flush=True)

bad=[]
for (m,n,a,b,c,d,r,s),z in sorted(attached.items()):
    v=attached.get((m,n,a,b,d,c,r,s),(0,0))
    if z!=v:bad.append(((m,n,a,b,c,d,r,s),z,v))
w=readback['local_axis1_swap_witness']
assert len(bad)==readback['rows_changed_by_axis1_swap_among_existing_keys']==6048
assert bad[0]==(f(w['key']),f(w['correct']),f(w['swapped_axis1_occurrence']))
print('axis1 adverse changes',len(bad),'first',bad[0],flush=True)

old=tbl(S/'edge-1.jsonl')
residual=tbl(A/'residual-edge.jsonl')
for i,c in enumerate(meta['controls']):
    lo,ro=f(c['old_edge_boundary']),f(c['residual_edge_boundary'])
    r,s=c['remote_masks']
    left={(m,a,b):z for (h,m,a,b,u,v),z in old.items() if (h,u,v)==lo}
    right={(n,a,b):z for (h,n,a,b,u,v),z in residual.items() if (h,u,v)==ro}
    # Recompute the entire junction directly, no compact or merge factor used.
    out=(0,0)
    pathsum=defaultdict(lambda:(0,0))
    for ((m,b0,b1),xl),((n,a0,a1),xr) in product(left.items(),right.items()):
        if m&n:continue
        for ((m2,r0,c0,c1),x2),((m3,s0,d0,d1),x3) in product(edge2.items(),edge3.items()):
            if (r0,s0)!=(r,s) or (m|n|m2|m3)!=255 or any(i&j for k,i in enumerate((m,n,m2,m3)) for j in (m,n,m2,m3)[k+1:]):
                continue
            w=pos(12,m)+sorted(pos(4,ro[0])+pos(12,n))+sorted(pos(12,m2)+pos(14,r))+sorted(pos(12,m3)+pos(13,s))
            assert len(set(w))==len(w)==14
            sg=sign(w)
            assert sign([97 if j==96 else 96 if j==97 else j for j in w])==-sg
            v=co(co(xl,xr),co(x2,x3))
            eps0=epsilon.get((a0,b0,c0,d0),0)
            eps1=epsilon.get((a1,b1,c1,d1),0)
            piece=tuple(sg*eps0*eps1*x for x in v)
            if any(piece):
                path=(m,n,a0,a1,b0,b1,r,s)
                pathsum[path]=add(pathsum[path],piece)
                out=add(out,piece)
    assert out==f(c['signed_numerator']) and len(pathsum)==12 and all(any(x) for x in pathsum.values())
    key,value=f(c['first_compact_path'])
    assert pathsum[key]==value
    assert tuple(x-2*y for x,y in zip(out,value))==f(c['adverse_single_path_sign_numerator'])
    assert all((a==b and cc==dd) for _,_,a,b,cc,dd,_,_ in pathsum)
    assert f(c['swapped_axis3_occurrence_numerator'])==out
    assert f(readback['junction_readback'][i]['swapped_axis1_occurrence_numerator'])==out
    print('junction',i,out,'12 paths and sign-adverse',tuple(x-2*y for x,y in zip(out,value)),flush=True)
assert meta['closure_denominator']==64**2 and c['denominator']==768**2*64**2
assert Fraction(out[0],c['denominator'])==Fraction(3,512)

new=load(B/'graph.json')
assert new['combined_denominator']==G['combined_denominator']*64**2==881306922499064668360802304
assert new['external_exponential_divisor']==512
assert new['factor_keys']['rank12_closure']==['old_mask12','new_mask12','S4_12_a0_0','S4_12_a0_1','S4_12_a1_0','S4_12_a1_1','remote14','remote13']
assert set(new['boundary'])==set(G['boundary'])-{'remote12','S4_12_a0_0','S4_12_a0_1','S4_12_a1_0','S4_12_a1_1'}|{'remote14','remote13'}
assert {k:v for k,v in G['factor_keys'].items() if k!='merge_rank12'}=={k:v for k,v in new['factor_keys'].items() if k!='rank12_closure'}
for d,y in ((2,6),(3,5)):
    fr,tr=owner(4,d)
    assert fr==tuple(('S4',y,i,d) for i in range(2)) and not tr and edge(4,d)=={4,y}
print('rank4 next owners are distinct S4 rank6 and rank5; their ordered components remain open',flush=True)
