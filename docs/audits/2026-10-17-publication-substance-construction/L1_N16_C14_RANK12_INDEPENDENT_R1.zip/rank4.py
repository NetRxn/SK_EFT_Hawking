from collections import Counter, defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from fractions import Fraction
import json,sys
from src.core.formulas import original_action_factors, original_spin4_link, original_coframe_blocks
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
A,T,S,SE,P=map(Path,sys.argv[1:6])
def load(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def f(v): return tuple(map(f,v)) if isinstance(v,(tuple,list)) else v
def tbl(p):
    rr=f(rows(p)); t=dict(rr); assert len(rr)==len(t)
    return t
def co(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def add(z,w):return z[0]+w[0],z[1]+w[1]
def sign(w):return (-1)**sum(i>j for k,i in enumerate(w) for j in w[k+1:])
def pos(site,mask):return [8*site+i for i in range(8) if mask>>i&1]
R=OriginalRegulator()
index={x:i for i,x in enumerate(R.sites)}
positions={g:i for i,g in enumerate(R.generator_order)}
assert (R.extents,R.boundary_signs,R.convention,R.word)==((2,)*4,(1,)*4,'source_C','closed')
L={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in R.link_order}
M=load(A/'result.json')
G=load(A/'graph.json')
base=load(T/'graph.json')
C=load(P/'support-census.json')['sites']
row=load(S/'result.json')['row']
assert row['exponential_divisor']==512
acts=[]
for i,(x,*axes) in enumerate(row['planes']):
    anchors={tuple(sorted((index[tuple(y)],d) for y,d in aa)) for degree,comp,aa,n,_ in C[x]['raw_branches']
             if n and degree==2 and sorted(j for j,_ in comp)==axes}
    assert len(anchors)==1
    acts.append(('S2',x,i,tuple(axes),next(iter(anchors))))
acts += [('S4',x,i,tuple(range(4)),()) for x,n in enumerate(row['S4_occupations']) for i in range(n)]

def edge(rank,d):
    return frozenset((rank,index[R.step(R.sites[rank],d)[0]]))
def owner(rank,axis):
    E=edge(rank,axis)
    frames=[(s,x,i,d) for s,x,i,axes,_ in acts for d in axes if edge(x,d)==E]
    traces=[(s,x,i,(k,d)) for s,x,i,_,aa in acts for k,d in aa if edge(k,d)==E]
    return f(frames),f(traces)
fr,tr=owner(4,0)
assert f(M['edge'])==(0,12,fr,tr)
assert fr==(('S4',12,0,0),('S4',12,1,0))
assert tr==(('S2',0,2,(4,0)),('S2',0,3,(4,0)))

@cache
def moment(q):
    ns=Counter(q)
    if any(n%2 for n in ns.values()):return Fraction()
    return Fraction(prod(3 if n==4 else 1 for n in ns.values()),
        prod(j for n in Counter(i//4 for i in q).values() for j in range(4,4+n,2)))

def compute(site,axis,trace_slots,center):
    neighbor=next(iter(edge(site,axis)-{site}))
    ends=tuple(sorted((site,neighbor)))
    # The actual coframes all center at rank 12, including residual edge.
    alpha=defaultdict(list)
    qindex={(R.sites[x],axis,h,k):i for i,(x,h,k) in enumerate(product(ends,('L','R'),range(4)))}
    for component in range(4):
        for b in original_coframe_blocks(R,(R.sites[center],axis,component),L):
            for i,j in product(range(4),repeat=2):
                w=(positions[b.bar_site,'bar',i],positions[b.psi_site,'psi',j])
                for sy,z in b.matrix[i][j].terms:
                    assert len(sy)==1 and sy[0].index[:2]==b.anchor
                    c=(z.real*4*b.weight,z.imag*4*b.weight)
                    assert all(v.denominator==1 for v in c)
                    alpha[qindex[sy[0].index]].append((component,w,tuple(map(int,c))))
    support=0
    grouped=defaultdict(lambda:(0,0))
    weight_scale=48 if trace_slots else 4
    for q in product(range(16),range(16),*trace_slots):
        H=moment(q)*weight_scale
        if not H:continue
        assert H.denominator==1
        support+=1
        for (a,w,z),(b,v,t) in product(alpha[q[0]],alpha[q[1]]):
            word=w+v
            if len(set(word))!=4:continue
            local,remote=(sum(1<<(i%8) for i in word if i//8==x) for x in (site,neighbor))
            assert local.bit_count()==remote.bit_count()==2
            key=(local,remote,a,b,*q[2:])
            grouped[key]=add(grouped[key],tuple(int(H)*sign(word)*u for u in co(z,t)))
    nonzero={k:v for k,v in grouped.items() if any(v)}
    return nonzero,support,len(grouped)-len(nonzero)


e=[]
for d,y in ((2,6),(3,5)):
    fr,tr=owner(4,d)
    assert fr==tuple(('S4',y,i,d) for i in range(2)) and not tr
    assert edge(4,d)=={4,y}
    t,s,z=compute(4,d,(),y)
    assert len(t)==48 and s==16 and z==240
    print('rank4 next',d,'neighbor',y,'rows',len(t),'denominator 64')
    e.append(t)
proposals=[(k,l) for k,l in product(*e) if not k[0]&l[0]]
domain={255^(k[0]|l[0]) for k,l in proposals}
print('rank4 next raw edge pairing budget',len(e[0])*len(e[1]),'disjoint',len(proposals),'fused masks',len(domain))
assert len(domain)>0
