from pathlib import Path
import json,sys
a=Path(sys.argv[1])
m=json.loads((a/'result.json').read_text())
assert sum(m['charged_operations'].values())==162921<m['cap']['work']==4_000_000
s=m['storage']
assert s['rows']==107424<m['cap']['rows']==120000
assert s['charged_bytes']==512*s['rows']==55001088<m['cap']['accounted_bytes']==64*1024**2
files=('edge12-axis2.jsonl','edge12-axis3.jsonl','rank12-compact.jsonl','rank12-closure.jsonl')
assert s['serialized_bytes']==sum((a/f).stat().st_size for f in files)==458752<m['cap']['serialized_bytes']==4*1024**2
assert m['rss_peak_bytes']==138297344<m['cap']['sampled_rss']==384*1024**2
assert m['cap']['scalar']==2**61-1
print('scoped work, cumulative row and accounting byte meters, file sizes and sampled RSS receipt checked')
