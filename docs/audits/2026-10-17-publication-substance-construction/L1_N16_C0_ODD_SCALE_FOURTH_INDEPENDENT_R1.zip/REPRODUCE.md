# Fourth L1 odd-root scale-up independent acceptance

The archived independent report records factor and contraction coverage.
Verify the SHA-256 manifest and run
`python3 check-residual.py independent/reviewed-exact.tsv` to reproduce
the one-profile subtraction from the third accepted residual.

Full c0 and physical B3 remain open.
