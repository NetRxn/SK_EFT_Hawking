# Independent fourth odd-root scale-up review

**ACCEPT** original representative `(155950080585,580896423965)` at
weight 96. Its exact source-normalized signed coefficient is
`1256039477675214589546875/2475880078570760549798248448`. The
orbit-weighted contribution is
`3768118433025643768640625/77371252455336267181195264`.
Recording this one row leaves **9,639 unresolved orbits and 830,439
labels** in the original temporal residual. The full original c0
sign, value and nonvanishing remain open.

## Pinned inputs and original support

The primary continuity snapshot checked fresh at both boundaries.
The pinned clean checkpoint is
`ec448b05ad71a355cc0f46c32f14d72eb086df35` and matched its tracked
upstream. I verified the 83-file frozen author manifest, 50 raw
spatial-edge entries, 1,142 projected factors and alias files, 38
accepted residual files and the preceding 32-file independent review.
The author archive manifest matches the checked-in one. The exact
residual extracted from the accepted third scale-up archive matches
the supplied residual bytes. The fourth representative is present
exactly once at weight 96. The pilot and the three previously
accepted scale-up profiles are absent.

A complete independent enumeration of 1,048,576 projected assignments
checks the original two-chirality temporal singlets, spatial load
bounds and the corrected combined center parity. It recovers exactly
62 states. The 31 frozen cases and their simultaneous chirality
flips cover this roster with no fixed point or duplicate pair.
All 2,976 full support anchor-plan rows and all 1,488 selected
representative rows match. The established source gamma3 involution
permutes the chiral Haar factors while preserving the filled local
Grassmann top. Each elementary EHC insertion changes sign, and
all 32 give an even sign overall. The complete coefficient is
twice the signed sum of the 31 representative values.

## Source normalization, signs and factors

The original occupation contains 28 zero powers, ten ones, eight
twos and two threes. All insertion factorials remain in place,
giving `(2!)⁸(3!)²=9216`. Each original insertion contributes
two coframes, whose raw exported coefficients have the original
quarters removed. Restoring them gives the factor 4⁻⁶⁴. The
literal block assembly matches all 512 quarter-stripped rows.
The 768 canonical original EHC ordering controls confirm that
the two curvature and two complementary coframe orderings
cancel the separate action prefactor 1/4. The two layers'
axis counts are (4,8,4) and (4,4,8). Both original world epsilon
products and the cross-site wedge parity are positive. The latter
agrees with 64 exact generator layouts for each layer. The
within-site signed inversions remain in every mask factor.

The independent factor checks include:

- All linear, quadratic and cubic root projections and their
  signs. The literal source reproduces all 1,718 nonzero entries
  from 4,920 candidates.
- All temporal and spatial anchor moments. Independent normalized
  quaternion moment calculation matches 90 temporal nonzeros
  across ten shapes and 3,372 spatial nonzeros across 37 shapes,
  after evaluating 722 and 68,622 full entries, respectively.
- Every row of every one of the 50 exact projected spatial-edge
  identities. For each reduced row, the two original endpoint
  alias preimages reconstruct a disjoint set of original rows.
  Multiplication by both exact Gaussian gains reconstructs all
  211,716 unsqueezed coefficients with their original anchored
  matrix indices. The comparison checks full support and gains,
  including that no row is added or omitted. In addition, 71
  signed literal coframe targets across all 50 raw patterns
  agree, including imaginary targets where present. The largest
  planned direct target has 1,048,576 candidate products.
  The production unsqueezed edge tables are otherwise reused
  from their checked hashes rather than regenerated in full.
- Every row of all 992 split site factors. For fixed original
  coframe words, the root tensor depends on the original matrix
  indices. The mask tensor sums over actual disjoint endpoint
  masks with the full original wedge sign. It multiplies their
  exact endpoint alias gains and preserves the canonical edge
  indices. Contracting both tensors over the three original
  coframe words gives the unsplit site contraction. The reviewer
  directly rebuilds all 6,263,704 projected mask rows and
  2,418,195 root rows. Peak planned root and mask work per site
  is 207,360 and 561,152, respectively. Individual mask/root
  tables have at most 135,840 and 92,816 rows.

## Signed replay

I rebuilt each 88-factor signed network in its original coordinates.
The matrix, word and mask wires follow the previously verified
closed-plaquette incidence, and every nontrivial wire appears twice.
All initial cardinalities and wire counts agree with the author logs.

The independent tuple-key quotient aggregates identical full primitive
Gaussian coefficient slices on the complete shared tuple, applying
their exact gains to the adjacent factor. This identity preserves
all other open indices and both denominator scales. Whole-slice
support comparison and exact addition also certify the empty
factors used to prove the 23 zero channels. The implementation
passes 129 direct open-boundary controls, including unmatched
two-index bonds and exact signed cancellation.

All 31 signed values match the frozen author table. Six are
positive, two negative, and 23 zero. Representatives 7 and 16
each give `-90124024193107734375/19807040628566084398385987584`.
Each was computed directly. Both negative values remain in the
signed sum. All nonzero results are real. The complete 31-row
table is `pair-exact.tsv`, and the single original reviewed
coefficient is in `reviewed-exact.tsv`.

The largest initial network has 590,870 rows across its factors.
The maximum admitted join has 8,304 matched coefficient products
and a largest output of 4,608 rows. The maximum full numerical
path uses 37,689 matched products. Quotient and histogram scans
are charged separately and reach 28,923,326 in the largest
nonzero case. Prospective work and height guards precede
coefficient arithmetic, and row limits guard sparse insertion.
The counts exclude raw-edge preparation. They do not establish
broad batch throughput.

This receipt covers only the fourth profile. No repository,
manuscript or Lean state changed.

## Replay

Scratch uses `AUTHOR` for the frozen intake, `UNSQUEEZED` for
the original spatial-edge files, `SPLIT` for the projected factors,
`SUPPORT` for the full screened anchor input, `INDEPENDENT` for the
previous projection and `prior-coframes.tsv` for the canonical
quarter-stripped coframes. `residual.tsv` comes from the approved
third scale-up archive. Use clean science candidate `51e7c745e`
for the literal source checks.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 support.py > support.out
PYTHONDONTWRITEBYTECODE=1 python3 moments.py > moments.out
PYTHONDONTWRITEBYTECODE=1 python3 edge-reconstruct.py > edge-reconstruct.out
PYTHONDONTWRITEBYTECODE=1 python3 edge-control.py > edge-control.out
PYTHONDONTWRITEBYTECODE=1 python3 quotient-control.py > quotient-control.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" root-rebuild.py > root-rebuild.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" normalization.py > normalization.out
for start in 0 8 16 24; do
  stop=$((start+8)); [ "$stop" -le 31 ] || stop=31
  PYTHONDONTWRITEBYTECODE=1 python3 site-reconstruct.py "$start" "$stop" > "site-$start.out"
  PYTHONDONTWRITEBYTECODE=1 python3 replay.py $(seq "$start" "$((stop-1))") > "cases-$start.out"
done
python3 verify.py > verification.out
shasum -a 256 -c manifest.sha256
```
