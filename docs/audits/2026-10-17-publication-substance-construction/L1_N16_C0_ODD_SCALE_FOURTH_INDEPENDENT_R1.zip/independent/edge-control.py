from ast import literal_eval as parse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from math import prod
from pathlib import Path
from moments import integral,mul,add

C=defaultdict(list)
for l in Path('prior-coframes.tsv').open():
    o,w,m,q,r,s=map(int,l.split())
    C[o,w].append((m,q,(r,s)))

def raw(shape,indices,wh):
    h,a,b,c,d=shape
    left=tuple(i for i in indices if i<4)
    right=tuple(i-4 for i in indices if i>=4)
    (u,U),(v,V),(x,X),(y,Y)=wh
    return mul(integral(((a,u,v,True),(c,x,y,False)),left),
               integral(((b,U,V,True),(d,X,Y,False)),right))

def literal(shape,line):
    ar,br,S,T=shape
    a,b,mask,X,Y,r,s=line.split('\t')
    words=(parse(a),parse(b))
    assert (len(words[0]),len(words[1]))==(ar,br)
    target=int(mask)
    roster=[[row for row in C[o,w] if row[0]&~target==0]
            for o in range(2) for w in words[o]]
    A=parse(X);B=parse(Y)
    count=prod(map(len,roster))
    assert count<=2_000_000
    result=(0,0)
    for choices in product(*roster):
        indices=[]
        z=(1,0)
        occupied=0
        odd=0
        for mask,q,value in choices:
            if occupied&mask:break
            odd+=sum((occupied>>(i+1)).bit_count() for i in range(16) if mask>>i&1)
            occupied|=mask
            z=mul(z,value)
            indices.append(q)
        else:
            assert occupied==target
            if odd&1:z=(-z[0],-z[1])
            left=tuple(sorted(k for k in indices if k<8))
            right=tuple(sorted(k-8 for k in indices if k>=8))
            result=add(result,mul(z,mul(raw(S,left,A),raw(T,right,B))))
    assert result==(F(r),F(s)),(shape,line,result)
    return count

total=0
peak=0
for j,l in enumerate(x for x in Path('AUTHOR/edge-plan.out').read_text().splitlines() if x.startswith('pattern ')):
    shape=parse(l[8:l.rindex(')')+1])
    with Path(f'UNSQUEEZED/edge-batch/{j:02}.tsv').open() as f:
        keys=[next(f)]
        if keys[0].split()[-1]=='0':
            for line in f:
                if line.split()[-1]!='0':
                    keys.append(line);break
        for line in keys:
            q=literal(shape,line)
            total+=1
            peak=max(peak,q)
print('literal signed target rows',total,'from 50 edge shapes; peak direct product candidates',peak)
