from collections import Counter,defaultdict
from fractions import Fraction as F
from pathlib import Path
K=(155950080585,580896423965,96)
roster=[tuple(map(int,l.split())) for l in Path('residual.tsv').read_text().splitlines()]
assert (len(roster),len(set(roster)),sum(w for a,b,w in roster))==(9640,9640,830535)
assert [t for t in roster if t[:2]==K[:2]]==[K]
assert not any((a,b) in {(103607566400,1256282136720),(103607566400,1256282652690),(103607566400,1261652672530),(140684411270,558347329670)} for a,b,w in roster)
author={}
for l in Path('AUTHOR/pair-values.tsv').read_text().splitlines()[1:]:
    j,x=l.split()
    assert int(j) not in author
    author[int(j)]=F(x)
meta={}
expected={}
archives=defaultdict(int)
for p in sorted(Path('AUTHOR/cases').glob('*.out')):
    text=p.read_text().splitlines()
    n,w,r=map(int,(text[0].split()[4],text[0].split()[6],text[0].split()[9]))
    j=int(text[0].split()[1])
    assert j==int(p.stem.split('-')[1]) and n==88
    fields=text[-1].split()
    if fields[:2]==['EXACT','ZERO']:
        value=F(0)
    else:
        assert fields[:3]==['EXACT','channel',str(j)] and F(fields[4])==0
        value=F(fields[3])
    assert author[j]==value
    if j in expected:assert expected[j]==(w,r)
    expected[j]=(w,r)
    archives[j]+=1
assert len(archives)==31 and set(archives.values())=={1}
values={}
limits=[]
joins={}
zero={}
for shard in (0,8,16,24):
    for l in Path(f'cases-{shard}.out').read_text().splitlines():
        p=l.split()
        if p[0]=='case':
            j,n,w,r=map(int,(p[1],p[3],p[5],p[8]))
            assert n==88 and j not in meta and (w,r)==expected[j]
            meta[j]=(w,r)
        elif p[0]=='EXACT':
            assert int(p[1])==j and j not in values
            values[j]=F(p[2])
        elif p[0]=='stats':
            limits.append(tuple(map(int,(p[4],p[7],p[9],p[11]))))
        elif p[0]=='join':
            p0,r0,t0=int(p[2]),int(p[3]),int(p[5])
            old=joins.get(j,(0,0,0))
            joins[j]=max(old[0],p0),max(old[1],r0),t0
        elif p[:2]==['empty','quotient']:
            assert j not in zero
            zero[j]=l
assert set(meta)==set(values)==set(range(31))
assert values==author
counts=Counter((z>0)-(z<0) for z in values.values())
assert counts=={0:23,1:6,-1:2} and len(limits)==8
assert [j for j,z in values.items() if z<0]==[7,16]
assert {j for j,z in values.items() if not z}==set(zero)
s=2*sum(values.values())
a,b,w,v,x=Path('AUTHOR/author-exact.tsv').read_text().splitlines()[1].split()
assert tuple(map(int,(a,b,w)))==K and s==F(v) and s*K[2]==F(x)
remain=[r for r in roster if r!=K]
assert len(remain)==9639 and sum(r[2] for r in remain)==830439
print('pair signs',counts,'negatives',values[7],values[16])
print('max initial rows',max(r for w,r in meta.values()),'max numerical join/output/cumulative',
      *[max(v) for v in zip(*joins.values())])
print('max nonzero factor / join / cumulative / charged scans',*[max(v) for v in zip(*limits)])
print('exact normalized signed representative',s)
print('weighted contribution',s*K[2])
print('residual after this one subtraction',len(remain),sum(r[2] for r in remain))
Path('reviewed-exact.tsv').write_text('\t'.join(map(str,(*K,s)))+'\n')
Path('pair-exact.tsv').write_text(''.join(f'{j}\t{values[j]}\n' for j in sorted(values)))
