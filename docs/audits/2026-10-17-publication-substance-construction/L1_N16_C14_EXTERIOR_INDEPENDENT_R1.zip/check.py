from collections import Counter, defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from fractions import Fraction
import json,sys
from src.core.formulas import original_action_factors, original_spin4_link, original_coframe_blocks
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
A,T,S,SE,P=map(Path,sys.argv[1:6])
def load(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def f(v): return tuple(map(f,v)) if isinstance(v,(tuple,list)) else v
def tbl(p):
    rr=f(rows(p)); t=dict(rr); assert len(rr)==len(t)
    return t
def co(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def add(z,w):return z[0]+w[0],z[1]+w[1]
def sign(w):return (-1)**sum(i>j for k,i in enumerate(w) for j in w[k+1:])
def pos(site,mask):return [8*site+i for i in range(8) if mask>>i&1]
R=OriginalRegulator()
index={x:i for i,x in enumerate(R.sites)}
positions={g:i for i,g in enumerate(R.generator_order)}
assert (R.extents,R.boundary_signs,R.convention,R.word)==((2,)*4,(1,)*4,'source_C','closed')
L={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in R.link_order}
M=load(A/'result.json')
G=load(A/'graph.json')
base=load(T/'graph.json')
C=load(P/'support-census.json')['sites']
row=load(S/'result.json')['row']
assert row['exponential_divisor']==512
acts=[]
for i,(x,*axes) in enumerate(row['planes']):
    anchors={tuple(sorted((index[tuple(y)],d) for y,d in aa)) for degree,comp,aa,n,_ in C[x]['raw_branches']
             if n and degree==2 and sorted(j for j,_ in comp)==axes}
    assert len(anchors)==1
    acts.append(('S2',x,i,tuple(axes),next(iter(anchors))))
acts += [('S4',x,i,tuple(range(4)),()) for x,n in enumerate(row['S4_occupations']) for i in range(n)]

def edge(rank,d):
    return frozenset((rank,index[R.step(R.sites[rank],d)[0]]))
def owner(rank,axis):
    E=edge(rank,axis)
    frames=[(s,x,i,d) for s,x,i,axes,_ in acts for d in axes if edge(x,d)==E]
    traces=[(s,x,i,(k,d)) for s,x,i,_,aa in acts for k,d in aa if edge(k,d)==E]
    return f(frames),f(traces)
fr,tr=owner(4,0)
assert f(M['edge'])==(0,12,fr,tr)
assert fr==(('S4',12,0,0),('S4',12,1,0))
assert tr==(('S2',0,2,(4,0)),('S2',0,3,(4,0)))

@cache
def moment(q):
    ns=Counter(q)
    if any(n%2 for n in ns.values()):return Fraction()
    return Fraction(prod(3 if n==4 else 1 for n in ns.values()),
        prod(j for n in Counter(i//4 for i in q).values() for j in range(4,4+n,2)))

def compute(site,axis,trace_slots,center):
    neighbor=next(iter(edge(site,axis)-{site}))
    ends=tuple(sorted((site,neighbor)))
    # The actual coframes all center at rank 12, including residual edge.
    alpha=defaultdict(list)
    qindex={(R.sites[x],axis,h,k):i for i,(x,h,k) in enumerate(product(ends,('L','R'),range(4)))}
    for component in range(4):
        for b in original_coframe_blocks(R,(R.sites[center],axis,component),L):
            for i,j in product(range(4),repeat=2):
                w=(positions[b.bar_site,'bar',i],positions[b.psi_site,'psi',j])
                for sy,z in b.matrix[i][j].terms:
                    assert len(sy)==1 and sy[0].index[:2]==b.anchor
                    c=(z.real*4*b.weight,z.imag*4*b.weight)
                    assert all(v.denominator==1 for v in c)
                    alpha[qindex[sy[0].index]].append((component,w,tuple(map(int,c))))
    support=0
    grouped=defaultdict(lambda:(0,0))
    weight_scale=48 if trace_slots else 4
    for q in product(range(16),range(16),*trace_slots):
        H=moment(q)*weight_scale
        if not H:continue
        assert H.denominator==1
        support+=1
        for (a,w,z),(b,v,t) in product(alpha[q[0]],alpha[q[1]]):
            word=w+v
            if len(set(word))!=4:continue
            local,remote=(sum(1<<(i%8) for i in word if i//8==x) for x in (site,neighbor))
            assert local.bit_count()==remote.bit_count()==2
            key=(local,remote,a,b,*q[2:])
            grouped[key]=add(grouped[key],tuple(int(H)*sign(word)*u for u in co(z,t)))
    nonzero={k:v for k,v in grouped.items() if any(v)}
    return nonzero,support,len(grouped)-len(nonzero)

from functools import cache
from itertools import combinations
B,PURE=map(Path,sys.argv[6:8])
m=load(B/'result.json')
prior=load(PURE/'graph.json')
edge_meta=prior['pending_exterior_edges']
edges=[tuple(e['mask_order']) for e in edge_meta]
assert edges==list(map(tuple,m['edges'])) and len(edges)==16
sites=tuple(sorted({s for e in edges for s in e}))
boundary=tuple(sites[:-1])
assert sites[-1]==15 and list(boundary)==m['boundary_order']
COMMON=None
inc=defaultdict(list)
for i,(e,meta) in enumerate(zip(edges,edge_meta,strict=True)):
    c,n=e
    d=meta['axis']
    fr,tr=owner(c,d)
    assert fr==tuple(('S4',c,j,d) for j in (0,1)) and not tr and edge(c,d)=={c,n}
    full,hs,zeros=compute(c,d,(),c)
    assert (len(full),hs,zeros)==(48,16,240)
    simple=tbl(PURE/meta['file'])
    assert full=={(u,v,j,j):z for (u,v),z in simple.items() for j in range(4)}
    normal={(u,v):z[0]//8 for (u,v),z in simple.items()}
    assert all(i==0 and r%8==0 for r,i in simple.values())
    if COMMON is None:COMMON=normal
    assert COMMON==normal
    for s,t in ((c,n),(n,c)):inc[s].append(i)
print('all 16 normalized source maps and endpoint orders independently reproduced',flush=True)

for s,expected in ((1,(9,5)),(2,(10,6))):
    group=[]
    for axis,c in enumerate(expected):
        fr,tr=owner(s,axis)
        assert fr==tuple(('S4',c,j,axis) for j in (0,1)) and not tr
        full,support,zero=compute(s,axis,(),c)
        assert full=={(a,b,j,j):(8*n,0) for (a,b),n in COMMON.items() for j in range(4)}
        group.append(full)
    d=defaultdict(lambda:(0,0))
    for ((p,x,i,j),z),((q,y,k,l),w) in product(*[[(k,z) for k,z in t.items() if k[2:]==(0,0)] for t in group]):
        if p&q:continue
        o=255^(p|q)
        w0=pos(s,o)+sorted(pos(s,p)+pos(expected[0],x))+sorted(pos(s,q)+pos(expected[1],y))
        sg=sign(w0)
        lo=8*s
        assert sign([lo+1 if n==lo else lo if n==lo+1 else n for n in w0])==-sg
        key=(o,x,y)
        d[key]=add(d[key],tuple(sg*v for v in co(z,w)))
    d={k:v for k,v in d.items() if any(v)}
    assert len(d)==84 and d==tbl(B/f'rank{s}-projection.jsonl')
print('rank1 and rank2 direct full-word projection tables 84+84 matched',flush=True)

HAND=((3,5,10,12),(48,80,160,192))
FULL=(15,240)
def ch(mask):return int(mask>=16)
def term(edge,site,h):return ((edge>>site)&1)^h

def connect(mask):
    # Site/chirality vertices carry degree one (boundary) or two
    # (actual complement); physical edges join opposite hands.
    handcounts=Counter()
    adjacent=defaultdict(list)
    fixed={}
    for i,(a,b) in enumerate(edges):
        h=mask>>i&1
        A,B=(a,h),(b,h^1)
        handcounts.update((A,B))
        adjacent[A].append(B)
        adjacent[B].append(A)
    for s in sites:
        a,b=handcounts[s,0],handcounts[s,1]
        if s==15 and (a,b)!=(2,2):return None
        if s in (1,2):
            if a==0:fixed[s]=FULL[0]
            if b==0:fixed[s]=FULL[1]
        elif not(1<=a<=2 and 1<=b<=2):return None
    return adjacent,fixed

def walk(remaining,adj):
    comp=set()
    seen=[min(remaining)]
    while seen:
        u=seen.pop()
        if u in comp:continue
        comp.add(u); seen.extend(adj[u])
    ends=sorted(u for u in comp if len(adj[u])==1)
    assert len(ends) in (0,2)
    start=ends[0] if ends else min(comp)
    path=[start]
    prev=None
    cur=start
    while True:
        nxt=next((u for u in sorted(adj[cur]) if u!=prev),None)
        if nxt is None:break
        path.append(nxt)
        if nxt==start:break
        prev,cur=cur,nxt
    assert set(path)==comp and (bool(ends) or path[-1]==path[0])
    remaining.difference_update(comp)
    return tuple(u[1] for u in path),ends

def pairing(x,y):
    h=ch(x)
    assert ch(y)==h and x|y==FULL[h] and not x&y
    return sign(pos(0,x)+pos(0,y))

@cache
def transfer(seq,loop):
    result={}
    for x in HAND[seq[0]]:
        incoming={x:1}
        # x is the incoming old boundary mask or the starting loop mask.
        for a,b in zip(seq,seq[1:]):
            out=defaultdict(int)
            for z,v in incoming.items():
                leave=FULL[a]^z
                parity=pairing(z,leave)
                for k in HAND[b]:
                    out[k]+=v*parity*COMMON.get((leave,k),0)
            incoming=out
        if loop:
            result[x,x]=incoming[x]
        else:
            for arrived,n in incoming.items():
                if n:
                    old=FULL[seq[-1]]^arrived
                    result[x,old]=n*pairing(arrived,old)
    return sum(result.values()) if loop else result

def reference(mask):
    q=connect(mask)
    if q is None:return None
    adj,fixed=q
    remaining=set(adj)
    scalar=1
    paths={}
    while remaining:
        seq,ends=walk(remaining,adj)
        t=transfer(seq,not ends)
        if not ends:
            assert t==3*(-2)**(len(seq)-1)
            scalar*=t
        else:
            e=len(seq)-1
            assert len(t)==6 and Counter(t.values())==Counter({(-2)**e:2,(-1)**(e+1)*2**(e-1):4})
            paths[tuple(ends)]=t
    return fixed,scalar,paths

stored={}
for orient,fixed,scalar,paths in rows(B/'exterior-orientations.jsonl'):
    assert orient not in stored
    stored[orient]=(dict(fixed),scalar,{(tuple(a),tuple(b)):{(u,v):z for u,v,z in t} for a,b,t in paths})
counts=Counter()
path_rows=gross=0
first=None
for ori in range(65536):
    e=reference(ori)
    if e is None:
        assert ori not in stored
        continue
    assert e==stored[ori]
    k=len(e[2])
    counts[k]+=1
    path_rows+=sum(map(len,e[2].values()))
    n=prod(map(len,e[2].values()))
    if first is None and gross+n>4_000_000:
        first=dict(orientation=ori,previous_visits=gross,term_visits_this_orientation=n,prospective_visits=gross+n,cap=4_000_000)
    gross+=n
assert counts=={4:588,5:1296,6:720} and sum(counts.values())==2604 and path_rows==78912 and gross==44432064
assert first==load(B/'preflight.json')['first_prospective_refusal']
print('all 65536 orientations checked using site-chirality transfer; 2604 accepted, 78912 exact path rows; flatten refusal',first,flush=True)

# Independent literal traversal uses reverse physical edge order and final
# whole-site-major word, rather than on-the-fly site sign multiplication.
for c in m['controls']:
    old=dict(zip(boundary,c['boundary'],strict=True))
    masks={s:old.get(s,0) for s in sites}
    used={}
    total=adverse=count=0
    order=tuple(reversed(range(16)))
    last={s:min(inc[s]) for s in sites}
    def recurse(t,weight):
        global total,adverse,count
        if t==16:
            word=[j for s in boundary for j in pos(s,old[s])]
            for i,(a,b) in enumerate(edges):
                x,y=used[i]
                word+=sorted(pos(a,x)+pos(b,y))
            assert len(word)==len(set(word))==8*len(sites)
            total+=weight*sign(word)
            lo=8*boundary[0]
            adverse+=weight*sign([lo+1 if j==lo else lo if j==lo+1 else j for j in word])
            count+=1
            return
        i=order[t]
        a,b=edges[i]
        for (x,y),z in COMMON.items():
            if x&masks[a] or y&masks[b]:continue
            m,n=masks[a],masks[b]
            if (i==last[a] and m|x!=255) or (i==last[b] and n|y!=255):continue
            masks[a],masks[b]=m|x,n|y
            used[i]=(x,y)
            recurse(t+1,weight*z)
            masks[a],masks[b]=m,n
    recurse(0,1)
    assert (total,count,adverse)==(c['normalized_numerator'],c['exact_literal_paths'],c['wrong_single_site_top_orientation'])
    assert c['denominator']==8**16
    print('whole-word reversed-edge control',total,count,'single-site sign reversal',adverse,flush=True)

graph=load(B/'graph.json')
assert graph['external_exponential_divisor']==512
assert graph['scalar_numerator_multiplier']==24**5
assert graph['boundary']==prior['boundary']
assert graph['factor_keys']==prior['factor_keys']
assert graph['replaced_pending_exterior_denominator_multiplier']==64**16
assert graph['combined_denominator']==prior['combined_denominator']
assert graph['exact_denominator_before_exponential_divisor']==prior['combined_denominator']*8**16
assert graph['exterior_environment']['denominator']==8**16
assert graph['exterior_environment']['boundary']==[f'remote{s}' for s in boundary]
assert graph['replaced_pending_edges']==prior['pending_exterior_edges']
assert 'pending_exterior_denominator_multiplier' not in graph
print('whole-graph core denominator, normalized exterior factor 8^16 and scalar/external factors exactly once',flush=True)
