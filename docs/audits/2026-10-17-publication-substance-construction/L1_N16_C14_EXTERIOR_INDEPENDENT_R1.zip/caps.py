from pathlib import Path
import sys,json
a=Path(sys.argv[1]);m=json.loads((a/'result.json').read_text())
s=m['storage'];c=m['cap']
assert sum(m['charged_operations'].values())==615373<c['work']==4_000_000
assert s['rows']==7298<c['rows']==120000
assert s['charged_bytes']==512*s['rows']==3736576<c['accounted_bytes']==64*1024**2
assert s['serialized_bytes']==sum(x.stat().st_size for x in a.glob('*.jsonl'))==1128686<c['serialized_bytes']==4*1024**2
assert m['rss_peak_bytes']==110215168<c['sampled_rss']==384*1024**2
assert c['scalar']==2**61-1
print('all scoped work, cumulative rows, accounting/output bytes, sampled RSS and checked arithmetic limits consistent')
