# D8 1.5 scratch author handoff

Base MAIN 8a99bcc0e353a136b2b84595bb27aa1bfe19e16c. Intake and final canonical continuity checks returned fresh=true and changed=[]. The real checkout stayed clean.

Patch /tmp/publication-d8-primary-propagation-r1.patch, SHA256 ac53d1a46f81b693a4d57cf3d3d69e6f402cb16783cb5580999ee1d7b7024272. Exactly three tracked paths, with clean git diff --check and git apply --check.

| Candidate path | SHA256 |
| --- | --- |
| papers/D8/paper_draft.tex | 3502e5363b4ec701ee91c4d5902c734f2e6ab7f7541feed35b0e0cf95c51e25d |
| src/core/citations.py | 00167a41b736caf2b2d1c12f8ab923ef887fa352664db21b4901cc33975f5704 |
| docs/primary_sources_state.json | 8669a6f52a47adc07cdf5a3535b0962852788e8d25fd4b0ee72d04c544a2c3ef |

The manuscript uses source-checked passages from 43228e87b and 0124198d2 with further attribution corrections. Ross–Selinger Proposition 8.8 is the expected T-count statement relative to the second-optimal count, Proposition 8.11 is the expected runtime, and C.23 is a lemma. The formal conditional word-length theorem has its own bounded witness. The relative-norm prose distinguishes the integral result, the source dyadic criterion and denominator clearing, the C.20 construction's exact premises, and C.21's explicit positive norm parameter. The KMM exact-synthesis attribution names Theorem 1, Algorithm 1 and Corollary 1. The Mukhopadhyay prose names the resource-theory locators and scopes Conjecture 4.8 to the heuristic. The two obsolete source comments and the stale reader-facing custody paragraph were replaced by source-backed claims and mathematical scope. All 19 current citation keys, labels and figure links remain present. C.20 and C.21 are the only altered formal statement blocks in the manuscript.

The canonical FetchRecord and Sidecar classes wrote the scratch state, with the pre-existing file adoption timestamp and no fetch URL. Parsed comparison found exactly three changed registry records, each limited to pointer and notes. The sidecar likewise changes three records plus generated_at. All three source paths resolve to held files with verified PDF magic, author-version stamp, size and SHA256. All nine historical cache headers identify project-authored summaries. The original Verify command was extracted verbatim and ran with exit 0 from MAIN, where it establishes file custody. Scope script and output are /tmp/publication-d8-primary-propagation-r1-scope.py and /tmp/publication-d8-primary-propagation-r1-scope.log.

Baseline and candidate compiled in scratch via latexmk -pdf -interaction=nonstopmode -halt-on-error. Both produce 13 pages and the same four overfull widths and existing stuck-float warning. No unresolved citations or references in the final candidate log. Candidate PDF /tmp/publication-d8-primary-propagation-r1.Tybjyn/papers/D8/paper_draft.pdf, SHA256 d09806f0b9dd2d3e882cebc8fc1def1ddc5447c4e24a7e9451d69a6d578ae184. Text readback /tmp/publication-d8-primary-propagation-r1.render.txt includes the corrected attributions and scope paragraph. This was an author check of compilation and extracted text. Independent source and rendered review remain the acceptance step.

No real checkout, Lit-Search, network, Lean or ledger mutations. No finding closure.
