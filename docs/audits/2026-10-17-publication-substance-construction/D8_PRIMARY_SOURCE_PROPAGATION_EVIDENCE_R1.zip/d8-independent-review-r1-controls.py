from collections import Counter
from pathlib import Path
import ast, hashlib, json, re
d=Path('/tmp/d8-independent-review-r1.path').read_text().strip()
d=Path(d)
workspace=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research')
entries=['RossSelinger2016','KMM2013','Mukhopadhyay2024']
stamps={'RossSelinger2016':'1403.2975v3','KMM2013':'1206.5236v4','Mukhopadhyay2024':'2401.08950v1'}
def get(rel,baseline=False):
    return (d/(rel+('.baseline' if baseline else ''))).read_text()
def registry(source):
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CITATION_REGISTRY' for t in n.targets))
    return ast.literal_eval(node.value)
orig, cand=(registry(get('src/core/citations.py',i)) for i in (True,False))
assert orig.keys()==cand.keys()
assert [k for k in cand if cand[k]!=orig[k]]==[k for k in cand if k in entries]
a,b=(json.loads(get('docs/primary_sources_state.json',i)) for i in (True,False))
assert a.keys()==b.keys() and a['entries'].keys()==b['entries'].keys()
assert {k for k in b if a[k]!=b[k]}=={'entries','generated_at'}
assert {k for k in b['entries'] if a['entries'][k]!=b['entries'][k]}==set(entries)
out={'registry_and_sidecar':{}}
for k in entries:
    assert set(orig[k])==set(cand[k])
    assert {f for f in orig[k] if orig[k][f]!=cand[k][f]}=={'primary_source_path','notes'}
    s=b['entries'][k]
    assert s['primary_source_path']==cand[k]['primary_source_path']
    f=workspace/s['primary_source_path']
    data=f.read_bytes()
    h=hashlib.sha256(data).hexdigest()
    assert data.startswith(b'%PDF-') and len(data)==s['size_bytes'] and h in s['note']
    assert stamps[k] in (d/(k+'.txt')).read_text()[:9000]
    assert stamps[k] in s['note'] and stamps[k] in cand[k]['notes']
    assert s['tier_achieved']=='arxiv-pdf' and s['verdict']=='success' and s['url_used'] is None
    out['registry_and_sidecar'][k]={'sha256':h,'bytes':len(data),'held_edition':stamps[k]}
old,new=(get('papers/D8/paper_draft.tex',i) for i in (True,False))
cit=lambda s:{k.strip() for ks in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^{}]+)\}',s) for k in ks.split(',')}
assert cit(old)==cit(new) and len(cit(new))==19
for key,pattern in {'labels':r'\\label\{([^{}]+)\}','figure_links':r'\\includegraphics(?:\[[^\]]*\])?\{([^{}]+)\}'}.items():
    assert Counter(re.findall(pattern,old))==Counter(re.findall(pattern,new))
    out[key]=len(re.findall(pattern,new))
blocks=lambda s:{re.search(r'\\label\{([^{}]+)\}',block).group(1):block for block in re.findall(r'\\begin\{(?:lemma|theorem|hypothesis)\}.*?\\end\{(?:lemma|theorem|hypothesis)\}',s,re.S) if re.search(r'\\label\{([^{}]+)\}',block)}
bo,bn=blocks(old),blocks(new)
assert bo.keys()==bn.keys()
out['changed_formal_blocks']=[k for k in bn if bn[k]!=bo[k]]
assert set(out['changed_formal_blocks'])=={'lem:c20','lem:c21'}
assert not re.search(r'^% TODO:.*(?:RossSelinger|Mukhopadhyay|KMM2013)',new,re.M)
cachekeys=['AaronsonGottesman2004','BMPRV1999','Brylinski2002','Hietala2020VOQC','KMM2013','Lewis2021VerifQC','Mukhopadhyay2024','ReadRezayi1999','RossSelinger2016']
for k in cachekeys:
    f=workspace/'Lit-Search/Phase-1-and-Background/primary-sources'/(k+'.abstract.txt')
    assert 'Project-authored summary (no primary-source quotation)' in '\n'.join(f.read_text().splitlines()[:11])
out['summary_headers']=cachekeys
out['citation_keys']=len(cit(new))
print(json.dumps(out,indent=2))
