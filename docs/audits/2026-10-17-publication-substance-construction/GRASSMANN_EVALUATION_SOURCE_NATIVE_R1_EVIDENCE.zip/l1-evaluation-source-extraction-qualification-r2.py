from pathlib import Path
import sys,json,subprocess
sys.path.insert(0,'scripts')
import extract_lean_deps as e
baseline='57f6c2a9340cb1947919f607e59b3d740ca4fb16'
before=json.loads(subprocess.check_output(['git','show',baseline+':lean/lean_deps.json'],text=True))
old={x['name']:x for x in before};assert len(old)==len(before)==41294
assert not e._needs_refresh(), "R1 extraction must already be fresh; refuse repetition"
after=json.loads(Path("lean/lean_deps.json").read_text())
new={x['name']:x for x in after};assert len(new)==len(after)
assert all(new.get(k)==v for k,v in old.items())
mods={'SKEFTHawking.ADW.FiniteGrassmannEvaluation','SKEFTHawking.ADW.FiniteGrassmannSourceAuxiliary'}
added=[new[n] for n in sorted(set(new)-set(old))]
assert len(added)==189
exception=[x for x in added if x['module'] not in mods]
assert len(exception)==1
x=exception[0]
assert x['name']=='PowerSeries.evalNegHom.eq_1' and x['autogen'] is True
assert x['module']=='SKEFTHawking.ADW.GaussianAuxiliaryCompensation'
assert x['type']=='∀ {A : Type u_2} [inst : CommRing A], Eq PowerSeries.evalNegHom (PowerSeries.rescale (-1))'
assert not x['axiom_deps_project'] and x['kind']=='theorem'
assert x['name_deps_project']==x['type_deps_project']==x['value_deps_project']==[]
assert not x['name_deps_timed_out']
assert all(x['module'] in mods for x in added if x not in exception)
allowed={'propext','Classical.choice','Quot.sound'}
assert all(set(x['axiom_deps_core'])<=allowed and not x['axiom_deps_project'] for x in added)
c1=json.load(open('/tmp/publication-eq7-c1-independent-review-r2.json'))
c3=json.load(open('/tmp/publication-eq7-c3-source-independent-review-r1.json'))
names=[x['name'] for x in c1['validation']['kernel_batch']['kernel']]+['SKEFTHawking.ADW.FiniteGrassmannSourceAuxiliary.'+n for n in c3['names']]
assert len(names)==162 and len(set(names))==162
assert all(n in new and set(new[n]['axiom_deps_core'])<=allowed and not new[n]['axiom_deps_project'] for n in names)
assert Path('lean/lean_deps.json.hash').read_text().strip()==e.compute_lean_hash()
result={'candidate':baseline,'prior_records':len(old),'current_records':len(new),'all_prior_records_exact':True,'added_records':added,'reviewed_public_export_names':names,'source_hash':e.compute_lean_hash(),'scope':'R1 completed extraction before ROOT module-only-addition assertion failed; R2 validates exact one autogen PowerSeries.evalNegHom.eq_1 in unchanged prior module, all41294 old records exact and all162 exports. No extraction repeated, no checker/source change.'}
Path('/tmp/l1-evaluation-source-extraction-differential-r2.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'added_records','reviewed_public_export_names'}}))
