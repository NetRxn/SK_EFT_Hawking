from pathlib import Path
import os,sys,subprocess,json,datetime
primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');candidate=Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking');sys.path.insert(0,str(primary/'scripts'));from lean_slots.state import Inventory,directory_lock
assert Path.cwd()==primary;head=subprocess.check_output(['git','-C',str(candidate),'rev-parse','HEAD'],text=True).strip();assert head=='57f6c2a9340cb1947919f607e59b3d740ca4fb16';assert set(subprocess.check_output(['git','-C',str(candidate),'diff','--name-only'],text=True).splitlines())=={'lean/lean_deps.json','lean/lean_deps.json.hash'}
prior=json.loads(Path('/tmp/l1-evaluation-source-main-native-r1.result.json').read_text());assert prior['returncode']==0 and prior['candidate']==head
inv=Inventory.load();prefix=Path('/tmp/l1-evaluation-source-main-refresh-r2');assert not prefix.with_suffix('.invocation.json').exists();env=dict(os.environ,UV_PROJECT_ENVIRONMENT=str(primary/'.venv'),UV_NO_SYNC='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1')

commands=[('extraction-qualification',[str(primary/'.venv/bin/python'),'-B','/tmp/l1-evaluation-source-extraction-qualification-r2.py']),('counts',[str(primary/'.venv/bin/python'),'scripts/update_counts.py']),('tables',[str(primary/'.venv/bin/python'),'scripts/render_paper_tables.py']),('fast-sync',[str(primary/'.venv/bin/python'),'scripts/sync.py','--fast']),('freshness',[str(primary/'.venv/bin/python'),'scripts/validate.py','--check','counts_fresh','--check','theorem_census_agrees','--check','tables_fresh','--check','claim_clusters_fresh','--no-memo'])]
receipt={'candidate':head,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Existing canonical extraction/writers/freshness after actual combined MAIN native build; all old41294records exact; no checker or runtime change','steps':[]}
with directory_lock(inv.state_root/'locks/authoritative-build.lock',purpose='ROOT accepted C1 and C3-S canonical refresh'):
 prefix.with_suffix('.invocation.json').write_text(json.dumps(receipt,indent=2)+'\n');print('STARTED '+head,flush=True)
 for name,argv in commands:
  with Path(str(prefix)+'.'+name+'.stdout').open('w') as out,Path(str(prefix)+'.'+name+'.stderr').open('w') as err:r=subprocess.run(argv,cwd=candidate,env=env,stdout=out,stderr=err)
  receipt['steps'].append({'name':name,'argv':argv,'returncode':r.returncode});prefix.with_suffix('.progress.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name+' returncode='+str(r.returncode),flush=True)
  if r.returncode:break
 receipt.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head_after=subprocess.check_output(['git','-C',str(candidate),'rev-parse','HEAD'],text=True).strip(),status_after=subprocess.check_output(['git','-C',str(candidate),'status','--porcelain'],text=True));prefix.with_suffix('.result.json').write_text(json.dumps(receipt,indent=2)+'\n')
sys.exit(receipt['steps'][-1]['returncode'])
