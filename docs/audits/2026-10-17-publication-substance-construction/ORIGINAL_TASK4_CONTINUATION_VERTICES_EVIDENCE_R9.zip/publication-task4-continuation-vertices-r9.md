# Original N16 fixed-center continuation vertices R9

The represented polynomial is the original closed-word source-C N16 seam
with one S2 vertex at x, one S2 vertex at y=x+e0, one complete S2 or S4
vertex at w=x+e2 and one raw contact at y. The order used for streaming is
x then w then contact then y. Every coframe has even exterior degree,
so commuting these source factors preserves the exterior sign. The single
contact supplies the only raw slot and original anchored J label.

At w the canonical action constructor supplies 384 raw ordered S2 terms.
Sorting the two even coframe factors partitions these into 96 groups of
four. In 24 diagonal groups the curvature pieces cancel pairwise. The 72
live groups keep all 128 anchored curvature coefficient records, their
two actual coframes and one g2 factor. The 24 S4 terms retain each actual
four-coframe epsilon product, its sign and one g1 factor. No linear
combination of isolated R8 components substitutes for an action vertex.

For a requested exterior mask and complete commuting symbol multiset,
the stream projects all operands separately and traverses only feasible
prefixes by disjoint exterior masks and exact multiset subtraction. The
existing exact later-coframe inverse supplies all y branches and signed
paths. The forward control uses Counter inclusion and canonical exterior
polynomial multiplication. At w it uses each original raw orientation
and original companion order, sums within exact branch identity, then
multiplies the admitted products. The direct and streamed constructions
agree on every reported signed group value. The retained raw input
rosters and bounded scratch projections are distinct from full output
support, which is never materialized.

The original source grades are disjoint. The w-S2 seam uses exterior
degree 14, 19 quaternion factors, g2³ and one J. The w-S4 seam uses
exterior degree 18, 17 quaternion factors, g2²g1 and one J. Both raw
grades have odd total quaternion degree. If every remaining factor is
omitted, simultaneous central sign reversal on all links kills the
complete Haar average of either isolated grade. This statement does not
allow removal of a raw term before all original incident factors arrive.
The full action expansion can include further coframes and mixed products.

The 52 R8 controls restore the actual isolated continuation vector only
as a restriction control. They compare all signed group subtotals and
path counts to the previously accepted record. Actual R9 targets are
selected from disjoint-mask paths through the complete w vertices. Source
labels and quaternion anchors are retained through both contact slots.

The next original task is to combine the remaining fixed-w alternatives,
then extend the frontier to the other centers and prove last use of
exterior and Haar labels before any projection. No full partition,
normalization, connected response, original analytic or executable
correspondence, or publication acceptance is claimed.

## Exact terminal receipt

The bounded Python invocation exited 0 on the exact adjacent source file.
All 52 R8 signed group tables and path counts were reproduced. The
forward oracle matched 30 R9 targets and 1,280 later-group subtotals.
The targets cover six S2 curvature planes and all 24 S4 permutations in
their actual signed path rosters, with literal and both mixed contact
directions for both source grades. Each target was seeded by an explicitly
nonzero grouped contribution. Twenty-six complete coefficients nevertheless
vanish after summing, so retaining the actual branch and signed addition
is material to the result. Two literal-to-mixed checks agree exactly.
Wrong anchored J and wrong coupling each give zero in both source grades.
The explicit zero-work probe refuses before the first operand projection.

The work ledger charges 4,709,152 operations, with a cap of 30,000,000.
The scoped forward oracle observed at most 166 prospective product
records against a 16,384-record cap. The largest actual projected query
has 98 coefficient records and the largest actual signed output has 192
group records. The later arena holds 10,240 records in 88 maps, and the
deterministic seed view holds 30,872 rows. The full raw source and
projected factor objects remain outside the later arena. Process peak
RSS was 133,283,840 bytes. These are observed scratch scopes and
logical accounting, not a bound for an all-center full-support run.
The in-loop guard checks the number of retained branch entries plus
the size of the next group. The total number of group records is
checked after each query and independently in the audit. No universal peak bound is inferred
from that guard.

Replay on the primary checkout with `PYTHONPATH=. .venv/bin/python -B
/tmp/publication-task4-continuation-vertices-r9.py`. The source imports
the frozen R8, R7, R6, R5 and R4 scripts. It reads the frozen R8 JSON for
the exact predecessor comparisons. Run the adjacent `.audit.py` to
verify the terminal JSON grades, row counts, and charged scopes.
An instrumented optimization was prepared during the longer first
replay and is not the executed artifact. Review should use the exact
adjacent source matching the completed receipt.

The first and final author continuity receipts agree. No tracked
repository, Lean slot, or original full campaign was modified.
Independent verification and ROOT acceptance remain pending.
