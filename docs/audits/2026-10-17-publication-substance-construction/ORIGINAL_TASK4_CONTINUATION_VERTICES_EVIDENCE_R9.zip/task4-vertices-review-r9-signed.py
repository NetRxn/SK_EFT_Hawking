from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial
import importlib.util
import json
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

def load(label, path):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module

r4 = load("r4review", "/tmp/publication-task4-later-full-vertex-r4.py")
Q, P, S = o.QComplex, o.Polynomial, o.Symbol
reg = o.OriginalRegulator()
x, y = reg.sites[0], reg.step(reg.sites[0], 0)[0]
x2 = reg.step(x, 2)[0]
q = S("g2", ())
j = S("J", (y, 0, 0))
assert (reg.volume, reg.word, reg.convention) == (16, "closed", "source_C")

def tensor(alpha, *, slot=(), labels=()):
    # Rebuild the four signed bilinears directly from the block definition
    # and the globally ordered bar/psi basis. No author arena or ExteriorPolynomial.
    positions = {token: i for i, token in enumerate(reg.generator_order)}
    out = defaultdict(Q)
    blocks = f.original_coframe_blocks(reg, alpha)
    for b in blocks:
        for i, k in product(range(4), repeat=2):
            a, z = positions[b.bar_site, "bar", i], positions[b.psi_site, "psi", k]
            for key, value in b.matrix[i][k].terms:
                out[(1 << a | 1 << z, tuple(sorted((*labels, *key))), slot)] += value * b.weight * (-1 if a > z else 1)
    return {k: v for k, v in out.items() if v}

def trace_rows(site, k, l, mu, nu, a, b):
    # Direct closed matrix word D† C† B A, with original quaternion labels.
    anchors = (site,k), (reg.step(site,k)[0],l), (reg.step(site,l)[0],k), (site,l)
    links = [f.original_spin4_link(*(tuple(P.variable(S("q",(*z,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for z in anchors]
    A,B,C,D = links
    U = o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(D),o.matrix_dagger(C)),o.matrix_multiply(B,A))
    gamma = o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    poly = sum((U[i][k]*gamma[k][i] for i,k in product(range(4),repeat=2)),P()) * o.epsilon((k,l,mu,nu))
    return {(0,key,()): value for key,value in poly.terms}

def indices(mask):
    return [i for i in range(mask.bit_length()) if mask >> i & 1]

def multiply(left, right):
    out = defaultdict(Q)
    for (lm,lk,lj), lv in left.items():
        for (rm,rk,rj), rv in right.items():
            if lm & rm or len(lj) + len(rj) > 2:
                continue
            z = tuple(sorted(lj + rj))
            multiplicity = 1
            for i in set(z):
                multiplicity *= factorial(z.count(i)) // (factorial(lj.count(i)) * factorial(rj.count(i)))
            parity = sum(i > k for i,k in product(indices(lm),indices(rm))) % 2
            out[lm|rm,tuple(sorted(lk+rk)),z] += lv * rv * (-multiplicity if parity else multiplicity)
    return {k:v for k,v in out.items() if v}

def summed(*maps):
    out = defaultdict(Q)
    for d in maps:
        for k,v in d.items(): out[k] += v
    return {k:v for k,v in out.items() if v}

def slot_relabel(d, slot):
    return {(m,k,slot):v for (m,k,_),v in d.items()}

def snapshot(arena, handle):
    out = {}
    arena.scan(handle, lambda k,v:out.__setitem__(k,v))
    return out

from collections import Counter
from functools import lru_cache
from itertools import combinations

r7=load("r7review","/tmp/publication-task4-predecessor-roster-r7.py")
r4,r5=r7.r4,r7.r5
w=r5.Work(cap=20_000_000)
arena=r4.Arena(r4.Caps(100_000,65_536))

@lru_cache(maxsize=None)
def ordered_closed_word(site,k,l):
    sx=reg.step(site,k)[0]
    sy=reg.step(site,l)[0]
    anchors=((site,k),(sx,l),(sy,k),(site,l))
    ls=[f.original_spin4_link(*(tuple(P.variable(S("q",(*anchor,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for anchor in anchors]
    a,b,c,d=ls
    return o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(d),o.matrix_dagger(c)),o.matrix_multiply(b,a))

def direct_trace(site,k,l,mu,nu,a,b):
    mat=ordered_closed_word(site,k,l)
    gamma=o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    p=sum((mat[i][j]*gamma[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))
    return {(0,tuple(sorted((*k,q))),()):coef for k,coef in p.terms}

def raw_exact(e):
    return {(m,key,()):coef for m,poly in e.terms for key,coef in poly.terms}

C={}
H={}
source={}
diagonals={}
for site in (x,y):
    ac,ah,ad=r7.roster(reg,site,w)
    C[site]={(mu,a):tensor((site,mu,a)) for mu,a in product(range(4),repeat=2)}
    assert all(len(rows)==64 and rows==raw_exact(ac[key]) for key,rows in C[site].items())
    traces={}
    cancels=[]
    for mu,nu in combinations(range(4),2):
        k,l=[i for i in range(4) if i not in (mu,nu)]
        for a,b in product(range(4),repeat=2):
            tag=k,l,mu,nu,a,b
            main=direct_trace(site,k,l,mu,nu,a,b)
            flip_coframes=direct_trace(site,k,l,nu,mu,b,a)
            flip_curve=direct_trace(site,l,k,mu,nu,a,b)
            flip_both=direct_trace(site,l,k,nu,mu,b,a)
            if a==b:
                assert main and flip_coframes and flip_curve and flip_both
                assert not summed(main,flip_coframes) and not summed(flip_curve,flip_both)
                cancels.append(tag)
            else:
                assert len(main)==128 and main==flip_coframes==flip_curve==flip_both
                assert main==raw_exact(ah[tag])
                traces[tag]=main
    assert len(cancels)==24 and sorted(cancels)==ad
    assert len(traces)==72 and set(traces)==set(ah)
    H[site]=traces
    diagonals[site]=sorted(cancels)
    source[site]=ac,ah
from itertools import permutations

r8=load("r8review","/tmp/publication-task4-continuation-roster-r8.py")
r9=load("r9review","/tmp/publication-task4-continuation-vertices-r9.py")
work=r5.Work(cap=30_000_000)
cw,raw,choices,wdiag=r9.source_roster(reg,x2,work)
F={key:tensor((x2,*key)) for key in product(range(4),repeat=2)}
assert all(len(rows)==64 and rows==raw_exact(cw[key]) for key,rows in F.items())
G1=S("g1",())
w_branches={}
ind_diag=[]
for mu,nu in combinations(range(4),2):
    k,l=[i for i in range(4) if i not in (mu,nu)]
    for a,b in product(range(4),repeat=2):
        tag=(2,k,l,mu,nu,a,b)
        main=direct_trace(x2,k,l,mu,nu,a,b)
        flip_coframes=direct_trace(x2,k,l,nu,mu,b,a)
        flip_curve=direct_trace(x2,l,k,mu,nu,a,b)
        flip_both=direct_trace(x2,l,k,nu,mu,b,a)
        # Each raw orientation has the original factor 1/4. Compare
        # the multiset before alignment, preserving signs and zeros.
        # Coupling symbol sorts before q symbols. Remove only that label.
        quarters=[P(tuple((tuple(s for s in sy if s!=q),v*Fraction(1,4))
                          for (_,sy,_),v in d.items()))
                  for d in (main,flip_coframes,flip_curve,flip_both)]
        assert Counter(quarters)==Counter(term.coefficient for term in raw[tag])
        if a==b:
            assert main and not summed(main,flip_coframes) and not summed(flip_curve,flip_both)
            ind_diag.append(tag[1:])
        else:
            assert main==flip_coframes==flip_curve==flip_both and len(main)==128
            w_branches[tag]=(((mu,a),(nu,b)),main)
for a in permutations(range(4)):
    tag=(4,*a)
    # Permutation parity is derived directly, independent of source epsilon.
    epsilon=(-1)**sum(u>v for i,u in enumerate(a) for v in a[i+1:])
    assert len(raw[tag])==1 and raw[tag][0].coefficient==P.scalar(epsilon)
    assert raw[tag][0].components==tuple((x2,i,v) for i,v in enumerate(a))
    w_branches[tag]=(tuple(enumerate(a)),{(0,(G1,),()):Q(epsilon)})
assert sorted(ind_diag)==wdiag
assert len(w_branches)==96 and set(w_branches)==set(choices)
assert all(cs==choices[tag][0] and d==raw_exact(choices[tag][1]) for tag,(cs,d) in w_branches.items())
assert len(raw)==120 and sum(map(len,raw.values()))==408
assert Counter(k[0] for k in w_branches)=={2:72,4:24}

D0=tensor((y,0,0),labels=(j,))
D1=tensor((y,1,0),labels=(j,))
D={(0,):D0,(0,1):summed(D0,D1)}
assert tuple(map(len,D.values()))==(64,128)
jp=P.variable(j)
DC={(0,):source[y][0][0,0]*jp,(0,1):(source[y][0][0,0]+source[y][0][1,0])*jp}
assert all(D[slot]==raw_exact(e) for slot,e in DC.items())
yh={tag:arena.ingest(r4.rows(e)) for tag,e in source[y][1].items()}
yc={tag:arena.ingest(r4.rows(e)) for tag,e in source[y][0].items()}
assert arena.metric()["live_records"]==10240 and arena.metric()["live_maps"]==88

def decode(d):
    def freeze(x):
        return tuple(map(freeze,x)) if isinstance(x,list) else x
    return int(d["mask_hex"],16),tuple(S(n,freeze(v)) for n,v in d["symbols"]),tuple(d["slot"])

@lru_cache(maxsize=50000)
def inv_sign(L,R):
    return (-1)**sum(i>k for i,k in product(indices(L),indices(R)))

# For each query, direct forward evaluation retains only factors dividing
# the complete target; independent exact Counter arithmetic and no inverse.
def forward(key, selected):
    mask,sy,slot=key
    powers=Counter(sy)
    charged=0
    def proj(d):
        rows=[]
        for k,v in d.items():
            m,terms,_=k
            if m&mask!=m: continue
            p=Counter(terms)
            if not p-powers:
                rows.append((m,p,v,k in D1 if d is D[(0,1)] else False))
        return rows
    cx={tag:proj(d) for tag,d in C[x].items()}
    cy={tag:proj(d) for tag,d in C[y].items()}
    hx={tag:proj(d) for tag,d in H[x].items()}
    hy={tag:proj(d) for tag,d in H[y].items()}
    cf={tag:proj(d) for tag,d in F.items()}
    all_factors={tag:proj(d) for tag,(_,d) in selected.items() if d is not None}
    dd=proj(D[slot])
    projected=sum(map(len,(*cx.values(),*hx.values(),*cf.values(),*all_factors.values(),dd)))

    def terms(operands):
        nonlocal charged
        for rows in product(*operands):
            charged+=1
            assert charged<=100_000, "independent query enumeration exceeded bound"
            occupied=0
            powers_used=Counter()
            value=Q(1)
            direction=False
            for m,pp,v,d in rows:
                if occupied&m or (powers_used+pp)-powers:
                    break
                value*=v*inv_sign(occupied,m)
                occupied|=m
                powers_used+=pp
                direction|=d
            else:
                yield occupied,powers_used,value,direction
    late={}
    for tag,trace in hy.items():
        _,_,mu,nu,a,b=tag
        got=list(terms((cy[mu,a],cy[nu,b],trace)))
        if got: late[tag]=got
    wpre={}
    for tag,(cs,d) in selected.items():
        operands=tuple(cf[c] for c in cs)
        if d is not None: operands=(*operands,all_factors[tag])
        got=list(terms(operands))
        if got: wpre[tag]=got
    result={}
    dirs=Counter()
    witness_dirs=defaultdict(Counter)
    for tag,trace in hx.items():
        _,_,mu,nu,a,b=tag
        xpre=list(terms((cx[mu,a],cx[nu,b],trace,dd)))
        if not xpre: continue
        for wk,wrows in wpre.items():
            table={}
            n=0
            for (m,p,v,d),(m0,p0,v0,_) in product(xpre,wrows):
                charged+=1
                assert charged<=100_000, "independent query enumeration exceeded bound"
                if m&m0 or (p+p0)-powers: continue
                union=m|m0
                partial=p+p0
                weight=v*v0*inv_sign(m,m0)
                for yk,yrows in late.items():
                    for m1,p1,v1,_ in yrows:
                        charged+=1
                        assert charged<=100_000, "independent query enumeration exceeded bound"
                        if union&m1 or union|m1!=mask or partial+p1!=powers: continue
                        value=weight*v1*inv_sign(union,m1)
                        assert value
                        table[yk]=table.get(yk,Q(0))+value
                        n+=1
                        dirs[int(d)]+=1
                        witness_dirs[tag,wk,yk][int(d)]+=1
            if n: result[tag,wk]=(table,n)
    return result,projected,dirs,witness_dirs,charged

def fmt(g):
    return [[list(k),str(v)] for k,v in sorted(g.items())]
def totals(result):
    later=defaultdict(Q)
    by_w=defaultdict(Q)
    for (_,wk),(g,n) in result.items():
        for yk,v in g.items():
            later[yk]+=v
            by_w[wk]+=v
    return fmt(later),fmt(by_w),str(sum(later.values(),Q(0)))

author=json.load(open("/tmp/publication-task4-continuation-vertices-r9.json"))
prior=json.load(open("/tmp/publication-task4-continuation-roster-r8.json"))
old_choices={c:((c,),None) for c in F}
assert len(prior["results"])==52
old_cases=[]
for row in prior["results"]:
    target=decode(row["target"])
    got,_,dirs,_,charged=forward(target,old_choices)
    by_comp=defaultdict(list)
    for (xkey,comp),(g,n) in sorted(got.items()):
        by_comp[comp].append([list(xkey),n,fmt(g)])
    assert [[list(comp),rows] for comp,rows in sorted(by_comp.items())]==row["paths"]
    old_cases.append(charged)

results=[]
totals_for_controls={}
scope={}
for degree in (2,4):
    scope[degree]={tag:row for tag,row in w_branches.items() if tag[0]==degree}
for row in author["targets"]:
    key=decode(row["target"])
    degree=row["degree"]
    got,projected,dirs,witness_dirs,charged=forward(key,scope[degree])
    groups=[[[list(xk),list(wk)],fmt(g),n] for (xk,wk),(g,n) in sorted(got.items())]
    assert groups==row["groups"] and projected==row["projected"]
    later,continuation,total=totals(got)
    assert (later,continuation,total)==(row["later"],row["continuation"],row["total"])
    bx,bw,by=map(tuple,row["seeded"])
    assert got[bx,bw][0][by] and witness_dirs[bx,bw,by][row["contact_direction"]]
    assert key[0].bit_count()==(14 if degree==2 else 18)
    symbol_grade=Counter(s.family for s in key[1])
    assert symbol_grade==({"q":19,"g2":3,"J":1} if degree==2 else {"q":17,"g2":2,"g1":1,"J":1})
    totals_for_controls[key]=(groups,total)
    results.append({"degree":degree,"slot":key[2],"groups":sum(len(g) for g,_ in got.values()),
                    "target_zero":total==str(Q(0)),"directions":dict(dirs),
                    "continuation_branches":sorted({wk for _,wk in got}),
                    "projected":projected,"independent_work":charged})
assert len(results)==30
assert sum(r["groups"] for r in results)==1280 and sum(r["target_zero"] for r in results)==26
assert max(r["projected"] for r in results)==98 and max(r["groups"] for r in results)==192
assert len({wk[:3] for r in results if r["degree"]==2 for wk in r["continuation_branches"]})==6
assert len({wk for r in results if r["degree"]==4 for wk in r["continuation_branches"]})==24
checks=[]
for ctrl in author["controls"]:
    if ctrl[0]=="zero_work_refusal": continue
    label,degree,encoded,total=ctrl
    key=decode(encoded)
    got,projected,dirs,_,charged=forward(key,scope[degree])
    if label=="exact_literal_summand_of_mixed":
        groups=[[[list(xk),list(wk)],fmt(g),n] for (xk,wk),(g,n) in sorted(got.items())]
        base=key[0],key[1],(0,)
        assert (groups,totals(got)[2])==totals_for_controls[base]
        assert totals(got)[2]==total and dirs and set(dirs)=={0}
    else:
        assert not got and not dirs
    checks.append({"control":label,"degree":degree,"directions":dict(dirs),"groups":len(got)})
tiny=r5.Work(cap=0)
try:
    r9.signed(decode(author["targets"][0]["target"]),2,*source[x],cw,choices,DC,arena,yc,yh,tiny)
except RuntimeError as exc:
    assert "work cap at 0" in str(exc) and tiny.used==0 and not tiny.counts
else:
    raise AssertionError("zero-work query did not refuse")
print(json.dumps({"roster":{"S2":72,"S2_diagonal":24,"S4":24},
 "R8_controls":len(old_cases),"max_R8_independent_work":max(old_cases),
 "targets":results,"controls":checks,"zero_work_refusal":True},indent=2))
