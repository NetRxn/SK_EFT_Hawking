"""Check exact output scope, degrees, support and recorded resource totals."""
from collections import Counter, defaultdict
from pathlib import Path
import json

prefix = Path(__file__).with_name("publication-task4-continuation-vertices-r9")
data = json.loads(prefix.with_suffix(".json").read_text())
assert data["r8_controls"] == 52
assert data["raw_counts"] == {"S2":384,"S4":24}
assert data["group_counts"] == {"S2":72,"S4":24}
assert all(len(x)==24 for x in data["diagonal"])
assert sum(data["work"].values()) == data["work_total"] <= data["work_cap"]
assert data["oracle_pair_peak"]<=data["oracle_record_cap"]
hist=Counter()
groups=0
max_records=0
max_projected=0
branches=defaultdict(set)
for target in data["targets"]:
    t=target["target"]
    degree=target["degree"]
    # The canonical key format contains an exact integer mask and ordered raw symbols.
    expected=Counter({"q":19,"g2":3,"J":1} if degree==2 else {"q":17,"g2":2,"g1":1,"J":1})
    assert int(t["mask_hex"],16).bit_count()==2*(5+degree)
    assert Counter(s[0] for s in t["symbols"])==expected, t
    slot=tuple(t["slot"])
    hist[(degree,slot,target["contact_direction"])]+=1
    records=sum(len(g) for _,g,_ in target["groups"])
    groups+=records
    max_records=max(max_records,records)
    max_projected=max(max_projected,target["projected"])
    assert records<=data["output_cap"]
    assert target["projected"]<=data["projection_cap"]
    for _,wk in (key for key,_,_ in target["groups"]):
        branches[degree].add(tuple(wk))
print(json.dumps({
    "cases":[(degree,slot,direction,n) for (degree,slot,direction),n in sorted(hist.items())],
    "target_count":sum(hist.values()),
    "later_subtotals":groups,
    "max_subtotals_per_key":max_records,
    "max_projected_records_per_key":max_projected,
    "actual_continuation_branch_support":[(k,sorted(v)) for k,v in sorted(branches.items())],
    "full_zero_targets":sum(row["total"]=="QComplex(storage=(0, 1, 0, 1))" for row in data["targets"]),
    "oracle_pair_peak":data["oracle_pair_peak"],
    "work_total":data["work_total"],
    "native_peak_rss":data["native_peak_rss"],
},indent=2))
