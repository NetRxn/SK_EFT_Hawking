# Exact PR117 W1b gate delta

Run canonical build_graph.extract_readiness_gate_nodes in clean detached scratch checkouts with the same local Lit-Search access and Python environment. All 231 bundle states are unchanged. Portfolio is 160 passed, 25 blocked, 28 open, 18 needs recheck. All 704 paper-level states are unchanged. Only evaluation times and the L1 LeanProofSubstance evidence string differ. The latter counts 4 to 7 direct theorem citations, with zero placeholder overlap. L1 G3 and G11 remain blocked.
