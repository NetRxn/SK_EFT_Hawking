# Original coefficient Task2 implementation handoff R1

SOURCE_IMPLEMENTED_BOUNDED_TESTS_PASS_FULL_SCIENTIFIC_EXECUTION_PENDING

Task2 is not complete: the COMPLETE original one-site scientific control is implemented but has NOT executed. ROOT must reconcile different complete source/science and algebra/cost reviews before actual runtime admission. No numeric coefficient or Task3/Task4/physical/publication acceptance is claimed.

## Implemented requirement coverage

- **original_geometry_and_task1_conservation:** Entire accepted prefixes byte-identical; no original Task1 definition/test change; C/M and both original action-word builders reused.
- **raw_C2_family_grading:** RawJet/GradedTerm/SourceFamilyGrading/SourceJet, exact repeated mixed factors, homogeneous degree and explicit coefficient/support/contact metadata; no generic odd-H or derivative-order filter.
- **singular_safe_minor:** Row/subset DP determinant with all first/second/acceleration jets, sorted complementary insertion minors and overlap exterior signs; no inverse/det division.
- **moments_W:** Canonical exact positive-variance Gaussian, scaled Hermite and quaternion S3 moments; independent expanded-Hermite Gaussian kernel; generic globally bounded W (default64) and full factored original one-site W4.
- **insertion_frame_current_measure:** Generic complete original pre-Haar frame and local-phase pullback; literal T versus metric H versus current source couplings; insertion/action/measure raw products, current/metric mixed contacts and explicit accelerations; frozen Haar derivatives zero unless supplied.
- **denominator_and_refusals:** Unknown original denominator retained by generic contraction, explicit exact nonzero certificate, quotient and log response jets, exact restricted-Hessian Legendre refusal, resource/height incomplete exceptions.
- **complete_original_one_site_source:** All16 original coframes/eight Grassmann generators/four independent Spin4 links. Direct136 exterior pairs, all3876 quartics with740 center-compatible and3136 certified center zeros; separate two actual2x2 chiral determinant pair tables; both full original action builders and route-specific curvature mean/covariance recomputation.
- **full_W_query_and_contact_scope:** 4029 original raw P4/Hermite factor terms and23504 Gaussian-compatible coefficient queries per actual word/variance. Full interacting denominator, allJ4/g1/g2J2/g2² families retained before center/curvature support; v2/v3; six-slot specified frame jets including W derivatives and shifted-J frame factors. All16/136 T and10/55 H derivative polynomials, source origin/nonzero-axis evaluations,26 normalized T/H frame insertion/denominator jets; one-site inversion/g2/J dictionary.
- **full_expected_regression:** Unexecuted full scientific test independently builds complete accepted96g2²+free quartic expected polynomial only as test oracle; no expected scientific constants produce source coefficients.
- **full_scientific_execution:** NOT RUN: requires ROOT actual runtime admission, independent complete source/cost reviews and subsequent scientific-result review. No Task2 completion or coefficient result accepted by this source handoff.
- **physical_and_successors:** No physical P0/C3/N0 certificate consumed; Euclidean metric_M remains M_N. Task3 complete N16/all24minors/F60-G52 contacts, Task4 fullZ/frontier/allocation/nonzero certificate, formal and physical/B3/publication obligations remain owed.

## Actual bounded verification

`PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 .venv/bin/python -m pytest tests/test_original_coefficient_jets.py -k 'not full_small_carrier' -v -s -p no:cacheprovider`

Exit0:15 passed,1 full scientific test deselected. Maximum 156928 counted products/fixture; total reported 165224; process peak RSS 217137152 bytes (<512MiB). AST parsing and scoped whitespace checks pass. Final actual log `/tmp/task2-final-tests.log`.

All accepted Task1 source bytes are conserved as entire prefixes; protected Task1 tests unchanged. Protected Task1 and dependency tests were subsequently rerun under explicit ROOT bounded admission in the combined67-test regression below. Source hashes and prefix byte counts follow.

- `src/core/formulas.py`: SHA256 `f893d165e8f0eaf8aa5ced348d2993f0219d7bd3370daa5fcfb49dddd20abd6d`,535669bytes; entire prior509040-byte prefix conserved.
- `src/vestigial/original_coefficients.py`: SHA256 `b3c2c59fcb6bc00b6f7b125be387855467d7eb208466467f3c6be3dbbf94c8b5`,59702bytes; entire prior27548-byte prefix conserved.
- `tests/test_original_coefficient_jets.py`: SHA256 `8a453b19613a6190937f0963ba9bf13b07d9aab985e392baf741edeb3b4aaf37`,14190bytes; entire prior0-byte prefix conserved.

## Arithmetic, storage and execution boundary

QComplex four normalized integers, immutable packed/repeated symbol keys; every six-slot jet is six coefficient records. Factored raw W retains shared coefficient keys and never expands giant quartic quaternion maps.

Direct136 pair maps discarded after scalar tensor output; independent two2x2 determinant pair tables then replace them; word/variance phases processed sequentially. Both original curvature routes recompute actual means/covariances.

Direct tensor reserves400000*1536 bytes before pair construction; determinant reserves55000*1536. ExactBudget adds128MiB fixed reserve, doubles recursively measured unique object payload for container/resize headroom and checks live graphs;1024-bit components are checked in supplied graphs.

Object-graph/model preallocation is not universal process RSS or a24-hour watchdog. Arbitrary untrusted Generic Polynomial operations outside these APIs are not fully instrumented or universally bounded. Full native scientific RSS/time remains UNKNOWN until admitted run.

The accepted prospective175370240 candidate core products plus<20M bookkeeping allowance is preserved as a SOURCE model; actual complete scientific count/height/timing/RSS is UNKNOWN. No coefficient-ring product or six-slot jet is priced as one scalar record. The generic exact budget raises incomplete exceptions; no partial map is returned as a completed zero. Whole-array accounting is performed before/after bounded stages, with an explicit128MiB reserve; this is not a process-wide allocator guard.

## RED/GREEN and limitations

- Initial uv pytest attempt exited2 before tests: sandbox denied uv cache initialization. Existing primary .venv interpreter then ran the intended RED tests. No dependency/cache repair was attempted.
- Initial native RED:6 failures for intentionally absent APIs,1 full-control deselection.
- First GREEN attempt exposed erroneous manual expected mixed product382 (correct413), erroneous manual quotient mixed1/4 (correct17/16), and inherited-dataclass positional storage-limit initialization defect; all corrected, green.
- Additional RED tests exposed missing logZ refusal, coupling-roster extraction ignored when source roster empty, mutable RawJet values and mutable factored-weight/request metadata; corrected and green.
- Actual pre-Haar action fixture initially used identity in the complementary curvature pair, making its commutator zero. Replaced only that test quaternion by an exact noncommuting unit quaternion; the actual current/action/contact test is nonvacuous and green.
- Combined long documentary displays sometimes truncated; substantive accepted source/coefficient/contact and review portions were re-read in bounded reads. No source absence inference was taken from truncated output or failed text search.
- Final source audit RED exposed numeric literal-H vertex misgrading after coefficient collection. Repaired by grading exact typed original vertex/literal/current pieces BEFORE collection, preserving transformed anchor incidence, coupling/source degrees and exact coefficients; actual original numeric-H/current test is nonvacuous and green.
- Final source audit RED exposed C2.at(order3) silently returning0. It now refuses unsupported derivative order; no higher nonlinear-frame vanishing is inferred.
- No full scientific control executed, so complete scientific operation count, peak live records, integer heights, wall time, RSS and numerical coefficients remain UNKNOWN. Source review may identify further implementation defects.

## Decisions and preserved acceptance

- Use existing .venv without uv after the cache access refusal; do not repair dependencies/cache.
- Keep original Task1 entire source prefixes fixed; new source and tests append only to assigned files.
- Retain full expensive scientific test without skip/xfail/environment bypass; current allocation selects bounded tests only.
- C3 references identify actual source/Gaussian premises only. Missing all-order quaternion/Dirac/minor/C2 bridges remain explicit Stage2/3 obligations, never invented references.
- Numeric link specialization retains a conservative original-anchor envelope in generic grading; it is not a disjoint-Haar certificate. Full one-site factorization independently checks actual surviving quaternion support before factorizing.

The source must still pass different complete original-science and algebra/cost reviews. Actual complete one-site execution and independent result review remain mandatory; ROOT owns all Git, broader gates and canonical closure. No production local8, physical P0/C3/N0 mapping or N16 denominator is consumed. New scalar/Dirac/Haar/C2 bridges retain Stage2/3 obligations. The final SAME-packet check is retained separately and must show expected owned-source drift, never self-refreshed.

No shared docs, notebook, roadmap, packet, ledger, Lean/backend/controller or Git mutation was performed. Stdlib difflib froze the scoped candidate delta; ROOT owns git diff --check and normal integration.

## ROOT-admitted protected regression

`PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/tmp:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 .venv/bin/python -m pytest tests/test_original_coefficients.py tests/test_dependency_declaration.py tests/test_original_coefficient_jets.py -k 'not test_original_full_small_carrier_direct_vs_auxiliary' -vv -s -p no:cacheprovider -p task2_runtime_receipts_plugin`

Exit0: **67 passed,1 deselected in19.08s**:47 protected Task1+5 dependency+15 new bounded Task2. The only deselection is `test_original_full_small_carrier_direct_vs_auxiliary`. All67 exact selected node IDs and per-node process RSS receipts are in the companion JSON and `/tmp/task2-combined-resources.json`; existing scalar teardown counters are in `/tmp/task2-combined-tests.log`. Maximum reported outer-fixture scalar count156928; process lifetime peak256049152bytes (<512MiB). These RSS values are shared-process high-water snapshots at each teardown, not isolated per-fixture allocation peaks. Five static dependency checks emit no original-coefficient scalar counter; their count remains null rather than invented0. Tiny nested refusal counters are separate from the existing outer-fixture counters.

Final SAME packet after combined regression: exit1,fresh=false,changed=[owned-files,source] ONLY. Expected owned-source drift retained without refreshing. ROOT must reconcile before review/acceptance.
