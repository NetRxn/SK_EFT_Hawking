from fractions import Fraction as F
import json,hashlib,pathlib,zipfile,resource
from src.vestigial import original_coefficients as o
from src.core import formulas as f
p=o.Polynomial.scalar
results={}
with o.ExactBudget(10000,512*1024**2) as b:
 h=o.Symbol('h',(0,)); H=o.Polynomial.variable(h); W=H*H+p(2); D=H*H*H*H+H*H+p(1)
 ibp=[]
 for v in (F(2),F(3)):
  first,second=f.original_auxiliary_insertion_weights(W,(h,),v)
  def integral(poly):return sum((c.real*f.original_gaussian_moment((len(k),),v) for k,c in poly.terms),F())
  direct=integral(W*o.polynomial_derivative(o.polynomial_derivative(D,h),h))
  correct=integral(second[0,0]*D)
  poisoned=integral(((H*H*F(1,v*v)-p(F(1,v)))*W)*D)
  assert correct==direct and poisoned!=direct
  ibp.append({'variance':str(v),'direct_second':str(direct),'ibp_second':str(correct),'missing_W_derivatives':str(poisoned)})
 results['tiny_polynomial_IBP']=ibp
 # Deliberately artificial eight-generator top insertion checks public generic
 # request/certificate integrity, not original scientific coefficient output.
 reg=o.OriginalRegulator((1,1,1,1)); J=o.Symbol('J',(0,)); Hsym=o.Symbol('H',(0,))
 labels=(0,1); zero=o.RawJet.constant(o.ExteriorPolynomial(),labels)
 insertion=o.RawJet.constant(o.ExteriorPolynomial(((255,o.Polynomial.variable(J)),)),labels)
 measure=o.RawJet.constant(p(1),labels)
 term=o.GradedTerm(4,(0,0),(1,0),('insertion',),o.GeneratorLinkSupport(reg.generator_order,(),reg.sites),1)
 grading=o.SourceFamilyGrading(tuple((k,((term,) if not k else ())) for k in zero.indices()))
 source=o.SourceJet(labels,grading,zero,insertion,measure)
 bad=o.SupportCertificate('certificate names H while request names J',((Hsym,),),o.SourceFamilyGrading(()),True,reg.generator_order,reg.link_order)
 request=o.CoefficientRequest(None,((J,),),'artificial top insertion integrity probe',bad)
 # Active budget nesting is avoided: generic contract owns its new cost scope.
 generic=o.ExactBudget(10000,512*1024**2)
 answer=o.contract_original(reg,source,request,generic)
 results['mismatched_complete_certificate']={'accepted':True,'certificate_roster':repr(answer.support.source_multiindices),'requested_roster':repr(request.source_multiindices),'returned_value':repr(dict(answer.N)[()]),'source_grading_indices':len(source.grading.entries),'certificate_grading_indices':len(answer.support.grading.entries),'products':generic.products}
 bound=o.SupportCertificate('same honest grading but wrong source roster',((Hsym,),),grading,True,reg.generator_order,reg.link_order)
 second_request=o.CoefficientRequest(None,((J,),),'artificial top insertion integrity probe',bound)
 second_budget=o.ExactBudget(10000,512*1024**2)
 second_answer=o.contract_original(reg,source,second_request,second_budget)
 results['mismatched_roster_with_same_grading']={'accepted':True,'returned_J':dict(second_answer.N)[()]==o.Polynomial.variable(J),'grading_equal':second_answer.support.grading==source.grading,'products':second_budget.products}
 results['products']=b.products
results['process_peak_RSS_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
root=pathlib.Path('.')
z=zipfile.ZipFile('docs/audits/2026-10-17-publication-substance-construction/ORIGINAL_COEFFICIENT_TASK1_FROZEN_R2_EVIDENCE.zip')
results['conservation']={}
for name in ('src/core/formulas.py','src/vestigial/original_coefficients.py','tests/test_original_coefficients.py'):
 old=z.read('candidate/'+name);new=(root/name).read_bytes()
 results['conservation'][name]={'old_bytes':len(old),'new_bytes':len(new),'old_sha256':hashlib.sha256(old).hexdigest(),'whole_sha256':hashlib.sha256(new).hexdigest(),'prefix_equal':new.startswith(old),'unchanged':new==old}
pathlib.Path('/tmp/task2-science-r1-tiny-probes.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
