from fractions import Fraction
import json, resource
from src.vestigial import original_coefficients as o

out={}
actual=o.QComplex.__mul__
products=[]
def measured(self,other):
    products.append(1)
    return actual(self,other)
o.QComplex.__mul__=measured
o.QComplex.__rmul__=measured
q=o.Symbol('q',((0,0,0,0),0,'L',0))
p=o.Polynomial((((q,q),o.QComplex(2)),))
with o.ExactBudget(1000,512*1024**2) as budget:
    products.clear(); value=o.integrated_polynomial_product(p,p)
    out['integrated_product']={'result':str(value),'counted':budget.products,'QComplex_multiplies':len(products)}
j=o.Symbol('J',(0,))
p=o.Polynomial((((j,j),o.QComplex(3)),))
with o.ExactBudget(1000,512*1024**2) as budget:
    products.clear(); value=o.polynomial_derivative(p,j)
    out['derivative']={'result':str(value),'counted':budget.products,'QComplex_multiplies':len(products)}
p=o.Polynomial((((q,q),o.QComplex(2)),))
with o.ExactBudget(1000,512*1024**2) as budget:
    products.clear(); value=o.haar_polynomial(p)
    out['haar']={'result':str(value),'counted':budget.products,'QComplex_multiplies':len(products)}
o.QComplex.__mul__=actual; o.QComplex.__rmul__=actual
# Height limit applies to all exact scalar records, but arithmetic paths may evade it.
with o.ExactBudget(1000,512*1024**2,integer_bit_limit=8) as budget:
    value=o.integrated_polynomial_product(o.Polynomial.scalar(2**20),o.Polynomial.scalar(1))
    out['unobserved_height']={'returned':value.storage,'peak_records':budget.peak_scalar_records,'height_limit':budget.integer_bit_limit}
# Frozen outer certificate can hold mutable unchecked grading.
mutable=[]
cert=o.SupportCertificate('declared complete',(),mutable,True,(),())
mutable.append('changed after construction')
out['mutable_certificate_grading']=cert.grading
# SourceJet checks only the derivative INDEX roster, not actual raw summands.
reg=o.OriginalRegulator((1,1,1,1))
one=o.ExteriorPolynomial(((0,o.Polynomial.scalar(1)),))
top=o.ExteriorPolynomial(((255,o.Polynomial.scalar(1)),))
zero=o.ExteriorPolynomial()
labels=(0,1)
action=o.RawJet.constant(zero,labels)
grading=o.SourceFamilyGrading(tuple((k,()) for k in action.indices()))
source=o.SourceJet(labels,grading,action,o.RawJet.constant(top,labels),o.RawJet.constant(o.Polynomial.scalar(1),labels))
# Deliberately inconsistent request/certificate source rosters and grading.
cert=o.SupportCertificate('declared other roster',((o.Symbol('H',(0,0)),),),o.SourceFamilyGrading(()),True,reg.generator_order,reg.link_order)
request=o.CoefficientRequest(None,(),'unit',cert)
budget=o.ExactBudget(10000,512*1024**2)
result=o.contract_original(reg,source,request,budget)
out['incoherent_accepted']={'source_grading_terms':sum(len(v) for k,v in grading.entries),'insertion_nonzero':bool(top.terms),'certificate_derivative_slots':len(cert.grading.entries),'roster_matches':request.source_multiindices==cert.source_multiindices,'result_support_complete':result.support.complete,'constant_top':str(dict(result.N)[()].terms),'products':budget.products}
out['RSS_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
assert out['RSS_bytes']<512*1024**2
print(json.dumps(out,indent=2))
