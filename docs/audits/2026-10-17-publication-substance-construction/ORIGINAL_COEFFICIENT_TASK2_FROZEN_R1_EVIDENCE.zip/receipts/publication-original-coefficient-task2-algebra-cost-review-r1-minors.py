from fractions import Fraction as F
from itertools import combinations
from math import factorial
import resource,json
from src.vestigial import original_coefficients as o
from src.core import formulas as f
p=o.Polynomial.scalar
results=[]
for rows in (((1,2,0,1),(0,1,3,0),(2,0,1,1),(1,1,0,2)),((1,2,0,1),(0,1,3,0),(1,2,0,1),(1,1,0,2))):
 with o.ExactBudget(1_000_000,512*1024**2) as budget:
  matrix=o.SparseMatrix(4,tuple(((i,j),v) for i,row in enumerate(rows) for j,v in enumerate(row)))
  bil=o.ExteriorPolynomial()
  for i,row in enumerate(rows):
   for j,v in enumerate(row):
    bil+=o.ExteriorPolynomial.generator(i)*o.ExteriorPolynomial.generator(4+j)*p(v)
  one=o.ExteriorPolynomial(((0,p(1)),)); power=one; exp=one
  for n in range(1,5):
   power=power*bil;exp+=power*p(F(1,factorial(n)))
  checked=0
  for k in range(5):
   for bars in combinations(range(4),k):
    for psis in combinations(range(4),k):
     ins=one
     for i in bars:ins=ins*o.ExteriorPolynomial.generator(i)
     for i in psis:ins=ins*o.ExteriorPolynomial.generator(4+i)
     actual=dict((ins*exp).terms).get(255,p(0))
     assert actual==o.complementary_insertion(matrix,bars,psis),(bars,psis,actual)
     checked+=1
  budget.check_storage((matrix,bil,exp))
  results.append({'minors':checked,'products':budget.products,'peak_modeled_bytes':budget.peak_payload_bytes})
with o.ExactBudget(1_000_000,512*1024**2) as budget:
 checked=0
 for v in (F(2),F(3)):
  for a in range(5):
   for b in range(9):
    assert o.hermite_gaussian_contraction((a,),(b,),v)==o.count_hermite_contraction((0,)*a,(0,)*b,v)
    checked+=1
 results.append({'independent_Hermite_comparisons':checked,'products':budget.products})
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
assert rss<512*1024**2
print(json.dumps({'fixtures':results,'peak_RSS_bytes':rss},indent=2))
