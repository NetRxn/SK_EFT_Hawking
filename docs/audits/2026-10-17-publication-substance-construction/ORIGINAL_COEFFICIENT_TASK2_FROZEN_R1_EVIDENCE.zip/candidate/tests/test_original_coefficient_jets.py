"""Exact bounded jet controls and separately admitted COMPLETE one-site control."""
from fractions import Fraction as F
import pytest
from src.vestigial import original_coefficients as o
from src.core import formulas as f

@pytest.fixture(autouse=True)
def bounded_work(request):
    if request.node.name == 'test_original_full_small_carrier_direct_vs_auxiliary':
        yield
    else:
        with o.ExactBudget(1_000_000,512*1024**2) as cost:
            yield
        import resource
        rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        assert rss<=512*1024**2
        print('SCALAR_PRODUCTS', request.node.name, cost.products, 'PROCESS_PEAK_RSS_BYTES',rss)


def p(x): return o.Polynomial.scalar(x)

def test_singular_first_mixed_repeated_minors():
    z = o.SparseMatrix(2, ())
    a = o.SparseMatrix(2, (((0,0),1),))
    b = o.SparseMatrix(2, (((1,1),1),))
    m = o.SparseMatrix(2, (((1,1),3),))
    assert o.determinant_jet(m, (a,)).at((0,)) == p(3)
    assert o.determinant_jet(z, (a,b)).at((0,1)) == p(1)
    ident = o.SparseMatrix(2, (((0,0),1),((1,1),1)))
    assert o.determinant_jet(z, (ident,)).at((0,0)) == p(2)
    assert o.determinant_jet(o.SparseMatrix(1,()), (o.SparseMatrix(1,(((0,0),1),)),)).at((0,0)) == p(0)
    assert o.complementary_insertion(m, (0,), (0,)) == p(3)
    # Two sorted bars then two sorted psis supply a minus at n=2.
    assert o.complementary_insertion(z,(0,1),(0,1)) == p(-1)


def test_exact_gaussian_haar_and_sigma_independence():
    for v in (F(2),F(3)):
        assert f.original_gaussian_moment((3,),v)==0
        assert f.original_gaussian_moment((4,2),v)==3*v**3
        assert f.original_scaled_hermite(2,v)==((0,-v),(2,F(1)))
        assert o.hermite_gaussian_contraction((2,), (2,), v)==2
        assert o.hermite_gaussian_contraction((0,), (4,), v)==3*v*v
        assert o.hermite_gaussian_contraction((3,), (3,), v)==6
        # Independent polynomial expansion, not formula-to-itself.
        assert o.hermite_gaussian_contraction((2,), (4,),v)==12*v
    assert f.original_quaternion_haar_moment((2,0,0,0))==F(1,4)
    assert f.original_quaternion_haar_moment((4,0,0,0))==F(1,8)
    assert f.original_quaternion_haar_moment((2,2,0,0))==F(1,24)
    q=lambda axis,ch,k:o.Symbol('q',((0,0,0,0),axis,ch,k))
    assert o.haar_polynomial(o.Polynomial((((q(0,'L',1),)*2+(q(0,'R',1),)*2,1),)))==p(F(1,16))
    assert o.haar_polynomial(o.Polynomial((((q(0,'L',1),q(1,'L',1)),1),)))==p(0)


def test_raw_contacts_acceleration_and_denominator():
    J=o.RawJet
    # O=2+3t+5s+7t²/2+11ts+13s²/2, S analog; measure moves too.
    a=J.from_slots((2,3,5,7,11,13)); b=J.from_slots((17,19,23,29,31,37))
    assert (a*b).slots()==(34,89,131,291,413,525)
    x=J.from_slots((0,2,3,5,7,11))
    ex=o.exponential_jet(x, p(1))
    assert ex.slots()==tuple(map(p,(1,2,3,9,13,20)))
    out=o.insertion_action_measure_jet(a,x,b, p(1))
    assert out == a*ex*b
    n=J.from_slots((2,3,5,7,11,13)); den=J.from_slots((4,2,3,5,7,11))
    r=o.normalize_jet(n,den,o.NonzeroZCertificate(o.QComplex(4)))
    assert r.at(())==o.QComplex(F(1,2))
    assert r.at((0,))==o.QComplex(F(1,2))
    assert r.at((0,1))==o.QComplex(F(17,16))
    # Frame acceleration is not truncated by Grassmann/source derivative count.
    frames=f.original_diagonal_frame_jets()
    assert frames[0].at((0,1))==p(1)
    assert frames[1].at((0,0))==p(1)
    assert frames[2].at((1,1))==p(1)
    assert frames[3].at((0,1))==p(2)


def test_W_derivative_and_all_jet_contacts():
    h=o.Polynomial.variable(o.Symbol('h',(0,)))
    for v in (F(2),F(3)):
        w=h*h+p(2)
        first,second=f.original_auxiliary_insertion_weights(w,(o.Symbol('h',(0,)),),v)
        assert first[0]==h*w*F(1,v)-h*2
        assert second[0,0]==(h*h*F(1,v*v)-p(F(1,v)))*w-h*h*F(4,v)+p(2)
        assert second[0,0] != (h*h*F(1,v*v)-p(F(1,v)))*w


def test_source_family_grading_and_unknown_refusals():
    s=o.GeneratorLinkSupport((),(),())
    # Odd literal metric order IS permitted by weighted saturation.
    g=o.GradedTerm(2,(0,0),(0,1),('literal_metric',),s,F(1))
    assert g.saturates(1,inserted_degree=2)
    assert not g.saturates(1)
    assert o.literal_source_supported(4,0,1,2)
    assert not o.literal_source_supported(4,1,1,0)
    with pytest.raises(ValueError,match='UNKNOWN'):
        o.normalize_jet(o.RawJet.constant(o.QComplex(1)),o.Unknown('full Z not computed'),None)
    with pytest.raises(ValueError,match='nonzero'):
        o.NonzeroZCertificate(o.QComplex(0))
    with pytest.raises(ValueError,match='Hessian'):
        o.legendre_local(((0,0),(0,0)), (0,1))
    assert o.legendre_local(((2,0),(0,3)), (0,1)) == ((o.QComplex(F(1,2)),o.QComplex()),(o.QComplex(),o.QComplex(F(1,3))))


def test_exact_budget_no_partial_complete_result():
    with pytest.raises(o.BudgetExceeded,match='incomplete'):
        with o.ExactBudget(0,512*1024**2):
            o.determinant_jet(o.SparseMatrix(1,(((0,0),1),)),())
    with pytest.raises(o.BudgetExceeded,match='storage'):
        o.ExactBudget(100,1).check_storage((p(1),))


def test_original_full_small_carrier_direct_vs_auxiliary():
    # This COMPLETE scientific test requires ROOT runtime admission. No skip or
    # environment bypass; bounded allocation selects other named tests explicitly.
    with o.ExactBudget(250_000_000,2*1024**3) as budget:
        result=f.original_one_site_complete_control(budget=budget)
    assert result['complete']
    assert result['quartic_slots']==3876 and result['center_allowed']==740
    assert result['words']==('printed','closed') and result['variances']==(F(2),F(3))
    assert result['query_count']==23504*4
    # Expected accepted polynomial is a regression ORACLE only in this test.
    # The production coefficients were independently generated from original
    # coframe, exterior, determinant, Gaussian and Haar arithmetic.
    origin=(0,0,0,0)
    j=tuple(o.Polynomial.variable(o.Symbol('J',(origin,mu,a))) for mu in range(4) for a in range(4))
    g2=o.Polynomial.variable(o.Symbol('g2',()))
    rows=tuple(sum((j[4*mu+a]*j[4*mu+a] for a in range(4)),p(0)) for mu in range(4))
    expected=g2*g2*96+sum((r*r*F(25,128) for r in rows),p(0))
    from itertools import combinations
    for mu,nu in combinations(range(4),2):
        dot=sum((j[4*mu+a]*j[4*nu+a] for a in range(4)),p(0))
        expected+=rows[mu]*rows[nu]*F(13,32)+dot*dot*F(1,16)
    for word, report in result['reports'].items():
        assert report['direct']==report['auxiliary'][F(2)]==report['auxiliary'][F(3)]==expected
        assert report['interacting_denominator']==p(96)
        assert report['nonzero_quartics']==172
        assert len(report['T_first'])==16 and len(report['T_second'])==136
        assert len(report['H_first'])==10 and len(report['H_second'])==55
        assert report['frame_direct']==report['frame_auxiliary'][F(2)]==report['frame_auxiliary'][F(3)]


def test_prehaar_frame_metric_current_contacts():
    reg=o.OriginalRegulator((2,1,1,1))
    x,y=reg.sites
    # Exact original endpoint bilinear and local phase charge, then frame path.
    links={anchor:f.original_spin4_link((0,1,0,0),(0,0,1,0)) for anchor in reg.link_order}
    t=o.assemble_coframe(reg,f.original_coframe_blocks(reg,(x,0,3),links)).to_exterior(reg)
    charges={x:F(0),y:F(1)}
    current=o.exterior_phase_derivative(t,reg,charges)
    assert current != o.ExteriorPolynomial()
    scalar=o.RawJet.from_slots(tuple(p(v) for v in (1,2,3,5,7,11)))
    tj=o.RawJet.constant(t)*scalar
    cj=o.apply_linear_map_jet(tj,lambda v:o.exterior_phase_derivative(v,reg,charges))
    assert cj.at((0,1))==current*p(7)
    coframes={(x,mu,a):tj for mu in range(4) for a in range(4)}
    metric=f.original_literal_metric(coframes,x,0,1)
    assert metric.at((0,1))==(t*t)*p(4*(2*7+2*2*3))
    assert o.apply_linear_map_jet(metric,lambda v:o.exterior_phase_derivative(v,reg,charges)).at((0,1))==o.exterior_phase_derivative(metric.at((0,1)),reg,charges)


def test_literal_metric_joint_polynomial_repeated_factors():
    j=tuple(o.Symbol('J',(i,)) for i in range(16))
    h=tuple(o.Symbol('H',(i,)) for i in range(10))
    # A complete formal quartic seed tests generic H and raw factors without
    # asserting this formal seed is an averaged original one-site coefficient.
    seed=o.Polynomial((((j[0],)*4,1),((j[0],j[0],j[4],j[4]),1)))
    joint=o.literal_metric_source_polynomial(seed,j,h)
    assert dict(joint.terms)[tuple(sorted((h[0],h[0])))]==o.QComplex(12)
    # Offdiagonal H01 occurs once: dJ0 dJ4 on J0²J4² gives 4J0J4.
    assert dict(joint.terms)[tuple(sorted((j[0],j[4],h[1])))]==o.QComplex(4)
    assert dict(joint.terms)[tuple(sorted((h[1],h[1])))]==o.QComplex(2)


def test_weight_full_degree_compensation_without_local8():
    x=o.Symbol('X',(0,)); X=o.Polynomial.variable(x)
    # Independent tiny EXACT Hermite algebra fixture; original full carrier is
    # the separate full scientific control. No substitution for that target.
    for v in (F(2),F(3)):
        w=o.hermite_weight(X*X*F(2,3),(x,),v,4)
        h=o.Symbol('h',(0,)); aux=o.Polynomial.variable(h)
        # Evaluate every polynomial coefficient through independently expanded
        # centered Gaussian moments against the true polynomial determinant seed.
        product=w*(aux*aux*aux*aux)
        value=sum((c.real*f.original_gaussian_moment((len(k),),v) for k,c in product.terms),F(0))
        assert value==F(16,3)
    with pytest.raises(ValueError,match='zero X-constant'):
        o.hermite_weight(p(1),(x,),F(2),4)


def test_original_zero_coupling_normalization_refusal():
    # Original V=1 has four fermion pairs, so literal zero M determinant is0.
    zero=o.determinant_jet(o.SparseMatrix(4,()),())
    assert zero.at(())==p(0)
    with pytest.raises(ValueError,match='nonzero'):
        o.normalize_jet(zero,zero,None)
    with pytest.raises(ValueError,match='nonzero'):
        o.logarithmic_response(zero,None)


def test_graded_coefficient_and_complete_raw_weight_schedule():
    # Metadata-only full raw roster: no original coefficients/Haar/control run.
    from itertools import combinations,permutations
    quadratic={(4*mu+a,4*nu+b):p(1) for mu,nu in combinations(range(4),2) for a in range(4) for b in range(4) if a!=b}
    quartic=tuple((tuple(4*mu+a for mu,a in enumerate(order)),F(o.epsilon(order))) for order in permutations(range(4)))
    for v in (F(2),F(3)):
        terms=o.one_site_weight_terms(quadratic,quartic,v)
        assert len(terms)==4029
        assert sum(1 for term in terms for _ in o.gaussian_compatible_queries(term))==23504
        assert sum(term.origin=='compensation' for term in terms)==16
    assert len(o.multiindices(16,4))==3876
    assert sum(o.direction_center_even(k) for k in o.multiindices(16,4))==740
    assert sum(not o.direction_center_even(k) for k in o.multiindices(16,4))==3136


def test_actual_original_frame_phase_action_pullback():
    reg=o.OriginalRegulator((2,1,1,1)); x,y=reg.sites
    choices=((F(3,5),F(4,5),0,0),(F(5,13),0,F(12,13),0),(0,0,0,1),(F(8,17),F(9,17),F(12,17),0))
    links={anchor:f.original_spin4_link(choices[i%4],choices[(i+1)%4]) for i,anchor in enumerate(reg.link_order)}
    zero=o.RawJet.constant(p(0)); ident=o.RawJet.constant(p(1))
    frame={(site,mu,nu):(ident if mu==nu and mu<2 else zero) for site in reg.sites for mu in range(4) for nu in range(4)}
    for site in reg.sites:
        frame[site,0,0]=o.RawJet.from_slots(tuple(p(v) for v in (1,2,0,3,0,0)))
    phase={x:zero,y:o.RawJet.from_slots(tuple(p(v) for v in (0,0,1,0,0,0)))}
    charges={x:0,y:1}
    jet=f.original_frame_source_jet(reg,links,frame=frame,phase=phase,g2=1,metric_sources={(x,0,0):1},insertion=lambda t:f.original_literal_metric(t,x,0,0))
    assert jet.action.at(()) != o.ExteriorPolynomial()
    assert jet.action.at((1,)) == o.exterior_phase_derivative(jet.action.at(()),reg,charges)
    assert jet.action.at((0,1)) == o.exterior_phase_derivative(jet.action.at((0,)),reg,charges)
    assert jet.insertion.at((0,0)) == jet.insertion.at(())*p(2*3+2*2**2)
    assert jet.measure.at((0,1))==p(0)
    assert any(term.t_degree==2 and term.coupling_powers==(0,1) for key,terms in jet.grading.entries for term in terms if term.contact_labels==('action',))
    assert any(term.t_degree==2 and term.coupling_powers==(0,0) and term.source_powers==(0,1) for key,terms in jet.grading.entries for term in terms if term.contact_labels==('literal_metric',))


def test_generic_coefficient_request_preserves_coupling_roster():
    g1,g2=o.Symbol('g1',()),o.Symbol('g2',())
    cert=o.SupportCertificate('bounded exact polynomial fixture',(),o.SourceFamilyGrading(()),True,(),())
    request=o.CoefficientRequest(((0,2),),(),'unit',cert)
    poly=o.Polynomial((((g1,),2),((g2,g2),3),((),5)))
    assert o.extract_requested_coefficients(poly,request)==o.Polynomial((((g2,g2),3),))


def test_accelerated_singular_three_by_three_and_jet_immutability():
    m=o.SparseMatrix(3,(((1,1),2),((2,2),3)))
    identity=o.SparseMatrix(3,tuple(((i,i),1) for i in range(3)))
    acceleration=o.SparseMatrix(3,(((0,0),5),))
    jet=o.determinant_jet(m,(identity,),{(0,0):acceleration})
    # det(diag(0,2,3)+t I)=6t+5t²+t³. Matrix acceleration adds5*6.
    assert jet.at((0,))==p(6)
    assert jet.at((0,0))==p(40)
    labels=[0,1]; index=[0]
    value=o.RawJet(labels,(((),p(2)),(index,p(3))))
    labels[0]=8; index[0]=1
    assert value.labels==(0,1) and value.at((0,))==p(3)
    with pytest.raises(TypeError,match='immutable'):
        o.RawJet((0,),(((),[1]),))
    with pytest.raises(ValueError,match='C2'):
        value.at((0,0,0))


def test_factored_weight_and_request_metadata_freeze():
    labels=[0,1]; directions=[0,0]
    term=o.FactoredWeightTerm(labels,F(2),frame_directions=directions)
    labels[0]=9;directions[0]=3
    assert term.eta==(0,1) and term.frame_directions==(0,0)
    roster=[[o.Symbol('J',(0,))]]; coupling=[[0,2]]
    cert=o.SupportCertificate('unit',roster,o.SourceFamilyGrading(()),True,[],[])
    request=o.CoefficientRequest(coupling,roster,'unit',cert)
    roster[0].clear();coupling[0][1]=4
    assert request.coupling_powers==((0,2),)
    assert request.source_multiindices==cert.source_multiindices==((o.Symbol('J',(0,)),),)
