#!/bin/zsh
set -euo pipefail
cd -- "${0:A:h}"
primary=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking
frozen=/private/tmp/l1-c0-odd.XZTIsVjI
prev=/private/tmp/l1-c0-multi-independent.8aMOEQWW
dual=/private/tmp/l1-c0-dual-independent.iqPptEG2
(cd "$primary"; python3 scripts/codex_continuity.py check .codex/continuity/l1-c0-odd-square-pause-independent-r1.json) > continuity.out
verify() {
    local dir=$1 digest=$2 out=$3
    (cd "$dir"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > "$out"
    test "$(cut -d' ' -f1 < "$out" | head -1)" = "$digest"
}
verify "$frozen" dd14df650b3ddbe7e843c55ea19f67822a995239f1c888eda3af30a383cf4859 author-manifest.out
verify "$prev" b04908b4be942bfd5bc54b868e83c2ecac3fd1eef4fc2363ace1cd3eae216440 multi-manifest.out
verify "$dual" 96f585f21560748dd3ab643dd5ffc4eda9a06ea9af110fc65db5c9ee80c938cc dual-manifest.out
cmp project.py "$prev/project.py"
for f in census.py classify.py bivectors.tsv source-gram.tsv edge-moments.tsv mixed.tsv quadratic-all.tsv imaginary-trace.tsv adjoint.tsv fundamental-product.tsv source-edge.tsv; do cmp "$f" "$dual/$f"; done
cmp source-edge.tsv "$frozen/edge_coframes.tsv"
export PYTHONDONTWRITEBYTECODE=1
PYTHONPATH="$primary" "$primary/.venv/bin/python" fundamental.py > fundamental.out
cmp fundamental.tsv "$frozen/fundamental.tsv"
python3 own.py > own.out
cmp own.tsv "$frozen/own.tsv"
clang++ -O3 -std=c++20 -Wall -Wextra -Werror -Wno-unused-function -fsanitize=undefined -fno-sanitize-recover=all odd_edge.cpp -o odd_edge
./odd_edge > odd-edge.out
cmp odd-edge.tsv "$frozen/odd-edge.tsv"
PYTHONPATH="$primary" "$primary/.venv/bin/python" character.py > character.out
python3 odd_run.py > odd-run.out
cmp odd-exact.tsv "$frozen/odd-exact.tsv"
PYTHONPATH="$primary" "$primary/.venv/bin/python" square.py > square.out
python3 width.py > width.out
python3 remaining.py > remaining.out
