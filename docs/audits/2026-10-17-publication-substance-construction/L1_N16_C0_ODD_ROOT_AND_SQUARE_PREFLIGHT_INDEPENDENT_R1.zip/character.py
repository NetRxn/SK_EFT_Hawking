from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import product
from src.core.formulas import original_quaternion_haar_moment
from census import read

source=defaultdict(list)
for side,lab,m,q,r,i in (map(int,r) for r in read("source-edge.tsv")):
    source[side,lab].append((m,q,(r,i)))
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def sign(a,b):return (-1)**sum((a>>(i+1)).bit_count() for i in range(16) if b>>i&1)
@cache
def haar(key):
    ex=Counter(key)
    out=F(1)
    for j in range(0,16,4):
        out*=original_quaternion_haar_moment(tuple(ex[j+k] for k in range(4)))
    return out

def table(side,m):
    out=defaultdict(list)
    for (u,q,a),(v,r,b) in product(source[side,0],repeat=2):
        if u&v or (u|v)&~m:continue
        A=mul(a,b);c=sign(u,v)
        out[u|v].append(((q,r),(c*A[0],c*A[1])))
    return out

for loads,h,a,b,z in (((0,4),0,15,240,F(-3,8)),((0,4),0,53,92,F(3,32)),
                     ((2,2),1,15,240,F(-3,32)),((2,2),1,53,92,F(3,64))):
    target=a|(b<<8)
    L,R=table(int(loads==(0,4)),target),table(1,target)
    real=imag=F(0)
    for u,rows in L.items():
        v=target^u
        for (q,a0),(p,b0) in product(rows,R.get(v,())):
            w=sum(2*(1 if k==0 else -1)*haar(tuple(sorted(q+p+(4*h+k,8+4*h+k)))) for k in range(4))
            if not w:continue
            r,i=mul(a0,b0);c=sign(u,v)
            real+=r*c*w/256;imag+=i*c*w/256
    assert (real,imag)==(z,0)
    print("canonical character raw check",loads,h,a,b,real)
