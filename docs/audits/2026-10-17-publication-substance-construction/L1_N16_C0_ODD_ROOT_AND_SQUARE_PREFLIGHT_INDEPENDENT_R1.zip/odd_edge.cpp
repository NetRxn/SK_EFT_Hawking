#include <tuple>
#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>
using I=int64_t;
using W=__int128_t;
using V=std::vector<int>;
struct Z {
    I r=0,i=0;
    bool any() const {return r||i;}
    void add(Z z,int s=1){r+=s*z.r;i+=s*z.i;}
    Z mul(Z z)const{return {r*z.r-i*z.i,r*z.i+i*z.r};}
};
std::string dec(W n){
    if(n<0)return "-"+dec(-n);
    std::string s;
    do{s.push_back('0'+n%10);n/=10;}while(n);
    return {s.rbegin(),s.rend()};
}
int wedge(unsigned a,unsigned b) {
    unsigned inversions=0;
    for(int j=0;j<16;++j)if((b>>j)&1)inversions+=std::popcount(a>>(j+1));
    return 1-2*(inversions&1);
}
struct Term { unsigned mask; int q; Z val; };
std::vector<Term> src[2][4];
struct Degree2 { unsigned mask; std::array<int,2> q;Z val; };
std::vector<Degree2> quadratic[2][4][4];
void quadratics(){
    for(int s=0;s<2;++s)for(int a=0;a<4;++a)for(int b=a;b<4;++b){
        std::map<std::array<unsigned,3>,Z> collected;
        for(auto u:src[s][a])for(auto v:src[s][b]){
            if(u.mask&v.mask)continue;
            collected[{u.mask|v.mask,unsigned(std::min(u.q,v.q)),unsigned(std::max(u.q,v.q))}]
                .add(u.val.mul(v.val),wedge(u.mask,v.mask));
        }
        for(auto [key,z]:collected)if(z.any())
            quadratic[s][a][b].push_back({key[0],{int(key[1]),int(key[2])},z});
    }
}
int moment48(std::array<int,2> a,std::array<int,2> b){
    std::array<int,4> q={a[0],a[1],b[0],b[1]};std::sort(q.begin(),q.end());
    if(q[0]!=q[1]||q[2]!=q[3])return 0;
    if(q[0]==q[2])return 6;
    return q[0]/4==q[2]/4 ? 2:3;
}
struct Entry {int l,r,ml,mr; Z z;};
std::vector<Entry> make_edge(const std::vector<V>& labelsL,const std::vector<V>& labelsR){
    std::vector<Entry> output;
    for(int l=0;l<int(labelsL.size());++l)for(int r=0;r<int(labelsR.size());++r){
        V a=labelsL[l],b=labelsR[r];
        if(a.empty())a=b;
        if(b.empty())b=a;
        const auto& u=quadratic[labelsL[l].empty()?1:0][a[0]][a[1]];
        const auto& v=quadratic[labelsR[r].empty()?0:1][b[b.size()-2]][b.back()];
        std::unordered_map<unsigned,Z> c;
        for(const auto& x:u)for(const auto& y:v){
            if(x.mask&y.mask)continue;
            const int w=moment48(x.q,y.q);if(!w)continue;
            c[x.mask|y.mask].add(x.val.mul(y.val),w*wedge(x.mask,y.mask));
        }
        for(auto [m,z]:c)if(z.any()){
            assert(std::popcount(m&255)==4&&std::popcount(m>>8)==4);
            output.push_back({l,r,int(m&255),int(m>>8),z});
        }
    }
    return output;
}

using Row=std::tuple<unsigned,std::array<int,2>,Z>;
using Buckets=std::map<unsigned,std::vector<Row>>;
std::map<std::array<int,4>,Buckets> pair_cache;
const Buckets& collect_pair(int u,int a,int v,int b){
    auto [it,fresh]=pair_cache.try_emplace({u,a,v,b});
    if(!fresh)return it->second;
    std::map<std::tuple<unsigned,int,int>,Z> rows;
    for(auto x:src[u][a])for(auto y:src[v][b]){
        if(x.mask&y.mask)continue;
        rows[{x.mask|y.mask,std::min(x.q,y.q),std::max(x.q,y.q)}]
            .add(x.val.mul(y.val),wedge(x.mask,y.mask));
    }
    for(auto [key,z]:rows)if(z.any()){
        auto [m,i,j]=key;
        it->second[(1U<<i)^(1U<<j)].push_back({m,{i,j},z});
    }
    return it->second;
}
int scalar_moment(std::vector<int> q,int den){
    std::array<int,16> ex{};
    for(int k:q)++ex.at(k);
    int num=1,divisor=1;
    for(int k=0;k<16;k+=4){
        int degree=0;
        for(int i=k;i<k+4;++i){
            if(ex[i]%2)return 0;
            degree+=ex[i];
            for(int j=1;j<ex[i];j+=2)num*=j;
        }
        for(int j=4;j<4+degree;j+=2)divisor*=j;
    }
    assert(den%divisor==0);
    return num*(den/divisor);
}
std::vector<V> words(int n){
    std::vector<V> result;
    auto gen=[&](auto&& self,V p,int min)->void{
        if(int(p.size())==n){result.push_back(p);return;}
        for(int a=min;a<4;++a){p.push_back(a);self(self,p,a);p.pop_back();}
    };
    gen(gen,{},0);
    return result;
}
int code(const V& labels){int z=0;for(int k:labels)z=4*z+k;return z;}
std::map<std::array<int,4>,std::pair<I,I>> tensor(int a,int b,int chi,bool crossed){
    std::map<std::array<int,4>,Z> result;
    uint64_t candidates=0;
    for(const auto& A:words(a))for(const auto& B:words(b)){
        std::vector<std::pair<int,int>> f;
        for(int n:A)f.push_back({0,n});
        for(int n:B)f.push_back({1,n});
        if(f.size()==4&&crossed)std::swap(f[1],f[2]);
        const auto& P=collect_pair(f[0].first,f[0].second,f[1].first,f[1].second);
        if(f.size()==2){
            assert(chi<0);
            const auto it=P.find(0);
            if(it!=P.end())for(auto [m,q,z]:it->second){
                result[{code(A),code(B),int(m&255),int(m>>8)}].add(z);
                ++candidates;
            }
            continue;
        }
        const auto& Q=collect_pair(f[2].first,f[2].second,f[3].first,f[3].second);
        for(int j=0;j<(chi<0?1:4);++j){
            int u=4*std::max(chi,0)+j,v=u+8;
            unsigned parity=chi<0?0:((1U<<u)|(1U<<v));
            for(const auto& [k,rows]:P){
                const auto match=Q.find(k^parity);
                if(match==Q.end())continue;
                candidates+=rows.size()*match->second.size();
                assert(candidates<=50000000);
                for(auto [m,p,z]:rows)for(auto [n,q,w]:match->second){
                    if(m&n)continue;
                    std::vector<int> ex={p[0],p[1],q[0],q[1]};
                    int coeff;
                    if(chi<0)coeff=scalar_moment(ex,48);
                    else{
                        ex.push_back(u);ex.push_back(v);
                        coeff=(j==0?2:-2)*scalar_moment(ex,192);
                    }
                    result[{code(A),code(B),int((m|n)&255),int((m|n)>>8)}].add(z.mul(w),wedge(m,n)*coeff);
                }
            }
        }
    }
    std::map<std::array<int,4>,std::pair<I,I>> kept;
    for(auto [k,z]:result)if(z.any())kept[k]={z.r,z.i};
    std::cout<<"loads "<<a<<' '<<b<<" chi "<<chi<<" crossed "<<crossed<<" candidates "<<candidates<<" rows "<<kept.size()<<'\n';
    return kept;
}
int main(){
    std::ifstream in("source-edge.tsv");int s,a,q;unsigned m;Z z;
    while(in>>s>>a>>m>>q>>z.r>>z.i)src[s][a].push_back({m,q,z});
    for(const auto& side:src)for(const auto& label:side)assert(label.size()==64);
    std::ofstream out("odd-edge.tsv");
    auto write=[&](int a,int b,int chi){
        auto t=tensor(a,b,chi,false);
        if(a+b==4)assert(t==tensor(a,b,chi,true));
        for(const auto& [k,z]:t){
            out<<a<<'\t'<<b<<'\t'<<chi;
            for(int x:k)out<<'\t'<<x;
            out<<'\t'<<z.first<<'\t'<<z.second<<'\n';
        }
    };
    for(auto [a,b]:{std::pair{1,1},{1,3},{3,1}})write(a,b,-1);
    for(auto [a,b]:{std::pair{0,4},{2,2},{4,0}})for(int j=0;j<2;++j)write(a,b,j);
}
