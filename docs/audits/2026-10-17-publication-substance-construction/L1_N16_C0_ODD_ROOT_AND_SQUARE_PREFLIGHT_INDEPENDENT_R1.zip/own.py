from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from census import read,write
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def add(a,b):return a[0]+b[0],a[1]+b[1]
data=defaultdict(list)
for i,j,q,r,z in (map(int,row) for row in read("fundamental.tsv")):
    data[q].append((i,j,(r,-z)))
raw=defaultdict(list)
out=defaultdict(dict)
for side,label,m,n,q,p,r,i in (map(int,row) for row in read("quadratic-all.tsv")):
    raw[side,label,m,n].append((q,p,(r,i)))
    if q//8==p//8 or (q//4)%2!=(p//4)%2:continue
    assert q<8<=p
    t=out[side,(q//4)%2]
    for (d,a,z),(b,c,w) in product(data[q%4],data[p%4]):
        key=label,m,n,2*a+b,2*c+d
        t[key]=add(t.get(key,(0,0)),mul((r,i),mul(z,w)))
rows=[]
for (side,h),table in sorted(out.items()):
    T={k:v for k,v in table.items() if any(v)}
    assert len(T)==360 and sum(i!=0 for r,i in T.values())==120
    rows.extend((side,h,*k,*v) for k,v in sorted(T.items()))
    k=next(k for k in sorted(T) if T[k][1]==-8)
    l,m,n,p1,p2=k
    a,b=divmod(p1,2);c,d=divmod(p2,2)
    value=(F(0),F(0))
    # Direct two-anchor integration, without requiring an anchor split
    # in advance. The first moment on each actually labelled group is
    # zero unless it is paired with its matching fundamental coefficient.
    for q,p,z in raw[side,l,m,n]:
        for j,k2 in product(range(4),repeat=2):
            qa=4*h+j;qc=8+4*h+k2
            if sorted((q,p))!=[qa,qc]:continue
            A=next((x for u,v,x in data[j] if (u,v)==(d,a)),(0,0))
            B=next((x for u,v,x in data[k2] if (u,v)==(b,c)),(0,0))
            v=mul(z,mul(A,B))
            value=add(value,(F(v[0],256),F(v[1],256)))
    assert value==(0,F(-1,32))
    print("own endpoint",side,"chirality",h,"rows",len(T),"direct imaginary control",value)
write("own.tsv",rows)
