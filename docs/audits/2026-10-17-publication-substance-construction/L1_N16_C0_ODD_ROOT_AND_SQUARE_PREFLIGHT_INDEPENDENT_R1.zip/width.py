from collections import Counter,defaultdict
from math import comb
from itertools import combinations_with_replacement,product
from census import read

pair_multiplicity=Counter()
for a,b,i,j,n in (map(int,r) for r in read("adjoint.tsv")):
    for h in (0,4):pair_multiplicity[h+i,h+j]+=1
for a,b,i,j,r,n in (map(int,r) for r in read("fundamental-product.tsv")):
    pair_multiplicity[i,j]+=1
assert len(pair_multiplicity)==36 and sum(pair_multiplicity.values())==112
by_parity=defaultdict(Counter)
for owner,label,u,v,q,r,re,im in (map(int,r) for r in read("quadratic-all.tsv")):
    assert re or im
    by_parity[owner,label][(1<<q)^(1<<r)]+=1
for owner,anchor,d in product(range(2),range(2),(2,4)):
    counts=[]
    for i,j in pair_multiplicity:
        p=(1<<(i+8*anchor))^(1<<(j+8*anchor))
        if d==2:
            n=sum(by_parity[owner,4*a+b][p] for a,b in combinations_with_replacement(range(4),2))
        else:
            n=0
            for a,b,c,e in combinations_with_replacement(range(4),4):
                A=by_parity[owner,4*a+b]
                B=by_parity[owner,4*c+e]
                n+=sum(w*B[k^p] for k,w in A.items())
        counts.append((i,j,n))
    raw=sum(pair_multiplicity[i,j]*n for i,j,n in counts)
    cached=sum(n for i,j,n in counts)
    peak=max(n for i,j,n in counts)
    assert (raw,cached,peak)==({2:(37600,11632,960),4:(43266176,14198720,1036576)}[d])
    print("owner",owner,"anchor",anchor,"degree",d,"raw",raw,"reuse",cached,"peak",peak)
dense=comb(7,4)*comb(8,4)**2*4**2
assert dense==2744000 and dense>150000
print("dense degree-four interface",dense,"cap",150000,"REFUSED before allocation; populated width unknown")
