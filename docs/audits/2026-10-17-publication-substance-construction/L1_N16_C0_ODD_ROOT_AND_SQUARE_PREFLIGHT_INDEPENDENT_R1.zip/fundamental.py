from itertools import product
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import Polynomial, Symbol
from census import write
X=(0,0,0,0)
Y=(0,1,0,0)
def actual(site,chi):
    variables=[Symbol("q",(site,1,chi,j)) for j in range(4)]
    Q=tuple(Polynomial.variable(s) for s in variables)
    I=(1,0,0,0)
    U=original_spin4_link(*((Q,I) if chi=="L" else (I,Q)))
    h=0 if chi=="L" else 2
    return variables,tuple(tuple(U[h+i][h+j] for j in range(2)) for i in range(2))
def character(A,B):
    return sum((A[i][j]*B[j][i] for i,j in product(range(2),repeat=2)),Polynomial())
rosters=[]
for chi in ("L","R"):
    a,A=actual(X,chi);b,B=actual(Y,chi)
    target=sum((2*(1 if j==0 else -1)*Polynomial.variable(a[j])*Polynomial.variable(b[j]) for j in range(4)),Polynomial())
    assert character(A,B)==target
    rows=[]
    for i,j in product(range(2),repeat=2):
        for (s,),z in A[i][j].terms:
            rows.append((i,j,s.index[-1],int(z.real),int(z.imag)))
    rosters.append(rows)
assert rosters[0]==rosters[1]
write("fundamental.tsv",rosters[0])
print("canonical fundamental roster and both original two-anchor characters checked")
