# Scoped independent acceptance

The replay verifies all 24 signed odd-root values and the conditional directed-square formula and preflight controls. The full signed square and full c0 remain open. No further tranche is active in this publication chat at the pause milestone.
