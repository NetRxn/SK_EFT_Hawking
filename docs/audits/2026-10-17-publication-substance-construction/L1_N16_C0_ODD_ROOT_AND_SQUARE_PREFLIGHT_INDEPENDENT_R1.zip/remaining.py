from collections import Counter
from fractions import Fraction as F
from project import projection
from census import profile,read,write

prev="/private/tmp/l1-c0-multi-independent.8aMOEQWW"
done={(int(a),int(b)):int(w) for a,b,w,z in read("odd-exact.tsv")}
out=[(a,b,w) for a,b,w in (map(int,r) for r in read(prev+"/block-remaining.tsv")) if (a,b) not in done]
assert len(out)==10458 and sum(w for a,b,w in out)==903819

def components(graph):
    seen=set()
    for a,b,k in graph:
        if a in seen:continue
        group={a,b}
        while True:
            ext=group|{v for e in graph if group.intersection(e[:2]) for v in e[:2]}
            if ext==group:break
            group=ext
        seen|=group
        yield {e:p for e,p in graph.items() if e[0] in group}

def kind(c):
    d=Counter(v for e in c for v in e[:2])
    if len(c)!=4 or set(d.values())!={2}:return None
    if any(a and b for a,b in c.values()):return "double"
    roots={u if p else v for (u,v,k),(p,q) in c.items()}
    return ("directed" if len(roots)==4 else "zigzag",tuple(sorted(a+b for a,b in c.values())))
squares=Counter();family=Counter()
for a,b,w in out:
    core=projection(a,b,2)[0]
    cc=[c for g in core for c in components(g)]
    ks=[kind(c) for c in cc]
    squares.update(k for k in ks if k is not None)
    if any(ks) and all(len(c)==1 or (k is not None and k!="double") for c,k in zip(cc,ks)):
        family["orbits"]+=1;family["labels"]+=w
    if (a,b)==(37086699520,8935831015554):
        assert w==48 and ks==[("directed",(2,)*4)]
        C=cc[0]
        root_to_dest={(u if p else v):(v if p else u) for (u,v,k),(p,q) in C.items()}
        assert root_to_dest=={0:4,4:6,6:2,2:0}
        A=profile(a)[2];B=profile(b)[2]
        assert all(tuple(sorted(A[e]))==(0,4) and tuple(sorted(B[e]))==(0,2) for e in C)
        print("directed square pilot",a,b,w,root_to_dest,"own two, opposite four")
assert squares["directed",(2,)*4]==774 and squares["double"]==2659
assert family=={"orbits":588,"labels":41868}
print("square orientation census",squares)
print("isolated-or-single-root-square family",dict(family))
print("remaining temporal block",len(out),sum(w for a,b,w in out))
write("block-remaining.tsv",out)
