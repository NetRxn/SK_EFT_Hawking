from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations_with_replacement,product
from src.core.formulas import original_plaquette,original_spin4_link,original_quaternion_haar_moment
from src.vestigial.original_coefficients import OriginalRegulator,Polynomial,QComplex,Symbol,matrix_multiply
from census import read

reg=OriginalRegulator(temporal_axis=0)
vertices=((0,0,0,0),(0,0,0,1),(0,0,1,1),(0,0,1,0))
directions=(3,2,3,2)
points=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),(F(1,2),)*4,(F(3,5),0,F(4,5),0))
obs=matrix_multiply(matrix_multiply(reg.gamma[0],reg.gamma[1]),reg.gamma5)
def literal_trace(M):
    return sum((M[i][j]*obs[j][i] for i,j in product(range(4),repeat=2)),Polynomial())
adj=list(tuple(map(int,r)) for r in read("adjoint.tsv"))
fund=list(tuple(map(int,r)) for r in read("fundamental-product.tsv"))
imag={(i,j,k):QComplex(r,n) for i,j,k,r,n in (map(int,r) for r in read("imaginary-trace.tsv"))}
bv={(h,i):s for h,a,b,i,s in (map(int,r) for r in read("bivectors.tsv")) if (a,b)==(0,1)}
def matrix(d,entries):
    out=[[QComplex() for j in range(d)] for i in range(d)]
    for i,j,z in entries:out[i][j]+=z
    return out
def transpose(a):return tuple(zip(*a))
def dagger(a):return [[z.conjugate() for z in r] for r in transpose(a)]
def multiply(a,b):
    return [[sum((x*y for x,y in zip(r,s)),QComplex()) for s in transpose(b)] for r in a]
def trace(a):return sum((row[i] for i,row in enumerate(a)),QComplex())
def repr_matrix(q,j):
    if j==0:return [[QComplex(1)]]
    if j<3:
        v=q[j-1]
        return matrix(3,((a,b,QComplex(c*v[i]*v[k])) for a,b,i,k,c in adj))
    u=q[0]+q[1]
    return matrix(4,((a,b,QComplex(c,e)*(u[i]*u[k])) for a,b,i,k,c,e in fund))
def root_matrix(j):
    if j==0:return [[QComplex(2)]]
    if j<3:
        t=[bv.get((j-1,i),0) for i in range(3)]
        return matrix(3,((i,k,QComplex(2*t[i]*t[k]-int(i==k))) for i,k in product(range(3),repeat=2)))
    entries=[]
    for i,j in product(range(3),repeat=2):
        t=2*bv.get((0,i),0)*bv.get((1,j),0)
        if not t:continue
        for a,b,c,d in product(range(2),repeat=4):
            entries.append((2*a+c,2*b+d,imag.get((i,a,b),QComplex())*imag.get((j,c,d),QComplex())*t))
    return matrix(4,entries)

pairs=list(combinations_with_replacement(range(8),2))
@cache
def normalized_haar(a,b):
    x=Counter(a+b)
    return original_quaternion_haar_moment(tuple(x[j] for j in range(4)))*original_quaternion_haar_moment(tuple(x[j] for j in range(4,8)))
H={a:[(b,z) for b in pairs if (z:=normalized_haar(a,b))] for a in pairs}
def local_transfer(poly,r0,r1):
    out=defaultdict(QComplex)
    for key,coef in poly.terms:
        groups=defaultdict(list)
        for s in key:groups[s.index[0]].append(4*(s.index[2]=="R")+s.index[3])
        assert set(groups)=={r0,r1} and len(groups[r0])==len(groups[r1])==2
        a,b=(tuple(sorted(groups[r])) for r in (r0,r1))
        for x,z in H[b]:out[a,x]+=coef*z
    return {k:v for k,v in out.items() if v}
def join(a,b):
    rows=defaultdict(list)
    for (i,j),v in b.items():rows[i].append((j,v))
    c=defaultdict(QComplex)
    for (i,j),v in a.items():
        for k,w in rows[j]:c[i,k]+=v*w
    return {k:v for k,v in c.items() if v}

for sample in range(2):
    spatial=[]
    links={}
    for i,x in enumerate(vertices):
        k=directions[i]
        y=vertices[(i+1)%4]
        assert reg.step(x,k)[0]==y
        q=tuple(tuple(Polynomial.variable(Symbol("q",(x,0,chi,j))) for j in range(4)) for chi in ("L","R"))
        links[x,0]=original_spin4_link(*q)
        if sample:
            a=(points[(i+1)%6],points[(2*i+1)%6])
            b=(points[(2*i+2)%6],points[(i+3)%6])
        else:
            a=b=(points[0],points[0])
        links[x,k]=original_spin4_link(*a)
        links[reg.step(x,0)[0],k]=original_spin4_link(*b)
        spatial.append((a,b))
    transfers=[];support=[]
    for i,x in enumerate(vertices):
        y=vertices[(i+1)%4]
        f=literal_trace(original_plaquette(reg,x,0,directions[i],links))
        P=f*f
        support.append(len(P.terms))
        transfers.append(local_transfer(P,x,y))
    A=join(*transfers[:2]);B=join(*transfers[2:])
    direct=sum((n*B.get((j,i),QComplex()) for (i,j),n in A.items()),QComplex())
    channels=[]
    for j,d in enumerate((1,3,3,4)):
        root=transpose(root_matrix(j))
        factor=[multiply(root,dagger(repr_matrix(a,j))) for a,b in spatial]
        remote=[repr_matrix(b,j) for a,b in spatial][::-1]
        own_prod=multiply(multiply(factor[0],factor[1]),multiply(factor[2],factor[3]))
        opp_prod=multiply(multiply(remote[0],remote[1]),multiply(remote[2],remote[3]))
        channels.append(trace(own_prod)*trace(opp_prod)*F(1,d**4))
    assert sum(channels,QComplex())==direct
    assert direct==QComplex([F(155,9),F(10792,675)][sample])
    assert channels[0]==QComplex(16)
    if sample:assert direct-channels[0]==QComplex(F(-8,675))
    print("conditional directed square sample",sample,"root supports",support,"raw transfer pair rows",len(A),len(B),
          "channels",[(z.real,z.imag) for z in channels],"exact",direct.real)
