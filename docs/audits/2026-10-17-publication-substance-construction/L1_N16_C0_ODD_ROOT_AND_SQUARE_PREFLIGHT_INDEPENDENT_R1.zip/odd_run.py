from collections import Counter
from fractions import Fraction as F
from functools import cache
from itertools import permutations,product
from math import factorial,prod
from project import projection
from census import profile,occupancy,read,write,triples
from classify import coeff
from contract import value

prior="/private/tmp/l1-c0-multi-independent.8aMOEQWW"
rows=[tuple(map(int,r)) for r in read(prior+"/odd-unresolved.tsv")]
assert (len(rows),sum(w for a,b,w in rows))==(24,816)

@cache
def canonical(code,edges):
    m=occupancy(code)
    images=[]
    for perm in permutations(range(3)):
        image=[sum(((v>>k)&1)<<perm[k] for k in range(3)) for v in range(8)]
        labels=[triples.index(tuple(t[perm.index(i)] for i in range(3))) for t in m]
        for shift in range(8):
            moved=sum(n<<(6*(v^shift)) for v,n in zip(image,labels))
            updated=tuple(sorted((tuple(sorted((image[u]^shift,image[v]^shift))),chi) for (u,v),chi in edges))
            swapped=tuple((e,chi^1) for e,chi in updated)
            images.append((moved,min(updated,swapped)))
    return min(images)

owners=Counter();roster={}
for a,b,w in rows:
    graphs,forced,domain=projection(a,b,2)
    own=int(bool(graphs[1])); owners[own]+=1
    assert not graphs[1-own] and len(graphs[own])==4
    assert all(p==(1,1) for p in graphs[own].values())
    occupied=sorted(graphs[own])
    own_edges=profile((a,b)[own])[2];opp_edges=profile((a,b)[1-own])[2]
    assert all(sorted(own_edges[e])==[0,2] and tuple(sorted(opp_edges[e])) in ((0,4),(2,2)) for e in occupied)
    assert all(set(domain[own,v,k])=={(1,0),(0,1)} for u,w2,k in occupied for v in (u,w2))
    moments=profile(a)[1]+profile(b)[1]+forced
    original=[n for t in occupancy(a)+occupancy(b) for n in t if n]
    assert sorted(original)==sorted((*moments,*([1]*8)))
    f=F(prod(coeff(n,0,0) for n in moments),4**4*prod(factorial(n) for n in original))
    terms=Counter()
    for chi in product(range(2),repeat=4):
        spec=[tuple((e[:2],k+(0 if t==own else 2)) for e,k in zip(occupied,chi)) for t in range(2)]
        key=tuple(sorted(canonical(c,s) for c,s in zip((a,b),spec)))
        terms[key]+=f
    roster[a,b]=terms
assert owners=={0:4,1:20}
keys=sorted({k for t in roster.values() for pair in t for k in pair})
assert len(keys)==83 and sum(map(len,roster.values()))==117
print("odd geometry owners",dict(owners),"configurations",len(keys),"weighted terms",sum(map(len,roster.values())),flush=True)
data={k:value(*k) for k in keys}
out=[]
for a,b,w in rows:
    z=sum(f*data[x]*data[y] for (x,y),f in roster[a,b].items())
    assert z>0
    out.append((a,b,w,z))
assert out[0]==(37086699520,6212693790810,48,F(916073923391047265625,4611686018427387904))
subtotal=sum(w*z for a,b,w,z in out)
assert subtotal==F(5771684842675958076255,9007199254740992)
print("exact odd signed subtotal",len(out),sum(w for a,b,w,z in out),subtotal,flush=True)
write("odd-exact.tsv",out)
code=6212693790810;es=((0,4),(1,5),(2,6),(3,7));spec=tuple((e,0) for e in es)
z=value(code,spec,reverse=True)
wrong=value(code,spec,mutant=0)
swap=value(code,tuple((e,1) for e in es))
assert z==swap==F(7780827681,268435456) and wrong==0
print("reverse and direct chirality swap",z,swap,"one-site wedge omission",wrong)
