from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle
import sys

source, tag = sys.argv[1:3]
with Path(source).open('rb') as handle:
    checkpoint = pickle.load(handle)
factors = checkpoint['factors']
degree = Counter(wire for axes, _, _ in factors for wire in axes)
assert all(count == 2 for count in degree.values())
counts = []
for i, j in combinations(range(len(factors)), 2):
    left, right = factors[i], factors[j]
    shared = tuple(w for w in left[0] if w in right[0])
    if not shared:
        continue
    def histogram(factor):
        indices = [factor[0].index(w) for w in shared]
        return Counter(tuple(row[k] for k in indices) for row in factor[1])
    a, b = histogram(left), histogram(right)
    weighted = {key: n*b[key] for key,n in a.items() if key in b}
    counts.append((sum(weighted.values()),i,j,shared,weighted))
matched,i,j,shared,weighted = min(counts, key=lambda item:item[:3])
print(tag, 'minimum join',matched,'pair',i,j,flush=True)
plans=[]
for p in range(len(shared)):
    subtotal=Counter()
    for key,n in weighted.items():
        subtotal[key[p]]+=n
    if 1<len(subtotal)<=4:
        plans.append((max(subtotal.values()),len(subtotal),p,subtotal))
assert plans
_,_,position,subtotal=min(plans, key=lambda item:item[:3])
wire=shared[position]
print('cut',repr(wire),'products by value',dict(subtotal),flush=True)
for index,value in enumerate(sorted(subtotal)):
    conditioned=[]
    for axes, rows, denominator in factors:
        if wire not in axes:
            conditioned.append((axes,rows,denominator))
            continue
        p=axes.index(wire)
        conditioned.append((axes[:p]+axes[p+1:],{r[:p]+r[p+1:]:z for r,z in rows.items() if r[p]==value},denominator))
    child={**checkpoint,'factors':conditioned,'conditioning':[*checkpoint['conditioning'],(wire,value)]}
    with Path(f'{tag}-{index}.pkl').open('xb') as handle:
        pickle.dump(child,handle,protocol=5)
    print(index,repr(value),sum(len(r) for _,r,_ in conditioned),flush=True)
