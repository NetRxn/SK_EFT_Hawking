from ast import literal_eval
from collections import Counter
from pathlib import Path
import pickle

root = Path('/private/tmp/l1-tuple-separators.OxRDWT')
previous = Path('/private/tmp/l1-dense-resume.bbZW6V')

def load(path):
    return pickle.loads(path.read_bytes())

def audit(source, pair, fixed_axes, plan, children):
    parent = load(source)
    factors = parent['factors']
    degree = Counter(w for axes, _, _ in factors for w in axes)
    assert set(degree.values()) == {2}
    left, right = (factors[i] for i in pair)
    common = set(left[0]).intersection(right[0])
    ordered = tuple(sorted(common))
    buckets = Counter(tuple(dict(zip(right[0], row))[a] for a in ordered) for row in right[1])
    spectrum = Counter()
    for row in left[1]:
        assignment = dict(zip(left[0], row))
        multiplicity = buckets[tuple(assignment[a] for a in ordered)]
        if multiplicity:
            spectrum[tuple(assignment[a] for a in fixed_axes)] += multiplicity
    assert spectrum == plan
    for coordinate, path in children.items():
        fixed = dict(zip(fixed_axes, coordinate))
        child = load(path)
        assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
        assert child['label_partition'] == parent['label_partition']
        for (axes, rows, denominator), (small_axes, small_rows, small_denominator) in zip(factors, child['factors'], strict=True):
            assert denominator == small_denominator
            assert tuple(w for w in axes if w not in fixed) == small_axes
            expected = {row: value for row, value in rows.items()
                        if all(row[p] == fixed[w] for p,w in enumerate(axes) if w in fixed)}
            recovered = {}
            for row,value in small_rows.items():
                assignment = dict(zip(small_axes,row))
                assignment.update(fixed)
                recovered[tuple(assignment[w] for w in axes)] = value
            assert recovered == expected
    print(source.name, 'pair',pair,'cuts',fixed_axes,'cases',len(spectrum),
          'sum/max products',sum(spectrum.values()),max(spectrum.values()),'children audited',list(children),flush=True)

for tag, base in (('tuple0','0b'), ('tuple1','1a')):
    lines = (root/f'{tag}-plan.out').read_text().splitlines()
    pair = tuple(map(int,lines[0].split()[-2:]))
    cut, counts = lines[1].removeprefix('cut ').split(' products by value ')
    counts = {(x,): n for x,n in literal_eval(counts).items()}
    audit(previous/f'join-cap-dense-label-{base}-reduced.pkl', pair, (literal_eval(cut),), counts,
          {key: root/f'{tag}-{i}.pkl' for i,key in enumerate(sorted(counts))})

source = root/'row-cap-physical-slice-dense-label-tuple0-0-reduced.pkl'
axes, raw = literal_eval((root/'pilot.roster').read_text())
counts = dict(raw)
pilot = min(counts,key=lambda x:(counts[x],x))
largest = max(counts,key=lambda x:(counts[x],x))
assert largest == (68, (2,))
audit(source,load(source)['rejected_pair'],axes,counts,{pilot:root/'pilot.pkl',largest:root/'pilot-max.pkl'})
assert pilot == (18, (3,))
print('PASS exact partition supports, multiplicities, selected factor coefficients and original conditioning')
