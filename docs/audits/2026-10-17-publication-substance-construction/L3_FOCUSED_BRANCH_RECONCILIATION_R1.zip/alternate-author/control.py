from pathlib import Path
import subprocess
import sys
from src.core.citations import CITATION_REGISTRY as registry

base = Path(sys.argv[1])
j = registry["JacobsonVolovik1998JETP"]
assert (j["doi"], j["arxiv"], j["volume"], j["page"]) == (
    "10.1134/1.567808", "gr-qc/9811014", 68, "874-880")
assert registry["JacobsonVolovik1998"]["doi"] == "10.1103/PhysRevD.58.064021"
assert registry["JacobsonKoike2002"]["arxiv"] == "cond-mat/0205174"
pdf = subprocess.check_output(
    ["pdftotext", "-f", "1", "-l", "1", str(base / j["primary_source_path"]), "-"],
    text=True)
assert "arXiv:gr-qc/9811014v1" in pdf
bal = (base / "Lit-Search/Phase-6a/primary-sources/Balbinot2005PRD.source/acusticpap.tex"
       ).read_text(encoding="latin-1")
bib = bal.split(r"\bibitem{jacobson}", 1)[1].split(r"\bibitem", 1)[0]
assert "874 (1998)" in bib and "cond-mat/0205174" in bib and "064021" not in bib
doc = Path(j["used_in"][0]).read_text()
assert "JETP Lett.* **68**, 874 (1998)" in doc
assert "Jacobson–Koike cond-mat/0205174" in doc
print("Distinct registry identities, held full text, Balbinot source and existing Lean attribution all match.")
