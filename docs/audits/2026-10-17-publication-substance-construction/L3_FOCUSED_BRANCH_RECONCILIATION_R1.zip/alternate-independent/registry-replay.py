import ast, sys
from pathlib import Path
a,b,lit = (Path(x) for x in sys.argv[1:])
reg = 'src/core/citations.py'
def data(root):
    tree=ast.parse((root/reg).read_text())
    reg_node=next(x.value for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CITATION_REGISTRY' for t in x.targets))
    keys=[ast.literal_eval(k) for k in reg_node.keys]
    assert len(keys)==len(set(keys))
    return dict(zip(keys,reg_node.values))
old,new=data(a),data(b)
k='JacobsonVolovik1998JETP'
assert set(new)-set(old)=={k} and len(new)==len(old)+1
assert all(ast.dump(new[key])==ast.dump(value) for key,value in old.items())
jetp=ast.literal_eval(new[k])
prd=ast.literal_eval(old['JacobsonVolovik1998'])
koike=ast.literal_eval(old['JacobsonKoike2002'])
assert [jetp[key] for key in ['journal','volume','page','year','doi','arxiv']]==['JETP Lett.',68,'874-880',1998,'10.1134/1.567808','gr-qc/9811014']
assert jetp["title"]=="Effective spacetime and Hawking radiation from a moving domain wall in a thin film of 3He-A"
assert jetp["doi_verified"] is None
assert jetp["primary_source_path"].endswith("JacobsonVolovik1998JETP-arXiv-v1.pdf")
assert "held full text is arXiv v1" in jetp["notes"]
assert prd['doi']=='10.1103/PhysRevD.58.064021'
assert koike['arxiv']=='cond-mat/0205174'
lean=Path('lean/SKEFTHawking/BHThermodynamicsFourLaws.lean')
assert jetp['used_in']==[str(lean)]
assert (lit/Path(jetp['primary_source_path']).relative_to('Lit-Search')).is_file()
assert (a/lean).read_bytes()==(b/lean).read_bytes()
text=(b/lean).read_text()
for s in ('Jacobson–Volovik, *JETP Lett.* **68**, 874 (1998) together with','Jacobson–Koike cond-mat/0205174','**not** resolve to PRD 58, 064021'):
    assert s in text
print(f'{len(old)} original registry entries unchanged; one distinct JETP key; held path resolves')
print('Existing Lean citation correctly names both thin-film references and excludes the bulk PRD paper')
