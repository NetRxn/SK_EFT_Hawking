# Author evidence awaiting independent replay

The 352 scalar and 160 reduced-isolated results are frozen. The remaining 24 odd-root reduced-isolated cases and full temporal block stay open.
