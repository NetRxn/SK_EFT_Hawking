from collections import Counter
from fractions import Fraction as F
from math import factorial,prod
from pathlib import Path
from multi import todo
from projection_full import compute
from scalar import canonical
from family import co,edges
from network import network
rows=[]
for r in todo:
    result=compute(r)
    if result is None or any(result[0]):continue
    a,b,w,A,B,ca,cb,la,lb=r
    assert all(n%2==0 for row in A+B for n in row)
    c=F(prod(co[n][0,0] for row in A+B for n in row),prod(factorial(n) for row in A+B for n in row))
    rows.append((a,b,w,canonical(a),canonical(b),c))
assert len(rows)==352 and sum(r[2] for r in rows)==27696
keys=sorted({k for r in rows for k in r[3:5]})
print("signed scalar exact family candidates",len(rows),"canonical coframe codes",len(keys),flush=True)
data={};refused={}
for k in keys:
    try:
        z=network(k)
        data[k]=z
        print("scalar signed layer",k,z,flush=True)
    except RuntimeError as e:
        refused[k]=str(e)
        print("scalar layer refusal",k,e,flush=True)
out=[];not_done=[]
for a,b,w,u,v,f in rows:
    if u not in data or v not in data:not_done.append((a,b,w));continue
    z=f*data[u]*data[v]
    out.append((a,b,w,z))
print("signed exact scalar orbits",len(out),"labeled",sum(r[2] for r in out),
      "signs",Counter((x>0)-(x<0) for a,b,w,x in out))
print("scalar refusal orbits",len(not_done),"labeled",sum(r[2] for r in not_done))
print("scalar weighted subtotal",sum(w*x for a,b,w,x in out))
Path("scalar-exact.tsv").write_text("".join(chr(9).join(map(str,row))+chr(10) for row in out))
Path("scalar-refused.tsv").write_text("".join(chr(9).join(map(str,row))+chr(10) for row in not_done))
