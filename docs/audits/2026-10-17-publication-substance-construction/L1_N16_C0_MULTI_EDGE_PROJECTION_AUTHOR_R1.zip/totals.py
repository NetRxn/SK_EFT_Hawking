from collections import Counter
from fractions import Fraction as F
from pathlib import Path
from multi import todo
from red_census import rows
def read(p):return {(int(a),int(b)):(int(w),F(z)) for a,b,w,z in (
    line.split() for line in Path(p).read_text().splitlines())}
a=read("scalar-exact.tsv");b=read("reduced-exact.tsv")
assert not set(a)&set(b)
known=a|b
print("new signed totals",len(known),sum(w for w,z in known.values()))
print("new weighted subtotal",sum(w*z for w,z in known.values()))
left={r[:2]:r[2] for r in todo if r[:2] not in known}
assert len(left)==10482 and sum(left.values())==904635
print("remaining temporal block",len(left),sum(left.values()))
odd=[r[:3] for r,s,code in rows if code=="odd roots"]
assert len(odd)==24 and sum(r[2] for r in odd)==816
assert all((a,b) in left and left[a,b]==w for a,b,w in odd)
print("reduced-isolated odd-root unresolved",len(odd),sum(r[2] for r in odd))
Path("reduced-odd-unresolved.tsv").write_text("".join(chr(9).join(map(str,r))+chr(10) for r in odd))
