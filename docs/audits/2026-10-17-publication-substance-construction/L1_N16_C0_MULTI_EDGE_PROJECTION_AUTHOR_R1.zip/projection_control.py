from collections import Counter
from fractions import Fraction as F
from itertools import combinations_with_replacement,product
from core import residual, comps
from multi import todo
from projection import compute as coarse
from projection_full import compute, LABELS, vals
from src.core.formulas import original_quaternion_haar_moment

matched=0;removed=0;layers=0;types=Counter();exact_zero=[];forced=Counter()
for r in todo:
    x=coarse(r);y=compute(r)
    assert (x is None)==(y is None)
    if y is None:continue
    assert x[0]==y[0]
    matched+=1
    count=sum(bool(n) for c in r[5:7] for pair in c.values() for n in pair)-sum(
        bool(n) for c in y[0] for pair in c.values() for n in pair)
    assert count>=0
    if count:removed+=1
    forced[count]+=1
    for c in y[0]:
        for d in comps(c):types[len(d)]+=1
print("total and separate chiral support graphs agree on",matched,"representatives")
print("representatives with at least one additional forced scalar root",removed)
print("forced-root-count distribution",sorted(forced.items()))
print("residual individual temporal components by edge count",types.most_common())

p=next(r for r in residual if r[:2]==(166856593410,8960795485785))
_,domains,_=compute(p)
for t,v in product(range(2),(4,5)):
    active={LABELS[i] for i in vals(domains[24*t+3*v])}
    assert (2,0) in active and (0,2) in active
print("prior nontrivial overlapping pilot spin-one channels remain allowed")

def moment(items):
    return original_quaternion_haar_moment(tuple(items.count(j) for j in range(4)))
R=((0,1),(1,-1),(2,-1),(3,1))
def M(seq):
    return sum(s*moment((*seq,j,j)) for j,s in R)
assert M(())==0 and all(M((k,))==0 for k in range(4))
assert M((3,3))==F(1,12)
for d in range(4):
    for a in range(d+1):
        for x,y in product(combinations_with_replacement(range(4),a),
                           combinations_with_replacement(range(4),d-a)):
            assert M(x)*M(y)==0
assert M((3,3))**2==F(1,144)
print("source Haar spin-one spatial edge moments vanish below degree four",
      "and a degree-four control gives",F(1,144))
