# Multi-edge temporal-core representation projection and signed reductions

The primary packet `l1-c0-multi-edge-author-r1.json` checked fresh
at `27012c18fa374e8341e124b510abbedeedb18d29`. This scratch work
uses the previously frozen degree, coframe-Q3, residual-core,
isolated-edge and dual-overlap packages read-only. Their manifests
reverified. The preceding dual-overlap digest is
`37756b9d05aab9e82d62e25f6489314809848e1302f2b834ba3335daedc75c76`.
Prior acceptance status is distinct from this result's review.
No tracked file, prior artifact, notebook or Lean slot was changed.

Starting from the 10,994 unresolved temporal A-only/B-only orbits,
representation constraints force all curvature channels to scalar
in **352** orbits. They reduce another 184 to isolated temporal
edges, of which **160** even-root cases admit exact signed
contraction and **24** odd-root cases remain open. All 512 newly
evaluated orbit representatives are positive. The exact signed
values, multiplicities, adverse controls and residual accounting
are included below. The full temporal block and full c0 remain open.

## Residual temporal geometry

The input is the complete 11,923-orbit degree-block table minus
all previously signed and exact-zero dispositions. This leaves
10,994 orbits and 947,355 labeled coarse survivors. The existing
single-root temporal leaf rule is applied independently at each
connector, retaining every leaf's local coframe moment.

The most common individual residual temporal connected components
before the additional projection are four-cycles with 6,289
appearances, isolated edges with 5,460 appearances, connected
eight-vertex ten-edge components with 3,757 appearances, and
two-edge paths with 3,718 appearances. The largest paired shape
class has 456 orbits. There are 2,252 all-even occupancies, with
188,928 labeled occupations. No remaining orbit has its entire
residual curvature anchor set disjoint from all coframe edges.
`multi.out` contains the paired shape census.

## Exact representation support projection

Expand each rooted degree-m curvature factor in matrix
coefficients of its actual Spin(4) holonomy. A label
(p/2,q/2) obeys p+q≤m and p+q=m modulo two, since each
quaternion coordinate is a matrix coefficient of one
fundamental representation. The coefficients of that
expansion retain the original even coframe polynomial at the
root. Every rooted holonomy matrix has a single representation
label on all of its four actual anchors.

There are two necessary local Haar constraints:

1. At one temporal anchor, each chirality must have an invariant
   tensor in its product of incident spins. For doubled spins
   n_i this requires an even sum and 2 max n_i ≤ sum n_i.
   Dualizing a matrix does not change these representation
   requirements. Both original temporal connectors retain their
   separate constraints.
2. At a spatial anchor based at vertex v in direction k, the two
   connector labels on the curvature rooted there are
   (p_A,q_A) and (p_B,q_B), with the scalar for an absent root.
   A polynomial of degree h in a spatial anchor's coframe
   coordinates can supply at most h total doubled spin.
   Clebsch–Gordan decomposition of the two curvature
   representations therefore requires at least
   |p_A−p_B|+|q_A−q_B| such coframe occurrences at this anchor.
   Sum these lower bounds for the two independent directed
   anchors of an undirected edge. The result must fit the
   coframe edge degree in **both** spatial layers. The two
   connector kernels use the same spatial variables.

Propagate the label domains by deleting any label that has
no witness in one necessary local constraint using the
current domains. Every global nonzero term has local witnesses
at the initial step, so induction preserves its label
assignment through all deletions. This is a sound restriction,
without claiming a sufficient test for nonzero source tensors.
A label forced to (0,0) can be projected exactly before doing
the remaining integrals. Its complete coefficient is the
constant Haar projection of the rooted polynomial. In the
even powers used here it is 2W for degree two and 10W²
for degree four. Every such factor retains its original
coframe and original m! divisor. No rooted factor is dropped.

The weaker total-spin relaxation uses s=p+q, |s_A−s_B|
in the spatial bound and the triangle constraint on s.
The separate chiral calculation gives the same reduced
nontrivial-support graphs for all 10,994 input representatives.
It terminates after at most six propagation passes. The
projection forces at least one additional scalar root in
**6,787** representatives. No orbit was declared zero by
this projection. There are 352 fully scalar graphs with
27,696 labels and 184 nonempty isolated graphs with 15,840
labels. These are exact consequences of the necessary
domain eliminations, not signed estimates. Other terms
inside the remaining graphs can still vanish.

The local Haar control uses the canonical quaternion moment
function. For a spin-one diagonal coefficient it verifies
vanishing at total coframe degree below four on two distinct
spatial anchors and an exact degree-four witness 1/144.
The previous genuine overlapping dual-core control retains
both of its spin-one channels under the new domain tests.
These controls distinguish an exact support elimination from
an assumption that shared spatial corrections may be ignored.

## Signed contraction of the complete even admissions

For the fully scalar family the original coframe graph
contains only total edge degrees two and four, including
mixed-owner (2,2) edges. Original coframe edge tensors,
site-mask inversion signs and mixed-owner moments are
reused from the previous exact source package. All original
curvature roots have been projected exactly to local scalar
moments by the constraints above. After this elimination,
the two spatial layers' remaining coframe graphs have
disjoint links. Each layer's rooted W factors are symmetric
in the coframe directions, so spatial translations and
axis permutations give 20 canonical cached layer contractions.

All 20 signed layers completed. All **352** full representative
values are positive. With original factorials and one orbit
weight per representative, the exact subtotal is

```
843344393264084456134970038551 / 288230376151711744.
```

Of the 184 projections to isolated edges, 160 have even
root powers and the previously measured degree-two/four
coframe support. They cover 15,024 labels. Every surviving
isolated edge has both roots present. All forced scalar
roots are carried into the dispatcher as separate local
moment factors, including when two roots are forced at
the same temporal edge. The original two-connector
isolated Schur formulas then evaluate the reduced
graph exactly. Restoring the full representation
domain on surviving roots does not reintroduce any
forbidden terms, since those terms remain killed by the
same Haar support constraints. This is a different
schedule for the original geometric occupation.

Six of these even cases have nontrivial dual overlap,
and the rest use the exact scalar or disjoint shared
character contraction. The reduced-isolated family
requires 21 canonical layer configurations. All
completed and all **160** representative values are
positive. The exact weighted subtotal is

```
860014394035274407282409403 / 562949953421312.
```

The coframe sewing preflights exact shared-key joins
and retains the original signs and Gaussian integer
coefficients. The measured maxima across these
families are 19,968 local complement trials,
64,512 rows in any populated table, 593,920 products
in an ordinary matched join, and 1,114,112 terminal
triangle lookup trials. The largest terminal resident
input width is 83,712 rows. The source caps are two
million products in a binary join, 150,000 rows,
four million terminal triangle lookups and 384 bits
in Gaussian-integer bounds. No admitted signed orbit
refused. The scalar and reduced-isolated runs use
about 102 MB and 103 MB peak RSS, respectively.

## Exact nontrivial shared-Haar pilot and adverse signs

The originally multi-edge representative
`(174372786201,41302710654530)`, orbit size 96,
reduces to a (2,2) temporal edge on (2,3) in both
connectors. Its A spatial edge has two coframes
and its B spatial edge has none. The nontrivial
spin-one channels therefore use the original
one-layer decorated Haar tensor with the other
layer's exact Schur trace. The original
representative, including factorials and all
forced scalar moments, is

```
8604807324297538165875 / 281474976710656.
```

The scalar-only shortcut gives
1075580423607158602875/35184372088832 instead.
The retained shared-anchor correction is nonzero.
The weighted contribution of the complete 96-member
orbit is 25814421972892614497625/8796093022208.

A reverse contraction verifies the signed active
layer channel 38840955975/8388608. Omitting the
inherited wedge sign at just one active vertex
changes it to 7719180525/8388608. The scalar
shortcut and the one-vertex mutation are adverse
controls, not changes to the original contraction.

## Residual boundary

Together the two new families have **512** exact
positive orbits covering **42,720** occupations.
Their combined weighted subtotal is

```
1283671763010144952663563652887 / 288230376151711744.
```

The complete temporal A-only/B-only block now has
**10,482 unresolved orbits** and **904,635** labeled
coarse survivors. Of these, the **24** odd-root
reduced-isolated cases covering **816** occupations
are separately retained in `reduced-odd-unresolved.tsv`.
Their remaining cores have (1,1) rooted powers.
The coframe edges have even total degree, with
odd endpoint loads on some edges. Their signed
contraction needs fundamental-representation
root factors and new odd-owner edge tensors,
which the current even-root dispatcher does not
admit. This is an exact scope boundary, not a
claim that a larger width would solve them. `remaining.out` gives their concrete
endpoint loads and the unresolved multi-edge
component census. The large surviving multi-edge
cores need a new connected temporal tensor
contraction with shared spatial Haar. The full
signed widths of those kernels are unmeasured.

The signed subtotal and projection counts do not
determine the remaining temporal block or the
full c0. Independent replay is required for this
scratch result.

## Reproduction

Run `multi.py`, `projection.py`, `projection_full.py`,
`signed_scalar.py`, `red_census.py`, `signed_reduced.py`,
`adverse.py`, `totals.py` and `remaining.py` from the
package. The signed Python routines reuse the
frozen source tensor and dispatch inputs bound
by the prior manifests. The source-backed
`projection_control.py` uses the exact primary
checkout on PYTHONPATH, its existing venv Python
and PYTHONDONTWRITEBYTECODE=1. `measure.py` records
timings and peak RSS. The exact signed values
and separate unresolved tables are retained.
