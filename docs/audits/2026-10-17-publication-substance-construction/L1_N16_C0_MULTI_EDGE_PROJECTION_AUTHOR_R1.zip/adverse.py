from fractions import Fraction as F
from network import network
key=(174372786201,(((2,3),0),))
value=network(*key,reverse=True)
wrong=network(*key,mutant=3)
assert value==F(38840955975,8388608) and value!=wrong
print("projected-pilot signed layer alternative order",value,"one vertex wedge omission",wrong)
