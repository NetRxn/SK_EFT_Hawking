from collections import Counter
from pathlib import Path
from core import comps,shape
from family import edges
from multi import todo
from projection_full import compute
done={tuple(map(int,line.split()[:2])) for p in ('scalar-exact.tsv','reduced-exact.tsv')
      for line in Path(p).read_text().splitlines()}
odd={tuple(map(int,line.split()[:2])) for line in Path('reduced-odd-unresolved.tsv').read_text().splitlines()}
odd_shapes=Counter();odd_signed_edges=Counter();comp=Counter();largest=Counter()
for r in todo:
    if r[:2] in done:continue
    core,domains,it=compute(r)
    c=[shape(d) for C in core for d in comps(C)]
    comp.update(c);largest[max(x[1] for x in c)]+=1
    if r[:2] in odd:
        odd_shapes[tuple(sorted(tuple(sorted(v)) for C in core for v in C.values()))]+=1
        for m in r[3:5]:
            odd_signed_edges.update(tuple(sorted(v)) for v in edges(m).values() if any(x%2 for x in v))
print("largest unresolved core-edge count per orbit",sorted(largest.items()))
print("unresolved individual core shapes",comp.most_common(10))
print("odd reduced-isolated core multiplicity patterns",odd_shapes)
print("odd endpoint coframe loads (total degree may be even)",odd_signed_edges)
