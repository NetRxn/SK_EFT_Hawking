from collections import Counter
from fractions import Fraction as F
from pathlib import Path
from red_census import rows
from dispatch import factors
from network import network

def lifted(r,cur):
    a,b,w,A,B,ca,cb,la,lb=r
    aug=[]
    for old,new,leaves in zip((ca,cb),cur,(la,lb)):
        extra=list(leaves)
        for e,p in old.items():
            q=new.get(e,(0,0))
            for i,(x,y) in enumerate(zip(p,q)):
                assert y in (0,x)
                if x and not y:
                    assert x%2==0
                    extra.append((e,x,0) if i==0 else (e,0,x))
        aug.append(extra)
    assert all(min(x)>0 for C in cur for x in C.values())
    return a,b,w,A,B,*cur,*aug

cases=[lifted(r,s) for r,s,key in rows if key=='admit']
assert len(cases)==160 and sum(r[2] for r in cases)==15024
rosters={r[:2]:factors(r) for r in cases}
configs=sorted({x for terms in rosters.values() for pair in terms for x in pair},
               key=lambda x:(len(x[1]),sum(j==2 for e,j in x[1]),x))
print("reduced isolated canonical configurations",len(configs),"cache roles",
      Counter(len(s) for _,s in configs),"weighted terms",sum(map(len,rosters.values())),flush=True)
values={};refused={}
for k in configs:
    try:
        values[k]=network(*k)
        print("reduced layer",k,values[k],flush=True)
    except RuntimeError as e:
        refused[k]=str(e)
        print("reduced layer refusal",k,e,flush=True)
pilot=next(r for r in cases if r[:2]==(174372786201,41302710654530))
out=[];unknown=[]
for r in cases:
    a,b,w=r[:3]
    terms=rosters[a,b]
    if any(x not in values for p in terms for x in p):
        unknown.append((a,b,w));continue
    z=sum(c*values[x]*values[y] for (x,y),c in terms.items())
    out.append((a,b,w,z))
    if r is pilot:
        old=sum(c*values[x]*values[y] for (x,y),c in factors(r,True).items())
        assert z!=old
        print("signed nontrivial projected multi-edge pilot",a,b,w,z,
              "scalar-only shortcut",old,"orbit weighted",w*z,flush=True)
print("reduced isolated layer count signed/refused",len(values),len(refused))
print("reduced isolated signed",len(out),sum(r[2] for r in out),
      "signs",Counter((z>0)-(z<0) for a,b,w,z in out))
print("reduced isolated refusal",len(unknown),sum(r[2] for r in unknown))
print("reduced isolated subtotal",sum(w*z for a,b,w,z in out))
Path("reduced-exact.tsv").write_text("".join(chr(9).join(map(str,r))+chr(10) for r in out))
Path("reduced-refused.tsv").write_text("".join(chr(9).join(map(str,r))+chr(10) for r in unknown))
