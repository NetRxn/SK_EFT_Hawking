# L1 original dense signed geometric cover

The independent ACTUAL review archive contains the exact frozen author candidate, independent original-source and support replays, and exact intake retally. The ROOT roster archive separately rebuilds the support graph from the accepted independent census and verifies the workload proxy. It reports the earlier seven-group credit state; the ACTUAL intake retally applies the later accepted pilot pairs and leaves 1,047 representatives.

Read the candidacy and reviews at their declared scope. The complete signed dense contribution and the original physical publication obligations are still open. This evidence justifies computing the same original dense contribution from the selected whole groups using weights 192 on the selected bipartite side and 96 on each loop component.

Verify the two outer member digests with `shasum -a 256 -c SHA256SUMS`. Extract each nested ZIP, verify its manifest, and follow its replay instructions. The literal source and accepted independent archives are pinned by the included receipts.
