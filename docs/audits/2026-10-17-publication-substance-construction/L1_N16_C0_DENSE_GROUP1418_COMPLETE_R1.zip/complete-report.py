"""Write the frozen scalar and measured comparisons into the review."""
from csv import DictReader
from pathlib import Path
from re import M, search

f=Path('REVIEW.md')
label='## Exact arithmetic and measured comparisons'
s=f.read_text().split(label,1)[0]+label+'\n'
raw=(Path('retally.out')).read_text()
sr,den=search(r'^raw Gaussian sum (-?\d+) 0 factor denominator (\d+)',raw,M).groups()
value=search(r'^physical weighted (-?\d+/\d+) 0',raw,M)[1]
prep,guard,cont,terminal,total=search(r'^author measured seconds ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)',raw,M).groups()
wall=search(r'^author sum of solve walls plus shared preparation ([\d.]+)',raw,M)[1]
ip,ig,ic,it=search(r'^independent measured preparation/native/retained pass sums ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)',raw,M).groups()
iw=search(r'^independent sum of preparation, native and continuation walls ([\d.]+)',raw,M)[1]
assert terminal=='0.0'
with Path('measured-comparisons.tsv').open() as src:
    records={int(r['group']):r for r in DictReader(src,delimiter='\t')}
row=records[1418]
assert row['author_measured_component_sum_s']==total
ranges=row['native_accepted_products'],row['continuation_accepted_products'],row['continuation_refused_visits']
reference=[records[g]['author_measured_component_sum_s'] for g in (1284,183,189)]
s+=f'''
The exact raw Gaussian sum is ({sr}, 0) at inherited factor denominator
{den}. Applying the original physical divisor 16 × 4^64 and the cover
coefficient 192 gives **{value} + 0i**.

All six native caps, 15 retained passes and 18 continuation row refusals
were replayed. Accepted native joins visited {int(ranges[0]):,} products.
Retained continuation joins visited {int(ranges[1]):,} products and their
refused attempts visited {int(ranges[2]):,}. These counts have separate
columns from the independent preparation's two-sweep input-row visits.
The measured components sum to {total} author seconds
({prep} preparation, {guard} guarded work, {cont} continuation). The sum
of author solve walls plus shared preparation is {wall} seconds.
The independent preparation/native/retained-stage components are
{ip}, {ig} and {ic} seconds and sum to {it}. The independent sum of
preparation, native and full continuation walls is {iw} seconds.
Both wall sums add separate label measurements, so concurrent lane time
is outside that scope. Neither route needed a separate terminal job.

The same work convention gives {reference[0]}, {reference[1]} and
{reference[2]} seconds for previously reviewed six-live Groups 1284, 183
and 189. Their separate terminal costs, when present, are recorded in
measured-comparisons.tsv. The path here uses the same original score,
guards, signed quotient and retained recipe. These are scoped group
measurements. The comparison leaves component 14's unfinished groups
and the complete-profile runtime open.

## Reproduction

Verify the relative archive manifest and the six original operand
manifests. The large numerical family files and exact author pickles
are checksum-bound external operands. The commands below regenerate
the original support, complete preparation, all native and retained
signed replays, and both arithmetic and cost ledgers.

    python3 -B input-custody.py /path/to/publication-checkpoint /path/to/author-base
    python3 -B originals.py /path/to/publication-checkpoint
    python3 -B reduce.py 1418
    bash replay-label.sh 0 3 scalar author-order
    bash replay-label.sh 1 3 scalar author-order
    bash replay-label.sh 2 2 scalar author-order
    bash replay-label.sh 3 2 scalar author-order
    bash replay-label.sh 4 2 scalar author-order
    bash replay-label.sh 6 3 scalar author-order
    python3 -B retally.py /path/to/publication-checkpoint
    python3 -B compare-cost.py /path/to/publication-checkpoint > measured-comparisons.tsv

The scripts default to the original pilot author tree. Set
L1_GROUP1418_AUTHOR_BASE and L1_GROUP1418_AUTHOR_ROOT to the bound
author-base and its cached-original-roster directory if relocated.
The local original-roster.txt, prepared-roster.tsv, ordinal-roster.tsv
and accepted-result.json are the regenerated Group 1418 preparation
outputs. The relative archive manifest and all receipt files are
provided separately from the external operands.
'''
f.write_text(s.replace("author's committed input layout","author's frozen input layout"))
