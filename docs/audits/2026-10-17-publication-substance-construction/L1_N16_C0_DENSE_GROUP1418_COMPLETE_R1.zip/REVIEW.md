# Independent complete signed Group 1418 review

Group 1418 belongs to the accepted selected side of geometric component 14.
Its original gamma3 partner is Group 2732. The signed cover coefficient is
192 from occupation weight 48, gamma3 multiplicity two and the geometric side
multiplicity two. The two extra multiplicities are already included in 192.

The work-start continuity packet checked fresh at
8543061633b64e2a738c0497ccb3c417ce5aabab. The replay reads the accepted
original factor and cut archives at this checkpoint, verifies all 88
compiled numerical family files, and independently enumerates the 30,976
full label states from all 740 local relations. Group 1418's exact cut
selects eight original completions and 252 eligible source blocks. All
oriented source tables use the original denominator product
12003621991652557120041733255593984.

## Exact preparation and signed work

A fresh independent 88-factor preparation reduced 1,981,325 signed rows
to 516,282 and then 447,389 in the existing two sweeps. The two sweeps
visited 16,893,870 input rows. The replay retains explicit original L
boundaries, Gaussian coefficients and degree-two physical incidences.
All 88 prepared tables match the author frontier pinned at SHA-256
96fa76b621113c2ceed88e8ad049ceeaba91dede4136644c8822ee96ca96e8ad.
The original ordinal cut and selected block roster also match the
author's frozen input layout. Original ordinals 5 and 7 each have seven
empty prepared restrictions and give exact zero. Ordinals 0, 1, 2, 3, 4
and 6 have signed terminal values.

Every live ordinal's native replay inverse-lifts the signed selected
rows to the same prepared parent and reconstructs the guarded checkpoint
on the author pair. The complete continuation replays validate each
inverse signed split, Gaussian quotient, necessary peer projection
and exact retained coefficient table, retaining the original row
and product budgets. Original traversal order independently verifies
the cap's transient row count, author refusal visits and available
supported-product visits. All six terminals are empty-axis scalars.

## Exact arithmetic and measured comparisons

The exact raw Gaussian sum is (-261710847670839924272448017222515888075127643936123905472724992, 0) at inherited factor denominator
12003621991652557120041733255593984. Applying the original physical divisor 16 × 4^64 and the cover
coefficient 192 gives **-31937485184424189101211543/41538374868278621028243970633760768 + 0i**.

All six native caps, 15 retained passes and 18 continuation row refusals
were replayed. Accepted native joins visited 23,554,228 products.
Retained continuation joins visited 85,500,548 products and their
refused attempts visited 23,110,745. These counts have separate
columns from the independent preparation's two-sweep input-row visits.
The measured components sum to 437.336713 author seconds
(23.69 preparation, 134.499609 guarded work, 279.147104 continuation). The sum
of author solve walls plus shared preparation is 449.63 seconds.
The independent preparation/native/retained-stage components are
23.713185, 160.277636 and 307.071051 seconds and sum to 491.061872. The independent sum of
preparation, native and full continuation walls is 495.929269 seconds.
Both wall sums add separate label measurements, so concurrent lane time
is outside that scope. Neither route needed a separate terminal job.

The same work convention gives 263.86166, 637.378503 and
467.891059 seconds for previously reviewed six-live Groups 1284, 183
and 189. Their separate terminal costs, when present, are recorded in
measured-comparisons.tsv. The path here uses the same original score,
guards, signed quotient and retained recipe. These are scoped group
measurements. The comparison leaves component 14's unfinished groups
and the complete-profile runtime open.

## Reproduction

Verify the relative archive manifest and the six original operand
manifests. The large numerical family files and exact author pickles
are checksum-bound external operands. The commands below regenerate
the original support, complete preparation, all native and retained
signed replays, and both arithmetic and cost ledgers.

    python3 -B input-custody.py /path/to/publication-checkpoint /path/to/author-base
    python3 -B originals.py /path/to/publication-checkpoint
    python3 -B reduce.py 1418
    bash replay-label.sh 0 3 scalar author-order
    bash replay-label.sh 1 3 scalar author-order
    bash replay-label.sh 2 2 scalar author-order
    bash replay-label.sh 3 2 scalar author-order
    bash replay-label.sh 4 2 scalar author-order
    bash replay-label.sh 6 3 scalar author-order
    python3 -B retally.py /path/to/publication-checkpoint
    python3 -B compare-cost.py /path/to/publication-checkpoint > measured-comparisons.tsv

The scripts default to the original pilot author tree. Set
L1_GROUP1418_AUTHOR_BASE and L1_GROUP1418_AUTHOR_ROOT to the bound
author-base and its cached-original-roster directory if relocated.
The local original-roster.txt, prepared-roster.tsv, ordinal-roster.tsv
and accepted-result.json are the regenerated Group 1418 preparation
outputs. The relative archive manifest and all receipt files are
provided separately from the external operands.
