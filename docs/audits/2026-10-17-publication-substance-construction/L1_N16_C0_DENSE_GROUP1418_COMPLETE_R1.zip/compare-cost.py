"""Compare complete six-live signed groups using only measured phase scopes."""
import argparse
import csv
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import re
from subprocess import check_output
from zipfile import ZipFile

CHECKPOINT='8543061633b64e2a738c0497ccb3c417ce5aabab'
ROOT='docs/audits/2026-10-17-publication-substance-construction'
PINS={
    1284:'85efc3df3564b1243932cb8d1f39d70c6ea964760939825c990e1a9949004106',
    183:'094bc1ad24c7d229164a82071d749829988823d6db7e8d625e740557102ef0d0',
    189:'41bee65ac8984cc743b58a53dfdd9f6b50dded7fe8050c35a40a858aa8d3e218',
}

def records(thunk, group):
    plan=json.loads(thunk('accepted-result.json'))
    assert plan['group']==group and len(plan['remaining_ordinals'])==6
    stages=list(csv.DictReader(thunk('signed-work.tsv').decode().splitlines(),delimiter='\t'))
    caps=list(csv.DictReader(thunk('native-caps.tsv').decode().splitlines(),delimiter='\t'))
    timers=re.search(rb'(?m)^author measured seconds ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)$',
                     thunk('retally.out')).groups()
    timing=tuple(Decimal(s.decode()) for s in timers)
    assert len(caps)==6
    return (group,plan['source_rows'],plan['prepared_rows'],plan['quotient_sweeps'][-1][-1],
            sum(int(r['used_before']) for r in caps),
            sum(int(r['finished_products']) for r in stages),sum(int(r['refused_visit_products']) for r in stages),
            *timing)

def main(repo):
    rows=[]
    for group,digest in PINS.items():
        path=f'{ROOT}/L1_N16_C0_DENSE_GROUP{group}_COMPLETE_R1.zip'
        raw=check_output(['git','-C',str(repo),'show',f'{CHECKPOINT}:{path}'])
        assert sha256(raw).hexdigest()==digest
        with ZipFile(BytesIO(raw)) as z:
            rows.append(records(z.read,group))
    rows.append(records(lambda name:Path(name).read_bytes(),1418))
    fmt=('group','pre_sweep_source_rows','prepared_rows','sweep_row_visits','native_accepted_products',
         'continuation_accepted_products','continuation_refused_visits','author_preparation_s','author_guard_s',
         'author_continuation_s','author_terminal_s','author_measured_component_sum_s')
    print(*fmt,sep='\t')
    for row in rows:
        print(*row,sep='\t')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('repo',type=Path)
    main(p.parse_args().repo)
