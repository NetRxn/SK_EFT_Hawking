from ast import literal_eval
from collections import Counter,defaultdict
from fractions import Fraction
from hashlib import file_digest,sha256
from itertools import combinations,product
from math import factorial,lcm,prod
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile
from io import BytesIO
import re

PUB=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
HEAD='75b1430cad98ed444fd6549da1ec54531cb0f6bd'
ROOT='docs/audits/2026-10-17-publication-substance-construction'
DIGESTS={
 'DENSE_FACTOR_INPUTS_INDEPENDENT':'a9088fd54fbdb92c2a74fc7331f9793c950ba790cd5d89a8143f32af5fc93983',
 'DENSE_REUSE_PILOT':'c078c4fc4efc7ca903e17db526209e20a5692c260f202d837eac586a5a420416',
 'DENSE_COMPILED_FACTORS':'d66dc728ccb948a2630ea87b242564fba9b2c89ed51b3d9f3f100516f270ea42',
 'DENSE_GROUP128_COMPLETE':'9000d548ccd03c538315e7c84d0ab79a468595aeb6a3110ff549fc7f032576e2',
 'DENSE_GROUP672_COMPLETE':'8a93fb0149c6f918542338f5550be24581c875b761977d6dae350b50adc71f7a',
 'DENSE_GROUP934_COMPLETE':'8ec12dd30a63e16113cc022f4375e6b151db62142ca340c73bb53b5f1793531e',
}

def committed(kind):
    name=f'{ROOT}/L1_N16_C0_{kind}_R1.zip'
    raw=check_output(['git','-C',str(PUB),'show',f'{HEAD}:{name}'])
    digest=sha256(raw).hexdigest()
    assert digest==DIGESTS[kind]
    z=ZipFile(BytesIO(raw))
    assert len(z.namelist())==len(set(z.namelist()))
    manifest=next(s for s in ('SHA256SUMS','manifest.sha256') if s in z.namelist())
    for l in z.read(manifest).decode().splitlines():
        h,n=l.split(maxsplit=1)
        assert sha256(z.read(n.removeprefix('./'))).hexdigest()==h
    print('committed archive and manifest',kind,digest,flush=True)
    return z

def chirality_key(key):
    return tuple((b,a) for a,b in key)

def chr_family(family):
    return family[:-1]+str(1-int(family[-1])) if family.startswith('T') else family

def chr_wire(axis):
    return (*axis[:-1],1-axis[-1]) if axis[0]=='R' else axis


def load_cut():
    with committed('DENSE_REUSE_PILOT') as z, committed('DENSE_COMPILED_FACTORS') as compiled:
        def parse(name):
            return [row.split('\t') for row in z.read(f'census/{name}').decode().splitlines()]
        plan=[(int(i),int(n),int(rows),int(b),literal_eval(key),literal_eval(ids))
              for i,n,rows,b,key,ids in parse('cut-plan.tsv')]
        blocks=[(name,literal_eval(key),int(start),int(size),int(rows),int(den))
                for name,key,start,size,rows,den in parse('block-index.tsv')]
        assert z.read('census/block-index.tsv')==compiled.read('block-index.tsv')
        assert z.read('group934/schema.tsv')==compiled.read('schema.tsv')
        schema={name:(literal_eval(L),literal_eval(P)) for name,L,P,*_ in
                (line.split('\t') for line in compiled.read('schema.tsv').decode().splitlines())}
        axes=literal_eval(z.read('census/cut-axes.tsv').decode())
    assert len(schema)==88 and len(axes)==len(set(axes))==16
    assert tuple(sorted(set(schema['M01'][0])|set(schema['M06'][0])))==axes
    assert [i for i,*_ in plan]==list(range(3872))
    assert len({row[4] for row in plan})==len(plan)
    assert len({(f,k) for f,k,*_ in blocks})==len(blocks)==2456
    return plan,blocks,schema,axes

def label_support(schema,blocks):
    rel=defaultdict(set)
    for name,key,*_ in blocks:rel[name].add(key)
    rules={}
    for name,(axes,_) in schema.items():
        ordered=tuple(sorted(axes))
        indices=tuple(axes.index(k) for k in ordered)
        rows={tuple(key[i] for i in indices) for key in rel[name]}
        assert rules.setdefault(ordered,rows)==rows
    assert len(rules)==36
    axes=tuple(sorted({k for order in rules for k in order}))
    direct=defaultdict(set)
    with committed('DENSE_FACTOR_INPUTS_INDEPENDENT') as evidence:
        with ZipFile(BytesIO(evidence.read('independent/DIRECT-published.zip'))) as origin:
            for line in origin.read('manifest.sha256').decode().splitlines():
                h,n=line.split(maxsplit=1)
                assert sha256(origin.read(n.removeprefix('./'))).hexdigest()==h
            for line in origin.read('503841882182-1461451755920-local-labels.tsv').decode().splitlines():
                scope,key=map(literal_eval,line.split('\t'))
                known=dict(zip((('L',*w) for w in scope),key,strict=True))
                assert all(v==(0,0) for w,v in known.items() if w not in axes)
                reduced=tuple(w for w in sorted(known) if w in axes)
                direct[reduced].add(tuple(known[w] for w in reduced))
    assert direct==rules and sum(map(len,direct.values()))==740
    print('all 740 local relations match the independently accepted same-profile direct constraints',flush=True)
    domain={k:set() for k in axes}
    for order,rows in rules.items():
        for k,values in zip(order,zip(*rows),strict=True):domain[k].update(values)
    # Tabulate each variable/value as a bitset of allowed local rows. At
    # each branch, propagate the joined domains until they stabilize.
    dimensions={k:tuple(sorted(v)) for k,v in domain.items()}
    tables=[]
    neighbors=defaultdict(list)
    for order,rows in rules.items():
        look=[]
        for i,k in enumerate(order):
            masks=defaultdict(int)
            for bit,row in enumerate(sorted(rows)):masks[row[i]]|=1<<bit
            look.append((k,masks))
            neighbors[k].append(len(tables))
        tables.append((look,(1<<len(rows))-1))
    states=[]
    nodes=0
    def solve(d,work):
        nonlocal nodes
        nodes+=1
        while work:
            i=work.pop()
            vectors,allowed=tables[i]
            for k,masks in vectors:
                v=0
                for x in d[k]:v|=masks[x]
                allowed &= v
                if not allowed:return
            for k,masks in vectors:
                subset=tuple(x for x in d[k] if masks[x]&allowed)
                if subset!=d[k]:
                    d[k]=subset
                    work.update(neighbors[k])
        k=min((k for k in axes if len(d[k])>1),key=lambda k:(len(d[k]),-len(neighbors[k])),default=None)
        if k is None:
            states.append(tuple(d[w][0] for w in axes))
        else:
            for x in d[k]:
                child=d.copy()
                child[k]=(x,)
                solve(child,set(neighbors[k]))
    solve(dimensions,set(range(len(tables))))
    assert len(states)==len(set(states))==30_976
    print('exact compiled natural-join support',len(axes),'L axes',len(rules),'complete constraints',nodes,'branch nodes',len(states),'states',flush=True)
    return axes,states,rel
