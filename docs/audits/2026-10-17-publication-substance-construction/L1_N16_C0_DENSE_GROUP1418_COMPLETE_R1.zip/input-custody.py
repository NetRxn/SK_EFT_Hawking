"""Bind all numerical input files and the original source census to accepted commits."""
import argparse
from pathlib import Path
from hashlib import sha256,file_digest
from subprocess import check_output,run
from io import BytesIO
from zipfile import ZipFile

HEAD='8543061633b64e2a738c0497ccb3c417ce5aabab'
ROOT='docs/audits/2026-10-17-publication-substance-construction'
PINS={
 'DENSE_COMPILED_FACTORS':'d66dc728ccb948a2630ea87b242564fba9b2c89ed51b3d9f3f100516f270ea42',
 'DENSE_COMPONENT3_COMPLETE':'b647c71ad84d85b92232fc28d1dc332e7728cb4772b00608642594f0af218980',
 'DENSE_GEOMETRY_COVER':'bf3bfef6484236edc5eca2961d705f9ee27cc17b857c9c69df89114e4d99b1b4',
 'DENSE_REUSE_PILOT':'c078c4fc4efc7ca903e17db526209e20a5692c260f202d837eac586a5a420416',
}

def verify(repo,base,tip,metadata_only):
    def git(*args): return check_output(['git','-C',str(repo),*args])
    run(['git','-C',str(repo),'merge-base','--is-ancestor',HEAD,tip],check=True)
    print('checkpoint',HEAD,'readback',git('rev-parse',tip).decode().strip())
    print('intervening paths',git('diff','--name-only',HEAD,tip).decode().splitlines())
    for name,digest in PINS.items():
        path=f'{ROOT}/L1_N16_C0_{name}_R1.zip'
        raw=git('show',f'{HEAD}:{path}')
        assert sha256(raw).hexdigest()==digest and raw==git('show',f'{tip}:{path}')
        print(name,'SHA256',digest,flush=True)
        with ZipFile(BytesIO(raw)) as z:
            if name=='DENSE_COMPILED_FACTORS':
                for key in ('schema.tsv','block-index.tsv'):
                    assert (base/key).read_bytes()==z.read(key)
                local=z.read('local-blocks.sha256')
                assert (base/'compiled-local-blocks.sha256').read_bytes()==local
                if not metadata_only:
                    rows=[line.split(maxsplit=1) for line in local.decode().splitlines()]
                    assert len(rows)==88
                    for h,n in rows:
                        with (base/n.removeprefix('./')).open('rb') as f:
                            assert file_digest(f,'sha256').hexdigest()==h
                    print('all 88 immutable compiled numerical family files verified',flush=True)
            elif name=='DENSE_REUSE_PILOT':
                for key in ('cut-plan.tsv','cut-axes.tsv','block-index.tsv','prepare-branch.py'):
                    assert (base/key).read_bytes()==z.read(f'census/{key}')
                assert (base/'quotient.py').read_bytes()==z.read('group934/quotient.py')
                print('compiled cut roster and original preparation scripts byte-identical',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('repo',type=Path)
    p.add_argument('author',type=Path)
    p.add_argument('--tip',default='HEAD')
    p.add_argument('--metadata-only',action='store_true')
    a=p.parse_args()
    verify(a.repo,a.author,a.tip,a.metadata_only)
