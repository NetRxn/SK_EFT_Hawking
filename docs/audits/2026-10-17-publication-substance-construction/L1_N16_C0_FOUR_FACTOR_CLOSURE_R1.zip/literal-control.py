from fractions import Fraction
from itertools import combinations, product
from math import prod
from pathlib import Path
from random import Random
import pickle
import re
import subprocess
import sys
import tempfile

driver=Path(__file__).resolve().with_name('close-four-cached.py')
rng=Random(117)
pairs=list(combinations(range(4),2))
axes=tuple(('G',i) for i in range(len(pairs)))
domains={axis:range(2+i%2) for i,axis in enumerate(axes)}
for trial in range(12):
    factors=[]
    for node in range(4):
        scope=[axis for axis,pair in zip(axes,pairs,strict=True) if node in pair]
        rng.shuffle(scope)
        rows={}
        for key in product(*(domains[k] for k in scope)):
            z=rng.randrange(-3,4),rng.randrange(-3,4)
            if any(z) and rng.randrange(4):
                rows[key]=z
        factors.append((tuple(scope),rows,node+2))
    re_total=im_total=0
    for key in product(*(domains[k] for k in axes)):
        assignment=dict(zip(axes,key,strict=True))
        a,b=1,0
        for scope,rows,_ in factors:
            x,y=rows.get(tuple(assignment[w] for w in scope),(0,0))
            a,b=a*x-b*y,a*y+b*x
        re_total+=a
        im_total+=b
    den=prod(f[2] for f in factors)*16*4**64
    expected=(Fraction(re_total,den),Fraction(im_total,den))
    with tempfile.TemporaryDirectory() as folder:
        path=Path(folder)/'literal.pkl'
        path.write_bytes(pickle.dumps({'factors':factors,'conditioning':[],'label_partition':None}))
        for a,b in pairs:
            out=subprocess.check_output([sys.executable,str(driver),str(path),'--pair',str(a),str(b)],text=True)
            match=re.search(r'^exact normalized real (\S+) imaginary (\S+)',out,re.M)
            assert tuple(map(Fraction,match.groups()))==expected,(trial,a,b)
print('12 independently enumerated rational Gaussian networks, 6 pairings each, all exact')
