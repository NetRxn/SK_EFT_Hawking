from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import hashlib
import pickle
import re

scratch=Path(__file__).resolve().parent
source=Path('/private/tmp/l1-four-factor.Yv76ax')
author=Path('/private/tmp/l1-recover-three.jPcO9K')
previous=Path('/private/tmp/l1-three-cases-independent.PZCYHb')
prior=(previous/'accepted.tsv').read_text().splitlines()
cuts=(previous/'check-cuts.out').read_text()
print('outer\tcase\tcoordinate\tvalue real\tvalue imaginary\tinput SHA256')
for outer in (36,46):
    assert f'PASS nine-case projection and exact inverse lifting for outer {outer}' in cuts
    axes,rows=literal_eval((author/str(outer)/'case-0.roster').read_text())
    roster=sorted(rows,key=lambda pair:(pair[1],pair[0]))
    assert len(roster)==len({coords for coords,_ in roster})==9
    original_sections=[i for i,line in enumerate(prior) if line.startswith(f'OUTER {outer} ')]
    assert len(original_sections)==1
    previous_values={}
    for line in prior[original_sections[0]+1:]:
        if line.startswith('INCOMPLETE OUTER'):
            break
        if line.startswith('OPEN'):
            continue
        idx,coord,real,im,*metadata=line.split('\t')
        assert int(idx) not in previous_values and literal_eval(coord)==roster[int(idx)][0]
        previous_values[int(idx)]=(Fraction(real),Fraction(im),metadata[-1])
    assert set(previous_values)==set(range(7))
    values=previous_values.copy()
    for case in (7,8):
        expected=(source/f'{outer}-{case}-cached.out').read_text()
        received=(scratch/f'replay-{outer}-{case}.out').read_text()
        pattern=r'^exact normalized real (\S+) imaginary (\S+) seconds (\S+)$'
        donor=re.search(pattern,expected,re.M)
        replay=re.search(r'^independent exact normalized real (\S+) imaginary (\S+)$',received,re.M)
        assert donor and replay and donor.groups()[:2]==replay.groups()
        expected_raw=re.search(r' raw (-?\d+) (-?\d+) factor denominator (\d+)',expected)
        actual_raw=re.search(r'^raw (-?\d+) (-?\d+) factor denominator (\d+)',received,re.M)
        assert expected_raw and actual_raw and expected_raw.groups()==actual_raw.groups()
        path=author/str(outer)/f'row-cap-physical-slice-dense-label-case-{case}-2-reduced.pkl'
        blob=path.read_bytes()
        digest=hashlib.sha256(blob).hexdigest()
        assert received.splitlines()[0].startswith(f'input sha256 {digest} ')
        frontier=pickle.loads(blob)
        child=pickle.loads((author/str(outer)/f'case-{case}.pkl').read_bytes())
        assert frontier['conditioning']==child['conditioning']
        assert frontier['label_partition']==child['label_partition']
        actual_coordinate=tuple(dict(frontier['conditioning'])[axis] for axis in axes)
        assert actual_coordinate==roster[case][0]
        values[case]=(*map(Fraction,replay.groups()),digest)
    assert set(values)==set(range(9))
    for index in range(9):
        print(outer,index,roster[index][0],*values[index],sep='\t')
    print('ACCEPTED OUTER',outer,*(sum(row[i] for row in values.values()) for i in (0,1)),sep='\t')
