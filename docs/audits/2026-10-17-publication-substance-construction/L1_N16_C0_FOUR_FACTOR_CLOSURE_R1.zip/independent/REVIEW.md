# Independent replay of four row-limited terminal closures

Continuity packet l1-four-factor-closure-review-r1 checked fresh. The four inputs are the saved four-factor row-refusal frontiers for children 7 and 8 of outer cases 36 and 46. Both inner rosters were previously reconstructed and their full nine inverse lifts checked. Each reviewed frontier has unique axes within every factor, exact integer Gaussian rows with matching arity, positive denominators, and only degree-two open indices. Fixed coordinates are absent from all remaining factor axes. Full conditioning and representation-label metadata agree with the original cut child. External normalization +1/(16*4^64) and original factor-denominator product are applied once.

## Exact scalar and cache review

For a selected pair of factors A and B, their shared coordinates are summed in their matched row product. A compatible complement must agree with all four cross-pair coordinate vectors, and the two remaining factors C and D must also agree on their mutual internal coordinate. Degree two ensures each coordinate appears in exactly one of these six sets. The terminal scalar is the sum of matched A/B coefficients multiplied by the exact C/D inner product at the four cross-pair coordinates. This identity holds for Gaussian integers without a numerical approximation or normalization adjustment.

The author cache uses all four cross-pair coordinates as keys and the fixed C/D factor tables as read-only data. Per-edge recoding is injective and common to both factors incident to that edge. Degree two, distinct axes and the full row key ensure the closure's dictionary cannot collapse different coefficients with the same encoded key. Missing supports and exactly canceled inner products both contribute zero. Cache eviction can recompute an exact value but cannot change it. The bounds restrict pair matches, closure probes, Gaussian multiplications and resident cache entries. The uncached author attempts refused at their arithmetic limit. Their receipts remain part of the evidence.

## Independent route

The independent driver uses alternate outer pair (1,2) and complement (0,3), while the author uses (1,3) with complement (0,2). It processes disjoint blocks fixed by one cross-pair edge vector. In each block it reduces all matching A/B terms to boundary amplitudes before the C/D inner product, with support filtering on both boundary halves. Blocks cannot share a boundary tuple. There is no retained closure LRU or author module import. Distributivity over exact Gaussian integers justifies the regrouping. Peak block entries bound the temporary boundary dictionary.

Each outer identity is derived from the original 48-entry roster sorted by product forecast and coordinate. The initial outer46 check used an incorrect manually entered coordinate, refused before arithmetic and remains preserved as an adverse receipt. The corrected guard selects the roster entry directly. The outer36 guard was already correct, and final aggregation also checks all four cuts and input hashes.

| Inputs | Selected pair matches per input | Gaussian products per input | Closure probes per input | Peak block rows per input | Seconds |
|---|---:|---:|---:|---:|---:|
| Outer 36 children 7 and 8 | 6,138,720 | 23,692,032 | 15,536,640 | 24,984 | 13.366 and 13.277 |
| Outer 46 children 7 and 8 | 6,593,616 | 27,595,440 | 18,564,576 | 24,984 | 15.976 and 15.060 |

All four independent outputs match the author raw Gaussian numerators, factor denominator and normalized exact complex values. Distinct input digests and separate contractions cover both members of each equal-value pair. The paired equality does not assume a symmetry. Aggregation checks the prior seven accepted entries, new input identities, and exhaustive disjoint nine-child support for each outer case.

- Outer 36: -311265394132600099496295/5192296858534827628530496329220096, imaginary 0.
- Outer 46: -52600891516154856091647/324518553658426726783156020576256, imaginary 0.

The values close outer cases 36 and 46 within the 48-case partition of the first binary child of tuple 0. Earlier reductions are carried by the pinned saved lineage and previously reviewed equivalence. This review supplies no independent replay of the full original network or acceptance of the enclosing binary child, whole tuple, branch or c0.
