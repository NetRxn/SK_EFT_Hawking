from fractions import Fraction
from pathlib import Path
import re

root=Path(__file__).resolve().parent
review=(root/'previously-accepted.tsv').read_text()
pattern=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
expected={
    36:Fraction(-311265394132600099496295,5192296858534827628530496329220096),
    46:Fraction(-52600891516154856091647,324518553658426726783156020576256),
}
for outer in (36,46):
    exact={}
    section=review.split(f'OUTER {outer} ',1)[1].split(f'INCOMPLETE OUTER {outer}',1)[0]
    for row in section.splitlines()[1:]:
        fields=row.split('\t')
        if fields[0].isdigit():
            exact[int(fields[0])]=tuple(map(Fraction,fields[2:4]))
    assert set(exact)==set(range(7))
    for child in (7,8):
        source=root/f'{outer}-{child}-cached.out'
        exact[child]=tuple(map(Fraction,pattern.search(source.read_text()).groups()))
    value=tuple(sum(v[i] for v in exact.values()) for i in (0,1))
    assert value==(expected[outer],Fraction(0))
    print(outer,*value,sep='\t')
