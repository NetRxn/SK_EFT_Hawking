"""Actual source seed and witness replay only. No quartic coefficient evaluator."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from hashlib import sha256
import json
import sys
path = Path(__file__).with_name("publication-task4-continuation-quartic-r13.py")
spec = spec_from_file_location("r12_witness_control", path)
m = module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)
work = m.r5.Work(cap=1_500_000)
reg, centers, inputs, raw, d0, d1 = m.r10.setup(work)
rejected = []
rows = []
targets = m.seeded_targets(inputs, d0, d1, work, rejected.append)
for target, direction, seed, attempt, value, paths, peak in targets:
    # The actual suspended inner frame has no view or flattened row cache
    # while the independent coefficient phase would run.
    candidates = targets.gi_frame.f_locals["candidates"]
    assert candidates.gi_code is m.indexed_seed.__code__
    frame = candidates.gi_frame.f_locals
    assert not any(k in frame for k in ("cache", "flat", "rr"))
    if not rows:
        try:
            m.witness(target, seed, inputs, m.r5.Work(cap=10_000), 0)
        except RuntimeError as exc:
            assert str(exc) == "quartic local cap: prospective 1, cap 0"
            witness_refusal = str(exc)
        else:
            raise AssertionError("witness projection bypassed local admission")
    rows.append(dict(target=m.r5.fingerprint(target),direction=direction,seed=seed,
                     attempt=attempt,witness=str(value),paths=paths,peak=peak))
assert len(rows)==3 and [row["direction"] for row in rows]==[0,0,1]
assert any(row["target"]["slot"]==m.SLOTS[1] for row in rejected)
assert rows[0]["witness"] == str(m.Q(m.Fraction(3,32768)))
frozen = path.with_name("publication-task4-continuation-quartic-r12.witness-control.json").read_bytes()
assert sha256(frozen).hexdigest() == "3c377af889b673e49b26a510c3f43d48d0028542c671c77e4bd690fedbe65c06"
prior = json.loads(frozen)
def without_work(rejection):
    return {k: v for k, v in rejection.items() if k != "work"}
assert m.json_identity(rows) == prior["rows"]
assert m.json_identity([without_work(r) for r in rejected]) == [without_work(r) for r in prior["rejected"]]
print(json.dumps(dict(rows=rows,rejected=rejected,work=work.used,cap=work.cap,
                      seed_counts={k:v for k,v in work.counts.items() if k.startswith("quartic_seed_")},
                      retained_seed_views_at_accepted_yields=0,
                      prefix_digest=m.PREFIX_DIGEST,prefix_records=m.PREFIX_RECORDS,
                      witness_refusal=witness_refusal),indent=2))
