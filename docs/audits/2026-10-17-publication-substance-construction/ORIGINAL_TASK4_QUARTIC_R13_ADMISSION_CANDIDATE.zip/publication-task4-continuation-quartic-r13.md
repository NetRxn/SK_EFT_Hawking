# R13 seed retention correction

The seed path reads the immutable ExteriorPolynomial and Polynomial
tuples in the order used by r4.rows. It counts each exterior block
to expose the flat length, calls the same random.choice sequence,
then locates the selected flat index by subtracting each polynomial
block length in order. It charges the count and lookup traversals
and the selected coefficient read before executing them. Each
operand view references the source tuple and is deleted when that
operand is done. No flat coefficient collection is created. The
bounded actual witness replay checks the suspended seed frame at
each accepted yield for retained cache or view state.

The 24 accepted R10 target, source seed and attempt identities are
reconstructed against the frozen receipt. The three R12 nonzero
witness identities, exact coefficients and path counts, and the
zero rejection, are checked against the frozen R12 receipt. The
two mixed seeds still use the combined d0+d1 contact observable.
R12 local and oracle overlap, fanout, signed cap and arithmetic
controls are retained. New adverse controls check unequal block
lengths, matching RNG state, and prospective refusals during count,
lookup and row reads.

The exact original quartic coefficient evaluation awaits independent
admission. Its candidate command uses --root-admitted-original after
the appropriate fresh packet and review. It writes an exclusive
R13 JSONL receipt and preserves previous R10/R11/R12 evidence.
