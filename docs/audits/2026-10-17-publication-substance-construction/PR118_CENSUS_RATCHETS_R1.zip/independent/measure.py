import sys
from pathlib import Path
from validate import check_count_literals, check_spelled_out_census_figures
from src.core import constants
assert Path(constants.__file__).resolve().is_relative_to(Path.cwd().resolve())
mode = sys.argv[1]
for check, expected, old_ceiling, new_ceiling in (
        (check_count_literals, "91 count-literal matches across 64 papers", 95, 91),
        (check_spelled_out_census_figures, "67 spelled-out census figure(s) across 20 of 64 draft(s)", 71, 67)):
    result = check()
    detail = next(d for d in result.details if d.message.startswith(expected))
    assert result.passed and result.measured and detail.measured
    assert f"ceiling {old_ceiling if mode == 'before' else new_ceiling}" in detail.message
    print(check.__name__, detail.message)
