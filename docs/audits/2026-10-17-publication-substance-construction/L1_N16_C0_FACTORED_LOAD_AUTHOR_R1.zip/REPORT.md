# Original N16 pure-EHC factored load and signed face reductions

The primary packet `publication-l1-n16-c0-factored-load-author-r1.json`
checked fresh at `27012c18fa374e8341e124b510abbedeedb18d29`. The
calculation uses the original periodic closed action, the original
Berezin orientation and all 64 independently anchored Spin(4) links.
This is scratch evidence. No tracked source, shared notebook, controller
or Lean slot was modified.

## Conditioning on center totals closes vertex stars early

For each vertex x let M_x be the total number of EHC factors centered
there, and let h_x be its four directional coframe loads. The exact
range is M_x in 0 through 4 with sum M_x=32 and

```
sum_u h_(x,u) = 2 M_x
0 <= h_(x,u) <= M_x
sum_u h_(x xor e_u,u) = 8 - 2 M_x.
```

The first two rows characterize possible local directional loads, not
just a relaxation. They are the degree vectors of a loopless multigraph
on the four directions with M_x edges. Pick the two largest positive
degrees and subtract one from both. At most two degrees could equal
M_x, both are picked, and the new largest degree is at most M_x−1.
Induction constructs the required six coframe-pair multiplicities.
Different local multiplicity assignments with the same load are
retained in the occupation count.

When M is fixed, the last row splits into two independent systems.
Even-center loads supply incoming totals to odd vertices, and odd
centers supply the even vertices. In each system, a residual state has
eight labeled column totals. All four incident source rows of a sink
must be complete before that sink's incoming equality closes. The
star-first order places the four neighbors of a selected sink first.
The independent lexicographic order closes its first sink in row five.

The memoized recursion counts exact numbers of completions, viable
prefix transitions and naive traversal trials. A viable DAG compiles
only transitions whose suffix count is positive, which avoids scanning
inadmissible local choices at every represented prefix. The compiler
and collector check that actual completion and work counts equal the
prospective counts. These steps handle both the distinct-load count
and the occupation count with duplicate load choices retained.

The global unconstrained M envelope has exactly 10,651,488,789 labeled
rosters before neighbor-capacity tests. This is the coefficient of
t^32 in (1+t+...+t^4)^16, checked by both integer convolution and
inclusion–exclusion. It is an upper envelope for feasible M.
No global sweep of those rosters was attempted.

## Complete coarse result for uniform M=2

The star order has 8,227 memo states and 172,767 occupation memo trials
per side. The lex order has 9,575 states and 201,075 trials per side.
The star order counts 1,354,811 load assignments and 4,738,011
occupation assignments per side. Squaring gives respectively
1,835,512,845,721 load assignments and 22,448,748,236,121 occupations
with exact site-degree saturation in the uniform sector.

The original geometric parity data carried per half are:

- S, one bit per undirected edge, equal to curvature uses of both
  anchors plus coframe occurrences, modulo two.
- A, curvature parity of the actual first directed anchor on each
  edge. The other anchor remains separate.
- P, a bit wherever a coframe occurred on that half.

The join is exactly S_even=S_odd plus

```
(A_even xor A_odd) & ~(P_even | P_odd) = 0.
```

The first condition is the necessary undirected parity. The second
enforces both directed anchors whenever there are no coframes on
the edge. If d>0, total parity is sufficient for a split of the d
coframes between the two anchors at the unresolved-chirality level.
If d=0, individual parity is required. The conditions test aggregate
Haar support only. They do not discard chirality, generator order or
spinor coefficients from the original contraction.

Prospective bounds were 300,000 memo states, 50 million counting or
collection transitions per side, five million completions per side,
one million live DAG arcs, 131,072 syndrome bins, 250 million directed
candidate pairs and 128 MiB of raw signature descriptors. The
syndrome bound follows because the vertex boundary of a completed
half's S vanishes. Its outgoing degrees 2M and incoming degrees
8−2M are even. The Q4 edge cycle space has dimension 32−16+1=17.

Naive rechecking of the 21 local options at every viable prefix would
take 138,460,392 trials per side, so it refused before histogram
allocation. The viable DAG had only 25,884 arcs per side and exactly
11,331,362 live-prefix transitions. It admitted the following complete
exact support calculations:

| Stage | Exact uniform-sector result |
| --- | ---: |
| Total geometric occupations satisfying site saturation | 22,448,748,236,121 |
| Distinct completed syndromes on each side | 130,688 |
| Occupations matching undirected parity | 198,840,165 |
| Occupations also satisfying split-anchor parity | **87,055,413** |

The descriptor allocation was 113,712,264 bytes. Full directed runs
under the star and lex orders gave identical counts in 0.94 s and
0.89 s, with measured peak RSS below 134 MB. These are exact counts
of geometric occupations in the declared uniform sector. They are
upper bounds on occupations with nonzero signed contribution. No
inference from coarse count to physical value is made.

A separate all-even control doubles a single plane at every site.
Each parity side reduces to a binary degree-two subgraph on Q4.
An independent enumeration of the 272 perfect matchings and all
unions of disjoint pairs gives 2,970 distinct 2-factors, agreeing
with the row recursion. The resulting 8,820,900 labeled occupations
pass both directed parities because every occurrence count is even.

For M=4 on every even site and M=0 elsewhere the factored saturation
count is exact. There are 5,396,234,781 load assignments and
360,186,646,596 occupations on its nontrivial side. Its
613,774,076,852 viable prefix transitions fail the compiled cap,
so no histogram or directed descriptors were allocated for that
sector. These are saturation counts, with parity survivors unknown.

## Independent load and signed-source controls

The fixed-load XOR contraction reran on h=(1,1,1,1) at all sites.
It gives 5,937 coarse survivors from 43,046,721 occupations and
agrees with independent two-half enumeration. The unique fixed
h=(2,2,0,0) occupation passes. The staggered mutation with no
coframe on eight blocking edges passes the undirected check and
fails the actual directed check.

For a signed-source comparison, restrict to all four bars at x
and two psis at each of x+e0 and x+e1. The factored support count
with M_x=2 and all other M=0 has one occupation, passing both
parities. The original-source script derives the same unique
center and world plane from the endpoint labels. It keeps the
source quarter-coframe, both independent anchors, inverse word,
Grassmann sign and the 2! denominator. Opposite endpoint
chiralities give exact restricted Haar top 3/4. With both endpoint
pairs left-chiral, the same coarse occupation passes but the
actual coefficient is zero, since only the two right-chiral
center bars can occur. The source's full ordered roster agrees
with the grouped formula on 16 nonzero quartic masks in the
first control and four in the second. This demonstrates the
coarse/exact boundary in an original-source example.

## Signed route for one full periodic occupation

Take the unique full load h=(2,2,0,0) at all sites. Its occupation
has m_(x,23)=2 for every x. All curvature links are in directions
2,3 and all coframe links in 0,1. Haar factors therefore separate
by the two direction sets. The curvature sector has four disjoint
2×2 faces indexed by the values of bits 0,1. Each face retains
all eight actual anchors, including both on every undirected edge.
The four rooted curvature polynomials are correlated.

For a fixed rooted plane, let F_AB be the antisymmetrized original
trace, with the original forward closed word and its inverse. Write
the literal chiral coefficient vectors as

```
F_AB = 2 u^L_AB dot vec(q_L) + 2 u^R_AB dot vec(q_R),
G^chi(AB,CD) = u^chi_AB dot u^chi_CD.
```

The vectors come directly from the source gamma convention and are
real. Gauge invariance of product Haar allows conjugation averaging
at each root independently, because a rooted closed holonomy only
transforms under the gauge variable at its base. The mixed
L/R cross term averages to zero. Within each chirality isotropy
gives (4/3)|vec(q_chi)|² times G^chi. In terms of the spin-one
adjoint character chi_1(U)=4q0²−1, this gives the exact local
replacement of two curvature factors under the face integral,

```
F_AB F_CD -> G^L(AB,CD)(1 - chi_1(H_L)/3)
          + G^R(AB,CD)(1 - chi_1(H_R)/3).
```

A nonempty proper subset of the four roots carrying one chiral
adjoint character leaves a singleton anchor. Its integral
vanishes. The rooted overlap graph is a connected square, with
each link used by exactly two distinct roots. For the full
four-root single-chirality moment, the two occurrences of each
actual anchor give the adjoint Schur pair
`integral R_ab R_cd = delta_ac delta_bd / 3`.
The closed word D† C† B A fixes which indices are transposed.
The literal anchor pairing of the 16 trace indices leaves four
free equality classes. The full adjoint-character moment is
therefore 3^(4−8)=1/81.

Writing G_x for the local internal pair labels at root x, the
complete two-curvatures-per-root face tensor is the sum of three
separable terms

```
product_x (G_x^L + G_x^R)
  + (product_x G_x^L + product_x G_x^R) / 6561.
```

The source script verifies the literal trace vectors, the singleton
anchor supports and the equality classes. In particular F01
has coefficients −2 q_(L,3) + 2 q_(R,3). The product of four
F01 squares has exact Haar moment 104978/6561, while separately
averaging each rooted square would give 16. In the mixed
F01 F23 control the local G's are −1 and +1, so separate averaging
would give zero. The actual four-root joint moment is 2/6561.
The direct coordinate-parity contraction of four *unsquared*
F01 factors gives zero in both chiralities. These tests retain the
original four words and all eight anchors.

Expand the three face terms over the four independent curvature
faces. This gives only 3^4=81 index assignments t. At any fixed t,
the remaining coframes are confined to four identical Q2
squares in axes 0,1, indexed by bits 2,3. The chosen local G at a
given position in a square is the same across the four squares.
The Haar variables and odd site generators in distinct squares are
independent. Regrouping the site tops permutes eight-generator
blocks and has positive sign. The single occupation's original
contribution therefore reduces exactly to

```
(2!)^-16 * sum_t 6561^(-number_of_corrected_faces(t)) * C(t)^4,
```

where C(t) is the **signed** Haar/Berezin contraction of one
32-generator coframe square, with both links on each of its four
undirected edges. The world epsilon appears squared. The local
quartic coframe factors have real G tensors and are invariant
under coefficient conjugation combined with bar/psi exchange
and product reversal: each original coframe changes sign under this
involution, and there are four at each center. The original
top has positive involution sign (reversal of eight generators
and four paired exchanges at each site). Thus C(t) is real
and the single-occupation contribution is nonnegative. Its
strict positivity and exact value remain uncomputed.

For a bounded next signed calculation, construct the fourth
Haar edge tensor with two coframes centered at each endpoint.
Each edge supplies degree four at each endpoint. At one endpoint
the interface needs at most 10 symmetric internal index pairs
and 70 degree-four exterior masks. Local Berezin contraction
pairs only complementary masks and retains their exact sign.
Each C(t) can therefore be represented by a cycle of four
edge tensors and four signed vertex tensors on interfaces of
size at most 700. The 700 count is a dimension bound, not
measured populated support or operation count. An exact sparse
edge-tensor preflight and an independent small check of the
square contraction are the next missing steps. This route
addresses only the stated full occupation; its sign cannot be
extended to the other occupations by dropping their contributions.

## Boundary and reproduction

The whole original c0 remains uncomputed. The uniform-sector
support and the exact signed face reduction are independently
reviewable claims. Neither proves c0 zero or nonzero.

Build `factored.cpp` with
`clang++ -std=c++20 -O3 -Wall -Wextra -Werror factored.cpp -o factored`.
Run e.g. `python3 measure.py ./factored uniform star directed`;
the executable arguments follow the receipt names. Run
`fibers.py` and `combinatorial_controls.py` with Python.
For `source_control.py` and `curvature_face.py`, use the
primary checkout on PYTHONPATH and its existing venv interpreter
with PYTHONDONTWRITEBYTECODE=1. The same-chirality control is
selected by the literal argument `same-chirality`.
