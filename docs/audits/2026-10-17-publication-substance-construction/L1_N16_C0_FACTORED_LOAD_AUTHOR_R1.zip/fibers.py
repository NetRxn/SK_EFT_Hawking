from collections import Counter, defaultdict
from itertools import combinations, product

def rank(columns):
    b = {}
    for x in columns:
        while x:
            k = x.bit_length()
            if k not in b:
                b[k] = x
                break
            x ^= b[k]
    return len(b)

axes = range(4)
planes = list(combinations(axes, 2))
edges = [(x, k) for x in range(16) for k in axes if not x & (1 << k)]
edge_index = {e: i for i, e in enumerate(edges)}

def edge(x, k):
    return edge_index[x & ~(1 << k), k]

def parity_column(x, u, v):
    k, ell = sorted(set(axes) - {u, v})
    curv = [edge(x, k), edge(x ^ (1 << k), ell), edge(x ^ (1 << ell), k), edge(x, ell)]
    return sum(1 << i for i in curv + [edge(x, u), edge(x, v)])

by_h = defaultdict(list)
for m in product(range(5), repeat=6):
    if sum(m) > 4:
        continue
    h = tuple(sum(n for (u, v), n in zip(planes, m) if a in (u, v)) for a in axes)
    parity = sum((n % 2) << i for i, n in enumerate(m))
    by_h[h].append(parity)

def group_sum(columns, mask):
    out = 0
    for i, c in enumerate(columns):
        if mask & (1 << i):
            out ^= c
    return out

print("labeled h profiles", len(by_h), "local m profiles", sum(map(len, by_h.values())))
print("raw h-fiber size histogram", sorted(Counter(map(len, by_h.values())).items()))
print("distinct local parity fiber histogram", sorted(Counter(len(set(g)) for g in by_h.values()).items()))
print("number of non-affine local parity sets", sum(len(set(g)) == 3 for g in by_h.values()))
variation = {value ^ g[0] for g in by_h.values() for value in g}
print("distinct degree-preserving m parity variations", sorted(variation))
assert variation == {0, 30, 45, 51}
columns = [[parity_column(x, *plane) for plane in planes] for x in range(16)]
print("degree-preserving projected Haar variation rank", rank(
    group_sum(cols, delta) for cols in columns for delta in variation))
assert rank(group_sum(cols, delta) for cols in columns for delta in variation) == 13

def fixed_loads(name, load, expect, directed=True):
    caps = [sum(load[x]) + sum(load[x ^ (1 << k)][k] for k in axes) for x in range(16)]
    assert caps == [8] * 16
    zero_edges = sum(1 << i for i, (x, k) in enumerate(edges)
                     if load[x][k] == load[x ^ (1 << k)][k] == 0)

    def projected(x, u, v):
        k, ell = sorted(set(axes) - {u, v})
        anchored = ((x, k), (x ^ (1 << k), ell), (x ^ (1 << ell), k), (x, ell))
        a = sum(1 << edge(y, j) for y, j in anchored if not y & (1 << j))
        return parity_column(x, u, v) | ((a & zero_edges) << 32 if directed else 0)

    opts = []
    differences = []
    for x in range(16):
        cols = [projected(x, *plane) for plane in planes]
        opt = Counter(group_sum(cols, p) for p in by_h[load[x]])
        opts.append(opt)
        ref = next(iter(opt))
        differences.extend(k ^ ref for k in opt)
    maximum = 2 ** rank(differences)
    assert maximum <= 100000

    def extend(block):
        states = Counter({0: 1})
        peak = 1
        for opt in block:
            next_states = Counter()
            for a, a_count in states.items():
                for b, b_count in opt.items():
                    next_states[a ^ b] += a_count * b_count
            states = next_states
            peak = max(peak, len(states))
        return states, peak

    full, peak = extend(opts)
    def explicit_half(block):
        result = Counter()
        for values in product(*(list(row.elements()) for row in block)):
            x = 0
            for v in values:
                x ^= v
            result[x] += 1
        return result
    left, right = explicit_half(opts[:8]), explicit_half(opts[8:])
    independent = sum(n * right[x] for x, n in left.items())
    assert independent == full[0]
    if expect is not None:
        assert full[0] == expect
    print(name, "directed", directed, "zero edges", zero_edges.bit_count(),
          "parity-state bound", maximum, "actual peak", peak,
          "all occupations", sum(full.values()), "surviving occupations", full[0])

fixed_loads("all-one", [(1, 1, 1, 1)] * 16, None)
fixed_loads("axis-01", [(2, 2, 0, 0)] * 16, 1)
p = [2 + (-1) ** x.bit_count() * bool(x & 4) for x in range(16)]
fixed_loads("split-anchor-negative", [(v, v, 0, 0) for v in p], 0)
fixed_loads("split-anchor-undirected-only", [(v, v, 0, 0) for v in p], 1, directed=False)
