#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <numeric>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

using U64 = uint64_t;
using U128 = __uint128_t;
using Word = uint32_t;
using Row = std::array<int, 4>;
using Sites = std::array<int, 16>;
constexpr U64 MAX_TRANSITIONS = 50000000;
constexpr U64 MAX_COMPLETIONS = 5000000;
constexpr size_t MAX_MEMO_STATES = 300000;
constexpr size_t MAX_SYNDROMES = 131072;
constexpr size_t MAX_DAG_ARCS = 1000000;
constexpr U64 MAX_JOIN_PAIRS = 250000000;
constexpr size_t MAX_DESCRIPTOR_BYTES = 128 * 1024 * 1024;

std::string dec(U128 x) {
    std::string out;
    do { out += char('0' + x % 10); x /= 10; } while (x);
    std::reverse(out.begin(), out.end());
    return out;
}

struct Geometry {
    std::array<std::array<int, 4>, 16> edge{};
    std::array<std::array<int, 2>, 6> pairs{};
    std::array<std::array<Word, 6>, 16> plane_syndrome{}, first_anchor{};
    Geometry() {
        int e = 0, p = 0;
        for (int x = 0; x < 16; ++x)
            for (int k = 0; k < 4; ++k)
                if (!(x & (1 << k))) edge[x][k] = edge[x ^ (1 << k)][k] = e++;
        for (int u = 0; u < 4; ++u)
            for (int v = u + 1; v < 4; ++v) pairs[p++] = {u, v};
        for (int x = 0; x < 16; ++x)
            for (int i = 0; i < 6; ++i) {
                auto [u, v] = pairs[i];
                Row complement{};
                int n = 0;
                for (int k = 0; k < 4; ++k)
                    if (k != u && k != v) complement[n++] = k;
                int k = complement[0], l = complement[1];
                plane_syndrome[x][i] = (Word(1) << edge[x][u]) ^ (Word(1) << edge[x][v]);
                for (auto [y, a] : {std::pair{x,k}, {x ^ (1 << k),l}, {x ^ (1 << l),k}, {x,l}}) {
                    const Word bit = Word(1) << edge[y][a];
                    plane_syndrome[x][i] ^= bit;
                    if (!(y & (1 << a))) first_anchor[x][i] ^= bit;
                }
            }
    }
};
struct Signature {
    Word syn = 0, a = 0, coframe = 0;
};
struct Choice {
    Row h{};
    Signature data{};
};
using Options = std::array<std::vector<Choice>, 8>;

void occupations(const Geometry& g, int x, int pair, int left, Choice q,
                 std::vector<Choice>& out) {
    if (pair == 6) {
        if (!left) out.push_back(q);
        return;
    }
    auto [u, v] = g.pairs[pair];
    for (int n = 0; n <= left; ++n) {
        occupations(g, x, pair + 1, left - n, q, out);
        ++q.h[u]; ++q.h[v];
        q.data.syn ^= g.plane_syndrome[x][pair];
        q.data.a ^= g.first_anchor[x][pair];
        q.data.coframe |= (Word(1) << g.edge[x][u]) | (Word(1) << g.edge[x][v]);
    }
}
struct Count { U128 leaves = 0, live_steps = 0, trials = 0; };

struct Side {
    std::array<int, 8> sources{}, sinks{}, last{};
    std::array<std::array<int, 4>, 8> col{};
    std::array<int, 8> target{};
    std::array<std::unordered_map<Word, Count>, 9> cache;
    U64 work = 0;
    size_t states = 0;
    const Options opts;
    Side(const Geometry& g, const Sites& m, const Sites& top, int parity,
         const std::string& order, const std::string& mode) : opts(build(g, m, parity, order, mode)) {
        std::array<int, 16> col_id{};
        for (int x = 0, i = 0; x < 16; ++x)
            if (std::popcount(unsigned(x)) % 2 != parity) {
                col_id[x] = i;
                sinks[i] = x;
                target[i++] = top[x] - 2 * m[x];
            }
        for (int row = 0; row < 8; ++row)
            for (int a = 0; a < 4; ++a) {
                int j = col_id[sources[row] ^ (1 << a)];
                col[row][a] = j;
                last[j] = row;
            }
    }
    Options build(const Geometry& g, const Sites& m, int parity,
                  const std::string& order, const std::string& mode) {
        Options out;
        std::vector<int> rows;
        for (int x = 0; x < 16; ++x)
            if (std::popcount(unsigned(x)) % 2 == parity) rows.push_back(x);
        if (order == "star") {
            const int target_vertex = parity ^ 1;
            std::stable_sort(rows.begin(), rows.end(), [=](int a, int b) {
                return std::popcount(unsigned(a ^ target_vertex)) <
                    std::popcount(unsigned(b ^ target_vertex));
            });
        }
        for (int i = 0; i < 8; ++i) {
            int x = rows[i];
            sources[i] = x;
            occupations(g, x, 0, m[x], {}, out[i]);
            if (mode == "loads") {
                std::map<Row, Choice> unique;
                for (const auto& a : out[i]) unique.emplace(a.h, a);
                out[i].clear();
                for (const auto& [h, a] : unique) out[i].push_back(a);
            } else if (mode == "same-plane") {
                if (m[x] != 2) throw std::runtime_error("uniform M=2 required");
                out[i].erase(std::remove_if(out[i].begin(), out[i].end(), [](const auto& a) {
                    return std::count(a.h.begin(), a.h.end(), 2) != 2;
                }), out[i].end());
                if (out[i].size() != 6) throw std::runtime_error("same-plane roster mismatch");
            }
        }
        return out;
    }
    bool advance(int i, Word before, const Choice& q, Word& after) const {
        after = before;
        for (int a = 0; a < 4; ++a) {
            int j = col[i][a];
            int d = ((before >> (4 * j)) & 15) + q.h[a];
            if (d > target[j] || (last[j] == i && d != target[j])) return false;
            after += Word(q.h[a]) << (4 * j);
        }
        return true;
    }
    Count count(int i, Word state) {
        if (i == 8) return {1, 0, 0};
        auto it = cache[i].find(state);
        if (it != cache[i].end()) return it->second;
        if (++states > MAX_MEMO_STATES) throw std::runtime_error("memo state cap");
        Count sum;
        for (const auto& q : opts[i]) {
            if (++work > MAX_TRANSITIONS) throw std::runtime_error("memo work cap");
            Word next = 0;
            if (!advance(i, state, q, next)) continue;
            Count suffix = count(i + 1, next);
            if (!suffix.leaves) continue;
            sum.leaves += suffix.leaves;
            sum.live_steps += 1 + suffix.live_steps;
            sum.trials += suffix.trials;
        }
        if (sum.leaves) sum.trials += opts[i].size();
        cache[i].emplace(state, sum);
        return sum;
    }
    void collect(int i, Word state, Word syn, std::unordered_map<Word, U64>& out,
                 U64& trials) const {
        if (i == 8) {
            ++out[syn];
            if (out.size() > MAX_SYNDROMES) throw std::runtime_error("syndrome cap");
            return;
        }
        for (const auto& q : opts[i]) {
            if (++trials > MAX_TRANSITIONS) throw std::runtime_error("histogram trial cap");
            Word next = 0;
            if (!advance(i, state, q, next)) continue;
            if (i + 1 < 8 && cache[i + 1].at(next).leaves == 0) continue;
            collect(i + 1, next, syn ^ q.data.syn, out, trials);
        }
    }
    using Arc = std::pair<Word, Signature>;
    using Dag = std::array<std::unordered_map<Word, std::vector<Arc>>, 8>;
    Dag compile() const {
        Dag dag;
        size_t arcs = 0;
        for (int i = 0; i < 8; ++i)
            for (const auto& [state, suffix] : cache[i]) {
                if (!suffix.leaves) continue;
                auto& steps = dag[i][state];
                for (const auto& q : opts[i]) {
                    Word next = 0;
                    if (!advance(i, state, q, next)) continue;
                    if (i + 1 < 8 && cache[i + 1].at(next).leaves == 0) continue;
                    if (++arcs > MAX_DAG_ARCS) throw std::runtime_error("DAG arc cap");
                    steps.emplace_back(next, q.data);
                }
            }
        std::cout << "compiled arcs " << arcs << '\n';
        return dag;
    }
    void collect_compiled(const Dag& dag, int i, Word state, Word syn,
                          std::unordered_map<Word, U64>& out, U64& steps) const {
        if (i == 8) {
            ++out[syn];
            if (out.size() > MAX_SYNDROMES) throw std::runtime_error("syndrome cap");
            return;
        }
        for (auto [next, local] : dag[i].at(state)) {
            if (++steps > MAX_TRANSITIONS) throw std::runtime_error("compiled trial cap");
            collect_compiled(dag, i + 1, next, syn ^ local.syn, out, steps);
        }
    }
    std::unordered_map<Word, U64> histogram(const Count& c, bool compiled) const {
        const U128 budget = compiled ? c.live_steps : c.trials;
        if (c.leaves > MAX_COMPLETIONS || budget > MAX_TRANSITIONS)
            throw std::runtime_error("prospective histogram bound");
        std::unordered_map<Word, U64> result;
        U64 trials = 0;
        if (c.leaves && compiled) collect_compiled(compile(), 0, 0, 0, result, trials);
        else if (c.leaves) collect(0, 0, 0, result, trials);
        U64 mass = 0;
        for (const auto& [k, n] : result) mass += n;
        if (mass != c.leaves || trials != budget) throw std::runtime_error("histogram tally mismatch");
        return result;
    }
    void record(const Dag& dag, int i, Word state, Signature prefix,
                std::vector<Signature>& out, U64& steps) const {
        if (i == 8) { out.push_back(prefix); return; }
        for (const auto& [next, local] : dag[i].at(state)) {
            if (++steps > MAX_TRANSITIONS) throw std::runtime_error("descriptor trial cap");
            record(dag, i + 1, next,
                   {prefix.syn ^ local.syn, prefix.a ^ local.a, prefix.coframe | local.coframe},
                   out, steps);
        }
    }
    std::vector<Signature> descriptors(const Count& c) const {
        std::vector<Signature> result;
        result.reserve(size_t(c.leaves));
        U64 steps = 0;
        if (c.leaves) record(compile(), 0, 0, {}, result, steps);
        if (result.size() != c.leaves || steps != c.live_steps)
            throw std::runtime_error("descriptor tally mismatch");
        std::sort(result.begin(), result.end(),
                  [](const auto& a, const auto& b) { return a.syn < b.syn; });
        return result;
    }
    void report(const Count& c, int parity) const {
        int first_close = 9;
        for (int r : last) first_close = std::min(first_close, r + 1);
        std::cout << "side " << parity << " sources";
        for (int x : sources) std::cout << ' ' << x;
        std::cout << " first full star " << first_close << " states " << states
                  << " memo trials " << work << " completions " << dec(c.leaves)
                  << " live-prefix transitions " << dec(c.live_steps)
                  << " prospective histogram trials " << dec(c.trials) << "\n";
    }
};
void run(const Geometry& g, const std::string& sector, const std::string& order,
         const std::string& mode) {
    Sites m{}, top{};
    top.fill(8);
    if (sector == "uniform") m.fill(2);
    else if (sector == "checker")
        for (int x = 0; x < 16; ++x) m[x] = std::popcount(unsigned(x)) % 2 == 0 ? 4 : 0;
    else if (sector == "control") {
        top.fill(0); top[0] = 4; top[1] = top[2] = 2; m[0] = 2;
    } else throw std::runtime_error("unknown sector");
    std::cout << sector << ' ' << order << ' ' << mode << '\n';
    Side even(g, m, top, 0, order, mode), odd(g, m, top, 1, order, mode);
    Count a = even.count(0, 0), b = odd.count(0, 0);
    even.report(a, 0); odd.report(b, 1);
    std::cout << "saturated products " << dec(U128(a.leaves) * b.leaves) << '\n';
    if (mode == "loads") return;
    const bool compiled = mode == "compiled" || mode == "directed";
    if (a.leaves > MAX_COMPLETIONS || b.leaves > MAX_COMPLETIONS ||
        (compiled ? a.live_steps : a.trials) > MAX_TRANSITIONS ||
        (compiled ? b.live_steps : b.trials) > MAX_TRANSITIONS) {
        std::cout << "REFUSED before histogram allocation\n";
        return;
    }
    const auto left = even.histogram(a, compiled), right = odd.histogram(b, compiled);
    U128 surviving = 0;
    for (const auto& [syn, mass] : left) {
        auto it = right.find(syn);
        if (it != right.end()) surviving += U128(mass) * it->second;
    }
    std::cout << "syndrome counts " << left.size() << ' ' << right.size()
              << " undirected survivors " << dec(surviving) << '\n';
    if (mode != "directed") return;
    if (surviving > MAX_JOIN_PAIRS ||
        (a.leaves + b.leaves) * sizeof(Signature) > MAX_DESCRIPTOR_BYTES) {
        std::cout << "REFUSED before directed descriptor allocation\n";
        return;
    }
    const auto e = even.descriptors(a), o = odd.descriptors(b);
    size_t i = 0, j = 0;
    U64 checked = 0, directed = 0;
    while (i < e.size() && j < o.size()) {
        if (e[i].syn < o[j].syn) { ++i; continue; }
        if (o[j].syn < e[i].syn) { ++j; continue; }
        size_t ei = i + 1, oj = j + 1;
        while (ei < e.size() && e[ei].syn == e[i].syn) ++ei;
        while (oj < o.size() && o[oj].syn == o[j].syn) ++oj;
        checked += (ei - i) * (oj - j);
        for (size_t x = i; x < ei; ++x)
            for (size_t y = j; y < oj; ++y) {
                const Word mismatch = (e[x].a ^ o[y].a) & ~(e[x].coframe | o[y].coframe);
                directed += mismatch == 0;
            }
        i = ei; j = oj;
    }
    if (checked != surviving) throw std::runtime_error("directed tally mismatch");
    std::cout << "descriptor bytes " << (e.size() + o.size()) * sizeof(Signature)
              << " checked pairs " << checked << " directed survivors " << directed << '\n';
}

int main(int argc, char** argv) {
    if (argc != 4) return 2;
    try {
        run(Geometry{}, argv[1], argv[2], argv[3]);
    } catch (const std::runtime_error& e) {
        std::cerr << e.what() << '\n';
        return 3;
    }
}
