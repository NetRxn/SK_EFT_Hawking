from fractions import Fraction
from itertools import product, combinations
from collections import Counter
from src.core.formulas import original_plaquette, original_spin4_link, original_quaternion_haar_moment
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol, matrix_multiply

reg = OriginalRegulator()
k, ell = 2, 3
face = [(0, 0, a, b) for a, b in product(range(2), repeat=2)]
anchors = [(x, axis) for x in face for axis in (k, ell)]
indices = {e: i for i, e in enumerate(anchors)}
links = {e: original_spin4_link(*[
    tuple(Polynomial.variable(Symbol("q", (*e, chi, j))) for j in range(4))
    for chi in ("L", "R")
]) for e in anchors}
gamma = reg.gamma
insertion = matrix_multiply(matrix_multiply(gamma[0], gamma[1]), reg.gamma5)
def trace(u):
    return sum((u[i][j] * insertion[j][i] for i in range(4) for j in range(4)), Polynomial())

terms = []
anchor_slots = []
for x in face:
    p = (trace(original_plaquette(reg, x, k, ell, links))
         - trace(original_plaquette(reg, x, ell, k, links))) * Fraction(1, 2)
    row = {}
    for key, coeff in p.terms:
        chi, = {symbol.index[-2] for symbol in key}
        slots = tuple(indices[symbol.index[:2]] for symbol in key)
        if not row:
            anchor_slots.append(slots)
        else:
            assert slots == anchor_slots[-1]
        assert coeff.imag == 0 and coeff.real.denominator == 1
        row[chi, tuple(symbol.index[-1] for symbol in key)] = int(coeff.real)
    assert len(row) == 128
    terms.append(row)
assert Counter(i for row in anchor_slots for i in row) == {i: 2 for i in range(8)}
assert all(set(a) ^ set(b) for a, b in combinations(anchor_slots, 2))
neighbors = [set() for _ in face]
for i, j in combinations(range(4), 2):
    if set(anchor_slots[i]) & set(anchor_slots[j]):
        neighbors[i].add(j); neighbors[j].add(i)
assert all(len(s) == 2 for s in neighbors)
# Each used anchored variable occurs twice. Coordinate parity forces equal
# coordinate and chirality on its two appearances. The rooted overlap graph
# is a connected square, so there is one common chirality per surviving key.
sum_int = 0
for chi in ("L", "R"):
    subtotal = 0
    for values in product(range(4), repeat=8):
        term = 1
        for slots, table in zip(anchor_slots, terms):
            term *= table.get((chi, tuple(values[i] for i in slots)), 0)
        subtotal += term
    print("four-root trace numerator", chi, subtotal)
    sum_int += subtotal
answer = sum_int * original_quaternion_haar_moment((2, 0, 0, 0)) ** 8
print("each one-root and each distinct two-root moment vanishes by singleton anchors")
print("joint four-root moment", answer)
assert answer == 0

# At each root, average the curvature square over its independent local
# Spin(4) gauge rotation. Verify from the literal trace that each chiral
# curvature contribution has magnitude twice one imaginary quaternion
# component, so its averaged square is 1 - chi_adj(H)/3.
root = face[0]
holonomy_symbols = [
    tuple(Symbol("q", (root, k, chi, j)) for j in range(4))
    for chi in ("L", "R")
]
holonomy = original_spin4_link(*[
    tuple(Polynomial.variable(s) for s in row) for row in holonomy_symbols
])
one_trace = trace(holonomy)
assert len(one_trace.terms) == 2
assert {key[0].index[-2] for key, _ in one_trace.terms} == {"L", "R"}
assert all(len(key) == 1 and key[0].index[-1] > 0 and abs(coeff.real) == 2
           and coeff.imag == 0 for key, coeff in one_trace.terms)
print("literal one-holonomy F01 coefficients",
      [(key[0].index[-2:], coeff.storage) for key, coeff in one_trace.terms])

# In the adjoint representation the real link matrices have
# integral R_ab R_cd = delta_ac delta_bd / 3. For the closed word
# D^t C^t B A, match the row and column indices of each link's two
# occurrences after transposing the daggered occurrence.
matches = {a: [] for a in anchors}
for i, x in enumerate(face):
    a, b = (x, k), (reg.step(x, k)[0], ell)
    c, d = (reg.step(x, ell)[0], k), (x, ell)
    for j, (anchor, reverse) in enumerate(((d, True), (c, True), (b, False), (a, False))):
        u, v = 4 * i + j, 4 * i + (j + 1) % 4
        matches[anchor].append((v, u) if reverse else (u, v))
parents = list(range(16))
def rep(i):
    while parents[i] != i:
        i = parents[i]
    return i
for ends in matches.values():
    assert len(ends) == 2
    for u, v in zip(*ends):
        parents[rep(u)] = rep(v)
free = len({rep(i) for i in range(16)})
moment = Fraction(3) ** (free - 8)
square_moment = 16 + 2 * moment / 3 ** 4
print("adjoint-character equality classes", free, "joint character moment", moment)
print("four-root joint square moment", square_moment,
      "versus product of separate square moments", 16)
assert square_moment > 16

# Build all chiral vectors in the literal C convention. F is the
# antisymmetrized trace, which equals the raw trace off diagonal.
vectors = {}
for a, b in product(range(4), repeat=2):
    current = matrix_multiply(matrix_multiply(gamma[a], gamma[b]), reg.gamma5)
    p = sum((holonomy[i][j] * current[j][i] for i in range(4) for j in range(4)),
            Polynomial()) if a != b else Polynomial()
    by_symbol = {key[0]: coeff for key, coeff in p.terms}
    for row, chi in zip(holonomy_symbols, ("L", "R")):
        vals = [by_symbol.get(s) for s in row]
        assert vals[0] is None
        assert all(q is None or q.imag == 0 for q in vals)
        vectors[a, b, chi] = tuple(q.real / 2 if q is not None else 0 for q in vals[1:])
def gram(a, b, c, d, chi):
    return sum(x * y for x, y in zip(vectors[a, b, chi], vectors[c, d, chi]))
g_l, g_r = (gram(0, 1, 2, 3, chi) for chi in ("L", "R"))
assert (g_l, g_r) in ((-1, 1), (1, -1))
cross = (g_l + g_r) ** 4 + moment * (g_l ** 4 + g_r ** 4) / 3 ** 4
assert cross == Fraction(2, 6561)
print("mixed component local G_L,G_R", g_l, g_r,
      "four-root F01*F23 moment", cross)
