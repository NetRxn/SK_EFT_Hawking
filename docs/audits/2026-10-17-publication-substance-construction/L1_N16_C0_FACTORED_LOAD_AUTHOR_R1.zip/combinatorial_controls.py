from itertools import combinations, permutations
from math import comb

even = [x for x in range(16) if x.bit_count() % 2 == 0]
odd = [x for x in range(16) if x.bit_count() % 2 == 1]
matchings = []
for ys in permutations(odd):
    if not all((x ^ y).bit_count() == 1 for x, y in zip(even, ys)):
        continue
    matchings.append(sum(1 << (4 * i + ((x ^ y).bit_length() - 1))
                         for i, (x, y) in enumerate(zip(even, ys))))
assert len(matchings) == 272
factors = {a | b for a, b in combinations(matchings, 2) if a & b == 0}
assert len(factors) == 2970
print("independent union of disjoint matchings 2-factor count", len(factors))
print("all-even uniform-M paired coarse survivors", len(factors) ** 2)

dp = [1]
for i in range(16):
    nxt = [0] * (len(dp) + 4)
    for j, n in enumerate(dp):
        for k in range(5):
            nxt[j + k] += n
    dp = nxt
inc_excl = sum((-1) ** k * comb(16, k) * comb(47 - 5 * k, 15) for k in range(7))
assert dp[32] == inc_excl
print("center-total rosters before neighbor-capacity checks", dp[32])
