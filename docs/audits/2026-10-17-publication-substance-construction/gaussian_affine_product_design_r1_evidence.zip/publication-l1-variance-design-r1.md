# L1 positive-variance and finite-product Hermite construction design R1

**DESIGN ONLY, ready for independent mathematical/source review, not proof acceptance.**
Primary source is `2fbbfd95a396cadfd89961dea226d84c4f281675`. First and final checks
of the SAME original continuity packet are fresh/unchanged. Only the assigned
`/tmp` Markdown/JSON are written. No source edit, Lean/LSP/build/controller/runtime,
cache/dependency mutation, Git mutation or scientific simulation was performed.
ROOT owns dispatch, native qualification, integration, notebook and acceptance.

## Existing substrate and the actual remaining composition

Read the complete accepted GaussianPolynomialHermite and GaussianPolynomialIBP
modules and the complete 98-line exact auxiliary construction. Read the actual
Gaussian affine theorem/proof, relevant Mathlib statements/proofs below, source
contexts, agent/continuity/Lean4 guidance and current notebook/roadmap. Existing
secondary Gaussian modules were inspected in the specific sections stated below;
this is not a full scientific re-audit of every such module.

- `Detection/GaussianThreshold.lean:237`: actual
  `SKEFTHawking.Detection.gaussianReal_map_affine {c : ℝ} {v : ℝ≥0}
  (hv : (v : ℝ) = c^2) (μ : ℝ)` proves
  `(gaussianReal 0 1).map (fun y ↦ c*y+μ) = gaussianReal μ v`.
  Its proof calls Mathlib's multiply/add pushforwards. It already covers every
  scale and mean (including zero/negative scale); do not re-prove this bridge.
  The actual typed index record has no project axioms, standard three only.
  Latest source-history commit inspected: `b23696844d1284cffa1fa52cb2184d1e701e32a2`
  (31 July). This is a concrete reuse opportunity, not a missing-substrate claim.
- `ADW/GaussianPolynomialHermite.lean` is exact accepted author
  `bfb8ca2576ccdfb25ad2ebf3bebc1a2bfb7d9fc0`: actual standard-Gaussian integrability,
  arbitrary-n/p Hermite integration by parts, mixed monomial reduction and all-degree
  orthogonality/norm. Its source and `.olean` exist. Reuse these, not a new expectation.
- Mathlib `Probability/Distributions/Gaussian/Real.lean:329,309` already has
  `gaussianReal_map_const_mul`, `gaussianReal_map_add_const`; `:579,584` proves
  `memLp_id_gaussianReal`/`memLp_id_gaussianReal'` for all finite Lp exponents.
  Its Gaussian argument `v : ℝ≥0` is **variance**, not standard deviation.
- Mathlib `MeasureTheory/Integral/Pi.lean:65,106` has the actual methods
  `MeasureTheory.Integrable.fintype_prod` and
  `MeasureTheory.integral_fintype_prod_eq_prod`; the file's introductory prose
  uses an older-looking lowercase name, so the actual declaration is authoritative.
  This already proves finite independent-coordinate product integrability/Fubini.
- `QuantumNetwork/GaussianWick.lean:33` already supplies all-multi-index unnormalized
  factorization `gaussInt_monomial`. The degree≤4 restriction in `moment_eq_wval`
  and sphere/Wick consumers is NOT a restriction on that factorization theorem.
  Reuse Mathlib's direct probability-product theorem for the present representation;
  the older result remains a genuine related asset, not missing work.
- `AnisotropicGaussianFT.lean:113` already proves arbitrary-dimension complex Gaussian
  linear-source integration `integral_cexp_neg_quadratic_form` with PosDef G and
  positive real part of b. Mathlib `Gaussian/FourierTransform.lean:251,292` already
  has `GaussianFourier.integrable_cexp_neg_mul_sum_add` and
  `GaussianFourier.integral_cexp_neg_mul_sum_add`, for arbitrary finite type and
  complex source. These are possible generating-function assets downstream.
- `QuantumNetwork/GaussianComplexMoment.lean:43` is a genuine complex sphere
  coordinate/moment development; it is not the same measure/observable as arbitrary
  signed complex auxiliary W. Do not count it as the latter by name similarity.
- `HubbardStratonovichRHMC.lean:48` actually proves `hsGaussianAction 0 g=0`.
  The surrounding docstring's full integral/sign claim does not turn this theorem
  into the missing signed polynomial representation. Keep existing debt linked;
  do not restore the false negative sign for a real hX coupling.

**Discovery boundary:** no Lean lease was granted to this read-only design author, so this author made no LSP query.
The primary typed `lean_deps.json` has zero ADW Gaussian rows despite both actual
IBP/Hermite sources and `.olean`s being present. A build does not itself rerun the
canonical extractor. This positive source/index discrepancy prevents using index
absence as absence of substrate. Source/types/history and known positive matches
were inspected; final no-duplicate admission still requires the worker's actual
statement/type LSP search in the correct import context. No exhaustive absence
claim or new proof commission is inferred from this bounded design search.

## Exact first-package contract

Use actual `gaussianReal μ v`, `σ : ℝ`, `hσ : 0<σ`, `hv : (v:ℝ)=σ²`.
For every natural n and **every** p:ℝ[X], prove genuine integrability of p and the
entire Hermite-product insertion, then

`E_N(μ,v)[He_n((X-μ)/σ) p(X)] = σ^n E_N(μ,v)[(D^n p)(X)]`.

No degree cap, assumed moment/Stein premise, supplied integration-by-parts axiom,
new project axiom or custom measure is allowed. Positivity of σ provides the
nonzero denominator and actual positive variance; a separate v>0 premise would
be redundant. The theorem concerns probabilists' Hermite, with no √2 scaling.
A schematic Lean contract is retained verbatim in the companion JSON; it is
not an elaborated file and must not be represented as one.

Suggested implementation home: a new mathematical module
`ADW/GaussianPolynomialAffine.lean`, importing the exact Hermite module and the
existing Detection GaussianThreshold bridge, plus narrowly needed measure tools.
The bridge's module also imports ReadoutRelaxationBound; inspect final import DAG
and cost before admission. Avoid moving/refactoring shared APIs just to avoid this
already-existing dependency, and do not duplicate the affine theorem. No gate,
planner, registry or controller extension is needed. A generic integral-map
wrapper should remain a local helper unless repeated use justifies a public API.

## Constructive proof sequence

1. Set `a=C σ*X+C μ` and `q=p.comp a`. Then q.eval z=p.eval(σ*z+μ).
   Standard polynomial integrability of q gives actual target integrability by
   rewriting the measure with existing `Detection.gaussianReal_map_affine hv μ`
   and using `integrable_map_measure` (its `.2` direction). Continuity of polynomial
   evaluation supplies the required AEStronglyMeasurable premise. Do not use
   `Integrable.comp_measurable` backwards: it maps target integrability to a pullback.
2. For the whole insertion use polynomial
   `(realHermite n) * q` under N(0,1). Pullback of the target integrand equals this
   evaluation because `((σ*z+μ)-μ)/σ=z` for σ≠0. Apply accepted
   `integrable_hermite_mul n q` (or polynomial-product integrability) and the same
   map-integrability equivalence. This proves absolute integrability before any
   integral identity is invoked. D^n p also falls under polynomial integrability.
3. A small algebraic helper proves, by induction on n,
   `D^n(p.comp a)=C(σ^n)*((D^n p).comp a)`.
   Exact inspected APIs: `Polynomial.derivative_comp` (Derivative.lean:586),
   `Polynomial.derivative_C_mul` (:155), `Polynomial.derivative_C_mul_X` (:89),
   derivative_add/C and iteration successor. The formal derivative chain rule is
   `D(p.comp a)=D a * (D p).comp a`. No analytic differentiation under an integral
   is necessary. The only exact iterated-comp special form found in these source
   sections is `iterate_derivative_comp_one_sub_X`; this is a bounded observation,
   not an exhaustive statement that a general affine lemma is absent elsewhere.
4. Rewrite both target integrals through the exact pushforward using
   `MeasureTheory.integral_map` (Bochner/Basic.lean:1043) with its actual measurable
   hypotheses. Reduce the left to existing `integral_hermite_mul n q`. Replace
   D^n q with the chain helper, pull out σ^n using `integral_const_mul`, and push
   the right back to N(μ,v). Every side's genuine integrability was proved in1-2.
5. Reuse the carrying theorem for actual mixed centered-monomial coefficients,
   zero/diagonal/orthogonality checks and the σ=1,μ=0 specialization. Do not ship
   a large collection of wrappers instead of the carrying theorem. These checks
   protect normalization, not a substitute for the general quantified result.

Manual normalization checks: n=0 gives E[p]=E[p]. n=1,p=(X-μ) gives σ (not v).
n=2,p=(X-μ)² gives2σ²; both sides use actual E[Y²]=σ²,E[Y⁴]=3σ⁴.
Omitting σ^n, replacing it with v^n, or using physicists' Hermite would fail these.
For n greater than degree p the derivative is zero, but the theorem remains
nonvacuous for all degrees; no bound is installed on its statement.

## Finite-dimensional lift: full coefficient contract and APIs

Let ι be ANY Fintype (including the empty type), σᵢ>0,
vᵢ:ℝ≥0 with vᵢ=σᵢ², μᵢ:ℝ, and actual product measure
`ν=Measure.pi (fun i ↦ gaussianReal (μ i) (v i))`.
The probability/sigma-finiteness instances follow from those of gaussianReal.
For arbitrary α:ι→ℕ and a family pᵢ:ℝ[X], define the explicit integrand
`∏i [He_(αi)((h_i-μ_i)/σ_i) * p_i(h_i)]`.
Use actual `Integrable.fintype_prod` on the already proved per-coordinate integrals,
then `integral_fintype_prod_eq_prod` to obtain EXACTLY

`∫ ∏i He_(αi)((h_i-μ_i)/σ_i) p_i(h_i) dν
 = ∏i [σ_i^(αi) * ∫ (D^(αi)p_i)(x) dN(μ_i,v_i)]`.

No new Fubini theorem, independence assumption or supplied factorization identity
is needed. Independence is represented by the explicit product measure. Every
factor and finite product must have a separate integrability theorem even though
Mathlib's scalar product integral formula can be stated without it (totalization
would otherwise conceal a failed integrability obligation).

For original auxiliary Eq6, set μᵢ=0, commonσ and pᵢ=X^(βᵢ). The resulting full
all-α,β coefficient formula is

`∫ ∏i He_(αi)(h_i/σ) h_i^(βi) dν
 = ∏i [σ^(αi) * (βi.descFactorial (αi):ℝ)
       * ∫ x^(βi-αi) dN(0,σ²)]`.

Natural subtraction is harmless for βi<αi because the descending factorial is
zero; do not rewrite negative exponents or divide by a disappearing coefficient.
For2coordinates α=β=(1,1), the result isσ²; multiplying by the original W factor
σ^(-2) gives1 as required. The empty-coordinate case is integral1=1, not a domain
requiring dimension>0. Original per-site dimension16 and whole finite-lattice
site products are specializations, never hard-coded degree/dimension ceilings.

General real MvPolynomial integrability follows from `MvPolynomial.as_sum`
(Basic.lean:968), actual `eval_monomial`/`eval_sum` (Eval.lean:267,295), finite-sum
integrability and the monomial product result. Multiplication by the multivariate
Hermite polynomial is still polynomial. Complex coefficients are finite complex
linear combinations of integrable real monomials; use actual
`MeasureTheory.integral_complex_ofReal` (Bochner/ContinuousLinearMap.lean:162),
complex scalar linearity and the continuous real-to-complex linear isometry for
integrability. This is W(h,Ω) over real h, not a replacement complex Gaussian h.

A full multivariate derivative statement can be proved monomial-by-monomial using
actual `MvPolynomial.pderiv` and `pderiv_monomial` (PDeriv.lean:59,70). If choosing
an ordered mixed-derivative operator, derive its coordinate-order independence
from the actual monomial formula rather than assume commuting derivatives. For
Eq6's finite coefficient acceptance, the all-multi-index monomial identity plus
finite linearity is already the needed coefficient foundation; stopping at a
single separable polynomial is not acceptance of a general p/W.

## From coefficient identities to original Eq6-11 (still owed)

A. Obtain all standard Gaussian monomial values, if the admitted discovery does
not already locate an exact matching general result. Existing GaussianMoments has
second/fourth and all odd unnormalized moments; do not mistake that for a global
absence of all-order Gaussian moments. An available derivation from actual IBP is
m_(k+1)=k*m_(k-1), m0=1,m1=0, hence m_(2r)=(2r)!/(2^r*r!) and odd moments0.
This is a proof route, not a new claimed compiled result.
B. Expand exp(h·X) coefficientwise: coefficientβ is h^β/β!, apply the full product
formula, and prove σ^(-|α|) cancellation and the compensating exp(σ²ΣX²/2)
convolution. The resulting finite coefficients must agree for every β up to the
actual nilpotence bound M, with no analytic series/integral exchange assumed.
C. Retain complex p_(x,α)(Ω), finite degree truncation and arbitrary finite coupling
signs. Prove evaluation into the actual commuting even Grassmann algebra kills
all degrees>M; then Eq7 follows from cancellation of the two formal Gaussian
series. No positivity or division by W is used at its zeros.
D. Assemble site products and the actual oriented coframe bilinear matrix; prove
Berezin determinant orientation and compact-link/coefficient integrability and
all exchanges for actual constructed link dependence, not arbitrary unproved
boundedness placeholders. Normalized correlators require Z≠0.
E. Derive Eq11 with the derivative of the ENTIRE W times polynomial coefficient
insertion. For centered N(0,σ²), `E[h_i F]=σ² E[∂iF]`. Taking formal coefficient
F=W exp(h·T) gives BOTH ∂iW and W*T_i; omitting ∂iW or declaring h/σ² physical T
would fail the original objective. Nonzero μ adds μ_i E[F], so use μ=0 here.
F. Independently qualify exact source/MCP kernel closure, actual native root and
ExtractDeps, canonical count/table artifacts and closure, before scientific or
publication acceptance. The original physical source/Legendre state, tensor
modes/matter/transport, calibrated normalization/window, continuum/thermal/order
and simulation obligations remain OPEN BUILD. None follows from this supporting
Gaussian composition or a scoped manual mathematical acceptance.

## Proof-ready next package and admission requirements

1. ROOT accepts a fresh independent mathematical/source review of this design.
2. ROOT admits a correct current wt slot; worker first uses Lean4 LSP by statement
   and type to locate possible existing affine derivative/Hermite implementations,
   reconciles imports/build index/history and records discoveries. Reuse any exact
   stronger implementation. No slot is leased or granted by this report.
3. Implement the arbitrary-positive-variance one-dimensional carrying theorem and
   genuine integrability plus finite-coordinate product application in ONE coherent
   assigned module, preserving all prior statements. Report any new import .olean
   need to ROOT; never build/repair it independently. No source/planner extension.
4. Worker supplies all actual diagnostics/goals/verify axiom receipts; independent
   reviewer checks the full quantified contract, normalization and nonvacuity.
   ROOT integrates and qualifies actual main candidate; full auxiliary continuation
   remains active rather than marking Eq6-11 or B3 complete at this milestone.

The design is mathematically a composition of identified existing assets. Its
Lean snippets are unelaborated, and no exact implementation-completeness verdict
is issued before the required admitted LSP search and independent review.

## Coordination readback at completion

ROOT reported a fresh complete controller census and normal wt1 acquisition/prepare
at primary2fbb/current epoch. A separate matching worker is performing actual
read-only LSP discovery/axiom inspection. This author has not consumed those
results and does not attribute them to this source-only design. The main full
merge-profile build lock is not a blanket prohibition on properly admitted LSP.
ROOT will reconcile that actual discovery before commissioning implementation.
