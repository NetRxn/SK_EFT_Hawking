from ast import literal_eval as parse
from collections import Counter,defaultdict
from dataclasses import dataclass,field
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
from sys import argv
import sys

WORK=32_000_000
ROWS=800_000
BITS=256
source=Path('compact-boundary.py').read_text()
start=source.index('def width(')
end=source.index('tally=0',start)
definitions=source[start:end]
start=definitions.index('for f in factors:')
end=definitions.index('def indices',start)
definitions=definitions[:start]+definitions[end:]
start=source.index('@dataclass')
end=source.index('def bind(',start)
exec(source[start:end]+definitions)

def load(path):
    with path.open() as file:
        raw,denom,name=next(file).rstrip('\n').split('\t')
        rows={}
        for line in file:
            h,r,i=line.split()
            key=int(h,16)
            assert key not in rows and len(rows)<ROWS
            rows[key]=int(r),int(i)
    return Factor(name,parse(raw),rows,int(denom))

def eligible(fs):
    columns=defaultdict(list)
    for i,f in enumerate(fs):
        for w in f.wires:columns[w].append(i)
    assert all(len(rows)==2 for rows in columns.values())
    choices=[]
    for i,j in sorted({tuple(x) for x in columns.values()}):
        A,B=fs[i],fs[j]
        cols=indices(A,B)
        n=work(A,B,cols)
        score=n*(1+len(A.wires)+len(B.wires)-2*len(cols))
        choices.append((score,n,i,j,cols))
    return sorted(choices), columns

def splits(fs):
    choices,columns=eligible(fs)
    _,n,i,j,cols=choices[0]
    boundary=(set(fs[i].wires)|set(fs[j].wires))-set(cols)
    candidates=[]
    for w in sorted(boundary):
        if w[0]!='R':continue
        a,b=columns[w]
        ha,hb=buckets(fs[a],(w,)),buckets(fs[b],(w,))
        domain=sorted(ha.keys()&hb.keys())
        if len(domain)<2:continue
        count=[ha[k]*hb[k] for k in domain]
        width=sum(count)
        # Balance product reduction across all values on this wire.
        candidates.append((Fraction(max(count),width),-width,w,domain))
    return sorted(candidates)

files=sorted(Path('frontier5').glob('*.tsv'))
assert files
all_factors=[load(f) for f in files]
fs=[f for f in all_factors if f.wires]
assert len(fs)==5
scalars=[f for f in all_factors if not f.wires]
if len(argv)<=1:
    for result in splits(fs)[:12]:print(result)
    sys.exit()

choices=splits(fs)
_,_,wire,domain=choices[int(argv[1])]
v=int(argv[2])
assert v in domain
for f in fs:
    if wire in f.wires:
        recipe=estimate(f.wires,(wire,))
        f.rows={key:z for key,z in f.rows.items() if extract(key,recipe)==v}
        f.histograms.clear()
print('tile',wire,v,'full domain',domain,flush=True)
count=0
budget=90_000_000
while fs:
    for f in fs[:]:
        if not f.wires:
            scalars.append(f);fs.remove(f)
    if not fs:break
    deleted=prune(fs,rounds=2)
    if any(not f.rows for f in fs):
        print('EXACT ZERO',count)
        sys.exit()
    options,_=eligible(fs)
    for _,products,i,j,cols in options:
        if products>WORK or count+products>budget:continue
        count+=products
        try:
            C=join(fs[i],fs[j],cols,products)
        except RuntimeError as e:
            print('REFUSED JOIN',str(e),products,flush=True)
            continue
        print('join',len(fs),products,len(C.rows),'pruned',deleted,flush=True)
        if not C.rows:
            print('EXACT ZERO',count);sys.exit()
        fs.pop(j);fs.pop(i);fs.append(C)
        break
    else:
        print('OPEN TILE',len(fs),count,min(n for _,n,*_ in options))
        sys.exit(3)
r,n=Fraction(1),Fraction(0)
for f in scalars:
    a,b=f.rows[0]
    a,b=Fraction(a,f.denom),Fraction(b,f.denom)
    r,n=r*a-n*b,r*b+n*a
print('EXACT TILE before insertion factorial',r,n,'products',count)
