from collections import Counter,defaultdict
from dataclasses import dataclass
from pathlib import Path
from itertools import combinations
from ast import literal_eval as parse
from fractions import Fraction as F
from math import lcm
import sys

sys.path.insert(0,str(Path("INDEPENDENT").absolute()))
from census import occupancy
O=[occupancy(code) for code in (103607566400,1256282136720)]
cap_rows=300_000
cap_work=4_000_000
cap_total=20_000_000
cap_bits=256
roots=defaultdict(dict)
for l in Path('OLD/states.tsv').read_text().splitlines():
    c,t,x,k,p,q=map(int,l.split())
    roots[c][t,x,k]=p,q
plans=defaultdict(dict)
for l in Path('OLD/anchor-plan.tsv').read_text().splitlines():
    c,t,x,k,*shape=map(int,l.split())
    plans[c][t,x,k]=tuple(shape)
patterns={}
for i,l in enumerate(l for l in Path('SEWN/edge-plan.out').read_text().splitlines() if l.startswith('pattern ')):
    patterns[parse(l[8:l.rindex(')')+1])]=i
temporal=defaultdict(list)
for l in Path('OLD/temporal.tsv').read_text().splitlines():
    shape,rows,cols,r,s=l.split('\t')
    temporal[parse(shape)].append((tuple(x for ij in zip(parse(rows),parse(cols)) for x in ij),(F(r),F(s))))

@dataclass
class Table:
    names:tuple
    keys:tuple
    rows:dict
    scale:int
def make(name,keys,entries):
    actual=tuple(k for k in keys if k is not None)
    scales=[]
    raw={}
    for row,z in entries:
        assert len(row)==len(keys)
        assert all(k is not None or not x for k,x in zip(keys,row))
        key=tuple(x for k,x in zip(keys,row) if k is not None)
        assert key not in raw and len(raw)<cap_rows
        raw[key]=z
        scales.extend(v.denominator for v in z)
    assert len(actual)==len(set(actual)) and raw
    d=lcm(*scales)
    return Table((name,),actual,{k:tuple(int(v*d) for v in z) for k,z in raw.items()},d)

def build(case,name):
    state=roots[case]
    t,x,tag=(int(k) for k in name[1:]+('0' if len(name)==3 else ''))
    def wires(layer,site,axis,column):
        return tuple((layer,site,axis,column,h) if s else None
                     for h,s in enumerate(state.get((layer,site,axis),(0,0))))
    def label(site,k):return ((t,site,k,'mask'),(t,site,k,'word'))
    if name[0]=='T':
        roster=[];ks=[]
        for (layer,y,k),s in sorted(state.items()):
            q=s[tag]
            if layer!=t or not q or x not in (y,y^(1<<k)):continue
            outgoing=(x==y)
            roster.append((q,bool(t^int(not outgoing))))
            for column in ((3,4) if outgoing else (1,2)):
                ks.append(wires(t,y,k,column)[tag])
        return make(name,tuple(ks),temporal[tuple(roster)])
    if name[0]=='E':
        k=tag;y=x^(1<<k)
        load=lambda v:sum(O[t][v])-O[t][v][k]
        p=patterns[load(x),load(y),plans[case][t,x,k],plans[case][t,y,k]]
        keys=label(x,k)+label(y,k)
        for v in (x,y):
            for side,cols in ((t,(0,1)),(1-t,(2,3))):
                for c in cols:keys+=wires(side,v,k,c)
        def entries():
            for l in Path(f'SEWN/edge-batch/{p:02}.tsv').open():
                a,b,m,A,B,r,s=l.split('\t')
                mask=int(m)
                row=(mask&255,parse(a),mask>>8,parse(b))
                row+=tuple(z for pair in (*parse(A),*parse(B)) for z in pair)
                yield row,(F(r),F(s))
        return make(name,keys,entries())
    assert name[0]=='S'
    active=[k for k,n in enumerate(O[t][x]) if n]
    keys=tuple(w for k in range(3) for w in label(x,k))
    for k in active:
        keys+=wires(t,x,k,4)+wires(t,x,k,0)
    def entries():
        for l in Path(f'SEWN/site/{case}-{t}-{x}.tsv').open():
            w,m,rs,re,im=l.split('\t')
            values=tuple(z for entry in zip(parse(m),parse(w)) for z in entry)
            rs=parse(rs)
            assert len(rs)==2*len(active)
            for j,k in enumerate(active):
                base=state.get((t,x,k),(0,0))[1]+1
                values+=divmod(rs[2*j],base)+divmod(rs[2*j+1],base)
            yield values,(F(re),F(im))
    return make(name,keys,entries())

def select(key,idx):return tuple(key[i] for i in idx)
def pairs(a,b):
    shared=tuple(x for x in a.keys if x in b.keys)
    L=tuple(a.keys.index(k) for k in shared)
    R=tuple(b.keys.index(k) for k in shared)
    return L,R
def forecast(a,b,L,R):
    left=Counter(select(k,L) for k in a.rows)
    right=Counter(select(k,R) for k in b.rows)
    return sum(v*right[k] for k,v in left.items())
def join(a,b,L,R,n):
    assert n<=cap_work
    height=[max((abs(x)+abs(y)).bit_length() for x,y in t.rows.values()) for t in (a,b)]
    assert sum(height)+n.bit_length()<=cap_bits
    p=tuple(i for i in range(len(a.keys)) if i not in L)
    q=tuple(i for i in range(len(b.keys)) if i not in R)
    groups=defaultdict(list)
    for k,z in b.rows.items():groups[select(k,R)].append((select(k,q),z))
    out={}
    seen=0
    for k,(a0,a1) in a.rows.items():
        prefix=select(k,p)
        for suffix,(b0,b1) in groups.get(select(k,L),()):
            seen+=1
            k0=prefix+suffix
            prev=out.get(k0,(0,0))
            got=(prev[0]+a0*b0-a1*b1,prev[1]+a0*b1+a1*b0)
            if any(got):
                assert k0 in out or len(out)<cap_rows
                out[k0]=got
            else:out.pop(k0,None)
    assert seen==n
    return Table(a.names+b.names,select(a.keys,p)+select(b.keys,q),out,a.scale*b.scale)

def reproduce(case,names):
    factors=[build(case,n) for n in reversed(names)]
    degree=Counter(k for f in factors for k in f.keys)
    assert set(degree.values())=={1,2}
    boundary={k for k,n in degree.items() if n==1}
    total=0;max_step=0
    sizes=[len(f.rows) for f in factors]
    while len(factors)>1:
        choices=[]
        for i,j in combinations(range(len(factors)),2):
            a,b=factors[i],factors[j]
            L,R=pairs(a,b)
            if L:choices.append((forecast(a,b,L,R),-i,-j,L,R))
        count,ni,nj,L,R=min(choices)
        i,j=-ni,-nj
        assert total+count<=cap_total
        total+=count
        max_step=max(max_step,count)
        t=join(factors[i],factors[j],L,R,count)
        sizes.append(len(t.rows))
        factors=[f for k,f in enumerate(factors) if k not in (i,j)]+[t]
        if not t.rows:break
    assert not t.rows
    outside=Counter(k for f in factors for k in f.keys)
    assert {k for k,n in outside.items() if n==1}==boundary
    print(case,'open-boundary zero, external wires',len(boundary),
          'largest factor',max(sizes),'max matched join',max_step,'total matched',total,flush=True)
for l in Path('NETWORK/legacy-subset/witnesses-first.out').read_text().splitlines():
    i,names,*_=l.split()
    reproduce(int(i),names.split(','))
