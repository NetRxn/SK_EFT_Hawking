import ast
from collections import Counter,defaultdict
from math import prod
from itertools import product
from pathlib import Path
from functools import cache
import sys

root=Path('INDEPENDENT')
sys.path.insert(0,str(root.absolute()))
from census import profile,occupancy
proj=ast.parse((root/'project.py').read_text())
parts=[p for p in proj.body if isinstance(p,(ast.FunctionDef,ast.Import,ast.ImportFrom))]
scope={}
exec(compile(ast.Module(body=parts,type_ignores=[]),'project.py','exec'),scope)
a,b=(103607566400,1256282136720)
assert sum(n for code in (a,b) for row in occupancy(code) for n in row)==32
G,forced,domain=scope['projection'](a,b,2)
assert G
labels=list(sorted(domain))
index={r:i for i,r in enumerate(labels)}
space=[]
times=[]
loads=[profile(code)[2] for code in (a,b)]
space_anchor_edges=sorted(set(G[0])|set(G[1]))
for u,v,k in space_anchor_edges:
    local=tuple(sum(L.get((u,v,k),(0,0))) for L in loads)
    idx=tuple(index[t,x,k] for x in (u,v) for t in (0,1))
    space.append((idx,local))
for t in (0,1):
    for x in range(8):
        times.append(tuple(i for i,(s,y,k) in enumerate(labels)
                           if t==s and x in (y,y^(1<<k))))
@cache
def coupling(values):
    reachable={0}
    for n in values:
        reachable={j for t in reachable for j in range(abs(t-n),t+n+1,2)}
    return 0 in reachable
@cache
def spatial(labels,loads):
    parity=sum(p+q for p,q in labels)&1
    if any((n&1)!=parity for n in loads):return False
    costs=tuple(sum(abs(a-b) for a,b in zip(labels[z],labels[z+1])) for z in (0,2))
    return sum(costs)<=min(loads) and (min(loads)!=0 or not any(costs))

dimensions=[domain[k] for k in labels]
allowed=set()
old_parity=set()
scans=prod(map(len,dimensions))
assert scans==1_048_576
for s in product(*dimensions):
    for i in times:
        group=[s[j] for j in i]
        if not all(coupling(tuple(sorted(x))) for x in zip(*group)):break
    else:
        for i,n in space:
            if not spatial(tuple(s[j] for j in i),n):break
        else:
            state=tuple((*k,*sp) for k,sp in zip(labels,s) if any(sp))
            allowed.add(state)
            if all(all((sum(s[j][0] for j in i)&1)==(d&1) for d in n) for i,n in space):
                old_parity.add(state)
def state_rows(p):
    cases=defaultdict(list)
    for l in Path(p).read_text().splitlines():
        i,*r=map(int,l.split())
        cases[i].append(tuple(r))
    return {k:tuple(sorted(s)) for k,s in cases.items()}
existing=state_rows('NETWORK/corrected-support/states.tsv')
prior=state_rows('OLD/states.tsv')
assert set(existing.values())==allowed and len(allowed)==36
assert set(prior.values())==old_parity and len(old_parity)==9
lookup={state:i for i,state in existing.items()}
def swap(state):return tuple((t,x,k,v,u) for t,x,k,u,v in state)
pairs={tuple(sorted((i,lookup[swap(s)]))) for i,s in existing.items()}
assert len(pairs)==18 and all(a<b for a,b in pairs)
author={}
for l in Path('EXCHANGE/pairs.tsv').read_text().splitlines():
    i,j,c=l.split()
    i,j=int(i),int(j)
    assert existing[j]==swap(existing[i])
    if c!='-':assert prior[int(c)]==existing[i]
    author[tuple(sorted((i,j)))]=c
assert pairs==set(author)
assert {int(x) for x in author.values() if x!='-'}==set(range(9))
with Path('reviewed-pairs.tsv').open('w') as p:
    for i,j in sorted(pairs):print(i,j,author[i,j],sep='\t',file=p)

def plans():
    for case,state in sorted(existing.items()):
        assignment={(t,x,k):(a,b) for t,x,k,a,b in state}
        for side in (0,1):
            for u,v,k in sorted(set(space_anchor_edges)|set(loads[side])):
                degree=sum(loads[side].get((u,v,k),(0,0)))
                for x in (u,v):
                    yield (case,side,x,k,degree,*assignment.get((side,x,k),(0,0)),
                           *assignment.get((1-side,x,k),(0,0)))
ref=(tuple(map(int,l.split())) for l in Path('NETWORK/corrected-support/anchor-plan.tsv').open())
assert list(plans())==list(ref)
print('original projected domain tuples',scans,'corrected support',len(allowed),'legacy parity',len(old_parity),'pairs',len(pairs))
print('all frozen corrected anchor plan rows verified')
print('pilot original insertion degree',sum(n for code in (a,b) for row in occupancy(code) for n in row),'scalar forced',forced)
