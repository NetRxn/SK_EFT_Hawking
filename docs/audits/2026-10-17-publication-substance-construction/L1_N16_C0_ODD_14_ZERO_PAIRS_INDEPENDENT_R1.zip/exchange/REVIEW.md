# Independent review of corrected odd-root support and chirality exchange

**ACCEPT** the corrected 36-state necessary support roster, the 18
equal-value chirality pairs, the closed plaquette wiring and the five
original open-boundary zero witnesses for pilot
`(103607566400,1256282136720)`, of original orbit weight 96.

The five verified witnesses give ten exact-zero channels by exchange.
This review supplies no signed value for the complete pilot. The other
13 pair values remain unverified by this receipt. The later author
support-pruning stream is a separate evidence package. The pilot stays
in the exact residual, which contains **9,644 orbits and 830,919 labels**.
The full original c0 remains open.

## Checked inputs and corrected support

The continuity snapshot returned fresh. The clean science checkout is
`51e7c745eccad5e99676cdc8e4b523ad73e617b1`. The clean checkpoint at
`41460c92bff8bee6bb6ae4aa15d52995f154e7d8` matches its tracked upstream.
I verified the 39-entry corrected archive manifest, eight exchange input
hashes, older nine-state anchor manifest, the original sewn input
manifest and all 169 generated spatial and site tensor checksums. The
checkpoint copy of the correction archive carries the same manifest.
The checkpoint's already accepted residual contains precisely one
instance of this pilot at weight 96.

A coframe is linear in a sum of left and right quaternion coordinates.
A center sign change in one chirality tests the number of coframe
factors allocated to that chirality in the individual monomial.
Occupations specify only total coframe degree. After summing away
allocation, a necessary parity condition follows from simultaneously
negating both chirality variables at the anchor. Its exponent is
the sum of the two representation doubled-spin totals plus the
total coframe degree, and must be even. The equivalent first-chirality
constraint with total degree on its right-hand side is invalid.

I checked the regression directly in the clean canonical source's
original four quarter-increments, original generator order and
normalized Haar. A named original coframe coefficient times the
right-fundamental off-diagonal entry gives −i/8, or −i/2 in the
quarter-stripped export. Total coframe degree is one and left spin
is zero. The old rule rejects this nonzero integral.

Starting from the reproduced prior projected local domains, I
enumerated all 1,048,576 tuples and tested temporal singlets independently
in both chiralities using successive Clebsch–Gordan couplings.
The spatial checks used the original minimum load bound, both actual
anchor pairings with zero loads, and the corrected simultaneous
parity on either spatial layer. Exactly 36 states survive, matching
the frozen table including all label tuples. Reapplying the invalid
first-chirality test recovers exactly the old nine as a strict subset
for this pilot. The full corrected anchor-plan table also matches.
These are necessary support tests, so an admitted state may
still integrate to zero.

## Exact source exchange and equality of each pair

In the original space-first source, G=gamma3 is a real block exchange
with G†=G and G²=I. It interchanges the chiral quaternion blocks of
every anchored Spin(4) link without moving its anchor. The two
independent product Haar factors exchange, preserving their joint
measure. It does not reverse the word or conjugate the final
Gaussian-integer coefficient. Direct gamma multiplication gives
`G gamma_A G = s_A gamma_A`, with s=(-1,-1,-1,+1),
and `G gamma5 G=-gamma5`.

Transform the bar and psi generators by G at every site. In the
original eight-generator ordering this exchanges the two four-slot
blocks. It is a permutation of four transpositions, so it preserves
each local top orientation and the complete Berezin coefficient.
The simultaneous coframe link and generator transform multiplies
each internal A component by s_A. I checked all 192 literal spatial
coframes on the 16-site carrier, including both coincident L=2 hops
and their signs, and checked each of the 16 local top masks. The
curvature trace transforms by −s_A s_B. Its two coframes multiply
by s_A s_B. Therefore each elementary EHC curvature-coframe root
contributes a single minus sign. The pilot's original insertion
powers sum to 32 and preserve the complete sign. The original
multiplicity factorials are unchanged.

In the irrep-index factorization, the exchange takes the (p,q)
tensor product to (q,p) by flipping its two index slots. Haar
projection and tensor contraction commute with this change of
variables. This gives equality of the signed, normalized channel
values for each pair individually. Enumerating the support
involution gives 18 disjoint two-member orbits with no fixed point,
all matching the author map. The nine legacy states link to nine
different pairs, with original state IDs checked explicitly.

## Closed-word check and legacy zero witnesses

With a time-first root, the canonical closed source order is
`A† V_y† B V_x` when A denotes the own spatial link and B the
opposite spatial link. The component `C[i4,i0]` joins the matrix
chain through indices `(i0,i1),(i1,i2),(i2,i3),(i3,i4)`.
Its first and third factors are the spatial ones. A change of
integration variable by inversion for the other connector reverses
the two temporal dagger flags but does not reverse the four-factor
word. I independently constructed the symmetric-power
representation in the recorded unnormalized polynomial basis,
then tested both connectors, all three spatial axes, two different
internal bivectors, powers one and two, and five asymmetric rational
link profiles. All 120 original literal controls agree. Reversing
the four-factor contraction changes 102.

I rebuilt each witness incidence network from the hashed old
spatial, temporal and signed site factors using the accepted
wire order. I used a separate sparse Gaussian-integer contraction
and checked exact matches and the all-open-boundary result rather
than running the author's witness program. All five subnetworks
vanish with 20 external wire indices still open. Every omitted
factor of the complete channel therefore multiplies a zero tensor.
These checks reuse the frozen local factor values. They do not
regenerate all signed local tables from source.

| Legacy channel | Corrected pair | Largest matched join | Total matched products |
| --- | --- | ---: | ---: |
| 0 | 11, 24 | 479,232 | 568,192 |
| 1 | 16, 18 | 1,327,104 | 1,331,200 |
| 2 | 17, 19 | 1,327,104 | 1,331,200 |
| 3 | 6, 28 | 479,232 | 568,192 |
| 4 | 7, 29 | 479,232 | 568,192 |

The largest resident factor is 58,752 rows. Prospective work,
coefficient height and total product checks precede the signed
joins, and a row guard checks each new output key. These controls
qualify the five witnesses as bounded contractions. The framework
can also ingest corrected-factor rows for exact whole-overlap
support pruning. Such pruning never loses a full assignment if it
deletes only rows that have no simultaneous match on all shared
wires. No additional corrected witness is accepted here.

## Reproduction

Run in this scratch directory with `NETWORK` pointing to the
corrected support archive, `EXCHANGE` to its frozen pair map,
`OLD` to the preceding nine-state anchor archive, `SEWN` to
the prior signed factor directory and `INDEPENDENT` to the
prior independent source and projection tables.

```sh
(cd NETWORK && shasum -a 256 -c manifest.sha256) > network-manifest.out
shasum -a 256 -c EXCHANGE/review-inputs.sha256 > exchange-manifest.out
(cd SEWN && shasum -a 256 -c regenerated-tables.sha256) > sewn-table-manifest.out
PYTHONDONTWRITEBYTECODE=1 python3 support.py > support.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" source.py > source.out
PYTHONDONTWRITEBYTECODE=1 python3 witnesses.py > witnesses.out
shasum -a 256 -c manifest.sha256
```

There were no repository, manuscript or Lean state changes.
