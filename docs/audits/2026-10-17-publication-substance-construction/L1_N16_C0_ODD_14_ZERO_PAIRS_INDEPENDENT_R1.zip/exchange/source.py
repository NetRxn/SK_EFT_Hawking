from ast import literal_eval
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from math import comb,prod
from pathlib import Path
from src.core.formulas import (
    original_plaquette as plaquette, original_spin4_link as spin,
    original_coframe_blocks as blocks,
)
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial as P, QComplex as Q, Symbol,
    ExteriorPolynomial as E, matrix_multiply as mm, matrix_dagger as dagger,
    assemble_coframe, haar_polynomial,
)
reg=OriginalRegulator()
assert reg.temporal_axis==3
G=reg.gamma[3]
I=tuple(tuple(P.scalar(int(i==j)) for j in range(4)) for i in range(4))
assert G==dagger(G) and mm(G,G)==I
assert all(G[i][j]==P.scalar(int(j==(i^2))) for i,j in product(range(4),repeat=2))
signs=(-1,-1,-1,1)
assert all(mm(mm(G,M),G)==tuple(tuple(s*v for v in row) for row in M)
           for s,M in zip(signs,reg.gamma))
assert mm(mm(G,reg.gamma5),G)==tuple(tuple(-v for v in row) for row in reg.gamma5)

def swapq(p):
    return P(tuple((tuple(Symbol(s.family,(*s.index[:-2],'R' if s.index[-2]=='L' else 'L',s.index[-1]))
                               if s.family=='q' else s for s in word),v) for word,v in p.terms))
def involute(e):
    out=[]
    for m,z in e.terms:
        bits=[i^4 for i in range(8*reg.volume) if m>>i&1]
        inversions=sum(a>b for i,a in enumerate(bits) for b in bits[i+1:])
        out.append((sum(1<<i for i in bits),(-1)**inversions*swapq(z)))
    return E(tuple(out))
assert all(involute(E(((255<<(8*i),P.scalar(1)),)))==E(((255<<(8*i),P.scalar(1)),))
           for i in range(reg.volume))
coframe_count=0
for x,mu,a in product(reg.sites,range(3),range(4)):
    e=assemble_coframe(reg,blocks(reg,(x,mu,a))).to_exterior(reg)
    expected=E(tuple((m,signs[a]*v) for m,v in e.terms))
    assert involute(e)==expected,(x,mu,a)
    coframe_count+=1
print('canonical source gamma and Haar chirality exchange',coframe_count,'coframes and all 16 local top orientations')

def qvars(x,k):
    q=tuple(tuple(P.variable(Symbol('q',(x,k,c,i))) for i in range(4)) for c in ('L','R'))
    return q
x=reg.sites[0]; mu=0; y=reg.step(x,mu)[0]
original=assemble_coframe(reg,blocks(reg,(x,mu,0))).to_exterior(reg)
m=(1<<2)|(1<<(8*reg.site_number(y)+4))
literal=dict(original.terms)[m]
LU=spin(*qvars(x,mu))
moment=haar_polynomial(literal*LU[3][2])
assert moment==P.scalar(Q(0,F(-1,8))),moment
print('canonical source parity counterexample',moment.terms[0][1].storage,'original quarter; x4 = -i/2')

Qraw=((1,0,0,0),(0,1,0,0),(0,0,1,0),(F(1,2),)*4,
      (F(5,13),F(12,13),0,0),(0,F(3,5),F(4,5),0),(F(3,5),0,0,F(4,5)))
def component(U):
    assert all(not keys for keys,z in U.terms)
    return U.terms[0][1] if U else Q()
def sym_block(M,n):
    entries=[]
    for i in range(n+1):
        row=[]
        for j in range(n+1):
            value=Q()
            for a in range(n-j+1):
                b=i-a
                if 0<=b<=j:
                    value+=comb(n-j,a)*comb(j,b)*prod(
                        (M[1][0],)*a+(M[0][0],)*(n-j-a)+(M[1][1],)*b+(M[0][1],)*(j-b))
            row.append(P.scalar(value))
        entries.append(tuple(row))
    return tuple(entries)
def rep(L,p,q):
    left=sym_block(tuple(tuple(component(L[i][j]) for j in range(2)) for i in range(2)),p)
    right=sym_block(tuple(tuple(component(L[i+2][j+2]) for j in range(2)) for i in range(2)),q)
    return tuple(tuple(left[i][j]*right[k][l] for j,l in product(range(p+1),range(q+1)))
                 for i,k in product(range(p+1),range(q+1)))
def trace(M):return sum((M[i][i] for i in range(len(M))),P())
table=defaultdict(list)
for l in Path('OLD/root.tsv').read_text().splitlines():
    n,u,v,p,q,i,j,r,s=l.split('\t')
    n,p,q,i,j=map(int,(n,p,q,i,j))
    table[n,literal_eval(u),literal_eval(v)].append((p,q,i,j,P.scalar(Q(F(r),F(s)))))
def evaluate(decor,mats):
    seen={}
    ans=P()
    for p,q,i,j,c in decor:
        if (p,q) not in seen:
            a,b,c1,d=[rep(f,p,q) for f in mats]
            seen[p,q]=mm(mm(mm(a,b),c1),d)
        ans+=c*seen[p,q][j][i]
    return ans

count=adverse=0
for t,mu,seed in product(range(2),range(3),range(5)):
    x=(0,0,0,t)
    y=reg.step(x,mu)[0];z=reg.step(x,3)[0]
    V,W,B,A=[spin(Qraw[(seed+i+mu)%7],Qraw[(2*seed+j+mu)%7]) for i,j in ((0,3),(1,0),(3,2),(4,5))]
    assign={(x,3):dagger(V) if t else V,(y,3):dagger(W) if t else W,(x,mu):A,(z,mu):B}
    ordered=(dagger(A),W if t else dagger(W),B,dagger(V) if t else V)
    literal=plaquette(reg,x,3,mu,assign)
    assert literal==mm(mm(mm(*ordered[:2]),ordered[2]),ordered[3])
    for a,b in ((0,1),(1,3)):
        C=mm(mm(reg.gamma[a],reg.gamma[b]),reg.gamma5)
        l=trace(mm(literal,C))
        transformed=trace(mm(mm(mm(G,literal),G),C))
        assert transformed==-signs[a]*signs[b]*l
        for n in (1,2):
            decor=table[n,(a,)*n,(b,)*n]
            assert decor
            lpow=l if n==1 else l*l
            assert evaluate(decor,ordered)==lpow
            wrong=evaluate(decor,ordered[::-1])
            adverse+=wrong!=lpow
            count+=1
print('literal closed-word controls',count,'of which reversal changes',adverse)
