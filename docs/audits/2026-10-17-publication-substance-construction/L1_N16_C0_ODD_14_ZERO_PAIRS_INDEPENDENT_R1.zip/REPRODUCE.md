# L1 independently accepted zero pairs and remaining contraction frontier

The two review directories separately preserve the accepted support and
chirality proof, five signed open-boundary zero witnesses, and nine
independent whole-overlap pruning certificates. Check each directory's
manifest. The combined coverage in pruning/reviewed-pairs.tsv marks
14 pairs zero and four pairs open. The original pilot remains in the
accepted residual. No stage or publication gate is discharged.

The compact directory holds author-only experiments on legacy channel
5, corrected pair (0,32). Its packed keys use disjoint fixed-width
fields for each mask, coframe word and representation index. Exact
integer arithmetic and prospective matched-product caps remain.
The greedy low-work schedule reaches nine live factors. The
boundary-aware ranking uses matched products times one plus the number
of output wires. At step 49 it leaves five live factors and 18 scalar
factors after 46,812,672 admitted products. The tested next join has
31,850,496 matched products and exceeds the 800,000-row sparse guard.

The export saves all exact frontier rows and scalar factors locally.
The archive carries the exact row counts, SHA-256 hashes and reproduction
script for each table. The files regenerate rather than adding 48 MB
of intermediate data to Git. One explicit binary representation-index
slice gets to four factors but still exceeds the sparse guard on
subsequent joins. Its complement was not run. No signed coefficient
or sign result follows from that slice.

Restore OLD and SEWN as specified in the correction archive and then
run from compact/:

```sh
python3 export49.py "$OLD" "$SEWN" 5 boundary > regenerated-frontier.out
python3 finish_frontier.py > split-plan.out
python3 finish_frontier.py 0 0 > frontier-tile0.out
```

The final replay returns 3 for a resource refusal. Work from the
exported five factors directly when testing a separator with more
than one wire or a streamed final exact contraction. Retain every
complement and the original factorial divisor 186624.
