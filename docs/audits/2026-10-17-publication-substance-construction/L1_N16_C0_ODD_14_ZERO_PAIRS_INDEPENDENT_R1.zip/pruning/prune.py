from collections import Counter,defaultdict,deque
from dataclasses import dataclass
from pathlib import Path
from itertools import combinations,product
from ast import literal_eval
from fractions import Fraction as F
from functools import lru_cache
from math import lcm
import sys

parse=lru_cache(maxsize=60000)(literal_eval)

sys.path.insert(0,str(Path("INDEPENDENT").absolute()))
from census import occupancy
O=[occupancy(code) for code in (103607566400,1256282136720)]
cap_rows=300_000
cap_initial=600_000
cap_scanned=20_000_000
roots=defaultdict(dict)
for l in Path('FACTORS/new-anchors/states.tsv').read_text().splitlines():
    c,t,x,k,p,q=map(int,l.split())
    roots[c][t,x,k]=p,q
plans=defaultdict(dict)
for l in Path('FACTORS/new-anchors/anchor-plan.tsv').read_text().splitlines():
    c,t,x,k,*shape=map(int,l.split())
    plans[c][t,x,k]=tuple(shape)
patterns={}
for i,l in enumerate(l for l in Path('FACTORS/edge-plan.out').read_text().splitlines() if l.startswith('pattern ')):
    patterns[parse(l[8:l.rindex(')')+1])]=i
temporal=defaultdict(list)
for l in Path('FACTORS/new-anchors/temporal.tsv').read_text().splitlines():
    shape,rows,cols,r,s=l.split('\t')
    temporal[parse(shape)].append((tuple(x for ij in zip(parse(rows),parse(cols)) for x in ij),(F(r),F(s))))

@dataclass
class Table:
    names:tuple
    keys:tuple
    rows:dict
def make(name,keys,entries):
    actual=tuple(k for k in keys if k is not None)
    output=set()
    for row,z in entries:
        assert len(row)==len(keys)
        assert all(k is not None or not x for k,x in zip(keys,row))
        key=tuple(x for k,x in zip(keys,row) if k is not None)
        assert key not in output and len(output)<cap_rows
        assert bool(z[0] or z[1])
        output.add(key)
    assert len(actual)==len(set(actual)) and output
    return Table((name,),actual,output)

def build(case,name):
    state=roots[case]
    t,x,tag=(int(k) for k in name[1:]+('0' if len(name)==3 else ''))
    def wires(layer,site,axis,column):
        return tuple((layer,site,axis,column,h) if s else None
                     for h,s in enumerate(state.get((layer,site,axis),(0,0))))
    def label(site,k):return ((t,site,k,'mask'),(t,site,k,'word'))
    if name[0]=='T':
        roster=[];ks=[]
        for (layer,y,k),s in sorted(state.items()):
            q=s[tag]
            if layer!=t or not q or x not in (y,y^(1<<k)):continue
            outgoing=(x==y)
            roster.append((q,bool(t^int(not outgoing))))
            for column in ((3,4) if outgoing else (1,2)):
                ks.append(wires(t,y,k,column)[tag])
        return make(name,tuple(ks),temporal[tuple(roster)])
    if name[0]=='E':
        k=tag;y=x^(1<<k)
        load=lambda v:sum(O[t][v])-O[t][v][k]
        p=patterns[load(x),load(y),plans[case][t,x,k],plans[case][t,y,k]]
        keys=label(x,k)+label(y,k)
        for v in (x,y):
            for side,cols in ((t,(0,1)),(1-t,(2,3))):
                for c in cols:keys+=wires(side,v,k,c)
        def entries():
            for l in Path(f'FACTORS/edge-batch/{p:02}.tsv').open():
                a,b,m,A,B,r,s=l.split('\t')
                mask=int(m)
                row=(mask&255,parse(a),mask>>8,parse(b))
                row+=tuple(z for pair in (*parse(A),*parse(B)) for z in pair)
                yield row,(F(r),F(s))
        return make(name,keys,entries())
    assert name[0]=='S'
    active=[k for k,n in enumerate(O[t][x]) if n]
    keys=tuple(w for k in range(3) for w in label(x,k))
    for k in active:
        keys+=wires(t,x,k,4)+wires(t,x,k,0)
    def entries():
        for l in Path(f'FACTORS/site/{case}-{t}-{x}.tsv').open():
            w,m,rs,re,im=l.split('\t')
            values=tuple(z for entry in zip(parse(m),parse(w)) for z in entry)
            rs=parse(rs)
            assert len(rs)==2*len(active)
            for j,k in enumerate(active):
                base=state.get((t,x,k),(0,0))[1]+1
                values+=divmod(rs[2*j],base)+divmod(rs[2*j+1],base)
            yield values,(F(re),F(im))
    return make(name,keys,entries())


def plans_from(path):
    rows=defaultdict(list)
    for l in Path(path).read_text().splitlines():
        k,*r=map(int,l.split())
        rows[k].append(tuple(r))
    return rows

new_root=Path('FACTORS/new-anchors')
accepted=Path('NETWORK/corrected-support')
for name in ('root.tsv','spatial.tsv','temporal.tsv'):
    assert (new_root/name).read_bytes()==(accepted/name).read_bytes()
for name in ('states.tsv','anchor-plan.tsv'):
    ref=plans_from(accepted/name)
    cut=plans_from(new_root/name)
    assert set(cut)=={4,5,8,9,10,12,13,14,15}
    assert all(cut[k]==ref[k] for k in cut)
assert set(roots)==set(plans)=={4,5,8,9,10,12,13,14,15}

def geometry():
    yield from (f'S{t}{x}' for t,x in product(range(2),range(8)))
    for t in range(2):
        for u in range(8):
            for k in range(3):
                if not u>>k&1:yield f'E{t}{u}{k}'
    yield from (f'T{t}{x}{h}' for t,x,h in product(range(2),range(8),range(2)))

def audit(case):
    nets=[build(case,n) for n in geometry()]
    assert len(nets)==72
    incidence=defaultdict(list)
    for i,table in enumerate(nets):
        for k in table.keys:incidence[k].append(i)
    assert all(len(factors)==2 for factors in incidence.values())
    initial=sum(len(t.rows) for t in nets)
    assert initial<=cap_initial
    peak=max(len(t.rows) for t in nets)
    print('case',case,'factor-count',len(nets),'wires',len(incidence),
          'initial rows',initial,'peak factor',peak,flush=True)
    shared=defaultdict(list)
    for k,(i,j) in incidence.items():shared[i,j].append(k)
    arcs={}
    neighbors=defaultdict(set)
    for (i,j),keys in shared.items():
        a=tuple(nets[i].keys.index(k) for k in keys)
        b=tuple(nets[j].keys.index(k) for k in keys)
        arcs[i,j]=a,b,tuple(keys)
        arcs[j,i]=b,a,tuple(keys)
        neighbors[i].add(j);neighbors[j].add(i)

    # Independent AC-3 work stack. For each directed edge project the full
    # overlap tuple, then delete only rows absent from that entire projection.
    scanned=deleted=steps=0
    generation=[0]*len(nets)
    projection_cache={}
    pending=sorted(arcs.copy(),reverse=True)
    enqueued=set(pending)
    while pending:
        i,j=pending.pop()
        enqueued.remove((i,j))
        a,b,keys=arcs[i,j]
        left,right=nets[i],nets[j]
        cachekey=(j,b)
        projection=projection_cache.get(cachekey)
        if projection is None or projection[0]!=generation[j]:
            scanned+=len(right.rows)
            assert scanned<=cap_scanned
            allow={tuple(row[p] for p in b) for row in right.rows}
            projection_cache[cachekey]=(generation[j],allow)
        else:allow=projection[1]
        scanned+=len(left.rows)
        assert scanned<=cap_scanned
        kept={r for r in left.rows if tuple(r[p] for p in a) in allow}
        if len(kept)==len(left.rows):continue
        before=len(left.rows)
        gone=before-len(kept)
        assert gone>0 and kept<=left.rows
        deleted+=gone
        steps+=1
        left.rows=kept
        generation[i]+=1
        print('remove',case,steps,left.names[0],right.names[0],
              before,len(kept),len(allow),repr(keys),flush=True)
        if not kept:
            print('PROVED ZERO',case,'empty',left.names[0],'steps',steps,
                  'deleted',deleted,'scanned',scanned,'products',0,flush=True)
            return
        for k in sorted(neighbors[i],reverse=True):
            arc=k,i
            if arc not in enqueued:
                pending.append(arc);enqueued.add(arc)
    raise RuntimeError(('arc pruning reaches nonempty fixed point',case,steps,deleted,scanned))

for case in map(int,sys.argv[1:]):
    audit(case)
