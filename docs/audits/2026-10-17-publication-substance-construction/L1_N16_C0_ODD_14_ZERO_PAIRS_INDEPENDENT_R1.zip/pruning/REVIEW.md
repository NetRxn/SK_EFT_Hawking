# Independent review of nine corrected whole-overlap zero certificates

**ACCEPT** the nine zero channels numbered 4, 5, 8, 9, 10, 12, 13, 14
and 15 in the corrected 36-state pilot roster. The previously accepted
chirality exchange gives one exact-zero partner for each. Alongside
the five previously accepted legacy zeros and their partners, the
independent coverage is **14 zero pairs, or 28 of 36 channels**.

The open pairs are `(0,32)`, `(1,33)`, `(2,34)` and `(3,35)`.
The pilot `(103607566400,1256282136720)` still has no complete signed
coefficient. The current residual has **9,644 orbits and 830,919
labels**. This receipt subtracts no representative.

## Inputs and exact wiring

The primary continuity snapshot checked fresh. The clean checkpoint
`00acd92cf74e949753e70318f83dfb71b56f3547` matched its tracked upstream.
Compared to `41460c92b`, it changes only the author pruning archive
and the existing direction map. The checked-in archive's manifest
matches the frozen author archive and the source factor directory.
All 42 checkpoint entries, 186 regenerated edge/site table entries
and 17 preceding independent review entries verified.

The nine-state anchor files are the exact subset of the prior accepted
36-state and anchor-plan rows. The root, spatial and temporal
representation moment exports agree byte-for-byte with the accepted
corrected-support inputs. I independently rebuilt the site, spatial
and temporal incidences using the verified closed-wire convention.
The matrix chain of each root is (i0,i1), (i1,i2), (i2,i3), (i3,i4).
Its own and opposite spatial matrices use the first and third pairs.
Its site coefficient carries (i4,i0) and the temporal Haar rows use
the original connector inversion flags. The local coframe mask and
word labels remain in their actual endpoint and axis incidence.

Each corrected network has 72 factors and every nontrivial wire
appears exactly twice. For all nine, the complete wire and initial
sparse row counts agree with the frozen author receipts. All source
rows are nonzero exact values with no duplicate support key after
removing trivial representation columns. This replay verifies the
zero certificates against the frozen local factor values. It
does not regenerate every local factor coefficient from source.

## Proof and independent replay

For each directed pair of factor tables that share any wire, take
the projection of the second table's current support onto their
**entire** shared wire tuple. The first table may discard exactly
those rows whose matching projection is absent from that set.
Any term in a complete product has to pick consistent values on
every shared wire at once. A discarded row cannot be part of such a
term. Induction over the deletions preserves every possible complete
assignment. The statement also holds with any external variables
fixed, because these tests sum or constrain no unseen boundary
index. An empty factor therefore proves the whole channel zero,
independently of the original denominators or Grassmann signs.

The reviewer used a new deterministic, directed support worklist.
At each step it projects all shared indices and removes rows only
through that full-tuple test, then requeues affected neighbors.
The three scratch transcripts record every deletion's source
factor, peer, overlap wires and before-and-after counts. All nine
schedules independently empty site factor S06. They perform zero
matched coefficient products. This establishes a support zero
without assuming any algebraic cancellation.

| Corrected channel | Partner | Initial sparse rows | Deletion steps | Support row visits |
| --- | --- | ---: | ---: | ---: |
| 4 | 30 | 400,987 | 26 | 2,368,462 |
| 5 | 31 | 417,363 | 27 | 2,656,102 |
| 8 | 27 | 467,132 | 29 | 3,192,246 |
| 9 | 25 | 401,659 | 25 | 2,240,694 |
| 10 | 26 | 417,635 | 26 | 2,515,842 |
| 12 | 20 | 335,514 | 22 | 1,390,030 |
| 13 | 21 | 351,890 | 23 | 1,677,670 |
| 14 | 22 | 351,490 | 23 | 1,665,178 |
| 15 | 23 | 367,866 | 24 | 1,952,818 |

The largest single source factor contains 62,592 rows. Maximum
initial network cardinality is 467,132 support rows. Each
projection or filter is checked against the row-visit allowance
before running. The largest cumulative visit count is 3,192,246.
The largest number of discarded rows per proof is 197,336. These
support counts do not describe numerical contraction width.
The exact current pair coverage is in `reviewed-pairs.tsv`.

## Replay

Scratch expects `PRIOR` to point to the preceding independent
exchange review, `NETWORK` to the full corrected support archive,
`FACTORS` to the corrected generated local factor directory, and
`INDEPENDENT` to the established independent decoder. `AUTHOR`
is the extracted checkpoint pruning archive.

```sh
(cd AUTHOR && shasum -a 256 -c checkpoint-manifest.sha256) > author-manifest.out
(cd FACTORS && shasum -a 256 -c regenerated-tables.sha256) > local-tables.out
(cd PRIOR && shasum -a 256 -c manifest.sha256) > prior-manifest.out
PYTHONDONTWRITEBYTECODE=1 python3 prune.py 4 5 8 > batch-0.out
PYTHONDONTWRITEBYTECODE=1 python3 prune.py 9 10 12 > batch-1.out
PYTHONDONTWRITEBYTECODE=1 python3 prune.py 13 14 15 > batch-2.out
python3 verify.py > verification.out
shasum -a 256 -c manifest.sha256
```

No repository, manuscript or Lean state changed.
