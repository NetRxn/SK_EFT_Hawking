from collections import Counter
from pathlib import Path

def rows(p):
    return [line.split() for line in Path(p).read_text().splitlines()]
scope={4,5,8,9,10,12,13,14,15}
header={}
zero={}
remove_count=Counter()
for brain in range(3):
    for r in rows(f'batch-{brain}.out'):
        if r[0]=='case':
            case,n,wires,total,peak=map(int,(r[1],r[3],r[5],r[8],r[11]))
            assert n==72 and case not in header
            header[case]=(wires,total,peak)
            author=rows(f'AUTHOR/corrected{case}.out')
            assert author[0]==f'case {case} source factors 72 wires {wires} initial rows {total}'.split()
            assert author[-1]==f'EXACT channel zero {case} products 0'.split()
        elif r[0]=='remove':
            case=int(r[1]);remove_count[case]+=1
            assert int(r[2])==remove_count[case]
            assert int(r[5])>int(r[6])>=0
            assert int(r[7])>0
        elif r[:2]==['PROVED','ZERO']:
            case=int(r[2])
            assert case not in zero and int(r[-1])==0
            assert int(r[6])==remove_count[case]
            zero[case]=(r[4],int(r[6]),int(r[8]),int(r[10]))
assert set(zero)==set(header)==scope
prior={}
for x,y,old,status in rows('PRIOR/pair-review.tsv'):
    prior[int(x),int(y)]=(old,status)
combined={}
coverage=Counter()
with Path('reviewed-pairs.tsv').open('w') as out:
    for x,y,old,status in rows('AUTHOR/pair-disposition.tsv'):
        i,j=sorted((int(x),int(y)))
        prev=prior[i,j]
        assert prev[0]==old
        if i in zero or j in zero:
            assert prev[1]=='OPEN' and len({i,j}&set(zero))==1 and old=='-'
            method='corrected whole-overlap support'
            tag='ZERO'
        elif prev[1]=='ZERO':
            method='legacy open-boundary contraction'
            tag='ZERO'
        else:
            assert old!='-'
            method='open'
            tag='OPEN'
        assert tag==status and (i,j) not in combined
        combined[i,j]=tag
        coverage[method]+=1
        print(i,j,old,tag,method,sep='\t',file=out)
assert set(combined)==set(prior)
assert coverage=={'corrected whole-overlap support':9,'legacy open-boundary contraction':5,'open':4}
for case in sorted(scope):
    print(case,*header[case],*zero[case],sep='\t')
print('proof totals cases/pairs/channels',len(zero),len(combined),2*len(combined))
print('coverage',dict(coverage))
print('max initial/peak/steps/deletions/scans',max(v[1] for v in header.values()),
      max(v[2] for v in header.values()),max(v[1] for v in zero.values()),
      max(v[2] for v in zero.values()),max(v[3] for v in zero.values()))
