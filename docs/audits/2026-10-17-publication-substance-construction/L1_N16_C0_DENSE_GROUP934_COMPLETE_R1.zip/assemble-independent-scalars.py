from pathlib import Path
from zipfile import ZipFile
import re

d=Path(__file__).resolve().parent
parts={}
def add(n,x,y,den):
    assert n not in parts
    parts[n]=tuple(map(int,(x,y,den)))
for name in ('independent-L4.zip','independent-L567.zip'):
    with ZipFile(d/name) as z:
        for row in z.read('scalar.tsv').decode().splitlines()[1:]:
            group,scope,n,x,y,den,*_=row.split('\t')
            assert group=='934' and scope=='whole_original_joint_L_assignment'
            add(int(n),x,y,den)
with ZipFile(d/'independent-L01.zip') as z:
    for n in (0,1):
        text=z.read(f'L{n}.out').decode()
        found=re.findall(fr'Group934 L{n} raw signed scalar (-?\d+) (-?\d+) denominator (\d+)',text)
        assert len(found)==1
        add(n,*found[0])
with ZipFile(d/'independent-L23.zip') as z:
    for row in z.read('scalar.tsv').decode().splitlines()[1:]:
        data=row.split('\t')
        assert data[0]=='934'
        offset=2 if data[1]=='whole_original_joint_L_assignment' else 1
        n,x,y,den,*_=data[offset:]
        assert int(n) in [2,3]
        add(int(n),x,y,den)
assert set(parts)==set(range(8))
print('group\tscope\tassignment\traw_real\traw_imag\tfactor_denominator')
for n,row in sorted(parts.items()):
    print('934','whole_original_joint_L_assignment',n,*row,sep='\t')
