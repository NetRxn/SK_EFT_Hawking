# Exact original Group 934 signed contraction

The prepared source and the first unconditioned guard belong to the
earlier dense reuse pilot. Its prepared source fingerprint is
ca06cb543e73dd7708ab259a949a9e1c66a64e56a2622bd16de830ea96c070b7.
The original eight joint labels exhaust the common source support,
as independently checked from the prepared signed factor tables.
The source, preserved guarded tables and continuation operands are
pinned in each label's exact manifest.

The label driver starts from the original prepared factor state.
It applies the explicit joint label before the guarded contraction and
checks the roster. The subsequent passes preserve signed denominators
and original retained axes. Assignments 1–3 use independent triangle
closures for their three-factor terminal. The other assignments end
with one axis-empty signed factor.

From clean extraction verify SHA256SUMS and all linked independent
source/cap and continuation archives. Run retally.py from the group
archive root to reproduce the exact raw sum and original normalization
from the pinned profile driver and author receipts. The independent
scalar ledger and retally independently confirm those values.
This is one dense-group contribution to the full coefficient.
