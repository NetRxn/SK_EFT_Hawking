import sys
from pathlib import Path
import numpy as np
from src.core.visualizations import fig_T_H_evolution_regime_partition
f=fig_T_H_evolution_regime_partition()
a,b,c=f.data
assert a.y[0]==b.y[0]==1 and np.all(np.diff(a.y)<0) and np.all(np.diff(b.y)>0)
np.testing.assert_allclose(b.y,(1-np.asarray(b.x)/5)**(-1/3))
np.testing.assert_allclose(c.x,c.y)
assert c.x[50]==1 and np.isclose(c.y[50],1)
assert not c.showlegend and '5t/t_evap' in f.layout.xaxis.title.text
p=Path(sys.argv[1])/'figure.png'
f.write_image(str(p), format='png', width=f.layout.width, height=f.layout.height, scale=2)
print('Exact candidate figure source checks and render passed')
