# Original N16 Task3 direct polar edge author receipt

Candidate branch `codex/publication-l1-original-n16-task3` in the assigned N16
Python worktree. HEAD stays at the reviewed, pushable base `4672e9fec`.
The exact installed diff is `publication-task3-direct-edge-author-r1.worktree.diff`,
SHA-256 `e0374adc794199ffa53b4c8ee52e1d84579e35365bd5686aeeaa8db9fd21c76b`.
The first continuity receipt is SAME. The final receipt lists exactly
`owned-files` and `source`, expected after the author change. Git diff whitespace
validation passed. The three assigned files are the only worktree changes.

The direct edge uses the original unequal endpoint blocks. It collapses
the four signed quarter increments into D=U†−V at x and −D† at y and then
uses the accepted real polar section on the two-site support. This is an
invariant-test calculation for an induced original edge. It leaves the
full regulator, action and normalization separate. Both endpoint
coframes use the original gamma constructor and canonical generator
order. In each cubic, the routine contracts all literal n/b/p pairs in
the oriented two-site top. It computes the local G by literal wedges
and solves B=G^T E G for both full coefficient matrices. All zeros are
computed. The top of Qx^4 follows from the same coalesced wedge engine.
No accepted coefficient, zero mask or radial moment value is an input.

The sparse contraction uses a 24-bit key with one 16-bit mask and two
4-bit radial powers. It coalesces each accepted wedge product immediately,
drops exact cancellations, shares Qx², and enforces each output bound
before inserting a new slot. Reservations include both input layers,
retained maps and output capacity, plus 4096 slots for small coframe,
basis, result and moment objects. A separate 55,000 occupied/reserved
slot cap does not rely on unique-object counting. ExactBudget measures
the supplied live containers and includes resizing slack. It meters
actual exact scalar products and checked integer arithmetic. Bitmask
rejections have no scalar product. The binomial expansion of
(2−2q0)^k calls the existing normalized quaternion moment implementation.
Each test first collects its full oriented radial polynomial, then refuses
a nonzero odd radial term. No division by either radial variable is used.

Bounded controls only, as assigned:

- Red from the exact frozen baseline: six intended failures for absent
  production entries, in `publication-task3-direct-edge-author-r1.red-final-controls.log`.
- Negative endpoint control: replacing the y blocks by the x placements
  broke both actual original-anchor comparisons and the mixed coefficient
  test. The negative result changed the mixed n–n dual entry from 12 to
  45/4. See `publication-task3-direct-edge-author-r1.poison-qy.log`.
- Exact worktree green: 63 bounded coefficient-jet cases passed. The
  complete original one-site test was deselected. See
  `publication-task3-direct-edge-author-r1.green-worktree.log`.
- The existing original-coefficient substrate suite passed all 47 cases.
  See `publication-task3-direct-edge-author-r1.substrate-tests.log`.
- The measured local call used 2520 exact scalar products, 7791 integer
  products, 14 peak checked bits and 28652 occupied-or-reserved slots.
  Modeled payload was 178167336 bytes and process RSS high water
  101793792 bytes. It returned all 36 entries in each literal and dual
  matrix, with six nonzero entries per dual matrix. The original fourth
  moment was exactly 1125/4. See
  `publication-task3-direct-edge-author-r1.bounded-receipt.json`.

The block-level controls used actual independent periodic anchors at
unequal radii, including an exactly singular chirality. The test suite
also verifies low storage and scalar budget refusal, odd radial refusal,
and reservation enforcement before a new map entry. The explicit original
coframe Lean reference resolves in the checked source. This change
does not supply the formal polar/invariant-to-executable bridge.

The direct local increment is ready for independent source and cost
review. Independent complementary minors, actual N16 geometric support
and complete scalar/contact reconstruction remain owed. No full N16 or
one-site scientific producer, Lean command, main integration, formal
closure, publication acceptance, commit or push was performed.
