# Original N16 Task3 direct polar edge R2 repair

The three owned files are frozen in the assigned worktree on
`codex/publication-l1-original-n16-task3` at parent `4672e9fec`.
The exact installed diff from that parent has SHA-256
`3a4d85da3f3e3fa8b4864fbee7a527cc8846cf58aaaef7feb88d7339347a6f55`.
The applied R1→R2 delta has SHA-256
`94be57c82da635f9e366e38feaceb41462069ed289bda5ae5e7f0801658a80eb`.
The R1 diff and the independent REVISE remain preserved separately.
The first R2 packet matched and the final check changed only the owned
files and source as expected. `git diff --check` passed.

The direct API requires each of the scalar product, storage and integer
height limits to be a positive Python int within its reviewed maximum.
It checks all three before its first reservation. The 21 invalid-cap
controls cover NaN, infinity, integral and fractional floats, bool,
zero and negative int independently in each field. Their sentinel
detects any call to the first reservation. Existing positive low-cap
tests continue to reach and enforce storage and exact product refusal.
Generic ExactBudget behavior remains in its original scope.

The internal polar radius family is now real only on the two explicit
chirality indices L and R. A legacy arbitrary r symbol conjugates as
it did before R1, even with the same index. Another index in the new
internal family also retains ordinary conjugation. The original-anchor
comparisons continue to exercise the actual internal radii, both with
unequal radii and with a singular right chirality.

Each wedge now reserves its attempted Cartesian visit count in a
separate cumulative counter before visiting the pairs. The direct hard
bound is the reviewed 14,014,464 upper bound for the four higher
wedges plus up to 512 initial coframe-square pairs. These 512 are part
of the original plan's small overhead, making the conservative
edge/minor combined subtotal 60,488,960 before other overhead. The
rest of the N16 package still requires its own cost review and
admission. For the local production call, 7,120 attempted wedge pairs
split into 5,672 mask overlaps and 1,448 exact wedge products. The
latter bill exactly once through QComplex. Another 1,072 exact products
occur in assembly, projection, averaging and basis arithmetic. The
instrumented check compared every wedge call's debit to its actual
disjoint-pair count. Thus the total arithmetic debit is 2,520, and
the separate visit counter records all wedge candidates without double
billing surviving products.

All four complete 36-entry tables and the oriented fourth moment
continue to match R1. The bounded receipt records 7,791 integer
products, 14 peak checked bits, 28,652 occupied or reserved records,
178,167,336 modeled payload bytes and 100,040,704 bytes RSS high water
for the observed local process. The existing one-site science and
full N16 producer were not run.

Evidence prefix `/tmp/publication-task3-direct-edge-author-r2`:

- `.first.json` and `.final.json` are the continuity receipts.
- `.red.log` records 23 failures on the preserved R1 source.
- `.green-scratch.log` records the 29 focused N16 checks.
- `.green-worktree.log` records 133 passes and one deselected complete
  one-site test across the two original-coefficient suites.
- `.bounded-receipt.json` and `.pair-reconciliation.json` record the
  local production metrics and the independent per-call instrumentation.
- `.delta.diff` and `.worktree.diff` carry the exact changes.

This is the author handoff for independent review. The auxiliary
minor route, complete original N16 support and contacts, full-volume
normalization, formal correspondence and publication gates remain open.
No commit, push, Lean operation or full scientific run was performed.
