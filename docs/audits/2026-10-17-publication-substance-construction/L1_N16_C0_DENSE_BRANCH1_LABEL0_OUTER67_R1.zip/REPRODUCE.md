# L1 group 128 opposite branch, assignment 0, outer 6 and exact transfer to 7

Source pin: e7c97c008 with the original exact signed-map archive. Outer 6 uses
all sixteen G(0,0,2) cases, eight eight-case continuations in the low family and four two-case
plus four six-case continuations in the high family. Each original denominator
and external normalization is preserved. The independent full-row replay of
the prior 6→7 map verifies transfer to one distinct original outer case.

From the extracted archive root:

```sh
shasum -a 256 -c SHA256SUMS
python3 -B author/outer6/retally-outer6.py author/outer6 author/inner0 author/low author/inner8 author/high | cmp - author/outer6/author-outer6-complete.tsv
```

The source and independent exact arithmetic manifests bind the original values
and operands. The remaining representative 2 and the full group remain open.
