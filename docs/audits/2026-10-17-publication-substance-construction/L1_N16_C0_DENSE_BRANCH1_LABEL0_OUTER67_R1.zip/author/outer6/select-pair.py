from collections import Counter
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import load,dump
import sys

with open(sys.argv[1],'rb') as f:
    cap=load(f)
F=cap['factors']
degrees=Counter(w for A,_,_ in F for w in A)
assert len(F)==8 and set(degrees.values())=={2}
assert prod(d for _,_,d in F)==40512224221827380280140849737629696
def project(A,out):
    return tuple(A.index(w) for w in out)
def hist(A,R,W):
    where=project(A,W)
    return Counter(tuple(x[p] for p in where) for x in R)
choices=[]
for i,j in combinations(range(len(F)),2):
    A,L,_=F[i]
    B,R,_=F[j]
    common=tuple(w for w in A if w in B)
    if not common: continue
    l,r=hist(A,L,common),hist(B,R,common)
    matched=sum(n*r[k] for k,n in l.items())
    choices.append((matched,(i,j),common))
    print('pair',i,j,'projected products',matched,'shared indices',len(common),flush=True)
matched,pair,common=min(choices)
assert matched>0
print('chosen',pair,matched,flush=True)
cap['rejected_pair']=pair
cap['matched']=matched
with Path('partition-input.pkl').open('xb') as out:
    dump(cap,out,protocol=5)
