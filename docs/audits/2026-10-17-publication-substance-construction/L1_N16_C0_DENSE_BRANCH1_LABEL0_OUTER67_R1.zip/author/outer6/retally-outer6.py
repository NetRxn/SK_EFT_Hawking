from ast import literal_eval
from fractions import Fraction as Q
from pathlib import Path
import re
import sys

base,first,low,eighth,high=map(Path,sys.argv[1:])
norm=40512224221827380280140849737629696*16*4**64
def roster(path):
    raw=(path/'s0.roster').read_bytes()
    axes, support=literal_eval(raw.decode())
    assert len(support)==len(dict(support)) and 1<len(support)
    return axes,raw,sorted(support,key=lambda x:(x[1],x[0]))
def child(d,raw,index,coord,products):
    assert (d/f's{index}.roster').read_bytes()==raw
    c=d/f'slice{index}'
    assert f'pilot {coord!r} matched {products} stored rows ' in (c/'partition.out').read_text()
    return c
def exact(c):
    status=(c/'contraction.receipt').read_text().splitlines()[0]
    assert status=='child_status 0',c
    line=(c/'contraction.out').read_text().splitlines()[-1]
    value=Q(re.fullmatch(r'exact normalized ([-\d/]+) peak rows \d+ matched products \d+',line)[1])
    assert (value*norm).denominator==1
    return value
axes,raw,parent=roster(base)
assert axes==(('G',0,0,2),) and len(parent)==16 and sum(n for _,n in parent)==8318976
total=Q(0)
print('outer6 term','coordinate','projected','nested cells','nested projected','exact real','imaginary',sep='\t')
for i,(key,n) in enumerate(parent):
    orig=child(base,raw,i,key,n)
    assert (orig/'contraction.receipt').read_text().splitlines()[0]=='child_status 2'
    if i==0:d=first
    elif i<8:d=low/str(i)
    elif i==8:d=eighth
    else:d=high/str(i)
    iaxis,inner,terms=roster(d)
    projected=int((d/'plan.out').read_text().splitlines()[-1].split()[-1])
    assert projected==sum(v for _,v in terms)
    q=sum(exact(child(d,inner,j,k,v)) for j,(k,v) in enumerate(terms))
    total+=q
    print(i,key,n,len(terms),projected,q,0,sep='\t')
print('total','','','','',total,0,sep='\t')
