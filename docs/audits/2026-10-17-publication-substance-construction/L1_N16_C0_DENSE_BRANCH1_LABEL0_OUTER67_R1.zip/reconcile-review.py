from csv import DictReader
from fractions import Fraction as Q
from pathlib import Path

root=Path(__file__).resolve().parent
factor_den=40512224221827380280140849737629696
den=factor_den*16*4**64
author=list(DictReader((root/'author/outer6/author-outer6-complete.tsv').open(),delimiter='\t'))
assert len(author)==17 and author[-1]['outer6 term']=='total'
assert [int(r['outer6 term']) for r in author[:-1]]==list(range(16))
peer=list(DictReader((root/'independent/outer6/leaf-ledger.tsv').open(),delimiter='\t'))
assert len(peer)==96
seen={(int(r['inner']),int(r['child'])) for r in peer}
assert seen=={(i,j) for i,a in enumerate(author[:-1]) for j in range(int(a['nested cells']))}
sums={i:Q() for i in range(16)}
for row in peer:
    i=int(row['inner'])
    assert int(row['factor_denominator'])==factor_den
    assert Q(row['imag'])==int(row['raw_imaginary'])==0
    assert len(row['operand_sha256'])==64
    exact=Q(int(row['raw_real']),den)
    assert exact==Q(row['real'])
    sums[i]+=exact
for i,row in enumerate(author[:-1]):
    assert sums[i]==Q(row['exact real']) and int(row['imaginary'])==0
total=sum(sums.values())
assert total==Q(author[-1]['exact real']) and int(author[-1]['imaginary'])==0
print('outer-6',total,0,sep='\t')
print('outer-7',total,0,sep='\t')
