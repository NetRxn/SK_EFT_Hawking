from pathlib import Path
from ast import literal_eval
p=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
def locate(key):
    return Path((p/f'label0-{key}.path').read_text().strip())
outer=locate('roster')
base=locate('outer6')
first,low,eighth,high=[locate(f'outer6-{k}') for k in ('4factor','low-cohort','5factor','high-cohort')]
def family(i):
    return first if i==0 else low/str(i) if i<8 else eighth if i==8 else high/str(i)
def roster(folder):
    axes, rows=literal_eval((folder/'s0.roster').read_text())
    return axes,sorted(rows,key=lambda r:(r[1],r[0]))
