from ast import literal_eval
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial,prod
from pathlib import Path
from pickle import loads
import csv
import re

from setup import base,family,roster
codes=(503841882182,1461451755920)
modes=sorted((a,b,c) for a,b,c in product(range(5),repeat=3) if a+b+c<=4)
occ=[]
for code in codes:
    record=[]
    for site in range(8):
        code,digit=divmod(code,64)
        record.append(modes[digit])
    assert not code
    occ.append(record)
world=sum((k+3)*value for layer in occ for powers in layer for k,value in enumerate(powers))
# Count cross-site sign by scanning site groups weighted by their insertions.
cross=0
for layer in occ:
    prior=[0]*8
    for site in range(8):
        for k in range(3):
            if site & (2**k):
                continue
            peer=site+2**k
            weight=sum(layer[u][j] for u in (site,peer) for j in range(3) if j!=k)
            cross+=weight*(sum(prior[site+1:])+sum(prior[peer+1:]))
            prior[site]+=weight
            prior[peer]+=weight
phase=(-1)**((world+cross)%2)
P=[p for layer in occ for site in layer for p in site]
total_occ=sum(P)
multiplicity=prod(map(factorial,P))
assert (total_occ,multiplicity,phase)==(32,16,1)
N=40512224221827380280140849737629696
scale=N*multiplicity*4**(2*total_occ)
print('normalization','occupation',total_occ,'factorial',multiplicity,'quarters exponent',2*total_occ,'world',world,'cross',cross,'phase',phase,'positive denominator',scale,sep='\t')

from sys import argv
with Path(argv[1]).open() as f:
    ledger=list(csv.DictReader(f,delimiter='\t'))
assert len(ledger)==17
axes,parents=roster(base)
assert axes==(('G',0,0,2),) and len(parents)==16
all_terms=[]
with Path('leaf-ledger.tsv').open('x') as out:
    print('inner','child','axis','coordinate','projected_products','operand_sha256',
          'raw_real','raw_imaginary','factor_denominator','real','imag',
          'independent_products','seconds',sep='\t',file=out)
    for i, (point,weight) in enumerate(parents):
        row=ledger[i]
        assert (int(row['outer6 term']),literal_eval(row['coordinate']),int(row['projected']))==(i,point,weight)
        folder=family(i)
        axes,children=roster(folder)
        assert (len(children),sum(w for _,w in children))==(int(row['nested cells']),int(row['nested projected']))
        terms=[]
        for k,(key,projected) in enumerate(children):
            ref=folder/f'slice{k}'
            assert (ref/'contraction.receipt').read_text().splitlines()[0]=='child_status 0'
            s=(ref/'contraction.out').read_text().splitlines()[-1]
            author_value=Fraction(re.fullmatch(r'exact normalized ([-\d/]+) peak rows \d+ matched products \d+',s)[1])
            src=folder/f'label-s{k}-reduced-frontier.pkl'
            source=src.read_bytes()
            conditioning=loads(source)['conditioning']
            digest=sha256(source).hexdigest()
            assert conditioning==list(zip(axes,key,strict=True))
            log=Path(f'leaf-{i:02d}-{k:02d}.out').read_text()
            assert f'operand {k} {digest} cut {conditioning}' in log.splitlines()
            a,b,d=map(int,re.search(r'^raw scalar (-?\d+) (-?\d+) factor denominator (\d+)$',log,re.M).groups())
            products,elapsed=re.search(r'^replay products (\d+) wall seconds (\S+)$',log,re.M).groups()
            value=(Fraction(phase*a,scale),Fraction(phase*b,scale))
            assert d==N and value==(author_value,Fraction(0))
            print(i,k,axes,key,projected,digest,a,b,d,*value,products,elapsed,sep='\t',file=out)
            terms.append((a,b,value,int(products),float(elapsed)))
        subtotal=tuple(sum(t[2][j] for t in terms) for j in range(2))
        assert subtotal==(Fraction(row['exact real']),Fraction(row['imaginary']))
        print('inner',i,point,weight,len(children),*subtotal,sep='\t')
        all_terms.extend(terms)
assert len(all_terms)==96
raw=tuple(sum(t[j] for t in all_terms) for j in range(2))
total=tuple(sum(t[2][j] for t in all_terms) for j in range(2))
assert total==tuple(Fraction(phase*x,scale) for x in raw)
assert ledger[-1]['outer6 term']=='total'
assert total==(Fraction(ledger[-1]['exact real']),Fraction(ledger[-1]['imaginary']))
print('raw',*raw,N,'normalized',*total,sep='\t')
print('independent leaf products',sum(t[3] for t in all_terms),'max',max(t[3] for t in all_terms),
      'elapsed sum',round(sum(t[4] for t in all_terms),4))
