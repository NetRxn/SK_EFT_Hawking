from setup import *
from concurrent.futures import ThreadPoolExecutor
from time import perf_counter
import subprocess
import sys
from threading import Lock
lock=Lock()
jobs=[(i,k,folder/f'label-s{k}-reduced-frontier.pkl') for i in range(16)
      if (folder:=family(i)).exists() and (folder/'s0.roster').exists()
      for k in range(len(roster(folder)[1])) if (folder/f'label-s{k}-reduced-frontier.pkl').exists()]
def work(job):
    i,k,src=job
    dest=Path(f'leaf-{i:02d}-{k:02d}.out')
    if dest.exists(): return
    start=perf_counter()
    with dest.open('xb') as f:
        run=subprocess.run([sys.executable,'-u','independent-sparse.py',str(k),str(src)],
                            stdout=f,stderr=subprocess.STDOUT,timeout=150)
    with lock:
        print(f'{i}\t{k}\t{run.returncode}\t{perf_counter()-start:.6f}',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(work,jobs))
