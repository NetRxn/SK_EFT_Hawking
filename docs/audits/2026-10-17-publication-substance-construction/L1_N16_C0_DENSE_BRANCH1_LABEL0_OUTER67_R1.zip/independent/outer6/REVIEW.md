# Independent L1 group-128 branch 1, L assignment 0, outer ordinal 6

The independent normalized signed subtotal is
`-8720661076882492896855/10141204801825835211973625643008 + 0i`.
This covers original outer ordinal 6, `G(0,5,1)=81`. The author ledger
agrees at each of its 16 independently recomputed inner values. The previously
reviewed exact signed map transfers this value to outer ordinal 7 at
`G(0,5,1)=84`. This contributes a second equal signed term, with no extra
normalization or multiplicity. The map had checked all raw signed rows and
incident domains of the two operands. This review bound both of those exact
raw operands to their accepted archive hashes and to the current source
inverse lifts. It did not rediscover the signed map.

The continuity adapter was fresh at `e7c97c008170ad43f0a4a27205d68143d8d6256a`.
The independent source audit reconstructed six exhaustive compatible original
L projections, the signed L0 restriction, and all eight outer inverse lifts.
The native branch operand is pinned in the accepted dense binary reduction
archive. Original L0's degree-two cap has 804,480 rows and 870,912 compatible
selected-pair products across the eight-value outer roster. The outer6 cap
hash is `ad52337a77fab78c4b9bce6b6ded77f95ed7fffa3220cc4d888c589c4f7395dd`.
Its selected minimum projected pair is (0,2) with 8,318,976 products.
Its exact next support exhausts the sixteen values of G(0,0,2).

Independent support reconstruction and full signed inverse lifts covered
all sixteen inner and all 96 nested selectors. Inner indices 0–7 split
into eight G(1,5,1) values each. Indices 8–11 split into two R(0,1,2,0,1)
values each. Indices 12–15 split into six G(0,1,2) values each. Every split
preserves the degree-two factor structure on the remaining indices and
the exact denominator. The support counters are join workloads and do not
weight any scalar term.

The independent signed sparse evaluator recomputed 96 distinct exact leaves
from their own quotient inputs, then verified each leaf against its author
terminal result, each of the 16 subtotals, and the whole author ledger.
It used necessary-support pruning, width-aware join selection, and bounds
of 8 million products per join, 30 million per leaf, 1 million rows, and a
30-second arithmetic check. Across the 96 leaves this used 150,512,256
products, a maximum of 5,184,544 within one leaf, and 190.6267 summed
per-leaf seconds. The initial concurrent launch summary has a few interleaved
writes. The separate full per-leaf stdout and hash-bound signed ledger
are the authoritative independent receipts.

The independent raw subtotal is
`-189672937464815997739080479512399365053877359979683652947631144960 + 0i`
on common factor denominator `40512224221827380280140849737629696`.
Reconstruction from frozen profile codes 503841882182 and 1461451755920
gave occupation 32, factorial multiplicity 16, quarter exponent 64, and
even phase from world 136 plus cross 444. The external normalization
`+1/(16 * 4^64)` enters exactly once. Both Gaussian components were evaluated
independently and all 96 imaginary values were zero.

The portable archive preserves the review methods, operand hashes and signed
receipts. The large binary operands are separate and required for a fresh
replay. This review covers outer6 and verification of its transfer through
the previously accepted signed map to outer7. Full group 128 and the L1
manuscript's larger claims require separate evidence.

The author lineage replay reproduced 131 scoped stage observations byte for
byte, including the outer-6 partition, 113 reducers, and 17 cap contractions.
Summed stage elapsed was 789.680 seconds across two workers. Independent signed
restriction and lift audits cover the remaining selectors, and independent
signed arithmetic covers the 96 leaves. All 1,373 scoped author operand and
receipt hashes passed readback.
