from hashlib import file_digest
from pathlib import Path
import shutil
from setup import p as prep,outer,base,first,low,eighth,high
suffixes={'.pkl','.py','.out','.roster','.receipt','.tsv','.err'}
def paths(root):
    return [q for q in root.rglob('*') if q.is_file() and q.suffix in suffixes]
native=Path('/private/tmp/l1-dense-resume.bbZW6V')
families={
    'source':(prep,paths(prep/'branch1-label0')+[prep/'verified-pin/label-0-branch-1.pkl']),
    'native':(native,[native/'row-cap-physical-slice-dense-binary-1.pkl']),
    'outer':(outer,[q for q in paths(outer) if not q.relative_to(outer).parts[0].startswith('slice')
                   or q.relative_to(outer).parts[0]=='slice6']),
    'base':(base,paths(base)),
    'first':(first,paths(first)),
    'low':(low,paths(low)),
    'eighth':(eighth,paths(eighth)),
    'high':(high,paths(high)),
}
with Path('operands.sha256').open('x') as out:
    for family,(base,files) in families.items():
        for src in sorted(files):
            with src.open('rb') as f:
                digest=file_digest(f,'sha256').hexdigest()
            print(digest,src,sep='  ',file=out)
            if src.suffix!='.pkl':
                dst=Path('author-receipts')/family/src.relative_to(base)
                dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(src,dst)
