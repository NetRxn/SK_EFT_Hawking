from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess
import sys
from time import perf_counter
from setup import outer,base,family,roster

target=Path.cwd()/'byte-audit-run'
target.mkdir()
def compare(left,right):
    h=sha256(left.read_bytes()).hexdigest()
    assert h==sha256(right.read_bytes()).hexdigest(),(left,right)
    return h
def stage(name,args,home,expected,code=0):
    start=perf_counter()
    path=home/name
    with (home/expected.name).open('xb') as out:
        check=subprocess.run([sys.executable,'-B',str(path),*args],cwd=home,
                             stdout=out,stderr=subprocess.STDOUT,timeout=150)
    assert check.returncode==code,(home,name,check.returncode)
    compare(home/expected.name,expected)
    return perf_counter()-start
def tools(home,source,*names):
    (home/'checkpoint').mkdir(parents=True)
    for name in names:
        shutil.copyfile(source/name,home/name)

jobs=[('outer',outer,6,base/'partition-input.pkl',True)]
p=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
jobs[0]=('outer',outer,6,p/'branch1-label0/row-cap-physical-slice-dense-branch.pkl',True)
jobs.extend(('inner',base,i,None,True) for i in range(16))
for i in range(16):
    loc=family(i)
    jobs.extend((f'nested{i}',loc,k,None,False) for k in range(len(roster(loc)[1])))
assert len(jobs)==113

def work(job):
    family,loc,i,source,contract=job
    home=target/f'{family}-{i}'
    ref=loc/f'slice{i}'
    tools(home,loc,'contract-with-peer.py','peer_pair.py',
          'exact-multicut.py','reduce-label-frontier.py','checkpoint/quotient.py')
    tag=f's{i}'
    data=f'{tag}.pkl'
    reduced=f'label-{tag}-reduced-frontier.pkl'
    result=[]
    if family=='outer':
        elapsed=stage('exact-multicut.py',[str(source),data,str(i)],home,ref/'partition.out')
        compare(home/f'{tag}.roster',loc/f'{tag}.roster')
        result.append(('partition',compare(home/data,loc/data),elapsed))
    else:
        # Independent support.py certifies the selector output.
        (home/data).symlink_to(loc/data)
    elapsed=stage('reduce-label-frontier.py',[data,tag],home,ref/'reduce.out')
    result.append(('reduce',compare(home/reduced,loc/reduced),elapsed))
    if contract:
        (home/'dense-saturated-frontier.pkl').symlink_to(home/reduced)
        compare(home/'dense-saturated-frontier.pkl',ref/'dense-saturated-frontier.pkl')
        elapsed=stage('contract-with-peer.py',[],home,ref/'contraction.out',2)
        cap='join-cap-physical-slice-dense-branch.pkl'
        result.append(('contract-stop',compare(home/cap,ref/cap),elapsed))
    for name in (data,reduced,'dense-saturated-frontier.pkl','join-cap-physical-slice-dense-branch.pkl'):
        path=home/name
        if path.exists(): path.unlink()
    return family,i,result

with ThreadPoolExecutor(max_workers=int(sys.argv[1])) as pool:
    for family,i,results in pool.map(work,jobs):
        for phase,digest,elapsed in results:
            print(family,i,phase,digest,f'{elapsed:.6f}',sep='\t',flush=True)
