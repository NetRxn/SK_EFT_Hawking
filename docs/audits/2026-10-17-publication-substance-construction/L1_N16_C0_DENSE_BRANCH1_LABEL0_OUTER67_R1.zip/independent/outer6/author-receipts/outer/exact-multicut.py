from collections import Counter
from pathlib import Path
import pickle
import sys

source, out = map(Path, sys.argv[1:3])
data = pickle.loads(source.read_bytes())
factors = data['factors']
i, j = data['rejected_pair']
left, right = factors[i], factors[j]
shared = tuple(w for w in left[0] if w in right[0])
degree = Counter(w for axes, _, _ in factors for w in axes)
assert all(degree[w] == 2 for w in shared)
def histogram(factor):
    positions = tuple(factor[0].index(w) for w in shared)
    return Counter(tuple(row[p] for p in positions) for row in factor[1])
b = histogram(right)
shared_positions = tuple(left[0].index(w) for w in shared)
weights = [(row,b[tuple(row[p] for p in shared_positions)]) for row in left[1]]
weights = [(row,n) for row,n in weights if n]
available = tuple(p for p,w in enumerate(left[0]) if w not in shared and degree[w]==2)
positions = ()
groups = {(): sum(n for _,n in weights)}

def costs(positions):
    totals = Counter()
    for row,count in weights:
        totals[tuple(row[p] for p in positions)] += count
    return totals

while max(groups.values()) > 500_000:
    choices = []
    for p in available:
        if p not in positions:
            candidate = positions+(p,)
            totals = costs(candidate)
            choices.append((max(totals.values()), len(totals), p, totals))
    assert choices, ('no remaining cut axis',groups)
    peak,_,p,groups=min(choices,key=lambda choice:choice[:3])
    positions += (p,)
    print('added axis',left[0][p],'cases',len(groups),'max products',peak,flush=True)
    assert len(positions) <= 12
shared = left[0]
print('partition',tuple(shared[p] for p in positions),'cases',len(groups),'min/max products',min(groups.values()),max(groups.values()),flush=True)
out.with_suffix('.roster').write_text(repr((tuple(shared[p] for p in positions),sorted(groups.items())))+'\n')
values=sorted(groups, key=lambda key:(groups[key],key))[int(sys.argv[3]) if len(sys.argv)>3 else 0]
fixed=dict(zip((shared[p] for p in positions),values))
result=[]
for axes,rows,denominator in factors:
    check=tuple((p,fixed[w]) for p,w in enumerate(axes) if w in fixed)
    keep=tuple(p for p,w in enumerate(axes) if w not in fixed)
    result.append((tuple(axes[p] for p in keep),{tuple(row[p] for p in keep):z for row,z in rows.items() if all(row[p]==v for p,v in check)},denominator))
assert all(rows for _,rows,_ in result)
data['factors']=result
data['conditioning']=[*data.get('conditioning',[]),*fixed.items()]
with out.open('xb') as handle:
    pickle.dump(data,handle,protocol=5)
print('pilot',repr(values),'matched',groups[values],'stored rows',sum(len(r) for _,r,_ in result),flush=True)
