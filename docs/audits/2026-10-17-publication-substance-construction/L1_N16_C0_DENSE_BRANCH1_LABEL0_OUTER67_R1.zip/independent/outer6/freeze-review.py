from hashlib import file_digest
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

cwd=Path.cwd()
fixed={
    'REVIEW.md','accepted-source-pin.out','accepted-normalization.out','lineage.py','lineage.out',
    'operands.sha256','operands-check.out','retally.py','retally.out','leaf-ledger.tsv',
    'setup.py','support.py','support.out','source-and-outer.py','source-and-outer.out','independent-sparse.py',
    'replay.py','replay.tsv','replay-addendum.tsv','freeze-operands.py','freeze-review.py',
    'map-archive.sha256','map-original-unpacked.sha256','map-live-operands.sha256','accepted-map.out','accepted-map.md','map-binding.out','map-binding.py',
}
fixed.update(x.name for x in cwd.glob('leaf-*.out'))
paths=[cwd/name for name in sorted(fixed)]
paths.extend(sorted(x for x in (cwd/'author-receipts').rglob('*') if x.is_file()))
manifest=cwd/'review.sha256'
with manifest.open('x') as out:
    for p in paths:
        with p.open('rb') as f:
            print(file_digest(f,'sha256').hexdigest(),p.relative_to(cwd),sep='  ',file=out)
with ZipFile('portable-review.zip','x',ZIP_DEFLATED,compresslevel=6) as archive:
    for p in [*paths,manifest]:
        archive.write(p,p.relative_to(cwd))
