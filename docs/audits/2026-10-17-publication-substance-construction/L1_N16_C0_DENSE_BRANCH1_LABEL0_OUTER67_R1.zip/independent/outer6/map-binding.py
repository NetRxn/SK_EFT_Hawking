from fractions import Fraction
from pathlib import Path
from re import search,M
from setup import outer
def manifest(path):
    return {Path(name).name:digest for digest,name in
            (line.split(maxsplit=1) for line in Path(path).read_text().splitlines())}
archive=manifest('map-archive.sha256')
assert archive['L1_N16_C0_DENSE_BRANCH1_LABEL0_REUSE_R1.zip']=='8620faa764075ad31673ed01e851b64bdbea06f262d885b305d306251aa992a4'
archived=manifest('map-original-unpacked.sha256')
live=manifest('map-live-operands.sha256')
assert all(archived[name]==sha for name,sha in live.items()) and len(live)==3
accepted=Path('accepted-map.out').read_text()
assert search(r'^PASS exact signed map 6 7 edges 32 edge values 886 .* rows 584868 denominator 40512224221827380280140849737629696$',accepted,M)
source=Path('source-and-outer.out').read_text()
for i,v in ((6,81),(7,84)):
    assert search(rf'^PASS exact lifted case {i} {v} 172800 {live[f"s{i}.pkl"]} ',source,M)
line=next(line for line in Path('retally.out').read_text().splitlines() if line.startswith('raw\t'))
values=tuple(map(Fraction,line.split('\t')[-2:]))
assert values==(Fraction(-8720661076882492896855,10141204801825835211973625643008),Fraction(0))
print('PASS donor and both original (G(0,5,1)) raw selector operands match the accepted signed-map archive')
print('PASS outer7 signed transfer from independently replayed outer6',*values)
