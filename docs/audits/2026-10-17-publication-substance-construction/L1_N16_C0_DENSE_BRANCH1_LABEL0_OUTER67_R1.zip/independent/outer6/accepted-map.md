# Independent original signed maps of group 128 branch 1, L assignment 0

Both raw maps preserve the exact signed complex contraction. Outer ordinal 0 at `G(0,5,1)=7` transfers its independently accepted scalar to ordinal 1 at value 13. The exact result is `−1746699869512866458538495/649037107316853453566312041152512 + 0i`. A separate author ledger with 22 terms agrees. The map from ordinal 6 at value 81 to ordinal 7 at value 84 proves exact equality. A numerical value for that pair requires its own accepted donor.

The continuity packet matched publication checkpoint `cd4740a06666f0b337768efcf0a63e5c8a583765`. The accepted dense binary archive supplies the original first-index branch 1 state with uncompressed SHA-256 `4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be`. Independent finite projection recovered all six complete L assignments and all 804,480 Gaussian rows of the L0 parent before the first join. Its exact signed tables are the direct L0 restriction of the original branch. The independent outer census exhausted eight values and 870,912 compatible products. The raw inverse lifts at all four selected coordinates recovered their exact parent rows and positive denominators.

Each witness uses the original order of the ten factors. The review independently recovered all 32 edge scopes and both endpoints of every edge. Each witness bijects the full 886 edge values and restricts correctly to each endpoint's actual domain, including the compatible intersection. The review checked all 555,612 rows in the first map and 584,868 rows in the second map, in the original raw axis order. The checked coefficient relation applies to both Gaussian components. Equal table cardinalities and the edge bijections make each row match exhaustive in both directions.

For each compatible closed assignment, the associated edge sign occurs twice, once at each endpoint. It therefore cancels in the product of the ten factors. The edge bijections preserve the summation domain, with no multiplier. The product of the original factor denominators stays `40512224221827380280140849737629696`. The fixed mode records independently give world phase exponent 136, crossing exponent 444, occupation total 32 and factorial denominator 16. The shared external normalization is positive `1/(16*4^64)`, independent of the four conditioning values.

The scope is the two original signed-map equalities and the transfer of the accepted ordinal-0 scalar to ordinal 1. The full original B3 scalar remains open.

## Verification and operands

The compact manifest includes the signed witnesses, source receipts, donor acceptance receipts, raw hashes, and exhaustive verification code. The large operands are bound by `serialized-operands.sha256`. That separate inventory contains the exact committed `L1_N16_C0_DENSE_BINARY_REDUCTION_R1.zip` and gzip copies of the native label-0 cap and raw selections `s0.pkl`, `s1.pkl`, `s6.pkl` and `s7.pkl`. The original uncompressed hashes are in `original-unpacked.sha256`. The archive blob is recorded in `inputs/archive-blob.txt`.

To reconstruct the optional large files from the original sources, read the archive at the named publication commit and gzip each raw source with `gzip -1 -n -c`. The cap is `branch1-label0/row-cap-physical-slice-dense-branch.pkl` under `/private/tmp/l1-group128-branch1-preparation.SlDJuy`. The four raw selections are in `/private/tmp/l1-branch1-label0-roster.XAoNMg`. Store the reconstructed files at the relative paths in the serialized operand manifest.

Run from this directory.

```sh
shasum -a 256 -c review-manifest.sha256
shasum -a 256 -c serialized-operands.sha256
python3 -B verify-map.py | cmp - verify-map.out
```
