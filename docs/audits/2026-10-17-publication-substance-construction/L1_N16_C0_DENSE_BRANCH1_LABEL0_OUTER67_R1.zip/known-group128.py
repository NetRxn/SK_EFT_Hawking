from csv import DictReader
from fractions import Fraction
from io import StringIO
from pathlib import Path
from zipfile import ZipFile
import sys

audit=Path(sys.argv[1])
checks=Path(__file__).resolve().parent
names='L1_N16_C0_DENSE_'
def extract(archive,entry):
    with ZipFile(audit/(names+archive+'.zip')) as z:
        return z.read(entry).decode('utf-8',errors='strict')
def real0(row):
    r,im=map(Fraction,row)
    assert im==0
    return r
def row(archive,entry,key):
    data=[line.split('\t') for line in extract(archive,entry).splitlines()]
    [x]=[r for r in data if r[0]==key]
    return real0(x[1:3])

known={}
known['branch0']=row('CHILD01_PAIRED_COMPLETE_BRANCH0_R1','recombined.tsv','first-index branch0')
for assignment in (1,2):
    known[f'branch1 L{assignment}']=row(f'BRANCH1_LABEL{assignment}_R1','verified-composition.tsv','total')
for assignment in (3,4,5):
    known[f'branch1 L{assignment}']=row('BRANCH1_LABELS345_R1','verified-exact-values.tsv',str(assignment))
scope=list(DictReader(StringIO(extract('BRANCH1_LABEL0_REUSE_R1','verified-scope.tsv')),delimiter='\t'))
assert [r['outer'] for r in scope]==list(map(str,range(8)))
assert [int(r['anchor']) for r in scope]==[0,0,2,2,2,2,6,6]
for i in (0,1):
    term=scope[i]
    assert term['state']=='verified exact scalar'
    known[f'branch1 L0 outer{i}']=real0((term['real'],term['imaginary']))
accepted=(checks/'verified-values.tsv').read_text().splitlines()
assert [r.split('\t')[0] for r in accepted]==['outer-6','outer-7']
for line in accepted:
    key,*parts=line.split('\t')
    known['branch1 L0 '+key.replace('-','')]=real0(parts)
assert len(known)==10
print('original scope','exact real','imaginary',sep='\t')
for key,val in known.items():
    print(key,val,0,sep='\t')
print('known subtotal',sum(known.values()),0,sep='\t')
print('remaining', 'four original outer values 2–5 via one representative',sep='\t')
