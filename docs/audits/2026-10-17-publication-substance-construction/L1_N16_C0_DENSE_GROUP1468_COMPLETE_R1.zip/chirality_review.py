from ast import literal_eval
from collections import Counter,defaultdict
from fractions import Fraction
from hashlib import file_digest,sha256
from itertools import combinations,product
from math import factorial,lcm,prod
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile
from io import BytesIO
import re

PUB=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
HEAD='085be20e08752d1c77668c2e097fc7ed32e948b0'
ROOT='docs/audits/2026-10-17-publication-substance-construction'
DIGESTS={
 'DENSE_FACTOR_INPUTS_INDEPENDENT':'a9088fd54fbdb92c2a74fc7331f9793c950ba790cd5d89a8143f32af5fc93983',
 'DENSE_REUSE_PILOT':'c078c4fc4efc7ca903e17db526209e20a5692c260f202d837eac586a5a420416',
 'DENSE_COMPILED_FACTORS':'d66dc728ccb948a2630ea87b242564fba9b2c89ed51b3d9f3f100516f270ea42',
 'DENSE_GROUP128_COMPLETE':'9000d548ccd03c538315e7c84d0ab79a468595aeb6a3110ff549fc7f032576e2',
 'DENSE_GROUP672_COMPLETE':'8a93fb0149c6f918542338f5550be24581c875b761977d6dae350b50adc71f7a',
 'DENSE_GROUP934_COMPLETE':'8ec12dd30a63e16113cc022f4375e6b151db62142ca340c73bb53b5f1793531e',
}

def committed(kind):
    name=f'{ROOT}/L1_N16_C0_{kind}_R1.zip'
    raw=check_output(['git','-C',str(PUB),'show',f'{HEAD}:{name}'])
    digest=sha256(raw).hexdigest()
    assert digest==DIGESTS[kind]
    z=ZipFile(BytesIO(raw))
    assert len(z.namelist())==len(set(z.namelist()))
    manifest=next(s for s in ('SHA256SUMS','manifest.sha256') if s in z.namelist())
    for l in z.read(manifest).decode().splitlines():
        h,n=l.split(maxsplit=1)
        assert sha256(z.read(n.removeprefix('./'))).hexdigest()==h
    print('committed archive and manifest',kind,digest,flush=True)
    return z

def chirality_key(key):
    return tuple((b,a) for a,b in key)

def chr_family(family):
    return family[:-1]+str(1-int(family[-1])) if family.startswith('T') else family

def chr_wire(axis):
    return (*axis[:-1],1-axis[-1]) if axis[0]=='R' else axis

def physical_normalization():
    with committed('DENSE_FACTOR_INPUTS_INDEPENDENT') as z:
        review=z.read('independent/REVIEW.md').decode()
        assert all(key in review for key in ('original gamma3 chiral exchange','15,488 two-member orbits',
                  'preserves the filled site exterior measure','Weight 48 in the accepted ledger is external'))
        geom=z.read('independent/geometry-check.out').decode()
        assert 'fixed 0 two-member orbits 15488' in geom
        profile=tuple(map(int,z.read('independent/profiles.tsv').split()))
        assert profile==(503841882182,1461451755920,48)
    occ_keys=[d for d in product(range(5),repeat=3) if sum(d)<=4]
    occ=tuple(tuple(occ_keys[code>>(6*x)&63] for x in range(8)) for code in profile[:2])
    insertions=sum(n for layer in occ for row in layer for n in row)
    multiplicity=prod(factorial(n) for layer in occ for row in layer for n in row)
    assert (insertions,multiplicity)==(32,16)
    edges=sorted((a,b,k) for a in range(8) for k in range(3) if a < (b:=a^(1<<k)))
    eps=sum(n*(3+k) for layer in occ for row in layer for k,n in enumerate(row))
    cross=0
    for layer in occ:
        edge_sizes=[sum(layer[a])+sum(layer[b])-layer[a][k]-layer[b][k] for a,b,k in edges]
        cross+=sum(m*n*sum(x>y for x in e[:2] for y in f[:2])
           for (e,m),(f,n) in combinations(zip(edges,edge_sizes,strict=True),2))
    assert (eps,cross)==(136,444)
    literal_source=check_output(['git','-C',str(PUB),'show',f'{HEAD}:{ROOT}/l1_direct_b_haar.py'])
    assert literal_source==Path('literal-gamma-source.py').read_bytes()
    assert b'gamma.append(zeros(2).row_join(eye(2)).col_join(eye(2).row_join(zeros(2))))' in literal_source
    assert b'gamma5=diag(1,1,-1,-1)' in literal_source
    assert b'pauli=[Matrix([[0,1],[1,0]]),Matrix([[0,-I],[I,0]]),diag(1,-1)]' in literal_source
    assert b'gamma=[zeros(2).row_join(-I*p).col_join((I*p).row_join(zeros(2))) for p in pauli]' in literal_source
    perm=tuple(j^2 for j in range(4))
    assert all(perm[perm[j]]==j for j in range(4))
    assert sum(x>y for x,y in combinations(perm,2))%2==0
    gamma5=(1,1,-1,-1)
    assert tuple(gamma5[j] for j in perm)==tuple(-x for x in gamma5)
    pauli=(((0,0),(1,0),(1,0),(0,0)),
           ((0,0),(0,-1),(0,1),(0,0)),
           ((1,0),(0,0),(0,0),(-1,0)))
    def gamma_entry(j,k,p):
        if j//2==k//2:return (0,0)
        re,im=p[(j%2)*2+k%2]
        phase=1 if j>=2 else -1
        return -phase*im,phase*re
    for p in pauli:
        for j,k in product(range(4),repeat=2):
            assert gamma_entry(perm[j],perm[k],p)==tuple(-x for x in gamma_entry(j,k,p))
    print('literal gamma3 involution, determinant +1, gamma5 sign -1 and three Clifford conjugation signs',flush=True)
    assert (-1)**(eps+cross)==(-1)**insertions==1
    print('physical source',profile,'insertions factorial quarter-exponent world cross',
          insertions,multiplicity,2*insertions,eps,cross,flush=True)
    return multiplicity*4**(2*insertions),profile[2]

def load_cut():
    with committed('DENSE_REUSE_PILOT') as z, committed('DENSE_COMPILED_FACTORS') as compiled:
        def parse(name):
            return [row.split('\t') for row in z.read(f'census/{name}').decode().splitlines()]
        plan=[(int(i),int(n),int(rows),int(b),literal_eval(key),literal_eval(ids))
              for i,n,rows,b,key,ids in parse('cut-plan.tsv')]
        blocks=[(name,literal_eval(key),int(start),int(size),int(rows),int(den))
                for name,key,start,size,rows,den in parse('block-index.tsv')]
        assert z.read('census/block-index.tsv')==compiled.read('block-index.tsv')
        assert z.read('group934/schema.tsv')==compiled.read('schema.tsv')
        schema={name:(literal_eval(L),literal_eval(P)) for name,L,P,*_ in
                (line.split('\t') for line in compiled.read('schema.tsv').decode().splitlines())}
        axes=literal_eval(z.read('census/cut-axes.tsv').decode())
    assert len(schema)==88 and len(axes)==len(set(axes))==16
    assert tuple(sorted(set(schema['M01'][0])|set(schema['M06'][0])))==axes
    assert [i for i,*_ in plan]==list(range(3872))
    assert len({row[4] for row in plan})==len(plan)
    assert len({(f,k) for f,k,*_ in blocks})==len(blocks)==2456
    return plan,blocks,schema,axes

def label_support(schema,blocks):
    rel=defaultdict(set)
    for name,key,*_ in blocks:rel[name].add(key)
    rules={}
    for name,(axes,_) in schema.items():
        ordered=tuple(sorted(axes))
        indices=tuple(axes.index(k) for k in ordered)
        rows={tuple(key[i] for i in indices) for key in rel[name]}
        assert rules.setdefault(ordered,rows)==rows
    assert len(rules)==36
    axes=tuple(sorted({k for order in rules for k in order}))
    direct=defaultdict(set)
    with committed('DENSE_FACTOR_INPUTS_INDEPENDENT') as evidence:
        with ZipFile(BytesIO(evidence.read('independent/DIRECT-published.zip'))) as origin:
            for line in origin.read('manifest.sha256').decode().splitlines():
                h,n=line.split(maxsplit=1)
                assert sha256(origin.read(n.removeprefix('./'))).hexdigest()==h
            for line in origin.read('503841882182-1461451755920-local-labels.tsv').decode().splitlines():
                scope,key=map(literal_eval,line.split('\t'))
                known=dict(zip((('L',*w) for w in scope),key,strict=True))
                assert all(v==(0,0) for w,v in known.items() if w not in axes)
                reduced=tuple(w for w in sorted(known) if w in axes)
                direct[reduced].add(tuple(known[w] for w in reduced))
    assert direct==rules and sum(map(len,direct.values()))==740
    print('all 740 local relations match the independently accepted same-profile direct constraints',flush=True)
    domain={k:set() for k in axes}
    for order,rows in rules.items():
        for k,values in zip(order,zip(*rows),strict=True):domain[k].update(values)
    # Tabulate each variable/value as a bitset of allowed local rows. At
    # each branch, propagate the joined domains until they stabilize.
    dimensions={k:tuple(sorted(v)) for k,v in domain.items()}
    tables=[]
    neighbors=defaultdict(list)
    for order,rows in rules.items():
        look=[]
        for i,k in enumerate(order):
            masks=defaultdict(int)
            for bit,row in enumerate(sorted(rows)):masks[row[i]]|=1<<bit
            look.append((k,masks))
            neighbors[k].append(len(tables))
        tables.append((look,(1<<len(rows))-1))
    states=[]
    nodes=0
    def solve(d,work):
        nonlocal nodes
        nodes+=1
        while work:
            i=work.pop()
            vectors,allowed=tables[i]
            for k,masks in vectors:
                v=0
                for x in d[k]:v|=masks[x]
                allowed &= v
                if not allowed:return
            for k,masks in vectors:
                subset=tuple(x for x in d[k] if masks[x]&allowed)
                if subset!=d[k]:
                    d[k]=subset
                    work.update(neighbors[k])
        k=min((k for k in axes if len(d[k])>1),key=lambda k:(len(d[k]),-len(neighbors[k])),default=None)
        if k is None:
            states.append(tuple(d[w][0] for w in axes))
        else:
            for x in d[k]:
                child=d.copy()
                child[k]=(x,)
                solve(child,set(neighbors[k]))
    solve(dimensions,set(range(len(tables))))
    assert len(states)==len(set(states))==30_976
    print('exact compiled natural-join support',len(axes),'L axes',len(rules),'complete constraints',nodes,'branch nodes',len(states),'states',flush=True)
    return axes,states,rel

def cut_pairing(plan,blocks,schema,cut):
    by_block={(f,k):i for i,(f,k,*_) in enumerate(blocks)}
    images={i:by_block[chr_family(f),chirality_key(k)] for i,(f,k,*_) in enumerate(blocks)}
    assert all(images[images[i]]==i and blocks[i][-2:]==blocks[images[i]][-2:] for i in images)
    for name,(L,P) in schema.items():
        other=chr_family(name)
        assert schema[other][0]==L and set(map(chr_wire,P))==set(schema[other][1])
    degrees=Counter(w for L,P in schema.values() for w in P)
    assert len(degrees)==424 and set(degrees.values())=={2}
    assert all(chr_wire(chr_wire(w))==w and degrees[w]==degrees[chr_wire(w)] for w in degrees)
    axes,states,relations=label_support(schema,blocks)
    S=set(states)
    assert all(key!=chirality_key(key) and chirality_key(key) in S for key in S)
    fix=tuple(axes.index(w) for w in cut)
    groups=defaultdict(list)
    for key in states:groups[tuple(key[i] for i in fix)].append(key)
    lookup={key:i for i,n,r,b,key,ids in plan}
    assert set(groups)==set(lookup) and all(len(v)==8 for v in groups.values())
    by_index={i:row for row in plan for i in row[:1]}
    local={f:tuple(axes.index(w) for w in L) for f,(L,P) in schema.items()}
    by_view=defaultdict(list)
    for idx,(f,tag,*_) in enumerate(blocks):
        fam_axes=schema[f][0]
        by_view[f,tuple(v for w,v in zip(fam_axes,tag,strict=True) if w in cut)].append(idx)
    fixed_positions={f:tuple(cut.index(w) for w in L if w in cut) for f,(L,_) in schema.items()}
    pairs={}
    computed={}
    extra_counts=Counter()
    for i,n,r,b,key,ids in plan:
        projected={by_block[f,tuple(state[j] for j in cols)]
                   for f,cols in local.items() for state in groups[key]}
        expected_ids={idx for f,fixed in fixed_positions.items()
                      for idx in by_view[f,tuple(key[j] for j in fixed)]}
        assert tuple(sorted(expected_ids))==ids
        assert projected<=expected_ids
        extra_counts[len(expected_ids-projected)]+=1
        assert sum(blocks[x][4] for x in ids)==r and sum(blocks[x][3] for x in ids)==b
        partner=lookup[chirality_key(key)]
        assert partner!=i
        assert {chirality_key(st) for st in groups[key]}==set(groups[chirality_key(key)])
        assert {images[x] for x in ids}==set(by_index[partner][5])
        factor_dens=defaultdict(list)
        for idx in ids:
            f,k,start,size,rows,den=blocks[idx]
            factor_dens[f].append(den)
        assert set(factor_dens)==schema.keys()
        den=prod(lcm(*values) for values in factor_dens.values())
        computed[i]=(n,r,den)
        pairs[i]=partner
    assert all(pairs[pairs[i]]==i and computed[i]==computed[pairs[i]] for i in pairs)
    assert len(pairs)==3872 and sum(i<j for i,j in pairs.items())==1936
    assert sum(x[1] for x in computed.values())==10_581_286_320
    print('partition fibers and signed exchange',len(cut),'fixed axes',len(groups),'disjoint cut groups',len(images),'blocks',len(degrees),'wires',flush=True)
    print('locally admitted blocks beyond globally extendible projections per group',sorted(extra_counts.items()),flush=True)
    return pairs,computed

def exact_receipts(pairs,computed,scale,weight):
    with committed('DENSE_GROUP128_COMPLETE') as z:
        tab={cols[0]:(Fraction(cols[1]),Fraction(cols[2])) for cols in
             (s.split('\t') for s in z.read('verified-group128.tsv').decode().splitlines()[1:])}
        assert tuple(x+y for x,y in zip(tab['branch0'],tab['branch1'],strict=True))==tab['group128']
        accepted={128:tab['group128']}
    for group,name in ((672,'RETALLY.txt'),(934,'AUTHOR_RETALLY.txt')):
        with committed(f'DENSE_GROUP{group}_COMPLETE') as z:
            lines=z.read(name).decode().splitlines()
            terms=[re.fullmatch(r'original joint-L (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)',s) for s in lines if s.startswith('original joint-L ')]
            assert [int(term[1]) for term in terms]==list(range(8))
            assert {int(term[4]) for term in terms}=={computed[group][2]}
            value=tuple(sum(Fraction(int(t[k]),int(t[4])*scale) for t in terms) for k in (2,3))
            tag=('normalized signed total ' if group==672 else 'exact normalized ')
            expected=next(s.removeprefix(tag).split() for s in lines if s.startswith(tag))
            assert value==tuple(map(Fraction,expected))
            accepted[group]=value
    closure={}
    for i,value in accepted.items():
        j=pairs[i]
        assert value[1]==0 and i not in closure and j not in closure
        closure[i]=closure[j]=value
    remainder={min(i,pairs[i]) for i in pairs if i not in closure}
    assert len(closure)==6 and len(remainder)==1933
    subtotal=tuple(sum(v[i] for v in closure.values()) for i in (0,1))
    weighted=tuple(weight*v for v in subtotal)
    print('covered exact groups',sorted(closure),'remainder individual groups',len(pairs)-len(closure),'representatives',len(remainder),flush=True)
    print('signed normalized subtotal',*subtotal,'weight-48 subtotal',*weighted,flush=True)
    return accepted,subtotal,weighted

def check_candidate(pairs,computed,receipt):
    code=Path('candidate/pair-retally.py').read_bytes()
    raw_bytes=Path('candidate/pair-retally.tsv').read_bytes()
    assert sha256(code).hexdigest()=='88601f8d4f064ebc0bf2b10dbdc7f202c46550d118e9be9b8575aeebd4ce7af5'
    assert sha256(raw_bytes).hexdigest()=='ae01d0665b4122fb0251332ee67f8d43bc5c4d80052ca8309053fc503ece5185'
    raw=raw_bytes.decode().splitlines()
    mark=raw.index('direct\tpaired\texact normalized real of each\timaginary')
    pair_rows=[tuple(map(int,s.split('\t'))) for s in raw[1:mark]]
    assert pair_rows==[(i,pairs[i],*computed[i]) for i in sorted(pairs) if i<pairs[i]]
    accepted,subtotal,weighted=receipt
    for row in raw[mark+1:mark+4]:
        a,b,v,w=row.split('\t')
        assert int(b)==pairs[int(a)] and accepted[int(a)]==(Fraction(v),Fraction(w))
    assert f'paired signed normalized subtotal before outer orbit weight {subtotal[0]} {subtotal[1]}' in raw
    assert f'paired signed normalized subtotal including outer orbit weight 48 {weighted[0]} {weighted[1]}' in raw
    assert 'groups covered 6 groups remaining 3866' in raw
    assert 'unevaluated representative groups 1933' in raw
    upper=max(r for n,r,d in computed.values())
    top=tuple(i for i in sorted(computed) if computed[i][1]==upper)
    assert top==(934,1673,2198,2937) and upper==3436540
    assert pairs[934]==2937 and pairs[1673]==2198
    print('verified complete candidate pair ledger and all four upper-stratum bindings',top,upper,flush=True)

if __name__=='__main__':
    scale,weight=physical_normalization()
    pairs,computed=cut_pairing(*load_cut())
    check_candidate(pairs,computed,exact_receipts(pairs,computed,scale,weight))
