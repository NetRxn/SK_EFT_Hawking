"""Independently bind native and continuation refusal records to full replay and pinned state."""
from pathlib import Path
from ast import literal_eval
from prefix import BASE,SURVIVORS,CAP,sha,read
import re
rows=[]
for i in SURVIVORS:
    author=BASE/f'L{i}'
    local=Path(f'author/L{i}')
    replay=Path(f'L{i}-replay.out').read_text()
    cap=author/CAP
    pin=sha(cap)
    x=read(cap)
    m=re.search(rf'^independent exact native cap tables {i} {pin} (\d+) (\d+) (\d+) (\d+) \((\d+), (\d+)\) (\d+) (\d+) (\d+)$',replay,re.M)
    assert m
    nf,r,_,work,a,b,proposal,visits,threshold=map(int,m.groups())
    assert len(x['factors'])==nf and sum(len(z) for _,z,_ in x['factors'])==r
    assert (x['used_before'],x['rejected_pair'],x['matched'])==(work,(a,b),proposal)
    assert 500_001<=visits<=proposal<=8_000_000 and threshold==500_001
    assert f'open row cap {nf} {proposal} frontier saved' in (local/'contraction.out').read_text().splitlines()
    rows.append((i,0,'rows',repr((a,b)),proposal,visits,threshold,pin,'independent_native_threshold'))
    del x
    for k in sorted(local.glob('pass[1-9].out')):
        n=int(k.stem[-1])
        name='unsharded-result.pkl' if n==1 else f'pass{n}-result.pkl'
        state=author/name
        log=k.read_text()
        assert f'preserved checkpoint {name} {sha(state)} ' in log
        receipts=[literal_eval(s) for s in re.findall(
            r'^(?:bounded refusal|follow refused) (\(.*\)) (?:cumulative|work) \d+$',log,re.M)]
        record=read(state)['refused_pairs']
        assert receipts==record
        for item in record:
            if n==1:
                a,b,p,v,kind=item
                supported='not recorded'
            else:
                a,b,p,v,supported,kind=item
                assert 0<supported<=v
            assert a!=b and 0<v<=p<=8_000_000 and kind in ('rows','wall')
            if kind=='rows':
                assert 500_001<=v
                if n>1:assert 500_001<=supported
            rows.append((i,n,kind,repr((a,b)),p,v,supported,sha(state),'author_typed_discarded_trial'))
        totals=re.search(rf'^stage counts {n} \d+ \d+ \d+ \d+ \d+ (\d+)$',replay,re.M)
        assert totals and int(totals[1])==sum(x[3] for x in record)
Path('typed-refusals.tsv').write_text(
    'ordinal\tstage\ttype\tpair\tforecast\tvisits\tthreshold_or_supported\tsaved_state_sha256\tevidence\n'+
    ''.join('\t'.join(map(str,row))+'\n' for row in rows))
print('exact typed refusal journal matches',len(rows),'events; native guard independently replayed',flush=True)
