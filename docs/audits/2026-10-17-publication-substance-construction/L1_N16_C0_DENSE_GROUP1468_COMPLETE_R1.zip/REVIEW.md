# Independent complete signed Group 1468 review

The work-start continuity check accepted publication commit `085be20e08752d1c77668c2e097fc7ed32e948b0`. The separately accepted component-14 preparation archive `prior-preparation.zip` has SHA256 `11a4aa7e219c2a727a8a118a9910a8665bef7ed135ebd5531b3d30d926cfb56b` and binds all 88 signed prepared factor families, both exact zero restrictions, and the original label roster to `dc3454bc55972b1bafb3eb3fea09e9cd184c8a3be920f4df59e8e151a6bd806d`. The prepared source has 582,699 stored rows after both accepted signed sweeps from 2,420,774 selected input rows. This review begins at that exact prepared source and verifies the preparation archive's manifest, author receipt readback and original frozen source scope.

I independently enumerated the 4,096 binary values of the 12 retained joint-L axes and verified all eight original indices. The six live original ordinals remain 0, 1, 2, 3, 4 and 6. At original 5 and 7 I independently rechecked the exact names of all seven empty restricted factors and bound the accepted proof of exact zero. The initial scratch harness mistakenly expected the empty-factor count from a previous group. Its L4/L6 assertion logs are retained. The corrected check uses the exact archived list per original ordinal. The six live signed selections independently inverse-lift every conditioned row to the prepared input, with exact labels and factor denominators.

The separate alternate sparse replays reproduce each native row-cap refusal and retained tables under unchanged numerical limits. Every continuation independently inverts exact splits, carries Gaussian phase and magnitude across closed degree-two axes only, and recomputes each retained join with alternate sparse iteration and peer-support projections. Full coefficient-table equality holds through every retained state, including three-factor endpoints. Discarded continuation trials are bound to their exact typed original log and saved checkpoint journal. Their charged work stays separate from accepted retained arithmetic.

L0 and L6 use independent third-pivot triangle contractions. Their original author covers are checked against the original stored row order, with at most 8,000,000 compatible products per interval. The independent sparse natural-key traversals exhaust all 7,192,576 L0 and 12,386,304 L6 signed products exactly once and match both author pivots.

## Exact composition and timing

All eight original terms have zero imaginary part and share the positive inherited denominator `175635987074934534906874926465024`. `scalar.tsv` records exact source labels, raw numerators and terminal hashes. `composition.tsv` gives the exact stored-factor value, signed value with physical prefactor, and standalone weighted contribution.

The independent source record and direct cross-check identify Group 1468 on the selected side of component 14 and bind every one of the 128 original directed label crossings of this (K_{8,8}) component. Chiral partner 2682 has the opposite ordered chiral key and the same exact inherited denominator. The physical sign is positive and the divisor is (2^{132}). The cover coefficient 192 applies once, from occupation weight 48, the chiral factor two and the selected geometric side factor two.

The timing ledger separates preparation, native guarded work, continuation, separate triangle time, and each solve wall. These measured components describe this group, and do not establish a wider campaign runtime.

## Reproduction

Verify `review.sha256` and locate the unchanged frozen binary operands pinned under each `author/L*`. From this review directory:

```sh
python3 -B source_review.py
python3 -B controls.py
for i in 0 1 2 3 4 6; do python3 -B prefix.py "$i"; done
python3 -B typed_refusals.py
python3 -B retally.py
```

If a triangle author receipt completes after an independent retained replay, `finish_triangle.py ORDINAL` binds it to the exact accepted endpoint. The archive includes the independent preparation proof, original author records, reviewer checks and exact signed ledgers. Large binary operands remain external and checksum-pinned.
