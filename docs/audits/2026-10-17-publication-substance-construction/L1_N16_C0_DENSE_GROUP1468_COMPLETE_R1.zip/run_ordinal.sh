#!/bin/bash
set -eu -o pipefail
i=$1
b=/private/tmp/l1-component14-remaining.fvZB2B/group-1468/cached-original-roster
a="$b/L$i"
f="author/L$i"
test -s "$b/solve-L$i.time"
mkdir -p "$f"
(cd "$a" && shasum -a 256 ./*.py ./*.pkl ./*.out ./*.receipt ./*.err ./*.tsv | sed 's%  \./%  %') > "$f/frozen-inputs.sha256"
for x in "$a"/*.py "$a"/*.out "$a"/*.receipt "$a"/*.err "$a"/*.tsv "$b/solve-L$i.out" "$b/solve-L$i.time"; do cp "$x" "$f"; done
if [ -s "$a/terminal.time" ]; then cp "$a/terminal.time" "$f"; fi
code=0
python3 -B prefix.py "$i" > "L$i-replay.out" 2> "L$i-replay.err" || code=$?
printf '%s\n' "$code" > "L$i-status.out"
test "$code" = 0
