from pathlib import Path
from hashlib import file_digest
from zipfile import ZipFile,ZIP_DEFLATED
assert Path('scalar.tsv').read_text().count('\n')==9
assert Path('cap-work.tsv').read_text().count('\n')==7
assert 'physical_cover_contribution' in Path('composition.tsv').read_text()
assert 'whole signed exact raw' in Path('retally.out').read_text()
assert 'exact typed refusal journal matches' in Path('typed-refusals.out').read_text()
assert Path('typed-refusals.tsv').read_text().count('independent_native_threshold')==6
def hashfile(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
exclude=('review.sha256','portable-review.zip','review-check.out')
files=sorted(p for p in Path('.').rglob('*') if p.is_file() and p.name not in exclude and
             p.suffix!='.pkl' and '__pycache__' not in p.parts)
manifest=Path('review.sha256')
manifest.write_text(''.join(f'{hashfile(p)}  {p}\n' for p in files))
with ZipFile('portable-review.zip','w',compression=ZIP_DEFLATED,compresslevel=9) as z:
    for p in [*files,manifest]:z.write(p)
with ZipFile('portable-review.zip') as z:
    assert z.testzip() is None
