from pathlib import Path
from hashlib import sha256,file_digest
from zipfile import ZipFile
from subprocess import check_output
from io import BytesIO
from ast import literal_eval
from csv import DictReader
from itertools import product
from collections import defaultdict
from math import lcm,prod
from prefix import BASE,N,PARENT_SHA,sha,read
from chirality_review import physical_normalization,load_cut
import json

def verify(z,manifest):
    assert len(z.namelist())==len(set(z.namelist()))
    for line in z.read(manifest).decode().splitlines():
        h,n=line.split(maxsplit=1)
        assert sha256(z.read(n.removeprefix('./'))).hexdigest()==h
prep=Path('prior-preparation.zip')
assert sha(prep)=='11a4aa7e219c2a727a8a118a9910a8665bef7ed135ebd5531b3d30d926cfb56b'
with ZipFile(prep) as z:
    verify(z,'MANIFEST.sha256')
    for n in ('frontier.sha256','original-labels.tsv','original-roster.txt','prepared-roster.tsv','ordinal-roster.tsv','result.json','preparation.out','preparation.time'):
        assert z.read('group-1468/'+n)==Path('source',n).read_bytes()
    assert z.read('group-1468/author-original-label-roster.tsv')==Path('source/original-label-roster.tsv').read_bytes()
    receipt=json.loads(z.read('group-1468/result.json'))
    assert receipt['prepared_sha256']==PARENT_SHA and receipt['denominator']==N
    assert receipt['remaining_ordinals']==[0,1,2,3,4,6] and receipt['proved_zero_ordinals']==[5,7]
    assert (receipt['source_rows'],receipt['prepared_rows'])==(2420774,582699)
    expected='independent preparation verified'
    assert expected in z.read('replay-1468.out').decode()
    for n in ('component14-crossing.tsv','geometry.tsv','phase-geometry.out'):
        Path('source',n).write_bytes(z.read(n))
    preparation=BASE.parent
    for n in ('preparation.out','preparation.time','frontier.sha256'):
        assert (preparation/n).read_bytes()==Path('source',n).read_bytes()
    assert sha(preparation/'dense-saturated-frontier.pkl')==sha(BASE/'dense-saturated-frontier.pkl')==PARENT_SHA

packet=json.loads(Path('continuity-packet.json').read_text())
for name,meta in packet['owned_state'].items():
    zbytes=check_output(['git','-C',packet['checkout'],'show',f"{packet['source']['head']}:{name}"])
    assert sha256(zbytes).hexdigest()==meta['sha256']
    if 'DENSE_GEOMETRY_COVER' in name:
        with ZipFile(BytesIO(zbytes)) as z:
            verify(z,'SHA256SUMS')
            assert b'weights 192' in z.read('README.md')
    print('pinned assigned source archive',name,meta['sha256'],flush=True)

def tsv(n):
    with Path('source',n).open() as f:
        return list(DictReader(f,delimiter='\t'))
geometry=next(r for r in tsv('geometry.tsv') if r['group']=='1468')
group=1468; partner=int(geometry['gamma3_partner'])
assert geometry['component']=='14' and partner==2682
A,B=(set(literal_eval(geometry[k])) for k in ('selected_side','mirror_side'))
assert group in A and len(A)==len(B)==8 and not A&B
c=tsv('component14-crossing.tsv')
triples={(int(r['canonical_original_group']),int(r['target_canonical_group']),int(r['source_completion_ordinal'])) for r in c}
assert len(triples)==len(c)==128
assert {(x,y) for x,y,_ in triples}=={*product(A,B),*product(B,A)}
assert all({i for x,_,i in triples if x==g}==set(range(8)) for g in A|B)
assert len({int(r['gamma3_partner']) for r in c if int(r['canonical_original_group'])==group})==1
assert {int(r['gamma3_partner']) for r in c if int(r['canonical_original_group'])==group}=={partner}
plan,blocks,schema,axes=load_cut()
assert len(axes)==16 and tuple((q,p) for p,q in plan[group][4])==plan[partner][4]
for g in (group,partner):
    groups=defaultdict(list)
    for i in plan[g][5]:
        label,key,location,encoded,nrows,denom=blocks[i]
        groups[label].append(denom)
    assert len(groups)==88 and prod(lcm(*d) for d in groups.values())==N
zero_rows=tsv('ordinal-roster.tsv')
assert [int(x['original_ordinal']) for x in zero_rows]==list(range(8))
zeros=[x for x in zero_rows if x['disposition']=='exact_zero']
assert [int(x['original_ordinal']) for x in zeros]==[5,7]
L,original=literal_eval(Path('source/original-roster.txt').read_text())
fs=read(BASE/'dense-saturated-frontier.pkl')['factors']
for z in zeros:
    i=int(z['original_ordinal'])
    bound=dict(zip(L,original[i],strict=True))
    empty=[]
    for label,(scope,rows,den) in zip(sorted(schema),fs,strict=True):
        selected=tuple((j,bound[axis]) for j,axis in enumerate(scope) if axis in bound)
        if not any(all(row[j]==v for j,v in selected) for row in rows):empty.append(label)
    assert empty==literal_eval(z['empty_prepared_factors'])
    print('verified full original empty-factor restriction',i,','.join(empty),flush=True)
scale,occupation=physical_normalization()
assert scale==2**132 and occupation==48 and 2*2*occupation==int(geometry['weight'])==192
assert geometry['signed_geometric_phase']=='1'
Path('geometry.tsv').write_text('group\tcomponent\tclass\tgamma_partner\tphase\tphysical_divisor\tsource_weight\tchirality_factor\tgeometry_factor\tcover_coefficient\tfactor_denominator\n'
    +'\t'.join(map(str,(group,14,'K8,8',partner,1,scale,occupation,2,2,192,N)))+'\n')
print('verified exact independent source and zeros; all 128 component14 crossings; gamma3 counterpart and coefficient 192',flush=True)
