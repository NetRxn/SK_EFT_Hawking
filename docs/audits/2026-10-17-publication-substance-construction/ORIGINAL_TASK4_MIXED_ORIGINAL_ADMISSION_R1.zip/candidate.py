"""Original N16 two-center S2/S4 coefficient requests and bounded controls."""
from collections import Counter, defaultdict
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import random
import re
import sys

HERE = Path("/tmp")
spec = spec_from_file_location("two_center_r13", HERE / "publication-task4-continuation-quartic-r13.py")
base = module_from_spec(spec)
sys.modules[spec.name] = base
spec.loader.exec_module(base)
r10, r5, r6, r7, r4 = base.r10, base.r5, base.r6, base.r7, base.r10.r4
E, P, Q, S = r10.E, r10.P, r10.Q, r10.S
ONE, ZERO = Q(1), Q(0)
PREFIX = 720
SLOTS = r10.SLOTS
G1, G2 = r10.G1, r10.G2

def merge(table, key, value, paths):
    old = table.get(key)
    if old is None:
        table[key] = value, paths
    else:
        table[key] = old[0] + value, old[1] + paths

def setup(work):
    reg, (x,y,w), inputs, raw_w, d0, d1 = r10.setup(work)
    z = reg.step(w, 0)[0]
    assert z == reg.step(y, 2)[0]
    cz, raw_z, choices_z, _ = r10.r9.source_roster(reg, z, work)
    return reg, (x,y,w,z), inputs, (cz, choices_z), (raw_w, raw_z), d0, d1

def group_rows(target, coframes, traces, work, admission, used):
    yield from base.group_factors(target, coframes, traces, work, admission, used)

def local_table(target, coframes, choices, work, admission, reserved, degree):
    table = {}
    count = 0
    for key, factors, projected in center_groups(
            target, coframes, choices, work, admission,
            lambda: reserved + count + len(table), degree):
        for mask, symbols, _, value in r10.stream_rows(factors, target, work):
            work.charge("multicenter_local_group_updates")
            state, label = (mask, symbols), key
            labels = table.get(state)
            if labels is None or label not in labels:
                admission.check(reserved + projected + count + len(table)
                                + 1 + int(labels is None))
                count += 1
                if labels is None:
                    labels = table[state] = {}
            merge(labels, label, value, 1)
        del factors
    return table, count + len(table)

def complementary_join(left, right, mask, key, work):
    """Yield complete joined source labels, exact coefficient and path count."""
    for (lm, lk), llabels in left.items():
        work.charge("multicenter_complement_tests")
        if lm & mask != lm:
            continue
        rk = r5.subtract(key, lk)
        if rk is None:
            continue
        rm = mask ^ lm
        labels = right.get((rm, rk))
        if labels is None:
            continue
        sign = r5.mask_sign(lm, rm)
        for llabel, (lv, ln) in llabels.items():
            for rlabel, (rv, rn) in labels.items():
                work.charge("multicenter_complement_updates")
                yield llabel, rlabel, lv * rv * sign, ln * rn

def production(target, inputs, z_inputs, work, capacity, degrees, *, selected=None, carry=0, outer_labels=None):
    mask, symbols, slot = target
    validate_grades(target, degrees)
    cx, hx, cw, ww, contacts, cy, hy = inputs
    cap = base.Admission(r10.LOCAL_CAP)
    left, left_size = local_table(target, cw, ww, work, cap, carry, degrees[0])
    right, right_size = local_table(target, *z_inputs, work, cap, carry + left_size, degrees[1])
    fixed = carry + left_size + right_size
    contact = base.projection(contacts[slot], target, work, cap, fixed)
    fixed += len(contact)
    if outer_labels is not None:
        x_label, y_label = outer_labels
        hx, hy = {x_label: hx[x_label]}, {y_label: hy[y_label]}
    later = defaultdict(list)
    paths = 0
    for ykey, factors, live in group_rows(target, cy, hy, work, cap, lambda: fixed + 2*paths):
        for ym, yk, _, yv in r10.stream_rows(factors, target, work):
            work.charge("multicenter_later_paths")
            if paths + 1 > r10.LATER_CAP:
                raise RuntimeError(f"multicenter later path cap at prospective {paths+1}")
            cap.check(fixed + live + 2*(paths + 1))
            later[ym,yk].append((ykey,yv))
            paths += 1
        del factors
    output = r10.SignedOutput(capacity)
    seeded_value, seeded_paths = ZERO, 0
    residual_degree, residual_symbol_degree = local_grades(degrees)
    for xkey, factors, live in group_rows(
            target, cx, hx, work, cap, lambda: fixed + 2*paths + len(output.table)):
        for xm, _, remaining, xv in r10.stream_rows((*factors,contact), target, work):
            for (ym,yk), ylabels in later.items():
                work.charge("multicenter_outer_complement_tests")
                if xm & ym:
                    continue
                local_mask = mask ^ (xm | ym)
                if local_mask.bit_count() != residual_degree:
                    continue
                local_key = r5.subtract(remaining, yk)
                if local_key is None or len(local_key) != residual_symbol_degree:
                    continue
                sign = r5.mask_sign(xm, local_mask) * r5.mask_sign(xm|local_mask,ym)
                for wkey,zkey,local,n in complementary_join(left,right,local_mask,local_key,work):
                    for ykey, yv in ylabels:
                        work.charge("multicenter_final_signed_updates")
                        key = (xkey,(),ykey)
                        cap.check(fixed + 2*paths + live + len(output.table) + int(key not in output.table))
                        coeff = xv * local * yv * sign
                        output.put(key, coeff, n)
                        if (xkey,wkey,zkey,ykey) == selected:
                            seeded_value += coeff
                            seeded_paths += n
        del factors
    return output, cap.peak, paths, seeded_value, seeded_paths

def independent_sign(left, right):
    parity = 0
    while left:
        bit = left & -left
        parity ^= (right & (bit-1)).bit_count() & 1
        left ^= bit
    return -1 if parity else 1

def oracle(target, inputs, z_inputs, raws, outer_raws, work, capacity, carry, degrees):
    """Rebuild actual raw local orientations and canonical outer products."""
    mask, symbols, slot = target
    cx, _, _, _, contacts, cy, _ = inputs
    cap = base.Admission(r10.LOCAL_CAP)
    cap.check(carry)
    left = raw_center(target, inputs[2], raws[0], work, cap, carry, degrees[0])
    right = raw_center(target, z_inputs[0], raws[1], work, cap, carry + len(left), degrees[1])
    reserve = carry + len(left) + len(right)
    residual_degree, residual_symbol_degree = local_grades(degrees)
    target_counts = Counter(symbols)
    def restrict(poly, fixed):
        n = r5.count(poly)
        cap.check(fixed + n)
        return r5.subset_factor(poly, mask, target_counts, work)
    d = restrict(contacts[slot], reserve)
    reserve += r5.count(d)
    # Partition eager products into one exact canonical left row.
    # Each step reserves the distinct input/output and projection scratch.
    def product_at(a,b,fixed):
        out = E()
        ac,bc = r5.count(a),r5.count(b)
        for am,p in a.terms:
            for ak,av in p.terms:
                live = fixed + ac + bc + r5.count(out)
                prospective = live + 1 + 2*bc
                if prospective > work.oracle_record_cap:
                    raise RuntimeError(f"multicenter oracle cap at prospective {prospective}")
                work.oracle_max_prospective_records = max(work.oracle_max_prospective_records,prospective)
                cap.check(prospective)
                work.charge("multicenter_oracle_pairs",bc)
                part = E(((am,P(((ak,av),))),)) * b
                projected = r5.subset_factor(part,mask,target_counts,work)
                updated = r5.count(projected)
                accumulated = live + r5.count(part) + r5.count(out) + 2*updated
                if accumulated > work.oracle_record_cap:
                    raise RuntimeError(f"multicenter oracle sum cap at prospective {accumulated}")
                work.oracle_max_prospective_records = max(work.oracle_max_prospective_records,accumulated)
                cap.check(accumulated)
                work.charge("multicenter_oracle_canonical_sums",updated)
                out += projected
                del part, projected
        return out
    def outer(coframes, raw, used, with_contact):
        enumerated = 0
        for key, terms in raw.items():
            if key[0] != 2:
                continue
            vertex = E()
            for term in terms:
                enumerated += 1
                work.charge("mixed_power_raw_outer_orientations")
                fixed = used() + r5.count(vertex)
                (_,mu,a), (_,nu,b) = term.components
                p = restrict(coframes[mu,a],fixed)
                q = restrict(coframes[nu,b],fixed + r5.count(p))
                if p == E() or q == E():
                    del p,q
                    continue
                trace_count = len(term.coefficient.terms)
                live = fixed + r5.count(p) + r5.count(q)
                check_oracle(work, live + 2 * trace_count)
                cap.check(live + trace_count)
                h = restrict(E(((0,term.coefficient * P.variable(G2)),)),
                             live)
                if h == E():
                    del p,q,h
                    continue
                pair = product_at(p,q,fixed + r5.count(h))
                del p,q
                piece = product_at(pair,h,fixed)
                del pair,h
                piece_count = r5.count(piece)
                cap.check(fixed + 2*piece_count)
                check_oracle(work, fixed + 2*piece_count)
                work.charge("mixed_power_raw_outer_sums", piece_count)
                vertex += piece
                del piece
            fixed = used()
            if with_contact and vertex != E():
                vertex = product_at(vertex,d,fixed-r5.count(d))
            if vertex != E():
                yield key[1:],vertex
            del vertex
        assert enumerated == 384
    later = {}
    later_size = 0
    for key, poly in outer(cy,outer_raws[1],lambda:reserve+2*later_size,False):
        count = r5.count(poly)
        if later_size+count > r10.LATER_CAP:
            raise RuntimeError(f"multicenter oracle later cap at prospective {later_size+count}")
        cap.check(reserve+2*(later_size+count))
        later[key] = poly
        later_size += count
        del poly
    out = r10.SignedOutput(capacity)
    for xkey, early in outer(cx,outer_raws[0],lambda:reserve+2*later_size+len(out.table),True):
        for ykey, late in later.items():
            for (em,ek,_),ev in r4.rows(early):
                for (ym,yk,_),yv in r4.rows(late):
                    work.charge("multicenter_oracle_outer_pairs")
                    if em & ym:
                        continue
                    outer_counts = Counter(ek+yk)
                    if outer_counts - target_counts:
                        continue
                    sub = target_counts - outer_counts
                    if sum(sub.values()) != residual_symbol_degree:
                        continue
                    required = mask ^ (em|ym)
                    if required.bit_count() != residual_degree:
                        continue
                    for (lm,lk),(lv,_) in left.items():
                        work.charge("multicenter_oracle_raw_joins")
                        if lm & required != lm or not lv:
                            continue
                        lc = Counter(lk)
                        if lc - sub:
                            continue
                        rk = tuple(sorted((sub-lc).elements()))
                        rm = required ^ lm
                        rv,_ = right.get((rm,rk),(ZERO,0))
                        if rv:
                            key = (xkey,(),ykey)
                            cap.check(reserve+2*later_size+r5.count(early)+len(out.table)+int(key not in out.table))
                            work.charge("multicenter_oracle_signed_updates")
                            sign = (independent_sign(em,lm) * independent_sign(em|lm,rm)
                                    * independent_sign(em|lm|rm,ym))
                            out.put(key,ev*lv*rv*yv*sign)
        del early
    return out, cap.peak

def raw_center(target, coframes, raw, work, admission, fixed, degree):
    """Use every original oriented or permuted source term in source order."""
    mask, symbols, _ = target
    counts = Counter(symbols)
    def restrict(poly):
        return r5.subset_factor(poly, mask, counts, work)
    w = {}
    projections = 0
    for key, poly in coframes.items():
        admission.check(fixed + projections + r5.count(poly))
        projected = restrict(poly)
        projections += r5.count(projected)
        w[key] = projected
    rows = {}
    input_ids = {id(poly) for poly in w.values()}
    def reserve_oracle(prospective):
        if prospective > work.oracle_record_cap:
            raise RuntimeError(f"quartic oracle cap: prospective {prospective}, cap {work.oracle_record_cap}")
        work.oracle_max_prospective_records = max(work.oracle_max_prospective_records, prospective)
    def multiply(a, b):
        # Both limits apply to these live rows. The oracle limit also
        # includes bounded temporary canonical output and its projection.
        left, right = r5.count(a), r5.count(b)
        separate = {id(poly): poly for poly in (a, b) if id(poly) not in input_ids}
        retained = fixed + projections + len(rows) + sum(map(r5.count, separate.values()))
        pairs = left * right
        prospective = retained + 2 * pairs
        reserve_oracle(prospective)
        admission.check(retained + 2 * pairs)
        work.charge("oracle_pair_admission", pairs)
        return restrict(a * b)
    enumerated = 0
    coupling = G2 if degree == 2 else G1
    for raw_key, terms in raw.items():
        if raw_key[0] != degree:
            continue
        for term in terms:
            work.charge("quartic_raw_orientations")
            enumerated += 1
            components = tuple(w[mu, a] for _, mu, a in term.components)
            if not all(components):
                continue
            partial = components[0]
            for factor in components[1:]:
                partial = multiply(partial, factor)
            trace_rows = len(term.coefficient.terms)
            retained = fixed + projections + len(rows) + r5.count(partial)
            reserve_oracle(retained + 2 * trace_rows)
            admission.check(retained + 2 * trace_rows)
            raw_trace = E(((0, term.coefficient * P.variable(coupling)),))
            trace = restrict(raw_trace)
            del raw_trace
            intermediate = r5.count(partial) + r5.count(trace)
            admission.check(fixed + projections + len(rows) + intermediate)
            product = multiply(partial, trace)
            intermediate += r5.count(product)
            for vm, polys in product.terms:
                for vk, vv in polys.terms:
                    work.charge("quartic_raw_signed_updates")
                    base.add_term(rows, (vm, vk), vv, 1, admission,
                             fixed + projections + intermediate)
            del product, partial, trace
    assert enumerated == {2: 384, 4: 24}[degree]
    return rows


def check_oracle(work, prospective):
    if prospective > work.oracle_record_cap:
        raise RuntimeError(f"mixed power oracle cap: prospective {prospective}")
    work.oracle_max_prospective_records = max(work.oracle_max_prospective_records, prospective)


def local_grades(degrees):
    assert degrees in ((2, 4), (4, 2), (2, 2))
    return sum(2 * degree for degree in degrees), sum(7 if d == 2 else 5 for d in degrees)


def validate_grades(target, degrees):
    mask, symbols, slot = target
    exterior, symbols_degree = local_grades(degrees)
    assert mask.bit_count() == 10 + exterior
    assert len(symbols) == 16 + symbols_degree
    assert sum(s.family == "q" for s in symbols) == 13 + symbols_degree - 2
    assert symbols.count(G2) == 2 + degrees.count(2)
    assert symbols.count(G1) == degrees.count(4)
    assert sum(s.family == "J" for s in symbols) == 1
    assert slot in SLOTS


def center_groups(target, coframes, choices, work, admission, used, degree):
    projected = {}
    live = 0
    for key, poly in coframes.items():
        rows = base.projection(poly, target, work, admission, used() + live)
        projected[key] = rows
        live += len(rows)
    for key, (components, trace) in choices.items():
        work.charge("mixed_power_production_branches")
        if key[0] != degree:
            continue
        factors = tuple(projected[component] for component in components)
        if not all(factors):
            continue
        rows = base.projection(trace, target, work, admission, used() + live)
        if rows:
            yield key, (*factors, rows), live + len(rows)
        del rows


def selected_witness(target, inputs, z_inputs, selected, work, carry=0):
    """Complete labelled branch coefficient, independently of the full tables."""
    cx,hx,cw,ww,contacts,cy,hy = inputs
    cz,wz = z_inputs
    xk,wk,zk,yk = selected
    slot = target[2]
    cap = base.Admission(r10.LOCAL_CAP)
    live = carry
    def retain(poly):
        nonlocal live
        projected = base.projection(poly,target,work,cap,live)
        live += len(projected)
        return projected
    def outer(coframes,traces,label):
        _,_,mu,nu,a,b = label
        return retain(coframes[mu,a]),retain(coframes[nu,b]),retain(traces[label])
    def inner(coframes,choices,label):
        components,trace = choices[label]
        return (*(retain(coframes[c]) for c in components),retain(trace))
    x,w,z,y = outer(cx,hx,xk),inner(cw,ww,wk),inner(cz,wz,zk),outer(cy,hy,yk)
    d = retain(contacts[slot])
    later = {}
    ypaths = 0
    for ym,yk,_,yv in r10.stream_rows(y,target,work):
        work.charge("multicenter_witness_later_updates")
        ypaths += 1
        if ypaths > r10.LATER_CAP:
            raise RuntimeError(f"multicenter witness later path cap at {ypaths}")
        cap.check(live+len(later)+int((ym,yk) not in later))
        merge(later,(ym,yk),yv,1)
    value,paths = ZERO,0
    for pm,_,remaining,pv in r10.stream_rows((*x,*w,*z,d),target,work):
        ym = target[0] ^ pm
        if (ym,remaining) in later:
            work.charge("multicenter_witness_final_updates")
            yv,n = later[ym,remaining]
            value += pv*yv*r5.mask_sign(pm,ym)
            paths += n
    return value,paths,cap.peak


def source_factors(inputs, z_inputs, labels, d):
    cx,hx,cw,ww,_,cy,hy = inputs
    cz,wz = z_inputs
    xk,wk,zk,yk = labels
    def local(coframes, choices, label):
        components, trace = choices[label]
        return (*(coframes[component] for component in components), trace)
    def outer(coframes, traces, label):
        _,_,mu,nu,a,b = label
        return coframes[mu,a],coframes[nu,b],traces[label]
    return (*outer(cx,hx,xk), *local(cw,ww,wk), *local(cz,wz,zk),
            d, *outer(cy,hy,yk))


def seed_candidates(inputs, z_inputs, degrees, slot, d, rng, seen, work, w, z, frames):
    _,hx,_,ww,_,_,hy = inputs
    _,wz = z_inputs
    wk_options = tuple(key for key in ww if key[0] == degrees[0])
    zk_options = tuple(key for key in wz if key[0] == degrees[1])
    xx, yy = tuple(hx), tuple(hy)
    for attempt in range(1,2049):
        work.charge("mixed_power_seed_attempts")
        wk, zk = rng.choice(wk_options), rng.choice(zk_options)
        if slot == SLOTS[0] and any(0 not in k[3:5] for k in (wk,zk) if k[0] == 2):
            continue
        if slot == SLOTS[1]:
            xk, yk = rng.choice(frames)
        else:
            xk, yk = rng.choice(xx), rng.choice(yy)
        labels = (xk, wk, zk, yk)
        mask, symbols, lineage = 0, [], []
        for poly in source_factors(inputs,z_inputs,labels,d):
            view = base.IndexedRows(poly,work)
            for _ in range(16):
                work.charge("mixed_power_seed_draws")
                (m,k,_), value = rng.choice(view)
                if not m & mask:
                    mask |= m
                    symbols.extend(k)
                    lineage.append((m,k,value))
                    break
            else:
                del view
                break
            del view
        else:
            w_slice = lineage[3:4+degrees[0]]
            z_slice = lineage[4+degrees[0]:5+sum(degrees)]
            shared = {s for _,part,_ in w_slice for s in part} & {
                s for _,part,_ in z_slice for s in part
            }
            reciprocal = tuple(sorted(s for s in shared if s.family == "q"
                                      and s.index[0] in (w,z) and s.index[1] == 0))
            if slot == SLOTS[0] and not reciprocal:
                continue
            target = (mask, tuple(sorted(symbols)), slot)
            if target in seen:
                continue
            seen.add(target)
            yield target, labels, attempt, reciprocal, lineage
    raise RuntimeError(f"mixed power structural seed cap {degrees} {slot} at attempt 2048")


def reflect(label):
    return (*label[:4], label[4] ^ 1, label[5] ^ 1)


def frame_controls(target, labels, inputs, z_inputs, degrees, work, carry):
    xk,_,_,yk = labels
    cases = ((xk,yk), (reflect(xk),yk), (xk,reflect(yk)), (reflect(xk),reflect(yk)))
    values = []
    paths = []
    peak = 0
    for xl,yl in cases:
        if xl not in inputs[1] or yl not in inputs[-1]:
            values.append(ZERO)
            paths.append(0)
            continue
        out, p, _, _, _ = production(target, inputs, z_inputs, work, 1, degrees,
                                     carry=carry + len(values), outer_labels=(xl,yl))
        coeff, count = out.table.get((xl,(),yl),(ZERO,0))
        values.append(coeff)
        paths.append(count)
        peak = max(peak,p)
        del out
    return values, paths, peak


def find_requests(inputs,z_inputs,d0,d1,w,z,work,log):
    rng = random.Random(20261107)
    parent_row = json.loads((Path("/tmp/publication-l1-asymmetric-candidate-r1.sL0Nfh")
                             / "original.jsonl").read_text().splitlines()[1])
    seed_frames = tuple((tuple(key[0]),tuple(key[2]))
                   for key,value,_ in parent_row["table"] if value != str(ZERO))
    assert len(seed_frames) == 6
    for degrees in ((2,4),(4,2)):
        seen = set()
        for slot,direction,d in ((SLOTS[0],0,d0),(SLOTS[1],0,d0),(SLOTS[1],1,d1)):
            candidates = seed_candidates(inputs,z_inputs,degrees,slot,d,rng,seen,work,w,z,seed_frames)
            for qualified in range(1,13):
                try:
                    target,labels,attempt,shared,lineage = next(candidates)
                except RuntimeError as failure:
                    print(json.dumps(dict(degrees=degrees,slot=slot,direction=direction,
                                          qualified=qualified-1,work=work.used,error=str(failure))),
                          file=log,flush=True)
                    break
                validate_grades(target,degrees)
                carry = 1024 + 35 * len(seen)
                value,paths,peak = selected_witness(target,inputs,z_inputs,labels,work,carry)
                frames, frame_paths, frame_peak = [], [], 0
                if value:
                    frames, frame_paths, frame_peak = frame_controls(
                        target,labels,inputs,z_inputs,degrees,work,carry
                    )
                # A nonzero base and unequal exact pair sums on each one-frame
                # reflection, plus a nonzero four-frame orbit total, distinguish
                # this target from the measured pairwise S2/S2 cancellations.
                asymmetric = (bool(frames and frames[0]) and
                              bool(frames[0] + frames[1]) and
                              bool(frames[0] + frames[2]) and
                              bool(sum(frames,ZERO)))
                work.charge("mixed_power_seed_receipt_rows", len(lineage))
                base.Admission(r10.LOCAL_CAP).check(carry + 2*len(lineage))
                receipt = dict(degrees=degrees,target=r5.fingerprint(target),direction=direction,
                               branch=labels,attempt=attempt,qualified=qualified,
                               repeated=r5.fingerprint((0,shared,()))["symbols"],
                               path=[(hex(m),[(s.family,s.index) for s in k],str(v)) for m,k,v in lineage],
                               witness=str(value),paths=paths,local_peak=max(peak,frame_peak),
                               frame_coefficients=list(map(str,frames)),frame_paths=frame_paths,
                               work=work.used,asymmetric=asymmetric,reserved_path_records=carry)
                if value and frames[0] and (slot == SLOTS[0] or asymmetric):
                    candidates.close()
                    yield receipt
                    break
                print(json.dumps(receipt),file=log,flush=True)
                del receipt
            else:
                print(json.dumps(dict(degrees=degrees,slot=slot,direction=direction,
                                      qualified=12,work=work.used,error="mixed power qualified cap")),
                      file=log,flush=True)


if __name__ == "__main__" and not __debug__:
    raise SystemExit("Assertions must be enabled")
if __name__ == "__main__" and sys.argv[1:] == ["--bounded-discovery"]:
    work = r5.Work(cap=r10.WORK_CAP, oracle_record_cap=r10.PAIR_CAP)
    _, (_,_,w,z), inputs, z_inputs, raws, d0,d1 = setup(work)
    with (Path(__file__).parent / "discovery.rejected.jsonl").open("x") as rejected:
        for row in find_requests(inputs,z_inputs,d0,d1,w,z,work,rejected):
            print(json.dumps(row),flush=True)

PACKET = Path(__file__).resolve().parent
ACCEPTED = Path("/tmp/publication-l1-asymmetric-candidate-r1.sL0Nfh")
REQUEST_KEYS = (
    ((2,4),SLOTS[0],0), ((2,4),SLOTS[1],0), ((2,4),SLOTS[1],1),
    ((4,2),SLOTS[0],0), ((4,2),SLOTS[1],0), ((4,2),SLOTS[1],1),
)
TARGET_BYTES = 20178
TARGET_DIGEST = "84ca076d2ec7cb78975c921dfcbc25a98b6b7c469e6fe9e4083c66897f2bfdd0"

def accepted_parent():
    path = ACCEPTED / "candidate.py"
    assert sha256(path.read_bytes()).hexdigest() == (
        "f7fbe6ed0679b3a8dec0062842f5806d7a55fda71aa0ef560524deac021cb451"
    )
    spec = spec_from_file_location("accepted_asymmetric_s2s2", path)
    parent = module_from_spec(spec)
    sys.modules[spec.name] = parent
    spec.loader.exec_module(parent)
    return parent


def baseline_controls(parent, inputs, z_inputs, d0, d1, w, z, work):
    from io import BytesIO
    path = ACCEPTED / "original.jsonl"
    raw = path.read_bytes()
    assert sha256(raw).hexdigest() == (
        "dd47b8e1e27a57288c7945e6255a23ee87ba5171751c38ff09f1cb148695a196"
    )
    assert parent.r2.output_prefix() == 696
    identity = parent.r2.identity_controls(inputs, z_inputs, work)
    count = 0
    checked = 0
    with BytesIO(raw) as terminal:
        header = parent.r2.decode_frozen(next(terminal).decode(),work,base.Admission(r10.LOCAL_CAP))
        assert header["identity_controls"] == identity
        for line, expected in zip(parent.target_lines(work),parent.EXPECTED,strict=True):
            target,labels,witness,paths,receipt = parent.checked_request(
                line,expected,inputs,z_inputs,d0,d1,w,z,work
            )
            row = parent.r2.decode_frozen(next(terminal).decode(),work,base.Admission(r10.LOCAL_CAP))
            assert row["target"] == receipt["target"] and row["branch"] == receipt["branch"]
            assert row["witness"] == str(witness) and row["paths"] == paths
            assert len(row["table"]) == row["output_records"]
            count += row["output_records"]
            checked += 1
            del row, target, labels, witness, paths, receipt
        terminal_row = parent.r2.decode_frozen(next(terminal).decode(),work,base.Admission(r10.LOCAL_CAP))
        assert not terminal.readline()
    assert terminal_row["prefix_output_records"] == 696
    assert 696 + count == terminal_row["cumulative_output_records"] == PREFIX
    assert checked == 3
    return dict(identity=identity,s2s2_witnesses=checked,s2s2_signed_groups=count)


def checked_request(line, expected, parent, inputs, z_inputs, d0, d1, w, z, work):
    cap = base.Admission(r10.LOCAL_CAP)
    carry = 3*(line.count(b"[") + line.count(b"{")) + 96
    cap.check(carry)
    work.charge("mixed_power_request_decode", len(line))
    row = json.loads(line)
    target = r6.decoded(row["target"])
    degrees,slot,direction = expected
    assert (tuple(row["degrees"]),target[2],row["direction"]) == expected
    assert 1 <= row["attempt"] <= 2048 and 1 <= row["qualified"] <= 12
    validate_grades(target,degrees)
    labels = tuple(map(tuple,row["branch"]))
    assert tuple(label[0] for label in labels[1:3]) == degrees
    path = tuple(map(parent.decode_operand,row["path"]))
    assert len(path) == 15 and parent.support(path) == target[:2]
    factors = source_factors(inputs,z_inputs,labels,d0 if direction == 0 else d1)
    for (mask,key,coefficient), factor in zip(path,factors,strict=True):
        for (m,k,slot_key), c in r4.rows(factor):
            work.charge("mixed_power_witness_source_rows")
            if (mask,key,(),coefficient) == (m,k,slot_key,c):
                break
        else:
            raise RuntimeError("preregistered operand absent from exact original factor")
    w_slice, z_slice = path[3:4+degrees[0]], path[4+degrees[0]:5+sum(degrees)]
    common = {s for _,key,_ in w_slice for s in key} & {s for _,key,_ in z_slice for s in key}
    shared = sorted(s for s in common if s.family == "q" and s.index[0] in (w,z) and s.index[1] == 0)
    assert row["repeated"] == json.loads(json.dumps(r5.fingerprint((0,shared,()))["symbols"]))
    assert slot != SLOTS[0] or shared
    value,paths,witness_peak = selected_witness(target,inputs,z_inputs,labels,work,carry)
    frames,frame_paths,frame_peak = frame_controls(target,labels,inputs,z_inputs,degrees,work,carry)
    assert value and paths and frames[0]
    assert (str(value),paths) == (row["witness"],row["paths"])
    assert list(map(str,frames)) == row["frame_coefficients"] and frame_paths == row["frame_paths"]
    if slot == SLOTS[1]:
        assert frames[0]+frames[1] and frames[0]+frames[2] and sum(frames,ZERO)
    row.update(reserved_path_records=carry,witness_peak=max(cap.peak,witness_peak,frame_peak))
    return target,labels,value,paths,row


def evaluate(target, labels, value, paths, receipt, inputs, z_inputs, raws, outer_raws, work, capacity, parent):
    carry = receipt["reserved_path_records"]
    degrees = tuple(receipt["degrees"])
    out,peak,later,selected,selected_paths = production(
        target,inputs,z_inputs,work,capacity,degrees,selected=labels,carry=carry
    )
    assert (selected,selected_paths) == (value,paths)
    reference, oracle_peak = oracle(
        target,inputs,z_inputs,raws,outer_raws,work,capacity,carry+len(out.table),degrees
    )
    total = parent.compare_groups(out.table,reference.table,work)
    del reference
    xk,_,_,yk = labels
    frames = ((xk,yk),(reflect(xk),yk),(xk,reflect(yk)),(reflect(xk),reflect(yk)))
    compare = [out.table.get((xl,(),yl),(ZERO,0)) for xl,yl in frames]
    assert [str(v) for v,_ in compare] == receipt["frame_coefficients"]
    assert [n for _,n in compare] == receipt["frame_paths"]
    conversion = carry + 3*len(out.table)
    base.Admission(r10.LOCAL_CAP).check(conversion)
    work.charge("mixed_power_signed_receipt_rows",len(out.table))
    receipt.update(total=str(total),local_peak=max(peak,oracle_peak,receipt["witness_peak"],conversion),
                   later_paths=later,output_records=len(out.table),
                   table=[(key,str(v),n) for key,(v,n) in sorted(out.table.items())])
    return bool(total)


def run(original, out):
    if original and len(REQUEST_KEYS) != 6:
        raise RuntimeError("full original batch refused: two reverse mixed requests unqualified")
    work = r5.Work(cap=r10.WORK_CAP,oracle_record_cap=r10.PAIR_CAP)
    parent = accepted_parent()
    reg,(x,y,w,z),inputs,z_inputs,raws,d0,d1 = setup(work)
    baseline = baseline_controls(parent,inputs,z_inputs,d0,d1,w,z,work)
    print(json.dumps(dict(baseline=baseline,work=work.used)),file=out,flush=True)
    if original:
        outer_raws = tuple(r10.r9.source_roster(reg,site,work)[1] for site in (x,y))
    used = PREFIX
    nonzero = 0
    with (PACKET/"targets.jsonl").open("rb") as source:
        ledger = source.read(TARGET_BYTES+1)
    work.charge("mixed_power_ledger_input_bytes",len(ledger))
    assert len(ledger) == TARGET_BYTES and sha256(ledger).hexdigest() == TARGET_DIGEST
    from io import BytesIO
    for line, expected in zip(BytesIO(ledger), REQUEST_KEYS, strict=True):
        try:
            target,labels,value,paths,receipt = checked_request(
                line,expected,parent,inputs,z_inputs,d0,d1,w,z,work
            )
            if original:
                nonzero += evaluate(target,labels,value,paths,receipt,inputs,z_inputs,raws,outer_raws,
                                    work,r10.OUTPUT_CAP-used,parent)
                used += receipt["output_records"]
        except RuntimeError as failure:
            print(json.dumps(dict(refused=expected,error=str(failure),work=work.used)),
                  file=out,flush=True)
            raise
        print(json.dumps(receipt),file=out,flush=True)
        del target,labels,value,paths,receipt
    print(json.dumps(dict(mode="original" if original else "bounded_controls",work=dict(work.counts),
                          work_total=work.used,oracle_peak=work.oracle_max_prospective_records,
                          prefix_output_records=PREFIX,cumulative_output_records=used,
                          complete_nonzero=nonzero if original else None)),file=out,flush=True)


if __name__ == "__main__":
    if sys.argv[1:] == ["--bounded-controls"]:
        run(False, sys.stdout)
    elif sys.argv[1:] == ["--root-admitted-original"]:
        if len(REQUEST_KEYS) != 6:
            raise SystemExit("full original batch refused: two reverse mixed requests unqualified")
        with (PACKET/"original.jsonl").open("x") as stream:
            run(True,stream)
    elif sys.argv[1:] != ["--bounded-discovery"]:
        raise SystemExit("Use a bounded mode or separately authorized original mode")
