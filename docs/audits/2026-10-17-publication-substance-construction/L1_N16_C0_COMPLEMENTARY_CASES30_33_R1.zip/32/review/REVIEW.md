# Complementary tuple 0 outer case 32 independent exact review

The nine separate exact terminal replays sum to **-311265394132600099496295 / 5192296858534827628530496329220096 + 0i**. This is outer case 32 of the selector-1 child of tuple 0 in dense group 128 descendant (0, 0). It matches the same coordinate's accepted selector-0 scalar and derives from its own distinct parent and exact inputs.

At publication checkpoint 2857ccc12539261a46532e12dd1ae145472aed60, the original separator pins the eight-factor tuple0-1 parent to uncompressed SHA256 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d. Independent projected matching reproduces the full original 48-case roster and 6,427,904 pair matches. Case 32 is coordinate (17, (1,)), with 177,240 matches and 423,946 stored rows. An exact inverse lift recovers its restricted parent rows, axes, signed coefficients and denominators.

Both outer row caps are rebuilt from the pinned parent and produce the exact seven-factor inner restart with SHA256 3767c3233c3f5965dc249e98a2c6faccdd886f882fc7324d314d211c9a04226e. The independent inner census on G(0,1,2) gives all nine supported coordinates with 2,001,024 products total, minimum 44,928 and maximum 435,456. Each conditioned child's inverse lift exactly recovers its source factor slices. Clean execution of frozen author programs reproduces the cap/checkpoint bytes, reductions and terminal author receipts separately from the independent mathematical replays. All 19 cap snapshots verify, comprising 13 join refusals and six row refusals. The byte-for-byte lineage run took 230.65 seconds. The independent source census and inverse-lift audit took 19.12 seconds.

| Slice | Coordinate | Products in the inner census | Exact normalized real |
| --- | --- | --- | --- |
| 0 | 12 | 44928 | -7579449762635066717835/2596148429267413814265248164610048 |
| 1 | 192 | 62208 | -2639017884707118117/20282409603651670423947251286016 |
| 2 | 3 | 169344 | -56843999868716591259645/2596148429267413814265248164610048 |
| 3 | 5 | 169344 | -86042431804685377031955/5192296858534827628530496329220096 |
| 4 | 96 | 217728 | -1958914993772195309097/324518553658426726783156020576256 |
| 5 | 144 | 217728 | -1958914993772195309097/324518553658426726783156020576256 |
| 6 | 48 | 248832 | -111230041368208192983/649037107316853453566312041152512 |
| 7 | 80 | 435456 | -8031338588767617209115/2596148429267413814265248164610048 |
| 8 | 160 | 435456 | -8031338588767617209115/2596148429267413814265248164610048 |

All imaginary values are exactly zero. Slices 0, 1, 4, 5 and 6 use independent Gaussian-integer sparse joins. Slices 2 and 3 use alternate triangle pivot 1 in place of author pivot 0. Slices 7 and 8 use selected pair (1, 2) in place of author pair (1, 3), group exact products by the outgoing boundary, then compute the complementary closure. Each replay starts from its own frozen terminal input. The five plain sparse schedules use 636,048 to 6,391,680 Gaussian products. Each triangle uses 18,643,968 supported triples and 18,752,832 Gaussian products, with 17.47 and 18.55 seconds inside the replay. The four-factor replays each use 6,138,720 selected-pair matches, 15,536,640 complementary closure probes and 23,692,032 Gaussian products over 11 bounded shards. Their internal elapsed times are 21.95 and 19.73 seconds. timings.tsv preserves per-slice work, output peaks and both internal and process elapsed times.

Independent projection histograms validate all 32 sorted pivot intervals across the four author shard stacks. They reproduce the exact probe or pair-match count per interval, and each shard stack's exact raw and normalized sum agrees with the independent signed replay. The independent shard census took 2.34 seconds.

Every replay preserves the exact raw scalar and combines the factor-denominator product 40512224221827380280140849737629696 with the positive external scale 1/(16*4^64) once. The committed selector-0 ledger confirms the matching value after the selector-1 computation. The final comparison uses the independently contracted selector-1 scalar and verifies that the two original parents are distinct.

## Reproduction

Retain inputs/, scripts/ and replays/ as relative directories. The separator.zip and first-child.zip archives can be restored from the pinned Git objects. The generated lineage directory can be recreated from the frozen inputs. Run the checks in a fresh copy, with no generated lineage/ directory.

```sh
sh verify-source-pins.sh
shasum -a 256 -c frozen-inputs.sha256
shasum -a 256 -c source-archives.sha256
python3 audit.py > audit.out
python3 verify-lineage.py outer 0 1 2 3 4 5 6 7 8 > verify-lineage.out
python3 replay-all.py > replay-all.out
python3 verify-shards.py > verify-shards.out
python3 timings.py > timings.tsv
python3 verify-cap-list.py > cap-list.out
python3 aggregate.py > aggregate.out
python3 compare-first.py > compare-first.out
```
