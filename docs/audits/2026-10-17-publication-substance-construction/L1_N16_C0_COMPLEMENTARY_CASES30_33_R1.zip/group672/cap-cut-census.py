from collections import Counter, defaultdict
from pathlib import Path
import pickle

with Path('row-cap-physical-slice-dense-branch.pkl').open('rb') as stream:
    checkpoint = pickle.load(stream)
factors = checkpoint['factors']
i, j = checkpoint['rejected_pair']
axes_a, left, _ = factors[i]
axes_b, right, _ = factors[j]
shared = tuple(axis for axis in axes_a if axis in axes_b)
positions_a = tuple(axes_a.index(axis) for axis in shared)
positions_b = tuple(axes_b.index(axis) for axis in shared)
lhs = Counter(tuple(row[k] for k in positions_a) for row in left)
rhs = Counter(tuple(row[k] for k in positions_b) for row in right)
counts = {key: lhs[key] * rhs[key] for key in lhs.keys() & rhs.keys()}
assert sum(counts.values()) == checkpoint['matched']
degrees = Counter(axis for axes, _, _ in factors for axis in axes)
plans = []
for index, axis in enumerate(shared):
    if axis[0] == 'L' or degrees[axis] != 2:
        continue
    by_value = defaultdict(int)
    for key, count in counts.items():
        by_value[key[index]] += count
    if len(by_value) > 1:
        plans.append((max(by_value.values()), len(by_value), axis, sorted(by_value.items())))
print('unpartitioned', checkpoint['matched'], 'rejected pair', (i, j), 'factor sizes', len(left), len(right))
print('ranked physical cuts by maximum projected products')
for plan in sorted(plans)[:12]:
    print(repr(plan))
