# Dense group 672 benchmark intake

Group 672 is a valid second benchmark for the bounded preparation and initial contraction. It lies near the median of the 3,872 groups by loaded rows. Group 128 is tied for the lightest input. The group 672 cap receipt does not contain a complete normalized scalar.

The M01/M06 cut plan, axes and original numerical programs match the committed dense pause archive at bc39124d43aee12bc323030c5989e491118c02db. The roster has 3,872 unique cuts of eight supported assignments. Independently matching the pinned cut labels to the indexed compiled blocks yields the complete selected set for each of groups 128 and 672, with 252 blocks in 88 factors per group. All 88 compiled file hashes verify. Across both groups, 366 unique selected blocks were directly decoded to verify their labels, byte extents, exact row counts and denominators. Group 672 has 1,936 groups with fewer input rows, four with the same count including itself, and 1,932 with more. The overall input-row median is 2,730,558.

The original preparer correctly selects, loads and logs group 672 before the quotient loops. The loop reuses its group variable as a factor index, leaving 87 in the serialized branch field. The correction preserves the selected index in a dedicated variable. All corresponding factors match in order, axis order, ordered rows, Gaussian coefficient pairs and denominators. Replacing only 87 with 672 in the original loaded checkpoint and serializing again produces the corrected pickle byte for byte. The common total factor denominator is 576173855599322741762003196268511232. The contractor reads only factors and used_before from that checkpoint. Neither branch metadata nor support count can affect its arithmetic or stopping condition.

| Metric at the same stage | Group 128 | Group 672 |
| --- | ---: | ---: |
| Loaded factor rows | 1,792,198 | 2,731,846 |
| Encoded input bytes | 72,763,325 | 112,580,042 |
| Rows after the two preparation sweeps | 435,604 | 714,563 |
| Cumulative quotient sweep visits | 14,982,772 | 24,140,767 |
| Completed initial joins | 68 | 62 |
| Completed matched products | 5,022,652 | 3,028,312 |
| Factors at initial row cap | 20 | 26 |
| Next-join product forecast | 2,789,920 | 3,563,808 |

Group 672 stopped with exit 2 at the 500,000-row guard during its refused join. Its saved 26-factor checkpoint has 2,139,736 factor rows and rejected pair (4, 8). Independent shared-key histograms reproduce the 3,563,808 predicted products. The saved used_before field matches the sum of all 62 completed joins and excludes unfinished join work. A separately recorded group 672 sample has identical preparation and cap states and the same contraction receipt. Group 128's later 12-factor cap belongs to a separate continuation.

For planning, the near-median sample loaded 52.4% more rows, retained 64.0% more rows after preparation and took 61.1% more quotient sweep visits than the lightest benchmark. Its initial refused join was 27.7% larger while its completed product count before the stop was 39.7% smaller. Preparation workload and where contraction stalls can vary independently. The group 672 intake reports 45.24 seconds for the original preparation and 73.905 seconds to the contractor's initial cap. The corrected preparation took 41.663 seconds. The separate identical sample reports 34.81 and 60.32 seconds. These are local bounded measurements with different timing captures. Neither sample establishes time to finish group 672 or provides a profile-wide runtime multiplier.

The evidence is read-only with respect to the reviewed artifacts. Run python3 verify.py with the author intake directory as its argument from this directory, with pause.zip restored from its Git object. Run python3 verify-selected-blocks.py with the same argument for the direct compiled block checks. compiled-inputs.sha256 and group672-artifacts.sha256 use paths relative to the author intake directory. The review evidence has a separate relative manifest.
