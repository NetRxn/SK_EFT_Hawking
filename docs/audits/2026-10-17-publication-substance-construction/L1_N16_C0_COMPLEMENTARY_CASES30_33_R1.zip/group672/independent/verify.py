import ast
from ast import literal_eval
from collections import Counter, defaultdict
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
from re import M, findall, search
from statistics import median
from sys import argv
from zipfile import ZipFile

root=Path(argv[1])
archive_path=Path('pause.zip')
with ZipFile(archive_path) as archive:
    hashes={n.removeprefix('./'):h for h,n in map(str.split,archive.read('manifest.sha256').decode().splitlines())}

    def archived(name):
        data=archive.read(name)
        assert sha256(data).hexdigest()==hashes[name]
        return data

    for name in ('cut-plan.tsv','cut-axes.tsv','prepare-branch.py','contract-branch.py','quotient.py'):
        assert archived(name)==(root/name).read_bytes()
    assert archived('compiled-inputs.sha256')==Path('compiled-inputs.sha256').read_bytes()
    assert archived('selected-branch.tsv').strip()==b'128'
    prep128=archived('prepare-branch.out').decode()
    cont128=archived('contract-branch.out').decode()
    cont128_later=archived('contract-final.out').decode()

schema={}
for ln in (root/'schema.tsv').read_text().splitlines():
    name,labels,physical,n,r,d=ln.split('\t')
    assert name not in schema
    schema[name]=(literal_eval(labels),literal_eval(physical),int(n),int(r),int(d))
blocks=[]
block_sets=defaultdict(list)
for ln in (root/'block-index.tsv').read_text().splitlines():
    name,label,offset,size,rows,d=ln.split('\t')
    block=(name,literal_eval(label),int(offset),int(size),int(rows),int(d))
    blocks.append(block)
    block_sets[name].append(block)
assert len(block_sets)==len(schema)==88
for name,entries in block_sets.items():
    _,_,n,r,d=schema[name]
    assert len(entries)==n and sum(item[4] for item in entries)==r
    end=0
    for _,label,offset,size,rows,bden in entries:
        assert offset==end and len(label)==len(schema[name][0]) and min(size,rows,bden)>0
        end+=size
    assert end==(root/'compiled'/f'{name}.blocks').stat().st_size

axes=literal_eval((root/'cut-axes.tsv').read_text())
assert axes==tuple(sorted(set(schema['M01'][0])|set(schema['M06'][0])))
plans=[]
for ln in (root/'cut-plan.tsv').read_text().splitlines():
    i,n,rows,size,labels,ids=ln.split('\t')
    assert int(i)==len(plans)
    plans.append((int(n),int(rows),int(size),literal_eval(labels),literal_eval(ids)))
assert len(plans)==3872 and sum(x[0] for x in plans)==30976
assert len(set(p[3] for p in plans))==3872 and [p[3] for p in plans]==sorted(p[3] for p in plans)
assert all(p[0]==8 for p in plans)
row_counts=[p[1] for p in plans]
assert min(row_counts)==plans[128][1]
assert median(row_counts)==2730558
assert sum(c<plans[672][1] for c in row_counts)==1936

for i in (128,672):
    support,rows,size,labels,ids=plans[i]
    assert len(labels)==len(axes)==16
    fixed=dict(zip(axes,labels,strict=True))
    expected=tuple(j for j,(name,key,*_) in enumerate(blocks)
                   if all(w not in fixed or fixed[w]==v for w,v in zip(schema[name][0],key,strict=True)))
    assert ids==expected
    chosen=[blocks[j] for j in ids]
    assert len({item[0] for item in chosen})==88
    assert sum(block[4] for block in chosen)==rows and sum(block[3] for block in chosen)==size
    print('source group',i,'support',support,'rows',rows,'encoded bytes',size,'selected blocks',len(ids),
          'below/equal/above',sum(v<rows for v in row_counts),sum(v==rows for v in row_counts),sum(v>rows for v in row_counts),flush=True)
print('PASS pinned cut plan, full compatible block selections for 128/672, row-count median',median(row_counts),flush=True)

def digest(path):
    raw=path.read_bytes()
    return sha256(raw).hexdigest()

old_code=(root/'prepare-branch.py').read_text()
new_code=(root/'corrected/prepare-branch.py').read_text()
assert new_code == (old_code.replace('row_count,j,support','row_count,group_id,support')
                    .replace("print('branch',j,","print('branch',group_id,")
                    .replace("print('exact zero by empty factor',j)","print('exact zero by empty factor',group_id)")
                    .replace("'branch':j,","'branch':group_id,"))
assert (root/'preparation.out').read_bytes()==(root/'corrected/preparation.out').read_bytes()
for name in ('cut-plan.tsv','cut-axes.tsv','schema.tsv','block-index.tsv','quotient.py'):
    assert (root/name).read_bytes()==(root/'corrected'/name).read_bytes()
prog=ast.parse((root/'contract-branch.py').read_text())
obj_loads=[node for node in ast.walk(prog) if isinstance(node,ast.Name) and node.id=='obj' and isinstance(node.ctx,ast.Load)]
obj_keys=[node.slice.value for node in ast.walk(prog) if isinstance(node,ast.Subscript) and isinstance(node.value,ast.Name) and node.value.id=='obj']
assert len(obj_loads)==len(obj_keys)==2 and set(obj_keys)=={'factors','used_before'}
print('PASS preparer fix changes only group identifier binding and diagnostic/serialization uses; contractor reads',obj_keys,flush=True)

old_path=root/'dense-saturated-frontier.pkl'
new_path=root/'corrected/dense-saturated-frontier.pkl'
old_raw=old_path.read_bytes()
new_raw=new_path.read_bytes()
old,new=pickle.loads(old_raw),pickle.loads(new_raw)
assert set(old)==set(new)=={'factors','used_before','branch','support'}
assert (old['branch'],new['branch'])==(87,672)
assert old['support']==new['support']==8 and old['used_before']==new['used_before']==0
assert len(old['factors'])==len(new['factors'])==88
for a,b in zip(old['factors'],new['factors'],strict=True):
    assert a[0]==b[0] and a[2]==b[2] and len(a[1])==len(b[1])
    assert all(x==y for x,y in zip(a[1].items(),b[1].items(),strict=True))
old['branch']=672
assert pickle.dumps(old,protocol=5)==new_raw
assert sha256(old_raw).hexdigest()==(root/'frontier.sha256').read_text().split()[0]
den=prod(d for _,_,d in new['factors'])
assert den==576173855599322741762003196268511232
assert sum(len(r) for _,r,_ in new['factors'])==714563
print('PASS byte-exact corrected pickle after replacing branch 87 with 672',
      sha256(old_raw).hexdigest(),sha256(new_raw).hexdigest(),'denominator',den,flush=True)
del old,new,old_raw,new_raw

def metrics(text):
    joins=[tuple(map(int,j)) for j in findall(r'^join (\d+) (\d+) (\d+) axes (\d+)$',text,M)]
    factors,next_products=map(int,search(r'^open row cap (\d+) (\d+) frontier saved$',text,M).groups())
    assert tuple(j[0] for j in joins)==tuple(range(87,factors-1,-1))
    return factors,next_products,len(joins),sum(j[1] for j in joins),max(j[2] for j in joins)

def prep(text):
    first=search(r'^branch (\d+) support assignments (\d+) planned rows (\d+) encoded bytes (\d+)$',text,M)
    sweep=search(r'^sweep 1 rows \d+ to (\d+) coalesced \d+ visits (\d+)$',text,M)
    return tuple(map(int,first.groups()+sweep.groups()))

metrics128=metrics(cont128)
assert metrics128==(20,2789920,68,5022652,334912)
assert cont128_later.strip().endswith('open row cap 12 1439712 frontier saved')
cont672=(root/'contraction.out').read_text()
metrics672=metrics(cont672)
assert metrics672==(26,3563808,62,3028312,301824)
assert (root/'contraction.err').read_bytes()==b''
assert (root/'contraction.time').read_text().splitlines()[-1]=='exit_status 2'
p128=prep(prep128)
p672=prep((root/'preparation.out').read_text())
assert p128[:4]==(128,*plans[128][:3]) and p672[:4]==(672,*plans[672][:3])
print('comparison columns group support rows encoded saturated_rows sweep_visits remaining_factors refused_next_products completed_joins completed_products max_completed_output_rows')
for p,m in ((p128,metrics128),(p672,metrics672)):
    print('comparison',*p,*m,flush=True)

path=root/'row-cap-physical-slice-dense-branch.pkl'
cap=pickle.loads(path.read_bytes())
assert set(cap)=={'factors','used_before','rejected_pair','matched','physical_cut'}
assert cap['physical_cut']==(None,None) and cap['used_before']==metrics672[3]
assert len(cap['factors'])==metrics672[0] and cap['matched']==metrics672[1]
assert prod(d for _,_,d in cap['factors'])==den
f,g=(cap['factors'][i] for i in cap['rejected_pair'])
shared=tuple(w for w in f[0] if w in g[0])
def projection(tensor):
    axes,rows,_=tensor
    positions=tuple(axes.index(w) for w in shared)
    return Counter(tuple(row[i] for i in positions) for row in rows)
c1,c2=map(projection,(f,g))
assert sum(n*c2[key] for key,n in c1.items())==cap['matched']
print('PASS terminal cap checkpoint',digest(path),'rejected pair',cap['rejected_pair'],'factor rows',
      sum(len(r) for _,r,_ in cap['factors']),'complete products',cap['used_before'],'next forecast',cap['matched'],flush=True)
