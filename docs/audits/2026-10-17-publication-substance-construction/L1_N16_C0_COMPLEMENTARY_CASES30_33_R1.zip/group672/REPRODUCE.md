# Cost sample in dense group 672

Reconstruct the compiled factor blocks and cut inputs from the dense compiled
factor and streamed-cut evidence. Verify cut-plan.tsv, block-index.tsv,
cut-axes.tsv and schema.tsv against input.sha256. Run the corrected preparation
script with group argument 672. Its group identifier is preserved in the
serialized metadata. The earlier preparer reused the group variable in its
pair loop. The two runs produced identical signed factors and work metadata
apart from the group identifier, and the contraction script consumes the
factors and work count. Use the corrected frontier when rerunning
contract-branch.py. The capped terminal frontier contains 26 factors and
2,139,736 rows. Compare the exact cap and restart hashes.

The original preparation's timing wrapper logged a sysctl permission error
after the child produced its checkpoint. The corrected preparation was
measured with Python's monotonic timer and child maximum RSS. The contraction
was timed the same way. Exit status 2 is the explicit row-cap refusal.
Timings include other live local review work and are observed wall time.

The prior group 672 timing receipts record preparation at 34.81 seconds
and contraction at 60.32 seconds. Both original run logs and both saved
frontier files match this repeat byte for byte before the metadata fix.

To reproduce the worst W slice, restrict both factors of the rejected pair
(4, 8) to W(1,3,0)=(0,2), remove the now-fixed axis from both factors, and
keep every other factor, coefficient and denominator. Serialize the result
as dense-saturated-frontier.pkl with the original completed work count and
the physical-cut tuple. The contractor only changes the diagnostic and
restart metadata for that cut. The resulting join hits the same 500,000-row
cap even though projected products fall below one million.
