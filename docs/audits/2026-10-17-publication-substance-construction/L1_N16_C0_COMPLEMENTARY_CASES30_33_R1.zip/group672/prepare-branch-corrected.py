from ast import literal_eval as lit
from collections import Counter,defaultdict
from itertools import combinations
from math import lcm
from pathlib import Path
import pickle,sys
exec(Path('quotient.py').read_text().split('\nlocal_test()\n',1)[0])
local_test()
schema={}
for line in Path('schema.tsv').read_text().splitlines():
    name,labels,physical,n,rows,den=line.split('\t')
    schema[name]=(lit(labels),lit(physical),int(den))
data=[]
for line in Path('block-index.tsv').read_text().splitlines():
    name,row,start,size,rows,den=line.split('\t')
    data.append((name,lit(row),int(start),int(size),int(rows),int(den)))
axes=lit(Path('cut-axes.tsv').read_text())
records=[]
for line in Path('cut-plan.tsv').read_text().splitlines():
    i,n,rows,size,label,indices=line.split('\t')
    records.append((int(rows),int(i),int(n),int(size),lit(label),lit(indices)))
row_count,group_id,support,size,labels,indices=min(records) if len(sys.argv)==1 else next(row for row in records if row[1]==int(sys.argv[1]))
selected=dict(zip(axes,labels))
indices_by_name=defaultdict(list)
for i in indices:
    name,key,start,blocksize,count,d=data[i]
    assert all(v==selected[w] for w,v in zip(schema[name][0],key) if w in selected)
    indices_by_name[name].append((key,start,blocksize,count,d))
print('branch',group_id,'support assignments',support,'planned rows',row_count,'encoded bytes',size,flush=True)
assert len(indices_by_name)==88
F=[]
loaded=0
for name,items in sorted(indices_by_name.items()):
    keys,physical,_=schema[name]
    keep=tuple(i for i,w in enumerate(keys) if w not in selected)
    finalaxes=tuple(keys[i] for i in keep)+physical
    common=lcm(*(item[-1] for item in items))
    entries={}
    with Path(f'compiled/{name}.blocks').open('rb') as f:
        for key,start,blocksize,count,d in items:
            f.seek(start)
            known,ports,den,rows=pickle.load(f)
            assert (known,den,len(rows),f.tell())==(key,d,count,start+blocksize)
            phases=tuple(ports.index(w) if w in ports else None for w in physical)
            tag=tuple(key[i] for i in keep)
            scale=common//den
            for row,(a,b) in rows.items():
                x=tag+tuple(row[i] if i is not None else 0 for i in phases)
                assert x not in entries
                entries[x]=a*scale,b*scale
            loaded+=count
    F.append((finalaxes,entries,common))
assert loaded==row_count
degrees=Counter(w for scope,_,_ in F for w in scope)
assert sum(k[0]!='L' for k in degrees)==424 and all(v==2 for k,v in degrees.items() if k[0]!='L')
print('loaded rows',loaded,'factor families',len(F),'live label axes',sum(k[0]=='L' for k in degrees),flush=True)
pairs=[(i,j) for i,j in combinations(range(len(F)),2)
       if any(w[0]!='L' and w in F[j][0] for w in F[i][0])]
visits=0
for step in range(2):
    before=sum(len(r) for _,r,_ in F)
    folded=0
    for i,j in pairs:
        for a,b in ((i,j),(j,i)):
            visits+=len(F[a][1])+len(F[b][1])
            assert visits<=60000000,('quotient sweep cap',visits)
            F[a],F[b],removed=quotient(F[a],F[b],degrees)
            folded+=removed
    after=sum(len(r) for _,r,_ in F)
    print('sweep',step,'rows',before,'to',after,'coalesced',folded,'visits',visits,flush=True)
    if any(not r for _,r,_ in F):
        print('exact zero by empty factor',group_id)
        break
with Path('dense-saturated-frontier.pkl').open('wb') as f:
    pickle.dump({'factors':F,'used_before':0,'branch':group_id,'support':support},f,protocol=5)
