# Complementary tuple 0 outer cases 30 through 33

Reconstruct the original selector-1 parent from the review source pins.
Rebuild the four distinct outer cuts and follow the primary and rescue
receipts and saved frontier hashes. Recreate each nine-coordinate inner
roster, then follow the author shard receipts for the capped triangles
and, in cases 32 and 33, the two capped four-factor slices. The independent
reviews use alternative contraction pivots and preserve the raw
signed values, work receipts and exact normalization. Use only trusted
serialized inputs.

Compare preceding-thirty.tsv against the thirty-term-retally.tsv from the
preceding committed archive. Run python3 verify-and-retally.py to replay the
signed arithmetic and cumulative retally. This verifies terms in the
specified complementary child.
