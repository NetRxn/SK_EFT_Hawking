from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import re
import shutil
import subprocess
import sys

author = Path('/private/tmp/l1-c0-complementary-cases24-47.XWr8Qj/tuple0-1/30')
parent = author/'row-cap-physical-slice-dense-label-rescue-reduced.pkl'
cwd = Path.cwd()
scripts = ('exact-multicut.py', 'reduce-label-frontier.py', 'contract-reduced-label.py',
           'contract-peer.py', 'peer_pair.py', 'checkpoint/quotient.py')
bindings={str(n): receipt for n, *_, receipt in
          (ln.split('\t') for ln in (author/'author-case30.tsv').read_text().splitlines() if not ln.startswith('sum\t'))}

def check_file(actual, original):
    assert sha256(actual.read_bytes()).digest() == sha256(original.read_bytes()).digest(), actual

def verify(i):
    scratch = cwd/f'lineage-{i}'
    scratch.mkdir()
    (scratch/'checkpoint').mkdir()
    for name in scripts:
        shutil.copyfile(author/name, scratch/name)

    def invoke(program, args, log, exit_code=0, original=None):
        with (scratch/log).open('xb') as out:
            p = subprocess.run([sys.executable, '-u', program, *args], cwd=scratch,
                               stdout=out, stderr=subprocess.STDOUT, timeout=180)
        assert p.returncode==exit_code,(i,program,args,p.returncode)
        check_file(scratch/log,author/(original or log))

    def checked(name):
        check_file(scratch/name, author/name)

    tag = f'slice-{i}'
    initial = tag + '.pkl'
    invoke('exact-multicut.py',[str(parent),initial,str(i)],tag+'-plan.out')
    checked(initial)
    checked(tag+'.roster')
    stages = []
    while True:
        invoke('reduce-label-frontier.py',[initial,tag],tag+'-reduce.out')
        checked(f'label-{tag}-reduced-frontier.pkl')
        receipt = tag+'-contract.out'
        terminal = receipt == bindings[str(i)]
        program = 'contract-peer.py' if tag.startswith('rescue') else 'contract-reduced-label.py'
        invoke(program,[tag],receipt,exit_code=0 if terminal else 2)
        stages.append((tag, (scratch/receipt).read_text().splitlines()[-1]))
        if terminal:
            break
        saves = list(scratch.glob(f'*-dense-label-{tag}-reduced.pkl'))
        assert len(saves)==1,(i,tag,saves)
        initial = saves[0].name
        checked(initial)
        if i in (5,6) and tag == f'rescue-{i}-1':
            assert bindings[str(i)] == f'slice-{i}-shard-sum.out'
            break
        tag=f'rescue-{i}-{len(stages)-1}'
    return i, stages

with ThreadPoolExecutor(max_workers=3) as pool:
    for index, stages in pool.map(verify,map(int,sys.argv[1:])):
        for tag, end in stages:
            print(index, tag, 'byte-identical', end, sep='\t', flush=True)
