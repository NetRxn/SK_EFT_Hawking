# Independent verification of complementary tuple 0 outer case 30

The exact normalized sum is
**-603848671539328985994783/5192296858534827628530496329220096 + 0i**.

The original separator archive was read from publication checkpoint
2857ccc12539261a46532e12dd1ae145472aed60 and matches the worktree bytes.
Its manifest verified. The decompressed complementary parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It has selector R(0,0,2,0,1)=1. Its rejected-pair histogram reconstructs
the full 48-coordinate roster over 6,427,904 products. Outer case 30
is (66, (3,)) with 141,792 pair products. The inverse lift recovers
403,656 compatible rows with their exact Gaussian coefficients and
denominators. First-child cases 28 and 30 have the same scalar under
selector 0. This calculation uses its own selector-1 operand.

Two outer row-cap stages reproduce the seven-factor inner parent
fbd00ee7e29126c401e1e898513d93d461eb86d7cb1fbb766187301ba0e53019.
Its rejected-pair histogram reconstructs all nine inner coordinates on
G(0,1,2) over 2,911,488 matched products. Each exact inverse lift
recovers every compatible parent row. The outer caps and all 20 inner
generic cycles reproduce byte for byte, including the 13 inner caps
and seven generic exact terminals.

| Slice | Inner coordinate | Projected pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 12 | 195,456 | -5692727247760044234855/2596148429267413814265248164610048 |
| 1 | 48 | 199,296 | -7741476545915524167/81129638414606681695789005144064 |
| 2 | 96 | 232,512 | -2164765870170958229109/162259276829213363391578010288128 |
| 3 | 144 | 232,512 | -2164765870170958229109/162259276829213363391578010288128 |
| 4 | 192 | 265,728 | 1846598470298593469829/649037107316853453566312041152512 |
| 5 | 3 | 394,752 | -131056210396553359661415/2596148429267413814265248164610048 |
| 6 | 5 | 461,184 | -143949272609465419525695/5192296858534827628530496329220096 |
| 7 | 80 | 465,024 | -15533460303436396556379/2596148429267413814265248164610048 |
| 8 | 160 | 465,024 | -15533460303436396556379/2596148429267413814265248164610048 |

Seven terminal states pass a fresh direct sparse schedule. The independent
triangle schedule for slices 5 and 6 uses pivot 1 and matches the author
pivot 0 raw numerators and normalized values. Each alternate triangle
covers 13,317,120 matching triples and uses 13,394,880 Gaussian products.
The audit independently verifies eight author shard intervals per
triangle. The parent projected pair counts for slices 5 and 6 are
394,752 and 461,184, respectively. Every slice uses the common
factor denominator product 40512224221827380280140849737629696
and normalization 1/(16*4^64) once.

The timing receipt records wall time and product counts per independent
terminal replay. Sparse runs took 0.3608–11.5513 s. Triangle slices 5 and
6 took 11.356 s and 11.724 s in concurrent scratch runs.

The review manifest uses relative paths and includes copies of the
author receipts. The frozen-input inventory records the checkpoints
used for exact replays.
