from pathlib import Path
import re

print('slice\tmethod\tgaussian_products\twall_seconds\treceipt')
for i in range(9):
    if i in (5,6):
        file=Path(f'slice-{i}-triangle-replay.out')
        method='alternate_triangle_pivot_1'
        pattern=r'^independent pivot 1 .* Gaussian products (\d+) wall seconds (\S+)$'
    else:
        file=Path(f'slice-{i}-sparse-replay.out')
        method='sparse'
        pattern=r'^exact normalized real .* independent matched products (\d+) wall seconds (\S+)$'
    match=re.search(pattern,file.read_text(),re.M)
    assert match is not None,file
    products,seconds=match.groups()
    print(i,method,products,seconds,file.name,sep='\t')
