from decimal import Decimal
from pathlib import Path
import re

print('slice\tshard\twall_seconds\treceipt')
for i in (5,6):
    for shard in range(8):
        path=Path(f'author-receipts/slice-{i}-shard-{shard}.out')
        seconds=re.search(r'^exact normalized real .* imaginary .* seconds (\S+)$',path.read_text(),re.M)[1]
        assert Decimal(seconds)>0
        print(i,shard,seconds,path,sep='\t')
