# Independent verification of complementary tuple 0 outer case 31

The exact normalized sum is
**-153959781396137153207967/1298074214633706907132624082305024 + 0i**.

The original separator archive was read from publication checkpoint
bc39124d43aee12bc323030c5989e491118c02db and matches the worktree bytes.
Its manifest verified. The decompressed complementary parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It has selector R(0,0,2,0,1)=1. Its rejected-pair histogram reconstructs
the full 48-coordinate roster over 6,427,904 products. Outer case 31
is (68, (3,)) with 141,792 pair products. The inverse lift recovers
403,656 compatible rows with their exact Gaussian coefficients and
denominators. First-child cases 29 and 31 have the same scalar under
selector 0. This calculation uses its own selector-1 operand.

Two outer row-cap stages reproduce the seven-factor inner parent
8fafc779bf3825be32f6c251c7bb9644b892f7c4d862fd5ca81c8235bfb5c7e0.
Its rejected-pair histogram reconstructs all nine inner coordinates on
G(0,1,2) over 2,911,488 matched products. Each exact inverse lift
recovers every compatible parent row. The outer caps and all 20 inner
generic cycles reproduce byte for byte, including the 13 inner caps
and seven generic exact terminals.

| Slice | Inner coordinate | Projected pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 3 | 195,456 | -5692727247760044234855/2596148429267413814265248164610048 |
| 1 | 48 | 199,296 | -7741476545915524167/81129638414606681695789005144064 |
| 2 | 96 | 232,512 | -8922273288258176388171/649037107316853453566312041152512 |
| 3 | 144 | 232,512 | -8922273288258176388171/649037107316853453566312041152512 |
| 4 | 192 | 265,728 | 986920747720823072997/324518553658426726783156020576256 |
| 5 | 5 | 394,752 | -68374468822156701948135/2596148429267413814265248164610048 |
| 6 | 12 | 461,184 | -17282068170213171911355/324518553658426726783156020576256 |
| 7 | 80 | 465,024 | -3983159223360507705921/649037107316853453566312041152512 |
| 8 | 160 | 465,024 | -3983159223360507705921/649037107316853453566312041152512 |

Seven terminal states pass a fresh direct sparse schedule. The independent
triangle schedule for slices 5 and 6 uses pivot 1 and matches the author
pivot 0 raw numerators and normalized values. Each alternate triangle
covers 13,317,120 matching triples and uses 13,394,880 Gaussian products.
The audit independently verifies eight author shard intervals per
triangle. The parent projected pair counts for slices 5 and 6 are
394,752 and 461,184, respectively. Every slice uses the common
factor denominator product 40512224221827380280140849737629696
and normalization 1/(16*4^64) once.

The timing receipt records wall time and product counts per independent
terminal replay. Sparse runs took 0.3679–11.9483 s. Triangle slices 5 and
6 took 12.143 s and 12.003 s in concurrent scratch runs. The checkpoint
timing receipts separately record all five outer commands and all 49
inner cut, reduction and contraction commands, including cap exits.
A separate receipt lists the original author timings for each of the 16
triangle shards. All times are observed elapsed values.

The review manifest uses relative paths and includes copies of the
author receipts. The frozen-input inventory records the checkpoints
used for exact replays.
