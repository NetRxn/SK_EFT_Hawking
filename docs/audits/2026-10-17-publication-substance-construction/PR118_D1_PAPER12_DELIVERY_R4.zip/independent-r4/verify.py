import ast
import hashlib
from pathlib import Path
import re
import subprocess as sp
import sys

r3, a3, r4 = map(Path, sys.argv[1:])
base = "f9ee606b79542dbd01413a2745ada12bc326aff3"
registry = "src/core/citations.py"
trees = [a3 / "tree", r4 / "tree"]
def git(tree, *args):
    return sp.check_output(["git", "-C", tree, *args])
def sections(path):
    return {s.splitlines()[0].decode().split()[-1][2:]: s
            for s in path.read_bytes().split(b"diff --git ")[1:]}

def sections_bytes(data):
    return {s.splitlines()[0].decode().split()[-1][2:]: s
            for s in data.split(b"diff --git ")[1:]}

p3 = sections(r3 / "composed-r3.patch")
p4 = sections(r4 / "composed-r4.patch")
assert len(p3) == 12 and set(p4) == set(p3) | {registry}
assert all(p4[k] == v for k, v in p3.items())
short = sections(r4 / "r4-only.patch")[registry].splitlines(keepends=True)
full = p4[registry].splitlines(keepends=True)
assert short[0] == full[0] and short[2:] == full[2:]
assert all(b.startswith(a) for a, b in zip(short[1].split()[1].split(b".."), full[1].split()[1].split(b"..")))
for tree, patch in zip(trees, [p3, p4]):
    assert git(tree, "rev-parse", "HEAD").decode().strip() == base
    assert set(git(tree, "diff", "HEAD", "--name-only", "-z").decode().rstrip("\0").split("\0")) == set(patch)
    assert not git(tree, "diff", "HEAD", "--check")
    # Verify patch matches each frozen tree, including index and binary payloads.
    assert sections_bytes(git(tree, "diff", "HEAD", "--binary", "--full-index")) == patch
    # Ordinary untracked and ignored scratch outputs are outside the patch.
for k in p3:
    assert (trees[0]/k).read_bytes() == (trees[1]/k).read_bytes()
original, revised = [(tree / registry).read_bytes() for tree in trees]
needle = b"'used_in': ['papers/E2/paper_draft.tex'],"
replacement = b"'used_in': ['papers/E2/paper_draft.tex', 'papers/D1/paper_draft.tex'],"
offset = original.index(b"'AndersonBFP2014Graybody':")
i = original.index(needle, offset)
assert revised == original[:i] + replacement + original[i+len(needle):]
def entries(data):
    dictionary = next(n.value for n in ast.parse(data).body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == "CITATION_REGISTRY" for t in n.targets))
    return {k.value: ast.literal_eval(v) for k, v in zip(dictionary.keys, dictionary.values)
            if isinstance(k, ast.Constant) and k.value in {"AndersonBFP2013", "AndersonBFP2014Graybody"}}
before, after = map(entries, (original, revised))
assert before["AndersonBFP2013"] == after["AndersonBFP2013"]
gray = after["AndersonBFP2014Graybody"]
assert before["AndersonBFP2014Graybody"] | {"used_in": gray["used_in"]} == gray
assert gray["arxiv"] == "1404.3224v3"
assert gray["primary_source_path"].endswith("/AndersonBFP2014Graybody.pdf")
for path in gray["used_in"]:
    source = (trees[1]/path).read_text()
    assert re.search(r"\\cite\{AndersonBFP2014Graybody\}", source)
    item = source.split(r"\bibitem{AndersonBFP2014Graybody}")[1].split(r"\bibitem")[0]
    assert "104044 (2014), arXiv:1404.3224v3." in item
print("12 accepted R3 patch sections and tracked file bytes are identical.")
print("R4 matches the candidate tree and adds exactly one registry line.")
print("Both live consumers cite PRD 90, 104044 and arXiv:1404.3224v3.")
print("2013 record, 2014 version, recorded PDF path and scope are retained.")
for path in [r3/"composed-r3.patch", r4/"composed-r4.patch", r4/"r4-only.patch"]:
    print(hashlib.sha256(path.read_bytes()).hexdigest(), path)
