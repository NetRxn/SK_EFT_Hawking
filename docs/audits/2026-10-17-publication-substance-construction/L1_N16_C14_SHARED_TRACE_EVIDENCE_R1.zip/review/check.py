from collections import Counter, defaultdict
from itertools import product
from math import prod
from pathlib import Path
import json,sys

from src.core.formulas import original_action_factors, original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol

author,star,prior=map(Path,sys.argv[1:])
meta=json.loads((author/'result.json').read_text())
sm=json.loads((star/'result.json').read_text())
census=json.loads((prior/'support-census.json').read_text())['sites']
reg=OriginalRegulator()
siteindex={x:i for i,x in enumerate(reg.sites)}
def read(f):
    return [json.loads(x) for x in f.read_text().splitlines()]
def frozen(x):
    return tuple(map(frozen,x)) if isinstance(x,(list,tuple)) else x

def incidences(root):
    def edge(x,d):return frozenset((x,reg.step(x,d)[0]))
    def anchors(x,axes):
        sets={tuple(sorted((tuple(y),k) for y,k in a)) for deg,c,a,n,_ in census[x]['raw_branches']
              if deg==2 and tuple(d for d,_ in c)==axes and n}
        assert len(sets)==1
        return next(iter(sets))
    row=sm['row']
    acts=[('S2',x,i,(a,b),anchors(x,(a,b))) for i,(x,a,b) in enumerate(row['planes'])]
    acts += [('S4',x,i,tuple(range(4)),()) for x,n in enumerate(row['S4_occupations']) for i in range(n)]
    x=reg.sites[root]
    result=[]
    for d in range(4):
        target=edge(x,d)
        frame=tuple((fam,i,j,a) for fam,i,j,axes,_ in acts for a in axes if edge(reg.sites[i],a)==target)
        trace=tuple((fam,i,j,(siteindex[y],a)) for fam,i,j,_,src in acts for y,a in src if edge(y,a)==target)
        result.append((siteindex[reg.step(x,d)[0]],frame,trace))
    return result

owners=incidences(8)
assert owners==[(e['neighbor'],frozen(e['coframes']),frozen(e['open_trace_legs'])) for e in sm['edges']]
assert tuple(x[2] for x in owners[0][2])==tuple(x[2] for x in owners[1][2])==(2,3)
A=owners[0][2][0][-1]
B=owners[1][2][0][-1]
assert (A,B)==frozen(meta['seam_anchors'])==((0,0),(8,1))
C,D=frozen(meta['residual_anchors'])
assert (C,D)==((4,0),(0,1))
reg0=reg.sites[0]
links={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in reg.link_order}
def add(z,w):
    return z[0]+w[0],z[1]+w[1]
def mul(z,w):
    return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def signs(s,z):
    return s*z[0],s*z[1]

raw = original_action_factors(reg,reg0,links)
# Independently accumulate raw trace orientation entries and keep the
# complete open components and two remote-anchor coordinates.
source=defaultdict(lambda:(0,0))
n=0
for f in raw:
    if f.t_degree!=2 or sorted(a for _,a,_ in f.components)!=[2,3]:
        continue
    n+=1
    components=tuple(a for _,_,a in sorted(f.components))
    for key,value in f.coefficient.terms:
        labels={(siteindex[s.index[0]],s.index[1]):s.index[3]+4*(s.index[2]=='R') for s in key}
        assert len(key)==4 and set(labels)=={A,B,C,D}
        u,v,w,z=(labels[t] for t in (A,B,C,D))
        k=(u,v,*components,w,z)
        x,y=value.real*4,value.imag*4
        assert x.denominator==y.denominator==1
        source[k]=add(source[k],(int(x),int(y)))
assert n==64 and len(source)==2048
signed={k:z for k,z in source.items() if any(z)}
trace=dict(frozen(read(author/'trace-slices.jsonl')))
assert signed==trace and len(trace)==meta['trace_nonzero_rows']==1536
bins=Counter(k[:2] for k in trace)
assert len(bins)==32 and set(bins.values())=={48}
print('64 signed raw source branches, 1536 exact nonzero trace entries and 512 exact canceled rows; 32 joint bins x 48',flush=True)

edges=[dict(frozen(read(star/f'edge-{d}.jsonl'))) for d in range(4)]
partitions=frozen(read(star/'site-factors.jsonl'))
assert len(partitions)==meta['retained_site_partitions']==240
mask_pairs={p[:2] for p,_,_ in partitions}
labels=[defaultdict(set),defaultdict(set)]
for d in (0,1):
    for k in edges[d]:
        labels[d][k[0]].add(k[-2:])
# Generate candidate tiles from two independent occurrence trace bins,
# and check both pre-existing edge slice interfaces and site masks.
tiles=set()
for (m,n),(u2,v2),(u3,v3) in product(mask_pairs,bins,bins):
    if (u2,u3) in labels[0][m] and (v2,v3) in labels[1][n]:
        tiles.add((m,n,u2,u3,v2,v3))
rows=frozen(read(author/'conditional-tiles.jsonl'))
assert tiles==set(rows) and len(rows)==len(tiles)==36608 and len(mask_pairs)==108
assert Counter((u2//4,u3//4) for _,_,u2,u3,_,_ in rows)=={(0,0):1920,(0,1):16384,(1,0):16384,(1,1):1920}
print('36,608 tiles exactly matched, over 108 mask-pair groups and all 240 site partitions',flush=True)

def literal_signature(local,ext):
    slots=[]
    for axis,(m,e) in enumerate(zip(local,ext,strict=True)):
        neighbor=owners[axis][0]
        slots.extend(sorted([64+i for i in range(8) if m>>i&1]+
                     [8*neighbor+i for i in range(8) if e[0]>>i&1]))
    if len(set(slots))!=16:return 0
    return (-1)**sum(i>j for k,i in enumerate(slots) for j in slots[k+1:])

def signs_and_controls(control):
    ext=frozen(control['edge_boundary'])
    tr=frozen(control['trace_boundary'])
    # Fixed exterior boundary first. Full raw trace table, no tile or
    # serialized site sign used, so this tests both independently.
    operands=[[(k[0],k[4:],z) for k,z in e.items() if k[1:4]==b] for e,b in zip(edges,ext,strict=True)]
    exact=(0,0)
    alias=(0,0)
    for a,b,c,d in product(*operands):
        picks=(a,b,c,d)
        s=literal_signature(tuple(q[0] for q in picks),ext)
        if not s:
            continue
        edgeprod=(s,0)
        for _,_,z in picks:
            edgeprod=mul(edgeprod,z)
        K=(a[1][0],b[1][0])
        J=(a[1][1],b[1][1])
        F=signed.get(K+tr[0],(0,0))
        exact=add(exact,mul(edgeprod,mul(F,signed.get(J+tr[1],(0,0)))))
        alias=add(alias,mul(edgeprod,mul(F,signed.get(K+tr[1],(0,0)))))
    assert exact==tuple(control['numerator']) and alias==tuple(control['false_occurrence_alias_numerator'])
    assert exact!=alias and any(exact)
    return exact,alias

for c in meta['fixed_boundary_controls']:
    print('control exact/false reuse',*signs_and_controls(c),flush=True)
assert prod(meta['edge_denominators'])*4**2==meta['common_sewn_denominator']==38654705664
assert sm['row']['exponential_divisor']==512

root0=incidences(0)
print('rank-zero exact owner interface by axis',root0,flush=True)
assert [d[0] for d in root0]==[8,4,2,1]
assert all(len(d[1])==len(d[2])==2 for d in root0)
assert tuple(x[-1] for x in root0[1][2])==((0,1),(0,1))
assert tuple(x[2] for x in root0[1][2])==(2,3)
assert all(tuple(x[2] for x in root0[d][2])==(0,1) for d in (2,3))
print('next axes 1/2/3 are degree four; (23) residual (4,0) remains open; (01) traces gain slots (0,2),(0,3) and retain (2,3),(1,2)',flush=True)
