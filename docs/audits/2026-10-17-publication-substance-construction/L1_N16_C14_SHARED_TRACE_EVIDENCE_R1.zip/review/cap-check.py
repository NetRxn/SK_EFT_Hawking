import ast,json,sys
from collections import Counter
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace
a=Path(sys.argv[1])
p=json.loads((a/'result.json').read_text())
m=p['meters']
assert m['work']==sum(p['charged_operations'].values())==173754
assert m['rows']==69494 and m['tracked_bytes']==m['rows']*384==26685696
assert m['output_bytes']==sum((a/f).stat().st_size for f in ('trace-slices.jsonl','conditional-tiles.jsonl'))==636160
assert all(m[k]<=p['limits'][k] for k in m)
assert p['peak_rss_bytes']==114475008<p['limits']['sampled_rss']==384*1024**2
ns=dict(Counter=Counter,json=json,METERS=Counter(),WORK=Counter(),PEAK_RSS=0,
    LIMITS=dict(work=2,rows=2,tracked_bytes=768,output_bytes=4,scalar=127,sampled_rss=7),
    resource=SimpleNamespace(RUSAGE_SELF=0,getrusage=lambda _:SimpleNamespace(ru_maxrss=8)))
names={'work','row','emit','put','add','times','rss'}
nodes=[n for n in ast.parse((a/'sew.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names]
exec(compile(ast.Module(nodes,[]),'frozen guards','exec'),ns)
def refuses(fn,reason):
    try: fn()
    except RuntimeError as e:
        assert e.args[0]==reason or e.args[0][0]==reason
    else: raise AssertionError(reason)
for i in range(2):
    ns['work']('visit')
    ns['row']()
refuses(lambda:ns['work']('visit'),'prospective_work')
refuses(ns['row'],'prospective_table')
f=BytesIO()
ns['emit'](f,0)
refuses(lambda:ns['emit'](f,[0]),'prospective_output')
refuses(lambda:ns['add']((-123,0),(-5,0)),'prospective scalar sum')
refuses(lambda:ns['times']((90,0),(2,0)),'prospective scalar product')
refuses(ns['rss'],'sampled_rss')
assert ns['METERS']=={'work':2,'rows':2,'tracked_bytes':768,'output_bytes':2}
assert f.getvalue()==b'0\n'
print('prospective and sampled guards pass lowered-limit controls')
print('author meter totals 173754 work, 69494 cumulative rows, 26685696 accounting bytes, 636160 serialized bytes, 114475008 author-observed sampled peak RSS')
