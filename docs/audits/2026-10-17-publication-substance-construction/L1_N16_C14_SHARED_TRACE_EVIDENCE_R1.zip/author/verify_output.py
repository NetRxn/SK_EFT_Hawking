"""Read serialized artifacts independently and exhaust the admissible tile interface."""
from collections import Counter, defaultdict
from pathlib import Path
import json

ROOT=Path(__file__).parent
PREV=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')

def rows(path):
    with path.open() as f:
        for line in f:
            yield json.loads(line)

trace={}
for key,z in rows(ROOT/'trace-slices.jsonl'):
    u,v,*outside=key
    assert len(outside)==4 and u//4==v//4 and any(z)
    k=tuple(key)
    assert k not in trace
    trace[k]=z
seam={k[:2] for k in trace}
counts=Counter(k[:2] for k in trace)
assert set(counts.values())=={48} and len(seam)==32
assert seam=={(u,v) for u in range(8) for v in range(8) if u//4==v//4}

axis={}
for i in (0,1):
    grouped=defaultdict(set)
    for (mask,remote,a,b,u,v),z in rows(PREV/f'edge-{i}.jsonl'):
        assert any(z)
        grouped[mask].add((u,v))
    axis[i]=grouped

mask_pairs={tuple(p[:2]) for p,s,n in rows(PREV/'site-factors.jsonl')}
tiles=defaultdict(set)
for m,n,u,v,x,y in rows(ROOT/'conditional-tiles.jsonl'):
    assert (m,n) in mask_pairs
    k=(u,v,x,y)
    assert k not in tiles[m,n]
    tiles[m,n].add(k)
assert set(tiles)==mask_pairs
for m,n in mask_pairs:
    def split(table):
        groups=defaultdict(list)
        for u,v in table:
            groups[u//4,v//4].append((u,v))
        return groups
    left,right=split(axis[0][m]),split(axis[1][n])
    actual={(u,v,x,y) for hand in left.keys()&right.keys()
            for u,v in left[hand] for x,y in right[hand]}
    assert actual==tiles[m,n]

print(json.dumps(dict(trace_rows=len(trace),seam_bins=len(seam),
   mask_pairs=len(mask_pairs),conditional_tiles=sum(map(len,tiles.values())),
   occurrence_chirality_tile_counts=sorted(
      (list(hand),n) for hand,n in Counter((u//4,v//4) for table in tiles.values()
                        for u,v,x,y in table).items())),indent=2))
