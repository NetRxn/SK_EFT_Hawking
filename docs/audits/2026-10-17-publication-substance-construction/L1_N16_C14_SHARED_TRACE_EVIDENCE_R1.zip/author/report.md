# Exact shared-trace sewing for original N16 c14

This is the periodic closed source_C, zero-centered (01,01,23,23)
representative at pinned clean primary 27012c18fa374e8341e124b510abbedeedb18d29.
The cut starts from the independently accepted exact rank-8 site star.
It sews both original (23) S2 trace occurrences, IDs 2 and 3. It leaves
all remaining exterior masks, action components, remote link coordinates
and action factors open.

## Exact representation

Read the four edge slice tables and signed rank-8 partitions from the
accepted edge/site package. The two open trace coordinate slots on axis
0 are on directed anchor (site rank 0, axis 0); the slots on axis 1 are
on directed anchor (rank 8, axis 1). The slots in each axis table are
ordered by original occurrences 2 and 3. Each coordinate value 0–7
means L0–L3, R0–R3 of that original anchor.

The frozen `trace-slices.jsonl` has entries
`[[u,v,a2,a3,r0,r1],[real,imag]]` with common denominator 4.
Here `(u,v)` is one occurrence's ordered pair of coordinates at the two
seam anchors. The components `(a2,a3)` are the original rank-zero
coframe components on axes 2 and 3. Coordinates `(r0,r1)` belong to the
actual remaining anchors (4,0) and (0,1). They remain open and keep their
chirality. The trace rows are the exact accumulated signed coefficients
from the 64 raw ordered source factors for the coframe plane 23, summed
by even coframe component identity. Only exact complex zeros are pruned.

The frozen `conditional-tiles.jsonl` has entries
`[mask0,mask1,u2,u3,v2,v3]`. An entry instructs the contraction to
multiply these four exact conditional slices:

- Axis-0 edge slice at `(mask0,(u2,u3))`.
- Axis-1 edge slice at `(mask1,(v2,v3))`.
- Original trace occurrence 2 at ordered seam pair `(u2,v2)`.
- Original trace occurrence 3 at ordered seam pair `(u3,v3)`.

For every accepted signed site partition, sum all its mask-pair tiles
and multiply by the corresponding axis-2 and axis-3 edge slices and
the original site sign. This contracts all four seam-coordinate
slots. It preserves all open labels as the tensor product of slices,
with exact signed addition where open boundary keys coincide. Both
trace factors use the same source coefficients but independent slot
IDs and independent open label tuples. The common denominator of the
combined factored result is 38,654,705,664. The representative's
exponential factorial divisor 512 remains external and is applied
once, rather than per tile or per trace.

## Completeness and checks

There are 1,536 nonzero trace rows, 48 for each of 32 admitted joint
seam bins. Two coordinates in the same original trace have the same
chirality, but their coordinate indices can differ. The readback
checker independently reconstructs all 36,608 admissible tiles over
108 local-mask pairs by matching edge chirality groups. It checks that
every frozen tile appears once, and that all 240 signed site partitions
retain the interface required by their masks. Tile counts across the
ordered occurrence chirality pairs LL, LR, RL and RR are 1,920, 16,384,
16,384 and 1,920.

Six nonzero fixed-boundary coefficients agree with the independent
contraction route. It fixes the original remote coordinates and
component tuple before summing the relevant raw ordered trace
orientations, enumerates exterior masks at the selected boundary
without using the serialized site partition signs, and calculates
sign from the full 128-generator word. The controls cover all four
ordered chirality pairs. Deliberately reusing occurrence 2's seam
coordinates in place of occurrence 3's changes all six coefficients.
The first control gives 1/12,288 with exact distinct occurrence labels
and 1/36,864 with false reuse. A mixed-chirality control gives 1/4,096
with the original labels and zero under false reuse.

The run charged 173,754 operations under a prospective 4,000,000
limit. It charged 69,494 cumulative rows against 300,000 at 384
accounting bytes per row, or 26,685,696 accounting bytes against
128 MiB. Its two exact output streams used 636,160 bytes against a
prospective 16 MiB output cap. Checked real and imaginary integer
arithmetic is limited prospectively to magnitude 2^61−1. Observed
process peak RSS was 114,475,008 bytes, checked periodically against
a 384 MiB ceiling. The latter is a sampled refusal guard. The
accounting bytes do not measure the interpreter's actual allocation.
Source constructors, caches, secondary indexing and sorting, manifest
work, and separate readback are outside the charged operation or
table meters. Original source initialization is included in process
RSS. The previously estimated 17,020,928 edge-row pairing route was
not executed, and no representative was flattened or evaluated.

## Next exact contraction

Use the sewn star's axis-0 exterior boundary at rank 0 to contract
the six other rank-zero coframes before projecting its eight
generators. Attach the two still-open original (01) S2 traces while
retaining the ordered (23) residual-anchor coordinates and the shared
original source component labels. First measure the conditional
slice cost and count the raw rank-zero seam owners from the complete
roster. A compact continuation should eliminate rank-zero masks or
components before expanding remote boundary slices. Both other axis
arrangements, whole representative values, c14, c0, the complete
denominator and its normalization are outside this checkpoint.
