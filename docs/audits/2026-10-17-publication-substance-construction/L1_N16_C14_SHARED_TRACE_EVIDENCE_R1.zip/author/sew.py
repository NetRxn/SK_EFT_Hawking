"""Complete sparse conditional sewing of two original source C3 trace occurrences."""
from collections import Counter, defaultdict
from functools import cache
from itertools import product
from pathlib import Path
import json, resource, sys

ROOT=Path(__file__).parent
PREV=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
SEAM=Path('/tmp/publication-c14-signed-r1.YJ2sFv')
sys.path.insert(0,str(SEAM))
from probe import REG, RANK, original_action_factors_cached

LIMITS=dict(work=4_000_000,rows=300_000,tracked_bytes=128*1024**2,
            output_bytes=16*1024**2,scalar=(1<<61)-1,sampled_rss=384*1024**2)
METERS=Counter()
WORK=Counter()
PEAK_RSS=0

def rss():
    global PEAK_RSS
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    PEAK_RSS=max(n,PEAK_RSS)
    if n>LIMITS['sampled_rss']:
        raise RuntimeError(('sampled_rss',n,LIMITS['sampled_rss']))

def work(phase):
    count=METERS['work']+1
    if count>LIMITS['work']:
        raise RuntimeError(('prospective_work',phase,count,LIMITS['work']))
    METERS['work']=count
    WORK[phase]+=1
    if count%2048==0:
        rss()

def row():
    n=METERS['rows']+1
    b=METERS['tracked_bytes']+384
    if n>LIMITS['rows'] or b>LIMITS['tracked_bytes']:
        raise RuntimeError(('prospective_table',n,b))
    METERS.update(rows=1,tracked_bytes=384)

def put(table,key,value):
    if key not in table:
        row()
    table[key]=value

def emit(f,value):
    text=json.dumps(value,separators=(',',':')).encode('ascii')+b'\n'
    n=METERS['output_bytes']+len(text)
    if n>LIMITS['output_bytes']:
        raise RuntimeError(('prospective_output',n,LIMITS['output_bytes']))
    f.write(text)
    METERS['output_bytes']=n

def add(z,w):
    lim=LIMITS['scalar']
    for a,b in zip(z,w):
        if (a>0 and b>0 and a>lim-b) or (a<0 and b<0 and a<-lim-b):
            raise RuntimeError('prospective scalar sum')
    return (z[0]+w[0],z[1]+w[1])

def times(z,w):
    a,b=z
    c,d=w
    m=max(abs(c),abs(d))
    if m and max(abs(a),abs(b))>LIMITS['scalar']//(2*m):
        raise RuntimeError('prospective scalar product')
    return (a*c-b*d,a*d+b*c)

# Same global alphabet as the accepted star tables, with original anchor IDs.
A0,A1,B0,B1=(0,0),(8,1),(4,0),(0,1)
ORDER=(A0,A1,B0,B1)
ZERO=(0,0)

def source_key(key):
    q={}
    for s in key:
        site,axis,hand,k=s.index
        anchor=(RANK[site],axis)
        assert anchor not in q and s.family=='q'
        q[anchor]=k+(4 if hand=='R' else 0)
    assert set(q)==set(ORDER)
    return tuple(q[a] for a in ORDER)

@cache
def raw_trace():
    source=original_action_factors_cached(REG.sites[0])
    factors=[f for f in source if f.t_degree==2 and {a[1] for a in f.components}=={2,3}]
    assert len(factors)==64
    return factors

def make_trace():
    # Split only by exact joint original seam tuple. Coefficient includes
    # original signs and orientation weights; the four remaining labels stay open.
    out={}
    for f in raw_trace():
        assert {(RANK[x],k) for x,k in f.anchors}==set(ORDER)
        a,b=(component[2] for component in sorted(f.components))
        for q,z in f.coefficient.terms:
            work('trace_source_monomial')
            q0,q1,r0,r1=source_key(q)
            val=(z.real*4,z.imag*4)
            assert all(v.denominator==1 and abs(v)<=LIMITS['scalar'] for v in val)
            k=(q0,q1,a,b,r0,r1)
            put(out,k,add(out.get(k,ZERO),tuple(v.numerator for v in val)))
    groups=defaultdict(dict)
    with (ROOT/'trace-slices.jsonl').open('wb') as f:
        for k,z in sorted(out.items()):
            work('trace_serialize')
            if z==ZERO:
                continue
            u,v,*outside=k
            assert u//4==v//4
            put(groups[u,v],tuple(outside),z)
            emit(f,[k,z])
    assert len(groups)==32 and {len(v) for v in groups.values()}=={48}
    return groups

def load_star():
    edges=[]
    for axis in range(4):
        indexed=defaultdict(lambda:defaultdict(dict))
        with (PREV/f'edge-{axis}.jsonl').open() as f:
            for line in f:
                work('edge_read')
                key,z=json.loads(line)
                m,n,a,b,*q=key
                assert len(q)==(2 if axis<2 else 0)
                assert all(0<=i<8 for i in q)
                k=(n,a,b)
                put(indexed[m][tuple(q)],k,tuple(z))
        edges.append(indexed)
    site=[]
    with (PREV/'site-factors.jsonl').open() as f:
        for line in f:
            work('site_read')
            masks,sg,_=json.loads(line)
            row()
            site.append((tuple(masks),sg))
    return edges,site

def make_tiles(edges, site, trace):
    tile_map={}
    eligible_pairs=sorted({p[:2] for p,_ in site})
    with (ROOT/'conditional-tiles.jsonl').open('wb') as f:
        for m,n in eligible_pairs:
            choices=[]
            for u,v in product(sorted(edges[0][m]),sorted(edges[1][n])):
                work('candidate_tile')
                keys=(u[0],v[0]),(u[1],v[1])
                if not all(k in trace for k in keys):
                    continue
                row()
                choices.append((u,v))
                emit(f,[m,n,*u,*v])
            assert choices
            put(tile_map,(m,n),choices)
    return tile_map

def literal_sign(parts, extern):
    # Read positions in the complete 128-generator top-word convention.
    word=[]
    for p,x,j in zip(parts,extern,(0,12,10,9),strict=True):
        word += sorted([64+i for i in range(8) if p>>i&1]+
                       [8*j+i for i in range(8) if x[0]>>i&1])
    if len(set(word))!=len(word):
        return 0
    return (-1)**sum(x>y for i,x in enumerate(word) for y in word[i+1:])

@cache
def fixed_raw_trace(outside):
    # Independent source reduction with directly matched raw ordered slots.
    a,b,r0,r1=outside
    out={}
    for f in raw_trace():
        if any(label != (a if direction==2 else b) for _,direction,label in f.components):
            continue
        for key,z in f.coefficient.terms:
            work('raw_fixed_trace_scan')
            u,v,x,y=source_key(key)
            if (x,y)!=(r0,r1):
                continue
            v0,v1=z.real*4,z.imag*4
            assert v0.denominator==v1.denominator==1
            k=(u,v)
            put(out,k,add(out.get(k,ZERO),(v0.numerator,v1.numerator)))
    return {k:v for k,v in out.items() if v!=ZERO}

@cache
def fixed_edge(axis,mask,outside):
    groups=EDGES[axis][mask]
    out={}
    for k,g in groups.items():
        work('fixed_edge_lookup')
        if outside in g:
            put(out,k,g[outside])
    return out

def tile_evaluate(ext, trace_ext, alias=False):
    a,b=trace_ext
    value=ZERO
    for (m,n,o,p),sg in SITE:
        work('tile_fixed_partition')
        z=EDGES[2][o][()].get(ext[2],ZERO)
        w=EDGES[3][p][()].get(ext[3],ZERO)
        if z==ZERO or w==ZERO:
            continue
        pref=times(times(z,w),(sg,0))
        e0=fixed_edge(0,m,ext[0])
        e1=fixed_edge(1,n,ext[1])
        eligible=product(e0,e1) if alias else TILES[m,n]
        for u,v in eligible:
            work('tile_fixed_lookup')
            if u not in e0 or v not in e1:
                continue
            k=(u[0],v[0])
            l=k if alias else (u[1],v[1])
            x=TRACE.get(k,{}).get(a,ZERO)
            y=TRACE.get(l,{}).get(b,ZERO)
            value=add(value,times(times(times(x,y),times(e0[u],e1[v])),pref))
    return value

def raw_evaluate(ext, trace_ext):
    # Solve the literal exterior pairing independently on the fixed boundary.
    raw0,raw1=map(fixed_raw_trace,trace_ext)
    masks=[]
    for axis,ext0 in enumerate(ext):
        masks.append([p for p in EDGES[axis] if fixed_edge(axis,p,ext0)])
    value=ZERO
    for p in product(*masks):
        work('raw_fixed_partition')
        sg=literal_sign(p,ext)
        if not sg:
            continue
        pref=times(times(fixed_edge(2,p[2],ext[2])[()],fixed_edge(3,p[3],ext[3])[()]),(sg,0))
        for (u,e),(v,g) in product(fixed_edge(0,p[0],ext[0]).items(),fixed_edge(1,p[1],ext[1]).items()):
            work('raw_fixed_axis_pair')
            x=raw0.get((u[0],v[0]),ZERO)
            y=raw1.get((u[1],v[1]),ZERO)
            value=add(value,times(times(times(e,x),times(g,y)),pref))
    return value

def checks():
    out=[]
    checked=set()
    alias_found=False
    hands=Counter()
    quotas={(0,0):2,(1,1):2,(0,1):1,(1,0):1}
    for i,(p,_) in enumerate(SITE):
        if i%7:
            continue
        m,n,o,q=p
        for u,v in TILES[m,n][::11]:
            work('control_proposal')
            k=(u[0],v[0])
            l=(u[1],v[1])
            hand=(k[0]//4,l[0]//4)
            if k==l or hands[hand]==quotas[hand]:
                continue
            outside=tuple(next(iter(EDGES[axis][m0][v0]))
                          for axis,(m0,v0) in enumerate(zip(p,(u,v,(),()),strict=True)))
            traces=(next(iter(TRACE[k])),next(iter(TRACE[l])))
            if (outside,traces) in checked:
                continue
            checked.add((outside,traces))
            true=tile_evaluate(outside,traces)
            raw=raw_evaluate(outside,traces)
            assert true==raw
            if true==ZERO:
                continue
            alias=tile_evaluate(outside,traces,True)
            alias_found|=alias!=true
            hands[hand]+=1
            row()
            out.append(dict(edge_boundary=outside,trace_boundary=traces,
                            witness_seam_pairs=(k,l),numerator=true,
                            false_occurrence_alias_numerator=alias))
            if hands==quotas and alias_found:
                return out
    raise AssertionError('insufficient independent nonzero or adverse controls')

def main():
    global EDGES,SITE,TRACE,TILES
    rss()
    EDGES,SITE=load_star()
    TRACE=make_trace()
    TILES=make_tiles(EDGES,SITE,TRACE)
    print('seam bins',len(TRACE),'conditional tiles',sum(map(len,TILES.values())),flush=True)
    evidence=checks()
    rss()
    out=dict(occurrences=[2,3], seam_anchors=[A0,A1], residual_anchors=[B0,B1],
        edge_denominators=[768,768,64,64], trace_denominator=4,
        common_sewn_denominator=768**2*64**2*4**2,trace_bins=len(TRACE),
        trace_nonzero_rows=sum(map(len,TRACE.values())),
        mask_pair_groups=len(TILES),conditional_tiles=sum(map(len,TILES.values())),
        retained_site_partitions=len(SITE),fixed_boundary_controls=evidence,
        limits=LIMITS,meters=dict(METERS),charged_operations=dict(WORK),peak_rss_bytes=PEAK_RSS)
    (ROOT/'result.json').write_text(json.dumps(out,indent=2)+'\n')
    print('complete',len(evidence),METERS,flush=True)

if __name__=='__main__':
    main()
