from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, combinations_with_replacement, permutations, product
from math import comb, factorial, prod
from pathlib import Path
import json, pickle, re, subprocess
import xml.etree.ElementTree as ET

BASE=Path('/tmp')
P=Path('/Users/johnroehm/.codex/worktrees/l1-original-n16-python/SK_EFT_Hawking')
prefix='publication-task3-full-science-'
def path(s): return BASE/(prefix+s)
def read(s): return json.loads(path(s).read_text())
def digest(p): return sha256(p.read_bytes()).hexdigest()
admission,child,sup,launch,once=(read(s) for s in
 ('admission.json','progress-r1.json','supervisor-r5.json','launch-r5.json','launch-once.json'))
assert admission['head']=='51e7c745eccad5e99676cdc8e4b523ad73e617b1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip()==admission['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=P,text=True)==''
assert all(digest(P/f)==h for f,h in admission['source'].items())
assert child['source']==admission['source']
assert admission['owner']=='ROOT' and admission['independent_result_review_required']
assert once['admission_sha256']==digest(path('admission.json'))=='676cd97e254988377c45a324fe3878168305e4996ca312f0a57b0e8d3cf56a66'
assert once['source_head']==launch['source_head']==admission['head']
assert once['owner_pid']!=launch['pid']==child['pid']
assert launch['child_script_sha256']==digest(path('child-r3.py'))=='d2e368b92bff05edd1bec7d29bab100093b4c7cebbb6e39d431e007c04100dc3'
assert digest(path('supervisor-r5.py'))=='548e50bf77243fdda3032f56c139303f36496aac6a819eca34b9e6c30b71d6eb'
assert launch['command'][-3:]==[str(path('child-r3.py')),str(path('admission.json')),once['admission_sha256']]
assert sup['wall_started']==launch['wall_started']<=child['wall_started']
assert sup['exit_code']==child['pytest_exit_code']==0 and child['status']=='terminal_pass'
assert sup['termination_reason'] is None and sup['cleanup_errors']==[]
assert sup['independent_result_review_required'] and not sup['full_scientific_acceptance']
limits=admission['limits']
assert 0<sup['sampled_peak_tree_rss_bytes']<=limits['rss']
assert 0<child['native_self_peak_rss_bytes']<=limits['rss']
assert sup['max_observed_threads']==limits['threads']==1
assert 0<child['wall_seconds']<=sup['wall_seconds']<=limits['wall_seconds']
cost=child['cost']
assert cost['limit']==limits['products'] and cost['storage_limit']==limits['rss']
assert cost['integer_bit_limit']==limits['integer_bits'] and cost['fixed_reserve_bytes']==128*1024**2
for observed, maximum in [('products','products'),('peak_scalar_records','scalar_records'),
                          ('peak_integer_bits','integer_bits'),('peak_payload_bytes','rss')]:
    assert type(cost[observed]) is int and 0<cost[observed]<=limits[maximum]
assert type(cost['integer_products']) is int and cost['integer_products']>0

xml=ET.parse(path('r1.xml'))
suite,=xml.findall('.//testsuite')
assert {k:suite.get(k) for k in ('tests','errors','failures','skipped')}=={
    'tests':'1','errors':'0','failures':'0','skipped':'0'}
case,=suite.findall('testcase')
assert case.get('classname')=='tests.test_original_coefficient_jets'
assert case.get('name')=='test_full_original_f60_g52_and_contacts'
assert list(case)==[]
assert admission['selector']=='tests/test_original_coefficient_jets.py::'+case.get('name')
assert f"{admission['selector']} PASSED" in path('r1.stdout').read_text()
assert path('r1.stderr').stat().st_size==0

# This is ROOT's locally created artifact. Verify its independently pinned
# digest and terminal length before unpickling with the pinned source classes.
payload=path('result-r1.pickle').read_bytes()
assert len(payload)==child['result_pickle_bytes']==14335
assert sha256(payload).hexdigest()==child['result_pickle_sha256']=='9174a93da197c46678d6d83fd2a595074b8222c5422743f1610ba4c534b98e62'
r=pickle.loads(payload)
from src.vestigial import original_coefficients as o
import src.core.formulas as f
assert Path(o.__file__).resolve()==P/'src/vestigial/original_coefficients.py'
assert Path(f.__file__).resolve()==P/'src/core/formulas.py'

def scalar(q):
    assert type(q) is o.QComplex and q.imag==0
    return q.real
def matrix(m):
    assert len(m)==6 and all(len(row)==6 for row in m)
    return tuple(tuple(scalar(q) for q in row) for row in m)
def mul(a,b): return tuple(tuple(sum(x*y for x,y in zip(row,col,strict=True))
                         for col in zip(*b,strict=True)) for row in a)
def trans(a): return tuple(zip(*a,strict=True))
def scale(a,k): return tuple(tuple(k*x for x in row) for row in a)

C=((1,0,0),(0,0,-2),(0,-2,0))
G3=((-2,0,0),(0,0,1),(0,1,0))
E=tuple(tuple(F(C[i%3][j%3]) if i//3!=j//3 else F(0) for j in range(6)) for i in range(6))
G=tuple(tuple(F(G3[i%3][j%3]) if i//3==j//3 else F(0) for j in range(6)) for i in range(6))
labels=tuple((chi,k) for chi in ('L','R') for k in ('n','b','p'))
def sphere(n):
    if n%2: return F(0)
    return F(prod(range(1,n,2)),prod(range(4,n+4,2)))
radial=tuple(sum(comb(n,k)*2**(n-k)*(-2)**k*sphere(k) for k in range(n+1)) for n in range(5))
assert radial==(1,2,5,14,42)
mu=F(45,4)*radial[2]**2
assert mu==F(1125,4)
Ex,Em=scale(E,F(45,4)),scale(E,F(12))
assert r['complete'] is True and r['edge_routes_agree'] is True
for key in ('direct_edge','auxiliary_edge'):
    edge=r[key]
    assert edge.labels==labels
    assert matrix(edge.local_pairing)==G and edge.radial_moments==radial
    assert scalar(edge.fourth_top)==mu
    assert matrix(edge.cubic_x)==Ex and matrix(edge.cubic_mixed)==Em
    assert matrix(edge.cubic_x_tests)==mul(mul(trans(G),Ex),G)
    assert matrix(edge.cubic_mixed_tests)==mul(mul(trans(G),Em),G)
aux=r['auxiliary_edge']
assert aux.minor_counts==(12,12) and aux.empty_test_counts==(30,30)
assert r['direct_edge'].attempted_wedge_pairs==7120

# Independent geometric oracle using four-bit flips and brute multisets.
sites=tuple(product(range(2),repeat=4))
axes=range(4)
i,t=0,3
def flip(site,axis):
    return tuple(v ^ (k==axis) for k,v in enumerate(site))
def plaq(site,k,l):
    return ((site,k),(flip(site,k),l),(flip(site,l),k),(site,l))
x0=sites[0]
y0=flip(x0,i)
x1,y1=flip(x0,t),flip(y0,t)
core=(x0,y0,x1,y1)
outsiders=set(sites)-set(core)
anchors=set(product(sites,axes))
geo=r['geometry']
assert geo['core']==core
assert dict(geo['anchor_translation'])=={(s,j):(flip(s,t),j) for s,j in anchors}
assert set(geo['spectator_anchors'])=={(s,i) for s in outsiders}
assert len(geo['spectator_edges'])==6
assert {(frozenset(e),frozenset(a)) for e,a in geo['spectator_edges']}=={
    (frozenset((s,flip(s,i))),frozenset(((s,i),(flip(s,i),i)))) for s in outsiders}
cases={
 'diagonal':((6,6,6,6),()), 'mixed_fg':((2,2,6,6),()), 'mixed_gf':((6,6,2,2),()),
 'temporal_x':((8,6,8,6),(x0,)), 'temporal_y':((6,8,6,8),(y0,)),
 'temporal_mixed':((8,8,8,8),(x0,y0)), 'spatial_mixed':((8,8,8,8),()),
}
assert set(geo['cases'])==set(cases)
active_counts={}
for name,(occupancy,temporal_roots) in cases.items():
    holes={s:8-d for s,d in zip(core,occupancy,strict=True)}
    profiles={}
    for site in sites:
        for plane in (*combinations(axes,2),tuple(axes)):
            profile=Counter((site,)*len(plane)+tuple(flip(site,j) for j in plane))
            if all(n<=holes.get(s,0) for s,n in profile.items()):
                profiles[len(plane),site,plane]=profile
    record=geo['cases'][name]
    assert dict(record['holes'])=={s:d for s,d in holes.items() if d}
    assert set(record['admissible_vertices'])==set(profiles)
    expected={}
    for k in range(sum(holes.values())//4+1):
        for vertices in combinations_with_replacement(profiles,k):
            if sum((profiles[v] for v in vertices),Counter())!=Counter(holes):
                continue
            counts=Counter(vertices)
            weight=F(1,prod(factorial(n) for n in counts.values()))
            coframe={(s,i) for s in sites}
            coframe.update((s,t) for root in temporal_roots for s in (root,flip(root,t)))
            curves=[]
            channels=set()
            for degree,site,plane in counts:
                assert degree==2
                coframe.update((s,j) for j in plane for s in (site,flip(site,j)))
                other=tuple(j for j in axes if j not in plane)
                channel=frozenset(((*order,*pair),plaq(site,*order)) for order in permutations(other)
                                  for pair in permutations(plane))
                channels.add(channel)
                curves.append({a for _,aa in channel for a in aa})
            assert all(len(a)==4 and a.isdisjoint(coframe) for a in curves)
            assert all(a.isdisjoint(b) for a,b in combinations(curves,2))
            expected[frozenset(counts.items())]=(weight,coframe.union(*curves),channels)
    actual={frozenset(item['multiplicities']):(item['exponential_weight'],set(item['anchors']),
                  set(map(frozenset,item['curvature_channels']))) for item in record['supports']}
    assert len(actual)==len(record['supports']) and actual==expected,name
    active_counts[name]=sorted(len(a) for _,a,_ in expected.values())
    assert r['raw_homogeneity'][name]==sum(holes.values())

# Dense ordered square trace, independent of the sparse producer loop.
def square(A,B,Tx,Ty):
    chain=A
    for M in (G,Ty,G,trans(B),G,trans(Tx),G):
        chain=mul(chain,M)
    return tuple(sum(chain[j][j] for j in ch) for ch in (range(3),range(3,6)))
tt=scale(E,F(1,8))
# Full original curvature pair has 2(delta_ac delta_bd - delta_ad delta_bc).
# Tracing over the temporal TT gives 2*(4-1)=6, with factorial still pending.
area=scale(tt,2*(4-1))
loops={'mixed_fg':square(Em,Ex,area,area),'mixed_gf':square(Ex,Em,area,area),
       'temporal_mixed':square(Ex,Ex,scale(tt,4),scale(tt,4))}
assert loops=={'mixed_fg':(3645,3645),'mixed_gf':(3645,3645),
               'temporal_mixed':(F(6075,4),F(6075,4))}
assert set(r['chirality_loops'])==set(loops)
for k,lr in loops.items():
    stored=r['chirality_loops'][k]
    assert tuple(chi for chi,_ in stored)==('L','R')
    assert tuple(scalar(z) for _,z in stored)==lr
spectator=mu**len(geo['spectator_edges'])
g2=o.Symbol('g2',())
expected_raw={k:() for k in ('diagonal','temporal_x','temporal_y')}
for k in ('mixed_fg','mixed_gf'):
    support,=geo['cases'][k]['supports']
    expected_raw[k]=(((g2,)*4, sum(loops[k])*spectator*support['exponential_weight']),)
expected_raw['temporal_mixed']=(((),sum(loops['temporal_mixed'])*spectator),)
expected_raw['spatial_mixed']=(((),spectator*mu**2),)
assert set(r['raw'])==set(expected_raw)
for k, terms in expected_raw.items():
    assert tuple((key,scalar(v)) for key,v in r['raw'][k].terms)==terms,k
assert isinstance(r['denominator'],o.Unknown) and isinstance(r['normalized'],o.Unknown)
assert 'original interacting full Z' in r['denominator'].reason
assert 'exact nonzero certificate' in r['normalized'].reason
assert r['raw_homogeneity']['mixed_fg']==r['raw_homogeneity']['mixed_gf']==16
assert r['raw_homogeneity']['temporal_mixed']==r['raw_homogeneity']['spatial_mixed']==0

print(json.dumps({
    'source_head':admission['head'],'pickle_sha256':digest(path('result-r1.pickle')),
    'pickle_bytes':len(payload),'child_pid':child['pid'],'single_test':admission['selector'],
    'pytest_seconds':suite.get('time'),'child_seconds':child['wall_seconds'],'supervisor_seconds':sup['wall_seconds'],
    'native_child_peak_rss_bytes':child['native_self_peak_rss_bytes'],
    'sampled_process_tree_rss_bytes':sup['sampled_peak_tree_rss_bytes'],'threads':sup['max_observed_threads'],
    'cost':cost,'original_wedge_pairs':r['direct_edge'].attempted_wedge_pairs,
    'active_anchor_counts':active_counts,'two_edge_routes_verified':True,
    'chirality_loops':{k:list(map(str,v)) for k,v in loops.items()},
    'raw_exact_coefficients':{k:[str(v) for _,v in terms] for k,terms in expected_raw.items()},
    'raw_homogeneity':r['raw_homogeneity'],'normalization':'UNKNOWN',
},indent=2))
