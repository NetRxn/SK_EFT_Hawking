#!/usr/bin/env bash
set -euo pipefail
scratch=$PWD
author=/private/tmp/l1-child01-tuples234.cugnpQ
mkdir -p combination-checked/run combination-checked/tuple0-branch0-pilot
for i in 0 1; do
 name="row-cap-physical-slice-dense-label-tuple0-branch-$i-reduced.pkl"
 ln -s "$author/$name" "combination-checked/$name"
done
ln -s "$author/tuple0-branch0-pilot/pilot.roster" combination-checked/tuple0-branch0-pilot/pilot.roster
cp "$author/tuple0-pair-equivalence/sum-branches-checked.py" combination-checked/run/sum-branches.py
cd combination-checked/run
TIMEFORMAT='%3R seconds'
{ time python3 -u sum-branches.py 37 > combine-37.out; } 2> "$scratch/combine-timing.out"
for file in combined-37.pkl combine-37.out; do cmp "$file" "$author/tuple0-pair-equivalence/$file"; done
printf 'PASS exact original paired constructor bytes and receipt\n'
