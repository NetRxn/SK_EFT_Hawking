#!/usr/bin/env bash
set -euo pipefail
p=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe39-inner
until test -f "$p/terminal-plan.tsv" && test -s "$p/wall-timing.tsv" &&
      test "$(wc -l < "$p/primary.tsv")" -eq 9; do sleep 5; done
python3 -B rescue-source-pins.py 39 > rescue-source-pins.out
python3 -B -u replay-all.py 39 0 1 2 3 4 5 6 7 8 > replay-timing.tsv

until test -s "$p/author-case39.tsv" && test "$(wc -l < "$p/author-case39.tsv")" -eq 10; do sleep 5; done
python3 -B freeze-inputs.py 39
for prefix in source paired inner; do
  shasum -a 256 -c "$prefix-operands.sha256" > "$prefix-operands-verify.out"
done
/usr/bin/time -p python3 -B audit.py 39 > audit.out 2> audit.time
python3 -B verify-shard-coverage.py 39 > shard-coverage.out
python3 -B ledger-metrics.py 39 > signed-ledger.tsv
