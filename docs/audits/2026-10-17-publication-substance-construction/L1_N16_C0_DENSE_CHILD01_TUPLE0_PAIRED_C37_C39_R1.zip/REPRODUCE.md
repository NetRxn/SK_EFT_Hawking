# L1 original paired cuts 37 and 39

These are two distinct original outer coordinates of group 128, descendant (0,1), tuple 0. Each is independently reviewed with its own exact pair constructor, support, inverse lifts, caps and signed term replay. The full tuple and original signed coefficient remain open.

Verify manifest.sha256 here and the numbered review-manifest.portable.sha256 files in their review directories. ROOT verified the original manifests in scratch before packaging and preserved their original manifest text. The machine-local continuity packets remain local. From each author directory run python3 sum-case<index>.py and compare every line against author-case<index>.tsv. Compare independent REVIEW.md and signed term receipts.

Restore the two frozen branch operands, full outer roster and initial signed pair scripts from L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip at 383f42e573962e8f7f41c0111c82a59a605c73ff. Verify the branch hashes before reading. From clean author/pair scratch, run sum-branches-checked.py at each recorded index, then reduce-label-frontier.py combined-<index>.pkl sum<index> and contract-reduced-label.py sum<index>. Return code 2 saves the cap. Verify the pair, reduction and cap hashes from author/<index>/outer-inputs.sha256.

From another scratch directory with the archived inner scripts and checkpoint/quotient.py, run run-primary.py with the exact outer cap as argument and capture primary.tsv. Run reduce-open.py for every refused slice listed in the frozen rescue.tsv. Use the archived three- and four-factor drivers with the exact inputs, pair and eight disjoint intervals from terminal-plan.tsv. Then run sum-shards.py for each hard term. The scratch batch wrappers reproduce these choices using the archived reference paths. Exact inputs are identified in each inner-operands.sha256. All normalized terms include the common external factor 1/(16*4^64) once.

The review scripts preserve original paths and reviewed bytes. Adapt their hardcoded prefixes in scratch copies to the restored author inputs, keeping the archived originals. Reproduce the signed independent outputs and recorded byte-lineage checks. Times describe the concurrent command work for the measured inputs.

Run coverage-retally.py with the earlier audit archive directory as argument. It retains all 48 coordinates and independent signed results for only the accepted subset. Compare output with coverage-ledger.tsv. The subtotal covers the verified rows.
