"""One unrestricted161 pilot for the accepted coupled finite-word construction.

A selected-word pilot is not a full-ensemble or physical susceptibility result.
"""
import argparse
from copy import deepcopy
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import sys
import time

ROOT = Path(__file__).resolve().parent
COLD_SECONDS = 600
WARM_SECONDS = 60


def contract_prepared(prepared, divisor, eliminate, emit):
    if len(prepared) != 15 or type(divisor) is not int or divisor <= 0:
        raise ValueError('exactly fifteen branches and a positive integer divisor required')
    total = Fraction()
    peak = 0
    for branch, (weight, table) in enumerate(prepared):
        if type(weight) is not Fraction:
            raise ValueError('branch weight must be an exact Fraction')
        if table is None:
            raw, size = 0, 0
        else:
            factors, local_divisor, exclusive = table
            if local_divisor != divisor or type(local_divisor) is not int:
                raise ValueError('local normalization differs from original divisor')
            raw, size = eliminate(deepcopy(factors), set(exclusive))
            if type(raw) is not int or type(size) is not int:
                raise ValueError('eliminator must return exact integer numerator and peak')
        value = Fraction(raw, divisor)
        total += weight * value
        peak = max(peak, size)
        emit({'branch': branch, 'weight': [weight.numerator, weight.denominator],
              'raw_numerator': raw, 'divisor': divisor,
              'coefficient': [value.numerator, value.denominator],
              'algebraically_empty': table is None, 'peak_rows': size})
    return total, peak


def emit(record):
    print(json.dumps(record, sort_keys=True), flush=True)


def verify_inputs():
    binding = json.loads((ROOT / 'source-binding.json').read_text())
    science = ROOT / 'science'
    for name, expected in binding['helper_closure'].items():
        if hashlib.sha256((science / (name + '.py')).read_bytes()).hexdigest() != expected:
            raise ValueError('scientific helper changed: ' + name)
    if hashlib.sha256((science / 'coupled.py').read_bytes()).hexdigest() != binding['rebound_evaluator_sha256']:
        raise ValueError('rebound evaluator changed')
    return binding


def timed_out(signum, frame):
    raise TimeoutError('fixed-label cold or whole-pass warm deadline exceeded')


def check_deadline(deadline):
    if time.perf_counter() >= deadline:
        raise TimeoutError('fixed-label absolute phase deadline exceeded')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--word', type=int, required=True, choices=(161,))
    args = parser.parse_args()
    signal.signal(signal.SIGALRM, timed_out)
    signal.setitimer(signal.ITIMER_REAL, COLD_SECONDS)
    start = time.perf_counter()
    cold_deadline = start + COLD_SECONDS
    try:
        binding = verify_inputs()
        science = ROOT / 'science'
        sys.path.insert(0, str(science))
        spec = importlib.util.spec_from_file_location('coupled', science / 'coupled.py')
        module = importlib.util.module_from_spec(spec)
        sys.modules['coupled'] = module
        spec.loader.exec_module(module)
        if module.AUDIT != science or (module.k2.ROW_CAP, module.k2.PAIR_CAP) != (120000, 3000000):
            raise ValueError('scientific root or cap mismatch')
        _, geometry = module.data()[args.word]
        restrictions = {}
        prepared = []
        cores = []
        for weight, core in module.branches(geometry):
            table = module.prepare(geometry, core, restrictions)
            # Keep the original Prepared.roles separately; the eliminator consumes three fields.
            prepared.append((weight, None if table is None else
                             (table.factors, table.divisor, table.exclusive)))
            cores.append({str(q): list(labels) for q, labels in sorted(core.items())})
        if len(prepared) != 15:
            raise ValueError('incomplete protected branch population')
        verify_inputs()
        check_deadline(cold_deadline)
        emit({'kind': 'pilot-preparation', 'word': args.word, 'branches': len(prepared),
              'restrictions': {str(q): labels for q, labels in restrictions.items()},
              'cores': cores, 'binding': binding, 'divisor': geometry.divisor,
              'cold_seconds': time.perf_counter() - start})
        check_deadline(cold_deadline)
        warm = time.perf_counter()
        warm_deadline = warm + WARM_SECONDS
        # Exactly one allowance covers every branch, emissions, final readback and total.
        signal.setitimer(signal.ITIMER_REAL, WARM_SECONDS)
        def emit_branch(row):
            check_deadline(warm_deadline)
            emit({'kind': 'pilot-branch', 'word': args.word, **row})
            check_deadline(warm_deadline)
        total, peak = contract_prepared(prepared, geometry.divisor,
            module.k3.eliminate_components, emit_branch)
        verify_inputs()
        check_deadline(warm_deadline)
        emit({'kind': 'pilot-complete', 'word': args.word, 'branches': 15,
              'scope': 'complete selected unrestricted161 word only; full ensemble remains open',
              'coefficient': [total.numerator, total.denominator], 'peak_rows': peak,
              'warm_seconds_before_final_emission': time.perf_counter() - warm,
              'whole_seconds_before_final_emission': time.perf_counter() - start,
              'row_cap': module.k2.ROW_CAP, 'pair_cap': module.k2.PAIR_CAP})
        check_deadline(warm_deadline)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    main()
