"""Capture one owned fixed-word child under the unchanged665-second parent cap."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PARENT_SECONDS = 665


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--word', type=int, required=True, choices=(161,))
    args = parser.parse_args()
    out = ROOT / ('unrestricted-word-' + str(args.word))
    out.mkdir(exist_ok=False)
    sources = [ROOT / 'pilot.py', ROOT / 'run_unrestricted.py', ROOT / 'source-binding.json']
    sources += sorted((ROOT / 'science').glob('*.py'))
    snapshots = out / 'consumed'
    snapshots.mkdir()
    hashes = {}
    for source in sources:
        key = source.relative_to(ROOT)
        data = source.read_bytes()
        target = snapshots / key
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        hashes[str(key)] = hashlib.sha256(data).hexdigest()
    argv = [sys.executable, '-B', str(ROOT / 'pilot.py'), '--word', str(args.word)]
    start = time.perf_counter()
    try:
        result = subprocess.run(argv, capture_output=True, timeout=PARENT_SECONDS)
        code, stdout, stderr, timeout = result.returncode, result.stdout, result.stderr, False
    except subprocess.TimeoutExpired as exc:
        code, stdout, stderr, timeout = None, exc.stdout or b'', exc.stderr or b'', True
    elapsed = time.perf_counter() - start
    (out / 'stdout').write_bytes(stdout)
    (out / 'stderr').write_bytes(stderr)
    source_unchanged = all(hashlib.sha256((ROOT / key).read_bytes()).hexdigest() == value
                           for key, value in hashes.items())
    receipt = {'argv': argv, 'word': args.word, 'exit_code': code, 'timeout': timeout,
               'parent_seconds': elapsed, 'parent_cap_seconds': PARENT_SECONDS,
               'consumed_sha256': hashes, 'source_unchanged': source_unchanged,
               'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
               'stderr_sha256': hashlib.sha256(stderr).hexdigest()}
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt, sort_keys=True), flush=True)
    # Driver success requires both a successful child and the complete exact outcome set.
    if timeout or code != 0 or stderr or not source_unchanged or elapsed >= PARENT_SECONDS:
        raise SystemExit(1)
    rows = [json.loads(line) for line in stdout.splitlines()]
    branches = [r for r in rows if r.get('kind') == 'pilot-branch']
    totals = [r for r in rows if r.get('kind') == 'pilot-complete']
    if ([r['branch'] for r in branches] != list(range(15)) or
        any(r['word'] != args.word for r in branches) or
        len(totals) != 1 or totals[0]['word'] != args.word or totals[0]['branches'] != 15):
        raise SystemExit('incomplete scientific output; no complete outcome accepted')
    print(json.dumps({'complete_selected_unrestricted_word_child': args.word,
                      'scope': 'selected unrestricted161 pilot only; independent data and coefficient acceptance remain owed'}))


if __name__ == '__main__':
    main()
