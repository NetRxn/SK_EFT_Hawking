"""Selected coupled161/163 scientific construction; scratch source, no CLI.

Only prepare and local scalar-table construction are exposed at this stage.
Full action contraction requires separate review and execution admission.
"""
from pathlib import Path
from collections import Counter, namedtuple
from itertools import product
from fractions import Fraction
import hashlib
import importlib
import json
import sys

AUDIT=Path(__file__).resolve().parent
sys.path.insert(0,str(AUDIT))
import l1_extended_offset_witness_k2 as k2
import l1_extended_offset_witness_k3 as k3
import l1_extended_offset_witness_k4 as k4
import l1_extended_offset_witness_k4_two_square as two
from l1_extended_four_face_gauge_join import IDENTITY
from l1_extended_mixed_center_gamma import COMPONENTS
from l1_extended_mixed_curvature_core import face_tensor,PAIRS
from l1_extended_overlap_strip import HAAR
from l1_extended_mixed_frame_moment import moment
from l1_extended_two_mixed_centers import remap
from l1_direct_b_haar import add

EXPECTED_WORDS=(161,163)
MANIFEST_SHA256='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b'
assert k2.ROW_CAP==120000 and k2.PAIR_CAP==3000000
Geometry=namedtuple('Geometry','index frame edges sources coupled independent linked other roles fixed forest fixed_action divisor')
Prepared=namedtuple('Prepared','factors divisor exclusive roles')

def geometry(row):
 assert row['index'] in EXPECTED_WORDS and tuple(row['axes'])==(2,2)
 frame,sources,edges,faces,protected,removed=two.base(row)
 shift=int(row['index']==163)
 edge=lambda q,a:(q^shift,a)
 face=lambda q,a,b:(q^shift,a,b)
 roles={name:edge(q,a) for name,q,a in [('H',5,2),('K',7,1),('J',9,2),('L',13,2),('M',9,3),('N',13,3)]}
 coupled=tuple(face(*f) for f in ((7,1,2),(1,2,3),(5,2,3),(9,2,3),(13,2,3)))
 independent={f:b for f,b in faces.items() if f not in coupled}
 assert len(frame)==15 and len(edges)==20 and len(removed)==6
 assert set(faces)==set(coupled)|{face(q,2,3) for q in (0,4,8,12)}
 forest=set(sources)|{edge(q,a) for q,a in ((3,1),(7,2),(1,3),(5,3))}
 parent={};vertices=set()
 def root(q):
  while q in parent:q=parent[q]
  return q
 for q,a in sorted(forest):
  y=q^(1<<a);u,v=root(q),root(y);assert u!=v;parent[u]=v;vertices.update((q,y))
 assert len(forest)==6 and len(vertices)==8 and len({root(q) for q in vertices})==2
 fixed=dict.fromkeys(forest,IDENTITY)
 fixed_action={}
 for q,a in forest:
  y=q^(1<<a);key=min(q,y),max(q,y),a
  if key in edges:
   assert len(edges[key])==1;fixed_action[key]=int(q>y)
 assert len(fixed_action)==2
 for q,a in sources:
  y=q^(1<<a);assert (min(q,y),max(q,y),a) not in edges
 protected_link=edge(0,2)
 assert set.union(*independent.values())&protected=={protected_link}
 linked=(protected_link[0],protected_link[0]^(1<<protected_link[1]))
 other=tuple(f[0] for f in sorted(independent) if f[0] not in linked)
 assert len(other)==2
 q,a=roles['K'];key=min(q,q^(1<<a)),max(q,q^(1<<a)),a
 assert edges[key]==[(5^shift,1)] and frame[5^shift].index(1)==1
 endpoints=Counter(v for q,a in sources for v in (q,q^(1<<a)))
 incoming=Counter(q^(1<<a) for q,axes in frame.items() for a in axes)
 assert all(4*(q in frame)+2*incoming[q]+2*endpoints[q]==8 for q in range(16))
 divisor=k3.witness.SCALE**43*4**64*48**10*2**15
 return Geometry(row['index'],frame,edges,sources,coupled,independent,linked,other,roles,fixed,forest,fixed_action,divisor)

def data():
 manifest,_=k4.data()
 assert hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()==MANIFEST_SHA256
 return {i:(manifest['rows'][i],geometry(manifest['rows'][i])) for i in EXPECTED_WORDS}

def component_key(q):return ('component',q)
def occurrence_key(q,e):return ('occurrence',q,e[0],e[1])

def curvature_factors(g):
 """Ten integer scalar factors; normalized by48^4*192 in g.divisor."""
 names=('square','torus1','torus5','torus9','torus13')
 incidence={}
 factors=[];descriptors=[]
 order=(('H','K'),('J',),('L','H'),('M','N','J'),('N','H','M','L'))
 for name,face,role_names in zip(names,g.coupled,order,strict=True):
  free=tuple(g.roles[r] for r in role_names)
  axes=(component_key(face[0]),)+tuple(occurrence_key(face[0],e) for e in free)
  rows={}
  for c in COMPONENTS:
   for key,weight in face_tensor(face,free,g.fixed,c).items():
    rows[(c,)+tuple(PAIRS[i] for i in key)]={0:(weight,0)}
  assert rows and len(rows)<=k2.ROW_CAP
  factors.append((axes,rows,{}));descriptors.append(('face',name))
  for role,axis in zip(role_names,axes[1:],strict=True):
   incidence.setdefault(role,[]).append(axis)
 for name in ('J','L','M','N'):
  axes=tuple(incidence[name]);assert len(axes)==2
  rows={(p,PAIRS[j]):{0:(weight,0)} for p in PAIRS for j,weight in HAAR[p]}
  assert len(rows)==92
  factors.append((axes,rows,{}));descriptors.append(('moment4',name))
 axes=tuple(incidence['H']);assert len(axes)==3
 rows={}
 for a,b,c in product(PAIRS,repeat=3):
  weight=moment(tuple(sorted(a+b+c)))
  if weight:rows[a,b,c]={0:(weight,0)}
 assert len(rows)==1520
 factors.append((axes,rows,{}));descriptors.append(('moment6','H'))
 assert len(factors)==10 and sum(len(f[1]) for f in factors)==63877
 assert len(incidence['K'])==1
 return factors,descriptors,incidence['K'][0]

def branches(g):
 result=list(k2.protected_branches(g.linked,g.other));assert len(result)==15
 for weight,core in result:
  assert set(core)=={f[0] for f in g.independent}
  yield weight,core

def prepare(g,core,restrict=None):
 """Build exact original47-factor graph, without any elimination/contraction."""
 restrict={} if restrict is None else restrict
 scalar,scalar_roles,probe_key=curvature_factors(g)
 coupled={f[0] for f in g.coupled}
 kq,ka=g.roles['K'];ky=kq^(1<<ka);live=min(kq,ky),max(kq,ky),ka
 changed=set(g.fixed_action)|{live}
 exclusive={label for e,labels in g.edges.items() if len(labels)==1 and e not in changed for label in labels}
 factors=[];descriptors=[];choices={}
 for q,axes in sorted(g.frame.items()):
  keys=tuple((q,a) for a in axes)
  domains=COMPONENTS if q in coupled else (None,)
  rows={}
  for comp in domains:
   weights=k3.witness.center_weights((comp,) if comp is not None else core.get(q))
   for gamma,weight in weights.items():
    if q in restrict and gamma!=restrict[q]:continue
    if any(gamma[j][0]!=gamma[j][1] for j,key in enumerate(keys) if key in exclusive):continue
    rows[gamma+(() if comp is None else (comp,))]={0:(weight,0)}
  if not rows:return None
  choices[q]=rows
  factors.append((keys+(() if q not in coupled else (component_key(q),)),rows,{}));descriptors.append(('center',q))
 for edge,keys in sorted(g.edges.items()):
  lo,hi,a=edge;centers=tuple(int(q==hi) for q,axis in keys)
  domains=[sorted({row[g.frame[q].index(axis)] for row in choices[q]}) for q,axis in keys]
  rows={}
  for gammas in product(*domains):
   if edge==live:
    assert len(keys)==1
    for probe in PAIRS:
     row=k3.probed_action_edge(gammas[0],centers[0],int(kq==hi),probe)
     if row:rows[gammas+(probe,)]=k3.witness.gaussian(remap(row,(lo,hi)))
   else:
    row=k3.fixed_action_edge(gammas,centers,g.fixed_action[edge]) if edge in g.fixed_action else k3.witness.local_edge(gammas,centers)
    if row:rows[gammas]=k3.witness.gaussian(remap(row,(lo,hi)))
  if not rows:return None
  degree=2*len(keys)
  factors.append((tuple(keys)+((probe_key,) if edge==live else ()),rows,{lo:degree,hi:degree}));descriptors.append(('action',edge))
 factors.extend(scalar);descriptors.extend(scalar_roles)
 for q,a in g.sources:
  y=q^(1<<a)
  row=add(*(k3.witness.anchored(0,(),None,gamma) for gamma in range(4)))
  factors.append(((),{():k3.witness.gaussian(remap(row,(q,y)))},{q:2,y:2}));descriptors.append(('source',q,a))
 assert len(factors)==47 and len(descriptors)==47
 assert {q:sum(f[2].get(q,0) for f in factors) for q in range(16)}==dict.fromkeys(range(16),8)
 assert set(Counter(key for f in factors for key in f[0]).values())=={2}
 assert max(sum(len(poly) for poly in f[1].values()) for f in factors)<=k2.ROW_CAP
 return Prepared(factors,g.divisor,exclusive,descriptors)

def source_hashes():
 names=('l1_direct_b_haar','l1_extended_four_face_gauge_join','l1_extended_mixed_center_gamma','l1_extended_mixed_curvature_core','l1_extended_mixed_frame_moment','l1_extended_offset_square','l1_extended_offset_witness','l1_extended_offset_witness_k2','l1_extended_offset_witness_k3','l1_extended_offset_witness_k4','l1_extended_offset_witness_k4_two_square','l1_extended_overlap_strip','l1_normalization_uniform_mixed_edge','l1_extended_two_mixed_centers','l1_extended_opposed_source')
 result={}
 for name in names:
  module=importlib.import_module(name);path=Path(module.__file__).resolve();assert path.parent==AUDIT
  result[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
 result['evaluator']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 return result
