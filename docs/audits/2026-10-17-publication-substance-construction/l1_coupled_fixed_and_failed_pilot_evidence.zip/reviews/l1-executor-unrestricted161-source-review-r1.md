# Independent unrestricted161 pilot source review r1

**ACCEPT the frozen source for the one authorized unrestricted161 pilot. No necessary correction found.** This is source review only; no scientific import, preparation, contraction, actual cap/runtime observation, coefficient or new coverage is accepted. It authorizes neither163 nor repeating a failed run. ROOT retains current resource admission and execution, and independent actual-data/coefficient acceptance remains owed.

First action was primary `python3 scripts/codex_continuity.py check .codex/continuity/l1-executor-unrestricted161-source-review-r1.json`, returning fresh:true/changed:[]. Read its current notebook and independent fixed-data acceptance `/private/tmp/l1-executor-fixed-data-review-r1.md`, including all30 fixed branch outcomes, exact paired-domain/weight/XOR1 acceptance and their unchanged scientific limitations. The roadmap and AGENTS/CLAUDE/WAVE/ADR-008/ADR-017/continuity authorities remain identical to the previously read source-review inputs, as confirmed by the packet. The current notebook explicitly records publication's authorization of one reviewed unchanged-cap unrestricted161 pilot. Candidate38f5396223019b1e77de684551e8ef259c6dc521 and pre-existing unrelated edits remain packet-bound; no source or notebook edits occurred.

Independently hashed the pilot and driver:

- pilot.py:66ce604d161eb1dfe958b24c7f940e48db8ba7214436c43bcc82da567781a51d
- run_unrestricted.py:fbc73961288efe5e78e942508e734589d92ab4d463c13bee38c058441a8bf06a

The original accepted fixed.py70b91d1bfb0fb85b69863d375ce1aeadd97f0fe03ff0012de8dcd301b79a0eb0 and run.pyca7eeb0d6ce8e1bbb18ae11f0a3247dd47610e6e52ca328b041e9d2675878fc8 remain unchanged. Bindingf6af1c8d238f8e3a685fbd969555799dc69d051e7a125ef39eeb6b0393b7edfb and rebound evaluatore9fda2261a1e1f7bd158c951f2472e9562c085cbd69d4e64347dc7ce16b91af2 also match. Independently rechecked all33 bound helper hashes and their bytes against the scientific-base publication checkpoint: exact matches. Scientific evaluator AST/source acceptance except its AUDIT rebinding remains the prior independent source result, not a new scientific derivation.

## Actual delta and scientific scope

Read both complete new files and inspected complete unified diffs against the frozen accepted originals. Parsed both pairs with stdlib ast and verified every non-main function AST is identical, including contract_prepared, verify_inputs, emission and deadline helpers. The complete main-function diffs contain only:

- pilot module documentation and completion-scope wording;
- choices=(161,) in BOTH child and driver;
- restrictions={} instead of the fixed-gamma restriction dictionary;
- fixed event names changed consistently to pilot event names;
- driver filenames/output directory and final scope updated for this exact pilot.

No other mathematical/control-flow change is present. The driver docstring and timeout messages still contain historical “fixed” wording; they do not alter the word choice, restrictions, timing or acceptance logic and require no scientific correction.

At pilot.py:90-101 the original data/geometry/branches/prepare flow is retained. Empty restrictions removes only fixed gamma slicing: original center_weights/peeled domains, original protected branch cores and all coupled component/occurrence-probe variables remain active. The complete47-factor graph retains15 centers,20 action factors,10 coupled scalar factors and two separate sources, with live K routing, changed fixed forest action edges, original mask/remap/wedge signs and source/action normalization inherited unchanged. No new component/probe truncation, source substitution, branch omission, chirality multiplier or cap adjustment appears.

All15 original signed Fraction weights remain direct outputs of branches(g):1/256 plus, in each chirality, -1/559872 and six matching terms weighted(2ifdiagonalelse1)/279936. The unchanged original divisor is192**43 * 4**64 * 48**10 * 2**15. contract_prepared remains exactly the reviewed implementation: each branch contributes weight*Fraction(raw,divisor), nonempty local divisors are checked, raw outputs are exact integers, and original k3.eliminate_components consumes deep-copied factors/private exclusivity. Literal original-prepare None is the only algebraic-empty shortcut; exceptions are not caught into zero. Original k2 row120000/compatible-pair3000000 guards and actual join/domain/sign semantics remain unchanged.

## Budgets, failure evidence and provenance

Pilot lines76-79 retain600seconds cold, armed before science verification/import/preparation. All15 branch preparations and preparation output remain within that phase. Lines109-127 retain ONE60second warm allowance for the whole15-branch pass, including deep copies, all eliminations/branch emissions, final input hash readback and final total emission; absolute deadline checks remain around emissions and after final output. There is no per-branch reset or cache shortcut. The finally block only disarms the timer; exceptions propagate.

run_unrestricted.py retains665seconds for the whole child and captures original stdout/stderr/exit/source hashes. Its source snapshots now correctly name pilot.py and run_unrestricted.py; argv launches that child with -B and word161. All36 science sources are included, yielding39 consumed source/binding files. source-binding verifies every bound helper and the evaluator before import, after preparation and after contraction. Science-path construction is unchanged from accepted fixed source; actual loaded-module provenance remains an execution/data-review question, not a claim established by this static inspection.

The output directory uses mkdir(exist_ok=False), preserving one run's evidence against silent overwrite. There is no internal retry or163 path. A scientific exception, timeout, source drift, stderr/nonzero exit or overlong parent refuses success. The driver still requires branches0through14 exactly once, the requested word and exactly one15-branch completion. A completion-looking raw line before a final emission/deadline failure does not become accepted output: the nonzero child status is refused. Partial branches and receipts remain failed/incomplete evidence, not totals or fallback zero.

## Scope and census correction

No new fixture or scientific test was run for this delta review. Executed operations were the required continuity check and stdlib-only AST/hash/text/file comparisons. No scientific module import, preparation, contraction, Git, build, process/slot/configuration/harness probe or source edit occurred. Only this report and the expressly requested census erratum were written.

The prior source report's34-file science census was incorrect. Independently confirmed36 files:33 bound helpers, coupled.py and two unreferenced original input copies l1_full_action_reference.py/l1_ward_witness.py. Both extras match original/inputs/ bytes and have no text/import reference anywhere in the copied science sources. Separate `/private/tmp/l1-executor-fixed-source-review-r1-erratum.md` preserves that correction without modifying the frozen original report. This changes no mathematical/source or fixed-data acceptance.

Actual unrestricted161 data, intermediate support/runtime feasibility, independent coefficient reconstruction/replay and any broader population/main/publication acceptance remain unverified. Coverage remains236/272. Full k4, derivative-normalized full source/action ensemble, commonZ, physicalB3/window, modes/matter/transport and Lean remain open. A genuine intermediate cap failure must return to reviewed mathematical factorization, not changed caps, omitted channels or a repeated unauthorized attempt.
