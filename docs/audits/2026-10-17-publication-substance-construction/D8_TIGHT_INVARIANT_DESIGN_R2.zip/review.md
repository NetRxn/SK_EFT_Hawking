# D8 tighter loop-invariant design independent review

**ACCEPT the mathematical design. REVISE one source line before kernel
intake.** The exact unelaborated patch has SHA256
`e25d252e6c17370adea9872f5a5a1f91f7382c918a241c08e79db8cdaed1d6ae`.
It applies cleanly on the unchanged draft
`3bfc51622b6b246ce31662403888cd06a93f6dc8`. Intake and terminal
continuity matched. This was a read-only source review.

## Required amendment

At the last step of the `h_conv` calculation, the current patch invokes
`linarith [K_compose_sqrt_two_ε₀_lt_one]`. The imported theorem on line 135
of `SolovayKitaevRecursion.lean` bounds the expression with `Real.sqrt`.
The goal uses `Real.rpow`. The same module already exports the exact
power-form bound at line 527. Reuse it directly:

```lean
      _ ≤ 1 := K_compose_rpow_two_ε₀_le_half.trans (by norm_num)
```

Update the generalized declaration's adjacent docstring to name its
positive variable starting budget and upper bound, since the existing
docstring still describes the fixed two-epsilon case.

## Mathematical and API audit

For a starting budget `a` in `(0, 2 * ε₀]`, the existing
`Real.rpow_le_rpow` and positivity of `K_compose` imply
`K_compose * a ^ (1/2) ≤ K_compose * (2 * ε₀) ^ (1/2) ≤ 1/2`.
The weaker upper bound one suffices for the actual
`EpsilonSeq.ε_seq_le_ε_zero` API, and the resulting per-level bound
feeds the same `2 * ε₀` outer numerical estimates in the original
geometric induction. The `ε_seq_nonneg` application supplies the
other per-level premise. The base case is the existing zero-depth
unfolding and the strict base finder bound, weakened to ≤.

Compared the 696 lines starting with `have h_V_n_bound` up to the
new compatibility wrapper. They are byte-identical with SHA256
`8a0ad5681bae0c6ec42848f8c5b2c61575aac8c63c36776e91a126d3f355abc3`.
The old public theorem header is also byte-identical. Its new wrapper
specializes the generalized proof at `2 * ε₀`, preserving the
original result type and call sites. The existing `CliffordTCompiler`
imports expose the generic discharge through both dependencies.
The strict `cliffordTBaseFinder_constructive_approx_opNorm` is
definitionally the required base finder predicate at `ε₀`.
The Clifford+T instance uses the same recursion and constructive
base finder as the manuscript.

The current generic SU(2) proof and corresponding Clifford+T invariant
start at `2 * ε₀`. The SU(d) results use a different recursion and budget
and are not direct substitutes. The scoped source and signature search
did not find an already exposed theorem for this exact compiler and
starting budget. No built LSP/type query was attempted because the
assignment reserves all slots for active work.

## Delivery boundary

No kernel or build check was performed. The amended patch needs
authoritative elaboration and axiom checks. The downstream manuscript
proof reference and registry should use the new tighter declaration
after acceptance. The current manuscript formula is the closed form of
this new sequence at `ε₀`; the existing `ε_seq_closed_form` supplies
that conversion. The public compiler depth, actual word, and length
bounds are separate and retain their existing proof interfaces.
