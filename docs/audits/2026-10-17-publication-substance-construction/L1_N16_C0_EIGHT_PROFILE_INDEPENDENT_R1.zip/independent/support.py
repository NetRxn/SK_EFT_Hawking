import ast
from collections import Counter,defaultdict
from math import prod
from itertools import product
from pathlib import Path
from functools import cache
import sys

root=Path('INDEPENDENT')
sys.path.insert(0,str(root.absolute()))
from census import profile,occupancy
proj=ast.parse((root/'project.py').read_text())
parts=[p for p in proj.body if isinstance(p,(ast.FunctionDef,ast.Import,ast.ImportFrom))]
scope={}
exec(compile(ast.Module(body=parts,type_ignores=[]),'project.py','exec'),scope)

@cache
def coupling(values):
    reachable={0}
    for n in values:
        reachable={j for t in reachable for j in range(abs(t-n),t+n+1,2)}
    return 0 in reachable

@cache
def spatial(labels,loads):
    parity=sum(p+q for p,q in labels)&1
    if any((n&1)!=parity for n in loads):return False
    costs=tuple(sum(abs(a-b) for a,b in zip(labels[z],labels[z+1])) for z in (0,2))
    return sum(costs)<=min(loads) and (min(loads)!=0 or not any(costs))

def anchors(path):
    return [tuple(map(int,l.split())) for l in path.open()]
def state_rows(path,plan):
    cases={c:[] for c,*_ in plan}
    for l in path.open():
        i,*r=map(int,l.split())
        cases[i].append(tuple(r))
    for r in cases.values():assert len(r)==len(set(r))
    return {k:tuple(sorted(s)) for k,s in cases.items()}

def verify(a,b,w,out):
    G,forced,domain=scope['projection'](a,b,2)
    labels=list(sorted(domain))
    index={r:i for i,r in enumerate(labels)}
    space=[]
    loads=[profile(code)[2] for code in (a,b)]
    edges=sorted(set(G[0])|set(G[1]))
    for u,v,k in edges:
        local=tuple(sum(L.get((u,v,k),(0,0))) for L in loads)
        idx=tuple(index[t,x,k] for x in (u,v) for t in (0,1))
        space.append((idx,local))
    times=[tuple(i for i,(s,y,k) in enumerate(labels) if t==s and x in (y,y^(1<<k)))
           for t,x in product(range(2),range(8))]
    dimensions=[domain[k] for k in labels]
    scans=prod(map(len,dimensions))
    assert scans<=8_000_000
    allowed=set()
    for s in product(*dimensions):
        for i in times:
            both=zip(*(s[j] for j in i))
            if not all(coupling(tuple(sorted(x))) for x in both):break
        else:
            if all(spatial(tuple(s[j] for j in i),n) for i,n in space):
                allowed.add(tuple((*k,*q) for k,q in zip(labels,s) if any(q)))
    path=Path('AUTHOR')/f'{a}-{b}'
    orig_plan=anchors(path/'all-anchor-plan.tsv')
    part_plan=anchors(path/'anchor-plan.tsv')
    orig=state_rows(path/'all-states.tsv',orig_plan)
    part=state_rows(path/'states.tsv',part_plan)
    assert set(orig.values())==allowed and len(orig)==len(allowed)==4
    assert all(orig[k]==v for k,v in part.items())
    lookup={j:k for k,j in orig.items()}
    exchange={k:lookup[tuple((t,y,c,q,p) for t,y,c,p,q in st)] for k,st in orig.items()}
    assert all(exchange[exchange[x]]==x for x in orig)
    assert set(part)=={x for x in orig if x<=exchange[x]}
    def plans(data):
        for case,state in sorted(data.items()):
            st={(t,x,k):(p,q) for t,x,k,p,q in state}
            for t in (0,1):
                for u,v,k in sorted((u,u^(1<<k),k) for u,k in product(range(8),range(3)) if not u>>k&1):
                    d=sum(loads[t].get((u,v,k),(0,0)))
                    for x in (u,v):
                        yield case,t,x,k,d,*st.get((t,x,k),(0,0)),*st.get((1-t,x,k),(0,0))
    assert sorted(plans(orig))==sorted(orig_plan)
    assert sorted(plans(part))==sorted(part_plan)
    for i,st in sorted(part.items()):
        kind='scalar-fixed' if not st else 'other-fixed' if exchange[i]==i else 'paired'
        print(a,b,w,i,exchange[i],1 if exchange[i]==i else 2,kind,sep='\t',file=out)
    print(a,b,'original projected tuples',scans,'full states',len(orig),
          'representatives',len(part),'fixed IDs',[j for j,x in exchange.items() if x==j],
          'anchor rows full/selected',len(orig_plan),len(part_plan))
with Path('reviewed-pairs.tsv').open('w') as out:
    for l in Path('AUTHOR/next-cases.out').open():
        verify(*map(int,l.split()),out)
