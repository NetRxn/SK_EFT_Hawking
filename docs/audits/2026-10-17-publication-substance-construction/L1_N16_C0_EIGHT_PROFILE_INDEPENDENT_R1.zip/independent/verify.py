from fractions import Fraction as F
from collections import Counter,defaultdict
from pathlib import Path
from math import prod

author=Path('AUTHOR')
residual=[tuple(map(int,l.split())) for l in Path('residual.tsv').read_text().splitlines()]
assert len(residual)==len(set(residual))==9639 and sum(w for a,b,w in residual)==830439
values={}
for l in (author/'author-exact.tsv').read_text().splitlines()[1:]:
    a,b,w,coef,inc=l.split()
    key=(int(a),int(b),int(w))
    assert key not in values and key in residual
    assert sum(r[:2]==key[:2] for r in residual)==1
    assert key[2]==96 and F(inc)==F(coef)*key[2]
    values[key]=F(coef)
assert len(values)==8 and sum(r[2] for r in values)==768
pre={}
for l in (author/'batch-before-scalar.out').read_text().splitlines():
    if l.startswith('COMPLETE AUTHOR PROFILE '):
        a,b,w,coef=l.split()[3:]
        pre[int(a),int(b),int(w)]=F(coef)
assert len(pre)==7
multiplicity=defaultdict(dict)
for l in Path('reviewed-pairs.tsv').read_text().splitlines():
    a,b,w,i,j,m,kind=l.split()
    k=(int(a),int(b),int(w))
    multiplicity[k][int(i)]=(int(j),int(m),kind)
assert set(multiplicity)==set(values)
assert sum(len(r) for r in multiplicity.values())==18
fixed={key for key,rows in multiplicity.items()
       if any(kind=='scalar-fixed' for _,_,kind in rows.values())}
assert fixed=={(139627958850,8960527077529,96),(164324020825,8935831015554,96)}
scalar={}
for l in Path('scalar-direct.out').open():
    a,b,x,y,_,__,___,z=l.split()
    assert F(x)*F(y)==F(z)
    scalar[int(a),int(b),96]=F(z)
assert set(scalar)==fixed
result={}
signed=[]
stats=[]
counts=Counter()
geometry={}
n_joins=[]
for key in values:
    k=f'{key[0]}-{key[1]}'
    history={}
    expect=multiplicity[key]
    for row in Path(f'cases-{k}.out').read_text().splitlines():
        p=row.split()
        if p[0]=='case':
            j,n,wi,m=map(int,(p[1],p[3],p[5],p[8]))
            frozen=(author/k/f'case-{j:03}.out').read_text().splitlines()
            head=frozen[0].split()
            assert n==88 and (j,n,wi,m)==tuple(map(int,(head[1],head[4],head[6],head[9])))
            geometry[key,j]=(wi,m)
            q=frozen[-1].split()
            if q[:2]==['EXACT','ZERO']:target=F(0)
            else:
                assert q[:3]==['EXACT','channel',str(j)] and F(q[4])==0
                target=F(q[3])
        elif p[0]=='EXACT':
            assert int(p[1])==j and j not in history
            amount=F(p[2])
            assert amount==target
            history[j]=amount
            counts[(amount>0)-(amount<0)]+=1
        elif p[0]=='stats':
            stats.append(tuple(map(int,(p[4],p[7],p[9],p[11]))))
        elif p[0]=='join':
            n_joins.append(tuple(map(int,(p[2],p[3],p[5]))))
    assert set(history)==set(expect)
    assert sum(m for j,m,k0 in expect.values())==4
    s=F(0)
    for j,amount in sorted(history.items()):
        partner,m,kind=expect[j]
        if kind=='scalar-fixed':
            assert key in scalar and j==partner==0 and amount==scalar[key] and m==1
        if kind=='other-fixed':
            assert key in fixed and j==partner==2 and m==1
        s+=m*amount
        signed.append((*key,j,partner,m,kind,amount))
    assert s==values[key] and s>0
    result[key]=s
    if key in pre:
        delta=scalar[key] if key in scalar else F(0)
        assert s-pre[key]==delta
        print(*key,'signed',s,'weighted',s*key[2],'old log correction',delta)
    else:print(*key,'signed',s,'weighted',s*key[2])
assert counts=={0:5,1:11,-1:2}
print('represented signed values',dict(counts),'max initial rows',max(m for w,m in geometry.values()))
print('max nonzero factor/join/cumulative/charged scans',*[max(x) for x in zip(*stats)])
print('max join/retained/cumulative all paths',*[max(x) for x in zip(*n_joins)])
total=sum(key[2]*v for key,v in result.items())
print('combined exact increment',total)
left=[r for r in residual if r not in result]
assert len(left)==9631 and sum(w for a,b,w in left)==829671
print('residual after exactly eight accepted rows',len(left),sum(w for a,b,w in left))
Path('reviewed-exact.tsv').write_text(''.join('\t'.join(map(str,(*key,v)))+'\n' for key,v in result.items()))
Path('signed-pairs.tsv').write_text(''.join('\t'.join(map(str,r))+'\n' for r in signed))
