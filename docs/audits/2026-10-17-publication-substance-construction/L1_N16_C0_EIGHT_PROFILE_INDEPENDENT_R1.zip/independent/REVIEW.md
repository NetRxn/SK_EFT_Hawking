# Independent review of eight small-support N16 profiles

**ACCEPT** the eight original representatives in `reviewed-exact.tsv`,
each at weight 96. All eight complete coefficients are positive.
The 768 newly resolved labels give the signed weighted increment
`67614204477797306168258385024402541185/9903520314283042199192993792`.
Removing exactly these eight rows leaves **9,631 unresolved orbits
and 829,671 labels**. This receipt leaves full original c0 open.

The primary continuity snapshot checked fresh at both boundaries.
The pinned checkpoint `1c575ab0ce6b8c86ba689c209b13cfb3a8bf21dd` was
clean and matched its tracked upstream. The frozen archive manifests
match the checked-in evidence and the approved predecessor residual.
I verified all 116 author archive entries, all eight local-factor
manifests and the two extra scalar-factor manifests. I also verified
the prior 38-file review manifest and accepted 44-file residual
manifest. The exact block extracted from the prior archive equals
the supplied residual byte-for-byte. All eight current representatives
occur uniquely at their original weight and are disjoint from earlier
accepted rows.

## Original support including the chirality fixed assignments

Independent original occupation decoding and all exact local
representation constraints recover four states per profile. I
enumerated 1,507,328 projected local tuples across the eight
profiles, testing the independent temporal singlets, spatial
minimum load and zero-load equalities, and the corrected joint
center parity. The complete 1,536 original anchor-plan rows and
864 represented anchor-plan rows agree. The eight spatial cubes
keep explicit zero-load anchor rows as part of the original
incidence. An all-scalar assignment is therefore an anchor-plan
ID with an empty sparse nontrivial-state roster.

The same source gamma3 exchange swaps the chirality labels without
altering the original anchors, Haar law or filled site tops. Every
original occupation has 32 EHC insertions, so their combined sign
under the exchange is positive. Each two-member orbit of the
exchange contributes twice its independently computed value.
Each fixed assignment contributes once.

Six profiles have two two-member orbits. In each of
`(139627958850,8960527077529)` and
`(164324020825,8935831015554)`, assignments 0 and 2 are individually
fixed. Assignment 0 is all scalar and has no sparse rows.
Assignment 2 is the nontrivial fixed state. Assignments 1 and 3
are exchanged. Both fixed assignments have multiplicity one in
each profile. This gives 18 independently computed representatives
covering all 32 supported states across the batch.

### Independent correction of the two initially incomplete sums

Both all-scalar channels were replayed from the separate frozen
signed site factors. I independently evaluated each one a second
way using the earlier ordinary normalized layer contractions.
Each occupation in these two profiles has 16 quadratic roots.
The sixteen factors of 2 from normalized scalar curvature moments
cancel the sixteen original 2! divisors. The independent product
of the two original scalar spatial layers therefore gives the
same channel value with no extra normalization.

| Original profile | Scalar fixed ID 0, counted once | Nontrivial fixed ID 2, counted once |
| --- | --- | --- |
| (139627958850,8960527077529) | 63688619845806271785/2199023255552 | 39089232645460417186875/151115727451828646838272 |
| (164324020825,8935831015554) | 92705155107367908825/2199023255552 | -4724115820080382115325/2305843009213693952 |

Each revised full coefficient differs from its old incomplete log
by exactly the corresponding scalar ID 0 value, once. The old
receipts used an incomplete sparse roster and therefore omit
these terms. The other preserved old values agree. The exchanged
ID 1 in the first fixed-point profile is negative and was counted
twice. The negative fixed ID 2 in the second was counted once.
The five zero represented terms stay zero.

## Normalization and local factor scope

The canonical original source reproduces all 512 stripped
coframe coefficients and checks all 768 ordered EHC coefficients
against the folded time-first arrangement. The four equivalent
orderings cancel the explicit action prefactor 1/4. Each of 32
EHC insertions contributes two coframes. Each raw coframe table
strips one quarter, so the source coefficient has 4⁻⁶⁴.
The original occupation factorials range among 2,304, 20,736,
65,536 and 186,624 as detailed in `normalization.out). None
is taken from a projected or quotient occupancy. The world
epsilon signs and cross-site wedge parities are positive for
both layers of all eight profiles. The latter agrees with
64 literal generator layouts per layer and profile. Actual
site masks retain their local Grassmann signs.

The independent factor checks cover:

- The common root table shared by all eight profiles. The literal
  source reconstructs all 1,718 nonzeros out of 4,920 candidates.
- All archived temporal and spatial anchor moments. There are
  3,340 checked temporal entries, including 516 nonzeros, and
  84,458 spatial entries, including 5,444 nonzeros.
- Full exact proportional-edge reconstruction. The two endpoint
  alias preimage maps, including Gaussian gains, recreate all
  874,826 unsqueezed signed rows across 186 profile-specific
  edge tables. Every pair of endpoint preimages preserves the
  original remaining matrix indices. The reconstruction is
  disjoint and exhaustive. Direct literal signed controls
  additionally check 228 raw targets across those edge tables,
  including imaginary targets where present. The largest
  prospective direct raw target has 1,048,576 products. I
  did not regenerate all production raw edge tables.
- The complete split site factors, including both extra scalar
  directories. The independent assembler restores exact original
  root words and matrices, endpoint masks, all signed wedge
  inversions and the precise Gaussian alias gains. Contracting
  the mask and root halves over the three original words
  reproduces the unsplit site constraint. All 576 factors,
  with 764,500 mask rows and 107,602 root rows, match. Peak
  site trial and root product counts are 27,648 and 9,792.
  Maximum mask/root rows per factor are 10,752 and 1,632.

## Signed replay and per-profile receipt

The reviewer independently builds the 18 original 88-factor
networks, including both scalar-fixed networks with their
original case ID 0. Every nontrivial wire has two occurrences.
The independent tuple-key quotient uses the full common wire
tuple, primitive Gaussian coefficients and exact accumulation
on the peer, preserving every other boundary and the original
factor denominators. Prospective join work and integer height
bounds, site candidate bounds and sparse row limits were
applied. All 18 exact values match their frozen individual
receipts, including all zero certificates. The complete
represented table has 11 positive, two negative and five zero
values. See `signed-pairs.tsv` for their exact original
multiplicities. The largest initial network has 78,071 rows,
largest numerical join 7,424 products, largest cumulative
numerical path 78,456 products, and largest charged nonzero
scan tally 35,427,496.

| Original pair | Source-normalized coefficient |
| --- | --- |
| (103607566400,9912822792210) | 4981785870330086965576171875/316912650057057350374175801344 |
| (139627958850,8960527077529) | 4376648210658180399266448280635/151115727451828646838272 |
| (164324020825,8935831015554) | 97203676606043331981967875/2305843009213693952 |
| (225741963330,2233391382560) | 14165124661938687317138671875/1267650600228229401496703205376 |
| (240774348889,2218358997010) | 2489225905152239851318359375/1267650600228229401496703205376 |
| (558347329670,27012293481030) | 2467898594192618165836558125/79228162514264337593543950336 |
| (558347845640,22684023153285) | 9936232569677352536412890625/633825300114114700748351602688 |
| (563717865480,5087541354949) | 637135830072864459137109375/316912650057057350374175801344 |

Each accepted row subtracts one original orbit and 96 labels
exactly once. The per-profile weighted contributions and old
log corrections are recorded in `verification.out`.
The execution bounds exclude cold raw-edge preparation.
No repository, manuscript, or Lean state changed.

## Replay

Scratch uses `AUTHOR` for the frozen intake, `RAW` for the
original factor directories and two additional scalar-fixed
subdirectories, `INDEPENDENT` for the prior projection inputs,
`CHAIN` for the preceding accepted ordinary scalar-layer
checker, and `prior-coframes.tsv` for the original stripped
source export. `ROOT.tsv` is the common root table.
`residual.tsv` is the accepted fourth scale-up archive's exact
`block-remaining.tsv`. Use clean candidate `51e7c745e`.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 support.py > support.out
while read -r a b w; do
  k="$a-$b"
  PYTHONDONTWRITEBYTECODE=1 python3 replay.py "$k" > "cases-$k.out"
  sh factors.sh "$k"
done < AUTHOR/next-cases.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" root-rebuild.py > root-rebuild.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" normalization.py > normalization.out
PYTHONDONTWRITEBYTECODE=1 python3 scalar-direct.py > scalar-direct.out
python3 verify.py > verification.out
python3 coverage.py > coverage.out
shasum -a 256 -c manifest.sha256
```
