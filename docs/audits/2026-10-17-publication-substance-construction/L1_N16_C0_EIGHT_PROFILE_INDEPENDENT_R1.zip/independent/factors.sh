set -eu
for k in "$@"; do
  PYTHONDONTWRITEBYTECODE=1 python3 edge-reconstruct.py "$k" > "edge-$k.out"
  PYTHONDONTWRITEBYTECODE=1 python3 site-reconstruct.py "$k" > "site-$k.out"
  PYTHONDONTWRITEBYTECODE=1 python3 edge-control.py "$k" > "literal-$k.out"
done
