# L1 eight-profile independent acceptance

Check the archive manifest and run
`python3 check-residual.py independent/reviewed-exact.tsv`.
The script uses the fourth accepted residual and subtracts the eight reviewed
original weight-96 rows exactly once. The independent report documents the
signed replay, chirality-fixed assignments and rebuilt factor coverage.

This checkpoint covers eight more original coefficients. Full c0 and
physical B3 remain open.
