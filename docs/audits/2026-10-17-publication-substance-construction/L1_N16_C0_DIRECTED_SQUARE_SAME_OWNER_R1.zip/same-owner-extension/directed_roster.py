"""Extract the pilot's existing acceptance class from the frozen residual."""
import ast
import json
from pathlib import Path
import sys

prior=Path(__file__).resolve().parents[1]/"INDEPENDENT"
sys.path.insert(0,str(prior))
from census import occupancy,profile,read

p=ast.parse((prior/"project.py").read_text())
p.body=[node for node in p.body if not (
    isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('previous','todo')
                                        for t in node.targets))]
scope={"__name__":"frozen_projection"}
exec(compile(p,str(prior/"project.py"),"exec"),scope)
projection=scope["projection"]

residual=[tuple(map(int,row)) for row in read(prior/"block-remaining.tsv")]
assert (len(residual),sum(row[2] for row in residual))==(10458,903819)
selected=[]
for a,b,weight in residual:
    if any(n%2 for row in occupancy(a)+occupancy(b) for n in row):
        continue
    graph,forced,domains=projection(a,b,2)
    own=[i for i,g in enumerate(graph) if g]
    if len(own)!=1:
        continue
    side,=own
    core=graph[side]
    if len(core)!=4 or any(sorted(pair)!=[0,2] for pair in core.values()):
        continue
    roots={u if x else v:v if x else u for (u,v,k),(x,y) in core.items()}
    if len(roots)!=4 or roots.keys()!=set(roots.values()):
        continue
    start=min(roots)
    cycle=[start,roots[start]]
    for _ in range(2):cycle.append(roots[cycle[-1]])
    if len(set(cycle))!=4 or roots[cycle[-1]]!=start:
        continue
    edges=[profile(x)[2] for x in (a,b)]
    if not all(sorted(edges[side].get(e,()))in ([0,2],[0,4]) and sorted(edges[1-side].get(e,())) in ([0,2],[0,4]) for e in core):
        continue
    if any(sorted(v) not in ([0,2],[0,4],[2,2]) for layer in edges for v in layer.values()):
        continue
    if side != 1:
        continue
    selected.append({"ids":[a,b],"weight":weight,"root_layer":side,"cycle":cycle,
                     "forced_scalar_powers":list(forced)})
pilot=[x for x in selected if x["ids"]==[37086699520,8935831015554]]
assert len(pilot)==1 and pilot[0]["cycle"]==[0,4,6,2] and pilot[0]["weight"]==48
print(len(selected),"candidate orbits;",sum(x["weight"] for x in selected),"labels")
print("pilot:",pilot[0])
Path(__file__).with_name("directed-roster.json").write_text(json.dumps(selected,indent=2)+"\n")
