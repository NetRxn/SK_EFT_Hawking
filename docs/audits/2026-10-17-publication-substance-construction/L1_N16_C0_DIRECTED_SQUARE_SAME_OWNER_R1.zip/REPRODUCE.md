Restore the original pilot sources and independent tables from the sibling
L1_N16_C0_DIRECTED_SQUARE_PILOT_R1.zip archive. Use its REPRODUCE.md.
Put same-owner-extension in the restored author directory (the frozen path
used by the independent script). In this package's independent directory,
link INDEPENDENT to the pilot author historical INDEPENDENT directory, root.tsv
and spatial.tsv to the pilot independent tables, and frozen to the pilot author
directory. Verify both manifests and run independent/REVIEW.md's commands.
The accepted-batch-residual.tsv member equals the previous pushed batch
archive's block-remaining.tsv. The new block-remaining.tsv removes only the
42 independently accepted rows.
