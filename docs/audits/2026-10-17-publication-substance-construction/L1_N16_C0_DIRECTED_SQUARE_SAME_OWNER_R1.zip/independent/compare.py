import ast
from fractions import Fraction as F
import json
from pathlib import Path
import re

def rows(path):
    return [tuple(map(int,l.split())) for l in Path(path).read_text().splitlines()]

from collections import Counter
old=rows('INDEPENDENT/block-remaining.tsv')
pilot=(37086699520,8935831015554,48)
preceding={(int(a),int(b),int(w)) for a,b,w,_ in (l.split() for l in
    Path('prior-batch-exact.tsv').read_text().splitlines())}
assert len(preceding)==5 and pilot not in preceding
accepted={pilot}|preceding
residual=rows('accepted-batch-residual.tsv')
assert [r for r in old if r not in accepted]==residual
assert len(residual)==10452 and sum(r[2] for r in residual)==903531
prefix=Path('frozen/same-owner-extension')
roster=json.loads((prefix/'directed-additional.json').read_text())
author=[l.split() for l in (prefix/'author-results.tsv').read_text().splitlines()]
assert len(author)==len(roster)==42
def gaussian_pairs(s):
    literal=re.sub(r"Fraction\((-?\d+), (\d+)\)",r"'\1/\2'",s)
    return [tuple(map(F,pair)) for pair in ast.literal_eval(literal)]

a_channels={}
a_limits=[]
for idx,c in enumerate(roster):
    a,b=c['ids']
    key=(a,b,c['weight'])
    assert key==tuple(map(int,author[idx][:3]))
    assert key in residual and key not in accepted
    assert author[idx][-2]=='EXACT'
    out=(prefix/f'case-{idx:02}.out').read_text()
    tail=out.splitlines()[-1].split()
    assert tuple(map(int,(tail[2],tail[3],tail[5])))==key
    assert F(tail[-1])==F(author[idx][-1])
    chan=[]
    for q,r,v in re.findall(r'channel result \d (\(.*?\)) (\(.*?\)) scaled contribution (\S+)',out):
        remote,own=gaussian_pairs(f"[{q}, {r}]")
        chan.append((remote,own,F(v)))
    a_channels[key]=chan
    assert len(chan)==4
    a_limits.append((
            max(map(int,re.findall(r' site \d work (\d+)',out))),
            max(map(int,re.findall(r'populated rows (\d+)',out))),
            max(map(int,re.findall(r' matched (\d+) rows',out))),
            max(map(int,re.findall(r'triangle preflight (\d+)',out))),
            max(map(int,re.findall(r'resident input rows (\d+)',out))),
    ))
def validate(path):
    cases=[];exact={};key=None;params=[]
    for l in Path(path).read_text().splitlines():
        p=l.split()
        if l.startswith('case '):
            a,b,w,s=map(int,p[1:5])
            cycl,forced=re.fullmatch(r'(\[.*\]) (\(.*\))',' '.join(p[5:])).groups()
            cases.append(dict(ids=[a,b],weight=w,root_layer=s,cycle=ast.literal_eval(cycl),
                              forced_scalar_powers=list(ast.literal_eval(forced))))
            key=(a,b,w)
            chan=[]
        elif p[0] in ('0','1','2','3'):
            r,t=re.fullmatch(r'\d (\[.*\]) (\S+)',l).groups()
            x,y=gaussian_pairs(r)
            chan.append((x,y,F(t)))
        elif p[0]=='total':
            assert len(chan)==4 and chan==a_channels[key]
            assert key!=pilot and key in residual and key not in exact
            exact[key]=F(p[2])
            assert exact[key]==sum(t[2] for t in chan)
            assert exact[key]==F(author[len(exact)-1][-1])
        elif p[0]=='layer':
            params.append(tuple(int(p[i]) for i in (6,8,11,14)))
    assert cases==roster
    print(path,'maximum factor/work/site/initial',*[max(x) for x in zip(*params)])
    return exact
ordinary=validate('independent.out')
reverse=validate('reverse.out')
assert ordinary==reverse and len(ordinary)==42
assert sum(r[2] for r in ordinary)==3840
assert Counter(r[2] for r in ordinary)=={96:38,48:4}
assert all(v>0 for v in ordinary.values())
print("sign census",Counter((v>0)-(v<0) for v in ordinary.values()))
print("orbit weight histogram",Counter(w for _,_,w in ordinary))
left=[r for r in residual if r not in ordinary]
assert len(left)==10410 and sum(r[2] for r in left)==899691
print('frozen maxima (site / factor / join / triangle / triangle input)',*[max(x) for x in zip(*a_limits)])
print('added',len(ordinary),'orbits',sum(r[2] for r in ordinary),'labels',sum(r[2]*v for r,v in ordinary.items()))
print('residual',len(left),sum(r[2] for r in left))
Path('reviewed-exact.tsv').write_text(''.join('\t'.join(map(str,(*r,v)))+'\n' for r,v in ordinary.items()))
