import json,re,subprocess
from functools import lru_cache
from pathlib import Path

source='487a2b3a7cb9c5bd0fc7198016350520335b6010'
target='3bfc51622b6b246ce31662403888cd06a93f6dc8'
def git(*args):
    return subprocess.check_output(('git',*args),text=True)
def tree(ref):
    return {p:(meta.split()[-1]) for line in git('ls-tree','-r',ref,'lean').splitlines()
            for meta,p in [line.split('\t',1)]}
src,dst=map(tree,(source,target))
@lru_cache(None)
def contents(oid):
    return git('cat-file','blob',oid)
def imports(oid):
    # All actual project imports use the standard one-module-per-line form.
    return re.findall(r'(?m)^import (SKEFTHawking(?:\.\w+)+)\s*$',contents(oid))
def path(module):
    return 'lean/'+module.replace('.','/')+'.lean'
paths=set()
def visit(p):
    if p in paths: return
    assert p in src, p
    paths.add(p)
    for m in imports(src[p]):
        visit(path(m))
for name in ('FiniteDiracQuaternionSpecialization','FiniteGrassmannSourceGenerating'):
    visit(path('SKEFTHawking.ADW.'+name))
same=[p for p in sorted(paths) if src[p]==dst.get(p)]
added=[p for p in sorted(paths) if p not in dst]
different=[p for p in sorted(paths) if p in dst and src[p]!=dst[p]]
pins=['lean/lean-toolchain','lean/lake-manifest.json','lean/lakefile.toml']
result=dict(source=source,target=target,modules=len(paths),same=len(same),missing=added,
            conflicts=different,dependency_pins={p:src[p]==dst[p] for p in pins},
            source_blob_ids={p:src[p] for p in sorted(paths)},
            source_roots=['FiniteDiracQuaternionSpecialization','FiniteGrassmannSourceGenerating'])
Path('/tmp/publication-eq11-main-import-audit-r2.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k!='source_blob_ids'})
