from fractions import Fraction as F
import json
from src.vestigial.original_coefficients import (
    Polynomial, QComplex, Symbol, haar_polynomial, integrated_polynomial_product,
)

site = (0, 0, 0, 0)
q = Symbol("q", (site, 0, "L", 0))
q_other_coord = Symbol("q", (site, 0, "L", 1))
q_other_side = Symbol("q", (site, 0, "R", 0))
q_other_direction = Symbol("q", (site, 1, "L", 0))
q_other_site = Symbol("q", ((1, 0, 0, 0), 0, "L", 0))
h = Symbol("h", (site, 0, 0))
j = Symbol("J", (site, 0, 1))
jbar = j.conjugate()

def poly(*terms):
    return Polynomial(terms)

def expectation(symbols, value):
    return poly((symbols, value))

checks = {
    "odd term disappears and auxiliary/source powers survive": (
        poly(((q, h, h, j), QComplex(17)), ((q, q, h, h, j), QComplex(4, -8))),
        expectation((h, h, j), QComplex(1, -2))),
    "same residual merges unlike input monomials": (
        poly(((q, q, h), QComplex(4, 8)), ((q, q, q, q, h), QComplex(8, -8))),
        expectation((h,), QComplex(2, 1))),
    "same residual cancellation drops the zero": (
        poly(((q, q, h), QComplex(4, 8)), ((q, q, q, q, h), QComplex(-8, -16))),
        Polynomial()),
    "source and conjugated source remain distinct": (
        poly(((q, q, j), QComplex(4)), ((q, q, jbar), QComplex(-4))),
        poly(((j,), QComplex(1)), ((jbar,), QComplex(-1)))),
    "same chiral link groups before taking a moment": (
        expectation((q, q, q_other_coord, q_other_coord), QComplex(1)),
        Polynomial.scalar(F(1, 24))),
}
for name, other in (("chirality", q_other_side), ("direction", q_other_direction),
                    ("site", q_other_site)):
    checks[f"distinct {name} factors"] = (
        expectation((q, q, other, other), QComplex(1)), Polynomial.scalar(F(1, 16)))

results = []
for name, (original, expected) in checks.items():
    actual = haar_polynomial(original)
    assert actual == expected, (name, actual, expected)
    results.append({"check": name, "input_terms": len(original.terms),
                    "output_coefficients": [value.storage for _, value in actual.terms]})

a = expectation((q,), QComplex(1))
assert not haar_polynomial(a)
assert integrated_polynomial_product(a, a) == QComplex(F(1, 4))
results.append({"check": "shared-link contraction is not a ring map",
                "separate_factor_value": 0, "product_integral": [1, 4, 0, 1]})
print(json.dumps(results, indent=2))
