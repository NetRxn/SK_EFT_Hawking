# Publication pause Git custody

This incremental Git bundle preserves both exact local histories while
leaving the live controller and local branches in place.

- Primary ref `refs/heads/codex/publication-primary-custody-20261105`
  points to `27012c18fa374e8341e124b510abbedeedb18d29`.
- Parked wt1 ref `refs/heads/worktree-wt1` points to
  `5e76a60b9f4df1287fb7a83bbba6f6def69f0a47`.
- The prerequisite is
  `4672e9fecad14dc2223704548786bdf4a5ccdca8`, the existing
  remote primary-custody branch head. The bundle has 39 primary
  commits after that prerequisite plus the two parked wt1 commits.

A direct push of the primary head was rejected by GitHub's pre-receive
hook because `lean/lean_deps.json` in that history is 100.96 MB.
The exact commits are preserved here without editing their history.

Extract the archive, verify the checksum, and fetch the existing
remote custody branch if the prerequisite is absent. In a repository
containing that prerequisite, verify the bundle and fetch to new
recovery refs before inspecting the source.

```sh
shasum -a 256 -c combined-custody.sha256
git bundle verify PUBLICATION_PRIMARY_AND_WT1_PAUSE.bundle
git fetch PUBLICATION_PRIMARY_AND_WT1_PAUSE.bundle \
  refs/heads/codex/publication-primary-custody-20261105:refs/heads/recovered/publication-primary-pause \
  refs/heads/worktree-wt1:refs/heads/recovered/publication-wt1-pause
git rev-parse recovered/publication-primary-pause recovered/publication-wt1-pause
```

The archive preserves Git objects and branch tips. It does not carry
or authorize a lease, runtime epoch, cache, or slot restore. Use the
existing controller to reconcile those when resuming.
