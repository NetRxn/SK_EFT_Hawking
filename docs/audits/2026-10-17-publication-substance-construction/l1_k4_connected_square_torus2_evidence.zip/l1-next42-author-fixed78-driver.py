import subprocess,time,json
from pathlib import Path
start=time.perf_counter()
with open('/tmp/l1-next42-author-fixed78.out','wb') as out,open('/tmp/l1-next42-author-fixed78.err','wb') as err:
 try:
  result=subprocess.run(['/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python','-B','/tmp/l1-next42-author-fixed-runner.py','78'],stdout=out,stderr=err,timeout=665);code=result.returncode;reason='terminal'
 except subprocess.TimeoutExpired:code=124;reason='parent-wall-timeout'
r={'exit_code':code,'reason':reason,'word':78,'full_wall_seconds':time.perf_counter()-start,'preparation_limit_seconds':600,'whole15_fixed_warm_limit_seconds':60,'parent_wall_limit_seconds':665}
Path('/tmp/l1-next42-author-fixed78.exit.json').write_text(json.dumps(r,sort_keys=True)+'\n');print(json.dumps(r),flush=True)
