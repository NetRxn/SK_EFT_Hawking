from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product,combinations
from functools import cache
from math import prod
import runpy,json,hashlib,signal,time
start=time.perf_counter();signal.alarm(600)
p=Path('/tmp/l1-next42-author-source-r1.py');assert hashlib.sha256(p.read_bytes()).hexdigest()=='d5244fb68dbb9f10fd098a1b0e7f94679bfed53c43e0eb2271aed0031b64f68f'
s=runpy.run_path(str(p),run_name='independent_connected_direct');k2,k3=s['k2'],s['k3'];found=s['data']()
from l1_direct_b_haar import R,add,scale,wedge
from l1_extended_opposed_source import frame,action_frame
from l1_extended_two_mixed_centers import remap
from l1_normalization_opposed_fourth import nodes,L
from l1_extended_offset_square import cubature_edge
from l1_extended_mixed_curvature_core import face_vector,conditional
from l1_extended_mixed_center_gamma import COMPONENTS
from l1_normalization_uniform_mixed_edge import unit

def emit(kind,**kw):print(json.dumps(dict(kind=kind,**kw),sort_keys=True),flush=True)
def mul(q,r):
 a,b,c,d=q;e,f,g,h=r
 return (a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
def adj(q):return (q[0],)+tuple(-x for x in q[1:])
def hol(face,coords,ch):
 x,a,b=face;u,v,w,z=[coords[e][ch] for e in ((x,a),(x^(1<<a),b),(x^(1<<b),a),(x,b))]
 return mul(mul(adj(z),adj(w)),mul(v,u))
def vector(face,coords,label):ch,i=divmod(label,3);return hol(face,coords,ch)[1+i]
@cache
def hm(indices):
 n=Counter(indices);ans=F(1)
 for base in (0,4):
  ns=[n[i] for i in range(base,base+4)]
  if any(x%2 for x in ns):return F()
  ans*=F(prod(prod(range(1,x,2)) for x in ns),prod(range(4,4+sum(ns),2)))
 return ans
@cache
def mom(p,q):return hm(tuple(sorted(p+q)))
pairs=tuple((a,b) for a in range(8) for b in range(a,8))
@cache
def pairmatches(p):return tuple((q,mom(p,q)) for q in pairs if mom(p,q))
def tensor(face,free,fixed,labels):
 polys=[]
 for label in labels:
  ch,i=divmod(label,3);poly={}
  for js in product(range(4),repeat=len(free)):
   coords=dict(fixed);coords.update({e:(unit(j),unit(j)) for e,j in zip(free,js)})
   v=vector(face,coords,label)
   if v:poly[tuple(4*ch+j for j in js)]=v
  polys.append(poly)
 out=Counter()
 for a,u in polys[0].items():
  for b,v in polys[1].items():out[tuple(tuple(sorted(z)) for z in zip(a,b))]+=u*v
 return {k:v for k,v in out.items() if v}
def independent_integral(faces,fixed,labels,external):
 free=set.union(*faces.values())-set(fixed);factors=[((),{():external})]
 for face,edges in faces.items():
  local=tuple(sorted(free&edges));factors.append((local,tensor(face,local,fixed,labels[face])))
 while free:
  edge=min(free);inds=[i for i,f in enumerate(factors) if edge in f[0]];assert len(inds)==2
  ai,bi=inds;(aa,a),(bb,b)=factors[ai],factors[bi];factors=[f for i,f in enumerate(factors) if i not in inds]
  shared=tuple(e for e in aa if e in bb);free-=set(shared)
  ixa=[aa.index(e) for e in shared];ixb=[bb.index(e) for e in shared]
  la=[i for i,e in enumerate(aa) if e not in shared];lb=[i for i,e in enumerate(bb) if e not in shared]
  lookup=defaultdict(list)
  for key,v in b.items():lookup[tuple(key[i] for i in ixb)].append((key,v))
  out=defaultdict(F)
  for key,u in a.items():
   for opts in product(*(pairmatches(key[i]) for i in ixa)):
    js,ws=zip(*opts)
    for other,v in lookup.get(js,()):out[tuple(key[i] for i in la)+tuple(other[i] for i in lb)]+=u*v*prod(ws)
  factors.append((tuple(aa[i] for i in la)+tuple(bb[i] for i in lb),{k:v for k,v in out.items() if v}))
 assert all(not f[0] for f in factors)
 return prod(f[1].get((),0) for f in factors)

# Original outgoing frame definition versus fixed source moments; inspect all gamma polynomials.
ident=frame(0,False,unit(0),unit(0));source_ref=add(*(wedge(v,v) for v in ident));source_raw=add(*(k3.witness.anchored(0,(),None,j) for j in range(4)))
assert source_raw==scale(source_ref,192)
for j in range(4):assert k3.witness.anchored(0,(),None,j)==scale(wedge(ident[j],ident[j]),192)
for word,(row,g) in found.items():
 for q,a in g.sources:assert remap(source_raw,(q,q^(1<<a)))==scale(remap(source_ref,(q,q^(1<<a))),192)
emit('both-source-identity',per_gamma=4,remapped_sources=4,shared_source_explicit=True,raw_scale=192)

q4=(F(1,2),)*4;q4s=(F(1,2),F(-1,2),F(1,2),F(-1,2));q34=(F(3,5),F(4,5),F(),F());q34p=(F(),F(3,5),F(),F(-4,5))
samples=[(unit(i),unit(j)) for i,j in product(range(4),repeat=2)]+[(q4,q4s),(q4s,q4),(q34,q34p),(q34p,q4),(q4,tuple(-x for x in q4s))]
patterns=[((0,0),)*4,((0,0),(3,3),(0,0),(0,0)),((0,1),(0,1),(0,0),(0,0)),((1,2),(1,2),(0,0),(3,3)),((0,0),(0,0),(3,3),(3,3)),((3,4),(3,4),(3,3),(3,3)),((0,3),(0,3),(0,0),(0,0))]
for word,(row,g) in found.items():
 square=g.squares[0];live=g.lives[0];fixed=g.fixed_square[square];rows=k3.square_factor(square,live,fixed);nonzero_offdiag=0
 for left,right in samples:
  coords={**fixed,live:(left,right)};qu=left+right
  for labels in COMPONENTS:
   actual=sum(w*qu[a]*qu[b] for (c,(a,b)),w in rows.items() if c==labels)
   expected=prod(vector(square,coords,l) for l in labels)
   assert actual==expected
   assert expected==prod(face_vector(square,coords,*divmod(l,3)) for l in labels)
   nonzero_offdiag+=sum(bool(w*qu[a]*qu[b]) and a!=b for (c,(a,b)),w in rows.items() if c==labels)
 branches=list(k2.protected_branches(g.linked,g.other));joint_tests=0
 for pattern in patterns:
  labels={f:pattern[(g.linked+g.other).index(f[0])] for f in g.protected_torus}
  scalar=k2.formula(branches,{f[0]:labels[f] for f in labels})
  direct=independent_integral(g.protected_torus,{g.shared_source:(unit(0),unit(0))},labels,F(1))
  assert direct==conditional(g.protected_torus,{g.shared_source},{g.shared_source:(unit(0),unit(0))},labels)==scalar
  for sq_labels in ((0,0),(0,1),(0,3),(3,4)):
   coords={**fixed,live:(q4,q4s)};square_value=prod(vector(square,coords,l) for l in sq_labels)
   # Explicit disconnected scalar square remains inside independent closure.
   joint=independent_integral(g.protected_torus,{g.shared_source:(unit(0),unit(0))},labels,square_value)
   rowvalue=sum(w*(q4+q4s)[a]*(q4+q4s)[b] for (c,(a,b)),w in rows.items() if c==sq_labels)
   assert joint==scalar*rowvalue;joint_tests+=1
 assert nonzero_offdiag>0
 # Consistent endpoint transformations of all actual five-face holonomies with a nonidentity shared link.
 allfaces={square:set(fixed)|{live},**g.protected_torus};edges=set.union(*allfaces.values())
 coords={e:samples[16+(i%5)] for i,e in enumerate(sorted(edges))}
 gauges={0:(unit(0),unit(0))};pending=set(fixed)
 while pending:
  e=next(e for e in pending if e[0] in gauges or (e[0]^(1<<e[1])) in gauges);q,a=e;y=q^(1<<a)
  if q in gauges:gauges[y]=tuple(mul(gauges[q][ch],adj(coords[e][ch])) for ch in (0,1))
  else:gauges[q]=tuple(mul(gauges[y][ch],coords[e][ch]) for ch in (0,1))
  pending.remove(e)
 for q in range(16):gauges.setdefault(q,(q4s,q34))
 transformed={e:tuple(mul(mul(gauges[e[0]^(1<<e[1])][ch],coords[e][ch]),adj(gauges[e[0]][ch])) for ch in (0,1)) for e in edges}
 assert all(transformed[e]==(unit(0),unit(0)) for e in fixed)
 for f in allfaces:
  for ch in (0,1):assert hol(f,transformed,ch)==mul(mul(gauges[f[0]][ch],hol(f,coords,ch)),adj(gauges[f[0]][ch]))
 emit('joint-conditional-curvature',word=word,torus_patterns=len(patterns),joint_scalar_controls=joint_tests,square_samples=len(samples),square_component_pairs=len(COMPONENTS),activated_offdiag_terms=nonzero_offdiag,nonidentity_shared_forest_covariance=True,scope='Haar-coordinate independence only; Grassmann graph remains coupled')

# Full four-coframe two-center fixed action edge against original frame cubature.
labelsets=[((0,0),(0,0)),((0,1),(0,1)),((0,1),(2,3)),((1,2),(1,2)),((0,3),(1,2))]
for labels,fixed_anchor in product(labelsets,(0,1)):
 exact=k3.fixed_action_edge(labels,(0,1),fixed_anchor)
 assert scale(exact,96**2*8**4//(192**2*4**4))==cubature_edge(labels,(0,1),fixed_anchor)
emit('two-center-fixed-edge',centers=[0,1],anchors=[0,1],gamma_cases=len(labelsets),full_polynomial_equalities=2*len(labelsets))

# Independent direct cubature for action gamma pair and live quadratic probe.
# nodes has doubled q and96 measure; raw moment has192 and unit q: ratio2*2^(degree+probe degree).
rule=tuple(nodes());live_cases=0;nonzero=0
for center,physical_anchor,labels,probe in product((0,1),(0,1),((0,0),(0,1),(1,2)),((1,1),(1,2),(1,5))):
 total=[]
 for n in range(0,3,2):
  for chosen in combinations(range(2),n):
   chunks=tuple(tuple(labels[i] for i in range(2) if (i in chosen)==(a==0)) for a in (0,1))
   factors=[]
   for anchor,chunk in enumerate(chunks):
    terms=[]
    for left,right,weight in rule:
     t=action_frame(0,anchor^center,left,right)
     if center:t=[scale(remap(v,(1,0)),-1) for v in t]
     v={0:R.one}
     for j in chunk:v=wedge(v,t[j])
     coordinates=left+right;extra=coordinates[probe[0]]*coordinates[probe[1]] if anchor==physical_anchor else 1
     terms.append(scale(v,weight*extra))
    factors.append(add(*terms))
   total.append(wedge(*factors))
 direct=add(*total);exact=k3.probed_action_edge(labels,center,physical_anchor,probe)
 assert scale(exact,96**2*2**4//192**2)==direct
 live_cases+=1;nonzero+=bool(direct)
emit('opposite-center-live-probe',full_polynomial_equalities=live_cases,nonzero=nonzero,centers=[0,1],anchors=[0,1],offdiagonal_probes=[[1,2],[1,5]])
signal.alarm(0);emit('direct-controls-complete',seconds=time.perf_counter()-start,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP,unrestricted_coefficients_run=False)
