from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
import ast,json,hashlib
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
def read(stem):return [json.loads(l) for l in (P/(stem+'.out')).read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r78=read('l1-next42-author-pilot78');r80=read('l1-next42-author-full80');D=192**42*4**64*48**10*2**15
summaries={};allbranches={};supports={}
for word,rs,stem in [(78,r78,'l1-next42-author-pilot78'),(80,r80,'l1-next42-author-full80')]:
 start,prep,warm=rs[:3];last=rs[-1];branches=rs[3:-1];exitobj=json.loads((P/(stem+'.exit.json')).read_text());runner=P/(stem+'.py')
 assert exitobj['exit_code']==0 and exitobj['reason']=='terminal' and exitobj['full_wall_seconds']<665 and not (P/(stem+'.err')).read_bytes()
 assert prep['seconds']==last['preparation_seconds']<600 and last['whole15_warm_seconds']<60 and prep['restrictions']==[]
 assert prep['row_cap']==120000 and prep['pair_cap']==3000000 and prep['divisor']==last['divisor']==D and len(branches)==15 and len(prep['support_domains'])==15
 linked=(1,5) if word==78 else (0,4);other=(9,13) if word==78 else (8,12);bases=linked+other
 expected=[(F(1,256),{q:tuple((i,i) for i in range(6)) for q in bases})]
 for c in (0,1):
  indices=range(3*c,3*c+3);ds=tuple((i,i) for i in indices);expected.append((F(-1,559872),dict.fromkeys(bases,ds)))
  for pair in combinations_with_replacement(indices,2):expected.append((F(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:ds,other[1]:ds}))
 total=F();rawsum=F();zeros=0;rowcounts=[]
 for i,(v,s,(weight,domain)) in enumerate(zip(branches,prep['support_domains'],expected)):
  assert v['kind']=='exact-branch' and v['branch']==s['branch']==i and v['word']==word
  assert F(*v['weight'])==F(*s['weight'])==weight and v['divisor']==D and F(v['raw_numerator'],D)==F(*v['coefficient'])
  assert {q:tuple(tuple(p) for p in pairs) for q,pairs in s['core_domains']}==domain and not s['algebraic_empty_preparation'] and not v['algebraic_empty_preparation']
  assert len(s['center_support'])==15 and all(any(tuple(tuple(p) for p in x['labels'][:2])!=((0,0),(1,1)) for x in c['rows']) for c in s['center_support'])
  total+=weight*F(*v['coefficient']);rawsum+=weight*v['raw_numerator'];zeros+=not v['raw_numerator'];rowcounts.append({c['center']:len(c['rows']) for c in s['center_support']})
 assert rawsum.denominator==1 and rawsum.numerator==last['raw_numerator'] and total==F(*last['coefficient'])==F(230444796360321160875,8796093022208)
 assert max(v['peak_rows'] for v in branches)==last['peak_rows']==3952
 calls=[n for n in ast.walk(ast.parse(runner.read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Subscript) and isinstance(n.func.value,ast.Name) and n.func.value.id=='s' and isinstance(n.func.slice,ast.Constant) and n.func.slice.value=='prepare']
 assert len(calls)==1 and len(calls[0].args)==2 and not calls[0].keywords
 binding=json.loads((P/'l1-next42-author-binding.json').read_text())['principal_source_sha256'];assert start['principal_source_sha256']==binding and all(sha(A/f)==h for f,h in binding.items())
 assert prep['sources']==prep['fixed_sources']==[[0,2],[1,2]] and prep['fixed_action_edges']==[[[4,5,0],[[4,0],[5,0]]]]
 ind=next(x for x in json.loads((P/'l1-connected-core-review.json').read_text())['geometry'] if x['word']==word)
 assert prep['square']==ind['square'] and prep['live']==ind['live'] and prep['fixed_forest']==ind['fixed'] and prep['live_action_labels']==ind['live_action'] and prep['shared_source']==ind['shared'][0]
 assert start['source_sha256']==last['source_sha256']=='d5244fb68dbb9f10fd098a1b0e7f94679bfed53c43e0eb2271aed0031b64f68f'
 if word==80:assert last['scope']=='Complete unrestricted80 selected word; no otherword coefficient'
 summaries[word]={'coefficient':last['coefficient'],'all15_branch_arithmetic':True,'all15_nonempty_fullgamma_preparations':True,'zero_raw_branches':zeros,'peak':3952,'cold_seconds':last['preparation_seconds'],'whole15_warm_seconds':last['whole15_warm_seconds'],'parent_seconds':exitobj['full_wall_seconds'],'actual_exit':0,'runner_sha256':sha(runner),'stdout_sha256':sha(P/(stem+'.out')),'exit_sha256':sha(P/(stem+'.exit.json'))}
 allbranches[word]=branches;supports[word]=prep['support_domains']
for a,b in zip(allbranches[78],allbranches[80]):
 for key in ('branch','weight','raw_numerator','divisor','coefficient','peak_rows'):assert a[key]==b[key]
for a,b in zip(supports[78],supports[80]):
 assert {q^1:domain for q,domain in a['core_domains']}==dict(b['core_domains'])
 aa={v['center']^1:{k:x for k,x in v.items() if k!='center'} for v in a['center_support']};bb={v['center']:{k:x for k,x in v.items() if k!='center'} for v in b['center_support']};assert aa==bb
replay=json.loads((P/'l1-connected-core-review-replay78-verification.json').read_text());assert replay['actual_exit']==0 and replay['coefficient']==summaries[78]['coefficient']
g=json.loads((P/'l1-connected-core-review.json').read_text());assert g['accepted_disjoint']==230 and g['unique_connected_class']==[78,80] and set(g['unique_connected_class'])<=set(g['remaining'])
manifest=next(json.loads(l) for l in (A/'l1_k4_census.out.txt').read_text().splitlines() if json.loads(l).get('kind')=='paired-k4-census');assert all(manifest['rows'][w]['axes']==[2,2] for w in (78,80))
subtotal=F(*summaries[78]['coefficient'])+F(*summaries[80]['coefficient']);assert subtotal==F(230444796360321160875,4398046511104)
result={'verdict':'ACCEPT complete scientific connected78/80 class and independent full78 replay; portable/archive acceptance pending','words':summaries,'all30_branch_arithmetic':True,'all15_XOR1_raw_weight_divisor_coefficient_peak_covariance':True,'all15_XOR1_actual_fullgamma_center_rows_domains_covariance':True,'class_exactly':[78,80],'class_disjoint_from_accepted230':True,'same_axis_subtotal':[subtotal.numerator,subtotal.denominator],'divisor':D,'principal16_current_bindings_match':True,'independent_full78_replay':replay,'preserved78_scope_metadata_defect':r78[-1]['scope'],'portable_scope':230,'portable_archive_review':'NOT YET PERFORMED','remaining_unrestricted_words_after_scientific_class':40,'full_k4_sourceaction_commonZ_B3_modes_transport':'OPEN'}
(P/'l1-connected-core-review-class-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='independent_full78_replay'},indent=2))
