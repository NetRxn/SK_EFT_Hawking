from pathlib import Path
import subprocess,time,json
P=Path('/tmp');stem=P/'l1-connected-core-review-replay78';cmd=['/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python','-B',str(stem.with_suffix('.py'))];start=time.perf_counter()
with stem.with_suffix('.out').open('wb') as out,stem.with_suffix('.err').open('wb') as err:
 try:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=665);code=r.returncode;reason='terminal'
 except subprocess.TimeoutExpired:code=124;reason='parent-timeout'
v={'command':cmd,'actual_exit':code,'reason':reason,'actual_parent_seconds':time.perf_counter()-start,'parent_bound':665,'cold_bound':600,'whole15_warm_bound':60};stem.with_suffix('.exit.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
if code:print(stem.with_suffix('.err').read_text(),flush=True)
raise SystemExit(code)
