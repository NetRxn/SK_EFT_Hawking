import subprocess,time,json,hashlib
from pathlib import Path
script=Path('docs/audits/2026-10-17-publication-substance-construction/l1_extended_offset_witness_k4_connected_source_square_torus.py')
runs=[('census',[],30),('fixed',['--controls-only'],60),('78',['--word','78'],60)]
for tag,args,limit in runs:
 stem=Path('/tmp/l1-connected-portable-cli-'+tag); start=time.perf_counter()
 with stem.with_suffix('.out').open('w') as out,stem.with_suffix('.err').open('w') as err:
  try:
   r=subprocess.run(['/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python',str(script),*args],stdout=out,stderr=err,timeout=limit)
   code=r.returncode;reason='terminal'
  except subprocess.TimeoutExpired:
   code=124;reason='whole-process timeout'
 elapsed=time.perf_counter()-start
 receipt={'args':args,'exit_code':code,'reason':reason,'actual_parent_wall_seconds':elapsed,'whole_process_limit_seconds':limit,'source_sha256':hashlib.sha256(script.read_bytes()).hexdigest()}
 stem.with_suffix('.exit.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(tag,json.dumps(receipt),flush=True)
 assert code==0
 if tag=='78':
  row=json.loads(stem.with_suffix('.out').read_text());assert row['coefficient']==[230444796360321160875,8796093022208]
  assert row['preparation_seconds']<600 and row['whole15_warm_seconds']<60
