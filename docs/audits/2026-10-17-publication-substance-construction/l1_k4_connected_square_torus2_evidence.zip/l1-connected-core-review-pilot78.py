from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
import ast,json,hashlib
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=P/'l1-next42-author-source-r1.py';runner=P/'l1-next42-author-pilot78.py';out=P/'l1-next42-author-pilot78.out';err=P/'l1-next42-author-pilot78.err';exitpath=P/'l1-next42-author-pilot78.exit.json'
assert sha(source)=='d5244fb68dbb9f10fd098a1b0e7f94679bfed53c43e0eb2271aed0031b64f68f'
assert sha(out)=='45083f3e27eba365c41a5f024deb9921a62fc40c8ad8e0ab786a104ef05cc9b4'
assert not err.read_bytes()
records=[json.loads(l) for l in out.read_text().splitlines()];start,prep,warm=records[:3];branches=records[3:-1];last=records[-1];terminal=json.loads(exitpath.read_text())
assert [start['kind'],prep['kind'],warm['kind'],last['kind']]==['phase-start','phase-complete','phase-start','exact-word']
assert prep['phase']=='cold-unrestricted-preparation' and warm['phase']=='warm-WHOLE15-unrestricted-contraction' and prep['restrictions']==[]
assert terminal['exit_code']==0 and terminal['reason']=='terminal' and terminal['full_wall_seconds']<665
assert prep['seconds']==last['preparation_seconds']<600 and last['whole15_warm_seconds']<60
assert start['hard_limit_seconds']==600 and warm['hard_limit_seconds']==60 and terminal['parent_wall_limit_seconds']==665
assert prep['row_cap']==120000 and prep['pair_cap']==3000000
assert len(branches)==15 and all(v['kind']=='exact-branch' and v['branch']==i and v['word']==78 for i,v in enumerate(branches))
# Independently construct the canonical15 protected branch weights and domains.
bases=(1,5,9,13);expected=[(F(1,256),{q:tuple((i,i) for i in range(6)) for q in bases})]
for c in range(2):
 indices=range(3*c,3*c+3);diagonal=tuple((i,i) for i in indices)
 expected.append((F(-1,559872),dict.fromkeys(bases,diagonal)))
 for pair in combinations_with_replacement(indices,2):expected.append((F(2 if pair[0]==pair[1] else 1,279936),{1:(pair,),5:(pair,),9:diagonal,13:diagonal}))
assert len(expected)==15
D=192**42*4**64*48**10*2**15;assert prep['divisor']==last['divisor']==D
rawsum=F();total=F();zero=0;nonfixed=[]
fixed=((0,0),(1,1));supports=prep['support_domains'];assert len(supports)==15
centers=[q for q in range(16) if q!=2];rowcounts=[]
for i,(record,support,(weight,domain)) in enumerate(zip(branches,supports,expected)):
 assert record['divisor']==D and F(*record['weight'])==F(*support['weight'])==weight and support['branch']==i
 assert {q:tuple(tuple(p) for p in pairs) for q,pairs in support['core_domains']}==domain
 assert not support['algebraic_empty_preparation'] and not record['algebraic_empty_preparation']
 assert F(record['raw_numerator'],D)==F(*record['coefficient'])
 rawsum+=weight*record['raw_numerator'];total+=weight*F(*record['coefficient']);zero+=record['raw_numerator']==0
 assert [v['center'] for v in support['center_support']]==centers
 branch_counts={};beyond=[]
 for v in support['center_support']:
  q=v['center'];expected_selector='square_component' if q==0 else 'protected_torus_core' if q in domain else 'peeled'
  assert v['selector']==expected_selector and v['rows'] and all(x['weight'] for x in v['rows'])
  gamma=[tuple(tuple(p) for p in x['labels'][:2]) for x in v['rows']]
  beyond.append(any(x!=fixed for x in gamma));branch_counts[q]=len(v['rows'])
  if q==0:assert all(len(x['labels'])==3 for x in v['rows'])
  else:assert all(len(x['labels'])==2 for x in v['rows'])
 assert any(beyond);nonfixed.append(sum(beyond));rowcounts.append(branch_counts)
assert rawsum.denominator==1 and rawsum.numerator==last['raw_numerator'] and total==F(*last['coefficient'])==F(230444796360321160875,8796093022208)
assert max(v['peak_rows'] for v in branches)==last['peak_rows']==3952
# Inspect actual executed AST: no fixed restriction argument or per-branch reprepare during warm solve.
tree=ast.parse(runner.read_text());calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Subscript) and isinstance(n.func.value,ast.Name) and n.func.value.id=='s' and isinstance(n.func.slice,ast.Constant) and n.func.slice.value=='prepare']
assert len(calls)==1 and len(calls[0].args)==2 and not calls[0].keywords
assert [ast.unparse(n) for n in calls[0].args]==['g','core']
funcs={n.name:n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef)}
prepare=funcs['prepare'];assert prepare.args.args[-1].arg=='restrict' and isinstance(prepare.args.defaults[-1],ast.Constant) and prepare.args.defaults[-1].value is None
assert ast.unparse(prepare.body[0])=='restrict = {} if restrict is None else restrict'
assert any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='alarm' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value==60 for n in ast.walk(tree))
# Same independently reconstructed geometry and all principal source bindings.
g=next(x for x in json.loads((P/'l1-connected-core-review.json').read_text())['geometry'] if x['word']==78)
for key,pkey in [('square','square'),('live','live'),('fixed','fixed_forest')]:assert g[key]==prep[pkey]
assert prep['shared_source']==[1,2] and prep['sources']==prep['fixed_sources']==[[0,2],[1,2]] and prep['live_action_labels']==[[1,0]] and prep['fixed_action_edges']==[[[4,5,0],[[4,0],[5,0]]]]
binding=json.loads((P/'l1-next42-author-binding.json').read_text())['principal_source_sha256'];assert start['principal_source_sha256']==binding and len(binding)==16
assert all(sha(A/f)==h for f,h in binding.items());assert start['source_sha256']==last['source_sha256']==sha(source)
annotation=json.loads((P/'l1-next42-author-pilot78-validation.json').read_text());assert annotation['stdout_sha256']==sha(out) and annotation['executed_runner_sha256']==sha(runner) and annotation['parentexit_sha256']==sha(exitpath)
assert last['scope']=='COMPLETE unrestricted78 ONLY; unrestricted coefficient NOTRUN'
result={'verdict':'ACCEPT complete unrestricted78 pilot receipt; copied NOTRUN suffix is contradicted by actual runner/preparation/branch evidence and retained as annotated metadata defect','scope':'stdlib receipt arithmetic and AST inspection only; no scientific imports or replay','word':78,'all15_independent_weights_domains_raw_divisor_equalities':True,'all15_preparations_nonempty':True,'computed_zero_branches':zero,'nonfixed_gamma_centers_per_branch':nonfixed,'recorded_center_row_counts':rowcounts,'actual_prepare_call_positional_args':2,'actual_prepare_call_keyword_args':0,'actual_restrictions':[],'warm_reuses_prepared_factors':True,'both_sources_and_action_labels_verified':True,'coefficient':last['coefficient'],'raw_numerator':last['raw_numerator'],'divisor':D,'peak':3952,'cold_seconds':prep['seconds'],'whole15_warm_seconds':last['whole15_warm_seconds'],'actual_parent_seconds':terminal['full_wall_seconds'],'actual_exit':0,'principal16_hashes_match':True,'original_scope_label':last['scope'],'author_annotation_hashes_match_originals':True,'source_sha256':sha(source),'executed_runner_sha256':sha(runner),'stdout_sha256':sha(out),'exit_sha256':sha(exitpath),'portable_scope':230,'word80_unrestricted':'NOT RUN','independent_full_replay':'NOT RUN and not authorized'}
(P/'l1-connected-core-review-pilot78-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='recorded_center_row_counts'},indent=2))
