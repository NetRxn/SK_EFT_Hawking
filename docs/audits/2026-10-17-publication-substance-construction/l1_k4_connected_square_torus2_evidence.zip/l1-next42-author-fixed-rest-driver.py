import subprocess,json,time
from pathlib import Path
start=time.perf_counter();completed=[]
for word in (78,80):
 print(json.dumps({'kind':'launch-fixed-word','word':word}),flush=True)
 result=subprocess.run(['python3',f'/tmp/l1-next42-author-fixed{word}-driver.py'],check=False)
 receipt=json.loads(Path(f'/tmp/l1-next42-author-fixed{word}.exit.json').read_text())
 if result.returncode or receipt['exit_code']:
  r={'exit_code':receipt['exit_code'] or result.returncode,'completed_words':completed,'failed_word':word,'full_wall_seconds':time.perf_counter()-start}
  Path('/tmp/l1-next42-author-fixed-rest.exit.json').write_text(json.dumps(r,sort_keys=True)+'\n');print(json.dumps(r),flush=True);raise SystemExit(1)
 completed.append(word)
r={'exit_code':0,'completed_words':completed,'full_wall_seconds':time.perf_counter()-start}
Path('/tmp/l1-next42-author-fixed-rest.exit.json').write_text(json.dumps(r,sort_keys=True)+'\n');print(json.dumps(r),flush=True)
