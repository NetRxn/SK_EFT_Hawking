from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from itertools import product
from functools import cache
import sys,runpy,json,signal,time,hashlib
word=int(sys.argv[1]);began=time.perf_counter();signal.alarm(600)
source=Path('/tmp/l1-next42-author-source-r1.py');assert hashlib.sha256(source.read_bytes()).hexdigest()=='d5244fb68dbb9f10fd098a1b0e7f94679bfed53c43e0eb2271aed0031b64f68f'
s=runpy.run_path(str(source),run_name='independent_connected_fixed');k2,k3=s['k2'],s['k3'];row,g=s['data']()[word]
from l1_normalization_opposed_fourth import L
from l1_direct_b_haar import add,scale,wedge
from l1_extended_opposed_source import frame
from l1_normalization_uniform_mixed_edge import unit
from l1_extended_two_mixed_centers import remap

def emit(kind,**v):print(json.dumps(dict(kind=kind,word=word,**v),sort_keys=True),flush=True)
@cache
def from_original_L(domain):
 out=Counter()
 for a,b,c,d in product(range(4),repeat=4):
  first=tuple(sorted((a,b)));second=tuple(sorted((c,d)))
  for i,u in L[a,c]:
   for j,v in L[b,d]:
    pair=tuple(sorted((i,j)))
    weight=12*int(i==j) if domain is None else int(pair in domain)
    out[first,second]+=u*v*weight
 return {k:v for k,v in out.items() if v}

def independent_prepare(core,restriction):
 square=g.squares[0];live=g.lives[0];sq=k3.square_factor(square,live,g.fixed_square[square]);sk=('square',0,'component');pk=('square',0,'probe')
 le=(min(live[0],live[0]^(1<<live[1])),max(live[0],live[0]^(1<<live[1])),live[1]);changed=set(g.fixed_edges)|{le}
 exclusive={k for e,keys in g.edges.items() if len(keys)==1 and e not in changed for k in keys}
 factors=[];choices={}
 for q,axes in sorted(g.frame.items()):
  keys=tuple((q,a) for a in axes);rows={};components=sorted({c for c,p in sq}) if q==square[0] else (None,)
  for comp in components:
   domain=(comp,) if q==square[0] else core.get(q)
   weights=from_original_L(None if domain is None else tuple(domain));assert weights==k3.witness.center_weights(domain)
   gamma=restriction[q];weight=weights.get(gamma,0)
   if not weight or any(gamma[j][0]!=gamma[j][1] for j,k in enumerate(keys) if k in exclusive):continue
   rows[gamma+((comp,) if q==square[0] else ())]={0:(weight,0)}
  if not rows:return None
  choices[q]=rows;factors.append((keys+((sk,) if q==square[0] else ()),rows,{}))
 for e,keys in sorted(g.edges.items()):
  lo,hi,a=e;centers=tuple(int(q==hi) for q,axis in keys);dom=[sorted({r[g.frame[q].index(axis)] for r in choices[q]}) for q,axis in keys];rows={}
  for gammas in product(*dom):
   if e==le:
    for probe in sorted({p for c,p in sq}):
     poly=k3.probed_action_edge(gammas[0],centers[0],int(live[0]==hi),probe)
     if poly:rows[gammas+(probe,)]=k3.witness.gaussian(remap(poly,(lo,hi)))
   else:
    poly=k3.fixed_action_edge(gammas,centers,g.fixed_edges[e]) if e in g.fixed_edges else k3.witness.local_edge(gammas,centers)
    if poly:rows[gammas]=k3.witness.gaussian(remap(poly,(lo,hi)))
  if not rows:return None
  factors.append((tuple(keys)+((pk,) if e==le else ()),rows,{lo:2*len(keys),hi:2*len(keys)}))
 factors.append(((sk,pk),{key:{0:(v,0)} for key,v in sq.items()},{}))
 ts=frame(0,False,unit(0),unit(0));src=scale(add(*(wedge(t,t) for t in ts)),192)
 for q,a in g.sources:
  y=q^(1<<a);factors.append(((),{():k3.witness.gaussian(remap(src,(q,y)))},{q:2,y:2}))
 assert len(factors)==38 and len(Counter(k for keys,r,d in factors for k in keys))==32
 assert set(Counter(k for keys,r,d in factors for k in keys).values())=={2}
 assert all(sum(d.get(q,0) for keys,r,d in factors)==8 for q in range(16))
 return factors,192**42*4**64*48**10*2**15,exclusive
branches=list(k2.protected_branches(g.linked,g.other));assert len(branches)==15
restrictions=dict.fromkeys(g.frame,k3.witness.FIXED_GAMMAS);prepared=[]
for b,(weight,core) in enumerate(branches):
 for q in g.frame:
  if q not in {g.squares[0][0]}:
   domain=core.get(q);assert from_original_L(None if domain is None else tuple(domain))==k3.witness.center_weights(domain)
 actual=s['prepare'](g,core,restrictions);reference=independent_prepare(core,restrictions);assert actual==reference
 prepared.append((weight,actual));emit('prepared-branch',branch=b,weight=[weight.numerator,weight.denominator],core=[[q,list(domain)] for q,domain in sorted(core.items())],empty=actual is None,factors=0 if actual is None else len(actual[0]),original_L_all_center_weights_equal=True,all38_factor_tables_equal=actual is not None)
# Offdiagonal live-center rows: all other sites fixed. They are checked directly even when global saturation vanishes.
q=g.lives[0][0]^(1<<g.lives[0][1]);off=dict(restrictions);off[q]=((0,1),(0,1));off_rows=0
for b,(weight,core) in enumerate(branches):
 actual=s['prepare'](g,core,off);reference=independent_prepare(core,off);assert actual==reference;off_rows+=actual is not None
emit('gamma-constraints',live_action_center=q,offdiagonal_profile=[[0,1],[0,1]],branches_checked=15,nonempty=off_rows,core_torus_centers=sorted(g.linked+g.other),square_curvature_center=g.squares[0][0],both_fixed_action_labels=[[4,0],[5,0]])
prep=time.perf_counter()-began;emit('preparation-complete',seconds=prep,branches=15,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP,restrictions=[[q,v] for q,v in sorted(restrictions.items())],divisor=g.divisor)
signal.alarm(60);warm=time.perf_counter();total=F();peak=0;raws=[]
for b,(weight,p) in enumerate(prepared):
 raw,n=(0,0) if p is None else k3.eliminate_components(p[0],p[2]);peak=max(peak,n);value=F(raw,g.divisor);total+=weight*value;raws.append(raw)
 emit('fixed-branch',branch=b,weight=[weight.numerator,weight.denominator],raw=raw,divisor=g.divisor,coefficient=[value.numerator,value.denominator],peak=n)
signal.alarm(0);emit('fixed-complete',coefficient=[total.numerator,total.denominator],peak=peak,cold_seconds=prep,warm_seconds=time.perf_counter()-warm,parent_seconds=time.perf_counter()-began,raws=raws,unrestricted_coefficient=False)
