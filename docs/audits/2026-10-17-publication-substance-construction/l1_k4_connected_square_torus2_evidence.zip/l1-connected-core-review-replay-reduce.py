from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path('/tmp')
def rows(name):return [json.loads(l) for l in (P/name).read_text().splitlines()]
def sha(name):return hashlib.sha256((P/name).read_bytes()).hexdigest()
r=rows('l1-connected-core-review-replay78.out');pilot=rows('l1-next42-author-pilot78.out');exitobj=json.loads((P/'l1-connected-core-review-replay78.exit.json').read_text());assert exitobj['actual_exit']==0 and exitobj['reason']=='terminal' and exitobj['actual_parent_seconds']<665
b=[x for x in r if x['kind']=='exact-branch'];pb=[x for x in pilot if x['kind']=='exact-branch'];prep=[x for x in r if x['kind']=='prepared-branch'];assert len(b)==len(pb)==len(prep)==15
last=r[-1];raw=F();total=F()
for i,(a,p) in enumerate(zip(b,pb)):
 assert a['branch']==p['branch']==i
 for key in ('weight','raw_numerator','divisor','coefficient','peak_rows'):assert a[key]==p[key]
 assert F(a['raw_numerator'],a['divisor'])==F(*a['coefficient']);raw+=F(*a['weight'])*a['raw_numerator'];total+=F(*a['weight'])*F(*a['coefficient'])
 assert prep[i]['all15_centers_beyond_fixed'] and prep[i]['original_L_center_weights_equal'] and prep[i]['factor_count']==38 and prep[i]['label_count']==32 and prep[i]['degree8_all_sites'] and prep[i]['restrictions']==[]
assert raw.denominator==1 and raw.numerator==last['raw_numerator']==pilot[-1]['raw_numerator'] and total==F(*last['coefficient'])==F(*pilot[-1]['coefficient']) and last['peak_rows']==3952
assert last['cold_seconds']<600 and last['whole15_warm_seconds']<60 and last['principal16_bindings_unchanged']
assert not (P/'l1-connected-core-review-replay78.err').read_bytes()
result={'verdict':'ACCEPT independent complete unrestricted78 replay','actual_exit':0,'all15_raws_weights_divisors_coefficients_and_peaks_equal_pilot':True,'all15_preparations_original_L_centerweights_fullgamma_and_graphchecks':True,'coefficient':last['coefficient'],'raw_numerator':last['raw_numerator'],'divisor':last['divisor'],'peak':3952,'cold_seconds':last['cold_seconds'],'whole15_warm_seconds':last['whole15_warm_seconds'],'parent_seconds':exitobj['actual_parent_seconds'],'source_sha256':last['source_sha256'],'files_sha256':{f:sha(f) for f in ['l1-connected-core-review-replay78.py','l1-connected-core-review-replay78-driver.py','l1-connected-core-review-replay78.out','l1-connected-core-review-replay78.err','l1-connected-core-review-replay78.exit.json']},'preserved_pilot_metadata_typo':pilot[-1]['scope'],'pilot_typo_annotation':'Actual two-argument prepare call/defaultrestriction/fullgamma rows proved unrestricted; original stream untouched','portable_scope':230,'word80_receipt_review':'pending actual author terminal notice'}
(P/'l1-connected-core-review-replay78-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
