from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
def rows(p):return [json.loads(l) for l in p.read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
results={}
for word in (78,80):
 r=rows(P/f'l1-connected-core-review-fixed{word}.out');author=rows(P/f'l1-next42-author-fixed{word}.out');actual_exit=json.loads((P/f'l1-connected-core-review-fixed{word}.exit.json').read_text());assert actual_exit['actual_exit']==0 and not actual_exit['timeout'] and actual_exit['parent_seconds']<665
 branches=[v for v in r if v['kind']=='fixed-branch'];ab=[v for v in author if v['kind']=='exact-fixed-branch'];assert len(branches)==len(ab)==15
 prep=[v for v in r if v['kind']=='prepared-branch'];assert len(prep)==15 and sum(not v['empty'] for v in prep)==5
 last=r[-1];assert last['kind']=='fixed-complete' and last['cold_seconds']<600 and last['warm_seconds']<60
 total=F();rawtotal=F()
 for i,(v,a) in enumerate(zip(branches,ab)):
  assert i==v['branch']==a['branch'] and v['raw']==a['raw_numerator'] and v['weight']==a['weight'] and v['divisor']==a['divisor'] and v['coefficient']==a['coefficient']
  value=F(v['raw'],v['divisor']);assert value==F(*v['coefficient']);total+=F(*v['weight'])*value;rawtotal+=F(*v['weight'])*v['raw']
 assert total==F(*last['coefficient'])==F(*author[-1]['coefficient']) and rawtotal.denominator==1 and rawtotal.numerator==author[-1]['raw_numerator']
 assert all(p['original_L_all_center_weights_equal'] and (p['empty'] or p['all38_factor_tables_equal']) for p in prep)
 off=next(v for v in r if v['kind']=='gamma-constraints');assert off['nonempty']==5
 results[str(word)]={'branches':15,'nonempty':5,'structural_empty':10,'full38_factor_tables_equal_to_independent_reference':True,'all_center_gamma_weights_equal_original_L':True,'offdiagonal_prepared_branches':15,'offdiagonal_nonempty':5,'offdiagonal_solve_run':False,'all_author_raws_weights_divisors_equal':True,'coefficient_fixed_only':last['coefficient'],'peak':last['peak'],'cold_seconds':last['cold_seconds'],'whole15_warm_seconds':last['warm_seconds'],'parent_seconds':actual_exit['parent_seconds'],'actual_exit':0}
r78=[v for v in rows(P/'l1-connected-core-review-fixed78.out') if v['kind']=='fixed-branch'];r80=[v for v in rows(P/'l1-connected-core-review-fixed80.out') if v['kind']=='fixed-branch']
assert all(all(a[k]==b[k] for k in ('branch','raw','weight','divisor','coefficient')) for a,b in zip(r78,r80))
direct=rows(P/'l1-connected-core-review-direct.out');de=json.loads((P/'l1-connected-core-review-direct.exit.json').read_text());assert de['actual_exit']==0 and direct[-1]['kind']=='direct-controls-complete'
binding=json.loads((P/'l1-next42-author-binding.json').read_text());assert all(sha(A/f)==h for f,h in binding['principal_source_sha256'].items())
files=[P/f'l1-connected-core-review-{x}.{ext}' for x in ('direct','fixed78','fixed80') for ext in ('out','err','exit.json')]+[P/f'l1-connected-core-review-{x}.py' for x in ('direct','fixed','driver')]
result={'verdict':'ACCEPT direct controls and independent fixed fullgraph78/80; no unrestricted pilot authorized or run','fixed':results,'xor1_all15_raw_weight_divisor_covariance':True,'direct':direct,'direct_actual_exit':de,'principal16_source_hashes_unchanged':True,'source_sha256':sha(P/'l1-next42-author-source-r1.py'),'files_sha256':{str(f):sha(f) for f in files},'portable_scope':230,'remaining_coefficients':42,'full_k4_commonZ_physical_B3':'OPEN','scope_limits':['No unrestricted gamma preparation or coefficient','Offdiagonal restrictions checked as complete prepared factor tables, not scalar solves','Joint forest covariance tested for original five-face holonomies; Spin/Grassmann covariance uses existing accepted convention','No candidate/Git/notebook writes']}
(P/'l1-connected-core-review-controls-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
