from pathlib import Path
import subprocess,time,json,sys
mode=sys.argv[1];root=Path('/tmp');stem=root/('l1-connected-core-review-'+mode);py='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
args=[py,'-B',str(root/('l1-connected-core-review-'+('direct' if mode=='direct' else 'fixed')+'.py'))]+([] if mode=='direct' else [mode.removeprefix('fixed')])
t=time.perf_counter()
with stem.with_suffix('.out').open('w') as out,stem.with_suffix('.err').open('w') as err:
 try:r=subprocess.run(args,stdout=out,stderr=err,timeout=665);code=r.returncode;timed=False
 except subprocess.TimeoutExpired:code=124;timed=True
result={'command':args,'actual_exit':code,'timeout':timed,'parent_seconds':time.perf_counter()-t,'parent_bound':665,'cold_bound':600,'whole_warm_bound':60 if mode!='direct' else None}
stem.with_suffix('.exit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if code:print(stem.with_suffix('.err').read_text(),flush=True)
raise SystemExit(code)
