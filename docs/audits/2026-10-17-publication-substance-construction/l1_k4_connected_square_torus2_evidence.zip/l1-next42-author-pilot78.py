import sys,json,runpy,signal,time,hashlib
from pathlib import Path
from fractions import Fraction
word=78
start=time.perf_counter();signal.alarm(600)
source=Path('/tmp/l1-next42-author-source-r1.py');source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
assert source_sha=='d5244fb68dbb9f10fd098a1b0e7f94679bfed53c43e0eb2271aed0031b64f68f'
binding=json.loads(Path('/tmp/l1-next42-author-binding.json').read_text())['principal_source_sha256']
root=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
assert len(binding)==16 and all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in binding.items())
print(json.dumps({'kind':'phase-start','phase':'cold-unrestricted-preparation','word':word,'scope':'COMPLETE unrestricted78 ONLY','hard_limit_seconds':600,'source_sha256':source_sha,'principal_source_sha256':binding}),flush=True)
s=runpy.run_path(str(source),run_name='connected_core_fixed_source');row,g=s['data']()[word]
restrict={};assert not restrict
square=g.squares[0];square_center=square[0];torus_centers={f[0] for f in g.protected_torus};assert square_center not in torus_centers
comp_domain=sorted({labels for labels,probe in s['k3'].square_factor(square,g.lives[0],g.fixed_square[square])})
prepared=[];supports=[]
for branch,(weight,core) in enumerate(s['k2'].protected_branches(g.linked,g.other)):
 p=s['prepare'](g,core);prepared.append((weight,p))
 if p is not None:
  factors,divisor,exclusive=p
  centers=[]
  for center_index,(q,axes) in enumerate(sorted(g.frame.items())):
   keys,rows,degrees=factors[center_index]
   centers.append({'center':q,'selector':'square_component' if q==square_center else 'protected_torus_core' if q in core else 'peeled','rows':[{'labels':key,'weight':value[0][0]} for key,value in sorted(rows.items())]})
 else:centers=[]
 supports.append({'branch':branch,'weight':[weight.numerator,weight.denominator],'core_domains':sorted(core.items()),'center_support':centers,'algebraic_empty_preparation':p is None})
assert len(prepared)==15
fixed_keys=set(g.fixed_edges);fixed_action=[(edge,labels) for edge,labels in sorted(g.edges.items()) if edge in fixed_keys]
assert len(fixed_action)==1 and fixed_action[0][1]==[(4,0),(5,0)]
q,a=g.lives[0];live_key=min(q,q^(1<<a)),max(q,q^(1<<a)),a
assert len(g.edges[live_key])==1 and g.edges[live_key][0][0] in torus_centers
prep=time.perf_counter()-start
print(json.dumps({'kind':'phase-complete','phase':'cold-unrestricted-preparation','seconds':prep,'word':row,'branches':15,'restrictions':sorted(restrict.items()),'support_domains':supports,'divisor':g.divisor,'sources':g.sources,'fixed_sources':sorted(g.fixed_sources),'fixed_forest':sorted(g.fixed_square[square]),'shared_source':g.shared_source,'square':square,'live':g.lives[0],'live_action_labels':g.edges[live_key],'fixed_action_edges':fixed_action,'torus_centers':sorted(torus_centers),'linked':g.linked,'other':g.other,'action_edges':[(e,l) for e,l in sorted(g.edges.items())],'row_cap':s['k2'].ROW_CAP,'pair_cap':s['k2'].PAIR_CAP}),flush=True)
signal.alarm(60);began=time.perf_counter()
print(json.dumps({'kind':'phase-start','phase':'warm-WHOLE15-unrestricted-contraction','hard_limit_seconds':60,'word':word}),flush=True)
total=Fraction();peak=0
for branch,(weight,p) in enumerate(prepared):
 if p is None:raw,size,divisor=0,0,g.divisor
 else:
  factors,divisor,exclusive=p;raw,size=s['k3'].eliminate_components(factors,exclusive)
 value=Fraction(raw,divisor);total+=weight*value;peak=max(peak,size)
 print(json.dumps({'kind':'exact-branch','word':word,'branch':branch,'weight':[weight.numerator,weight.denominator],'raw_numerator':raw,'divisor':divisor,'coefficient':[value.numerator,value.denominator],'algebraic_empty_preparation':p is None,'peak_rows':size}),flush=True)
signal.alarm(0);raw=total*g.divisor;assert raw.denominator==1
print(json.dumps({'kind':'exact-word','word':row,'scope':'COMPLETE unrestricted78 ONLY; unrestricted coefficient NOTRUN','coefficient':[total.numerator,total.denominator],'raw_numerator':raw.numerator,'divisor':g.divisor,'branches':15,'peak_rows':peak,'preparation_seconds':prep,'whole15_warm_seconds':time.perf_counter()-began,'full_seconds':time.perf_counter()-start,'source_sha256':source_sha}),flush=True)
