from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement,product
from collections import Counter
from functools import cache
import runpy,hashlib,json,time,signal
P=Path('/tmp');source=P/'l1-next42-author-source-r1.py';A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');start=time.perf_counter();signal.alarm(600)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(kind,**v):print(json.dumps(dict(kind=kind,word=78,**v),sort_keys=True),flush=True)
assert sha(source)=='d5244fb68dbb9f10fd098a1b0e7f94679bfed53c43e0eb2271aed0031b64f68f'
binding=json.loads((P/'l1-next42-author-binding.json').read_text())['principal_source_sha256'];assert len(binding)==16 and all(sha(A/f)==h for f,h in binding.items())
emit('replay-start',scope='COMPLETE independent unrestricted78',source_sha256=sha(source),principal_source_sha256=binding,cold_bound=600,whole15_warm_bound=60,parent_bound=665)
s=runpy.run_path(str(source),run_name='independent_connected_replay');k2,k3=s['k2'],s['k3'];row,g=s['data']()[78]
from l1_normalization_opposed_fourth import L
@cache
def originalweights(domain):
 out=Counter()
 for a,b,c,d in product(range(4),repeat=4):
  for i,u in L[a,c]:
   for j,v in L[b,d]:out[tuple(sorted((a,b))),tuple(sorted((c,d)))]+=u*v*(12*int(i==j) if domain is None else int(tuple(sorted((i,j))) in domain))
 return {k:v for k,v in out.items() if v}
# Reconstruct the paired action frame from the original manifest row and compare to independently graphed data.
frame={q:(0,1) for q in range(16) if q!=row['omitted']};frame.update({q:tuple(a) for q,a in row['changes']});assert frame==g.frame
ind=next(x for x in json.loads((P/'l1-connected-core-review.json').read_text())['geometry'] if x['word']==78)
assert tuple(ind['square'])==g.squares[0] and tuple(ind['live'])==g.lives[0] and ind['fixed']==[list(e) for e in sorted(g.fixed_square[g.squares[0]])] and [list(e) for e in sorted(g.protected_torus)]==ind['torus']
assert g.sources==((0,2),(1,2)) and g.fixed_sources==set(g.sources) and not g.joined_source
assert g.edges[4,5,0]==[(4,0),(5,0)] and g.edges[0,1,0]==[(1,0)] and g.divisor==192**42*4**64*48**10*2**15
bs=(1,5,9,13);branches=[(F(1,256),{q:tuple((i,i) for i in range(6)) for q in bs})]
for c in (0,1):
 indices=range(3*c,3*c+3);ds=tuple((i,i) for i in indices);branches.append((F(-1,559872),dict.fromkeys(bs,ds)))
 for pair in combinations_with_replacement(indices,2):branches.append((F(2 if pair[0]==pair[1] else 1,279936),{1:(pair,),5:(pair,),9:ds,13:ds}))
assert branches==list(k2.protected_branches(g.linked,g.other)) and len(branches)==15
prepared=[]
for b,(weight,core) in enumerate(branches):
 p=s['prepare'](g,core);assert p is not None;factors,divisor,exclusive=p
 assert len(factors)==38 and set(Counter(k for ks,rs,ds in factors for k in ks).values())=={2} and len(Counter(k for ks,rs,ds in factors for k in ks))==32
 assert all(sum(ds.get(q,0) for ks,rs,ds in factors)==8 for q in range(16)) and divisor==g.divisor
 allbeyond=True;supports=[]
 for n,(q,axes) in enumerate(sorted(g.frame.items())):
  keys,rows,degrees=factors[n];assert keys[:2]==tuple((q,a) for a in axes)
  components=sorted({r[2] for r in rows}) if q==g.squares[0][0] else (None,)
  expected={}
  for comp in components:
   domain=(comp,) if q==g.squares[0][0] else core.get(q);weights=originalweights(None if domain is None else tuple(domain));assert weights==k3.witness.center_weights(domain)
   for gamma,w in weights.items():
    if any(gamma[j][0]!=gamma[j][1] for j,key in enumerate(keys[:2]) if key in exclusive):continue
    expected[gamma+((comp,) if q==g.squares[0][0] else ())]={0:(w,0)}
  assert rows==expected
  allbeyond &= any(r[:2]!=k3.witness.FIXED_GAMMAS for r in rows)
  supports.append({'center':q,'rows':len(rows),'selector':'square_component' if q==0 else 'protected_torus_core' if q in core else 'peeled'})
 assert allbeyond
 packed=[[keys,[[key,sorted(poly.items())] for key,poly in sorted(rows.items())],sorted(degrees.items())] for keys,rows,degrees in factors]
 digest=hashlib.sha256(json.dumps(packed,separators=(',',':')).encode()).hexdigest()
 prepared.append((weight,p));emit('prepared-branch',branch=b,weight=[weight.numerator,weight.denominator],core_domains=sorted(core.items()),restrictions=[],factor_count=38,label_count=32,degree8_all_sites=True,original_L_center_weights_equal=True,all15_centers_beyond_fixed=True,center_support=supports,factor_tables_sha256=digest)
prep=time.perf_counter()-start;emit('preparation-complete',seconds=prep,branches=15,restrictions=[],divisor=g.divisor,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP)
signal.alarm(60);began=time.perf_counter();total=F();peak=0
for b,(weight,(factors,divisor,exclusive)) in enumerate(prepared):
 raw,n=k3.eliminate_components(factors,exclusive);value=F(raw,divisor);total+=weight*value;peak=max(peak,n)
 emit('exact-branch',branch=b,weight=[weight.numerator,weight.denominator],raw_numerator=raw,divisor=divisor,coefficient=[value.numerator,value.denominator],peak_rows=n)
signal.alarm(0);rawtotal=total*g.divisor;assert rawtotal.denominator==1 and total==F(230444796360321160875,8796093022208)
assert all(sha(A/f)==h for f,h in binding.items()) and sha(source)=='d5244fb68dbb9f10fd098a1b0e7f94679bfed53c43e0eb2271aed0031b64f68f'
emit('independent-complete-unrestricted',coefficient=[total.numerator,total.denominator],raw_numerator=rawtotal.numerator,divisor=g.divisor,peak_rows=peak,branches=15,cold_seconds=prep,whole15_warm_seconds=time.perf_counter()-began,full_seconds=time.perf_counter()-start,source_sha256=sha(source),principal16_bindings_unchanged=True,scope='COMPLETE unrestricted78 independent replay only')
