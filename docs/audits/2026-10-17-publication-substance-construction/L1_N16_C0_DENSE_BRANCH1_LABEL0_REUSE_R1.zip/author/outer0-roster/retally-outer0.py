from ast import literal_eval
from fractions import Fraction as Q
from pathlib import Path
import re
import sys
base,tri,heavy=map(Path,sys.argv[1:])
norm=40512224221827380280140849737629696*16*4**64

def roster(path, axes, count):
    roster=(path/'s0.roster').read_bytes()
    ws, pairs=literal_eval(roster.decode())
    assert ws==axes and len(pairs)==len(dict(pairs))==count
    return roster, sorted(pairs,key=lambda x:(x[1],x[0]))
def read(parent,d,i,key,n):
    assert (parent/f's{i}.roster').read_bytes()==d
    child=parent/f'slice{i}'
    assert f'pilot {key!r} matched {n} stored rows ' in (child/'partition.out').read_text()
    status=(child/'contraction.receipt').read_text().splitlines()[0]
    return child,status
def exact(child,status):
    assert status=='child_status 0'
    return Q(re.fullmatch(r'exact normalized ([-\d/]+) peak rows \d+ matched products \d+',
            (child/'contraction.out').read_text().splitlines()[-1])[1])
def nested(parent):
    raw,pairs=roster(parent,(('G',1,5,1),),8)
    assert sum(n for _,n in pairs) in (11_656_320,23_141_120),sum(n for _,n in pairs)
    return sum(exact(*read(parent,raw,i,k,n)) for i,(k,n) in enumerate(pairs))
def triangle(i):
    by_i={int(r[0]):tuple(map(int,r[1:])) for r in (line.split() for line in (tri/'forecast.tsv').read_text().splitlines())}
    rows,count,shards,worst=by_i[i]
    left=probes=raw=0
    for k in range(shards):
        s=(tri/str(i)/f'shard-{k}.out').read_text()
        a,b,r,j,h=map(int,re.search(r'left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)',s).groups())
        assert a==left and b>a and r==rows and j==k and h==shards
        left=b
        probes+=int(re.search(r'triangle closure \d+ nonzero-support triples (\d+) bounded probes',s)[1])
        re_num,im_num,den=map(int,re.search(r'raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)',s).groups())
        assert im_num==0 and den*16*4**64==norm
        raw+=re_num
    assert left==rows and probes==count
    return Q(raw,norm)

raw,pairs=roster(base,(('G',0,2,0),),22)
assert sum(n for _,n in pairs)==22_030_848
total=Q(0)
print('ordinal','G020','parent_products','method','real','imag',sep='\t')
for i,(k,n) in enumerate(pairs):
    child,status=read(base,raw,i,k,n)
    if i in (16,17):
        assert status=='child_status 2'
        q,method=triangle(i),'sharded triangle'
    elif i in (8,9,14,15,18,19,20,21):
        assert status=='child_status 2'
        q,method=nested(heavy if i==21 else base/f'rescue{i}'),'eight-value nested slice'
    else:
        q,method=exact(child,status),'direct'
    assert (q*norm).denominator==1
    print(i,k,n,method,q,0,sep='\t')
    total+=q
print('total','','','',total,0,sep='\t')
