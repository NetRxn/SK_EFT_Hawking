from ast import literal_eval
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
parent = Path(sys.argv[1]).resolve()
roster_bytes = (root / "s0.roster").read_bytes()
axes, counts = literal_eval(roster_bytes.decode())
assert len(axes) == 1
assert len(counts) == len(dict(counts)) == 22
assert sum(n for _, n in counts) == 22_030_848
assert max(n for _, n in counts) == 1_721_088

def step(script, args, directory, log):
    with log.open("xb") as output:
        subprocess.run(
            [sys.executable, "-B", script, *args], cwd=directory,
            stdout=output, stderr=subprocess.STDOUT, check=True, timeout=150
        )

def solve(index):
    work = root / f"slice{index}"
    work.mkdir()
    tag = f"s{index}"
    step("exact-multicut.py", [str(parent), f"{tag}.pkl", str(index)], root, work / "partition.out")
    assert (root / f"{tag}.roster").read_bytes() == roster_bytes
    step("reduce-label-frontier.py", [f"{tag}.pkl", tag], root, work / "reduce.out")
    os.link(root / f"label-{tag}-reduced-frontier.pkl", work / "dense-saturated-frontier.pkl")
    step("../run-with-peer.py", [], work, work / "terminal.out")
    status = (work / "contraction.receipt").read_text().splitlines()[0]
    print(index, status, (work / "contraction.out").read_text().splitlines()[-1], sep="\t", flush=True)

with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(solve, range(1, 21)))
