# L1 group 128 opposite branch, assignment 0, first two contributions and exact reuse

Source pin `cd4740a06`. The original eight-member G(0,5,1) roster identifies
this one exact contribution. Its continuation uses every value of the
22-member G(0,2,0) roster, with eight nested four-factor continuations, two
sharded triangles and the remaining direct exact terms. All signs and the
original denominators are retained. The original normalization enters once.

From the extracted archive root:

```sh
shasum -a 256 -c SHA256SUMS
python3 -B author/outer0-roster/retally-outer0.py author/outer0-roster author/outer0-triangles author/outer0-four-factor | cmp - author/outer0-roster/author-outer0-complete.tsv
```

The independent package records the original lineage, exhaustive support,
exact contributions and portable operand pins. The independently verified raw
map transfers the value of outer 0 to 1. The second author retally yields the
same value from its own source.

```sh
python3 -B author/outer1-roster/retally-outer1.py author/outer1-roster author/outer1-triangles author/outer1-roster/rescue21 | cmp - author/outer1-roster/author-outer1-complete.tsv
```

The maps from 2 to 3–5 and from 6 to 7 establish exact equality at disjoint
source scopes. Their anchor scalars and the complete signed group sum remain
open.
