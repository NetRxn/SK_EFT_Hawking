from ast import literal_eval
from csv import DictReader
from fractions import Fraction as Q
from pathlib import Path

root=Path(__file__).resolve().parent
axes,terms=literal_eval((root/'author/initial-roster/s0.roster').read_text())
assert axes==(('G',0,5,1),) and len(terms)==len(dict(terms))==8
assert sum(n for _,n in terms)==870912
outer=sorted(terms,key=lambda x:(x[1],x[0]))
assert [v for v,n in outer]==[(7,),(13,),(49,),(52,),(193,),(196,),(81,),(84,)]
real=[]
for n in (0,1):
    source=root/f'author/outer{n}-roster/author-outer{n}-complete.tsv'
    rows=list(DictReader(source.open(),delimiter='\t'))
    assert len(rows)==23 and rows[-1]['ordinal']=='total'
    assert [int(s['ordinal']) for s in rows[:-1]]==list(range(22))
    assert all(Q(s['imag'])==0 for s in rows)
    total=sum(Q(s['real']) for s in rows[:-1])
    assert total==Q(rows[-1]['real'])
    real.append(total)
assert real[0]==real[1]
print('outer','coordinate','products','anchor','real','imaginary','state',sep='\t')
for i, (coordinate,products) in enumerate(outer):
    anchor=0 if i<2 else 2 if i<6 else 6
    state='verified exact scalar' if i<2 else 'anchor scalar open'
    output=(real[i],0) if i<2 else ('','')
    print(i,coordinate,products,anchor,*output,state,sep='\t')
