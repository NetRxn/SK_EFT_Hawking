from csv import DictReader
from fractions import Fraction as Q
from pathlib import Path

base=Path(__file__).resolve().parent
norm=40512224221827380280140849737629696*16*4**64
source=base/'author/outer0-roster/author-outer0-complete.tsv'
author=list(DictReader(source.open(),delimiter='\t'))
assert len(author)==23 and author[-1]['ordinal']=='total'
assert [int(row['ordinal']) for row in author[:-1]]==list(range(22))
peer=base/'independent/outer0/leaf-ledger.tsv'
rows=list(DictReader(peer.open(),delimiter='\t'))
nested={8,9,14,15,18,19,20,21}
assert {(int(r['inner']),r['nested']) for r in rows}=={
 (i,str(j)) for i in nested for j in range(8)}|{
 (i,'') for i in range(22) if i not in nested}
assert len(rows)==78
subtotal={i:Q() for i in range(22)}
for row in rows:
    value=Q(int(row['raw_real']),norm)
    assert value==Q(row['value_real'])
    assert Q(row['value_imaginary'])==int(row['raw_imaginary'])==0
    assert int(row['factor_denominator'])*16*4**64==norm
    assert len(row['input_sha256'])==64
    subtotal[int(row['inner'])]+=value
for row in author[:-1]:
    assert subtotal[int(row['ordinal'])]==Q(row['real']) and int(row['imag'])==0
grand=sum(subtotal.values())
assert grand==Q(author[-1]['real']) and int(author[-1]['imag'])==0
print('outer-0',grand,0,sep='\t')
