from ast import literal_eval
from collections import Counter,defaultdict
from csv import DictReader
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from itertools import combinations,product
from math import factorial,prod
from pathlib import Path
from pickle import loads
from re import M,search
from zipfile import ZipFile

p=Path('inputs')
def digest(raw): return sha256(raw).hexdigest()
def entries(raw):
    return {name.removeprefix('./'):h for h,name in map(str.split,raw.splitlines())}

N=40512224221827380280140849737629696
with ZipFile(p/'archived-binary.zip') as archive:
    man=entries(archive.read('manifest.sha256').decode())
    name='branch128-binary-1-frontier.pkl.gz'
    for item in (name,'frontiers-uncompressed.sha256','contract-binary.py'):
        assert digest(archive.read(item))==man[item]
    raw=decompress(archive.read(name))
    assert digest(raw)==entries(archive.read('frontiers-uncompressed.sha256').decode())[name.removesuffix('.gz')]
    assert digest(raw)=='4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be'
    branch=loads(raw)
    assert branch['physical_cut']==(('R',1,3,0,2,1),1)
print('PASS committed first-index branch 1 raw source',digest(raw),flush=True)
pins=entries(Path('original-unpacked.sha256').read_text())
def load_input(name,pin):
    raw=decompress((p/(name+'.gz')).read_bytes())
    assert digest(raw)==pins[pin]
    return loads(raw)

def restriction(before,after,fixed):
    for (scope,rows,d),(target,dst,e) in zip(before,after,strict=True):
        assert d==e and d>0
        assert target==tuple(w for w in scope if w not in fixed)
        keep=tuple(scope.index(w) for w in target)
        where=tuple((i,fixed[w]) for i,w in enumerate(scope) if w in fixed)
        eligible=[(row,z) for row,z in rows.items() if all(row[i]==v for i,v in where)]
        assert len(eligible)==len(dst)
        assert {tuple(row[i] for i in keep):z for row,z in eligible}==dst
    assert prod(d for _,_,d in after)==N

parent=load_input('label0-cap.pkl','row-cap-physical-slice-dense-branch.pkl')
assert parent['physical_cut']==(branch['physical_cut'],('complete-L-assignment',0))
assert (parent['used_before'],parent['rejected_pair'],parent['matched'])==(0,(1,2),870912)
factors=branch['factors']
assert len(factors)==len(parent['factors'])==10
labels=tuple(sorted({w for s,_,_ in factors for w in s if w[0]=='L'}))
assert len(labels)==12
support=[]
for scope,rows,d in factors:
    cols=[scope.index(w) for w in labels if w in scope]
    support.append((tuple(scope[i] for i in cols),{tuple(row[i] for i in cols) for row in rows}))
domains=[sorted(set.intersection(*[{row[s.index(w)] for row in rows} for s,rows in support if w in s])) for w in labels]
valid=[]
for values in product(*domains):
    assignment=dict(zip(labels,values,strict=True))
    if all(tuple(assignment[w] for w in scope) in rows for scope,rows in support):
        valid.append(assignment)
assert len(valid)==6 and valid[0]==dict.fromkeys(labels,(0,1))
restriction(factors,parent['factors'],valid[0])
assert sum(len(rows) for _,rows,_ in parent['factors'])==804480
print('PASS six complete L projections and exact L0 restriction, 804480 signed rows',flush=True)
del branch,raw,factors

w=('G',0,5,1)
A,B=(parent['factors'][i] for i in parent['rejected_pair'])
common=tuple(sorted(set(A[0])&set(B[0])))
assert w in A[0] and w not in B[0]
ai=[A[0].index(k) for k in common]
bi=[B[0].index(k) for k in common]
ix=A[0].index(w)
hist=Counter(tuple(r[i] for i in bi) for r in B[1])
counts=Counter()
for r in A[1]:
    if n:=hist[tuple(r[i] for i in ai)]:
        counts[(r[ix],)]+=n
seen={r[s.index(w)] for s,rows,d in parent['factors'] if w in s for r in rows}
assert set(counts)=={(v,) for v in seen}
ordered=sorted(counts,key=lambda k:(counts[k],k))
assert [key[0] for key in ordered]==[7,13,49,52,193,196,81,84] and sum(counts.values())==870912
print('PASS complete outer roster',[(k,counts[k]) for k in ordered],flush=True)

def incidence(factors):
    axes=defaultdict(list)
    for i,(scope,rows,d) in enumerate(factors):
        assert len(scope)==len(set(scope))
        for key in scope: axes[key].append(i)
    shared=defaultdict(list)
    for axis,endpoints in sorted(axes.items()):
        assert len(endpoints)==2 and endpoints[0]!=endpoints[1]
        assert axis not in (w,*labels)
        shared[tuple(endpoints)].append(axis)
    return {edge:tuple(scope) for edge,scope in shared.items()}

for pair in ((0,1),(6,7)):
    ao,bo=pair
    left,right=(load_input(f's{i}.pkl',f's{i}.pkl') for i in pair)
    for i,state in zip(pair,(left,right),strict=True):
        [point]=ordered[i]
        assert {k:v for k,v in state.items() if k not in ('factors','conditioning')}=={k:v for k,v in parent.items() if k!='factors'}
        assert state['conditioning']==[(w,point)]
        axes,roster=literal_eval((p/f's{i}.roster').read_text())
        assert axes==(w,) and counts==dict(roster)
        restriction(parent['factors'],state['factors'],{w:point})
        print('PASS raw inverse lift',i,point,counts[(point,)],pins[f's{i}.pkl'],flush=True)
    before,after=left['factors'],right['factors']
    perm,lw,rw,transforms,negative=loads(decompress((p/f'witness-select-{ao}-{bo}.pkl.gz').read_bytes()))
    assert perm==tuple(range(10)) and len(before)==len(after)==10
    edges=incidence(before)
    assert edges==incidence(after)==lw==rw
    assert len(edges)==32 and set(transforms)==set(negative)==set(edges)
    endpoints=[defaultdict(dict),defaultdict(dict)]
    total=0
    for i,((a,rows,d),(b,target,e)) in enumerate(zip(before,after,strict=True)):
        assert a==b and d==e and len(rows)==len(target)
        plan=[(key,tuple(a.index(wire) for wire in scope),transforms[key],set(negative[key]))
              for key,scope in edges.items() if i in key]
        assert sorted(pos for _,cols,_,_ in plan for pos in cols)==list(range(len(a)))
        for key,cols,_,signs in plan:
            endpoints[0][key][i]={tuple(r[j] for j in cols) for r in rows}
            endpoints[1][key][i]={tuple(r[j] for j in cols) for r in target}
            assert len(signs)==len(negative[key]) and signs<=set(transforms[key])
        neg_count=0
        for r,z in rows.items():
            assert len(z)==2 and any(z) and all(type(c) is int for c in z)
            mapped=[None]*len(a)
            parity=0
            for _,cols,translation,signs in plan:
                key=tuple(r[j] for j in cols)
                parity^=(key in signs)
                for j,result in zip(cols,translation[key],strict=True):
                    mapped[j]=result
            result=target[tuple(mapped)]
            assert result==((-z[0],-z[1]) if parity else z),(pair,i,r,z,mapped,result)
            neg_count+=parity
        total+=len(rows)
        print('PASS factor signed rows',ao,bo,i,len(rows),neg_count,d,flush=True)
    changed=0
    for key in edges:
        old=endpoints[0][key]
        new=endpoints[1][key]
        mapping=transforms[key]
        assert set(old)==set(new)==set(key)
        assert set(mapping)==set.union(*old.values())
        assert len(set(mapping.values()))==len(mapping)
        assert set(mapping.values())==set.union(*new.values())
        for i in key:
            assert {mapping[v] for v in old[i]}==new[i]
        assert {mapping[v] for v in set.intersection(*old.values())}==set.intersection(*new.values())
        changed+=sum(v!=n for v,n in mapping.items())
    print('PASS exact signed map',ao,bo,'edges',len(edges),'edge values',sum(map(len,transforms.values())),
          'relabeled values',changed,'negative edge values',sum(map(len,negative.values())),
          'rows',total,'denominator',N,flush=True)
    del left,right,before,after

basis=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occ=[[basis[(code//64**v)%64] for v in range(8)] for code in (503841882182,1461451755920)]
edges=sorted(((u,v,(u^v).bit_length()-1) for u,v in combinations(range(8),2) if (u^v).bit_count()==1),key=lambda t:(t[0],t[2]))
world=sum((k+3)*n for spin in occ for row in spin for k,n in enumerate(row))
cross=0
for spin in occ:
    words=[(u,v,sum(spin[u])+sum(spin[v])-spin[u][k]-spin[v][k]) for u,v,k in edges]
    cross+=sum(m*n*sum(a>b for a in (u,v) for b in (x,y)) for (u,v,m),(x,y,n) in combinations(words,2))
assert (world,cross,sum(sum(row) for spin in occ for row in spin),prod(factorial(n) for spin in occ for row in spin for n in row))==(136,444,32,16)
print('PASS shared normalization phase +1 and external denominator',16*4**64,flush=True)

donor_pins=entries((p/'accepted-outer0-review.sha256').read_text())
for local,reference in (('accepted-outer0.out','retally.out'),('accepted-source-and-outer.out','source-and-outer.out'),('accepted-normalization.out','accepted-normalization.out')):
    assert digest((p/local).read_bytes())==donor_pins[reference]
assert search(r'^PASS exact lifted case 0 7 82944 '+pins['s0.pkl']+r' ',(p/'accepted-source-and-outer.out').read_text(),M)
donor=search(r'^outer0 subtotal raw\t(-?\d+)\t(-?\d+)\t(\d+)\tnormalized\t(\S+)\t(\S+)$',(p/'accepted-outer0.out').read_text(),M)
raw,imag,den=map(int,donor.groups()[:3])
assert den==N
verified=tuple(map(Fraction,donor.groups()[3:]))
assert verified==(Fraction(raw,N*16*4**64),Fraction(imag,N*16*4**64))
table=list(DictReader((p/'author-outer1.tsv').read_text().splitlines(),delimiter='\t'))
assert len(table)==23 and [int(row['ordinal']) for row in table[:-1]]==list(range(22))
assert len({row['G020'] for row in table[:-1]})==22 and table[-1]['ordinal']=='total'
observed=tuple(sum(Fraction(row[key]) for row in table[:-1]) for key in ('real','imag'))
assert observed==verified==tuple(Fraction(table[-1][key]) for key in ('real','imag'))
print('PASS raw 0→1 map transfers accepted scalar and matches separate author 22-term sum',*verified,flush=True)
print('PASS raw 6→7 equality, numerical transfer conditional on an accepted donor',flush=True)
