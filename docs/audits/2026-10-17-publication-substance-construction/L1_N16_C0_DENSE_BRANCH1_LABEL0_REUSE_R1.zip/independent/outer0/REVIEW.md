# Independent L1 group-128 branch 1, L assignment 0, outer ordinal 0

The exact signed subtotal matches the author ledger at
`-1746699869512866458538495/649037107316853453566312041152512 + 0i`.
The accepted term is outer ordinal 0, `G(0,5,1)=7`. The other seven
outer values have verified source conditioning in this review, and arithmetic
acceptance here is limited to ordinal 0. This subtotal does not establish the
whole L assignment, group 128, signed c0, or L1 publication readiness.

The continuity adapter reported fresh at candidate
`cd4740a06666f0b337768efcf0a63e5c8a583765`. The independent source audit
matched the accepted native operand hash in the dense binary reduction archive
and recovered the six exhaustive compatible original L projections. It then
compared every signed row of the L0 inverse restriction, and all eight inverse
lifts of the G(0,5,1) split. The split represents 870,912 compatible selected
pair products. L0's cap has ten degree-two factors and 804,480 rows, with
rejected pair (1,2). Outer 0's author restart has seven degree-two factors,
1,147,120 rows and 5,136,000 completed products.

The independently reconstructed minimum projected pair at the outer 0 cap
was (0,2), with 22,030,848 products. Its 22 distinct points on G(0,2,0) have
weights from 408,320 to 1,721,088. All 22 frozen selector inputs preserve
the full restricted signed rows under inverse lifting. The 352-point earlier
two-axis pilot has the same first-axis marginal and contributes zero terms to
this result. Each of eight hard terms (8, 9, 14, 15, 18, 19, 20, 21) has a
separately reconstructed minimum pair (0,1) and eight-value G(1,5,1)
partition. Each of the 64 nested point restrictions was independently inverted,
preserving signed coefficients and positive denominators. Their stage counts
and the 22-point weights characterize support and were not used as scalar
multipliers.

The independent evaluator computed all 78 distinct scalar leaves from
their quotient or three-factor inputs. Twelve were direct, 64 nested, and
two used independent triangle pivots that differed from the author pivot 0.
It used signed integer sparse contraction with necessary support pruning
and a width-aware join choice. The sparse path retained limits of 8 million
products per join, 30 million per leaf, 1 million output rows and a 30-second
arithmetic check. The alternate triangle path used at most 2 million forecast
probes per pivot shard. Each of the four author triangle intervals was
reconstructed from the original sorted pivot-row support; intervals were
disjoint and exhaustive, with 5,498,880 supported triples per interval.
The signed raw shard sums matched the independently replayed triangles.
Two initial triangle launch logs record a corrected scratch path typo.
All 78 arithmetic runs completed successfully on their proper operands.

The independent raw subtotal was
`-593600524158799691719177671025208180248098781591831439401455452160 + 0i`
on the factor denominator `40512224221827380280140849737629696`.
Reconstruction from frozen profile codes 503841882182 and 1461451755920
gave occupation 32, factorial multiplicity 16, quarter exponent 64, and even
phase from world 136 plus cross 444. This contributes `+1/(16 * 4^64)`
exactly once. Independent terminal arithmetic used 174,134,528 products
across leaves, a maximum of 13,879,712 within one leaf, and 190.859 seconds
summed per-leaf elapsed. Products and wall time exclude source checks and
lineage replay.

`source-and-outer.out` and `support.out` give the exact source and roster
checks. `retally.out` gives normalized inner terms and author shard traffic.
`leaf-ledger.tsv` gives input SHA-256, both raw signed components, factor
denominator, normalized value, and independent arithmetic effort for every
leaf. `author-receipts/` retains the scoped frozen plaintext author evidence.
`operands.sha256` identifies the original author inputs and receipts using
their machine-local paths. The portable review evidence includes plaintext
and hashes of the exact operands. The large binary operands must be obtained
separately for a fresh replay.

The author lineage replay reproduced 100 scoped stage observations byte for
byte. These were the original L0 cap, the outer0 partition, 87 reducers, and
11 further cap contractions. Total stage duration was 716.112 seconds
summed over two workers. Independent restriction/lift audits cover the inner
and nested selectors. Independent terminal arithmetic covers the 78 leaves.
The earlier unused two-axis pilot was checked by support and inverse lift.
All 1,044 scoped author source and receipt hashes passed readback.
