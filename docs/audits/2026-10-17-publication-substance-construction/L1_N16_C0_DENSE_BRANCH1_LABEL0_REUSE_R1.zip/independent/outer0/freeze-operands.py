from hashlib import file_digest
from pathlib import Path
import shutil
prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
outer=Path('/private/tmp/l1-branch1-label0-roster.XAoNMg')
initial=Path('/private/tmp/l1-branch1-label0-rescue0.Wie25T')
single=Path('/private/tmp/l1-branch1-label0-single-axis.yeOz8z')
four=Path('/private/tmp/l1-branch1-label0-4factor.Ok2j8F')
tri=Path('/private/tmp/l1-label0-outer0-triangles.P9vbG2')
suffixes={'.pkl','.py','.out','.roster','.receipt','.tsv','.err'}
def paths(root):
    return [q for q in root.rglob('*') if q.is_file() and q.suffix in suffixes]
families={
    'source':(prep,paths(prep/'branch1-label0')+[prep/'verified-pin/label-0-branch-1.pkl']),
    'native':(Path('/private/tmp/l1-dense-resume.bbZW6V'),
              [Path('/private/tmp/l1-dense-resume.bbZW6V/row-cap-physical-slice-dense-binary-1.pkl')]),
    'outer':(outer,[q for q in paths(outer) if not q.relative_to(outer).parts[0].startswith('slice')
                   or q.relative_to(outer).parts[0]=='slice0']),
    'initial':(initial,paths(initial)),
    'single':(single,paths(single)),
    'nested21':(four,paths(four)),
    'triangles':(tri,paths(tri)),
}
with Path('operands.sha256').open('x') as out:
    for family,(base,files) in families.items():
        for src in sorted(files):
            with src.open('rb') as f:
                digest=file_digest(f,'sha256').hexdigest()
            print(digest,src,sep='  ',file=out)
            if src.suffix!='.pkl':
                dst=Path('author-receipts')/family/src.relative_to(base)
                dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(src,dst)
