from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
from time import perf_counter

root=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
parent=Path((root/'label0-single-axis.path').read_text().strip())
nested21=Path((root/'label0-4factor.path').read_text().strip())
jobs=[]
for i in range(22):
    if i in (16,17):
        jobs.append((f'inner-{i}', 'independent-triangle.py',[str(i)]))
    elif i in (8,9,14,15,18,19,20,21):
        child=parent/f'rescue{i}' if i!=21 else nested21
        for k in range(8):
            jobs.append((f'inner-{i}-nested-{k}','independent-sparse.py',
                         [str(k),str(child/f'label-s{k}-reduced-frontier.pkl')]))
    else:
        jobs.append((f'inner-{i}','independent-sparse.py',[str(i),str(parent/f'label-s{i}-reduced-frontier.pkl')]))
assert len(jobs)==78
def work(args):
    label,script,argv=args
    start=perf_counter()
    with Path(label+'-replay.out').open('xb') as out:
        p=subprocess.run([sys.executable,'-u',script,*argv],stdout=out,stderr=subprocess.STDOUT,timeout=150)
    return label,p.returncode,perf_counter()-start
with ThreadPoolExecutor(max_workers=2) as pool:
    for label,status,t in pool.map(work,jobs):
        print(label,status,f'{t:.6f}',sep='\t',flush=True)
