from ast import literal_eval
from collections import Counter
from hashlib import sha256
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import loads

outer=Path('/private/tmp/l1-branch1-label0-roster.XAoNMg')
initial=Path('/private/tmp/l1-branch1-label0-rescue0.Wie25T')
single=Path('/private/tmp/l1-branch1-label0-single-axis.yeOz8z')
four=Path('/private/tmp/l1-branch1-label0-4factor.Ok2j8F')
D=40512224221827380280140849737629696
stamp=((('R',1,3,0,2,1),1),('complete-L-assignment',0))
def load(path):
    return loads(path.read_bytes())
def h(path):
    return sha256(path.read_bytes()).hexdigest()
def project(scope,keys):
    positions=tuple(scope.index(k) for k in keys)
    return lambda row:tuple(row[k] for k in positions)
def degrees(f):
    assert all(len(a)==len(set(a)) and x and d>0 for a,x,d in f)
    return Counter(k for a,_,_ in f for k in a)
def validate(f):
    assert set(degrees(f).values())=={2} and prod(d for _,_,d in f)==D
def cost(f,i,j,axes=()):
    a,x,_=f[i]
    b,y,_=f[j]
    shared=tuple(sorted(set(a)&set(b)))
    assert not set(axes)&set(shared) and set(axes)<=set(a)|set(b)
    key_a,key_b=project(a,shared),project(b,shared)
    ax_a,ax_b=tuple(k for k in axes if k in a),tuple(k for k in axes if k in b)
    proj_a,proj_b=project(a,ax_a),project(b,ax_b)
    t_a=Counter((key_a(row),proj_a(row)) for row in x)
    t_b=Counter((key_b(row),proj_b(row)) for row in y)
    nodes={}
    for (edge,point),n in t_b.items():
        nodes.setdefault(edge,[]).append((point,n))
    answer=Counter()
    for (edge,lhs),n in t_a.items():
        for rhs,m in nodes.get(edge,()):
            mapping=dict(zip(ax_a,lhs,strict=True))|dict(zip(ax_b,rhs,strict=True))
            answer[tuple(mapping[k] for k in axes)]+=n*m
    return answer

def base(cap,inp,expected_pair,expected_count):
    a=load(cap)
    b=load(inp)
    f=a['factors']
    assert a['physical_cut']==b['physical_cut']==stamp
    validate(f)
    assert a|{'rejected_pair':expected_pair,'matched':expected_count}==b
    c={(i,j):cost(f,i,j)[()] for i,j in combinations(range(len(f)),2)}
    assert min(c,key=lambda ij:(c[ij],ij))==expected_pair and c[expected_pair]==expected_count
    print('minimum projected pair',len(f),expected_pair,expected_count,'census',c,'input',h(inp),flush=True)
    return f
def lift_validate(f,fixed,cut):
    assert len(f)==len(cut)
    for (a,x,d),(b,y,e) in zip(f,cut,strict=True):
        assert d==e and b==tuple(k for k in a if k not in fixed)
        fixed_pos=tuple((position,fixed[k]) for position,k in enumerate(a) if k in fixed)
        keep=project(a,b)
        if not fixed_pos:
            assert x==y
            continue
        count=0
        for row,v in x.items():
            if all(row[position]==n for position,n in fixed_pos):
                assert y[keep(row)]==v
                count+=1
        assert count==len(y)

def check(folder,f,pair,axes,num,total,indices=None):
    wanted=cost(f,*pair,axes)
    assert len(wanted)==num and sum(wanted.values())==total and min(wanted.values())>0
    roster=(folder/'s0.roster').read_text()
    assert literal_eval(roster)==(axes,sorted(wanted.items()))
    ranked=sorted(wanted,key=lambda p:(wanted[p],p))
    for i in (range(num) if indices is None else indices):
        point=ranked[i]
        fixed=dict(zip(axes,point,strict=True))
        raw=folder/f's{i}.pkl'
        reduction=folder/f'label-s{i}-reduced-frontier.pkl'
        r,c=load(raw),load(reduction)
        assert (folder/f's{i}.roster').read_text()==roster
        assert r['physical_cut']==c['physical_cut']==stamp
        assert tuple(r['conditioning'])==tuple(c['conditioning'])==tuple(fixed.items())
        lift_validate(f,fixed,r['factors'])
        validate(r['factors'])
        validate(c['factors'])
        assert not set(fixed)&set(degrees(c['factors']))
        print('PASS exact lifted',folder.name,i,point,wanted[point],h(raw),h(reduction),flush=True)
    return wanted
cap=outer/'slice0/join-cap-physical-slice-dense-branch.pkl'
assert h(cap)=='2a7938438bfcee894fc1dbbf3673c26f7c62421ba8e2e4566e772b05ce78a506'
f=base(cap,initial/'partition-input.pkl',(0,2),22030848)
assert (len(f),sum(len(x) for _,x,_ in f))==(7,1147120)
axes=(('G',0,2,0),('G',0,0,2))
pilot=check(initial,f,(0,2),axes,352,22030848,indices=(0,))
axis=axes[:1]
closed=check(single,f,(0,2),axis,22,22030848)
marginal=Counter()
for (i,j),n in pilot.items():
    marginal[(i,)]+=n
assert marginal==closed and (min(closed.values()),max(closed.values()))==(408320,1721088)
print('Unused 352-point two-axis pilot marginal matches final 22-point roster')
for i in (8,9,14,15,18,19,20,21):
    folder=single/f'rescue{i}' if i!=21 else four
    nested_cap=single/f'slice{i}'/'join-cap-physical-slice-dense-branch.pkl'
    expected=11656320 if i<18 else 23141120
    f=base(nested_cap,folder/'partition-input.pkl',(0,1),expected)
    assert len(f)==4
    result=check(folder,f,(0,1),(('G',1,5,1),),8,expected)
    assert set(result.values())==({1122240,1791840} if i<18 else {2227840,3557440})
print('PASS all support, inverse lifts, factors and normalizations')
