from shape import *
from edge_relabel import edge_model,domains,marginals
from signed_gauge import check_mapped_magnitudes,recover
from pickle import dump
from gzip import open as gzopen
from sys import argv
from time import perf_counter

def refine(source,dest,colors=None,limit=6):
 ds=[domains(G) for G in (source,dest)]
 assert set(ds[0])==set(ds[1])
 if colors is None: colors=[{e:dict.fromkeys(vals,0) for e,vals in group.items()} for group in ds]
 for iteration in range(limit):
  sigs=[marginals(G,C,use_coefficient=False) for G,C in zip((source,dest),colors,strict=True)]
  old=sum(len(set(M.values())) for M in colors[0].values())
  for e in colors[0]:
   a,b=[Counter((C[e][k],v) for k,v in S[e].items()) for C,S in zip(colors,sigs,strict=True)]
   if a!=b: return None,(iteration,e)
  for e in colors[0]:
   uni={}
   for i in range(2):
    for k,c in colors[i][e].items():
     colors[i][e][k]=uni.setdefault((c,sigs[i][e][k]),len(uni))
  counts={e:Counter(outer.values()) for e,outer in colors[0].items()}
  totals=sum(len(x) for x in counts.values())
  print('refine iteration',iteration,'colors',old,totals,'ambiguous local group sizes',Counter(n for x in counts.values() for n in x.values() if n>1),flush=True)
  if old==totals:break
 return colors,None

def generate(C,identity=True):
 out={}
 for e in C[0]:
  a,b=defaultdict(set),defaultdict(set)
  for v,c in C[0][e].items():a[c].add(v)
  for v,c in C[1][e].items():b[c].add(v)
  m={}
  for c,D in a.items():
   E=b[c]
   common=D&E if identity else set()
   m.update({k:k for k in common})
   m.update(zip(sorted(D-common),sorted(E-common),strict=True))
  out[e]=m
 return out

if __name__=='__main__':
 stage,left,right=argv[1],*map(int,argv[2:])
 ts=perf_counter()
 levels=[edge_model(factors(stage,q)[0]) for q in (left,right)]
 A,B=[x[0] for x in levels]
 print('checked original operands',stage,left,right,flush=True)
 result,status=refine(A,B)
 print('result',status,'seconds',perf_counter()-ts,flush=True)
 if result is not None:
  for k in result[0]:
   x,y=result[0][k],result[1][k]
   print('edge',k,'domain',len(x),'classes',len(set(x.values())),'same domains',set(x)==set(y),
         'within address colors',sum(x[v]==y.get(v) for v in x),flush=True)
  with open('relabel-colors.pkl','wb') as f:dump(result,f,protocol=5)
  for ident in (True,False):
   M=generate(result,ident)
   if check_mapped_magnitudes(A,B,M):
    charge,status=recover(A,B,M)
    print('signed solved?',charge is not None,status,flush=True)
    if charge is not None:
     with gzopen(f'witness-{stage}-{left}-{right}.pkl.gz','wb') as f:
      dump((tuple(range(len(A))),levels[0][1],levels[1][1],M,charge),f,protocol=5)
     break
