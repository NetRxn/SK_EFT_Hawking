from shape import *
from edge_relabel import edge_model,domains
from signed_gauge import magnitude,recover
from refine import refine
from collections import defaultdict
from gzip import compress
from pickle import loads,dumps
from sys import argv
from time import perf_counter

def context(edges,row,value,C):
 return magnitude(value),tuple(C[e][x] for e,x in zip(edges,row,strict=True))

class Search:
 def __init__(self,L,R,colors):
  self.L,self.R,self.colors=L,R,colors
  self.variables=sorted((e,v) for e,d in colors[0].items() for v in d)
  self.index={k:i for i,k in enumerate(self.variables)}
  allowed=defaultdict(list)
  for e,d in colors[1].items():
   for v,c in d.items():allowed[e,c].append(v)
  self.opts=[tuple(sorted(allowed[e,colors[0][e][v]])) for e,v in self.variables]
  self.masks=[(1<<len(v))-1 for v in self.opts]
  self.pref=[(self.opts[i].index(v) if v in self.opts[i] else 0) for i,(e,v) in enumerate(self.variables)]
  buckets=defaultdict(list)
  for i,(e,v) in enumerate(self.variables):
   buckets[e,colors[0][e][v]].append(i)
  self.groups=list(buckets.values())
  assert all(len(g)==len(self.opts[g[0]]) and len(set(self.opts[i] for i in g))==1 for g in self.groups)
  self.Rblocks=[]
  for es,T,d in R:
   by=defaultdict(list)
   for row,z in T.items():by[context(es,row,z,colors[1])].append(row)
   self.Rblocks.append(by)
  self.bound=100000
  self.work=0
  self.active={}
 def add(self,i,row,z):
  es=self.L[i][0]
  var=tuple(self.index[e,v] for e,v in zip(es,row,strict=True))
  if var in self.active:return
  word=context(es,row,z,self.colors[0])
  dest=self.Rblocks[i][word]
  table=[tuple(1<<self.opts[j].index(v) for j,v in zip(var,r,strict=True)) for r in dest]
  assert table
  self.active[var]=table
 def trial(self,doms):
  self.work+=1
  if self.work>self.bound:raise TimeoutError('search node bound')
  changed=True
  while changed:
   changed=False
   for vs in self.groups:
    fixed=0
    for v in vs:
     mask=doms[v]
     if mask.bit_count()==1:
      if mask&fixed:return
      fixed|=mask
    for v in vs:
     old=doms[v]
     if old.bit_count()>1:
      new=old&~fixed
      if not new:return
      if new!=old:doms[v]=new;changed=True
   for vs,tuples in self.active.items():
    avail=[0]*len(vs)
    domains=tuple(doms[v] for v in vs)
    for tt in tuples:
     if all(m&a for m,a in zip(tt,domains,strict=True)):
      for k,code in enumerate(tt):avail[k]|=code
    if not any(avail):return
    for v,x in zip(vs,avail,strict=True):
     if x!=doms[v]:doms[v]=x;changed=True
  # Prefer branching only on variables in an active relation.
  freq=Counter(v for var in self.active for v in var if doms[v].bit_count()>1)
  if not freq:
   return doms
  n=min(freq,key=lambda v:(doms[v].bit_count(),-freq[v],v))
  option=doms[n]
  pref=1<<self.pref[n]
  while option:
   q=pref if option&pref else option&-option
   option^=q
   nxt=doms.copy()
   nxt[n]=q
   res=self.trial(nxt)
   if res is not None:return res
 def concrete(self,dom):
  result=defaultdict(dict)
  for g in self.groups:
   free=set(range(len(g)))
   for i in g:
    if dom[i].bit_count()==1:
     j=dom[i].bit_length()-1
     free.remove(j)
     e,v=self.variables[i]
     result[e][v]=self.opts[i][j]
   for i in g:
    if dom[i].bit_count()!=1:
     # No active relation has unresolved variables. Only the ordinary bijection remains.
     k=self.pref[i]
     j=k if k in free else min(free)
     assert (dom[i]>>j)&1
     free.remove(j)
     e,v=self.variables[i]
     result[e][v]=self.opts[i][j]
  return dict(result)
 def check(self,M,examples=22):
  failure=[]
  for i in sorted(range(len(self.L)),key=lambda i:len(self.L[i][1])):
   es,X,_=self.L[i]; _,Y,_=self.R[i]
   local=0
   eligible=set()
   pp=tuple(M[e] for e in es)
   for row,z in X.items():
    d=tuple(m[v] for m,v in zip(pp,row,strict=True))
    q=Y.get(d)
    if q is None or magnitude(q)!=magnitude(z):
     key=context(es,row,z,self.colors[0])
     if key in eligible:continue
     local+=1
     eligible.add(key)
     failure.append((i,row,z))
     if local>=examples:break
  return failure

if __name__=='__main__':
 t=perf_counter()
 st,l,r=argv[1],*map(int,argv[2:])
 L,LS=edge_model(factors(st,l)[0]); R,RS=edge_model(factors(st,r)[0])
 p=Path(f'colors-{st}-{l}-{r}.pkl')
 if p.exists(): C=loads(p.read_bytes())
 else:
  C,status=refine(L,R)
  print('refine result',status,flush=True)
  if C is None:raise SystemExit(0)
  p.write_bytes(dumps(C,protocol=5))
 search=Search(L,R,C)
 for i,(_,table,_) in enumerate(L):
  if len(table)>200:continue
  for row,z in table.items():search.add(i,row,z)
 for attempt in range(45):
  ans=search.trial(search.masks.copy())
  if ans is None:
   print('finite row-bijection constraints refuted',len(search.active),search.work,perf_counter()-t,flush=True)
   raise SystemExit(0)
  M=search.concrete(ans)
  bad=search.check(M)
  print('search',attempt,'constraints',len(search.active),'visited',search.work,'unmapped examples',len(bad),'time',perf_counter()-t,flush=True)
  if bad:
   for i,row,z in bad:search.add(i,row,z)
   continue
  charge,state=recover(L,R,M)
  print('full support absolute value map','sign state',state,'elapsed',perf_counter()-t,flush=True)
  if charge is None:
   Path(f'unsigned-{st}-{l}-{r}.pkl').write_bytes(dumps(M,protocol=5))
   break
  final=(tuple(range(len(L))),LS,RS,M,charge)
  Path(f'witness-{st}-{l}-{r}.pkl.gz').write_bytes(compress(dumps(final,protocol=5),mtime=0))
  break
