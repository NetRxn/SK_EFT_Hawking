from shape import *
from archives import archive,LATEST
from ast import literal_eval
from collections import defaultdict
from math import prod
from gzip import decompress
from pickle import loads
from time import perf_counter
from sys import argv
from hashlib import sha256

D=40512224221827380280140849737629696
O=('R',1,3,0,2,1),1
OUT=('G',0,5,1)
ids={2:49,3:52,4:193,5:196}
P=Path('/private/tmp/l1-dense-resume.bbZW6V/row-cap-physical-slice-dense-binary-1.pkl')

def lift(selected,parent,fixed):
 for (ax,X,d),(target,Y,e) in zip(parent,selected,strict=True):
  assert d==e and target==tuple(w for w in ax if w not in fixed)
  c=tuple((n,fixed[w]) for n,w in enumerate(ax) if w in fixed)
  if not c:
   assert X==Y
   continue
  got={}
  for key,z in Y.items():
   v=list(key)
   for i,x in c:v.insert(i,x)
   k=tuple(v)
   assert k not in got
   got[k]=z
  assert got=={k:z for k,z in X.items() if all(k[i]==x for i,x in c)}

def prove_sources():
 archive(LATEST)
 old=archive('DENSE_BRANCH1_LABELS345')
 binary=archive('DENSE_BINARY_REDUCTION')
 source=A/'branch1-label0'
 cap_path=source/'row-cap-physical-slice-dense-branch.pkl'
 initial=source/'dense-saturated-frontier.pkl'
 anchors=old.read('author/parents/label0/operands.sha256').decode()
 for p in (cap_path,initial):
  assert any(l.startswith(sha(p)) and l.endswith(p.name) for l in anchors.splitlines())
 assert sha(P)==sha256(decompress(binary.read('branch128-binary-1-frontier.pkl.gz'))).hexdigest()=='4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be'
 root=read(P)
 cap=read(cap_path)
 frozen=read(initial)
 assert root['physical_cut']==O and cap['physical_cut']==frozen['physical_cut']==(O,('complete-L-assignment',0))
 assert len(root['factors'])==len(cap['factors'])==len(frozen['factors'])==10
 assert cap['factors']==frozen['factors']
 assert cap['used_before']==0 and frozen['used_before']==1143480
 named=dict(frozen['selected'])
 assert len(named)==12 and set(named.values())=={(0,1)}
 roster=[literal_eval(s.split('assignment 1 ',1)[1]) for s in (source/'support.out').read_text().splitlines() if s.startswith('exact surviving L assignment 1 ')]
 assert len(roster)==6 and roster[0]==frozen['selected']
 lift(frozen['factors'],root['factors'],named)
 F=cap['factors']
 wire_degree=Counter(x for ax,_,_ in F for x in ax)
 assert set(wire_degree.values())=={2} and prod(d for _,_,d in F)==D
 assert sum(len(x) for _,x,_ in F)==804480
 assert [i for i,(ax,_,_) in enumerate(F) if OUT in ax]==[1,4]
 a,X,_=F[cap['rejected_pair'][0]]
 b,Y,_=F[cap['rejected_pair'][1]]
 assert OUT in a and OUT not in b
 shared=tuple(w for w in a if w in b)
 assert len(shared)>0 and OUT not in shared
 idx=[tuple(x.index(w) for w in shared) for x in (a,b)]
 rhs=Counter(tuple(r[p] for p in idx[1]) for r in Y)
 left=Counter((tuple(r[p] for p in idx[0]),r[a.index(OUT)]) for r in X)
 numbers=Counter()
 for (s,g),n in left.items():
  if rhs[s]:numbers[(g,)]+=n*rhs[s]
 assert len(numbers)==8 and sum(numbers.values())==cap['matched']==870912
 ar,roster=literal_eval((R/'s0.roster').read_text())
 assert ar==(OUT,) and numbers==dict(roster)
 positions=sorted(numbers,key=lambda k:(numbers[k],k))
 print('exact original 1-branch assignment0 lift and byte-unchanged cap factor tables',sha(initial),sha(cap_path),
       'original full 8-cut roster',[(q,numbers[q]) for q in positions],flush=True)
 for n,g in ids.items():
  cut=R/f's{n}.pkl'
  o=read(cut)
  assert positions[n]==(g,) and numbers[(g,)]==89856 and o['conditioning']==[(OUT,g)]
  assert o['physical_cut']==cap['physical_cut'] and prod(d for _,_,d in o['factors'])==D
  assert (R/f's{n}.roster').read_bytes()==(R/'s0.roster').read_bytes()
  lift(o['factors'],F,{OUT:g})
  print('exact raw outer lift',n,g,sha(cut),'rows',sum(len(t) for _,t,_ in o['factors']),flush=True)

def actual_edges(F):
 incidence=defaultdict(list)
 for i,(ax,_,d) in enumerate(F):
  assert d>0 and len(ax)==len(set(ax))
  for w in ax:incidence[w].append(i)
 edges=defaultdict(set)
 for w,v in incidence.items():
  assert len(v)==2
  edges[tuple(v)].add(w)
 return dict(edges)

def verify(l,r,witness):
 left,_=factors('select',l)
 right,_=factors('select',r)
 perm,old,new,maps,flip=loads(decompress(witness.read_bytes()))
 assert perm==tuple(range(len(left))) and len(left)==len(right)
 assert set(old)==set(new)==set(maps)==set(flip)
 for graph,scopes in ((left,old),(right,new)):
  assert prod(d for _,_,d in graph)==D
  assert actual_edges(graph)=={e:set(v) for e,v in scopes.items()}
 for e,m in maps.items():
  assert len(m)==len(set(m.values()))
  assert set(flip[e])<=set(m) and len(flip[e])==len(set(flip[e]))
 lhs=defaultdict(dict); rhs=defaultdict(dict)
 rows=neg=0
 for i,((a,X,d),(b,Y,e)) in enumerate(zip(left,right,strict=True)):
  assert d==e and len(X)==len(Y)
  ports=[]
  for edge,M in maps.items():
   if i not in edge:continue
   aa=tuple(a.index(w) for w in old[edge])
   bb=tuple(b.index(w) for w in new[edge])
   k=tuple(flip[edge])
   ports.append((edge,aa,bb,M,set(k)))
  got={}
  for row,z in X.items():
   key=[None]*len(b)
   sigma=1
   for edge,aa,bb,M,signs in ports:
    p=tuple(row[j] for j in aa)
    q=M[p]
    for j,v in zip(bb,q,strict=True):
     assert key[j] is None
     key[j]=v
    if p in signs:sigma=-sigma
   y=tuple(key)
   assert None not in y and y not in got and all(type(v) is int for v in z) and any(z)
   got[y]=tuple(sigma*v for v in z)
   rows+=1
   neg+=sigma<0
  assert got==Y
  for e,aa,bb,M,signs in ports:
   lhs[e][i]={tuple(row[j] for j in aa) for row in X}
   rhs[e][i]={tuple(row[j] for j in bb) for row in Y}
 changed=amb=0
 for e,M in maps.items():
  i,j=e
  assert set(M)==lhs[e][i]|lhs[e][j] and set(M.values())==rhs[e][i]|rhs[e][j]
  for n in e:assert {M[k] for k in lhs[e][n]}==rhs[e][n]
  changed+=sum(k!=v for k,v in M.items())
  assert old[e]==new[e]
  for i,_ in enumerate(old[e]):
   f=defaultdict(set)
   for k,v in M.items():f[k[i]].add(v[i])
   amb+=any(len(s)>1 for s in f.values())
 assert rows==560676
 return len(left),len(maps),sum(map(len,maps.values())),changed,amb,sum(map(len,flip.values())),rows,neg

if __name__=='__main__':
 prove_sources()
 print('from','to','factors','edges','values','changed_values','noncomponentwise_wires','negative_edge_values','rows','flipped_rows','from_hash','to_hash','witness_hash','seconds',sep='\t',flush=True)
 for n in (tuple(map(int,argv[1:])) or (3,4,5)):
  start=perf_counter()
  w=Path(f'witness-select-2-{n}.pkl.gz')
  result=verify(2,n,w)
  print(2,n,*result,sha(R/'s2.pkl'),sha(R/f's{n}.pkl'),sha(w),f'{perf_counter()-start:.6f}',sep='\t',flush=True)
