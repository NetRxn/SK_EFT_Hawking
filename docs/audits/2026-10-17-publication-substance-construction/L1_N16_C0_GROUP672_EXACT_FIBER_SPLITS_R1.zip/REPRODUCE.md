# Group 672 exact fiber splits on the 14-factor residual

Restore the second-fold row cap from L1_N16_C0_GROUP672_SIX_ROW_INTERVALS_R1.zip and its predecessors. Check SHA256 1af9a67813e00b5eeaebcc52600916ecf81b176fe5ef06ba74b01b3de1e3bb96. The pinned run log establishes 2,186,112 inherited products, and the legacy row-cap serialization omits this inherited counter. The inputs and signed factors are unchanged by recovering that counter.

The independent directory preserves the review and exact support forecasts. Reproduce its candidate with candidate.py, then pilot.py using the candidate SHA256. The three inverse reconstructions, exact signed joins and final tensor denominator are recorded in its manifest and terminal receipts. The author verify-multifiber.py independently reconstructs all three original tensors and replays the exact signed joins. Its arguments are the original row cap, the generated split frontier and the pilot residual. It compares recomputed signed row dictionaries, allowing traversal order to differ on recomputed outputs.

The separate author split.py applies the simpler rank-two split. The egress run forces its first join. It then hits the prior 3,055,488-product row cap again. The author multifiber continuation uses the separate verified pilot residual with its first pair pinned. It reaches a 1,150,848-product row cap. Use the corresponding runner from the author directory and put the actual selected input under the expected dense-saturated-frontier.pkl name. Match all generated state hashes. These are bounded contractions and exact residual scopes.

Verify manifest.sha256 and independent/review-manifest.portable.sha256. Group scalar, total group runtime and profile cost remain open.
