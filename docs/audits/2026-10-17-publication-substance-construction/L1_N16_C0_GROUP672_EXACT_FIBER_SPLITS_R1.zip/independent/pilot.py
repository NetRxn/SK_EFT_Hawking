from candidate import *
from itertools import count

SOURCE=Path('split-frontier.pkl')
MAX_WORK=500000
MAX_ROWS=500000
MAX_STEPS=3
assert len(argv)==2 and sha(SOURCE)==argv[1]
source=read(SOURCE)
assert source['origin_input_sha256']==H
assert source['used_before']==2186112
assert len(source['factors'])==17
F=dict(zip(source['factor_labels'],source['factors']))
start=perf_counter()
edges={}
for a,b in combinations(F,2):
    s=score(F[a],F[b])
    if s is not None: edges[a,b]=s
newlabels=count(14)
trace=[]
work=0
for k in range(MAX_STEPS):
    # Exclude undoing a split immediately. Keep physical join information prominent.
    admissible=[(s[0]*(1+s[1])**2,s,a,b) for (a,b),s in edges.items() if a[0]!=b[0] and work+s[0]<=MAX_WORK]
    if not admissible: break
    _,(est,width,support),a,b=min(admissible)
    assert est>0
    x,y=F.pop(a),F.pop(b)
    match,out=join(x,y,est)
    assert len(out[1])<=match==est and len(out[1])<=MAX_ROWS and len(out[0])==width
    work+=match
    mid=(next(newlabels),0)
    F[mid]=out
    edges={pair:s for pair,s in edges.items() if a not in pair and b not in pair}
    for i in F:
        if i==mid: continue
        value=score(F[i],out)
        if value is not None: edges[i,mid]=value
    trace.append((a,b,mid,match,len(out[1]),width,out[2]))
    print('exact signed unsharded pilot join',trace[-1],'run work',work,
          'factor count',len(F),'seconds',round(perf_counter()-start,6),flush=True)
assert len(trace)>0
assert prod(n for _,_,n in F.values())==DEN
assert set(Counter(w for ax,_,_ in F.values() for w in ax).values())=={2}
nexts=sorted((s,a,b) for (a,b),s in edges.items())
print('precise residual candidates',nexts[:16],flush=True)
print('exact unsharded residual rows',sum(len(rows) for _,rows,_ in F.values()),'factors',len(F),'cumulative committed products',source['used_before']+work,flush=True)
final={**source,'factors':list(F.values()),'factor_labels':tuple(F),'used_before':source['used_before']+work,
       'completed_this_run':work,'exact_pilot_trace':tuple(trace),'split_frontier_sha256':sha(SOURCE)}
with Path('split-pilot-residual.pkl').open('xb') as fh: dump(final,fh,protocol=5)
assert read(Path('split-pilot-residual.pkl'))==final
print('residual checkpoint SHA',sha(Path('split-pilot-residual.pkl')),flush=True)
print('elapsed seconds',round(perf_counter()-start,6),flush=True)
