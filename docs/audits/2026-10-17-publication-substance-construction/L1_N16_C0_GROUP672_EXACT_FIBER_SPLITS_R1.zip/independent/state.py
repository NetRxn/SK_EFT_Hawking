from collections import Counter,defaultdict
from itertools import combinations
from pathlib import Path
from runpy import run_path

old=run_path('check-residuals.py')
read,sha,project=(old['v'][k] for k in ('read','hashfile','project'))
trim,summarize,forecasts=(old[k] for k in ('trim','state_summary','forecasts'))
D=Path('/private/tmp/l1-group672-six-row.V3TMCN')
P=D/'block5-fold12'
CAP=P/'row-cap-physical-slice-dense-branch.pkl'
H='1af9a67813e00b5eeaebcc52600916ecf81b176fe5ef06ba74b01b3de1e3bb96'
FOLD=D/'second-fold-1-2.pkl'
FH='be4466d4fd5b6d381ef50f772e648334c142884548f3276d8839e62d21d81dad'

def axes_positions(keep, scope):
    return tuple(scope.index(w) for w in keep)

def support(F,target):
    ax,rows,_=F
    return {project(k,axes_positions(target,ax)) for k in rows} if target else {()}

def select(F, ids):
    ax=[F[k][0] for k in ids]
    counts=Counter(w for scope in ax for w in scope)
    return tuple(w for scope in ax for w in scope if counts[w]==1)

def cap():
    assert sha(CAP)==H
    obj=read(CAP)
    assert summarize(obj['factors'])==(1964480,217)
    assert obj['rejected_pair']==(1,2) and obj['matched']==3055488 and obj['used_before']==0
    return obj

if __name__=='__main__':
    assert sha(P/'dense-saturated-frontier.pkl')==sha(FOLD)==FH
    a=read(FOLD)
    c=read(CAP)
    assert c['physical_cut']==a['physical_cut']
    F,removed=trim(a['factors'])
    print('verified initial signed tables and two support sweeps',removed,summarize(F),flush=True)
    assert F==c['factors']
    assert a['used_before']==2186112 and a['completed_this_run']==1950336
    print('row cap payload stored used_before',c['used_before'],'true inherited products',a['used_before'],flush=True)
    for i,(axes,rows,n) in enumerate(F):
        adj=[(j,len(set(axes)&set(b))) for j,(b,_,_) in enumerate(F) if j!=i and set(axes)&set(b)]
        print('factor',i,len(axes),len(rows),n,'links',adj,flush=True)
    print('all exact match forecasts',forecasts(F),flush=True)
