# Group 672 second fold and unsharded continuation

This review covers only original joint-L assignment 7, J(1,1,2)=(1,), G(0,6,0) in {81,88,193,200}, and outgoing left-row interval 5 at [2437,2768). The original group, its assignment 7, the J=(1,) sum, and this interval's scalar remain open.

The continuity packet was fresh at publication checkpoint 605a32fd1707c0c074ac3c3f388f39c5906f654b. The committed six-row archive and its operand lists bind the exact prior 14-factor cap, second-fold input, and subsequent row-cap object. See source-pins.out and original-operands.sha256. All original axes have degree two. The product of tensor denominators is 576173855599322741762003196268511232 throughout. The inherited positive physical prefactor is 1/(16×4^64) when normalizing a terminal scalar.

## Second exact fold and measured refusal

The second fold acts on the committed 14-factor input's pair (1,2). Independent primitive-vector normalization and Gaussian scale transfer verified 6,112 and 21,024 input rows by direction. Each direction restored every normalized row before transfer. The fold merged 4+8 shared fibers, reduced matched products from 10,708,224 to 3,055,488, and yielded 1,744 and 7,008 signed rows. The entire frozen folded input matches the reconstruction, including the remaining tables, axes, denominators and original condition.

Two independently replayed support sweeps remove zero. All 14 row-cap factors match the saved tables, with 1,964,480 rows and 217 degree-two wires. The exact linked-pair census confirms (1,2) is the sole raw candidate inside the 8M per-join guard. All 10 author peer-pair checks match, and all 3,055,488 products survive those and the 35 bounded connected three-peer projections tested here. The four shared atoms and the Gaussian fiber profiles on each side prove that all 3,055,488 products have distinct nonzero signed output rows. The 500,001st row necessarily trips the 500,000-row guard. Author status was 2 after 21.025581 s at 1,472,544,768 B peak child RSS. The rejected join is uncommitted.

The saved row-cap object stores used_before=0. The committed predecessor and log carry 2,186,112 completed products into this restart. Preserve the lineage in any resume envelope. The author fallback quotient screen on eight other pairs found no raw quotient ≤8M. Our independently measured peer-pair admissibility screen reduces (2,3) from 8,031,744 raw matches to 5,836,032 feasible products via peers (11,13). This number alone gives no 500,000-row safety bound. Unfiltered fusion of (1,2) with one additional adjacent factor costs at least 1,867,335,680 products.

## Exact local factorization and first unsharded continuation

For each selected source factor, partition the outgoing axes by its listed neighboring factors. For every left key, normalize its sparse right fiber by the integer content and a Gaussian unit. The left child at (left key, class) carries the recovered Gaussian scale. The right child at (class, right key) carries the primitive coefficients. Each left key belongs to exactly one class, and direct contraction reproduces its signed rows and the full zero complement. The class wire is fresh, has degree two, and uses the same complete finite class roster in both children. The original denominator is on the left child, and the right child has denominator 1.

| Source factor | Left neighbors | Old rows | Left rows | Right rows | Classes | Denominators |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | 2,3,6,11 | 1,744 | 128 | 252 | 18 | 24,1 |
| 2 | 3,11,13 | 7,008 | 984 | 224 | 28 | 48,1 |
| 3 | 1,2,5,7 | 10,512 | 360 | 552 | 20 | 72,1 |

The frozen 17-factor split retains every other factor and every original wire incidence. candidate.out records each ordered denominator and the exact candidate forecasts. The three joins below used a combined 144,192 products under a 500,000 total work budget. Each output has at most its exact admitted match count. A second traversal with independent real and imaginary accumulators reproduced every row of the saved 14-factor state. The first run elapsed 10.76 s, including initial forecasts and final checkpoint readback.

| Join | Products | Output rows | Output axes | Denominator |
| --- | ---: | ---: | ---: | ---: |
| (1-left,2-right)→14 | 7,168 | 7,168 | 14 | 24 |
| (2-left,3-left)→15 | 39,360 | 39,360 | 21 | 3,456 |
| (1-right,14)→16 | 97,664 | 97,664 | 22 | 24 |

The new checkpoint is one unsharded 14-factor state with 2,082,792 signed rows and 2,330,304 cumulative committed products. The next exact minimum is tuple index (1,12), corresponding to (3-right,15), with 1,150,848 raw products, 44 outgoing axes and 20 common atoms. This makes a single guarded continuation possible with a strict product cap sized for that pair and the existing 500,000-row limit. The next projected upper bound exceeds the row guard, so a reproducible next attempt should preserve the exact frontier on refusal. No result beyond the three joins was run in this package.

Reproduction from this directory uses python3 -B verify-fold.py, state.py, profile.py, screen.py 2 100000, screen.py 3 100000, screen.py triples, screen.py 2 100000 2 3, splits.py 1 2 3, and check-receipt.py with the frozen logs. Run candidate.py in a fresh copy with the pinned input paths and no candidate output. Then run pilot.py with the split-frontier SHA from result-operands.sha256, followed by replay-pilot.py. The two large locally generated outputs have a separate manifest. The same original group condition, signed arithmetic, and denominator apply at all stages.
