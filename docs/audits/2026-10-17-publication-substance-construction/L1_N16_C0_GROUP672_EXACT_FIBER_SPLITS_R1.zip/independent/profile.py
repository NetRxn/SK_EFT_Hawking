from collections import Counter,defaultdict
from math import gcd
from time import perf_counter
from state import *

I=(1,2)
UNIT=((1,0),(0,1),(-1,0),(0,-1))
def mul(p,q):
    a,b=p; x,y=q
    return a*x-b*y,a*y+b*x

def gauss_sum(parts):
    a=b=0
    for x,y in parts: a+=x; b+=y
    return a,b

def normalized(z):
    div=gcd(*(v for a in z for v in a))
    unit=max(UNIT,key=lambda u:mul(next(a for a in z if any(a)),u))
    prim=tuple(mul((a//div,b//div),unit) for a,b in z)
    scale=div*unit[0],-div*unit[1]
    assert tuple(mul(a,scale) for a in prim)==z
    return prim,scale

def profile(F,i,shared,atoms):
    ax,rows,_=F[i]
    internal=axes_positions(shared,ax)
    outgoing=tuple(w for w in ax if w not in shared)
    rest=axes_positions(outgoing,ax)
    full=defaultdict(dict)
    codes={v:k for k,v in enumerate(atoms)}
    for row,z in rows.items():
        key=project(row,rest)
        p=codes[project(row,internal)]
        assert p not in full[key]
        full[key][p]=z
    groups=defaultdict(list)
    direct=Counter()
    for row,vector in full.items():
        g=tuple(vector.get(k,(0,0)) for k in range(len(atoms)))
        direct[g]+=1
        prim,scale=normalized(g)
        groups[prim].append((row,scale))
    print('factor',i,'outgoing',len(outgoing),'unique rows',len(full),'raw profiles',len(direct),
          'primitive profiles',len(groups),'most common',[len(v) for _,v in sorted(groups.items(),key=lambda q:-len(q[1]))[:12]],flush=True)
    return outgoing,groups

if __name__=='__main__':
    t=perf_counter()
    C=cap()
    F=C['factors']
    i,j=I
    shared=tuple(w for w in F[i][0] if w in F[j][0])
    al,ar=(support(F[k],shared) for k in I)
    assert al==ar
    atoms=tuple(sorted(al))
    print('exact input',H,'shared axes',shared,'atoms',atoms,flush=True)
    L,A=profile(F,i,shared,atoms)
    R,B=profile(F,j,shared,atoms)
    assert len(A)*len(B)<1000000
    done=Counter()
    for a,X in A.items():
        for b,Y in B.items():
            cost=sum(any(p) and any(q) for p,q in zip(a,b))
            z=gauss_sum(mul(p,q) for p,q in zip(a,b))
            n=len(X)*len(Y)
            done['raw_products']+=n*cost
            done['dot_products']+=1
            if cost: done['candidate_rows']+=n
            if any(z):
                done['nonzero_rows']+=n
                done['nonzero_profile_pairs']+=1
            elif cost:
                done['cancelled_rows']+=n
    assert done['raw_products']==3055488
    print('exact factorized arithmetic totals',dict(done),'seconds',round(perf_counter()-t,6),flush=True)
