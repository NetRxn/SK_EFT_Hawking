from splits import split
from profile import mul
from state import *
from math import prod
from pickle import dump
from time import perf_counter
from sys import argv

DEN=576173855599322741762003196268511232
PLAN={1:(2,3,6,11),2:(3,11,13),3:(1,2,5,7)}

def build(original, plan):
    F={}
    for i,(ax,rows,den) in enumerate(original):
        if i not in plan:
            F[(i,0)]=(ax,rows,den)
            continue
        left=tuple(w for w in ax if any(w in original[j][0] for j in plan[i]))
        A,B,rank=split(original,i,left,independent=True)
        label=('exact-fiber',i)
        assert label not in {w for scope,_,_ in original for w in scope}
        assert A[0][-1:]==B[0][:1]==(label,)
        assert {row[-1] for row in A[1]}=={row[0] for row in B[1]}==set(range(rank))
        print('reconstructed every raw signed row and support',i,'old rows',len(rows),
              'left linked neighbors',plan[i],'split rows',len(A[1]),len(B[1]),'classes',rank,
              'original/left/right denominators',(den,A[2],B[2]),flush=True)
        F[(i,0)],F[(i,1)]=A,B
    degree=Counter(w for ax,_,_ in F.values() for w in ax)
    was=Counter(w for ax,_,_ in original for w in ax)
    assert degree==was+Counter({('exact-fiber',i):2 for i in plan})
    assert prod(d for _,_,d in F.values())==DEN
    return F

def score(A,B):
    ax,X,d=A; ay,Y,e=B
    shared=tuple(w for w in ax if w in ay)
    if not shared:
        return None
    ai=axes_positions(shared,ax); bi=axes_positions(shared,ay)
    p=Counter(project(z,ai) for z in X); q=Counter(project(z,bi) for z in Y)
    return sum(s*q[k] for k,s in p.items()),len(set(ax)^set(ay)),len(p.keys()&q.keys())

def join(A,B,maximum):
    ax,X,d=A; ay,Y,e=B
    shared=tuple(w for w in ax if w in ay)
    left=tuple(w for w in ax if w not in ay)
    right=tuple(w for w in ay if w not in ax)
    ai=axes_positions(shared,ax); bi=axes_positions(shared,ay)
    li=axes_positions(left,ax); ri=axes_positions(right,ay)
    groups=defaultdict(list)
    for row,z in X.items():
        groups[project(row,ai)].append((project(row,li),z))
    matched=0
    out={}
    for y,q in Y.items():
        tail=project(y,ri)
        for head,p in groups.get(project(y,bi),()):
            matched+=1
            assert matched<=maximum
            row=head+tail
            a,b=mul(p,q); c,f=out.get(row,(0,0))
            if a+c or b+f: out[row]=a+c,b+f
            else: out.pop(row,None)
    return matched,(left+right,out,d*e)

def forecasts(F, baseline):
    ret=[]
    for i,j in combinations(F,2):
        r=baseline.get((i[0],j[0])) if i[0] not in PLAN and j[0] not in PLAN and i[1]==j[1]==0 else score(F[i],F[j])
        if r is not None:
            ret.append((*r,i,j))
    return sorted(ret)

if __name__=='__main__':
    start=perf_counter()
    obj=cap()
    original=obj['factors']
    F=build(original,PLAN)
    baseline={}
    # Recompute all source raw pair costs once and reuse mathematically unaffected pairs.
    for i,j in combinations(range(len(original)),2):
        if i not in PLAN and j not in PLAN:
            baseline[i,j]=score(original[i],original[j])
    initial=forecasts(F,baseline)
    print('split-stage complete exact forecast best',initial[:20],flush=True)
    print('split-stage ordered denominators',[(i,d) for i,(_,_,d) in F.items()],flush=True)
    assert 2186112+sum(r[0] for r in initial[:1]) < 40000000
    stage={**obj,'factors':list(F.values()),'used_before':2186112,'completed_this_run':0,
           'origin_input_sha256':H,'split_factors':tuple(PLAN.items()),'factor_labels':tuple(F)}
    for obsolete in ('rejected_pair','matched'): del stage[obsolete]
    if len(argv)==1:
        with Path('split-frontier.pkl').open('xb') as fh: dump(stage,fh,protocol=5)
        saved=read(Path('split-frontier.pkl'))
        assert saved==stage
        print('complete unsharded split frontier',sha(Path('split-frontier.pkl')),flush=True)
    print('elapsed',round(perf_counter()-start,6),flush=True)
