from candidate import *
from time import perf_counter

start=perf_counter()
source=Path('split-frontier.pkl')
output=Path('split-pilot-residual.pkl')
assert sha(source)=='2a3b6a2eb369c1ec3273dae2d2811a691144ffc2eccaed778141a4388bf407e4'
assert sha(output)=='6a35a540eaee90864390f50ea052e170c6979978d53d8083979c2f77cdc26ae1'
orig,final=read(source),read(output)
states=dict(zip(orig['factor_labels'],orig['factors']))
literal=[
 ((1,0),(2,1),(14,0),7168,7168,14,24),
 ((2,0),(3,0),(15,0),39360,39360,21,3456),
 ((1,1),(14,0),(16,0),97664,97664,22,24),
]
assert final['exact_pilot_trace']==tuple(literal)

def other_direction(A,B):
    a,X,d=A; b,Y,n=B
    link=tuple(w for w in b if w in a)
    keep=tuple(w for w in a if w not in link)+tuple(w for w in b if w not in link)
    ac,bc=axes_positions(link,a),axes_positions(link,b)
    at=axes_positions(tuple(w for w in keep if w in a),a)
    bt=axes_positions(tuple(w for w in keep if w in b),b)
    lookup=defaultdict(list)
    for row,z in Y.items(): lookup[project(row,bc)].append((project(row,bt),z))
    reals,imags=Counter(),Counter()
    count=0
    for x,s in X.items():
        left=project(x,at)
        for right,t in lookup[project(x,ac)]:
            count+=1
            k=left+right
            ar,ai=s; br,bi=t
            reals[k]+= ar*br-ai*bi
            imags[k]+= ai*br+ar*bi
    return count,(keep,{k:(reals[k],imags[k]) for k in reals if reals[k] or imags[k]}, d*n)

for i,j,u,n,rows,width,d in literal:
    count,t=other_direction(states.pop(i),states.pop(j))
    assert count==n and (len(t[1]),len(t[0]),t[2])==(rows,width,d)
    states[u]=t
assert tuple(states)==final['factor_labels']
assert list(states.values())==final['factors']
assert final['physical_cut']==orig['physical_cut']
assert final['used_before']==2330304 and final['completed_this_run']==144192
assert prod(n for _,_,n in states.values())==DEN
print('verified exact Gaussian alternate traversal for all three joins, all residual tables and coefficients',sum(len(s[1]) for s in states.values()),'seconds',perf_counter()-start)
