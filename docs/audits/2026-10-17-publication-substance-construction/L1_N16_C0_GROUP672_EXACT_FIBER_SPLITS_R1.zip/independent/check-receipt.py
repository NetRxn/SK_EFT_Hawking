from pathlib import Path
from re import findall,finditer

author=Path('author')
log=(author/'contraction.out').read_text()
receipt=(author/'contraction.receipt').read_text()
code=(author/'contract-with-peer.py').read_text()
assert receipt=='child_status 2\nelapsed_seconds 21.025581\npeak_child_rss_bytes 1472544768\n'
assert (author/'contraction.err').stat().st_size==0
assert 'factors 14 prior matched work 2186112' in log
assert 'quotient before join 14 3055488 3055488 slices 0' in log
assert log.endswith('open row cap 14 3055488 frontier saved\n')
assert "if k not in out and len(out)>=500000:" in code and "'used_before':work-matched" in code
claimed=set(tuple(map(int,t)) for t in findall(r'peer pair support (\d+) (\d+) projected products (\d+) allowed (\d+)',log))
p=Path('rank2.out').read_text()
found={tuple(map(int,x.groups())) for x in finditer(r'constraint \((\d+), (\d+)\) width \d+ projected matches (\d+) support (\d+)',p)}
assert claimed==found and len(found)==10
for n in (2,3):
    r=Path(f'rank{n}.out').read_text()
    assert f"pair (1, 2) rank {n} totals {{'raw': 3055488, 'accepted': 3055488}}" in r
    print('rank',n,'literal independently projected constraints',len(findall(r'^constraint',r,flags=8)))
assert "'nonzero_rows': 3055488" in Path('profile.out').read_text()
print('verified refusal from exact nonzero distinct count beyond 500000 and 10 matching peer checks')
print('checked inherited work 2186112 and row-cap take-up 3055488 beyond saved used_before=0')
