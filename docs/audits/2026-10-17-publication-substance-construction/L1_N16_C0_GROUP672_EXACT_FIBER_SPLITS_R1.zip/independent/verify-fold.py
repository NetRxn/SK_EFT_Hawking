from collections import Counter,defaultdict
from math import gcd,prod
from pathlib import Path
from runpy import run_path
from time import perf_counter

q=run_path('exact-intervals.py')
entry,sha,DEN=(q[k] for k in ('read','hashfile','DEN'))
a=Path('/private/tmp/l1-group672-six-row.V3TMCN')
original=a/'block5-fold48/join-cap-physical-slice-dense-branch.pkl'
assert sha(original)=='d4f60e531da0259afb60d536f90070d2d31760a9529dd3d0d29b56cd0c7643d9'
source=entry(original)
factors=source['factors']
degree=Counter(k for scope,_,_ in factors for k in scope)
assert all(n==2 and w[0]!='L' for w,n in degree.items())
MULT=((1,0),(0,1),(-1,0),(0,-1))
def mul(p,q):
    a,b=p
    x,y=q
    return a*x-b*y,a*y+b*x

def axes(f,g):
    return tuple(k for k in f[0] if k in g[0])

def buckets(f,shared):
    scope,table,d=f
    common=tuple(scope.index(w) for w in shared)
    outgoing=tuple(w for w in scope if w not in shared)
    private=tuple(scope.index(w) for w in outgoing)
    groups=defaultdict(dict)
    for key,g in table.items():
        atom=tuple(key[p] for p in common)
        tail=tuple(key[p] for p in private)
        assert tail not in groups[atom]
        assert any(g)
        groups[atom][tail]=g
    return outgoing,groups

def count(f,g):
    common=axes(f,g)
    _,l=buckets(f,common)
    _,r=buckets(g,common)
    return sum(len(l[k])*len(r[k]) for k in l.keys()&r.keys())

def direction(f,g):
    shared=axes(f,g)
    assert len(shared)>0 and all(degree[w]==2 for w in shared)
    left,A=buckets(f,shared)
    right,B=buckets(g,shared)
    aliases={}
    factors={}
    sections={}
    checked_rows=0
    for atom in sorted(A.keys()&B.keys()):
        vector=A[atom]
        q=gcd(*(v for z in vector.values() for v in z))
        assert q>0
        origin=vector[min(vector)]
        u=max(MULT,key=lambda unit:mul(origin,unit))
        scalar=q*u[0],-q*u[1]
        units=tuple((tail,mul((z[0]//q,z[1]//q),u)) for tail,z in sorted(vector.items()))
        assert all(v%q==0 for z in vector.values() for v in z)
        # Exact termwise factorization before any regrouping.
        assert all(mul(z,scalar)==vector[tail] for tail,z in units)
        checked_rows+=len(units)
        representative=sections.setdefault(units,atom)
        factors[representative]=units
        aliases[atom]=(representative,scalar)
    move=len(aliases)-len(sections)
    if move==0 and len(aliases)==len(B):
        return f,g,move,checked_rows,len(aliases),len(A)-len(aliases),0
    next_left={representative+tail:z for representative,units in factors.items() for tail,z in units}
    next_right=defaultdict(lambda:(0,0))
    for atom,(representative,scalar) in aliases.items():
        for tail,z in B[atom].items():
            x,y=next_right[representative+tail]
            a,b=mul(z,scalar)
            next_right[representative+tail]=x+a,y+b
    cancellations=sum(not any(v) for v in next_right.values())
    supported={r:z for r,z in next_right.items() if any(z)}
    return (shared+left,next_left,f[2]),(shared+right,supported,g[2]),move,checked_rows,len(aliases),len(A)-len(aliases),cancellations

i,j=1,2
start=perf_counter()
f,g,m,ca,sa,da,za=direction(factors[i],factors[j])
g,f,n,cb,sb,db,zb=direction(g,f)
assert (count(factors[i],factors[j]),count(f,g),m+n,len(f[1]),len(g[1]))==(10708224,3055488,12,1744,7008)
print('fold matched counts',10708224,3055488,'merged fibers',m,n,'signed rows checked',ca,cb,
      'support atoms',sa,sb,'unmatched labels',da,db,'cancelled exact row sums',za,zb,flush=True)
target=a/'second-fold-1-2.pkl'
assert sha(target)=='be4466d4fd5b6d381ef50f772e648334c142884548f3276d8839e62d21d81dad'
expected=list(factors)
expected[i],expected[j]=f,g
assert entry(target)==dict(source,factors=expected)
assert Counter(w for scope,_,_ in expected for w in scope)==degree
assert prod(d for _,_,d in expected)==DEN
print('exact same full folded source object',sha(target),'elapsed',perf_counter()-start,flush=True)
