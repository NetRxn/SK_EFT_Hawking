from profile import normalized
from state import *
from sys import argv
from time import perf_counter

def split(F,i,left,independent=False):
    ax,R,d=F[i]
    right=tuple(w for w in ax if w not in left)
    lpos=axes_positions(left,ax); rpos=axes_positions(right,ax)
    by=defaultdict(list)
    for row,z in R.items(): by[project(row,lpos)].append((project(row,rpos),z))
    A,B,classes={},{},{}
    for x,rows in by.items():
        rows.sort()
        keys,z=zip(*rows)
        prim,scale=normalized(z)
        signature=tuple(zip(keys,prim))
        fresh=len(classes)
        label=classes.setdefault(signature,fresh)
        A[x+(label,)]=scale
        if label==fresh:
            B.update({(label,)+key:v for key,v in signature})
    if independent:
        pos=tuple((left+right).index(w) for w in ax)
        direct=defaultdict(list)
        for key,z in B.items():direct[key[0]].append((key[1:],z))
        restored={}
        from profile import mul
        for key,z in A.items():
            for tail,w in direct[key[-1]]:
                row=project(key[:-1]+tail,pos)
                assert row not in restored
                restored[row]=mul(z,w)
        assert restored==R
    synthetic=('exact-fiber',i)
    return (left+(synthetic,),A,d),((synthetic,)+right,B,1),len(classes)

def proposal(F,i):
    ax,R,_=F[i]
    peers={j:tuple(k for k in ax if k in bx) for j,(bx,_,_) in enumerate(F) if i!=j and set(ax)&set(bx)}
    H={j:Counter(project(row,axes_positions(shared,F[j][0])) for row in F[j][1]) for j,shared in peers.items()}
    print('input factor',i,'neighbors',tuple(peers),'rows',len(R),flush=True)
    def costs(f):
        scope,R,_=f
        for j,shared in peers.items():
            if not set(shared)<=set(scope):continue
            inds=axes_positions(shared,scope)
            yield sum(H[j][project(row,inds)] for row in R),j
    found=[]
    for n in range(1,len(peers)):
        for chosen in combinations(peers,n):
            vars={w for j in chosen for w in peers[j]}
            left=tuple(w for w in ax if w in vars)
            A,B,k=split(F,i,left)
            z=sorted([(n,j,'A') for n,j in costs(A)]+[(n,j,'B') for n,j in costs(B)])
            opts=[(n,j,v) for n,j,v in z if (i,j) not in ((1,2),(2,1))]
            found.append((opts[0][0],max(len(A[1]),len(B[1])),len(A[1])+len(B[1]),k,chosen,z))
    for row in sorted(found)[:8]:
        print('top neighbor join',i,*row,flush=True)
    for row in sorted(found,key=lambda r:(r[2],r[0]))[:5]:
        print('top representation',i,*row,flush=True)
    return found

if __name__=='__main__':
    from gc import collect
    t=perf_counter()
    F=cap()['factors']
    for i in map(int,argv[1:]):
        proposal(F,i)
        collect()
    print('seconds',round(perf_counter()-t,6),flush=True)
