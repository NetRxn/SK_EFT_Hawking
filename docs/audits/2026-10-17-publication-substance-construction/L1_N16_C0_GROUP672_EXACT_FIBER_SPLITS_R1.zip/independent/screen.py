from state import *
from time import perf_counter
from sys import argv

def joint_constraints(F,ids,bound,max_peers,budget):
    peers=[i for i in range(len(F)) if i not in ids]
    relevant=[i for i in peers if set(F[i][0])&set(bound)]
    scopes={i:set(F[i][0]) for i in peers}
    cache={}
    for n in range(1,max_peers+1):
        for group in combinations(peers,n):
            touching=set(group)&set(relevant)
            if len(touching)<min(2,n): continue
            if n>1 and any(not any(scopes[i]&scopes[j] for j in group if j!=i) for i in group): continue
            internal=Counter(w for i in group for w in scopes[i])
            out=tuple(w for w in bound if w in internal)
            local={}
            for i in group:
                keep=tuple(w for w in F[i][0] if internal[w]>1 or w in out)
                if (i,keep) not in cache:
                    cache[i,keep]=support(F[i],keep)
                local[i]=(keep,cache[i,keep])
            joined,spent=natural(local,budget)
            if joined is None: continue
            ax,rows=joined
            allowed={project(k,axes_positions(out,ax)) for k in rows}
            yield group,spent,out,allowed

def natural(tables,budget):
    tables=dict(tables)
    i=min(tables,key=lambda i:len(tables[i][1]))
    ax,X=tables.pop(i)
    spent=0
    while tables:
        _,j=min((-len(set(ax)&set(ay)),j) for j,(ay,_) in tables.items())
        ay,Y=tables.pop(j)
        common=tuple(w for w in ax if w in ay)
        tail=tuple(w for w in ay if w not in ax)
        rows=defaultdict(list)
        yi=axes_positions(common,ay)
        ti=axes_positions(tail,ay)
        for y in Y:
            rows[project(y,yi)].append(project(y,ti))
        xi=axes_positions(common,ax)
        projected=[(x,rows.get(project(x,xi),())) for x in X]
        spent+=sum(len(ys) for _,ys in projected)
        if budget is not None and spent>budget: return None,spent
        X={x+y for x,ys in projected for y in ys}
        ax+=tail
    return (ax,X),spent

def all_thirds(F,scope):
    a,b=scope
    print('triple exact raw match counts over all third factors connected to (1,2):',flush=True)
    for c in range(len(F)):
        if c in scope or not set(F[c][0])&set(F[a][0]+F[b][0]):continue
        p=(a,b,c)
        freq=Counter(w for i in p for w in F[i][0])
        axes={i:tuple(w for w in F[i][0] if freq[w]>1) for i in p}
        tables={i:Counter(project(row,axes_positions(axes[i],F[i][0])) for row in F[i][1]) for i in p}
        ret,spent=natural({i:(axes[i],set(t)) for i,t in tables.items()},1000000)
        if ret is None:
            print(p,'projection exceeded 1m',spent,flush=True)
            continue
        ax,joined=ret
        inds={i:axes_positions(axes[i],ax) for i in p}
        products=sum(tables[a][project(k,inds[a])]*tables[b][project(k,inds[b])]*tables[c][project(k,inds[c])] for k in joined)
        print(p,'raw',products,'outgoing',len(select(F,p)),'projection combinations',len(joined),'spent',spent,
              'histograms',[(i,len(tables[i])) for i in p],flush=True)

def pair_masks(F,ids,rank,budget):
    a,b=ids
    bound=select(F,ids)
    ax,X,_=F[a]; ay,Y,_=F[b]
    c=tuple(w for w in ax if w in ay)
    xc=axes_positions(c,ax); yc=axes_positions(c,ay)
    left=tuple(w for w in bound if w in ax); right=tuple(w for w in bound if w in ay)
    li=axes_positions(left,ax); ri=axes_positions(right,ay)
    ykeys=list(Y)
    raw=defaultdict(int)
    for count,k in enumerate(ykeys): raw[project(k,yc)]|=1<<count
    constraints=[]
    for group,spent,scope,allowed in joint_constraints(F,ids,bound,rank,budget):
        if not allowed:
            print('empty support proof',group,scope,flush=True)
            return
        print('constraint',group,'width',len(scope),'projected matches',spent,'support',len(allowed),flush=True)
        ix=tuple(i for i,w in enumerate(scope) if w in left)
        iy=tuple(i for i,w in enumerate(scope) if w in right)
        XL=axes_positions(tuple(scope[i] for i in ix),ax)
        YR=axes_positions(tuple(scope[i] for i in iy),ay)
        masks=defaultdict(int)
        for count,k in enumerate(ykeys): masks[project(k,YR)]|=1<<count
        mapped=defaultdict(int)
        for k in allowed: mapped[project(k,ix)]|=masks[project(k,iy)]
        constraints.append((group,XL,mapped))
    # For each left row, filter original compatible right-row positions by exact projected support.
    totals=Counter()
    gone=Counter()
    for x in X:
        avail=raw[project(x,xc)]
        totals['raw']+=avail.bit_count()
        for group,XL,mapped in sorted(constraints,key=lambda x:(len(x[0]),len(x[2]))):
            new=avail & mapped[project(x,XL)]
            gone[group]+=avail.bit_count()-new.bit_count()
            avail=new
            if not avail: break
        totals['accepted']+=avail.bit_count()
    print('pair',ids,'rank',rank,'totals',dict(totals),'constraint incremental removals',gone,flush=True)

if __name__=='__main__':
    t=perf_counter()
    F=cap()['factors']
    if argv[1]=='triples':all_thirds(F,(1,2))
    else:pair_masks(F,tuple(map(int,argv[3:])) or (1,2),int(argv[1]),int(argv[2]))
    print('elapsed seconds',round(perf_counter()-t,6),flush=True)
