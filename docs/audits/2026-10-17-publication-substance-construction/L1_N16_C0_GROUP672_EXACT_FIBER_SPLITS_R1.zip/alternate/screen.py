from collections import Counter,defaultdict
from hashlib import file_digest
from itertools import combinations
from math import gcd
from pathlib import Path
from pickle import dump,load
import sys,time

source=Path(sys.argv[1])
with source.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='1af9a67813e00b5eeaebcc52600916ecf81b176fe5ef06ba74b01b3de1e3bb96'
    stream.seek(0)
    state=load(stream)
F=state['factors']
assert len(F)==14 and state['rejected_pair']==(1,2)
D=Counter(w for a,_,_ in F for w in a)
assert set(D.values())=={2}
code=Path('contract-with-peer.py').read_text()
namespace={'defaultdict':defaultdict,'gcd':gcd}
exec(code[code.index('def rotate('):code.index('def local_test()')],namespace)
quotient=namespace['quotient']
def describe(a,b):
    axes,rows,_=a
    other,terms,_=b
    wires=tuple(w for w in axes if w in other)
    left=tuple(axes.index(w) for w in wires)
    right=tuple(other.index(w) for w in wires)
    x=Counter(tuple(r[u] for u in left) for r in rows)
    y=Counter(tuple(r[u] for u in right) for r in terms)
    return sum(x[k]*y[k] for k in x.keys()&y.keys()),len(set(axes)^set(other))
candidates=[]
for i,j in combinations(range(len(F)),2):
    if (i,j)==(1,2) or not set(F[i][0])&set(F[j][0]):
        continue
    count,width=describe(F[i],F[j])
    candidates.append((count,width,i,j))
worklist=sorted(candidates)[:6]
worklist=list(dict.fromkeys([*worklist,*sorted(candidates,key=lambda x:(x[1],x[0],x[2:]))[:3]]))
results=[]
for count,width,i,j in worklist:
    start=time.monotonic()
    A,B=F[i],F[j]
    a,b,m=quotient(A,B,D)
    b,a,n=quotient(b,a,D)
    after,retained=describe(a,b)
    assert after<=count and retained==width and a[2]==A[2] and b[2]==B[2]
    print(i,j,count,width,after,m+n,len(a[1]),len(b[1]),round(time.monotonic()-start,6),sep='\t',flush=True)
    if after<=8_000_000 and after>0:
        modified=list(F)
        modified[i],modified[j]=a,b
        with Path(f'fold-{i}-{j}.pkl').open('xb') as output:
            dump(dict(state,factors=modified,preferred_pair=(i,j)),output,protocol=5)
        results.append((after*(1+width)**2,after,i,j))
if results:
    _,after,i,j=min(results)
    print('least weighted alternative',i,j,after,flush=True)
