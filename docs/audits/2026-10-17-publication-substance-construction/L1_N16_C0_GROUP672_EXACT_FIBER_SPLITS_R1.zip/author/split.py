from collections import Counter,defaultdict
from hashlib import file_digest
from math import gcd,prod
from pathlib import Path
from pickle import dump,load
from sys import argv

parent=Path(argv[1])
with parent.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='1af9a67813e00b5eeaebcc52600916ecf81b176fe5ef06ba74b01b3de1e3bb96'
    stream.seek(0)
    state=load(stream)
F=state['factors']
assert len(F)==14 and state['rejected_pair']==(1,2)
scope,rows,den=F[1]
assert len(rows)==1744
D=Counter(w for A,_,_ in F for w in A)
assert set(D.values())=={2}
neighbors=(2,3,11)
other=(6,12,13)
left=tuple(w for w in scope if any(w in F[i][0] for i in neighbors))
right=tuple(w for w in scope if any(w in F[i][0] for i in other))
assert set(left).isdisjoint(right) and set(left)|set(right)==set(scope)
L=tuple(scope.index(w) for w in left)
R=tuple(scope.index(w) for w in right)
def project(row,columns):
    return tuple(row[p] for p in columns)
def rotate(x,y,n):
    return ((x,y),(-y,x),(-x,-y),(y,-x))[n]

fibers=defaultdict(list)
for row,(a,b) in rows.items():
    fibers[project(row,L)].append((project(row,R),a,b))
library={}
lrows={}
rrows={}
for prefix,entries in sorted(fibers.items()):
    entries.sort()
    common=0
    for _,a,b in entries:
        common=gcd(common,gcd(a,b))
    assert common>0
    _,a,b=entries[0]
    phase=max(range(4),key=lambda n:rotate(a,b,n))
    key=tuple((suffix,*rotate(a//common,b//common,phase)) for suffix,a,b in entries)
    token=library.setdefault(key,len(library))
    lrows[prefix+(token,)]=rotate(common,0,-phase%4)
    for suffix,a,b in key:
        col=(token,)+suffix
        if col in rrows:
            assert rrows[col]==(a,b)
        else:
            rrows[col]=(a,b)
assert len(library)==2 and sorted((len(lrows),len(rrows)))==[4,872]
right_index=defaultdict(list)
for (token,*suffix),z in rrows.items():
    right_index[token].append((suffix,z))
restored={}
for (*prefix,token),(a,b) in lrows.items():
    for suffix,(x,y) in right_index[token]:
        row=[None]*len(scope)
        for k,value in zip(L,prefix,strict=True):
            row[k]=value
        for k,value in zip(R,suffix,strict=True):
            row[k]=value
        key=tuple(row)
        assert key not in restored
        restored[key]=(a*x-b*y,a*y+b*x)
assert restored==rows
fresh=('QF',1,0)
assert fresh not in D
out=list(F)
out[1]=(left+(fresh,),lrows,1)
out.append(((fresh,)+right,rrows,den))
assert prod(d for _,_,d in F)==prod(d for _,_,d in out)
assert all(n==2 for n in Counter(w for A,_,_ in out for w in A).values())
with Path('split-state.pkl').open('xb') as stream:
    dump(dict(factors=out,used_before=2186112,physical_cut=state['physical_cut']),
         stream,protocol=5)
print('exact inverse reconstruction',len(restored),'rows',len(lrows),len(rrows),'rank',len(library),'denominator',den)
print('inherited products 2186112 validated original row-cap log; rejected pair work excluded')
print('left boundary',left,'right boundary',right)
for n in neighbors:
    B,Y,_=out[n]
    wires=tuple(w for w in left if w in B)
    if not wires:
        continue
    a=tuple(out[1][0].index(w) for w in wires)
    b=tuple(B.index(w) for w in wires)
    counts=Counter(project(row,b) for row in Y)
    print('post-split projected join',n,sum(counts[project(row,a)] for row in lrows),flush=True)
