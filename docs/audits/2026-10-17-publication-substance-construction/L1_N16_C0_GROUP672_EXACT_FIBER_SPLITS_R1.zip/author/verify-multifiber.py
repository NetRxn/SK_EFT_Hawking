from collections import Counter,defaultdict
from hashlib import sha256,file_digest
from math import prod
from pathlib import Path
from pickle import load,dumps
import sys

source,split,finish=map(Path,sys.argv[1:])
pins=('1af9a67813e00b5eeaebcc52600916ecf81b176fe5ef06ba74b01b3de1e3bb96',
      '2a3b6a2eb369c1ec3273dae2d2811a691144ffc2eccaed778141a4388bf407e4',
      '6a35a540eaee90864390f50ea052e170c6979978d53d8083979c2f77cdc26ae1')
def read(p,pin):
    with p.open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==pin
        stream.seek(0)
        return load(stream)
def digest(f):
    return sha256(dumps(f,protocol=5)).digest()
def multiply(a,b):
    p,q=a
    r,s=b
    return (p*r-q*s,p*s+q*r)
def contract(A,B):
    lhs,left,d=A
    rhs,right,e=B
    common=set(lhs)&set(rhs)
    keepL=tuple(w for w in lhs if w not in common)
    keepR=tuple(w for w in rhs if w not in common)
    common=tuple(sorted(common))
    def place(scope,axes):
        return tuple(scope.index(w) for w in axes)
    def key(row,indices):
        return tuple(row[i] for i in indices)
    i,j=place(lhs,common),place(rhs,common)
    a,b=place(lhs,keepL),place(rhs,keepR)
    by=defaultdict(list)
    for row,value in right.items():
        by[key(row,j)].append((key(row,b),value))
    out={}
    work=0
    for row,value in left.items():
        k=key(row,a)
        for tail,term in by.get(key(row,i),()):
            work+=1
            p,q=out.get(k+tail,(0,0))
            r,s=multiply(value,term)
            out[k+tail]=p+r,q+s
    return (keepL+keepR,{k:v for k,v in out.items() if any(v)},d*e),work
S=read(source,pins[0])
den=prod(d for _,_,d in S['factors'])
original={i:S['factors'][i] for i in (1,2,3)}
untouched={i:digest(f) for i,f in enumerate(S['factors']) if i not in original}
scope=S['physical_cut']
del S
C=read(split,pins[1])
assert C['physical_cut']==scope and C['used_before']==2186112
labels=C['factor_labels']
F=dict(zip(labels,C['factors'],strict=True))
assert len(F)==17 and prod(f[2] for f in F.values())==den
assert all(digest(F[i,0])==v for i,v in untouched.items())
for i,(old_axes,old_rows,d) in original.items():
    (axes,values,e),_=contract(F[i,0],F[i,1])
    inverse=tuple(axes.index(w) for w in old_axes)
    assert d==e and len(axes)==len(old_axes)==len(inverse)
    assert {tuple(row[p] for p in inverse):z for row,z in values.items()}==old_rows
    print('independent complete split reconstruction',i,len(values),'original denominator',d,flush=True)
del C
for a,b,key,expected in (((1,0),(2,1),(14,0),7168),
                         ((2,0),(3,0),(15,0),39360),
                         ((1,1),(14,0),(16,0),97664)):
    out,work=contract(F.pop(a),F.pop(b))
    assert work==expected
    F[key]=out
    print('independent join',a,b,key,work,len(out[1]),out[2],flush=True)
new={(15,0),(16,0)}
final={i:digest(f) for i,f in F.items() if i not in new}
signed={i:f for i,f in F.items() if i in new}
assert prod(f[2] for f in F.values())==den
assert set(Counter(w for a,_,_ in F.values() for w in a).values())=={2}
del F
R=read(finish,pins[2])
assert R['used_before']==2330304 and R['completed_this_run']==144192
assert R['physical_cut']==scope and prod(f[2] for f in R['factors'])==den
observed=dict(zip(R['factor_labels'],R['factors'],strict=True))
assert {i:digest(f) for i,f in observed.items() if i not in new}==final
assert {i:f for i,f in observed.items() if i in new}==signed
print('exact split/three-join signed factor readback and original denominator pass',den)
