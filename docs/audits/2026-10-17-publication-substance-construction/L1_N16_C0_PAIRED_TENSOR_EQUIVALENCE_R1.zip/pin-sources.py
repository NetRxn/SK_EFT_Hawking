from hashlib import sha256
from io import BytesIO
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile

from sources import ledger

pub=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
scope='docs/audits/2026-10-17-publication-substance-construction'
commit='12f7927a58cf7b20dd23143efa3dd56836f072bc'
groups={'PAIRED_C28':(28,),'PAIRED_NEIGHBORS':(29,30,31),'PAIRED_C24_C32':(32,),
        'PAIRED_C34_C36_C38':(34,36,38)}
def read_manifest(raw):
    lines=[line.split(maxsplit=1) for line in raw.decode().splitlines()]
    checks={name.removeprefix('./'):digest for digest,name in lines}
    assert len(checks)==len(lines)
    return checks
for group,cohort in groups.items():
    locator=f'{scope}/L1_N16_C0_DENSE_CHILD01_TUPLE0_{group}_R1.zip'
    stored=check_output(['git','-C',str(pub),'show',f'{commit}:{locator}'])
    assert stored==(pub/locator).read_bytes()
    blob=check_output(['git','-C',str(pub),'rev-parse',f'{commit}:{locator}']).decode().strip()
    print('archive',commit,blob,sha256(stored).hexdigest(),locator,sep='\t')
    with ZipFile(BytesIO(stored)) as arc:
        assert arc.testzip() is None
        manifest=read_manifest(arc.read('manifest.sha256'))
        for i in cohort:
            base='author/inner' if i==28 else f'author/{i}'
            known=f'{base}/author-case{i}.tsv'
            key=f'{base}/'+('operands.sha256' if i==28 else 'inner-operands.sha256')
            operands=arc.read(key)
            saved=arc.read(known)
            assert sha256(operands).hexdigest()==manifest[key] and sha256(saved).hexdigest()==manifest[known]
            audit=ledger(i)
            dst=next(iter(audit.values()))[0].parent
            assert saved==(dst/f'author-case{i}.tsv').read_bytes()
            table=read_manifest(operands)
            keys={p.name for p,*_ in audit.values()} | {f'slice-{i}.pkl' for i in range(9)} | {f'author-case{i}.tsv'}
            for name in sorted(keys):
                path=dst/name
                raw=sha256(path.read_bytes()).hexdigest()
                assert raw==(sha256(saved).hexdigest() if name==f'author-case{i}.tsv' else table[name])
                print('input',i,name,raw,sep='\t')
