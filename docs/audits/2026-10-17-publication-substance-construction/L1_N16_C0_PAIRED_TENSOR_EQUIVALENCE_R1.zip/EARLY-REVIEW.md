# Earlier-boundary follow-up for the same four paired-cut samples

For each of (28,30), (29,31), (32,36) and (34,38), six additional witnesses move the reuse boundary back to the initially conditioned seven-factor inputs. The mappings again swap 48 with 192 and fix other inner labels. The 16 cases at labels 80, 96, 144 and 160 verify on every original stored row. The eight cases at labels 48 and 192 first require exact pairwise shared-index support pruning. The checker verifies 5,301,992 retained rows per side. Positive factor denominators and balanced edge signs are preserved by the same termwise proof as the terminal witness.

At a pruning step, a removed row has a shared-edge tuple absent from its neighbor's current support. It cannot occur in any full matched configuration. Induction over these removals makes the fixed-point restriction contraction-preserving. The independent checker forms the support intersections simultaneously each round and verifies the signed map on the fixed point.

The twelve earlier-boundary searches at labels 3, 5 and 12 are undecided. Four rounds of magnitude refinement and deterministic relabeling did not find a map on their initially conditioned or first reduced inputs. These finite searches are not impossibility proofs. Use the already frozen terminal witnesses for these terms and retain the existing cap/restart proofs. This follow-up establishes no reusable map on the unpartitioned outer state.

The evidence is separate from the frozen 36-terminal manifest. Verify with `shasum -a 256 -c early-manifest.sha256` and rerun `python3 -B verify-early.py` on the pinned operands. No contraction was rerun.
