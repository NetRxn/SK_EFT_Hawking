# Exact reuse certificates for four paired-cut samples

All 36 corresponding terminal inputs admit a signed tensor equivalence for the four tested pairs (28,30), (29,31), (32,36) and (34,38). This is an exact certificate on the saved terminal inputs, after the previously verified partition and restart lineage. In each pair the nine inner coordinates agree under the involution swapping 48 and 192 and fixing all other inner coordinate labels. The archived ledgers have the same compatible outer-pair counts at each mapped inner coordinate.

Treat every shared set of degree-two wires between two factors as one edge with a tuple-valued index. The certificate gives a factor permutation and an edgewise bijection on entire index tuples, which may mix values within a shared set of wires. For 24 inner pairs that relabeling carries every Gaussian coefficient exactly. The 12 remaining certificates tag selected edge values with −1. Each endpoint of the edge receives the same tag. The product of the two tags is +1 in every fully matched configuration. Because each edge is incident to exactly two factors and relabeled consistently at both endpoints, the bijection gives one target matching configuration for every source matching configuration, with unchanged signed product. No quotient rows were dropped to obtain these 36 certificates. Some constituent wire arities or labels differ. The certificate operates on the entire shared tuple.

Every witness preserves the corresponding positive factor denominator term by term. The denominator product for all samples is `40512224221827380280140849737629696`. The same positive external normalization `1/(16*4^64)` is applied once. The independent checker audits the factor and edge bijections, row injectivity and surjectivity, and both Gaussian components for every stored nonzero row. Its output includes counts, raw numerator pairs recovered from the already accepted exact ledger and common normalization, and the published operand hashes. No terminal contraction was rerun.

The committed inputs are pinned to `12f7927a58cf7b20dd23143efa3dd56836f072bc`. The final continuity readback records publication map and source drift from other accepted work. The original owned neighboring archive retained blob `9a8df08f909c6a73a7ba76e5904670dfd7ea377e` and byte-identical live contents. The archived ledgers and both the terminal and initially conditioned source hashes are in `source-pins.tsv`.

The four tested pairs are the full scope of the result. It authorizes reuse only when these exact terminal inputs and the verified lineage remain bound. The witnesses establish no symmetry for other outer coordinates or for the original unpartitioned paired inputs. An earlier-stage investigation is separate.

From this directory, verify the frozen files and rerun the checker. The checker needs the original author inputs at the paths in `sources.py` or the same bytes restored into that layout.

```sh
shasum -a 256 -c terminal-manifest.sha256
python3 -B verify-witnesses.py > witness-readback.tsv
cmp checked-witnesses.tsv witness-readback.tsv
```
