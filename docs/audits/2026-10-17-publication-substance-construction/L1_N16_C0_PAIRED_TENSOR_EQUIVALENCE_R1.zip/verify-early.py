from csv import DictReader
from hashlib import sha256
from pathlib import Path
from pickle import dumps,loads
from runpy import run_path

from sources import ledger

checkpoint_checker=run_path('verify-witnesses.py')
verify=checkpoint_checker['verify']
pins=checkpoint_checker['pins']()

class MemoryOperand:
    def __init__(self,factors):
        self._contents=dumps({'factors':factors},protocol=5)
    def read_bytes(self):
        return self._contents

def prune(path):
    factors=loads(path.read_bytes())['factors']
    scopes=[s for s,_,_ in factors]
    edges=[]
    for i,A in enumerate(scopes):
        for j,B in enumerate(scopes[:i]):
            shared=sorted(set(A)&set(B))
            if shared:
                edges.append((i,j,tuple(A.index(x) for x in shared),tuple(B.index(x) for x in shared)))
    def projection(row,indices):
        return tuple(row[p] for p in indices)
    while True:
        restrictions=[[] for _ in factors]
        for i,j,p,q in edges:
            left={projection(r,p) for r in factors[i][1]}
            right={projection(r,q) for r in factors[j][1]}
            if left != right:
                common=left&right
                if left!=common: restrictions[i].append((p,common))
                if right!=common: restrictions[j].append((q,common))
        if not any(restrictions):
            return MemoryOperand(factors),sum(len(r) for _,r,_ in factors)
        factors=[(axes,{row:z for row,z in values.items()
                       if all(projection(row,pos) in allowed for pos,allowed in checks)},den)
                 for (axes,values,den),checks in zip(factors,restrictions,strict=True)]

def initial(case,key):
    terms=ledger(case)
    base=terms[key][0].parent
    line=next(r.split('\t') for r in (base/f'author-case{case}.tsv').read_text().splitlines()[:-1]
              if int(r.split('\t')[1])==key)
    return base/f'slice-{line[0]}.pkl'

print('left','right','inner_left','inner_right','boundary','left_sha256','right_sha256',
      'left_original_rows','right_original_rows','verified_rows_per_side','changed_sign_rows','certificate',sep='\t',flush=True)
with Path('early-gauge-screen.tsv').open() as source:
    rows=[r for r in DictReader(source,delimiter='\t') if r['map']=='True']
assert len(rows)==24
for row in rows:
    a,b,k,h=map(int,(row['left'],row['right'],row['left_inner'],row['right_inner']))
    cert=Path(f'witnesses-gauge/slice-{a}-{b}-{k}-{h}.pkl.gz')
    L,R=initial(a,k),initial(b,h)
    orig=[sum(len(values) for _,values,_ in loads(p.read_bytes())['factors']) for p in (L,R)]
    digests=[sha256(p.read_bytes()).hexdigest() for p in (L,R)]
    assert digests==[pins[a,L.name],pins[b,R.name]]
    trim=row['diagnostic'].startswith("('trim',")
    if trim:
        left,nl=prune(L)
        right,nr=prune(R)
        assert nl==nr and all(nl<c for c in orig)
    else:
        left,right=L,R
    _,_,_,_,exact,flipped=verify(left,right,cert,True)
    print(a,b,k,h,'support-pruned' if trim else 'original slice',*digests,*orig,exact,flipped,cert,sep='\t',flush=True)
