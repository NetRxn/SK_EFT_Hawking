from concurrent.futures import ProcessPoolExecutor
from csv import DictReader
from gzip import open as compress
from pathlib import Path
from pickle import dump
from time import perf_counter

from sources import ledger,swap
from signed_gauge import search_gauge,model

def run(job):
    l,r,k,stage=job
    rk=swap.get(k,k)
    F,G=ledger(l),ledger(r)
    x,y=F[k][0],G[rk][0]
    if stage in ('slice','reduced-slice'):
        for side,p,key in ((l,x,k),(r,y,rk)):
            line=next(row.split('\t') for row in (p.parent/f'author-case{side}.tsv').read_text().splitlines()[:-1] if int(row.split('\t')[1])==key)
            name=f'slice-{line[0]}.pkl' if stage=='slice' else f'label-slice-{line[0]}-reduced-frontier.pkl'
            if side==l: x=p.parent/name
            else: y=p.parent/name
    t=perf_counter()
    proof,outcome=search_gauge(model(x),model(y))
    if proof is not None:
        with compress(Path('witnesses-gauge')/f'{stage}-{l}-{r}-{k}-{rk}.pkl.gz','wb',compresslevel=1) as out:
            dump(proof,out,protocol=5)
    return l,r,k,rk,stage,bool(proof),round(perf_counter()-t,5),repr(outcome)

if __name__=='__main__':
    import sys
    stage=sys.argv[1]
    with Path('edge-screen.tsv').open() as f:
        jobs=[tuple(map(int,(p['left'],p['right'],p['left_inner'])))+(stage,)
              for p in DictReader(f,delimiter='\t') if int(p['left_inner']) in (3,5,12)]
    print('left','right','left_inner','right_inner','stage','map','seconds','diagnostic',sep='\t')
    with ProcessPoolExecutor(max_workers=3) as workers:
        for row in workers.map(run,jobs):
            print(*row,sep='\t',flush=True)
