from concurrent.futures import ProcessPoolExecutor
from gzip import open as compress
from hashlib import sha256
from pathlib import Path
from pickle import dump
from time import perf_counter

from edge_relabel import search, model
from sources import PAIRS, ledger, swap

def run(job):
    left,right,key,other,left_file,right_file,cost,real,imag=job
    time=perf_counter()
    result,proof=search(model(left_file),model(right_file))
    digits=[sha256(path.read_bytes()).hexdigest() for path in (left_file,right_file)]
    if result:
        with compress(Path('witnesses')/f'{left}-{right}-{key}-{other}.pkl.gz','wb',compresslevel=1) as out:
            dump(result,out,protocol=5)
    return (left,right,key,other,cost,real,imag,bool(result),*digits,round(perf_counter()-time,5),repr(proof))

if __name__=='__main__':
    jobs=[]
    for a,b in PAIRS:
        left,right=ledger(a),ledger(b)
        for key in sorted(left):
            other=swap.get(key,key)
            l,p,r,i=left[key]
            k,q,s,j=right[other]
            assert (p,r,i)==(q,s,j)
            jobs.append((a,b,key,other,l,k,p,r,i))
    Path('witnesses').mkdir(exist_ok=True)
    print('left','right','left_inner','right_inner','screen_products','real','imaginary','map','left_sha256','right_sha256','seconds','diagnostic',sep='\t')
    with ProcessPoolExecutor(max_workers=4) as pool:
        for row in pool.map(run,jobs):
            print(*row,sep='\t',flush=True)
