"""Compare a planar compact density bracket with an independently applied discrete full generator."""
import json
import numpy as np

def bump(t, radius):
    s = t / radius
    inside = np.abs(s) < 1
    d = np.where(inside, 1 - s*s, 1)
    b = np.where(inside, np.exp(-1 / d), 0)
    log_prime = -2*s / (d*d)
    log_second = -2 / (d*d) - 8*s*s / (d*d*d)
    return b, b*log_prime/radius, b*(log_second + log_prime**2)/radius**2

def run(n, q):
    length = 8.0
    dx = length/n
    grid = np.linspace(-length/2, length/2, n, endpoint=False)
    x, y = grid[:, None], grid[None, :]
    fx, fpx, fppx = bump(x, 1.7)
    fy, fpy, fppy = bump(y, 1.5)
    f = fx*fy
    ux, upx, _ = bump(x-.27, 1.55)
    uy, upy, _ = bump(y+.13, 1.4)
    phase = np.exp(1j*(q*x-1.31*y))
    u = ux*uy*phase
    dux = (upx+1j*q*ux)*uy*phase
    duy = ux*(upy-1.31j*uy)*phase
    a, ax = .37, .013
    v = ux*uy*np.exp(1j*(.83*x+.41*y))
    vp = .2*np.cos(x)+.07*np.sin(y)
    vx = .11*np.sin(x-y)
    rabi = .43 + .19j*np.sin(x+.7*y)
    g = np.exp(-x*x-y*y) * np.exp(1j*(1.2*x+.3*y))
    g = g / (dx*np.linalg.norm(g))
    omega = np.linspace(.04, 8, 113)
    dw = omega[1]-omega[0]
    w = .2*omega*np.exp(-omega)*np.exp(.37j*omega)
    beta = .13*np.exp(-omega)*np.exp(-.18j*omega)

    def port(z): return w*(dx*dx*np.vdot(g,z))
    def port_adj(z): return g*(dw*np.vdot(w,z))
    def m(s):
        z1,z2,z3 = s
        return f*z1, np.zeros_like(z2), np.zeros_like(z3)
    def kinetic(z, method):
        if method == "fft":
            freq = 2*np.pi*np.fft.fftfreq(n, dx)
            return np.fft.ifft2((freq[:,None]**2+freq[None,:]**2)*np.fft.fft2(z))
        # Minus the fourth-order central second difference on each axis.
        return sum((np.roll(z,2,i)-16*np.roll(z,1,i)+30*z
                    -16*np.roll(z,-1,i)+np.roll(z,-2,i))/(12*dx*dx) for i in (0,1))
    def k(s, method):
        z1,z2,z3 = s
        return (a*kinetic(z1,method)+vp*z1+rabi*z2+port_adj(z3),
                ax*kinetic(z2,method)+vx*z2+np.conj(rabi)*z1,
                omega*z3+port(z1))
    def diff(s,t): return tuple(i-j for i,j in zip(s,t))
    def norm(s):
        return np.sqrt(dx*dx*(np.linalg.norm(s[0])**2+np.linalg.norm(s[1])**2)+dw*np.linalg.norm(s[2])**2)
    def bracket(s,method): return diff(k(m(s),method),m(k(s,method)))

    cf = -a*((fppx*fy+fx*fppy)*u+2*fpx*fy*dux+2*fx*fpy*duy)
    expected = (cf-f*(rabi*v+port_adj(beta)),np.conj(rabi)*f*u,port(f*u))
    err = {method: float(norm(diff(bracket((u,v,beta),method),expected))/norm(expected))
           for method in ("fft","stencil")}
    for method in err:
        assert norm(bracket((np.zeros_like(u),np.zeros_like(v),np.zeros_like(beta)),method)) == 0
    assert norm((np.zeros_like(u),expected[1],expected[2])) > 0
    # Constant total identity has vanishing bracket. A constant photon projector retains exchange.
    identity_state = (u,v,beta)
    def identity(s): return s
    assert norm(diff(k(identity(identity_state),"fft"),identity(k(identity_state,"fft")))) == 0
    project = (u, np.zeros_like(v), np.zeros_like(beta))
    def photon(s):
        return s[0], np.zeros_like(s[1]), np.zeros_like(s[2])
    kproject = k(project,"fft")
    projector_bracket = diff(kproject,photon(k((u,v,beta),"fft")))
    projector_expected = (-(rabi*v+port_adj(beta)),np.conj(rabi)*u,port(u))
    assert norm(diff(projector_bracket,projector_expected)) < 2e-12
    assert norm(projector_expected) > 0
    return err, float(norm((cf,np.zeros_like(v),np.zeros_like(beta)))/(dx*np.linalg.norm(u)))

results = {str(n):run(n,5.37)[0] for n in (64,128,256,512,1024)}
assert results["1024"]["fft"] < 1e-8
assert results["1024"]["stencil"] < results["512"]["stencil"]/10
growth = {str(q):run(512,q)[1] for q in (0,8,16,32,64)}
assert growth["64"] > 6*growth["8"]
print(json.dumps({"grid_errors":results,"normalized_analytic_photon_bracket":growth,
                  "scope":"nondimensional compact packets on periodic numerical padding; positive-frequency rectangular bath quadrature; no continuum regulator error certification or measured calibration"},indent=2))
