# Coupled planar density bracket numerical controls

Run `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -B planar_bracket.py`
with the project's existing NumPy environment. Compare stdout with
`planar_bracket.json`. Exact last bits can vary by platform and library build.
The assertions check the stipulated comparisons without requiring bitwise
identity across environments.

The spatial test uses smoothly supported packets on a numerically padded
periodic square. The bath is a fixed positive-frequency quadrature. The
Fourier and fourth-order spatial stencil apply both full bracket compositions
independently of the analytic derivatives. This fixture does not measure
physical device response or supply an estimate uniform in modulation.
