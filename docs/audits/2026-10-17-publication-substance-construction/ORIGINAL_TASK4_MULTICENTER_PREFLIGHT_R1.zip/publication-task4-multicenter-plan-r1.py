"""Bounded original N16 geometry and shared-factor coefficient controls."""
from collections import Counter
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, product
from pathlib import Path
import json
import sys

HERE = Path(__file__).parent
spec = spec_from_file_location("multicenter_r4_inputs", HERE / "publication-task4-later-full-vertex-r4.py")
r4 = module_from_spec(spec)
sys.modules[spec.name] = r4
spec.loader.exec_module(r4)
f, o = r4.f, r4.o
E, P, Q, S = r4.E, r4.P, r4.Q, r4.S
WORK_CAP = 30_000
PAIR_CAP = 4096
work = Counter()

def charge(name, amount=1):
    if sum(work.values()) + amount > WORK_CAP:
        raise RuntimeError(f"preflight work cap on {name} at prospective {sum(work.values()) + amount}")
    work[name] += amount

def anchors_of(symbols):
    return {(s.index[0], s.index[1]) for s in symbols if s.family == "q"}

def anchored_link(anchor):
    return f.original_spin4_link(*(
        tuple(P.variable(S("q", (*anchor, hand, coord))) for coord in range(4))
        for hand in ("L", "R")
    ))

def plaquette_anchors(reg, site, k, l):
    return ((site,k),(reg.step(site,k)[0],l),(reg.step(site,l)[0],k),(site,l))

def trace(reg, site, k, l, mu, nu, a, b):
    """The four ordered contributions at one selected grouped S2 branch."""
    anchors = {
        anchor for pair in ((k, l), (l, k))
        for anchor in plaquette_anchors(reg, site, *pair)
    }
    links = {anchor: anchored_link(anchor) for anchor in sorted(anchors)}
    raw = []
    for first, second in ((k, l), (l, k)):
        plaquette = f.original_plaquette(reg, site, first, second, links)
        for c, d, left, right in ((mu, nu, a, b), (nu, mu, b, a)):
            charge("ordered_trace_entries", 16)
            gamma = o.matrix_multiply(o.matrix_multiply(reg.gamma[left], reg.gamma[right]), reg.gamma5)
            p = sum((plaquette[i][j] * gamma[j][i] for i in range(4) for j in range(4)), P())
            raw.append(p * Fraction(o.epsilon((first, second, c, d)), 4))
    grouped = sum(raw, P())
    assert grouped and len(grouped.terms) == 128
    assert all(p == grouped * Fraction(1, 4) for p in raw)
    return grouped, anchors

def coefficient(poly, mask, key):
    for (m,s,_),value in r4.rows(poly):
        charge("canonical_output_scan")
        if m == mask and s == key:
            return value
    return Q(0)

def symbol_info(key):
    return [(s.family, s.index) for s in key]

def sign_independent(a, b):
    return (-1) ** sum(i > j for i in range(a.bit_length()) if a >> i & 1
                      for j in range(b.bit_length()) if b >> j & 1)

def coframe_control(reg, w, z):
    left = r4.exterior(reg, (w, 0, 0))
    right = r4.exterior(reg, (z, 0, 0))
    aa = list(r4.rows(left))
    bb = list(r4.rows(right))
    assert len(aa) * len(bb) == PAIR_CAP
    charge("actual_coframe_pairs", len(aa) * len(bb))
    canonical = left * right
    overlap = None
    candidates = {}
    charge("collision_scan_pairs", len(aa) * len(bb))
    for ((am, ak, _), av), ((bm, bk, _), bv) in product(aa, bb):
        if am & bm:
            overlap = (am, bm, ak, bk, av, bv)
            continue
        if ak != bk:
            continue
        key = am | bm, tuple(sorted(ak + bk))
        candidates.setdefault(key, (am, bm, av, bv))
    assert overlap is not None
    am, bm, ak, bk, av, bv = overlap
    assert E(((am, P(((ak, av),))),)) * E(((bm, P(((bk, bv),))),)) == E()
    for (mask, key), (am, bm, av, bv) in candidates.items():
        value = coefficient(canonical, mask, key)
        if not value:
            continue
        total = Q(0)
        matches = 0
        for ((lm, lk, _), lv), ((rm, rk, _), rv) in product(aa, bb):
            charge("direct_coframe_coeff_pairs")
            if lm & rm or lm | rm != mask or tuple(sorted(lk + rk)) != key:
                continue
            total += lv * rv * sign_independent(lm, rm)
            matches += 1
        assert total == value and matches >= 1
        assert (E(((am, P(((key[:1], av),))),))
                * E(((bm, P(((key[1:], bv),))),))) != E()
        return dict(exact_mask=hex(mask), exact_symbols=symbol_info(key),
                    exact_coefficient=str(value), matching_ordered_pairs=matches,
                    overlap_masks=[hex(overlap[0]),hex(overlap[1])],
                    overlap_symbols=[symbol_info(overlap[2]),symbol_info(overlap[3])],
                    survival_masks=[hex(am),hex(bm)])
    raise AssertionError("no surviving repeated-coordinate coframe coefficient")

def distinct_trace_collision(reg, w, z):
    # Curvature now uses axis 0, so the collision is in actual closed
    # plaquette traces rather than just the reciprocal coframes.
    a, b = 0, 1
    left, a_anchors = trace(reg, w, 0, 1, 2, 3, a, b)
    right, b_anchors = trace(reg, z, 0, 1, 2, 3, a, b)
    shared = a_anchors & b_anchors
    assert shared == {(w,1),(z,1)}
    factors = [r4.exterior(reg, (site, axis, flavor))
               for site in (w,z) for axis,flavor in ((2,a),(3,b))]
    occupied = 0
    picked = []
    for factor in factors:
        for (mask, key, _), value in r4.rows(factor):
            charge("actual_disjoint_coframe_rows")
            if not mask & occupied:
                picked.append((mask,key,value))
                occupied |= mask
                break
        else:
            raise AssertionError("no disjoint source path")
    for (lk, lv), (rk, rv) in product(left.terms, right.terms):
        charge("curvature_collision_paths")
        repeated = [s for s in set(lk) & set(rk) if (s.index[0],s.index[1]) in shared]
        if repeated:
            masks = [entry[0] for entry in picked]
            assert sum(mask.bit_count() for mask in masks) == occupied.bit_count() == 8
            term = lv * rv
            prefix = 0
            for mask, _, value in picked:
                term *= value * sign_independent(prefix, mask)
                prefix |= mask
            assert term
            return dict(left_anchors=sorted(a_anchors),right_anchors=sorted(b_anchors),
                        shared=sorted(shared), repeated=symbol_info(sorted(repeated)),
                        trace_degrees=[len(lk),len(rk)], exterior_mask=hex(occupied),
                        trace_symbols=[symbol_info(lk),symbol_info(rk)],
                        coframe_masks=[hex(mask) for mask in masks],
                        coframe_symbols=[symbol_info(key) for _,key,_ in picked],
                        branch_path_coefficient=str(term), full_coefficient_computed=False)
    raise AssertionError("no actual trace collision")

def topology(reg, sites):
    def source(site):
        center_star = {site, *(reg.step(site, axis)[0] for axis in range(4))}
        coframe_links = {(site, axis) for axis in range(4)} | {
            (reg.step(site, axis, -1)[0], axis) for axis in range(4)
        }
        curvature_links = {
            anchor for k,l in product(range(4), repeat=2) if k != l
            for anchor in plaquette_anchors(reg, site, k, l)
        }
        return center_star, coframe_links, curvature_links
    sets = {name: source(site) for name,site in sites.items()}
    assert all(tuple(map(len, groups)) == (5,8,16) for groups in sets.values())
    pairs = {}
    for a,b in combinations(sites,2):
        p,q = sets[a],sets[b]
        pairs[a+b] = dict(shared_exterior_sites=sorted(p[0]&q[0]),
                          shared_coframe_anchors=sorted(p[1]&q[1]),
                          shared_curvature_anchors=sorted(p[2]&q[2]),
                          shared_total_anchors=sorted((p[1]|p[2])&(q[1]|q[2])))
    return pairs

def main():
    reg = o.OriginalRegulator()
    x = reg.sites[0]
    y = reg.step(x,0)[0]
    w = reg.step(x,2)[0]
    z = reg.step(w,0)[0]
    sites = dict(x=x,y=y,w=w,z=z)
    pairs = topology(reg, sites)
    assert pairs["wz"]["shared_exterior_sites"] == [w,z]
    assert pairs["wz"]["shared_coframe_anchors"] == [(w,0),(z,0)]
    assert len(pairs["wz"]["shared_total_anchors"]) == 8
    cf = coframe_control(reg,w,z)
    trace_witness = distinct_trace_collision(reg,w,z)
    print(json.dumps(dict(sites=sites, extents=reg.extents, convention=reg.convention,
        word=reg.word, pairs=pairs, coframe_control=cf, curvature_path=trace_witness,
        charged_work=dict(work), total=sum(work.values()), work_cap=WORK_CAP,
        coframe_pair_cap=PAIR_CAP),indent=2))
if __name__ == "__main__":
    main()
