from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

parent = str(Path(sys.argv[1]).resolve())

def run(index):
    tag = f'slice-{index}'
    for script, arguments, label in [
        ('exact-multicut.py',[parent,f'{tag}.pkl',str(index)],'plan'),
        ('reduce-label-frontier.py',[f'{tag}.pkl',tag],'reduce'),
        ('contract-reduced-label.py',[tag],'contract'),
    ]:
        receipt = Path(f'{tag}-{label}.out')
        with receipt.open('xb') as output:
            result = subprocess.run([sys.executable,'-u',script,*arguments],
                                    stdout=output,stderr=subprocess.STDOUT,timeout=180)
        allowed = (0,2) if label == 'contract' else (0,)
        assert result.returncode in allowed,(index,label,result.returncode)
    print(index,result.returncode,receipt.read_text().splitlines()[-1],sep='\t',flush=True)

with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run,range(9)))
