from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path
import pickle,sys

root=Path(__file__).resolve().parent
exec((root/'checkpoint/quotient.py').read_text().split('\nlocal_test()\n',1)[0])
local_test()
with (root/sys.argv[1]).open('rb') as handle:
    checkpoint=pickle.load(handle)
factors=checkpoint['factors']
assert 2 <= len(factors) <= 9
domains=defaultdict(list)
for axes,rows,_ in factors:
    assert rows
    for position,wire in enumerate(axes):
        domains[wire].append({row[position] for row in rows})
fixed={wire:next(iter(sets[0])) for wire,sets in domains.items()
       if len(sets[0])==1 and all(values==sets[0] for values in sets)}
reduced=[]
for axes,rows,denominator in factors:
    positions=[position for position,wire in enumerate(axes) if wire not in fixed]
    selected={tuple(row[position] for position in positions):z for row,z in rows.items()}
    assert len(selected)==len(rows)
    reduced.append((tuple(axes[position] for position in positions),selected,denominator))
checkpoint['factors']=factors=reduced
checkpoint['second_stripped_fixed_coordinates']=fixed
print('singleton reduction',len(fixed),'indices','widths',[len(axes) for axes,_,_ in factors],flush=True)
degree=Counter(wire for axes,_,_ in factors for wire in axes)
assert all(count==2 for count in degree.values())
visits=0
for stage in range(2):
    before=sum(len(rows) for _,rows,_ in factors)
    removed=0
    for i,j in combinations(range(len(factors)),2):
        for a,b in ((i,j),(j,i)):
            visits+=len(factors[a][1])+len(factors[b][1])
            assert visits<=60000000
            factors[a],factors[b],count=quotient(factors[a],factors[b],degree)
            removed+=count
    after=sum(len(rows) for _,rows,_ in factors)
    print('quotient sweep',stage,before,'to',after,'folded',removed,flush=True)
    if after==before and removed==0:
        break
with (root/f'label-{sys.argv[2]}-reduced-frontier.pkl').open('xb') as handle:
    pickle.dump(checkpoint,handle,protocol=5)
