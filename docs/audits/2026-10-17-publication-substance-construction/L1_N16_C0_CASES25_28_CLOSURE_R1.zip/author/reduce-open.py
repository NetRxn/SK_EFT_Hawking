from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
import time

def solve(index):
    initial=f'slice-{index}'
    if Path(f'{initial}-contract.out').read_text().splitlines()[-1].startswith('exact normalized '):
        return
    tag=initial
    started=time.monotonic()
    for phase in range(2):
        checkpoints=list(Path('.').glob(f'*-dense-label-{tag}-reduced.pkl'))
        assert len(checkpoints)==1,(index,phase,checkpoints)
        tag=f'rescue-{index}-{phase}'
        for script,args,suffix in [
            ('reduce-label-frontier.py',[str(checkpoints[0]),tag],'reduce'),
            ('contract-peer.py',[tag],'contract'),
        ]:
            receipt=Path(f'{tag}-{suffix}.out')
            with receipt.open('xb') as out:
                result=subprocess.run([sys.executable,'-u',script,*args],stdout=out,
                                      stderr=subprocess.STDOUT,timeout=150)
            allowed=(0,2) if suffix=='contract' else (0,)
            assert result.returncode in allowed,(index,phase,suffix,result.returncode)
        if result.returncode==0:
            break
    print(index,result.returncode,round(time.monotonic()-started,3),
          receipt.read_text().splitlines()[-1],sep='\t',flush=True)

with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(solve,map(int,sys.argv[1:])))
