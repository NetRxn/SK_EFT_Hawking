# Independent sparse Gaussian integer contraction. No author function imported.
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
from math import prod
from fractions import Fraction
import pickle,time,sys
started=time.monotonic()
with Path(sys.argv[1]).open('rb') as f: checkpoint=pickle.load(f)
fs=checkpoint['factors'];denominator=prod(d for a,r,d in fs)
assert not any(k[0]=='L' for a,r,d in fs for k in a)
assert all(v==2 for v in Counter(k for a,r,d in fs for k in a).values())
spent=0
while len(fs)>1:
    forecasts=[]
    for i,j in combinations(range(len(fs)),2):
        a,r,_=fs[i];b,s,_=fs[j];shared=set(a)&set(b);order=sorted(shared)
        ix=[a.index(k) for k in order];jx=[b.index(k) for k in order]
        counts=Counter(tuple(row[p] for p in jx) for row in s)
        n=sum(counts[tuple(row[p] for p in ix)] for row in r)
        forecasts.append((n,i,j,ix,jx))
    n,i,j,ix,jx=min(forecasts)
    print("forecast",n,i,j,"prior",spent,flush=True)
    if len(fs)==3:
        # For degree-two indices, each remaining coordinate belongs to just
        # one pair of factors. Intersect adjacency supports before multiplying.
        from operator import itemgetter
        A,B,C=fs
        x=tuple(sorted(set(A[0])&set(B[0])))
        y=tuple(sorted(set(A[0])&set(C[0])))
        z=tuple(sorted(set(B[0])&set(C[0])))
        assert all(len(axes)==len(set(axes)) for axes,_,_ in fs)
        assert set(x)|set(y)==set(A[0]) and set(x)|set(z)==set(B[0]) and set(y)|set(z)==set(C[0])
        def projector(axes, edge):
            where=tuple(axes.index(k) for k in edge)
            return lambda row:tuple(row[p] for p in where)
        def adjacency(factor, first, second):
            axes,rows,_ = factor
            key=projector(axes,first)
            tail=projector(axes,second)
            index=defaultdict(dict)
            for row,entry in rows.items():
                k,t=key(row),tail(row)
                assert t not in index[k]
                index[k][t]=entry
            return index
        bx,cy=adjacency(B,x,z),adjacency(C,y,z)
        akey,atail=projector(A[0],x),projector(A[0],y)
        probes=0
        triangles=0
        real=imaginary=0
        for row,(a,b) in A[1].items():
            bs,cs=bx[akey(row)],cy[atail(row)]
            probes+=min(len(bs),len(cs))
            assert probes<=30000000
            for tail in bs.keys() & cs.keys():
                triangles+=1
                assert spent+triangles*2<=30000000
                c,d=bs[tail]
                e,f=cs[tail]
                re,im=a*c-b*d,a*d+b*c
                real+=re*e-im*f
                imaginary+=re*f+im*e
            assert time.monotonic()-started<60
        spent+=triangles*2
        print('triangle closure',triangles,'nonzero-support triples',probes,'bounded probes','products',triangles*2,'output rows',1,flush=True)
        fs=[((),{():(real,imaginary)},prod(factor[2] for factor in fs))]
        break
    assert n<=8000000 and spent+n<=30000000
    assert time.monotonic()-started<60
    a,r,d=fs[i];b,s,e=fs[j];li=[p for p in range(len(a)) if p not in ix];ri=[p for p in range(len(b)) if p not in jx]
    axes=tuple(a[p] for p in li)+tuple(b[p] for p in ri)
    buckets=defaultdict(list)
    for row,z in s.items():buckets[tuple(row[p] for p in jx)].append((tuple(row[p] for p in ri),z))
    out={};seen=0
    for row,(x,y) in r.items():
        prefix=tuple(row[p] for p in li)
        for suffix,(u,v) in buckets[tuple(row[p] for p in ix)]:
            seen+=1;key=prefix+suffix;old=out.get(key,(0,0));z=old[0]+x*u-y*v,old[1]+x*v+y*u
            if any(z):out[key]=z
            else:out.pop(key,None)
            assert len(out)<=1000000
            if seen%32768==0:assert time.monotonic()-started<60
    assert seen==n;spent+=n
    print('independent join',i,j,'products',n,'output rows',len(out),'remaining',len(fs)-1,flush=True)
    fs=[f for p,f in enumerate(fs) if p not in (i,j)]+[(axes,out,d*e)]
a,r,d=fs[0];assert not a and d==denominator
re,im=r.get((),(0,0));actual=Fraction(re,d*16*4**64);imag=Fraction(im,d*16*4**64)
print('raw scalar numerator',re,'imaginary',im,'factor denominator',d)
print('exact normalized real',actual,'imaginary',imag,'independent matched products',spent,'wall seconds',round(time.monotonic()-started,4))
print('conditioning',checkpoint['conditioning'],'label partition',checkpoint['label_partition'])
