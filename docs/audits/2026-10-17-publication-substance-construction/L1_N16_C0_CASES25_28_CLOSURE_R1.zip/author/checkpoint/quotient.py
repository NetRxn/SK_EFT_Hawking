from collections import defaultdict,Counter
from math import gcd
from pathlib import Path
import pickle

def rotate(a,b,n):
    return ((a,b),(-b,a),(-a,-b),(b,-a))[n]

def project(row,indices):
    return tuple(row[i] for i in indices)

def quotient(left,right,degrees):
    la,L,ld=left
    ra,R,rd=right
    shared=tuple(w for w in la if w in ra)
    closed=tuple(w for w in shared if w[0]!='L' and degrees[w]==2)
    boundary=tuple(w for w in shared if w not in closed)
    private=tuple(w for w in la if w not in shared)
    if not closed:
        return left,right,0
    # Never move coefficients between different shared boundary labels.
    li=tuple(la.index(w) for w in shared)
    ri=tuple(ra.index(w) for w in shared)
    lr=tuple(la.index(w) for w in private)
    bi=tuple(shared.index(w) for w in boundary)
    other=tuple(w for w in ra if w not in shared)
    ro=tuple(ra.index(w) for w in other)
    keys={project(row,ri) for row in R}
    slices=defaultdict(list)
    for row,(a,b) in L.items():
        key=project(row,li)
        if key in keys:
            slices[key].append((project(row,lr),a,b))
    equivalence={}
    aliases={}
    for key,items in sorted(slices.items()):
        items.sort()
        g=0
        for _,a,b in items:
            g=gcd(g,gcd(a,b))
            if g==1:
                break
        assert g>0
        _,a,b=items[0]
        phase=max(range(4),key=lambda j:rotate(a,b,j))
        signature=tuple((pos,*rotate(x//g,y//g,phase)) for pos,x,y in items)
        dst=equivalence.setdefault((project(key,bi),signature),key)
        aliases[key]=(dst,*rotate(g,0,(-phase)%4))
    if len(equivalence)==len(slices)==len(keys):
        return left,right,0
    outL={dst+pos:(a,b) for (_,signature),dst in equivalence.items() for pos,a,b in signature}
    outR={}
    for row,(a,b) in R.items():
        alias=aliases.get(project(row,ri))
        if alias is None:
            continue
        dst,x,y=alias
        key=dst+project(row,ro)
        r,n=outR.get(key,(0,0))
        z=r+a*x-b*y,n+a*y+b*x
        if any(z):
            outR[key]=z
        else:
            outR.pop(key,None)
    return (shared+private,outL,ld),(shared+other,outR,rd),len(slices)-len(equivalence)

def local_test():
    u=('L',0); p=('G',0); x=('W',0)
    left=((u,p,x),{(0,1,2):(2,0),(0,2,2):(0,4),(1,1,2):(2,0)},1)
    right=((u,p),{(0,1):(3,0),(0,2):(5,0),(1,1):(7,0)},1)
    a,b,m=quotient(left,right,Counter({u:3,p:2,x:1}))
    assert m==1
    def literal(a,b):
        A,L,_=a;B,R,_=b
        ans=defaultdict(lambda:(0,0))
        for row,(x,y) in L.items():
            s=dict(zip(A,row))
            for col,(r,t) in R.items():
                d=dict(zip(B,col))
                if all(d[k]==s[k] for k in set(A)&set(B)):
                    key=s[u],s[('W',0)]
                    d0,d1=ans[key]
                    ans[key]=d0+x*r-y*t,d1+x*t+y*r
        return ans
    assert literal(a,b)==literal(left,right)=={(0,2):(6,20),(1,2):(14,0)}
local_test()
path=Path('row-cap-branch-0.pkl')
with path.open('rb') as f:
    data=pickle.load(f)
F=data['factors']
i,j=data['rejected_pair']
degrees=Counter(k for axes,_,_ in F for k in axes)
for x,y in ((i,j),(j,i),(i,j)):
    before=len(F[x][1]),len(F[y][1])
    F[x],F[y],n=quotient(F[x],F[y],degrees)
    print('quotient',x,y,before,'after',len(F[x][1]),len(F[y][1]),'coalesced slices',n,flush=True)
shared=tuple(k for k in F[i][0] if k in F[j][0])
def histogram(f):
    axes,rows,_=f
    where=[axes.index(k) for k in shared]
    return Counter(project(row,where) for row in rows)
left,right=histogram(F[i]),histogram(F[j])
work=sum(n*right[key] for key,n in left.items())
assert work<=data['matched']
print('blocked join matches',data['matched'],'to',work,flush=True)
data['matched']=work
with Path('quotient-frontier.pkl').open('wb') as f:
    pickle.dump(data,f,protocol=5)
