from collections import defaultdict
from itertools import combinations

def pair_checks(factors, excluded, output_axes, product_cap=1_000_000):
    checks = []
    peers = [i for i in range(len(factors)) if i not in excluded]
    for a, b in combinations(peers, 2):
        left_axes, left_rows, _ = factors[a]
        right_axes, right_rows, _ = factors[b]
        shared = tuple(k for k in left_axes if k in right_axes)
        left_out = tuple(k for k in left_axes if k in output_axes)
        right_out = tuple(k for k in right_axes if k in output_axes)
        if not shared or not left_out or not right_out:
            continue
        assert not set(left_out) & set(right_out)
        def buckets(axes, rows, boundary):
            shared_positions = tuple(axes.index(k) for k in shared)
            boundary_positions = tuple(axes.index(k) for k in boundary)
            result = defaultdict(set)
            for row in rows:
                key = tuple(row[i] for i in shared_positions)
                result[key].add(tuple(row[i] for i in boundary_positions))
            return result
        left = buckets(left_axes,left_rows,left_out)
        right = buckets(right_axes,right_rows,right_out)
        common = left.keys() & right.keys()
        products = sum(len(left[k])*len(right[k]) for k in common)
        if products > product_cap:
            continue
        allowed = {x+y for k in common for x in left[k] for y in right[k]}
        checks.append((tuple(output_axes.index(k) for k in left_out+right_out),allowed))
        print('peer pair support',a,b,'projected products',products,'allowed',len(allowed),flush=True)
    return checks
