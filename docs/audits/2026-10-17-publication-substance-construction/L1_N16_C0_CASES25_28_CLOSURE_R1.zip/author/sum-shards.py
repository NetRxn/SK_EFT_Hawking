from fractions import Fraction
from pathlib import Path
import re
import sys

case, count = map(int,sys.argv[1:])
assert count > 0
real = imaginary = end = 0
parent_rows = denominator = None
max_arithmetic = max_probes = 0
for i in range(count):
    receipt = Path(f'slice-{case}-shard-{i}.out').read_text()
    low, high, total, shard, roster = map(int, re.search(
        r'^left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)$',
        receipt,re.M).groups())
    assert shard == i and roster == count
    assert low == end == total*i//count and high == total*(i+1)//count
    assert parent_rows is None or parent_rows == total
    parent_rows,end = total,high
    matches, retained, probes, re_int, im_int, den = map(int,re.search(
        r'^closure products (\d+) retained outer matches (\d+) closure probes (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)$',
        receipt,re.M).groups())
    assert denominator is None or denominator == den
    denominator = den
    assert re.search(r'^exact normalized real .* imaginary .* seconds ',receipt,re.M)
    assert re.search(r'^conditioning .* label partition ',receipt,re.M)
    real += re_int
    imaginary += im_int
    max_arithmetic = max(max_arithmetic,matches+2*retained)
    max_probes = max(max_probes,probes)
assert end == parent_rows
print('complete shards',count,'left rows',parent_rows,'raw',real,imaginary,'factor denominator',denominator)
print('maximum shard arithmetic',max_arithmetic,'maximum closure probes',max_probes)
scale=denominator*16*4**64
print('exact normalized real',Fraction(real,scale),'imaginary',Fraction(imaginary,scale))
