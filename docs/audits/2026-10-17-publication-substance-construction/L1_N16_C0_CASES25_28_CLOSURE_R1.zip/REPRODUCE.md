# L1 N16 dense outer case 25

Original scientific source 51e7c745e, publication parent cdd9b80ff. Case 25 lies in the first binary child of tuple 0 in descendant (0,0). The scientific claim here concerns one conditioned contribution.

Restore `row-cap-physical-slice-dense-label-case-25-2-reduced.pkl` from `L1_N16_C0_CASES17_23_CLOSURE_R1.zip` using the original archived eight-factor parent and `next-frontiers` instructions. The decompressed seven-factor file has SHA256 `67b0b0415d281046b9db72ba5cefb40cdbf84d45c40fe9f6adc8586581d149c5`. Deserialize only trusted checkpoint inputs.

Use a fresh scratch copy of `author`:

```bash
python3 -u run-primary.py /absolute/path/to/restored-parent.pkl >slices.tsv
python3 -u reduce-open.py 0 1 2 3 4 5 6 7 8 >rescue.tsv
for n in 5 6; do
    python3 -u triangle-bounded.py "join-cap-dense-label-rescue-$n-1-reduced.pkl" >"slice-$n-triangle.out" || exit 1
done
for n in 2 3; do
    python3 -u capture-quotient.py "slice-$n" >"capture-$n.out" || exit 1
    cmp "capture-$n.out" "slice-$n-contract.out" || exit 1
done
shasum -a 256 -c /absolute/path/to/archive/frontiers.sha256
python3 sum-case25.py
```

The nine inner cut coordinates support exactly 2,579,328 projected pair matches. The original direct and repeated support/quotient reductions close seven scalar contributions. Two further values close by exact triangle contractions. Each author triangle uses 26,634,240 exact Gaussian products within the scientific cap. The script's historical output label says “independent” because it derives from an earlier replay code path. Here those two logged calculations are author evidence. The independent replays are stored separately in `review`.

The exact real subtotal is `-41341172375785624570953/2596148429267413814265248164610048` and the imaginary part is zero. The full signed coefficient and publication gates remain open.

## Cases 26–28 and cumulative retally

Use the corresponding `author26`, `author27` or `author28` folder, and replace the case name in the restore path, ledger command and checksum name. Their seven-factor parent SHA256s are `811f2f3ebc57d598493d10931b8327446e3b04d294a38f1f6dc1836399460e1d`, `17fa0873765a2ba37e22e8499d353dba70c5e47c08fe80cd85301778d00cfd82` and `41fdced25b6e0c006ccbb4c6e5edd3eab3881a500aaf3d3e83f071024d3f45d5`. Cases 26 and 27 use the same procedure as 25. Case 28 omits the capture commands because the separate independent sparse replays reproduce all seven non-triangle values directly. Its inner split supports 2,911,488 pair matches. The exact values, conditionings and distinct input checksums are in each author's ledger and matching reviewer directory.

The frozen reviewer manifests may refer to duplicate Git ZIPs. Restore the upstream original separator and cases 17–23 ZIPs by their hashes under the local basenames specified in the reports.

Run `python3 verify-cases.py 25 26 27 28` to check the 36 exact slice outputs, including raw Gaussian numerators and normalized fractions. Run `python3 retally-48.py 25 26 27 28` to reproduce the exact subtotal over 33 distinct accepted outer cases and list the 15 open cases. The prior ledger and original roster text are included unchanged from their canonical ZIPs.
