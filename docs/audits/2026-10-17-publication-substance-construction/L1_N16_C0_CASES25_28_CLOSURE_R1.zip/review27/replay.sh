#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 audit.py > audit.out
a=/private/tmp/l1-c0-case27.fRbBdw
tab=$(printf '\t')
while IFS="$tab" read -r index coord products real imag receipt; do
    if test "$index" = sum; then break; fi
    case "$index" in 5|6) continue;; esac
    stem=${receipt%-contract.out}
    if python3 -u replay.py "$index" 0 "$a/label-$stem-reduced-frontier.pkl" "$a/$receipt" > "slice-$index-replay.out" 2>&1; then
        test "$index" != 2 && test "$index" != 3
    else
        case "$index" in
            2|3) grep -q 'assert n<=8000000' "slice-$index-replay.out" ;;
            *) exit 1 ;;
        esac
    fi
done < "$a/author-case27.tsv"
python3 verify-captures.py > capture-audit.out
for index in 2 3; do
    python3 -u replay.py "$index" 0 "$a/post-quotient-slice-$index.pkl" "$a/capture-$index.out" > "slice-$index-capture-replay.out"
done
for index in 5 6; do
    python3 -u triangle.py "$index" > "slice-$index-triangle-replay.out"
done
python3 aggregate.py > aggregate.out
