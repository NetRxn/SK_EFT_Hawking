# Independent verification of L1 N16 outer case 28

The review pins publication checkpoint cdd9b80ff and the seven-factor
parent identified in next-frontiers/inputs.sha256 within
L1_N16_C0_CASES17_23_CLOSURE_R1.zip. The archive manifest verified.
The checked parent SHA256 is
41fdced25b6e0c006ccbb4c6e5edd3eab3881a500aaf3d3e83f071024d3f45d5.
The archived outer roster maps case 28 to (34, (3,)) on G(0,4,2) and
J(1,4,2). This is in the first binary child of tuple 0, descendant
(0,0), branch 128.

An independent histogram match on the rejected parent pair (0, 1)
regenerated the complete nine-value cut on G(0,1,2). The disjoint
values cover 2,911,488 matched pair products. Every nonzero complete
network summand must match that pair. An exact inverse lift of each cut
recovered every compatible parent row, Gaussian coefficient and factor
denominator. The parent conditioning, label partition, degree-two open
axes and factor denominator product were checked for all terminal inputs.

| Slice | Cut value | Matched parent pair products | Independent normalized real |
|---|---:|---:|---:|
| 0 | 12 | 195,456 | -5692727247760044234855/2596148429267413814265248164610048 |
| 1 | 192 | 199,296 | -7741476545915524167/81129638414606681695789005144064 |
| 2 | 96 | 232,512 | -2164765870170958229109/162259276829213363391578010288128 |
| 3 | 144 | 232,512 | -2164765870170958229109/162259276829213363391578010288128 |
| 4 | 48 | 265,728 | 1846598470298593469829/649037107316853453566312041152512 |
| 5 | 3 | 394,752 | -131056210396553359661415/2596148429267413814265248164610048 |
| 6 | 5 | 461,184 | -143949272609465419525695/5192296858534827628530496329220096 |
| 7 | 80 | 465,024 | -15533460303436396556379/2596148429267413814265248164610048 |
| 8 | 160 | 465,024 | -15533460303436396556379/2596148429267413814265248164610048 |

All imaginary parts are zero. The exact independent sum is
**-603848671539328985994783/5192296858534827628530496329220096 + 0i**.

Seven terminal inputs passed independent sparse Gaussian integer
contraction. For slices 5 and 6 the generic contraction preserved
three-factor join-cap states. The independent triangle arithmetic
intersects adjacency supports around pivot 1, accumulates pair products
for each distinct pivot row, and then multiplies by that row's exact
coefficient. Each slice covers 13,317,120 matching triples with
13,394,880 Gaussian products across seven shards. The largest shard
used 1,999,980 probes and 2,012,900 products. The alternate ordering
agrees with the author pivot 0 raw numerators and normalized fractions.
All nine replays apply the positive factor denominator product
40512224221827380280140849737629696 and external normalization
1/(16*4^64) once. They import no author contraction code.

The frozen inputs and logs preserve all 13 generic cap refusals. The
refusal audit binds each to its distinct saved checkpoint and verifies
its conditioning, label partition, factor count, denominator product
and degree-two axes. Intermediate lineage is supported by these
state and receipt checks and by byte identity of the common author code
with the fully replayed case 18 code. The new independent arithmetic
covers exact case 28 terminal contractions and the nine-term sum.
