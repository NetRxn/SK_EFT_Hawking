from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

author = Path('/private/tmp/l1-c0-case28.PfQy54')
prior = Path('/private/tmp/l1-c0-case18.szXdBy')
for name in ('exact-multicut.py','reduce-label-frontier.py','contract-reduced-label.py',
             'contract-peer.py','peer_pair.py','checkpoint/quotient.py'):
    assert (author/name).read_bytes() == (prior/name).read_bytes()
    print('matches previously replayed case 18 author script',name)
parts = {}
for line in (author/'author-case28.tsv').read_text().splitlines()[:-1]:
    index, value, count, real, imag, receipt = line.split('\t')
    parts[int(index)] = receipt
seen = []
for i, exact_receipt in parts.items():
    child = pickle.loads((author/f'slice-{i}.pkl').read_bytes())
    tag = f'slice-{i}'
    for phase in range(3):
        receipt = f'{tag}-contract.out'
        reduced = author/f'label-{tag}-reduced-frontier.pkl'
        text = (author/receipt).read_text()
        tail = text.splitlines()[-1]
        snapshots = list(author.glob(f'*-dense-label-{tag}-reduced.pkl'))
        if receipt == exact_receipt:
            assert tail.startswith('exact normalized ') and not snapshots
            break
        match = re.fullmatch(r'open (row|join) cap (\d+) (?:completed products )?(\d+) frontier saved',tail)
        assert match and len(snapshots)==1
        saved = snapshots[0]
        assert saved.name.startswith('row-cap-' if match[1]=='row' else 'join-cap-')
        data = saved.read_bytes()
        state = pickle.loads(data)
        for key in ('conditioning','label_partition'):
            assert state[key] == child[key]
        factors = state['factors']
        assert len(factors) == int(match[2])
        assert prod(d for _,_,d in factors) == 40512224221827380280140849737629696
        assert all(n==2 and a[0]!='L' for a,n in Counter(a for axes,_,_ in factors for a in axes).items())
        if i in (5,6) and phase==2:
            assert match[1]=='join' and exact_receipt==f'slice-{i}-triangle.out'
        seen.append((i,tag,tail,saved.name,sha256(data).hexdigest()))
        tag=f'rescue-{i}-{phase}'
assert len(seen)==13
for values in seen:
    print(*values,sep='\t')
print('PASS 13 cap receipts match distinct frozen conditioned restart inputs')
