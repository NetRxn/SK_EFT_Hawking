from collections import Counter, defaultdict
from fractions import Fraction as F
from math import factorial, prod
import json
from random import Random
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, QComplex, Symbol, assemble_dirac,
    haar_polynomial, integrated_polynomial_product,
)

origin, neighbor = (0,0,0,0), (1,0,0,0)
a, b, opposite, moved, distant = [
    Symbol("q", (*anchor, k))
    for anchor,k in [
        ((origin,0,"L"),0), ((origin,0,"L"),1), ((origin,0,"R"),0),
        ((origin,1,"L"),0), ((neighbor,0,"L"),0)
    ]
]
h = Symbol("h", (origin,0,0))
j = Symbol("J", (origin,0,0))
jb = j.conjugate()

def moment(key):
    groups = defaultdict(Counter)
    for symbol in key:
        if symbol.family == "q":
            groups[symbol.index[:-1]][symbol.index[-1]] += 1
    result = F(1)
    for group in groups.values():
        if any(p % 2 for p in group.values()):
            return F()
        half = [p//2 for p in group.values()]
        # Uniform S^3 squares have the Dirichlet(1/2,1/2,1/2,1/2) law.
        result *= F(prod(factorial(2*k)//factorial(k) for k in half),
                    4**sum(half)*factorial(1+sum(half)))
    return result

def oracle(polynomial):
    accum = defaultdict(lambda:(F(),F()))
    for key, coeff in polynomial.terms:
        residual = tuple(sym for sym in key if sym.family != "q")
        re, im = accum[residual]
        m = moment(key)
        accum[residual] = (re+m*coeff.real, im+m*coeff.imag)
    return {k:v for k,v in accum.items() if any(v)}

def readback(polynomial):
    return {key:(coefficient.real,coefficient.imag) for key,coefficient in polynomial.terms}

def P(*terms):
    return Polynomial(tuple((tuple(key),QComplex(re,im)) for key,re,im in terms))

scoped = {
    "same_anchor_distinct_coordinates": (P(([a,a,b,b],1,0)), {():(F(1,24),F())}),
    "distinct_chirality": (P(([a,a,opposite,opposite],1,0)), {():(F(1,16),F())}),
    "distinct_direction": (P(([a,a,moved,moved],1,0)), {():(F(1,16),F())}),
    "distinct_site": (P(([a,a,distant,distant],1,0)), {():(F(1,16),F())}),
    "odd_term_is_zero": (P(([a,b,b,h],19,11)), {}),
    "collision_accumulates": (P(([h,j,a,a],2,8),([h,j]+[a]*4,-8,4)),
                               {tuple(sorted([h,j])):(-F(1,2),F(5,2))}),
    "collision_cancels": (P(([h,j,a,a],2,8),([h,j]+[a]*4,-4,-16)), {}),
    "different_residual_labels_stay_distinct": (P(([j,a,a],4,4),([jb]+[a]*4,8,-8)),
                                                  {(j,):(F(1),F(1)),(jb,):(F(1),-F(1))}),
    "squared_radius_has_unit_moment": (P(*[([Symbol("q",(origin,0,"L",k))]*2,1,0) for k in range(4)]),
                                      {():(F(1),F())}),
}
results={}
for name,(poly,expected) in scoped.items():
    assert oracle(poly) == readback(haar_polynomial(poly)) == expected, name
    results[name]=True
x=P(([a],1,0))
y=P(([a],1,1),([b],4,0))
assert not haar_polynomial(x) and not haar_polynomial(y)
assert integrated_polynomial_product(x,y).storage == (1,4,1,4)
assert oracle(x*y) == {():(F(1,4),F(1,4))}
assert integrated_polynomial_product(x,y,sign=-1).storage == (-1,4,-1,4)
results["shared_link_first_power_product_and_sign"]=True
rng=Random(32041)
labels=[a,b,opposite,moved,distant,h,j,jb]
for _ in range(64):
    poly=P(*[(rng.choices(labels,k=rng.randrange(10)), F(rng.randint(-7,7),rng.randint(1,7)),
              F(rng.randint(-7,7),rng.randint(1,7))) for _ in range(28)])
    assert readback(haar_polynomial(poly)) == oracle(poly)
reg=OriginalRegulator((2,2,1,1))
matrix=assemble_dirac(reg)
seen=set()
for _,entry in matrix.entries:
    assert readback(haar_polynomial(entry)) == oracle(entry)
    for key,_ in entry.terms:
        for s in key:
            seen.add(s.family)
            assert not s.conjugated
            if s.family == "q":
                x,mu,side,coord=s.index
                assert x in reg.sites and mu in range(4) and side in {"L","R"} and coord in range(4)
            else:
                x,mu,coord=s.index
                assert s.family in {"h","J"} and x in reg.sites and mu in range(4) and coord in range(4)
assert seen=={"h","J","q"}
print(json.dumps({"manual":results,"seeded_polynomials":64,"actual_dirac_entries":len(matrix.entries),
                  "actual_dirac_label_families":sorted(seen)},indent=2))
