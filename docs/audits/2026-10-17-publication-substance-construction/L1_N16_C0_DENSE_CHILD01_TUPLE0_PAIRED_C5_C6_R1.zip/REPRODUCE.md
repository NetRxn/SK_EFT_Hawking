# L1 original paired cuts 5 and 6

These are two distinct outer coordinates of group 128, descendant (0,1), tuple 0. Cut 5 has 16 exact terms beyond its five-factor join cap. Cut 6 has 23 exact terms after its row cap.

Restore the frozen 48-coordinate roster and branch operands from L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip at 383f42e573962e8f7f41c0111c82a59a605c73ff. Check source hashes. Reproduce each outer pair via sum-branches-checked.py and the recorded generic reduction and contraction. The author runner is run-rostered-next.py. The outer-inputs.sha256 files identify the paired inputs and saved caps.

For cut 5, use the recorded exact frontier partition and complete 16-value roster. From author/5/frontier, use prepare.py on the frozen cap and reproduce the first term. Then use run-cohort.py, triangle-forecast.py for the eight capped labels, finish-triangles.py and sum-case2.py. Check all signed rows and SHA256 entries in operands.sha256.

For cut 6, use the complete roster in author/6/slice-0.roster. Run the two-stage generic reduction. The exact four-factor sharding plan covers inner slices 21 and 22. Verify the two eight-shard intervals and term retally. Run sum-case6.py in its author directory.

All terms use the positive external factor 1/(16*4^64) once. Verify manifest.sha256 and the portable independent manifests. Run coverage-retally.py with the repository audit archive directory and compare the complete 48-coordinate ledger.
