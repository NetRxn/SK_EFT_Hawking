from ast import literal_eval
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shutil,subprocess,sys,time

root=Path(__file__).resolve().parent
parent=Path(sys.argv[1]).resolve()
first=(root/'prepare.out').read_text().splitlines()
roster=literal_eval(first[1].removeprefix('weighted roster '))
initial=literal_eval(first[2].split('projected')[0].rsplit(' ',2)[1])
assert initial in dict(roster) and len(roster)==16

def run(row):
    label,count=row
    if label==initial:
        return label,count,0,0,'existing measured pilot'
    here=root/str(label)
    here.mkdir()
    for name in ('reduce-label-frontier.py','contract-peer.py','peer_pair.py'):
        shutil.copyfile(root/name,here/name)
    shutil.copytree(root/'checkpoint',here/'checkpoint')
    start=time.monotonic()
    for program,args,name in (
        (str(root/'prepare-selected.py'),[str(parent),str(label)],'prepare'),
        ('reduce-label-frontier.py',['selected.pkl','cut2-selected'],'reduction'),
        ('contract-peer.py',['cut2-selected'],'contraction')):
        with (here/f'{name}.out').open('xb') as out:
            try:
                status=subprocess.run([sys.executable,'-B',program,*args],cwd=here,stdout=out,
                       stderr=subprocess.STDOUT,timeout=120).returncode
            except subprocess.TimeoutExpired:
                status=124
        if status!=0:
            return label,count,status,round(time.monotonic()-start,6),name
    return label,count,0,round(time.monotonic()-start,6),
with ThreadPoolExecutor(max_workers=2) as pool:
    for row in pool.map(run,roster):
        print(*row,sep='\t',flush=True)
