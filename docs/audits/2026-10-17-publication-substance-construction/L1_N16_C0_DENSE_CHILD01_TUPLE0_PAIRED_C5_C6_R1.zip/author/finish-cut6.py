from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations
from pathlib import Path
import pickle
import shutil
import subprocess
import sys
import time

parent = Path(__file__).resolve().parent
source_drivers = parent / 'heavy47-inner'
cut = int(sys.argv[1])
scratch = parent / f'probe{cut}-inner'
shards = 8
known_statuses = []
for receipt in ('primary.tsv', 'rescue.tsv'):
    if (scratch/receipt).exists():
        for line in (scratch/receipt).read_text().splitlines():
            idx, status, *_ = line.split('\t')
            known_statuses.append((int(idx), int(status)))
statuses = dict(known_statuses)
assert sorted(statuses) == list(range(23))
assert set(statuses.values()) <= {0, 2}

def forecast(factors, pair):
    a, A, _ = factors[pair[0]]
    b, B, _ = factors[pair[1]]
    common = tuple(axis for axis in a if axis in b)
    if not common:
        return None
    ia = tuple(a.index(axis) for axis in common)
    ib = tuple(b.index(axis) for axis in common)
    counts = Counter(tuple(row[i] for i in ib) for row in B)
    ordered = sorted(A)
    return [sum(counts[tuple(row[i] for i in ia)]
                for row in ordered[len(ordered)*s//shards:len(ordered)*(s+1)//shards])
            for s in range(shards)]

def solve_status(idx):
    possibilities = list(scratch.glob(f'*-dense-label-rescue-{idx}-1-reduced.pkl'))
    assert len(possibilities) == 1, possibilities
    p = possibilities[0]
    with p.open('rb') as stream:
        factors = pickle.load(stream)['factors']
    if len(factors) == 3:
        return p.name,'triangle-shards.py',(),()
    if len(factors) != 4:
        raise ValueError((idx,len(factors),p))
    candidates = [(pair, counts) for pair in combinations(range(4),2)
                  if (counts := forecast(factors,pair)) is not None]
    pair, counts = min(candidates,key=lambda row:(sum(row[1]),max(row[1]),row[0]))
    assert max(counts) <= 8_000_000
    return p.name,'close-four-shards.py',pair,counts

plans = {idx:solve_status(idx) for idx,status in statuses.items() if status==2}
for name in ('triangle-shards.py','close-four-shards.py','sum-shards.py'):
    shutil.copyfile(source_drivers/name,scratch/name)
with (scratch/'terminal-plan.tsv').open('x') as receipt:
    for index,(path,script,pair,counts) in sorted(plans.items()):
        print(index,path,script,pair,counts,sep='\t',file=receipt)

def run(task):
    index, shard = task
    path, script, pair, counts = plans[index]
    if script == 'triangle-shards.py':
        args = [path,str(shard),str(shards)]
    else:
        args = [path,'--pair',*map(str,pair),'--shard',str(shard),str(shards)]
    start=time.monotonic()
    with (scratch/f'slice-{index}-shard-{shard}.out').open('xb') as receipt:
        subprocess.run([sys.executable,script,*args],stdout=receipt,stderr=subprocess.STDOUT,
                       cwd=scratch,timeout=130,check=True)
    return index,shard,round(time.monotonic()-start,3)

with ThreadPoolExecutor(max_workers=2) as pool, (scratch/'shard-timing.tsv').open('x') as times:
    for result in pool.map(run, ((idx,s) for idx in sorted(plans) for s in range(shards))):
        print(*result,sep='\t',file=times,flush=True)
for index in plans:
    with (scratch/f'slice-{index}-shard-sum.out').open('xb') as receipt:
        subprocess.run([sys.executable,'sum-shards.py',str(index),str(shards)],
                       stdout=receipt,cwd=scratch,check=True)
