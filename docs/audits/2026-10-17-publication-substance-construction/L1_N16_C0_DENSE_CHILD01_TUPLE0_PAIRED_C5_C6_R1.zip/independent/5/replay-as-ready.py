from pathlib import Path
import subprocess
import sys
from time import monotonic,sleep

pair=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
here=Path.cwd()
start=monotonic()
done=set()
while len(done)<16:
    for outer in (5,):
        stage=Path((pair/f'cut{outer}-frontier.path').read_text().strip())
        text=(stage/'cohort.tsv').read_text() if (stage/'cohort.tsv').is_file() else ''
        for line in text.splitlines():
            label,products,code,*_=line.split('\t')
            k,L=int(label),int(code)
            if (outer,k) in done:
                continue
            src=stage if k==17 else stage/label
            workdir=here
            if L==0:
                program='sparse-support-direct.py'
                inp=src/'label-cut2-selected-reduced-frontier.pkl'
                args=(label,'terminal',str(inp))
                name=f'label{label}-pruned.out'
            elif L==2:
                program='triangle.py'
                args=(label,'join-cap-dense-label-cut2-selected-reduced.pkl')
                name=f'label{label}-alt-triangle.out'
            else:
                raise ValueError((outer,k,L))
            with (workdir/name).open('xb') as output:
                p=subprocess.run([sys.executable,'-u',program,*args],cwd=workdir,stdout=output,
                                 stderr=subprocess.STDOUT,timeout=120)
            assert p.returncode==0,(outer,k,L,name,p.returncode)
            done.add((outer,k))
            print(outer,k,L,name,sep='\t',flush=True)
    assert monotonic()-start<900
    sleep(2)
