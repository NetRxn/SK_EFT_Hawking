from ast import literal_eval
from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle

pair=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
author=Path((pair/'cut5-frontier.path').read_text().strip())
parent=pair/'join-cap-dense-label-sum5-reduced.pkl'
raw=parent.read_bytes()
state=pickle.loads(raw)
expect_hash='cc7c23de99feefbff3e82e26614f7c36276e73a25c691c4abe8b5125a81c46fe'
assert sha256(raw).hexdigest()==expect_hash
factors=state['factors']
axis=('G',1,0,2)
assert len(factors)==5 and 'refusal' in state and 'rejected_pair' not in state
assert set(Counter(k for scope, _, _ in factors for k in scope).values())=={2}
assert [i for i,(axes,_,_) in enumerate(factors) if axis in axes]==[0,4]
def key_positions(scope, axes):
    return tuple(scope.index(x) for x in axes)
def project(row, positions):
    return tuple(row[i] for i in positions)
edges=tuple(sorted(set(factors[0][0]) & set(factors[3][0])))
assert axis not in edges
p,q=[key_positions(factors[i][0],edges) for i in (0,3)]
domain=set.intersection(*({row[scope.index(axis)] for row in rows}
                         for scope,rows,_ in factors if axis in scope))
weights=Counter()
left=Counter((row[factors[0][0].index(axis)], project(row,p)) for row in factors[0][1])
right=Counter(project(row,q) for row in factors[3][1])
for (value,key),left_count in left.items():
    weights[value]+=left_count*right[key]
weights=+weights
assert set(weights)==domain and len(domain)==16
assert sum(weights.values())==14_947_200 and min(weights.values())==622800 and max(weights.values())==1245600
attach=(author/'prepare.out').read_text().splitlines()
assert attach[0]==f'input sha256 {expect_hash}'
assert sorted(weights.items())==literal_eval(attach[1].removeprefix('weighted roster '))
print('PASS complete independent roster and compatible factor domain',axis, sorted(weights.items()))
print('PASS total matches',sum(weights.values()),'range',min(weights.values()),max(weights.values()))
for value,count in sorted(weights.items()):
    home=author if value==17 else author/str(value)
    selected=home/'selected.pkl'
    if not selected.is_file():
        print('OPEN missing frozen selected input',value,count)
        continue
    bits=selected.read_bytes()
    child=pickle.loads(bits)
    child_axes=Counter(k for scope,_,_ in child['factors'] for k in scope)
    assert child_axes==Counter({k:2 for scope,_,_ in factors for k in scope if k!=axis})
    assert {k:v for k,v in state.items() if k not in ('factors','conditioning')}=={k:v for k,v in child.items() if k not in ('factors','conditioning')}
    assert child['conditioning']==state['conditioning']+[(axis,value)]
    assert prod(d for _,_,d in child['factors'])==prod(d for _,_,d in factors)==40512224221827380280140849737629696
    for (scope,rows,d),(new,cut,e) in zip(factors,child['factors'],strict=True):
        assert d==e
        if axis not in scope:
            assert scope==new and rows==cut
        else:
            i=scope.index(axis)
            assert scope[:i]+scope[i+1:]==new
            lifted={row[:i]+(value,)+row[i:]:z for row,z in cut.items()}
            assert lifted=={row:z for row,z in rows.items() if row[i]==value}
    log=(home/'prepare.out').read_text().splitlines()
    assert log[:2]==attach[:2] and log[2]==f'fixed {axis} {value} projected {count}'
    print('PASS inverse lift',value,count,sha256(bits).hexdigest(),sum(len(rows) for _,rows,_ in child['factors']))
