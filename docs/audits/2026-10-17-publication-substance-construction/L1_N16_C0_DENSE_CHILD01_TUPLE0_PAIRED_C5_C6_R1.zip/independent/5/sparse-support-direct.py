# Independent sparse Gaussian integer contraction. No author function imported.
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
from math import prod
from fractions import Fraction
import pickle,time,sys
started=time.monotonic();case,stage,*override=sys.argv[1:]; D=Path('/private/tmp/l1-c0-case16.HLZKWE')
with (Path(override[0]) if override else D/f'label-slice-{case}-reduced-frontier.pkl').open('rb') as f:checkpoint=pickle.load(f)
fs=checkpoint['factors'];denominator=prod(d for a,r,d in fs)
assert not any(k[0]=='L' for a,r,d in fs for k in a)
assert all(v==2 for v in Counter(k for a,r,d in fs for k in a).values())
def prune(factors):
    factors = [(axes, rows.copy(), d) for axes, rows, d in factors]
    for i, j in combinations(range(len(factors)), 2):
        left, right = factors[i], factors[j]
        common = sorted(set(left[0]) & set(right[0]))
        if not common:
            continue
        positions = [tuple(axes.index(w) for w in common) for axes, _, _ in (left, right)]
        allowed = set.intersection(*({tuple(row[p] for p in pp) for row in f[1]}
                                     for f, pp in zip((left, right), positions, strict=True)))
        for idx, pp in zip((i, j), positions, strict=True):
            axes, rows, d = factors[idx]
            factors[idx] = (axes, {row: z for row, z in rows.items() if tuple(row[p] for p in pp) in allowed}, d)
    return factors

spent=0
while len(fs)>1:
    fs=prune(fs)
    forecasts=[]
    for i,j in combinations(range(len(fs)),2):
        a,r,_=fs[i];b,s,_=fs[j];shared=set(a)&set(b);order=sorted(shared)
        ix=[a.index(k) for k in order];jx=[b.index(k) for k in order]
        counts=Counter(tuple(row[p] for p in jx) for row in s)
        n=sum(counts[tuple(row[p] for p in ix)] for row in r)
        forecasts.append((n,i,j,ix,jx))
    def size_score(entry):
        n, i, j, ix, _ = entry
        width = len(fs[i][0]) + len(fs[j][0]) - 2 * len(ix)
        return n * (1 + width)**2, n, i, j

    eligible = [e for e in forecasts if e[0] <= 8000000 and spent + e[0] <= 30000000]
    assert eligible, ('no allowed join', sorted((p[0], p[1], p[2]) for p in forecasts)[:4], spent)
    n,i,j,ix,jx=min(eligible,key=size_score)
    print("forecast",n,i,j,"prior",spent,flush=True)
    assert n<=8000000 and spent+n<=30000000
    assert time.monotonic()-started<30
    a,r,d=fs[i];b,s,e=fs[j];li=[p for p in range(len(a)) if p not in ix];ri=[p for p in range(len(b)) if p not in jx]
    axes=tuple(a[p] for p in li)+tuple(b[p] for p in ri)
    buckets=defaultdict(list)
    for row,z in s.items():buckets[tuple(row[p] for p in jx)].append((tuple(row[p] for p in ri),z))
    out={};seen=0
    for row,(x,y) in r.items():
        prefix=tuple(row[p] for p in li)
        for suffix,(u,v) in buckets[tuple(row[p] for p in ix)]:
            seen+=1;key=prefix+suffix;old=out.get(key,(0,0));z=old[0]+x*u-y*v,old[1]+x*v+y*u
            if any(z):out[key]=z
            else:out.pop(key,None)
            assert len(out)<=1000000
            if seen%32768==0:assert time.monotonic()-started<30
    assert seen==n;spent+=n
    print('independent join',i,j,'products',n,'output rows',len(out),'remaining',len(fs)-1,flush=True)
    fs=[f for p,f in enumerate(fs) if p not in (i,j)]+[(axes,out,d*e)]
a,r,d=fs[0];assert not a and d==denominator
re,im=r.get((),(0,0));actual=Fraction(re,d*16*4**64);imag=Fraction(im,d*16*4**64)
assert denominator == 40512224221827380280140849737629696
print('independently computed raw scalar numerator',re,'imaginary',im,'factor denominator',d)
print('exact normalized real',actual,'imaginary',imag,'independent matched products',spent,'wall seconds',round(time.monotonic()-started,4))
print('conditioning',checkpoint['conditioning'],'label partition',checkpoint['label_partition'])
