from collections import Counter
from decimal import Decimal
from pathlib import Path
import re

entries=[line.split('\t') for line in Path('cohort-lineage.tsv').read_text().splitlines()]
assert len(entries)==48
assert len({tuple(row[:2]) for row in entries})==48
assert Counter((stage,code) for _,stage,code,_ in entries)==Counter({
    ('prepare','0'):16, ('reduction','0'):16, ('contraction','0'):8, ('contraction','2'):8})
print('generic sum of elapsed seconds',sum(Decimal(x[-1]) for x in entries))
for prefix,regex in (
    ('pruned',r'^exact normalized .* products (\d+) wall seconds (\S+)$'),
    ('alt-triangle',r'^independent pivot 1 .* products (\d+) wall seconds (\S+)$'),
):
    files=sorted(Path().glob(f'label*-{prefix}.out'))
    assert len(files)==8
    values=[(int(m[1]),Decimal(m[2])) for file in files if (m:=re.search(regex,file.read_text(),re.M))]
    assert len(values)==8
    print(prefix,'products',sorted(set(n for n,_ in values)),
          'seconds min/max/sum',min(t for _,t in values),max(t for _,t in values),sum(t for _,t in values))
