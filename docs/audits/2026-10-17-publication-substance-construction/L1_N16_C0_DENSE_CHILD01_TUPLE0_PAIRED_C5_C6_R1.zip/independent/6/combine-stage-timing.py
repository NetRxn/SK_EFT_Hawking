from collections import Counter
from decimal import Decimal
from pathlib import Path

print('slice\tstage_receipt\texit_code\twall_seconds')
rows=[]
for i in range(23):
    log=Path(f'lineage-{i}/stage-timing.tsv')
    for line in log.read_text().splitlines():
        ordinal,name,code,seconds=line.split('\t')
        assert int(ordinal)==i and Decimal(seconds)>0
        assert code in ('0','2') and (code=='0' or name.endswith('-contract.out'))
        rows.append((ordinal,name,code,seconds))
assert len(rows)==77 and len({x[:2] for x in rows})==77
assert Counter(code for _,_,code,_ in rows)==Counter({'0':71,'2':6})
assert sum(name.endswith('-plan.out') for _,name,_,_ in rows)==23
assert sum(name.endswith('-reduce.out') for _,name,_,_ in rows)==27
assert sum(name.endswith('-contract.out') for _,name,_,_ in rows)==27
for row in rows:
    print(*row,sep='\t')
