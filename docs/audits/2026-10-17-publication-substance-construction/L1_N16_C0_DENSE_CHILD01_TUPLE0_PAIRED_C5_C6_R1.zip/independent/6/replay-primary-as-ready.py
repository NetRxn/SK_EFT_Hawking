from pathlib import Path
import subprocess
import sys
from time import monotonic,sleep

author=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe6-inner')
started=monotonic()
seen=set()
while len(seen)<23:
    for table in sorted(author.glob('primary*.tsv')):
        for line in table.read_text().splitlines():
            n,code,_=line.split('\t',2)
            if n in seen:
                continue
            if code=='0':
                path=author/f'label-slice-{n}-reduced-frontier.pkl'
                receipt=author/f'slice-{n}-contract.out'
                with Path(f'slice-{n}-replay.out').open('xb') as out:
                    result=subprocess.run([sys.executable,'-u','sparse-replay.py',n,'terminal',str(path),str(receipt)],
                                          stdout=out,stderr=subprocess.STDOUT,timeout=120)
                assert result.returncode==0,(n,result.returncode)
            else:
                assert code=='2'
            seen.add(n)
            print(n,code,sep='\t',flush=True)
    assert monotonic()-started<600
    sleep(2)
