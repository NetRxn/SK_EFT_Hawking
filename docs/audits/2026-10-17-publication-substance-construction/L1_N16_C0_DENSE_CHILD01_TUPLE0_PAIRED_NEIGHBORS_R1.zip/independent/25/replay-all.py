from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run
from sys import executable

author = Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe25-inner')
def replay(row):
    i, coordinate, count, real, imaginary, receipt = row.split('\t')
    if 'shard-sum' in receipt and Path(f'slice-{i}-triangle-replay.out').is_file():
        log = Path(f'slice-{i}-triangle-replay.out').read_text()
        if 'exact normalized real ' in log:
            return i,'triangle',0
    if 'shard-sum' in receipt:
        with Path(f'slice-{i}-triangle-replay.out').open('w') as log:
            r = run([executable,'-B','-u','triangle.py',i],stdout=log,check=True,timeout=120)
        return i,'triangle',r.returncode
    stage = receipt.removesuffix('-contract.out')
    state = author/f'label-{stage}-reduced-frontier.pkl'
    for method in ('sparse', 'sparse-support'):
        with Path(f'slice-{i}-{method}-replay.out').open('w') as log:
            r = run([executable,'-B','-u',f'{method}-replay.py',i,'0',str(state),str(author/receipt)],stdout=log,check=False,timeout=120)
        if r.returncode == 0:
            Path(f'slice-{i}-replay.out').write_bytes(Path(f'slice-{i}-{method}-replay.out').read_bytes())
            return i,method,r.returncode
    raise ValueError(i)

with ThreadPoolExecutor(max_workers=3) as workers:
    from sys import argv
    ledger = author/'author-case25.tsv'
    rows = ledger.read_text().splitlines()[:-1] if ledger.exists() else [
        f'{i}\t-\t-\t-\t-\t{name}-contract.out' for i,name in
        {0:'rescue-0-0',1:'rescue-1-1',2:'slice-2',3:'slice-3',4:'slice-4',7:'rescue-7-0',8:'rescue-8-0'}.items()]
    selected = set(argv[1:])
    for result in workers.map(replay,[row for row in rows if not selected or row.split('\t')[0] in selected]):
        print(*result,sep='\t',flush=True)
