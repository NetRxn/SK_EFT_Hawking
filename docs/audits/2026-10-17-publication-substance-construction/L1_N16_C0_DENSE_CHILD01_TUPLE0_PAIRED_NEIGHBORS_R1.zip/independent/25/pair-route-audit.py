from ast import literal_eval
from collections import Counter, defaultdict
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads
root=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
route=root/'tuple0-pair-equivalence'
def state(path): return loads(path.read_bytes())
sources=[state(root/f'row-cap-physical-slice-dense-label-tuple0-branch-{i}-reduced.pkl') for i in (0,1)]
assert sources[0]['label_partition']==sources[1]['label_partition']
assert sources[0]['physical_cut']==sources[1]['physical_cut']
assert sources[0]['conditioning'][:-1]==sources[1]['conditioning'][:-1]
assert [s['conditioning'][-1] for s in sources]==[(('R',0,0,2,0,1),i) for i in (0,1)]
A,B=[s['factors'] for s in sources]
assert A[2:]==B[2:]
assert A[:2]!=B[:2]
assert all(A[i][2]==B[i][2] for i in (0,1))
cuts, ordered = literal_eval((root/'tuple0-branch0-pilot/pilot.roster').read_text())
expected=dict(ordered)
assert len(ordered)==len(expected)==48 and sum(expected.values())==6427904
coordinate=sorted(expected,key=lambda k:(expected[k],k))[25]
assert coordinate==(36,(3,))
fixed=dict(zip(cuts,coordinate,strict=True))
def restrict(factor):
    axes,rows,den=factor
    surviving=tuple(a for a in axes if a not in fixed)
    out={}
    for row,g in rows.items():
        kv=dict(zip(axes,row,strict=True))
        if all(kv[a]==v for a,v in fixed.items() if a in kv):
            reduced=tuple(kv[a] for a in surviving)
            assert reduced not in out
            out[reduced]=g
    return surviving,out,den

acc=defaultdict(lambda:[0,0])
domains=[]
for i,fs in enumerate((A,B)):
    assert set(Counter(k for ax,_,_ in fs for k in ax).values())=={2}
    a,l,ad=fs[0]; b,r,bd=fs[1]
    shared=tuple(sorted(set(a)&set(b)))
    assert all(k not in shared for k in cuts)
    out=tuple(k for k in a if k not in shared)+tuple(k for k in b if k not in shared)
    projection=lambda keys,domain:tuple(domain.index(k) for k in keys)
    ix,jx=projection(shared,a),projection(shared,b)
    cx=projection(cuts,a)
    histogram=Counter(tuple(row[j] for j in jx) for row in r)
    traffic=Counter()
    for row in l:
        n=histogram[tuple(row[j] for j in ix)]
        if n:traffic[tuple(row[j] for j in cx)]+=n
    assert traffic==expected
    # Condition first, index left, enumerate in the right-factor direction.
    a2,l2,_=restrict(fs[0]); b2,r2,_=restrict(fs[1])
    left=defaultdict(list)
    ax=projection(shared,a2); bx=projection(shared,b2)
    aa=tuple(j for j in range(len(a2)) if j not in ax)
    bb=tuple(j for j in range(len(b2)) if j not in bx)
    for row,g in l2.items():
        left[tuple(row[j] for j in ax)].append((tuple(row[j] for j in aa),g))
    matched=0
    for row,(c,d) in r2.items():
        tail=tuple(row[j] for j in bb)
        for head,(x,y) in left[tuple(row[j] for j in bx)]:
            term=acc[head+tail]
            term[0]+=x*c-y*d
            term[1]+=x*d+y*c
            matched+=1
    assert matched==expected[coordinate]
    domains.append((tuple(k for k in out if k not in fixed),ad*bd))
assert domains[0]==domains[1]
axes,d=domains[0]
independent=(axes,{row:tuple(g) for row,g in acc.items() if any(g)},d)
combined=state(route/'combined-25.pkl')
assert combined['label_partition']==sources[0]['label_partition']
assert combined['conditioning']==sources[0]['conditioning'][:-1]+list(fixed.items())
assert combined['binary_sum']=={'summed_index':('R',0,0,2,0,1),'values':(0,1),'coordinate':coordinate}
assert combined['factors']==[independent]+[restrict(f) for f in A[2:]]
assert set(Counter(k for a,_,_ in combined['factors'] for k in a).values())=={2}
for s in sources:
 assert prod(x[2] for x in s['factors'])==prod(x[2] for x in combined['factors'])==40512224221827380280140849737629696
print('PASS two disjoint binary slices, common 6-factor environment, shared label partition and factor denominators')
print('PASS exact complete same 48-coordinate support per branch, 6427904 pair matches each')
print('PASS independent exact pointwise signed pair sum, all 7 factor tables and normalizations, pilot',coordinate,len(independent[1]),sha256((route/'combined-25.pkl').read_bytes()).hexdigest())
