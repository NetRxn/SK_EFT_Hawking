from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run
from sys import argv, executable
from time import perf_counter
from pickle import loads

outer=int(argv[1])
root=Path(__file__).resolve().parent
base=Path(f'/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe{outer}-inner')
routes={0:'rescue-0-0',1:'slice-1',2:'rescue-2-0',3:'rescue-3-0',
        4:'rescue-4-1',5:'triangle',6:'triangle',7:'rescue-7-0',8:'rescue-8-0'}

def review(index):
    route=routes[index]
    started=perf_counter()
    if route=='triangle':
        source=base/f'join-cap-dense-label-rescue-{index}-1-reduced.pkl'
        condition=dict(loads(source.read_bytes())['conditioning'])
        destination=Path(f'slice-{index}-triangle-replay.out')
        with destination.open('xb') as log:
            proc=run([executable,'-B','-u',str(root/'triangle.py'),str(index),
                      str(source),str(condition['G',0,1,2])],stdout=log,stderr=log,
                     check=True,timeout=180)
        return index,route,proc.returncode,f'{perf_counter()-started:.6f}'
    state=base/f'label-{route}-reduced-frontier.pkl'
    receipt=base/f'{route}-contract.out'
    for method in ('sparse','sparse-support'):
        command_started=perf_counter()
        with Path(f'slice-{index}-{method}-replay.out').open('xb') as log:
            proc=run([executable,'-B','-u',str(root/f'{method}-replay.py'),
                      str(index),'0',str(state),str(receipt)],stdout=log,stderr=log,
                     check=False,timeout=180)
        elapsed=perf_counter()-command_started
        if proc.returncode==0:
            Path(f'slice-{index}-replay.out').write_bytes(Path(f'slice-{index}-{method}-replay.out').read_bytes())
            return index,method,proc.returncode,f'{elapsed:.6f}'
    raise ValueError(index)

with ThreadPoolExecutor(max_workers=2) as workers:
    for row in workers.map(review,map(int,argv[2:])):
        print(*row,sep='\t',flush=True)
