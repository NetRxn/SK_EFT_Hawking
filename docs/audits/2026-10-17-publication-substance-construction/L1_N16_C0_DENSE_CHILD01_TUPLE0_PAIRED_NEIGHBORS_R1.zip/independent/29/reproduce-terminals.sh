#!/usr/bin/env bash
set -euo pipefail
a=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe29-inner
while read -r i stem; do
 python3 -u sparse-replay.py "$i" terminal "$a/label-$stem-reduced-frontier.pkl" "$a/$stem-contract.out" > "slice-$i-replay.out"
done < seeds.tsv
for i in 5 6; do
 python3 -u triangle.py "$i" > "slice-$i-triangle-replay.out"
done
python3 terminal-timing.py > replay-timing.tsv
python3 audit.py > audit.out
python3 verify-shard-coverage.py > shard-coverage.out
