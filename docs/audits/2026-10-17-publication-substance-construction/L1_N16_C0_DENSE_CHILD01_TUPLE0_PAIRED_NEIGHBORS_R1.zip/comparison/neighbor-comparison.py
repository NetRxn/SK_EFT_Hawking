from collections import Counter
from pathlib import Path
import pickle

def ledger(path):
    rows = [line.split('\t') for line in path.read_text().splitlines()]
    assert len(rows) == 10 and rows[-1][0] == 'sum'
    terms = {int(row[1]): tuple(row[2:5]) for row in rows[:-1]}
    assert len(terms) == 9
    return terms, tuple(rows[-1][1:])

archive = Path(__file__).resolve().parent.parent
author = archive/'author'
reference = archive/'comparison'
for i,j in ((24,25),(28,30),(29,31)):
    first = (reference if i in (24,28) else author/str(i))/f'author-case{i}.tsv'
    second = author/str(j)/f'author-case{j}.tsv'
    a,total_a = ledger(first)
    b,total_b = ledger(second)
    print(i,j,'same subtotal',total_a==total_b,'same labeled rows',a==b,sep='\t')
    if (i,j) != (24,25):
        permutation = {48:192,192:48}
        assert set(a)==set(b)
        assert {permutation.get(k,k):v for k,v in a.items()} == b
        print(i,j,'all nine rows agree after 48↔192',sep='\t')

def marginal_invariant(factor):
    axes, rows, _ = factor
    return Counter(tuple(sorted(Counter(row[pos] for row in rows).values()))
                   for pos in range(len(axes)))

for i,j in ((28,30),(29,31)):
    values=[]
    for n in (i,j):
        with (Path.cwd()/f'combined-{n}.pkl').open('rb') as inp:
            values.append(pickle.load(inp)['factors'])
    left,right = values
    sizes = [len(rows) for _,rows,_ in left]
    assert sizes == [len(rows) for _,rows,_ in right] and len(set(sizes)) == len(sizes)
    assert left[2:] == right[2:]
    for k in (0,1):
        assert marginal_invariant(left[k]) != marginal_invariant(right[k])
        print(i,j,k,'different support marginals even after axis reordering',sep='\t')
