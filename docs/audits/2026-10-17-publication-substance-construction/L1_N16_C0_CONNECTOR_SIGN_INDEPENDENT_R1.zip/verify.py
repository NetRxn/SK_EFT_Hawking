from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, product

from src.core.formulas import (
    original_action_factors, original_coframe_blocks, original_spin4_link,
)
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, QComplex, Symbol, assemble_coframe,
    matrix_dagger, matrix_multiply,
)

reg = OriginalRegulator(temporal_axis=0)
x = reg.sites[0]
y, z = (reg.step(x, axis)[0] for axis in (2, 3))
ZERO = Polynomial()
plus = original_spin4_link((1, 0, 0, 0), (1, 0, 0, 0))
minus = original_spin4_link((-1, 0, 0, 0), (-1, 0, 0, 0))
central = {anchor: plus for anchor in reg.link_order}
central[y, 2] = central[z, 3] = minus
symbolic = {anchor: original_spin4_link(*[
    tuple(Polynomial.variable(Symbol('q', (*anchor, hand, i))) for i in range(4))
    for hand in ('L', 'R')
]) for anchor in reg.link_order}

# All root-plane placements, including the two distinct periodic directed anchors.
planes = Counter()
for center in reg.sites:
    for k, l in combinations(range(4), 2):
        anchors = ((center, k), (reg.step(center, k)[0], l),
                   (reg.step(center, l)[0], k), (center, l))
        temporal = [site for site, axis in anchors if axis == 0]
        if temporal:
            assert len(temporal) == 2 and {site[0] for site in temporal} == {center[0]}
            planes['curvature', center[0]] += 1
        else:
            assert 0 in set(range(4)) - {k, l}
            planes['coframe', center[0]] += 1
assert set(planes.values()) == {24}
print('full root-plane incidence', dict(planes), flush=True)

# Verify each directed original coframe pair is skew-Hermitian in its
# full bar/psi coefficient matrix. This is the sharp rule, since sharp
# takes bar_i psi_j to bar_j psi_i without a further exterior sign.
for center, axis, internal in product(reg.sites, range(4), range(4)):
    rows = original_coframe_blocks(reg, (center, axis, internal), symbolic)
    for head, reverse in ((rows[0], rows[1]), (rows[2], rows[3])):
        assert head.anchor == reverse.anchor
        assert head.bar_site == reverse.psi_site
        assert head.psi_site == reverse.bar_site
        assert head.weight == -reverse.weight
        assert matrix_dagger(head.matrix) == reverse.matrix
print('checked 512 exact directed coframe sharp-odd pairs')

# Clifford trace reality uses skew-Hermiticity only for distinct internal labels.
for a, b in product(range(4), repeat=2):
    if a != b:
        m = matrix_multiply(matrix_multiply(reg.gamma[a], reg.gamma[b]), reg.gamma5)
        assert matrix_dagger(m) == tuple(tuple(-p for p in row) for row in m)

def inversions(seq):
    return sum(v > w for i, v in enumerate(seq) for w in seq[i+1:])

def ordered(seq):
    return tuple(sorted(seq)), (-1)**inversions(seq)

def top_trial(links, same=False):
    keep = tuple(g for g in reg.generator_order if
                 (g[0] == x and g[1] == 'bar') or
                 (g[0] == y and g[1] == 'psi' and g[2] < 2) or
                 (g[0] == z and g[1] == 'psi' and (g[2] < 2) == same))
    place = {g: i for i, g in enumerate(keep)}
    assert len(place) == 8
    frames = {}
    active = Counter()
    for center, axis, label in product(reg.sites, range(4), range(4)):
        neighbor = reg.step(center, axis)[0]
        if frozenset((center, neighbor)) not in (frozenset((x,y)), frozenset((x,z))):
            continue
        frame = assemble_coframe(reg, original_coframe_blocks(reg, (center, axis, label), links))
        records = []
        for (i, j), weight in frame.entries:
            bar = (reg.sites[i // 4], 'bar', i % 4)
            psi = (reg.sites[j // 4], 'psi', j % 4)
            if bar in place and psi in place:
                records.append((place[bar], place[psi], weight))
                active[center, axis] += 1
        if records:
            frames[center, axis, label] = records
    candidate = tuple(c for c in reg.sites if sum(bool(active[c, a]) for a in range(4)) >= 2)
    if not candidate:
        return 0, QComplex()
    assert candidate == (x,)
    def quarters(polynomial):
        for term, coefficient in polynomial.terms:
            nr, dr, ni, di = coefficient.storage
            assert 4 % dr == 4 % di == 0
            yield term, nr*(4//dr), ni*(4//di)

    quartics = defaultdict(dict)
    raw_count = 0
    zero_matrix = tuple((ZERO,)*4 for _ in range(4))
    curvature_keys = {(x,0),(reg.step(x,0)[0],1),(reg.step(x,1)[0],0),(x,1)}
    # Restrict only the coefficient constructor to the proved unique
    # contributing plane, retaining physical matrices in every coframe.
    curvature_links = {key:links[key] if key in curvature_keys else zero_matrix
                       for key in reg.link_order}
    for factor in original_action_factors(reg, x, curvature_links):
        if factor.t_degree != 2:
            continue
        left, right = factor.components
        if left not in frames or right not in frames:
            continue
        raw_count += 1
        for (a,b,p),(c,d,q) in product(frames[left],frames[right]):
            word = (a,b,c,d)
            if len(set(word)) != 4:
                continue
            key, sign = ordered(word)
            acc = quartics[key]
            for (u,ar,ai),(v,br,bi),(w,cr,ci) in product(
                quarters(factor.coefficient), quarters(p), quarters(q),
            ):
                term = tuple(sorted(u+v+w))
                ab_r,ab_i = ar*br-ai*bi, ar*bi+ai*br
                sr,si = acc.get(term, (0,0))
                acc[term] = sr+sign*(ab_r*cr-ab_i*ci), si+sign*(ab_r*ci+ab_i*cr)
    assert raw_count == 64
    quartics = {k: {t: c for t,c in v.items() if c != (0,0)} for k, v in quartics.items()}
    quartics = {k: v for k, v in quartics.items() if v}
    # Each polynomial is homogeneous of degree one in each occupied
    # chirality/anchor. Joining identical raw monomials is exact because
    # a different coordinate or anchor makes at least one odd Haar exponent.
    sparse = {}
    for mask, polynomial in quartics.items():
        sparse[mask] = polynomial
        for term in sparse[mask]:
            assert len({s.index[:-1] for s in term}) == len(term)
    exact = defaultdict(lambda: (0,0))
    for left, terms in sparse.items():
        right = tuple(i for i in range(8) if i not in left)
        if left >= right or right not in sparse:
            continue
        sign = (-1)**inversions(left + right)
        for term, coefficient in terms.items():
            if term in sparse[right]:
                a,b = coefficient
                c,d = sparse[right][term]
                sr,si = exact[len(term)]
                exact[len(term)] = sr+sign*(a*c-b*d), si+sign*(a*d+b*c)
    ans = sum((QComplex(Fraction(a,4096*4**n), Fraction(b,4096*4**n))
               for n,(a,b) in exact.items()), QComplex())
    return len(sparse), ans

plane = ((x,0),(reg.step(x,0)[0],1),(reg.step(x,1)[0],0),(x,1))
active = set(plane) | {(x,2),(y,2),(x,3),(z,3)}
# Outside this explicit support the coframes do not retain two active
# directions at any center. Such anchors cannot appear in the trial.
projected = {key:(symbolic[key] if key in active else plus) for key in reg.link_order}
whole = top_trial(projected)
assert whole == (16, QComplex(Fraction(3, 4))), whole
assert top_trial(projected, same=True)[1] == QComplex()
print('canonical raw ordered quartics, full selected moment', whole)

def check_central(point, wanted):
    spatial = set()
    for center, axis, label in product(reg.sites, range(1, 4), range(4)):
        coeffs = assemble_coframe(reg, original_coframe_blocks(reg, (center, axis, label), point))
        if coeffs.entries:
            spatial.add((center, axis))
    assert spatial == wanted

check_central(central, {(x,2), (x,3), (y,2), (z,3)})
fixed = central | {key: value for key, value in symbolic.items() if key[1] == 0}
fixed_result = top_trial(fixed)
assert fixed_result[1] == QComplex(3), fixed_result
assert top_trial(fixed, same=True)[1] == QComplex()
print('canonical raw ordered quartics, fixed central spatial and temporal Haar', fixed_result)
swap = lambda c: reg.step(c,0)[0]
reverse = {(c,a): central[swap(c),a] for c,a in central}
check_central(reverse, {(swap(c), a) for c,a in {(x,2),(x,3),(y,2),(z,3)}})
assert top_trial(reverse | {key: value for key,value in symbolic.items() if key[1] == 0}) == (0, QComplex())
print('swapped point support check passed')
