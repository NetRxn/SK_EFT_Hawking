from itertools import combinations
from math import comb
from random import Random

def reorder(word):
    return tuple(sorted(word)), (-1)**sum(a > b for i,a in enumerate(word) for b in word[i+1:])

def check(n, pairs):
    top = tuple(range(2*n))
    def complement(i):
        return tuple(v for v in range(n) if v not in i)
    def swap(k):
        return k+n if k<n else k-n
    def sharp(k):
        return k^2
    def r(i,j):
        left, s = reorder(tuple(sharp(k) for k in i[::-1]))
        right, t = reorder(tuple(sharp(k) for k in j[::-1]))
        return left, right, s*t*((-1)**(len(i)*len(j)))
    def p(i,j):
        ic,jc = complement(i),complement(j)
        return jc,ic,reorder(i+ic)[1]*reorder(j+jc)[1]
    assert reorder(tuple(map(swap,top)))[1] == reorder(tuple(map(sharp,top[::-1])))[1] == 1
    checked = 0
    for i,j in pairs:
        a,b,s = p(i,j)
        word = i+tuple(v+n for v in j)+tuple(map(swap,a+tuple(v+n for v in b)))
        assert reorder(word) == (top,s)
        assert p(a,b) == (i,j,s)
        c,d,t = r(i,j)
        assert r(c,d) == (i,j,t)
        e,f,u = p(c,d)
        g,h,v = r(a,b)
        assert (e,f,t*u) == (g,h,s*v)
        checked += 1
    return checked
for n in (4,8):
    evens = [w for k in range(0,n+1,2) for w in combinations(range(n),k)]
    print(n, check(n, ((i,j) for i in evens for j in evens)))
rng = Random(3510)
def sample():
    return tuple(sorted(rng.sample(range(64), 2*rng.randrange(33))))
print(64, check(64, ((sample(),sample()) for _ in range(512))))
ambient = sum(comb(64,i)*comb(64,64-i) for i in range(0,65,2))
assert ambient == (comb(128,64)+comb(64,32))//2
print('ambient even/even middle degree', ambient)
