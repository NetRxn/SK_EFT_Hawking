# Draft PR118 exact 23-test cohort

- known `a36f923d34cf0c4145f10ab8846595f0bd22dd86` — 7 passed, 16 failed.
- post-repair `9f8608351d9c5c94ed9d18df24ea2649087e8fd5` — 13 passed, 10 failed.
- post-backing `9c6d0187f269ed56d865b0835c906ac062f65529` — 15 passed, 8 failed.

Recovered tests:
- `tests.test_d5_bundles_readiness.TestSentenceLengthRatchet::test_ceiling_matches_the_live_measurement`
- `tests.test_d5_bundles_readiness.TestSentenceLengthRatchet::test_gate_is_green_at_the_frozen_ratchet`
- `tests.test_d5_prose_checks.TestSpelledOutCensusFigures::test_the_live_ceiling_has_ZERO_headroom`
- `tests.test_ratchets_have_zero_headroom.TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[count_literals]`
- `tests.test_ratchets_have_zero_headroom.TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[numerical_literals]`
- `tests.test_validate_public_surface.TestNumericalLiteralPopulationComposition::test_ceiling_matches_the_live_population`

Recovered tests:
- `tests.test_d5_reviews.TestChainBackingTargetsResolve::test_a_dangling_link_seeded_past_the_ceiling_fails`
- `tests.test_d5_reviews.TestChainBackingTargetsResolve::test_the_ceiling_carries_no_headroom`

The newest raw run uses the same scratch setup as the two earlier runs. Its eight failures include one architecture inventory test that passes separately on the same head after installing the expected primary pre-commit hook into the scratch clone. A Git config override alone failed because the census reads the hook directory directly. No tracked change was required.

The remaining seven tests cover CI measurement coverage (83/85 in this scratch environment), the pre-existing module coverage count (186 vs 147, two tests), and Stage 13 finding population limits (four tests). The 83/85 result leaves axiom closure and manuscript length unmeasured in the scratch run. It does not qualify either gate.
