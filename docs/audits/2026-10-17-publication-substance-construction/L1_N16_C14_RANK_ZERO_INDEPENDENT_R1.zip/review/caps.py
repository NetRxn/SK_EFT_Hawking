from pathlib import Path
import json,sys
p=Path(sys.argv[1])
e=json.loads((p/'edge-meta.json').read_text())
c=json.loads((p/'result.json').read_text())
assert sum(e['charged_operations'].values())==575896
assert sum(c['charged_operations'].values())==c['meters']['work']==176762
assert e['storage']['rows']==113328 and c['meters']['rows']==118010
assert e['storage']['charged_bytes']==512*113328==58023936
assert c['meters']['tracked_bytes']==384*118010==45315840
assert e['cap']['rows']==120000 and e['cap']['accounted_bytes']==64*1024**2
assert 512*e['cap']['rows']<e['cap']['accounted_bytes']
assert e['storage']['serialized_bytes']==sum((p/f).stat().st_size for f in ('zero-edge-1.jsonl','zero-edge-2.jsonl','zero-edge-3.jsonl','zero-site-factors.jsonl'))==1108056
assert c['meters']['output_bytes']==sum((p/f).stat().st_size for f in ('plane-01-trace.jsonl','compatible-mask-bridge.jsonl'))==36268
assert (e['rss_peak_bytes'],c['peak_rss_bytes'])==(116228096,124993536)
assert "100001, 51200512, 100000, 67108864" in (p/'edge-refusal.log').read_text().splitlines()[-1]
for name in ('control','indexed','partition','seam'):
    assert '4000001, 4000000' in (p/f'compose-{name}-refusal.log').read_text().splitlines()[-1]
assert "300001, 115200384" in (p/'compose-nonzero-search-refusal.log').read_text().splitlines()[-1]
print('meter and serialized byte totals match; 120k-row cap retains 64MiB bound; initial row and work refusals independently read')
