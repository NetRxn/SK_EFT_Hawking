from collections import Counter, defaultdict
from functools import cache
from itertools import combinations, product
from math import prod
from pathlib import Path
from fractions import Fraction
import json,sys
from src.core.formulas import original_action_factors, original_spin4_link, original_coframe_blocks
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol

a,star,sewn,prior=map(Path,sys.argv[1:])
def load(f):return json.loads(f.read_text())
def rows(f):return [json.loads(line) for line in f.read_text().splitlines()]
def fr(v):return tuple(map(fr,v)) if isinstance(v,(list,tuple)) else v
def co(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def sumz(z,w):return z[0]+w[0],z[1]+w[1]
def sgn(word):return (-1)**sum(i>j for n,i in enumerate(word) for j in word[n+1:])
def bits(i,m):return [8*i+k for k in range(8) if m>>k&1]
def readtable(f):
    r=fr(rows(f))
    t=dict(r)
    assert len(r)==len(t) and all(any(x) for x in t.values())
    return t
r=OriginalRegulator()
idx={s:i for i,s in enumerate(r.sites)}
x=r.sites[0]
pos={z:i for i,z in enumerate(r.generator_order)}
assert (r.extents,r.boundary_signs,r.convention,r.word)==((2,)*4,(1,)*4,'source_C','closed')
L={a:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*a,h,k))) for k in range(4)) for h in ('L','R'))) for a in r.link_order}
M=load(a/'result.json')
E=load(a/'edge-meta.json')
old=[readtable(star/f'edge-{i}.jsonl') for i in range(4)]
new=[readtable(a/f'zero-edge-{i}.jsonl') for i in range(1,4)]
C=load(prior/'support-census.json')['sites']
occ=load(star/'result.json')['row']
assert occ['exponential_divisor']==512

def edge(x,d):
    return frozenset((x,r.step(x,d)[0]))
src=[]
for i,(site,*axes) in enumerate(occ['planes']):
    variants={tuple(sorted((idx[tuple(y)],d) for y,d in anchors)) for degree,comp,anchors,n,_ in C[site]['raw_branches']
              if n and degree==2 and tuple(sorted(j for j,_ in comp))==tuple(axes)}
    assert len(variants)==1
    src.append(('S2',site,i,tuple(axes),next(iter(variants))))
src += [('S4',site,i,(0,1,2,3),()) for site,n in enumerate(occ['S4_occupations']) for i in range(n)]

def owners(x,d):
    want=edge(r.sites[x],d)
    frames=[(f,c,i,j) for f,c,i,axes,_ in src for j in axes if edge(r.sites[c],j)==want]
    traces=[(f,c,i,(e,j)) for f,c,i,_,anchors in src for e,j in anchors if edge(r.sites[e],j)==want]
    return fr(frames),fr(traces)

@cache
def mom(q):
    powers=Counter(q)
    if any(n%2 for n in powers.values()):
        return Fraction()
    return Fraction(prod(3 if n==4 else 1 for n in powers.values()),
        prod(j for n in Counter(i//4 for i in q).values() for j in range(4,4+n,2)))

for d,(expected,tab) in enumerate(zip(E['edges'],new,strict=True),1):
    neighbor=idx[r.step(x,d)[0]]
    assert (d,neighbor)==(expected['axis'],expected['neighbor'])
    f,t=owners(0,d)
    assert (f,t)==(fr(expected['coframes']),fr(expected['open_trace_legs']))
    assert len(f)==len(t)==2 and all(o[1]==0 for o in f)
    alpha=defaultdict(list)
    qindex={(y,d,h,j):i for i,(y,h,j) in enumerate(product((x,r.sites[neighbor]),('L','R'),range(4)))}
    for component in range(4):
        for b in original_coframe_blocks(r,(x,d,component),L):
            for i,j in product(range(4),repeat=2):
                word=(pos[b.bar_site,'bar',i],pos[b.psi_site,'psi',j])
                for k,z in b.matrix[i][j].terms:
                    assert len(k)==1 and k[0].index[:2]==b.anchor
                    c=(z.real*4*b.weight,z.imag*4*b.weight)
                    assert all(n.denominator==1 for n in c)
                    alpha[qindex[k[0].index]].append((component,word,tuple(map(int,c))))
    out=defaultdict(lambda:(0,0))
    support=0
    qslots=[range(8) if e==0 else range(8,16) for _,_,_,(e,_) in t]
    for q in product(range(16),range(16),*qslots):
        factor=mom(q)*48
        if not factor:continue
        assert factor.denominator==1
        support+=1
        for (a0,w0,z0),(a1,w1,z1) in product(alpha[q[0]],alpha[q[1]]):
            word=w0+w1
            if len(set(word))!=4:continue
            m,n=(sum(1<<(i%8) for i in word if i//8==rank) for rank in (0,neighbor))
            assert m.bit_count()==n.bit_count()==2
            k=(m,n,a0,a1,*q[2:])
            out[k]=sumz(out[k],tuple(int(factor)*sgn(word)*z for z in co(z0,z1)))
    assert {k:v for k,v in out.items() if any(v)}==tab
    assert support==240 and len(tab)==14208
    print('rank-zero edge',d,'rows',len(tab),'zero-pruned',len(out)-len(tab),'support',support,flush=True)

def sitepartitions(axes,i=0,remaining=frozenset(range(8)),word=()):
    if not remaining:
        yield tuple(sum(1<<j for j in p) for p in word),sgn(sum(word,()))
        return
    for p in combinations(sorted(remaining),2):
        if sum(1<<j for j in p) in axes[i]:
            yield from sitepartitions(axes,i+1,remaining-set(p),word+(p,))
shared=Counter(k[:2] for k in old[0])
c8=[Counter(k[0] for k in t) for t in old[1:]]
c0=[Counter(k[0] for k in t) for t in new]
p0=dict(sitepartitions((set(j for i,j in shared),*c0)))
p8=dict(sitepartitions((set(i for i,j in shared),*c8)))
assert p0==dict(fr(rows(a/'zero-site-factors.jsonl'))) and len(p0)==2520
assert p8=={tuple(k):s for k,s,_ in rows(star/'site-factors.jsonl')} and len(p8)==240
b0=Counter(k[0] for k in p0)
b8=Counter(k[0] for k in p8)
bridge={(i,j):(b8[i],b0[j],n) for (i,j),n in shared.items() if b8[i] and b0[j]}
assert bridge=={(i,j):(a,b,n) for i,j,a,b,n in rows(a/'compatible-mask-bridge.jsonl')}
assert len(bridge)==100
gross=0
compatible=0
for i,j in product(p8,p0):
    n=shared[i[0],j[0]]
    if n:
        compatible+=1
        gross+=n*prod(c[t] for c,t in zip(c8,i[1:]))*prod(c[t] for c,t in zip(c0,j[1:]))
assert (compatible,gross)==(73440,36474951220875755520)
print('signed site factors, bridge, compatible partition pairs, gross visits',len(p0),len(p8),len(bridge),compatible,gross,flush=True)

planes={(0,1):((0,2),(0,3),(2,3),(1,2)),(2,3):((0,0),(8,1),(4,0),(0,1))}
trace={k:defaultdict(lambda:(0,0)) for k in planes}
for f in original_action_factors(r,x,L):
    if f.t_degree!=2:continue
    ordered=sorted(f.components)
    plane=tuple(d for _,d,_ in ordered)
    if plane not in planes:continue
    for symbols,z in f.coefficient.terms:
        v={(idx[s.index[0]],s.index[1]):s.index[3]+4*(s.index[2]=='R') for s in symbols}
        q0,q1,r0,r1=(v[q] for q in planes[plane])
        key=(q0,q1,*(j for _,_,j in ordered),r0,r1)
        rr,ii=z.real*4,z.imag*4
        assert rr.denominator==ii.denominator==1
        trace[plane][key]=sumz(trace[plane][key],(int(rr),int(ii)))
trace={p:{k:z for k,z in v.items() if any(z)} for p,v in trace.items()}
assert trace[(0,1)]==readtable(a/'plane-01-trace.jsonl')
assert trace[(2,3)]==readtable(sewn/'trace-slices.jsonl')
for t in trace.values():
    assert Counter(Counter(k[:2] for k in t).values())=={48:32}
assert M['common_denominator']==768**5*64**2*4**4==280159925619463815168
tiles=set(fr(rows(sewn/'conditional-tiles.jsonl')))
print('both actual plane trace tables exactly matched and all four occurrence coordinate interfaces retained',flush=True)

for z in M['partition_and_seam_restricted_controls']:
    b8,b0=fr(z['rank8_partition']),fr(z['rank0_partition'])
    ext8,ext0=fr(z['old_edge_boundary']),fr(z['new_remote_masks'])
    q=fr(z['retained_seam_tile'])
    q1,q2,q3=fr(z['retained_new_seam_labels'])
    R01,R23=fr(z['residual_plane01']),fr(z['residual_plane23'])
    assert (b8[0],b8[1],*q) in tiles
    word=sorted(bits(8,b8[0])+bits(0,b0[0]))
    for i,n in enumerate((12,10,9),1):
        word+=sorted(bits(8,b8[i])+bits(n,ext8[i-1][0]))
    for i,n in enumerate((4,2,1),1):
        word+=sorted(bits(0,b0[i])+bits(n,ext0[i-1]))
    assert len(set(word))==len(word)==28
    sign=sgn(word)
    assert sign==p8[b8]*p0[b0] and sgn([1 if i==0 else 0 if i==1 else i for i in word])==-sign
    prefix=(sign,0)
    for i in range(1,4):
        key=(b8[i],*ext8[i-1],*(q[2:] if i==1 else ()))
        prefix=co(prefix,old[i][key])
    lookup=lambda table,local,remote,q:[(k[2:4],v) for k,v in table.items() if k[:2]==(local,remote) and k[4:]==q]
    opts=[lookup(old[0],b8[0],b0[0],q[:2])]
    opts += [lookup(tab,b0[i],ext0[i-1],qi) for i,(tab,qi) in enumerate(zip(new,(q1,q2,q3),strict=True),1)]
    values={}
    for (j0,v0),(j1,v1),(j2,v2),(j3,v3) in product(*opts):
        v=prefix
        for t in (v0,v1,v2,v3):v=co(v,t)
        for i in range(2):
            v=co(v,trace[0,1].get((q2[i],q3[i],j0[i],j1[i],*R01[i]),(0,0)))
            v=co(v,trace[2,3].get((q[i],q[2+i],j2[i],j3[i],R23[i],q1[i]),(0,0)))
        if any(v):values[(j0,j1,j2,j3)]=v
    value=(sum(x for x,_ in values.values()),sum(y for _,y in values.values()))
    assert value==fr(z['coefficient_numerator'])==(0,0) and len(values)==16
    path=z['one_contributing_path']
    selected=tuple(tuple(path[k][:2]) for k in ('left_edge','new_edge1','new_edge2','new_edge3'))
    assert values[selected]==fr(path['numerator'])
    assert tuple(-2*x for x in values[selected])==fr(z['adverse_single_path_sign_numerator'])
    print('restricted exact cancellation',len(values),value,'path-sign negative',tuple(-2*x for x in values[selected]),flush=True)
assert owners(4,0)==((('S4',12,0,0),('S4',12,1,0)),(('S2',0,2,(4,0)),('S2',0,3,(4,0))))
assert idx[r.step(r.sites[4],0)[0]]==12
print('residual (4,0) edge true owners are S4 rank12 occurrences 0/1 and S2 rank0 occurrences 2/3; closes only its Haar factors',flush=True)
