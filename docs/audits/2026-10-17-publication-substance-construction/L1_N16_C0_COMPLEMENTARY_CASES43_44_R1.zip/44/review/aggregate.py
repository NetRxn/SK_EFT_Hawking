from fractions import Fraction
from pathlib import Path
from re import M,search

from binding import ROOT, records, rows
from exact_factors import DEN

audit=Path('audit.out').read_text()
assert audit.endswith('PASS all 48/9 source roster, all ten inverse lifts and nine terminal conditioning bindings\n')
lineage=Path('verify-lineage.out').read_text().splitlines()
assert 'PASS outer cap/restart lineage recreated seven-factor inner parent' in lineage
assert sum(line.startswith('PASS inner cap/restart lineage ') for line in lineage)==9
shards=Path('verify-shards.out').read_text().splitlines()
assert sum(line.startswith('PASS author shard ') for line in shards)==32
value=r'^(?:independent )?exact normalized real (\S+) imaginary (\S+)(?: |$)'
raw=r'^(?:PASS )?raw(?: scalar numerator)? (-?\d+) (?:imaginary )?(-?\d+) factor denominator (\d+)$'
vals=[]
for i,coord,matches,real,imag,name in records:
    replay=(Path('replays')/f'{i}-replay.out').read_text()
    expected=tuple(map(Fraction,(real,imag)))
    assert expected==tuple(map(Fraction,search(value,replay,M).groups()))
    assert expected==tuple(map(Fraction,search(value,(ROOT/name).read_text(),M).groups()))
    r,j,d=map(int,search(raw,replay,M).groups())
    assert d==DEN and tuple(Fraction(x,d*16*4**64) for x in (r,j))==expected
    vals.append(expected)
    print('PASS slice',i,coord,matches,*expected,flush=True)
total=tuple(sum(column,Fraction(0)) for column in zip(*vals,strict=True))
assert total==tuple(map(Fraction,rows[-1][1:]))
print('PASS exact case 44 subtotal',*total,flush=True)
