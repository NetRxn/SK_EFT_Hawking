# Complementary tuple 0 cut and dense profile pilot

The per-outer-case reviews name the frozen source and original selector-1
input. Rebuild each outer cut, nine inner cuts, inverse lifts and all saved
frontiers from those source pins. Replay triangles 2 and 3 and four-factor
slices 7 and 8 against their individual shard receipts. Use only trusted
serialized inputs.

Compare preceding-forty-three.tsv against the prior checkpoint's
retally.tsv. Run python3 verify-and-retally.py for the
independent signed arithmetic and cumulative result.
