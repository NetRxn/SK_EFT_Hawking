"""Small exact fixture with both placements, collision, and cap refusals."""
from fractions import Fraction
from itertools import permutations, product
from types import SimpleNamespace
import json

import candidate as m

def q(index):
    return m.S("q", ("fixture", index))

def ep(mask, key, coefficient=1):
    return m.E(((mask, m.P(((tuple(sorted(key)), m.Q(coefficient)),))),))

outer_label = (2,3,0,1,0,1)
s2_label = (2,*outer_label)
s4_label = (4,0,1,2,3)
shared = q(200)

def site(degree, start, tag, *, coframe_collision=False):
    coframes = {(axis,frame): m.E() for axis,frame in product(range(4), repeat=2)}
    components = tuple((axis,axis) for axis in range(degree))
    for axis,frame in components:
        bit = 1 << (start+2*axis)
        second = bit << 1
        coord = shared if axis == 0 and start in (4,12) else q(tag+axis)
        coframes[axis,frame] = ep(bit|second,(coord,),axis+1)
        if axis == 0 and coframe_collision:
            coframes[axis,frame] += ep(1 << 4 | second,(coord,),-1)
    if degree == 2:
        trace = m.P(((tuple(q(tag+i) for i in range(4,8)),m.Q(3)),))
        label, coupling = s2_label,m.G2
        raw = {label:[
            SimpleNamespace(components=tuple((0,axis,frame) for axis,frame in order),
                            coefficient=trace*Fraction(1,4))
            for order in (components,components[::-1],components,components[::-1])
        ]}
        raw.update({(2,i):[SimpleNamespace(
            components=((0,0,2),(0,1,2)),coefficient=m.P()
        )] for i in range(380)})
    else:
        trace = m.P.scalar(m.Q(1))
        label, coupling = s4_label,m.G1
        raw = {(4,*order): [SimpleNamespace(
            components=tuple((0,axis,frame) for axis,frame in enumerate(order)),
            coefficient=m.P.scalar(m.r4.o.epsilon(order)),
        )] for order in permutations(range(4))}
    h = m.E(((0,trace*m.P.variable(coupling)),))
    local = {label: (components,h)}
    canonical = h
    for component in reversed(components):
        canonical = coframes[component]*canonical
    return coframes, local, raw, canonical

cx,xchoices,rx,xp = site(2,0,0)
cy,ychoices,ry,yp = site(2,20,20)
hx,hy = {outer_label:xchoices[s2_label][1]}, {outer_label:ychoices[s2_label][1]}
j = m.S("J",("fixture",0))
d0 = ep(1 << 24 | 1 << 25,(q(100),j))
d1 = d0*m.Q(-2)
slot = m.SLOTS[1]
d = d0+d1

def refused(invoke, match):
    try:
        invoke()
    except RuntimeError as exc:
        assert str(exc).startswith(match), str(exc)
        return str(exc)
    raise AssertionError(f"missing refusal: {match}")

cases = {}
for degrees in ((2,4),(4,2)):
    cw,ww,rw,wp = site(degrees[0],4,40)
    cz,wz,rz,zp = site(degrees[1],12,60,coframe_collision=True)
    inputs = cx,hx,cw,ww,{m.SLOTS[0]:d0,slot:d},cy,hy
    z_inputs = cz,wz
    labels = (outer_label,next(iter(ww)),next(iter(wz)),outer_label)
    ((mask,symbols,_),value), = m.r4.rows(xp*wp*zp*d*yp)
    target = mask,symbols,slot
    assert symbols.count(shared) == 2
    colliding = ep(1 << 4 | 1 << 13,(shared,),-1)
    assert not (cw[0,0]*colliding).terms
    work = m.r5.Work(cap=200_000,oracle_record_cap=m.r10.PAIR_CAP)
    out,prod_peak,later,selected,paths = m.production(
        target,inputs,z_inputs,work,20,degrees,selected=labels
    )
    oracle,oracle_peak = m.oracle(
        target,inputs,z_inputs,(rw,rz),(rx,ry),work,20,len(out.table),degrees
    )
    assert out.table == {(outer_label,(),outer_label):(value,1)}
    assert {(key,v) for key,(v,_) in oracle.table.items()} == {((outer_label,(),outer_label),value)}
    assert (selected,paths) == m.selected_witness(target,inputs,z_inputs,labels,work)[:2] == (value,1)
    frames,counts,_ = m.frame_controls(target,labels,inputs,z_inputs,degrees,work,0)
    assert frames == [value,m.ZERO,m.ZERO,m.ZERO] and counts == [1,0,0,0]
    output_refusal = refused(
        lambda: m.production(target,inputs,z_inputs,m.r5.Work(cap=200_000),0,degrees),
        "signed output cap: retained 0, prospective 1, cap 0",
    )
    oracle_refusal = refused(
        lambda: m.oracle(target,inputs,z_inputs,(rw,rz),(rx,ry),
                         m.r5.Work(cap=200_000,oracle_record_cap=1),20,1,degrees),
        "quartic oracle cap:",
    )
    old = m.r10.LOCAL_CAP
    m.r10.LOCAL_CAP = prod_peak-1
    try:
        local_refusal = refused(
            lambda: m.production(target,inputs,z_inputs,m.r5.Work(cap=200_000),20,degrees),
            f"quartic local cap: prospective {prod_peak}, cap {prod_peak-1}",
        )
    finally:
        m.r10.LOCAL_CAP = old
    old = m.r10.LATER_CAP
    m.r10.LATER_CAP = 0
    try:
        later_refusal = refused(
            lambda: m.production(target,inputs,z_inputs,m.r5.Work(cap=200_000),20,degrees),
            "multicenter later path cap at prospective 1",
        )
    finally:
        m.r10.LATER_CAP = old
    fanout_refusal = refused(
        lambda: list(m.complementary_join(
            {(1,()):{(0,):(m.ONE,1)}},{(2,()):{(1,):(m.ONE,1)}},3,(),m.r5.Work(cap=1)
        )),
        "fiber work cap at 1 on multicenter_complement_updates plus 1",
    )
    cases[str(degrees)] = dict(total=str(value),production_peak=prod_peak,oracle_peak=oracle_peak,
                               oracle_prospective=work.oracle_max_prospective_records,
                               later=later,output_refusal=output_refusal,
                               oracle_refusal=oracle_refusal,local_refusal=local_refusal,
                               later_refusal=later_refusal,fanout_refusal=fanout_refusal)
assert not (m.PACKET/"original.jsonl").exists()
print(json.dumps(cases,sort_keys=True))
