import json
import candidate as m

work = m.r5.Work(cap=m.r10.WORK_CAP,oracle_record_cap=m.r10.PAIR_CAP)
parent = m.accepted_parent()
_,(_,_,w,z),inputs,z_inputs,_,d0,d1 = m.setup(work)
baseline = m.baseline_controls(parent,inputs,z_inputs,d0,d1,w,z,work)
print(json.dumps(dict(baseline=baseline,work=work.used,cap=m.r10.WORK_CAP),sort_keys=True))
