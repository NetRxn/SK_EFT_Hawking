"""Exact bounded quartic controls for the original fixed-center R10 seam."""
from collections import defaultdict
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json
import random
import sys

HERE = Path(__file__).parent
spec = spec_from_file_location("r10_quartic_inputs", HERE / "publication-task4-continuation-powers-r10.py")
r10 = module_from_spec(spec)
sys.modules[spec.name] = r10
spec.loader.exec_module(r10)
r5, r6, r7, r8 = r10.r5, r10.r6, r10.r7, r10.r8
Q, P, E, SLOTS = r10.Q, r10.P, r10.E, r10.SLOTS
ZERO = Q(0)
ONE = Q(1)
POWER = (4, 0)
PREFIX_RECORDS = 652
PREFIX_DIGEST = "25534627ec143bea9a76b664638d170d842a18052773f2969c11922da158829a"
WITNESS_CANDIDATE_CAP = 12

class Admission:
    def __init__(self, cap):
        self.cap = cap
        self.peak = 0

    def check(self, requested):
        if requested > self.cap:
            raise RuntimeError(f"quartic local cap: prospective {requested}, cap {self.cap}")
        self.peak = max(self.peak, requested)

def add_term(table, key, coefficient, paths, admission, fixed=0):
    old = table.get(key)
    if old is None:
        admission.check(fixed + len(table) + 1)
        table[key] = coefficient, paths
    else:
        table[key] = old[0] + coefficient, old[1] + paths

def split(center):
    first = center & -center
    rest = [1 << i for i in range(center.bit_length()) if (1 << i) & (center ^ first)]
    for three in combinations(rest, 3):
        half = first | sum(three)
        yield half, center ^ half

def partitioned_quartic(vertices, wanted, center, work, admission):
    """Join distinct complementary center halves; retain one live pair at a time."""
    assert center.bit_count() == 8
    output = {}
    two_bit_buckets = defaultdict(list)
    for state in vertices:
        work.charge("quartic_vertex_index")
        mask, _ = state
        cm = mask & center
        assert cm.bit_count() == 2
        admission.check(len(vertices) + len(wanted) + sum(map(len, two_bit_buckets.values())) + 1)
        # Store the key only; signed coefficients live in vertices.
        two_bit_buckets[cm].append(state)
    fixed = len(vertices) + len(wanted) + sum(map(len, two_bit_buckets.values()))
    # wanted is passed by the caller, and already counted above. Its exact
    # keys partition the requested quartic coefficients.
    for left_center, right_center in split(center):
        work.charge("quartic_center_splits")
        def pairs(half_center, other):
            half = {}
            for first_center, first_keys in two_bit_buckets.items():
                work.charge("quartic_bucket_filters")
                if first_center & half_center != first_center:
                    continue
                second_center = half_center ^ first_center
                if first_center > second_center:
                    continue
                for am, ak in first_keys:
                    work.charge("quartic_first_rows")
                    av, an = vertices[am, ak]
                    for bm, bk in two_bit_buckets.get(second_center, ()):
                        work.charge("quartic_half_pairs")
                        if am & bm:
                            continue
                        mask, symbols = am | bm, tuple(sorted(ak + bk))
                        for tm, tk in wanted:
                            work.charge("quartic_half_projection")
                            if mask & tm == mask and r5.subtract(tk, symbols) is not None:
                                break
                        else:
                            continue
                        ab = r5.mask_sign(am, bm)
                        ba = r5.mask_sign(bm, am)
                        bv, bn = vertices[bm, bk]
                        value = av * bv * Fraction(ab + ba, 2)
                        add_term(half, (mask, symbols), value, 2 * an * bn,
                                 admission, fixed + len(output) + len(other))
            return half

        left = pairs(left_center, ())
        if not left:
            del left
            continue
        right = pairs(right_center, left)
        if not right:
            del left, right
            continue
        # Index by the complete pair key. The residual target determines
        # at most one partner for each left coefficient and target.
        for tm, tk in wanted:
            for (lm, lk), (lv, ln) in left.items():
                work.charge("quartic_complement_tests")
                if lm & tm != lm:
                    continue
                rk = r5.subtract(tk, lk)
                if rk is None:
                    continue
                rm = tm ^ lm
                match = right.get((rm, rk))
                if match is None:
                    continue
                rv, rn = match
                lr, rl = r5.mask_sign(lm, rm), r5.mask_sign(rm, lm)
                value = lv * rv * Fraction(lr + rl, 6)
                add_term(output, (tm, tk), value, 2 * ln * rn,
                         admission, fixed + len(left) + len(right))
        del left, right
    return output

def direct_coefficients(vertices, wanted, center, work, admission):
    """Independent recursion over ordered raw exterior factors.

    At every recursion level the factor that owns the lowest surviving
    center bit is unique. The ordered draws of an unordered disjoint
    factor collection all have the same sign, so anchoring on that bit
    counts the collection once with the exponential weight already
    absorbed. No half-table or pair symmetry enters this oracle.
    """
    index = defaultdict(list)
    indexed = 0
    for state, (value, _) in vertices.items():
        if not value:
            continue
        mask, _ = state
        bits = mask & center
        assert bits.bit_count() == 2
        while bits:
            bit = bits & -bits
            work.charge("quartic_direct_index")
            admission.check(len(vertices) + len(wanted) + indexed + 1)
            index[bit].append(state)
            indexed += 1
            bits ^= bit
    result = {}
    memo = {}
    def coeff(mask, key):
        state = mask, key
        bits = mask & center
        if not bits:
            return ONE if not mask and not key else ZERO
        if state in memo:
            return memo[state]
        value = ZERO
        for vm, vk in index[bits & -bits]:
            work.charge("direct_anchored_factors")
            if vm & mask != vm:
                continue
            suffix = r5.subtract(key, vk)
            if suffix is not None:
                rest = mask ^ vm
                vv = vertices[vm, vk][0]
                value += vv * coeff(rest, suffix) * r5.mask_sign(vm, rest)
        # Cache only if capacity permits. Recursion remains exact when a
        # memo state is streamed instead. Account the one temporary state.
        live = len(vertices) + len(wanted) + indexed + len(result) + len(memo)
        if live + 6 <= admission.cap:
            admission.check(live + 6)
            memo[state] = value
        return value

    for mask, key in wanted:
        work.charge("quartic_direct_targets")
        # Reserve one output row and five nested recursion frames.
        admission.check(len(vertices) + len(wanted) + indexed + len(result) + len(memo) + 6)
        result[mask, key] = coeff(mask, key)
    return result

def projection(poly, target, work, admission, fixed):
    mask, symbols, _ = target
    selected = []
    for (m, key, slot), value in r10.r4.rows(poly):
        work.charge("operand_projection_checks")
        assert not slot
        if m & mask == m and r5.subtract(symbols, key) is not None:
            admission.check(fixed + len(selected) + 1)
            selected.append((m, key, value))
    return selected

def group_factors(target, coframes, traces, work, admission, used):
    c = {}
    live = 0
    for key, poly in coframes.items():
        rows = projection(poly, target, work, admission, used() + live)
        c[key] = rows
        live += len(rows)
    for key, poly in traces.items():
        work.charge("quartic_outer_trace_groups")
        _, _, mu, nu, a, b = key
        if not (c[mu, a] and c[nu, b]):
            continue
        h = projection(poly, target, work, admission, used() + live)
        if h:
            yield key, (c[mu, a], c[nu, b], h), live + len(h)
        del h


def exterior_residuals(target, inputs, center, work, admission):
    cx, hx, _, _, contacts, cy, hy = inputs
    mask, symbols, slot = target
    d = projection(contacts[slot], target, work, admission, 0)
    later = defaultdict(list)
    later_paths = 0
    for key, operands, live in group_factors(target, cy, hy, work, admission,
                                              lambda: len(d) + later_paths):
        for ym, yk, _, yv in r10.stream_rows(operands, target, work):
            if ym & center:
                continue
            if later_paths + 1 > r10.LATER_CAP:
                raise RuntimeError(f"quartic later cap: prospective {later_paths + 1}")
            admission.check(len(d) + live + later_paths + 1)
            work.charge("quartic_later_rows")
            later[ym, yk].append((key, yv))
            later_paths += 1
        del operands
    wanted = defaultdict(dict)
    records = 0
    for xkey, operands, live in group_factors(
            target, cx, hx, work, admission,
            lambda: len(d) + later_paths + records + len(wanted)):
        for xm, _, left, xv in r10.stream_rows((*operands, d), target, work):
            if xm & center:
                continue
            for ym, yk in later:
                work.charge("quartic_outer_tests")
                if xm & ym:
                    continue
                qm = mask ^ (xm | ym)
                qk = r5.subtract(left, yk)
                if qk is None or (qm & center) != center or qm.bit_count() != 16:
                    continue
                if qk.count(r10.G2) != 4 or len(qk) != 28:
                    continue
                pair = qm, qk
                grouped = wanted.get(pair)
                for ykey, yv in later[ym, yk]:
                    work.charge("quartic_outer_signed_updates")
                    g = xkey, ykey
                    if grouped is None or g not in grouped:
                        prospective = (len(d) + live + later_paths + records + 1
                                       + len(wanted) + int(grouped is None))
                        admission.check(prospective)
                        records += 1
                        grouped = wanted[pair]
                    value = xv * yv * r5.mask_sign(xm, qm) * r5.mask_sign(xm | qm, ym)
                    prev = grouped.get(g)
                    grouped[g] = (value, 1) if prev is None else (prev[0] + value, prev[1] + 1)
        del operands
    return wanted, records, later_paths

def production_vertices(target, inputs, wanted, work, admission, fixed):
    _, _, cw, choices, _, _, _ = inputs
    w = {}
    projected = 0
    for key, poly in cw.items():
        rows = projection(poly, target, work, admission, fixed + projected)
        w[key] = rows
        projected += len(rows)
    vertices = {}
    for key, (components, poly) in choices.items():
        work.charge("quartic_production_branches")
        if key[0] != 2 or not all(w[c] for c in components):
            continue
        trace = projection(poly, target, work, admission, fixed + projected + len(vertices))
        for vm, vk, _, vv in r10.stream_rows((*[w[c] for c in components], trace), target, work):
            for qm, qk in wanted:
                work.charge("quartic_vertex_projection")
                if vm & qm == vm and r5.subtract(qk, vk) is not None:
                    add_term(vertices, (vm, vk), vv, 1, admission, fixed + projected + len(trace))
                    break
        del trace
    return vertices

def raw_vertices(target, inputs, raw, work, admission, fixed):
    """Expand all original S2 orientations, including the canceled groups."""
    mask, symbols, _ = target
    from collections import Counter
    counts = Counter(symbols)
    _, _, cw, _, _, _, _ = inputs
    def restrict(poly):
        return r5.subset_factor(poly, mask, counts, work)
    w = {}
    projections = 0
    for key, poly in cw.items():
        admission.check(fixed + projections + r5.count(poly))
        projected = restrict(poly)
        projections += r5.count(projected)
        w[key] = projected
    rows = {}
    input_ids = {id(poly) for poly in w.values()}
    def reserve_oracle(prospective):
        if prospective > work.oracle_record_cap:
            raise RuntimeError(f"quartic oracle cap: prospective {prospective}, cap {work.oracle_record_cap}")
        work.oracle_max_prospective_records = max(work.oracle_max_prospective_records, prospective)
    def multiply(a, b):
        # Both limits apply to these live rows. The oracle limit also
        # includes bounded temporary canonical output and its projection.
        left, right = r5.count(a), r5.count(b)
        separate = {id(poly): poly for poly in (a, b) if id(poly) not in input_ids}
        retained = fixed + projections + len(rows) + sum(map(r5.count, separate.values()))
        pairs = left * right
        prospective = retained + 2 * pairs
        reserve_oracle(prospective)
        admission.check(retained + pairs)
        work.charge("oracle_pair_admission", pairs)
        return restrict(a * b)
    for raw_key, terms in raw.items():
        if raw_key[0] != 2:
            continue
        for term in terms:
            work.charge("quartic_raw_orientations")
            (_, mu, a), (_, nu, b) = term.components
            if not (w[mu, a] and w[nu, b]):
                continue
            partial = multiply(w[mu, a], w[nu, b])
            trace_rows = len(term.coefficient.terms)
            retained = fixed + projections + len(rows) + r5.count(partial)
            reserve_oracle(retained + 2 * trace_rows)
            admission.check(retained + trace_rows)
            raw_trace = E(((0, term.coefficient * P.variable(r10.G2)),))
            trace = restrict(raw_trace)
            del raw_trace
            intermediate = r5.count(partial) + r5.count(trace)
            admission.check(fixed + projections + len(rows) + intermediate)
            product = multiply(partial, trace)
            intermediate += r5.count(product)
            for vm, polys in product.terms:
                for vk, vv in polys.terms:
                    work.charge("quartic_raw_signed_updates")
                    add_term(rows, (vm, vk), vv, 1, admission,
                             fixed + projections + intermediate)
            del product, partial, trace
    return rows

def json_identity(value):
    return json.loads(json.dumps(value))

class IndexedRows:
    """Random access in r4.rows order with no retained flattened rows."""

    __slots__ = ("terms", "size", "work")

    def __init__(self, poly, work):
        self.terms = poly.terms
        self.work = work
        self.size = 0
        for _, coefficients in self.terms:
            work.charge("quartic_seed_count_blocks")
            self.size += len(coefficients.terms)

    def __len__(self):
        return self.size

    def __getitem__(self, index):
        if not 0 <= index < self.size:
            raise IndexError(index)
        for mask, coefficients in self.terms:
            self.work.charge("quartic_seed_lookup_blocks")
            size = len(coefficients.terms)
            if index < size:
                self.work.charge("quartic_seed_read_rows")
                key, value = coefficients.terms[index]
                return (mask, key, ()), value
            index -= size
        raise AssertionError("immutable exterior row count changed")

def indexed_seed(powers, cx, hx, cw, choices, d, cy, hy, rng, work, seen):
    """R10 seed schedule with the same flat draws against immutable source rows."""
    a, b = powers
    def around(coframes, traces, key):
        _, _, mu, nu, i, j = key
        return coframes[mu, i], coframes[nu, j], traces[key]
    groups = {degree: tuple(key for key in choices if key[0] == degree) for degree in (2, 4)}
    xx, yy = tuple(hx), tuple(hy)
    for attempt in range(1, 2049):
        work.charge("quartic_seed_attempts")
        wkeys = tuple(sorted(rng.choices(groups[2], k=a) + rng.choices(groups[4], k=b)))
        xkey, ykey = rng.choice(xx), rng.choice(yy)
        w_factors = tuple(
            factor
            for key in wkeys
            for factor in (*(cw[component] for component in choices[key][0]), choices[key][1])
        )
        operands = (*w_factors, d, *around(cx, hx, xkey), *around(cy, hy, ykey))
        mask = 0
        symbols = []
        for poly in operands:
            flat = IndexedRows(poly, work)
            for _ in range(16):
                work.charge("seed_draws")
                (m, key, _), _ = rng.choice(flat)
                if not m & mask:
                    mask |= m
                    symbols.extend(key)
                    break
            else:
                del flat
                break
            del flat
        else:
            core = mask, tuple(sorted(symbols))
            if core not in seen:
                yield core, (xkey, wkeys, ykey), attempt

def seeded_targets(inputs, d0, d1, work, rejected, witness_cap=r10.LOCAL_CAP):
    """Restore the accepted R10 prefix, then retry distinct actual seeds."""
    cx, hx, cw, choices, _, cy, hy = inputs
    rng = random.Random(20261107)
    seen = set()
    frozen = (HERE / "publication-task4-continuation-powers-r10.progress.jsonl").read_bytes()
    assert sha256(frozen).hexdigest() == PREFIX_DIGEST
    rows = [json.loads(line) for line in frozen.splitlines()]
    assert len(rows) == 24 and sum(row["output_peak"] for row in rows) == PREFIX_RECORDS
    for row in rows:
        wanted = r6.decoded(row["target"])
        powers = tuple(row["powers"])
        slot = tuple(row["slot"])
        direction = row["direction"]
        assert wanted[2] == slot
        d = d1 if direction else d0
        for core, seeded, attempt in indexed_seed(powers, cx, hx, cw, choices, d, cy, hy, rng, work, seen):
            if core == wanted[:2]:
                assert attempt == row["attempt"]
                assert json_identity(seeded) == row["seeded"]
                assert json_identity(r5.fingerprint((*core, slot))) == row["target"]
                seen.add(core)
                break
        else:
            raise AssertionError(f"frozen R10 seed could not be reconstructed: {row['target']}")
    del rows, frozen, row
    for slot, direction, d in ((SLOTS[0], 0, d0), (SLOTS[1], 0, d0), (SLOTS[1], 1, d1)):
        candidates = indexed_seed(POWER, cx, hx, cw, choices, d, cy, hy, rng, work, seen)
        for _ in range(WITNESS_CANDIDATE_CAP):
            candidate = next(candidates, None)
            if candidate is None:
                raise RuntimeError(f"no disjoint quartic seed for {slot}, direction {direction}")
            core, seed, attempt = candidate
            seen.add(core)
            target = (*core, slot)
            value, paths, peak = witness(target, seed, inputs, work, witness_cap)
            if value:
                assert paths
                yield target, direction, seed, attempt, value, paths, peak
                break
            rejected(dict(target=r5.fingerprint(target), direction=direction, seed=seed,
                          attempt=attempt, zero_witness=str(value), witness_paths=paths,
                          witness_peak=peak, work=work.used))
        else:
            raise RuntimeError(f"quartic witness candidate cap {WITNESS_CANDIDATE_CAP} for {slot}, direction {direction}")


def witness(target, seed, inputs, work, cap):
    from collections import Counter
    from math import factorial, prod
    cx, hx, cw, choices, contacts, cy, hy = inputs
    xkey, wkeys, ykey = seed
    mask, symbols, slot = target
    admission = Admission(cap)
    fixed = 0
    def retain(poly):
        nonlocal fixed
        rows = projection(poly, target, work, admission, fixed)
        fixed += len(rows)
        return rows
    def outer(key, coframes, traces):
        _, _, mu, nu, a, b = key
        return retain(coframes[mu, a]), retain(coframes[nu, b]), retain(traces[key])
    xs = outer(xkey, cx, hx)
    ys = outer(ykey, cy, hy)
    if not all((*xs, *ys)):
        return ZERO, 0, admission.peak
    w = {}
    traces = {}
    factors = []
    for key in wkeys:
        components, trace = choices[key]
        if key not in traces:
            traces[key] = retain(trace)
        for component in components:
            if component not in w:
                w[component] = retain(cw[component])
            factors.append(w[component])
        factors.append(traces[key])
    contact = retain(contacts[slot])
    later = {}
    later_paths = 0
    for ym, yk, _, yv in r10.stream_rows(ys, target, work):
        work.charge("quartic_witness_later_updates")
        later_paths += 1
        if later_paths > r10.LATER_CAP:
            raise RuntimeError(f"quartic witness later cap: prospective {later_paths}")
        add_term(later, (ym, yk), yv, 1, admission, fixed)
    weight = Fraction(1, prod(factorial(n) for n in Counter(wkeys).values()))
    value, paths = ZERO, 0
    for xm, _, remaining, xv in r10.stream_rows((*xs, *factors, contact), target, work):
        ym = mask ^ xm
        yv, n = later.get((ym, remaining), (ZERO, 0))
        if n:
            work.charge("quartic_seed_matches")
            value += xv * yv * r5.mask_sign(xm, ym) * weight
            paths += n
    return value, paths, admission.peak


def validate_target(target, direction, seed, attempt, seeded_value, seeded_paths, witness_peak,
                    center, inputs, raw, work, remaining):
    admission = Admission(r10.LOCAL_CAP)
    wanted, outer_records, later_paths = exterior_residuals(target, inputs, center, work, admission)
    fixed = len(wanted) + outer_records
    # Keep one copy of each retained artifact. Feed the pair constructor
    # the reserved budget for the other live outer records.
    local_budget = Admission(r10.LOCAL_CAP - outer_records)
    vertices = production_vertices(target, inputs, wanted, work, admission, fixed)
    local = partitioned_quartic(vertices, wanted, center, work, local_budget)
    del vertices
    local_peak = max(admission.peak, outer_records + local_budget.peak)
    direct_budget = Admission(r10.LOCAL_CAP - outer_records - len(local))
    direct = raw_vertices(target, inputs, raw, work, direct_budget, len(wanted))
    reference = direct_coefficients(direct, wanted, center, work, direct_budget)
    del direct
    for key in wanted:
        assert local.get(key, (ZERO, 0))[0] == reference[key], key
    output = r10.SignedOutput(remaining)
    for key in wanted:
        value, paths = local.get(key, (ZERO, 0))
        if paths:
            for group, (outer, n) in wanted[key].items():
                work.charge("quartic_final_signed_updates")
                prospective = int(group not in output.table)
                admission.check(outer_records + len(wanted) + len(local) + len(reference)
                                + len(output.table) + prospective)
                output.put(group, value * outer, paths * n)
    selected = output.table.get((seed[0], seed[2]), (ZERO, 0))
    quartic_local_keys = len(wanted)
    combined_direct_peak = outer_records + len(local) + direct_budget.peak
    del wanted, local, reference
    admission.check(3 * len(output.table))
    work.charge("quartic_receipt_rows", len(output.table))
    return {
        "target": r5.fingerprint(target), "direction": direction, "attempt": attempt,
        "seed": seed, "seeded_xy_sum": str(selected[0]), "seeded_xy_paths": selected[1],
        "seeded_coefficient": str(seeded_value), "seeded_paths": seeded_paths,
        "coefficients": [(k, str(v), n) for k, (v, n) in sorted(output.table.items())],
        "total": str(sum((v for v, _ in output.table.values()), ZERO)),
        "quartic_local_keys": quartic_local_keys, "later_paths": later_paths,
        "local_peak": max(local_peak, combined_direct_peak,
                          admission.peak, witness_peak),
        "output_records": len(output.table),
    }

def run_original():
    work = r5.Work(cap=r10.WORK_CAP, oracle_record_cap=r10.PAIR_CAP)
    reg, (_, _, w), inputs, raw, d0, d1 = r10.setup(work)
    center = 255 << (8 * reg.site_number(w))
    output = HERE / "publication-task4-continuation-quartic-r13.original.jsonl"
    used = PREFIX_RECORDS
    def log_rejection(row):
        print(json.dumps(row), file=sys.stderr, flush=True)
    with output.open("x") as receipt:
        for target, direction, seeded, attempt, value, paths, peak in seeded_targets(
                inputs, d0, d1, work, log_rejection):
            print(json.dumps(dict(target=r5.fingerprint(target), direction=direction,
                                  seed=seeded, attempt=attempt)), file=sys.stderr, flush=True)
            row = validate_target(target, direction, seeded, attempt, value, paths, peak,
                                  center, inputs, raw, work, r10.OUTPUT_CAP - used)
            used += row["output_records"]
            print(json.dumps(row), file=receipt, flush=True)
            del row
        print(json.dumps(dict(work=dict(work.counts), work_total=work.used,
                              oracle_peak=work.oracle_max_prospective_records,
                              prefix_output_records=PREFIX_RECORDS,
                              quartic_output_records=used - PREFIX_RECORDS,
                              cumulative_output_records=used)),
              file=receipt, flush=True)

if __name__ == "__main__":
    if sys.argv[1:] != ["--root-admitted-original"]:
        raise SystemExit("Original replay requires ROOT admission and explicit mode")
    run_original()
