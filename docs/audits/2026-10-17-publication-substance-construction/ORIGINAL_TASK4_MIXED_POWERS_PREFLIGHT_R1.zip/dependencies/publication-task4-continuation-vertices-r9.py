"""Exact target coefficients of either complete original continuation vertex."""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path
import importlib.util
import json
import random
import resource
import sys

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("r8_vertices", HERE / "publication-task4-continuation-roster-r8.py")
r8 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r8
spec.loader.exec_module(r8)
r7, r6, r5, r4 = r8.r7, r8.r6, r8.r5, r8.r4
Q, P, E, S, SLOTS = r8.Q, r8.P, r8.E, r8.S, r8.SLOTS
G1, G2 = S("g1", ()), r7.G2
PAIR_CAP = 16384
WORK_CAP = 30_000_000
OUTPUT_CAP = 2048
QUERY_PROJECTION_CAP = 45_000


def branch_key(raw):
    components = tuple(sorted(raw.components))
    if raw.t_degree == 4:
        return (4, *(a for _, _, a in components))
    (_, mu, a), (_, nu, b) = components
    k, l = (axis for axis in range(4) if axis not in (mu, nu))
    return (2, k, l, mu, nu, a, b)


def source_roster(reg, w, work):
    anchors = {(w, axis) for axis in range(4)} | {
        (reg.step(w, axis)[0], other) for axis, other in product(range(4), repeat=2)
        if axis != other
    }
    links = {}
    for anchor in sorted(anchors):
        work.charge("continuation_link_constructions")
        links[anchor] = r4.f.original_spin4_link(*(
            tuple(P.variable(S("q", (*anchor, hand, j))) for j in range(4))
            for hand in ("L", "R")
        ))
    raw = defaultdict(list)
    for term in r4.f.original_action_factors(reg, w, links):
        work.charge("continuation_original_action_terms")
        raw[branch_key(term)].append(term)
    assert Counter((key[0], len(items)) for key, items in raw.items()) == {(2, 4): 96, (4, 1): 24}
    continuation, grouped_trace, diagonal = r7.roster(reg, w, work)
    choices = {}
    for key, terms in sorted(raw.items()):
        if key[0] == 2:
            _, k, l, mu, nu, a, b = key
            summed = sum((term.coefficient for term in terms), P())
            if key[1:] in diagonal:
                assert not summed and all(term.coefficient for term in terms)
                continue
            h = grouped_trace[key[1:]]
            assert h == E(((0, summed * P.variable(G2)),))
            choices[key] = ((mu, a), (nu, b)), h
        else:
            components = tuple(enumerate(key[1:]))
            assert terms[0].coefficient == P.scalar(r4.o.epsilon(key[1:]))
            choices[key] = components, E(((0, terms[0].coefficient * P.variable(G1)),))
    assert Counter(k[0] for k in choices) == {2: 72, 4: 24}
    return continuation, raw, choices, diagonal


def project(e, target, work):
    return r7.projection(e, target, work)


def signed(target, degree, cx, hx, cw, choices, contacts, arena, cy_handles, hy_handles, work):
    mask, symbols, slot = target
    x = {key: project(e, target, work) for key, e in cx.items()}
    h = {key: project(e, target, work) for key, e in hx.items()}
    w = {key: project(e, target, work) for key, e in cw.items()}
    wh = {key: project(e, target, work) for key, (_, e) in choices.items() if key[0] == degree}
    d = project(contacts[slot], target, work)
    projected = sum(map(len, (*x.values(), *h.values(), *w.values(), *wh.values(), d)))
    assert projected <= QUERY_PROJECTION_CAP
    output = {}
    for xkey, trace in h.items():
        _, _, mu, nu, a, b = xkey
        if not all((x[mu,a], x[nu,b], trace, d)):
            continue
        for wkey, wh_trace in wh.items():
            work.charge("continuation_group_candidates")
            world = tuple(w[c] for c in choices[wkey][0])
            if not wh_trace or not all(world):
                continue
            operands = (x[mu,a], x[nu,b], trace, *world, wh_trace, d)

            def scan(_, emit):
                def descend(index, occupied, used, residual, value):
                    if index == len(operands):
                        work.charge("streamed_prefix_paths")
                        emit((occupied, used, slot), value)
                        return
                    for m, key, q in operands[index]:
                        work.charge("streamed_operand_tests")
                        if m & occupied:
                            continue
                        leftover = r5.subtract(residual, key)
                        if leftover is not None:
                            descend(index+1, occupied | m, tuple(sorted(used+key)),
                                    leftover, value*q*r5.mask_sign(occupied,m))
                descend(0, 0, (), symbols, Q(1))

            class View:
                get = staticmethod(arena.get)

            View.scan = staticmethod(scan)
            group, _, _, paths, _ = r5.fiber(View(), None, cy_handles, hy_handles, target, work)
            if paths:
                if len(output) + len(group) > OUTPUT_CAP:
                    raise RuntimeError("signed result record cap")
                output[xkey,wkey] = group, paths
    assert sum(len(group) for group, _ in output.values()) <= OUTPUT_CAP
    return output, projected


def direct(target, degree, cx, hx, cw, raw, contacts, cy, hy, work):
    """Canonical polynomial products, with independent raw ordered terms at w."""
    mask, symbols, slot = target
    counts = Counter(symbols)
    def restrict(e):
        return r5.subset_factor(e, mask, counts, work)

    def product_at_key(operands, *retained):
        acc = E(((0, P.scalar(1)),))
        for i, e in enumerate(operands):
            acc = restrict(work.oracle_product(acc, e, *operands[i+1:], *retained))
            if not acc:
                break
        return acc

    xc, xh, wc, yc, yh = ({key: restrict(e) for key,e in table.items()}
                          for table in (cx,hx,cw,cy,hy))
    d = restrict(contacts[slot])
    if not d:
        return {}
    later = {}
    for key, trace in yh.items():
        _, _, mu, nu, a, b = key
        if all((yc[mu,a],yc[nu,b],trace)):
            candidate = product_at_key((yc[mu,a],yc[nu,b],trace), *later.values())
            if candidate:
                later[key] = candidate

    # Project each canonical raw term with its original, unsorted component
    # order. Grouping for output is only a label, not a source simplification.
    w_products = {}
    coupling = G2 if degree==2 else G1
    for key, terms in raw.items():
        if key[0] != degree:
            continue
        subtotal = E()
        for term in terms:
            work.charge("oracle_raw_continuation_terms")
            factors = tuple(wc[mu,a] for _,mu,a in term.components)
            if not all(factors):
                continue
            h = restrict(E(((0, term.coefficient*P.variable(coupling)),)))
            if not h:
                continue
            q = product_at_key((*factors,h), subtotal,*later.values(),*w_products.values())
            if r5.count(q)+r5.count(subtotal)+sum(map(r5.count,w_products.values())) > PAIR_CAP:
                raise RuntimeError("oracle continuation cache cap")
            subtotal += q
        if subtotal:
            w_products[key] = subtotal

    out = {}
    for key, trace in xh.items():
        _, _, mu, nu, a, b = key
        if not all((xc[mu,a], xc[nu,b], trace)):
            continue
        for wkey, wv in w_products.items():
            v = product_at_key((xc[mu,a], xc[nu,b], trace, wv, d), *later.values(),*w_products.values())
            if not v:
                continue
            coefficients = {}
            for ykey,yv in later.items():
                result = r8.coefficient(work.oracle_product(v,yv,*later.values(),*w_products.values()), mask,symbols)
                if result:
                    coefficients[ykey] = result
            if coefficients:
                out[key,wkey] = coefficients
    return out


def r8_control(cx,hx,cw,contacts,cy,hy,arena,cy_handles,hy_handles,work):
    prior=json.loads((HERE/"publication-task4-continuation-roster-r8.json").read_text())
    for row in prior["results"]:
        target=r6.decoded(row["target"])
        got,_=r8.signed_stream(target,cx,hx,cw,contacts,arena,cy_handles,hy_handles,work)
        paths=[(comp, [(branch,n,r8.group_rows(group))
                      for branch,(group,n) in sorted(by_branch.items())])
               for comp,by_branch in sorted(got.items())]
        assert json.loads(json.dumps(paths))==row["paths"]
    return len(prior["results"])


def main():
    reg=r4.o.OriginalRegulator()
    x=reg.sites[0]
    y,w=reg.step(x,0)[0],reg.step(x,2)[0]
    work=r5.Work(cap=WORK_CAP,oracle_record_cap=PAIR_CAP)
    cx,hx,x_diagonal=r7.roster(reg,x,work)
    cy,hy,y_diagonal=r7.roster(reg,y,work)
    cw,raw,choices,w_diagonal=source_roster(reg,w,work)
    j=P.variable(S("J",(y,0,0)))
    d0,d1=cy[0,0]*j,cy[1,0]*j
    contacts={SLOTS[0]:d0,SLOTS[1]:d0+d1}
    arena=r4.Arena(r4.Caps(100_000,65_536))
    cy_handles={k:arena.ingest(r4.rows(e)) for k,e in cy.items()}
    hy_handles={k:arena.ingest(r4.rows(e)) for k,e in hy.items()}
    old_count=r8_control(cx,hx,cw,contacts,cy,hy,arena,cy_handles,hy_handles,work)
    rng=random.Random(771913)
    slots=((SLOTS[0],d0,0),(SLOTS[1],d0,0),(SLOTS[1],d1,1))
    xkeys=tuple(k for k in hx if k[-2:]==(0,1))
    ykeys=tuple(k for k in hy if k[-2:]==(0,1))
    wkeys={2:tuple(k for k in choices if k[0]==2 and k[-2:]==(0,1)),
           4:tuple(k for k in choices if k[0]==4)[::6]}
    roster={id(e):tuple(r4.rows(e)) for e in (*cx.values(),*hx.values(),*cw.values(),
                     *(e for _,e in choices.values()),d0,d1,*cy.values(),*hy.values())}
    assert sum(map(len,roster.values())) <= 35_000
    rows=[]
    found=set()

    def stream(target,degree):
        return signed(target,degree,cx,hx,cw,choices,contacts,arena,cy_handles,hy_handles,work)

    def verify(target, degree, got):
        direct_rows=direct(target,degree,cx,hx,cw,raw,contacts,cy,hy,work)
        assert {key: nonzero for key,(gs,_) in got.items()
                if (nonzero:=r7.nonzero(gs))}==direct_rows
        combined=defaultdict(lambda: Q(0))
        by_continuation=defaultdict(lambda: Q(0))
        for (_,wk),(gs,_) in got.items():
            for yk,q in gs.items():
                combined[yk]+=q
                by_continuation[wk]+=q
        total=sum(combined.values(),Q(0))
        return dict(groups=[(k,r8.group_rows(gs),n) for k,(gs,n) in sorted(got.items())],
                    later=r8.group_rows(combined),total=str(total),
                    continuation=r8.group_rows(by_continuation))

    for degree in (2,4):
        for slot,d,direction in slots:
            for i,wk in enumerate(wkeys[degree]):
                wcomponents,wh=choices[wk]
                for attempt in range(256):
                    xk=xkeys[(i+attempt)%len(xkeys)]
                    yk=ykeys[(2*i+attempt+1)%len(ykeys)]
                    _,_,xm,xn,xa,xb=xk
                    _,_,ym,yn,ya,yb=yk
                    factors=(cx[xm,xa],cx[xn,xb],hx[xk],*(cw[c] for c in wcomponents),
                             wh,d,cy[ym,ya],cy[yn,yb],hy[yk])
                    work.charge("seed_factor_draws",len(factors))
                    occupied,symbols=0,()
                    for factor in factors:
                        (m,key,_),_=rng.choice(roster[id(factor)])
                        if m & occupied:
                            break
                        occupied|=m
                        symbols+=key
                    else:
                        target=occupied,tuple(sorted(symbols)),slot
                        if target in found:
                            continue
                        got,projected=stream(target,degree)
                        branch=got.get((xk,wk),({},0))[0]
                        if not branch.get(yk):
                            continue
                        result=verify(target,degree,got)
                        result.update(target=r5.fingerprint(target),degree=degree,contact_direction=direction,
                                      seeded=(xk,wk,yk),attempt=attempt+1,projected=projected)
                        rows.append(result)
                        found.add(target)
                        break
                else:
                    raise AssertionError(f"no positive signed target for {degree} {slot} {direction} {wk}")
    controls=[]
    for degree in (2,4):
        base=next(row for row in rows if row["degree"]==degree and tuple(row["target"]["slot"])==SLOTS[0])
        mask,symbols,_=r6.decoded(base["target"])
        mixed=(mask,symbols,SLOTS[1])
        got,_=stream(mixed,degree)
        result=verify(mixed,degree,got)
        assert result["groups"]==base["groups"] and result["total"]==base["total"]
        controls.append(("exact_literal_summand_of_mixed",degree,r5.fingerprint(mixed),result["total"]))
        wrong_j=S("J",(reg.step(y,1)[0],0,0))
        wrong_g=G1 if degree==2 else G2
        actual_g=G2 if degree==2 else G1
        for label,target in (
            ("wrong_J",(mask,tuple(sorted(wrong_j if s.family=="J" else s for s in symbols)),SLOTS[1])),
            ("wrong_coupling",(mask,tuple(sorted((*list(symbols)[:list(symbols).index(actual_g)],
                                                *list(symbols)[list(symbols).index(actual_g)+1:],wrong_g))),SLOTS[0])),
        ):
            zero,_=stream(target,degree)
            assert not zero and not direct(target,degree,cx,hx,cw,raw,contacts,cy,hy,work)
            controls.append((label,degree,r5.fingerprint(target),"0"))
    dry=r5.Work(cap=0)
    try:
        signed(r6.decoded(rows[0]["target"]),2,cx,hx,cw,choices,contacts,arena,cy_handles,hy_handles,dry)
    except RuntimeError as exc:
        assert dry.used==0 and "work cap at 0" in str(exc)
        controls.append(("zero_work_refusal",str(exc)))
    else:
        raise AssertionError("zero work returned a result")
    print(json.dumps(dict(
        regulator=dict(extents=reg.extents,word=reg.word,convention=reg.convention),
        centers=(x,y,w),raw_counts=dict(S2=384,S4=24),group_counts=dict(S2=72,S4=24),
        diagonal=[x_diagonal,y_diagonal,w_diagonal],r8_controls=old_count,
        choice_roster=[(key,components,r5.count(trace)) for key,(components,trace) in choices.items()],
        targets=rows, controls=controls, seed_rows=sum(map(len,roster.values())),
        work=dict(work.counts),work_total=work.used,work_cap=work.cap,
        projection_cap=QUERY_PROJECTION_CAP,output_cap=OUTPUT_CAP,
        oracle_pair_peak=work.oracle_max_prospective_records,oracle_record_cap=PAIR_CAP,
        arena=arena.metric(),native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    ),indent=2))


if __name__=="__main__":
    main()
