"""R6 bounded full predecessor target-key convolution; scratch only."""
from collections import Counter
import importlib.util
import json
from pathlib import Path
import resource
import sys

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location(
    "r5_predecessor", HERE/"publication-task4-all-residual-reaggregation-r5.py")
r5 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r5
spec.loader.exec_module(r5)
r4 = r5.r4
Q, P, E, S = r5.Q, r5.P, r5.E, r5.S
G2, SLOTS = r5.G2, r5.SLOTS


def source(reg,arena):
    x = reg.sites[0]
    y = reg.step(x,0)[0]
    terms = r4.factors(reg)
    C,R = (terms[i]*terms[i+1] for i in (0,2))
    C = C*P.variable(G2)
    ca,cb,h,future = (arena.ingest(r4.rows(t)) for t in terms[:4])
    raw_c,_ = arena.join(ca,cb,arena.retained(ca,cb))
    arena.drop(ca)
    arena.drop(cb)
    ch = arena.new_map()
    arena.scan(raw_c,lambda key,value: arena.put(
        ch,(key[0],tuple(sorted((*key[1],G2))),key[2]),value))
    arena.drop(raw_c)
    rh,_ = arena.join(h,future,arena.retained(h,future))
    arena.drop(h)
    arena.drop(future)
    r4.assert_exact(arena,ch,dict(r4.rows(C)))
    r4.assert_exact(arena,rh,dict(r4.rows(R)))
    assert (arena.count(ch),arena.count(rh)) == (3584,8192)
    old_c = arena.new_map()
    old_r = arena.new_map()
    ybit = 1 << (8*reg.site_number(y))
    axes = tuple(tuple(sorted((S('q',(x,0,'L',i)),S('q',(x,1,'L',0)),G2))) for i in (1,2))

    def select_c(key,v):
        if key[0] & (255*ybit) == ybit and key[1] in axes:
            arena.put(old_c,key,v)

    def select_r(key,v):
        k = key[1]
        if not arena.count(old_r) and any(k.count(s)==2 and s.index[:2]==(x,2) for s in set(k)):
            arena.put(old_r,key,v)

    arena.scan(ch,select_c)
    arena.scan(rh,select_r)
    assert (arena.count(old_c),arena.count(old_r)) == (6,1)
    b0,b1 = (r4.exterior(reg,(y,axis,0)) for axis in (0,1))
    j = P.variable(S('J',(y,0,0)))
    D = {SLOTS[0]:b0*j,SLOTS[1]:(b0+b1)*j}
    dh = {slot:arena.ingest(r4.rows(e)) for slot,e in D.items()}
    assert tuple(arena.count(dh[s]) for s in SLOTS)==(64,128)
    return ch,rh,dh,old_c,old_r,C,R,D


def subset(arena,h,target,work,name):
    m,s,_ = target
    rows=[]
    def take(key,value):
        work.charge(name)
        if key[0] & m == key[0] and r5.subtract(s,key[1]) is not None:
            rows.append((key,value))
    arena.scan(h,take)
    return rows


class PredecessorStream:
    """Expose only signed rows admitted by one complete target, without a K map."""
    def __init__(self,arena,ch,rh,dh,old_c,old_r,target,mixed_anchors,work):
        self.arena = arena
        self.ch,self.rh,self.dh = ch,rh,dh
        self.old_c,self.old_r = old_c,old_r
        self.target,self.work = target,work
        self.mixed_anchors = mixed_anchors
        self.max_records = 0
        self.origins = Counter()
        self.admitted_predecessor_paths = 0
        self.projected_operands = {}

    def get(self,h,key):
        return self.arena.get(h,key)

    def scan(self,ignored,callback):
        M,X,slot = self.target
        w = self.work
        if slot not in self.dh:
            return
        C,R,D = (subset(self.arena,h,self.target,w,name)
                 for h,name in ((self.ch,'C_filter'),(self.rh,'R_filter'),(self.dh[slot],'D_filter')))
        self.projected_operands = dict(C=len(C),R=len(R),D=len(D))
        self.max_records = len(C)+len(R)+len(D)
        assert self.max_records <= 3584+8192+128
        for (cm,cs,_),cv in C:
            left = r5.subtract(X,cs)
            assert left is not None
            c_new = self.arena.get(self.old_c,(cm,cs,())) is None
            for (dm,ds,_),dv in D:
                w.charge('CD_pairs')
                if cm&dm:
                    continue
                left_cd = r5.subtract(left,ds)
                if left_cd is None:
                    continue
                mask_cd = cm|dm
                sign_cd = r5.mask_sign(cm,dm)
                extra = slot==(0,1) and any(s.family=='q' and s.index[:2] in self.mixed_anchors for s in ds)
                for (rm,rs,_),rv in R:
                    w.charge('CDR_pairs')
                    if mask_cd&rm or r5.subtract(left_cd,rs) is None:
                        continue
                    self.admitted_predecessor_paths += 1
                    r_new = self.arena.get(self.old_r,(rm,rs,())) is None
                    before = w.counts['nonzero_signed_paths']
                    mask = mask_cd|rm
                    symbols = tuple(sorted(cs+ds+rs))
                    coef = cv*dv*rv*(sign_cd*r5.mask_sign(mask_cd,rm))
                    callback((mask,symbols,slot),coef)
                    found = w.counts['nonzero_signed_paths']-before
                    if found:
                        self.origins[c_new,r_new,extra] += found


def direct(C,R,D,coframes,traces,key,work):
    """Independent forward polynomial oracle, with operand-level safe filtering."""
    m,s,slot = key
    if slot not in D:
        return {}
    counts = Counter(s)
    cp,dp,rp = (r5.subset_factor(e,m,counts,work) for e in (C,D[slot],R))
    cd = work.oracle_product(cp,dp,rp)
    del cp,dp
    cdr = work.oracle_product(cd,rp)
    del cd,rp
    K = r4.o.RawJet((0,1),(((),E()),(slot,cdr)))
    return r5.direct(K,coframes,traces,key,work)


def decoded(obj):
    return (int(obj['mask_hex'],16),
            tuple(S(family,index) for family,index in obj['symbols']),tuple(obj['slot']))


def read_r5_targets():
    receipt = json.loads((HERE/"publication-task4-all-residual-reaggregation-r5.json").read_text())
    return [(decoded(r['output_key']),r) for r in receipt['exact_common_output_keys']]


def make_new_targets(arena,C,R,D,old_c,old_r,coframes,traces,anchors,work):
    # Build the full bounded W once. Its discovery role does not select
    # any group for evaluation, which always queries all 72 groups.
    tag = (0,3,1,2,0,1)
    _,_,mu,nu,a,b = tag
    a_h,b_h = coframes[mu,a],coframes[nu,b]
    W,_ = arena.join(a_h,b_h,arena.retained(a_h,b_h),complement=True)
    H = traces[tag]
    class FirstFound(Exception):
        pass

    def first_key(h):
        found = []
        def take(key,_):
            found.append(key)
            raise FirstFound
        try:
            arena.scan(h,take)
        except FirstFound:
            pass
        return found[0]

    wm,ws,_ = first_key(W)
    hm,hs,_ = first_key(H)
    assert not hm
    arena.drop(W)
    out={}
    # The upper sampling admission is 50,000 C/R/contact tests.
    # Scan source maps without keeping a new copy of their rows.
    cap = 50_000
    start = sum(work.counts[x] for x in ('sample_C','sample_R','sample_D'))
    class Complete(Exception):
        pass

    def charge(name):
        if sum(work.counts[x] for x in ('sample_C','sample_R','sample_D'))-start == cap:
            raise RuntimeError("new-target discovery cap reached")
        work.charge(name)

    for slot,h in D.items():
        generated = set()

        def take_c(c,_):
            charge('sample_C')
            cm,cs,_ = c
            if cm&wm or arena.get(old_c,c) is not None:
                return

            def take_r(r,_):
                charge('sample_R')
                rm,rs,_ = r
                occupied = cm|wm
                if rm&occupied or arena.get(old_r,r) is not None:
                    return
                occupied |= rm

                def take_d(d,_):
                    charge('sample_D')
                    dm,ds,_ = d
                    if dm&occupied:
                        return
                    if slot==(0,1) and not any(s.family=='q' and s.index[:2] in anchors for s in ds):
                        return
                    key = (occupied|dm,tuple(sorted(cs+ds+rs+ws+hs)),slot)
                    if key not in out:
                        out[key] = dict(C=r5.fingerprint(c),R=r5.fingerprint(r),D=r5.fingerprint(d))
                        generated.add(key)
                    if len(generated)==4:
                        raise Complete

                arena.scan(h,take_d)

            arena.scan(R,take_r)

        try:
            arena.scan(C,take_c)
        except Complete:
            pass
        assert len(generated)==4
    return out


def eager_probe(arena,a,b):
    before=arena.metric()
    try:
        out,stats=arena.join(a,b,arena.retained(a,b),complement=True)
    except r4.Refusal as exc:
        after=arena.metric()
        assert after['live_records']==before['live_records']
        assert after['live_maps']==before['live_maps'] and not after['live_indexes'] and not after['active_readers']
        return dict(refused=exc.kind,at_visits=exc.visits,prospective_records=exc.live,
                    before=before,after=after)
    else:
        count=arena.count(out)
        arena.drop(out)
        return dict(refused=None,records=count,join=stats,before=before,after=arena.metric())


def nonzero(group):
    return {g:v for g,v in group.items() if v}


def format_groups(group):
    return [(g,str(v)) for g,v in sorted(group.items())]


def evaluate(arena,C,R,D,old_c,old_r,coframes,traces,key,anchors,work):
    stream = PredecessorStream(arena,C,R,D,old_c,old_r,key,anchors,work)
    by_group,eligible,contributing,paths,_ = r5.fiber(stream,None,coframes,traces,key,work)
    return by_group,dict(
        projected_operands=stream.projected_operands,retained_projection_records=stream.max_records,
        admissible_predecessor_products=stream.admitted_predecessor_paths,
        predecessor_paths_eligible_for_later_groups=eligible,
        predecessor_paths_with_later_contributions=contributing,
        later_raw_signed_paths=paths,
        origins=[(*origin,n) for origin,n in sorted(stream.origins.items())])


def main():
    reg = r4.o.OriginalRegulator()
    y = reg.step(reg.sites[0],0)[0]
    mixed_anchors = ((y,1),(reg.step(y,1)[0],1))
    arena = r4.Arena(r4.Caps(1_000_000,65_536))
    work = r5.Work()
    ch,rh,dh,old_c,old_r,C,R,D = source(reg,arena)
    coframes,traces,src_cf,src_tr = r5.source_roster(reg,y,arena,work)
    initial = arena.metric()
    assert initial['live_records'] == 3584+8192+192+6+1+1024+9216
    obstruction = eager_probe(arena,ch,rh)
    targets = make_new_targets(arena,ch,rh,dh,old_c,old_r,coframes,traces,mixed_anchors,work)
    old_targets = read_r5_targets()
    results = []
    for key,old in [*old_targets,*targets.items()]:
        original_target = 'group_sums' in old
        full,info = evaluate(arena,ch,rh,dh,old_c,old_r,coframes,traces,key,mixed_anchors,work)
        full_direct = direct(C,R,D,src_cf,src_tr,key,work)
        assert nonzero(full) == full_direct
        restricted,old_info = evaluate(arena,old_c,old_r,dh,old_c,old_r,coframes,traces,key,mixed_anchors,work)
        if original_target:
            expected = {tuple(g):v for g,v in old['group_sums']}
            assert {g:str(v) for g,v in restricted.items() if v} == {
                g:v for g,v in expected.items() if v != str(Q(0))}
        else:
            assert any(c_new and r_new and (key[2]==(0,) or extra) and n>0
                       for c_new,r_new,extra,n in info['origins'])
        results.append(dict(output_key=r5.fingerprint(key),accepted_r5_target=original_target,
            full_group_sums=format_groups(full),direct_per_group_equal=True,
            full_total=str(sum(full.values(),Q(0))),
            full_total_zero=not sum(full.values(),Q(0)),full=info,
            restricted_group_sums=format_groups(restricted),restricted=old_info,
            full_differs_from_restriction=nonzero(full)!=nonzero(restricted),
            new_source_witness=None if original_target else old))
    assert any(row['full_differs_from_restriction'] for row in results)
    assert arena.metric()['live_records']==initial['live_records']
    print(json.dumps(dict(C_records=arena.count(ch),R_records=arena.count(rh),
        contact_records=[arena.count(dh[s]) for s in SLOTS],old_subset_records=[6,1],
        full_factor_arena=initial,full_eager_CR_probe=obstruction,
        final_arena=arena.metric(),target_results=results,
        work=dict(work.counts),work_total=work.used,work_cap=work.cap,
        oracle_record_cap=work.oracle_record_cap,
        oracle_max_prospective_records=work.oracle_max_prospective_records,
        original_later_groups=len(traces),all_alternatives=r4.ALTERNATIVES,
        native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_unit='bytes' if sys.platform=='darwin' else 'KiB'),indent=2))


if __name__=='__main__':
    main()
