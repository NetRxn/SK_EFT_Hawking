"""Exact fixed-center continuation component queries on the original N16 seam."""
from collections import Counter, defaultdict
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import importlib.util
import json
import random
import resource
import sys

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("r7_continuation", HERE / "publication-task4-predecessor-roster-r7.py")
r7 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r7
spec.loader.exec_module(r7)
r6, r5, r4 = r7.r6, r7.r5, r7.r4
Q, P, E, S, SLOTS = r7.Q, r7.P, r7.E, r7.S, r7.SLOTS
COMPONENTS = tuple(product(range(4), repeat=2))
PLANES = tuple(combinations(range(4), 2))
FIXED = (2, 0)
PROJECTION_CAP = 16 * 64 + 72 * 128 + 16 * 64 + 128


def continuation_source(reg, center, work):
    """Read the actual S2/S4 occurrence roster, without replacing its companions."""
    anchors = {(center, axis) for axis in range(4)}
    anchors.update((reg.step(center, axis)[0], other)
                   for axis, other in product(range(4), repeat=2) if axis != other)
    links = {
        anchor: r4.f.original_spin4_link(
            *(tuple(P.variable(S("q", (*anchor, hand, j))) for j in range(4))
              for hand in ("L", "R")))
        for anchor in sorted(anchors)
    }
    counts = Counter()
    for factor in r4.f.original_action_factors(reg, center, links):
        work.charge("continuation_raw_source_terms")
        for site, mu, a in factor.components:
            assert site == center
            counts[factor.t_degree, mu, a] += 1
    assert counts == {(degree, *key): n for degree, n in ((2, 48), (4, 6)) for key in COMPONENTS}
    coframes = {key: r4.exterior(reg, (center, *key)) for key in COMPONENTS}
    assert all(r5.count(e) == 64 for e in coframes.values())
    return coframes, counts


def signed_stream(target, x_coframes, x_traces, continuation, contact,
                  arena, yc, yh, work):
    """Project shared factors once and emit exact tables keyed by component and predecessor."""
    mask, symbols, slot = target
    c = {k: r7.projection(e, target, work) for k, e in x_coframes.items()}
    h = {k: r7.projection(e, target, work) for k, e in x_traces.items()}
    f = {k: r7.projection(e, target, work) for k, e in continuation.items()}
    d = r7.projection(contact[slot], target, work)
    projected = sum(map(len, (*c.values(), *h.values(), *f.values(), d)))
    assert projected <= PROJECTION_CAP
    result = {}
    for branch, trace in h.items():
        _, _, mu, nu, a, b = branch
        if not all((trace, c[mu, a], c[nu, b], d)):
            continue
        for component, future in f.items():
            work.charge("continuation_component_branch_tests")
            if not future:
                continue
            operands = (c[mu, a], c[nu, b], trace, future, d)

            def scan_predecessors(_, emit):
                def descend(index, occupied, used, residual, value):
                    if index == len(operands):
                        work.charge("completed_predecessor_paths")
                        emit((occupied, used, slot), value)
                        return
                    for m, key, coefficient in operands[index]:
                        work.charge("ordered_factor_candidates")
                        if occupied & m:
                            continue
                        remainder = r5.subtract(residual, key)
                        if remainder is not None:
                            descend(index + 1, occupied | m, tuple(sorted(used + key)),
                                    remainder, value * coefficient * r5.mask_sign(occupied, m))
                descend(0, 0, (), symbols, Q(1))

            class ReadView:
                get = staticmethod(arena.get)
                scan = staticmethod(scan_predecessors)

            group, _, _, paths, _ = r5.fiber(ReadView(), None, yc, yh, target, work)
            if paths:
                result.setdefault(component, {})[branch] = (group, paths)
    return result, projected


def coefficient(poly, mask, symbols):
    return next((c for m, p in poly.terms if m == mask
                 for key, c in p.terms if key == symbols), Q(0))


def forward(target, x_coframes, x_traces, continuation, contact, y_coframes,
            y_traces, work, weights=None):
    """Distinct Counter projection and canonical exterior products, with aggregate oracle."""
    mask, symbols, slot = target
    counts = Counter(symbols)

    def project(factors):
        return {k: r5.subset_factor(e, mask, counts, work) for k, e in factors.items()}

    c, h, f = map(project, (x_coframes, x_traces, continuation))
    d = r5.subset_factor(contact[slot], mask, counts, work)
    cy, hy = map(project, (y_coframes, y_traces))
    later = {}
    n = 0
    for k, trace in hy.items():
        _, _, mu, nu, a, b = k
        first, second = cy[mu, a], cy[nu, b]
        if first and second and trace:
            pair = work.oracle_product(first, second, trace)
            if n + r5.count(pair) * r5.count(trace) > work.oracle_record_cap:
                raise RuntimeError("projected later cache cap")
            later[k] = work.oracle_product(pair, trace)
            n += r5.count(later[k])

    def through(prefix):
        jet = r4.o.RawJet((0, 1), (((), E()), (slot, prefix)))
        return {k: q for k, e in later.items()
                if (q := coefficient(work.oracle_product(jet.at(slot), e), mask, symbols))}

    whole_prefix = E()
    result = {}
    if d:
        for component, continuation_part in f.items():
            weight = Q(1) if weights is None else weights.get(component, Q(0))
            if not continuation_part or not weight:
                continue
            continuation_part = continuation_part * weight
            by_branch = {}
            for branch, trace in h.items():
                _, _, mu, nu, a, b = branch
                first, second = c[mu, a], c[nu, b]
                if not all((first, second, trace)):
                    continue
                value = work.oracle_product(first, second, trace, continuation_part, d, whole_prefix)
                value = work.oracle_product(value, trace, continuation_part, d, whole_prefix)
                value = work.oracle_product(value, continuation_part, d, whole_prefix)
                value = work.oracle_product(value, d, whole_prefix)
                value = r5.subset_factor(value, mask, counts, work)
                if not value:
                    continue
                if r5.count(value) + r5.count(whole_prefix) > work.oracle_record_cap:
                    raise RuntimeError("summed forward prefix cap")
                whole_prefix += value
                if subtotal := through(value):
                    by_branch[branch] = subtotal
            if by_branch:
                result[component] = by_branch
    return result, through(whole_prefix)


def subtotal_map(rows):
    groups = defaultdict(lambda: Q(0))
    for group, _ in rows.values():
        for k, value in group.items():
            groups[k] += value
    return groups


def group_rows(groups):
    return [(key, str(value)) for key, value in sorted(groups.items())]


def anchors(e):
    return {s.index[:2] for (_, key, _), _ in r4.rows(e)
            for s in key if s.family == "q"}


def marker_check(reg, centers, x_traces, y_traces, x_coframes, y_coframes, continuation, contact):
    """Compute anchor unions from actual records, then recover unique plane markers."""
    x, y, w = centers
    for center, coframes in zip(centers, (x_coframes, y_coframes, continuation), strict=True):
        for (mu, _), factor in coframes.items():
            support = {(center, mu), (reg.step(center, mu, -1)[0], mu)}
            assert anchors(factor) == support
            assert all(len(key) == 1 and key[0].family == "q" and key[0].index[:2] in support
                       for (_, key, _), _ in r4.rows(factor))
    assert anchors(contact[SLOTS[0]]) == anchors(y_coframes[0, 0])
    assert anchors(contact[SLOTS[1]]) == anchors(y_coframes[0, 0]) | anchors(y_coframes[1, 0])
    expected = []
    for center, table in zip((x, y), (x_traces, y_traces), strict=True):
        plane_support = {}
        for key, factor in table.items():
            support = anchors(factor)
            k, l = key[:2]
            assert support == {(center, k), (reg.step(center, k)[0], l),
                               (reg.step(center, l)[0], k), (center, l)}
            assert len(support) == 4
            assert all(Counter(s.index[:2] for s in symbols if s.family == "q")
                       == Counter(support) for (_, symbols, _), _ in r4.rows(factor))
            assert plane_support.setdefault(key[:2], support) == support
        expected.append(plane_support)
    common = set().union(*(anchors(e) for e in (
        *x_coframes.values(), *y_coframes.values(), *continuation.values(), *contact.values())))
    markers = []
    for current, other in (expected, expected[::-1]):
        elsewhere = set().union(*other.values()) | common
        markers.append({
            k: v - elsewhere - set().union(*(a for p, a in current.items() if p != k))
            for k, v in current.items()
        })
    return markers


def main():
    reg = r4.o.OriginalRegulator()
    x = reg.sites[0]
    y, w = reg.step(x, 0)[0], reg.step(x, 2)[0]
    work = r5.Work(cap=24_000_000)
    cx, hx, x_diag = r7.roster(reg, x, work)
    cy, hy, y_diag = r7.roster(reg, y, work)
    continuation, occurrences = continuation_source(reg, w, work)
    assert continuation[FIXED] == r4.factors(reg)[3]
    j = P.variable(S("J", (y, 0, 0)))
    direction_1 = cy[1, 0] * j
    contact = {SLOTS[0]: cy[0, 0] * j, SLOTS[1]: cy[0, 0] * j + direction_1}
    assert tuple(map(r5.count, contact.values())) == (64, 128)
    arena = r4.Arena(r4.Caps(100_000, 65_536))
    yh = {k: arena.ingest(r4.rows(e)) for k, e in hy.items()}
    yc = {k: arena.ingest(r4.rows(e)) for k, e in cy.items()}
    markers = marker_check(reg, (x, y, w), hx, hy, cx, cy, continuation, contact)

    def streamed(target):
        return signed_stream(target, cx, hx, continuation, contact, arena, yc, yh, work)

    def oracle(target, weights=None):
        return forward(target, cx, hx, continuation, contact, cy, hy, work, weights)

    results = []
    seen = set()

    def check(target, prior=None, witness=None, prepared=None):
        stream, projected = streamed(target) if prepared is None else prepared
        direct, common = oracle(target)
        assert {
            component: usable
            for component, by_branch in stream.items()
            if (usable := {branch: r7.nonzero(group) for branch, (group, _) in by_branch.items()
                           if r7.nonzero(group)})
        } == direct
        if prior is not None:
            # Includes all zero group subtotals and all original path multiplicities.
            old = {tuple(branch): (paths, dict((tuple(k), q) for k, q in groups))
                   for branch, paths, groups in prior["branches"]}
            now = {branch: (paths, dict(group_rows(group)))
                   for branch, (group, paths) in stream.get(FIXED, {}).items()}
            assert old == now
            assert str(sum(subtotal_map(stream.get(FIXED, {})).values(), Q(0))) == prior["whole"]
        sums = {key: subtotal_map(by_branch) for key, by_branch in stream.items()}
        combined = defaultdict(lambda: Q(0))
        collisions = []
        for key in hy:
            active = [(comp, group[key]) for comp, group in sums.items() if group.get(key)]
            if not active:
                continue
            combined[key] = sum((q for _, q in active), Q(0))
            if len(active) >= 2:
                collisions.append((key, [(comp, str(q)) for comp, q in active],
                                   str(combined[key])))
        assert r7.nonzero(combined) == common
        support = {s.index[:2] for s in target[1] if s.family == "q"}
        marked = [tuple(k for k, ks in ms.items() if support & ks) for ms in markers]
        assert all(len(found) <= 1 for found in marked)
        if marked[0]:
            assert all(branch[:2] == marked[0][0] for rows in stream.values() for branch in rows)
        if marked[1]:
            assert all(key[:2] == marked[1][0] for rows in stream.values()
                       for group, _ in rows.values() for key in group)
        row = dict(target=r5.fingerprint(target), projected=projected, witness=witness,
                   prior_r7_checked=prior is not None, marked_planes=marked,
                   component_groups=[(key, group_rows(group)) for key, group in sorted(sums.items())],
                   component_totals=[(key, str(sum(group.values(), Q(0))))
                                     for key, group in sorted(sums.items())],
                   paths=[(comp, [(branch, paths, group_rows(group))
                                  for branch, (group, paths) in sorted(rows.items())])
                          for comp, rows in sorted(stream.items())],
                   all_ones_groups=group_rows(combined), collisions=collisions,
                   all_ones_total=str(sum(combined.values(), Q(0))))
        results.append(row)
        seen.add(target)
        return row

    prior = json.loads((HERE / "publication-task4-predecessor-roster-r7.json").read_text())
    for row in prior["results"]:
        check(r6.decoded(row["target"]), prior=row)

    generator = random.Random(418533)
    sample_counts = {}
    leaf = (0, 3, 1, 2, 0, 1)
    predecessor_branches = tuple((k, l, *[i for i in range(4) if i not in (k, l)], 0, 1)
                                 for k, l in PLANES)
    for i, component in enumerate(COMPONENTS):
        slot = SLOTS[i % 2]
        seed_contact = direction_1 if slot == SLOTS[1] else contact[slot]
        for attempt in range(256):
            pred = predecessor_branches[(i + attempt) % len(predecessor_branches)]
            _, _, mu, nu, a, b = pred
            _, _, ym, yn, ya, yb = leaf
            factors = (cx[mu, a], cx[nu, b], hx[pred], continuation[component],
                       seed_contact, cy[ym, ya], cy[yn, yb], hy[leaf])
            work.charge("seed_draws", len(factors))
            occupied, symbols = 0, ()
            for factor in factors:
                (m, key, _), _ = generator.choice(tuple(r4.rows(factor)))
                if m & occupied:
                    break
                occupied |= m
                symbols += key
            else:
                target = occupied, tuple(sorted(symbols)), slot
                if target in seen:
                    continue
                measured = streamed(target)
                rows = measured[0].get(component, {})
                if not r7.nonzero(subtotal_map(rows)):
                    continue
                sample_counts[component] = attempt + 1
                check(target, witness=(component, pred, leaf), prepared=measured)
                break
        else:
            raise AssertionError(f"no positive component witness {component} in 256 draws")

    # The literal operand is also a summand of the mixed operand. Check the
    # unmodified full mixed evaluator at exactly the same anchored symbols.
    mixed_direction0 = []
    for axis in range(4):
        literal = next(row for row in results[32:48] if row["witness"][0][0] == axis
                       and tuple(row["target"]["slot"]) == SLOTS[0])
        mask, symbols, _ = r6.decoded(literal["target"])
        mixed = check((mask, symbols, SLOTS[1]))
        assert mixed["paths"] == literal["paths"]
        assert mixed["all_ones_groups"] == literal["all_ones_groups"]
        mixed_direction0.append(len(results) - 1)

    # Two genuine overlapping component pairs, in distinct raw slots.
    # The all-ones contraction is nonzero; the phase-weighted one vanishes.
    weighted_controls = []
    for i in (0, 6):
        target = r6.decoded(results[i]["target"])
        stream, _ = streamed(target)
        groups = {c: subtotal_map(rows) for c, rows in stream.items()}
        first, second = (2, 0), (2, 1)
        assert r7.nonzero(groups[first]) and r7.nonzero(groups[second])
        for sign in (-1, 1):
            weights = {first: Q(1), second: Q(0, sign)}
            _, got = oracle(target, weights)
            want = {group: sum((weight * groups[c].get(group, Q(0))
                                for c, weight in weights.items()), Q(0))
                    for group in hy}
            assert got == r7.nonzero(want)
            assert bool(got) == (sign == 1)
            weighted_controls.append(dict(target_index=i, weights=[(c, str(q)) for c,q in weights.items()],
                                          exact_groups=group_rows(got),
                                          total=str(sum(got.values(), Q(0)))))

    adverse = []
    for slot in SLOTS:
        row = next(r for r in results[32:] if tuple(r["target"]["slot"]) == slot)
        mask, symbols, _ = r6.decoded(row["target"])
        wrong = S("J", (reg.step(y, 1)[0], 0, 0))
        target = mask, tuple(sorted(wrong if s.family == "J" else s for s in symbols)), slot
        assert not streamed(target)[0] and oracle(target) == ({}, {})
        adverse.append(("wrong_source_zero", r5.fingerprint(target)))
    dry = r5.Work(cap=0)
    try:
        signed_stream(r6.decoded(results[0]["target"]), cx, hx, continuation, contact, arena, yc, yh, dry)
    except RuntimeError as exc:
        assert dry.used == 0 and "work cap at 0" in str(exc)
        adverse.append(("zero_work_refusal", str(exc)))
    else:
        raise AssertionError("zero-work query returned a coefficient")

    print(json.dumps(dict(
        regulator=dict(extents=reg.extents, word=reg.word, convention=reg.convention),
        centers=(x, y, w), fixed_component=FIXED,
        component_records=[(key, r5.count(e), sha256(json.dumps([
            (r5.fingerprint(row), str(q)) for row, q in r4.rows(e)], sort_keys=True).encode()).hexdigest())
            for key, e in continuation.items()],
        occurrence_counts=[(key, n) for key, n in sorted(occurrences.items())],
        source_choices=dict(predecessor=len(hx), later=len(hy), predecessor_canceled=len(x_diag),
                            later_canceled=len(y_diag), site_alternatives=r4.ALTERNATIVES),
        markers=[[(k, sorted(v)) for k, v in ms.items()] for ms in markers],
        results=results, adverse=adverse, weighted_controls=weighted_controls,
        mixed_direction0_target_indices=mixed_direction0, sample_counts=list(sample_counts.items()),
        projection_cap=PROJECTION_CAP, work=dict(work.counts), work_total=work.used,
        work_cap=work.cap, oracle_record_cap=work.oracle_record_cap,
        oracle_pair_peak=work.oracle_max_prospective_records, arena=arena.metric(),
        native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss), indent=2))


if __name__ == "__main__":
    main()
