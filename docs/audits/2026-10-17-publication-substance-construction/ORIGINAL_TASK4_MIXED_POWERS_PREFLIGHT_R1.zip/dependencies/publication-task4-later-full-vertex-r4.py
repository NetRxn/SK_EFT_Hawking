"""Bounded original N16 full selected later vertex. Scratch only."""
from dataclasses import dataclass
from itertools import product
from math import comb
import json
import resource
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

Q, P, E, S = o.QComplex, o.Polynomial, o.ExteriorPolynomial, o.Symbol
INDICES = ((), (0,), (1,), (0, 0), (0, 1), (1, 1))
ALTERNATIVES = tuple((q,p) for q in range(3) for p in range(5-2*q))

class Refusal(ValueError):
    def __init__(self, kind, visits, live):
        self.kind, self.visits, self.live = kind, visits, live
        super().__init__(f'{kind} cap: visits={visits}, requested_live={live}')

@dataclass(frozen=True, slots=True)
class Refused:
    kind: str
    visits: int
    live: int

class BucketDirectory(dict):
    """Weak references are available for the refusal lifetime test."""

@dataclass(frozen=True, slots=True)
class Caps:
    visits: int
    records: int

    def check(self):
        if type(self.visits) is not int or not 0 < self.visits <= 2_000_000:
            raise ValueError('visits must be a positive exact integer within the probe envelope')
        if type(self.records) is not int or not 0 < self.records <= 65_536:
            raise ValueError('records must be a positive exact integer within the probe envelope')

class Arena:
    """Track coefficient and mask-index logical slots, not Python heap bytes."""
    def __init__(self, caps):
        if type(caps) is not Caps:
            raise ValueError('exact scratch Caps required')
        caps.check()
        self.caps = caps
        self._maps = {}
        self._index_slots = {}
        self._readers = {}
        self._serial = 0
        self._issued_serial = 0
        self._used = 0
        self._charged = {'buckets': 0, 'records': 0}
        self._live = 0
        self._peak = 0

    def _check(self):
        self.caps.check()
        active=tuple(self._maps)+tuple(self._index_slots)
        if (type(self._serial) is not int or self._serial < 0
                or type(self._issued_serial) is not int or self._serial != self._issued_serial
                or any(type(h) is not int or not 0 < h <= self._serial for h in active)
                or len(set(active)) != len(active)):
            raise ValueError('invalid handle allocation serial or roster')
        if any(type(h) is not int or h not in self._maps or type(n) is not int or n <= 0
               for h,n in self._readers.items()):
            raise ValueError('invalid reader roster')
        if type(self._used) is not int or not 0 <= self._used <= self.caps.visits:
            raise ValueError('invalid consumed visit counter')
        if (set(self._charged) != {'buckets','records'}
                or any(type(v) is not int or v < 0 for v in self._charged.values())
                or sum(self._charged.values()) != self._used):
            raise ValueError('inconsistent charged visit ledger')
        if any(type(v) is not int or v < 0 for v in self._index_slots.values()):
            raise ValueError('invalid indexed storage accounting')
        known = sum(map(len,self._maps.values())) + sum(self._index_slots.values())
        if type(self._live) is not int or self._live != known:
            raise ValueError('invalid live-record counter')
        if type(self._peak) is not int or not self._live <= self._peak <= self.caps.records:
            raise ValueError('invalid peak-record counter')

    def _admit(self, extra):
        prospective = self._live+extra
        if prospective > self.caps.records:
            raise Refusal('records',self._used,prospective)

    def _update(self, delta):
        self._live+=delta
        self._peak=max(self._peak,self._live)

    def visit(self,kind='records'):
        self._check()
        if kind not in self._charged:
            raise ValueError('unknown visit accounting kind')
        if self._used >= self.caps.visits:
            raise Refusal('visits',self._used,self._live)
        self._used+=1
        self._charged[kind]+=1

    def _new_id(self):
        self._check()
        next_id=self._serial+1
        if next_id in self._maps or next_id in self._index_slots:
            raise ValueError('handle collision before mutation')
        self._serial=next_id
        self._issued_serial=next_id
        return next_id

    def _require_map(self,h,*,mutable=False):
        if type(h) is not int or h <= 0 or h not in self._maps:
            raise ValueError('unowned or nonexact map handle')
        if mutable and h in self._readers:
            raise ValueError('map is in an active read')
        return self._maps[h]

    def _require_index(self,h):
        if type(h) is not int or h <= 0 or h not in self._index_slots:
            raise ValueError('unowned or nonexact index handle')

    def new_map(self):
        self._check()
        h=self._new_id()
        self._maps[h]={}
        return h

    def put(self,h,key,c):
        self._check()
        self._require_map(h,mutable=True)
        if type(key) is not tuple or len(key)!=3 or type(c) is not Q:
            raise ValueError('immutable exact coefficient record required')
        mask,symbols,slot=key
        if (type(mask) is not int or not 0<=mask<1<<128
                or type(symbols) is not tuple or any(type(v) is not S for v in symbols)
                or type(slot) is not tuple or len(slot)>2
                or any(type(i) is not int or i not in (0,1) for i in slot)
                or slot!=tuple(sorted(slot))):
            raise ValueError('invalid exact original mask, symbols or raw slot')
        prior=self._maps[h].get(key)
        value=c if prior is None else prior+c
        if value:
            if prior is None:
                self._admit(1)
                self._maps[h][key]=value
                self._update(1)
            else:
                self._maps[h][key]=value
        elif prior is not None:
            del self._maps[h][key]
            self._update(-1)

    def ingest(self,rows):
        result=self._ingest_transaction(rows)
        if isinstance(result,Refused):
            del rows
            raise Refusal(result.kind,result.visits,result.live) from None
        return result

    def _ingest_transaction(self,rows):
        h=self.new_map()
        try:
            for key,c in rows: self.put(h,key,c)
        except Refusal as err:
            self.drop(h)
            return Refused(err.kind,err.visits,err.live)
        except BaseException:
            self.drop(h)
            raise
        return h

    def drop(self,h):
        self._check()
        self._require_map(h,mutable=True)
        self._update(-len(self._maps.pop(h)))

    def _new_index(self):
        self._check()
        h=self._new_id()
        self._index_slots[h]=0
        return h

    def _index_admit(self,h,extra):
        self._check()
        self._require_index(h)
        if type(extra) is not int or extra < 0:
            raise ValueError('invalid exact index increment')
        self._admit(extra)
        self._index_slots[h]+=extra
        self._update(extra)

    def _drop_index(self,h):
        self._check()
        self._require_index(h)
        self._update(-self._index_slots.pop(h))

    def retained(self,a,b):
        self._check()
        self._require_map(a)
        self._require_map(b)
        return tuple(sorted(set(self._maps)-{a,b}))

    def _check_join(self,a,b,retained):
        self._check()
        self._require_map(a)
        self._require_map(b)
        if type(retained) is not tuple or any(type(h) is not int or h <= 0 for h in retained):
            raise ValueError('retained must name exact positive owned handles')
        if len(set(retained))!=len(retained) or set(retained)!=set(self._maps)-{a,b}:
            raise ValueError('inconsistent retained live-map roster')

    def metric(self):
        self._check()
        return dict(visits=self._used,charged_by_kind=dict(self._charged),
                    live_records=self._live,peak_records=self._peak,
                    live_maps=len(self._maps),live_indexes=len(self._index_slots),
                    active_readers=sum(self._readers.values()))

    def count(self,h):
        self._check()
        return len(self._require_map(h))

    def get(self,h,key):
        self._check()
        return self._require_map(h).get(key)

    def scan(self,h,callback):
        """Synchronous borrow: callback receives an immutable key/value pair only."""
        self._check()
        self._require_map(h)
        self._readers[h]=self._readers.get(h,0)+1
        try:
            for key,value in self._maps[h].items():
                callback(key,value)
        finally:
            n=self._readers[h]-1
            if n:
                self._readers[h]=n
            else:
                del self._readers[h]

    def _bucket(self,h,shared,ticket):
        buckets=BucketDirectory()
        for key,value in self._maps[h].items():
            mask=key[0]&shared
            if mask not in buckets:
                self._index_admit(ticket,1)
                buckets[mask]=[]
            self._index_admit(ticket,1)
            buckets[mask].append((key,value))
        return buckets

    def _product(self,out,litem,ritem):
        (lm,lk,lj),lc=litem
        (rm,rk,rj),rc=ritem
        if lm&rm or len(lj)+len(rj)>2:
            return
        slot=tuple(sorted(lj+rj))
        multiplier=1
        for label in set(slot):
            multiplier*=comb(slot.count(label),lj.count(label))
        sign=1
        bits=lm
        while bits:
            low=bits&-bits
            if (rm&(low-1)).bit_count()%2:
                sign=-sign
            bits^=low
        self.put(out,(lm|rm,tuple(sorted(lk+rk)),slot),lc*rc*(sign*multiplier))

    def join(self,a,b,retained=(),*,complement=False):
        self._check_join(a,b,retained)
        result=self._join_transaction(a,b,complement)
        # Raise only from a frame containing the immutable receipt. In
        # particular no inner traceback, directory, row list or iterator
        # becomes reachable from the caller's saved exception.
        if isinstance(result,Refused):
            raise Refusal(result.kind,result.visits,result.live) from None
        return result

    def _join_transaction(self,a,b,complement):
        out=self.new_map()
        ticket=None
        stats=dict(bucket_checks=0, compatible_record_visits=0, record_visits=0,
                   shared_bits=0,index_records=0)
        try:
            if complement:
                union_a=union_b=0
                for mask,_,_ in self._maps[a]: union_a|=mask
                for mask,_,_ in self._maps[b]: union_b|=mask
                shared=union_a&union_b
                stats['shared_bits']=shared.bit_count()
                ticket=self._new_index()
                left=self._bucket(a,shared,ticket)
                right=self._bucket(b,shared,ticket)
                stats['index_records']=self._index_slots[ticket]
                for lm,rows in left.items():
                    for rm,cols in right.items():
                        self.visit('buckets')
                        stats['bucket_checks']+=1
                        if lm&rm: continue
                        for litem in rows:
                            for ritem in cols:
                                self.visit()
                                stats['compatible_record_visits']+=1
                                self._product(out,litem,ritem)
            else:
                for litem in self._maps[a].items():
                    for ritem in self._maps[b].items():
                        self.visit()
                        stats['record_visits']+=1
                        self._product(out,litem,ritem)
        except Refusal as err:
            self.drop(out)
            return Refused(err.kind,err.visits,err.live)
        except BaseException:
            self.drop(out)
            raise
        finally:
            if ticket is not None:
                self._drop_index(ticket)
        return out,stats

def exterior(reg,alpha):
    return o.assemble_coframe(reg,f.original_coframe_blocks(reg,alpha)).to_exterior(reg)

def rows(e):
    return (((mask,key,()),value) for mask,p in e.terms for key,value in p.terms)

def factors(reg):
    x=reg.sites[0]
    k,l,mu,nu,a,b=2,3,0,1,0,1
    anchor=(x,k)
    xk=reg.step(x,k)[0]
    anchors=(anchor,(xk,l),(reg.step(x,l)[0],k),(x,l))
    def link(site_axis):
        return f.original_spin4_link(*(tuple(P.variable(S('q',(*site_axis,chi,j)))
                                      for j in range(4)) for chi in ('L','R')))
    u=f.original_plaquette(reg,x,k,l,{z:link(z) for z in anchors})
    g=o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    trace=sum((u[i][j]*g[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))
    return (exterior(reg,(x,mu,a)),exterior(reg,(x,nu,b)),E(((0,trace),)),
            exterior(reg,(xk,k,0)),anchor)

def make_prefix(caps,actual):
    arena=Arena(caps)
    a,b=arena.ingest(rows(actual[0])),arena.ingest(rows(actual[1]))
    c,_=arena.join(a,b)
    arena.drop(a); arena.drop(b)
    t=arena.ingest(rows(actual[2]))
    return arena,c,t

def future_prefix(caps,actual):
    arena,c,t=make_prefix(caps,actual)
    future=arena.ingest(rows(actual[3]))
    d,_=arena.join(t,future,(c,))
    arena.drop(t); arena.drop(future)
    return arena,c,d

def attempt(arena,a,b,*,complement=False):
    before=arena.metric()
    try: arena.join(a,b,arena.retained(a,b),complement=complement)
    except Refusal as exc:
        after=arena.metric()
        assert after['live_records']==before['live_records']
        assert after['live_maps']==before['live_maps'] and not after['live_indexes'] and not after['active_readers']
        return dict(refused=exc.kind,at_visits=exc.visits,requested_live_records=exc.live,
                    released_partial_map_and_index=True,before=before,after=after)
    raise AssertionError('bounded refusal was required')


def oracle_snapshot(arena,h):
    """Explicit independent bounded scratch copy, never part of a live join."""
    result={}
    arena.scan(h,lambda key,value:result.__setitem__(key,value))
    return result

def as_exterior(terms):
    assert all(j==() for _,_,j in terms)
    return E(tuple((mask,P(((key,value),))) for (mask,key,_),value in terms.items()))

def assert_exact(arena,h,reference):
    assert arena.count(h)==len(reference)
    def match(key,c): assert c==reference[key]
    arena.scan(h,match)

def add_handle(arena,out,h):
    arena.scan(h,lambda key,v:arena.put(out,key,v))

def ownership_controls():
    arena=Arena(Caps(20,20))
    key=(1,(),())
    h=arena.ingest(((key,Q(3)),))
    blocked=[]
    def read(k,c):
        assert k==key and c==Q(3)
        for invoke in (lambda:arena.drop(h),lambda:arena.put(h,k,Q(1))):
            try: invoke()
            except ValueError: blocked.append(True)
            else: raise AssertionError('mutated active borrow')
        return {'data':(k,c)}  # callback return is not a map/iterator escape.
    assert not hasattr(arena,'map')
    assert arena.scan(h,read) is None and len(blocked)==2
    def raise_read(k,c):
        raise RuntimeError('bounded reader failure')
    try: arena.scan(h,raise_read)
    except RuntimeError: pass
    else: raise AssertionError('reader exception not seen')
    assert arena.metric()['active_readers']==0
    assert arena.get(h,key)==Q(3)
    invalid=0
    for bad in (True,False,1.0,0,-1,float('nan'),h+100):
        for call in (lambda:arena.get(bad,key),lambda:arena.count(bad),
                     lambda:arena.scan(bad,lambda *_:None),lambda:arena.drop(bad),
                     lambda:arena.put(bad,key,Q(1)),lambda:arena.retained(bad,h),
                     lambda:arena.join(bad,h)):
            try: call()
            except ValueError: invalid+=1
            else: raise AssertionError((bad,call))
    assert arena.get(h,key)==Q(3) and arena.metric()['live_records']==1
    it=arena._new_index()
    arena._index_admit(it,1)
    for bad in (True,float('nan'),-1,1.0):
        for call in (lambda:arena._index_admit(bad,1),lambda:arena._drop_index(bad),
                     lambda:arena._index_admit(it,bad)):
            try: call()
            except ValueError: invalid+=1
            else: raise AssertionError((bad,call))
    arena._drop_index(it)
    honest=arena._serial
    for bad in (0,True,-1,1.0,float('nan')):
        arena._serial=bad
        for action in (arena.new_map,arena._new_index):
            try: action()
            except ValueError: pass
            else: raise AssertionError('corrupt serial allocated')
            # Inspect without normal guard while serial remains adversarial.
            assert set(arena._maps)=={h} and arena._maps[h]=={key:Q(3)}
            assert not arena._index_slots and arena._live==1
        arena._serial=honest
    malformed=(((True,(),()),Q(1)),((1,[S('g2',())],()),Q(1)),
               ((1,(),(False,)),Q(1)),(key,{'mutable':'not a coefficient'}))
    for k,c in malformed:
        try: arena.put(h,k,c)
        except ValueError: pass
        else: raise AssertionError('mutable or inexact record accepted')
    arena.drop(h)
    assert arena.metric()['live_records']==0
    arena._serial=0  # Even an empty arena must not revive a stale handle.
    try: arena.new_map()
    except ValueError: pass
    else: raise AssertionError('stale handle revived')
    assert not arena._maps and arena._issued_serial==honest
    arena._serial=honest
    assert arena.new_map()>honest
    return dict(escaped_view_interface_absent=True,callback_returns_no_borrow=True,
                active_borrow_mutation_refusals=len(blocked),reader_exception_releases=True,
                invalid_map_or_index_controls=invalid,pre_mutation_serial_refusals=11,
                invalid_record_controls=len(malformed))

def closed_trace(reg,x,k,l,mu,nu,a,b):
    anchors=((x,k),(reg.step(x,k)[0],l),(reg.step(x,l)[0],k),(x,l))
    def link(site_axis):
        return f.original_spin4_link(*(tuple(P.variable(S('q',(*site_axis,chi,j)))
                                      for j in range(4)) for chi in ('L','R')))
    u=f.original_plaquette(reg,x,k,l,{z:link(z) for z in anchors})
    g=o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    return sum((u[i][j]*g[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))

def literal_j(reg,y,mu,a):
    symbol=S('J',(y,mu,a))
    return symbol,exterior(reg,(y,mu,a))*P.variable(symbol)

def later_nonconstant_leaf(reg,y,reference):
    """A complete one-monomial leaf of a distinct real later S2 choice."""
    k,l,mu,nu,a,b=0,3,1,2,0,1
    trace=closed_trace(reg,y,k,l,mu,nu,a,b)
    assert trace
    v0=exterior(reg,(y,mu,a)); v1=exterior(reg,(y,nu,b))
    # This exact bounded control selects one actual coframe monomial per
    # factor and one actual curvature monomial, not a synthetic matrix.
    source0=list(rows(v0));source1=list(rows(v1))
    choices=iter(reference)
    for om,_,_ in choices:
        pair=next(((k0,c0,k1,c1) for k0,c0 in source0 for k1,c1 in source1
                   if not k0[0]&k1[0] and not om&(k0[0]|k1[0])),None)
        if pair is not None: break
    else: raise AssertionError('later center leaf has no compatible control')
    k0,c0,k1,c1=pair
    q,c=trace.terms[0]
    leaf=as_exterior({k0:c0})*as_exterior({k1:c1})*P(((tuple(sorted((*q,S('g2',())))),c),))
    assert len(tuple(rows(leaf)))==1
    return leaf,dict(center=y,world_order=(k,l,mu,nu),components=(a,b),
                     complete_trace_support=len(trace.terms),selected_monomial_leaves=1)

def derivative_contact(reg,y,j,arena,left,one_r):
    """Raw J then frame contact of the actual local world-coframe map."""
    bare0=exterior(reg,(y,0,0))
    bare1=exterior(reg,(y,1,0))
    t_and_s=((0,),(0,1))
    poly=P.variable(j)
    # J(t)=t J and A_{00}(s)=1+s, A_{01}(s)=s.
    # The first and mixed slots follow directly by labelled differentiation.
    contacts=arena.ingest(((mask,key,slot),c) for slot,term in
                          zip(t_and_s,(bare0*poly,(bare0+bare1)*poly),strict=True)
                          for mask,entry in term.terms for key,c in entry.terms)
    out=arena.new_map()
    for h in left:
        intermediate,_=arena.join(h,contacts,arena.retained(h,contacts),complement=True)
        add_handle(arena,out,intermediate)
        arena.drop(intermediate)
    sliced,_=arena.join(out,one_r,arena.retained(out,one_r),complement=True)
    source_jet=o.RawJet((0,1),(((),P()),((0,),poly)))
    frame_jet=o.RawJet((0,1),(((),bare0),((1,),bare0+bare1)))
    a,b=(as_exterior(oracle_snapshot(arena,h)) for h in left)
    r=as_exterior(oracle_snapshot(arena,one_r))
    direct=o.RawJet.constant((a+b)*r)*frame_jet*source_jet
    exact={(mask,key,slot):c for slot in INDICES
           for mask,entry in direct.at(slot).terms for key,c in entry.terms}
    assert_exact(arena,sliced,exact)
    counts={str(slot):sum(jj==slot for _,_,jj in exact) for slot in t_and_s}
    assert all(counts.values()) and sum(counts.values())==len(exact)
    records=arena.count(contacts)
    arena.drop(sliced); arena.drop(out); arena.drop(contacts)
    return dict(literal_source_and_mixed_frame_derivatives_equal=True,
                raw_slots=counts,actual_contact_input_records=records)



def refusal_lifetime_controls():
    import weakref
    class Observe(Arena):
        def __init__(self,caps):
            super().__init__(caps)
            self.buckets=[]
        def _bucket(self,*args):
            result=super()._bucket(*args)
            self.buckets.append(weakref.ref(result))
            return result
    saved=[]
    checked=[]
    # First example builds both bucket maps and fails on output. Second
    # example fails during construction of the second index.
    for cap in (11,8):
        arena=Observe(Caps(20,cap))
        a=arena.ingest((((m,(),()),Q(1)) for m in (1,2)))
        b=arena.ingest((((m,(),()),Q(1)) for m in (4,8)))
        try: arena.join(a,b,complement=True)
        except Refusal as err: saved.append(err)
        else: raise AssertionError('expected record refusal')
        failure=saved[-1]
        assert failure.__context__ is None and failure.__cause__ is None
        tb=failure.__traceback__
        frames=[]
        while tb is not None:
            frames.append(tb.tb_frame.f_code.co_name)
            tb=tb.tb_next
        assert '_join_transaction' not in frames and '_bucket' not in frames and '_product' not in frames
        assert arena.buckets and all(ref() is None for ref in arena.buckets)
        assert arena.metric()['live_records']==4 and not arena.metric()['live_indexes']
        arena.drop(a);arena.drop(b)
        assert arena.metric()['live_records']==0
        checked.append(dict(refusal_cap=cap,visited=failure.visits,refusal_record=failure.live,
                            saved_trace_frames=frames,dead_bucket_weakrefs=len(arena.buckets)))
    # A generator passed to ingest must not be kept alive by a saved
    # refusal either. The wrapper deletes its own input reference.
    class Rows:
        def __iter__(self):
            for m in (1,2): yield (m,(),()),Q(1)
    source=Rows()
    weak=weakref.ref(source)
    arena=Arena(Caps(20,1))
    try: arena.ingest(source)
    except Refusal as err: saved.append(err)
    else: raise AssertionError('expected ingest refusal')
    del source
    assert weak() is None and arena.metric()['live_records']==0
    assert len(saved)==3
    return dict(saved_join_refusals=checked,retained_ingest_input_released=True)

def to_raw(records):
    return o.RawJet((0,1),tuple((slot,as_exterior({
         (m,k,()):v for (m,k,j),v in records.items() if j==slot
    })) for slot in INDICES))

def from_raw(jet):
    return {(m,k,j):c for j in INDICES for m,poly in jet.at(j).terms for k,c in poly.terms}

def contact_seed(reg,arena,C,R):
    x=reg.sites[0]
    y=reg.step(x,0)[0]
    z=reg.step(y,1)[0]
    ysite=255<<(8*reg.site_number(y))
    first=1<<(8*reg.site_number(y))
    g2=S('g2',())
    j=S('J',(y,0,0))
    axes=tuple(tuple(sorted((S('q',(x,0,'L',i)),S('q',(x,1,'L',0))))) for i in (1,2))
    left=tuple(arena.new_map() for _ in axes)
    def take(key,value):
        m,k,slot=key
        if m&ysite==first and k in axes:
            assert slot==()
            arena.put(left[axes.index(k)],(m,tuple(sorted((*k,g2))),slot),value)
    arena.scan(C,take)
    assert tuple(arena.count(h) for h in left)==(3,3)

    # The selected R factor is exactly the accepted first row whose
    # genuine shared (x,2) coordinate has exponent two.
    one_r=arena.new_map()
    def take_r(key,value):
        if not arena.count(one_r) and any(key[1].count(s)==2 and s.index[:2]==(x,2) for s in set(key[1])):
            arena.put(one_r,key,value)
    arena.scan(R,take_r)
    assert arena.count(one_r)==1
    bare0=exterior(reg,(y,0,0))
    bare1=exterior(reg,(y,1,0))
    p=P.variable(j)
    slots=((0,),(0,1))
    contact=arena.ingest(((m,k,slot),c) for slot,term in
                         zip(slots,(bare0*p,(bare0+bare1)*p),strict=True)
                         for m,v in term.terms for k,c in v.terms)
    residual=arena.new_map()
    for h in left:
        part,_=arena.join(h,contact,arena.retained(h,contact),complement=True)
        add_handle(arena,residual,part)
        arena.drop(part)
    original,_=arena.join(residual,one_r,arena.retained(residual,one_r),complement=True)

    a,b=(as_exterior(oracle_snapshot(arena,h)) for h in left)
    r=as_exterior(oracle_snapshot(arena,one_r))
    actual_j=o.RawJet((0,1),(((),P()),((0,),p)))
    actual_frame=o.RawJet((0,1),(((),bare0),((1,),bare0+bare1)))
    direct=from_raw(o.RawJet.constant((a+b)*r)*actual_frame*actual_j)
    assert_exact(arena,original,direct)
    source_counts={str(slot):sum(k[2]==slot for k in direct) for slot in slots}
    assert source_counts=={'(0,)':209,'(0, 1)':545}
    # Both chosen rows are genuine terms of this exact raw source map.
    # The mixed row must be from the additional world direction 1.
    chosen=arena.new_map()
    wanted=set(slots)
    mixed_link=None
    def pick(key,value):
        nonlocal mixed_link
        _,k,slot=key
        if slot not in wanted: return
        if slot==(0,1):
            mixed_link=next((s for s in k if s.family=='q' and s.index[:2] in ((y,1),(z,1))),None)
            if mixed_link is None: return
        assert j in k and g2 in k
        arena.put(chosen,key,value)
        wanted.remove(slot)
    arena.scan(original,pick)
    assert not wanted and arena.count(chosen)==2 and mixed_link is not None
    for h in (*left,one_r,contact,residual,original,C,R):
        arena.drop(h)
    return chosen,mixed_link,source_counts

def oriented_vertex(reg,y):
    k,l,mu,nu,a,b=0,3,1,2,0,1
    terms=[]
    for (i,j),(r,s) in product(((k,l),(l,k)),((mu,nu),(nu,mu))):
        # Sorting the two even coframe factors back to the declared
        # order exchanges gamma indices only for a reversed coframe pair.
        ia,ib=(a,b) if (r,s)==(mu,nu) else (b,a)
        terms.append(closed_trace(reg,y,i,j,r,s,ia,ib)*P.scalar(__import__('fractions').Fraction(1,4)))
    h=sum(terms,P())
    expected=closed_trace(reg,y,k,l,mu,nu,a,b)
    assert h==expected and len(h.terms)==128
    assert all(term==h*P.scalar(__import__('fractions').Fraction(1,4)) for term in terms)
    trace=E(((0,h*P.variable(S('g2',()))),))
    return exterior(reg,(y,mu,a)),exterior(reg,(y,nu,b)),trace,len(terms)

def axes_symbols(key,axes):
    return tuple(s for s in key if s.family=='q' and s.index[1] in axes)

def vertex_case(reg):
    arena=Arena(Caps(350_000,65_536))
    # These are the same two prefix joins as R2/R3, now on the repaired arena.
    actual=factors(reg)
    root0,root1=(arena.ingest(rows(e)) for e in actual[:2])
    C,_=arena.join(root0,root1)
    arena.drop(root0);arena.drop(root1)
    h=arena.ingest(rows(actual[2]));future=arena.ingest(rows(actual[3]))
    R,_=arena.join(h,future,(C,))
    arena.drop(h);arena.drop(future)
    assert (arena.count(C),arena.count(R))==(3584,8192)
    K,mixed_link,seed_counts=contact_seed(reg,arena,C,R)
    y=reg.step(reg.sites[0],0)[0]
    w=reg.step(y,2)[0]
    private_mask=255<<(8*reg.site_number(w))
    ta,tb,trace,norient=oriented_vertex(reg,y)
    ma,mb=(arena.ingest(rows(e)) for e in (ta,tb))
    W,_=arena.join(ma,mb,(K,),complement=True)
    direct_w=ta*tb
    assert_exact(arena,W,dict(rows(direct_w)))
    coframe_input_sizes=arena.count(ma),arena.count(mb)
    arena.drop(ma);arena.drop(mb)
    H=arena.ingest(rows(trace))
    # Disjoint world-axis sets recover the complete original coframe and
    # curvature input keys. This count prices the whole selected vertex.
    nv=(arena.count(W),arena.count(H))
    assert nv==(3584,128)
    def check_w(k,c): assert len(axes_symbols(k[1],(1,2)))==len(k[1])==2
    def check_h(k,c): assert k[0]==0 and k[2]==() and len(axes_symbols(k[1],(0,3)))==4
    arena.scan(W,check_w);arena.scan(H,check_h)
    eager=attempt(arena,W,H,complement=True)

    KW,_=arena.join(K,W,arena.retained(K,W),complement=True)
    snapshot_k=oracle_snapshot(arena,K)
    assert not any(m&private_mask for m,_,_ in snapshot_k)
    k_by_slot={k[2]:k for k in snapshot_k}
    assert len(k_by_slot)==2
    direct_kw=from_raw(to_raw(snapshot_k)*o.RawJet.constant(direct_w))
    assert_exact(arena,KW,direct_kw)

    # Keeping the slot identifies its one fixed incoming K. Thus the
    # high-axis part of KW is known; projecting to low-axis q, mask and
    # slot is injective. Charge proof metadata with the same arena.
    charge=arena._new_index()
    projected=set()
    groups={}
    count_by_slot={}
    mixed_squares=0
    def inspect(key,value):
        nonlocal mixed_squares
        mask,symbols,slot=key
        private=(mask,axes_symbols(symbols,(1,2)),slot)
        assert private not in projected
        arena._index_admit(charge,1)
        projected.add(private)
        assert axes_symbols(symbols,(0,3))==axes_symbols(k_by_slot[slot][1],(0,3))
        pkey=(mask&private_mask,axes_symbols(symbols,(2,)))
        squared=(slot==(0,1) and symbols.count(mixed_link)>1)
        mixed_squares+=int(squared)
        if pkey not in groups:
            arena._index_admit(charge,1)
            groups[pkey]=(0,0,False)
        n0,n1,found=groups[pkey]
        groups[pkey]=(n0+int(slot==(0,)),n1+int(slot==(0,1)),found or squared)
        count_by_slot[slot]=count_by_slot.get(slot,0)+1
    arena.scan(KW,inspect)
    assert mixed_squares
    selected=min((key for key, row in groups.items() if all(row)),
                 key=lambda key:(-sum(groups[key][:2]),key))
    chosen_counts=groups[selected][:2]
    partition_count=len(groups)
    assert len(projected)==arena.count(KW)
    del groups,projected
    arena._drop_index(charge)
    whole_refusal=attempt(arena,KW,H,complement=True)

    chosen=arena.new_map()
    def take(key,value):
        if (key[0]&private_mask,axes_symbols(key[1],(2,)))==selected:
            arena.put(chosen,key,value)
    arena.scan(KW,take)
    assert arena.count(chosen)==sum(chosen_counts)
    before=arena.metric()
    final,join_stats=arena.join(chosen,H,arena.retained(chosen,H),complement=True)

    # Direct eager local oracle on the COMPLETE recoverable output sector.
    # Select each original W operand from the independent ta*tb exterior
    # product, before multiplying by all H trace terms, then apply K.
    direct={}
    for (km,ks,slot),coefficient in snapshot_k.items():
        wterms=[]
        for wm,wpoly in direct_w.terms:
            if wm&km: continue
            matched=tuple((wk,wc) for wk,wc in wpoly.terms
                          if ((km|wm)&private_mask,axes_symbols(tuple(sorted(ks+wk)),(2,)))==selected)
            if matched:
                wterms.append((wm,P(matched)))
        incoming=E(((km,P(((ks,coefficient),))),))
        output=incoming*(E(tuple(wterms))*trace)
        for m,p in output.terms:
            for key,c in p.terms:
                assert (m&private_mask,axes_symbols(key,(2,)))==selected
                direct[m,key,slot]=c
    assert_exact(arena,final,direct)
    assert len(direct)==sum(chosen_counts)*nv[1]
    assert all(sum(s.family=='g2' for s in key)==2 and sum(s.family=='J' for s in key)==1
               for _,key,_ in direct)
    assert any(slot==(0,1) and key.count(mixed_link)>1 for _,key,slot in direct)
    return dict(seed_direct_contact_outputs=seed_counts,
        selected_actual_residual_rows=2,selected_slots=[str(j) for j in sorted(k_by_slot)],
        mixed_frame_shared_anchor_coordinate=mixed_link.index,
        original_coframe_input_sizes=coframe_input_sizes,
        original_ordered_trace_contributions=norient,coframe_records=nv[0],complete_trace_records=nv[1],
        complete_grouped_vertex_distinct_keys=nv[0]*nv[1],
        eager_complete_vertex_refusal=eager,
        complete_signed_pretrace_records_by_slot={str(k):v for k,v in count_by_slot.items()},
        mixed_shared_coordinate_squared_pretrace_records=mixed_squares,
        exact_full_factored_output_keys_by_slot={str(k):v*nv[1] for k,v in count_by_slot.items()},
        eager_full_contact_through_vertex_refusal=whole_refusal,
        recoverable_output_partitions=partition_count,
        complete_selected_partition_pretrace_records=chosen_counts,
        complete_selected_partition_outputs=len(direct),all_partition_coefficients_match=True,
        selected_partition_join=join_stats,before_selected_partition_join=before,
        final_arena=arena.metric())

def main():
    print(json.dumps(dict(ownership=ownership_controls(),refusal_lifetime=refusal_lifetime_controls(),
        result=vertex_case(o.OriginalRegulator()),all_original_alternatives=ALTERNATIVES,
        original_grouped_vertex_choices_per_center=72,other_grouped_vertex_choices_remaining=71,
        native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_unit='bytes' if sys.platform=='darwin' else 'KiB'),indent=2))
if __name__=='__main__': main()
