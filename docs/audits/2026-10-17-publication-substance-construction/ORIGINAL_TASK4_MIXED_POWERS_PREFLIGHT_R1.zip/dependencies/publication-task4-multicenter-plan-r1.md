# Original N16 two-center continuation preflight

## Carrier and measured intersections

Use the original periodic closed-word source-C carrier with extents
(2,2,2,2), paired boundary signs all +1, and generator order supplied
by OriginalRegulator. Keep x=(0,0,0,0) and y=x+e0=(1,0,0,0),
the exact original S2 at each, and the original y contact. Continue
the existing w=x+e2=(0,0,1,0) and add z=w+e0=y+e2=(1,0,1,0).
The factor order is x, w, z, contact, y. Identity at z recovers
the existing order. The two actual contacts are J T_y00 and
J(T_y00+T_y10) with the same anchored J. Directions 0 and 1 of the
mixed seed are target construction routes for the same observable.

The coframe support stars at w and z intersect on w and z themselves.
Both directed e0 anchors remain distinct even though forward and
backward hops reach the same neighbor. Each site's curvature
anchor set has 16 elements. The two sets share six, namely axes
1,2,3 at both w and z. Combined coframe and curvature support
shares all eight anchored axes at w and z. The full x/y/w/z
pair matrix is in the JSON, including the two square diagonals.
For example w and y have overlapping coframe exterior sites x and z.

Actual T_w00 T_z00 has coefficient -1/16 at exterior mask
0x1100000000000000440000 and q_(w,0,L,1)^2. The canonical exterior
product and an independent signed ordered-pair enumeration agree.
A distinct pair of actual rows has the identical exterior mask
0x8000000000000000020000 and annihilates before any quaternion
integration. The selected k=0,l=1 traces with coframe axes 2,3
also share anchored variables independently of the reciprocal
coframe example. The bounded preflight explicitly constructs all
four original orientations for each selected trace, checks its
128-term grouped sum, and records a disjoint nonzero branch path
with a repeated q_(w,1,L,0) and signed coefficient +1/64.
This branch path alone leaves the full two-center coefficient open.

## Construction and deterministic evaluation

Use the complete per-site alternatives (a,b) in
(0,0),(1,0),(2,0),(3,0),(4,0),(0,1),(1,1),(2,1),(0,2).
Here a is the S2 power and b is the S4 power. Each nonzero coframe
contributes one of the center's eight bits, so 2a+4b>8 is structurally
zero independently of surrounding factors. This argument applies
separately to both sites. The weight is the product of the two
1/(a!b!) weights. Keep all 81 allocation pairs distinct in control
metadata. Physical keys retain the actual shared couplings. In
particular exchange of a power between centers may leave the same
g2/g1 grade and must be reaggregated whenever an output asks for
their sum. Do not add fake site-labelled couplings to source keys.

For a pair with A=a_w+a_z and B=b_w+b_z the raw exterior and
quaternion grades are respectively 10+4A+8B and 13+6A+4B, with
g2^(2+A) g1^B J. For two center degrees eight, each center's own
coframes already occupy all its bits. Reciprocal coframe edges
between the centers then vanish and incident x/y factors using
either saturated site's bits are excluded by the exact mask.
The unsaturated (1,0),(1,0) case keeps those edges available and
tests repeated anchored coordinates directly. Global odd
quaternion grade does not justify eliminating raw intermediate keys.

Enumerate the 81 allocation pairs by increasing total center degree,
then lexicographically by the ordered four powers (a_w,b_w,a_z,b_z).
At each pair use the literal direction-0 target and both directions
of the combined contact. The deterministic seed policy should use
fixed seed 20261107, exact original source ordering, R13's charged
immutable row draws, 2,048 structural attempts and at most 12
qualified disjoint witnesses per request. Restrict the first
two-center implementation to the three (1,0),(1,0) requests and
identity restrictions at z. Require its literal reciprocal-edge
control to have repeated anchored q, a distinct overlap case to
return zero, and a nonzero exact signed coefficient for at least
one representative target. If a requested witness does not meet
those conditions within the cap, record its exact refusal. The
next ordered batch should cover (1,0),(0,1), the reversed allocation,
then paired high powers once the evidence supports admission.
The 243 request identities describe the eventual schedule and
are not an admission for a single heavy replay.

Production should build site-local weighted tables projected to
the exact target mask and symbol multiset. Use full exterior keys
and exact symbol multisets for complementary joins. Partition
retained local tables by occupied center masks where needed.
Make x/contact/y residuals before the join, stream one w partition,
and read z's exact complementary key. Cross-center multiplication
must apply the signed exterior inversion and reject any repeated
bit before constructing the candidate output. Aggregate exact x/y
groups and save a fully labelled witness before collapsing local
labels. Carry all independently accepted prior signed records into
the existing 2,048 global signed-record cap. Preserve prospective
8,192 live local rows, 8,192 later paths, 16,384 oracle scratch rows,
and 20 million charged operations for the first reviewed run.
Before each admission count simultaneous local input tables,
index references, previous and next maps, residuals, oracle
temporaries and accumulated signed groups as appropriate to each
named cap. Charge all attempted and accepted inner work, including
the complete signed fanout. A cap refusal is a result to preserve,
with its target, phase, prospective amount and exact code identity.

The independent oracle must rebuild each complete site source
with original_action_factors, all 384 ordered S2 orientations and
24 S4 permutations, multiplying original coframes in source order
with canonical ExteriorPolynomial arithmetic. Multiply independent
raw factors for the prescribed powers using their factorials.
The oracle may partition oversized canonical products by a
single left row with a prospective bound and then sum exact
projected rows. Do not derive its candidate local tables or
lookups from production. Compare signed x/y coefficients for every
admitted target and carry the exact complete sum, including zero
rows with nonzero paths where the scope calls for them. The
smaller current preflight checks one complete coframe product and
one actual curvature path. It does not execute this coefficient
oracle or the original two-center seam.

## Last use

For a fixed factor schedule, a generator can be retired only when
its bit is outside the union of exterior support of every remaining
factor. An anchored quaternion coordinate can be retired only
when its entire independent (site, axis, hand) family is outside
the remaining source incidence. Maintain this separately from
target projection and from optional physical integration. A raw
target coefficient preserves requested mask bits and quaternion
multiplicities even after their last factor. A full Berezin
coefficient may enforce all eight bits at a site only after every
incident action or contact has passed. An actual Haar evaluation
may apply exact moments to an anchor-hand only once all its
coordinates have passed their last use. Preserve signs and moments
separately for distinct reciprocal anchors.

In the proposed square both centers and their shared quaternion
families are live across the w/z cut. The x/y side of the square
introduces additional later incidence, so local center completion
alone does not prove last use. The full 16-site continuation
requires an incidence graph including every unprocessed action
and contact. The current topology proves necessary retention and
a safe sufficient future-support test, with no claimed complete
schedule, normalized response or publication closure.

Next action is independent review of this plan and exact preflight,
then one admitted low-power two-center package with real
overlap and collision controls. All three selected fixed-center R13
quartic directions have independent acceptance. The remaining quartic
work covers other center pairs and unselected coefficients.
