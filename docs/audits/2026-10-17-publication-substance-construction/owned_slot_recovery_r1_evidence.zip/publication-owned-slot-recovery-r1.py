"""One-time ROOT operation authorized by the operator; not controller machinery."""
from pathlib import Path
from datetime import datetime, timezone
import os, sys, json, subprocess, hashlib

primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
os.chdir(primary);sys.path.insert(0,str(primary/'scripts'))
from lean_slots.state import Inventory, directory_lock
from lean_slots.controller import Controller
from lean_slots.supervisor import Supervisor

inv=Inventory.load(primary/'config/lean-slots.public.json');ctl=Controller(inv);sup=Supervisor(inv)
archive=primary/'.codex/continuity/publication-owned-slot-recovery-20261106-r1'
archive.mkdir(exist_ok=False)
receipt={'authorization':'Operator explicitly authorized saved-worktree manual recovery by the team orchestrator, 2026-11-06; ROOT is the designated reset owner.','started_at':datetime.now(timezone.utc).isoformat(),'slots':[],'source_or_configuration_changes':False,'cache_changes_in_manual_recovery':False}
def save():
 p=archive/'receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
 with p.open('rb') as f:os.fsync(f.fileno())
def git(*args,cwd=primary):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
def preserve_file(src,dst):
 b=src.read_bytes()
 with dst.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert dst.read_bytes()==b
 return hashlib.sha256(b).hexdigest()
targets={2:('8187fc8312d3a9a070239adea5a4f04c48266822','codex/preserve-wt2-bp-20261106'),3:('3505b2f8afa4b47ef34b02771983dc8083a1c7fa','codex/preserve-wt3-frontier-20261106')}
base_ref=git('branch','--show-current');base_sha=git('rev-parse','HEAD')
assert base_ref=='codex/publication-primary-custody-20261105'
assert base_sha=='2fbbfd95a396cadfd89961dea226d84c4f281675'
assert not ctl._dirty(primary)
receipt.update(base_ref=base_ref,base_sha=base_sha)
remote=git('ls-remote','--heads','origin',*[f'refs/heads/{ref}' for _,ref in targets.values()])
remote_refs={line.split()[1]:line.split()[0] for line in remote.splitlines()}
for old,ref in targets.values():
 assert remote_refs.get('refs/heads/'+ref)==old
 if git('branch','--list',ref):assert git('rev-parse','refs/heads/'+ref)==old
 else:subprocess.run(['git','branch',ref,old],cwd=primary,check=True)
save()
try:
 with directory_lock(inv.state_root/'locks/integration.lock',purpose='operator-authorized preserved-slot recovery'):
  for n,(old,ref) in targets.items():
   with ctl._slot_lock(n):
    ctl._assert_no_stop_only_reservation(n)
    lease=ctl._lease_for_command(n,states={'READY_TO_ABSORB','QUARANTINED'})
    worktree,slot=ctl._assert_worktree_identity(n)
    assert not ctl._dirty(worktree) and git('rev-parse','HEAD',cwd=worktree)==old
    assert git('rev-parse',base_ref)==base_sha
    with sup.lifecycle():
     census=sup.capacity_census()
     assert census['complete'] and not census['conflicts'] and not census['errors']
     assert n not in census['reserved_physical_slots']
     observations=[]
     for kind in ('backend','proxy'):
      assert sup.process_state(kind,n)=='down'
      sup._assert_quiescent(kind,n,observations=observations)
     item={'slot':n,'old_head':old,'preserved_local_and_remote_ref':ref,'original_lease':lease,'quiescence':[o.as_dict() for o in observations],'actions':[]}
     receipt['slots'].append(item)
     lease_path=inv.lease_path(n)
     original_hash=preserve_file(lease_path,archive/f'wt{n}-lease-original.json')
     item['lease_sha256']=original_hash
     for kind in ('backend','proxy'):
      p=inv.process_path(kind,n)
      if p.exists():item[kind+'_original_sha256']=preserve_file(p,archive/f'wt{n}-{kind}-original.json')
     save()
     # Existing guarded lifecycle functions clear only genuinely quiescent records.
     sup._stop_backend_unlocked(n);sup._stop_proxy_unlocked(n)
     item['actions'].append('existing guarded stop confirmed quiescence and retired stopped process records')
     subprocess.run(['git','checkout','--no-overwrite-ignore','-B',slot['branch'],base_ref],cwd=worktree,check=True,capture_output=True,text=True)
     assert git('rev-parse','HEAD',cwd=worktree)==base_sha and not ctl._dirty(worktree)
     item['actions'].append('saved clean worktree branch reset to authoritative primary; ignored files protected')
     assert hashlib.sha256(lease_path.read_bytes()).hexdigest()==original_hash
     os.replace(lease_path,archive/f'wt{n}-lease-retired.json')
     assert hashlib.sha256((archive/f'wt{n}-lease-retired.json').read_bytes()).hexdigest()==original_hash
     assert inv.lease(n,required=False) is None
     item['actions'].append('exact old lease archived atomically under explicit operator authority; no owner-ended claim or forged state')
     item.update(new_head=git('rev-parse','HEAD',cwd=worktree),dirty=ctl._dirty(worktree),lease_removed=True)
     save()
 receipt['manual_recovery_complete']=True
 receipt['finished_at']=datetime.now(timezone.utc).isoformat();save()
 print(json.dumps({'manual_recovery_complete':True,'archive':str(archive),'base':base_sha,'slots':[{'slot':i['slot'],'new_head':i['new_head'],'lease_removed':i['lease_removed'],'dirty':i['dirty']} for i in receipt['slots']]}))
except BaseException as e:
 receipt['error']=repr(e);receipt['finished_at']=datetime.now(timezone.utc).isoformat();save();raise
