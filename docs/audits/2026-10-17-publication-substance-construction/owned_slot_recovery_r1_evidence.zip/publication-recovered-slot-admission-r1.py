from pathlib import Path
from datetime import datetime,timezone
import sys,json,subprocess,os
primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
os.chdir(primary);sys.path.insert(0,str(primary/'scripts'))
from lean_slots.state import Inventory
from lean_slots.controller import Controller
from lean_slots.supervisor import Supervisor
inv=Inventory.load(primary/'config/lean-slots.public.json');ctl=Controller(inv);sup=Supervisor(inv)
archive=primary/'.codex/continuity/publication-owned-slot-recovery-20261106-r1'
receipt={'scope':'Existing native admission validation only, no scientific source edits or task grants','started_at':datetime.now(timezone.utc).isoformat(),'slots':[]}
out=archive/'native-admission.json'
def save():out.write_text(json.dumps(receipt,indent=2)+'\n')
base_ref=subprocess.check_output(['git','branch','--show-current'],text=True).strip()
assert base_ref=='codex/publication-primary-custody-20261105'
try:
 for n in (2,3):
  item={'slot':n,'steps':[]};receipt['slots'].append(item);save()
  print('wt'+str(n)+': start existing proxy',flush=True)
  sup.start_proxy(n);item['steps'].append('proxy started through existing guarded lifecycle');save()
  lease=ctl.acquire(n,client='codex',base_ref=base_ref);item['acquired']=lease;save()
  print('wt'+str(n)+': acquired; prepare matching epoch',flush=True)
  prepared=ctl.prepare(n);item['prepared']=prepared;save()
  print('wt'+str(n)+': actual native MCP probe',flush=True)
  probe=sup.probe(n,client='codex');item['native_probe']=probe;save()
  assert probe['active_dispatch'] is True and not probe['lean_build_exposed']
  assert not ctl._dirty(inv.worktree(n))
  ctl.release(n);assert inv.lease(n,required=False) is None
  item['released']=True;item['dirty']=ctl._dirty(inv.worktree(n));save()
  print('wt'+str(n)+': native dispatch passed and normal release completed',flush=True)
 status=ctl.status();(archive/'native-final-status-local.json').write_text(json.dumps(status,indent=2)+'\n')
 assert status['capacity_complete'] and not status['capacity_errors'] and not status['capacity_conflicts']
 for n in (2,3):
  s=next(s for s in status['slots'] if s['slot']==n)
  assert s['lease'] is None and not s['dirty'] and s['backend_state']=='down' and not s['resource_reserved']
 receipt['final_public_readback']={'capacity_complete':True,'capacity_errors':[],'capacity_conflicts':[],'global_running_backends':status['global_running_backends'],'slots':[{'slot':s['slot'],'head':s['head'],'lease':s['lease'],'dirty':s['dirty'],'backend':s['backend_state'],'proxy':s['proxy_state'],'resource_reserved':s['resource_reserved']} for s in status['slots']]}
 receipt['passed']=True;receipt['finished_at']=datetime.now(timezone.utc).isoformat();save()
 print(json.dumps(receipt['final_public_readback']),flush=True)
except BaseException as e:
 receipt['error']=repr(e);receipt['finished_at']=datetime.now(timezone.utc).isoformat();save();raise
