from collections import Counter
from fractions import Fraction
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

author = Path('/private/tmp/l1-c0-case39.O6qZik')
prior = Path('/private/tmp/l1-c0-case18.szXdBy')
for name in ('exact-multicut.py','reduce-label-frontier.py','contract-reduced-label.py',
             'contract-peer.py','peer_pair.py','checkpoint/quotient.py'):
    assert (author/name).read_bytes() == (prior/name).read_bytes()
    print('matches previously replayed case 18 author script',name)
children = {i: pickle.loads((author/f'slice-{i}.pkl').read_bytes()) for i in range(9)}

def read_checkpoint(path, i):
    raw = path.read_bytes()
    state = pickle.loads(raw)
    for key in ('conditioning','label_partition'):
        assert state[key] == children[i][key]
    factors = state['factors']
    assert prod(d for _,_,d in factors) == 40512224221827380280140849737629696
    assert all(n==2 and a[0]!='L' for a,n in Counter(a for axes,_,_ in factors for a in axes).items())
    return state,sha256(raw).hexdigest()

seen = []
for log in sorted(author.glob('*-contract.out')):
    tag = log.name.removesuffix('-contract.out')
    tail = log.read_text().splitlines()[-1]
    snapshots = list(author.glob(f'*-dense-label-{tag}-reduced.pkl'))
    if tail.startswith('exact normalized '):
        assert not snapshots
        continue
    match = re.fullmatch(r'open (row|join) cap (\d+) (?:completed products )?(\d+) frontier saved',tail)
    assert match and len(snapshots)==1
    saved = snapshots[0]
    assert saved.name.startswith('row-cap-' if match[1]=='row' else 'join-cap-')
    i = int(tag.split('-')[1])
    state,digest = read_checkpoint(saved,i)
    assert len(state['factors']) == int(match[2])
    seen.append(saved.name)
    print('cap',i,tag,tail,saved.name,digest,sep='\t')
assert len(seen)==len(set(seen))==17
print('PASS 17 cap receipts match distinct frozen conditioned restart inputs')

closure = [tuple(map(int,line.split('\t'))) for line in (author/'shard-jobs.tsv').read_text().splitlines()]
assert len(closure)==32 and set(closure)=={(i,s,0) for i in (2,3,7,8) for s in range(8)}
for i in (2,3,7,8):
    triangle = i in (2,3)
    path = author/(f'join-cap-dense-label-rescue-{i}-1-reduced.pkl' if triangle
                   else f'row-cap-physical-slice-dense-label-rescue-{i}-0-reduced.pkl')
    state,digest = read_checkpoint(path,i)
    expected_length = len(state['factors'][0 if triangle else 1][1])
    denominator = prod(d for _,_,d in state['factors'])
    products, probes = [], []
    raw = [0,0]
    end = 0
    for shard in range(8):
        text = (author/f'slice-{i}-shard-{shard}.out').read_text()
        lo,hi,length,idx,count = map(int,re.search(r'^left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)',text,re.M).groups())
        assert lo==end and hi>lo and length==expected_length and idx==shard and count==8
        end = hi
        assert f"conditioning {state['conditioning']} label partition {state['label_partition']}" in text
        args = re.search(r'^closure products (\d+) retained outer matches (\d+) closure probes (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)',text,re.M)
        work,matched,p,re_num,im_num,den = map(int,args.groups())
        arithmetic = work + 2 * matched
        assert den==denominator and max(arithmetic,p)<=30_000_000
        products.append(arithmetic)
        probes.append(p)
        raw[0]+=re_num
        raw[1]+=im_num
        match = re.search(r'^exact normalized real (\S+) imaginary (\S+)(?: |$)',text,re.M)
        assert tuple(map(Fraction,match.groups())) == tuple(Fraction(n,den*16*4**64) for n in (re_num,im_num))
        if not triangle:
            assert 'left pair 1 3 ' in text
    assert end==expected_length
    summary = (author/f'slice-{i}-shard-sum.out').read_text()
    assert f'complete shards 8 left rows {end} raw {raw[0]} {raw[1]} factor denominator {denominator}' in summary
    assert f'maximum shard arithmetic {max(products)} maximum closure probes {max(probes)}' in summary
    match = re.search(r'^exact normalized real (\S+) imaginary (\S+)(?: |$)',summary,re.M)
    assert tuple(map(Fraction,match.groups())) == tuple(Fraction(n,denominator*16*4**64) for n in raw)
    print('PASS eight author shards full disjoint row coverage and exact raw sum',i,digest,end,*raw,'max products/probes',max(products),max(probes))
