# Independent verification of L1 N16 outer case 39

The review pins publication checkpoint cf1330a76 and the seven-factor
parent identified in next-frontiers/inputs.sha256 within
L1_N16_C0_CASES29_31_CLOSURE_R1.zip. The archive manifest verified.
The checked parent SHA256 is
43eeffa4069fae10da784823bb8474ab6c3b057c73a2134129792403a3b0c8b3.
The archived outer roster maps case 39 to (136, (2,)) on G(0,4,2) and
J(1,4,2), in the first binary child of tuple 0, descendant (0,0),
branch 128.

An independent histogram match on the rejected parent pair (0, 4)
regenerated the complete nine-value cut on G(0,1,2). The disjoint values
cover 2,001,024 matched pair products. Every nonzero complete network
summand must match that pair. Exact inverse lifts recover every compatible
parent row and Gaussian coefficient and preserve each factor denominator.
All terminal inputs retained complete conditioning and the label partition,
degree-two open axes and the positive denominator product.

| Slice | Cut value | Matched parent pair products | Independent normalized real |
|---|---:|---:|---:|
| 0 | 3 | 44,928 | -11110915873446200016345/2596148429267413814265248164610048 |
| 1 | 48 | 62,208 | -2011362180249495969/10141204801825835211973625643008 |
| 2 | 5 | 169,344 | -3451458467456410661775/162259276829213363391578010288128 |
| 3 | 12 | 169,344 | -33843346116668590909995/649037107316853453566312041152512 |
| 4 | 96 | 217,728 | -4663776247126866816363/324518553658426726783156020576256 |
| 5 | 144 | 217,728 | -4663776247126866816363/324518553658426726783156020576256 |
| 6 | 192 | 248,832 | 6720855919829297127/5070602400912917605986812821504 |
| 7 | 80 | 435,456 | -4480890652576321243803/649037107316853453566312041152512 |
| 8 | 160 | 435,456 | -4480890652576321243803/649037107316853453566312041152512 |

All imaginary parts are zero. The exact independent sum is
**-309249011481254844095997/2596148429267413814265248164610048 + 0i**.
Equal slice values retain distinct conditioned inputs and SHA256 identities.

Five direct sparse terminal replays passed. The two triangles in
slices 2 and 3 independently used pivot 1 in place of the author's
pivot 0. Each covers 18,643,968 matching triples and uses 18,752,832
Gaussian products, with at most 2,014,974 products in any shard.
The four-factor replays in slices 7 and 8 use initial pair (1,2),
with 7,892,640 candidate products, followed by closure on (0,3).
Each uses 23,812,992 Gaussian products across 15 shards, with at most
1,979,632 products per shard and 24,984 entries per block. The author
used initial pair (1,3). Both alternate orders agree with the author
raw numerators and normalized fractions. All independent arithmetic
uses the same factor denominator product
40512224221827380280140849737629696 and external normalization
1/(16*4^64), each applied once.

The author shard audit independently checked 32 successful receipts.
Each of the four sharded slices has eight disjoint author intervals
covering its complete pivot or left factor, and summed raw numerators
agree with the author summary and the full independent contraction.
The 17 generic cap refusals are bound to distinct frozen restart
states, including the later alternate capped attempts for slices 7
and 8. Intermediate lineage uses archived state and receipt checks
and byte identity of the common author scripts with the fully replayed
case 18 code. The new independent arithmetic qualifies case 39 and
its exact nine-term sum.
