# L1 N16 exact outer cases 37, 39 and 40

Scientific source 51e7c745e, publication parent cf1330a76. These are separate outer terms of the first binary child of tuple 0 in descendant (0,0). Restore the corresponding seven-factor parent `row-cap-physical-slice-dense-label-case-N-2-reduced.pkl` as described by `L1_N16_C0_CASES29_31_CLOSURE_R1.zip` under `next-frontiers`. The SHA256s for 37, 39 and 40 are `b571efd1666e1860baaccf4719be6d1a7e4e347a5721d443354a9ea8e108198c`, `43eeffa4069fae10da784823bb8474ab6c3b057c73a2134129792403a3b0c8b3` and `4d82c89992ed801f6db20472c122feac836dfc3e92cbfe7ba2ac480bb10f3923`. Deserialize only trusted checkpoint files.

From scratch seeded with the appropriate author folder:

```bash
python3 -u run-primary.py /absolute/path/to/restored-parent.pkl >slices.tsv
python3 -u reduce-open.py 0 1 2 3 4 5 6 7 8 >rescue.tsv
shasum -a 256 -c /absolute/path/to/archive/frontiersN.sha256
python3 -u run-final-shards.py >shard-jobs.tsv
python3 sum-caseN.py
```

Replace N with the case index. Triangles 2 and 3 and four-factor slices 7 and 8 each use eight disjoint author row intervals. The other five values close by direct or repeated support/quotient reduction. Independent evidence preserves alternate pivots and selected pairs, input bindings, and full exact shard checks. Recreate a duplicate named Git ZIP absent from a reviewer manifest from the original repository bytes by its recorded hash. See each `reviewN/REVIEW.md` for the precise lineage and evidence scope.

Run `python3 verify-cases.py 37 39 40` and `python3 retally-48.py 37 39 40` to reproduce the exact sum of the new term values and the updated partial total from the immutable 40-case ledger. Coincident term values have separate original input coordinates. The full signed coefficient and publication acceptance remain open.
