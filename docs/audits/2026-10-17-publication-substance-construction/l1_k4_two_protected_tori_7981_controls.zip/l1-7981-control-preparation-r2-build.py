from pathlib import Path
import ast,json,hashlib
P=Path('/tmp');stem='l1-7981-control-preparation-r2';A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
source=P/'l1-7981-evaluator-draft-r1.py';assert hashlib.sha256(source.read_bytes()).hexdigest()=='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
t=ast.parse(source.read_text());f=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='source_hashes');names=next(ast.literal_eval(n.value) for n in ast.walk(f) if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='names' for v in n.targets))
binding={n+'.py':hashlib.sha256((A/(n+'.py')).read_bytes()).hexdigest() for n in names};assert len(binding)==16
(P/(stem+'-binding.json')).write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'principal_source_sha256':binding},indent=2)+'\n')
header='''from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product,combinations
from functools import cache
from math import prod
import runpy,json,hashlib,signal,time
P=Path('/tmp');A=Path(%r)
SOURCE=P/'l1-7981-evaluator-draft-r1.py';EXPECTED='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
BINDING=%r

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bound():
 assert sha(SOURCE)==EXPECTED
 assert len(BINDING)==16 and all(sha(A/n)==h for n,h in BINDING.items())
def emit(kind,**v):print(json.dumps(dict(kind=kind,**v),sort_keys=True),flush=True)
'''%(str(A),binding)
fixed=header+'''
# Prepared only: ROOT admission and independent source review precede execution.
start=time.perf_counter();signal.alarm(600);bound()
emit('phase-start',phase='cold-fixed79-preparation',word=79,scope='FIXED-gamma ONLY',hard_limit_seconds=600,source_sha256=EXPECTED,principal_source_sha256=BINDING)
s=runpy.run_path(str(SOURCE),run_name='author_fixed79_controls');k2,k3=s['k2'],s['k3'];row,g=s['data']()[79]
assert k2.ROW_CAP==120000 and k2.PAIR_CAP==3000000
assert len(g.edges)==20 and not g.joined_source and len(g.forest)==4 and g.fixed_sources==set(g.sources)=={(0,2),(1,2)}
assert g.divisor==192**42*4**64*48**6*2**15
restrict=dict.fromkeys(g.frame,k3.witness.FIXED_GAMMAS);assert len(restrict)==15
square,=g.squares;comp_domain=sorted({c for c,p in k3.square_factor(square,g.lives[0],g.fixed_square[square])})
branches=list(s['branches'](g));assert len(branches)==225 and sum(w<0 for w,c in branches)==52
prepared=[];support=[]
for b,(weight,core) in enumerate(branches):
 assert len(core)==8 and square[0] not in core
 p=s['prepare'](g,core,restrict);prepared.append((weight,p));centers=[];empty=[]
 for ci,(q,axes) in enumerate(sorted(g.frame.items())):
  expected={}
  for comp in (comp_domain if q==square[0] else (None,)):
   w=k3.witness.center_weights((comp,) if q==square[0] else core.get(q)).get(restrict[q],0)
   if w:expected[restrict[q]+((comp,) if q==square[0] else ())]={0:(w,0)}
  if not expected:empty.append(q)
  if p is not None:assert p[0][ci][1]==expected
  centers.append({'center':q,'selector':'square_component' if q==square[0] else 'protected_torus' if q in core else 'peeled','rows':[{'labels':k,'weight':v[0][0]} for k,v in sorted(expected.items())]})
 audit=None
 if p is not None:
  factors,divisor,exclusive=p;counts=Counter(k for keys,rs,ds in factors for k in keys);degrees={q:sum(ds.get(q,0) for ks,rs,ds in factors) for q in range(16)}
  assert divisor==g.divisor and len(factors)==38 and len(counts)==32 and set(counts.values())=={2} and degrees==dict.fromkeys(range(16),8)
  source_factors=[]
  for label,(keys,rows,degs) in zip(g.sources,factors[-2:],strict=True):
   assert keys==();source_factors.append({'source':label,'degrees':degs,'polynomial':[{'mask':m,'real':v[0],'imag':v[1]} for m,v in sorted(rows[()].items())]})
  audit={'factors':38,'labels':32,'all_labels_twice':True,'site_degrees':degrees,'source_factors':source_factors,'factor_row_slots':[sum(map(len,rs.values())) for ks,rs,ds in factors]}
 support.append({'branch':b,'source0_branch':b//15,'source1_branch':b%15,'weight':[weight.numerator,weight.denominator],'core_domains':sorted(core.items()),'center_support':centers,'empty_center_sites':empty,'structural_empty_preparation':p is None,'prepared_graph':audit})
assert len(prepared)==225
metadata=s['describe'](row,g);live=metadata['live_action_routing'];fixed=metadata['fixed_action_routing']
assert live['physical_anchor']==1 and live['labels'][0]['frame_gamma_slot']==1 and live['labels'][0]['center_flag']==0
assert sorted((x['labels'][0]['frame_gamma_slot'],x['labels'][0]['center_flag'],x['physical_anchor']) for x in fixed)==[(1,0,1),(1,1,0)]
prep=time.perf_counter()-start
emit('phase-complete',phase='cold-fixed79-preparation',word=79,branches=225,seconds=prep,restrictions=sorted(restrict.items()),support_domains=support,geometry=metadata,divisor=g.divisor,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP)
signal.alarm(60);warm=time.perf_counter();emit('phase-start',phase='warm-WHOLE225-fixed79-contraction',word=79,hard_limit_seconds=60)
# Exactly the retained tables, without any second prepare/solve call.
total,peak=s['contract_prepared'](prepared,g.divisor,lambda r:emit('exact-fixed-branch',word=79,**r))
warm_seconds=time.perf_counter()-warm;raw=total*g.divisor;assert raw.denominator==1;bound();signal.alarm(0)
emit('exact-fixed-word',word=79,scope='FIXED-gamma ONLY; unrestricted NOTRUN',branches=225,coefficient=[total.numerator,total.denominator],raw_numerator=raw.numerator,divisor=g.divisor,peak_rows=peak,preparation_seconds=prep,whole225_warm_seconds=warm_seconds,full_seconds=time.perf_counter()-start,source_sha256=EXPECTED)
'''
(P/(stem+'-fixed79-runner.py')).write_text(fixed)
# Reuse accepted independent quaternion Haar reference definitions, not its execution.
ref=(P/'l1-110153-review-reference.py').read_text();ast.parse(ref)
(P/(stem+'-quaternion-reference.py')).write_text(ref)
direct=header+'''
# No factor preparation or scalar contraction in this direct worker.
start=time.perf_counter();signal.alarm(600);bound()
emit('direct-start',source_sha256=EXPECTED,principal_source_sha256=BINDING,scope='DIRECT79/81 ONLY; no prepared factors or scalar contractions')
s=runpy.run_path(str(SOURCE),run_name='author_7981_direct');k2,k3=s['k2'],s['k3'];found=s['data']();assert tuple(found)==(79,81)
from l1_direct_b_haar import R,add,scale,wedge,bilinear,diag,gamma
from l1_extended_opposed_source import frame,action_frame
from l1_extended_two_mixed_centers import remap
from l1_normalization_disjoint_sector import quat
from l1_normalization_opposed_fourth import nodes
from l1_extended_offset_square import cubature_edge
from l1_extended_mixed_curvature_core import conditional,face_vector
from l1_extended_mixed_center_gamma import COMPONENTS
from l1_normalization_uniform_mixed_edge import unit
REFERENCE=P/'l1-7981-control-preparation-r2-quaternion-reference.py'
assert sha(REFERENCE)==%r
exec(compile(REFERENCE.read_text(),str(REFERENCE),'exec'))
pairs=tuple((a,b) for a in range(8) for b in range(a,8))
ident=frame(0,False,unit(0),unit(0));src=scale(add(*(wedge(v,v) for v in ident)),192)
assert src==add(*(k3.witness.anchored(0,(),None,j) for j in range(4)))
for j in range(4):assert k3.witness.anchored(0,(),None,j)==scale(wedge(ident[j],ident[j]),192)
q4=(F(1,2),)*4;q4s=(F(1,2),F(-1,2),F(1,2),F(-1,2));q34=(F(3,5),F(4,5),F(),F());q34p=(F(),F(3,5),F(),F(-4,5))
samples=[(unit(i),unit(j)) for i,j in product(range(4),repeat=2)]+[(q4,q4s),(q4s,q4),(q34,q34p),(q34p,q4),(q4,tuple(-x for x in q4s))]
patterns=[((0,0),)*4,((0,0),(3,3),(0,0),(0,0)),((0,1),(0,1),(0,0),(0,0)),((1,2),(1,2),(0,0),(3,3)),((0,0),(0,0),(3,3),(3,3)),((3,4),(3,4),(3,3),(3,3)),((0,3),(0,3),(0,0),(0,0))]
for word,(row,g) in found.items():
 square,=g.squares;live,=g.lives;fixed=g.fixed_square[square];rows=k3.square_factor(square,live,fixed);offdiag=0
 for left,right in samples:
  coords={**fixed,live:(left,right)};q=left+right
  for labels in COMPONENTS:
   direct=prod(vector(square,coords,l) for l in labels)
   assert direct==prod(face_vector(square,coords,*divmod(l,3)) for l in labels)==sum(w*q[a]*q[b] for (c,(a,b)),w in rows.items() if c==labels)
   offdiag+=sum(bool(w*q[a]*q[b]) and a!=b for (c,(a,b)),w in rows.items() if c==labels)
 assert offdiag>0
 branches=list(s['branches'](g));assert len(branches)==225 and sum(w<0 for w,c in branches)==52
 tables=[];facelabels=[]
 for torus in g.tori:
  tb=list(k2.protected_branches(torus.linked,torus.other));assert len(tb)==15
  values=[];maps=[]
  for pattern in patterns:
   mapping=dict(zip(torus.linked+torus.other,pattern,strict=True));labels={f:mapping[f[0]] for f in torus.faces};fixed_t={torus.fixed_source:(unit(0),unit(0))}
   direct=independent_integral(torus.faces,fixed_t,labels,F(1));assert direct==conditional(torus.faces,{torus.fixed_source},fixed_t,labels)==k2.formula(tb,mapping)
   values.append(direct);maps.append(labels)
  tables.append(values);facelabels.append(maps)
 for i,j in product(range(7),repeat=2):
  mapping={f[0]:v for f,v in (facelabels[0][i]|facelabels[1][j]).items()}
  assert k2.formula(branches,mapping)==tables[0][i]*tables[1][j]
 for i,j in ((0,0),(1,4),(2,2),(3,4),(4,1),(5,5),(6,6)):
  allfaces=g.tori[0].faces|g.tori[1].faces;labels=facelabels[0][i]|facelabels[1][j]
  sq_labels=(0,1) if i%%2 else (0,3);coords={**fixed,live:(q4,q4s)};scalar=prod(vector(square,coords,l) for l in sq_labels)
  allfixed={t.fixed_source:(unit(0),unit(0)) for t in g.tori}
  assert independent_integral(allfaces,allfixed,labels,scalar)==scalar*tables[0][i]*tables[1][j]
 # Joint F4 has two physical components. Seed each component independently.
 allfaces={square:set(fixed)|{live},**g.tori[0].faces,**g.tori[1].faces};edges=set.union(*allfaces.values())|g.forest
 coords={e:samples[16+i%%5] for i,e in enumerate(sorted(edges))};gauges={};pending=set(g.forest);components=0
 while pending:
  reachable=[e for e in sorted(pending) if e[0] in gauges or (e[0]^(1<<e[1])) in gauges]
  if not reachable:
   e=min(pending);gauges[e[0]]=(q4s,q34) if components else (unit(0),unit(0));components+=1
  else:e=reachable[0]
  q,a=e;y=q^(1<<a)
  if q in gauges:
   assert y not in gauges;gauges[y]=tuple(mul(gauges[q][ch],adj(coords[e][ch])) for ch in (0,1))
  else:gauges[q]=tuple(mul(gauges[y][ch],coords[e][ch]) for ch in (0,1))
  pending.remove(e)
 assert components==2
 for q in range(16):gauges.setdefault(q,(q4s,q34))
 transformed={e:tuple(mul(mul(gauges[e[0]^(1<<e[1])][ch],coords[e][ch]),adj(gauges[e[0]][ch])) for ch in (0,1)) for e in edges}
 assert len(g.forest)==4 and all(transformed[e]==(unit(0),unit(0)) for e in g.forest)
 for face in allfaces:
  for ch in (0,1):assert hol(face,transformed,ch)==mul(mul(gauges[face[0]][ch],hol(face,coords,ch)),adj(gauges[face[0]][ch]))
 # Complete BOTH source degree-four polynomials before and after gauge fixing.
 # Pull transformed endpoint Grassmann variables back by their actual site rotations.
 for q,a in g.sources:
  y=q^(1<<a);sx=diag(*(quat(z) for z in gauges[q]));sy=diag(*(quat(z) for z in gauges[y]));sxdag=diag(*(quat(adj(z)) for z in gauges[q]));sydag=diag(*(quat(adj(z)) for z in gauges[y]))
  u=diag(*(quat(z) for z in transformed[q,a]));ud=diag(*(quat(adj(z)) for z in transformed[q,a]));v=diag(*(quat(z) for z in coords[q,a]));vd=diag(*(quat(adj(z)) for z in coords[q,a]))
  matrices=[(ga*vd,v*ga,sxdag*ga*ud*sy,sydag*u*ga*sx) for ga in gamma]
  # Integer coefficient ring: clear one common denominator before both degree-four polynomials.
  from math import lcm
  denominator=1
  for group in matrices:
   for matrix in group:
    for coefficient in matrix:
     for part in coefficient.expand().as_real_imag():denominator=lcm(denominator,int(part.as_numer_denom()[1]))
  old=[add(bilinear(a*denominator,0,1),scale(bilinear(b*denominator,1,0),-1)) for a,b,c,d in matrices]
  pulled=[add(bilinear(c*denominator,0,1),scale(bilinear(d*denominator,1,0),-1)) for a,b,c,d in matrices]
  assert add(*(wedge(t,t) for t in old))==add(*(wedge(t,t) for t in pulled))
  assert remap(src,(q,y))==remap(scale(add(*(wedge(v,v) for v in ident)),192),(q,y))
 emit('joint-F4-direct',word=word,forest_edges=4,forest_components=2,all16_site_rotations=True,both_nonidentity_source_polynomials_covariant=True,all9_face_holonomies_covariant=True,torus_direct_patterns=14,cartesian225_checks=49,disconnected_nineface_closures=7,square_samples=21,square_components=21,activated_offdiag_terms=offdiag)
# Actual singleton orientations; first and second gamma pairs are deliberately distinguishable.
for center,anchor in ((1,0),(0,1)):
 for labels in ((0,0),(0,1),(1,2),(2,3)):
  assert k3.fixed_action_edge((labels,),(center,),anchor)==cubature_edge((labels,),(center,),anchor)
emit('singleton-fixed-edge-direct',actual_orientations=[[1,0],[0,1]],gamma_cases=4,full_polynomial_equalities=8)
rule=tuple(nodes());nonzero=0;zero=0
for labels,probe in product(((0,0),(0,1),(1,2)),((1,1),(1,2),(1,5))):
 center=0;anchor=1;terms=[]
 for n in (0,2):
  for chosen in combinations(range(2),n):
   chunks=tuple(tuple(labels[i] for i in range(2) if (i in chosen)==(a==0)) for a in (0,1));factors=[]
   for local,chunk in enumerate(chunks):
    vals=[]
    for left,right,weight in rule:
     t=action_frame(0,local^center,left,right);poly={0:R.one}
     for j in chunk:poly=wedge(poly,t[j])
     qq=left+right;extra=qq[probe[0]]*qq[probe[1]] if local==anchor else 1;vals.append(scale(poly,weight*extra))
    factors.append(add(*vals))
   terms.append(wedge(*factors))
 direct=add(*terms);assert direct==scale(k3.probed_action_edge(labels,center,anchor,probe),4);nonzero+=bool(direct);zero+=not bool(direct)
emit('live-singleton-direct',center=0,physical_anchor=1,global_frame_slot=1,edge_local_slot=0,equalities=9,nonzero=nonzero,zero=zero,offdiagonal_probes=[[1,2],[1,5]])
bound();signal.alarm(0);emit('direct-controls-complete',seconds=time.perf_counter()-start,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP,factor_preparations_run=0,fixed_scalar_replays_run=0,unrestricted_coefficients_run=0,source_sha256=EXPECTED)
'''%hashlib.sha256(ref.encode()).hexdigest()
(P/(stem+'-direct-runner.py')).write_text(direct)
for mode in ('fixed79','direct'):
 runner=P/(stem+'-'+mode+'-runner.py');rsha=hashlib.sha256(runner.read_bytes()).hexdigest();prefix=str(P/(stem+'-'+mode))
 driver='''"""Prepared only. ROOT admission must precede this scientific subprocess."""
import subprocess,time,json,hashlib
from pathlib import Path
RUNNER=Path(%r);EXPECTED_RUNNER_SHA256=%r
PREFIX=%r
EXECUTABLE='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
def main():
 start=time.perf_counter();outpath=Path(PREFIX+'.out');errpath=Path(PREFIX+'.err');exitpath=Path(PREFIX+'.exit.json')
 assert hashlib.sha256(RUNNER.read_bytes()).hexdigest()==EXPECTED_RUNNER_SHA256
 if any(p.exists() for p in (outpath,errpath,exitpath)):raise FileExistsError('Preserve original attempt streams')
 command=[EXECUTABLE,'-B',str(RUNNER)];timeout=False
 with outpath.open('xb') as out,errpath.open('xb') as err:
  process=subprocess.Popen(command,stdout=out,stderr=err)
  try:child_exit=process.wait(timeout=665)
  except subprocess.TimeoutExpired:timeout=True;process.kill();child_exit=process.wait()
 driver_exit=124 if timeout else (0 if child_exit==0 else 1);records=[];bad=0
 for line in outpath.read_text(errors='replace').splitlines():
  try:records.append(json.loads(line))
  except ValueError:bad+=1
 receipt={'actual_child_exit_code':child_exit,'driver_exit_code':driver_exit,'parent_timeout':timeout,'parent_seconds':time.perf_counter()-start,'cold_limit_seconds':600,'whole225_fixed_warm_limit_seconds':%r,'parent_wall_limit_seconds':665,'command':command,'runner_sha256':EXPECTED_RUNNER_SHA256,'source_sha256':'e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7','complete_raw_branch_records':sum(r.get('kind')=='exact-fixed-branch' for r in records),'last_complete_record_kind':records[-1].get('kind') if records else None,'truncated_or_nonJSON_lines':bad,'scope':%r}
 exitpath.write_text(json.dumps(receipt,sort_keys=True)+'\\n');print(json.dumps(receipt),flush=True);return driver_exit
if __name__=='__main__':raise SystemExit(main())
'''%(str(runner),rsha,prefix,60 if mode=='fixed79' else None,'FIXED79 ONLY; unrestricted NOTRUN' if mode=='fixed79' else 'DIRECT79/81 ONLY; no factor preparation or scalar contraction')
 (P/(stem+'-'+mode+'-driver.py')).write_text(driver)
