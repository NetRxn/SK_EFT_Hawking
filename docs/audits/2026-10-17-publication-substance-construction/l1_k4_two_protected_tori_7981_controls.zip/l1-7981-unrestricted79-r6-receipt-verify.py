from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path('/tmp');pre='l1-7981-unrestricted79-r6';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths=[P/(pre+s) for s in ('.out','.err','.exit.json')];out,err,ep=paths;rs=[json.loads(l) for l in out.read_text().splitlines()];e=json.loads(ep.read_text())
assert e['actual_child_exit_code']==e['driver_exit_code']==0 and not e['parent_timeout'] and not err.read_bytes() and e['complete_raw_branch_records']==225 and e['truncated_or_nonJSON_lines']==0
assert e['cold_limit_seconds']==600 and e['whole225_warm_limit_seconds']==60 and e['parent_wall_limit_seconds']==665 and e['parent_seconds']<665
prep=next(r for r in rs if r['kind']=='phase-complete');bs=[r for r in rs if r['kind']=='exact-branch'];last=rs[-1];supports=prep['support_domains'];D=192**42*4**64*48**6*2**15
assert len(bs)==len(supports)==225 and prep['branches']==last['branches']==225 and last['word']==79 and last['scope']=='Complete selected unrestricted word79' and last['restrictions']==prep['restrictions']==rs[0]['restrictions']=={} and prep['divisor']==last['divisor']==D and prep['row_cap']==120000 and prep['pair_cap']==3000000
nonempty=empty=zero=0;total=F();minimum_center_domain=None
for i,(b,s) in enumerate(zip(bs,supports,strict=True)):
 assert b['branch']==s['branch']==i and b['word']==79 and b['weight']==s['weight'] and b['divisor']==D and F(*b['coefficient'])==F(b['raw_numerator'],D) and b['algebraic_empty_preparation']==s['structural_empty_preparation']
 total+=F(*b['weight'])*F(*b['coefficient'])
 if s['structural_empty_preparation']:empty+=1;assert b['raw_numerator']==b['peak_rows']==0
 else:
  nonempty+=1;a=s['prepared_graph'];assert a['factors']==38 and a['labels']==32 and a['all_labels_twice'] and {int(q):v for q,v in a['site_degrees'].items()}==dict.fromkeys(range(16),8) and len(a['source_factors'])==2 and len(a['center_support'])==15
  for c in a['center_support']:
   assert c['rows'];n=len(c['rows']);minimum_center_domain=n if minimum_center_domain is None else min(minimum_center_domain,n)
  zero+=b['raw_numerator']==0
assert total==F(*last['coefficient'])==F(last['raw_numerator'],D) and last['peak_rows']==max(b['peak_rows'] for b in bs) and last['preparation_seconds']<600 and last['whole225_warm_seconds']<60 and sum(F(*b['weight'])<0 for b in bs)==52
binding=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text());A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');assert all(sha(A/n)==h for n,h in binding['principal_source_sha256'].items()) and sha(P/'l1-7981-evaluator-draft-r1.py')==binding['source_sha256']
fixed=json.loads((P/'l1-7981-fixed81-r4-transpose-verification.json').read_text());assert all(sha(Path(n))==h for n,h in fixed['original_stream_sha256'].items())
r={'scope':'Author selected unrestricted79 pilot only; independent acceptance pending; no81/class/portable acceptance','actual_handle':15754,'actual_driver_exit':0,'actual_child_exit':0,'branches':225,'nonempty_prepared':nonempty,'structural_empty':empty,'computed_raw_zero_nonempty':zero,'negative_weights':52,'coefficient':last['coefficient'],'raw_numerator':last['raw_numerator'],'divisor':D,'peak_rows':last['peak_rows'],'cold_seconds':last['preparation_seconds'],'whole225_warm_seconds':last['whole225_warm_seconds'],'parent_seconds':e['parent_seconds'],'all225_raw_weight_divisor_final_equalities':True,'all_nonempty_38factor_32label_twice_degree8at16site_graphs':True,'restrictions':{},'minimum_prepared_center_row_count':minimum_center_domain,'source_sha256':binding['source_sha256'],'runner_sha256':sha(P/(pre+'-runner.py')),'driver_sha256':sha(P/(pre+'-driver.py')),'principal16_binding_unchanged':True,'all6_fixed_original_streams_unchanged':True,'original_receipt_sha256':{str(p):sha(p) for p in paths},'limits':{'cold':600,'WHOLE225warm':60,'parent':665,'row':120000,'pair':3000000},'fallback_zeros':False,'81_replay_portability':'NOT RUN'}
(P/(pre+'-receipt-verification.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
