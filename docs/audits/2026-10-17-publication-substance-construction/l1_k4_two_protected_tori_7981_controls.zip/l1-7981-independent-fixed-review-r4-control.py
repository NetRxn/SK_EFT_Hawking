"""PREPARED ONLY: ROOT admission required. Both450 fixed prepared graphs; NO scalar contractions."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
from itertools import product,combinations,combinations_with_replacement
from functools import cache
import runpy,hashlib,json,signal,time
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
SOURCE=P/'l1-7981-evaluator-draft-r1.py';EXPECTED='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(kind,**data):print(json.dumps(dict(kind=kind,**data),sort_keys=True),flush=True)
BINDING=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text())['principal_source_sha256']
def bound():
 assert sha(SOURCE)==EXPECTED and len(BINDING)==16
 assert all(sha(A/n)==h for n,h in BINDING.items())
start=time.perf_counter();signal.alarm(600);bound();emit('independent450-start',source_sha256=EXPECTED,principal_source_sha256=BINDING,inner_limit=600,scalar_contractions_run=0)
s=runpy.run_path(str(SOURCE),run_name='independent_7981_originalL_prepared');k2,k3=s['k2'],s['k3'];found=s['data']();assert list(found)==[79,81] and k2.ROW_CAP==120000 and k2.PAIR_CAP==3000000
from l1_direct_b_haar import R,add,scale,wedge
from l1_extended_opposed_source import frame,action_frame
from l1_normalization_opposed_fourth import nodes,L
from l1_normalization_uniform_mixed_edge import unit
# Independent quaternion polynomial reference, bound before executing function definitions only.
REFERENCE=P/'l1-7981-control-preparation-r2-quaternion-reference.py'
assert sha(REFERENCE)=='3520188b78f838b475814949104c8c64dc3c5dd3cff2ff57ba93024bdc642059'
# Select only mul/adj/hol/vector; no moments or reference eliminations are needed here.
import ast
rt=ast.parse(REFERENCE.read_text());exec(compile(ast.Module(body=[n for n in rt.body if isinstance(n,ast.FunctionDef) and n.name in ('mul','adj','hol','vector')],type_ignores=[]),str(REFERENCE),'exec'))
@cache
def original_weights(domain):
 out=Counter()
 for a,b,c,d in product(range(4),repeat=4):
  for i,u in L[a,c]:
   for j,v in L[b,d]:out[tuple(sorted((a,b))),tuple(sorted((c,d)))]+=u*v*(12*int(i==j) if domain is None else int(tuple(sorted((i,j))) in domain))
 return {k:v for k,v in out.items() if v}
def gaussian(poly,divisor=1):
 out={}
 for mask,v in poly.items():
  assert v.is_ground;re,im=int(v.const().x),int(v.const().y);assert re%divisor==im%divisor==0
  if re or im:out[mask]=(re//divisor,im//divisor)
 return out
def relocate(poly,sites):
 # Geometric local row relocation uses existing even-degree local convention.
 return {sum(((m>>(8*i))&255)<<(8*q) for i,q in enumerate(sites)):v for m,v in poly.items()}
@cache
def old_frame(anchor,center,left,right):
 t=action_frame(0,anchor^center,left,right)
 if center:return tuple(scale(relocate(v,(1,0)),-1) for v in t)
 return tuple(t)
RULE=tuple(nodes())
@cache
def anchor_integral(anchor,slots,fixed,probe):
 rule=(((2,0,0,0),(2,0,0,0),96),) if fixed else RULE;vals=[]
 for left,right,weight in rule:
  v={0:R.one}
  for center,gamma in slots:v=wedge(v,old_frame(anchor,center,tuple(left),tuple(right))[gamma])
  coords=tuple(left)+tuple(right);vals.append(scale(v,weight*(coords[probe[0]]*coords[probe[1]] if probe is not None else 1)))
 return add(*vals)
@cache
def edge_reference(labels,centers,fixed_anchor,probe_anchor,probe):
 slots=tuple((center,j) for center,pair in zip(centers,labels,strict=True) for j in pair);terms=[]
 for n in range(0,len(slots)+1,2):
  for chosen in combinations(range(len(slots)),n):
   terms.append(wedge(*(anchor_integral(a,tuple(slots[i] for i in range(len(slots)) if (i in chosen)==(a==0)),a==fixed_anchor,probe if a==probe_anchor else None) for a in (0,1))))
 # Original rule weights96 per anchor and reps2q vs canonical192 per anchor.
 # d raw coframes, and two additional quaternion powers for a probe.
 ratio=2**(len(slots)+(2 if probe is not None else 0)-2)
 assert ratio in (1,4);return gaussian(add(*terms),ratio)
@cache
def square_reference(square,live,fixed_items):
 fixed=dict(fixed_items);rows={};components=tuple(combinations_with_replacement(range(6),2));probes=tuple(combinations_with_replacement(range(8),2))
 for comp in components:
  def evalq(q):return vector(square,{**fixed,live:(q[:4],q[4:])},comp[0])*vector(square,{**fixed,live:(q[:4],q[4:])},comp[1])
  values={i:evalq(tuple(int(k==i) for k in range(8))) for i in range(8)}
  for a,b in probes:
   v=values[a] if a==b else evalq(tuple(int(k==a)+int(k==b) for k in range(8)))-values[a]-values[b]
   if v:rows[comp,(a,b)]=v
 return rows
identity=frame(0,False,unit(0),unit(0));source_ref=gaussian(scale(add(*(wedge(v,v) for v in identity)),192))
def reconstruct(g,core):
 square,=g.squares;live,=g.lives;sq=square_reference(square,live,tuple(sorted(g.fixed_square[square].items())));assert sq==k3.square_factor(square,live,g.fixed_square[square]);comps=sorted({comp for comp,p in sq});gamma=((0,0),(1,1));factors=[];empty_center=False
 for q,axes in sorted(g.frame.items()):
  rows={}
  for comp in comps if q==square[0] else (None,):
   domain=(comp,) if comp is not None else core.get(q);key=None if domain is None else tuple(domain);w=original_weights(key)
   assert w==k3.witness.center_weights(domain)
   if w.get(gamma):rows[gamma+((comp,) if comp is not None else ())]={0:(w[gamma],0)}
  if not rows:empty_center=True
  factors.append((tuple((q,a) for a in axes)+((('square',0,'component'),) if q==square[0] else ()),rows,{}))
 if empty_center:return None
 liveedge=min(live[0],live[0]^(1<<live[1])),max(live[0],live[0]^(1<<live[1])),live[1]
 changed=set(g.fixed_edges)|{liveedge};exclusive={key for e,keys in g.edges.items() if len(keys)==1 and e not in changed for key in keys}
 for edge,keys in sorted(g.edges.items()):
  lo,hi,axis=edge;labels=tuple(gamma[g.frame[q].index(a)] for q,a in keys);centers=tuple(int(q==hi) for q,a in keys);rows={}
  for probe in sorted({p for comp,p in sq}) if edge==liveedge else (None,):
   local=edge_reference(labels,centers,g.fixed_edges.get(edge),int(live[0]==hi) if probe is not None else None,probe)
   if local:rows[labels+((probe,) if probe is not None else ())]=relocate(local,(lo,hi))
  if not rows:return None
  factors.append((tuple(keys)+((('square',0,'probe'),) if edge==liveedge else ()),rows,{lo:2*len(keys),hi:2*len(keys)}))
 factors.append(((('square',0,'component'),('square',0,'probe')),{key:{0:(v,0)} for key,v in sq.items()},{}))
 for q,a in g.sources:factors.append(((),{():relocate(source_ref,(q,q^(1<<a)))},{q:2,q^(1<<a):2}))
 return factors,g.divisor,exclusive

def shifted(poly):
 result={}
 for mask,(re,im) in poly.items():
  sign=(-1)**sum(((mask>>(8*q))&255).bit_count()*((mask>>(8*(q^1)))&255).bit_count() for q in range(0,16,2))
  m=sum(((mask>>(8*q))&255)<<(8*(q^1)) for q in range(16));result[m]=(sign*re,sign*im)
 return result

def normalize(factors):
 out=[]
 for keys,rows,degrees in factors:
  order=sorted(range(len(keys)),key=lambda i:repr(keys[i]));out.append((tuple(keys[i] for i in order),{tuple(labels[i] for i in order):poly for labels,poly in rows.items()},degrees))
 return sorted(out,key=lambda f:repr((f[0],sorted(f[2].items()))))

def translated(table):
 if table is None:return None
 factors,D,exclusive=table;out=[]
 for keys,rows,degrees in factors:
  newkeys=tuple((k[0]^1,k[1]) if isinstance(k[0],int) else k for k in keys)
  # Preserve key/row alignment here; normalize permutes both together.
  out.append((newkeys,{labels:shifted(poly) for labels,poly in rows.items()},{q^1:d for q,d in degrees.items()}))
 return normalize(out),D,{(q^1,a) for q,a in exclusive}
allprepared={};domains={}
for word,(row,g) in found.items():
 restrictions=dict.fromkeys(g.frame,((0,0),(1,1)));branches=list(s['branches'](g));assert len(branches)==225 and sum(w<0 for w,c in branches)==52;retained=[];nonempty=0
 for index,(weight,core) in enumerate(branches):
  expected=reconstruct(g,core);actual=s['prepare'](g,core,restrictions);assert actual==expected
  if actual is not None:
   nonempty+=1;factors,D,exclusive=actual;counts=Counter(k for keys,rs,ds in factors for k in keys);assert len(factors)==38 and len(counts)==32 and set(counts.values())=={2} and {q:sum(ds.get(q,0) for ks,rs,ds in factors) for q in range(16)}==dict.fromkeys(range(16),8)
  retained.append(actual)
 assert nonempty==25;allprepared[word]=retained;domains[word]=branches
 emit('independent225-prepared',word=word,branches=225,nonempty=25,structural_empty=200,all_original_L_and_full_rows_equal=True,scalar_contractions_run=0)
for i,j in product(range(15),repeat=2):
 a,b=15*i+j,15*j+i;wa,ca=domains[79][a];wb,cb=domains[81][b];assert wa==wb and {q^1:d for q,d in ca.items()}==cb
 ta=translated(allprepared[79][a]);raw=allprepared[81][b]
 tb=None if raw is None else (normalize(raw[0]),raw[1],raw[2]);assert ta==tb
bound();signal.alarm(0);emit('independent450-complete',branches=450,nonempty=50,structural_empty=400,all_centerweights_original_L=True,full_rows_original_cubature=True,source_square_rows_independent=True,transpose225_all_rows_signed_site_covariance=True,scalar_contractions_run=0,unrestricted_coefficients_run=0,seconds=time.perf_counter()-start,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP,source_sha256=EXPECTED)
