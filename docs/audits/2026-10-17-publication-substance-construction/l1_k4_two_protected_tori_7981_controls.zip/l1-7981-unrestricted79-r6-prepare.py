from pathlib import Path
import ast,hashlib,json,types
from fractions import Fraction
P=Path('/tmp');pre='l1-7981-unrestricted79-r6';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fixed=P/'l1-7981-control-preparation-r2-fixed79-runner.py';assert sha(fixed)=='1e3a15719d1522d0ed1f4004e4b4dfd680c35cff3a66374d5b4cec9a07fdc1d1'
header=fixed.read_text().split('# Prepared only:',1)[0]
r=header+'''
# Prepared only: ROOT nonauthor review and fresh runtime admission precede execution.
start=time.perf_counter();signal.alarm(600);bound()
RUNNER_SHA256=sha(Path(__file__))
emit('phase-start',phase='cold-unrestricted79-preparation',word=79,scope='Complete selected unrestricted word79',restrictions={},hard_limit_seconds=600,source_sha256=EXPECTED,runner_sha256=RUNNER_SHA256,principal_source_sha256=BINDING)
s=runpy.run_path(str(SOURCE),run_name='author_unrestricted79_pilot');k2,k3=s['k2'],s['k3'];row,g=s['data']()[79]
assert k2.ROW_CAP==120000 and k2.PAIR_CAP==3000000
assert len(g.edges)==20 and not g.joined_source and len(g.forest)==4 and g.fixed_sources==set(g.sources)=={(0,2),(1,2)}
assert len(g.frame)==15 and g.divisor==192**42*4**64*48**6*2**15
# Default restrict=None: prepare the complete225 tables exactly once.
prepared=s['prepare_branches'](g)
assert len(prepared)==225
branch_domains=list(s['branches'](g));assert len(branch_domains)==225 and sum(w<0 for w,c in branch_domains)==52
supports=[]
for b,((weight,p),(expected_weight,core)) in enumerate(zip(prepared,branch_domains,strict=True)):
 assert weight==expected_weight and len(core)==8 and g.squares[0][0] not in core
 audit=None
 if p is not None:
  factors,divisor,exclusive=p;counts=Counter(k for keys,rs,ds in factors for k in keys);degrees={q:sum(ds.get(q,0) for ks,rs,ds in factors) for q in range(16)}
  assert divisor==g.divisor and len(factors)==38 and len(counts)==32 and set(counts.values())=={2} and degrees==dict.fromkeys(range(16),8)
  center_support=[]
  for ci,(q,axes) in enumerate(sorted(g.frame.items())):
   keys,rows,ds=factors[ci]
   assert tuple(keys[:2])==tuple((q,a) for a in axes) and not ds
   center_support.append({'center':q,'axes':axes,'selector':'square_component' if q==g.squares[0][0] else 'protected_torus' if q in core else 'peeled','rows':[{'labels':k,'weight':v[0][0]} for k,v in sorted(rows.items())]})
  source_factors=[]
  for label,(keys,rows,degs) in zip(g.sources,factors[-2:],strict=True):
   assert keys==();source_factors.append({'source':label,'degrees':degs,'polynomial':[{'mask':m,'real':v[0],'imag':v[1]} for m,v in sorted(rows[()].items())]})
  audit={'factors':38,'labels':32,'all_labels_twice':True,'site_degrees':degrees,'source_factors':source_factors,'center_support':center_support,'factor_row_slots':[sum(map(len,rs.values())) for ks,rs,ds in factors]}
 supports.append({'branch':b,'source0_branch':b//15,'source1_branch':b%15,'weight':[weight.numerator,weight.denominator],'core_domains':sorted(core.items()),'structural_empty_preparation':p is None,'prepared_graph':audit})
metadata=s['describe'](row,g);assert metadata['live_action_routing']['physical_anchor']==1 and metadata['live_action_routing']['labels'][0]['frame_gamma_slot']==1
prep=time.perf_counter()-start
emit('phase-complete',phase='cold-unrestricted79-preparation',word=79,scope='Complete selected unrestricted word79',restrictions={},branches=225,seconds=prep,support_domains=supports,geometry=metadata,divisor=g.divisor,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP)
signal.alarm(60);warm=time.perf_counter();emit('phase-start',phase='warm-WHOLE225-unrestricted79-contraction',word=79,hard_limit_seconds=60)
# Actual helper reuses the retained tables, emits225 original indices, never prepares again.
total,peak=s['contract_prepared'](prepared,g.divisor,lambda r:emit('exact-branch',word=79,**r))
warm_seconds=time.perf_counter()-warm;raw=total*g.divisor;assert raw.denominator==1;bound();signal.alarm(0)
emit('exact-word',word=79,scope='Complete selected unrestricted word79',restrictions={},branches=225,coefficient=[total.numerator,total.denominator],raw_numerator=raw.numerator,divisor=g.divisor,peak_rows=peak,preparation_seconds=prep,whole225_warm_seconds=warm_seconds,full_seconds=time.perf_counter()-start,source_sha256=EXPECTED,runner_sha256=RUNNER_SHA256)
'''
runner=P/(pre+'-runner.py');runner.write_text(r)
old=P/'l1-7981-control-preparation-r2-fixed79-driver.py';d=old.read_text().replace('/tmp/l1-7981-control-preparation-r2-fixed79-runner.py',str(runner)).replace('1e3a15719d1522d0ed1f4004e4b4dfd680c35cff3a66374d5b4cec9a07fdc1d1',sha(runner)).replace('/tmp/l1-7981-control-preparation-r2-fixed79','/tmp/'+pre).replace("'exact-fixed-branch'","'exact-branch'").replace('whole225_fixed_warm_limit_seconds','whole225_warm_limit_seconds').replace('FIXED79 ONLY; unrestricted NOTRUN','Complete selected unrestricted word79')
driver=P/(pre+'-driver.py');driver.write_text(d)
for p in (runner,driver):compile(p.read_text(),str(p),'exec')
rt=ast.parse(r);dt=ast.parse(d);assert 'signal.alarm(600)' in ast.unparse(rt) and 'signal.alarm(60)' in ast.unparse(rt) and 'timeout=665' in ast.unparse(dt)
prepcalls=[n for n in ast.walk(rt) if isinstance(n,ast.Call) and ast.unparse(n.func)=="s['prepare_branches']"];assert len(prepcalls)==1 and len(prepcalls[0].args)==1 and not prepcalls[0].keywords
assert not any(isinstance(n,ast.Call) and (ast.unparse(n.func)=="s['prepare']" or 'solve' in ast.unparse(n.func)) for n in ast.walk(rt))
source=P/'l1-7981-evaluator-draft-r1.py';st=ast.parse(source.read_text());helpers=[n for n in st.body if isinstance(n,ast.FunctionDef) and n.name in ('prepare_branches','contract_prepared')]
objects=[(object(),192,object()) for i in range(225)];domains=[(Fraction(-1 if i%5==0 else 1),{'opaque':i}) for i in range(225)];prepc=[];calls=[]
def prepare(g,c,restrict):assert restrict is None;prepc.append(c);return None if len(prepc)==9 else objects[len(prepc)-1]
def eliminate(f,e):calls.append((f,e));return len(calls),len(calls)%7
ns={'Fraction':Fraction,'k3':types.SimpleNamespace(eliminate_components=eliminate),'prepare':prepare,'branches':lambda g:iter(domains)};exec(compile(ast.Module(body=helpers,type_ignores=[]),'<actual-helpers-AST>','exec'),ns)
prepared=ns['prepare_branches'](object());assert len(prepc)==225;ids=[id(p) for w,p in prepared];records=[];alarms=[];ticks=iter((1.,2.,3.))
ns2={'signal':types.SimpleNamespace(alarm=alarms.append),'time':types.SimpleNamespace(perf_counter=lambda:next(ticks)),'emit':lambda kind,**kw:records.append({'kind':kind,**kw}),'s':ns,'prepared':prepared,'g':types.SimpleNamespace(divisor=192),'prep':10.,'start':0.,'EXPECTED':sha(source),'RUNNER_SHA256':sha(runner),'bound':lambda:None}
begin=next(i for i,n in enumerate(rt.body) if isinstance(n,ast.Expr) and ast.unparse(n)=='signal.alarm(60)');exec(compile(ast.Module(body=rt.body[begin:],type_ignores=[]),'<actual-unrestricted79-warm-AST>','exec'),ns2)
bs=[x for x in records if x['kind']=='exact-branch'];assert len(bs)==225 and len(calls)==224 and len(prepc)==225 and alarms==[60,0] and all(x['word']==79 and x['branch']==i for i,x in enumerate(bs)) and ids==[id(p) for w,p in prepared] and records[-1]['scope']=='Complete selected unrestricted word79' and records[-1]['restrictions']=={}
assert bs[8]['algebraic_empty_preparation'] and bs[8]['raw_numerator']==0
assert not any(Path('/tmp/'+pre+s).exists() for s in ('.out','.err','.exit.json'))
result={'scope':'Prepared unrestricted79 only; no scientific imports/execution','runner_sha256':sha(runner),'driver_sha256':sha(driver),'source_sha256':sha(source),'actual_AST_mock':{'preparation_calls_default_None':225,'retained225_objects_reused':True,'nonempty_opaque_eliminations':224,'structural_empty':1,'emitted_exact_branch_records':225,'emitted_word':79,'restrictions':{},'warm_extra_preparations':0,'negative_weight_arithmetic':True,'alarms':alarms},'limits':{'cold':600,'WHOLE225warm':60,'parent':665,'row':120000,'pair':3000000},'new_exclusive_output_prefix':'/tmp/'+pre,'source_review_and_admission':'OWED','scientific_execution':False}
(P/(pre+'-verification.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
