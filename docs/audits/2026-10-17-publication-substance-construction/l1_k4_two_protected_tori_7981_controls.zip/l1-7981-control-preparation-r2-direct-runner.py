from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product,combinations
from functools import cache
from math import prod
import runpy,json,hashlib,signal,time
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
SOURCE=P/'l1-7981-evaluator-draft-r1.py';EXPECTED='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
BINDING={'l1_direct_b_haar.py': '535d4233a51b89e44f8b9d9b8d01ed624b659d68f1ee9e10ec14efea060900b1', 'l1_extended_four_face_gauge_join.py': '4ddfbc8731cc8c8f546b4347c28718fc3917e131d3a5f461fef19f67122ec91b', 'l1_extended_mixed_center_gamma.py': 'a3dcaffb79e59a174b3a2816d207d8ced22e2bd11a9e05b8c9ea07a20d9c158d', 'l1_extended_mixed_curvature_core.py': '24f640e140b8ab179779f8fc9f5029c2484d834a8f79d5f134991822d2010242', 'l1_extended_mixed_frame_moment.py': '3d1e8d1e1281e6a27223224cf0cbb7dc0545e9c7c035951a0adabd97d9cf3137', 'l1_extended_offset_square.py': '32373f84a267f266e29dea45fa4fe4dc49823be288f1e37dc168dabf06c1793d', 'l1_extended_offset_witness.py': 'e558b5a3211ee2ff62bd4f9d8b06c762ba26d3e041eb8a70280fee7464a4dd0f', 'l1_extended_offset_witness_k2.py': '1d10dc5705e89e8d16cc9e6991b7547b2d8b67bb52e257505aa04259c85455d7', 'l1_extended_offset_witness_k3.py': 'fa1ef180c87707c6e9a4a13410890b77b04c3620774587a81d00dd9b34e2c73d', 'l1_extended_offset_witness_k4.py': 'b2b6027c9a3f13dab49b9c72efd09ecc9dbf1e6bf3ab9903fdb008ac79fd12e0', 'l1_extended_offset_witness_k4_free_torus.py': 'ba82ce5abdcc35dc0e4d98fe52fef1f275837f7063074babfb2cd95c0ab24109', 'l1_extended_offset_witness_k4_peeled.py': '7eb0114dec24a2cc0674c2e3e3865ffc34d12924f131868d95ad121c62d31a4c', 'l1_extended_offset_witness_k4_single_square.py': '4fd18a9a852ce9c1d331f9462f4436d7d8d41f6cd10f408e0dfa2c3aca2729dd', 'l1_extended_offset_witness_k4_two_square.py': '1bd858308e4ba5be3d9d25ce1b0d0a8695600b7b030e45e765d923c60610e78b', 'l1_extended_opposed_source.py': '06e16f2f83062b1b123bf2a6ce7150522114a43c2af06fb117e73823a6bc42f5', 'l1_extended_two_mixed_centers.py': '6f950654cc6e2650246dcb55623040f22e5a3bda7a5ce74c4ab7f0eaf9f628b2'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bound():
 assert sha(SOURCE)==EXPECTED
 assert len(BINDING)==16 and all(sha(A/n)==h for n,h in BINDING.items())
def emit(kind,**v):print(json.dumps(dict(kind=kind,**v),sort_keys=True),flush=True)

# No factor preparation or scalar contraction in this direct worker.
start=time.perf_counter();signal.alarm(600);bound()
emit('direct-start',source_sha256=EXPECTED,principal_source_sha256=BINDING,scope='DIRECT79/81 ONLY; no prepared factors or scalar contractions')
s=runpy.run_path(str(SOURCE),run_name='author_7981_direct');k2,k3=s['k2'],s['k3'];found=s['data']();assert tuple(found)==(79,81)
from l1_direct_b_haar import R,add,scale,wedge,bilinear,diag,gamma
from l1_extended_opposed_source import frame,action_frame
from l1_extended_two_mixed_centers import remap
from l1_normalization_disjoint_sector import quat
from l1_normalization_opposed_fourth import nodes
from l1_extended_offset_square import cubature_edge
from l1_extended_mixed_curvature_core import conditional,face_vector
from l1_extended_mixed_center_gamma import COMPONENTS
from l1_normalization_uniform_mixed_edge import unit
REFERENCE=P/'l1-7981-control-preparation-r2-quaternion-reference.py'
assert sha(REFERENCE)=='3520188b78f838b475814949104c8c64dc3c5dd3cff2ff57ba93024bdc642059'
exec(compile(REFERENCE.read_text(),str(REFERENCE),'exec'))
pairs=tuple((a,b) for a in range(8) for b in range(a,8))
ident=frame(0,False,unit(0),unit(0));src=scale(add(*(wedge(v,v) for v in ident)),192)
assert src==add(*(k3.witness.anchored(0,(),None,j) for j in range(4)))
for j in range(4):assert k3.witness.anchored(0,(),None,j)==scale(wedge(ident[j],ident[j]),192)
q4=(F(1,2),)*4;q4s=(F(1,2),F(-1,2),F(1,2),F(-1,2));q34=(F(3,5),F(4,5),F(),F());q34p=(F(),F(3,5),F(),F(-4,5))
samples=[(unit(i),unit(j)) for i,j in product(range(4),repeat=2)]+[(q4,q4s),(q4s,q4),(q34,q34p),(q34p,q4),(q4,tuple(-x for x in q4s))]
patterns=[((0,0),)*4,((0,0),(3,3),(0,0),(0,0)),((0,1),(0,1),(0,0),(0,0)),((1,2),(1,2),(0,0),(3,3)),((0,0),(0,0),(3,3),(3,3)),((3,4),(3,4),(3,3),(3,3)),((0,3),(0,3),(0,0),(0,0))]
for word,(row,g) in found.items():
 square,=g.squares;live,=g.lives;fixed=g.fixed_square[square];rows=k3.square_factor(square,live,fixed);offdiag=0
 for left,right in samples:
  coords={**fixed,live:(left,right)};q=left+right
  for labels in COMPONENTS:
   direct=prod(vector(square,coords,l) for l in labels)
   assert direct==prod(face_vector(square,coords,*divmod(l,3)) for l in labels)==sum(w*q[a]*q[b] for (c,(a,b)),w in rows.items() if c==labels)
   offdiag+=sum(bool(w*q[a]*q[b]) and a!=b for (c,(a,b)),w in rows.items() if c==labels)
 assert offdiag>0
 branches=list(s['branches'](g));assert len(branches)==225 and sum(w<0 for w,c in branches)==52
 tables=[];facelabels=[]
 for torus in g.tori:
  tb=list(k2.protected_branches(torus.linked,torus.other));assert len(tb)==15
  values=[];maps=[]
  for pattern in patterns:
   mapping=dict(zip(torus.linked+torus.other,pattern,strict=True));labels={f:mapping[f[0]] for f in torus.faces};fixed_t={torus.fixed_source:(unit(0),unit(0))}
   direct=independent_integral(torus.faces,fixed_t,labels,F(1));assert direct==conditional(torus.faces,{torus.fixed_source},fixed_t,labels)==k2.formula(tb,mapping)
   values.append(direct);maps.append(labels)
  tables.append(values);facelabels.append(maps)
 for i,j in product(range(7),repeat=2):
  mapping={f[0]:v for f,v in (facelabels[0][i]|facelabels[1][j]).items()}
  assert k2.formula(branches,mapping)==tables[0][i]*tables[1][j]
 for i,j in ((0,0),(1,4),(2,2),(3,4),(4,1),(5,5),(6,6)):
  allfaces=g.tori[0].faces|g.tori[1].faces;labels=facelabels[0][i]|facelabels[1][j]
  sq_labels=(0,1) if i%2 else (0,3);coords={**fixed,live:(q4,q4s)};scalar=prod(vector(square,coords,l) for l in sq_labels)
  allfixed={t.fixed_source:(unit(0),unit(0)) for t in g.tori}
  assert independent_integral(allfaces,allfixed,labels,scalar)==scalar*tables[0][i]*tables[1][j]
 # Joint F4 has two physical components. Seed each component independently.
 allfaces={square:set(fixed)|{live},**g.tori[0].faces,**g.tori[1].faces};edges=set.union(*allfaces.values())|g.forest
 coords={e:samples[16+i%5] for i,e in enumerate(sorted(edges))};gauges={};pending=set(g.forest);components=0
 while pending:
  reachable=[e for e in sorted(pending) if e[0] in gauges or (e[0]^(1<<e[1])) in gauges]
  if not reachable:
   e=min(pending);gauges[e[0]]=(q4s,q34) if components else (unit(0),unit(0));components+=1
  else:e=reachable[0]
  q,a=e;y=q^(1<<a)
  if q in gauges:
   assert y not in gauges;gauges[y]=tuple(mul(gauges[q][ch],adj(coords[e][ch])) for ch in (0,1))
  else:gauges[q]=tuple(mul(gauges[y][ch],coords[e][ch]) for ch in (0,1))
  pending.remove(e)
 assert components==2
 for q in range(16):gauges.setdefault(q,(q4s,q34))
 transformed={e:tuple(mul(mul(gauges[e[0]^(1<<e[1])][ch],coords[e][ch]),adj(gauges[e[0]][ch])) for ch in (0,1)) for e in edges}
 assert len(g.forest)==4 and all(transformed[e]==(unit(0),unit(0)) for e in g.forest)
 for face in allfaces:
  for ch in (0,1):assert hol(face,transformed,ch)==mul(mul(gauges[face[0]][ch],hol(face,coords,ch)),adj(gauges[face[0]][ch]))
 # Complete BOTH source degree-four polynomials before and after gauge fixing.
 # Pull transformed endpoint Grassmann variables back by their actual site rotations.
 for q,a in g.sources:
  y=q^(1<<a);sx=diag(*(quat(z) for z in gauges[q]));sy=diag(*(quat(z) for z in gauges[y]));sxdag=diag(*(quat(adj(z)) for z in gauges[q]));sydag=diag(*(quat(adj(z)) for z in gauges[y]))
  u=diag(*(quat(z) for z in transformed[q,a]));ud=diag(*(quat(adj(z)) for z in transformed[q,a]));v=diag(*(quat(z) for z in coords[q,a]));vd=diag(*(quat(adj(z)) for z in coords[q,a]))
  matrices=[(ga*vd,v*ga,sxdag*ga*ud*sy,sydag*u*ga*sx) for ga in gamma]
  # Integer coefficient ring: clear one common denominator before both degree-four polynomials.
  from math import lcm
  denominator=1
  for group in matrices:
   for matrix in group:
    for coefficient in matrix:
     for part in coefficient.expand().as_real_imag():denominator=lcm(denominator,int(part.as_numer_denom()[1]))
  old=[add(bilinear(a*denominator,0,1),scale(bilinear(b*denominator,1,0),-1)) for a,b,c,d in matrices]
  pulled=[add(bilinear(c*denominator,0,1),scale(bilinear(d*denominator,1,0),-1)) for a,b,c,d in matrices]
  assert add(*(wedge(t,t) for t in old))==add(*(wedge(t,t) for t in pulled))
  assert remap(src,(q,y))==remap(scale(add(*(wedge(v,v) for v in ident)),192),(q,y))
 emit('joint-F4-direct',word=word,forest_edges=4,forest_components=2,all16_site_rotations=True,both_nonidentity_source_polynomials_covariant=True,all9_face_holonomies_covariant=True,torus_direct_patterns=14,cartesian225_checks=49,disconnected_nineface_closures=7,square_samples=21,square_components=21,activated_offdiag_terms=offdiag)
# Actual singleton orientations; first and second gamma pairs are deliberately distinguishable.
for center,anchor in ((1,0),(0,1)):
 for labels in ((0,0),(0,1),(1,2),(2,3)):
  assert k3.fixed_action_edge((labels,),(center,),anchor)==cubature_edge((labels,),(center,),anchor)
emit('singleton-fixed-edge-direct',actual_orientations=[[1,0],[0,1]],gamma_cases=4,full_polynomial_equalities=8)
rule=tuple(nodes());nonzero=0;zero=0
for labels,probe in product(((0,0),(0,1),(1,2)),((1,1),(1,2),(1,5))):
 center=0;anchor=1;terms=[]
 for n in (0,2):
  for chosen in combinations(range(2),n):
   chunks=tuple(tuple(labels[i] for i in range(2) if (i in chosen)==(a==0)) for a in (0,1));factors=[]
   for local,chunk in enumerate(chunks):
    vals=[]
    for left,right,weight in rule:
     t=action_frame(0,local^center,left,right);poly={0:R.one}
     for j in chunk:poly=wedge(poly,t[j])
     qq=left+right;extra=qq[probe[0]]*qq[probe[1]] if local==anchor else 1;vals.append(scale(poly,weight*extra))
    factors.append(add(*vals))
   terms.append(wedge(*factors))
 direct=add(*terms);assert direct==scale(k3.probed_action_edge(labels,center,anchor,probe),4);nonzero+=bool(direct);zero+=not bool(direct)
emit('live-singleton-direct',center=0,physical_anchor=1,global_frame_slot=1,edge_local_slot=0,equalities=9,nonzero=nonzero,zero=zero,offdiagonal_probes=[[1,2],[1,5]])
bound();signal.alarm(0);emit('direct-controls-complete',seconds=time.perf_counter()-start,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP,factor_preparations_run=0,fixed_scalar_replays_run=0,unrestricted_coefficients_run=0,source_sha256=EXPECTED)
