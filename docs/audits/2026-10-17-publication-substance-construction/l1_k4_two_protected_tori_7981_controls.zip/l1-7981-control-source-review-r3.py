from pathlib import Path
import ast,hashlib,json,types
from fractions import Fraction
P=Path('/tmp');stem='l1-7981-control-preparation-r2';A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={n:P/(stem+'-'+n) for n in ['fixed79-runner.py','fixed79-driver.py','direct-runner.py','direct-driver.py','quaternion-reference.py','binding.json']}
hashes={n:sha(p) for n,p in files.items()};trees={n:ast.parse(p.read_text()) for n,p in files.items() if n.endswith('.py')}
for n,t in trees.items():compile(t,str(files[n]),'exec')
source=P/'l1-7981-evaluator-draft-r1.py';assert sha(source)=='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
binding=json.loads(files['binding.json'].read_text());capture=json.loads((P/'l1-residual38-second-family-geometry.json').read_text());assert len(binding['principal_source_sha256'])==16
for n,h in capture['source_sha256'].items():assert sha(A/n)==h
for name in ('fixed79-runner.py','direct-runner.py'):
 t=trees[name];assign={n.targets[0].id:n.value for n in t.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
 assert ast.literal_eval(assign['BINDING'])==binding['principal_source_sha256']
 assert ast.literal_eval(assign['EXPECTED'])==sha(source)
for n,h in binding['principal_source_sha256'].items():assert sha(A/n)==h
for mode in ('fixed79','direct'):
 t=trees[mode+'-driver.py'];assign={n.targets[0].id:ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Constant)}
 assert assign['EXPECTED_RUNNER_SHA256']==hashes[mode+'-runner.py']
 text=ast.unparse(t);assert 'timeout=665' in text and "open('xb')" in text and 'process.kill()' in text and 'child_exit = process.wait()' in text
 assert '124 if timeout else 0 if child_exit == 0 else 1' in text
fixed=trees['fixed79-runner.py'];direct=trees['direct-runner.py'];sourcetree=ast.parse(source.read_text())
assert not any(isinstance(n,ast.ExceptHandler) for n in ast.walk(fixed))
fixedcalls=[ast.unparse(n.func) for n in ast.walk(fixed) if isinstance(n,ast.Call)];assert fixedcalls.count("s['prepare']")==1 and fixedcalls.count("s['contract_prepared']")==1 and not any('solve' in c for c in fixedcalls)
assert "s['data']()[79]" in ast.unparse(fixed) and 'signal.alarm(600)' in ast.unparse(fixed) and 'signal.alarm(60)' in ast.unparse(fixed)
assert not any(isinstance(n,ast.Call) and any(x in ast.unparse(n.func) for x in ('prepare','solve','eliminate_components','contract_prepared')) for n in ast.walk(direct))
# Execute only accepted contract helper + actual author warm AST with opaque tables.
helper=next(n for n in sourcetree.body if isinstance(n,ast.FunctionDef) and n.name=='contract_prepared');calls=[];events=[]
opaque=[(Fraction(-1 if i%5==0 else 1),None if i==7 else (object(),192,object())) for i in range(225)];before=[id(t) for w,t in opaque]
def eliminate(f,e):calls.append((f,e));return len(calls),len(calls)%11
ns={'Fraction':Fraction,'k3':types.SimpleNamespace(eliminate_components=eliminate)};exec(compile(ast.Module(body=[helper],type_ignores=[]),'<accepted-helper>','exec'),ns)
alarms=[];clock=iter([1.,2.,3.]);bound=[];begin=next(i for i,n in enumerate(fixed.body) if isinstance(n,ast.Expr) and ast.unparse(n)=='signal.alarm(60)')
env={'signal':types.SimpleNamespace(alarm=alarms.append),'time':types.SimpleNamespace(perf_counter=lambda:next(clock)),'emit':lambda kind,**kw:events.append({'kind':kind,**kw}),'s':{'contract_prepared':ns['contract_prepared']},'prepared':opaque,'g':types.SimpleNamespace(divisor=192),'prep':10.,'start':0.,'EXPECTED':sha(source),'bound':lambda:bound.append(True)}
exec(compile(ast.Module(body=fixed.body[begin:],type_ignores=[]),'<actual-warm-mock>','exec'),env)
assert alarms==[60,0] and len(calls)==224 and before==[id(t) for w,t in opaque] and len(bound)==1
branches=[e for e in events if e['kind']=='exact-fixed-branch'];assert len(branches)==225 and branches[7]['algebraic_empty_preparation'] and branches[7]['raw_numerator']==0 and events[-1]['kind']=='exact-fixed-word'
expected=Fraction();idx=0
for w,t in opaque:
 if t is not None:idx+=1;expected+=w*Fraction(idx,192)
assert events[-1]['coefficient']==[expected.numerator,expected.denominator]
# Source inspection pins exact endpoint pullback and denominator structure without executing it.
d=ast.unparse(direct)
for snippet in ['sxdag * ga * ud * sy','sydag * u * ga * sx','bilinear(a * denominator, 0, 1)','bilinear(b * denominator, 1, 0)','bilinear(c * denominator, 0, 1)','bilinear(d * denominator, 1, 0)','for q, a in g.sources','components == 2','range(16)','for center, anchor in ((1, 0), (0, 1))','scale(k3.probed_action_edge(labels, center, anchor, probe), 4)']:
 assert snippet in d,snippet
r={'verdicts':{'fixed79':'ACCEPT source for bounded fixed79 admission','direct':'ACCEPT source for bounded direct controls admission'},'continuity':{'packet':'publication-7981-control-source-review-r3.json','first_check_exit':0,'fresh':True,'changed':[]},'checker_command':'python3 /tmp/l1-7981-control-source-review-r3.py','checker_exit':0,'hashes':hashes,'evaluator_sha256':sha(source),'binding16_current':True,'captured18_current':True,'syntax_files':len(trees),'opaque_actual_warm_AST':{'branches':225,'nonempty_contractions':224,'retained_table_ids':True,'None_structural_zero':True,'negative_weights':True,'alarms':[60,0],'no_preparation_called':True},'limits':{'cold':600,'whole225warm':60,'parent':665,'rows':120000,'pairs':3000000},'driver_exclusive_original_streams_and_timeout_failure':True,'scope':'Only stdlib syntax/hash/AST/static and opaque orchestration mocks; no scientific import, moment, prep, control, coefficient, test, candidate/primary/Git/state mutation.','owed':['Actual direct runtime verification','Independent original-L center/full-row reconstruction','All450 prepared/fixed branches with81 transpose','Independent direct/fixed runtime receipts','Fresh ROOT admission before each runtime','Unrestricted pilot and portable acceptance remain ungranted']}
(P/'l1-7981-control-source-review-r3.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
