from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path('/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();D=192**42*4**64*48**6*2**15
prefixes={79:'l1-7981-control-preparation-r2-fixed79',81:'l1-7981-fixed81-r4'};data={};summary={};hashes={}
for word,pre in prefixes.items():
 paths=[P/(pre+s) for s in ('.out','.err','.exit.json')];out,err,ep=paths;rs=[json.loads(l) for l in out.read_text().splitlines()];e=json.loads(ep.read_text());assert e['actual_child_exit_code']==e['driver_exit_code']==0 and not e['parent_timeout'] and not err.read_bytes() and e['complete_raw_branch_records']==225 and e['truncated_or_nonJSON_lines']==0
 assert e['cold_limit_seconds']==600 and e['whole225_fixed_warm_limit_seconds']==60 and e['parent_wall_limit_seconds']==665 and e['parent_seconds']<665
 prep=next(r for r in rs if r['kind']=='phase-complete');bs=[r for r in rs if r['kind']=='exact-fixed-branch'];last=rs[-1];supports=prep['support_domains'];assert len(bs)==len(supports)==225 and last['word']==word and last['branches']==225 and prep['divisor']==last['divisor']==D and prep['row_cap']==120000 and prep['pair_cap']==3000000
 total=F();nonempty=empty=zero=0
 for i,(b,s) in enumerate(zip(bs,supports,strict=True)):
  assert b['branch']==s['branch']==i and b['word']==word and b['weight']==s['weight'] and F(*b['coefficient'])==F(b['raw_numerator'],D) and b['divisor']==D and b['algebraic_empty_preparation']==s['structural_empty_preparation']
  total+=F(*b['weight'])*F(*b['coefficient'])
  if s['structural_empty_preparation']:empty+=1;assert b['raw_numerator']==b['peak_rows']==0
  else:
   nonempty+=1;a=s['prepared_graph'];assert a['factors']==38 and a['labels']==32 and a['all_labels_twice'] and {int(q):v for q,v in a['site_degrees'].items()}==dict.fromkeys(range(16),8) and len(a['source_factors'])==2;zero+=b['raw_numerator']==0
 assert total==F(*last['coefficient'])==F(last['raw_numerator'],D) and last['peak_rows']==max(b['peak_rows'] for b in bs) and last['preparation_seconds']<600 and last['whole225_warm_seconds']<60 and sum(F(*b['weight'])<0 for b in bs)==52
 data[word]=(prep,bs,last)
 summary[word]={'coefficient':last['coefficient'],'raw_numerator':last['raw_numerator'],'peak_rows':last['peak_rows'],'nonempty':nonempty,'structural_empty':empty,'computed_raw_zeros_nonempty':zero,'cold_seconds':last['preparation_seconds'],'whole225_warm_seconds':last['whole225_warm_seconds'],'parent_seconds':e['parent_seconds']}
 hashes.update({str(p):sha(p) for p in paths})
a,ab,al=data[79];b,bb,bl=data[81]
def flipcore(core):return sorted([[q^1,dom] for q,dom in core])
def flipmask(mask):return sum(((mask>>(8*q))&255)<<(8*(q^1)) for q in range(16))
for i,x in enumerate(a['support_domains']):
 j=15*(i%15)+i//15;y=b['support_domains'][j];u,v=ab[i],bb[j]
 assert (x['source0_branch'],x['source1_branch'])==(y['source1_branch'],y['source0_branch'])
 assert x['weight']==y['weight'] and x['structural_empty_preparation']==y['structural_empty_preparation'] and flipcore(x['core_domains'])==y['core_domains']
 assert all(u[k]==v[k] for k in ('weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation'))
 assert sorted(q^1 for q in x['empty_center_sites'])==y['empty_center_sites']
 xc={r['center']^1:{k:v for k,v in r.items() if k!='center'} for r in x['center_support']};yc={r['center']:{k:v for k,v in r.items() if k!='center'} for r in y['center_support']};assert xc==yc
 if x['prepared_graph'] is not None:
  targets={tuple(r['source']):r for r in y['prepared_graph']['source_factors']}
  for src in x['prepared_graph']['source_factors']:
   q,axis=src['source'];target=targets[q^1,axis]
   converted=sorted((flipmask(p['mask']),p['real'],p['imag']) for p in src['polynomial']);expected=sorted((p['mask'],p['real'],p['imag']) for p in target['polynomial']);assert converted==expected
assert al['coefficient']==bl['coefficient'] and al['raw_numerator']==bl['raw_numerator']
binding=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text());A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');assert all(sha(A/n)==h for n,h in binding['principal_source_sha256'].items())
r={'scope':'Author fixed79/81 receipt reduction only; independent acceptance remains owed; unrestricted NOTRUN','actual81_handle':79040,'actual81_driver_exit':0,'actual81_child_exit':0,'words':summary,'all450_raw_weight_divisor_final_equalities':True,'all225_XOR1_transposed_raw_weight_domain_centerweight_sourcepoly_equalities':True,'branch_map':'15i+j -> 15j+i','peaks_preserved_not_required_equal':True,'principal16_bindings_unchanged':True,'source_sha256':binding['source_sha256'],'original_stream_sha256':hashes,'fixed81_runner_sha256':sha(P/'l1-7981-fixed81-r4-runner.py'),'fixed81_driver_sha256':sha(P/'l1-7981-fixed81-r4-driver.py'),'limits':{'cold':600,'WHOLE225warm':60,'parent':665,'row':120000,'pair':3000000},'unrestricted':'NOT RUN','independent_originalL_full_rows':'separate reviewer lane; NOT CLAIMED'}
(P/'l1-7981-fixed81-r4-transpose-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
