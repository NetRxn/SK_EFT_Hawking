from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
import json,hashlib
P=Path('/tmp');prefix=P/'l1-7981-control-preparation-r2-fixed79';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths={k:Path(str(prefix)+s) for k,s in [('out','.out'),('err','.err'),('exit','.exit.json')]};rs=[json.loads(l) for l in paths['out'].read_text().splitlines()];ex=json.loads(paths['exit'].read_text());first,prep,warm=rs[:3];bs=rs[3:-1];last=rs[-1];D=192**42*4**64*48**6*2**15
assert not paths['err'].read_bytes() and ex['actual_child_exit_code']==ex['driver_exit_code']==0 and not ex['parent_timeout'] and ex['complete_raw_branch_records']==225 and ex['truncated_or_nonJSON_lines']==0
assert ex['runner_sha256']==sha(P/'l1-7981-control-preparation-r2-fixed79-runner.py') and ex['source_sha256']==sha(P/'l1-7981-evaluator-draft-r1.py') and ex['parent_seconds']<665
assert len(bs)==len(prep['support_domains'])==225 and first['hard_limit_seconds']==600 and warm['hard_limit_seconds']==60 and prep['row_cap']==120000 and prep['pair_cap']==3000000
binding=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text())['principal_source_sha256'];assert first['principal_source_sha256']==binding
A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');assert all(sha(A/n)==h for n,h in binding.items())
def protected(linked,other):
 yield F(1,256),dict.fromkeys(linked+other,tuple((i,i) for i in range(6)))
 for c in (0,3):
  diag=tuple((i,i) for i in range(c,c+3));yield F(-1,559872),dict.fromkeys(linked+other,diag)
  for pair in combinations_with_replacement(range(c,c+3),2):yield F(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:diag,other[1]:diag}
expected=[(w*v,c|d) for w,c in protected((0,4),(8,12)) for v,d in protected((1,5),(9,13))];assert sum(w<0 for w,c in expected)==52
total=F();rawsum=F();empty=nonempty=zeros=0
for i,(r,s,(w,c)) in enumerate(zip(bs,prep['support_domains'],expected)):
 assert r['kind']=='exact-fixed-branch' and r['word']==79 and r['branch']==s['branch']==i and s['source0_branch']==i//15 and s['source1_branch']==i%15
 assert F(*r['weight'])==F(*s['weight'])==w and r['divisor']==D and F(r['raw_numerator'],D)==F(*r['coefficient'])
 assert {q:tuple(tuple(p) for p in ds) for q,ds in s['core_domains']}==c
 assert r['algebraic_empty_preparation']==s['structural_empty_preparation']==bool(s['empty_center_sites'])
 total+=w*F(*r['coefficient']);rawsum+=w*r['raw_numerator'];audit=s['prepared_graph']
 assert len(s['center_support'])==15 and len({x['center'] for x in s['center_support']})==15
 if r['algebraic_empty_preparation']:empty+=1;assert audit is None and r['raw_numerator']==r['peak_rows']==0
 else:
  nonempty+=1;zeros+=r['raw_numerator']==0
  assert audit['factors']==38 and audit['labels']==32 and audit['all_labels_twice'] and {int(q):d for q,d in audit['site_degrees'].items()}==dict.fromkeys(range(16),8)
  assert len(audit['source_factors'])==2 and len(audit['factor_row_slots'])==38
  for sf in audit['source_factors']:
   q,a=sf['source'];assert (q,a) in [(0,2),(1,2)] and {int(x):d for x,d in sf['degrees'].items()}=={q:2,q^(1<<a):2}
assert (nonempty,empty,zeros)==(25,200,0) and total==F(*last['coefficient'])==F(10367035518435041776795,7709672958021817718820298555392)
assert rawsum.denominator==1 and rawsum.numerator==last['raw_numerator'] and last['divisor']==prep['divisor']==D and max(r['peak_rows'] for r in bs)==last['peak_rows']==564
assert last['preparation_seconds']==prep['seconds']<600 and last['whole225_warm_seconds']<60 and last['branches']==225
# Reconcile actual direct originals, independent of author's derived summaries.
dp=P/'l1-7981-control-preparation-r2-direct';direct=[json.loads(l) for l in Path(str(dp)+'.out').read_text().splitlines()];de=json.loads(Path(str(dp)+'.exit.json').read_text());assert de['actual_child_exit_code']==de['driver_exit_code']==0 and not de['parent_timeout'] and not Path(str(dp)+'.err').read_bytes() and de['truncated_or_nonJSON_lines']==0
assert de['runner_sha256']==sha(P/'l1-7981-control-preparation-r2-direct-runner.py') and de['source_sha256']==sha(P/'l1-7981-evaluator-draft-r1.py') and direct[0]['principal_source_sha256']==binding
assert [x['kind'] for x in direct]==['direct-start','joint-F4-direct','joint-F4-direct','singleton-fixed-edge-direct','live-singleton-direct','direct-controls-complete']
for x in direct[1:3]:assert x['word'] in [79,81] and x['both_nonidentity_source_polynomials_covariant'] and x['all9_face_holonomies_covariant'] and x['activated_offdiag_terms']==67 and x['cartesian225_checks']==49 and x['torus_direct_patterns']==14 and x['disconnected_nineface_closures']==7
assert direct[3]['full_polynomial_equalities']==8 and direct[4]['equalities']==direct[4]['nonzero']==9 and direct[4]['zero']==0 and direct[-1]['factor_preparations_run']==direct[-1]['fixed_scalar_replays_run']==direct[-1]['unrestricted_coefficients_run']==0
files=list(paths.values())+[Path(str(dp)+s) for s in ['.out','.err','.exit.json']];result={'verdict':'ACCEPT actual fixed79 receipt and direct79/81 runtime evidence within their scopes','packet':'publication-7981-independent-fixed-review-r4.json','first_check_fresh':True,'first_check_exit':0,'checker_exit':0,'fixed79':{'branches':225,'nonempty':25,'structural_empty':200,'negative_weights':52,'computed_zero_nonempty':0,'coefficient':last['coefficient'],'peak':564,'cold_seconds':last['preparation_seconds'],'whole225warm_seconds':last['whole225_warm_seconds'],'parent_seconds':ex['parent_seconds']},'all225_independent_weight_domain_raw_D_fraction_final_reductions':True,'direct79and81_original_records_accepted':True,'principal16_current':True,'files':{str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files},'owed':'Independent original-L/full-row450 prepared control and fixed81 transpose plus receipt acceptance before pilot; no new scientific imports/preps/tests or coefficient run in this receipt check'}
(P/'l1-7981-independent-fixed-review-r4-receipts.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
