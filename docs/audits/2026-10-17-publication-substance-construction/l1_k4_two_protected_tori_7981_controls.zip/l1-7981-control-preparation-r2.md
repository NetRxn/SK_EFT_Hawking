# 79/81 control preparation r2

Preparation complete within scratch-only scope. Scientific execution NOT RUN. Independent review of these new direct/fixed scripts and fresh ROOT admission remain required. Portable scientific milestone remains234/272; no increase or publication/full-response acceptance follows.

Initial candidate continuity check: fresh at assignedcdc75df66. Return check: stale with changed=[source], matching ROOT-disclosed handoff/citation changes. I did not refresh the packet or write candidate, primary, notebook, Git, slot or controller state. ROOT must reconcile and issue fresh admission before execution.

## Prepared execution surfaces

- fixed79-driver.py launches only the hard-coded79 fixed-gamma runner,600s cold /60s WHOLE225 warm /665s parent. It prepares each225 branch exactly once, retains exact table objects and calls actual accepted contract_prepared once. All225 exact branch records and final raw/divisor/fraction are emitted. Word81 and unrestricted modes are unavailable in this author driver.
- direct-driver.py launches DIRECT79/81 only,600s inner/665s parent. It has no prepare, solve, elimination or scalar contraction call. Both drivers bind runner SHA, preserve original streams with exclusive creation, retain timeout/nonzero terminal receipts and never replace resource failure by zero.
- Both workers bind accepted e4a228c evaluator and its16 principal siblings. These16 hashes match the prior accepted geometry capture. Original120000 row/3000000 pair caps are asserted.

## Direct controls encoded, all UNRUN

Joint F4 fixes4 edges in2 separately seeded components using nonidentity original links and rotations on all16 sites. It compares all9 actual face holonomies and BOTH full degree-four source polynomials before/after endpoint Spin pullback, with a common denominator cleared for the existing integer coefficient ring. The latter is a new implementation that requires independent mathematical/source review and actual runtime verification. No source disappears; explicit identity source moments are independently compared per gamma and remapped to both source endpoints.

Both square orientations receive21 basis/multiple-coordinate quaternion samples and21 component pairs with activated offdiagonal assertions. Each of the two actual source-bearing tori receives7 independent exact Haar/conditional/formula patterns;49 Cartesian225-formula checks and7 disconnected nine-face closures retain the scalar square. The full Grassmann response remains one graph.

Actual singleton fixed moments test both(center,anchor)=(1,0),(0,1) against original cubature. The actual live(center,anchor)=(0,1) receives9 gamma/probe polynomial controls, including offdiagonal/mixed probes. Slot1 is routed by accepted actual source to edge-localgamma[0], not changed to[1]. The fixed79 restriction has distinguishable global pairs((0,0),(1,1)); metadata asserts all modified gamma slots1 and liveanchor1/fixedanchors0and1.

Fixed79 receipts encode all225 support/domain/weight records,38 factors/32 labels twice/site degree8 at16sites,15 paired action vertices, E20/J0/6peeled and D=192^42*4^64*48^6*2^15. Structural empty preparations are explicit and distinct from computed branch zeros; exceptions and timeouts remain failures. All52 negative branch weights are retained.

## Actually run

The initial and return continuity checks; read-only inspection of referenced authorities, notebook, accepted mathematical/source reviews and existing control precedents; stdlib builder/patch/report scripts; and stdlib-check.py. The checker compiled/AST-parsed the scratch scripts, checked source/runner bindings and driver limits, and executed only the actual accepted contract_prepared AST plus actual new author warm-block AST with225 opaque mock tables. It verified225 calls/emissions, table identity, negative exact mock weights and60s alarm routing. It did not import scientific modules, prepare factors, generate moments, run direct/fixed controls, pilot coefficients, tests, builds or fetches.

## Remaining obligations and risks

All new scientific controls are unrun. The source-polynomial covariance implementation, direct cubature scaling and exact Haar controls need independent nonauthor source review, then admitted runtime evidence. No measured79/81 performance exists. Fixed79 alone does not establish all450 fixed branches or79/81 raw covariance: fixed81 must later receive a separately reviewed/admitted driver, and compare79 branch15i+j to81 branch15j+i. All450 full prepared graph/center-weight/slot controls and independently accepted direct/fixed receipts remain required before any unrestricted pilot. Current fixed runner checks author center tables with canonical weights; independent original-L reconstruction/full-row validation remains reviewer work.161/163 remain excluded due to the opposite periodic source/shared-link cycle; coupled relative holonomy construction is still owed. No236-portable/fullk4/commonZ/B3/modes/transport/main/publication closure follows.

## SHA256 bindings

- l1-7981-control-preparation-r2-fixed79-runner.py: `1e3a15719d1522d0ed1f4004e4b4dfd680c35cff3a66374d5b4cec9a07fdc1d1`
- l1-7981-control-preparation-r2-fixed79-driver.py: `14585bf8c010e33852f3e0845ea5aef6c3ebab0ad952dd1b639eafe2fb33fa5e`
- l1-7981-control-preparation-r2-direct-runner.py: `80233a0218949cf60eab66c4ad5c8accf446a4998073d88f86b9a3f72198d737`
- l1-7981-control-preparation-r2-direct-driver.py: `f77f12c8e6a45e97b77ae769e0611143a945cd05229cd41878f987cb911c0b0c`
- l1-7981-control-preparation-r2-quaternion-reference.py: `3520188b78f838b475814949104c8c64dc3c5dd3cff2ff57ba93024bdc642059`
- l1-7981-control-preparation-r2-binding.json: `9c53cd21f0cb622f6a16dc2b9673cf489c0997ae205d9819d8f21955d4744c59`
- l1-7981-control-preparation-r2-stdlib-check.py: `ccdab1429a0c6215b16e518ed6e29d620fe0737aaf5d99435feb57b790a85b4d`
- l1-7981-control-preparation-r2-stdlib-check.json: `cd656e1af97d33b4d3c98c4ea07921ff04f327eacd2497e8a4a1160707613685`
