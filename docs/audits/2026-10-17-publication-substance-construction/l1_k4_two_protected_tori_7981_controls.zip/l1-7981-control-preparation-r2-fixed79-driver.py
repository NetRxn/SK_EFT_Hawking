"""Prepared only. ROOT admission must precede this scientific subprocess."""
import subprocess,time,json,hashlib
from pathlib import Path
RUNNER=Path('/tmp/l1-7981-control-preparation-r2-fixed79-runner.py');EXPECTED_RUNNER_SHA256='1e3a15719d1522d0ed1f4004e4b4dfd680c35cff3a66374d5b4cec9a07fdc1d1'
PREFIX='/tmp/l1-7981-control-preparation-r2-fixed79'
EXECUTABLE='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
def main():
 start=time.perf_counter();outpath=Path(PREFIX+'.out');errpath=Path(PREFIX+'.err');exitpath=Path(PREFIX+'.exit.json')
 assert hashlib.sha256(RUNNER.read_bytes()).hexdigest()==EXPECTED_RUNNER_SHA256
 if any(p.exists() for p in (outpath,errpath,exitpath)):raise FileExistsError('Preserve original attempt streams')
 command=[EXECUTABLE,'-B',str(RUNNER)];timeout=False
 with outpath.open('xb') as out,errpath.open('xb') as err:
  process=subprocess.Popen(command,stdout=out,stderr=err)
  try:child_exit=process.wait(timeout=665)
  except subprocess.TimeoutExpired:timeout=True;process.kill();child_exit=process.wait()
 driver_exit=124 if timeout else (0 if child_exit==0 else 1);records=[];bad=0
 for line in outpath.read_text(errors='replace').splitlines():
  try:records.append(json.loads(line))
  except ValueError:bad+=1
 receipt={'actual_child_exit_code':child_exit,'driver_exit_code':driver_exit,'parent_timeout':timeout,'parent_seconds':time.perf_counter()-start,'cold_limit_seconds':600,'whole225_fixed_warm_limit_seconds':60,'parent_wall_limit_seconds':665,'command':command,'runner_sha256':EXPECTED_RUNNER_SHA256,'source_sha256':'e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7','complete_raw_branch_records':sum(r.get('kind')=='exact-fixed-branch' for r in records),'last_complete_record_kind':records[-1].get('kind') if records else None,'truncated_or_nonJSON_lines':bad,'scope':'FIXED79 ONLY; unrestricted NOTRUN'}
 exitpath.write_text(json.dumps(receipt,sort_keys=True)+'\n');print(json.dumps(receipt),flush=True);return driver_exit
if __name__=='__main__':raise SystemExit(main())
