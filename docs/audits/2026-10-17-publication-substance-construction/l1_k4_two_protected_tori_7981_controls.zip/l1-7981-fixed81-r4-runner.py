from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product,combinations
from functools import cache
from math import prod
import runpy,json,hashlib,signal,time
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
SOURCE=P/'l1-7981-evaluator-draft-r1.py';EXPECTED='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
BINDING={'l1_direct_b_haar.py': '535d4233a51b89e44f8b9d9b8d01ed624b659d68f1ee9e10ec14efea060900b1', 'l1_extended_four_face_gauge_join.py': '4ddfbc8731cc8c8f546b4347c28718fc3917e131d3a5f461fef19f67122ec91b', 'l1_extended_mixed_center_gamma.py': 'a3dcaffb79e59a174b3a2816d207d8ced22e2bd11a9e05b8c9ea07a20d9c158d', 'l1_extended_mixed_curvature_core.py': '24f640e140b8ab179779f8fc9f5029c2484d834a8f79d5f134991822d2010242', 'l1_extended_mixed_frame_moment.py': '3d1e8d1e1281e6a27223224cf0cbb7dc0545e9c7c035951a0adabd97d9cf3137', 'l1_extended_offset_square.py': '32373f84a267f266e29dea45fa4fe4dc49823be288f1e37dc168dabf06c1793d', 'l1_extended_offset_witness.py': 'e558b5a3211ee2ff62bd4f9d8b06c762ba26d3e041eb8a70280fee7464a4dd0f', 'l1_extended_offset_witness_k2.py': '1d10dc5705e89e8d16cc9e6991b7547b2d8b67bb52e257505aa04259c85455d7', 'l1_extended_offset_witness_k3.py': 'fa1ef180c87707c6e9a4a13410890b77b04c3620774587a81d00dd9b34e2c73d', 'l1_extended_offset_witness_k4.py': 'b2b6027c9a3f13dab49b9c72efd09ecc9dbf1e6bf3ab9903fdb008ac79fd12e0', 'l1_extended_offset_witness_k4_free_torus.py': 'ba82ce5abdcc35dc0e4d98fe52fef1f275837f7063074babfb2cd95c0ab24109', 'l1_extended_offset_witness_k4_peeled.py': '7eb0114dec24a2cc0674c2e3e3865ffc34d12924f131868d95ad121c62d31a4c', 'l1_extended_offset_witness_k4_single_square.py': '4fd18a9a852ce9c1d331f9462f4436d7d8d41f6cd10f408e0dfa2c3aca2729dd', 'l1_extended_offset_witness_k4_two_square.py': '1bd858308e4ba5be3d9d25ce1b0d0a8695600b7b030e45e765d923c60610e78b', 'l1_extended_opposed_source.py': '06e16f2f83062b1b123bf2a6ce7150522114a43c2af06fb117e73823a6bc42f5', 'l1_extended_two_mixed_centers.py': '6f950654cc6e2650246dcb55623040f22e5a3bda7a5ce74c4ab7f0eaf9f628b2'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bound():
 assert sha(SOURCE)==EXPECTED
 assert len(BINDING)==16 and all(sha(A/n)==h for n,h in BINDING.items())
def emit(kind,**v):print(json.dumps(dict(kind=kind,**v),sort_keys=True),flush=True)

# Prepared only: ROOT admission and independent source review precede execution.
start=time.perf_counter();signal.alarm(600);bound()
emit('phase-start',phase='cold-fixed81-preparation',word=81,scope='FIXED-gamma ONLY',hard_limit_seconds=600,source_sha256=EXPECTED,principal_source_sha256=BINDING)
s=runpy.run_path(str(SOURCE),run_name='author_fixed81_controls');k2,k3=s['k2'],s['k3'];row,g=s['data']()[81]
assert k2.ROW_CAP==120000 and k2.PAIR_CAP==3000000
assert len(g.edges)==20 and not g.joined_source and len(g.forest)==4 and g.fixed_sources==set(g.sources)=={(0,2),(1,2)}
assert g.divisor==192**42*4**64*48**6*2**15
restrict=dict.fromkeys(g.frame,k3.witness.FIXED_GAMMAS);assert len(restrict)==15
square,=g.squares;comp_domain=sorted({c for c,p in k3.square_factor(square,g.lives[0],g.fixed_square[square])})
branches=list(s['branches'](g));assert len(branches)==225 and sum(w<0 for w,c in branches)==52
prepared=[];support=[]
for b,(weight,core) in enumerate(branches):
 assert len(core)==8 and square[0] not in core
 p=s['prepare'](g,core,restrict);prepared.append((weight,p));centers=[];empty=[]
 for ci,(q,axes) in enumerate(sorted(g.frame.items())):
  expected={}
  for comp in (comp_domain if q==square[0] else (None,)):
   w=k3.witness.center_weights((comp,) if q==square[0] else core.get(q)).get(restrict[q],0)
   if w:expected[restrict[q]+((comp,) if q==square[0] else ())]={0:(w,0)}
  if not expected:empty.append(q)
  if p is not None:assert p[0][ci][1]==expected
  centers.append({'center':q,'selector':'square_component' if q==square[0] else 'protected_torus' if q in core else 'peeled','rows':[{'labels':k,'weight':v[0][0]} for k,v in sorted(expected.items())]})
 audit=None
 if p is not None:
  factors,divisor,exclusive=p;counts=Counter(k for keys,rs,ds in factors for k in keys);degrees={q:sum(ds.get(q,0) for ks,rs,ds in factors) for q in range(16)}
  assert divisor==g.divisor and len(factors)==38 and len(counts)==32 and set(counts.values())=={2} and degrees==dict.fromkeys(range(16),8)
  source_factors=[]
  for label,(keys,rows,degs) in zip(g.sources,factors[-2:],strict=True):
   assert keys==();source_factors.append({'source':label,'degrees':degs,'polynomial':[{'mask':m,'real':v[0],'imag':v[1]} for m,v in sorted(rows[()].items())]})
  audit={'factors':38,'labels':32,'all_labels_twice':True,'site_degrees':degrees,'source_factors':source_factors,'factor_row_slots':[sum(map(len,rs.values())) for ks,rs,ds in factors]}
 support.append({'branch':b,'source0_branch':b//15,'source1_branch':b%15,'weight':[weight.numerator,weight.denominator],'core_domains':sorted(core.items()),'center_support':centers,'empty_center_sites':empty,'structural_empty_preparation':p is None,'prepared_graph':audit})
assert len(prepared)==225
metadata=s['describe'](row,g);live=metadata['live_action_routing'];fixed=metadata['fixed_action_routing']
assert live['physical_anchor']==1 and live['labels'][0]['frame_gamma_slot']==1 and live['labels'][0]['center_flag']==0
assert sorted((x['labels'][0]['frame_gamma_slot'],x['labels'][0]['center_flag'],x['physical_anchor']) for x in fixed)==[(1,0,1),(1,1,0)]
prep=time.perf_counter()-start
emit('phase-complete',phase='cold-fixed81-preparation',word=81,branches=225,seconds=prep,restrictions=sorted(restrict.items()),support_domains=support,geometry=metadata,divisor=g.divisor,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP)
signal.alarm(60);warm=time.perf_counter();emit('phase-start',phase='warm-WHOLE225-fixed81-contraction',word=81,hard_limit_seconds=60)
# Exactly the retained tables, without any second prepare/solve call.
total,peak=s['contract_prepared'](prepared,g.divisor,lambda r:emit('exact-fixed-branch',word=81,**r))
warm_seconds=time.perf_counter()-warm;raw=total*g.divisor;assert raw.denominator==1;bound();signal.alarm(0)
emit('exact-fixed-word',word=81,scope='FIXED-gamma ONLY; unrestricted NOTRUN',branches=225,coefficient=[total.numerator,total.denominator],raw_numerator=raw.numerator,divisor=g.divisor,peak_rows=peak,preparation_seconds=prep,whole225_warm_seconds=warm_seconds,full_seconds=time.perf_counter()-start,source_sha256=EXPECTED)
