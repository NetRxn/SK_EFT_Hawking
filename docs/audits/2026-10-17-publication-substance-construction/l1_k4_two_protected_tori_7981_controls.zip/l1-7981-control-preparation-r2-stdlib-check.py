from pathlib import Path
import ast,json,hashlib,types
from fractions import Fraction
P=Path('/tmp');stem='l1-7981-control-preparation-r2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=sorted(P.glob(stem+'*.py'));syntax={str(p):sha(p) for p in files}
for p in files:compile(p.read_text(),str(p),'exec');ast.parse(p.read_text())
source=P/'l1-7981-evaluator-draft-r1.py';assert sha(source)=='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
t=ast.parse(source.read_text());helper=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='contract_prepared')
tables=[(Fraction(-1 if i%5==0 else 1,i+1),(object(),192,object())) for i in range(225)];ids=[id(p) for w,p in tables];calls=[];emissions=[]
def eliminate(f,e):
 calls.append((f,e));return (len(calls),len(calls)%7)
ns={'Fraction':Fraction,'k3':types.SimpleNamespace(eliminate_components=eliminate)};exec(compile(ast.Module(body=[helper],type_ignores=[]),'<actual-source-contract-AST>','exec'),ns)
value,peak=ns['contract_prepared'](tables,192,emissions.append)
assert len(calls)==len(emissions)==225 and ids==[id(p) for w,p in tables]
assert value==sum(w*Fraction(i+1,192) for i,(w,p) in enumerate(tables)) and all(e['branch']==i for i,e in enumerate(emissions))
# Actual author warm block AST, using opaque tables and the actual helper AST.
fixed=ast.parse((P/(stem+'-fixed79-runner.py')).read_text());begin=next(i for i,n in enumerate(fixed.body) if isinstance(n,ast.Expr) and ast.unparse(n)=='signal.alarm(60)')
alarms=[];records=[];ticks=iter((1.,2.,3.));boundcalls=[]
ns2={'signal':types.SimpleNamespace(alarm=alarms.append),'time':types.SimpleNamespace(perf_counter=lambda:next(ticks)),'emit':lambda kind,**kw:records.append({'kind':kind,**kw}),'s':{'contract_prepared':ns['contract_prepared']},'prepared':tables,'g':types.SimpleNamespace(divisor=192),'prep':10.,'start':0.,'EXPECTED':sha(source),'bound':lambda:boundcalls.append(True)}
# Weighted total need not have integer raw for arbitrary mocks: choose integral mock weights here.
ns2['prepared']=[(Fraction(-1 if i%5==0 else 1),p) for i,(w,p) in enumerate(tables)];calls.clear()
exec(compile(ast.Module(body=fixed.body[begin:],type_ignores=[]),'<actual-author-warm-AST>','exec'),ns2)
assert alarms==[60,0] and len(calls)==225 and len([r for r in records if r['kind']=='exact-fixed-branch'])==225 and records[-1]['kind']=='exact-fixed-word' and records[-1]['branches']==225
# Static guard: direct runner has no prepare, eliminate or solve call.
direct=ast.parse((P/(stem+'-direct-runner.py')).read_text())
assert not any(isinstance(n,ast.Call) and any(x in ast.unparse(n.func) for x in ('prepare','eliminate_components','solve','contract_prepared')) for n in ast.walk(direct))
for mode in ('direct','fixed79'):
 d=ast.parse((P/(stem+'-'+mode+'-driver.py')).read_text());assign={n.targets[0].id:ast.literal_eval(n.value) for n in d.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Constant)}
 assert assign['EXPECTED_RUNNER_SHA256']==sha(P/(stem+'-'+mode+'-runner.py'))
 assert 'timeout=665' in ast.unparse(d) and "open('xb')" in ast.unparse(d)
assert 'signal.alarm(600)' in ast.unparse(fixed) and 'signal.alarm(60)' in ast.unparse(fixed)
assert not any(isinstance(n,ast.ExceptHandler) for n in ast.walk(fixed))
result={'status':'PASS stdlib source/AST/hash/opaque mock only','scripts_sha256':syntax,'source_sha256':sha(source),'actual_contract_helper_225_opaque_tables_reused':True,'actual_author_warm_AST_225_emissions_and_60_alarm':True,'driver_runner_hashes_match':True,'parent_limit':665,'cold_limit':600,'whole225_warm_limit':60,'direct_no_prepare_or_contraction_calls':True,'scientific_imports_or_controls_run':False,'resource_errors_fall_back_to_zero':False,'scope':'Preparation only; independent source review and ROOT admission still required'}
(P/(stem+'-stdlib-check.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
