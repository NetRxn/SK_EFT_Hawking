from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path('/tmp');prefix=P/'l1-7981-control-preparation-r2-fixed79';out=Path(str(prefix)+'.out');err=Path(str(prefix)+'.err');ep=Path(str(prefix)+'.exit.json');rs=[json.loads(l) for l in out.read_text().splitlines()];e=json.loads(ep.read_text());assert e['actual_child_exit_code']==e['driver_exit_code']==0 and not e['parent_timeout'] and e['complete_raw_branch_records']==225 and not e['truncated_or_nonJSON_lines'] and not err.read_bytes()
assert e['cold_limit_seconds']==600 and e['whole225_fixed_warm_limit_seconds']==60 and e['parent_wall_limit_seconds']==665 and e['parent_seconds']<665
prep=next(r for r in rs if r['kind']=='phase-complete');bs=[r for r in rs if r['kind']=='exact-fixed-branch'];last=rs[-1];D=192**42*4**64*48**6*2**15
assert len(bs)==prep['branches']==last['branches']==225 and last['word']==79 and prep['divisor']==last['divisor']==D and last['source_sha256']=='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
assert prep['row_cap']==120000 and prep['pair_cap']==3000000 and prep['seconds']<600 and last['whole225_warm_seconds']<60
supports=prep['support_domains'];assert len(supports)==225
nonempty=zero=empty=0;weighted=F();peak=0
for i,(b,s) in enumerate(zip(bs,supports,strict=True)):
 assert b['branch']==s['branch']==i and b['weight']==s['weight'] and b['divisor']==D and F(*b['coefficient'])==F(b['raw_numerator'],D)
 assert b['algebraic_empty_preparation']==s['structural_empty_preparation'] and (s['source0_branch'],s['source1_branch'])==(i//15,i%15)
 weighted+=F(*b['weight'])*F(*b['coefficient']);peak=max(peak,b['peak_rows'])
 if s['structural_empty_preparation']:
  empty+=1;assert b['raw_numerator']==0 and b['peak_rows']==0
 else:
  nonempty+=1;a=s['prepared_graph'];assert a['factors']==38 and a['labels']==32 and a['all_labels_twice'] and {int(q):v for q,v in a['site_degrees'].items()}==dict.fromkeys(range(16),8) and len(a['source_factors'])==2
  zero+=b['raw_numerator']==0
assert weighted==F(*last['coefficient'])==F(last['raw_numerator'],D) and peak==last['peak_rows'] and sum(F(*b['weight'])<0 for b in bs)==52
binding=json.loads((P/'l1-7981-control-preparation-r2-binding.json').read_text());A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(A/n)==h for n,h in binding['principal_source_sha256'].items())
r={'scope':'Author FIXED79 ONLY; independent review pending; no unrestricted coefficient or portable increase','actual_handle':96766,'actual_driver_exit':0,'actual_child_exit':0,'branches':225,'nonempty_prepared':nonempty,'structural_empty_preparations':empty,'computed_raw_zero_nonempty_branches':zero,'negative_branch_weights':52,'coefficient':last['coefficient'],'raw_numerator':last['raw_numerator'],'divisor':D,'peak_rows':peak,'cold_seconds':last['preparation_seconds'],'whole225_warm_seconds':last['whole225_warm_seconds'],'parent_seconds':e['parent_seconds'],'limits':{'cold':600,'WHOLE225warm':60,'parent':665,'row':120000,'pair':3000000},'all225_raw_weight_divisor_final_equalities':True,'all_nonempty_graphs_38factors_32labels_twice_degree8at16sites':True,'principal16_bindings_unchanged':True,'original_receipt_sha256':{str(p):sha(p) for p in (out,err,ep)},'source_sha256':binding['source_sha256'],'fixed81':'NOT RUN','direct':'separate reviewer lane','unrestricted':'NOT RUN','161163':'separate owed cyclic-holonomy family'}
(P/'publication-7981-fixed79-execution-r3-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
