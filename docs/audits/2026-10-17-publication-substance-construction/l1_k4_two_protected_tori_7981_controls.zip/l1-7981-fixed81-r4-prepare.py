from pathlib import Path
import ast,hashlib,difflib,json,types
from fractions import Fraction
P=Path('/tmp');oldr=P/'l1-7981-control-preparation-r2-fixed79-runner.py';oldd=P/'l1-7981-control-preparation-r2-fixed79-driver.py';newr=P/'l1-7981-fixed81-r4-runner.py';newd=P/'l1-7981-fixed81-r4-driver.py';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(oldr)=='1e3a15719d1522d0ed1f4004e4b4dfd680c35cff3a66374d5b4cec9a07fdc1d1' and sha(oldd)=='14585bf8c010e33852f3e0845ea5aef6c3ebab0ad952dd1b639eafe2fb33fa5e'
r=oldr.read_text().replace('fixed79','fixed81').replace('word=79','word=81').replace("s['data']()[79]","s['data']()[81]");newr.write_text(r)
d=oldd.read_text().replace(str(oldr),str(newr)).replace('1e3a15719d1522d0ed1f4004e4b4dfd680c35cff3a66374d5b4cec9a07fdc1d1',sha(newr)).replace('/tmp/l1-7981-control-preparation-r2-fixed79','/tmp/l1-7981-fixed81-r4').replace('FIXED79','FIXED81');newd.write_text(d)
for p in (newr,newd):compile(p.read_text(),str(p),'exec')
rt,ot=ast.parse(r),ast.parse(oldr.read_text());dt=ast.parse(d)
# Compare semantic ASTs after reversing precisely the word/phase/runname substitutions.
assert ast.dump(ast.parse(r.replace('fixed81','fixed79').replace('word=81','word=79').replace("s['data']()[81]","s['data']()[79]")),include_attributes=False)==ast.dump(ot,include_attributes=False)
assert 'signal.alarm(600)' in ast.unparse(rt) and 'signal.alarm(60)' in ast.unparse(rt) and 'timeout=665' in ast.unparse(dt)
assert '120000' in r and '3000000' in r and not any(isinstance(n,ast.ExceptHandler) for n in ast.walk(rt))
source=P/'l1-7981-evaluator-draft-r1.py';assert sha(source)=='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
helper=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='contract_prepared');calls=[]
def eliminate(f,e):calls.append((f,e));return len(calls),len(calls)%7
ns={'Fraction':Fraction,'k3':types.SimpleNamespace(eliminate_components=eliminate)};exec(compile(ast.Module(body=[helper],type_ignores=[]),'<actual-contract-helper>','exec'),ns)
tables=[(Fraction(-1 if i%5==0 else 1),None if i==8 else (object(),192,object())) for i in range(225)];ids=[id(p) for w,p in tables]
records=[];alarms=[];ticks=iter((1.,2.,3.));boundcalls=[]
ns2={'signal':types.SimpleNamespace(alarm=alarms.append),'time':types.SimpleNamespace(perf_counter=lambda:next(ticks)),'emit':lambda kind,**kw:records.append({'kind':kind,**kw}),'s':{'contract_prepared':ns['contract_prepared']},'prepared':tables,'g':types.SimpleNamespace(divisor=192),'prep':10.,'start':0.,'EXPECTED':sha(source),'bound':lambda:boundcalls.append(True)}
begin=next(i for i,n in enumerate(rt.body) if isinstance(n,ast.Expr) and ast.unparse(n)=='signal.alarm(60)');exec(compile(ast.Module(body=rt.body[begin:],type_ignores=[]),'<actual-fixed81-warm-AST>','exec'),ns2)
bs=[r for r in records if r['kind']=='exact-fixed-branch'];assert len(bs)==225 and len(calls)==224 and alarms==[60,0] and records[-1]['word']==81 and records[-1]['branches']==225 and all(b['word']==81 and b['branch']==i for i,b in enumerate(bs))
assert bs[8]['algebraic_empty_preparation'] and bs[8]['raw_numerator']==0 and ids==[id(p) for w,p in tables]
assert not any(Path('/tmp/l1-7981-fixed81-r4'+s).exists() for s in ('.out','.err','.exit.json'))
patch=''.join(difflib.unified_diff(oldr.read_text().splitlines(keepends=True),r.splitlines(keepends=True),fromfile=str(oldr),tofile=str(newr)))+''.join(difflib.unified_diff(oldd.read_text().splitlines(keepends=True),d.splitlines(keepends=True),fromfile=str(oldd),tofile=str(newd)))
(P/'l1-7981-fixed81-r4.diff').write_text(patch)
result={'scope':'Prepared FIXED81 source only, scientific imports/execution NOTRUN','runner_sha256':sha(newr),'driver_sha256':sha(newd),'source_sha256':sha(source),'prior79_runner_sha256':sha(oldr),'prior79_driver_sha256':sha(oldd),'reverse_word_phase_binding_AST_equal':True,'actual_helper_actual_new_warm_AST_mock':{'branches':225,'nonempty_opaque_eliminations':224,'structural_empty':1,'original_table_identity':True,'negative_weights_retained':True,'all_emitted_words':81,'alarms':alarms},'limits':{'cold':600,'WHOLE225warm':60,'parent':665,'row':120000,'pair':3000000},'exclusive_new_receipts':True,'scientific_execution':False}
(P/'l1-7981-fixed81-r4-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
