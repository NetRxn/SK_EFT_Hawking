def mul(q,r):
 a,b,c,d=q;e,f,g,h=r
 return (a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)

def adj(q):return (q[0],)+tuple(-x for x in q[1:])

def hol(face,coords,ch):
 x,a,b=face;u,v,w,z=[coords[e][ch] for e in ((x,a),(x^(1<<a),b),(x^(1<<b),a),(x,b))]
 return mul(mul(adj(z),adj(w)),mul(v,u))

def vector(face,coords,label):ch,i=divmod(label,3);return hol(face,coords,ch)[1+i]

@cache
def hm(indices):
 n=Counter(indices);ans=F(1)
 for base in (0,4):
  ns=[n[i] for i in range(base,base+4)]
  if any(x%2 for x in ns):return F()
  ans*=F(prod(prod(range(1,x,2)) for x in ns),prod(range(4,4+sum(ns),2)))
 return ans

@cache
def mom(p,q):return hm(tuple(sorted(p+q)))

@cache
def pairmatches(p):return tuple((q,mom(p,q)) for q in pairs if mom(p,q))

def tensor(face,free,fixed,labels):
 polys=[]
 for label in labels:
  ch,i=divmod(label,3);poly={}
  for js in product(range(4),repeat=len(free)):
   coords=dict(fixed);coords.update({e:(unit(j),unit(j)) for e,j in zip(free,js)})
   v=vector(face,coords,label)
   if v:poly[tuple(4*ch+j for j in js)]=v
  polys.append(poly)
 out=Counter()
 for a,u in polys[0].items():
  for b,v in polys[1].items():out[tuple(tuple(sorted(z)) for z in zip(a,b))]+=u*v
 return {k:v for k,v in out.items() if v}

def independent_integral(faces,fixed,labels,external):
 free=set.union(*faces.values())-set(fixed);factors=[((),{():external})]
 for face,edges in faces.items():
  local=tuple(sorted(free&edges));factors.append((local,tensor(face,local,fixed,labels[face])))
 while free:
  edge=min(free);inds=[i for i,f in enumerate(factors) if edge in f[0]];assert len(inds)==2
  ai,bi=inds;(aa,a),(bb,b)=factors[ai],factors[bi];factors=[f for i,f in enumerate(factors) if i not in inds]
  shared=tuple(e for e in aa if e in bb);free-=set(shared)
  ixa=[aa.index(e) for e in shared];ixb=[bb.index(e) for e in shared]
  la=[i for i,e in enumerate(aa) if e not in shared];lb=[i for i,e in enumerate(bb) if e not in shared]
  lookup=defaultdict(list)
  for key,v in b.items():lookup[tuple(key[i] for i in ixb)].append((key,v))
  out=defaultdict(F)
  for key,u in a.items():
   for opts in product(*(pairmatches(key[i]) for i in ixa)):
    js,ws=zip(*opts)
    for other,v in lookup.get(js,()):out[tuple(key[i] for i in la)+tuple(other[i] for i in lb)]+=u*v*prod(ws)
  factors.append((tuple(aa[i] for i in la)+tuple(bb[i] for i in lb),{k:v for k,v in out.items() if v}))
 assert all(not f[0] for f in factors)
 return prod(f[1].get((),0) for f in factors)
