from pathlib import Path
p=Path('/tmp/l1-7981-control-preparation-r2-build.py');s=p.read_text();old="""  old=[add(bilinear(ga*vd,0,1),scale(bilinear(v*ga,1,0),-1)) for ga in gamma]
  pulled=[add(bilinear(sxdag*ga*ud*sy,0,1),scale(bilinear(sydag*u*ga*sx,1,0),-1)) for ga in gamma]
""";new="""  matrices=[(ga*vd,v*ga,sxdag*ga*ud*sy,sydag*u*ga*sx) for ga in gamma]
  # Integer coefficient ring: clear one common denominator before both degree-four polynomials.
  from math import lcm
  denominator=1
  for group in matrices:
   for matrix in group:
    for coefficient in matrix:
     for part in coefficient.expand().as_real_imag():denominator=lcm(denominator,int(part.as_numer_denom()[1]))
  old=[add(bilinear(a*denominator,0,1),scale(bilinear(b*denominator,1,0),-1)) for a,b,c,d in matrices]
  pulled=[add(bilinear(c*denominator,0,1),scale(bilinear(d*denominator,1,0),-1)) for a,b,c,d in matrices]
""";assert old in s;s=s.replace(old,new);p.write_text(s)
