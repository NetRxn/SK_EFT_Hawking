from pathlib import Path
from fractions import Fraction as F
import json,hashlib
P=Path('/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=[json.loads(l) for l in (P/'l1-7981-control-preparation-r2-fixed79.out').read_text().splitlines()];b=[json.loads(l) for l in (P/'l1-7981-fixed81-r4.out').read_text().splitlines()];ap,bp=a[1],b[1];ab,bb=a[3:-1],b[3:-1];ex=json.loads((P/'l1-7981-fixed81-r4.exit.json').read_text());assert not (P/'l1-7981-fixed81-r4.err').read_bytes() and ex['actual_child_exit_code']==ex['driver_exit_code']==0 and not ex['parent_timeout'] and ex['truncated_or_nonJSON_lines']==0 and ex['complete_raw_branch_records']==225
assert ex['runner_sha256']==sha(P/'l1-7981-fixed81-r4-runner.py') and ex['source_sha256']==sha(P/'l1-7981-evaluator-draft-r1.py') and b[0]['principal_source_sha256']==a[0]['principal_source_sha256']
assert ex['parent_seconds']<665 and ex['cold_limit_seconds']==600 and ex['whole225_fixed_warm_limit_seconds']==60 and b[0]['hard_limit_seconds']==600 and b[2]['hard_limit_seconds']==60
assert len(bb)==len(bp['support_domains'])==225 and bp['row_cap']==120000 and bp['pair_cap']==3000000
D=192**42*4**64*48**6*2**15;total=F();raw=F();empty=zero=negative=0
for i,j in [(i,j) for i in range(15) for j in range(15)]:
 x,y=ab[15*i+j],bb[15*j+i];xs,ys=ap['support_domains'][15*i+j],bp['support_domains'][15*j+i]
 assert x['word']==79 and y['word']==81 and x['branch']==15*i+j and y['branch']==ys['branch']==15*j+i
 assert all(x[k]==y[k] for k in ['weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation'])
 assert y['divisor']==D and F(*y['coefficient'])==F(y['raw_numerator'],D) and y['weight']==ys['weight'] and y['algebraic_empty_preparation']==ys['structural_empty_preparation']==bool(ys['empty_center_sites'])
 w=F(*y['weight']);total+=w*F(*y['coefficient']);raw+=w*y['raw_numerator'];negative+=w<0;empty+=y['algebraic_empty_preparation'];zero+=not y['algebraic_empty_preparation'] and y['raw_numerator']==0
 assert {q^1:ds for q,ds in xs['core_domains']}==dict(ys['core_domains'])
 assert {c['center']^1:{k:v for k,v in c.items() if k!='center'} for c in xs['center_support']}=={c['center']:{k:v for k,v in c.items() if k!='center'} for c in ys['center_support']}
 assert sorted(q^1 for q in xs['empty_center_sites'])==ys['empty_center_sites']
 if ys['prepared_graph'] is not None:
  audit=ys['prepared_graph'];assert audit['factors']==38 and audit['labels']==32 and audit['all_labels_twice'] and {int(q):d for q,d in audit['site_degrees'].items()}==dict.fromkeys(range(16),8)
  sourcey={tuple(f['source']):f for f in audit['source_factors']}
  for f in xs['prepared_graph']['source_factors']:
   g=sourcey[f['source'][0]^1,f['source'][1]];shifted=[]
   for v in f['polynomial']:
    mask=v['mask'];sign=(-1)**sum(((mask>>(8*q))&255).bit_count()*((mask>>(8*(q^1)))&255).bit_count() for q in range(0,16,2));m=sum(((mask>>(8*q))&255)<<(8*(q^1)) for q in range(16));shifted.append((m,sign*v['real'],sign*v['imag']))
   assert sorted(shifted)==sorted((v['mask'],v['real'],v['imag']) for v in g['polynomial']) and {int(q)^1:d for q,d in f['degrees'].items()}=={int(q):d for q,d in g['degrees'].items()}
 else:assert y['raw_numerator']==y['peak_rows']==0
assert (225-empty,empty,negative,zero)==(25,200,52,0) and total==F(*b[-1]['coefficient'])==F(10367035518435041776795,7709672958021817718820298555392) and raw.denominator==1 and raw.numerator==b[-1]['raw_numerator']
assert max(x['peak_rows'] for x in bb)==b[-1]['peak_rows']==564 and b[-1]['preparation_seconds']==bp['seconds']<600 and b[-1]['whole225_warm_seconds']<60
files=[P/('l1-7981-fixed81-r4'+s) for s in ['.out','.err','.exit.json','-runner.py','-driver.py']];result={'verdict':'ACCEPT fixed81 original arithmetic and all225 physical XOR1/branch transpose covariance against accepted fixed79','checker_exit':0,'nonempty':25,'structural_empty':200,'negative_weights':52,'computedzeros':0,'fixed_coefficient':b[-1]['coefficient'],'peak':564,'cold_seconds':b[-1]['preparation_seconds'],'whole225warm_seconds':b[-1]['whole225_warm_seconds'],'parent_seconds':ex['parent_seconds'],'all225_transposed_raw_weight_D_fraction_equalities':True,'core_center_support_empty_source_mask_signed_covariance':True,'files_sha256':{str(p):sha(p) for p in files},'independent_originalL_prepared450_runtime':'UNRUN; prepared separately, fresh ROOT admission required','pilot_unrestricted':'NOT AUTHORIZED OR RUN'};(P/'l1-7981-independent-fixed-review-r4-transpose.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
