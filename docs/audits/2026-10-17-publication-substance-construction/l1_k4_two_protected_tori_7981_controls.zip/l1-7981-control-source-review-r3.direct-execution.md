# Actual DIRECT79/81 execution r3

TERMINAL PASS, handle97065, child/driver/tool exit0, no parent timeout; child13.440814s, parent13.509701s. First continuity check fresh/exit0. Ran exactly primary .venv/bin/python -B /tmp/l1-7981-control-preparation-r2-direct-driver.py from candidate. Original stdout/stderr/terminal receipt preserved unchanged; stderr empty, all output lines validJSON. Exact stream hashes and complete records in adjacent JSON.

Both79/81 passed joint4-edge/two-component F4 covariance, both nonidentity full source polynomials, all9 holonomies, square21samples/21components with activated offdiagonals,14 torus patterns,49 Cartesian225 checks and7 disconnected square-scalar closures each. Eight fixed singleton polynomial equalities and nine live singleton equalities passed; all nine live polynomials nonzero, actualcenter0/anchor1/globalframe1/edgelocal0. Original120000/3000000caps retained. No factor preparations, fixed scalar replays or unrestricted coefficients ran.

This is direct runtime evidence, pending independent receipt review. Independent original-L/all450 fixed79/81/transposed raw controls and fresh admission remain required before any pilot. No tracked/primary/notebook/Git/state/controller write or script repair occurred.
