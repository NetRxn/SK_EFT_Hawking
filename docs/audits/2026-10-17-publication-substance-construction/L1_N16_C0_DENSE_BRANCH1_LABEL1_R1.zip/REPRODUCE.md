# L1 group 128 opposite branch, assignment 1

Scientific source and prior acceptance pin: `2a5d3addb`. The 16 outer
coordinates cover the conditioned original parent. Choose the exact
contraction or signed transfer method from the author ledger. Each shift
or sign map is verified on its full raw inputs in the separate review.
All outer and inner weights are one. The original normalization is applied
once per terminal scalar.

From the extracted archive root, check the manifest and rerun the exact
author retally using the archived terminal logs and compact signed maps.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B author/roster/retally-assignment.py author/roster author/maps author/rescue0 author/rescue8 author/rescue12 | cmp - author/roster/author-complete.tsv
```

The independent signed ledgers cover 0–7 and 8–15, with independent
non-mapped evaluations for both heavy representatives. Large operands are
bound to their SHA-256 pins and original reconstruction sources.
Assignment 0 and complete group 128 remain open.
