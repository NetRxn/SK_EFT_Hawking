from ast import literal_eval
from csv import DictWriter
from fractions import Fraction as Q
from pathlib import Path
import re
import sys

root=Path(sys.argv[1])
maproot=Path(sys.argv[2])
direct={
 0:Path(sys.argv[3]),
 4:root/'rescue4',5:root/'rescue5',6:root/'rescue6',7:root/'rescue7',
 8:Path(sys.argv[4]),12:Path(sys.argv[5])
}
mapped={1:(0,maproot/'map.pkl.gz'), 2:(0,maproot/'map2/map.pkl.gz'),
        3:(0,maproot/'map3/map.pkl.gz'),
        **{i:(8,maproot/f'high{i}/map.pkl.gz') for i in (9,10,11)},
        **{i:(12,maproot/f'from12-{i}/map.pkl.gz') for i in (13,14,15)}}
def roster(d,axes,count,total):
    raw=(d/'s0.roster').read_bytes()
    sticks,labels=literal_eval(raw.decode())
    assert sticks==axes and len(labels)==len(dict(labels))==count
    assert sum(n for _,n in labels)==total
    return raw,sorted(labels,key=lambda row:(row[1],row[0]))
def exact(d,axes,counts,total):
    raw, terms=roster(d,axes,counts,total)
    values=[]
    for i,(coord,n) in enumerate(terms):
        assert (d/f's{i}.roster').read_bytes()==raw
        child=d/f'slice{i}'
        assert f'pilot {coord!r} matched {n} stored rows ' in (child/'partition.out').read_text()
        assert (child/'contraction.receipt').read_text().splitlines()[0]=='child_status 0'
        tail=(child/'contraction.out').read_text().splitlines()[-1]
        val=Q(re.fullmatch(r'exact normalized ([-\d/]+) peak rows \d+ matched products \d+',tail)[1])
        assert (val*40512224221827380280140849737629696*16*4**64).denominator==1
        values.append(val)
    return sum(values)
_,outer=roster(root,(('G',0,4,2),),16,2_377_728)
case_values={}
writer=DictWriter(sys.stdout,fieldnames=('slice','coordinate','products','method','real','imaginary'),delimiter='\t',lineterminator='\n')
writer.writeheader()
for i,(coord,n) in enumerate(outer):
    if i in direct:
        if i<8:
            value=exact(direct[i],(('G',1,5,2),),16,5_129_664)
        else:
            value=exact(direct[i],(('G',0,1,2),),9,13_160_448)
        method='direct nested roster'
    else:
        j,witness=mapped[i]
        assert witness.is_file()
        value=case_values[j]
        method=f'verified raw row map from {j}'
    case_values[i]=value
    writer.writerow(dict(slice=i,coordinate=coord,products=n,method=method,real=value,imaginary=0))
writer.writerow(dict(slice='total',real=sum(case_values.values()),imaginary=0))
