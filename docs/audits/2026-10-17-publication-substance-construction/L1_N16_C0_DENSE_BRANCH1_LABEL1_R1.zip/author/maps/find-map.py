from gzip import compress
from pathlib import Path
from pickle import dumps,loads
from runpy import run_path
import sys
source=Path('/private/tmp/l1-paired-reuse-screen.ugYgXU')
sys.path.insert(0,str(source))
from signed_gauge import search_gauge
verify=run_path(str(source/'verify-witnesses.py'))['verify']
verify.__globals__['N']=40512224221827380280140849737629696
left,right=map(Path,sys.argv[1:3])
A,B=(loads(path.read_bytes())['factors'] for path in (left,right))
print('sizes',[len(f[1]) for f in A],[len(f[1]) for f in B],flush=True)
witness,status=search_gauge(A,B)
if witness is None:
    print('inconclusive',repr(status)[:320],flush=True)
else:
    dest=Path('map.pkl.gz')
    assert status[0]=='original',status[0]
    dest.write_bytes(compress(dumps(witness,protocol=5),mtime=0))
    print('verified equivalence',verify(left,right,dest,True),flush=True)
