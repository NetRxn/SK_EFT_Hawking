from ast import literal_eval
from csv import DictReader
from fractions import Fraction as Q
from pathlib import Path

p=Path(__file__).resolve().parent
norm=40512224221827380280140849737629696*16*4**64
a=list(DictReader((p/'author/roster/author-complete.tsv').open(),delimiter='\t'))
assert len(a)==17 and a[-1]['slice']=='total'
author={int(r['slice']):r for r in a[:-1]}
assert tuple(author)==tuple(range(16))
low=list(DictReader((p/'independent/first8/verified-scalars.tsv').open(),delimiter='\t'))
assert low[-1]['outer']=='subtotal'
high=(p/'independent/last8/signed-ledger.tsv').read_text().splitlines()
assert high[0].split('\t')[-1]==str(norm)
start=next(i for i,x in enumerate(high) if x.startswith('outer_ordinal\t'))
peer=list(DictReader(high[start:-1],delimiter='\t'))
assert [int(r['outer']) for r in low[:-1]]==list(range(8))
assert [int(r['outer_ordinal']) for r in peer]==list(range(8,16))
cover={}
for r in low[:-1]+peer:
    if 'outer' in r:
        i=int(r['outer'])
        coordinate=(int(r['G042']),)
        projected=int(r['outer_products'])
        imag=int(r['raw_imaginary'])
        exact_imag=Q(r['normalized_imaginary'])
    else:
        i=int(r['outer_ordinal'])
        coordinate=literal_eval(r['coordinate'])
        projected=int(r['projected'])
        imag=int(r['raw_imag'])
        exact_imag=Q(r['normalized_imag'])
    assert coordinate==literal_eval(author[i]['coordinate'])
    assert projected==int(author[i]['products'])
    value=Q(int(r['raw_real']),norm)
    assert Q(r['normalized_real'])==Q(author[i]['real'])==value
    assert imag==exact_imag==Q(author[i]['imaginary'])==0
    cover[i]=value
low_sum=sum(cover[i] for i in range(8))
high_sum=sum(cover[i] for i in range(8,16))
assert low_sum==Q(low[-1]['normalized_real'])
assert high_sum==Q(high[-1].split('\t')[-2])
assert len(cover)==16 and sum(cover.values())==Q(a[-1]['real']) and Q(a[-1]['imaginary'])==0
print('0-7',low_sum,0,sep='\t')
print('8-15',high_sum,0,sep='\t')
print('total',sum(cover.values()),0,sep='\t')
