from common import *
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from collections import defaultdict
from itertools import combinations
from re import fullmatch
from sys import argv
from time import perf_counter,sleep

def contract(T):
    visited=0; top=0; history=[]
    F=list(T)
    while len(F)>1:
        forecasts=[]
        for i,j in combinations(range(len(F)),2):
            a,X,d=F[i];b,Y,e=F[j]
            shared=tuple(w for w in b if w in a)
            ic,jc=positions(a,shared),positions(b,shared)
            cx=Counter(project(k,ic) for k in X)
            cy=Counter(project(k,jc) for k in Y)
            q=sum(cy[k]*v for k,v in cx.items())
            forecasts.append((q,-i,-j,ic,jc))
        pred,i,j,ic,jc=min(forecasts)
        i,j=-i,-j
        assert pred<=2_000_000 and visited+pred<=6_000_000
        a,X,d=F[i];b,Y,e=F[j]
        xp=tuple(k for k in range(len(a)) if k not in ic)
        yp=tuple(k for k in range(len(b)) if k not in jc)
        scope=project(a,xp)+project(b,yp)
        left=defaultdict(list)
        for r,z in X.items():left[project(r,ic)].append((project(r,xp),z))
        totals={}
        hits=0
        for r,(u,v) in Y.items():
            out=project(r,yp)
            for head,(x,y) in left.get(project(r,jc),()):
                k=head+out
                a0,b0=totals.get(k,(0,0))
                totals[k]=(a0+u*x-v*y,b0+v*x+u*y)
                hits+=1
        assert hits==pred
        out={k:z for k,z in totals.items() if any(z)}
        assert len(out)<=1_000_000
        top=max(top,len(out))
        visited+=hits
        history.append((i,j,hits,len(out)))
        F=[x for n,x in enumerate(F) if n not in (i,j)]+[(scope,out,d*e)]
    a,X,d=F[0]
    assert not a and d==D and set(X)<={()}
    return *X.get((),(0,0)),visited,top,history

def evaluate(work):
    outer,i=work; start=perf_counter()
    folder=rescue(outer)
    p=folder/f'label-s{i}-reduced-frontier.pkl'
    while not (folder/f'slice{i}/contraction.receipt').exists():
        assert perf_counter()-start<240,(outer,i)
        sleep(1)
    T=read(p); F=validate(T)
    assert len(F)==5
    assert len(T['conditioning'])==1
    t=tuple(v for _,v in T['conditioning'])
    l,m,work,peak,history=contract(F)
    elapsed=perf_counter()-start
    text=(folder/f'slice{i}/contraction.out').read_text().splitlines()
    claim=fullmatch(r'exact normalized (\S+) peak rows (\d+) matched products (\d+)',text[-1])
    assert claim and (Fraction(l,N),Fraction(m,N))==(Fraction(claim[1]),Fraction(0))
    status=(folder/f'slice{i}/contraction.receipt').read_text()
    receipt=fullmatch(r'child_status 0\nelapsed_seconds (\S+)\npeak_child_rss_bytes (\d+)\n',status)
    assert receipt
    assert (folder/f'slice{i}/contraction.err').read_bytes()==b''
    assert sha(p)==sha(folder/f'slice{i}/dense-saturated-frontier.pkl')
    return outer,i,*t,l,m,Fraction(l,N),Fraction(m,N),work,peak,f'{elapsed:.6f}',claim[3],receipt[1],receipt[2],sha(p),repr(history).replace(' ','')

if __name__=='__main__':
    pairs=[(q,i) for q in (tuple(map(int,argv[1:])) or E) for i in range(16)]
    print('outer','inner','g152','raw_real','raw_imaginary','normalized_real','normalized_imaginary',
          'review_products','review_peak_rows','review_seconds','author_products','author_seconds','author_rss','terminal_sha256','review_schedule',sep='\t',flush=True)
    with ProcessPoolExecutor(max_workers=3) as pool:
        for r in pool.map(evaluate,pairs):print(*r,sep='\t',flush=True)
