from common import *
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run,STDOUT
from sys import executable,argv
from shutil import copyfile
from time import perf_counter
from re import fullmatch

def call(path,script,args,log,expected,rc,time):
    start=perf_counter()
    with (path/log).open('xb') as out:
        p=run([executable,'-B',str(Path(script).resolve()),*args],cwd=path,stdout=out,stderr=STDOUT,timeout=time)
    assert p.returncode==rc,(path,script,rc,p.returncode)
    assert sha(path/log)==sha(expected),(path,log)
    return perf_counter()-start

def origin():
    path=Path('lineage-origin')
    path.mkdir()
    p=A/'branch1-label1'
    for f in ('contract-with-peer.py','peer_pair.py'):
        copyfile(A/f,path/f)
    start=p/'dense-saturated-frontier.pkl'
    (path/start.name).symlink_to(start)
    elapsed=call(path,path/'contract-with-peer.py',[],'contraction.out',p/'contraction.out',2,150)
    q=path/'row-cap-physical-slice-dense-branch.pkl'
    assert sha(q)==sha(p/q.name)
    print('entire original contraction and refused envelope byte-identical',sha(q),elapsed,flush=True)

def setup(path,author):
    (path/'checkpoint').mkdir(parents=True)
    for name in ('checkpoint/quotient.py','contract-with-peer.py','exact-multicut.py','peer_pair.py','reduce-label-frontier.py'):
        copyfile(author/name,path/name)

def stage(scope,ordinal,outer,author,parent,terminal=False):
    path=Path(f'lineage-{scope}-{outer}-{ordinal}')
    setup(path,author)
    src=f's{ordinal}.pkl'
    tag=f's{ordinal}'
    label=f'label-{tag}-reduced-frontier.pkl'
    original=author/f'slice{ordinal}'
    report=[]
    if not terminal:
        elapsed=call(path,path/'exact-multicut.py',[str(parent),src,str(ordinal)],'partition.out',original/'partition.out',0,100)
        assert sha(path/src)==sha(author/src) and sha((path/src).with_suffix('.roster'))==sha((author/src).with_suffix('.roster'))
        report.append(('partition',elapsed,sha(path/src)))
    else:
        # Independent arithmetic and inverse lift verify the exact partition. Here replay reduction alone.
        (path/src).symlink_to(author/src)
    elapsed=call(path,path/'reduce-label-frontier.py',[src,tag],'reduce.out',original/'reduce.out',0,150)
    assert sha(path/label)==sha(author/label)==sha(original/'dense-saturated-frontier.pkl')
    report.append(('reduce',elapsed,sha(path/label)))
    if not terminal:
        (path/'dense-saturated-frontier.pkl').symlink_to((path/label).resolve())
        elapsed=call(path,path/'contract-with-peer.py',[],'contraction.out',original/'contraction.out',2,150)
        q=path/'row-cap-physical-slice-dense-branch.pkl'
        assert sha(q)==sha(original/q.name)
        report.append(('contract-cap',elapsed,sha(q)))
    for action,secs,h in report:print(outer,ordinal,scope,action,f'{secs:.6f}',h,sep='\t',flush=True)

if __name__=='__main__':
    name=argv[1]
    if name=='origin':
        origin()
    elif name=='outer':
        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(lambda n:stage('outer',n,n,R,A/'branch1-label1/row-cap-physical-slice-dense-branch.pkl'),C))
    else:
        data=[(n,m) for n in (tuple(map(int,argv[2:])) or E) for m in range(16)]
        with ThreadPoolExecutor(max_workers=3) as pool:
            list(pool.map(lambda p:stage('nested',p[1],p[0],rescue(p[0]),None,True),data))
