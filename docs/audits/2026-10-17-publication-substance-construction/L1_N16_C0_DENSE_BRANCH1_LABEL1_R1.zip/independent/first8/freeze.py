from common import *
from shutil import copyfile

records={}
def append(prefix,base):
    for p in base.rglob('*'):
        if p.is_file():records[p]=prefix/p.relative_to(base)
source=A/'branch1-label1'
append(Path('origin'),source)
for name in ('contract-with-peer.py','peer_pair.py','run-with-peer.py'):
    records[A/name]=Path('origin')/name
for name in ('contract-with-peer.py','peer_pair.py','reduce-label-frontier.py','exact-multicut.py','checkpoint/quotient.py','s0.roster'):
    records[R/name]=Path('outer')/name
raw=Path('/private/tmp/l1-dense-resume.bbZW6V/row-cap-physical-slice-dense-binary-1.pkl')
records[raw]=Path('origin')/raw.name
for n in C:
    for name in (f's{n}.pkl',f's{n}.roster',f'label-s{n}-reduced-frontier.pkl'):
        records[R/name]=Path('outer')/name
    append(Path(f'outer/slice{n}'),R/f'slice{n}')
    if n in E: append(Path(f'nested-{n}'),rescue(n))
for n in (1,2,3):
    src=M if n==1 else M/f'map{n}'
    records[src/'map.pkl.gz']=Path(f'maps/{n}/map.pkl.gz')
    if (src/'replay.out').is_file():
        records[src/'replay.out']=Path(f'maps/{n}/replay.out')
for n in (4,5,6,7):
    src=M/f'map{n}/replay.out'
    if src.is_file():records[src]=Path(f'maps/{n}/inconclusive.out')
with Path('source-operands.sha256').open('x') as out:
    for p,dst in sorted(records.items()):
        print(sha(p),p,sep='  ',file=out)
        if p.suffix!='.pkl':
            q=Path('author')/dst
            q.parent.mkdir(parents=True,exist_ok=True)
            copyfile(p,q)
