# Group 128 first-index branch 1, assignment 1, outer cuts 0–7

Each reviewed cut contributes **415494880211077147935/1298074214633706907132624082305024 + 0i**. Their disjoint eight-cut subtotal is **415494880211077147935/162259276829213363391578010288128 + 0i**.

| Outer cut | Original G(0,4,2) coordinate | Exact route |
| --- | ---: | --- |
| 0 | 18 | 16 independent Gaussian terminal replays |
| 1 | 20 | Complete signed five-factor map from cut 0 |
| 2 | 33 | Complete signed five-factor map from cut 0 |
| 3 | 40 | Complete signed five-factor map from cut 0 |
| 4 | 65 | 16 independent Gaussian terminal replays |
| 5 | 72 | 16 independent Gaussian terminal replays |
| 6 | 130 | 16 independent Gaussian terminal replays |
| 7 | 132 | 16 independent Gaussian terminal replays |

## Original branch and exact rosters

The source is pinned at publication checkpoint 2a5d3addb3096757c73269e62b3221497a700245. The archive for assignments 3–5 contains the assignment-1 parent operand inventory. The binary-reduction archive pins and contains the exact ten-factor branch-1 source. Independent enumeration checks all 256 available combinations on 12 label axes, yields exactly six factor-compatible joint assignments, and places each in the eight original projected label states. The exact signed assignment-1 inverse lift recovers 676,080 selected rows, including every Gaussian coefficient and individual factor denominator.

Replaying the source peer contractor from that selection reproduces the initial exact 404,352-product join and the nine-factor cap with forecast 2,377,728. Independent matched histograms recover 16 exhaustive G(0,4,2) coordinates with this total. Each reviewed coordinate has 99,072 products and 564,432 stored rows. The eight selected source envelopes are distinct and inverse-lift exactly. The 24 outer partition, reduction and guarded contraction stages reproduce the recorded bytes. Each ends at a five-factor row cap after four completed joins using 2,203,584 products, with 5,129,664 prospective products in the rejected join.

The second partition for direct cuts 0, 4, 5, 6 and 7 uses G(1,5,2) and has 16 feasible coordinates. The exact traffic per cut is 5,129,664 products, including eight coordinates with 212,664 matches and eight with 428,544 matches. All 80 signed inverse lifts and 80 source-to-terminal reductions are checked. The 80 pre-reduction inputs have distinct hashes. Their 48 distinct terminal contents include exact reduced-byte coincidences between cuts 4 and 6 and between cuts 5 and 7 at each matching inner value. Each was still contracted separately from its own author input. The author status ledgers cover indices 1–15 and the individual index-0 receipts complete each roster.

## Signed maps and exact terminal sums

For each cut 1–3, an independent checker indexes the actual two-endpoint wire incidence, enumerates the joint edge supports and verifies full domain and image of each witness. The map is bijective on each of 10 edge bundles across all 2,610 distinct bundle values, with identical application at both endpoints. It reconstructs every one of the 749,120 signed source rows as a distinct exact target row. It preserves the five individual denominators and verifies each sign multiplier. The three maps have 100, 42 and 58 negatively charged edge values, with 402,592, 109,536 and 504,064 sign-flipped rows, respectively. The two endpoint factors introduce the same sign on the same value, so each edge sign squares to one in every complete matched contraction term. Each map therefore transfers exactly the full accepted cut-0 scalar into its own distinct target. These witnesses are limited to the stated cap operands.

Each of the 80 independent direct scalar computations uses an exact minimum-product sparse schedule with reverse compatible-table traversal and separate real and imaginary integer accumulation. It imports no author contraction implementation. Each direct outer sum uses 3,629,968 reviewer products. The five raw real sums each equal 70601132737067600557461626204231665583811195951240247813079040 with imaginary zero. Direct Fraction addition and normalization of the exact raw sum give the same results. All author terminal values match. The exact source profile (503841882182,1461451755920) gives degree 32, world 136, cross 444, phase +1, factorial 16 and Haar denominator 4^64. The factor denominator product 40512224221827380280140849737629696 survives every stage. Each disjoint partition element has weight one and external normalization enters once.

This package closes the first eight of sixteen outer cuts for original assignment 1. The remaining eight outer cuts and the rest of the group require their own evidence.

## Reproduction

Run rosters.py, arithmetic.py, maps.py and retally.py with the frozen sources from the reviewer directory. Review the exact signed stage bytes with lineage.py in origin, outer and nested modes in fresh reviewer scratch. The per-term arithmetic ledger and roster files record each coordinate, raw value and input hash. Source-operands.sha256 binds the large pickles separately from the portable text and witness package.
