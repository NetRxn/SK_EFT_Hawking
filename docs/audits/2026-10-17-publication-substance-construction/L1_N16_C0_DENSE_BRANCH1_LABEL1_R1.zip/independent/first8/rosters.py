from common import *
from archives import archive,LATEST
from ast import literal_eval
from collections import defaultdict
from csv import DictReader
from hashlib import sha256
from itertools import product
from gzip import decompress
from math import factorial
from sys import argv
from time import perf_counter,sleep

P=Path('/private/tmp/l1-dense-resume.bbZW6V/row-cap-physical-slice-dense-binary-1.pkl')
AX_OUT=(('G',0,4,2),)
AX_IN=(('G',1,5,2),)
OUT_IDS=dict(enumerate((18,20,33,40,65,72,130,132)))

def check_norm():
    codes=(503841882182,1461451755920)
    occ=[o for o in product(range(5),repeat=3) if sum(o)<=4]
    layers=[[occ[(v>>(6*i))&63] for i in range(8)] for v in codes]
    edges=[(i,i^(1<<k),k) for i in range(8) for k in range(3) if ((i>>k)&1)==0]
    world=degree=exponent=0
    weight=1
    for m in layers:
        degree+=sum(map(sum,m))
        world+=sum(n*(3+i) for o in m for i,n in enumerate(o))
        weight*=prod(factorial(n) for o in m for n in o)
        v=[(u,w,sum(m[u])+sum(m[w])-m[u][k]-m[w][k]) for u,w,k in edges]
        exponent+=sum(a*b*sum(x>y for x in (u,w) for y in (s,t))
                      for i,(u,w,a) in enumerate(v) for s,t,b in v[i+1:])
    assert (degree,weight,world,exponent)==(32,16,136,444)
    assert (-1)**((world+exponent)%2)==1 and D*weight*4**(2*degree)==N
    print('original physical profile',codes,'total degree',degree,'factorial',weight,'world',world,'cross',exponent,'phase +1',
          'factor denominator',D,'normalizing denominator',N,flush=True)

def verify_rows(parent,target,fixed,byrow=False):
    for (a,X,d),(b,Y,e) in zip(parent,target,strict=True):
        assert d==e
        need=tuple((k,fixed[w]) for k,w in enumerate(a) if w in fixed)
        if not need:
            assert a==b and X==Y
            continue
        assert b==tuple(w for w in a if w not in fixed)
        expected={k:v for k,v in X.items() if all(k[j]==t for j,t in need)}
        found={}
        for row,z in Y.items():
            full=list(row)
            for pos,val in need:full.insert(pos,val)
            key=tuple(full)
            assert key not in found
            found[key]=z
        assert expected==found

def origin():
    archive(LATEST)
    z=archive("DENSE_BRANCH1_LABELS345")
    author_pins=z.read('author/parents/label1/operands.sha256').decode()
    source=A/'branch1-label1'
    for name in ('dense-saturated-frontier.pkl','row-cap-physical-slice-dense-branch.pkl'):
        got=sha(source/name)
        assert any(l.startswith(got) and l.endswith(name) for l in author_pins.splitlines()),(name,got,author_pins)
    h=sha(P)
    assert h=='4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be'
    binary=archive('DENSE_BINARY_REDUCTION')
    assert sha256(decompress(binary.read('branch128-binary-1-frontier.pkl.gz'))).hexdigest()==h
    doc=archive('DENSE_CONDITIONED_SCALARS')
    history=defaultdict(dict)
    for l in doc.read('author/checkpoint/independent/states.tsv').decode().splitlines():
        i,t,c,w,p,q=map(int,l.split()); history[i][('L',t,c,w)]=(p,q)
    o=read(P); fs=o['factors']
    assert len(fs)==10 and prod(d for _,_,d in fs)==D
    assert o['physical_cut']==L[0]
    all_axes=tuple(sorted({w for a,_,_ in fs for w in a if w[0]=='L'}))
    assert len(all_axes)==12
    parents=[]
    domain=defaultdict(list)
    for a,rows,d in fs:
        keep=tuple(w for w in a if w in all_axes)
        pos=positions(a,keep)
        table=Counter(project(row,pos) for row in rows)
        for i,w in enumerate(keep):domain[w].append({key[i] for key in table})
        parents.append((keep,table))
    choices=tuple(set.intersection(*domain[w]) for w in all_axes)
    assert Counter(map(len,choices))=={1:4,2:8}
    support=[]
    for k in product(*map(sorted,choices)):
        a=dict(zip(all_axes,k,strict=True))
        weights=tuple(r[tuple(a[w] for w in wid)] for wid,r in parents)
        if all(weights):support.append((tuple(a.items()),weights))
    valid={tuple(v[w] for w in all_axes) for v in history.values()}
    assert len(support)==6 and len(valid)==8 and {tuple(n for _,n in key) for key,_ in support}<=valid
    assignment,traffic=support[1]
    assert [n for n in (source/'support.out').read_text().splitlines() if n.startswith('exact surviving L assignment 1 ')]
    expect=[literal_eval(n.removeprefix('exact surviving L assignment 1 ')) for n in (source/'support.out').read_text().splitlines() if n.startswith('exact surviving L assignment 1 ')]
    assert expect==[p for p,_ in support]
    projected=read(source/'dense-saturated-frontier.pkl')
    assert projected['selected']==assignment
    selected=validate(projected)
    assert projected['used_before']==1143480==o['used_before']
    verify_rows(fs,selected,dict(assignment))
    assert tuple(len(t) for _,t,_ in selected)==traffic and sum(traffic)==676080
    print('PASS original full 256-combination support, 6 feasible, eight original projected, selected exact signed lift',
          assignment,traffic,sha(source/'dense-saturated-frontier.pkl'),flush=True)
    cap=read(source/'row-cap-physical-slice-dense-branch.pkl')
    assert len(validate(cap))==9
    assert cap['used_before']==404352 and cap['matched']==2377728
    return cap

def census(p,folder,axes,LEN,total,lo,hi):
    F=validate(p)
    text=(folder/'s0.roster').read_bytes()
    wa,ls=literal_eval(text.decode())
    assert wa==axes and len(ls)==len(dict(ls))==LEN
    a,b=[F[i] for i in p['rejected_pair']]
    A,X,_=a; B,Y,_=b
    joint=tuple(k for k in B if k in A)
    assert not set(joint)&set(axes)
    assert all(k in A for k in axes)
    grid=Counter(project(key,positions(A,joint))+project(key,positions(A,axes)) for key in X)
    y=Counter(project(key,positions(B,joint)) for key in Y)
    out=Counter()
    j=len(joint)
    for k,v in grid.items():
        if n:=y[k[:j]]:out[k[j:]]+=v*n
    assert dict(out)==dict(ls)
    assert sum(out.values())==total==p['matched'] and (min(out.values()),max(out.values()))==(lo,hi)
    order=sorted(out,key=lambda v:(out[v],v))
    return out,order,text

def selection(n,folder,i,state,axes,lot,order,ref):
    path=folder/f's{i}.pkl'
    tag=read(path)
    assert (folder/f's{i}.roster').read_bytes()==ref
    allowed=dict(zip(axes,order[i],strict=True))
    assert tag['conditioning']==state.get('conditioning',[])+list(allowed.items())
    p={k:v for k,v in state.items() if k!='factors'}
    q={k:v for k,v in tag.items() if k not in ('factors','conditioning')}
    assert {k:v for k,v in p.items() if k!='conditioning'}==q
    f=validate(tag)
    verify_rows(state['factors'],f,allowed)
    log=(folder/f'slice{i}/partition.out').read_text().splitlines()[-1]
    assert log==f'pilot {order[i]!r} matched {lot[order[i]]} stored rows {sum(len(t) for _,t,_ in f)}'
    return (n,i,*order[i],lot[order[i]],sum(len(t) for _,t,_ in f),sha(path))

def verify_nested(n,p):
    d=rescue(n)
    val=read(p)
    assert val['used_before']==2203584 and val['matched']==5129664
    assert len(validate(val))==5
    la,order,text=census(val,d,AX_IN,16,5129664,212664,428544)
    print('PASS distinct signed nested parent',n,sha(p),'complete axis roster',AX_IN,16,sum(la.values()),flush=True)
    output=[]
    for i in range(16):
        started=perf_counter()
        while not (d/f'slice{i}/contraction.receipt').exists():
            assert perf_counter()-started<240,(n,i)
            sleep(1)
        row=selection(n,d,i,val,AX_IN,la,order,text)
        output.append(row)
    with Path(f'roster-{n}.tsv').open('x') as f:
        print('outer','inner','g152','products','stored_rows','selected_sha256',sep='\t',file=f)
        for row in output:print(*row,sep='\t',file=f)
    print('PASS all exact signed inverse lifts',n,len(output),flush=True)

if __name__=='__main__':
    check_norm()
    state=origin()
    outer,order,text=census(state,R,AX_OUT,16,2377728,99072,198144)
    print('PASS exact complete outer roster',AX_OUT,order,16,sum(outer.values()),flush=True)
    for n in (tuple(map(int,argv[1:])) or C):
        assert order[n]==(OUT_IDS[n],)
        pp=selection(n,R,n,state,AX_OUT,outer,order,text)
        print('PASS exact outer selection',pp,flush=True)
        if n in E:
            verify_nested(n,R/f'slice{n}/row-cap-physical-slice-dense-branch.pkl')
