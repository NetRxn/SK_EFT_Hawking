from common import *
from rosters import OUT_IDS
from collections import defaultdict
from csv import DictReader
from fractions import Fraction as F
from pathlib import Path

def load_table(path):
    return list(DictReader(path.read_text().splitlines(),delimiter='\t'))

direct=defaultdict(list)
for r in load_table(Path('independent-terminal.tsv')):
    outer=int(r['outer'])
    direct[outer].append(r)
assert set(direct)==set(E)
unions=defaultdict(list)
selected=set()
values={}
for outer,terms in direct.items():
    folder=rescue(outer)
    lift=load_table(Path(f'roster-{outer}.tsv'))
    assert len(terms)==len(lift)==16
    batch={}
    for line in (folder/'batch.out').read_text().splitlines():
        i,status,value=line.split('\t')
        assert status=='child_status 0' and int(i) not in batch
        batch[int(i)]=value
    assert set(batch)==set(range(1,16))
    pointset=set()
    for i,(term,entry) in enumerate(zip(terms,lift,strict=True)):
        for key in ('outer','inner','g152'): assert term[key]==entry[key]
        assert int(term['inner'])==i and term['g152'] not in pointset
        pointset.add(term['g152'])
        h=term['terminal_sha256']
        unions[h].append((outer,i))
        picked=entry['selected_sha256']
        assert picked not in selected
        selected.add(picked)
        if i: assert batch[i]==(folder/f'slice{i}/contraction.out').read_text().splitlines()[-1]
        assert all(F(int(term[f'raw_{x}']),N)==F(term[f'normalized_{x}']) for x in ('real','imaginary'))
    raw=tuple(sum(int(t[f'raw_{x}']) for t in terms) for x in ('real','imaginary'))
    v=tuple(F(r,N) for r in raw)
    assert v==tuple(sum(F(t[f'normalized_{x}']) for t in terms) for x in ('real','imaginary'))
    assert sum(int(t['products']) for t in lift)==5129664
    values[outer]=(raw,v)
    print(outer,'direct independent 16 signed terms',*v,'raw',*raw,'review products',sum(int(t['review_products']) for t in terms),flush=True)
assert len(selected)==80 and len(unions)==48
paired={tuple(v) for v in unions.values() if len(v)>1}
assert paired=={((a,i),(b,i)) for a,b in ((4,6),(5,7)) for i in range(16)}
print('distinct selected operands',len(selected),'distinct terminal bytes',len(unions),
      'coincident reduced inputs 4/6 and 5/7 at same inner index, separately replayed',flush=True)
maps=load_table(Path('maps.tsv'))
assert [int(r['target']) for r in maps]==[1,2,3]
for row in maps:
    src,n=int(row['source']),int(row['target'])
    assert src==0 and n not in values and row['source_sha256']==sha(R/'slice0/row-cap-physical-slice-dense-branch.pkl')
    assert row['target_sha256']==sha(R/f'slice{n}/row-cap-physical-slice-dense-branch.pkl')
    assert row['witness_sha256']==sha((M/f'map{n}' if n>1 else M)/'map.pkl.gz')
    values[n]=values[src]
assert set(values)==set(C)
with Path('verified-scalars.tsv').open('x') as out:
    print('outer','G042','outer_products','method','raw_real','raw_imaginary','normalized_real','normalized_imaginary','cap_sha256',sep='\t',file=out)
    for i in C:
        raw,value=values[i]
        route='16 independently replayed' if i in E else 'complete signed map from cut 0'
        print(i,OUT_IDS[i],99072,route,*raw,*value,sha(R/f'slice{i}/row-cap-physical-slice-dense-branch.pkl'),sep='\t',file=out)
    raw_sum=tuple(sum(x[0][i] for x in values.values()) for i in (0,1))
    sum_v=tuple(F(x,N) for x in raw_sum)
    assert sum_v==tuple(sum(x[1][i] for x in values.values()) for i in (0,1))
    print('subtotal','-',99072*8,'8 disjoint outer cuts',*raw_sum,*sum_v,'-',sep='\t',file=out)
print('verified eight-cut subtotal',*sum_v,flush=True)
