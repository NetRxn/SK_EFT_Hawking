from common import *
from collections import defaultdict
from gzip import decompress
from pickle import loads
from time import perf_counter

def graph(factors):
    sides=defaultdict(list)
    for i,(a,X,d) in enumerate(factors):
        assert len(a)==len(set(a)) and d>0 and X
        for w in a:sides[w].append(i)
    edges=defaultdict(set)
    for w,p in sides.items():
        assert len(p)==2
        edges[tuple(p)].add(w)
    return dict(edges)

def compare(A,B,cert):
    idx,orig,target,mapping,neg=cert
    assert idx==tuple(range(5))
    Ea,Eb=graph(A),graph(B)
    assert set(Ea)==set(Eb)==set(mapping)==set(orig)==set(target)==set(neg)
    assert Ea=={k:set(v) for k,v in orig.items()}
    assert Eb=={k:set(v) for k,v in target.items()}
    assert all(len(v)==len(set(v.values())) for v in mapping.values())
    assert all(set(neg[k])<=set(v) for k,v in mapping.items())
    before=defaultdict(dict)
    after=defaultdict(dict)
    rows=flips=0
    for i,((a,X,d),(b,Y,e)) in enumerate(zip(A,B,strict=True)):
        assert d==e and len(X)==len(Y)
        spec=[]
        for k,table in mapping.items():
            if i not in k:continue
            q=positions(a,orig[k]); p=positions(b,target[k])
            inv=set(neg[k])
            before[k][i]={project(r,q) for r in X}
            after[k][i]={project(r,p) for r in Y}
            spec.append((q,p,table,inv))
        hit=set()
        for row,(u,v) in X.items():
            sign=1
            dst=[None]*len(b)
            for q,p,table,inv in spec:
                k=project(row,q)
                sign*=(-1 if k in inv else 1)
                for col,atom in zip(p,table[k],strict=True):
                    assert dst[col] is None
                    dst[col]=atom
            target_row=tuple(dst)
            assert None not in target_row and target_row not in hit
            assert Y[target_row]==(sign*u,sign*v) and (u or v)
            hit.add(target_row)
            rows+=1
            flips+=sign<0
        assert len(hit)==len(Y)
    for k,table in mapping.items():
        i,j=k
        assert set(table)==before[k][i]|before[k][j]
        assert set(table.values())==after[k][i]|after[k][j]
        for q in k:
            assert {table[p] for p in before[k][q]}==after[k][q]
            assert len(neg[k])==len(set(neg[k]))
    return len(A),len(mapping),sum(map(len,mapping.values())),sum(map(len,neg.values())),rows,flips

def cap(n):
    p=R/f'slice{n}'/'row-cap-physical-slice-dense-branch.pkl'
    state=read(p)
    F=validate(state)
    assert len(F)==5 and state['matched']==5129664 and 'conditioning' not in state
    return p,F

if __name__=='__main__':
    print('source','target','factors','edges','mapped_values','negative_values','signed_rows','flipped_rows','source_sha256','target_sha256','witness_sha256','seconds',sep='\t',flush=True)
    src,A=cap(0)
    for n in (1,2,3):
        start=perf_counter()
        dst,B=cap(n)
        witness=(M/f'map{n}' if n>1 else M)/'map.pkl.gz'
        statistics=compare(A,B,loads(decompress(witness.read_bytes())))
        assert statistics[:3]==(5,10,2610) and statistics[4]==749120
        print(0,n,*statistics,sha(src),sha(dst),sha(witness),f'{perf_counter()-start:.6f}',sep='\t',flush=True)
        del B
