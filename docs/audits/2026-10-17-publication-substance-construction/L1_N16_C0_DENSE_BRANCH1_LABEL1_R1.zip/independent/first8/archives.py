from hashlib import sha256
from io import BytesIO
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile

P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
H='2a5d3addb3096757c73269e62b3221497a700245'
SUBDIR=Path('docs/audits/2026-10-17-publication-substance-construction')
LATEST='DENSE_BRANCH1_LABEL2'
opened={}
def archive(name):
    if name not in opened:
        p=SUBDIR/f'L1_N16_C0_{name}_R1.zip'
        data=check_output(['git','-C',P,'show',f'{H}:{p}'])
        h=sha256(data).hexdigest()
        if name==LATEST: assert h=='915c9bf497925eb41d4906c2b02e0c734f950f6bd946e4a0f4ee727f20a29b53'
        assert h==sha256((P/p).read_bytes()).hexdigest()
        z=ZipFile(BytesIO(data))
        assert len(z.namelist())==len(set(z.namelist()))
        if 'manifest.sha256' in z.namelist():
            for line in z.read('manifest.sha256').decode().splitlines():
                hh,f=line.split(maxsplit=1)
                assert hh==sha256(z.read(f.removeprefix('./'))).hexdigest(),(name,f)
        print('verified source archive',H,p.name,h,flush=True)
        opened[name]=z
    return opened[name]
