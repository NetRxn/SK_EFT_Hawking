from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess
import sys
from time import perf_counter

prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
branch=prep/'branch1-label1'
author=Path('/private/tmp/l1-branch1-label1-roster.kxIvcb')
base=Path.cwd()/'byte-audit'
nested_only='--nested' in sys.argv
def compare(left,right):
    assert sha256(left.read_bytes()).digest()==sha256(right.read_bytes()).digest(),(left,right)
def stage(program,args,home,expected,code=0):
    target=home/expected.name
    start=perf_counter()
    with target.open('xb') as out:
        check=subprocess.run([sys.executable,'-B',str(program),*args],cwd=home,
                             stdout=out,stderr=subprocess.STDOUT,timeout=150)
    took=perf_counter()-start
    assert check.returncode==code,(home,expected,check.returncode)
    compare(target,expected)
    return took

for name in ('contract-with-peer.py','peer_pair.py'):
    compare(prep/name,author/name)
tools=base/'author-methods'
cap=base/'cap-replay'
name='row-cap-physical-slice-dense-branch.pkl'
if not nested_only:
    base.mkdir()
    tools.mkdir()
    (tools/'checkpoint').mkdir()
    for name in ('contract-with-peer.py','peer_pair.py','exact-multicut.py','reduce-label-frontier.py','checkpoint/quotient.py'):
        shutil.copyfile(author/name,tools/name)
    cap=base/'cap-replay'
    cap.mkdir()
    shutil.copyfile(branch/'sparse-label-pilot.pkl',cap/'dense-saturated-frontier.pkl')
    compare(cap/'dense-saturated-frontier.pkl',branch/'dense-saturated-frontier.pkl')
    assert (branch/'contraction.receipt').read_text().splitlines()[0]=='child_status 2'
    elapsed=stage(tools/'contract-with-peer.py',[],cap,branch/'contraction.out',2)
    compare(cap/name,branch/name)
    print('cap','contraction',2,f'{elapsed:.6f}',sep='\t',flush=True)
    
else:
    compare(cap/name,branch/name)
nested=[(int(i),Path((prep/f'label1-rescue{i}.path').read_text().strip())) for i in (8,12)]
def solve(item):
    family, location, source, i, status=item
    home=base/f'replay-{family}-lineage-{i}'
    home.mkdir()
    (home/'checkpoint').mkdir()
    for fname in ('contract-with-peer.py','peer_pair.py','exact-multicut.py',
                  'reduce-label-frontier.py','checkpoint/quotient.py'):
        if family!='outer' and fname=='exact-multicut.py':
            baseline=(tools/fname).read_text()
            expected=baseline.replace('while max(groups.values()) > 500_000:', 'while not positions:')
            assert expected!=baseline and (location/fname).read_text()==expected
        else:
            compare(location/fname,tools/fname)
        shutil.copyfile(location/fname,home/fname)
    tag=f's{i}'
    reference=location/f'slice{i}'
    prep_time=stage(home/'exact-multicut.py',[str(source),f'{tag}.pkl',str(i)],
                    home,reference/'partition.out')
    compare(home/f'{tag}.pkl',location/f'{tag}.pkl')
    compare(home/f'{tag}.roster',location/f'{tag}.roster')
    reduced=f'label-{tag}-reduced-frontier.pkl'
    reduce_time=stage(home/'reduce-label-frontier.py',[f'{tag}.pkl',tag],home,reference/'reduce.out')
    compare(home/reduced,location/reduced)
    shutil.copyfile(home/reduced,home/'dense-saturated-frontier.pkl')
    compare(home/'dense-saturated-frontier.pkl',reference/'dense-saturated-frontier.pkl')
    assert int((reference/'contraction.receipt').read_text().splitlines()[0].split()[-1])==status
    done_time=stage(home/'contract-with-peer.py',[],home,reference/'contraction.out',status)
    if status==2:
        leaf='join-cap-physical-slice-dense-branch.pkl'
        compare(home/leaf,reference/leaf)
    return family,i,status,prep_time,reduce_time,done_time

outer=[('outer',author,cap/name,i,2) for i in range(8,16)]
inner=[(f'nested{outer_i}',folder,folder/'partition-input.pkl',i,0)
       for outer_i,folder in nested for i in range(9)]
with ThreadPoolExecutor(max_workers=2) as pool:
    for label,i,status,*elapsed in pool.map(solve,inner if nested_only else outer+inner):
        for method,t in zip(('partition','reduce','contract'),elapsed,strict=True):
            print(label,i,method,(status if method=='contract' else 0),f'{t:.6f}',sep='\t',flush=True)
