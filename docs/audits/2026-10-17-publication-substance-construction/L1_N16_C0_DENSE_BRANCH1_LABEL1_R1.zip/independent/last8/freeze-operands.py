from hashlib import sha256
from pathlib import Path
import shutil

prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
branch=prep/'branch1-label1'
author=Path((prep/'label1-roster.path').read_text().strip())
maps=Path((prep/'label1-cap-equivalence.path').read_text().strip())
support=sorted(p for p in author.iterdir() if p.is_file() and p.suffix in ('.tsv','.out','.py','.pkl','.roster'))
inner=sorted(p for i in range(8,16) for p in (author/f'slice{i}').glob('*')
             if p.is_file() and p.suffix in ('.pkl','.out','.err','.receipt'))
data={
    'source': (prep,[prep/'read-support.py',prep/'rank-labels.py',prep/'contract-with-peer.py',prep/'peer_pair.py',
               prep/'verified-pin'/'label-1-branch-1.pkl',prep/'verified-pin'/'check-1.out',
               branch/'sparse-label-pilot.pkl',branch/'dense-saturated-frontier.pkl',
               branch/'row-cap-physical-slice-dense-branch.pkl',branch/'contraction.out',
               branch/'contraction.err',branch/'contraction.receipt',branch/'support.out',
               branch/'rank-labels.py',branch/'label-rank.out']),
    'outer':(author,support+inner+[author/'checkpoint/quotient.py']),
}
for anchor in (8,12):
    folder=Path((prep/f'label1-rescue{anchor}.path').read_text().strip())
    data[f'anchor{anchor}']=(folder,sorted(p for p in folder.rglob('*') if p.is_file()
                     and p.suffix in ('.pkl','.out','.tsv','.py','.roster','.receipt','.err')))
receipts=[maps/'find-map.py']
for name in [f'high{i}' for i in range(9,16)]+[f'from12-{i}' for i in (13,14,15)]:
    receipts.extend(sorted(p for p in (maps/name).glob('*') if p.is_file() and p.suffix in ('.out','.gz')))
data['maps']=(maps,receipts)
with Path('operands.sha256').open('w') as out:
    for family,(base,paths) in data.items():
        for src in paths:
            digest=sha256(src.read_bytes()).hexdigest()
            print(digest,src,sep='  ',file=out)
            if src.suffix=='.pkl':
                continue
            target=Path('author-receipts')/family/src.relative_to(base)
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,target)
