from ast import literal_eval
from collections import Counter
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from pickle import loads

prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
branch=prep/'branch1-label1'
author=Path('/private/tmp/l1-branch1-label1-roster.kxIvcb')
native=Path('/private/tmp/l1-dense-resume.bbZW6V/row-cap-physical-slice-dense-binary-1.pkl')
h=lambda p:sha256(p.read_bytes()).hexdigest()
assert h(native)=='4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be'
cap=branch/'row-cap-physical-slice-dense-branch.pkl'
assert h(cap)=='07894024cd2240ae1e5c5685f5cc92920e8a40c2565b0452342cca9aabcb27eb'
D=40512224221827380280140849737629696
def inverse_lift(before,after,fixed):
    for (scope,rows,d),(sliced,chosen,e) in zip(before,after,strict=True):
        assert d==e and sliced==tuple(k for k in scope if k not in fixed)
        positions=tuple((i,fixed[k]) for i,k in enumerate(scope) if k in fixed)
        keep=projection(scope,sliced)
        wanted={row:z for row,z in rows.items() if all(row[i]==v for i,v in positions)}
        actual={}
        for row,z in chosen.items():
            vals=dict(zip(sliced,row,strict=True))|fixed
            restored=tuple(vals[k] for k in scope)
            assert restored not in actual and keep(restored)==row
            actual[restored]=z
        assert actual==wanted
def degree(factors):
    return Counter(w for axes,_,_ in factors for w in axes)
def projection(axes,keys):
    idx=tuple(axes.index(k) for k in keys)
    return lambda row:tuple(row[i] for i in idx)
nested=Path('/private/tmp/l1-branch1-label1-rescue12.wDiQcz')
source=author/'slice12/join-cap-physical-slice-dense-branch.pkl'
assert h(source)=='9f51b63b5da1e456e7de53690f77f066a03f2b1d660c4d448ccb63828581e9ab'
leaf=loads(source.read_bytes())
partition=loads((nested/'partition-input.pkl').read_bytes())
assert leaf=={k:v for k,v in partition.items() if k not in ('rejected_pair','matched')}
F=leaf['factors']
assert len(F)==5 and set(degree(F).values())=={2}
assert leaf['physical_cut']==((('R',1,3,0,2,1),1),('complete-L-assignment',1))
def support(i,j):
    A,X,_=F[i]
    B,Y,_=F[j]
    shared=tuple(sorted(set(A)&set(B)))
    p,q=projection(A,shared),projection(B,shared)
    counts=Counter(map(q,Y))
    return sum(counts[p(row)] for row in X)
pairs={pair:support(*pair) for pair in __import__('itertools').combinations(range(5),2)}
assert min(pairs,key=pairs.__getitem__)==partition['rejected_pair']==(0,2)
assert pairs[0,2]==partition['matched']==13160448
axis=('G',0,1,2)
A,X,_=F[0]
B,Y,_=F[2]
edge=tuple(sorted(set(A)&set(B)))
assert axis in A and axis not in edge
p,q=projection(A,edge),projection(B,edge)
joint=Counter((row[A.index(axis)],p(row)) for row in X)
counts=Counter(map(q,Y))
weights=Counter()
for (v,z),n in joint.items():
    weights[v]+=n*counts[z]
weights=+weights
allowed=set.intersection(*({r[scope.index(axis)] for r in rows}
                           for scope,rows,_ in F if axis in scope))
assert set(weights)==allowed and len(allowed)==9 and sum(weights.values())==13160448
print('PASS minimum pair full support',sorted(pairs.items()))
print('PASS all nested G(0,1,2) values',sorted(weights.items()))
G=(nested/'s0.roster').read_bytes()
assert literal_eval(G.decode())==((axis,),[((v,),k) for v,k in sorted(weights.items())])
for i,v in enumerate(sorted(weights,key=lambda v:(weights[v],v))):
    raw=nested/f's{i}.pkl'
    child=loads(raw.read_bytes())
    clean=nested/f'label-s{i}-reduced-frontier.pkl'
    c=loads(clean.read_bytes())
    assert (nested/f's{i}.roster').read_bytes()==G
    assert child['conditioning']==c['conditioning']==[(axis,v)]
    assert child['physical_cut']==c['physical_cut']==leaf['physical_cut']
    inverse_lift(F,child['factors'],{axis:v})
    assert prod(d for _,_,d in child['factors'])==prod(d for _,_,d in c['factors'])==D
    assert set(degree(c['factors']).values())=={2}
    print('PASS exact nested lift',i,v,weights[v],h(raw),h(clean))
