from collections import Counter, defaultdict
from gzip import decompress
from hashlib import sha256
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import loads

base=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
roster=Path((base/'label1-roster.path').read_text().strip())
witnesses=Path((base/'label1-cap-equivalence.path').read_text().strip())
denominator=40512224221827380280140849737629696
physical=((('R',1,3,0,2,1),1),('complete-L-assignment',1))
def operand(i):
    return roster/f'slice{i}'/'join-cap-physical-slice-dense-branch.pkl'
def h(bits):
    return sha256(bits).hexdigest()

def verify(anchor,target,witness):
    raw_source=operand(anchor).read_bytes()
    raw_target=operand(target).read_bytes()
    x,y=loads(raw_source),loads(raw_target)
    assert x['physical_cut']==y['physical_cut']==physical
    X=x['factors']
    p=witness.read_bytes()
    perm,source_axes,target_axes,maps,negative=loads(decompress(p))
    assert sorted(perm)==list(range(5))
    Y=[y['factors'][i] for i in perm]
    assert len(X)==len(Y)==5
    assert prod(d for _,_,d in X)==prod(d for _,_,d in Y)==denominator
    assert set(Counter(a for scope,_,_ in X for a in scope).values())=={2}
    assert set(Counter(a for scope,_,_ in Y for a in scope).values())=={2}
    edges={ij for ij in combinations(range(5),2) if set(X[ij[0]][0])&set(X[ij[1]][0])}
    assert edges=={ij for ij in combinations(range(5),2) if set(Y[ij[0]][0])&set(Y[ij[1]][0])}
    assert edges==set(source_axes)==set(target_axes)==set(maps)
    assert set(negative)<=edges
    inverse={}
    charges={}
    for edge in edges:
        i,j=edge
        A,B=source_axes[edge],target_axes[edge]
        assert len(A)==len(set(A)) and len(B)==len(set(B))
        assert set(A)==set(X[i][0])&set(X[j][0])
        assert set(B)==set(Y[i][0])&set(Y[j][0])
        m=maps[edge]
        assert all(len(u)==len(A) and len(v)==len(B) for u,v in m.items())
        inv={v:u for u,v in m.items()}
        assert len(inv)==len(m) and m
        inverse[edge]=inv
        charged=set(negative.get(edge,()))
        assert charged<=set(m)
        charges[edge]=charged
    checked=flipped=0
    for i,((axes,A,D),(target_scope,B,E)) in enumerate(zip(X,Y,strict=True)):
        assert len(A)==len(B) and D==E
        assert all(any(z) for z in A.values()) and all(any(z) for z in B.values())
        blocks=[]
        src_positions=[]
        dst_positions=[]
        for edge in sorted(edges):
            if i not in edge:
                continue
            p1=tuple(axes.index(w) for w in source_axes[edge])
            p2=tuple(target_scope.index(w) for w in target_axes[edge])
            src_positions.extend(p1)
            dst_positions.extend(p2)
            blocks.append((edge,p1,p2,inverse[edge],charges[edge]))
            # Each incidence supplies its own projections; either endpoint may have extra local support.
            observed_x={tuple(row[j] for j in p1) for row in A}
            observed_y={tuple(row[j] for j in p2) for row in B}
            assert observed_x<=set(maps[edge]) and observed_y<=set(inverse[edge])
            assert {maps[edge][z] for z in observed_x}==observed_y
        assert sorted(src_positions)==list(range(len(axes)))
        assert sorted(dst_positions)==list(range(len(target_scope)))
        for row,(x,y) in B.items():
            recovered=[None]*len(axes)
            parity=0
            for edge,p1,p2,inv,charge in blocks:
                earlier=inv[tuple(row[k] for k in p2)]
                for k,v in zip(p1,earlier,strict=True):
                    recovered[k]=v
                parity^=earlier in charge
            assert A[tuple(recovered)]==((-x,-y) if parity else (x,y))
            checked+=1
            flipped+=parity
    for edge,m in maps.items():
        union=set()
        for i in edge:
            axes,rows,_=X[i]
            positions=tuple(axes.index(k) for k in source_axes[edge])
            union.update(tuple(row[k] for k in positions) for row in rows)
        assert union==set(m)
    print(anchor,target,len(X),len(edges),sum(map(len,maps.values())),sum(map(len,charges.values())),
          checked,flipped,h(raw_source),h(raw_target),h(p),witness,
          sep='\t',flush=True)

print('anchor','target','factors','edges','edge_values','signed_values','checked_rows','flipped_rows','anchor_sha256','target_sha256','witness_sha256','witness',sep='\t')
for source,dest,folder in [(8,n,f'high{n}') for n in (9,10,11)]+[(12,n,f'from12-{n}') for n in (13,14,15)]:
    path=witnesses/folder/'map.pkl.gz'
    assert path.is_file()
    verify(source,dest,path)
