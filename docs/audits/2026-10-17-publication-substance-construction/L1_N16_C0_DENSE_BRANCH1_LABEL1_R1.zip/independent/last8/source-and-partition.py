from ast import literal_eval
from collections import Counter
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from pickle import loads

prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
branch=prep/'branch1-label1'
author=Path('/private/tmp/l1-branch1-label1-roster.kxIvcb')
native=Path('/private/tmp/l1-dense-resume.bbZW6V/row-cap-physical-slice-dense-binary-1.pkl')
h=lambda p:sha256(p.read_bytes()).hexdigest()
assert h(native)=='4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be'
cap=branch/'row-cap-physical-slice-dense-branch.pkl'
assert h(cap)=='07894024cd2240ae1e5c5685f5cc92920e8a40c2565b0452342cca9aabcb27eb'
root=loads(native.read_bytes())
original=[(axes,rows,d) for axes,rows,d in root['factors']]
assert root['physical_cut']==(('R',1,3,0,2,1),1) and len(original)==10

def degree(factors):
    return Counter(w for axes,_,_ in factors for w in axes)
def projection(axes,keys):
    idx=tuple(axes.index(k) for k in keys)
    return lambda row:tuple(row[i] for i in idx)
wire_set=sorted(k for k in degree(original) if k[0]=='L')
views=[]
for scope,rows,d in original:
    keys=tuple(k for k in scope if k[0]=='L')
    views.append((keys,set(map(projection(scope,keys),rows))))
domains=[]
for k in wire_set:
    allowed=[{row[keys.index(k)] for row in values} for keys,values in views if k in keys]
    domains.append(set.intersection(*allowed))
assert len(wire_set)==12 and all(d for d in domains)
compatible=[]
for values in product(*map(sorted,domains)):
    assignment=dict(zip(wire_set,values,strict=True))
    if all(tuple(assignment[k] for k in keys) in allowed for keys,allowed in views):
        compatible.append(tuple(assignment.items()))
assert len(compatible)==6 and len(set(compatible))==6
prefix='exact surviving L assignment 1 '
records=[literal_eval(line.removeprefix(prefix)) for line in (branch/'support.out').read_text().splitlines() if line.startswith(prefix)]
assert records==compatible
print('PASS full native L census',len(compatible))
for label,assignment in enumerate(compatible):
    print('L assignment',label,assignment)

fixed=dict(compatible[1])
reduced=loads((branch/'sparse-label-pilot.pkl').read_bytes())
proof=loads((prep/'verified-pin/label-1-branch-1.pkl').read_bytes())
assert reduced['selected']==compatible[1]
assert reduced['physical_cut']==(root['physical_cut'],('complete-L-assignment',1))
assert reduced['used_before']==root['used_before']==1_143_480
assert reduced['factors']==proof['factors']
assert len(reduced['factors'])==10 and sum(len(rows) for _,rows,_ in reduced['factors'])==676080
def inverse_lift(before,after,fixed):
    for (scope,rows,d),(sliced,chosen,e) in zip(before,after,strict=True):
        assert d==e and sliced==tuple(k for k in scope if k not in fixed)
        positions=tuple((i,fixed[k]) for i,k in enumerate(scope) if k in fixed)
        keep=projection(scope,sliced)
        wanted={row:z for row,z in rows.items() if all(row[i]==v for i,v in positions)}
        actual={}
        for row,z in chosen.items():
            vals=dict(zip(sliced,row,strict=True))|fixed
            restored=tuple(vals[k] for k in scope)
            assert restored not in actual and keep(restored)==row
            actual[restored]=z
        assert actual==wanted
inverse_lift(original,reduced['factors'],fixed)
shape=degree(reduced['factors'])
assert not any(k[0]=='L' for k in shape) and set(shape.values())=={2}
print('PASS complete L label1 inverse lift, stored rows',sum(len(rows) for _,rows,_ in reduced['factors']))

state=loads(cap.read_bytes())
assert state['physical_cut']==reduced['physical_cut'] and state['used_before']==404352
f=state['factors']
assert len(f)==9 and set(degree(f).values())=={2}
axis=('G',0,4,2)
selected=[scope for scope,_,_ in f if axis in scope]
assert len(selected)==2
i,j=state['rejected_pair']
assert(i,j)==(0,1)
A,X,_=f[i]
B,Y,_=f[j]
shared=tuple(sorted(set(A)&set(B)))
assert axis in A and axis not in shared
restricted=set.intersection(*({row[scope.index(axis)] for row in rows}
                              for scope,rows,_ in f if axis in scope))
first=projection(A,shared)
second=projection(B,shared)
left=Counter((row[A.index(axis)],first(row)) for row in X)
right=Counter(map(second,Y))
traffic=Counter()
for (value,key),n in left.items():
    traffic[value]+=n*right[key]
traffic=+traffic
assert set(traffic)==restricted and len(traffic)==16
assert sum(traffic.values())==state['matched']==2377728
assert (min(traffic.values()),max(traffic.values()))==(99072,198144)
print('PASS complete disjoint G cut',axis,sorted(traffic.items()))
roster=(author/'s0.roster').read_bytes()
assert literal_eval(roster.decode())==((axis,),[((k,),n) for k,n in sorted(traffic.items())])
ordered=sorted(traffic,key=lambda key:(traffic[key],key))
D=40512224221827380280140849737629696
for i,value in enumerate(ordered):
    raw=author/f's{i}.pkl'
    r=loads(raw.read_bytes())
    clean=author/f'label-s{i}-reduced-frontier.pkl'
    c=loads(clean.read_bytes())
    assert (author/f's{i}.roster').read_bytes()==roster
    assert r['conditioning']==c['conditioning']==[(axis,value)]
    assert r['physical_cut']==c['physical_cut']==state['physical_cut']
    inverse_lift(f,r['factors'],{axis:value})
    assert prod(d for _,_,d in r['factors'])==prod(d for _,_,d in c['factors'])==D
    assert set(degree(r['factors']).values())==set(degree(c['factors']).values())=={2}
    print('PASS exact lifted case',i,value,traffic[value],h(raw),h(clean))

nested=Path('/private/tmp/l1-branch1-label1-rescue8.Eb5iO0')
source=author/'slice8/join-cap-physical-slice-dense-branch.pkl'
assert h(source)=='98c335128a8edcf7b5767cad4a623a9ae2d415a48bb6ae74d8294a8f744a5db3'
leaf=loads(source.read_bytes())
partition=loads((nested/'partition-input.pkl').read_bytes())
assert leaf=={k:v for k,v in partition.items() if k not in ('rejected_pair','matched')}
F=leaf['factors']
assert len(F)==5 and set(degree(F).values())=={2}
assert leaf['physical_cut']==state['physical_cut']
def support(i,j):
    A,X,_=F[i]
    B,Y,_=F[j]
    shared=tuple(sorted(set(A)&set(B)))
    p,q=projection(A,shared),projection(B,shared)
    counts=Counter(map(q,Y))
    return sum(counts[p(row)] for row in X)
pairs={pair:support(*pair) for pair in __import__('itertools').combinations(range(5),2)}
assert min(pairs,key=pairs.__getitem__)==partition['rejected_pair']==(0,2)
assert pairs[0,2]==partition['matched']==13160448
axis=('G',0,1,2)
A,X,_=F[0]
B,Y,_=F[2]
edge=tuple(sorted(set(A)&set(B)))
assert axis in A and axis not in edge
p,q=projection(A,edge),projection(B,edge)
joint=Counter((row[A.index(axis)],p(row)) for row in X)
counts=Counter(map(q,Y))
weights=Counter()
for (v,z),n in joint.items():
    weights[v]+=n*counts[z]
weights=+weights
allowed=set.intersection(*({r[scope.index(axis)] for r in rows}
                           for scope,rows,_ in F if axis in scope))
assert set(weights)==allowed and len(allowed)==9 and sum(weights.values())==13160448
print('PASS minimum pair full support',sorted(pairs.items()))
print('PASS all nested G(0,1,2) values',sorted(weights.items()))
G=(nested/'s0.roster').read_bytes()
assert literal_eval(G.decode())==((axis,),[((v,),k) for v,k in sorted(weights.items())])
for i,v in enumerate(sorted(weights,key=lambda v:(weights[v],v))):
    raw=nested/f's{i}.pkl'
    child=loads(raw.read_bytes())
    clean=nested/f'label-s{i}-reduced-frontier.pkl'
    c=loads(clean.read_bytes())
    assert (nested/f's{i}.roster').read_bytes()==G
    assert child['conditioning']==c['conditioning']==[(axis,v)]
    assert child['physical_cut']==c['physical_cut']==leaf['physical_cut']
    inverse_lift(F,child['factors'],{axis:v})
    assert prod(d for _,_,d in child['factors'])==prod(d for _,_,d in c['factors'])==D
    assert set(degree(c['factors']).values())=={2}
    print('PASS exact nested lift',i,v,weights[v],h(raw),h(clean))
