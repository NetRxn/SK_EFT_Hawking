from collections import Counter
from decimal import Decimal
from pathlib import Path

lines=Path('lineage.tsv').read_text().splitlines()
assert len(lines)==79
assert lines[0].startswith('cap\tcontraction\t2\t')
cap=Decimal(lines[0].split('\t')[-1])
groups=Counter()
times=Counter()
seen=set()
for line in lines[1:]:
    family,i,stage,status,clock=line.split('\t')
    assert (family,i,stage) not in seen
    seen.add((family,i,stage))
    groups[family,stage,status]+=1
    times[family]+=Decimal(clock)
assert groups==Counter({('outer','partition','0'):8,('outer','reduce','0'):8,('outer','contract','2'):8,
                        ('nested8','partition','0'):9,('nested8','reduce','0'):9,('nested8','contract','0'):9,
                        ('nested12','partition','0'):9,('nested12','reduce','0'):9,('nested12','contract','0'):9})
report=Path('report-prefix.md').read_text()
checks=len(Path('operands-verify.out').read_text().splitlines())
report+=f"""
All 79 scoped stage commands reproduced bytes. The outer cap replay took {cap:.3f} s. The eight outer selector, reduction and cap groups took {times['outer']:.3f} s summed, and the nested anchors took {times['nested8']:.3f} and {times['nested12']:.3f} s summed under two workers. The first byte verifier stopped after the valid outer replay because it assumed identical selector source for the nested branches. The nested selector changes the threshold-driven loop to one explicitly selected axis. After checking this exact source difference and independently proving the nine-member supports, the reviewer replayed all 54 nested stages. The 18 independent terminal contractions took 45.995 s summed. All {checks} operand entries, the separately pinned native root and every portable manifest entry passed checksum readback.
"""
Path('REVIEW.md').write_text(report)
