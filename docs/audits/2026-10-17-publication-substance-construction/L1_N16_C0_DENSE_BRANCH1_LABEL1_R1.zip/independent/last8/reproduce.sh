#!/usr/bin/env bash
set -euo pipefail
prep=/private/tmp/l1-group128-branch1-preparation.SlDJuy
python3 -u source-and-partition.py > source-and-partition.out
python3 -u nested12-support.py > nested12-support.out
python3 -u lineage.py > lineage.tsv
for anchor in 8 12; do
 dir=$(<"$prep/label1-rescue$anchor.path")
 for i in {0..8}; do
  python3 -u independent-sparse.py "$i" "$dir/label-s$i-reduced-frontier.pkl" > "outer$anchor-slice-$i-replay.out"
 done
done
python3 -u inverse-signed-maps.py > signed-maps.tsv
python3 -u retally.py > signed-ledger.tsv
