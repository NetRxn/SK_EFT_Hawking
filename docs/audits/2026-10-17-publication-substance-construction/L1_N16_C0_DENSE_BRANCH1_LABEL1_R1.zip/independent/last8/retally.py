from ast import literal_eval
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial,prod
from pathlib import Path
from pickle import loads
import csv
import re

author=Path('/private/tmp/l1-branch1-label1-roster.kxIvcb')
codes=(503841882182,1461451755920)
modes=sorted((a,b,c) for a,b,c in product(range(5),repeat=3) if a+b+c<=4)
occ=[]
for code in codes:
    record=[]
    for site in range(8):
        code,digit=divmod(code,64)
        record.append(modes[digit])
    assert not code
    occ.append(record)
world=sum((k+3)*value for layer in occ for powers in layer for k,value in enumerate(powers))
# Count cross-site sign by scanning site groups weighted by their insertions.
cross=0
for layer in occ:
    prior=[0]*8
    for site in range(8):
        for k in range(3):
            if site & (2**k):
                continue
            peer=site+2**k
            weight=sum(layer[u][j] for u in (site,peer) for j in range(3) if j!=k)
            cross+=weight*(sum(prior[site+1:])+sum(prior[peer+1:]))
            prior[site]+=weight
            prior[peer]+=weight
phase=(-1)**((world+cross)%2)
P=[p for layer in occ for site in layer for p in site]
total_occ=sum(P)
multiplicity=prod(map(factorial,P))
assert (total_occ,multiplicity,phase)==(32,16,1)
N=40512224221827380280140849737629696
scale=N*multiplicity*4**(2*total_occ)
print('normalization','occupation',total_occ,'factorial',multiplicity,'quarters exponent',2*total_occ,'world',world,'cross',cross,'phase',phase,'positive denominator',scale,sep='\t')

source=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
stages={i:Path((source/f'label1-rescue{i}.path').read_text().strip()) for i in (8,12)}
def h(path):
    return sha256(path.read_bytes()).hexdigest()

inner={}
print('anchor','inner_ordinal','inner_coordinate','projected','operand_sha256','raw_real','raw_imag','exact_real','exact_imag','products','seconds',sep='\t')
for anchor in (8,12):
    root=stages[anchor]
    axes,rows=literal_eval((root/'s0.roster').read_text())
    assert axes==(('G',0,1,2),) and len(rows)==9
    roster=sorted(rows,key=lambda z:(z[1],z[0]))
    raw_total=[0,0]
    for i,((k,),count) in enumerate(roster):
        path=root/f'label-s{i}-reduced-frontier.pkl'
        branch=root/f'slice{i}'
        log=Path(f'outer{anchor}-slice-{i}-replay.out').read_text()
        assert f'operand {i} {h(path)} cut {[(axes[0],k)]}' in log.splitlines()
        a,b,d=map(int,re.search(r'^raw scalar (-?\d+) (-?\d+) factor denominator (\d+)$',log,re.M).groups())
        assert d==N
        real,imag=Fraction(phase*a,scale),Fraction(phase*b,scale)
        assert (branch/'contraction.receipt').read_text().splitlines()[0]=='child_status 0'
        z=(branch/'contraction.out').read_text().splitlines()[-1]
        exact,peak,products=re.fullmatch(r'exact normalized (\S+) peak rows (\d+) matched products (\d+)',z).groups()
        assert (real,imag)==(Fraction(exact),Fraction(0))
        work,time=re.search(r'^replay products (\d+) wall seconds (\S+)$',log,re.M).groups()
        print(anchor,i,k,count,h(path),a,b,real,imag,work,time,sep='\t')
        raw_total[0]+=a
        raw_total[1]+=b
    inner[anchor]=tuple(raw_total)
    print('anchor subtotal',anchor,*raw_total,*[Fraction(phase*a,scale) for a in raw_total],sep='\t')
assert h(stages[8]/'partition-input.pkl')!=h(stages[12]/'partition-input.pkl')

with open('signed-maps.tsv') as f:
    bindings={int(row['target']):row for row in csv.DictReader(f,delimiter='\t')}
assert set(bindings)=={9,10,11,13,14,15}
with (author/'author-complete.tsv').open() as f:
    ledger=list(csv.DictReader(f,delimiter='\t'))
assert len(ledger)==17
A,rows=literal_eval((author/'s0.roster').read_text())
assert A==(('G',0,4,2),) and len(rows)==16
points=sorted(rows,key=lambda z:(z[1],z[0]))
values=[]
print('outer_ordinal','coordinate','projected','anchor','signed_map_sha256','raw_real','raw_imag','denominator','normalized_real','normalized_imag',sep='\t')
def leaf(i):
    return author/f'slice{i}'/'join-cap-physical-slice-dense-branch.pkl'
for i in range(8,16):
    point,traffic=points[i]
    row=ledger[i]
    assert (int(row['slice']),literal_eval(row['coordinate']),int(row['products']))==(i,point,traffic)
    ref=8 if i<12 else 12
    assert h(leaf(i)) and int((author/f'slice{i}'/'contraction.receipt').read_text().splitlines()[0].split()[-1])==2
    if ref==i:
        assert row['method']=='direct nested roster'
        witness='direct'
    else:
        m=bindings[i]
        assert int(m['anchor'])==ref and row['method']==f'verified raw row map from {ref}'
        assert m['anchor_sha256']==h(leaf(ref)) and m['target_sha256']==h(leaf(i))
        assert int(m['checked_rows'])==962752
        witness=m['witness_sha256']
    a,b=inner[ref]
    normalized=(Fraction(phase*a,scale),Fraction(phase*b,scale))
    assert normalized==(Fraction(row['real']),Fraction(row['imaginary']))
    print(i,point,traffic,ref,witness,a,b,N,*normalized,sep='\t')
    values.append((a,b))
raw=tuple(map(sum,zip(*values,strict=True)))
sub=tuple(Fraction(phase*a,scale) for a in raw)
assert sub==tuple(sum(Fraction(row[k]) for row in ledger[8:16]) for k in ('real','imaginary'))
print('subtotal-8-through-15',*raw,N,*sub,sep='\t')
