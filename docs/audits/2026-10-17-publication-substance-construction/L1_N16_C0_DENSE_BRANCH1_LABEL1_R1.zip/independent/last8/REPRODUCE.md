# Reproduce original branch 1, L assignment 1, outer ordinals 8–15

Use scratch and the pinned operands in SOURCE_PINS.txt, native-operand.sha256 and operands.sha256. Author source, text receipts and all six signed certificates are under author-receipts. Large original tensors are bound by SHA256 and can be rebuilt from the archived native frontier.

Run bash reproduce.sh with restored author inputs to reproduce the exact signed label restriction, full 16-member outer support and inverse lifts, the two nine-member nested subpartitions, all scoped contraction-stage bytes, 18 independent nested scalars and 6 inverse signed maps. The signed ledger records the exact signed raw value and normalized value for every scoped outer ordinal. The review does not evaluate outer ordinals 0–7.
