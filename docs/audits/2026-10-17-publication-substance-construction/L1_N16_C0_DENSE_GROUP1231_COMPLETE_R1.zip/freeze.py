"""Write the portable full signed review manifest."""
from hashlib import file_digest
from pathlib import Path

names=('REVIEW.md','retally.tsv','retally.out','cap.tsv','work.tsv','scalar.tsv','timing.tsv',
       'run-native.sh','run-continuation.sh','configure.py','retally.py','verify.py','source.py',
       'triangle_replay.py','audit_triangle.py','freeze.py','original-roster.txt','original-labels.tsv',
       'prepared-roster.tsv','zero-roster.tsv','geometry.tsv','reduce.out',
       'continuity.json','continuity-packet.json','continuity-r2.json','continuity-packet-r2.json',
       'checkpoint-delta.tsv','checkpoint-delta.out','latest-publication-head.txt',
       'group1231-source-geometry-independent.zip','source-freeze-verify.out','source-review-manifest.sha256')
needed=('frontier.sha256','preparation.time','intake-retally.out')
files=[*(Path(n) for n in names),*(Path('source-receipts')/n for n in needed),*(f for f in Path('author').rglob('*') if f.is_file())]
with Path('review-manifest.portable.sha256').open('w') as out:
    for p in sorted(files):
        with p.open('rb') as f:
            h=file_digest(f,'sha256').hexdigest()
        print(h,p,sep='  ',file=out)
