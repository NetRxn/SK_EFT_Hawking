#!/bin/sh
set -eu
label="$1"
source="/private/tmp/l1-geometry-group1231.s1YbrG/cached-original-roster/L${label}"
result="author/L${label}"
python3 -B configure.py "$label"
cp "$source"/{contraction.out,contraction.receipt,contraction.err,condition.py,joint-label-roster.tsv,preparation.out} "$result/"
/usr/bin/time -p python3 -B -u source.py "$label" > "$result/native-replay.out" 2> "$result/native-replay.time"
