"""Pin the currently frozen original-ordinal seed and guarded cap."""
from hashlib import file_digest
from pathlib import Path
import json,re,sys
case=int(sys.argv[1])
r=Path('prepared-roster.tsv').read_text().splitlines()[1:]
records={int(i):(int(rows),int(peak)) for i,_,rows,peak in map(lambda q:q.split('\t'),r)}
a=Path('/private/tmp/l1-geometry-group1231.s1YbrG/cached-original-roster')/f'L{case}'
def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
cap,forecast=map(int,re.search(r'open row cap (\d+) (\d+) frontier saved',(a/'contraction.out').read_text()).groups())
rows,peak=records[case]
data={'rows':rows,'peak':peak,'cap_factors':cap,'native_refused':forecast,
      'seed_sha':sha(a/'dense-saturated-frontier.pkl'),'cap_sha':sha(a/'row-cap-physical-slice-dense-branch.pkl')}
cap_path=Path(f'author/L{case}/pins.json')
if cap_path.exists():
    assert all(json.loads(cap_path.read_text())[k]==v for k,v in data.items())
if len(sys.argv)>2:
    n=int(sys.argv[2])
    d=a/f'pass{n}-result.pkl'
    data.update(terminal_sha=sha(d),passes=n)
    report=(a/f'pass{n}.out').read_text()
    match=re.search(r'exact raw scalar \((-?\d+), (-?\d+)\)',report)
    if match: data.update(expected_raw=int(match[1]),expected_imag=int(match[2]),mode='scalar')
    else: data.update(mode=sys.argv[3])
cap_path.parent.mkdir(parents=True,exist_ok=True)
cap_path.write_text(json.dumps(data,indent=2)+'\n')
