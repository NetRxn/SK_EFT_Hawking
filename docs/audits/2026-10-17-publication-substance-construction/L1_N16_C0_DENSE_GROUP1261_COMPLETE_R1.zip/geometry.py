"""Reconcile the assigned original group and its accepted geometric cover coefficient."""
from ast import literal_eval
from csv import DictReader
from itertools import product
from pathlib import Path
import json

def one(path):
    with Path(path).open() as f: yield from DictReader(f,delimiter='\t')

def main():
    group=1261
    comp,=[r for r in one('source-receipts/components.tsv') if r['id']=='98']
    A=set(literal_eval(comp['selected_side'])); B=set(literal_eval(comp['other_side']))
    assert group in A and comp['kind']=='K8,8' and len(A)==len(B)==8 and not A&B
    edges={(int(r['source_canonical']),int(r['target_canonical'])):int(r['full_assignment_count'])
           for r in one('source-receipts/ordered-edges.tsv')}
    assert {k:n for k,n in edges.items() if k[0] in A|B or k[1] in A|B}=={
        (a,b):2 for a,b in [*product(A,B),*product(B,A)]}
    pairs={int(r['canonical']):int(r['gamma3_partner']) for r in one('source-receipts/gamma-pairs.tsv')}
    norm,=one('source-receipts/accepted-1231-geometry.tsv')
    assert (norm['component'],norm['selected_class'])==('98','K8,8')
    phase,divisor,weight,c,g=map(int,(norm[x] for x in ('phase','physical_divisor','source_weight','chirality_factor','geometry_factor')))
    assert (phase,divisor,weight,c,g)==(1,2**132,48,2,2)
    prep=json.loads(Path('source-receipts/result.json').read_text())
    assert prep['group']==group and prep['remaining_ordinals']==[0,1,2,3,4,6] and prep['proved_zero_ordinals']==[5,7]
    full=weight*c*g
    assert full==int(comp['whole_pair_weight'])==192
    with Path('geometry.tsv').open('w') as out:
        print('group','component','selected_class','partner','phase','physical_divisor','source_weight','chirality_factor','geometry_factor','full_cover_weight',sep='\t',file=out)
        print(group,98,'K8,8',pairs[group],phase,divisor,weight,c,g,full,sep='\t',file=out)
    print('Group 1261 original chirality partner',pairs[group],'component 98 exact cover coefficient',full)

if __name__=='__main__':
    main()
