"""Write a relative manifest for the full original Group 1261 review."""
from hashlib import file_digest
from pathlib import Path

names=('REVIEW.md','retally.tsv','retally.out','cap.tsv','work.tsv','scalar.tsv','timing.tsv',
       'run-native.sh','run-continuation.sh','configure.py','retally.py','verify.py','source.py',
       'triangle_replay.py','audit_triangle.py','freeze.py','original-roster.txt','original-labels.tsv',
       'prepared-roster.tsv','zero-roster.tsv','geometry.tsv','geometry.py','geometry.out',
       'continuity.json','continuity-packet.json','checkpoint-delta.tsv','checkpoint-delta.out',
       'source-archives.tsv','prepared-verify.log','group1231-verify.log','geometry-verify.log','source1231-verify.log')
files=[*(Path(n) for n in names),*Path('source-receipts').glob('*'),*(f for f in Path('author').rglob('*') if f.is_file())]
for pattern in ('continuity-r2.json','continuity-packet-r2.json'):
    files.extend(Path('.').glob(pattern))
with Path('review-manifest.portable.sha256').open('w') as out:
    for p in sorted(files):
        with p.open('rb') as f:
            h=file_digest(f,'sha256').hexdigest()
        print(h,p,sep='  ',file=out)
