from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from subprocess import CompletedProcess
from scripts.validation.checks import bundles_readiness as b

with TemporaryDirectory() as base:
    p=Path(base)
    d=p/'L3'
    d.mkdir()
    tex=d/'paper_draft.tex'
    tex.write_text('\n'.join((
      r'\begin{figure}[t] ordinary \end{figure}',
      r'\begin {figure*}[t] double width \end{figure*}',
      r'% \begin{figure} commented ordinary \end{figure}',
      r'text % \begin{figure*} inline commented double \end{figure*}',
      r'\%  text \begin{figure} escaped percent \end{figure}',
      r'\begin{table*} unrelated \end{table*}',
    )))
    (d/'paper_draft.pdf').write_bytes(b'%PDF-1.4')
    with patch.object(b._H,'PAPERS_DIR',p),patch.object(b,'_read_metadata',return_value={'length_target':{'unit':'word_equivalents'}}),patch('shutil.which',return_value='/fixture/pdftotext'),patch('subprocess.run',return_value=CompletedProcess([],0,stdout='four words in output')):
        got=b._measure_manuscript('L3')
        assert got==(904,'word_equivalents','3 figure(s) at 300 words each'),got
        print(got)
