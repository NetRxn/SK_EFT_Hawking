import json
import re
import subprocess
import sys
from pathlib import Path

from scripts.validation.checks import bundles_readiness as b

mode=sys.argv[1]
root=Path.cwd()/'papers'/'L3'
tex=root/'paper_draft.tex'
pdf=root/'paper_draft.pdf'
meta=json.loads((root/'bundle_metadata.json').read_text())['length_target']
t=subprocess.run(['pdftotext',str(pdf),'-'],check=True,text=True,capture_output=True).stdout
body=len(t.split())
noncomments='\n'.join(line.split('%',1)[0] for line in tex.read_text().splitlines() if not line.lstrip().startswith('%'))
ordinary=noncomments.count(r'\begin{figure}')
starred=noncomments.count(r'\begin{figure*}')
assert (body,ordinary,starred)==(2663,0,1)
actual=b._measure_manuscript('L3')
n=1 if mode=='patched' else 0
assert actual==(body+300*n,'word_equivalents',f'{n} figure(s) at 300 words each')
assert meta['venue_ceiling']==3750 if 'venue_ceiling' in meta else 3750 in meta.values()
print(json.dumps(dict(mode=mode,rendered_pdf_words=body,ordinary_figures=ordinary,
    starred_figures=starred,actual_counter=actual,declared_target=meta),indent=2))
