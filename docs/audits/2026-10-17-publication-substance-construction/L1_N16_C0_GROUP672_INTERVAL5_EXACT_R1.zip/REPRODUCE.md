# Exact signed interval within original L1 group 672

Source pin `a1243a0f6`. The input is the 14-factor cap from the earlier
smallest row interval, listed as block 5 in the exact fiber-split archive.
Its operand SHA-256 is
`aa79757eb63a437cadb3de4ef8f4c2e6abebc0b1c449be09f9515a743261a208`.

Author logs and operand hashes pin the original complete signed inverse
factor splits, exact quotients, bounded joins, row-limit refusals and final
four-factor input. The two exact complementary closures have separate
product and support-probe receipts. The recorded result is a factor-scope
raw value at the inherited denominator. Complete original G block, J child,
group and physical source results require further independent evidence.

Check the archive and replay the compact exact arithmetic receipt:

```sh
shasum -a 256 -c SHA256SUMS
python3 -B author/verified-arithmetic-scope.py | cmp - author/verified-arithmetic-scope.tsv
```

The independent source and arithmetic review retains its own checksums and
the commands used for full inverse and exact terminal replay.
