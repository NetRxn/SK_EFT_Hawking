from split672 import *
from time import perf_counter
from pickle import dump

def fold(F,G,axes):
    A,X,d=F;B,Y,e=G
    pa,pb=[pos(ax,axes) for ax in (A,B)]
    ag=tuple(w for w in A if w not in axes); bg=tuple(w for w in B if w not in axes)
    va,vb=pos(A,ag),pos(B,bg)
    L,R=defaultdict(dict),defaultdict(dict)
    for k,z in X.items():L[pull(k,pa)][pull(k,va)]=z
    for k,z in Y.items():R[pull(k,pb)][pull(k,vb)]=z
    keyset=L.keys()&R.keys()
    bucket={}
    ans={}
    X1={};Y1=defaultdict(lambda:(0,0))
    for k in sorted(keyset):
        seq=tuple(sorted(L[k].items()))
        ys,zs=zip(*seq)
        normalized,scale=primitive(zs)
        assert tuple(mul(v,scale) for v in normalized)==zs
        signature=(ys,normalized)
        j=bucket.setdefault(signature,k)
        ans[k]=j,scale
        if j==k:
            for key,v in zip(ys,normalized,strict=True): X1[j+key]=v
    if len(bucket)==len(L)==len(R):
        return F,G,0
    for k,(j,scale) in ans.items():
        for suffix,z in R[k].items():
            key=j+suffix
            a,b=Y1[key]
            c,d0=mul(z,scale)
            Y1[key]=a+c,b+d0
    return (axes+ag,X1,d),(axes+bg,{k:z for k,z in Y1.items() if any(z)},e),len(keyset)-len(bucket)

def folds(F):
    trace=[]
    for sweep in range(2):
        for i,j in combinations(range(len(F)),2):
            A,B=F[i],F[j]
            common=tuple(w for w in A[0] if w in B[0])
            if not common:continue
            f,g,x=fold(A,B,common)
            g,f,y=fold(g,f,common)
            before,after=compatible(A,B),compatible(f,g)
            if x+y or before!=after:
                print('exact Gaussian quotient',sweep,i,j,before,'to',after,'merged fibers',x,y,'rows',len(f[1]),len(g[1]),flush=True)
                trace.append((sweep,i,j,before,after,x,y))
            F[i],F[j]=f,g
    return trace

if __name__=='__main__':
    start=perf_counter()
    st=read(Path('unsharded-pilot30.pkl'))
    F=list(st['factors'])
    assert len(F)==4 and prod(d for _,_,d in F)==N
    report=folds(F)
    scores=[]
    for i,j in combinations(range(4),2):scores.append((compatible(F[i],F[j]),i,j))
    print('post-fold actual costs',sorted(scores),flush=True)
    nexts={**st,'factors':F,'exact_folds':tuple(report),'fold_predecessor':sha(Path('unsharded-pilot30.pkl'))}
    with Path('unsharded-pilot30-fold.pkl').open('xb') as f:dump(nexts,f,protocol=5)
    print('quotient residual',sha(Path('unsharded-pilot30-fold.pkl')),'seconds',round(perf_counter()-start,6),flush=True)
