from split672 import split,read,sha,N
from collections import Counter
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import dump
from sys import argv
from time import perf_counter

source=Path(argv[1])
out=Path(argv[2])
assert sha(source)==argv[3]
state=read(source)
F=state['factors']
labels=state['factor_labels']
assert len(F)==8 and len(labels)==len(F)
assert prod(d for _,_,d in F)==N
assert set(Counter(w for a,_,_ in F for w in a).values())=={2}
start=perf_counter()
next_label=max(i for i,j in labels)+1
aux=1+max(w[1] for a,_,_ in F for w in a if w[0]=="exact-fiber-split")
new={}
trace=[]
for i,(axes,rows,den) in enumerate(F):
    label=labels[i]
    peers={j:set(axes)&set(b) for j,(b,_,_) in enumerate(F) if j!=i and set(axes)&set(b)}
    best=None
    for count in (1,2):
        if len(peers)<=count: continue
        for subset in combinations(peers,count):
            selected=set().union(*(peers[j] for j in subset))
            for invert in (False,True):
                retained=tuple(w for w in axes if (w in selected)!=invert)
                a,b,_=split(F[i],aux+i,retained)
                size=len(a[1])+len(b[1])
                candidate=(size,retained)
                if best is None or size<best[0]:best=candidate
            if best is not None and best[0]*8<=len(rows):break
        if best is not None and best[0]*8<=len(rows):break
    if best is not None and best[0]*2<len(rows):
        a,b,k=split(F[i],aux+i,best[1],verify=True)
        left,right=(next_label,0),(next_label,1)
        next_label+=1
        new[left],new[right]=a,b
        trace.append((label,left,right,len(rows),len(a[1]),len(b[1]),k))
        print('exact inverse',trace[-1],'elapsed',perf_counter()-start,flush=True)
    else:
        new[label]=F[i]
        print('retained',label,len(rows),best[0] if best else None,'elapsed',perf_counter()-start,flush=True)
assert prod(d for _,_,d in new.values())==N
assert set(Counter(w for a,_,_ in new.values() for w in a).values())=={2}
with out.open('xb') as f:
    dump({**state,'factors':list(new.values()),'factor_labels':tuple(new),
          'resplit_trace':trace,'resplit_predecessor':sha(source)},f,protocol=5)
print('verified factorization',len(new),'factors',sum(len(rows) for _,rows,_ in new.values()),'rows',sha(out),flush=True)
