from split672 import *
from fractions import Fraction
from functools import lru_cache
from time import perf_counter
from sys import argv
from resource import getrusage,RUSAGE_SELF
from math import prod

P=Path(argv[1])
H=argv[2]
MAX_PROBES=30_000_000
MAX_CACHE=120_000
def axes(a,b):return tuple(w for w in a if w in b)

def closure(F,I,J):
    start=perf_counter()
    a,b,c,d=[F[x] for x in (*I,*J)]
    A,X,m=a;B,Y,n=b;C,Z,o=c;D,V,p=d
    J0=axes(A,B);J1=axes(C,D)
    U0=axes(A,C);U1=axes(B,C)
    V0=axes(A,D);V1=axes(B,D)
    assert len(J0)+len(U0)+len(V0)==len(A)
    assert len(J0)+len(U1)+len(V1)==len(B)
    assert len(J1)+len(U0)+len(U1)==len(C)
    assert len(J1)+len(V0)+len(V1)==len(D)
    # Mark each complete outward key with an integer ID. Unknown projections have no completion.
    def adj(sc,T,outer):
        out=defaultdict(dict)
        i=pos(sc,outer);j=pos(sc,J1)
        for row,z in T.items():
            k,h=pull(row,i),pull(row,j)
            assert h not in out[k]
            out[k][h]=z
        by={k:i for i,k in enumerate(out)}
        return by,tuple(out.values())
    ids2,P2=adj(C,Z,U0+U1)
    ids3,P3=adj(D,V,V0+V1)
    l=sum(len(t) for t in P2); r=sum(len(t) for t in P3)
    assert (l,r)==(len(Z),len(V))
    probes=0
    visits=0
    fused=0
    completions=0
    def share(x,y):
        nonlocal probes,completions
        U,V=P2[x],P3[y]
        if len(U)>len(V):U,V=V,U
        probes+=len(U)
        assert probes<=MAX_PROBES,('probe guard',probes,visits)
        a0,b0=0,0
        for key,z in U.items():
            if (v:=V.get(key)) is not None:
                a1,b1=mul(z,v)
                a0+=a1
                b0+=b1
                completions+=1
        return a0,b0
    once=lru_cache(maxsize=MAX_CACHE)(share)
    def parts(a,T,out0,out1):
        s,j,k=(pos(a,e) for e in (J0,out0,out1))
        return ((pull(row,s),pull(row,j),pull(row,k),z) for row,z in T.items())
    partsR=defaultdict(list)
    for k,t,u,z in parts(B,Y,U1,V1): partsR[k].append((t,u,z))
    norm=(0,0)
    a0,b0=0,0
    forecast=compatible(a,b)[0]
    assert forecast<=8_000_000
    for k,l2,l3,z in parts(A,X,U0,V0):
        for r2,r3,w in partsR[k]:
            visits+=1
            i=ids2.get(l2+r2)
            if i is None:continue
            j=ids3.get(l3+r3)
            if j is None:continue
            fused+=1
            v=once(i,j)
            if any(v):
                x,y=mul(mul(z,w),v)
                a0+=x;b0+=y
    assert visits==forecast
    return a0,b0,visits,fused,probes,completions,once.cache_info(),round(perf_counter()-start,6)

if __name__=='__main__':
    assert sha(P)==H
    O=read(P);F=O['factors']
    assert len(F)==4 and prod(d for _,_,d in F)==N
    assert set(Counter(w for a,t,d in F for w in a).values())=={2}
    I=tuple(map(int,argv[3:5]))
    assert len(I)==2 and len(set(I))==2 and set(I)<=set(range(4))
    J=tuple(i for i in range(4) if i not in I)
    data=closure(F,I,J)
    print('exact raw scoped interval',H,'pair',I,J,'raw',*data[:2],'factor denominator',N,flush=True)
    print('pair products, constraint-retained pairs, dot probes, four-row completions at cache misses, cache, seconds',*data[2:],
          'peak rss bytes',getrusage(RUSAGE_SELF).ru_maxrss)
