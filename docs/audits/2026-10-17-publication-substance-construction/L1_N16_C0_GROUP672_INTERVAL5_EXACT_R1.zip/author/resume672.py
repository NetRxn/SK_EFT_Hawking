from split672 import compatible, joined, read, sha, N
from collections import Counter
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import dump
from sys import argv
from time import perf_counter

source=Path(argv[1])
out=Path(argv[2])
assert sha(source)==argv[3]
data=read(source)
factors=data['factors']
assert prod(d for _,_,d in factors)==N
assert set(Counter(w for a,_,_ in factors for w in a).values())=={2}
labels=dict(zip(data['factor_labels'],factors,strict=True))
assert len(labels)==len(factors)
last=max(i for i,_ in labels)
checks={}
for i,j in combinations(labels,2):
    value=compatible(labels[i],labels[j])
    if value: checks[i,j]=value
work=0
trace=[]
refused=set()
started=perf_counter()
for step in range(40):
    candidate=[(count*(width+1)**2,count,width,i,j)
               for (i,j),(count,width,_) in checks.items()
               if i[0]!=j[0] and (i,j) not in refused
               and 0<count<=8_000_000 and count+work<=20_000_000]
    if not candidate or len(labels)==1 or perf_counter()-started>180:
        break
    _,count,width,i,j=min(candidate)
    result,visited=joined(labels[i],labels[j],count)
    work+=visited
    if result is None:
        refused.add((i,j))
        print('row refusal',i,j,count,visited,flush=True)
        continue
    assert visited==count and len(result[0])==width
    label=(last+step+1,0)
    labels.pop(i)
    labels.pop(j)
    checks={k:v for k,v in checks.items() if i not in k and j not in k}
    for k,factor in labels.items():
        value=compatible(factor,result)
        if value: checks[k,label]=value
    labels[label]=result
    entry=(i,j,label,count,len(result[1]),width)
    trace.append(entry)
    print('exact join',entry,'remaining',len(labels),'work',work,'seconds',perf_counter()-started,flush=True)
assert prod(k for _,_,k in labels.values())==N
assert all(n==2 for n in Counter(w for a,_,_ in labels.values() for w in a).values())
if len(labels)==1:
    ax,rows,den=next(iter(labels.values()))
    assert ax==() and den==N
    print('raw scoped subnetwork scalar',rows.get((),(0,0)),den,flush=True)
else:
    print('open factors',len(labels),'work',work,'next exact forecasts',
          sorted((value,i,j) for (i,j),value in checks.items() if i[0]!=j[0])[:16],flush=True)
with out.open('xb') as f:
    dump({**data,'factors':list(labels.values()),'factor_labels':tuple(labels),
          'resume_trace':trace,'resume_work':work,'resume_predecessor':sha(source)},f,protocol=5)
print('elapsed',perf_counter()-started,'output sha256',sha(out),flush=True)
