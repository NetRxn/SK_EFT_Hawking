from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

root=Path(__file__).resolve().parent
source_hash='aa79757eb63a437cadb3de4ef8f4c2e6abebc0b1c449be09f9515a743261a208'
last='022169f0e4d96f9d36453cf8a9843e5bbfd99251852eada157a28a1562b3b1e1'
pair_receipts=[]
for name in ('close672-13.out','close672-01.out'):
    text=(root/name).read_text()
    r,i,d=map(int,re.search(r'\braw (-?\d+) (-?\d+) factor denominator (\d+)',text).groups())
    assert last in text and d==576173855599322741762003196268511232
    pair_receipts.append((r,i,d))
assert pair_receipts[0]==pair_receipts[1]
r,i,d=pair_receipts[0]
print('source',source_hash,sep='\t')
print('terminal input',last,sep='\t')
print('raw real',r,sep='\t')
print('raw imaginary',i,sep='\t')
print('factor denominator',d,sep='\t')
print('factor-scope exact real',Fraction(r,d),sep='\t')
accepted=0
for trace_name in ('pilot.out','continued672.out','continued672-r2.out','continued672-r3.out','continued672-r4.out'):
    lines=(root/trace_name).read_text().splitlines()
    joins=[line for line in lines if line.startswith(('exact guarded unsharded join ','exact join '))]
    count=sum(literal_eval(line.split('join ',1)[1].split(' remaining ',1)[0])[3] for line in joins)
    accepted+=len(joins)
    print('accepted joins',trace_name,len(joins),count,sep='\t')
assert accepted==43
