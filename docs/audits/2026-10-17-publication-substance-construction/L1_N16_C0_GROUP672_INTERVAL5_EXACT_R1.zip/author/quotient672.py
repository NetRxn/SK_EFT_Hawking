from collections import Counter
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import dump
from runpy import run_path
from sys import argv
from time import perf_counter
from split672 import compatible, read, sha, N

fold=run_path('fold672-lib.py')['fold']
source=Path(argv[1])
out=Path(argv[2])
assert sha(source)==argv[3]
raw=read(source)
labels=raw['factor_labels']
F=dict(zip(labels,raw['factors'],strict=True))
start=perf_counter()
trace=[]
for left,right in (((19,0),(27,0)),((4,0),(5,1))):
    a,b=F[left],F[right]
    common=tuple(w for w in a[0] if w in b[0])
    assert common
    aa,bb,first=fold(a,b,common)
    bb,aa,second=fold(bb,aa,common)
    prior=compatible(a,b)
    after=compatible(aa,bb)
    assert aa[2]==a[2] and bb[2]==b[2]
    F[left],F[right]=aa,bb
    event=(left,right,prior,after,first,second)
    trace.append(event)
    print('exact fold',event,'seconds',perf_counter()-start,flush=True)
assert prod(d for _,_,d in F.values())==N
assert set(Counter(w for a,_,_ in F.values() for w in a).values())=={2}
with out.open('xb') as fd:
    dump({**raw,'factors':list(F.values()),'factor_labels':tuple(F),
          'quotient_trace':trace,'quotient_predecessor':sha(source)},fd,protocol=5)
print('quotient output',sha(out),'seconds',perf_counter()-start,flush=True)
