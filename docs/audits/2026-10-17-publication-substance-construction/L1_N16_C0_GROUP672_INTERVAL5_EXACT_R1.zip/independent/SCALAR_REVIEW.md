# Group 672 exact scalar for left-row interval 5

The independently replayed scoped Gaussian numerator is
`3509926069799187026593951974062879254428784546066270890491904 + 0i`
at the stored factor denominator
`576173855599322741762003196268511232`.
The scope is original joint-L assignment 7, J(1,1,2)=(1,),
G(0,6,0) in {81,88,193,200}, and left-row interval 5 [2437,2768).
Other intervals, assignment 7 in full, group 672, and the external
physical normalization require separate evidence.

The nested initial review supplies the archive-pinned 14-factor source and
independent inverse check for the first 28-factor split, the first join and
the following 16 joins. The exact 11-factor restart has 1,148,168 retained
signed rows and SHA-256
`505c0638932ce992207000b710c172289a454a01db6cdfc406388ff0e46f57a2`.
The audit keeps the three initial row-cap refusals.

The independent extension then reconstructed both bidirectional Gaussian
quotients using exact primitive-vector classes and scale transfer. The
first quotient merged 48 shared fibers in one direction and the second
pair was invariant. Every quotient row matched after named-axis alignment.
The generic quotient-first continuation left 11 factors at its row guards,
as recorded by its author receipt. The directed resplit has 22 factors.
All eleven factor-pair inverses reproduce their source rows, both Gaussian
components, support and denominator. A separate reversed-operand
contraction replay reproduced all 14 admitted joins and the exact eight
retained factors on
`6bb04e8607ae1d12756b7886cf45572af58ea54717aee33ae662842e52072e9d`.
This used 3,585,788 successful products and accounts for five further author
row refusals in the total 8,566,785 visits.

The R4 resplit independently reconstructed all eight original factors from
the sixteen new ones and its 101,150 rows preserve their finite auxiliary
class domains. Twelve signed joins used 3,287,272 products and matched
every row of the resulting four-factor state on
`022169f0e4d96f9d36453cf8a9843e5bbfd99251852eada157a28a1562b3b1e1`.
The stored outcome had 620,628 rows across four factors. The two staged
author row refusals are preserved as work receipts, for 5,351,290 visits
including refusals.

The terminal evaluation independently built degree-two support blocks,
visited the complete selected pair support, and summed exact Gaussian
complement dots. Both pairings, (1,3)×(0,2) and (0,1)×(2,3), reproduced
the corresponding author scalar. The pair visits were 2,846,016 and
2,954,880, within the 8-million limit. The independent schedules used
11,583,570 and 13,963,344 complement probes, below the 30-million cap.
Cache, probe and join limits stayed
in place. No physical index was further conditioned within this
interval. The exact signed scalar is therefore the whole stored interval
term, without additional external physical normalization or rescaling.

Large binary operands are identified in SHA-256 manifests and required
separately for full reproduction. Later scoped refusals have their author
receipts. All accepted mathematical transformations and both terminal
pairings have independent arithmetic receipts.
