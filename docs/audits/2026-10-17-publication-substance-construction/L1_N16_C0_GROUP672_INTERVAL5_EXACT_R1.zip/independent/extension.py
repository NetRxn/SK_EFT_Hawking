from collections import Counter,defaultdict
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from math import gcd,prod
from pathlib import Path
from pickle import loads
from re import search,M,findall
from sys import argv
from time import monotonic

N=576173855599322741762003196268511232
author=Path('/private/tmp/l1-group672-exact-unsharded-pilot.AooTRr')
origin=Path('/private/tmp/l1-group672-factor1-split.NRGgZS/multifiber/row-cap-physical-slice-dense-branch.pkl')
class RowLimit(Exception): pass

started=monotonic()
def read(p):
    b=p.read_bytes()
    return loads(b),sha256(b).hexdigest()
def mul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def positions(a,b):
    col=tuple(a.index(w) for w in b)
    return lambda key:tuple(key[j] for j in col)
def verify(f):
    assert all(s and d>0 and len(a)==len(set(a)) and all(any(v) for v in s.values()) for a,s,d in f)
    assert set(Counter(w for a,_,_ in f for w in a).values())<= {2}
    assert prod(d for _,_,d in f)==N
def join(f,g):
    a,x,d=f; b,y,e=g
    shared=tuple(sorted(set(a)&set(b)))
    external=tuple(sorted(set(a)^set(b)))
    aa=tuple(w for w in external if w in a)
    bb=tuple(w for w in external if w in b)
    P,Q=positions(a,shared),positions(b,shared)
    A,B=positions(a,aa),positions(b,bb)
    order=positions(aa+bb,external)
    hist=Counter(map(P,x))
    forecast=sum(hist[Q(k)] for k in y)
    assert forecast<=8_000_000
    buckets=defaultdict(list)
    for key,value in x.items():
        buckets[P(key)].append((A(key),value))
    out={}
    work=0
    for k,v in y.items():
        right=B(k)
        for left,z in buckets.get(Q(k),()):
            dest=order(left+right)
            old=out.get(dest,(0,0))
            rr,ii=mul(v,z)
            value=(old[0]+rr,old[1]+ii)
            if any(value): out[dest]=value
            else: out.pop(dest,None)
            work+=1
            if len(out)>500_000:raise RowLimit(work,len(out))
            if work%32768==0: assert monotonic()-started<180
    assert work==forecast
    return (external,out,d*e),work
def eq(x,y):
    a,r,d=x; b,s,e=y
    return d==e and set(a)==set(b) and {positions(a,b)(k):v for k,v in r.items()}==s

from ast import literal_eval

def pair_cost(F,G):
    a,x,_=F;b,y,_=G
    wires=tuple(sorted(set(a)&set(b)))
    if not wires:return None
    ax=Counter(map(positions(a,wires),x))
    by=Counter(map(positions(b,wires),y))
    return sum(ax[k]*by[k] for k in ax.keys()&by.keys()),len(set(a)^set(b)),len(ax.keys()&by.keys())

def fold(a,b,edge):
    A,X,d=a;B,Y,e=b
    al=tuple(w for w in A if w not in edge); bl=tuple(w for w in B if w not in edge)
    p,q,s,t=positions(A,edge),positions(B,edge),positions(A,al),positions(B,bl)
    L,R=defaultdict(dict),defaultdict(dict)
    for k,v in X.items():L[p(k)][s(k)]=v
    for k,v in Y.items():R[q(k)][t(k)]=v
    both=L.keys()&R.keys()
    groups=defaultdict(list)
    for k in both:
        vec=L[k]
        c=gcd(*(n for z in vec.values() for n in z))
        assert c>0
        outs=sorted(vec)
        raw=[(vec[w][0]//c,vec[w][1]//c) for w in outs]
        i=max(range(4),key=lambda i:(raw[0],(-raw[0][1],raw[0][0]),
                                      (-raw[0][0],-raw[0][1]),(raw[0][1],-raw[0][0]))[i])
        rot=((1,0),(0,1),(-1,0),(0,-1))[i]
        normalized=tuple(zip(outs,(mul(z,rot) for z in raw),strict=True))
        scale=c*rot[0],-c*rot[1]
        assert {w:mul(v,scale) for w,v in normalized}==vec
        groups[normalized].append((k,scale))
    if len(groups)==len(L)==len(R):return a,b,0
    F={}
    H=defaultdict(lambda:[0,0])
    for v,items in groups.items():
        anchor=min(key for key,_ in items)
        F.update((anchor+k,z) for k,z in v)
        for key,scale in items:
            for p,w in R[key].items():
                rr,ii=mul(scale,w)
                H[anchor+p][0]+=rr;H[anchor+p][1]+=ii
    return (edge+al,F,d),(edge+bl,{k:tuple(z) for k,z in H.items() if any(z)},e),len(both)-len(groups)

prior,h0=read(author/'continued672.pkl')
quot,h1=read(author/'quotient672.pkl')
rs,h2=read(author/'resplit672.pkl')
out,h3=read(author/'continued672-r3.pkl')
assert h0=='505c0638932ce992207000b710c172289a454a01db6cdfc406388ff0e46f57a2'
assert h3=='6bb04e8607ae1d12756b7886cf45572af58ea54717aee33ae662842e52072e9d'
assert quot['quotient_predecessor']==h0 and rs['resplit_predecessor']==h1 and out['resume_predecessor']==h2
assert all(s['physical_cut']==prior['physical_cut'] for s in (quot,rs,out))
for s in (prior,quot,rs,out):verify(s['factors'])
stage=dict(zip(prior['factor_labels'],prior['factors'],strict=True))
for i,j,u,v,m,n in quot['quotient_trace']:
    a,b=stage[i],stage[j]
    assert pair_cost(a,b)==u
    edge=tuple(w for w in a[0] if w in b[0])
    a,b,first=fold(a,b,edge)
    b,a,second=fold(b,a,edge)
    assert (first,second)==(m,n) and pair_cost(a,b)==v
    stage[i],stage[j]=a,b
    print('exact two-sided fold',i,j,u,v,m,n,flush=True)
assert all(eq(a,b) for a,b in zip(stage.values(),quot['factors'],strict=True)) and tuple(stage)==quot['factor_labels']
print('independent quotient all rows',h1,flush=True)
split=dict(zip(rs['factor_labels'],rs['factors'],strict=True))
assert len(split)==22
for j,(label,a,b,n,m,k,classes) in enumerate(rs['resplit_trace']):
    F,G=split[a],split[b]
    _,x,d=F;_,y,e=G
    shared=set(F[0])&set(G[0])
    assert shared=={('exact-fiber-split',100+j)}
    A,B=positions(F[0],tuple(shared)),positions(G[0],tuple(shared))
    assert len(set(map(A,x)))==len(set(map(B,y)))==classes and set(map(A,x))==set(map(B,y))
    assert (len(x),len(y))==(m,k) and d==stage[label][2] and e==1
    z,worked=join(G,F)
    assert worked==n==len(stage[label][1])
    assert eq(z,stage[label])
    print('independent resplit inverse',label,a,b,n,m,k,classes,flush=True)
assert len(rs['resplit_trace'])==11
print('independent 22-factor signed resplit',h2,'rows',sum(len(r) for _,r,_ in split.values()),flush=True)
stage=split
work=0
for a,b,c,n,m,k in out['resume_trace']:
    z,cost=join(stage.pop(b),stage.pop(a))
    assert (cost,len(z[1]),len(z[0]))==(n,m,k)
    work+=cost
    assert work<=20_000_000
    stage[c]=z
    print('independent resumed join',a,b,c,n,m,k,flush=True)
assert tuple(stage)==out['factor_labels'] and all(eq(a,b) for a,b in zip(stage.values(),out['factors'],strict=True))
assert len(stage)==8 and len(out['resume_trace'])==14
text=(author/'continued672-r3.out').read_text()
refused=tuple(map(int,findall(r'^row refusal .+ (\d+)$',text,M)))
assert len(refused)==5 and sum(refused)+work==out['resume_work']
forecasts=sorted((q,a,b) for a,b in combinations(stage,2) if (q:=pair_cost(stage[a],stage[b])) is not None)
assert forecasts[:16]==literal_eval(search(r'^open factors 8 work 8566785 next exact forecasts (.+)$',text,M)[1])
print('independent eight-factor frontier',h3,'rows',sum(len(r) for _,r,_ in stage.values()),
      'accepted joins work',work,'with author refusals',out['resume_work'],'no scalar',flush=True)
print('exact next forecasts',forecasts[:16],flush=True)
print('seconds',round(monotonic()-started,6),flush=True)
