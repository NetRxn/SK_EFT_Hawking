from collections import Counter,defaultdict
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from math import gcd,prod
from pathlib import Path
from pickle import loads
from re import search,M,findall
from sys import argv
from time import monotonic

N=576173855599322741762003196268511232
author=Path('/private/tmp/l1-group672-exact-unsharded-pilot.AooTRr')
origin=Path('/private/tmp/l1-group672-factor1-split.NRGgZS/multifiber/row-cap-physical-slice-dense-branch.pkl')
class RowLimit(Exception): pass

started=monotonic()
def read(p):
    b=p.read_bytes()
    return loads(b),sha256(b).hexdigest()
def mul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def positions(a,b):
    col=tuple(a.index(w) for w in b)
    return lambda key:tuple(key[j] for j in col)
def verify(f):
    assert all(s and d>0 and len(a)==len(set(a)) and all(any(v) for v in s.values()) for a,s,d in f)
    assert set(Counter(w for a,_,_ in f for w in a).values())<= {2}
    assert prod(d for _,_,d in f)==N
def join(f,g):
    a,x,d=f; b,y,e=g
    shared=tuple(sorted(set(a)&set(b)))
    external=tuple(sorted(set(a)^set(b)))
    aa=tuple(w for w in external if w in a)
    bb=tuple(w for w in external if w in b)
    P,Q=positions(a,shared),positions(b,shared)
    A,B=positions(a,aa),positions(b,bb)
    order=positions(aa+bb,external)
    hist=Counter(map(P,x))
    forecast=sum(hist[Q(k)] for k in y)
    assert forecast<=8_000_000
    buckets=defaultdict(list)
    for key,value in x.items():
        buckets[P(key)].append((A(key),value))
    out={}
    work=0
    for k,v in y.items():
        right=B(k)
        for left,z in buckets.get(Q(k),()):
            dest=order(left+right)
            old=out.get(dest,(0,0))
            rr,ii=mul(v,z)
            value=(old[0]+rr,old[1]+ii)
            if any(value): out[dest]=value
            else: out.pop(dest,None)
            work+=1
            if len(out)>500_000:raise RowLimit(work,len(out))
            if work%32768==0: assert monotonic()-started<180
    assert work==forecast
    return (external,out,d*e),work
def eq(x,y):
    a,r,d=x; b,s,e=y
    return d==e and set(a)==set(b) and {positions(a,b)(k):v for k,v in r.items()}==s

def closure(f,I):
    J=tuple(j for j in range(4) if j not in I)
    factors=[f[j] for j in (*I,*J)]
    scopes=[u[0] for u in factors]
    def common(i,j):return tuple(sorted(set(scopes[i])&set(scopes[j])))
    def index(i,edge,out):
        scope,rows,_=factors[i]
        p,q=positions(scope,edge),positions(scope,out)
        assert len(edge)+len(out)==len(scope)
        result=defaultdict(dict)
        for k,val in rows.items():
            outer,inner=q(k),p(k)
            assert inner not in result[outer]
            result[outer][inner]=val
        return result
    left=common(0,1);right=common(2,3)
    X,Y=index(0,left,common(0,2)+common(0,3)),index(1,left,common(1,2)+common(1,3))
    U,V=index(2,right,common(0,2)+common(1,2)),index(3,right,common(0,3)+common(1,3))
    # Reindex the selected pair by its inner wire; use support blocks for the complement.
    def invert(table,n):
        out=defaultdict(list)
        for outer,inner in table.items():
            for k,z in inner.items():out[k].append((outer[:n],outer[n:],z))
        return out
    X,Y=invert(X,len(common(0,2))),invert(Y,len(common(1,2)))
    forecast=sum(len(X[k])*len(Y[k]) for k in X.keys()&Y.keys())
    assert forecast<=8_000_000,(I,forecast)
    probes=0;products=0
    @lru_cache(maxsize=120000)
    def dot(a,b):
        nonlocal probes,products
        AA,BB=U.get(a,{}),V.get(b,{})
        probes+=min(len(AA),len(BB))
        assert probes<=30_000_000
        rr=ii=0
        for v in AA.keys()&BB.keys():
            x,y=mul(AA[v],BB[v]);rr+=x;ii+=y;products+=1
        return rr,ii
    real=imag=visits=0
    for k in X.keys()&Y.keys():
        for a,b,z in X[k]:
            for c,d,w in Y[k]:
                u,v=mul(mul(z,w),dot(a+c,b+d));real+=u;imag+=v;visits+=1
                if visits%32768==0:assert monotonic()-started<120
    assert visits==forecast
    print('independent complementary closure',I,J,visits,probes,products,dot.cache_info(),flush=True)
    return real,imag
from ast import literal_eval
from re import findall
before,h0=read(author/'continued672-r3.pkl')
split,h1=read(author/'resplit672-r4.pkl')
out,h2=read(author/'continued672-r4.pkl')
assert h0=='6bb04e8607ae1d12756b7886cf45572af58ea54717aee33ae662842e52072e9d'
assert h2=='022169f0e4d96f9d36453cf8a9843e5bbfd99251852eada157a28a1562b3b1e1'
assert split['resplit_predecessor']==h0 and out['resume_predecessor']==h1
assert before['physical_cut']==split['physical_cut']==out['physical_cut']
for item in (before,split,out):verify(item['factors'])
original=dict(zip(before['factor_labels'],before['factors'],strict=True))
stage=dict(zip(split['factor_labels'],split['factors'],strict=True))
assert len(original)==8 and len(stage)==16
assert sum(len(r) for _,r,_ in stage.values())==101150
for i,(label,a,b,n,m,k,classes) in enumerate(split['resplit_trace']):
    F,G=stage[a],stage[b]
    wire=set(F[0])&set(G[0])
    assert len(wire)==1
    [w]=wire
    assert w not in original[label][0] and w[0]=='exact-fiber-split'
    P,Q=positions(F[0],(w,)),positions(G[0],(w,))
    assert len(set(map(P,F[1])))==classes and set(map(P,F[1]))==set(map(Q,G[1]))
    assert (len(F[1]),len(G[1]))==(m,k) and F[2]==original[label][2] and G[2]==1
    f,j=join(G,F)
    assert j==n==len(original[label][1]) and eq(f,original[label])
    print('independent R4 signed inverse',i,label,a,b,n,m,k,classes,flush=True)
assert len(split['resplit_trace'])==8
print('independent R4 split operand',h1,flush=True)
work=0
for a,b,c,n,m,k in out['resume_trace']:
    z,cost=join(stage.pop(b),stage.pop(a))
    assert (cost,len(z[1]),len(z[0]))==(n,m,k)
    work+=cost
    assert work<=20_000_000
    stage[c]=z
    print('independent R4 signed join',a,b,c,n,m,k,flush=True)
assert len(out['resume_trace'])==12 and len(stage)==4
assert tuple(stage)==out['factor_labels'] and all(eq(a,b) for a,b in zip(stage.values(),out['factors'],strict=True))
text=(author/'continued672-r4.out').read_text()
refused=tuple(map(int,findall(r'^row refusal .+ (\d+)$',text,M)))
assert len(refused)==2 and sum(refused)+work==out['resume_work']
print('independent R4 four-factor frontier',h2,'rows',sum(len(r) for _,r,_ in stage.values()),
      'accepted work',work,'with author refusals',out['resume_work'],flush=True)
answers={}
for tag,pair in (('13',(1,3)),('01',(0,1))):
    expected=search(r' raw (-?\d+) (-?\d+) factor denominator (\d+)',(author/f'close672-{tag}.out').read_text())
    a,b,d=map(int,expected.groups())
    assert (author/f'close672-{tag}.out').read_text().split()[4]==h2
    assert d==N
    value=closure(list(stage.values()),pair)
    assert value==(a,b)
    answers[pair]=value
assert len(set(answers.values()))==1
print('exact signed raw interval scalar',*next(iter(answers.values())),'factor denominator',N,
      'elapsed',round(monotonic()-started,6),flush=True)
