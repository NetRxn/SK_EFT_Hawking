from hashlib import file_digest
from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile,ZIP_DEFLATED

p=Path.cwd()
a=Path('/private/tmp/l1-group672-exact-unsharded-pilot.AooTRr')
names=('continued672.pkl','quotient672.pkl','continued672-r2.pkl','resplit672.pkl',
       'continued672-r3.pkl','resplit672-r4.pkl','continued672-r4.pkl',
       'quotient672.py','fold672-lib.py','quotient672.out','continued672-r2.out',
       'resplit672.py','resplit672.out','continued672-r3.out','resplit672-r4.py','resplit672-r4.out',
       'continued672-r4.out','close672.py','close672-13.out','close672-01.out')
source=[a/f for f in names]
def digest(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
receipts=p/'scalar-author-receipts'
receipts.mkdir()
with (p/'scalar-operands.sha256').open('x') as out:
    for f in source:
        print(digest(f),f,sep='  ',file=out)
        if f.suffix!='.pkl':copyfile(f,receipts/f.name)
files=[p/f for f in ('SCALAR_REVIEW.md','freeze-extension.py','extension.py','extension.out',
                      'terminal.py','terminal.out','scalar-operands.sha256','portable-review.zip')]
files.extend(sorted(receipts.iterdir()))
manifest=p/'scalar-review.sha256'
with manifest.open('x') as out:
    for f in files:print(digest(f),f.relative_to(p),sep='  ',file=out)
with ZipFile('portable-scalar-review.zip','x',ZIP_DEFLATED,compresslevel=6) as archive:
    for f in [*files,manifest]:archive.write(f,f.relative_to(p))
