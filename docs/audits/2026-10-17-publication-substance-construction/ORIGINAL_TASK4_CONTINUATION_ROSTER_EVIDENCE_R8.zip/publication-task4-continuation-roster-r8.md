# Original N16 Task4 fixed-center continuation roster R8

## Exact object

Fix the original closed word and source-C convention on the four-dimensional
L=2 carrier. Keep the original predecessor S2 at x=(0,0,0,0), later S2 at
y=x+e0, the two original raw contact slots at y, and the continuation center
w=x+e2. R7 fixed the continuation coframe T_(w,2,0). R8 computes the complete
fixed-center vector indexed by (mu,a) in {0,1,2,3}². Each component uses the
actual ordered coframe and the original signed quarter hopping blocks.

The full original action roster at w contains each component 48 times among
384 ordered S2 terms and six times among 24 S4 terms. These are occurrence
counts, not weights on an isolated coframe. The actual future source products
couple each occurrence to the other coframes and trace or epsilon. R8 retains
the component index as a coefficient label. It also evaluates separately
declared all-ones and phase-weighted contractions as collision controls. It does not identify the
all-ones contraction with an original action vertex. Linearity then also gives
any scalar component contraction on the tested fixed seam.

The selected product has a complete predecessor and later set of 72 live
grouped S2 choices each. It uses the same exterior generator order, two exact
g2 factors and original anchored q powers as R7. The literal raw contact is
J_(y,0,0) T_(y,0,0). The mixed raw contact uses
J_(y,0,0) (T_(y,0,0)+T_(y,1,0)). Exactly one factor supplies the
raw contact label. The two contact directions have distinct anchored support.

## Exact replay and incidence

The stream projects shared x factors, all 16 continuation factors and the
selected raw contact by target mask inclusion and exact multiset subtraction.
It streams the ordered factor product without accumulating a full predecessor
map. The R5 inverse later evaluator retains all possible choices, including
ordered two-bit splits and signed exterior inversions. It stores each exact
component, predecessor and later-group subtotal even when paths cancel.

The forward oracle independently uses Counter inclusion and canonical
ExteriorPolynomial products on only target-compatible rows. RawJet retains the
actual selected raw slot. It materializes target-compatible prefixes under the
prospective record and aggregate work caps, first separately and then adding
their signed contributions before the later multiplication for the all-ones
control. Exact branch/group agreement plus linearity covers every coefficient
of the indexed vector at the requested keys. R7 path counts and zero group
subtotals are checked explicitly under its fixed component restriction.

The anchor envelope enumerates the directed source incidence separately.
Every curvature monomial contributes its four distinct plaquette anchors.
Each coframe monomial contributes one of its two possible directed hopping
anchors. This includes all 16 continuation components, both source slots
and all compatible predecessor and later world-axis choices. The profile
remembers multiplicity of actual anchored q coordinates. Every profile
identifies a unique pair of curvature planes, continuation world direction
and contact world direction, even after adding continuation axes that remove
some R7 single-anchor witnesses. The calculation does not remove any
coordinates or apply Haar or exterior last-use closure.

## Measured evidence

Both evaluators matched all 52 exact targets, including all 32 R7 restricted
targets and one nonzero witness for every one of the 16 continuation
components. Four additional mixed direction-0 targets reproduce the literal
tables at the same exact anchored keys for each of the four continuation
directions. Mixed direction 1 is witnessed at all four continuation directions.
The 52 tables contain 136 overlaps between nonzero component subtotals at
the same later group. The all-ones contraction retains those overlaps.
At one genuine overlapping target in each raw slot, weights (1,-i) on
components (2,0) and (2,1) cancel the complete coefficient. Reversing the
phase gives respectively i/32 and -i/32. The forward oracle applies these
weights before adding the prefixes and independently verifies both outcomes.
Two wrong anchored J queries give zero paths. A zero-work query refuses
before charging a record or returning a coefficient.

The independent incidence enumeration has 9,216 literal and 18,432 mixed
directed anchor selections, with 6,684 and 13,979 distinct profiles and
exactly one joint plane/direction label per profile. Both centers lose
the single-anchor marker for plane (0,2), but the complete multiset still
determines both planes. It verifies all 1,080 observed signed group entries.
Within this fixed seam it bounds each reachable key by at most 4 continuation
internal components times 12 predecessor internal choices times 12 later
internal choices, or 576 group subtotals. The measured maximum is 32.

The final author run used 2,183,968 charged operations within the 24,000,000
aggregate cap. The observed projected list peak was 37 records against a
structural upper bound of 11,392. The later arena retained 10,240 records in
88 maps, with zero indexes and readers. The direct oracle's maximum scoped
prospective product was 64 records under the 16,384-record guard. That guard
covers each charged product and explicitly passed retained terms. It does
not bound fixed factor objects, all projection views, raw source assembly,
or native Python heap usage. Native peak RSS was 114,999,296 bytes on this
run. The incidence profile dictionaries and serialized receipt are also
separate from the coefficient arena.

The initial 48-target artifact is reproduced exactly inside the final
52-target output. An exploratory failure from a scratch Python class-scope
name collision is preserved separately. The exact first and final
continuity receipts both returned SAME on primary cc9e2a5be. No repository,
Lean, or slot actions were performed.

## Remaining scope

The next construction is to include the actual continuation companion factors
and their trace or epsilon weights as full source vertices at w. Other
continuation centers, all remaining original centers and nine site alternatives, global
last-incidence proof, full numerical Z, nonzero normalization, connected and
physical response remain open. The original source words, physical scope and
publication acceptance are unchanged.

Replay from the primary checkout with
`PYTHONPATH=. .venv/bin/python -B /tmp/publication-task4-continuation-roster-r8.py`,
then run the adjacent `.incidence.py` against its JSON. The final record
retains the original R7/R6/R5/R4 source scripts as dependencies and the exact
R7 JSON input. This is author evidence pending an independent review.
