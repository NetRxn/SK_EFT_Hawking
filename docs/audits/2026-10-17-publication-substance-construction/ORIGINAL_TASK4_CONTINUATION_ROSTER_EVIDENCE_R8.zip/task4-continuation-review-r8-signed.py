from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial
import importlib.util
import json
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

def load(label, path):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module

r4 = load("r4review", "/tmp/publication-task4-later-full-vertex-r4.py")
Q, P, S = o.QComplex, o.Polynomial, o.Symbol
reg = o.OriginalRegulator()
x, y = reg.sites[0], reg.step(reg.sites[0], 0)[0]
x2 = reg.step(x, 2)[0]
q = S("g2", ())
j = S("J", (y, 0, 0))
assert (reg.volume, reg.word, reg.convention) == (16, "closed", "source_C")

def tensor(alpha, *, slot=(), labels=()):
    # Rebuild the four signed bilinears directly from the block definition
    # and the globally ordered bar/psi basis. No author arena or ExteriorPolynomial.
    positions = {token: i for i, token in enumerate(reg.generator_order)}
    out = defaultdict(Q)
    blocks = f.original_coframe_blocks(reg, alpha)
    for b in blocks:
        for i, k in product(range(4), repeat=2):
            a, z = positions[b.bar_site, "bar", i], positions[b.psi_site, "psi", k]
            for key, value in b.matrix[i][k].terms:
                out[(1 << a | 1 << z, tuple(sorted((*labels, *key))), slot)] += value * b.weight * (-1 if a > z else 1)
    return {k: v for k, v in out.items() if v}

def trace_rows(site, k, l, mu, nu, a, b):
    # Direct closed matrix word D† C† B A, with original quaternion labels.
    anchors = (site,k), (reg.step(site,k)[0],l), (reg.step(site,l)[0],k), (site,l)
    links = [f.original_spin4_link(*(tuple(P.variable(S("q",(*z,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for z in anchors]
    A,B,C,D = links
    U = o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(D),o.matrix_dagger(C)),o.matrix_multiply(B,A))
    gamma = o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    poly = sum((U[i][k]*gamma[k][i] for i,k in product(range(4),repeat=2)),P()) * o.epsilon((k,l,mu,nu))
    return {(0,key,()): value for key,value in poly.terms}

def indices(mask):
    return [i for i in range(mask.bit_length()) if mask >> i & 1]

def multiply(left, right):
    out = defaultdict(Q)
    for (lm,lk,lj), lv in left.items():
        for (rm,rk,rj), rv in right.items():
            if lm & rm or len(lj) + len(rj) > 2:
                continue
            z = tuple(sorted(lj + rj))
            multiplicity = 1
            for i in set(z):
                multiplicity *= factorial(z.count(i)) // (factorial(lj.count(i)) * factorial(rj.count(i)))
            parity = sum(i > k for i,k in product(indices(lm),indices(rm))) % 2
            out[lm|rm,tuple(sorted(lk+rk)),z] += lv * rv * (-multiplicity if parity else multiplicity)
    return {k:v for k,v in out.items() if v}

def summed(*maps):
    out = defaultdict(Q)
    for d in maps:
        for k,v in d.items(): out[k] += v
    return {k:v for k,v in out.items() if v}

def slot_relabel(d, slot):
    return {(m,k,slot):v for (m,k,_),v in d.items()}

def snapshot(arena, handle):
    out = {}
    arena.scan(handle, lambda k,v:out.__setitem__(k,v))
    return out

from collections import Counter
from functools import lru_cache
from itertools import combinations

r7=load("r7review","/tmp/publication-task4-predecessor-roster-r7.py")
r4,r5=r7.r4,r7.r5
w=r5.Work(cap=20_000_000)
arena=r4.Arena(r4.Caps(100_000,65_536))

@lru_cache(maxsize=None)
def ordered_closed_word(site,k,l):
    sx=reg.step(site,k)[0]
    sy=reg.step(site,l)[0]
    anchors=((site,k),(sx,l),(sy,k),(site,l))
    ls=[f.original_spin4_link(*(tuple(P.variable(S("q",(*anchor,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for anchor in anchors]
    a,b,c,d=ls
    return o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(d),o.matrix_dagger(c)),o.matrix_multiply(b,a))

def direct_trace(site,k,l,mu,nu,a,b):
    mat=ordered_closed_word(site,k,l)
    gamma=o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    p=sum((mat[i][j]*gamma[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))
    return {(0,tuple(sorted((*k,q))),()):coef for k,coef in p.terms}

def raw_exact(e):
    return {(m,key,()):coef for m,poly in e.terms for key,coef in poly.terms}

C={}
H={}
source={}
diagonals={}
for site in (x,y):
    ac,ah,ad=r7.roster(reg,site,w)
    C[site]={(mu,a):tensor((site,mu,a)) for mu,a in product(range(4),repeat=2)}
    assert all(len(rows)==64 and rows==raw_exact(ac[key]) for key,rows in C[site].items())
    traces={}
    cancels=[]
    for mu,nu in combinations(range(4),2):
        k,l=[i for i in range(4) if i not in (mu,nu)]
        for a,b in product(range(4),repeat=2):
            tag=k,l,mu,nu,a,b
            main=direct_trace(site,k,l,mu,nu,a,b)
            flip_coframes=direct_trace(site,k,l,nu,mu,b,a)
            flip_curve=direct_trace(site,l,k,mu,nu,a,b)
            flip_both=direct_trace(site,l,k,nu,mu,b,a)
            if a==b:
                assert main and flip_coframes and flip_curve and flip_both
                assert not summed(main,flip_coframes) and not summed(flip_curve,flip_both)
                cancels.append(tag)
            else:
                assert len(main)==128 and main==flip_coframes==flip_curve==flip_both
                assert main==raw_exact(ah[tag])
                traces[tag]=main
    assert len(cancels)==24 and sorted(cancels)==ad
    assert len(traces)==72 and set(traces)==set(ah)
    H[site]=traces
    diagonals[site]=sorted(cancels)
    source[site]=ac,ah
from itertools import permutations

r8=load("r8review","/tmp/publication-task4-continuation-roster-r8.py")
Fa,occ=r8.continuation_source(reg,x2,w)
F={key:tensor((x2,*key)) for key in product(range(4),repeat=2)}
assert all(len(f)==64 and f==raw_exact(Fa[key]) for key,f in F.items())
_,_,_,old_f,_=r4.factors(reg)
assert F[2,0]==raw_exact(old_f)
counts=Counter()
for k,l,mu,nu in permutations(range(4)):
    for a,b in product(range(4),repeat=2):
        counts[2,mu,a]+=1
        counts[2,nu,b]+=1
for perm in permutations(range(4)):
    for axis,a in enumerate(perm):
        counts[4,axis,a]+=1
assert counts==occ
D0=tensor((y,0,0),labels=(j,))
D1=tensor((y,1,0),labels=(j,))
D={(0,):D0,(0,1):summed(D0,D1)}
assert tuple(map(len,D.values()))==(64,128)
yh={tag:arena.ingest(r4.rows(e)) for tag,e in source[y][1].items()}
yc={tag:arena.ingest(r4.rows(e)) for tag,e in source[y][0].items()}
assert arena.metric()["live_records"]==10240 and arena.metric()["live_maps"]==88
jp=P.variable(j)
DC={(0,):source[y][0][0,0]*jp,(0,1):(source[y][0][0,0]+source[y][0][1,0])*jp}
assert all(D[slot]==raw_exact(e) for slot,e in DC.items())

def decode(d):
    def freeze(x):
        return tuple(map(freeze,x)) if isinstance(x,list) else x
    return int(d["mask_hex"],16),tuple(S(n,freeze(v)) for n,v in d["symbols"]),tuple(d["slot"])
def inv(L,R):
    return sum(i>k for i,k in product(indices(L),indices(R)))

def forward(key, weights=None):
    mask,sy,slot=key
    powers=Counter(sy)
    def proj(d):
        return [(k,v,Counter(k[1])) for k,v in d.items() if k[0]&mask==k[0] and not Counter(k[1])-powers]
    cx={tag:proj(d) for tag,d in C[x].items()}
    cy={tag:proj(d) for tag,d in C[y].items()}
    hx={tag:proj(d) for tag,d in H[x].items()}
    hy={tag:proj(d) for tag,d in H[y].items()}
    ff={tag:proj(d) for tag,d in F.items()}
    dd=proj(D[slot])
    retained=sum(map(len,(*cx.values(),*hx.values(),*ff.values(),dd)))
    def terms(operands):
        for rows in product(*operands):
            union=0
            accumulated=Counter()
            coef=Q(1)
            for (m,_,_),v,c in rows:
                if union&m or (accumulated+c)-powers:
                    break
                coef*=v*(-1)**inv(union,m)
                union|=m
                accumulated+=c
            else:
                yield union,accumulated,coef,rows
    late={}
    for tag,trace in hy.items():
        _,_,mu,nu,a,b=tag
        generated=[(m,p,v) for m,p,v,_ in terms((cy[mu,a],cy[nu,b],trace))]
        if generated: late[tag]=generated
    out={}
    dirs=Counter()
    dirs_by_comp=defaultdict(Counter)
    for tag,trace in hx.items():
        _,_,mu,nu,a,b=tag
        if not all((trace,cx[mu,a],cx[nu,b],dd)): continue
        for comp,fr in ff.items():
            weight=Q(1) if weights is None else weights.get(comp,Q(0))
            if not weight: continue
            group_sum={}
            paths=0
            for m,p,v,rows in terms((cx[mu,a],cx[nu,b],trace,fr,dd)):
                dkey=rows[-1][0]
                direction=1 if dkey in D1 else 0
                for group,factors in late.items():
                    for m1,p1,v1 in factors:
                        if m&m1 or m|m1!=mask or p+p1!=powers: continue
                        group_sum[group]=group_sum.get(group,Q(0))+weight*v*v1*(-1)**inv(m,m1)
                        paths+=1
                        dirs[direction]+=1
                        dirs_by_comp[comp][direction]+=1
            if paths: out.setdefault(comp,{})[tag]=(group_sum,paths)
    return out,retained,dirs,dirs_by_comp

def fmt(g):
    return [[list(k),str(v)] for k,v in sorted(g.items())]
def summarize(table):
    sums={}
    for comp,branches in table.items():
        comp_sum=defaultdict(Q)
        for groups,paths in branches.values():
            for group,v in groups.items():
                comp_sum[group]+=v
        sums[comp]=dict(comp_sum)
    combined={}
    collisions=[]
    for group in sorted(H[y]):
        active=[(comp,groups[group]) for comp,groups in sorted(sums.items()) if groups.get(group)]
        if not active: continue
        value=sum((v for _,v in active),Q(0))
        combined[group]=value
        if len(active)>1:
            collisions.append([list(group),[[list(comp),str(v)] for comp,v in active],str(value)])
    return sums,combined,collisions

# Derive topology from the independently generated exact factor maps,
# then count raw support profiles by multiplying anchor Counters.
def anchors(key):
    return tuple((s.index[0],s.index[1]) for s in key[1] if s.family=="q")
def support(factor):
    return tuple(sorted({a for key in factor for a in anchors(key)}))
planes=tuple(combinations(range(4),2))
trace_anchor_profiles={}
for site in (x,y):
    for plane in planes:
        shapes={tuple(sorted(anchors(key))) for tag,d in H[site].items() if tag[:2]==plane for key in d}
        assert len(shapes)==1 and len(set(next(iter(shapes))))==4
        trace_anchor_profiles[site,plane]=next(iter(shapes))
def axes_at(site,axis):
    choices={support(C[site][axis,internal]) for internal in range(4)} if site in C else {
        support(F[axis,internal]) for internal in range(4)}
    assert len(choices)==1 and len(next(iter(choices)))==2
    return next(iter(choices))
def profile_index(slot):
    directions=(0,) if slot==(0,) else (0,1)
    out={}
    n=0
    for a,b,axis,d in product(planes,planes,range(4),directions):
        fixed=trace_anchor_profiles[x,a]+trace_anchor_profiles[y,b]
        world=[axes_at(site,mu) for site,pair in ((x,a),(y,b)) for mu in range(4) if mu not in pair]
        world += [axes_at(x2,axis),axes_at(y,d)]
        for tail in product(*world):
            key=tuple(sorted(fixed+tail))
            label=(a,b,axis,d)
            assert out.setdefault(key,label)==label
            n+=1
    return out,n
indices_by_slot={}
profile_counts=[]
for slot in D:
    ind,n=profile_index(slot)
    indices_by_slot[slot]=ind
    profile_counts.append({"slot":slot,"directed_choices":n,"unique_profiles":len(ind)})
assert [(p["directed_choices"],p["unique_profiles"]) for p in profile_counts]==[(9216,6684),(18432,13979)]

auth=json.load(open("/tmp/publication-task4-continuation-roster-r8.json"))
old=json.load(open("/tmp/publication-task4-predecessor-roster-r7.json"))
old_rows={decode(row["target"]):row for row in old["results"]}
assert [[list(k),n] for k,n in sorted(counts.items())]==auth["occurrence_counts"]
assert [[list(k),len(d),sha256(json.dumps([
    (r5.fingerprint(row),str(v)) for row,v in sorted(d.items())],sort_keys=True).encode()).hexdigest()]
    for k,d in sorted(F.items())]==auth["component_records"]
results=[]
verified=Counter()
target_keys=set()
for ix,row in enumerate(auth["results"]):
    key=decode(row["target"])
    assert key not in target_keys
    target_keys.add(key)
    table,projected,directions,dirs_by_comp=forward(key)
    assert projected==row["projected"]
    serialized=[[list(c),[[list(b),p,fmt(g)] for b,(g,p) in sorted(branches.items())]]
                for c,branches in sorted(table.items())]
    assert serialized==row["paths"]
    sums,combined,collisions=summarize(table)
    assert [[list(c),fmt(g)] for c,g in sorted(sums.items())]==row["component_groups"]
    assert [[list(c),str(sum(g.values(),Q(0)))] for c,g in sorted(sums.items())]==row["component_totals"]
    assert fmt(combined)==row["all_ones_groups"] and str(sum(combined.values(),Q(0)))==row["all_ones_total"]
    assert collisions==row["collisions"]
    if row["prior_r7_checked"]:
        prior=old_rows[key]
        by_branch=table[(2,0)]
        assert sorted([[list(b),p,fmt(g)] for b,(g,p) in by_branch.items()])==sorted(prior["branches"])
        assert str(sum(sums[(2,0)].values(),Q(0)))==prior["whole"]
    if row["witness"]:
        comp,bp,bq=map(tuple,row["witness"])
        assert comp in sums and any(sums[comp].values())
        assert bp in table[comp] and bq in table[comp][bp][0]
        verified[comp]+=1
        assert key[2]!=(0,1) or dirs_by_comp[comp][1]
    if ix in auth["mixed_direction0_target_indices"]:
        assert key[2]==(0,1) and directions[0] and not directions[1]
        lit=next(r for r in auth["results"] if decode(r["target"])==(key[0],key[1],(0,)))
        assert lit["paths"]==row["paths"] and lit["all_ones_groups"]==row["all_ones_groups"]
    label=indices_by_slot[key[2]][tuple(sorted(anchors(key)))]
    xp,yp,axis,direction=label
    assert all(c[0]==axis and all(b[:2]==xp and all(g[:2]==yp for g in vals) for b,(vals,_) in br.items())
               for c,br in table.items())
    assert directions and set(directions)=={direction}
    n_groups=sum(len(vals) for branches in table.values() for vals,_ in branches.values())
    results.append({"directions":dict(directions),"groups":n_groups,"overlaps":len(collisions),
                    "unique_anchor_label":label,"projected":projected})
assert len(results)==52 and len(verified)==16 and sum(r["prior_r7_checked"] for r in auth["results"])==32
assert (sum(r["groups"] for r in results),sum(r["overlaps"] for r in results),
        max(r["groups"] for r in results),max(r["projected"] for r in results))==(1080,136,32,37)

# Apply the two phase weights before multiplying each direct raw path.
weighted=[]
for i,row in enumerate(auth["weighted_controls"]):
    target=decode(auth["results"][row["target_index"]]["target"])
    weights={(2,0):Q(1),(2,1):Q(0,-1 if i%2==0 else 1)}
    table,*_=forward(target,weights)
    _,groups,_=summarize(table)
    total=sum(groups.values(),Q(0))
    assert fmt({k:v for k,v in groups.items() if v})==row["exact_groups"]
    assert str(total)==row["total"]
    weighted.append(str(total))
assert weighted==[str(Q(0)),str(Q(0,Fraction(1,32))),str(Q(0)),str(Q(0,Fraction(-1,32)))]

controls=[]
for name,value in auth["adverse"]:
    if name!="wrong_source_zero": continue
    target=decode(value)
    table,projected,dirs,_=forward(target)
    assert not table and not dirs
    controls.append({"slot":target[2],"zero_paths":True})
tiny=r5.Work(cap=0)
try:
    r8.signed_stream(decode(auth["results"][0]["target"]),*source[x],Fa,DC,arena,yc,yh,tiny)
except RuntimeError as exc:
    assert "work cap at 0" in str(exc) and tiny.used==0 and not tiny.counts
else:
    raise AssertionError("expected fail-closed work cap")
print(json.dumps({"checked_components":len(F),"profiles":profile_counts,"authored_targets":results,
                  "weighted":weighted,"adverse":controls,"zero_cap_refusal":True},indent=2))
