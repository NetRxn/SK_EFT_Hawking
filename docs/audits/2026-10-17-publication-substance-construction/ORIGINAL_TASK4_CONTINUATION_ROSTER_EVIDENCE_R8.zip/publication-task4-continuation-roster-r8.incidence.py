"""Enumerate the anchor-multiplicity support envelope for the exact R8 seam."""
from collections import Counter, defaultdict
from itertools import combinations, product
from pathlib import Path
import json


PLANES = tuple(combinations(range(4), 2))
X = (0, 0, 0, 0)


def shift(x, axis):
    return tuple((v + (j == axis)) % 2 for j, v in enumerate(x))


def plaquette(x, plane):
    k, l = plane
    return (x, k), (shift(x, k), l), (shift(x, l), k), (x, l)


def coframe(x, axis):
    return (x, axis), (shift(x, axis), axis)


Y, W = shift(X, 0), shift(X, 2)
surviving = {}
slot_results = []
for slot, directions in (((0,), (0,)), ((0, 1), (0, 1))):
    profiles = defaultdict(set)
    multiplicities = 0
    for p, q in product(PLANES, repeat=2):
        px = [coframe(X, axis) for axis in range(4) if axis not in p]
        py = [coframe(Y, axis) for axis in range(4) if axis not in q]
        for axis, contact_axis in product(range(4), directions):
            for tail in product(*px, *py, coframe(W, axis), coframe(Y, contact_axis)):
                key = tuple(sorted((*plaquette(X, p), *plaquette(Y, q), *tail)))
                profiles[key].add((p, q, axis, contact_axis))
                multiplicities += 1
    surviving[slot] = profiles
    ambiguous = [(k, sorted(v)) for k, v in sorted(profiles.items())
                 if len({(p, q) for p, q, _, _ in v}) > 1]
    assert all(len(v) == 1 for v in profiles.values())
    slot_results.append({
        "slot": slot, "paths": multiplicities, "distinct_profiles": len(profiles),
        "profile_plane_pair_ambiguities": len(ambiguous),
        "ambiguity_examples": ambiguous[:3],
        "max_plane_pairs": max(len({(p, q) for p, q, _, _ in v}) for v in profiles.values()),
        "max_joint_plane_and_world_direction_labels": max(map(len, profiles.values())),
    })

result = json.loads(Path(__file__).with_name("publication-task4-continuation-roster-r8.json").read_text())
checked = 0
peak_signed_group_entries = 0
actual_direction_hits = Counter()
for index, row in enumerate(result["results"]):
    key = tuple(sorted((tuple(i[0]), i[1]) for family, i in row["target"]["symbols"] if family == "q"))
    slot = tuple(row["target"]["slot"])
    support = surviving[slot][key]
    label, = support
    actual_direction_hits[slot, label[2], label[3]] += 1
    if row["witness"] and slot == (0, 1):
        assert label[3] == 1
    if index in result["mixed_direction0_target_indices"]:
        assert slot == (0, 1) and label[3] == 0
    n_groups = sum(len(groups) for _, branches in row["paths"] for _, _, groups in branches)
    assert n_groups <= 4 * 12 * 12
    peak_signed_group_entries = max(peak_signed_group_entries, n_groups)
    for (mu, _), branches in row["paths"]:
        for p, _, groups in branches:
            for q, _ in groups:
                assert any((tuple(p[:2]), tuple(q[:2]), mu) == (xp, yp, axis)
                           for xp, yp, axis, _ in support)
                checked += 1
print(json.dumps(dict(
    scope="All directed original anchor multiplicities before exterior or quaternion filtering",
    complete_anchor_options="Curvature contributes each plaquette anchor once; each coframe contributes one of its two directed anchors.",
    slot_results=slot_results, matched_signed_group_entries=checked,
    actual_direction_hits=sorted(actual_direction_hits.items()),
    theoretical_group_subtotals_per_reachable_key=4 * 12 * 12,
    peak_signed_group_entries=peak_signed_group_entries,
    caveat="An ambiguous profile is a support possibility and is not an asserted full-key collision."
), indent=2))
