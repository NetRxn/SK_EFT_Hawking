# Independent original N16 continuation roster review R8

**ACCEPT the exact fixed-center continuation component vector for the
selected raw seam.** This keeps both original S2 rosters, both contact
directions and all sixteen individual coframes at w=x+e2. The all-ones
and phase-weighted sums are explicit diagnostic contractions of that
vector. The actual full source vertices at w, further centers and site
alternatives, global last incidences, full Z and connected normalization
remain open.

## Authority and replay

The exact author probe reproduced every deterministic JSON field. Its
first 48 saved tables agree exactly with the initial artifact. The
incidence receipt reproduced byte for byte. Work sums to 2,183,968
charged operations, with 10,240 logical records in 88 later-factor
maps, zero indexes/readers, and 64 prospective scoped oracle records
at peak. Process peak RSS was 115,277,824 bytes on replay. The factor,
projection and prospective product counts describe named scopes. They
leave source assembly, interpreter arithmetic, profile dictionaries
and serialized receipts outside the arena. The separate exploratory
class-scope failure remains preserved.

## Independent signed construction

I generated the original four signed hopping blocks on the explicit
ordered bar/psi basis, and built the closed D† C† B A word and oriented
gamma trace directly. All exact predecessor and later coframes and
trace maps matched. Their 72 aligned off-diagonal groups and 24
diagonal cancellations account for 384 original ordered S2 terms at
each center. I independently rebuilt all sixteen continuation
coframes, 64 records each. Their exact coefficient hashes matched
and the fixed component matches R7's prior factor. Direct world and
internal permutation enumeration independently gives 48 S2 and six
S4 occurrences for each isolated component in the original source
roster. Those counts carry no isolated component weight.

The independent forward calculation enumerates projected source
operands using exact Counter containment. It requires disjoint
exterior masks and exact final symbol powers and counts signs by
explicit basis inversions. It retains raw contact slots and the
direction of each contributing contact term. It uses neither the
author stream, inverse subtraction, mask split nor arena product to
construct its reference.

All 52 signed tables matched, including every component, predecessor
branch, later-group subtotal and raw path count. The exact fixed
(2,0) restriction reproduces all 32 R7 tables, including zeros.
The sixteen nonzero witnesses match their original branches and
every mixed witness contains a genuine direction-1 path. Four
additional mixed direction-0 controls match the literal signed
tables at exactly the same raw symbols, one per continuation world
direction. The 52 queries cover 1,080 signed group entries and 136
overlaps between nonzero component subtotals. The projected list
maximum is 37 and the observed signed group-entry maximum is 32.

Applying complex weights before the independent raw forward product
reproduces the exact phase cancellations in both slots. Weights
(1,-i) on components (2,0) and (2,1) give zero. Reversing the phase
gives +i/32 for the literal control and -i/32 for the mixed control.
The weighted queries remain diagnostic contractions of the indexed
vector. Wrong anchored J in either slot gives zero paths, and a
zero-work query refused without charging or returning a coefficient.

## Independent raw incidence envelope

I extracted the four mandatory plaquette anchors and the two actual
directed coframe support choices from the independently rebuilt exact
maps. Complete raw anchor multiset enumeration yields 9,216 literal
and 18,432 mixed directed choices, with 6,684 and 13,979 distinct
profiles. Each profile identifies a unique pair of curvature planes,
continuation world direction and contact world direction. Those labels
match every observed path. With the two planes and direction fixed,
at most 4 continuation internals times 12 predecessor internals
times 12 later internals are possible, giving 576 group subtotals per
reachable key. This is an unprojected anchor support result. It does
not establish last-use closure, post-Haar separation, or any global
numerical work bound.

The exact reviewer first and final checks were fresh, byte-identical,
and showed no changed inputs at primary cc9e2a5be. No repository,
Lean, slot or complete-run actions occurred. The evidence prefix
is /tmp/task4-continuation-review-r8- with suffixes first.json,
final.json, replay.json, incidence-replay.json, signed.py, signed.json
and independent.md.
