from pathlib import Path
import ast,hashlib,json,zipfile,subprocess,sys,dataclasses,re
M=Path.cwd();P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');packet=P/'.codex/continuity/publication-main-citation-composition-review-r2.json';d=json.loads(packet.read_text());oldpacket=json.loads((P/'.codex/continuity/publication-main-citation-composition-review-r1.json').read_text());oldbefore=json.loads(Path('/tmp/publication-main-citation-composition-review-r1-before.json').read_text())
archive=P.parent/'.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction/MAIN_CITATION_COMPOSITION_FROZEN_R1_EVIDENCE.zip'
with zipfile.ZipFile(archive) as z:
 assert z.testzip()is None
 manifest=json.loads(z.read('manifest.json'));assert set(z.namelist())==set(manifest)|{'manifest.json'}
 for n,r in manifest.items():
  b=z.read(n);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],n
 assert not any(n.endswith('.pdf') or n.endswith('publication-dawson-full-source-r1.txt') for n in z.namelist())
 current={p:(M/p).read_bytes() for p in d['owned_files']};old={p:z.read('candidate/'+p) for p in d['owned_files']}
 assert [p for p in current if current[p]!=old[p]]==['papers/AutomatedReviews/2026-11-07-citation-held-source-reconciliation/infra.md','src/core/citations.py']
 prior=z.read('independent/publication-main-citation-composition-review-r1.md');assert prior==Path('/tmp/publication-main-citation-composition-review-r1.md').read_bytes()
 before_note="Its abstract and section 3.3 distinguish the gate-length exponent log(5)/log(3/2) from the compressed classical-runtime exponent log(3)/log(3/2)."
 after_note="Its abstract gives the rounded exponents; Section 3, Analysis, Eqs. (8)-(9), printed page 7, gives the gate-length exponent log(5)/log(3/2) and the pointer-compressed classical-runtime exponent log(3)/log(3/2)."
 assert current['src/core/citations.py']==old['src/core/citations.py'].replace(before_note.encode(),after_note.encode())
 finding='papers/AutomatedReviews/2026-11-07-citation-held-source-reconciliation/infra.md';assert current[finding].startswith(old[finding].rstrip());history=current[finding][len(old[finding].rstrip()):].decode();assert 'Independent R1 residual' in history and 'Verify:' not in history
 assert current[finding].decode().split('**Verify:**')[1].splitlines()[0]==old[finding].decode().split('**Verify:**')[1].splitlines()[0]
 def registry(src):
  t=ast.parse(src);return ast.literal_eval(next(n.value for n in t.body if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name)and v.id=='CITATION_REGISTRY' for v in n.targets)))
 a=registry(current['src/core/citations.py']);b=registry(old['src/core/citations.py']);changes=[(k,f)for k in a for f in a[k] if a[k][f]!=b[k][f]];assert changes==[('DawsonNielsen2006','notes')]
 for r in oldpacket['references']['authorities'][:6]:
  match=next(x for x in d['references']['authorities'] if x['path']==r['path']);assert r['sha256']==match['sha256']
 custody={}
 for path,b in oldbefore['held'].items():
  p=Path(path);s=p.stat();now={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':s.st_size,'mode':s.st_mode,'mtime_ns':s.st_mtime_ns};assert now==b,path;custody[path]=now
 pdf=Path(next(p for p in custody if p.endswith('DawsonNielsen2006.pdf')));text=subprocess.check_output(['pdftotext','-f','7','-l','7','-layout',str(pdf),'-'],text=True)
 assert '(8)' in text and '(9)' in text and 'ln 5/ ln(3/2)' in text and 'ln 3/ ln(3/2)' in text
 fulltext=subprocess.check_output(['pdftotext','-layout',str(pdf),'-'],text=True);assert re.search(r'^3\s+The Solovay-Kitaev algorithm for qubits',fulltext,re.M);assert 'Analysis:' in fulltext and '3.3' not in fulltext
 sys.path[:0]=[str(M),str(M/'scripts')]
 from src.core import citations,constants
 import validation.checks.citations as ck
 assert Path(citations.__file__).resolve().is_relative_to(M)
 captured={}
 def profile(frame,event,arg):
  if frame.f_code is ck.check_citation_primary_sources_present.__code__ and event=='return':
   for k in ['usage','undeclared_class','missing_from_registry','not_cached','abstract_only','metadata_only','cached','inprep_exempt','class_exempt']:captured[k]=frame.f_locals.get(k)
 sys.setprofile(profile)
 try:result=ck.check_citation_primary_sources_present()
 finally:sys.setprofile(None)
 assert result.passed and len(captured['undeclared_class'])==constants.CITATION_UNDECLARED_CLASS_CEILING==76 and not captured['missing_from_registry'];assert captured['undeclared_class']==json.loads(Path('/tmp/publication-main-citation-composition-review-r1-tests.json').read_text())['canonical_result']['population']['undeclared_class']
 assert all((M/p).read_bytes()==v for p,v in current.items());assert not (M/'docs/.test_missing_stubs.json').exists()
 out={'candidate':d['source']['head'],'archive':{'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'verified_members':len(manifest),'no_full_source_copied':True},'delta':{'changed_paths':changes,'only_Dawson_notes_literal_replaced':True,'finding_history_only':history,'all_other_owned_bytes_exact':True,'all_governing_references_exact':True},'held_seven_bytes_stats_exact':custody,'actual_page7_equations_verified':True,'corrected_note':a['DawsonNielsen2006']['notes'],'canonical_result':{'passed':result.passed,'population':captured,'details':[dataclasses.asdict(x) for x in result.details]},'origins':{'citations':citations.__file__,'constants':constants.__file__,'checker':ck.__file__},'new_R2_pytest_run':False,'R1_test_receipt_reused_for_unchanged_runtime_code':{'passed':76,'skipped':1,'xml_sha256':hashlib.sha256(Path('/tmp/publication-main-citation-composition-review-r1-tests.xml').read_bytes()).hexdigest()},'all_current_source_hashes':{p:hashlib.sha256(v).hexdigest() for p,v in current.items()}}
 Path('/tmp/publication-main-citation-composition-review-r2-check.json').write_text(json.dumps(out,indent=2,default=lambda x:sorted(x) if isinstance(x,set) else str(x))+'\n');print(json.dumps({'canonical_passed':result.passed,'undeclared':len(captured['undeclared_class']),'archive_members':len(manifest),'only_source_field':changes,'all_other_bytes_and_custody_exact':True,'R2_pytest_rerun':False},indent=2))
