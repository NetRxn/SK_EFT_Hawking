# Citation composition R2 — exact source locator correction

ROOT read the COMPLETE independent R1 review and checked the actual held v2 Analysis/Eqs.(8)–(9), printed page7. It has Section3 with an unnumbered Analysis discussion, not Section3.3. The R1 author report and note were inaccurate on that locator. Frozen R1 source, report and full adverse review are preserved; this R2 record supersedes their locator wording without rewriting historical evidence.

The ONLY tracked-source R1→R2 change is the Dawson notes locator/abstract-versus-formula wording. All registry fields/addedidentities/state/metadata/bibliographicbodies/constants/testassertions remain byte-exact from the complete reviewed R1. The new canonical finding adds the exact residual/correction history. Fulltextremains LitSearch; allheldsourcebytes/stats unchanged.

R1actual76PASS/1existingSKIP andcanonicalPASS are exact prior-source receipts. Different R2 reassessment of actualcorrectednote andsourceconservation is required; originaldeclaredVerify will be rerun on the accepted currentsource bythecanonicalwriter. No fullcompile/main/publication/physics/sourcefindingclosure is inferred.
