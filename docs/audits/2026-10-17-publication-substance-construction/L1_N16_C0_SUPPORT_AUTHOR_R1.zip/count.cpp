#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include <vector>
using Count = uint64_t;

std::vector<int> sites(int parity) {
    std::vector<int> result;
    for (int v = 0; v < 16; ++v)
        if (__builtin_popcount(v) % 2 == parity)
            result.push_back(v);
    return result;
}

void count_profiles(int degree) {
    auto start = std::chrono::steady_clock::now();
    auto even = sites(0), odd = sites(1);
    std::array<int, 16> odd_index{};
    for (int i = 0; i < 8; ++i)
        odd_index[odd[i]] = i;
    std::array<int, 8> last{};
    for (int i = 0; i < 8; ++i)
        for (int j = 0; j < 4; ++j)
            last[odd_index[even[i] ^ (1 << j)]] = i;

    std::vector<std::array<int, 4>> compositions;
    for (int a = 0; a <= degree; ++a)
        for (int b = 0; a + b <= degree; ++b)
            for (int c = 0; a + b + c <= degree; ++c)
                compositions.push_back({a, b, c, degree - a - b - c});

    std::unordered_map<uint32_t, Count> states{{0, 1}};
    Count updates = 0, attempts = 0;
    std::cout << "degree " << degree << " rows " << compositions.size() << " widths";
    for (int i = 0; i < 8; ++i) {
        std::unordered_map<uint32_t, Count> next;
        std::array<int, 4> columns{};
        for (int j = 0; j < 4; ++j)
            columns[j] = odd_index[even[i] ^ (1 << j)];
        for (auto [key, count] : states) {
            attempts += compositions.size();
            for (auto composition : compositions) {
                bool admissible = true;
                uint32_t increment = 0;
                for (int j = 0; j < 4; ++j) {
                    int col = columns[j], shift = 4 * col;
                    int sum = ((key >> shift) & 15) + composition[j];
                    if (sum > degree || (last[col] == i && sum != degree)) {
                        admissible = false;
                        break;
                    }
                    increment |= uint32_t(composition[j]) << shift;
                }
                if (admissible) {
                    ++updates;
                    next[key + increment] += count;
                }
            }
        }
        states.swap(next);
        std::cout << ' ' << states.size();
    }
    if (states.size() != 1) std::abort();
    const double seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - start).count();
    std::cout << " count " << states.begin()->second << " attempts " << attempts
              << " updates " << updates << " seconds " << seconds << '\n';
}

int main() {
    for (int degree : {1, 2, 4, 8})
        count_profiles(degree);
}
