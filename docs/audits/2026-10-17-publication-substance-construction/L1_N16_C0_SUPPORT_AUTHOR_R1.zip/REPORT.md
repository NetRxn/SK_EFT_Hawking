# Original periodic N16 pure-EHC support reduction

Packet `publication-l1-n16-c0-support-author-r1.json` was fresh at primary
`27012c18fa374e8341e124b510abbedeedb18d29`. The source is the original
`src/core/formulas.py` and `src/vestigial/original_coefficients.py`.
The independent-input boundary is the accepted nonzero-normalization result at
`6f78e5b63`, which proves a bound on c16 and an actual nonzero-g2
normalization point without computing c0. The inverse-word identity comes from
`ORIGINAL_EHC_REFLECTION_SOURCE_ADJOINT.md` at the same commit.
All new programs and evidence are scratch-only. No repository, notebook,
controller or slot was modified.

## Exact occurrence roster

Let Q4 have vertices x in F2^4 and let e_mu toggle bit mu. The original
periodic closed source has 128 odd generators and 64 independent anchored
Spin(4) variables with two independent SU(2) Haar variables per anchor.
The source generator order places the L block before the R block at each
site, with bars before psis within each chirality. Moving the two L psis past
two R bars gives positive sign against the site order with all bars first.

For sorted curvature axes k<l and sorted complementary coframe axes u<v,
let

```
F_AB(x;k,l) = 1/2 Tr[(H_kl - H_lk) gamma_A gamma_B gamma5]
B(x;k,l) = epsilon(k,l,u,v) sum_AB F_AB T_(x,u,A) T_(x,v,B).
```

For the closed source, `H_lk=H_kl^dagger` at the same x, with the same four
actual anchored links in the inverse word. The diagonal A=B difference is
zero because the trace on each quaternionic block is unchanged under
dagger. Off diagonal, the block scalar in H+H^dagger has zero trace against
gamma_A gamma_B gamma5, so F_AB is the corresponding forward trace and
F_BA=-F_AB. Swapping the two curvature axes gives the inverse subtraction.
Swapping the two coframe axes swaps the two internal labels after commuting
the even coframes and flips the world epsilon. The four ordered placements
combine with the original quarter to give exactly B. Thus
`S2=sum_(x,k<l) B(x;k,l)`, with 96 labeled summands. Source raw and grouped
actions agree in the scoped control below.

Write m(x;k,l) for the exponent of B. The exact target is

```
c0 = sum_{m >= 0, sum m = 32} [prod m!]^-1 I_top E_Haar [prod B(x;k,l)^m].
```

Every factor at x uses two center generators and one at each of its two
distinct coframe neighbors. Consequently each site has total center
multiplicity at most 4. Let h(x,u) be the sum of m at x over the three
curvature planes excluding u. For undirected edge e={x,x+e_u}, let
d_e=h(x,u)+h(x+e_u,u). Then every surviving monomial satisfies
`sum_(e incident x) d_e=8` at every vertex. This equation is precisely
total site-degree saturation at the occurrence level. It does not identify
the two original anchors on e.

## Further exact support tests

**Chirality and orientation.** A coframe is one bar and one psi at opposite
vertices and opposite chiralities. Color its edge by the chirality at the
even endpoint and orient it from bar to psi. For each color and each
orientation, exactly two occurrences are incident at each vertex, since
full top uses both spinor components of each local chirality and bar/psi
kind. Every surviving monomial's d is the sum of four degree-two
nonnegative integer edge profiles. For a coframe centered at x, its
physical link chirality equals the chirality of the other endpoint: the
gamma flips at x and each U or U^dagger preserves chirality. Hence the
edge color, chosen center and bar/psi orientation retain enough metadata
to obtain the physical link chirality and odd generator kind at both ends.

**Independent anchors.** For a fixed m, let r_A be the curvature occurrence
count on actual anchor A. A curvature occurrence contributes exactly one
quaternion coordinate on each of
`(x,k), (x+e_k,l), (x+e_l,k), (x,l)`, all in one chirality. For the two
anchors A and D of an undirected edge e, a coarse parity allocation of
its d_e coframes exists exactly when

```
a = r_A mod 2, b = r_D mod 2
d_e >= a+b and d_e = a+b mod 2.
```

Indeed, the count assigned to A must lie between 0 and d_e and equal a
modulo two, while the complement equals b modulo two. Every occurrence
has both anchor choices before resolving spinor coefficients. This
feasibility concerns total degree only. The mod-two equality also reads
`d mod 2 = boundary(f)` in the Q4 cubical chain complex, where each of
the 24 geometric faces has its four rooted curvature exponents summed
modulo two. The lower bound `d_e >= a+b` adds an independent constraint.
In particular a zero-coframe edge cannot repair one odd curvature
occurrence on each of its two anchors.

Once chirality is assigned, require parity separately on both SU(2)
variables at each anchor. Once quaternion coordinates are assigned,
require each individual coordinate exponent even. For exponents
(2s0,2s1,2s2,2s3) with r=sum s, integrate using the exact normalized
moment `prod_i (2s_i-1)!! / [2^r (r+1)!]`. Use complete exterior masks,
with collision rejection and signed coefficient accumulation. Each
pruning rule is an equality or a necessary condition on the original
labels. Passing the parity or degree rules does not assert a nonzero
coefficient.

**Symmetry.** Bit translations and permutations of the four world axes
act on the original anchored labels, without conjugating or identifying
links. A world permutation multiplies the action by its sign, through
epsilon. The 32 factors cancel that sign. The Grassmann top is invariant
because it permutes size-eight site blocks, and the independent normalized
Haar factors are permuted. The full 384-element group therefore acts on
the summands. Use orbit multiplicities at the chosen enumeration level.
For a first-stage representative d, one may evaluate all compatible m
above it and multiply that sum by the size of the d orbit. If reducing
m again, use the stabilizer of d, not a second orbit factor from the full
group. This uses no geometric reflection or assumed reflection invariance.

## Verified controls and prospective caps

1. `support_controls.py` builds two pairs of actual 32-occurrence
   profiles, all top-saturated at the site-degree level. First, replacing
   the planes 01 and 23 at the origin by 02 and 13 preserves d=2 on every
   edge but creates eight face-boundary failures. Second, use only
   curvature plane 23, with m=2 initially everywhere. Replace its
   multiplicity by `2 + (-1)^popcount(x) * bit2(x)`. This preserves d=4 on axes 0,1 and d=0
   on 2,3 and passes the full undirected face-boundary test. It nevertheless
   fails at eight axis-3 undirected edges where both distinct anchors are
   odd and no coframes occur. These are zero exclusions for the full
   contraction of those occupations, independent of spin cancellations.
2. `source_control.py` keeps the four bars at x, two L psis at x+e0 and
   two R psis at x+e1, using their inherited order. The original full action
   has a unique eligible center x, with coframes in 0,1 and curvature
   plane 2,3. For each coframe direction its pair tensor is diagonal with
   coefficient -1/4 on the selected four-generator mask. The full
   curvature Frobenius second moment is 24. The source-order sign joining
   the two masks is positive, and the restricted degree-eight top of
   `S2^2/2!` is exactly 3/4. All eight used anchors in this control
   remain separately labeled. The remaining Haar variables are absent
   from the restricted polynomial and integrate to one. At an asymmetric
   exact quaternion point, the source's complete ordered factor roster
   and the grouped formula agree on 16 nonzero restricted quartic masks.
   This restriction is a support/integration control only.
3. `count.cpp` counts integer degree-r edge profiles by adding the eight
   even-site rows. A state holds the eight running odd-site totals. Each
   row enumerates the four-coordinate compositions of r and checks exact
   equality when an odd column is closed. The degree-8 run counted
   109,621,610,869 profiles from 440,316,030 attempted updates, with
   2,200,689 peak states. Degree four gives 20,126,899 and degree two
   gives 24,962. Four separately enumerated orientation rosters would
   yield 388,255,409,514,885,136 Cartesian tuples before compatibility.
4. `burnside.cpp` counts fixed profiles by assigning a common weight to
   each edge orbit under a representative of each of the 20 signed
   cycle types. A signed cycle is classified by length and translation-bit
   XOR. Axis permutations identify equal-length cycles, and translations
   conjugate bit patterns of the same XOR on each cycle. Burnside gives
   287,954,372 degree-8 orbits, 59,404 degree-4 orbits and 161 degree-2
   orbits. `orbit_control.py` independently enumerates the degree-two
   profiles and partitions their explicit 384-element group images,
   recovering 24,962 profiles and 161 orbits. These are envelope counts.
   They do not count surviving 96-component occupations after parity.

Measured Darwin runs from `measure.py` took 1.49 s and 136,445,952 bytes
peak RSS for the count DP, 0.029 s and 6,373,376 bytes for Burnside with
the count DP's identity contribution, 0.54 s and 26,148,864 bytes for
the independent orbit check, and 1.77 s and 91,176,960 bytes for the
source control. The measured pilots cover support or a restricted
coefficient only.

A prospective explicit d-orbit-first evaluator, with a preflight cap of
10 million representatives, must refuse before writing a representative
table or attempting full exterior products. The exact envelope contains
over 28 times that many orbit representatives. Even a packed 4-byte
identifier per orbit would exceed 1.15 GB before any weights or keys.
The four-oriented-profile Cartesian schedule also refuses before
enumeration. These are caps on the stated schedules, not a lower bound
on an intertwined parity/saturation algorithm. The support counts above
come from DPs that do not materialize these orbits or tuples.

The arithmetic itself has a finite exact bound. There are 192 total
quaternion occurrences (six per factor). An anchor can occur at most
once in one factor, whose center is at the anchor's origin or one of its
four neighbors, so its degree is at most 20. For a surviving complete
term let r_i be half the degree in each SU(2) factor, with sum 96.
The product of Haar denominators divides `2^96 * 192!`, since
`sum_active (r_i+1) <= 192`. The original coframe quarters contribute
`2^128`, and the occupation factorial product divides 32!. Thus a
common Gaussian rational scale is `D=2^224 * 192! * 32!` (1527 bits).
This permits exact rational accumulation or exact modular arithmetic
away from the scale's prime divisors. The accepted action-norm estimate
gives `abs(c0)<=2^800`, so D times c0 has integer components with a
2327-bit magnitude bound. A nonzero modular residue would suffice for
nonvanishing if obtained from the complete contraction. Zero residues
would need modulus product exceeding twice the magnitude bound for an
exact zero conclusion.

A smaller exact schedule would join center occupations, directed anchor
and chirality parities, and odd-generator occupancy before emitting any
d orbit or four-roster tuple. Use only local multiplicity states
(`binom(10,6)=210` at one center), maintain labeled exterior masks
and unresolved quaternion exponents, and integrate an anchor only
after all of its contributing centers have been consumed. Project a
site's mask to its full top when all of its coframe incidences are
closed. The actual state frontier under that join is unmeasured and
needs its own preflight before a full launch. Exact cancellation in
that complete frontier remains unresolved.

## Boundary

The output is an exact support reduction, source-backed controls and a
measured refusal for two candidate schedules. Neither the eight-generator
test, a restricted inverse-pair zero, nor an inserted eight-site nodal
moment evaluates the original 128-generator full-Haar c0. No sign,
zero or nonzero conclusion for c0 follows here. Independent mathematical
and original-source review of this scratch report remains for the lead.

## Reproduction

Build `count.cpp` and `burnside.cpp` with
`clang++ -std=c++17 -O3 -Wall -Wextra -Werror`. Run the binaries through
`python3 measure.py ./count` and `python3 measure.py ./burnside`.
Run `python3 support_controls.py` and
`python3 measure.py "$(command -v python3)" orbit_control.py`.
For `source_control.py`, use the exact primary checkout on PYTHONPATH
and its existing venv interpreter with PYTHONDONTWRITEBYTECODE=1.
