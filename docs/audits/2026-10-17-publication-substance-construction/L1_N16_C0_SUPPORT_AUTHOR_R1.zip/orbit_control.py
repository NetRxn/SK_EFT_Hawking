from itertools import permutations, product

vertices = range(16)
edges = sorted((v, v ^ (1 << i)) for v in vertices for i in range(4) if not v & (1 << i))
edge_index = {edge: i for i, edge in enumerate(edges)}
even = [v for v in vertices if v.bit_count() % 2 == 0]
odd = sorted(set(vertices) - set(even))
rows = [tuple(tuple(sorted((v, v ^ (1 << i)))) for i in range(4)) for v in even]
last = {v: max(i for i, row in enumerate(rows) if any(v in edge for edge in row)) for v in odd}
degree_two = [x for x in product(range(3), repeat=4) if sum(x) == 2]
def generate(i, degrees, profile):
    if i == 8:
        yield tuple(profile)
        return
    row = rows[i]
    neighbors = [edge[0] ^ edge[1] ^ even[i] for edge in row]
    for weights in degree_two:
        after = tuple(degrees[v] + w for v, w in zip(neighbors, weights))
        if any(d > 2 or (last[v] == i and d != 2) for v, d in zip(neighbors, after)):
            continue
        for v, d, edge, w in zip(neighbors, after, row, weights):
            degrees[v] = d
            profile[edge_index[edge]] = w
        yield from generate(i + 1, degrees, profile)
        for v, w in zip(neighbors, weights):
            degrees[v] -= w

def edge_permutation(p, b):
    vertex_map = [b ^ sum(1 << p[i] for i in range(4) if v & (1 << i)) for v in vertices]
    return tuple(edge_index[tuple(sorted((vertex_map[v], vertex_map[w])))] for v, w in edges)

group = [edge_permutation(p, b) for p in permutations(range(4)) for b in vertices]
assert len(set(group)) == 384
remaining = set(generate(0, [0] * 16, [0] * 32))
assert len(remaining) == 24962
orbit_count = 0
while remaining:
    x = next(iter(remaining))
    orbit = {tuple(x[i] for i in g) for g in group}
    assert len(orbit) and 384 % len(orbit) == 0 and orbit <= remaining
    remaining.difference_update(orbit)
    orbit_count += 1
assert orbit_count == 161
print("independent degree-two explicit orbit partition:", orbit_count)
