from collections import Counter
from itertools import combinations
from math import factorial

sites = range(16)
axes = range(4)
planes = tuple(combinations(axes, 2))
anchors = [(x, k) for x in sites for k in axes]
edges = [(x, k) for x, k in anchors if not x & (1 << k)]

def analyze(m):
    coframe = Counter()
    curvature = Counter()
    for (x, k, ell), n in m.items():
        assert n >= 0
        for axis in set(axes) - {k, ell}:
            coframe[x, axis] += n
        for anchor in ((x, k), (x ^ (1 << k), ell), (x ^ (1 << ell), k), (x, ell)):
            curvature[anchor] += n
    assert sum(m.values()) == 32
    assert all(sum(n for (y, _, _), n in m.items() if x == y) <= 4 for x in sites)
    d = {(x, k): coframe[x, k] + coframe[x ^ (1 << k), k] for x, k in edges}
    top = [sum(d[x & ~(1 << k), k] for k in axes) for x in sites]
    boundary_failure = []
    directed_failure = []
    anchor_choices = 1
    for (x, k), degree in d.items():
        a = curvature[x, k] % 2
        b = curvature[x ^ (1 << k), k] % 2
        if degree % 2 != (a + b) % 2:
            boundary_failure.append((x, k))
        choices = [n for n in range(degree + 1) if n % 2 == a and (degree - n) % 2 == b]
        if not choices:
            directed_failure.append((x, k))
        anchor_choices *= len(choices)
        assert bool(choices) == (degree >= a + b and degree % 2 == (a + b) % 2)
    assert top == [8] * 16
    return d, boundary_failure, directed_failure, anchor_choices

full = {(x, k, ell): 1 for x in sites for k, ell in ((0, 1), (2, 3))}
mutated = full.copy()
mutated[0, 0, 1] = mutated[0, 2, 3] = 0
mutated[0, 0, 2] = mutated[0, 1, 3] = 1
d1, b1, s1, a1 = analyze(full)
d2, b2, s2, a2 = analyze(mutated)
assert d1 == d2 and set(d1.values()) == {2}
assert b1 == s1 == [] and a1 == 2 ** 32
assert len(b2) == len(s2) == 8 and a2 == 0
print("same degree-8 profile, different face-boundary result:", len(b1), len(b2))

restricted = {(x, 2, 3): 2 for x in sites}
split_mutation = {(x, 2, 3): 2 + ((-1) ** (x.bit_count() % 2)) * bool(x & 4) for x in sites}
d3, b3, s3, a3 = analyze(restricted)
d4, b4, s4, a4 = analyze(split_mutation)
assert d3 == d4
assert b3 == s3 == b4 == [] and a3 == 3 ** 16
assert len(s4) == 8 and a4 == 0
print("same degree-8 profile and face parity, different directed result:", len(s3), len(s4))
print("directed blockers:", s4)

scale = factorial(32) * 2 ** 224 * factorial(192)
assert scale.bit_length() == 1527
print("common denominator bits:", scale.bit_length())
print("degree-two four-roster Cartesian candidates:", 24962 ** 4)
print("full quartic roster union bound:", 210 ** 16)
