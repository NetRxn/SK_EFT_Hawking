import json
import os
import sys
import time

start = time.monotonic()
pid = os.posix_spawn(sys.argv[1], sys.argv[1:], os.environ)
child, status, rusage = os.wait4(pid, 0)
assert child == pid and os.waitstatus_to_exitcode(status) == 0, status
print(json.dumps({
    "seconds": time.monotonic() - start,
    "user_seconds": rusage.ru_utime,
    "system_seconds": rusage.ru_stime,
    "maxrss_bytes_on_darwin": rusage.ru_maxrss,
}, sort_keys=True))
