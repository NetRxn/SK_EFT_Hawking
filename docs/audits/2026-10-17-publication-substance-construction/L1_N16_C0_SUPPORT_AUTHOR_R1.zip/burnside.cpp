#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>
using Count = uint64_t;
using Edge = std::pair<int, int>;
using Perm = std::array<int, 4>;

int image(int v, Perm p, int b) {
    int w = b;
    for (int i = 0; i < 4; ++i)
        if ((v >> i) & 1)
            w ^= 1 << p[i];
    return w;
}

std::string conjugacy_type(Perm p, int b) {
    std::array<bool, 4> seen{};
    std::string type;
    for (int i = 0; i < 4; ++i) {
        if (seen[i]) continue;
        int length = 0, flips = 0;
        for (int j = i; !seen[j]; j = p[j]) {
            seen[j] = true;
            ++length;
            flips ^= (b >> j) & 1;
        }
        type += char('0' + 2 * length + flips);
    }
    std::sort(type.begin(), type.end());
    return type;
}

struct Orbit {
    std::array<int, 16> counts{};
    std::vector<int> sites;
    uint64_t nibble_counts{};
};
std::vector<Orbit> edge_orbits(Perm p, int b) {
    std::set<Edge> unseen;
    for (int i = 0; i < 16; ++i)
        for (int axis = 0; axis < 4; ++axis)
            if (((i >> axis) & 1) == 0)
                unseen.insert({i, i ^ (1 << axis)});
    std::vector<Orbit> result;
    while (!unseen.empty()) {
        const auto root = *unseen.begin();
        auto edge = root;
        Orbit orbit;
        do {
            if (unseen.erase(edge) != 1) std::abort();
            ++orbit.counts[edge.first];
            ++orbit.counts[edge.second];
            auto [v, w] = edge;
            edge = std::minmax(image(v, p, b), image(w, p, b));
        } while (edge != root);
        for (int i = 0; i < 16; ++i) {
            if (orbit.counts[i] == 0) continue;
            orbit.sites.push_back(i);
            orbit.nibble_counts |= uint64_t(orbit.counts[i]) << (4 * i);
        }
        result.push_back(orbit);
    }
    return result;
}

Count fixed(Perm p, int b, int degree, std::size_t& peak) {
    auto orbits = edge_orbits(p, b);
    std::array<int, 16> last{};
    for (std::size_t i = 0; i < orbits.size(); ++i)
        for (int v : orbits[i].sites)
            last[v] = i;
    std::unordered_map<uint64_t, Count> states{{0, 1}};
    for (std::size_t i = 0; i < orbits.size(); ++i) {
        std::unordered_map<uint64_t, Count> next;
        const auto& orbit = orbits[i];
        for (auto [key, count] : states) {
            int maximum = degree, required = -1;
            for (int v : orbit.sites) {
                int residue = degree - ((key >> (4 * v)) & 15);
                maximum = std::min(maximum, residue / orbit.counts[v]);
                if (last[v] == int(i)) {
                    if (residue % orbit.counts[v] != 0 ||
                        (required >= 0 && required != residue / orbit.counts[v])) {
                        maximum = -1;
                        break;
                    }
                    required = residue / orbit.counts[v];
                }
            }
            if (required >= 0 && required <= maximum)
                next[key + orbit.nibble_counts * required] += count;
            if (required < 0)
                for (int weight = 0; weight <= maximum; ++weight)
                    next[key + orbit.nibble_counts * weight] += count;
        }
        if (next.size() > 3000000) std::abort();
        peak = std::max(peak, next.size());
        states.swap(next);
    }
    if (states.size() > 1) std::abort();
    return states.empty() ? 0 : states.begin()->second;
}

int main() {
    Perm id{0, 1, 2, 3};
    std::map<std::string, std::pair<int, std::pair<Perm, int>>> classes;
    auto p = id;
    do {
        for (int b = 0; b < 16; ++b) {
            auto& item = classes[conjugacy_type(p, b)];
            ++item.first;
            item.second = {p, b};
        }
    } while (std::next_permutation(p.begin(), p.end()));

    for (int degree : {2, 4, 8}) {
        Count total = 0;
        std::size_t peak = 0;
        for (const auto& [type, cls] : classes) {
            auto [size, rep] = cls;
            auto [p, b] = rep;
            Count count;
            if (p == id && b == 0) {
                count = degree == 2 ? 24962 : degree == 4 ? 20126899 : 109621610869;
            } else {
                count = fixed(p, b, degree, peak);
            }
            std::cout << degree << ' ' << type << ' ' << size << ' ' << count << '\n';
            total += size * count;
        }
        if (total % 384 != 0) std::abort();
        std::cout << "degree " << degree << " orbit count " << total / 384
                  << " maximum states, nonidentity " << peak << '\n';
    }
}
