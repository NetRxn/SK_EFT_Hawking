from fractions import Fraction
from itertools import product
import json

from src.core.formulas import original_spin4_link

zero = (Fraction(), Fraction())
one = (Fraction(1), Fraction())
identity = ((one, zero), (zero, one))

def complex_add(z, w):
    return (z[0] + w[0], z[1] + w[1])

def complex_mul(z, w):
    a, b = z
    c, d = w
    return (a*c - b*d, a*d + b*c)

def conj(z):
    return (z[0], -z[1])

def dagger(A):
    return tuple(tuple(conj(A[j][i]) for j in range(2)) for i in range(2))

def matrix_mul(A, B):
    return tuple(tuple(complex_add(complex_mul(A[i][0], B[0][j]),
                                   complex_mul(A[i][1], B[1][j]))
                       for j in range(2)) for i in range(2))

def adjugate(A):
    return ((A[1][1], tuple(-v for v in A[0][1])),
            (tuple(-v for v in A[1][0]), A[0][0]))

def determinant(A):
    return complex_add(complex_mul(A[0][0], A[1][1]),
                       tuple(-v for v in complex_mul(A[0][1], A[1][0])))

def coordinates(A):
    return (A[0][0][0], A[0][1][1], A[0][1][0], A[0][0][1])

def expected_block(q):
    a, b, c, d = q
    return (((a, d), (c, b)), ((-c, b), (a, -d)))

def constant_pair(polynomial):
    if not polynomial.terms:
        return zero
    ((key, value),) = polynomial.terms
    assert key == ()
    return value.real, value.imag

def python_block(q, index):
    full = original_spin4_link(q if index == 0 else (1, 0, 0, 0),
                               q if index == 2 else (1, 0, 0, 0))
    return tuple(tuple(constant_pair(full[i][j]) for j in range(index, index+2))
                 for i in range(index, index+2))

def norm_sq(q):
    return sum(x*x for x in q)

def stereographic(t):
    t = tuple(Fraction(x) for x in t)
    radius = norm_sq(t)
    return ((1-radius)/(1+radius), *(2*x/(1+radius) for x in t))

def left(A, q):
    return coordinates(matrix_mul(A, expected_block(q)))

def plus(q, r):
    return tuple(a+b for a, b in zip(q, r))

def scale(c, q):
    return tuple(c*a for a in q)

units = tuple(stereographic(t) for t in product(range(-2, 3), repeat=3))
units += ((Fraction(-1), Fraction(), Fraction(), Fraction()),)
vectors = tuple(tuple(Fraction(x, 3) for x in v) for v in product(range(-1, 2), repeat=4))
assert norm_sq((Fraction(1, 2),)*4) == 1
assert max(abs(v) for v in (Fraction(1, 2),)*4) == Fraction(1, 2)
blocks = 0
for q in units + vectors:
    A = expected_block(q)
    assert coordinates(A) == q
    assert determinant(A) == (norm_sq(q), Fraction())
    for index in (0, 2):
        assert python_block(q, index) == A
        blocks += 1

actions = 0
for u in units:
    A = expected_block(u)
    A_inv = dagger(A)
    assert norm_sq(u) == 1
    assert determinant(A) == one
    assert A_inv == adjugate(A)
    assert matrix_mul(A_inv, A) == identity
    for index, q in enumerate(vectors):
        r = vectors[(13*index+1) % len(vectors)]
        Aq = left(A, q)
        B = expected_block(units[(17*index+4) % len(units)])
        assert expected_block(Aq) == matrix_mul(A, expected_block(q))
        assert norm_sq(Aq) == norm_sq(q)
        assert left(A_inv, Aq) == q
        assert left(A, plus(q, r)) == plus(Aq, left(A, r))
        assert left(A, scale(Fraction(-5, 7), q)) == scale(Fraction(-5, 7), Aq)
        assert left(matrix_mul(A, B), q) == left(A, left(B, q))
        actions += 1

# A genuinely complex first row exposes swapping b and c in the inverse.
q = stereographic((1, 2, 3))
assert q[1] != q[2]
A = expected_block(q)
wrong_inverse = (A[0][0][0], A[0][1][0], A[0][1][1], A[0][0][1])
assert expected_block(wrong_inverse) != A
print(json.dumps(dict(unit_quaternions=len(units), ambient_vectors=len(vectors),
                      both_chiral_block_matches=blocks, left_action_cases=actions,
                      inverse_swap_rejected=True, euclidean_sup_norm_separated=True)))
