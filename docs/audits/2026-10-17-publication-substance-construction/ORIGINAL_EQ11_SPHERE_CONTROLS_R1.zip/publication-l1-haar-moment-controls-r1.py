from fractions import Fraction
from itertools import product
from math import factorial
import json

from src.core.formulas import original_quaternion_haar_moment

def independent_gaussian_ratio(powers):
    if any(n % 2 for n in powers):
        return Fraction(0)
    half_powers = tuple(n // 2 for n in powers)
    value = Fraction(1, 2 ** sum(half_powers) * factorial(sum(half_powers) + 1))
    for n in half_powers:
        value *= Fraction(factorial(2 * n), 2 ** n * factorial(n))
    return value

max_degree = 18
cases = 0
odd = 0
sphere_identity = 0
for powers in product(range(max_degree + 1), repeat=4):
    degree = sum(powers)
    if degree > max_degree:
        continue
    expected = independent_gaussian_ratio(powers)
    actual = original_quaternion_haar_moment(powers)
    assert actual == expected, (powers, actual, expected)
    cases += 1
    odd += any(n % 2 for n in powers)
    if degree <= max_degree - 2:
        terms = tuple(tuple(v + (2 if j == i else 0) for j, v in enumerate(powers))
                      for i in range(4))
        assert sum((original_quaternion_haar_moment(p) for p in terms), Fraction()) == actual
        sphere_identity += 1
print(json.dumps(dict(max_degree=max_degree, cases=cases, odd=odd,
                      sphere_identity=sphere_identity)))
