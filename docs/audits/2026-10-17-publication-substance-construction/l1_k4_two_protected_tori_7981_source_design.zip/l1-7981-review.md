# Independent mathematical design review:79/81

**ACCEPT the mathematical design, subject to the explicit implementation and direct/fixed controls below.** No new evaluator implementation has yet been supplied or reviewed. This accepts a construction route, not factor preparation, execution, fixed values, unrestricted coefficients or portable coverage. Portable scope stays232/272 and all40 remaining unrestricted coefficients, including parallel110/153, remain owed.

## Recovery, exact inputs and attempts

Packet `publication-l1-7981-design-review-r1.json` checked fresh. Scientific authority is immutable commit `16fde9b0803019d55d0b10250fed52e6258c1d42`; all18 scientific-source hashes in the captured author JSON equal those Git blobs. The captured probe was read, not imported or run. Independent reviewer graph code was extracted from the previous independent stdlib reconstruction, and the complete272 manifest was read from its immutable Git blob. Transient broad-test seeds were not treated as scientific state.

`python3 /tmp/l1-7981-review.py` ultimately exited0 in0.15s. It uses only stdlib graph/AST/JSON/hash/Fraction operations and accepted225-branch AST with pure domain stubs. No scientific import, moment, gamma preparation, factor table, control, coefficient, heavy test, production seed, process/slot or candidate/notebook/primary write was performed. Broad85890 remained untouched.

Two **stdlib checker** mistakes are preserved as `/tmp/l1-7981-review-attempt1.py/.json` and `-attempt2.py/.json`: the extended all272 scan initially asserted the singleton-source-torus condition before filtering free-torus110, and the161/163 diagnostic initially assumed its square was fully action-protected. The exact predicate was completed and the excluded square was selected by its unique non-(2,3) plane. These were reviewer checker assumptions, not source defects or scientific attempts; no input or receipt was rewritten.

Captured input SHA256 values at review:

- Derivation: `a296e8e6657b4546cd64f2d5bcc46a50b5cd9016cee62649e4ef479a834fa5b7`.
- Geometry JSON: `cbed097dcbf9b2f16d1ac8e2a3aaf448ac0d9963dbd3fe029495d8a67b68deb1`.
- Probe: `d9979aea0a8d3b6f46e71cbafb1d8af2f1df8b17cfa157a5fc71ccab84e3acbe`.

The author corrected the initial phrase “thirty paired curvature copies” to **fifteen curvature pairs (thirty curvature occurrences)**. Reversing only that phrase reproduces the initial derivation SHA256 `97742a09fd2f19c0d8080e9bf9354bedf68026b755621dc65342a0fe022855ae`, proving that the correction changes no construction or control plan. The final derivation hash above includes this wording correction. Its separately disclosed earlier live-anchor metadata correction remains disclosed; the final captured geometry correctly asserts anchor1 and frame gamma slot1.

## Exact family and physical geometry

The previously independently proved232 accepted indices are disjoint from the parallel design110/153. Removing those two assignments leaves a38-word planning partition, not an additional accepted population. The complete predicate—nine-face residual core, one fully action-protected square, two four-face(2,3) tori each protected only by one distinct original source, and a singleton square/torus intersection equal to an original source—was independently checked over all272 words and selects exactly79/81. Both are same-axis. The full38 roster is in `/tmp/l1-7981-review-verification.json`.

|Word|Square; live|Three fixed square links|Additional source completing joint forest|Omitted action center|
|---|---|---|---|---|
|79|`(3,1,2)`;`(3,1)`|`(1,2),(3,2),(7,1)`|`(0,2)`|2|
|81|`(2,1,2)`;`(2,1)`|`(0,2),(2,2),(6,1)`|`(1,2)`|3|

Both joint forests contain4 edges on6 physical vertices, in2 acyclic components. The two source links `(0,2),(1,2)` remain explicit. Each torus has8 directed links, with only its own source protected; after joint fixing it has7 remaining Haar variables. Square/torus intersection is exactly the shared source; all other square links are outside both torus boundaries, and the two torus boundaries are disjoint. The square live link is outside both. Square curvature center3/2 is disjoint from all8 torus centers0,1,4,5,8,9,12,13.

Joint normalized-Haar forest fixing has volume1 under the existing accepted site-covariant convention. The shared source becomes a single deterministic identity in both square and torus; the other source becomes identity in its own torus. The square live, torus0 seven and torus1 seven Haar coordinates are disjoint. Conditional curvature integration consequently supplies the square tensor times two protected15 tensors. Opposite directed periodic links are still integrated. The global action/gamma/Grassmann response does not factor.

Each graph retains15 paired action vertices, both degree4 source polynomials,20 action geometric edges and all16 Grassmann integration sites. Omitted action center2/3 is not removed from the physical Grassmann measure. Independent incidence gives38 factors,32 twice-occurring labels and degree8 at every site. There are6 peeled curvature pairs and9 retained pairs: one explicit square and8 torus pairs.

## Exact routing requirements for implementation

These actual modified action factors all use **frame gamma pair index1**:

|Word|Factor edge|Action center|Frame slot|Center flag|Physical anchor|Weight selector|
|---|---|---:|---:|---:|---:|---|
|79|live1–3,axis1|1|1|0|1|source1 torus|
|79|fixed3–7,axis2|7|1|1|0|peeled|
|79|fixed5–7,axis1|5|1|0|1|source1 torus|
|81|live0–2,axis1|0|1|0|1|source0 torus|
|81|fixed2–6,axis2|6|1|1|0|peeled|
|81|fixed4–6,axis1|4|1|0|1|source0 torus|

The accepted generic `prepare` already obtains an edge label's gamma pair through `row[g.frame[q].index(axis)]`. Preserve that mechanism. Its later `gamma[0]` at a singleton edge means the first **edge-local label**, whose value has already come from frame slot1; replacing it with `gamma[1]` would be incorrect. Do not copy a prior first-frame-axis assumption or hard-code the live physical anchor0.

Use `probed_action_edge(edge_gamma,center=0,physical_anchor=1,probe)` for the actual live singleton, then global `(lo,hi)` remap. Both fixed edges are singletons with the exact center/physical-anchor pairs `(1,0)` and `(0,1)`. The generic fixed helper fixes only the declared directed anchor and integrates its opposite. Preserve endpoint signs and remaps. One fixed action center is peeled and the other torus-weighted; they must not be conflated or assigned equal gamma restrictions by convenience.

Square component weights belong only at square center3/2. Merge the two protected core dictionaries only on their disjoint4+4 center domains, retaining `core.get(q)` at all8 torus centers and peeled selectors at the other6 action centers. Keep all action edges and both sources in one factor graph. Source0/source1 torus domains couple through actual two-center action edges and the full Grassmann contraction, even though their conditional Haar variables are disjoint.

The square's3 fixed links populate `fixed_square`; action-anchor flags can be derived from them. The extra fixed source is absent from action geometric edges, so it does not create an action-moment factor. `fixed_sources` must nevertheless contain BOTH sources, `joined_source` remains empty (J0), and both explicit identity source polynomials must reach the source loop once, remapped to sites0,4 and1,5. A new geometry wrapper must expose the existing `prepare` fields without changing the accepted scientific AST; the new225-branch iterator can reuse accepted two-protected-tori `branches` with ordered torus records.

##225 terms, normalization and transpose

Order torus roles by original source `(0,2)` then `(1,2)`:

- Source0 torus: linked0,4; other8,12.
- Source1 torus: linked1,5; other9,13.

Each has15 exact protected branches. The full225 Cartesian products include all scalar, same/opposite chirality, mixed/linked matching domains, and52 negative product weights. Independent Fraction/domain reconstruction matches every one of225 captured weights and merged8-center dictionaries in both words. The actual accepted225-branch AST reproduces those exact products when executed with pure stdlib domain stubs.

XOR1 exchanges source roles. Therefore word79 branch `(i,j)` maps to word81 `(j,i)`, flat `15i+j → 15j+i`. All225 weights and translated merged domains satisfy that relation. Comparing equal flat indices without transposition would be invalid except at coincidentally equal entries. Source swap is even because each insertion has degree4. This remains a geometry/domain prediction; no coefficient covariance has been computed.

E20 contributes192^40 raw directed moment scales; the2 explicit fixed sources contribute192^2. Sixty action coframes and4 source coframes contribute4^64;6 peeled curvature pairs contribute48^6;15 paired factorials contribute2^15. The divisor is

`192^42 * 4^64 * 48^6 * 2^15`.

The explicit square and2 protected tensors retain all9 unpeeled pairs. Do not append48^8, another source moment, forest volume, source permutation, translation, shear or axis multiplicity.

##161/163 remain a separate coupled-holonomy construction

Word161's square `(7,1,2)` shares `(5,2)`, opposite source `(1,2)`; word163's square `(6,1,2)` shares `(4,2)`, opposite source `(0,2)`. Those shared links are outside the action/source protected set. Fixing both directed source and its shared opposite link forms a genuine2-edge periodic cycle. Independent union-find verifies failure of the joint identity forest route. The relative holonomy must remain in a coupled square/torus tensor and be integrated jointly with its action/probe. This excludes those words from79/81, without asserting impossibility or zero coefficients.

## Required independent controls before execution/pilot

Only after ROOT grants fresh authorization and reconciles the broad-test freeze:

1. Inspect the actual new evaluator source and require unchanged accepted `prepare`/`contraction` ASTs, exact4-edge forest/source metadata, original caps and an ordered225-product branch iterator. Add explicit assertions for all6 routing rows above and the second gamma slots. No implementation has yet passed this source review.
2. Directly test joint4-edge forest covariance with both source links nonidentity before fixing, consistent endpoint rotations and both complete source polynomials. Include both forest components and all16 physical sites. Never average the shared link independently in square and torus or gauge-fix a cycle.
3. Verify actual square21-probe coefficients for both face orientations with basis plus exact multiple-coordinate left/right quaternions; activate off-diagonal and mixed-chirality probes. Compare direct original holonomies with square row reconstruction. A basis-only or trace-only check is insufficient.
4. Independently integrate each actual source-bearing torus, then compare their conditional product and square tensor with all225-term formulas on a representative Cartesian component set including diagonal, linked off-diagonal, mixed and opposite-chirality assignments. Preserve disconnected scalar factors at closure. The source polynomials remain external once each. No final source/Grassmann scalar product may replace the global graph.
5. Direct cubature of the live edge must use actual second-frame gamma rows and `(center,physical_anchor)=(0,1)`, with off-diagonal quaternion probes. Direct fixed singleton cubature must exercise both `(1,0)` and `(0,1)` orientations and the actual torus/peeled gamma selectors. Inspect nonzero and zero local polynomials separately; use actual supported rows for meaningful global restrictions.
6. Prepare all225 branches for each word only after authorization. Verify every center weight from original gamma tensors, square/protected/peeled routing, both source polynomials, actual slot extraction and all38-factor/32-label/128-generator/site-degree invariants, exact weights/divisors and original120000-row/3000000-pair caps. Structural empty support, computed zero, timeout and resource exhaustion are distinct outcomes.
7. Run complete fixed-gamma controls over all450 branches and verify raw/weight/divisor covariance under **the225-index transpose**, as well as the final exact weighted sums. Include prepared-row/local-polynomial controls that distinguish first versus second frame slots and preserve global torus coupling.
8. Before one unrestricted pilot, independently accept direct/fixed receipts and bindings. Cold preparation must retain each actual prepared table once; the warm deadline covers the entire225 contractions and reuses those exact tables. Do not copy a15-loop, omit negative/opposite-chirality branches, call solve after a separate cold preparation, or infer timing from the prior families. Existing600cold/60WHOLE225warm/665parent bounds and caps remain unless ROOT explicitly changes them. Preserve every failed/terminal attempt and metadata correction.

All selected79/81 coefficients, parallel110/153, other36 planning-partition words and original full ensemble/commonZ/physicalB3/modes/transport/main/publication obligations remain open. Design acceptance supplies no234/236 portable claim.
