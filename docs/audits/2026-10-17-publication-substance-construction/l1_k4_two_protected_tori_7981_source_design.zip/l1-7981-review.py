from pathlib import Path
from collections import Counter,defaultdict
from itertools import product,combinations_with_replacement
from fractions import Fraction
from types import SimpleNamespace
import ast,json,hashlib,subprocess
P=Path('/tmp');repo=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103');prefix='docs/audits/2026-10-17-publication-substance-construction/'
pk=json.loads(Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-l1-7981-design-review-r1.json').read_text());commit=pk['source']['head'];assert commit=='16fde9b0803019d55d0b10250fed52e6258c1d42'
def blob(name):return subprocess.run(['git','show',commit+':'+prefix+name],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
def digest(b):return hashlib.sha256(b).hexdigest()
author=json.loads((P/'l1-residual38-second-family-geometry.json').read_text());previous=json.loads((P/'l1-residual40-review-verification.json').read_text());assert previous['pinned_immutable_source_commit']==commit
assert all(digest(blob(n))==h for n,h in author['source_sha256'].items()) and len(author['source_sha256'])==18
manifest=next(json.loads(l) for l in blob('l1_k4_census.out.txt').splitlines() if json.loads(l).get('kind')=='paired-k4-census');assert digest(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode())==author['manifest_sha256']=='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b'
rem40=set(previous['remaining40']);accepted=set(range(272))-rem40;assert accepted==set(author['accepted_roster']) and len(accepted)==232
rem38=sorted(rem40-{110,153});assert rem38==author['residual38_roster'] and set(rem38).isdisjoint(accepted|{110,153})
# Previously independent stdlib graph function; execute only its AST, never module-level code.
funcs={n.name:n for n in ast.parse((P/'l1-residual40-review.py').read_text()).body if isinstance(n,ast.FunctionDef)};ns={'Counter':Counter,'defaultdict':defaultdict};exec(compile(ast.Module(body=[funcs['graph']],type_ignores=[]),'independent_graph','exec'),ns);graph=ns['graph']
def protected(linked,other):
 bs=linked+other;yield Fraction(1,256),dict.fromkeys(bs,tuple((i,i) for i in range(6)))
 for c in (0,3):
  diag=tuple((i,i) for i in range(c,c+3));yield Fraction(-1,559872),dict.fromkeys(bs,diag)
  for pair in combinations_with_replacement(range(c,c+3),2):yield Fraction(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:diag,other[1]:diag}
selected=[];result=[];branches={};models={}
for row in manifest['rows']:
 frame,sources,edges,faces,protected_links,removed=graph(row)
 if len(faces)!=9:continue
 squares=[f for f,b in faces.items() if b<=protected_links]
 if len(squares)!=1:continue
 sq=squares[0];others={f:b for f,b in faces.items() if f!=sq}
 if any(f[1:]!=(2,3) for f in others):continue
 tori=[{f:b for f,b in others.items() if f[0]&3==c} for c in sorted({f[0]&3 for f in others})]
 if len(tori)!=2 or any(len(t)!=4 for t in tori):continue
 tb=[set.union(*t.values()) for t in tori];shared=faces[sq]&set.union(*tb)
 if len(shared)!=1 or not shared<=set(sources):continue
 if any(len(b&protected_links)!=1 or not (b&protected_links)<=set(sources) for b in tb):continue
 T=[]
 for t,b in zip(tori,tb):
  hits=b&protected_links;assert len(hits)==1;source,=hits;assert source in sources and sum(source in bd for bd in t.values())==2
  linked=source[0],source[0]^(1<<source[1]);other=tuple(f[0] for f in t if f[0] not in linked);assert len(other)==2
  T.append({'source':source,'faces':sorted(t),'boundary':b,'linked':linked,'other':other})
 T.sort(key=lambda t:t['source']);assert {t['source'] for t in T}==set(sources) and not T[0]['boundary']&T[1]['boundary']
 live=sq[0],sq[1];fixed=faces[sq]-{live};forest=fixed|set(sources);assert len(fixed)==3 and len(forest)==4
 parent={}
 def root(q):
  while q in parent:q=parent[q]
  return q
 for q,a in sorted(forest):
  lo,hi=root(q),root(q^(1<<a));assert lo!=hi;parent[lo]=hi
 assert {v for q,a in forest for v in (q,q^(1<<a))}==({0,1,3,4,5,7} if row['index']==79 else {0,1,2,4,5,6})
 assert len(edges)==20 and len(removed)==6 and all((min(q,q^(1<<a)),max(q,q^(1<<a)),a) not in edges for q,a in sources)
 assert not (faces[sq]-shared)&set.union(*tb) and live not in set.union(*tb)
 assert all(len(t['boundary']-forest)==7 for t in T)
 livekey=min(live[0],live[0]^(1<<live[1])),max(live[0],live[0]^(1<<live[1])),live[1]
 fixedkeys={(min(q,q^(1<<a)),max(q,q^(1<<a)),a):int(q>q^(1<<a)) for q,a in fixed}
 def incidence(e,labels,anchor):
  return {'edge':list(e),'physical_anchor':anchor,'labels':[{'center':q,'axis':a,'gamma_pair_index':frame[q].index(a),'center_relative_to_lo':int(q==e[1]),'role':'source0_torus' if q in {f[0] for f in T[0]['faces']} else 'source1_torus' if q in {f[0] for f in T[1]['faces']} else 'square' if q==sq[0] else 'peeled'} for q,a in labels]}
 li=incidence(livekey,edges[livekey],int(live[0]==livekey[1]));fi=[incidence(e,edges[e],a) for e,a in sorted(fixedkeys.items()) if e in edges]
 assert len(li['labels'])==1 and li['physical_anchor']==1 and li['labels'][0]['gamma_pair_index']==1 and li['labels'][0]['center_relative_to_lo']==0
 assert len(fi)==2 and all(len(f['labels'])==1 and f['labels'][0]['gamma_pair_index']==1 for f in fi)
 assert [(x['physical_anchor'],x['labels'][0]['center_relative_to_lo']) for x in fi]==[(0,1),(1,0)]
 centers=set.union(*({f[0] for f in t['faces']} for t in T));assert len(centers)==8 and sq[0] not in centers
 factors=[(tuple((q,a) for a in axes)+((('component',),) if q==sq[0] else ()),{}) for q,axes in sorted(frame.items())]
 for e,ks in sorted(edges.items()):
  lo,hi,a=e;factors.append((tuple(ks)+((('probe',),) if e==livekey else ()),{lo:2*len(ks),hi:2*len(ks)}))
 factors.append(((('component',),('probe',)),{}))
 for q,a in sources:factors.append(((),{q:2,q^(1<<a):2}))
 lc=Counter(k for ks,d in factors for k in ks);degree={q:sum(d.get(q,0) for ks,d in factors) for q in range(16)}
 assert len(factors)==38 and len(lc)==32 and set(lc.values())=={2} and degree==dict.fromkeys(range(16),8)
 prodbranch=[(w*v,c|d) for w,c in protected(T[0]['linked'],T[0]['other']) for v,d in protected(T[1]['linked'],T[1]['other'])];assert len(prodbranch)==225 and all(len(c)==8 for w,c in prodbranch)
 a=next(x for x in author['records'] if x['word']['index']==row['index']);assert a['live_incidence']==li and a['fixed_action_incidence']==fi and a['joint_forest']==[list(e) for e in sorted(forest)]
 for k,(weight,domain) in enumerate(prodbranch):
  b=a['branches'][k];assert b['index']==k and b['source0_branch']==k//15 and b['source1_branch']==k%15 and Fraction(*b['weight'])==weight and {int(q):tuple(tuple(x) for x in d) for q,d in b['core'].items()}==domain
 selected.append(row['index']);branches[row['index']]=prodbranch;models[row['index']]=SimpleNamespace(tori=[SimpleNamespace(linked=t['linked'],other=t['other']) for t in T])
 result.append({'word':row['index'],'omitted_action_center_retained_site':row['omitted'],'square':sq,'live':live,'fixed_square':sorted(fixed),'joint_four_edge_forest':sorted(forest),'forest_components':2,'live_incidence':li,'fixed_action_incidence':fi,'both_sources':sources,'torus_roles':[{'source':t['source'],'linked':t['linked'],'other':t['other'],'faces':t['faces']} for t in T],'all16_site_degrees8':True,'factors':38,'labels':32,'E':20,'J':0,'peeled':6,'divisor':192**42*4**64*48**6*2**15,'terms':225,'negative_terms':sum(w<0 for w,c in prodbranch)})
assert selected==[79,81] and set(selected)<=set(rem38)
a,b=manifest['rows'][79],manifest['rows'][81];assert a['omitted']^1==b['omitted'] and sorted((q^1,a) for q,a in a['changes'])==sorted((q,a) for q,a in b['changes'])
for i in range(15):
 for j in range(15):
  a=branches[79][15*i+j];b=branches[81][15*j+i];assert a[0]==b[0] and {q^1:v for q,v in a[1].items()}==b[1]
# Reuse accepted225-branch AST with pure Fraction/domain stub to prove its role order.
bs=next(n for n in ast.parse(blob('l1_extended_offset_witness_k4_two_protected_tori.py')).body if isinstance(n,ast.FunctionDef) and n.name=='branches');bn={'k2':SimpleNamespace(protected_branches=protected),'product':product};exec(compile(ast.Module(body=[bs],type_ignores=[]),'accepted_225_branches','exec'),bn)
assert all(list(bn['branches'](g))==branches[w] for w,g in models.items())
# Opposite directed periodic link creates genuine parallel-edge cycle for161/163.
excluded=[]
for w in (161,163):
 frame,sources,edges,faces,prot,removed=graph(manifest['rows'][w]);sq=next(f for f in faces if f[1:]!=(2,3));tb=set.union(*(b for f,b in faces.items() if f!=sq));shared,=faces[sq]&tb
 opposite=(shared[0]^(1<<shared[1]),shared[1]);assert opposite in sources and shared not in sources and shared[1]==2
 parent={};cycle=False
 for q,a in sorted((faces[sq]-{(sq[0],sq[1])})|set(sources)):
  def root(q):
   while q in parent:q=parent[q]
   return q
  x,y=root(q),root(q^(1<<a))
  if x==y:cycle=True
  else:parent[x]=y
 assert cycle;excluded.append({'word':w,'shared_square_link':shared,'opposite_source':opposite,'joint_identity_forest_cycle':True,'separate_relative_holonomy_required':True})
# Accepted prepare actually selects the frame slot using .index(axis); gamma[0] at the edge is not frame slot0.
prepare=next(n for n in ast.parse(blob('l1_extended_offset_witness_k4_connected_source_square_torus.py')).body if isinstance(n,ast.FunctionDef) and n.name=='prepare');ps=ast.unparse(prepare)
assert 'row[g.frame[q].index(axis)]' in ps and 'core.get(q)' in ps and 'int(g.lives[index][0] == hi)' in ps and 'fixed_action_edge(gamma, centers, g.fixed_edges[edge])' in ps
out={'verdict':'ACCEPT79/81 mathematical design with explicit gamma-slot/anchor implementation requirements; no evaluator source yet reviewed','immutable_commit':commit,'input_hashes':{str(P/n):digest((P/n).read_bytes()) for n in ['l1-residual38-second-family-derivation.md','l1-residual38-second-family-geometry.json','l1-residual38-second-family-probe.py']},'all18_scientific_source_hashes_equal_immutable_git':True,'accepted232_and_excluded_parallel110153_disjoint':True,'residual38':rem38,'family_exactly':selected,'complete_predicate_checked_all272':True,'geometry':result,'all225_exact_product_domains_match_author_per_word':True,'all225_XOR1_transpose_weights_domains_verified':True,'accepted225_branches_AST_checked_with_pure_stubs':True,'generic_prepare_actual_slot_and_anchor_contract_verified':True,'161163_exclusion':excluded,'no_scientific_import_preparation_control_coefficient_or_heavy_test':True,'portable_scope':232,'all40_portable_remaining_coefficients_still_owed':True,'full_k4_sourceaction_commonZ_B3_modes_transport_main_publication':'OPEN'}
(P/'l1-7981-review-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
