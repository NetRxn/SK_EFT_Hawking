from pathlib import Path
from collections import Counter,defaultdict
from itertools import product,combinations_with_replacement
from fractions import Fraction
import ast,json,hashlib
A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
captured=Path('/tmp/l1-residual40-author-geometry.json');x=json.loads(captured.read_text());manifest=json.loads((A/'l1_k4_census.out.txt').read_text().splitlines()[1]);mh=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert mh==x['manifest_sha256']
accepted=set.union(*(set(v) for v in x['accepted_populations'].values()));assert len(accepted)==232
remaining=[r for r in manifest['rows'] if r['index'] not in accepted|{110,153}];assert len(remaining)==38

def graph(row):
 frame={q:(0,1) for q in range(16) if q!=row['omitted']};frame.update((q,tuple(a)) for q,a in row['changes']);sources=((0,row['axes'][0]),(1,row['axes'][1]));edges=defaultdict(list);faces={}
 for q,axes in sorted(frame.items()):
  for a in axes:
   y=q^(1<<a);edges[min(q,y),max(q,y),a].append((q,a))
  a,b=(a for a in range(4) if a not in axes);faces[q,a,b]={(q,a),(q^(1<<a),b),(q^(1<<b),a),(q,b)}
 protected=set(sources)|{(v,a) for lo,hi,a in edges for v in (lo,hi)};removed=[]
 while faces:
  counts=Counter(e for b in faces.values() for e in b);deletions=[f for f,b in faces.items() if any(counts[e]==1 and e not in protected for e in b)]
  if not deletions:break
  for f in deletions:removed.append(f);del faces[f]
 return frame,sources,edges,faces,protected,removed

def branches(linked,other):
 bases=linked+other;D=tuple((i,i) for i in range(6));out=[(Fraction(1,256),dict.fromkeys(bases,D))]
 for c in (0,3):
  diag=tuple((i,i) for i in range(c,c+3));out.append((Fraction(-1,559872),dict.fromkeys(bases,diag)))
  for pair in combinations_with_replacement(range(c,c+3),2):out.append((Fraction(2 if pair[0]==pair[1] else 1,279936),dict(zip(bases,((pair,),(pair,),diag,diag)))))
 assert len(out)==15;return out
selected=[]
for row in remaining:
 frame,sources,edges,faces,protected,removed=graph(row)
 if len(faces)!=9:continue
 squares=[f for f,b in faces.items() if b<=protected]
 if len(squares)!=1:continue
 square,=squares;tfaces={f:b for f,b in faces.items() if f!=square}
 if any(f[1:]!=(2,3) for f in tfaces):continue
 tori=[{f:b for f,b in tfaces.items() if f[0]&3==c} for c in sorted({f[0]&3 for f in tfaces})]
 if len(tori)!=2 or any(len(t)!=4 for t in tori):continue
 shared=faces[square]&set.union(*(set.union(*t.values()) for t in tori))
 if len(shared)!=1 or not shared<=set(sources):continue
 assert len(removed)==6 and len(edges)==20
 live=square[0],square[1];fixed=faces[square]-{live};forest=fixed|set(sources);assert len(forest)==4
 parent={}
 def root(q):
  while q in parent:q=parent[q]
  return q
 for q,a in sorted(forest):
  u,v=root(q),root(q^(1<<a));assert u!=v;parent[u]=v
 T=[]
 for t in tori:
  source,=set.union(*t.values())&protected;assert source in sources
  assert sum(source in b for b in t.values())==2
  linked=source[0],source[0]^(1<<source[1]);other=tuple(f[0] for f in t if f[0] not in linked)
  assert len(other)==2 and set(linked)<={f[0] for f in t};T.append(dict(faces=sorted(t),source=source,linked=linked,other=other,boundaries=sorted(set.union(*t.values()))))
 T.sort(key=lambda t:t['source']);assert not set(T[0]['boundaries'])&set(T[1]['boundaries'])
 assert set(sources)=={t['source'] for t in T};assert square[0] not in {f[0] for t in T for f in t['faces']}
 assert not (faces[square]-shared)&set.union(*(set(t['boundaries']) for t in T))
 fk={(min(q,q^(1<<a)),max(q,q^(1<<a)),a):int(q>q^(1<<a)) for q,a in fixed};q,a=live;lk=min(q,q^(1<<a)),max(q,q^(1<<a)),a
 assert len(edges[lk])==1
 assert all((min(q,q^(1<<a)),max(q,q^(1<<a)),a) not in edges for q,a in sources)
 center_roles={q:'square' if q==square[0] else 'source0_torus' if q in [f[0] for f in T[0]['faces']] else 'source1_torus' if q in [f[0] for f in T[1]['faces']] else 'peeled' for q in frame}
 factors=[(tuple((q,a) for a in axes)+(('square_component',) if q==square[0] else ()),{}) for q,axes in frame.items()]
 for (lo,hi,a),labels in edges.items():factors.append((tuple(labels)+(('square_probe',) if (lo,hi,a)==lk else ()),{lo:2*len(labels),hi:2*len(labels)}))
 factors.append((('square_component','square_probe'),{}))
 for q,a in sources:factors.append(((),{q:2,q^(1<<a):2}))
 degrees={q:sum(d.get(q,0) for _,d in factors) for q in range(16)};counts=Counter(str(k) for keys,_ in factors for k in keys)
 assert degrees==dict.fromkeys(range(16),8) and len(factors)==38 and len(counts)==32 and set(counts.values())=={2}
 B=[]
 for i,(w,c) in enumerate(branches(T[0]['linked'],T[0]['other'])):
  for j,(v,d) in enumerate(branches(T[1]['linked'],T[1]['other'])):
   assert not set(c)&set(d);z=w*v;B.append(dict(index=15*i+j,source0_branch=i,source1_branch=j,weight=[z.numerator,z.denominator],core={str(q):dom for q,dom in (c|d).items()}))
 def incidence(e,labels,anchor):
  return dict(edge=e,physical_anchor=anchor,labels=[dict(center=q,axis=a,gamma_pair_index=frame[q].index(a),center_relative_to_lo=int(q==e[1]),role=center_roles[q]) for q,a in labels])
 selected.append(dict(word=row,frame=sorted(frame.items()),sources=sources,source_face_incidence=[(s,[f for f,b in faces.items() if s in b]) for s in sources],square=square,square_boundary=sorted(faces[square]),live=live,live_incidence=incidence(lk,edges[lk],int(live[0]==lk[1])),fixed_square=sorted(fixed),joint_forest=sorted(forest),fixed_action_incidence=[incidence(e,edges[e],fk[e]) for e in sorted(fk) if e in edges],tori=T,peeled_faces=sorted(removed),action_edges=sorted(edges.items()),center_roles=center_roles,site_degrees=degrees,omitted_action_center_retained_site=row['omitted'],factor_count=38,label_count=32,all_label_multiplicities=2,E=20,J=0,divisor_exponents={'192':42,'4':64,'48':6,'2':15},divisor=192**42*4**64*48**6*2**15,branches=B))
assert [g['word']['index'] for g in selected]==[79,81]
names=('l1_direct_b_haar','l1_extended_four_face_gauge_join','l1_extended_mixed_center_gamma','l1_extended_mixed_curvature_core','l1_extended_mixed_frame_moment','l1_extended_offset_square','l1_extended_offset_witness','l1_extended_offset_witness_k2','l1_extended_offset_witness_k3','l1_extended_offset_witness_k4','l1_extended_offset_witness_k4_free_torus','l1_extended_offset_witness_k4_peeled','l1_extended_offset_witness_k4_single_square','l1_extended_offset_witness_k4_two_square','l1_extended_opposed_source','l1_extended_two_mixed_centers','l1_extended_offset_witness_k4_connected_source_square_torus','l1_extended_offset_witness_k4_two_protected_tori')
hashes={n+'.py':hashlib.sha256((A/(n+'.py')).read_bytes()).hexdigest() for n in names}
for n in names:ast.parse((A/(n+'.py')).read_text())
result=dict(packet='publication-l1-residual38-second-design-r1',candidate_head='16fde9b0803019d55d0b10250fed52e6258c1d42',status='stdlib-only design; no scientific execution or acceptance',captured_geometry_sha256=hashlib.sha256(captured.read_bytes()).hexdigest(),manifest_sha256=mh,source_sha256=hashes,accepted_roster=sorted(accepted),excluded_parallel_family=[110,153],residual38_roster=[r['index'] for r in remaining],selected_complete_family=[79,81],remaining_after_proposal=36,records=selected,control_plan=['Independently rederive complete family selector over all272 words and exact232/excluded2 partition','Joint forest covariance: four edges, both sources, actual directed orientations; no source insertion removed','Exact square quaternion polynomial on all21 probes and multi-coordinate nonidentity forests','Both protected torus direct Haar tensors (15terms each), full225 product, same/opposite chirality mixed patterns','Live singleton SECOND-gamma at center1/0 and two singleton fixed action edges at centers5/7 or4/6; direct moments in both physical anchors','Both identity source polynomials and retained omitted2/3 physical sites; all38 factors32 labels degree8 at16sites','Prepare all450 branch graphs only after ROOT authorization; retain branch weights and structural zero/failure distinction','All450 fixed-Gamma raw controls and XOR1 mapping i,j to j,i, flat15i+j to15j+i','Independent direct/fixed acceptance before one unrestricted ROOT-authorized full225-branch pilot with original caps and budget'])
Path('/tmp/l1-residual38-second-family-geometry.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'family':result['selected_complete_family'],'summary':[{k:r[k] for k in ('square','live','joint_forest','live_incidence','fixed_action_incidence','divisor')} for r in selected],'source_sha256':hashes},sort_keys=True))
