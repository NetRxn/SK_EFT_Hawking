from pathlib import Path
from collections import Counter,defaultdict,namedtuple
from itertools import product,combinations_with_replacement
from fractions import Fraction
from types import SimpleNamespace
import ast,json,hashlib
A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');P=Path('/tmp/l1-7981-evaluator-draft-r1.py');S=P.read_text();tree=ast.parse(S)
def fnode(s,n):return next(x for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name==n)
def install(s,n,env):exec(compile(ast.Module([fnode(s,n)],[]),'<stdlib-only-extracted-'+n+'>','exec'),env)
old=(A/'l1_extended_offset_witness_k4_connected_source_square_torus.py').read_text();two_source=(A/'l1_extended_offset_witness_k4_two_protected_tori.py').read_text()
unchanged={n:ast.dump(fnode(S,n),include_attributes=False)==ast.dump(fnode(old,n),include_attributes=False) for n in ('prepare','contraction')};unchanged['branches']=ast.dump(fnode(S,'branches'),include_attributes=False)==ast.dump(fnode(two_source,'branches'),include_attributes=False);unchanged['solve']=ast.dump(fnode(S,'solve'),include_attributes=False)==ast.dump(fnode(two_source,'solve'),include_attributes=False);assert all(unchanged.values())
# Never execute module import/header, prepare, contraction, solve or local moments.
manifest=json.loads((A/'l1_k4_census.out.txt').read_text().splitlines()[1]);captured=json.loads(Path('/tmp/l1-residual38-second-family-geometry.json').read_text())
baseenv={'Counter':Counter,'defaultdict':defaultdict};install((A/'l1_extended_offset_witness_k4_two_square.py').read_text(),'base',baseenv)
env={'Counter':Counter,'defaultdict':defaultdict,'product':product,'Fraction':Fraction,'IDENTITY':object(),'hashlib':hashlib,'json':json,'two':SimpleNamespace(base=baseenv['base']),'k3':SimpleNamespace(witness=SimpleNamespace(SCALE=192)),'k4':SimpleNamespace(data=lambda:(manifest,None)),'EXPECTED_WORDS':(79,81),'EXPECTED_MANIFEST_SHA256':captured['manifest_sha256']}
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('Torus','Geometry') for t in node.targets):exec(compile(ast.Module([node],[]),'<namedtuple-only>','exec'),{'namedtuple':namedtuple},env)
for n in ('family_geometry','geometry','data','describe','branches'):install(S,n,env)
# Protected/core ASTs operate only on finite label dictionaries and rational weights.
coreenv={'Fraction':Fraction,'BASES':(1,5,9,13),'DIAGONAL':tuple((i,i) for i in range(6)),'combinations_with_replacement':combinations_with_replacement};install((A/'l1_extended_offset_witness.py').read_text(),'core_branches',coreenv)
penv={'witness':SimpleNamespace(BASES=coreenv['BASES'],core_branches=coreenv['core_branches'])};install((A/'l1_extended_offset_witness_k2.py').read_text(),'protected_branches',penv);env['k2']=SimpleNamespace(protected_branches=penv['protected_branches'])
found=env['data']();assert tuple(found)==(79,81);assert len(manifest['rows'])==272
results=[];allbranches={}
for w,(row,g) in found.items():
 expected=next(r for r in captured['records'] if r['word']['index']==w);desc=env['describe'](row,g)
 assert sorted(g.frame.items())==[(q,tuple(axes)) for q,axes in expected['frame']]
 assert g.divisor==expected['divisor'] and sorted(g.forest)==list(map(tuple,expected['joint_forest']))
 assert desc['live_action_routing']['physical_anchor']==1
 assert desc['live_action_routing']['labels'][0]['frame_gamma_slot']==1
 assert sorted((d['labels'][0]['center_flag'],d['physical_anchor']) for d in desc['fixed_action_routing'])==[(0,1),(1,0)]
 assert all(d['labels'][0]['frame_gamma_slot']==1 for d in desc['fixed_action_routing'])
 B=list(env['branches'](g));assert len(B)==225
 for (weight,core),b in zip(B,expected['branches'],strict=True):
  assert [weight.numerator,weight.denominator]==b['weight'];assert json.loads(json.dumps(core))==b['core']
 # Symbolic incidence mirrors unchanged prepare's fields, without building any factors.
 centers=[(tuple((q,a) for a in axes)+(('square_component',) if q==g.squares[0][0] else ()),{}) for q,axes in g.frame.items()]
 live=g.lives[0];lk=min(live[0],live[0]^(1<<live[1])),max(live[0],live[0]^(1<<live[1])),live[1]
 edgef=[(tuple(labels)+(('square_probe',) if e==lk else ()),{e[0]:2*len(labels),e[1]:2*len(labels)}) for e,labels in g.edges.items()]
 sources=[((),{q:2,q^(1<<a):2}) for q,a in g.sources]
 F=centers+edgef+[(('square_component','square_probe'),{})]+sources;counts=Counter(str(k) for keys,_ in F for k in keys)
 assert len(F)==38 and len(counts)==32 and set(counts.values())=={2}
 assert all(sum(d.get(q,0) for _,d in F)==8 for q in range(16))
 assert len(g.fixed_sources)==2 and len(sources)==2 and not g.joined_source
 allbranches[w]=B;results.append({'word':w,'metadata':desc,'branches':225,'negative_weights':sum(weight<0 for weight,core in B),'symbolic_factor_count':38,'symbolic_label_count':32,'all16_degree8':True,'all225_weights_domains_equal_accepted_design':True})
for i,(weight,core) in enumerate(allbranches[79]):
 j=15*(i%15)+i//15;v,d=allbranches[81][j];assert weight==v and {q^1:labels for q,labels in core.items()}==d
assert env['family_geometry'](next(r for r in manifest['rows'] if r['index']==161)) is None
assert env['family_geometry'](next(r for r in manifest['rows'] if r['index']==163)) is None
# Exact generic AST slot/source dispatch retained, not a first-axis substitute.
prepare_ast=ast.dump(fnode(S,'prepare'),include_attributes=False);assert 'gamma[1]' not in ast.get_source_segment(S,fnode(S,'prepare'))
sourcefiles=[A/n for n in captured['source_sha256']];hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sourcefiles};assert hashes==captured['source_sha256']
# Source orchestration AST mock: synthetic sentinels only, no actual factor preparation.
for n in ('prepare_branches','contract_prepared'):install(S,n,env)
seen=[];sentinel=object()
def fake_prepare(g,core,restrict=None):
 seen.append((core,restrict));return (sentinel,g.divisor,sentinel)
env['prepare']=fake_prepare
g=found[79][1];synthetic=env['prepare_branches'](g,{'sentinel':'restriction'})
assert len(seen)==len(synthetic)==225 and all(r=={'sentinel':'restriction'} for c,r in seen)
calls=[]
def fake_eliminate(f,e):
 assert f is sentinel and e is sentinel;calls.append(1);return 1,7
env['k3']=SimpleNamespace(eliminate_components=fake_eliminate)
emitted=[];value,peak=env['contract_prepared'](synthetic,g.divisor,emitted.append)
assert len(calls)==len(emitted)==225 and peak==7 and [r['branch'] for r in emitted]==list(range(225))
assert value==sum((w for w,t in synthetic),Fraction())/g.divisor
assert all(r['divisor']==g.divisor and not r['algebraic_empty_preparation'] for r in emitted)
# No source scientific entry point has been imported/executed by this probe.
result={'packet':'publication-l1-7981-evaluator-draft-r1','status':'AST/source design evidence only; no scientific execution','evaluator':str(P),'evaluator_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'manifest_sha256':captured['manifest_sha256'],'all272_structural_selector_exact79_81':True,'unchanged_ASTs':unchanged,'synthetic_orchestration_225_prepares_225_contracts_225_emits':True,'source_sha256':hashes,'source0_major_source1_minor_225_transpose_verified':True,'all450_branch_weights_domains_verified':True,'records':results,'explicit_exclusions':[161,163],'source_binding':{'BOTH_fixed_source_polynomials':True,'global_frame_slot1_routed_through_edge_local_gamma0':True,'live_physical_anchor1_fixed_anchors0_1':True},'required_controls':'Fresh independent actual-source acceptance, then ROOT authorization for direct F4/BOTHsource/quaternion/two-protected225tensor/live and fixed singleton slot1 moments/all450 preparations and fixed controls. No unrestrictedpilot until independent direct/fixed acceptance.'}
Path('/tmp/l1-7981-evaluator-draft-verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({'evaluator_sha256':result['evaluator_sha256'],'unchanged_ASTs':unchanged,'exact_family':[79,81],'branch_count_each':225,'negative_weights_each':results[0]['negative_weights'],'all450_domains_verified':True,'no_scientific_execution':True},sort_keys=True))
