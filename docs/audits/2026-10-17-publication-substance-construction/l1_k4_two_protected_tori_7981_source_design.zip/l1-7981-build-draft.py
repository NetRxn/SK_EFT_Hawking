from pathlib import Path
import ast
A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
old=(A/'l1_extended_offset_witness_k4_connected_source_square_torus.py').read_text();two=(A/'l1_extended_offset_witness_k4_two_protected_tori.py').read_text()
def function(s,name):
 n=next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name==name);return ast.get_source_segment(s,n)
header='''"""Exact selected k4 source-sharing square with two protected tori.

Both sources, all fifteen paired action vertices and sixteen physical Grassmann
sites remain. Joint four-edge forest fixing separates conditional curvature
Haar tensors only; the complete action/source/gamma contraction stays global.
All225 source-ordered protected branch products are retained, including signs
and opposite chirality. This selected family is not the physical B3 response.
"""
'''
start=old[old.index('import sys,'):old.index('Geometry=namedtuple')]
start=start.replace("AUDIT=Path(__file__).resolve().parent", "AUDIT=Path(__file__).resolve().parent\nif not (AUDIT/'l1_extended_offset_witness_k3.py').is_file():\n AUDIT=Path("+repr(str(A))+")")
geom='''Torus=namedtuple('Torus','faces fixed_source linked other')
Geometry=namedtuple('Geometry','frame edges sources squares lives fixed_square fixed_edges joined_source divisor fixed_sources tori shared_source forest')

def family_geometry(row):
 frame,sources,edges,faces,protected,removed=two.base(row)
 if len(frame)!=15 or len(row['changes'])!=4 or len(faces)!=9 or len(removed)!=6:return None
 squares=tuple(f for f,b in faces.items() if b<=protected)
 if len(squares)!=1:return None
 square,=squares;rest={f:b for f,b in faces.items() if f!=square}
 if any(f[1:]!=(2,3) for f in rest):return None
 groups=[{f:b for f,b in rest.items() if f[0]&3==c} for c in sorted({f[0]&3 for f in rest})]
 if len(groups)!=2 or any(len(t)!=4 for t in groups):return None
 incidence=[set.union(*t.values())&protected for t in groups]
 if any(len(s)!=1 or not s<=set(sources) for s in incidence):return None
 if set.union(*incidence)!=set(sources):return None
 shared=faces[square]&set.union(*(set.union(*t.values()) for t in groups))
 if len(shared)!=1 or not shared<=set(sources):return None
 shared_source,=shared
 assert not set.union(*groups[0].values())&set.union(*groups[1].values())
 assert not (faces[square]-shared)&set.union(*(set.union(*t.values()) for t in groups))
 live=square[0],square[1];fixed=dict.fromkeys(faces[square]-{live},IDENTITY)
 forest=set(fixed)|set(sources);assert len(fixed)==3 and len(forest)==4
 parent={}
 def root(q):
  while q in parent:q=parent[q]
  return q
 vertices=set()
 for q,a in sorted(forest):
  y=q^(1<<a);vertices.update((q,y));u,v=root(q),root(y);assert u!=v;parent[u]=v
 assert len(vertices)==6 and len({root(q) for q in vertices})==2
 fixed_edges={}
 for q,a in fixed:
  y=q^(1<<a);fixed_edges[min(q,y),max(q,y),a]=int(q>y)
 tori=[]
 for t,inc in zip(groups,incidence,strict=True):
  source,=inc;q,a=source;linked=q,q^(1<<a);other=tuple(f[0] for f in t if f[0] not in linked)
  assert len(other)==2 and set(linked)<=set(f[0] for f in t)
  assert sum(source in b for b in t.values())==2
  tori.append(Torus(t,source,linked,other))
 tori=tuple(sorted(tori,key=lambda t:t.fixed_source))
 assert len(edges)==20 and square[0] not in {f[0] for t in tori for f in t.faces}
 assert all((min(q,q^(1<<a)),max(q,q^(1<<a)),a) not in edges for q,a in sources)
 q,a=live;y=q^(1<<a);key=min(q,y),max(q,y),a
 assert len(edges[key])==1
 center,axis=edges[key][0]
 assert frame[center].index(axis)==1 and center==key[0] and q==key[1]
 actual_fixed=[]
 for edge,anchor in sorted(fixed_edges.items()):
  if edge not in edges:continue
  labels=edges[edge];assert len(labels)==1
  c,axis=labels[0];assert frame[c].index(axis)==1
  actual_fixed.append((int(c==edge[1]),anchor))
 assert sorted(actual_fixed)==[(0,1),(1,0)]
 endpoints=Counter(v for q,a in sources for v in (q,q^(1<<a)))
 incoming=Counter(q^(1<<a) for q,axes in frame.items() for a in axes)
 assert all(4*(q in frame)+2*incoming[q]+2*endpoints[q]==8 for q in range(16))
 divisor=k3.witness.SCALE**(2*len(edges)+2)*4**64*48**6*2**15
 return Geometry(frame,edges,sources,squares,(live,),{square:fixed},fixed_edges,{},divisor,set(sources),tori,shared_source,forest)

def geometry(row):
 result=family_geometry(row);assert result is not None
 return result

def data():
 manifest,_=k4.data();found={}
 assert hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()==EXPECTED_MANIFEST_SHA256
 for row in manifest['rows']:
  g=family_geometry(row)
  if g is not None:found[row['index']]=(row,g)
 assert tuple(found)==EXPECTED_WORDS
 return found
'''
meta='''EXPECTED_WORDS=(79,81)
EXPECTED_MANIFEST_SHA256='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b'

def describe(row,g):
 square,=g.squares;live,=g.lives;q,a=live;y=q^(1<<a);key=min(q,y),max(q,y),a
 def routing(edge,labels,anchor):
  return {'edge':edge,'physical_anchor':anchor,'labels':[{'center':c,'axis':axis,'frame_gamma_slot':g.frame[c].index(axis),'center_flag':int(c==edge[1])} for c,axis in labels]}
 fixed=[routing(e,g.edges[e],anchor) for e,anchor in sorted(g.fixed_edges.items()) if e in g.edges]
 return {'word':row,'sources':g.sources,'fixed_sources':sorted(g.fixed_sources),
         'squares':g.squares,'lives':g.lives,'fixed_square_links':sorted(g.fixed_square[square]),
         'joint_forest':sorted(g.forest),'forest_components':2,'shared_source':g.shared_source,
         'tori':[{'faces':sorted(t.faces),'fixed_source':t.fixed_source,'linked':t.linked,'other':t.other} for t in g.tori],
         'live_action_routing':routing(key,g.edges[key],int(q==key[1])),
         'fixed_action_routing':fixed,'action_edges':len(g.edges),'joined_edges':sorted(g.joined_source),
         'paired_action_vertices':len(g.frame),'grassmann_sites':16,'peeled':6,'divisor':g.divisor,
         'branch_order':'source0_major_source1_minor','xor1_branch_map':'15*i+j -> 15*j+i'}
'''
prep='''def prepare_branches(g,restrict=None):
 prepared=[(weight,prepare(g,core,restrict)) for weight,core in branches(g)]
 assert len(prepared)==225
 return prepared
'''
contract=function(old,'contract_prepared').replace('assert len(prepared)==15','assert len(prepared)==225')
main=function(old,'main').replace("'branches':15","'branches':225").replace("connected-source-square-torus","source-sharing-square-two-protected-tori").replace("whole15_warm_seconds","whole225_warm_seconds")
text='\n\n'.join([header+start+geom,function(old,'prepare'),function(old,'contraction'),function(two,'branches'),function(two,'solve'),meta,function(old,'source_hashes'),prep,contract,main,"if __name__=='__main__':main()\n"])
p=Path('/tmp/l1-7981-evaluator-draft-r1.py');p.write_text(text);ast.parse(text)
for n in ('prepare','contraction'):
 assert ast.dump(ast.parse(function(text,n)),include_attributes=False)==ast.dump(ast.parse(function(old,n)),include_attributes=False)
assert ast.dump(ast.parse(function(text,'branches')),include_attributes=False)==ast.dump(ast.parse(function(two,'branches')),include_attributes=False)
print('AST-only source created; preserved prepare/contraction/branches ASTs')
