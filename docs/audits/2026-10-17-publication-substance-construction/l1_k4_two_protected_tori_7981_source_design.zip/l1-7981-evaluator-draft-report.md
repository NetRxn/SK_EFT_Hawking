#79/81 evaluator draft: source-only delivery

Packet `publication-l1-7981-evaluator-draft-r1` checked fresh. Read current56fe notebook and independent `/tmp/l1-7981-review.md` design acceptance. ROOT owns repository/notebook and future execution authorization. Current153 author/110 independent replay CPU lanes were not touched.

New scratch source `/tmp/l1-7981-evaluator-draft-r1.py`, SHA256 **e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7**. No scientific module import, factor preparation, local moment/control, fixed coefficient, unrestricted coefficient or scientific batch occurred. All statements below are AST/stdlib source-design evidence.

The actual structural selector scans the canonical272 manifest and selects exactly79/81:15 paired action vertices/four frame changes;9 residual/6peeled faces; one action-protected square; two four-face(2,3) tori each protected by exactly one distinct original source; singleton square/torus shared link is a source.161/163 are excluded by the predicate, not by index blacklist. Joint forest has4 edges on6 physical vertices in2 acyclic components. Both explicit source identity polynomials and all16 integration sites are retained.

The draft preserves **exact AST equality** for accepted connected-source `prepare` and `contraction` and accepted two-protected-tori `branches` and `solve`. Edge-local `gamma[0]` remains untouched: preceding `row[g.frame[q].index(axis)]` has already selected global frame gamma slot1. Live physical anchor1 and fixed singleton anchor/center pairs(0,1),(1,0) are asserted in actual geometry and exported explicitly through `describe`. One fixed action center is torus-weighted and one peeled; gamma tables remain globally coupled.

Source-ordered tori use linked0/4,other8/12 and linked1/5,other9/13. All225 protected15×15 products per word are retained,52 negative weights per word included. Exact Fraction weights and every merged8-center domain match all450 captured accepted design records. XOR1 transposes branch roles15i+j→15j+i; all225 weight/domain covariance checks pass in stdlib. Source/action incidence reconstructs38 factors/32 twice-occurring labels and degree8 at all16 sites without preparing any scientific tables. Divisor is192^42*4^64*48^6*2^15; E20/J0.

`prepare_branches` now iterates the actual225 `branches(g)` once; `contract_prepared` requires225 and emits every supplied branch. The unchanged generic contraction AST and accepted225-branch solve remain available. CLI metadata consistently says225 and `whole225_warm_seconds`. A stdlib mock of only orchestration ASTs with synthetic sentinel tables checks225 prepare calls,225 contraction calls,225 emitted records, unchanged exact weighted arithmetic and no extra cold preparation; this is not factor-preparation or scientific execution evidence.

`source_hashes` retains the accepted16 principal scientific dependency bindings and actual evaluator hash. The stdlib verifier additionally rehashes all18 scientific files captured by accepted design; all match. Portable installation uses source-adjacent audit modules; scratch-only fallback resolves this candidate audit path when source lives in/tmp. This fallback performs no action during AST inspection. Existing row120000/pair3000000 caps are asserted unchanged.

Artifacts:

- `/tmp/l1-7981-evaluator-draft-r1.py`: actual proposed source.
- `/tmp/l1-7981-evaluator-preservation.diff`: explicit diff from accepted connected-source evaluator; diff exit1 means intended differences.
- `/tmp/l1-7981-evaluator-ast-probe.py`: stdlib-only AST/graph/finite-domain/synthetic orchestration verifier.
- `/tmp/l1-7981-evaluator-draft-verification.json`: actualsource hash, eighteen kernel hashes, exact structural selection, routing/normalization, branch/domain and mock results.
- `/tmp/l1-7981-build-draft.py`: deterministic source assembler preserving scientific ASTs.

Required next substantive action: fresh independent review of this **actual evaluator source**, including generic gamma slot dispatch, directed anchors, four-edge forest, both source polynomials and225 complete products. Then ROOT may authorize direct joint nonidentity F4/BOTH-source covariance, exact square21-probe multi-coordinate quaternion, each protected15 tensor/full225 product, and live/fixed singleton second-slot moments. Only after authorization prepare all450 actual branch graphs and fixed-gamma controls, preserving structural-empty/computed-zero/resource/timeout distinctions and original600cold/60WHOLE225warm/665parent budgets/caps. No unrestricted pilot before independent direct/fixed acceptance. FullB3/commonZ/fullensemble/main/publication acceptance and selected79/81 coefficients remain open.

No encountered source bug or metadata correction was required in this draft. Earlier design metadata/prose corrections remain in their original recorded design history; this source does not overwrite any accepted kernel.
