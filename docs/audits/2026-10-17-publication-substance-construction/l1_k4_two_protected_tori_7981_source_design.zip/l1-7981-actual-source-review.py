from pathlib import Path
from collections import Counter,defaultdict,namedtuple
from fractions import Fraction
from itertools import product,combinations_with_replacement
from types import SimpleNamespace
from contextlib import redirect_stdout,redirect_stderr
from io import StringIO
import ast,json,hashlib,subprocess,sys
P=Path('/tmp');proposal=P/'l1-7981-evaluator-draft-r1.py';repo=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103');A=repo/'docs/audits/2026-10-17-publication-substance-construction';rel='docs/audits/2026-10-17-publication-substance-construction/';COMMIT='16fde9b0803019d55d0b10250fed52e6258c1d42'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blob(f):return subprocess.run(['git','show',COMMIT+':'+rel+f],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
assert sha(proposal)=='e4a228c1194e303001edb65ecdb416d3f9067eb90990bb45726bba91613f39e7'
text=proposal.read_text();tree=ast.parse(text);b={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
connected={n.name:n for n in ast.parse(blob('l1_extended_offset_witness_k4_connected_source_square_torus.py')).body if isinstance(n,ast.FunctionDef)};tori={n.name:n for n in ast.parse(blob('l1_extended_offset_witness_k4_two_protected_tori.py')).body if isinstance(n,ast.FunctionDef)}
assert all(ast.dump(b[n],include_attributes=False)==ast.dump(connected[n],include_attributes=False) for n in ('prepare','contraction')) and all(ast.dump(b[n],include_attributes=False)==ast.dump(tori[n],include_attributes=False) for n in ('branches','solve'))
proof=json.loads((P/'l1-7981-review-verification.json').read_text());capture=json.loads((P/'l1-residual38-second-family-geometry.json').read_text());assert len(capture['source_sha256'])==18 and all(hashlib.sha256(blob(n)).hexdigest()==h and sha(A/n)==h for n,h in capture['source_sha256'].items())
manifest=next(json.loads(l) for l in blob('l1_k4_census.out.txt').splitlines() if json.loads(l).get('kind')=='paired-k4-census')
ns={'Counter':Counter,'defaultdict':defaultdict};graph=next(n for n in ast.parse((P/'l1-residual40-review.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='graph');exec(compile(ast.Module(body=[graph],type_ignores=[]),'independent_graph','exec'),ns)
ns.update(hashlib=hashlib,json=json,IDENTITY=((1,0,0,0),(1,0,0,0)),two=SimpleNamespace(base=ns['graph']),k3=SimpleNamespace(witness=SimpleNamespace(SCALE=192)),k4=SimpleNamespace(data=lambda:(manifest,{})),Fraction=Fraction,product=product)
for n in tree.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('Torus','Geometry') for t in n.targets):
  typ,fields=map(ast.literal_eval,n.value.args);ns[typ]=namedtuple(typ,fields)
ns['EXPECTED_WORDS']=(79,81);ns['EXPECTED_MANIFEST_SHA256']='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b'
for k in ('family_geometry','geometry','data','describe'):exec(compile(ast.Module(body=[b[k]],type_ignores=[]),str(proposal),'exec'),ns)
found=ns['data']();assert list(found)==[79,81] and all(ns['family_geometry'](manifest['rows'][w]) is None for w in (110,153,161,163))
protected=next(n for n in ast.parse((P/'l1-7981-review.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='protected');bn={'Fraction':Fraction,'combinations_with_replacement':combinations_with_replacement};exec(compile(ast.Module(body=[protected],type_ignores=[]),'independent15_domains','exec'),bn)
ns['k2']=SimpleNamespace(protected_branches=bn['protected']);exec(compile(ast.Module(body=[b['branches']],type_ignores=[]),str(proposal),'exec'),ns)
allbranches={};routing_tests=0;records=[]
for word,(row,g) in found.items():
 meta=ns['describe'](row,g);old=next(r for r in proof['geometry'] if r['word']==word);assert [list(e) for e in sorted(g.forest)]==old['joint_four_edge_forest'] and meta['forest_components']==2 and meta['paired_action_vertices']==15 and meta['grassmann_sites']==16 and g.fixed_sources=={(0,2),(1,2)} and g.joined_source=={}
 assert len(g.edges)==20 and g.divisor==192**42*4**64*48**6*2**15
 branches=list(ns['branches'](g));assert len(branches)==225 and sum(w<0 for w,c in branches)==52
 cap=next(r for r in capture['records'] if r['word']['index']==word)
 for i,((w,c),r) in enumerate(zip(branches,cap['branches'])):assert r['index']==i and Fraction(*r['weight'])==w and {int(q):tuple(tuple(p) for p in ds) for q,ds in r['core'].items()}==c and len(c)==8 and g.squares[0][0] not in c
 # Symbolic source/action graph from actual new geometry.
 factors=[(tuple((q,a) for a in axes)+((('component',),) if q==g.squares[0][0] else ()),{}) for q,axes in sorted(g.frame.items())]
 q,a=g.lives[0];liveedge=min(q,q^(1<<a)),max(q,q^(1<<a)),a
 for edge,keys in sorted(g.edges.items()):
  lo,hi,a=edge;factors.append((tuple(keys)+((('probe',),) if edge==liveedge else ()),{lo:2*len(keys),hi:2*len(keys)}))
 factors.append(((('component',),('probe',)),{}))
 for q,a in g.sources:factors.append(((),{q:2,q^(1<<a):2}))
 lc=Counter(k for ks,d in factors for k in ks);assert len(factors)==38 and len(lc)==32 and set(lc.values())=={2} and all(sum(d.get(q,0) for ks,d in factors)==8 for q in range(16))
 # Evaluate the actual generic slot-selection expression with distinguishable first/second sentinel pairs.
 prep=b['prepare'];domains=next(n.value for n in ast.walk(prep) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='domains' for t in n.targets) and isinstance(n.value,ast.ListComp))
 probe_call=next(n for n in ast.walk(prep) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='probed_action_edge');fixed_call=next(n for n in ast.walk(prep) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='fixed_action_edge')
 for edge in [liveedge]+[e for e in sorted(g.fixed_edges) if e in g.edges]:
  keys=g.edges[edge];c,axis=keys[0];env={'g':g,'choices':{c:{((10,11),(20,21)):None}},'keys':keys};ds=eval(compile(ast.Expression(body=domains),str(proposal),'eval'),env);assert ds==[[(20,21)]] and g.frame[c].index(axis)==1
  env.update(gamma=((20,21),),centers=(int(c==edge[1]),),edge=edge,index=0,hi=edge[1],probe=(1,2),k3=SimpleNamespace(probed_action_edge=lambda *args:args,fixed_action_edge=lambda *args:args))
  args=eval(compile(ast.Expression(body=probe_call if edge==liveedge else fixed_call),str(proposal),'eval'),env)
  if edge==liveedge:assert args==((20,21),0,1,(1,2))
  else:assert args==(((20,21),),(int(c==edge[1]),),g.fixed_edges[edge])
  routing_tests+=1
 allbranches[word]=branches;records.append({'word':word,'metadata':meta,'225_terms':True,'52_negative_weights':True,'8_disjoint_core_domains':True,'38_factors32labels_all16site8':True,'second_frame_slot_routing_mock':True})
for i,j in product(range(15),repeat=2):
 w,c=allbranches[79][15*i+j];v,d=allbranches[81][15*j+i];assert w==v and {q^1:ds for q,ds in c.items()}==d
names=next(ast.literal_eval(n.value) for n in ast.walk(b['source_hashes']) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in n.targets));binding=json.loads((P/'l1-next42-author-binding.json').read_text())['principal_source_sha256'];assert len(names)==16 and set(n+'.py' for n in names)==set(binding) and all(sha(A/n)==h for n,h in binding.items())
assert any(isinstance(n,ast.Assert) and 'k2.ROW_CAP == 120000 and k2.PAIR_CAP == 3000000'==ast.unparse(n.test) for n in tree.body)
# Inert opaque-table helper and argparse tests from prior independent checker, adapted only population/word constants.
namespace={'Fraction':Fraction};g=SimpleNamespace(linked=(1,5),other=(9,13));restrict=object();core=[object() for i in range(225)];tables=[([object()],60,object()) if i!=4 else None for i in range(225)];weights=[Fraction((i+1)*(-1 if i%7==0 else 1),16) for i in range(225)];calls=[]
namespace['branches']=lambda actual_g:iter(zip(weights,core)) if actual_g is g else (_ for _ in ()).throw(AssertionError('wrong geometry'))
def fakeprepare(actual_g,actual_core,actual_restrict):
 assert actual_g is g and actual_restrict is restrict;i=len(calls);assert actual_core is core[i];calls.append(i);return tables[i]
namespace['prepare']=fakeprepare
for name in ('prepare_branches','contract_prepared'):exec(compile(ast.Module(body=[b[name]],type_ignores=[]),str(proposal),'exec'),namespace)
prepared=namespace['prepare_branches'](g,restrict);assert calls==list(range(225)) and all(p[1] is t for p,t in zip(prepared,tables))
seen=[]
def fake_eliminate(factors,exclusive):
 i=next(i for i,t in enumerate(tables) if t is not None and t[0] is factors);assert tables[i][2] is exclusive;seen.append(i);return (i+1)*60,i+100
namespace['k3']=SimpleNamespace(eliminate_components=fake_eliminate);events=[];value,peak=namespace['contract_prepared'](prepared,60,events.append)
assert seen==[i for i in range(225) if i!=4] and len(events)==225 and peak==324
assert value==sum((weights[i]*Fraction((i+1)*60 if i!=4 else 0,60) for i in range(225)),Fraction())
for i,e in enumerate(events):assert e['branch']==i and e['weight']==[weights[i].numerator,weights[i].denominator] and e['algebraic_empty_preparation']==(i==4) and e['raw_numerator']==((i+1)*60 if i!=4 else 0)
try:namespace['contract_prepared'](prepared,61)
except AssertionError:pass
else:raise AssertionError('divisor mismatch not rejected')
assert len(calls)==225 # contraction never calls prepare again
# Run actual argparse/main AST against inert geometry and opaque prepared-table mocks.
mainns={'Fraction':Fraction,'json':json,'EXPECTED_WORDS':(79,81),'EXPECTED_MANIFEST_SHA256':'ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b','__doc__':'Portable review mock CLI','perf_counter':lambda:1.0}
gs={i:SimpleNamespace(frame={0:(0,1),1:(0,1)},divisor=64) for i in (79,81)};data_calls=[];prep_calls=[];contract_calls=[]
mainns['data']=lambda:(data_calls.append(True) or {i:({'index':i},gs[i]) for i in (79,81)})
mainns['source_hashes']=lambda:{'evaluator':sha(proposal)};mainns['k2']=SimpleNamespace(ROW_CAP=120000,PAIR_CAP=3000000);mainns['k3']=SimpleNamespace(witness=SimpleNamespace(FIXED_GAMMAS=((0,0),(1,1))))
mainns['describe']=lambda row,g:{'word':row,'divisor':g.divisor};opaque={i:object() for i in (79,81)}
def prepstub(g,restrict=None):
 i=next(i for i in (79,81) if gs[i] is g);prep_calls.append((i,restrict));return opaque[i]
def contractstub(p,d):
 i=next(i for i in (79,81) if opaque[i] is p);assert d==64;contract_calls.append(i);return Fraction(9,4),7
mainns['prepare_branches']=prepstub;mainns['contract_prepared']=contractstub
exec(compile(ast.Module(body=[b['main']],type_ignores=[]),str(proposal),'exec'),mainns)
def cli(args):
 old=sys.argv;sys.argv=['portable.py',*args];stdout,stderr=StringIO(),StringIO();code=0
 try:
  with redirect_stdout(stdout),redirect_stderr(stderr):
   try:mainns['main']()
   except SystemExit as e:code=e.code
 finally:sys.argv=old
 return code,stdout.getvalue(),stderr.getvalue()
code,out,err=cli([]);v=json.loads(out);assert code==0 and v['valid_words']==[79,81] and not prep_calls and not contract_calls
for word in (79,81):
 code,out,err=cli(['--word',str(word)]);v=json.loads(out);assert code==0 and v['word']['index']==word and v['branches']==225 and v['raw_numerator']==144 and prep_calls[-1]==(word,None) and contract_calls[-1]==word
prep_calls.clear();contract_calls.clear();code,out,err=cli(['--controls-only']);v=[json.loads(l) for l in out.splitlines()];assert code==0 and all(r['branches']==225 for r in v) and [r['word'] for r in v]==[79,81] and [i for i,r in prep_calls]==[79,81] and contract_calls==[79,81]
assert all(r=={0:((0,0),(1,1)),1:((0,0),(1,1))} for i,r in prep_calls)
refusals={}
for args in (['--word','109'],['--word','154'],['--word','79','--controls-only'],['--word','notint'],['--unknown']):
 before=len(data_calls);code,out,err=cli(args);assert code==2 and len(data_calls)==before and not out;refusals[' '.join(args)]=code
result={'verdict':'ACCEPT actual79/81 evaluator source/design only; no scientific execution authorized by this review','draft_sha256':sha(proposal),'preserved_ASTs':{'prepare':'accepted connected1fdb','contraction':'accepted connected1fdb','branches':'acceptedtwo-protected6d8e','solve':'acceptedtwo-protected6d8e'},'all18_captured_scientific_source_hashes_match_current_and_immutable_git':True,'actual_runtime_source_hashes':{'principal_siblings':16,'plus_evaluator':1},'all272_actual_family_selector_exactly':[79,81],'161163_excluded_by_structure':True,'both_sources_F4_twocomponents_15actions_16sites_verified':True,'all450_exact_domains_weights_match_independent_design':True,'all225_transpose_covariance':True,'actual_global_frame_slot1_edge_local_gamma0_mock_checks':routing_tests,'actual_live_anchor1_fixedanchor0_and1_verified':True,'opaque225_helpers':{'prepare_calls':225,'reprepare_calls':0,'table_identity':True,'emitted_records':225,'exact_negative_weight_arithmetic':True,'None_zero_and_divisor_refusal':True},'CLI_mocks':{'default':[79,81],'unrestricted':[79,81],'fixed':[79,81],'refusals':refusals,'branches_metadata':225},'scope':'stdlib AST/graph/Fraction/opaque mock only; no scientific imports, factorpreps, controls or coefficients','portable_scope':232,'milestone110153_portable_archive':'still separately pending ROOT final review','records':records}
(P/'l1-7981-actual-source-review-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
