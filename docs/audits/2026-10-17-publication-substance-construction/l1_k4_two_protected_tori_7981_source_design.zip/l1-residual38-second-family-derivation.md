# Residual38 second family: a shared-source square and two protected tori

Packet: `publication-l1-residual38-second-design-r1`, checked fresh by the candidate's continuity adapter before inspection. Candidate authority is clean committed `16fde9b0803019d55d0b10250fed52e6258c1d42`; ROOT owns candidate, notebook and acceptance. All work here used standard-library AST, JSON, hashes and finite graph algebra. No physics imports, prepared factors, fixed controls, coefficients, process launches or candidate writes occurred. Barefast handle85890 remains ROOT-owned and untouched. Claude session trimming/hooks/goal instructions do not confer a Codex runtime lease.

The complete source-sharing two-protected-torus family among the residual38 is **79/81**. This is selected by an actual structural predicate over all residual records, rather than picking one word: residual nine-face core; one action-protected square; two complete four-face (2,3) tori, each carrying exactly one distinct source; square/tori intersection exactly one of the original sources. The predicate selects exactly79/81. The accepted232 union, separately owned110/153 and residual38 are disjoint in the attached JSON. No count is promoted by this proposal.

## Original polynomial and incidence

Start from the ordered product of both source insertions on `(0,2)` and `(1,2)` and all fifteen paired action vertices. At each non-omitted action center, the actual frame axes are reconstructed from the canonical manifest's four changes. Each action vertex retains its paired curvature and four coframes. There are fifteen curvature pairs (thirty curvature occurrences), sixty action coframes and four source coframes. Integrate over all sixteen Grassmann sites, including the omitted action center2 for79 or3 for81. Neither source polynomial nor that site's integration is deleted.

Source0 uses sites0,4; source1 uses sites1,5. They are not action edges in either word. The directed source1 link for79 lies on torus faces1,9 and square3; source0 lies on torus faces0,8. The roles exchange under XOR1 for81. Thus two source insertions remain explicit fixed-identity degree-four polynomials, not scalar response factors.

The exact action-edge lists, frame axes, residual/peeled faces, all source incidence and domains for all225 branch products are recorded in `/tmp/l1-residual38-second-family-geometry.json`. Symbolic incidence gives38 factors (15 centers,20 action edges,one square tensor,two source factors),32 labels each occurring twice and degree8 at all16 sites. This is an incidence proof; nonempty unrestricted factor tables remain to be tested after authorization.

## Joint gauge forest and actual local anchors

| word | square | live directed anchor | joint fixed forest | source0 torus centers | source1 torus centers |
|---|---|---|---|---|---|
|79|(3,1,2)|(3,1)|(0,2),(1,2),(3,2),(7,1)|0,4,8,12|1,5,9,13|
|81|(2,1,2)|(2,1)|(0,2),(1,2),(2,2),(6,1)|0,4,8,12|1,5,9,13|

Both forests have four independent edges: the three-edge square tree plus the other disjoint source edge. The probe verifies acyclicity on physical endpoints. Set these four directed links jointly to identity by site gauge covariance. Normalized Haar forest volume is1. The shared source is fixed in the square and its torus simultaneously. Opposite directed periodic links remain integrated.

After this joint fixing, the remaining square live holonomy, seven links of source0 torus and seven links of source1 torus are disjoint Haar variables. Each torus's only protected boundary link is its own fixed source. The square center3/2 is absent from the eight torus centers. Thus conditional curvature tensors factor as square times protected15 times protected15. This does not factor the source/action/Grassmann observable: live and fixed action centers continue to carry their torus or peeled gamma weights in the one global contraction.

Important exact incidence, differing from previous families:

* Live edge1–3 for79,0–2 for81 has singleton action center1/0, **gamma pair index1 (the second frame axis)**. Physical live anchor is upper endpoint3/2, so `probed_action_edge(..., center=0, physical_anchor=1, probe)` applies before global remap.
* Fixed action edge3–7 for79,2–6 for81 has singleton center7/6, **gamma pair index1**, peeled selector. Its directed fixed anchor3/2 is lower endpoint, so fixed_anchor0 and center1.
* Fixed action edge5–7 for79,4–6 for81 has singleton center5/4, **gamma pair index1**, shared-source torus selector. Its fixed directed anchor7/6 is upper endpoint, so fixed_anchor1 and center0.

The four-edge forest includes two source edges and those two action edges. Only the square's three fixed edges enter `fixed_square`/`fixed_edges`; the other source remains explicit through `fixed_sources`. No action moment is assigned to the absent source action edge. All three modified action factors retain actual directed anchors and gamma slot1. The existing generic `prepare` reads the gamma slot from actual frame axes; it must not be replaced by hard-coded first-axis data.

## Complete exact branch product and denominator

Use `k2.protected_branches(linked,other)` for each torus. Source0 has linked(0,4),other(8,12); source1 has linked(1,5),other(9,13). Each protected tensor has15 branches: scalar1/256; each chirality diagonal term-1/559872; six symmetric linked pair terms per chirality with weight2/279936 for diagonal pair or1/279936 for off-diagonal pair. Multiply every source0 branch by every source1 branch. All225 products are retained, including opposite chirality and negative products, with core dictionaries merged only on disjoint center sets.

The square tensor still uses all exact21 quadratic quaternion probes through `square_factor`, and square-component center weights at center3/2. Torus restrictions are supplied through `core.get(q)` at all eight torus centers; six peeled center weights remain. The source/action factors are contracted globally through the existing elimination routine.

Six curvature pairs peel. Twenty geometric action edges supply40 raw directed moment scales192; both identity source moments supply another two, so192^42. There are64 coframes, giving4^64, and15 paired vertex factorials give2^15. The divisor is exactly

`192^42 * 4^64 * 48^6 * 2^15`.

One explicit square and eight protected-torus pairs retain all nine residual curvature pairs. Their tensor weights already carry their exact conditional Haar normalizations. Do not append48^8 or any extra source normalization, translation, shear, permutation or source multiplicity. Original row120000/pair3000000 caps remain.

XOR1 maps79 to81, including frame, square, live/fixed physical anchors, omitted physical site and both sources. Since branch roles are ordered by fixed source, XOR1 **swaps the two torus branch roles**. Flat index15i+j therefore maps to15j+i; the stdlib probe explicitly verified all225 weights and all merged gamma domains under this transpose. Source insertions have even Grassmann degree4, so their swap has positive sign. No coefficient equality is asserted before scientific execution.

## Reuse and required next substantive action

Actual declarations were inspected, not inferred from names/docstrings: `k2.protected_branches`, `witness.core_branches`, `two.base`, `offset_square.square_factor`, `probed_action_edge` and `fixed_action_edge`, plus accepted connected-family `prepare` and two-protected-tori `branches`. Git history identifies the two-tori checkpoint8214f00e1 and earlier generic square sourcea62363d74. These existing helpers support the actual singleton action moments and second-axis frame slots.

Next ROOT/reviewer action is independent design review of this packet, especially actual directed anchors and the225 branch transpose. After fresh design acceptance and ROOT authorization, construct a scratch evaluator using unchanged connected `prepare`/`contraction`, this four-edge forest geometry, and two-protected-tori225 Cartesian `branches`. Then independently control the joint nonidentity forest, both source polynomials, direct square21 quaternion coefficients, each torus's direct15 tensor and their225 product, both singleton fixed action anchor orientations, live second-axis moment, and all16 saturation sites. Prepare/control all450 branch graphs for79/81 before any unrestricted pilot. Preserve structural empty support, resource exhaustion and nonzero coefficients as separate outcomes. Only independent direct/fixed acceptance can authorize a complete225-branch unrestricted pilot at the original caps/budgets.

## Separate next construction for161/163

Inspection initially grouped161/163 with79/81 by square-plus-two-tori face counts. Their actual shared square links are(5,2)/(4,2), the opposite directed periodic links to sources(1,2)/(0,2). Fixing source and shared opposite link creates a two-edge cycle; the above forest route does not apply. Their constructive route must retain the residual relative holonomy: fix the source and two square-only tree links, keep the opposite shared link as a joint variable of square and protected torus, derive the torus tensor polynomial in that holonomy and integrate its product with the square/action probe. Existing `face_tensor`/conditional finite quaternion moments give the direct expansion substrate; this is a separate coupled-holonomy tensor construction, not an impossibility claim. Those two words remain owed at full strength and are not counted in this source-sharing family.

Scope: proposal only. Selected79/81 coefficients, other36 residual words, parallel110/153, fullk4/fullensemble/common partition coefficient and original physicalB3 susceptibility normalization/window/microscopic/retarded matching remain open.

## Scratch metadata correction

An initial standard-library metadata assembly reused a loop variable and printed live physical_anchor0; the geometry itself identifies upper endpoint3/2. This was corrected to explicit `live[0]` and asserted1 in both records before delivery. The control-plan text was also corrected to second gamma slot1. No physics import or scientific computation occurred in either version. Final output binds actual hashes of eighteen inspected source files and captured geometry JSON. The final JSON and probe should be reviewed, not the earlier tool-display metadata.
