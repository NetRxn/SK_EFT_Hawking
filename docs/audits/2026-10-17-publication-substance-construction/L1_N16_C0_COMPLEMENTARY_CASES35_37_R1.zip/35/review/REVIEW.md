# Independent verification of complementary tuple 0 outer case 35

The exact normalized sum is
**-309249011481254844095997/2596148429267413814265248164610048 + 0i**.

The original separator archive is pinned to publication checkpoint
bc45b03f4146c9fb821b7471b18f27b66ed92c05 using the recorded Git blob.
The archive manifest verified. The decompressed complementary parent
SHA256 is 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It selects R(0,0,2,0,1)=1. Its rejected-pair histogram reconstructs the
complete 48-coordinate roster over 6,427,904 products. Case 33 is
(24, (2,)) with 177,240 pair products and an exact inverse lift of
428,682 compatible rows. The equal first-child case 35 scalar is from
selector 0. This review uses the selector-1 factors throughout.

Two outer row-cap stages reproduce the seven-factor inner parent
4d63e9fc77681ee1bd6795cf50406f16e894f1edb29d6e65cd2ff279ab9c8eb0.
The inner rejected-pair histogram reconstructs all nine distinct cuts
of G(0,1,2) over 2,001,024 products. Exact inverse lifts recover every
compatible Gaussian coefficient and denominator for each cut.
The 22 generic inner stages reproduce byte for byte, including
17 cap refusals and five exact terminals. The later capped rescue
inputs for slices 7 and 8 are preserved. The author four-factor
closures both use their corresponding rescue-0 capped operands.

| Slice | Inner coordinate | Projected pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 3 | 44,928 | -11110915873446200016345/2596148429267413814265248164610048 |
| 1 | 192 | 62,208 | -2011362180249495969/10141204801825835211973625643008 |
| 2 | 5 | 169,344 | -3451458467456410661775/162259276829213363391578010288128 |
| 3 | 12 | 169,344 | -33843346116668590909995/649037107316853453566312041152512 |
| 4 | 96 | 217,728 | -4663776247126866816363/324518553658426726783156020576256 |
| 5 | 144 | 217,728 | -4663776247126866816363/324518553658426726783156020576256 |
| 6 | 48 | 248,832 | 6720855919829297127/5070602400912917605986812821504 |
| 7 | 80 | 435,456 | -4480890652576321243803/649037107316853453566312041152512 |
| 8 | 160 | 435,456 | -4480890652576321243803/649037107316853453566312041152512 |

Five final states pass independent direct sparse contraction. The
alternate triangles of slices 2 and 3 use pivot 1. Each covers
18,643,968 matching triples and uses 18,752,832 Gaussian products.
The two four-factor replays use independent pair (1,2) and closure
on (0,3), while the author's pair is (1,3). Each of the independent
replays forecasts 7,892,640 selected pair matches and uses 23,812,992
Gaussian products over 15 bounded shards, with at most 1,979,632
products per shard and 24,984 entries per block. The four alternate
replays agree with the author raw numerators and normalized values.
All 32 author shard receipts have complete disjoint row intervals
and sum exactly to the independently contracted values. All nine
terminal calculations use factor denominator
40512224221827380280140849737629696 and normalization 1/(16*4^64)
once.

The five outer commands took 23.980 s in total. The 53 inner commands
recorded 296.178 s of summed per-command elapsed time with two workers.
Timing receipts also record
nine independent terminal runs and the 32 original author shards.
The independent triangle runs took 12.160 s and 11.318 s. The
four-factor runs took 15.083 s and 14.823 s. These are observed
per-command elapsed times under concurrent scratch execution.

The relative review manifest includes copies of the author receipts.
The frozen-input inventory hashes the source operands required for
the replays.
