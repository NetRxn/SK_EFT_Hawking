"""Independent blockwise Gaussian contraction for a four-factor degree-two frontier."""
from ast import literal_eval
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations
from math import prod
from pathlib import Path
import argparse
import hashlib
import pickle
import time

parser = argparse.ArgumentParser()
parser.add_argument('outer', type=int)
parser.add_argument('case', type=int)
parser.add_argument('--pair', type=int, nargs=2, default=(1, 2))
args = parser.parse_args()
started = time.monotonic()
root=Path('/private/tmp/l1-c0-complementary-cases24-47.XWr8Qj/tuple0-1/35')
path = root/f'row-cap-physical-slice-dense-label-rescue-{args.case}-0-reduced.pkl'
raw = path.read_bytes()
checkpoint = pickle.loads(raw)
factors = checkpoint['factors']
assert len(factors) == 4
assert all(len(set(axes)) == len(axes) and denominator > 0 and rows
           for axes, rows, denominator in factors)
degrees = Counter(axis for axes, _, _ in factors for axis in axes)
assert all(degree == 2 and axis[0] != 'L' for axis, degree in degrees.items())
assert all(len(row) == len(axes) and any(value) and all(type(v) is int for v in value)
           for axes, rows, _ in factors for row, value in rows.items())
assert checkpoint['label_partition']['index'] == 0
conditions = dict(checkpoint['conditioning'])
assert len(conditions) == len(checkpoint['conditioning'])
assert args.outer == 35 and args.case in (7,8)
expected = next(line.split('\t') for line in (root/'author-case35.tsv').read_text().splitlines() if line.startswith(f'{args.case}\t'))
assert conditions['G',0,1,2] == int(expected[1])
assert all(axis not in degrees for axis in conditions)
a, b = args.pair
assert 0 <= a < b < 4 and (a, b) != (1, 3)
c, d = sorted({0, 1, 2, 3} - {a, b})

def encode(position, neighbors):
    axes, rows, _ = factors[position]
    indices = [tuple(axes.index(axis) for axis in sorted(set(axes) & set(factors[peer][0])))
               for peer in neighbors]
    assert sum(len(group) for group in indices) == len(axes)
    seen = set()
    for row, value in rows.items():
        keys = tuple(tuple(row[i] for i in group) for group in indices)
        assert keys not in seen
        seen.add(keys)
        yield (*keys, value)

def buckets(position, neighbors):
    by_boundary = defaultdict(dict)
    for x, y, internal, value in encode(position, neighbors):
        by_boundary[x,y][internal] = value
    return by_boundary

right = defaultdict(list)
for shared, out_c, out_d, coeff in encode(b, (a, c, d)):
    right[shared].append((out_c, out_d, coeff))
left = list(encode(a, (b, c, d)))
admissions = [Counter(), Counter()]
forecast = 0
for shared, out_c, out_d, _ in left:
    matches = len(right.get(shared, ()))
    forecast += matches
    admissions[0][out_c] += matches
    admissions[1][out_d] += matches
print('input sha256', hashlib.sha256(raw).hexdigest(), 'stored rows', sum(len(r) for _,r,_ in factors), flush=True)
print('alternate pair', (a,b), 'forecast', forecast, 'closure pair', (c,d), flush=True)
block_axis = min(range(2), key=lambda index:max(admissions[index].values()))
natural_blocks = defaultdict(list)
for row in left:
    natural_blocks[row[1+block_axis]].append(row)
blocks=[]
for label,items in sorted(natural_blocks.items()):
    selected=[]
    products=0
    for row in items:
        count=len(right.get(row[0],()))
        assert count<=120_000
        if selected and products+count>120_000:
            blocks.append((products,selected))
            selected=[]
            products=0
        selected.append(row)
        products+=count
    if selected:
        blocks.append((products,selected))
assert sum(n for n,_ in blocks)==forecast
assert sum(len(rows) for _,rows in blocks)==len(left)
assert max(n for n,_ in blocks)<=120_000
shards=[]
chosen=[]
used=0
for products,block in blocks:
    if chosen and used+products>600_000:
        shards.append((used,chosen))
        chosen=[]
        used=0
    chosen.append((products,block))
    used+=products
if chosen:
    shards.append((used,chosen))
assert sum(n for n,_ in shards)==forecast
print('row blocks',len(blocks),'shards',len(shards),'max outer matches per shard',max(n for n,_ in shards),flush=True)
cx = buckets(c, (a,b,d))
dx = buckets(d, (a,b,c))

def mul(x, y):
    a,b=x
    c,d=y
    return a*c-b*d, a*d+b*c

total_real=total_imaginary=0
total_products=total_probes=total_selected=peak_shard_products=peak_shard_probes=peak_block=0
processed=0
for shard_number,(shard_forecast,parts) in enumerate(shards):
    shard_started=time.monotonic()
    assert shard_forecast<=8_000_000
    arithmetic=probes=selected=closure_terms=kept_boundaries=peak=0
    for _,block in parts:
        projected = {}
        for shared, ac, ad, left_value in block:
            for bc, bd, right_value in right.get(shared, ()):
                # Group the selected pair on its outgoing four edges, eliminating its internal edge.
                key = (ac, bc, ad, bd)
                selected += 1
                if (ac,bc) not in cx or (ad,bd) not in dx:
                    continue
                arithmetic += 1
                assert arithmetic <= 30_000_000
                r,i = mul(left_value,right_value)
                rr,ii = projected.get(key,(0,0))
                projected[key] = (r+rr,i+ii)
                assert len(projected) <= 200_000
        peak = max(peak,len(projected))
        for (ac,bc,ad,bd), outer_value in projected.items():
            if not any(outer_value):
                continue
            u,v=cx[ac,bc],dx[ad,bd]
            probes += min(len(u), len(v))
            assert probes <= 30_000_000
            r=i=0
            for internal in u.keys() & v.keys():
                re,im = mul(u[internal],v[internal])
                r+=re
                i+=im
                arithmetic += 1
                closure_terms += 1
                assert arithmetic <= 30_000_000
            if r or i:
                kept_boundaries += 1
                arithmetic += 1
                assert arithmetic <= 30_000_000
                re,im=mul(outer_value,(r,i))
                total_real+=re
                total_imaginary+=im
        assert time.monotonic() - shard_started < 120
    assert selected==shard_forecast
    start_row=processed
    processed+=sum(len(block) for _,block in parts)
    total_products+=arithmetic
    total_probes+=probes
    total_selected+=selected
    peak_shard_products=max(peak_shard_products,arithmetic)
    peak_shard_probes=max(peak_shard_probes,probes)
    peak_block=max(peak_block,peak)
    print('shard',shard_number,'row interval',start_row,processed,'selected matches',selected,
          'Gaussian products',arithmetic,'closure probes',probes,'peak block entries',peak,
          'seconds',round(time.monotonic()-shard_started,3),flush=True)
assert total_selected==forecast and processed==len(left)
denominator = prod(den for _,_,den in factors)
assert denominator == 40512224221827380280140849737629696
scale=denominator*16*4**64
result=Fraction(total_real,scale),Fraction(total_imaginary,scale)
assert result==tuple(map(Fraction,expected[3:5]))
print('complete shards',len(shards),'left rows',processed,'peak Gaussian products/shard',peak_shard_products,
      'peak closure probes/shard',peak_shard_probes,'peak entries',peak_block,'total products',total_products,
      'total probes',total_probes,'seconds',round(time.monotonic()-started,3),flush=True)
print('raw',total_real,total_imaginary,'factor denominator',denominator,flush=True)
print('independent exact normalized real',result[0],'imaginary',result[1],flush=True)
