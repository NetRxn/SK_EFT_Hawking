# Independent verification of complementary tuple 0 outer case 36

The exact normalized sum is
**-311265394132600099496295/5192296858534827628530496329220096 + 0i**.

The original separator archive is pinned to publication checkpoint
395f25b08227dccd6964a8c3d02dc2f9492ab7c2 and matches the worktree bytes.
The archive manifest verified. The decompressed complementary parent
SHA256 is 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It selects R(0,0,2,0,1)=1. Its rejected-pair histogram reconstructs the
complete 48-coordinate roster over 6,427,904 products. Case 33 is
(129, (1,)) with 177,240 pair products and an exact inverse lift of
423,946 compatible rows. The equal first-child case 36 scalar is from
selector 0. This review uses the selector-1 factors throughout.

Two outer row-cap stages reproduce the seven-factor inner parent
e0af9fbc1ab6520589baad8abe60f8ede4f8a2b1bf194873408e7104e28cd90d.
The inner rejected-pair histogram reconstructs all nine distinct cuts
of G(0,1,2) over 2,001,024 products. Exact inverse lifts recover every
compatible Gaussian coefficient and denominator for each cut.
The 22 generic inner stages reproduce byte for byte, including
17 cap refusals and five exact terminals. The later capped rescue
inputs for slices 7 and 8 are preserved. The author four-factor
closures both use their corresponding rescue-0 capped operands.

| Slice | Inner coordinate | Projected pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 12 | 44,928 | -7579449762635066717835/2596148429267413814265248164610048 |
| 1 | 48 | 62,208 | -2639017884707118117/20282409603651670423947251286016 |
| 2 | 3 | 169,344 | -56843999868716591259645/2596148429267413814265248164610048 |
| 3 | 5 | 169,344 | -86042431804685377031955/5192296858534827628530496329220096 |
| 4 | 96 | 217,728 | -1958914993772195309097/324518553658426726783156020576256 |
| 5 | 144 | 217,728 | -1958914993772195309097/324518553658426726783156020576256 |
| 6 | 192 | 248,832 | -111230041368208192983/649037107316853453566312041152512 |
| 7 | 80 | 435,456 | -8031338588767617209115/2596148429267413814265248164610048 |
| 8 | 160 | 435,456 | -8031338588767617209115/2596148429267413814265248164610048 |

Five final states pass independent direct sparse contraction. The
alternate triangles of slices 2 and 3 use pivot 1. Each covers
18,643,968 matching triples and uses 18,752,832 Gaussian products.
The two four-factor replays use independent pair (1,2) and closure
on (0,3), while the author's pair is (1,3). Each of the independent
replays forecasts 6,138,720 selected pair matches and uses 23,692,032
Gaussian products over 11 bounded shards, with at most 2,673,792
products per shard and 24,984 entries per block. The four alternate
replays agree with the author raw numerators and normalized values.
All 32 author shard receipts have complete disjoint row intervals
and sum exactly to the independently contracted values. All nine
terminal calculations use factor denominator
40512224221827380280140849737629696 and normalization 1/(16*4^64)
once.

The timing receipts record five outer commands, 53 inner commands,
nine independent terminal runs and the 32 original author shards.
The independent triangle runs took 15.68 s and 15.372 s. The
four-factor runs took 18.812 s and 18.944 s. These are observed
per-command elapsed times under concurrent scratch execution.

The relative review manifest includes copies of the author receipts.
The frozen-input inventory hashes the source operands required for
the replays.
