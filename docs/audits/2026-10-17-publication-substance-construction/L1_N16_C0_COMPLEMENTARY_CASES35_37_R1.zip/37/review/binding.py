from pathlib import Path

ROOT = Path('inputs')
rows = [line.split('\t') for line in (ROOT/'author-case37.tsv').read_text().splitlines()]
assert len(rows)==10 and rows[-1][0]=='sum'
records = rows[:-1]
TERMINAL_INPUTS = tuple(
    f'join-cap-dense-label-rescue-{i}-1-reduced.pkl' if i in (2,3) else
    f'row-cap-physical-slice-dense-label-rescue-{i}-0-reduced.pkl' if i in (7,8) else
    f"label-{row[-1].removesuffix('-contract.out')}-reduced-frontier.pkl"
    for i,row in enumerate(records)
)
