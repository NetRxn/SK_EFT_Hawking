from fractions import Fraction as F
from itertools import product
from src.core.formulas import original_plaquette,original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator,Polynomial,matrix_dagger,matrix_multiply

def mul(a,b):
    s,*v=a;t,*w=b
    return (s*t-sum(x*y for x,y in zip(v,w)),*(s*w[i]+t*v[i]-(v[(i+1)%3]*w[(i+2)%3]-v[(i+2)%3]*w[(i+1)%3]) for i in range(3)))

def adj(a):return a[0],*(-x for x in a[1:])
def word(*args):
    result=(1,0,0,0)
    for a in args:result=mul(result,a)
    return result

basis=tuple(tuple(int(i==j) for i in range(4)) for j in range(4))
units=(*basis,(F(1,2),)*4,(F(3,5),0,F(4,5),0))
I=units[0]
Id=(I,I)
cases=[(Id,Id,Id,Id),((units[5],units[4]),Id,Id,Id),
       tuple((units[(t+3)%6],units[(2*t+3)%6]) for t in range(4))]
reg=OriginalRegulator(temporal_axis=0)
x=(0,0,0,0)
X=reg.step(x,0)[0]
y=reg.step(x,1)[0]
Y=reg.step(y,0)[0]

# Degree two in each used quaternion group is integrated exactly on
# the signed coordinate axes. Different chiralities' cross terms are
# zero since a singleton temporal quaternion has mean zero.
for index,spatial in enumerate(cases):
    direct=schur=F(0)
    for chi in range(2):
        a,b,c,d=(links[chi] for links in spatial)
        for U,V in product(basis,repeat=2):
            h=word(adj(a),adj(V),b,U)
            j=word(adj(c),adj(U),d,V)
            direct+=F(4*h[3]*j[3],16)
        O=basis[3] # Opposite chirality flips this sign twice.
        schur+=F(2*word(b,d)[0]*2*word(O,adj(a),O,adj(c))[0],4)
    assert direct==schur==[F(-2),F(-11,10),F(0)][index]
    A,B,C,D=map(lambda t:original_spin4_link(*t),spatial)
    U=(units[4],units[5]);V=(units[3],units[1])
    links={(x,0):original_spin4_link(*U),(y,0):original_spin4_link(*V),
           (x,1):A,(X,1):B,(y,1):C,(Y,1):D}
    H=original_plaquette(reg,x,0,1,links)
    J=original_plaquette(reg,y,0,1,links)
    assert H==original_spin4_link(*(word(adj(a),adj(v),b,u) for (a,b,_,_),u,v in zip(zip(*spatial),U,V)))
    assert J==original_spin4_link(*(word(adj(c),adj(u),d,v) for (_,_,c,d),u,v in zip(zip(*spatial),U,V)))

    # A gauge change at the vertex x acts on both incoming and
    # outgoing anchors, including both L2 spatial orientations.
    g=original_spin4_link(units[4],units[5])
    transformed={}
    for (s,k),h in links.items():
        if reg.step(s,k)[0]==x:h=matrix_multiply(g,h)
        if s==x:h=matrix_multiply(h,matrix_dagger(g))
        transformed[s,k]=h
    assert original_plaquette(reg,x,0,1,transformed)==matrix_multiply(matrix_multiply(g,H),matrix_dagger(g))
    assert original_plaquette(reg,y,0,1,transformed)==J
    print("literal conditional F01 first-power control",index,direct,"Schur",schur)

# The same half-turn conjugates two independent imaginary directions
# to their negatives. Check every antisymmetric source gamma component,
# including separate conjugation axes in the two chiral blocks.
g=original_spin4_link(basis[2],basis[3])
for H in (original_spin4_link(basis[1],basis[1]),original_spin4_link(basis[3],basis[2])):
    G=matrix_multiply(matrix_multiply(g,H),matrix_dagger(g))
    for a,b in product(range(4),repeat=2):
        if a==b:continue
        O=matrix_multiply(matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
        def trace(M):
            return sum((M[i][j]*O[j][i] for i,j in product(range(4),repeat=2)),Polynomial())
        assert trace(G)==-trace(H)
print("literal original root covariance and common half-turn controls pass")

for n in range(5):
    s=[(p+1)*(q+1) for p,q in product(range(n+1),repeat=2) if p+q<=n and not (n-p-q)%2]
    print("degree",n,"ambient components",sum(d*d for d in s),"max dimension",max(s))
