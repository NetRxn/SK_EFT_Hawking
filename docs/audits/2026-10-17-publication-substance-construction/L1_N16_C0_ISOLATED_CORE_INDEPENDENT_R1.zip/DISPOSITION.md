# Scoped acceptance

Independent replay accepts six signed orbit values and 81 exact zero orbits, together resolving 6,036 additional labeled occupations. See the prior L1_N16_C0_ISOLATED_CORE_AUTHOR_R1.zip. Shared spatial contraction for the general family and full c0 remain open.
