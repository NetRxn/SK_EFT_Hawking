from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations, combinations_with_replacement, product
from math import factorial,prod
from census import occupancy, profile, read, write

def key(seq):
    out=0
    for n in seq:out=4*out+n
    return out

moments=defaultdict(dict)
for d,side,k,owner,remote,re,im in (map(int,row) for row in read("edge-moments.tsv")):
    assert im==0 and re!=0
    assert owner.bit_count()==remote.bit_count()==d
    assert (owner,remote) not in moments[d,side,k]
    moments[d,side,k][owner,remote]=re
for d,n in ((2,48),(4,380)):
    by_side=[{k:v for (degree,s,k),v in moments.items() if (degree,s)==(d,side)} for side in (0,1)]
    assert by_side[0]==by_side[1]
    assert sum(map(len,by_side[0].values()))==n

@cache
def moment_rows(d,labels):
    out=defaultdict(list)
    for (u,v),z in moments[d,0,key(labels)].items():out[u].append((v,z))
    return out

pairs=list(combinations_with_replacement(range(4),2))
W=[(pairs[a],pairs[b],n) for a,b,n in (map(int,r) for r in read("source-gram.tsv"))]
assert len(W)==18

@cache
def at_site(m):
    terms={ ((),(),()):1 }
    for axis,n in enumerate(m):
        r,s=[d for d in range(3) if d!=axis]
        assert n%2==0
        for _ in range(n//2):
            new=Counter()
            for a,c in terms.items():
                for x,y,w in W:
                    b=list(a)
                    b[r]=tuple(sorted(b[r]+x))
                    b[s]=tuple(sorted(b[s]+y))
                    new[tuple(b)]+=c*w
            terms={k:v for k,v in new.items() if v}
    return terms

def inv(a,b):
    return sum((a>>(i+1)).bit_count() for i in range(8) if b>>i&1)

@cache
def available(mask,d):
    return [sum(1<<i for i in choice) for choice in combinations([i for i in range(8) if mask>>i&1],d)]

@cache
def coframe(code,mutant=-1,reverse=False):
    m=occupancy(code)
    _,_,graph=profile(code)
    incidence=[[] for _ in range(8)]
    scale=1
    for (u,v,k),(p,q) in sorted(graph.items()):
        d=p+q
        assert d in (2,4) and not(p and q)
        for a,owned in ((u,bool(p)),(v,bool(q))):
            incidence[a].append(((u,v,k),d,owned))
        scale*=64 if d==2 else 12288
    factors=[]
    largest_site=0
    for v,edge_list in enumerate(incidence):
        assert sum(d for _,d,_ in edge_list)==8
        table=Counter()
        for labels,c in at_site(m[v]).items():
            rows=[moment_rows(d,labels[e[2]]) if own else None for e,d,own in edge_list]
            def walk(i,remaining,old,contraction,vals):
                if i==len(edge_list):
                    assert remaining==0
                    table[vals]+=contraction
                    return
                _,d,own=edge_list[i]
                if d==remaining.bit_count():
                    possible=(remaining,)
                elif own:
                    possible=(mask for mask in rows[i] if not (mask&~remaining))
                else:
                    possible=available(remaining,d)
                for mask in possible:
                    signed=contraction*(-1 if v!=mutant and inv(old,mask)%2 else 1)
                    vals2=rows[i].get(mask,()) if own else ((mask,1),)
                    for remote,weight in vals2:
                        walk(i+1,remaining^mask,old|mask,signed*weight,vals+(remote,))
            walk(0,255,0,c,())
        table={k:v for k,v in table.items() if v}
        largest_site=max(largest_site,len(table))
        factors.append((tuple(e for e,d,own in edge_list),table))
    # Sweep vertices in geometric order and match only frontier edge
    # masks. Every edge is closed on the visit to its second endpoint.
    order=list(reversed(range(8))) if reverse else range(8)
    frontier=()
    previous={():1}
    peak=0
    for v in order:
        keys,site=factors[v]
        shared=tuple(sorted(set(frontier)&set(keys)))
        next_keys=tuple(sorted(set(frontier)^set(keys)))
        ix=[keys.index(e) for e in shared]
        iy=[frontier.index(e) for e in shared]
        pick=[(e in frontier,frontier.index(e) if e in frontier else keys.index(e)) for e in next_keys]
        site_groups=defaultdict(list)
        for row,n in site.items():
            site_groups[tuple(row[i] for i in ix)].append((row,n))
        nxt=Counter()
        for a,n in previous.items():
            for b,k in site_groups.get(tuple(a[i] for i in iy),()):
                dest=tuple((a if take else b)[i] for take,i in pick)
                nxt[dest]+=n*k
        previous={k:v for k,v in nxt.items() if v}
        frontier=next_keys
        peak=max(peak,len(previous))
    assert frontier==()
    value=F(previous.get((),0),scale)
    print("coframe",code,"drop site",mutant,"reverse sweep",reverse,"peak site",largest_site,"peak sweep",peak,"value",value)
    return value

# Orientation averaging of twice a quaternion imaginary projection:
# E(root^2)=4(l+r)/3 and E(root^4)=16(l²+r²)/5+32lr/3.
# Express l and l² as linear combinations of integer-spin characters.
l=[F(3,4),F(-1,4),F(0)]
l2=[F(5,8),F(-5,16),F(1,16)]
def char_coeff(power,i,j):
    if not power:return int(i==j==0)
    if power==2:return F(4,3)*(l[i]*(j==0)+l[j]*(i==0))
    assert power==4
    return F(16,5)*(l2[i]*(j==0)+l2[j]*(i==0))+F(32,3)*l[i]*l[j]

def core_weights(A,B):
    shared=F(1)
    separated=F(1)
    for e in A.keys()|B.keys():
        a,b=A.get(e,(0,0));c,d=B.get(e,(0,0))
        shared*=sum(prod(char_coeff(p,i,j) for p in (a,b,c,d))/F(((2*i+1)*(2*j+1))**4)
                    for i,j in product(range(3),repeat=2))
        separated*=prod(char_coeff(p,0,0) for p in (a,b,c,d))
    return shared,separated

subtotal=F(0)
rows=[]
for a,b,w in (map(int,r) for r in read("candidates.tsv")):
    A,leavesA,_=profile(a);B,leavesB,_=profile(b)
    H,Hsplit=core_weights(A,B)
    divisor=prod(factorial(n) for m in occupancy(a)+occupancy(b) for n in m)
    leaf_moments=prod({2:2,4:10}[n] for n in leavesA+leavesB)
    coframes=coframe(a)*coframe(b)
    value=H*leaf_moments*coframes/divisor
    assert value>0
    rows.append((a,b,w,value))
    subtotal+=w*value
    print("orbit",a,b,w,"core Haar",H,"split spatial",Hsplit,"leaf moment",leaf_moments,"divisor",divisor,"value",value)
    if a==b==149259165705:
        assert H==F(2076356601844132,207594140625) and Hsplit==10000
        assert coframe(a,reverse=True)==coframe(a)==F(11696130675,2097152)
        assert coframe(a,mutant=0)==F(2308323825,2097152)
assert subtotal==F(3957259417708218600393632457,5629499534213120000)
print("exact six-orbit weighted subtotal",subtotal)
write("signed-orbits.tsv",rows)
