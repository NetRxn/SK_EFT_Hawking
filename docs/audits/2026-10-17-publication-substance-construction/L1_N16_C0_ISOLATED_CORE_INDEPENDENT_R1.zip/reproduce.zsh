#!/bin/zsh
set -euo pipefail
cd -- "${0:A:h}"
primary=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking
author=/private/tmp/l1-c0-core.1zohnyO1
degree=/private/tmp/l1-c0-degree-independent.nEpHYJlb
q3=/private/tmp/l1-c0-q3-independent.t3DCmj20
(cd "$primary"; python3 scripts/codex_continuity.py check .codex/continuity/l1-c0-isolated-core-independent-r1.json) > continuity.out
(cd "$author"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > author-manifest.out
(cd "$degree"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > degree-manifest.out
(cd "$q3"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > q3-manifest.out
test "$(cut -d' ' -f1 < author-manifest.out | head -1)" = 485a4b062cd2dc7426e9ed250626c1e7e4b9d7ec39cb0e4a5ced52d08375770f
test "$(cut -d' ' -f1 < degree-manifest.out | head -1)" = 5975bed7abd9b5fa50ae8e7396d9c22d907d12c2b0953bc56c184a72052b59a5
test "$(cut -d' ' -f1 < q3-manifest.out | head -1)" = 4da5f6dbe2d0cf97f2b1d81f9274d96d32eb3a3195f1ebca0c6a31723dce6622
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$primary" "$primary/.venv/bin/python" source.py > source.out
cmp source-edge.tsv "$author/edge_coframes.tsv"
awk '$1==1 {print $2 "\t" $3 "\t" $4}' "$author/grams.tsv" | cmp source-gram.tsv -
clang++ -O3 -std=c++20 -Wall -Wextra -Werror -fsanitize=undefined -fno-sanitize-recover=all edge.cpp -o edge
./edge
PYTHONDONTWRITEBYTECODE=1 python3 census.py > census.out
cmp zeros.tsv "$author/zero-orbits.tsv"
PYTHONDONTWRITEBYTECODE=1 python3 signed.py > signed.out
cmp signed-orbits.tsv "$author/signed-orbits.tsv"
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$primary" "$primary/.venv/bin/python" schur.py > schur.out
