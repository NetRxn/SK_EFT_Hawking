from fractions import Fraction as F
from math import factorial
import json

def odd_product(n):
    result = 1
    for k in range(1, n + 1, 2):
        result *= k
    return result

def s3(exponents):
    if any(k % 2 for k in exponents):
        return F(0)
    total = sum(exponents)
    value = F(1)
    for n in exponents:
        value *= odd_product(n - 1)
    for j in range(0, total, 2):
        value /= 4 + j
    return value

def gmean(n, variance):
    return F(0) if n % 2 else odd_product(n - 1) * variance ** (n // 2)

def compensated_h2(sigma, variance, cutoff):
    # The scalar zero-source slice uses coeff of exp(-sigma^2 * t^2 / 2).
    # Expand the probabilists' Hermite polynomial and take exact h moments.
    result = F(0)
    for n in range(0, cutoff + 1, 2):
        m = n // 2
        coefficient = (-sigma ** 2 / 2) ** m / factorial(m)
        hermite_moment = sum(
            F((-1) ** r * factorial(n), 2 ** r * factorial(r) * factorial(n - 2*r))
            * gmean(n - 2*r + 2, variance) / sigma ** (n - 2*r)
            for r in range(m+1)
        )
        result += coefficient * hermite_moment / sigma ** n
    return result

# A representative determinant D(h,J) = det(diag(x+Jx, 2(x+Jx)+3(y+Jy))).
# Compute the two first slots and the mixed slot using independent nilpotent positions.
def determinant_slots(a, b):
    z = {"x": 7, "y": 13}
    f = [z["x"], int(a == "x"), int(b == "x"), 0]
    g = [2*z["x"]+3*z["y"], 2*int(a == "x")+3*int(a == "y"),
         2*int(b == "x")+3*int(b == "y"), 0]
    answer = [0] * 4
    for i, x in enumerate(f):
        for j, y in enumerate(g):
            if i & j == 0:
                answer[i | j] += x*y
    return answer

cases = {
    "same_anchor_square_joint": s3((2,0,0,0)),
    "same_anchor_square_split": s3((1,0,0,0))**2,
    "same_anchor_mixed_even_joint": s3((2,2,0,0)),
    "same_anchor_mixed_even_split": s3((2,0,0,0))*s3((0,2,0,0)),
    "distinct_anchor_first_product": s3((1,0,0,0))**2,
    "distinct_anchor_wrongly_aliased": s3((2,0,0,0)),
    "variance4_zero_source_weighted_h2_cutoff4": compensated_h2(F(2), F(4), 4),
    "variance4_dropped_compensation": gmean(2, F(4)),
    "variance2_wrong_scale_weighted_h2_cutoff4": compensated_h2(F(2), F(2), 4),
    "determinant_distinct_x_y": determinant_slots("x","y"),
    "determinant_repeated_x_x": determinant_slots("x","x"),
}
expected = dict(zip(cases, [F(1,4),0,F(1,24),F(1,16),0,F(1,4),0,4,F(15,16),
                           [371,67,21,3], [371,67,67,4]], strict=True))
assert cases == expected, (cases, expected)
print(json.dumps(cases, default=str, indent=2))
