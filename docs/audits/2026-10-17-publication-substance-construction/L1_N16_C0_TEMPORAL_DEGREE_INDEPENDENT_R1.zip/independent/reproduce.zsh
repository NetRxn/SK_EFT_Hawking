#!/bin/zsh
set -euo pipefail
cd -- "${0:A:h}"
primary=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking
frozen=/private/tmp/l1-n16-c0-degree.1K9GzWW5
(cd "$primary"; python3 scripts/codex_continuity.py check .codex/continuity/l1-c0-temporal-degree-independent-r1.json) > continuity.out
(cd "$frozen"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > input-manifest.out
test "$(cut -d' ' -f1 < input-manifest.out | head -1)" = 8f1654b9b7c52730e3840ed2020df9419e1172eb78b5f438d6c725b49a2a48b0
clang++ -O3 -std=c++20 -Wall -Wextra -Werror support.cpp -o support
./support > support.out
cmp orbits.tsv "$frozen/orbits-checker.tsv"
cmp orbits.tsv "$frozen/orbits-slab.tsv"
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$primary" "$primary/.venv/bin/python" source.py > source.out
cmp source-edge.tsv "$frozen/edge_coframes.tsv"
awk '$1==1 {print $2 "\t" $3 "\t" $4}' "$frozen/grams.tsv" | cmp source-gram.tsv -
clang++ -O3 -std=c++20 -Wall -Wextra -Werror -fsanitize=undefined -fno-sanitize-recover=all slices.cpp -o slices
./slices > slices.out
python3 contract.py > contract.out
awk -F '\t' '$1=="axis" {print $2 "\t" $3 "\t" $4 "\t" $5}' signed.tsv | cmp "$frozen/axis-values.tsv" -
awk -F '\t' '$1=="mixed" {print $2,$3,"weight",$4,"value",$5}' signed.tsv > mixed-compare.out
sed -n 's/^exact mixed leaf-and-slice orbit //p' "$frozen/leaf.out" | cmp mixed-compare.out -
