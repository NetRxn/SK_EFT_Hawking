from collections import Counter
from fractions import Fraction as Q
from functools import cache
from itertools import product
from math import factorial, prod
from pathlib import Path
import re

def degree_envelope(n):
    return {(4*f+3*p+q,p+3*q)
            for f,p,q in product(range(n+1),repeat=3)
            if f+p+q==n and (p+q)%2==0 and (f%2==0 or p+q>=2)
            and 4*f+3*p+q<=64 and p+3*q<=64}

all_degrees=[degree_envelope(n) for n in range(33)]
assert all_degrees[1]==set()
assert all_degrees[2]=={(8,0),(6,2),(4,4),(2,6)}
assert all_degrees[3]=={(10,2),(8,4),(6,6)}
sewn=[[(a,b) for a,b in d if (64-b,64-a) in all_degrees[32-n]]
      for n,d in enumerate(all_degrees)]
print("missing sewn degrees",[n for n,d in enumerate(sewn) if not d],
      "ordered blocks",sum(map(len,sewn)))
assert [n for n,d in enumerate(sewn) if not d]==[1,31]
assert sum(map(len,sewn))==377

# Each face is the L2 x L2 square. Directly form the closed anchored word
# at each of the four roots, preserving the two positive anchors per axis.
anchor_to_entries={}
for v in range(4):
    word=((v,1,True),(v^2,0,True),(v^1,1,False),(v,0,False))
    for j,(u,k,adj) in enumerate(word):
        left,right=4*v+j,4*v+(j+1)%4
        anchor_to_entries.setdefault((u,k),[]).append((right,left) if adj else (left,right))
assert len(anchor_to_entries)==8
all_indices=[{i} for i in range(16)]
for pairs in anchor_to_entries.values():
    assert len(pairs)==2
    for i,j in zip(*pairs):
        if all_indices[i] is not all_indices[j]:
            group=all_indices[i]|all_indices[j]
            for a in group: all_indices[a]=group
classes=len({tuple(sorted(g)) for g in all_indices})
assert classes==4
for mask in range(1,15):
    assert any((mask>>(p[0]//4)^mask>>(q[0]//4))&1
               for p,q in anchor_to_entries.values())
print("literal face anchors",len(anchor_to_entries),"trace index classes",classes,
      "adjoint moment",Q(3)**(classes-8))

# Expand the exact orientation moments in the character basis. If a is
# q0_L^2 and b is q0_R^2, 1-a=3/4-chi1_L/4 and
# (1-a)^2=5/8-5 chi1_L/16+chi2_L/16.
coeffs={0:{(0,0):Q(1)},2:{},4:{}}
length=[Q(3,4),Q(-1,4),Q(0)]
length2=[Q(5,8),Q(-5,16),Q(1,16)]
for i,j in product(range(3),repeat=2):
    coeffs[2][i,j]=Q(4,3)*(length[i]*(j==0)+length[j]*(i==0))
    coeffs[4][i,j]=Q(16,5)*(length2[i]*(j==0)+length2[j]*(i==0))+Q(32,3)*length[i]*length[j]
for q in (Q(0),Q(1,3),Q(2,3),Q(1)):
    ch=(1,4*q*q-1,16*q**4-12*q*q+1)
    assert sum(a*b for a,b in zip(length,ch))==1-q*q
    assert sum(a*b for a,b in zip(length2,ch))==(1-q*q)**2
# Schur orthogonality across paired anchors forces the same spin around
# the connected face per chirality. The free-index count is spin-independent.
@cache
def face(ms):
    if any(m%2 for m in ms): return Q(0)
    return sum(prod(coeffs[m].get((i,j),0) for m in ms)
               *Q((2*i+1)*(2*j+1))**(classes-8)
               for i,j in product(range(3),repeat=2))
print("shared Haar square control",face((2,)*4),"independent spatial averaging",16)
assert face((2,)*4)==Q(104978,6561)
assert face((4,0,4,0))==100

pat=r"(uniform|checker) (\d+) / (\d+)\^(\d+)"
slices={key:Q(int(n),int(d)**int(p)) for key,n,d,p in re.findall(pat,Path("slices.out").read_text())}
assert slices=={"uniform":Q(1573101,2048),"checker":Q(3598425,8192)}
print("exact signed slices",slices)

triples=[(a,b,c) for a,b,c in product(range(5),repeat=3) if a+b+c<=4]
def decode(code):
    return tuple(triples[code>>(6*v)&63] for v in range(8))
def axes(occupation):
    return {k for v in range(8) for k in range(3) if occupation[v][k]}
def coframe_single_axis(row,k):
    total=Q(1)
    for side in range(2):
        loads=sorted(m[k] for v,m in enumerate(row) if v>>k&1==side)
        if loads==[2]*4: total*=slices["uniform"]
        elif loads==[0,0,4,4]: total*=slices["checker"]
        else: raise AssertionError(loads)
    return total

@cache
def peel(m):
    remaining={(v,v|(1<<k)):(m[v][k],m[v|(1<<k)][k])
               for v in range(8) for k in range(3)
               if not v>>k&1 and (m[v][k] or m[v|(1<<k)][k])}
    removed=[]
    while remaining:
        degree=Counter(v for e in remaining for v in e)
        leaves=[e for e,root in remaining.items() if min(degree[v] for v in e)==1 and sum(bool(n) for n in root)==1]
        if not leaves: break
        for e in leaves:
            n=sum(remaining.pop(e))
            assert n in (2,4)
            removed.append(n)
    return tuple(removed),len(remaining)

subset=Counter()
partial=fully=fully_mass=0
rows=[]
for line in Path("orbits.tsv").read_text().splitlines():
    a,b,w=map(int,line.split())
    A,B=decode(a),decode(b)
    U,V=axes(A),axes(B)
    D=prod(factorial(n) for m in A+B for n in m)
    if len(U|V)==1:
        k,=U
        f=prod(face(tuple(m[v][k] for m,v in ((A,v),(A,v^(1<<k)),(B,v),(B,v^(1<<k)))))
               for v in range(8) if not v>>k&1)
        value=f*coframe_single_axis(A,k)*coframe_single_axis(B,k)/D if f else Q(0)
        rows.append(("axis",a,b,w,value))
        subset["axis",bool(value)]+=w
    else:
        removedA,resA=peel(A);removedB,resB=peel(B)
        if removedA or removedB: partial+=1
        if not resA and not resB:
            fully+=1;fully_mass+=w
            if len(U)==len(V)==1:
                k,=U;ell,=V
                leaf_haar={2:Q(2),4:Q(10)}
                value=prod(leaf_haar[n] for n in removedA+removedB)*coframe_single_axis(A,k)*coframe_single_axis(B,ell)/D
                rows.append(("mixed",a,b,w,value))
                subset["mixed",bool(value)]+=w
with open("signed.tsv","w") as out:
    for row in rows: print(*row,sep="\t",file=out)
print("mixed leaf eligible",partial,"fully reducible",fully,"labeled",fully_mass)
assert (partial,fully,fully_mass)==(8210,12,312)
print("signed orbits",len(rows),"labeled",sum(subset.values()),"subset",dict(subset))
assert len(rows)==24 and sum(subset.values())==315
for label in ("axis","mixed"):
    print(label,"weighted subtotal",sum(w*q for kind,a,b,w,q in rows if kind==label))
