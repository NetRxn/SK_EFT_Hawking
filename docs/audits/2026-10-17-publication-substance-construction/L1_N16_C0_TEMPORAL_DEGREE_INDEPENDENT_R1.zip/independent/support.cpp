#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using U=uint64_t;
using I=unsigned;
using A=std::array<int,8>;
using T=std::array<int,3>;
struct Layer { U code; I P,R,L,Z; };
std::vector<T> triples;
std::array<std::array<std::pair<int,int>,35>,8> dummy;
std::map<int,std::vector<U>> build(const std::array<int,4>& sites) {
    std::map<int,std::vector<U>> half;
    auto visit=[&](auto&& self,int depth,A load,U code)->void{
        if(depth==4){
            int key=0;for(int i=7;i>=0;--i)key=9*key+load[i];
            half[key].push_back(code);return;
        }
        const int u=sites[depth];
        for(I j=0;j<triples.size();++j){
            const auto m=triples[j]; const int M=m[0]+m[1]+m[2];auto l=load;
            l[u]+=2*M;
            for(int k=0;k<3;++k)l[u^(1<<k)]+=M-m[k];
            if(*std::max_element(l.begin(),l.end())<=8)
                self(self,depth+1,l,code|(U(j)<<(6*u)));
        }
    };
    visit(visit,0,{},0);
    return half;
}
std::vector<T> decode(U code) {
    std::vector<T> a;for(int i=0;i<8;++i)a.push_back(triples.at((code>>(6*i))&63));return a;
}
int main(){
    for(int a=0;a<=4;++a)for(int b=0;b<=4-a;++b)for(int c=0;c<=4-a-b;++c)
        triples.push_back({a,b,c});
    const auto left=build({0,1,6,7}),right=build({2,3,4,5});
    std::vector<Layer> layers;
    U saturated=0;
    std::array<std::array<int,3>,12> edges;
    int e=0;for(int v=0;v<8;++v)for(int k=0;k<3;++k)if(!(v&(1<<k)))
        edges[e++]={v,v^(1<<k),k};
    const int target=43046720; // 9^8-1
    for(const auto& [d,codes]:left){
        const auto it=right.find(target-d); if(it==right.end())continue;
        for(U a:codes)for(U b:it->second){
            ++saturated;
            const auto m=decode(a|b);
            I parity=0,P=0,R=0,L=0,Z=0;
            A M{};
            for(int v=0;v<8;++v)for(int k=0;k<3;++k){
                M[v]+=m[v][k];
                if(m[v][k]&1)parity^=(1U<<v)|(1U<<(v^(1<<k)));
            }
            if(parity)continue;
            for(int j=0;j<12;++j){
                const auto [u,v,k]=edges[j];
                if((M[u]+M[v])&1)P|=1U<<j;
                if((m[u][k]+m[v][k])&1)R|=1U<<j;
                if(m[u][k]&1)L|=1U<<j;
                if(M[u]+M[v]==m[u][k]+m[v][k])Z|=1U<<j;
            }
            layers.push_back({a|b,P,R,L,Z});
        }
    }
    std::map<std::pair<I,I>,std::vector<Layer>> buckets;
    for(auto l:layers)buckets[{l.P,l.R}].push_back(l);
    std::set<std::pair<U,U>> full;
    U retained=0,undirected=0,signature_pairs=0,bins=0;
    for(const auto& [k,aa]:buckets){
        auto it=buckets.find({k.second,k.first});if(it==buckets.end())continue;
        const auto& bb=it->second;
        retained+=aa.size();
        std::set<std::pair<I,I>> sigA,sigB;
        for(auto a:aa)sigA.emplace(a.L,a.Z);
        for(auto b:bb)sigB.emplace(b.L,b.Z);
        bins+=sigA.size();
        signature_pairs+=sigA.size()*sigB.size();
        undirected+=aa.size()*bb.size();
        for(auto a:aa)for(auto b:bb)
            if(!((a.L^b.L)&(a.Z|b.Z)))full.emplace(a.code,b.code);
    }
    std::cout<<"support "<<saturated<<' '<<layers.size()<<' '<<retained<<' '<<bins<<' '
             <<signature_pairs<<' '<<undirected<<' '<<full.size()<<'\n';
    std::unordered_map<U,std::array<U,48>> transforms;
    for(auto l:layers){
        const auto m=decode(l.code);
        auto& table=transforms[l.code];
        std::array<int,3> perm{0,1,2};
        int t=0;
        do {
            for(int delta=0;delta<8;++delta){
                U out=0;
                for(int v=0;v<8;++v){
                    int w=delta;T dest{};
                    for(int k=0;k<3;++k){w^=((v>>k)&1)<<perm[k];dest[perm[k]]=m[v][k];}
                    const U j=std::find(triples.begin(),triples.end(),dest)-triples.begin();
                    assert(j<35);
                    out|=j<<(6*w);
                }
                table[t++]=out;
            }
        }while(std::next_permutation(perm.begin(),perm.end()));
        assert(t==48);
    }
    std::map<size_t,int> sizes;std::ofstream out("orbits.tsv");
    while(!full.empty()){
        const auto [a,b]=*full.begin();
        std::set<std::pair<U,U>> orb;
        const auto& aa=transforms.at(a);const auto& bb=transforms.at(b);
        for(int t=0;t<48;++t){orb.emplace(aa[t],bb[t]);orb.emplace(bb[t],aa[t]);}
        for(auto p:orb)assert(full.erase(p)==1);
        ++sizes[orb.size()];
        out<<a<<'\t'<<b<<'\t'<<orb.size()<<'\n';
    }
    for(auto [n,k]:sizes)std::cout<<n<<':'<<k<<' ';
    std::cout<<'\n';
}
