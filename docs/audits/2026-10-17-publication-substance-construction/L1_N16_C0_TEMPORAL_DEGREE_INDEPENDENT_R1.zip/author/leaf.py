from collections import Counter
from pathlib import Path
local=[(a,b,c) for a in range(5) for b in range(5-a) for c in range(5-a-b)]
def decode(code): return [local[(code>>(6*v))&63] for v in range(8)]

def strip(m):
    edges={}
    for u in range(8):
        for k in range(3):
            v=u^(1<<k)
            if u<v and (m[u][k] or m[v][k]):
                edges[u,v]=(m[u][k],m[v][k])
    removed=[]
    while edges:
        degree=Counter(x for pair in edges for x in pair)
        leaf=next(((u,v) for (u,v),(a,b) in sorted(edges.items())
                   if min(degree[u],degree[v])==1 and min(a,b)==0),None)
        if leaf is None: break
        u,v=leaf
        a,b=edges.pop(leaf)
        assert (a or b)%2==0
        removed.append((u if a else v,(u^v).bit_length()-1,a or b))
    return removed,edges

def largest_coframe(m):
    n=[sum(row) for row in m]
    adj=[set() for _ in m]
    for u in range(8):
        for k in range(3):
            v=u^(1<<k)
            if n[u]+n[v]-m[u][k]-m[v][k]:
                adj[u].add(v)
    remaining=set(range(8))
    largest=0
    while remaining:
        component={min(remaining)}
        while True:
            union=component|set().union(*(adj[u] for u in component))
            if union==component:break
            component=union
        remaining-=component
        largest=max(largest,len(component))
    return largest

def separable_layer(m):
    return len({k for row in m for k in range(3) if row[k]})==1
complete=[]; partial=0
for row in Path("orbits-slab.tsv").read_text().splitlines():
    a,b,n=map(int,row.split()); A,B=decode(a),decode(b)
    mixed=len({k for r in A+B for k in range(3) if r[k]})>1
    x,rx=strip(A);y,ry=strip(B)
    if mixed and (x or y):partial+=1
    if mixed and not rx and not ry:
        score=max(largest_coframe(A),largest_coframe(B))
        complete.append((score,a,b,n,A,B,x,y))
assert complete
print("mixed orbits admitting at least one exact single-root leaf",partial)
print("mixed orbits fully reducible by those leaves",len(complete),
      "labeled",sum(r[3] for r in complete))
print("fully reducible mixed maximum coframe component census",sorted(Counter(r[0] for r in complete).items()))
print("first fully reducible mixed representative",min(complete))
print("fully reducible mixed with both layers separately axis-separated",
      sum(separable_layer(r[4]) and separable_layer(r[5]) for r in complete))
from fractions import Fraction as F
separate=[r for r in complete if separable_layer(r[4]) and separable_layer(r[5])]
c=F(3598425,8192)
total=F(0)
for _,a,b,n,A,B,_,_ in separate:
    assert sorted(sum(x) for x in A)==sorted(sum(x) for x in B)==[0]*4+[4]*4
    value=F(10,24)**8*c**4
    total+=n*value
    print("exact mixed leaf-and-slice orbit",a,b,"weight",n,"value",value)
print("mixed leaf-and-slice labeled mass",sum(r[3] for r in separate),"subtotal",total)
print("first unresolved fully leaf-reduced coframe-only pilot",
      min(r for r in complete if r[0]==8))
