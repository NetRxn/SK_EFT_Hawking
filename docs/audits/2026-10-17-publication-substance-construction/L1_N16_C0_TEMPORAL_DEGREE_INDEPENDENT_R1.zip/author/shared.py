from fractions import Fraction
from itertools import product
from src.core.formulas import original_spin4_link, original_plaquette
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol, matrix_multiply, matrix_dagger

reg=OriginalRegulator(temporal_axis=0)
x=(0,0,0,0)
roots=[(t,r,0,0) for t,r in product(range(2),repeat=2)]
matches={}
units=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),
       (Fraction(1,2),)*4,(Fraction(3,5),0,Fraction(4,5),0))
point={(r,k):original_spin4_link(units[i%6],units[(2*i+1)%6])
       for i,(r,k) in enumerate(product(roots,(0,1)))}
for i,r in enumerate(roots):
    a,b,c,d=(r,0),(reg.step(r,0)[0],1),(reg.step(r,1)[0],0),(r,1)
    closed=matrix_multiply(matrix_multiply(matrix_dagger(point[d]),matrix_dagger(point[c])),
                           matrix_multiply(point[b],point[a]))
    assert original_plaquette(reg,r,0,1,point)==closed
    for j,(anchor,dagger) in enumerate(((d,True),(c,True),(b,False),(a,False))):
        u,v=4*i+j,4*i+(j+1)%4
        matches.setdefault(anchor,[]).append((v,u) if dagger else (u,v))
assert len(matches)==8 and all(len(v)==2 for v in matches.values())
par=list(range(16))
def root(v):
    while par[v]!=v:
        v=par[v]
    return v
for p in matches.values():
    for a,b in zip(*p):
        par[root(a)]=root(b)
free=len({root(i) for i in range(16)})
moment=Fraction(3)**(free-8)
assert free==4 and moment==Fraction(1,81)
print("four original words, eight shared anchors, free Schur indices",free)
print("joint adjoint characters",moment)

basis=[tuple(Symbol("q",(x,0,chi,j)) for j in range(4)) for chi in ("L","R")]
H=original_spin4_link(*(tuple(Polynomial.variable(s) for s in row) for row in basis))
g=reg.gamma
op=matrix_multiply(matrix_multiply(g[0],g[1]),reg.gamma5)
trace=sum((H[i][j]*op[j][i] for i,j in product(range(4),repeat=2)),Polynomial())
source={(key[0].index[-2],key[0].index[-1]):v.real for key,v in trace.terms}
assert source=={("L",3):-2,("R",3):2} and all(v.imag==0 for _,v in trace.terms)
# Isotropic root conjugation turns a curvature square into
# 2-(chi_L+chi_R)/3. A nonempty proper subset has a singleton
# original anchor, so only constants and a same-chirality four-cycle survive.
joint=16+2*moment/3**4
assert joint==Fraction(104978,6561)
print("two connector squared-curvature kernels with shared spatial Haar",joint)
print("same curvature kernels with separately averaged spatial Haar",16)
