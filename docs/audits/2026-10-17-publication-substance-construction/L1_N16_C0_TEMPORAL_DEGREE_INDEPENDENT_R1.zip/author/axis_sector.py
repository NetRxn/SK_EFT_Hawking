from fractions import Fraction as F
from itertools import product
from math import factorial, prod
from pathlib import Path

def c2(q): return 4*q*q-1
def c4(q): return 16*q**4-12*q*q+1
co = {
    0:{(0,0):F(1)},
    2:{(0,0):F(2),(1,0):F(-1,3),(0,1):F(-1,3)},
    4:{(0,0):F(10),(1,0):F(-3),(0,1):F(-3),
       (2,0):F(1,5),(0,2):F(1,5),(1,1):F(2,3)}
}
for a,b in product(map(F,(-1,0,F(1,2),F(3,5),1)),repeat=2):
    l,r=1-a*a,1-b*b
    chars=lambda q:(1,c2(q),c4(q))
    assert sum(x*chars(a)[i]*chars(b)[j] for (i,j),x in co[2].items()) == F(4,3)*(l+r)
    assert sum(x*chars(a)[i]*chars(b)[j] for (i,j),x in co[4].items()) == (
        F(16,5)*(l*l+r*r)+F(32,3)*l*r)
def face(ms):
    return sum(prod(co[m].get((a,b),0) for m in ms)/F(((2*a+1)*(2*b+1))**4)
               for a,b in product(range(3),repeat=2))
assert face([2]*4)==F(104978,6561)
assert face([4,0,4,0])==100

local=[(a,b,c) for a in range(5) for b in range(5-a) for c in range(5-a-b)]
def decode(code): return [local[(code>>(6*x))&63] for x in range(8)]
rows=[tuple(map(int,x.split())) for x in Path('orbits-slab.tsv').read_text().splitlines()]
u,=[x.split() for x in Path('uniform-slice.out').read_text().splitlines()
    if x.startswith('C numerator')]
c_uniform=F(int(u[2]),int(u[5])**int(u[7]))
assert c_uniform==F(1573101,2048)
s,=[x.split() for x in Path('pilot_signed.out').read_text().splitlines()
    if x.startswith('pilot checkerboard')]
c_checker=F(int(s[4]),12288**4)
assert c_checker==F(3598425,8192)
aggregate=F(0);zero=positive=labeled_pos=labeled_zero=0
terms=[]
for a,b,weight in rows:
    M=[decode(a),decode(b)]
    used={k for row in M for m in row for k in range(3) if m[k]}
    if len(used)!=1: continue
    k,=used
    m=[[r[k] for r in row] for row in M]
    if any(n%2 for row in m for n in row):
        zero+=1;labeled_zero+=weight;terms.append((a,b,weight,F(0)));continue
    curvature=prod(face([m[t][v^(u<<k)] for t,u in product(range(2),repeat=2)])
                   for v in range(8) if not v&(1<<k))
    coframe=F(1)
    for t,u in product(range(2),repeat=2):
        slice_ms=sorted(m[t][v] for v in range(8) if ((v>>k)&1)==u)
        if slice_ms==[2]*4: coframe*=c_uniform
        elif slice_ms==[0,0,4,4]: coframe*=c_checker
        else: raise AssertionError(slice_ms)
    exact=curvature*coframe/prod(factorial(n) for row in m for n in row)
    assert exact>0
    if a==b==279173922820:
        assert exact==F(10,24)**8*c_checker**4
        print("named nonuniform pilot exact",exact)
    if a==b==8935713546370:
        assert exact==F(104978,6561)**4*c_uniform**4/2**16
        print("uniform control exact",exact)
    aggregate+=weight*exact
    positive+=1;labeled_pos+=weight;terms.append((a,b,weight,exact))
assert positive+zero==22 and labeled_pos+labeled_zero==291
print("positive axis-separated orbits",positive,"labeled",labeled_pos)
print("zero axis-separated orbits",zero,"labeled",labeled_zero)
print("complete axis-separated subtotal",aggregate)
Path("axis-values.tsv").write_text("".join(f"{a}\t{b}\t{w}\t{z}\n" for a,b,w,z in terms))
