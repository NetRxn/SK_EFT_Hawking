from fractions import Fraction
from itertools import product
from pathlib import Path
from src.core.formulas import original_coframe_blocks, original_spin4_link, original_plaquette
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol, assemble_coframe, matrix_multiply

reg = OriginalRegulator(temporal_axis=0)
x = (0,0,0,0)
odd_sites = {x,reg.step(x,2)[0],reg.step(x,3)[0]}
index = {g:i for i,g in enumerate(g for g in reg.generator_order if g[0] in odd_sites)}
coframes = []
for axis in (2,3):
    y = reg.step(x,axis)[0]
    for A in range(4):
        p = assemble_coframe(reg,original_coframe_blocks(reg,(x,axis,A)))
        for (a,b),f in p.entries:
            u = index[reg.sites[a//4],"bar",a%4]
            v = index[reg.sites[b//4],"psi",b%4]
            s = 4 if u<v else -4
            for key,z in f.terms:
                sym, = key
                p,k,chi,i = sym.index
                assert p in (x,y) and k==axis
                q = 8*(p==y)+4*(chi=="R")+i
                re,im=z.real*s,z.imag*s
                assert re.denominator==im.denominator==1 and abs(re)+abs(im)==1
                coframes.append((axis-2,A,q,(1<<u)|(1<<v),int(re),int(im)))
assert len(coframes)==512

y = reg.step(x,0)[0]
z = reg.step(x,1)[0]
anchors = ((x,0),(y,1),(z,0),(x,1))
links = {a:original_spin4_link(*[
    tuple(Polynomial.variable(Symbol("q",(*a,chi,i))) for i in range(4))
    for chi in ("L","R")]) for a in anchors}
H=original_plaquette(reg,x,0,1,links)
Hi=original_plaquette(reg,x,1,0,links)
curves=[]
for A,B in product(range(4),repeat=2):
    gamma=reg.gamma
    op=matrix_multiply(matrix_multiply(gamma[A],gamma[B]),reg.gamma5)
    p=sum(((H[i][j]-Hi[i][j])*op[j][i] for i,j in product(range(4),repeat=2)),
          Polynomial())*Fraction(1,2)
    assert len(p.terms)==(128 if A!=B else 0)
    for key,v in p.terms:
        chi,={s.index[-2] for s in key}
        q = {s.index[:2]:s.index[-1] for s in key}
        assert set(q)==set(anchors)
        idx=(chi=="R")*256+sum(q[a]<<(2*i) for i,a in enumerate(anchors))
        assert v.imag==0 and v.real.denominator==1
        curves.append((A,B,idx,int(v.real)))
assert len(curves)==1536
def write(path,data):
    Path(path).write_text("".join("\t".join(map(str,r))+"\n" for r in data))
write("coframes.tsv",coframes)
write("curvatures.tsv",curves)
print("representative source factors",len(coframes),len(curves))
