from pathlib import Path
from collections import Counter
from itertools import product
local = [(a,b,c) for a in range(5) for b in range(5-a) for c in range(5-a-b)]
def decode(code):
    return [local[(code>>(6*x))&63] for x in range(8)]
def temporal_degree(m):
    return [sum(m[v][k]+m[v^(1<<k)][k] for k in range(3)) for v in range(8)]
rows = [tuple(map(int,line.split())) for line in Path('orbits-slab.tsv').read_text().splitlines()]
assert len(rows)==11923 and sum(n for a,b,n in rows)==1021224
same = []
degree_hist = Counter()
for a,b,n in rows:
    A,B=decode(a),decode(b)
    degrees=temporal_degree(A)+temporal_degree(B)
    assert all(d%2==0 for d in degrees)
    degree_hist[max(degrees)] += 1
    used={k for m in A+B for k in range(3) if m[k]}
    if len(used)==1:
        same.append((a,b,n,A,B,degrees))
print("temporal-maximum-degree orbit census", sorted(degree_hist.items()))
print("axis-separated signed orbit count",len(same),"labeled mass",sum(x[2] for x in same))
for a,b,n,A,B,degrees in same:
    if all(d==4 for d in degrees) and len(set(A+B))>1:
        print("first nonuniform axis-separated degree-four pilot", a,b,n,A,B)
        break
else:
    print("no nonuniform axis-separated degree-four pilot")
pilot=min((s for s in same if len(set(s[3]+s[4]))>1),key=lambda s:(max(s[5]),sum(d!=4 for d in s[5]),s[:2]))
print("minimum-width axis-separated nonuniform pilot",pilot)
uniform=[(a,b,n) for a,b,n,A,B,_ in same if len(set(A+B))==1]
assert len(uniform)==1 and uniform[0][2]==3
print("prior signed positive uniform orbit",uniform[0])
