#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <vector>
using Word=uint32_t;
using U64=uint64_t;
constexpr U64 LOCAL_PRODUCT_CAP=10000000;
constexpr U64 INITIAL_JOIN_CAP=50000000;
struct Z { int r=0,i=0; };
struct Term { Word mask; int re,im; };
int sign(Word a,Word b) {
    int p=0;
    while(a){Word k=a&-a;p^=std::popcount(b&(k-1))&1;a^=k;}
    return p?-1:1;
}
int main() {
    std::array<std::array<std::array<std::vector<Term>,4>,16>,2> T;
    std::array<std::array<std::vector<std::pair<int,int>>,4>,4> F;
    std::ifstream ti("coframes.tsv"),fi("curvatures.tsv");
    int axis,a,b,q,r,i;
    Word m;
    int count=0;
    while(ti>>axis>>a>>q>>m>>r>>i){T.at(axis).at(q).at(a).push_back({m,r,i});++count;}
    if(count!=512)throw std::runtime_error("coframe source roster");
    count=0;
    while(fi>>a>>b>>q>>r){F.at(a).at(b).emplace_back(q,r);++count;}
    if(count!=1536)throw std::runtime_error("curvature source roster");
    U64 raw=0;
    for(int u=0;u<16;++u)
        for(int v=0;v<16;++v)
            for(int a=0;a<4;++a)
                for(int b=0;b<4;++b)
                    raw+=T[0][u][a].size()*T[1][v][b].size()*F[a][b].size();
    std::cout<<"raw local product preflight "<<raw<<'\n';
    if(raw>LOCAL_PRODUCT_CAP)throw std::runtime_error("local product cap");
    U64 alive=0,nnz=0,imaginary=0,max_height=0;
    size_t peak=0;
    for(int u=0;u<16;++u)
        for(int v=0;v<16;++v){
            std::map<Word,std::array<Z,512>> out;
            for(int a=0;a<4;++a)
                for(int b=0;b<4;++b)
                    for(const auto& A:T[0][u][a])
                        for(const auto& B:T[1][v][b]){
                            if(A.mask&B.mask||F[a][b].empty())continue;
                            alive+=F[a][b].size();
                            auto& row=out[A.mask|B.mask];
                            int s=sign(A.mask,B.mask);
                            for(auto[q,c]:F[a][b]){
                                row[q].r+=s*c*(A.re*B.re-A.im*B.im);
                                row[q].i+=s*c*(A.re*B.im+A.im*B.re);
                            }
                        }
            peak=std::max(peak,out.size());
            for(const auto&[mask,row]:out)
                for(auto z:row){
                    nnz+=z.r||z.i;
                    imaginary+=z.i!=0;
                    max_height=std::max(max_height,U64(std::abs(z.r)+std::abs(z.i)));
                }
        }
    std::cout<<"post-wedge raw "<<alive<<" collected nonzeros "<<nnz
             <<" imaginary "<<imaginary<<" maximum scaled height "<<max_height
             <<" peak live mask rows "<<peak<<'\n';
    const U64 candidate=nnz*nnz;
    std::cout<<"unfiltered first two-factor signed Cartesian candidates "<<candidate<<'\n';
    if(candidate>INITIAL_JOIN_CAP)std::cout<<"REFUSED unfiltered signed Cartesian schedule before allocation\n";
}
