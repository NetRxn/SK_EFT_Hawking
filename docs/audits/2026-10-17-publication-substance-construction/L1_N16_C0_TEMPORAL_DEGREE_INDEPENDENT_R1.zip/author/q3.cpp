#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using U64 = uint64_t;
using Word = uint32_t;
using Count = __uint128_t;
constexpr U64 HALF_CAP = 1600000, LAYER_PAIR_CAP = 50000000;
constexpr U64 SIGNATURE_CAP = 1000000, JOINT_PAIR_CAP = 50000000;
constexpr U64 ORBIT_PAIR_CAP = 1250000;
constexpr U64 ORBIT_ACTION_CAP = 3000000;
constexpr Word DTOP = 0x88888888;
struct Local {
    std::array<int,3> m{}, h{};
    int center = 0;
    U64 key = 0;
};
struct Half { U64 key; Word roster; };
struct Signature { Word pr, az; };
std::string dec(Count x) {
    std::string s;
    do { s += char('0' + x%10); x/=10; } while(x);
    std::reverse(s.begin(),s.end()); return s;
}
struct Geometry {
    std::array<std::array<int,3>,8> edge{};
    std::array<std::pair<int,int>,12> ends{};
    std::array<Word,256> delta{};
    std::array<std::array<int,4>,2> centers{};
    std::array<std::vector<Local>,8> local;
    explicit Geometry(bool slab) {
        int ne=0, np[2]={0,0};
        for (int v=0;v<8;++v) {
            int parity=slab ? v&1 : std::popcount(unsigned(v))%2;
            centers[parity][np[parity]++]=v;
            for(int a=0;a<3;++a) {
                if(v&(1<<a)) continue;
                int y=v^(1<<a);
                ends[ne]={v,y};
                edge[v][a]=edge[y][a]=ne++;
            }
            for(int a=0;a<=4;++a)
                for(int b=0;a+b<=4;++b)
                    for(int c=0;a+b+c<=4;++c) {
                        Local L;
                        L.m={a,b,c};L.center=a+b+c;
                        U64 d=U64(2*L.center)<<(4*v);
                        unsigned t=0;
                        for(int i=0;i<3;++i) {
                            int y=v^(1<<i);
                            L.h[i]=L.center-L.m[i];
                            d|=U64(L.h[i])<<(4*y);
                            if(L.m[i]%2) t^=(1<<v)|(1<<y);
                        }
                        L.key=(d<<8)|t;
                        local[v].push_back(L);
                    }
            if(local[v].size()!=35) throw std::runtime_error("bad local roster");
        }
        for(int p=0;p<256;++p)
            for(int e=0;e<12;++e) {
                auto [u,v]=ends[e];
                if(((p>>u)^(p>>v))&1) delta[p]|=1<<e;
            }
    }
    static bool harmonic(Word edges, const std::array<std::pair<int,int>,12>& ends) {
        unsigned d=0;
        for(int e=0;e<12;++e)
            if(edges&(1<<e)) { auto[u,v]=ends[e];d^=(1<<u)|(1<<v); }
        return d==0;
    }
    void make_half(std::vector<Half>& out, int parity, int i, U64 key, Word roster) const {
        if(i==4) {
            if(out.size()>=HALF_CAP) throw std::runtime_error("half record cap");
            out.push_back({key,roster});return;
        }
        int x=centers[parity][i];
        for(int j=0;j<35;++j) {
            U64 other=local[x][j].key;
            U64 before=key>>8, add=other>>8;
            bool ok=true;
            for(int v=0;v<8;++v)
                if(((before>>(4*v))&15)+((add>>(4*v))&15)>8) {ok=false;break;}
            if(ok) make_half(out,parity,i+1,((before+add)<<8)|((key^other)&255),
                             roster|(Word(j)<<(6*i)));
        }
    }
    U64 encode(Word even,Word odd) const {
        U64 out=0;
        for(int i=0;i<4;++i) {
            out |= U64((even>>(6*i))&63) << (6*centers[0][i]);
            out |= U64((odd>>(6*i))&63) << (6*centers[1][i]);
        }
        return out;
    }
    Signature signature(Word even,Word odd) const {
        std::array<const Local*,8> L{};
        for(int i=0;i<4;++i) {
            L[centers[0][i]]=&local[centers[0][i]][(even>>(6*i))&63];
            L[centers[1][i]]=&local[centers[1][i]][(odd>>(6*i))&63];
        }
        Word p=0,r=0,a=0,z=0;
        int total=0;
        for(int v=0;v<8;++v) { p|=(L[v]->center&1)<<v;total+=L[v]->center; }
        if(total!=16) throw std::runtime_error("wrong action degree");
        for(int v=0;v<8;++v)
            for(int k=0;k<3;++k) {
                int y=v^(1<<k);
                if(v>y) continue;
                int e=edge[v][k];
                int h=L[v]->h[k]+L[y]->h[k];
                r|=((L[v]->m[k]+L[y]->m[k])&1)<<e;
                a|=(L[v]->m[k]&1)<<e;
                z|=(h==0)<<e;
            }
        if(!harmonic(r,ends)) throw std::runtime_error("connector anchor parity mismatch");
        return {p|(r<<8),a|(z<<12)};
    }
};
using Histogram = std::unordered_map<Word,std::unordered_map<Word,std::vector<int>>>;
void orbit_count(const Geometry& g,const Histogram& hist,const std::vector<U64>& layers,
                 const std::array<std::vector<int>,4096>& reverse_delta,Count expected,bool slab) {
    if(expected>ORBIT_PAIR_CAP) throw std::runtime_error("orbit pair cap before allocation");
    constexpr unsigned BITS=13;
    constexpr Word IDMASK=(1<<BITS)-1;
    if(layers.size()>1<<BITS) throw std::runtime_error("orbit ID packing cap");
    std::unordered_map<U64,int> layer_id;
    for(size_t i=0;i<layers.size();++i)
        if(!layer_id.emplace(layers[i],i).second) throw std::runtime_error("duplicated layer roster");
    std::vector<std::vector<int>> maps;
    std::array<int,3> perm={0,1,2};
    do {
        std::array<int,8> pv{};
        std::array<int,35> pl{};
        for(int v=0;v<8;++v)
            for(int a=0;a<3;++a) pv[v] |= ((v>>a)&1)<<perm[a];
        for(int i=0;i<35;++i) {
            std::array<int,3> m{};
            for(int a=0;a<3;++a) m[perm[a]]=g.local[0][i].m[a];
            auto it=std::find_if(g.local[0].begin(),g.local[0].end(),
                                 [&](const auto& L){return L.m==m;});
            if(it==g.local[0].end()) throw std::runtime_error("orbit local image missing");
            pl[i]=it-g.local[0].begin();
        }
        for(int b=0;b<8;++b) {
            std::vector<int> map;
            for(U64 key:layers) {
                U64 image=0;
                for(int v=0;v<8;++v)
                    image |= U64(pl[(key>>(6*v))&63]) << (6*(pv[v]^b));
                map.push_back(layer_id.at(image));
            }
            maps.push_back(std::move(map));
        }
    } while(std::next_permutation(perm.begin(),perm.end()));
    std::unordered_set<Word> remaining;
    remaining.reserve(U64(expected));
    for(const auto& [pr,a]:hist) {
        const Word p=pr&255,r=pr>>8;
        for(int q:reverse_delta[r]) {
            auto it=hist.find(q|(g.delta[p]<<8));
            if(it==hist.end()) continue;
            for(const auto& [x,m]:a)
                for(const auto& [y,n]:it->second)
                    if(!(((x^y)&4095)&((x|y)>>12)))
                        for(int i:m)
                            for(int j:n)
                                if(!remaining.insert((Word(i)<<BITS)|j).second)
                                    throw std::runtime_error("duplicated joint occupation");
        }
    }
    if(remaining.size()!=expected) throw std::runtime_error("orbit support mass");
    U64 total=0,actions=0,orbits=0;
    std::array<U64,97> sizes{};
    std::vector<std::array<U64,3>> representatives;
    while(!remaining.empty()) {
        const Word key=*remaining.begin();
        int i=key>>BITS,j=key&IDMASK;
        std::array<Word,96> images{};
        int n=0;
        for(const auto& m:maps) {
            if((actions+=2)>ORBIT_ACTION_CAP) throw std::runtime_error("orbit action cap");
            images[n++]=(Word(m[i])<<BITS)|m[j];
            images[n++]=(Word(m[j])<<BITS)|m[i];
        }
        if(n!=96) throw std::runtime_error("orbit group size");
        std::sort(images.begin(),images.end());
        const size_t size=std::unique(images.begin(),images.end())-images.begin();
        if(96%size) throw std::runtime_error("orbit divisibility");
        std::pair<U64,U64> canonical{~U64(0),~U64(0)};
        for(size_t k=0;k<size;++k) {
            if(remaining.erase(images[k])!=1) throw std::runtime_error("orbit overlap or support failure");
            canonical=std::min(canonical,std::pair{layers[images[k]>>BITS],layers[images[k]&IDMASK]});
        }
        representatives.push_back({canonical.first,canonical.second,size});
        ++sizes[size];total+=size;++orbits;
    }
    if(total!=expected) throw std::runtime_error("orbit mass mismatch");
    std::sort(representatives.begin(),representatives.end());
    std::ofstream export_file(slab?"orbits-slab.tsv":"orbits-checker.tsv");
    for(auto [a,b,n]:representatives) export_file<<a<<'\t'<<b<<'\t'<<n<<'\n';
    if(!export_file)throw std::runtime_error("orbit export failure");
    std::cout<<"spatial-and-layer-swap orbits "<<orbits<<" group actions "<<actions<<" sizes";
    for(size_t i=1;i<sizes.size();++i) if(sizes[i]) std::cout<<' '<<i<<':'<<sizes[i];
    std::cout<<'\n';
}
using Range = std::pair<size_t,size_t>;
std::unordered_map<U64,Range> ranges(const std::vector<Half>& h,bool parity) {
    std::unordered_map<U64,Range> out;
    const auto key=[&](size_t i){return parity?h[i].key:h[i].key>>8;};
    for(size_t i=0,j;i<h.size();i=j) {
        for(j=i+1;j<h.size()&&key(j)==key(i);++j){}
        out.emplace(key(i),Range{i,j});
    }
    return out;
}
Count pair_count(const std::unordered_map<U64,Range>& left,
                 const std::unordered_map<U64,Range>& right,bool parity) {
    Count count=0;
    for(const auto&[key,lr]:left) {
        const auto rev=parity ? ((U64(DTOP)-(key>>8))<<8)|(key&255) : DTOP-key;
        auto it=right.find(rev);
        if(it!=right.end()) count+=Count(lr.second-lr.first)*(it->second.second-it->second.first);
    }
    return count;
}
int main(int argc,char**) {
  try {
    Geometry g(argc>1);
    std::vector<Half> e,o;
    g.make_half(e,0,0,0,0);
    g.make_half(o,1,0,0,0);
    const auto cmp=[](const Half&a,const Half&b){return a.key<b.key;};
    std::sort(e.begin(),e.end(),cmp);std::sort(o.begin(),o.end(),cmp);
    std::cout<<"half records "<<e.size()<<' '<<o.size()<<'\n';
    std::cout<<"single-layer site-saturated "<<dec(pair_count(ranges(e,false),ranges(o,false),false))<<'\n';
    auto le=ranges(e,true),ri=ranges(o,true);
    Count layer=pair_count(le,ri,true);
    std::cout<<"single-layer site and temporal parity "<<dec(layer)<<" match keys "<<le.size()<<' '<<ri.size()<<'\n';
    if(layer>LAYER_PAIR_CAP) throw std::runtime_error("layer pair cap before signature allocation");
    Histogram hist;
    std::vector<U64> layers;
    U64 retained=0,bins=0;
    std::array<std::vector<int>,4096> reverse_delta;
    for(int p=0;p<256;++p) reverse_delta[g.delta[p]].push_back(p);
    for(const auto&[key,lr]:le) {
        const auto rev=((U64(DTOP)-(key>>8))<<8)|(key&255);
        auto it=ri.find(rev);
        if(it==ri.end()) continue;
        for(size_t i=lr.first;i<lr.second;++i)
            for(size_t j=it->second.first;j<it->second.second;++j) {
                const Signature s=g.signature(e[i].roster,o[j].roster);
                const Word p=s.pr&255,r=s.pr>>8;
                if(!Geometry::harmonic(g.delta[p],g.ends)||reverse_delta[r].empty()) continue;
                auto [record, fresh]=hist[s.pr].try_emplace(s.az);
                if(fresh && ++bins>SIGNATURE_CAP) throw std::runtime_error("signature record cap");
                record->second.push_back(layers.size());
                layers.push_back(g.encode(e[i].roster,o[j].roster));
                ++retained;
            }
    }
    std::cout<<"single-layer retained cross-signature envelope "<<retained<<" bins "<<bins
             <<" primary keys "<<hist.size()<<'\n';
    Count undirected=0, directed=0, tested=0;
    for(const auto& [pr,a]:hist) {
        const Word p=pr&255,r=pr>>8;
        for(int q:reverse_delta[r]) {
            const Word qr=q|(g.delta[p]<<8);
            auto it=hist.find(qr);
            if(it==hist.end()) continue;
            const auto& b=it->second;
            tested+=Count(a.size())*b.size();
        }
    }
    std::cout<<"joint distinct signature candidate pairs "<<dec(tested)<<'\n';
    if(tested>JOINT_PAIR_CAP) throw std::runtime_error("joint pair cap before directed join");
    for(const auto& [pr,a]:hist) {
        const Word p=pr&255,r=pr>>8;
        for(int q:reverse_delta[r]) {
            const Word qr=q|(g.delta[p]<<8);
            auto it=hist.find(qr);
            if(it==hist.end()) continue;
            for(auto[x,m]:a)
                for(auto[y,n]:it->second) {
                    const Count ways=Count(m.size())*n.size();
                    undirected+=ways;
                    if(!(((x^y)&4095)&((x|y)>>12))) directed+=ways;
                }
        }
    }
    std::cout<<"full block joint undirected occupations "<<dec(undirected)
             <<" directed occupations "<<dec(directed)<<'\n';
    orbit_count(g,hist,layers,reverse_delta,directed,argc>1);
  } catch(const std::runtime_error& e) {
    std::cout<<"REFUSED "<<e.what()<<'\n';
    return 2;
  }
}
