# Original N16 connector degree blocks and signed contraction preflight

The primary packet
`publication-l1-n16-c0-connector-degree-frontier-author-r1.json`
checked fresh at `27012c18fa374e8341e124b510abbedeedb18d29`.
This scratch result uses the original periodic closed source and its
two-connector cut from the preceding provisional sign report. It
eliminates the complete connector-degree pair (1,31), gives exact
support and a representative table for the complete temporal-curvature
block at n=16, and evaluates 24 orbits in that block. The remaining
signed block and the full c0 are open. No tracked source, notebook,
controller or Lean slot was modified.

## Exact degree exclusions

Let w_n be the independent connector Haar integral of K(A,B)^n/n!.
In any product let f count the temporal-curvature factors, and p,q
count temporal-coframe factors centered respectively in A,B. Then

```
n=f+p+q
d_A=4f+3p+q
d_B=p+3q.
```

Each temporal curvature occupies the two distinct forward anchors
at adjacent spatial vertices of Q3. Each temporal coframe contributes
one use at its spatial vertex. The parity condition on a connector
anchor is even total use there. In particular p+q is even. Flipping
the connector anchors on either one of the two spatial sublattices
shows separately that the number of temporal-coframe factors at
that spatial parity equals f modulo two. Thus odd f requires at
least two temporal-coframe factors, one on each spatial parity.

A single factor has an odd occurrence on at least one independent
connector anchor, so w_1 is identically zero. The paired terms n=1
and n=31 are therefore exactly absent from the full c0. For n=2,
only two curvature factors on the same temporal-anchor pair or
two temporal-coframe factors on the same anchor can survive. This
leaves only layer degrees (8,0), (6,2), (4,4), (2,6). For n=3,
three pure curvature factors cannot make an even multigraph on the
bipartite temporal-anchor Q3. The only possible roster has one
curvature factor and two temporal coframes, one at each endpoint
of its anchor pair. It leaves only (10,2), (8,4), (6,6). These are
support envelopes, rather than assertions that every component is
nonzero. More generally the A-only projection of odd w_n vanishes
by the same bipartite even-graph argument, and the B-only projection
vanishes for every n>0 because every K(A,B) factor uses A odd
generators.

The full sewing matches (n,d_A,d_B) to
(32−n,64−d_B,64−d_A) in the untransposed connector kernel.
`degrees.py` exhausts the numerical necessary conditions above
and both layer capacity bounds. It finds 377 ordered candidate
degree-and-layer blocks. The only connector degrees absent from
that envelope are n=1 and n=31. Additional source zeros are possible.

## Complete n=16 block with only temporal curvatures

Take the w_16 component of layer degree (64,0). Its sewn partner
is the same component in the swapped kernel. All factors must
be temporal curvatures with two spatial coframes. This defines
one complete bidegree block, with no terms of this bidegree
omitted. It contains a previously evaluated strictly positive
single occupation, obtained by a world permutation of the
uniform rooted-plane profile. That checks actual signed support
in the block and does not determine its complete sign.

In each Q3 layer let m(v,k) count temporal-curvature terms
centered at v in the plane with spatial axis k. Define

```
M(v)=sum_k m(v,k)
h(v,k)=M(v)-m(v,k)
d(v--w,k)=h(v,k)+h(w,k).
```

There are 35 local triples with nonnegative entries and M≤4.
Every term uses two central odd generators and one at each
of its two complementary spatial neighbors. Thus degree-eight
saturation is exactly sum of the incident d's equals eight
at each site. It implies sum_v M(v)=16.

Each temporal connector retains its own parity test. Set
R(v--w)=m(v,k)+m(w,k) modulo two. The connector's independent
anchor parities mean that R is an even edge chain, with zero
boundary at every vertex. Let P(v)=M(v) modulo two, and let
L(v--w)=m(v,k) modulo two at the endpoint v with its k bit zero.

Now perform the parity preflight for the **shared** spatial Haar.
Each curvature rooted at v in either connector uses the spatial
anchor (v,k) once in both layers. Thus at each actual spatial
anchor its curvature count is the sum of both connectors' root
multiplicities. The necessary undirected conditions in A and B
are equivalent to

```
R_A = delta P_B,  R_B = delta P_A,
```

where delta is the edge gradient over GF(2). Indeed
d_A = delta P_A + R_A modulo two, while the curvature parity
on its undirected edge is R_A+R_B. The B equation is analogous.
With d>0, aggregate parity is sufficient for allocating the
coframe occurrences between the two directed anchors at the
unresolved-chirality level. With d=0, both directed curvature
parities must already be zero. Given the preceding equations,
this is exactly L_A=L_B on every edge with d_A=0 or d_B=0.
The comparison retains both anchors and both connector labels.
Separate chiral and coordinate moment tests remain necessary.

## Sparse preflight and reproducible complete support table

The eight spatial centers are split into two groups of four.
Each partial record keeps its labeled site degree vector,
connector anchor XOR and four local triple identities. Join
on complementary site degree and equal connector XOR.
The two independent splittings use checkerboard and coordinate
slabs. The two methods give identical complete support:

| Stage | Exact result |
| --- | ---: |
| Site-saturated layer occupations | 163,194 |
| With that layer's temporal parity | 21,462 |
| Layer occupations retained by the cross-signature envelope | 6,174 |
| Distinct joint signature comparisons | 73,833 |
| Joint undirected-compatible ordered occupations | 1,335,360 |
| Joint split-anchor-compatible ordered occupations | **1,021,224** |

The signature counts are exact for these stated coarse tests.
In particular the last count bounds the support of the signed
complete block from above, rather than counting its nonzero
terms. The slab split generates only 52,292 half records per side
versus 866,837 for the checkerboard split. Both runs retain the
individual local triple identities until their required sign
and moment constraints can be applied.

The simultaneous spatial group has eight bit translations and
six axis permutations, together with exchange of the two layers.
It has 96 elements. Layer exchange preserves the full top,
and each odd world permutation supplies its sign 32 times.
The original signed occupation is constant on each orbit.
Partitioning the exact support by this action gives **11,923**
orbits. The size distribution is

```
3:2  6:21  12:81  24:383  48:1811  96:9625.
```

The two complete representative tables are byte-identical.
Each row has two layer codes and its orbit multiplicity.
A layer code uses six bits per spatial vertex, in ascending
vertex order. Each six-bit index is the position of the local
triple in ascending nested a,b,c loops with a+b+c≤4. It gives
the complete labeled exponents, so no additional orbit factor
from an independent per-layer action is applied.

Prospective support caps were 1.6 million partial records per
half, 50 million layer join pairs, one million signature bins,
50 million joint signature comparisons, 1.25 million ordered
pairs for orbit extraction and three million group actions.
The slab support and orbit run took about 0.15 seconds and
53 MB peak RSS. Exact values are in both receipts.

The signed contraction corresponding to this table is the sum
over its representatives of orbit multiplicity times the
original Grassmann top and product Haar of the representative's
ordered rooted factors, with both layers' spatial anchor
polynomials multiplied before integrating them and divided
by the product of every original m!. The local wedge sign is
always that of the canonical source-order masks. Each original
quaternion group is integrated only once, on its complete
coordinate exponent. This is a finite exact contraction
schedule once a cap-safe moment and mask elimination is chosen.

The naive explicit Cartesian version of this schedule refuses.
`source_tensor.py` exports the literal original coframe and
curvature coefficients for a representative temporal plane.
`tensor.cpp` uses the actual quarter-coframe coefficients,
coefficient phases and exterior inversion signs. The local
product has 6,291,456 raw attempts, 5,505,024 after Grassmann
collision rejection, and exactly 1,277,952 collected nonzero
keys, of which 638,976 have imaginary coefficient. The local
count stays within its ten-million-product cap by grouping
coframe quaternion labels before collecting. The unfiltered
first Cartesian join of two such factors would try
1,633,161,314,304 products, exceeding its 50-million-product
cap before allocation. This is a refusal of that explicit
signed schedule. It is not a lower bound on a projected
Haar join or the remaining source frontier.

## Shared spatial Haar control

`shared.py` checks four actual closed words rooted on the same
time-spatial 2×2 face, using both connectors and all eight
anchored variables. Two roots per connector share their two
temporal anchors. After root conjugation averaging, the literal
F01 square gives 2−(chi_L+chi_R)/3, with chi the spin-one
adjoint character. The source has F01=−2q_(L,3)+2q_(R,3).
A proper nonempty same-chirality subset of the rooted words
leaves an unpaired anchored matrix, so only the constant and
the complete four-root loop survive.

For the loop, Haar orthogonality pairs the two matrix entries
on each of eight real adjoint links. The literal D† C† B A
words leave four free trace-index classes, giving a character
moment 3^(4−8)=1/81. This is verified by exact index pairing
and by comparing the four original words at asymmetric
rational source links. The product of the two connector
squared-curvature kernels has moment 104978/6561 with
shared spatial Haar. Separately averaging each kernel over
its spatial variables gives 4×4=16. This control checks the
shared-anchor obstruction independently of the occupancy
frontier.

## Exact signed subclass and the first signed pilot

Among the complete block's representatives, 22 orbits with
291 labeled occupations use a single common spatial curvature
axis in both layers. The curvature and coframe anchor sets are
then disjoint. For each coframe square, degree saturation gives
local center multiplicities 2±t in a checkerboard pattern.
Indeed opposite vertices have the same two neighbors, so
subtracting their equations forces equal multiplicities.
Adjacent multiplicities then sum to four.
Independently conjugate the rooted curvature holonomy at each
root using only the curvature anchor variables. An odd
curvature power vanishes by isotropy. Thus the only surviving
squares are the uniform m=2 and checkerboard m=0,4 cases.

For both chiralities the squared norm of the curvature
coefficient contracted with the two coframes is the same
nilpotent polynomial W_x from the earlier source Gram
calculation. Let chi_j denote the integer-spin character.
Independent orientation averaging at the root leaves W_x^(m/2)
times the following scalar character polynomial:

```
m=0: 1
m=2: 2 - (chi_1^L + chi_1^R)/3
m=4: 10 - 3(chi_1^L + chi_1^R)
        + (chi_2^L + chi_2^R)/5 + (2/3) chi_1^L chi_1^R.
```

For the fourth power this follows from the sphere moments
E u²=1/3 and E u⁴=1/5 and the two independent chiral orientations.
Writing l=1−q0_L² and r=1−q0_R², the polynomial before character
expansion is (16/5)(l²+r²)+(32/3)lr. The script verifies both
character expansions by exact rational substitution. On a
curvature face the anchor pair integrals force one common spin
per chirality at all four roots. The equality classes are the
same four as in the source control, giving d_L^-4 d_R^-4,
where d_chi=2j_chi+1. Therefore all four-root face factors
are finite sums over spins 0,1,2, retaining the shared
spatial anchors. For m=2 at all roots this reproduces
104978/6561. A face with a zero root retains only spin zero.

The first nonuniform signed pilot is the representative
`(279173922820,279173922820)`, orbit size six. In both
layers m_(v,03)=4 at spatial vertices 0,3,5,6 and all
other entries vanish. Each (0,3) face has one active root
per connector and two disjoint pairs of temporal anchors.
Conditional on the shared spatial links, the individual
holonomies are independent Haar, so each active root gives
10 W_x². This simplification is proved only for this pilot
and the related complete single-root cases.

The checkerboard coframe square has four coframes at the
active endpoint of each edge and none centered at the
inactive endpoint. The edge supplies degree four at each
endpoint. The active interface is at most 35 symmetric
internal quartic labels times 70 degree-four masks, and the
inactive interface is only 70 masks. The exact source
edge exporter verifies equality of the relevant world-axis
rosters after relabeling. The two coframe pairings and
endpoint reversal give identical edge tensors. The
measured grouping used 1,036,576 Haar candidate joins,
380 nonzero edge entries and 7,344 matching products.
It retained the complex numerators and source complement
signs from the original slice method. The exact checkerboard
slice is 3598425/8192. The uniform slice receipt carries
1573101/2048. The named pilot therefore has original value

```
(10/4!)^8 (3598425/8192)^4
= 9982511481025756988525390625/295147905179352825856.
```

The exact calculation of all 22 common-axis orbits gives
five zero orbits with 48 labeled occupations and 17 positive
orbits with 243 labeled occupations. The full weighted
common-axis subtotal is

```
9508082319300279337096284815510102405304663083
/4411510252774325019161395200000000.
```

The table `axis-values.tsv` gives every representative,
multiplicity and signed value. This completes a subclass
of the declared degree block rather than a separate action.

## A cap-safe mixed-axis reduction

For a fixed representative, form the temporal-anchor graph
in each layer, with an edge for any temporal-curvature
occurrence at either of its roots. If a temporal anchor is a
leaf and only one root is occupied on that edge, its group
variable appears only in one rooted holonomy. Conditional on
all other links and on all coframes, integration of this
leaf makes that holonomy Haar. It replaces the whole power
by its exact isotropic moment, independent of the other
temporal anchor and the two shared spatial curvature
anchors in that root. Those spatial anchors remain wherever
other factors still use them. This step uses the original
Haar product and works before materializing any local
coefficient Cartesian product. Repeating the rule leaves
either a smaller curvature graph or an entirely coframe
problem. No factorization of the residual shared spatial
Haar is made.

The full representative table contains 8,210 mixed-axis
orbits with at least one such leaf and 12 mixed orbits
with all curvature powers removable by leaves. The latter
cover 312 labeled occupations. Two of those orbits have
parallel checkerboard coframe squares in each layer, with
different curvature axes across the layers. The exact same
slice and factorial calculation evaluates both positively.
Their representative codes are
`(279173922820,977108729870)` and
`(279173922820,61572886094720)`, each of size 12.
The exact weighted subtotal of these 24 occupations is
29947534443077270965576171875/36893488147419103232.

The first remaining entirely leaf-reduced pilot is
`(279173922820,289913962500)`, orbit size 48. It leaves
one connected coframe-only Q3 with eight sites. Its
signed edge and vertex contraction is the next bounded
moment step, using the same labeled masks and an edge
elimination order chosen from measured incidence widths.
No full mixed-axis signed join is yet certified.

In total 24 orbits with 315 labeled coarse survivors have
exact signed values, leaving 11,899 orbits with 1,020,909
labeled coarse survivors in this complete degree block.
The computed positive subtotal does not control the signs
of the remaining occupations or of the other degree blocks.

## Reproduction

Compile `q3.cpp`, `tensor.cpp`, and `pilot_signed.cpp` with
`clang++ -std=c++20 -O3 -Wall -Wextra -Werror`.
Run `q3` in its default checkerboard mode and with `slab`,
and compare the emitted tables. Run the Python scripts
`degrees.py`, `pilot.py`, `axis_sector.py`, and `leaf.py`
in the package directory. For `source_tensor.py`, `shared.py`,
and `edge_export.py`, use the exact primary on PYTHONPATH
and its existing venv Python with PYTHONDONTWRITEBYTECODE=1.
The signed pilot includes the earlier slice utility file
with its main function explicitly returning zero for the
renamed-entrypoint build. Timed receipts use `measure.py`.
The package and the earlier signed input remain subject to
independent mathematical and original-source review.
