from itertools import product

def candidates(n):
    out = set()
    for f in range(n+1):
        t = n-f
        if t%2 or (f%2 and t<2):
            continue
        for c in range(t+1):
            a, b = 4*f+3*c+(t-c), c+3*(t-c)
            if max(a,b)<=64:
                out.add((a,b))
    return out if n!=1 else set()

def paired(n):
    return sorted((a,b) for a,b in candidates(n)
                  if (64-b,64-a) in candidates(32-n))

assert candidates(1)==set()
assert candidates(2)=={(8,0),(6,2),(4,4),(2,6)}
assert candidates(3)=={(10,2),(8,4),(6,6)}
assert [n for n in range(33) if not paired(n)] == [1,31]
for n in range(17):
    print("connector factors",n,"paired layer degrees",paired(n))
print("ordered potential degree-and-layer blocks",sum(len(paired(n)) for n in range(33)))
