import ast,hashlib,json,pathlib,re,subprocess,sys
from collections import Counter
F=pathlib.Path(sys.argv[1])
def prev(p):return subprocess.check_output(['git','show','HEAD:'+p],text=True)
def tree(p):return pathlib.Path(p).read_text()
def registry(text):
 for n in ast.parse(text).body:
  if isinstance(n,ast.Assign) and any(getattr(x,'id','')=='CITATION_REGISTRY' for x in n.targets):return ast.literal_eval(n.value)
def dif(a,b):return sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))
p='src/core/citations.py'
changed={'Amelio2020','Coutant2014','CoutantWeinfurtner2018KdV','AndersonBFP2014Graybody'}
assert set(dif(registry(prev(p)),registry(tree(p))))==changed
p='docs/primary_sources_state.json'
a,b=[json.loads(x) for x in (prev(p),tree(p))]
assert all(a.get(k)==b.get(k) for k in a.keys()|b.keys() if k!='entries')
assert set(dif(a['entries'],b['entries']))==changed
for k in sorted(changed):
 x=b['entries'][k]; y=registry(tree('src/core/citations.py'))[k]
 assert x['primary_source_path']==y['primary_source_path']
 root=pathlib.Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research')
 pdf=root/x['primary_source_path']
 assert pdf.stat().st_size==x['size_bytes']
 print('source',k,x['url_used'],hashlib.sha256(pdf.read_bytes()).hexdigest())
p='papers/E1/bundle_metadata.json'
a,b=[json.loads(x) for x in (prev(p),tree(p))]
assert set(dif(a,b))=={'apex_theorems','length_target'}
a1,b1=[{x['name']:x for x in z['apex_theorems']} for z in (a,b)]
d=dif(a1,b1)
assert len(d)==2
assert all(dif(a1[k],b1[k])==['claims'] for k in d)
assert dif(a['length_target'],b['length_target'])==['abstract_ceiling']
print('metadata',d,'abstract_ceiling source verified',b['length_target']['abstract_ceiling']['source_verified'])
p='src/core/visualizations.py'
nodes=lambda s:{n.name:ast.dump(n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
assert dif(nodes(prev(p)),nodes(tree(p)))==['fig_polariton_regime_map','fig_stimulated_hawking_spectrum']
print('producer',dif(nodes(prev(p)),nodes(tree(p))))
texts={code:tree(f'papers/{code}/paper_draft.tex') for code in ('E1','E2')}
bad={'E1':['no device parameter can move','cannot be absorbed into the greybody factor','no longer a large fraction of the probe','dug out of a background ten'],'E2':['first platform','stays within a few percent','every $1{+}1$D result transfers','a single shot resolves']}
good={'E1':['necessary weak-loss criterion','does not determine a mode occupation','requires a measured in-band noise budget','A gain-shape comparison is','unknown $\\Gamma(\\omega)$','Acquisition time depends on the calibrated transfer and noise'], 'E2':['AndersonBFP2014Graybody','exterior asymptotic sound speed','finite-band error bound','0.99994','26.3','cannot independently identify','no achieved sensitivity']}
for code,text in texts.items():
 collapsed=' '.join(text.split())
 assert all(t not in collapsed for t in bad[code]), (code,bad[code])
 assert all(t in collapsed for t in good[code]), (code,[(t,t in collapsed) for t in good[code]])
 pdf=F/f'papers/{code}/paper_draft.pdf'
 rendered=subprocess.check_output(['pdftotext',str(pdf),'-'],text=True)
 count=len(rendered.split())+300*text.count(r'\begin{figure}')
 assert count=={'E1':3409,'E2':3629}[code]
 print('length',code,count,'PDF',hashlib.sha256(pdf.read_bytes()).hexdigest())
print('PASS scoped source, adverse text and PDF-count checks')
