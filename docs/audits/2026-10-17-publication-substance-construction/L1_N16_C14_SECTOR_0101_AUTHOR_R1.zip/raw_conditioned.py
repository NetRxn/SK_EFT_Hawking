"""Independent original-spoke exact control using literal source halves."""
from collections import defaultdict
from itertools import product
from pathlib import Path
import json,sys
import qcontract as q

D=Path(__file__).parent
ZERO=(0,0)

def literal_half(data,side,ray):
    table={}
    for (a,b,z),(c,d,w) in product(data[side][0][1],data[side][1][1]):
        q.work('literal_source_trace_pair')
        v=ray.get((b[0],d[0],b[1],d[1]),ZERO)
        if v==ZERO:
            continue
        key=tuple(4*x+y for x,y in zip(a,c,strict=True))
        if key not in table and len(table)==q.ROWS:
            raise q.Refused(('literal_half_rows',len(table)+1,q.ROWS))
        table[key]=q.add(table.get(key,ZERO),q.mul(v,q.mul(z,w)))
    return {k:z for k,z in table.items() if z!=ZERO}

def literal_spoke(raw,name,j):
    t={}
    for (a,b,c,d),z in raw[name][j].items():
        q.work('literal_spoke_row')
        x,y=4*a+b,4*c+d
        t[(y,x) if name in 'CD' else (x,y)]=z
    return t

def main(ix):
    q.CAP=6_000_000
    q.rss()
    raw,source=q.source()
    data=q.traces(source)
    mask=[tuple(k) for k,w in q.read(D/'weighted-mask-amplitude-0101.jsonl')]
    expected={tuple(k):tuple(z) for k,z in q.read(D/'q-amplitudes-0101.jsonl')}
    key=mask[ix]
    l=literal_half(data,0,raw['E'][key[4]])
    r=literal_half(data,1,raw['F'][key[5]])
    spokes=[literal_spoke(raw,name,j) for name,j in zip(q.SPK,key[:4],strict=True)]
    right=list(r.items())
    restrictions=[]
    for i,t in enumerate(spokes):
        rev=defaultdict(list)
        for x,y in t:
            rev[y].append(x)
        found=defaultdict(int)
        for j,(lab,z) in enumerate(right):
            q.work('right_support_index')
            for x in rev[lab[i]]:
                q.work('right_support_bitset')
                found[x]|=1<<j
        restrictions.append(found)
    plans=[]
    n=0
    for lab,v in l.items():
        q.work('literal_spoke_preflight')
        bits=restrictions[0][lab[0]]&restrictions[1][lab[1]]&restrictions[2][lab[2]]&restrictions[3][lab[3]]
        if bits:
            plans.append((lab,v,bits))
            n+=bits.bit_count()
    if n>4_000_000 or q.TOTAL+n>q.CAP:
        raise q.Refused(('literal_control_actual_pair_visits',q.TOTAL,n,q.CAP))
    result=ZERO
    first=None
    for lab,v,bits in plans:
        while bits:
            q.work('literal_compatible_spoke_pair')
            low=bits&-bits
            rlab,w=right[low.bit_length()-1]
            bits^=low
            value=q.mul(v,w)
            for i,t in enumerate(spokes):
                value=q.mul(value,t[lab[i],rlab[i]])
            if first is None:
                first=value
            result=q.add(result,value)
    assert result==expected.get(key,ZERO) and first is not None
    q.rss()
    out=dict(ray_key=key,left_nonzero=len(l),right_nonzero=len(r),nonzero_literal_pairs=n,
        exact_numerator=result,adverse_single_path_flip=q.add(result,q.mul((-2,0),first)),
        work=dict(q.WORK),charged=q.TOTAL,cap=q.CAP,numeric_pair_cap=4_000_000,sampled_peak_rss=q.PEAK)
    (D/f'raw-control-{ix}.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main(int(sys.argv[1]))
