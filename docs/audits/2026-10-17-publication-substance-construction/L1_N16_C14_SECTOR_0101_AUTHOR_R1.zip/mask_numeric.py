"""Admitted exact numeric mask join of coalesced signed half response pairs."""
from collections import defaultdict
from pathlib import Path
import json
import separate as g

D=Path(__file__).parent

def main():
    g.rss()
    left={}
    right={}
    for side,j,rows in g.read(D/'coalesced-mask-half-rays.jsonl'):
        if not side:
            left[j]=rows
        else:
            d=defaultdict(list)
            for k,z in rows:
                d[k[0]].append((k,z))
            right[j]=d
    out={}
    visits=0
    for (i,j),w in g.read(D/'coalesced-mask-half-pairs.jsonl'):
        for (mask,a,b,f),x in left[i]:
            for (other,c,d,e),z in right[j].get(255^mask,()):
                g.charge('numeric_coalesced_half_product')
                visits+=1
                k=(a,b,c,d,e,f)
                if k not in out:
                    g.reserve('numeric_weighted_mask_key')
                out[k]=g.add(out.get(k,0),g.mul(w,g.mul(x,g.mul(z,g.cross(mask,other)))))
    assert visits==3293184
    count=0
    with (D/'weighted-mask-amplitude-0101.jsonl').open('wb') as f:
        for k,z in sorted(out.items()):
            if z:
                g.charge('serialize_mask_row')
                g.emit(f,[k,z])
                count+=1
    g.rss()
    result=dict(exact_products=visits,nonzero_mask_rows=count,zero_mask_rows=len(out)-count,
            work=dict(g.OPS),meters=dict(g.M),caps=g.CAPS,sampled_peak_rss=g.RSS)
    (D/'mask-numeric.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
