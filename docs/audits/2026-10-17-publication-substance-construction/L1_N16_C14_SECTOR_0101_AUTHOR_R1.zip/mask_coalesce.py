"""Exact half-response quotient before the mixed/mixed exterior join."""
from functools import cache
from math import gcd
from pathlib import Path
import json
import separate as g

D=Path(__file__).parent

def main():
    g.rss()
    _,masks,stats=g.ray_split()
    g.INDEX=g.index(masks)
    env=[(tuple(k),w) for k,w in g.read(g.CORE/'coalesced-environment.jsonl')]
    half=[{},{}]
    rays=[{},{}]

    @cache
    def primitive(side,key):
        table=(g.left if side==0 else g.right)(*key)
        if not table:
            return None
        order=sorted(table)
        c=gcd(*(table[k] for k in order))
        if table[order[0]]<0:
            c=-c
        v=tuple((k,table[k]//c) for k in order)
        assert {k:g.mul(w,c) for k,w in v}==table
        if v not in rays[side]:
            g.reserve('half_response_id')
            ix=len(rays[side])
            rays[side][v]=ix
            half[side][ix]=dict(v)
        return rays[side][v],c

    cross={}
    nonempty=0
    for (r4,r12,r3,r10,r9,m1,m2),w in env:
        g.charge('group_exact_exterior_boundary')
        l=primitive(0,(r4,r12,r10,r9))
        r=primitive(1,(r3,m1,m2))
        if not l or not r:
            continue
        nonempty+=1
        key=(l[0],r[0])
        if key not in cross:
            g.reserve('coalesced_half_pair')
        cross[key]=g.add(cross.get(key,0),g.mul(w,g.mul(l[1],r[1])))
    cross={k:v for k,v in cross.items() if v}
    paircount=0
    direct_pair_count=0
    for (r4,r12,r3,r10,r9,m1,m2),w in env:
        g.charge('direct_schedule_preflight')
        # Read exact candidate cardinality only, without numeric expansion.
        l=primitive(0,(r4,r12,r10,r9))
        r=primitive(1,(r3,m1,m2))
        if not l or not r:
            continue
        a,b=half[0][l[0]],half[1][r[0]]
        pair_count=gross_count(a,b)
        direct_pair_count+=pair_count
    for (i,j),w in cross.items():
        g.charge('coalesced_pair_preflight')
        paircount+=gross_count(half[0][i],half[1][j])
    with (D/'coalesced-mask-half-rays.jsonl').open('wb') as f:
        for i,t in enumerate(half):
            for j,v in t.items():
                g.emit(f,[i,j,sorted(v.items())])
    with (D/'coalesced-mask-half-pairs.jsonl').open('wb') as f:
        for k,w in sorted(cross.items()):
            g.emit(f,[k,w])
    controls=g.fixed_checks(env)
    admission=dict(source_environment_rows=len(env),nonempty_half_environment_rows=nonempty,
        mask_ray_split=stats,exact_half_response_counts=list(map(len,half)),
        nonzero_coalesced_half_pairs=len(cross),direct_prospective_pair_products=direct_pair_count,
        coalesced_prospective_pair_products=paircount,preflight_work=dict(g.OPS),
        preflight_meters=dict(g.M),caps=g.CAPS,fixed_controls=controls)
    (D/'mask-admission.json').write_text(json.dumps(admission,indent=2)+'\n')
    print(json.dumps(admission,indent=2))

@cache
def mask_counts(keys):
    d={}
    for k in keys:
        d[k[0]]=d.get(k[0],0)+1
    return d

def gross_count(a,b):
    c=mask_counts(tuple(a))
    d=mask_counts(tuple(b))
    return sum(n*d.get(255^k,0) for k,n in c.items())

if __name__=='__main__':
    main()
