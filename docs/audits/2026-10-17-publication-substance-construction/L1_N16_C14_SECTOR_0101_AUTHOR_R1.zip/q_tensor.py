"""Exact sparse per-ray paired trace tensor and four-axis basis transform."""
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import permutations,product
from math import gcd,prod
from pathlib import Path
import json
import qcontract as q

D=Path(__file__).parent
CORE=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
AGGREGATE_CAP=40_000_000
RAY_CAP=4_000_000
TABLE_CAP=200_000
ZERO=(0,0)

def from_spokes():
    matrices=[{},{}]
    for b in q.read(D/'spoke-bases.jsonl'):
        n=b['name']
        for side,key in ((0,'column'),(1,'row')):
            t=defaultdict(list)
            for a,c,z in b[key]:
                i,j=(a,c) if side==0 else (c,a)
                t[i].append((j,q.integral(q.dec(z))))
            matrices[side][n]=t
    return matrices

def indexed(data):
    out=[]
    for sides in data:
        pair=[]
        for _,flat in sides:
            t=defaultdict(list)
            for a,b,z in flat:
                q.work('trace_residual_index')
                t[b].append((a,z))
            pair.append(t)
        out.append(pair)
    return out

def estimates(ts,mat,raw,selected,mids,mask):
    out=[]
    for side,name in enumerate(('left','right')):
        ids=sorted({k[0] for k in selected[name]})
        for j in ids:
            f=raw['E' if side==0 else 'F'][j]
            c=sum(len(ts[side][0].get((a,c),()))*len(ts[side][1].get((b,d),()))
                  for a,b,c,d in f)
            def axis_bound(order):
                sizes=[16]*4
                values=[]
                for i in order:
                    m=mat[side][q.SPK[i]]
                    entries=sum(len(v) for v in m.values())
                    values.append(entries*prod(v for k,v in enumerate(sizes) if k!=i))
                    sizes[i]=1+max(j for r in m.values() for j,z in r)
                return sum(values),order,values
            p,order,bound=min(axis_bound(order) for order in permutations(range(4)))
            n=c+p
            out.append(dict(side=name,ray=j,source_pair_products=c,
                            axis_order=order,transform_upper_bounds=bound,prospective=n))
    combine=sum(prod(len(mids[n][j]) for n,j in zip(q.SPK,k[:4],strict=True)) for k,w in mask)
    return out,combine

def transforms(ts,mat,raw,selected,plan):
    out=[{},{}]
    for receipt in plan:
        name,j=receipt['side'],receipt['ray']
        side=int(name=='right')
        t={}
        before=q.TOTAL
        for (a,b,c,d),w in raw['E' if side==0 else 'F'][j].items():
            for (u,z),(v,y) in product(ts[side][0].get((a,c),()),ts[side][1].get((b,d),())):
                q.work('ray_source_trace_pair')
                key=tuple(4*x+y for x,y in zip(u,v,strict=True))
                if key not in t and len(t)==TABLE_CAP:
                    raise q.Refused(('prospective_table',name,j,len(t)+1,TABLE_CAP))
                t[key]=q.add(t.get(key,ZERO),q.mul(w,q.mul(z,y)))
        t={k:z for k,z in t.items() if z!=ZERO}
        rows=[len(t)]
        for i in receipt["axis_order"]:
            n=q.SPK[i]
            nx={}
            for k,z in t.items():
                for b,w in mat[side][n].get(k[i],()):
                    q.work('ray_axis_basis_transform')
                    key=(*k[:i],b,*k[i+1:])
                    if key not in nx and len(nx)==TABLE_CAP:
                        raise q.Refused(('prospective_table',name,j,i,len(nx)+1,TABLE_CAP))
                    nx[key]=q.add(nx.get(key,ZERO),q.mul(z,w))
            t={k:z for k,z in nx.items() if z!=ZERO}
            rows.append(len(t))
        for e,*k in selected[name]:
            if e==j and tuple(k) in t:
                out[side][(j,*k)]=t[tuple(k)]
        receipt['actual_work']=q.TOTAL-before
        receipt['nonzero_rows_by_stage']=rows
        assert receipt['actual_work']<=receipt['prospective']<=RAY_CAP
    return out

def main():
    q.CAP=AGGREGATE_CAP
    q.rss()
    raw,source=q.source()
    data=q.traces(source)
    opts,mids=q.bases()
    mat=from_spokes()
    ts=indexed(data)
    selected=json.loads((D/'selected-basis-keys.json').read_text())
    rawmask=[(tuple(k),z) for k,z in q.read(D/'weighted-mask-amplitude-0101.jsonl')]
    scale=gcd(*(z for k,z in rawmask))
    mask=[(k,z//scale) for k,z in rawmask]
    plan,combine=estimates(ts,mat,raw,selected,mids,mask)
    total=q.TOTAL+sum(r['prospective'] for r in plan)+combine
    admission=dict(ray_cap=RAY_CAP,aggregate_cap=AGGREGATE_CAP,prospective_aggregate=total,
                   initial_charged=q.TOTAL,admitted_ray_partitions=plan,middle_product_count=combine)
    (D/'tensor-admission.json').write_text(json.dumps(admission,indent=2)+'\n')
    print('prospective aggregate',total,'max ray',max(r['prospective'] for r in plan),flush=True)
    if total>AGGREGATE_CAP or any(r['prospective']>RAY_CAP for r in plan):
        raise q.Refused(('prospective_tensor_schedule',total,AGGREGATE_CAP))
    left,right=transforms(ts,mat,raw,selected,plan)
    numerator=ZERO
    amplitudes={}
    chunks=[]
    offset=0
    while offset<len(mask):
        n=0
        end=offset
        while end<len(mask):
            k=mask[end][0]
            count=prod(len(mids[x][j]) for x,j in zip(q.SPK,k[:4],strict=True))
            if n+count>RAY_CAP:
                break
            n+=count
            end+=1
        assert end>offset
        before=q.TOTAL
        z,table=q.combine(mask[offset:end],mids,left,right)
        assert not (amplitudes.keys()&table.keys()) and q.TOTAL-before==n
        amplitudes.update(table)
        numerator=q.add(numerator,z)
        chunks.append(dict(begin=offset,end_exclusive=end,prospective=n,actual=q.TOTAL-before))
        offset=end
    print('0101 exact numerator',numerator,'nonzero amplitudes',len(amplitudes),flush=True)
    with (D/'q-amplitudes-0101.jsonl').open('w') as f:
        for k,z in sorted(amplitudes.items()):
            print(json.dumps([k,z],separators=(',',':')),file=f)
    with (D/'selected-transforms.jsonl').open('w') as f:
        for n,t in (('left',left),('right',right)):
            for k,z in sorted(t.items()):
                print(json.dumps([n,k,z],separators=(',',':')),file=f)
    den=json.loads((CORE/'graph.json').read_text())['exact_denominator_before_exponential_divisor']
    rat=Fraction(scale*24**5,den*512)
    q.rss()
    out=dict(sector='0101',normalized_interior_scalar_numerator=numerator,mask_numerator_gcd=scale,
        nonzero_selected_transform_rows=[len(left),len(right)],nonzero_q_amplitude_rows=len(amplitudes),
        external_s4_multiplier=24**5,external_row_divisor=512,graph_denominator=den,
        weighted_exact_sector_value=[str(z*rat) for z in numerator],per_ray_chunks=plan,middle_chunks=chunks,
        caps=dict(aggregate_work=AGGREGATE_CAP,ray_work=RAY_CAP,rows_per_table=TABLE_CAP,
                  sampled_rss=q.RSS_CAP,scalar=q.INT_CAP),
        total_work=q.TOTAL,work=dict(q.WORK),sampled_peak_rss=q.PEAK,
        other_sectors_evaluated=False,full_representative_evaluated=False)
    (D/'q-result.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
