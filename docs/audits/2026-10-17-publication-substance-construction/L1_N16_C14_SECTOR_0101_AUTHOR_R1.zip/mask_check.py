"""Direct original environment-weighted mask coefficients, no half quotient."""
from functools import cache
from pathlib import Path
import json
import separate as g

D=Path(__file__).parent

def main():
    g.rss()
    _,masks,_=g.ray_split()
    g.INDEX=g.index(masks)
    exact={tuple(k):w for k,w in g.read(D/'weighted-mask-amplitude-0101.jsonl')}
    witness=sorted(exact)[::1023][:4]
    totals=[0]*len(witness)
    live=[0]*len(witness)
    first=[None]*len(witness)
    @cache
    def sub(side,key,ray):
        table=(g.left if side==0 else g.right)(*key)
        return {row[0]:z for row,z in table.items() if row[1:]==ray}
    for (r4,r12,r3,r10,r9,m1,m2),w in g.read(g.CORE/'coalesced-environment.jsonl'):
        for j,(a,b,c,d,e,f) in enumerate(witness):
            g.charge('direct_uncoalesced_mask_boundary')
            left=sub(0,(r4,r12,r10,r9),(a,b,f))
            right=sub(1,(r3,m1,m2),(c,d,e))
            for m,z in left.items():
                g.charge('direct_uncoalesced_mask_join')
                n=255^m
                if n not in right:
                    continue
                value=g.mul(w,g.mul(z,g.mul(right[n],g.cross(m,n))))
                totals[j]=g.add(totals[j],value)
                live[j]+=1
                if first[j] is None:
                    first[j]=value
    assert totals==[exact[k] for k in witness] and all(live)
    g.rss()
    out=dict(controls=[dict(key=k,exact_numerator=totals[i],
        direct_nonzero_products=live[i],adverse_one_product=g.add(totals[i],g.mul(-2,first[i])))
        for i,k in enumerate(witness)],work=dict(g.OPS),meters=dict(g.M),caps=g.CAPS,sampled_rss=g.RSS)
    (D/'mask-check.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
