"""Exact Gaussian matrix basis, projected spoke requirements, no trace sum."""
from collections import Counter
from itertools import product
from pathlib import Path
import json,resource
import sympy as s

D=Path(__file__).parent
MAX_VISITS=4_000_000
VISITS=0
def charge(n=1):
    global VISITS
    if VISITS+n>MAX_VISITS:
        raise RuntimeError(('prospective_basis_visit',VISITS+n,MAX_VISITS))
    VISITS+=n

def enc(z):
    a,b=z.expand(complex=True).as_real_imag()
    return [int(a.p),int(a.q),int(b.p),int(b.q)]

def rows(matrix):
    return [[i,j,enc(matrix[i,j])] for i in range(matrix.rows) for j in range(matrix.cols) if matrix[i,j]!=0]

def main():
    data={name:(labels,table) for name,labels,table in map(json.loads,(D/'interior-rays.jsonl').read_text().splitlines())}
    support={}
    details={}
    with (D/'spoke-bases.jsonl').open('w') as f:
        for name in 'ABCD':
            labels,table=data[name]
            mat={}
            for j,v in table:
                m=s.zeros(16)
                for (a,b,c,d),(x,y) in v:
                    charge()
                    p,q=4*a+b,4*c+d
                    if name in 'CD':
                        p,q=q,p
                    m[p,q]=x+s.I*y
                mat[j]=m
            col=s.Matrix.hstack(*mat.values()).columnspace()
            row=s.Matrix.vstack(*mat.values()).T.columnspace()
            C=s.Matrix.hstack(*col)
            R=s.Matrix.hstack(*row).T
            pr=list(C.T.rref()[1]);pc=list(R.rref()[1])
            ci=C[pr,:].inv()
            ri=R[:,pc].inv()
            assert pr and pc
            middle={}
            support[name]={}
            for j,m in mat.items():
                x=ci*m[pr,pc]*ri
                assert (C*x*R-m).applyfunc(s.simplify).is_zero_matrix
                middle[j]=rows(x)
                support[name][j]=[(i,k) for i,k,_ in middle[j]]
            record=dict(name=name,source_order=labels,transposed=name in 'CD',column=rows(C),
                        row=rows(R),coordinates=middle)
            print(json.dumps(record,separators=(',',':')),file=f)
            details[name]=dict(common_column_rank=len(pr),common_row_rank=len(pc),
                 encoded_ray_support_histogram=dict(Counter(map(len,middle.values()))),
                 column_nonzero=len(record['column']),row_nonzero=len(record['row']))
    left=set();right=set();visits=0
    for key,z in map(json.loads,(D/'weighted-mask-amplitude-0101.jsonl').read_text().splitlines()):
        a,b,c,d,e,f=key
        for parts in product(*(support[name][i] for name,i in zip('ABCD',(a,b,c,d),strict=True))):
            charge()
            visits+=1
            left.add((e,*(x for x,y in parts)))
            right.add((f,*(y for x,y in parts)))
    (D/'selected-basis-keys.json').write_text(json.dumps(dict(left=sorted(left),right=sorted(right)))+'\n')
    result=dict(exact_basis_verified=True,spokes=details,spoke_pair_terms=visits,
                unique_left_trace_basis_keys=len(left),unique_right_trace_basis_keys=len(right),
                charged_visits=VISITS,cap=MAX_VISITS,trace_amplitudes_evaluated=False,
                sampled_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    (D/'basis-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
