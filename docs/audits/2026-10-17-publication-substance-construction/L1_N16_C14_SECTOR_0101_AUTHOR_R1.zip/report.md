# Exact LRLR sector of original N16 c14

The pinned authority is original periodic closed source_C at clean
primary 27012c18fa374e8341e124b510abbedeedb18d29. This is sector
0101 of the original zero-centered (01,01,23,23) row, with
chirality L, R, L, R for original occurrences 0, 1, 2, 3.
Inside each fixed chirality the coordinate index is 0–3. The
original occurrence and directed anchor labels stay distinct.
The exact sector contribution is
5065164171/4611686018427387904 + 0i, with original divisor 512
and the separate 24^5 multiplier applied once.

## Original source and signed mask quotient

The eleven original signed joins run on the actual 0101 factors.
The original tile and mask-bridge unit predicates are reconstructed
exactly from source supports. The recorded source/partial factor
run uses 1,997,159 charged visits and preserves the signed output
factor tables.

Both mixed exterior halves are larger than in the earlier sectors.
The exact direct mask schedule would visit 43,024,384 products,
above the admitted 4,000,000 cap. Each half response is normalized
by its signed integer gcd, and every original response reconstructs
exactly. There are 25 left and 1,024 right half response rays and
2,980 nonzero coalesced signed environment pairs. The preflight
uses 1,261,802 work visits. Its numerical continuation visits
exactly 3,293,184 products and coalesces to 4,096 nonzero six-ray
weights in 3,301,309 charged visits.

Four complete fixed mask boundary controls match literal rank-zero
projection. Separately, four entire weighted mask coefficients
were recomputed over the original 178,150 environment rows without
using the normalized half response quotient. All agree with the
stored weighted masks, and reversing one contributing product
changes each. This separate comparison uses 1,615,753 visits.

## Exact interior tensor schedule and controls

All 64 original spoke matrices reconstruct in their exact Gaussian
bases. Enumerating the selected keys via all middle products hit
the 4,000,001 planning guard. The replacement intersects bitsets
of actual mask-ray rows and gives 14,848 selected basis keys on
each trace half in 550,528 charged visits. This is exact projected
support. Sampled direct product checks also agree with it.

The inherited 24M tensor aggregate admission refused at the
38,610,962 conservative bound. The admitted schedule changes the
axis order by minimizing the exact dense-support bound over the
24 permutations and uses a declared 40M aggregate cap. It
preflights at 30,943,250 visits with largest prospective ray
partition 800,768. Actual total is 12,336,146 visits with maximum
single-ray work 219,296 and largest nonzero table 9,216 rows.
The two exact middle-product partitions are 3,999,456 and
1,308,960 visits. No numerical partition exceeds 4,000,000.
Normalized scalar payload is checked at 127 bits. The sampled
process RSS peaks at 39,616,512 bytes under the sampled 384 MiB
guard. All ray and combination receipts are recorded.

Serialized readback independently reconstructs the 64 matrices,
recomputes all 5,308,416 middle products and combines all 4,096
signed weighted terms. It finds 962,560 nonzero middle paths
and reproduces the exact sector value. Two separate exact
original-spoke controls use the literal original trace rows and
conditioned bitset intersection, with no Gaussian basis factors.
Each visits 2,876,416 compatible signed spoke products. The
numerators are +1,460,288,880,640 and -1,460,288,880,640.
Reversing one contributing path changes them to
1,460,255,326,208 and -1,460,297,268,248 respectively.
The first original-control aggregate preflight refused at
4,316,522 visits under a 4M cap. Each successful control uses
a prospectively declared 6M aggregate cap and separate 4M
numeric-product cap, with 4,316,522 actual charged visits.

## Provisional whole-c14 arithmetic

The separately frozen source symmetry review supplies orbit
weights 2, 8, 2, 4 for exact representatives 0000, 0001, 0011,
0101, and the factor 48 for 16 translations times three axis
arrangements. The signed sum at the canonical arrangement is
102294681665067/1152921504606846976. Multiplying by 48 gives
the provisional full c14 arithmetic
306884044995201/72057594037927936 + 0i. Divisor 512 is already
included in each sector. This arithmetic awaits independent
whole-coefficient acceptance. It does not evaluate c0, the
complete denominator or the normalized observable.
