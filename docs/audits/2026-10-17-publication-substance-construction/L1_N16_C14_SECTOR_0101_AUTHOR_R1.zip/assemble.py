"""Provisional exact c14 arithmetic from frozen sector values and reviewed weights."""
from fractions import Fraction
from pathlib import Path
import json

D=Path(__file__).parent
sources={
 '0000':Path('/tmp/publication-c14-core-interior-r1.mdHnLO/q-result.json'),
 '0001':Path('/tmp/publication-c14-mixed-sector-r1.SsiNEZ/q-result.json'),
 '0011':Path('/tmp/publication-c14-sector0011-r1.MmSbSs/q-result.json'),
 '0101':D/'q-result.json',
}
weights={'0000':2,'0001':8,'0011':2,'0101':4}
review=Path('/tmp/publication-c14-sector-symmetry-independent.T8KFY4/review.md')
rows=[]
for sector,p in sources.items():
    result=json.loads(p.read_text())
    assert result['sector']==sector
    assert result['external_s4_multiplier']==24**5 and result['external_row_divisor']==512
    real,imag=map(Fraction,result['weighted_exact_sector_value'])
    assert imag==0
    w=weights[sector]
    rows.append(dict(sector=sector,signed_sector_value=str(real),orbit_multiplicity=w,
        signed_weighted_sector_value=str(w*real),sector_evidence=str(p)))
assert sum(weights.values())==16
scalar=sum(Fraction(x['signed_weighted_sector_value']) for x in rows)
c14=scalar*48
assert scalar==Fraction(102294681665067,1152921504606846976)
assert c14==Fraction(306884044995201,72057594037927936)
out=dict(status='provisional arithmetic pending independent whole-coefficient acceptance',
    symmetry_review=str(review),sector_rows=rows,canonical_zero_root_arrangement=str(scalar),
    translations=16,axis_arrangements=3,translation_arrangement_multiplier=48,
    provisional_c14=str(c14),imaginary_part='0',
    divisor_512='already included in each sector, not applied again')
(D/'provisional-c14.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
