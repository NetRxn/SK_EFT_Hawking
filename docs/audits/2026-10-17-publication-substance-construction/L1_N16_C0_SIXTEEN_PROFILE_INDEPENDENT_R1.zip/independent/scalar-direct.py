from pathlib import Path
from math import factorial,prod
from fractions import Fraction as F
from contextlib import redirect_stdout
from io import StringIO

source=Path('CHAIN/chain.py').read_text().split('\nrows=roster(',1)[0]
scope={'__name__':'independent_scalar'}
exec(source,scope)
for a,b in ((int(q[0]),int(q[1])) for q in (l.split() for l in Path('reviewed-pairs.tsv').open()) if q[-1]=='scalar-fixed'):
    occ=scope['occupancy'](a)+scope['occupancy'](b)
    n=[t for row in occ for t in row]
    assert n.count(2)==16 and set(n)=={0,2}
    with redirect_stdout(StringIO()):
        x=scope['value'](a,False)
        y=scope['value'](b,False)
    assert (2**16)==prod(factorial(t) for t in n)
    val=x*y
    expected=F(next(t.split()[2] for t in Path(f'replay-{a}-{b}-0.out').read_text().splitlines()
                    if t.startswith('EXACT 0 ')))
    assert val==expected
    print(a,b,x,y,'scalar fixed value',val)
