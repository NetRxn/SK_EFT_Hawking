# L1 independent odd-root pilot intake

The signed coefficient and weight agree on exact independent replay.
Author science and its evidence are pinned at fc38ab990. The sole
continuity authority delta was the operator-directed disposition-map
refactor e06b53f49. The old map preserved in the repo history file is
byte-identical to the independently pinned source. Lead reconciliation
issued and checked continuity revision r2 before this intake.

Use each reviewer command in independent/REVIEW.md to reproduce the full
signed coefficient. published-base.tsv equals the preceding independently
accepted residual from L1_N16_C0_SHARED_EDGE_ONE_ZERO_R1.zip. From this
root run python3 check-pilot-residual.py independent/reviewed-exact.tsv.
The only removed row is the weight-96 pilot. block-remaining.tsv is the
new exact residual.

The scaling/ data are author preparation. The screen uses the corrected
joint-center constraints and existing necessary local representation
projection. It samples the first eight representatives of each of
the 12 largest remaining odd/shared connector-shape groups. Exactly
72 of 96 bounded support searches complete, while 24 reach the 1,024
branch-node cap. This is a deterministic stress sample, with no population
inference or signed coefficient acceptance. Four chosen width trials
span four shapes and require 4, 28, 96, and 62 supported assignments.
The latter two test scalar forced roots as well as distinct connector
shapes. All 384 associated labels remain in the residual. The measured
join speed of the accepted pilot omits factor generation, which must be
measured independently before planning a broad batch.

For these support scripts, restore the earlier one-or-zero archive
as FROZEN and the earlier author projection sandbox as PRIOR. From
scaling/ run:

```sh
python3 screen.py "$FROZEN/preflight" "$PRIOR" "$FROZEN" > screen.out
python3 next_cases.py "$FROZEN/preflight" "$PRIOR" "$FROZEN" > next-cases.out
python3 prepare_support.py "$FROZEN/preflight" "$PRIOR" "$FROZEN" > next-prep.out
```

Use the frozen legacy preflight only to load its original projection
functions. The withdrawn one-chirality parity screen is never called.
