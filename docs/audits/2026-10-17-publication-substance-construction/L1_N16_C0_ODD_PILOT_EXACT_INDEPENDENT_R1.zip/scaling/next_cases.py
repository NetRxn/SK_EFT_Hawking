from pathlib import Path
from collections import Counter

source=Path('screen.py').read_text()
exec(source[:source.index('root=Path(source)')])
rows=[(103607566400,1256282652690), (103607566400,1261652672530),
      (140684411270,558347329670), (155950080585,580896423965)]
allowed={(int(a),int(b)):int(w) for a,b,w in (r.split() for r in Path(frozen,'block-remaining.tsv').read_text().splitlines())}
for a,b in rows:
    result=solve_pilot(a,b)
    assert result[0]=='EXACT_SUPPORT' and result[2]>0
    print(a,b,allowed[a,b],*result)
