from pathlib import Path
from itertools import product

source=Path('screen.py').read_text()
s=source[:source.index('root=Path(source)')]
s=s.replace("    return ('EXACT_SUPPORT',checked,len(states),maxspin,maxpower,tuple(forced))",
            "    return states,checked")
exec(s)
r=Path('candidate-support')
r.mkdir()
all_edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
for line in Path('next-cases.out').read_text().splitlines():
    a,b,weight=map(int,line.split()[:3])
    states,checked=solve_pilot(a,b)
    assert states
    group=r/f'{a}-{b}'
    group.mkdir()
    loads=[profile(c)[2] for c in (a,b)]
    root_channels=set()
    anchor_shapes=set()
    with (group/'states.tsv').open('w') as channel_file, (group/'anchor-plan.tsv').open('w') as anchor_file:
        for i,state in enumerate(states):
            for (t,x,k),(l,h) in sorted(state.items()):
                if l or h:print(i,t,x,k,l,h,sep='\t',file=channel_file)
            for t,code in enumerate((a,b)):
                for x,row in enumerate(decode(code)):
                    for k,n in enumerate(row):
                        if n: root_channels.add((n,*state.get((t,x,k),(0,0))))
            for t,load in enumerate(loads):
                for u,v,k in all_edges:
                    degree=sum(load.get((u,v,k),(0,0)))
                    for x in (u,v):
                        shape=(degree,*state.get((t,x,k),(0,0)),*state.get((1-t,x,k),(0,0)))
                        print(i,t,x,k,*shape,sep='\t',file=anchor_file)
                        anchor_shapes.add(shape)
    (group/'root-channels.tsv').write_text(''.join('\t'.join(map(str,ch))+'\n' for ch in sorted(root_channels)))
    print(a,b,weight,'states',len(states),'branch nodes',checked,
          'root channels',len(root_channels),'anchor shapes',len(anchor_shapes))
