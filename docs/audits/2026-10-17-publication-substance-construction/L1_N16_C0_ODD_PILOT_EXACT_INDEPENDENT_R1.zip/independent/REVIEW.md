# Independent exact review of the odd-root pilot

**ACCEPT** the original representative `(103607566400,1256282136720)`
at weight 96. The independently reproduced real signed coefficient is
`20706441900927168861083984375/1267650600228229401496703205376`.
Its weighted contribution is
`62119325702781506583251953125/39614081257132168796771975168`.
Removing the one verified residual row leaves **9,643 orbits and
830,823 labels**. The full original c0 sign, value and nonvanishing
remain open.

## Pinned inputs and coverage

The primary continuity snapshot initially checked fresh against
checkpoint `fc38ab9907f44b70d13b25003ecdcb1ca2625213`. The clean source
for literal checks is candidate `51e7c745e`. The complete author
quotient manifest matches the version stored in the pinned checkpoint
archive and verified with the legacy anchor, generated signed factors,
and preceding independent zero-pair manifests. I extracted the
already accepted exact residual and verified unique pilot membership
at the original weight 96.

At final readback the sole continuity delta was `authority[6]`, the
active disposition map, after the lead's planned documentation edit.
The diff from `fc38ab990` to `e06b53f49` contains only the revised
active map and the new history file. The latter equals the pinned
active-map bytes saved as `pinned-direction-map.md`, SHA-256
`6b3907317995734c97258d27d0bc35c35c1aaa7e2996ba90ad3a35957738cfca`.
The numerical review is against the pinned inputs. The lead retains
responsibility for continuity reconciliation before intake.

The preceding independent receipt establishes 14 exact-zero pairs
across the 36 corrected channels. The four open pairs map exactly to
legacy rows 5, 6, 7 and 8. The accepted gamma3 exchange identifies the
two signed coefficients inside each pair, and the preceding corrected
support covers all necessary channels. This review independently
evaluates one representative of each remaining pair. The complete
pilot is twice the sum of these four real values.

## Exact full-network reduction

Each original case is rebuilt as 72 site, spatial and temporal
factors with complete representation and coframe mask/word wires.
The previously verified closed-word convention determines the
orientation on every matrix column pair. Every nontrivial wire
appears twice before processing, and the initial network cardinalities
match the original frozen receipts. Exact row denominators are
absorbed into a common positive integer scale for each factor.
The independent replay reuses the frozen exact local values and
does not regenerate the entire signed local-factor pipeline.

For two factors A(x,u), B(x,v), the tuple x lists **all** their shared
wire values. Distinct slices x may have the same primitive Gaussian
coefficient array after dividing by the integer gcd of all real and
imaginary coordinates and fixing a Gaussian phase. The independent
orientation puts the first coefficient in the half-open first
quadrant. Reconstruction checks `A(x,u)=g_x P_j(u)` for every row,
where g_x is a Gaussian unit times the positive gcd. Exact equality
compares the full sparse tuple-indexed arrays. The new left factor
stores one P_j. The new right factor stores
`sum_(x in j) g_x B(x,v)`. Summing their product over j produces
the original sum over x for every open u,v. Multiplying both original
denominators preserves the normalization. Rows with no matching
bond support contribute zero. The operation can retain unmatched
proportionality classes without affecting exactness.

I used an independent tuple-key representation, a different Gaussian
unit convention, and a separate join scheduler. There is no dependency
on the author's intermediate frontier or numerical output. A separate
direct check compares every output coefficient, with all external
indices open, for 129 small exact controls including nontrivial
Gaussian phases, unmatched two-index bonds, and exact cancellation.

## Original source normalization and signs

I assembled the original canonical coframe blocks on both edge owners
and all four internal components. With their explicit quarter removed,
all 512 source rows match the accepted table used to prepare the
frozen factors. Unnormalized coframe products therefore require the
quarter once per original coframe occurrence. Directly combining the
canonical original EHC action factors in all ordered exterior slots
gives the time-first curvature component and its world epsilon sign
with no additional action quarter. The two curvature orders and
two complementary coframe orders contribute the compensating four
terms. All 768 canonical source controls across the 16 sites and three
spatial axes confirm the folding, including cancellation of diagonal
internal components. The site Grassmann products use the literal
sorted edge order already checked in the preceding signed factor review.

The decoded original powers consist of thirty zeros, ten ones, two
twos and six threes. Their sum is 32 and their original factorial
product is `(2!)²(3!)⁶=186624`. Each EHC insertion uses two coframes,
giving exactly 64 quarter factors and the additional divisor 4⁶⁴.
The original occupancies by spatial axis are (12,0,4) and (4,0,12)
for the two layers. The epsilon product is positive in each. I
independently checked the fixed cross-site wedge parity from all
edge endpoint degrees. It is even in each layer, and 64 exact
Grassmann layout controls per layer reproduce the decomposition
into local signs and cross-site parity. Permuting complete eight-slot
site tops across the two layers contributes an even permutation.

## Exact results and measured resources

| Legacy case | Corrected pair | Source-normalized coefficient |
| --- | --- | --- |
| 5 | 0, 32 | 5096117406084947496826171875/633825300114114700748351602688 |
| 6 | 1, 33 | 37106492954534316650390625/1267650600228229401496703205376 |
| 7 | 2, 34 | 123430232354246272705078125/1267650600228229401496703205376 |
| 8 | 3, 35 | 898825969817695068359375/2535301200456458802993406410752 |

All four imaginary parts vanish. The guarded independent schedule
uses at most 58,752 rows in one factor, 784 matched products in a
join, and 7,241 matched products in one full channel. Initial
network support reaches 367,866 rows. Quotient work counts are
separate from these products. The largest scan tally in the
independent replay is 4,294,923, including scans charged for
histograms, primitive slice inspection and peer accumulation.
The checker enforces work and integer height caps before joins
and peer coefficient accumulation, charges scans before executing
their passes, and guards sparse row insertion. All four cases
complete without refusal on these schedules.

This accepts one original coefficient and its weight, and does not
advance native or publication gates. No repository, manuscript
or Lean state changed during the independent calculation.

## Replay

Scratch expects `OLD` and `SEWN` to point to the previously hashed
legacy anchor and local-factor directories, `INDEPENDENT` to the
earlier independent decoder, `PRIOR` to the accepted zero-pair
review, and `AUTHOR` to the frozen complete author archive.
`prior-coframes.tsv` is the accepted original quarter-stripped
source table. `residual.tsv` comes from the published
`L1_N16_C0_SHARED_EDGE_ONE_ZERO_R1.zip`.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 quotient-control.py > quotient-control.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" normalization.py > normalization.out
for id in 5 6 7 8; do
  PYTHONDONTWRITEBYTECODE=1 python3 replay.py "$id" > "case-$id.out"
done
python3 verify.py > verification.out
shasum -a 256 -c manifest.sha256
```
