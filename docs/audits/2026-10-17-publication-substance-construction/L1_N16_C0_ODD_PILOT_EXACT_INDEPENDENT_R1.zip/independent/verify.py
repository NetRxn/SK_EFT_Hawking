from fractions import Fraction as F
from pathlib import Path

A=103607566400
B=1256282136720
W=96
residual=[tuple(map(int,line.split())) for line in Path('residual.tsv').read_text().splitlines()]
assert len(residual)==len(set(residual))==9644
assert sum(r[2] for r in residual)==830919
assert [r for r in residual if r[:2]==(A,B)]==[(A,B,W)]
rows=[line.split()[:4] for line in Path('PRIOR/reviewed-pairs.tsv').read_text().splitlines()]
assert len(rows)==18 and {int(v) for r in rows for v in r[:2]}==set(range(36))
zero=[r for r in rows if r[3]=='ZERO']
nonzero=[r for r in rows if r[3]=='OPEN']
assert len(zero)==14 and {tuple(map(int,r[:3])) for r in nonzero}=={(0,32,5),(1,33,6),(2,34,7),(3,35,8)}
original={}
for i in range(5,9):
    fields=Path(f'case-{i}.out').read_text().splitlines()[-1].split()
    assert fields[:2]==['EXACT',str(i)]
    assert F(fields[2])>0
    original[i]=F(fields[2])
author=Path('AUTHOR/pilot-value.out').read_text().splitlines()
assert {int(i):F(x) for i,x,*_ in (l.split() for l in author[:4])}==original
total=2*sum(original.values())
assert total==F(author[-2].split()[-1])
assert W*total==F(author[-1].split()[-1])
rest=[r for r in residual if r!=(A,B,W)]
assert len(rest)==9643 and sum(w for a,b,w in rest)==830823
print('checked original legacy values',*[str(v) for v in original.values()])
print('all complete pairs zero/nonzero',len(zero),len(nonzero))
print('positive signed pilot value',total)
print('weighted original value',W*total)
print('residual after exactly one subtraction',len(rest),sum(w for a,b,w in rest))
Path('reviewed-exact.tsv').write_text(f'{A}\t{B}\t{W}\t{total}\n')
