# Complementary tuple 0 outer cases 27 and 29

Reconstruct the original selector-1 parent from the source pins in each
review. Apply the distinct original outer cut, then follow the primary and
rescue receipts and compare the saved hashes in frontiers.sha256. Recreate
the nine inner coordinates and use the eight disjoint shards for each
of triangles 5 and 6. The author and independent reviewer scripts record
the distinct contraction orders. Use only trusted serialized inputs.

Compare preceding-twenty-eight.tsv with twenty-eight-term-retally.tsv from
the preceding committed archive. Run python3 verify-and-retally.py to
reconstruct the eighteen signed values and the exact thirty-term retally.
Cases 27 and 29 are the additions. Their terminal values apply only to the
specified complementary child. The sibling diagonal, full profile and
physical susceptibility remain outside this result.
