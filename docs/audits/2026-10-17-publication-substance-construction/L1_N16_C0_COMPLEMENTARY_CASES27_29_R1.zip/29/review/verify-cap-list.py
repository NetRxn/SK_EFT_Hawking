from hashlib import sha256
from pathlib import Path
from re import M,findall

root=Path('inputs')
log=Path('verify-lineage.out').read_text()
caps=findall(r'^PASS frozen cap (\S+) (\S+) (\S+) ([0-9a-f]{64}) open (join|row) cap ',log,M)
assert len({name for _,_,name,_,_ in caps})==len(caps)==15
assert {file.name for file in root.glob('*-cap-*-reduced.pkl')}=={name for _,_,name,_,_ in caps}
for _,_,name,expected,_ in caps:
    assert sha256((root/name).read_bytes()).hexdigest()==expected
print('PASS all 15 author cap checkpoints rebuilt and hashed',
      sum(k=='join' for *_,k in caps),'join and',sum(k=='row' for *_,k in caps),'row')
