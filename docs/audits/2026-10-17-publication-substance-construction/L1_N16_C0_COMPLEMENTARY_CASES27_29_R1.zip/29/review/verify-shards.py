from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from pickle import loads
from re import M, findall, search

from binding import ROOT, TERMINAL_INPUTS
from exact_factors import DEN, overlap, proj

raw_pat=r'raw(?: scalar numerator)? (-?\d+) (?:imaginary )?(-?\d+) factor denominator (\d+)'
value_pat=r'^exact normalized real (\S+) imaginary (\S+)(?: |$)'

def get_exact(text):
    raw=set(findall(raw_pat,text))
    assert len(raw)==1
    real,imag,d=map(int,raw.pop())
    assert d==DEN
    values=findall(value_pat,text,M)
    assert len(values)==1 and tuple(map(Fraction,values[0]))==(Fraction(real,DEN*16*4**64),Fraction(imag,DEN*16*4**64))
    return real,imag

for index in (5,6):
    data=(ROOT/TERMINAL_INPUTS[index]).read_bytes()
    checkpoint=loads(data)
    factors=checkpoint['factors']
    assert len(factors)==3
    ax,rows,_=factors[0]
    ordered=sorted(rows)
    traffic=[]
    for other,coeffs,_ in factors[1:]:
        common=overlap(ax,other)
        counts=Counter(map(proj(other,common),coeffs))
        key=proj(ax,common)
        traffic.append([counts[key(row)] for row in ordered])
    forecast=[min(n,m) for n,m in zip(*traffic,strict=True)]
    assert {path.name for path in ROOT.glob(f'slice-{index}-shard-[0-9]*.out')}=={f'slice-{index}-shard-{k}.out' for k in range(8)}
    terms=[]
    triangles=0
    expected_traffic=sum(forecast)
    for shard in range(8):
        lo,hi=len(ordered)*shard//8,len(ordered)*(shard+1)//8
        log=(ROOT/f'slice-{index}-shard-{shard}.out').read_text()
        assert f'left row interval {lo} {hi} of {len(ordered)} shard {shard} of 8' in log.splitlines()
        assert f"conditioning {checkpoint['conditioning']} label partition {checkpoint['label_partition']}" in log.splitlines()
        triple_count,probes,products=map(int,search(r'^triangle closure (\d+) nonzero-support triples (\d+) bounded probes products (\d+) output rows 1$',log,M).groups())
        assert probes==sum(forecast[lo:hi]) and products==2*triple_count
        triangles+=triple_count
        terms.append(get_exact(log))
        print('PASS author shard',index,shard,'interval',lo,hi,'projected probes',probes,'support triangles',triple_count,flush=True)
    merged=tuple(sum(column) for column in zip(*terms,strict=True))
    report=(ROOT/f'slice-{index}-shard-sum.out').read_text()
    assert f'complete shards 8 left rows {len(ordered)} ' in report
    assert merged==get_exact(report)
    replay=(Path('replays')/f'{index}-replay.out').read_text()
    assert f'input SHA256 {sha256(data).hexdigest()}' in replay.splitlines()
    alternate=search(r'^independent pivot ([12]) probes (\d+) triples (\d+) ',replay,M)
    assert int(alternate[3])==triangles and merged==get_exact(replay)
    print('PASS exact eight-shard cover and raw/normalized sum',index,'author rows',len(ordered),
          'author probes',expected_traffic,'independent pivot',alternate[1],'triangles',triangles,flush=True)
