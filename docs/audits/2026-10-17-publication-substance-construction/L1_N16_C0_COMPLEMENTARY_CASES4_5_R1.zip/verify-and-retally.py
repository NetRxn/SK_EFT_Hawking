from pathlib import Path
from fractions import Fraction
import re
import subprocess
import sys

case_value={}
for line in Path('preceding-four.tsv').read_text().splitlines():
    fields=line.split('	')
    if fields[0].isdigit():
        index,real,imaginary=fields
        case_value[int(index)]=(Fraction(real),Fraction(imaginary))
assert set(case_value)==set(range(4))
for n in (4,5):
    case=Path('author')/str(n)
    a=subprocess.check_output([sys.executable,'sum-shards.py',str(n),'8'],cwd=case,text=True)
    assert a==(case/'exact-shards.out').read_text()
    expect=re.search(r'raw (-?\d+) (-?\d+) factor denominator (\d+)',a,re.M)
    raw=tuple(map(int,expect.groups()))
    reviewer=Path('review')/f'case-{n}'
    for receipt in ('post-replay.out','alternate-replay.out'):
        output=(reviewer/receipt).read_text()
        m=re.search(r'raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)',output)
        assert tuple(map(int,m.groups()))==raw
        scaled=re.search(r'exact normalized real (\S+) imaginary (\S+)',output)
        x,y=map(Fraction,scaled.groups())
        assert (x,y)==(Fraction(raw[0],raw[2]*16*4**64),Fraction(raw[1],raw[2]*16*4**64))
    case_value[n]=x,y
for n,(x,y) in sorted(case_value.items()):
    print(n,x,y,sep='\t')
print('PARTIAL SUM',len(case_value),*map(sum,zip(*case_value.values())),sep='\t')
