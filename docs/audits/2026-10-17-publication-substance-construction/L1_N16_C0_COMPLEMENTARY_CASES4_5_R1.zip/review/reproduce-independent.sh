#!/usr/bin/env bash
set -euo pipefail
root=$PWD
id=$1
author="/private/tmp/l1-c0-sibling-cases2-5.9i0IdU/tuple0-1/$id"
scratch=$(mktemp -d /private/tmp/l1-complementary-review-replay.XXXXXX)
cp -R "$root/archive/checkpoint" "$scratch/"
cp "$root/archive/reduce-label-frontier.py" "$author/join-cap-dense-label-rescue-reduced.pkl" "$scratch/"
cd "$scratch"
python3 -u reduce-label-frontier.py join-cap-dense-label-rescue-reduced.pkl independent > post-reduce.out
cmp post-reduce.out "$root/case-$id/post-reduce.out"
cmp label-independent-reduced-frontier.pkl "$root/case-$id/label-independent-reduced-frontier.pkl"
python3 -u "$root/replay.py" "$id" independent label-independent-reduced-frontier.pkl "$author/exact-shards.out"
python3 -u "$root/replay-alternate.py" "$id" independent label-independent-reduced-frontier.pkl "$author/exact-shards.out"
