#!/usr/bin/env bash
set -euo pipefail
root=$PWD
author=/private/tmp/l1-c0-sibling-cases2-5.9i0IdU/tuple0-1/$1
work="$root/case-$1"
for script in exact-multicut.py reduce-label-frontier.py contract-reduced-label.py checkpoint/quotient.py; do
    cmp "$root/archive/$script" "$author/$script"
    cp "$root/archive/$script" "$work/$script"
done
for script in contract-peer.py peer_pair.py; do
    cmp "/private/tmp/l1-c0-case18.szXdBy/$script" "$author/$script"
    cp "$author/$script" "$work/$script"
done
cd "$work"
python3 -u exact-multicut.py "$root/parent.pkl" input.pkl "$1" > plan.out
cmp input.pkl "$author/input.pkl"
cmp input.roster "$author/input.roster"
cmp plan.out "$author/plan.out"
printf 'PASS complementary case %s cut, roster and plan byte for byte\n' "$1"
python3 -u reduce-label-frontier.py input.pkl primary > reduce.out
cmp reduce.out "$author/reduce.out"
cmp label-primary-reduced-frontier.pkl "$author/label-primary-reduced-frontier.pkl"
status=0
python3 -u contract-reduced-label.py primary > contract.out || status=$?
test "$status" = 2
cmp contract.out "$author/contract.out"
cmp row-cap-physical-slice-dense-label-primary-reduced.pkl "$author/row-cap-physical-slice-dense-label-primary-reduced.pkl"
printf 'PASS primary reduction, row cap (exit 2) and checkpoint byte for byte\n'
python3 -u reduce-label-frontier.py row-cap-physical-slice-dense-label-primary-reduced.pkl rescue > rescue-reduce.out
cmp rescue-reduce.out "$author/rescue-reduce.out"
cmp label-rescue-reduced-frontier.pkl "$author/label-rescue-reduced-frontier.pkl"
status=0
python3 -u contract-peer.py rescue > rescue-contract.out || status=$?
test "$status" = 2
cmp rescue-contract.out "$author/rescue-contract.out"
cmp join-cap-dense-label-rescue-reduced.pkl "$author/join-cap-dense-label-rescue-reduced.pkl"
printf 'PASS rescue reduction, join cap (exit 2) and checkpoint byte for byte\n'
