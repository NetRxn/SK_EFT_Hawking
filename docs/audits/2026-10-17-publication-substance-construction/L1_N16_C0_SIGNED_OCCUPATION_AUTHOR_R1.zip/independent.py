from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
from functools import lru_cache
from math import prod
from pathlib import Path
from src.core.formulas import original_quaternion_haar_moment
from src.vestigial.original_coefficients import ExteriorPolynomial, Polynomial, QComplex

def read(name):
    return [tuple(map(int, row.split())) for row in Path(name).read_text().splitlines()]

src = defaultdict(list)
for center, a, mask, q, re, im in read("coframes.tsv"):
    src[center, a].append((mask, q, QComplex(F(re, 4), F(im, 4))))
edge = {(i, m, j, n): QComplex(F(r, 12288), F(s, 12288))
        for i, m, j, n, r, s in read("edge.tsv")}
pairs = list(combinations(range(5), 2))
pairs = [(i, j - 1) for i, j in pairs]
masks = [m for m in range(256) if m.bit_count() == 4]

# Direct four-factor enumeration on selected original edge entries.
# Coordinate counts and moments are obtained independently of the C++
# quadratic parity buckets or fourth-moment scale.
moment_cache = lru_cache(None)(original_quaternion_haar_moment)
def direct(i, m, j, n):
    a, c = pairs[i]
    b, d = pairs[j]
    target = m | (n << 8)
    pools = [[term for term in src[center, internal] if not term[0] & ~target]
             for center, internal in ((0, a), (0, c), (1, b), (1, d))]
    answer = QComplex()
    candidates = prod(map(len, pools))
    assert candidates <= 2000000
    for monomials in product(*pools):
        used = 0
        parity = 0
        for mask, q, _ in monomials:
            used |= mask
            parity ^= 1 << q
        if parity or used != target:
            continue
        order = []
        powers = [0] * 16
        z = QComplex(1)
        for mask, q, val in monomials:
            order.extend(k for k in range(16) if mask & (1 << k))
            powers[q] += 1
            z *= val
        assert len(set(order)) == 8
        sign = (-1) ** sum(a > b for a, b in combinations(order, 2))
        moment = F(sign)
        for k in range(0, 16, 4):
            moment *= moment_cache(tuple(powers[k:k+4]))
        answer += z * moment
    return answer

real = [k for k, z in edge.items() if z.real and not z.imag]
imag = [k for k, z in edge.items() if z.imag]
absent = [(i, m, j, n) for i, j in product(range(10), repeat=2)
          for m, n in product(masks[::17], repeat=2) if (i, m, j, n) not in edge]
control = real[::max(1, len(real) // 3)][:3] + imag[::max(1, len(imag) // 3)][:3] + absent[:3]
for k in control:
    actual = direct(*k)
    assert actual == edge.get(k, QComplex()), (k, actual, edge.get(k))
    print("direct original edge", k, actual.storage)

# Compare the 70 complement signs against the canonical exterior product,
# rather than the bit-inversion routine of the fast slice implementation.
ext = {0: ExteriorPolynomial(((0, Polynomial.scalar(1)),))}
for m in masks:
    e = ext[0]
    for i in range(8):
        if m & (1 << i):
            e *= ExteriorPolynomial.generator(i)
    ext[m] = e
for m in masks:
    n = m ^ 255
    source_top = (ext[m] * ext[n]).terms
    inversions = sum(a > b for a in range(8) if m & (1 << a)
                     for b in range(8) if n & (1 << b))
    assert source_top == ((255, Polynomial.scalar((-1) ** inversions)),)
print("original exterior complement signs", len(masks))
