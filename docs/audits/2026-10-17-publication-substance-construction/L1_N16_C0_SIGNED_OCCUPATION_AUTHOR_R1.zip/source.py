from collections import Counter
from itertools import product
from pathlib import Path
from src.core.formulas import original_coframe_blocks, original_spin4_link
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, Symbol, assemble_coframe, matrix_multiply,
)
reg = OriginalRegulator()
x = reg.sites[0]
pairs = [(a, b) for a in range(4) for b in range(a, 4)]
pair_id = {ab: i for i, ab in enumerate(pairs)}

def export_coframe(axis):
    y = reg.step(x, axis)[0]
    positions = {g: i for i, g in enumerate(g for g in reg.generator_order if g[0] in (x, y))}
    out = []
    for center_id, center in enumerate((x, y)):
        for a in range(4):
            matrix = assemble_coframe(reg, original_coframe_blocks(reg, (center, axis, a)))
            for (r, c), pol in matrix.entries:
                bar = positions[reg.sites[r // 4], "bar", r % 4]
                psi = positions[reg.sites[c // 4], "psi", c % 4]
                sign = 1 if bar < psi else -1
                mask = (1 << bar) | (1 << psi)
                for key, coeff in pol.terms:
                    symbol, = key
                    anchor, k, chi, coord = symbol.index
                    assert k == axis and anchor in (x, y) and chi in ("L", "R")
                    q = (8 if anchor == y else 0) + (4 if chi == "R" else 0) + coord
                    r4, i4 = 4 * sign * coeff.real, 4 * sign * coeff.imag
                    assert r4.denominator == i4.denominator == 1
                    assert abs(r4) + abs(i4) == 1
                    out.append((center_id, a, mask, q, int(r4), int(i4)))
    return sorted(out)
terms = export_coframe(0)
assert terms == export_coframe(1)
assert Counter((c, a) for c, a, *_ in terms) == {(c, a): 64 for c, a in product(range(2), range(4))}
Path("coframes.tsv").write_text("".join("\t".join(map(str, row)) + "\n" for row in terms))

gamma = reg.gamma
labels = [tuple(Symbol("q", (x, 0, chi, j)) for j in range(4)) for chi in ("L", "R")]
hol = original_spin4_link(*(tuple(Polynomial.variable(s) for s in row) for row in labels))
vectors = {}
for a, b in product(range(4), repeat=2):
    op = matrix_multiply(matrix_multiply(gamma[a], gamma[b]), reg.gamma5)
    trace = sum((hol[i][j] * op[j][i] for i, j in product(range(4), repeat=2)), Polynomial()) if a != b else Polynomial()
    val = {key[0]: coeff for key, coeff in trace.terms}
    for chi in range(2):
        assert labels[chi][0] not in val
        row = []
        for s in labels[chi][1:]:
            q = val.get(s)
            assert q is None or (q.imag == 0 and abs(q.real) == 2)
            row.append(0 if q is None else int(q.real / 2))
        vectors[a, b, chi] = tuple(row)
        assert sum(map(abs, row)) == (a != b)
g = Counter()
for a,b,c,d,chi in product(range(4), range(4), range(4), range(4), range(2)):
    r, s = pair_id[tuple(sorted((a,c)))], pair_id[tuple(sorted((b,d)))]
    v = sum(x * y for x,y in zip(vectors[a,b,chi], vectors[c,d,chi]))
    g[chi+1,r,s] += v
    g[0,r,s] += v
rows = [(t,r,s,v) for (t,r,s),v in sorted(g.items()) if v]
assert all(g[t,r,s] == g[t,s,r] for t,r,s,_ in rows)
Path("grams.tsv").write_text("".join("\t".join(map(str, row)) + "\n" for row in rows))
print("source terms", len(terms), "nonzero Gram entries", Counter(t for t, *_ in rows))
