# Exact signed value for the selected full periodic N16 occupation

The primary continuity packet
`publication-l1-n16-c0-signed-slice-author-r1.json` checked fresh at
`27012c18fa374e8341e124b510abbedeedb18d29`. The input reduction is the
signed face and square decomposition from the provisional factored-load
report. The only occupation evaluated here has m_(x,23)=2 at every
vertex and zero multiplicity in all other rooted planes. Its original
Haar/Berezin contribution is

```
(1/2^16) * [(104978/6561) * (1573101/2048)]^4
= 1079840342062317710103477257434903921 / 3101843146481947279097856
> 0.
```

This incorporates the original signs, all 128 odd generators, all 64
anchored links and the original exponential factorial. The rest of the
pure-EHC coefficient remains open.

## Source-derived collapse from 81 slices to one

The two curvatures at each root supply either the base Gram G0=GL+GR or
one of the two single-chirality Gram tensors. Before contracting the
coframes, GL and GR are different. In the coefficient of this
occupation, each site's two coframes of a given direction commute.
The internal labels are therefore symmetrized within each of the two
direction pairs. `source.py` obtains all trace vectors from the
canonical source gamma and Spin(4) matrices. It sums the four ordered
internal labels over their sorted pair labels. In this symmetrization
the 10×10 matrices satisfy GL=GR and G0=2GL entry by entry. Each has
18 nonzero entries. In polynomial form, the common chiral vertex is

```
W_x = (sum_A T_(x,0,A)^2) (sum_B T_(x,1,B)^2)
      - (sum_A T_(x,0,A) T_(x,1,A))^2.
```

The earlier curvature face formula has two correlated terms of weight
1/6561 in addition to the base product. After the above symmetrization,
the face multiplies the product of its four W_x by
16+2/6561=104978/6561. There are four distinct curvature faces, each
integrating eight distinct original anchored links. For the remaining
coframe factors the four 0,1 squares, each with eight other anchored
links, are independent. Each has the same source-order, signed
32-generator coefficient C*. Hence the selected occupation is
2^-16(104978/6561)^4(C*)^4. The original world epsilon is squared.
The factor 2^-16 is the product of sixteen 1/2! factors. There is no
additional 32! after expanding the original exponential into labeled
occupations. Permuting whole site tops or whole square tops has
positive sign.

`curvature_face.py` reruns the literal trace and anchor checks from
the face result. It verifies the joint four-root square scale
104978/6561 and the mixed four-root F01 F23 control 2/6561. The
single-root product of separate averages would give zero in that
mixed control. The input face derivation remains under separate
independent review.

## The exact fourth Haar tensor

The canonical coframe assembly exports 64 signed linear monomials per
internal component and center on a representative undirected edge.
Each term has one odd generator at each endpoint and a coefficient
in {1,−1,i,−i}/4 times one quaternion coordinate. The 16 quaternion
coordinate IDs distinguish both anchors, both SU(2) groups on each
anchor, and all four real coordinates. The export in axes 0 and 1 is
identical after relabeling endpoints and anchors.

For one edge integrate the actual product of two coframes centered
at each endpoint. The tensor is indexed at an endpoint by its sorted
internal pair and degree-four exterior mask, at most 10×70=700
states. Each product uses exactly four quaternion coordinates.
Construct two quadratic polynomials with full labels and signed
exterior products. Matching their coordinate parity leaves only
q^4 or q^2 r^2. The normalized moments are respectively 1/8 for
one coordinate, 1/24 for distinct coordinates of the same SU(2)
group, and 1/16 for distinct groups. A common moment denominator
is 48. Multiplying by the four original coframe quarters gives the
edge's common denominator 4^4·48=12288.

The implementation compared every entry by two groupings.
The first forms the two coframes at each center before joining the
pair. The second forms each pair from opposite centers before
joining. The groupings have 3,862,912 and 11,065,344 candidate
moment joins respectively and agree entry by entry, including
zeros. The 700×700 tensor has 3,952 nonzero entries, including
1,600 imaginary entries. The numerator's maximum Gaussian
integer one-norm is 2,688. Exchanging the two complete endpoints
gives its transpose without a sign, which the implementation
checks exactly.

`independent.py` also enumerates the four raw source monomial
pools independently on nine selected edge entries. It uses the
canonical exact quaternion moment function with full coordinate
powers and computes the source exterior sign by direct inversion
count. It agrees on three real entries, three imaginary entries,
and three zero entries. For example, it recovers 3/16,
−11/384, and −11i/192. Its raw control was capped at two million
candidates per entry. A preliminary 400,000-candidate control
refused before evaluation and the final capped controls were
rerun with parity and complete-mask prefilters.

## The signed 32-generator square

Let E be the integer numerator of the fourth Haar edge tensor.
At each site two incident edges supply degree four. The vertex
matrix V uses the common chiral Gram and accepts exactly
complementary exterior masks. Its sign is the canonical sign of
their local ordered product. The source exterior multiplication
agrees with the implementation on all 70 complement signs.
Moving an edge endpoint's degree-four word across other endpoint
words is an even permutation. Traversing a square alternates axis
0 and axis 1, so V alternates with its transpose. V is symmetric
because the symmetrized Gram is symmetric and exchanging two
degree-four masks is even. The checked endpoint symmetry of E
then gives the exact square coefficient

```
C* = trace((V E)^4) / 12288^4.
```

`slice.cpp` forms VE and EV, checks their transpose relation, and
computes each trace as the contraction of two signed length-two
paths. Each path product has 218,432 nonzero input products. Both
orientations yield the same Gaussian integer trace numerator

```
17512633766806290432 + 0 i
```

and C*=1573101/2048. All imaginary parts are retained through the
contraction. `result.py` also explicitly reconstructs the original
81 face assignments and verifies equality with the collapsed
positive rational.

The prospective limits are 50 million moment joins per grouping
and 50 million matching products per matrix phase, separately.
The edge tables have the fixed interface size 700. Before path
multiplication, the code derives exact integer-height bounds from
the measured maximum entry one-norm and the interface dimension.
It refuses if the path products or final trace could exceed the
fixed signed integer types. The measured matching stage used
882,000 vertex products per orientation and a maximum entry
one-norm of 8,064 after applying V. The whole compiled calculation
ran within the recorded resource caps. Timing and RSS are in
`slice.out` and `independent_fast.out`.

The original restricted top controls also reran. The opposite
endpoint chiralities give the exact 3/4 coefficient and the
same-chirality variant gives zero with identical coarse support.
These are independent source and sign checks for the scope
boundaries, separate from the 32-generator result.

## Reproduction

Use the exact primary checkout on PYTHONPATH and its existing venv
Python with PYTHONDONTWRITEBYTECODE=1. Run `source.py` to generate
`coframes.tsv` and `grams.tsv`. Compile `slice.cpp` with
`clang++ -std=c++20 -O3 -Wall -Wextra -Werror slice.cpp -o slice`.
Run `python3 measure.py ./slice > slice.out`. This writes
`edge.tsv`. Run `result.py` with Python, and `independent.py`,
`curvature_face.py` and `source_control.py` with the same
source environment. The second restricted source run supplies the
argument `same-chirality`. The manifest binds source exports,
programs, receipts and this report. No tracked files or Lean
slots were changed. The selected occupation requires independent
acceptance, and its positivity does not control cancellations
from other occupations in the full periodic c0.
