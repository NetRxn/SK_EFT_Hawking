from fractions import Fraction as F
from itertools import product
from pathlib import Path
rows = Path("slice.out").read_text().splitlines()
rec, = [r.split() for r in rows if r.startswith("C numerator ")]
c = F(int(rec[2]), int(rec[5]) ** int(rec[7]))
assert c == F(1573101, 2048)
mu = F(104978, 6561)
factored = (mu * c) ** 4 / 2**16
explicit = sum((2**t.count(0) * c)**4 / 6561**(4 - t.count(0))
               for t in product((0, 1, 2), repeat=4)) / 2**16
assert explicit == factored and factored > 0
print("C*:", c)
print("face scale:", mu)
print("selected occupation with all factorials:", factored)
print("81-term direct reconstruction equals factored form")
