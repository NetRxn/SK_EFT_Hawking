from pathlib import Path
from collections import Counter,defaultdict
from itertools import product
from fractions import Fraction
import ast,sys,json,signal,time,hashlib
signal.alarm(30);start=time.perf_counter()
A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');sys.path.insert(0,str(A))
from sympy import I,Matrix,diag,eye,zeros,Rational,simplify
from sympy.polys.rings import ring
from sympy.polys.domains import QQ_I
import l1_direct_b_haar as original
from l1_normalization_opposed_fourth import L
from l1_extended_opposed_source import frame as actual_frame,action_frame as actual_action_frame
# Exact original function ASTs, with only scalar coefficient domain extended ZZ_I→QQ_I.
# Formulas and generator ordering are unchanged; integer calls below anchor the domain extension.
R,z=ring('z',QQ_I);gamma=original.gamma;g5=diag(1,1,-1,-1)
ns={'R':R,'defaultdict':defaultdict,'product':product,'wedge_sign':original.wedge_sign,'diag':diag,'I':I,'pauli':original.pauli,'zeros':zeros,'eye':eye,'gamma':gamma}
for file,names in [('l1_direct_b_haar.py',{'add','scale','wedge','bilinear'}),('l1_normalization_disjoint_sector.py',{'quat','adj'}),('l1_extended_opposed_source.py',{'frame','action_frame'}),('l1_direct_a_haar.py',{'mul'}),('l1_extended_mixed_curvature_core.py',{'face_vector'})]:
 body=[n for n in ast.parse((A/file).read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names];exec(compile(ast.Module(body=body,type_ignores=[]),str(A/file),'exec'),ns)
add,scale,wedge,bilinear,quat,adj,mul=(ns[n] for n in ('add','scale','wedge','bilinear','quat','adj','mul'))
def q(n):
 r=sum(x*x for x in n);return (Rational(1-r,1+r),*(Rational(2*x,1+r) for x in n))
def unitary(link):return diag(quat(link[0]),quat(link[1]))
Gq={s:(q((1+s%3,(s//3)%3,1)),q((1,(s+1)%4,1+(s//4)%3))) for s in range(16)};G={s:unitary(v) for s,v in Gq.items()}
for s,v in G.items():assert (v.H*v).applyfunc(lambda x:x.expand())==eye(4) and v.det().expand()==1
word=int(sys.argv[2]);flip=0 if word==161 else 1;forest=[(0,2),(1,2),(3^flip,1),(7^flip,2),(1^flip,3),(5^flip,3)]
bare={(s,a):(q((1+(s+a)%3,(s+2*a)%3,(2*s+a)%4)),q((1+(s+2*a)%4,(2*s+a)%3,1+(s+a)%2))) for s in range(16) for a in range(4)}
for s,a in forest:
 t=s^(1<<a);bare[s,a]=tuple(tuple(mul(adj(Gq[t][c]),Gq[s][c])) for c in (0,1))
new={(s,a):tuple(tuple(mul(mul(Gq[s^(1<<a)][c],v[c]),adj(Gq[s][c]))) for c in (0,1)) for (s,a),v in bare.items()}
for e in forest:assert new[e]==((1,0,0,0),)*2
H=(5^flip,2);src=(1^flip,2);assert H not in forest and new[H]!=((1,0,0,0),)*2 and bare[H]!=tuple(tuple(adj(v)) for v in bare[src])
# Canonical polynomial transforms use 8 variables per physical site: bar[0:4],psi[4:8].
def normpoly(p):return {m:str(v) for m,v in sorted(p.items()) if v}
def fingerprint(p):return hashlib.sha256(json.dumps(normpoly(p),sort_keys=True).encode()).hexdigest()
def ringconvert(p):return {m:R.from_expr(v.as_expr()) for m,v in p.items()}
def vector(edge,center,coords,pullback=False,wrong_bar=False,incoming_poison=False):
 axis=edge;neighbor=center^(1<<axis);ns['bilinear']=lambda M,b,p:bilinear((G[center if b==0 else neighbor] if wrong_bar else G[center if b==0 else neighbor].H)*M*G[center if p==0 else neighbor] if pullback else M,center if b==0 else neighbor,center if p==0 else neighbor)
 # Both source/action calls use direction0 locally; site1 then remaps to physical neighbor.
 left,right=coords[center,axis];forward=ns['frame'](0,False,left,right)
 left,right=coords[neighbor,axis];incoming=ns['frame'](0,True,left,right) if incoming_poison else ns['action_frame'](0,1,left,right)
 ns['bilinear']=bilinear
 return [add(x,y) for x,y in zip(forward,incoming)]
def origin_blocks(axis,center,coords,pullback=False):
 neighbor=center^(1<<axis);U=unitary(coords[center,axis]);V=unitary(coords[neighbor,axis])
 def block(M,b,p,sign):
  if pullback:M=G[b].H*M*G[p]
  return scale(bilinear(M,b,p),sign)
 return [[block(g*U.H,center,neighbor,1) for g in gamma],
         [block(U*g,neighbor,center,-1) for g in gamma],
         [block(V.H*g,neighbor,center,1) for g in gamma],
         [block(g*V,center,neighbor,-1) for g in gamma]]

def source(origin,axis,coords,pullback=False,wrong_bar=False):
 y=origin^(1<<axis)
 ns['bilinear']=lambda M,b,p:bilinear((G[origin if b==0 else y] if wrong_bar else G[origin if b==0 else y].H)*M*G[origin if p==0 else y] if pullback else M,origin if b==0 else y,origin if p==0 else y)
 f=ns['frame'](0,False,*coords[origin,axis]);ns['bilinear']=bilinear
 return add(*(wedge(p,p) for p in f)),f
# Independent direct Grassmann substitution; canonical masks are expanded in ascending generator order.
def substitute(p,sites):
 images={}
 for s in sites:
  for i in range(4):
   images[8*s+i]={1<<(8*s+j):R.from_expr(G[s].H[j,i]) for j in range(4) if G[s].H[j,i]}
   images[8*s+4+i]={1<<(8*s+4+j):R.from_expr(G[s][i,j]) for j in range(4) if G[s][i,j]}
 out={}
 for mask,value in p.items():
  term={0:value}
  for bit in range(mask.bit_length()):
   if mask>>bit&1:term=wedge(term,images[bit])
  out=add(out,term)
 return out
mode=sys.argv[1];result={'mode':mode,'word':word,'link_law':'U_xy prime = S_y U_xy S_x dagger','spinor_law':'psi prime=S psi; bar prime=bar S dagger','source_scalar_domain':'actual AST ZZ_I→QQ_I only'}
if mode=='source':
 checks=[]
 for origin in (0,1):
  old,oldvec=source(origin,2,bare);raw,rawvec=source(origin,2,new);pulled,pulledvec=source(origin,2,new,True);assert old and pulled==old
  generic=substitute(raw,(origin,origin^4));assert generic==pulled
  wrong,_=source(origin,2,new,True,True);assert wrong!=old
  # Actual imported generator at cleared integer coordinates verifies exact formula/domain anchoring.
  link=bare[origin,2];den=1
  from math import lcm
  for sector in link:
   for x in sector:den=lcm(den,int(x.q))
  integer=tuple(tuple(int(den*x) for x in sector) for sector in link)
  expected=actual_frame(0,False,*integer);ns['bilinear']=bilinear;local=ns['frame'](0,False,*link)
  assert all(scale(v,den)==ringconvert(w) for v,w in zip(local,expected))
  checks.append({'origin':origin,'terms':len(old),'sha256':fingerprint(old),'generic_quartic_spinor_substitution':True,'wrong_bar_transformation_detected':True})
 result['source_checks']=checks
elif mode=='action':
 center=int(sys.argv[3]);manifest=next(r for l in (A/'l1_k4_census.out.txt').read_text().splitlines() if (r:=json.loads(l))['kind']=='paired-k4-census');row=manifest['rows'][word];frame={s:(0,1) for s in range(16) if s!=row['omitted']};frame.update((s,tuple(a)) for s,a in row['changes']);mu,nu=frame[center];ka,la=sorted(set(range(4))-set((mu,nu)));face=(center,ka,la)
 def hol(coords):
  a,b,c,d=(coords[e] for e in ((center,ka),(center^(1<<ka),la),(center^(1<<la),ka),(center,la)))
  return diag(*(quat(mul(mul(adj(d[ch]),adj(c[ch])),mul(b[ch],a[ch]))) for ch in (0,1)))
 Po,Pn=hol(bare),hol(new);assert (Pn-G[center]*Po*G[center].H).applyfunc(lambda x:x.expand())==zeros(4)
 oldmu=vector(mu,center,bare);oldnu=vector(nu,center,bare);newmu=vector(mu,center,new,True);newnu=vector(nu,center,new,True)
 rot=Matrix(4,4,lambda a,b:(gamma[b]*G[center].H*gamma[a]*G[center]).trace().expand()/4);assert (rot.T*rot).applyfunc(lambda x:x.expand())==eye(4) and rot.det().expand()==1
 assert all(newmu[a]==add(*(scale(oldmu[b],rot[a,b]) for b in range(4))) for a in range(4));assert all(newnu[a]==add(*(scale(oldnu[b],rot[a,b]) for b in range(4))) for a in range(4))
 blockchecks=0
 for axis,oldv,newv in ((mu,oldmu,newmu),(nu,oldnu,newnu)):
  ob=origin_blocks(axis,center,bare);nb=origin_blocks(axis,center,new,True)
  assert all(add(*(v[a] for v in ob))==oldv[a] and add(*(v[a] for v in nb))==newv[a] for a in range(4))
  for oldblock,newblock in zip(ob,nb):
   assert all(newblock[a]==add(*(scale(oldblock[b],rot[a,b]) for b in range(4))) for a in range(4));blockchecks+=1

 def action(coords,ev,fv):
  values=[ns['face_vector'](face,coords,*divmod(i,3)) for i in range(6)];p=hol(coords);out={}
  for a,b in product(range(4),repeat=2):
   coefficient=sum(v*values[i] for i,v in L[a,b]);assert coefficient==(p*(gamma[a]*gamma[b]-gamma[b]*gamma[a])*g5).trace().expand()/2
   if coefficient:out=add(out,scale(wedge(ev[a],fv[b]),coefficient))
  return out
 before=action(bare,oldmu,oldnu);after=action(new,newmu,newnu);assert before and before==after
 result.update(center=center,frame=(mu,nu),face=face,action_terms=len(before),action_sha256=fingerprint(before),coframe_vector_covariance=True,closed_face_covariance=True,actual_curvature_L_trace_bridge=True,whole_local_action_polynomial_equal=True,SO4_rotation_orthogonal_det1=True,individual_origin_blocks=blockchecks)
 # Concrete negative controls at the endpoints directly touched by extra forest and H.
 if center==(1^flip):
  poisoned=dict(new);e=(1^flip,3);s,a=e;t=s^(1<<a);poisoned[e]=tuple(tuple(mul(bare[e][c],adj(Gq[s][c]))) for c in (0,1))
  bad=action(poisoned,newmu,newnu);assert bad!=before;result['missing_single_forest_endpoint_detected']=True
 if center==(5^flip):
  poisoned=dict(new);poisoned[H]=((1,0,0,0),)*2;bad=action(poisoned,newmu,newnu);assert bad!=before;result['opposite_anchor_identified_with_fixed_source_detected']=True
  # Full independent quartic mask expansion for one actual action (not only matrix pullback).
  raw=action(new,vector(mu,center,new),vector(nu,center,new));generic=substitute(raw,(center,center^(1<<mu),center^(1<<nu)));assert generic==before;result['generic_quartic_action_spinor_substitution']=True
  wo=vector(mu,center,bare,incoming_poison=True);wn=vector(mu,center,new,True,incoming_poison=True)
  assert any(wn[a]!=add(*(scale(wo[b],rot[a,b]) for b in range(4))) for a in range(4));result['reverse_source_frame_misused_as_incoming_action_detected']=True

elif mode=='coframe-basis':
 from l1_extended_offset_witness import coframe as actual_coframe
 basis_checks=0
 for center,anchor,coordinate,g in product(range(2),range(2),range(8),range(4)):
  one=tuple(int(j==coordinate%4) for j in range(4));zero=(0,0,0,0);link=(one,zero) if coordinate<4 else (zero,one)
  ns['bilinear']=lambda M,b,p:bilinear(M,center if b==0 else 1-center,center if p==0 else 1-center)
  expected=ns['frame'](0,False,*link) if anchor==center else ns['action_frame'](0,1,*link)
  ns['bilinear']=bilinear
  assert expected[g]==ringconvert(actual_coframe(center,anchor,coordinate,g));basis_checks+=1
 result['all128_actual_coframe_center_anchor_basis_sign_checks']=basis_checks
elif mode=='jacobian':
 topchecks=0
 for site in range(16):
  top=((1<<8)-1)<<(8*site);actual=substitute({top:R.one},(site,));assert actual=={top:R.one};topchecks+=1
 result.update(all16_unit_Berezin_top_mask_checks=topchecks,all_spin4_matrices_unitary_det1=True,forest_links_fixed_to_identity=forest,opposite_H_stays_nonidentity=True)
else:raise AssertionError(mode)
result['seconds']=time.perf_counter()-start;print(json.dumps(result,sort_keys=True))
