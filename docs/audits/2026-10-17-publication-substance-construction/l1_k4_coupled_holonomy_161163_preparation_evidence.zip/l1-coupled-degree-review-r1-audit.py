from pathlib import Path
import hashlib,json,zipfile,collections,subprocess,time
P=Path('/tmp');prefix=P/'l1-coupled-degree-review-r1';sha=lambda b:hashlib.sha256(b).hexdigest()
xp=P/'l1-coupled-evaluator-r2-degree-evidence.json';assert sha(xp.read_bytes())=='b9a41769c75dc95b5340c52b588ba6621e40f5d85a00accb0516751a92070f62';x=json.loads(xp.read_bytes())
report=P/'l1-coupled-evaluator-r2-degree-report.md';assert sha(report.read_bytes())=='49ecaf7c39b887526285d614bf83206c9c1b631c15dfc098f13ff66c0bc6937d'
old=json.loads((P/'l1-coupled-evaluator-r2-sourcecontract.json').read_text());prior=json.loads((P/'l1-coupled-preparation-review-r1-audit.json').read_text())
assert len(x['attempts'])==16 and [a['name'] for a in x['attempts']]==['degree-fixtures']+['degree-unrestricted'+str(i) for i in range(15)]
agg=collections.Counter();by_role={};bindings={};records=[]
with zipfile.ZipFile(str(prefix)+'-consumed.zip','x',zipfile.ZIP_DEFLATED) as z:
 def keep(p):
  data=p.read_bytes();z.writestr(p.name,data);bindings[p.name]=sha(data);return data
 keep(xp);keep(report)
 for name,h in x['frozen_bindings'].items():
  p=P/('l1-coupled-evaluator-r2-'+name);assert sha(keep(p))==h
 # Independently preserve and recheck all90 original18 scientific attempt artifacts.
 for name,h in prior['bindings'].items():
  p=P/name
  if name not in bindings:assert sha(keep(p))==h
  else:assert bindings[name]==h
 for a in x['attempts']:
  stem='l1-coupled-evaluator-r2-'+a['name'];raw={s:keep(P/(stem+'.'+s)) for s in ['source.py','controls.py','stdout','stderr','exit.json','runlog']}
  r=json.loads(raw['exit.json']);assert r==a['receipt'];assert r['exit_code']==0 and r['timeout'] is False and r['parent_seconds']<30 and raw['stderr']==b''
  assert sha(raw['source.py'])==r['source_sha256']==x['source_sha256']
  assert sha(raw['controls.py'])==r['controls_sha256']==x['controls_sha256']
  assert sha(raw['stdout'])==r['stdout_sha256'] and sha(raw['stderr'])==r['stderr_sha256']
  d=json.loads(raw['stdout']);assert d.pop('source_hashes')==old['source_hashes'];assert d==a['observations']
  log=raw['runlog'].decode();decoder=json.JSONDecoder();rr,n=decoder.raw_decode(log);assert rr==r;dd,n2=decoder.raw_decode(log[n:].lstrip());assert dd==json.loads(raw['stdout']);assert not log[n:].lstrip()[n2:].strip()
  if a['name']=='degree-fixtures':
   assert r['argv'][3:]==['degree-fixtures'] and d['mode']=='degree-fixtures'
   fixtures=d['fixtures'];assert fixtures['baseline']==fixtures['restored']
   expected={'wrong_degree':'monomial_degree','wrong_support':'undeclared_site_support','too_high_mask':'mask_range','negative_mask':'mask_range','nonzero_scalar':'undeclared_site_support'}
   assert fixtures['poisons']=={k:{'result':'RED as required','reason':v} for k,v in expected.items()}
   assert fixtures['baseline']['totals']=={'factors':1,'rows':1,'monomials':1,'nonzero_masks':1}
  else:
   j=int(a['name'].removeprefix('degree-unrestricted'));assert r['argv'][3:]==['xor',str(j),'unrestricted'] and d['mode']=='xor'
   assert d['161']==d['163'];comp=d['comparison'];assert comp['factors']==47 and comp['negative_mask_sign_terms']==0
   original=old['attempts'][j+2]['observations'];assert comp==original['comparison']
   for word in ('161','163'):
    w=dict(d[word]);m=w.pop('monomial_support_degree_readback');assert w==original[word]
    assert m['mask_range_below_2pow128'] is True and m['support_only_declared_sites'] is True and m['all_declared_popcounts_exact'] is True and m['scalar_center_masks_zero'] is True
    totals=m['totals'];assert totals['factors']==47 and totals['rows']==w['rows']==comp['rows'] and totals['monomials']==w['terms']==comp['terms']
    roles=m['by_role'];assert {k:v['factors'] for k,v in roles.items()}==w['factor_kinds']
    assert {k:sum(v[k] for v in roles.values()) for k in totals}==totals
    for role,v in roles.items():
     if role in ('center','face','moment4','moment6'):assert v['nonzero_masks']==0 and v['rows']==v['monomials']
     else:assert v['nonzero_masks']==v['monomials']
     by_role.setdefault(role,collections.Counter()).update(v)
    agg.update(totals)
   records.append({'branch':j,'rows_per_word':d['161']['rows'],'monomials_per_word':d['161']['terms'],'seconds':r['parent_seconds']})
assert dict(agg)==x['aggregate_full_preparation_monomial_readback']=={'factors':1410,'rows':1986726,'monomials':2962818,'nonzero_masks':1008912}
assert {k:dict(v) for k,v in by_role.items()}==x['by_role']
assert [r['branch'] for r in records]==list(range(15));assert max(a['receipt']['parent_seconds'] for a in x['attempts'])==x['max_parent_seconds']
# Native final authorities/read-only checkout readback only; no scientific execution.
base=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research');repo=base/'.publication-l1-checkpoint-20261103';py=str(base/'SK_EFT_Hawking/.venv/bin/python');receipts=[]
for name,argv in [('continuity',[py,'-B',str(repo/'scripts/codex_continuity.py'),'check',str(base/'SK_EFT_Hawking/.codex/continuity/l1-coupled-degree-acceptance-r1.json')]),('head',['git','rev-parse','HEAD']),('status',['git','status','--porcelain=v1'])]:
 t=time.monotonic();r=subprocess.run(argv,cwd=repo,capture_output=True,text=True,timeout=30);receipts.append({'name':name,'argv':argv,'exit':r.returncode,'seconds':time.monotonic()-t,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0 and not r.stderr
assert json.loads(receipts[0]['stdout'])['fresh'] and receipts[1]['stdout'].strip()=='531f89f59136c7a23b24ad036e11f77fc2593c62' and receipts[2]['stdout']==''
cov=P/'l1-coupled-covariance-independent-r1-review.md';assert sha(cov.read_bytes()).startswith('d9e1030d')
result={'verdict':'ACCEPT_ACTUAL_COMPLETE_MONOMIAL_DEGREE_SUPPORT_RANGE_SCALAR_ZERO_AND_SIGNED_XOR1_DATA','required_corrections':[],'scientific_children':16,'complete_word_branch_graphs':30,'all_raw_receipts_snapshots_streams_hashes_exits_exact':True,'all_original18_artifacts_unchanged':True,'frozen_bindings':x['frozen_bindings'],'aggregate':dict(agg),'by_role':{k:dict(v) for k,v in by_role.items()},'records':records,'max_child_parent_seconds':x['max_parent_seconds'],'fixture_reasons':expected,'no_scientific_rerun_or_contraction':True,'covariance_separate_review_sha256':sha(cov.read_bytes()),'final_receipts':receipts,'bindings':bindings,'consumed_zip_sha256':sha(Path(str(prefix)+'-consumed.zip').read_bytes()),'coverage':'236/272 unchanged','limits':'No fixed coefficient, scalar/full contraction, intermediate cap/runtime, portable/main/publication acceptance'}
Path(str(prefix)+'-review.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ('bindings','final_receipts','frozen_bindings')}))
