# Coupled161/163 scratch implementation handback

Frozen scientific source: `/tmp/l1-coupled-evaluator-r2-source.py`, SHA256 `5736258f9fe63fe246fb98df8827ac16d4fe1a933439723b92ebbcceb1bba6e7`.

This implements the independently accepted b9ccad54 design using the existing scientific kernels. Separate source review ACCEPT_SOURCE_ONLY is `/tmp/l1-coupled-source-review-r1-review.md`, SHA256 `fbfcdad52a3fa7977aa3266ebba255b5079dd66516c34be78316962b19ff1c3c`. That reviewer independently checked geometry, all15 branch domains/weights and all fourth/sixth moments, but deliberately did not adopt the preparation observations below. No scalar or action contraction, coefficient, full CLI, portable delivery, runtime feasibility or publication acceptance is claimed. Coverage stays236/272.

## Authority and writes

First and final native checks of `.codex/continuity/l1-coupled-evaluator-implementation-r1.json` returned fresh=true/changed=[]. Candidate HEAD remains531f89f59136c7a23b24ad036e11f77fc2593c62. Accepted design/review/acceptance/interface and updated primary notebook were read. Only `/tmp/l1-coupled-evaluator-r2-*` scratch files were written. All consumed source/control snapshots and original child stdout/stderr/exit receipts remain preserved. There was no tracked source/notebook/Git/slot/runtime/configuration mutation, dependency operation or broad test.

## Implemented source contract

The module exposes only geometry/data/component_key/occurrence_key/curvature_factors/branches/prepare/source_hashes. It has no eliminator, solve function, main block or CLI. No scientific contraction can occur by invoking its defined construction functions.

`data()` reads the existing complete k4 census and asserts manifest SHA256 `ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b`. It selects only161/163. `geometry()` reconstructs the original frames, both ordered sources,20 action edges and six peeled faces from existing two.base. It asserts the exact remaining coupled/independent face sets, genuine six-edge forest, source/action separation, original physical-site degree8 and precise live-edge center/slot. H stays independent and unfixed; for161 it is(5,2), opposite the fixed source(1,2), while K=(7,1) stays joined to action center5/slot1. Word163 is the complete XOR1 image. No opposite-anchor inverse substitution occurs.

`curvature_factors()` constructs exactly five original face factors with free-link orders HK/J/LH/MNJ/NHML, four raw48 fourth-moment factors and one raw192 joint H sixth-moment factor. Separate occurrence labels keep every coordinate index twice-used. It uses canonical face_tensor/PAIRS/COMPONENTS/HAAR/moment; there is no new Haar formula/helper, scalar-tensor lookup or cache. Actual both-word scalar supports are300/21/300/4200/57168/92/92/92/92/1520: ten factors,63877 rows, largest57168. All21 unordered component pairs and all36 coordinate pairs are enumerated where appropriate. Existing coefficient grouping supplies offdiagonal multiplicity once; no factor2 is added.

`branches()` retains exactly15 original protected-branch terms for the independent torus, including both negative chirality corrections and every matching term. `prepare()` retains15 center gamma factors,20 original action-edge factors,10 coupled scalar factors and2 explicit original ordered sources:47 factors. The two fixed action edges use canonical fixed_action_edge, K uses canonical probed_action_edge, every other action edge uses canonical witness.local_edge, and both sources use actual sum_gamma anchored(0,(),None,gamma) followed by physical remap. Existing signed coframe endpoint exchange and mask polynomials remain intact. The component-pair variables connect each of the five coupled face factors to its own center_weights((comp,)); independent-torus center domains come from the selected signed branch; other centers use peeled_channels through center_weights(None).

The exact raw divisor is192^43*4^64*48^10*2^15. The original action/source/coframe/peeled/factorial contribution is192^42*4^64*48^6*2^15, while the explicit coupled moment factors append48^4*192 exactly once. Independent-torus branch weights remain normalized Fraction values outside that divisor. Both identity-fixed source factors retain raw192. No Haar forest volume, source-order factorial or axis/shear multiplier is introduced. Original row120000/pair3000000 constants are asserted unchanged. Preparation checks individual-factor row/term caps but does not execute a join or establish intermediate limits.

## Actual bounded observations

Original17 consumed control snapshots have SHA256 `ed66b3f27f2429984ed4750651b629dc211ca40ee94853afe5bc8968be8ea5ca`. The current `/tmp/l1-coupled-evaluator-r2-controls.py` additionally includes ROOT-requested comparator seam controls and has SHA256 `bbd74607ce156432d6b9f6ee5a80f6db8ef7bfd580535201789e55dadd64c31f`. Driver: `/tmp/l1-coupled-evaluator-r2-run.py`. Scientific children use primary `.venv/bin/python -B`, their own30s alarm and parent30s timeout. Every consumed source/control snapshot is copied before the child runs.

The original17 scientific children were actually run: one both-word scalar-table/branch observation, one both-word fixed-gamma branch0 preparation/XOR1 comparison, and one both-word UNRESTRICTED preparation/XOR1 comparison for each branch0..14. All17 exited0, all stderr streams are empty, none timed out, and the largest observed parent duration was27.517861750s. The final sourcecontract audit checked every child terminal result, exact consumed source/control hash, stdout hash, branchweight equality and comparison payload; later driver exit statuses alone were not used as scientific success evidence. There were no failed/retried scientific children.

All30 unrestricted preparations are nonempty. Every one has47 factors and47 distinct twice-used labels, with metadata degree8 at all16 physical sites. Maximum individual factor has57168 monomials. Counts per word/branch are:

| Branches | Rows | Exterior/scalar terms |
|---|---:|---:|
|0,1,8|66253|99631|
|2,5,7,9,12,14|66237|99615|
|3,10|66197|96511|
|4,6,11,13|66197|97951|

Fixed-gamma branch0 has63959 rows/65126 terms for each word, still47 factors/47 labels and metadata degree8. This is preparation only, not a fixed-label coefficient.

The XOR1 checker matches all47 factors by semantic role, maps gamma/component/occurrence axes, reorders their row coordinates, maps physical-site degree metadata and compares every Gaussian coefficient after the full128-generator mask permutation. Its sign is computed by the inversion parity of the selected generators; it is not replaced by an assumed block sign. All15 unrestricted comparisons and the fixed branch0 comparison passed EXACT dictionary equality. Actual individual prepared monomials in these tables all had positive XOR1 permutation parity; a separate exact toy control of the same checker returned the required negative sign for one generator at site0 and one at site1, and positive sign for two at each site. Complete intermediate contraction rows can have different mask support and still require the canonical signed joins.

The reported degree8 condition is the actual sum of factor degree metadata checked at preparation time. The checker compared complete actual masks and coefficients under XOR1; it did not separately assert per-monomial degree metadata equality at every factor. An independent preparation/control acceptance should inspect that distinction rather than treating degree metadata alone as a full Grassmann-support proof.

Machine-readable receipts/observations are `/tmp/l1-coupled-evaluator-r2-sourcecontract.json`. Original per-attempt files are `/tmp/l1-coupled-evaluator-r2-local.*`, `...-fixed0.*` and `...-unrestricted0.*` through `...-unrestricted14.*`; each includes consumed `.source.py` and `.controls.py`, original `.stdout`, `.stderr` and `.exit.json`. Later runs additionally preserve driver `.runlog`. The sourcecontract contains actual scientific helper SHA256 values returned by the frozen source, matching the15 accepted-design helper bindings. This names the measured15-helper binding set; it is not asserted to be every transitive Python import in the repository.

## Covariance boundary and next action

Complete prepared-row XOR1 is an actual author observation above, not nonidentity gauge covariance. Independent nonidentity forest/source/action/spinor/Berezin covariance is owned by source_register_implementation_review. That reviewer identified the existing original-law owners `l1_ward_witness.py` and `l1_full_action_reference.py`; these were read directly. Their link transformation is U(x,a)'=S(x+a)U(x,a)S(x)†, with barψ'=barψS† and ψ'=Sψ. The canonical closed d†c†ba face orientation must remain; the existing literal-order counterexample must not be weakened or bypassed. No separate substitute Ward helper was invented here.

At handback I have not adopted or claimed that independent nonidentity result. Actual transformed links, source/action coframes, spinor mask pullback, nonidentity forest reconstruction and unit Berezin Jacobian need the assigned independent readback and review before fixed/pilot acceptance. The present frozen source and its source acceptance do not discharge that bridge by invoking gauge invariance in prose.

Next independently review/adopt the actual30-preparation signed-row evidence and reconcile it with that nonidentity result. Then, on separate execution admission, perform independently bounded normalized scalar-slice/fixed-label controls with all15 branches and original roles/divisor; no fixed/scalar/full contraction was attempted in this package. Whole runtime must preserve600cold/ONE60whole warm/665parent and120000row/3000000pair bounds. No warm/cold full-contraction performance, peak intermediate support or complete joint T support was measured. A genuine cap failure requires reviewed scientific factorization, not a raised cap, discarded branch or partial sum.

Full k4/full source-action ensemble/common partition, physicalB3/window, microscopic modes/matter coupling, transport/frequency/error, portable delivery, main and human/publication acceptance remain open. No236→238 credit is assigned.

Evidence SHA256: sourcecontract.json `cd3c67b4e64cb6bb9af1b5d33f6cfd701c6a6de1d0d892fdc3a8399e8438bd05`; run.py `b85affe2781a1b395159d4c728ee72d3679d7d1c977a1e0332c1bb0dffcdfe70`.

## Additional requested comparator seam

An18th bounded scientific child (26.991568292s, terminal0, empty stderr) re-prepared the actual unrestricted branch0 pair, then exercised the existing comparator. Actual bits0/8 XOR1 fixture returned mask257/sign−1. Changing one actual Gaussian coefficient in action factor(0,1,0) caused RED; restoration returned complete66253-row/99631-term equality. Changing one actual mask in the same factor caused RED; restoration again returned full equality. These expected RED observations were caught explicitly and recorded, not suppressed scientific failures. Original source573 remained byte-identical. Original seam consumedsource/controls/stdout/stderr/exit files are `/tmp/l1-coupled-evaluator-r2-seam.*`; stdoutSHA `b3cc554ce34a8900029e40d41cd6887d3d8b1464fa516be4400b44ee93921525`. Across all18 children there are32 unrestricted preparation executions representing30 distinct word/branch pairs, plus2 fixed branch0 preparations. All18 child exits and consumed source/control bindings have now been audited.
