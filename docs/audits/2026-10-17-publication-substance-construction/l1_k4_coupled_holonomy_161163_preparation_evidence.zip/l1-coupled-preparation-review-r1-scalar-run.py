from pathlib import Path
import subprocess,json,time,hashlib
prefix=Path('/tmp/l1-coupled-preparation-review-r1');p=Path('/tmp')
for name,original in [('source','l1-coupled-evaluator-r2-source.py'),('math','l1-coupled-holonomy-independent-r1-math.py')]:Path(str(prefix)+'-consumed-'+name+'.py').write_bytes((p/original).read_bytes())
argv=['/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python','-B',str(prefix)+'-scalar.py'];t=time.monotonic()
try:
 r=subprocess.run(argv,capture_output=True,timeout=30);stdout=r.stdout;stderr=r.stderr;code=r.returncode;timeout=False
except subprocess.TimeoutExpired as e:stdout=e.stdout or b'';stderr=e.stderr or b'';code=None;timeout=True
Path(str(prefix)+'-scalar.stdout').write_bytes(stdout);Path(str(prefix)+'-scalar.stderr').write_bytes(stderr)
receipt={'argv':argv,'exit':code,'timeout':timeout,'seconds':time.monotonic()-t,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'checker_sha256':hashlib.sha256(Path(str(prefix)+'-scalar.py').read_bytes()).hexdigest()};Path(str(prefix)+'-scalar-exit.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));print(stdout.decode());print(stderr.decode())
