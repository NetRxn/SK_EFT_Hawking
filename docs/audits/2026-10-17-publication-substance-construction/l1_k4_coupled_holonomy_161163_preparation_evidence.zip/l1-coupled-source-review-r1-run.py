from pathlib import Path
import subprocess,time,json,hashlib
base=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research');py=str(base/'SK_EFT_Hawking/.venv/bin/python');prefix=Path('/tmp/l1-coupled-source-review-r1');receipts=[]
commands=[('continuity',[py,'-B',str(base/'.publication-l1-checkpoint-20261103/scripts/codex_continuity.py'),'check',str(base/'SK_EFT_Hawking/.codex/continuity/l1-coupled-source-review-r1.json')]),('local',[py,'-B',str(prefix)+'-check.py'])]
for name,argv in commands:
 start=time.monotonic();r=subprocess.run(argv,cwd=base/'.publication-l1-checkpoint-20261103',capture_output=True,text=True,timeout=30)
 Path(str(prefix)+'-'+name+'.stdout').write_text(r.stdout);Path(str(prefix)+'-'+name+'.stderr').write_text(r.stderr)
 receipts.append({'name':name,'argv':argv,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr})
Path(str(prefix)+'-receipts.json').write_text(json.dumps(receipts,indent=2));print(json.dumps(receipts))
