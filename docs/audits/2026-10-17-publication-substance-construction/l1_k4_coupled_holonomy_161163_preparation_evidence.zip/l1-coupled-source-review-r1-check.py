import signal, ast, hashlib, importlib.util, json, math, collections
from pathlib import Path
from fractions import Fraction
from itertools import product
signal.alarm(30)
p=Path('/tmp/l1-coupled-evaluator-r2-source.py'); digest=hashlib.sha256(p.read_bytes()).hexdigest()
assert digest=='5736258f9fe63fe246fb98df8827ac16d4fe1a933439723b92ebbcceb1bba6e7'
spec=importlib.util.spec_from_file_location('reviewed',p); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
functions={n.name for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
assert functions=={'geometry','data','component_key','occurrence_key','curvature_factors','branches','prepare','source_hashes'}
results=[]
for index,omitted,changes in [(161,6,[(2,(0,2)),(3,(0,2)),(7,(0,3)),(14,(1,3))]),(163,7,[(2,(0,2)),(3,(0,2)),(6,(0,3)),(15,(1,3))])]:
 row={'index':index,'axes':(2,2),'omitted':omitted,'changes':changes};g=m.geometry(row);shift=index==163
 assert g.roles['H'] not in g.fixed and (g.roles['H'][0]^(1<<g.roles['H'][1]),g.roles['H'][1]) in g.sources
 assert g.fixed_action=={(1^shift,3^shift,1):1,(3^shift,7^shift,2):1}
 assert g.divisor==192**43*4**64*48**10*2**15
 branches=list(m.branches(g));assert len(branches)==15
 assert [w for w,c in branches]==[Fraction(1,256)]+sum(([Fraction(-1,559872)]+[Fraction(2 if a==b else 1,279936) for a in range(t,t+3) for b in range(a,t+3)] for t in (0,3)),[])
 for w,core in branches:
  assert len(core)==4 and all(core.values())
  assert all(q in g.frame for q in core)
 incidence=collections.Counter();order=(('H','K'),('J',),('L','H'),('M','N','J'),('N','H','M','L'))
 for f,names in zip(g.coupled,order):
  boundary={(f[0],f[1]),(f[0]^(1<<f[1]),f[2]),(f[0]^(1<<f[2]),f[1]),(f[0],f[2])}
  assert boundary-set(g.fixed)=={g.roles[n] for n in names}
  incidence.update(names)
 assert incidence=={'H':3,'K':1,'J':2,'L':2,'M':2,'N':2}
 changed=set(g.fixed_action)|{(5^shift,7^shift,1)}
 routing=[]
 for edge in sorted(changed):
  keys=g.edges[edge];assert len(keys)==1
  q,a=keys[0];assert q==edge[0] and g.frame[q].index(a)==1
  routing.append({'edge':edge,'label':keys[0],'center_flag':int(q==edge[1]),'anchor_flag':1})
 results.append({'word':index,'centers':len(g.frame),'edges':len(g.edges),'sources':g.sources,'forest':sorted(g.forest),'H':g.roles['H'],'routing':routing,'branch_weights':[str(w) for w,c in branches],'scalar_incidence':dict(incidence)})
# Independent factorial Dirichlet moments, no author's scalar factor construction.
def haar(coords):
 counts=collections.Counter(coords);v=Fraction(1)
 for start in (0,4):
  exps=[counts[j] for j in range(start,start+4)]
  if any(n%2 for n in exps):return Fraction(0)
  halves=[n//2 for n in exps];s=sum(halves)
  v*=Fraction(math.prod(math.factorial(2*n)//(4**n*math.factorial(n)) for n in []),1) if False else Fraction(math.prod(math.factorial(2*n) for n in halves),4**s*math.prod(math.factorial(n) for n in halves)*math.factorial(s+1))
 return v
hist=collections.Counter()
for a,b,c in product(m.PAIRS,repeat=3):
 coords=a+b+c;expected=192*haar(coords);assert expected.denominator==1
 actual=m.moment(tuple(sorted(coords)));assert actual==expected
 if actual:hist[actual]+=1
assert hist=={1:168,2:1008,3:144,6:192,15:8}
for a in m.PAIRS:
 rows=dict(m.HAAR[a])
 for j,b in enumerate(m.PAIRS):assert rows.get(j,0)==48*haar(a+b)
print(json.dumps({'sha256':digest,'geometry':results,'sixth_histogram':dict(hist),'sixth_entries_checked':36**3,'fourth_entries_checked':36**2,'source_hashes':m.source_hashes(),'no_prepare_or_curvature_factors_called':True},sort_keys=True))
