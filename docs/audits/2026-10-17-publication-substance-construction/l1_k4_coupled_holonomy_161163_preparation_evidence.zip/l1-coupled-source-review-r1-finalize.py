from pathlib import Path
import subprocess,time,json,hashlib,re
base=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research');repo=base/'.publication-l1-checkpoint-20261103';audit=repo/'docs/audits/2026-10-17-publication-substance-construction';prefix=Path('/tmp/l1-coupled-source-review-r1');py=str(base/'SK_EFT_Hawking/.venv/bin/python')
receipts=json.loads(Path(str(prefix)+'-receipts.json').read_text());local=json.loads(receipts[1]['stdout'])
refs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [audit/'l1_k4_coupled_holonomy_161163_design.md',audit/'l1_k4_coupled_holonomy_161163_design_review.md',Path('/tmp/l1-coupled-evaluator-r2-source.py')]}
assert refs['l1_k4_coupled_holonomy_161163_design.md']=='b9ccad542317211e6da55cac2dba62d2e46495691103d3839dbc206510491ccd'
assert refs['l1_k4_coupled_holonomy_161163_design_review.md']=='61eea1082c0f4d2514e2d30a142cf4180d217674edf59a76006e19393559d6bd'
for name,digest in local['source_hashes'].items():
 if name!='evaluator': assert ('"'+name+'": "'+digest+'"') in (audit/'l1_k4_coupled_holonomy_161163_design.md').read_text()
final=[]
for name,argv in [('head',['git','rev-parse','HEAD']),('status',['git','status','--porcelain=v1']),('continuity',[py,'-B',str(repo/'scripts/codex_continuity.py'),'check',str(base/'SK_EFT_Hawking/.codex/continuity/l1-coupled-source-review-r1.json')])]:
 t=time.monotonic();r=subprocess.run(argv,cwd=repo,capture_output=True,text=True,timeout=30);final.append({'name':name,'argv':argv,'exit':r.returncode,'seconds':time.monotonic()-t,'stdout':r.stdout,'stderr':r.stderr})
 assert r.returncode==0
assert final[0]['stdout'].strip()=='531f89f59136c7a23b24ad036e11f77fc2593c62' and final[1]['stdout']=='' and json.loads(final[2]['stdout'])['fresh']
Path(str(prefix)+'-final-receipts.json').write_text(json.dumps(final,indent=2))
report={'verdict':'ACCEPT_SOURCE_ONLY','required_corrections':[],'source_sha256':local['sha256'],'candidate_head':final[0]['stdout'].strip(),'candidate_clean':True,'continuity_initial_native':json.loads(receipts[0]['stdout']),'continuity_final_native':json.loads(final[2]['stdout']),'references_sha256':refs,'executed_receipts':str(prefix)+'-receipts.json','final_receipts':str(prefix)+'-final-receipts.json','local_results':local,'scope':'Full frozen source plus canonical helper source audit, bounded geometry/branch/domain/moment checks. No prepare(), curvature_factors(), elimination, full scalar or action contraction invoked.','open_gates':['Actual nonidentity forest source/action/spinor covariance','Complete all15branch prepared tables and induced signed XOR1 comparison','Independent implicit tensor selected-slice equality and bounded fixed contraction acceptance','Separate runtime admission and complete cold600/warm60whole/parent665 bounded contraction','Independent reconstruction/replay and portable CLI acceptance','Full k4 population, full derivative-normalized ensemble/common partition/physical B3/window/modes/matter/transport/main/publication'],'coverage':236,'coverage_denominator':272,'artifact_hashes':{Path(str(prefix)+s).name:hashlib.sha256(Path(str(prefix)+s).read_bytes()).hexdigest() for s in ['-check.py','-run.py','-receipts.json','-final-receipts.json']}}
Path(str(prefix)+'-review.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'verdict':report['verdict'],'references_sha256':refs,'final_checks':final,'report':str(prefix)+'-review.json'}))
