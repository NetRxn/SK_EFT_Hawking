from pathlib import Path
import subprocess,json,time,hashlib
P=Path('/tmp');C=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103');A=C/'docs/audits/2026-10-17-publication-substance-construction';script=P/'l1-coupled-covariance-independent-r1-control.py';EXE='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p):sha(p) for p in A.glob('l1_*.py')};tasks=[]
for word,omitted in ((161,6),(163,7)):
 tasks.extend([['source',str(word)],['jacobian',str(word)]])
 tasks.extend([['action',str(word),str(q)] for q in range(16) if q!=omitted])
tasks.append(['coframe-basis','161']);records=[]
for args in tasks:
 label='-'.join(args)+'-r4';prefix=P/('l1-coupled-covariance-independent-r1-'+label)
 if prefix.with_suffix('.exit.json').exists():
  ex=json.loads(prefix.with_suffix('.exit.json').read_text());assert ex['exit']==0 and ex['checker_sha256']==sha(script)
 else:
  assert not prefix.with_suffix('.out').exists() and not prefix.with_suffix('.err').exists();argv=[EXE,'-B',str(script),*args];start=time.perf_counter();timeout=False
  try:r=subprocess.run(argv,capture_output=True,text=True,timeout=30);stdout,stderr,code=r.stdout,r.stderr,r.returncode
  except subprocess.TimeoutExpired as e:timeout=True;stdout=e.stdout or b'';stderr=e.stderr or b'';stdout=stdout.decode() if isinstance(stdout,bytes) else stdout;stderr=stderr.decode() if isinstance(stderr,bytes) else stderr;code=124
  elapsed=time.perf_counter()-start;prefix.with_suffix('.out').write_text(stdout);prefix.with_suffix('.err').write_text(stderr);ex={'argv':argv,'exit':code,'parent_seconds':elapsed,'timeout':timeout,'checker_sha256':sha(script)};prefix.with_suffix('.exit.json').write_text(json.dumps(ex,indent=2)+'\n')
 assert ex['exit']==0 and not ex['timeout'] and ex['parent_seconds']<30 and not prefix.with_suffix('.err').read_bytes(),(args,ex,prefix.with_suffix('.err').read_text())
 result=json.loads(prefix.with_suffix('.out').read_text());records.append({'exit_receipt':ex,'result':result,'prefix':str(prefix)});print('PASS '+' '.join(args),flush=True)
assert all(sha(Path(p))==h for p,h in inputs.items())
result={'scope':'Original local source/coframe/curvature action and forest gauge covariance, no full contraction or implementation acceptance','records':records,'commands':len(records),'current_source_hashes':inputs,'all_source_bytes_unchanged':True,'checker_sha256':sha(script),'max_parent_seconds':max(x['exit_receipt']['parent_seconds'] for x in records)};(P/'l1-coupled-covariance-independent-r1-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'commands':len(records),'max_parent_seconds':result['max_parent_seconds'],'all_source_bytes_unchanged':True}),flush=True)
