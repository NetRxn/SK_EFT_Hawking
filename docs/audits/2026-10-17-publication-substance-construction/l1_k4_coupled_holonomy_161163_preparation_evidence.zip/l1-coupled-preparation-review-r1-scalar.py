from pathlib import Path
import ast,hashlib,signal,importlib.util,json
from collections import Counter
from itertools import product
signal.alarm(30)
P=Path('/tmp');prefix=P/'l1-coupled-preparation-review-r1'
p=Path(str(prefix)+'-consumed-source.py');assert hashlib.sha256(p.read_bytes()).hexdigest()=='5736258f9fe63fe246fb98df8827ac16d4fe1a933439723b92ebbcceb1bba6e7'
spec=importlib.util.spec_from_file_location('actual',p);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
mathp=Path(str(prefix)+'-consumed-math.py');assert hashlib.sha256(mathp.read_bytes()).hexdigest()=='24eeb4ed2af4a5654a194c6a30eb073d75238c9452dc0078d4afdafcb0ad9577'
tree=ast.parse(mathp.read_text());cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mode' for t in n.targets));ns={};exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(mathp),'exec'),ns)
PAIRS=ns['PAIRS'];COMPS=ns['COMPS'];FACES=ns['FACES'];ownpoly=ns['facepoly'];four=ns['four'];six=ns['six']
assert PAIRS==c.PAIRS and COMPS==c.COMPONENTS
results=[]
for index,omitted,changes in [(161,6,[(2,(0,2)),(3,(0,2)),(7,(0,3)),(14,(1,3))]),(163,7,[(2,(0,2)),(3,(0,2)),(6,(0,3)),(15,(1,3))])]:
 shift=int(index==163);g=c.geometry({'index':index,'omitted':omitted,'changes':changes,'axes':(2,2)})
 actual,descriptors,probe=c.curvature_factors(g);expected=[];incidence={}
 locations=[7,1,5,9,13];links={'H':(5,2),'K':(7,1),'J':(9,2),'L':(13,2),'M':(9,3),'N':(13,3)}
 for j,(q,names) in enumerate(zip(locations,FACES)):
  axes=(('component',q^shift),)+tuple(('occurrence',q^shift,links[n][0]^shift,links[n][1]) for n in names)
  rows={(comp,)+tuple(PAIRS[k] for k in key):{0:(weight,0)} for comp in COMPS for key,weight in ownpoly(j,comp).items()}
  expected.append((axes,rows,{}))
  for n,a in zip(names,axes[1:]):incidence.setdefault(n,[]).append(a)
 for name in ('J','L','M','N'):
  rows={(PAIRS[a],PAIRS[b]):{0:(v,0)} for a,b in product(range(36),repeat=2) if (v:=four(a,b))};expected.append((tuple(incidence[name]),rows,{}))
 rows={(PAIRS[a],PAIRS[b],PAIRS[d]):{0:(v,0)} for a,b,d in product(range(36),repeat=3) if (v:=six(a,b,d))};expected.append((tuple(incidence['H']),rows,{}))
 assert actual==expected,index
 assert descriptors==[('face',n) for n in ('square','torus1','torus5','torus9','torus13')]+[('moment4',n) for n in ('J','L','M','N')]+[('moment6','H')]
 assert probe==incidence['K'][0]
 counts=Counter(a for axes,rows,degrees in actual for a in axes)
 assert all(counts[a]==(1 if a[0]=='component' or a==probe else 2) for a in counts)
 for q in locations:counts['component',q^shift]+=1
 counts[probe]+=1;assert set(counts.values())=={2}
 results.append({'word':index,'actual_full_factor_dictionaries_equal':True,'factor_count':len(actual),'row_counts':[len(f[1]) for f in actual],'rows':sum(len(f[1]) for f in actual),'distinct_scalar_axes':len(counts),'host_completed_multiplicity2':True,'probe':probe,'dictionary_sha256':hashlib.sha256(repr(expected).encode()).hexdigest()})
print(json.dumps({'results':results,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'independent_math_sha256':hashlib.sha256(mathp.read_bytes()).hexdigest(),'no_action_preparation_or_contraction':True},sort_keys=True))
