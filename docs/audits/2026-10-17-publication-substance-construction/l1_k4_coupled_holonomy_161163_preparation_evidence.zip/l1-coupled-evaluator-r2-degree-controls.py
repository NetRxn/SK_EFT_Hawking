"""Bounded table/preparation observations only; never calls an eliminator."""
import sys,signal,importlib.util,json,hashlib
from pathlib import Path
from collections import Counter
signal.alarm(30)
spec=importlib.util.spec_from_file_location('coupled','/tmp/l1-coupled-evaluator-r2-source.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def map_axis(a):
 if len(a)==2 and type(a[0]) is int:return (a[0]^1,a[1])
 if a[0]=='component':return (a[0],a[1]^1)
 assert a[0]=='occurrence';return(a[0],a[1]^1,a[2]^1,a[3])
def map_role(r):
 if r[0]=='center':return(r[0],r[1]^1)
 if r[0]=='source':return(r[0],r[1]^1,r[2])
 if r[0]=='action':
  lo,hi,a=r[1];return(r[0],tuple(sorted((lo^1,hi^1)))+(a,))
 return r

def signed_mask(mask):
 indices=[i for i in range(128) if mask>>i&1]
 image=[8*((i//8)^1)+i%8 for i in indices]
 parity=sum(a>b for i,a in enumerate(image) for b in image[i+1:])%2
 return sum(1<<i for i in image),(-1 if parity else 1)

def compare(a,b):
 assert a.divisor==b.divisor
 assert {map_axis(x) for x in a.exclusive}==b.exclusive
 right=dict(zip(b.roles,b.factors,strict=True));rowcount=termcount=negative=0
 for role,(axes,rows,degrees) in zip(a.roles,a.factors,strict=True):
  other,expected,deg=right[map_role(role)]
  images=tuple(map_axis(x) for x in axes);assert set(images)==set(other)
  reorder=tuple(images.index(x) for x in other)
  assert {q^1:d for q,d in degrees.items()}==deg
  transformed={}
  for key,poly in rows.items():
   newkey=tuple(key[i] for i in reorder);newpoly={}
   for mask,(r,i) in poly.items():
    mapped,sign=signed_mask(mask);negative+=int(sign<0);newpoly[mapped]=(sign*r,sign*i)
   transformed[newkey]=newpoly;rowcount+=1;termcount+=len(poly)
  assert transformed==expected,role
 return dict(factors=47,rows=rowcount,terms=termcount,negative_mask_sign_terms=negative)

def monomial_support_degrees(p):
 """Inspect every actual monomial; metadata alone is never its witness."""
 assert p is not None and len(p.factors)==len(p.roles)
 totals={'factors':0,'rows':0,'monomials':0,'nonzero_masks':0}
 by_role={}
 for role,(axes,rows,degrees) in zip(p.roles,p.factors,strict=True):
  assert isinstance(degrees,dict)
  assert all(type(q) is int and 0<=q<16 and type(d) is int and 0<d<=8 for q,d in degrees.items()),('degree_metadata',role)
  if role[0] in ('center','face','moment4','moment6'):assert not degrees,('scalar_metadata',role)
  allowed=sum(255<<(8*q) for q in degrees)
  count=0;nonzero=0
  for key,poly in rows.items():
   assert poly,('empty_polynomial',role,key)
   for mask,coefficient in poly.items():
    assert type(mask) is int and 0<=mask<(1<<128),('mask_range',role,key,mask)
    assert mask&~allowed==0,('undeclared_site_support',role,key,mask)
    if not degrees:assert mask==0,('scalar_mask',role,key,mask)
    for q,d in degrees.items():
     assert ((mask>>(8*q))&255).bit_count()==d,('monomial_degree',role,key,q,d,mask)
    count+=1;nonzero+=int(mask!=0)
  item=by_role.setdefault(role[0],{'factors':0,'rows':0,'monomials':0,'nonzero_masks':0})
  for target in (totals,item):
   target['factors']+=1;target['rows']+=len(rows);target['monomials']+=count;target['nonzero_masks']+=nonzero
 return {'totals':totals,'by_role':by_role,'mask_range_below_2pow128':True,'support_only_declared_sites':True,'all_declared_popcounts_exact':True,'scalar_center_masks_zero':True}

def degree_fixtures():
 def table(mask,degrees,kind='action'):
  return c.Prepared([((),{():{mask:(1,0)}},degrees)],1,set(),[(kind,'fixture')])
 mask=3|(3<<8)
 baseline=monomial_support_degrees(table(mask,{0:2,1:2}))
 cases=[('wrong_degree',table(mask,{0:3,1:2}),'monomial_degree'),
        ('wrong_support',table((mask^1)|(1<<16),{0:2,1:2}),'undeclared_site_support'),
        ('too_high_mask',table(1<<128,{0:2}),'mask_range'),
        ('negative_mask',table(-1,{0:2}),'mask_range'),
        ('nonzero_scalar',table(1,{},'center'),'undeclared_site_support')]
 red={}
 for name,p,expected in cases:
  try:monomial_support_degrees(p)
  except AssertionError as e:
   assert e.args and e.args[0][0]==expected,(name,e.args)
   red[name]={'result':'RED as required','reason':expected}
  else:raise AssertionError(('fixture_escaped',name))
 restored=monomial_support_degrees(table(mask,{0:2,1:2}))
 assert baseline==restored
 return {'baseline':baseline,'poisons':red,'restored':restored}

def describe(p):
 if p is None:return {'algebraically_empty':True}
 return dict(monomial_support_degree_readback=monomial_support_degrees(p),factors=len(p.factors),factor_kinds=dict(Counter(r[0] for r in p.roles)),rows=sum(len(f[1]) for f in p.factors),terms=sum(sum(map(len,f[1].values())) for f in p.factors),max_factor_terms=max(sum(map(len,f[1].values())) for f in p.factors),label_count=len(set(k for f in p.factors for k in f[0])),degree8_all_sites=True,each_label_twice=True,divisor=p.divisor)

mode=sys.argv[1];found={} if mode=='degree-fixtures' else c.data();out={'mode':mode,'source_hashes':c.source_hashes()}
if mode=='degree-fixtures':
 out['fixtures']=degree_fixtures()
elif mode=='local':
 for i,(row,g) in found.items():
  f,roles,k=c.curvature_factors(g);out[str(i)]={'factors':len(f),'rows':[len(x[1]) for x in f],'total_rows':sum(len(x[1]) for x in f),'branch_weights':[[w.numerator,w.denominator] for w,core in c.branches(g)]}
 assert out['161']['rows']==out['163']['rows']==[300,21,300,4200,57168,92,92,92,92,1520]
elif mode=='seam':
 prepared=[]
 for i in (161,163):
  row,g=found[i];weight,core=list(c.branches(g))[0];prepared.append(c.prepare(g,core))
 a,b=prepared
 out['baseline']=compare(a,b)
 assert signed_mask((1<<0)|(1<<8))==((1<<0)|(1<<8),-1)
 assert signed_mask(3|(3<<8))==(3|(3<<8),1)
 out['negative_mask_fixture']={'mask':257,'mapped':257,'sign':-1}
 selected=next(j for j,role in enumerate(b.roles) if role[0]=='action')
 rows=b.factors[selected][1];key=next(iter(rows));original=rows[key];mask=next(iter(original));r,i=original[mask]
 poisoned=dict(original);poisoned[mask]=(r+1,i);rows[key]=poisoned
 try:compare(a,b)
 except AssertionError as e:out['wrong_coefficient']='RED as required: '+str(e)
 else:raise AssertionError('coefficient poison escaped')
 finally:rows[key]=original
 out['coefficient_restored']=compare(a,b)
 poisoned=dict(original);value=poisoned.pop(mask);poisoned[mask^1]=value;rows[key]=poisoned
 try:compare(a,b)
 except AssertionError as e:out['wrong_mask']='RED as required: '+str(e)
 else:raise AssertionError('mask poison escaped')
 finally:rows[key]=original
 out['mask_restored']=compare(a,b)
elif mode in ('prepare','xor'):
 branch=int(sys.argv[2]);fixed=(sys.argv[3]=='fixed');indices=(161,163) if mode=='xor' else (int(sys.argv[4]),)
 prepared=[]
 for i in indices:
  row,g=found[i];weight,core=list(c.branches(g))[branch]
  p=c.prepare(g,core,dict.fromkeys(g.frame,c.k3.witness.FIXED_GAMMAS) if fixed else None)
  out[str(i)]={'weight':[weight.numerator,weight.denominator],**describe(p)};prepared.append(p)
 if mode=='xor':
  if any(p is None for p in prepared):assert all(p is None for p in prepared);out['comparison']='both_algebraically_empty'
  else:out['comparison']=compare(*prepared)
else:raise ValueError(mode)
print(json.dumps(out,sort_keys=True))
