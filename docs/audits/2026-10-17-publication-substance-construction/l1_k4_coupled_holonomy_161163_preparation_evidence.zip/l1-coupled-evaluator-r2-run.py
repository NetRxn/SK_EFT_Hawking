"""Capture one explicitly selected bounded local/preparation attempt."""
import subprocess,sys,time,json,hashlib
from pathlib import Path
prefix=Path('/tmp/l1-coupled-evaluator-r2-'+sys.argv[1]);args=sys.argv[2:]
for kind in ('source','controls'):
 data=Path('/tmp/l1-coupled-evaluator-r2-'+kind+'.py').read_bytes();prefix.with_suffix('.'+kind+'.py').write_bytes(data)
command=['/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python','-B','/tmp/l1-coupled-evaluator-r2-controls.py',*args]
start=time.perf_counter()
try:
 r=subprocess.run(command,capture_output=True,timeout=30);code=r.returncode;stdout=r.stdout;stderr=r.stderr;timeout=False
except subprocess.TimeoutExpired as e:
 code=None;stdout=e.stdout or b'';stderr=e.stderr or b'';timeout=True
prefix.with_suffix('.stdout').write_bytes(stdout);prefix.with_suffix('.stderr').write_bytes(stderr)
receipt=dict(argv=command,exit_code=code,timeout=timeout,parent_seconds=time.perf_counter()-start,source_sha256=hashlib.sha256(Path('/tmp/l1-coupled-evaluator-r2-source.py').read_bytes()).hexdigest(),controls_sha256=hashlib.sha256(Path('/tmp/l1-coupled-evaluator-r2-controls.py').read_bytes()).hexdigest(),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest())
prefix.with_suffix('.exit.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));print(stdout.decode());print(stderr.decode())
