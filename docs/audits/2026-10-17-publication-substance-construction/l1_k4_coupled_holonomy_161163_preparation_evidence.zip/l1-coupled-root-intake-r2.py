from pathlib import Path
from hashlib import sha256
import json
root=Path('/tmp');v=json.loads((root/'l1-coupled-evaluator-r2-sourcecontract.json').read_text())
assert len(v['attempts'])==18
for attempt in v['attempts']:
 name=attempt['name'];base=root/('l1-coupled-evaluator-r2-'+name);r=json.loads(Path(str(base)+'.exit.json').read_text());assert r==attempt['receipt'] and r['exit_code']==0 and not r['timeout']
 assert sha256(Path(str(base)+'.source.py').read_bytes()).hexdigest()==r['source_sha256']==v['source_sha256']
 assert sha256(Path(str(base)+'.controls.py').read_bytes()).hexdigest()==r['controls_sha256']
 out=Path(str(base)+'.stdout').read_bytes();err=Path(str(base)+'.stderr').read_bytes();assert not err and sha256(out).hexdigest()==r['stdout_sha256'] and sha256(err).hexdigest()==r['stderr_sha256'];actual=json.loads(out); assert actual.pop('source_hashes')==v['source_hashes']; assert actual==attempt['observations']
assert sorted(int(x['name'].removeprefix('unrestricted')) for x in v['attempts'] if x['name'].startswith('unrestricted'))==list(range(15))
print({'actual_old_children':18,'all_consumed_source_control_streams_bound':True,'all_individual_exit_zero':True,'all15_unrestricted_branch_indices':True,'max_seconds':v['max_parent_seconds']})
