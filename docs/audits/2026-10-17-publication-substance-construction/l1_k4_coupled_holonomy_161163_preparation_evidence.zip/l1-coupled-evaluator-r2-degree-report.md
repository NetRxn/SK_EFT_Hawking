# Coupled161/163 actual-monomial degree execution handback

Author observations only; independent prepared-data acceptance remains assigned to the source peer. No contraction or physical coefficient is claimed. Coverage remains236/272.

Fresh degree-execution packet was checked first. Only admitted immutable source5736258f, degree controlscfcca680 and driver84a8a1 were executed; prior source/controls/all18 attempt bindings and bytes were independently rechecked unchanged. No tracked/notebook/Git/slot/runtime/configuration change occurred.

The admitted degree-fixtures child exited0/empty stderr in0.187276667s. Positive baseline/restored fixtures pass; wrongdegree, wrongsupport, negative/out-of-range masks and nonzero scalar mask each produced the required RED reason. These were deliberate detected fixtures, not failed scientific children.

All15 admitted sequential unrestricted preparation children exited0 with empty stderr and no timeout; every scientific receipt, consumed source/control/stdout/stderr hash and payload was audited before its successor. Largest parent duration 27.026149291s, below the unchanged30s per-child bound. Every child constructs BOTH161/163 and compares all47 factors under the complete signed128-generator physical-site XOR1 mask permutation.

Every actual factor-row monomial was inspected: integer0≤mask<2^128, zero bits outside declared sites, exact declared per-site popcounts, and scalar/center mask0. Across30 complete word/branch preparations, this scanned1986726 rows and2962818 monomials, including1008912 nonzero masks. Every preparation retains47 factors/47 twice-used labels, the full original16-site degree8 metadata and the unchanged raw divisor192^43*4^64*48^10*2^15. The former metadata-versus-actual-mask gap is therefore closed at author observation scope.

| Branch | Scientific child | Parent s | Rows per word | Monomials per word | Actual degree/support/range and signed XOR1 |
|---:|---|---:|---:|---:|---|
|0|exit0, empty stderr|26.431727|66253|99631|PASS, both words|
|1|exit0, empty stderr|25.822440|66253|99631|PASS, both words|
|2|exit0, empty stderr|25.658956|66237|99615|PASS, both words|
|3|exit0, empty stderr|25.878597|66197|96511|PASS, both words|
|4|exit0, empty stderr|25.945954|66197|97951|PASS, both words|
|5|exit0, empty stderr|26.651244|66237|99615|PASS, both words|
|6|exit0, empty stderr|26.429809|66197|97951|PASS, both words|
|7|exit0, empty stderr|26.445114|66237|99615|PASS, both words|
|8|exit0, empty stderr|27.026149|66253|99631|PASS, both words|
|9|exit0, empty stderr|26.249725|66237|99615|PASS, both words|
|10|exit0, empty stderr|26.020236|66197|96511|PASS, both words|
|11|exit0, empty stderr|26.665809|66197|97951|PASS, both words|
|12|exit0, empty stderr|25.989850|66237|99615|PASS, both words|
|13|exit0, empty stderr|25.938243|66197|97951|PASS, both words|
|14|exit0, empty stderr|26.368296|66237|99615|PASS, both words|

Complete role counts and all original receipt/payload records are in `/tmp/l1-coupled-evaluator-r2-degree-evidence.json`. Original files are `/tmp/l1-coupled-evaluator-r2-degree-fixtures.*` and `...-degree-unrestricted0.*` through `...-degree-unrestricted14.*`: consumed source/control snapshots, original stdout/stderr, terminal exit JSON, and preparation driver runlogs. Exact scientific source/control/driver SHA256 bindings are in the evidence. Existing prior18 attempt files, sourcecontract and report were not rewritten.

The independently accepted finite-word nonidentity covariance bridge is separate. Gauge-fix the complete internally summed original action/source word first; subsequent fixed-gamma restrictions are numerical diagnostics and need not each be gauge-invariant. This batch measures actual masks/degrees and physical-site XOR1, not a replacement Ward identity. No fixed-label/scalar/full contraction, intermediate join support, runtime feasibility or new execution admission follows.

Next the source peer independently reviews these exact actual prepared-data observations and their source/receipt bindings. Any scalar/fixed contraction still needs separate execution admission under original120000row/3000000pair and600cold/ONE60whole warm/665parent bounds. Fullk4/source-action ensemble/common partition, physicalB3/window, microscopic modes/matter coupling, transport, main/human/publication remain open.

Evidence SHA256 `b9a41769c75dc95b5340c52b588ba6621e40f5d85a00accb0516751a92070f62`.
