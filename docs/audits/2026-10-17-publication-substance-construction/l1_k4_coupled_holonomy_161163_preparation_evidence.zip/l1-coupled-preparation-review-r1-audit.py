from pathlib import Path
import hashlib,json,zipfile,ast
P=Path('/tmp');prefix=P/'l1-coupled-preparation-review-r1';sha=lambda b:hashlib.sha256(b).hexdigest()
contract=P/'l1-coupled-evaluator-r2-sourcecontract.json';assert sha(contract.read_bytes())=='cd3c67b4e64cb6bb9af1b5d33f6cfd701c6a6de1d0d892fdc3a8399e8438bd05'
x=json.loads(contract.read_bytes());assert len(x['attempts'])==18
names=['local','fixed0']+['unrestricted'+str(i) for i in range(15)]+['seam'];assert [a['name'] for a in x['attempts']]==names
bindings={};observations=[]
with zipfile.ZipFile(str(prefix)+'-consumed.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in [contract,P/'l1-coupled-evaluator-r2-report.md',P/'l1-coupled-evaluator-r2-run.py',P/'l1-coupled-evaluator-r2-degree-controls.py',P/'l1-coupled-evaluator-r2-degree-run.py',P/'l1-coupled-holonomy-independent-r1-math.py']:
  data=p.read_bytes();z.writestr(p.name,data);bindings[p.name]=sha(data)
 for a in x['attempts']:
  stem=P/('l1-coupled-evaluator-r2-'+a['name']);payload={}
  for suffix in ['source.py','controls.py','stdout','stderr','exit.json']:
   p=Path(str(stem)+'.'+suffix);data=p.read_bytes();payload[suffix]=data;z.writestr(p.name,data);bindings[p.name]=sha(data)
  r=json.loads(payload['exit.json']);assert r==a['receipt'] and r['exit_code']==0 and not r['timeout'] and r['parent_seconds']<30
  assert r['source_sha256']==sha(payload['source.py'])==x['source_sha256']
  controlsha='bbd74607ce156432d6b9f6ee5a80f6db8ef7bfd580535201789e55dadd64c31f' if a['name']=='seam' else 'ed66b3f27f2429984ed4750651b629dc211ca40ee94853afe5bc8968be8ea5ca'
  assert r['controls_sha256']==sha(payload['controls.py'])==controlsha
  assert r['stdout_sha256']==sha(payload['stdout']) and r['stderr_sha256']==sha(payload['stderr']) and payload['stderr']==b''
  d=json.loads(payload['stdout']);sources=d.pop('source_hashes');assert sources==x['source_hashes'];assert d==a['observations']
  tree=ast.parse(payload['controls.py']);assert not any(isinstance(t,ast.Call) and isinstance(t.func,ast.Attribute) and t.func.attr in ('eliminate','eliminate_components','solve','contraction') for t in ast.walk(tree))
  observations.append({'name':a['name'],'seconds':r['parent_seconds'],'rows':d.get('comparison',{}).get('rows'),'terms':d.get('comparison',{}).get('terms')})
  if a['name'].startswith('unrestricted') or a['name']=='fixed0':
   assert d['comparison']['factors']==47
   for word in ('161','163'):
    w=d[word];assert w['factors']==47 and w['label_count']==47 and w['degree8_all_sites'] and w['each_label_twice']
    assert w['factor_kinds']=={'action':20,'center':15,'face':5,'moment4':4,'moment6':1,'source':2}
    assert w['max_factor_terms']==57168 and w['rows']==d['comparison']['rows'] and w['terms']==d['comparison']['terms']
   assert d['161']==d['163']
  if a['name']=='seam':
   assert d['baseline']==d['coefficient_restored']==d['mask_restored']=={'factors':47,'negative_mask_sign_terms':0,'rows':66253,'terms':99631}
   assert d['negative_mask_fixture']=={'mapped':257,'mask':257,'sign':-1}
   assert d['wrong_mask'].startswith('RED as required:') and d['wrong_coefficient'].startswith('RED as required:')
assert bindings['l1-coupled-evaluator-r2-report.md']=='fa1912f83b2224368ae209a3c67b218c67e92667c0fe558a8ed3b42057d58f10'
assert bindings['l1-coupled-holonomy-independent-r1-math.py']=='24eeb4ed2af4a5654a194c6a30eb073d75238c9452dc0078d4afdafcb0ad9577'
result={'accepted_original_attempts':18,'all_sources_snapshots_streams_exits_exact':True,'full_unrestricted_word_branch_pairs':30,'unrestricted_executions_including_seam':32,'fixed_executions':2,'metadata_degree_not_actual_monomial_degree':True,'observations':observations,'bindings':bindings,'consumed_zip_sha256':sha(Path(str(prefix)+'-consumed.zip').read_bytes())}
Path(str(prefix)+'-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='bindings'}))
