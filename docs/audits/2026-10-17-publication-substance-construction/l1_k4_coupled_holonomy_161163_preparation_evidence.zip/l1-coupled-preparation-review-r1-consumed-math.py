from pathlib import Path
from collections import Counter,defaultdict
from functools import lru_cache
from fractions import Fraction
from itertools import combinations_with_replacement,product
from math import factorial
import signal,json,sys,time,hashlib
signal.alarm(30);start=time.perf_counter()
P=Path('/tmp');W=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research');A=W/'.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction'
PAIRS=tuple(combinations_with_replacement(range(8),2));COMPS=tuple(combinations_with_replacement(range(6),2));IX={p:i for i,p in enumerate(PAIRS)}
# Signed basis quaternion algebra, independently expressed as unit multiplication.
# Pair values give (basis index, sign); e1e2=e3, e2e3=e1, e3e1=e2.
def unitmul(a,b):
 if a==0:return b,1
 if b==0:return a,1
 if a==b:return 0,-1
 return 6-a-b, 1 if (a,b) in ((1,2),(2,3),(3,1)) else -1
FACES=(('H','K'),('J',),('L','H'),('M','N','J'),('N','H','M','L'))
DAGGERS=((False,False),(True,),(True,False),(True,False,False),(True,True,False,False))
@lru_cache(None)
def vectors(face):
 names=FACES[face];dag=DAGGERS[face];out=[{} for _ in range(6)]
 for cs in product(range(4),repeat=len(names)):
  u,sign=0,1
  for v,d in zip(cs,dag):
   u,s=unitmul(u,v);sign*=s*(-1 if d and v else 1)
  if u:
   for chirality in (0,1):out[3*chirality+u-1][tuple(4*chirality+v for v in cs)]=sign
 return out
@lru_cache(None)
def facepoly(face,comp):
 aa,bb=(vectors(face)[i] for i in comp);out=Counter()
 for a,u in aa.items():
  for b,v in bb.items():out[tuple(IX[tuple(sorted((x,y)))] for x,y in zip(a,b))]+=u*v
 return {k:v for k,v in out.items() if v}
# Dirichlet(1/2,...,1/2) normalized coordinate moments, written with factorials.
# This is independent of canonical double-factorial and author's raw moment helper.
@lru_cache(None)
def sphere(exponents):
 if any(n%2 for n in exponents):return Fraction()
 ks=[n//2 for n in exponents];s=sum(ks)
 numerator=1;denominator=4**s*factorial(s+1)
 for k in ks:numerator*=factorial(2*k);denominator*=factorial(k)
 return Fraction(numerator,denominator)
@lru_cache(None)
def avg(indices):
 counts=Counter(indices);return sphere(tuple(counts[i] for i in range(4)))*sphere(tuple(counts[i] for i in range(4,8)))
@lru_cache(None)
def four(a,b):
 v=48*avg(tuple(sorted(PAIRS[a]+PAIRS[b])));assert v.denominator==1;return v.numerator
@lru_cache(None)
def six(a,b,c):
 v=192*avg(tuple(sorted(PAIRS[a]+PAIRS[b]+PAIRS[c])));assert v.denominator==1;return v.numerator
# Integrate H and L FIRST across S,B,D. Author integrates J,M,N,L before H.
def slice_value(labels,wrong=False):
 S0,A0,B0,C0,D0=[facepoly(i,c) for i,c in enumerate(labels)]
 # Collapse J in (A,C) separately; result Q(M,N), raw scale48.
 Q=Counter()
 for (m,n,j),v in C0.items():
  w=sum(u*four(j,k[0]) for k,u in A0.items())
  if w:Q[m,n]+=v*w
 # H+L projection across S(H,K), B(L,H), D(N,H,M,L).
 # Memoize scalar projection in each D(H,L) slot and retained K.
 slots={(h,l) for n,h,m,l in D0};R={}
 for hd,ld in slots:
  out=Counter()
  for (hs,k),u in S0.items():
   for (lb,hb),v in B0.items():
    mh=192*avg(PAIRS[hs])*avg(PAIRS[hb])*avg(PAIRS[hd]) if wrong else six(hs,hb,hd)
    if mh:
     ml=four(lb,ld)
     if ml:out[k]+=u*v*mh*ml
  R[hd,ld]={k:v for k,v in out.items() if v}
 # Independently close M,N after H,L (not before H as in author's order).
 MN={}
 for n,h,m,l in D0:
  if (m,n) not in MN:MN[m,n]=sum(v*four(m,mc)*four(n,nc) for (mc,nc),v in Q.items())
 out=Counter()
 for (n,h,m,l),v in D0.items():
  q=MN[m,n]
  if q:
   for k,u in R[h,l].items():out[k]+=v*q*u
 return {str(PAIRS[k]):str(Fraction(v,48**4*192)) for k,v in sorted(out.items()) if v}
patterns=[((0,0),)*5,((0,1),(0,0),(0,1),(0,0),(0,0)),((0,3),)*5,((0,0),(0,0),(0,0),(3,3),(3,3)),((0,1),)*5,((0,3),(0,3),(0,3),(1,4),(1,4))]
mode=sys.argv[1]
if mode.startswith('slice'):
 i=int(mode[5:]);actual=slice_value(patterns[i]);wrong=slice_value(patterns[i],True);original=json.loads((P/'l1-coupled-holonomy-r1-controls.json').read_text())[i];expected=json.loads(original['stdout']);assert actual==expected['actual'] and wrong==expected['incorrect_independent_H'],(i,actual,expected)
 result={'mode':mode,'projection_order':'H+L first across S,B,D; J then M,N closure','pattern':patterns[i],'actual':actual,'incorrect_independent_H':wrong,'author_exact_equality':True}
elif mode=='moments':
 f=[(a,b,four(a,b)) for a,b in product(range(36),repeat=2) if four(a,b)];s=[(a,b,c,six(a,b,c)) for a,b,c in product(range(36),repeat=3) if six(a,b,c)]
 assert len(f)==92 and len(s)==1520 and Counter(x[-1] for x in s)=={1:168,2:1008,3:144,6:192,15:8}
 assert avg((0,)*6)==Fraction(5,64) and avg((0,0,1,1,2,2))==Fraction(1,192) and avg((0,0,0,0,4,4))==Fraction(1,32)
 # Different verification again: exhaustive coordinate-pairing recursion on all4096 ordered sector tuples.
 def pairings(indices):
  if not indices:return 1
  return sum(pairings(indices[1:j]+indices[j+1:]) for j in range(1,len(indices)) if indices[0]==indices[j])
 for inds in product(range(4),repeat=6):assert avg(tuple(sorted(inds)))==Fraction(pairings(inds),192)
 result={'mode':mode,'fourth_rows':len(f),'sixth_rows':len(s),'sixth_histogram':dict(Counter(x[-1] for x in s)),'ordered4096_pairing_checks':True,'pure_mixed_degree6_samples':True,'denominator':48**4*192}
elif mode=='support':
 counts={i:{'total_rows':sum(len(facepoly(i,c)) for c in COMPS),'max_component':max(len(facepoly(i,c)) for c in COMPS)} for i in range(5)}
 assert [counts[i]['total_rows'] for i in range(5)]==[300,21,300,4200,57168] and max(x['max_component'] for x in counts.values())==4096
 scalar=sum(x['total_rows'] for x in counts.values())+4*92+1520;assert scalar==63877
 # Every formal label in the proposed scalar network and host action/center interfaces occurs twice.
 labels=Counter();factors=[]
 for face,names in enumerate(FACES):
  ks=[('component',face)]+[('occurrence',face,v) for v in names];factors.append(ks);labels.update(ks)
 for name in ('J','L','M','N','H'):
  ks=[('occurrence',face,name) for face,variables in enumerate(FACES) if name in variables];assert len(ks)==(3 if name=='H' else 2);factors.append(ks);labels.update(ks)
 labels.update(('component',i) for i in range(5));labels.update([('occurrence',0,'K')]);assert set(labels.values())=={2}
 result={'mode':mode,'own_direct_holonomy_face_polynomial_counts':counts,'primitive_scalar_rows':scalar,'largest_factor_rows':57168,'largest_component_rows':4096,'every_component_occurrence_label_twice':True,'full_graph_factors':15+20+len(factors)+2,'runtime_feasibility':'UNMEASURED'}
else:raise AssertionError(mode)
result['seconds']=time.perf_counter()-start;print(json.dumps(result,sort_keys=True))
