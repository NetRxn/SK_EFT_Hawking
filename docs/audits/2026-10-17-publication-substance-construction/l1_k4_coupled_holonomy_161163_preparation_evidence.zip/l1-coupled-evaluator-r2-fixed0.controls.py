"""Bounded table/preparation observations only; never calls an eliminator."""
import sys,signal,importlib.util,json,hashlib
from pathlib import Path
from collections import Counter
signal.alarm(30)
spec=importlib.util.spec_from_file_location('coupled','/tmp/l1-coupled-evaluator-r2-source.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def map_axis(a):
 if len(a)==2 and type(a[0]) is int:return (a[0]^1,a[1])
 if a[0]=='component':return (a[0],a[1]^1)
 assert a[0]=='occurrence';return(a[0],a[1]^1,a[2]^1,a[3])
def map_role(r):
 if r[0]=='center':return(r[0],r[1]^1)
 if r[0]=='source':return(r[0],r[1]^1,r[2])
 if r[0]=='action':
  lo,hi,a=r[1];return(r[0],tuple(sorted((lo^1,hi^1)))+(a,))
 return r

def signed_mask(mask):
 indices=[i for i in range(128) if mask>>i&1]
 image=[8*((i//8)^1)+i%8 for i in indices]
 parity=sum(a>b for i,a in enumerate(image) for b in image[i+1:])%2
 return sum(1<<i for i in image),(-1 if parity else 1)

def compare(a,b):
 assert a.divisor==b.divisor
 assert {map_axis(x) for x in a.exclusive}==b.exclusive
 right=dict(zip(b.roles,b.factors,strict=True));rowcount=termcount=negative=0
 for role,(axes,rows,degrees) in zip(a.roles,a.factors,strict=True):
  other,expected,deg=right[map_role(role)]
  images=tuple(map_axis(x) for x in axes);assert set(images)==set(other)
  reorder=tuple(images.index(x) for x in other)
  assert {q^1:d for q,d in degrees.items()}==deg
  transformed={}
  for key,poly in rows.items():
   newkey=tuple(key[i] for i in reorder);newpoly={}
   for mask,(r,i) in poly.items():
    mapped,sign=signed_mask(mask);negative+=int(sign<0);newpoly[mapped]=(sign*r,sign*i)
   transformed[newkey]=newpoly;rowcount+=1;termcount+=len(poly)
  assert transformed==expected,role
 return dict(factors=47,rows=rowcount,terms=termcount,negative_mask_sign_terms=negative)

def describe(p):
 if p is None:return {'algebraically_empty':True}
 return dict(factors=len(p.factors),factor_kinds=dict(Counter(r[0] for r in p.roles)),rows=sum(len(f[1]) for f in p.factors),terms=sum(sum(map(len,f[1].values())) for f in p.factors),max_factor_terms=max(sum(map(len,f[1].values())) for f in p.factors),label_count=len(set(k for f in p.factors for k in f[0])),degree8_all_sites=True,each_label_twice=True,divisor=p.divisor)

mode=sys.argv[1];found=c.data();out={'mode':mode,'source_hashes':c.source_hashes()}
if mode=='local':
 for i,(row,g) in found.items():
  f,roles,k=c.curvature_factors(g);out[str(i)]={'factors':len(f),'rows':[len(x[1]) for x in f],'total_rows':sum(len(x[1]) for x in f),'branch_weights':[[w.numerator,w.denominator] for w,core in c.branches(g)]}
 assert out['161']['rows']==out['163']['rows']==[300,21,300,4200,57168,92,92,92,92,1520]
elif mode in ('prepare','xor'):
 branch=int(sys.argv[2]);fixed=(sys.argv[3]=='fixed');indices=(161,163) if mode=='xor' else (int(sys.argv[4]),)
 prepared=[]
 for i in indices:
  row,g=found[i];weight,core=list(c.branches(g))[branch]
  p=c.prepare(g,core,dict.fromkeys(g.frame,c.k3.witness.FIXED_GAMMAS) if fixed else None)
  out[str(i)]={'weight':[weight.numerator,weight.denominator],**describe(p)};prepared.append(p)
 if mode=='xor':
  if any(p is None for p in prepared):assert all(p is None for p in prepared);out['comparison']='both_algebraically_empty'
  else:out['comparison']=compare(*prepared)
else:raise ValueError(mode)
print(json.dumps(out,sort_keys=True))
