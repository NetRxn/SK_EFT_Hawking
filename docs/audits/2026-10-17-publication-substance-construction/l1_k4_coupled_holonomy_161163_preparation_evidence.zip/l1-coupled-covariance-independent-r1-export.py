from pathlib import Path
import runpy,sys,json,signal
signal.alarm(30)
ns=runpy.run_path('/tmp/l1-coupled-covariance-independent-r1-control.py',run_name='covariance_export')
if sys.argv[1]=='action':
 result={'kind':'actual-polynomial-readback','mode':'action','word':ns['word'],'center':ns['center'],'before':ns['normpoly'](ns['before']),'pulled_after':ns['normpoly'](ns['after']),'independent_generic_mask_substitution':ns['normpoly'](ns['generic']),'rotation':[[str(x) for x in row] for row in ns['rot'].tolist()]}
else:
 result={'kind':'actual-polynomial-readback','mode':'source','word':ns['word'],'origin':1,'before':ns['normpoly'](ns['old']),'pulled_after':ns['normpoly'](ns['pulled']),'independent_generic_mask_substitution':ns['normpoly'](ns['generic'])}
result.update(forest=ns['forest'],G_quaternions={q:[[str(v) for v in sector] for sector in val] for q,val in ns['Gq'].items()},opposite_anchor=ns['H'],opposite_after=[[str(v) for v in sector] for sector in ns['new'][ns['H']]])
print(json.dumps(result,sort_keys=True))
