import ast
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
import json,sys
a=Path(sys.argv[1])
source=ast.parse((a/'probe.py').read_text())
ns=dict(Counter=Counter,ATTEMPTS=Counter(),PEAK_ROWS=Counter(),PEAK_BITS=0,
        ATTEMPT_CAP=3,STATE_CAP=3,SCALAR_PAYLOAD_BITS=4)
names={'charge','row_room','payload'}
exec(compile(ast.Module([n for n in source.body if isinstance(n,ast.FunctionDef) and n.name in names],[]),'frozen helpers','exec'),ns)
ns['charge']('unit',3)
ns['row_room']('unit',3)
ns['payload'](SimpleNamespace(storage=(1,1,1,1)))
for name,action,want in (
    ('charge',lambda:ns['charge']('unit'),('prospective_attempts','unit',4,3)),
    ('row_room',lambda:ns['row_room']('unit',4),('prospective_rows','unit',4,3)),
    ('payload',lambda:ns['payload'](SimpleNamespace(storage=(2,1,1,1))),('scalar_payload_bits',5,4)),
):
    try: action()
    except RuntimeError as e: assert e.args==(want,)
    else: raise AssertionError(name)
assert ns['ATTEMPTS']=={'unit':3} and ns['PEAK_ROWS']=={'unit':3} and ns['PEAK_BITS']==4
receipt=json.loads((a/'result.json').read_text())
assert sum(receipt['attempts'].values())==842
assert receipt['peak_rows']=={'canonical_output':1,'raw_operand_options':4}
assert receipt['scalar_bits']==30
print('prospective monitored-counter checks all passed; instrumented results 842 visits, 1/4 rows, 30 normalized storage bits')
