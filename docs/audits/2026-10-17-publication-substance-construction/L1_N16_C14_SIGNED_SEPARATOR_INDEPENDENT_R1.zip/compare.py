from collections import Counter, defaultdict
from fractions import Fraction
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
import json,sys
from sympy import I, Rational, S, expand
from src.core.formulas import original_action_factors, original_coframe_blocks, original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol

author=Path(sys.argv[1])
prior=Path(sys.argv[2])
report=json.loads((author/'result.json').read_text())
census=json.loads((prior/'support-census.json').read_text())['sites']
reg=OriginalRegulator()
sites=reg.sites
assert reg.convention=='source_C' and reg.word=='closed'
seam={(sites[0],0),(sites[8],0)}
gindex={x:i for i,x in enumerate(reg.generator_order)}
links={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in reg.link_order}

def flatten(v):
    return tuple(map(flatten,v)) if isinstance(v,(tuple,list)) else v

def coeff(z):
    a,b,c,d=z.storage
    return Rational(a,b)+I*Rational(c,d)

def storage(z):
    re,im=expand(z).as_real_imag()
    return [int(re.p),int(re.q),int(im.p),int(im.q)]

def from_terms(p,target):
    return next((coeff(z) for k,z in p.terms if tuple(s.index for s in k)==target),S.Zero)

@cache
def action(site):
    return original_action_factors(reg,site,links)

def wedge(a,b):
    if a&b:
        raise ValueError('collision in selected source word')
    swaps=0
    while b:
        bit=b & -b
        swaps += (a//(bit<<1)).bit_count()
        b -= bit
    return (-1)**(swaps%2)

@cache
def frame(alpha,m,key):
    # Collapse each selected signed bilinear directly from raw matrix entries.
    # No author production wrapper, exterior polynomial or path Cartesian product.
    total=S.Zero
    hits=0
    for b in original_coframe_blocks(reg,alpha,links):
        for i,j in product(range(4),repeat=2):
            x=gindex[b.bar_site,'bar',i]
            y=gindex[b.psi_site,'psi',j]
            if ((1<<x)|(1<<y))!=m:
                continue
            q=from_terms(b.matrix[i][j],key)
            if q:
                hits+=1
                total += Rational(b.weight.numerator,b.weight.denominator)*q*(-1 if x>y else 1)
    assert hits>0
    return expand(total),hits

@cache
def wick(indices):
    if not indices:
        return 1
    return sum(wick(indices[1:i]+indices[i+1:]) for i in range(1,len(indices)) if indices[0]==indices[i])

def moments(key,alias):
    # Independent normalized Gaussian-pairing calculation on the sphere.
    groups=defaultdict(list)
    for x,d,h,k in key:
        if (x,d) in seam:
            groups[(sites[0] if alias else x,d,h)].append(k)
    weight=Fraction(1)
    for coords in groups.values():
        pairs=wick(tuple(coords))
        if len(coords)%2:
            assert pairs==0
        weight *= Fraction(pairs,prod(range(4,len(coords)+4,2)))
    return weight,sorted((a,[c.count(k) for k in range(4)]) for a,c in groups.items())

def incidences(i,axes):
    # Use all actual nonzero raw orientations in the accepted census.
    owner_directions=set()
    owner_anchors=set()
    normalized_edge_patterns=set()
    for degree,components,anchors,trace_count,_ in census[i]['raw_branches']:
        if not trace_count or sorted(d for d,_ in components)!=list(axes):
            continue
        dir_links=[]
        for d,_ in components:
            x=sites[i]
            other=reg.step(x,d,-1)[0]
            dir_links.append(tuple(sorted((x,other))))
            if (x,d) in seam or (other,d) in seam:
                assert (x,d) in seam and (other,d) in seam
                owner_directions.add(d)
        anchor_pairs=[(tuple(x),d) for x,d in anchors]
        owner_anchors.update(a for a in anchor_pairs if a in seam)
        curvature_edges=[tuple(sorted((x,reg.step(x,d)[0]))) for x,d in anchor_pairs]
        normalized_edge_patterns.add(tuple(sorted(dir_links+curvature_edges)))
    assert len(normalized_edge_patterns)==1
    return (tuple(sorted(owner_directions)),tuple(sorted(owner_anchors))),next(iter(normalized_edge_patterns))

def factors(row):
    return [tuple(label) for label in row['planes']]+[(i,0,1,2,3) for i,n in enumerate(row['S4_occupations']) for _ in range(n)]

def owners(row):
    result=[]
    for i,*axes in factors(row):
        (dirs,anchors),_=incidences(i,axes)
        if dirs or anchors:
            result.append((sites[i],tuple(axes),dirs,anchors))
    return tuple(result)

for name,row in report['results'].items():
    owned=owners(row['roster'])
    assert owned==flatten(row['owner_specs']) and len(owned)==len(row['selected'])
    running_mask=0
    value=S.One
    keys=[]
    path_counts=[]
    for own,selection in zip(owned,row['selected'],strict=True):
        site,axes,dirs,trace_anchors=own
        components,frames,trace=map(flatten,(selection['components'],selection['frames'],selection['trace']))
        assert tuple(c[1] for c in components)==axes and all(c[0]==site for c in components)
        assert tuple(sorted((x,d) for x,d,_,_ in trace if (x,d) in seam))==trace_anchors
        assert tuple(c[1] for c,(_,key) in zip(components,frames,strict=True) if key[0][:2] in seam)==dirs
        restrictions=dict(zip(components,frames,strict=True))
        candidate_factors=[f for f in action(site) if set(f.components)==set(components)]
        local_mask=None
        local_value=S.Zero
        orient_paths=matching_paths=0
        for f in candidate_factors:
            trace_value=from_terms(f.coefficient,trace)
            if not trace_value:
                continue
            matching_paths+=1
            fmask=0
            fval=trace_value
            term_count=1
            for a in f.components:
                g,key=restrictions[a]
                z,hits=frame(a,g,key)
                term_count*=hits
                fval *= wedge(fmask,g)*z
                fmask |= g
            orient_paths+=term_count
            assert local_mask is None or local_mask==fmask
            local_mask=fmask
            local_value+=fval
        path_counts.append(dict(matching_orientations=len(candidate_factors),present_orientations=matching_paths,increment_paths=orient_paths))
        value=expand(value*wedge(running_mask,local_mask)*local_value)
        running_mask |= local_mask
        keys.extend(trace)
        for _,k in frames:
            keys.extend(k)
    keys.sort()
    assert running_mask==row['exterior_mask']
    assert storage(value)==row['signed_coefficient']
    assert tuple(k for k in keys if k[:2] not in seam)==flatten(row['open_key'])
    assert path_counts==row['raw_counts']
    moment,closed=moments(keys,False)
    assert flatten(closed)==flatten(row['closed_blocks'])
    alias,_=moments(keys,True)
    assert str(moment)==row['Haar'] and str(alias)==row['alias_Haar']
    assert storage(value*Rational(moment.numerator,moment.denominator))==row['result']
    print(name,'owners',len(owned),'source paths',prod(x['increment_paths'] for x in path_counts),
        'raw',value,'Haar',moment,'alias Haar',alias,flush=True)

for row in report['survivors']:
    degrees=Counter(e for i,*axes in factors(row) for e in incidences(i,axes)[1])
    assert Counter(degrees.values())=={2:24,4:8}
for degree,expected in ((2,16),(4,736)):
    # Distinct labeled leg positions. Alphabet 0..15 is block*4+coordinate.
    counts=Counter()
    for word in product(range(16),repeat=degree):
        if any(n%2 for n in Counter(word).values()):
            continue
        blocks=len({i//4 for i in word})
        counts[blocks]+=1
    assert sum(counts.values())==expected
    assert counts==({1:16} if degree==2 else {1:160,2:576})
    print('labeled edge support',degree,dict(counts),flush=True)
