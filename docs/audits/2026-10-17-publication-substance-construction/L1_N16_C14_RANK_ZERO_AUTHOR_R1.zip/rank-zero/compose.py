"""Exact conditional two-site contraction and bounded fixed-boundary controls."""
from collections import Counter, defaultdict
from functools import cache
from itertools import product
from pathlib import Path
import json, sys

OUT=Path(__file__).parent
EDGE=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
SEWN=Path('/tmp/publication-c14-shared-trace-r1.9tcmVn')
sys.path.insert(0,str(SEWN))
import sew
from sew import REG, RANK, ZERO, add, times, row, put, work, emit

def jsonl(path):
    with path.open() as f:
        for line in f:
            work('read_row')
            yield json.loads(line)

A01=((0,2),(0,3),(2,3),(1,2))
A23=sew.ORDER

@cache
def raw_factors(plane):
    return tuple(f for f in sew.original_action_factors_cached(REG.sites[0])
                 if f.t_degree==2 and tuple(sorted(mu for _,mu,_ in f.components))==plane)

def trace_source(plane,anchors):
    out={}
    assert len(raw_factors(plane))==64
    for f in raw_factors(plane):
        d={mu:a for _,mu,a in f.components}
        for key,z in f.coefficient.terms:
            work('trace_raw_monomial')
            q={(RANK[x],mu): k+4*(h=='R') for s in key for x,mu,h,k in [s.index]}
            assert set(q)==set(anchors)
            v=z.real*4,z.imag*4
            assert all(x.denominator==1 for x in v)
            k=tuple(q[x] for x in anchors[:2])+tuple(d[x] for x in plane)+tuple(q[x] for x in anchors[2:])
            put(out,k,add(out.get(k,ZERO),tuple(x.numerator for x in v)))
    return {k:v for k,v in out.items() if v!=ZERO}

def inspect_global():
    trace=trace_source((0,1),A01)
    assert len(trace)==1536
    with (OUT/'plane-01-trace.jsonl').open('wb') as f:
        for k,z in sorted(trace.items()):
            work('trace_write')
            emit(f,[k,z])
    trace23={tuple(k):tuple(z) for k,z in jsonl(SEWN/'trace-slices.jsonl')}
    assert len(trace23)==1536
    return trace,trace23

def load():
    # Edge indexes. Shared E0 carries both site masks and stays internal.
    shared=defaultdict(dict)
    for (m,n,a,b,u,v),z in jsonl(EDGE/'edge-0.jsonl'):
        put(shared[m,n],(a,b,u,v),tuple(z))
    old=[]
    for i in (1,2,3):
        index=defaultdict(lambda:defaultdict(dict))
        for (m,n,a,b,*q),z in jsonl(EDGE/f'edge-{i}.jsonl'):
            put(index[n,a,b][m],tuple(q),tuple(z))
        old.append(index)
    new=[]
    for i in (1,2,3):
        index=defaultdict(lambda:defaultdict(dict))
        for (m,n,a,b,u,v),z in jsonl(OUT/f'zero-edge-{i}.jsonl'):
            put(index[n][m],(a,b,u,v),tuple(z))
        new.append(index)
    pos8={tuple(m):s for m,s,_ in jsonl(EDGE/'site-factors.jsonl')}
    pos0={tuple(m):s for m,s in jsonl(OUT/'zero-site-factors.jsonl')}
    tile=defaultdict(set)
    for p,q,u,v,x,y in jsonl(SEWN/'conditional-tiles.jsonl'):
        row()
        tile[p,q].add((u,v,x,y))
    return shared,old,new,pos8,pos0,tile

def full_sign(p8,p0,old,new,transpose_zero=False):
    # Literal global exterior word: accepted star edges then remaining rank-0 edges.
    def w(i,m,j,n):
        return sorted([8*i+k for k in range(8) if m>>k&1]+
                      [8*j+k for k in range(8) if n>>k&1])
    word=w(8,p8[0],0,p0[0])
    for axis,(neighbor,ext) in enumerate(zip((12,10,9),old,strict=True),1):
        word+=w(8,p8[axis],neighbor,ext[0])
    for axis,(neighbor,ext) in enumerate(zip((4,2,1),new,strict=True),1):
        word+=w(0,p0[axis],neighbor,ext)
    if len(word)!=len(set(word)):
        return 0
    if transpose_zero:
        word=[1 if v==0 else 0 if v==1 else v for v in word]
    return (-1)**sum(a>b for i,a in enumerate(word) for b in word[i+1:])

def hand(q):
    return tuple(k//4 for k in q)

@cache
def conditional(table_name,axis,ext,mask,hands):
    table=SHARED if table_name=='shared' else (OLD if table_name=='old' else NEW)[axis][ext]
    group=table.get(mask,{})
    out={}
    for k,z in group.items():
        work('conditional_boundary_row')
        q=k if table_name=='old' else k[2:]
        if not hands or hand(q)==hands:
            put(out,k,z)
    return out

@cache
def fixed_trace(kind,residual,mode):
    # Distinct reference starts from raw orientations at the fixed residual
    # rather than reusing grouped, serialized trace coefficients.
    residual=tuple(residual)
    t=TRACE01 if kind==0 else TRACE23
    p=(0,1) if kind==0 else (2,3)
    if mode=='raw':
        t=raw_fixed(kind,residual)
    out={}
    for (u,v,a,b,x,y),z in t.items():
        work('fixed_trace_row')
        if kind==0 and (x,y)!=residual or kind==1 and (x,)!=residual:
            continue
        put(out,(u,v,a,b,y) if kind else (u,v,a,b),z)
    return out

@cache
def raw_fixed(kind,residual):
    anchors=A01 if kind==0 else A23
    plane=(0,1) if kind==0 else (2,3)
    out={}
    for f in raw_factors(plane):
        comp=[None,None]
        for _,axis,a in f.components:
            comp[plane.index(axis)]=a
        for key,z in f.coefficient.terms:
            work('fixed_raw_orientation_scan')
            items={(RANK[s.index[0]],s.index[1]):s.index[3]+4*(s.index[2]=='R') for s in key}
            u,v,x,y=(items[a] for a in anchors)
            if kind==0 and (x,y)!=residual or kind==1 and (x,)!=residual:
                continue
            k=(u,v,*comp,x,y)
            g=z.real*4,z.imag*4
            assert all(a.denominator==1 for a in g)
            put(out,k,add(out.get(k,ZERO),tuple(a.numerator for a in g)))
    return {k:v for k,v in out.items() if v!=ZERO}

def local_lanes(extold,extnew,r01,r23,raw,mask_restriction=None):
    h01=tuple(r[0]//4 for r in r01)
    h23=tuple(r//4 for r in r23)
    if raw:
        # Reconstruct all potential local masks from the edge tables and
        # derive the sign from the complete literal 28-generator word.
        p8s=product(sorted({m for m,n in SHARED}),*(sorted(OLD[i][extold[i]]) for i in range(3)))
        p0by=defaultdict(list)
        for p0 in product(sorted({n for m,n in SHARED}),*(sorted(NEW[i][extnew[i]]) for i in range(3))):
            work('raw_candidate_zero_mask')
            if p0[0]|p0[1]|p0[2]|p0[3]==255 and sum(p.bit_count() for p in p0)==8:
                row()
                p0by[p0[0]].append(p0)
    else:
        p8s=iter(P8)
        p0by=P0BY
    for p8 in p8s:
        work('candidate_eight_mask')
        if mask_restriction and p8!=mask_restriction[0]:
            continue
        if not all(p8[i+1] in OLD[i][extold[i]] for i in range(3)):
            continue
        if p8[0]|p8[1]|p8[2]|p8[3]!=255:
            continue
        b=conditional('old',0,extold[0],p8[1],h23)
        if mask_restriction:
            k=mask_restriction[2][2:]
            b={k:b[k]} if k in b else {}
        if not b:
            continue
        d=OLD[1][extold[1]][p8[2]][()]
        e=OLD[2][extold[2]][p8[3]][()]
        for m8,m0 in SHARED_BY8[p8[0]]:
            a=conditional('shared',0,None,(m8,m0),h23)
            if mask_restriction:
                a={k:z for k,z in a.items() if k[2:]==mask_restriction[2][:2]}
            if not a:
                continue
            for p0 in p0by[m0]:
                work('candidate_zero_mask')
                if mask_restriction and p0!=mask_restriction[1]:
                    continue
                if not all(p0[i+1] in NEW[i][extnew[i]] for i in range(3)):
                    continue
                c=conditional('new',0,extnew[0],p0[1],h23)
                f=conditional('new',1,extnew[1],p0[2],h01)
                g=conditional('new',2,extnew[2],p0[3],h01)
                if mask_restriction:
                    cq,fq,gq=mask_restriction[3]
                    c={k:z for k,z in c.items() if k[2:]==cq}
                    f={k:z for k,z in f.items() if k[2:]==fq}
                    g={k:z for k,z in g.items() if k[2:]==gq}
                if not c or not f or not g:
                    continue
                if raw:
                    sign=full_sign(p8,p0,extold,extnew)
                    assert full_sign(p8,p0,extold,extnew,True)==-sign
                    if not sign:
                        continue
                else:
                    sign=P8[p8]*P0[p0]
                yield p8,p0,(a,b,c,f,g),times(times(d,e),(sign,0))

def primary_value(extold,extnew,r01,r23,restriction=None):
    s01=[fixed_trace(0,r,'factored') for r in r01]
    s23=[fixed_trace(1,(r,),'factored') for r in r23]
    t01=[]
    t23=[]
    for t in s01:
        d=defaultdict(dict)
        for (q2,q3,a0,a1),v in t.items():
            put(d[a0,a1],(q2,q3),v)
        t01.append(d)
    for t in s23:
        d=defaultdict(dict)
        for (q00,q81,a2,a3,q01),v in t.items():
            put(d[q00,q81,q01],(a2,a3),v)
        t23.append(d)
    total=ZERO
    paths=0
    first_path=None
    for p8,p0,(a,b,c,f,g),pref in local_lanes(extold,extnew,r01,r23,False,restriction):
        ix_f=defaultdict(list)
        ix_g=defaultdict(list)
        for (c0,c1,u0,u1),zf in f.items():
            work('primary_index_edge')
            row()
            ix_f[c0,u0].append((c1,u1,zf))
        for (d0,d1,v0,v1),zg in g.items():
            work('primary_index_edge')
            row()
            ix_g[d0,v0].append((d1,v1,zg))
        for (ka,za),(kb,zb),(kc,zc) in product(a.items(),b.items(),c.items()):
            work('primary_left_input')
            a0,a1,q00,q01=ka
            b0,b1,q10,q11=kc
            if (q00,q01,*kb) not in TILES[p8[:2]]:
                continue
            first=t01[0].get((a0,b0),{})
            second=t01[1].get((a1,b1),{})
            third=t23[0].get((q00,kb[0],q10),{})
            fourth=t23[1].get((q01,kb[1],q11),{})
            if not second or not fourth:
                continue
            for ((u0,v0),z0),((c0,d0),z2) in product(first.items(),third.items()):
                work('primary_first_occurrence')
                for (c1,u1,zf),(d1,v1,zg) in product(ix_f[c0,u0],ix_g[d0,v0]):
                    work('primary_projected_joins')
                    z1=second.get((u1,v1),ZERO)
                    z3=fourth.get((c1,d1),ZERO)
                    if z1==ZERO or z3==ZERO:
                        continue
                    paths+=1
                    value=pref
                    for z in (za,zb,zc,z0,z1,z2,z3,zf,zg):
                        value=times(value,z)
                    if first_path is None:
                        first_path=dict(left_edge=ka,star_edge1=kb,new_edge1=kc,
                            new_edge2=(c0,c1,u0,u1),new_edge3=(d0,d1,v0,v1),
                            numerator=value)
                    total=add(total,value)
    return total,paths,first_path

def raw_value(extold,extnew,r01,r23,restriction=None):
    s01=[fixed_trace(0,r,'raw') for r in r01]
    s23=[fixed_trace(1,(r,),'raw') for r in r23]
    t01=[]
    t23=[]
    for t in s01:
        d=defaultdict(dict)
        for (q2,q3,a0,a1),v in t.items():
            put(d[q2,q3],(a0,a1),v)
        t01.append(d)
    for t in s23:
        d=defaultdict(dict)
        for (q00,q81,a2,a3,q01),v in t.items():
            put(d[a2,a3,q81],(q00,q01),v)
        t23.append(d)
    total=ZERO
    paths=0
    for _,_,(a,b,c,f,g),pref in local_lanes(extold,extnew,r01,r23,True,restriction):
        ix_a=defaultdict(list)
        ix_c=defaultdict(list)
        for (a0,a1,q00,q01),za in a.items():
            work('raw_index_edge')
            row()
            ix_a[a0,q00].append((a1,q01,za))
        for (b0,b1,q10,q11),zc in c.items():
            work('raw_index_edge')
            row()
            ix_c[b0,q10].append((b1,q11,zc))
        for (kf,zf),(kg,zg),(kb,zb) in product(f.items(),g.items(),b.items()):
            work('raw_right_input')
            c0,c1,u0,u1=kf
            d0,d1,v0,v1=kg
            first=t01[0].get((u0,v0),{})
            second=t01[1].get((u1,v1),{})
            third=t23[0].get((c0,d0,kb[0]),{})
            fourth=t23[1].get((c1,d1,kb[1]),{})
            if not second or not fourth:
                continue
            for ((a0,b0),z0),((q00,q10),z2) in product(first.items(),third.items()):
                work('raw_first_occurrence')
                for (a1,q01,za),(b1,q11,zc) in product(ix_a[a0,q00],ix_c[b0,q10]):
                    work('raw_projected_joins')
                    z1=second.get((a1,b1),ZERO)
                    z3=fourth.get((q01,q11),ZERO)
                    if z1==ZERO or z3==ZERO:
                        continue
                    paths+=1
                    value=pref
                    for z in (za,zb,zc,zf,zg,z0,z1,z2,z3):
                        value=times(value,z)
                    total=add(total,value)
    return total,paths

def find_boundary():
    prev=json.loads((SEWN/'result.json').read_text())
    result=[]
    seen=set()
    t01=defaultdict(dict)
    t23=defaultdict(dict)
    for (u,v,a,b,r,s),z in TRACE01.items():
        put(t01[u,v,a,b],(r,s),z)
    for (u,v,a,b,r,s),z in TRACE23.items():
        put(t23[u,v,r],(a,b,s),z)

    @cache
    def new_options(i,mask):
        table=defaultdict(dict)
        for remote,t in NEW[i].items():
            for k,v in t.get(mask,{}).items():
                work('witness_edge_index')
                if k not in table:
                    row()
                # One deterministic outside mask is enough to propose a witness.
                table[k].setdefault('remote',remote)
        return table

    @cache
    def option_index(i,mask):
        out=defaultdict(list)
        for k in new_options(i,mask):
            work('witness_projection_index')
            row()
            out[k[2:] if i==0 else k[:2]].append(k)
        return out

    def witnesses():
        for c in [prev['fixed_boundary_controls'][i] for i in (0,2,3,4,1,5)]:
            exts=tuple(map(tuple,c['edge_boundary'][1:]))
            r23=tuple(x[2] for x in c['trace_boundary'])
            h23=hand(r23)
            for p8 in P8:
                work('witness_eight_partition')
                if not all(p8[i+1] in OLD[i][exts[i]] for i in range(3)):
                    continue
                b=conditional('old',0,exts[0],p8[1],h23)
                for m,n in SHARED_BY8[p8[0]]:
                    a=conditional('shared',0,None,(m,n),h23)
                    for p0 in P0BY[n]:
                        work('witness_zero_partition')
                        right=[new_options(i,p0[i+1]) for i in range(3)]
                        for ka,kb in product(a,b):
                            work('witness_old_edge_pair')
                            a0,a1,q00,q01=ka
                            if (q00,q01,*kb) not in TILES[p8[:2]]:
                                continue
                            one=t23[q00,kb[0],r23[0]]
                            two=t23[q01,kb[1],r23[1]]
                            for x,y in product(one,two):
                                work('witness_23_product')
                                c0,d0,s0=x
                                c1,d1,s1=y
                                cc=option_index(0,p0[1]).get((s0,s1),())
                                ff=option_index(1,p0[2]).get((c0,c1),())
                                gg=option_index(2,p0[3]).get((d0,d1),())
                                for kc,kf,kg in product(cc,ff,gg):
                                    work('witness_new_edges')
                                    b0,b1,*_=kc
                                    _,_,u0,u1=kf
                                    _,_,v0,v1=kg
                                    x0=t01[u0,v0,a0,b0]
                                    x1=t01[u1,v1,a1,b1]
                                    for r01 in product(x0,x1):
                                        work('witness_residual')
                                        new=tuple(right[i][k]['remote'] for i,k in enumerate((kc,kf,kg)))
                                        key=exts,new,r01,r23,(p8,p0,(q00,q01,*kb),(kc[2:],kf[2:],kg[2:]))
                                        if key in seen:
                                            continue
                                        row()
                                        seen.add(key)
                                        yield key

    for exts,new,r01,r23,parts in witnesses():
        print('control preflight work',sew.METERS['work'],flush=True)
        true,paths,first_path=primary_value(exts,new,r01,r23,parts)
        assert paths and first_path and first_path['numerator']!=ZERO
        raw,rawpaths=raw_value(exts,new,r01,r23,parts)
        assert raw==true and paths==rawpaths
        false=add(true,(-2*first_path['numerator'][0],-2*first_path['numerator'][1]))
        row()
        result.append(dict(old_edge_boundary=exts,new_remote_masks=new,
            residual_plane01=r01,residual_plane23=r23,rank8_partition=parts[0],rank0_partition=parts[1],retained_seam_tile=parts[2],retained_new_seam_labels=parts[3],coefficient_numerator=true,
            exact_nonzero_paths=paths,one_contributing_path=first_path,adverse_single_path_sign_numerator=false))
        print('control',len(result),true,'adverse',false,flush=True)
        if len(result)>=3 and any(r['coefficient_numerator']!=r['adverse_single_path_sign_numerator'] for r in result):
            return result,[]
    raise AssertionError(('no independent fixed boundary controls with nonzero paths',len(result)))

def main():
    global TRACE01,TRACE23,SHARED,OLD,NEW,P8,P0,TILES,P0BY,SHARED_BY8
    sew.rss()
    TRACE01,TRACE23=inspect_global()
    SHARED,OLD,NEW,P8,P0,TILES=load()
    P0BY=defaultdict(list)
    SHARED_BY8=defaultdict(list)
    for p in P0:
        P0BY[p[0]].append(p)
    for m,n in SHARED:
        SHARED_BY8[m].append((m,n))
    # Local relation identifies the shared edge's two masks while keeping
    # the two old/new site partitions factored and their signed weights.
    bridge={}
    with (OUT/'compatible-mask-bridge.jsonl').open('wb') as f:
        for (p8,p0),t in sorted(SHARED.items()):
            work('mask_bridge')
            old_count=sum(x[0]==p8 for x in P8)
            new_count=len(P0BY[p0])
            if not old_count or not new_count:
                continue
            put(bridge,(p8,p0),(old_count,new_count,len(t)))
            emit(f,[p8,p0,old_count,new_count,len(t)])
    meta=dict(plane01_rows=len(TRACE01),plane01_seam_bins=len({k[:2] for k in TRACE01}),
        plane23_rows=len(TRACE23),rank8_partitions=len(P8),rank0_partitions=len(P0),
        compatible_mask_bridge=len(bridge),compatible_site_partition_pairs=sum(a*b for a,b,c in bridge.values()),
        common_denominator=768**5*64**2*4**4)
    print('exact factored interface',meta,flush=True)
    # Preserve the complete exact local object even if a control needs a different route.
    (OUT/'interface.json').write_text(json.dumps(meta,indent=2)+'\n')
    meta['partition_and_seam_restricted_controls'],_=find_boundary()
    sew.rss()
    meta.update(limits=sew.LIMITS,meters=dict(sew.METERS),charged_operations=dict(sew.WORK),peak_rss_bytes=sew.PEAK_RSS)
    (OUT/'result.json').write_text(json.dumps(meta,indent=2)+'\n')

if __name__=='__main__':
    main()
