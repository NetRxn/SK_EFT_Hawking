"""Check the serialized mask bridge and the exact gross Cartesian visit count."""
from collections import Counter, defaultdict
from math import prod
from pathlib import Path
import json

OUT=Path(__file__).parent
EDGE=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')

def lines(p):
    with p.open() as f:
        for line in f:
            yield json.loads(line)

edges8=[Counter(k[0] for k,z in lines(EDGE/f'edge-{i}.jsonl')) for i in (1,2,3)]
edges0=[Counter(k[0] for k,z in lines(OUT/f'zero-edge-{i}.jsonl')) for i in (1,2,3)]
p8={tuple(p):s for p,s,_ in lines(EDGE/'site-factors.jsonl')}
p0={tuple(p):s for p,s in lines(OUT/'zero-site-factors.jsonl')}
bridge=Counter(tuple(k[:2]) for k,z in lines(EDGE/'edge-0.jsonl'))
assert len(p8)==240 and len(p0)==2520
counts=[Counter(),Counter()]
weights=[Counter(),Counter()]
for i,(parts,edges) in enumerate(zip((p8,p0),(edges8,edges0),strict=True)):
    for p,s in parts.items():
        assert all(m.bit_count()==2 for m in p)
        assert sum(p)==(p[0]|p[1]|p[2]|p[3])==255
        word=[k for m in p for k in range(8) if m>>k&1]
        assert s==(-1)**sum(a>b for j,a in enumerate(word) for b in word[j+1:])
        counts[i][p[0]]+=1
        weights[i][p[0]]+=prod(edges[j][m] for j,m in enumerate(p[1:]))
serialized={}
for a,b,c,d,n in lines(OUT/'compatible-mask-bridge.jsonl'):
    assert n==bridge[a,b] and c==counts[0][a] and d==counts[1][b]
    assert (a,b) not in serialized
    serialized[a,b]=(c,d,n)
assert set(serialized)=={(a,b) for a,b in bridge if counts[0][a] and counts[1][b]}
assert len(serialized)==100
print(json.dumps(dict(compatible_mask_pairs=len(serialized),
   compatible_site_partition_pairs=sum(a*b for a,b,n in serialized.values()),
   gross_edge_cartesian_visits_before_any_trace_filters=sum(n*weights[0][a]*weights[1][b]
                                    for (a,b),(c,d,n) in serialized.items())),indent=2))
