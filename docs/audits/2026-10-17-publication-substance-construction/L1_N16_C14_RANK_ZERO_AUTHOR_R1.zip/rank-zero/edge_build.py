"""Extract exact source tensors on the three as-yet uncontracted rank-zero edges."""
from collections import Counter
from pathlib import Path
import json, sys

OUT=Path(__file__).parent
PREV=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
sys.path.insert(0,str(PREV))
import cut

def main():
    cut.OUT=OUT
    cut.ROW_CAP=120_000
    cut.rss()
    row=cut.roster()
    owners=cut.star_owners(row,0)
    axes=[]
    with (PREV/'edge-0.jsonl').open() as f:
        axis0=Counter(json.loads(line)[0][1] for line in f)
    counts=[axis0]
    for d in owners[1:]:
        i=d[0]
        a,den,support=cut.edge_tensor(d,0,False)
        b,den0,support0=cut.edge_tensor(d,0,True)
        assert a==b and den==den0==768 and support==support0==240
        cut.write_rows(f'zero-edge-{i}.jsonl',a)
        count=Counter(k[0] for k in a)
        counts.append(count)
        axes.append(dict(axis=i,neighbor=d[1],coframes=d[2],open_trace_legs=d[3],
            exact_denominator=den,support_before_bilinear_filters=support,
            nonzero_rows=len(a),local_mask_slices=dict(sorted(count.items()))))
        print(i,len(a),flush=True)
    site=cut.partitions(counts)
    with (OUT/'zero-site-factors.jsonl').open('wb') as f:
        for k,s in sorted(site.items()):
            cut.work('serialized_zero_site_factor')
            cut.emit(f,[k,s])
    cut.rss()
    meta=dict(edges=axes,partitions=len(site),charged_operations=dict(cut.WORK),
              storage=dict(cut.STORE),rss_peak_bytes=cut.RSS_PEAK,cap=dict(rows=cut.ROW_CAP, work=cut.WORK_CAP, accounted_bytes=cut.BYTE_CAP, serialized_bytes=cut.FILE_CAP, sampled_rss=cut.RSS_CEILING, scalar=cut.INT_LIMIT))
    (OUT/'edge-meta.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('rank-zero partitions',len(site),flush=True)

if __name__=='__main__':
    main()
