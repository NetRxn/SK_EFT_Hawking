from ast import literal_eval
from collections import Counter,defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
import sys

p=Path(sys.argv[1])
moments=defaultdict(Counter)
for row in (p/'spatial.tsv').read_text().splitlines():
    shape,indices,*_=row.split('\t')
    q=literal_eval(indices)
    moments[literal_eval(shape)][q]+=1
coframes=[defaultdict(Counter) for _ in range(2)]
for line in Path(sys.argv[2]).open():
    owner,degree,raw,count=line.rstrip('\n').split('\t')
    indices=tuple(map(int,raw.split(','))) if raw else ()
    assert len(indices)==int(degree)
    group=coframes[int(owner)][int(degree)]
    assert indices not in group
    group[indices]=int(count)

@cache
def predicted(a,b,S,T):
    d=a+b
    assert S[0]==T[0]==d
    joins=weighted=0;matched=0
    for q1,n1 in coframes[0][a].items():
        for q2,n2 in coframes[1][b].items():
            q=tuple(sorted(q1+q2))
            left=tuple(i for i in q if i<8)
            right=tuple(i-8 for i in q if i>=8)
            m=moments[S][left]*moments[T][right]
            if m:
                joins+=n1*n2
                weighted+=n1*n2*m
                matched+=1
    return matched,joins,weighted

# The two pilot profiles are pinned in the previous author checkpoint.
space=list(product(range(5),repeat=3))
roster=[t for t in space if sum(t)<=4]
loads=[]
for code in tuple(map(int,__import__('os').environ['L1_PROFILE_CODES'].split(','))):
    occ=[roster[(code>>(6*x))&63] for x in range(8)]
    loads.append([tuple(sum(v)-n for n in v) for v in occ])
plans={}
for row in (p/'anchor-plan.tsv').read_text().splitlines():
    case,t,x,k,*shape=map(int,row.split())
    plans[case,t,x,k]=tuple(shape)
costs={}
for (case,t,u,k),S in sorted(plans.items()):
    if u>>k&1:continue
    v=u^(1<<k)
    T=plans[case,t,v,k]
    a,b=loads[t][u][k],loads[t][v][k]
    key=a,b,S,T
    if key not in costs:costs[key]=predicted(*key)
    print(case,t,u,k,a,b,*costs[key])
for key,result in sorted(costs.items(),key=lambda kv:-kv[1][2]):print("pattern",repr(key),*result)

print('unique',len(costs),'cumulative products',sum(v[2] for v in costs.values()),'max products',max(v[2] for v in costs.values()))
