from hashlib import sha256
from pathlib import Path
from time import monotonic
from collections import Counter
import sys

old,new=map(Path,sys.argv[1:3])
counts=Counter()
digests={}
def digest(path):
    target=path.resolve()
    if target not in digests:
        with target.open('rb') as stream:
            digests[target]=sha256(stream.read()).digest()
    return digests[target]
def compare(left,right,kind):
    assert digest(left)==digest(right),(left,right)
    counts[kind]+=1
def totals(parent):
    return [line for line in (parent/'batch.out').read_text().splitlines()
            if line.startswith('COMPLETE AUTHOR PROFILE ')]
started=monotonic()
assert len(totals(old))==16 and totals(old)==totals(new)
for record in (old/'next-cases.out').read_text().splitlines():
    a,b,w=record.split()
    profile=f'{a}-{b}-tiled'
    left,right=old/profile,new/profile
    for name in ('states.tsv','anchor-plan.tsv','edge-plan.out','spatial.tsv','temporal.tsv','root.tsv','rays.out','site.out'):
        compare(left/name,right/name,name)
    for folder in ('raw-edges','rays','site'):
        names={p.name for p in (left/folder).glob('*.tsv')}
        assert names and names=={p.name for p in (right/folder).glob('*.tsv')}
        for name in names:
            compare(left/folder/name,right/folder/name,folder)
    names={p.name for p in left.glob('case-*.out')}
    assert names and names=={p.name for p in right.glob('case-*.out')}
    for name in names:
        compare(left/name,right/name,'signed contraction log')
print('matched all 16 exact coefficients')
for k,v in sorted(counts.items()):
    print(k,v)
for parent in (old,new):
    wall=next(line.split()[1] for line in (parent/'batch.out').read_text().splitlines() if line.startswith('real '))
    print(parent.name,'wall seconds',wall)
print('comparison wall seconds',round(monotonic()-started,2))
