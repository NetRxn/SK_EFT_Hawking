# End-to-end L1 shared-input batch replay

The original and modified batch drivers run the same 16 original profiles
with the same coframe source and accepted predecessor inputs. The modified
driver counts the roster once before entering the profile loop and uses a
fresh per-run projected edge directory indexed by SHA-256 of raw edge
bytes. The cache content is published to the run directory only after all
three files and counts for that entry have been produced.

With both complete work trees available, invoke
`python3 compare.py ORIGINAL_RUN SHARED_INPUT_RUN`.
The comparison matches all 16 coefficients and checks hashes of all raw
edges, projected tables and aliases, site factors, edge plans, spatial and
temporal tables, and signed case logs. The large factor files are local.
Timing logs are included. Wall time changes from 261.75 to 120.33 seconds
on this cohort. This comparison does not change independent acceptance.
