from collections import Counter, defaultdict
from pathlib import Path
import sys
coframes=[defaultdict(Counter) for _ in range(2)]
for line in Path(sys.argv[1]).open():
    owner,word,mask,q,*_=line.rstrip('\n').split('\t')
    indices=tuple(map(int,q.split(',')))
    coframes[int(owner)][len(indices)][indices]+=1
for c in coframes:c[0][()]=1


for owner,groups in enumerate(coframes):
    for degree,counts in sorted(groups.items()):
        for indices,count in sorted(counts.items()):
            print(owner,degree,','.join(map(str,indices)),count,sep='\t')
