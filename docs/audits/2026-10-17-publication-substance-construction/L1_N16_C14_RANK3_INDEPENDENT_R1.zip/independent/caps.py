from pathlib import Path
import sys,json
a=Path(sys.argv[1]); m=json.loads((a/'result.json').read_text())
s=m['storage']; c=m['cap']
assert sum(m['charged_operations'].values())==468048<c['work']==4_000_000
assert s['rows']==138800<c['rows']==200000
assert s['charged_bytes']==512*s['rows']==71065600<c['accounted_bytes']==128*1024**2
assert s['serialized_bytes']==sum(x.stat().st_size for x in a.glob('*.jsonl'))==784688<c['serialized_bytes']==4*1024**2
assert m['rss_peak_bytes']==136265728<c['sampled_rss']==384*1024**2
assert c['scalar']==2**61-1
assert '4000001, 4000000' in (a/'unconditioned-control-refusal.log').read_text().splitlines()[-1]
print('scoped work, cumulative rows, accounting and output bytes, sampled RSS and first work refusal checked')
