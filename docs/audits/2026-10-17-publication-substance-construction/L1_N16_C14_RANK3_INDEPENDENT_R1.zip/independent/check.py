from collections import Counter, defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from fractions import Fraction
import json,sys
from src.core.formulas import original_action_factors, original_spin4_link, original_coframe_blocks
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
A,T,S,SE,P=map(Path,sys.argv[1:6])
def load(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def f(v): return tuple(map(f,v)) if isinstance(v,(tuple,list)) else v
def tbl(p):
    rr=f(rows(p)); t=dict(rr); assert len(rr)==len(t)
    return t
def co(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def add(z,w):return z[0]+w[0],z[1]+w[1]
def sign(w):return (-1)**sum(i>j for k,i in enumerate(w) for j in w[k+1:])
def pos(site,mask):return [8*site+i for i in range(8) if mask>>i&1]
R=OriginalRegulator()
index={x:i for i,x in enumerate(R.sites)}
positions={g:i for i,g in enumerate(R.generator_order)}
assert (R.extents,R.boundary_signs,R.convention,R.word)==((2,)*4,(1,)*4,'source_C','closed')
L={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in R.link_order}
M=load(A/'result.json')
G=load(A/'graph.json')
base=load(T/'graph.json')
C=load(P/'support-census.json')['sites']
row=load(S/'result.json')['row']
assert row['exponential_divisor']==512
acts=[]
for i,(x,*axes) in enumerate(row['planes']):
    anchors={tuple(sorted((index[tuple(y)],d) for y,d in aa)) for degree,comp,aa,n,_ in C[x]['raw_branches']
             if n and degree==2 and sorted(j for j,_ in comp)==axes}
    assert len(anchors)==1
    acts.append(('S2',x,i,tuple(axes),next(iter(anchors))))
acts += [('S4',x,i,tuple(range(4)),()) for x,n in enumerate(row['S4_occupations']) for i in range(n)]

def edge(rank,d):
    return frozenset((rank,index[R.step(R.sites[rank],d)[0]]))
def owner(rank,axis):
    E=edge(rank,axis)
    frames=[(s,x,i,d) for s,x,i,axes,_ in acts for d in axes if edge(x,d)==E]
    traces=[(s,x,i,(k,d)) for s,x,i,_,aa in acts for k,d in aa if edge(k,d)==E]
    return f(frames),f(traces)
fr,tr=owner(4,0)
assert f(M['edge'])==(0,12,fr,tr)
assert fr==(('S4',12,0,0),('S4',12,1,0))
assert tr==(('S2',0,2,(4,0)),('S2',0,3,(4,0)))

@cache
def moment(q):
    ns=Counter(q)
    if any(n%2 for n in ns.values()):return Fraction()
    return Fraction(prod(3 if n==4 else 1 for n in ns.values()),
        prod(j for n in Counter(i//4 for i in q).values() for j in range(4,4+n,2)))

def compute(site,axis,trace_slots,center):
    neighbor=next(iter(edge(site,axis)-{site}))
    ends=tuple(sorted((site,neighbor)))
    # The actual coframes all center at rank 12, including residual edge.
    alpha=defaultdict(list)
    qindex={(R.sites[x],axis,h,k):i for i,(x,h,k) in enumerate(product(ends,('L','R'),range(4)))}
    for component in range(4):
        for b in original_coframe_blocks(R,(R.sites[center],axis,component),L):
            for i,j in product(range(4),repeat=2):
                w=(positions[b.bar_site,'bar',i],positions[b.psi_site,'psi',j])
                for sy,z in b.matrix[i][j].terms:
                    assert len(sy)==1 and sy[0].index[:2]==b.anchor
                    c=(z.real*4*b.weight,z.imag*4*b.weight)
                    assert all(v.denominator==1 for v in c)
                    alpha[qindex[sy[0].index]].append((component,w,tuple(map(int,c))))
    support=0
    grouped=defaultdict(lambda:(0,0))
    weight_scale=48 if trace_slots else 4
    for q in product(range(16),range(16),*trace_slots):
        H=moment(q)*weight_scale
        if not H:continue
        assert H.denominator==1
        support+=1
        for (a,w,z),(b,v,t) in product(alpha[q[0]],alpha[q[1]]):
            word=w+v
            if len(set(word))!=4:continue
            local,remote=(sum(1<<(i%8) for i in word if i//8==x) for x in (site,neighbor))
            assert local.bit_count()==remote.bit_count()==2
            key=(local,remote,a,b,*q[2:])
            grouped[key]=add(grouped[key],tuple(int(H)*sign(word)*u for u in co(z,t)))
    nonzero={k:v for k,v in grouped.items() if any(v)}
    return nonzero,support,len(grouped)-len(nonzero)

from itertools import permutations
B,PRE=map(Path,sys.argv[6:8])
meta=load(B/'result.json')
edges=[]
for d,neighbor,anchor in ((0,11,None),(1,7,None),(2,1,(1,2)),(3,2,(2,3))):
    fr,tr=owner(3,d)
    assert fr==tuple(('S4',3,j,d) for j in (0,1)) and edge(3,d)=={3,neighbor}
    assert tr==(tuple(('S2',0,j,anchor) for j in (0,1)) if anchor else ())
    assert f(meta['owners'][d])==(d,neighbor,fr,tr)
    t,s,z=compute(3,d,(range(8),range(8)) if anchor else (),3)
    assert (len(t),s,z)==((14208,240,3584) if anchor else (48,16,240))
    assert t==tbl(B/f'rank3-axis{d}.jsonl')
    edges.append(t)
print('all four original incidence and raw signed Haar maps checked', [len(t) for t in edges],flush=True)

eps={}
for v in original_action_factors(R,R.sites[3],L):
    if v.t_degree!=4:continue
    assert tuple(d for _,d,_ in v.components)==(0,1,2,3)
    k=tuple(a for _,_,a in v.components)
    ((key,z),)=v.coefficient.terms
    assert not key and not z.imag and z.real==sign(k)
    eps[k]=int(z.real)
assert set(eps)==set(permutations(range(4)))
tails=defaultdict(list)
for (a,b,c,d),z in eps.items():tails[a,b].append((c,d,z))
compact=defaultdict(lambda:(0,0))
for ((m,r,a0,a1),x),((n,s,b0,b1),y) in product(edges[0].items(),edges[1].items()):
    if m&n:continue
    w=sorted(pos(3,m)+pos(11,r))+sorted(pos(3,n)+pos(7,s))
    sg=sign(w)
    for (c,d,t),(e,f0,u) in product(tails[a0,b0],tails[a1,b1]):
        k=(m|n,c,e,d,f0,r,s)
        compact[k]=add(compact[k],tuple(sg*t*u*v for v in co(x,y)))
compact={k:v for k,v in compact.items() if any(v)}
assert len(compact)==2016 and compact==tbl(B/'rank3-compact.jsonl')

projection={}
fused={k[0] for k in compact}
m2={k[0] for k in edges[2]}
m3={k[0] for k in edges[3]}
for t,m,n in product(fused,m2,m3):
    w=pos(3,t)+pos(3,m)+pos(3,n)
    if len(w)==len(set(w))==8:projection[t,m,n]=sign(w)
assert len(projection)==108 and projection==tbl(B/'rank3-projection.jsonl')
for site,axis in ((1,2),(2,3)):
    old={k[1] for k,_ in rows(T/f'zero-edge-{5-axis}.jsonl')}
    new={k[1] for k in edges[axis]}
    merge={(m,n,m|n):sign(pos(site,m)+pos(site,n)) for m,n in product(old,new) if not m&n}
    assert len(merge)==420 and merge==tbl(B/f'merge-rank{site}.jsonl')
print('compact 2016, projection 108, signed merges 420+420',flush=True)

a01=((0,2),(0,3),(2,3),(1,2))
trace=defaultdict(lambda:(0,0))
for v in original_action_factors(R,R.sites[0],L):
    labels=sorted(v.components)
    if tuple(d for _,d,_ in labels)!=(0,1):continue
    a,b=(a for _,_,a in labels)
    for key,z in v.coefficient.terms:
        code={(index[s.index[0]],s.index[1]):s.index[3]+4*(s.index[2]=='R') for s in key}
        assert set(code)==set(a01) and len(key)==4
        u,w,r,s=(code[k] for k in a01)
        z0,z1=z.real*4,z.imag*4
        assert z0.denominator==z1.denominator==1
        k=(u,w,a,b,r,s)
        trace[k]=add(trace[k],(int(z0),int(z1)))
assert {k:z for k,z in trace.items() if any(z)}==tbl(T/'plane-01-trace.jsonl')
print('complete original ordered plane01 trace, 1536 nonzero entries and anchor order checked',flush=True)
for ctl in meta['controls']:
    old1,old2=ctl['old_masks']
    new1,new2=ctl['new_masks']
    assert ctl['fused_masks']==[old1|new1,old2|new2] and not(old1&new1 or old2&new2)
    r11,r7=ctl['remote11'],ctl['remote7']
    t0,t1=(f(ctl[k]) for k in ('trace0_fixed','trace1_fixed'))
    left0=[(k,z) for k,z in edges[0].items() if k[1]==r11]
    left1=[(k,z) for k,z in edges[1].items() if k[1]==r7]
    right=defaultdict(list)
    for d,remote in ((2,new1),(3,new2)):
        for k,z in edges[d].items():
            if k[1]==remote:right[d,k[2],k[3]].append((k,z))
    # Direct raw left edge / two ordered epsilons / conditional right edges.
    out=alias=(0,0)
    paths=defaultdict(lambda:(0,0))
    for ((m0,_,a,b),x),((m1,_,c,d),y) in product(left0,left1):
        if m0&m1:continue
        for (a2,a3,s0),(b2,b3,s1) in product(tails[a,c],tails[b,d]):
            for ((m2,_,_,_,u0,u1),v),((m3,_,_,_,w0,w1),z) in product(right[2,a2,b2],right[3,a3,b3]):
                if (m0|m1|m2|m3)!=255 or sum(q.bit_count() for q in (m0,m1,m2,m3))!=8:
                    continue
                word=pos(1,old1)+pos(2,old2)+sorted(pos(3,m0)+pos(11,r11))+sorted(pos(3,m1)+pos(7,r7))+sorted(pos(3,m2)+pos(1,new1))+sorted(pos(3,m3)+pos(2,new2))
                assert len(word)==len(set(word))==20
                val=tuple(sign(word)*s0*s1*j for j in co(co(x,y),co(v,z)))
                cc=co(val,co(trace[(*t0,w0,u0)],trace[(*t1,w1,u1)]))
                bad=co(val,co(trace[(*t0,w0,u0)],trace[(*t1,w0,u0)]))
                key=(m0|m1,a2,b2,a3,b3,m2,u0,u1,m3,w0,w1)
                paths[key]=add(paths[key],cc)
                out=add(out,cc)
                alias=add(alias,bad)
    paths={k:z for k,z in paths.items() if any(z)}
    assert len(paths)==ctl['nonzero_factored_paths']==48
    assert out==f(ctl['signed_numerator'])==alias==f(ctl['false_occurrence_alias_numerator'])
    adverse=f(ctl['adverse_single_path_flip_numerator'])
    target=tuple((x-y)//2 for x,y in zip(out,adverse))
    assert target in paths.values()
    assert tuple(x-2*y for x,y in zip(out,target))==adverse
    assert abs(Fraction(out[0],ctl['denominator']))==Fraction(3,32)
    assert abs(Fraction(adverse[0],ctl['denominator']))==Fraction(23,256)
    print('raw literal junction',out,'48 signed paths; reuse inert; path reversal',adverse,flush=True)

g=load(B/'graph.json')
pg=load(PRE/'graph.json')
change={'remote1':'old_mask1','remote2':'old_mask2'}
assert {k:g['factor_keys'][k] for k in pg['factor_keys']}=={k:[change.get(x,x) for x in v] for k,v in pg['factor_keys'].items()}
expected=dict(rank3_compact=['fused_mask3','S4_3_a2_0','S4_3_a2_1','S4_3_a3_0','S4_3_a3_1','remote11','remote7'],
 rank3_edge2=['edge2_mask3','new_mask1','S4_3_a2_0','S4_3_a2_1','q12_0','q12_1'],
 rank3_edge3=['edge3_mask3','new_mask2','S4_3_a3_0','S4_3_a3_1','q23_0','q23_1'],
 rank3_projection=['fused_mask3','edge2_mask3','edge3_mask3'],
 merge_rank1=['old_mask1','new_mask1','remote1'],merge_rank2=['old_mask2','new_mask2','remote2'])
assert {k:v for k,v in g['factor_keys'].items() if k not in pg['factor_keys']}==expected
assert set(g['boundary'])==set(pg['boundary'])-{'q12_0','q12_1','q23_0','q23_1'}|{'remote11','remote7'}
assert g['combined_denominator']==pg['combined_denominator']*64**2*768**2==8721064880344833042121878122499340763136
assert g['external_exponential_divisor']==512
print('complete original factor graph scope, open labels and external divisor checked',flush=True)
