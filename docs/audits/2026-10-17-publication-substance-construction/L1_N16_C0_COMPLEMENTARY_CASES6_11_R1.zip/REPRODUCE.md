# Complementary tuple 0 child cases 6–11

Bind the committed separator archive using review/SOURCE_PINS.txt. Its
complementary parent restores the author input for every case. For each case,
use the saved author drivers in fresh scratch. Run exact-multicut.py with the
parent, input.pkl and case index, then reduce-label-frontier.py input.pkl
primary and contract-reduced-label.py primary. Restore the rescue frontier
from the primary cap output, run reduce-label-frontier.py with tag rescue,
and run contract-peer.py rescue. Compare the resulting frontier hashes to
the receipts in author/CASE. Use trusted source bytes for deserialization.

The review relocation requires the restored source and author inputs
recorded in the external manifests. The two independent signed replays,
including exact raw numerators, live under review/case-CASE. Compare the
preceding-six.tsv bytes to six-term-retally.tsv in the committed cases 4–5
closure, then run python3 verify-and-retally.py to check both lanes of exact
arithmetic and reproduce the 12/48 subtotal.
