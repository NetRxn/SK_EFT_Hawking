from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess

def line(i):
    log = Path(f'case-{i}/lineage.out')
    with log.open('xb') as output:
        p=subprocess.run(['bash','reproduce-lineage.sh',str(i)],stdout=output,stderr=subprocess.STDOUT,timeout=180)
    print(i,p.returncode,sep='\t',flush=True)
    return p.returncode

with ThreadPoolExecutor(max_workers=3) as pool:
    assert all(code==0 for code in list(pool.map(line,range(6,12))))
