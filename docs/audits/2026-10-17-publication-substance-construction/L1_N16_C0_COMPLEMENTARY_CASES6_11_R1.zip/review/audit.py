from ast import literal_eval
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

root = Path(__file__).resolve().parent
archive = root/'archive'
authors = Path('/private/tmp/l1-c0-sibling-cases6-11.VaqDtE/tuple0-1')
census = Path('/private/tmp/l1-c0-complementary-census.aRhHhn')
path = 'row-cap-physical-slice-dense-label-tuple0-{}-reduced.pkl'
pins = {name:digest for digest,name in (line.split() for line in (archive/'frontiers-uncompressed.sha256').read_text().splitlines())}
def parent(branch):
    name = path.format(branch)
    raw = decompress((archive/f'{name}.gz').read_bytes())
    assert sha256(raw).hexdigest() == pins[name]
    assert raw == (census/name).read_bytes()
    return pickle.loads(raw)

first = parent(0)
second = parent(1)
assert pins[path.format(1)] == '9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d'
split = ('R',0,0,2,0,1)
assert first['conditioning'][:-1] == second['conditioning'][:-1]
assert first['conditioning'][-1] == (split,0) and second['conditioning'][-1] == (split,1)
assert first['label_partition'] == second['label_partition']
assert first['factors'] != second['factors']
print('PASS distinct complementary binary parent',pins[path.format(1)],'selector',split,1)
axes, entries = literal_eval((archive/'pilot.roster').read_text())
assert len(entries) == len(dict(entries)) == 48
factors=second['factors']
assert len(factors)==8 and set(Counter(w for scope,_,_ in factors for w in scope).values()) == {2}
left,right = [factors[i] for i in second['rejected_pair']]
shared=sorted(set(left[0])&set(right[0]))
left_shared = tuple(left[0].index(axis) for axis in shared)
right_shared = tuple(right[0].index(axis) for axis in shared)
left_cut = tuple(left[0].index(axis) for axis in axes)
left_counts=Counter((tuple(row[i] for i in left_shared),tuple(row[i] for i in left_cut)) for row in left[1])
right_counts=Counter(tuple(row[i] for i in right_shared) for row in right[1])
roster=Counter()
for (key,cut),n in left_counts.items():
    if count:=n*right_counts[key]:
        roster[cut]+=count
assert roster == dict(entries)
order = sorted(roster, key=lambda c:(roster[c],c))
assert sum(roster.values()) == second['matched'] == 6427904
print('PASS complementary roster',axes,len(roster),'pair products',sum(roster.values()),'min/max',min(roster.values()),max(roster.values()))
coords=((130,(3,)),(132,(3,)),(18,(1,)),(18,(2,)),(20,(1,)),(20,(2,)))
cap_work=dict(zip(range(6,12),(2618560,2618560,4058640,3492880,4058640,3492880),strict=True))
primary_ids=set()
terminal_ids=set()
exact_cases=[]
for case,coord in zip(range(6,12),coords,strict=True):
    author=authors/str(case)
    assert (archive/'pilot.roster').read_bytes() == (author/'input.roster').read_bytes()
    assert order[case]==coord and roster[coord]==(70896 if case<8 else 106344)
    print('PASS original mapped coordinate',case,coord,roster[coord])
    fixed = dict(zip(axes,coord,strict=True))
    raw = (author/'input.pkl').read_bytes()
    primary_ids.add(sha256(raw).hexdigest())
    child=pickle.loads(raw)
    assert child['conditioning'] == second['conditioning']+list(fixed.items())
    assert child['label_partition'] == second['label_partition']
    for (scope,rows,den),(cscope,crows,cden) in zip(factors,child['factors'],strict=True):
        assert den==cden
        assert tuple(w for w in scope if w not in fixed) == cscope
        want = {row:value for row,value in rows.items()
                if all(row[i]==fixed[w] for i,w in enumerate(scope) if w in fixed)}
        got = {}
        for row,value in crows.items():
            assignment=dict(zip(cscope,row,strict=True))
            assignment.update(fixed)
            got[tuple(assignment[k] for k in scope)]=value
        assert got==want
    print('PASS exact inverse lift',sha256(raw).hexdigest(),'rows',sum(len(rows) for _,rows,_ in child['factors']))
    for name, length in [('label-primary-reduced-frontier.pkl',8),('join-cap-dense-label-primary-reduced.pkl',5),('label-rescue-reduced-frontier.pkl',5)]:
        raw = (author/name).read_bytes()
        if name == 'label-rescue-reduced-frontier.pkl':
            terminal_ids.add(sha256(raw).hexdigest())
        stage = pickle.loads(raw)
        assert stage['conditioning']==child['conditioning'] and stage['label_partition']==child['label_partition']
        ff=stage['factors']
        assert len(ff)==length
        assert all(n==2 and a[0]!='L' for a,n in Counter(a for scope,_,_ in ff for a in scope).items())
        assert all(den>0 and len(scope)==len(set(scope)) and all(len(row)==len(scope) and len(val)==2 and any(val) and all(type(x) is int for x in val) for row,val in rows.items()) for scope,rows,den in ff)
        assert prod(den for _,_,den in ff) == 40512224221827380280140849737629696
        print('PASS exact stage input',name,sha256(raw).hexdigest(),'factors and rows',length,sum(len(rows) for _,rows,_ in ff))
    log=(root/f'case-{case}'/'greedy-replay.out').read_text()
    assert f"conditioning {child['conditioning']} label partition {child['label_partition']}" in log
    signature=r'^exact normalized real (\S+) imaginary (\S+) '
    exact=tuple(map(Fraction,re.search(signature,log,re.M).groups()))
    assert exact == tuple(map(Fraction,re.search(signature,(author/'rescue-contract.out').read_text(),re.M).groups()))
    r,i,d=map(int,re.search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',log,re.M).groups())
    assert d==40512224221827380280140849737629696
    assert tuple(Fraction(j,d*16*4**64) for j in (r,i))==exact
    alternate=(root/f'case-{case}'/'alternate-replay.out').read_text()
    assert f"conditioning {child['conditioning']} label partition {child['label_partition']}" in alternate
    assert 'forecast 1184724 0 2 prior 0' in alternate
    assert 'forecast 190512 2 4 prior 0' in log
    assert tuple(map(Fraction,re.search(signature,alternate,re.M).groups()))==exact
    assert tuple(map(int,re.search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',alternate,re.M).groups()))==(r,i,d)
    cap=(author/'contract.out').read_text().splitlines()[-1]
    assert cap==f'open join cap 5 completed products {cap_work[case]} frontier saved'
    print('PASS exact normalized complementary case',case,coord,*exact,'raw',r,i,'factor denominator',d)
    exact_cases.append(exact)
    print('PASS cap receipt',case,cap)

assert len(primary_ids)==len(terminal_ids)==6
parts=tuple(sum(c,Fraction(0)) for c in zip(*exact_cases,strict=True))
print('PASS six distinct cut and terminal input identities, exact batch subtotal',*parts)
