from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

author = Path('/private/tmp/l1-c0-sibling-cases6-11.VaqDtE/tuple0-1')
def run(job):
    i, algorithm = job
    program = 'replay.py' if algorithm == 'greedy' else 'replay-alternate.py'
    a=author/str(i)
    log = Path(f'case-{i}/{algorithm}-replay.out')
    with log.open('xb') as output:
        p=subprocess.run([sys.executable,'-u',program,str(i),'rescue',str(a/'label-rescue-reduced-frontier.pkl'),str(a/'rescue-contract.out')],
                         stdout=output,stderr=subprocess.STDOUT,timeout=60)
    print(i,algorithm,p.returncode,sep='\t',flush=True)
    return p.returncode

jobs = [(i, choice) for choice in ('greedy','alternate') for i in range(6,12)]
for i in range(6,12):
    Path(f'case-{i}').mkdir(exist_ok=True)
with ThreadPoolExecutor(max_workers=3) as pool:
    assert all(code==0 for code in list(pool.map(run,jobs)))
