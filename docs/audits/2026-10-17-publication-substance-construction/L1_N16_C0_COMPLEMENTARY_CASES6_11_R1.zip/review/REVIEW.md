# Independent verification of complementary tuple 0 cases 6–11

Each normalized real numerator below uses denominator
5192296858534827628530496329220096. Every imaginary contribution is zero.

| Case | Original coordinate | Real numerator |
|---|---|---:|
| 6 | (130, (3,)) | 1763518048972234363017 |
| 7 | (132, (3,)) | 3196789373761759059327 |
| 8 | (18, (1,)) | 896319661658118850215 |
| 9 | (18, (2,)) | 29121274344003337413 |
| 10 | (20, (1,)) | 3134785905393298749225 |
| 11 | (20, (2,)) | 3072782437024838439123 |

The original separator archive was read from publication checkpoint
9029a2a4bd91c4e37f8a2d5b298597edb29fa2df and matches the worktree bytes.
Its manifest verified. The complementary parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It selects R(0,0,2,0,1)=1 and has its own factor tables. An independent
histogram on its rejected parent pair regenerates all 48 coordinates over
6,427,904 matched products. The six cuts have distinct input identities.
Exact inverse lifts recover every compatible parent row, Gaussian
coefficient and factor denominator. The stored stages preserve all
conditioning, the label partition and the degree-two open axes.

Clean-scratch author execution reproduced every cut, roster, planning
receipt, reduction, join-cap receipt, retained checkpoint and successful
rescue receipt byte for byte. The generic contractions refused further
joins at five factors after 2,618,560 products for cases 6–7,
4,058,640 for cases 8 and 10, and 3,492,880 for cases 9 and 11.

Two separate signed Gaussian integer schedules contract the six distinct
terminal inputs. The greedy schedule starts with pair (2,4) and uses
6,945,952 matched products per case. The alternate starts with pair
(0,2) and uses 13,087,188 matched products per case. All raw real and
imaginary numerators agree between schedules. Exact normalized values
also match their respective author rescue receipts. Each contraction
uses the factor denominator product 40512224221827380280140849737629696
and the external normalization 1/(16*4^64) once.

The review manifest uses relative paths. The copied author receipts
appear under author-receipts/. The separate frozen-input inventory
identifies the source operands required to repeat the contractions.
