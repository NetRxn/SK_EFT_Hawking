from fractions import Fraction
from pathlib import Path
import re

cases={}
for line in Path('preceding-six.tsv').read_text().splitlines():
    fields=line.split('\t')
    if fields[0].isdigit():
        index,x,y=fields
        assert int(index) not in cases
        cases[int(index)]=Fraction(x),Fraction(y)
assert set(cases)==set(range(6))
normalized = re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
raw = re.compile(r'raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)')
for n in range(6,12):
    expected=tuple(map(Fraction,normalized.search((Path('author')/str(n)/'rescue-contract.out').read_text()).groups()))
    for route in ('greedy-replay.out','alternate-replay.out'):
        result=(Path('review')/f'case-{n}'/route).read_text()
        a,b,d=map(int,raw.search(result).groups())
        scale=d*16*4**64
        assert (Fraction(a,scale),Fraction(b,scale))==tuple(map(Fraction,normalized.search(result).groups()))==expected
    cases[n]=expected
assert set(cases)==set(range(12))
for index,(x,y) in sorted(cases.items()):
    print(index,x,y,sep='\t')
print('PARTIAL SUM',len(cases),*map(sum,zip(*cases.values())),sep='\t')
