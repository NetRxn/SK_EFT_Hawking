# Independent review of paired cut 16

The exact signed value of outer coordinate `(65,(1,))` in group128 descendant (0,1), tuple 0 is `3134785905393298749225/2596148429267413814265248164610048 + 0i`. Its raw Gaussian subtotal is `(266332326040368520175346924451858681301824037407722277385011200,0)` with factor denominator `40512224221827380280140849737629696`. Each term was normalized once by the positive external factor 1/(16*4^64). The fixed mode records independently yield total occupation 32, factorial contribution 16 and even phase exponent. The cut weights count compatible products and do not multiply the signed scalar.

The continuity packet matched checkpoint `605a32fd1707c0c074ac3c3f388f39c5906f654b`. The original selector branches each have 48 compatible outer coordinates and 6,427,904 matched products. The independent signed constructor recovered the exact seven-factor combined state with 106,344 products per branch and 77,328 signed pair rows. The combined state has SHA-256 `3df5a0fba99d3d936798070d98af387a0041e28c72c98e27d606fe2ca3d7158c`. Byte replay recovered both retained joins, with 808,704 and 4,214,912 products, and the five-factor join refusal after 5,023,616 products. The cap SHA-256 is `d0adde2fa57c8206701be499c0b648e3f233049eb1df363d3553f092b442fbe6`.

Both incident scopes of `G(1,0,2)` have the same 16 supported values. The independent histogram matches 31,075,200 weighted (0,3) pair products and verifies exhaustive, mutually exclusive coverage. Each of the 16 inverse lifts recovered the exact original rows, axes, denominators and Gaussian coefficients for both affected factors and the other three tables. Each ordinary preparation, reduction, contraction or refusal reproduced byte for byte, with 48 commands and 407.773930 summed command seconds. All 8 retained inner refusals are three-factor inputs that close exactly via the shard route.

The 8 generic terminals passed independent signed sparse contractions. The 8 triangles were contracted with an alternate pivot using the signed kernel, and all 16 author shard intervals were separately contracted to verify each raw Gaussian pair and normalized pair. The signed ledger is the sum of the distinct exact terms. Independent terminal routes performed 142,768,768 products and took 151.142474 summed command seconds. Independent replay of the author shard intervals took 61.239267 additional summed seconds. These timings are command durations from concurrent work. Both original caps and all inner refusal receipts are retained.

The portable manifest covers the exact ledger, the selected receipts, input hashes and verification scripts. Large original binary checkpoints are bound by the operand inventory. From this case directory, with the review scripts at its parent, run:

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B ../retally.py | cmp - signed-ledger.tsv
```
