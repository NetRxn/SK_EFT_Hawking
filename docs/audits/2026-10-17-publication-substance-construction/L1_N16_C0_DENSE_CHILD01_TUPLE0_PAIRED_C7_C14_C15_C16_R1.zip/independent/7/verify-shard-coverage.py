from ast import literal_eval
from collections import Counter
from pathlib import Path
from pickle import loads
import re
ROOT=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe7-inner')
TERMINALS=[(int(index), path, prog, literal_eval(pivot), literal_eval(traffic)) for index,path,prog,pivot,traffic in
           (line.split('\t') for line in (ROOT/'terminal-plan.tsv').read_text().splitlines())]


def projection(axes, edge):
    positions = tuple(axes.index(k) for k in edge)
    return lambda row: tuple(row[p] for p in positions)


for index, path, program, author_pair, author_traffic in TERMINALS:
    checkpoint = loads((ROOT / path).read_bytes())
    factors = checkpoint['factors']
    triangle = program == 'triangle-shards.py'
    if triangle:
        assert author_pair == author_traffic == ()
        pivot, others = 0, (1, 2)
    else:
        assert program == 'close-four-shards.py' and len(author_pair) == 2 and len(author_traffic) == 8
        pivot, partners = author_pair
        others = (partners,)
    left_axes, left_rows, _ = factors[pivot]
    ordered = sorted(left_rows)
    traffic = []
    for other in others:
        right_axes, right_rows, _ = factors[other]
        edge = tuple(sorted(set(left_axes) & set(right_axes)))
        left_key = projection(left_axes, edge)
        counts = Counter(map(projection(right_axes, edge), right_rows))
        traffic.append([counts[left_key(row)] for row in ordered])
    candidates = [min(counts) for counts in zip(*traffic, strict=True)]
    paths = sorted(ROOT.glob(f'slice-{index}-shard-[0-9]*.out'))
    assert len(paths) == 8
    total = 0
    author_triples = 0
    for shard, path in enumerate(paths):
        assert path.name == f'slice-{index}-shard-{shard}.out'
        lo, hi = len(ordered)*shard//8, len(ordered)*(shard+1)//8
        expected = sum(candidates[lo:hi])
        log = path.read_text()
        assert f'left row interval {lo} {hi} of {len(ordered)} shard {shard} of 8' in log.splitlines()
        assert f"conditioning {checkpoint['conditioning']} label partition {checkpoint['label_partition']}" in log.splitlines()
        if triangle:
            match = re.search(r'^triangle closure (\d+) nonzero-support triples (\d+) bounded probes products (\d+) output rows 1$', log, re.M)
            triples, probes, products = map(int, match.groups())
            assert probes == expected and products == 2*triples
            author_triples += triples
        else:
            assert author_traffic[shard] == expected
            complement=tuple(sorted(set(range(4)) - set(author_pair)))
            assert f'left pair {pivot} {partners} candidate matches {expected} closure pair {complement[0]} {complement[1]}' in log.splitlines()
        total += expected
        print('PASS case', index, 'author shard', shard, 'pivot factor', pivot,
              'row interval', (lo, hi), 'independently counted', expected, 'probes' if triangle else 'pair matches')
    assert total == sum(candidates)
    if triangle:
        replay = Path(f'slice-{index}-triangle-replay.out').read_text()
        match = re.search(r'^independent pivot [12] probes \d+ triples (\d+) ', replay, re.M)
        assert int(match[1]) == author_triples
    print('PASS case', index, 'complete author shard coverage through', len(ordered), 'pivot rows; total', total)
