# Reproduce original paired cut 7

Use both frozen branch operands, original author paths (or hash-checked equivalents), source receipts under author-receipts and a fresh copy of this scratch driver set. The adaptive runner recorded the first nine and the remaining fourteen separately in two primary tables.

Run python3 pair-route-audit.py, bash combine-readback.sh and bash pair-lineage.sh for source support, signed pair and initial exact cap bytes. Run python3 -u inner-lineage.py with ordinals 0 through 22 inclusive, then python3 combine-stage-timing.py. An empty seeds.tsv records that all 21 unsharded terminal terms closed directly. Run bash reproduce-terminals.sh to recompute every signed terminal and verify author shard intervals, traffic, raw totals and normalization.
