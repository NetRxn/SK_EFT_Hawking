from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
import ast,json,hashlib
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def records(stem):return [json.loads(l) for l in (P/(stem+'.out')).read_text().splitlines()]
f=next(n for n in ast.parse((P/'l1-110153-review-fixed-receipts.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='product_branches');ns={'F':F,'combinations_with_replacement':combinations_with_replacement};exec(compile(ast.Module(body=[f],type_ignores=[]),'independent45_products','exec'),ns)
D=192**42*4**64*48**6*2**15;scientific={};parsed={};files=[]
for word,stem in [(110,'l1-residual40-author-pilot110-r1'),(153,'l1-residual40-author-full153-r1')]:
 rs=records(stem);first,prep,warm=rs[:3];last=rs[-1];bs=rs[3:-1];ex=json.loads((P/(stem+'.exit.json')).read_text());assert ex['exit_code']==ex['actual_child_exit_code']==ex['driver_exit_code']==0 and not ex['parent_timeout'] and ex['truncated_or_nonJSON_lines']==0 and not (P/(stem+'.err')).read_bytes()
 assert len(bs)==len(prep['support_domains'])==45 and prep['restrictions']==[] and prep['branches']==last['branches']==45 and prep['seconds']==last['preparation_seconds']<600 and last['whole45_warm_seconds']<60 and ex['full_wall_seconds']<665
 linked,other,free=((1,5),(9,13),(3,7,11,15)) if word==110 else ((0,4),(8,12),(2,6,10,14));expected=ns['product_branches'](linked,other,free);total=F();raw=F();zero=0
 for i,(b,s,(weight,domain)) in enumerate(zip(bs,prep['support_domains'],expected)):
  assert b['kind']=='exact-branch' and b['word']==word and b['branch']==s['branch']==i and s['protected_branch_index']==i//3 and s['free_branch_index']==i%3
  assert b['divisor']==D and F(b['raw_numerator'],D)==F(*b['coefficient']) and F(*b['weight'])==F(*s['weight'])==weight
  assert {q:tuple(tuple(v) for v in ds) for q,ds in s['core_domains']}==domain and len(domain)==8 and not s['algebraic_empty_preparation'] and not b['algebraic_empty_preparation']
  audit=s['prepared_graph'];assert audit['factors']==38 and audit['labels']==32 and audit['all_labels_twice'] and {int(q):d for q,d in audit['site_degrees'].items()}==dict.fromkeys(range(16),8) and len(audit['source_factors'])==2
  assert len(s['center_support'])==15 and all(c['rows'] and any(tuple(tuple(p) for p in v['labels'][:2])!=((0,0),(1,1)) for v in c['rows']) for c in s['center_support'])
  for c in s['center_support']:
   q=c['center'];role='square_component' if q==(0 if word==110 else 1) else 'protected_torus_core' if q in linked+other else 'free_torus_core' if q in free else 'peeled';assert c['selector']==role
  total+=weight*F(*b['coefficient']);raw+=weight*b['raw_numerator'];zero+=b['raw_numerator']==0
 assert zero==18 and total==F(*last['coefficient'])==F(461966234549968960425,140737488355328) and raw.denominator==1 and raw.numerator==last['raw_numerator'] and last['divisor']==D
 assert max(b['peak_rows'] for b in bs)==last['peak_rows']==(5632 if word==110 else 3024)
 assert prep['sources']==prep['fixed_sources']==[[0,2],[1,2]] and prep['all_Grassmann_sites']==list(range(16)) and prep['omitted_action_center_retained_Grassmann_site']==(4 if word==110 else 5)
 assert prep['fixed_action_edges']==[[[4,5,0],[[5,0] if word==110 else [4,0]]]] and prep['live_action_labels']==[[1,0] if word==110 else [0,0]]
 runner=P/('l1-residual40-author-pilot110-runner-r1.py' if word==110 else 'l1-residual40-author-full153-runner-r1.py');driver=P/('l1-residual40-author-pilot110-driver-r1.py' if word==110 else 'l1-residual40-author-full153-driver-r1.py');t=ast.parse(runner.read_text());pc=[n for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Subscript) and isinstance(n.func.slice,ast.Constant) and n.func.slice.value=='prepare'];assert len(pc)==1 and len(pc[0].args)==2 and not pc[0].keywords and sha(runner)==ex['runner_sha256']
 assert 'for branch, (weight, p) in enumerate(prepared)' in ast.unparse(t)
 if word==153:assert ex['complete_raw_branch_records']==45 and last['scope']=='Complete unrestricted153 selected word; no otherword coefficient'
 binding=json.loads((P/'l1-residual40-author-binding.json').read_text())['principal_source_sha256'];assert first['principal_source_sha256']==binding and len(binding)==16 and all(sha(A/f)==h for f,h in binding.items())
 assert first['source_sha256']==last['source_sha256']==ex['source_sha256']=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98'
 scientific[word]={'coefficient':last['coefficient'],'raw_numerator':last['raw_numerator'],'nonempty_preparations':45,'computed_raw_zero_branches':18,'peak_ordering_sensitive':last['peak_rows'],'cold_seconds':last['preparation_seconds'],'whole45_warm_seconds':last['whole45_warm_seconds'],'parent_seconds':ex['full_wall_seconds'],'actual_exit':0,'stdout_sha256':sha(P/(stem+'.out')),'exit_sha256':sha(P/(stem+'.exit.json')),'runner_sha256':sha(runner),'driver_sha256':sha(driver)};parsed[word]=(bs,prep)
 files.extend([P/(stem+ext) for ext in ('.out','.err','.exit.json')]+[runner,driver])
a,ap=parsed[110];b,bp=parsed[153]
for x,y in zip(a,b):assert all(x[k]==y[k] for k in ('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation'))
assert ap['word']['omitted']^1==bp['word']['omitted'] and sorted((q^1,axes) for q,axes in ap['word']['changes'])==sorted((q,axes) for q,axes in bp['word']['changes'])
assert sorted((q^1,a) for q,a in ap['fixed_forest'])==sorted(tuple(x) for x in bp['fixed_forest'])
def actionmap(edges):
 out=[]
 for (l,h,a),ks in edges:
  x,y=sorted((l^1,h^1));out.append(((x,y,a),tuple(sorted((q^1,axis) for q,axis in ks))))
 return sorted(out)
assert actionmap(ap['action_edges'])==sorted((tuple(e),tuple(sorted(tuple(k) for k in ks))) for e,ks in bp['action_edges'])
def maskmap(mask):
 sign=(-1)**sum(((mask>>(8*q))&255).bit_count()*((mask>>(8*(q^1)))&255).bit_count() for q in range(0,16,2));return sum(((mask>>(8*q))&255)<<(8*(q^1)) for q in range(16)),sign
for x,y in zip(ap['support_domains'],bp['support_domains']):
 assert {q^1:ds for q,ds in x['core_domains']}==dict(y['core_domains']) and {c['center']^1:{k:v for k,v in c.items() if k!='center'} for c in x['center_support']}=={c['center']:{k:v for k,v in c.items() if k!='center'} for c in y['center_support']}
 ym={tuple(f['source']):f for f in y['prepared_graph']['source_factors']}
 for f in x['prepared_graph']['source_factors']:
  other=ym[f['source'][0]^1,f['source'][1]];converted=[]
  for v in f['polynomial']:
   mask,sign=maskmap(v['mask']);converted.append((mask,sign*v['real'],sign*v['imag']))
  assert sorted(converted)==sorted((v['mask'],v['real'],v['imag']) for v in other['polynomial'])
# Independently executed complete110 retry, original failed attempt untouched.
rep=records('l1-110-review-replay-r2');rex=json.loads((P/'l1-110-review-replay-r2.exit.json').read_text());assert rex['actual_child_exit']==rex['actual_driver_exit']==0 and rex['actual_complete_branch_records']==45 and rex['invalid_lines']==0 and not rex['parent_timeout'] and rex['parent_seconds']<665 and not (P/'l1-110-review-replay-r2.err').read_bytes()
rb=[v for v in rep if v['kind']=='exact-branch'];prep=[v for v in rep if v['kind']=='prepared-branch'];last=rep[-1];assert len(rb)==len(prep)==45 and last['cold_seconds']<600 and last['whole45_warm_seconds']<60 and last['coefficient']==scientific[110]['coefficient'] and last['raw_numerator']==scientific[110]['raw_numerator']
for r,p in zip(rb,a):assert all(r[k]==p[k] for k in ('branch','weight','raw_numerator','divisor','coefficient','algebraic_empty_preparation'))
assert all(v['original_L_all_center_rows_equal'] and v['all15centers_beyond_fixed'] and v['all16site_degrees8'] and v['factor_count']==38 and v['label_count']==32 and v['bothsource_polynomials_equal_pilot'] and v['omitted_site4_retained'] for v in prep)
firstex=json.loads((P/'l1-110-review-replay.exit.json').read_text());assert firstex['actual_child_exit']==firstex['actual_driver_exit']==1 and firstex['actual_complete_branch_records']==0
annotation=json.loads((P/'l1-110-review-replay-attempt1-annotation.json').read_text());assert annotation['schema_mock_normalized_assertion_passes'] and annotation['only_runtime_assertion_normalization_changed']
for name,key in [('l1-110-review-replay.py','original_runner_sha256'),('l1-110-review-replay-driver.py','original_driver_sha256'),('l1-110-review-replay.out','original_stdout_sha256'),('l1-110-review-replay.err','original_stderr_sha256'),('l1-110-review-replay.exit.json','original_exit_sha256')]:assert sha(P/name)==annotation[key]
files.extend([P/n for n in ('l1-110-review-replay.py','l1-110-review-replay-driver.py','l1-110-review-replay.out','l1-110-review-replay.err','l1-110-review-replay.exit.json','l1-110-review-replay-r2.py','l1-110-review-replay-driver-r2.py','l1-110-review-replay-r2.out','l1-110-review-replay-r2.err','l1-110-review-replay-r2.exit.json','l1-110-review-replay-metadata-preflight.json','l1-110-review-replay-attempt1-annotation.json')])
replay={'verdict':'ACCEPT independent complete110 replay retry2; original failed validation attempt preserved','actual_handle':32867,'actual_child_driver_exit':0,'all45_raw_weight_divisor_fraction_equal_pilot':True,'all45_originalL_fullgamma_degree_source_table_checks':True,'coefficient':last['coefficient'],'raw_numerator':last['raw_numerator'],'peak_ordering_sensitive':last['peak_rows'],'cold_seconds':last['cold_seconds'],'whole45_warm_seconds':last['whole45_warm_seconds'],'parent_seconds':rex['parent_seconds'],'completed_branch_counter':45,'first_attempt':{'handle':71223,'actual_child_driver_exit':1,'complete_branches':0,'cause':'runtime tuple/int-key source provenance compared directly to JSON list/string-key representation','preserved':True,'correction':'serialization-normalized provenance assertion only; no scientific source or computation statement changed'}}
ind=json.loads((P/'l1-residual40-review-verification.json').read_text());assert ind['unique_structural_family']==[110,153] and set((110,153))<=set(ind['remaining40'])
subtotal=2*F(*last['coefficient']);result={'verdict':'ACCEPT complete scientific110/153 class and independent complete110 replay; portable/archive acceptance pending','words':scientific,'independent_replay':replay,'all90_branch_arithmetic':True,'all45_XOR1_raw_weight_divisor_fraction_core_fullgamma_sourcepoly_covariance':True,'branch_role_order':'3i+j remains3i+j, no transpose','actual_peaks_preserved_no_equal_peak_requirement':True,'same_axis_class_subtotal':[subtotal.numerator,subtotal.denominator],'class_exactly':[110,153],'class_disjoint_from_accepted232':True,'principal16_bindings_unchanged':True,'source_sha256':'a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98','preserved_author110_counter_defect':'reported0 because copied exact-fixed-branch filter; actual45 original exact-branch records preserved with annotation','files_sha256':{str(p):sha(p) for p in files},'portable_scope':232,'portable234':'NOT ACCEPTED until actual portable/archive review','remaining_unrestricted_after_scientific_class':38,'full_k4_sourceaction_commonZ_B3_modes_transport_main_publication':'OPEN'}
(P/'l1-110-review-replay-verification.json').write_text(json.dumps(replay,indent=2)+'\n');(P/'l1-110153-review-class-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files_sha256'},indent=2))
