from pathlib import Path
from collections import Counter,defaultdict
import ast,json,hashlib
AUDIT=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
manifest=next(r for r in map(json.loads,(AUDIT/'l1_k4_census.out.txt').read_text().splitlines()) if 'rows' in r)
assert hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b'
old=json.loads(Path('/tmp/l1-next52-author-classification.json').read_text());accepted={k:set(v) for k,v in old['accepted_populations'].items()};hashes={}
for filename in ('l1_extended_offset_witness_k4_both_source_square_free_torus.py','l1_extended_offset_witness_k4_two_square_protected_torus.py','l1_extended_offset_witness_k4_two_protected_tori.py','l1_extended_offset_witness_k4_connected_source_square_torus.py'):
 p=AUDIT/filename;tree=ast.parse(p.read_text());words=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EXPECTED_WORDS' for t in n.targets));accepted[filename]=set(words);hashes[filename]=hashlib.sha256(p.read_bytes()).hexdigest()
assert sum(map(len,accepted.values()))==len(set.union(*accepted.values()))==232
remaining=[row for row in manifest['rows'] if row['index'] not in set.union(*accepted.values())]
assert len(remaining)==40 and Counter(tuple(r['axes']) for r in remaining)=={(2,2):26,(2,3):14}
def graph(row):
 frame={q:(0,1) for q in range(16) if q!=row['omitted']};frame.update((q,tuple(axes)) for q,axes in row['changes']);sources=((0,row['axes'][0]),(1,row['axes'][1]));edges=defaultdict(list);faces={}
 for q,axes in sorted(frame.items()):
  for a in axes:
   y=q^(1<<a);edges[min(q,y),max(q,y),a].append((q,a))
  a,b=(a for a in range(4) if a not in axes);faces[q,a,b]={(q,a),(q^(1<<a),b),(q^(1<<b),a),(q,b)}
 protected=set(sources)|{(v,a) for lo,hi,a in edges for v in (lo,hi)};removed=[]
 while faces:
  counts=Counter(e for boundary in faces.values() for e in boundary);deletions=[f for f,b in faces.items() if any(counts[e]==1 and e not in protected for e in b)]
  if not deletions:break
  for f in deletions:removed.append(f);del faces[f]
 ends=Counter(v for q,a in sources for v in (q,q^(1<<a)));incoming=Counter(q^(1<<a) for q,axes in frame.items() for a in axes);assert all(4*(q in frame)+2*incoming[q]+2*ends[q]==8 for q in range(16))
 return frame,sources,edges,faces,protected,removed
records=[];selected=[];classes=defaultdict(list)
for row in remaining:
 frame,sources,edges,faces,protected,removed=graph(row);pending=set(faces);components=[]
 while pending:
  todo=[pending.pop()];comp=[]
  while todo:
   f=todo.pop();comp.append(f);neighbors={g for g in pending if faces[g]&faces[f]};pending-=neighbors;todo.extend(neighbors)
  components.append(sorted(comp))
 components.sort();joined=[]
 for q,a in sources:
  y=q^(1<<a);key=min(q,y),max(q,y),a
  if key in edges:joined.append((key,int(q!=edges[key][0][0])))
 sig=(tuple(row['axes']),tuple(sorted(len(c) for c in components)),tuple(sum(s in faces[f] for f in faces) for s in sources),len(joined));classes[str(sig)].append(row['index'])
 records.append({'word':row,'core':sorted(faces),'components':components,'face_boundaries':[(f,sorted(b)) for f,b in sorted(faces.items())],'action_edges':[(e,l) for e,l in sorted(edges.items())],'source_face_incidence':[(s,[f for f,b in faces.items() if s in b]) for s in sources],'joined_source_edges':joined,'E':len(edges),'J':len(joined),'peeled':len(removed)})
 if len(faces)!=9:continue
 squares=[f for f,b in faces.items() if b<=protected]
 if len(squares)!=1:continue
 square,=squares
 if not set(sources)<=faces[square]:continue
 others={f:b for f,b in faces.items() if f!=square}
 if any(f[1:]!=(2,3) for f in others):continue
 tori=[{f:b for f,b in others.items() if f[0]&3==c} for c in sorted({f[0]&3 for f in others})]
 if len(tori)!=2 or any(len(t)!=4 for t in tori):continue
 prot=[t for t in tori if set.union(*t.values())&protected];free=[t for t in tori if not set.union(*t.values())&protected]
 if len(prot)!=1 or len(free)!=1:continue
 prot,free=prot[0],free[0];shared=faces[square]&set.union(*prot.values())
 if len(shared)!=1 or not shared<=set(sources) or set.union(*prot.values())&protected!=shared:continue
 assert not set.union(*free.values())&(set.union(*prot.values())|faces[square])
 shared_source,=shared;live=square[0],square[1];fixed=faces[square]-{live};assert set(sources)<=fixed
 parent={}
 def root(q):
  while q in parent:q=parent[q]
  return q
 for q,a in fixed:
  u,v=root(q),root(q^(1<<a));assert u!=v;parent[u]=v
 assert len(edges)==20 and not joined and len(removed)==6
 prot_sites={f[0] for f in prot};free_sites={f[0] for f in free};assert not prot_sites&free_sites and square[0] not in prot_sites|free_sites
 fixedkeys={(min(q,q^(1<<a)),max(q,q^(1<<a)),a) for q,a in fixed};fixed_action=[(e,l) for e,l in sorted(edges.items()) if e in fixedkeys]
 assert len(fixed_action)==1 and len(fixed_action[0][1])==1
 fixed_center=fixed_action[0][1][0][0];assert fixed_center in prot_sites
 q,a=live;y=q^(1<<a);livekey=min(q,y),max(q,y),a;assert len(edges[livekey])==1 and edges[livekey][0][0] in prot_sites
 factors=[]
 for q,axes in sorted(frame.items()):factors.append((tuple((q,a) for a in axes)+((('square',0,'component'),) if q==square[0] else ()),{}))
 for e,labels in sorted(edges.items()):
  lo,hi,a=e;factors.append((tuple(labels)+((('square',0,'probe'),) if e==livekey else ()),{lo:2*len(labels),hi:2*len(labels)}))
 factors.append(((('square',0,'component'),('square',0,'probe')),{}))
 for q,a in sources:factors.append(((),{q:2,q^(1<<a):2}))
 counts=Counter(key for keys,d in factors for key in keys);assert len(factors)==38 and len(counts)==32 and set(counts.values())=={2}
 assert all(sum(d.get(q,0) for keys,d in factors)==8 for q in range(16))
 q,a=shared_source;linked=q,q^(1<<a);other=tuple(f[0] for f in prot if f[0] not in linked)
 selected.append({'word':row,'sources':sources,'square':square,'live':live,'fixed_forest':sorted(fixed),'shared_source':shared_source,'protected_torus':sorted(prot),'free_torus':sorted(free),'linked':linked,'other':other,'protected_centers':sorted(prot_sites),'free_centers':sorted(free_sites),'square_center':square[0],'live_action_labels':edges[livekey],'fixed_action_edges':fixed_action,'action_edges':[(e,l) for e,l in sorted(edges.items())],'center_selectors':{str(q):'square_component' if q==square[0] else 'protected_torus_core' if q in prot_sites else 'free_torus_core' if q in free_sites else 'peeled' for q in sorted(frame)},'omitted_action_center_but_retained_Grassmann_site':row['omitted'],'E':20,'J':0,'peeled':6,'branches':45,'divisor':192**42*4**64*48**6*2**15,'symbolic_factor_count':38,'symbolic_label_count':32,'all_labels_twice_and_all16_degrees8':True})
assert [g['word']['index'] for g in selected]==[110,153]
result={'canonical_manifest_file':str(AUDIT/'l1_k4_census.out.txt'),'canonical_manifest_line':2,'manifest_sha256':'ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b','accepted_populations':{k:sorted(v) for k,v in accepted.items()},'accepted_additional_module_hashes':hashes,'scientifically_accepted_union':232,'timing_caveat':'Scientific78/80 accepted; final portable/archive review running at assignment, so no public232 acceptance inferred','remaining40_roster':[r['index'] for r in remaining],'remaining40_axes':{'same':26,'mixed':14},'classes':classes,'records':records,'next_complete_family':[110,153],'selected_geometry':selected,'execution_scope':'stdlib graph/AST/hash only; no physics imports or preparation/coefficient'}
Path('/tmp/l1-residual40-author-geometry.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'remaining40':result['remaining40_roster'],'classes':classes,'next_complete_family':result['next_complete_family'],'selected':selected},sort_keys=True))
