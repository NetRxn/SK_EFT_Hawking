from pathlib import Path
from fractions import Fraction
from types import SimpleNamespace
from contextlib import redirect_stdout,redirect_stderr
from io import StringIO
import ast,hashlib,json,sys
P=Path('/tmp');proposal=P/'l1-residual40-author-portable/l1_extended_offset_witness_k4_shared_square_protected_free_tori.py';original=P/'l1-residual40-author-source-r1.py';A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def funcs(p):return {n.name:n for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
a,b=funcs(original),funcs(proposal);science=('geometry','data','prepare','contraction','branches','solve');assert all(ast.dump(a[n],include_attributes=False)==ast.dump(b[n],include_attributes=False) for n in science)
assert sha(original)=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98' and sha(proposal)=='0cf1a5ad661240a518c1f03d66f53b71ca7d25b26dca687614ad82b7c33f73a1'
binding=json.loads((P/'l1-residual40-author-binding.json').read_text())['principal_source_sha256'];names=next(ast.literal_eval(n.value) for n in ast.walk(b['source_hashes']) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in n.targets));assert set(n+'.py' for n in names)==set(binding) and len(names)==16 and all(sha(A/f)==h for f,h in binding.items())
tree=ast.parse(proposal.read_text());pathcode=[ast.unparse(n) for n in tree.body if isinstance(n,(ast.Assign,ast.If,ast.Assert))];assert 'AUDIT = Path(__file__).resolve().parent' in pathcode
assert any('Path(m.__file__).parent == AUDIT' in c for c in pathcode) and any('Path(m.__file__).parent == AUDIT' in ast.unparse(n) for n in ast.walk(b['source_hashes']))
assert any('k2.ROW_CAP == 120000 and k2.PAIR_CAP == 3000000'==ast.unparse(n.test) for n in tree.body if isinstance(n,ast.Assert))
# Exact helper behavior with opaque prepared table objects, no scientific modules or tensors.
namespace={'Fraction':Fraction};g=SimpleNamespace(linked=(1,5),other=(9,13));restrict=object();core=[object() for i in range(45)];tables=[([object()],60,object()) if i!=4 else None for i in range(45)];weights=[Fraction((i+1)*(-1 if i%7==0 else 1),16) for i in range(45)];calls=[]
namespace['branches']=lambda actual_g:iter(zip(weights,core)) if actual_g is g else (_ for _ in ()).throw(AssertionError('wrong geometry'))
def fakeprepare(actual_g,actual_core,actual_restrict):
 assert actual_g is g and actual_restrict is restrict;i=len(calls);assert actual_core is core[i];calls.append(i);return tables[i]
namespace['prepare']=fakeprepare
for name in ('prepare_branches','contract_prepared'):exec(compile(ast.Module(body=[b[name]],type_ignores=[]),str(proposal),'exec'),namespace)
prepared=namespace['prepare_branches'](g,restrict);assert calls==list(range(45)) and all(p[1] is t for p,t in zip(prepared,tables))
seen=[]
def fake_eliminate(factors,exclusive):
 i=next(i for i,t in enumerate(tables) if t is not None and t[0] is factors);assert tables[i][2] is exclusive;seen.append(i);return (i+1)*60,i+100
namespace['k3']=SimpleNamespace(eliminate_components=fake_eliminate);events=[];value,peak=namespace['contract_prepared'](prepared,60,events.append)
assert seen==[i for i in range(45) if i!=4] and len(events)==45 and peak==144
assert value==sum((weights[i]*Fraction((i+1)*60 if i!=4 else 0,60) for i in range(45)),Fraction())
for i,e in enumerate(events):assert e['branch']==i and e['weight']==[weights[i].numerator,weights[i].denominator] and e['algebraic_empty_preparation']==(i==4) and e['raw_numerator']==((i+1)*60 if i!=4 else 0)
try:namespace['contract_prepared'](prepared,61)
except AssertionError:pass
else:raise AssertionError('divisor mismatch not rejected')
assert len(calls)==45 # contraction never calls prepare again
# Run actual argparse/main AST against inert geometry and opaque prepared-table mocks.
mainns={'Fraction':Fraction,'json':json,'EXPECTED_WORDS':(110,153),'EXPECTED_MANIFEST_SHA256':'ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b','__doc__':'Portable review mock CLI','perf_counter':lambda:1.0}
gs={i:SimpleNamespace(frame={0:(0,1),1:(0,1)},divisor=64) for i in (110,153)};data_calls=[];prep_calls=[];contract_calls=[]
mainns['data']=lambda:(data_calls.append(True) or {i:({'index':i},gs[i]) for i in (110,153)})
mainns['source_hashes']=lambda:{'evaluator':sha(proposal)};mainns['k2']=SimpleNamespace(ROW_CAP=120000,PAIR_CAP=3000000);mainns['k3']=SimpleNamespace(witness=SimpleNamespace(FIXED_GAMMAS=((0,0),(1,1))))
mainns['describe']=lambda row,g:{'word':row,'divisor':g.divisor};opaque={i:object() for i in (110,153)}
def prepstub(g,restrict=None):
 i=next(i for i in (110,153) if gs[i] is g);prep_calls.append((i,restrict));return opaque[i]
def contractstub(p,d):
 i=next(i for i in (110,153) if opaque[i] is p);assert d==64;contract_calls.append(i);return Fraction(9,4),7
mainns['prepare_branches']=prepstub;mainns['contract_prepared']=contractstub
exec(compile(ast.Module(body=[b['main']],type_ignores=[]),str(proposal),'exec'),mainns)
def cli(args):
 old=sys.argv;sys.argv=['portable.py',*args];stdout,stderr=StringIO(),StringIO();code=0
 try:
  with redirect_stdout(stdout),redirect_stderr(stderr):
   try:mainns['main']()
   except SystemExit as e:code=e.code
 finally:sys.argv=old
 return code,stdout.getvalue(),stderr.getvalue()
code,out,err=cli([]);v=json.loads(out);assert code==0 and v['valid_words']==[110,153] and not prep_calls and not contract_calls
for word in (110,153):
 code,out,err=cli(['--word',str(word)]);v=json.loads(out);assert code==0 and v['word']['index']==word and v['branches']==45 and v['raw_numerator']==144 and prep_calls[-1]==(word,None) and contract_calls[-1]==word
prep_calls.clear();contract_calls.clear();code,out,err=cli(['--controls-only']);v=[json.loads(l) for l in out.splitlines()];assert code==0 and all(r['branches']==45 for r in v) and [r['word'] for r in v]==[110,153] and [i for i,r in prep_calls]==[110,153] and contract_calls==[110,153]
assert all(r=={0:((0,0),(1,1)),1:((0,0),(1,1))} for i,r in prep_calls)
refusals={}
for args in (['--word','109'],['--word','154'],['--word','110','--controls-only'],['--word','notint'],['--unknown']):
 before=len(data_calls);code,out,err=cli(args);assert code==2 and len(data_calls)==before and not out;refusals[' '.join(args)]=code
r={'verdict':'ACCEPT portable source/design; actual scientific CLI/archive acceptance pending','review_scope':'stdlib AST/source/hash inspection and inert helper/argparse tests only; no scientific imports or full coefficient','portable_sha256':sha(proposal),'original_sha256':sha(original),'six_scientific_ASTs_equal':list(science),'sixteen_named_sibling_bindings_match':True,'sibling_path_guards_verified':True,'original_caps':{'row':120000,'pair':3000000},'prepared_table_identity_retained':True,'prepare_calls_per45':45,'contract_prepared_prepare_calls':0,'all45_emit_branch_records_and_exact_weighted_arithmetic':True,'None_table_zero_branch_verified':True,'divisor_mismatch_refused':True,'main_default_census':[110,153],'main_unrestricted_word_modes':[110,153],'main_controls_only_fixed_modes':[110,153],'main_prepares_once_reuses_exact_tables':True,'CLI_refusals':refusals,'no_original_receipt_or_typo_annotation_modified':True,'portable_scope':232}
(P/'l1-110153-review-portable-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
# Actual metadata writer, using captured pure geometry rather than a scientific import.
describens={};exec(compile(ast.Module(body=[b['describe']],type_ignores=[]),str(proposal),'exec'),describens)
captured=json.loads((P/'l1-residual40-author-geometry.json').read_text());descriptions=[]
for meta in captured['selected_geometry']:
 square=tuple(meta['square']);live=tuple(meta['live']);fixed={tuple(e):None for e in meta['fixed_forest']};edges={tuple(e):[tuple(k) for k in labels] for e,labels in meta['action_edges']}
 fixededges={(min(q,q^(1<<a)),max(q,q^(1<<a)),a):int(q>q^(1<<a)) for q,a in fixed}
 gmeta=SimpleNamespace(edges=edges,fixed_edges=fixededges,lives=(live,),sources=tuple(tuple(x) for x in meta['sources']),squares=(square,),fixed_sources={tuple(x) for x in meta['sources']},fixed_square={square:fixed},shared_source=tuple(meta['shared_source']),protected_torus={tuple(f):None for f in meta['protected_torus']},free_tori=[{tuple(f):None for f in meta['free_torus']}],linked=tuple(meta['linked']),other=tuple(meta['other']),joined_source={},divisor=meta['divisor'])
 actual=describens['describe'](meta['word'],gmeta);assert actual['Grassmann_sites']==list(range(16)) and actual['omitted_action_center_retained_site']==meta['word']['omitted'] and actual['action_edges']==20 and actual['peeled']==6 and actual['joined_edges']==[] and len(actual['free_torus'])==len(actual['protected_torus'])==4
 assert actual['fixed_sources']==[(0,2),(1,2)] and actual['sources']==((0,2),(1,2)) and len(actual['fixed_action_edges'])==1 and len(actual['fixed_action_edges'][0][1])==1
 descriptions.append(actual)
vp=P/'l1-110153-review-portable-verification.json';v=json.loads(vp.read_text());v['actual_describe_AST_checked_for_both_words']=True;v['retained_omitted_site_all16_sources_E20_J0_6peeled_metadata']=True;v['negative_mock_weights_retained']=True;v['all45_helpers_iterate_new_branches_not_protected15']=True;vp.write_text(json.dumps(v,indent=2)+'\n');print('actual describe metadata110/153 PASS')
