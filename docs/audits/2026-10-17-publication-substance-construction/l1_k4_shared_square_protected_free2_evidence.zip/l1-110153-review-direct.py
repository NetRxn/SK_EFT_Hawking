from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product,combinations
from functools import cache
from math import prod
import runpy,json,hashlib,signal,time
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');start=time.perf_counter();signal.alarm(600)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(kind,**v):print(json.dumps(dict(kind=kind,**v),sort_keys=True),flush=True)
source=P/'l1-residual40-author-source-r1.py';assert sha(source)=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98'
binding=json.loads((P/'l1-residual40-author-binding.json').read_text())['principal_source_sha256'];assert len(binding)==16 and all(sha(A/n)==h for n,h in binding.items())
emit('direct-start',source_sha256=sha(source),principal_source_sha256=binding,scope='DIRECT110/153 ONLY, no fixed scalar replay or unrestricted coefficient',inner_seconds=600,parent_seconds=665)
s=runpy.run_path(str(source),run_name='independent_residual40_direct');k2,k3=s['k2'],s['k3'];found=s['data']();assert list(found)==[110,153]
from l1_direct_b_haar import R,add,scale,wedge
from l1_extended_opposed_source import frame,action_frame
from l1_extended_two_mixed_centers import remap
from l1_normalization_opposed_fourth import nodes,L
from l1_extended_offset_square import cubature_edge
from l1_extended_mixed_curvature_core import conditional,face_vector
from l1_extended_mixed_center_gamma import COMPONENTS
from l1_normalization_uniform_mixed_edge import unit
# Accepted independent polynomial reference functions, copied without its module-level run.
exec(compile((P/'l1-110153-review-reference.py').read_text(),str(P/'l1-110153-review-reference.py'),'exec'))
pairs=tuple((a,b) for a in range(8) for b in range(a,8))
@cache
def original_weights(domain):
 out=Counter()
 for a,b,c,d in product(range(4),repeat=4):
  for i,u in L[a,c]:
   for j,v in L[b,d]:out[tuple(sorted((a,b))),tuple(sorted((c,d)))]+=u*v*(12*int(i==j) if domain is None else int(tuple(sorted((i,j))) in domain))
 return {k:v for k,v in out.items() if v}
ident=frame(0,False,unit(0),unit(0));source_ref=scale(add(*(wedge(v,v) for v in ident)),192);raw_source=add(*(k3.witness.anchored(0,(),None,j) for j in range(4)));assert raw_source==source_ref
for j in range(4):assert k3.witness.anchored(0,(),None,j)==scale(wedge(ident[j],ident[j]),192)
q4=(F(1,2),)*4;q4s=(F(1,2),F(-1,2),F(1,2),F(-1,2));q34=(F(3,5),F(4,5),F(),F());q34p=(F(),F(3,5),F(),F(-4,5))
samples=[(unit(i),unit(j)) for i,j in product(range(4),repeat=2)]+[(q4,q4s),(q4s,q4),(q34,q34p),(q34p,q4),(q4,tuple(-x for x in q4s))]
patterns=[((0,0),)*4,((0,0),(3,3),(0,0),(0,0)),((0,1),(0,1),(0,0),(0,0)),((1,2),(1,2),(0,0),(3,3)),((0,0),(0,0),(3,3),(3,3)),((3,4),(3,4),(3,3),(3,3)),((0,3),(0,3),(0,0),(0,0))]
for word,(row,g) in found.items():
 square=g.squares[0];live=g.lives[0];fixed=g.fixed_square[square];sqrows=k3.square_factor(square,live,fixed);offdiag=0
 for left,right in samples:
  coords={**fixed,live:(left,right)};q=left+right
  for labels in COMPONENTS:
   direct=prod(vector(square,coords,l) for l in labels);assert direct==prod(face_vector(square,coords,*divmod(l,3)) for l in labels)
   assert direct==sum(w*q[a]*q[b] for (c,(a,b)),w in sqrows.items() if c==labels)
   offdiag+=sum(bool(w*q[a]*q[b]) and a!=b for (c,(a,b)),w in sqrows.items() if c==labels)
 assert offdiag>0
 branches=list(s['branches'](g));assert len(branches)==45 and sum(w<0 for w,c in branches)==6
 pt,ft=g.protected_torus,g.free_tori[0];pb=list(k2.protected_branches(g.linked,g.other));fb=list(k2.free_branches(ft));assert branches==[(w*v,c|d) for w,c in pb for v,d in fb]
 porder=g.linked+g.other;forder=tuple(f[0] for f in ft);pvalues=[];fvalues=[];plabels=[];flabels=[]
 for pattern in patterns:
  pmap=dict(zip(porder,pattern));fmap=dict(zip(forder,pattern));pface={f:pmap[f[0]] for f in pt};fface={f:fmap[f[0]] for f in ft}
  pd=independent_integral(pt,{g.shared_source:(unit(0),unit(0))},pface,F(1));fd=independent_integral(ft,{},fface,F(1))
  assert pd==conditional(pt,{g.shared_source},{g.shared_source:(unit(0),unit(0))},pface)==k2.formula(pb,pmap)
  assert fd==conditional(ft,set(),{},fface)==k2.formula(fb,fmap)
  pvalues.append(pd);fvalues.append(fd);plabels.append(pface);flabels.append(fface)
 checked=0
 for i,j in product(range(7),repeat=2):
  labels={f[0]:x for f,x in (plabels[i]|flabels[j]).items()};formula=sum(w for w,core in branches if all(labels[q] in domain for q,domain in core.items()));assert formula==pvalues[i]*fvalues[j];checked+=1
 # Full disconnected eight-face closure including scalar square, not a final Grassmann product.
 for i,j in ((0,0),(1,4),(2,2),(3,4),(4,1),(5,5),(6,6)):
  allfaces=pt|ft;alllabels=plabels[i]|flabels[j]
  coords={**fixed,live:(q4,q4s)};labels=(0,1) if i%2 else (0,3);scalar=prod(vector(square,coords,l) for l in labels)
  joint=independent_integral(allfaces,{g.shared_source:(unit(0),unit(0))},alllabels,scalar);assert joint==scalar*pvalues[i]*fvalues[j]
 # Nonidentity joint forest gauge covariance, all9 actual face holonomies.
 allfaces={square:set(fixed)|{live},**pt,**ft};edges=set.union(*allfaces.values());coords={e:samples[16+i%5] for i,e in enumerate(sorted(edges))};gauges={0:(unit(0),unit(0))};pending=set(fixed)
 while pending:
  e=next(e for e in pending if e[0] in gauges or (e[0]^(1<<e[1])) in gauges);q,a=e;y=q^(1<<a)
  if q in gauges:gauges[y]=tuple(mul(gauges[q][ch],adj(coords[e][ch])) for ch in (0,1))
  else:gauges[q]=tuple(mul(gauges[y][ch],coords[e][ch]) for ch in (0,1))
  pending.remove(e)
 for q in range(16):gauges.setdefault(q,(q4s,q34))
 transformed={e:tuple(mul(mul(gauges[e[0]^(1<<e[1])][ch],coords[e][ch]),adj(gauges[e[0]][ch])) for ch in (0,1)) for e in edges}
 assert all(transformed[e]==(unit(0),unit(0)) for e in fixed)
 for f in allfaces:
  for ch in (0,1):assert hol(f,transformed,ch)==mul(mul(gauges[f[0]][ch],hol(f,coords,ch)),adj(gauges[f[0]][ch]))
 for q,a in g.sources:assert remap(raw_source,(q,q^(1<<a)))==remap(source_ref,(q,q^(1<<a)))
 assert row['omitted'] in {q^(1<<a) for q,a in g.sources}
 emit('conditional45-direct',word=word,protected_patterns=7,free_patterns=7,cartesian_formula_checks=checked,joint_nineface_closures=7,square_samples=21,square_components=21,activated_offdiagonal_terms=offdiag,nonidentity_F3_nineface_covariance=True,both_fixed_source_remaps=True,omitted_source_Grassmann_site_retained=row['omitted'])
 # Exact gamma weights at ALL8 core centers for ALL45 product domains; actual fixed prepared graphs (no scalar contractions).
 restrictions=dict.fromkeys(g.frame,k3.witness.FIXED_GAMMAS);nonempty=0;empty=0;cross_checks=0
 for b,(weight,core) in enumerate(branches):
  assert len(core)==8 and square[0] not in core
  for q in g.frame:
   domain=core.get(q)
   if q!=square[0]:assert original_weights(None if domain is None else tuple(domain))==k3.witness.center_weights(domain)
  p=s['prepare'](g,core,restrictions)
  if p is None:
   assert any(not original_weights(tuple(domain)).get(restrictions[q],0) for q,domain in core.items());empty+=1;continue
  nonempty+=1;factors,divisor,exclusive=p
  assert divisor==g.divisor==192**42*4**64*48**6*2**15 and len(factors)==38
  counts=Counter(k for keys,rows,degrees in factors for k in keys);assert len(counts)==32 and set(counts.values())=={2}
  assert all(sum(degrees.get(q,0) for keys,rows,degrees in factors)==8 for q in range(16))
  for ci,(q,axes) in enumerate(sorted(g.frame.items())):
   keys,rows,degrees=factors[ci];comp=sorted({k[2] for k in rows}) if q==square[0] else (None,);expected={}
   for c in comp:
    domain=(c,) if q==square[0] else core.get(q);weights=original_weights(None if domain is None else tuple(domain));gamma=restrictions[q];w=weights.get(gamma,0)
    if w and not any(gamma[j][0]!=gamma[j][1] for j,key in enumerate(keys[:2]) if key in exclusive):expected[gamma+((c,) if q==square[0] else ())]={0:(w,0)}
   assert rows==expected
  for qi,(q,a) in enumerate(g.sources):
   y=q^(1<<a);assert factors[-2+qi]==((),{():k3.witness.gaussian(remap(source_ref,(q,y)))},{q:2,y:2})
  ps={f[0] for f in pt};fs={f[0] for f in ft}
  for ei,(edge,labels) in enumerate(sorted(g.edges.items())):
   if any(q in ps for q,a in labels) and any(q in fs for q,a in labels):
    keys,rows,degrees=factors[15+ei];assert keys==tuple(labels) and len(keys)==2 and set(degrees.values())=={4};cross_checks+=1
  assert sum(f[2].get(row['omitted'],0) for f in factors[15:35])==6 and sum(f[2].get(row['omitted'],0) for f in factors[-2:])==2
 emit('gamma-and-prepared-graphs-direct',word=word,branches=45,nonempty=nonempty,structural_empty=empty,core_centers=8,all_centerweights_original_L=True,full_factor_predicates_checked=True,both_source_polys_checked=True,omitted_site_action6_source2=True,protected_free_cross_action_factor_checks=cross_checks,scalar_contractions_run=0)
# NEW singleton fixed moments, not the previous two-center edge case.
fixed_checks=0
for center,anchor,labels in product((0,1),(0,1),((0,0),(0,1),(1,2),(2,3))):
 exact=k3.fixed_action_edge((labels,),(center,),anchor);direct=cubature_edge((labels,),(center,),anchor);assert exact==direct;fixed_checks+=1
emit('singleton-fixed-edge-direct',full_polynomial_equalities=fixed_checks,actual_orientations=[[1,0],[0,1]],gamma_cases=4)
# Direct original-frame cubature for the actual live orientations and offdiagonal probe monomials.
rule=tuple(nodes());live_checks=0
for center,anchor in ((1,0),(0,1)):
 for labels,probe in product(((0,0),(0,1),(1,2)),((1,1),(1,2),(1,5))):
  terms=[]
  for n in (0,2):
   for chosen in combinations(range(2),n):
    chunks=tuple(tuple(labels[i] for i in range(2) if (i in chosen)==(a==0)) for a in (0,1));factors=[]
    for local,chunk in enumerate(chunks):
     vals=[]
     for left,right,weight in rule:
      t=action_frame(0,local^center,left,right)
      if center:t=[scale(remap(v,(1,0)),-1) for v in t]
      poly={0:R.one}
      for j in chunk:poly=wedge(poly,t[j])
      qq=left+right;extra=qq[probe[0]]*qq[probe[1]] if local==anchor else 1;vals.append(scale(poly,weight*extra))
     factors.append(add(*vals))
    terms.append(wedge(*factors))
  direct=add(*terms);assert direct and direct==scale(k3.probed_action_edge(labels,center,anchor,probe),4);live_checks+=1
emit('actual-live-probe-direct',full_polynomial_equalities=live_checks,actual_orientations=[[1,0],[0,1]],all_nonzero=True,offdiagonal_probes=[[1,2],[1,5]])
assert all(sha(A/n)==h for n,h in binding.items()) and sha(source)=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98'
signal.alarm(0);emit('direct-controls-complete',seconds=time.perf_counter()-start,principal16_bindings_unchanged=True,source_sha256=sha(source),row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP,fixed_scalar_replays_run=0,unrestricted_coefficients_run=0)
