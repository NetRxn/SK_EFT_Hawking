import sys,json,runpy,signal,time,hashlib
from pathlib import Path
from fractions import Fraction
from collections import Counter
word=153
start=time.perf_counter();signal.alarm(600)
source=Path('/tmp/l1-residual40-author-source-r1.py');source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
assert source_sha=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98'
binding=json.loads(Path('/tmp/l1-residual40-author-binding.json').read_text())['principal_source_sha256']
root=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
assert len(binding)==16 and all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in binding.items())
print(json.dumps({'kind':'phase-start','phase':'cold-unrestricted-preparation','word':word,'scope':'Complete unrestricted153 ONLY','hard_limit_seconds':600,'source_sha256':source_sha,'principal_source_sha256':binding}),flush=True)
s=runpy.run_path(str(source),run_name='connected_core_fixed_source');row,g=s['data']()[word]
restrict={};assert not restrict
square=g.squares[0];square_center=square[0];torus_centers={f[0] for f in g.protected_torus};free_centers={f[0] for f in g.free_tori[0]}
assert not torus_centers&free_centers and square_center not in torus_centers|free_centers
assert row['omitted'] not in g.frame and row['omitted'] in {v for q,a in g.sources for v in (q,q^(1<<a))}
comp_domain=sorted({labels for labels,probe in s['k3'].square_factor(square,g.lives[0],g.fixed_square[square])})
prepared=[];supports=[]
for branch,(weight,core) in enumerate(s['branches'](g)):
 p=s['prepare'](g,core);prepared.append((weight,p));centers=[];graph_audit=None
 if p is not None:
  fs,local_divisor,exclusive=p
  counts=Counter(key for keys,rows,degrees in fs for key in keys)
  site_degrees={q:sum(degrees.get(q,0) for keys,rows,degrees in fs) for q in range(16)}
  assert len(fs)==38 and len(counts)==32 and set(counts.values())=={2} and site_degrees==dict.fromkeys(range(16),8)
  for center_index,(q,axes) in enumerate(sorted(g.frame.items())):
   keys,rows,degrees=fs[center_index]
   centers.append({'center':q,'selector':'square_component' if q==square_center else 'protected_torus_core' if q in torus_centers else 'free_torus_core' if q in free_centers else 'peeled','rows':[{'labels':key,'weight':value[0][0]} for key,value in sorted(rows.items())]})
  source_factors=[]
  for source_label,factor in zip(g.sources,fs[-2:],strict=True):
   keys,rows,degrees=factor;assert not keys
   source_factors.append({'source':source_label,'degrees':degrees,'polynomial':[{'mask':mask,'real':value[0],'imag':value[1]} for mask,value in sorted(rows[()].items())]})
  graph_audit={'factors':len(fs),'labels':len(counts),'all_labels_twice':True,'site_degrees':site_degrees,'factor_row_slots':[sum(map(len,rows.values())) for keys,rows,degrees in fs],'source_factors':source_factors}
 supports.append({'branch':branch,'protected_branch_index':branch//3,'free_branch_index':branch%3,'weight':[weight.numerator,weight.denominator],'core_domains':sorted(core.items()),'center_support':centers,'prepared_graph':graph_audit,'algebraic_empty_preparation':p is None})
assert len(prepared)==45
fixed_keys=set(g.fixed_edges);fixed_action=[(edge,labels) for edge,labels in sorted(g.edges.items()) if edge in fixed_keys]
assert len(fixed_action)==1 and fixed_action[0][1]==([(5,0)] if word==110 else [(4,0)])
q,a=g.lives[0];live_key=min(q,q^(1<<a)),max(q,q^(1<<a)),a
assert len(g.edges[live_key])==1 and g.edges[live_key][0][0] in torus_centers
prep=time.perf_counter()-start
print(json.dumps({'kind':'phase-complete','phase':'cold-unrestricted-preparation','seconds':prep,'word':row,'branches':45,'restrictions':sorted(restrict.items()),'support_domains':supports,'divisor':g.divisor,'sources':g.sources,'fixed_sources':sorted(g.fixed_sources),'fixed_forest':sorted(g.fixed_square[square]),'shared_source':g.shared_source,'square':square,'live':g.lives[0],'live_action_labels':g.edges[live_key],'fixed_action_edges':fixed_action,'torus_centers':sorted(torus_centers),'free_centers':sorted(free_centers),'protected_torus':sorted(g.protected_torus),'free_torus':sorted(g.free_tori[0]),'omitted_action_center_retained_Grassmann_site':row['omitted'],'all_Grassmann_sites':list(range(16)),'linked':g.linked,'other':g.other,'action_edges':[(e,l) for e,l in sorted(g.edges.items())],'row_cap':s['k2'].ROW_CAP,'pair_cap':s['k2'].PAIR_CAP}),flush=True)
signal.alarm(60);began=time.perf_counter()
print(json.dumps({'kind':'phase-start','phase':'warm-WHOLE45-unrestricted-contraction','hard_limit_seconds':60,'word':word}),flush=True)
total=Fraction();peak=0
for branch,(weight,p) in enumerate(prepared):
 if p is None:raw,size,divisor=0,0,g.divisor
 else:
  factors,divisor,exclusive=p;raw,size=s['k3'].eliminate_components(factors,exclusive)
 value=Fraction(raw,divisor);total+=weight*value;peak=max(peak,size)
 print(json.dumps({'kind':'exact-branch','word':word,'branch':branch,'weight':[weight.numerator,weight.denominator],'raw_numerator':raw,'divisor':divisor,'coefficient':[value.numerator,value.denominator],'algebraic_empty_preparation':p is None,'peak_rows':size}),flush=True)
raw=total*g.divisor;assert raw.denominator==1
warm_seconds=time.perf_counter()-began;signal.alarm(0)
print(json.dumps({'kind':'exact-word','word':row,'scope':'Complete unrestricted153 selected word; no otherword coefficient','coefficient':[total.numerator,total.denominator],'raw_numerator':raw.numerator,'divisor':g.divisor,'branches':45,'peak_rows':peak,'preparation_seconds':prep,'whole45_warm_seconds':warm_seconds,'full_seconds':time.perf_counter()-start,'source_sha256':source_sha}),flush=True)
