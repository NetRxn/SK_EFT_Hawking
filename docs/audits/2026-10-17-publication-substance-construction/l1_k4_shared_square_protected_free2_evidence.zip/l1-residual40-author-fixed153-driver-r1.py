"""Prepared runner only: separate ROOT authorization is required before execution."""
import subprocess,time,json,hashlib,sys
from pathlib import Path
RUNNER=Path('/tmp/l1-residual40-author-fixed-runner-r1.py')
EXPECTED_RUNNER_SHA256='a9d52ce03c03ea2494a2ffad96d92faf5dea0fab2e2c97d70d6baf51aa8b7406'
PREFIX='/tmp/l1-residual40-author-fixed153-r1'
EXECUTABLE='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'

def main():
 start=time.perf_counter();outpath=Path(PREFIX+'.out');errpath=Path(PREFIX+'.err');exitpath=Path(PREFIX+'.exit.json')
 assert hashlib.sha256(RUNNER.read_bytes()).hexdigest()==EXPECTED_RUNNER_SHA256
 if any(p.exists() for p in (outpath,errpath,exitpath)):
  raise FileExistsError('Preserve original streams; use a newly reviewed attempt driver rather than overwrite')
 command=[EXECUTABLE,'-B',str(RUNNER),'153'];parent_timeout=False
 with outpath.open('xb') as out,errpath.open('xb') as err:
  process=subprocess.Popen(command,stdout=out,stderr=err)
  try:child_exit=process.wait(timeout=665)
  except subprocess.TimeoutExpired:
   parent_timeout=True;process.kill();child_exit=process.wait()
 driver_exit=124 if parent_timeout else (0 if child_exit==0 else 1)
 complete_records=[];truncated_lines=0
 for line in outpath.read_text(errors='replace').splitlines():
  try:complete_records.append(json.loads(line))
  except ValueError:truncated_lines+=1
 last_phase=next((r.get('phase') for r in reversed(complete_records) if r.get('kind') in ('phase-start','phase-complete')),None)
 receipt={'exit_code':child_exit,'actual_child_exit_code':child_exit,'driver_exit_code':driver_exit,'parent_timeout':parent_timeout,'word':153,'full_wall_seconds':time.perf_counter()-start,'cold_limit_seconds':600,'whole45_fixed_warm_limit_seconds':60,'parent_wall_limit_seconds':665,'last_complete_phase_record':last_phase,'complete_raw_branch_records':sum(r.get('kind')=='exact-fixed-branch' for r in complete_records),'truncated_or_nonJSON_lines':truncated_lines,'executable':EXECUTABLE,'command':command,'runner_sha256':EXPECTED_RUNNER_SHA256,'source_sha256':'a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98','scope':'FIXED-action-gamma control ONLY; no unrestricted coefficient'}
 exitpath.write_text(json.dumps(receipt,sort_keys=True)+'\n');print(json.dumps(receipt),flush=True)
 return driver_exit

if __name__=='__main__':raise SystemExit(main())
