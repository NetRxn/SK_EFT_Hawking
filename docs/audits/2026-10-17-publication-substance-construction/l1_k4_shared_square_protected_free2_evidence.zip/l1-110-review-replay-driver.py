from pathlib import Path
import subprocess,time,json
P=Path('/tmp');STEM=P/'l1-110-review-replay';BRANCH_KIND='exact-branch'
def count_complete_branches(records):return sum(r.get('kind')==BRANCH_KIND for r in records)
def main():
 start=time.perf_counter();out=Path(str(STEM)+'.out');err=Path(str(STEM)+'.err');exitpath=Path(str(STEM)+'.exit.json');assert not any(p.exists() for p in (out,err,exitpath))
 command=['/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python','-B',str(STEM)+'.py'];timed=False
 with out.open('xb') as o,err.open('xb') as e:
  p=subprocess.Popen(command,stdout=o,stderr=e)
  try:code=p.wait(timeout=665)
  except subprocess.TimeoutExpired:timed=True;p.kill();code=p.wait()
 records=[];bad=0
 for line in out.read_text().splitlines():
  try:records.append(json.loads(line))
  except ValueError:bad+=1
 count=count_complete_branches(records);drivercode=0 if code==0 and not timed and count==45 and bad==0 else 1
 result={'actual_child_exit':code,'actual_driver_exit':drivercode,'parent_timeout':timed,'parent_seconds':time.perf_counter()-start,'cold_bound':600,'whole45_warm_bound':60,'parent_bound':665,'actual_complete_branch_kind':BRANCH_KIND,'actual_complete_branch_records':count,'invalid_lines':bad,'command':command,'scope':'Complete unrestricted110 independent replay ONLY'}
 exitpath.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 if drivercode:print(err.read_text(),flush=True)
 return drivercode
if __name__=='__main__':raise SystemExit(main())
