"""Scratch-only AST/mock audit; never imports or executes scientific kernels."""
import argparse,ast,hashlib,json
from pathlib import Path

def audit(runner_path,driver_path,mode,word):
 runner=Path(runner_path);driver=Path(driver_path);rt=ast.parse(runner.read_text());dt=ast.parse(driver.read_text())
 def strings(tree,key):
  out=[]
  for n in ast.walk(tree):
   if isinstance(n,ast.Dict):
    for k,v in zip(n.keys,n.values,strict=True):
     if isinstance(k,ast.Constant) and k.value==key and isinstance(v,ast.Constant):out.append(v.value)
  return out
 emitted=set(strings(rt,'kind'));scopes=strings(rt,'scope')+strings(dt,'scope')
 expected='exact-branch' if mode=='unrestricted' else 'exact-fixed-branch'
 final='exact-word' if mode=='unrestricted' else 'exact-fixed-word'
 predicates=[]
 for n in ast.walk(dt):
  if not(isinstance(n,ast.Compare) and len(n.ops)==1 and isinstance(n.ops[0],ast.Eq) and len(n.comparators)==1 and isinstance(n.comparators[0],ast.Constant) and isinstance(n.comparators[0].value,str)):continue
  left=n.left
  if isinstance(left,ast.Call) and isinstance(left.func,ast.Attribute) and isinstance(left.func.value,ast.Name) and left.func.value.id=='r' and left.func.attr=='get' and len(left.args)==1 and isinstance(left.args[0],ast.Constant) and left.args[0].value=='kind':predicates.append(n)
 fixtures=[{'kind':'phase-start'},{'kind':'phase-complete'}]+[{'kind':expected,'branch':i} for i in range(45)]+[{'kind':final}]
 counter_checks=[]
 for predicate in predicates:
  expr=compile(ast.fix_missing_locations(ast.Expression(predicate)),'<mock-record-counter>','eval')
  actual=sum(bool(eval(expr,{'__builtins__':{}},{'r':r})) for r in fixtures)
  opposite='exact-fixed-branch' if mode=='unrestricted' else 'exact-branch'
  false_positive=bool(eval(expr,{'__builtins__':{}},{'r':{'kind':opposite}}))
  counter_checks.append({'counter_kind':predicate.comparators[0].value,'actual_fixture_count':actual,'expected_fixture_count':45,'opposite_mode_false_positive':false_positive,'pass':actual==45 and not false_positive})
 alarms=[n.args[0].value for n in ast.walk(rt) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='signal' and n.func.attr=='alarm' and len(n.args)==1 and isinstance(n.args[0],ast.Constant)]
 parent_limits=[k.value.value for n in ast.walk(dt) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='wait' for k in n.keywords if k.arg=='timeout' and isinstance(k.value,ast.Constant)]
 assigned_words=[n.value.value for n in rt.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='word' for t in n.targets) and isinstance(n.value,ast.Constant)]
 source_hash='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98'
 source_unchanged=hashlib.sha256(Path('/tmp/l1-residual40-author-source-r1.py').read_bytes()).hexdigest()==source_hash
 scope_ok=bool(scopes) and all(('unrestricted' in str(s).lower() and 'notrun' not in str(s).lower() and 'fixed' not in str(s).lower()) if mode=='unrestricted' else 'fixed' in str(s).lower() for s in scopes)
 passed=(expected in emitted and final in emitted and len(counter_checks)==1 and all(c['pass'] for c in counter_checks) and scope_ok and alarms==[600,60,0] and parent_limits==[665] and assigned_words==[word] and source_unchanged)
 return {'pass':passed,'scope':'AST and inert record fixtures ONLY; no scientific execution','runner_path':str(runner),'runner_sha256':hashlib.sha256(runner.read_bytes()).hexdigest(),'driver_path':str(driver),'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'mode':mode,'word':word,'emitted_kinds':sorted(emitted),'expected_branch_kind':expected,'counter_checks':counter_checks,'scope_labels':scopes,'mode_scope_consistent':scope_ok,'signal_alarms':alarms,'parent_wait_limits':parent_limits,'assigned_word':assigned_words,'immutable_a30_source_unchanged':source_unchanged}

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runner',required=True);p.add_argument('--driver',required=True);p.add_argument('--mode',choices=('fixed','unrestricted'),required=True);p.add_argument('--word',type=int,required=True);p.add_argument('--output',required=True);args=p.parse_args()
 result=audit(args.runner,args.driver,args.mode,args.word);Path(args.output).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if result['pass'] else 1)
