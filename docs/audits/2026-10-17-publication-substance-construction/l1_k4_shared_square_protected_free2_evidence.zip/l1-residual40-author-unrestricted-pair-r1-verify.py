from pathlib import Path
from fractions import Fraction
import ast,json,hashlib
P='/tmp/l1-residual40-author-';sha='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98'
assert hashlib.sha256(Path(P+'source-r1.py').read_bytes()).hexdigest()==sha
protected=[Fraction(*r['weight']) for r in map(json.loads,Path('/tmp/l1-next50-author-prepare.out').read_text().splitlines()) if r['word']==191];weights=[a*b for a in protected for b in (Fraction(1,256),Fraction(1,1679616),Fraction(1,1679616))]
records={};preps={};terms={};values={};binding=None
for word,tag in ((110,'pilot110'),(153,'full153')):
 prefix=P+tag+'-r1';out=Path(prefix+'.out');err=Path(prefix+'.err');exitfile=Path(prefix+'.exit.json');exit=json.loads(exitfile.read_text())
 assert exit['actual_child_exit_code']==exit['driver_exit_code']==0 and not exit['parent_timeout'] and not err.read_bytes()
 lines=[json.loads(l) for l in out.read_text().splitlines()];first,prep=lines[:2];branches=[r for r in lines if r['kind']=='exact-branch'];last=lines[-1]
 assert len(branches)==45 and [r['branch'] for r in branches]==list(range(45)) and prep['restrictions']==[]
 assert last['kind']=='exact-word' and last['word']['index']==word and last['branches']==45
 assert first['source_sha256']==last['source_sha256']==sha
 if binding is None:binding=first['principal_source_sha256']
 assert first['principal_source_sha256']==binding and len(binding)==16
 assert prep['sources']==prep['fixed_sources']==[[0,2],[1,2]] and len(prep['action_edges'])==20
 assert prep['fixed_action_edges']==([[[4,5,0],[[5,0]]]] if word==110 else [[[4,5,0],[[4,0]]]]) and prep['live_action_labels']==([[1,0]] if word==110 else [[0,0]])
 assert prep['omitted_action_center_retained_Grassmann_site']==(4 if word==110 else 5) and prep['all_Grassmann_sites']==list(range(16))
 D=192**42*4**64*48**6*2**15;assert prep['divisor']==last['divisor']==D and prep['row_cap']==120000 and prep['pair_cap']==3000000
 assert last['preparation_seconds']<600 and last['whole45_warm_seconds']<60
 for r in branches:
  b=r['branch'];support=prep['support_domains'][b]
  assert Fraction(*r['weight'])==weights[b] and Fraction(r['raw_numerator'],D)==Fraction(*r['coefficient']) and r['divisor']==D
  assert support['protected_branch_index']==b//3 and support['free_branch_index']==b%3 and not support['algebraic_empty_preparation'] and not r['algebraic_empty_preparation']
  routes={c['center']:c for c in support['center_support']};assert len(routes)==15 and prep['omitted_action_center_retained_Grassmann_site'] not in routes
  assert routes[prep['square'][0]]['selector']=='square_component' and all(routes[q]['selector']=='protected_torus_core' for q in prep['torus_centers']) and all(routes[q]['selector']=='free_torus_core' for q in prep['free_centers'])
  assert any(row['labels'][:2]!=[[0,0],[1,1]] for c in routes.values() for row in c['rows'])
  audit=support['prepared_graph'];assert audit['factors']==38 and audit['labels']==32 and audit['all_labels_twice'] and audit['site_degrees']=={str(q):8 for q in range(16)}
  assert len(audit['source_factors'])==2 and all(f['polynomial'] for f in audit['source_factors'])
  for f,(q,a) in zip(audit['source_factors'],((0,2),(1,2)),strict=True):
   y=q^(1<<a);assert f['source']==[q,a] and f['degrees']=={str(q):2,str(y):2}
   assert all(((p['mask']>>(8*q))&255).bit_count()==2 and ((p['mask']>>(8*y))&255).bit_count()==2 for p in f['polynomial'])
 value=sum((Fraction(*r['weight'])*Fraction(*r['coefficient']) for r in branches),Fraction());assert value==Fraction(*last['coefficient'])==Fraction(last['raw_numerator'],D)
 assert last['peak_rows']==max(r['peak_rows'] for r in branches)<=120000
 if word==153:assert exit['complete_raw_branch_records']==45
 values[word]=value;preps[word]=prep;terms[word]=branches
 records[word]={'coefficient':last['coefficient'],'actual_peak_rows':last['peak_rows'],'cold_seconds':last['preparation_seconds'],'WHOLE45_warm_seconds':last['whole45_warm_seconds'],'actual_parent_wall_seconds':exit['full_wall_seconds'],'all45_nonempty_preparations':True,'computed_raw_zero_branches':sum(r['raw_numerator']==0 for r in branches),'original_driver_counter':exit['complete_raw_branch_records'],'actual_raw_record_count':len(branches),'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'exit_sha256':hashlib.sha256(exitfile.read_bytes()).hexdigest(),'runner_sha256':exit['runner_sha256']}
assert values[110]==values[153]
a,b=preps[110],preps[153]
assert a['word']['omitted']^1==b['word']['omitted'] and sorted((q^1,axes) for q,axes in a['word']['changes'])==[tuple(x) for x in b['word']['changes']]
assert sorted((q^1,axis) for q,axis in a['fixed_forest'])==[tuple(x) for x in b['fixed_forest']]
assert [q^1 for q in a['torus_centers']]==b['torus_centers'] and [q^1 for q in a['free_centers']]==b['free_centers']
transformed=[]
for (lo,hi,axis),labels in a['action_edges']:
 u,v=lo^1,hi^1;transformed.append(((min(u,v),max(u,v),axis),sorted((q^1,x) for q,x in labels)))
assert sorted(transformed)==sorted((tuple(e),sorted(tuple(l) for l in labels)) for e,labels in b['action_edges'])
def transform_source_poly(f):
 out=[]
 for term in f['polynomial']:
  mapped=[((i//8)^1)*8+i%8 for i in range(128) if term['mask']>>i&1]
  sign=(-1)**sum(x>y for k,x in enumerate(mapped) for y in mapped[k+1:]);out.append((sum(1<<i for i in mapped),sign*term['real'],sign*term['imag']))
 return sorted(out)
for x,y in zip(terms[110],terms[153],strict=True):assert (x['weight'],x['raw_numerator'],x['divisor'])==(y['weight'],y['raw_numerator'],y['divisor'])
for x,y in zip(a['support_domains'],b['support_domains'],strict=True):
 assert sorted((q^1,labels) for q,labels in x['core_domains'])==[tuple(v) for v in y['core_domains']]
 routes={c['center']:c for c in y['center_support']};assert all(c['selector']==routes[c['center']^1]['selector'] and c['rows']==routes[c['center']^1]['rows'] for c in x['center_support'])
 target={tuple(f['source']):f for f in y['prepared_graph']['source_factors']}
 for f in x['prepared_graph']['source_factors']:
  q,axis=f['source'];g=target[q^1,axis];assert transform_source_poly(f)==sorted((p['mask'],p['real'],p['imag']) for p in g['polynomial'])
root=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in binding.items())
subtotal=sum(values.values(),Fraction())
result={'scope':'Author complete110/153 mathematical reduction; no portable234/fullphysics acceptance','source_sha256':sha,'records':records,'all90_raw_productweight_divisor_final_equalities':True,'actual_XOR1_source_action_forest_core_domain_center_weight_sourcepoly_and_branchraw_covariance':True,'branch_role_map':'3i+j -> same3i+j; no transpose','peak_policy':'Preserve actual5632/3024 separately; resource peaks are not required to be mathematical invariants','all90_preparations_nonempty_and_unrestricted':True,'principal_bindings_rechecked':16,'unsigned_same_subtotal':[subtotal.numerator,subtotal.denominator],'preserved110_counter_defect':'Originaldriver counter0 matched fixedkind; actual45exact-branch rows verified and preserved. New153counter45 correct.'}
Path(P+'unrestricted-pair-r1-verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True))
