from pathlib import Path
import subprocess,time,json,hashlib
script=Path('docs/audits/2026-10-17-publication-substance-construction/l1_extended_offset_witness_k4_shared_square_protected_free_tori.py')
exe='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
for tag,args,limit in [('census',[],30),('fixed',['--controls-only'],60),('110',['--word','110'],60)]:
 prefix='/tmp/l1-110153-portable-cli-'+tag;out=Path(prefix+'.out');err=Path(prefix+'.err');end=Path(prefix+'.exit.json')
 assert all(not p.exists() for p in (out,err,end))
 command=[exe,'-B',str(script),*args];start=time.perf_counter()
 with out.open('xb') as stdout,err.open('xb') as stderr:
  try:r=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=limit);code=r.returncode;reason='terminal'
  except subprocess.TimeoutExpired:code=124;reason='whole process timeout'
 record={'exit_code':code,'reason':reason,'command':command,'actual_parent_wall_seconds':time.perf_counter()-start,'whole_process_limit_seconds':limit,'source_sha256':hashlib.sha256(script.read_bytes()).hexdigest()};end.write_text(json.dumps(record,indent=2)+'\n');print(tag,json.dumps(record),flush=True)
 assert code==0
 records=[json.loads(s) for s in out.read_text().splitlines()]
 if tag=='110':
  assert len(records)==1 and records[0]['coefficient']==[461966234549968960425,140737488355328]
  assert records[0]['branches']==45 and records[0]['whole45_warm_seconds']<60
