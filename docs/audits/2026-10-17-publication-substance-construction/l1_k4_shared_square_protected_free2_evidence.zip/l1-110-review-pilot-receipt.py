from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
import ast,json,hashlib
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=P/'l1-residual40-author-source-r1.py';runner=P/'l1-residual40-author-pilot110-runner-r1.py';driver=P/'l1-residual40-author-pilot110-driver-r1.py';stem=P/'l1-residual40-author-pilot110-r1';out=Path(str(stem)+'.out');err=Path(str(stem)+'.err');expath=Path(str(stem)+'.exit.json');annotation=Path(str(stem)+'-validation.json')
assert sha(source)=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98' and sha(runner)=='061a071e087df20410d27be2cacded98a2ccf96ad9cdc502c5b062ab13a1209c' and sha(driver)=='babae27b6d77033e27f775b8ce3c9cd3b69cd5a657eaf529c8909408afdaf8f1'
rs=[json.loads(l) for l in out.read_text().splitlines()];first,prep,warm=rs[:3];bs=rs[3:-1];last=rs[-1];ex=json.loads(expath.read_text());note=json.loads(annotation.read_text());assert not err.read_bytes()
assert ex['exit_code']==ex['actual_child_exit_code']==ex['driver_exit_code']==0 and not ex['parent_timeout'] and ex['truncated_or_nonJSON_lines']==0 and ex['full_wall_seconds']<665
assert ex['runner_sha256']==sha(runner) and ex['source_sha256']==sha(source) and ex['cold_limit_seconds']==600 and ex['whole45_unrestricted_warm_limit_seconds']==60 and ex['parent_wall_limit_seconds']==665
assert first['phase']==prep['phase']=='cold-unrestricted-preparation' and first['hard_limit_seconds']==600 and warm['phase']=='warm-WHOLE45-unrestricted-contraction' and warm['hard_limit_seconds']==60
assert prep['restrictions']==[] and prep['seconds']==last['preparation_seconds']<600 and last['whole45_warm_seconds']<60 and len(bs)==len(prep['support_domains'])==prep['branches']==last['branches']==45
assert last['scope']=='Complete unrestricted110 selected word; no otherword coefficient' and last['word']['index']==110
# Exact branch products reconstructed by the earlier independent pure-Fraction function.
f=next(n for n in ast.parse((P/'l1-110153-review-fixed-receipts.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='product_branches');ns={'F':F,'combinations_with_replacement':combinations_with_replacement};exec(compile(ast.Module(body=[f],type_ignores=[]),'independent45weights','exec'),ns);expected=ns['product_branches']((1,5),(9,13),(3,7,11,15))
D=192**42*4**64*48**6*2**15;assert prep['divisor']==last['divisor']==D;rawsum=F();total=F();zeros=0;widths=[]
fixed_records=[json.loads(l) for l in (P/'l1-residual40-author-fixed110-r1.out').read_text().splitlines()];fixedsource=next(s['prepared_graph']['source_factors'] for s in fixed_records[1]['support_domains'] if s['prepared_graph'] is not None)
for i,(b,s,(weight,domain)) in enumerate(zip(bs,prep['support_domains'],expected)):
 assert b['kind']=='exact-branch' and b['word']==110 and b['branch']==s['branch']==i and s['protected_branch_index']==i//3 and s['free_branch_index']==i%3
 assert b['divisor']==D and F(*b['weight'])==F(*s['weight'])==weight and F(b['raw_numerator'],D)==F(*b['coefficient'])
 assert {q:tuple(tuple(p) for p in ps) for q,ps in s['core_domains']}==domain and len(domain)==8 and 0 not in domain
 assert not s['algebraic_empty_preparation'] and not b['algebraic_empty_preparation'];zeros+=b['raw_numerator']==0
 audit=s['prepared_graph'];assert audit['factors']==38 and audit['labels']==32 and audit['all_labels_twice'] and {int(q):d for q,d in audit['site_degrees'].items()}==dict.fromkeys(range(16),8) and audit['source_factors']==fixedsource
 assert len(audit['factor_row_slots'])==38 and all(n>0 for n in audit['factor_row_slots'])
 assert len(s['center_support'])==15;counts={}
 for c in s['center_support']:
  q=c['center'];assert q!=4 and c['rows'] and all(v['weight'] for v in c['rows']);counts[q]=len(c['rows'])
  role='square_component' if q==0 else 'protected_torus_core' if q in (1,5,9,13) else 'free_torus_core' if q in (3,7,11,15) else 'peeled';assert c['selector']==role
  assert any(tuple(tuple(p) for p in v['labels'][:2])!=((0,0),(1,1)) for v in c['rows'])
  assert all(len(v['labels'])==(3 if q==0 else 2) for v in c['rows'])
 widths.append(counts);rawsum+=weight*b['raw_numerator'];total+=weight*F(*b['coefficient'])
assert zeros==18 and rawsum.denominator==1 and rawsum.numerator==last['raw_numerator'] and total==F(*last['coefficient'])==F(461966234549968960425,140737488355328)
assert max(b['peak_rows'] for b in bs)==last['peak_rows']==5632
assert prep['sources']==prep['fixed_sources']==[[0,2],[1,2]] and prep['all_Grassmann_sites']==list(range(16)) and prep['omitted_action_center_retained_Grassmann_site']==4
assert prep['torus_centers']==[1,5,9,13] and prep['free_centers']==[3,7,11,15] and prep['fixed_action_edges']==[[[4,5,0],[[5,0]]]] and prep['live_action_labels']==[[1,0]]
assert prep['row_cap']==120000 and prep['pair_cap']==3000000
binding=json.loads((P/'l1-residual40-author-binding.json').read_text())['principal_source_sha256'];assert len(binding)==16 and first['principal_source_sha256']==binding and all(sha(A/n)==h for n,h in binding.items()) and first['source_sha256']==last['source_sha256']==sha(source)
tree=ast.parse(runner.read_text());calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Subscript) and isinstance(n.func.value,ast.Name) and n.func.value.id=='s' and isinstance(n.func.slice,ast.Constant) and n.func.slice.value=='prepare'];assert len(calls)==1 and len(calls[0].args)==2 and not calls[0].keywords and [ast.unparse(x) for x in calls[0].args]==['g','core']
prepare=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='prepare');assert prepare.args.defaults[-1].value is None and ast.unparse(prepare.body[0])=='restrict = {} if restrict is None else restrict'
assert 'for branch, (weight, p) in enumerate(prepared)' in ast.unparse(tree)
# Original exit counter is a metadata bug, proven by its AST and actual stream; preserve it unchanged.
assert ex['complete_raw_branch_records']==0 and len([r for r in rs if r.get('kind')=='exact-branch'])==45 and len([r for r in rs if r.get('kind')=='exact-fixed-branch'])==0
assert "r.get('kind') == 'exact-fixed-branch'" in ast.unparse(ast.parse(driver.read_text()))
assert note['stdout_sha256']==sha(out) and note['exit_sha256']==sha(expath) and note['runner_sha256']==sha(runner) and note['driver_sha256']==sha(driver)
assert note['preserved_driver_counter_defect']['reported_complete_raw_branch_records']==0 and note['preserved_driver_counter_defect']['actual_exact_branch_records']==45
result={'verdict':'ACCEPT complete unrestricted110 pilot receipt; copied fixed-kind branch counter is preserved annotated metadata defect','review_scope':'stdlib AST/hash/JSON/Fraction only; no additional science run','actual_child_driver_exit0':True,'all45_raw_product_weight_domain_divisor_branch_and_weighted_final_equalities':True,'all45_preparations_nonempty_fullgamma':True,'all15_action_centers_have_beyond_fixed_gamma_rows_everybranch':True,'all8_core_domains_and_square_free_protected_peeled_routing':True,'all38_factors32_labels16site_degree8_records':True,'bothsourcepolynomials_equal_independently_accepted_direct_fixed_sources':True,'omitted_site4_retained':True,'computed_rawzero_nonempty_branches':18,'structural_empty_preparations':0,'coefficient':last['coefficient'],'raw_numerator':last['raw_numerator'],'divisor':D,'peak':5632,'cold_seconds':last['preparation_seconds'],'whole45_warm_seconds':last['whole45_warm_seconds'],'parent_seconds':ex['full_wall_seconds'],'actual_prepare_positional_args':2,'actual_prepare_keywords':0,'actual_restrictions':[],'warm_reuses_prepared_objects':True,'preserved_driver_counter':{'reported':0,'actual45_exact_branch_records':45,'cause':'copied filter compares exact-fixed-branch instead of exact-branch','annotation_hashes_match_original':True},'principal16_bindings_unchanged':True,'source_sha256':sha(source),'runner_sha256':sha(runner),'driver_sha256':sha(driver),'stdout_sha256':sha(out),'exit_sha256':sha(expath),'annotation_sha256':sha(annotation),'recorded_center_widths':widths,'word153_unrestricted':'NOT RUN','independent_unrestricted110_replay':'NOT RUN or authorized by this review','portable_scope':232,'full_k4_sourceaction_commonZ_physicalB3_modes_transport':'OPEN'}
(P/'l1-110-review-pilot-receipt-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='recorded_center_widths'},indent=2))
