from pathlib import Path
from collections import Counter
from functools import cache
from fractions import Fraction as F
from itertools import product,combinations_with_replacement
import ast,runpy,json,hashlib,time,signal
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');start=time.perf_counter();signal.alarm(600)
WORD=110;BRANCH_KIND='exact-branch';SCOPE='Complete unrestricted110 independent replay ONLY'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(kind,**v):print(json.dumps(dict(kind=kind,word=WORD,**v),sort_keys=True),flush=True)
source=P/'l1-residual40-author-source-r1.py';assert sha(source)=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98'
binding=json.loads((P/'l1-residual40-author-binding.json').read_text())['principal_source_sha256'];assert len(binding)==16 and all(sha(A/n)==h for n,h in binding.items())
emit('phase-start',phase='cold-unrestricted-preparation',scope=SCOPE,source_sha256=sha(source),principal_source_sha256=binding,hard_limit_seconds=600)
s=runpy.run_path(str(source),run_name='independent_complete110_replay');k2,k3=s['k2'],s['k3'];row,g=s['data']()[WORD]
from l1_normalization_opposed_fourth import L
@cache
def original_weights(domain):
 out=Counter()
 for a,b,c,d in product(range(4),repeat=4):
  for i,u in L[a,c]:
   for j,v in L[b,d]:out[tuple(sorted((a,b))),tuple(sorted((c,d)))]+=u*v*(12*int(i==j) if domain is None else int(tuple(sorted((i,j))) in domain))
 return {k:v for k,v in out.items() if v}
# Independent exact45 product, copied as pure AST rather than any scientific module.
f=next(n for n in ast.parse((P/'l1-110153-review-fixed-receipts.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='product_branches');ns={'F':F,'combinations_with_replacement':combinations_with_replacement};exec(compile(ast.Module(body=[f],type_ignores=[]),'independent_exact45_products','exec'),ns)
branches=ns['product_branches']((1,5),(9,13),(3,7,11,15));assert len(branches)==45 and branches==list(s['branches'](g))
ind=next(x for x in json.loads((P/'l1-residual40-review-verification.json').read_text())['geometry'] if x['word']==WORD)
assert list(g.squares[0])==ind['square'] and list(g.lives[0])==ind['live'] and [list(e) for e in sorted(g.fixed_square[g.squares[0]])]==ind['fixed_forest']
assert g.sources==((0,2),(1,2)) and g.fixed_sources==set(g.sources) and g.edges[4,5,0]==[(5,0)] and g.edges[0,1,0]==[(1,0)] and row['omitted']==4
D=192**42*4**64*48**6*2**15;assert g.divisor==D
frame={q:(0,1) for q in range(16) if q!=row['omitted']};frame.update({q:tuple(a) for q,a in row['changes']});assert frame==g.frame
pilot=[json.loads(l) for l in (P/'l1-residual40-author-pilot110-r1.out').read_text().splitlines()];pilotbranches=[x for x in pilot if x['kind']==BRANCH_KIND];assert len(pilotbranches)==45
prepared=[]
for b,(weight,core) in enumerate(branches):
 p=s['prepare'](g,core);assert p is not None;factors,divisor,exclusive=p
 assert len(factors)==38 and divisor==D;counts=Counter(k for keys,rows,degrees in factors for k in keys)
 assert len(counts)==32 and set(counts.values())=={2} and all(sum(ds.get(q,0) for ks,rs,ds in factors)==8 for q in range(16))
 centers=[]
 for ci,(q,axes) in enumerate(sorted(g.frame.items())):
  keys,rows,degrees=factors[ci];assert keys[:2]==tuple((q,a) for a in axes);expected={}
  for comp in (sorted({r[2] for r in rows}) if q==g.squares[0][0] else (None,)):
   domain=(comp,) if q==g.squares[0][0] else core.get(q);weights=original_weights(None if domain is None else tuple(domain));assert weights==k3.witness.center_weights(domain)
   for gamma,w in weights.items():
    if any(gamma[j][0]!=gamma[j][1] for j,key in enumerate(keys[:2]) if key in exclusive):continue
    expected[gamma+((comp,) if q==g.squares[0][0] else ())]={0:(w,0)}
  assert rows==expected and any(r[:2]!=k3.witness.FIXED_GAMMAS for r in rows)
  centers.append({'center':q,'rows':len(rows),'selector':'square_component' if q==0 else 'protected_torus_core' if q in (1,5,9,13) else 'free_torus_core' if q in (3,7,11,15) else 'peeled'})
 source_polys=[]
 for source_label,(keys,rows,degrees) in zip(g.sources,factors[-2:],strict=True):
  assert not keys;source_polys.append({'source':source_label,'degrees':degrees,'polynomial':[{'mask':m,'real':v[0],'imag':v[1]} for m,v in sorted(rows[()].items())]})
 assert source_polys==pilot[1]['support_domains'][b]['prepared_graph']['source_factors']
 packed=[[keys,[[key,sorted(poly.items())] for key,poly in sorted(rows.items())],sorted(degrees.items())] for keys,rows,degrees in factors]
 emit('prepared-branch',branch=b,protected_branch_index=b//3,free_branch_index=b%3,weight=[weight.numerator,weight.denominator],core_domains=sorted(core.items()),restrictions=[],factor_count=38,label_count=32,all16site_degrees8=True,original_L_all_center_rows_equal=True,all15centers_beyond_fixed=True,center_support=centers,bothsource_polynomials_equal_pilot=True,omitted_site4_retained=True,factor_tables_sha256=hashlib.sha256(json.dumps(packed,separators=(',',':')).encode()).hexdigest())
 prepared.append((weight,p))
prep=time.perf_counter()-start;emit('phase-complete',phase='cold-unrestricted-preparation',seconds=prep,branches=45,restrictions=[],divisor=D,row_cap=k2.ROW_CAP,pair_cap=k2.PAIR_CAP)
signal.alarm(60);warm=time.perf_counter();emit('phase-start',phase='warm-WHOLE45-unrestricted-contraction',hard_limit_seconds=60)
total=F();peak=0;zeros=0
for b,(weight,(factors,divisor,exclusive)) in enumerate(prepared):
 raw,size=k3.eliminate_components(factors,exclusive);value=F(raw,divisor);total+=weight*value;peak=max(peak,size);zeros+=raw==0
 emit(BRANCH_KIND,branch=b,weight=[weight.numerator,weight.denominator],raw_numerator=raw,divisor=divisor,coefficient=[value.numerator,value.denominator],peak_rows=size,algebraic_empty_preparation=False)
 assert raw==pilotbranches[b]['raw_numerator'] and value==F(*pilotbranches[b]['coefficient']) and weight==F(*pilotbranches[b]['weight']) and divisor==pilotbranches[b]['divisor']
signal.alarm(0);raw=total*D;assert raw.denominator==1 and total==F(461966234549968960425,140737488355328) and zeros==18
assert sha(source)=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98' and all(sha(A/n)==h for n,h in binding.items())
emit('independent-complete-unrestricted',scope=SCOPE,coefficient=[total.numerator,total.denominator],raw_numerator=raw.numerator,divisor=D,branches=45,peak_rows=peak,computed_raw_zero_branches=zeros,nonempty_preparations=45,cold_seconds=prep,whole45_warm_seconds=time.perf_counter()-warm,full_seconds=time.perf_counter()-start,source_sha256=sha(source),principal16_bindings_unchanged=True)
