from pathlib import Path
from collections import Counter
from itertools import combinations_with_replacement
from fractions import Fraction as F
import ast,json,hashlib
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=P/'l1-residual40-author-source-r1.py';runner=P/'l1-residual40-author-fixed-runner-r1.py';assert sha(source)=='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98' and sha(runner)=='a9d52ce03c03ea2494a2ffad96d92faf5dea0fab2e2c97d70d6baf51aa8b7406'
binding=json.loads((P/'l1-residual40-author-binding.json').read_text())['principal_source_sha256'];assert len(binding)==16 and all(sha(A/n)==h for n,h in binding.items())
D=192**42*4**64*48**6*2**15;recs={};summaries={};files=[source,runner]
def product_branches(linked,other,freebases):
 p=[(F(1,256),dict.fromkeys(linked+other,tuple((i,i) for i in range(6))))]
 for c in (0,3):
  inds=range(c,c+3);ds=tuple((i,i) for i in inds);p.append((F(-1,559872),dict.fromkeys(linked+other,ds)))
  for pair in combinations_with_replacement(inds,2):p.append((F(2 if pair[0]==pair[1] else 1,279936),{linked[0]:(pair,),linked[1]:(pair,),other[0]:ds,other[1]:ds}))
 f=[(F(1,256),dict.fromkeys(freebases,tuple((i,i) for i in range(6))))]
 for c in (0,3):f.append((F(1,1679616),dict.fromkeys(freebases,tuple((i,i) for i in range(c,c+3)))))
 assert len(p)==15 and len(f)==3
 return [(w*v,c|d) for w,c in p for v,d in f]
for word in (110,153):
 stem=P/f'l1-residual40-author-fixed{word}-r1';out=Path(str(stem)+'.out');err=Path(str(stem)+'.err');expath=Path(str(stem)+'.exit.json');driver=P/f'l1-residual40-author-fixed{word}-driver-r1.py';rs=[json.loads(l) for l in out.read_text().splitlines()];first,prep,warm=rs[:3];branches=rs[3:-1];last=rs[-1];ex=json.loads(expath.read_text());files.extend([out,err,expath,driver])
 assert ex['exit_code']==ex['actual_child_exit_code']==ex['driver_exit_code']==0 and not ex['parent_timeout'] and ex['truncated_or_nonJSON_lines']==0 and ex['complete_raw_branch_records']==45 and not err.read_bytes()
 assert ex['full_wall_seconds']<665 and ex['runner_sha256']==sha(runner) and ex['source_sha256']==sha(source) and ex['cold_limit_seconds']==600 and ex['whole45_fixed_warm_limit_seconds']==60 and ex['parent_wall_limit_seconds']==665
 assert first['phase']==prep['phase']=='cold-fixed-preparation' and first['hard_limit_seconds']==600 and warm['phase']=='warm-WHOLE45-fixed-contraction' and warm['hard_limit_seconds']==60
 assert last['preparation_seconds']==prep['seconds']<600 and last['whole45_warm_seconds']<60 and prep['branches']==last['branches']==45 and len(branches)==len(prep['support_domains'])==45
 assert first['source_sha256']==last['source_sha256']==sha(source) and first['principal_source_sha256']==binding and last['scope']=='FIXED-gamma ONLY; unrestricted coefficient NOTRUN'
 assert prep['row_cap']==120000 and prep['pair_cap']==3000000 and prep['all_Grassmann_sites']==list(range(16)) and prep['omitted_action_center_retained_Grassmann_site']==(4 if word==110 else 5)
 restrictions={q:tuple(tuple(p) for p in gamma) for q,gamma in prep['restrictions']};assert len(restrictions)==15 and set(restrictions)==set(range(16))-{prep['word']['omitted']} and set(restrictions.values())=={((0,0),(1,1))}
 linked=(1,5) if word==110 else (0,4);other=(9,13) if word==110 else (8,12);free=(3,7,11,15) if word==110 else (2,6,10,14);expected=product_branches(linked,other,free);assert len(expected)==45 and sum(w<0 for w,c in expected)==6
 total=F();rawsum=F();empty=0;computedzeros=0
 for i,(b,s,(weight,domain)) in enumerate(zip(branches,prep['support_domains'],expected)):
  assert b['kind']=='exact-fixed-branch' and b['word']==word and b['branch']==s['branch']==i and s['protected_branch_index']==i//3 and s['free_branch_index']==i%3
  assert F(*b['weight'])==F(*s['weight'])==weight and b['divisor']==D and F(b['raw_numerator'],D)==F(*b['coefficient'])
  assert {q:tuple(tuple(p) for p in ps) for q,ps in s['core_domains']}==domain
  assert b['structural_empty_preparation']==s['structural_empty_preparation']==bool(s['empty_center_sites'])
  total+=weight*F(*b['coefficient']);rawsum+=weight*b['raw_numerator']
  empty+=s['structural_empty_preparation'];computedzeros+=not s['structural_empty_preparation'] and b['raw_numerator']==0
  assert len(s['center_support'])==15
  for c in s['center_support']:
   q=c['center'];selector='square_component' if q==(0 if word==110 else 1) else 'protected_torus_core' if q in linked+other else 'free_torus_core' if q in free else 'peeled';assert c['selector']==selector
   assert all(tuple(tuple(p) for p in v['labels'][:2])==restrictions[q] and v['weight'] for v in c['rows'])
  audit=s['prepared_graph']
  if s['structural_empty_preparation']:
   assert audit is None and b['raw_numerator']==0 and b['peak_rows']==0
  else:
   assert audit['factors']==38 and audit['labels']==32 and audit['all_labels_twice'] and {int(q):d for q,d in audit['site_degrees'].items()}==dict.fromkeys(range(16),8)
   assert len(audit['source_factors'])==2
   for f in audit['source_factors']:
    q,a=f['source'];assert (q,a) in ((0,2),(1,2)) and {int(p):d for p,d in f['degrees'].items()}=={q:2,q^(1<<a):2}
 assert empty==30 and rawsum.denominator==1 and rawsum.numerator==last['raw_numerator'] and total==F(*last['coefficient'])==F(1901385366902249675,8923232590303029767153123328)
 assert prep['divisor']==last['divisor']==D and max(b['peak_rows'] for b in branches)==last['peak_rows']==(1368 if word==110 else 540)
 assert prep['sources']==prep['fixed_sources']==[[0,2],[1,2]] and prep['fixed_action_edges']==[[[4,5,0],[[5,0] if word==110 else [4,0]]]] and prep['live_action_labels']==[[1,0] if word==110 else [0,0]]
 recs[word]=(rs,branches,prep);summaries[word]={'actual_exit':0,'branches':45,'nonempty':15,'structural_empty':30,'computed_zero_nonempty_branches':computedzeros,'negative_weights':6,'coefficient_FIXED_ONLY':last['coefficient'],'peak_rows_ordering_sensitive':last['peak_rows'],'cold_seconds':last['preparation_seconds'],'whole45_warm_seconds':last['whole45_warm_seconds'],'parent_seconds':ex['full_wall_seconds'],'stdout_sha256':sha(out),'exit_sha256':sha(expath),'driver_sha256':sha(driver)}
a,ab,ap=recs[110];b,bb,bp=recs[153]
for x,y in zip(ab,bb):assert all(x[k]==y[k] for k in ('branch','weight','raw_numerator','divisor','coefficient','structural_empty_preparation'))
assert ap['word']['omitted']^1==bp['word']['omitted'] and sorted((q^1,axes) for q,axes in ap['word']['changes'])==sorted((q,axes) for q,axes in bp['word']['changes'])
assert sorted((q^1,axis) for q,axis in ap['fixed_forest'])==sorted(tuple(x) for x in bp['fixed_forest'])
assert [ap['shared_source'][0]^1,ap['shared_source'][1]]==bp['shared_source']
def shifted_action(edges):
 out=[]
 for (lo,hi,axis),labels in edges:
  l,h=sorted((lo^1,hi^1));out.append(((l,h,axis),tuple(sorted((q^1,a) for q,a in labels))))
 return sorted(out)
assert shifted_action(ap['action_edges'])==sorted((tuple(e),tuple(sorted(tuple(k) for k in ks))) for e,ks in bp['action_edges'])
for x,y in zip(ap['support_domains'],bp['support_domains']):
 assert {q^1:ps for q,ps in x['core_domains']}==dict(y['core_domains'])
 assert {c['center']^1:{k:v for k,v in c.items() if k!='center'} for c in x['center_support']}=={c['center']:{k:v for k,v in c.items() if k!='center'} for c in y['center_support']}
 assert sorted(q^1 for q in x['empty_center_sites'])==y['empty_center_sites']
 if x['prepared_graph'] is not None:
  xf=x['prepared_graph']['source_factors'];yf=y['prepared_graph']['source_factors']
  def maskshift(mask):
   sign=(-1)**sum(((mask>>(8*q))&255).bit_count()*((mask>>(8*(q^1)))&255).bit_count() for q in range(0,16,2))
   mapped=sum(((mask>>(8*q))&255)<<(8*(q^1)) for q in range(16));return mapped,sign
  ym={tuple(f['source']):f for f in yf}
  for f in xf:
   g=ym[f['source'][0]^1,f['source'][1]];mapped=[]
   for v in f['polynomial']:
    mask,sign=maskshift(v['mask']);mapped.append((mask,sign*v['real'],sign*v['imag']))
   assert sorted(mapped)==sorted((v['mask'],v['real'],v['imag']) for v in g['polynomial']) and {int(q)^1:d for q,d in f['degrees'].items()}=={int(q):d for q,d in g['degrees'].items()}
# Actual runner scope and phase reuse, inspected without importing it.
t=ast.parse(runner.read_text());calls=[n for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Subscript) and isinstance(n.func.value,ast.Name) and n.func.value.id=='s' and isinstance(n.func.slice,ast.Constant) and n.func.slice.value=='prepare'];assert len(calls)==1 and len(calls[0].args)==3 and ast.unparse(calls[0].args[2])=='restrict'
assert 'for branch, (weight, p) in enumerate(prepared)' in ast.unparse(t) and 'restrict = dict.fromkeys(g.frame, s[\'k3\'].witness.FIXED_GAMMAS)' in ast.unparse(t)
direct=json.loads((P/'l1-110153-review-direct-verification.json').read_text());assert direct['actual_exit']==0 and direct['source_sha256']==sha(source) and direct['fixed_scalar_replays_run']==0
result={'verdict':'ACCEPT complete DIRECT plus author FIXED110/153 controls; only ROOT may authorize next unrestricted pilot','review_scope':'stdlib receipt/AST/hash/Fraction only; no additional scientific run','words':summaries,'all90_raw_weight_divisor_branch_and_weighted_final_equalities':True,'XOR1_flat3i_plus_j_identity':True,'XOR1_all45_raw_weight_divisor_coefficient_covariance':True,'XOR1_source_action_forest_core_centerweight_and_explicit_sourcepolynomial_mask_covariance':True,'peaks_preserved_not_forced_equal':{'110':1368,'153':540},'actual_fixed_restrictions_all15_action_centers':True,'all16_Grassmann_sites_retained':True,'source_sha256':sha(source),'runner_sha256':sha(runner),'principal16_bindings_unchanged':True,'files_sha256':{str(p):sha(p) for p in files},'direct_controls_accepted_separately':True,'independent_fixed_scalar_replay':'NOT RUN','unrestricted_coefficients':'NOT RUN','portable_scope':232,'family7981':'separate mathematical design only','full_k4_sourceaction_commonZ_B3_modes_transport':'OPEN'}
(P/'l1-110153-review-fixed-receipts-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
