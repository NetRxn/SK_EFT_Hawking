# L1 N16 dense outer cases 29–31

Scientific source 51e7c745e and publication checkpoint 9a804cb9c. The three cases are distinct terms in the first binary child of tuple 0 in descendant (0,0). Use the exact slots in the 48-entry roster even where scalar values coincide.

Restore each `row-cap-physical-slice-dense-label-case-N-2-reduced.pkl` as documented by `L1_N16_C0_CASES17_23_CLOSURE_R1.zip` under `next-frontiers`. The parent SHA256 values for 29, 30 and 31, respectively, are `76766e032b117cab136a91787cd13e1cde3fb2303190f7e5bf99a7b34b6a7262`, `0fc95eae5603abb46e31fac55512583b6c0d1c8b6e7cb5895e8d24bdb8a27a85`, and `daf93e85d17fd491ddfa19f66da2ad7a87b07f892d7b92586314fa7f57f9b7c9`. Deserialize only trusted checkpoint inputs.

For each N, copy the contents of its author folder to fresh scratch. Run the following with the actual parent path and index.

```bash
python3 -u run-primary.py /absolute/path/to/restored-parent.pkl >slices.tsv
python3 -u reduce-open.py 0 1 2 3 4 5 6 7 8 >rescue.tsv
for n in 5 6; do
    python3 -u triangle-bounded.py "join-cap-dense-label-rescue-$n-1-reduced.pkl" >"slice-$n-triangle.out" || exit 1
done
shasum -a 256 -c /absolute/path/to/archive/frontiersN.sha256
python3 sum-caseN.py
```

Each exact inner split covers 2,911,488 pair matches and nine coordinates. The seven non-triangle slices close through the direct and repeated support/quotient reductions. The two triangle slices close by exact scalar contraction. The author command inherits the word “independent” in its output from an earlier use of the code; the separate `reviewN` directories contain the actual independent arithmetic. The independent reports bind the exact cuts, terminal states and caps to each distinct case.

Restore any omitted duplicate ZIP in a frozen reviewer manifest from the repository copy with the matching bytes. The archive incorporates the earlier 33-case ledger without relabeling any prior receipt. Use the retally script to report the exact partial contribution and open roster. The full child, original signed coefficient and physical/publication obligations remain open.

Run `python3 verify-cases.py 29 30 31` and `python3 retally-48.py 29 30 31` in the extracted archive. They verify all 27 current scalar replays and reproduce the exact partial subtotal over 36 distinct cases.

All 12 remaining cases have reproducible seven-factor frontiers. Restore the original 48-roster parent from `L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip` and run `python3 run-batch.py /absolute/path/to/original-parent.pkl 33 34 35 37 38 39 40 41 42 43 44 45` from scratch seeded with `author29`. Compare the exact output paths against `next-frontiers/inputs.sha256`. Then partition and finish each requested case before independent review.
