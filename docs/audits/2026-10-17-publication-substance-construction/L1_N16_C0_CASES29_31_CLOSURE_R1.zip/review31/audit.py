from ast import literal_eval
from collections import Counter
from pathlib import Path
import pickle


def load(path):
    return pickle.loads(path.read_bytes())

def audit(source, pair, fixed_axes, plan, children):
    parent = load(source)
    factors = parent['factors']
    degree = Counter(w for axes, _, _ in factors for w in axes)
    assert set(degree.values()) == {2}
    left, right = (factors[i] for i in pair)
    common = set(left[0]).intersection(right[0])
    ordered = tuple(sorted(common))
    buckets = Counter(tuple(dict(zip(right[0], row))[a] for a in ordered) for row in right[1])
    spectrum = Counter()
    for row in left[1]:
        assignment = dict(zip(left[0], row))
        multiplicity = buckets[tuple(assignment[a] for a in ordered)]
        if multiplicity:
            spectrum[tuple(assignment[a] for a in fixed_axes)] += multiplicity
    assert spectrum == plan
    for coordinate, path in children.items():
        fixed = dict(zip(fixed_axes, coordinate))
        child = load(path)
        assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
        assert child['label_partition'] == parent['label_partition']
        for (axes, rows, denominator), (small_axes, small_rows, small_denominator) in zip(factors, child['factors'], strict=True):
            assert denominator == small_denominator
            assert tuple(w for w in axes if w not in fixed) == small_axes
            expected = {row: value for row, value in rows.items()
                        if all(row[p] == fixed[w] for p,w in enumerate(axes) if w in fixed)}
            recovered = {}
            for row,value in small_rows.items():
                assignment = dict(zip(small_axes,row))
                assignment.update(fixed)
                recovered[tuple(assignment[w] for w in axes)] = value
            assert recovered == expected
    print(source.name, 'pair',pair,'cuts',fixed_axes,'cases',len(spectrum),
          'sum/max products',sum(spectrum.values()),max(spectrum.values()),'children audited',list(children),flush=True)


from hashlib import sha256
from math import prod
from zipfile import ZipFile

root=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-c0-case31.jmDLG4')
source=Path('/private/tmp/l1-open-roster-25-31.oY6JAC/row-cap-physical-slice-dense-label-case-31-2-reduced.pkl')
with ZipFile(root/'pinned.zip') as archive, ZipFile(root/'original.zip') as original:
    assert archive.testzip() is None
    receipts = {name: digest for digest, name in
                (line.split() for line in archive.read('next-frontiers/inputs.sha256').decode().splitlines())}
    parent_hash = sha256(source.read_bytes()).hexdigest()
    assert receipts[source.name] == parent_hash
    outer = archive.read('next-frontiers/case-31.roster')
    assert outer == original.read('pilot.roster')
print('canonical outer roster SHA256',sha256(outer).hexdigest(),'parent SHA256',parent_hash)
outer_axes,outer_rows=literal_eval(outer.decode())
assert sorted(outer_rows,key=lambda p:(p[1],p[0]))[31]==((68,(3,)),141792)
parent=load(source)
assert len(parent['factors'])==7
assert tuple(dict(parent['conditioning'])[axis] for axis in outer_axes)==(68,(3,))
roster=(author/'slice-0.roster').read_bytes()
assert all((author/f'slice-{i}.roster').read_bytes()==roster for i in range(9))
axes,raw=literal_eval(roster.decode())
counts=dict(raw)
assert len(counts)==len(raw)==9
order=sorted(counts,key=lambda c:(counts[c],c))
audit(source,parent['rejected_pair'],axes,counts,{order[i]:author/f'slice-{i}.pkl' for i in range(9)})
import sys
if '--cuts-only' in sys.argv[1:]:
    print('PASS canonical parent, full nine-cut support and nine inverse lifts')
    raise SystemExit(0)
table=[line.split('\t') for line in (author/'author-case31.tsv').read_text().splitlines()]
assert len(table)==10 and table[9][0]=='sum'
for i in range(9):
    entry=table[i]
    assert tuple(map(int,entry[:3]))==(i,order[i][0],counts[order[i]])
    child=load(author/f'slice-{i}.pkl')
    receipt=entry[-1].removesuffix('-contract.out')
    path=author/(f'join-cap-dense-label-rescue-{i}-1-reduced.pkl' if i in (5,6) else f'label-{receipt}-reduced-frontier.pkl')
    data=path.read_bytes()
    state=pickle.loads(data)
    assert state['conditioning']==child['conditioning']
    assert state['label_partition']==child['label_partition']
    factors=state['factors']
    assert prod(d for _,_,d in factors)==40512224221827380280140849737629696
    assert all(d>0 and len(a)==len(set(a)) and all(len(k)==len(a) and len(v)==2 and any(v) and all(type(x) is int for x in v)
                                                for k,v in table.items()) for a,table,d in factors)
    assert set(Counter(w for a,_,_ in factors for w in a).values())=={2}
    assert not set(dict(state['conditioning'])).intersection(w for a,_,_ in factors for w in a)
    print('replay input',i,order[i][0],counts[order[i]],path.name,sha256(data).hexdigest(),len(factors),sum(len(r) for _,r,_ in factors))
print('PASS full nine-cut support, nine inverse lifts and terminal metadata')
