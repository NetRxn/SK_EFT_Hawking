#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 audit.py > audit.out
a=/private/tmp/l1-c0-case31.jmDLG4
tab=$(printf '\t')
while IFS="$tab" read -r index coord products real imag receipt; do
    if test "$index" = sum; then break; fi
    case "$index" in
      5|6) python3 -u triangle.py "$index" > "slice-$index-triangle-replay.out" ;;
      *)
        stem=${receipt%-contract.out}
        python3 -u replay.py "$index" 0 "$a/label-$stem-reduced-frontier.pkl" "$a/$receipt" > "slice-$index-replay.out"
        ;;
    esac
done < "$a/author-case31.tsv"
python3 aggregate.py > aggregate.out
