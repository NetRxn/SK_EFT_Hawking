from fractions import Fraction
from pathlib import Path
import re

root=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-c0-case30.NiaDDW')
normalized=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
raw=re.compile(r'^(?:PASS )?raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',re.M)
join=re.compile(r'^independent join \d+ \d+ products (\d+) output rows (\d+) remaining \d+$',re.M)
audit=(root/'audit.out').read_text()
assert audit.endswith('PASS full nine-cut support, nine inverse lifts and terminal metadata\n')
binding={int(i):(int(c),int(n),name,sha) for i,c,n,name,sha in re.findall(
    r'^replay input (\d+) (\d+) (\d+) (\S+) ([0-9a-f]{64}) \d+ \d+$',audit,re.M)}
total_real=total_imaginary=Fraction(0)
ledger=[line.split('\t') for line in (author/'author-case30.tsv').read_text().splitlines()]
assert len(ledger)==10 and len(binding)==9
for entry in ledger[:-1]:
    itr, coord, matches, expected, expected_imag, receipt=entry
    i=int(itr)
    assert binding[i][:2]==(int(coord),int(matches))
    stage='triangle-replay' if i in (5,6) else 'replay'
    log=(root/f'slice-{i}-{stage}.out').read_text()
    (r,im),=normalized.findall(log)
    sr,si=Fraction(r),Fraction(im)
    (nr,ni,d),=raw.findall(log)
    scale=int(d)*16*4**64
    assert (sr,si)==(Fraction(int(nr),scale),Fraction(int(ni),scale))
    assert (r,im)==normalized.findall((author/receipt).read_text())[0]==(expected,expected_imag)
    parts=[(int(p),int(rows)) for p,rows in join.findall(log)]
    if i in (5,6):
        result=re.search(r'^independent pivot (\d+) probes (\d+) triples (\d+) nonzero pivot rows \d+ Gaussian products (\d+) wall seconds ',log,re.M)
        assert result and int(result[1]) in (1,2)
        count=int(result[4])
        peak_join=int(re.search(r'^closed final pivot shard \d+ \d+ peak \d+ (\d+)$',log,re.M)[1])
        peak_rows=1
        assert (nr,ni,d)==raw.findall((author/receipt).read_text())[0]
    else:
        count=sum(p for p,_ in parts)
        peak_join=max(p for p,_ in parts)
        peak_rows=max(rows for _,rows in parts)
    total_real+=sr
    total_imaginary+=si
    print('PASS slice',i,'coordinate',coord,'real',sr,'imaginary',si,'products',count,'maximum join or shard',peak_join,'largest retained output',peak_rows,'source',stage)
assert [ledger[-1][0],str(total_real),str(total_imaginary)]==ledger[-1]
print('PASS full exact independent case 30 sum',total_real,total_imaginary)
