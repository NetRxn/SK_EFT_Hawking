# L1 outer case 29 independent exact review

All nine independently replayed exact results agree with the author ledger. The exact subtotal is **-153959781396137153207967 / 1298074214633706907132624082305024 + 0i**.

The original 48-case roster identifies case 29 as (36,(3,)). The seven-factor parent matches its archived hash in L1_N16_C0_CASES17_23_CLOSURE_R1 at checkpoint cdd9b80ff9a7ee73cb78a46deb0c8e20045a758b. Independent matching on retained parent pair (0,1) identifies nine inner values of G(0,1,2), with 2,911,488 matched products and maximum 465,024 per cut. A nonzero network term requires a match on the selected pair. The inverse lifts verify all nine conditioned children against the parent factors, retaining exact Gaussian coefficients and original denominators.

Independent sparse joins close slices 0, 1, 2, 3, 4, 7 and 8 from their separate ledger-selected reduced states. They use at most 8,543,036 products per replay, 4,831,904 products in any join and 487,872 retained output rows. Earlier author join and row-cap receipts are preserved.

Slices 5 and 6 use alternate pivot 1 compared with the author's pivot 0. The independent route sums the complement inner product before multiplication by the pivot coefficient. It covers 13,317,120 exact support triples and uses 13,394,880 Gaussian multiplications for each slice, compared with author's 26,634,240. The raw and normalized scalar receipts agree.

The sparse evaluator enforces 8M products per join, 30M total, 1M accumulator rows and 30 seconds per replay. The triangle evaluator uses disjoint pivot-row shards with explicit arithmetic and probe bounds. The factor-denominator product is 40512224221827380280140849737629696 and the positive scale 1/(16*4^64) is applied once. Earlier reductions to the terminal frontiers rely on frozen lineage and previously reviewed exact algebra. This review accepts case 29 of the 48-case cut for one binary child of dense tuple 0. The full signed coefficient remains open.
