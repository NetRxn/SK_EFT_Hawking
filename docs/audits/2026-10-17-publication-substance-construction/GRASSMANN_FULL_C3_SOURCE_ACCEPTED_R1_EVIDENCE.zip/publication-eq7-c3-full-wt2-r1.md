# Full original C3 worker result

Task publication-eq7-c3-full-wt2-r1; recovery packet publication-eq7-c3-full-wt2-r2; parent publication-remediation. ROOT is notebook writer and lifecycle/integration owner. Owning roadmap docs/roadmaps/Phase6a_Roadmap.md. Only lean/SKEFTHawking/ADW/FiniteGrassmannSourceAuxiliary.lean edited/committed in assigned public wt2. Peer files preserved.

Commit 056ccb9f08454238934977de4bb6548d18c6275e, worktree-wt2. Source SHA256 397a3cd02e7f901157cd366411811fc37f99737addd401217134e11fea03320a;1355 lines. Clean git status; git diff --check passed. Normal commit leak guard passed. Existing84 public exports and original declaration/proof block preserved exactly;84 new public exports including70 new theorems.

## Construction

Actual localIntegral/local_integrable/local_eq7, separate printed/closed family theorems, inclusion-image and pairwise commutation proofs. site_nilExp_product and ordered_local_integrals cover every complete nodup enumeration; order independence and global integral equality to actual ordered local integrals are proved. Finset products are restricted to actual C or scalars, never full G.

The globalIntegrand is exactly the ORIGINAL product of independent site compensation weights, multiplying one common4V finite exponential of the summed actual local fields. global_integrable is proved independently through finite C expansions and actual scalar finite-Pi product integrability, before global_eq7 is evaluated by the proved scalar finite-Pi integral theorem. No substituted single compensation polynomial, assumed Fubini/interchange/integrability or analytic exponential on G.

Explicit gaussian_uncurry_preserving/gaussian_curry_preserving prove rectangular measure equality; uncurriedIntegrand/uncurried_global_integrable/uncurried_global_eq7 export Site×D Gaussian forms. Both printed/closed source families discharge actual constants, common cutoff and integrability premises.

Controls include both original two-site source product integrals with independent couplings, arbitrary independent real site fields, shared-budget mixed vanishing, positive-cutoff original one-site weighted integral, zero couplings and sigma2/half comparisons. The actual three-site torus coframes T0,T1 have projection(ab−ad)/4 and(cd+ab)/4. Their product projects to abcd/16≠0. A basis theorem proves the four-generator word nonzero; arbitrary independent nonzero real field amplitudes retain the actual mixed product in the SAME global coframe family. Projection is only an algebraic control.

## Actual evidence

Exact full1355-line source plus168 public #print axioms requests succeeded, timed_out=false,168 expected diagnostic messages. Every axiom list is a subset of propext/Classical.choice/Quot.sound; no sorryAx. Every one of70 new theorem closing goals was queried SEQUENTIALLY against the owned file and has goals_after=[]. Final owned-file diagnostics success=true, items=[], failed_dependencies=[]. Headline lean_verify(scan_source=true) for global_eq7, uncurried_global_eq7 and actual_independent_field_mixed_nonzero returned standard3 and no warnings. Source scan has no sorry/axiom/native_decide/maxHeartbeats. Complete exact source, original source, public roster, outline, full-source kernel request/response, all70 goal responses and headline verification are in JSON.

## Recovery and limitations

R1 FIRST check fresh=true; mandatory post-pause check correctly found expected own-source drift. ROOT inspected it and issued R2; FIRST R2 recovery check fresh=true. Actual host status verified ACTIVE public codex wt2, original base450710 and epoch6e14, running backend/proxy. No reset/cache/prepare/build/compiler patch was performed.

Early isolated Source-importing snippets returning success with empty info were superseded and are NOT relied upon. Exact full-source diagnostics exposed real control errors and simplifier PANIC; immutable panic and ROOT healthy probe/status artifacts remain untouched. Correction decomposed typed coordinate/Fin/ZMod guards, explicit ite scalar rewriting and gamma302 by rfl. Full raw failing iterations remain in JSON. Initial C2 API discovery/local_search preceded JSON log initialization; their raw responses remain in the conversation transcript and are not final acceptance evidence. First report write hit Argument list too long; chunked evidence writes succeeded.

This is worker source/kernel completion, pending DIFFERENT independent full actual mathematical/source/kernel review and ROOT absorption/native/canonical/full gates. It is not full-tree or publication acceptance. Original Eq9–11/Berezin/Haar/compact-link Fubini/nonzeroZ and B2/B3/state/physics/publication remain OPEN. Full original C3 acceptance scope was not reduced.
