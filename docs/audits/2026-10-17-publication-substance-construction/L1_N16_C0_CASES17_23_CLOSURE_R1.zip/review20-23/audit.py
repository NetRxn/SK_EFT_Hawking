from ast import literal_eval
from collections import Counter
from pathlib import Path
import pickle


def load(path):
    return pickle.loads(path.read_bytes())

def audit(source, pair, fixed_axes, plan, children):
    parent = load(source)
    factors = parent['factors']
    degree = Counter(w for axes, _, _ in factors for w in axes)
    assert set(degree.values()) == {2}
    left, right = (factors[i] for i in pair)
    common = set(left[0]).intersection(right[0])
    ordered = tuple(sorted(common))
    buckets = Counter(tuple(dict(zip(right[0], row))[a] for a in ordered) for row in right[1])
    spectrum = Counter()
    for row in left[1]:
        assignment = dict(zip(left[0], row))
        multiplicity = buckets[tuple(assignment[a] for a in ordered)]
        if multiplicity:
            spectrum[tuple(assignment[a] for a in fixed_axes)] += multiplicity
    assert spectrum == plan
    for coordinate, path in children.items():
        fixed = dict(zip(fixed_axes, coordinate))
        child = load(path)
        assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
        assert child['label_partition'] == parent['label_partition']
        for (axes, rows, denominator), (small_axes, small_rows, small_denominator) in zip(factors, child['factors'], strict=True):
            assert denominator == small_denominator
            assert tuple(w for w in axes if w not in fixed) == small_axes
            expected = {row: value for row, value in rows.items()
                        if all(row[p] == fixed[w] for p,w in enumerate(axes) if w in fixed)}
            recovered = {}
            for row,value in small_rows.items():
                assignment = dict(zip(small_axes,row))
                assignment.update(fixed)
                recovered[tuple(assignment[w] for w in axes)] = value
            assert recovered == expected
    print(source.name, 'pair',pair,'cuts',fixed_axes,'cases',len(spectrum),
          'sum/max products',sum(spectrum.values()),max(spectrum.values()),'children audited',list(children),flush=True)


from hashlib import sha256
from math import prod
from zipfile import ZipFile

author = Path('/private/tmp/l1-open-roster-20-23.FG3Gvr')
source = Path('/private/tmp/l1-cut-verified.cCz5nO/row-cap-physical-slice-dense-label-tuple0-0-reduced.pkl')
cases = range(20,24)
archive_path = Path(__file__).resolve().parent / 'pinned.zip'
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    receipts = {name: digest for digest, name in
                (line.split() for line in archive.read('frontiers-uncompressed.sha256').decode().splitlines())}
    parent_hash = sha256(source.read_bytes()).hexdigest()
    assert receipts[source.name] == parent_hash == '5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867'
    roster = archive.read('pilot.roster')
print('archive SHA256',sha256(archive_path.read_bytes()).hexdigest())
print('parent SHA256',parent_hash,'roster SHA256',sha256(roster).hexdigest())
parent = load(source)
assert len(parent['factors']) == 8
axes, raw = literal_eval(roster.decode())
counts = dict(raw)
assert len(counts) == len(raw) == 48
order = sorted(counts, key=lambda c: (counts[c],c))
assert order[20:24] == [(130,(1,)),(130,(2,)),(132,(1,)),(132,(2,))]
for i in cases:
    assert (author/f'case-{i}.roster').read_bytes() == roster
audit(source,parent['rejected_pair'],axes,counts,{order[i]:author/f'case-{i}.pkl' for i in cases})
for i in cases:
    child = load(author/f'case-{i}.pkl')
    p = author/f'label-case-{i}-1-reduced-frontier.pkl'
    data = p.read_bytes()
    state = pickle.loads(data)
    assert state['conditioning'] == child['conditioning']
    assert state['label_partition'] == child['label_partition']
    factors = state['factors']
    assert prod(d for _,_,d in factors)==40512224221827380280140849737629696
    assert all(d>0 and len(a)==len(set(a)) and all(len(k)==len(a) and len(v)==2 and any(v) and all(type(x) is int for x in v)
                                                for k,v in table.items()) for a,table,d in factors)
    assert set(Counter(w for a,_,_ in factors for w in a).values()) == {2}
    assert not set(dict(state['conditioning'])).intersection(w for a,_,_ in factors for w in a)
    print('replay input',i,order[i],counts[order[i]],p.name,sha256(data).hexdigest(),len(factors),sum(len(t) for _,t,_ in factors))
print('PASS archive pin, full 48-way pair support, four inverse lifts and terminal input lineage')
