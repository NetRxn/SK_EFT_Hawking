from fractions import Fraction
from pathlib import Path
import re

root=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-open-roster-20-23.FG3Gvr')
normalized=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
raw=re.compile(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',re.M)
joins=re.compile(r'^independent join \d+ \d+ products (\d+) output rows (\d+) remaining \d+$',re.M)
batch=dict((i,receipt) for i, disposition,receipt in (line.split('\t') for line in (author/'batch.tsv').read_text().splitlines()) if disposition=='exact')
total_real=total_imaginary=Fraction(0)
assert (root/'audit.out').read_text().endswith('PASS archive pin, full 48-way pair support, four inverse lifts and terminal input lineage\n')
for i in range(20,24):
    log=(root/f'case-{i}-replay.out').read_text()
    (r,im),=normalized.findall(log)
    sr,si=Fraction(r),Fraction(im)
    (nr,ni,d),=raw.findall(log)
    scale=int(d)*16*4**64
    assert (sr,si)==(Fraction(int(nr),scale),Fraction(int(ni),scale))
    assert (r,im)==normalized.findall((author/f'case-{i}-1-contract.out').read_text())[0]==normalized.findall(batch[str(i)])[0]
    parts=[(int(p),int(rows)) for p,rows in joins.findall(log)]
    count=sum(p for p,_ in parts)
    peak_join=max(p for p,_ in parts)
    peak_rows=max(rows for _,rows in parts)
    assert len(parts)==4 and count==6945952 and peak_join==4938288
    total_real+=sr
    total_imaginary+=si
    print('PASS case',i,'real',sr,'imaginary',si,'products',count,'maximum join',peak_join,'largest retained output',peak_rows)
print('PASS cases 20 through 23 subtotal', total_real, total_imaginary)
