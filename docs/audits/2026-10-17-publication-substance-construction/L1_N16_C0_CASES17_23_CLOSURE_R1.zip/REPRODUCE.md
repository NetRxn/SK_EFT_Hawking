# L1 N16 dense group 128 exact cases 17 through 23

This package is scoped to the first binary child of tuple 0, descendant (0,0), scientific source 51e7c745e and publication parent 08db0bb2f. It preserves independent scalar replays with exact signed arithmetic. Keep each coordinate and its input bound to its own ledger. Coincident scalar values do not enter the acceptance argument.

## Cases 17–19

Restore the parent `row-cap-physical-slice-dense-label-case-N-2-reduced.pkl` from the `next-frontiers` instructions and expected hashes in `L1_N16_C0_CASES4_11_CLOSURE_R1.zip`. Replace N with 17, 18 or 19. The expected SHA256 values are, respectively, `d47f58d7f13a76695d40066cf6a2a91594913f085b3adbdf638b87bd22927a82`, `99bcc702ff93d5794b5336d95bdd4932a1bfbba5485693595e5089928ebf9fab`, and `49a6f32c38addd2fc82aa83d95105126f5cef4fc39493053b29cfa75e347e7c8`. Only deserialize trusted checkpoint inputs.

Copy the contents of the corresponding author folder to fresh scratch. Run:

```bash
python3 -u run-primary.py /absolute/path/to/restored-parent.pkl >slices.tsv
python3 -u reduce-open.py 0 1 2 3 4 5 6 7 8 >rescue.tsv
python3 -u capture-quotient.py slice-4 >capture-4.out
cmp capture-4.out slice-4-contract.out
python3 -u capture-quotient.py slice-5 >capture-5.out
cmp capture-5.out slice-5-contract.out
shasum -a 256 -c /absolute/path/to/archive/inputN.sha256
python3 sum-caseN.py
```

The nine internal partitions each cover 1,021,248 selected pair products. Final three-factor capture only adds serialization after quotient and is checked against the original author log. The independent replays used different joins on the terminal inputs. Their reports distinguish original refused routes, final result and the earlier reduced-lineage boundary.

## Cases 20–23

Restore the eight-factor parent `row-cap-physical-slice-dense-label-tuple0-0-reduced.pkl` in `L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip`, SHA256 `5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867`. From a fresh copy of the contents of `author20-23`, run `python3 -u run-batch.py /absolute/path/to/restored-parent.pkl 20 21 22 23` and compare logs and frozen input hashes. The complete outer cut support and all four inverse lifts were independently audited before terminal calculations.

The frozen reviewer manifests may name Git archive copies. Restore their exact bytes from the upstream original separator and cases 4–11 ZIPs under the basenames in the reports. This package keeps the pinned archive objects in their existing repository locations. Full signed coefficient, physical susceptibility and publication gates remain open.

## Recombine the accepted terms

Run `python3 verify-current.py` after extracting the package. It checks exact author and independent values, including the 27 separately normalized raw Gaussian replays. Then run `python3 retally.py /absolute/path/to/repo/docs/audits/2026-10-17-publication-substance-construction`. It reads previous frozen receipts and reports a single exact, duplicate-free subtotal over the verified entries of the archived 48-case roster. The result is partial and the remaining indices are printed separately.

The seven next cases 25–31 have exact prejoin frontiers. Run the same author batch command as for 20–23 with indices `25 26 27 28 29 30 31`, then compare `next-frontiers/inputs.sha256` and its immutable receipts. Further partitioning and independent acceptance remain required.
