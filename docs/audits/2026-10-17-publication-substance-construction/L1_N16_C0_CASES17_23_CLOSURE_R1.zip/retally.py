"""Read frozen independent result receipts and sum one partial 48-case roster."""
from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re
import sys
from zipfile import ZipFile

root=Path(__file__).resolve().parent
evidence=Path(sys.argv[1])
values={}

def add(index, pair, ref):
    assert index not in values
    values[index]=(Fraction(pair[0]),Fraction(pair[1]),ref)

def from_archive(name,member):
    archive=f'L1_N16_C0_{name}_R1.zip'
    with ZipFile(evidence/archive) as z:
        return z.read(member).decode(), f'{archive}:{member}'

def archived_rows(name,member,indices):
    text,ref=from_archive(name,member)
    seen=set()
    for row in text.splitlines():
        fields=row.split('\t')
        if fields[0].isdigit() and int(fields[0]) in indices:
            index=int(fields[0])
            add(index,fields[-2:],ref)
            seen.add(index)
    assert seen==indices

def archived_match(index,name,member,pattern):
    body,ref=from_archive(name,member)
    (pair,)=re.findall(pattern,body,re.M)
    add(index,pair,ref)

archived_rows('SEPARATOR_BATCH','accepted-values.tsv',{0,1,2})
archived_match(3,'CASE3_SCALEUP','independent/replay-3-2.out',r'^exact normalized real (\S+) imaginary (\S+)')
archived_rows('CASES4_11_CLOSURE','aggregate.out',set(range(4,12)))
archived_match(12,'SEPARATOR_CASE12','independent/accepted.tsv',r'^TOTAL\t(\S+)\t(\S+)$')
archived_rows('CASES13_15_CLOSURE','aggregate-cases.out',{13,14,15})
archived_match(16,'CASE16_CLOSURE','independent/aggregate.out',r'^PASS full exact independent case 16 sum (\S+) (\S+)$')
for index in (17,18,19):
    path=f'author{index}/author-case{index}.tsv'
    line=(root/path).read_text().splitlines()[-1].split('\t')
    assert line[0]=='sum'
    add(index,line[1:],f'{path} [independent terminal receipts checked by verify-current.py]')
for i,r in enumerate((root/'review20-23/aggregate.out').read_text().splitlines()[:4],20):
    pattern=rf'^PASS case {i} real (\S+) imaginary (\S+) '
    add(i,re.match(pattern,r).groups(),'review20-23/aggregate.out')
archived_match(24,'SEPARATOR_RECOVERY_24_36_46','independent/accepted.tsv',r'^ACCEPTED OUTER\t24\t(\S+)\t(\S+)$')
archived_match(32,'CASE32_CLOSURE','independent/aggregate.out',r'^PASS full exact independent case 32 sum (\S+) (\S+)$')
for i in (36,46):
    archived_match(i,'FOUR_FACTOR_CLOSURE','independent/accepted.tsv',rf'^ACCEPTED OUTER\t{i}\t(\S+)\t(\S+)$')
archived_match(47,'CASE47_CLOSURE','independent/aggregate.out',r'^PASS full exact independent case 47 sum (\S+) (\S+)$')
roster,_=from_archive('LARGER_TUPLE_SEPARATOR','pilot.roster')
_,coordinates=literal_eval(roster)
ordered=sorted(coordinates,key=lambda item:(item[1],item[0]))
assert len(ordered)==len(dict(ordered))==48
assert set(values)==set(range(25))|{32,36,46,47}
print('index','roster coordinate','real','imaginary','receipt',sep='\t')
for i,(x,y,ref) in sorted(values.items()):
    print(i,ordered[i][0],x,y,ref,sep='\t')
print('PARTIAL SUM',len(values),sum(x for x,_,_ in values.values()),sum(y for _,y,_ in values.values()),sep='\t')
print('OPEN',','.join(str(i) for i in range(48) if i not in values),sep='\t')
