from hashlib import file_digest
from pathlib import Path

root = Path(__file__).resolve().parent
author = Path('/private/tmp/l1-c0-case19.QpDhc7')
parent = Path('/private/tmp/l1-open-roster-next.56OPQR/row-cap-physical-slice-dense-label-case-19-2-reduced.pkl')
ledger = author / 'author-case19.tsv'
inputs = {parent, ledger}
inputs.update(author / name for name in (
    'slices.tsv', 'rescue.tsv', 'exact-multicut.py', 'reduce-label-frontier.py',
    'contract-reduced-label.py', 'capture-quotient.py', 'contract-peer.py',
    'peer_pair.py', 'checkpoint/quotient.py', 'run-primary.py', 'reduce-open.py',
))
for i, entry in enumerate(ledger.read_text().splitlines()[:-1]):
    receipt = entry.split('\t')[-1]
    stem = receipt.removesuffix('-contract.out')
    names = (f'slice-{i}.pkl', f'slice-{i}.roster', f'slice-{i}-plan.out',
             f'slice-{i}-contract.out', f'slice-{i}-reduce.out',
             f'label-slice-{i}-reduced-frontier.pkl',
             receipt, f'label-{stem}-reduced-frontier.pkl')
    inputs.update(author / name for name in names)
for i in (4, 5):
    inputs.update(author / name for name in (f'post-quotient-slice-{i}.pkl', f'capture-{i}.out'))
for pattern in ('rescue-*-reduce.out', 'rescue-*-contract.out',
                'join-cap-*-reduced.pkl', 'row-cap-*-reduced.pkl', 'label-rescue-*-reduced-frontier.pkl'):
    inputs.update(author.glob(pattern))
for path in sorted(inputs):
    with path.open('rb') as stream:
        print(file_digest(stream, 'sha256').hexdigest(), '  ', path, sep='')
