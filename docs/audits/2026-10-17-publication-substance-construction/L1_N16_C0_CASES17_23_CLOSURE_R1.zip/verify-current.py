"""Check the three archived nine-slice contractions and four direct outer values."""
from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

root=Path(__file__).resolve().parent
normalized=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
raw=re.compile(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',re.M)

def exact(text):
    return tuple(map(Fraction,normalized.search(text).groups()))

for case in (17,18,19):
    a=root/f'author{case}'
    r=root/f'review{case}'
    rows=[line.split('\t') for line in (a/f'author-case{case}.tsv').read_text().splitlines()]
    assert len(rows)==10 and [int(fields[0]) for fields in rows[:-1]]==list(range(9))
    axes,roster=literal_eval((a/'slice-0.roster').read_text())
    ordered=sorted(roster,key=lambda row:(row[1],row[0]))
    assert axes == (('G',0,1,2),) and len(ordered)==len(dict(ordered))==9
    assert sum(n for _,n in ordered)==1_021_248
    sx=sy=Fraction()
    for index,coord,matches,x,y,receipt in rows[:-1]:
        coordinate,n=ordered[int(index)]
        assert (int(coord),int(matches))==(coordinate[0],n)
        assert literal_eval((a/f'slice-{index}.roster').read_text())==(axes,roster)
        if index in ('4','5'):
            suffix='capture-replay'
        elif case==18:
            suffix='terminal-replay'
        else:
            suffix='replay'
        log=(r/f'slice-{index}-{suffix}.out').read_text()
        found=exact(log)
        nr,ni,den=map(int,raw.search(log).groups())
        scale=den*16*4**64
        assert found==(Fraction(nr,scale),Fraction(ni,scale))==(Fraction(x),Fraction(y))
        assert found==exact((a/receipt).read_text())
        sx+=found[0]
        sy+=found[1]
    assert rows[-1]==['sum',str(sx),str(sy)]
    print('PASS',case,sx,sy)

a=root/'author20-23'
r=root/'review20-23'
values=[]
for i,line in enumerate((a/'batch.tsv').read_text().splitlines(),20):
    n,state,result=line.split('\t')
    assert n==str(i) and state=='exact'
    found=exact((r/f'case-{i}-replay.out').read_text())
    assert found==exact(result)
    values.append(found)
    print('PASS',i,*found)
assert len(values)==4
