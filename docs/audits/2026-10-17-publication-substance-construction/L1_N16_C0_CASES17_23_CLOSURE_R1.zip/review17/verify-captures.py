from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads

author=Path('/private/tmp/l1-c0-case17.3sDb9H')
checks={4:'0688464bb91e74b815bd324403ab9e8d4877d0590c2bac1b475059b9da23dbc5',5:'a66c95d5e59adc676047bb13fbd150b7786dbebe908f54b51bfbaa314c6fe46e'}
source=(author/'contract-reduced-label.py').read_text()
capture=(author/'capture-quotient.py').read_text()
addendum="""\n        if len(factors)==3:
            snap={**obj,'factors':factors,'used_before':work}
            with Path(f'post-quotient-{tag}.pkl').open('xb') as handle:
                pickle.dump(snap,handle,protocol=5)
\n"""
assert capture.count(addendum)==1 and capture.replace(addendum,'')==source
for i,expected in checks.items():
    raw=(author/f'post-quotient-slice-{i}.pkl').read_bytes()
    assert sha256(raw).hexdigest()==expected
    assert (author/f'capture-{i}.out').read_bytes()==(author/f'slice-{i}-contract.out').read_bytes()
    reduced=loads(raw)
    child=loads((author/f'slice-{i}.pkl').read_bytes())
    assert all(reduced[key]==child[key] for key in ('conditioning','label_partition'))
    factors=reduced['factors']
    assert len(factors)==3 and set(Counter(w for a,_,_ in factors for w in a).values())=={2}
    assert prod(d for _,_,d in factors)==40512224221827380280140849737629696
    assert all(d>0 and len(a)==len(set(a)) and all(len(k)==len(a) and len(v)==2 and any(v) and all(type(x) is int for x in v)
                                                for k,v in rows.items()) for a,rows,d in factors)
    print('PASS capture',i,expected,'retained rows',sum(len(r) for _,r,_ in factors),'prefix products',reduced['used_before'])
