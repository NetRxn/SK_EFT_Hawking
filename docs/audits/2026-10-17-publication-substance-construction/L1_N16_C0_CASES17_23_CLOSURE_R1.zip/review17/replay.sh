#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 audit.py > audit.out
a=/private/tmp/l1-c0-case17.3sDb9H
tab=$(printf '\t')
while IFS="$tab" read -r index coord products real imag receipt; do
    if test "$index" = sum; then break; fi
    stem=${receipt%-contract.out}
    if python3 -u replay.py "$index" 0 "$a/label-$stem-reduced-frontier.pkl" "$a/$receipt" > "slice-$index-replay.out" 2>&1; then
        test "$index" != 4 && test "$index" != 5
    else
        case "$index" in
            4|5) grep -q 'assert len(out)<=1000000' "slice-$index-replay.out" ;;
            *) exit 1 ;;
        esac
    fi
done < "$a/author-case17.tsv"
python3 verify-captures.py > capture-audit.out
for index in 4 5; do
    python3 -u replay.py "$index" 0 "$a/post-quotient-slice-$index.pkl" "$a/capture-$index.out" > "slice-$index-capture-replay.out"
done
python3 aggregate.py > aggregate.out
