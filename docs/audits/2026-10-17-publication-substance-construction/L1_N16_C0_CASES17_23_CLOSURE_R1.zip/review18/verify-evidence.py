from collections import Counter
from pathlib import Path

def rows(path):
    return [tuple(row.split('\t')) for row in Path(path).read_text().splitlines()]

lineage = rows('lineage.tsv')
terminals = [r for r in lineage if r[-1].startswith('exact normalized')]
refusals = [r for r in lineage if r[-1].startswith(('open row cap', 'open join cap'))]
assert len(lineage) == 17 and len(refusals) == 8
assert Counter(int(r[0]) for r in terminals) == Counter(range(9))
replays = rows('replay-18.tsv')
assert set(replays) == {(str(18), str(i), 'terminal', '0') for i in range(9)} | {
    ('18', '4', 'capture', '0'), ('18', '5', 'capture', '0')}
audit = Path('check-cuts-and-sum.out').read_text().splitlines()
assert sum(line.startswith('PASS slice ') for line in audit) == 9
assert audit[-1] == 'PASS exact case 18 sum 11627739971317979867547/5192296858534827628530496329220096 imaginary 0'
for i in (4, 5):
    log = Path(f'slice-{i}-terminal-replay.out').read_text()
    assert 'PASS raw scalar numerator' in log
    assert 'independent matched products 8352280 ' in log
    assert 'forecast 4817664 ' in log
    captured = Path(f'slice-{i}-capture-replay.out').read_text()
    assert 'independent matched products 874608 ' in captured
assert len(Path('author-frozen-verify.out').read_text().splitlines()) == 98
print('PASS nine exact inverse lifts and independent terminal scalars, both capture replays, and complete 17-cycle unchanged author lineage')
