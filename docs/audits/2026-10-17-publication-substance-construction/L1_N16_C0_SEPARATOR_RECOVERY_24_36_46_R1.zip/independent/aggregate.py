from ast import literal_eval
from fractions import Fraction
import hashlib
import pickle
from pathlib import Path
import re

scratch=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-recover-three.jPcO9K')
cuts=(scratch/'check-cuts.out').read_text()
for outer in ('24','36','46'):
    directory=author/outer
    assert f'PASS nine-case projection and exact inverse lifting for outer {outer}' in cuts
    axes,rows=literal_eval((directory/'case-0.roster').read_text())
    roster=sorted(rows,key=lambda pair:(pair[1],pair[0]))
    assert len(roster)==len({coords for coords,_ in roster})==9
    receipts={}
    for row in (directory/'batch.out').read_text().splitlines():
        case,status,scalar=row.split('\t')
        assert int(case) not in receipts
        receipts[int(case)]=(status,scalar)
    assert set(receipts)==set(range(9))
    accepted=[]
    open_cases=[]
    print('OUTER',outer,'case\tcoordinate\treal\timaginary\tscope\tproducts\tlargest join\tpeak rows\tinput SHA256')
    for case,(coordinate,_) in enumerate(roster):
        status,scalar=receipts[case]
        rescue=directory/f'rescue-{case}-contract.out'
        rescued=(scratch/f'replay-rescue-{outer}-{case}-rescue.out').is_file()
        if rescued:
            assert status!='exact'
            replay_log=scratch/f'replay-rescue-{outer}-{case}-rescue.out'
            replay_input=directory/f'label-rescue-{case}-reduced-frontier.pkl'
            earlier=pickle.loads((directory/f'case-{case}.pkl').read_bytes())
            later=pickle.loads(replay_input.read_bytes())
            assert later['conditioning']==earlier['conditioning']
            assert later['label_partition']==earlier['label_partition']
            scalar=rescue.read_text().splitlines()[-1]
            scope='additional quotient'
        elif status!='exact':
            open_cases.append(case)
            print('OPEN',case,status,scalar)
            continue
        else:
            logs=[p for p in directory.glob(f'case-{case}-*-contract.out') if p.read_text().splitlines()[-1:]==[scalar]]
            assert len(logs)==1
            stage=logs[0].name.split('-')[2]
            replay_input=directory/f'label-case-{case}-{stage}-reduced-frontier.pkl'
            replay_log=scratch/f'replay-{outer}-{case}-{stage}.out'
            scope='direct'
            if (scratch/f'replay-preclosure-{outer}-{case}-{stage}.out').is_file():
                replay_log=scratch/f'replay-preclosure-{outer}-{case}-{stage}.out'
                earlier=pickle.loads(replay_input.read_bytes())
                replay_input=directory/f'preclosure-case-{case}-{stage}.pkl'
                later=pickle.loads(replay_input.read_bytes())
                assert later['conditioning']==earlier['conditioning']
                assert later['label_partition']==earlier['label_partition']
                scope='three-factor'
        found=re.search(r'^exact normalized real (\S+) imaginary (\S+) independent matched products (\d+) wall',replay_log.read_text(),re.M) if replay_log.is_file() else None
        if not found:
            open_cases.append(case)
            print('OPEN',case,'independent replay pending or cap',replay_log.name)
            continue
        a,b,products=found.groups()
        value=tuple(map(Fraction,(a,b)))
        original=re.fullmatch(r'exact normalized real (\S+) imaginary (\S+) peak rows \d+ matched products \d+',scalar)
        assert value==tuple(map(Fraction,original.groups()))
        data=replay_input.read_bytes()
        state=pickle.loads(data)
        assert tuple(dict(state['conditioning'])[axis] for axis in axes)==coordinate
        joins=[tuple(map(int,match)) for match in re.findall(r'^independent join \d+ \d+ products (\d+) output rows (\d+) remaining ',replay_log.read_text(),re.M)]
        max_join=max(p for p,_ in joins)
        max_rows=max(r for _,r in joins)
        assert max_join<=8000000 and max_rows<=1000000 and int(products)<=30000000
        accepted.append(value)
        print(case,coordinate,*value,scope,products,max_join,max_rows,hashlib.sha256(data).hexdigest(),sep='\t')
    assert len(accepted)+len(open_cases)==9
    if not open_cases:
        print('ACCEPTED OUTER',outer,*(sum(v[i] for v in accepted) for i in (0,1)),sep='\t')
    else:
        print('INCOMPLETE OUTER',outer,'accepted children',len(accepted),'open indices',open_cases)
