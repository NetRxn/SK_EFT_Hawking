# Independent review of separator outer cases 24, 36, and 46

The l1-three-separator-cases-review-r1 continuity packet checked fresh at handoff. The three inputs are separately saved tuple 0 first-binary-child outer cases from the 48-case roster. Scope covers their nine-way partitions and independent arithmetic from frozen reduced factors. No tracked path, Lean process or slot was used.

The direct replay imports no author contraction, quotient or support code. It forecasts each candidate join on the actual shared coordinates, then contracts integer Gaussian coefficients exactly. It enforces 8,000,000 products per join, 30,000,000 products total and 1,000,000 retained rows. The factor denominator product is checked against the independently reviewed original branch assembly. External normalization remains +1/(16*4^64). No multiplicity is applied for selecting an outer case or child.

Outer 24 children 2 and 3 refused from their initial reduced inputs at a 29,708,160-product forecast. The accepted replay for each uses the author's frozen post-quotient three-factor snapshot. The source instrumentation only writes the existing factors before the final join. Outer 24 children 5 and 6 and outer 36 and 46 children 2 and 3 recover from the row or product limited frontiers after an additional standard quotient sweep. Their exact replays verify arithmetic from the saved reduced inputs. Preceding reductions are based on frozen lineage and prior algebra review.

Original author refusals and independent refusals are retained. The audit checks each terminal replay's fixed coordinates and the unchanged representation-label partition. Complete outer sums require independent inverse-lift and roster coverage for every child as well as all nine exact terminal contributions.

All three nine-case supports and all 27 inverse lifts passed. The independent pair forecasts for cases 24, 36 and 46 are respectively 2,579,328, 2,001,024 and 2,280,960 products, with maximum per child 398,592, 435,456 and 497,664. These counts concern the projected pair. Later joins have separate costs and limits.

Outer 24 is independently complete. The exact sum is -70691890706351622304821/5192296858534827628530496329220096 with imaginary part 0. Outer 36 and outer 46 each have seven accepted children. Children 7 and 8 remain open in both. Their author restart states have four factors each, with 155,864 rows for outer 36 and 178,532 for outer 46. No partial total is promoted to a completed outer coefficient. Accepted.tsv reports every replay input checksum, value, scope and resource bound, plus the unresolved children.

The accepted outer total belongs to one entry of tuple 0's first binary child. The full binary-child sum, tuple 0, tuple 1, branch 128, full profile and c0 remain open.
