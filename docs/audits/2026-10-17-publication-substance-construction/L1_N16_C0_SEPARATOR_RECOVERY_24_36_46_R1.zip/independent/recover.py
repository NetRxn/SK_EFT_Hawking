from pathlib import Path
import re
import subprocess
import sys

root=Path('/private/tmp/l1-recover-three.jPcO9K')
scratch=Path(__file__).resolve().parent
for outer in ('24','36','46'):
    directory=root/outer
    for child in range(9):
        for label,mask in (('rescue',f'rescue-{child}-contract.out'),('preclosure',f'case-{child}-preclosure.out')):
            receipt=directory/mask
            if not receipt.is_file():
                continue
            lines=receipt.read_text().splitlines()
            if not lines or not lines[-1].startswith('exact normalized real '):
                continue
            if label=='preclosure':
                snapshots=list(directory.glob(f'preclosure-case-{child}-*.pkl'))
                assert len(snapshots)==1
                replay_input=snapshots[0]
                stage=replay_input.stem.split('-')[-1]
            else:
                replay_input=directory/f'label-rescue-{child}-reduced-frontier.pkl'
                stage='rescue'
            output=scratch/f'replay-{label}-{outer}-{child}-{stage}.out'
            if output.is_file():
                continue
            assert replay_input.is_file()
            with output.open('x') as handle:
                result=subprocess.run([sys.executable,'-u',str(scratch/'replay.py'),outer,str(child),stage,str(replay_input),str(receipt)],stdout=handle,stderr=subprocess.STDOUT)
            print(outer,child,stage,result.returncode,flush=True)
