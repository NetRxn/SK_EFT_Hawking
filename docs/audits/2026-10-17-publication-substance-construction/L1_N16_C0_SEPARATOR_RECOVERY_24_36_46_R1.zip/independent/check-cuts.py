from ast import literal_eval
from collections import Counter
from pathlib import Path
import pickle

root = Path('/private/tmp/l1-tuple-separators.OxRDWT')
previous = Path('/private/tmp/l1-dense-resume.bbZW6V')

def load(path):
    return pickle.loads(path.read_bytes())

def audit(source, pair, fixed_axes, plan, children):
    parent = load(source)
    factors = parent['factors']
    degree = Counter(w for axes, _, _ in factors for w in axes)
    assert set(degree.values()) == {2}
    left, right = (factors[i] for i in pair)
    common = set(left[0]).intersection(right[0])
    ordered = tuple(sorted(common))
    buckets = Counter(tuple(dict(zip(right[0], row))[a] for a in ordered) for row in right[1])
    spectrum = Counter()
    for row in left[1]:
        assignment = dict(zip(left[0], row))
        multiplicity = buckets[tuple(assignment[a] for a in ordered)]
        if multiplicity:
            spectrum[tuple(assignment[a] for a in fixed_axes)] += multiplicity
    assert spectrum == plan
    for coordinate, path in children.items():
        fixed = dict(zip(fixed_axes, coordinate))
        child = load(path)
        assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
        assert child['label_partition'] == parent['label_partition']
        for (axes, rows, denominator), (small_axes, small_rows, small_denominator) in zip(factors, child['factors'], strict=True):
            assert denominator == small_denominator
            assert tuple(w for w in axes if w not in fixed) == small_axes
            expected = {row: value for row, value in rows.items()
                        if all(row[p] == fixed[w] for p,w in enumerate(axes) if w in fixed)}
            recovered = {}
            for row,value in small_rows.items():
                assignment = dict(zip(small_axes,row))
                assignment.update(fixed)
                recovered[tuple(assignment[w] for w in axes)] = value
            assert recovered == expected
    print(source.name, 'pair',pair,'cuts',fixed_axes,'cases',len(spectrum),
          'sum/max products',sum(spectrum.values()),max(spectrum.values()),'children audited',list(children),flush=True)

root=Path('/private/tmp/l1-recover-three.jPcO9K')
batch=Path('/private/tmp/l1-separator-batch.s99JBN')
probes=Path('/private/tmp/l1-peer-pair.e9j13C')
outer_axes, base_rows=literal_eval(Path('/private/tmp/l1-tuple-separators.OxRDWT/pilot.roster').read_text())
outer_roster=sorted(base_rows,key=lambda pair:(pair[1],pair[0]))
for outer in (24,36,46):
    source=batch/f'row-cap-physical-slice-dense-label-case-{outer}-2-reduced.pkl'
    parent=load(source)
    parent_fixed=dict(parent['conditioning'])
    assert tuple(parent_fixed[a] for a in outer_axes)==outer_roster[outer][0]
    directory=root/str(outer)
    axes, raw=literal_eval((probes/f'next-{outer}.roster').read_text())
    counts=dict(raw)
    assert len(axes)==1 and len(counts)==len(raw)==9
    order=sorted(counts,key=lambda coord:(counts[coord],coord))
    children={}
    for index, coordinates in enumerate(order):
        childfile=directory/f'case-{index}.pkl'
        assert literal_eval((directory/f'case-{index}.roster').read_text())==(axes,raw)
        children[coordinates]=childfile
        child=load(childfile)
        terminal=[p for p in directory.glob(f'case-{index}-*-contract.out')
                  if any(line.startswith('exact normalized real ') for line in p.read_text().splitlines())]
        for log in terminal:
            stage=log.name.split('-')[2]
            final=load(directory/f'label-case-{index}-{stage}-reduced-frontier.pkl')
            assert final['conditioning']==child['conditioning']
            assert final['label_partition']==child['label_partition']
        print('outer',outer,'case',index,coordinates,'matched',counts[coordinates],flush=True)
    audit(source,parent['rejected_pair'],axes,counts,children)
    print('PASS nine-case projection and exact inverse lifting for outer',outer,flush=True)
