from pathlib import Path
import re
import subprocess
import sys
import time

root=Path('/private/tmp/l1-recover-three.jPcO9K')
scratch=Path(__file__).resolve().parent
deadline=time.monotonic()+150
tested=set()
while time.monotonic()<deadline:
    done=0
    for outer in ('24','36','46'):
        base=root/outer
        for line in (base/'batch.out').read_text().splitlines():
            pieces=line.split('\t')
            if len(pieces)!=3:
                continue
            case,status,value=pieces
            key=outer,case
            done+=1
            if key in tested:
                continue
            tested.add(key)
            if status!='exact':
                print(outer,case,'author',status,value,flush=True)
                continue
            terminal=[p for p in base.glob(f'case-{case}-*-contract.out') if p.read_text().splitlines()[-1:]==[value]]
            assert len(terminal)==1
            stage=terminal[0].name.split('-')[2]
            candidate=scratch/f'replay-{outer}-{case}-{stage}.out'
            if candidate.exists():
                continue
            with candidate.open('x') as log:
                result=subprocess.run([sys.executable,'-u',str(scratch/'replay.py'),outer,case,stage],stdout=log,stderr=subprocess.STDOUT)
            print(outer,case,stage,result.returncode,flush=True)
    if done==27:
        break
    time.sleep(2)
