from itertools import product
from src.core.formulas import original_action_factors, original_coframe_blocks, original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol

reg=OriginalRegulator()
assert (reg.extents,reg.boundary_signs,reg.convention,reg.word)==((2,)*4,(1,)*4,'source_C','closed')
def shift(x,t):
    return tuple(a^b for a,b in zip(x,t,strict=True))
for t,x,d,k in product(reg.sites,reg.sites,range(4),(-1,1)):
    end,sgn=reg.step(x,d,k)
    assert reg.step(shift(x,t),d,k)==(shift(end,t),sgn)
    assert sgn==1

links={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in reg.link_order}

x=(0,1,0,1)
t=(1,0,1,1)
y=shift(x,t)
def component(alpha):
    x,axis,a=alpha
    return shift(x,t),axis,a
def anchor(link):
    x,axis=link
    return shift(x,t),axis
def terms(poly):
    return {tuple(sorted(Symbol('q',(shift(s.index[0],t),*s.index[1:])) for s in key)):v for key,v in poly.terms}
for mu,a in product(range(4),repeat=2):
    for b,c in zip(original_coframe_blocks(reg,(x,mu,a),links),original_coframe_blocks(reg,(y,mu,a),links),strict=True):
        assert (component(b.alpha),shift(b.bar_site,t),shift(b.psi_site,t),anchor(b.anchor),b.weight)==(c.alpha,c.bar_site,c.psi_site,c.anchor,c.weight)
        for row_b,row_c in zip(b.matrix,c.matrix,strict=True):
            for p,q in zip(row_b,row_c,strict=True):
                assert terms(p)==dict(q.terms)
                assert all(len(key)==1 and key[0].index[:2]==b.anchor for key,_ in p.terms)
print('all 2048 signed-hop translation identities and all 64 symbolic coframe blocks in a mixed wrap translation pass',flush=True)
count=0
for b,c in zip(original_action_factors(reg,x,links),original_action_factors(reg,y,links),strict=True):
    assert (b.t_degree,tuple(map(component,b.components)),tuple(map(anchor,b.anchors)))==(c.t_degree,c.components,c.anchors)
    assert terms(b.coefficient)==dict(c.coefficient.terms)
    assert all(sorted(s.index[:2] for s in key)==sorted(b.anchors) for key,_ in b.coefficient.terms)
    count+=1
assert count==408
print('all 408 signed local source factors in a mixed wrap translation pass; all monomials carry exactly their recorded plaquette anchors')
