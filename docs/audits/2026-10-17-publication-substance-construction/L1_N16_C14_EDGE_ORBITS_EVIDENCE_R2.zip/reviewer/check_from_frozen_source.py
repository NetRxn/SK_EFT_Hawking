from collections import Counter, defaultdict
from functools import reduce
from hashlib import sha256
from math import factorial, prod
from operator import xor
from pathlib import Path
import json,sys

root=Path(sys.argv[1])
census=json.loads((root/'support-census.json').read_text())
source_rows=census['sites']
site_index={tuple(row['site']):i for i,row in enumerate(source_rows)}
anchor_edge={}
for x in range(16):
    for axis in range(4):
        opposite=x^(8>>axis)
        anchor_edge[x,axis]=min(x,opposite),max(x,opposite)
undirected={edge:1<<i for i,edge in enumerate(sorted(set(anchor_edge.values())))}
assert len(anchor_edge)==64 and len(undirected)==32
def mask(items):
    return reduce(xor,(undirected[anchor_edge[item]] for item in items),0)
s2={}
s4={}
for x,row in enumerate(source_rows):
    for degree, components, anchors, trace_terms, _ in row['raw_branches']:
        if not trace_terms:
            continue
        directions=tuple(d for d,_ in components)
        assert len(set(directions))==degree
        if degree==2:
            assert set(d for _,d in anchors)==set(range(4))-set(directions)
            assert len(anchors)==4
        else:
            assert degree==4 and not anchors
        m=mask([(x,d) for d in directions]+[(site_index[tuple(site)],d) for site,d in anchors])
        table,key=(s2,(x,*directions)) if degree==2 else (s4,x)
        prior=table.setdefault(key,m)
        assert m==prior and m.bit_count()==(6 if degree==2 else 4)
assert len(s2)==96 and len(s4)==16
for x,row in enumerate(source_rows):
    for degree, components,*_ in row['grouped_branches']:
        if degree==2:
            assert (x,*(d for d,_ in components)) in s2

def signature(row):
    return (tuple(map(tuple,row['planes'])),tuple(row['S4_occupations']),row['exponential_divisor'])

raw=(root/'c14-occupancy-roster.jsonl').read_bytes()
all_rows=set(map(signature,map(json.loads,raw.splitlines())))
assert len(all_rows)==1968
counts=Counter()
clusters=defaultdict(set)
for labels,occ,divisor in all_rows:
    assert divisor==prod(factorial(v) for v in (*Counter(labels).values(),*occ))
    m=reduce(xor,(s2[branch] for branch in labels),0)
    m^=reduce(xor,(s4[x] for x,q in enumerate(occ) if q&1),0)
    centers={x for x,_,_ in labels}
    counts[len(centers),m==0]+=1
    if m:
        continue
    # Use the unique occupied S2 center as the translation origin, then
    # invert that change of origin independently to check all rooted rows.
    assert len(centers)==1
    x=next(iter(centers))
    canonical=(tuple((0,a,b) for _,a,b in labels),tuple(occ[i^x] for i in range(16)),divisor)
    clusters[canonical].add(x)
for (labels,occ,divisor),origins in clusters.items():
    assert origins==set(range(16))
    for x in origins:
        image=(tuple((x,a,b) for _,a,b in labels),tuple(occ[i^x] for i in range(16)),divisor)
        assert image in all_rows
# All translations reorder the 128 generators by complete eight-label blocks.
for t in range(16):
    perm=[8*(x^t)+i for x in range(16) for i in range(8)]
    assert sum(perm[i]>perm[j] for i in range(128) for j in range(i+1,128))%2==0
result={'roster_sha256':sha256(raw).hexdigest(),
        'counts':[dict(centers=n,even=e,rows=v) for (n,e),v in sorted(counts.items())],
        'translation_orbits':[dict(planes=labels,occupations=q,factorial_divisor=d,size=len(cluster))
        for (labels,q,d),cluster in sorted(clusters.items())]}
expected=json.loads(Path(sys.argv[2]).read_text())
assert json.loads(json.dumps(result))==expected
print(json.dumps(result,indent=2))
