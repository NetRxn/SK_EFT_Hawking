"""Check the unoriented-edge parity cut and translation orbits of c14."""
from collections import Counter
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import sys

roster = Path(sys.argv[1]).read_bytes()
sites = tuple(product(range(2), repeat=4))
ranks = {site: i for i, site in enumerate(sites)}
axes = frozenset(range(4))
rows = [json.loads(line) for line in roster.splitlines()]


def step(site, axis):
    return site[:axis] + (1 - site[axis],) + site[axis + 1:]


def edge(site, axis):
    return min(site, step(site, axis)), axis


def shift(site, vector):
    return tuple(a ^ b for a, b in zip(site, vector, strict=True))


def signature(row):
    return tuple(map(tuple, row["planes"])), tuple(row["S4_occupations"]), row["exponential_divisor"]


def translate(row, vector):
    planes, occupations, divisor = signature(row)
    return (
        tuple(sorted((ranks[shift(sites[index], vector)], k, l) for index, k, l in planes)),
        tuple(occupations[ranks[shift(site, vector)]] for site in sites),
        divisor,
    )


counts = Counter()
survivors = {}
for row in rows:
    degrees = Counter()
    for site, number in zip(sites, row["S4_occupations"], strict=True):
        for axis in axes:
            degrees[edge(site, axis)] += number
    for index, mu, nu in row["planes"]:
        site = sites[index]
        k, l = sorted(axes - {mu, nu})
        anchors = ((site, k), (step(site, k), l), (step(site, l), k), (site, l))
        degrees.update(edge(anchor, axis) for anchor, axis in anchors)
        degrees.update(edge(site, axis) for axis in (mu, nu))
    assert sum(degrees.values()) == 14 * 4 + 4 * 6
    centers = len({index for index, _, _ in row["planes"]})
    even = not any(degree % 2 for degree in degrees.values())
    counts[centers, even] += 1
    if even:
        survivors[signature(row)] = row

assert counts == {(1, False): 48, (1, True): 48, (2, False): 1776, (4, False): 96}
assert len(survivors) == 48
unassigned = set(survivors)
orbits = []
while unassigned:
    representative = min(unassigned)
    images = {translate(survivors[representative], vector) for vector in sites}
    assert len(images) == 16 and images <= unassigned
    orbits.append({"planes": representative[0], "occupations": representative[1],
                   "factorial_divisor": representative[2], "size": len(images)})
    unassigned -= images
assert len(orbits) == 3
print(json.dumps({"roster_sha256": sha256(roster).hexdigest(),
                  "counts": [{"centers": n, "even": e, "rows": v}
                             for (n, e), v in sorted(counts.items())],
                  "translation_orbits": orbits}, indent=2))
