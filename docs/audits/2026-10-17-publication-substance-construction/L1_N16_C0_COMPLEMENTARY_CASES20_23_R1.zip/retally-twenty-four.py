from fractions import Fraction
from pathlib import Path
import re

values={}
for line in Path('preceding-twenty.tsv').read_text().splitlines():
    fields=line.split('\t')
    if fields[0].isdigit():
        i,x,y=fields
        assert int(i) not in values
        values[int(i)]=(Fraction(x),Fraction(y))
assert set(values)==set(range(20))
for i,x,y in re.findall(r'^PASS case (\d+) exact normalized (\S+) (\S+)',Path('aggregate.out').read_text(),re.M):
    assert int(i) not in values
    values[int(i)]=(Fraction(x),Fraction(y))
assert set(values)==set(range(24))
for i,(x,y) in sorted(values.items()):
    print(i,x,y,sep='\t')
print('PARTIAL SUM',len(values),*map(sum,zip(*values.values())),sep='\t')
