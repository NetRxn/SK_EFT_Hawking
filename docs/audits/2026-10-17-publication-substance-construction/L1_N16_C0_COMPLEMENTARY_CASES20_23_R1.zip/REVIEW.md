# Complementary tuple 0 cases 20–23 independent exact review

The four separate selector-1 replays give exact subtotal **891626159802532421997 / 649037107316853453566312041152512 + 0i**.

| Case | Coordinate | Exact normalized real | Imaginary |
| --- | --- | --- | --- |
| 20 | (130, (1,)) | 896319661658118850215/5192296858534827628530496329220096 | 0 |
| 21 | (130, (2,)) | 29121274344003337413/5192296858534827628530496329220096 | 0 |
| 22 | (132, (1,)) | 3134785905393298749225/5192296858534827628530496329220096 | 0 |
| 23 | (132, (2,)) | 3072782437024838439123/5192296858534827628530496329220096 | 0 |

At publication checkpoint 67d6876f170cba4e89e5c6bf995643fe66b8f13a, the original separator pins the eight-factor complementary parent tuple0-1 to uncompressed SHA256 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d. Its selector R(0,0,2,0,1) is 1. Independent matching on parent pair (0, 1) recovers the full 48-case roster on G(0,4,2) and J(1,4,2), with 6,427,904 compatible products in total and 106,344 for each reviewed case. Each inverse lift recovers every restricted source row, ordered axis, signed coefficient and exact denominator.

Independent lineage reconstruction reproduces the first reductions and three completed joins per case. The first two joins use 19,440 and 1,276,960 products. The last uses 2,762,240 for cases 20 and 22, and 2,196,480 for 21 and 23. The exact five-factor state at each join refusal verifies against the author snapshot. The independent census confirms that every linked join forecast at each refusal exceeds 8,000,000, with a minimum of 8,547,200 for each case. A separate quotient/singleton reconstruction regenerates all four exact rescued terminal tables, with distinct cut and terminal input hashes. The four lineages took 129.22 seconds.

Independent terminal arithmetic uses plain sparse Gaussian-integer joins with neither author quotient routines nor peer projections. Each replay starts from its own rescued checkpoint, uses 6,945,952 compatible products, peaks at 118,976 retained rows, takes 7.07–8.30 seconds and preserves the exact raw numerator and factor denominator. The previously verified positive external scale 1/(16*4^64) is applied once. The signed rationals match the author receipts. The independently regenerated results also match the corresponding coordinates and exact values in the committed selector-0 closure ledger. The pinned selector-1 parent and its separately lifted and replayed inputs establish these four matching scalar values.

This review covers complementary cases 20–23 of tuple 0 in dense group 128 descendant (0, 0). It contributes four terms to the selector-1 contraction.

Keep the relative inputs/ and replays/ directories with the evidence. Restore separator.zip and first-child.zip from the pinned Git objects in SOURCE_PINS.txt. Check both supplied manifests from the evidence root. Run these commands from the evidence root.

```sh
python3 verify-lineage.py > verify-lineage.out
sh replay-terminals.sh 20 21 22 23
python3 verify-aggregate.py > aggregate.out
python3 compare-first.py
```
