from ast import literal_eval
from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads
from itertools import combinations

from exact_factors import DEN, read, groups, overlap, reduce_factors, prune, combine, quotient, proj

case_root = Path('inputs')
indices=(20,21,22,23)
expected_slots = {20:(130,(1,)),21:(130,(2,)),22:(132,(1,)),23:(132,(2,))}
parent = read('separator.zip','row-cap-physical-slice-dense-label-tuple0-1-reduced.pkl')
assert parent['conditioning'][-1] == (('R',0,0,2,0,1),1)
assert parent['label_partition']['index'] == 0
factors = parent['factors']
assert len(factors)==8
assert set(Counter(w for axes,_,_ in factors for w in axes).values())=={2}
assert parent['rejected_pair']==(0,1)
left,right=factors[:2]
roster=(case_root/'20/input.roster').read_bytes()
assert all((case_root/str(i)/'input.roster').read_bytes()==roster for i in indices)
cut_axes, table=literal_eval(roster.decode())
assert cut_axes == (('G',0,4,2),('J',1,4,2))
shared=overlap(left[0],right[0])
B=groups(right,shared)
join_key=proj(left[0],shared)
cut_key=proj(left[0],cut_axes)
spectrum=Counter()
for row in left[1]:
    multiplicity=len(B.get(join_key(row),()))
    if multiplicity:
        spectrum[cut_key(row)] += multiplicity
assert len(table)==len(spectrum)==48 and spectrum==dict(table)
assert sum(spectrum.values())==parent['matched']==6427904
order=sorted(spectrum,key=lambda k:(spectrum[k],k))
assert {i:order[i] for i in indices}==expected_slots
print('PASS complete 48-case roster',sum(spectrum.values()),'minimum',min(spectrum.values()),
      'maximum',max(spectrum.values()),'SHA256',sha256(roster).hexdigest(),flush=True)
def check_case(i):
    author=case_root/str(i)
    case=order[i]
    count=spectrum[case]
    assert count==106344
    fixed=dict(zip(cut_axes,case,strict=True))
    conditions=parent['conditioning']+list(fixed.items())

    def state(name):
        raw=(author/name).read_bytes()
        obj=loads(raw)
        rows=sum(len(r) for _,r,_ in obj['factors'])
        print('checkpoint',i,name,'SHA256',sha256(raw).hexdigest(),'rows',rows,flush=True)
        assert obj['conditioning']==conditions and obj['label_partition']==parent['label_partition']
        assert obj['physical_cut']==parent['physical_cut']
        assert prod(d for _,_,d in obj['factors'])==DEN
        return obj

    cut=state('input.pkl')
    for (axes,rows,d),(out,small,e) in zip(factors,cut['factors'],strict=True):
        assert d==e and out==tuple(w for w in axes if w not in fixed)
        recovered={}
        for row,z in small.items():
            lookup=dict(zip(out,row,strict=True)) | fixed
            recovered[tuple(lookup[w] for w in axes)]=z
        expected={row:z for row,z in rows.items() if all(row[j]==fixed[w] for j,w in enumerate(axes) if w in fixed)}
        assert recovered==expected
    cut_rows=sum(len(r) for _,r,_ in cut['factors'])
    assert (author/'plan.out').read_text().splitlines()[-1]==f'pilot {case!r} matched {count} stored rows {cut_rows}'
    print('PASS case',i,case,'cut rows and inverse lifts',cut_rows,flush=True)

    working=list(cut['factors'])
    reduce_factors(working)
    assert state('label-primary-reduced-frontier.pkl')['factors']==working
    prune(working)
    prune(working)
    last_products,last_rows = (2762240,382080) if i in (20,22) else (2196480,391680)
    stages=[(0,6,19440,19440),(0,3,1276960,92416),(0,1,last_products,last_rows)]
    products=0
    for a,b,expected_products,expected_rows in stages:
        if expected_products>50_000:
            assert quotient(working,a,b)+quotient(working,b,a)==0
        left,right=working[a],working[b]
        shared=overlap(left[0],right[0])
        outside=tuple(w for w in left[0]+right[0] if w not in shared)
        remaining=[f for j,f in enumerate(working) if j not in (a,b)]
        checks=[]
        if expected_products>250_000:
            for axes,rows,_ in remaining:
                edge=overlap(axes,outside)
                if edge:
                    checks.append((proj(outside,edge),set(map(proj(axes,edge),rows))))
        joined,n=combine(left,right,lambda row: all(key(row) in allowed for key,allowed in checks))
        assert (n,len(joined[1]))==(expected_products,expected_rows)
        products+=n
        working=remaining+[joined]
        prune(working,len(working)-1)
    cap=state('join-cap-dense-label-primary-reduced.pkl')
    assert cap['used_before']==products
    assert cap['refusal']=='no physical join admitted within per-run product limits'
    assert working==cap['factors']
    assert (author/'contract.out').read_text().splitlines()[-1]==f'open join cap {len(working)} completed products {products} frontier saved'
    forecasts=[]
    for left,right in combinations(working,2):
        shared=overlap(left[0],right[0])
        if not shared:
            continue
        ka,kb=proj(left[0],shared),proj(right[0],shared)
        right_counts=Counter(map(kb,right[1]))
        forecast=sum(right_counts[ka(row)] for row in left[1])
        forecasts.append(forecast)
    assert len(forecasts)>0 and min(forecasts)>8_000_000
    print('PASS case',i,'join-cap lineage, completed products',products,'minimum projected join',min(forecasts),flush=True)
    reduce_factors(working)
    assert state('label-rescue-reduced-frontier.pkl')['factors']==working
    print('PASS case',i,'terminal checkpoint fully reproduced from pinned cut',flush=True)

for i in indices:
    check_case(i)
