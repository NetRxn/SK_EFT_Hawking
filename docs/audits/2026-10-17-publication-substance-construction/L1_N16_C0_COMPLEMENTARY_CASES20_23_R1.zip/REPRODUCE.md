# Complementary tuple 0 cases 20–23

Restore the two Git source archives pinned by SOURCE_PINS.txt. Run sh
rehydrate.sh in clean scratch to recreate all 40 author inputs and verify
their hashes. These four original terms have distinct inputs. Each uses the
original 48-coordinate outer roster and its own verified join-cap and
rescue sequence. Deserialize only trusted checkpoint inputs.

The independent replay, aggregate and comparison scripts are described in
REVIEW.md. The agreement with corresponding first-child scalars was checked
after independent replay of the complementary child.

Compare preceding-twenty.tsv with twenty-term-retally.tsv in the committed
complementary cases 17–19 closure. Run python3 retally-twenty-four.py to
reproduce the exact 24/48 subtotal.
