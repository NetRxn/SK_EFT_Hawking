#!/bin/sh
set -eu
root=$(pwd)
unzip -p separator.zip row-cap-physical-slice-dense-label-tuple0-1-reduced.pkl.gz | gzip -d >parent.pkl
test "$(shasum -a 256 parent.pkl | cut -d' ' -f1)" = 9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d
for n in 20 21 22 23; do
    mkdir -p "$root/inputs/$n/checkpoint"
    cd "$root/inputs/$n"
    cp "$root/author/"*.py .
    cp "$root/author/checkpoint/quotient.py" checkpoint/
    python3 -u exact-multicut.py "$root/parent.pkl" input.pkl "$n" >plan.out
    python3 -u reduce-label-frontier.py input.pkl primary >reduce.out
    rc=0
    python3 -u contract-reduced-label.py primary >contract.out || rc=$?
    test "$rc" -eq 2
    python3 -u reduce-label-frontier.py join-cap-dense-label-primary-reduced.pkl rescue >rescue-reduce.out
    python3 -u contract-peer.py rescue >rescue-contract.out
done
cd "$root"
shasum -a 256 -c frozen-inputs.sha256
