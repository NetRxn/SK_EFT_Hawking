from ast import literal_eval
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from re import M, findall
from zipfile import ZipFile

from exact_factors import read

with ZipFile('first-child.zip') as archive:
    ledger = archive.read('partial-48.tsv')
    manifest = {name.removeprefix('./'):digest
                for digest,name in map(str.split,archive.read('manifest.sha256').decode().splitlines())}
    assert sha256(ledger).hexdigest() == manifest['partial-48.tsv']
    assert manifest['partial-48.tsv'] == '58cef3be160fa9a1178abd7fc646335b815b20f47fba71a849533d273813f0e6'
    rows = [line.split('\t') for line in ledger.decode().splitlines() if line.split('\t')[0].isdigit()]
    first = {int(i):(literal_eval(coord),Fraction(x),Fraction(y)) for i,coord,x,y,_ in rows}
    assert len(rows)==len(first)==48
selector=('R',0,0,2,0,1)
for child_id in (0,1):
    state=read('separator.zip',f'row-cap-physical-slice-dense-label-tuple0-{child_id}-reduced.pkl')
    assert state['conditioning'][-1]==(selector,child_id)
lineage=Path('verify-lineage.out').read_text()
coords={int(i):literal_eval(coord) for i,coord in findall(r'^PASS case (\d+) (.+) cut rows and inverse lifts \d+$',lineage,M)}
last=Path('aggregate.out').read_text()
records = {int(i):(Fraction(x),Fraction(y)) for i,x,y in findall(r'^PASS case (\d+) exact normalized (\S+) (\S+) ',last,M)}
assert set(coords)==set(records)=={20,21,22,23}
for i in sorted(records):
    assert (coords[i],*records[i])==first[i]
    print('PASS case',i,'scalar equals selector-0 term, independently regenerated and replayed from selector 1',*records[i])
