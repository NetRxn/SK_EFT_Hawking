from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from re import M, findall, search

indices=(20,21,22,23)
audit=Path('verify-lineage.out').read_text()
assert len(findall(r'^PASS case \d+ terminal checkpoint',audit,M))==4
terminals=[]
input_hashes=set()
terminal_hashes=set()
for index in indices:
    author=Path('inputs')/str(index)
    log = (Path('replays')/str(index)/'replay.out').read_text()
    found = search(r'^exact normalized real (\S+) imaginary (\S+) independent matched products (\d+) wall seconds (\S+)$',log,M)
    re, im, products, elapsed = found.groups()
    rnum, inum, den = map(int,search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',log,M).groups())
    norm = den*16*4**64
    totals = (Fraction(re),Fraction(im))
    assert totals == (Fraction(rnum,norm),Fraction(inum,norm))
    row = (author/'rescue-contract.out').read_text()
    expected = tuple(map(Fraction,search(r'^exact normalized real (\S+) imaginary (\S+) ',row,M).groups()))
    assert totals == expected
    hashes = []
    for name in ('input.pkl','label-rescue-reduced-frontier.pkl'):
        digest=sha256((author/name).read_bytes()).hexdigest()
        assert search(rf'^checkpoint {index} {name} SHA256 {digest} rows \d+$',audit,M)
        hashes.append(digest)
    input_hashes.add(hashes[0])
    terminal_hashes.add(hashes[1])
    peak=max(map(int,findall(r'^independent join \d+ \d+ products \d+ output rows (\d+) remaining \d+$',log,M)))
    terminals.append(totals)
    print('PASS case',index,'exact normalized',*totals,'products',products,'peak rows',peak,'seconds',elapsed,flush=True)
assert len(input_hashes)==len(terminal_hashes)==4
print('PASS distinct raw child and rescue SHA256 identities for all four cases')
print('PASS four-case subtotal',*(sum(group,Fraction(0)) for group in zip(*terminals,strict=True)))
