# R12 fixed-center quartic admission candidate

The R11 pair arithmetic is unchanged. Each half table stores the
exact S2²/2! mask and symbol coefficient. Each complementary center
split is visited once and both orders enter with factor 1/6. The
independent local reference builds original raw oriented S2 factors
and recurses by the unique factor owning the lowest available center
bit. It shares the outer grouping, which was already exercised in
the lower-power R10 controls.

The replay checks the SHA256 of the frozen 24-request R10 prefix and
reconstructs each exact target mask, symbol multiset, slot, branch
seed and attempt. It retries from the accepted prefix. The quartic
witness stage admits up to 12 distinct disjoint candidates per
direction, logs every zero witness with exact path count, and passes
only nonzero witnesses onward. Both mixed seed directions evaluate
the combined d0+d1 contact. They select different target requests,
while the contact observable stays the same.

The local ledger bounds simultaneous live dynamically projected
coefficient rows. It counts later paths while outer signed groups
are assembled and includes projections and the current trace.
The witness runs before outer and local maps exist. Raw independent
multiplication reserves retained outer and production rows, raw
vertex and projection rows, and the prospective operands and
temporary products. The oracle 16,384-row bound counts raw canonical
product and projection together. The local 8,192-row bound counts
the retained projected row upper bound with the live maps. Both
apply to the same stages with different scopes. These are logical
record reservations, not bounds on interpreter RSS. Setup's frozen
source factors are inputs to these scratch counters. Each outer
fanout update, pair bucket traversal and final signed update is
charged prospectively against the 20-million-operation limit.
The signed-output ledger carries the 652 already accepted R10 rows,
leaving 1,396 for these three requests.

The bounded controls exercise exact independent ordered arithmetic,
the original-source seed and witness search, and low-cap refusals
for overlapping outer, oracle and witness maps, outer fanout and
cumulative output. Original quartic coefficients and their resource
fit remain unexecuted. The original entrypoint creates an exclusive
JSONL receipt, logs witness rejections and accepted target fingerprints
to stderr, and retains completed rows if a later request refuses.
Execute the original entrypoint only after fresh independent admission.
