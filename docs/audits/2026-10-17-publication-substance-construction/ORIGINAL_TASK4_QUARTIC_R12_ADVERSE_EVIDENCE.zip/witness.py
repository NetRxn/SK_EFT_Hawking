from pathlib import Path
from hashlib import sha256
from collections import Counter
import importlib.util, json, sys
path=Path('/tmp/publication-task4-continuation-quartic-r12.py')
spec=importlib.util.spec_from_file_location('r12_independent', path)
m=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)
frozen=Path('/tmp/publication-task4-continuation-powers-r10.progress.jsonl').read_bytes()
prior=[json.loads(line) for line in frozen.splitlines()]
assert len(prior)==24 and sum(len(row['table']) for row in prior)==652
assert sha256(frozen).hexdigest()==m.PREFIX_DIGEST
work=m.r5.Work(cap=2_500_000)
reg,(_,_,w),inputs,raw,d0,d1=m.r10.setup(work)
rejected=[]
generated=m.seeded_targets(inputs,d0,d1,work,rejected.append)
result=[]
prior_count=0
for target,direction,seed,attempt,value,paths,peak in generated:
    cache=generated.gi_frame.f_locals['candidates'].gi_frame.f_locals['cache']
    sizes=Counter(len(rows) for rows in cache.values())
    cache_rows=sum(k*v for k,v in sizes.items())
    assert value and paths>0
    print('accepted seed',target[2],direction,attempt,str(value),paths,peak,'seed cache',cache_rows,dict(sizes),'work',work.used,flush=True)
    result.append(dict(target=m.r5.fingerprint(target),direction=direction,seed=seed,attempt=attempt,
                       coefficient=str(value),paths=paths,peak=peak))
    for row in rejected[prior_count:]:
        print('zero witness',row['direction'],row['attempt'],row['witness_paths'],row['witness_peak'],flush=True)
    prior_count=len(rejected)
assert len(result)==3
known=json.loads(Path('/tmp/publication-task4-continuation-quartic-r12.witness-control.json').read_text())
print('known receipt row fields', [sorted(r) for r in known['rows']],flush=True)
print('record',json.dumps(dict(result=result,rejected=rejected,work=work.used),default=str),flush=True)
