"""Actual source seed and witness replay only. No quartic coefficient evaluator."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import sys
path = Path(__file__).with_name("publication-task4-continuation-quartic-r12.py")
spec = spec_from_file_location("r12_witness_control", path)
m = module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)
work = m.r5.Work(cap=1_500_000)
reg, centers, inputs, raw, d0, d1 = m.r10.setup(work)
rejected = []
rows = []
for target, direction, seed, attempt, value, paths, peak in m.seeded_targets(inputs, d0, d1, work, rejected.append):
    if not rows:
        try:
            m.witness(target, seed, inputs, m.r5.Work(cap=10_000), 0)
        except RuntimeError as exc:
            assert str(exc) == "quartic local cap: prospective 1, cap 0"
            witness_refusal = str(exc)
        else:
            raise AssertionError("witness projection bypassed local admission")
    rows.append(dict(target=m.r5.fingerprint(target),direction=direction,seed=seed,
                     attempt=attempt,witness=str(value),paths=paths,peak=peak))
assert len(rows)==3 and [row["direction"] for row in rows]==[0,0,1]
assert any(row["target"]["slot"]==m.SLOTS[1] for row in rejected)
assert rows[0]["witness"] == str(m.Q(m.Fraction(3,32768)))
print(json.dumps(dict(rows=rows,rejected=rejected,work=work.used,cap=work.cap,
                      prefix_digest=m.PREFIX_DIGEST,prefix_records=m.PREFIX_RECORDS,
                      witness_refusal=witness_refusal),indent=2))
