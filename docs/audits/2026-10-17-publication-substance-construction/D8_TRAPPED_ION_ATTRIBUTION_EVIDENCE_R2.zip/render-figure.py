from pathlib import Path
from PIL import Image, ImageChops
import importlib.util, json, sys, hashlib

m,p=map(Path,sys.argv[1:])
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.fig_d8_alphabet_dimension_map()
a=load(m/"src/core/visualizations.py","src.core.visualizations_before")
b=load(p/"src/core/visualizations.py","src.core.visualizations_after")
x,y=(json.loads(f.to_json()) for f in (a,b))
assert [i for i,(u,v) in enumerate(zip(x["data"],y["data"],strict=True)) if u!=v]==[3]
assert [i for i,(u,v) in enumerate(zip(x["layout"]["annotations"],y["layout"]["annotations"],strict=True)) if u!=v]==[3]
x["data"][3]["hovertemplate"]=y["data"][3]["hovertemplate"]
x["layout"]["annotations"][3]["text"]=y["layout"]["annotations"][3]["text"]
assert x==y
f=Path("papers/D8/figures/d8_fig1_alphabet_dimension_map.png")
(p/f).parent.mkdir(exist_ok=True)
for fig,path in ((a,p/"baseline.png"),(b,p/f)):
    w,h=fig.layout.width,fig.layout.height
    fig.write_image(str(path),format="png",width=w,height=h,scale=2 if w>=1000 else 3)
old=Image.open(p/"baseline.png").convert("RGB")
tracked=Image.open(m/f).convert("RGB")
new=Image.open(p/f).convert("RGB")
assert old.size==tracked.size==new.size==(2160,820)
assert ImageChops.difference(old,tracked).getbbox() is None
box=ImageChops.difference(old,new).getbbox()
assert box is not None and box[0]>1000 and box[2]<2160 and box[3]-box[1]<65,box
report={"dimensions":new.size,"pixel_delta_box":box,"tracked_matches_baseline":True,
        "modified_plotly_trace":3,"modified_annotation":3,
        "sha256":hashlib.sha256((p/f).read_bytes()).hexdigest()}
(p/"figure-scope.json").write_text(json.dumps(report,indent=2)+"\n")
print(report)
