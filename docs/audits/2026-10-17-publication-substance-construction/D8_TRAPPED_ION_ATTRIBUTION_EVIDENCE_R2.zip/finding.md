---
bundle_target: D8
kind: targeted
---

# D8 trapped-ion universality attribution

### 1.1 — The trapped-ion paragraph reverses the entangling criterion and misstates the formal proof route

- **severity:** major
- **lane:** prose
- **Gate:** NarrativeGrounding
- **Location:** `papers/D8/paper_draft.tex`, trapped-ion paragraph, alphabet table and coverage figure; `papers/D8/bundle_metadata.json`; `src/core/citations.py`
- **Observed:** At delivery baseline 0192841b, the trapped-ion paragraph calls a gate that entangles a product state primitive. The paragraph, table, apex attribution and citation registry identify the Brylinski criterion as the formal density proof.
- **Evidence:** The held Brylinski author PDF arXiv:quant-ph/0108062v1, p. 2, defines primitive gates by preservation of decomposability and states the equivalence with imprimitivity in Theorem 1.3. The actual Lean theorem uses `trappedIonSU4ClosureDenseWitness`, with fifteen spanning tensor-Pauli tangents and their flows on the positive even grid.
- **Expected:** Attribute the external universality criterion precisely and describe the actual formal witness at its existing strength.
- **Fix:** Correct the paragraph, table, figure producer and PNG, apex note and registry entry, record the versioned held PDF, and update the current per-anchor readback.
- **Verify:** `grep -Fq 'gate \emph{imprimitive}' papers/D8/paper_draft.tex && grep -Fq 'Tensor-Pauli closure flows' papers/D8/paper_draft.tex && grep -Fq 'density via the span and closure flows of fifteen tensor-Pauli tangents' papers/D8/bundle_metadata.json && grep -Fq 'Tensor-Pauli closure flows' src/core/visualizations.py`
