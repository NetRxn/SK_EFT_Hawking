# D8 trapped-ion attribution independent review R1

**HOLD.** The exact five-path patch
`d3ee7895d905089684e839b0d6eb3d50b55e361ff2221a4619dd0fe3854929f0`
corrects the manuscript paragraph, Table II and the tracked attribution
records. Figure 2 still presents the Brylinski criterion as the
alphabet-specific density input. This visible contradiction blocks
closure of the proof-attribution finding.

## Source and Lean correspondence

I read the held arXiv:quant-ph/0108062v1 author PDF, p. 2. Theorem 1.3
uses imprimitivity for universality with all single-qudit gates, and
the adjacent definition says primitive gates preserve decomposable
tensors. The new external-context wording correctly applies the
imprimitive term to the grid entangler. The held PDF hash
`d646d64aabe5fe70762cfae67cd2c371a753df96e3683ac8bf241293a3b13cd3`
and 166,177 bytes match the exact proposed source record.

The existing trapped-ion alphabet has four local H/T gates and
MS(kπ/N) for 0 ≤ k < 2N. For positive even N, k=N/2 gives MS(π/2).
The actual matrix expansion maps |00⟩ to
(|00⟩−i|11⟩)/√2, so both Schmidt coefficients are nonzero.
The formal witness follows a separate construction.
`trappedIonSU4ClosureDenseWitness` has fifteen tensor-Pauli tangents,
uses `suFourTangent_spans` and `suFourTangent_flow`, and preserves
N>0 and 2∣N. The six local directions come from the per-ion
containment, and conjugation using the grid entangler and per-ion
Cliffords gives the nine entangling flows. The exact
`trappedIonSU4_solovayKitaev_headline_unconditional` theorem consumes
that witness. The proposed paragraph and apex attribution match.

## Exact replay and rendered blocker

I archived base `0192841b280d750579371585f5442a29d7aa3c2c` and
applied the patch in scratch. Only the exact five expected paths
change. All nineteen cited keys, bibliography, figure links and
labels remain the same. The citation registry changes only Brylinski
source path and notes. The sidecar changes only its Brylinski entry
and generation timestamp. Only the trapped-ion apex claim changes
in metadata, leaving writer-owned fields intact. The current
Brylinski row alone changes in the audit roster, and the historical
verdict remains byte-identical.

The declared Verify exited 1 on the baseline and 0 on the candidate.
Its three string checks do not test the rendered figure. The supplied
13-page author PDF corresponds to the independently applied candidate
TeX bytes. Its page 5 visibly shows both corrected passages and the
new Table II row, with no clipping there. On page 6 the included
`papers/D8/figures/d8_fig1_alphabet_dimension_map.png` visibly labels
the trapped-ion row “Brylinski entangling criterion.” The caption
says that the annotations name the actual alphabet-specific density
inputs. The generator still emits the same old label at
`src/core/visualizations.py:14469`. This raster annotation is absent
from the PDF text extraction.

Update the exact producer annotation and regenerate the tracked PNG,
then inspect the recompiled Figure 2 alongside Table II and the
paragraph. Preserve the original rendered adverse control. The R1
five-path scope and declared Verify have no canonical closure
acceptance because they miss the visible contradiction.

First and final continuity checks matched. Independent comparator,
outputs, source text and rendered page images are in the scratch
directory recorded at `/tmp/d8-brylinski-independent-r1.path`. No
repository, source cache, ledger, Lean slot or remote writes were made.
