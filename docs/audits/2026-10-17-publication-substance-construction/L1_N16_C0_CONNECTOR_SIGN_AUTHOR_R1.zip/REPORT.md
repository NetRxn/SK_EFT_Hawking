# Original pure-EHC connector sewing and its sign obstruction

The primary continuity packet
`publication-l1-n16-c0-global-sign-author-r1.json` checked fresh at
`27012c18fa374e8341e124b510abbedeedb18d29`. This scratch calculation
keeps the periodic closed action, all odd generators, the original
Berezin order and all independent anchored Spin(4) Haar variables.
The earlier positive value for the selected occupation m_(x,23)=2
does not enter the proof of the cut criterion.

The full c0 has an exact two-connector factorization. The resulting
signed sewing is a difference of Hilbert norm squares. The actual
original kernel has a nonzero negative projection in a nonvacuum
degree pair, as shown by a canonical-source Haar control below.
This disproves two simple norm shortcuts. It leaves the numerical
value and sign of the full c0 open.

## 1. Exact cut of the entire original action

Cut along world axis 0, retaining A at bit 0 and B at bit 1.
Each layer has 64 odd generators and 24 spatial links. There are
two distinct sets of eight temporal anchors, V_A based in A and
V_B based in B. Use A and B also for the odd variables and spatial
links on the corresponding layer. The inherited temporal cut uses
this world label. The pure partition coefficient is unchanged under
a world permutation since the 32 factors cancel its orientation sign.

For one temporal edge write x in A, y=x+e0 in B, U=V_A(x)
and V=V_B(y). Define the directed contributions before the quarter by

```
F_(A->B,x)^C(U) = bar_x gamma_C U† psi_y - bar_y U gamma_C psi_x
F_(A->B,y)^C(U) = bar_x U† gamma_C psi_y - bar_y gamma_C U psi_x.
```

The reversed direction uses the same definitions with x,y swapped
and V in place of U. In particular it gives the negative of the
displayed pair evaluated at V†, with the endpoint labels retained.
Adding the two directed contributions at either endpoint and
multiplying by 1/4 gives the exact original temporal coframe.
No connector is identified with its inverse or with the other
connector.

Group the 24 ordered world placements at each center by their
sorted curvature plane, using the original inverse-word
antisymmetrization and world sign. This gives 96 rooted planes
across the carrier. Exactly 48 have temporal curvature, and
exactly 48 instead have a temporal coframe.

Define K(A,B;V_A) by the following assignment:

- Include all temporal-curvature terms centered in A. In the
  closed word for plane (0,i), the two temporal links are based
  at x and x+e_i in A, with one spatial link from each layer.
  Both coframes are spatial and centered in A. The temporal
  curvature terms centered in B belong to the other connector.
- For every spatial-curvature term in both A and B, replace its
  one temporal coframe by its directed contribution from V_A,
  including the quarter. Its spatial curvature and its other
  coframe are left at their actual center in the actual layer.

The other polynomial is K(B,A;V_B), obtained by periodic
one-step translation with both arguments and connector anchors
exchanged. The original pure-EHC action is exactly

```
S2 = K(A,B;V_A) + K(B,A;V_B).
```

Both terms are Grassmann-even, so the finite exterior exponential
factors. Integrate the two connector sets with their own normalized
product Haar. Let W(A,B;g)=E_{V_A} exp(g K(A,B;V_A)). Then

```
c0 = I_top E_{spatial A,B} [W(A,B;1) W(B,A;1)].
```

No integration over the 48 spatial anchors is implicit in W.
The product on the right uses the original single copy of the
spatial variables on each side. Its top coefficient has exactly
32 action factors, so taking g=1 is harmless. In homogeneous
terms, its coefficients use 1/n! and 1/(32−n)!, exactly the
binomial expansion of S2^32/32!.

Each connector uses the full Spin(4) Haar for all eight anchors.
Multiplying all links of that connector by the common central
element −I4 preserves Haar. A temporal-curvature factor has two
connector occurrences, while a temporal-coframe factor has one.
Thus only even counts of temporal-coframe factors survive.
Each such factor has odd degree in each layer, and a
temporal-curvature factor has all four odd generators in its own
layer. Consequently the surviving W has even exterior degree
separately in A and B. The stronger independent anchor and
chirality moment constraints remain required.

`cut_source.py` tests the decomposition against the canonical
24-order action at asymmetric exact quaternion values on a
12-generator restriction. Each of the four connector and coupling
pieces is nonzero. Their sum agrees with all 42 surviving raw
quartic coefficients. The structural cut audit covers all 96
grouped planes. The restriction is only an exact coefficient
control and does not set any physical links or odd generators
to particular values in the full coefficient.

## 2. Exact signed sewing criterion

Use the ordinary coefficient Hilbert space of exterior forms,
with the coefficient functions integrated in product Haar on the
48 remaining spatial links. The Hilbert inner product is
conjugate-linear in its first entry. Let tau swap both layers,
including their spatial arguments. For two even forms set

```
B(f,h) = I_top E_{spatial} [f tau(h)].
```

Let I,J be source-order masks in A and B. If w_(I,J) denotes
the corresponding coefficient, the exterior-complement and
spatial-swap operator P is

```
(Pw)_(I,J)(U_A,U_B) =
  eps(I,bar I) eps(J,bar J) w_(bar J,bar I)(U_B,U_A).
```

The eps signs are those of the ordered local concatenations
against the 64-generator layer tops. To see the full sign, the
partner after swapping has an A mask bar I and B mask bar J.
In expanding the swapped partner and regrouping both A masks
first, the crossing exponent is |bar I|(|J|+|bar J|), which is
even. Only the two displayed eps factors remain. The full
layer swap preserves the original top orientation.

Thus B(f,h)=<conj(f), P h>, where conj alone conjugates the
coefficients. P is a real signed permutation with a
measure-preserving link pullback. It is a self-adjoint
involution on the even sector. For example P twice changes the
two local eps factors by (-1)^(|I|+|J|)=+1. Let R be the
linear signed action on exterior words of exchanging bar with
psi and reversing the order, holding coefficients fixed. The
antilinear sharp is R followed by coefficient conjugation.
R fixes the original top and commutes with the layer swap.
On even forms its product reversal preserves B, since even
forms commute. Therefore R is an orthogonal involution,
R^T P R=P and R commutes with P.

Each original spatial coframe and each of the two directed
temporal pieces changes sign under sharp. The original
antisymmetric curvature traces are real on the compact group.
All terms of K contain two even coframe pieces, so K and W
are sharp-real. Hence the exact global criterion is

```
J = R P
Pi_plus  = (1 + J)/2
Pi_minus = (1 - J)/2
c0 = <W, J W> = ||Pi_plus W||^2 - ||Pi_minus W||^2.
```

These are coefficient norms with respect to the remaining
Haar measure and do not introduce a physical state or adjoint.
Both the sewing sign and the difference follow from the
original cut and the inherited top.

Write w_n for the connector-Haar image of K^n/n!. The
involution J sends total odd degree 4n to 128−4n. The
corresponding degree-paired formula is

```
c0 = 2 sum_(n=0..15) Re <w_n, J w_(32-n)>
     + ||Pi_plus w_16||^2 - ||Pi_minus w_16||^2.
```

The sign of the full sum requires these signed quantities or
a comparison of their complete positive and negative norms.
A positive fixed-occupation contribution supplies neither
comparison. The exact mask tests in `exterior_sewing.py`
check all even masks of two small cuts and a deterministic
sample of 2,487 full 128-generator even masks. They check
P squared, R squared, their commutation, and the complete
wedge sign against the formula above. The identities themselves
follow from the algebra, independently of sampling.

## 3. Adverse controls for the natural norm shortcuts

### Ordinary swap or conjugation of the connector kernel

Keep four bars at x in A, two left psis at x+e2 in A and two
right psis at x+e3 in A, with every other odd variable set to
zero for this coefficient test. A nonzero contribution must
have its two coframe edges connecting distinct retained psi
sites to the barred center x. This forces center x and world
coframe plane 2,3. The temporal-curvature plane 0,1 belongs
to V_A. All temporal-coframe terms vanish on the restriction.
K(B,A;V_B) also vanishes, since its temporal-curvature
coframes are centered in the odd-empty B.

The degree-eight coefficient of W(A,B;1) on the restriction,
after integrating the remaining spatial Haar, is exactly 3/4.
The canonical source calculation uses both coframe anchors
on each of the two edges, the joint curvature second moment,
the signed ordered top, and 1/2!. The degree-eight
coefficient of W(B,A;1) is zero. The latter has only its
constant on this restriction. The layer swap after connector
Haar therefore cannot be replaced by ordinary coefficient
conjugation, which does not change the layer support.

### Failure of the positive sewing eigenspace away from vacuum

An explicit spatial link point makes the adverse sewing
projection visible in degree eight, without using the vacuum.
Set all spatial links to +I4 except two anchors in A.
On the reverse anchor of each of the edges x→x+e2 and
x→x+e3, use −I4. These are legitimate independent compact
group values. This is a coefficient-function test, while the
outer pairing still uses Haar.

Every spatial holonomy is central at this point, so every
antisymmetric spatial curvature vanishes. The only nonzero
spatial coframe edges are the two designated edges in A.
The sole center with two different nonzero spatial coframe
directions is x. Thus K(A,B;V_A) contains only the temporal
curvature at x in plane 0,1 with its two spatial coframes.
Each factor uses two odd generators at x, so K^5=0.
K(B,A;V_B) vanishes identically at this point, since all B
spatial coframes vanish.

At x the two spatial coframe pairs in the preceding odd
restriction have coefficient −1/2 per equal internal pair
on their respective masks. The source calculation derives
this from the actual ±I4 anchored coframes. The curvature
Haar square uses the two independent forward temporal
anchors, with the other two plaquette links identity. Its
Frobenius sum is 24. The original degree-eight coefficient
of W(A,B;1) at this spatial point is therefore

```
(1/2!) * (-1/2)^2 * 24 = 3.
```

The direct calculation in `one_side.py` checks this exact
value using the source-ordered masks. It also reproduces
the fully integrated 3/4 control above. When the spatial
arguments are swapped, K(A,B;V_A) vanishes at the swapped
point for the same support reason as K(B,A;V_B) at the
original point. In particular the degree-120 coefficient
w_30 there is zero. The coefficient of Pi_minus W in the
selected degree-eight mask at the original point is
therefore 3/2. The same holds for Pi_plus W in that mask.
These polynomial coefficient functions are continuous and
normalized Haar has full support. The degree-pair
(8,120) negative norm component is strictly positive in the
actual kernel. This excludes W lying in the positive
eigenspace of the natural signed sewing involution. It
does not imply a negative contribution from any complete
32-factor occupation or determine the full sign.

The actual geometric reflection discussed in the earlier
source-adjoint evidence is distinct from tau and also
changes the temporal curvature placement. No new reflection,
norm, or pairing is introduced to replace either operation.

## 4. Scope, preflight and reproduction

The exact cut reduces a possible full signed computation to
homogeneous connector kernels with common spatial-link
arguments. The natural norm shortcut is ruled out by the
controls above. A dense coefficient-vector route would need,
even in the sole middle-degree sector with both layer degrees
even, an ambient roster of

```
[binom(128,64) + binom(64,32)] / 2
```

masks. The script verifies this both from the parity binomial
formula and by direct degree-pair summation. This is an exact
ambient dimension, not a lower bound on nonzero source
coefficients. The declared dense schedule caps at one million
masks and refuses before allocation. The projected exact
source probes use at most 12 odd generators and the independent
mask controls use at most 65,536 enumerated masks per small
cut plus 5,000 sampled full masks. Timings and RSS are in
the receipts. No full sparse connector expansion or global
norm difference was attempted. Those resource and sign
questions remain open.

Use the exact primary checkout on PYTHONPATH and its existing
venv interpreter with PYTHONDONTWRITEBYTECODE=1 for
`cut_source.py` and `one_side.py`. Run
`exterior_sewing.py` with Python. The measured calls use
`measure.py`. All files and receipts are scratch only.
Independent mathematical and original-source review remain
for the lead. No tracked source, notebook, controller or
Lean slot was modified.
