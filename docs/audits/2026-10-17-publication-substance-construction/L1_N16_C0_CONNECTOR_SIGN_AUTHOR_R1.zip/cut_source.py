from fractions import Fraction as F
from itertools import combinations, product
from collections import Counter
from src.core.formulas import original_action_factors, original_coframe_blocks, original_plaquette, original_spin4_link
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, QComplex, assemble_coframe, epsilon, matrix_dagger, matrix_multiply,
)

reg = OriginalRegulator(temporal_axis=0)
x = (0,0,0,0)
y = reg.step(x,0)[0]
centers = (x,y)
kept = tuple(g for g in reg.generator_order if
             (g[0] in centers and (g[2] < 2 if g[1] == "bar" else g[2] >= 2)) or
             (g[1] == "psi" and (g[0],g[2]) in
              {(reg.step(c,2)[0],2) for c in centers} |
              {(reg.step(c,3)[0],3) for c in centers}))
pos = {g:i for i,g in enumerate(kept)}
assert len(kept) == 12

def permitted(c,a):
    z = reg.step(c,a)[0]
    return any((b[0],p[0]) in ((c,z),(z,c)) and b[1] == "bar" and p[1] == "psi"
               and (b[2] < 2) != (p[2] < 2) for b,p in product(kept,repeat=2))
assert tuple(c for c in reg.sites if sum(permitted(c,a) for a in range(4)) >= 2) == centers

units = ((1,0,0,0), (0,1,0,0), (0,0,1,0), (0,0,0,1),
         (F(1,2),)*4, (F(3,5),0,F(4,5),0), (F(2,3),F(1,3),F(2,3),0))
links = {key:original_spin4_link(units[(j+2)%7],units[(3*j+1)%7])
         for j,key in enumerate(reg.link_order)}
gamma = reg.gamma
basis = {(a,b):matrix_multiply(matrix_multiply(gamma[a],gamma[b]),reg.gamma5)
         for a,b in product(range(4),repeat=2)}
def coeff(p):
    if not p:
        return QComplex()
    (key,value), = p.terms
    assert not key
    return value

def add(out, mask, value):
    if value:
        out[mask] = out.get(mask,QComplex()) + value

def insert_bilinear(out,c,z,matrix,scale):
    for i,j in product(range(4),repeat=2):
        a,b = (c,"bar",i),(z,"psi",j)
        if a in pos and b in pos:
            add(out,(1<<pos[a])|(1<<pos[b]),coeff(matrix[i][j])*scale*(-1 if pos[a]>pos[b] else 1))

def projected_original(c,a,A):
    out = {}
    M = assemble_coframe(reg,original_coframe_blocks(reg,(c,a,A),links))
    for (i,j), v in M.entries:
        key = (reg.sites[i//4],"bar",i%4),(reg.sites[j//4],"psi",j%4)
        if all(g in pos for g in key):
            u,w = map(pos.get,key)
            add(out,(1<<u)|(1<<w),coeff(v)*(-1 if u>w else 1))
    return out

def temporal_piece(c,A,t):
    # Forward connector based at t. These are the literal directed
    # F_base and F_target expressions with factor 1/4.
    b = c if c[0] == t else reg.step(c,0)[0]
    z = reg.step(b,0)[0]
    U = links[b,0]
    out = {}
    if c == b:
        insert_bilinear(out,b,z,matrix_multiply(gamma[A],matrix_dagger(U)),F(1,4))
        insert_bilinear(out,z,b,matrix_multiply(U,gamma[A]),F(-1,4))
    else:
        insert_bilinear(out,b,z,matrix_multiply(matrix_dagger(U),gamma[A]),F(1,4))
        insert_bilinear(out,z,b,matrix_multiply(gamma[A],U),F(-1,4))
    return out

def clean(out): return {k:v for k,v in out.items() if v}
def multiply(out,left,right,scalar):
    if not scalar:
        return
    for (a,u),(b,v) in product(left.items(),right.items()):
        if a & b:
            continue
        p = sum((b & ((1 << i)-1)).bit_count() for i in range(len(kept)) if a & (1<<i))
        add(out,a|b,u*v*scalar*(-1)**p)

frames = {(c,a,A):projected_original(c,a,A)
          for c,a,A in product(centers,range(4),range(4))}
parts = {(c,A,t):temporal_piece(c,A,t)
         for c,A,t in product(centers,range(4),range(2))}
for c,A in product(centers,range(4)):
    total = parts[c,A,0].copy()
    for m,v in parts[c,A,1].items():
        add(total,m,v)
    assert clean(total) == clean(frames[c,0,A])
raw = {}
for c in centers:
    for f in original_action_factors(reg,c,links):
        if f.t_degree == 2:
            assert len(f.components) == 2
            left,right = map(frames.get,f.components)
            multiply(raw,left,right,coeff(f.coefficient))

cut = {(t,mode):{} for t in range(2) for mode in ("T","F")}
anchors = Counter()
for c in reg.sites:
    for k,l in combinations(range(4),2):
        m,n = sorted(set(range(4))-{k,l})
        # Full geometric audit includes centers pruned only from the
        # projected coefficient comparison, not the source roster.
        if k == 0:
            temporal_anchors = (c, reg.step(c,l)[0])
            assert all(a[0] == c[0] for a in temporal_anchors)
            anchors["temporal curvature"] += 1
        else:
            assert m == 0
            anchors["temporal coframe"] += 1
        if c not in centers or not permitted(c,m) or not permitted(c,n):
            continue
        H = original_plaquette(reg,c,k,l,links)
        Hi = original_plaquette(reg,c,l,k,links)
        for A,B in product(range(4),repeat=2):
            p = sum(((H[i][j]-Hi[i][j])*basis[A,B][j][i]
                     for i,j in product(range(4),repeat=2)),Polynomial())
            scalar = coeff(p)*F(epsilon((k,l,m,n)),2)
            if k == 0:
                multiply(cut[c[0],"F"],frames[c,m,A],frames[c,n,B],scalar)
            else:
                for t in range(2):
                    multiply(cut[t,"T"],parts[c,A,t],frames[c,n,B],scalar)
total = {}
for (t,mode), data in cut.items():
    print("projected cut piece",t,mode,"nonzero masks",len(clean(data)))
    assert clean(data)
    for m,v in data.items():
        add(total,m,v)
assert clean(total) == clean(raw)
print("original grouped planes across both coupling types",dict(anchors))
print("matching exact canonical raw quartic masks",len(clean(raw)))
