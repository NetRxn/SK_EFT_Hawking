from itertools import combinations
from random import Random

def sign(a, b):
    return (-1) ** sum((b & ((1 << i) - 1)).bit_count()
                       for i in range(a.bit_length()) if a & (1 << i))

def swap(m, n):
    a, b = m & ((1 << n) - 1), m >> n
    return (a << n) | b, (-1) ** (a.bit_count() * b.bit_count())

def sharp(m, n):
    # Local source order bL1,bL2,pL1,pL2,bR1,bR2,pR1,pR2.
    src = [i for i in range(2*n) if m & (1 << i)]
    out = [i ^ 2 for i in reversed(src)]
    return sum(1 << i for i in out), (-1) ** sum(a > b for a,b in combinations(out,2))

def sewing(m,n):
    top = (1 << (2*n)) - 1
    k, s = swap(top ^ m, n)
    return k, s * sign(m, top ^ m)

def compose(f,g,m,n):
    i,s = g(m,n)
    j,t = f(i,n)
    return j,s*t

rng = Random(682)
for n in (4,8,64):
    top = (1 << (2*n))-1
    masks = range(1 << (2*n)) if n < 64 else [0,top] + [rng.getrandbits(2*n) for _ in range(5000)]
    checked = 0
    for m in masks:
        if m.bit_count() % 2:
            continue
        p,s = sewing(m,n)
        assert compose(sewing,sewing,m,n) == (m,1)
        assert compose(sharp,sharp,m,n) == (m,1)
        assert compose(sewing,sharp,m,n) == compose(sharp,sewing,m,n)
        p_swap, s_swap = swap(p,n)
        assert m & p_swap == 0 and m | p_swap == top
        assert s == s_swap * sign(m,p_swap)
        mask = (1 << n)-1
        a,b = m & mask,m >> n
        assert p == ((b ^ mask) | ((a ^ mask) << n))
        assert s == sign(a,a ^ mask) * sign(b,b ^ mask)
        checked += 1
    assert compose(sharp,sewing,0,n) == (top,1)
    assert compose(sharp,sewing,top,n) == (0,1)
    print("layer generators", n, "checked even masks", checked,
          "vacuum and top swapped by sharp-sewing involution")
from math import comb
middle = (comb(128,64)+comb(64,32))//2
assert middle == sum(comb(64,a)**2 for a in range(0,65,2))
print("ambient middle-degree even-even mask count", middle)
assert middle > 1000000
print("REFUSED explicit dense ambient mask roster before allocation")
