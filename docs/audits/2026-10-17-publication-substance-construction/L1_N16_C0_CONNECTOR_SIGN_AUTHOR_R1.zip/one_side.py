from fractions import Fraction as F
from itertools import product
import sys
from src.core.formulas import (
    original_coframe_blocks, original_plaquette, original_quaternion_haar_moment,
    original_spin4_link, original_action_factors,
)
from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, QComplex, Symbol, assemble_coframe, epsilon,
    matrix_multiply,
)

same_chirality = len(sys.argv) == 2 and sys.argv[1] == "same-chirality"
reg = OriginalRegulator(temporal_axis=0)
x = reg.sites[0]
mu, nu, k, ell = 2, 3, 0, 1
y = reg.step(x, mu)[0]
z = reg.step(x, nu)[0]
kept = tuple(g for g in reg.generator_order if (
    g[0] == x and g[1] == "bar"
    or g[0] == y and g[1] == "psi" and g[2] < 2
    or g[0] == z and g[1] == "psi" and (g[2] < 2) == same_chirality
))
position = {g: i for i, g in enumerate(kept)}
assert len(kept) == 8
eligible = []
for center in reg.sites:
    active_axes = {
        axis for axis in range(4)
        if any(
            (a[0], b[0]) in ((center, reg.step(center, axis)[0]),
                            (reg.step(center, axis)[0], center))
            and a[1] == "bar" and b[1] == "psi" and (a[2] < 2) != (b[2] < 2)
            for a, b in product(kept, repeat=2)
        )
    }
    if len(active_axes) >= 2:
        eligible.append((center, active_axes))
assert eligible == [(x, {mu, nu})]

def sign(mask_a, mask_b):
    return (-1) ** sum((mask_b & ((1 << i) - 1)).bit_count()
                       for i in range(8) if mask_a & (1 << i))

def coframe(axis, a, links=None):
    matrix = assemble_coframe(reg, original_coframe_blocks(reg, (x, axis, a), links))
    output = {}
    for (i, j), coefficient in matrix.entries:
        bar = (reg.sites[i // 4], "bar", i % 4)
        psi = (reg.sites[j // 4], "psi", j % 4)
        if bar in position and psi in position:
            mask_a, mask_b = 1 << position[bar], 1 << position[psi]
            output[mask_a | mask_b] = coefficient * sign(mask_a, mask_b)
    return output

def trace(left, right):
    return sum((left[i][j] * right[j][i] for i in range(4)
                for j in range(4)), Polynomial())

gamma = reg.gamma
traces = {(a, b): matrix_multiply(matrix_multiply(gamma[a], gamma[b]), reg.gamma5)
          for a, b in product(range(4), repeat=2)}
anchors = [(x, k), (reg.step(x, k)[0], ell), (reg.step(x, ell)[0], k), (x, ell)]
links = {anchor: original_spin4_link(*[
    tuple(Polynomial.variable(Symbol("q", (*anchor, chirality, i))) for i in range(4))
    for chirality in ("L", "R")
]) for anchor in anchors}
word = original_plaquette(reg, x, k, ell, links)
inverse_word = original_plaquette(reg, x, ell, k, links)
curvature = {(a, b): (trace(word, traces[a, b]) - trace(inverse_word, traces[a, b]))
                     * F(1, 2) for a, b in traces}

def exact_multilinear_pair(first, second, group_count):
    terms = dict(second.terms)
    for polynomial in (first, second):
        for key, _ in polynomial.terms:
            assert len(key) == len({s.index[:-1] for s in key}) == group_count
    factor = original_quaternion_haar_moment((2, 0, 0, 0)) ** group_count
    return sum((val * terms[key] for key, val in first.terms if key in terms), QComplex()) * factor

def coframe_pair(left, right):
    output = {}
    for (mask_a, a), (mask_b, b) in product(left.items(), right.items()):
        if mask_a & mask_b:
            continue
        mask = mask_a | mask_b
        val = exact_multilinear_pair(a, b, 1) * sign(mask_a, mask_b)
        output[mask] = output.get(mask, QComplex()) + val
    return {mask: value for mask, value in output.items() if value}

axis_pairs = {}
for axis in (mu, nu):
    frames = [coframe(axis, a) for a in range(4)]
    pair_mask = sum(1 << i for g, i in position.items()
                    if g[0] == reg.step(x, axis)[0]
                    or (g[0] == x and (g[2] < 2) != (axis == mu or same_chirality)))
    for a, c in product(range(4), repeat=2):
        out = coframe_pair(frames[a], frames[c])
        assert out == ({pair_mask: QComplex(F(-1, 4))} if a == c else {})
        axis_pairs[axis, a, c] = out

answer = QComplex()
for a, b, c, d in product(range(4), repeat=4):
    for (mask_a, val_a), (mask_b, val_b) in product(axis_pairs[mu, a, c].items(),
                                                  axis_pairs[nu, b, d].items()):
        if mask_a | mask_b != 255 or mask_a & mask_b:
            continue
        answer += (val_a * val_b * sign(mask_a, mask_b)
                   * exact_multilinear_pair(curvature[a, b], curvature[c, d], 4)
                   * F(epsilon((k, ell, mu, nu)) ** 2, 2))
assert answer == QComplex(0 if same_chirality else F(3, 4)), answer
print("same chirality", same_chirality)
print("kept source-order labels", kept)
print("unique contributing center and plane", eligible)
print("one-factor curvature supports", [len(curvature[0, b].terms) for b in range(4)])
print("restricted original S2^2/2! Haar top", answer.storage)
print("curvature Frobenius second moment", sum(
    (exact_multilinear_pair(p, p, 4) for p in curvature.values()), QComplex()).storage)

# Compare actual 24-order factor roster and grouped formula at an asymmetric
# rational unit quaternion point. This uses all ordered terms and both anchors
# for all coframes that can contribute. Nonparticipating center and axis
# pruning has already been independently checked above.
units = ((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1),
         (F(1, 2), F(1, 2), F(1, 2), F(1, 2)),
         (F(3, 5), 0, F(4, 5), 0))
point = {}
values = {}
for i, anchor in enumerate(reg.link_order):
    left, right = units[(i + 2) % len(units)], units[(3 * i + 1) % len(units)]
    point[anchor] = original_spin4_link(left, right)
    for chi, coords in zip(("L", "R"), (left, right)):
        values.update({Symbol("q", (*anchor, chi, j)): v for j, v in enumerate(coords)})

def accumulate(out, a, b, coefficient, frames):
    for (mask_a, val_a), (mask_b, val_b) in product(frames[a].items(), frames[b].items()):
        if mask_a & mask_b:
            continue
        mask = mask_a | mask_b
        val = coefficient * val_a * val_b * sign(mask_a, mask_b)
        out[mask] = out.get(mask, Polynomial()) + val

frames = {(x, axis, a): coframe(axis, a, point)
          for axis, a in product((mu, nu), range(4))}
raw = {}
for factor in original_action_factors(reg, x, point):
    if factor.t_degree == 2 and all(comp in frames for comp in factor.components):
        accumulate(raw, *factor.components, factor.coefficient, frames)
reduced = {}
for (a, b), p in curvature.items():
    accumulate(reduced, (x, mu, a), (x, nu, b),
               Polynomial.scalar(p.evaluate(values) * epsilon((k, ell, mu, nu))), frames)
assert {k: v for k, v in raw.items() if v} == {k: v for k, v in reduced.items() if v}
assert any(raw.values())
print("ordered raw versus grouped quartic comparison", sum(map(bool, raw.values())), "nonzero masks")

# Special central spatial-link point. This does not alter the physical
# Haar integration. It exhibits an open-support failure of the
# proposed positive sewing eigenspace in a non-vacuum degree pair.
plus = original_spin4_link((1,0,0,0),(1,0,0,0))
minus = original_spin4_link((-1,0,0,0),(-1,0,0,0))
central = {key:plus for key in reg.link_order}
central[y,mu] = central[z,nu] = minus
special_axis_pairs = {}
for axis in (mu,nu):
    frames = [coframe(axis,a,central) for a in range(4)]
    for a,c in product(range(4),repeat=2):
        terms = {}
        for (m1,p1),(m2,p2) in product(frames[a].items(),frames[c].items()):
            if not m1 & m2:
                key = m1 | m2
                terms[key] = terms.get(key,Polynomial()) + p1*p2*sign(m1,m2)
        out = {key:p.terms[0][1] for key,p in terms.items() if p}
        prev = axis_pairs[axis,a,c]
        assert out == {key:2*v for key,v in prev.items()}
        special_axis_pairs[axis,a,c] = out

# Only the forward temporal links in the selected plane remain symbolic.
# The two spatial anchors in this plane are exactly identity.
anchored = {anchor:(links[anchor] if anchor[1] == k else central[anchor])
            for anchor in anchors}
W = original_plaquette(reg,x,k,ell,anchored)
Wi = original_plaquette(reg,x,ell,k,anchored)
FF = {(a,b):(trace(W,traces[a,b])-trace(Wi,traces[a,b]))*F(1,2)
      for a,b in traces}
special = QComplex()
for a,b,c,d in product(range(4),repeat=4):
    for (m1,v1),(m2,v2) in product(special_axis_pairs[mu,a,c].items(),
                                 special_axis_pairs[nu,b,d].items()):
        if (m1 | m2) == 255 and not m1 & m2:
            special += v1*v2*sign(m1,m2)*exact_multilinear_pair(FF[a,b],FF[c,d],2)*F(1,2)
assert special == QComplex(3)
print("fixed central spatial links and connector Haar only, original degree-eight top",
      special.storage)
print("nonzero spatial coframes supported on two undirected edges, other-side spatial coframes vanish")
print("all spatial curvature vanishes at central link point, so K has only one center and K^5=0")
