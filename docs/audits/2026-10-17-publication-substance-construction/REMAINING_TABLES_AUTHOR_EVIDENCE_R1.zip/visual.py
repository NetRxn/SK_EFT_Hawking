from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from PIL import Image, ImageDraw

root=Path(sys.argv[1])
evidence=root/"evidence"
markers={
"D1":{"platform_hierarchy":"dominance","status":"acousticMetric det"},
"D2":{"branches":"framing, no","z4":"difference"},
"D4":{"grades":"Substantive and correct"},
"D6":{"counts":"no storage faults","modules":"Modules in the capstone"},
"D9":{"what_certifies":"Certifies D","exact":"Gen. amp. damping","classes":"Kernel-checked, empty"},
"D10":{"inhabitance":"Hypotheses in signature"},
}
def run(*args):return subprocess.check_output(args,text=True)
page_info={}
for bundle, labels in markers.items():
    case_info={}
    for case in ("base","candidate","ten"):
        pd=root/case/"papers"/bundle/"paper_draft.pdf"
        pdir=evidence/"raster"/bundle/case
        pdir.mkdir(parents=True,exist_ok=True)
        for flag, name in [("-layout","layout"),("-raw","raw")]:
            subprocess.run(["pdftotext",flag,str(pd),str(pdir/(name+".txt"))],check=True)
        pages=(pdir/"layout.txt").read_text().split("\f")
        matches={name:[i for i,t in enumerate(pages,1) if marker in t] for name,marker in labels.items()}
        if not list(pdir.glob("page-*.png")): subprocess.run(["pdftoppm","-r","86","-png",str(pd),str(pdir/"page")],check=True)
        h={int(f.stem.rsplit("-",1)[1]):sha256(f.read_bytes()).hexdigest() for f in pdir.glob("page-*.png")}
        dest=run("pdfinfo","-dests",str(pd))
        (pdir/"destinations.txt").write_text(dest)
        case_info[case]={"pages": len(h),"table_markers":matches,"hashes":h}
    base=case_info["base"]
    for case in ("candidate","ten"):
        item=case_info[case]
        assert len(item["hashes"])==len(base["hashes"]), (bundle,case)
        item["changed_raster_pages"]=[i for i,h in sorted(item["hashes"].items()) if h!=base["hashes"][i]]
        dirs = [evidence/"raster"/bundle/c for c in ("base",case)]
        names = lambda directory: sorted(re.findall(r'^\s*\d+\s+\[[^\n]*\]\s+(.*)$',(directory/"destinations.txt").read_text(),re.M))
        item["destination_names_preserved"] = names(dirs[0]) == names(dirs[1])
    page_info[bundle]=case_info
    for label,pages in case_info["candidate"]["table_markers"].items():
        bases=case_info["base"]["table_markers"][label]
        # Markers with multiple incidental hits still keep every candidate page listed.
        if not pages or not bases: continue
        for j,i in enumerate(pages):
            ref=bases[min(j,len(bases)-1)]
            def page_png(case,page):
                matches=list((evidence/"raster"/bundle/case).glob(f"page-{page:02d}.png"))
                return matches[0] if matches else (evidence/"raster"/bundle/case/f"page-{page}.png")
            a,b=[Image.open(page_png(c,p)).convert("RGB") for c,p in [("base",ref),("candidate",i)]]
            target=Image.new("RGB",(a.width+b.width,max(a.height,b.height)+25),"white")
            target.paste(a,(0,25)); target.paste(b,(a.width,25))
            draw=ImageDraw.Draw(target)
            draw.text((8,4),f"{bundle} base p.{ref} {label}",fill="black")
            draw.text((a.width+8,4),f"{bundle} candidate p.{i} {label}",fill="black")
            (evidence/"paired").mkdir(exist_ok=True)
            target.save(evidence/"paired"/f"{bundle}-{label}-{i}.jpg",quality=92)
(evidence/"visual.json").write_text(json.dumps(page_info,indent=2)+"\n")
for b,i in page_info.items():
    print(b,i["candidate"]["pages"],i["candidate"]["changed_raster_pages"],i["candidate"]["table_markers"],"destinations",i["candidate"]["destination_names_preserved"])
