import json, re, sys
from pathlib import Path

p = Path(sys.argv[1])
bundles = ["D1", "D2", "D4", "D6", "D9", "D10"]
table = re.compile(r"\\begin\{tabular\}\{([lcr]+)\}(.*?)\\end\{tabular\}", re.S)
include = re.compile(r"\\input\{(tables/[^{}]+\.tex)\}")
rules = re.compile(r"\\(toprule|midrule|bottomrule|colrule|hline)\b")

def rows(body):
    content = rules.sub("",body)
    cells = [line.split("&") for line in re.split(r"\\\\(?:\[2pt\])?", content)]
    assert not any(c.strip() for c in cells.pop())
    return [[re.sub(r"\$(.*?)\$", lambda m: "$" + m[1].strip() + "$", " ".join(cell.split()))
             for cell in row] for row in cells]

report={}
for bundle in bundles:
    old = p / "base" / "papers" / bundle
    new = p / "candidate" / "papers" / bundle
    left = (old / "paper_draft.tex").read_text()
    right = (new / "paper_draft.tex").read_text()
    assert table.sub("TABLE-BODY",left) == include.sub("TABLE-BODY",right), bundle
    report[bundle] = {}
    for a, inc in zip(table.finditer(left), include.finditer(right), strict=True):
        rendered = (new / inc[1]).read_text()
        b, = list(table.finditer(rendered))
        assert a[1] == b[1], inc[1]
        arows,brows=rows(a[2]),rows(b[2])
        assert arows == brows, (bundle,inc[1],[(i,x,y) for i,(x,y) in enumerate(zip(arows,brows,strict=True)) if x!=y])
        report[bundle][inc[1]] = {
            "alignment": a[1],
            "header_cells": len(arows[0]),
            "data_rows": len(arows)-1,
            "data_cells": sum(len(r) for r in arows[1:]),
            "baseline_rules": rules.findall(a[2]),
            "candidate_rules": rules.findall(b[2]),
            "baseline_extra_row_spaces": a[2].count(r"\\[2pt]"),
            "candidate_extra_row_spaces": b[2].count(r"\\[2pt]"),
        }
print(json.dumps(report,indent=2))
