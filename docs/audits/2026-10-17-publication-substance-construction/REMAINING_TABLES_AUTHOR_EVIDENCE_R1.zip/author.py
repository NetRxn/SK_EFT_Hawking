from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
specifications = {
    "D1": [("platform_hierarchy", "Dispersive and dissipative benchmark corrections", ("platform", "temperature", "dispersion", "dissipation", "dominance")),
           ("status", "Results and proof status", ("result", "section", "status"))],
    "D2": [("branches", "Anomaly constraints by branch", ("branch", "condition", "solutions")),
           ("z4", "Z4 charges in both normalisations", ("species", "hypercharge", "b_minus_l", "gem", "ours", "difference"))],
    "D4": [("grades", "Proof trust grades", ("grade", "meaning"))],
    "D6": [("counts", "Malignant-pair counts and their reciprocals", ("count", "value", "inverse")),
           ("modules", "Modules in the capstone dependency closure", ("module", "contribution"))],
    "D9": [("what_certifies", "Data and worst-case error certification", ("datum", "certification", "route")),
           ("exact", "Exact distances and bounds by channel", ("channel", "distance", "declaration")),
           ("classes", "Failure classes and responses", ("class", "closure", "response"))],
    "D10": [("inhabitance", "Apex statements and construction witnesses", ("layer", "hypotheses", "witness"))],
}
body_re = re.compile(r"\\begin\{tabular\}\{([lcr]+)\}(.*?)\\end\{tabular\}", re.S)
format_re = re.compile(r"\\(?:toprule|midrule|bottomrule|colrule)\b")
row_re = re.compile(r"\\\\(?:\[2pt\])?")
def parse(body):
    rows = row_re.split(format_re.sub("", body))
    assert not rows[-1].strip(), rows[-1]
    return [tuple(" ".join(cell.split()) for cell in row.split("&")) for row in rows[:-1]]

d1_setup = r'''
from scripts.gen_d1_hierarchy_table import compute_bec_hierarchy, fmt_sci_latex


_BEC_LABELS = {
    "Steinhauer": r"$^{87}$Rb BEC (Steinhauer/de~Nova)",
    "Heidelberg": r"$^{39}$K BEC (Heidelberg, projected)",
    "Trento": r"spin-sonic BEC (Trento)",
}


def _hierarchy_rows() -> list[dict[str, str]]:
    rows = []
    for name, values in compute_bec_hierarchy().items():
        dominance = values["dominance"]
        rows.append({
            "platform": _BEC_LABELS[name],
            "temperature": values["T_H_nominal_label"],
            "dispersion": fmt_sci_latex(values["delta_disp"]),
            "dissipation": fmt_sci_latex(values["delta_diss"]),
            "dominance": r"\textbf{diss}" if dominance == "diss" else dominance,
        })
    # Platform-specific orientation estimates as reported in the caption and text.
    rows.extend(_NON_BEC_ROWS)
    return rows
'''
d2_setup = r'''
from fractions import Fraction
from math import isclose

from src.core.constants import SM_FERMION_DATA, SM_Z4_CHARGE_FORMULA


_SPECIES = {
    "Q_L": r"$Q_L$",
    "u_R_bar": r"$\bar u_R$",
    "d_R_bar": r"$\bar d_R$",
    "L": r"$L$",
    "e_R_bar": r"$\bar e_R$",
    "nu_R_bar": r"$\bar\nu_R$",
}


def _sixths(value: float) -> Fraction:
    """Read the exact sixth-integer charge represented by a source float."""
    charge = Fraction(round(6 * value), 6)
    if not isclose(value, float(charge), rel_tol=0, abs_tol=1e-12):
        raise ValueError(f"Expected a sixth-integer Standard Model charge, got {value}")
    return charge


def _charge_rows() -> list[dict[str, str]]:
    rows = []
    for name, species in _SPECIES.items():
        fermion = SM_FERMION_DATA[name]
        y = _sixths(fermion["Y"])
        b_minus_l = _sixths(fermion["B_minus_L"])
        # Eq. (gem-standard) uses the rescaled García-Etxebarria--Montero charges.
        gem = -12 * y - 15 * b_minus_l
        ours = (SM_Z4_CHARGE_FORMULA["Y_coeff"] * y
                + SM_Z4_CHARGE_FORMULA["B_minus_L_coeff"] * b_minus_l)
        rows.append({
            "species": species,
            "hypercharge": f"${y}$",
            "b_minus_l": f"${b_minus_l}$",
            "gem": f"${gem}$",
            "ours": f"${ours}$",
            "difference": f"${gem - ours}$",
        })
    return rows
'''
d6_setup = r'''
# AGP2006 Sec. 8.3 (fault models and Eqs. 32--36) and its depolarizing example.
# Retain the reported count precision, then compute each displayed reciprocal.
_COUNTS = (
    (r"$A_{\rm CNOT}$, depolarizing noise", 7_183, True),
    (r"$A_{\rm CNOT}$, no storage faults", 22_701, False),
    (r"$A_{\rm CNOT}$, Eq.~\eqref{eq:acnot}", 35_235, False),
    (r"$A'_{\rm CNOT}$, cubic term absorbed", 36_108, True),
    (r"$A''_{\rm CNOT}$, ancilla acceptance", 36_511, True),
)


def _count_rows() -> list[dict[str, str]]:
    rows = []
    for label, count, approximate in _COUNTS:
        prefix = r"\approx " if approximate else ""
        digits = f"{count:,}".replace(",", r"\,")
        mantissa, exponent = f"{1 / count:.2e}".split("e")
        rows.append({
            "count": label,
            "value": f"${prefix}{digits}$",
            "inverse": rf"${mantissa}\times10^{{{int(exponent)}}}$",
        })
    return rows
'''
dynamic = {("D1", "platform_hierarchy"): "_hierarchy_rows", ("D2", "z4"): "_charge_rows", ("D6", "counts"): "_count_rows"}

def py_string(s):
    if "\\" in s and '"' not in s:
        return 'r"' + s + '"'
    return repr(s)

def emit_tuples(name, rows):
    return name + " = (\n" + "".join("    (" + ", ".join(map(py_string, row)) + "),\n" for row in rows) + ")\n\n"

for bundle, specs in specifications.items():
    folder = root / "papers" / bundle
    draft = folder / "paper_draft.tex"
    tex = draft.read_text()
    bodies = list(body_re.finditer(tex))
    assert len(bodies) == len(specs)
    text = f'"""Canonical table specifications for {bundle}."""\n\n'
    if bundle == "D2":
        # Standard library imports precede project imports.
        setup = d2_setup.lstrip().replace("from src.core.constants import SM_FERMION_DATA, SM_Z4_CHARGE_FORMULA\n",
            "from scripts.paper_tables import Col\nfrom src.core.constants import SM_FERMION_DATA, SM_Z4_CHARGE_FORMULA\n")
        text += setup
    else:
        text += "from scripts.paper_tables import Col\n"
        if bundle == "D1":
            text += d1_setup
        if bundle == "D6":
            text += "\n" + d6_setup
    text += "\n"
    entries = []
    for (name, desc, fields), match in zip(specs, bodies, strict=True):
        alignment, body = match.groups()
        headers, *rows = parse(body)
        assert all(len(row) == len(fields) == len(alignment) for row in [headers, *rows]), (name, rows)
        cols = ", ".join(py_string(f) for f in fields)
        fn = dynamic.get((bundle, name))
        if fn is None:
            data = f"_{name.upper()}_ROWS"
            text += emit_tuples(data, rows)
            fn = f"lambda: [dict(zip(({cols}), row, strict=True)) for row in {data}]"
        elif bundle == "D1":
            text += "_NON_BEC_ROWS = [\n"
            for row in rows[3:]:
                text += "    {\n" + "".join(f'        "{key}": {py_string(value)},\n' for key, value in zip(fields, row, strict=True)) + "    },\n"
            text += "]\n\n"
        entry = f'    "{name}": {{\n        "description": "{desc}",\n        "columns": [\n'
        entry += "".join(f'            Col("{field}", {py_string(header)}, align="{align}"),\n'
                         for field, header, align in zip(fields, headers, alignment, strict=True))
        entries.append(entry + f'        ],\n        "rows": {fn},\n    }},\n')
    for match, (name, _, _) in zip(reversed(bodies), reversed(specs), strict=True):
        tex = tex[:match.start()] + rf"\input{{tables/{name}.tex}}" + tex[match.end():]
    draft.write_text(tex)
    (folder / "tables.py").write_text(text + "TABLES = {\n" + "".join(entries) + "}\n")
