from collections import Counter
import json
from pathlib import Path
import sys
from validate_helpers import draft_input_closure
from validation.checks.prose_lean_refs import _prose_verbatim_tokens
root=Path(sys.argv[1])
controls={}
for bundle in ["D1","D2","D4","D6","D9","D10"]:
    def tokens(case):
        sources=[p for p in draft_input_closure(root/case/"papers"/bundle/"paper_draft.tex")
                     if p.suffix == ".tex" and p.is_file()]
        combined="\n".join(p.read_text() for p in sources)
        return Counter(t for t,_ in _prose_verbatim_tokens(combined))
    a,b=tokens("base"),tokens("candidate")
    assert a == b,(bundle,a-b,b-a)
    controls[bundle]={"equal":True,"distinct_verbatim_tokens":len(a),"verbatim_occurrences":sum(a.values())}
print(json.dumps(controls,indent=2))
