from collections import Counter
import json
from pathlib import Path
import sys

from validation.checks import prose_lean_refs as refs

root=Path(sys.argv[1])
bundles=("D1","D2","D4","D6","D9","D10")
index=refs._load_lean_name_index()
resolved={"OK","MATHLIB","PRIVATE","PHYSLIB"}
def status(token):
    if token in refs._PROSE_REF_ALLOWLIST:
        return "ALLOWLIST"
    value=refs._resolve_prose_ref(token,index,deep=False)
    if value in resolved:
        return value
    if not refs._prose_token_is_reportable(token):
        return "NOT_REPORTABLE"
    return refs._resolve_prose_ref(token,index)
def summary(counter, statuses):
    out={}
    for key,t in [("raw",set(statuses.values())), ("resolved",resolved), ("checker_candidates",set(statuses.values())-{"NOT_REPORTABLE"})]:
        subset={v:n for v,n in counter.items() if statuses[v] in t}
        out[key]={"unique":len(subset),"occurrences":sum(subset.values()),"repeated_occurrences":sum(subset.values())-len(subset)}
    return out
report={}
for b in bundles:
    def count(case):
        source=(root/case/"papers"/b/"paper_draft.tex").read_text()
        return Counter(token for token, offset in refs._prose_verbatim_tokens(source))
    a,c=count("base"),count("candidate")
    statuses={t:status(t) for t in a|c}
    assert not c-a,(b,c-a)
    report[b]={"before":summary(a,statuses),"after":summary(c,statuses),
        "lost_occurrences":{t:{"before":a[t],"after":c[t],"status":statuses[t]} for t in sorted(a-c)},
        "lost_unique_resolved": [t for t in sorted(a-c) if t not in c and statuses[t] in resolved]}
print(json.dumps(report,indent=2))
