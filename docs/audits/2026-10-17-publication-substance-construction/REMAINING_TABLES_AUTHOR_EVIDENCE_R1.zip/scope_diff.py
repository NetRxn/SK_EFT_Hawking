import difflib
from hashlib import sha256
from pathlib import Path
import re
import subprocess
import sys

repo = Path("/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking")
root = Path(sys.argv[1])
kind = sys.argv[2]
head = "ddc320ec365a1f42fd5d8d81796ae07bc0bb029c"
bundles = ["D1", "D2", "D4", "D6", "D9", "D10"]
files = []
for bundle in bundles:
    location = Path("papers") / bundle
    files.extend([location / "paper_draft.tex", location / "tables.py"])
    draft = (root / files[-2]).read_text()
    specs = re.findall(r"\\input\{(tables/[^}]+\.tex)\}", draft)
    files.extend(location / s for s in specs)
assert len(files) == len(set(files)) == (23 if kind == "all-11" else 22)
patch = []
for location in files:
    name = str(location)
    new = (root / location).read_bytes()
    result = subprocess.run(["git","-C",str(repo),"show",f"{head}:{name}"], capture_output=True)
    old = result.stdout if result.returncode == 0 else b""
    assert new != old
    if not old:
        assert result.returncode == 128 and "does not exist" in result.stderr.decode(), result.stderr
    patch.append(f"diff --git a/{name} b/{name}\n")
    if not old:
        patch.append("new file mode 100644\n")
    patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),
                                     f"a/{name}" if old else "/dev/null",f"b/{name}"))
patch_path = root.parent / f"{kind}.patch"
patch_path.write_text("".join(patch))
(root.parent / f"{kind}.sha256").write_text("".join(f"{sha256((root / x).read_bytes()).hexdigest()}  {x}\n" for x in files))
subprocess.run(["git", "-C", str(repo), "apply", "--check", str(patch_path)], check=True)
print(kind, len(files), sha256(patch_path.read_bytes()).hexdigest(), patch_path)
