# Original finite Dirac/Berezin wt1 candidate

Task: publication-original-dirac-berezin-wt1-r1. Parent: publication-remediation.
Owner: original-dirac-berezin-wt1-worker. Notebook writer and lifecycle owner: ROOT.
Notebook: /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-original-dirac-berezin-wt1-r1-notebook.md.
Roadmap: docs/roadmaps/Phase6a_Roadmap.md.
Packet: publication-original-dirac-berezin-wt1-r1.json.

Candidate: e87baaeb9bcd208e396c19acaa9309c3756a7a60, branch worktree-wt1.
Owned file only: lean/SKEFTHawking/ADW/FiniteGrassmannDiracBerezin.lean.
Absolute slot: /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.claude/worktrees/wt1.
Source SHA256: 578821c0a1cd9125a95d41aa928b70fbff2b90d301848cd37a44352dab8416f6.
Normal commit hook passed; worktree clean. No aggregate, dependency, registry, notebook or PRIMARY edits.

## Implemented mathematical scope

- globalMatrix sums the actual four signed quarter-coframe hopping increments on original Fermion = Site x Fin4 indices. globalMatrix_eq9 reconstructs the original coframe linear field for arbitrary complex coefficients. Coincident anchors are added; identity links on the actual one-site torus yield the zero matrix.
- berezin is the linear top coordinate of an actual exterior basis on the SAME original 8V generator carrier. localSourceOrder explicitly orders barL1 barL2 psiL1 psiL2 barR1 barR2 psiR1 psiR2. It is independent of any matrix or determinant.
- Actual row factors are products of genuine odd coordinate vectors. Square-zero and repeated-row vanishing give a genuine alternating row product; Mathlib determinant uniqueness gives arbitrary complex determinant dependence.
- Homogeneous grading kills lower finite exponential terms. The existing squareZero_list_sum_top factorial-product theorem gives the top term, and the finite exponential factorial cancels. No inverse, nonzero determinant, real/positive restriction, Pfaffian, magnitude or target-identity assumption is used.
- local_source_pairs proves the two odd swaps per site's literal source word; source_top_sites retains whole degree-eight site words. diagonal_source_top and rowBerezin_normalization prove source normalization +1. The final berezin_nilExp_det theorem is valid for every original 4V complex matrix, including singular ones.
- berezinContinuous uses C1's actual finite-dimensional norm. berezin_integral and berezin_C3 exchange this actual functional with the actual integrable C3 Gaussian integral. original_determinant_integrable proves scalar absolute integrability.
- fullWeight is the unchanged product of every original site compensation weight at common cutoff 4V. original_fixed_link_determinant specializes the complete fixed-link identity at the actual globalMatrix. printed_fixed_link_determinant and closed_fixed_link_determinant retain their separately labeled sources.

## Search and reuse

Actual matching wt1 local name, semantic meaning and type searches were used, alongside actual pinned Mathlib ExteriorPower Basis/Pairing, ExteriorAlgebra Basis, Determinant and DirectSum source. Existing coframe source/imports and its source history were inspected. The determinant uniqueness API for the actual alternating row product supplied a shorter direct route than constructing an additional full wedge-pairing interface. Existing hopping_reconstructs_coframe, squareZero_list_sum_top, AlternatingMap.eq_smul_basis_det, Pi.basisFun_det_apply, collectedBasis_repr_of_mem_ne, uncurried_global_integrable and uncurried_global_eq7 are reused. No stale catalog absence claim was made.

Proof-state and multi-attempt work included the full matrix-sum rearrangement, top-degree coordinate annihilation, source index site grouping and source normalization. Initial proof-development failures were resolved by decomposition and typed inclusions, with no heartbeat increases.

## Verification evidence

Final matching MCP diagnostic result: success=true, timed_out=false, items=[], failed_dependencies=[].
All 54 new exports were checked together with actual #print axioms on the complete exact source: success=true, timed_out=false, 54 info results, standard propext/Classical.choice/Quot.sound only or no axioms.
39 actual end-of-proof lean_goal observations all return goals_after=[]; term proofs also have empty goal states.
lean_verify on berezin_nilExp_det and final original_fixed_link_determinant returns exactly the standard three axioms and no source-scan warnings. The first twelve exports additionally passed individual lean_verify checks.
Full raw axiom output, all closing states and diagnostics are preserved in the companion JSON report.

Controls: empty_matrix_control (empty matrix/exterior unit), one_site_zero_matrix, one_site_original_matrix and one_site_original_integral (actual original regulator with all coincident increments), offdiagonal_swap (full-carrier negative permutation determinant), complex_phase (full-carrier imaginary phase), singular_repeated_row (full-carrier repeated-row singularity).
Whitespace check passed on the new file and on the exact staged set. Only the assigned path was staged and committed with normal hooks.

## Authority and continuity

FIRST and recovery continuity checks were fresh. Initial worker sandbox status could not run ps; worker stopped and reported before editing. ROOT reconciled with privileged ACTIVE public codex wt1 controller status and successful matching probes. The actual matching worker Lean diagnostics then succeeded. ROOT later reconfirmed capacity_complete=true with no conflicts/errors and maintained the heartbeat. No worker lifecycle or environment repair was performed.

Final SAME packet check reports fresh=false, changed=[owned-files, source], as expected from the assigned new file and source-only commit. The packet was not self-refreshed. ROOT must reconcile the candidate into a new review packet.

## Remaining acceptance and original scope

This is a source-only fixed-link Dirac/Berezin/C3 candidate. A new module still needs ROOT's authoritative build before downstream imports; no worker build was run.
Independent complete mathematical/source/kernel review, ROOT serialization, authoritative build, integration and absorption remain required.
The outer compact-link Haar measure, coefficient continuity/boundedness and Fubini consumer remain necessary for full Eq10. No outer Haar identity was assumed or claimed.
Eq11 insertions/weight derivatives, composite source response, original full Z, nonzero normalization where needed, B2/B3 metric/state/matter/transport/continuum and publication obligations remain explicit and open. No physical state, positivity, propagating gravity or publication acceptance follows from this finite identity.

