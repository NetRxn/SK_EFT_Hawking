#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

using I64 = int64_t;
using I128 = __int128_t;
using U64 = uint64_t;
constexpr U64 MAX_MOMENT_PAIRS = 50000000;
constexpr U64 MAX_MATCH_PRODUCTS = 50000000;
constexpr int D = 700;

struct Z {
    I64 re = 0, im = 0;
    Z& operator+=(Z v) { re += v.re; im += v.im; return *this; }
    Z operator*(Z v) const { return {re*v.re - im*v.im, re*v.im + im*v.re}; }
    Z operator*(int v) const { return {re*v, im*v}; }
    bool operator==(Z v) const { return re == v.re && im == v.im; }
    explicit operator bool() const { return re != 0 || im != 0; }
    U64 height() const { return std::abs(re) + std::abs(im); }
};

std::string dec(I128 n) {
    bool neg = n < 0;
    if (neg) n = -n;
    std::string out;
    do { out += char('0' + n%10); n /= 10; } while (n);
    if (neg) out += '-';
    std::reverse(out.begin(), out.end());
    return out;
}
int sign(unsigned a, unsigned b) {
    int p = 0;
    while (a) {
        unsigned i = a & -a;
        p ^= std::popcount(b & (i - 1)) & 1;
        a ^= i;
    }
    return p ? -1 : 1;
}
struct Linear { unsigned mask; int q; Z value; };
struct Quad { unsigned mask; int a, b; Z value; };
using LinearRoster = std::array<std::array<std::vector<Linear>, 4>, 2>;
using QuadRoster = std::array<std::vector<Quad>, 257>;
using Matrix = std::vector<Z>;
using Gram = std::array<std::array<int, 10>, 10>;

LinearRoster read_coframes() {
    LinearRoster out;
    std::ifstream in("coframes.tsv");
    int x, a, q, re, im;
    unsigned mask;
    while (in >> x >> a >> mask >> q >> re >> im) {
        if (x < 0 || x > 1 || a < 0 || a > 3 || q < 0 || q > 15 ||
            mask >= 65536 || std::popcount(mask & 255) != 1 ||
            std::popcount(mask >> 8) != 1 || std::abs(re) + std::abs(im) != 1)
            throw std::runtime_error("invalid source coframe row");
        out[x][a].push_back({mask, q, {re, im}});
    }
    for (const auto& center : out)
        for (const auto& v : center)
            if (v.size() != 64) throw std::runtime_error("source coframe size");
    return out;
}
Gram read_gram() {
    std::array<Gram,3> gs{};
    std::ifstream in("grams.tsv");
    int t, i, j, n;
    while (in >> t >> i >> j >> n) {
        if (t < 0 || t > 2 || i < 0 || i > 9 || j < 0 || j > 9 || std::abs(n) > 4)
            throw std::runtime_error("invalid Gram row");
        gs[t][i][j] = n;
    }
    int count = 0;
    for (int i = 0; i < 10; ++i)
        for (int j = 0; j < 10; ++j) {
            if (gs[0][i][j] != 2*gs[1][i][j] || gs[1][i][j] != gs[2][i][j] ||
                gs[1][i][j] != gs[1][j][i])
                throw std::runtime_error("Gram collapse or symmetry mismatch");
            count += gs[1][i][j] != 0;
        }
    if (count != 18) throw std::runtime_error("Gram support mismatch");
    return gs[1];
}
QuadRoster square_pair(const std::vector<Linear>& a, const std::vector<Linear>& b) {
    std::unordered_map<unsigned, Z> exact;
    for (const auto& u : a)
        for (const auto& v : b) {
            if (u.mask & v.mask) continue;
            unsigned qa = std::min(u.q, v.q), qb = std::max(u.q, v.q);
            unsigned key = (u.mask | v.mask) | (qa << 16) | (qb << 20);
            exact[key] += (u.value * v.value) * sign(u.mask, v.mask);
        }
    QuadRoster out;
    for (const auto& [key, value] : exact) {
        if (!value) continue;
        int a = (key >> 16) & 15, b = (key >> 20) & 15;
        int p = a == b ? 0 : 1 + 16*a + b;
        out[p].push_back({key & 65535, a, b, value});
    }
    return out;
}
int moment48(const Quad& a, const Quad& b) {
    // Quadratic parity buckets are identical. The fourth-order keys are
    // either q^4 or q^2 r^2, using separately labeled Haar groups.
    const int qa = a.a;
    const int qb = a.a == a.b ? b.a : a.b;
    if (qa == qb) return 6;
    return qa/4 == qb/4 ? 2 : 3;
}
U64 candidates(const QuadRoster& a, const QuadRoster& b) {
    U64 out = 0;
    for (int i = 0; i < 257; ++i) out += U64(a[i].size()) * b[i].size();
    return out;
}
void contract_edge(const QuadRoster& a, const QuadRoster& b, int left, int right,
                   const std::array<int, 256>& pos, Matrix& out) {
    for (int p = 0; p < 257; ++p)
        for (const auto& u : a[p])
            for (const auto& v : b[p]) {
                if (u.mask & v.mask) continue;
                unsigned mask = u.mask | v.mask;
                int i = pos[mask & 255], j = pos[mask >> 8];
                if (i < 0 || j < 0) throw std::runtime_error("nonquartic endpoint");
                const int row = 70*left + i, col = 70*right + j;
                out[row*D + col] += (u.value * v.value) * (moment48(u,v)*sign(u.mask,v.mask));
            }
}
Matrix edge_tensor(const LinearRoster& src, const std::array<int, 256>& pos, bool mixed) {
    std::array<std::pair<int,int>,10> index;
    int n = 0;
    for (int a = 0; a < 4; ++a)
        for (int b = a; b < 4; ++b) index[n++] = {a,b};
    std::array<QuadRoster, 10> left, right;
    std::array<std::array<QuadRoster, 4>, 4> cross;
    if (mixed) {
        for (int a = 0; a < 4; ++a)
            for (int b = 0; b < 4; ++b)
                cross[a][b] = square_pair(src[0][a], src[1][b]);
    } else {
        for (int i = 0; i < 10; ++i) {
            auto [a,b] = index[i];
            left[i] = square_pair(src[0][a], src[0][b]);
            right[i] = square_pair(src[1][a], src[1][b]);
        }
    }
    const auto roster = [&](int i, int j, int side) -> const QuadRoster& {
        if (!mixed) return side ? right[j] : left[i];
        auto [a,c] = index[i];
        auto [b,d] = index[j];
        return side ? cross[c][d] : cross[a][b];
    };
    U64 count = 0;
    for (int i = 0; i < 10; ++i)
        for (int j = 0; j < 10; ++j)
            count += candidates(roster(i,j,0), roster(i,j,1));
    std::cout << "moment candidates mixed " << mixed << ' ' << count << '\n';
    if (count > MAX_MOMENT_PAIRS) throw std::runtime_error("moment candidate cap");
    Matrix result(D*D);
    for (int i = 0; i < 10; ++i)
        for (int j = 0; j < 10; ++j)
            contract_edge(roster(i,j,0), roster(i,j,1), i, j, pos, result);
    return result;
}
Matrix product_ve(const Matrix& e, const Gram& g, const std::array<int, 256>& pos,
                  const std::vector<unsigned>& masks, bool reverse) {
    Matrix a(D*D);
    U64 count = 0;
    for (int i = 0; i < D; ++i) {
        const unsigned mask = masks[i % 70];
        const int comp = pos[255 ^ mask];
        for (int j = 0; j < 10; ++j) {
            const int value = g[i/70][j] * sign(mask, 255 ^ mask);
            if (!value) continue;
            const int k = 70*j + comp;
            for (int l = 0; l < D; ++l) {
                if (++count > MAX_MATCH_PRODUCTS) throw std::runtime_error("vertex match cap");
                if (reverse) a[l*D + i] += e[l*D + k] * value;
                else a[i*D + l] += e[k*D + l] * value;
            }
        }
    }
    std::cout << "vertex matching products reverse " << reverse << ' ' << count << '\n';
    return a;
}
I128 trace_four(const Matrix& a, bool reverse) {
    std::vector<std::vector<int>> nonzero(D);
    U64 max = 0, products = 0;
    for (int i = 0; i < D; ++i)
        for (int j = 0; j < D; ++j)
            if (const auto v = a[i*D+j]; v) {
                nonzero[i].push_back(j);
                max = std::max(max, v.height());
            }
    for (int i = 0; i < D; ++i)
        for (int k : nonzero[i]) products += nonzero[k].size();
    U64 count = 0;
    for (const auto& r : nonzero) count += r.size();
    std::cout << "A reverse " << reverse << " nnz " << count << " height " << max
              << " matching products " << products << '\n';
    const int squared_bits = 10 + 2*std::bit_width(max);
    if (products > MAX_MATCH_PRODUCTS || squared_bits > 62 || 20 + 2*squared_bits > 126)
        throw std::runtime_error("matching resource or exact integer height cap");
    Matrix b(D*D);
    for (int i = 0; i < D; ++i)
        for (int k : nonzero[i])
            for (int j : nonzero[k]) b[i*D+j] += a[i*D+k]*a[k*D+j];
    I128 real = 0, imag = 0;
    for (int i = 0; i < D; ++i)
        for (int j = 0; j < D; ++j) {
            const Z x = b[i*D+j], y = b[j*D+i];
            real += I128(x.re)*y.re - I128(x.im)*y.im;
            imag += I128(x.re)*y.im + I128(x.im)*y.re;
        }
    std::cout << "trace numerator " << dec(real) << ' ' << dec(imag) << '\n';
    if (imag) throw std::runtime_error("slice should be real");
    return real;
}
int main() {
    try {
        std::array<int, 256> pos; pos.fill(-1);
        std::vector<unsigned> masks;
        for (unsigned m = 0; m < 256; ++m)
            if (std::popcount(m) == 4) {
                pos[m] = masks.size();
                masks.push_back(m);
            }
        auto source = read_coframes();
        auto g = read_gram();
        auto edge = edge_tensor(source, pos, false);
        auto mixed = edge_tensor(source, pos, true);
        if (edge != mixed) throw std::runtime_error("edge regrouping discrepancy");
        U64 nnz = 0, height = 0, imaginary = 0;
        std::ofstream edge_export("edge.tsv");
        for (int i = 0; i < D; ++i)
            for (int j = 0; j < D; ++j) {
                const Z z = edge[i*D+j];
                if (!(z == edge[j*D+i])) throw std::runtime_error("edge endpoint symmetry");
                if (z) edge_export << i/70 << '\t' << masks[i%70] << '\t' << j/70
                                   << '\t' << masks[j%70] << '\t' << z.re << '\t' << z.im << '\n';
                nnz += bool(z);
                imaginary += z.im != 0;
                height = std::max(height,z.height());
            }
        std::cout << "edge nnz " << nnz << " imaginary " << imaginary << " height " << height << '\n';
        auto ve = product_ve(edge, g, pos, masks, false);
        auto ev = product_ve(edge, g, pos, masks, true);
        for (int i = 0; i < D; ++i)
            for (int j = 0; j < D; ++j)
                if (!(ve[i*D+j] == ev[j*D+i])) throw std::runtime_error("matrix orientation discrepancy");
        const auto c = trace_four(ve, false);
        if (trace_four(ev, true) != c) throw std::runtime_error("trace cyclic discrepancy");
        std::cout << "C numerator " << dec(c) << " edge denominator 12288 power 4\n";
    } catch (const std::runtime_error& e) {
        std::cerr << "REFUSED " << e.what() << '\n';
        return 2;
    }
    return 0;
}
