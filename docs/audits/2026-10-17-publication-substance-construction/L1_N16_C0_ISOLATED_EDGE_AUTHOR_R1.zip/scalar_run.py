from collections import Counter
from fractions import Fraction as F
from pathlib import Path
from scalar import admitted,cache,census,canonical
from network import network

values={};refused={}
for code in sorted(set(cache.values())):
    try: values[code]=network(code)
    except RuntimeError as e:refused[code]=str(e)
    print("canonical layer",code,values.get(code),refused.get(code),flush=True)
# Independently route a noncanonical layer via the full factor sewing.
for code in (166856593410,8960795485785):
    k=canonical(code)
    if k in values:
        assert values[k]==network(code)
        print("canonicalization control",code,k,values[k])
total=F(0);solved=[];unresolved=[]
for r,factor in admitted:
    a,b,w=r[:3];A,B=cache[a],cache[b]
    if A not in values or B not in values:
        unresolved.append(r);continue
    x=values[A]*values[B]*factor
    solved.append((a,b,w,x));total+=w*x
Path("scalar-values.tsv").write_text("".join(f"{a}\t{b}\t{w}\t{x}\n" for a,b,w,x in solved))
print("scalar projection census",dict(census))
print("scalar layer count signed/refused",len(values),len(refused))
print("scalar solved orbits/labeled",len(solved),sum(r[2] for r in solved))
print("scalar refused orbits/labeled",len(unresolved),sum(r[2] for r in unresolved))
print("sign counts",dict(Counter((x>0)-(x<0) for a,b,w,x in solved)))
print("exact scalar subtotal",total)
