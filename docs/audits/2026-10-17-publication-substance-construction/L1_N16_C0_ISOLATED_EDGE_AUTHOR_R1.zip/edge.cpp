#define main reference_slice_main
#include "slice_reference.cpp"
#undef main
#include <map>
using Key=std::array<int,3>;
using Tab=std::map<Key,Z>;
LinearRoster read() {
    std::ifstream in("edge_coframes.tsv");
    LinearRoster out;
    int x,a,q,r,i;unsigned m;
    while(in>>x>>a>>m>>q>>r>>i)out.at(x).at(a).push_back({m,q,{r,i}});
    for(const auto& s:out)for(const auto& a:s)
        if(a.size()!=64)throw std::runtime_error("source coframe roster");
    return out;
}
int main() {
    auto input=read();
    std::ofstream out("edge.tsv");
    std::array<Tab,2> control;
    for(int x=0;x<2;++x) {
        std::array<std::array<QuadRoster,4>,4> pair;
        for(int a=0;a<4;++a)for(int b=a;b<4;++b)
            pair[a][b]=square_pair(input[x][a],input[x][b]);
        Tab e2;
        for(int a=0;a<4;++a)for(int b=a;b<4;++b)
            for(const auto& u:pair[a][b][0]){
                int lo=u.mask&255,hi=u.mask>>8;
                if(x)std::swap(lo,hi);
                e2[{4*a+b,lo,hi}]+=u.value;
            }
        for(auto it=e2.begin();it!=e2.end();)
            if(!it->second)it=e2.erase(it);else ++it;
        if(x==0)control[0]=e2;
        else if(control[0]!=e2)throw std::runtime_error("two-factor endpoint reversal mismatch");
        for(int pairing=0;pairing<(x?1:2);++pairing){
            U64 work=0;
            for(int a=0;a<4;++a)for(int b=a;b<4;++b)
              for(int c=b;c<4;++c)for(int d=c;d<4;++d)
                work+=pairing?candidates(pair[a][c],pair[b][d]):candidates(pair[a][b],pair[c][d]);
            if(work>MAX_MOMENT_PAIRS)throw std::runtime_error("moment work cap");
            Tab e4;
            for(int a=0;a<4;++a)for(int b=a;b<4;++b)
              for(int c=b;c<4;++c)for(int d=c;d<4;++d){
                const auto& A=pair[a][pairing?c:b];
                const auto& B=pair[pairing?b:c][d];
                for(int p=0;p<257;++p)
                  for(const auto& u:A[p])for(const auto& v:B[p]){
                    if(u.mask&v.mask)continue;
                    unsigned m=u.mask|v.mask;
                    int lo=m&255,hi=m>>8;
                    if(x)std::swap(lo,hi);
                    e4[{((a*4+b)*4+c)*4+d,lo,hi}]+=(u.value*v.value)*(moment48(u,v)*sign(u.mask,v.mask));
                  }
              }
            for(auto it=e4.begin();it!=e4.end();)
                if(!it->second)it=e4.erase(it);else ++it;
            if(x==0&&pairing==0)control[1]=e4;
            else if(control[1]!=e4)throw std::runtime_error("four-factor pairing or endpoint mismatch");
            std::cout<<"edge grouping "<<x<<' '<<pairing<<" candidates "<<work<<'\n';
        }
    }
    for(int d=0;d<2;++d) {
        std::cout<<"edge degree "<<2*(d+1)<<" entries "<<control[d].size()<<'\n';
        for(const auto& [key,z]:control[d])
            out<<2*(d+1)<<'\t'<<key[0]<<'\t'<<key[1]<<'\t'<<key[2]<<'\t'<<z.re<<'\t'<<z.im<<'\n';
    }
    if(!out)throw std::runtime_error("edge export");
}
