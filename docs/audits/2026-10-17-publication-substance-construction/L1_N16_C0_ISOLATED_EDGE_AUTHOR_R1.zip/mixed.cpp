#define main reference_main
#include "slice_reference.cpp"
#undef main
int main() {
    std::array<int,256> pos;pos.fill(-1);
    std::vector<unsigned> masks;
    for(unsigned m=0;m<256;++m)
        if(std::popcount(m)==4){pos[m]=masks.size();masks.push_back(m);}
    const auto src=read_coframes();
    const auto a=edge_tensor(src,pos,false);
    if(a!=edge_tensor(src,pos,true))throw std::runtime_error("mixed tensor pairing mismatch");
    std::array<int,10> pair_id;
    int n=0;
    for(int i=0;i<4;++i)for(int j=i;j<4;++j)pair_id[n++]=4*i+j;
    std::ofstream out("mixed.tsv");
    int entries=0;
    for(int i=0;i<D;++i)for(int j=0;j<D;++j)
        if(const auto v=a[i*D+j];v){
            out<<pair_id[i/70]<<'\t'<<pair_id[j/70]<<'\t'<<masks[i%70]<<'\t'
               <<masks[j%70]<<'\t'<<v.re<<'\t'<<v.im<<'\n';
            ++entries;
        }
    if(!out)throw std::runtime_error("mixed tensor export");
    std::cout<<"mixed owner entries "<<entries<<'\n';
}
