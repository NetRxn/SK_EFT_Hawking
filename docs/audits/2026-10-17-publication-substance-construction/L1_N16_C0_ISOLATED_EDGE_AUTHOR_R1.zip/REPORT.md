# Exact isolated-edge scalar family and overlapping shared-Haar pilot

The primary continuity packet `l1-c0-isolated-edge-author-r1.json`
checked fresh at `27012c18fa374e8341e124b510abbedeedb18d29`.
This package depends on the frozen residual-core source evidence
at `/private/tmp/l1-c0-core.1zohnyO1/manifest.sha256`, digest
`485a4b062cd2dc7426e9ed250626c1e7e4b9d7ec39cb0e4a5ced52d08375770f`.
That manifest reverified and remained read-only. The prior
source reduction and evidence are independently under review.
Only new scratch files were written.

The prior census identified 816 isolated double-root-edge
orbits in the temporal A-only/B-only n=16 block. Six were
already signed and two were already certified zero. This
package evaluates 732 additional orbits by an exact scalar
channel projection and one additional genuinely overlapping
orbit by an exact scalar plus spin-one contraction. All
733 new values are positive. The remaining 75 isolated
orbits, the rest of this degree block and the full c0 remain open.

## Exact scalar channel selection and census

After integrating the single-root temporal leaves, a residual
isolated spatial edge has a double-root temporal core in one
or both connector layers. Each connector's original two
temporal Haar integrals give the conditional Schur tensor
from the previous report. Its representation label
(p/2,q/2) has one representation matrix at each of
the four directed spatial anchors. The pair of links in
the other layer enters through a single character of their
product. The pair in the core's own layer carries the two
spatial matrices and the rooted coframe coefficients.

For a core in just one connector, any nontrivial representation
must be supplied by coframe occurrences at **each** of those
actual spatial anchors. A polynomial of coordinate degree k
has only representation labels satisfying p+q≤k, since
each coordinate is a fundamental matrix coefficient in
one chirality. As the unresolved isolated-edge roster has
even root powers, its first nontrivial p+q is two. A necessary
condition for that channel is therefore at least four
coframe occurrences in each spatial layer on the undirected
edge. If either layer has fewer, the exact spatial Haar
projection leaves only the scalar. Its root moments are
2 W for power two and 10 W² for power four, with W the
canonical symmetrized chiral Gram polynomial. This conclusion
permits curvature and coframe overlap. It is an exact
representation-degree exclusion after retaining the shared
spatial factors.

If both connectors occupy the edge but neither layer has
coframes on it, the independent root conjugation and the
shared spatial character contraction from the prior report
apply exactly. The full character factor is kept, including
its nontrivial channels and d_j^-4. In particular this route
does not discard legitimate shared Haar correlations.

The exhaustive frozen-table census of the 808 unresolved
isolated orbits found only even root powers and only total
coframe edge degrees two and four. There are 732 orbits
with 61,470 labels where every edge qualifies for one of
the exact treatments above. The remaining 76 have a
dual-connector core that overlaps at least one coframe edge.
No whole-orbit sign is assigned by this census.

The admitted scalar family has 228 labeled layer codes.
Canonicalizing the spatial bit translations and axis
permutations reduces these to **13** coframe layer
contractions. At the scalar stage, each local W polynomial
is symmetric in its two directions and each complete
layer top is invariant under permutation of its
eight-generator site blocks. This justifies the layer
canonicalization after curvature factors have been
separated exactly. Two actual layer contractions also
agree with their canonical images. Original m! factors
are applied to every full representative.

All 13 layer contractions completed within the measured
sparse caps. All 732 original representative values are
positive. The orbit-weighted scalar-family subtotal is

```
15291812481604689642179533548685571603119
/1323453075832297505748418560.
```

The exact values and multiplicities are in
`scalar-values.tsv`.

## Canonical mixed-owner coframe sewing

The ordinary edge tensors retain both independent directed
anchors, the original quarter and the source quaternion
phases. The mixed (2,2) tensor has 3,952 nonzero entries.
Its two exact moment pairings agree entry by entry.
The remaining ordinary same-owner edge tensors are
the frozen source-derived 48- and 380-entry tensors
for total degrees two and four.

Each factor has an actual endpoint label consisting of
the sorted internal coframe multi-index and its exterior
mask, with a projected representation index when present.
Each site closes by the signed product of disjoint
incident masks giving the source-order eight-mask top.
Different edges in this selected even family supply
even degree at each endpoint. Regrouping their local
monomials and permuting whole site tops introduces
no additional sign. The local inversion signs are
retained inside the site tensor. Imaginary edge and
intermediate coefficients are kept as exact Gaussian
integer pairs. The actual final contracted coefficients
are real.

The ordinary mixed edge pairing runs admit at most
11,065,344 moment candidates, below their 50-million
cap. The network caps site or binary join products at
two million, populated tables at 150,000 rows, and
intermediate integer heights at 384 bits. Shared
state histograms preflight every binary join. A
prospective ordinary final join in the overlapping
pilot refused 2,899,968 candidates at its two-million
cap before allocation. The successful replacement
uses a fused scalar closure of the last three factors.
For each row of one factor it intersects the two
matching conditional row dictionaries, without
materializing a new intermediate tensor. Its separate
cap is four million total lookups, two million per
row, and 150,000 total resident input rows. Actual
peak rows and work for each run are in the receipts.
The scalar family, including the canonicalization
controls, took about 6.6 seconds and 90 MB peak RSS.

## Nontrivial dual-core projection with coframe overlap

The pilot representative `(166856593410,8960795485785)`
has orbit size 96. Its dual-connector core is on spatial
edge (4,5), with rooted powers (2,2) in each connector.
The A spatial edge has two coframes centered at one
endpoint, while the B spatial edge has none. Every
other core in this representative is single-connector
and satisfies the exact scalar exclusion above.

Let R denote the real adjoint rotation derived from
the canonical SU(2) matrix, and let b be the actual
chiral coframe bivector in this basis. The exact
quadratic projection in one chirality is

```
4 (vec(q) dot b)^2 = W + sum_(i,j) (2 b_i b_j - W delta_ij) R_ij(q).
```

The full scalar term is 2W after combining chiralities.
The source check verifies the quadratic polynomial
identity on canonical coordinates before imposing the
sphere relation, with its scalar term multiplied by
the quaternion norm square. It also checks all 81
adjoint Schur pair identities using the canonical Haar
moment function. The exported original bivector and
adjoint polynomial coefficients are used directly.

For the two connector kernels on the pilot edge,
integrate the B spatial anchor pair first, with its
actual empty coframe support. Their Schur matrices
pair against the A connector's character. This forces
equal irreducible labels, contracts each B root matrix
to its trace and contributes d^-2. The possible
(p,q)=(1,1) label has zero root trace because it is
the product of two linear imaginary quaternion
components. Only the scalar and the two single-
chirality spin-one labels survive. In a spin-one
channel each B root trace is −W. Their product is
the ordinary B coframe factor.

In A each coframe uses one of the two directed
anchors. With integer-spin matrices, a split of one
coframe per anchor has odd total degree at both
anchors and vanishes. Thus the two coframes use one
common anchor. The other anchor integrates by
one further Schur orthogonality, contributing d^-1.
If the occupied anchor is a rather than c, the
remaining two adjoint entries are
R(a)[delta,alpha] R(a)[gamma,beta], with local root
indices (alpha,beta) and (gamma,delta). If c is
occupied they are R(c)[alpha,delta] R(c)[beta,gamma].
The original coframe endpoints and both anchor
choices remain separate. Together with the two
conditional connector integrations this accounts
for the full factor d^-7=3^-7 in each spin channel.

The surviving occupied-anchor moments have total
quaternion degree six and include the actual two
coframe coefficients. The common denominator is
16·192=3072. For either owner and either chirality,
2,208 signed quadratic coframe records expand to
1,584 collected decorated Haar rows. This stage
admits at most one million candidate products.
Summing a root's diagonal adjoint indices at each
fixed diagonal index of its partner recovers the
ordinary original degree-two edge tensor exactly,
as required by rotation orthogonality. The test
also retains imaginary coefficients in the open
tensor.

The spin-one correction replaces one local W at
each core root in A by 2 b_i b_j−W delta_ij and uses
the decorated spatial edge. The scalar B layer
continues to use its original W at every root.
This is an exact joint shared-Haar contraction.
The two layer coefficients in the scalar channel
are paired with factor 16 from the four core roots.
The remaining 12 roots each supply a scalar factor
2 and a divisor 2!, so they cancel individually.
The four core 2! factors give the remaining divisor
16 in the final representative.

## Exact pilot and adverse controls

The original representative with all factorials is

```
52271073647433042742089/140737488355328.
```

Its orbit-weighted contribution is
156813220942299128226267/4398046511104.
Separately averaging the spatial links of the two
connectors would keep only the scalar channel and
give 6533759724910137236961/17592186044416.
That differs from the actual answer by the retained
spin-one correction. In particular the independent
spatial approximation is false even for this
complete original occupation.

Two different sparse contraction orders agree on
the left spin channel. Both original chiral contractions
have the same value 2462520447/2097152. Omitting the original wedge
sign at one vertex changes that channel, yielding
397852479/2097152 for the adverse coframe control.
This verifies sensitivity to the inherited exterior
orientation. The remaining Schur signs are checked
by the source polynomial identity and by the
decorated rotation-trace control. The maximum
resident inputs in the fused closure are 134,400
rows and the largest populated single table is
49,152 rows, with at most 96 conditional lookups
for any one row. The complete pilot including both
channels, the reverse and the adverse control
uses about 116 MB peak RSS. Detailed actual work,
state widths and signed subtotals are in
`network.out`.

## Remaining work and reproduction

This result adds 733 exact positive orbits covering
61,566 labeled occupations. The isolated family now
has **75 unresolved orbits** and **5,664 labeled
occupations**. The declared n=16 A-only/B-only
temporal block has **11,069 unresolved orbits** and
**953,019 labeled coarse survivors**. No computation
of the other 75 overlapping dual-channel cases was
started under this package. Their full signed state
widths are unmeasured. The other connector degree
blocks and full c0 also remain unresolved.

The prior residual manifest is verified in
`prior-verify.out`. Build `mixed.cpp` and the copied
same-owner `edge.cpp` with
`clang++ -std=c++20 -O3 -Wall -Wextra -Werror`.
The copied frozen source coframes are the inputs.
Run `spin_source.py` against the exact primary
checkout on PYTHONPATH using its existing venv
Python and PYTHONDONTWRITEBYTECODE=1. Then run
`decorate.py`, `network.py` and `scalar_run.py`
in the package directory. `measure.py` records
timing and peak RSS. Original source, prior
artifacts and Git state were not changed.
This result requires independent replay.
