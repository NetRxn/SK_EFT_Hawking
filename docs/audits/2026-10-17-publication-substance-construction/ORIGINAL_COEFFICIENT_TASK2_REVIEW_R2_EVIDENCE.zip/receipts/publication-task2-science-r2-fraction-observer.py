from fractions import Fraction as F
from src.vestigial import original_coefficients as o
import json,resource
original=F.__add__;observed=[]
def record(self,other):
 result=original(self,other)
 if isinstance(result,F): observed.append((str(self),str(other),str(result),abs(result.numerator).bit_length(),result.denominator.bit_length()))
 return result
# Instrument only the independent probe process, never source or the parent.
a=o.RawJet.from_slots((1,1,-1,-200,-200,200));b=o.RawJet.from_slots((1,200,200,-200,200,200))
F.__add__=record
try:
 with o.ExactBudget(10000,512*1024**2,integer_bit_limit=8) as budget:
  result=a*b
finally:F.__add__=original
large=[x for x in observed if x[3]>8 or x[4]>8]
assert large and all(str(v) in ['1','201','199','0'] for v in result.slots())
print(json.dumps({'actual_oversized_intermediate_additions':large,'observed_max_integer_bits':max(max(v[3:]) for v in observed),'budget_recorded_peak':budget.peak_integer_bits,'budget_products':budget.products,'returned_slots':list(map(str,result.slots())),'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2))
