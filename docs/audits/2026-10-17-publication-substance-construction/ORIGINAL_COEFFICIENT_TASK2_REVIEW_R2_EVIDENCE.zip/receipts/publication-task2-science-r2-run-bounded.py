import subprocess,os,json,time,resource
from pathlib import Path
p=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
cmd=[str(p/'.venv/bin/python'),'-B','-m','pytest','tests/test_original_coefficients.py','tests/test_dependency_declaration.py','tests/test_original_coefficient_jets.py','-k','not test_original_full_small_carrier_direct_vs_auxiliary','-vv','-s','-p','no:cacheprovider','--junitxml=/tmp/publication-task2-science-r2-bounded.xml']
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(p)
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:env[k]='1'
t=time.monotonic()
with open('/tmp/publication-task2-science-r2-bounded.log','w') as out,open('/tmp/publication-task2-science-r2-bounded.stderr','w') as err:r=subprocess.run(cmd,cwd=p,env=env,stdout=out,stderr=err)
meta={'argv':cmd,'cwd':str(p),'returncode':r.returncode,'wall_seconds':time.monotonic()-t,'child_peak_RSS_bytes':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'full_scientific_control_run':False}
Path('/tmp/publication-task2-science-r2-bounded-run.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2));assert meta['child_peak_RSS_bytes']<512*1024**2;raise SystemExit(r.returncode)
