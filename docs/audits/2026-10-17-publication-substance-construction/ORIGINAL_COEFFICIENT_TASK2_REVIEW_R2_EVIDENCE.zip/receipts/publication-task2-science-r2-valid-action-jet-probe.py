from fractions import Fraction as F
import json,resource
from src.vestigial import original_coefficients as o
from src.core.formulas import original_spin4_link,original_coframe_blocks
reg=o.OriginalRegulator((1,1,1,1));u=original_spin4_link((0,0,0,1),(0,0,0,1));links={a:u for a in reg.link_order}
frame=o.assemble_coframe(reg,original_coframe_blocks(reg,((0,0,0,0),0,3),links)).to_exterior(reg)
one=o.ExteriorPolynomial(((0,o.Polynomial.scalar(1)),));labels=('t',)
action=o.RawJet(labels,(((),frame),((0,),frame),((0,0),frame*2)))
insertion=o.RawJet.constant(one,labels);measure=o.RawJet.constant(o.Polynomial.scalar(1),labels)
entries=[]
for index in action.indices():
 terms=[]
 for role,jet in [('literal_T',action),('insertion',insertion),('measure',measure)]:
  raw=jet.at(index)
  if role=='measure':words=[(None,raw)]
  else:words=raw.terms
  for mask,p in words:
   gs=() if mask is None else tuple(g for i,g in enumerate(reg.generator_order) if mask>>i&1)
   sup=o.GeneratorLinkSupport(gs,(),tuple(sorted(set(g[0] for g in gs))))
   for monomial,c in p.terms:terms.append(o.GradedTerm(0 if mask is None else mask.bit_count()//2,(0,0),(0,0),(role,),sup,F(1),c,mask,monomial))
 entries.append((index,tuple(terms)))
grading=o.SourceFamilyGrading(tuple(entries));source=o.SourceJet(labels,grading,action,insertion,measure)
support=o.SupportCertificate('tiny actual coframe plus scalar derivative probe',(),grading,True,reg.generator_order,reg.link_order);req=o.CoefficientRequest(None,(),'unit',support)
budget=o.ExactBudget(100000,512*1024**2)
result=o.contract_original(reg,source,req,budget)
# Independently check its actual original T^4=24 top (bounded local algebra).
p=one
with o.ExactBudget(100000,512*1024**2) as control:
 for _ in range(4):p=p*frame
 assert dict(p.terms)[255]==o.Polynomial.scalar(24)
out={'actual_T_power4_top':str(dict(p.terms)[255]),'returned_N':[(str(k),str(v.terms)) for k,v in result.N],'complete':result.support.complete,'correct_derivatives':'1,4,20: top exp((1+t+t^2)T)=(1+t+t^2)^4','products':budget.products,'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
assert out['RSS_bytes']<512*1024**2
assert [o._scalar_value(v) for _,v in result.N]==list(map(o.QComplex,(1,4,20)));print(json.dumps(out,indent=2))
