from fractions import Fraction as F
import json,resource
from src.vestigial import original_coefficients as o
# Independent actual rational C2 cancellation, not a hypothetical cost upper bound.
a=o.RawJet.from_slots(tuple(map(F,[1,1,-1,-200,-200,200])));b=o.RawJet.from_slots(tuple(map(F,[1,200,200,-200,200,200])))
with o.ExactBudget(10000,512*1024**2,integer_bit_limit=8) as cost:r=a*b
assert r.slots()==tuple(map(F,[1,201,199,0,0,0]));assert cost.peak_integer_bits==8
reg=o.OriginalRegulator((1,1,1,1));labels=(0,1);p=o.Polynomial.scalar
zero=o.ExteriorPolynomial();one=o.ExteriorPolynomial(((0,p(1)),));top=o.ExteriorPolynomial(((255,p(1)),));support=o.GeneratorLinkSupport((),(),());full=o.GeneratorLinkSupport(reg.generator_order,reg.link_order,reg.sites)
grade=o.SourceFamilyGrading(tuple((k,() if k else (o.GradedTerm(0,(0,0),(0,0),('action',),support,1,o.QComplex(1),0,()),o.GradedTerm(4,(0,0),(0,0),('insertion',),full,1,o.QComplex(1),255,()),o.GradedTerm(0,(0,0),(0,0),('measure',),support,1,o.QComplex(1),None,()))) for k in o.RawJet.constant(zero,labels).indices()))
source=o.SourceJet(labels,grade,o.RawJet.constant(one),o.RawJet.constant(top),o.RawJet.constant(p(1)))
cert=o.SupportCertificate('fully matched original carrier poison',(),grade,True,reg.generator_order,reg.link_order)
budget=o.ExactBudget(10000,512*1024**2);out=o.contract_original(reg,source,o.CoefficientRequest(None,(),'unit',cert),budget)
assert dict(out.N)[()]==p(F(65,24)) and out.support.complete
receipt={'rational_C2':{'actual_slots':[str(x) for x in r.slots()],'products':cost.products,'reported_peak_bits':cost.peak_integer_bits,'actual_200_plus_200_bits':(200+200).bit_length()},'nonnilpotent_action':{'returned_complete':out.support.complete,'returned_top':str(dict(out.N)[()]),'products':budget.products,'action_fifth_power_body':1},'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'Tiny ROOT source-contract repros only; no scientific coefficient run'}
assert receipt['RSS_bytes']<512*1024**2
print(json.dumps(receipt,indent=2))
