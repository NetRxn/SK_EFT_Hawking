from fractions import Fraction as F
from itertools import combinations
import json,resource
from src.vestigial import original_coefficients as o
r=o.OriginalRegulator((1,1,1,1));pos={g:i for i,g in enumerate(r.generator_order)};x=r.sites[0]
Q=o.QComplex;P=o.Polynomial
matrices=[((1,Q(0,1),2,0),(2,3,1,0),(0,1,4,2),(1,0,0,5)),((1,Q(0,1),2,0),(1,Q(0,1),2,0),(0,1,4,2),(1,0,0,5))]
checks=0
with o.ExactBudget(500000,512*1024**2) as budget:
 for raw in matrices:
  m=o.SparseMatrix(4,tuple(((i,j),P.scalar(v)) for i,row in enumerate(raw) for j,v in enumerate(row)))
  form=m.to_exterior(r);unit=o.ExteriorPolynomial(((0,P.scalar(1)),));exp=unit;power=unit
  from math import factorial
  for k in range(1,5):
   power=power*form;exp+=power*F(1,factorial(k))
  for k in range(5):
   for bars in combinations(range(4),k):
    for psis in combinations(range(4),k):
     ins=unit
     for i in bars:ins=ins*o.ExteriorPolynomial.generator(pos[x,'bar',i])
     for i in psis:ins=ins*o.ExteriorPolynomial.generator(pos[x,'psi',i])
     direct=dict((ins*exp).terms).get(255,P())
     assert direct==o.complementary_insertion(m,bars,psis),(bars,psis,direct,o.complementary_insertion(m,bars,psis))
     checks+=1
 from src.core.formulas import original_scaled_hermite,original_gaussian_moment
 hchecks=0
 for v in (F(2),F(3)):
  for eta in range(5):
   for beta in range(9):
    expanded=sum((c*original_gaussian_moment((d+beta,),v)/v**eta for d,c in original_scaled_hermite(eta,v)),F())
    assert expanded==o.count_hermite_contraction((0,)*eta,(0,)*beta,v),(eta,beta,v)
    hchecks+=1
 print(json.dumps({'minor_checks':checks,'Hermite_checks':hchecks,'products':budget.products,'peak_integer_bits':budget.peak_integer_bits,'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2))
