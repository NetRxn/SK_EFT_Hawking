from fractions import Fraction as F
from itertools import combinations
from math import factorial
import json,resource
from src.vestigial import original_coefficients as o
# A separate plain Fraction exterior implementation on the literal source order.
bars=(0,1,4,5);psis=(2,3,6,7)
def wedge(a,b):
 out={}
 for x,c in a.items():
  for y,d in b.items():
   if x&y:continue
   swaps=sum((y&((1<<i)-1)).bit_count() for i in range(8) if x>>i&1)
   key=x|y;out[key]=out.get(key,F())+c*d*(-1)**swaps
 return {k:v for k,v in out.items() if v}
def word(ids):
 out={0:F(1)}
 for i in ids:out=wedge(out,{1<<i:F(1)})
 return out
def exp_reference(m):
 A={}
 for i in range(4):
  for j in range(4):
   for mask,c in word((bars[i],psis[j])).items():A[mask]=A.get(mask,F())+c*m[i][j]
 result={0:F(1)};power={0:F(1)}
 for k in range(1,5):
  power=wedge(power,A)
  for mask,c in power.items():result[mask]=result.get(mask,F())+c/F(factorial(k))
 return result
matrices=[((1,2,0,1),(0,1,1,0),(2,0,1,1),(1,0,2,1)),((1,2,0,1),(0,1,1,0),(1,2,0,1),(1,0,2,1))]
receipts=[]
for m in matrices:
 E=exp_reference(m);M=o.SparseMatrix(4,tuple(((i,j),m[i][j]) for i in range(4) for j in range(4)))
 count=0
 with o.ExactBudget(100000,512*1024**2) as budget:
  for k in range(5):
   for I in combinations(range(4),k):
    for J in combinations(range(4),k):
     expected=wedge(word(tuple(bars[i] for i in I)+tuple(psis[j] for j in J)),E).get(255,F())
     actual=o.complementary_insertion(M,I,J)
     assert actual==o.Polynomial.scalar(expected),(m,I,J,expected,actual)
     count+=1
 receipts.append({'matrix':m,'all_minor_checks':count,'products':budget.products,'determinant_reference':str(E.get(255,F()))})
assert sum(r['all_minor_checks'] for r in receipts)==140
print(json.dumps({'fixtures':receipts,'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2))
