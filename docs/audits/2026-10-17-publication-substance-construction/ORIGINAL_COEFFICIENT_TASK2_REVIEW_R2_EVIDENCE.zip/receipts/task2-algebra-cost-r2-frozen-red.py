from pathlib import Path
import zipfile,tempfile,importlib.util,sys,hashlib,json,os
P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');sys.path.insert(0,str(P))
archive=P.parent/'.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction/ORIGINAL_COEFFICIENT_TASK2_FROZEN_R1_EVIDENCE.zip'
with tempfile.TemporaryDirectory(prefix='task2-r2-frozen-red-',dir='/tmp') as d:
 d=Path(d);records={}
 with zipfile.ZipFile(archive) as z:
  for path in ['src/vestigial/original_coefficients.py','src/core/formulas.py']:
   data=z.read('candidate/'+path);f=d/Path(path).name;f.write_bytes(data);records[path]=hashlib.sha256(data).hexdigest()
 import src.vestigial,src.core
 for name,filename,parent,attr in [('src.vestigial.original_coefficients','original_coefficients.py',src.vestigial,'original_coefficients'),('src.core.formulas','formulas.py',src.core,'formulas')]:
  spec=importlib.util.spec_from_file_location(name,d/filename);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;setattr(parent,attr,module);spec.loader.exec_module(module)
 print('FROZEN_R1_PRODUCTION_HASHES',json.dumps(records,sort_keys=True),flush=True)
 import pytest
 code=pytest.main(['tests/test_original_coefficient_jets.py','-k','test_r2_scalar_product_counter_covers_actual_operations or test_r2_integer_height_refusal_covers_streams_and_temporaries or test_r2_certificate_rejects_mutable_or_untyped_grading or test_r2_nonzero_raw_source_requires_actual_summand_grading','-vv','-s','-p','no:cacheprovider','--junitxml=/tmp/task2-algebra-cost-r2-frozen-red.xml'])
 raise SystemExit(code)
