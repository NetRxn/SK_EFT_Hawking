from fractions import Fraction as F
import json,resource
from src.vestigial import original_coefficients as o
out={}
# Every supplied primitive product stays inside eight bits; mixed accumulations
# temporarily reach400 then cancel before RawJet's final constructor check.
a=o.RawJet.from_slots((1,1,-1,-200,-200,200))
b=o.RawJet.from_slots((1,200,200,-200,200,200))
with o.ExactBudget(10000,512*1024**2,integer_bit_limit=8) as cost:
 product=a*b
 out['raw_rational_mixed_cancellation']={'slots':[str(v) for v in product.slots()],'peak_integer_bits':cost.peak_integer_bits,'products':cost.products,'uncaught_naive_mixed_partial_sum':400,'partial_sum_bits':400 .bit_length()}
# A nonnilpotent degree-zero action is graded and fully matched; a finite
# exponential must refuse or separately retain its analytic scalar exponential.
r=o.OriginalRegulator((1,1,1,1));support0=o.GeneratorLinkSupport((),(),())
supporttop=o.GeneratorLinkSupport(r.generator_order,(),r.sites)
act=o.ExteriorPolynomial(((0,o.Polynomial.scalar(1)),));top=o.ExteriorPolynomial(((255,o.Polynomial.scalar(1)),));measure=o.Polynomial.scalar(1)
terms=(o.GradedTerm(0,(0,0),(0,0),('action',),support0,F(1),o.QComplex(1),0,()),o.GradedTerm(4,(0,0),(0,0),('insertion',),supporttop,F(1),o.QComplex(1),255,()),o.GradedTerm(0,(0,0),(0,0),('measure',),support0,F(1),o.QComplex(1),None,()))
grading=o.SourceFamilyGrading((((),terms),));source=o.SourceJet((),grading,o.RawJet.constant(act,()),o.RawJet.constant(top,()),o.RawJet.constant(measure,()),order=0,insertion_id='top')
certificate=o.SupportCertificate('complete exact tiny body probe',(),grading,True,r.generator_order,r.link_order)
request=o.CoefficientRequest(None,(),'top',certificate)
cost=o.ExactBudget(10000,512*1024**2)
result=o.contract_original(r,source,request,cost)
out['nonnilpotent_action_body']={'coefficient':str(dict(result.N)[()].terms),'complete':result.support.complete,'products':cost.products,'correct_analytic_value':'exp(1), not truncated sum 65/24','actual_truncated_sum':str(sum((F(1,o.checked_factorial(k)) for k in range(5)),F()))}
out['RSS_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
assert out['RSS_bytes']<512*1024**2
print(json.dumps(out,indent=2))
