from fractions import Fraction as F
import json,resource
from src.vestigial import original_coefficients as o
out={}
a=o.RawJet((0,),(((),F(1)),((0,),F(1))))
b=o.RawJet((0,),(((),F(127,6)),((0,),F(-127,10))))
with o.ExactBudget(1000,512*1024**2,integer_bit_limit=8) as cost:
 value=a*b
 out['raw_fraction_jet_add']={'result':str(value.at((0,))),'peak_integer_bits':cost.peak_integer_bits,'products':cost.products,'actual_native_fraction_cross_numerators':[127*3,127*5]}
try:
 with o.ExactBudget(1000,512*1024**2,integer_bit_limit=8):o.rational_add(F(127,6),F(-127,10))
except o.BudgetExceeded:out['checked_sum_refuses']=True
out['RSS_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(json.dumps(out,indent=2))
reg=o.OriginalRegulator((1,1,1,1));unit=o.ExteriorPolynomial(((0,o.Polynomial.scalar(1)),));top=o.ExteriorPolynomial(((255,o.Polynomial.scalar(1)),));empty=o.GeneratorLinkSupport((),(),())
terms=(o.GradedTerm(0,(0,0),(0,0),('action',),empty,F(1),o.QComplex(1),0,()),o.GradedTerm(4,(0,0),(0,0),('insertion',),o.GeneratorLinkSupport(reg.generator_order,reg.link_order,reg.sites),F(1),o.QComplex(1),255,()),o.GradedTerm(0,(0,0),(0,0),('measure',),empty,F(1),o.QComplex(1),None,()))
grade=o.SourceFamilyGrading((((),terms),));source=o.SourceJet((),grade,o.RawJet.constant(unit,()),o.RawJet.constant(top,()),o.RawJet.constant(o.Polynomial.scalar(1),()))
cert=o.SupportCertificate('constant action admitted as original complete',(),grade,True,reg.generator_order,reg.link_order)
budget=o.ExactBudget(10000,512*1024**2)
result=o.contract_original(reg,source,o.CoefficientRequest(None,(),'unit',cert),budget)
print(json.dumps({'action_body_nonzero_accepted':True,'complete':result.support.complete,'returned_top':str(dict(result.N)[()]),'products':budget.products,'action_fifth_nonzero':bool((unit*unit*unit*unit*unit).terms),'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2))
r=o.OriginalRegulator((2,1,1,1));x,y=r.sites;pos={g:i for i,g in enumerate(r.generator_order)}
mask=(1<<pos[x,'bar',0])|(1<<pos[y,'psi',0]);bilinear=o.ExteriorPolynomial(((mask,o.Polynomial.scalar(1)),))
with o.ExactBudget(10000,512*1024**2,integer_bit_limit=8) as c:
 got=o.exterior_phase_derivative(bilinear,r,{x:F(127,10),y:F(127,6)})
 print(json.dumps({'phase_charge_sum':str(got),'peak_integer_bits':c.peak_integer_bits,'products':c.products,'native_cross_numerators':[381,635]}))
n=(1<<1023)-1
a=o.RawJet((0,),(((),F(1)),((0,),F(1))))
b=o.RawJet((0,),(((),F(n,6)),((0,),F(-n,10))))
with o.ExactBudget(1000,512*1024**2) as c:
 got=a*b
 print(json.dumps({'DEFAULT_1024_raw_fraction_height_bypass':got.at((0,))==F(n,15),'peak_integer_bits':c.peak_integer_bits,'native_cross_widths':[(3*n).bit_length(),(5*n).bit_length()],'result_width':got.at((0,)).numerator.bit_length(),'products':c.products}))
