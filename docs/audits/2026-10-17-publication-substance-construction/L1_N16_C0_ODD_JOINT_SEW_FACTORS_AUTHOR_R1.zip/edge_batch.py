from ast import literal_eval
from hashlib import sha256
from pathlib import Path
import subprocess
import sys

out=Path('edge-batch')
out.mkdir()
log=[]
for index,line in enumerate(l for l in Path('edge-plan.out').read_text().splitlines() if l.startswith('pattern ')):
    text=line.removeprefix('pattern ')
    close=text.rindex(')')
    a,b,s,t=literal_eval(text[:close+1])
    products=int(text.split()[-1])
    assert products<=4_000_000
    command=[sys.executable,'edge_exact.py',sys.argv[1],str(a),str(b),repr(s),repr(t)]
    try:
        receipt=subprocess.run(command, text=True,capture_output=True,check=True)
    except subprocess.CalledProcessError as error:
        print(index,a,b,s,t,'REFUSED',error.stderr.rstrip(),flush=True)
        continue
    path=out/f'{index:02}.tsv'
    Path('edge-selected.tsv').replace(path)
    print(index,receipt.stdout.strip(),sha256(path.read_bytes()).hexdigest(),flush=True)
