from ast import literal_eval
from collections import defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import Polynomial, QComplex, Symbol, haar_polynomial
import sys

rows=[]
for line in Path('mixed-odd-control.tsv').read_text().splitlines()[::433]:
    first,second,mask,x,y,r,i=line.split('\t')
    rows.append((literal_eval(first),literal_eval(second),literal_eval(mask),literal_eval(x),literal_eval(y),QComplex(Fraction(r),Fraction(i))))
assert len(rows)==8
raw=defaultdict(list)
for o,a,mask,index,r,i in (map(int,line.split()) for line in Path(sys.argv[1]).read_text().splitlines()):
    raw[o,a].append((mask,index,QComplex(r,i)))
q=[Polynomial.variable(Symbol('q',(j//8,1,'L' if j%8<4 else 'R',j%4))) for j in range(16)]
signed_inverse=(q[0],-q[1],-q[2],-q[3])
V=original_spin4_link(signed_inverse,(1,0,0,0))
for word0,word1,mask,x,y,expected in rows:
    assert all(s==(0,0) for s in (*x[2:],*y))
    # Literal multiplication of the three linear coframes in owner order.
    polynomial=Polynomial()
    for terms in product(*(raw[o,a] for o,word in enumerate((word0,word1)) for a in word)):
        m=0
        val=QComplex(1)
        for n,index,z in terms:
            if n&~mask or m&n:break
            parity=sum((n&((1<<j)-1)).bit_count() for j in range(16) if m>>j&1)
            val*=z*(-1 if parity%2 else 1)
            m|=n
        else:
            assert m==mask
            z=Polynomial.coerce(val)
            for _,index,_ in terms:z*=q[index]
            polynomial+=z
    answer=haar_polynomial(polynomial*V[x[0][0]][x[1][0]])
    assert answer==Polynomial.coerce(expected)
    print(word0,word1,mask,x,expected.real,expected.imag)
