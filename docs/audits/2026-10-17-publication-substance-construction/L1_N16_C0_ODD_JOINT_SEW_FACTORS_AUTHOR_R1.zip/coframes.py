from collections import defaultdict
from itertools import combinations_with_replacement
from pathlib import Path
import sys

LINEAR_ROWS=64
WORK_LIMIT=20_000_000
ROW_LIMIT=400_000
src=defaultdict(dict)
for owner,a,mask,q,r,i in (map(int,row.split()) for row in Path(sys.argv[1]).read_text().splitlines()):
    assert owner in (0,1) and a in range(4) and q in range(16)
    assert mask.bit_count()==2 and (mask&255).bit_count()==1
    assert abs(r)+abs(i)==1 and (mask,q) not in src[owner,a]
    src[owner,a][mask,(q,)]=r,i
assert len(src)==8 and all(len(f)==LINEAR_ROWS for f in src.values())

def wedge(a,b):
    return -1 if sum((b&((1<<i)-1)).bit_count() for i in range(16) if a>>i&1)%2 else 1

def join(a,b):
    work=len(a)*len(b)
    if work>WORK_LIMIT:raise ValueError(('coframe work refusal',work))
    out={}
    for (am,aq),(ar,ai) in a.items():
        for (bm,bq),(br,bi) in b.items():
            if am&bm:continue
            s=wedge(am,bm)
            k=am|bm,tuple(sorted(aq+bq))
            r,i=out.get(k,(0,0))
            if k not in out and len(out)>=ROW_LIMIT:raise ValueError(('coframe row refusal',len(out)))
            r+=s*(ar*br-ai*bi);i+=s*(ar*bi+ai*br)
            if r or i:out[k]=r,i
            else:out.pop(k,None)
    return out,work

assert wedge(1,2)==1 and wedge(2,1)==-1
tables=[{():{(0,()):(1,0)}} for _ in range(2)]
with Path('coframe-roster.tsv').open('w') as out:
    for owner in range(2):
        for degree in range(1,5):
            nrows=work=0
            for word in combinations_with_replacement(range(4),degree):
                prev=tables[owner][word[:-1]]
                rows,cost=join(prev,src[owner,word[-1]])
                assert all((mask&255).bit_count()==(mask>>8).bit_count()==degree for mask,_ in rows)
                if degree<4:tables[owner][word]=rows
                nrows+=len(rows);work+=cost
                for (mask,indices),(re,im) in sorted(rows.items()):
                    print(owner,','.join(map(str,word)),mask,','.join(map(str,indices)),re,im,sep='\t',file=out)
            print(owner,degree,work,nrows,flush=True)
