# L1 odd-root pilot signed site and spatial factors

Author checkpoint from the nine support candidates at e9678295f. The
pilot coefficient remains unevaluated. The original coframe source is
AUTHOR/coframes.tsv from the frozen earlier square author package.
The pilot's root/anchor tensors are from
L1_N16_C0_ODD_JOINT_PILOT_AUTHOR_R1.zip, unchanged.

Coframe words are sorted within an owner because coframe bilinears have
even exterior degree. Each product accumulates the explicit exterior
sign within an edge. The matched work is planned from only the
compatible anchor monomials, and actual exact rows retain both owner
words, the lower and upper endpoint masks, and both anchor matrix
indices. The direct literal check multiplies all three linear coframes
and the original inverse link matrix before Haar integration for eight
selected nonzero mixed-owner factor entries. It reproduces their real
and imaginary parts. This is an author control.

Site factors use the power and Fourier channel of every original root.
They match coframe words across all three spatial directions and require
an exact disjoint complement of the first two generator masks in
the third. The local sign follows the incident order induced by the
same lexicographic edge order on the whole layer. Grouping the two
endpoint blocks from each edge into site order incurs a fixed sign,
because the block degrees depend only on the occupation. Both pilot
layers have positive cross-site sign. For each layer, 128 literal
64-bit wedge products independently match the predicted combination
of site signs and the cross-site sign.

All 25 unique edge factors completed under four million planned
matched products per pattern, with 216,200 total nonzero rows and
60,928 in the largest table. All 144 site factors completed, with
2,509,824 nonzero rows in total, 62,592 in the largest table, and
66,816 as the largest planned exact root-matrix product count after
the local generator supports were chosen. No site tensor was empty.
The diagnostic reports do not bound subsequent joins or certify
a complete nonzero integral.

Next wire the root trace to its four factors. Walk the ordered
plaquette as V_x B V_y^-1 A^-1, with A in the owner's layer.
The site table's Fourier matrix indices are (i4,i0).
Use (i0,i1) on V_x, (i1,i2) on B, (i2,i3) on V_y^-1 and
(i3,i4) on A^-1. Reverse the temporal link representation for
the other layer as required by its original traversal.
The index convention needs a literal finite link control before
full sewing. Measure planned matched products by tensor cut before
multiplication, using the original site labels and preserving all
factorials. Temporal component shapes can be reused after verifying
that the boundary matrix indices agree. No residual row is subtracted.

## Replay

EXISTING points to the extracted e9678295f pilot. COFRAMES points to
the frozen prior coframes.tsv, and PY is the Python interpreter with
NumPy available. Use the pinned science checkout as PYTHONPATH for
the literal control. Use a clean scratch directory for replay. The
coframe, edge and site tables are regenerated locally. They occupy
several hundred MB. The edge and site table hashes are recorded
in regenerated-tables.sha256.

```sh
python3 coframes.py "$COFRAMES" > coframes.out
python3 edge_plan.py "$EXISTING" > edge-plan.out
python3 edge_batch.py "$EXISTING" > edge-batch.out
python3 site_exact.py "$EXISTING" > site-exact.out
python3 sign_control.py > signs.out
cmp mixed-odd-control.tsv edge-batch/08.tsv
"$PY" edge_literal.py "$COFRAMES" > edge-literal.out
shasum -a 256 -c regenerated-tables.sha256
```
