from itertools import product
from math import prod
from random import Random

roster=[a for a in product(range(5),repeat=3) if sum(a)<=4]
rng=Random(251)
def inversions(a,b):
    return sum((b&((1<<i)-1)).bit_count() for i in range(a.bit_length()) if a>>i&1)
for code in (103607566400,1256282136720):
    occ=[roster[(code>>(6*x))&63] for x in range(8)]
    edges=[(u,u^(1<<k),sum(occ[u])-occ[u][k]+sum(occ[u^(1<<k)])-occ[u^(1<<k)][k])
           for u in range(8) for k in range(3) if not u>>k&1]
    L=[(u,v,d) for u,v,d in edges if d]
    # Adjacent transposition count from edge-contiguous to site-contiguous
    # storage. For each inversion both endpoint mask degrees are fixed.
    cross=sum(a[2]*b[2]*(u>v) for i,a in enumerate(L) for b in L[i+1:] for u in a[:2] for v in b[:2])
    signs=set()
    for _ in range(128):
        used=[0]*8
        order=[rng.sample(range(8),8) for _ in range(8)]
        full=0; literal=0; local=0
        merged=[0]*8
        for u,v,d in L:
            masks=[]
            for x in (u,v):
                m=sum(1<<i for i in order[x][used[x]:used[x]+d])
                assert m.bit_count()==d
                used[x]+=d
                local+=inversions(merged[x],m)
                merged[x]|=m
                masks.append(m)
            factor=(masks[0]<<(8*u))|(masks[1]<<(8*v))
            literal+=inversions(full,factor)
            full|=factor
        assert used==[8]*8 and full==(1<<64)-1
        assert (literal-local-cross)%2==0
        signs.add(cross%2)
    print(code,'attains full degree, cross-site parity',signs.pop(),'128 literal agreement controls')
