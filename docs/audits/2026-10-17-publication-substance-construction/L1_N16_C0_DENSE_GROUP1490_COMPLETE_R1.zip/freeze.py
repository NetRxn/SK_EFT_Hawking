"""Verify frozen signed receipts and create the portable review archive."""
from csv import DictReader
from hashlib import sha256
from pathlib import Path
import json
from zipfile import ZipFile, ZIP_DEFLATED

GROUP=1490
LIVE=(0,1,2,3,4,6)
root=Path('.')
manifest=Path('MANIFEST.sha256')
archive=Path(f'l1-group{GROUP}-complete-independent-review.zip')

for label in LIVE:
    folder=Path('author')/f'L{label}'
    listed=(folder/'operand.sha256').read_text().splitlines()
    confirmed=(folder/'operand-verify.out').read_text().splitlines()
    assert len(listed)==len(confirmed) and all(line.endswith(': OK') for line in confirmed)
    status=(folder/'replay-guarded.out').read_text()
    pins=json.loads((folder/'pins.json').read_text())
    if pins['mode']=='triangle':
        assert f'whole original L{label} exact terminal triangle ready' in status
        assert f'whole original L{label} triangle raw ' in (folder/'triangle-replay.out').read_text()
        assert 'both author signed sums agree' in (folder/'triangle-interval-audit.out').read_text()
    else:
        assert pins['mode']=='scalar' and f'whole original L{label} raw ' in status

with Path('native-caps.tsv').open() as f:
    native=list(DictReader(f,delimiter='\t'))
    assert tuple(int(row['ordinal']) for row in native)==LIVE
    assert all(int(row['crossing_rows'])==500_001 for row in native)
with Path('signed-work.tsv').open() as f:
    work=list(DictReader(f,delimiter='\t'))
    assert len(work)==sum(json.loads((Path('author')/f'L{x}'/'pins.json').read_text())['passes'] for x in LIVE)
    for row in work:
        products=int(row['finished_products'])+int(row['refused_visit_products'])
        assert products<=(40_000_000 if row['pass']=='1' else 20_000_000)
with Path('continuation-refusals.tsv').open() as f:
    refusals=list(DictReader(f,delimiter='\t'))
    assert all(row['type']=='rows' and row['independent_visits']==row['author_visits'] and
               int(row['crossing_rows'])==500_001 and int(row['forecast'])<=8_000_000
               for row in refusals)

source=Path('l1-component14-remaining-preparation-independent.zip')
assert sha256(source.read_bytes()).hexdigest()=='11a4aa7e219c2a727a8a118a9910a8665bef7ed135ebd5531b3d30d926cfb56b'

files=sorted(p for p in root.rglob('*') if p.is_file() and p not in (manifest,archive)
             and '__pycache__' not in p.parts)
assert not any(path.suffix=='.pkl' for path in files)
manifest.write_text(''.join(f'{sha256(path.read_bytes()).hexdigest()}  {path}\n' for path in files))
with ZipFile(archive,'w',compression=ZIP_DEFLATED) as z:
    for path in files+[manifest]:
        z.write(path,str(path))
with ZipFile(archive) as z:
    assert z.testzip() is None
    for line in z.read(str(manifest)).decode().splitlines():
        digest,path=line.split(maxsplit=1)
        assert sha256(z.read(path)).hexdigest()==digest
print('Verified archive manifest members',len(files),archive,sha256(archive.read_bytes()).hexdigest())
