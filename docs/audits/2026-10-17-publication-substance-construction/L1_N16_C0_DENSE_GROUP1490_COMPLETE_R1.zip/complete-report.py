"""Add exact retally and independent measured-scope readbacks to the report."""
from csv import DictReader
from pathlib import Path
from re import M,search
import json

f=Path('REVIEW.md')
heading='## Exact retally and work'
s=f.read_text().split(heading,1)[0]+heading+'\n'
summary=Path('retally.out').read_text()
sr,den=search(r'^raw Gaussian sum (-?\d+) 0 factor denominator (\d+)',summary,M).groups()
value=search(r'^physical weighted (-?\d+/\d+) 0',summary,M)[1]
prep,guard,cont,terminal,total=search(r'^author measured seconds ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)',summary,M).groups()
walls=search(r'^author sum of solve walls plus shared preparation ([\d.]+)',summary,M)[1]
ip,ig,ic,it=search(r'^independent measured preparation/native/retained pass sums ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)',summary,M).groups()
iw=search(r'^independent sum of preparation, native and continuation walls ([\d.]+)',summary,M)[1]
refusals=int(search(r'^verified continuation refusals (\d+)',summary,M)[1])
controls=Path('author/L0/native-order-control.out').read_text()
r=json.loads(search(r'^reverse-order audit (.*)',controls,M)[1])
o=json.loads(search(r'^original-order audit (.*)',controls,M)[1])
assert (r['visited'],r['supported'],r['peak_rows'],r['output_rows'])==(1711360,1688320,386844,376960)
assert (o['visited'],o['supported'],o['peak_rows'])==(1260046,1243656,500001)
with Path('native-caps.tsv').open() as z:
    caps=list(DictReader(z,delimiter='\t'))
with Path('signed-work.tsv').open() as z:
    passes=list(DictReader(z,delimiter='\t'))
with Path('timing.tsv').open() as z:
    timers=list(DictReader(z,delimiter='\t'))
third=sum(float(row['independent_extra_s']) for row in timers)
native=sum(int(r['used_before']) for r in caps)
done=sum(int(r['finished_products']) for r in passes)
refused=sum(int(r['refused_visit_products']) for r in passes)
s+=f'''
The exact raw Gaussian sum is ({sr}, 0) at factor denominator {den}.
Applying the original physical divisor and cover coefficient 192 once
gives **{value} + 0i**.

The evidence covers six native row caps, {len(passes)} retained passes
and {refusals} continuation row refusals. Accepted native joins visited
{native:,} products. Retained continuations accepted {done:,} products,
with {refused:,} visits in refused attempts. On L0 the alternate reverse
guard traversal of pair (0,3) visits all 1,711,360 forecasted products,
with 1,688,320 peer-supported products, a 386,844-row peak and 376,960
rows on completion in {r['elapsed_seconds']} seconds. The original
traversal on the same pinned operands crosses the 500,000-row guard
at 1,260,046 visits and 1,243,656 peer-supported products in
{o['elapsed_seconds']} seconds. These measured controls retain the
same 20-factor original scope and 2,510,784 preceding accepted product
visits, and leave the commissioned signed route unchanged.

Measured author components sum to {total} seconds, covering {prep}
preparation, {guard} native guarding, {cont} retained continuation
and {terminal} separate terminal work. Original solve walls plus shared
preparation sum to {walls} seconds, with separate terminal jobs additional.
Independent preparation/native guarding/retained stages measure {ip},
{ig} and {ic} seconds, totaling {it}. Independent measured full preceding
phase walls sum to {iw} seconds. The independent extra terminal replays
take {third:.6f} seconds total. These are stage or per-label sums.

## Reproduction

Verify the archive and every original operand manifest. The archive
contains the exact accepted preparation review. The large numerical
operands remain external and checksum-bound. Replay scripts default to
the original author cached-original-roster directory. Set
L1_GROUP1490_AUTHOR_ROOT to the same-layout frozen author path if moved.

'''
for n in (0,1,2,3,4,6):
    d=Path('author')/f'L{n}'
    pin=json.loads((d/'pins.json').read_text())
    if pin['mode']=='triangle':
        t=(d/'triangle-replay.out').read_text()
        count=int(search(r'^independent third anchor forecast \d+ \d+ (\d+)',t,M)[1])
        s+=f'The L{n} independent third pivot covers {count:,} compatible products and agrees with both original pivot sums and their shard coverage.\n\n'
s+='The following commands regenerate the signed evidence and original guarded control.\n\n'
for n in (0,1,2,3,4,6):
    pin=json.loads((Path('author')/f'L{n}'/'pins.json').read_text())
    s+=f'    bash replay-label.sh {n} {pin["passes"]} {pin["mode"]} author-order\n'
s+='    python3 -B native-order-control.py 0\n    python3 -B retally.py /path/to/publication-checkpoint\n'
f.write_text(s)
