"""Test the transient L0 row guard in two orders on the same cap inputs."""
import json
from source import CAP_SHA,ROW_LIMIT,join,origin,read,sha

assert sha(origin)==CAP_SHA
cap=read(origin)
i,j=cap['rejected_pair']
factors=cap['factors']
left,right=factors[i],factors[j]
peers=[f for k,f in enumerate(factors) if k not in (i,j)]
expected=cap['matched']
assert expected==1_711_360
reverse_audit={}
original_audit={}
reverse=join(left,right,peers,expected,stop_at_cap=True,audit=reverse_audit)
assert len(reverse)==3 and len(reverse[1])<=ROW_LIMIT
original=join(left,right,peers,expected,stop_at_cap=True,forward=True,audit=original_audit)
assert len(original)==2 and original[1]==ROW_LIMIT+1
print('same L0 signed operands',sha(origin),'pair',i,j,'prejoin factors',len(factors),
      'prejoin accepted visit count',cap['used_before'],'planned products',expected,'row limit',ROW_LIMIT)
print('alternate reverse traversal completes with rows',len(reverse[1]))
print('original traversal crosses transient row guard at visits and rows',*original)

assert reverse_audit['visited']==expected and original_audit['visited']==original[0]
print('reverse-order audit',json.dumps(reverse_audit,sort_keys=True))
print('original-order audit',json.dumps(original_audit,sort_keys=True))
