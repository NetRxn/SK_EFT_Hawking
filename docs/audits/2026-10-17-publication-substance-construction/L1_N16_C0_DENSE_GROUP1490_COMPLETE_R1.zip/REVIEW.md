# Independent complete signed Group 1490 review

Group 1490 lies on the accepted selected side of component 14. Its
original gamma3 partner is Group 2660. The accepted total transport
phase is +1 and the cover coefficient is 192. This coefficient includes
occupation weight 48, gamma3 multiplicity two and geometric side
multiplicity two. The original physical divisor is 16 × 4^64.

The work-start packet was fresh at 085be20e08752d1c77668c2e097fc7ed32e948b0.
The nested preparation review at SHA-256
11a4aa7e219c2a727a8a118a9910a8665bef7ed135ebd5531b3d30d926cfb56b
reconstructs the 252 original source blocks, exact eight-term roster
and every one of the 88 prepared signed tables. Its Group 1490 prepared
frontier SHA-256 is
2e5e972a63f5808a32faf2f50a64122f7b16b44c8f74f593870639d4cb3bf451.
The two signed sweeps reduce 2,429,350 rows to 776,530 and then 598,145.
They visit 22,956,753 input rows within the original 60-million-row
preparation limit. Original ordinals 5 and 7 are exact zero from
the same seven empty restrictions. Their original coordinate keys
remain in the scalar ledger.

## Exact signed guard and continuation

The reviewer releases only the six original live ordinals 0, 1, 2, 3,
4 and 6 after verifying signed row selection, native cap reconstruction
and retained exact continuation. Each native signed slice is inverse-lifted
into the same original prepared parent. Continued stages independently
reconstruct exact signed splits, quotient folds, peer projections,
visit counts and every retained table. Original traversal order retains
the transient row-guard count under exact Gaussian accumulation. The
archive records both the cap scope and its associated accepted and refused
visit counts.

## Exact retally and work

The exact raw Gaussian sum is (-29917724822949898358333145705742209769626415865708519111000064, 0) at factor denominator 395180970918602703540468584546304.
Applying the original physical divisor and cover coefficient 192 once
gives **-7097474090495283928414711389/2658455991569831745807614120560689152 + 0i**.

The evidence covers six native row caps, 14 retained passes
and 24 continuation row refusals. Accepted native joins visited
28,213,256 products. Retained continuations accepted 72,947,232 products,
with 33,108,713 visits in refused attempts. On L0 the alternate reverse
guard traversal of pair (0,3) visits all 1,711,360 forecasted products,
with 1,688,320 peer-supported products, a 386,844-row peak and 376,960
rows on completion in 4.954529 seconds. The original
traversal on the same pinned operands crosses the 500,000-row guard
at 1,260,046 visits and 1,243,656 peer-supported products in
4.311142 seconds. These measured controls retain the
same 20-factor original scope and 2,510,784 preceding accepted product
visits, and leave the commissioned signed route unchanged.

Measured author components sum to 493.086892 seconds, covering 30.6
preparation, 171.072732 native guarding, 280.49416 retained continuation
and 10.92 separate terminal work. Original solve walls plus shared
preparation sum to 496.3 seconds, with separate terminal jobs additional.
Independent preparation/native guarding/retained stages measure 33.936658,
207.599328 and 321.410121 seconds, totaling 562.946107. Independent measured full preceding
phase walls sum to 568.078782 seconds. The independent extra terminal replays
take 8.626747 seconds total. These are stage or per-label sums.

## Reproduction

Verify the archive and every original operand manifest. The archive
contains the exact accepted preparation review. The large numerical
operands remain external and checksum-bound. Replay scripts default to
the original author cached-original-roster directory. Set
L1_GROUP1490_AUTHOR_ROOT to the same-layout frozen author path if moved.

The L3 independent third pivot covers 13,762,560 compatible products and agrees with both original pivot sums and their shard coverage.

The following commands regenerate the signed evidence and original guarded control.

    bash replay-label.sh 0 2 scalar author-order
    bash replay-label.sh 1 2 scalar author-order
    bash replay-label.sh 2 2 scalar author-order
    bash replay-label.sh 3 2 triangle author-order
    bash replay-label.sh 4 3 scalar author-order
    bash replay-label.sh 6 3 scalar author-order
    python3 -B native-order-control.py 0
    python3 -B retally.py /path/to/publication-checkpoint
