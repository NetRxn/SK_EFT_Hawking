from pathlib import Path
import hashlib,json,ast,re,xml.etree.ElementTree as ET
P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');before=Path('/tmp/publication-task2-r3-preimage');owned=['src/core/formulas.py','src/vestigial/original_coefficients.py','tests/test_original_coefficient_jets.py']
source={name:{'sha256':hashlib.sha256((P/name).read_bytes()).hexdigest(),'bytes':(P/name).stat().st_size,'lines':len((P/name).read_bytes().splitlines())} for name in owned}
full=json.loads(Path('/tmp/publication-task2-r3-bounded-final-receipt.json').read_text());assert full['exit_code']==0 and full['suite']['tests']=='109' and full['suite']['failures']=='0' and full['suite']['errors']=='0' and full['suite']['skipped']=='0'
red=json.loads(Path('/tmp/publication-task2-r3-red-archive-receipt.json').read_text());redxml=ET.parse('/tmp/publication-task2-r3-red-archive.xml').getroot().find('testsuite');assert redxml.attrib['failures']=='13' and redxml.attrib['tests']=='16' and redxml.attrib['errors']=='0'
log=Path('/tmp/publication-task2-r3-bounded-final.log').read_text();counts=[{'node':m[0],'outer_products':int(m[1])} for m in re.findall(r'SCALAR_PRODUCTS\s+(\S+)\s+(\d+)',log)];assert len(counts)==104
final=json.loads(Path('/tmp/publication-task2-r3-final-continuity.json').read_text());assert not final['fresh'] and final['changed']==['owned-files','source']
oldast=ast.parse((before/owned[1]).read_text());newast=ast.parse((P/owned[1]).read_text());oldnodes={n.name:n for n in oldast.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))};newnodes={n.name:n for n in newast.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))};changed=[name for name in oldnodes if ast.dump(oldnodes[name])!=ast.dump(newnodes[name])];assert changed==['RawJet','SourceJet','exterior_phase_derivative'];methods={}
for name in ['RawJet','SourceJet']:
 oldmethods={n.name:ast.dump(n) for n in oldnodes[name].body if isinstance(n,ast.FunctionDef)};newmethods={n.name:ast.dump(n) for n in newnodes[name].body if isinstance(n,ast.FunctionDef)};methods[name]=[m for m in oldmethods if oldmethods[m]!=newmethods[m]]
assert methods=={'RawJet':['__mul__'],'SourceJet':['__post_init__']}
assert (before/owned[0]).read_bytes()==(P/owned[0]).read_bytes();assert (P/owned[2]).read_bytes().startswith((before/owned[2]).read_bytes())
cost={'old_domination_core':175370240,'pair_sign_correction':78336,'corrected_core_ceiling':175448576,'final_Haar_bucket_scales':1000000,'full_auxiliary_W_Gaussian_frame':10000000,'direct_interactions_frame':3000000,'literal_H_source_frame_quotient_evaluation':16000000,'remaining_geometry_construction_margin':19921664,'complete_prospective_total':225370240,'unchanged_scientific_product_limit':250000000,'unchanged_scientific_storage_limit':2*1024**3,'unchanged_integer_bit_limit':1024,'actual_full_scientific_count':None}
assert sum(cost[k] for k in ['corrected_core_ceiling','final_Haar_bucket_scales','full_auxiliary_W_Gaussian_frame','direct_interactions_frame','literal_H_source_frame_quotient_evaluation','remaining_geometry_construction_margin'])==225370240
md=f'''# Original coefficient Task2 R3 repair handoff

**SOURCE_REPAIRED_BOUNDED_GREEN; different complete science and algebra/cost review still required.** The full original scientific test remains UNEXECUTED / UNADMITTED. No actual complete coefficient, scientific product/height/RSS/time census, Task2 completion, physical/B3, main, publication or human acceptance is claimed.

## Authority and exact ownership

FIRST action was the assigned SAME continuity packet check from PRIMARY: exit0, fresh=true, changed=[]. I read the packet/notebook, both COMPLETE independent R2 reports, canonical finding context, governing scientific/continuity contracts and actual source/diff before editing. I applied review-reception and TDD guidance. Only the assigned domain module and jet-test file changed; the assigned canonical formulas file remains byte-identical. No peer edit was reverted.

No Git, Lean/LSP, build, dependency/cache repair, controller/process/slot, roadmap/notebook/packet, registry/ledger/closure, web/network or scientific campaign operation occurred. ROOT owns all integration/closure/runtime decisions. Final SAME packet is intentionally stale ONLY for owned-files/source, without refresh.

## Complete repair of both R2 residual roots

**Finding1.2 — rational intermediate sums.** RawJet.__mul__ now routes int/Fraction accumulations through the EXISTING rational_add, after the existing checked product primitive. QComplex/Polynomial/ExteriorPolynomial additions retain their already checked type-specific paths. No coefficient product is double billed. The actual original exterior_phase_derivative validates each used real exact charge with _rational and accumulates signed charges with rational_add, replacing the native Fraction sum. The fixed bar/psi sign uses negation, which changes no integer width or logical coefficient-product unit.

New regressions cover8-bit AND actual default1024-bit hidden numerator-product escapes, an actual mixed partial that reaches400 before cancellation, and oversized phase inputs whose charges cancel tozero. Higher-limit counterparts preserve exact derivatives n/15 and original current phase i*n/15; the mixed C2 product retains exactly17 logical coefficient products. Original one-label raw product retains7, and the actual one-term current helper retains1. Both numerator/denominator cross-products and accumulated numerators now pass through the existing height/integer counters BEFORE Fraction normalization can hide them.

The surrounding exact-scalar paths were audited: RawJet.__add__, exponential_jet, Gaussian/Hermite/moment kernels, normalization/log/Hessian and Polynomial/QComplex accumulation already use checked exact operations. Remaining native sum/prod sites in this domain concern integer support/index/storage metadata or values whose Polynomial/QComplex operations are checked. The generic hermite_weight already refuses X-constant source terms, so no redundant body mechanism was added there.

**Finding1.1 — actual nilpotent action family.** SourceJet validates the ACTUAL collected action in EACH declared value/first/repeated/mixed slot has positive even exterior degree, after matching its exact typed grading. A nonzero degree-zero scalar or formal-source body now refuses before finite4V exponential completeness is asserted. All six C2 slots are covered, not only the base action. The existing derivative-scope check already refuses nonzero hidden higher contacts.

The check intentionally does NOT ban scalar insertion/measure bodies or individually cancelling pre-collection action pieces. Exact +1/−1 action-body pieces can remain recorded in grading while their actual collected body iszero. New actual original one-site coframe controls independently establish T^4=24top, retain A(t)=(1+t+t²)T derivatives(1,4,20), and retain the moving scalar measure(3+t) result(3,13,68). No lower cutoff, generic odd-H exclusion, deleted support certificate, source-roster shrink or analytic body approximation was introduced.

## Actual RED and GREEN evidence

The complete16new R3 cases were FIRST run against the immutable frozen R2 archive, whose SHA256 is a4cdbfa940fae240c09c55f2d1882146111a29f092333991b790da47b56680d7. Both production modules were loaded from archive bytes with hashes independently compared against its manifest. Actual result: **13 intended failures,3 positive controls passed,zero errors**,0.50s, native process peak129548288bytes. Every failure is the expected missing refusal, not a fixture/import error. The42 other cases in that jet file were deselected; no expensive scientific control ran.

After the minimal three-definition repair, all16new cases pass. The complete admitted affected regression then passed109tests. A final run explicitly cleared the default marker filter with -m '' so the only deselection is the original full scientific test:

`.venv/bin/python -B -m pytest -m '' tests/test_original_coefficients.py tests/test_dependency_declaration.py tests/test_original_coefficient_jets.py -k 'not test_original_full_small_carrier_direct_vs_auxiliary' -vv -s -p no:cacheprovider --junitxml=/tmp/publication-task2-r3-bounded-final.xml`

Final actual exit0: **109PASS/1DESELECTED**,26.01s;0failures/errors/skips. Native process peak **258064384bytes** (<512MiB). Numeric thread pools all1, no bytecode or pytest cache. XML/companion JSON preserve all109selected IDs. There are104 reported outer-fixture product counters, maximum{max(x['outer_products'] for x in counts)}, sum{sum(x['outer_products'] for x in counts)}; the five static dependency checks have no invented scalar count. Nested refusal/positive-budget counts are separate from outer counters. RSS is whole shared-process high-water, not an isolated per-fixture allocation. No new skip/xfail or environment bypass was added to the scientific test.

## Corrected full-source prospective cost, unchanged ceiling

These are conservative SOURCE allocations, not actual scientific measurements. R2 review identified78336additional explicit exterior-pair sign products missing from the old95744pair-build subtotal. R3 makes that correction explicit and funds it from the SAME existing20Mconstruction margin; it does not increase the complete225370240prospective envelope or250Mactual hard limit.

| Complete phase | Prospective scalar-product ceiling | Accounting |
|---|---:|---|
| Direct/determinant/curvature/pair construction |175448576|138101760direct +23016960independent determinant +14155776curvature +174080pair construction. The latter is old95744 plus78336explicit sign products; these are upper-bound allocations, not measured counts. |
| Final exact Haar bucket scales |1000000|57104calls ×at most14moment buckets =799456, within1M. |
| Complete W/Gaussian/frame schedule |10000000|94016queries ×at most101products =9495616, plus31392weight coefficients within32000allowance. |
| Direct interactions/frame contacts |3000000|Both words' complete12444queries at81products give2015928, plus at most109520free-frame products. |
| Full literal-H/source/frame/quotient/evaluation |16000000|Retains the full740center-compatible quartics,136possible g2J²slots and two scalar coupling terms; the previously reviewed four upper subtotals sum14605600, not a172observed-nonzero cap. |
| Geometry, construction and remaining margin |19921664|Original20000000 minus the explicit78336sign correction. Actual action-building allocation remains below4M; ample unchanged room remains for normalized kernels/geometry/setup. |
| **Total prospective** |**225370240**|Strictly below the unchanged250000000scalar-product limit. |

The R3 rational accumulation changes introduce no new logical scalar products: they make integer arithmetic and temporary widths observable. Source-domain validation inspects already normalized masks/terms and does not generate coefficient products. Integer products remain separately counted; fixed normalized one-site symbolic/real-point assumptions and actual1024-bit checks are unchanged. This is not a proof of full native fit/time or of arbitrary unadmitted input domains.

The exact original complete producer remains unchanged: all3876quartics,740center-allowed/3136center-zero slots, both actual printed/closed words, v2/v3,4029raw Wterms and94016queries; all T/H/frame/normalization/contact families and actual interacting denominator remain. The25moment-pattern/14bucket normalized-kernel cache and sequential direct/independent table schedule are unchanged. The400000×1536+128MiB reserve remains748617728bytes; actual scientific admission still needs ROOT's oneCPU/2GiB/24-hour supervision and independent result review. No scientific coefficient, full count, peak height or complete native resource result is supplied here.

## Exact conservation and frozen candidate

| Path | SHA256 | Bytes |
|---|---|---:|
| src/core/formulas.py |{source[owned[0]]['sha256']}|{source[owned[0]]['bytes']}|
| src/vestigial/original_coefficients.py |{source[owned[1]]['sha256']}|{source[owned[1]]['bytes']}|
| tests/test_original_coefficient_jets.py |{source[owned[2]]['sha256']}|{source[owned[2]]['bytes']}|

The complete536661formula bytes remain identical to R2, including the accepted509040-byte Task1 prefix and full scientific producer. Protected Task1 tests retain SHA25615d64a3899ad078015864ae4354156c62bbe1bb6a4e8db3c5a398833865d885d. All23031R2jet-test bytes remain an exact prefix. AST comparison finds ONLY RawJet.__mul__, SourceJet.__post_init__ and exterior_phase_derivative changed; no old function was deleted/shadowed or new production framework/helper added. AST parsing and per-file whitespace checks pass. Full R2→R3diff and immutable receipt hashes are in the companion artifacts.

ROOT must intake the complete source/cost repair, obtain different full science/algebra-cost reviews, reconcile the SAME canonical1.1/1.2findings and only then consider actual scientific runtime admission. Actual complete results/counters/heights/RSS/time and independent result verification remain owed. Formal source-to-executable/Task3N16/Task4fullZ/nonzero normalization, physical state/domain/adjoint/constraints/calibration, B3window/modes/matter/transport/limits and all publication/human requirements remain at their original strength. No source-only or bounded-test result substitutes for them.
'''
mdpath=Path('/tmp/publication-original-coefficient-task2-repair-r3.md');mdpath.write_text(md)
receipt_files=['/tmp/publication-original-coefficient-task2-repair-r3.md','/tmp/publication-original-coefficient-task2-repair-r3.diff','/tmp/publication-task2-r3-red-archive-runner.py','/tmp/publication-task2-r3-red-archive.log','/tmp/publication-task2-r3-red-archive.xml','/tmp/publication-task2-r3-red-archive-receipt.json','/tmp/publication-task2-r3-green-targeted.log','/tmp/publication-task2-r3-green-targeted.xml','/tmp/publication-task2-r3-bounded-final-runner.py','/tmp/publication-task2-r3-bounded-final.log','/tmp/publication-task2-r3-bounded-final.xml','/tmp/publication-task2-r3-bounded-final-receipt.json','/tmp/publication-task2-r3-final-continuity.json']
report={'status':'SOURCE_REPAIRED_BOUNDED_GREEN_REQUIRES_DIFFERENT_REVIEW','task':'publication-original-coefficient-task2-repair-r3','source':source,'changed_existing_definitions':changed,'changed_methods':methods,'formulas_R2_byte_identical':True,'Task1_tests_sha256':hashlib.sha256((P/'tests/test_original_coefficients.py').read_bytes()).hexdigest(),'all_R2_jet_test_bytes_preserved':True,'R2_jet_test_prefix_bytes':23031,'first_SAME_packet':{'exit_code':0,'fresh':True,'changed':[]},'final_SAME_packet':{'exit_code':1,'result':final,'never_refreshed':True},'frozen_R2_red':{**red,'tests':16,'expected_failures':13,'passed_positive_controls':3,'errors':0,'other_jet_cases_deselected':42},'bounded_tests':{**full,'passed':109,'deselected':1,'observed_outer_fixture_counters':counts,'max_reported_outer_counter':max(x['outer_products'] for x in counts),'sum_reported_outer_counters':sum(x['outer_products'] for x in counts),'unobserved_dependency_test_counts':None,'full_scientific_execution':False},'cost_model':cost,'full_scientific_execution':False,'forbidden_operations_performed':False,'static_checks':{'AST_parse':True,'whitespace':True,'all_other_domain_AST_nodes_equal':True,'no_old_test_rewritten':True},'artifacts':{f:{'bytes':Path(f).stat().st_size,'sha256':hashlib.sha256(Path(f).read_bytes()).hexdigest()} for f in receipt_files}}
Path('/tmp/publication-original-coefficient-task2-repair-r3.json').write_text(json.dumps(report,indent=2)+'\n')
for name,d in source.items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==d['sha256']
print('R3 terminal frozen handoff ready',json.dumps(source,indent=2))
