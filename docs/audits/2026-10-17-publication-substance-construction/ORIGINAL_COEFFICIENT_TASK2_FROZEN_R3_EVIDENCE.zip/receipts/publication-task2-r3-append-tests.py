from pathlib import Path
import json,hashlib
P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
owned=['src/core/formulas.py','src/vestigial/original_coefficients.py','tests/test_original_coefficient_jets.py']
root=Path('/tmp/publication-task2-r3-preimage');root.mkdir(exist_ok=False)
for name in owned:
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((P/name).read_bytes())
(root/'manifest.json').write_text(json.dumps({name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in owned},indent=2)+'\n')
p=P/owned[-1];old=p.read_text();assert 'test_r3_' not in old;p.write_text(old+Path('/tmp/publication-task2-r3-new-tests.txt').read_text())
print('R2 source preimages frozen; discriminating R3 tests appended; production source untouched')
