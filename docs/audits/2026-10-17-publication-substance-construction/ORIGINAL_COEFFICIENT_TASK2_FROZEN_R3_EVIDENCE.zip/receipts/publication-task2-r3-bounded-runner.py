from pathlib import Path
import sys,resource,json,xml.etree.ElementTree as ET,time,os
P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');sys.path.insert(0,str(P))
import pytest
args=['tests/test_original_coefficients.py','tests/test_dependency_declaration.py','tests/test_original_coefficient_jets.py','-k','not test_original_full_small_carrier_direct_vs_auxiliary','-vv','-s','-p','no:cacheprovider','--junitxml=/tmp/publication-task2-r3-bounded.xml']
started=time.time();code=pytest.main(args);rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
suite=ET.parse('/tmp/publication-task2-r3-bounded.xml').getroot().find('testsuite')
receipt={'command':[sys.executable,'-B','-m','pytest',*args],'exit_code':int(code),'wall_seconds':time.time()-started,'peak_RSS_bytes':rss,'suite':suite.attrib,'selected_node_ids':[c.attrib['classname']+'::'+c.attrib['name'] for c in suite.findall('testcase')],'sole_deselection':'test_original_full_small_carrier_direct_vs_auxiliary','full_scientific_execution':False,'thread_caps':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']}}
Path('/tmp/publication-task2-r3-bounded-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('BOUNDED_PROCESS_PEAK_RSS_BYTES',rss,flush=True)
assert rss<512*1024**2
raise SystemExit(code)
