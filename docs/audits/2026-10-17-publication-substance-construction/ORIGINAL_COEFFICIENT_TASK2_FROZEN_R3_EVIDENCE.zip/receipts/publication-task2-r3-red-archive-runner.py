from pathlib import Path
import zipfile,tempfile,importlib.util,sys,hashlib,json,resource
P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');sys.path.insert(0,str(P))
archive=P.parent/'.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction/ORIGINAL_COEFFICIENT_TASK2_FROZEN_R2_EVIDENCE.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='a4cdbfa940fae240c09c55f2d1882146111a29f092333991b790da47b56680d7'
with tempfile.TemporaryDirectory(prefix='task2-r3-frozen-red-',dir='/tmp') as d:
 d=Path(d);records={}
 with zipfile.ZipFile(archive) as z:
  manifest=json.loads(z.read('manifest.json'))
  for path in ['src/vestigial/original_coefficients.py','src/core/formulas.py']:
   data=z.read('candidate/'+path);meta=manifest['candidate/'+path];assert hashlib.sha256(data).hexdigest()==meta['sha256'];f=d/Path(path).name;f.write_bytes(data);records[path]=hashlib.sha256(data).hexdigest()
 import src.vestigial,src.core
 for name,filename,parent,attr in [('src.vestigial.original_coefficients','original_coefficients.py',src.vestigial,'original_coefficients'),('src.core.formulas','formulas.py',src.core,'formulas')]:
  spec=importlib.util.spec_from_file_location(name,d/filename);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;setattr(parent,attr,module);spec.loader.exec_module(module)
 print('FROZEN_R2_PRODUCTION_HASHES',json.dumps(records,sort_keys=True),flush=True)
 import pytest
 code=pytest.main(['tests/test_original_coefficient_jets.py','-k','test_r3_','-vv','-s','-p','no:cacheprovider','--junitxml=/tmp/publication-task2-r3-red-archive.xml'])
 rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 Path('/tmp/publication-task2-r3-red-archive-receipt.json').write_text(json.dumps({'exit_code':int(code),'source':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'peak_RSS_bytes':rss,'full_scientific_execution':False},indent=2)+'\n')
 assert rss<512*1024**2
 raise SystemExit(code)
