"""Exact one-factor and mask-closure join size measurements; no scalar run."""
from collections import Counter,defaultdict
from itertools import product
from pathlib import Path
import json

D=Path(__file__).parent
R3=Path('/tmp/publication-c14-rank3-r1.q1WfND')
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
WORK_CAP=4_000_000
ROW_CAP=200_000
WORK=Counter()

def charge(k,n=1):
    if WORK.total()+n>WORK_CAP:
        raise RuntimeError(('prospective_preflight_work',k,WORK.total()+n,WORK_CAP))
    WORK[k]+=n

def rows(p):
    with p.open() as f:
        for s in f:
            yield json.loads(s)

def ray_table(n):
    return {j:[tuple(k) for k,v in row] for j,row in rows(D/f'quotient-{n}-rays.jsonl')}

def main():
    env=[tuple(k) for k,v in rows(D/'coalesced-environment.jsonl')]
    freq=[Counter(k[i] for k in env) for i in range(7)]
    names=('rank4','rank12','rank3','rank10','rank9')
    rays={n:ray_table(n) for n in names}
    single={}
    for i,n in enumerate(names):
        charge('conditioned_single_group',len(freq[i]))
        visits=sum(count*len(rays[n][key]) for key,count in freq[i].items())
        single[n]=dict(original_env_keys=len(env),exact_pair_product_visits=visits,
            exceeds_work_cap=visits>WORK_CAP)
    for i in (1,2):
        count=Counter(k[2] for k,v in rows(R3/f'merge-rank{i}.jsonl'))
        f=freq[4+i]
        charge('conditioned_single_group',len(f))
        visits=sum(n*count[m] for m,n in f.items())
        single[f'rank{i}_merge']=dict(original_env_keys=len(env),exact_pair_product_visits=visits,
                                      exceeds_work_cap=visits>WORK_CAP)
    # Completely project rank8's two simple exterior rays into its accepted
    # signed site factor before any numerical environment-core merge.
    pair_by=defaultdict(set)
    for masks,s,_ in rows(STAR/'site-factors.jsonl'):
        a,b,c,d=masks
        for i,j in product(rays['rank10'],rays['rank9']):
            charge('rank8_support_projection')
            if (c,) in rays['rank10'][i] and (d,) in rays['rank9'][j]:
                pair_by[i,j].add((a,b))
    out=0
    seen=set()
    first=None
    for key in env:
        i,j=key[3:5]
        supported=pair_by[i,j]
        if first is None and out+len(supported)>WORK_CAP:
            first=dict(environment_key=key,previous=out,next=out+len(supported),cap=WORK_CAP)
        out+=len(supported)
        for a,b in supported:
            charge('bounded_rank8_support_candidate')
            target=(*key[:3],a,b,*key[5:])
            if target not in seen and len(seen)==ROW_CAP:
                first_row=dict(environment_key=key,prospective=len(seen)+1,cap=ROW_CAP)
                break
            seen.add(target)
        else:
            continue
        break
    else:
        first_row=None
    # Count across every environment key independently of bounded support storage.
    gross=sum(len(pair_by[k[3:5]]) for k in env)
    result=dict(single_environment_factor_joins=single,
        rank8_pair_projection=dict(scope_pairs=len(pair_by),exact_support_pairs=sum(map(len,pair_by.values())),
            exact_pair_product_visits=gross,bounded_distinct_support_prefix=len(seen),
            first_prospective_output_refusal=first_row,flat_work_refusal=first),
        charged_operations=dict(WORK),caps=dict(work=WORK_CAP,rows=ROW_CAP),
        coefficient_join_executed=False)
    (D/'join-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
