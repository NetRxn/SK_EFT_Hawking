"""Bounded exact coalescence of the reduced environment boundary only."""
from collections import Counter,defaultdict
from itertools import product
from pathlib import Path
import json
import quotient as guard

D=Path(__file__).parent
ENV=Path('/tmp/publication-c14-exterior-r1.jdckE6')
NAMES=tuple(guard.GROUPS)
RANKS=(1,2,5,6,7,9,10,11,13,14)

def rows(p):
    with p.open() as f:
        for line in f:
            yield json.loads(line)

def reduced_boundary():
    components={}
    for i,signature,labels,table in rows(D/'components.jsonl'):
        guard.charge('read_component')
        guard.reserve('read_component')
        components[i]=labels,table
    out={}
    gross=0
    for mask,fixed,scalar,ids in rows(D/'orientation-quotient.jsonl'):
        guard.charge('orientation')
        c=[components[i] for i in ids]
        labels=sum((t for t,v in c),[])
        assert len({tuple(x) for x in labels})==len(labels)
        for path in product(*(v for t,v in c)):
            guard.charge('exact_quotient_flat_term')
            gross+=1
            coeff=scalar
            key=[]
            for k,w in path:
                key+=k
                coeff=guard.mul(coeff,w)
            masks=dict(fixed)
            classes={}
            for label,m in zip(labels,key,strict=True):
                if label[0]=='ray':
                    classes[label[1]]=m
                else:
                    rank,h=label[1:]
                    assert m in guard.MODES[h] and not masks.get(rank,0)&m
                    masks[rank]=masks.get(rank,0)|m
            assert set(masks)=={1,2} and len(classes)==5
            n=(*(classes[g] for g in NAMES),masks[1],masks[2])
            if n not in out:
                guard.reserve('coalesced_environment_key')
            out[n]=guard.add(out.get(n,0),coeff)
    assert gross==810460
    zeros=sum(z==0 for z in out.values())
    return {k:v for k,v in out.items() if v},gross,zeros

def check(out):
    by=defaultdict(lambda:defaultdict(list))
    for name in NAMES:
        for k,(ray,weight) in rows(D/f'quotient-{name}-map.jsonl'):
            guard.charge('read_control_variant')
            by[name][ray].append((k,weight))
    orientation=[]
    for mask,fixed,scalar,paths in rows(ENV/'exterior-orientations.jsonl'):
        guard.charge('read_literal_control_orientation')
        guard.reserve('literal_control_orientation')
        orientation.append((fixed,scalar,[(a,b,{(m,n):z for m,n,z in t}) for a,b,t in paths]))
    lookup={}
    def coefficient(mask):
        if mask in lookup:
            return lookup[mask]
        q=dict(zip(RANKS,mask,strict=True))
        total=0
        for fixed,scalar,path in orientation:
            guard.charge('reference_full_environment_lookup')
            if any(q[s]!=m for s,m in fixed):
                continue
            actual=dict(fixed)
            z=scalar
            for (s,h),(t,j),values in path:
                x=q[s]&(15 if h==0 else 240)
                y=q[t]&(15 if j==0 else 240)
                w=values.get((x,y))
                if w is None:
                    break
                actual[s]=actual.get(s,0)|x
                actual[t]=actual.get(t,0)|y
                z=guard.mul(z,w)
            else:
                if actual==q:
                    total=guard.add(total,z)
        guard.reserve('reference_boundary_cache')
        lookup[mask]=total
        return total
    result=[]
    def order(item):
        k,_=item
        g=[by[n][j] for n,j in zip(NAMES,k[:5],strict=True)]
        minimum=1
        mixed=False
        for v in g:
            signs={w<0 for _,w in v}
            mixed|=len(signs)>1
            if signs=={True}:
                minimum=-minimum
        return (not (mixed or minimum<0),sum(map(len,g)),k)
    for k,v in sorted(out.items(),key=order):
        groups=[by[n][j] for n,j in zip(NAMES,k[:5],strict=True)]
        n=1
        for a in groups:
            n*=len(a)
        if n>64:
            continue
        total=0
        unsigned=0
        for combo in product(*groups):
            guard.charge('reference_direct_variant')
            fixed={1:k[-2],2:k[-1]}
            w=1
            for name,(masks,weight) in zip(NAMES,combo,strict=True):
                fixed.update(zip(guard.GROUPS[name][0],masks,strict=True))
                w=guard.mul(w,weight)
            exact=coefficient(tuple(fixed[r] for r in RANKS))
            total=guard.add(total,guard.mul(w,exact))
            unsigned=guard.add(unsigned,guard.mul(abs(w),exact))
        assert total==v
        result.append(dict(boundary=k,exact_coalesced_numerator=v,
                           complete_original_mask_variants=n,reverse_one_site_orientation=-v,
                           discarded_ray_weight_sign_numerator=unsigned))
        if len(result)==5:
            assert any(v['exact_coalesced_numerator']!=v['discarded_ray_weight_sign_numerator'] for v in result)
            return result
    raise AssertionError('five complete quotient fixed checks required')

def main():
    guard.rss()
    out,visits,zero=reduced_boundary()
    with (D/'coalesced-environment.jsonl').open('wb') as f:
        for k,z in sorted(out.items()):
            guard.charge('serialize_nonzero_coalesced_row')
            guard.emit(f,[k,z])
    controls=check(out)
    guard.rss()
    result=dict(boundary_order=[*NAMES,'remote1','remote2'],flat_terms=visits,nonzero_rows=len(out),
        exact_zero_keys=zero,controls=controls,meters=dict(guard.STATE),work=dict(guard.WORK),
        caps=guard.LIMS,peak_rss_bytes=guard.PEAK,full_representative_evaluated=False)
    (D/'coalescence.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
