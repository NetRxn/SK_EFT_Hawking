"""Count exact exterior path term semijoin against projected core support."""
from collections import Counter,defaultdict
from itertools import product
from pathlib import Path
import json,resource

D=Path(__file__).parent
ENV=Path('/tmp/publication-c14-exterior-r1.jdckE6')
S4=Path('/tmp/publication-c14-s4-diagonal-r1.btrcpw')
R3=Path('/tmp/publication-c14-rank3-r1.q1WfND')
R12=Path('/tmp/publication-c14-rank12-r1.ehXXAy')
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
CAP=4_000_000
WORK=Counter()

def charge(k):
    if WORK.total()>=CAP:
        raise RuntimeError(('prospective_join_refusal',k,WORK.total()+1,CAP))
    WORK[k]+=1

def keys(path):
    with path.open() as f:
        for line in f:
            charge('project_input_row')
            k,_=json.loads(line)
            yield k

def project(path,ix):
    return {tuple(k[i] for i in ix) for k in keys(path)}

def run():
    constraints={
        (6,5):project(S4/'rank4-closure-exterior.jsonl',(2,3)),
        (14,13):project(R12/'rank12-closure.jsonl',(6,7)),
        (11,7):project(R3/'rank3-compact.jsonl',(5,6)),
    }
    unary={
        1:{x for x, in project(R3/'merge-rank1.jsonl',(2,))},
        2:{x for x, in project(R3/'merge-rank2.jsonl',(2,))},
        9:{x for x, in project(STAR/'edge-3.jsonl',(1,))},
        10:{x for x, in project(STAR/'edge-2.jsonl',(1,))},
    }
    assert all(len(unary[i])==70 for i in (1,2))
    before=after=positive=0
    group_hist=Counter()
    first=None
    with (ENV/'exterior-orientations.jsonl').open() as f:
        for line in f:
            charge('orientation_semijoin')
            mask,fixed,scalar,paths=json.loads(line)
            p=[]
            owner=defaultdict(list)
            for i,(left,right,table) in enumerate(paths):
                a,b=left[0],right[0]
                owner[a].append((i,0))
                owner[b].append((i,1))
                p.append([(m,n) for m,n,z in table])
            n=6**len(p)
            before+=n
            predicates=defaultdict(list)
            adj=defaultdict(set)
            for (a,b),allowed in constraints.items():
                (i,j),=owner[a]
                (k,l),=owner[b]
                scope=frozenset((i,k))
                predicates[scope].append((i,j,k,l,allowed))
                adj[i].add(k)
                adj[k].add(i)
            for site in (9,10):
                (i,j),=owner[site]
                p[i]=[row for row in p[i] if row[j] in unary[site]]
            remaining=set(range(len(p)))
            terms=1
            while remaining:
                u=min(remaining)
                comp={u}
                frontier=[u]
                while frontier:
                    v=frontier.pop()
                    more=adj[v]-comp
                    comp.update(more)
                    frontier.extend(more)
                remaining-=comp
                group_hist[len(comp)]+=1
                index=sorted(comp)
                rules=[rule for scope,rules in predicates.items() if scope<=comp for rule in rules]
                good=0
                for choice in product(*(p[i] for i in index)):
                    charge('conditioned_component_assignments')
                    assign=dict(zip(index,choice))
                    if all((assign[i][j],assign[k][l]) in allowed for i,j,k,l,allowed in rules):
                        good+=1
                terms*=good
            if terms:
                positive+=1
            if first is None and after+terms>CAP:
                first=dict(orientation=mask,previous=after,terms=terms,prospective=after+terms,cap=CAP)
            after+=terms
    return dict(projected_pairs={str(k):len(v) for k,v in constraints.items()},
            full_path_term_visits=before,terms_passing_necessary_core_projections=after,
            orientations_retained=positive,component_path_counts=dict(sorted(group_hist.items())),
            first_prospective_flat_refusal=first,work=dict(WORK),
            process_sample_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            boundary_join_executed=False,interpretation='Semijoin applies only projected necessary mask support. Counts are orientation terms before coalescence, not support of complete core coefficient.')

if __name__=='__main__':
    r=run()
    (D/'result.json').write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps(r,indent=2))
