# Exact original N16 c14 signed core-boundary quotient

The pinned source is original periodic closed source_C at clean primary
27012c18fa374e8341e124b510abbedeedb18d29. The quotient uses the exact
zero-centered (01,01,23,23) exterior environment, subsequently accepted
by its independent review. It retains the original whole-row divisor
512 and the separate pure-S4 numerator multiplier 24^5.

The three actual projected pair-mask domains of the earlier core
factors have 44 keys each. Applying these necessary support constraints
and the singleton masks to the 44,432,064 exterior path terms retains
24,847,680 orientation terms, before coalescence. This is a support
semijoin and not the nonzero support of the exact core. It was counted
via small connected groups, without enumerating the entire flattened
route. The prospective flat visit limit would be exceeded at orientation
15,510 with 4,009,212 visits.

## Exact signed quotient

For each of five actual core factors, treat all internal label
coefficients at a fixed open boundary as a vector. Divide each vector
by the signed integer gcd, with the first nonzero component chosen
positive in its normalized representative. Each original signed
slice is reconstructed exactly from one ray ID and one signed
scalar weight. The rank-4, rank-12 and rank-3 pair-mask families
each compress 44 slices to 11 rays. The earlier two single-mask
factors at ranks 10 and 9 each compress eight slices to six rays.

Push those five signed scalar weights into the original exterior
path factors before coalescence. Normalize each path's two type-A
weights to +2 and four type-B weights to -1. Its exact signed
scaling, including the original closed cycle factor, stays in the
orientation scalar. Within each orientation, connect path variables
only when a core boundary pair uses both. Rank-1 and rank-2 half masks
remain separate within these components and reassemble only in the
reduced boundary output. Each cached component has at most four path
variables. The exact pushforward preserves cancellation on coincident
quotient labels.

There are 1,456 unique component tables and 2,604 orientation
records. The corresponding flat **quotient environment** needs
810,460 term visits. This route completed and coalesced to 178,150
nonzero signed rows. Each row key is five ordered ray IDs followed
by the original complete rank-1 and rank-2 fused masks. The five
core ray carrier files and the coalesced environment replace the
earlier open-boundary contraction exactly. The inherited graph
denominator remains unchanged. In particular the five signed
core weights are already included in the environment and are
applied once.

Five exact coalesced boundary coefficients were independently checked
by enumerating all 16 original mask variants in each respective ray
combination, evaluating each original exterior coefficient across
the whole orientation carrier, then applying the original signed
ray weights. All five equal 2,251,799,813,685,248 in numerator
units. Dropping the signs of those ray weights gives the opposite
coefficient in every check. These are exact environment boundary
controls. They do not evaluate the final scalar obtained by
multiplying the normalized core factors.

## Prospective core join sizes

The completed reduced environment is still too large for the tested
direct whole-representative schedules. Exact projected join counts
are 44,945,568 visits for direct rank-12 ray absorption and
7,592,496 for direct rank-3 ray absorption. Projecting both simple
rank-8 rays through the actual signed site partition uses 228
supported local mask pairs across 36 ray pairs. A direct join to
the environment would visit 1,517,244 products and reached the
200,001 distinct-support row limit in the measured projection.
This last measurement includes no coefficients or cancellations.
These are schedule-specific refusals, with no lower-bound claim.

The quotient construction used 1,086,480 charged visits, 39,679
tracked rows and 1,324,635 output bytes. The separate coalescence
and controls used 1,203,822 visits, 182,290 tracked rows and
6,822,011 serialized bytes, with a sampled peak process RSS of
124,502,016 bytes. The prospective caps were 4,000,000 visits,
200,000 tracked rows, 32 MiB output and checked integer magnitude
2^61-1. Process RSS used a sampled 384 MiB guard. Input containers,
indexing and sorting not recorded as tracked table rows are outside
that counter. This package contains no whole representative run.

A next schedule should first eliminate exact interior core labels
within chirality-conditioned blocks, then attach the reduced
environment by a smaller set of shared ray/mask labels. A fresh
prospective size measure is required. The full representative,
other axis arrangements, c14, c0, the complete denominator and
normalization remain open.
