"""Exact signed boundary quotient without representative evaluation."""
from collections import Counter,defaultdict
from functools import cache
from itertools import product
from math import gcd
from pathlib import Path
import json,resource

D=Path(__file__).parent
ENV=Path('/tmp/publication-c14-exterior-r1.jdckE6')
S4=Path('/tmp/publication-c14-s4-diagonal-r1.btrcpw')
R3=Path('/tmp/publication-c14-rank3-r1.q1WfND')
R12=Path('/tmp/publication-c14-rank12-r1.ehXXAy')
GROUPS={
 'rank4':((6,5),S4/'rank4-closure-exterior.jsonl',2),
 'rank12':((14,13),R12/'rank12-closure.jsonl',6),
 'rank3':((11,7),R3/'rank3-compact.jsonl',5),
 'rank10':((10,),S4/'s4-10-axis2-exterior.jsonl',1),
 'rank9':((9,),S4/'s4-9-axis3-exterior.jsonl',1),
}
LIMS=dict(work=4_000_000,rows=200_000,output=32*1024**2,rss=384*1024**2,
          scalar=(1<<61)-1)
WORK=Counter()
STATE=Counter()
PEAK=0
MODES=((3,5,10,12),(48,80,160,192))

def rss():
    global PEAK
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    PEAK=max(PEAK,n)
    if n>LIMS['rss']:
        raise RuntimeError(('sampled_RSS',n,LIMS['rss']))

def charge(kind):
    n=STATE['work']+1
    if n>LIMS['work']:
        raise RuntimeError(('prospective_work',kind,n,LIMS['work']))
    STATE['work']=n
    WORK[kind]+=1
    if n%2048==0:
        rss()

def reserve(kind):
    n=STATE['rows']+1
    if n>LIMS['rows']:
        raise RuntimeError(('prospective_retained_rows',kind,n,LIMS['rows']))
    STATE['rows']=n

def emit(f,x):
    b=json.dumps(x,separators=(',',':')).encode('ascii')+b'\n'
    n=STATE['output']+len(b)
    if n>LIMS['output']:
        raise RuntimeError(('prospective_serialized_output',n,LIMS['output']))
    f.write(b)
    STATE['output']=n

def add(a,b):
    lim=LIMS['scalar']
    if (a>0 and b>0 and a>lim-b) or (a<0 and b<0 and a< -lim-b):
        raise RuntimeError('prospective integer addition')
    return a+b

def mul(a,b):
    if b and abs(a)>LIMS['scalar']//abs(b):
        raise RuntimeError('prospective integer product')
    return a*b

def rays():
    out={}
    stats={}
    for name,(ranks,p,split) in GROUPS.items():
        slices=defaultdict(dict)
        with p.open() as f:
            for line in f:
                charge('read_core_boundary_slice')
                k,z=json.loads(line)
                assert tuple(k[:split]) not in slices[tuple(k[split:])]
                slices[tuple(k[split:])][tuple(k[:split])]=tuple(z)
        rays={}
        lookup={}
        with (D/f'quotient-{name}-rays.jsonl').open('wb') as fp:
            for k,v in sorted(slices.items()):
                first=next(a for ik in sorted(v) for a in v[ik] if a)
                weight=gcd(*(a for z in v.values() for a in z))
                weight*=1 if first>0 else -1
                vec=tuple((ik,tuple(a//weight for a in z)) for ik,z in sorted(v.items()))
                assert {ik:tuple(mul(a,weight) for a in z) for ik,z in vec}==v
                if vec not in rays:
                    reserve('coefficient_ray')
                    rays[vec]=len(rays)
                    emit(fp,[rays[vec],vec])
                reserve('ray_map')
                lookup[k]=(rays[vec],weight)
        with (D/f'quotient-{name}-map.jsonl').open('wb') as fp:
            for k,v in sorted(lookup.items()):
                emit(fp,[k,v])
        out[name]=lookup
        stats[name]=dict(boundary=list(ranks),source_slices=len(slices),signed_proportional_rays=len(rays))
    assert [v['signed_proportional_rays'] for v in stats.values()]==[11,11,11,6,6]
    return out,stats

def path_options(a,b):
    x,y=MODES[a[1]],MODES[b[1]]
    return [(x[0],y[3],2),(x[3],y[0],2),*((m,n,-1) for m in x[1:3] for n in y[1:3])]

def grouping(paths):
    owner={}
    for i,(a,b) in enumerate(paths):
        for t in (a,b):
            if t[0] not in (1,2):
                assert t[0] not in owner
                owner[t[0]]=i
    adjacency=defaultdict(set)
    for ranks,_,_ in GROUPS.values():
        s={owner[r] for r in ranks}
        for i in s:
            adjacency[i].update(s-{i})
    pending=set(range(len(paths)))
    result=[]
    while pending:
        found={min(pending)}
        queue=list(found)
        while queue:
            i=queue.pop()
            extra=adjacency[i]-found
            found.update(extra)
            queue.extend(extra)
        pending-=found
        result.append(tuple(paths[i] for i in sorted(found)))
    return result

@cache
def component(sig):
    names={p[0] for ab in sig for p in ab}
    groups=[(n,ranks) for n,(ranks,_,_) in GROUPS.items() if all(s in names for s in ranks)]
    halves=sorted(t for ab in sig for t in ab if t[0] in (1,2))
    label=[('ray',n) for n,_ in groups]+[('half',*h) for h in halves]
    table={}
    for raw in product(*(path_options(a,b) for a,b in sig)):
        charge('component_path_assignments')
        by={}
        half={}
        w=1
        for (a,b),(m,n,z) in zip(sig,raw,strict=True):
            for endpoint,mask in ((a,m),(b,n)):
                if endpoint[0] in (1,2):
                    half[endpoint]=mask
                else:
                    by[endpoint[0]]=mask
            w=mul(w,z)
        rays=[]
        for name,ranks in groups:
            ray=LOOKUP[name].get(tuple(by[s] for s in ranks))
            if ray is None:
                break
            j,sc=ray
            rays.append(j)
            w=mul(w,sc)
        else:
            key=(*rays,*(half[h] for h in halves))
            if key not in table:
                reserve('component_exact_key')
            table[key]=add(table.get(key,0),w)
    return label,{k:z for k,z in table.items() if z}

def carrier():
    ids={}
    hist=Counter()
    g_hist=Counter()
    gross=0
    ref=0
    first=None
    nonzero=0
    with (D/'orientation-quotient.jsonl').open('wb') as fo, (D/'components.jsonl').open('wb') as fc:
        for line in (ENV/'exterior-orientations.jsonl').open():
            charge('read_exact_orientation')
            mask,fixed,scalar,paths=json.loads(line)
            signatures=[]
            weights=[]
            product_len=1
            all_paths=[]
            for a,b,table in paths:
                endpoints=tuple(a),tuple(b)
                native={(m,n):z for m,n,z in table}
                normalized=path_options(*endpoints)
                scale=native[normalized[0][0],normalized[0][1]]
                assert scale%2==0
                scale//=2
                assert native=={(m,n):mul(scale,z) for m,n,z in normalized}
                scalar=mul(scalar,scale)
                all_paths.append(endpoints)
            for sig0 in grouping(all_paths):
                sig=tuple(sorted(sig0))
                hist[len(sig)]+=1
                lab,table=component(sig)
                if sig not in ids:
                    reserve('component_identifier')
                    ids[sig]=len(ids)
                    emit(fc,[ids[sig],sig,lab,sorted(table.items())])
                    g_hist[len(sig)]+=1
                signatures.append(ids[sig])
                product_len*=len(table)
            if product_len:
                nonzero+=1
            if first is None and gross+product_len>LIMS['work']:
                first=dict(orientation=mask,previous=gross,terms=product_len,prospective=gross+product_len,
                           cap=LIMS['work'])
            gross+=product_len
            emit(fo,[mask,fixed,scalar,signatures])
    return dict(component_ids=len(ids),component_scopes_by_path_count=dict(hist),
                unique_component_scopes=dict(g_hist),orientation_records=nonzero,
                flat_quotient_component_term_count=gross,first_prospective_flat_refusal=first)

def main():
    global LOOKUP
    rss()
    LOOKUP,stats=rays()
    output=carrier()
    rss()
    output.update(core_rays=stats,work=dict(WORK),meters=dict(STATE),caps=LIMS,peak_rss_bytes=PEAK,
        full_representative_evaluated=False)
    (D/'quotient.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))

if __name__=='__main__':
    main()
