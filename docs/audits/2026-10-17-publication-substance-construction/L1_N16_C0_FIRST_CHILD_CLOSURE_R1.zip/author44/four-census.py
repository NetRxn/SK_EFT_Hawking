from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle
import sys

for filename in sys.argv[1:]:
    data = pickle.loads(Path(filename).read_bytes())
    factors = data['factors']
    if len(factors)!=4:
        continue
    forecasts=[]
    for a,b in combinations(range(4),2):
        scope,rows,_=factors[a]
        right,peer,_=factors[b]
        shared=tuple(w for w in scope if w in right)
        l=tuple(scope.index(w) for w in shared)
        r=tuple(right.index(w) for w in shared)
        counts=Counter(tuple(row[i] for i in r) for row in peer)
        forecast=sum(counts[tuple(row[i] for i in l)] for row in rows)
        forecasts.append((forecast,a,b))
    print(filename,sorted(forecasts),flush=True)
