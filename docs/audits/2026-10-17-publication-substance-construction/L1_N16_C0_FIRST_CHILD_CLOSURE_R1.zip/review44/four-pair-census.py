from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle

root = Path('/private/tmp/l1-c0-case44.ZB6lk2')
for i in (7,8):
    f = pickle.loads((root/f'row-cap-physical-slice-dense-label-rescue-{i}-0-reduced.pkl').read_bytes())['factors']
    counts = []
    for a,b in combinations(range(4),2):
        A,B = f[a],f[b]
        shared = sorted(set(A[0])&set(B[0]))
        l = tuple(A[0].index(axis) for axis in shared)
        r = tuple(B[0].index(axis) for axis in shared)
        right = Counter(tuple(row[p] for p in r) for row in B[1])
        n = sum(right[tuple(row[p] for p in l)] for row in A[1])
        counts.append((a,b,n))
        print('slice',i,'pair',a,b,'products',n,'out scope',len(set(A[0])^set(B[0])))
