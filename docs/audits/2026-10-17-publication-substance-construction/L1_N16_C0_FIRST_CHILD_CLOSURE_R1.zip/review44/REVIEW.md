# Independent verification of L1 N16 outer case 44

The review pins publication checkpoint 7c4223279285b40301624a5c8115dc027450a8fe and the seven-factor
parent identified in next-frontiers/inputs.sha256 within
L1_N16_C0_CASES29_31_CLOSURE_R1.zip. The archive manifest verified.
The checked parent SHA256 is
4d75a305733fdafaabf8095ab03cd438a3f642053ba830a550ba5ec42f49b917.
The archived outer roster maps case 44 to (66, (1,)) on G(0,4,2) and
J(1,4,2), in the first binary child of tuple 0, descendant (0,0),
branch 128.

An independent histogram match on the rejected parent pair (0, 4)
regenerated the complete nine-value cut on G(0,1,2). The disjoint values
cover 2,280,960 matched pair products. Every nonzero complete network
summand must match that pair. Exact inverse lifts recover every compatible
parent row and Gaussian coefficient and preserve each factor denominator.
All terminal inputs retained complete conditioning and the label partition,
degree-two open axes and the positive denominator product.

| Slice | Cut value | Matched parent pair products | Independent normalized real |
|---|---:|---:|---:|
| 0 | 12 | 44,928 | -8215595331806265617025/2596148429267413814265248164610048 |
| 1 | 48 | 62,208 | -14394095842748134149/81129638414606681695789005144064 |
| 2 | 3 | 169,344 | -165277828351316671795665/2596148429267413814265248164610048 |
| 3 | 5 | 200,448 | -195112405856456656467165/5192296858534827628530496329220096 |
| 4 | 96 | 248,832 | -23771693924041298199075/1298074214633706907132624082305024 |
| 5 | 144 | 248,832 | -23771693924041298199075/1298074214633706907132624082305024 |
| 6 | 192 | 311,040 | 2204328248172050188671/649037107316853453566312041152512 |
| 7 | 80 | 497,664 | -5420629610652808270899/649037107316853453566312041152512 |
| 8 | 160 | 497,664 | -5420629610652808270899/649037107316853453566312041152512 |

All imaginary parts are zero. The exact independent sum is
**-802289474534037328295697/5192296858534827628530496329220096 + 0i**.
Equal slice values retain distinct conditioned inputs and SHA256 identities.
Case 44 was derived from (66, (1,)). The case 40 ledger in
L1_N16_C0_CASES37_39_40_CLOSURE_R1.zip records the same scalar at
the distinct outer coordinate (34, (1,)).

Five direct sparse terminal replays passed. The two triangles in
slices 2 and 3 independently used pivot 1 in place of the author's
pivot 0. Slices 2 and 3 cover 18,643,968 and 19,975,680 triples and use
18,752,832 and 20,092,320 Gaussian products, respectively. Each shard
uses at most 2,016,265 products. Recorded wall times were 11.765 s
and 12.414 s, respectively, in the concurrent scratch run.
The four-factor replays in slices 7 and 8 use initial pair (1,2),
with 6,593,616 candidate products, followed by closure on (0,3).
Each uses 27,595,440 Gaussian products across 12 shards, with at most
2,900,784 products per shard and 24,984 entries per block. The author
used initial pair (1,3). The concurrent independent four-factor runs
took 17.096 s and 16.718 s. Both alternate orders agree with the author
raw numerators and normalized fractions. All independent arithmetic
uses the same factor denominator product
40512224221827380280140849737629696 and external normalization
1/(16*4^64), each applied once.

The author shard audit independently checked 32 successful receipts.
Each of the four sharded slices has eight disjoint author intervals
covering its complete pivot or left factor, and summed raw numerators
agree with the author summary and the full independent contraction.
The 17 generic cap refusals are bound to distinct frozen restart
states, including the later alternate capped attempts for slices 7
and 8. Intermediate lineage uses archived state and receipt checks
and byte identity of the common author scripts with the fully replayed
case 18 code. The new independent arithmetic qualifies case 44 and
its exact nine-term sum.
