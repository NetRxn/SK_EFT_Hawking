from ast import literal_eval
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import lcm
from pathlib import Path
import pickle
import re
from zipfile import ZipFile

root = Path(__file__).resolve().parent
pins = {
    'pilot.roster': '185ad83d0dc0b6dcaa311b65cbbc6fc8542a0b31120e8fc4fbf59d0e238b1c4c',
    'partial-48.tsv': '66d491d32abc7133bf6915df4f5768faf5de4fa598325716d59479d605b3199a',
    'frontier-parents.sha256': '4003ded9a28359ae79aa72ff7dacebc8891b3fe94dcc485452efbea66a304971',
}
for name, expected in pins.items():
    assert sha256((root/name).read_bytes()).hexdigest() == expected, name
axes, entries = literal_eval((root/'pilot.roster').read_text())
assert axes == (('G',0,4,2),('J',1,4,2))
counts = dict(entries)
assert len(entries) == len(counts) == 48
roster = sorted(counts,key=lambda coord: (counts[coord],coord))
assert sum(counts.values()) == 6427904

# Regenerate the conserved outer cut from both factor marginals of the
# archived rejected pair before using its original order.
original_path = root/'L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip'
assert sha256(original_path.read_bytes()).hexdigest() == '06772d72f61bcb361130dede255d0e84ba98735e62671c5d635029cfe5df7d63'
with ZipFile(original_path) as archive:
    assert archive.read('pilot.roster') == (root/'pilot.roster').read_bytes()
    data = decompress(archive.read('row-cap-physical-slice-dense-label-tuple0-0-reduced.pkl.gz'))
assert sha256(data).hexdigest() == '5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867'
state = pickle.loads(data)
factors = state['factors']
assert all(n == 2 for n in Counter(w for scope,_,_ in factors for w in scope).values())
left, right = [factors[i] for i in state['rejected_pair']]
shared = sorted(set(left[0]) & set(right[0]))
assert all(axis in left[0] for axis in axes)
left_match = tuple(left[0].index(axis) for axis in shared)
left_cut = tuple(left[0].index(axis) for axis in axes)
right_match = tuple(right[0].index(axis) for axis in shared)
left_counts = Counter((tuple(row[i] for i in left_match), tuple(row[i] for i in left_cut))
                      for row in left[1])
right_counts = Counter(tuple(row[i] for i in right_match) for row in right[1])
spectrum = Counter()
for (key, cut), n in left_counts.items():
    products = n * right_counts[key]
    if products:
        spectrum[cut] += products
assert spectrum == counts
print('PASS original cut',axes,'complete coordinates',len(roster),'matched pair products',sum(spectrum.values()))

lines = (root/'partial-48.tsv').read_text().splitlines()
parts = {}
for line in lines[:-2]:
    n, coord, real, imaginary, reason = line.split('\t')
    case = int(n)
    assert case not in parts and 0 <= case < 48
    assert literal_eval(coord) == roster[case]
    assert reason in ('previous accepted receipt','new independent replay')
    parts[case] = (Fraction(real),Fraction(imaginary))
assert len(parts) == 46 and set(range(48))-set(parts) == {44,45}
assert lines[-1] == 'OPEN\t44,45'

def sum_components(values):
    return tuple(sum(column, Fraction(0)) for column in zip(*values,strict=True))

prior = sum_components(parts.values())
label, count, real, imaginary = lines[-2].split('\t')
assert (label, int(count)) == ('PARTIAL SUM',46)
assert prior == (Fraction(real),Fraction(imaginary))
print('PASS prior committed ledger',len(parts),'exact sum',*prior)
parent_pins = {name: digest for digest,name in (row.split() for row in (root/'frontier-parents.sha256').read_text().splitlines())}
def match_review(manifest, original_name, copied_name):
    entries = {name: digest for digest,name in (row.split() for row in (root/manifest).read_text().splitlines())}
    assert entries[original_name] == sha256((root/copied_name).read_bytes()).hexdigest(), copied_name

match_review('case44.review-manifest.sha256','check-cuts-and-sum.out','case44.independent.out')
match_review('case45.review-manifest.sha256','aggregate.out','case45.independent.out')
match_review('case45.review-manifest.sha256','audit-archive.out','case45.audit.out')
text44 = (root/'case44.independent.out').read_text()
text45 = (root/'case45.independent.out').read_text()
audit45 = (root/'case45.audit.out').read_text()
assert 'all nine inverse lifts and terminal input metadata' in audit45
hash44, coord44 = re.search(r'^parent \S+ ([0-9a-f]{64}) outer cut .* (\(\d+, \(\d+,\)\))$',text44,re.M).groups()
outer_roster45, hash45 = re.search(r'^canonical outer roster SHA256 ([0-9a-f]{64}) parent SHA256 ([0-9a-f]{64})$',audit45,re.M).groups()
assert outer_roster45 == pins['pilot.roster']
assert literal_eval(coord44) == roster[44] == (66,(1,))
assert roster[45] == (66,(2,)) and hash44 != hash45
for i,text,digest,pattern,terminal in [
    (44,text44,hash44,r'^PASS slice (\d+) \d+ \d+ .* exact (\S+) (\S+)$',r'^PASS exact case 44 sum (\S+) imaginary (\S+)$'),
    (45,text45,hash45,r'^independent scalar (\d+) \d+ \d+ (\S+) (\S+) [0-9a-f]{64}$',r'^PASS full exact independent case 45 sum (\S+) (\S+)$'),
]:
    parent = f'row-cap-physical-slice-dense-label-case-{i}-2-reduced.pkl'
    assert digest == parent_pins[parent]
    records = re.findall(pattern,text,re.M)
    assert [int(row[0]) for row in records] == list(range(9))
    scalar = sum_components((Fraction(real),Fraction(imaginary)) for _,real,imaginary in records)
    assert scalar == tuple(map(Fraction,re.search(terminal,text,re.M).groups()))
    parts[i] = scalar
    print('PASS independent case',i,roster[i],digest,'exact sum',*scalar)

assert set(parts) == set(range(48)) and len(set(roster)) == len(parts) == 48
values = [parts[i] for i in range(48)]
total = sum_components(values)
common = lcm(*(value.denominator for pair in values for value in pair))
numerators = tuple(sum(value.numerator*(common//value.denominator) for value in column)
                   for column in zip(*values,strict=True))
assert total == tuple(Fraction(value,common) for value in numerators)
print('PASS complete coverage',len(values),'distinct original coordinates',len(set(roster)))
print('common denominator',common,'integer sums',*numerators)
print('PASS exact case 0-47 subtotal',*total)
