# Independent exact sum of the 48 outer terms in tuple 0's first binary child

The exact normalized subtotal is
**-3421066796274305094734655/1298074214633706907132624082305024 + 0i**.
With the common denominator 5192296858534827628530496329220096, the
real and imaginary integer totals are -13684267185097220378938620 and 0.

The review pins publication commit 60f49e3cdb7c3117476f65da12bca647a8452d41.
The three source ZIPs were read from that commit and matched the publication
worktree bytes. Every entry in each archive manifest verified. The original
cut roster was independently regenerated from the decompressed tuple 0
first-child restart parent and its rejected pair, yielding 48 distinct
coordinates over 6,427,904 matched pairs.

The 46 committed values in CASES42_43_CLOSURE_R1's partial-48.tsv matched
their coordinates in the original roster and summed to its exact reported
partial value, -1485155929129304672505789/649037107316853453566312041152512
with zero imaginary part. Cases 44 and 45 were independently re-summed from
their nine respective slice receipts, with both review manifests verified.
Case 44 is at (66, (1,)) and case 45 is at (66, (2,)), each bound to its own
archived parent hash. Each original coordinate occurs once.

The 48 input contributions already carry normalization. The retally adds
their real and imaginary rationals directly and cross-checks the result at
their least common denominator. This closes the arithmetic for the first
binary child of tuple 0 in descendant (0,0), branch 128. Its complementary
child remains necessary for the full tuple.

Run `python3 retally.py` beside the pinned inputs to reproduce `retally.out`.
`SOURCE_PINS.txt` records the commit and source blob IDs.
