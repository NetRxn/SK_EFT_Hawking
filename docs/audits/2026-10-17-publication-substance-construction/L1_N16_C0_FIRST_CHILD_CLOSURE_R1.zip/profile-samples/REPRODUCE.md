# Bounded cost samples

Group 672 is the upper middle group in the archived dense cut plan sorted by
initial row count and group index. It starts with 2,731,846 rows across 88
factors. Reconstruct the original compiled factor blocks and verify them
using the recorded manifest. Use `schema.tsv` and `block-index.tsv` from
`L1_N16_C0_DENSE_COMPILED_FACTORS_R1.zip`. Use `cut-axes.tsv`, `cut-plan.tsv`,
`quotient.py`, `prepare-branch.py` and `contract-branch.py` from
`L1_N16_C0_DENSE_BRANCH_PAUSE_R1.zip` without modifications.

Run `python3 -u prepare-branch.py 672` and verify
`sample-frontier.sha256`. Then run `python3 -u contract-branch.py`.
The author run reduced to 714,563 rows in 34.81 seconds and hit the
existing row cap after 60.32 seconds with 26 factors remaining. Exit 2 is
the recorded cap refusal. Verify the prejoin state with
`sample-contraction.sha256`. These times cover work before the first refusal.

The sibling cost samples use verified uncompressed inputs and the
unmodified `exact-multicut.py` from
`L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip`. For each name in
`tuple0-1 tuple1-0b tuple1-1b`, run
`python3 exact-multicut.py row-cap-physical-slice-dense-label-NAME-reduced.pkl NAME-pilot.pkl`
with NAME replaced by that name. The rosters size the first partition.
Later join, row, timing and scalar costs remain open. No full-profile
runtime is established by these measurements.
