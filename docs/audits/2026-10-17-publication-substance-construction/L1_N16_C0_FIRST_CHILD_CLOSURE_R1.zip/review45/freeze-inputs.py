from hashlib import file_digest
from pathlib import Path
from binding import ROOT, TERMINAL_INPUTS, DIRECT_LOGS

parent = Path('/private/tmp/l1-open-roster-42-45.SjKued/row-cap-physical-slice-dense-label-case-45-2-reduced.pkl')
inputs = {parent, ROOT / 'author-case45.tsv', ROOT / 'checkpoint/quotient.py'}
inputs.update(ROOT / name for name in (*TERMINAL_INPUTS, *DIRECT_LOGS.values()))
for glob in ('*.py', '*.out', '*.roster', '*.tsv', '*-reduced*.pkl', 'slice-?.pkl'):
    inputs.update(ROOT.glob(glob))
for path in sorted(inputs):
    with path.open('rb') as stream:
        print(file_digest(stream, 'sha256').hexdigest(), '  ', path, sep='')
