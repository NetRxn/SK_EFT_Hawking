from pathlib import Path
ROOT = Path('/private/tmp/l1-c0-case45.AcSqmg')
TERMINAL_INPUTS = (
 'label-rescue-0-0-reduced-frontier.pkl',
 'label-slice-1-reduced-frontier.pkl',
 'join-cap-dense-label-rescue-2-1-reduced.pkl',
 'join-cap-dense-label-rescue-3-1-reduced.pkl',
 'label-rescue-4-0-reduced-frontier.pkl',
 'label-rescue-5-0-reduced-frontier.pkl',
 'label-rescue-6-1-reduced-frontier.pkl',
 'row-cap-physical-slice-dense-label-rescue-7-0-reduced.pkl',
 'row-cap-physical-slice-dense-label-rescue-8-0-reduced.pkl',
)
DIRECT_LOGS = {0:'rescue-0-0-contract.out',1:'slice-1-contract.out',
               4:'rescue-4-0-contract.out',5:'rescue-5-0-contract.out',6:'rescue-6-1-contract.out'}
