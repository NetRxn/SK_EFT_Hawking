from collections import Counter
from math import prod
from pathlib import Path
from pickle import loads
from re import fullmatch

from binding import ROOT

evidence = Path('author-cap-receipts')
assert sorted(path.name for path in evidence.glob('*.out')) == sorted(
    log.name for log in ROOT.glob('*-contract.out')
    if log.read_text().splitlines()[-1].startswith(('open join cap', 'open row cap'))
)
matched = set()
counts = Counter()
for receipt in sorted(evidence.glob('*.out')):
    raw = receipt.read_bytes()
    assert raw == (ROOT / receipt.name).read_bytes()
    last = raw.decode().splitlines()[-1]
    kind, count, products = fullmatch(r'open (join|row) cap (\d+) (?:completed products )?(\d+) frontier saved', last).groups()
    stem = receipt.name.removesuffix('-contract.out')
    prefix = 'join-cap-dense-label' if kind == 'join' else 'row-cap-physical-slice-dense-label'
    input_path = ROOT / f'{prefix}-{stem}-reduced.pkl'
    assert input_path not in matched
    matched.add(input_path)
    factors = loads(input_path.read_bytes())
    assert len(factors['factors']) == int(count)
    assert prod(den for _,_,den in factors['factors']) == 40512224221827380280140849737629696
    if kind == 'join':
        assert factors['refusal'] == 'no physical join admitted within per-run product limits'
        assert factors['used_before'] == int(products)
    else:
        assert factors['matched'] == int(products)
        i, j = factors['rejected_pair']
        assert 0 <= i < j < int(count)
    counts[kind] += 1
    print('PASS cap receipt', receipt.name, 'checkpoint', input_path.name, 'factors', count, 'products', products)
assert matched == {*ROOT.glob('join-cap-*-reduced.pkl'), *ROOT.glob('row-cap-*-reduced.pkl')}
print('PASS full cap checkpoint inventory', counts['join'], 'join refusals and', counts['row'], 'row refusals')
