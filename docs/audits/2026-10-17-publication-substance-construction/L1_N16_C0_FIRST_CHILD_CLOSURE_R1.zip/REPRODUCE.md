# L1 N16 exact outer cases 44 and 45

Scientific source 51e7c745e. Case 44 review parent 7c4223279 and case 45
review parent 60f49e3cd. The preceding 46-case ledger is from 60f49e3cd. Both terms belong to the first binary child of tuple
0 in descendant (0,0). Restore the corresponding distinct seven-factor
parents from `L1_N16_C0_CASES29_31_CLOSURE_R1.zip` under `next-frontiers`
using its `inputs.sha256` and the reviewer pins. Deserialize only trusted
checkpoint files.

From scratch seeded with the appropriate author folder:

```bash
python3 -u run-primary.py /absolute/path/to/restored-parent.pkl >slices.tsv
python3 -u reduce-open.py 0 1 2 3 4 5 6 7 8 >rescue.tsv
shasum -a 256 -c /absolute/path/to/archive/frontiersN.sha256
python3 -u run-final-shards.py >shard-jobs.tsv
python3 sum-caseN.py
```

Replace N with the case index. Triangles 2 and 3 and four-factor slices 7 and 8 each use eight disjoint author row intervals. The other five values close by direct or repeated support/quotient reduction. Independent evidence preserves alternate pivots and selected pairs, input bindings, and full exact shard checks. Recreate a duplicate named Git ZIP absent from a reviewer manifest from the original repository bytes by its recorded hash. See each `reviewN/REVIEW.md` for the precise lineage and evidence scope.

Run `python3 verify-cases.py 44 45` and `python3 retally-48.py 44 45` to
reproduce the independent arithmetic and update the immutable 46-case
ledger. Each value is replayed from its distinct original case input.


For the separate full independent retally, copy the three tracked source
archives named in `independent-retally/archives.sha256` into that directory,
verify their hashes, then run `python3 retally.py` there and compare
with `retally.out`. The complete 48-term ledger and independent retally
agree. See `profile-samples/REPRODUCE.md` for the bounded cost probes.
