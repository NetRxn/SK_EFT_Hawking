from ast import literal_eval
from collections import Counter, defaultdict
from hashlib import sha256
from pathlib import Path

def lines(name, expected):
    body = Path(name).read_bytes()
    assert sha256(body).hexdigest() == expected
    return [line.split("\t") for line in body.decode().splitlines()]

plan = lines("cut-plan.tsv", "28b9a0879fad79733a1ef85521b1c871841fd21714c461fba5ddf0438478ce2d")
blocks = lines("block-index.tsv", "fcc47845f3e81de9f67fb593a4d53470a7ffddf876c512dbf0951433d7bb7f16")
assert [int(row[0]) for row in plan] == list(range(3872))
families = defaultdict(Counter)
whole_keys = Counter()
grand_rows = 0
for group, _, rows, _, _, encoded in plan:
    indices = tuple(literal_eval(encoded))
    assert len(indices) == len(set(indices))
    whole_keys[indices] += 1
    by_name = defaultdict(list)
    reconstructed = 0
    for index in indices:
        assert 0 <= index < len(blocks)
        name, _, _, _, count, _ = blocks[index]
        by_name[name].append(index)
        reconstructed += int(count)
    assert len(by_name) == 88 and reconstructed == int(rows), group
    grand_rows += reconstructed
    for name, indices in by_name.items():
        families[name][tuple(indices)] += 1
assert len(families) == 88
assert all(sum(roster.values()) == len(plan) for roster in families.values())
class_count = sum(len(roster) for roster in families.values())
row_count = sum(sum(int(blocks[i][4]) for i in key) for roster in families.values() for key in roster)
upper = max(int(row[2]) for row in plan)
print("exact ordered whole-group block selections", len(whole_keys), "distinct across", len(plan), "groups")
print("family table keys", class_count, "across", len(plan)*len(families), "references")
print("loaded rows by reference", grand_rows, "rows across distinct family table keys", row_count)
print("families by distinct table count", sorted(Counter(map(len, families.values())).items()))
print("maximum-input group ids", tuple(int(row[0]) for row in plan if int(row[2]) == upper), "rows", upper)
