# Exact input-table reuse census for the original dense profile

The pinned cut-plan and compiled block-index receipts are the census
inputs. Compare every row count to its referenced blocks, then group the
ordered block IDs by factor family. The existing preparer uses exactly
those IDs, its fixed retained axes, and the original compiled operands
to assemble a raw signed input table. The census does not identify
equivalences between different keys or predict a post-quotient speedup.

```sh
shasum -a 256 -c SHA256SUMS
cd census
python3 -B census.py | cmp - CENSUS.txt
```

The Group 934 pilot reproduces the front end of the existing original
route on a maximum-row case. Large compiled inputs and intermediate
factor states are pinned by hashes in their respective receipts.

For a fresh Group 934 run, make an empty working directory. Copy the
Group 934 scripts and schema into it, together with the plan, index,
cut axes and original preparer from census. Expose the pinned original
compiled operands as compiled/. Run the preparer with argument 934,
check the first operand fingerprint, and run the guarded driver.
Status 2 in the receipt identifies the preserved row cap. The cache
pilot checks both recorded Group 672 and Group 934 frontiers. Its
Group 672 input path refers to the original local frontier and can be
set to the same hash-verified operand on another machine.
