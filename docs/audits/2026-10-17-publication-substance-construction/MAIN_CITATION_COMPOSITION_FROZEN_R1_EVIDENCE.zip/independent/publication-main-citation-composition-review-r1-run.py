from pathlib import Path
import json,sys,subprocess,os,hashlib,dataclasses,xml.etree.ElementTree as ET,time
M=Path.cwd();P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');packet=json.loads((P/'.codex/continuity/publication-main-citation-composition-review-r1.json').read_text())
sys.path[:0]=[str(M),str(M/'scripts')]
from src.core import citations,constants
import validation.checks.citations as ck
import back_fill_primary_sources as fetch
origins={k:str(Path(v.__file__).resolve()) for k,v in [('citations',citations),('constants',constants),('check',ck),('writer',fetch)]}
assert all(Path(v).is_relative_to(M) for v in origins.values()),origins
owned=packet['owned_files']
def sources():return {p:hashlib.sha256((M/p).read_bytes()).hexdigest() for p in owned}
custody=[Path(x['path']) for x in packet['references']['authorities'] if '/Lit-Search/' in x['path']]
def held():
 return {str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'mode':p.stat().st_mode,'mtime_ns':p.stat().st_mtime_ns} for p in custody}
before={'sources':sources(),'held':held(),'origins':origins}
Path('/tmp/publication-main-citation-composition-review-r1-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(M)+':'+str(M/'scripts'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
argv=[str(P/'.venv/bin/python'),'-B','-m','pytest','-m','','-q','-p','no:cacheprovider','tests/test_d5_citations.py','tests/test_phase6i_wave1.py','tests/test_workspace_resolver.py','--junitxml=/tmp/publication-main-citation-composition-review-r1-tests.xml']
start=time.time();r=subprocess.run(argv,env=env,cwd=M,capture_output=True,text=True)
Path('/tmp/publication-main-citation-composition-review-r1-tests.stdout').write_text(r.stdout);Path('/tmp/publication-main-citation-composition-review-r1-tests.stderr').write_text(r.stderr)
suite=ET.parse('/tmp/publication-main-citation-composition-review-r1-tests.xml').getroot().find('testsuite');tests=[{'node':c.attrib['classname']+'::'+c.attrib['name'],'time':c.attrib.get('time'),'status':'failed' if c.find('failure')is not None else 'error' if c.find('error')is not None else 'skipped' if c.find('skipped')is not None else 'passed'} for c in suite.findall('testcase')]
assert r.returncode==0 and suite.attrib['tests']=='77' and suite.attrib['skipped']=='1',r.stdout
captured={}
def profile(frame,event,arg):
 if frame.f_code is ck.check_citation_primary_sources_present.__code__ and event=='return':
  for k in ['usage','undeclared_class','missing_from_registry','not_cached','abstract_only','metadata_only','class_exempt','inprep_exempt','cached']:captured[k]=frame.f_locals.get(k)
sys.setprofile(profile)
try:result=ck.check_citation_primary_sources_present()
finally:sys.setprofile(None)
assert result.passed and len(captured['undeclared_class'])==constants.CITATION_UNDECLARED_CLASS_CEILING==76 and not captured['missing_from_registry']
assert captured['undeclared_class']==json.loads(Path('/tmp/publication-main-citation-postmeasurement-r1.json').read_text())['canonical_population']['undeclared_class']
after={'sources':sources(),'held':held()};assert before['sources']==after['sources'];assert before['held']==after['held'];assert not (M/'docs/.test_missing_stubs.json').exists()
out={'argv':argv,'returncode':r.returncode,'wall_seconds':time.time()-start,'test_summary':suite.attrib,'tests':tests,'origins':origins,'before':before,'after':after,'canonical_result':{'passed':result.passed,'details':[dataclasses.asdict(d) for d in result.details],'population':captured},'source_hashes_exact':True,'held_bytes_stats_exact':True,'repository_scratch_absent':True}
Path('/tmp/publication-main-citation-composition-review-r1-tests.json').write_text(json.dumps(out,indent=2,default=lambda x:sorted(x) if isinstance(x,set) else str(x))+'\n')
print(json.dumps({'returncode':r.returncode,'test_summary':suite.attrib,'canonical_passed':result.passed,'undeclared':len(captured['undeclared_class']),'missing':len(captured['missing_from_registry']),'sources_and_held_exact':True},indent=2))
