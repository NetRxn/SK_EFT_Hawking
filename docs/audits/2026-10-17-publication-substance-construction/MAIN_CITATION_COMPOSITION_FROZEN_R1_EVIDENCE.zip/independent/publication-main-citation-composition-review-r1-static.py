from pathlib import Path
import ast,json,subprocess,hashlib,zipfile
M=Path.cwd();P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');packet=json.loads((P/'.codex/continuity/publication-main-citation-composition-review-r1.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='e8b6a73cf4e0e94003af49cb5bb866ff8d99c4c4'
def old(path):return subprocess.check_output(['git','show','HEAD:'+path])
def registry(data):
 t=ast.parse(data);n=next(n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id=='CITATION_REGISTRY' for k in n.targets));return ast.literal_eval(n.value)
b=registry(old('src/core/citations.py'));a=registry(Path('src/core/citations.py').read_bytes());added=sorted(set(a)-set(b));changed=sorted(k for k in b if b[k]!=a[k]);assert len(b)==664 and len(a)==677 and len(added)==13 and changed==['BarceloLRR2005','DawsonNielsen2006'];assert not(set(b)-set(a))
donor=registry(subprocess.check_output(['git','show','4737b36dcae1fb556449d7b816f087e0f5f4f885:src/core/citations.py']))
assert all(a[k]==donor[k] for k in added);assert a['BarceloLRR2005']==donor['BarceloLRR2005']
assert all(a[k]==b[k] for k in b if k not in changed)
for k in ['Volovik2024Vestigial','Volovik2026SecondSound','Volovik2024VacuumDecay','BakerBellini2017','CreminelliVernizzi2017','SaksteinJain2017','EzquiagaZumalacarregui2017','Abbott2017GW170817']:assert a[k]==b[k]
t1=ast.parse(old('src/core/citations.py'));t2=ast.parse(Path('src/core/citations.py').read_bytes())
def erase_registry(t):
 for n in t.body:
  if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id=='CITATION_REGISTRY' for k in n.targets):n.value=ast.Constant(None)
 return ast.dump(t,include_attributes=False)
assert erase_registry(t1)==erase_registry(t2)
assert Path('src/core/constants.py').read_bytes()==old('src/core/constants.py').replace(b'CITATION_UNDECLARED_CLASS_CEILING = 78',b'CITATION_UNDECLARED_CLASS_CEILING = 76')
assert Path('tests/test_d5_citations.py').read_bytes()==old('tests/test_d5_citations.py').replace(b'the moment a 79th undeclared entry appears',b'the moment one new undeclared entry appears')
for k in added:
 if a[k]['inprep']:
  assert all(a[k].get(x)is None for x in ['doi','arxiv','primary_source_path','doi_verified']) and a[k]['journal']=='in preparation'
assert sum(a[k]['inprep'] for k in added)==8
state_before=json.loads(old('docs/primary_sources_state.json'));state_after=json.loads(Path('docs/primary_sources_state.json').read_bytes());assert len(state_before['entries'])==649 and len(state_after['entries'])==654;new_state=sorted(set(state_after['entries'])-set(state_before['entries']));state_changed=sorted(k for k in state_before['entries'] if state_before['entries'][k]!=state_after['entries'][k]);assert state_changed==['DawsonNielsen2006'];assert new_state==['Barcelo2011','FinazziLiberatiSindoni2012','Kitaev2006','Verlinde1988','Wang2026TMDPolariton']
for p in ['papers/D1/paper_draft.tex','papers/D3/paper_draft.tex','papers/D9/paper_draft.tex','papers/E1/paper_draft.tex']:
 assert old(p).split(b'\\begin{thebibliography}',1)[0]==Path(p).read_bytes().split(b'\\begin{thebibliography}',1)[0]
for p in ['papers/D8/paper_draft.tex','papers/L1/paper_draft.tex','papers/F/paper_draft.tex','papers/D1/bundle_metadata.json','papers/E1/bundle_metadata.json']:assert old(p)==Path(p).read_bytes(),p
for key in new_state+['DawsonNielsen2006']:
 rec=state_after['entries'][key];p=(M.parent/rec['primary_source_path']);assert p.is_file() and p.stat().st_size==rec['size_bytes'] and rec['verdict']=='success'
 if key!='Verlinde1988':assert p.read_bytes().startswith(b'%PDF') and rec['tier_achieved']=='arxiv-pdf'
 else:
  d=json.loads(p.read_bytes());assert 'message' in d and 'abstract' not in d['message'] and 'body' not in d['message'] and rec['tier_achieved']=='crossref-json'
d=json.loads((M.parent/'Lit-Search/Phase-1-and-Background/primary-sources/DawsonNielsen2006.json').read_text());assert d['message']['DOI'].lower()==a['DawsonNielsen2006']['doi'].lower();assert d['message']['title']==['The Solovay-Kitaev algorithm'];assert d['message']['volume']=='6' and d['message']['page']=='81-95';assert d['message']['published-print']['date-parts'][0][0]==2006
held_before=json.load(open('/tmp/publication-main-citation-reuse-held-r1.json'));actualheld={}
for key,rec in held_before.items():
 p=Path(rec['path']);s=p.stat();v={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size_bytes':s.st_size,'mode':s.st_mode,'mtime_ns':s.st_mtime_ns};assert all(rec[k]==value for k,value in v.items());actualheld[key]=v
changed_paths=subprocess.check_output(['git','status','--short'],text=True).splitlines();assert len(changed_paths)==10,changed_paths
out={'head':head,'old_registry':len(b),'new_registry':len(a),'added':added,'changed_old':changed,'unchanged_old_records':len(b)-len(changed),'added_entries_exact_donor':True,'all_other_citations_module_AST_equal':True,'protected_current_L1_GW_entries_equal':True,'constant_single_downward_change':True,'test_docstring_only':True,'internal_inprep_identities':8,'state_old':649,'state_new':654,'state_added':new_state,'state_changed':state_changed,'scientific_bodies_metadata_human_equal':True,'Dawson_crossref_metadata':{'DOI':d['message']['DOI'],'title':d['message']['title'],'volume':d['message']['volume'],'page':d['message']['page'],'published':d['message']['published-print']},'five_original_held_custody_equal':actualheld,'status':changed_paths}
Path('/tmp/publication-main-citation-composition-review-r1-static.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['head','old_registry','new_registry','changed_old','unchanged_old_records','state_changed','added_entries_exact_donor','test_docstring_only']},indent=2))
