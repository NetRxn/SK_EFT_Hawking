from pathlib import Path
import os,sys,json,hashlib,io,contextlib,dataclasses
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'scripts')]
import httpx
import back_fill_primary_sources as fetch
from src.core import citations
assert Path(citations.__file__).resolve().is_relative_to(Path.cwd())
assert fetch.SIDECAR_PATH.resolve()==(Path.cwd()/'docs/primary_sources_state.json').resolve()
held=json.load(open('/tmp/publication-main-citation-reuse-held-r1.json'))
def custody():
 out={}
 for key,meta in held.items():
  p=Path(meta['path']);s=p.stat();out[key]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size_bytes':s.st_size,'mode':s.st_mode,'mtime_ns':s.st_mtime_ns}
 return out
before=custody()
for key,d in before.items():
 for k,v in d.items():assert held[key][k]==v,(key,k)
old=json.loads(fetch.SIDECAR_PATH.read_text());original=httpx.Client
class RefuseNetwork(original):
 def request(self,*a,**k):raise AssertionError('No network permitted in held-source registration')
httpx.Client=RefuseNetwork
steps=[]
try:
 for key in held:
  stdout=io.StringIO();stderr=io.StringIO()
  with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):code=fetch.main(['--fetch','--bibkey',key,'--no-stubs','--sleep','0'])
  assert code==0
  assert "'pre-existing': 1" in stderr.getvalue(),stderr.getvalue()
  steps.append({'bibkey':key,'returncode':code,'stdout':stdout.getvalue(),'stderr':stderr.getvalue()})
finally:httpx.Client=original
now=json.loads(fetch.SIDECAR_PATH.read_text());assert all(now['entries'][k]==v for k,v in old['entries'].items());assert set(now['entries'])-set(old['entries'])==set(held);after=custody();assert before==after
from validation.checks.citations import check_citation_primary_sources_present
captured={}
def profile(frame,event,arg):
 if frame.f_code is check_citation_primary_sources_present.__code__ and event=='return':
  for key in ['usage','undeclared_class','missing_from_registry','abstract_only','metadata_only','not_cached','class_exempt','inprep_exempt','cached']:captured[key]=frame.f_locals.get(key)
sys.setprofile(profile)
try:r=check_citation_primary_sources_present()
finally:sys.setprofile(None)
receipt={'steps':steps,'held_before_after_exact':before,'all_old_state_entries_exact':True,'old_state_entries':len(old['entries']),'new_state_entries':len(now['entries']),'network_refused':True,'no_downloads':True,'source_import':citations.__file__,'writer':fetch.__file__,'check_passed':r.passed,'canonical_population':captured,'details':[dataclasses.asdict(x) for x in r.details]}
Path('/tmp/publication-main-citation-register-r1.json').write_text(json.dumps(receipt,indent=2,default=lambda x:sorted(x) if isinstance(x,set) else str(x))+'\n')
assert not captured['missing_from_registry'];assert len(captured['undeclared_class'])==76,len(captured['undeclared_class'])
print(json.dumps({'check_passed':r.passed,'undeclared':len(captured['undeclared_class']),'missing_registry':len(captured['missing_from_registry']),'old_state_entries':len(old['entries']),'new_state_entries':len(now['entries']),'held_artifacts_exact':len(before),'import':citations.__file__,'summary':next(x.message for x in r.details if x.name=='summary')},indent=2))
