import json
from math import exp, expm1
import numpy as np
from scipy.integrate import quad

rng = np.random.default_rng(61022)
site_density = np.diag([1.0, 0.0])
identity = np.eye(2)
max_transform_error = 0.0
max_second_moment_error = 0.0
minimum_certified_margin = float("inf")
thermal_cases = 0
window_rejections = 0
zero_controls = 0

for _ in range(40):
    gap = rng.uniform(0.12, 3.6)
    beta = rng.uniform(0.03, 4.1)
    hamiltonian = (gap / 2) * np.array([[1.0, -1.0], [-1.0, 1.0]])
    energies, vectors = np.linalg.eigh(hamiltonian)
    probabilities = np.exp(-beta * energies)
    probabilities /= probabilities.sum()
    rho = (vectors * probabilities) @ vectors.conj().T
    observable_in_energy = vectors.conj().T @ site_density @ vectors
    weight = (probabilities[0] - probabilities[1]) * abs(observable_in_energy[0, 1])**2
    moment = float(np.trace(rho @ site_density @ site_density).real)
    max_second_moment_error = max(max_second_moment_error, abs(moment - 0.5))
    assert weight > 0
    assert abs(moment - 0.5) <= 2e-14

    def commutator(t, observable=site_density, state=rho):
        u = (vectors * np.exp(1j * t * energies)) @ vectors.conj().T
        observed = u @ observable @ u.conj().T
        return np.trace(state @ (observed @ observable - observable @ observed))

    for edge_fraction in (0.35, 1.0):
        lower = edge_fraction * gap
        upper = gap + 0.23
        assert lower <= gap <= upper
        absolute_bound = moment * (-expm1(-beta * lower)) / lower
        margin = absolute_bound - weight / gap
        assert margin >= 0
        minimum_certified_margin = min(minimum_certified_margin, margin)
    assert not (gap + 0.1 <= gap <= gap + 0.2)
    window_rejections += 1

    eta = rng.uniform(0.65, 2.3)
    z = rng.uniform(-1.4 * gap, 1.4 * gap) + 1j * eta
    horizon = 35 / eta

    def transform_integrand(t):
        return 1j * np.exp(1j * z * t) * commutator(t)

    real = quad(lambda t: transform_integrand(t).real, 0, horizon, epsabs=1e-10)[0]
    imag = quad(lambda t: transform_integrand(t).imag, 0, horizon, epsabs=1e-10)[0]
    integrated = real + 1j * imag
    predicted = weight * (1 / (gap - z) + 1 / (gap + z))
    error = abs(predicted - integrated)
    max_transform_error = max(max_transform_error, error)
    assert error < 5e-10
    for t in (0.0, 1 / gap, 7 / gap):
        assert abs(commutator(t, identity)) < 1e-14
        assert abs(commutator(t, site_density, identity / 2)) < 1e-14
        zero_controls += 2
    thermal_cases += 1

print(json.dumps(dict(seed=61022, thermal_cases=thermal_cases,
                      zero_controls=zero_controls, windows_excluding_atom=window_rejections,
                      max_transform_error=max_transform_error,
                      max_second_moment_error=max_second_moment_error,
                      minimum_certified_margin=minimum_certified_margin), indent=2))
