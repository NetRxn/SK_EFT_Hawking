# Finite thermal spectral control

Run `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -B finite_thermal.py`
in the project's NumPy and SciPy environment. The reference stdout is
`finite_thermal.json`. Floating point output can vary by library and platform.

The calculation starts from the two-site hopping matrix and a local density.
It independently diagonalizes the matrix and integrates the actual matrix
commutator over a finite positive-time range. It compares this against the
closed causal expression and checks the weighted moment and zero controls.
The excluded-window count tests interval membership. The data are
synthetic and have a single discrete transition, giving no device calibration
or exact nonzero continuum DKM density.
