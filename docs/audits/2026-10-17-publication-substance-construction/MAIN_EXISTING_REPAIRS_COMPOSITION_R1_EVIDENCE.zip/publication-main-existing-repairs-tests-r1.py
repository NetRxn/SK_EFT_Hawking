from pathlib import Path
import os,subprocess,json,datetime,hashlib
p=Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking');primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');prefix=Path('/tmp/publication-main-existing-repairs-tests-r1')
manifest=json.loads(Path('/tmp/publication-main-existing-repairs-compose-r1.json').read_text())
for f,v in manifest['changes'].items():assert hashlib.sha256((p/f).read_bytes()).hexdigest()==v['after_sha256'],f
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');env.pop('PYTHONPATH',None);env.pop('PYTEST_ADDOPTS',None)
r={'base':manifest['base'],'candidate':'base plus exact7path source manifest','scope':'Existing serialization/lifecycle/D7 positive+negative controls; real unchanged citation error must remain visible; no broad/native/scientific run','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'legs':[]}
legs=[('scoped',['tests/test_bundle_json_serializer.py','tests/test_d5_bundles_readiness.py::TestUnmeasuredIsDistinctFromYellow','tests/test_validate_public_surface.py::TestTexQuoteReferencesAreExtracted']),('scratch-negative',['tests/test_phase6i_wave1.py::test_extract_missing_bibkeys_emits_no_orphans'])]
for label,nodes in legs:
 argv=[str(primary/'.venv/bin/python'),'-B','-m','pytest','-m','','-q','-p','no:cacheprovider',*nodes,'--junitxml='+str(prefix)+'.'+label+'.xml']
 with Path(str(prefix)+'.'+label+'.stdout').open('w') as out,Path(str(prefix)+'.'+label+'.stderr').open('w') as err:x=subprocess.run(argv,cwd=p,env=env,stdout=out,stderr=err)
 r['legs'].append({'label':label,'argv':argv,'returncode':x.returncode});print(label,x.returncode,flush=True)
 r['scratch_residue_exists']=(p/'docs/.test_missing_stubs.json').exists()
 if label=='scoped':assert x.returncode==0
 else:assert x.returncode==1 and not r['scratch_residue_exists']
for f,v in manifest['changes'].items():assert hashlib.sha256((p/f).read_bytes()).hexdigest()==v['after_sha256'],f
r['source_conserved_during_runs']=True;r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();Path(str(prefix)+'.result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
