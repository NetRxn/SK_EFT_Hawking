from pathlib import Path
import subprocess,os,json,hashlib,datetime
R=Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking');P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(R),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
base=[str(P/'.venv/bin/python'),'-B','-m','pytest','-m','','-q','-p','no:cacheprovider']
report={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(R),'legs':[]}
for label,scope in [('scoped',['tests/test_bundle_json_serializer.py','tests/test_d5_bundles_readiness.py::TestUnmeasuredIsDistinctFromYellow','tests/test_validate_public_surface.py::TestTexQuoteReferencesAreExtracted']),('citation-negative',['tests/test_phase6i_wave1.py::test_extract_missing_bibkeys_emits_no_orphans'])]:
 argv=base+scope+['--junitxml=/tmp/publication-main-existing-repairs-review-r1-'+label+'.xml']
 result=subprocess.run(argv,cwd=R,env=env,capture_output=True,text=True)
 for suffix,content in [('stdout',result.stdout),('stderr',result.stderr)]:Path('/tmp/publication-main-existing-repairs-review-r1-'+label+'.'+suffix).write_text(content)
 report['legs'].append({'label':label,'argv':argv,'returncode':result.returncode,'stdout_tail':result.stdout[-1600:]})
report['scratch_residue_exists']=(R/'docs/.test_missing_stubs.json').exists()
assert report['legs'][0]['returncode']==0
assert report['legs'][1]['returncode']==1 and '10 unregistered' in report['legs'][1]['stdout_tail']
assert not report['scratch_residue_exists']
report['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
Path('/tmp/publication-main-existing-repairs-review-r1-tests.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
