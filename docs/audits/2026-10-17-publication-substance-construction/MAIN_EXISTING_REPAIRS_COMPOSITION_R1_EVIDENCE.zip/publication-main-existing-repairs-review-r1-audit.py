from pathlib import Path
import ast,hashlib,json,subprocess,sys,os
root=Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking')
manifest=json.loads(Path('/tmp/publication-main-existing-repairs-compose-r1.json').read_text())
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
def old(f):return git('show','HEAD:'+f)
def sha(b):return hashlib.sha256(b).hexdigest()
def subtree(src,name):
 t=ast.parse(src)
 return next(n for n in ast.walk(t) if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name)
checks={}
assert git('rev-parse','HEAD').decode().strip()==manifest['base']
changed=git('diff','--name-only').decode().splitlines()
assert set(changed)==set(manifest['changes'])
for f,info in manifest['changes'].items():
 assert sha(old(f))==info['before_sha256']
 assert sha((root/f).read_bytes())==info['after_sha256']
sys.path.insert(0,str(root/'scripts'));from bundle_json import dump_bundle_json
for code in ['D3','L2']:
 f=f'papers/{code}/bundle_metadata.json';before=json.loads(old(f));after=json.loads((root/f).read_bytes())
 assert before==after
 assert dump_bundle_json(before).encode()==(root/f).read_bytes()
 checks[code]={'all_parsed_values_conserved':True,'canonical_serializer_exact':True,'field_count':len(after)}
for code in ['D6','D8','D10']:
 f=f'papers/{code}/bundle_metadata.json';before=json.loads(old(f));after=json.loads((root/f).read_bytes());donor=json.loads(git('show','996fa93a38fbd663a42837cc6b9db6bc8f74d480:'+f))
 differences=[k for k in before if before[k]!=after[k]]
 assert differences==['stage10_status'] and set(before)==set(after)
 assert after['stage10_status']=='pending-redo'==donor['stage10_status']
 assert after['freshness_stale'] and after['stage13_redo_required']
 checks[code]={'only_changed_field':differences,'before':before['stage10_status'],'after':after['stage10_status'],'stale_redo_retained':True}
f='tests/test_validate_public_surface.py';base=ast.parse(old(f));now=ast.parse((root/f).read_bytes());donor=git('show','b0f8e3b45c14d188faace12c450e596cc0b5829b:'+f)
cls='TestTexQuoteReferencesAreExtracted'
assert ast.dump(subtree((root/f).read_bytes(),cls))==ast.dump(subtree(donor,cls))
assert [ast.dump(n) for n in base.body if not isinstance(n,ast.ClassDef) or n.name!=cls]==[ast.dump(n) for n in now.body if not isinstance(n,ast.ClassDef) or n.name!=cls]
checks['D7']={'entire_class_matches_accepted_donor':True,'all_other_AST_nodes_exact':True}
f='tests/test_phase6i_wave1.py';name='test_extract_missing_bibkeys_emits_no_orphans';base=ast.parse(old(f));now=ast.parse((root/f).read_bytes());donor=git('show','6e2983e61:'+f)
assert ast.dump(subtree((root/f).read_bytes(),name))==ast.dump(subtree(donor,name))
assert [ast.dump(n) for n in base.body if not isinstance(n,ast.FunctionDef) or n.name!=name]==[ast.dump(n) for n in now.body if not isinstance(n,ast.FunctionDef) or n.name!=name]
checks['scratch']={'complete_function_matches_composed_donor':True,'all_other_AST_nodes_exact':True,'residue_before':(root/'docs/.test_missing_stubs.json').exists()}
assert not checks['scratch']['residue_before']
# Pin actual module origins before tests; Python executable belongs to PRIMARY but imports must not.
import src.core.constants as constants
import src.core.citations as citations
import validation.checks.prose_lean_refs as refs
import bundle_json
for mod in [constants,citations,refs,bundle_json]:assert Path(mod.__file__).resolve().is_relative_to(root),mod.__file__
checks['origins']={m.__name__:m.__file__ for m in [constants,citations,refs,bundle_json]}
checks['source_hashes']={f:sha((root/f).read_bytes()) for f in changed}
checks['head']=manifest['base']
checks['git_diff_check']=subprocess.run(['git','diff','--check'],cwd=root,capture_output=True,text=True).returncode
assert checks['git_diff_check']==0
Path('/tmp/publication-main-existing-repairs-review-r1-audit.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
