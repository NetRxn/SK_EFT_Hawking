import json
import os
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,"/tmp/publication-l1-pairing-r1.hy5gTm")
import diagnostic as d
import preregister as q

frozen=next(row for row in map(json.loads,d.EVIDENCE.open()) if 'path' in row)
target=d.key(frozen['target'])
W=d.r5.Work
work=W(cap=100)
records=[]
def refuses(name, expected, run):
    try:
        run()
    except RuntimeError as error:
        assert expected in str(error), error
        records.append([name,str(error)])
    else:
        raise AssertionError(name)
E,P=d.p['E'],d.p['P']
outer=(0,0,0,1,0,1)
label=(2,*outer)
operand=E(((0,P((((),d.Q(1)),))),))
coframes={(0,0):operand,(1,1):operand}
choice={label:(((0,0),(1,1)),operand)}
inputs=({}, {}, coframes, choice, {target[2]:operand}, coframes, {outer:operand})
z=(coframes,choice)
with patch.object(d.r10,'LOCAL_CAP',0):
    refuses('live projections','quartic local cap',
        lambda:d.trace(target,inputs,z,W(cap=1000),0))
    refuses('joined residual tables','quartic local cap',
        lambda:q.residual_rows(target,coframes,choice,*z,W(cap=1000),0))
with patch.object(d.r10,'LATER_CAP',0):
    refuses('later path','diagnostic later cap',
        lambda:d.trace(target,inputs,z,W(cap=1000),0))
refused_work=W(cap=0)
refuses('charged vertex visit','fiber work cap',
        lambda:d.trace(target,inputs,z,refused_work,0))
assert refused_work.used==0
print(json.dumps(records,indent=2))
