import ast
import json
from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path

original=Path('/tmp/publication-task4-multicenter-s2s2-r2.original.jsonl')
author=Path('/tmp/publication-l1-pairing-r1.hy5gTm')
def read(p):
    return [json.loads(s) for s in p.read_text().splitlines()]
def immutable(x):
    return tuple(map(immutable,x)) if isinstance(x,list) else x
def exact(seq):
    return F(*seq[:2]),F(*seq[2:])
def parse(s):
    expr=ast.parse(s,mode="eval").body
    assert isinstance(expr,ast.Call) and expr.func.id=="QComplex"
    assert not expr.args and len(expr.keywords)==1 and expr.keywords[0].arg=="storage"
    return exact(ast.literal_eval(expr.keywords[0].value))
def mult(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def add(a,b):
    return a[0]+b[0],a[1]+b[1]
def minus(a):
    return -a[0],-a[1]
def sign_mask(masks):
    used=set()
    inversions=0
    for m in masks:
        bits={i for i in range(m.bit_length()) if (m>>i)&1}
        assert not used&bits
        inversions+=sum(i>j for i in used for j in bits)
        used.update(bits)
    return (-1)**inversions,sum(1<<i for i in used)
def signed(masks, factors):
    sign,mask=sign_mask(masks)
    result=(sign,0)
    for f in factors:
        result=mult(result,f)
    return result,sign,mask
def canonical(key):
    return Counter((family,immutable(index)) for family,index in key)
def expanded(key):
    assert all(not conj for _,_,conj in key)
    return canonical([(family,index) for family,index,conj in key])
def record_key(row):
    target=row['target']
    return target['mask_hex'],tuple(target['slot']),row['direction']
def zero_counts():
    return ((F(0),F(0)),0)
def fold(bag,key,v,count):
    o,n=bag[key]
    bag[key]=add(o,v),n+count

rows={record_key(row):row for row in read(original) if 'path' in row}
observed=[]
for row in read(author/'trace.final.jsonl'):
    if not 'paths' in row:
        continue
    frozen=rows[record_key(row)]
    assert row['target']==frozen['target']
    assert row['peak']<=8192 and row['render_peak']<=8192 and row['work']<=20_000_000
    assert row['local']['y_rows']<=8192
    grouped=defaultdict(zero_counts)
    branch=defaultdict(zero_counts)
    paths=Counter()
    for ls,v,sg,components,factors in row['paths']:
        ls=immutable(ls)
        parts=immutable(components)
        fac=tuple(map(exact,factors))
        val=exact(v)
        res,sign,mask=signed([int(c[0],16) for c in components],fac)
        assert (res,sign,mask)==(val,sg,int(frozen['target']['mask_hex'],16))
        assert sum((expanded(k) for _,k in components),Counter())==canonical(frozen['target']['symbols'])
        fold(grouped,(ls[0],(),ls[3]),val,1)
        fold(branch,ls,val,1)
        paths[(ls,val,sg,parts,fac)]+=1
    expected={immutable(k):(parse(v),n) for k,v,n in frozen['table']}
    assert grouped==expected and row['count']==len(expected)
    assert branch[immutable(frozen['branch'])]==(parse(frozen['witness']),frozen['paths'])
    unpaired=paths.copy()
    pairs=0
    while unpaired:
        path,n=unpaired.popitem()
        l,v,s,c,f=path
        w=l[1]
        twin=((l[0],w[:-2]+(w[-2]^1,w[-1]^1),*l[2:]),minus(v),s,c,(f[0],minus(f[1]),*f[2:]))
        assert twin!=path and unpaired.pop(twin)==n
        pairs+=n
    assert 2*pairs==len(row['paths'])
    observed.append((record_key(row),len(expected),len(row['paths']),pairs))
assert [(n,p,t) for _,n,p,t in observed]==[(12,96,48),(4,32,16),(4,48,24)]

found=[]
for name in ('chirality.jsonl','double-chirality.jsonl'):
    for row in read(author/name):
        if not 'candidate' in row:
            continue
        candidate=row['candidate']
        identity=(row['from_target'],tuple(candidate['slot']),row['direction'])
        frozen=rows[identity]
        path=row['path']
        assert row['chosen_branch']==frozen['branch']
        changes={i for i,(a,b) in enumerate(zip(path,frozen['path'],strict=True)) if a!=b}
        assert changes==({5,8} if row['direction']==1 else {5})
        for i in changes:
            before,after=frozen['path'][i],path[i]
            assert before[0]==after[0]=='0x0'
            old,new=({k[1][2] for k in t[1] if k[0]=='q'} for t in (before,after))
            assert (old,new) in [({'L'},{'R'}),({'R'},{'L'})]
            assert sum(k[0]=='q' for k in before[1])==sum(k[0]=='q' for k in after[1])==4
        masks=[int(m,16) for m,_,_ in path]
        _,mask=sign_mask(masks)
        assert mask==int(candidate['mask_hex'],16)==int(identity[0],16)
        assert all(parse(v)!=(0,0) for _,_,v in path)
        key=sum((canonical(k) for _,k,_ in path),Counter())
        assert key==canonical(candidate['symbols'])!=canonical(frozen['target']['symbols'])
        _,localmask=sign_mask(masks[3:9])
        localk=sum((canonical(k) for _,k,_ in path[3:9]),Counter())
        assert localmask==int(row['residual_mask'],16)
        result,count=(F(0),F(0)),0
        for wl,zl,v,n,left,right in row['complement_rows']:
            _,joined=sign_mask([int(left[0],16),int(right[0],16)])
            assert joined==localmask
            assert expanded(left[1])+expanded(right[1])==localk
            result,count=add(result,exact(v)),count+n
        assert (result,count)==(exact(row['residual_value']),row['local_path_count'])
        assert result!=(0,0) and row['local_peak']<=8192 and row['work']<=20_000_000
        found.append((identity,tuple(sorted(key.items())),result,count))
assert len({(i,k) for i,k,_,_ in found})==3
assert [(v,n) for _,_,v,n in found]==[((0,F(1,16)),4),((-F(1,16),0),4),((F(1,8),0),8)]
print(json.dumps({'observed':observed,'candidate_results':[(i,[str(x) for x in v],n) for i,_,v,n in found]},indent=2))
