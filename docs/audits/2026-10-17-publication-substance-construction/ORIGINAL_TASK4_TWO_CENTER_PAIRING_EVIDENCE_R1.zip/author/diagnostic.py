from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from runpy import run_path
import json

PIN = Path("/tmp/publication-task4-multicenter-s2s2-r2.py")
EVIDENCE = PIN.with_suffix(".original.jsonl")
assert sha256(PIN.read_bytes()).hexdigest() == "3e467a34ba1e2c774b3c2e1812c9fa34dd51ad94566602f7d3480f852d1e6ec5"
assert sha256(EVIDENCE.read_bytes()).hexdigest() == "e2d3bc7529532171be1d04f109f479dab01cef349616e2e394297f72123c74b0"
p = run_path(str(PIN))
r5, r10, base, Q, S = (p[k] for k in ("r5","r10","base","Q","S"))

def freeze(x):
    return tuple(map(freeze,x)) if isinstance(x,list) else x

def key(record):
    return (int(record["mask_hex"],16),
            tuple(S(family,freeze(index)) for family,index in record["symbols"]),
            tuple(record["slot"]))

def describe(m,k):
    return [hex(m),[(s.family,s.index,s.conjugated) for s in k]]

def trace(target, inputs, z_inputs, work, control):
    cx,hx,cw,ww,contacts,cy,hy = inputs
    cap = base.Admission(r10.LOCAL_CAP)
    used = control
    def rows(operands):
        nonlocal used
        projected = []
        try:
            for operand in operands:
                view = base.projection(operand,target,work,cap,used)
                projected.append(view)
                used += len(view)
            yield from r10.stream_rows(tuple(projected),target,work)
        finally:
            used -= sum(map(len,projected))
    def local(coframes,choices):
        nonlocal used
        retained = []
        for label,(components, polynomial) in choices.items():
            if label[0] != 2:
                continue
            work.charge("diagnostic_vertex_labels")
            for m,k,_,v in rows(tuple(coframes[c] for c in components)+(polynomial,)):
                cap.check(used+1)
                used += 1
                retained.append((m,k,label,v))
        return retained
    def outer(coframes,traces,contact):
        for label,polynomial in traces.items():
            work.charge("diagnostic_vertex_labels")
            _,_,mu,nu,a,b = label
            yield from ((m,k,label,v) for m,k,_,v in rows(
                (coframes[mu,a],coframes[nu,b],polynomial)+contact))
    left = local(cw,ww)
    right = local(*z_inputs)
    index = defaultdict(list)
    for m,k,label,v in right:
        work.charge("diagnostic_right_index")
        cap.check(used+1+int((m,k) not in index))
        used += 1+int((m,k) not in index)
        index[m,k].append((label,v))
    later = []
    for row in outer(cy,hy,()):
        cap.check(used+1)
        if len(later) >= r10.LATER_CAP:
            raise RuntimeError("diagnostic later cap")
        used += 1
        later.append(row)
    mask, symbols, slot = target
    labelled = []
    for xm,xk,xlabel,xv in outer(cx,hx,(contacts[slot],)):
        for ym,yk,ylabel,yv in later:
            work.charge("diagnostic_outer_pairs")
            if xm & ym:
                continue
            rest_mask = mask ^ (xm|ym)
            if rest_mask.bit_count()!=8:
                continue
            remaining = r5.subtract(symbols,tuple(sorted(xk+yk)))
            if remaining is None or len(remaining)!=14:
                continue
            for wm,wk,wlabel,wv in left:
                work.charge("diagnostic_complement_tests")
                if wm & rest_mask != wm:
                    continue
                zk = r5.subtract(remaining,wk)
                if zk is None:
                    continue
                zm = rest_mask ^ wm
                for zlabel,zv in index.get((zm,zk),()):
                    work.charge("diagnostic_matches")
                    cap.check(used+1)
                    used += 1
                    sign = (p["independent_sign"](xm,wm) *
                            p["independent_sign"](xm|wm,zm) *
                            p["independent_sign"](xm|wm|zm,ym))
                    factors = (xv,wv,zv,yv)
                    value = xv*wv*zv*yv*sign
                    labelled.append(((xlabel,wlabel,zlabel,ylabel),value,sign,
                                    ((xm,xk),(wm,wk),(zm,zk),(ym,yk)),factors))
    return labelled,cap.peak,{"w_rows":len(left),"z_rows":len(right),"y_rows":len(later)}

def reconcile(labelled,record,work,cap,control):
    collapsed = defaultdict(lambda: [Q(0),0])
    cap.check(control+len(labelled)+len(record["table"])+1)
    for labels,v,*_ in labelled:
        work.charge("diagnostic_collapse")
        k = (labels[0],(),labels[3])
        cap.check(control+len(labelled)+len(collapsed)+int(k not in collapsed))
        collapsed[k][0] += v
        collapsed[k][1] += 1
    assert len(collapsed) == len(record["table"])
    for k,v,n in record["table"]:
        work.charge("diagnostic_compare_frozen")
        actual, actual_n = collapsed[freeze(k)]
        assert (str(actual), actual_n) == (v,n)
    selected = freeze(record["branch"])
    selected_n, selected_sum = 0, Q(0)
    for labels,v,*_ in labelled:
        work.charge("diagnostic_compare_witness")
        if labels == selected:
            selected_n += 1
            selected_sum += v
    assert selected_n == record["paths"]
    assert str(selected_sum) == record["witness"]
    return len(collapsed)

if __name__ == "__main__":
    work = r5.Work(cap=r10.WORK_CAP,oracle_record_cap=r10.PAIR_CAP)
    reg,centers,inputs,z_inputs,raws,d0,d1 = p["setup"](work)
    print(json.dumps({"setup_work":work.used,"centers":centers}),flush=True)
    with EVIDENCE.open() as rows:
        next(rows)
        for row in rows:
            work.charge("diagnostic_frozen_bytes",len(row))
            control=row.count("[")+row.count("{")
            base.Admission(r10.LOCAL_CAP).check(control)
            record=json.loads(row)
            labelled,peak,local=trace(key(record["target"]),inputs,z_inputs,work,control)
            output_cap=base.Admission(r10.LOCAL_CAP)
            count=reconcile(labelled,record,work,output_cap,control)
            render_reserve=control+sum(18+sum(len(k) for _,k in detail)
                                       for _,_,_,detail,_ in labelled)
            output_cap.check(render_reserve)
            work.charge("diagnostic_render",render_reserve)
            print(json.dumps(dict(target=record["target"],direction=record["direction"],
                count=count,peak=peak,render_peak=output_cap.peak,baseline_record_bound=control,local=local,work=work.used,
                paths=[(labels,v.storage,sign,[describe(*pair) for pair in detail],
                        [f.storage for f in factors])
                       for labels,v,sign,detail,factors in labelled])),flush=True)
            del labelled, record
    print(json.dumps(dict(total_work=work.used,work_classes=dict(work.counts))),flush=True)
