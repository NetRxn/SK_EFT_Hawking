"""Locate the sign flip in the individual coframes and trace from each selected lineage."""
from fractions import Fraction
import json
from diagnostic import EVIDENCE, Q, freeze, p, r10, r5
from preregister import decode
from src.vestigial.original_coefficients import matrix_multiply

def coeff(e,m,k):
    return sum((v for (n,l,slot),v in r10.r4.rows(e) if (m,k,())==(n,l,slot)),Q(0))

reg=r10.r4.o.OriginalRegulator()
x=reg.sites[0]
w=reg.step(x,2)[0]
with EVIDENCE.open() as rows:
    next(rows)
    for line in rows:
        row=json.loads(line)
        factor=decode(row["path"])[3:6]
        label=freeze(row["branch"])[1]
        expected=[(label[3],label[5]),(label[4],label[6])]
        original=[coeff(r10.r4.exterior(reg,(w,mu,a)),*factor[i][:2])
                  for i,(mu,a) in enumerate(expected)]
        assert original==[f[2] for f in factor[:2]]
        reflected=[coeff(r10.r4.exterior(reg,(w,mu,a^1)),*factor[i][:2])
                   for i,(mu,a) in enumerate(expected)]
        alternatives=[]
        # A reflected decomposition can exchange exterior bits between the
        # coframes even when its assembled local exterior key is unchanged.
        wanted_mask=factor[0][0]|factor[1][0]
        source=[]
        for i,(mu,a) in enumerate(expected):
            source.append([(m,v) for (m,k,slot),v in
                           r10.r4.rows(r10.r4.exterior(reg,(w,mu,a^1)))
                           if k==factor[i][1] and not slot and m&wanted_mask==m])
        for (m1,v1) in source[0]:
            for (m2,v2) in source[1]:
                if m1&m2==0 and m1|m2==wanted_mask:
                    alternatives.append([hex(m1),hex(m2),v1.storage,v2.storage,r5.mask_sign(m1,m2)])
        a,b=label[-2:]
        gamma=reg.gamma
        direct=matrix_multiply(matrix_multiply(gamma[a],gamma[b]),reg.gamma5)
        mirrored=matrix_multiply(matrix_multiply(gamma[a^1],gamma[b^1]),reg.gamma5)
        block_signs={}
        for hand,indices in (("L",range(2)),("R",range(2,4))):
            pairs=[(direct[i][j],mirrored[i][j]) for i in indices for j in indices]
            assert any(v for v,_ in pairs)
            signs=[sign for sign in (1,-1) if all(sign*v==u for v,u in pairs)]
            assert len(signs)==1
            block_signs[hand]=signs[0]
        assert block_signs["L"]==-block_signs["R"]
        hands={s.index[2] for s in factor[2][1] if s.family=="q"}
        assert len(hands)==1
        hand=hands.pop()
        assert len(alternatives)==1
        original_value=original[0]*original[1]*factor[2][2]*r5.mask_sign(factor[0][0],factor[1][0])
        reflected_value=reflected[0]*reflected[1]*factor[2][2]*block_signs[hand]*alternatives[0][-1]
        assert reflected_value==-original_value
        print(json.dumps(dict(target=row["target"]["mask_hex"],w_frame=label,
            original_trace_hand=hand,reflection_sign_by_chirality=block_signs,
            original_complete_w=original_value.storage,reflected_complete_w=reflected_value.storage,
            original_mask=[hex(f[0]) for f in factor[:2]],
            original_coframes=[v.storage for v in original],
            original_wedge_sign=r5.mask_sign(factor[0][0],factor[1][0]),
            original_trace=factor[2][2].storage,
            reflected_same_individual_mask=[v.storage for v in reflected],
            reflected_same_assembled_key=alternatives)))
