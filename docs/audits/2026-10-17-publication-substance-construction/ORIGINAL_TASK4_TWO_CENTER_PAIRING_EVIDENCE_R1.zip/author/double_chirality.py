"""Resolve the additional local cancellation in the third fixed outer path."""
from itertools import islice,product
import json
from chirality import candidates
from diagnostic import EVIDENCE,Q,base,describe,freeze,key,p,r5,r10
from preregister import CARRY,combine,decode,residual_rows

LIMIT_EACH = 4

def verify_pairs(summands,wkey,zkey):
    def flip(label):
        return label[:-2]+(label[-2]^1,label[-1]^1)
    sub={(w,z,l,r):(v,n) for w,z,v,n,l,r in summands}
    for w,z,v,n,l,r in summands:
        if w==wkey and z==zkey and v:
            if (sub.get((flip(w),z,l,r))==(v,n) and sub.get((w,flip(z),l,r))==(v,n)):
                return True
    return False

def main():
    work=r5.Work(cap=r10.WORK_CAP,oracle_record_cap=r10.PAIR_CAP)
    reg=r10.r4.o.OriginalRegulator()
    w=reg.step(reg.sites[0],2)[0]
    z=reg.step(w,0)[0]
    cw,raw_w,ww,_=r10.r9.source_roster(reg,w,work)
    del raw_w
    cz,raw_z,wz,_=r10.r9.source_roster(reg,z,work)
    del raw_z
    with EVIDENCE.open() as rows:
        next(rows)
        for line in rows:
            carry=CARRY+line.count("[")+line.count("{")+2*LIMIT_EACH
            base.Admission(r10.LOCAL_CAP).check(carry)
            work.charge("double_chirality_input_bytes",len(line))
            row=json.loads(line)
            if row["direction"]!=1:
                continue
            target=key(row["target"])
            labels=freeze(row["branch"])
            wkey,zkey=labels[1:3]
            fixed=decode(row["path"])
            assert combine(fixed)==target[:2]
            w_paths=list(islice(candidates(ww[wkey][1],fixed[5],work),LIMIT_EACH))
            z_paths=list(islice(candidates(wz[zkey][1],fixed[8],work),LIMIT_EACH))
            w_mirror,w_replacement=w_paths[0]
            assert w_mirror
            single=fixed[:5]+(w_replacement,)+fixed[6:]
            mask,symbols=combine(single[3:9])
            summands,peak=residual_rows((mask,symbols,target[2]),cw,ww,cz,wz,work,carry)
            assert not sum((v for _,_,v,*_ in summands),Q(0))
            # First isolate a same-key Z reflection in the single-W-change fiber.
            sub={(w,z,l,r):(v,n) for w,z,v,n,l,r in summands}
            zflip=zkey[:-2]+(zkey[-2]^1,zkey[-1]^1)
            assert any(sub.get((wkey,zflip,l,r))==(-v,n) and v
                       for w,z,v,n,l,r in summands if w==wkey and z==zkey)
            print(json.dumps(dict(control="single W, remaining opposite Z pair",
                paths=sum(n for _,_,_,n,*_ in summands),summands=len(summands),peak=peak)),flush=True)
            del summands,sub
            trials=[]
            for trial,((wmirror,wreplacement),(zmirror,zreplacement)) in enumerate(product(w_paths,z_paths),1):
                path=fixed[:5]+(wreplacement,)+fixed[6:8]+(zreplacement,)+fixed[9:]
                mask,symbols=combine(path)
                candidate=mask,symbols,target[2]
                assert mask==target[0] and candidate!=target
                localmask,localk=combine(path[3:9])
                summands,peak=residual_rows((localmask,localk,target[2]),cw,ww,cz,wz,work,carry)
                total=sum((v for _,_,v,*_ in summands),Q(0))
                n=sum(n for _,_,_,n,*_ in summands)
                same_sign=verify_pairs(summands,wkey,zkey)
                trials.append(dict(trial=trial,wmirror=wmirror,zmirror=zmirror,
                                   paths=n,summands=len(summands),same_sign=same_sign,total=total.storage))
                if total and same_sign:
                    print(json.dumps(dict(candidate=r5.fingerprint(candidate),from_target=hex(target[0]),
                        direction=row["direction"],trial=trial,w_mirror_coordinates=wmirror,
                        z_mirror_coordinates=zmirror,chosen_branch=labels,
                        path=[(hex(m),[(s.family,s.index) for s in k],str(v)) for m,k,v in path],
                        residual_mask=hex(localmask),residual_value=total.storage,
                        local_path_count=n,local_peak=peak,work=work.used,trial_rows=trials,
                        complement_rows=[(wk,zk,v.storage,c,describe(*l),describe(*r))
                                         for wk,zk,v,c,l,r in summands])),flush=True)
                    break
                del summands
            else:
                print(json.dumps(dict(refusal="no same-sign W/Z reflection with nonzero local residual",
                    limit=LIMIT_EACH**2,work=work.used,trial_rows=trials)),flush=True)
    print(json.dumps(dict(total_work=work.used,work_classes=dict(work.counts))),flush=True)

if __name__=="__main__":
    main()
