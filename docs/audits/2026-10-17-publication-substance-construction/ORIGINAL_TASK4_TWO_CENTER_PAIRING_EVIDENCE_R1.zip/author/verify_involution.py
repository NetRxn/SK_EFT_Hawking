"""Audit the observed W-only reflection on complete saved path records."""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import sys

def freeze(x):
    return tuple(map(freeze,x)) if isinstance(x,list) else x

def neg(v):
    rn,rd,inn,ind=v
    return -rn,rd,-inn,ind

def flip(p):
    labels,value,exterior,keys,factors=p
    w=labels[1]
    reflected=w[:-2]+(w[-2]^1,w[-1]^1)
    return ((labels[0],reflected,labels[2],labels[3]),neg(value),exterior,keys,
            (factors[0],neg(factors[1]),factors[2],factors[3]))

if __name__=="__main__":
    input=Path(sys.argv[1])
    print(json.dumps({"source_sha256":sha256(input.read_bytes()).hexdigest()}))
    for row in map(json.loads,input.open()):
        if "paths" not in row:
            continue
        paths=Counter(map(freeze,row["paths"]))
        assert all(p!=flip(p) and p==flip(flip(p)) for p in paths)
        assert paths==Counter({flip(p):n for p,n in paths.items()})
        groups=Counter((p[0][0],p[0][3]) for p in paths)
        labels=sorted(set((p[0][1],flip(p)[0][1]) for p in paths))
        factors=sorted(set((p[4][1],flip(p)[4][1]) for p in paths))
        print(json.dumps(dict(mask=row["target"]["mask_hex"],slot=row["target"]["slot"],
            direction=row["direction"],groups=len(groups),paths=paths.total(),
            pairs=paths.total()//2,w_label_exchange=labels,w_signed_factors=factors)))
