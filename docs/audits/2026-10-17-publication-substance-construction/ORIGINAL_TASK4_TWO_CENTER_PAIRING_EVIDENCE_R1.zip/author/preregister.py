"""Probe ordered center complements with the recorded exterior/contact path held fixed."""
from collections import defaultdict
from hashlib import sha256
from itertools import islice
import ast
import json

from diagnostic import EVIDENCE, Q, S, base, describe, freeze, key, p, r5, r10

LIMIT_PER_DIRECTION = 24
CARRY = 768

def combine(lineage):
    mask=0
    symbols=[]
    for m,k,_ in lineage:
        if m & mask:
            return None
        mask |= m
        symbols.extend(k)
    return mask,tuple(sorted(symbols))

def coefficient(text):
    node=ast.parse(text,mode="eval").body
    assert node.func.id=="QComplex" and not node.args and node.keywords[0].arg=="storage"
    rn,rd,inn,ind=ast.literal_eval(node.keywords[0].value)
    from fractions import Fraction
    return Q(Fraction(rn,rd),Fraction(inn,ind))

def decode(path):
    return tuple((int(m,16),tuple(S(family,freeze(index)) for family,index in k),coefficient(v))
                 for m,k,v in path)

def single_substitutions(path,labels,w,z,cw,cz,work):
    sources=[]
    for i,center,label,coframes in ((3,w,labels[1],cw),(6,z,labels[2],cz)):
        for step,(axis,spin) in enumerate(((label[3],label[5]),(label[4],label[6]))):
            idx=i+step
            old=path[idx][1][0]
            sources.append((idx,center,coframes[axis,spin],old))
    for mode in (0,1,2):
        for idx,center,poly,old in sources:
            occupied,_=combine(path[:idx]+path[idx+1:])
            for (m,k,slot),v in r10.r4.rows(poly):
                work.charge("preregister_substitution_rows")
                assert not slot and len(k)==1 and k[0].family=="q"
                symbol=k[0]
                if m & occupied or (m,k)==path[idx][:2]:
                    continue
                if mode==0 and not (symbol.index[:2]==old.index[:2] and
                                    symbol.index[2]!=old.index[2]):
                    continue
                if mode==1 and not (symbol.index[:3]==old.index[:3] and
                                    symbol.index[3]!=old.index[3]):
                    continue
                if mode==2 and symbol!=old:
                    continue
                yield mode,idx,path[:idx]+((m,k,v),)+path[idx+1:]

def residual_rows(residual,cw,ww,cz,wz,work,carry):
    mask,symbols,_=residual
    admission=base.Admission(r10.LOCAL_CAP)
    left,lsize=p["local_table"](residual,cw,ww,work,admission,carry)
    right,rsize=p["local_table"](residual,cz,wz,work,admission,carry+lsize)
    summands=[]
    for (lm,lk),llabels in left.items():
        work.charge("preregister_complement_tests")
        if lm & mask != lm:
            continue
        rk=r5.subtract(symbols,lk)
        if rk is None:
            continue
        rm=mask ^ lm
        for wl,(wv,wn) in llabels.items():
            for zl,(zv,zn) in right.get((rm,rk),{}).items():
                work.charge("preregister_complement_summands")
                admission.check(carry+lsize+rsize+len(summands)+1)
                v=wv*zv*r5.mask_sign(lm,rm)
                summands.append((wl,zl,v,wn*zn,(lm,lk),(rm,rk)))
    return summands, admission.peak

def main():
    work=r5.Work(cap=r10.WORK_CAP,oracle_record_cap=r10.PAIR_CAP)
    reg=r10.r4.o.OriginalRegulator()
    x=reg.sites[0]
    w=reg.step(x,2)[0]
    z=reg.step(w,0)[0]
    cw,raw_w,ww,_=r10.r9.source_roster(reg,w,work)
    del raw_w
    cz,raw_z,wz,_=r10.r9.source_roster(reg,z,work)
    del raw_z
    all_targets=set()
    with EVIDENCE.open() as rows:
        next(rows)
        for line in rows:
            base.Admission(r10.LOCAL_CAP).check(line.count("[")+line.count("{"))
            work.charge("preregister_input_bytes",len(line))
            row=json.loads(line)
            all_targets.add(key(row["target"]))
    with EVIDENCE.open() as rows:
        next(rows)
        for line in rows:
            carry=CARRY+line.count("[")+line.count("{")+len(all_targets)
            base.Admission(r10.LOCAL_CAP).check(carry)
            work.charge("preregister_input_bytes",len(line))
            row=json.loads(line)
            target=key(row["target"])
            labels=freeze(row["branch"])
            fixed=decode(row["path"])
            assert combine(fixed)==target[:2]
            found=False
            # The old local residual is independently constrained before changing it.
            lm,lk=combine(fixed[3:9])
            old,old_peak=residual_rows((lm,lk,target[2]),cw,ww,cz,wz,work,carry)
            old_n=sum(n for _,_,_,n,*_ in old)
            old_value=sum((v for _,_,v,*_ in old),Q(0))
            print(json.dumps(dict(old=hex(target[0]),slot=target[2],direction=row["direction"],
                old_local_paths=old_n,old_local_summands=len(old),
                old_local_value=old_value.storage,old_local_peak=old_peak)),flush=True)
            del old
            for trial,(mode,idx,path) in enumerate(islice(
                    single_substitutions(fixed,labels,w,z,cw,cz,work),LIMIT_PER_DIRECTION),1):
                mask,symbols=combine(path)
                candidate=mask,symbols,target[2]
                if candidate in all_targets:
                    continue
                all_targets.add(candidate)
                lm,lk=combine(path[3:9])
                assert lm.bit_count()==8 and len(lk)==14
                summands,peak=residual_rows((lm,lk,target[2]),cw,ww,cz,wz,work,
                                           carry+len(all_targets))
                value=sum((v for _,_,v,*_ in summands),Q(0))
                n=sum(n for _,_,_,n,*_ in summands)
                if value and len(summands)==1:
                    wl,zl,v,_,l,r=summands[0]
                    assert wl==labels[1] and zl==labels[2]
                    print(json.dumps(dict(candidate=r5.fingerprint(candidate),from_target=hex(target[0]),
                        direction=row["direction"],trial=trial,mode=mode,operand=idx,
                        chosen_branch=labels,
                        path=[(hex(m),[(s.family,s.index) for s in k],str(v)) for m,k,v in path],
                        left=describe(*l),right=describe(*r),residual_value=v.storage,
                        local_path_count=n,local_peak=peak,work=work.used)),flush=True)
                    found=True
                    break
                del summands
            if not found:
                print(json.dumps(dict(refusal="no unique nonzero residual",
                    old=hex(target[0]),limit=LIMIT_PER_DIRECTION,work=work.used)),flush=True)
    print(json.dumps(dict(total_work=work.used,work_classes=dict(work.counts))),flush=True)

if __name__=="__main__":
    main()
