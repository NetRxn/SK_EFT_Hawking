"""Preregister exact opposite-hand W plaquette targets, with fixed outer paths."""
from fractions import Fraction
from hashlib import sha256
import json

from diagnostic import EVIDENCE,Q,S,base,describe,freeze,key,p,r5,r10
from preregister import CARRY,combine,decode,residual_rows

TRIAL_LIMIT = 16

def candidates(poly, old, work):
    m,k,v=old
    assert m==0
    hands={s.index[2] for s in k if s.family=="q"}
    assert len(hands)==1
    hand=hands.pop()
    opposite="L" if hand=="R" else "R"
    mirrored=tuple(sorted(S(s.family,s.index[:2]+(opposite,)+s.index[3:],s.conjugated)
                          if s.family=="q" else s for s in k))
    for match in (True,False):
        for (pm,pk,slot),pv in r10.r4.rows(poly):
            work.charge("chirality_source_scan")
            assert not pm and not slot
            if (pk==mirrored)==match and all(s.family!="q" or s.index[2]==opposite for s in pk):
                yield match,(pm,pk,pv)

def main():
    work=r5.Work(cap=r10.WORK_CAP,oracle_record_cap=r10.PAIR_CAP)
    reg=r10.r4.o.OriginalRegulator()
    x=reg.sites[0]
    w=reg.step(x,2)[0]
    z=reg.step(w,0)[0]
    cw,raw_w,ww,_=r10.r9.source_roster(reg,w,work)
    del raw_w
    cz,raw_z,wz,_=r10.r9.source_roster(reg,z,work)
    del raw_z
    old_keys=set()
    with EVIDENCE.open() as rows:
        next(rows)
        for line in rows:
            work.charge("chirality_input_bytes",len(line))
            base.Admission(r10.LOCAL_CAP).check(line.count("[")+line.count("{")+len(old_keys))
            old_keys.add(key(json.loads(line)["target"]))
    with EVIDENCE.open() as rows:
        next(rows)
        for line in rows:
            carry=CARRY+line.count("[")+line.count("{")+len(old_keys)
            base.Admission(r10.LOCAL_CAP).check(carry)
            work.charge("chirality_input_bytes",len(line))
            row=json.loads(line)
            target=key(row["target"])
            labels=freeze(row["branch"])
            fixed=decode(row["path"])
            assert combine(fixed)==target[:2]
            wkey=labels[1]
            flip=wkey[:-2]+(wkey[-2]^1,wkey[-1]^1)
            source=ww[wkey][1]
            trial_rows=[]
            for trial,(mirrored,replacement) in enumerate(candidates(source,fixed[5],work),1):
                if trial>TRIAL_LIMIT:
                    break
                path=fixed[:5]+(replacement,)+fixed[6:]
                mask,symbols=combine(path)
                candidate=mask,symbols,target[2]
                assert mask==target[0] and candidate not in old_keys
                localmask,localk=combine(path[3:9])
                summands,peak=residual_rows((localmask,localk,target[2]),cw,ww,cz,wz,work,carry)
                total=sum((v for _,_,v,*_ in summands),Q(0))
                n=sum(n for _,_,_,n,*_ in summands)
                # Match the W reflection with the same residual key and the same ordered Z row.
                intended=[(value,count,left,right) for wk,zk,value,count,left,right in summands
                          if wk==wkey and zk==labels[2]]
                flipped=[(value,count,left,right) for wk,zk,value,count,left,right in summands
                         if wk==flip and zk==labels[2]]
                same_sign=any(v and (v,c,l,r) in flipped for v,c,l,r in intended)
                trial_rows.append(dict(trial=trial,mirror_coordinates=mirrored,same_sign=same_sign,
                                        paths=n,summands=len(summands),total=total.storage))
                if total and same_sign:
                    old_keys.add(candidate)
                    print(json.dumps(dict(candidate=r5.fingerprint(candidate),from_target=hex(target[0]),
                        direction=row["direction"],trial=trial,mirror_coordinates=mirrored,
                        chosen_branch=labels,w_trace_hands=[
                            sorted({s.index[2] for s in operand[1] if s.family=="q"})
                            for operand in (fixed[5],replacement)],
                        path=[(hex(m),[(s.family,s.index) for s in k],str(v)) for m,k,v in path],
                        residual_mask=hex(localmask),residual_value=total.storage,
                        local_path_count=n,local_peak=peak,work=work.used,trial_rows=trial_rows,
                        complement_rows=[(wk,zk,v.storage,c,describe(*l),describe(*r))
                                         for wk,zk,v,c,l,r in summands])),flush=True)
                    break
                del summands
            else:
                trial=0
            if not trial_rows or not (trial_rows[-1]["same_sign"] and trial_rows[-1]["total"]!=Q(0).storage):
                print(json.dumps(dict(refusal="no same-sign W reflection and nonzero residual",
                    old=hex(target[0]),limit=TRIAL_LIMIT,work=work.used,trial_rows=trial_rows)),flush=True)
    print(json.dumps(dict(total_work=work.used,work_classes=dict(work.counts))),flush=True)

if __name__=="__main__":
    main()
