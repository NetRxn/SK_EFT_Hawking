"""Independent receipt arithmetic and preregistration integrity, without source replay."""
import ast
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import sys

def read(path):
    return map(json.loads,Path(path).open())

def c(v):
    return Fraction(*v[:2]),Fraction(*v[2:])

def form(value):
    node=ast.parse(value,mode="eval").body
    assert node.func.id=="QComplex" and len(node.keywords)==1 and node.keywords[0].arg=="storage"
    return c(ast.literal_eval(node.keywords[0].value))

def freeze(x):
    return tuple(map(freeze,x)) if isinstance(x,list) else x

def terms(path):
    mask=0
    key=Counter()
    for m,k,value in path:
        assert any(form(value))
        bits=int(m,16)
        assert not mask&bits
        mask|=bits
        key.update(map(freeze,k))
    return mask,key

frozen={(row["target"]["mask_hex"],tuple(row["target"]["slot"]),row["direction"]):row
        for row in read("/tmp/publication-task4-multicenter-s2s2-r2.original.jsonl") if "path" in row}
seen=set()
for file in sys.argv[1:]:
    for row in read(file):
        if "candidate" not in row:
            continue
        target=row["candidate"]
        f=frozen[row["from_target"],tuple(target["slot"]),row["direction"]]
        assert f["branch"]==row["chosen_branch"]
        changed={i for i,(a,b) in enumerate(zip(f["path"],row["path"],strict=True)) if a!=b}
        expected={5,8} if "z_mirror_coordinates" in row else {5}
        assert changed==expected
        for i in changed:
            before,after=f["path"][i],row["path"][i]
            assert before[0]==after[0]=="0x0"
            hands=[{s[1][2] for s in p[1] if s[0]=="q"} for p in (before,after)]
            assert len(hands[0])==len(hands[1])==1 and not hands[0]&hands[1]
        mask,key=terms(row["path"])
        assert mask==int(target["mask_hex"],16)
        assert key==Counter(map(freeze,target["symbols"])) and key!=terms(f["path"])[1]
        identity=(mask,tuple(sorted(key.items())),tuple(target["slot"]))
        assert identity not in seen
        seen.add(identity)
        paths=row["complement_rows"]
        assert sum(p[3] for p in paths)==row["local_path_count"]
        assert tuple(sum((c(p[2])[i] for p in paths),Fraction()) for i in (0,1))==c(row["residual_value"])
        assert any(c(row["residual_value"]))
        for wl,zl,v,n,lk,rk in paths:
            lm,rm=(int(k[0],16) for k in (lk,rk))
            assert not lm&rm
            assert lm|rm==int(row["residual_mask"],16)
            assert Counter((family,freeze(idx)) for k in (lk,rk) for family,idx,conj in k[1]
                           if not conj)==terms(row["path"][3:9])[1]
        print(json.dumps(dict(direction=row["direction"],mask=target["mask_hex"],
            slot=target["slot"],changed_operands=sorted(changed),
            signed=row["residual_value"],path_count=row["local_path_count"])))
