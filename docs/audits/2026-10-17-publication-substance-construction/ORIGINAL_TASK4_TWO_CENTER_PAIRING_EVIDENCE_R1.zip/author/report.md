# Original N16 selected two-center cancellation diagnostic

Author scope is scratch-only against 22d5708f1863fc0c7d1614ee3b5648c10f7fc627.
The numerical source is unchanged from the original execution pin acf6e548.
The primary authorized no fresh full coefficient run. This diagnostic did
not invoke original admission, identity replay, or an original output writer.
It used only three already frozen targets and exact path support around them.

## Exact reconstruction

The separate diagnostic built the actual source rosters and projected the
ordered x, w, z, contact, y path factors against the frozen full exterior
mask and symbol key. It keeps one row per streamed source path, not only
grouped coefficients. For the late join the degree-two contact can be
moved across the two degree-four local factors with sign +1. The full
inter-group exterior sign is recomputed separately, from ordered bit
inversions. Every retained partial record includes full masks, anchor
and coordinate multisets, four labels, and exact complex factors.

The collapse reproduces every frozen group coefficient and positive
path count, and reproduces each frozen fully labelled witness.

| Target mask | Slot, seed direction | Outer groups | Paths | Opposite-sign pairs |
| --- | --- | ---: | ---: | ---: |
| 0x25805500000001202c4066 | literal, 0 | 12 | 96 | 48 |
| 0x200000000e01e60002008000900099 | mixed, 0 | 4 | 32 | 16 |
| 0x1000d10dc0000004001b00025 | mixed, 1 | 4 | 48 | 24 |

The distinct mixed requests share the actual combined contact observable.
The finite pairing is explicit. Keep x, z, y labels, all four partial
masks and symbol multisets, all other partial factors and the outer
exterior sign. In the ordered W factor keep the four plane axes and
replace only frame indices (a,b) with (a xor 1,b xor 1). The W scalar
reverses between +i/8 and -i/8. The exact complete path multiset equals
its reflected multiset including duplicate counts. Applying the map
twice returns the path record and no records are fixed.

For the three selected atomic lineages the paired W coframes use the
same individual masks, symbols and wedge sign. The coframe product
keeps its sign in the literal target and reverses it in both mixed
targets. The exact gamma matrix reflection has block signs L+ and R-
for frames (0,2) and L- and R+ for frames (2,1). The frozen W plaquette
trace hands are R, L and R respectively. Hence the whole W scalar
reverses for all three lineages by different coframe/trace combinations.
This establishes the cancellation mechanism for the complete selected
path multisets and a constructive check on their witnesses. It is
not a sector-wide vanishing statement.

The bounded diagnostic charged 271,147 logical operations. The
target-dependent projection, path, and index peaks were 410, 291
and 369 records, including the charged frozen baseline reserves.
The separate collapse/output envelopes peaked at 4,881, 1,766
and 2,534 against 8,192 logical records. These logical counts
do not measure interpreter bytes, prebuilt source roster storage,
or native RSS. The original logical prefix remains unchanged.

## Next-target selection

Changing one actual W/Z coframe operand at a time, with the other
twelve seed operands fixed, gave no unique nonzero ordered local
complement among the first 24 proposals per direction. The preserved
exploratory receipt reports 358,011 charges. This scan had a stronger
uniqueness acceptance than necessary and establishes no wider refusal.

The directed alternative keeps every coframe and exterior mask
fixed and flips the single whole W plaquette chirality. The
block calculation predicts the existing W reflection now preserves,
rather than reverses, the W sign on the unchanged coframes. The
probe checks this against actual source monomials and then checks the
complete ordered W/Z local complement, with the outer seed path
fixed. A nonzero local complement discriminates this cancellation
mechanism, but other outer paths can still cancel the full target.

Two first mirrored-coordinate trials succeed with the W trace alone.
The third target gives a same-sign W pair but retains a same-key
opposite-sign Z pair. All sixteen bounded W-only trials at that
target gave zero local totals. The first jointly mirrored W/Z trial
has same-sign reflected partners at both centers and a nonzero local
total. The three preregistered full keys are in the two JSONL receipts
and can be distinguished from the frozen inputs by their changed
anchored symbol multisets even though their masks and slots match.

| Request | Changed plaquette hands | Complete fixed-outer local value | Local paths |
| --- | --- | ---: | ---: |
| Literal, 0 | W R to L | i/16 | 4 |
| Mixed, 0 | W L to R | -1/16 | 4 |
| Mixed, 1 | W R to L and mirrored Z | 1/8 | 8 |

The W-only probe charged 143,552 operations, with accepted local
peaks of 1,057 and 1,024. The mixed-direction-1 double probe charged
26,670 operations, with local peaks 1,038 for the single-W control
and 1,027 for the double substitution. An independent script using
Fraction receipt arithmetic checks the three full keys, preserved
exterior masks and slots, exact changed operand set, full anchored
symbol multiset, complement disjointness, path counts and signed sums.
The literal seed's shared reciprocal coframe coordinate is retained
because no coframe factor changed.

Next action is independent source/cap review and, if admitted, a
separate original candidate computing and comparing every complete
signed outer group against the raw-oriented oracle. These controls
give only complete W/Z sums with a fixed outer path. They do not
establish a nonzero full coefficient, a broader nonzero sector,
full Z, or publication acceptance. There is no scope change.

The first scratch attempt exited at a nested target-record decode
error before any coefficient trace. Its exact script and receipts
are preserved. The corrected script decoded the frozen target
record explicitly, tightened prospective output accounting, and
completed all three reconstructions. The predecessor and terminal
inputs remain unchanged.
