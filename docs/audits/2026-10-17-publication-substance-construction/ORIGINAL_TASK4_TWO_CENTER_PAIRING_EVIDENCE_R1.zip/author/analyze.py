import collections
from fractions import Fraction
import json
import sys

def freeze(x):
    return tuple(map(freeze,x)) if isinstance(x,(list,tuple)) else x

def q(xs):
    return Fraction(*xs[:2]), Fraction(*xs[2:])

def compare(p,t):
    lp, vp, sp, kp, fp = p
    lt, vt, st, kt, ft = t
    return (
        tuple(i for i in range(4) if lp[i]!=lt[i]),
        tuple(i for i in range(4) if kp[i][0]!=kt[i][0]),
        tuple(i for i in range(4) if kp[i][1]!=kt[i][1]),
        tuple(i for i in range(4) if fp[i]!=ft[i]),
        sp != st,
    )

for row in map(json.loads,open(sys.argv[1])):
    if "paths" not in row:
        continue
    groups = collections.defaultdict(list)
    for path in row["paths"]:
        lp, *_ = path
        groups[freeze((lp[0],lp[3]))].append(path)
    counters = collections.Counter()
    exact_exterior_and_symbols = collections.Counter()
    print(row["target"]["mask_hex"])
    for label, paths in groups.items():
        for p in paths:
            r,i=q(p[1])
            partners=[t for t in paths if q(t[1])==(-r,-i)]
            matches=collections.Counter(compare(p,t) for t in partners)
            if not matches:
                print("unpaired magnitude",label,p[1])
            counters.update(matches)
        vals=collections.Counter(tuple(p[1]) for p in paths)
        exact_exterior_and_symbols.update(tuple(compare(p,t)[1:3])
            for p in paths for t in paths if q(p[1])==tuple(-v for v in q(t[1])))
    print("partner changes",counters)
    print("exterior and symbols",exact_exterior_and_symbols)
    print("example group", [(p[0], p[1], p[2]) for p in next(iter(groups.values()))])
