from fractions import Fraction as F
from itertools import product
from pathlib import Path
from ast import literal_eval
from collections import defaultdict
from src.core.formulas import original_plaquette,original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator,QComplex,matrix_multiply
import sys

p=Path(sys.argv[1])
R=defaultdict(list)
for line in (p/'root.tsv').read_text().splitlines():
    n,u,v,a,b,i,j,r,s=line.split('\t')
    if (literal_eval(u),literal_eval(v))==((0,)*int(n),(1,)*int(n)):
        R[int(n),int(a),int(b)].append((int(i),int(j),QComplex(F(r),F(s))))

def rep(M,n):
    a,b=M[0];c,d=M[1]
    if n==0:return ((QComplex(1),),)
    if n==1:return M
    assert n==2
    return ((a*a,a*b,b*b),(2*a*c,a*d+b*c,2*b*d),(c*c,c*d,d*d))

def D(q,p,qspin,inverse):
    if inverse:q=tuple((r[0],*(-x for x in r[1:])) for r in q)
    U=original_spin4_link(*q)
    a=rep(tuple(tuple(U[i][j] for j in range(2)) for i in range(2)),p)
    b=rep(tuple(tuple(U[2+i][2+j] for j in range(2)) for i in range(2)),qspin)
    return tuple(tuple(a[i][j]*b[k][l] for j,l in product(range(p+1),range(qspin+1))) for i,k in product(range(p+1),range(qspin+1)))

reg=OriginalRegulator()
G=matrix_multiply(matrix_multiply(reg.gamma[0],reg.gamma[1]),reg.gamma5)
Q=[(F(1,2),)*4,(F(3,5),0,F(4,5),0),(0,F(12,13),0,F(5,13)),(0,1,0,0),(1,0,0,0),(0,0,0,1)]
bad=0
for t,seed in product(range(2),range(6)):
    x=(0,0,0,t)
    y=reg.step(x,0)[0]
    z=reg.step(x,3)[0]
    V,W,B,A=[(Q[(seed+i)%6],Q[(2*seed+j)%6]) for i,j in ((0,3),(1,0),(3,2),(4,5))]
    def orient(q):
        return tuple((a[0],*(-r for r in a[1:])) for a in q) if t else q
    anchors={(x,3):original_spin4_link(*orient(V)),(y,3):original_spin4_link(*orient(W)),
             (x,0):original_spin4_link(*A),(z,0):original_spin4_link(*B)}
    def trace_original(word):
        U=original_plaquette(reg,x,3,0,anchors,word)
        return sum((U[i][j]*G[j][i] for i,j in product(range(4),repeat=2)),QComplex())
    for n in (1,2):
        values=[]
        for closed in (True,False):
            value=QComplex()
            for (m,p,q),entries in R.items():
                if m!=n:continue
                factors=[D(A,p,q,True),D(W,p,q,not t),D(B,p,q,False),D(V,p,q,bool(t))]
                if not closed:factors.reverse()
                d=(p+1)*(q+1)
                for i4,i0,c in entries:
                    for i1,i2,i3 in product(range(d),repeat=3):
                        a,b,c1,e=factors
                        value+=c*a[i0][i1]*b[i1][i2]*c1[i2][i3]*e[i3][i4]
            values.append(value)
        reference=trace_original('closed')
        other=trace_original('printed')
        if n==2:reference=reference*reference;other=other*other
        assert values==[reference,other],(t,seed,n,values,reference,other)
        bad+=reference!=other
assert bad>0
print(24,'exact literal/root tensor controls',bad,'separate closed from reversed wiring')
