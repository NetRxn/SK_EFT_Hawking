#!/bin/sh
set -eu
for case in 1 2 3 4 5 6 7 8
do
  python3 network_cached.py "$1" "$2" "$case" > "case$case.out" || test "$?" = 3
done
