from pathlib import Path
import subprocess
import sys

for i in range(9):
    source=Path(f'case{i}.out')
    if not source.exists():continue
    rows=source.read_text().splitlines()
    if not rows or not rows[-1].startswith('EXACT channel zero'):continue
    A,B=rows[-2].split()[1:3]
    names=A.split('+')+B.split('+')
    # Repeat just the subnetwork with all external columns open.
    result=subprocess.run([sys.executable,'witness.py',*sys.argv[1:],str(i),*names],
                          check=True,capture_output=True,text=True)
    assert result.stdout.splitlines()[-1].startswith(f'EXACT channel zero {i} ')
    print(i,','.join(names),result.stdout.splitlines()[-1],flush=True)
    Path(f'witness{i}.out').write_text(result.stdout)
