# L1 odd-root support correction and signed subnetwork receipts

Science checkout 51e7c745e. Corrected author evidence against checkpoint
dc706134e. No representative is subtracted and no publication gate advances.

## Support correction

The earlier proposed first-chirality spatial center equation used total
coframe degree for its right-hand side. The original coframe is a sum of
terms linear in coordinates of either chirality. The equation for one
chirality must use the number of factors in that chirality, which has
not been fixed by occupation. The literal Haar control here has one
coframe and no left spin. It gives a nonzero right-fundamental moment
- i/2. The valid center equation after dropping the allocation sums both
chiralities on the representation side and uses total coframe degree.
Zero-load anchor pairings and independent left/right temporal singlet
conditions still apply. The earlier parity assignment counts and derived
portfolio coverage threshold are withdrawn.

The corrected worklist visits 71 branch nodes and retains 36 channel
assignments. A literal traversal of all 1,048,576 local tuples matches
the worklist. The old nine are a strict subset. Swapping both chiralities
permutes the 36-element support. This statement is about assignments,
with no assumed equality of their coefficients. The corrected temporal
and spatial moment tables cover ten and 23 unique anchor patterns.

## Closed plaquette and original subset

For a time-first root, the closed word is A^-1 V_y^-1 B V_x.
The matrix coefficient C_(i4,i0) sews this order via the four pairs
(i0,i1), (i1,i2), (i2,i3), (i3,i4). The spatial own-anchor factor
carries the first pair, the other layer carries the third, and temporal
anchors carry the second and fourth. The previous printed-order sketch
is superseded. The Haar-sampled temporal inverses in the other layer are
a change of integration variable. The 24 fixed finite-link cases match
the literal source class polynomials for powers one and two. Sixteen
also distinguish the closed word from its reversal.

Of the old nine candidates, exact Gaussian-integer contraction gives
five zero channels. Repeating just each vanishing subnetwork with
boundary indices open verifies that every boundary coefficient is zero.
The other four hit prospective or allocation limits in the author
schedule. Their status is unresolved. This old numbering is used only
under legacy-subset. There are 27 additional channels in corrected-support.
No combined signed pilot coefficient is available.

## Replay

Restore the directed-square inputs into PRIOR as in the earlier
checkpoints. OLD is e9678295f extracted. Reconstruct the signed spatial
and site factors of dc706134e in SEWN following that receipt.
FROZEN is the extracted dff31cc3a archive. Set PYTHONPATH to science
checkout 51e7c745e and use the repository Python environment for PY.

```sh
"$PY" wiring_control.py "$OLD" > wiring-control.out
cd corrected-support
python3 joint_support.py "$FROZEN/preflight" "$PRIOR" "$FROZEN" > support.out
python3 brute_support.py "$PRIOR" > brute-support.out
"$PY" temporal.py > temporal.out
"$PY" spatial.py > spatial.out
"$PY" parity_counterexample.py "$PRIOR/AUTHOR/coframes.tsv" > parity-counterexample.out
cd ../legacy-subset
python3 network.py "$OLD" "$SEWN" 0 > case0.out
sh batch.sh "$OLD" "$SEWN"
python3 replay_witnesses.py "$OLD" "$SEWN" > witnesses-first.out
```
