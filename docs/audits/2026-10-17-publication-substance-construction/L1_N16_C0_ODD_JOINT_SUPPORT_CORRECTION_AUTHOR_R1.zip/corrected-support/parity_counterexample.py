from itertools import product
from pathlib import Path
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import Polynomial,QComplex,Symbol,haar_polynomial
import sys
coframes=[tuple(map(int,r.split())) for r in Path(sys.argv[1]).read_text().splitlines()]
coords=[Polynomial.variable(Symbol('q',(j//8,1,'L' if j%8<4 else 'R',j%4))) for j in range(16)]
matrix=original_spin4_link((1,0,0,0),tuple(coords[4:8]))
owner,word,mask=next((o,a,m) for o,a,m,k,r,i in coframes if k in range(4,8))
source=sum((QComplex(r,i)*coords[j] for o,a,m,j,r,i in coframes if (o,a,m)==(owner,word,mask)),Polynomial())
moments=[(i,j,haar_polynomial(source*matrix[2+i][2+j])) for i,j in product(range(2),repeat=2)]
rows=[(i,j,value.real,value.imag) for i,j,z in moments for key,value in z.terms if not key]
assert rows
print('literal coframe',owner,word,mask,'right-fundamental Haar moments',rows)
print('total coframe degree 1, first chirality doubled-spin sum 0')
