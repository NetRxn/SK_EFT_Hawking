from collections import Counter
from fractions import Fraction as F
from itertools import combinations, permutations
from pathlib import Path
import inspect
import json
import sys

from src.vestigial import original_coefficients as py

ZERO = (F(0), F(0))
ONE = (F(1), F(0))

def add(a, b):
    return a[0] + b[0], a[1] + b[1]

def mul(a, b):
    return a[0]*b[0] - a[1]*b[1], a[0]*b[1] + a[1]*b[0]

def poly_add(a,b):
    out=dict(a)
    for k,v in b.items():
        out[k]=add(out.get(k,ZERO),v)
    return {k:v for k,v in out.items() if v!=ZERO}

def poly_mul(a,b):
    out={}
    for ka,va in a.items():
        for kb,vb in b.items():
            k=tuple(sorted(ka+kb))
            out[k]=add(out.get(k,ZERO),mul(va,vb))
    return {k:v for k,v in out.items() if v!=ZERO}

def direct_minor(entries, columns):
    total={}
    for perm in permutations(columns):
        inversions=sum(a>b for i,a in enumerate(perm) for b in perm[i+1:])
        term={():((-1)**inversions*ONE[0],ONE[1])}
        for i,j in enumerate(perm):
            term=poly_mul(term,entries.get((i,j),{}))
        total=poly_add(total,term)
    return total

def to_project(poly):
    return py.Polynomial(tuple((tuple(py.Symbol("J",(i,)) for i in k),py.QComplex(*v))
        for k,v in poly.items()))

def build_case(n,kind):
    entries={}
    for i in range(n):
        for j in range(n):
            if kind=="zero" or (kind=="sparse" and (i+2*j)%3!=0):
                continue
            row=0 if kind=="repeated-row" else i
            values={(): (F((row+2*j)%5-2,row+j+1),F((2*row+j)%3-1,j+2)),
                    ((row+j)%3,): (F(j-1, row+1), F(row-j,2))}
            entries[i,j]={k:v for k,v in values.items() if v!=ZERO}
    return entries

def observe(fn):
    lines,start=inspect.getsourcelines(fn)
    stored=next(i+start for i,line in enumerate(lines) if line.strip()=="states=nxt")
    stages=[]
    def tracer(frame,event,arg):
        if event=="line" and frame.f_lineno==stored:
            stages.append(dict(frame.f_locals["nxt"]))
        return tracer
    def entry(frame,event,arg):
        if event=="call" and frame.f_code is fn.__code__:
            return tracer
        return None
    def run(matrix):
        assert sys.gettrace() is None
        sys.settrace(entry)
        try:
            value=fn(matrix)
        finally:
            sys.settrace(None)
        out=stages[:]
        stages.clear()
        return value,out
    return run

run=observe(py.determinant_polynomial)
counts=Counter()
for n in range(6):
    for kind in ("dense","sparse","repeated-row","zero"):
        entries=build_case(n,kind)
        m=py.SparseMatrix(n,tuple((ij,to_project(p)) for ij,p in entries.items() if p))
        actual,stages=run(m)
        assert len(stages)==n
        for i,states in enumerate(stages,1):
            assert all(mask.bit_count()==i and mask < 1<<n for mask in states)
            for cols in combinations(range(n),i):
                mask=sum(1<<j for j in cols)
                expected=to_project(direct_minor(entries,cols))
                assert states.get(mask,py.Polynomial())==expected,(n,kind,i,cols)
                counts[kind]+=1
        assert actual==to_project(direct_minor(entries,tuple(range(n))))
        counts["final"]+=1
print(json.dumps({"counts":dict(sorted(counts.items())),"prefix_states":sum(counts[k]
    for k in ("dense","sparse","repeated-row","zero")),
    "scope":"Exact current Python stage states, all selected columns for dimensions 0 through 5",
    "oracle":"Direct Leibniz permutations with independent rational-complex polynomial operations",
    "empty":"Empty determinant verified in all four matrix families"},indent=2))
