from collections import Counter
from contextlib import redirect_stdout
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import importlib.util
import io
import json

from src.vestigial import original_coefficients as py

f=Path(__file__).with_name("publication-l1-determinant-dp-controls-r1.py")
spec=importlib.util.spec_from_file_location("prefix_controls",f)
o=importlib.util.module_from_spec(spec)
with redirect_stdout(io.StringIO()):
    spec.loader.exec_module(o)

labels=(100,101)
slots=((),(0,),(1,),(0,0),(0,1),(1,1))
def scale(c, value):
    return c*value[0], c*value[1]

def scaled_shift(poly,labels,factor):
    return {tuple(sorted(k+labels)):scale(factor,v) for k,v in poly.items()}

def raw_slots(poly):
    out={key:{} for key in slots}
    for symbols,value in poly.items():
        label=tuple(j-100 for j in symbols if j in labels)
        if len(label)>2:
            continue
        rest=tuple(j for j in symbols if j not in labels)
        factor=2 if len(label)==2 and label[0]==label[1] else 1
        out[label][rest]=scale(factor,value)
    return tuple(o.to_project(out[k]) for k in slots)

def matrix(n,entries):
    return py.SparseMatrix(n,tuple((ij,o.to_project(v)) for ij,v in entries.items() if v))

counts=Counter()
for n in range(5):
    for kind in ("dense","sparse","repeated-row","zero"):
        entries=o.build_case(n,kind)
        inc=(o.build_case(n,"sparse"),o.build_case(n,"dense"))
        acceleration={(0,0):o.build_case(n,"repeated-row"),(0,1):o.build_case(n,"sparse"),
                      (1,1):o.build_case(n,"off-diagonal")}
        ordinary={}
        for i in range(n):
            for j in range(n):
                ij=(i,j)
                poly=entries.get(ij,{})
                for index,table in enumerate(inc):
                    poly=o.poly_add(poly,scaled_shift(table.get(ij,{}),(labels[index],),F(1)))
                for key,table in acceleration.items():
                    poly=o.poly_add(poly,scaled_shift(table.get(ij,{}),tuple(labels[k] for k in key),
                        F(1,2) if key[0]==key[1] else F(1)))
                ordinary[ij]=poly
        result=py.determinant_jet(matrix(n,entries),tuple(matrix(n,t) for t in inc),
                                   {k:matrix(n,t) for k,t in acceleration.items()})
        expected=raw_slots(o.direct_minor(ordinary,tuple(range(n))))
        assert result.slots()==expected,(n,kind)
        counts["determinants"]+=1
        counts["coefficient_slots"]+=len(slots)
        for k,scalar in zip(slots,expected,strict=True):
            if k in ((0,0),(1,1)) and scalar.terms:
                counts["nonzero_diagonal_second_slots"]+=1
            if k==(0,1) and scalar.terms:
                counts["nonzero_mixed_slots"]+=1
print(json.dumps({"counts":dict(sorted(counts.items())),
    "scope":"Current determinant_jet and exact independent Leibniz determinant of formal second-order perturbations",
    "convention":"Ordinary coefficients use half the diagonal acceleration and are rescaled by two on diagonal readback",
    "matrix_dimensions":[0,1,2,3,4]},indent=2))
