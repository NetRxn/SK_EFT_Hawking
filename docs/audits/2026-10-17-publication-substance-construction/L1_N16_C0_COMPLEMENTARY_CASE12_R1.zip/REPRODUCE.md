# Complementary tuple 0 child case 12

Restore the complementary outer parent from the separator archive pinned in
review/SOURCE_PINS.txt. Recreate its distinct (33,(1,)) input with the
author exact-multicut.py using case index 12. Reduce with tag primary and
use contract-reduced-label.py. Re-reduce the preserved row-cap state under
the rescue tag and use contract-peer.py. The resulting cap checkpoint is
the seven-factor row-cap-physical-slice-dense-label-rescue-reduced.pkl.

Run run-primary.py with that parent in fresh scratch, then reduce-open.py
with inner indices 0 through 8, and sum-case12.py. Verify the resulting
frontier hashes. The separate inner-0 pilot in the manifest is generated
by exact-multicut.py on the seven-factor parent with case index 0. Use
only trusted checkpoint inputs when deserializing.

The independent reports preserve exact inverse lifts, lineage and replays.
Compare preceding-twelve.tsv to twelve-term-retally.tsv in the committed
complementary cases 6–11 archive. Run python3 verify-and-retally.py to
cross-check the nine raw, normalized and authored values and reproduce the
exact 13/48 partial sum.
