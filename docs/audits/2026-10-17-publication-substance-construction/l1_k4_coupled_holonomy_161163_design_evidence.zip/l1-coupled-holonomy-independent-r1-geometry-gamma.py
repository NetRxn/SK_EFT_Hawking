from pathlib import Path
from collections import Counter,defaultdict
from itertools import product,combinations_with_replacement
import signal,time,json,ast,sys,runpy
signal.alarm(30);start=time.perf_counter()
P=Path('/tmp');W=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research');A=W/'.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction'
manifest=next(r for l in (A/'l1_k4_census.out.txt').read_text().splitlines() if (r:=json.loads(l))['kind']=='paired-k4-census');selected={r['index']:r for r in manifest['rows'] if r['index'] in (161,163)}
geometry={}
def root(parent,x):
 while parent.get(x,x)!=x:x=parent[x]
 return x
def forest(edges):
 parent={};vertices=set()
 for q,a in edges:
  y=q^(1<<a);vertices.update((q,y));u,v=root(parent,q),root(parent,y)
  if u==v:return False,len(vertices),None
  parent[u]=v
 return True,len(vertices),len({root(parent,x) for x in vertices})
for word,row in selected.items():
 frame={q:(0,1) for q in range(16) if q!=row['omitted']};frame.update((q,tuple(ax)) for q,ax in row['changes']);sources=((0,2),(1,2));edges=defaultdict(list);faces={}
 for q,axes in sorted(frame.items()):
  for a in axes:
   y=q^(1<<a);edges[min(q,y),max(q,y),a].append((q,a))
  a,b=sorted(set(range(4))-set(axes));faces[q,a,b]={(q,a),(q^(1<<a),b),(q^(1<<b),a),(q,b)}
 original=dict(faces);protected=set(sources)|{(v,a) for lo,hi,a in edges for v in (lo,hi)};peeled=[]
 while True:
  incid=Counter(e for es in faces.values() for e in es);target=next((f for f,es in sorted(faces.items()) if any(incid[e]==1 and e not in protected for e in es)),None)
  if target is None:break
  peeled.append(target);del faces[target]
 assert len(frame)==15 and sum(map(len,frame.values()))==30 and len(edges)==20 and len(peeled)==6 and len(faces)==9
 assert all((min(q,q^(1<<a)),max(q,q^(1<<a)),a) not in edges for q,a in sources)
 incoming=Counter(q^(1<<a) for q,axes in frame.items() for a in axes);ends=Counter(v for q,a in sources for v in (q,q^(1<<a)));assert all(4*(q in frame)+2*incoming[q]+2*ends[q]==8 for q in range(16))
 x=7 if word==161 else 6;C0=(x^4,1);D0=(x,2);K=(x,1);H=(x^2,2);r=(x^6,2);E=(x^6,3);F=(x^2,3)
 fixed=[*sources,C0,D0,E,F];assert forest(fixed)==(True,8,2) and not forest(fixed+[H])[0]
 assert H==(r[0]^4,2) and H!=r and H in set.union(*faces.values())
 assert all(e not in protected for e in (E,F))
 routed=[]
 for e in (C0,D0,K):
  q,a=e;y=q^(1<<a);key=min(q,y),max(q,y),a;labels=edges[key];assert len(labels)==1
  center,axis=labels[0];routed.append({'directed':e,'edge':key,'center':center,'axis':axis,'slot':frame[center].index(axis),'center_flag':int(center==key[1]),'anchor_flag':int(q==key[1])})
 assert all(z['slot']==1 and z['center_flag']==0 and z['anchor_flag']==1 for z in routed)
 assert frame[x]==(0,3) and len(faces)==len(set(faces)) and x not in (routed[-1]['center'],)
 geometry[word]={'frame':frame,'sources':sources,'edges':dict(edges),'faces':faces,'forest':fixed,'routed':routed,'peeled':peeled}
a,b=geometry[161],geometry[163];assert {q^1:axes for q,axes in a['frame'].items()}==b['frame'];assert {(q^1,i,j):{(x^1,k) for x,k in es} for (q,i,j),es in a['faces'].items()}==b['faces'];assert {(q^1,i) for q,i in a['forest']}==set(b['forest'])
# Use actual canonical pure function ASTs only; no scientific module initialization.
ns={}
for path,names in [(A/'l1_direct_a_haar.py',{'mul','adj'}),(A/'l1_extended_mixed_curvature_core.py',{'face_vector','face_tensor'})]:
 body=[n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names];exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),ns)
ns.update(product=product,Counter=Counter,PAIR_INDEX={p:i for i,p in enumerate(combinations_with_replacement(range(8),2))},unit=lambda j:tuple(int(i==j) for i in range(4)))
def ga(a,b):return a[0]+b[0],a[1]+b[1]
def gm(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def mat(q):
 a,b,c,d=q;return (((a,-d),(-c,-b)),((c,-b),(a,d)))
def mm(a,b):return tuple(tuple(ga(gm(a[i][0],b[0][j]),gm(a[i][1],b[1][j])) for j in range(2)) for i in range(2))
def md(a):return tuple(tuple((a[j][i][0],-a[j][i][1]) for j in range(2)) for i in range(2))
def mv(m):return (-m[0][1][1],-m[0][1][0],-m[0][0][1])
NAMES={'H':(5,2),'K':(7,1),'J':(9,2),'L':(13,2),'M':(9,3),'N':(13,3)};FIXED=[(1,2),(1,3),(5,3),(3,1),(7,2)]
words=[(('H',False),('K',False)),(('J',True),),(('L',True),('H',False)),(('M',True),('N',False),('J',False)),(('N',True),('H',True),('M',False),('L',False))];facekeys=[(7,1,2),(1,2,3),(5,2,3),(9,2,3),(13,2,3)]
checks=0
for t in range(128):
 coordinates={e:((1,0,0,0),)*2 for e in FIXED}
 for k,e in enumerate(NAMES.values()):coordinates[e]=tuple(tuple(((t*(i+1)+3*k+2*chir+i*i)%7)-3 for i in range(4)) for chir in range(2))
 for chir in (0,1):
  for f,word in zip(facekeys,words):
   result=mat((1,0,0,0))
   for name,dag in word:
    m=mat(coordinates[NAMES[name]][chir]);result=mm(result,md(m) if dag else m)
   for component,value in enumerate(mv(result)):
    assert ns['face_vector'](f,coordinates,chir,component)==value;checks+=1
# Compare every coefficient of independent explicit-holonomy tensors, not just support counts.
ind=runpy.run_path(str(P/'l1-coupled-holonomy-independent-r1-math.py'),run_name='independent_common') if False else None
# Load only definitions/constants before mode dispatch; own helper file has no scientific imports.
text=(P/'l1-coupled-holonomy-independent-r1-math.py').read_text().split('mode=sys.argv[1]')[0];own={};exec(compile(text,'independent-polynomial-definitions','exec'),own)
fixed={e:((1,0,0,0),)*2 for e in FIXED};totals=[]
for i,(f,names) in enumerate(zip(facekeys,own['FACES'])):
 rows=0
 for c in combinations_with_replacement(range(6),2):
  direct=own['facepoly'](i,c);canonical=ns['face_tensor'](f,tuple(NAMES[n] for n in names),fixed,c);assert direct==canonical,(f,c);rows+=len(direct)
 totals.append(rows)
# Center interface: compare a direct expanded gamma bilinear square with grouped face_channels.
sys.path.insert(0,str(A))
from l1_normalization_opposed_fourth import L
from l1_extended_mixed_center_gamma import face_channels
from l1_extended_offset_witness import center_weights,coframe
v=(2,-3,5,7,-11,13);direct=Counter()
for a,b,c,d in product(range(4),repeat=4):
 u=sum(w*v[i] for i,w in L[a,c]);z=sum(w*v[i] for i,w in L[b,d]);direct[tuple(sorted((a,b))),tuple(sorted((c,d)))]+=u*z
reference=Counter();wrong=Counter()
for i,j in combinations_with_replacement(range(6),2):
 assert center_weights(((i,j),))==face_channels((i,j))
 for key,w in face_channels((i,j)).items():reference[key]+=w*v[i]*v[j];wrong[key]+=w*v[i]*v[j]*(2 if i!=j else 1)
assert {k:v for k,v in direct.items() if v}=={k:v for k,v in reference.items() if v};assert reference!=wrong
# Existing endpoint exchange is signed in its canonical owner; sources route original directed endpoints.
coframe_ast=next(n for n in ast.parse((A/'l1_extended_offset_witness.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='coframe');assert '-1' in ast.unparse(coframe_ast)
print(json.dumps({'geometry_words':list(geometry),'both_forests':{'edges':6,'vertices':8,'components':2},'fixing_opposite_H_creates_cycle':True,'full15centers20edges2sources16degree8':True,'both_source_edges_not_action_edges':True,'exact_XOR1_frames_faces_forest':True,'changed_action_routing':{w:g['routed'] for w,g in geometry.items()},'independent_integer_2x2_matrix_orientation_checks':checks,'all105_component_polynomial_coefficients_match_canonical':True,'own_face_totals':totals,'direct_gamma_square_equals_grouped_channels':True,'extra_offdiagonal_factor2_refuted':True,'scalar_factorial_accounting':{'action192_exponent':40,'source192_exponent':2,'coframes':64,'peeled48_exponent':6,'new_moment48_exponent':4,'new_moment192_exponent':1,'action_pair_factorial2_exponent':15},'seconds':time.perf_counter()-start},sort_keys=True))
