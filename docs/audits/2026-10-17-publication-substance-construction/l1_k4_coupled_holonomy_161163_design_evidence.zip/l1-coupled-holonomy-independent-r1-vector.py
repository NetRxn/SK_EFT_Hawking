from pathlib import Path
import ast,itertools,signal,json,time
signal.alarm(30);start=time.perf_counter();P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
ns={}
for path,names in [(A/'l1_direct_a_haar.py',{'mul','adj'}),(A/'l1_extended_mixed_curvature_core.py',{'face_vector'})]:
 functions=[n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names];exec(compile(ast.Module(body=functions,type_ignores=[]),str(path),'exec'),ns)
own={};exec(compile((P/'l1-coupled-holonomy-independent-r1-math.py').read_text().split('mode=sys.argv[1]')[0],'independentdefinitions','exec'),own)
names={'H':(5,2),'K':(7,1),'J':(9,2),'L':(13,2),'M':(9,3),'N':(13,3)};fixed=[(1,2),(1,3),(5,3),(3,1),(7,2)];faces=[(7,1,2),(1,2,3),(5,2,3),(9,2,3),(13,2,3)];checks=0
for f,(face,variables) in enumerate(zip(faces,own['FACES'])):
 for indices in itertools.product(range(4),repeat=len(variables)):
  cs={e:((1,0,0,0),)*2 for e in fixed}
  for n,i in zip(variables,indices):cs[names[n]]=(tuple(int(j==i) for j in range(4)),)*2
  for chir in (0,1):
   for a in range(3):
    actual=ns['face_vector'](face,cs,chir,a);expected=own['vectors'](f)[3*chir+a].get(tuple(i+4*chir for i in indices),0);assert actual==expected;checks+=1
assert checks==2136
print(json.dumps({'all_independent_holonomy_vector_coefficients_match_canonical':True,'exhaustive_linear_basis_checks':checks,'seconds':time.perf_counter()-start}))
