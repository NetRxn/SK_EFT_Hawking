from pathlib import Path
from functools import cache
from collections import Counter
from fractions import Fraction
from math import prod
from itertools import product
import ast,signal,time,json
signal.alarm(30);start=time.perf_counter();P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
ns={'cache':cache,'Counter':Counter,'Fraction':Fraction,'prod':prod,'SCALE':192}
for f,name in [('l1_direct_a_haar.py','haar_moment'),('l1_extended_mixed_frame_moment.py','moment')]:
 n=next(n for n in ast.parse((A/f).read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name);exec(compile(ast.Module(body=[n],type_ignores=[]),str(A/f),'exec'),ns)
own={};exec(compile((P/'l1-coupled-holonomy-independent-r1-math.py').read_text().split('mode=sys.argv[1]')[0],'independentdefinitions','exec'),own)
for a,b in product(range(36),repeat=2):assert 4*own['four'](a,b)==ns['moment'](tuple(sorted(own['PAIRS'][a]+own['PAIRS'][b])))
for a,b,c in product(range(36),repeat=3):assert own['six'](a,b,c)==ns['moment'](tuple(sorted(own['PAIRS'][a]+own['PAIRS'][b]+own['PAIRS'][c])))
print(json.dumps({'canonical_actual_AST_equal_to_independent_factorial_Dirichlet':True,'fourth_entries_including_zeros':1296,'sixth_entries_including_zeros':46656,'seconds':time.perf_counter()-start}))
