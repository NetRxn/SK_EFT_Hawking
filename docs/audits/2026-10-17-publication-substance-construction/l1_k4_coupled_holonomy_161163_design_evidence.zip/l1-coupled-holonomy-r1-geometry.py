import sys,signal,json,hashlib
from pathlib import Path
from collections import Counter
signal.alarm(30)
p=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
sys.path.insert(0,str(p))
import l1_extended_offset_witness_k4 as k4
import l1_extended_offset_witness_k4_two_square as two
manifest,_=k4.data()
result=[]
for i in (161,163):
 row=manifest['rows'][i];frame,sources,edges,faces,protected,removed=two.base(row)
 result.append(dict(row=row,frame=sorted(frame.items()),sources=sources,edges=sorted(edges.items()),faces=[(f,sorted(e)) for f,e in sorted(faces.items())],protected=sorted(protected),removed=removed,incidence=sorted(Counter(e for b in faces.values() for e in b).items())))
print(json.dumps(result,indent=2))
