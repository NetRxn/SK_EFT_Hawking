exec(open('/tmp/l1-coupled-holonomy-r1-controls.py').read().split("if __name__")[0])
from itertools import product
four=[(i,j,w) for i,p in enumerate(PAIRS) for j,w in HAAR[p]]
six=[(a,b,c,w) for a,b,c in product(range(36),repeat=3) if (w:=moment(tuple(sorted(PAIRS[a]+PAIRS[b]+PAIRS[c]))))]
assert F(moment((0,)*6),192)==F(5,64)
assert F(moment((0,0,1,1,2,2)),192)==F(1,192)
assert F(moment((0,0,0,0,4,4)),192)==F(1,32)
assert moment((0,0,0,4,4,4))==0
paths=['l1_direct_b_haar','l1_extended_four_face_gauge_join','l1_extended_mixed_center_gamma','l1_extended_mixed_curvature_core','l1_extended_mixed_frame_moment','l1_extended_offset_square','l1_extended_offset_witness','l1_extended_offset_witness_k2','l1_extended_offset_witness_k3','l1_extended_offset_witness_k4','l1_extended_offset_witness_k4_two_square','l1_extended_overlap_strip','l1_normalization_uniform_mixed_edge','l1_extended_two_mixed_centers','l1_extended_opposed_source']
print(json.dumps(dict(fourth_integer_denominator=48,fourth_rows=len(four),sixth_integer_denominator=192,sixth_rows=len(six),sixth_weight_histogram=dict(Counter(r[-1] for r in six)),source_hashes={name+'.py':hashlib.sha256((p/(name+'.py')).read_bytes()).hexdigest() for name in paths}),sort_keys=True,indent=2))
