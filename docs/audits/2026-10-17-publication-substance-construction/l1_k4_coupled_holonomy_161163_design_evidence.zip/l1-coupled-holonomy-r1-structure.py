exec(open('/tmp/l1-coupled-holonomy-r1-controls.py').read().split("if __name__")[0])
from l1_extended_mixed_center_gamma import COMPONENTS
from l1_direct_a_haar import adj,mul
# Exact quaternion formulas, including conjugation, on both sectors of 256 deterministic assignments.
for t in range(256):
 coords=dict(fixed)
 for k,e in enumerate((H,K,J,L,M,N)):
  coords[e]=(unit((t//4**(k%4))%4),unit(((t//4**(k%4))%4+k+1)%4))
 for c in range(2):
  h,k,j,l,m,n=(coords[e][c] for e in (H,K,J,L,M,N))
  expected=(mul(h,k),adj(j),mul(adj(l),h),mul(mul(adj(m),n),j),mul(mul(mul(adj(n),adj(h)),m),l))
  for face,q in zip(((7,1,2),(1,2,3),(5,2,3),(9,2,3),(13,2,3)),expected):
   for a in range(3):assert face_vector(face,coords,c,a)==q[a+1]
# Enumerated sparse face sizes for the exact all-label generator, not a full joint tensor.
counts={}
for face,variables in [((7,1,2),(H,K)),((1,2,3),(J,)),((5,2,3),(L,H)),((9,2,3),(M,N,J)),((13,2,3),(N,H,M,L))]:
 sizes=[len(face_tensor(face,variables,fixed,c)) for c in COMPONENTS]
 counts[str(face)]={'total_rows':sum(sizes),'maximum_rows_per_component':max(sizes)}
print(json.dumps({'quaternion_vector_checks':256*2*5*3,'all_component_face_counts':counts,'normalized_tensor_denominator':48**4*192},sort_keys=True))
