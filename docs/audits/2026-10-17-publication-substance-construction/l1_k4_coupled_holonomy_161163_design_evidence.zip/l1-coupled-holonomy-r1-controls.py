import sys,signal,json,hashlib
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction as F
from itertools import product
signal.alarm(30)
p=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');sys.path.insert(0,str(p))
from l1_extended_mixed_curvature_core import face_tensor,PAIRS,face_vector
from l1_extended_four_face_gauge_join import IDENTITY
from l1_extended_overlap_strip import HAAR
from l1_extended_mixed_frame_moment import moment
from l1_direct_b_haar import haar_moment
from l1_normalization_uniform_mixed_edge import unit
J=(9,2);L=(13,2);M=(9,3);N=(13,3);H=(5,2);K=(7,1)
fixed={(1,2):IDENTITY,(1,3):IDENTITY,(5,3):IDENTITY,(3,1):IDENTITY,(7,2):IDENTITY}
# Tensor order is square7, torus1,5,9,13. All moments below raw at48 or192.
def tensor(labels):
 s,a,b,c,d=labels
 A=face_tensor((1,2,3),(J,),fixed,a)
 C=face_tensor((9,2,3),(M,N,J),fixed,c)
 jproject=Counter()
 for (m,n,j),v in C.items():
  jproject[m,n]+=v*sum(w*A.get((i,),0) for i,w in HAAR[PAIRS[j]])
 # Integrate M,N using the preprojected small two-edge table.
 mnproject=Counter()
 for (m,n),v in jproject.items():
  if v:
   for i,u in HAAR[PAIRS[m]]:
    for j,w in HAAR[PAIRS[n]]:mnproject[i,j]+=v*u*w
 D=face_tensor((13,2,3),(N,H,M,L),fixed,d)
 by_hl=Counter()
 for (n,h,m,l),v in D.items():by_hl[h,l]+=v*mnproject[m,n]
 B=face_tensor((5,2,3),(L,H),fixed,b)
 lproject=Counter()
 for (l,h),v in B.items():
  for i,w in HAAR[PAIRS[l]]:lproject[i,h]+=v*w
 hh=Counter()
 for (h,l),v in by_hl.items():
  if v:
   for h2 in range(len(PAIRS)):
    if (w:=lproject[l,h2]):hh[h,h2]+=v*w
 S=face_tensor((7,1,2),(H,K),fixed,s)
 actual=Counter();wrong=Counter()
 for (h,k),v in S.items():
  for (h1,h2),w in hh.items():
   actual[k]+=v*w*moment(tuple(sorted(PAIRS[h]+PAIRS[h1]+PAIRS[h2])))
   # Deliberately invalid independent averages of H's three occurrences.
   wrong[k]+=v*w*moment(PAIRS[h])*moment(PAIRS[h1])*moment(PAIRS[h2])
 actual={str(PAIRS[k]):str(F(v,48**4*192)) for k,v in actual.items() if v}
 wrong={str(PAIRS[k]):str(F(v,48**4*192**3)) for k,v in wrong.items() if v}
 return actual,wrong
if __name__=='__main__':
 index=int(sys.argv[1])
 patterns=[((0,0),)*5,((0,1),(0,0),(0,1),(0,0),(0,0)),((0,3),)*5,((0,0),(0,0),(0,0),(3,3),(3,3)),((0,1),)*5,((0,3),(0,3),(0,3),(1,4),(1,4))]
 label=patterns[index];actual,wrong=tensor(label)
 print(json.dumps(dict(pattern=label,actual=actual,incorrect_independent_H=wrong,different=actual!=wrong),sort_keys=True))
