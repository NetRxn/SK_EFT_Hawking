from pathlib import Path
from fractions import Fraction
from itertools import product
from collections import Counter
import hashlib,json,sys,signal
signal.alarm(30)
a=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction')
sys.path.insert(0,str(a))
from l1_direct_a_haar import haar_moment

def pairings(xs):
 if not xs:
  yield ();return
 first=xs[0]
 for i in range(1,len(xs)):
  for rest in pairings(xs[1:i]+xs[i+1:]):yield ((first,xs[i]),)+rest
ps=tuple(pairings(tuple(range(6))));assert len(ps)==15
for labels in product(range(4),repeat=6):
 c=Counter(labels)
 independent=Fraction(sum(all(labels[x]==labels[y] for x,y in pairs) for pairs in ps),192)
 actual=haar_moment(tuple(c[i] for i in range(4)))
 assert independent==actual,(labels,independent,actual)
assert haar_moment((6,0,0,0))==Fraction(5,64)
wrong=haar_moment((2,0,0,0))*haar_moment((4,0,0,0))
assert wrong==Fraction(1,32)!=Fraction(5,64)
assert haar_moment((2,2,2,0))==Fraction(1,192)
print(json.dumps({'scope':'Existing single-sector Haar helper degree-six check only; no coupled tensor/source/action/physical acceptance','ordered_index_cases':4**6,'pairings':15,'sixth_diagonal':'5/64','incorrect_independent_second_fourth':'1/32','three_component_mixed':'1/192','helper_sha256':hashlib.sha256((a/'l1_direct_a_haar.py').read_bytes()).hexdigest()},sort_keys=True))
