from pathlib import Path
from hashlib import sha256
import json,subprocess,time,signal
signal.alarm(60)
p=Path('/tmp');py='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python'
commands=[('geometry',[py,'-B','/tmp/l1-coupled-holonomy-r1-geometry.py']),('structure',[py,'-B','/tmp/l1-coupled-holonomy-r1-structure.py']),('moments',[py,'-B','/tmp/l1-coupled-holonomy-r1-moments.py'])]
commands += [('control'+str(i),[py,'-B','/tmp/l1-coupled-holonomy-r1-controls.py',str(i)]) for i in range(6)]
commands += [('root-sixth',[py,'-B','/tmp/l1-coupled-holonomy-root-sixth-check.py'])]
receipts=[]
originals={f.name:sha256(f.read_bytes()).hexdigest() for f in p.glob('l1-coupled-holonomy-r1-*') if f.is_file()}
for name,cmd in commands:
 start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=30);elapsed=time.perf_counter()-start
 stem=p/('l1-coupled-design-root-intake-r1-'+name)
 for ext,value in [('stdout',r.stdout),('stderr',r.stderr)]:
  out=Path(str(stem)+'.'+ext);assert not out.exists();out.write_bytes(value)
 receipt={'name':name,'command':cmd,'exit':r.returncode,'seconds':elapsed,'stdout_sha256':sha256(r.stdout).hexdigest(),'stderr_sha256':sha256(r.stderr).hexdigest()};receipts.append(receipt)
 assert r.returncode==0 and not r.stderr,receipt
 actual=json.loads(r.stdout)
 if name in ('geometry','structure','moments'):
  assert actual==json.loads((p/('l1-coupled-holonomy-r1-'+name+'.json')).read_text()),name
 elif name.startswith('control'):
  i=int(name[7:]);prior=json.loads((p/'l1-coupled-holonomy-r1-controls.json').read_text())[i]
  assert actual==json.loads(prior['stdout']),name
assert originals=={f.name:sha256(f.read_bytes()).hexdigest() for f in p.glob('l1-coupled-holonomy-r1-*') if f.is_file()}
output={'scope':'ROOT fresh bounded scientific design/control intake; no fullaction contraction/coefficient or physical acceptance','commands':receipts,'unchanged_author_files':originals}
out=p/'l1-coupled-design-root-intake-r1.json';assert not out.exists();out.write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({'terminal_commands':len(receipts),'all_exit_zero':True,'all_original_semantics_match':True,'max_seconds':max(q['seconds'] for q in receipts),'receipt':str(out)}))
