# Independent acceptance of the 112- and 152-assignment profiles

Verify manifest.sha256, then run
`python3 check-residual.py independent/reviewed-exact.tsv`.
The two exact weight-96 subtractions reproduce the independently reported
residual. The review records full local-factor and signed contraction
coverage, the incompatible-basis control, and the scan-cap recoveries.
Full c0 and physical B3 remain open.
