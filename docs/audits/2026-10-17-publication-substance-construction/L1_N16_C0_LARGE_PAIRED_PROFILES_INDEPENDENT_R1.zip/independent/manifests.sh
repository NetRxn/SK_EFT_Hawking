set -eu
for p in 140684411270-580896423965 155950118473-580896423965; do
    here=$PWD
    (cd "AUTHOR/$p" && shasum -a 256 -c manifest.sha256) > "author-manifest-$p.out"
    (cd "RAW/$p-tiled" && shasum -a 256 -c "$here/AUTHOR/$p/frozen-factors.sha256") > "factors-$p.out"
done
(cd RESIDUAL && shasum -a 256 -c manifest.sha256) > residual-manifest.out
