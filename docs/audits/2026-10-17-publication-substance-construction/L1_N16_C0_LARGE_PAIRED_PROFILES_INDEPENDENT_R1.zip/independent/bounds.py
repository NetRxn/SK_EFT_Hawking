from collections import defaultdict
from pathlib import Path
ranges=('replay-*.out','memo-*.out','repair-*.out')
caps=(0,0,0,0,0,0,0)
entries=defaultdict(set)
refusals=[]
for pattern in ranges:
    for path in sorted(Path('.').glob(pattern)):
        _,a,b,shard=path.stem.split('-')
        for line in path.open():
            where=line.split()
            if not where:
                continue
            if where[0]=='case':
                c=int(where[1])
                high=[int(where[5]),int(where[-1]),0,0,0,0,0]
            if where[0]=='join':
                for j,i in ((3,2),(4,3),(5,5)):
                    high[j]=max(high[j],int(where[i]))
            if where[0]=='sweep':
                high[6]=max(high[6],int(where[-1]))
            if where[0]=='ZERO':
                for i,q in zip((2,3,5,6),where[3:]):
                    high[i]=max(high[i],int(q))
            if where[0]=='stats':
                for i,q in zip((2,3,5,6),(where[i] for i in (4,7,9,11))):
                    high[i]=max(high[i],int(q))
            if where[0]=='EXACT':
                assert int(where[1])==c
                entries[a,b].add(c)
                caps=tuple(map(max,zip(caps,high)))
            if line.startswith("AssertionError: ('quotient scans'"):
                refusals.append((a,b,c,line.strip()))
for (a,b),ct in sorted(entries.items()):
    print(a,b,len(ct))
print('successful maxima wires, initial rows, tracked peak rows, single join, join output, cumulative products, total scans',*caps)
for row in refusals:print('retained refusal',*row)
