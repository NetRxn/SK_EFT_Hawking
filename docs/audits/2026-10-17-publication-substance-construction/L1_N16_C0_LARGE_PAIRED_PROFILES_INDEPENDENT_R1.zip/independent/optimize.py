from pathlib import Path
p=Path('replay.py')
s=p.read_text().replace('from dataclasses import dataclass','from dataclasses import dataclass, field').replace('from itertools import combinations','from itertools import combinations, count').replace('@dataclass\nclass Table:', 'serials=count()\n\n@dataclass\nclass Table:').replace('    scale:int\ndef make', '    scale:int\n    serial:int=field(default_factory=lambda:next(serials))\ndef make')
s=s.replace('def sweeps(fs,budget,record):','def sweeps(fs,budget,record,unchanged):').replace('                step=reduce(A,B,L,R,budget)\n                if step is None:continue','                key=(A.serial,B.serial)\n                if key in unchanged:continue\n                step=reduce(A,B,L,R,budget)\n                if step is None:\n                    assert len(unchanged)<50_000\n                    unchanged.add(key)\n                    continue')
s=s.replace('    record=[0,0]','    record=[0,0]\n    unchanged=set()').replace('sweeps(fs,budget,record)','sweeps(fs,budget,record,unchanged)')
s=s.replace('            if not sweeps(fs,budget,record,unchanged):\n                print','            if not sweeps(fs,budget,record,unchanged):\n                print("ZERO COUNTERS",case,peak,used,total,budget.used,flush=True)\n                print')
p.write_text(s)
