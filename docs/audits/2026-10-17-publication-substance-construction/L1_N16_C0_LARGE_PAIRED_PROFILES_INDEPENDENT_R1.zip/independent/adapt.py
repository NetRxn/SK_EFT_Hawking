from pathlib import Path
p=Path('replay.py')
s=p.read_text().replace('and raw\n','\n').replace('300_000','500_000').replace('<=800_000','<=1_300_000').replace('    used=total=0','    if any(not f.rows for f in initial):\n        print("EMPTY",case,tuple(f.names for f in initial if not f.rows),flush=True)\n        print("EXACT",case,0,flush=True)\n        return\n    used=total=0').replace('    for p in sorted(plans):pilot(p)','    low,high=map(int,sys.argv[2:4])\n    for p in sorted(plans):\n        if low<=p<high:pilot(p)').replace("print('EXACT',case,0,flush=True)","print('ZERO COUNTERS',case,peak,used,total,budget.used,flush=True)\n        print('EXACT',case,0,flush=True)",1)
p.write_text(s)
