set -eu
export PYTHONDONTWRITEBYTECODE=1
repo=/Users/johnroehm/.codex/worktrees/l1-original-n16-python/SK_EFT_Hawking
python=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python
bash manifests.sh
python3 support.py > support.out
PYTHONPATH="$repo" "$python" normalization.py > normalization-replay.out
PYTHONPATH="$repo" "$python" root-rebuild.py > root-replay.out
while read -r a b w; do
    p="$a-$b"
    python3 edge-reconstruct.py "$p" > "edges-$p.out"
    PYTHONPATH="$repo" "$python" edge-control.py "$p" > "literal-$p.out"
    python3 site-reconstruct.py "$p" > "sites-$p.out"
    n=56
    if [ "$a" = 155950118473 ]; then n=76; fi
    python3 replay.py "$p" 0 "$n" > "repair-$p-0.out"
done < profiles.tsv
python3 verify-pairs.py --final
