from pathlib import Path
p=Path('support.py')
s=p.read_text()
a=s.index('    assert scans<=')
b=s.index('    def plans(data):',a)
s=s[:a]+'''    constraints=[]
    for indices in times:
        constraints.append((indices,lambda ss:all(coupling(tuple(sorted(x))) for x in zip(*ss))))
    for indices,n in space:
        constraints.append((indices,lambda ss,n=n:spatial(tuple(ss),n)))
    tables=[]
    for ix,test in constraints:
        assert prod(len(dimensions[j]) for j in ix)<=1_000_000
        tables.append((ix,tuple(s for s in product(*(dimensions[j] for j in ix)) if test(s))))
    allowed=set()
    nodes=0
    def walk(dom):
        nonlocal nodes
        nodes+=1
        assert nodes<=1_000_000
        changed=True
        while changed:
            changed=False
            for ix,table in tables:
                rows=[r for r in table if all(v in dom[j] for j,v in zip(ix,r))]
                if not rows:return
                for j,vals in zip(ix,zip(*rows)):
                    subset=dom[j].intersection(vals)
                    if subset!=dom[j]:
                        changed=True
                        dom[j]=subset
        j=min((j for j in range(len(dom)) if len(dom[j])>1),key=lambda j:len(dom[j]),default=None)
        if j is None:
            allowed.add(tuple((*k,*q) for k,r in zip(labels,dom) for q in r if any(q)))
            return
        for q in sorted(dom[j]):
            child=dom.copy()
            child[j]={q}
            walk(child)
    walk([set(d) for d in dimensions])
    path=Path('AUTHOR')/f'{a}-{b}'
    raw=Path('RAW/candidate-support')/f'{a}-{b}'
    orig_plan=anchors(raw/'anchor-plan.tsv')
    part_plan=anchors(path/'anchor-plan.tsv')
    assert (raw/'states.tsv').read_bytes()==(path/'all-states.tsv').read_bytes()
    orig=state_rows(path/'all-states.tsv',orig_plan)
    part=state_rows(path/'states.tsv',part_plan)
    assert set(orig.values())==allowed and len(orig)==len(allowed)==({140684411270:112,155950118473:152}[a])
    lookup={j:k for k,j in orig.items()}
    exchange={k:lookup[tuple((t,y,c,q,p) for t,y,c,p,q in st)] for k,st in orig.items()}
    assert all(exchange[exchange[x]]==x and exchange[x]!=x for x in orig)
    taken={lookup[v] for v in part.values()}
    assert len(taken)==len(part) and all((x in taken)!=(exchange[x] in taken) for x in orig)
''' + s[b:]
a=s.index('    for i,st in sorted(part.items()):')
s=s[:a]+'''    for i,st in sorted(part.items()):
        j=lookup[st]
        print(a,b,w,i,j,exchange[j],2,sep='\\t',file=out)
    print(a,b,'full product',scans,'search nodes',nodes,'full states',len(orig),
          'representatives',len(part),'anchor rows full/selected',len(orig_plan),len(part_plan))
with Path('reviewed-pairs.tsv').open('w') as out:
    for l in Path('profiles.tsv').open():
        verify(*map(int,l.split()),out)
'''
p.write_text(s)
