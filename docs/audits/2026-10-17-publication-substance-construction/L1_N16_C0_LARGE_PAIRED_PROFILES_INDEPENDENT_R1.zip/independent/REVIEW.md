# Independent review of the original 112- and 152-assignment N16 c0 profiles

The review operated on canonical original source at `51e7c745eccad5e99676cdc8e4b523ad73e617b1`, checkpoint HEAD and upstream `259206170098ed9b44fd3211fca956724515d6fb`, and the predecessor accepted at `b07d1ad43`. Both frozen author intake manifests match the published archives byte for byte. Every asserted author intake and frozen factor hash verifies. The predecessor residual is byte-identical to `block-remaining.tsv` in the published eight-profile acceptance archive.

## Original support and normalization

I independently regenerated the projected root degree domains and imposed the two temporal SU(2) coupling conditions, the combined spatial center parity, and the spatial minimum-load and zero-load equalities. A finite verified constraint search covered each underlying 16,777,216-tuple product in 391 and 303 branch nodes, respectively. Every original necessary-support assignment and all 5,376 and 7,296 original anchor rows agree. All 2,688 and 3,648 selected anchor rows agree, and original IDs and selected IDs were joined using the full tuples. The independently determined chirality exchange has 56 and 76 two-member orbits and no fixed assignments. The frozen representative roster contains exactly one member from every orbit.

For the source gamma3 exchange, conjugate both Spin(4) blocks by the chirality-swapping gamma matrix and apply its induced transformation to the two site spinors. This permutes the two normalized Haar factors and leaves each completely filled local exterior measure invariant. Each EHC factor reverses sign under the exchange and the total original insertion degree is 32, so every exchanged pair contributes twice its signed representative value. This uses the already accepted source involution and independently checks its exact finite pairing in these two profiles.

I reconstructed all 512 literal stripped coframes and 768 original four-order EHC folding controls. The 32 EHC factors give 64 stripped coframe quarters, so the sewn integer/rational result is divided by `4^64`. Multiplicity factorials are 6,912 and 27,648, respectively. The world-epsilon and cross-site wedge parities are both even on every root of each profile. I tested 64 literal layouts per root as a check on the recovered site wedge ordering.

## Factor and wire coverage

Every representative uses its original 88-factor network. Temporal owner and direction labels follow the explicit half-edge orientation, site top factors use local canonical mask signs, and the split site halves share the three original raw words. Every transmitted nontrivial wire label occurs in two factors. The two endpoint alias maps keep both unsqueezed edge matrix-index blocks in place and map each native endpoint label to its projected site label with its signed Gaussian gain. The inverse reconstruction recovers every original key and coefficient exactly once across 54/379,560 and 67/295,444 tables/rows, respectively.

Canonical source independently reconstructs the common root table, covering all 4,920 literal projections and 1,718 nonzeros. Whole normalized temporal moments cover 1,185 and 1,820 entries with 149 and 167 nonzeros. Whole spatial anchor moments cover 32,634 and 118,926 entries with 1,908 and 6,176 nonzeros. Direct literal source controls verify 73 and 92 exact raw edge rows over all edge patterns, including nonreal targets, with a largest prospective direct product count of 1,048,576. The original production raw-edge tables are independently reconstructed from the frozen quotient and alias tables. Direct re-integration from canonical source has the stated target-row scope.

I independently rebuilt the mask and root halves from original root words and matrices, exact wedge order and endpoint gains. The tables agree entry for entry before network joining. All 4,224 split factors agree, including 12,324,888 mask and 4,456,024 root rows for 112, and 17,398,204 mask and 4,333,800 root rows for 152. The largest site trial and root-product counts were 669,824 and 207,360. See `site-coverage.out` for the per-profile counts. A site with an empty factor remains part of the original support census and is a structural zero on contraction.

The initial 112-assignment driver attached raw edge labels to the already projected site factors. I independently reproduced that mismatch by replacing only `rays` with `raw-edges` on the frozen corrected network of case 007. The invalid value is exactly
`-24757516332897079906581117046875/604462909807314587353088 + i*5667428478562382044968222796875/302231454903657293676544`,
which agrees with the frozen invalid author log and fails the real-coefficient guard. Both the pre-optimization and optimized independent replays of the corrected projected wiring yield the same value `-12160452524899562296875/316912650057057350374175801344` and zero imaginary part. Only the correctly matched projected labels enter the accepted calculation.

## Exact contraction and resource boundaries

I constructed each independent network with tuple keys and integral Gaussian numerators over separate exact denominators. For every complete shared-wire tuple, I normalized the source slice by the integer gcd and a unique Gaussian unit, and checked that rescaling recovered the input. If two slices agree in their normalized entries, only the representative primitive slice is retained and every preimage multiplier is summed on the neighbor. An empty required table or vanishing full bond contraction certifies zero. Remaining joins use exact equality of the full common wire tuple. The replay tests the twofold wire incidence and the exact imaginary-zero result.

Each case has prospective ceilings of 500,000 rows per factor, 1,300,000 initial rows, 2,000,000 matched products per join, 30,000,000 cumulative matched products, 100,000,000 charged scan visits and a 256-bit bound for Gaussian numerator accumulation. Root and mask site assembly each admit at most 2,000,000 prospective trials, with a 300,000-row structural limit per site output. The original independent wide sweeps reached the scan guard on 112 cases 012 and 032 and 152 case 056. Those refusal logs are retained. The exact retry memoizes only a no-change outcome for the same pair of immutable factor versions. The later verification variant additionally memoizes exact pair forecast counts by immutable versions and checks the same-input signed case 007. None alters the Gaussian quotient identity or case input. See `bounds.out` for observed visit/product bounds and the original refusal records.

## Outcome

**ACCEPT** both original pure-EHC N16 c0 coefficients.

| Profile | Positive / negative / zero representatives | Exact coefficient |
|---|---:|---|
| (140684411270, 580896423965) | 26 / 16 / 14 | 2954539359174694647877171875/5070602400912917605986812821504 |
| (155950118473, 580896423965) | 11 / 7 / 58 | 25972163108707061896125328125/324518553658426726783156020576256 |

The combined weight-96 contribution is `645188046287662558080792984375/10141204801825835211973625643008`. The two coefficients are recorded in `reviewed-exact.tsv`. `signed-pairs.tsv` gives every selected ID, both original support IDs, multiplicity and independently replayed signed value. The predecessor contains both profiles at weight 96. `block-remaining.tsv` removes exactly those two orbits and 192 labels, leaving 9,629 orbits and 829,479 labels. The scope is these two coefficients using the verified factor coverage above.

Run `bash reproduce.sh` from this directory with the input symlinks in place. `replay-*.out` retain the initial exact replays and refusals. `memo-*.out` retain the successful immutable-version retry shards, and `repair-*-7.out` retains the unchanged-input parity control. `raw-wiring-mutant.out` records the expected reality-guard failure. The verifier reads the independent exact logs and compares every result with its source-member author log. No repository, manuscript, notebook, or Lean slot was changed.
