from collections import defaultdict
from pathlib import Path

sets=defaultdict(dict)
paths=(Path('sites-140684411270-580896423965.out'),Path('sites-152-lower.out'),Path('sites-152-upper.out'))
for p in paths:
    n='112' if '140684411270' in p.name else '152'
    for l in p.open():
        if l.startswith('Traceback'):
            raise ValueError(p)
        sp=l.split()
        if not sp or not sp[0].isdecimal():
            continue
        c,t,x,nr,mask,mc,rc=map(int,(sp[i] for i in (0,1,2,5,8,11,14)))
        v=nr,mask,mc,rc
        assert sets[n].setdefault((c,t,x),v)==v
for k,v in sorted(sets.items()):
    want=56 if k=='112' else 76
    if len(v)<want*16:
        print(k,'pending sites',want*16-len(v))
        continue
    assert set(v)=={(c,t,x) for c in range(want) for t in range(2) for x in range(8)}
    columns=list(zip(*v.values()))
    print(k,'sites',len(v),'factors',2*len(v),'mask and root rows',sum(columns[2]),sum(columns[3]),
          'max root products, mask trials, mask rows and root rows',*(max(col) for col in columns))
