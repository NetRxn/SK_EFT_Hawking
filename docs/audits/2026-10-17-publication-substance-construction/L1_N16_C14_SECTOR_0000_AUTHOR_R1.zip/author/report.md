# Exact LLLL sector of the original N16 c14 representative

The pinned source is original periodic closed source_C at clean primary
27012c18fa374e8341e124b510abbedeedb18d29. This is the zero-centered
(01,01,23,23) representative. The accepted signed quotient environment
is used without altering the original external divisor or source
coupling conventions.

All four coordinate slots of an original S2 trace lie in the same
chirality. The exact whole representative splits into sixteen
ordered chirality assignments across original trace occurrences
0, 1, 2 and 3. This run evaluates only LLLL. Its exact value including
the whole-row divisor 512 and separate pure-S4 scalar 24^5 is
49946065209/2251799813685248, with imaginary part zero.
It is a sector contribution to one representative.

## Exact interior and exterior separation

The original Boolean tile and mask bridge are implied by the
coefficient factors. The check reconstructs their full 36,608
and 100 row supports from the original rank-8 site masks, signed
edge row domains, original trace bins and shared masks. Removing
those unit predicates preserves each exact surviving term.

Eleven bounded signed binary joins produce six factors whose
indices split into exterior mask/ray labels and four interior
q/component labels. Each factor has exactly eleven primitive
signed interior rays. Exact scalar weights reproduce every
original exterior slice. The factorized frontier and signed
ray maps are frozen. A generic whole-sector greedy order
completed fourteen joins, then refused prospectively at
4,102,097 visits. Conditioning one shared rank-zero mask
also reached the 200,001 row guard on that alternative route.
Neither refused route entered the final computation.

The mask side divides into two local halves at rank zero.
Each half projects two disjoint masks to a signed four-bit
union. Only complementary unions can saturate rank zero.
The two half signs and their crossing sign recover its
original full eight-generator order. The mask network
joined all 178,150 exact accepted environment rows, with
122,777 complementary half products and 36,288 environment
rows contributing matching pairs. Coalescence leaves 401
nonzero signed weights on six interior rays. Four fixed
boundary controls agree with literal full-rank-zero wedge
enumeration. The weighted mask run charged 1,576,066 visits,
6,908 tracked rows and 207,867 serialized bytes. Its sampled
peak process RSS was 63,635,456 bytes.

## Bounded exact interior transform

Naively multiplying the four normalized spoke rays would visit
507,576,320 terms over the 401 retained keys. Each spoke's
eleven Gaussian matrices instead share exact rank-ten column
and row bases. All 44 matrices reconstruct exactly using
rational Gaussian entries. The middle matrices have just one
to six nonzero entries each. The retained 401 combinations
therefore require 9,557 middle-matrix products and 339 left
and 330 right transformed trace entries.

The uncached trace evaluation had a prospective worst-case
count of 6,051,828 and was refused before numerical execution.
The admitted schedule reuses each exact transformed pair of
source traces across the selected E/F ray IDs. This gives
291,072 candidate products on each side and a prospective
worst-case count of 3,507,156 against 4,000,000. A first
combination attempt also exposed a 127-bit payload refusal.
Factoring the common exact mask numerator gcd
18,360,560,885,397,180,590,850,048 into the final scalar
restores bounded interior payload without altering any
coefficient. The normalized complex numerator is
190,681,525,899,145,248,768 + 0i.

The successful sector evaluation used 3,442,116 charged visits,
including two exact direct original-spoke controls with
65,536 products each. These agree with their respective basis
amplitudes. Reversing a single recorded original path changes
both controls. Separate serialized readback reconstructs all
44 matrices and independently sums the 401 mask/amplitude
products with the original exact denominator and divisor.
It reproduces the reported sector value. The sector run's
sampled peak process RSS was 23,003,136 bytes. The row and
work meters cover their stated expansions, not Python/SymPy
construction internals. Scalar payload is checked on normalized
Gaussian coefficients. Sampled RSS is a guard, not a hard OS
limit.

The fifteen other sectors must be evaluated or reduced by a
verified signed transport identity. The all-sector original
representative, the other two axis arrangements, c14, c0,
complete denominator and normalization remain open.
