"""Prospectively bounded exact chirality-conditioned core joins."""
from collections import Counter,defaultdict
from functools import cache
from itertools import combinations,product
from pathlib import Path
import json,resource,sys

D=Path(__file__).parent
CORE=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
TWO=Path('/tmp/publication-c14-rank-zero-r1.gte6BM')
SEW=Path('/tmp/publication-c14-shared-trace-r1.9tcmVn')
RES=Path('/tmp/publication-c14-residual-edge-r1.klcKMh')
R3=Path('/tmp/publication-c14-rank3-r1.q1WfND')
WORK_CAP=4_000_000
ROW_CAP=200_000
FILE_CAP=32*1024**2
RSS_CAP=384*1024**2
INT_CAP=(1<<127)-1
KEEP=('ray_rank4','ray_rank12','ray_rank3','ray_rank10','ray_rank9','remote1','remote2')
QGROUPS=(
 ('q02_0','q03_0','q12_0','q23_0'),
 ('q02_1','q03_1','q12_1','q23_1'),
 ('q00_2','q81_2','q01_2','q40_2'),
 ('q00_3','q81_3','q01_3','q40_3'),
)
QINDEX={k:i for i,vs in enumerate(QGROUPS) for k in vs}
WORK=Counter()
TOTAL=0
RSS=0
WRITTEN=0
MAXROWS=0

class Refusal(Exception):
    pass

def rss():
    global RSS
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    RSS=max(n,RSS)
    if n>RSS_CAP:
        raise Refusal(('sampled_RSS',n,RSS_CAP))

def charge(k,n=1):
    global TOTAL
    if TOTAL+n>WORK_CAP:
        raise Refusal(('prospective_work',k,TOTAL+n,WORK_CAP))
    TOTAL+=n
    WORK[k]+=n
    if TOTAL%2048==0:
        rss()

def pair(z):
    return tuple(z) if isinstance(z,list) else (z,0)

def times(z,w):
    a,b=z
    c,d=w
    m=max(abs(c),abs(d))
    if m and max(abs(a),abs(b))>INT_CAP//(2*m):
        raise Refusal(('prospective_scalar_product',INT_CAP))
    return a*c-b*d,a*d+b*c

def add(z,w):
    for a,b in zip(z,w):
        if (a>0 and b>0 and a>INT_CAP-b) or (a<0 and b<0 and a< -INT_CAP-b):
            raise Refusal(('prospective_scalar_sum',INT_CAP))
    return z[0]+w[0],z[1]+w[1]

def emit(f,value):
    global WRITTEN
    line=json.dumps(value,separators=(',',':')).encode('ascii')+b'\n'
    if WRITTEN+len(line)>FILE_CAP:
        raise Refusal(('prospective_output_bytes',WRITTEN+len(line),FILE_CAP))
    f.write(line)
    WRITTEN+=len(line)

def read(path):
    with path.open() as f:
        for line in f:
            charge('source_rows')
            yield json.loads(line)

class Factor:
    def __init__(self,name,keys,table):
        self.name=name
        self.keys=tuple(keys)
        self.table=table
        self.index={}
    def idx(self,shared):
        if shared not in self.index:
            ps=[self.keys.index(k) for k in shared]
            out=defaultdict(list)
            for k,z in self.table.items():
                charge('index_row')
                out[tuple(k[i] for i in ps)].append((k,z))
            self.index[shared]=out
        return self.index[shared]

def read_core(sector,restriction):
    g=json.loads((CORE/'graph.json').read_text())
    masks={
      'rank8_edge0':STAR/'edge-0.jsonl','rank8_edge1':STAR/'edge-1.jsonl',
      'rank0_edge1':TWO/'zero-edge-1.jsonl','rank0_edge2':TWO/'zero-edge-2.jsonl',
      'rank0_edge3':TWO/'zero-edge-3.jsonl','trace0':TWO/'plane-01-trace.jsonl',
      'trace1':TWO/'plane-01-trace.jsonl','trace2':SEW/'trace-slices.jsonl',
      'trace3':SEW/'trace-slices.jsonl','partition_rank8':STAR/'site-factors.jsonl',
      'partition_rank0':TWO/'zero-site-factors.jsonl','residual_edge':RES/'residual-edge.jsonl',
      'rank3_edge2':R3/'rank3-axis2.jsonl','rank3_edge3':R3/'rank3-axis3.jsonl',
      'rank3_projection':R3/'rank3-projection.jsonl',
      'merge_rank1':R3/'merge-rank1.jsonl','merge_rank2':R3/'merge-rank2.jsonl',
    }
    rays={
      'rank4_closure':'rank4','rank12_closure':'rank12','rank3_compact':'rank3',
      'rank8_edge2':'rank10','rank8_edge3':'rank9',
    }
    fs=[]
    for name,keys in g['factor_keys'].items():
        if name in ('coalesced_environment','conditional_tile','mask_bridge'):
            continue
        hand=[(i,QINDEX[k]) for i,k in enumerate(keys) if k in QINDEX]
        conditions=[(i,restriction[k]) for i,k in enumerate(keys) if k in restriction]
        retained=[i for i,k in enumerate(keys) if k not in restriction]
        table={}
        if name in rays:
            def get_items(tag):
                for j,v in read(CORE/f'quotient-{tag}-rays.jsonl'):
                    for k,z in v:
                        charge('source_ray_rows')
                        yield [*k,j],z
            items=get_items(rays[name])
        else:
            items=((line[0],line[1]) for line in read(masks[name]))
        for key,z in items:
            if any(key[i]//4 != sector[j] for i,j in hand):
                continue
            if any(key[i]!=v for i,v in conditions):
                continue
            assert len(key)==len(keys)
            k=tuple(key[i] for i in retained)
            assert k not in table
            table[k]=pair(z)
        fs.append(Factor(name,[keys[i] for i in retained],table))
    degree=Counter(k for f in fs for k in f.keys)
    assert all(v==(1 if k in KEEP else 2) for k,v in degree.items())
    return fs

def redundant_boolean():
    # Verify set equality for the bridge and tile from independently
    # frozen factor projections, rather than counting either twice.
    p8=set()
    p0=set()
    sitepairs=set()
    for k,s,_ in read(STAR/'site-factors.jsonl'):
        p8.add(k[0])
        sitepairs.add(tuple(k[:2]))
    for k,s in read(TWO/'zero-site-factors.jsonl'):
        p0.add(k[0])
    left=defaultdict(set)
    right=defaultdict(set)
    for (m,n,a,b,u,v),z in read(STAR/'edge-0.jsonl'):
        left[m].add((u,v))
    for (m,n,a,b,u,v),z in read(STAR/'edge-1.jsonl'):
        right[m].add((u,v))
    bridge={tuple(row[:2]) for row in read(TWO/'compatible-mask-bridge.jsonl')}
    actual={(m,n) for (m,n,a,b,u,v),z in read(STAR/'edge-0.jsonl') if m in p8 and n in p0}
    assert actual==bridge
    tracebins={tuple(k[:2]) for k,z in read(SEW/'trace-slices.jsonl')}
    tiles={tuple(line) for line in read(SEW/'conditional-tiles.jsonl')}
    refs=set()
    for m,n in sitepairs:
        for u,v in product(left[m],right[n]):
            charge('tile_implication')
            if (u[0],v[0]) in tracebins and (u[1],v[1]) in tracebins:
                refs.add((m,n,*u,*v))
    assert refs==tiles
    return dict(implied_tile_rows=len(refs),implied_mask_bridge_rows=len(bridge))

def measure(left,right,shared):
    a=left.idx(shared)
    b=right.idx(shared)
    n=0
    for k in a.keys()&b.keys():
        charge('join_index_projection')
        n+=len(a[k])*len(b[k])
    return n

def schedule(fs,history,stop=None):
    while len(fs)>1:
        candidates=[]
        for a,b in combinations(fs,2):
            shared=tuple(k for k in a.keys if k in b.keys)
            if not shared:
                continue
            n=measure(a,b,shared)
            width=len(a.keys)+len(b.keys)-2*len(shared)
            candidates.append((n,width,a.name,b.name,shared,a,b))
        if not candidates:
            # Fully fixed labels can disconnect legitimate scalar factors.
            a,b=fs[:2]
            candidates=[(len(a.table)*len(b.table),len(a.keys)+len(b.keys),a.name,b.name,(),a,b)]
        n,_,_,_,shared,a,b=min(candidates,key=lambda x:x[:4])
        if TOTAL+n>WORK_CAP:
            return history,fs,dict(kind='work',left=a.name,right=b.name,shared=shared,
                charged_before=TOTAL,join_visits=n,prospective=TOTAL+n,cap=WORK_CAP)
        l=a.idx(shared)
        r=b.idx(shared)
        li=[i for i,k in enumerate(a.keys) if k not in shared]
        ri=[i for i,k in enumerate(b.keys) if k not in shared]
        outer=[a.keys[i] for i in li]+[b.keys[i] for i in ri]
        out={}
        for group in sorted(l.keys()&r.keys()):
            for (x,z),(y,w) in product(l[group],r[group]):
                charge('exact_partial_join')
                k=tuple(x[i] for i in li)+tuple(y[i] for i in ri)
                if k not in out and len(out)==ROW_CAP:
                    return history,fs,dict(kind='rows',left=a.name,right=b.name,shared=shared,
                        join_visits=n,prospective=len(out)+1,cap=ROW_CAP)
                out[k]=add(out.get(k,(0,0)),times(z,w))
        nonzero={k:z for k,z in out.items() if z!=(0,0)}
        node=Factor('('+a.name+'+'+b.name+')',outer,nonzero)
        history.append(dict(left=a.name,right=b.name,eliminated=shared,visits=n,
            output_labels=outer,nonzero_rows=len(nonzero),cancelled_rows=len(out)-len(nonzero)))
        print('join',len(history),a.name,b.name,n,len(nonzero),flush=True)
        fs[:]=[f for f in fs if f is not a and f is not b]+[node]
        if stop is not None and len(history)==stop:
            return history,fs,dict(kind='deliberate_exact_checkpoint',joins=stop)
    return history,fs,None

def main(sector,restriction,stop=None):
    rss()
    implication=redundant_boolean()
    fs=read_core(sector,restriction)
    name="".join(map(str,sector))+"".join("-"+k+str(v) for k,v in restriction.items())
    if stop is not None:
        name+=f"-stop{stop}"
    input_sizes={f.name:len(f.table) for f in fs}
    print('sector',sector,'factor sizes',input_sizes,flush=True)
    history=[]
    try:
        history,frontier,ref=schedule(fs,history,stop)
    except Refusal as exc:
        # Preserve source/cap refusal exactly when it occurs during an
        # auxiliary projection rather than an admitted coefficient join.
        frontier=fs
        ref=dict(kind='projection_or_guard',details=exc.args)
    with (D/f'frontier-{name}.jsonl').open('wb') as f:
        for v in frontier:
            if len(v.table)<=ROW_CAP:
                emit(f,[v.name,v.keys,sorted(v.table.items())])
    rss()
    report=dict(sector=sector,restriction=restriction,input_sizes=input_sizes,redundant_boolean=implication,
        exact_completed_joins=history,frontier={v.name:dict(keys=v.keys,rows=len(v.table)) for v in frontier},
        refusal=ref,whole_core_complete=ref is None,environment_attached=False,
        work=dict(WORK),total_work=TOTAL,output_bytes=WRITTEN,sampled_rss=RSS,
        caps=dict(work=WORK_CAP,rows=ROW_CAP,serialized=FILE_CAP,sampled_rss=RSS_CAP,scalar=INT_CAP))
    (D/f'result-{name}.json').write_text(json.dumps(report,indent=2)+'\n')
    print('terminal',ref,flush=True)

if __name__=='__main__':
    a=tuple(map(int,sys.argv[1]))
    assert len(a)==4 and set(a)<={0,1}
    restrictions={k:int(v) for k,v in (x.split("=") for x in sys.argv[2:] if not x.startswith("stop="))}
    stop=next((int(x.split("=")[1]) for x in sys.argv[2:] if x.startswith("stop=")),None)
    main(a,restrictions,stop)
