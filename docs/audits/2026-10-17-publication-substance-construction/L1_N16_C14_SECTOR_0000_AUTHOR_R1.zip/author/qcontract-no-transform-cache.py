"""Exact selected Gaussian-basis LLLL interior transform and scalar control."""
from collections import Counter,defaultdict
from fractions import Fraction
from functools import cache
from itertools import product
from pathlib import Path
import json,resource

D=Path(__file__).parent
CORE=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
CAP=4_000_000
ROWS=200_000
RSS_CAP=384*1024**2
INT_CAP=(1<<127)-1
WORK=Counter()
TOTAL=0
PEAK=0
ZERO=(0,0)
SPK='ABCD'
SIDES=(
  (('a1_0','a0_0','q02_0','q03_0'),('a1_1','a0_1','q02_1','q03_1'),('q23_0','q12_0'),('q23_1','q12_1')),
  (('q01_2','q00_2','a2_2','a3_2'),('q01_3','q00_3','a2_3','a3_3'),('q40_2','q81_2'),('q40_3','q81_3'))
)

class Refused(Exception):
    pass

def rss():
    global PEAK
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    PEAK=max(PEAK,n)
    if n>RSS_CAP:
        raise Refused(('sampled_RSS',n,RSS_CAP))

def work(k,n=1):
    global TOTAL
    if TOTAL+n>CAP:
        raise Refused(('prospective_work',k,TOTAL+n,CAP))
    TOTAL+=n
    WORK[k]+=n
    if TOTAL%2048==0:
        rss()

def check(z):
    for x in z:
        if isinstance(x,Fraction):
            if abs(x.numerator)>INT_CAP or x.denominator>INT_CAP:
                raise Refused(('rational_payload_limit',INT_CAP))
        elif abs(x)>INT_CAP:
            raise Refused(('integer_payload_limit',INT_CAP))
    return z

def add(z,w):
    return check((z[0]+w[0],z[1]+w[1]))

def mul(z,w):
    a,b=z
    c,d=w
    return check((a*c-b*d,a*d+b*c))

def dec(v):
    a,b,c,d=v
    return (Fraction(a,b),Fraction(c,d))

def integral(z):
    assert all(x.denominator==1 for x in z)
    return tuple(int(x) for x in z)

def read(p):
    with p.open() as f:
        for line in f:
            work('read_input')
            yield json.loads(line)

def source():
    rays={}
    ts=[]
    for name,labels,rows in read(D/'interior-rays.jsonl'):
        if name.startswith('trace'):
            ts.append((labels,rows))
        else:
            rays[name]={j:{tuple(k):tuple(z) for k,z in t} for j,t in rows}
    assert len(ts)==4
    return rays,ts

def traces(tables):
    data=[]
    for i,side in enumerate(SIDES):
        group=[]
        for j in (0,1):
            labels,rows=tables[2*i+j]
            p=[labels.index(k) for k in side[j]]
            q=[labels.index(k) for k in side[2+j]]
            by=defaultdict(list)
            flat=[]
            for k,z in rows:
                work('trace_row_index')
                a=tuple(k[t] for t in p)
                b=tuple(k[t] for t in q)
                by[a].append((b,tuple(z)))
                flat.append((a,b,tuple(z)))
            group.append((by,flat))
        data.append(group)
    return data

def bases():
    options=[{},{}]
    middles={}
    for b in read(D/'spoke-bases.jsonl'):
        name=b['name']
        left=defaultdict(lambda:defaultdict(list))
        right=defaultdict(lambda:defaultdict(list))
        for index,k,z in b['column']:
            a,c=divmod(index,4)
            left[k][a].append((c,integral(dec(z))))
        for k,index,z in b['row']:
            a,c=divmod(index,4)
            right[k][a].append((c,integral(dec(z))))
        options[0][name]=left
        options[1][name]=right
        middles[name]={int(j):[(k,l,dec(z)) for k,l,z in vals] for j,vals in b['coordinates'].items()}
    return options,middles

def count_plans(selected,options,data):
    byside=[]
    for i,s in enumerate(('left','right')):
        work_count=0
        for e,*ix in selected[s]:
            vecs=[options[i][name][j] for name,j in zip(SPK,ix,strict=True)]
            for a,b,z in data[i][0][1]:
                work('transformed_source_candidate_preflight')
                n=1
                for r,u in zip(vecs,a,strict=True):
                    n*=len(r[u])
                work_count+=n
        byside.append(work_count)
    return byside

def calculate(selected,options,data,rays):
    out=[]
    for i,s in enumerate(('left','right')):
        tab={}
        h=rays['E' if i==0 else 'F']
        second=data[i][1][0]
        for e,*ix in selected[s]:
            vecs=[options[i][name][j] for name,j in zip(SPK,ix,strict=True)]
            value=ZERO
            for a,b,z in data[i][0][1]:
                work('transformed_source_row')
                for candidate in product(*(r[u] for r,u in zip(vecs,a,strict=True))):
                    work('transformed_source_candidate')
                    lab=tuple(p for p,v in candidate)
                    others=second.get(lab,())
                    if not others:
                        continue
                    pref=z
                    for _,w in candidate:
                        pref=mul(pref,w)
                    for rem,u in others:
                        work('transformed_trace_pair')
                        g=h[e].get((b[0],rem[0],b[1],rem[1]),ZERO)
                        if g!=ZERO:
                            value=add(value,mul(mul(pref,u),g))
            if value!=ZERO:
                if len(tab)==ROWS:
                    raise Refused(('transformed_row_cap',len(tab)+1,ROWS))
                tab[(e,*ix)]=value
        out.append(tab)
    return out

def combine(mask,mids,l,r):
    coeff=ZERO
    out={}
    for (a,b,c,d,e,f),w in mask:
        num=ZERO
        for terms in product(*(mids[n][j] for n,j in zip(SPK,(a,b,c,d),strict=True))):
            work('selected_middle_product')
            x=l.get((e,*(i for i,j,z in terms)),ZERO)
            y=r.get((f,*(j for i,j,z in terms)),ZERO)
            if ZERO in (x,y):
                continue
            pref=mul(x,y)
            for _,_,z in terms:
                pref=mul(pref,z)
            num=add(num,pref)
        if num!=ZERO:
            num=integral(tuple(Fraction(x) for x in num))
            out[a,b,c,d,e,f]=num
            coeff=add(coeff,mul((w,0),num))
    return coeff,out

def direct_controls(rays,data,out,allkeys):
    controls=[]
    @cache
    def direct_half(side,j,x,y):
        tab=data[side][0][0]
        other=data[side][1][0]
        h=rays['E' if side==0 else 'F'][j]
        val=ZERO
        for (a,z),(b,w) in product(tab.get(x,()),other.get(y,())):
            work('direct_half_source_pair')
            k=(a[0],b[0],a[1],b[1])
            v=h.get(k,ZERO)
            if v!=ZERO:
                val=add(val,mul(mul(z,w),v))
        return val
    chosen=sorted(allkeys,key=lambda k:(len(rays['A'][k[0]])*len(rays['B'][k[1]])*
        len(rays['C'][k[2]])*len(rays['D'][k[3]]),k))
    for k in chosen:
        a,b,c,d,e,f=k
        options=[]
        for n,j in zip(SPK,(a,b,c,d),strict=True):
            table=rays[n][j]
            if n in 'CD':
                options.append([((x,y,u,v),z) for (u,v,x,y),z in table.items()])
            else:
                options.append(list(table.items()))
        gross=1
        for z in options:
            gross*=len(z)
        if gross>800_000 or TOTAL+gross>CAP:
            continue
        ans=ZERO
        first=None
        paths=0
        for terms in product(*options):
            work('literal_original_ray_spoke_product')
            labels=[k for k,z in terms]
            left=direct_half(0,e,tuple(k[0] for k in labels),tuple(k[1] for k in labels))
            right=direct_half(1,f,tuple(k[2] for k in labels),tuple(k[3] for k in labels))
            if ZERO in (left,right):
                continue
            value=mul(left,right)
            for _,v in terms:
                value=mul(value,v)
            if first is None:
                first=value
            ans=add(ans,value)
            paths+=1
        assert ans==out.get(k,ZERO)
        if first is None:
            continue
        controls.append(dict(ray_key=k,original_spoke_products=gross,nonzero_paths=paths,
                             exact_numerator=ans,single_path_flip=add(ans,mul((-2,0),first))))
        if len(controls)==2:
            break
    assert controls
    return controls

def main():
    rss()
    raw,ts=source()
    data=traces(ts)
    opts,mids=bases()
    selected=json.loads((D/'selected-basis-keys.json').read_text())
    mask=[(tuple(k),w) for k,w in read(D/'weighted-mask-amplitude-0000.jsonl')]
    pre=count_plans(selected,opts,data)
    print('exact basis candidate visits',pre,'preflight work',TOTAL,flush=True)
    # Each candidate can meet at most the largest fixed-spoke trace bucket.
    max_bucket=[max(map(len,d[1][0].values())) for d in data]
    pessimistic=TOTAL+sum(len(selected[s])*len(data[i][0][1])+n*(1+max_bucket[i])
                        for i,(s,n) in enumerate(zip(('left','right'),pre,strict=True)))+9557
    (D/'q-admission.json').write_text(json.dumps(dict(exact_basis_candidates=pre,
         max_trace_bucket=max_bucket,prospective_worst_case=pessimistic,work_cap=CAP),indent=2)+'\n')
    if pessimistic>CAP:
        raise Refused(('whole_sector_before_transform',pessimistic,CAP))
    l,r=calculate(selected,opts,data,raw)
    numerator,out=combine(mask,mids,l,r)
    print('LLLL complete exact sector numerator',numerator,'ray amplitudes',len(out),flush=True)
    # Keep the exact result even if a comparison cap needs a later route.
    (D/'q-amplitudes-0000.jsonl').write_text(''.join(json.dumps([k,z],separators=(',',':'))+'\n'
                                                   for k,z in sorted(out.items())))
    with (D/'selected-transforms.jsonl').open('w') as f:
        for name,t in zip(('left','right'),(l,r),strict=True):
            for k,z in sorted(t.items()):
                print(json.dumps([name,k,z],separators=(',',':')),file=f)
    controls=direct_controls(raw,data,out,[k for k,w in mask])
    totalden=json.loads((CORE/'graph.json').read_text())['exact_denominator_before_exponential_divisor']
    v=Fraction(numerator[0]*24**5,totalden*512)
    imag=Fraction(numerator[1]*24**5,totalden*512)
    rss()
    result=dict(sector='0000',interior_scalar_numerator=numerator,nonzero_selected_transform_rows=[len(l),len(r)],
        nonzero_q_amplitude_rows=len(out),external_s4_multiplier=24**5,external_row_divisor=512,
        graph_denominator=totalden,weighted_exact_sector_value=[str(v),str(imag)],
        independent_original_ray_controls=controls,work=dict(WORK),total_work=TOTAL,caps=dict(work=CAP,rows=ROWS,sampled_rss=RSS_CAP,scalar=INT_CAP),
        sampled_peak_rss=PEAK,other_sectors_evaluated=False,full_representative_evaluated=False)
    (D/'q-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
