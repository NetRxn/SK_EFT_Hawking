#!/usr/bin/env bash
set -euo pipefail
author=/private/tmp/l1-c0-complementary-cases24-47.XWr8Qj/tuple0-1/34
root=$PWD
mkdir -p outer-lineage/checkpoint
for script in exact-multicut.py reduce-label-frontier.py contract-reduced-label.py checkpoint/quotient.py; do
    cmp "archive/$script" "$author/$script"
    cp "archive/$script" "outer-lineage/$script"
done
for script in contract-peer.py peer_pair.py; do
    cmp "/private/tmp/l1-c0-case18.szXdBy/$script" "$author/$script"
    cp "$author/$script" "outer-lineage/$script"
done
cd outer-lineage
printf 'stage\twall_seconds\n' > "$root/outer-stage-timing.tsv"
timed() {
    local stage=$1
    shift
    local TIMEFORMAT="$stage"$'\t%3R'
    { time "$@"; } 2>> "$root/outer-stage-timing.tsv"
}
timed outer-cut python3 -u exact-multicut.py "$root/parent.pkl" input.pkl 34 > plan.out
for f in input.pkl input.roster plan.out; do cmp "$f" "$author/$f"; done
printf 'PASS outer cut, roster and plan byte for byte\n'
timed primary-reduction python3 -u reduce-label-frontier.py input.pkl primary > reduce.out
cmp reduce.out "$author/reduce.out"
cmp label-primary-reduced-frontier.pkl "$author/label-primary-reduced-frontier.pkl"
ret=0
timed primary-contraction python3 -u contract-reduced-label.py primary > contract.out || ret=$?
test "$ret" = 2
cmp contract.out "$author/contract.out"
first=row-cap-physical-slice-dense-label-primary-reduced.pkl
cmp "$first" "$author/$first"
printf 'PASS primary reduction and row-cap byte for byte\n'
timed rescue-reduction python3 -u reduce-label-frontier.py "$first" rescue > rescue-reduce.out
cmp rescue-reduce.out "$author/rescue-reduce.out"
cmp label-rescue-reduced-frontier.pkl "$author/label-rescue-reduced-frontier.pkl"
ret=0
timed rescue-contraction python3 -u contract-peer.py rescue > rescue-contract.out || ret=$?
test "$ret" = 2
cmp rescue-contract.out "$author/rescue-contract.out"
second=row-cap-physical-slice-dense-label-rescue-reduced.pkl
cmp "$second" "$author/$second"
printf 'PASS rescue reduction and inner seven-factor parent byte for byte\n'
