from hashlib import sha256
from pathlib import Path
from sys import argv
from zipfile import ZipFile
root=Path(argv[1])

def check_archive(path):
    with ZipFile(path) as z:
        assert z.testzip() is None
        manifest={n.removeprefix('./'):h for h,n in map(str.split,z.read('manifest.sha256').decode().splitlines())}
        for n,h in manifest.items():
            member = n if n in z.namelist() else './'+n
            assert sha256(z.read(member)).hexdigest()==h,(path,n)
        print('PASS committed source archive and internal manifest',path,len(manifest))
check_archive('pause.zip')
check_archive('compiled.zip')
with ZipFile('pause.zip') as z:
    for n in ('cut-axes.tsv','cut-plan.tsv','contract-branch.py','prepare-branch.py'):
        assert z.read(n)==(root/n).read_bytes()
with ZipFile('compiled.zip') as z:
    for n in ('block-index.tsv','schema.tsv'):
        assert z.read(n)==(root/n).read_bytes()
manifest={n:h for h,n in map(str.split,Path('previous/review-manifest.sha256').read_text().splitlines())}
for n in ('SOURCE_PINS.txt','verify.out','group672-artifacts.sha256'):
    assert sha256((Path('previous')/n).read_bytes()).hexdigest()==manifest[n]
inputs={n:h for h,n in map(str.split,Path('previous/group672-artifacts.sha256').read_text().splitlines())}
assert inputs['row-cap-physical-slice-dense-branch.pkl']=='473aeb9c69bf918b97e23a8bb2d9fbc2c133d8b8d03f98f717004e4912ff8a54'
assert 'PASS terminal cap checkpoint '+inputs['row-cap-physical-slice-dense-branch.pkl'] in Path('previous/verify.out').read_text()
print('PASS previously verified group 672 initial cap and original compiled cut input bindings')
