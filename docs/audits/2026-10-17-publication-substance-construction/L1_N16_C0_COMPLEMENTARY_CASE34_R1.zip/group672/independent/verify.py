from collections import Counter
from hashlib import sha256,file_digest
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import load
from re import findall,search,M
from sys import argv
from zipfile import ZipFile

root=Path(argv[1])
cap_name='row-cap-physical-slice-dense-branch.pkl'
in_name='dense-saturated-frontier.pkl'
den=576173855599322741762003196268511232
known={
    '.':('473aeb9c69bf918b97e23a8bb2d9fbc2c133d8b8d03f98f717004e4912ff8a54',None),
    'worst-w-slice':('5193ddba327c99b6b17b1cf8a0f8cf0c5970dd4f6f6ea90701ecfb6a7ad244a9','f09b0bfe2183d2952cca03c0181a912e554333a096f5f56b1da54a5f214d0ab3'),
    'worst-wg-slice':('f55800b3efa04366c4264349cda7f4f88a6b413c494e5d42477470241c3f479f','a9e9bb850d0c38675dcee2128c6a065f9ce4148bf3483a9207ad380c5d5f0123'),
    'worst-wgg-slice':('f990e6d70fa7e6c3fa3e8e8c00892ece3fd6f8cf17a953563421439f583db157','192084cd501f695d4ba9215cafb1831e07a58bf828ad8618a563325fc3e5ab15'),
}
steps=[
    ('worst-w-slice',('W',1,3,0),(0,2),(('W',1,3,0),(0,2)),(26,969856,0,0)),
    ('worst-wg-slice',('G',1,3,0),97,((('W',1,3,0),(0,2)),(('G',1,3,0),97)),(24,915456,2,220536)),
    ('worst-wgg-slice',('G',1,4,2),80,(((('W',1,3,0),(0,2)),(('G',1,3,0),97)),(('G',1,4,2),80)),(22,2884800,2,1007616)),
]
def saved(folder,name,expected):
    with (root/folder/name).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==expected
        stream.seek(0)
        snapshot=load(stream)
    assert prod(d for _,_,d in snapshot['factors'])==den
    return snapshot

def keys(scope,axes):
    positions=tuple(scope.index(w) for w in axes)
    return lambda row: tuple(row[p] for p in positions)

def histogram(checkpoint):
    factors=checkpoint['factors']
    degrees=Counter(a for sc,_,_ in factors for a in sc)
    pair=checkpoint['rejected_pair']
    left,right=(factors[i] for i in pair)
    shared=tuple(k for k in left[0] if k in right[0])
    ca,cb=(Counter(map(keys(a,shared),r)) for a,r,_ in (left,right))
    matched={k:n*cb[k] for k,n in ca.items() if cb[k]}
    assert sum(matched.values())==checkpoint['matched']
    def weights(axes):
        positions=tuple(shared.index(w) for w in axes)
        counts=Counter()
        for key,n in matched.items():
            counts[tuple(key[i] for i in positions)]+=n
        assert sum(counts.values())==checkpoint['matched']
        return counts
    options=[]
    for axis in shared:
        if axis[0]!='L' and degrees[axis]==2:
            counts=weights((axis,))
            options.append((max(counts.values()),len(counts),axis,counts))
    return weights,sorted(options,key=lambda q:q[:3]),(len(left[1]),len(right[1]))

def inverse_lift(parent,cut,axis,value):
    assert cut['used_before']==parent['used_before']
    incident=[]
    for i,((axes,rows,d),(out,small,e)) in enumerate(zip(parent['factors'],cut['factors'],strict=True)):
        assert d==e
        if axis not in axes:
            assert (axes,rows,d)==(out,small,e)
            assert all(a==b for a,b in zip(rows.items(),small.items(),strict=True))
            continue
        incident.append(i)
        pos=axes.index(axis)
        assert out==axes[:pos]+axes[pos+1:]
        remaining={row[:pos]+row[pos+1:]:z for row,z in rows.items() if row[pos]==value}
        assert remaining==small
        assert all(a==b for a,b in zip(remaining.items(),small.items(),strict=True))
        recovered={row[:pos]+(value,)+row[pos:]:z for row,z in small.items()}
        assert recovered=={row:z for row,z in rows.items() if row[pos]==value}
    assert tuple(incident)==parent['rejected_pair']
    print('PASS exact ordered factor conditioning and inverse lift',axis,value,incident,
          'input rows',sum(len(r) for _,r,_ in cut['factors']),flush=True)

def reweight_widths(source, out):
    # Degree accounting gives the exact output scope of a join; the quotient only reorders scopes.
    pairs=[]
    before=[(set(a),d,i) for i,(a,_,d) in enumerate(source)]
    after=[(set(a),d,i) for i,(a,_,d) in enumerate(out)]
    sol={}
    for a,ad,i in before:
        hits=[j for b,bd,j in after if a==b and ad==bd]
        if len(hits)==1:
            sol[i]=hits[0]
    removed=set(range(len(before)))-sol.keys()
    added=set(range(len(after)))-set(sol.values())
    if len(removed)!=4 or len(added)!=2:
        print('scope genealogy unavailable from unchanged-factor bijection',len(removed),len(added),flush=True)
        return
    degree=Counter(w for ax,_,_ in source for w in ax)
    for i,j in combinations(sorted(removed),2):
        a,_,d=source[i]
        b,_,e=source[j]
        scope={w for w in a if degree[w]>(2 if w in b else 1)}|{w for w in b if w not in a and degree[w]>1}
        to=[k for k in added if set(out[k][0])==scope and out[k][2]==d*e]
        if len(to)==1:
            pairs.append((i,j,to[0]))
    assert len(pairs)==2 and {i for a,b,_ in pairs for i in (a,b)}==removed
    print('PASS independent accepted join scope/denominator genealogy',pairs,flush=True)

base=saved('.',cap_name,known['.'][0])
assert (base['matched'],base['used_before'],base['rejected_pair'])==(3563808,3028312,(4,8))
before='.'
for folder,axis,value,condition,metrics in steps:
    weights,options,old_sizes=histogram(base)
    match=weights((axis,))
    assert value in {key[0] for key in match} and match[(value,)]==max(match.values())
    print('source',before,'pair',base['rejected_pair'],'sizes',old_sizes,
          'match',base['matched'],'ranked closed-axis candidates',[(peak,n,a) for peak,n,a,_ in options],flush=True)
    print('PASS complete disjoint selected-axis cover',axis,'cases',len(match),'total',sum(match.values()),'selected',value,match[(value,)],flush=True)
    for k,n in sorted(match.items()):
        print('partition',before,axis,k[0],n,flush=True)
    child=saved(folder,in_name,known[folder][1])
    assert child['physical_cut']==condition
    inverse_lift(base,child,axis,value)
    pair_cut=child|{'rejected_pair':base['rejected_pair'],'matched':match[(value,)]}
    histogram(pair_cut)
    del pair_cut,base

    new=saved(folder,cap_name,known[folder][0])
    assert new['physical_cut']==condition
    log=(root/folder/'contraction.out').read_text()
    joins=[tuple(map(int,fields)) for fields in findall(r'^join (\d+) (\d+) (\d+) axes (\d+)$',log,M)]
    stop,matched=map(int,search(r'^open row cap (\d+) (\d+) frontier saved$',log,M).groups())
    assert (stop,matched,len(joins),sum(x[1] for x in joins))==metrics
    assert len(new['factors'])==stop and new['matched']==matched and new['used_before']==metrics[-1]
    assert [j[0] for j in joins]==list(range(len(child['factors'])-1,stop-1,-1))
    assert (root/folder/'contraction.err').read_bytes()==b''
    assert (root/folder/'contraction.time').read_text().splitlines()[-1]=='exit_status 2'
    _,_,post_sizes=histogram(new)
    if len(joins):
        reweight_widths(child['factors'],new['factors'])
    else:
        for (a,r,d),(b,s,e) in zip(child['factors'],new['factors'],strict=True):
            assert set(a)==set(b) and d==e
            permute=keys(a,b)
            assert len(s)<=len(r)
            if a==b:
                assert all(r.get(k)==z for k,z in s.items())
            else:
                source={permute(k):z for k,z in r.items()}
                assert all(source.get(k)==z for k,z in s.items())
        print('PASS W retry only removed unsupported rows before same cap; no factor merge',flush=True)
    print('PASS terminal cap',folder,'pair',new['rejected_pair'],'pair sizes',post_sizes,'factors',stop,
          'before-refusal rows',sum(len(r) for _,r,_ in new['factors']),'forecast',matched,'completed products',new['used_before'],flush=True)
    before=folder
    base=new
    del child
_,options,sizes=histogram(base)
print('next cap pair',base['rejected_pair'],'sizes',sizes,
      'ranked closed-axis candidates',[(peak,n,axis) for peak,n,axis,_ in options],flush=True)
for peak,n,axis,counts in options:
    print('next partition',axis,n,peak,sorted(counts.items()),flush=True)

with ZipFile('pause.zip') as p:
    assert p.read('contract-branch.py')==(root/'contract-branch.py').read_bytes()
old=(root/'contract-branch.py').read_text()
new=(root/'worst-w-slice/contract-slice.py').read_text()
assert new==old.replace('wire=None\nvalue=None','wire,value=obj["physical_cut"]')
print('PASS v1 and follow-on contractor differ only in carrying cut metadata',flush=True)
