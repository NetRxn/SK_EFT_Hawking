from pathlib import Path
import hashlib
import pickle
import resource
import subprocess
import sys
import time

source = Path('../worst-wg-slice/row-cap-physical-slice-dense-branch.pkl')
with source.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == 'f55800b3efa04366c4264349cda7f4f88a6b413c494e5d42477470241c3f479f'
    stream.seek(0)
    original = pickle.load(stream)
assert original['physical_cut'] == ((('W', 1, 3, 0), (0, 2)), (('G', 1, 3, 0), 97))
axis, selected = ('G', 1, 4, 2), int(sys.argv[1])
factors = original['factors']
incident = tuple(i for i, (axes, _, _) in enumerate(factors) if axis in axes)
assert incident == original['rejected_pair'] == (12, 15)
for index in incident:
    axes, rows, denominator = factors[index]
    pos = axes.index(axis)
    reduced = {key[:pos] + key[pos+1:]: value for key, value in rows.items() if key[pos] == selected}
    assert reduced and len(reduced) == sum(key[pos] == selected for key in rows)
    factors[index] = (axes[:pos] + axes[pos+1:], reduced, denominator)
cut = (original['physical_cut'], (axis, selected))
with Path('dense-saturated-frontier.pkl').open('xb') as stream:
    pickle.dump(dict(factors=factors, used_before=original['used_before'], physical_cut=cut), stream, protocol=5)
print('fixed', cut, 'rows', sum(len(rows) for _, rows, _ in factors), flush=True)
del factors, original, rows, reduced
start = time.monotonic()
with Path('contraction.out').open('xb') as out, Path('contraction.err').open('xb') as err:
    try:
        status = subprocess.run([sys.executable, '../worst-w-slice/contract-slice.py'], stdout=out, stderr=err, timeout=120).returncode
    except subprocess.TimeoutExpired:
        status = 124
elapsed = time.monotonic() - start
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
Path('contraction.time').write_text(f'elapsed_seconds {elapsed:.3f}\nchild_maxrss_bytes {usage.ru_maxrss}\nexit_status {status}\n')
raise SystemExit(status)
