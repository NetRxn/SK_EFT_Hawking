# Group 672 physical-index cut probes

The group 672 replay in L1_N16_C0_COMPLEMENTARY_CASES30_33_R1.zip supplies
the original W(1,3,0)=(0,2) checkpoint and its source pins. Rebuild that
checkpoint under worst-w-slice and match its SHA256. Use each runner in
its own named directory with only trusted local checkpoint inputs.
The two commands are python3 run.py 97 under worst-wg-slice and
python3 run.py 80 under worst-wgg-slice. Each runner restricts the named
dimension on both incident factors and preserves all remaining signed
rows and denominators. The existing contractor uses unchanged arithmetic
and row limits. The cutoff is a per-invocation local bound.

Compare the run logs and the new restart hashes. Elapsed time and peak
memory are observed local values. No accepted scalar or whole-group
runtime follows from these probes.
