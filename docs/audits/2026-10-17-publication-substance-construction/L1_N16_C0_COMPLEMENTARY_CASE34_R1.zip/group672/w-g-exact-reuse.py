from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import pickle

source = Path('row-cap-physical-slice-dense-branch.pkl')
expected = '473aeb9c69bf918b97e23a8bb2d9fbc2c133d8b8d03f98f717004e4912ff8a54'
with source.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected
    stream.seek(0)
    checkpoint = pickle.load(stream)
factors = checkpoint['factors']
i, j = checkpoint['rejected_pair']
fixed_axes = (('W', 1, 3, 0), ('G', 1, 3, 0))
assert all(tuple(k for k, (axes, _, _) in enumerate(factors) if axis in axes) == (i, j)
           for axis in fixed_axes)
source_factors = (factors[i], factors[j])

def partition(axes, rows, denominator):
    positions = tuple(axes.index(axis) for axis in fixed_axes)
    free = tuple(k for k in range(len(axes)) if k not in positions)
    result = defaultdict(dict)
    for key, coefficient in rows.items():
        label = tuple(key[k] for k in positions)
        remainder = tuple(key[k] for k in free)
        assert remainder not in result[label]
        result[label][remainder] = coefficient
    assert sum(map(len, result.values())) == len(rows)
    return tuple(axes[k] for k in free), denominator, result

left_axes, left_d, left = partition(*source_factors[0])
right_axes, right_d, right = partition(*source_factors[1])
shared = tuple(axis for axis in left_axes if axis in right_axes)
left_shared = tuple(left_axes.index(axis) for axis in shared)
right_shared = tuple(right_axes.index(axis) for axis in shared)
classes = defaultdict(list)
support = []
for label in sorted(left.keys() & right.keys()):
    lhs = Counter(tuple(row[k] for k in left_shared) for row in left[label])
    rhs = Counter(tuple(row[k] for k in right_shared) for row in right[label])
    products = sum(n * rhs[k] for k, n in lhs.items())
    if products:
        pair = ((left_axes, left_d, tuple(sorted(left[label].items()))),
                (right_axes, right_d, tuple(sorted(right[label].items()))))
        digest = hashlib.sha256(repr(pair).encode()).hexdigest()
        if classes[digest]:
            other = classes[digest][0]
            assert left[label] == left[other] and right[label] == right[other]
        classes[digest].append(label)
        support.append((label, products, digest))
assert sum(products for _, products, _ in support) == checkpoint['matched']
print('all matched products', checkpoint['matched'], 'supported pair labels', len(support),
      'exactly identical reduced factor-pair classes', len(classes))
for w in sorted({label[0] for label, _, _ in support}):
    roster = [(label, products, digest) for label, products, digest in support if label[0] == w]
    print(w, len(roster), max(p for _, p, _ in roster), sum(p for _, p, _ in roster))
for digest, labels in sorted(classes.items()):
    if len(labels) > 1:
        print('identity class', digest, labels)
