# L1 N16 dense group 128 exact case 3 and scale-up diagnostic

Source base 51e7c745e. Publication checkpoint parent d49dd81b8. This is the first binary child of tuple 0 in descendant (0,0). Case 3 is the 48-roster entry (40,(3,)), in increasing compatible-pair count and then coordinate order.

Use the original `L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip` archive, verify its manifest, and decompress `row-cap-physical-slice-dense-label-tuple0-0-reduced.pkl.gz` into a scratch path. The uncompressed SHA256 must be 5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867. Only deserialize trusted checkpoint inputs.

In a fresh scratch directory copy the author Python files and the checkpoint folder. Run `python3 -u run-batch.py /absolute/path/to/decompressed/parent.pkl 3 16 32 47`. Verify the reconstructed frontiers against the supplied hashes after the additional pilots are reproduced. Independently run `python3 /absolute/path/to/archive/independent/replay.py 3 2 label-case-3-2-reduced-frontier.pkl`. The author and independent schedules agree on 11479417446010490751717/5192296858534827628530496329220096 with imaginary part zero. The independent cut checker and clean lineage reproduction record their original scratch paths. To repeat them, point their path variables to the restored parent, the original archive's roster and the regenerated author outputs.

The cached pre-reduction case 3 attempt refused its pair limit. The final case 3 value was obtained after exact reduction and contraction with a different order. Cases 16, 32 and 47 are still open. Their first continuations returned at the same seven-factor row boundary. Each can be split on the same degree-two coordinate G(0,1,2) into nine slices. The first slice of each advanced to a three- or four-factor boundary. For case 16 the prior scalar triangle driver also refused its arithmetic cap. None of these three cases supplies an accepted scalar. These pilots measure the benefit of the split and identify the next closures to test. They do not give a runtime estimate for the full hard profile.

To regenerate each additional pilot input and its saved closure, run the following from the author scratch after the first batch.

```bash
for n in 16 32 47; do
    python3 -u exact-multicut.py "row-cap-physical-slice-dense-label-case-$n-2-reduced.pkl" "second-$n.pkl" 0
    python3 -u reduce-label-frontier.py "second-$n.pkl" "second-$n"
    python3 -u contract-reduced-label.py "second-$n"
    test "$?" = 2 || exit 1
done
```

Compare exact conditioning and hashes before continuing from any generated state. Continue the nine-slice partitions and independently check all values before accepting their outer cases. The full branch, profile and original physical susceptibility remain open.
