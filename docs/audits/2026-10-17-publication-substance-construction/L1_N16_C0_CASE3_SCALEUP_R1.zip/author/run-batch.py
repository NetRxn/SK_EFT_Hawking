from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import pickle
import subprocess
import sys

root=Path.cwd()
source=Path(sys.argv[1])
indices=[int(x) for x in sys.argv[2:]]

def invoke(script, arguments, logfile):
    with logfile.open('x') as output:
        completed=subprocess.run([sys.executable,'-u',script,*map(str,arguments)],
                                 stdout=output,stderr=subprocess.STDOUT,timeout=120)
    return completed.returncode

def solve(index):
    base=f'case-{index}'
    candidate=root/f'{base}.pkl'
    result=invoke('exact-multicut.py',[source,candidate,index],root/f'{base}-plan.out')
    if result:
        return index,'partition-error',str(result)
    for cycle in range(3):
        tag=f'{base}-{cycle}'
        result=invoke('reduce-label-frontier.py',[candidate,tag],root/f'{tag}-reduce.out')
        if result:
            return index,'reduction-error',str(result)
        path=root/f'{tag}-contract.out'
        result=invoke('contract-reduced-label.py',[tag],path)
        if result==0:
            scalar=next(line for line in path.read_text().splitlines() if line.startswith('exact normalized'))
            return index,'exact',scalar
        if result!=2:
            return index,'contraction-error',str(result)
        saved=[p for p in (root/f'join-cap-dense-label-{tag}-reduced.pkl',
                            root/f'row-cap-physical-slice-dense-label-{tag}-reduced.pkl') if p.is_file()]
        assert len(saved)==1
        candidate=saved[0]
        if cycle==2:
            with candidate.open('rb') as handle:
                factors=pickle.load(handle)['factors']
            return index,'open',f'{len(factors)} factors, {sum(len(rows) for _,rows,_ in factors)} rows, {candidate.name}'

with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(solve,indices):
        print(*result,sep='\t',flush=True)
