# Independent replay of L1 outer case 3

The task pins checkpoint d49dd81b82e5e2c4bd4fc77541c0113f96bc60af. The on-disk parent matches the archive's decompressed SHA256 5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867, and the original roster matches the archive manifest's SHA256 185ad83d0dc0b6dcaa311b65cbbc6fc8542a0b31120e8fc4fbf59d0e238b1c4c. The source archive is L1_N16_C0_LARGER_TUPLE_SEPARATOR_R1.zip.

The full 48-case roster was replayed by independent histogram matching from the archived eight-factor row-cap parent. Its 6,427,904 matched products partition over the cut coordinates G(0,4,2) and J(1,4,2). Ordering by count and then coordinate gives index 3 as (40, (3,)), with 70,896 products in the projected pair. Inverse lifting the selected case exactly recovers all compatible parent rows, denominators and Gaussian coefficients. Full conditioning and the representation-label partition survive all five saved stages. Each reduction stage has unique axes, degree-two open coordinates, exact Gaussian coefficients and the unchanged positive denominator product.

The independent direct sparse arithmetic driver contracts the final four-factor reduced input without author quotient or contraction functions. It uses a different join order and agrees with the author scalar:

- Exact real: 11479417446010490751717/5192296858534827628530496329220096.
- Exact imaginary: 0.
- 3,698,504 products total, 2,119,440 largest join, 102,128 peak output rows.
- Original factor denominator product 40512224221827380280140849737629696 and external normalization +1/(16*4^64) are applied exactly once.

The first raw-output print in the scratch replay was shadowed by the imported regex module after the verified fraction was computed. I retained that log, corrected the diagnostic, and reran the independent contraction. The first unchanged author cycle ends at a row limit, the second at a product limit. The separate four-factor cached author attempt on the pre-reduction input exceeded its 8,000,000 match cap at forecast 29,932,704. That attempt remains a refusal. The completed scalar follows the later reduced input.

Clean-scratch execution of all three frozen author transformation cycles reproduced each reduced or refusal pickle and every reduction/contraction log byte for byte. This checks complete input-to-result lineage using the existing reviewed identities. Arithmetic independence comes from the distinct direct contraction of the final frozen factors.

Acceptance covers case 3 of the first binary child of tuple 0 in branch 128. It supplies no completed aggregate beyond this specific case. The complementary cases, full tuple, branch, profile and c0 remain open.
