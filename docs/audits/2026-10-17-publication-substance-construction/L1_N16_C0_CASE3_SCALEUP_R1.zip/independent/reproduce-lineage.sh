#!/usr/bin/env bash
set -eu
author=/private/tmp/l1-c0-pilot-next.Ssjz7H
scratch=$(mktemp -d /private/tmp/l1-outer3-lineage-reproduction.XXXXXX)
cp -R "$author/checkpoint" "$scratch/"
cp "$author/reduce-label-frontier.py" "$author/contract-reduced-label.py" "$author/case-3.pkl" "$scratch/"
cd "$scratch"
input=case-3.pkl
for stage in 0 1 2; do
    tag="case-3-$stage"
    python3 -u reduce-label-frontier.py "$input" "$tag" > "$tag-reduce.out"
    cmp "label-$tag-reduced-frontier.pkl" "$author/label-$tag-reduced-frontier.pkl"
    if python3 -u contract-reduced-label.py "$tag" > "$tag-contract.out"; then
        test "$stage" = 2
    else
        test "$?" = 2
    fi
    cmp "$tag-reduce.out" "$author/$tag-reduce.out"
    cmp "$tag-contract.out" "$author/$tag-contract.out"
    for name in "row-cap-physical-slice-dense-label-$tag-reduced.pkl" "join-cap-dense-label-$tag-reduced.pkl"; do
        if test -f "$name"; then
            cmp "$name" "$author/$name"
            input="$name"
        fi
    done
    printf 'stage %s byte-identical reduction, contraction log, and any saved frontier\n' "$stage"
done
