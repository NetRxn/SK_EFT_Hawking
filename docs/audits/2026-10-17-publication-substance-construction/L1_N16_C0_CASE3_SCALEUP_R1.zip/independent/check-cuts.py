from ast import literal_eval
from collections import Counter
from pathlib import Path
import pickle

root = Path('/private/tmp/l1-tuple-separators.OxRDWT')
previous = Path('/private/tmp/l1-dense-resume.bbZW6V')

def load(path):
    return pickle.loads(path.read_bytes())

def audit(source, pair, fixed_axes, plan, children):
    parent = load(source)
    factors = parent['factors']
    degree = Counter(w for axes, _, _ in factors for w in axes)
    assert set(degree.values()) == {2}
    left, right = (factors[i] for i in pair)
    common = set(left[0]).intersection(right[0])
    ordered = tuple(sorted(common))
    buckets = Counter(tuple(dict(zip(right[0], row))[a] for a in ordered) for row in right[1])
    spectrum = Counter()
    for row in left[1]:
        assignment = dict(zip(left[0], row))
        multiplicity = buckets[tuple(assignment[a] for a in ordered)]
        if multiplicity:
            spectrum[tuple(assignment[a] for a in fixed_axes)] += multiplicity
    assert spectrum == plan
    for coordinate, path in children.items():
        fixed = dict(zip(fixed_axes, coordinate))
        child = load(path)
        assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
        assert child['label_partition'] == parent['label_partition']
        for (axes, rows, denominator), (small_axes, small_rows, small_denominator) in zip(factors, child['factors'], strict=True):
            assert denominator == small_denominator
            assert tuple(w for w in axes if w not in fixed) == small_axes
            expected = {row: value for row, value in rows.items()
                        if all(row[p] == fixed[w] for p,w in enumerate(axes) if w in fixed)}
            recovered = {}
            for row,value in small_rows.items():
                assignment = dict(zip(small_axes,row))
                assignment.update(fixed)
                recovered[tuple(assignment[w] for w in axes)] = value
            assert recovered == expected
    print(source.name, 'pair',pair,'cuts',fixed_axes,'cases',len(spectrum),
          'sum/max products',sum(spectrum.values()),max(spectrum.values()),'children audited',list(children),flush=True)

from hashlib import sha256
from math import prod

author=Path('/private/tmp/l1-c0-pilot-next.Ssjz7H')
source=root/'row-cap-physical-slice-dense-label-tuple0-0-reduced.pkl'
assert sha256(source.read_bytes()).hexdigest()=='5ce859f08bdb3e0fd9fbd7644bf194a94864cc2426fb357ca2716ed7b28e8867'
roster=root/'pilot.roster'
assert sha256(roster.read_bytes()).hexdigest()=='185ad83d0dc0b6dcaa311b65cbbc6fc8542a0b31120e8fc4fbf59d0e238b1c4c'
axes,raw=literal_eval(roster.read_text())
assert literal_eval((author/'case-3.roster').read_text())==(axes,raw)
counts=dict(raw)
ordered=sorted(counts,key=lambda coordinate:(counts[coordinate],coordinate))
assert len(ordered)==len(raw)==48
coordinate=ordered[3]
assert coordinate==(40,(3,))
assert counts[coordinate]==70896
audit(source,load(source)['rejected_pair'],axes,counts,{coordinate:author/'case-3.pkl'})
initial=load(author/'case-3.pkl')
for name,total in (('label-case-3-0-reduced-frontier.pkl',8),
                   ('row-cap-physical-slice-dense-label-case-3-0-reduced.pkl',5),
                   ('label-case-3-1-reduced-frontier.pkl',5),
                   ('join-cap-dense-label-case-3-1-reduced.pkl',4),
                   ('label-case-3-2-reduced-frontier.pkl',4)):
    data=(author/name).read_bytes()
    state=pickle.loads(data)
    assert state['conditioning']==initial['conditioning']
    assert state['label_partition']==initial['label_partition']
    factors=state['factors']
    assert len(factors)==total
    assert prod(d for _,_,d in factors)==40512224221827380280140849737629696
    assert all(len(set(a))==len(a) and d>0 and all(len(k)==len(a) and any(v) and all(type(x) is int for x in v)
              for k,v in table.items()) for a,table,d in factors)
    assert all(n==2 for n in Counter(w for a,_,_ in factors for w in a).values())
    print(name,sha256(data).hexdigest(),len(factors),sum(len(rows) for _,rows,_ in factors),flush=True)
print('PASS archive identity, complete cut roster, exact selected inverse lift and stage metadata/denominator/axis checks')
