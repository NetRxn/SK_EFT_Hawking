from ast import literal_eval
from collections import Counter
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import re

root = Path(__file__).resolve().parent
archive = root/'archive'
author = Path('/private/tmp/l1-c0-sibling-cases2-5.9i0IdU/tuple0-1')
pins = {name:digest for digest,name in (line.split() for line in (archive/'frontiers-uncompressed.sha256').read_text().splitlines())}
def load_parent(i):
    name=f'row-cap-physical-slice-dense-label-tuple0-{i}-reduced.pkl'
    raw=decompress((archive/f'{name}.gz').read_bytes())
    assert sha256(raw).hexdigest()==pins[name]
    if i == 1:
        assert pins[name]=='9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d'
        assert raw==(root/'parent.pkl').read_bytes()
    return pickle.loads(raw)

first=load_parent(0)
parent=load_parent(1)
assert first['conditioning'][:-1]==parent['conditioning'][:-1]
assert first['conditioning'][-1]==(('R',0,0,2,0,1),0)
assert parent['conditioning'][-1]==(('R',0,0,2,0,1),1)
assert first['factors']!=parent['factors']
axes,entries=literal_eval((archive/'pilot.roster').read_text())
assert len(entries)==len(dict(entries))==48
factors=parent['factors']
assert len(factors)==8 and set(Counter(w for scope,_,_ in factors for w in scope).values())=={2}
left,right=[factors[i] for i in parent['rejected_pair']]
shared=sorted(set(left[0])&set(right[0]))
lmatch=tuple(left[0].index(k) for k in shared)
rmatch=tuple(right[0].index(k) for k in shared)
lcut=tuple(left[0].index(k) for k in axes)
left_count=Counter((tuple(row[p] for p in lmatch),tuple(row[p] for p in lcut)) for row in left[1])
right_count=Counter(tuple(row[p] for p in rmatch) for row in right[1])
roster=Counter()
for (key,cut),n in left_count.items():
    if count:=n*right_count[key]:
        roster[cut]+=count
assert roster==dict(entries)
assert sum(roster.values())==parent['matched']==6427904
order=sorted(roster,key=lambda k:(roster[k],k))
print('PASS complete complementary roster',axes,len(roster),'pair products',sum(roster.values()))
for case,expected in ((2,(33,(3,))),(3,(40,(3,)))):
    work=root/f'case-{case}'
    auth=author/str(case)
    assert (auth/'input.roster').read_bytes()==(archive/'pilot.roster').read_bytes()
    assert order[case]==expected and roster[expected]==70896
    fixed=dict(zip(axes,expected,strict=True))
    raw=(auth/'input.pkl').read_bytes()
    child=pickle.loads(raw)
    assert child['conditioning']==parent['conditioning']+list(fixed.items())
    assert child['label_partition']==parent['label_partition']
    for (scope,rows,d),(small,cut_rows,e) in zip(factors,child['factors'],strict=True):
        assert d==e and small==tuple(k for k in scope if k not in fixed)
        expected_rows={row:value for row,value in rows.items() if all(row[p]==fixed[k] for p,k in enumerate(scope) if k in fixed)}
        recovered={}
        for row,value in cut_rows.items():
            assignment=dict(zip(small,row,strict=True))
            assignment.update(fixed)
            recovered[tuple(assignment[k] for k in scope)]=value
        assert recovered==expected_rows
    print('PASS exact inverse lift case',case,expected,sha256(raw).hexdigest(),sum(len(rows) for _,rows,_ in child['factors']))
    stages=[
      (auth/'label-primary-reduced-frontier.pkl',8),
      (auth/'row-cap-physical-slice-dense-label-primary-reduced.pkl',5),
      (auth/'label-rescue-reduced-frontier.pkl',5),
      (auth/'join-cap-dense-label-rescue-reduced.pkl',4),
      (work/'label-independent-reduced-frontier.pkl',4),
    ]
    for path,length in stages:
        raw=path.read_bytes()
        state=pickle.loads(raw)
        assert state['conditioning']==child['conditioning'] and state['label_partition']==child['label_partition']
        f=state['factors']
        assert len(f)==length
        assert set(Counter(w for scope,_,_ in f for w in scope).values())=={2}
        assert all(d>0 and len(set(scope))==len(scope) and all(len(row)==len(scope) and len(value)==2 and any(value) and all(type(x) is int for x in value) for row,value in rows.items()) for scope,rows,d in f)
        assert prod(d for _,_,d in f)==40512224221827380280140849737629696
        print('PASS stage',case,path.name,sha256(raw).hexdigest(),len(f),sum(len(rows) for _,rows,_ in f))
    state=pickle.loads(stages[-2][0].read_bytes())
    width=len(state['factors'][0][1])
    den=prod(d for _,_,d in state['factors'])
    scale=den*16*4**64
    exact_re=r'^exact normalized real (\S+) imaginary (\S+)(?: |$)'
    raw_sum=[0,0]
    hi=0
    work_counts=[]
    probe_counts=[]
    for shard in range(8):
        text=(auth/f'slice-{case}-shard-{shard}.out').read_text()
        low,end,total,index,n=map(int,re.search(r'^left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)$',text,re.M).groups())
        assert low==hi==width*shard//8 and end==width*(shard+1)//8 and (total,index,n)==(width,shard,8)
        assert 'left pair 0 2 ' in text
        hi=end
        products,retained,probes,a,b,den2=map(int,re.search(r'^closure products (\d+) retained outer matches (\d+) closure probes (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)$',text,re.M).groups())
        assert den==den2
        work_counts.append(products+2*retained)
        probe_counts.append(probes)
        assert work_counts[-1]<=30_000_000 and probes<=30_000_000
        raw_sum[0]+=a
        raw_sum[1]+=b
        assert tuple(map(Fraction,re.search(exact_re,text,re.M).groups()))==(Fraction(a,scale),Fraction(b,scale))
        assert f"conditioning {state['conditioning']} label partition {state['label_partition']}" in text
    assert hi==width
    expected_raw=tuple(raw_sum)
    exact=tuple(Fraction(n,scale) for n in raw_sum)
    summary=(auth/'exact-shards.out').read_text()
    assert f'complete shards 8 left rows {width} raw {raw_sum[0]} {raw_sum[1]} factor denominator {den}' in summary
    assert f'maximum shard arithmetic {max(work_counts)} maximum closure probes {max(probe_counts)}' in summary
    assert tuple(map(Fraction,re.search(exact_re,summary,re.M).groups()))==exact
    print('PASS author eight-shard interval coverage and exact raw totals',case,width,*expected_raw,'max products/probes',max(work_counts),max(probe_counts))
    independent=(work/'post-replay.out').read_text()
    assert f"conditioning {state['conditioning']} label partition {state['label_partition']}" in independent
    assert tuple(map(int,re.search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',independent,re.M).groups()))==(*expected_raw,den)
    assert tuple(map(Fraction,re.search(exact_re,independent,re.M).groups()))==exact
    print('PASS independent complementary case',case,expected,'exact normalized',*exact)
