# Independent verification of complementary tuple 0 cases 2 and 3

The verified cases have imaginary component zero.

| Case | Original coordinate | Exact normalized real |
|---|---|---:|
| 2 | (33, (3,)) | 10046146121220966055407/5192296858534827628530496329220096 |
| 3 | (40, (3,)) | 11479417446010490751717/5192296858534827628530496329220096 |

The committed separator archive at 31e39aa98b747190462cf4f9b0f78a318b9f1618
matches the worktree bytes and its manifest verified. The complementary
parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It has selector R(0,0,2,0,1)=1 and distinct factor tables from the first
child at selector 0. An independent histogram on its rejected factor
pair reconstructs the complete 48-coordinate roster over 6,427,904
matched products. Each selected coordinate accounts for 70,896 products.
Both inverse lifts recover 398,724 compatible parent rows with identical
Gaussian coefficients and denominators.

Clean scratch execution reproduced each cut, plan, roster, reduction,
checkpoint and refusal receipt byte for byte. The primary steps
refused at a row cap, and their rescues refused at a four-factor join
cap after 1,044,576 completed products. For each case, eight successful
author shards partition the full 16,892-row factor at streaming pair
(0,2). The audit independently checked all 16 intervals, all exact
raw and normalized shard sums and the resource metadata.

The author terminal four-factor checkpoints each hold 545,196 rows.
The direct support-only attempt still forecast 8,658,080 products in
its smallest join and stopped before multiplication at its 8,000,000
limit. The retained logs record this bounded refusal. A fresh application
of the reviewed exact quotient reducer to each original terminal four-factor
checkpoint reduced its row count to 84,654, stripping one singleton
axis and folding 378 proportional slices. Each resulting input preserves
its own conditioning, label partition and denominator product.

On the two resulting inputs, the independent sparse arithmetic
reached the same author raw and normalized values with two distinct
schedules. The greedy schedule uses 3,698,504 products. The alternate
schedule starts on (1,3) and uses 4,326,904 products. The sparse arithmetic
imports no author contraction code and applies the common denominator
40512224221827380280140849737629696 and normalization factor 1/(16*4^64)
once. The raw numerators and exact fractions appear in the replay logs.

Run `bash reproduce-independent.sh 2` and `bash reproduce-independent.sh 3`
from this evidence directory to reproduce the additional reduction and
both sparse schedules against their own author receipts.
