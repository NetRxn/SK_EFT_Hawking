# Complementary tuple 0 child cases 2 and 3

Restore the pinned complementary parent from the committed separator
archive in the review source pins. The independent report describes
the source reconstruction, exact cut lifts and both terminal schedules.
The review scripts refer to the original scratch layout. Restore its
input bytes by regenerating the author states with the embedded drivers
and verifying the frontier hashes.

For each case, generate the distinct input with
`python3 exact-multicut.py PARENT input.pkl CASE`. Use reduction tag
primary and then contract with `contract-reduced-label.py primary`.
The saved primary cap checkpoint feeds `reduce-label-frontier.py` with
tag rescue, then `contract-peer.py rescue`. Its saved join-cap state
feeds `close-four-shards.py --pair 0 2 --shard SHARD 8` once per shard.
The restoration preserves all complete shard intervals. Treat all
pickles as trusted input artifacts.

For exact arithmetic readback, compare `pilot-totals.tsv` to
`exact-subtotals.tsv` in the preceding sibling pilot archive, then run
`python3 verify-and-retally.py`. This checks full author shard coverage,
all integer scalar numerators and the two separate reviewer schedules.
The resulting sum covers four of 48 terms of this child.
