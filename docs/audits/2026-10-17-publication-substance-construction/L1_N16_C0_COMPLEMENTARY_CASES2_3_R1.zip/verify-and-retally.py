from pathlib import Path
from fractions import Fraction
import re
import subprocess
import sys

case_value={}
for line in Path('pilot-totals.tsv').read_text().splitlines():
    family,index,real,imaginary=line.split('\t')
    if family=='tuple0-1' and index.isdigit():
        case_value[int(index)]=(Fraction(real),Fraction(imaginary))
assert set(case_value)=={0,1}
for n in (2,3):
    case=Path('author')/str(n)
    a=subprocess.check_output([sys.executable,'sum-shards.py',str(n),'8'],cwd=case,text=True)
    assert a==(case/'exact-shards.out').read_text()
    expect=re.search(r'raw (-?\d+) (-?\d+) factor denominator (\d+)',a,re.M)
    raw=tuple(map(int,expect.groups()))
    reviewer=Path('review')/f'case-{n}'
    for receipt in ('post-replay.out','alternate-replay.out'):
        output=(reviewer/receipt).read_text()
        m=re.search(r'raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)',output)
        assert tuple(map(int,m.groups()))==raw
        scaled=re.search(r'exact normalized real (\S+) imaginary (\S+)',output)
        x,y=map(Fraction,scaled.groups())
        assert (x,y)==(Fraction(raw[0],raw[2]*16*4**64),Fraction(raw[1],raw[2]*16*4**64))
    case_value[n]=x,y
for n,(x,y) in sorted(case_value.items()):
    print(n,x,y,sep='\t')
print('PARTIAL SUM',len(case_value),*map(sum,zip(*case_value.values())),sep='\t')
