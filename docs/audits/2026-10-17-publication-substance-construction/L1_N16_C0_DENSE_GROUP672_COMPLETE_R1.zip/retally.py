from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

def parse_roster():
    lines = Path("source/joint-label-roster.tsv").read_text().splitlines()
    axes = literal_eval(lines[0].split("\t")[1])
    rows = [line.split("\t") for line in lines[1:]]
    assert len(axes) == len(set(axes)) == 12
    assert [int(row[0]) for row in rows] == list(range(8))
    labels = [literal_eval(row[1]) for row in rows]
    assert len(set(labels)) == 8 and all(len(row) == 12 for row in labels)
    return {int(i): int(nrows) for i, _, nrows, _ in rows}

def exact_child(root):
    phases = sorted(root.glob("pass*.out"))
    candidates = []
    for out in phases:
        lines = out.read_text().splitlines()
        matches = [line for line in lines if line.startswith("exact raw scalar ")]
        if not matches:
            continue
        assert len(matches) == 1
        data = matches[0].removeprefix("exact raw scalar ")
        real, imag = literal_eval(data) if data.startswith("(") else tuple(map(int, data.split()))
        transformed = [line for line in lines if line.startswith("exact follow join ")]
        if transformed:
            terminal_join = literal_eval(transformed[-1].removeprefix("exact follow join ").split(" remaining ")[0])
            assert terminal_join[5:7] == (1, 0)
            denominator = terminal_join[7]
        else:
            joined = [line for line in lines if line.startswith("exact accepted join ")]
            assert joined
            terminal_join = literal_eval(joined[-1].removeprefix("exact accepted join ").split(" remaining ")[0])
            assert terminal_join[4:6] == (1, 0)
            denominator = terminal_join[6]
        candidates.append((real, imag, denominator))
    if (root/"terminal.out").exists():
        pattern = r"triangle signed numerator [012] [012] [012] (-?\d+) (-?\d+) denominator (\d+)"
        matches = [tuple(map(int, row)) for row in re.findall(pattern, (root/"terminal.out").read_text())]
        assert len(matches) >= 2 and len(set(matches)) == 1
        candidates.extend(matches)
    assert candidates and len(set(candidates)) == 1
    return candidates[0]

if __name__ == "__main__":
    rows = parse_roster()
    inherited = Path("source/L0_L7_RETALLY.txt").read_text()
    pattern = r"joint-L ([07]) exact raw (-?\d+) (-?\d+) factor denominator (\d+)"
    parent = re.findall(pattern, inherited)
    assert len(parent) == 2
    contributions = {int(i): (int(x), int(y), int(d)) for i, x, y, d in parent}
    assert contributions.keys() == {0, 7}
    for i in sorted(int(p.name[1:]) for p in Path.cwd().glob("L[1-6]") if p.is_dir()):
        direct = Path(f"L{i}")
        disposition = direct/"independent-review.zip"
        assert disposition.is_file()
        assert (direct/"preparation.out").read_text().strip() == f"group672 label selector {i} rows {rows[i]} census 8"
        assert (direct/"joint-label-roster.tsv").read_bytes() == Path("source/joint-label-roster.tsv").read_bytes()
        expected = exact_child(direct)
        independent = (direct/"independent-scalar.tsv").read_text().splitlines()
        assert independent[0] == "group\tscope\toriginal_joint_L_index\traw_real\traw_imag\tinherited_factor_denominator"
        assert len(independent) == 2
        group, scope, label, x, y, den = independent[1].split("\t")
        assert group == "672" and scope == "whole_original_joint_L_assignment" and int(label) == i
        assert (int(x), int(y), int(den)) == expected
        contributions[i] = expected
    den, = {data[2] for data in contributions.values()}
    proof = Path("source/original-label-review.md").read_text()
    assert str(den) in proof and "sign +1" in proof and "1/(16*4^64)" in proof
    for i,(real,imag,_) in sorted(contributions.items()):
        print("original joint-L", i, "raw", real, imag, "factor denominator", den)
        print("normalized contribution", Fraction(real, den*16*4**64), Fraction(imag, den*16*4**64))
    real = sum(x for x,_,_ in contributions.values())
    imag = sum(y for _,y,_ in contributions.values())
    complete = sorted(contributions) == list(range(8))
    print("accepted assignments", tuple(sorted(contributions)), "full group", complete)
    print("normalized signed total", Fraction(real, den*16*4**64), Fraction(imag, den*16*4**64))
