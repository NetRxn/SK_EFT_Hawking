# Original group 672 signed contraction

The earlier original-label route proves the complete roster and the
original normalization. Previous accepted evidence supplies assignments
0 and 7. The frozen signed author receipts and independent replays here
supply the remaining assignments. No child is counted twice.

After extracting into an empty directory, verify all members and replay
the retally.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B retally.py | cmp - RETALLY.txt
```

Each author directory contains the exact scripts, source receipts and
pinned operands. The corrected original family input and proof of support
are supplied by the existing original-label route archive. Intermediate
binary coefficients are pinned and reconstructed from the recorded
scripts. Every included independent review binds its own source path,
retained signed table comparisons and exact terminal receipt. When an
independent package reviews two assignments, the matching ledger row is
copied with each assignment. The retally checks those rows against the
corresponding author terminal.

The original finite-model factor denominator, orientation and occupation
prefactor enter once. This group value is a single contribution to the
full coefficient. The physical source correspondence, susceptibility,
and original publication requirements are separate open obligations.
