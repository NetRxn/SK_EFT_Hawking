#!/bin/sh
set -eu
test "$(git hash-object separator.zip)" = 02e33786d0bcd46e2314ad7fec1453595adcc815
test "$(git hash-object restart.zip)" = d7425904376ed3ffc07028be1e3c4cf97ec4186e
test "$(git hash-object conditioned.zip)" = 6f2182a9f567a46286cf5a6ea83fc282092981ce
unzip -p separator.zip contract-reduced-label.py | cmp - normalization-source.py
unzip -p restart.zip contract-reduced-label.py | cmp - normalization-source.py
unzip -p conditioned.zip author/contract-reduced-label.py | cmp - normalization-source.py
test "$(shasum -a 256 normalization-source.py | cut -d' ' -f1)" = a34ea27bea0d100d8828d51bfc9562a9ec69eb94d84c99a8b3c39e88d57cb8cd
unzip -p conditioned.zip REPRODUCE.md | grep -F 'Each value includes its own factor-denominator product and the verified external normalization +1/(16*4^64). Do not add a further orbit weight or chirality multiplicity at this conditioned stage.'
printf 'PASS all three committed archive pins and byte-identical normalization source\n'
