from collections import Counter
from hashlib import sha256
from pathlib import Path
import json,re,subprocess
base,candidate=Path('base'),Path('candidate')
meta=Path('papers/D8/bundle_metadata.json')
sweep=Path('docs/audits/stage13_attribution_sweep_2026-06-10.md')
prompt=Path('docs/agents/claims-reviewer-bundle-prompts.md')
finding=Path('papers/AutomatedReviews/2026-08-15-d8-stage10-redraft/D8.md')
assert {p.relative_to(base) for p in base.rglob('*') if p.is_file() and p.read_bytes()!=(candidate/p.relative_to(base)).read_bytes()}=={meta,sweep,prompt}
a,b=(json.loads((p/meta).read_text()) for p in (base,candidate))
assert a['notes']!=b['notes'] and b['notes'].startswith(a['notes'])
assert {k:v for k,v in a.items() if k!='notes'}=={k:v for k,v in b.items() if k!='notes'}
old,new=((p/sweep).read_text() for p in (base,candidate))
title=next(l for l in old.splitlines() if l.startswith('## D8 '))
assert new.split(title,1)[0]==old.split(title,1)[0]
assert new.split('### Historical 2026-06-10 D8 sweep',1)[1].split('\n\n\n',1)[1]==old.split(title,1)[1].lstrip('\n')
old_prompt,new_prompt=((p/prompt).read_text() for p in (base,candidate))
extract=lambda s:s.split('### D8.',1)[1].split('\n### ',1)[0]
assert 'Kuperberg' in extract(old_prompt) and 'Kuperberg' not in extract(new_prompt)
assert '(../audits/stage13_attribution_sweep_2026-06-10.md#d8)' in extract(new_prompt)
assert 'project-authored summaries as' in extract(new_prompt)
assert new_prompt.replace(extract(new_prompt),extract(old_prompt),1)==old_prompt
draft=(candidate/'papers/D8/paper_draft.tex').read_text()
keys={k.strip() for m in re.finditer(r'\\cite(?:\[[^\]]*\])?\{([^{}]+)\}',draft) for k in m[1].split(',')}
bib=set(re.findall(r'^@[A-Za-z]+\{([^,]+),',(candidate/'papers/D8/bibliography.bib').read_text(),re.M))
rows={}
for ln in new.split('**2026-11-07 anchor readback.**',1)[1].split('### Historical',1)[0].splitlines():
    if ln.startswith('| ') and not ln.startswith(('| Citation key','| ---')):
        key,use,status,evidence=map(str.strip,ln.strip('|').split('|'))
        assert use and evidence and key not in rows
        rows[key]=(use,status,evidence)
assert len(keys)==19 and len(bib)==20 and set(rows)==keys and bib-keys=={'BMPRV1999'}
assert rows['Brylinski2002'][1]=='NOT-SUPPORTED' and rows['Hietala2020VOQC'][1]=='SUPPORTED'
line=next(l for l in (candidate/finding).read_text().split('### 1.6 ',1)[1].split('### 1.7 ',1)[0].splitlines() if l.startswith('- **Verify:**'))
cmd=line.split('`')[1]
receipts={}
for label,p,code,out in [('baseline',base,1,'0'),('candidate',candidate,0,'5')]:
    run=subprocess.run(cmd,cwd=p,shell=True,text=True,capture_output=True)
    assert (run.returncode,run.stdout.strip(),run.stderr)==(code,out,'')
    receipts[label]={'exit':run.returncode,'count':out}
print(json.dumps({'rows':rows,'counts':dict(Counter(v[1] for v in rows.values())),'verify':receipts,
    'unchanged_writer_fields':{k:a[k] for k in ('open_findings','blocked_p1_gates')},
    'changed_meta_fields':['notes'],'historical_exact':True,'unreferenced_bibkeys':sorted(bib-keys)},indent=2,ensure_ascii=False))
