from ast import literal_eval
from collections import Counter
from hashlib import sha256
from math import prod
from itertools import combinations
from pathlib import Path
from gzip import decompress
from pickle import loads
from re import fullmatch
from sys import argv
from fractions import Fraction

from exact_factors import DEN, read, groups, overlap, reduce_factors, prune, combine, quotient, proj

index=int(argv[1])
author=Path('inputs')/str(index)
raw=decompress(Path('parent.pkl.gz').read_bytes())
digest=sha256(raw).hexdigest()
assert digest=='ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c'
parent=loads(raw)
assert dict(parent['conditioning'])[('R',0,6,1,1,1)] == 1
assert parent['physical_cut']==(('R',0,6,1,1,1),1)
assert parent['used_before']==0
print('PASS packed parent uncompressed SHA256',digest,flush=True)
assert parent['label_partition']['index'] == 1
factors = parent['factors']
assert len(factors)==6
assert set(Counter(w for axes,_,_ in factors for w in axes).values())=={2}
assert parent['rejected_pair']==(0,1)
li,ri = parent['rejected_pair']
left,right = factors[li],factors[ri]
cut_axes, table=literal_eval((author/'pilot.roster').read_text())
assert cut_axes == (('G',0,0,2),('J',1,4,2))
assert all(w in left[0] for w in cut_axes)
shared=overlap(left[0],right[0])
B=groups(right,shared)
joinpos=tuple(left[0].index(w) for w in shared)
cutpos=tuple(left[0].index(w) for w in cut_axes)
spectrum=Counter()
for row in left[1]:
    multiplicity=len(B.get(tuple(row[j] for j in joinpos),()))
    if multiplicity:
        spectrum[tuple(row[j] for j in cutpos)] += multiplicity
assert len(table)==len(spectrum)==36 and spectrum==dict(table)
assert sum(spectrum.values())==parent['matched']==6838272
assert sorted(spectrum,key=lambda k:(spectrum[k],k))[0]==(17,(3,))
case=sorted(spectrum,key=lambda k:(spectrum[k],k))[index]
print('PASS complete 36-case roster',sum(spectrum.values()),'minimum',min(spectrum.values()),
      'maximum',max(spectrum.values()),'case',index,case,spectrum[case],flush=True)
i,k,n,x,y,terminal= (author/'exact.tsv').read_text().strip().split('\t')
assert int(i)==index and literal_eval(k)==case and int(n)==spectrum[case]
terminal=int(terminal)
assert terminal in range(3)
fixed=dict(zip(cut_axes,case,strict=True))
conditions=parent['conditioning']+list(fixed.items())

def state(name):
    raw=(author/name).read_bytes()
    obj=loads(raw)
    print('checkpoint',name,'SHA256',sha256(raw).hexdigest(),'rows',sum(len(r) for _,r,_ in obj['factors']),flush=True)
    assert obj['conditioning']==conditions and obj['label_partition']==parent['label_partition']
    assert obj['physical_cut']==parent['physical_cut']
    assert prod(d for _,_,d in obj['factors'])==DEN
    return obj

def product_count(factors,i,j):
    a,b=factors[i],factors[j]
    shared=overlap(a[0],b[0])
    A,B=groups(a,shared),groups(b,shared)
    return sum(len(A[k])*len(B[k]) for k in A.keys() & B.keys())

def retained_join(factors, count, rows, width, quotiented=False):
    candidates=[(i,j) for i,j in combinations(range(len(factors)),2)
                if product_count(factors,i,j)==count]
    matches=[]
    for i,j in candidates:
        trial=list(factors)
        if quotiented:
            assert quotient(trial,i,j)+quotient(trial,j,i)==0
        left,right=trial[i],trial[j]
        shared=overlap(left[0],right[0])
        outward=tuple(w for w in left[0]+right[0] if w not in shared)
        if len(outward)!=width:
            continue
        restrictions=[]
        if count>250000:
            for k,peer in enumerate(trial):
                if k in (i,j):
                    continue
                scope=overlap(peer[0],outward)
                restrictions.append((proj(outward,scope),set(map(proj(peer[0],scope),peer[1]))))
        combined,actual=combine(left,right,lambda row: all(key(row) in allowed for key,allowed in restrictions))
        assert actual==count
        result=[f for k,f in enumerate(trial) if k not in (i,j)]+[combined]
        prune(result,len(result)-1)
        if len(result[-1][1])==rows:
            matches.append((i,j,result))
    assert len(matches)==1, (count,candidates,[(i,j) for i,j,_ in matches])
    i,j,result=matches[0]
    print('retained join pair',i,j,'products',count,'rows',rows,flush=True)
    return result

cut=state('pilot.pkl')
assert (author/'plan.out').read_text().splitlines()[-1]==f'pilot {case!r} matched {spectrum[case]} stored rows {sum(len(r) for _,r,_ in cut["factors"])}'
for (axes,rows,d),(out,small,e) in zip(factors,cut['factors'],strict=True):
    assert d==e and out==tuple(w for w in axes if w not in fixed)
    recovered={}
    for row,z in small.items():
        lookup=dict(zip(out,row,strict=True)) | fixed
        recovered[tuple(lookup[w] for w in axes)]=z
    expected={row:z for row,z in rows.items() if all(row[i]==fixed[w] for i,w in enumerate(axes) if w in fixed)}
    assert recovered==expected
print('PASS inverse lift preserves every coefficient, axis and denominator',flush=True)


working=list(cut['factors'])
measure={parts[1]:(parts[0],int(parts[2]),float(parts[3])) for line in
         (author/'timing.tsv').read_text().splitlines() if (parts:=line.split('\t'))}
assert measure['plan.out'][:2]==('exact-multicut.py',0)
assert len(measure)==1+2*(terminal+1)
for stage in range(terminal+1):
    tag=f'pilot-{stage}'
    assert measure[f'reduce-{stage}.out'][:2]==('reduce-label-frontier.py',0)
    assert measure[f'contract-{stage}.out'][:2]==('contract-reduced-label.py',0 if stage==terminal else 2)
    reduce_factors(working)
    reduced=state(f'label-{tag}-reduced-frontier.pkl')
    assert working==reduced['factors']
    lines=(author/f'contract-{stage}.out').read_text().splitlines()
    assert lines[0].endswith(f'factors {len(working)} prior matched work {reduced.get("used_before",0)}')
    if stage==terminal:
        exact=fullmatch(r'exact normalized real (\S+) imaginary (\S+) peak rows (\d+) matched products (\d+)',lines[-1])
        assert exact and tuple(map(Fraction,exact.groups()[:2]))==(Fraction(x),Fraction(y))
        print('PASS terminal checkpoint fully reproduced from pinned cut',
              index,'stage',stage,'author elapsed',sum(m[2] for m in measure.values()),flush=True)
        break
    prune(working)
    prune(working)
    work=0
    quotient_pending=False
    for line in lines[1:-1]:
        quotient_line=fullmatch(r'quotient before join (\d+) (\d+) (\d+) slices (\d+)',line)
        if quotient_line:
            size,before,after,folded=map(int,quotient_line.groups())
            assert size==len(working) and before==after and folded==0
            quotient_pending=True
        else:
            size,count,rows,width=map(int,fullmatch(r'join (\d+) (\d+) (\d+) axes (\d+)',line).groups())
            assert size==len(working)-1
            working=retained_join(working,count,rows,width,quotient_pending)
            work+=count
            quotient_pending=False
    cap=state(f'row-cap-physical-slice-dense-label-{tag}-reduced.pkl')
    i,j=cap['rejected_pair']
    assert cap['used_before']==work
    if quotient_pending:
        assert quotient(working,i,j)+quotient(working,j,i)==0
    assert working==cap['factors']
    forecast=product_count(working,i,j)
    assert forecast==cap['matched']
    assert lines[-1]==f'open row cap {len(working)} {forecast} frontier saved'
    print('PASS refusal checkpoint exact tables retained work',work,'forecast',forecast,flush=True)
