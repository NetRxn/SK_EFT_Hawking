from hashlib import sha256
from pathlib import Path
from pickle import loads

def fingerprint(factors):
    digest=sha256()
    for axes,rows,denominator in factors:
        digest.update(repr((axes,denominator)).encode()+b'\n')
        for key,coeff in sorted(rows.items()):
            digest.update(repr((key,coeff)).encode()+b'\n')
    return digest.hexdigest()

seen=set()
seen_terminal=set()
print('case\tcut_factor_tables_sha256\tterminal_factor_tables_sha256')
for number in range(17,26):
    root=Path('inputs')/str(number)
    stage=int((root/'exact.tsv').read_text().strip().split('\t')[-1])
    original=loads((root/'pilot.pkl').read_bytes())
    terminal=loads((root/f'label-pilot-{stage}-reduced-frontier.pkl').read_bytes())
    f=fingerprint(original['factors'])
    t=fingerprint(terminal['factors'])
    print(number,f,t,sep='\t')
    assert f not in seen, (number,'identical cut factor table')
    seen.add(f)
    seen_terminal.add(t)
print('distinct',len(seen),len(seen_terminal),sep='\t')
