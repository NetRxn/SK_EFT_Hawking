#!/bin/sh
set -eu
i=$1
author=/private/tmp/l1-child01-tuples234.cugnpQ/tuple1-remainder/$i
test -s "$author/exact.tsv"
mkdir -p "inputs/$i/checkpoint" "reviews/$i"
for file in "$author"/*.py "$author"/*.pkl "$author"/*.out "$author"/*.tsv "$author"/pilot.roster; do cp "$file" "inputs/$i/"; done
cp "$author/checkpoint/quotient.py" "inputs/$i/checkpoint/"
for entry in checkpoint/quotient.py contract-reduced-label.py reduce-label-frontier.py exact-multicut.py; do
  unzip -p archived-separator.zip "$entry" | cmp - "inputs/$i/$entry"
  printf '%s: committed separator byte match\n' "$entry"
done > "reviews/$i/source-pins.out"
/usr/bin/time -p python3 -u verify-lineage.py "$i" > "reviews/$i/lineage.out" 2> "reviews/$i/lineage.time"
stage=$(cut -f6 "inputs/$i/exact.tsv")
/usr/bin/time -p python3 -u replay.py "$i" "$stage" "inputs/$i/label-pilot-$stage-reduced-frontier.pkl" "inputs/$i/contract-$stage.out" > "reviews/$i/replay.out" 2> "reviews/$i/replay.time"
if test "$stage" -eq 1; then
    /usr/bin/time -p python3 -u verify-cap.py "inputs/$i/row-cap-physical-slice-dense-label-pilot-0-reduced.pkl" > "reviews/$i/cap.out" 2> "reviews/$i/cap.time"
fi
