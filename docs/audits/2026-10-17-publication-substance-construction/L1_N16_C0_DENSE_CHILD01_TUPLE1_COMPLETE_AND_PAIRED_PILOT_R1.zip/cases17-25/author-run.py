from ast import literal_eval
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction
import hashlib
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
source=root.parent/'row-cap-physical-slice-dense-label-1-2-reduced.pkl'
template=root.parent/'tuple1-pilot'
with source.open('rb') as f:
    assert hashlib.file_digest(f,'sha256').hexdigest()=='ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c'
references={name: digest for digest,name in (row.split(maxsplit=1) for row in (template/'source.sha256').read_text().splitlines())}
axes,roster=literal_eval((template/'pilot.roster').read_text())
assert axes==(('G',0,0,2),('J',1,4,2)) and len(roster)==36 and sum(n for _,n in roster)==6_838_272
order=sorted(roster,key=lambda row:(row[1],row[0]))

def run_case(index):
    path=root/str(index)
    path.mkdir()
    (path/'checkpoint').mkdir()
    shutil.copyfile(template/'checkpoint/quotient.py',path/'checkpoint/quotient.py')
    for name,digest in references.items():
        body=(template/name).read_bytes()
        assert hashlib.sha256(body).hexdigest()==digest
        (path/name).write_bytes(body)
    def run(script,args,receipt,allowed):
        start=time.monotonic()
        with (path/receipt).open('xb') as out:
            p=subprocess.run([sys.executable,'-u',script,*args],cwd=path,stdout=out,stderr=subprocess.STDOUT,timeout=150)
        elapsed=time.monotonic()-start
        with (path/'timing.tsv').open('a') as f:
            print(script,receipt,p.returncode,f'{elapsed:.6f}',sep='\t',file=f)
        assert p.returncode in allowed, (index,script,p.returncode)
        return p.returncode
    run('exact-multicut.py',[str(source),'pilot.pkl',str(index)],'plan.out',(0,))
    assert literal_eval((path/'pilot.roster').read_text()) == (axes,roster)
    key,count=order[index]
    assert (path/'plan.out').read_text().splitlines()[-1].startswith(f'pilot {key!r} matched {count} ')
    current='pilot.pkl'
    for stage in range(3):
        tag=f'pilot-{stage}'
        run('reduce-label-frontier.py',[current,tag],f'reduce-{stage}.out',(0,))
        rc=run('contract-reduced-label.py',[tag],f'contract-{stage}.out',(0,2))
        terminal=(path/f'contract-{stage}.out').read_text().splitlines()[-1]
        if rc==0:
            match=re.search(r'^exact normalized real (\S+) imaginary (\S+)',terminal)
            assert match
            real,imag = map(Fraction,match.groups())
            row=(index,key,count,real,imag,stage)
            (path/'exact.tsv').write_text('\t'.join(map(str,row))+'\n')
            print(*row,sep='\t',flush=True)
            return
        [saved]=list(path.glob(f'*-dense-label-{tag}-reduced.pkl'))
        current=saved.name
    (path/'capped.tsv').write_text(f'{index}\t{key}\t{current}\t{terminal}\n')
    print(index,key,'capped',terminal,sep='\t',flush=True)

cases=tuple(map(int,sys.argv[1:]))
assert len(set(cases))==len(cases) and set(cases) <= set(range(36))-{0,29}
with ThreadPoolExecutor(max_workers=2) as executor:
    list(executor.map(run_case,cases))
