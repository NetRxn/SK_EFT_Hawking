# Independent exact review of descendant (0,1), tuple 1, case 0

Accepted the signed normalized result `-84902755924970084587311/2596148429267413814265248164610048 + 0i` for case 0 at `(17,(3,))`, physical selector 1 and dense-label tuple 1. This is one of 36 terms.

The publication checkpoint is `07ce065a1175bcfbf3567c57dfd8eca573471034`. The committed separator and completed prior tuple 1 archive have Git blob IDs `02e33786d0bcd46e2314ad7fec1453595adcc815` and `377bab579075bc79b0acad3ccc26b11bec020cfd`. The compressed copy of the candidate six-factor parent decompresses to SHA-256 `ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c`, the parent previously reproduced from the accepted descendant in the candidate input review (`prior-candidate-inputs.sha256`). The pilot's four numerical source files byte-match the separator archive.

An independent exact factor kernel recomputed the full 36-coordinate cut roster for rejected pair (0,1). The mutually exclusive, exhaustive coordinates account for 6,838,272 formal products, with 142,464 at case 0 and a maximum of 213,696. The inverse lift recovers every coefficient, axis and denominator of the conditioned factor tables. The reconstruction verified the bounded pass with 34,488 products and 20,952 output rows, the five-factor refusal at a projected 2,657,280 products, and the rescued 72,808-row restart input at SHA-256 `8ea594d3e52dded6a2e503a366f1b69ef634b2259bbe357f36296ae8c3717f83`. The refusal checkpoint was preserved and compared factor by factor.

A signed sparse replay used four ordinary joins with exact Gaussian-integer accumulation, exercising 9,246,720 matched products with a largest join of 4,292,352 products and a peak of 238,464 retained output rows. The raw numerator was `(-7213362939341771763614558814330209883534656474230813386250125312,0)`, with factor denominator `40512224221827380280140849737629696`. Applying the positive external normalization `1/(16*4^64)` once yields the accepted result and matches the author receipt. Independent lineage and arithmetic took 5.65 s and 7.39 s wall, respectively, using the frozen files.

After confirming the new source and exact replay, the archived (0,0) tuple 1 ledger was checked for scalar equality. None of its 36 scalars equals this result. Twice either of its cases 10 and 11 equals this result as a scalar comparison. The accepted result here is specific to the independently replayed descendant (0,1) case 0.

Run from this directory with Python 3.

```sh
shasum -a 256 -c manifest.sha256
shasum -a 256 -c frozen-inputs.sha256
gzip -dc parent.pkl.gz | shasum -a 256 -c parent-unpacked.sha256
python3 verify-lineage.py
python3 replay.py 0 0 inputs/label-pilot-rescue-reduced-frontier.pkl inputs/contract-rescue.out
python3 compare-prior.py
```
