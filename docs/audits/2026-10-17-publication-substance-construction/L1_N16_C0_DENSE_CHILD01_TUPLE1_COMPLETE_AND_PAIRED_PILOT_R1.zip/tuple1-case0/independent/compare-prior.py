from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from re import M,search
from zipfile import ZipFile

with ZipFile('archived-tuple1.zip') as archive:
    ledger=archive.read('complete-ledger.tsv')
    manifest={name.removeprefix('./'):digest for digest,name in map(str.split,archive.read('manifest.sha256').decode().splitlines())}
    assert sha256(ledger).hexdigest()==manifest['complete-ledger.tsv']
    prior={}
    for line in ledger.decode().splitlines():
        fields=line.split('\t')
        if fields[0]=='term':
            _,i,g,j,products,x,y,_=fields
            assert int(i) not in prior
            prior[int(i)]=((int(g),(int(j),)),(Fraction(x),Fraction(y)))
assert set(prior)==set(range(36))
assert prior[0][0]==(17,(3,))
lineage=Path('verify-lineage.out').read_text()
assert lineage.endswith('PASS terminal checkpoint fully reproduced from pinned case 0 cut\n')
replay=Path('replay.out').read_text()
new=tuple(map(Fraction,search(r'^exact normalized real (\S+) imaginary (\S+) ',replay,M).groups()))
r,i,d=map(int,search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',replay,M).groups())
assert (Fraction(r,d*16*4**64),Fraction(i,d*16*4**64))==new
same=[i for i,(_,v) in sorted(prior.items()) if v==new]
twice=[i for i,(_,v) in sorted(prior.items()) if tuple(2*c for c in v)==new]
assert same==[] and twice==[10,11]
print('PASS archive comparison uses actual new case 0 source and exact replay receipts')
print('same normalized case 0 old',*prior[0][1],'new',*new)
print('equal prior 36-term scalars',same)
print('equal twice prior term',[(i,prior[i][0]) for i in twice],*new)
