from ast import literal_eval
from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
from gzip import decompress
from pickle import loads
from re import search

from exact_factors import DEN, read, groups, overlap, reduce_factors, prune, combine, quotient

author=Path('inputs')
raw=decompress(Path('parent.pkl.gz').read_bytes())
digest=sha256(raw).hexdigest()
assert digest=='ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c'
parent=loads(raw)
assert dict(parent['conditioning'])[('R',0,6,1,1,1)] == 1
assert parent['physical_cut']==(('R',0,6,1,1,1),1)
assert parent['used_before']==0
print('PASS packed parent uncompressed SHA256',digest,flush=True)
assert parent['label_partition']['index'] == 1
factors = parent['factors']
assert len(factors)==6
assert set(Counter(w for axes,_,_ in factors for w in axes).values())=={2}
assert parent['rejected_pair']==(0,1)
li,ri = parent['rejected_pair']
left,right = factors[li],factors[ri]
cut_axes, table=literal_eval((author/'pilot.roster').read_text())
assert cut_axes == (('G',0,0,2),('J',1,4,2))
assert all(w in left[0] for w in cut_axes)
shared=overlap(left[0],right[0])
B=groups(right,shared)
joinpos=tuple(left[0].index(w) for w in shared)
cutpos=tuple(left[0].index(w) for w in cut_axes)
spectrum=Counter()
for row in left[1]:
    multiplicity=len(B.get(tuple(row[j] for j in joinpos),()))
    if multiplicity:
        spectrum[tuple(row[j] for j in cutpos)] += multiplicity
assert len(table)==len(spectrum)==36 and spectrum==dict(table)
assert sum(spectrum.values())==parent['matched']==6838272
assert sorted(spectrum,key=lambda k:(spectrum[k],k))[0]==(17,(3,))
case=(17,(3,))
assert spectrum[case]==142464
print('PASS complete 36-case roster',sum(spectrum.values()),'minimum',min(spectrum.values()),
      'maximum',max(spectrum.values()),'case 0',case,spectrum[case],flush=True)
fixed=dict(zip(cut_axes,case,strict=True))
conditions=parent['conditioning']+list(fixed.items())

def state(name):
    raw=(author/name).read_bytes()
    obj=loads(raw)
    print('checkpoint',name,'SHA256',sha256(raw).hexdigest(),'rows',sum(len(r) for _,r,_ in obj['factors']),flush=True)
    assert obj['conditioning']==conditions and obj['label_partition']==parent['label_partition']
    assert obj['physical_cut']==parent['physical_cut']
    assert prod(d for _,_,d in obj['factors'])==DEN
    return obj

cut=state('pilot.pkl')
for (axes,rows,d),(out,small,e) in zip(factors,cut['factors'],strict=True):
    assert d==e and out==tuple(w for w in axes if w not in fixed)
    recovered={}
    for row,z in small.items():
        lookup=dict(zip(out,row,strict=True)) | fixed
        recovered[tuple(lookup[w] for w in axes)]=z
    expected={row:z for row,z in rows.items() if all(row[i]==fixed[w] for i,w in enumerate(axes) if w in fixed)}
    assert recovered==expected
print('PASS inverse lift preserves every coefficient, axis and denominator',flush=True)

working=list(cut['factors'])
reduce_factors(working)
reduced=state('label-pilot-reduced-frontier.pkl')
assert working==reduced['factors']
prune(working)
prune(working)
combined,count=combine(working[0],working[3])
assert count==34488 and len(combined[1])==20952
working=[f for i,f in enumerate(working) if i not in (0,3)] + [combined]
prune(working,4)
assert quotient(working,0,1)+quotient(working,1,0)==0
cap=state('row-cap-physical-slice-dense-label-pilot-reduced.pkl')
assert cap['used_before']==count and cap['rejected_pair']==(0,1)
assert working==cap['factors']
ap,bp=working[:2]
shared=overlap(ap[0],bp[0])
A,B=groups(ap,shared),groups(bp,shared)
forecast=sum(len(A[k])*len(B[k]) for k in A.keys() & B.keys())
assert forecast==cap['matched']==2657280
assert (author/'contract.out').read_text().splitlines()[-1]=='open row cap 5 2657280 frontier saved'
print('PASS refusal checkpoint exact five-factor tables; retained first join',count,'forecast',forecast,flush=True)
reduce_factors(working)
terminal=state('label-pilot-rescue-reduced-frontier.pkl')
assert terminal['factors']==working
print('PASS terminal checkpoint fully reproduced from pinned case 0 cut',flush=True)
