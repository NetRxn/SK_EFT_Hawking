from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from shutil import copyfile
from subprocess import run, STDOUT
from sys import executable

CASES = (26,27,28,30,31,32,33,34,35)
from time import perf_counter

evidence = Path(__file__).resolve().parent
original = Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple1-remainder')
pinned = evidence / 'LARGER_TUPLE_SEPARATOR'
scripts = ('exact-multicut.py', 'reduce-label-frontier.py',
           'contract-reduced-label.py', 'checkpoint/quotient.py')

def compare(left, right):
    assert left.read_bytes() == right.read_bytes(), (left, right)

def review(index):
    author = original / str(index)
    local = evidence / f'lineage-{index}'
    (local / 'checkpoint').mkdir(parents=True)
    for script in scripts:
        compare(pinned / script, author / script)
        copyfile(pinned / script, local / script)
    stage = int((author/'exact.tsv').read_text().split('\t')[-1])
    commands = (
        ('plan.out', 0, ('pilot.pkl', 'pilot.roster'),
         'exact-multicut.py', str(evidence / 'parent.pkl'), 'pilot.pkl', str(index)),
        ('reduce-0.out', 0, ('label-pilot-0-reduced-frontier.pkl',),
         'reduce-label-frontier.py', 'pilot.pkl', 'pilot-0'),
        ('contract-0.out', 2 if stage else 0, ('row-cap-physical-slice-dense-label-pilot-0-reduced.pkl',) if stage else (),
         'contract-reduced-label.py', 'pilot-0'),
        ('reduce-1.out', 0, ('label-pilot-1-reduced-frontier.pkl',),
         'reduce-label-frontier.py', 'row-cap-physical-slice-dense-label-pilot-0-reduced.pkl', 'pilot-1'),
        ('contract-1.out', 0, (),
         'contract-reduced-label.py', 'pilot-1'),
    )
    for log, expected_rc, outputs, *command in commands[:5 if stage else 3]:
        start = perf_counter()
        with (local / log).open('xb') as output:
            result = run([executable, '-B', '-u', *command], cwd=local,
                         stdout=output, stderr=STDOUT, timeout=180)
        elapsed = perf_counter() - start
        print(index, log, result.returncode, f'{elapsed:.6f}', sep='\t', flush=True)
        assert result.returncode == expected_rc, (index, log)
        for output in outputs + (log,):
            compare(local / output, author / output)

with ThreadPoolExecutor(max_workers=4) as executor:
    list(executor.map(review, CASES))
