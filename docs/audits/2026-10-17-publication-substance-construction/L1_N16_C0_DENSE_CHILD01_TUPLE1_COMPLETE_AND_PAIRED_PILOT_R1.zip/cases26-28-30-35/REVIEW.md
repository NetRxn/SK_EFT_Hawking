# Independent review of group128 descendant (0,1), tuple 1, cases 26–28 and 30–35

All nine signed Gaussian numerators and both normalized components were reproduced. The subtotal is `-2595696236556162803750925/5192296858534827628530496329220096 + 0i`. The raw Gaussian subtotal is `(-110265555167075895601318991795409676120380900526131739328564428800,0)`. The common factor denominator is `40512224221827380280140849737629696`. Each scalar applies the positive external factor `1/(16*4^64)` once.

The publication commit is `c08c92c60c8ece228ff8de4aa64cfeaf363e31c5`. The committed reference sources and their manifest receipts are the ones verified in the preceding cases 1–8 review. The packed parent was rebound to the decompressed SHA-256 `ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c`. Its two representation conditions are `(('R',1,3,0,2,1),0)` and `(('R',0,6,1,1,1),1)`. Tuple 1 is one of six dense-label configurations. The rejected-pair histogram recomputed the full 36-coordinate roster on `(('G',0,0,2),('J',1,4,2))` with 6,838,272 compatible products and an interval of 142,464 to 213,696 products per coordinate. Each reviewed case contains 213,696 products.

The inverse lifts recovered every original selected row, Gaussian coefficient and factor denominator. Independent quotient reconstruction matched the first reduction in all nine cases and the post-refusal reduction in seven cases. It also matched every retained factor table at each cap, including the two completed joins. Case 27 preserved 1,807,956 completed products. Cases 30–35 preserved 3,087,396 completed products each. A separate bounded occupancy scan located the first refused insertion at 500,000 retained rows in every capped case. Cases 26 and 28 closed directly at stage 0. All 41 archived-script stages reproduced logs and checkpoint bytes, including the seven status-2 refusals. The nine cut and terminal inputs have distinct hashes in each checkpoint class. The seven refusal inputs likewise have distinct hashes.

Direct and support-pruned sparse Gaussian arithmetic independently agreed with the author join implementation for every terminal input. The two independent variants selected the same join order in this cohort. They exercised different product counts in cases 27, 31, 33 and 35. Cases 26 and 28 each used 8,134,004 products and peaked at 217,728 retained output rows in the direct replay. The direct replay took 0.5025–7.6048 seconds per case. The support-pruned replay took 0.6463–8.9380 seconds. Timing tables preserve the concurrent wall durations, authors’ stage durations and exact cap insertion counts.

The numerical acceptance in this receipt covers only the nine listed coordinates. The roster check covers all 36 coordinates of this parent. The source inventory binds the author files in `/private/tmp/l1-child01-tuples234.cugnpQ/tuple1-remainder`.

Verify from this directory.

```sh
shasum -a 256 -c review-manifest.sha256
gzip -dc parent.pkl.gz | shasum -a 256 -c parent-unpacked.sha256
python3 -B compare-arithmetic.py
```
