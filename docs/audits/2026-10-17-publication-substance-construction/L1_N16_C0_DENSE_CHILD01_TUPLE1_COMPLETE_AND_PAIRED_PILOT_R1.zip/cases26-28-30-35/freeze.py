from csv import DictReader
from hashlib import sha256
from pathlib import Path
from subprocess import run

root = Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple1-remainder')
cases = (26,27,28,30,31,32,33,34,35)
files = ('pilot.pkl','label-pilot-0-reduced-frontier.pkl','pilot.roster',
         'exact-multicut.py','reduce-label-frontier.py','contract-reduced-label.py','checkpoint/quotient.py',
         'plan.out','reduce-0.out','contract-0.out','exact.tsv','timing.tsv')
caps = ('row-cap-physical-slice-dense-label-pilot-0-reduced.pkl',
        'label-pilot-1-reduced-frontier.pkl','reduce-1.out','contract-1.out')
with Path('author-inputs.sha256').open('w') as out, Path('author-stage-timing.tsv').open('w') as times:
    print('case','script','log','exit_code','wall_seconds',sep='\t',file=times)
    for i in cases:
        for name in files + (caps if i not in (26,28) else ()):
            path = Path(str(i))/name
            print(f'{sha256((root/path).read_bytes()).hexdigest()}  {path}',file=out)
        for line in (root/str(i)/'timing.tsv').read_text().splitlines():
            print(i,line,sep='\t',file=times)
with Path('author-inputs-verify.out').open('w') as out:
    run(['shasum','-a','256','-c',str(Path('author-inputs.sha256').resolve())],cwd=root,stdout=out,check=True)
with Path('cap-occupancy.tsv').open() as cap_file, Path('case-ledger.tsv').open() as ledger_file:
    caps_table = list(DictReader(cap_file,delimiter='\t'))
    ledger = {r['case']:r for r in DictReader(ledger_file,delimiter='\t')}
assert len(caps_table) == 7 and set(ledger) == set(map(str,cases))
for cap in caps_table:
    assert cap['projected_products'] == ledger[cap['case']]['rejected_products']
    assert cap['retained_rows'] == '500000'
    assert int(cap['refused_insertion']) <= int(cap['projected_products'])
timings = [line.split('\t') for line in Path('lineage-timing.tsv').read_text().splitlines()]
assert len(timings) == 41 and sum(row[2]=='2' for row in timings)==7
assert not any(Path(log).read_bytes() for log in ('audit-errors.out','cap-errors.out','lineage-errors.out'))
with Path('arithmetic-timing.tsv').open('w') as output:
    run(['python3','-B','compare-arithmetic.py'],stdout=output,check=True)
