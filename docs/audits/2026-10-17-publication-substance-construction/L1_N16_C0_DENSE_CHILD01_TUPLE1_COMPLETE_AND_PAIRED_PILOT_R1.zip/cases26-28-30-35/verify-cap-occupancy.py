from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from pickle import loads
from time import perf_counter

from exact_factors import add, mul, overlap, proj

ROOT = Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple1-remainder')
CASES = (27,30,31,32,33,34,35)

def run(case):
    start = perf_counter()
    path = ROOT/str(case)/'row-cap-physical-slice-dense-label-pilot-0-reduced.pkl'
    data = loads(path.read_bytes())
    i,j = data['rejected_pair']
    factors = data['factors']
    (a,A,_),(b,B,_) = factors[i],factors[j]
    shared = overlap(a,b)
    la = tuple(w for w in a if w not in shared)
    rb = tuple(w for w in b if w not in shared)
    left_key,right_key = proj(a,shared),proj(b,shared)
    prefix,suffix = proj(a,la),proj(b,rb)
    buckets = defaultdict(list)
    for row,z in B.items():
        buckets[right_key(row)].append((suffix(row),z))
    assert sum(len(buckets[left_key(row)]) for row in A) == data['matched']
    restrictions = []
    for k,(scope,rows,_) in enumerate(factors):
        if k not in (i,j):
            common = overlap(scope,la+rb)
            if common:
                restrictions.append((proj(la+rb,common),set(map(proj(scope,common),rows))))
    out = {}
    seen = 0
    for row,x in A.items():
        head = prefix(row)
        for tail,y in buckets[left_key(row)]:
            seen += 1
            key = head+tail
            if any(p(key) not in support for p,support in restrictions):
                continue
            z = add(out.get(key,(0,0)),mul(x,y))
            if not any(z):
                out.pop(key,None)
            elif key not in out and len(out)==500000:
                return case, i, j, seen, data['matched'], len(out), f'{perf_counter()-start:.6f}'
            else:
                out[key] = z
    raise AssertionError(f'row cap not observed for case {case}')

if __name__ == '__main__':
    print('case','left','right','refused_insertion','projected_products','retained_rows','wall_seconds',sep='\t',flush=True)
    with ProcessPoolExecutor(max_workers=3) as pool:
        for row in pool.map(run,CASES):
            print(*row,sep='\t',flush=True)
