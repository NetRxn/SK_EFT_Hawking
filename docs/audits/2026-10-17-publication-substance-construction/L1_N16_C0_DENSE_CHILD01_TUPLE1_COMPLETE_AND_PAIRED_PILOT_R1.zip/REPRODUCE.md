# Group 128 descendant (0,1) bounded tuple pilots

The two tuple 1 pilots cover the 142,464 and 213,696 diagnosed-product
classes in the 36-entry original cut. The tuple 0 branch 0 pilot covers
a 70,896-product member of its 48-entry original cut. Each record keeps
the original sign and both complex components, with no additional
normalization. Independent review derived the exact terminal scalar and
checked each distinct source, support/roster, inverse lift and saved cap.

The independent evidence directories include the original manifests and
reviewed text outputs. Large prior archives are available at the recorded
Git pins and are not duplicated. Reconstruct the local parent and restart
files with the pinned source recipe and match their SHA256 before running
the author's and reviewer's exact contractions. Use only trusted
reconstructed checkpoint inputs.

The two tuple 1 scalars are not the corresponding (0,0) results. For
tuple 0, the same least-cost coordinate also has a different signed scalar
from the already accepted (0,0) input. Any future reuse needs a proven
original factor identity.

The paired tuple 0 pilot independently verifies the initial signed sum of
both contracted pair tensors and the final combined scalar. The six
unchanged factors form a shared environment. This is an exact use of
linearity at one coordinate. Retain either a signed result or an exact
zero receipt for every coordinate before recombination. Full combined
intermediate byte replay and the remaining 47 coordinates are outside
this checkpoint.

The reviewer cohorts cover cases 1–8, 9–16, 17–25 and 26–28 plus 30–35. Run
python3 complete-retally.py and compare against tuple1-complete.tsv.
The completed ledger has one separately verified contribution for each
of 36 cut coordinates. The complete normalized value agrees with
descendant (0,0) tuple 1. Several coordinates have different scalar
values. The aggregate equality requires this complete evidence.
