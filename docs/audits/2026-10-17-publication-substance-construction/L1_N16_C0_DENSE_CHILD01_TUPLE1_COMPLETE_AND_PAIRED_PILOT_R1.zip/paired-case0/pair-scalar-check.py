from fractions import Fraction
from pathlib import Path
import re

pattern=r'^exact normalized real (\S+) imaginary (\S+)'
raw_pattern=r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$'
entries=[]
for filename in ('independent-replay.out','paired-reference-branch1-replay.out','paired-combined-replay.out'):
    log=Path(filename).read_text()
    scalar=tuple(map(Fraction,re.search(pattern,log,re.M).groups()))
    real,imag,denominator=map(int,re.search(raw_pattern,log,re.M).groups())
    assert denominator==40512224221827380280140849737629696
    assert scalar==tuple(Fraction(n,denominator*16*4**64) for n in (real,imag))
    entries.append((scalar,(real,imag)))
for key,((real,imag),raw) in zip(('branch 0','branch 1','combined'),entries,strict=True):
    print(key,'raw numerator',*raw,'normalized',real,imag)
assert all(tuple(x+y for x,y in zip(entries[0][i],entries[1][i],strict=True))==entries[2][i] for i in (0,1))
print('PASS combined independent scalar equals exact sum of distinct binary inputs')
