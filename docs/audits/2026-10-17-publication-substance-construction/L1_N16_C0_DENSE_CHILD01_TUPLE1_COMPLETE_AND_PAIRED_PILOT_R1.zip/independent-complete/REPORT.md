# Independent recombination of descendant (0,1), tuple 1

The complete signed contribution of this tuple is `-940520760199586648427969/649037107316853453566312041152512 + 0i`. The retally includes 36 independently accepted cuts of the six-factor source with uncompressed SHA-256 `ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c`. The source carries representation conditions `(('R',1,3,0,2,1),0)` and `(('R',0,6,1,1,1),1)`, followed by dense-label tuple 1. The prior (0,0) separator child at SHA-256 `843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077` has a different physical selector and four different factor tables. The recombination uses the reviewed operands and scalars from (0,1).

The rejected pair is (0,1). Both cut axes `(('G',0,0,2),('J',1,4,2))` occur in factor 0, with their second incidences in factors 5 and 2. The support of their joint projection from factor 0 equals the support of the compatible-pair histogram. Every nonzero assignment of the parent has a unique joint value in that projection and therefore appears in exactly one restricted contraction. The inverse-lift reviews cover all 36 restrictions and preserve the incident axes, keys, Gaussian coefficients and denominators. The histogram has 12 coordinates with 142,464 compatible products and 24 with 213,696, totaling 6,838,272. The ordered ledger includes each coordinate once, with distinct original cut and terminal input hashes. Compatible-pair counts measure work and carry no arithmetic weight.

The six acceptance packages and their input inventories were rechecked before selecting the portable receipts. The retally binds every copied receipt, cut hash and terminal input hash back to those manifests, checks each receipt's full conditioning, and agrees with all author terminal values. Four cases completed on the initial contraction and 32 completed after a retained refusal and restart. The signed replays are reviewed evidence from those packages. The standalone script rechecks their support and provenance and recomputes the sum.

The Gaussian numerator sums to `(-319627673867296243965201712456722914181220661712756367361983905792,0)` over common factor denominator `40512224221827380280140849737629696`. The fixed physical mode records independently give total occupation 32, factorial contribution 16, and even sign exponent 136 + 444. Their external factor is therefore positive `1/(16*4^64)` for every coordinate. The cut partitions an existing sum, so each cut has multiplicity one. The raw sum normalized once equals the sum of the 36 individually normalized fractions, with no extra multiplicity or normalization. This value closes the requested tuple term of the (0,1) descendant.

The archived separator at publication checkpoint `c08c92c60c8ece228ff8de4aa64cfeaf363e31c5` has Git blob ID `02e33786d0bcd46e2314ad7fec1453595adcc815`. The parent, selected receipts, their source inventories, script and ordered ledger are covered by the relative manifest. The verification and retally ran in 0.60 seconds wall on the frozen files.

Run from this directory with Python 3.10 or newer.

```sh
shasum -a 256 -c manifest.sha256
gzip -dc parent.pkl.gz | shasum -a 256 -c parent-unpacked.sha256
python3 retally.py | cmp - complete-ledger.tsv
```
