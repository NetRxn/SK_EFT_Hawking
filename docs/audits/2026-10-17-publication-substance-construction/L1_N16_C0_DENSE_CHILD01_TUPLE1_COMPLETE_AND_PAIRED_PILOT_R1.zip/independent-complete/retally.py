from ast import literal_eval
from collections import Counter
from csv import DictReader
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from itertools import combinations, product
from math import factorial, prod
from pathlib import Path
from pickle import loads
from re import M, escape, findall, fullmatch, search
from zipfile import ZipFile
import sys

root=Path('.')
parent_sha='ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c'
packed=decompress((root/'parent.pkl.gz').read_bytes())
assert sha256(packed).hexdigest()==parent_sha
parent=loads(packed)
factors=parent['factors']
assert len(factors)==6 and parent['used_before']==0
representation=[(('R',1,3,0,2,1),0),(('R',0,6,1,1,1),1)]
assert parent['physical_cut']==representation[-1]
assert parent['conditioning'][:2]==representation
assert dict(parent['conditioning'][2:])==parent['label_partition']['values']
assert (parent['label_partition']['index'],parent['label_partition']['count'])==(1,6)
assert all(n==2 for n in Counter(axis for scope,_,_ in factors for axis in scope).values())
den=prod(d for _,_,d in factors)
assert den==40512224221827380280140849737629696

old_member='row-cap-physical-slice-dense-label-tuple1-0b-reduced.pkl'
with ZipFile('archived-separator.zip') as archive:
    archived=decompress(archive.read(old_member+'.gz'))
    old_hashes={name.removeprefix('./'):digest for digest,name in
                map(str.split,archive.read('frontiers-uncompressed.sha256').decode().splitlines())}
    old_sha=sha256(archived).hexdigest()
    assert old_sha==old_hashes[old_member] and old_sha!=parent_sha
old=loads(archived)
assert old['physical_cut']==(representation[-1][0],0)
differences=tuple(i for i,(a,b) in enumerate(zip(factors,old['factors'],strict=True)) if a!=b)
assert differences==(0,1,3,5)

cut_axes,roster=literal_eval((root/'pilot.roster').read_text())
assert parent['rejected_pair']==(0,1)
assert cut_axes==(('G',0,0,2),('J',1,4,2))
assert [[i for i,(scope,_,_) in enumerate(factors) if w in scope] for w in cut_axes]==[[0,5],[0,2]]
assert set(cut_axes).isdisjoint(dict(parent['conditioning']))
left, right = factors[:2]
common=tuple(w for w in left[0] if w in right[0])
def project(scope,axes):
    positions=tuple(scope.index(w) for w in axes)
    return lambda row: tuple(row[i] for i in positions)
join_left=project(left[0],common)
join_right=project(right[0],common)
select=project(left[0],cut_axes)
right_counts=Counter(map(join_right,right[1]))
counts=Counter()
for row in left[1]:
    n=right_counts[join_left(row)]
    if n:
        counts[select(row)]+=n
assert counts==dict(roster) and len(roster)==len(counts)==36
assert sum(counts.values())==parent['matched']==6838272
assert set(map(select,left[1]))==counts.keys()
assert Counter(counts.values())=={142464:12,213696:24}
order=sorted(counts,key=lambda key:(counts[key],key))

# Recompute the external sign and factorial normalization from the fixed
# occupation records and cube edges. Neither conditioning coordinate is used.
orbit_rows=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occupation=[]
for record in (503841882182,1461451755920):
    vertices=[]
    for vertex in range(8):
        record,digit=divmod(record,64)
        vertices.append(orbit_rows[digit])
    assert record==0
    occupation.append(vertices)
edges=[(u,v,(u^v).bit_length()-1) for u,v in combinations(range(8),2) if (u^v).bit_count()==1]
edges.sort(key=lambda edge:(edge[0],edge[2]))
total=sum(sum(row) for spin in occupation for row in spin)
factorials=prod(factorial(n) for spin in occupation for row in spin for n in row)
signed_world=sum((axis+3)*n for spin in occupation for row in spin for axis,n in enumerate(row))
cross=0
for spin in occupation:
    words=[]
    for u,v,k in edges:
        words.append((u,v,sum(spin[u])+sum(spin[v])-spin[u][k]-spin[v][k]))
    cross+=sum(m*n*sum(int(a>b) for a in (u,v) for b in (x,y))
               for (u,v,m),(x,y,n) in combinations(words,2))
phase=(-1)**((signed_world+cross)%2)
assert (total,factorials,phase)==(32,16,1)
external=Fraction(phase,factorials*4**(2*total))
assert external==Fraction(1,16*4**64)

def check_table(inventory):
    manifest=root/'receipts'/inventory['cohort']/inventory['verified_primary_manifest']
    assert sha256(manifest.read_bytes()).hexdigest()==inventory['primary_manifest_sha256']
    source=root/'receipts'/inventory['cohort']/inventory['verified_input_manifest']
    assert sha256(source.read_bytes()).hexdigest()==inventory['input_manifest_sha256']
    original={}
    for checked in (manifest,source):
        for record in checked.read_text().splitlines():
            digest,name=record.split(maxsplit=1)
            assert name not in original or original[name]==digest
            original[name]=digest
    def check_copy(file,source_name):
        assert sha256(file.read_bytes()).hexdigest()==original[source_name]
    report=root/'receipts'/inventory['cohort']
    if inventory['type']=='ledger':
        check_copy(report/'case-ledger.tsv','case-ledger.tsv')
        with (report/'case-ledger.tsv').open() as file:
            source_rows={int(row['case']):row for row in DictReader(file,delimiter='\t')}
    else:
        source_rows={}
    selected=set()
    for folder in (p for p in report.iterdir() if p.is_dir()):
        index=int(folder.name)
        selected.add(index)
        coordinate=order[index]
        count=counts[coordinate]
        line=(folder/'plan.out').read_text().splitlines()[-1]
        assert fullmatch(fr'pilot {escape(repr(coordinate))} matched {count} stored rows \d+',line)
        receipt=(folder/'replay.out').read_text()
        raw_r,raw_i,factor_denominator=map(int,search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',receipt,M).groups())
        assert factor_denominator==den
        normalized=tuple(Fraction(n,den)*external for n in (raw_r,raw_i))
        replay_r,replay_i,replay_work=search(r'^exact normalized real (\S+) imaginary (\S+) independent matched products (\d+) ',receipt,M).groups()
        assert normalized==tuple(map(Fraction,(replay_r,replay_i)))
        selected_conditions, label=search(r'^conditioning (.*) label partition (.*)$',receipt,M).groups()
        assert literal_eval(selected_conditions)==parent['conditioning']+list(zip(cut_axes,coordinate,strict=True))
        assert literal_eval(label)==parent['label_partition']
        terminal=(folder/'terminal.out').read_text()
        author_r,author_i=search(r'^exact normalized real (\S+) imaginary (\S+) ',terminal,M).groups()
        assert normalized==tuple(map(Fraction,(author_r,author_i)))
        if inventory['type']=='pilot':
            stage=1
        else:
            a,c,n,x,y,s=(folder/'exact.tsv').read_text().strip().split('\t')
            stage=int(s)
            assert int(a)==index and literal_eval(c)==coordinate and int(n)==count
            assert normalized==(Fraction(x),Fraction(y))
        if index in source_rows:
            row=source_rows[index]
            assert (literal_eval(row['coordinate']),int(row['pair_products']))==(coordinate,count)
            assert tuple(map(Fraction,(row['normalized_real'],row['normalized_imaginary'])))==normalized
            assert tuple(map(int,(row['raw_real'],row['raw_imaginary'])))==(raw_r,raw_i)
            cut_hash,terminal_hash=row['cut_sha256'],row['terminal_sha256']
        else:
            lineage=(folder/'lineage.out').read_text()
            assert 'PASS inverse lift' in lineage and 'PASS terminal checkpoint fully reproduced' in lineage
            assert parent_sha in lineage
            cut_hash=search(r'^checkpoint pilot\.pkl SHA256 ([a-f0-9]{64}) ',lineage,M)[1]
            terminal_name=('label-pilot-rescue-reduced-frontier.pkl' if inventory['type']=='pilot'
                           else f'label-pilot-{stage}-reduced-frontier.pkl')
            terminal_hash=next(h for name,h in findall(r'^checkpoint (\S+) SHA256 ([a-f0-9]{64}) ',lineage,M) if name==terminal_name)
        match inventory['type']:
            case 'ledger':
                anchor=f'author-receipts/{index}'
                inputs=f'{index}'
                check_copy(folder/'replay.out',f'case-{index}-sparse.out')
            case 'batch':
                anchor=inputs=f'inputs/{index}'
                check_copy(folder/'replay.out',f'reviews/{index}/replay.out')
                check_copy(folder/'lineage.out',f'reviews/{index}/lineage.out')
            case 'pilot':
                anchor=inputs='inputs'
                check_copy(folder/'replay.out','replay.out')
                check_copy(folder/'lineage.out','verify-lineage.out')
            case _:
                raise AssertionError(inventory['type'])
        check_copy(folder/'plan.out',f'{anchor}/plan.out')
        assert original[f'{inputs}/pilot.pkl']==cut_hash
        if inventory['type']=='pilot':
            check_copy(folder/'terminal.out',f'{anchor}/contract-rescue.out')
            assert original[f'{inputs}/label-pilot-rescue-reduced-frontier.pkl']==terminal_hash
        else:
            check_copy(folder/'exact.tsv',f'{anchor}/exact.tsv')
            check_copy(folder/'terminal.out',f'{anchor}/contract-{stage}.out')
            assert original[f'{inputs}/label-pilot-{stage}-reduced-frontier.pkl']==terminal_hash
        yield index,coordinate,count,stage,cut_hash,terminal_hash,raw_r,raw_i,*normalized,int(replay_work),inventory['cohort']
    assert not source_rows or selected==source_rows.keys()

with (root/'review-inventories.tsv').open() as file:
    rows=sorted(row for source in DictReader(file,delimiter='\t') for row in check_table(source))
assert [r[0] for r in rows]==list(range(36))
assert [r[1] for r in rows]==order
assert len({r[4] for r in rows})==len({r[5] for r in rows})==36
assert Counter(r[3] for r in rows)=={0:4,1:32}
assert sum(r[2] for r in rows)==sum(counts.values())
raw=tuple(sum(r[p] for r in rows) for p in (6,7))
normalized=tuple(sum(r[p] for r in rows) for p in (8,9))
assert normalized==tuple(Fraction(n,den)*external for n in raw)

print('case\tcoordinate\tcut_products\tstage\tcut_sha256\tterminal_sha256\traw_real\traw_imag\tnormalized_real\tnormalized_imag\treplay_products\treview')
for row in rows:
    print(*row,sep='\t')
print('total\t-\t'+str(sum(counts.values()))+'\t-\t-\t-',*raw,*normalized,sum(r[10] for r in rows),'-',sep='\t')
print(f'parent {parent_sha}\nold separator child {old_sha}\ndistinct factor tables {differences}',file=sys.stderr)
print(f'support {len(order)} disjoint coordinates {sum(counts.values())} compatible products frequency {dict(Counter(counts.values()))}',file=sys.stderr)
print(f'normalization total occupation {total} factorials {factorials} world {signed_world} cross {cross} phase {phase} factor denominator {den}',file=sys.stderr)
print(f'raw subtotal {raw[0]} {raw[1]}\nexact normalized subtotal {normalized[0]} {normalized[1]}',file=sys.stderr)
