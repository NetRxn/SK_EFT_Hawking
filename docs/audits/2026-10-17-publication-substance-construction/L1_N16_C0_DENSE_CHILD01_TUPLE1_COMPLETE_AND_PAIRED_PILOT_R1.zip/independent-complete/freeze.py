from hashlib import sha256
from pathlib import Path
from shutil import copyfile

ROOT=Path('/private/tmp')
PREFIX='l1-child01-tuple1-'
COHORTS=[
    ('case0-independent.EX5AzP','pilot',[0]),
    ('cases1-8-independent.r8ShI8','ledger',range(1,9)),
    ('cases9-16-independent.4KzT7O','batch',range(9,17)),
    ('cases17-25-independent.jLbGiv','batch',range(17,26)),
    ('cases26-28-30-35-independent.VujZm0','ledger',[26,27,28,30,31,32,33,34,35]),
    ('case29-independent.tBq9U7','pilot',[29]),
]

def digest(path):
    with path.open('rb') as file:
        return sha256(file.read()).hexdigest()

def inventory(root, name):
    path=root/name
    rows={}
    for line in path.read_text().splitlines():
        expected,relative=line.split(maxsplit=1)
        assert relative not in rows and digest(root/relative)==expected, str(root/relative)
        rows[relative]=expected
    return rows

print('cohort\ttype\tverified_primary_manifest\tprimary_manifest_sha256\tentries\tverified_input_manifest\tinput_manifest_sha256\tentries')
for cohort,kind,indices in COHORTS:
    root=ROOT/(PREFIX+cohort)
    source=Path('receipts')/cohort
    source.mkdir(parents=True,exist_ok=True)
    main='review-manifest.sha256' if kind=='ledger' else 'manifest.sha256'
    support='author-inputs.sha256' if kind=='ledger' else 'frozen-inputs.sha256'
    primary=inventory(root,main)
    support_root=ROOT/'l1-child01-tuples234.cugnpQ/tuple1-remainder' if kind=='ledger' else root
    if kind=='ledger':
        rows={relative:expected for expected,relative in
              (line.split(maxsplit=1) for line in (root/support).read_text().splitlines())}
        assert digest(root/support)==primary[support]
        for relative,expected in rows.items():
            assert digest(support_root/relative)==expected, relative
        secondary=rows
    else:
        secondary=inventory(root,support)
    if cohort.startswith('cases26'):
        assert digest(root/main)=='71c500f08b487584350fe0e871d3241d544faa5aa2a93c14bf2e3df30da24792'
    assert digest(Path('parent.pkl.gz'))==(primary|secondary)['parent.pkl.gz']
    copyfile(root/main,source/main)
    copyfile(root/support,source/support)
    print(cohort,kind,main,digest(root/main),len(primary),support,digest(root/support),len(secondary),sep='\t')
    pins=primary|secondary
    def pinned(origin,target):
        assert digest(root/origin)==pins[origin], origin
        copyfile(root/origin,target)
    if kind=='ledger':
        pinned('case-ledger.tsv',source/'case-ledger.tsv')
    for index in indices:
        out=source/str(index)
        out.mkdir(exist_ok=True)
        if kind=='pilot':
            pinned('verify-lineage.out',out/'lineage.out')
            pinned('replay.out',out/'replay.out')
            pinned('inputs/plan.out',out/'plan.out')
            pinned('inputs/contract-rescue.out',out/'terminal.out')
        else:
            receipts=f'author-receipts/{index}' if kind=='ledger' else f'inputs/{index}'
            pinned(f'{receipts}/exact.tsv',out/'exact.tsv')
            pinned(f'{receipts}/plan.out',out/'plan.out')
            stage=(out/'exact.tsv').read_text().strip().split('\t')[-1]
            pinned(f'{receipts}/contract-{stage}.out',out/'terminal.out')
            if kind=='ledger':
                pinned(f'case-{index}-sparse.out',out/'replay.out')
            else:
                pinned(f'reviews/{index}/lineage.out',out/'lineage.out')
                pinned(f'reviews/{index}/replay.out',out/'replay.out')
