from ast import literal_eval
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from re import M, search

numbers=range(9,17)
print('case\tcoordinate\tcut_products\tterminal_sha256\tvalue_real\tvalue_imag\tcap_products\tcap_stop\treplay_products\tauthor_seconds\tlineage_seconds\tcap_seconds\treplay_seconds')
summed=[Fraction(0),Fraction(0)]
coordinates=set()
terminals=set()
for number in numbers:
    inputs=Path('inputs')/str(number)
    review=Path('reviews')/str(number)
    case,coordinate,cut_products,real,imag,stage=(inputs/'exact.tsv').read_text().strip().split('\t')
    coordinate=literal_eval(coordinate)
    assert int(case)==number and coordinate not in coordinates
    coordinates.add(coordinate)
    terminal=inputs/f'label-pilot-{stage}-reduced-frontier.pkl'
    digest=sha256(terminal.read_bytes()).hexdigest()
    assert digest not in terminals
    terminals.add(digest)
    lineage=(review/'lineage.out').read_text()
    assert (f'checkpoint {terminal.name} SHA256 {digest} rows ' in lineage
            and f'PASS terminal checkpoint fully reproduced from pinned cut {case} stage {stage}' in lineage)
    assert f'case {case} {coordinate!r} {cut_products}' in lineage
    raw=(review/'replay.out').read_text()
    r,i,d=map(int,search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',raw,M).groups())
    nr,ni,products=search(r'^exact normalized real (\S+) imaginary (\S+) independent matched products (\d+) ',raw,M).groups()
    expected=tuple(map(Fraction,(real,imag)))
    assert expected==(Fraction(nr),Fraction(ni))==(Fraction(r,d*16*4**64),Fraction(i,d*16*4**64))
    refused,forecast=map(int,search(r'^PASS refused insertion (\d+) of (\d+) products at retained rows 500000 rejected pair ',(review/'cap.out').read_text(),M).groups())
    assert f'forecast {forecast}\n' in lineage and 0<refused<=forecast
    author=sum(float(line.split('\t')[-1]) for line in (inputs/'timing.tsv').read_text().splitlines())
    times=[(review/f'{phase}.time').read_text().splitlines()[0].split()[1] for phase in ('lineage','cap','replay')]
    print(case,coordinate,cut_products,digest,real,imag,forecast,refused,products,f'{author:.6f}',*times,sep='\t')
    summed=[acc+term for acc,term in zip(summed,expected,strict=True)]
print('subtotal',*summed,sep='\t')
