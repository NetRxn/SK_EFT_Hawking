# Independent exact review of descendant (0,1), tuple 1, cases 9–16

This cohort covers eight of the 36 terms for physical selector 1 and dense-label tuple 1. The exact term results, subtotal, matched product counts and timings are in `summary.tsv`. The per-case timings are wall-clock measurements during the live batch and independent review.

The separator archive has Git blob ID `02e33786d0bcd46e2314ad7fec1453595adcc815` at publication checkpoint `c08c92c60c8ece228ff8de4aa64cfeaf363e31c5`. Each case's four numerical sources byte-match that archive. The packed six-factor source decompresses to SHA-256 `ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c`, the candidate previously reproduced from the accepted descendant. The independent exact kernel matched the common complete 36-coordinate roster for rejected pair (0,1), including counts from 142,464 to 213,696 and a total of 6,838,272.

Each selected cut was inverse-lifted and checked against the distinct original conditioned factors, including their coefficients and denominators. The review reproduced each reduction, the retained joins, each exact refusal snapshot and the rescued restart. A separate bounded pass directly witnessed the refusal threshold of 500,000 retained rows for each case. All eight terms then matched the author receipts through ordinary sparse joins with signed Gaussian-integer arithmetic and a single positive factor of `1/(16*4^64)` applied to each raw rational result. The summary binds each term to its distinct independently reconstructed terminal checkpoint.

Verify from this directory using the relative manifests and the frozen inputs.

```sh
shasum -a 256 -c manifest.sha256
shasum -a 256 -c frozen-inputs.sha256
gzip -dc parent.pkl.gz | shasum -a 256 -c parent-unpacked.sha256
python3 summarize.py
for i in 9 10 11 12 13 14 15 16; do
    stage=$(cut -f6 "inputs/$i/exact.tsv")
    python3 verify-lineage.py "$i"
    python3 verify-cap.py "inputs/$i/row-cap-physical-slice-dense-label-pilot-0-reduced.pkl"
    python3 replay.py "$i" "$stage" "inputs/$i/label-pilot-$stage-reduced-frontier.pkl" "inputs/$i/contract-$stage.out"
done
```
