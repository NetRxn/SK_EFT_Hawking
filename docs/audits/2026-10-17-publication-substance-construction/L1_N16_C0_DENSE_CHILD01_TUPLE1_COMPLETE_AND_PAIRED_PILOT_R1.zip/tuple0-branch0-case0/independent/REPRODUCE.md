# Reproduce the exact branch-0 pilot review

Use the Git archive pins in SOURCE_PINS.txt and the source and operand checksums recorded separately. The larger tuple separator archive supplies the original comparison roster and the three lineage scripts plus checkpoint/quotient.py. The first-child close archive supplies the earlier independent result and its whole roster. Extract the existing archived sources in fresh scratch. Keep the source archive named first-child.zip for audit.py.

The commands use the original author operand tree and prior separator extraction paths. Substitute their verified restored locations in scratch copies of lineage.sh and audit.py when operating on another host. Run bash lineage.sh from an empty review output location to reproduce the two caps and exact byte lineage. Run the independent terminal replay via:

    python3 -u sparse-replay.py 0 terminal "$author/label-pilot-second-reduced-frontier.pkl" "$author/contract-second.out" > independent-replay.out

Run python3 audit.py to reproduce the pilot inverse lift, signed numerator check, and coordinate-pinned prior comparison. Copies of all author text receipts are under author-receipts/. review-manifest.sha256 covers the relative evidence files, and frozen-operands.sha256 covers the factor table operands.
