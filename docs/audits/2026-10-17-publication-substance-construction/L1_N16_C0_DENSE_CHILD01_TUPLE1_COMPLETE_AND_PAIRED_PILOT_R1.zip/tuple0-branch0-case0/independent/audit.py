from ast import literal_eval
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads
import re
from zipfile import ZipFile

root=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-branch0-pilot')
parent=author.parent/'row-cap-physical-slice-dense-label-tuple0-branch-0-reduced.pkl'
prior=Path('/private/tmp/l1-comp47-independent.rZbJ4i/archive')
roster_digest='d3fec9217155aef752948ad614112f898c7283f747bbd699cea8886d2e465c98'
parent_digest='c5795431732ddb5ba8636d4ac5ee0401298439e8d6fcaa6f255e6e2bdfeee304'
pilot_digest='e423492cf4c0f49621a29a3bf33f8d5fa97efe0982b516b949f7115747942f05'
factor_denominator=40512224221827380280140849737629696
selector_used=('R',0,6,1,1,1)
branch_used=('R',0,0,2,0,1)

def load(path, pin=None):
    raw=path.read_bytes()
    if pin:
        assert sha256(raw).hexdigest()==pin,path
    return loads(raw)

state=load(parent,parent_digest)
assert dict(state['conditioning'])[selector_used]==1 and dict(state['conditioning'])[branch_used]==0
assert len(state['factors'])==8
assert set(Counter(k for a,_,_ in state['factors'] for k in a).values())=={2}
l,r=(state['factors'][i] for i in state['rejected_pair'])
axes_bytes=(author/'pilot.roster').read_bytes()
assert sha256(axes_bytes).hexdigest()==roster_digest
axes,entries=literal_eval(axes_bytes.decode())
assert len(entries)==len(dict(entries))==48
shared=tuple(sorted(set(l[0])&set(r[0])))
left=tuple(l[0].index(k) for k in shared)
right=tuple(r[0].index(k) for k in shared)
fixed_indices=tuple(l[0].index(k) for k in axes)
buckets=Counter(tuple(row[i] for i in right) for row in r[1])
observed=Counter()
for row in l[1]:
    count=buckets[tuple(row[i] for i in left)]
    if count:
        observed[tuple(row[i] for i in fixed_indices)]+=count
assert observed==dict(entries) and sum(observed.values())==state['matched']==6427904
coord=min(observed,key=lambda k:(observed[k],k))
assert coord==(18,(3,)) and observed[coord]==70896
print('PASS distinct selector-1 branch0 parent, 48 cut coordinates, 6427904 pair products, selected',coord)
cut=dict(zip(axes,coord,strict=True))
pilot=load(author/'pilot.pkl',pilot_digest)
assert pilot['conditioning']==state['conditioning']+list(cut.items())
assert pilot['label_partition']==state['label_partition']
for (a,t,d),(b,u,e) in zip(state['factors'],pilot['factors'],strict=True):
    assert d==e and b==tuple(k for k in a if k not in cut)
    actual={}
    for row,g in u.items():
        assignment=dict(zip(b,row,strict=True))
        assignment.update(cut)
        actual[tuple(assignment[k] for k in a)]=g
    expected={row:g for row,g in t.items() if all(row[j]==cut[k] for j,k in enumerate(a) if k in cut)}
    assert expected==actual
assert sum(len(t) for _,t,_ in pilot['factors'])==398724
print('PASS exact inverse lift and live signed table correspondence',pilot_digest)
frontiers=['label-pilot-reduced-frontier.pkl','row-cap-physical-slice-dense-label-pilot-reduced.pkl',
           'label-pilot-rescue-reduced-frontier.pkl','join-cap-dense-label-pilot-rescue-reduced.pkl',
           'label-pilot-second-reduced-frontier.pkl']
for name,expected_n in zip(frontiers,(8,5,5,4,4),strict=True):
    raw=(author/name).read_bytes()
    stage=loads(raw)
    f=stage['factors']
    assert len(f)==expected_n
    assert all(stage[key]==pilot[key] for key in ('conditioning','label_partition'))
    assert prod(d for _,_,d in f)==factor_denominator
    assert set(Counter(k for a,_,_ in f for k in a).values())=={2}
    assert all(d>0 and len(a)==len(set(a)) and all(len(row)==len(a) and len(g)==2 and any(g) and all(type(x) is int for x in g)
                                               for row,g in t.items()) for a,t,d in f)
    print('PASS saved stage',name,sha256(raw).hexdigest(),expected_n,sum(len(t) for _,t,_ in f))

signature=r'^exact normalized real (\S+) imaginary (\S+)'
receipt=(root/'independent-replay.out').read_text()
exact=tuple(map(Fraction,re.search(signature,receipt,re.M).groups()))
assert exact==tuple(map(Fraction,re.search(signature,(author/'contract-second.out').read_text(),re.M).groups()))
raw_re,raw_im,d=map(int,re.search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',receipt,re.M).groups())
assert d==factor_denominator and tuple(Fraction(x,d*16*4**64) for x in (raw_re,raw_im))==exact
assert f"conditioning {pilot['conditioning']} label partition {pilot['label_partition']}" in receipt
print('PASS exact signed pilot',*exact,'raw',raw_re,raw_im)

with ZipFile(root/'first-child.zip') as archive:
    manifest={n.removeprefix('./'):d for d,n in (line.split() for line in archive.read('manifest.sha256').decode().splitlines())}
    def verified(name):
        data=archive.read(name)
        assert sha256(data).hexdigest()==manifest[name]
        return data
    old_roster=verified('independent-retally/pilot.roster')
    assert old_roster==(prior/'pilot.roster').read_bytes()
    a,r=literal_eval(old_roster.decode())
    assert a==axes
    weights=dict(r)
    i=sorted(weights,key=lambda c:(weights[c],c)).index(coord)
    assert i==0 and weights[coord]==observed[coord]
    old_ledger=[line.split('\t') for line in verified('independent-retally/partial-48.tsv').decode().splitlines()]
    j,description,real,imag,*_=old_ledger[i]
    assert int(j)==i and literal_eval(description)==coord
    previous=Fraction(real),Fraction(imag)
    assert exact!=previous
    print('PASS coordinate-pinned old value differs',coord, 'old',*previous,
          'new',*exact,'new minus old',exact[0]-previous[0],exact[1]-previous[1])
