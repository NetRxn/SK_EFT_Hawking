#!/usr/bin/env bash
set -euo pipefail
q=$PWD
a=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-branch0-pilot
p=/private/tmp/l1-child01-tuples234.cugnpQ/row-cap-physical-slice-dense-label-tuple0-branch-0-reduced.pkl
ref=/private/tmp/l1-comp47-independent.rZbJ4i/archive
mkdir -p lineage/checkpoint
for f in exact-multicut.py reduce-label-frontier.py contract-reduced-label.py checkpoint/quotient.py; do
  cmp "$ref/$f" "$a/$f"
  cp "$ref/$f" "lineage/$f"
done
cd lineage
printf 'stage\tseconds\n' > "$q/lineage-timing.tsv"
timed() {
  local stage=$1
  shift
  local TIMEFORMAT="$stage"$'\t%3R'
  { time "$@"; } 2>> "$q/lineage-timing.tsv"
}
timed cut python3 -u exact-multicut.py "$p" pilot.pkl 0 > plan.out
for f in pilot.pkl pilot.roster plan.out; do cmp "$f" "$a/$f"; done
printf 'PASS cut plan, roster and operand bytes\n'
timed initial-reduce python3 -u reduce-label-frontier.py pilot.pkl pilot > reduce.out
ret=0
timed initial-contract python3 -u contract-reduced-label.py pilot > contract.out || ret=$?
test "$ret" = 2
first=row-cap-physical-slice-dense-label-pilot-reduced.pkl
for f in reduce.out contract.out label-pilot-reduced-frontier.pkl "$first"; do cmp "$f" "$a/$f"; done
printf 'PASS initial reduction and row-cap bytes\n'
timed rescue-reduce python3 -u reduce-label-frontier.py "$first" pilot-rescue > reduce-rescue.out
ret=0
timed rescue-contract python3 -u contract-reduced-label.py pilot-rescue > contract-rescue.out || ret=$?
test "$ret" = 2
second=join-cap-dense-label-pilot-rescue-reduced.pkl
for f in reduce-rescue.out contract-rescue.out label-pilot-rescue-reduced-frontier.pkl "$second"; do cmp "$f" "$a/$f"; done
printf 'PASS rescue reduction and join-cap bytes\n'
timed second-reduce python3 -u reduce-label-frontier.py "$second" pilot-second > reduce-second.out
timed second-contract python3 -u contract-reduced-label.py pilot-second > contract-second.out
for f in reduce-second.out contract-second.out label-pilot-second-reduced-frontier.pkl; do cmp "$f" "$a/$f"; done
printf 'PASS second reduction and exact terminal bytes\n'
