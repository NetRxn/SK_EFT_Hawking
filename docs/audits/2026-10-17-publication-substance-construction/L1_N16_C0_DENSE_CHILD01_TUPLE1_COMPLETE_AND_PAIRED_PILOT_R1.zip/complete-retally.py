from ast import literal_eval
from csv import DictReader
from fractions import Fraction
from pathlib import Path
import re
import sys

roster_path=Path('tuple1.roster')
axes,roster=literal_eval(roster_path.read_text())
assert len(roster)==36 and sum(count for _,count in roster)==6_838_272
ordered=sorted(roster,key=lambda row:(row[1],row[0]))
values={}
def add(case,a,b):
    v=Fraction(a),Fraction(b)
    assert case not in values
    values[case]=v

for source, product_field, real_field, imag_field in (
    ('cases1-8/case-ledger.tsv','pair_products','normalized_real','normalized_imaginary'),
    ('cases9-16/summary.tsv','cut_products','value_real','value_imag'),
    ('cases17-25/summary.tsv','cut_products','value_real','value_imag'),
    ('cases26-28-30-35/case-ledger.tsv','pair_products','normalized_real','normalized_imaginary'),
):
    with Path(source).open() as f:
        for record in DictReader(f, delimiter='\t'):
            if record['case'].isdigit():
                case=int(record['case'])
                assert (literal_eval(record['coordinate']),int(record[product_field]))==ordered[case]
                add(case,record[real_field],record[imag_field])
for case in 0,29:
    path=Path(f'tuple1-case{case}')/'independent'/'replay.out'
    pairs=re.findall(r'exact normalized real (\S+) imaginary (\S+)',path.read_text())
    assert len(pairs)==1,(case,pairs)
    add(case,*pairs[0])
assert set(values)==set(range(36))
for case,(real,imaginary) in sorted(values.items()):
    key,count=ordered[case]
    print(case,repr(key),count,real,imaginary,sep='\t',file=sys.stdout)
print('COMPLETE SUM',len(values),*map(sum,zip(*values.values())),sep='\t',file=sys.stdout)
print('OPEN',','.join(map(str,sorted(set(range(36))-set(values)))),sep='\t',file=sys.stdout)
