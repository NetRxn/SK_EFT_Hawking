# Independent review of group128 descendant (0,1), tuple 1, cases 1–8

All eight exact complex values were reproduced. Their subtotal is `-236140905347776917255879/1298074214633706907132624082305024 + 0i`. The common raw Gaussian numerator is `(-40125200567189183279095628698469377526328847457497879864814862336,0)`. The factor denominator is `40512224221827380280140849737629696`. The physical contraction applies the positive factor `1/(16*4^64)` once, before summing the normalized terms.

The publication commit is `c08c92c60c8ece228ff8de4aa64cfeaf363e31c5`. Both reference archives were read from this commit, compared to the worktree, and checked against their internal manifests. The six-factor parent was byte-matched to the candidate checkpoint bound by the prior independent case 0 review. Its uncompressed SHA-256 is `ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c`. The two representation conditions are `(('R',1,3,0,2,1),0)` and `(('R',0,6,1,1,1),1)`. Tuple 1 belongs to the six-element dense-label roster. The independent rejected-pair histogram recomputed all 36 exclusive cut coordinates of `(('G',0,0,2),('J',1,4,2))` and accounted for all 6,838,272 compatible products. The smallest and largest cuts contain 142,464 and 213,696 products. The eight reviewed cuts each contain 142,464 products.

The direct inverse lift recovered every selected original row with its Gaussian coefficient and factor denominator. Each reviewed cut, refusal state, and terminal input has a distinct hash within its checkpoint class. An independent factor kernel reconstructed both quotient reductions and the exact tables before each capped join. Cases 1, 2, 5 and 6 completed 34,488 products before the five-factor refusal. The refused join projected 2,657,280 products in case 1 and 2,536,320 in cases 2, 5 and 6. Cases 3, 4, 7 and 8 completed 1,800,648 products before the four-factor refusal at a projected 2,557,632 products. Each refusal exited with status 2 and retained its exact restart state. The five archived-script stages for every case reproduced every log and binary output byte for byte.

The terminal arithmetic used direct sparse Gaussian accumulation and a second replay with support pruning and a width-weighted schedule. Both replay variants reproduced every signed raw numerator and both normalized components without importing the author’s join implementation. Cases 1, 2, 5 and 6 also differed in join order between the two variants. Cases 3, 4, 7 and 8 used the same join order in both variants and differed in compatible product counts after support pruning. The direct replay took 0.4760–7.5219 seconds per case and the support-pruned replay took 0.5794–16.1234 seconds. Timing records preserve the stages and wall durations under concurrent execution.

The numerical acceptance in this receipt covers only the eight listed coordinates. The common roster check covers all 36 coordinates of this parent.

Verify the portable receipt files from this directory. The source inventory binds the original author files in `/private/tmp/l1-child01-tuples234.cugnpQ/tuple1-remainder`. The archived scripts and compressed parent are included in the manifest.

```sh
shasum -a 256 -c review-manifest.sha256
gzip -dc parent.pkl.gz | shasum -a 256 -c parent-unpacked.sha256
python3 -B compare-arithmetic.py
```
