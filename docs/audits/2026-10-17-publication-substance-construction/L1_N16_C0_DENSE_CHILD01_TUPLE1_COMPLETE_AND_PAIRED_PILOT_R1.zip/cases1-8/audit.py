from ast import literal_eval
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import loads
from re import search
from sys import argv
from time import perf_counter

from exact_factors import DEN, combine, groups, overlap, proj, prune, quotient, reduce_factors

SOURCE = Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple1-remainder')
HASH = 'ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c'
CUT = (('R',0,6,1,1,1),1)
OUTER = (('R',1,3,0,2,1),0)
CUT_AXES = (('G',0,0,2),('J',1,4,2))
NORM = DEN * 16 * 4**64
RECEIPTS = ('plan.out', 'pilot.roster', 'reduce-0.out', 'contract-0.out',
            'reduce-1.out', 'contract-1.out', 'exact.tsv', 'timing.tsv')

def bindings():
    data = decompress(Path('parent.pkl.gz').read_bytes())
    assert sha256(data).hexdigest() == HASH
    parent = loads(data)
    assert (parent['physical_cut'], parent['used_before'], parent['rejected_pair']) == (CUT, 0, (0,1))
    assert parent['conditioning'][:2] == [OUTER, CUT]
    assert (parent['label_partition']['index'], parent['label_partition']['count']) == (1, 6)
    factors = parent['factors']
    assert len(factors) == 6 and prod(d for _,_,d in factors) == DEN
    assert set(Counter(axis for axes,_,_ in factors for axis in axes).values()) == {2}
    left, right = factors[:2]
    shared = overlap(left[0],right[0])
    assert set(CUT_AXES).isdisjoint(shared) and set(CUT_AXES).issubset(left[0])
    right_hist = Counter(map(proj(right[0],shared),right[1]))
    left_hist = Counter(zip(map(proj(left[0],CUT_AXES),left[1]),map(proj(left[0],shared),left[1])))
    spectrum = Counter()
    for (cut, row), n in left_hist.items():
        if row in right_hist:
            spectrum[cut] += n * right_hist[row]
    assert len(spectrum) == 36
    assert sum(spectrum.values()) == parent['matched'] == 6838272
    assert (min(spectrum.values()),max(spectrum.values())) == (142464,213696)
    assert len(literal_eval(Path('pilot.roster').read_text())[1]) == 36
    assert (CUT_AXES,sorted(spectrum.items())) == literal_eval(Path('pilot.roster').read_text())
    roster = sorted(spectrum, key=lambda cut:(spectrum[cut],cut))
    assert roster[0] == (17,(3,))
    return parent, spectrum, roster

def product_count(left, right):
    shared = overlap(left[0],right[0])
    counts_a = Counter(map(proj(left[0],shared),left[1]))
    counts_b = Counter(map(proj(right[0],shared),right[1]))
    return sum(n * counts_b[k] for k,n in counts_a.items())

def stage_file(source, filename, parent, fixed):
    data = (source/filename).read_bytes()
    obj = loads(data)
    assert obj['physical_cut'] == CUT
    assert obj['conditioning'] == parent['conditioning'] + list(fixed.items())
    assert obj['label_partition'] == parent['label_partition']
    factors = obj['factors']
    assert prod(d for _,_,d in factors) == DEN
    assert set(Counter(axis for axes,_,_ in factors for axis in axes).values()) == {2}
    print(f'checkpoint {filename} SHA256 {sha256(data).hexdigest()} rows {sum(len(r) for _,r,_ in factors)}')
    return obj, sha256(data).hexdigest()

def reconstruct_join(factors, expected_work, expected_rows, expected_width):
    matches = []
    for i,j in combinations(range(len(factors)),2):
        left, right = factors[i], factors[j]
        join_scope = tuple(a for a in left[0] + right[0] if (a in left[0]) != (a in right[0]))
        if len(join_scope) != expected_width or product_count(left,right) != expected_work:
            continue
        checks = []
        if expected_work > 250000:
            for peer, (axes,rows,_) in enumerate(factors):
                if peer in (i,j):
                    continue
                shared = overlap(axes,join_scope)
                if shared:
                    checks.append((proj(join_scope,shared),set(map(proj(axes,shared),rows))))
        result,n = combine(left,right,lambda row: all(p(row) in support for p,support in checks))
        if n == expected_work and len(result[1]) == expected_rows:
            matches.append((i,j,result))
    assert len(matches) == 1, [(i,j) for i,j,_ in matches]
    i,j,result = matches[0]
    print(f'independent checkpoint join {i},{j} products {expected_work} rows {expected_rows}')
    remaining = [factor for k,factor in enumerate(factors) if k not in (i,j)] + [result]
    prune(remaining, len(remaining)-1)
    return remaining

def case(index):
    start = perf_counter()
    parent, spectrum, roster = bindings()
    source = SOURCE / str(index)
    frozen = Path('author-receipts') / str(index)
    frozen.mkdir(parents=True,exist_ok=True)
    for name in RECEIPTS:
        data = (source/name).read_bytes()
        iff = frozen/name
        if iff.exists():
            assert iff.read_bytes() == data
        else:
            iff.write_bytes(data)
    cut_value = roster[index]
    assert (frozen/'pilot.roster').read_bytes() == Path('pilot.roster').read_bytes()
    i, original_cut, pair_products, re, im, stage = (frozen/'exact.tsv').read_text().strip().split('\t')
    assert (int(i),literal_eval(original_cut),int(pair_products),int(stage)) == (index,cut_value,spectrum[cut_value],1)
    scalar = Fraction(re), Fraction(im)
    fixed = dict(zip(CUT_AXES,cut_value,strict=True))
    cut, cut_sha = stage_file(source, 'pilot.pkl', parent, fixed)
    for (axes,rows,d),(projected,cut_rows,e) in zip(parent['factors'],cut['factors'],strict=True):
        assert d == e and projected == tuple(axis for axis in axes if axis not in fixed)
        reconstructed = {}
        for row,z in cut_rows.items():
            wire_values = dict(zip(projected,row,strict=True)) | fixed
            reconstructed[tuple(wire_values[axis] for axis in axes)] = z
        full_slice = {row:z for row,z in rows.items() if all(row[p]==fixed[axis]
                      for p,axis in enumerate(axes) if axis in fixed)}
        assert reconstructed == full_slice
    plan = (frozen/'plan.out').read_text().splitlines()[-1]
    assert plan == f'pilot {cut_value!r} matched {spectrum[cut_value]} stored rows {sum(len(r) for _,r,_ in cut["factors"])}'
    print('PASS direct inverse lift of every coefficient')
    f = list(cut['factors'])
    reduce_factors(f)
    reduced, _ = stage_file(source, 'label-pilot-0-reduced-frontier.pkl', parent, fixed)
    assert f == reduced['factors']
    prune(f)
    prune(f)
    cap_lines = (frozen/'contract-0.out').read_text().splitlines()
    done = 0
    for line in cap_lines:
        if line.startswith('join '):
            _, n, products, rows, _, width = line.split()
            f = reconstruct_join(f,int(products),int(rows),int(width))
            assert len(f) == int(n)
            done += int(products)
        if line.startswith('quotient '):
            _, _, _, n, before, after, _, folded = line.split()
            assert (len(f),before,folded) == (int(n),after,'0')
    cap, cap_sha = stage_file(source, 'row-cap-physical-slice-dense-label-pilot-0-reduced.pkl', parent, fixed)
    li, ri = cap['rejected_pair']
    assert overlap(f[li][0],f[ri][0])
    assert quotient(f,li,ri) + quotient(f,ri,li) == 0
    assert f == cap['factors']
    forecast = product_count(f[li],f[ri])
    assert cap['matched'] == forecast
    assert cap['used_before'] == done
    assert cap_lines[-1] == f'open row cap {len(f)} {forecast} frontier saved'
    print(f'PASS exact independent row-cap checkpoint prior {done} rejected {forecast} byte_sha {cap_sha}')
    reduce_factors(f)
    terminal, final_sha = stage_file(source, 'label-pilot-1-reduced-frontier.pkl', parent, fixed)
    assert f == terminal['factors']
    assert terminal['matched'] == forecast and terminal['used_before'] == done
    author = search(r'exact normalized real (\S+) imaginary (\S+) peak rows (\d+) matched products (\d+)',
                    (frozen/'contract-1.out').read_text())
    assert (Fraction(author[1]), Fraction(author[2])) == scalar
    codes = [int(r.split('\t')[2]) for r in (frozen/'timing.tsv').read_text().splitlines()]
    assert codes == [0,0,2,0,0]
    raw = tuple(x*NORM for x in scalar)
    assert all(value.denominator == 1 for value in raw) and scalar[1] == 0
    print(f'PASS distinct conditioned state and signed normalization at {cut_value!r}, wall seconds {perf_counter()-start:.4f}',flush=True)
    return (index, cut_value, spectrum[cut_value], cut_sha, cap_sha, final_sha, len(f),
            done, forecast, *map(int,raw), *scalar)

if __name__ == '__main__':
    if argv[1:]:
        case(int(argv[1]))
    else:
        parent, spectrum, roster = bindings()
        print(f'PASS parent {HASH}, complete {len(roster)} coordinates, matched pair products {sum(spectrum.values())}',flush=True)
        with ProcessPoolExecutor(max_workers=3) as pool:
            answers = list(pool.map(case,range(1,9)))
        assert all(len({row[column] for row in answers}) == 8 for column in (1,3,4,5))
        names = ('case','coordinate','pair_products','cut_sha256','cap_sha256','terminal_sha256',
                 'terminal_factors','prior_products','rejected_products','raw_real','raw_imaginary',
                 'normalized_real','normalized_imaginary')
        with Path('case-ledger.tsv').open('w') as tsv:
            print(*names,sep='\t',file=tsv)
            for row in answers:
                print(*row,sep='\t',file=tsv)
        print('subtotal',*(sum(row[column] for row in answers) for column in range(-4,0)))
