from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

root=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple1-remainder')
def check(i):
    a=root/str(i)
    receipt=(a/'exact.tsv').read_text().split('\t')
    stage=int(receipt[5])
    state=a/f'label-pilot-{stage}-reduced-frontier.pkl'
    log=a/f'contract-{stage}.out'
    methods=['sparse','sparse-support']
    statuses=[]
    for method in methods:
        output=Path(f'case-{i}-{method}.out')
        with output.open('xb') as out:
            p=subprocess.run([sys.executable,'-u',f'{method}-replay.py',str(i),str(stage),str(state),str(log)],
                             stdout=out,stderr=subprocess.STDOUT,timeout=90)
        statuses.append(p.returncode)
        print(i,method,p.returncode,sep='\t',flush=True)
    assert min(statuses)==0

with ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(check,map(int,sys.argv[1:])))
