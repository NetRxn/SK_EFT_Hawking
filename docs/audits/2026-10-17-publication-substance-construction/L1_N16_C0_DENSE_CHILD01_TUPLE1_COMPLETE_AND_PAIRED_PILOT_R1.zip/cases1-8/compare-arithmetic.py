from csv import DictReader
from fractions import Fraction
from pathlib import Path
from re import search

root = Path('.')
methods = ('sparse','sparse-support')
job_rows = [line.split('\t') for line in (root/'replay-jobs.tsv').read_text().splitlines()]
assert set(tuple(row) for row in job_rows) == {(str(i),method,'0') for i in range(1,9) for method in methods}
header = ('case','method','joins','products','largest_join','peak_output_rows','wall_seconds')
print(*header,sep='\t')
with (root/'case-ledger.tsv').open() as file:
    for case in DictReader(file,delimiter='\t'):
        for method in methods:
            idx = case['case']
            text = (root/f'case-{idx}-{method}.out').read_text()
            raw = search(r'PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)', text)
            assert (int(raw[1]),int(raw[2])) == (int(case['raw_real']),int(case['raw_imaginary']))
            assert int(raw[3]) == 40512224221827380280140849737629696
            checks = search(r'exact normalized real (\S+) imaginary (\S+) independent matched products (\d+) wall seconds (\S+)',text)
            assert (Fraction(checks[1]),Fraction(checks[2])) == (Fraction(case['normalized_real']),Fraction(case['normalized_imaginary']))
            joins = [line.split() for line in text.splitlines() if line.startswith('independent join ')]
            pair_order = ','.join(j[2]+'/'+j[3] for j in joins)
            assert sum(int(j[5]) for j in joins) == int(checks[3])
            print(idx,method,pair_order,checks[3],max(int(j[5]) for j in joins),max(int(j[8]) for j in joins),checks[4],sep='\t')
