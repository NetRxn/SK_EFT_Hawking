from pathlib import Path
from pickle import loads
from exact_factors import add, mul, overlap, proj
from collections import defaultdict

checkpoint=loads(Path('inputs/row-cap-physical-slice-dense-label-pilot-reduced.pkl').read_bytes())
factors=checkpoint['factors']
i,j=checkpoint['rejected_pair']
left,right=factors[i],factors[j]
a,A,_=left
b,B,_=right
shared=overlap(a,b)
left_tail=tuple(w for w in a if w not in shared)
right_tail=tuple(w for w in b if w not in shared)
outward=left_tail+right_tail
left_key,right_key=proj(a,shared),proj(b,shared)
prefix,suffix=proj(a,left_tail),proj(b,right_tail)
buckets=defaultdict(list)
for row,z in B.items():
    buckets[right_key(row)].append((suffix(row),z))
assert sum(len(buckets[left_key(row)]) for row in A)==checkpoint['matched']==4228224
restrictions=[]
for k,(axes,rows,_) in enumerate(factors):
    if k not in (i,j):
        scope=overlap(axes,outward)
        if scope:
            restrictions.append((proj(outward,scope),set(map(proj(axes,scope),rows))))
out={}
seen=0
for row,z in A.items():
    tail0=prefix(row)
    for tail1,other in buckets[left_key(row)]:
        seen+=1
        key=tail0+tail1
        if any(project(key) not in support for project,support in restrictions):
            continue
        coeff=add(out.get(key,(0,0)),mul(z,other))
        if not any(coeff):
            out.pop(key,None)
        elif key not in out and len(out)==500000:
            print('PASS refused insertion',seen,'of',checkpoint['matched'],
                  'products at retained rows',len(out),'rejected pair',(i,j))
            raise SystemExit(0)
        else:
            out[key]=coeff
raise AssertionError('row cap not observed')
