# Independent exact review of descendant (0,1), tuple 1, case 29

Accepted the exact normalized result `-526370532351546247637679/5192296858534827628530496329220096 + 0i` for case 29 at `(68,(2,))`, physical selector 1 and dense-label tuple 1. This is one of 36 terms.

The separator and completed prior tuple 1 archives at publication checkpoint `c08c92c60c8ece228ff8de4aa64cfeaf363e31c5` have Git blob IDs `02e33786d0bcd46e2314ad7fec1453595adcc815` and `377bab579075bc79b0acad3ccc26b11bec020cfd`. The packed six-factor candidate decompresses to `ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c`, the parent independently reproduced from the accepted descendant during the candidate review. The four pilot numerical source files byte-match the committed separator sources.

The independent factor kernel recomputed the complete disjoint 36-coordinate roster for rejected pair (0,1) with 6,838,272 products. The selected case is in the 213,696-product class. Its lift recovered every coefficient, axis and denominator of all six conditioned factors from the pinned parent. The independent lineage re-created both retained joins at 31,572 and 1,776,384 products, the exact four-factor refusal state at 4,228,224 forecast products, and the 37,944-row rescued restart at SHA-256 `7a885bb1099aaca916528f3addc578b5b15f7067540a187639e33785e85240e8`. A separate bounded pass over the refusal snapshot directly observed the refused insertion at product 2,801,363 with 500,000 retained rows.

The alternate terminal replay used three ordinary sparse joins and exact signed Gaussian-integer accumulation. It used 769,824 matched products, up to 454,896 in one join, with a peak of 33,696 output rows. Raw numerator `(-22360297077880635605766639462859868616872808388380987401787408384,0)` and factor denominator `40512224221827380280140849737629696`, multiplied by the positive external normalization `1/(16*4^64)` once, produce the independently accepted result. The lineage, cap occupancy check and signed replay took 10.66 s, 4.49 s and 0.70 s wall respectively on the frozen inputs.

After confirming the distinct source and exact replay, comparison against the archived (0,0) tuple 1 complete ledger found no equal scalar. Twice either archived case 19 or case 21 equals the new scalar. This comparison covers the values in the ledger.

Run from this directory with Python 3.

```sh
shasum -a 256 -c manifest.sha256
shasum -a 256 -c frozen-inputs.sha256
gzip -dc parent.pkl.gz | shasum -a 256 -c parent-unpacked.sha256
python3 verify-lineage.py
python3 verify-cap.py
python3 replay.py 29 0 inputs/label-pilot-rescue-reduced-frontier.pkl inputs/contract-rescue.out
python3 compare-prior.py
```
