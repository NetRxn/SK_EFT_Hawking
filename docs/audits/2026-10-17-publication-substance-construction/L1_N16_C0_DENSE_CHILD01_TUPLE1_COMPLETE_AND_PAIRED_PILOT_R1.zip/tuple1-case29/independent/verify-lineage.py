from ast import literal_eval
from collections import Counter
from hashlib import sha256
from math import prod
from itertools import combinations
from pathlib import Path
from gzip import decompress
from pickle import loads
from re import search

from exact_factors import DEN, read, groups, overlap, reduce_factors, prune, combine, quotient, proj

author=Path('inputs')
raw=decompress(Path('parent.pkl.gz').read_bytes())
digest=sha256(raw).hexdigest()
assert digest=='ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c'
parent=loads(raw)
assert dict(parent['conditioning'])[('R',0,6,1,1,1)] == 1
assert parent['physical_cut']==(('R',0,6,1,1,1),1)
assert parent['used_before']==0
print('PASS packed parent uncompressed SHA256',digest,flush=True)
assert parent['label_partition']['index'] == 1
factors = parent['factors']
assert len(factors)==6
assert set(Counter(w for axes,_,_ in factors for w in axes).values())=={2}
assert parent['rejected_pair']==(0,1)
li,ri = parent['rejected_pair']
left,right = factors[li],factors[ri]
cut_axes, table=literal_eval((author/'pilot.roster').read_text())
assert cut_axes == (('G',0,0,2),('J',1,4,2))
assert all(w in left[0] for w in cut_axes)
shared=overlap(left[0],right[0])
B=groups(right,shared)
joinpos=tuple(left[0].index(w) for w in shared)
cutpos=tuple(left[0].index(w) for w in cut_axes)
spectrum=Counter()
for row in left[1]:
    multiplicity=len(B.get(tuple(row[j] for j in joinpos),()))
    if multiplicity:
        spectrum[tuple(row[j] for j in cutpos)] += multiplicity
assert len(table)==len(spectrum)==36 and spectrum==dict(table)
assert sum(spectrum.values())==parent['matched']==6838272
assert sorted(spectrum,key=lambda k:(spectrum[k],k))[0]==(17,(3,))
case=sorted(spectrum,key=lambda k:(spectrum[k],k))[29]
assert case==(68,(2,)) and spectrum[case]==213696
print('PASS complete 36-case roster',sum(spectrum.values()),'minimum',min(spectrum.values()),
      'maximum',max(spectrum.values()),'case 29',case,spectrum[case],flush=True)
assert (author/'plan.out').read_text().splitlines()[-1]=='pilot (68, (2,)) matched 213696 stored rows 210838'
fixed=dict(zip(cut_axes,case,strict=True))
conditions=parent['conditioning']+list(fixed.items())

def state(name):
    raw=(author/name).read_bytes()
    obj=loads(raw)
    print('checkpoint',name,'SHA256',sha256(raw).hexdigest(),'rows',sum(len(r) for _,r,_ in obj['factors']),flush=True)
    assert obj['conditioning']==conditions and obj['label_partition']==parent['label_partition']
    assert obj['physical_cut']==parent['physical_cut']
    assert prod(d for _,_,d in obj['factors'])==DEN
    return obj

cut=state('pilot.pkl')
for (axes,rows,d),(out,small,e) in zip(factors,cut['factors'],strict=True):
    assert d==e and out==tuple(w for w in axes if w not in fixed)
    recovered={}
    for row,z in small.items():
        lookup=dict(zip(out,row,strict=True)) | fixed
        recovered[tuple(lookup[w] for w in axes)]=z
    expected={row:z for row,z in rows.items() if all(row[i]==fixed[w] for i,w in enumerate(axes) if w in fixed)}
    assert recovered==expected
print('PASS inverse lift preserves every coefficient, axis and denominator',flush=True)

working=list(cut['factors'])
reduce_factors(working)
reduced=state('label-pilot-reduced-frontier.pkl')
assert working==reduced['factors']
prune(working)
prune(working)

def product_count(factors,i,j):
    a,b=factors[i],factors[j]
    shared=overlap(a[0],b[0])
    A,B=groups(a,shared),groups(b,shared)
    return sum(len(A[k])*len(B[k]) for k in A.keys() & B.keys())

def retained_join(factors, count, rows, width, quotiented=False):
    candidates=[(i,j) for i,j in combinations(range(len(factors)),2)
                if product_count(factors,i,j)==count]
    matches=[]
    for i,j in candidates:
        trial=list(factors)
        if quotiented:
            assert quotient(trial,i,j)+quotient(trial,j,i)==0
        left,right=trial[i],trial[j]
        shared=overlap(left[0],right[0])
        outward=tuple(w for w in left[0]+right[0] if w not in shared)
        if len(outward)!=width:
            continue
        restrictions=[]
        if count>250000:
            for k,peer in enumerate(trial):
                if k in (i,j):
                    continue
                scope=overlap(peer[0],outward)
                restrictions.append((proj(outward,scope),set(map(proj(peer[0],scope),peer[1]))))
        combined,actual=combine(left,right,lambda row: all(key(row) in allowed for key,allowed in restrictions))
        assert actual==count
        result=[f for k,f in enumerate(trial) if k not in (i,j)]+[combined]
        prune(result,len(result)-1)
        if len(result[-1][1])==rows:
            matches.append((i,j,result))
    assert len(matches)==1, (count,candidates,[(i,j) for i,j,_ in matches])
    i,j,result=matches[0]
    print('retained join pair',i,j,'products',count,'rows',rows,flush=True)
    return result

working=retained_join(working,31572,21924,22)
working=retained_join(working,1776384,145152,22,True)
cap=state('row-cap-physical-slice-dense-label-pilot-reduced.pkl')
i,j=cap['rejected_pair']
assert cap['used_before']==31572+1776384
assert quotient(working,i,j)+quotient(working,j,i)==0
assert working==cap['factors']
forecast=product_count(working,i,j)
assert forecast==cap['matched']==4228224
assert (author/'contract.out').read_text().splitlines()[1:]==[
    'join 5 31572 21924 axes 22',
    'quotient before join 5 1776384 1776384 slices 0',
    'join 4 1776384 145152 axes 22',
    'quotient before join 4 4228224 4228224 slices 0',
    'open row cap 4 4228224 frontier saved']
print('PASS refusal checkpoint exact four-factor tables; retained work',cap['used_before'],'forecast',forecast,flush=True)
reduce_factors(working)
terminal=state('label-pilot-rescue-reduced-frontier.pkl')
assert terminal['factors']==working
print('PASS terminal checkpoint fully reproduced from pinned case 29 cut',flush=True)
