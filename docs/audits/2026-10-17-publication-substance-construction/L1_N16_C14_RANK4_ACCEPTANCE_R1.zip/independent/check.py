from collections import Counter, defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
from fractions import Fraction
import json,sys
from src.core.formulas import original_action_factors, original_spin4_link, original_coframe_blocks
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol
A,T,S,SE,P=map(Path,sys.argv[1:6])
def load(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def f(v): return tuple(map(f,v)) if isinstance(v,(tuple,list)) else v
def tbl(p):
    rr=f(rows(p)); t=dict(rr); assert len(rr)==len(t)
    return t
def co(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def add(z,w):return z[0]+w[0],z[1]+w[1]
def sign(w):return (-1)**sum(i>j for k,i in enumerate(w) for j in w[k+1:])
def pos(site,mask):return [8*site+i for i in range(8) if mask>>i&1]
R=OriginalRegulator()
index={x:i for i,x in enumerate(R.sites)}
positions={g:i for i,g in enumerate(R.generator_order)}
assert (R.extents,R.boundary_signs,R.convention,R.word)==((2,)*4,(1,)*4,'source_C','closed')
L={anchor:original_spin4_link(*(tuple(Polynomial.variable(Symbol('q',(*anchor,h,i))) for i in range(4)) for h in ('L','R'))) for anchor in R.link_order}
M=load(A/'result.json')
G=load(A/'graph.json')
base=load(T/'graph.json')
C=load(P/'support-census.json')['sites']
row=load(S/'result.json')['row']
assert row['exponential_divisor']==512
acts=[]
for i,(x,*axes) in enumerate(row['planes']):
    anchors={tuple(sorted((index[tuple(y)],d) for y,d in aa)) for degree,comp,aa,n,_ in C[x]['raw_branches']
             if n and degree==2 and sorted(j for j,_ in comp)==axes}
    assert len(anchors)==1
    acts.append(('S2',x,i,tuple(axes),next(iter(anchors))))
acts += [('S4',x,i,tuple(range(4)),()) for x,n in enumerate(row['S4_occupations']) for i in range(n)]

def edge(rank,d):
    return frozenset((rank,index[R.step(R.sites[rank],d)[0]]))
def owner(rank,axis):
    E=edge(rank,axis)
    frames=[(s,x,i,d) for s,x,i,axes,_ in acts for d in axes if edge(x,d)==E]
    traces=[(s,x,i,(k,d)) for s,x,i,_,aa in acts for k,d in aa if edge(k,d)==E]
    return f(frames),f(traces)
fr,tr=owner(4,0)
assert f(M['edge'])==(0,12,fr,tr)
assert fr==(('S4',12,0,0),('S4',12,1,0))
assert tr==(('S2',0,2,(4,0)),('S2',0,3,(4,0)))

@cache
def moment(q):
    ns=Counter(q)
    if any(n%2 for n in ns.values()):return Fraction()
    return Fraction(prod(3 if n==4 else 1 for n in ns.values()),
        prod(j for n in Counter(i//4 for i in q).values() for j in range(4,4+n,2)))

def compute(site,axis,trace_slots,center):
    neighbor=next(iter(edge(site,axis)-{site}))
    ends=tuple(sorted((site,neighbor)))
    # The actual coframes all center at rank 12, including residual edge.
    alpha=defaultdict(list)
    qindex={(R.sites[x],axis,h,k):i for i,(x,h,k) in enumerate(product(ends,('L','R'),range(4)))}
    for component in range(4):
        for b in original_coframe_blocks(R,(R.sites[center],axis,component),L):
            for i,j in product(range(4),repeat=2):
                w=(positions[b.bar_site,'bar',i],positions[b.psi_site,'psi',j])
                for sy,z in b.matrix[i][j].terms:
                    assert len(sy)==1 and sy[0].index[:2]==b.anchor
                    c=(z.real*4*b.weight,z.imag*4*b.weight)
                    assert all(v.denominator==1 for v in c)
                    alpha[qindex[sy[0].index]].append((component,w,tuple(map(int,c))))
    support=0
    grouped=defaultdict(lambda:(0,0))
    weight_scale=48 if trace_slots else 4
    for q in product(range(16),range(16),*trace_slots):
        H=moment(q)*weight_scale
        if not H:continue
        assert H.denominator==1
        support+=1
        for (a,w,z),(b,v,t) in product(alpha[q[0]],alpha[q[1]]):
            word=w+v
            if len(set(word))!=4:continue
            local,remote=(sum(1<<(i%8) for i in word if i//8==x) for x in (site,neighbor))
            assert local.bit_count()==remote.bit_count()==2
            key=(local,remote,a,b,*q[2:])
            grouped[key]=add(grouped[key],tuple(int(H)*sign(word)*u for u in co(z,t)))
    nonzero={k:v for k,v in grouped.items() if any(v)}
    return nonzero,support,len(grouped)-len(nonzero)

B,PRE=map(Path,sys.argv[6:8])
meta=load(B/'result.json')
rb=load(B/'readback.json')
assert row['S4_occupations'][4]==0 and all(x!=4 for x,_,_ in row['planes'])
new=[]
for d,neighbor,desc in zip((2,3),(6,5),meta['owners'],strict=True):
    fr,tr=owner(4,d)
    assert fr==tuple(('S4',neighbor,j,d) for j in (0,1)) and not tr
    assert edge(4,d)=={4,neighbor} and f(desc)==(d,neighbor,fr,tr)
    tab,hs,zeros=compute(4,d,(),neighbor)
    assert tab==tbl(B/f'rank4-edge-axis{d}.jsonl') and (len(tab),hs,zeros)==(48,16,240)
    new.append(tab)
print('both full original 48-row degree-two signed edge maps matched',flush=True)
compact=defaultdict(lambda:(0,0))
disjoint=0
for ((m,r,a,b),z),((n,s,c,d),w) in product(*[e.items() for e in new]):
    if m&n:continue
    disjoint+=1
    local=pos(4,m)+pos(4,n)
    complement=tuple(i for i in range(32,40) if i not in local)
    fused=sum(1<<(i-32) for i in complement)
    word=list(complement)+sorted(pos(4,m)+pos(6,r))+sorted(pos(4,n)+pos(5,s))
    assert len(set(word))==len(word)==12
    sg=sign(word)
    assert sign([33 if i==32 else 32 if i==33 else i for i in word])==-sg
    k=(fused,r,a,b,s,c,d)
    compact[k]=add(compact[k],tuple(sg*i for i in co(z,w)))
assert disjoint==1472 and len({k[0] for k in compact})==18
assert len(compact)==1344 and all(any(z) for z in compact.values())
assert dict(compact)==tbl(B/'rank4-compact.jsonl')
merges=tbl(A/'merge-rank4.jsonl')
attached={}
for (m,n,q),sg in merges.items():
    assert not m&n and q==m|n and sg==sign(pos(4,m)+pos(4,n))
    for (fused,*remote),z in compact.items():
        if fused!=q:continue
        k=(m,n,*remote)
        assert k not in attached
        attached[k]=tuple(sg*i for i in z)
assert len(attached)==8064 and attached==tbl(B/'rank4-closure.jsonl')
print('1472 disjoint pairs, 18 fused masks, complete 1344 compact and 8064 attached signed maps',flush=True)

earlier=tbl(T/'zero-edge-1.jsonl')
res=tbl(A/'residual-edge.jsonl')
for ctl in meta['controls']:
    p,q=f(ctl['old_axis1_key']),f(ctl['residual_axis0_key'])
    remote=f(ctl['boundary'])
    left={k[1]:z for k,z in earlier.items() if (k[0],*k[2:])==p}
    right={k[0]:z for k,z in res.items() if k[1:]==q}
    selected=[[(k[0],z) for k,z in table.items() if k[1:]==rs] for table,rs in zip(new,(remote[:3],remote[3:]),strict=True)]
    total=(0,0)
    paths=defaultdict(lambda:(0,0))
    # Direct 4-edge sum uses original literal word, not compact or attached signs.
    for (m,w),(n,z),(m2,z2),(m3,z3) in product(left.items(),right.items(),*selected):
        if (m|n|m2|m3)!=255 or sum(x.bit_count() for x in (m,n,m2,m3))!=8:
            continue
        word=pos(4,m)+sorted(pos(4,n)+pos(12,q[0]))+sorted(pos(4,m2)+pos(6,remote[0]))+sorted(pos(4,m3)+pos(5,remote[3]))
        assert len(set(word))==len(word)==14
        sg=sign(word)
        assert sign([33 if i==32 else 32 if i==33 else i for i in word])==-sg
        val=tuple(sg*i for i in co(co(w,z),co(z2,z3)))
        total=add(total,val)
        paths[m,n,*remote]=add(paths[m,n,*remote],val)
    assert total==f(ctl['coefficient_numerator'])
    assert len(paths)==1 and all(any(z) for z in paths.values())
    key,val=f(ctl['first_nonzero_path'])
    assert paths[key]==val
    neg=tuple(a-2*b for a,b in zip(total,val))
    assert neg==f(ctl['flipped_single_path_numerator'])
    assert ctl['denominator']==768**2*64**2 and Fraction(total[0],ctl['denominator'])==Fraction(1,4096)
    print('literal fixed junction',total,'single sign adverse',neg,flush=True)

pg=load(PRE/'graph.json')
g=load(B/'graph.json')
assert set(g['boundary'])==set(pg['boundary'])-{'remote4'}|{'remote6','remote5','S4_6_a2_0','S4_6_a2_1','S4_5_a3_0','S4_5_a3_1'}
assert g['factor_keys']['rank4_closure']==['old_mask4','new_mask4','remote6','S4_6_a2_0','S4_6_a2_1','remote5','S4_5_a3_0','S4_5_a3_1']
assert {k:v for k,v in pg['factor_keys'].items() if k!='merge_rank4'}=={k:v for k,v in g['factor_keys'].items() if k!='rank4_closure'}
assert g['combined_denominator']==pg['combined_denominator']*4096==3609833154556168881605846237184
assert g['external_exponential_divisor']==512
for d,neighbor,anchor in ((0,11,None),(1,7,None),(2,1,(1,2)),(3,2,(2,3))):
    fr,tr=owner(3,d)
    assert fr==tuple(('S4',3,j,d) for j in (0,1)) and edge(3,d)=={3,neighbor}
    assert tr==tuple(('S2',0,j,anchor) for j in (0,1)) if anchor else not tr
    ts=(range(8),range(8)) if anchor else ()
    tab,s,zero=compute(3,d,ts,3)
    assert (len(tab),s,zero)==((14208,240,3584) if anchor else (48,16,240))
    print('rank3 next source',d,'neighbor',neighbor,'trace anchor',anchor,'raw nonzero rows',len(tab),flush=True)
