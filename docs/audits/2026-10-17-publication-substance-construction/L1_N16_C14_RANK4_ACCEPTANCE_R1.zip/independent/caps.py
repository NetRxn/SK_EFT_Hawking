from pathlib import Path
import sys,json
a=Path(sys.argv[1])
m=json.loads((a/'result.json').read_text())
s=m['storage']; c=m['cap']
assert sum(m['charged_operations'].values())==118261<c['work']==4_000_000
assert s['rows']==80520<c['rows']==120000
assert s['charged_bytes']==512*s['rows']==41226240<c['accounted_bytes']==64*1024**2
assert s['serialized_bytes']==sum(x.stat().st_size for x in a.glob('*.jsonl'))==301280<c['serialized_bytes']==4*1024**2
assert m['rss_peak_bytes']==116506624<c['sampled_rss']==384*1024**2
assert c['scalar']==2**61-1
print('scoped local work, cumulative rows, accounting and output bytes, and sampled RSS receipt checked')
