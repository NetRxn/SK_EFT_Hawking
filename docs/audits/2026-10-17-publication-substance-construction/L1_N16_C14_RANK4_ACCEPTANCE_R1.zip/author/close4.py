"""Full original rank-4 exterior projection with the two remote S4 pairs open."""
from collections import defaultdict
from itertools import product
from pathlib import Path
import json, sys

D=Path(__file__).parent
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
TWO=Path('/tmp/publication-c14-rank-zero-r1.gte6BM')
RES=Path('/tmp/publication-c14-residual-edge-r1.klcKMh')
PRE=Path('/tmp/publication-c14-rank12-r1.ehXXAy')
sys.path.insert(0,str(STAR))
import cut

ZERO=(0,0)
DEN=64**2

def read(p):
    with p.open() as f:
        for row in f:
            cut.work('read_frozen_row')
            yield json.loads(row)

def bits(i,m):
    return [8*i+k for k in range(8) if m>>k&1]

def literal_sign(words,transpose=False):
    w=sum((bits(i,m) for i,m in words),[])
    if len(w)!=len(set(w)):
        return 0
    if transpose:
        w=[33 if a==32 else 32 if a==33 else a for a in w]
    return (-1)**sum(a>b for i,a in enumerate(w) for b in w[i+1:])

def edges():
    row=cut.roster()
    assert row['S4_occupations'][4]==0 and all(a!=4 for a,_,_ in row['planes'])
    owner=cut.star_owners(row,4)[2:]
    out=[]
    for d,neighbor in zip(owner,(6,5),strict=True):
        axis,n,frames,trace=d
        assert n==neighbor and not trace
        assert frames==[('S4',neighbor,0,axis),('S4',neighbor,1,axis)]
        a,da,na=cut.edge_tensor(d,4,False)
        b,db,nb=cut.edge_tensor(d,4,True)
        assert a==b and da==db==64 and na==nb==16 and len(a)==48
        cut.write_rows(f'rank4-edge-axis{axis}.jsonl',a)
        out.append(a)
    return out,owner

def compact(two,three,raw=False):
    result={}
    disjoint=0
    for ((m,r,a,b),z),((n,s,c,d),w) in product(two.items(),three.items()):
        cut.work('raw_pair' if raw else 'complement_pair')
        if m&n:
            continue
        disjoint+=1
        if raw:
            remaining=set(range(8))-{x%8 for x in bits(4,m|n)}
            old=sum(1<<x for x in remaining)
            words=((1,3),(2,3),(4,old),(9,3),(10,3),(13,3),(14,3),(4,m),(6,r),(4,n),(5,s))
            sign=literal_sign(words)
            assert sign and literal_sign(words,True)==-sign
        else:
            old=255^(m|n)
            sign=(-1)**(cut.crossing(old,m)+cut.crossing(old|m,n))
        k=(old,r,a,b,s,c,d)
        cut.reserve('rank4_compact',k,result)
        result[k]=cut.add(result.get(k,ZERO),cut.scale(cut.times(z,w),sign))
    return {k:z for k,z in result.items() if z!=ZERO},disjoint,len(result)

def attach(table):
    index=defaultdict(list)
    for (m,*tail),z in table.items():
        cut.work('compact_index')
        cut.reserve('compact_index',len(index[m]),{})
        index[m].append((tuple(tail),z))
    out={}
    for (old,new,m),sg in read(RES/'merge-rank4.jsonl'):
        for key,z in index[m]:
            cut.work('attach_signed_merge')
            k=(old,new,*key)
            assert k not in out
            cut.reserve('rank4_attachment',k,out)
            out[k]=cut.scale(z,sg)
    return out

def index_old():
    one=defaultdict(dict)
    zero=defaultdict(dict)
    for (m01,old4,a,b,q,s),z in read(TWO/'zero-edge-1.jsonl'):
        k=(m01,a,b,q,s)
        cut.reserve('old_axis1_index',old4,one[k])
        one[k][old4]=tuple(z)
    for (new4,new12,a,b,q,s),z in read(RES/'residual-edge.jsonl'):
        k=(new12,a,b,q,s)
        cut.reserve('residual_axis0_index',new4,zero[k])
        zero[k][new4]=tuple(z)
    return one,zero

def junctions(a,two,three):
    one,zero=index_old()
    invs=[]
    for tbl in (one,zero):
        inv=defaultdict(list)
        for k,group in tbl.items():
            for m in group:
                cut.work('junction_index')
                cut.reserve('junction_index',len(inv[m]),{})
                inv[m].append(k)
        invs.append(inv)
    out=[]
    seen=set()
    for (m,n,*key),z in sorted(a.items()):
        cut.work('propose_control')
        r,a20,a21,s,a30,a31=key
        for o,p in product(invs[0][m][:3],invs[1][n][:3]):
            cut.work('propose_edge_context')
            k=o,p,tuple(key)
            if k in seen:
                continue
            cut.reserve('control_seen',k,seen)
            seen.add(k)
            result=ZERO
            first=None
            paths=0
            for (old,z),(new,w) in product(one[o].items(),zero[p].items()):
                cut.work('factored_fixed_junction')
                v=cut.times(cut.times(z,w),a.get((old,new,*key),ZERO))
                if v!=ZERO:
                    if first is None:
                        first=((old,new,*key),v)
                    paths+=1
                result=cut.add(result,v)
            if result==ZERO:
                continue
            exact=ZERO
            for (k,z),(j,w) in product(two.items(),three.items()):
                cut.work('raw_junction_edges')
                m2,*l=k
                m3,*r0=j
                if l+r0!=key or m2&m3:
                    continue
                for old,oldz in one[o].items():
                    cut.work('raw_junction_mask')
                    if old&(m2|m3):
                        continue
                    new=255^(old|m2|m3)
                    newz=zero[p].get(new,ZERO)
                    if newz==ZERO:
                        continue
                    words=((1,3),(2,3),(4,old),(9,3),(10,3),(13,3),(14,3),
                           (4,new),(4,m2),(6,r),(4,m3),(5,s))
                    sign=literal_sign(words)
                    assert sign and literal_sign(words,True)==-sign
                    val=cut.times(cut.times(z,w),cut.times(oldz,newz))
                    exact=cut.add(exact,cut.scale(val,sign))
            assert exact==result
            adverse=cut.add(result,cut.scale(first[1],-2))
            assert adverse!=result
            cut.reserve('junction_control',len(out),{})
            out.append(dict(old_axis1_key=o,residual_axis0_key=p,boundary=key,
                coefficient_numerator=result,first_nonzero_path=first,
                flipped_single_path_numerator=adverse,
                nonzero_attached_paths=paths,denominator=768**2*DEN))
            if len(out)==4:
                return out
    raise AssertionError(('fixed junction controls',len(out)))

def graph():
    g=json.loads((PRE/'graph.json').read_text())
    del g['factor_keys']['merge_rank4']
    g['factor_keys']['rank4_closure']=['old_mask4','new_mask4',
        'remote6','S4_6_a2_0','S4_6_a2_1','remote5','S4_5_a3_0','S4_5_a3_1']
    g['boundary']=[b for b in g['boundary'] if b!='remote4']+g['factor_keys']['rank4_closure'][2:]
    g['combined_denominator']*=DEN
    g['semantics']+=' rank4_closure replaces merge_rank4 and incorporates the two new Haar edges and the rank-4 top wedge projection. Its S4 component pairs belong to ranks 6 and 5 and remain open.'
    (D/'graph.json').write_text(json.dumps(g,indent=2)+'\n')
    return g['combined_denominator']

def main():
    cut.OUT=D
    cut.ROW_CAP=120_000
    cut.rss()
    (two,three),owner=edges()
    c,n,r=compact(two,three)
    raw,n0,r0=compact(two,three,True)
    assert c==raw and n==n0==1472 and r==r0
    assert len({k[0] for k in c})==18
    a=attach(c)
    assert a==attach(raw)
    cut.write_rows('rank4-compact.jsonl',c)
    cut.write_rows('rank4-closure.jsonl',a)
    print('compact',len(c),'attached',len(a),'removed zero keys',r-len(c),flush=True)
    checked=junctions(a,two,three)
    den=graph()
    cut.rss()
    out=dict(owners=owner,edge_rows=[len(two),len(three)],disjoint_edge_pairs=n,
        compact_rows=len(c),compact_exact_zeros=r-len(c),attached_rows=len(a),
        fused_masks=len({k[0] for k in c}),local_denominator=DEN,graph_denominator=den,
        controls=checked,charged_operations=dict(cut.WORK),storage=dict(cut.STORE),
        rss_peak_bytes=cut.RSS_PEAK,cap=dict(rows=cut.ROW_CAP,work=cut.WORK_CAP,
            accounted_bytes=cut.BYTE_CAP,serialized_bytes=cut.FILE_CAP,
            sampled_rss=cut.RSS_CEILING,scalar=cut.INT_LIMIT))
    (D/'result.json').write_text(json.dumps(out,indent=2)+'\n')
    print('verified',len(checked),'junctions',flush=True)

if __name__=='__main__':
    main()
