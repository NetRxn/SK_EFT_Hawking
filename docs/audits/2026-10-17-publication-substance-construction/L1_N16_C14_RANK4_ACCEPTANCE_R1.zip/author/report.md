# Exact original N16 c14 rank-4 signed closure

The pinned authority is the periodic closed source_C at clean primary
27012c18fa374e8341e124b510abbedeedb18d29. This increment starts with the
accepted rank-12 graph for the zero-centered (01,01,23,23)
representative. The original exponential divisor 512 stays external.

The original row has no S2 or S4 occurrence centered at rank 4.
Its two remaining edges go along axes 2 and 3 to ranks 6 and 5.
The respective owners are the two rank-6 S4 coframe occurrences
and the two rank-5 S4 coframe occurrences. Neither edge has
curvature incidence. Each complete degree-two Haar tensor has
48 nonzero rows at denominator 64. Both tables match the independent
raw quarter-increment, literal sign and invariant Haar route.

Among 2,304 new edge row pairs, 1,472 have disjoint rank-4
two-generator masks and cover 18 complementary four-generator
masks. Projecting against the fused four-generator mask from the
accepted earlier graph gives 1,344 distinct nonzero compact rows.
The compact key is
`[fused4,remote6,a2_occ0,a2_occ1,remote5,a3_occ0,a3_occ1]`.
The compact denominator is 4,096. The two ordered component
pairs belong to distinct original sites and remain open, together
with the two remote two-generator masks.

Absorbing the accepted signed rank-4 merge produces 8,064 rows,
with `[old4,new4]` in place of `fused4` in the key. The graph
replaces the prior rank-4 merge with this factor and sums the
two rank-4 masks. No local epsilon is present. The graph's combined
denominator before the external divisor is
3,609,833,154,556,168,881,605,846,237,184. The earlier factors stay
factored.

The literal exterior comparator matches the complete compact and
attached tables. It derives the complementary generator set and
uses original 128-position order, including unchanged even exterior
blocks. The readback checker independently verifies every frozen
compact and attached key. Four complete fixed junctions with the
earlier axis-1 edge and residual axis-0 edge all evaluate to 1/4,096.
Direct raw projection and serialized readback agree. Each has one
nonzero attached path, whose sign reversal changes the junction to
-1/4,096. Transposing the first two rank-4 generators reverses the
literal rank-4 exterior sign.

The run charged 118,261 operations against 4,000,000 and 80,520
cumulative entries against 120,000. It used 41,226,240 accounting
bytes against 64 MiB and 301,280 exact JSONL bytes against 4 MiB.
Checked Gaussian-integer operations are bounded prospectively.
The sampled peak process RSS was 116,506,624 bytes against a sampled
384 MiB ceiling. The accounting meters exclude source initialization,
interpreter overhead, secondary indexing and sorting, and separate
readback. The sampled ceiling is not OS enforcement.

The next useful candidate is rank 3. Its two degree-four edges
reach ranks 1 and 2 and carry the last two original plane-01 trace
coordinates at (1,2) and (2,3). Its two degree-two edges reach ranks
11 and 7. All eight coframes belong to the two original rank-3 S4
occurrences. A bounded joint cut could eliminate the remaining
plane-01 quaternion labels and both ordered epsilons while closing
rank 3. Other axis arrangements, whole representative values, c14,
c0, full denominator and normalization remain open.
