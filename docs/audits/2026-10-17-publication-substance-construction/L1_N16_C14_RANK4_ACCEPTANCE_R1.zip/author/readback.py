"""Check serialized rank-4 compact/attached products and fixed junctions."""
from collections import defaultdict
from itertools import product
from pathlib import Path
import json

D=Path(__file__).parent
TWO=Path('/tmp/publication-c14-rank-zero-r1.gte6BM')
RES=Path('/tmp/publication-c14-residual-edge-r1.klcKMh')

def rows(p):
    return [json.loads(s) for s in p.read_text().splitlines()]

def read(p):
    out={}
    for k,v in rows(p):
        assert tuple(k) not in out
        out[tuple(k)]=tuple(v)
    return out

def word(m):
    return [i for i in range(8) if m>>i&1]

def parity(w):
    return (-1)**sum(x>y for i,x in enumerate(w) for y in w[i+1:])

def mult(z,w):
    a,b=z
    c,d=w
    return a*c-b*d,a*d+b*c

def plus(z,w):
    return z[0]+w[0],z[1]+w[1]

zero=(0,0)
compact={}
for (k,z),(j,w) in product(read(D/'rank4-edge-axis2.jsonl').items(),read(D/'rank4-edge-axis3.jsonl').items()):
    m,*p=k
    n,*q=j
    if m&n:
        continue
    available=set(range(8))-(set(word(m))|set(word(n)))
    c=sum(1<<i for i in available)
    sg=parity(sorted(available)+word(m)+word(n))
    key=(c,*p,*q)
    compact[key]=plus(compact.get(key,zero),tuple(sg*x for x in mult(z,w)))
assert compact==read(D/'rank4-compact.jsonl')
attached={}
for (m,n,c),sg in rows(RES/'merge-rank4.jsonl'):
    assert sg==parity(word(m)+word(n)) and not m&n and m|n==c
    for k,z in compact.items():
        if k[0]==c:
            key=(m,n,*k[1:])
            assert key not in attached
            attached[key]=tuple(sg*x for x in z)
assert attached==read(D/'rank4-closure.jsonl')

old=defaultdict(dict)
new=defaultdict(dict)
for (m,n,a,b,q,r),z in rows(TWO/'zero-edge-1.jsonl'):
    old[m,a,b,q,r][n]=tuple(z)
for (m,n,a,b,q,r),z in rows(RES/'residual-edge.jsonl'):
    new[n,a,b,q,r][m]=tuple(z)
verified=[]
for c in json.loads((D/'result.json').read_text())['controls']:
    l=old[tuple(c['old_axis1_key'])]
    r=new[tuple(c['residual_axis0_key'])]
    total=zero
    for m,n in product(l,r):
        k=(m,n,*c['boundary'])
        total=plus(total,mult(mult(l[m],r[n]),attached.get(k,zero)))
    assert list(total)==c['coefficient_numerator']
    verified.append(total)
print(json.dumps(dict(compact_rows=len(compact),attached_rows=len(attached),
                      checked_junction_numerators=verified),indent=2))
