from collections import defaultdict
from pathlib import Path
def read(p):
    return (tuple(map(int,l.split())) for l in Path(p).open())
decorations=defaultdict(list)
for i in range(4):decorations[0,i,i].append((0,0,1,0))
for a,b,i,j,v in read('INDEPENDENT/adjoint.tsv'):
    for k,off in ((1,0),(2,4)):
        decorations[k,off+i,off+j].append((a,b,v,0))
for a,b,i,j,r,s in read('INDEPENDENT/fundamental-product.tsv'):
    decorations[3,i,j].append((a,b,r,s))
ordinary={(u,v,x|(y<<8),0,0):(4*r,4*s)
          for u,v,x,y,r,s in read('INDEPENDENT/mixed.tsv')}
with Path('mixed-matrices.tsv').open('w') as output:
    for h in range(2):
        for k in range(4):
            table={}
            n=sum(len(decorations.get((k,i,j),())) for a,i,j,*rest in read('mixed-signed.tsv') if a==h)
            assert n<=2_000_000
            for a,i,j,u,v,mask,re,im in read('mixed-signed.tsv'):
                if a!=h:continue
                for x,y,r,s in decorations.get((k,i,j),()):
                    key=(u,v,mask,x,y)
                    assert len(table)<150000 or key in table
                    p,q=table.get(key,(0,0))
                    table[key]=(p+re*r-im*s,q+re*s+im*r)
            retained={key:z for key,z in table.items() if any(z)}
            if k==0:assert retained==ordinary
            for key,z in sorted(retained.items()):
                output.write(' '.join(map(str,(h,k,*key,*z)))+'\n')
            print(h,k,len(table),len(retained),n)
