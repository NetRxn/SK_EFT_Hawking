#define main reference_main
#include "slice_reference.cpp"
#undef main
#include <map>

int moment(const std::array<int,6>& variables) {
    std::array<int,16> powers{};
    for(int k:variables)powers.at(k)++;
    int a=192,b=1;
    for(int g=0;g<16;g+=4){
        int degree=0;
        for(int p=g;p<g+4;p++){
            if(powers[p]&1) return 0;
            degree+=powers[p];
            for(int k=3;k<powers[p];k+=2) a*=k;
        }
        for(int k=0;k<degree;k+=2)b*=k+4;
    }
    if(a%b)throw std::runtime_error("nonintegral Haar");
    return a/b;
}
using Pair=std::pair<int,int>;
using Inner=std::unordered_map<unsigned,std::vector<Quad>>;
using Roster=std::map<int,std::map<unsigned,Inner>>;
unsigned parity(int a,int b) {return (1U<<a)^(1U<<b);}
std::array<std::vector<unsigned>,256> endpoint_complements(){
    std::array<std::vector<unsigned>,256> out;
    for(unsigned m=0;m<256;m++) {
        if(std::popcount(m)!=2)continue;
        unsigned available=255^m;
        for(unsigned x=available;x;x=(x-1)&available)
            if(std::popcount(x)==2)out[m].push_back(x);
        if(out[m].size()!=15)throw std::runtime_error("endpoint complement roster");
    }
    return out;
}
int main(){
    const auto c=endpoint_complements();
    const auto source=read_coframes();
    std::array<Roster,2> quad;
    for(int o:{0,1})for(int a=0;a<4;a++)for(int b=a;b<4;b++){
        const auto p=square_pair(source[o][a],source[o][b]);
        for(const auto& bucket:p)for(auto x:bucket)
            quad[o][a*4+b][parity(x.a,x.b)][x.mask].push_back(x);
    }
    std::map<Pair,int> decorations;
    std::ifstream adj("adjoint.tsv"),cross("fundamental-product.tsv");
    int a,b,i,j,r,s;
    while(adj>>a>>b>>i>>j>>r) for(int h:{0,4}) decorations[{h+i,h+j}]++;
    while(cross>>a>>b>>i>>j>>r>>s)decorations[{i,j}]++;
    for(int h:{0,1}){
        const auto visit=[&](Pair q,auto action){
            const auto needed=parity(q.first+8*h,q.second+8*h);
            for(const auto& [u,L]:quad[0])
                for(const auto& [v,R]:quad[1])
                    for(const auto& [p,X]:L){
                        auto it=R.find(p^needed);
                        if(it==R.end())continue;
                        const auto& Y=it->second;
                        for(const auto& [m,ms]:X)
                            for(unsigned lo:c[m&255])
                                for(unsigned hi:c[m>>8]){
                                    const unsigned n=lo|(hi<<8);
                                    auto hit=Y.find(n);
                                    if(hit!=Y.end())action(u,v,m|n,sign(m,n),ms,hit->second);
                                }
                    }
        };
        U64 raw=0,cached=0,peak_work=0;
        for(const auto& [q,m]:decorations){
            U64 work=0;
            visit(q,[&](int,int,unsigned,int,const auto& A,const auto& B){work+=U64(A.size())*B.size();});
            raw+=work*m;cached+=work;peak_work=std::max(peak_work,work);
        }
        if(cached>50'000'000 || I128(192)*64*64*64*64*cached>=(I128(1)<<62))
            throw std::runtime_error("prospective cap");
        std::cerr<<"anchor "<<h<<" hypothetical raw "<<raw<<" executed cached "<<cached
                 <<" pair peak "<<peak_work<<'\n';
        U64 peak=0,nnz=0;
        for(const auto& [q,m]:decorations){
            (void)m;
            std::map<std::tuple<int,int,unsigned>,Z> out;
            visit(q,[&](int u,int v,unsigned mask,int phase,const auto& A,const auto& B){
                auto key=std::make_tuple(u,v,mask);
                if(!out.contains(key)&&out.size()>=150'000)throw std::runtime_error("row limit");
                auto& z=out[key];
                for(auto a:A)for(auto b:B)z+=(a.value*b.value)*
                    (phase*moment({q.first+8*h,q.second+8*h,a.a,a.b,b.a,b.b}));
            });
            peak=std::max(peak,U64(out.size()));
            for(const auto& [key,z]:out)if(z){
                auto [u,v,m]=key;nnz++;
                std::cout<<h<<' '<<q.first<<' '<<q.second<<' '<<u<<' '<<v<<' '<<m<<' '<<z.re<<' '<<z.im<<'\n';
            }
        }
        std::cerr<<"anchor "<<h<<" rows "<<nnz<<" allocated pair peak "<<peak<<'\n';
    }
}
