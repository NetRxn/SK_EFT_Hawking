import ast,os,sys,inspect
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations_with_replacement,product
from math import factorial,prod
from pathlib import Path

sys.path.insert(0,str(Path("INDEPENDENT").absolute()))
scratch=Path.cwd()
os.chdir("INDEPENDENT")
from contract import same,mixed,integrate,final_three,occupancy,profile,local,enc,inv
source=ast.parse(Path("project.py").read_text())
source.body=[node for node in source.body if isinstance(node,(ast.FunctionDef,ast.Import,ast.ImportFrom))]
exec(compile(source,"project.py","exec"))
os.chdir(scratch)

def read(path):
    return (tuple(map(int,row.split())) for row in Path(path).open())
def plus(a,b):return a[0]+b[0],a[1]+b[1]
def times(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def conj(a):return a[0],-a[1]
# Preserve the independent join schedule while checking the batch's tighter
# declared resource caps at the points where it launches arithmetic.
def tighten(text, pairs):
    for before,after in pairs:
        assert text.count(before)==1, before
        text=text.replace(before,after)
    return text

class Refusal(RuntimeError):
    pass
def guard(condition,resource):
    if not condition:
        raise Refusal(resource)
env=dict(integrate.__globals__)
env['guard']=guard
exec(tighten(inspect.getsource(final_three),[
    ('    choices=[]','    guard(sum(len(t) for _,t in fs)<=150000, ("closing resident rows",sum(len(t) for _,t in fs)))\n    choices=[]'),
    ('    assert cost<=8_000_000','    guard(cost<=2_000_000, ("closing products",cost))\n    height=sum(max((max(abs(x),abs(y)).bit_length()+1 for x,y in t.values()),default=0) for _,t in fs)\n    guard(height+cost.bit_length()<=384, "closing height")')
]),env)
exec(tighten(inspect.getsource(integrate),[
    ('        assert n<=5_000_000,(A,B,n)','        guard(n<=2_000_000, ("join products",n))\n        height=sum(max((max(abs(x),abs(y)).bit_length()+1 for x,y in t.values()),default=0) for t in (X,Y))\n        guard(height+n.bit_length()<=384, "join height")'),
    ('                collect(out,k,mul(z,w))','                guard(k in out or len(out)<150000, "join rows")\n                collect(out,k,mul(z,w))'),
    ('        assert peak<300_000','        guard(peak<=150_000, ("factor rows",peak))')
]),env)
integrate=env['integrate']
widths=(1,3,3,4)
def selected_cases():
    residual=list(read('accepted-same-owner-residual.tsv'))
    assert len(residual)==10410==len({(a,b) for a,b,_ in residual})
    assert sum(w for _,_,w in residual)==899691
    for a,b,w in residual:
        occ=occupancy(a)+occupancy(b)
        if any(n&1 for row in occ for n in row):continue
        graphs,forced,domains=projection(a,b,2)
        live=[s for s,g in enumerate(graphs) if g]
        if len(live)!=1:continue
        side=live[0]
        core=graphs[side]
        if len(core)!=4:continue
        arrows=[((u,v,k) if x else (v,u,k)) for (u,v,k),(x,y) in core.items()
                if (x,y) in ((0,2),(2,0))]
        if len(arrows)!=4:continue
        out={u:(v,k) for u,v,k in arrows}
        incoming={v:u for u,v,k in arrows}
        if len(out)!=4 or out.keys()!=incoming.keys():continue
        start=min(out)
        walk=[start]
        for _ in range(4):walk.append(out[walk[-1]][0])
        if len(set(walk[:4]))!=4 or walk[-1]!=start:continue
        edges=[profile(n)[2] for n in (a,b)]
        if any(sorted(load) not in ([0,2],[0,4],[2,2]) for E in edges for load in E.values()):
            continue
        if not all(sorted(edges[side].get(e,())) in ([0,2],[0,4]) and
                   sorted(edges[1-side].get(e,())) in ([0,2],[0,4],[2,2]) for e in core):
            continue
        overlap=sum(edges[1-side].get(e)==(2,2) for e in core)
        if overlap:yield (a,b),w,side,walk[:4],forced,out,overlap

q=defaultdict(dict)
for o,h,d,k,w,m,i,j,r,s in read('spatial.tsv'):
    q[o,h,d,k][w,m,i,j]=(r,s)
mixed_square=defaultdict(dict)
for h,k,lw,rw,m,i,j,r,s in read('mixed-matrices.tsv'):
    mixed_square[h,k][lw,rw,m,i,j]=(r,s)
root_table=defaultdict(list)
for a,b,c,d,k,i,j,r,s in read('root.tsv'):
    root_table[k].append(((a,b),(c,d),i,j,(r,s)))

def factors(codes,roots,side,k,mutation,fixed):
    occ=occupancy(codes[side]);edges=profile(codes[side])[2]
    incident=defaultdict(list)
    factors=[]
    den=1
    for edge,(a,b) in sorted(edges.items()):
        u,v,axis=edge
        active=(roots.get(u)==(v,axis) or roots.get(v)==(u,axis))
        d=a+b
        if active:
            owner=int(bool(b)); anchor=int(roots.get(v)==(u,axis))
            data={}
            if a==b==2:
                rows=mixed_square[anchor,k].items()
            else:
                assert not(a and b)
                rows=(((0 if owner else w,w if owner else 0,m,i,j),z)
                      for (w,m,i,j),z in q[owner,anchor,d,k].items())
            for (left_word,right_word,m,i,j),coefficient in rows:
                state=(i,j) if anchor else (j,i)
                if any(x in fixed and fixed[x]!=p for x,p in zip((u,v),state)):continue
                if side==1 and mutation!='missing-conjugation':coefficient=conj(coefficient)
                if mutation=='all-conjugated':coefficient=conj(coefficient)
                key=((left_word,m&255,state[0]),(right_word,m>>8,state[1]))
                assert key not in data
                data[key]=coefficient
            den*=192*4**d
        else:
            if a and b:
                assert a==b==2
                data=mixed
            else:data=same[d] if a else {(y,x):z for (x,y),z in same[d].items()}
            if mutation=='all-conjugated':data={key:conj(z) for key,z in data.items()}
            den*=64 if d==2 else 12288
        wires=((u,v,0),(u,v,1))
        guard(sum(len(t) for _,t in factors)+len(data)<=150000, ('initial edge rows',side,k,u,v))
        factors.append((wires,data))
        for x,wire in zip((u,v),wires):
            slot=(0 if u==x else 1)
            avail=defaultdict(set)
            for row in data:
                w,m,i=row[slot]
                assert m.bit_count()==d
                avail[w,i].add(m)
            p=(int(roots[x]==(v if x==u else u,axis)) if active else -1)
            incident[x].append((wire,axis,p,avail))
    max_site_work=0
    for x,row in enumerate(occ):
        choices=[]
        if side==1 and x in roots:
            axis=roots[x][1]
            assert row[axis]==2
            scalar_row=tuple(0 if k==axis else n for k,n in enumerate(row))
            p,q1=[a for a in range(3) if a!=axis]
            for w1,w2,i,j,z in root_table[k]:
                if mutation=='all-conjugated':z=conj(z)
                for (_,base),scalar in local(scalar_row,-1,-1).items():
                    words=list(base)
                    words[p]=tuple(sorted(words[p]+w1))
                    words[q1]=tuple(sorted(words[q1]+w2))
                    choices.append((tuple(map(enc,words)),(j,i),times(z,scalar)))
        else:
            for (_,words),z in local(row,-1,-1).items():
                if mutation=='all-conjugated':z=conj(z)
                indices=([fixed[x]] if x in fixed else range(widths[k] if side==0 and x in roots else 1))
                for i in indices:
                    choices.append((tuple(map(enc,words)),(i,i),z))
        table={}
        plans=[]
        for words,indices,z in choices:
            labels=[(words[a],indices[p] if p>=0 else 0) for _,a,p,_ in incident[x]]
            groups=[D.get(s,()) for (_,_,_,D),s in zip(incident[x],labels)]
            if not all(groups):continue
            order=sorted(range(len(groups)),key=lambda i:len(groups[i]))
            plans.append((groups,order,labels,z))
        work=sum(prod(len(groups[i]) for i in order[:-1]) for groups,order,_,_ in plans)
        guard(work<=2_000_000, ('site complement work',work))
        max_site_work=max(max_site_work,work)
        for groups,order,labels,z in plans:
            for prefix in product(*(groups[i] for i in order[:-1])):
                mask=0
                for a in prefix:
                    if mask&a:break
                    mask|=a
                else:
                    complement=255^mask
                    if complement not in groups[order[-1]]:continue
                    masks=dict(zip(order,(*prefix,complement)))
                    ordered=list(map(masks.__getitem__,range(len(masks))))
                    exponent=sum(inv(a,b) for i,a in enumerate(ordered) for b in ordered[i+1:])
                    if mutation=='omit-wedge' and side==1 and x==0:exponent=0
                    signed=z if exponent%2==0 else (-z[0],-z[1])
                    key=tuple((w,m,i) for (w,i),m in zip(labels,ordered))
                    table[key]=plus(table.get(key,(0,0)),signed)
                    guard(len(table)<=150000, ('site factor rows',len(table)))
        factors.append((tuple(wire for wire,_,_,_ in incident[x]),{k:v for k,v in table.items() if any(v)}))
    guard(sum(len(t) for _,t in factors)<=150000, ('initial resident rows',sum(len(t) for _,t in factors)))
    return factors,den,max_site_work

def value(codes,roots,side,channel,mode,fixed):
    network,den,sites=factors(codes,roots,side,channel,mode,fixed)
    val,peak,work=integrate(network,mode=='reverse')
    print('layer',side,channel,'denominator',den,'peak',peak,'work',work,'site work',sites,
          'initial resident',sum(len(t) for _,t in network),'fixed',fixed,flush=True)
    return tuple(F(z,den) for z in val)

def run(codes,weight,cycle,roots,mode,tiled):
    numerator=prod({2:2,4:10}[n] for t,code in enumerate(codes) for x,row in enumerate(occupancy(code)) for axis,n in enumerate(row)
                   if n and not(t==1 and x in roots and roots[x][1]==axis))
    denominator=prod(factorial(n) for code in codes for row in occupancy(code) for n in row)
    print('normalization',numerator,denominator,F(numerator,denominator))
    total=F(0)
    for k,d in enumerate(widths):
        if not tiled or d==1:
            try:
                remote=value(codes,roots,0,k,mode,{})
                use_tiles=False
            except Refusal as error:
                print('guarded direct refusal',k,repr(error),flush=True)
                if mode=='direct-probe':return
                use_tiles=True
        else:use_tiles=True
        if use_tiles:
            cut=cycle[1],cycle[3]
            terms=[value(codes,roots,0,k,mode,dict(zip(cut,key)))
                   for key in product(range(d),repeat=2)]
            assert len(terms)==d*d
            remote=tuple(sum(z[i] for z in terms) for i in range(2))
            print('partition',k,cut,len(terms),remote,flush=True)
        own=value(codes,roots,1,k,mode,{})
        layers=[remote,own]
        r,i=times(*layers)
        assert i==0
        result=F(numerator,denominator*d**4)*r
        print(k,layers,result,flush=True)
        total+=result
    print('total',mode,total,flush=True)

all_cases=list(selected_cases())
assert {side:sum(r[1] for r in all_cases if r[2]==side) for side in (0,1)}=={0:1152,1:2544}
cases=sorted((r for r in all_cases if r[2]==1),key=lambda r:(r[-1],r[0]))
assert len(cases)==28 and sum(x[1] for x in cases)==2544
if sys.argv[1:]==['census']:
    from collections import Counter
    print('both core layers',Counter(r[2] for r in all_cases))
    for (a,b),w,side,cycle,forced,roots,overlap in sorted(all_cases,key=lambda r:(r[2],r[-1],r[0])):
        print(a,b,w,side,overlap,cycle,forced)
    sys.exit()
start=int(sys.argv[1]) if len(sys.argv)>1 else 0
stop=int(sys.argv[2]) if len(sys.argv)>2 else len(cases)
mode=sys.argv[3] if len(sys.argv)>3 else 'ordinary'
for index,(codes,w,side,cycle,forced,roots,overlap) in enumerate(cases):
    if not start<=index<stop:continue
    assert side==1
    print("case",*codes,w,side,overlap,cycle,forced,flush=True)
    run(codes,w,cycle,roots,mode,index>=25 and mode!='direct-probe')
