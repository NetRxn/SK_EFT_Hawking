Restore the pilot author and independent inputs using the sibling
L1_N16_C0_DIRECTED_SQUARE_PILOT_R1.zip archive and its instructions.
Put mixed-owner/ in that restored author root. Point the new independent/
links AUTHOR, INDEPENDENT, frozen, root.tsv and spatial.tsv at the restored
pilot locations. The prior exact files and evaluator outputs are included.
Verify the manifests and follow independent/REVIEW.md for replay commands.
The new residual removes only the 28 independently accepted B-core rows.
