#define main reference_main
#include "slice_reference.cpp"
#undef main
#include <map>
#include <span>

// The four independent S3 variables are distinguished by anchor and chirality.
int scaled_moment(std::span<const int> indices) {
    std::array<int,16> exponent{};
    for(int i:indices) ++exponent.at(i);
    int numerator=1,denominator=1;
    for(int group=0;group<4;++group){
        int degree=0;
        for(int i=4*group;i<4*group+4;++i){
            if(exponent[i]%2) return 0;
            degree+=exponent[i];
            for(int k=1;k<exponent[i];k+=2) numerator*=k;
        }
        for(int k=0;k<degree;k+=2) denominator*=4+k;
    }
    if(192*numerator%denominator) throw std::runtime_error("Haar scale is not integral");
    return 192*numerator/denominator;
}
int bucket(unsigned p){
    if(!p)return 0;
    if(std::popcount(p)!=2)return -1;
    int a=std::countr_zero(p),b=std::countr_zero(p&(p-1));
    return 1+16*a+b;
}
unsigned qmask(int p){
    if(!p)return 0;
    --p;return (1U<<(p/16))|(1U<<(p%16));
}

int main(){
  const auto src=read_coframes();
  std::map<std::pair<int,int>,U64> multiplicity;
  std::ifstream spin("adjoint.tsv"),cross("fundamental-product.tsv");
  int a,b,i,j,r,s;
  while(spin>>a>>b>>i>>j>>r)
    for(int chi=0;chi<2;++chi)++multiplicity[{4*chi+i,4*chi+j}];
  while(cross>>a>>b>>i>>j>>r>>s)++multiplicity[{i,j}];
  U64 monomials=0;
  for(const auto& [pair,weight]:multiplicity)monomials+=weight;
  if(monomials!=112||multiplicity.size()!=36)throw std::runtime_error("source roster");
  std::array<std::array<QuadRoster,16>,2> P;
  std::vector<int> words;
  for(int x=0;x<2;++x)
    for(int u=0;u<4;++u)
      for(int v=u;v<4;++v)P[x][4*u+v]=square_pair(src[x][u],src[x][v]);
  for(int u=0;u<4;++u)for(int v=u;v<4;++v)words.push_back(4*u+v);

  auto buckets=[&](int q0,int q1,auto visit){
    unsigned parity=(1U<<q0)^(1U<<q1);
    for(int u:words)for(int v:words)for(int p=0;p<257;++p){
      int other=bucket(qmask(p)^parity);
      if(other>=0)visit(u,v,P[0][u][p],P[1][v][other]);
    }
  };
  for(int anchor=0;anchor<2;++anchor){
    U64 raw=0,cached=0,peak=0;
    for(const auto& [pair,weight]:multiplicity){
      U64 work=0;
      buckets(pair.first+8*anchor,pair.second+8*anchor,
        [&](int,int,const auto& x,const auto& y){work+=U64(x.size())*y.size();});
      raw+=work*weight; cached+=work; peak=std::max(peak,work);
    }
    std::cerr<<"anchor "<<anchor<<" raw products "<<raw<<" cached products "<<cached
             <<" peak pair products "<<peak<<'\n';
    if(cached>MAX_MOMENT_PAIRS)throw std::runtime_error("cached product cap");
    // The candidate product count and the four unit-coframe factors imply
    // an absolute numerator bound of 192 * 64^4 * cached.
    if(I128(192)*64*64*64*64*cached>=(I128(1)<<62))
      throw std::runtime_error("coefficient mass cap");
  }
  for(int anchor=0;anchor<2;++anchor){
    U64 nonzero=0,peak=0;
    for(const auto& [pair,weight]:multiplicity){
      (void)weight;
      int q0=pair.first+8*anchor,q1=pair.second+8*anchor;
      std::map<unsigned,Z> rows;
      buckets(q0,q1,[&](int u,int v,const auto& X,const auto& Y){
        for(const auto& A:X)for(const auto& B:Y){
          if(A.mask&B.mask)continue;
          unsigned key=(u<<20)|(v<<16)|A.mask|B.mask;
          if(!rows.contains(key)&&rows.size()>=150000)throw std::runtime_error("row cap");
          int weight=sign(A.mask,B.mask)*scaled_moment(std::array{q0,q1,A.a,A.b,B.a,B.b});
          rows[key]+=(A.value*B.value)*weight;
        }
      });
      peak=std::max(peak,U64(rows.size()));
      for(const auto& [key,z]:rows)if(z){
        ++nonzero;
        std::cout<<anchor<<' '<<pair.first<<' '<<pair.second<<' '
                 <<(key>>20)<<' '<<((key>>16)&15)<<' '<<(key&65535)<<' '
                 <<z.re<<' '<<z.im<<'\n';
      }
    }
    std::cerr<<"anchor "<<anchor<<" nonzero "<<nonzero<<" peak allocated "<<peak<<'\n';
  }
}
