from collections import defaultdict
from pathlib import Path

source=defaultdict(list)
for line in Path("AUTHOR/adjoint.tsv").open():
    row,col,i,j,z=map(int,line.split())
    for c in range(2):
        source[tuple(sorted((4*c+i,4*c+j)))].append((c+1,row,col,z,0))
for line in Path("AUTHOR/fundamental-product.tsv").open():
    row,col,i,j,r,s=map(int,line.split())
    source[tuple(sorted((i,j)))].append((3,row,col,r,s))
assert len(source)==36 and sum(map(len,source.values()))==112
reference={}
for line in Path("AUTHOR/mixed.tsv").open():
    u,v,lo,hi,r,s=map(int,line.split())
    reference[u,v,lo|(hi<<8),0,0]=(4*r,4*s)
with Path("mixed-owner/matrices.tsv").open("w") as output:
    for anchor in range(2):
        for channel in range(4):
            terms=defaultdict(list)
            for (i,j),rows in source.items():
                terms[i,j].extend(row[1:] for row in rows if row[0]==channel)
                if channel==0 and i==j and i<4:terms[i,j].append((0,0,1,0))
            acc={}
            work=0
            for line in Path("mixed-owner/signed-mask.tsv").open():
                h,i,j,u,v,mask,a,b=map(int,line.split())
                if h!=anchor:continue
                for row,col,c,d in terms[i,j]:
                    work+=1
                    if work>2_000_000:raise RuntimeError("assembly product cap")
                    key=u,v,mask,row,col
                    prev=acc.get(key)
                    if prev is None:
                        if len(acc)>=150000:raise RuntimeError("assembly row cap")
                        prev=0,0
                    acc[key]=prev[0]+a*c-b*d,prev[1]+a*d+b*c
            live={k:v for k,v in acc.items() if any(v)}
            if channel==0:assert live==reference,(anchor,len(live),len(reference))
            for k,z in sorted(live.items()):
                output.write(" ".join(map(str,(anchor,channel,*k,*z)))+"\n")
            print(anchor,channel,len(acc),len(live),work,flush=True)
