"""Retally the original selected side of component 98 from reviewed evidence."""
from ast import literal_eval
from collections import Counter
from csv import DictReader
from fractions import Fraction
from io import BytesIO
from pathlib import Path
from sys import argv
from zipfile import ZipFile

source=Path(argv[1])
prepared=source/'L1_N16_C0_DENSE_COMPONENT98_PREPARATION_R1.zip'
geometry=source/'L1_N16_C0_DENSE_GEOMETRY_COVER_R1.zip'
with ZipFile(geometry) as root, ZipFile(BytesIO(root.read('ACTUAL_REVIEW.zip'))) as checked:
    with ZipFile(BytesIO(checked.read('candidate.zip'))) as candidate:
        lines=candidate.read('components.tsv').decode().splitlines()
        rows=list(DictReader(lines,delimiter='\t'))
        comp,=[row for row in rows if row['id']=='98']
        groups=literal_eval(comp['selected_side'])
        mirror=literal_eval(comp['other_side'])
        assert len(set(groups))==len(set(mirror))==8 and set(groups).isdisjoint(mirror)
        assert comp['kind']=='K8,8' and comp['whole_pair_weight']=='192'
        pair_lines=candidate.read('gamma-pairs.tsv').decode().splitlines()[1:]
        pairs={int(row[0]):int(row[1]) for line in pair_lines if (row:=line.split('\t'))}
        assert len(pairs)==1936
        assert len(set(groups+mirror+[pairs[g] for g in groups+mirror]))==32
with ZipFile(prepared) as z:
    p=list(DictReader(z.read('group-preparation.tsv').decode().splitlines(),delimiter='\t'))
    proved_zero={int(r['group']) for r in p if r['scope']=='whole_group_zero'}
    assert proved_zero=={1225,1255}
    assert all(literal_eval(r['zero_original_ordinals'])==list(range(8))
               for r in p if int(r['group']) in proved_zero)

result=Fraction(0)
print('group\tcover_weight\tweighted_exact_real\tweighted_exact_imag')
for group in groups:
    if group in proved_zero:
        total=Fraction(0)
    else:
        receipt=source/f'L1_N16_C0_DENSE_GROUP{group}_COMPLETE_R1.zip'
        if group==1302 and len(argv)>2:
            receipt=Path(argv[2])
        with ZipFile(receipt) as z:
            rows=list(DictReader(z.read('scalar.tsv').decode().splitlines(),delimiter='\t'))
            assert sorted(int(row['ordinal']) for row in rows)==list(range(8))
            values=[]
            for row in rows:
                real=int(row.get('raw_real',row.get('raw_re')))
                imag=int(row.get('raw_imag',row.get('raw_im')))
                den=int(row['factor_denominator'])
                assert den>0 and imag==0
                if int(row['ordinal']) in (5,7):
                    assert real==0
                values.append(Fraction(real,den))
            total=sum(values)*192/(16*4**64)
    print(group,192,total,0,sep='\t')
    result+=total
print('original selected groups',','.join(map(str,groups)))
print('original mirror groups',','.join(map(str,mirror)))
print('original selected-side cover contribution',result,0)
