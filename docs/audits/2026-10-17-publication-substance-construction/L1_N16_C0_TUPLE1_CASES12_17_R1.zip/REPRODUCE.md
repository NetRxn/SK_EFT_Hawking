# Shared tuple 1 child cases 12–17

Restore separator.zip and child-equality.zip from the Git blobs pinned in
SOURCE_PINS.txt. Run `sh rehydrate.sh` on a fresh extraction to regenerate
the 60 pinned author inputs. Use trusted original inputs for deserialization.
Follow REVIEW.md for the independent lineage and terminal replays.

Verify preceding-twelve.tsv against twelve-term-retally.tsv from the tracked
L1_N16_C0_TUPLE1_CASES6_11_R1.zip. Run `python3 retally-eighteen.py` for
the exact eighteen-term partial sum of one shared child. The factor of two
applies only at recombination of the complete tuple contribution.
