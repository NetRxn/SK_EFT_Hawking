#!/bin/sh
set -eu
root=$(pwd)
unzip -p separator.zip row-cap-physical-slice-dense-label-tuple1-0b-reduced.pkl.gz | gzip -d >parent.pkl
test "$(shasum -a 256 parent.pkl | cut -d' ' -f1)" = 843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077
for n in 12 13 14 15 16 17; do
    mkdir -p "$root/inputs/$n/checkpoint"
    cd "$root/inputs/$n"
    cp "$root/author/"*.py .
    cp "$root/author/checkpoint/quotient.py" checkpoint/
    python3 -u exact-multicut.py "$root/parent.pkl" input.pkl "$n" >plan.out
    python3 -u reduce-label-frontier.py input.pkl primary >reduce.out
    rc=0
    python3 -u contract-reduced-label.py primary >contract.out || rc=$?
    test "$rc" -eq 2
    python3 -u reduce-label-frontier.py row-cap-physical-slice-dense-label-primary-reduced.pkl rescue >rescue-reduce.out
    python3 -u contract-peer.py rescue >rescue-contract.out
done
cd "$root"
shasum -a 256 -c frozen-inputs.sha256
