# Dense tuple 1 shared-child cases 12–17 independent exact review

The six independently replayed terms give exact subtotal **-84036208057780682914317 / 649037107316853453566312041152512 + 0i**. Each case retains its own cut, saved checkpoint and signed scalar receipt, including pairs with equal values.

| Case | Coordinate | Exact normalized real | Imaginary |
| --- | --- | --- | --- |
| 12 | (17, (1,)) | -141126116119491656797227/5192296858534827628530496329220096 | 0 |
| 13 | (17, (2,)) | -390040090193769054352731/10384593717069655257060992658440192 | 0 |
| 14 | (24, (1,)) | -141126116119491656797227/5192296858534827628530496329220096 | 0 |
| 15 | (24, (2,)) | -390040090193769054352731/10384593717069655257060992658440192 | 0 |
| 16 | (33, (1,)) | 507195665631231180615/5192296858534827628530496329220096 | 0 |
| 17 | (33, (2,)) | -252268847562163273983/2596148429267413814265248164610048 | 0 |

At checkpoint 129f9eb70729ac629792ea847e93b74f149f699c, the original separator archive pins the six-factor tuple1-0b parent to uncompressed SHA256 843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077. Independent support matching on parent pair (0, 1) recovers the 36 supported coordinates on G(0,0,2) and J(1,4,2), with 6,838,272 compatible products. All six stated coordinates have 213,696 compatible products each. The census and order match all six author records. Each inverse lift recovers the restricted parent tables, signed coefficients and denominators.

The independent lineage code regenerates the first reduction, the completed 44,964-product and 3,042,432-product preliminary joins, the complete state at each row-cap refusal, and the rescued terminal factor tables. The refused join forecasts are 5,524,480 for 12 and 14, 4,392,960 for 13 and 15, 5,277,312 for 16, and 4,192,512 for 17. Each cut and each rescue input has a distinct hash. The roster and six lineages took 82.54 seconds.

The independent terminal implementation uses ordinary sparse Gaussian-integer joins with separate inputs and a different contraction schedule from the author's quotient and peer projection passes. The replays used 543,240 to 573,360 products and 25,872 to 25,920 peak output rows per case. Each ran for 0.51 to 0.55 seconds. Per-case replay logs preserve each exact raw numerator and denominator. The signed rationals apply the factor denominator and positive external scale 1/(16*4^64) once.

The committed child equality binds both coarse siblings to the common 36-case contraction. This review covers the six named terms in dense group 128 descendant (0, 0). Recombining the two equal child contractions remains a later step.

Keep the relative inputs/ and replays/ directories with the evidence. Restore separator.zip and child-equality.zip from the committed objects identified in SOURCE_PINS.txt. Run shasum -a 256 -c frozen-inputs.sha256, python3 verify-lineage.py, sh replay-terminals.sh 12 13 14 15 16 17 and python3 verify-aggregate.py. The supplied input and review manifests use relative paths.
