from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json
import re
import sys

def read(name):
    return [json.loads(line) for line in (Path(sys.argv[1]) / name).read_text().splitlines()]

def scalar(value):
    m = re.fullmatch(r"QComplex\(storage=\((-?\d+), (\d+), (-?\d+), (\d+)\)\)", value)
    assert m, value
    x, y, z, w = map(int, m.groups())
    return F(x, y), F(z, w)

def plus(*values):
    return tuple(map(sum, zip(*values, strict=True)))

def nonzero(value):
    return any(value)

def inspect(row):
    assert row["qualified"] <= 12 and row["attempt"] <= 2048
    target = row["target"]
    assert int(target["mask_hex"], 16).bit_count() == 22
    assert Counter(family for family, _ in target["symbols"]) == {"q": 23, "J": 1, "g1": 1, "g2": 3}
    v = scalar(row["witness"])
    frames = list(map(scalar, row["frame_coefficients"]))
    if not frames:
        assert not nonzero(v) and not row["asymmetric"]
        return {"labelled": False, "base": False}
    assert len(frames) == 4 and nonzero(v)
    base, x_pair, y_pair, orbit = frames[0], plus(*frames[:2]), plus(frames[0],frames[2]), plus(*frames)
    qualifies = all(map(nonzero, (base,x_pair,y_pair,orbit)))
    assert qualifies == row["asymmetric"]
    return dict(labelled=True, base=nonzero(base), x_zero=not nonzero(x_pair), y_zero=not nonzero(y_pair),
                orbit_zero=not nonzero(orbit), orbit=[str(v) for v in orbit], qualifies=qualifies)

admitted = read("targets.jsonl")
assert len(admitted) == 4
assert [inspect(row)["orbit"] for row in admitted] == [["0","0"], ["0","-1/16384"], ["0","1/16384"], ["0","0"]]
rejected = read("discovery.rejected.jsonl")
findings = {}
for direction, expected, charges in ((0, (10,1), 922590),(1,(11,3),1327277)):
    observed = [row for row in rejected if row["degrees"] == [4,2] and row["direction"] == direction and "target" in row
                and row["target"]["slot"] == [0,1]]
    assert [row["qualified"] for row in observed] == list(range(1,13))
    entries = [inspect(row) for row in observed]
    assert all(not entry.get("qualifies") for entry in entries)
    assert (sum(entry["labelled"] for entry in entries), sum(entry["base"] for entry in entries)) == expected
    assert all((not entry["base"]) or entry["x_zero"] or entry["y_zero"] for entry in entries)
    assert any(row.get("error") == "mixed power qualified cap" and row["work"] == charges
               and row["degrees"] == [4,2] and row["direction"] == direction for row in rejected)
    findings[direction] = dict(labelled_nonzero=expected[0], base_nonzero=expected[1], cap_charges=charges,
                               nonzero_base_rows=[row["qualified"] for row, entry in zip(observed, entries, strict=True)
                                                  if entry["base"]])
print(json.dumps(dict(admitted_orbits=[inspect(row)["orbit"] for row in admitted], rejected=findings),sort_keys=True))
