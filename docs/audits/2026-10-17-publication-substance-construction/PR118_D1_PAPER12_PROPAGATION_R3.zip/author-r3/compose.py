import ast
from pathlib import Path
import subprocess

draft = Path("papers/D1/paper_draft.tex")
s = draft.read_text()
def replace(old, new):
    global s
    assert s.count(old) == 1, old
    s = s.replace(old, new)
def span(start, end, new):
    global s
    a = s.index(start)
    b = s.index(end, a)
    s = s[:a] + new + s[b:]

replace(r"""condensates, a closed-form current-noise excess whose feasibility is
independent of the quantum-critical conductance for the Dirac fluid, and""", r"""condensates, a modeled current-noise excess whose ratio to ideal thermal
noise cancels the common conductance factor for the Dirac fluid, and""")
replace(r"""$c_s = v_F/\sqrt{2}$.

Replacing""", r"""$c_s = v_F/\sqrt{2}$. Physical transfer of scattering and readout
requires matching the dynamics and boundary conditions.

Replacing""")
span("for a total below two per", r"\subsection{Subluminal", r"""for an illustrative total of about $1.8\%$ at $\omega_H$ under the
adopted envelopes and geometry. Ref.~\cite{Geurs2025} quotes
$\ell_{ee} \sim 100$~nm as a scale for the width of the hydraulic jump.
Doubling the adopted $\ell_{ee}$ gives a total of about $2.6\%$ at the
same frequency. A physical error bound over the working band still
requires matching the inputs to the operating device.

""")
span("The observable here is", r"\begin{equation}", r"""The proposed observable is excess current noise. We adopt a leading
electrical response with a channel normalization motivated by
fluctuation--dissipation and scattering analogies~\cite{Roehm2026Wave16},
""")
span(r"Sec.~\ref{sec:hierarchy}. Equation~\eqref{eq:noise_psd} is obtained", "Two further statements", r"""Sec.~\ref{sec:hierarchy}. The electrical coupling of the collective
modes and the physical matching of the two analogies require a separate
derivation.

Equation~\eqref{eq:noise_psd} is the definition
\texttt{GrapheneNoiseFormula.hawkingNoisePSD}. It is positive for
positive inputs (\texttt{hawkingNoisePSD\_pos}) and monotone in the
greybody factor (\texttt{hawkingNoisePSD\_greybody\_mono}), so
$\Gamma \leq 1$ bounds the modeled signal from above. Substituting
$\Gamma = 1$ gives $2\hbar\omega\,\sigma_Q n_H$
(\texttt{fdt\_consistency}). This substitution provides an algebraic
comparison to the fluctuation--dissipation analogy. """)
span(r"The background against which Eq.", r"\begin{equation}", r"""For the ideal thermal reference we take the Johnson--Nyquist noise
$S_{\rm JN} = 4 k_B T_e \,\sigma_Q$ (\texttt{johnsonNyquistPSD}).
The modeled per-bin ratio is
""")
span("conductance has disappeared from it.", "The quantum-critical conductance", r"""conductance cancels from this ratio. The companion
\texttt{snr\_independent\_of\_sigma\_Q} gives the same ratio for any two
nonzero conductances because both terms share the same factor.
Absolute signal levels and sensitivity in the presence of additional
noise sources require a calibrated readout.

""")
span("That violation is the", r"\subsection{Detection at the Dean device}", r"""This transport measurement concerns the decoupling of charge and heat.
The devices of Ref.~\cite{Majumdar2025} are monolayers encapsulated in
hexagonal boron nitride, whereas the nozzle of Ref.~\cite{Geurs2025} is
bilayer. We use $\sigma_Q \approx 4e^2/h$ as a cross-device model input.
The Wiedemann--Franz measurement supplies transport context. Testing
the adopted noise response requires an operating-point conductance
measurement and independent transfer and noise calibration.

""")
span("Its content is the band separation", r"\begin{equation}" + "\n" + r"\Gamma_0", r"""It supplies the transverse threshold comparison at the assumed width.
A physical validity bound for the device also depends on its channel
structure and on the evanescent and other corrections over the band.

The infrared transmission in the hydrodynamic BEC model is
""")
span("a result of Anderson", r"\begin{figure}[t]", r"""from Eq.~(36) of Anderson \emph{et al.}~\cite{AndersonBFP2014Graybody}.
The calculation assumes stationary constant flow and density,
transverse freezing, and a smooth sound speed with fixed asymptotes.
Here $c_R$ denotes the exterior asymptotic sound speed. The scalar lies
in $[0,1]$ for positive inputs and equals one when $c_R=v$
(\texttt{greybody\_zero\_freq\_nonneg},
\texttt{greybody\_zero\_freq\_le\_one},
\texttt{greybody\_zero\_freq\_eq\_one}).
Adopting $c_R \approx c_s$ and $v/c_R=0.985$ gives
$\Gamma_0 \approx 0.99994$. A finite-frequency graphene transmission
law needs separate physical matching.

For the leading occupation in Eq.~\eqref{eq:snr_bin} the ideal ratio
has the low-frequency limit
\begin{equation}
\frac{\Delta S_I}{S_{\rm JN}} \;\longrightarrow\;
\frac{\Gamma_0\,T_H}{2\,T_e} \;\approx\; 8\times10^{-3}.
\end{equation}
Figure~\ref{fig:snr} instead samples the corrected model, which adds a
noise floor to the corrected occupation and uses an adopted
frequency-dependent transmission. Its denominator is the ideal
Johnson--Nyquist reference.

""")
span(r"\caption{Per-bin ratio of the Hawking", r"\label{fig:snr}", r"""\caption{Sampled current-noise model relative to ideal Johnson--Nyquist
noise at the adopted Dean bilayer-nozzle inputs. The occupation is
$\beta^2/(1-\delta_K)+n_{\rm noise}$, with effective-temperature Planck
factor $\beta^2$, adopted Keldysh correction $\delta_K$ and added floor
$n_{\rm noise}$. Transmission includes an adopted frequency roll-off.
At $T_e=150$~K and $\sigma_Q\approx 4e^2/h$, the ideal reference is
$S_{\rm JN}\approx 1.3\times10^{-24}$~$\mathrm{A^2/Hz}$. The annotation
gives the separate leading low-frequency limit
$\Gamma_0 T_H/(2T_e)$. Device sensitivity requires measured
transmission, detector response and background noise.}
""")
span("A radiometric measurement", r"\section{Exciton-polariton", r"""For independent bins and ideal stationary noise the radiometric scaling
is $t = 1/(\mathrm{SNR}_{\rm bin}^2\Delta f)$ at unit cumulative
signal-to-noise for bin width $\Delta f$. The estimate excludes gain
drift, calibration uncertainty and correlated noise.

A working band $\omega/\omega_H \in [0.5,4]$ requires measured
transmission, dispersion, channel geometry and electrical response.
Unknown transmission, detector gain and residual background can alter
both shape and normalization. One uncalibrated spectrum cannot
independently identify $T_H$ and $\sigma_Q$. With an independently
measured sonic gradient and operating-point conductivity, and with
transmission, transfer and noise calibrated, the fitted temperature and
normalization can test the temperature law and the adopted response.
The companion letter~\cite{Roehm2026E2} gives the device-specific model
and calibration requirements.

""")
replace(r"""dissipation-dominated configuration. The Dirac fluid delivers a
closed-form current-noise excess whose feasibility estimate is
insensitive to the least-controlled transport coefficient in it. The""", r"""dissipation-dominated configuration. For the Dirac fluid the adopted
current-noise model gives a ratio to ideal thermal noise in which the
common conductance cancels. Physical sensitivity requires calibration. The""")
e2 = Path("papers/E2/paper_draft.tex").read_text()
start = e2.index(r"\bibitem{AndersonBFP2014Graybody}")
end = e2.index(r"\bibitem{Blanter2000}", start)
span(r"\bibitem{AndersonBFP2013}", r"\bibitem{Roehm2026Wave1}", e2[start:end])
draft.write_text(s)

legacy = Path("papers/paper12_polariton/paper_draft.tex")
s = legacy.read_text()
replace(r"""steep-horizon results are quoted as the platform's demonstrated upper reach.
At steep horizon, $D = 0.93$ places the system in the non-perturbative
regime where the leading $-\pi D^2/6$ correction is $\sim$46\%, so those
predictions are leading-order only.""", r"""At the steep-horizon input $D=0.93$, the adopted term $-\pi D^2/6$ is
approximately $-46\%$. A physical truncation error remains to be
established.""")
replace(r"""\item Quasinormal mode resonances~\cite{Jacquet2023QNM,Burkhard2025}
--- unique to the driven-dissipative setting --- concentrate the
stimulated signal at specific frequencies, providing enhanced
detection windows.""", r"""\item The cited quasinormal mode studies~\cite{Jacquet2023QNM,Burkhard2025}
motivate looking for resonant structure. Using a resonance to choose a
probe frequency requires a calibrated response and noise spectrum.""")
legacy.write_text(s)

producer = Path("src/core/visualizations.py")
def function_span(source):
    node, = (n for n in ast.parse(source).body
             if isinstance(n, ast.FunctionDef) and n.name == "fig_graphene_snr_frequency")
    return node.lineno - 1, node.end_lineno
current = producer.read_text()
donor = subprocess.check_output(["git", "show", "32e8a784d:src/core/visualizations.py"], text=True)
lo, hi = function_span(current)
dlo, dhi = function_span(donor)
producer.write_text("".join(current.splitlines(keepends=True)[:lo] +
                            donor.splitlines(keepends=True)[dlo:dhi] +
                            current.splitlines(keepends=True)[hi:]))
