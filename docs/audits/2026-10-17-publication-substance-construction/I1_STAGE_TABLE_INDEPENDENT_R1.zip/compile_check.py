import json
import re
import sys
from pathlib import Path
from scripts.compile_bundle_pdf import compile_one
from scripts.render_paper_tables import spec_output_paths

root=Path(sys.argv[1]).resolve()
d=Path("papers/I1").resolve()
r=Path(sys.argv[2])
status,message,pages=compile_one(d,force=True,keep=True)
assert status and pages==37,message
tmp=Path(message.rsplit("artifacts kept: ",1)[1].strip())
data=(tmp/"paper_draft.fls").read_text()
(r/"I1.fls").write_text(data)
pwd=Path(next(l[4:] for l in data.splitlines() if l.startswith("PWD ")))
files={(pwd/l[6:]).resolve() for l in data.splitlines() if l.startswith("INPUT ")}
owned={x.resolve() for x in spec_output_paths(d/"tables.py")}
rendered={x for x in files if x.is_relative_to(d/"tables") and x.suffix==".tex"}
assert {x.name for x in rendered}=={"table1_stages.tex","table3_finding_classes.tex"}
assert {x.name for x in rendered-owned}==({"table1_stages.tex"} if r.name=="base-receipts" else set())
print(json.dumps({"compile":message,"pages":pages,"rendered":sorted(x.name for x in rendered),"owned":sorted(x.name for x in owned),"orphans":sorted(x.name for x in rendered-owned)},indent=2))
