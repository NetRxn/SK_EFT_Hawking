import hashlib
import json
import re
from pathlib import Path
from scripts import render_paper_tables as renderer

tree=Path.cwd()
source=tree/"docs/WAVE_EXECUTION_PIPELINE.md"
body=source.read_text().split("## Pipeline Overview",1)[1].split("```",2)[1]
pattern=r"^Stage (\d+[ab]?):\s*(.*?)\s+→\s+(Gate|Advisory):\s*(.*)$"
expected=re.findall(pattern,body,re.M)
assert [x[0] for x in expected]==["1","2","3a","3b",*[str(i) for i in range(4,15)]]
assert [x[0] for x in expected if x[2]=="Advisory"]==["14"]
bundle=tree/"papers/I1"
table=bundle/"tables/table1_stages.tex"
neighbor=bundle/"tables/table3_finding_classes.tex"
def rows(text):
    return {
        parts[0].strip(): [part.strip() for part in parts[1:]]
        for line in text.splitlines() if re.match(r"^\d+[ab]?\s+&",line)
        for parts in [re.split(r"(?<!\\)&",line.removesuffix(chr(92)*2))]
    }
parsed=rows(table.read_text())
assert list(parsed)==[x[0] for x in expected]
for number,name,kind,gate in expected:
    clean=lambda s: re.sub(r"[^a-z0-9]+"," ",s.lower()).strip()
    plain=lambda s: s.replace(r"\&","&").replace(r"\_","_")
    assert clean(plain(parsed[number][0]))==clean(name),(number,name,parsed[number][0])
    assert plain(parsed[number][1])==gate,(number,gate,parsed[number][1])
assert "Stage 14 is advisory." in (bundle/"paper_draft.tex").read_text()
frozen={p:p.read_bytes() for p in (table,neighbor)}
spec=renderer._load_spec(bundle/"tables.py")
owned={p.resolve() for p in renderer.spec_output_paths(bundle/"tables.py")}
assert owned=={p.resolve() for p in frozen}
passes=[]
for _ in range(2):
    paths=renderer.render_paper("I1",spec)
    assert {p.resolve() for p in paths}==owned
    assert all(p.read_bytes()==content for p,content in frozen.items())
    passes.append({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
print(json.dumps({"rows":expected,"render_sha256":passes},indent=2))
