from dataclasses import asdict
from pathlib import Path
import json
import sys
from validation.checks import bundles_readiness as b
p=Path(sys.argv[1]).resolve()
b._H.bundle_codes_or_unmeasured=lambda: (["I1"],None)
result={}
for lane in ("base","candidate"):
    b._H.PROJECT_ROOT=p/lane
    b._H.PAPERS_DIR=p/lane/"papers"
    result[lane]={check.__name__:asdict(check()) for check in (
        b.check_bundle_prose_em_dash_free,
        b.check_bundle_reader_facing_voice,
        b.check_bundle_manuscript_length)}
assert all(v["passed"] and v["measured"] for r in result.values() for v in r.values())
pages=[(p/f"{lane}-receipts/pdf.txt").read_text().split("\f") for lane in ("base","candidate")]
diff=[i for i,(a,b) in enumerate(zip(*pages,strict=True),1) if a!=b]
assert diff==[17],diff
print(json.dumps({"scope":result,"pdf_text_differing_pages":diff},indent=2))
