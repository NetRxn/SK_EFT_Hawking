# Independent verification of L1 N16 outer case 42

The review pins publication checkpoint 39ea78cc40757e11fda6430fe237c46345297064 and the seven-factor
parent identified in next-frontiers/inputs.sha256 within
L1_N16_C0_CASES29_31_CLOSURE_R1.zip. The archive manifest verified.
The checked parent SHA256 is
9a0d1da180d9357ce9e3f0d37619de624f568acf88988727356eb06b4d739474.
The archived outer roster maps case 42 to (36, (1,)) on G(0,4,2) and
J(1,4,2), in the first binary child of tuple 0, descendant (0,0),
branch 128.

An independent histogram match on the rejected parent pair (0, 4)
regenerated the complete nine-value cut on G(0,1,2). The disjoint values
cover 2,280,960 matched pair products. Every nonzero complete network
summand must match that pair. Exact inverse lifts recover every compatible
parent row and Gaussian coefficient and preserve each factor denominator.
All terminal inputs retained complete conditioning and the label partition,
degree-two open axes and the positive denominator product.

| Slice | Cut value | Matched parent pair products | Independent normalized real |
|---|---:|---:|---:|
| 0 | 3 | 44,928 | -8215595331806265617025/2596148429267413814265248164610048 |
| 1 | 192 | 62,208 | -14394095842748134149/81129638414606681695789005144064 |
| 2 | 5 | 169,344 | -86746711841561468706345/2596148429267413814265248164610048 |
| 3 | 12 | 200,448 | -46724202631162597712535/649037107316853453566312041152512 |
| 4 | 96 | 248,832 | -25625583662957547421905/1298074214633706907132624082305024 |
| 5 | 144 | 248,832 | -25625583662957547421905/1298074214633706907132624082305024 |
| 6 | 48 | 311,040 | 1291367012248039284243/324518553658426726783156020576256 |
| 7 | 80 | 497,664 | -23158002405203453926611/2596148429267413814265248164610048 |
| 8 | 160 | 497,664 | -23158002405203453926611/2596148429267413814265248164610048 |

All imaginary parts are zero. The exact independent sum is
**-52600891516154856091647/324518553658426726783156020576256 + 0i**.
Equal slice values retain distinct conditioned inputs and SHA256 identities.
Case 42 was derived from (36, (1,)). The archived case 46 has the same
scalar at (68, (1,)) in the prior partial-48.tsv ledger.

Five direct sparse terminal replays passed. The two triangles in
slices 2 and 3 independently used pivot 1 in place of the author's
pivot 0. Slices 2 and 3 cover 18,643,968 and 19,975,680 triples and use
18,752,832 and 20,092,320 Gaussian products, respectively. Each shard
uses at most 2,016,265 products. Recorded wall times were 20.895 s
and 16.976 s, respectively, in the concurrent scratch run.
The four-factor replays in slices 7 and 8 use initial pair (1,2),
with 6,593,616 candidate products, followed by closure on (0,3).
Each uses 27,595,440 Gaussian products across 12 shards, with at most
2,900,784 products per shard and 24,984 entries per block. The author
used initial pair (1,3). The concurrent independent four-factor runs
took 21.924 s and 22.175 s. Both alternate orders agree with the author
raw numerators and normalized fractions. All independent arithmetic
uses the same factor denominator product
40512224221827380280140849737629696 and external normalization
1/(16*4^64), each applied once.

The author shard audit independently checked 32 successful receipts.
Each of the four sharded slices has eight disjoint author intervals
covering its complete pivot or left factor, and summed raw numerators
agree with the author summary and the full independent contraction.
The 17 generic cap refusals are bound to distinct frozen restart
states, including the later alternate capped attempts for slices 7
and 8. Intermediate lineage uses archived state and receipt checks
and byte identity of the common author scripts with the fully replayed
case 18 code. The new independent arithmetic qualifies case 42 and
its exact nine-term sum.
