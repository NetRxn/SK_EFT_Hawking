"""Summarize initial storage only, from the already frozen dense cut plan."""
import hashlib
from pathlib import Path
from statistics import median
import sys
from zipfile import ZipFile

with ZipFile(Path(sys.argv[1])) as checkpoint:
    source = checkpoint.read('cut-plan.tsv')
digest = hashlib.sha256(source).hexdigest()
assert digest == '28b9a0879fad79733a1ef85521b1c871841fd21714c461fba5ddf0438478ce2d'
groups = [tuple(map(int, line.split('\t')[:4])) for line in source.decode().splitlines()]
assert [group[0] for group in groups] == list(range(3872))
assert all(group[1] == 8 for group in groups)
print('archived plan SHA256', digest)
print('groups', len(groups), 'total support assignments', sum(group[1] for group in groups))
for name, column in [('input rows', 2), ('encoded input bytes', 3)]:
    values = [group[column] for group in groups]
    baseline = groups[128][column]
    print(name, 'min/median/max', min(values), int(median(values)), max(values))
    print(name, 'group 128', baseline,
          'below/equal/above', sum(v < baseline for v in values),
          values.count(baseline), sum(v > baseline for v in values))
