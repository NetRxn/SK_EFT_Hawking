"""Compare the exact project import closure before transferring the first law."""
import hashlib
import json
import pathlib
import re
import subprocess
import sys

DONOR = "d006634b171222be7cfde9becb2332d317058cfd"
BASE = "e4c2212143de0bb0bd6fa19357af7a0926e29e43"
ROOT = "lean/SKEFTHawking/ExactSolutions.lean"
PINS = ("lean/lean-toolchain", "lean/lakefile.toml", "lean/lake-manifest.json")


def git(*args):
    return subprocess.check_output(["git", *args])


def tree(revision):
    result = {}
    for line in git("ls-tree", "-r", revision, "lean").decode().splitlines():
        entry, path = line.split("\t")
        result[path] = entry.split()[-1]
    return result


def source(revision, path):
    return git("show", f"{revision}:{path}")


def import_closure(revision, files):
    remaining = [ROOT]
    local = set()
    external = set()
    while remaining:
        path = remaining.pop()
        if path in local:
            continue
        local.add(path)
        text = source(revision, path).decode()
        for line in re.findall(r"(?m)^(?:(?:public|private|meta)\s+)?import\s+([^\n]+)", text):
            for module in line.split("--", 1)[0].split():
                candidate = "lean/" + module.replace(".", "/") + ".lean"
                if candidate in files:
                    remaining.append(candidate)
                else:
                    external.add(module)
    return local, external


def main(receipt_path):
    donor_files, base_files = tree(DONOR), tree(BASE)
    local, external = import_closure(DONOR, donor_files)
    base_local, base_external = import_closure(BASE, base_files)
    assert local == base_local
    assert external == base_external
    assert all(name == "Mathlib" or name.startswith("Mathlib.") for name in external)
    assert all(donor_files[path] == base_files[path] for path in PINS)
    assert source(DONOR + "^", ROOT) == source(BASE, ROOT)
    assert all(donor_files[path] == base_files[path] for path in local - {ROOT})

    proof = source(DONOR, ROOT)
    receipt = pathlib.Path(receipt_path).read_bytes()
    assert receipt.startswith(proof)
    suffix = receipt[len(proof):].decode().splitlines()
    commands = [line for line in suffix if line.strip()]
    assert len(commands) == 3
    assert all(line.startswith("#print axioms ") for line in commands)
    print(json.dumps({
        "donor": DONOR,
        "base": BASE,
        "root": ROOT,
        "project_sources": len(local),
        "exact_transitive_source_match": True,
        "root_preimage_match": True,
        "pins": {path: donor_files[path] for path in PINS},
        "donor_root_blob": donor_files[ROOT],
        "donor_receipt_source_sha256": hashlib.sha256(receipt).hexdigest(),
        "external_imports": sorted(external),
        "manifest": {path: donor_files[path] for path in sorted(local)},
    }, indent=2))


if __name__ == "__main__":
    main(sys.argv[1])
