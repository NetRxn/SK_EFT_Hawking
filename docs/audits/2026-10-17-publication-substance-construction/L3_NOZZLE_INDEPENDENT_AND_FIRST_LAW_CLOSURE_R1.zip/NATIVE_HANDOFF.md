# L3 nozzle native handoff

Source target is original L3 finding 2.1. Begin with the local stationary
model in the independently reviewed package. Bind the candidate to its
own exact Lean toolchain and Mathlib pin before proof execution.

1. Reuse the two-coordinate PG block and inverse from
   `SKEFTHawking.AcousticMetric.acousticMetric`,
   `acousticMetricInv` and `acousticMetric_inv_correct`.
   Formalize the throat identity for smooth positive area and density,
   fixed positive sound speed, differentiable stationary flux and
   Bernoulli law, and the oriented sonic throat. The slope magnitude
   and normalization must be derived from these hypotheses.
2. Construct the analytic local velocity branch. The pinned Mathlib
   source has `AnalyticAt.analyticOrderAt_eq_natCast`,
   `natCast_le_analyticOrderAt_iff_iteratedDeriv_eq_zero`,
   `HasStrictDerivAt.eventually_right_inverse`,
   `HasStrictDerivAt.to_localInverse` and
   `AnalyticAt.analyticAt_localInverse`. Check their exact types in the
   admitted lane. The divided analytic germ must evaluate to one at
   the throat and the velocity witness must satisfy both original
   fluid equations with positive reference density.
3. Show the stationary connection identity with the explicit
   transverse-uniform lift. State the null hypersurface and its cut
   separately. Retain the geometric transverse-varying adverse metric
   as a control against broadening the law to arbitrary stationary
   metrics. State the laboratory-time normalization and source
   acceleration normalization independently.
4. Keep exact PR112 finding 2.2 and native catalog qualification as
   separate work. The general physical L3 four-laws claim, including
   ADW exterior matching, acoustic energy and entropy balance and the
   third-law time bound, stays open.
