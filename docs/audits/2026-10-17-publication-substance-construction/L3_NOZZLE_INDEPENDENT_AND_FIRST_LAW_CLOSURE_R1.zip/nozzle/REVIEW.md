# L3 stationary nozzle zeroth-law candidate | independent review

**Verdict.** The frozen construction is mathematically sound for the local,
stationary, constant-sound-speed Laval nozzle and its transverse-uniform
effective metric lift. This supplies a local zeroth-law proof block for the
original L3 finding 2.1. The candidate text can make the positivity and
regularity assumptions explicit as detailed below. Native formalization,
exact catalog and consumer qualification, the physical ADW exterior,
acoustic energy and entropy balances, and the rest of the original four-laws
obligation remain open. This review is mathematical and source-specific.
Its scope includes the stated adverse metric.

## Input custody

- Primary continuity packet l3-nozzle-zeroth-independent-r1 returned
  `fresh: true`, `changed: []` using `scripts/codex_continuity.py check`.
  Primary HEAD observed as 27012c18fa374e8341e124b510abbedeedb18d29 with
  empty short status.
- Candidate package records PR112 base
  e4c2212143de0bb0bd6fa19357af7a0926e29e43. The nozzle manifest SHA-256 is
  5c79655ad1aa2ada3166528bb0aa71cb694a978ea2a2462d95d9c6990262b8a1.
  Independent `shasum -a 256 -c nozzle-manifest.sha256` matched all three files.
  The companion author script and log were used for custody only.
- Scope cross-checked against the exact runtime layout and the roadmap's
  L3 reconciliation. The first block under review is the local acoustic
  construction, which leaves the broader four physical laws and the fixed-G
  Schwarzschild donor qualification as separate obligations.

## Primary equations and independent profile argument

Balbinot, Fagnocchi and Fabbri v2 take the (t,z) metric block in (3.5) and
set the phonon terms in (3.2)–(3.3) aside in their classical stationary
calculation. Equations (4.1) and (4.4) give Aρv = D and
v²/2 + c² log(ρ/ρ₀) = 0 for constant c. The footnote after (4.9) explicitly
excludes external forcing from the simple throat condition. Take c, A₀,
β and ρ₀ positive and restrict to a neighborhood of the prescribed
A = A₀ + β z² waist on which v < 0. Differentiate the two equations and
divide the first by the nonzero flux. This gives
A'/A + ρ'/ρ + v'/v = 0 and ρ'/ρ = −vv'/c². Elimination gives
A'/A = −(v'/v)(1 − v²/c²), matching (4.3). At v(0) = −c, A'(0) = 0.
Differentiating once more at zero yields 2β/A₀ = 2(v'(0))²/c² because
the term proportional to the second velocity derivative is zero there.
[Balbinot et al., arXiv v2, (3.5) and (4.1)–(4.9)](https://arxiv.org/pdf/gr-qc/0405098v2#page=8)

A direct local inverse can be derived independently in a logarithmic
variable. Set w = −v/c, p = √(β/A₀). Evaluating the flux at zero gives
D = −A₀ρ₀ce^(−1/2). Substitution of ρ = ρ₀ e^(−w²/2) into continuity gives
(1+p²z²)w exp((1−w²)/2) = 1. Taking its real log gives
m(w) = log(1+p²z²), where m(w) = (w²−1)/2−log w. Since
m(1)=m'(1)=0 and m''(1)=2, the analytic factor a(w)=m(w)/(w−1)²
extends to a(1)=1 by its convergent Taylor series. Its positive analytic
square root defines M(w)=(w−1)√a(w) with M'(1)=1. Likewise b(z)=
log(1+p²z²)/(p²z²) extends analytically with b(0)=1. Define
N(z)=pz√b(z). The real analytic inverse function theorem gives
w(z)=M⁻¹(−N(z)), and w'(0)=−p. Squaring recovers the exact continuity
relation on a small neighborhood with w>0. Thus v'(0)=cp and shrinking
the neighborhood gives |v|>c for z<0 and |v|<c for z>0. Replacing −N with
+N gives the reversed branch. These are the two local analytic branches
through the throat because the analytic factors have simple zeros there
and M(w)²=N(z)². Arbitrarily changing the sign of M(w)/N(z) across z=0
fails differentiability at zero. Since h(u)=exp(m(−u))−1, it follows
that h(−1)=h'(−1)=0, h''(−1)=2, and the candidate's direct double-zero
inverse is equivalent to the independently constructed branch.

## Horizon and normalizations

Write K=∂t and H={z=0}. The stated lift is Lorentzian where c>0 and f>0,
with determinant −c²f⁴ in coordinates (t,z,y,x). Stationarity gives
a Killing field. On H its metric dual is fc dz and (dz)♯ = K/(fc).
The hypersurface is null, with tangent, nonzero, normal Killing field K.
The spatial cut is H intersected with a laboratory-time slice. For
f=ρ/c, K♭ on H is ρ(0)dz.

For a Killing field, ∇_K K = −(d g(K,K))♯/2. Equivalently in these
stationary coordinates, Γ^μ_tt = −g^{μν}∂_νg_tt/2. Here the gradient of
g_tt=f(v²−c²) on H is −2fc v_z dz. The derivatives of f drop out by the
sonic equality, and transverse derivatives of g_tt vanish on H. The
connection therefore gives ∇_K K = v_z K, hence constant cp for the
constructed branch throughout H. Under the constant normalization K/c,
the coefficient becomes v_z/c. Balbinot (4.17) gives the acceleration
k=c v_z=c²p and κ=k/c²=p, consistent with the K/c coefficient. Visser
§9.2 uses natural Newtonian time and writes ∇_L L=(g_H/c)L in (83),
with g_H equal to half the outward normal derivative of c²−v_perp² in
(84). In this axial model L=K, the outward direction is increasing z
and v_perp²=v², so g_H=c v_z. Visser §9.2 treats constancy and Killing
behavior in general stationary acoustic geometries as extra issues.
[Balbinot et al., arXiv v2, (4.17)](https://arxiv.org/pdf/gr-qc/0405098v2#page=10)
[Visser, arXiv v2, §9.2, (82)–(84)](https://arxiv.org/pdf/gr-qc/9712010v2#page=20)

## Adverse geometry and handoff

The same connection computation works when v(z,y) is stationary and
v(0,y)=-c. For v=-c+(1+y²)z and f=1, the null normal and local Killing
hypersurface are retained, while v_z|H=1+y², giving distinct values 1
and 2 at y=0 and y=1 in the chosen coordinates. Since the coefficient is
positive, the nearby sonic signs can be retained on a bounded transverse
patch containing both points by shrinking the z interval. This example
tests the geometric role of transverse uniformity. Interpreting its
velocity as v ∂z gives nonzero vorticity away from H at generic y,
so its use is limited to a metric control. The transverse-uniform
lift from the one-dimensional model is an effective local geometry.
The area-weighted nozzle continuity law is the governing reduced
equation.

Carry ρ₀>0 and smooth positive f (at least C¹ for the displayed
connection) explicitly into the native theorem. Use null hypersurface
for H and spatial cut for its fixed-time slice. Preserve the distinction
between laboratory-time nonaffinity, inverse-length normalization, and
acceleration, including branch orientation. The original 2.1 Verify
references the extracted native FourLaws_Schwarzschild catalog and
cannot be credited for this scratch review. The analytic existence
argument and its attachment to the relevant formal geometry and
consumer must still be established natively.

## Fresh computation

A separate here-document run with the primary checkout's
`.venv/bin/python` and SymPy 1.14.0 checked the differentiated
continuity/Bernoulli residuals, the throat derivative via the polynomial
jet v=−c+az+bz², the two independent jets of m and h, the full metric
determinant and inverse, the full stationary Christoffel column and
the adverse values. For the metric check it permitted an arbitrary
stationary f(z,y) and an arbitrary higher-order z²r(z,y) remainder,
and recovered Γ^μ_tt=(v_z,0,0,0) on H. The final command exited 0 and
printed the pass for all assertions. An initial command attempted to
substitute an unevaluated symbolic derivative at z=0 and stopped in the
throat-jet assertion. Substituting the generic polynomial before
differentiation resolved that symbolic evaluation issue. The mathematical
existence argument above is independent of the symbolic jet checks.
