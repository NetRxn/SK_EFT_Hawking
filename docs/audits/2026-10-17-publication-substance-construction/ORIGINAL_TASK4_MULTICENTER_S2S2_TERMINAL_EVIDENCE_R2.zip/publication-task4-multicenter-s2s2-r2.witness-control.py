"""Bounded original source witnesses and frozen one-center identity controls."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from hashlib import sha256
import json
import sys
p=Path(__file__).with_name("publication-task4-multicenter-s2s2-r2.py")
spec=spec_from_file_location("two_center_witness_control",p)
m=module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)
work=m.r5.Work(cap=1_500_000,oracle_record_cap=m.r10.PAIR_CAP)
reg,(x,y,w,z),inputs,z_inputs,raws,d0,d1=m.setup(work)
baseline_reserves=[]
original_production=m.production
def inspect_production(*args,**kwargs):
    row=sys._getframe(1).f_locals["row"]
    if "degree" in row:
        expected=1+len(row["groups"])+sum(len(g[1]) for g in row["groups"])
        expected+=len(row["later"])+len(row["continuation"])
    else:
        expected=1+len(row["table"])+len(row["reference"])
    assert kwargs["carry"]==expected
    baseline_reserves.append(expected)
    return original_production(*args,**kwargs)
m.production=inspect_production
identity=m.identity_controls(inputs,z_inputs,work)
m.production=original_production
assert len(baseline_reserves)==21
witness_carry=[]
original_witness=m.selected_witness
def inspect_witness(*args):
    frame=sys._getframe(1)
    assert "receipt" not in frame.f_locals
    witness_carry.append(args[-1])
    return original_witness(*args)
m.selected_witness=inspect_witness
accepted=[]
refused=[]
for target,selected,value,n,row in m.witness_candidates(inputs,z_inputs,d0,d1,work,w,z,refused.append):
    assert target[0].bit_count()==18 and value and n
    accepted.append(dict(row))
    row["table"]=[(i,0,1) for i in range(1352)]
    del row
m.selected_witness=original_witness
assert len(accepted)==3 and accepted[0]["repeated"]
assert [row["direction"] for row in accepted]==[0,0,1]
frozen=p.with_name("publication-task4-multicenter-s2s2-r1.witness-control.json").read_bytes()
assert sha256(frozen).hexdigest()=="5bcd41c828dc07003dda13e283da310e933356ddf778eb79385588fc05755bc7"
prior=json.loads(frozen)
assert m.base.json_identity(accepted)==prior["rows"]
assert m.base.json_identity(refused)==prior["rejected"]
assert identity==prior["identity"]
print(json.dumps(dict(identity=identity,rows=accepted,rejected=refused,work=work.used,counts=dict(work.counts),
                      baseline_reserves=baseline_reserves,witness_carry=witness_carry,
                      prior_receipts_at_witness_start=0,prefix=m.output_prefix(),work_cap=work.cap),indent=2))
