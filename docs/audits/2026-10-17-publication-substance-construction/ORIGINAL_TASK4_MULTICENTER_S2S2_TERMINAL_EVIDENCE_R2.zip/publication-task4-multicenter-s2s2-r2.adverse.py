"""Small exact fixture, complete canonical product, and prospective limits."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from types import SimpleNamespace
import json
import sys
p=Path(__file__).with_name("publication-task4-multicenter-s2s2-r2.py")
spec=spec_from_file_location("two_center_adverse",p)
m=module_from_spec(spec)
sys.modules[spec.name]=m
spec.loader.exec_module(m)

def q(i):
    return m.S("q",("fixture",i))

def ep(mask,key,v=1):
    return m.E(((mask,m.P(((tuple(sorted(key)),m.Q(v)),))),))

branch=(2,3,0,1,0,1)
local=(2,*branch)
shared=q(20)
def site(pair,tag,left_q=None,alternatives=()):
    a=((1<<pair[0])|(1<<pair[1]))
    b=((1<<pair[2])|(1<<pair[3]))
    left_q = q(tag) if left_q is None else left_q
    ca=ep(a,(left_q,))
    for mask in alternatives:
        ca += ep(mask,(left_q,),-1)
    cb=ep(b,(q(tag+1),),2)
    raw=m.P(((tuple(q(tag+i) for i in range(2,6)),m.Q(3)),))
    trace=m.E(((0,raw*m.P.variable(m.G2)),))
    row=SimpleNamespace(components=((0,0,0),(0,1,1)),coefficient=raw)
    return {(0,0):ca,(1,1):cb}, {branch:trace}, {local:(((0,0),(1,1)),trace)}, {local:[row]}, ca*cb*trace

x,hx,_,_,xp=site((0,8,1,9),0)
w,_,ww,rw,wp=site((2,10,3,11),10,shared)
z,_,zz,rz,zp=site((4,12,5,13),30,shared,alternatives=((1<<2)|(1<<12),))
y,hy,_,_,yp=site((6,14,7,15),40)
j=m.S("J",("fixture",0))
d0=ep((1<<16)|(1<<17),(q(50),j))
d1=d0*m.Q(-2)
slot=m.SLOTS[1]
d=d0+d1
original=xp*wp*zp*d*yp
actual_keys=list(m.r4.rows(original))
assert len(actual_keys)==1
target,value=actual_keys[0]
target=(*target[:2],slot)
inputs=x,hx,w,ww,{m.SLOTS[0]:d0,slot:d},y,hy
z_inputs=z,zz
labels=(branch,local,local,branch)
work=m.r5.Work(cap=200_000,oracle_record_cap=m.r10.PAIR_CAP)
out,prod_peak,later,witness,paths=m.production(target,inputs,z_inputs,work,20,selected=labels)
reference,oracle_peak=m.oracle(target,inputs,z_inputs,(rw,rz),work,20,len(out.table))
direct=m.selected_witness(target,inputs,z_inputs,labels,work)
assert out.table == {(branch,(),branch):(value,1)}
assert {k:v for k,(v,_) in reference.table.items()} == {(branch,(),branch):value}
assert (witness,paths)==direct[:2]==(value,1)
assert target[1].count(shared)==2
assert (wp*zp).terms and not (wp*ep((1<<2)|(1<<12),(shared,))).terms
one_site=xp*wp*d*yp
(one_key,one_value),=m.r4.rows(one_site)
identity=(*one_key[:2],slot)
single,*_=m.production(identity,inputs,z_inputs,work,20,identity=True)
assert single.table == {(branch,(local,),branch):(one_value,1)}
assert m.output_prefix()==696
def refused(invoke, prefix):
    try:
        invoke()
    except RuntimeError as exc:
        assert str(exc).startswith(prefix), str(exc)
        return str(exc)
    raise AssertionError(f"missing refusal: {prefix}")
out_refusal=refused(
    lambda: m.production(target,inputs,z_inputs,m.r5.Work(cap=200_000),0,selected=labels),
    "signed output cap: retained 0, prospective 1, cap 0",
)
old=m.r10.LOCAL_CAP
m.r10.LOCAL_CAP=prod_peak-1
try:
    joint=refused(lambda: m.production(target,inputs,z_inputs,m.r5.Work(cap=200_000),20),
                  f"quartic local cap: prospective {prod_peak}, cap {prod_peak-1}")
finally:
    m.r10.LOCAL_CAP=old
or_ref=refused(
    lambda: m.oracle(target,inputs,z_inputs,(rw,rz),m.r5.Work(cap=200_000,oracle_record_cap=1),20,1),
    "quartic oracle cap:",
)
fanout=refused(lambda: list(m.complementary_join(
    {(1,()):{(0,):(m.ONE,1)}},{(2,()):{(1,):(m.ONE,1)}},3,(),m.r5.Work(cap=1))),
    "fiber work cap at 1 on multicenter_complement_updates plus 1",
)
base_results=dict(value=str(value),identity_value=str(one_value),combined_contact=True,
    shared_symbol_power=target[1].count(shared),seed_paths=paths,production_peak=prod_peak,
    oracle_peak=oracle_peak,later_paths=later,operation_count=work.used,output_prefix=696,
    output_refusal=out_refusal,local_refusal=joint,oracle_refusal=or_ref,fanout_refusal=fanout)

# The frozen comparator now reads only a single decoded record. Exercise
# parse refusal before any collection and a combined carried baseline.
parser_work=m.r5.Work(cap=500)
parse_refusal=refused(lambda: m.decode_frozen('{"groups":[[]]}',parser_work,m.base.Admission(2)),
                     "quartic local cap: prospective 3, cap 2")
assert parser_work.counts["multicenter_identity_input_bytes"]==15
old=m.r10.LOCAL_CAP
m.r10.LOCAL_CAP=prod_peak+4
try:
    baseline_refusal=refused(
        lambda: m.production(target,inputs,z_inputs,m.r5.Work(cap=200_000),20,carry=5),
        f"quartic local cap: prospective {prod_peak+5}, cap {prod_peak+4}",
    )
finally:
    m.r10.LOCAL_CAP=old

original_seed=m.seed_candidates
original_witness=m.selected_witness
observed=[]
def fixture(_inputs,_zi,slot,direction,*args):
    lineage=[(1<<i,(),m.ONE) for i in range(13)]
    yield (8191,(),slot),direction,((),(),(),()),1,[],lineage
def observe(_target,_inputs,_zi,_selected,_work,carry):
    previous=sys._getframe(1).f_locals.get("receipt")
    observed.append((carry,len((previous or {}).get("table",[])),len((previous or {}).get("path",[]))))
    return m.ONE,1,carry
m.seed_candidates=fixture
m.selected_witness=observe
gen=m.witness_candidates(None,None,None,None,m.r5.Work(cap=100),None,None,lambda _:None)
try:
    for _ in range(3):
        *_, receipt=next(gen)
        assert receipt["witness_peak"]==27
        receipt["table"]=[(i,0,1) for i in range(1352)]
        del receipt
    assert observed==[(14,0,0)]*3
finally:
    gen.close()
    m.seed_candidates=original_seed
    m.selected_witness=original_witness
conversion_old=m.r10.LOCAL_CAP
m.r10.LOCAL_CAP=26
m.seed_candidates=fixture
m.selected_witness=observe
try:
    gen=m.witness_candidates(None,None,None,None,m.r5.Work(cap=100),None,None,lambda _:None)
    conversion=refused(lambda:next(gen),"quartic local cap: prospective 27, cap 26")
finally:
    gen.close()
    m.r10.LOCAL_CAP=conversion_old
    m.seed_candidates=original_seed
    m.selected_witness=original_witness
accounting=dict(baseline_parse_refusal=parse_refusal,baseline_overlap_refusal=baseline_refusal,
    witness_liveness=observed[:3],raw_rendered_conversion_refusal=conversion)
print(json.dumps(dict(original=base_results,liveness=accounting),indent=2))
