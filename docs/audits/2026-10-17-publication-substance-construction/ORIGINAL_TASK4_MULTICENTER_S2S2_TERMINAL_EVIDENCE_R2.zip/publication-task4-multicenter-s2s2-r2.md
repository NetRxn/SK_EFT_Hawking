# First original N16 two-center S2,S2 coefficient candidate

The scope is the first three selected S2(w) S2(z) requests and
identity at z on the 18 accepted R9 S2 targets and three accepted
R10 (1,0) targets. The production identity restriction compares the
complete original grouped coefficients and path counts. The identity
replay does not add records to the already accepted 696-record prefix.

The carrier is the original positive-boundary N16 closed-word
source-C square. x and y retain one S2 each. The order is x, w, z,
contact, y. The literal uses d0, and the two mixed seed directions
both evaluate d0+d1. The physical symbol key is shared across sites.
Site labels are retained as provenance in production and never
substituted for physical anchor or coupling coordinates.

The production route builds exact per-site projected S2 tables with
both full exterior masks and full sorted symbol multisets. Local
branch labels are signed and keep source-path counts. The target
residual from x/contact/y determines the complementary site state.
The pair join uses the exact exterior product sign and signed
aggregation to retain every x/y result with positive source-path
count. The selected branch sum is computed separately from these
tables in source order. The literal request also exhibits a
repeated reciprocal axis-0 quaternion coordinate on a disjoint
source path. The known actual zero of one overlapping coframe pair
is separately established by the frozen geometry preflight.

The reference uses the original raw oriented S2 factors at w and z,
including groups that cancel, builds their canonical projected
products, and constructs the x/contact and y factors via canonical
exterior arithmetic independently of production path streams. It
uses Counter multiset subtraction and separately coded exterior
inversions to join exact residuals. The final comparison examines
every coefficient from either table, treating absent coefficients
as zero. Production keeps its ordered path counts and checks its
selected branch sum against the separately streamed witness. At least one selected full
signed total must be nonzero. A zero on the known overlapping
path is never treated as a complete coefficient result.

The current allocation allows three directions with a fixed random
seed, at most 2,048 structural attempts and 12 candidate witnesses
per direction. After a witness succeeds, its seed generator closes.
The serialized path records are carried into the simultaneous
live-row reservation for the coefficient stage. The oracle also
reserves the retained production signed table. Source tables,
later index, live projections, final updates and canonical
temporaries have prospective named bounds and charged fanout. The
cumulative signed cap is 2,048 with 696 carried forward. The live
local and later-path caps are 8,192 each, the oracle scratch cap is
16,384, and the one new evaluation uses 20 million work charges.

The bounded fixture compares the full canonical expression,
production and raw-oriented oracle with a mixed contact, repeated
coordinate and an overlapping branch. It also checks identity and
adverse signed output, shared live rows, raw scratch and fanout.
The actual bounded witness and identity controls are separate
from evaluation of the three new complete original coefficients.
The original executable opens an exclusive result JSONL file.
Use --root-admitted-original only after a fresh independent
source and admission review.

## R2 live-record correction

The frozen R9 document hash pins its array formatting and content.
The candidate decodes one target at a time and checks a conservative
collection-delimiter bound before parsing it. The R10 comparison
similarly decodes a single JSONL row at a time. During each identity
evaluation the current baseline's target header, R9 group headers
and coefficient rows, or R10 signed and reference rows, are carried
into the production reservation. R9's additional retained later and
continuation summaries are counted. Signed identity comparison
looks up each expected key directly and checks cardinality and
paths. It creates no duplicate group map, sorted group index or
rendered identity table.

The seed generator drops its receipt immediately when resumed.
Original output serialization uses a separate caller-owned
dictionary. Witness conversion checks that its raw lineage and
rendered rows fit together before constructing a receipt. The
accepted serialized lineage remains reserved during each coefficient
evaluation. The adverse probes exercise prospective parse refusal,
baseline-plus-production refusal and raw/rendered witness conversion.
They also simulate a caller attaching 1,352 signed rows to a yielded
receipt, then verify zero prior rows at the next witness. The bounded
actual controls check the carried reserve at each identity request
and the generator boundary at each actual witness attempt.

The coefficient algebra, source order, witness identities, accepted
696-record prefix and original work and storage limits are unchanged.
This revision remains pending independent admission for the three
complete original coefficients.
