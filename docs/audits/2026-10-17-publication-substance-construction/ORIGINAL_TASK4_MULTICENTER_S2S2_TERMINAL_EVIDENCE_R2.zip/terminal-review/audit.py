from collections import Counter
from datetime import datetime
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import json,re

base=Path('/tmp/publication-task4-multicenter-s2s2-r2')
def read(s): return Path(str(base)+s).read_text()
def coeff(s):
    a,b,c,d=map(int,re.fullmatch('QComplex[(]storage=[(](-?[0-9]+), ([0-9]+), (-?[0-9]+), ([0-9]+)[)][)]',s).groups())
    assert b>0 and d>0
    z=F(a,b),F(c,d)
    assert (z[0].numerator,z[0].denominator,z[1].numerator,z[1].denominator)==(a,b,c,d)
    return z
def mul(a,b): return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def key(a): return json.dumps(a,separators=(',',':'))
def iso(s): return datetime.strptime(s.strip(),'%a %b %d %H:%M:%S UTC %Y')
assert read('.original.exit').strip()=='1' and not read('.original.stdout')
wall=(iso(read('.original.stop'))-iso(read('.original.start'))).total_seconds()
assert wall==91
interpreter=read('.original.interpreter')
assert interpreter.startswith('/Users/') and ' 3.14.8 ' in interpreter
actual=[json.loads(x) for x in read('.original.jsonl').splitlines()]
assert len(actual)==4 and 'work_total' not in actual[-1]
identity,*rows=actual
assert identity==dict(identity_controls={'R9':18,'R10':3},work=984816)
logs,stack=read('.original.stderr').split('Traceback (most recent call last):',1)
assert stack.strip().endswith('RuntimeError: all selected complete signed totals are zero')
assert 'AssertionError' not in stack and ' cap' not in stack
announced=[json.loads(x) for x in logs.splitlines()]
assert len(announced)==4
selected=[r for r in announced if coeff(r['witness'])!=(0,0)]
rejected=[r for r in announced if coeff(r['witness'])==(0,0)]
assert len(selected)==3 and len(rejected)==1
assert rejected[0]['target']['slot']==[0,1] and rejected[0]['direction']==1 and rejected[0]['attempt']==1 and rejected[0]['paths']==4
receipt=json.loads(read('.witness-control.json'))
assert selected==receipt['rows'] and rejected==receipt['rejected']
preceding=Path('/tmp/publication-task4-continuation-quartic-r13.original.jsonl').read_bytes()
assert sha256(preceding).hexdigest()=='822c1a3785f4ba68e8fe594bda0962ce4b5fbc6d3bdad3c6ae22ccd6a2d6b3a8'
assert json.loads(preceding.splitlines()[-1])['cumulative_output_records']==696
seen=set()
out=[]
for idx,(row,seed) in enumerate(zip(rows,selected,strict=True)):
    target=row['target']
    assert all(row[k]==v for k,v in seed.items())
    assert key(target) not in seen
    seen.add(key(target))
    assert (target['slot'],row['direction'],row['attempt'])==[([0],0,92),([0,1],0,1),([0,1],1,2)][idx]
    assert Counter(t[0] for t in target['symbols'])=={'J':1,'g2':4,'q':25}
    mask=0
    ks=Counter()
    value=F(1),F(0)
    assert len(row['path'])==13 and row['reserved_path_records']==14
    for index,(mask_text,symbols,c) in enumerate(row['path']):
        m=int(mask_text,16)
        assert not mask&m
        assert m.bit_count()==(0 if index in (2,5,8,12) else 2)
        sign=(-1)**sum(i>j for i,j in product(range(128),repeat=2) if mask&(1<<i) and m&(1<<j))
        value=mul(value,tuple(sign*v for v in coeff(c)))
        mask|=m
        ks.update(map(key,symbols))
    assert ks==Counter(map(key,target['symbols']))
    assert mask==int(target['mask_hex'],16) and mask.bit_count()==18
    groups={}
    for (x,discarded,y),c,n in row['table']:
        assert len(x)==len(y)==6 and not discarded
        group=tuple(x),tuple(y)
        assert group not in groups and type(n) is int and n>0
        groups[group]=coeff(c),n
    assert list(groups)==sorted(groups)
    assert len(groups)==row['output_records']==[12,4,4][idx]
    assert all(c==(0,0) for c,_ in groups.values())
    assert tuple(sum(c[i] for c,_ in groups.values()) for i in range(2))==coeff(row['total'])==(0,0)
    path_sum=sum(n for _,n in groups.values())
    assert path_sum==[96,32,48][idx]
    w=coeff(row['witness'])
    assert w==[(0,F(1,8192)),(F(1,8192),0),(F(1,16384),0)][idx]
    xy=tuple(row['branch'][0]),tuple(row['branch'][3])
    remaining=groups[xy][1]-row['paths']
    assert row['paths']==[2,2,1][idx] and remaining==[6,6,11][idx]
    assert row['local_peak']==[179,172,194][idx]<=8192
    assert row['later_paths']==[12,10,12][idx]<=8192
    assert row['work']==[1137522,1285416,1437738][idx]<=20_000_000
    out.append(dict(slot=target['slot'],direction=row['direction'],attempt=row['attempt'],
        groups=len(groups),path_sum=path_sum,selected_lineage=list(map(str,value)),
        witness=list(map(str,w)),witness_paths=row['paths'],
        remainder_selected_group_coefficient=list(map(str,(-w[0],-w[1]))),remainder_selected_group_paths=remaining,
        later_paths=row['later_paths'],local_peak=row['local_peak'],work_at_row=row['work']))
assert 696+sum(x['groups'] for x in out)==716<=2048
print(json.dumps(dict(exit=1,elapsed_seconds=wall,identity=identity,actual=out,retained_groups=20,
    cumulative_signed_records=716,paths_across_distinct_targets=176,work_at_last_row=rows[-1]['work'],
    terminal_summary_emitted=False,oracle_peak_exact=None),indent=2))
