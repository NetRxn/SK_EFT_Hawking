# Complementary tuple 0 outer case 25

Restore the original selector-1 parent from the Git archive in the
independent source pins. The author 48-coordinate cut and primary/rescue
passes produce the nine-coordinate restart input. Use the scripts under
author/ and the frontier hash manifest. Run run-primary.py on the saved
seven-factor outer restart, then reduce-open.py for inner indices 0–8.
The remaining triangles 5 and 6 use triangle-shards.py with eight disjoint
sorted-row shards each. Sum them with sum-shards.py for each inner index,
then run sum-case25.py. All underlying inputs must come from trusted
checkpoints.

Compare preceding-twenty-five.tsv with twenty-five-term-retally.tsv in
the committed complementary case 24 archive. Run verify-and-retally.py
to reproduce the exact case and cumulative sum after checking the
independent raw and normalized arithmetic. The review report describes
the separate first-pair and triangle routes and caps.

