# Independent verification of complementary tuple 0 outer case 25

The exact normalized sum is
**-41341172375785624570953/2596148429267413814265248164610048 + 0i**.

The original separator archive was read from publication checkpoint
e7117dc4ac893ed733c2445296337e5020328442 and matches the worktree bytes.
Its manifest verified. The decompressed complementary parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d.
It has selector R(0,0,2,0,1)=1. Its rejected-pair histogram reconstructs
the full 48-coordinate roster over 6,427,904 products. Outer case 25 is
(24, (3,)) with 118,160 pair products. The inverse lift recovers 401,772
compatible rows with their exact Gaussian coefficients and denominators.
First-child case 25 has the same coordinate and scalar under selector 0.
The complementary calculation begins from its own pinned operand.

The two outer row-cap stages reproduce the seven-factor inner parent
4e8572d0744630c904f0c282ccbda52ec8c0683e753edfa929cfd2b961f15f76.
Its rejected-pair histogram reconstructs all nine inner coordinates on
G(0,1,2) over 2,579,328 matched products. Each exact inverse lift
recovers every compatible parent row. The outer caps and all 18 inner
generic cycles reproduce byte for byte, including the 11 inner caps
and seven generic exact terminals.

| Slice | Inner coordinate | Matched parent pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 3 | 195,456 | -4047983651823933419325/2596148429267413814265248164610048 |
| 1 | 48 | 199,296 | -10184940244578426831/20282409603651670423947251286016 |
| 2 | 96 | 199,296 | -90499304937824206623/162259276829213363391578010288128 |
| 3 | 144 | 199,296 | -90499304937824206623/162259276829213363391578010288128 |
| 4 | 192 | 199,296 | -156913926114405537/2535301200456458802993406410752 |
| 5 | 5 | 394,752 | -1150014269006135923635/324518553658426726783156020576256 |
| 6 | 12 | 394,752 | -5388144904356564247065/649037107316853453566312041152512 |
| 7 | 80 | 398,592 | -136260311551798891131/324518553658426726783156020576256 |
| 8 | 160 | 398,592 | -136260311551798891131/324518553658426726783156020576256 |

The initial sparse order for slices 2 and 3 reached a forecast of
29,708,160 products after computing 8,103,640. The preserved refusal
logs stop before that join. Support-only semijoins and a width-based
sparse schedule independently contract the same full seven-factor inputs
in 12,779,224 products per slice. The other five generic terminal
scalars use direct independent sparse arithmetic.

The independent triangle schedule for slices 5 and 6 uses pivot 1.
It matches the two pivot 0 author sums at the raw Gaussian numerators
and normalized values. For each input it covers 13,317,120 triples and
uses 13,394,880 Gaussian products under the recorded shard caps. The
receipt audit independently checks each of the author's eight disjoint
intervals for both slices and re-sums their exact raw and normalized
values. All nine replays apply the common factor denominator
40512224221827380280140849737629696 and normalization 1/(16*4^64) once.

The review manifest uses relative paths and includes byte-identical
copies of the author receipts. The frozen-input inventory records the
checkpoints used for the exact replays.
