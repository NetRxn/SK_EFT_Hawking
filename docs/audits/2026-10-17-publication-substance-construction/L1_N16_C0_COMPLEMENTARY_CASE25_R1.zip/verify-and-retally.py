from fractions import Fraction
from pathlib import Path
from ast import literal_eval
import re

root=Path(__file__).resolve().parent
author=root/'author'
review=root/'review'
axes, roster=literal_eval((author/'slice-0.roster').read_text())
assert axes==(('G',0,1,2),) and len(roster)==len(dict(roster))==9
assert sum(n for _,n in roster)==2_579_328
ordered=sorted(roster,key=lambda x:(x[1],x[0]))
rows=[line.split('\t') for line in (author/'author-case25.tsv').read_text().splitlines()]
assert len(rows)==10
total=[Fraction(),Fraction()]
normalized=re.compile(r'^exact normalized real (\S+) imaginary (\S+)',re.M)
raw=re.compile(r'raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)')
for i,(index,key,products,x,y,receipt) in enumerate(rows[:-1]):
    assert int(index)==i and ((int(key),),int(products))==ordered[i]
    valid=[]
    for path in sorted(review.glob(f'slice-{i}-*-replay.out')):
        out=path.read_text()
        numerators=raw.search(out)
        if numerators:
            a,b,d=map(int,numerators.groups())
            values=Fraction(a,d*16*4**64),Fraction(b,d*16*4**64)
            assert values==tuple(map(Fraction,normalized.search(out).groups()))
            valid.append(values)
    assert valid and len(set(valid))==1,(i,valid)
    values=valid[0]
    assert values==tuple(map(Fraction,normalized.search((author/receipt).read_text()).groups()))
    assert values==(Fraction(x),Fraction(y))
    for k,value in enumerate(values):
        total[k]+=value
print('case',25,*total,sep='\t')
assert rows[-1]==['sum',*map(str,total)]
cases={}
for line in (root/'preceding-twenty-five.tsv').read_text().splitlines():
    fields=line.split('\t')
    if fields[0].isdigit():
        i,x,y=fields
        assert int(i) not in cases
        cases[int(i)]=(Fraction(x),Fraction(y))
assert set(cases)==set(range(25))
cases[25]=tuple(total)
for i, (x,y) in sorted(cases.items()):
    print(i,x,y,sep='\t')
print('PARTIAL SUM',len(cases),*map(sum,zip(*cases.values())),sep='\t')
