from collections import Counter
from fractions import Fraction
from itertools import combinations, permutations, product
from pathlib import Path
import importlib.util
import json
import sys

path = Path(__file__).with_name("publication-task4-later-full-vertex-r4.py")
spec = importlib.util.spec_from_file_location("r4_vertex", path)
r4 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r4
spec.loader.exec_module(r4)

reg = r4.o.OriginalRegulator()
y = reg.step(reg.sites[0], 0)[0]
quarter = r4.P.scalar(Fraction(1, 4))
coframe = {(mu, a): r4.exterior(reg, (y, mu, a))
           for mu, a in product(range(4), repeat=2)}
by_choice = []
histogram = Counter()
for mu, nu in combinations(range(4), 2):
    k, l = tuple(axis for axis in range(4) if axis not in (mu, nu))
    for a, b in permutations(range(4), 2):
        traces = []
        for (i,j), (m,n) in product(((k,l),(l,k)), ((mu,nu),(nu,mu))):
            ia, ib = (a,b) if (m,n)==(mu,nu) else (b,a)
            traces.append(r4.closed_trace(reg, y, i,j,m,n,ia,ib) * quarter)
        h = sum(traces, r4.P())
        assert h == r4.closed_trace(reg, y,k,l,mu,nu,a,b)
        assert all(piece == h*quarter for piece in traces)
        w = coframe[mu,a] * coframe[nu,b]
        w_count = 0
        for _, polynomial in w.terms:
            for key, _ in polynomial.terms:
                assert len(r4.axes_symbols(key, (mu,nu))) == len(key) == 2
                w_count += 1
        for key, _ in h.terms:
            assert len(r4.axes_symbols(key, (k,l))) == len(key) == 4
        h_count = len(h.terms)
        histogram[w_count,h_count] += 1
        by_choice.append(dict(choice=(k,l,mu,nu,a,b), coframe_keys=w_count,
                              trace_keys=h_count, standalone_group_keys=w_count*h_count))
assert len(by_choice) == 72
print(json.dumps(dict(center=y, count_by_factor_sizes=[(*key,value) for key,value in sorted(histogram.items())],
                      separately_labelled_key_sum=sum(row['standalone_group_keys'] for row in by_choice),
                      by_choice=by_choice), indent=2))
