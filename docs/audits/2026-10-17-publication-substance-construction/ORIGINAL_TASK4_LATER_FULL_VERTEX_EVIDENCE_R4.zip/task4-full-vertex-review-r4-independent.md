# Independent original N16 later full vertex review R4

**ACCEPT the bounded contraction, exact factored counts, separately labelled
72-choice roster and typed-cap refusal lifetime controls.** Both raw contact
directions reach the full designated later S2 group through one selected
original residual row apiece. The calculation preserves the original closed
source-C regulator, source labels, signed coefficients and shared quaternion
powers. Acceptance covers the measured logical envelope and its pinned
caller discipline. The remaining residual and group contractions, signed
reaggregation, full denominator and connected normalization remain open.

## Authority and replay

First and final checks on the exact independent continuity packet returned
fresh with no changed inputs, byte-identically. The author's final packet
reported source-only drift. The complete primary diff from 25b5f229c to
0736fda2e adds the GaussianPolynomialStein Lean module and its aggregate
import. It leaves the pinned original Python files unchanged. The primary
tracked checkout was clean.

I replayed both author scripts. The main JSON matched every deterministic
field. Its replay peak RSS was 135,774,208 bytes. The roster JSON matched
byte for byte. The two actual eager joins refused before prospective record
65,537 at visits 75,730 and 133,770, restoring 3,714 and 7,394 logical
records respectively. The selected complete partition returned at
144,011 cumulative visits, peak 65,536 logical records and 17,714 live
records with zero live indexes/readers.

## Independent original signed checks

The independent oracle reconstructs the four signed hopping increments on
the explicit globally ordered bar/psi basis, computes the original closed
word D† C† B A and oriented gamma trace, and multiplies coefficients with
explicit basis inversions and raw-label factorial multiplicities. It
reuses canonical exact arithmetic and original source blocks. The author
arena is used to identify its selected seed rows and capture actual maps
for comparison. The reference factors and joins do not call its product,
ExteriorPolynomial multiplication or RawJet multiplication.

The exact C and R maps matched all 3,584 and 8,192 entries. The direct raw
contact matched all 209 literal and 545 mixed entries and confirmed that
the selected mixed row comes from the axis-1 contact term. The complete
later group at y=x+e0 uses world curvature axes 0 and 3, coframe axes 1
and 2, and internal components 0 and 1. All four orientations align
exactly after the paired gamma-index switch. The coframes yield 3,584
signed keys and the trace yields 128, with disjoint quaternion axes and
no exterior trace mask. This gives 458,752 distinct standalone keys.

For the selected two actual residuals, the independent signed pretrace
matches all 1,920 literal and 1,760 mixed entries. Each slot fixes its
axis-0/3 seed multiset. Subtracting that fixed multiset from the output
recovers the trace key, including repeated shared coordinates. Its
complementary mask/axis-1/2 projection is injective within each slot.
Consequently the two exact factored counts are 245,760 and 225,280,
respectively. The mixed pretrace retains 120 squared keys at q(y,1,L,1).
The recoverable partition key depends only on the y+e2 mask and axis-2
quaternion multiset. It defines 56 nonempty groups. The independent
Cartesian product of the selected complete 40+40 group with the full
trace matched all 10,240 signed arena coefficients, 5,120 per slot,
with one J and two g2 factors per key.

## Standalone roster and failure lifetimes

The independent oracle regenerated every one of the 72 ordered unequal
internal choices for the six coframe pairs, checking all four aligned
trace orientations and exact signed coframe and trace sizes. The sum
33,030,144 retains the group label and is not a support count after
signed reaggregation. I also independently tested all 24 diagonal
internal groups. Their 96 nonzero ordered trace pieces cancel pairwise
under coframe reversal because the even coframes commute and epsilon
changes sign with identical internal labels. This accounts for all
384 ordered raw S2 factors at this selected center.

Saving a typed record-cap refusal after both indexes or during the second
index left no inner transaction frame, no retained bucket directory, no
exception context and no live index. An additional independent visit-cap
failure at visit 1 gave the same result with two built indexes. In every
case the four input records remained owned and dropping them returned to
zero. The author replay also confirmed the ingest lifetime control.
Unexpected host exceptions and external oracle objects remain outside the
typed-cap logical guarantee. RSS is a measured observation, not an
admission bound.

## Remaining construction

Contract the other residual rows and grouped choices and compare signed
reaggregation under common downstream keys. Establish actual last
incidences before any Haar or site closure. The separately labelled roster
does not bound coalesced global support, price the full computation or
evaluate Z. All nine original coupling alternatives and the complete
normalized scientific target remain owed.

Evidence uses the prefix `/tmp/task4-full-vertex-review-r4-`. The two
author replays, independent signed script/JSON, separate diagonal
script/JSON and first/final continuity receipts are all scratch files.
No source edits, full run, Lean execution or slot actions occurred.
