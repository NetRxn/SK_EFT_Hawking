from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial
import importlib.util
import json
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

def load(label, path):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module

r4 = load("r4review", "/tmp/publication-task4-later-full-vertex-r4.py")
Q, P, S = o.QComplex, o.Polynomial, o.Symbol
reg = o.OriginalRegulator()
x, y = reg.sites[0], reg.step(reg.sites[0], 0)[0]
x2 = reg.step(x, 2)[0]
q = S("g2", ())
j = S("J", (y, 0, 0))
assert (reg.volume, reg.word, reg.convention) == (16, "closed", "source_C")

def tensor(alpha, *, slot=(), labels=()):
    # Rebuild the four signed bilinears directly from the block definition
    # and the globally ordered bar/psi basis. No author arena or ExteriorPolynomial.
    positions = {token: i for i, token in enumerate(reg.generator_order)}
    out = defaultdict(Q)
    blocks = f.original_coframe_blocks(reg, alpha)
    for b in blocks:
        for i, k in product(range(4), repeat=2):
            a, z = positions[b.bar_site, "bar", i], positions[b.psi_site, "psi", k]
            for key, value in b.matrix[i][k].terms:
                out[(1 << a | 1 << z, tuple(sorted((*labels, *key))), slot)] += value * b.weight * (-1 if a > z else 1)
    return {k: v for k, v in out.items() if v}

def trace_rows(site, k, l, mu, nu, a, b):
    # Direct closed matrix word D† C† B A, with original quaternion labels.
    anchors = (site,k), (reg.step(site,k)[0],l), (reg.step(site,l)[0],k), (site,l)
    links = [f.original_spin4_link(*(tuple(P.variable(S("q",(*z,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for z in anchors]
    A,B,C,D = links
    U = o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(D),o.matrix_dagger(C)),o.matrix_multiply(B,A))
    gamma = o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    poly = sum((U[i][k]*gamma[k][i] for i,k in product(range(4),repeat=2)),P()) * o.epsilon((k,l,mu,nu))
    return {(0,key,()): value for key,value in poly.terms}

def indices(mask):
    return [i for i in range(mask.bit_length()) if mask >> i & 1]

def multiply(left, right):
    out = defaultdict(Q)
    for (lm,lk,lj), lv in left.items():
        for (rm,rk,rj), rv in right.items():
            if lm & rm or len(lj) + len(rj) > 2:
                continue
            z = tuple(sorted(lj + rj))
            multiplicity = 1
            for i in set(z):
                multiplicity *= factorial(z.count(i)) // (factorial(lj.count(i)) * factorial(rj.count(i)))
            parity = sum(i > k for i,k in product(indices(lm),indices(rm))) % 2
            out[lm|rm,tuple(sorted(lk+rk)),z] += lv * rv * (-multiplicity if parity else multiplicity)
    return {k:v for k,v in out.items() if v}

def summed(*maps):
    out = defaultdict(Q)
    for d in maps:
        for k,v in d.items(): out[k] += v
    return {k:v for k,v in out.items() if v}

def slot_relabel(d, slot):
    return {(m,k,slot):v for (m,k,_),v in d.items()}

def snapshot(arena, handle):
    out = {}
    arena.scan(handle, lambda k,v:out.__setitem__(k,v))
    return out

from collections import Counter
from itertools import combinations, permutations
import weakref

# Only use the author calculation to identify its exact chosen rows and
# capture actual outputs. Rebuild signs and original factors independently.
captured = []
real_assert = r4.assert_exact
def capture(arena, h, reference):
    real_assert(arena, h, reference)
    captured.append(snapshot(arena,h))
r4.assert_exact = capture
original_seed = r4.contact_seed
seed_capture = {}
def capture_seed(reg, arena, C, R):
    seed_capture["C"], seed_capture["R"] = snapshot(arena,C), snapshot(arena,R)
    result = original_seed(reg,arena,C,R)
    seed_capture["K"] = snapshot(arena,result[0])
    seed_capture["mixed"] = result[1]
    return result
r4.contact_seed = capture_seed
actual = r4.vertex_case(reg)
author_C, author_R, K = (seed_capture[n] for n in ("C","R","K"))
C = multiply(tensor((x,0,0)),tensor((x,1,1)))
R = multiply(trace_rows(x,2,3,0,1,0,1), tensor((x2,2,0)))
assert C == author_C and R == author_R
ymask = 255 << (8*reg.site_number(y))
y_first = 1 << (8*reg.site_number(y))
labels = [tuple(sorted((S("q",(x,0,"L",a)), S("q",(x,1,"L",0))))) for a in (1,2)]
Cparts = [{(m,tuple(sorted((*k,q))),s):v for (m,k,s),v in C.items()
           if m & ymask == y_first and k==label} for label in labels]
assert [len(c) for c in Cparts] == [3,3]
rkey = next(k for k in author_R if any(s.index[:2] == (x,2) and k[1].count(s)==2 for s in k[1]))
prefix = multiply(summed(*Cparts),{rkey:R[rkey]})
lit = slot_relabel(multiply(prefix,tensor((y,0,0),labels=(j,))), (0,))
mix_axis1 = slot_relabel(multiply(prefix,tensor((y,1,0),labels=(j,))), (0,1))
mix = summed(slot_relabel(lit,(0,1)), mix_axis1)
assert len(lit)==209 and len(mix)==545
assert summed(lit,mix) == captured[0]
for key,val in K.items():
    assert (lit if key[2] == (0,) else mix_axis1)[key] == val
assert set(k[2] for k in K) == {(0,),(0,1)}
a,b = 0,1
T = multiply(tensor((y,1,a)),tensor((y,2,b)))
H0 = trace_rows(y,0,3,1,2,a,b)
for k,l in ((0,3),(3,0)):
    for mu,nu,ia,ib in ((1,2,a,b),(2,1,b,a)):
        assert trace_rows(y,k,l,mu,nu,ia,ib) == H0
H = {(m,tuple(sorted((*k,q))),s):v for (m,k,s),v in H0.items()}
assert len(T)==3584 and len(H)==128 and T==captured[1]

def axes(symbols, desired):
    return tuple(s for s in symbols if s.family=="q" and s.index[1] in desired)
assert all(len(axes(k,{1,2}))==len(k)==2 for _,k,_ in T)
assert all(m==0 and not slot and len(axes(k,{0,3}))==4 for m,k,slot in H)
KT = multiply(K,T)
assert KT==captured[2]
mask2=255 << (8*reg.site_number(reg.step(y,2)[0]))
def pkey(key):
    m,k,_ = key
    return m&mask2,axes(k,{2})
groups = defaultdict(dict)
pretrace = Counter()
by_slot = {key[2]:key for key in K}
injective = set()
for key,value in KT.items():
    m,k,s = key
    assert axes(k,{0,3})==axes(by_slot[s][1],{0,3})
    projection = (m,axes(k,{1,2}),s)
    assert projection not in injective
    injective.add(projection)
    groups[pkey(key)][key] = value
    pretrace[s]+=1
assert len(groups)==56 and pretrace=={(0,):1920,(0,1):1760}
mixed = seed_capture["mixed"]
assert mixed.index==(y,1,"L",1)
squares = sum(s==(0,1) and k.count(mixed)==2 for _,k,s in KT)
assert squares==120
eligible = [key for key, g in groups.items()
            if {k[2] for k in g}=={(0,),(0,1)}
            and any(s==(0,1) and k.count(mixed)==2 for _,k,s in g)]
chosen = min(eligible,key=lambda k:(-len(groups[k]),k))
section = groups[chosen]
assert Counter(k[2] for k in section)=={(0,):40,(0,1):40}
# Independent Cartesian product with explicit basis inversion and raw jet
# multiplicity, checked against actual retained arena values.
out = multiply(section,H)
assert len(out)==10240 and out==captured[3]
assert all(pkey(key)==chosen for key in out)
assert all(k.count(q)==2 and k.count(j)==1 for _,k,_ in out)
# Recompute standalone roster from the original hopping blocks and closed
# word, comparing every choice to author row counts in the exact order.
roster = json.load(open("/tmp/publication-task4-later-full-vertex-r4-roster.json"))
by_choice = {tuple(row["choice"]):row for row in roster["by_choice"]}
tensors = {(i,a):tensor((y,i,a)) for i,a in product(range(4),repeat=2)}
counts=[]
for mu,nu in combinations(range(4),2):
    k,l = [i for i in range(4) if i not in (mu,nu)]
    for a,b in permutations(range(4),2):
        primary = trace_rows(y,k,l,mu,nu,a,b)
        assert len(primary)==128
        assert all(m==0 and not s and len(axes(key,{k,l}))==len(key)==4 for m,key,s in primary)
        for i,h in ((k,l),(l,k)):
            for r,t,e,g in ((mu,nu,a,b),(nu,mu,b,a)):
                assert trace_rows(y,i,h,r,t,e,g)==primary
        w=multiply(tensors[mu,a],tensors[nu,b])
        assert len(w)==3584
        assert all(not s and len(axes(key,{mu,nu}))==len(key)==2 for _,key,s in w)
        row=by_choice[k,l,mu,nu,a,b]
        assert (row["coframe_keys"],row["trace_keys"],row["standalone_group_keys"])==(len(w),len(primary),len(w)*len(primary))
        counts.append(row["standalone_group_keys"])
assert len(counts)==len(by_choice)==72 and sum(counts)==33030144
# Independent refusal checks, including a visit-cap failure with built
# indexes, no surviving inner frames/weakrefs, and restored logical state.
class Seen(r4.Arena):
    def __init__(self,caps):
        super().__init__(caps)
        self.refs=[]
    def _bucket(self,*args):
        result=super()._bucket(*args)
        self.refs.append(weakref.ref(result))
        return result

held=[]
def refused(caps, kind, position, directory_count):
    ar=Seen(r4.Caps(*caps))
    a=ar.ingest((((m,(),()),Q(1)) for m in (1,2)))
    b=ar.ingest((((m,(),()),Q(1)) for m in (4,8)))
    try:
        ar.join(a,b,complement=True)
    except r4.Refusal as exc:
        held.append(exc)
    else:
        raise AssertionError("expected refusal")
    err=held[-1]
    assert err.kind==kind and (err.live if kind=="records" else err.visits)==position
    assert err.__context__ is None and err.__cause__ is None
    t=err.__traceback__
    frames=[]
    while t:
        frames.append(t.tb_frame.f_code.co_name)
        t=t.tb_next
    assert frames==["refused","join"]
    assert len(ar.refs)==directory_count and all(ref() is None for ref in ar.refs)
    assert ar.metric()["live_records"]==4 and ar.metric()["live_indexes"]==0
    assert ar.metric()["active_readers"]==0
    ar.drop(a); ar.drop(b)
    assert ar.metric()["live_records"]==0
    return {"caps":caps,"kind":kind,"position":position,"dead_directory_count":directory_count,"frames":frames}
controls = [refused((20,11),"records",12,2),refused((20,8),"records",9,1),refused((1,20),"visits",1,2)]
print(json.dumps({"direct_contact_by_slot":{str(k):v for k,v in Counter(key[2] for key in summed(lit,mix)).items()},
  "pretrace_by_slot":{str(k):v for k,v in pretrace.items()},"square_keys":squares,
  "factored_cardinalities":{str(k):v*len(H) for k,v in pretrace.items()},
  "selected_partition":{str(k):v for k,v in Counter(key[2] for key in out).items()},
  "roster_choices":len(counts),"labelled_roster_sum":sum(counts),"refusal_controls":controls},indent=2))
