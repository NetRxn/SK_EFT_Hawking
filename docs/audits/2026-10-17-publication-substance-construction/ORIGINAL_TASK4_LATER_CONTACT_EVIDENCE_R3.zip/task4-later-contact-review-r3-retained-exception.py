from importlib.util import spec_from_file_location,module_from_spec
import json
import sys
spec=spec_from_file_location("r3","/tmp/publication-task4-later-contact-r3.py")
r3=module_from_spec(spec)
sys.modules[spec.name]=r3
spec.loader.exec_module(r3)
arena=r3.Arena(r3.Caps(20,11))
a=arena.ingest((((m,(),()),r3.Q(1)) for m in (1,2)))
b=arena.ingest((((m,(),()),r3.Q(1)) for m in (4,8)))
saved=[]
try: arena.join(a,b,complement=True)
except r3.Refusal as error:
    assert (error.kind,error.visits,error.live)==("records",3,12)
    saved.append(error)
else: raise AssertionError("expected refusal")
tb=saved[0].__traceback__
while tb and tb.tb_frame.f_code.co_name!="join":
    tb=tb.tb_next
assert tb
locals_=tb.tb_frame.f_locals
arena_count=arena.metric()
assert arena_count["live_records"]==4 and not arena_count["live_indexes"]
dirs=len(locals_["left"])+len(locals_["right"])
refs=sum(map(len,locals_["left"].values()))+sum(map(len,locals_["right"].values()))
assert (dirs,refs)==(2,4)
print(json.dumps(dict(refusal_at=saved[0].live,logged_live=arena_count["live_records"],
                      retained_bucket_directories=dirs,retained_bucket_references=refs)))
