"""Bounded original N16 later-center and literal contact. Scratch only."""
from dataclasses import dataclass
from itertools import product
from math import comb
import json
import resource
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

Q, P, E, S = o.QComplex, o.Polynomial, o.ExteriorPolynomial, o.Symbol
INDICES = ((), (0,), (1,), (0, 0), (0, 1), (1, 1))
ALTERNATIVES = tuple((q,p) for q in range(3) for p in range(5-2*q))

class Refusal(ValueError):
    def __init__(self, kind, visits, live):
        self.kind, self.visits, self.live = kind, visits, live
        super().__init__(f'{kind} cap: visits={visits}, requested_live={live}')

@dataclass(frozen=True, slots=True)
class Caps:
    visits: int
    records: int

    def check(self):
        if type(self.visits) is not int or not 0 < self.visits <= 2_000_000:
            raise ValueError('visits must be a positive exact integer within the probe envelope')
        if type(self.records) is not int or not 0 < self.records <= 65_536:
            raise ValueError('records must be a positive exact integer within the probe envelope')

class Arena:
    """Track coefficient and mask-index logical slots, not Python heap bytes."""
    def __init__(self, caps):
        if type(caps) is not Caps:
            raise ValueError('exact scratch Caps required')
        caps.check()
        self.caps = caps
        self._maps = {}
        self._index_slots = {}
        self._readers = {}
        self._serial = 0
        self._issued_serial = 0
        self._used = 0
        self._charged = {'buckets': 0, 'records': 0}
        self._live = 0
        self._peak = 0

    def _check(self):
        self.caps.check()
        active=tuple(self._maps)+tuple(self._index_slots)
        if (type(self._serial) is not int or self._serial < 0
                or type(self._issued_serial) is not int or self._serial != self._issued_serial
                or any(type(h) is not int or not 0 < h <= self._serial for h in active)
                or len(set(active)) != len(active)):
            raise ValueError('invalid handle allocation serial or roster')
        if any(type(h) is not int or h not in self._maps or type(n) is not int or n <= 0
               for h,n in self._readers.items()):
            raise ValueError('invalid reader roster')
        if type(self._used) is not int or not 0 <= self._used <= self.caps.visits:
            raise ValueError('invalid consumed visit counter')
        if (set(self._charged) != {'buckets','records'}
                or any(type(v) is not int or v < 0 for v in self._charged.values())
                or sum(self._charged.values()) != self._used):
            raise ValueError('inconsistent charged visit ledger')
        if any(type(v) is not int or v < 0 for v in self._index_slots.values()):
            raise ValueError('invalid indexed storage accounting')
        known = sum(map(len,self._maps.values())) + sum(self._index_slots.values())
        if type(self._live) is not int or self._live != known:
            raise ValueError('invalid live-record counter')
        if type(self._peak) is not int or not self._live <= self._peak <= self.caps.records:
            raise ValueError('invalid peak-record counter')

    def _admit(self, extra):
        prospective = self._live+extra
        if prospective > self.caps.records:
            raise Refusal('records',self._used,prospective)

    def _update(self, delta):
        self._live+=delta
        self._peak=max(self._peak,self._live)

    def visit(self,kind='records'):
        self._check()
        if kind not in self._charged:
            raise ValueError('unknown visit accounting kind')
        if self._used >= self.caps.visits:
            raise Refusal('visits',self._used,self._live)
        self._used+=1
        self._charged[kind]+=1

    def _new_id(self):
        self._check()
        next_id=self._serial+1
        if next_id in self._maps or next_id in self._index_slots:
            raise ValueError('handle collision before mutation')
        self._serial=next_id
        self._issued_serial=next_id
        return next_id

    def _require_map(self,h,*,mutable=False):
        if type(h) is not int or h <= 0 or h not in self._maps:
            raise ValueError('unowned or nonexact map handle')
        if mutable and h in self._readers:
            raise ValueError('map is in an active read')
        return self._maps[h]

    def _require_index(self,h):
        if type(h) is not int or h <= 0 or h not in self._index_slots:
            raise ValueError('unowned or nonexact index handle')

    def new_map(self):
        self._check()
        h=self._new_id()
        self._maps[h]={}
        return h

    def put(self,h,key,c):
        self._check()
        m=self._require_map(h,mutable=True)
        if type(key) is not tuple or len(key)!=3 or type(c) is not Q:
            raise ValueError('immutable exact coefficient record required')
        mask,symbols,slot=key
        if (type(mask) is not int or not 0<=mask<1<<128
                or type(symbols) is not tuple or any(type(v) is not S for v in symbols)
                or type(slot) is not tuple or len(slot)>2
                or any(type(i) is not int or i not in (0,1) for i in slot)
                or slot!=tuple(sorted(slot))):
            raise ValueError('invalid exact original mask, symbols or raw slot')
        prior=m.get(key)
        value=c if prior is None else prior+c
        if value:
            if prior is None:
                self._admit(1)
                m[key]=value
                self._update(1)
            else:
                m[key]=value
        elif prior is not None:
            del m[key]
            self._update(-1)

    def ingest(self,rows):
        h=self.new_map()
        try:
            for key,c in rows: self.put(h,key,c)
        except BaseException:
            self.drop(h)
            raise
        return h

    def drop(self,h):
        self._check()
        self._require_map(h,mutable=True)
        self._update(-len(self._maps.pop(h)))

    def _new_index(self):
        self._check()
        h=self._new_id()
        self._index_slots[h]=0
        return h

    def _index_admit(self,h,extra):
        self._check()
        self._require_index(h)
        if type(extra) is not int or extra < 0:
            raise ValueError('invalid exact index increment')
        self._admit(extra)
        self._index_slots[h]+=extra
        self._update(extra)

    def _drop_index(self,h):
        self._check()
        self._require_index(h)
        self._update(-self._index_slots.pop(h))

    def retained(self,a,b):
        self._check()
        self._require_map(a)
        self._require_map(b)
        return tuple(sorted(set(self._maps)-{a,b}))

    def _check_join(self,a,b,retained):
        self._check()
        self._require_map(a)
        self._require_map(b)
        if type(retained) is not tuple or any(type(h) is not int or h <= 0 for h in retained):
            raise ValueError('retained must name exact positive owned handles')
        if len(set(retained))!=len(retained) or set(retained)!=set(self._maps)-{a,b}:
            raise ValueError('inconsistent retained live-map roster')

    def metric(self):
        self._check()
        return dict(visits=self._used,charged_by_kind=dict(self._charged),
                    live_records=self._live,peak_records=self._peak,
                    live_maps=len(self._maps),live_indexes=len(self._index_slots),
                    active_readers=sum(self._readers.values()))

    def count(self,h):
        self._check()
        return len(self._require_map(h))

    def get(self,h,key):
        self._check()
        return self._require_map(h).get(key)

    def scan(self,h,callback):
        """Synchronous borrow: callback receives an immutable key/value pair only."""
        self._check()
        m=self._require_map(h)
        self._readers[h]=self._readers.get(h,0)+1
        try:
            for key,value in m.items():
                callback(key,value)
        finally:
            n=self._readers[h]-1
            if n:
                self._readers[h]=n
            else:
                del self._readers[h]

    def _bucket(self,h,shared,ticket):
        buckets={}
        for key,value in self._maps[h].items():
            mask=key[0]&shared
            if mask not in buckets:
                self._index_admit(ticket,1)
                buckets[mask]=[]
            self._index_admit(ticket,1)
            buckets[mask].append((key,value))
        return buckets

    def _product(self,out,litem,ritem):
        (lm,lk,lj),lc=litem
        (rm,rk,rj),rc=ritem
        if lm&rm or len(lj)+len(rj)>2:
            return
        slot=tuple(sorted(lj+rj))
        multiplier=1
        for label in set(slot):
            multiplier*=comb(slot.count(label),lj.count(label))
        sign=1
        bits=lm
        while bits:
            low=bits&-bits
            if (rm&(low-1)).bit_count()%2:
                sign=-sign
            bits^=low
        self.put(out,(lm|rm,tuple(sorted(lk+rk)),slot),lc*rc*(sign*multiplier))

    def join(self,a,b,retained=(),*,complement=False):
        self._check_join(a,b,retained)
        out=self.new_map()
        ticket=None
        stats=dict(bucket_checks=0, compatible_record_visits=0, record_visits=0,
                   shared_bits=0,index_records=0)
        try:
            if complement:
                union_a=union_b=0
                for mask,_,_ in self._maps[a]: union_a|=mask
                for mask,_,_ in self._maps[b]: union_b|=mask
                shared=union_a&union_b
                stats['shared_bits']=shared.bit_count()
                ticket=self._new_index()
                left=self._bucket(a,shared,ticket)
                right=self._bucket(b,shared,ticket)
                stats['index_records']=self._index_slots[ticket]
                for lm,rows in left.items():
                    for rm,cols in right.items():
                        self.visit('buckets')
                        stats['bucket_checks']+=1
                        if lm&rm: continue
                        for litem in rows:
                            for ritem in cols:
                                self.visit()
                                stats['compatible_record_visits']+=1
                                self._product(out,litem,ritem)
            else:
                for litem in self._maps[a].items():
                    for ritem in self._maps[b].items():
                        self.visit()
                        stats['record_visits']+=1
                        self._product(out,litem,ritem)
        except BaseException:
            self.drop(out)
            raise
        finally:
            if ticket is not None:
                self._drop_index(ticket)
        return out,stats

def exterior(reg,alpha):
    return o.assemble_coframe(reg,f.original_coframe_blocks(reg,alpha)).to_exterior(reg)

def rows(e):
    return (((mask,key,()),value) for mask,p in e.terms for key,value in p.terms)

def factors(reg):
    x=reg.sites[0]
    k,l,mu,nu,a,b=2,3,0,1,0,1
    anchor=(x,k)
    xk=reg.step(x,k)[0]
    anchors=(anchor,(xk,l),(reg.step(x,l)[0],k),(x,l))
    def link(site_axis):
        return f.original_spin4_link(*(tuple(P.variable(S('q',(*site_axis,chi,j)))
                                      for j in range(4)) for chi in ('L','R')))
    u=f.original_plaquette(reg,x,k,l,{z:link(z) for z in anchors})
    g=o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    trace=sum((u[i][j]*g[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))
    return (exterior(reg,(x,mu,a)),exterior(reg,(x,nu,b)),E(((0,trace),)),
            exterior(reg,(xk,k,0)),anchor)

def make_prefix(caps,actual):
    arena=Arena(caps)
    a,b=arena.ingest(rows(actual[0])),arena.ingest(rows(actual[1]))
    c,_=arena.join(a,b)
    arena.drop(a); arena.drop(b)
    t=arena.ingest(rows(actual[2]))
    return arena,c,t

def future_prefix(caps,actual):
    arena,c,t=make_prefix(caps,actual)
    future=arena.ingest(rows(actual[3]))
    d,_=arena.join(t,future,(c,))
    arena.drop(t); arena.drop(future)
    return arena,c,d

def attempt(arena,a,b,*,complement=False):
    before=arena.metric()
    try: arena.join(a,b,arena.retained(a,b),complement=complement)
    except Refusal as exc:
        after=arena.metric()
        assert after['live_records']==before['live_records']
        assert after['live_maps']==before['live_maps'] and not after['live_indexes'] and not after['active_readers']
        return dict(refused=exc.kind,at_visits=exc.visits,requested_live_records=exc.live,
                    released_partial_map_and_index=True,before=before,after=after)
    raise AssertionError('bounded refusal was required')


def oracle_snapshot(arena,h):
    """Explicit independent bounded scratch copy, never part of a live join."""
    result={}
    arena.scan(h,lambda key,value:result.__setitem__(key,value))
    return result

def as_exterior(terms):
    assert all(j==() for _,_,j in terms)
    return E(tuple((mask,P(((key,value),))) for (mask,key,_),value in terms.items()))

def assert_exact(arena,h,reference):
    assert arena.count(h)==len(reference)
    def match(key,c): assert c==reference[key]
    arena.scan(h,match)

def add_handle(arena,out,h):
    arena.scan(h,lambda key,v:arena.put(out,key,v))

def ownership_controls():
    arena=Arena(Caps(20,20))
    key=(1,(),())
    h=arena.ingest(((key,Q(3)),))
    blocked=[]
    def read(k,c):
        assert k==key and c==Q(3)
        for invoke in (lambda:arena.drop(h),lambda:arena.put(h,k,Q(1))):
            try: invoke()
            except ValueError: blocked.append(True)
            else: raise AssertionError('mutated active borrow')
        return {'data':(k,c)}  # callback return is not a map/iterator escape.
    assert not hasattr(arena,'map')
    assert arena.scan(h,read) is None and len(blocked)==2
    def raise_read(k,c):
        raise RuntimeError('bounded reader failure')
    try: arena.scan(h,raise_read)
    except RuntimeError: pass
    else: raise AssertionError('reader exception not seen')
    assert arena.metric()['active_readers']==0
    assert arena.get(h,key)==Q(3)
    invalid=0
    for bad in (True,False,1.0,0,-1,float('nan'),h+100):
        for call in (lambda:arena.get(bad,key),lambda:arena.count(bad),
                     lambda:arena.scan(bad,lambda *_:None),lambda:arena.drop(bad),
                     lambda:arena.put(bad,key,Q(1)),lambda:arena.retained(bad,h),
                     lambda:arena.join(bad,h)):
            try: call()
            except ValueError: invalid+=1
            else: raise AssertionError((bad,call))
    assert arena.get(h,key)==Q(3) and arena.metric()['live_records']==1
    it=arena._new_index()
    arena._index_admit(it,1)
    for bad in (True,float('nan'),-1,1.0):
        for call in (lambda:arena._index_admit(bad,1),lambda:arena._drop_index(bad),
                     lambda:arena._index_admit(it,bad)):
            try: call()
            except ValueError: invalid+=1
            else: raise AssertionError((bad,call))
    arena._drop_index(it)
    honest=arena._serial
    for bad in (0,True,-1,1.0,float('nan')):
        arena._serial=bad
        for action in (arena.new_map,arena._new_index):
            try: action()
            except ValueError: pass
            else: raise AssertionError('corrupt serial allocated')
            # Inspect without normal guard while serial remains adversarial.
            assert set(arena._maps)=={h} and arena._maps[h]=={key:Q(3)}
            assert not arena._index_slots and arena._live==1
        arena._serial=honest
    malformed=(((True,(),()),Q(1)),((1,[S('g2',())],()),Q(1)),
               ((1,(),(False,)),Q(1)),(key,{'mutable':'not a coefficient'}))
    for k,c in malformed:
        try: arena.put(h,k,c)
        except ValueError: pass
        else: raise AssertionError('mutable or inexact record accepted')
    arena.drop(h)
    assert arena.metric()['live_records']==0
    arena._serial=0  # Even an empty arena must not revive a stale handle.
    try: arena.new_map()
    except ValueError: pass
    else: raise AssertionError('stale handle revived')
    assert not arena._maps and arena._issued_serial==honest
    arena._serial=honest
    assert arena.new_map()>honest
    return dict(escaped_view_interface_absent=True,callback_returns_no_borrow=True,
                active_borrow_mutation_refusals=len(blocked),reader_exception_releases=True,
                invalid_map_or_index_controls=invalid,pre_mutation_serial_refusals=11,
                invalid_record_controls=len(malformed))

def closed_trace(reg,x,k,l,mu,nu,a,b):
    anchors=((x,k),(reg.step(x,k)[0],l),(reg.step(x,l)[0],k),(x,l))
    def link(site_axis):
        return f.original_spin4_link(*(tuple(P.variable(S('q',(*site_axis,chi,j)))
                                      for j in range(4)) for chi in ('L','R')))
    u=f.original_plaquette(reg,x,k,l,{z:link(z) for z in anchors})
    g=o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    return sum((u[i][j]*g[j][i] for i,j in product(range(4),repeat=2)),P())*o.epsilon((k,l,mu,nu))

def literal_j(reg,y,mu,a):
    symbol=S('J',(y,mu,a))
    return symbol,exterior(reg,(y,mu,a))*P.variable(symbol)

def later_nonconstant_leaf(reg,y,reference):
    """A complete one-monomial leaf of a distinct real later S2 choice."""
    k,l,mu,nu,a,b=0,3,1,2,0,1
    trace=closed_trace(reg,y,k,l,mu,nu,a,b)
    assert trace
    v0=exterior(reg,(y,mu,a)); v1=exterior(reg,(y,nu,b))
    # This exact bounded control selects one actual coframe monomial per
    # factor and one actual curvature monomial, not a synthetic matrix.
    source0=list(rows(v0));source1=list(rows(v1))
    choices=iter(reference)
    for om,_,_ in choices:
        pair=next(((k0,c0,k1,c1) for k0,c0 in source0 for k1,c1 in source1
                   if not k0[0]&k1[0] and not om&(k0[0]|k1[0])),None)
        if pair is not None: break
    else: raise AssertionError('later center leaf has no compatible control')
    k0,c0,k1,c1=pair
    q,c=trace.terms[0]
    leaf=as_exterior({k0:c0})*as_exterior({k1:c1})*P(((tuple(sorted((*q,S('g2',())))),c),))
    assert len(tuple(rows(leaf)))==1
    return leaf,dict(center=y,world_order=(k,l,mu,nu),components=(a,b),
                     complete_trace_support=len(trace.terms),selected_monomial_leaves=1)

def derivative_contact(reg,y,j,arena,left,one_r):
    """Raw J then frame contact of the actual local world-coframe map."""
    bare0=exterior(reg,(y,0,0))
    bare1=exterior(reg,(y,1,0))
    t_and_s=((0,),(0,1))
    poly=P.variable(j)
    # J(t)=t J and A_{00}(s)=1+s, A_{01}(s)=s.
    # The first and mixed slots follow directly by labelled differentiation.
    contacts=arena.ingest(((mask,key,slot),c) for slot,term in
                          zip(t_and_s,(bare0*poly,(bare0+bare1)*poly),strict=True)
                          for mask,entry in term.terms for key,c in entry.terms)
    out=arena.new_map()
    for h in left:
        intermediate,_=arena.join(h,contacts,arena.retained(h,contacts),complement=True)
        add_handle(arena,out,intermediate)
        arena.drop(intermediate)
    sliced,_=arena.join(out,one_r,arena.retained(out,one_r),complement=True)
    source_jet=o.RawJet((0,1),(((),P()),((0,),poly)))
    frame_jet=o.RawJet((0,1),(((),bare0),((1,),bare0+bare1)))
    a,b=(as_exterior(oracle_snapshot(arena,h)) for h in left)
    r=as_exterior(oracle_snapshot(arena,one_r))
    direct=o.RawJet.constant((a+b)*r)*frame_jet*source_jet
    exact={(mask,key,slot):c for slot in INDICES
           for mask,entry in direct.at(slot).terms for key,c in entry.terms}
    assert_exact(arena,sliced,exact)
    counts={str(slot):sum(jj==slot for _,_,jj in exact) for slot in t_and_s}
    assert all(counts.values()) and sum(counts.values())==len(exact)
    records=arena.count(contacts)
    arena.drop(sliced); arena.drop(out); arena.drop(contacts)
    return dict(literal_source_and_mixed_frame_derivatives_equal=True,
                raw_slots=counts,actual_contact_input_records=records)


def case(reg):
    x=reg.sites[0]
    y=reg.step(x,0)[0]
    ybit=1<<(8*reg.site_number(y))
    actual=factors(reg)
    arena,C,R=future_prefix(Caps(200_000,65_536),actual)
    g2=S('g2',())
    j,T=literal_j(reg,y,0,0)
    contact=arena.ingest(rows(T))
    assert arena.count(contact)==64
    expected_anchors={(x,0),(y,0)}
    assert {b.anchor for b in f.original_coframe_blocks(reg,(y,0,0))}==expected_anchors

    # Two complete predecessor partitions previously found in the
    # first deterministic collision search. Both use the same private
    # endpoint mask and axis-1 coordinate, but differ on actual axis 0.
    labels=tuple(tuple(sorted((S('q',(x,0,'L',axis)),S('q',(x,1,'L',0)))))
                 for axis in (1,2))
    left=tuple(arena.new_map() for _ in labels)
    def take(key,value):
        mask,symbols,j0=key
        if mask&((255)<<(8*reg.site_number(y)))==ybit and symbols in labels:
            assert j0==()
            h=left[labels.index(symbols)]
            arena.put(h,(mask,tuple(sorted((*symbols,g2))),()),value)
    arena.scan(C,take)
    before_parts=tuple(arena.count(h) for h in left)
    assert all(n>0 for n in before_parts)

    # Eager actual complete predecessor partition, followed by the
    # original later-center literal contact. This is bounded and must
    # fail closed under the preserved record/visit envelope.
    eager,stats=arena.join(left[0],R,arena.retained(left[0],R),complement=True)
    predecessor_count=arena.count(eager)
    eager_refusal=attempt(arena,eager,contact,complement=True)
    arena.drop(eager)

    # Moving the even-degree contact to the C side is exact; then
    # merge after keys stop identifying the earlier partitions.
    contact_parts=[]
    for h in left:
        part,_=arena.join(h,contact,arena.retained(h,contact),complement=True)
        contact_parts.append(part)
    observed=dict(collisions=0,opposite_sign_exact_cancellations=0)
    def collision(key,value):
        other=arena.get(contact_parts[1],key)
        if other is not None:
            observed['collisions']+=1
            observed['opposite_sign_exact_cancellations']+=int(not(value+other))
    arena.scan(contact_parts[0],collision)
    assert observed['collisions'] and observed['opposite_sign_exact_cancellations']
    residual=arena.new_map()
    for h in contact_parts: add_handle(arena,residual,h)
    assert arena.count(residual)>0

    # Choose the first actual R coefficient carrying a genuinely
    # squared shared quaternion coordinate, and retain its complete
    # bounded contact comparison. Selection receives immutable records.
    one_r=arena.new_map()
    def take_r(key,value):
        if not arena.count(one_r) and any(key[1].count(s)==2 and s.index[:2]==actual[-1]
                                         for s in set(key[1])):
            arena.put(one_r,key,value)
    arena.scan(R,take_r)
    assert arena.count(one_r)==1

    factored,_=arena.join(residual,one_r,arena.retained(residual,one_r),complement=True)
    a,b=(as_exterior(oracle_snapshot(arena,h)) for h in left)
    r=as_exterior(oracle_snapshot(arena,one_r))
    # Independent original exterior product in the eager order C R T.
    raw=(a+b)*r*T
    ref=dict(rows(raw))
    assert ref
    assert_exact(arena,factored,ref)
    assert all(j in key for _,key,_ in ref)
    derivatives=derivative_contact(reg,y,j,arena,left,one_r)

    # Make a complete reachable residual subpartition with ALL actual
    # R records. It retains the two original axis-0 anchors until
    # their actual final future source uses have been proved absent.
    selected=arena.new_map()
    def take_residual(key,value):
        if not arena.count(selected):
            arena.put(selected,key,value)
    arena.scan(residual,take_residual)
    completed,part_stats=arena.join(selected,R,arena.retained(selected,R),complement=True)
    assert arena.count(completed)>0
    whole_r_count=arena.count(R)
    full_residual_count=arena.count(completed)
    arena.drop(completed); arena.drop(selected)

    leaf,later_scope=later_nonconstant_leaf(reg,y,ref)
    later=arena.ingest(rows(leaf))
    downstream,_=arena.join(factored,later,arena.retained(factored,later),complement=True)
    final_ref=dict(rows(raw*leaf))
    assert final_ref
    assert_exact(arena,downstream,final_ref)
    assert all(sum(s.family=='g2' for s in key)==2 and j in key for _,key,_ in final_ref)
    return dict(root=x,later_center=y,literal_J_label=j.index,
        original_contact_anchor_count=len(expected_anchors),contact_records=arena.count(contact),
        predecessor_partitions_input_records=before_parts,
        predecessor_first_complete_outputs=predecessor_count,
        predecessor_first_join_stats=stats,
        eager_later_contact_refusal=eager_refusal,
        factored_contact_outputs_by_partition=[arena.count(h) for h in contact_parts],
        reaggregation=observed,signed_reaggregated_contact_records=arena.count(residual),
        direct_original_oracle_equal=True,direct_original_oracle_outputs=len(ref),
        literal_and_mixed_frame_contact=derivatives,
        complete_residual_partition=dict(right_input_records=whole_r_count,outputs=full_residual_count,stats=part_stats),
        selected_later_nonconstant_action_leaf=later_scope,
        after_later_action_equal=True,after_later_action_outputs=len(final_ref),
        final_tracked_metrics=arena.metric())

def main():
    print(json.dumps(dict(ownership=ownership_controls(),result=case(o.OriginalRegulator()),
        all_original_alternatives=ALTERNATIVES,native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_unit='bytes' if sys.platform=='darwin' else 'KiB'),indent=2))
if __name__=='__main__':main()
