# Independent original N16 later-center and contact review R3

**ACCEPT the pinned bounded contraction and its logical occupancy under
the measured caller discipline.** The direct signed calculation verifies
the actual later-center literal and mixed-frame contact, cross-partition
reaggregation, the full right-map join for one residual key, and one
genuine later S2 leaf. The arena fixes all three reported R2 failures
under its normal API. Generic arena admission still needs the refusal
lifetime control below. The complete later action factor, all remaining
source families, all nine choices, global cost, full Z and connected
normalization remain open.

## Authority and replay

At exact primary `25b5f229ce3f518ac08a9279f1680f2068cd4a4c`, read the
pinned notebook, original implementation plan and R2 acceptance, the
complete R3 probe, and the actual regulator, coframe, plaquette, action,
and exact coefficient definitions. First and final continuity checks
were byte-identical, fresh with no changed inputs. The author R3 script
SHA256 was
`78ca81eabeaa0d926e97b4e8f5891d4cc3af0b60c702562d10721fea5a741651`.

Running the exact author script using the primary's Python matched
every deterministic field. Independent replay peak native RSS was
114,606,080 bytes. The bounded eager contact failed at visit 47,480
before record 65,537. Both map counts and logical input storage were
restored, with no residual index or active reader in the measured caller.
The test did not return a partial join.

## Independent original factors and signed results

The independent code expands each original signed hopping block
directly on the globally ordered bar/psi basis. It evaluates the closed
plaquette using explicit matrix order D† C† B A and forms the signed
gamma trace. A direct cartesian product uses explicit basis inversions
and factorials for raw label multiplicity. This oracle uses the
repository's exact rational coefficient arithmetic and original
hopping-block and link declarations. It does not use the arena product,
ExteriorPolynomial product, RawJet product, or the author's final
contact oracle to compute its reference. The author arena order is
used only for the original selected row/residual and leaf identities.
The full signed C and R maps matched 3,584 and 8,192 terms.

The two complete predecessor partitions have three C rows each. The
64-row literal contact is based at y=x+e0 and touches distinct anchors
(x,0) and (y,0). Each factored contact has 136 signed outputs. Direct
key comparison yields 12 cross-partition collisions and six exact
opposite-sign cancellations, leaving 254 nonzero residual coefficients.
Both C×T partitions and the merged residual matched the arena term by
term. The contact and R have even exterior degrees, so reordering these
two exact factors before the Haar step preserves signs.

For the selected R term with a squared genuinely shared link
coordinate, the direct C R T product yielded 209 first-contact
coefficients. For the chosen frame row derivative, the coefficient of
t s is the sum of the two actual world components of the coframe,
bearing the same literal J label. This direct product yielded 545
mixed terms, including direction-1 anchors (y,1) and (y+e1,1). All
754 signed coefficients matched. The complete selected residual
key multiplied by every original R row gave 5,120 signed outputs,
all of which matched. That bucket pass used four checks and 8,198
live index directory/reference slots.

At y, independently evaluate all four equivalent curvature/coframe
orderings in the grouped S2 term. Their oriented trace maps agree
across both reversals, so the four constituent quarters give the
128-term grouped trace. Independently exhibit the selected leaf as
one actual product of the two coframe monomials and a term of that
trace. Its exact direct signed product with the literal contact
matched all 122 outputs and retained the second g2 label. This is
a selected monomial leaf, with the complete later vertex still owed.

## Adverse controls and promotion boundary

Independently reproduce R2's dropped-but-live mapping proxy, Boolean
handle read/removal, and live-map overwrite after rolling the
allocation serial backward. Under R3, the API exposes no mapping
view. Same-map put/drop fail inside nested synchronous reads, nested
reader exceptions restore the outer reader count, and all seven
tested Boolean-handle operations fail. Corrupt serial refuses both
map and index creation before mutation and refuses stale-handle
revival after the arena becomes empty. A separate cap of five
logical slots fails at the sixth index slot and restores both
input maps before any charged visit.

One new adverse case affects promotion. Saving the caught Refusal
keeps its traceback and the join's bucket maps alive. In a two-row
by two-row probe the refusal occurred at prospective slot 12 and the
arena immediately reported only the four input slots. The saved
traceback still held two bucket directories and four record references.
The pinned attempt helper does not retain the exception, so this
does not change its observed contraction or occupancy. Before treating
the arena as reusable memory admission, clear bucket local lifetimes
through the failure boundary or define and enforce a no-retained-
traceback API. Even with that fix, the logical budget is separate
from arithmetic temporaries, independently copied records, transient
source construction, arbitrary callback state, and process RSS.

Continue with the full actual later S2 factor and residual partitions,
preserving incidences and both source contact directions. When later
site/Haar projections can be proved final, reaggregate signed
contributions under their actual remaining keys. No earlier anchor
closure, global allocation claim, complete denominator, or physical
disposition follows from this bounded calculation.

Only scratch scripts and outputs were written. The first independent
script attempt used a wrong BlockIncrement attribute name and exited
before any calculation. Correcting it to the actual weight field
produced the complete independent run. No repository writes, native
build, full coefficient run, or Lean calls occurred.

Evidence file prefix is `task4-later-contact-review-r3-` in scratch.
The replay, independent script and JSON, retained-exception script
and JSON, and first/final continuity receipts belong to this review.
