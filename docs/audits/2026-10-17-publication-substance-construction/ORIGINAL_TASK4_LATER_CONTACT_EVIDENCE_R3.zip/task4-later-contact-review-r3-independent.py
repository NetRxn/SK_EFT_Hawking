from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial
import importlib.util
import json
import sys

from src.core import formulas as f
from src.vestigial import original_coefficients as o

def load(label, path):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[label] = module
    spec.loader.exec_module(module)
    return module

r2 = load("r2", "/tmp/publication-task4-shared-anchor-r2.py")
r3 = load("r3", "/tmp/publication-task4-later-contact-r3.py")
Q, P, S = o.QComplex, o.Polynomial, o.Symbol
reg = o.OriginalRegulator()
x, y = reg.sites[0], reg.step(reg.sites[0], 0)[0]
x2 = reg.step(x, 2)[0]
q = S("g2", ())
j = S("J", (y, 0, 0))
assert (reg.volume, reg.word, reg.convention) == (16, "closed", "source_C")

def tensor(alpha, *, slot=(), labels=()):
    # Rebuild the four signed bilinears directly from the block definition
    # and the globally ordered bar/psi basis. No author arena or ExteriorPolynomial.
    positions = {token: i for i, token in enumerate(reg.generator_order)}
    out = defaultdict(Q)
    blocks = f.original_coframe_blocks(reg, alpha)
    for b in blocks:
        for i, k in product(range(4), repeat=2):
            a, z = positions[b.bar_site, "bar", i], positions[b.psi_site, "psi", k]
            for key, value in b.matrix[i][k].terms:
                out[(1 << a | 1 << z, tuple(sorted((*labels, *key))), slot)] += value * b.weight * (-1 if a > z else 1)
    return {k: v for k, v in out.items() if v}

def trace_rows(site, k, l, mu, nu, a, b):
    # Direct closed matrix word D† C† B A, with original quaternion labels.
    anchors = (site,k), (reg.step(site,k)[0],l), (reg.step(site,l)[0],k), (site,l)
    links = [f.original_spin4_link(*(tuple(P.variable(S("q",(*z,chi,i))) for i in range(4))
                                     for chi in ("L","R"))) for z in anchors]
    A,B,C,D = links
    U = o.matrix_multiply(o.matrix_multiply(o.matrix_dagger(D),o.matrix_dagger(C)),o.matrix_multiply(B,A))
    gamma = o.matrix_multiply(o.matrix_multiply(reg.gamma[a],reg.gamma[b]),reg.gamma5)
    poly = sum((U[i][k]*gamma[k][i] for i,k in product(range(4),repeat=2)),P()) * o.epsilon((k,l,mu,nu))
    return {(0,key,()): value for key,value in poly.terms}

def indices(mask):
    return [i for i in range(mask.bit_length()) if mask >> i & 1]

def multiply(left, right):
    out = defaultdict(Q)
    for (lm,lk,lj), lv in left.items():
        for (rm,rk,rj), rv in right.items():
            if lm & rm or len(lj) + len(rj) > 2:
                continue
            z = tuple(sorted(lj + rj))
            multiplicity = 1
            for i in set(z):
                multiplicity *= factorial(z.count(i)) // (factorial(lj.count(i)) * factorial(rj.count(i)))
            parity = sum(i > k for i,k in product(indices(lm),indices(rm))) % 2
            out[lm|rm,tuple(sorted(lk+rk)),z] += lv * rv * (-multiplicity if parity else multiplicity)
    return {k:v for k,v in out.items() if v}

def summed(*maps):
    out = defaultdict(Q)
    for d in maps:
        for k,v in d.items(): out[k] += v
    return {k:v for k,v in out.items() if v}

def slot_relabel(d, slot):
    return {(m,k,slot):v for (m,k,_),v in d.items()}

def snapshot(arena, handle):
    out = {}
    arena.scan(handle, lambda k,v:out.__setitem__(k,v))
    return out

A = tensor((x,0,0))
B = tensor((x,1,1))
trace = trace_rows(x,2,3,0,1,0,1)
future = tensor((x2,2,0))
C = multiply(A,B)
R = multiply(trace,future)
assert (len(C),len(R),len(trace)) == (3584,8192,128)

# Use author arena only to recover its selected row order, then cross-check
# the whole generated source maps, rather than rely on row counts alone.
stage, ah, rh = r3.future_prefix(r3.Caps(200_000,65_536),r3.factors(reg))
author_C, author_R = snapshot(stage,ah),snapshot(stage,rh)
assert C == author_C and R == author_R
position = 8*reg.site_number(y)
y_mask = 255 << position
y_first = 1 << position
labels = [tuple(sorted((S("q",(x,0,"L",a)), S("q",(x,1,"L",0))))) for a in (1,2)]
Cparts = [{(m,tuple(sorted((*k,q))),s):v for (m,k,s),v in author_C.items()
           if m & y_mask == y_first and k==label} for label in labels]
assert [len(c) for c in Cparts] == [3,3]
T = tensor((y,0,0), labels=(j,))
T1 = tensor((y,1,0), labels=(j,))
assert len(T) == 64 and len(T1)==64
anchors = [{s.index[:2] for _,k,_ in t for s in k if s.family=="q"} for t in (T,T1)]
assert anchors == [{(x,0),(y,0)}, {(reg.step(y,1,-1)[0],1),(y,1)}]

part = [multiply(c,T) for c in Cparts]
collision = part[0].keys() & part[1].keys()
cancel = {k for k in collision if part[0][k]+part[1][k] == Q(0)}
left = summed(*part)
assert [len(c) for c in part] == [136,136]
assert (len(collision),len(cancel),len(left)) == (12,6,254)
first_r = next(k for k in author_R if any(s.index[:2]==(x,2) and k[1].count(s)==2 for s in k[1]))
R1 = {first_r:R[first_r]}
direct_prefix = multiply(summed(*Cparts),R1)
literal = multiply(direct_prefix,T)
mixed = multiply(direct_prefix,summed(T,T1))
assert (len(literal),len(mixed)) == (209,545)
assert literal == multiply(left,R1)

# Compare all reported signed coefficients with the R3 bucket join.
ch = [stage.ingest(c.items()) for c in Cparts]
t = stage.ingest(T.items())
parts = [stage.join(h,t,stage.retained(h,t),complement=True)[0] for h in ch]
for p,m in zip(parts,part,strict=True): assert snapshot(stage,p)==m
residual = stage.new_map()
for h in parts: stage.scan(h,lambda k,v:stage.put(residual,k,v))
assert snapshot(stage,residual)==left
chosen = next(iter(snapshot(stage,residual)))
assert len(multiply({chosen:left[chosen]},R)) == 5120
sel = stage.ingest(((chosen,left[chosen]),))
whole, stats = stage.join(sel,rh,stage.retained(sel,rh),complement=True)
assert snapshot(stage,whole)==multiply({chosen:left[chosen]},R)
assert (stats["bucket_checks"],stats["index_records"])==(4,8198)
stage.drop(whole)
stage.drop(sel)
one = stage.ingest(R1.items())
for expected,slot in [(literal,(0,)),(mixed,(0,1))]:
    t_slot = slot_relabel(T if slot==(0,) else summed(T,T1),slot)
    tj = stage.ingest(t_slot.items())
    p = stage.new_map()
    for h in ch:
        jh,_ = stage.join(h,tj,stage.retained(h,tj),complement=True)
        stage.scan(jh,lambda k,v:stage.put(p,k,v))
        stage.drop(jh)
    out,_ = stage.join(p,one,stage.retained(p,one),complement=True)
    assert snapshot(stage,out)==slot_relabel(expected,slot)
    for h in (out,p,tj): stage.drop(h)

# Check actual later grouped term against the four constituent signed
# quarter terms, including both reversals, and verify the selected leaf.
k,l,mu,nu,a,b = 0,3,1,2,0,1
later0 = tensor((y,mu,a))
later1 = tensor((y,nu,b))
traces = (trace_rows(y,k,l,mu,nu,a,b),
          trace_rows(y,l,k,mu,nu,a,b),
          trace_rows(y,k,l,nu,mu,b,a),
          trace_rows(y,l,k,nu,mu,b,a))
assert all(t==traces[0] for t in traces)
assert len(traces[0]) == 128
author_leaf,_ = r3.later_nonconstant_leaf(reg,y,dict(sorted(literal.items())))
leaf = dict(r3.rows(author_leaf))
assert len(leaf) == 1
key,val = next(iter(leaf.items()))
witness = None
for (m,k,s),v in later0.items():
    if m & key[0] != m: continue
    for (m1,k1,s1),v1 in later1.items():
        if m & m1 or m | m1 != key[0]: continue
        for (tm,tk,ts),tv in traces[0].items():
            if tuple(sorted((*k,*k1,*tk,q))) != key[1]: continue
            candidate = multiply(multiply({(m,k,s):v},{(m1,k1,s1):v1}),
                                 {(tm,tuple(sorted((*tk,q))),ts):tv})
            if candidate==leaf:
                witness=(m,m1,tm)
                break
        if witness: break
    if witness: break
assert witness
later = multiply(literal,leaf)
assert len(later)==122
hbase = stage.ingest(literal.items())
hleaf = stage.ingest(leaf.items())
h,_ = stage.join(hbase,hleaf,stage.retained(hbase,hleaf),complement=True)
assert snapshot(stage,h)==later

# Explicit R2 reproduction and R3 refusal/reader cleanup, with fresh arenas.
k0,k1=(1,(),()),(2,(),())
previous=r2.Arena(r2.Caps(10,1))
handle=previous.ingest(((k0,Q(1)),))
view=previous.map(handle)
previous.drop(handle)
assert previous.metric()["live_records"] == 0 and view[k0]==Q(1)
previous=r2.Arena(r2.Caps(10,3))
handle=previous.ingest(((k0,Q(1)),))
assert previous.map(True)[k0]==Q(1)
previous.drop(True)
assert previous.metric()["live_records"]==0
previous=r2.Arena(r2.Caps(10,3))
handle=previous.ingest(((k0,Q(1)),))
previous._serial=0
assert previous.new_map()==handle and not previous._maps[handle]

def refuses(action):
    try: action()
    except ValueError: return
    raise AssertionError("control was incorrectly admitted")

arena = r3.Arena(r3.Caps(20,20))
h = arena.ingest(((k0,Q(3)),))
assert not hasattr(arena,"map")
retained = []
def visit(k,c):
    retained.append((k,c))
    refuses(lambda:arena.put(h,k,Q(1)))
    refuses(lambda:arena.drop(h))
    def nested(k,c):
        assert arena.metric()["active_readers"] == 2
        raise RuntimeError("independent reader")
    try: arena.scan(h,nested)
    except RuntimeError: pass
    assert arena.metric()["active_readers"] == 1
    return k,c
assert arena.scan(h,visit) is None
assert arena.metric()["active_readers"]==0
for name,args in [("get",(True,k0)),("put",(True,k0,Q(1))),("drop",(True,)),
                  ("scan",(True,lambda *_:None)),("count",(True,)),
                  ("join",(True,h)),("retained",(True,h))]:
    refuses(lambda:getattr(arena,name)(*args))
assert snapshot(arena,h)=={k0:Q(3)}
for action in (arena.new_map,arena._new_index):
    arena._serial=0
    refuses(action)
    assert arena._maps[h]=={k0:Q(3)} and arena._live==1 and not arena._index_slots
    arena._serial=arena._issued_serial
arena.drop(h)
arena._serial=0
refuses(arena.new_map)
assert not arena._maps
arena._serial=arena._issued_serial
assert arena.new_map()>h

bounded=r3.Arena(r3.Caps(10,5))
left_handle = bounded.ingest(((k0,Q(1)),))
right_handle = bounded.ingest(((k1,Q(1)),))
before = bounded.metric()
try: bounded.join(left_handle,right_handle,complement=True)
except r3.Refusal as e:
    assert (e.kind,e.visits,e.live)==("records",0,6)
else: raise AssertionError("independent bucket allocation overflow not refused")
after=bounded.metric()
assert all(before[k]==after[k] for k in ("visits","live_records","live_maps","live_indexes","active_readers"))
assert snapshot(bounded,left_handle)=={k0:Q(1)} and snapshot(bounded,right_handle)=={k1:Q(1)}
print(json.dumps(dict(original_C=len(C), original_R=len(R), source_anchors=sorted(map(sorted,anchors)),
    collisions=len(collision), cancellations=len(cancel), residual=len(left), first=len(literal),
    mixed=len(mixed), full_R_residual=5120, signed_leaf_outputs=len(later),
    grouped_trace_quarter_agreement=True, R2_failures_reproduced=3,
    R3_adverse_read_handle_serial_checks=True, R3_bucket_cap_rollback=after),indent=2))
