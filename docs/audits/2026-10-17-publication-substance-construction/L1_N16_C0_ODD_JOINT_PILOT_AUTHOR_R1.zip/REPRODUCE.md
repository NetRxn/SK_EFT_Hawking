# L1 odd-root joint contraction pilot, author preflight

Candidate science source is 51e7c745e. The accepted residual and parity
preflight are in L1_N16_C0_SHARED_EDGE_ONE_ZERO_R1.zip at dff31cc3a. The
representative (103607566400,1256282136720) has weight 96 and remains in
that residual. This package resolves support and anchor tensors only.
It does not evaluate any signed Grassmann coefficient.

The local projection gives 1,048,576 representation assignments and the
parity screen allows 256. Adding temporal SU(2) singlet conditions, cross-layer
spatial spin budgets, and zero-load equalities leaves nine candidates.
A separate explicit traversal of all 1,048,576 assignments matches the
nine exported label tuples. The search enters 17 nodes under a
prospective 4,096-node cap. These are necessary constraints. A surviving
candidate can still integrate to zero.

For the surviving labels the normalized temporal tensors were evaluated
using quaternion Haar moments from the science checkout. The spatial
tables retain the two directed anchor variables, their two representation
matrix factors and the monomial in coframe coordinates on each anchor.
The anchor plan uses local degree from zero through the edge's total
coframe degree. A subsequent contraction must impose the original two
anchor allocations jointly. Symmetric powers use the unnormalized
polynomial basis, and the root tensors use the dual matrix index
convention from d times the normalized Haar coefficient of D(g^-1).
The fundamental empty-anchor Schur pairing is checked entry by entry.

The archive contains 1,718 root Fourier entries, 137 distinct temporal
moment entries across ten shapes, and 1,471 spatial moment entries across
15 shapes. The temporal enumeration considered 1,009 entries and the
spatial preflight bounded the work by 25,029 entries before multiplying
polynomials. The root projections retain all represented quadratic
channels and the particular surviving fundamental cubic channels.

The pilot geometry is two two-edge paths on one layer and two disjoint
four-cycles on the other. The same pair of component signatures covers
303 residual orbits and 26,280 labels. At least one layer decomposes
into multiple components for 273,201 labels in the odd/shared class.
Component shape alone does not determine contraction width. The next
step is to sew the original coframe factors, root generator words and
these Haar tensors with an original signed site order, planned join
work, and all factorials retained. Test nontrivial controls and obtain
independent replay before accepting any coefficient.

## Replay

Restore the prior one-or-zero shared-edge archive into FROZEN. Recover
the directed-square author's AUTHOR, INDEPENDENT and family-intake from
the earlier pilot and chain archives into PRIOR as their instructions
specify. The existing Python environment needs NumPy. Set PYTHONPATH
to the clean science checkout and use that environment for PY.

```sh
python3 joint_support.py "$FROZEN/preflight" "$PRIOR" "$FROZEN" > support.out
python3 brute_support.py "$PRIOR" > brute-support.out
python3 component_screen.py "$PRIOR" "$FROZEN/block-remaining.tsv" > components.out
"$PY" temporal.py > temporal.out
"$PY" root.py "$PRIOR/AUTHOR/bivectors.tsv" > root.out
"$PY" spatial.py > spatial.out
shasum -a 256 -c manifest.sha256
```
