from collections import Counter
from pathlib import Path
import sys

p=Path(sys.argv[1])/'family-intake/directed_roster.py'
namespace={'__file__':str(p)}
exec(p.read_text().split('\nselected=[]',1)[0],namespace)
projection,occupancy=(namespace[n] for n in ('projection','occupancy'))
p=p.with_name('residual_shapes.py')
namespace={'__file__':str(p)}
exec(p.read_text().split('\nrows=',1)[0],namespace)
components=namespace['components']

def signature(graph):
    result=[]
    for component in components(graph):
        degree=Counter(x for edge in component for x in edge[:2])
        result.append((len(component),tuple(sorted(degree.values()))))
    return tuple(sorted(result))
totals=Counter()
main_counts=Counter()
for row in Path(sys.argv[2]).read_text().splitlines():
    a,b,w=map(int,row.split())
    if not any(n%2 for s in occupancy(a)+occupancy(b) for n in s):continue
    (g,h),_,_=projection(a,b,2)
    if not g.keys() & h.keys():continue
    key=tuple(sorted((signature(g),signature(h))))
    totals[key]+=w
    main_counts[key]+=1
g,h=projection(103607566400,1256282136720,2)[0]
expected=tuple(sorted((signature(g),signature(h))))
print('pilot component signature',expected,'orbits',main_counts[expected],'labels',totals[expected])
all_connected=sum(w for k,w in totals.items() if len(k[0])<=1 and len(k[1])<=1)
print('at least one decomposable layer:',sum(totals.values())-all_connected,'labels')
print('top 12')
for k,w in totals.most_common(12):
    print(main_counts[k],w,k)
