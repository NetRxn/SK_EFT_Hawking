from collections import defaultdict
from functools import cache
from itertools import product
from math import prod
from pathlib import Path
import sys
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import Polynomial, QComplex, Symbol, haar_polynomial

q=tuple(tuple(Polynomial.variable(Symbol('q',(0,0,chirality,j))) for j in range(4)) for chirality in ('L','R'))
U=original_spin4_link(*q)
I=(1,0,0,0)
V=defaultdict(int,{(h,a,b,i):s for h,a,b,i,s in (map(int,row.split()) for row in Path(sys.argv[1]).read_text().splitlines())})
linear={(a,b):sum((2*V[h,a,b,i]*q[h][i+1] for h,i in product(range(2),range(3))),Polynomial())
        for a,b in product(range(4),repeat=2) if a!=b}

@cache
def matrix(h,n,inverse):
    coords=q[h]
    if inverse:
        coords=(coords[0],*(-v for v in coords[1:]))
    S=original_spin4_link(*((coords,I) if h==0 else (I,coords)))
    j=2*h
    W=tuple(tuple(S[j+a][j+b] for b in range(2)) for a in range(2))
    if n==0:return ((Polynomial.coerce(1),),)
    if n==1:return W
    assert n==2
    (a,b),(c,d)=W
    return ((a*a,a*b,b*b),(2*a*c,a*d+b*c,2*b*d),(c*c,c*d,d*d))

families={1:((0,1),(1,0)),2:((0,0),(0,2),(1,1),(2,0)),3:((0,1),(1,0))}
CAP=10000
values={}
for power,channels in families.items():
    polys=defaultdict(Polynomial)
    for words in product(linear,repeat=power):
        a,b=(tuple(sorted(seq)) for seq in zip(*words))
        z=Polynomial.coerce(1)
        for word in words:z*=linear[word]
        polys[a,b]+=z
    planned=len(polys)*sum(((a+1)*(b+1))**2 for a,b in channels)
    assert planned<=CAP
    max_terms=0
    for word,polynomial in sorted(polys.items()):
        for left,right in channels:
            L=matrix(0,left,True);R=matrix(1,right,True)
            d=len(L)*len(R)
            for a,b,c,e in product(range(len(L)),range(len(L)),range(len(R)),range(len(R))):
                p=polynomial*L[a][b]*R[c][e]; max_terms=max(max_terms,len(p.terms))
                projected=haar_polynomial(p).terms
                if projected:
                    ((key,value),)=projected
                    assert not key
                    values[power,*word,left,right,a*len(R)+c,b*len(R)+e]=value*d
    print('root power',power,'words',len(polys),'matrix projections',planned,'max monomials before Haar',max_terms,
          'nonzero',sum(k[0]==power for k in values))
    if power==1:
        for word,poly in polys.items():
            restored=Polynomial()
            for L,R in channels:
                d=R+1
                for a,b,c,e in product(range(L+1),range(L+1),range(R+1),range(R+1)):
                    coeff=values.get((power,*word,L,R,a*d+c,b*d+e),QComplex())
                    restored += matrix(0,L,False)[b][a]*matrix(1,R,False)[e][c]*coeff
            assert restored==poly
    if power in (2,3):
        scalar=polys[(0,)*power,(1,)*power]
        # In the cubic fundamental projection retain the q component of q^3.
        if power==2:
            assert values[2,(0,0),(1,1),0,0,0,0]==haar_polynomial(scalar).terms[0][1]
        else:
            for h,i in product(range(2),range(1,4)):
                represented=Polynomial()
                for L,R in channels:
                    d=R+1
                    for a,b,c,e in product(range(L+1),range(L+1),range(R+1),range(R+1)):
                        coeff=values.get((power,(0,)*power,(1,)*power,L,R,a*d+c,b*d+e),QComplex())
                        represented += matrix(0,L,False)[b][a]*matrix(1,R,False)[e][c]*coeff
                assert haar_polynomial((scalar-represented)*q[h][i])==Polynomial()
with Path('root.tsv').open('w') as out:
    for key,value in sorted(values.items()):
        print(*key,value.real,value.imag,sep='\t',file=out)
