from collections import Counter, defaultdict, deque
from itertools import product
from math import prod
from pathlib import Path
import sys

preflight, source, frozen = sys.argv[1:]
p=Path(preflight)/'parity-cost.py'
sys.argv=[sys.argv[0],source,frozen]
env={'__file__':str(p)}
exec(p.read_text().split('\npending=',1)[0],env)
projection,profile,decode=(env[k] for k in ('projection','profile','occupancy'))
filt=projection.__wrapped__.__globals__['filter_constraint']

CAP=4096
a,b=103607566400,1256282136720
frozen=Path(frozen)
assert (a,b,96) in {tuple(map(int,row.split())) for row in (frozen/'block-remaining.tsv').read_text().splitlines()}
graphs,forced,domains=projection(a,b,2)
constraints=[]
loads=[profile(c)[2] for c in (a,b)]
temporal=defaultdict(list)
for t,graph in enumerate(graphs):
    for (u,v,k),(p,q) in graph.items():
        for x,m in ((u,p),(v,q)):
            if m:
                for y in (u,v):
                    temporal[t,y].append((t,x,k))
constraints.extend(('time',0,tuple(group)) for group in temporal.values())
for e in graphs[0].keys()|graphs[1].keys():
    u,v,k=e
    group=tuple((t,x,k) for x in (u,v) for t in range(2))
    constraints.append(('space',min(sum(load.get(e,(0,0))) for load in loads),group))
    for side,load in enumerate(loads):
        d=sum(load.get(e,(0,0)))
        constraints.append(('parity',d%2,group))
        if not d:
            constraints.append(('equal',0,group[:2]))
            constraints.append(('equal',0,group[2:]))
neighbors=defaultdict(set)
for i,(_,_,group) in enumerate(constraints):
    for name in group:neighbors[name].add(i)
checked=0
def reduce(state):
    q=deque(range(len(constraints))); queued=set(q)
    while q:
        i=q.popleft(); queued.remove(i)
        kind,limit,group=constraints[i]
        old=tuple(state[k] for k in group)
        if kind in ('time','space'):
            new=filt(kind,limit,old)
        else:
            choices=[
                labels for labels in product(*old)
                if (labels[0]==labels[1] if kind=='equal' else sum(p for p,q in labels)%2==limit)
            ]
            new=tuple(tuple(sorted(set(col))) for col in zip(*choices)) if choices else ()
        if not new or not all(new):return False
        for k,prev,after in zip(group,old,new):
            if prev==after:continue
            state[k]=after
            for j in sorted(neighbors[k]-queued-{i}):
                q.append(j);queued.add(j)
    return True
def solve(state):
    global checked
    checked+=1
    if checked>CAP:raise RuntimeError('candidate node limit')
    if not reduce(state):return
    choices=[k for k in state if len(state[k])>1]
    if not choices:
        yield {k:v[0] for k,v in state.items()}
        return
    k=min(choices,key=lambda x:(len(state[x]),-len(neighbors[x]),x))
    for label in state[k]:
        yield from solve(state|{k:(label,)})

states=list(solve(domains.copy()))
print('pilot',a,b,'original local product',prod(map(len,domains.values())),'parity product',env['screen'](a,b))
print('branch nodes',checked,'admissible support',len(states))
print('channel multiplicities', {k:dict(Counter(s[k] for s in states)) for k in domains if any(any(x) for x in domains[k])})
print('max link dimensions',max(prod((p+1)*(q+1) for name in group for p,q in [s[name]]) for s in states for group in temporal.values()))
with Path('states.tsv').open('w') as out:
    for i,state in enumerate(states):
        for (t,x,k),(l,r) in sorted(state.items()):
            if l or r:print(i,t,x,k,l,r,sep='\t',file=out)
with Path('anchor-plan.tsv').open('w') as out:
    for i,state in enumerate(states):
        for layer,load in enumerate(loads):
            for e in sorted(graphs[0].keys()|graphs[1].keys()|load.keys()):
                u,v,k=e
                degree=sum(load.get(e,(0,0)))
                for site in (u,v):
                    left=state.get((layer,site,k),(0,0))
                    right=state.get((1-layer,site,k),(0,0))
                    print(i,layer,site,k,degree,*left,*right,sep='\t',file=out)
