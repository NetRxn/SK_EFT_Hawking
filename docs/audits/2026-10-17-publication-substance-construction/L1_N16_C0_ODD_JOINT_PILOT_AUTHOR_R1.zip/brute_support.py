# Enumerate the original local domains without branch propagation.
from itertools import product
from pathlib import Path
from math import prod
import sys

source=Path(sys.argv[1])/'family-intake/directed_roster.py'
env={'__file__':str(source)}
exec(source.read_text().split('\nselected=[]',1)[0],env)
project,profile=(env[k] for k in ('projection','profile'))
a,b=103607566400,1256282136720
graphs,_,domains=project(a,b,2)
names=list(domains)
def temporal(t,x):
    return [j for j,(s,y,k) in enumerate(names) if s==t and x in (y,y^(1<<k))]
def singlet(values):
    return sum(values)%2==0 and 2*max(values, default=0)<=sum(values)
time=[temporal(t,x) for t in range(2) for x in range(8)]
space=[]
for u,v,k in graphs[0].keys()|graphs[1].keys():
    ids=[names.index((t,x,k)) for x in (u,v) for t in range(2)]
    powers=tuple(sum(profile(code)[2].get((u,v,k),(0,0))) for code in (a,b))
    space.append((ids,powers))
local_rows=prod(map(len,domains.values()))
assert local_rows==1048576
actual=set()
for state in product(*domains.values()):
    if not all(all(singlet([state[j][c] for j in idx]) for c in (0,1)) for idx in time):continue
    if not all(
        sum(abs(state[idx[s]][c]-state[idx[s+1]][c]) for s in (0,2) for c in (0,1))<=min(powers)
        and all(sum(state[j][0] for j in idx)%2==d%2 for d in powers)
        for idx,powers in space):
        continue
    actual.add(tuple(sorted((*key,*value) for key,value in zip(names,state) if any(value))))
from collections import defaultdict
manifest=defaultdict(list)
for line in Path('states.tsv').read_text().splitlines():
    case,*key=map(int,line.split())
    manifest[case].append(tuple(key))
assert set(map(tuple,manifest.values()))==actual and len(actual)==9
print(local_rows,'literal enumeration rows;',len(actual),'match the constraint propagation export')
