# Independent verification of complementary tuple 0 outer case 18

The exact normalized sum is
**11627739971317979867547/5192296858534827628530496329220096 + 0i**.

The original separator archive was read from publication checkpoint
150434b38a37d677285b1490de008f72b7a982d0 and matches the worktree bytes.
Its manifest verified. The decompressed complementary parent SHA256 is
9aa8da707a19577129ae84d4879cccdbd3af62b2fdecb2758d74143efe94212d
and its selector R(0,0,2,0,1) is 1. Its own rejected-pair histogram
regenerates the full original 48-coordinate roster over 6,427,904
matches and binds outer case 18 to (72, (1,)), with 106,344 products.
The inverse lift recovers 420,886 compatible parent rows and their exact
Gaussian coefficients and denominators. First-child case 18 has the same
coordinate and scalar under selector 0. The complementary source and
terminal states have distinct hashes and were independently contracted.
Complementary case 14 has the same scalar at (40, (1,)), with a different
seven-factor parent and separate terminal replays.

The two outer row-cap stages reproduce byte for byte from the pinned
parent and yield the seven-factor inner parent SHA256
60f62d16e54b2707b5ea362d10dd0031281c8a0e7d31d803d4d15b3223648a4d.
Independent histogram matching on its rejected pair regenerates the
exhaustive nine-coordinate census on G(0,1,2) over 1,021,248 products.
Every complete-network term must use one of those distinct matched
assignments. Exact inverse lifts recover each of the nine slice inputs.
Clean scratch execution reproduces all 17 inner author cycles including
the eight cap-saved inputs and the nine exact terminal receipts.
All saved states preserve the full conditioning, label partition and
positive denominator product.

| Slice | Inner coordinate | Matched parent pair products | Independently verified normalized real |
|---|---:|---:|---:|
| 0 | 3 | 13,824 | -11685140226577673415/1298074214633706907132624082305024 |
| 1 | 48 | 23,328 | 960746576681676897/81129638414606681695789005144064 |
| 2 | 5 | 60,480 | -1235404845747698074155/5192296858534827628530496329220096 |
| 3 | 12 | 91,584 | -2028411939483503527275/2596148429267413814265248164610048 |
| 4 | 96 | 112,752 | -11051962176191080095/1298074214633706907132624082305024 |
| 5 | 144 | 112,752 | -11051962176191080095/1298074214633706907132624082305024 |
| 6 | 192 | 155,520 | 1417258427640987305745/649037107316853453566312041152512 |
| 7 | 80 | 225,504 | 706946219039124820413/1298074214633706907132624082305024 |
| 8 | 160 | 225,504 | 706946219039124820413/1298074214633706907132624082305024 |

All nine independent terminal replays use exact Gaussian integer
products. The full seven-factor inputs for slices 4 and 5 use a support-only
semijoin on shared axes followed by plain sparse products. That schedule
does not apply proportional quotients and uses 8,352,280 products per
slice, with largest join 4,817,664. All nine imaginary values are zero.
The arithmetic applies factor denominator product
40512224221827380280140849737629696 and external normalization
1/(16*4^64) once. Exact Fraction addition gives the reported sum.

The review manifest uses relative paths and includes verified copies of
the author receipts. The frozen inputs inventory records every author
checkpoint needed to repeat the verification.
