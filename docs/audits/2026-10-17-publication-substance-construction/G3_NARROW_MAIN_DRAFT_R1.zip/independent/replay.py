import hashlib
import json
from pathlib import Path
from scripts.build_graph import extract_parameter_nodes, extract_readiness_gate_nodes
from src.core.provenance import PARAMETER_PROVENANCE, PAPER_DEPENDENCIES
fields = ('llm_verified_date', 'human_verified_date')
nodes = extract_parameter_nodes()
result = {
    'registry_sha256': hashlib.sha256(Path('src/core/provenance.py').read_bytes()).hexdigest(),
    'l1_dependency_registry': PAPER_DEPENDENCIES.get('L1'),
    'nodes': nodes,
    'source_dates': {key: {field: row.get(field) for field in fields} for key, row in PARAMETER_PROVENANCE.items()},
    'gates': extract_readiness_gate_nodes(),
}
print(json.dumps(result, indent=2, default=str))
