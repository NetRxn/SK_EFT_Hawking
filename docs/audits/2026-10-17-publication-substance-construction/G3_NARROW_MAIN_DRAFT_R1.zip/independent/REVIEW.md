# Independent exact-main G3 transfer review

Scoped verdict: accept the frozen two-file producer patch and regression test on the exact main parent. L1 on this parent remains measured open. Applying this patch does not import the draft PR117 L1 linkage or the PR117 seven-blocker result. Live main was left untouched and final human approval remains separate.

## Identity and controls

- Continuity packet `l1-g3-main-composition-independent-r1` was fresh, with no changes.
- Clean detached parent `ce194cdc4bf939b108c17edc9530a7f0a14565f9` in an independent private clone. Candidate SHA-256 `b0e8b5ffb01fb88debf217a22159fff2f93219119cad80d1d4771ea0b67e042c`, verified by byte-identical patch reproduction. Removing only the per-file Git index lines yields byte-identical complete patch text to accepted PR117, including every hunk and its context.
- Test-only baseline intentionally failed at the G3 blocker assertion, where `TEST.verified` appeared as an extra blocker. Exact producer addition made the same test pass. `git diff --check` passed. The `TestExtractParameterNodes` class plus readiness gate evaluator suite passed 44 tests.
- Measured controlled candidate then pristine parent in the same checkout with `PYTHONHASHSEED=0`, reversing both hunks between processes. The stat manifest for 1,272 files under `papers/` matched before and after. Reapplied the exact frozen patch after the pair.

## Main graph effects

- `extract_readiness_gate_nodes()` emitted 704 gate nodes on each side, with the same IDs and individual states. Ignoring only `last_evaluated`, exactly five G3 gate payloads changed. `paper12_polariton` moved from 10 to 3 blockers, `paper1_first_order` from 16 to 10, `paper2_second_order` from 16 to 10, `paper3_gauge_erasure` from 6 to 3, and `paper4_wkb_connection` from 16 to 10. Each remains blocked. The controlled replay isolates the metadata patch from checkout timestamp and hash-order noise.
- L1 has no `PAPER_DEPENDENCIES` entry on the main parent. Its G3 payload is identical after excluding the evaluation timestamp: measured open, zero parameter edges, zero verified through those edges, and six unit-bearing literals. The open result reflects unestablished linkage, with no inference about which literals are human verified.
- All 211 Parameter nodes retain their prior payload exactly after removing the two added fields. Every emitted date equals the unchanged source value. The registry records 211 LLM dates and 128 human dates. The provenance registry digest is `1e929d8e3e0c4603e14e4df3e8bfc1108a71fbf9ace459b9171809f17d20766d`. This transfer records no new attestations and establishes no publication readiness or live dashboard result.
