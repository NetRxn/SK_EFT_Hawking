from collections import Counter
from copy import deepcopy
from pathlib import Path
import json

scratch = Path(__file__).resolve().parent
baseline = json.loads((scratch / 'controlled-parent.json').read_text())
candidate = json.loads((scratch / 'controlled-candidate.json').read_text())
fields = ('llm_verified_date', 'human_verified_date')
assert baseline['registry_sha256'] == candidate['registry_sha256']
assert baseline['source_dates'] == candidate['source_dates']
assert baseline['l1_dependency_registry'] == candidate['l1_dependency_registry'] is None

def index(rows):
    result = {node['id']: node for node in rows}
    assert len(result) == len(rows)
    return result

old_nodes = index(baseline['nodes'])
new_nodes = index(candidate['nodes'])
assert old_nodes.keys() == new_nodes.keys()
for node_id, old_node in old_nodes.items():
    node = deepcopy(new_nodes[node_id])
    projected_dates = {field: node['meta'].pop(field) for field in fields}
    assert projected_dates == candidate['source_dates'][node_id.removeprefix('param:')]
    assert node == old_node

old_gates = index(baseline['gates'])
new_gates = index(candidate['gates'])
assert old_gates.keys() == new_gates.keys()
delta = []
for gate_id, old_gate in old_gates.items():
    new_gate = new_gates[gate_id]
    old_gate['meta'].pop('last_evaluated')
    new_gate['meta'].pop('last_evaluated')
    if old_gate != new_gate:
        old_meta = old_gate['meta']
        new_meta = new_gate['meta']
        delta.append({
            'id': gate_id,
            'before': {'state': old_meta['state'], 'blockers': old_meta['blockers_total'], 'evidence': old_meta['evidence']},
            'after': {'state': new_meta['state'], 'blockers': new_meta['blockers_total'], 'evidence': new_meta['evidence']},
        })
l1 = old_gates['gate:L1:ParameterProvenance']['meta']
assert old_gates['gate:L1:ParameterProvenance'] == new_gates['gate:L1:ParameterProvenance']
assert l1['state'] == 'open' and l1['measured']
assert l1['evidence'] == ['0 parameters depended on; 0 human-verified', '6 unit-bearing literals in the draft']
print(json.dumps({
    'gate_count': len(old_gates),
    'state_counts_before': Counter(node['meta']['state'] for node in old_gates.values()),
    'state_counts_after': Counter(node['meta']['state'] for node in new_gates.values()),
    'l1_g3': l1,
    'parameter_count': len(old_nodes),
    'dated_parameter_counts': {field: sum(bool(values[field]) for values in candidate['source_dates'].values()) for field in fields},
    'provenance_registry_sha256': candidate['registry_sha256'],
    'delta': delta,
}, indent=2))
