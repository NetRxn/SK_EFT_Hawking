# Main-based G3 qualification

Draft PR119 contains only the reviewed producer and regression test. Exact main parent ce194cdc4, candidate bf742341. Same-tree replay controls numerical freshness mtimes and blocker ordering. Five G3 detail sets improve with zero gate-state transitions. Main-based L1 remains measured open, with no links. On both sides the inventory census matches with the installed hook, but the existing END_TO_END_MAP reference is unresolved. Full publication and human merge approval remain open.
