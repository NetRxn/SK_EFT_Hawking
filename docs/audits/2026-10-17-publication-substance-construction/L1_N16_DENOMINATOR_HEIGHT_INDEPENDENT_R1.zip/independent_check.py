from fractions import Fraction
from itertools import product
from math import factorial, lcm
from pathlib import Path
import json
import sys

from src.core.formulas import original_action_factors, original_coframe_blocks, original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol, quaternion_key_moment

regulator = OriginalRegulator()
assert regulator.extents == (2, 2, 2, 2)
assert regulator.boundary_signs == (1, 1, 1, 1)
assert regulator.word == "closed"
assert len(regulator.link_order) == 64
assert len(regulator.generator_order) == 128

def coordinate(anchor, hand, axis):
    return Symbol("q", (*anchor, hand, axis))

links = {
    anchor: original_spin4_link(*[
        tuple(Polynomial.variable(coordinate(anchor, hand, axis)) for axis in range(4))
        for hand in ("L", "R")
    ])
    for anchor in regulator.link_order
}
site = regulator.sites[0]
factor_rows = original_action_factors(regulator, site, links)
factor_counts = {}
for degree in (2, 4):
    rows = [row for row in factor_rows if row.t_degree == degree]
    factor_counts[degree] = len(rows)
    for row in rows:
        assert len(row.components) == degree
        for key, value in row.coefficient.terms:
            assert len(key) == (4 if degree == 2 else 0)
            assert all(symbol.family == "q" for symbol in key)
            scaled = value * (4 if degree == 2 else 1)
            assert scaled.real.denominator == scaled.imag.denominator == 1
assert factor_counts == {2: 384, 4: 24}

for direction, axis in product(range(4), repeat=2):
    blocks = original_coframe_blocks(regulator, (site, direction, axis), links)
    assert len(blocks) == 4
    for block in blocks:
        assert abs(block.weight) == Fraction(1, 4)
        for row in block.matrix:
            for entry in row:
                for key, value in entry.terms:
                    assert len(key) == 1 and key[0].family == "q"
                    assert value.real.denominator == value.imag.denominator == 1

a, b = regulator.link_order[:2]
q_a0 = coordinate(a, "L", 0)
q_a1 = coordinate(a, "L", 1)
q_ar0 = coordinate(a, "R", 0)
q_b0 = coordinate(b, "L", 0)
controls = {
    "empty": ((), 1),
    "odd_same_chirality_two_axes": ((q_a0, q_a1), 0),
    "same_coordinate_fourth": ((q_a0,) * 4, Fraction(1, 8)),
    "same_group_distinct_squares": ((q_a0,) * 2 + (q_a1,) * 2, Fraction(1, 24)),
    "distinct_chirality_squares": ((q_a0,) * 2 + (q_ar0,) * 2, Fraction(1, 16)),
    "distinct_anchor_squares": ((q_a0,) * 2 + (q_b0,) * 2, Fraction(1, 16)),
}
for key, expected in controls.values():
    assert quaternion_key_moment(key) == expected

# Recompute using integer LCM across all half-degree partitions. This does
# not rely on prime generation, factorization, or the author's valuation DP.
factorial_lcm = [1]
for total in range(1, 97):
    factorial_lcm.append(lcm(*[
        factorial(k + 1) * factorial_lcm[total - k]
        for k in range(1, total + 1)
    ]))
assert all(y % x == 0 for x, y in zip(factorial_lcm, factorial_lcm[1:]))
old = factorial(32) * 4**96 * (2**96 * factorial(97))**128
new = factorial(32) * 4**96 * 2**96 * factorial_lcm[96]

def crt_measure(d):
    cutoff = d << 801
    count = 0
    modulus_floor = 1
    while modulus_floor <= cutoff:
        modulus_floor <<= 60
        count += 1
    return cutoff.bit_length(), count

author = json.loads(Path(sys.argv[1]).read_text())
expected = {
    "existing_common_denominator_bits": old.bit_length(),
    "new_common_denominator_bits": new.bit_length(),
    "existing_crt_primes_bound": crt_measure(old)[1],
    "new_common_crt_primes_bound": crt_measure(new)[1],
}
assert all(author[k] == v for k, v in expected.items())
independent = []
for m, row in enumerate(author["per_coefficient"]):
    n = 32 - 2*m
    k = 96 - 4*m
    d = factorial(m) * factorial(n) * 4**(4*m + 3*n) * 2**k * factorial_lcm[k]
    bits, count = crt_measure(d)
    assert new % d == old % d == 0
    assert row == {
        "S4_power": m, "S2_power": n, "half_quaternion_degree_bound": k,
        "denominator_bits": d.bit_length(), "good_primes_gt": k + 1,
        "modulus_target_bits": bits, "sufficient_number_primes_gt_2pow60": count,
    }
    independent.append(row)
assert len(independent) == 17
print(json.dumps({
    "summary": expected, "independent_per_coefficient": independent,
    "source_factors_one_site": factor_counts,
    "coframe_cases": 16,
    "actual_grouped_moment_controls": {name: str(value) for name, (_, value) in controls.items()},
}, indent=2))
