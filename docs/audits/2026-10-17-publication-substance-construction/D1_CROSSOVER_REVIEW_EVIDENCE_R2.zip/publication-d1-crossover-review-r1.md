# Independent D1 finding 1.1 review R1

**REVISE the D1 scientific composition. ACCEPT the D4 2.2 and D8 1.4 format-only changes.** The CLI crossover equation, floor, JSON serialization and charter are corrected. F still uses the bare Hawking temperature for the same dressed crossover. The generator compares frequencies normalized by different temperatures when it produces its cutoff Boolean.

The canonical first check for `publication-d1-crossover-review-r1.json` returned exit 0, `fresh=true`, `changed=[]`. MAIN is `661a5e355a722b8957a3a23b642b05e160eb6f1f`. Actual `git diff HEAD` and the frozen patch have the same SHA256 `a02c456a42332c2165527634825f30d78a196525705c1124429893d878a9061b`. I reviewed the whole six-path diff, notebook, original finding and existing manuscript claims. No repository, ledger, Lean or slot mutations were performed.

## Scientific finding

The original expected result is one crossover computed with `T_eff ln(1 + 1/delta_diss)` in the generator, D1 and the charter. `WKBConnection.decoherenceParam` is 2Γ_H/κ. `noiseFloor` halves that parameter once and `noise_floor_eq_delta_diss` proves Γ_H/κ by unfolding and ring. `SecondOrderSK.deltaDissFromTransport_eq` connects the ratio to the first-order transport expression. `hawkingOccupation` divides β² by the survival factor 1−δ_k. D1 derives the Planck factor at dressed temperature using that relation and the Bogoliubov ratio. Its crossover equation is algebra at zero environment temperature under the stated WKB/FDR assumptions. It is not a separate exact frequency root proved by the floor theorem. With frequency-dependent κ_eff(ω), the physical crossing remains implicit in T_eff(ω).

The actual default CLI and `--json` both exit 0 in R1. Every JSON row has the exact floor Γ_H/κ, serializable Boolean and compatibility alias `ln_arg == omega_cross_over_TH`. I independently inverted the Planck factor and recomputed all rows from the emitted platform parameters.

| Platform | Floor | ω×/T_eff | ω×/T_H at the leading-order horizon benchmark | ωmax/T_H |
| --- | ---: | ---: | ---: | ---: |
| Steinhauer | 2.3771629552423217e-5 | 10.6470414953 | 10.6476968770 | 115.0333634628 |
| Heidelberg, projected | 0.0015925053479215164 | 6.4440380510 | 6.4342623945 | 121.0663800787 |
| Trento | 1.4130121214479423e-5 | 11.1672159128 | 11.1681627640 | 109.5041607765 |

The fourth column uses the D1 leading-order relation T_eff/T_H = 1/(1+δ_disp+δ_diss) at the declared horizon benchmark. The three benchmark accessibilities remain true with common units. The present code at `scripts/gen_d1_hierarchy_table.py:144` instead directly compares the third and fifth columns. For instance, with the Heidelberg benchmark correction and a hypothetical cutoff between 6.4343 and 6.4440 in T_H units, it reports the wrong Boolean. An exact benchmark Boolean should compare in common T_H units and disclose the scope of the conversion. Preserve legacy numeric keys for compatibility and make their denominator explicit.

D1 already states the correct equation and all three rounded T_eff coefficients. The charter now names the projected Heidelberg benchmark and 6.44 T_eff. F `paper_draft.tex:667–678` still uses T_H in the heading, Planck exponent, crossover prefactor and 6.44 multiplier. The actual `f_hierarchy_claims` validator passes because it explicitly requires that T_H anchor and compares its coefficient against the evaluator's T_eff coefficient. Thus the pass does not establish unit alignment. The F prose and its enforcing anchor should move together to T_eff, with the Heidelberg result remaining a projection. The D1 manuscript and its accepted floor equation already align. The existing code comment's “exactly ln 2” is asymptotic. At finite δ the difference from ln(2/δ) is ln(2/(1+δ)).

I reran the full D1 hierarchy test file with the existing project environment, `UV_NO_CACHE=1` and disabled bytecode/cacheprovider. Result: 14 passed, including the proposed Verify target. I executed the actual Git HEAD generator from a temporary source copy against the same project imports. The baseline CLI exited 0 but displayed the stale ln(2/δ) narrative with the already-correct numeric 6.44, and baseline JSON exited 1 on NumPy Boolean serialization. Thus the new public-CLI test has meaningful negative behavior. It presently does not check F's denominator, dimensional cutoff consistency, or retention of the compatibility alias. These are appropriate added controls in the revision. The direct D1/F validators both passed on R1. The independent semantic review rejects the F validator's unit convention rather than treating that green output as scientific evidence.

## Prior closure and format conservation

D4 2.2's old and new full shell commands have identical decoded argv and both exit 0. D8 1.4's outer argv prefix is identical. Decoding each literal exec argument and parsing its Python AST produces identical complete ASTs, SHA256 `9c9d1b77c968ce10d416fdd9dc628b9c710230b3ebe7af47c48b681a490686c0` on the default AST dump. Both old and new commands independently exit 0 with the same pinned-source success message and no stderr. Replacing just the active Verify line reconstructs each complete postimage byte-for-byte. Historical prose and commands remain intact.

The entire supersession ledger equals its HEAD blob, SHA256 `c305d06826f6c2da92267a0aca181e5fee540b5279800e861ecf5dbfd6f84e24`. It retains D4 2.2 and D8 1.4 fixed at `c9840bb1d87b0de90b36ee4bb58f5d2943c987b1` with verified exit 0. D8 1.8 likewise remains fixed at `dec5feba32a580564e98af2c7dfa7dd590d5672d` with verified exit 0. The unchanged canonical `review_verify_is_one_command` check independently passed 274 declarations / zero malformed. The separate global `review_severity_declared` check was red for existing historical corpus defects, including D1's pre-existing `code` lane. It is not the Verify formatting check, and this review asserts no corpus-wide green.

Final canonical continuity check returned `fresh=true` and `changed=[]` on the same frozen candidate.
