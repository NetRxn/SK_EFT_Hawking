import math
from scripts import gen_d1_hierarchy_table as generator
from src.wkb.spectrum import PlatformParams

def test_cutoff_normalization(monkeypatch):
    platform = PlatformParams("near cutoff", D=0.4, gamma_dim=1 / math.expm1(11.4))
    monkeypatch.setattr(generator, "PLATFORM_FACTORIES", {"Heidelberg": lambda: platform})
    row = generator.compute_bec_hierarchy()["Heidelberg"]
    assert row["omega_cross_over_TH"] < row["omega_max_over_TH"]
    assert not row["cross_below_cutoff"]
