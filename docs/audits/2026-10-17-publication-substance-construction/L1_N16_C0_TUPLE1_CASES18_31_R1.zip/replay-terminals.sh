#!/bin/sh
set -eu
for index in "$@"; do
    mkdir -p "replays/$index"
    case "$index" in
      18|20|26|28) frontier=label-primary-reduced-frontier.pkl; receipt=contract.out ;;
      *) frontier=label-rescue-reduced-frontier.pkl; receipt=rescue-contract.out ;;
    esac
    /usr/bin/time -p python3 -u replay.py "$index" 0 "inputs/$index/$frontier" "inputs/$index/$receipt" > "replays/$index/replay.out" 2> "replays/$index/replay.time"
done
