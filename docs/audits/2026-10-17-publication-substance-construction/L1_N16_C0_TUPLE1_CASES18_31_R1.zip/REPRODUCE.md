# Shared tuple 1 child cases 18–31

Restore separator.zip and child-equality.zip from the Git blobs pinned in
SOURCE_PINS.txt. Run sh rehydrate.sh in fresh scratch to regenerate the
124 pinned author inputs. Use trusted original inputs for deserialization.
Cases 18, 20, 26 and 28 close on their primary reductions. The other ten
retain an exact cap checkpoint and a rescue reduction. Follow REVIEW.md
for the independent lineage and terminal replays.

Verify preceding-eighteen.tsv against eighteen-term-retally.tsv from
L1_N16_C0_TUPLE1_CASES12_17_R1.zip. Run python3 retally-thirty-two.py for
the exact 32-term partial sum. Doubling applies after all terms close.
