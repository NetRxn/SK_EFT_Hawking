from fractions import Fraction
from pathlib import Path
import re

cases={}
for line in Path('preceding-eighteen.tsv').read_text().splitlines():
    fields=line.split('\t')
    if fields[0].isdigit():
        index,x,y=fields
        assert int(index) not in cases
        cases[int(index)]=(Fraction(x),Fraction(y))
assert set(cases)==set(range(18))
for index,x,y in re.findall(r'^PASS case (\d+) exact normalized (\S+) (\S+)',Path('aggregate.out').read_text(),re.M):
    assert int(index) not in cases
    cases[int(index)]=(Fraction(x),Fraction(y))
assert set(cases)==set(range(32))
for index,(x,y) in sorted(cases.items()):
    print(index,x,y,sep='\t')
print('PARTIAL SUM',len(cases),*map(sum,zip(*cases.values())),sep='\t')
