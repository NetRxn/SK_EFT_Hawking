# Dense tuple 1 shared-child cases 18–31 independent exact review

The 14 independent terminal results give exact subtotal **-1728214796344225896119025 / 5192296858534827628530496329220096 + 0i**.

| Case | Coordinate | Exact normalized real |
| --- | --- | --- |
| 18 | (34, (1,)) | -362373187640062814742087/10384593717069655257060992658440192 |
| 19 | (34, (2,)) | -526370532351546247637679/10384593717069655257060992658440192 |
| 20 | (36, (1,)) | -362373187640062814742087/10384593717069655257060992658440192 |
| 21 | (36, (2,)) | -526370532351546247637679/10384593717069655257060992658440192 |
| 22 | (40, (1,)) | 507195665631231180615/5192296858534827628530496329220096 |
| 23 | (40, (2,)) | -252268847562163273983/2596148429267413814265248164610048 |
| 24 | (65, (1,)) | 46797507983538349965/5192296858534827628530496329220096 |
| 25 | (65, (2,)) | -281263177739822351499/1298074214633706907132624082305024 |
| 26 | (66, (1,)) | -171712776706569354243141/5192296858534827628530496329220096 |
| 27 | (66, (2,)) | -123472917626008381943391/2596148429267413814265248164610048 |
| 28 | (68, (1,)) | -171712776706569354243141/5192296858534827628530496329220096 |
| 29 | (68, (2,)) | -123472917626008381943391/2596148429267413814265248164610048 |
| 30 | (72, (1,)) | 46797507983538349965/5192296858534827628530496329220096 |
| 31 | (72, (2,)) | -281263177739822351499/1298074214633706907132624082305024 |

All 14 imaginary parts are exactly zero. The cut input and terminal input hashes are distinct across the full batch, including equal scalar pairs.

At checkpoint d10807a717f151e578dd0553f49a4aa3dce5d5ec, the original separator archive pins the six-factor tuple1-0b input to uncompressed SHA256 843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077. Independent matching on parent pair (0, 1) recovers the common 36 supported coordinates on G(0,0,2) and J(1,4,2), with 6,838,272 compatible products in total and 213,696 for each reviewed case. The inverse lifts reproduce all restricted source factor rows, signed Gaussian pairs and factor denominators.

The two lineage groups independently reconstruct the primary reductions for each case. Cases 18, 20, 26 and 28 close directly in the author route, and the independent arithmetic uses the regenerated primary reduced input and a separate terminal schedule. Independent reconstruction also matches the first two author join counts and output row counts for those four terms. For the other ten cases the verifier reconstructs both completed preliminary joins, the exact saved refusal tables and each rescued terminal table before the separate replay. Preliminary completed products are 1,807,956 for 19, 21, 27 and 29, and 3,087,396 for 22–25 and 30–31. Refused forecasts are 4,228,224 for 19, 21, 27 and 29, 5,277,312 for 22, 24 and 30, and 4,192,512 for 23, 25 and 31. The two lineage groups took 77.07 and 76.83 seconds.

The separate terminal implementation uses ordinary sparse Gaussian-integer joins without author quotient or peer projection passes. Every replay preserves the exact raw signed scalar and applies the factor denominator and the verified positive external scale 1/(16*4^64) once. Direct replays use 8,134,004 products each and peak at 217,728 output rows. The rescue replays use 543,240 to 769,824 products per case. The exact sum counts all 14 independent identities.

The committed child equality binds both coarse siblings to this shared 36-case contraction in dense group 128 descendant (0, 0). This review covers the 14 named terms.

Keep the relative inputs/ and replays/ directories with the evidence. Restore separator.zip and child-equality.zip from the Git objects in SOURCE_PINS.txt. Use the following commands from the evidence root.

```sh
shasum -a 256 -c frozen-inputs.sha256
python3 verify-lineage.py 18 19 20 21 22 23 24 > verify-lineage-18-24.out
python3 verify-lineage.py 25 26 27 28 29 30 31 > verify-lineage-25-31.out
cat verify-lineage-18-24.out verify-lineage-25-31.out > verify-lineage.out
sh replay-terminals.sh 18 19 20 21 22 23 24 25 26 27 28 29 30 31
python3 verify-aggregate.py
```
