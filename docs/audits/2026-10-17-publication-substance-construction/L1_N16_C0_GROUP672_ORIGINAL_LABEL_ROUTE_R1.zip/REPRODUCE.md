# L1 group 672 exact label partition and measured residuals

Group 672 is a near-median input-size case in the original dense profile. This package establishes the complete eight-assignment partition on the original label axes and records exact selected branches and bounded contractions. It does not supply a group scalar.

Use the independently reviewed group 672 preparation in L1_N16_C0_COMPLEMENTARY_CASES30_33_R1.zip and its compiled source witnesses to recreate the corrected 88-factor operand. Check the recorded SHA256 before using it. Independent scripts also check the first 26-factor cap and the earlier W/G/G cap from L1_N16_C0_COMPLEMENTARY_CASE34_R1.zip. Restore scratch paths as indicated in individual scripts and refer to the original copies for exact hashes.

From a fresh author scratch directory, run condition.py with the corrected starting operand and expected source SHA256. The resulting label roster and selected case 7 factor tables match the independent construction. Run contract-slice.py through run.py to enforce the fixed 120-second subprocess guard. The exact chosen case reaches a retained 26-factor cap.

From fresh directories, use partition.py with that cap and each of the values 1, 2 and 3. Then run the same contraction prescription. These disjoint conditioning values exhaust case 7's stated J index. Every result still has work left. For case 0, the alternate copy of condition.py selects the least input-heavy complete label assignment before using the same guard. Its distinct cap is also retained.

The author recorded an input hash before branching. The pickle outputs are reproducible from the source and scripts, with the exact file hashes in operands.sha256. Replays can have different timing. A cap preserves a signed boundary factor state without deciding its scalar value or total cost. The staged reports distinguish independent byte replay, independently reconstructed input rows and author-only timing where applicable.
