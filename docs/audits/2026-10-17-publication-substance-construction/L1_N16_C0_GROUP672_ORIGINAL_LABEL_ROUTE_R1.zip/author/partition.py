from collections import Counter
from hashlib import file_digest
from pathlib import Path
import pickle
import sys

parent=Path(sys.argv[1])
label=(int(sys.argv[2]),)
with parent.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='996529b93e868f0a7114efcbd0a9235edd8ef4b76c4dcf64d5a26dced5b132c3'
    stream.seek(0)
    state=pickle.load(stream)
factors=state['factors']
i,j=state['rejected_pair']
assert (i,j)==(7,17) and len(factors)==26
axis=('J',1,1,2)
incidence=tuple(n for n,(a,_,_) in enumerate(factors) if axis in a)
assert len(incidence)==2 and set(incidence).intersection((i,j))
left,right=(factors[i],factors[j]) if axis in factors[i][0] else (factors[j],factors[i])
shared=tuple(w for w in left[0] if w in right[0])
ap=tuple(left[0].index(w) for w in shared)
bp=tuple(right[0].index(w) for w in shared)
index=Counter(tuple(row[k] for k in bp) for row in right[1])
col=left[0].index(axis)
roster=Counter()
for row in left[1]:
    n=index[tuple(row[k] for k in ap)]
    if n:
        roster[row[col]]+=n
assert roster=={(1,):249536,(2,):242496,(3,):242496}
assert sum(roster.values())==state['matched']==734528
for n in incidence:
    scope,table,den=factors[n]
    column=scope.index(axis)
    selected={row[:column]+row[column+1:]:z for row,z in table.items() if row[column]==label}
    assert len(selected)==sum(row[column]==label for row in table) and selected
    factors[n]=scope[:column]+scope[column+1:],selected,den
with Path('dense-saturated-frontier.pkl').open('xb') as out:
    pickle.dump(dict(factors=factors,used_before=state['used_before'],
                     physical_cut=(state['physical_cut'],(axis,label))),out,protocol=5)
print(axis,sorted(roster.items()),label,roster[label],sum(len(r) for _,r,_ in factors),flush=True)
