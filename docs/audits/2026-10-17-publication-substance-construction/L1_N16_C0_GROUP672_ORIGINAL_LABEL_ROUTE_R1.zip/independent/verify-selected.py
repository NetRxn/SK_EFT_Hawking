"""Independent exact support, inverse lift and next-cut census for assignment 7."""
from ast import literal_eval
from collections import Counter,defaultdict
from hashlib import sha256
from math import prod
from pathlib import Path
from runpy import run_path
from time import perf_counter

helpers=run_path('label-support.py')
root=helpers['ROOT']
read=helpers['read']
parent=root/'corrected/dense-saturated-frontier.pkl'
author=Path('/private/tmp/l1-group672-original-label.dAv5G8')
start=perf_counter()
axes,roster,peak=helpers['from_compiled']()
parent_hash,source=read(parent)
assert parent_hash=='cceeb82ab1491de4ed0de3935d49e2fdb0449e50e6597c0d43c4600f4fe96224'
declared=(author/'joint-label-roster.tsv').read_text().splitlines()
assert literal_eval(declared[0].split('\t')[1])==axes
projected=tuple((tuple((scope.index(w),axes.index(w)) for w in scope if w in axes),
    Counter(tuple(row[p] for p,w in enumerate(scope) if w in axes) for row in rows))
    for scope,rows,_ in source['factors'])
sizes=[]
for n,labels in enumerate(roster):
    local=[counts[tuple(labels[p] for _,p in column)] for column,counts in projected]
    sizes.append(sum(local))
    fields=declared[n+1].split('\t')
    assert len(fields)==4 and (int(fields[0]),literal_eval(fields[1]),int(fields[2]),int(fields[3]))==(n,labels,sum(local),max(local))
    assert all(local)
assert len(declared)==9 and len(source['factors'])==88
index=max(range(len(sizes)),key=lambda n:(sizes[n],n))
assert index==7 and sizes[index]==276336
selected_hash,selected=read(author/'dense-saturated-frontier.pkl')
assert selected_hash=='0d1a57b31aa5b9f6b7b7169d1aa03c2a5a894e4e6ab8ad9a0e06768703e8cf51'
assert selected['group']==672 and selected['used_before']==0
assert selected['physical_cut']==(axes,roster[index])
assert selected['joint_label_index']==index and selected['complete_label_roster']==roster
fixed=dict(zip(axes,roster[index],strict=True))
for n,((a,A,d),(b,B,e)) in enumerate(zip(source['factors'],selected['factors'],strict=True)):
    assert b==tuple(w for w in a if w not in fixed) and d==e
    recovered={}
    for row,z in B.items():
        values=dict(zip(b,row,strict=True))|fixed
        recovered[tuple(values[w] for w in a)]=z
    assert len(recovered)==len(B)
    constraints=[(i,fixed[w]) for i,w in enumerate(a) if w in fixed]
    exact={row:z for row,z in A.items() if all(row[i]==v for i,v in constraints)}
    assert recovered==exact,(n,len(recovered),len(exact))
    print('factor',n,'original scope',len(a),'kept',len(b),'selected rows',len(B),'denominator',d)
print('PASS original exact roster, independently lifted all 276336 selected signed rows and denominators')
cap_hash,cap=read(author/'row-cap-physical-slice-dense-branch.pkl')
assert cap_hash=='996529b93e868f0a7114efcbd0a9235edd8ef4b76c4dcf64d5a26dced5b132c3'
assert cap['physical_cut']==selected['physical_cut']
denominator=576173855599322741762003196268511232
assert prod(d for _,_,d in source['factors'])==prod(d for _,_,d in selected['factors'])==prod(d for _,_,d in cap['factors'])==denominator
assert len(cap['factors'])==26
assert set(Counter(w for a,_,_ in cap['factors'] for w in a).values())=={2}
print('cap pin',cap_hash,'rows',sum(len(r) for _,r,_ in cap['factors']),'denominator',denominator,'prior matched works',cap['used_before'])
i,j=cap['rejected_pair']
(a,A,_),(b,B,_)=cap['factors'][i],cap['factors'][j]
shared=tuple(w for w in a if w in b)
ix,iy=[tuple(s.index(w) for w in shared) for s in (a,b)]
histX=Counter(tuple(row[p] for p in ix) for row in A)
histY=Counter(tuple(row[p] for p in iy) for row in B)
work={row:histX[row]*histY[row] for row in histX.keys()&histY.keys()}
assert sum(work.values())==cap['matched']==734528
print('refused join',i,j,'left and right rows',len(A),len(B),'common atoms',len(work),'physical axes',shared)
choices=[]
for k,wire in enumerate(shared):
    tally=Counter()
    for row,n in work.items():
        tally[row[k]]+=n
    if len(tally)>1:
        choices.append((max(tally.values()),len(tally),wire,sorted(tally.items())))
for peak,c,w,cells in sorted(choices):
    print('cut',w,'supported',c,'peak',peak,'exact disposed roster',cells)
assert choices
pick=min(choices)
assert pick[0]<=500000 and sum(n for _,n in pick[-1])==734528
print('PASS complete proposed secondary split of refused join',pick)
print('independent scope-only audit seconds',f'{perf_counter()-start:.6f}')
_,_,wire,cells=pick
cost_classes=defaultdict(list)
for coordinate,weight in cells:
    cost_classes[weight].append(coordinate)
partitions=[[] for _ in range(2)]
for weight,coordinates in sorted(cost_classes.items()):
    assert len(coordinates)%2==0
    for i,coordinate in enumerate(sorted(coordinates)):
        partitions[i%2].append((coordinate,weight))
assert not ({c for c,_ in partitions[0]}&{c for c,_ in partitions[1]})
assert sorted(partitions[0]+partitions[1])==cells
wire_degree=sum(wire in scope for scope,_,_ in cap['factors'])
assert wire_degree==2 and wire in a and wire in b
for k,group in enumerate(partitions):
    allowed=tuple(sorted(c for c,_ in group))
    subsets=tuple(sum(row[scope.index(wire)] in allowed for row in entries) for scope,entries in ((a,A),(b,B)))
    work=sum(cost for _,cost in group)
    assert work==367264
    print('candidate child',k,'wire',wire,'allowed',allowed,'kept pair rows',subsets,
          'first explicit join projected products',work,'absolute upper bound on first output rows',work)
print('G unpairable marginal values', sorted(({row[a.index(wire)] for row in A}|{row[b.index(wire)] for row in B})-{c for c,_ in cells}))
