from collections import Counter
from hashlib import file_digest
from itertools import combinations, product
from math import factorial,prod
from pathlib import Path
from pickle import load
from runpy import run_path
from time import perf_counter

helper=run_path('label-support.py')
L,T,_=helper['from_compiled']()
target=helper['ROOT']/'corrected/dense-saturated-frontier.pkl'
with target.open('rb') as f:
    assert file_digest(f,'sha256').hexdigest()=='cceeb82ab1491de4ed0de3935d49e2fdb0449e50e6597c0d43c4600f4fe96224'
    f.seek(0)
    obj=load(f)
start=perf_counter()

def conditioned(i):
    fixed=dict(zip(L,T[i],strict=True))
    terms=[]
    for axes,rows,d in obj['factors']:
        cond=[(p,fixed[w]) for p,w in enumerate(axes) if w in fixed]
        keep=[p for p,w in enumerate(axes) if w not in fixed]
        small={}
        for row,z in rows.items():
            if all(row[k]==v for k,v in cond):
                reduced=tuple(row[k] for k in keep)
                assert reduced not in small
                small[reduced]=z
        terms.append((tuple(axes[k] for k in keep),small,d))
    assert len(terms)==88
    assert set(Counter(w for a,_,_ in terms for w in a).values())=={2}
    assert prod(d for _,_,d in terms)==576173855599322741762003196268511232
    return terms

def projections(axes,shared):
    return tuple(axes.index(w) for w in shared)
def project(key,positions):
    return tuple(key[i] for i in positions)
factors=conditioned(0)
assert sum(len(r) for _,r,_ in factors)==78966
scopes=[a for a,_,_ in factors]
tables=[r for _,r,_ in factors]
pairs=[]
for i,j in combinations(range(88),2):
    common=tuple(w for w in scopes[i] if w in scopes[j])
    if common:
        pairs.append((i,j,projections(scopes[i],common),projections(scopes[j],common)))
rounds=0
while True:
    removed=0
    for i,j,pa,pb in pairs:
        a={project(row,pa) for row in tables[i]}
        b={project(row,pb) for row in tables[j]}
        hits=a&b
        for idx,positions,domain in ((i,pa,a),(j,pb,b)):
            if domain!=hits:
                old=len(tables[idx])
                tables[idx]={row:z for row,z in tables[idx].items() if project(row,positions) in hits}
                removed+=old-len(tables[idx])
    rounds+=1
    after=sum(map(len,tables))
    print('exact support pruning round',rounds,'removed',removed,'stored rows',after,flush=True)
    if not removed:
        break
    assert rounds<=20
assert all(tables)
scores=[]
for i,j,p,q in pairs:
    A=Counter(project(k,p) for k in tables[i])
    B=Counter(project(k,q) for k in tables[j])
    traffic=sum(A[v]*B[v] for v in A.keys()&B.keys())
    boundary=len(set(scopes[i])^set(scopes[j]))
    scores.append((traffic,boundary,i,j))
print('initial candidates',len(scores),'smallest products',sorted(scores)[:10])
print('smallest width within 500k projected products',sorted((w,n,i,j) for n,w,i,j in scores if n<=500000)[:10])
print('lightest combined forecast',min((n*(w+1)**2,n,w,i,j) for n,w,i,j in scores))

rows=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occ=[[rows[(data>>(6*x))&63] for x in range(8)] for data in (503841882182,1461451755920)]
edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not (u>>k)&1]
total=sum(n for m in occ for row in m for n in row)
mult=prod(factorial(n) for m in occ for row in m for n in row)
world=sum((3+k)*n for m in occ for row in m for k,n in enumerate(row))
cross=0
for m in occ:
    weighted=[(u,v,sum(m[u])-m[u][k]+sum(m[v])-m[v][k]) for u,v,k in edges]
    cross+=sum(a[2]*b[2]*(u>v) for i,a in enumerate(weighted) for b in weighted[i+1:] for u in a[:2] for v in b[:2])
assert (total,mult,(-1)**((world+cross)%2))==(32,16,1)
print('normalization total/factorial/world/cross/sign',total,mult,world,cross,(-1)**((world+cross)%2))
print('wall seconds',f'{perf_counter()-start:.6f}')
