from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
from time import perf_counter

from runpy import run_path
helper=run_path("label-support.py")
from_compiled,join_all,read,symbols,ROOT=(helper[n] for n in ("from_compiled","join_all","read","symbols","ROOT"))

def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def profiled(obj,labels,assignments):
    rows=[(tuple(w for w in a if w in labels),
          Counter(tuple(row[i] for i,w in enumerate(a) if w in labels) for row in r))
          for a,r,d in obj['factors']]
    for n,L in enumerate(assignments):
        fixed=dict(zip(labels,L,strict=True))
        local=[counts[tuple(fixed[w] for w in a)] for a,counts in rows]
        assert len(local)==len(obj['factors'])
        print('assignment',n,'total rows',sum(local),'max factor rows',max(local),
              'empty factors',tuple(i for i,n in enumerate(local) if not n))
def profiles(obj,labels,assignments):
    i,j=obj['rejected_pair']
    (a,A,_),(b,B,_)=obj['factors'][i],obj['factors'][j]
    shared=tuple(w for w in a if w in b)
    ws=(('W',1,3,0),('G',1,3,0))
    assert set(ws)<=set(shared)
    fixed=tuple(w for w in labels if w in a or w in b)
    seen={}
    for u,T in enumerate(assignments):
        v=dict(zip(labels,T,strict=True))
        seen.setdefault(tuple(v[w] for w in fixed),[]).append(u)
    ai=tuple(a.index(w) for w in shared)
    bi=tuple(b.index(w) for w in shared)
    wpos=tuple(shared.index(w) for w in ws)
    def hist(A,indices,check):
        return Counter(tuple(row[i] for i in indices) for row in A
                       if all(row[p]==v for p,v in check))
    def traffic(coords):
        allowed=dict(zip(fixed,coords,strict=True)) if coords is not None else {}
        ca=tuple((a.index(w),v) for w,v in allowed.items() if w in a)
        cb=tuple((b.index(w),v) for w,v in allowed.items() if w in b)
        X,Y=hist(A,ai,ca),hist(B,bi,cb)
        out=Counter()
        for values in X.keys()&Y.keys():
            out[tuple(values[i] for i in wpos)]+=X[values]*Y[values]
        return out
    old=traffic(None)
    assert (len(old),sum(old.values()))==(260,3563808)
    covered=Counter()
    for k,group in seen.items():
        rows=traffic(k)
        covered.update(rows)
        print('source-label group',group,'pair-visible L tuple',k,'joint W/G labels',len(rows),
              'selected products',sum(rows.values()),'maximum',max(rows.values(),default=0))
    assert set(covered)<=set(old)
    assert all(n <= old[k] for k,n in covered.items())
    print('exact union covers W/G cases',len(covered),'out of',len(old),'compatible local pair products',
          sum(covered.values()),'out of',sum(old.values()),'uncovered labels',sorted(set(old)-set(covered)))
    print('candidate whole-group schedule combined disjoint original joint L labels before W/G')
    return old,covered

if __name__=='__main__':
    start=perf_counter()
    labels,values,peak=from_compiled()
    print('original compiled label support',len(values),labels,values,flush=True)
    for name in ('corrected/dense-saturated-frontier.pkl','row-cap-physical-slice-dense-branch.pkl'):
        h,obj=read(ROOT/name)
        s,cases,peak=join_all(symbols(obj))
        print('input',name,'SHA256',h,len(obj['factors']),'factor denominator',prod(d for _,_,d in obj['factors']))
        assert s==labels and cases==values
        print('PASS complete same exact eight-label support',peak)
        profiled(obj,labels,values)
        if 'rejected_pair' in obj:
            old,covered=profiles(obj,labels,values)
        del obj
    print('wall seconds',f'{perf_counter()-start:.6f}')
