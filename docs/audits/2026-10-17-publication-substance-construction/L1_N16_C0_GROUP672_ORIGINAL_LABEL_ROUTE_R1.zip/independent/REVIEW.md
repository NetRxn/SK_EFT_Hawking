# Group 672 exact route and bounded scalar attempts

**The whole-group signed scalar remains open.** The eight complete joint L assignments form an exact decomposition of group 672 and cover all 260 original W/G branches. The audited label and local-join counts certify coverage. The measured contraction attempts end at saved row caps.

## Complete original label partition

The original group 672 block index and schema give 88 local label relations. Independent natural joins of their projections yield exactly eight assignments across the twelve remaining L wires. The corrected 88-factor quotient parent and original 26-factor cap independently recover the same eight assignments. The projected labels of the first refused pair give four disjoint tuple classes, with 190,656, 56,736, 1,456,480 and 1,859,936 local pair products. Their W/G union includes every one of the 260 original coordinate pairs and all 3,563,808 products. The two labels in each class agree on the refused pair’s visible L wires. Their counts enter this support census once per visible label class. The full scalar decomposition uses each of the eight distinct complete L assignments once.

Every full matching configuration has exactly one complete L assignment. Restricting that value at every incident factor before contraction preserves the signs, exact sums and denominators. The preparer’s exact quotient keeps L as a boundary, permitting restriction of the corrected quotient parent separately on each label. Factor denominator product on the selected lineage is `576173855599322741762003196268511232`. Independent occupation normalization gives world and crossing exponents 136 and 444 and sign +1, with 32 insertions and factorial product 16. Divide the signed Gaussian sum by the factor denominator and apply `1/(16*4^64)` once.

The checkpoint for the older worst physical descent is SHA-256 `f990e6d70fa7e6c3fa3e8e8c00892ece3fd6f8cf17a953563421439f583db157`. It retains 22 factors, 1,457,816 rows and only four of the eight global L cases. Assignments 0–3 give empty factors on that physical path. A complete G(0,3,0) cut has 28 values there, and after global L conditioning each corresponding foreground join has at most 121,408 products. The 22-factor restart and its four surviving labels cover only their existing W/G path.

## Verified selected attempts

Assignment 7 began with 276,336 signed rows on all 88 conditioned factors. The independent inverse lift recovered every original coefficient. The archived contractor replay reproduced both logs and the 26-factor saved cap byte for byte, at 734,528 refused products, 665,812 stored rows and 1,196,020 completed products. The author took 9.242602 seconds. The reviewer took 9.126901 seconds with peak child RSS 546,095,104 bytes. Cap SHA-256 `996529b93e868f0a7114efcbd0a9235edd8ef4b76c4dcf64d5a26dced5b132c3`.

Assignment 0 began with 78,966 rows, all independently lifted. The checked author run completed 73 joins and 2,857,046 products before a status-2 cap with 15 factors, 1,095,136 stored rows and 2,458,624 projected products. Elapsed time was 24.758571 seconds. Cap SHA-256 `ab5ba8022e5d15d46b091fee50d35090c7c90b972463ef1ef23af9824b8972d2`. The refused join has eight full shared tuples at 307,328 products each. This provides an exact admissible first join in each of eight local continuations if that route is selected. The assignment 0 contraction was audited from saved states, source equality and work counters.

## Checked J partition of assignment 7

J(1,1,2) has exactly the common values (1,), (2,) and (3,) in incident factors 7 and 15. Restricting both is an exhaustive disjoint partition. Independent histogram recovers foreground forecasts 249,536, 242,496 and 242,496. All child input rows and coefficients pass exact inverse lift. The measured author runs each completed eight joins and then saved a distinct 18-factor status-2 cap, each at 1,191,936 projected products.

| J value | Initial rows | Completed products | Author wall seconds |
|---|---:|---:|---:|
| (1,) | 643,684 | 4,788,816 | 36.578529 |
| (2,) | 641,628 | 4,781,776 | 35.145128 |
| (3,) | 641,628 | 4,781,776 | 35.396090 |

The measured J caps were audited by direct input inverse lift, cap hash and metadata, and independent rejected-pair forecasts. Each run’s completed-product sum covers its eight joins. The three cap factors have distinct source paths and hashes. Their matching forecasts provide a common partition design.

## Next decisive experiment

Test the complete J=(1,) continuation in three disjoint G(0,6,0) blocks. These exact subsets exhaust all 16 compatible values of the residual pair (2,6). Restrict both incident factors to the block and keep the G wire until forcing that pair’s first ordinary exact join.

| G block | Exact first-join products and upper bound on output rows |
|---|---:|
| 81, 88, 193, 200 | 443,520 |
| 7, 13, 49, 52, 82, 194 | 374,208 |
| 11, 14, 50, 56, 84, 196 | 374,208 |

The same verified first-join bounds apply to the two other J residuals. Each bound is below 500,000, since every unique output row requires an input pair. Subsequent joins need fresh support forecasts and an output-row stop. Use exact signed Gaussian arithmetic, unique child keys and per-run checkpoints. Continue by support pruning, exact quotient and admissible joins. At a later cap, split using disjoint subsets of a degree-two shared tuple. If a single tuple is too heavy, partition one factor’s compatible rows into disjoint bounded ranges, using linearity to sum the resulting scalars. Count each terminal value or exact-zero proof once before collapsing its parent.

An initial experiment can use the historical 8-million projected products per join, 40-million completed products and 500,000 retained rows, with one isolated process, a 120-second timeout, and a measured RSS guard. Reserve a single-process limit around 2 GiB on the pilot host and stop with the last verified checkpoint if reached. The existing measured RSS applies to the assignment 7 parent replay. It does not establish a memory forecast for a residual scalar. Record elapsed time, peak RSS, row counts, products, refusals and signed results. Completing all three blocks would close precisely J=(1,). Assignment 7 additionally requires the other two J children. Group 672 additionally requires the other seven original label terms. A resource estimate for group 672 requires observed results beyond the current refusals.

The first G(1,1,0) cap also admits two balanced blocks of 367,264 products each, recorded in `verify-selected.out`. The two-block comparison applies at assignment 7’s first cap and remains untested.
