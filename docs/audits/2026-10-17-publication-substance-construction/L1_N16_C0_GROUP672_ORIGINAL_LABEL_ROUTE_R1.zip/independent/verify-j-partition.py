from collections import Counter,defaultdict
from hashlib import file_digest
from math import prod
from pathlib import Path
from pickle import load
from sys import argv
from time import perf_counter
import re

BASE=Path('/private/tmp/l1-group672-original-label.dAv5G8')
DEN=576173855599322741762003196268511232
AXIS=('J',1,1,2)
CAP='996529b93e868f0a7114efcbd0a9235edd8ef4b76c4dcf64d5a26dced5b132c3'
def read(name):
    with name.open('rb') as f:
        digest=file_digest(f,'sha256').hexdigest()
        f.seek(0)
        data=load(f)
    assert prod(d for _,_,d in data['factors'])==DEN
    degree=Counter(w for a,_,_ in data['factors'] for w in a)
    assert all(n==2 and w[0]!='L' for w,n in degree.items())
    return digest,data
def matched(data):
    i,j=data['rejected_pair']
    (a,A,_),(b,B,_)=data['factors'][i],data['factors'][j]
    labels=tuple(w for w in a if w in b)
    positions=tuple(tuple(scope.index(w) for w in labels) for scope in (a,b))
    left,right=(Counter(tuple(row[p] for p in pos) for row in table)
                for pos,table in zip(positions,(A,B),strict=True))
    weights={x:left[x]*right[x] for x in left.keys()&right.keys()}
    assert sum(weights.values())==data['matched']
    return i,j,(a,A),(b,B),labels,positions,weights
def residual_cap(number,origin):
    here=BASE/f'j{number}'
    receipt=(here/'contraction.receipt').read_text()
    details=(here/'contraction.out').read_text().splitlines()
    status=re.fullmatch(r'child status (\d+)\nelapsed seconds (\S+)\n',receipt)
    assert status is not None
    exitcode,elapsed=int(status[1]),float(status[2])
    assert exitcode==2
    assert (here/'contraction.err').read_bytes()==b''
    pin,state=read(here/'row-cap-physical-slice-dense-branch.pkl')
    assert state['physical_cut']==origin['physical_cut']
    log=re.fullmatch(r'open row cap (\d+) (\d+) frontier saved',details[-1])
    assert log is not None
    assert tuple(map(int,log.groups()))==(len(state['factors']),state['matched'])
    works=[int(re.match(r'join \d+ (\d+) \d+ axes \d+',r)[1]) for r in details if r.startswith('join ')]
    assert len(works)==len(origin['factors'])-len(state['factors'])
    assert sum(works)==state['used_before']
    print('measured author J child',number,'status',exitcode,'seconds',elapsed,'retained factors',len(state['factors']),
          'cap projected products',state['matched'],'completed products in this run',sum(works),'SHA256',pin)
    a,b,_,_,axes,_,weights=matched(state)
    choices=[]
    for k,axis in enumerate(axes):
        sizes=Counter()
        for row,n in weights.items(): sizes[row[k]]+=n
        if len(sizes)>1:
            peak=max(sizes.values())
            choices.append((peak,len(sizes),axis,sorted(sizes.items())))
    print('independent residual forecast',number,(a,b),state['matched'],'candidate shared axes',sorted(choices)[:3])
    if choices:
        eligible=[(n,peak,wire,entries) for peak,n,wire,entries in choices if peak<=500000]
        if eligible:
            print('smallest single-axis residue split',number,min(eligible))
    candidate=next(items for peak,count,wire,items in choices if wire==('G',0,6,0))
    blocks=[[],[],[]]
    totals=[0,0,0]
    for value,n in sorted(candidate,key=lambda pair:(-pair[1],pair[0])):
        where=min(range(3),key=lambda j:(totals[j],j))
        blocks[where].append(value)
        totals[where]+=n
    assert sorted(value for block in blocks for value in block)==sorted(value for value,_ in candidate)
    assert totals==[443520,374208,374208]
    for idx,(values,work) in enumerate(zip(blocks,totals,strict=True)):
        print('proposed residual G block',number,idx,tuple(sorted(values)),
              'first join product and maximum output rows',work)
    return pin,state

if __name__=='__main__':
    started=perf_counter()
    hashcode,source=read(BASE/'row-cap-physical-slice-dense-branch.pkl')
    assert hashcode==CAP and len(source['factors'])==26
    i,j,left,right,shared,positions,weights=matched(source)
    assert (i,j)==(7,17) and AXIS not in shared
    incident=tuple(k for k,(scope,_,_) in enumerate(source['factors']) if AXIS in scope)
    assert len(incident)==2 and len(set(incident)&{i,j})==1
    foreground=left if i in incident else right
    other=right if i in incident else left
    fpos,opos=positions if i in incident else positions[::-1]
    # Count each eligible J value through an entirely independent combined auxiliary histogram.
    fscope,frows=foreground
    xpos=fscope.index(AXIS)
    A=Counter((tuple(row[p] for p in fpos),row[xpos]) for row in frows)
    B=Counter(tuple(row[p] for p in opos) for row in other[1])
    tally=Counter()
    for (key,J),n in A.items():
        if B[key]: tally[J]+=n*B[key]
    assert tally=={(1,):249536,(2,):242496,(3,):242496}
    assert sum(tally.values())==734528
    print('exact J partition',AXIS,'incident factors',incident,'foreground coverage',sorted(tally.items()))
    for k in incident:
        a,r,_=source['factors'][k]
        domain={row[a.index(AXIS)] for row in r}
        assert domain==set(tally)
        print('complete local J alphabet',k,sorted(domain))
    for n in (1,2,3):
        here=BASE/f'j{n}'
        pin,child=read(here/'dense-saturated-frontier.pkl')
        J=(n,)
        assert child['physical_cut']==(source['physical_cut'],(AXIS,J))
        assert child['used_before']==source['used_before']
        total=0
        for k,((x,X,d),(y,Y,e)) in enumerate(zip(source['factors'],child['factors'],strict=True)):
            assert d==e
            total+=len(Y)
            if k not in incident:
                assert (x,X)==(y,Y)
                continue
            p=x.index(AXIS)
            assert y==x[:p]+x[p+1:]
            lift={row[:p]+(J,)+row[p:]:z for row,z in Y.items()}
            assert lift=={row:z for row,z in X.items() if row[p]==J}
            print('exact inverse lift child',n,'incident factor',k,'coefficient rows',len(Y),'denominator',d)
        print('PASS degree-two J child',n,'selected total rows',total,'input SHA256',pin)
        if '--include-status' in argv:
            residual_cap(n,child)
    print('independent route check elapsed',f'{perf_counter()-started:.6f}')
