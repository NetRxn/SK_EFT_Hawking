"""Independent exact support, inverse lift and next-cut census for assignment 7."""
from ast import literal_eval
from collections import Counter,defaultdict
from hashlib import sha256
from math import prod
from pathlib import Path
from runpy import run_path
from time import perf_counter
import re

helpers=run_path('label-support.py')
root=helpers['ROOT']
read=helpers['read']
parent=root/'corrected/dense-saturated-frontier.pkl'
author=Path('/private/tmp/l1-group672-original-label.dAv5G8/case0')
start=perf_counter()
axes,roster,peak=helpers['from_compiled']()
parent_hash,source=read(parent)
assert parent_hash=='cceeb82ab1491de4ed0de3935d49e2fdb0449e50e6597c0d43c4600f4fe96224'
declared=(author/'joint-label-roster.tsv').read_text().splitlines()
assert literal_eval(declared[0].split('\t')[1])==axes
projected=tuple((tuple((scope.index(w),axes.index(w)) for w in scope if w in axes),
    Counter(tuple(row[p] for p,w in enumerate(scope) if w in axes) for row in rows))
    for scope,rows,_ in source['factors'])
sizes=[]
for n,labels in enumerate(roster):
    local=[counts[tuple(labels[p] for _,p in column)] for column,counts in projected]
    sizes.append(sum(local))
    fields=declared[n+1].split('\t')
    assert len(fields)==4 and (int(fields[0]),literal_eval(fields[1]),int(fields[2]),int(fields[3]))==(n,labels,sum(local),max(local))
    assert all(local)
assert len(declared)==9 and len(source['factors'])==88
index=min(range(len(sizes)),key=lambda n:(sizes[n],n))
assert index==0 and sizes[index]==78966
selected_hash,selected=read(author/'dense-saturated-frontier.pkl')
assert selected_hash=='8a708e4b2ded8bca409493984e1c9ba4bdc6820c179b8491ebb555b276fa4e8c'
assert selected['group']==672 and selected['used_before']==0
assert selected['physical_cut']==(axes,roster[index])
assert selected['joint_label_index']==index and selected['complete_label_roster']==roster
fixed=dict(zip(axes,roster[index],strict=True))
for n,((a,A,d),(b,B,e)) in enumerate(zip(source['factors'],selected['factors'],strict=True)):
    assert b==tuple(w for w in a if w not in fixed) and d==e
    recovered={}
    for row,z in B.items():
        values=dict(zip(b,row,strict=True))|fixed
        recovered[tuple(values[w] for w in a)]=z
    assert len(recovered)==len(B)
    constraints=[(i,fixed[w]) for i,w in enumerate(a) if w in fixed]
    exact={row:z for row,z in A.items() if all(row[i]==v for i,v in constraints)}
    assert recovered==exact,(n,len(recovered),len(exact))
    print('factor',n,'original scope',len(a),'kept',len(b),'selected rows',len(B),'denominator',d)
print('PASS original exact roster, independently lifted all 78966 selected signed rows and denominators')
cap_hash,cap=read(author/'row-cap-physical-slice-dense-branch.pkl')
assert cap_hash=='ab5ba8022e5d15d46b091fee50d35090c7c90b972463ef1ef23af9824b8972d2'
assert cap['physical_cut']==selected['physical_cut']
denominator=576173855599322741762003196268511232
assert prod(d for _,_,d in source['factors'])==prod(d for _,_,d in selected['factors'])==prod(d for _,_,d in cap['factors'])==denominator
assert len(cap['factors'])==15
assert set(Counter(w for a,_,_ in cap['factors'] for w in a).values())=={2}
print('cap pin',cap_hash,'rows',sum(len(r) for _,r,_ in cap['factors']),'denominator',denominator,'prior matched works',cap['used_before'])
i,j=cap['rejected_pair']
(a,A,_),(b,B,_)=cap['factors'][i],cap['factors'][j]
shared=tuple(w for w in a if w in b)
ix,iy=[tuple(s.index(w) for w in shared) for s in (a,b)]
histX=Counter(tuple(row[p] for p in ix) for row in A)
histY=Counter(tuple(row[p] for p in iy) for row in B)
work={row:histX[row]*histY[row] for row in histX.keys()&histY.keys()}
assert sum(work.values())==cap['matched']==2458624
print('refused join',i,j,'left and right rows',len(A),len(B),'common atoms',len(work),'physical axes',shared)
choices=[]
for k,wire in enumerate(shared):
    tally=Counter()
    for row,n in work.items():
        tally[row[k]]+=n
    if len(tally)>1:
        choices.append((max(tally.values()),len(tally),wire,sorted(tally.items())))
for peak,c,w,cells in sorted(choices):
    print('cut',w,'supported',c,'peak',peak,'exact disposed roster',cells)
assert choices
pick=min(choices)
assert sum(n for _,n in pick[-1])==2458624
print('PASS complete proposed secondary split of refused join',pick)
print('independent scope-only audit seconds',f'{perf_counter()-start:.6f}')

logs=(author/'contraction.out').read_text().splitlines()
status=(author/'contraction.receipt').read_text().splitlines()
assert status[0]=='child status 2'
assert logs[-1]=='open row cap 15 2458624 frontier saved'
joins=[int(re.match(r'join \d+ (\d+) \d+ axes \d+',r)[1]) for r in logs if r.startswith('join ')]
assert len(joins)==88-15 and sum(joins)==cap['used_before']
assert (author/'contraction.err').read_bytes()==b''
print('PASS scope and author measured quote',status[1],'completed accepted joins',len(joins),'completed products',sum(joins))
assert len(work)==8 and set(work.values())=={307328}
print('case0 exact full shared-tuple slices', sorted(work.items()), 'each bound 307328')
