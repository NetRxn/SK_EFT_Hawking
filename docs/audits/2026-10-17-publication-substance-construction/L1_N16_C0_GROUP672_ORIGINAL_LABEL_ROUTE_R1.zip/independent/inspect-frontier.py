from collections import Counter
from hashlib import file_digest
from itertools import combinations
from math import prod
from pathlib import Path
from pickle import load
from time import perf_counter

root=Path('/private/tmp/l1-dense-group672.EF30g6')
fpath=root/'worst-wgg-slice/row-cap-physical-slice-dense-branch.pkl'
start=perf_counter()
with fpath.open('rb') as stream:
    print('source sha256',file_digest(stream,'sha256').hexdigest(),flush=True)
    stream.seek(0)
    obj=load(stream)
factors=obj['factors']
axes=[w for w,_,_ in factors]
tables=[t for _,t,_ in factors]
counts=Counter(w for a in axes for w in a)
print('checkpoint info',[(k,v) for k,v in obj.items() if k!='factors'])
print('degree histogram',Counter(counts.values()),'wires',len(counts),'dimensions before quotient',Counter(w[0] for w in counts),'stored rows',sum(map(len,tables)),'denominator',prod(d for _,_,d in factors))
print('factor sizes',[(i,len(a),len(r),d) for i,(a,r,d) in enumerate(factors)])
assert all(n==2 for k,n in counts.items() if k[0]!='L')
edges={}
for i,j in combinations(range(len(factors)),2):
    w=tuple(w for w in axes[i] if w in axes[j])
    if not w:
        continue
    ix=tuple(axes[i].index(k) for k in w)
    jx=tuple(axes[j].index(k) for k in w)
    A=Counter(tuple(r[p] for p in ix) for r in tables[i])
    B=Counter(tuple(r[p] for p in jx) for r in tables[j])
    support=A.keys()&B.keys()
    products=sum(A[k]*B[k] for k in support)
    sepscope=tuple(w for w in axes[i]+axes[j] if (w in axes[i]) != (w in axes[j]))
    edges[i,j]=(len(w),len(A),len(B),len(support),products,len(sepscope))
    print('edge',i,j,*edges[i,j],flush=True)
print('smallest alternative pair products',sorted((s[4],p,s[5],s[3]) for p,s in edges.items())[:20])
print('minimum boundary width',sorted((s[5],p,s[4],s[3]) for p,s in edges.items())[:20])
print('wall seconds',f'{perf_counter()-start:.6f}')
