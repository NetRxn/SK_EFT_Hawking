from hashlib import sha256
from pathlib import Path
from shutil import copyfile
from subprocess import run
from sys import executable
from time import perf_counter
from resource import getrusage,RUSAGE_CHILDREN
from platform import system

author=Path('/private/tmp/l1-group672-original-label.dAv5G8')
work=Path('cap-replay-verified')
work.mkdir()
for file in ('contract-slice.py','dense-saturated-frontier.pkl'):
    copyfile(author/file,work/file)
start=perf_counter()
with (work/'contraction.out').open('xb') as out, (work/'contraction.err').open('xb') as err:
    native=run([executable,'-B','-u','contract-slice.py'],cwd=work,stdout=out,stderr=err,timeout=120)
seconds=perf_counter()-start
max_rss=getrusage(RUSAGE_CHILDREN).ru_maxrss * (1 if system()=='Darwin' else 1024)
assert native.returncode==2
for file in ('contraction.out','contraction.err','row-cap-physical-slice-dense-branch.pkl'):
    l,r=work/file,author/file
    evidence=l.read_bytes()
    assert evidence==r.read_bytes(),file
    print('PASS byte exact',file,sha256(evidence).hexdigest())
print('child status',native.returncode)
print('elapsed seconds',f'{seconds:.6f}')
print('child peak RSS bytes',max_rss)
