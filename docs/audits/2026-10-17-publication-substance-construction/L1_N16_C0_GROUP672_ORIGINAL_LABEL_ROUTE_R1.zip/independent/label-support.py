from ast import literal_eval
from collections import Counter,defaultdict
from hashlib import file_digest
from math import prod
from pathlib import Path
from pickle import load
from time import perf_counter

ROOT=Path('/private/tmp/l1-dense-group672.EF30g6')
MAX_REL=4096

def natural(s,t):
    a,A=s
    b,B=t
    edges=tuple(w for w in a if w in b)
    pa=tuple(a.index(w) for w in edges)
    pb=tuple(b.index(w) for w in edges)
    tail=tuple(i for i,w in enumerate(b) if w not in a)
    lookup=defaultdict(list)
    for row in B:
        lookup[tuple(row[i] for i in pb)].append(tuple(row[i] for i in tail))
    out=set()
    for row in A:
        for extension in lookup[tuple(row[i] for i in pa)]:
            out.add(row+extension)
            if len(out)>MAX_REL:
                raise ValueError(('label support exceeds bounded census',a,b))
    return a+tuple(b[i] for i in tail),out

def join_all(relations):
    remaining=[(scope,rows) for scope,rows in relations if scope]
    position=min(range(len(remaining)),key=lambda i:len(remaining[i][1]))
    joined=remaining.pop(position)
    peak=len(joined[1])
    while remaining:
        axes=set(joined[0])
        j=min(range(len(remaining)),key=lambda i:(len(set(remaining[i][0])-axes),
               -len(set(remaining[i][0])&axes),len(remaining[i][1])))
        joined=natural(joined,remaining.pop(j))
        peak=max(peak,len(joined[1]))
    current,table=joined
    axes=tuple(sorted(current))
    index=tuple(current.index(w) for w in axes)
    rows=tuple(sorted(tuple(row[i] for i in index) for row in table))
    return axes,rows,peak

def symbols(obj):
    return tuple((tuple(w for w in a if w[0]=='L'),
                 {tuple(row[i] for i,w in enumerate(a) if w[0]=='L') for row in r})
                 for a,r,d in obj['factors'])

def from_compiled():
    keys={a:(literal_eval(l),literal_eval(w),int(d))
          for a,l,w,_,_,d in (line.split('\t') for line in (ROOT/'schema.tsv').read_text().splitlines())}
    row=next(line.split('\t') for line in (ROOT/'cut-plan.tsv').read_text().splitlines() if line.startswith('672\t'))
    _,count,rawrows,size,coords,indices=row
    cut_axes=literal_eval((ROOT/'cut-axes.tsv').read_text())
    fixed=dict(zip(cut_axes,literal_eval(coords),strict=True))
    raw=(ROOT/'block-index.tsv').read_text().splitlines()
    relations=defaultdict(set)
    counts=0
    for index in literal_eval(indices):
        family,atoms,_,_,n,_=raw[index].split('\t')
        a=keys[family][0]
        points=literal_eval(atoms)
        assert set(a)<=set(fixed)|{v for v in a if v[0]=='L'}
        assert all(fixed[w]==v for w,v in zip(a,points,strict=True) if w in fixed)
        relations[family].add(tuple(v for w,v in zip(a,points,strict=True) if w not in fixed))
        counts+=int(n)
    assert int(rawrows)==counts and len(relations)==88
    result=join_all((tuple(w for w in keys[family][0] if w not in fixed),coords)
                    for family,coords in relations.items())
    assert len(result[1])==int(count)
    return result

def read(path):
    with path.open('rb') as f:
        digest=file_digest(f,'sha256').hexdigest()
        f.seek(0)
        obj=load(f)
    return digest,obj

def compare(path,axes,full):
    digest,obj=read(path)
    print('input',digest,path,flush=True)
    a,rows,peak=join_all(symbols(obj))
    assert a==axes and set(rows)<=set(full)
    print('joint labels',len(rows),'peak enumeration',peak,'factor denominator',prod(d for _,_,d in obj['factors']))
    scope=tuple(tuple((j,axes.index(w)) for j,w in enumerate(a) if w in axes) for a,_,_ in obj['factors'])
    a,b=obj['rejected_pair']
    pair_shared=tuple(w for w in obj['factors'][a][0] if w in obj['factors'][b][0])
    loc=[tuple(obj['factors'][i][0].index(w) for w in pair_shared) for i in (a,b)]
    cut=('G',0,3,0) if 'worst-wgg' in str(path) else ('G',1,3,0)
    gpos=obj['factors'][a][0].index(cut) if cut in obj['factors'][a][0] else None
    profiles=[]
    for i,assignment in enumerate(full):
        f={j:[row for row in obj['factors'][j][1]
                    if all(row[u]==assignment[v] for u,v in scope[j])] for j in range(len(scope))}
        if any(not r for r in f.values()):
            assert assignment not in rows
            print('L case',i,'exact zero by empty factor',tuple(j for j,r in f.items() if not r))
            continue
        assert assignment in rows
        h=Counter(tuple(row[p] for p in loc[1]) for row in f[b])
        traffic=Counter()
        for key in f[a]:
            n=h[tuple(key[p] for p in loc[0])]
            if n: traffic[key[gpos] if gpos is not None else None]+=n
        print('L case',i,'rows',sum(map(len,f.values())),'rejected-pair',sum(traffic.values()),
              'supported G values',len(traffic),'peak',max(traffic.values(),default=0))
        if 'worst-wgg' in str(path):
            print('L case',i,'per-G forecasts',sorted(traffic.items()))
        profiles.append(traffic)
        del f
    return profiles
if __name__=='__main__':
    start=perf_counter()
    labels,full,peak=from_compiled()
    print('source complete joint roster',labels,'count',len(full),'peak support rows',peak,flush=True)
    for i,t in enumerate(full): print(i,repr(t))
    compare(ROOT/'worst-wgg-slice/row-cap-physical-slice-dense-branch.pkl',labels,full)
    print('wall seconds',f'{perf_counter()-start:.6f}')
