from hashlib import sha256
from pathlib import Path
from subprocess import check_output
from io import BytesIO
from zipfile import ZipFile

CHECKPOINT='3c2d5779d2cd749d9835ef549b8ff93197a06d5d'
pub=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
root=Path('/private/tmp/l1-dense-group672.EF30g6')
scope='docs/audits/2026-10-17-publication-substance-construction'
def git(*args):
    return check_output(['git','-C',str(pub),*args])
def archive(suffix):
    filename=f'L1_N16_C0_COMPLEMENTARY_{suffix}_R1.zip'
    rel=f'{scope}/{filename}'
    frozen=git('show',f'{CHECKPOINT}:{rel}')
    assert frozen==(pub/rel).read_bytes()
    print('committed archive',git('rev-parse',f'{CHECKPOINT}:{rel}').decode().strip(),sha256(frozen).hexdigest(),rel)
    return ZipFile(BytesIO(frozen))
def pairs(z,path):
    return {f.removeprefix('./'):d for d,f in (r.split(maxsplit=1) for r in z.read(path).decode().splitlines())}
with archive('CASES30_33') as prior:
    parent=pairs(prior,'group672/restart-hashes.sha256')
    inputs=pairs(prior,'group672/input.sha256')
    for key in ('corrected/dense-saturated-frontier.pkl','row-cap-physical-slice-dense-branch.pkl',
                'cut-axes.tsv','cut-plan.tsv','block-index.tsv','schema.tsv'):
        hashes=parent|inputs
        h=sha256((root/key).read_bytes()).hexdigest()
        assert h==hashes[key]
        print('pinned input',h,key)
with archive('CASE34') as newer:
    h=sha256((root/'worst-wgg-slice/row-cap-physical-slice-dense-branch.pkl').read_bytes()).hexdigest()
    assert h==pairs(newer,'group672/independent/input-artifacts.sha256')['worst-wgg-slice/row-cap-physical-slice-dense-branch.pkl']
    print('pinned input',h,'worst-wgg-slice/row-cap-physical-slice-dense-branch.pkl')
    assert newer.read('group672/fourth-cut-census.out')==(root/'worst-wgg-slice/fourth-cut-census.out').read_bytes()
    print('pinned public census bytes match')
    author=Path('/private/tmp/l1-group672-original-label.dAv5G8')
    s=sha256((author/'contract-slice.py').read_bytes()).hexdigest()
    assert s==pairs(newer,'group672/independent/input-artifacts.sha256')['worst-w-slice/contract-slice.py']
    print('author contractor matches prior source',s)
