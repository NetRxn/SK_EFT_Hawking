from hashlib import file_digest
from pathlib import Path
from shutil import copyfile

author=Path('/private/tmp/l1-group672-original-label.dAv5G8')
ancestor=Path('/private/tmp/l1-dense-group672.EF30g6')
base_items=('condition.py','run.py','partition.py','contract-slice.py','contraction.out','contraction.err','contraction.receipt',
            'joint-label-roster.tsv','parent.sha256','preparation.out','branch7-cap-census.tsv',
            'dense-saturated-frontier.pkl','row-cap-physical-slice-dense-branch.pkl')
child_items=('run.py','contract-slice.py','contraction.out','contraction.err','contraction.receipt',
             'preparation.out','dense-saturated-frontier.pkl','row-cap-physical-slice-dense-branch.pkl')
archives=('cut-axes.tsv','cut-plan.tsv','block-index.tsv','schema.tsv','corrected/dense-saturated-frontier.pkl',
          'row-cap-physical-slice-dense-branch.pkl','worst-wgg-slice/row-cap-physical-slice-dense-branch.pkl')
with Path('input-operands.sha256').open('w') as inventory:
    for base,items in ((author,base_items),(author/'case0',child_items+('joint-label-roster.tsv','condition.py')),
                       *((author/d,child_items) for d in ('j1','j2','j3'))):
        for item in items:
            f=base/item
            with f.open('rb') as source:
                print(file_digest(source,'sha256').hexdigest(),f,sep='  ',file=inventory)
            if f.suffix!='.pkl':
                local=Path('author-receipts')/f.relative_to(author)
                local.parent.mkdir(parents=True,exist_ok=True)
                copyfile(f,local)
    for name in archives:
        f=ancestor/name
        with f.open('rb') as source:
            print(file_digest(source,'sha256').hexdigest(),f,sep='  ',file=inventory)
