from collections import Counter
from classify import classify
from census import profile
_,overlap=classify()
pairs=Counter(); types=Counter()
for a,b,w,channels in overlap:
    if (a,b)==(166856593410,8960795485785):continue
    assert len(channels) in (1,2)
    pairs[len(channels)]+=1
    types[any(x and y for e,p,q,x,y in channels)]+=1
    edgesA=profile(a)[2];edgesB=profile(b)[2]
    for e,p,q,x,y in channels:
        assert x in (0,2) and y in (0,2) and (x or y)
        for n,t,d in ((x,p,edgesA),(y,q,edgesB)):
            if n:
                assert t==(2,2) and sorted(d[e])==[0,2]
            else:
                assert all(s in (2,4) for s in t)
                assert e not in d
assert types=={False:51,True:24}
print("overlapping cores per representative",dict(pairs),"both spatial layers somewhere",types[True])
