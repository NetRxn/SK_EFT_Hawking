from fractions import Fraction as F
from pathlib import Path
from census import components,profile,read,write
degree="/private/tmp/l1-c0-degree-independent.nEpHYJlb"
q3="/private/tmp/l1-c0-q3-independent.t3DCmj20"
core="/private/tmp/l1-c0-core-independent.xCQTska6"
previous="/private/tmp/l1-c0-isolated-independent.IcFdd3lq"

def signed(path):
    return {(int(a),int(b)):(int(w),F(z)) for a,b,w,z in read(path)}

block={(int(a),int(b)):int(w) for a,b,w in read(degree+"/orbits.tsv")}
axes={(int(a),int(b)) for t,a,b,w,z in read(degree+"/signed.tsv") if t=="axis"}
peeled=set(signed(q3+"/orbit-values.tsv"))
isol={}
for (a,b),w in block.items():
    if (a,b) in axes|peeled:continue
    shape=components(profile(a)[0])+components(profile(b)[0])
    if shape and all(s[1]==1 for s in shape):isol[a,b]=w
assert (len(isol),sum(isol.values()))==(816,67590)
zero={(int(a),int(b)):(int(w),F(0)) for a,b,w in read(core+"/zeros.tsv")}
pilot={}
for a,b,w,z,*_ in read(previous+"/pilot.tsv"):
    pilot[int(a),int(b)]=(int(w),F(z))
catalog={}
tables=[zero,signed(core+"/signed-orbits.tsv"),signed(previous+"/scalar-values.tsv"),pilot,signed("exact.tsv")]
for table in tables:
    for k,(w,z) in table.items():
        assert block[k]==w and k not in catalog
        if k in isol:catalog[k]=w,z
assert set(catalog)==set(isol)
assert sum(z>0 for w,z in catalog.values())==814 and sum(z==0 for w,z in catalog.values())==2
subtotal=sum(w*z for w,z in catalog.values())
assert subtotal==F(2062712136557518696419296388255447513513827,165431634479037188218552320000)
print("exact isolated total",len(catalog),sum(w for w,z in catalog.values()),"positive",814,"zero",2,"weighted subtotal",subtotal)
known=(axes|peeled).union(*tables)
remain=[(a,b,w) for (a,b),w in block.items() if (a,b) not in known]
assert (len(remain),sum(w for a,b,w in remain))==(10994,947355)
assert not set(isol)&{(a,b) for a,b,w in remain}
print("remaining temporal block",len(remain),sum(w for a,b,w in remain))
write("complete-isolated.tsv",[(a,b,w,z) for (a,b),(w,z) in sorted(catalog.items())])
write("block-remaining.tsv",remain)
