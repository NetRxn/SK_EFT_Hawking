from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations,combinations_with_replacement,product
from math import prod
from census import occupancy,profile,read

def plus(x,y):return (x[0]+y[0],x[1]+y[1])
def mul(x,y):return (x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def state(label,mask,p=0):return (label,mask,p)
def collect(out,k,v):
    out[k]=plus(out.get(k,(0,0)),v)
def clean(d):return {k:v for k,v in d.items() if any(v)}
same=defaultdict(dict)
for d,s,t,a,b,r,i in (map(int,l) for l in read("edge-moments.tsv")):
    if not s:same[d][state(t,a),state(0,b)]=(r,i)
assert tuple(map(len,(same[2],same[4])))==(48,380)
mixed={(state(a,u),state(b,v)):(r,i) for a,b,u,v,r,i in (map(int,l) for l in read("mixed.tsv"))}
assert len(mixed)==3952
@cache
def decorated(owner,chi):
    t={(state(l if not owner else 0,u,p),state(l if owner else 0,v,q)):(r,i)
       for l,u,v,p,q,r,i in (map(int,l) for l in read(f"decorated-{owner}-{chi}.tsv"))}
    assert len(t)==(3136 if chi==2 else 1584)
    return t
pairs=list(combinations_with_replacement(range(4),2))
W=[(pairs[a],pairs[b],n) for a,b,n in (map(int,r) for r in read("source-gram.tsv"))]
V=defaultdict(list)
for chi,a,b,i,n in (map(int,r) for r in read("bivectors.tsv")):V[chi,i].append((a,b,n))

def enc(word):
    out=0
    for n in word:out=out*4+n
    return out

inv_trace=defaultdict(list)
for i,a,b,r,j in (map(int,x) for x in read("imaginary-trace.tsv")):
    inv_trace[a,b].append((i,(r,j)))

@cache
def decorations(chi):
    if chi==2:
        out=[]
        for a,b,c,d in product(range(2),repeat=4):
            irow,icol=2*a+c,2*b+d
            for (i,z),(j,w) in product(inv_trace[a,b],inv_trace[c,d]):
                for (r,s,A),(p,q,B) in product(V[0,i],V[1,j]):
                    x,y=mul(z,w)
                    out.append((4*irow+icol,(r,p),(s,q),(2*A*B*x,2*A*B*y)))
        return out
    out=[]
    for i,j in product(range(3),repeat=2):
        p=3*i+j
        for (a,b,c),(d,e,f) in product(V[chi,i],V[chi,j]):
            out.append((p,(a,d),(b,e),(2*c*f,0)))
        if i==j:out.extend((p,A,B,(-C,0)) for A,B,C in W)
    return out

@cache
def local(m,chi,special):
    out={(0,((),(),())):(1,0)}
    for axis,n in enumerate(m):
        assert n%2==0
        j,k=[d for d in range(3) if d!=axis]
        for _ in range(n//2):
            if axis==special:
                assert n==2
                terms=decorations(chi)
            else:
                terms=[(0,a,b,(c,0)) for a,b,c in W]
            nxt={}
            for (p,key),a in out.items():
                for q,A,B,C in terms:
                    v=list(key)
                    v[j]=tuple(sorted(v[j]+A))
                    v[k]=tuple(sorted(v[k]+B))
                    collect(nxt,(p|q,tuple(v)),mul(a,C))
            out=clean(nxt)
    return out

def inv(a,b):return sum((a>>(i+1)).bit_count() for i in range(8) if b>>i&1)

def make_network(code,spin,mutant):
    special_edges=dict(spin); affected={}
    _,_,graph=profile(code)
    occ=occupancy(code)
    factors=[]
    inc=[[] for _ in occ]
    total=1
    for j,((a,b,k),(u,v)) in enumerate(sorted(graph.items())):
        d=u+v
        if (a,b) in special_edges:
            assert d==2 and not (u and v) and a not in affected and b not in affected
            chi=special_edges[a,b]
            affected[a]=affected[b]=(k,chi)
            t=decorated(int(not u),chi);den=3072
            special=True
        elif u and v:
            assert u==v==2
            t=mixed;den=12288;special=False
        else:
            t=same[d] if u else {(z,x):c for (x,z),c in same[d].items()}
            den=64 if d==2 else 12288;special=False
        total*=den
        factors.append(((2*j,2*j+1),t))
        for p,x in enumerate((a,b)):
            allowed=defaultdict(set)
            for row in t:
                l,m,i=row[p]
                allowed[l,i].add(m)
            inc[x].append((2*j+p,k,special,allowed))
    for x,edges in enumerate(inc):
        spec,chi=affected.get(x,(-1,-1))
        out={}
        for (s,labs),c in local(occ[x],chi,spec).items():
            lbl=[(enc(labs[k]),s if marked else 0) for e,k,marked,allowed in edges]
            allowed=[e[3].get(l,()) for e,l in zip(edges,lbl)]
            if not all(allowed):continue
            keys=sorted(range(len(edges)),key=lambda i:len(allowed[i]))
            masks=[0]*len(edges)
            def fill(j,used):
                if j==len(keys):
                    assert used==255
                    parity=sum(inv(a,b) for i,a in enumerate(masks) for b in masks[i+1:]) if x!=mutant else 0
                    sign=(-1 if parity%2 else 1)
                    value=(sign*c[0],sign*c[1])
                    row=tuple(state(l,m,r) for (l,r),m in zip(lbl,masks))
                    collect(out,row,value)
                    return
                i=keys[j]
                vals=(255^used,) if j==len(keys)-1 and (255^used) in allowed[i] else (() if j==len(keys)-1 else allowed[i])
                for m in vals:
                    if m&used:continue
                    masks[i]=m
                    fill(j+1,m|used)
            fill(0,0)
        factors.append((tuple(e[0] for e in edges),clean(out)))
    return factors,total

def project(row,ix):return tuple(row[i] for i in ix)
def grouped(scope,table,variables):
    idx=tuple(scope.index(v) for v in variables)
    out=defaultdict(list)
    for row,z in table.items():out[project(row,idx)].append((row,z))
    return out

def final_three(fs):
    # On the closing three-factor loop, cache the sparse transfer on
    # the shared A/B interface conditioned on a C row. Stream only
    # matches to the scalar, so no dense join is ever allocated.
    choices=[]
    for i in range(3):
        a,b,c=[fs[(i+j)%3] for j in range(3)]
        ab=tuple(sorted(set(a[0])&set(b[0])))
        ac=tuple(sorted(set(a[0])&set(c[0])))
        bc=tuple(sorted(set(b[0])&set(c[0])))
        if not (ab and ac and bc):continue
        if set(a[0])!=set(ab+ac) or set(b[0])!=set(ab+bc) or set(c[0])!=set(ac+bc):continue
        A=grouped(*a,ac); B=grouped(*b,bc)
        x=tuple(c[0].index(v) for v in ac);y=tuple(c[0].index(v) for v in bc)
        cost=sum(min(len(A.get(project(row,x),())),len(B.get(project(row,y),()))) for row in c[1])
        choices.append((cost,A,B,a,b,c,ab,x,y))
    if not choices:return None
    cost,A,B,a,b,c,ab,x,y=min(choices,key=lambda r:r[0])
    assert cost<=8_000_000
    ii=tuple(a[0].index(v) for v in ab);jj=tuple(b[0].index(v) for v in ab)
    X={p:{project(r,ii):z for r,z in group} for p,group in A.items()}
    Y={p:{project(r,jj):z for r,z in group} for p,group in B.items()}
    result=(0,0)
    for row,z in c[1].items():
        Xr=X.get(project(row,x),{});Yr=Y.get(project(row,y),{})
        if len(Xr)>len(Yr):Xr,Yr=Yr,Xr
        for r,xx in Xr.items():
            if r in Yr:result=plus(result,mul(z,mul(xx,Yr[r])))
    return result,cost

def integrate(fs,reverse):
    if reverse:fs=fs[::-1]
    peak=max(len(t) for s,t in fs)
    work=0
    while len(fs)>1:
        if len(fs)==3:
            closed=final_three(fs)
            if closed:return closed[0],peak,max(work,closed[1])
        options=[]
        for i,j in combinations(range(len(fs)),2):
            A,X=fs[i];B,Y=fs[j]
            s=tuple(sorted(set(A)&set(B)))
            if not s:continue
            p=tuple(A.index(v) for v in s);q=tuple(B.index(v) for v in s)
            P=Counter(project(r,p) for r in X);Q=Counter(project(r,q) for r in Y)
            n=sum(c*Q[k] for k,c in P.items())
            options.append((n,i,j,p,q,s))
        if options:n,i,j,p,q,s=min(options)
        else:
            i,j,p,q,s=0,1,(),(),()
            n=len(fs[0][1])*len(fs[1][1])
        A,X=fs[i];B,Y=fs[j]
        assert n<=5_000_000,(A,B,n)
        work=max(work,n)
        dst=tuple(sorted(set(A)^set(B)))
        take=tuple((v in B,B.index(v) if v in B else A.index(v)) for v in dst)
        out={}
        right=grouped(B,Y,s)
        for a,z in X.items():
            for b,w in right.get(project(a,p),()):
                k=tuple((a,b)[side][r] for side,r in take)
                collect(out,k,mul(z,w))
        result=clean(out)
        peak=max(peak,len(result))
        assert peak<300_000
        fs=[f for k,f in enumerate(fs) if k not in (i,j)]+[(dst,result)]
    assert not fs[0][0]
    return fs[0][1].get((),(0,0)),peak,work

@cache
def value(code,spin=(),mutant=-1,reverse=False,tile=None):
    factors,den=make_network(code,spin,mutant)
    if tile is not None:
        variable,bit,choice=tile
        hits=0
        for j,(scope,table) in enumerate(factors):
            if variable not in scope:continue
            i=scope.index(variable)
            halves=tuple({k:v for k,v in table.items() if (k[i][1]>>bit)&1==b} for b in (0,1))
            assert not (halves[0].keys()&halves[1].keys())
            assert halves[0]|halves[1]==table
            factors[j]=scope,halves[choice]
            hits+=1
        assert hits==2
    (r,i),peak,work=integrate(factors,reverse)
    assert i==0
    result=F(r,den)
    print("layer",code,"spin",spin,"wrong site",mutant,"reverse",reverse,"tile",tile,"peak",peak,"products",work,"exact",result,flush=True)
    return result
