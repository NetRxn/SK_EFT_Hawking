from collections import Counter,defaultdict
from functools import cache
from fractions import Fraction as F
from itertools import product
from math import prod
from pathlib import Path
from census import read,write

def mul(a,b):
    s,*u=a;t,*v=b
    return (s*t-sum(x*y for x,y in zip(u,v)),*(s*v[i]+t*u[i]-u[(i+1)%3]*v[(i+2)%3]+u[(i+2)%3]*v[(i+1)%3] for i in range(3)))
def adj(a):return a[0],*(-x for x in a[1:])
unit=[tuple(int(i==j) for i in range(4)) for j in range(4)]
rotation={}
for i,j in product(range(3),repeat=2):
    c=Counter()
    for a,b in product(range(4),repeat=2):
        h=mul(mul(unit[a],unit[j+1]),adj(unit[b]))
        c[tuple(sorted((a,b)))]+=h[i+1]
    rotation[i,j]={k:v for k,v in c.items() if v}

# Check the polynomial identity coefficient by coefficient in the
# canonical +i Pauli basis, before substituting the unit norm.
for i,j in product(range(3),repeat=2):
    c=Counter(rotation[i,j])
    c.update(rotation[j,i])
    if i==j:
        for a in range(4):c[a,a]+=1
        for a in range(3):c.subtract(rotation[a,a])
    assert {k:v for k,v in c.items() if v}=={tuple(sorted((i+1,j+1))):4}
@cache
def moment(q):
    counts=Counter(q)
    if any(n%2 for n in counts.values()):return F(0)
    return F(prod(prod(range(1,n,2)) for n in counts.values()),prod(range(4,4+len(q),2)))
for i,j,k,l in product(range(3),repeat=4):
    s=sum(a*b*moment(tuple(sorted(u+v))) for u,a in rotation[i,j].items() for v,b in rotation[k,l].items())
    assert s==F(int(i==k and j==l),3)
print("adjoint polynomial terms",sum(map(len,rotation.values())),"81 Schur entries and nine projection identities")
write("adjoint.tsv",[(i,j,*k,v) for (i,j),c in sorted(rotation.items()) for k,v in sorted(c.items())])

@cache
def occupied_moment(i,j,k,l,q,r,chi):
    assert q//4==r//4
    key=q%4,r%4
    use_same=(q//4)%2==chi
    extra=key if use_same else ()
    other=F(1) if use_same else moment(key)
    result=192*other*sum(c*d*moment(tuple(sorted(p+s+extra)))
                         for p,c in rotation[i,j].items() for s,d in rotation[k,l].items())
    assert result.denominator==1
    return int(result)

ordinary=[{},{}]
for d,side,l,u,v,r,i in (map(int,s) for s in read("edge-moments.tsv")):
    if d==2:
        m,n=(u,v) if not side else (v,u)
        ordinary[side][l,m,n]=(48*r,48*i)
data=[[],[]]
for side,l,u,v,q,r,re,im in (map(int,s) for s in read("quadratic.tsv")):
    data[side].append((l,u,v,q,r,re,im))
assert [len(d) for d in data]==[2208]*2
for owner,chi in product(range(2),repeat=2):
    real,imag=Counter(),Counter()
    for l,u,v,q,r,re,im in data[owner]:
        for alpha,beta,gamma,delta in product(range(3),repeat=4):
            indices=(delta,alpha,gamma,beta) if q<8 else (alpha,delta,beta,gamma)
            w=occupied_moment(*indices,q,r,chi)
            if not w:continue
            k=l,u,v,3*alpha+beta,3*gamma+delta
            real[k]+=w*re
            imag[k]+=w*im
    table={k:(real[k],imag[k]) for k in real.keys()|imag.keys() if real[k] or imag[k]}
    assert len(table)==1584
    for i in range(3):
        a,b=Counter(),Counter()
        for (l,u,v,x,y),(r,t) in table.items():
            if x in (0,4,8) and y==4*i:
                a[l,u,v]+=r;b[l,u,v]+=t
        assert all(n==0 for n in b.values())
        assert {k:(n,0) for k,n in a.items() if n}==ordinary[owner]
    print("owner",owner,"chirality",chi,"decorated rows",len(table))
    write(f"decorated-{owner}-{chi}.tsv",[(*k,*v) for k,v in sorted(table.items())])
