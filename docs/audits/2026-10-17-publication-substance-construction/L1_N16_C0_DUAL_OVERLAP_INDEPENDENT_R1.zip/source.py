from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
from src.core.formulas import original_action_factors, original_coframe_blocks, original_spin4_link
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial, Symbol, identity_matrix

reg=OriginalRegulator(temporal_axis=0)
x=reg.sites[0]
unit=identity_matrix(4)
variables=[[Symbol("q",(x,0,("L","R")[c],q)) for q in range(4)] for c in range(2)]
H=original_spin4_link(*(tuple(Polynomial.variable(s) for s in row) for row in variables))
links=dict.fromkeys(reg.link_order,unit)
links[x,0]=H
raw=original_action_factors(reg,x,links)
# Collapse ordered placements by sorting the commuting coframes.
# Isolate plane (0,1) directly from the full Eq.7 action roster.
from collections import defaultdict
f=defaultdict(Polynomial)
for term in raw:
    if term.t_degree!=2 or {label[1] for label in term.components}!={2,3}:
        continue
    (u,a),(v,b)=sorted((d,i) for _,d,i in term.components)
    assert (u,v)==(2,3)
    f[a,b]+=term.coefficient
assert all(not f[a,a].terms for a in range(4))
vectors={}
for (a,b),p in f.items():
    coord={key[0]:z for key,z in p.terms if len(key)==1}
    assert len(coord)==len(p.terms)==(2 if a!=b else 0)
    for c in range(2):
        row=[]
        for s in variables[c]:
            z=coord.get(s)
            assert z is None or (z.imag==0 and abs(z.real)==2)
            row.append(0 if z is None else int(z.real/2))
        assert row[0]==0
        vectors[a,b,c]=row[1:]
print("raw grouped F01",[(s.index,z.real,z.imag) for (s,),z in f[0,1].terms])

pairs=list(combinations(range(5),2))
pairs=[(a,b-1) for a,b in pairs]
G=Counter()
for a,b,c,d,h in product(range(4),range(4),range(4),range(4),range(2)):
    u=pairs.index(tuple(sorted((a,c))))
    v=pairs.index(tuple(sorted((b,d))))
    G[h,u,v]+=sum(p*q for p,q in zip(vectors[a,b,h],vectors[c,d,h]))
assert all(G[0,u,v]==G[1,u,v] for u,v in product(range(10),repeat=2))
with open("source-gram.tsv","w") as out:
    for (_,u,v),n in sorted(G.items()):
        if _==0 and n: print(u,v,n,sep="\t",file=out)
print("equal chiral Gram support",sum(n!=0 and h==0 for (h,_,_),n in G.items()))

# Audit every raw ordered quartic's cut anchor occupancy. For temporal
# coframes, audit each of the four literal increments separately.
counts=Counter()
for center in reg.sites:
    layer=center[0]
    for term in original_action_factors(reg,center,links):
        if term.t_degree!=2: continue
        temp={anchor for anchor in term.anchors if anchor[1]==0}
        if temp:
            assert len(temp)==2 and all(site[0]==layer for site,_ in temp)
            u,v=sorted(site for site,_ in temp)
            assert sum(a!=b for a,b in zip(u,v))==1
            assert all(label[1]!=0 for label in term.components)
            counts["curvature"]+=1
        else:
            tl,=[label for label in term.components if label[1]==0]
            for block in original_coframe_blocks(reg,tl):
                assert block.anchor[1]==0
                assert {block.bar_site[0],block.psi_site[0]}=={0,1}
                counts["coframe increments"]+=1
assert counts=={"curvature":3072,"coframe increments":12288}
print("ordered source roster audit",sorted(counts.items()))

def edge(axis):
    y=reg.step(x,axis)[0]
    ids={g:i for i,g in enumerate(g for g in reg.generator_order if g[0] in (x,y))}
    E=Counter()
    for side,center in enumerate((x,y)):
        for a in range(4):
            for inc in original_coframe_blocks(reg,(center,axis,a)):
                for i,j in product(range(4),repeat=2):
                    u=ids[inc.bar_site,"bar",i];v=ids[inc.psi_site,"psi",j]
                    for (s,),z in inc.matrix[i][j].terms:
                        site,ax,chi,q=s.index
                        assert ax==axis
                        q=q+4*(chi=="R")+8*(site==y)
                        coeff=z*(4*inc.weight*(1 if u<v else -1))
                        mask=(1<<u)|(1<<v)
                        E[side,a,mask,q,0]+=coeff.real
                        E[side,a,mask,q,1]+=coeff.imag
    return E
E=edge(1)
assert E==edge(2)==edge(3)
with open("source-edge.tsv","w") as out:
    for side,a,mask,q in sorted({i[:4] for i in E}):
        r,i=E[side,a,mask,q,0],E[side,a,mask,q,1]
        assert abs(r)+abs(i)==1
        print(side,a,mask,q,int(r),int(i),sep="\t",file=out)
print("raw source edge roster",len(E)//2)

# Check world permutation signs with a nonuniform rational configuration.
from itertools import permutations
probe=((1,0,0,0),(0,1,0,0),(F(1,2),)*4,
       (F(3,5),0,F(4,5),0),(0,F(5,13),0,F(12,13)),
       (F(8,17),F(15,17),0,0))
point={key:original_spin4_link(probe[(3*i+i//5)%6],probe[(7*i+i//3+1)%6])
       for i,key in enumerate(reg.link_order)}
def group_planes(raw):
    out=defaultdict(Polynomial)
    for term in raw:
        if term.t_degree==2:
            key=tuple(sorted((axis,label) for _,axis,label in term.components))
            out[key]+=term.coefficient
    return out
old=group_planes(original_action_factors(reg,x,point))
assert sum(bool(p.terms) for p in old.values())>0
for perm in permutations(range(1,4)):
    change=(0,)+perm
    sign=(-1)**sum(a>b for i,a in enumerate(change) for b in change[i+1:])
    def new_site(site):
        return tuple(site[change.index(i)] for i in range(4))
    new_links={(new_site(s),change[k]):h for (s,k),h in point.items()}
    new=group_planes(original_action_factors(reg,x,new_links))
    assert all(new[tuple(sorted((change[axis],label) for axis,label in key))]==val*sign
               for key,val in old.items())
print("all 6 spatial axis permutations match signed original action at asymmetric rational links")

from src.core.formulas import original_quaternion_haar_moment
from src.vestigial.original_coefficients import ExteriorPolynomial
assert [original_quaternion_haar_moment(e) for e in ((0,0,0,2),(0,0,0,4),(0,0,2,2),(0,0,1,3))]==[F(1,4),F(1,8),F(1,24),0]
for picked in combinations(range(8),4):
    mask=sum(1<<i for i in picked)
    a=ExteriorPolynomial(((mask,Polynomial.scalar(1)),))
    b=ExteriorPolynomial(((255^mask,Polynomial.scalar(1)),))
    assert (a*b).terms==((255,Polynomial.scalar((-1)**(sum(picked)-6))),)
print("canonical original Haar moments and all 70 complement signs match")

with open("bivectors.tsv","w") as out:
    for (a,b,c),row in sorted(vectors.items()):
        for i,n in enumerate(row):
            if n:print(c,a,b,i,n,sep="\t",file=out)

# Regenerate the fundamental product representation from actual source
# blocks and test the six imaginary-coordinate trace functionals.
from src.vestigial.original_coefficients import QComplex
z=QComplex(0,1)
P=[((0,1),(1,0)),((0,-z),(z,0)),((1,0),(0,-1))]
trace_coeffs={}
for i,a,b in product(range(3),range(2),range(2)):
    c=QComplex(0,-1)*P[i][b][a]
    if c.real or c.imag:trace_coeffs[i,a,b]=c
with open("imaginary-trace.tsv","w") as out:
    for (i,a,b),c in sorted(trace_coeffs.items()):
        print(i,a,b,int(c.real),int(c.imag),sep="\t",file=out)
for h,i in product(range(2),range(3)):
    poly=sum((H[a+2*h][b+2*h]*c for (j,a,b),c in trace_coeffs.items() if j==i),Polynomial())
    assert poly==2*Polynomial.variable(variables[h][i+1])
with open("fundamental-product.tsv","w") as out:
    for a,b,c,d in product(range(2),repeat=4):
        for key,value in (H[a][b]*H[2+c][2+d]).terms:
            x,y=key
            assert x.index[-2]=="L" and y.index[-2]=="R"
            print(2*a+c,2*b+d,x.index[-1],4+y.index[-1],int(value.real),int(value.imag),sep="\t",file=out)
for a,b in product(range(4),repeat=2):
    sign=(1 if a==3 else -1)*(1 if b==3 else -1)
    assert vectors[a,b,0]==[-sign*n for n in vectors[a,b,1]]
print("canonical fundamental-product source and chirality exchange phases pass")
