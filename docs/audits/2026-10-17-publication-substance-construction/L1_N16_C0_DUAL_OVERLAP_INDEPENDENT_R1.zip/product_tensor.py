from collections import Counter,defaultdict
from functools import cache
from fractions import Fraction as F
from itertools import product
from math import prod
from census import read,write

def mul(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def add(x,y):return x[0]+y[0],x[1]+y[1]
def conj(x):return x[0],-x[1]
def scale(x,k):return x[0]*k,x[1]*k
D=defaultdict(list)
for i,j,q,r,re,im in (map(int,x) for x in read("fundamental-product.tsv")):
    D[i,j].append(((q,r),(re,im)))
assert sum(map(len,D.values()))==64
@cache
def s3(q):
    ex=Counter(q)
    if any(n%2 for n in ex.values()):return F(0)
    return F(prod(prod(range(1,n,2)) for n in ex.values()),prod(range(4,4+len(q),2)))
@cache
def haar(q):
    return s3(tuple(i for i in q if i<4))*s3(tuple(i-4 for i in q if i>=4))
@cache
def mixed_moment(r,c,s,t,extra):
    result=(F(0),F(0))
    for (x,u),(y,v) in product(D[r,c],D[s,t]):
        z=haar(tuple(sorted(x+y+extra)))
        if z:result=add(result,scale(mul(conj(u),v),z))
    return result

ordinary=[{},{}]
for n,side,k,u,v,r,i in (map(int,x) for x in read("edge-moments.tsv")):
    if n==2:
        a,b=(u,v) if side==0 else (v,u)
        ordinary[side][k,a,b]=(48*r,48*i)

data=[[],[]];raw=[defaultdict(list),defaultdict(list)]
for owner,k,u,v,q,r,a,b in (map(int,x) for x in read("quadratic-all.tsv")):
    row=k,u,v,q,r,a,b
    raw[owner][k,u,v].append((q,r,(a,b)))
    if q//4==r//4:data[owner].append(row)
assert [len(z) for z in data]==[2208,2208]

def direct(side,k,u,v,p1,p2):
    # Integrate both physical anchors separately, without applying the
    # empty-anchor shortcut or assuming both coframes share an anchor.
    a,b=divmod(p1,4);c,d=divmod(p2,4)
    total=(F(0),F(0))
    for q,r,coef in raw[side][k,u,v]:
        z=(F(0),F(0))
        qa=tuple(n for n in (q,r) if n<8)
        qc=tuple(n-8 for n in (q,r) if n>=8)
        for i,j in product(range(4),repeat=2):
            L=mixed_moment(d,a,i,j,qa)
            R=mixed_moment(b,c,j,i,qc)
            z=add(z,mul(L,R))
        total=add(total,scale(mul(coef,z),F(1,16)))
    return total

for side in range(2):
    z={}
    for k,u,v,q,r,a,b in data[side]:
        extra=(q%8,r%8)
        for x,y,j,l in product(range(4),repeat=4):
            p=(l,x,j,y) if q<8 else (y,j,x,l)
            T=scale(mixed_moment(*p,extra),192)
            assert all(n.denominator==1 for n in T)
            if not any(T):continue
            key=k,u,v,4*x+y,4*j+l
            z[key]=add(z.get(key,(0,0)),mul((a,b),tuple(map(int,T))))
    z={k:v for k,v in z.items() if any(v)}
    assert len(z)==3136 and sum(i!=0 for _,i in z.values())==960
    for diag in range(4):
        contracted={}
        for (k,u,v,p1,p2),val in z.items():
            if p1%5==0 and p2==5*diag:contracted[k,u,v]=add(contracted.get((k,u,v),(0,0)),val)
        assert {k:v for k,v in contracted.items() if any(v)}==ordinary[side]
    rows=sorted(z)
    samples=[next(k for k in rows if z[k][0] and not z[k][1]),
             next(k for k in rows if z[k][1]>0),
             next(k for k in reversed(rows) if z[k][1]<0)]
    for k in samples:
        got=direct(side,*k)
        assert got==tuple(F(n,3072*4) for n in z[k])
        print("direct raw two-anchor control",side,k,got)
    print("product endpoint owner",side,"rows",len(z),"imaginary",sum(i!=0 for _,i in z.values()))
    write(f"decorated-{side}-2.tsv",[(*k,*v) for k,v in sorted(z.items())])
