from collections import Counter
from fractions import Fraction as F
from functools import cache
from itertools import permutations,product
from math import prod,factorial
from classify import classify,coeff,degree,removed,write,triples
from census import read,occupancy,profile
from contract import value

@cache
def decorated_key(code,decorations):
    m=occupancy(code)
    options=[]
    for order in permutations(range(3)):
        image=[sum(((v>>k)&1)<<order[k] for k in range(3)) for v in range(8)]
        labels=[triples.index(tuple(row[order.index(i)] for i in range(3))) for row in m]
        for shift in range(8):
            new=sum(label<<(6*(image[v]^shift)) for v,label in enumerate(labels))
            dec=tuple(sorted((tuple(sorted((image[a]^shift,image[b]^shift))),chi) for (a,b),chi in decorations))
            exchange=tuple((e,1-chi if chi!=2 else 2) for e,chi in dec)
            options.append((new,min(dec,exchange)))
    return min(options)

def terms(a,b,scalar=False):
    A,lA,eA=profile(a);B,lB,eB=profile(b)
    denom=prod(factorial(n) for t in occupancy(a)+occupancy(b) for n in t)
    overall=F(prod(coeff(n,0,0) for n in lA+lB),denom)
    edge_choices=[]
    for e in sorted(A.keys()|B.keys()):
        p=A.get(e,(0,0));q=B.get(e,(0,0))
        x=sum(eA.get(e,(0,0)));y=sum(eB.get(e,(0,0)))
        constant=prod(coeff(n,0,0) for n in p+q)
        if not (any(p) and any(q)):
            assert min(x,y)<4
            overall*=constant
        elif not (x or y):
            overall*=sum(prod(coeff(n,i,j) for n in p+q)/F(((2*i+1)*(2*j+1))**4) for i,j in product(range(3),repeat=2))
        else:
            edge=e[:2]
            assert x in (0,2) and y in (0,2)
            opts=[((),(),constant)]
            if x and y:
                assert p==q==(2,2)
                opts.extend((((edge,c),),((edge,c),),F(1,d**6)) for c,d in ((0,3),(1,3),(2,4)))
            elif x:
                assert p==(2,2)
                wt=prod(3*coeff(n,1,0) for n in q)/3**7
                opts.extend((((edge,c),),(),wt) for c in range(2))
            else:
                assert q==(2,2)
                wt=prod(3*coeff(n,1,0) for n in p)/3**7
                opts.extend(((),((edge,c),),wt) for c in range(2))
            edge_choices.append(opts[:1] if scalar else opts)
    out=Counter()
    for opts in product(*edge_choices):
        L=tuple(sorted(e for x,y,z in opts for e in x))
        R=tuple(sorted(e for x,y,z in opts for e in y))
        key=tuple(sorted((decorated_key(a,L),decorated_key(b,R))))
        out[key]+=overall*prod(z for x,y,z in opts)
    return out

def main():
    ordinary,overlap=classify()
    prior_pilot=(166856593410,8960795485785)
    chosen=[(a,b,w,channels) for a,b,w,channels in overlap if (a,b)!=prior_pilot]
    assert len(chosen)==75 and sum(r[2] for r in chosen)==5664
    both=sum(any(x and y for e,p,q,x,y in channels) for a,b,w,channels in chosen)
    assert both==24
    print("dual cases one-layer only",len(chosen)-both,"both-layer",both,flush=True)
    roster={(a,b):terms(a,b) for a,b,w,ch in chosen}
    cachekeys=sorted({key for d in roster.values() for pair in d for key in pair},key=lambda k:(len(k[1]),sum(c==2 for e,c in k[1]),k))
    assert (len(cachekeys),sum(map(len,roster.values())))==(25,274)
    print("configurations",len(cachekeys),"compressed weighted terms",sum(map(len,roster.values())),flush=True)
    tiled={ (170078605314,(((2,3),0),((4,5),0))), (170078605314,(((2,3),0),((4,5),1))) }
    data={}
    for key in cachekeys:
        if key in tiled:
            first=[value(*key,tile=(17,0,b)) for b in (0,1)]
            second=[value(*key,tile=(17,1,b)) for b in (0,1)]
            assert first==[F(2012212773,8388608),F(670737591,8388608)]
            assert sum(first)==sum(second)==F(670737591,2097152)
            data[key]=sum(first)
            print("two complete tilings",key,first,second,data[key],flush=True)
        else:data[key]=value(*key)
    products=[z for (a,s),z in data.items() if any(c==2 for e,c in s)]
    assert len(products)==7 and not any(products)
    control=(166856593410,(((2,3),0),((4,5),0)))
    normal=value(*control,reverse=True);wrong=value(*control,mutant=4)
    assert normal==F(820840149,2097152) and wrong!=normal
    print("two-adjoint reverse orientation control",normal,"wrong site",wrong,flush=True)
    def evaluate(rows):return sum(w*data[x]*data[y] for (x,y),w in rows.items())
    assert evaluate(terms(*prior_pilot))==F(52271073647433042742089,140737488355328)
    target=(166856593410,166856593410)
    assert evaluate(terms(*target))==F(3493001097617547990681,281474976710656)
    assert evaluate(terms(*target,True))==F(54576062567037718281,4398046511104)
    print("two-overlap full and scalar",evaluate(terms(*target)),evaluate(terms(*target,True)),flush=True)
    out=[(a,b,w,evaluate(roster[a,b])) for a,b,w,ch in chosen]
    assert all(z>0 for a,b,w,z in out)
    total=sum(w*z for a,b,w,z in out)
    assert total==F(1012068642997927782161928011277,1152921504606846976)
    print("exact 75 weighted subtotal",total,flush=True)
    write("exact.tsv",out)
    write("channels.tsv",[(a,s,z) for (a,s),z in data.items()])
if __name__=="__main__":main()
