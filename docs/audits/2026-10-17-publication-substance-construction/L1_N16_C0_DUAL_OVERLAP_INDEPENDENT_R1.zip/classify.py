from collections import Counter
from functools import cache
from fractions import Fraction as F
from itertools import permutations,product
from math import factorial,prod
from census import profile,occupancy,components,read,write,triples

degree="/private/tmp/l1-c0-degree-independent.nEpHYJlb"
q3="/private/tmp/l1-c0-q3-independent.t3DCmj20"
core="/private/tmp/l1-c0-core-independent.xCQTska6"
removed={tuple(map(int,r[1:3])) for r in read(degree+"/signed.tsv") if r[0]=="axis"}
for path in (q3+"/orbit-values.tsv",core+"/zeros.tsv",core+"/signed-orbits.tsv"):
    removed.update(tuple(map(int,r[:2])) for r in read(path))

# Recompute the class-function coefficients using fixed-norm
# orientation averages in each independent chirality.
L=(F(3,4),F(-1,4),F(0))
L2=(F(5,8),F(-5,16),F(1,16))
def coeff(n,p,q):
    if n==0:return int(p==q==0)
    if n==2:return F(4,3)*(L[p]*(q==0)+L[q]*(p==0))
    assert n==4
    return F(16,5)*(L2[p]*(q==0)+L2[q]*(p==0))+F(32,3)*L[p]*L[q]

@cache
def canonical(code):
    m=occupancy(code)
    candidates=[]
    for p in permutations(range(3)):
        dest=[triples.index(tuple(row[p.index(i)] for i in range(3))) for row in m]
        moved=[sum(((x>>i)&1)<<p[i] for i in range(3)) for x in range(8)]
        for shift in range(8):
            candidates.append(sum(c<<(6*(x^shift)) for x,c in zip(moved,dest)))
    return min(candidates)

def classify():
    ordinary=[]
    overlap=[]
    alive=Counter()
    for a,b,w in (map(int,r) for r in read(degree+"/orbits.tsv")):
        if (a,b) in removed:continue
        A,lA,eA=profile(a); B,lB,eB=profile(b)
        if any(s[1]!=1 for s in components(A)+components(B)):continue
        assert any(A) or any(B)
        assert all(n%2==0 for t in occupancy(a)+occupancy(b) for n in t)
        assert all(sum(d) in (2,4) and all(x%2==0 for x in d) for d in (*eA.values(),*eB.values()))
        alive["orbits"]+=1;alive["labels"]+=w
        weight=F(prod(coeff(n,0,0) for n in lA+lB),prod(factorial(n) for t in occupancy(a)+occupancy(b) for n in t))
        nontrivial=[]
        for e in A.keys()|B.keys():
            p=A.get(e,(0,0));q=B.get(e,(0,0))
            dA=sum(eA.get(e,(0,0)));dB=sum(eB.get(e,(0,0)))
            if any(p) and any(q):
                if dA or dB:nontrivial.append((e,p,q,dA,dB))
                else:
                    weight*=sum(prod(coeff(n,i,j) for n in p+q)/F(((2*i+1)*(2*j+1))**4)
                                for i,j in product(range(3),repeat=2))
            else:
                assert min(dA,dB)<4
                weight*=prod(coeff(n,0,0) for n in p+q)
        if nontrivial:overlap.append((a,b,w,tuple(nontrivial)))
        else:ordinary.append((a,b,w,weight))
    assert alive=={"orbits":808,"labels":67230},alive
    assert len(ordinary)==732 and sum(t[2] for t in ordinary)==61470
    assert len(overlap)==76 and sum(t[2] for t in overlap)==5760
    codes={code for a,b,w,f in ordinary for code in (a,b)}
    assert len(codes)==228 and len({canonical(c) for c in codes})==13
    print("isolated unresolved",dict(alive),"scalar admitted",len(ordinary),"scalar labels",sum(t[2] for t in ordinary),
          "overlap",len(overlap),"overlap labels",sum(t[2] for t in overlap),"layer codes",len(codes),"canonical layers",len({canonical(c) for c in codes}))
    write("overlap.tsv",overlap)
    return ordinary,overlap
