from collections import Counter
from functools import cache
from itertools import product
from pathlib import Path

spatial=[(u,u|(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
triples=[t for t in product(range(5),repeat=3) if sum(t)<=4]
def read(path):
    return (line.split() for line in Path(path).read_text().splitlines())

@cache
def occupancy(code):
    return tuple(triples[(code>>(6*i))&63] for i in range(8))

@cache
def profile(code):
    m=occupancy(code)
    active={(u,v,k):(m[u][k],m[v][k]) for u,v,k in spatial if m[u][k] or m[v][k]}
    leaves=[]
    while active:
        d=Counter(x for u,v,k in active for x in (u,v))
        remove=[e for e,(a,b) in active.items() if min(d[e[0]],d[e[1]])==1 and not(a and b)]
        if not remove: break
        for e in remove:
            n=sum(active.pop(e))
            assert n in (2,4)
            leaves.append(n)
    edges={}
    for u,v,k in spatial:
        counts=sum(m[u])-m[u][k],sum(m[v])-m[v][k]
        if any(counts):edges[u,v,k]=counts
    return active,tuple(leaves),edges

def gauge_zero(a,b):
    # Retain literal directed anchors and the actual four-dimensional
    # endpoint of each. The owner of a coframe may use either directed
    # spatial anchor even when all its occurrences are at one endpoint.
    p=(profile(a),profile(b))
    powers=Counter()
    directions=Counter()
    live=set()
    coframe=set()
    for t,(core,_,edges) in enumerate(p):
        for u,v,k in edges:
            coframe.update(((u|t*8,k),(v|t*8,k)))
        for (u,v,k),(m,n) in core.items():
            for root,power in ((u,m),(v,n)):
                if not power:continue
                x=root|t*8
                # Forward path: A, B, C dagger, D dagger.
                path=(x,x^8,x^8^(1<<k),x^(1<<k),x)
                word=((x,3),(x^8,k),(x^(1<<k),3),(x,k))
                for (anchor,axis),left,right in zip(word,path,path[1:]):
                    assert {anchor,anchor^(1<<axis)}=={left,right}
                live.update(word)
                powers[x]+=power
                directions[x]+=1
    for x,n in powers.items():
        if n%2 and directions[x]<=2 and not any(x in (site,site^(1<<k))
                                                 for site,k in coframe&live):
            return x,n,directions[x]
    return None

def components(core):
    groups={x:{x} for e in core for x in e[:2]}
    for u,v,k in core:
        comp=groups[u]|groups[v]
        for x in comp:groups[x]=comp
    out=[]
    for group in {tuple(sorted(c)) for c in groups.values()}:
        degrees=Counter(x for u,v,k in core if u in group for x in (u,v))
        out.append((len(group),sum(degrees.values())//2,tuple(sorted(degrees.values()))))
    return out

def write(path,rows):
    Path(path).write_text("".join("\t".join(map(str,row))+"\n" for row in rows))

def main():
    old=set()
    old.update(tuple(map(int,r[1:3])) for r in read("/private/tmp/l1-c0-degree-independent.nEpHYJlb/signed.tsv") if r[0]=="axis")
    old.update(tuple(map(int,r[:2])) for r in read("/private/tmp/l1-c0-q3-independent.t3DCmj20/orbit-values.tsv"))
    total=Counter()
    shape=Counter()
    zero=[]
    witness=[]
    candidates=[]
    for a,b,w in (map(int,r) for r in read("/private/tmp/l1-c0-degree-independent.nEpHYJlb/orbits.tsv")):
        if (a,b) in old:continue
        cA,lA,eA=profile(a);cB,lB,eB=profile(b)
        total["residual"]+=1;total["residual labels"]+=w
        shapes=components(cA)+components(cB)
        shape.update(shapes)
        iso=all(s[1]==1 for s in shapes)
        # Supports include the two rooted spatial anchors if both roots
        # occur. Cube edge disjointness is the frozen sufficient test.
        disjoint=not ((cA.keys()|cB.keys())&(eA.keys()|eB.keys()))
        if iso:total["isolated"]+=1;total["isolated labels"]+=w
        if disjoint:total["disjoint"]+=1;total["disjoint labels"]+=w
        proof=gauge_zero(a,b)
        if proof:
            zero.append((a,b,w))
            witness.append((a,b,w,*proof))
            if iso:total["isolated zero"]+=1
        if iso and disjoint and all(m%2==0 for p in occupancy(a)+occupancy(b) for m in p) and not any(x and y for x,y in (*eA.values(),*eB.values())):
            assert proof is None
            candidates.append((a,b,w))
    assert len(old)==34
    print("prior signed",len(old),"census",dict(total))
    print("common residual components",shape.most_common(3))
    print("exact zeros",len(zero),sum(r[2] for r in zero),"signed candidates",len(candidates),sum(r[2] for r in candidates))
    print("residual",total["residual"]-len(zero)-len(candidates),
          total["residual labels"]-sum(r[2] for r in zero+candidates))
    write("zeros.tsv",zero);write("zero-witnesses.tsv",witness);write("candidates.tsv",candidates)

if __name__=="__main__":
    main()
