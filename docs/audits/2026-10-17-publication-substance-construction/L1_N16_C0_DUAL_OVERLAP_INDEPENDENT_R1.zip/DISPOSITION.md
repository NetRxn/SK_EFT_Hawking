# Scoped independent acceptance

The replay verifies all 75 remaining isolated cases and the complete 816-orbit table. The 10,994-orbit temporal residual and full c0 remain open.
