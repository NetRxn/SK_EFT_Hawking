from fractions import Fraction as F
from contract import value
z=value(166856593410,(((2,3),1),((4,5),1)))
assert z==F(820840149,2097152)
w=value(166856593410,(((2,3),0),((4,5),0)),mutant=4)
assert w==F(132617493,2097152)
print("global chirality exchange verified",z,"adverse one-site omission",w)
