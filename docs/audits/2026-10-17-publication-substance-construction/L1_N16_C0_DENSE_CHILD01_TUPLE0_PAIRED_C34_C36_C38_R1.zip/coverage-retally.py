from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re
import sys
from zipfile import ZipFile

release=Path(sys.argv[1])
bundle=Path(__file__).resolve().parent
base='L1_N16_C0_DENSE_CHILD01_'
heavy=base+'TUPLE0_PAIRED_HEAVY47_R1.zip'
pilot=base+'TUPLE1_COMPLETE_AND_PAIRED_PILOT_R1.zip'
early={
    0:(pilot,'paired-case0/paired-combined-replay.out'),
    23:(base+'TUPLE0_PAIRED_MIDDLE23_R1.zip','author/inner/author-case23.tsv'),
    24:(base+'TUPLE0_PAIRED_C24_C32_R1.zip','author/24/author-case24.tsv'),
    28:(base+'TUPLE0_PAIRED_C28_R1.zip','author/inner/author-case28.tsv'),
    25:(base+'TUPLE0_PAIRED_NEIGHBORS_R1.zip','author/25/author-case25.tsv'),
    29:(base+'TUPLE0_PAIRED_NEIGHBORS_R1.zip','author/29/author-case29.tsv'),
    30:(base+'TUPLE0_PAIRED_NEIGHBORS_R1.zip','author/30/author-case30.tsv'),
    31:(base+'TUPLE0_PAIRED_NEIGHBORS_R1.zip','author/31/author-case31.tsv'),
    32:(base+'TUPLE0_PAIRED_C24_C32_R1.zip','author/32/author-case32.tsv'),
    26:(base+'TUPLE0_PAIRED_C26_C27_C33_C35_R1.zip','author/26/author-case26.tsv'),
    27:(base+'TUPLE0_PAIRED_C26_C27_C33_C35_R1.zip','author/27/author-case27.tsv'),
    33:(base+'TUPLE0_PAIRED_C26_C27_C33_C35_R1.zip','author/33/author-case33.tsv'),
    35:(base+'TUPLE0_PAIRED_C26_C27_C33_C35_R1.zip','author/35/author-case35.tsv'),
    47:(heavy,'author/pair/heavy47-inner/author-case47.tsv'),
}
with ZipFile(release/heavy) as archive:
    _,labels=literal_eval(archive.read('author/tuple0-branch0-pilot/pilot.roster').decode())
ordered=sorted(labels,key=lambda row:(row[1],row[0]))
assert len(ordered)==len(dict(ordered))==48 and sum(n for _,n in ordered)==6_427_904

def sum_ledger(text):
    rows=[line.split('\t') for line in text.splitlines()]
    assert len(rows)==10 and rows[-1][0]=='sum'
    assert len({row[1] for row in rows[:-1]})==9
    components = [sum(Fraction(row[i]) for row in rows[:-1]) for i in (3,4)]
    assert components==[Fraction(v) for v in rows[-1][1:]]
    return components

records={}
for index,(archive_key,path) in early.items():
    with ZipFile(release/archive_key) as archive:
        receipt=archive.read(path).decode()
    if index==0:
        [(real,imaginary)]=re.findall(r'^exact normalized real (\S+) imaginary (\S+)', receipt,re.M)
        values=[Fraction(real),Fraction(imaginary)]
    else:
        values=sum_ledger(receipt)
    records[index]=(*values,f'{archive_key}:{path}')
for index in (34,36,38):
    tag=f'author/{index}/author-case{index}.tsv'
    records[index]=(*sum_ledger((bundle/tag).read_text()),tag)

print('outer_cut','coordinate','pair_products_one_branch','disposition','real','imaginary','evidence',sep='\t')
for index,(coordinate,products) in enumerate(ordered):
    fields=('accepted',*records[index]) if index in records else ('open','','','')
    print(index,repr(coordinate),products,*fields,sep='\t')
real=sum(r[0] for r in records.values())
imaginary=sum(r[1] for r in records.values())
print('PARTIAL_SUM','','',f'{len(records)}/48',real,imaginary,'accepted cuts only',sep='\t')
