from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import re
import shutil
import subprocess
import sys
from time import perf_counter, sleep

outer=int(sys.argv[1])
author=Path(f'/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe{outer}-inner')
parent=author.parent/f'row-cap-physical-slice-dense-label-sum{outer}-reduced.pkl'
cwd = Path.cwd()
scripts = ('exact-multicut.py', 'reduce-label-frontier.py', 'contract-reduced-label.py',
           'contract-peer.py', 'peer_pair.py', 'checkpoint/quotient.py')
def outcome(receipt):
    stop=perf_counter()+250
    while perf_counter()<stop:
        if receipt.exists() and (lines:=receipt.read_text().splitlines()):
            if lines[-1].startswith('exact normalized real '):
                return 0
            if lines[-1].startswith('open ') and lines[-1].endswith('frontier saved'):
                return 2
        sleep(1)
    raise RuntimeError(f'Author stage did not settle: {receipt}')

def check_file(actual, original):
    assert sha256(actual.read_bytes()).digest() == sha256(original.read_bytes()).digest(), actual

def verify(i):
    scratch = cwd/f'lineage-{i}'
    scratch.mkdir()
    (scratch/'checkpoint').mkdir()
    for name in scripts:
        shutil.copyfile(author/name, scratch/name)

    def invoke(program, args, log, exit_code=0, original=None):
        start = perf_counter()
        with (scratch/log).open('xb') as out:
            p = subprocess.run([sys.executable, '-u', program, *args], cwd=scratch,
                               stdout=out, stderr=subprocess.STDOUT, timeout=180)
        duration = perf_counter() - start
        with (scratch/'stage-timing.tsv').open('a') as out:
            print(i, log, p.returncode, f'{duration:.6f}', sep='\t', file=out)
        assert p.returncode==exit_code,(i,program,args,p.returncode)
        check_file(scratch/log,author/(original or log))

    def checked(name):
        check_file(scratch/name, author/name)

    tag = f'slice-{i}'
    initial = tag + '.pkl'
    invoke('exact-multicut.py',[str(parent),initial,str(i)],tag+'-plan.out')
    checked(initial)
    checked(tag+'.roster')
    stages = []
    while True:
        invoke('reduce-label-frontier.py',[initial,tag],tag+'-reduce.out')
        checked(f'label-{tag}-reduced-frontier.pkl')
        receipt = tag+'-contract.out'
        status=outcome(author/receipt)
        terminal=status==0
        program = 'contract-peer.py' if tag.startswith('rescue') else 'contract-reduced-label.py'
        invoke(program,[tag],receipt,exit_code=status)
        stages.append((tag, (scratch/receipt).read_text().splitlines()[-1]))
        if terminal:
            break
        saves = list(scratch.glob(f'*-dense-label-{tag}-reduced.pkl'))
        assert len(saves)==1,(i,tag,saves)
        initial = saves[0].name
        checked(initial)
        if tag==f'rescue-{i}-1':
            break
        tag=f'rescue-{i}-{len(stages)-1}'
    return i, stages

with ThreadPoolExecutor(max_workers=2) as pool:
    for index, stages in pool.map(verify,map(int,sys.argv[2:])):
        for tag, end in stages:
            print(index, tag, 'byte-identical', end, sep='\t', flush=True)
