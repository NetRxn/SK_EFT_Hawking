from csv import DictReader
from hashlib import sha256
from pathlib import Path
from pickle import loads

current=Path.cwd()
previous=Path('/private/tmp/l1-paired34-independent.VFqIyv')
author=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
for pattern in ('combined-{}.pkl','row-cap-physical-slice-dense-label-sum{}-reduced.pkl'):
    snapshots=[]
    for index in (34,38):
        raw=(author/pattern.format(index)).read_bytes()
        state=loads(raw)
        x=dict(state['conditioning'])
        coordinate=(x['G',0,4,2],x['J',1,4,2])
        assert coordinate==({34:36,38:68}[index],(1,))
        snapshots.append((state,sha256(raw).hexdigest()))
    diff=[i for i,(a,b) in enumerate(zip(snapshots[0][0]['factors'],snapshots[1][0]['factors'],strict=True)) if a!=b]
    assert diff and snapshots[0][1]!=snapshots[1][1]
    print('PASS independent source distinction',pattern,snapshots[0][1],snapshots[1][1],'differing factor tables',diff)
old=(previous/'signed-ledger.tsv').read_bytes()
manifest={name:h for h,name in map(str.split,(previous/'review-manifest.sha256').read_text().splitlines())}
assert sha256(old).hexdigest()==manifest['signed-ledger.tsv']
with (current/'signed-ledger.tsv').open() as file:
    new=list(DictReader(file,delimiter='\t'))
before=list(DictReader(old.decode().splitlines(),delimiter='\t'))
assert len(before)==len(new)==10 and before[-1]['slice']==new[-1]['slice']=='subtotal'
assert all(before[-1][field]==new[-1][field] for field in ('norm_real','norm_imaginary'))
print('PASS prior cut 34 scalar equality with distinct factor tables and independent scope')
