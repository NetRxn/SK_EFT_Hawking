from ast import literal_eval
from collections import Counter
from itertools import combinations
from pickle import loads

def plans(base):
    result={}
    for line in (base/'terminal-plan.tsv').read_text().splitlines():
        i,name,program,pair,counts=line.split('\t')
        i=int(i)
        assert i not in result
        pair=literal_eval(pair)
        counts=literal_eval(counts)
        assert program in ('triangle-shards.py','close-four-shards.py')
        triangle=program=='triangle-shards.py'
        path=base/name
        state=loads(path.read_bytes())
        assert len(state['factors'])==(3 if triangle else 4)
        assert (bool(pair),bool(counts))==(not triangle,not triangle)
        result[i]=(path,triangle,pair,counts,state)
    return result


def forecast(factors,pair):
    a,A,_=factors[pair[0]]
    b,B,_=factors[pair[1]]
    common=tuple(sorted(set(a)&set(b)))
    if not common:
        return None
    ai=[a.index(w) for w in common]
    bi=[b.index(w) for w in common]
    counts=Counter(tuple(row[p] for p in bi) for row in B)
    return sum(counts[tuple(row[p] for p in ai)] for row in A)

def alternate_pair(factors,author_pair):
    preferred=(1,2)
    if author_pair!=preferred and forecast(factors,preferred) is not None:
        return preferred
    candidates=[(count,pair) for pair in combinations(range(len(factors)),2)
                if pair!=author_pair and (count:=forecast(factors,pair)) is not None]
    return min(candidates)[1]
