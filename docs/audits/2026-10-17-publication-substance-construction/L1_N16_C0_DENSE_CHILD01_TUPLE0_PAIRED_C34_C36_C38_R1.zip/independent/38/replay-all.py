from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run
from sys import argv, executable, stderr
from time import perf_counter
from terminal_plan import alternate_pair, plans

outer=int(argv[1])
root=Path(__file__).resolve().parent
base=Path(f'/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe{outer}-inner')
terminal=plans(base) if (base/'terminal-plan.tsv').exists() else {}
indices=tuple(map(int,argv[2:]))
routes={}
for index in indices:
    if index in terminal:
        routes[index]='triangle' if terminal[index][1] else 'four'
        continue
    logs=sorted(p for pattern in (f'slice-{index}-contract.out',f'rescue-{index}-*-contract.out')
                for p in base.glob(pattern)
                if p.read_text().splitlines()[-1].startswith('exact normalized real '))
    [finished]=logs
    routes[index]=finished.name.removesuffix('-contract.out')

def review(index):
    route=routes[index]
    started=perf_counter()
    if route in ('triangle','four'):
        source,is_triangle,author_pair,counts,checkpoint=terminal[index]
        coordinate=dict(checkpoint['conditioning'])['G',0,1,2]
        command=[str(root/f'{route}.py'),str(index),str(source),str(coordinate)]
        if not is_triangle:
            pair=alternate_pair(checkpoint['factors'],author_pair)
            assert pair!=author_pair
            print(f'slice {index} alternate pair {pair}',file=stderr,flush=True)
            command=[str(root/'four.py'),str(outer),str(index),str(source),str(coordinate),
                     '--pair',*map(str,pair)]
        destination=Path(f'slice-{index}-{route}-replay.out')
        with destination.open('xb') as log:
            proc=run([executable,'-B','-u',*command],stdout=log,stderr=log,check=True,timeout=200)
        return index,route,proc.returncode,f'{perf_counter()-started:.6f}'
    state=base/f'label-{route}-reduced-frontier.pkl'
    receipt=base/f'{route}-contract.out'
    for method in ('sparse','sparse-support'):
        command_started=perf_counter()
        with Path(f'slice-{index}-{method}-replay.out').open('xb') as log:
            proc=run([executable,'-B','-u',str(root/f'{method}-replay.py'),
                      str(index),'0',str(state),str(receipt)],stdout=log,stderr=log,
                     check=False,timeout=180)
        elapsed=perf_counter()-command_started
        if proc.returncode==0:
            Path(f'slice-{index}-replay.out').write_bytes(Path(f'slice-{index}-{method}-replay.out').read_bytes())
            return index,method,proc.returncode,f'{elapsed:.6f}'
    raise ValueError(index)

with ThreadPoolExecutor(max_workers=2) as workers:
    for row in workers.map(review,indices):
        print(*row,sep='\t',flush=True)
