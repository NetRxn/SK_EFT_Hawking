# Independent review of paired outer coordinate 38

The independently verified signed contribution of outer coordinate `(68,(1,))` in group128 descendant `(0,1)`, tuple 0 is `-311265394132600099496295/2596148429267413814265248164610048 + 0i`. The raw Gaussian subtotal is `(-26445198790954304951846478545540345876869910333702713327107440640,0)` over factor denominator `40512224221827380280140849737629696`. The common positive external normalization `1/(16*4^64)` is applied once. This acceptance covers outer coordinate 38. The verified scalar equals cut 34’s value. Their combined and capped inputs have different original factor tables even with conditioning metadata excluded.

The named continuity revision matched publication checkpoint `4a9856d5fc26550069dd6a07a08cc35633550436`. The two disjoint binary-selector inputs use the accepted hashes and share six environment factors. The independent census recovers all 48 coordinates and 6,427,904 compatible products per original branch. A condition-first signed constructor indexed the opposite factor and reconstructed every one of the seven combined tables using 177,240 products per branch. Their sum has 128,880 retained pair rows. The original constructor, outer reduction and refusal reproduced byte for byte. The combined input SHA-256 is `5f0b664f5d16151fb20c7df948e68598dd1a6c2367658efef57713005cb96784` and the retained cap SHA-256 is `4529ee5c76eb22d4012f2970d85b86eefc84cbcb79cdd5c556de6321484dbd25`. Independent reconstruction took 2.48 s. Constructor, reduction and refusal readbacks took 2.019, 9.851 and 3.343 s wall respectively.

The inner census recovered nine disjoint coordinates with 2,001,024 compatible products. Every exact inverse lift recovered the original conditioned rows, keys, axes, signed Gaussian coefficients and denominators. The 5 generic terminals were verified with independent sparse Gaussian contraction. Triangles in slices 2 and 3 used alternate pivot 1, and four-factor slices 7 and 8 used alternate pair (1,2). The author used pivot 0 and pair (1,3), respectively. All 32 author shard receipts passed exact interval coverage, independent candidate-work counts and signed raw arithmetic reconciliation. The signed ledger gives the route, raw value, projected work and observed work per slice.

The 53 generic inner commands across 22 stages reproduced each log and saved checkpoint byte, preserving all 17 refusals. Their summed wall duration was 266.400754 s under concurrent execution. The independent terminal replays used 96,397,296 products and 63.1252 summed wall seconds. The author terminal receipts record 134,500,151 products. Terminal work totals exclude generic work performed before a refusal. The signed ledger and timing tables preserve per-slice measurements.

Verify the portable receipts from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c review-manifest.sha256
python3 -B tools/ledger-metrics.py 38 | cmp - signed-ledger.tsv
python3 -B tools/summarize.py | cmp - summary.out
```

The three operand inventories bind the original binary and text files on the author scratch path. Full recalculation of the binary lineage requires those pinned files. The portable manifest contains the selected receipts, hashes, timings, authority checks and review scripts.
