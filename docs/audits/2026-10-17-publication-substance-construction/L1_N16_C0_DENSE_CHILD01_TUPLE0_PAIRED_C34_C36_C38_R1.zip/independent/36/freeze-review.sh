#!/usr/bin/env bash
set -euo pipefail
find author-receipts -type f -print | LC_ALL=C sort > portable-paths.list
find . -maxdepth 1 -type f -print | sed -e 's|^\./||' | awk '$0 !~ /^(portable-paths.list|review-manifest.sha256|review-manifest-verify.out|report-prefix.md|seeds-first.tsv)$/' | LC_ALL=C sort >> portable-paths.list
while IFS= read -r path; do shasum -a 256 "$path"; done < portable-paths.list > review-manifest.sha256
shasum -a 256 -c review-manifest.sha256 > review-manifest-verify.out
