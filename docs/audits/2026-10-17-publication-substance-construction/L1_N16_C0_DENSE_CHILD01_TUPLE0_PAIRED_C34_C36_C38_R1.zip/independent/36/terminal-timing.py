from pathlib import Path
import re

print('slice\tmethod\tproducts\tseconds\treceipt')
for i in range(9):
    if i in (2,3):
        method='triangle pivot 1'
        filename=f'slice-{i}-triangle-replay.out'
        metric=r'^independent pivot 1 .* Gaussian products (\d+) wall seconds (\S+)$'
    elif i in (7,8):
        method='four-factor pair 1,2'
        filename=f'slice-{i}-four-replay.out'
        metric=r'^complete shards .* total products (\d+) total probes \d+ seconds (\S+)$'
    else:
        method='plain sparse'
        filename=f'slice-{i}-replay.out'
        metric=r'^exact normalized real .* independent matched products (\d+) wall seconds (\S+)$'
    products,seconds=re.search(metric,Path(filename).read_text(),re.M).groups()
    print(i,method,products,seconds,filename,sep='\t')
