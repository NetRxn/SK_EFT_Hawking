from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle

author=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe36-inner')
for index in (7, 8):
    path=author/f'row-cap-physical-slice-dense-label-rescue-{index}-1-reduced.pkl'
    factors=pickle.loads(path.read_bytes())['factors']
    for a,b in combinations(range(len(factors)),2):
        axes_a, rows_a, _=factors[a]
        axes_b, rows_b, _=factors[b]
        shared=sorted(set(axes_a) & set(axes_b))
        positions_a=tuple(axes_a.index(k) for k in shared)
        positions_b=tuple(axes_b.index(k) for k in shared)
        counts=Counter(tuple(row[j] for j in positions_b) for row in rows_b)
        matched=sum(counts[tuple(row[j] for j in positions_a)] for row in rows_a)
        print(index,(a,b),matched)
