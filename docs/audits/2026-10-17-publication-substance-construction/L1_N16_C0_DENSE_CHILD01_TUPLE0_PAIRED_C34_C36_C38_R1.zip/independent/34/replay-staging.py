from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run
from sys import argv, executable

base=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe34-inner')
procedures={0:'rescue-0-0',1:'slice-1',2:'triangle',3:'triangle',
            4:'rescue-4-0',5:'rescue-5-0',6:'rescue-6-1',
            7:'four',8:'four'}

def review(i):
    route=procedures[i]
    if route in ('triangle','four'):
        args=[str(i)] if route=='triangle' else ['34',str(i),'--pair','1','2']
        with Path(f'slice-{i}-{route}-replay.out').open('w') as out:
            proc=run([executable,'-B','-u',f'{route}.py',*args],stdout=out,check=True,timeout=180)
        return i, route, proc.returncode
    state=base/f'label-{route}-reduced-frontier.pkl'
    receipt=base/f'{route}-contract.out'
    for method in ('sparse','sparse-support'):
        with Path(f'slice-{i}-{method}-replay.out').open('w') as out:
            proc=run([executable,'-B','-u',f'{method}-replay.py',str(i),'0',str(state),str(receipt)],stdout=out,check=False,timeout=120)
        if proc.returncode==0:
            Path(f'slice-{i}-replay.out').write_bytes(Path(f'slice-{i}-{method}-replay.out').read_bytes())
            return i, method, proc.returncode
    raise ValueError(i)

with ThreadPoolExecutor(max_workers=3) as workers:
    for row in workers.map(review,map(int,argv[1:]) if argv[1:] else procedures):
        print(*row,sep='\t',flush=True)
