from ast import literal_eval
from hashlib import sha256
from pathlib import Path
from pickle import loads

source=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe34-inner')
rows={}
for row in (source/'terminal-plan.tsv').read_text().splitlines():
    i, filename, script, route, counts = row.split('\t')
    if i in ('2','3'):
        assert filename==f'join-cap-dense-label-rescue-{i}-1-reduced.pkl'
        assert script=='triangle-shards.py' and literal_eval(route)==literal_eval(counts)==()
    else:
        assert i in ('7','8') and filename==f'row-cap-physical-slice-dense-label-rescue-{i}-1-reduced.pkl'
        assert script=='close-four-shards.py' and literal_eval(route)==(1,3)
        partition=literal_eval(counts)
        assert len(partition)==8 and sum(partition)==4704000
    assert i not in rows
    rows[i]=filename
assert set(rows)=={'2','3','7','8'}
seen=set()
print('slice','inner_coordinate','terminal_file','sha256','factors','stored_rows',sep='\t')
for row in (source/'author-case34.tsv').read_text().splitlines()[:-1]:
    i, coordinate, _, _, _, receipt = row.split('\t')
    if i in rows:
        assert receipt==f'slice-{i}-shard-sum.out'
        name=rows[i]
    else:
        assert receipt.endswith('-contract.out')
        name=f'label-{receipt.removesuffix("-contract.out")}-reduced-frontier.pkl'
    raw=(source/name).read_bytes()
    digest=sha256(raw).hexdigest()
    assert digest not in seen
    seen.add(digest)
    state=loads(raw)
    fixed=dict(state['conditioning'])
    assert (fixed['G',0,4,2],fixed['J',1,4,2],fixed['G',0,1,2])==(36,(1,),int(coordinate))
    print(i,coordinate,name,digest,len(state['factors']),sum(len(r) for _,r,_ in state['factors']),sep='\t')
assert len(seen)==9
