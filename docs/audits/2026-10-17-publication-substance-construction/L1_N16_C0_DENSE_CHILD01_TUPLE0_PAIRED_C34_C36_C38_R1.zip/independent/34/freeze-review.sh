#!/usr/bin/env bash
set -euo pipefail
python3 -B freeze-inputs.py
shasum -a 256 -c paired-operands.sha256 > paired-operands-verify.out
shasum -a 256 -c inner-operands.sha256 > inner-operands-verify.out
cat replay-{primary,rescue-early,rescue-final}.tsv | sort -k1,1n > replay-jobs.tsv
test "$(wc -l < replay-jobs.tsv | tr -d ' ')" = 9
python3 -B audit.py > audit.out
python3 -B verify-shard-coverage.py > shard-coverage.out
python3 -B audit-shard-raw.py > shard-raw-ledger.tsv
test "$(wc -l < shard-raw-ledger.tsv | tr -d ' ')" = 33
python3 -B ledger-metrics.py > signed-ledger.tsv
python3 -B terminal-inventory.py > terminal-inventory.tsv
for attempt in {1..90}; do
  test ! -s lineage-rescue-errors.out
  if [ "$(wc -l < lineage-rescue.tsv | tr -d ' ')" = 21 ]; then break; fi
  sleep 1
done
test "$(wc -l < lineage-rescue.tsv | tr -d ' ')" = 21
cat lineage-{primary,rescue}.tsv | sort -s -k1,1n > lineage.tsv
cat lineage-*/stage-timing.tsv | sort -k1,1n > lineage-stage-timing.tsv
python3 - <<'PY'
from pathlib import Path
from csv import DictReader
rows=[line.split('\t') for line in Path('lineage-stage-timing.tsv').read_text().splitlines()]
assert len(rows)==53 and sum(row[2]=='2' for row in rows)==17
assert len(Path('lineage.tsv').read_text().splitlines())==22
assert all(not p.read_text() for p in Path('.').glob('*-errors.out'))
with Path('signed-ledger.tsv').open() as data:
    signed=[row for row in DictReader(data,delimiter='\t') if row['slice']!='subtotal']
assert len(signed)==9
with Path('REVIEW.md').open('a') as report:
    independent=sum(int(row['review_products']) for row in signed)
    author=sum(int(row['author_terminal_products']) for row in signed)
    seconds=sum(float(row['review_wall_seconds']) for row in signed)
    print(f'\n**Pass.** All nine signed terminals match. All 32 original shard intervals, exact raw pairs and normalized values also match independent arithmetic. Independent terminal schedules took {seconds:.4f} summed seconds and used {independent:,} Gaussian products. The author terminal summaries record {author:,} products, with refusal work accounted for separately.',file=report)
    print(f'\nAll 53 commands for the 22 inner stages reproduced every log and saved checkpoint byte, including 17 documented refusals and five generic terminals. The sum of elapsed command times was {sum(float(row[-1]) for row in rows):.3f} seconds across concurrent replay workers.',file=report)
PY
{
  find author-receipts -type f
  printf '%s\n' *.py *.sh *.out *.tsv *-operands.sha256 REVIEW.md continuity.json continuity-readback.json pin-sources.py source-pins.out
} | awk '!/^review-manifest/' | LC_ALL=C sort -u | xargs shasum -a 256 > review-manifest.sha256
shasum -a 256 -c review-manifest.sha256 > review-manifest-verify.out
shasum -a 256 review-manifest.sha256
wc -l review-manifest.sha256
tail -1 signed-ledger.tsv
