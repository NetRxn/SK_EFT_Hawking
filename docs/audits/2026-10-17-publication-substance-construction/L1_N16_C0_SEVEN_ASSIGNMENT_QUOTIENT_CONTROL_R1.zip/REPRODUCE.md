# L1 seven-assignment signed factor contraction

Run `python3 verify-branches.py signed-reference.tsv` to verify the four
branch values against the independently reviewed original terms. The
partition fixes one representation axis and covers all seven assignments,
including three fixed points. The full exact value agrees with the accepted
reference coefficient.

For the two branches that hit the row cap, the quotient groups proportional
slices of closed physical indices. It scopes every equivalence class to
the retained boundary label values. Complex phase and integer scale are
transported to the other factor. The included literal Gaussian control
checks the transformation without a change across boundary labels.
Two sweeps reduced the two saved frontiers from 408,900 to 2,142 rows
and from 526,604 to 2,300 rows. Exact contractions then closed both.

This method control uses a coefficient already counted in the accepted
residual. Dense-profile numerical acceptance remains open.
