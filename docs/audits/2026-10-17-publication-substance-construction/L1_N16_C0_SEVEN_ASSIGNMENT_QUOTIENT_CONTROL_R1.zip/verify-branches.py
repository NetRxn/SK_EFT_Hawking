from pathlib import Path
from fractions import Fraction
from collections import defaultdict
from ast import literal_eval
from math import prod
import sys

profile=Path('164324020825-1884419784715-tiled')
states=defaultdict(dict,{int(l.split()[0]):{} for l in (profile/'anchor-plan.tsv').read_text().splitlines()})
for line in (profile/'states.tsv').read_text().splitlines():
    i,t,x,k,p,q=map(int,line.split())
    states[i][t,x,k]=(p,q)
a,b,w,expected=Path('reference.tsv').read_text().split()
signed={}
for line in Path(sys.argv[1]).read_text().splitlines():
    x,y,i,left,right,mult,tag,value=line.split()
    if (x,y)==(a,b):
        for case in {int(left),int(right)}:
            assert case not in signed
            signed[case]=Fraction(value)
        assert len({left,right})==int(mult)
assert set(signed)==set(states)
axis=(0,1,1)
branches=sorted({s.get(axis,(0,0)) for s in states.values()})
assert len(branches)==4
paths=['resume-saturated.out','bounded-branch-1.out','resume-saturated-2.out','bounded-branch-3.out']
total=Fraction()
ok=0
for i,(branch,path) in enumerate(zip(branches,paths)):
    have=Path(path)
    known=[j for j,state in states.items() if state.get(axis,(0,0))==branch]
    ref=sum(signed[j] for j in known)
    if not have.is_file():
        continue
    final=have.read_text().splitlines()[-1].split()
    if final[:2]!=['exact','normalized']:
        continue
    value=Fraction(final[2])
    assert value==ref,(i,value,ref)
    print('verified branch',i,'labels',branch,'cases',known,'exact',value)
    total+=value
    ok+=1
if ok==4:
    assert total==Fraction(expected)
    print('verified full seven-assignment coefficient',total)
