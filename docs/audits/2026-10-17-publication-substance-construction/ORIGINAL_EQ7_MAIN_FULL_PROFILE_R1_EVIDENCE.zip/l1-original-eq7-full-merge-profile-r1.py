from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

primary = Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
candidate = Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking')
expected = 'a56e6a644e2520a1891e70c607dbc98d13615062'
prefix = Path('/tmp/l1-original-eq7-full-merge-profile-r1')
assert not prefix.with_suffix('.invocation.json').exists()
sys.path.insert(0, str(primary / 'scripts'))
from lean_slots.state import Inventory, directory_lock

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

assert Path.cwd() == primary
assert git(candidate, 'rev-parse', 'HEAD') == expected
assert not git(candidate, 'status', '--porcelain')
assert git(primary, 'rev-parse', 'HEAD') == '056ccb9f08454238934977de4bb6548d18c6275e'
inventory = Inventory.load()
assert inventory.repo_root.resolve() == primary.resolve()
env = dict(os.environ, UV_PROJECT_ENVIRONMENT=str(primary / '.venv'), UV_NO_SYNC='1',
           PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1', PYTEST_ADDOPTS='--junitxml=/tmp/l1-original-eq7-full-profile-pytest-r1.xml')
argv = ['/Users/johnroehm/.local/bin/uv', 'run', 'python',
        str(candidate / 'scripts/verify_scope.py'), '--merge-gate']
receipt = {'candidate': expected, 'primary': git(primary, 'rev-parse', 'HEAD'),
           'argv': argv, 'launch_cwd': str(primary), 'inventory': str(inventory.source),
           'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'scope': 'Existing standalone full profile; no shared-slot epoch or publication acceptance',
           'environment': {k:env[k] for k in ['UV_PROJECT_ENVIRONMENT','UV_NO_SYNC','PYTHONDONTWRITEBYTECODE']},
           'pins': {p:hashlib.sha256((candidate/p).read_bytes()).hexdigest() for p in
                    ['scripts/verify_scope.py','lean/lean-toolchain','lean/lake-manifest.json','pyproject.toml','uv.lock']}}
for role, root in [('candidate',candidate), ('primary',primary)]:
    receipt[role+'_lake'] = str((root/'lean/.lake').resolve())
assert receipt['candidate_lake'] != receipt['primary_lake']
assert not (candidate/'lean/.lake').is_symlink()
assert all(p.resolve().is_relative_to(candidate / 'lean/.lake') for p in (candidate/'lean/.lake/packages').iterdir())
with directory_lock(inventory.state_root/'locks/authoritative-build.lock', purpose='ROOT focused original Eq7 actual-main complete merge qualification'):
    procs = subprocess.check_output(['ps','-axo','pid=,ppid=,ucomm=,args='],text=True)
    competing=[]
    for line in procs.splitlines():
        parts=line.strip().split(None,3)
        if len(parts)!=4 or int(parts[0])==os.getpid(): continue
        name=parts[2].lower(); args=parts[3]
        if name in {'lean','lake','leanc'} or (name.startswith('python') and
                ('verify_scope.py' in args or 'extract_lean_deps.py' in args or 'slotctl.py build' in args)):
            competing.append(line.strip())
    receipt['competing_build_processes']=competing
    assert not competing, 'Competing build/extraction process; no run started'
    probe = 'import json,sys,src.core.formulas as f,src.wkb.spectrum as s; print(json.dumps({"executable":sys.executable,"formulas":f.__file__,"spectrum":s.__file__}))'
    obs=subprocess.run(['/Users/johnroehm/.local/bin/uv','run','python','-B','-c',probe],cwd=candidate,env=env,capture_output=True,text=True)
    receipt['origin_probe']={'rc':obs.returncode,'stdout':obs.stdout,'stderr':obs.stderr}
    assert obs.returncode==0, obs.stderr
    origins=json.loads(obs.stdout)
    assert all(Path(origins[k]).resolve().is_relative_to(candidate) for k in ['formulas','spectrum'])
    prefix.with_suffix('.invocation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('STARTED exact candidate '+expected,flush=True)
    with prefix.with_suffix('.stdout').open('w') as out, prefix.with_suffix('.stderr').open('w') as err:
        result=subprocess.run(argv,cwd=primary,env=env,stdout=out,stderr=err)
    receipt.update(returncode=result.returncode, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   candidate_head_after=git(candidate,'rev-parse','HEAD'), candidate_status_after=git(candidate,'status','--porcelain'))
    prefix.with_suffix('.result.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('TERMINAL returncode='+str(result.returncode),flush=True)
sys.exit(result.returncode)
