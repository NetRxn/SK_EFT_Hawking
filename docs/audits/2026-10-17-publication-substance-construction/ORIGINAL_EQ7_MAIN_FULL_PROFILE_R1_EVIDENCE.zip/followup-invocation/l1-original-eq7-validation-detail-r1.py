from pathlib import Path
import os,sys,subprocess,json,hashlib,datetime
p=Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking');primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');prefix=Path('/tmp/l1-original-eq7-validation-detail-r1')
def git(*a):return subprocess.check_output(['git',*a],cwd=p,text=True).strip()
assert git('rev-parse','HEAD')=='a56e6a644e2520a1891e70c607dbc98d13615062'
f=p/'docs/.test_missing_stubs.json';assert hashlib.sha256(f.read_bytes()).hexdigest()=='0891b617824dd9865905de2f87d2dc8cb1952186de1da69ffba423d872daae6c'
assert Path('/tmp/l1-original-eq7-full-profile-terminal-r1.zip').is_file()
f.unlink();assert not git('status','--porcelain')
sys.path.insert(0,str(primary/'scripts'));from lean_slots.state import Inventory,directory_lock
inv=Inventory.load();assert inv.repo_root.resolve()==primary.resolve()
env=dict(os.environ,UV_PROJECT_ENVIRONMENT=str(primary/'.venv'),UV_NO_SYNC='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1');env.pop('PYTEST_ADDOPTS',None);env.pop('PYTHONPATH',None)
legs=[('ci',['--ci','--no-memo']),('freshness',['--check','counts_fresh','--check','tables_fresh','--check','claim_clusters_fresh','--check','notebook_exec','--no-memo'])]
r={'candidate':git('rev-parse','HEAD'),'scope':'Detailed rerun of failed validation legs only because existing full profile captures/discards detailed subprocess output; full pytest/native not repeated','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'residue_preserved_and_removed':True,'legs':[]}
Path(str(prefix)+'.invocation.json').write_text(json.dumps(r,indent=2)+'\n')
with directory_lock(inv.state_root/'locks/authoritative-build.lock',purpose='ROOT detailed failed validation-leg intake'):
 for name,args in legs:
  argv=[str(primary/'.venv/bin/python'),'-B',str(p/'scripts/validate.py'),*args]
  with Path(str(prefix)+f'.{name}.stdout').open('w') as out,Path(str(prefix)+f'.{name}.stderr').open('w') as err:
   result=subprocess.run(argv,cwd=p,env=env,stdout=out,stderr=err)
  r['legs'].append({'name':name,'argv':argv,'returncode':result.returncode});print(name,result.returncode,flush=True)
  Path(str(prefix)+'.progress.json').write_text(json.dumps(r,indent=2)+'\n')
r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head_after=git('rev-parse','HEAD'),status_after=git('status','--porcelain'))
Path(str(prefix)+'.result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
