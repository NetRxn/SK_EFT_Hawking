from collections import Counter, defaultdict, deque
from itertools import product
from math import prod
from pathlib import Path
import sys

preflight, source, frozen = sys.argv[1:]
p=Path(preflight)/'parity-cost.py'
sys.argv=[sys.argv[0],source,frozen]
env={'__file__':str(p)}
exec(p.read_text().split('\npending=',1)[0],env)
projection,profile,decode=(env[k] for k in ('projection','profile','occupancy'))
filt=projection.__wrapped__.__globals__['filter_constraint']

CAP=1024

def solve_pilot(a,b):
    graphs,forced,domains=projection(a,b,2)
    constraints=[]
    loads=[profile(c)[2] for c in (a,b)]
    temporal=defaultdict(list)
    for t,graph in enumerate(graphs):
        for (u,v,k),(p,q) in graph.items():
            for x,m in ((u,p),(v,q)):
                if m:
                    for y in (u,v):
                        temporal[t,y].append((t,x,k))
    constraints.extend(('time',0,tuple(group)) for group in temporal.values())
    for e in graphs[0].keys()|graphs[1].keys():
        u,v,k=e
        group=tuple((t,x,k) for x in (u,v) for t in range(2))
        constraints.append(('space',min(sum(load.get(e,(0,0))) for load in loads),group))
        for side,load in enumerate(loads):
            d=sum(load.get(e,(0,0)))
            constraints.append(('parity',d%2,group))
            if not d:
                constraints.append(('equal',0,group[:2]))
                constraints.append(('equal',0,group[2:]))
    neighbors=defaultdict(set)
    for i,(_,_,group) in enumerate(constraints):
        for name in group:neighbors[name].add(i)
    checked=0
    def reduce(state):
        q=deque(range(len(constraints))); queued=set(q)
        while q:
            i=q.popleft(); queued.remove(i)
            kind,limit,group=constraints[i]
            old=tuple(state[k] for k in group)
            if kind in ('time','space'):
                new=filt(kind,limit,old)
            else:
                choices=[
                    labels for labels in product(*old)
                    if (labels[0]==labels[1] if kind=='equal' else sum(p+q for p,q in labels)%2==limit)
                ]
                new=tuple(tuple(sorted(set(col))) for col in zip(*choices)) if choices else ()
            if not new or not all(new):return False
            for k,prev,after in zip(group,old,new):
                if prev==after:continue
                state[k]=after
                for j in sorted(neighbors[k]-queued-{i}):
                    q.append(j);queued.add(j)
        return True
    def solve(state):
        nonlocal checked
        checked+=1
        if checked>CAP:raise RuntimeError('candidate node limit')
        if not reduce(state):return
        choices=[k for k in state if len(state[k])>1]
        if not choices:
            yield {k:v[0] for k,v in state.items()}
            return
        k=min(choices,key=lambda x:(len(state[x]),-len(neighbors[x]),x))
        for label in state[k]:
            yield from solve(state|{k:(label,)})

    try:
        states=list(solve(domains.copy()))
    except RuntimeError as error:
        if str(error)!='candidate node limit':raise
        return ('REFUSED',checked,0,0,0,tuple(forced))
    maxspin=max((max(label) for state in states for label in state.values()),default=0)
    maxpower=max(n for code in (a,b) for row in decode(code) for n in row)
    return ('EXACT_SUPPORT',checked,len(states),maxspin,maxpower,tuple(forced))

root=Path(source)/'family-intake/residual_shapes.py'
scope={'__file__':str(root)}
exec(root.read_text().split('\nrows=',1)[0],scope)
components=scope['components']
def signature(graph):
    result=[]
    for component in components(graph):
        degree=Counter(x for edge in component for x in edge[:2])
        result.append((len(component),tuple(sorted(degree.values()))))
    return tuple(sorted(result))
counts=Counter()
coverage=Counter()
members=defaultdict(list)
residual=Path(frozen,'block-remaining.tsv')
for line in residual.read_text().splitlines():
    a,b,w=map(int,line.split())
    if (a,b)==(103607566400,1256282136720):continue
    if not any(n%2 for code in (a,b) for row in decode(code) for n in row):continue
    (L,R),_,_=projection(a,b,2)
    if not L.keys() & R.keys():continue
    key=tuple(sorted((signature(L),signature(R))))
    counts[key]+=1;coverage[key]+=w
    members[key].append((a,b,w))
print('eligible odd/shared projected labels',sum(coverage.values()),flush=True)
for group,n in coverage.most_common(12):
    print('shape',counts[group],n,group,flush=True)
    observations=Counter()
    examples={}
    for a,b,w in members[group][:8]:
        result=solve_pilot(a,b)
        observations[result[:1]+result[3:5]]+=1
        examples.setdefault(result[:1]+result[3:5],(a,b,w,result[1],result[2],result[5]))
    for kind,number in observations.items():
        print('sample',number,kind,examples[kind],flush=True)
print('pilot control',solve_pilot(103607566400,1256282136720))
