# L1 numerical support census

Run `python3 verify_census.py` to check the complete roster and recompute the
three groups on the fourth accepted residual. Those groups describe the
bounded support search and do not certify numerical contractions. A refusal
means the search reached its node cap. No candidate support zero was found.

In a fresh copy, remove classifications.tsv and run
`python3 census_support.py preflight source prior` to regenerate it. The
separate dense control uses `python3 dense.py preflight source prior` and
counts a single profile under successively higher node caps.

The spectra screen limits maximum spin label to 2, insertion power to 3,
and supported assignments to 152. It does not evaluate edge or site factor
sizes, chirality multiplicities, or signs.
