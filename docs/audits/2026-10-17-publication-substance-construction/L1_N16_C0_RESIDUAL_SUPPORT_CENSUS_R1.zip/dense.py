from pathlib import Path
import sys,time
inputs=sys.argv[1:]
s=Path('screen.py').read_text()
exec(s[:s.index('root=Path(source)')])
for cap in (1024,8192,65536):
    CAP=cap
    started=time.monotonic()
    result=solve_pilot(503841882182,1461451755920)
    print(cap,result,round(time.monotonic()-started,2),flush=True)
    if result[0]=='EXACT_SUPPORT':
        break
