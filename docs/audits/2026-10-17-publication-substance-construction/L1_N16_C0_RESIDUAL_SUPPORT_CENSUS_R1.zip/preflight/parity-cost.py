from collections import Counter, defaultdict
from pathlib import Path
from math import prod
import sys

base, frozen = map(Path,sys.argv[1:])
source = base / 'family-intake/directed_roster.py'
scope = {'__file__': str(source)}
exec(source.read_text().split('\nselected=[]', 1)[0], scope)
projection, occupancy, profile = (scope[k] for k in ('projection','occupancy','profile'))

def solve(equations):
    basis = {}
    for lhs, rhs in equations:
        while lhs:
            pivot = lhs.bit_length()
            if pivot not in basis:
                basis[pivot] = lhs,rhs
                break
            row, bit = basis[pivot]
            lhs ^= row
            rhs ^= bit
        if not lhs and rhs:
            return None
    return basis

def screen(a,b):
    graphs, _, domains = projection(a,b,2)
    parity_vars = {}
    fixed = {}
    for name, labels in domains.items():
        choices = {p % 2 for p,q in labels}
        if len(choices) == 2:
            parity_vars[name] = 1 << len(parity_vars)
        else:
            fixed[name], = choices
    equations = []
    def add(names, rhs=0):
        mask=0
        for name in names:
            mask ^= parity_vars.get(name,0)
            rhs ^= fixed.get(name,0)
        equations.append((mask,rhs))
    for t,graph in enumerate(graphs):
        variables=defaultdict(list)
        for (u,v,k),(p,q) in graph.items():
            for x, power in ((u,p),(v,q)):
                if not power:
                    continue
                for y in (u,v):
                    variables[y].append((t,x,k))
        for names in variables.values():
            add(names)
    load = [profile(code)[2] for code in (a,b)]
    for u,v,k in graphs[0].keys() | graphs[1].keys():
        # Each directed spatial anchor receives the two root characters
        # from that anchor in opposite layers. Sum their center equations
        # to eliminate allocation of individual vector coframes.
        for layer in load:
            add(((t,x,k) for t in range(2) for x in (u,v)),sum(layer.get((u,v,k),(0,0)))%2)
            if not sum(layer.get((u,v,k),(0,0))):
                for x in (u,v):
                    add(((0,x,k),(1,x,k)))
    basis=solve(equations)
    if basis is None:
        return 0,0,0
    n=len(parity_vars)
    sizes=[(sum(p%2==0 for p,q in domains[name]),sum(p%2==1 for p,q in domains[name])) for name in parity_vars]
    fixed_factor=prod(len(domains[name]) for name in fixed)
    free=[1 << i for i in range(n) if i+1 not in basis]
    pivots=[(1 << (i-1), row, rhs) for i,(row,rhs) in sorted(basis.items())]
    options=[0]
    for bit in free:
        options.extend([v|bit for v in options])
    elements=0
    for v in options:
        for bit, row, rhs in pivots:
            if ((row&v).bit_count() % 2) != rhs:
                v |= bit
        elements += prod(choices[(v>>j)&1] for j,choices in enumerate(sizes))
    return elements*fixed_factor,prod(map(len,domains.values())),len(free)


pending={tuple(map(int,s.split()[:2])) for s in (frozen/'chain/leaf-overlap-one-or-zero-author.tsv').read_text().splitlines()}
totals=Counter()
examples={}
for row in (frozen/'block-remaining.tsv').read_text().splitlines():
    a,b,w=map(int,row.split())
    if (a,b) in pending:continue
    graphs,_,d=projection(a,b,2)
    if not graphs[0].keys() & graphs[1].keys():continue
    if not any(p%2 for v in occupancy(a)+occupancy(b) for p in v):continue
    count,raw,nfree=screen(a,b)
    assert 0<count<=raw
    k=count.bit_length()-1
    totals[k,'orbits']+=1
    totals[k,'labels']+=w
    examples.setdefault(k,(a,b,w,count,raw,nfree))
for k in sorted(examples):
    print(k,totals[k,'orbits'],totals[k,'labels'],examples[k])
