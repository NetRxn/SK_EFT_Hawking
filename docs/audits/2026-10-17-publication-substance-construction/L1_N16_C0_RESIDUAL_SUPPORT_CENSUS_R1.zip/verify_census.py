from collections import Counter
from pathlib import Path

def read_rows(path):
    return [tuple(map(int,line.split())) for line in Path(path).read_text().splitlines()]

prior=read_rows('prior/block-remaining.tsv')
current=set(read_rows('accepted-residual.tsv'))
rows=[]
counts=Counter()
weights=Counter()
for line in Path('classifications.tsv').read_text().splitlines()[1:]:
    a,b,weight,status,nodes,support,spin,power=line.split()
    key=tuple(map(int,(a,b,weight)))
    rows.append(key)
    if key not in current:
        continue
    nodes,support,spin,power=map(int,(nodes,support,spin,power))
    assert status in {'REFUSED','EXACT_SUPPORT'}
    if status=='REFUSED':
        assert nodes==1025 and support==spin==power==0
        group='node cap'
    elif 0<support<=152 and spin<=2 and power<=3:
        group='within support-count and degree screen'
    else:
        assert support>0
        group='outside support-count or degree screen'
    counts[group]+=1
    weights[group]+=key[2]
assert rows==prior and len(set(rows))==9641
assert set(rows)-current=={(140684411270,558347329670,96),(155950080585,580896423965,96)}
assert sum(counts.values())==9639 and sum(weights.values())==830439
for group in sorted(counts):
    print(group,counts[group],weights[group])
