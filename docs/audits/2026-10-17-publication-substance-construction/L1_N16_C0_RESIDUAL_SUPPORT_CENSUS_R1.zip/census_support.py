from pathlib import Path
from collections import Counter
import sys

s = Path('screen.py').read_text()
exec(s[:s.index('root=Path(source)')])

residual = Path(frozen) / 'block-remaining.tsv'
rows = [tuple(map(int, line.split())) for line in residual.read_text().splitlines()]
assert (len(rows), sum(w for _, _, w in rows)) == (9641, 830631)
assert len({(a,b) for a,b,_ in rows}) == len(rows)
results = Counter()
weights = Counter()
with Path('classifications.tsv').open('x') as out:
    print('a','b','weight','status','nodes','support','max_spin','max_power',sep='\t',file=out)
    for index,(a,b,w) in enumerate(rows,1):
        outcome,nodes,support,spin,power,forced = solve_pilot(a,b)
        if outcome == 'REFUSED':
            key = 'node cap'
        elif support == 0:
            key = 'candidate support zero'
        elif spin <= 2 and power <= 3 and support <= 152:
            key = 'within tested support counts and degrees'
        else:
            key = 'larger supported profile'
        print(a,b,w,outcome,nodes,support,spin,power,sep='\t',file=out)
        results[key] += 1
        weights[key] += w
        if index % 100 == 0 or index == len(rows):
            out.flush()
            print(index,dict(results),dict(weights),flush=True)
