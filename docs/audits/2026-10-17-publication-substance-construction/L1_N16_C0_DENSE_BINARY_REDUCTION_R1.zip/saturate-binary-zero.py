from pathlib import Path
from itertools import combinations
from collections import Counter
import pickle

exec(Path('checkpoint/quotient.py').read_text().split('\nlocal_test()\n',1)[0])
p=Path('row-cap-physical-slice-dense-binary-0.pkl')
with p.open('rb') as f:
    obj=pickle.load(f)
F=obj['factors']
degree=Counter(w for axes,_,_ in F for w in axes)
before=sum(len(r) for _,r,_ in F)
pairs=[(i,j) for i,j in combinations(range(len(F)),2)
       if any(w[0]!='L' and degree[w]==2 and w in F[j][0] for w in F[i][0])]
visits=0
for stage in range(2):
    prior=sum(len(r) for _,r,_ in F)
    n=0
    for i,j in pairs:
        for x,y in ((i,j),(j,i)):
            visits+=len(F[x][1])+len(F[y][1])
            if visits>60000000:
                raise RuntimeError(('quotient preflight cap',visits))
            F[x],F[y],m=quotient(F[x],F[y],degree)
            n+=m
    print('sweep',stage,'rows',prior,'to',sum(len(r) for _,r,_ in F),'coalesced',n,flush=True)
print('total visited',visits,'rows before',before,'after',sum(len(r) for _,r,_ in F))
with Path('binary-zero-saturated-frontier.pkl').open('wb') as f:
    pickle.dump(obj,f,protocol=5)
