from collections import defaultdict
from pathlib import Path
import pickle

root = Path(__file__).resolve().parent
with (root / 'binary-zero-saturated-frontier.pkl').open('rb') as handle:
    checkpoint = pickle.load(handle)
factors = checkpoint['factors']
domains = defaultdict(list)
for axes, rows, _ in factors:
    assert rows
    for position, wire in enumerate(axes):
        domains[wire].append({row[position] for row in rows})
fixed = {
    wire: next(iter(sets[0]))
    for wire, sets in domains.items()
    if len(sets[0]) == 1 and all(values == sets[0] for values in sets)
}
reduced = []
for axes, rows, denominator in factors:
    positions = [position for position, wire in enumerate(axes) if wire not in fixed]
    new_axes = tuple(axes[position] for position in positions)
    new_rows = {tuple(row[position] for position in positions): value for row, value in rows.items()}
    assert len(new_rows) == len(rows)
    reduced.append((new_axes, new_rows, denominator))
checkpoint['factors'] = reduced
checkpoint['stripped_fixed_coordinates'] = fixed
with (root / 'binary-zero-fixed-stripped-frontier.pkl').open('xb') as handle:
    pickle.dump(checkpoint, handle, protocol=5)
print('removed globally singleton indices', len(fixed), 'label indices', sum(wire[0]=='L' for wire in fixed))
print('original widths', [len(axes) for axes,_,_ in factors])
print('reduced widths', [len(axes) for axes,_,_ in reduced])
print('rows unchanged', sum(len(rows) for _,rows,_ in factors))
