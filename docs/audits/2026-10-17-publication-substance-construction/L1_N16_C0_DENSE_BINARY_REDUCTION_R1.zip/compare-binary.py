from pathlib import Path
from fractions import Fraction
import pickle

root = Path(__file__).resolve().parent
objects = []
for value in (0, 1):
    with (root / f'row-cap-physical-slice-dense-binary-{value}.pkl').open('rb') as handle:
        objects.append(pickle.load(handle))
left, right = [obj['factors'] for obj in objects]
assert len(left) == len(right) == 10
overall = (Fraction(1), Fraction(0))
equivalent = True
for index, ((axes, rows, denominator), (other_axes, other_rows, other_denominator)) in enumerate(zip(left, right)):
    if axes != other_axes or rows.keys() != other_rows.keys():
        print('different support', index, len(rows), len(other_rows), axes == other_axes, flush=True)
        equivalent = False
        continue
    key = next(iter(rows))
    a, b = rows[key]
    x, y = other_rows[key]
    norm = a*a + b*b
    assert norm
    real = Fraction(x*a + y*b, norm) * Fraction(denominator, other_denominator)
    imag = Fraction(y*a - x*b, norm) * Fraction(denominator, other_denominator)
    for key, (a, b) in rows.items():
        x, y = other_rows[key]
        if (Fraction(x, other_denominator), Fraction(y, other_denominator)) != (
            (a*real - b*imag) / denominator, (a*imag + b*real) / denominator
        ):
            print('nonproportional', index, key, flush=True)
            equivalent = False
            break
    else:
        print('proportional', index, real, imag, len(rows), flush=True)
        r, s = overall
        overall = r*real - s*imag, r*imag + s*real
print('all factorwise equivalent', equivalent, 'overall relative factor', overall, flush=True)
