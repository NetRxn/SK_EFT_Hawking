# Dense branch 128 exact reduction checkpoint

Scientific source is 51e7c745eccad5e99676cdc8e4b523ad73e617b1. Starting publication checkpoint is d7f7b8ebeef495910c8d4a563afd973e213f0138 on codex/publication-l1-checkpoint-20261103. Use its L1_N16_C0_DENSE_BRANCH_PAUSE_R1.zip as the parent archive. The profile is (503841882182,1461451755920), with 30,976 support states partitioned into 3,872 groups of eight. This work concerns group 128 only.

## Exact state and scope

The archived 12-factor frontier passed its original SHA256 check. A further quotient sweep reduced rows from 1,067,872 to 855,072. Contraction completed one join and reached 11 factors. Subsequent sweeps reached 1,292,272 rows.

The quotient representative index ('R',1,3,0,2,1) has exactly the values 0 and 1, each occurring in exactly two factors. Its two contributions form a disjoint exhaustive partition of this frontier. These representative values need not identify original physical spin assignments. Each bounded contribution completed a join and reached 10 factors. Both then hit row limits before the next exact join.

For contribution 0, another exact quotient sweep reduced 1,190,848 rows to 1,001,096. Removing 116 globally fixed singleton indices, including four retained label indices, preserved all rows and coefficients. The resulting frontier is saved here. Its next join forecast is 698,112 matched products, and its output exceeded the 500,000-row limit. Contribution1 is saved at 10 factors and 1,190,848 rows with next join forecast 1,396,224. It still needs the later quotient and fixed-coordinate reduction.

No branch subtotal, signed full-profile coefficient, or reduction of the accepted residual follows. The residual stays 9,547 orbits and 821,655 labels. Full original c0, the physical B3 construction, and publication qualification remain open.

## Verification and restart

Run shasum -a256 -c manifest.sha256 after extraction. Decompress both branch128-binary-*-frontier.pkl.gz files and verify frontiers-uncompressed.sha256. These pickles contain locally generated exact integer Gaussian rows and positive denominators. They are prejoin states, with no partial failed accumulation promoted into the frontier.

For contribution 0, copy branch128-binary-0-frontier.pkl to binary-zero-fixed-stripped-frontier.pkl and run contract-binary-zero-fixed.py in the same scratch directory. It will reproduce the current refusal at unchanged limits. The next substantive step is an exact further separator or a different bounded join order for that saved frontier, followed by complete exact subtotal calculation. Preserve both rational real and imaginary components. Contribution1 can use the same driver after changing its input to branch128-binary-1-frontier.pkl, its provenance value to 1 and its output index to a fresh unique name. Apply the quotient/fixed-coordinate reductions first if useful. The full group 128 result requires summing both exact complex subtotals and validating the result against the independent original-source eight-state replay.

To reproduce the preceding history, extract the parent archive into checkpoint/ and decompress checkpoint/frontier.pkl.gz. The archived scripts and outputs record the sequence. plan-frontier-cut.py used the 11-factor state before the later quotient sweep. That measured choice was applied to the later exact equivalent frontier.

## Independent review

independent/REVIEW.md and REVIEW_FIXED.md record scoped source acceptance, 400 rational Gaussian literal quotient/partition controls, 100 fixed-coordinate controls, actual cut-domain checks, denominator-product verification, external normalization +1/(16*4^64), and exact output equality for singleton removal.

Review found an unjustified reality assertion for individual conditioned contributions. contract-binary-r2.py and later drivers preserve exact rational real and imaginary values. The earlier capped runs never reached that assertion. Reality can be assessed after the complete partition sum.

The separate original-source replay from the parent archive remains incomplete. Its two attempted cases capped at seven factors, with six unstarted. These bounded controls and saved frontiers do not replace that required independent coefficient verification.
