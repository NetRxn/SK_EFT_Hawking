# Scoped independent fixed-coordinate review

2026-11-19, reviewer /root/dense_binary_review. R3 continuity packet checked first: fresh=true, changed=[]. Its internal task name retains r1. Referenced notebook read. Scope: scratch strip-fixed.py and contract-binary-zero-fixed.py; existing REVIEW.md remains intact. No repository/Lean changes or large contractions performed.

## Accepted scoped algebra

The stripping transformation preserves the complete scalar sum exactly for this valid sparse network. A coordinate is removed only if every occurrence has exactly the same singleton support {v}. Every potentially nonzero global assignment therefore has that coordinate equal v; all other values yield zero. Summing over that coordinate contributes one copy, with no dimension/multiplicity/normalization factor. Projection of rows is injective: removed coordinates are constant within each factor, so two distinct rows cannot differ solely on removed positions. Coefficients and factor denominators remain identical, including any factor becoming scalar.

There is no exception for L labels: the earlier prohibition against merging variable boundary labels protects dependence on other values. A globally constant label has no remaining choice or dependence to preserve. Nor does this operation require interpretation as an original physical spin index: it removes singleton support in the CURRENT exact quotient network. It must not be described as eliminating an original unconditioned physical event. Scalar equality is the acceptance scope; if an application needed an output tensor retaining a removed label, its value would have to be reattached explicitly. That is not the present scalar contraction.

The source refuses empty factors before finding fixed coordinates. This is conservative: an empty factor is an exact zero case, but it is not silently misrepresented as a nonzero reduced network. Disagreeing singleton values across factors are not stripped, preserving their exact-zero incompatibility. The transformation also checks row-count injectivity and writes exclusively to a new output.

## Executed controls and actual output verification

Run:

python3 /private/tmp/l1-dense-binary-review-20261119/fixed-controls.py > /private/tmp/l1-dense-binary-review-20261119/fixed-controls.out

The controls invoke only the transformation fragment of frozen strip-fixed.py, avoiding its output-writing tail. An independent literal Gaussian-rational enumerator checks 100 seeded small networks, including singleton L and quotient coordinates, complex coefficients, denominators 3/7/11, inconsistent singleton refusal, and preservation of a nonunit scalar factor. All passed.

Actual input and output were read, not contracted. Reapplication of the frozen transformation exactly matches the saved output factor list and stripped-coordinate map; all unrelated checkpoint metadata agrees. Valid unique axes, row widths, every row count, coefficient and denominator are preserved. Observed 116 removed indices out of220, including4 L labels, across10 factors;1,001,096 stored rows unchanged. Widths:

[32,46,50,34,57,40,38,60,57,48] -> [19,18,14,25,29,22,14,30,28,23].

## Resume driver and evidence boundary

Compared contract-binary-zero-fixed.py with accepted contract-binary-r2.py. The only differences are input loading and provenance setup: it reads the already conditioned/stripped zero-slice frontier, sets the matching zero-slice name/wire/value, and removes the original eleven-factor conditioning loop. The quotient, join, peer support checks, resource caps, denominator handling and final exact rational complex output are unchanged. It correctly does not condition the already removed binary cut a second time.

Accepted as source-qualified exact continuation of the supplied zero-slice frontier. The driver relies on that frozen input identity for branch provenance; its hardcoded wire/value is descriptive metadata, not an independent check of ancestry. Stripping does not establish completion, a numerical scalar, or reality of either slice. Both exact complex slice totals remain necessary for branch128 recombination. Full signed coefficient, c0, physical B3 and publication acceptance remain open.
