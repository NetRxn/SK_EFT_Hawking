from pathlib import Path
from collections import Counter,defaultdict
from itertools import product
from fractions import Fraction as Q
from math import factorial,prod
import random,pickle,json,hashlib
D=Path('/private/tmp/l1-dense-resume.bbZW6V')
ns={};exec((D/'checkpoint/quotient.py').read_text().split('\nlocal_test()\n',1)[0],ns)
quotient=ns['quotient']
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def literal(fs,retained=()):
    axes=tuple(dict.fromkeys(k for a,r,d in fs for k in a))
    domains={k:sorted({row[a.index(k)] for a,r,d in fs if k in a for row in r}) for k in axes}
    ans=defaultdict(lambda:(Q(0),Q(0)))
    for vals in product(*(domains[k] for k in axes)):
        s=dict(zip(axes,vals));z=(Q(1),Q(0))
        for a,r,d in fs:
            v=r.get(tuple(s[k] for k in a),(0,0));z=mul(z,tuple(Q(x,d) for x in v))
        out=tuple(s[k] for k in retained);old=ans[out];ans[out]=old[0]+z[0],old[1]+z[1]
    return {k:v for k,v in ans.items() if any(v)}
def cut(fs,w,v):
    return [(tuple(k for k in a if k!=w),{row[:a.index(w)]+row[a.index(w)+1:]:z for row,z in r.items() if row[a.index(w)]==v},d) if w in a else (a,r,d) for a,r,d in fs]
rng=random.Random(20261119)
u=('L',0);b=('B',0);c=('C',0);x=('X',0);y=('Y',0)
units=((1,0),(0,1),(-1,0),(0,-1));coalesced=0
for case in range(400):
    # Four closed values carry primitive-identical columns, scaled by all four units.
    # Boundary values stay distinct, and third factor makes their preservation observable.
    L={};R={}
    for bv,uv in product(range(2),repeat=2):
        base={xv:(rng.randint(-3,3),rng.randint(-3,3)) for xv in range(2)}
        base={k:v if any(v) else (1,0) for k,v in base.items()}
        for cv in range(4):
            scale=tuple((cv+1)*v for v in units[(cv+case)%4])
            for xv,z in base.items():L[uv,bv,cv,xv]=mul(z,scale)
            for yv in range(2):
                z=(rng.randint(-4,4),rng.randint(-4,4))
                if any(z):R[cv,bv,uv,yv]=z
    # unmatched closed value is allowed and must contribute zero
    L[0,0,7,0]=(1,2)
    A=((u,b,c,x),L,3);B=((c,b,u,y),R,5)
    E=((b,x,y),{row:(rng.randint(-2,2),rng.randint(-2,2)) for row in product(range(2),repeat=3)},7)
    deg=Counter(k for a,_,_ in (A,B,E) for k in a)
    before=literal([A,B,E],(u,));aa,bb,n=quotient(A,B,deg);coalesced+=n
    assert literal([aa,bb,E],(u,))==before,(case,'first orientation')
    bb,aa,n=quotient(bb,aa,deg)
    assert literal([aa,bb,E],(u,))==before,(case,'reverse orientation')
    # Binary wire occurs twice; compare full complex rational scalar.
    fs=[aa,bb,E];want=literal(fs);v0=literal(cut(fs,x,0));v1=literal(cut(fs,x,1))
    got={};keys=set(v0)|set(v1)
    for k in keys:
        z0=v0.get(k,(0,0));z1=v1.get(k,(0,0));z=(z0[0]+z1[0],z0[1]+z1[1])
        if any(z):got[k]=z
    assert got==want,(case,'binary sum')
print('PASS literal rational Gaussian controls: 400 networks, both quotient orientations, protected L and degree3 boundaries, unmatched support, all four units, denominators 3/5/7, binary sum; coalesced',coalesced)
with (D/'resumed-eleven-saturated-frontier.pkl').open('rb') as f:obj=pickle.load(f)
fs=obj['factors'];w=('R',1,3,0,2,1)
inc=[(i,a.index(w),len(r),d,Counter(row[a.index(w)] for row in r)) for i,(a,r,d) in enumerate(fs) if w in a]
assert len(inc)==2
assert all(set(count)=={0,1} for i,p,n,d,count in inc)
assert all(len(a)==len(set(a)) and d>0 and all(len(row)==len(a) and any(z) for row,z in r.items()) for a,r,d in fs)
assert all(isinstance(v,int) for a,r,d in fs for row,z in r.items() for v in z)
print('frontier schema and nonzero Gaussian entries PASS; factor count',len(fs),'rows',sum(len(r) for a,r,d in fs),'denominator product',prod(d for a,r,d in fs),'used_before',obj['used_before'])
print('cut incidences',inc)
roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occ=[[roster[(int(code)>>(6*x))&63] for x in range(8)] for code in ('503841882182','1461451755920')]
edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
world=sum((3+k)*n for row in occ for o in row for k,n in enumerate(o));cross=0
for m in occ:
    weighted=[(u,v,sum(m[u])-m[u][k]+sum(m[v])-m[v][k]) for u,v,k in edges]
    cross+=sum(a[2]*b[2]*(u>v) for i,a in enumerate(weighted) for b in weighted[i+1:] for u in a[:2] for v in b[:2])
total=sum(n for m in occ for row in m for n in row);fact=prod(factorial(p) for m in occ for o in m for p in o)
assert total==32 and fact==16 and (world+cross)%2==0
print('normalizer occupancy total',total,'factorial',fact,'world',world,'cross',cross,'phase',(-1)**((world+cross)%2),'external factor +1/(16*4^64)')
