from pathlib import Path
from ast import literal_eval as lit
from collections import defaultdict
from math import lcm,prod
import pickle
D=Path('/private/tmp/l1-dense-streamed-cut.TKHkIW')
row,=[l.split('\t') for l in (D/'cut-plan.tsv').read_text().splitlines() if l.split('\t')[0]=='128']
ids=lit(row[-1]);blocks=[l.split('\t') for l in (D/'block-index.tsv').read_text().splitlines()]
by=defaultdict(list)
for i in ids:
    name,key,start,size,n,d=blocks[i];by[name].append(int(d))
initial=prod(lcm(*ds) for ds in by.values())
print('branch128 assignments',row[1],'factor families',len(by),'selected blocks',len(ids),'initial common-denominator product',initial)
assert len(by)==88 and int(row[1])==8
for name in ('checkpoint/frontier.pkl','resumed-eleven-saturated-frontier.pkl'):
    with (Path('/private/tmp/l1-dense-resume.bbZW6V')/name).open('rb') as f:o=pickle.load(f)
    actual=prod(d for a,r,d in o['factors']);assert actual==initial
    print(name,'denominator product PASS',actual)
# A literal conditioned complex counterexample: an unsliced real scalar need not
# have real slices. F(0)=i,F(1)=-i; G(0)=G(1)=1.
print('reality limitation: binary slices i and -i sum to real zero; full-network reality alone does not justify im==0 separately')
