# Scoped independent review: branch 128 quotient and binary partition

Reviewer /root/dense_binary_review; 2026-11-19. Continuity r1 checked fresh before work. Candidate source 51e7c745eccad5e99676cdc8e4b523ad73e617b1; archived checkpoint d7f7b8ebe. No repository edits, Lean commands or large contractions were performed. Scratch ownership only.

## Outcome

No arithmetic-equivalence defect found in the reviewed quotient, saturation, or binary conditioning. Exact equivalence holds under observed valid sparse-factor invariants. This is a scoped calculation review, not completion of branch128, full dense coefficient, full signed coefficient, c0, physical B3, or publication acceptance.

One actionable output limitation: contract-binary.py asserts each conditioned scalar has zero imaginary part. Full-network reality does not by itself imply reality of an individual conditioned slice. The two slices i and -i already furnish a literal counterexample. If a slice finishes with nonzero imaginary part, retain both exact rational components, sum both slices, and assert reality on the reconstructed branch unless a separate slice-wise reality proof is supplied. This is a possible false refusal, not evidence of wrong accepted arithmetic or an actual imaginary result here.

## Algebra and support reasoning

For shared index s=(boundary,closed), left slice L_s(p) is normalized as L_s(p)=g_s*i^(-phase_s)*S_s(p), where g_s is the positive integer gcd of all real/imaginary coefficients. Rotation is multiplication by i^phase and the max-rotation convention selects a deterministic unit. Thus canonical equivalent slices have identical S, with exact Gaussian scale transferred to the right. Right aggregation is sum_s g_s*i^(-phase_s)*R_s(q). This reproduces sum_s L_s(p)R_s(q) exactly, without conjugation. Both factor denominators remain unchanged; multiplication of denominators occurs only at joins.

Only shared non-L degree-two axes can be identified. Equivalence keys include every remaining shared boundary label value, protecting external degree>2 wires and all L labels, even an L label with degree two. Private left positions are part of the signature, so their complete tensor dependence is preserved. Right axes are projected and reordered consistently; no duplicate row insertion can occur because axes are unique. Unsupported shared slices are zero and may be dropped. Empty factors mean exact zero; an all-zero stored slice would fail gcd positivity, and the observed frontier has no such rows.

Pairwise support intersections and peer-projection rejection remove only assignments that cannot occur in a complete network. They need not reach a fixed point for correctness. Saturation preserves the same factor-list object stored in obj; rewriting F entries therefore updates the saved envelope. Axis incidence counts remain valid over each saturation sweep because quotient only reorders axes and changes their stored representatives.

The cut wire ('R',1,3,0,2,1) occurs in exactly two factors. Its observed support is exactly {0,1} in both. Restricting BOTH factors to the same value and deleting this axis partitions all compatible network assignments into disjoint, exhaustive slices. Projection is injective within each fixed-value slice. No extra factor of two, probability renormalization, chirality multiplicity, or orbit weight belongs in their sum. After prior quotient operations these labels denote representative summation classes; the partition is an exact arithmetic partition and does not independently establish original physical spin-event interpretation.

## Controls actually run

python3 scripts/codex_continuity.py check /Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/l1-c0-dense-binary-review-20261119-r1.json

python3 /private/tmp/l1-dense-binary-review-20261119/controls.py > /private/tmp/l1-dense-binary-review-20261119/controls.out

python3 /private/tmp/l1-dense-binary-review-20261119/denominator-control.py > /private/tmp/l1-dense-binary-review-20261119/denominator-control.out

The control loads ONLY the quotient function definition, not its checkpoint or contraction execution tail. An independent literal enumerator evaluates rational real/imaginary components over all assignments. 400 seeded small networks passed both quotient orientations, protected L and third-factor boundary labels, unmatched support, all four Gaussian units, nontrivial denominators 3/5/7, and exhaustive binary recombination. These checks exercise 4,799 first-orientation slice coalescences. They test the exact implemented quotient against literal summation, not a second copy of quotient arithmetic. The actual eleven-factor frontier was read and structurally checked, not contracted: 1,292,272 rows, unique axes, nonzero integer Gaussian rows, positive denominators. Cut incidences are factor7 position22 with 16,764 rows per value, and factor10 position55 with 231,680 rows per value.

## Normalization

Independent occupancy decoding of the two profile integers gives 32 insertions, factorial product16, world136, cross444, hence sign+1. The external factor is therefore +1/(16*4^64), consistent with archived independent normalization controls. prepare-branch.py forms each family using common=lcm(selected block denominators) and multiplies each numerator by common/block_denominator. No source factor is divided twice. Quotient transfers only Gaussian integer scales; joins multiply their factor denominators. The denominator control compares the selected 88 family LCM product against the archived and eleven-factor frontier denominator products; see terminal output. The final norm is factor-denominator-product *16*4^64. Schema denominators alone describe all variants and must not substitute for the selected-block LCMs.

This confirms downstream denominator accounting and the stated external normalization for the declared profile. It does not rederive every compiled numerator from original source factors or repeat the earlier complete source-binding/local Haar audit. Earlier source-qualified control evidence was read in checkpoint/independent/CHECKPOINT.md and /private/tmp/l1-dense-input-review.f0tPeN/normalization.py,out. compile.py source reasoning supports per-block denominator preservation.

## Refusal and acceptance scope

The row-cap saves prejoin factors (after any exact quotient), not partially accumulated out rows. used_before excludes the failed join, so no unfinished scalar is accepted. Binary scripts preserve earlier work for provenance but restart work=0: the 40-million cap is a per-invocation cap, not a cumulative historical-work claim. Integer arithmetic has no float roundoff. Bound checks establish admitted resource work only, not coefficient completion.

No terminal signed slice or branch value was computed by this reviewer. Logs, capped frontiers, unequal/equal factor comparisons and a successful literal toy control cannot supply such a value. Next admissible scientific evidence is exact terminal subtotals for BOTH slices followed by exact recombination, or another independently justified separator strategy; that still closes only branch128's conditioned contribution.

## R2 follow-up accepted within this scope

The r2 continuity packet check returned fresh=true and changed=[] (its task field retains the r1 assignment name). Reviewed the exact diff contract-binary.py -> contract-binary-r2.py: only the terminal imaginary-zero assertion and scalar print were replaced by imaginary=Fraction(phase*im,norm) plus printing both exact rational components. This corrects the reporting limitation above without changing conditioning, arithmetic, denominators, join gates, or saved-frontier semantics. Accepted as a scoped source correction. Neither R1 capped attempt reached the old assertion, so no existing terminal arithmetic result needs reinterpretation. Future terminal slice subtotals must be combined in both components before a branch-level reality assertion. R2 was inspected, not executed to completion.
