from pathlib import Path
from collections import defaultdict,Counter
from itertools import product
from fractions import Fraction as F
import pickle,random
D=Path('/private/tmp/l1-dense-resume.bbZW6V')
source=(D/'strip-fixed.py').read_text();fragment=source[source.index('domains ='):source.index("with (root / 'binary-zero-fixed-stripped-frontier.pkl')")]
def strip(fs):
    scope={'factors':fs,'defaultdict':defaultdict,'checkpoint':{}};exec(fragment,scope);return scope['reduced'],scope['fixed']
def literal(fs):
    axes=tuple(dict.fromkeys(k for a,r,d in fs for k in a));domains={k:set(row[a.index(k)] for a,r,d in fs if k in a for row in r) for k in axes}
    ans=(F(0),F(0))
    for row in product(*(domains[k] for k in axes)):
        s=dict(zip(axes,row));z=(F(1),F(0))
        for a,r,d in fs:
            u,v=r.get(tuple(s[k] for k in a),(0,0));u,v=F(u,d),F(v,d);x,y=z;z=x*u-y*v,x*v+y*u
        ans=ans[0]+z[0],ans[1]+z[1]
    return ans
rng=random.Random(19);L=('L',0);Q=('R',0);V=('V',0)
for i in range(100):
    fs=[((L,Q,V),{(5,9,v):(rng.randint(-5,5),rng.randint(-5,5)) for v in range(2)},3),((V,Q),{(v,9):(rng.randint(-5,5),rng.randint(-5,5)) for v in range(2)},7),((L,),{(5,):(2,-3)},11)]
    reduced,fixed=strip(fs);assert fixed=={L:5,Q:9};assert literal(reduced)==literal(fs)
# Incompatible singleton occurrences must not be removed.
fs=[((L,),{(0,):(1,0)},3),((L,),{(1,):(1,0)},5)];rr,fixed=strip(fs);assert not fixed and literal(rr)==literal(fs)==(0,0)
# A globally singleton factor can become a nonunit scalar: retain its coefficient.
fs=[((L,),{(4,):(2,3)},5)];rr,fixed=strip(fs);assert rr==[((),{():(2,3)},5)] and literal(rr)==literal(fs)
print('PASS 100 literal complex rational singleton-elimination controls, label+quotient coordinates, incompatible-singleton refusal, nonunit scalar preservation')
with (D/'binary-zero-saturated-frontier.pkl').open('rb') as f:original=pickle.load(f)
with (D/'binary-zero-fixed-stripped-frontier.pkl').open('rb') as f:actual=pickle.load(f)
want,fixed=strip(original['factors']);assert actual['factors']==want;assert actual['stripped_fixed_coordinates']==fixed
assert {k:v for k,v in actual.items() if k not in ('factors','stripped_fixed_coordinates')}=={k:v for k,v in original.items() if k!='factors'}
for (a,r,d),(b,s,e) in zip(original['factors'],want):
    assert len(a)==len(set(a)) and len(b)==len(set(b)) and d==e and len(r)==len(s)
    assert all(len(row)==len(a) for row in r)
print('PASS exact actual saved-output equality to independently invoked frozen transformation; all metadata/denominators/coefficients/row counts preserved')
print('removed',len(fixed),'label',sum(k[0]=='L' for k in fixed),'original indices',len({k for a,r,d in original['factors'] for k in a}))
print('widths',[len(a) for a,r,d in original['factors']],'->',[len(a) for a,r,d in want],'rows',sum(len(r) for a,r,d in want))
