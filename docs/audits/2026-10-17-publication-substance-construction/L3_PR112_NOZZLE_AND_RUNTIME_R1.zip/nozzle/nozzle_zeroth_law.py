from sympy import Eq, Function, Matrix, diff, exp, log, simplify, solve, symbols

t, z, y, x = symbols("t z y x", real=True)
c, area_0, beta, rho_0 = symbols("c A0 beta rho0", positive=True)
velocity = Function("v")(z)
density = Function("rho")(z)
area = area_0 + beta * z**2
mass_flux = area * density * velocity
bernoulli = velocity**2 / 2 + c**2 * log(density / rho_0)

density_slope = solve(diff(bernoulli, z), diff(density, z))[0]
normalized_flux_derivative = simplify(
    (diff(mass_flux, z) / mass_flux).subs(diff(density, z), density_slope)
)
nozzle = -diff(velocity, z) / velocity * (1 - velocity**2 / c**2)
assert simplify(normalized_flux_derivative - (diff(area, z) / area - nozzle)) == 0
slope = symbols("a", real=True)
horizon = {velocity: -c, diff(velocity, z): slope, z: 0}
assert simplify(diff(nozzle, z).subs(horizon, simultaneous=True)) == 2 * slope**2 / c**2
assert simplify(diff(diff(area, z) / area, z).subs(z, 0)) == 2 * beta / area_0

# The inverse-function step uses this double zero and the positive
# analytic extension of h(u)/(u+1)^2 at u=-1.
u = symbols("u", negative=True)
profile = -exp((u**2 - 1) / 2) / u - 1
profile_jets = [simplify(diff(profile, u, n).subs(u, -1)) for n in range(3)]
assert profile_jets == [0, 0, 2]

# Direct coordinate computation of nabla_K K for K = partial_t.
def stationary_pg_data(v, conformal):
    metric = conformal * Matrix([
        [v**2 - c**2, -v, 0, 0],
        [-v, 1, 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, 1],
    ])
    inverse = metric.inv()
    acceleration = -inverse * Matrix([diff(metric[0, 0], q) for q in (t, z, y, x)]) / 2
    return metric, inverse, acceleration.applyfunc(simplify)

conformal = Function("F")(z)
metric, inverse, acceleration = stationary_pg_data(velocity, conformal)
assert metric[:, 0].subs(horizon, simultaneous=True) == Matrix([0, c * Function("F")(0), 0, 0])
assert inverse[1, 1].subs(horizon, simultaneous=True) == 0
assert acceleration.subs(horizon, simultaneous=True) == Matrix([slope, 0, 0, 0])

# Adverse local geometric control. Same planar null Killing horizon,
# with nonconstant surface gravity when the transverse slope varies.
transverse_slope = 1 + y**2
tilted_metric, tilted_inverse, tilted_acceleration = stationary_pg_data(-c + transverse_slope*z, 1)
assert tilted_metric[:, 0].subs(z, 0) == Matrix([0, c, 0, 0])
assert tilted_inverse[1, 1].subs(z, 0) == 0
assert tilted_acceleration.subs(z, 0) == Matrix([transverse_slope, 0, 0, 0])
assert tilted_acceleration[0].subs({z: 0, y: 0}) == 1
assert tilted_acceleration[0].subs({z: 0, y: 1}) == 2
print("Nozzle equation and horizon slope: a^2 = c^2 beta / A0")
print("Analytic inverse jets at u=-1:", profile_jets)
print("Nozzle horizon: grad_K K = a K with K=partial_t")
print("Adverse stationary planar horizon: kappa(0)=1, kappa(1)=2")
