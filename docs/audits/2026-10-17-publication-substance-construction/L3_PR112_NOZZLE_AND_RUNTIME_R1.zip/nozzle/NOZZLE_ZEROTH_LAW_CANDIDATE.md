# Stationary constant-sound-speed nozzle horizon

Candidate evidence for the original L3 four-laws finding 2.1 on PR112
`e4c221214`. The target is a local zeroth-law construction in the
stationary one-dimensional Laval-nozzle model and its explicitly
transverse-uniform metric lift.

## Source and construction

[Balbinot, Fagnocchi and Fabbri, §4](https://arxiv.org/pdf/gr-qc/0405098#page=9)
use force-free stationary continuity `A rho v = D` and Bernoulli
`v^2/2 + c^2 log(rho/rho0)=0` at positive constant sound speed c.
Use the throat profile `A=A0+beta z^2` with positive A0 and beta.
On the black-hole branch v is negative, the sonic throat has v(0)=-c,
and the branch is supersonic for z<0 and subsonic for z>0.
Differentiation gives the nozzle equation
`A'/A=-(v'/v)(1-v^2/c^2)`. At the throat its derivative gives
`v'(0)^2=c^2 beta/A0`.

A local smooth branch can be constructed from their implicit equation (4.9).
Write u=v/c and `h(u)=-exp((u^2-1)/2)/u-1`. At u=-1, h=h'=0 and
h''=2. Analytic division extends `h(u)/(u+1)^2` across u=-1 with value
1. In a neighborhood where that factor stays positive, the real analytic
map `F(u)=(u+1) sqrt(h(u)/(u+1)^2)` has derivative 1 at u=-1.
Its local inverse applied to `sqrt(beta/A0) z` gives the oriented branch
with `v'(0)=c sqrt(beta/A0)`. The positive density follows from
`rho=rho0 exp(-v^2/(2c^2))` and the flux is
`D=-A0 rho0 exp(-1/2)c`. The second stationary branch comes from
reversing the argument of the inverse and has the opposite slope.
This is a local existence argument. A formal proof must supply analytic
division and the inverse step in the project.

For the stationary lifted metric
`g=f(z)[(v^2-c^2)dt^2-2v dt dz+dz^2+dy^2+dx^2]`, f positive,
take the Killing generator K=partial_t. On the sonic cut z=0,
`g(K,.)=f(0)c dz` and `g^zz=0`, so K is the null normal up to scale.
The actual connection calculation is `nabla_K K = v'(0) K`.
For the physical conformal factor `f=rho/c`, the covector is `rho(0) dz`.
Constancy follows on every transverse point of the cut since the profile
depends on z alone. Eq. (4.17) uses the acceleration normalization
`k=c v'(0)=c^2 sqrt(beta/A0)` and its `kappa=k/c^2`.
The nonaffinity of the chosen time generator is `v'(0)`.

## Controls and acceptance boundary

The attached SymPy calculation checks the differentiated laws, the
double-zero jets, the null normal and the actual connection. For the
adverse stationary metric with `v=-c+(1+y^2)z` and `f=1`, the same
planar cut is a local null Killing horizon, but its nonaffinity differs
at y=0 and y=1. That metric is outside the one-dimensional nozzle
hypotheses. It isolates the role of transverse uniformity. The limit on
general acoustic horizon claims agrees with
[Visser, §9.2](https://arxiv.org/pdf/gr-qc/9712010#page=20).

This construction preserves the distinction between the effective
acoustic metric and the physical ADW exterior. The next acceptance step
is independent mathematical review and native formalization of the
stationary equations, local profile, normalization and transverse
control. Neither the formal result nor a general acoustic, dynamical
or third-law result is recorded here. The existing fixed-coupling
Schwarzschild donor and its native-composition requirements are separate.
