# Second half of the 64-profile L1 run

Run `python3 verify_author.py` to reconstruct the 32 exact signed author sums
from terminal case logs and the full anchor rosters. Each fixed assignment
contributes once and each exchanged pair twice. The predecessor incorporates
independent acceptance of the first 32 profiles. The second 32 remain in
that residual until independent review verifies them.
