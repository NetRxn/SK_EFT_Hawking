#!/bin/bash
set -eu
a=/private/tmp/l1-component14-remaining.fvZB2B/group-1442/cached-original-roster
for label in "$@"; do
    d="author/L$label"
    source="$a/L$label"
    if [[ "$label" = 4 ]]; then source="$source/budget-rescue"; fi
    until test -s "$source/contraction.receipt" && test -s "$source/row-cap-physical-slice-dense-branch.pkl"; do sleep 3; done
    if ! test -f "$d/native-replay.out"; then
        /bin/sh run-native.sh "$label"
    fi
    until test -s "$a/solve-L$label.time" && test -s "$d/native-replay.out" &&
        tail -1 "$d/native-replay.out" | grep -q 'native source and cap independent seconds'; do
        sleep 3
    done
    if [[ "$label" = 4 ]]; then
        while :; do
            entry=$(awk '/^preserved checkpoint pass[0-9]+-result.pkl/ && $5<=3 {name=$3; gsub(/[^0-9]/,"",name); print name, $5}' "$source"/pass*.out 2>/dev/null | tail -1)
            if [[ -n "$entry" ]]; then
                read -r stage n <<< "$entry"
                if grep -q '^follow seconds ' "$source/pass$stage.out"; then break; fi
            fi
            sleep 3
        done
    else
        read -r stage n < <(awk '/^preserved checkpoint pass[0-9]+-result.pkl/ { name=$3; gsub(/[^0-9]/,"",name); print name, $5 }' "$source"/pass*.out | tail -1)
    fi
    if [[ "$n" = 1 ]]; then
        /bin/bash run-continuation.sh "$label" "$stage"
    elif [[ "$n" = 3 ]]; then
        /bin/bash run-continuation.sh "$label" "$stage" triangle
        /usr/bin/time -p python3 -B -u triangle_replay.py "$label" > "$d/extra-replay.out" 2> "$d/extra-replay.time"
        until grep -q '^elapsed ' "$source/terminal.out" 2>/dev/null; do sleep 3; done
        cp "$source/terminal.out" "$source/triangle.py" "$d/"
        if test -s "$source/terminal.time"; then cp "$source/terminal.time" "$d/"; fi
        python3 -B -u audit_triangle.py "$label" > "$d/triangle-audit.out"
    else
        printf 'L%s unknown terminal topology %s\n' "$label" "$n"
        exit 2
    fi
    tail -1 "$d/replay.out"
done
