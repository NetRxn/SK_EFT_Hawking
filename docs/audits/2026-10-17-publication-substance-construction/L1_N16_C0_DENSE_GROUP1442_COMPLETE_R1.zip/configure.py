"""Pin the currently frozen original-ordinal seed and guarded cap."""
from hashlib import file_digest
from pathlib import Path
import json,re,sys
case=int(sys.argv[1])
r=Path('prepared-roster.tsv').read_text().splitlines()[1:]
records={int(i):(int(rows),int(peak)) for i,_,rows,peak in map(lambda q:q.split('\t'),r)}
a=Path('/private/tmp/l1-component14-remaining.fvZB2B/group-1442/cached-original-roster')/f'L{case}'
def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
original=a
if case==4:
    a=a/'budget-rescue'
kind,cap,work=re.search(r'open (row|product) cap (\d+) (\d+) frontier saved',(a/'contraction.out').read_text()).groups()
assert kind==('product' if case==4 else 'row')
cap,work=int(cap),int(work)
rows,peak=records[case]
data={'rows':rows,'peak':peak,'cap_factors':cap,'native_refused':work if kind=='row' else None,
      'native_kind':kind,'native_used':work if kind=='product' else None,
      'seed_sha':sha(original/'dense-saturated-frontier.pkl'),'cap_sha':sha(a/'row-cap-physical-slice-dense-branch.pkl')}
cap_path=Path(f'author/L{case}/pins.json')
if cap_path.exists():
    old=json.loads(cap_path.read_text())
    assert all(old[k]==v for k,v in data.items() if k in old)
    data={**old,**data}
if len(sys.argv)>2:
    n=int(sys.argv[2])
    d=a/f'pass{n}-result.pkl'
    data.update(terminal_sha=sha(d),passes=n)
    report=(a/f'pass{n}.out').read_text()
    match=re.search(r'exact raw scalar \((-?\d+), (-?\d+)\)',report)
    if match: data.update(expected_raw=int(match[1]),expected_imag=int(match[2]),mode='scalar')
    else: data.update(mode=sys.argv[3])
cap_path.parent.mkdir(parents=True,exist_ok=True)
cap_path.write_text(json.dumps(data,indent=2)+'\n')
