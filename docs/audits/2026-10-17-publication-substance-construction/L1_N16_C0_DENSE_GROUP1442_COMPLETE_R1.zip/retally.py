"""Audit all original signed ordinals and apply the accepted geometric cover exactly once."""
from ast import literal_eval
from csv import DictReader
from decimal import Decimal
from fractions import Fraction
from hashlib import file_digest
from pathlib import Path
from pickle import load
import json
import re

GROUP=1442
N=2371085825511616221242811507277824
LIVE=Path('/private/tmp/l1-component14-remaining.fvZB2B/group-1442')
AUTHOR=LIVE/'cached-original-roster'
SURVIVORS=(0,1,2,3,4,6)
ZEROS=(5,7)

def sha(path):
    with path.open('rb') as f: return file_digest(f,'sha256').hexdigest()

def read(path):
    with path.open('rb') as f: return load(f)

def lookup(path):
    with Path(path).open() as f: return list(DictReader(f,delimiter='\t'))

def save(path,heading,rows):
    with Path(path).open('w') as f:
        print(*heading.split(),sep='\t',file=f)
        for row in rows:
            print(*row,sep='\t',file=f)

def main():
    root=LIVE/'dense-saturated-frontier.pkl'
    origin_sha=Path('source-receipts/frontier.sha256').read_text().split()[0]
    assert sha(root)==origin_sha=='a982400d4a30421c31198670e1fc8b2be290ff792dbf3810c8bbe61a5c732486'
    axes,roster=literal_eval(Path('original-roster.txt').read_text())
    assert len(axes)==12 and len(roster)==len(set(roster))==8
    zero_rows=lookup('zero-roster.tsv')
    assert [int(r['original_ordinal']) for r in zero_rows]==list(range(8))
    assert tuple(int(r['original_ordinal']) for r in zero_rows if r['disposition']=='exact_zero')==ZEROS
    assert all(r['original_joint_L_tuple']==repr(key) for r,key in zip(zero_rows,roster,strict=True))
    source_proof=json.loads(Path('source-receipts/result.json').read_text())
    assert source_proof['prepared_sha256']==origin_sha and source_proof['proved_zero_ordinals']==list(ZEROS)
    verdict={z:(z,repr(roster[z]),0,0,N,'empty_factor_after_preparation',origin_sha,'','','','','','') for z in ZEROS}
    stage_rows=[]
    refusal_rows=[]
    cap_rows=[]
    costs=[]
    special_costs=[]
    author_prep=Decimal(re.search(r'^real ([\d.]+)',Path('source-receipts/preparation.time').read_text(),re.M)[1])
    for ordinal in SURVIVORS:
        original=AUTHOR/f'L{ordinal}'
        a=original/'budget-rescue' if ordinal==4 else original
        f=Path(f'author/L{ordinal}')
        pins=json.loads((f/'pins.json').read_text())
        cut=axes,roster[ordinal]
        cap_path=a/'row-cap-physical-slice-dense-branch.pkl'
        assert sha(cap_path)==pins['cap_sha']
        assert read(cap_path)['physical_cut']==cut
        seed=original/'dense-saturated-frontier.pkl'
        assert sha(seed)==pins['seed_sha']
        if ordinal==4:
            assert sha(a/seed.name)==pins['seed_sha']
        assert (f/'joint-label-roster.tsv').read_bytes()==(Path('author/L0/joint-label-roster.tsv')).read_bytes()
        replay=(f/'replay.out').read_text()
        native=(f/'native-replay.out').read_text()
        if ordinal==4:
            kind='product'
            cm=re.search(r'(?m)^independent exact native product cap tables ([a-f0-9]+)((?: \d+){8})$',native)
            factor_count,cap_n,wires,accepted,linked,minimum,pair_limit,total_limit=map(int,cm[2].split())
            product_candidates=lookup(f/'native-product-forecast.tsv')
            assert (linked,minimum)==(len(product_candidates),int(product_candidates[0]['projected_products']))
            assert (factor_count,accepted,pair_limit,total_limit)==(13,5027428,8000000,40000000) and linked>0
            assert accepted==pins['native_used']
            assert all(int(row['projected_products'])>pair_limit or int(row['projected_cumulative'])>total_limit for row in product_candidates)
            refused_pair=''
            forecast=minimum
            visited=threshold=''
        else:
            kind='row'
            cm=re.search(r'(?m)^independent exact native cap tables ([a-f0-9]+) (\d+) (\d+) (\d+) (\d+) \((\d+), (\d+)\) (\d+) (\d+) (\d+)$',native)
            factor_count,cap_n,wires,accepted,a0,a1,forecast,visited,threshold=map(int,cm.groups()[1:])
            assert threshold==500001 and visited<=forecast and forecast==pins['native_refused']
            refused_pair=repr((a0,a1))
        assert pins['native_kind']==kind and cm[1]==pins['cap_sha']
        assert f'whole original L{ordinal} input {cm[1]} {cut!r}' in replay
        n_join=len(re.findall(r'(?m)^native accepted ',native))
        assert n_join==88-factor_count
        native_s=Decimal(re.search(r'(?m)^native source and cap independent seconds ([\d.]+)$',native)[1])
        cap_rows.append((ordinal,kind,pins['rows'],pins['peak'],n_join,accepted,cm[1],factor_count,cap_n,wires,refused_pair,forecast,visited,threshold,native_s))
        n=pins['passes']
        counts=[tuple(map(int,t)) for t in re.findall(r'(?m)^stage counts (\d+) (\d+) (\d+) (\d+) (\d+) (\d+) (\d+)$',replay)]
        times={int(i):Decimal(t) for i,t in re.findall(r'(?m)^independent stage wall seconds (\d+) ([\d.]+)$',replay)}
        assert tuple(row[0] for row in counts)==tuple(times)==tuple(range(1,n+1))
        author_stages=Decimal(0)
        for row in counts:
            stage=row[0]
            logs=(f/f'pass{stage}.out').read_text()
            split,terminal=('split-frontier.pkl','unsharded-result.pkl') if stage==1 else (f'pass{stage}-split.pkl',f'pass{stage}-result.pkl')
            for artifact in (split,terminal):
                assert f'preserved checkpoint {artifact} {sha(a/artifact)}' in logs
                assert read(a/artifact)['physical_cut']==cut
            refused=[literal_eval(x) for x in re.findall(r'(?m)^(?:bounded refusal|follow refused) (\(.*\)) (?:cumulative|work) \d+$',logs)]
            assert refused==list(read(a/terminal)['refused_pairs'])
            assert sum(x[3] for x in refused)==row[-1]
            independent=[m.groups() for m in re.finditer(
                rf'(?m)^independent exact refusal {stage} (\(\d+, 0\)|\(\d+, 1\)) (\(\d+, 0\)|\(\d+, 1\)) (\d+) (\d+) (\d+) (500001) rows author visits (\d+)$',
                replay)]
            assert len(independent)==len(refused)
            for receipt,verified in zip(refused,independent,strict=True):
                x,y,forecasted,visits,permitted,rows,author_visits=verified
                assert (literal_eval(x),literal_eval(y),int(forecasted),int(author_visits))==receipt[:4]
                refusal_rows.append((ordinal,stage,x,y,forecasted,author_visits,visits,permitted,rows))
            author_stage=Decimal(re.search(r'(?:total process|follow) seconds ([\d.]+)',logs)[1])
            author_stages+=author_stage
            stage_rows.append((ordinal,*row,len(refused),times[stage],author_stage))
        endpoint=a/terminal
        end_sha=sha(endpoint)
        assert end_sha==pins['terminal_sha']
        fs=read(endpoint)['factors']
        exotic=Decimal(0)
        author_exotic=Decimal(0)
        if pins['mode']=='scalar':
            rm=re.search(rf'(?m)^whole original L{ordinal} raw \((-?\d+), (-?\d+)\) (\d+) elapsed ([\d.]+)$',replay)
            real,imag,den=map(int,rm.groups()[:3])
            assert fs==[((),{():(real,imag)},den)]
            assert pins['expected_raw']==real and pins['expected_imag']==imag
            cont=Decimal(rm[4])
        else:
            rm=re.search(rf'(?m)^whole original L{ordinal} exact terminal .* ready {end_sha} {N} elapsed ([\d.]+)$',replay)
            cont=Decimal(rm[1])
            tri=(f/'extra-replay.out').read_text()
            tm=re.search(rf'(?m)^whole original L{ordinal} .* raw (-?\d+) (-?\d+) (\d+) elapsed ([\d.]+)$',tri)
            real,imag,den=map(int,tm.groups()[:3])
            exotic=Decimal(tm[4])
            assert 'both author signed sums agree with independent third anchor' in (f/'triangle-audit.out').read_text()
            tp=f/'terminal.time'
            if tp.exists():
                author_exotic=Decimal(re.search(r'(?m)^real ([\d.]+)',tp.read_text())[1])
            else:
                author_exotic=Decimal(re.search(r'(?m)^elapsed ([\d.]+)',(f/'terminal.out').read_text())[1])
            special_costs.append((f'L{ordinal}','two_complete_triangle_pivots',author_exotic))
        assert den==N and imag==0
        author_native=Decimal(re.search(r'elapsed seconds ([\d.]+)',(f/'contraction.receipt').read_text())[1])
        if ordinal==4:
            original_guard=Decimal(re.search(r'elapsed seconds ([\d.]+)',(f/'original-contraction.receipt').read_text())[1])
            special_costs.extend((('L4','original_no_admitted_join_guard',original_guard),('L4','capture_only_repeat',author_native)))
            author_native+=original_guard
        root_wall=Decimal(re.search(r'(?m)^real ([\d.]+)',(f/'solve.time').read_text())[1])
        costs.append((ordinal,author_native,author_stages,author_exotic,root_wall,native_s,cont,exotic))
        verdict[ordinal]=(ordinal,repr(roster[ordinal]),real,imag,den,pins['mode'],end_sha,native_s,cont,exotic,author_native,author_stages,author_exotic)
    ordered=[verdict[i] for i in range(8)]
    real=sum(row[2] for row in ordered)
    imag=sum(row[3] for row in ordered)
    normal=lookup('geometry.tsv')[0]
    divisor=int(normal['physical_divisor']); cover=int(normal['full_cover_weight'])
    assert (int(normal['phase']),divisor,cover)==(1,2**132,192)
    v=Fraction(real,N*divisor)
    shot=cover*v
    assert imag==0
    all_cost=[sum(row[i] for row in costs) for i in range(1,8)]
    save('scalar.tsv','ordinal original_tuple raw_real raw_imag factor_denominator terminal_mode source_or_terminal_sha256 native_seconds continuation_seconds extra_seconds author_native_seconds author_continuation_seconds author_extra_seconds',ordered)
    save('cap.tsv','ordinal guard_kind selected_rows largest_selected_factor native_accepted_joins native_accepted_products cap_sha256 cap_factors cap_rows degree_two_axes refused_pair refused_or_minimum_projected_products independent_threshold_visits independent_threshold_rows independent_native_seconds',cap_rows)
    save('work.tsv','ordinal pass inverse_splits retained_joins exact_folds output_factors retained_projected_products refused_attempted_products refusal_count independent_wall_seconds author_wall_seconds',stage_rows)
    save('timing.tsv','ordinal author_guard author_continuation author_extra author_solve_wall independent_source_guard independent_continuation independent_extra',costs)
    save('retally.tsv','group component raw_real raw_imag denominator reduced_raw_real exact_physical_base_real cover_weight weighted_real weighted_imag author_prep author_guard author_continuation author_extra author_sum_components author_sum_solve_walls',[(GROUP,14,real,imag,N,Fraction(real,N),v,cover,shot,0,author_prep,*all_cost[:3],author_prep+sum(all_cost[:3]),all_cost[3])])
    assert len(refusal_rows)==sum(row[-3] for row in stage_rows)
    save('refusals.tsv','ordinal pass left right projected_products author_visits independent_visits independent_support_passes independent_row_threshold',refusal_rows)
    save('special-author-costs.tsv','scope operation measured_seconds',special_costs)
    print('guard counts',len(cap_rows),'retained stage counts',len(stage_rows),'independent continuation row refusals',len(refusal_rows))
    print('measured independent native continuation extra',*all_cost[4:], 'total',sum(all_cost[4:]))
    print('whole original group raw',real,imag,N,'reduced',Fraction(real,N))
    print('exact standalone geometric cover contribution',shot,0)
    print('measured author components preparation guard continuation extra',author_prep,*all_cost[:3], 'total',author_prep+sum(all_cost[:3]))

if __name__=='__main__':
    main()
