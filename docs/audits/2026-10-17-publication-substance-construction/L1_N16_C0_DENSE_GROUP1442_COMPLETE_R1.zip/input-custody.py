"""Bind the frozen source, independently prepared roster and geometric inputs."""
from ast import literal_eval
from csv import DictReader
from hashlib import file_digest, sha256
from io import BytesIO
import json
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile

SOURCE=Path('/private/tmp/l1-component14-remaining.fvZB2B/group-1442')
FRONTIER='a982400d4a30421c31198670e1fc8b2be290ff792dbf3810c8bbe61a5c732486'
PREP='11a4aa7e219c2a727a8a118a9910a8665bef7ed135ebd5531b3d30d926cfb56b'

def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

def table(path):
    with path.open() as stream:
        return list(DictReader(stream,delimiter='\t'))

def main():
    packet=json.loads(Path('continuity-packet.json').read_text())
    commit=packet['source']['head']
    rows=[]
    for name,info in packet['owned_state'].items():
        content=check_output(['git','-C',packet['checkout'],'show',f'{commit}:{name}'])
        digest=sha256(content).hexdigest()
        assert digest==info['sha256']
        rows.append((Path(name).name,digest))
        print('publication operand',Path(name).name,digest,len(content))
        if 'DENSE_GEOMETRY_COVER' in name:
            with ZipFile(BytesIO(content)) as outer, ZipFile(BytesIO(outer.read('ACTUAL_REVIEW.zip'))) as actual:
                with ZipFile(BytesIO(actual.read('candidate.zip'))) as geometry:
                    for table_name in ('components.tsv','ordered-edges.tsv','gamma-pairs.tsv'):
                        assert geometry.read(table_name)==(Path('source-receipts')/table_name).read_bytes()
        if 'DENSE_REUSE_PILOT' in name:
            with ZipFile(BytesIO(content)) as pilot:
                assert pilot.read('census/cut-plan.tsv')==Path('source-receipts/cut-plan.tsv').read_bytes()
    rows.append(('L1_N16_C0_DENSE_FACTOR_INPUTS_INDEPENDENT_R1.zip','a9088fd54fbdb92c2a74fc7331f9793c950ba790cd5d89a8143f32af5fc93983'))
    receipts=Path('source-receipts')
    archive=receipts/'preparation-independent.zip'
    assert sha(archive)==PREP
    with ZipFile(archive) as prep:
        files=prep.read('MANIFEST.sha256').decode().splitlines()
        names=set()
        for line in files:
            digest,name=line.split(maxsplit=1)
            assert sha256(prep.read(name)).hexdigest()==digest
            assert name not in names
            names.add(name)
        assert len(prep.namelist())==len(names)+1 and set(prep.namelist())==names|{'MANIFEST.sha256'}
        for name in ('original-roster.txt','original-labels.tsv','prepared-roster.tsv'):
            assert prep.read(f'group-1442/{name}')==Path(name).read_bytes()
    rows.append((archive.name,PREP))
    with Path('source-archives.tsv').open('w') as out:
        print('archive','sha256',sep='\t',file=out)
        for row in rows: print(*row,sep='\t',file=out)
    original=SOURCE/'dense-saturated-frontier.pkl'
    cached=SOURCE/'cached-original-roster/dense-saturated-frontier.pkl'
    assert sha(original)==sha(cached)==FRONTIER
    direct=table(Path('zero-readback.tsv'))
    accepted=table(receipts/'ordinal-roster.tsv')
    assert len(direct)==len(accepted)==8
    for i,(here,there) in enumerate(zip(direct,accepted,strict=True)):
        assert int(here['ordinal'])==i==int(there['original_ordinal'])
        assert literal_eval(here['original_tuple'])==literal_eval(there['original_joint_L_tuple'])
        physical=literal_eval(here['empty_factors'])
        assert physical==literal_eval(there['empty_prepared_factors'])
        assert int(here['total_selected_rows'])==int(there['prepared_selected_rows'])
        assert int(here['largest_factor'])==int(there['largest_prepared_factor'])
    our_geometry,=table(Path('geometry.tsv'))
    prep_geometry,=[row for row in table(receipts/'geometry.tsv') if row['group']=='1442']
    assert (our_geometry['group'],our_geometry['component'],our_geometry['partner'],our_geometry['full_cover_weight'])==(
            prep_geometry['group'],prep_geometry['component'],prep_geometry['gamma3_partner'],prep_geometry['weight'])
    assert (our_geometry['phase'],our_geometry['physical_divisor'])==(prep_geometry['signed_geometric_phase'],str(2**132))
    print('original and cached prepared bytes',FRONTIER)
    print('independent prepared custody, manifest members',len(names),'all eight original coordinates, zeros and geometry agree',PREP)

if __name__=='__main__':
    main()
