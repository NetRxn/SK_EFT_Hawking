from core import *
from family import edges
done={tuple(map(int,l.split()[:2])) for l in Path('/private/tmp/l1-c0-dual.QWJPq5ha/complete-isolated.tsv').read_text().splitlines()}
done|={tuple(map(int,l.split()[:2])) for l in Path('/private/tmp/l1-c0-core.1zohnyO1/zero-orbits.tsv').read_text().splitlines()}
todo=[r for r in residual if r[:2] not in done]
assert len(todo)==10994 and sum(r[2] for r in todo)==947355
if __name__=="__main__":
    shape_count=Counter()
    shape_pairs=Counter()
    even=[];disjoint=[]
    for r in todo:
        a,b,w,A,B,ca,cb,la,lb=r
        pair=tuple(sorted(tuple(sorted(shape(c) for c in comps(C))) for C in (ca,cb)))
        shape_pairs[pair]+=1
        for C in comps(ca)+comps(cb):shape_count[shape(C)]+=1
        if all(n%2==0 for row in A+B for n in row):even.append(r)
        if not ((set(edges(A))|set(edges(B)))&(set(ca)|set(cb))):disjoint.append(r)
    print("residual shape pairs",shape_pairs.most_common(10))
    print("individual components",shape_count.most_common(10))
    print("all-even",len(even),sum(r[2] for r in even))
    print("coframe-disjoint",len(disjoint),sum(r[2] for r in disjoint))
    for r in disjoint[:12]:print(r[:3],r[5:7])
