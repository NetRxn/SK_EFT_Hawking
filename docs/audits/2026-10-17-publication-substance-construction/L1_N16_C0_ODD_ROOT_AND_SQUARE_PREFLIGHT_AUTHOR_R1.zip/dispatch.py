from collections import Counter
from contextlib import redirect_stdout
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import factorial,prod
from pathlib import Path
from core import decode,local
from family import co,edges
from scalar import perms,local_id
from network import network

@lru_cache(None)
def canonical(code,spec):
    m=decode(code)
    out=[]
    for perm in perms:
        axes=[sum(((v>>i)&1)<<perm[i] for i in range(3)) for v in range(8)]
        inds=[]
        for row in m:
            t=[0]*3
            for i,n in enumerate(row):t[perm[i]]=n
            inds.append(local_id(t))
        for shift in range(8):
            c=sum(n<<(6*(v^shift)) for n,v in zip(inds,axes))
            s=tuple(sorted((tuple(sorted((axes[u]^shift,axes[v]^shift))),j) for (u,v),j in spec))
            t=tuple((e,1-j if j<2 else j) for e,j in s)
            out.append((c,min(s,t)))
    return min(out)

def factors(r,scalar_only=False):
    a,b,w,A,B,ca,cb,la,lb=r
    ea,eb=edges(A),edges(B)
    mult=F(prod(co[x+y][0,0] for _,x,y in la+lb),prod(factorial(n) for row in A+B for n in row))
    options=[]
    for e in set(ca)|set(cb):
        pa,pb=ca.get(e,(0,0)),cb.get(e,(0,0))
        da,db=sum(ea.get(e,(0,0))),sum(eb.get(e,(0,0)))
        const=prod(co[n][0,0] for n in pa+pb)
        if not (sum(pa) and sum(pb)):
            assert min(da,db)<4
            mult*=const
        elif not (da or db):
            mult*=sum(prod(co[n].get((x,y),0) for n in pa+pb)/F(((2*x+1)*(2*y+1))**4)
                      for x,y in product(range(3),repeat=2))
        else:
            assert da in (0,2) and db in (0,2)
            row=[((),(),const)]
            if da and db:
                assert pa==pb==(2,2)
                row.extend(( ((e,j),),((e,j),),F(1,d**6)) for j,d in ((0,3),(1,3),(2,4)))
            elif da:
                assert pa==(2,2)
                wt=prod(3*co[n][1,0] for n in pb)/3**7
                row.extend((((e,j),),(),wt) for j in (0,1))
            else:
                assert pb==(2,2)
                wt=prod(3*co[n][1,0] for n in pa)/3**7
                row.extend(((),((e,j),),wt) for j in (0,1))
            options.append(row[:1] if scalar_only else row)
    keys=Counter()
    for choices in product(*options):
        left=tuple(sorted(x for row in choices for x in row[0]))
        right=tuple(sorted(x for row in choices for x in row[1]))
        factor=mult*prod(row[2] for row in choices)
        ka,kb=sorted((canonical(a,left),canonical(b,right)))
        keys[ka,kb]+=factor
    return keys
