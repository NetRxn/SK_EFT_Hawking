from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations,product
from math import factorial,prod
from pathlib import Path
from core import decode,strip
from coframe import sign,fill,W
from family import co

MAX_ROWS=150_000
MAX_PRODUCTS=2_000_000
MAX_BITS=384

def enc(x):
    n=0
    for i in x:n=4*n+i
    return n
def state(label,mask,p=0):return (label<<12)|(mask<<4)|p
def zadd(out,k,r,i):
    if not (r or i):return
    if k in out:
        a,b=out[k];r+=a;i+=b
    if r or i:out[k]=(r,i)
    else:out.pop(k,None)
    if len(out)>MAX_ROWS:raise RuntimeError("row cap")

SAME=defaultdict(dict)
for d,l,u,v,r,i in (map(int,x.split()) for x in Path("edge.tsv").read_text().splitlines()):
    SAME[d][state(l,u),state(0,v)]=(r,i)
MIX={}
for a,b,u,v,r,i in (map(int,x.split()) for x in Path("mixed.tsv").read_text().splitlines()):
    MIX[state(a,u),state(b,v)]=(r,i)
V=defaultdict(list)
for chi,a,b,i,s in (map(int,x.split()) for x in Path("bivectors.tsv").read_text().splitlines()):
    V[chi,i].append((a,b,s))

@lru_cache(None)
def decorated(owner,chi):
    out={}
    for l,u,v,a,b,r,i in (map(int,x.split()) for x in Path(f"decorated-{owner}-{chi}.tsv").read_text().splitlines()):
        out[state(l if owner==0 else 0,u,a),state(l if owner==1 else 0,v,b)]=(r,i)
    return out

inv=defaultdict(list)
for i,a,b,r,s in (map(int,row.split()) for row in Path("imaginary-trace.tsv").read_text().splitlines()):
    inv[a,b].append((i,r,s))
OWN=defaultdict(dict)
for owner,chi,l,u,v,p,q,r,i in (map(int,x.split()) for x in Path("own.tsv").read_text().splitlines()):
    OWN[owner,chi][state(l if owner==0 else 0,u,p),state(l if owner==1 else 0,v,q)]=(r,i)
NEW=defaultdict(dict)
for a,b,chi,u,v,m,n,r,i in (map(int,x.split()) for x in Path("odd-edge.tsv").read_text().splitlines()):
    NEW[a,b,chi][state(u,m),state(v,n)]=(r,i)
def local(m,special,chi):
    out={(0,((),(),())):(1,0)}
    for k,n in enumerate(m):
        if not n:continue
        j,l=[i for i in range(3) if i!=k]
        if k==special:
            assert n==1
            stage=[[(2*a+b,(A,),(B,),r*t*(-1)**k,s*t*(-1)**k)
                    for a,b in product(range(2),repeat=2)
                    for i,r,s in inv[a,b] for A,B,t in V[chi,i]]]
        else:
            assert n%2==0
            stage=[[(0,u,v,z,0) for u,v,z in W]]*(n//2)
        for actions in stage:
            nxt={}
            for (p,labels),(r,s) in out.items():
                for q,u,v,c,d in actions:
                    x=list(labels)
                    x[j]=tuple(sorted(x[j]+u));x[l]=tuple(sorted(x[l]+v))
                    zadd(nxt,(p|q,tuple(x)),r*c-s*d,r*d+s*c)
            out=nxt
    return out

def inputs(m,specials=(),mutant=-1):
    loads=[[sum(row)-x for x in row] for row in m]
    fs=[];inc=[[] for _ in m];scale=1
    special=dict(specials);at={}
    for u in range(8):
        for k in range(3):
            v=u^(1<<k)
            if u>v:continue
            a,b=loads[u][k],loads[v][k]
            d=a+b
            if not d:continue
            e=(u,v)
            if e in special:
                chi=special[e]
                if chi<2:
                    assert d==2 and min(a,b)==0 and u not in at and v not in at
                    t=OWN[int(b>0),chi];den=256;at[u]=at[v]=(k,chi)
                else:
                    assert d==4 and (a,b) in ((4,0),(0,4),(2,2))
                    t=NEW[a,b,chi-2];den=49152
            elif (a,b,-1) in NEW:t=NEW[a,b,-1];den=64 if d==2 else 12288
            elif a==b==2:t=MIX;den=12288
            elif min(a,b)==0 and d in (2,4):
                z=SAME[d];den=64 if d==2 else 12288
                t=z if a else {(j,i):v for (i,j),v in z.items()}
            else:raise RuntimeError("unsupported edge shape")
            edge_index=len(fs)
            ids=(2*edge_index,2*edge_index+1)
            fs.append((ids,t,f"e{u}{v}"))
            scale*=den
            for x,i in ((u,0),(v,1)):
                allowed=defaultdict(set)
                for key in t:
                    label,mid=divmod(key[i],1<<12)
                    mask,p=divmod(mid,16)
                    allowed[label,p].add(mask)
                inc[x].append((ids[i],k,d,e in special and special[e]<2,allowed))
    for x in range(8):
        ids=tuple(z[0] for z in inc[x])
        ds=tuple(z[2] for z in inc[x]);assert sum(ds)==8
        t={};k,chi=at.get(x,(-1,-1));rows=local(m[x],k,chi)
        preflight=0;plans=[]
        for (p,labels),(r,i) in rows.items():
            ls=[enc(labels[k]) for _,k,_,_,_ in inc[x]]
            ps=[p if marked else 0 for _,_,_,marked,_ in inc[x]]
            allowed=[allow[l,q] for (i,k,d,marked,allow),l,q in zip(inc[x],ls,ps)]
            if not all(allowed):continue
            order=sorted(range(len(allowed)),key=lambda i:len(allowed[i]))
            front=order[:-1];last=order[-1]
            preflight+=prod(len(allowed[k]) for k in front)
            plans.append((r,i,ls,ps,allowed,front,last))
        if preflight>MAX_PRODUCTS:raise RuntimeError(f"site complement product cap {x} {preflight}")
        for r,i,ls,ps,allowed,front,last in plans:
            for partial in product(*(allowed[j] for j in front)):
                mask=0
                for a in partial:
                    if mask&a:break
                    mask|=a
                else:
                    final=255^mask
                    if final not in allowed[last]:continue
                    masks=[0]*len(ids)
                    for a,k in zip(partial,front):masks[k]=a
                    masks[last]=final
                    s=1;prev=0
                    for a in masks:
                        s*=sign(prev,a);prev|=a
                    key=tuple(state(l,a,q) for l,a,q in zip(ls,masks,ps))
                    phase=1 if x==mutant else s
                    zadd(t,key,r*phase,i*phase)
        print("site",x,"local rows",len(rows),"complement trials",preflight,"factor rows",len(t))
        fs.append((ids,t,f"s{x}"))
    return fs,scale

@lru_cache(None)
def groups_keys(keys,pick):
    return Counter(tuple(k[i] for i in pick) for k in keys)

def triangle(fs):
    if set().union(*(set(x[0]) for x in fs)) != {
        v for v in set().union(*(set(x[0]) for x in fs))
        if sum(v in x[0] for x in fs)==2
    }: return None
    plans=[]
    total_input=sum(len(f[1]) for f in fs)
    if total_input>MAX_ROWS:raise RuntimeError(f"triangle resident row cap {total_input} "+
        str([(f[0],len(f[1])) for f in fs]))
    for i in range(3):
        a,b,c=[fs[(i+j)%3] for j in range(3)]
        ab=tuple(sorted(set(a[0])&set(b[0])))
        ac=tuple(sorted(set(a[0])&set(c[0])))
        bc=tuple(sorted(set(b[0])&set(c[0])))
        if not (ab and ac and bc): continue
        ap=[a[0].index(x) for x in ac];aq=[a[0].index(x) for x in ab]
        bp=[b[0].index(x) for x in bc];bq=[b[0].index(x) for x in ab]
        cp=[c[0].index(x) for x in ac];cq=[c[0].index(x) for x in bc]
        A=Counter(tuple(k[i] for i in ap) for k in a[1])
        B=Counter(tuple(k[i] for i in bp) for k in b[1])
        width=[min(A[tuple(k[i] for i in cp)],B[tuple(k[j] for j in cq)]) for k in c[1]]
        plans.append((sum(width),max(width,default=0),a,b,c,ap,aq,bp,bq,cp,cq))
    if not plans:return None
    w,peak,a,b,c,ap,aq,bp,bq,cp,cq=min(plans,key=lambda x:x[:2])
    if w>4_000_000 or peak>MAX_PRODUCTS:raise RuntimeError(f"triangle work cap {w} {peak}")
    def group(f,p,q):
        d=defaultdict(dict)
        for k,z in f[1].items():
            d[tuple(k[i] for i in p)][tuple(k[j] for j in q)]=z
        return d
    A,B=group(a,ap,aq),group(b,bp,bq)
    bits=sum(max((abs(r).bit_length()+abs(i).bit_length()+1 for r,i in f[1].values()),
                 default=0) for f in fs)+w.bit_length()
    if bits>MAX_BITS:raise RuntimeError("triangle integer cap")
    rr=ii=matched=0
    for k,(c1,c2) in c[1].items():
        aa=A[tuple(k[i] for i in cp)];bb=B[tuple(k[j] for j in cq)]
        if len(aa)>len(bb):aa,bb=bb,aa
        for key,(ar,ai) in aa.items():
            z=bb.get(key)
            if z is None:continue
            br,bi=z
            r,i=ar*br-ai*bi,ar*bi+ai*br
            rr+=r*c1-i*c2;ii+=r*c2+i*c1;matched+=1
    print("triangle preflight",w,"peak row work",peak,"resident input rows",total_input,"signed products",matched)
    return rr,ii

def contraction(fs,reverse=False):
    maxrows=max(len(a[1]) for a in fs)
    if reverse:fs.reverse()
    while len(fs)>1:
        if len(fs)==3:
            final=triangle(fs)
            if final is not None:
                print("measured peak populated rows",maxrows)
                return final
        options=[]
        for i,j in combinations(range(len(fs)),2):
            a,b=fs[i],fs[j]
            s=tuple(sorted(set(a[0])&set(b[0])))
            if not s:continue
            p=tuple(a[0].index(x) for x in s);q=tuple(b[0].index(x) for x in s)
            P=Counter(tuple(k[r] for r in p) for k in a[1])
            Q=Counter(tuple(k[r] for r in q) for k in b[1])
            w=sum(n*Q[k] for k,n in P.items())
            options.append((w,i,j,s,p,q))
        if options:w,i,j,s,p,q=min(options)
        else:
            i,j=0,1;s=p=q=();w=len(fs[i][1])*len(fs[j][1])
        A,B=fs[i],fs[j]
        if w>MAX_PRODUCTS:raise RuntimeError(f"join products cap {w}")
        aa=max(((abs(z[0])+abs(z[1])).bit_length()+1 for z in A[1].values()),default=0)
        bb=max(((abs(z[0])+abs(z[1])).bit_length()+1 for z in B[1].values()),default=0)
        if aa+bb+w.bit_length()>MAX_BITS:raise RuntimeError("height cap")
        ids=tuple(sorted(set(A[0])^set(B[0])))
        take=[(0,A[0].index(v)) if v in A[0] else (1,B[0].index(v)) for v in ids]
        h=defaultdict(list)
        for v,z in B[1].items():h[tuple(v[k] for k in q)].append((v,z))
        out={}
        for u,(ar,ai) in A[1].items():
            for v,(br,bi) in h[tuple(u[k] for k in p)]:
                pair=(u,v)
                key=tuple(pair[t][k] for t,k in take)
                zadd(out,key,ar*br-ai*bi,ar*bi+ai*br)
        name=A[2]+B[2]
        print("sew",name,"width",len(ids),"matched",w,"rows",len(out))
        maxrows=max(maxrows,len(out))
        fs=[t for k,t in enumerate(fs) if k not in (i,j)]+[(ids,out,name)]
    assert not fs[0][0]
    print("measured peak populated rows",maxrows)
    return fs[0][1].get((),(0,0))

def network(code,specials=(),reverse=False,mutant=-1,tile=None):
    fs,scale=inputs(decode(code),specials,mutant)
    if tile is not None:
        variable,bit,value=tile
        assert sum(variable in f[0] for f in fs)==2 and 0<=bit<8 and value in (0,1)
        out=[]
        for ids,table,name in fs:
            if variable in ids:
                j=ids.index(variable)
                cut={k:z for k,z in table.items() if ((k[j]>>(4+bit))&1)==value}
                print("tile",tile,name,"retained",len(cut),"of",len(table))
                out.append((ids,cut,name))
            else:out.append((ids,table,name))
        fs=out
    r,i=contraction(fs,reverse)
    assert i==0
    return F(r,scale)

if __name__=="__main__":
    code=6212693790810
    for j in (0,1):
        own=tuple((e,j) for e in ((0,4),(1,5),(2,6),(3,7)))
        rem=tuple((e,j+2) for e in ((0,4),(1,5),(2,6),(3,7)))
        print("pilot channels",j,network(code,own),network(37086699520,rem),flush=True)
