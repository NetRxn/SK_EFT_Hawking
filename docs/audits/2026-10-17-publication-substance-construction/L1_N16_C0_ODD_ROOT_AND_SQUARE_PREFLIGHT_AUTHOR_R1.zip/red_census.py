from collections import Counter
from multi import todo
from projection_full import compute
from core import comps
from family import edges
rows=[]
def classify(r,s):
    a,b,w,A,B,ca,cb,la,lb=r
    x,y=s
    ea,eb=edges(A),edges(B)
    if any(n%2 for v in A+B for n in v):return "odd roots"
    if any(sum(t)>4 for t in list(ea.values())+list(eb.values())):return "degree exceeds four"
    for e in set(x)|set(y):
        p,q=x.get(e,(0,0)),y.get(e,(0,0))
        u,v=sum(ea.get(e,(0,0))),sum(eb.get(e,(0,0)))
        if sum(p) and sum(q) and (u or v):
            if u not in (0,2) or v not in (0,2):return "dual high edge"
            if u and v and p!=q:return "dual two unequal"
            if (u and p!=(2,2)) or (v and q!=(2,2)):return "dual root not 2"
        elif not (sum(p) and sum(q)) and min(u,v)>=4:return "single both high"
    return "admit"
ct=Counter();mass=Counter()
for r in todo:
    out=compute(r)
    if out is None or not any(out[0]) or any(len(x)!=1 for c in out[0] for x in comps(c)):continue
    s,_,_=out
    key=classify(r,s)
    rows.append((r,s,key));ct[key]+=1;mass[key]+=r[2]
assert len(rows)==184
if __name__=='__main__':
    print(ct,mass)
    d=Counter()
    for r,s,key in rows:
        if key!='admit':continue
        ea,eb=(edges(m) for m in r[3:5])
        n=0
        for e in set(s[0])&set(s[1]):
            if sum(ea.get(e,(0,0))) or sum(eb.get(e,(0,0))):n+=1
        d[n]+=1
        if n and d[n]<=2:print("nontrivial example",r[:3],s,ea,eb)
    print("admitted dual overlaps",d)
