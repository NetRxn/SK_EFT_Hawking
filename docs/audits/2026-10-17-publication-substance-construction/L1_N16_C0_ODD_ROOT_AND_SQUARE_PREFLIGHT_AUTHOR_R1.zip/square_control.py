from collections import defaultdict,Counter
from functools import lru_cache
from fractions import Fraction as F
from itertools import product,combinations_with_replacement
from pathlib import Path
from src.core.formulas import original_spin4_link,original_plaquette,original_quaternion_haar_moment
from src.vestigial.original_coefficients import OriginalRegulator,Polynomial,QComplex,Symbol,matrix_multiply
reg=OriginalRegulator(temporal_axis=0)
cycle=((0,0,0,0),(0,0,0,1),(0,0,1,1),(0,0,1,0))
axis=(3,2,3,2)
coords=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),
        (F(1,2),)*4,(F(3,5),0,F(4,5),0))
gamma=reg.gamma
O=matrix_multiply(matrix_multiply(gamma[0],gamma[1]),reg.gamma5)
def z():return QComplex()
def mm(a,b):
    return tuple(tuple(sum((a[i][k]*b[k][j] for k in range(len(b))),z())
                       for j in range(len(b[0]))) for i in range(len(a)))
def transpose(a):return tuple(zip(*a))
def dagger(a):return tuple(tuple(v.conjugate() for v in row) for row in transpose(a))
def tr(a):return sum((a[i][i] for i in range(len(a))),z())
def coeff(p):
    if not p:return z()
    (key,v),=p.terms
    assert not key
    return v
R=[tuple(map(int,x.split())) for x in Path("adjoint.tsv").read_text().splitlines()]
D=[tuple(map(int,x.split())) for x in Path("fundamental-product.tsv").read_text().splitlines()]
def rep(q,j):
    if j==0:return ((QComplex(1),),)
    if j<3:
        u=q[j-1];out=[[0]*3 for _ in range(3)]
        for a,b,i,k,c in R:out[a][b]+=c*u[i]*u[k]
        return tuple(tuple(QComplex(v) for v in row) for row in out)
    u=q[0]+q[1];out=[[z() for _ in range(4)] for _ in range(4)]
    for a,b,i,k,r,s in D:out[a][b]+=QComplex(r,s)*(u[i]*u[k])
    return tuple(map(tuple,out))
vtab={(chi,i):s for chi,a,b,i,s in (
    map(int,l.split()) for l in Path("bivectors.tsv").read_text().splitlines()) if (a,b)==(0,1)}
I=defaultdict(lambda:z())
for i,a,b,r,s in (map(int,x.split()) for x in Path("imaginary-trace.tsv").read_text().splitlines()):
    I[i,a,b]=QComplex(r,s)
def fmat(j):
    if j==0:return ((QComplex(2),),)
    if j<3:
        b=[vtab.get((j-1,i),0) for i in range(3)]
        return tuple(tuple(QComplex(2*b[i]*b[k]-int(i==k)) for k in range(3)) for i in range(3))
    return tuple(tuple(sum((I[i,a,b]*I[k,c,d]*(2*vtab.get((0,i),0)*vtab.get((1,k),0))
                        for i,k in product(range(3),repeat=2)),z())
                    for b,d in product(range(2),repeat=2)) for a,c in product(range(2),repeat=2))

@lru_cache(None)
def H(a,b):
    q=a+b
    return original_quaternion_haar_moment(tuple(q.count(i) for i in range(4)))*original_quaternion_haar_moment(
        tuple(q.count(i) for i in range(4,8)))
def sparse(a,b):
    rows=defaultdict(list)
    for (i,j),n in b.items():rows[i].append((j,n))
    c=defaultdict(z)
    n=sum(len(rows[j]) for i,j in a)
    assert n<=500000
    for (i,j),v in a.items():
        for k,w in rows[j]:c[i,k]+=v*w
    return {k:v for k,v in c.items() if v},n
q2=list(combinations_with_replacement(range(8),2))
haar={(a,b):QComplex(H(a,b)) for a,b in product(q2,repeat=2) if H(a,b)}
for sample in range(2):
    links={}
    own=[];other=[]
    for i,x in enumerate(cycle):
        symbols=[[Polynomial.variable(Symbol("q",(x,0,c,j))) for j in range(4)] for c in ("L","R")]
        links[x,0]=original_spin4_link(*symbols)
        k=axis[i]
        if sample:
            a=(coords[(i+1)%6],coords[(2*i+1)%6]);b=(coords[(2*i+2)%6],coords[(i+3)%6])
        else:a=b=(coords[0],coords[0])
        own.append(a);other.append(b)
        links[x,k]=original_spin4_link(*a)
        links[reg.step(x,0)[0],k]=original_spin4_link(*b)
    raw=[]
    for i,x in enumerate(cycle):
        y=cycle[(i+1)%4]
        assert reg.step(x,axis[i])[0]==y
        h=original_plaquette(reg,x,0,axis[i],links)
        f=sum((h[a][b]*O[b][a] for a,b in product(range(4),repeat=2)),Polynomial())
        terms={}
        for key,v in (f*f).terms:
            u=tuple(sorted((4 if s.index[2]=="R" else 0)+s.index[3] for s in key if s.index[0]==x))
            w=tuple(sorted((4 if s.index[2]=="R" else 0)+s.index[3] for s in key if s.index[0]==y))
            assert len(u)==len(w)==2
            terms[u,w]=v
        raw.append(terms)
    T={(a,a):QComplex(1) for a in q2}
    work=0;peak=0
    for p in raw:
        T,w=sparse(T,p);work=max(w,work)
        T,w=sparse(T,haar);work=max(w,work);peak=max(peak,len(T))
    direct=sum((v for (a,b),v in T.items() if a==b),z())
    results=[]
    for j,d in ((0,1),(1,3),(2,3),(3,4)):
        M=fmat(j)
        A=tuple(tuple(QComplex(int(i==k)) for k in range(d)) for i in range(d))
        B=A
        for i in range(4):
            A=mm(A,mm(transpose(M),dagger(rep(own[i],j))))
            B=mm(rep(other[i],j),B)
        results.append(tr(A)*tr(B)*F(1,d**4))
    assert sum(results,z())==direct
    if not sample:assert any(results[1:])
    print("directed square conditional raw versus Schur",sample,
          "local row counts",[len(p) for p in raw],"peak raw rows",peak,
          "raw matched product maximum",work,"value",direct.storage,
          "channel values",[x.storage for x in results])
