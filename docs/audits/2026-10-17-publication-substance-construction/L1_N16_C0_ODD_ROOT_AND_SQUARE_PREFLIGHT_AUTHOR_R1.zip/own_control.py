from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import prod
from pathlib import Path
from src.core.formulas import original_quaternion_haar_moment
Q=defaultdict(list);U=defaultdict(list)
for x,a,m,q,r,i in (map(int,s.split()) for s in Path('edge_coframes.tsv').read_text().splitlines()):
    Q[x,a].append((m,q,r,i))
for a,b,q,r,i in (map(int,s.split()) for s in Path('fundamental.tsv').read_text().splitlines()):
    U[a,b].append((q,r,-i))
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
@lru_cache(None)
def mom(k):
    return prod(original_quaternion_haar_moment(tuple(k.count(i) for i in range(g,g+4)))
                for g in range(0,16,4))
def direct(owner,chi,l,ml,mh,p,q):
    a,b=divmod(l,4)
    alpha,beta=divmod(p,2);gamma,delta=divmod(q,2)
    re=im=F(0)
    for (u,j,r,i),(v,k,s,t) in product(Q[owner,a],Q[owner,b]):
        if u&v or (u|v)!=ml|(mh<<8):continue
        phase=(-1)**sum((v&((1<<i)-1)).bit_count() for i in range(16) if u>>i&1)
        w=mul((r,i),(s,t))
        for (a,r,i),(b,s,t) in product(U[delta,alpha],U[beta,gamma]):
            value=mul(w,mul((r,i),(s,t)))
            weight=F(phase,16)*mom(tuple(sorted((j,k,4*chi+a,8+4*chi+b))))
            re+=value[0]*weight;im+=value[1]*weight
    return re,im
rows=[tuple(map(int,l.split())) for l in Path('own.tsv').read_text().splitlines()]
for owner,chi in product(range(2),repeat=2):
    x=next(r for r in rows if r[:2]==(owner,chi) and r[-1])
    z=direct(*x[:-2])
    assert z==(F(x[-2],256),F(x[-1],256))
    print("direct two-anchor own-layer fundamental control",x[:-2],z)
