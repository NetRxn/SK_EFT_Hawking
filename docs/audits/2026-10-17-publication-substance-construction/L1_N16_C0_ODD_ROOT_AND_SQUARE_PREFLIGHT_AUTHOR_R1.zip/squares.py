from collections import Counter
from core import comps
from multi import todo
from projection_full import compute
from pathlib import Path
prior=Path('/private/tmp/l1-c0-multi.TIUoLhg3')
done={tuple(map(int,line.split()[:2])) for f in ('scalar-exact.tsv','reduced-exact.tsv','reduced-odd-unresolved.tsv')
      for line in (prior/f).read_text().splitlines()}

def kind(c):
    deg=Counter(v for e in c for v in e)
    if len(c)!=4 or set(deg.values())!={2}:return None
    if any(min(x)>0 for x in c.values()):return 'double-root'
    roots=Counter(e[0] if x else e[1] for e,(x,y) in c.items())
    return ('directed' if len(roots)==4 else 'zigzag', tuple(sorted(x+y for x,y in c.values())))
ct=Counter();families=[];exam={}
for r in todo:
    if r[:2] in done:continue
    ans=compute(r)
    if ans is None:continue
    C,dom,it=ans
    compset=[c for x in C for c in comps(x)]
    kinds=[kind(x) for x in compset]
    for k in kinds:
        if k:
            ct[k]+=1
            exam.setdefault(k,(r[:3],C))
    if all(len(c)==1 or kind(c) is not None and kind(c)!='double-root' for c in compset) and any(kinds):
        families.append((r,C,kinds))
print("projected residual square types",ct)
for k in ct.most_common(8):print("square example",k,exam[k[0]])
print("square-or-isolated-only orbit count",len(families),sum(r[2] for r,C,k in families))
