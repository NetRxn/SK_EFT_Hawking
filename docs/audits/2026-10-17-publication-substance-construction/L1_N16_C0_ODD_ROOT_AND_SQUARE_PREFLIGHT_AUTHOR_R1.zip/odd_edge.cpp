#define main reference_main
#include "slice_reference.cpp"
#undef main
#include <map>
using Key=std::array<int,4>;
using Table=std::map<Key,Z>;
using L=std::vector<int>;
std::vector<L> labels(int n,int min=0) {
    if(!n)return {{}};
    std::vector<L> out;
    for(int a=min;a<4;++a)for(auto xs:labels(n-1,a)){
        xs.insert(xs.begin(),a);out.push_back(xs);
    }
    return out;
}
int enc(const L& x){int a=0;for(int i:x)a=4*a+i;return a;}
unsigned qmask(int p) {
    if(!p)return 0;
    --p;return (1U<<(p/16))|(1U<<(p%16));
}
int bucket(unsigned p){
    if(!p)return 0;
    if(std::popcount(p)!=2)return -1;
    int a=std::countr_zero(p);
    int b=std::countr_zero(p&(p-1));
    return 1+16*a+b;
}
int haar192(const Quad& a,const Quad& b,int u,int v) {
    std::array<int,16> ex{};
    for(int q:{a.a,a.b,b.a,b.b,u,v})++ex[q];
    int den=1,num=1;
    for(int j=0;j<16;j+=4) {
        int total=0;
        for(int i=j;i<j+4;++i){
            if(ex[i]%2)return 0;
            total+=ex[i];
            for(int t=1;t<ex[i];t+=2)num*=t;
        }
        for(int t=4;t<4+total;t+=2)den*=t;
    }
    if(192%den)throw std::runtime_error("character moment denominator");
    return (u%4==0?2:-2)*num*(192/den);
}
struct Pairs {
    std::map<std::array<int,4>,QuadRoster> data;
    const LinearRoster& src;
    const QuadRoster& get(std::pair<int,int>a,std::pair<int,int>b){
        const std::array<int,4> k={a.first,a.second,b.first,b.second};
        if(!data.contains(k))data[k]=square_pair(src[a.first][a.second],src[b.first][b.second]);
        return data.at(k);
    }
};
Table build(Pairs& P,int d0,int d1,int chi,bool crossed){
    const auto A=labels(d0),B=labels(d1);
    U64 work=0;
    Table out;
    for(int run=0;run<2;++run){
        for(const auto& x:A)for(const auto& y:B){
            std::vector<std::pair<int,int>> factors;
            for(int i:x)factors.emplace_back(0,i);
            for(int i:y)factors.emplace_back(1,i);
            if(factors.size()==2){
                const auto& h=P.get(factors[0],factors[1]);
                if(!run){work+=h[0].size();continue;}
                for(const auto& u:h[0])out[{enc(x),enc(y),int(u.mask&255),int(u.mask>>8)}]+=u.value;
                continue;
            }
            if(crossed)std::swap(factors[1],factors[2]);
            const auto& h=P.get(factors[0],factors[1]);
            const auto& g=P.get(factors[2],factors[3]);
            for(int p=0;p<257;++p){
                if(h[p].empty())continue;
                for(int t=0;t<(chi<0?1:4);++t){
                    int u=4*std::max(0,chi)+t,v=u+8;
                    unsigned target=chi<0?0:((1U<<u)|(1U<<v));
                    int q=bucket(qmask(p)^target);
                    if(q<0||g[q].empty())continue;
                    if(!run){work+=U64(h[p].size())*g[q].size();continue;}
                    for(const auto& l:h[p])for(const auto& r:g[q]){
                        if(l.mask&r.mask)continue;
                        int coeff=chi<0?moment48(l,r):haar192(l,r,u,v);
                        unsigned mask=l.mask|r.mask;
                        out[{enc(x),enc(y),int(mask&255),int(mask>>8)}]+=
                            (l.value*r.value)*(coeff*sign(l.mask,r.mask));
                    }
                }
            }
        }
        if(!run&&work>MAX_MOMENT_PAIRS)throw std::runtime_error("odd or character edge moment cap");
    }
    for(auto i=out.begin();i!=out.end();)if(!i->second)i=out.erase(i);else ++i;
    std::cout<<"edge "<<d0<<' '<<d1<<" char "<<chi<<" crossed "<<crossed<<" candidates "<<work
             <<" rows "<<out.size()<<'\n';
    return out;
}
int main(){
    const auto source=read_coframes();
    Pairs P{{},source};
    std::ofstream out("odd-edge.tsv");
    for(auto [a,b]:{std::pair{1,1},{1,3},{3,1}}){
        auto rows=build(P,a,b,-1,false);
        if(a+b==4&&rows!=build(P,a,b,-1,true))throw std::runtime_error("odd mixed grouping");
        for(auto [k,z]:rows)out<<a<<'\t'<<b<<"\t-1\t"<<k[0]<<'\t'<<k[1]<<'\t'
                               <<k[2]<<'\t'<<k[3]<<'\t'<<z.re<<'\t'<<z.im<<'\n';
    }
    for(auto [a,b]:{std::pair{0,4},{2,2},{4,0}})for(int chi=0;chi<2;++chi){
        auto rows=build(P,a,b,chi,false);
        if(rows!=build(P,a,b,chi,true))throw std::runtime_error("remote character grouping");
        for(auto [k,z]:rows)out<<a<<'\t'<<b<<'\t'<<chi<<'\t'<<k[0]<<'\t'<<k[1]<<'\t'
                               <<k[2]<<'\t'<<k[3]<<'\t'<<z.re<<'\t'<<z.im<<'\n';
    }
}
