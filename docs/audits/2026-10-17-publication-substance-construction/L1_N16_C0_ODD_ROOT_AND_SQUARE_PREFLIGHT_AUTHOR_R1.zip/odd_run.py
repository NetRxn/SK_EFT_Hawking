from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from itertools import permutations,product
from math import prod,factorial
from pathlib import Path
from core import decode,local
from family import co
from red_census import rows
from odd_network import network
odd=[(r,s) for r,s,k in rows if k=='odd roots']
assert len(odd)==24 and sum(r[2] for r,s in odd)==816

@lru_cache(None)
def canonical(code,spec):
    m=decode(code)
    best=None
    for perm in permutations(range(3)):
        axes=[sum(((v>>i)&1)<<perm[i] for i in range(3)) for v in range(8)]
        ind=[]
        for row in m:
            p=[0]*3
            for i,n in enumerate(row):p[perm[i]]=n
            ind.append(local.index(tuple(p)))
        for shift in range(8):
            c=sum(n<<(6*(v^shift)) for n,v in zip(ind,axes))
            s=tuple(sorted((tuple(sorted((axes[u]^shift,axes[v]^shift))),j) for (u,v),j in spec))
            a=(c,min(s,tuple((e,j^1) for e,j in s)))
            best=a if best is None else min(best,a)
    return best

def roster(r,s):
    a,b,w,A,B,*_=r
    own=int(bool(s[1]))
    assert not s[1-own] and len(s[own])==4
    es=sorted(s[own])
    assert all(s[own][e]==(1,1) for e in es)
    f=F(prod(co[n][0,0] for row in A+B for n in row if n%2==0),
        prod(factorial(n) for row in A+B for n in row)*4**4)
    assert sum(n%2 for row in A+B for n in row)==8
    t=Counter()
    for chi in product(range(2),repeat=4):
        specs=[tuple((e,j+(0 if side==own else 2)) for e,j in zip(es,chi))
               for side in (0,1)]
        ka,kb=sorted(canonical(code,spec) for code,spec in zip((a,b),specs))
        t[ka,kb]+=f
    return t

all_rosters={r[:2]:roster(r,s) for r,s in odd}
configs=sorted({k for row in all_rosters.values() for p in row for k in p})

if __name__=='__main__':
    print("odd family configurations",len(configs),"weighted terms",sum(map(len,all_rosters.values())),flush=True)
    values={};refused={}
    for k in configs:
        try:
            values[k]=network(*k)
            print("signed odd layer",k,values[k],flush=True)
        except RuntimeError as e:
            refused[k]=str(e)
            print("odd layer refusal",k,e,flush=True)
    out=[];left=[]
    for r,s in odd:
        a,b,w=r[:3]
        t=all_rosters[a,b]
        if any(k not in values for p in t for k in p):
            left.append((a,b,w));continue
        value=sum(f*values[x]*values[y] for (x,y),f in t.items())
        out.append((a,b,w,value))
    print("signed odd completed configurations",len(values),"refused",len(refused))
    print("signed odd orbits",len(out),"labels",sum(w for a,b,w,z in out),
          "sign counts",Counter((z>0)-(z<0) for a,b,w,z in out))
    print("odd unresolved orbits",len(left),"labels",sum(w for a,b,w in left))
    print("odd exact subtotal",sum(w*z for a,b,w,z in out))
    for file,rows in [('odd-exact.tsv',out),('odd-refused.tsv',left)]:
        Path(file).write_text("".join(chr(9).join(map(str,r))+chr(10) for r in rows))
