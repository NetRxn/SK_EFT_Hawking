#define main reference_main
#include "slice_reference.cpp"
#undef main
#include <map>
int bucket(unsigned p){
    if(!p)return 0;
    if(std::popcount(p)!=2)return -1;
    int a=std::countr_zero(p),b=std::countr_zero(p&(p-1));
    return 1+16*a+b;
}
unsigned qmask(int p){
    if(!p)return 0;
    --p;return (1U<<(p/16))|(1U<<(p%16));
}
int main(){
    const auto src=read_coframes();
    std::map<std::pair<int,int>,U64> q;
    std::ifstream spin("adjoint.tsv"),cross("fundamental-product.tsv");
    int a,b,i,j,r,s;
    while(spin>>a>>b>>i>>j>>r){
        for(int chi=0;chi<2;++chi)++q[{4*chi+i,4*chi+j}];
    }
    while(cross>>a>>b>>i>>j>>r>>s)++q[{i,j}];
    U64 n=0;for(auto[k,w]:q)n+=w;
    std::cout<<"single-link representation source terms "<<n<<" shared q pairs "<<q.size()<<'\n';
    if(n!=112||q.size()!=36)throw std::runtime_error("source roster");
    for(int x=0;x<2;++x){
        std::array<std::array<QuadRoster,4>,4>P;
        for(int a=0;a<4;++a)for(int b=a;b<4;++b)P[a][b]=square_pair(src[x][a],src[x][b]);
        for(int anchor=0;anchor<2;++anchor)for(int d:{2,4}){
            U64 raw=0,cached=0,max_group=0;
            for(auto[k,w]:q){
                unsigned bit=(1U<<(k.first+8*anchor))^(1U<<(k.second+8*anchor));
                U64 work=0;
                for(int a=0;a<4;++a)for(int b=a;b<4;++b)
                    if(d==2)work+=P[a][b][bucket(bit)].size();
                    else for(int c=b;c<4;++c)for(int e=c;e<4;++e)
                        for(int p=0;p<257;++p){
                            int j=bucket(qmask(p)^bit);
                            if(j>=0)work+=U64(P[a][b][p].size())*P[c][e][j].size();
                        }
                cached+=work;raw+=w*work;max_group=std::max(max_group,work);
            }
            std::cout<<"spatial owner "<<x<<" rooted anchor "<<anchor<<" coframe degree "<<d
                     <<" raw matched products "<<raw<<" cached q-pair products "<<cached
                     <<" peak q-pair work "<<max_group<<" raw 50M cap "
                     <<(raw>MAX_MOMENT_PAIRS?"REFUSED":"ADMITTED")<<'\n';
        }
    }
    return 0;
}
