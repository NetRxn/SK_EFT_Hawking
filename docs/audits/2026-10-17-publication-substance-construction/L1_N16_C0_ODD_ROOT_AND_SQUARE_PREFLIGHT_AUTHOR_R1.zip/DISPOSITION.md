# Author checkpoint awaiting independent replay

All 24 odd-root cases were evaluated and the direct conditional square controls and spatial preflight are frozen. The full signed square, larger temporal block and c0 remain open.
