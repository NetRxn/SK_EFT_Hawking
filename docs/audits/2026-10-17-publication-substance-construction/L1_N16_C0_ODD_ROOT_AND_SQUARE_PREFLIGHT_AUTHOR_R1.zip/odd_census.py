from red_census import rows
from family import edges
from collections import Counter
odd=[(r,s) for r,s,key in rows if key=='odd roots']
assert len(odd)==24 and sum(r[2] for r,s in odd)==816
for r,(A,B) in odd[:8]:
    ea,eb=edges(r[3]),edges(r[4])
    print(r[:3],r[3:5],A,B,[(e,ea.get(e,(0,0)),eb.get(e,(0,0))) for e in set(A)|set(B)])
print("root locations",Counter((len(A),len(B),len(set(A)&set(B))) for r,(A,B) in odd))
