from collections import defaultdict
from itertools import product
from pathlib import Path
def zadd(out,k,r,i):
    a,b=out[k];out[k]=(a+r,b+i)
src=defaultdict(list)
for x,a,m,q,r,i in (map(int,l.split()) for l in Path('edge_coframes.tsv').read_text().splitlines()):
    src[x,a].append((m,q,r,i))
fund=defaultdict(list)
for a,b,q,r,i in (map(int,l.split()) for l in Path('fundamental.tsv').read_text().splitlines()):
    fund[q].append((a,b,r,-i))
out=[]
for owner,chi in product(range(2),repeat=2):
    t=defaultdict(lambda:(0,0))
    accepted=0
    for a in range(4):
      for b in range(a,4):
        for (u,q,r,i),(v,p,s,j) in product(src[owner,a],src[owner,b]):
            if u&v or q//8==p//8 or (q//4)%2!=chi or (p//4)%2!=chi:continue
            accepted+=1
            lo,hi=(q,p) if q<8 else (p,q)
            mask=u|v
            sign=(-1)**sum((v&((1<<n)-1)).bit_count() for n in range(16) if u>>n&1)
            A,B=(r*s-i*j)*sign,(r*j+i*s)*sign
            for (d,c,x,y),(g,f,z,w) in product(fund[lo%4],fund[hi%4]):
                # a†[alpha,delta] is conjugate U[delta,alpha],
                # c†[gamma,beta] is conjugate U[beta,gamma].
                l,m=2*c+g,2*f+d
                re,im=x*z-y*w,x*w+y*z
                zadd(t,(4*a+b,mask&255,mask>>8,l,m),A*re-B*im,A*im+B*re)
    rows=[(owner,chi,*k,*z) for k,z in sorted(t.items()) if any(z)]
    print('own fundamental owner',owner,'chi',chi,'accepted raw pairs',accepted,
          'rows',len(rows),'imaginary',sum(r[-1]!=0 for r in rows))
    out.extend(rows)
Path('own.tsv').write_text(''.join('\t'.join(map(str,r))+'\n' for r in out))
