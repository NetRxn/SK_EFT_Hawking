from collections import Counter
from functools import lru_cache
from itertools import product
from pathlib import Path
from multi import todo
from family import edges
from core import comps

D={0:1,1:2,2:5,3:10,4:21}
vals={i:tuple(k for k in range(5) if i>>k&1) for i in range(32)}
@lru_cache(None)
def allowed(kind,cap,domains):
    masks=[0]*len(domains)
    if kind=="S":
        valid=lambda r:abs(r[0]-r[1])+abs(r[2]-r[3])<=cap
    else:
        valid=lambda r:sum(r)%2==0 and 2*max(r,default=0)<=sum(r)
    for row in product(*(vals[d] for d in domains)):
        if valid(row):
            for i,k in enumerate(row):masks[i]|=1<<k
    return tuple(masks)

def compute(r):
    a,b,w,A,B,ca,cb,la,lb=r
    domains=[1]*48
    index=lambda t,v,k:24*t+3*v+k
    cons=[]
    for t,C in enumerate((ca,cb)):
        links=[[] for _ in range(8)]
        for (u,v),(x,y) in C.items():
            k=(u^v).bit_length()-1
            ids=(index(t,u,k),index(t,v,k))
            for j,n in zip(ids,(x,y)):
                domains[j]=D[n]
                if n:links[u].append(j);links[v].append(j)
        for ids in links:
            if ids:cons.append(("T",0,tuple(sorted(ids))))
    ea,eb=edges(A),edges(B)
    for u,v in set(ca)|set(cb):
        cap=min(sum(ea.get((u,v),(0,0))),sum(eb.get((u,v),(0,0))))
        k=(u^v).bit_length()-1
        cons.append(("S",cap,(index(0,u,k),index(1,u,k),index(0,v,k),index(1,v,k))))
    iterations=0
    while True:
        changed=False;iterations+=1
        for kind,cap,idx in cons:
            old=tuple(domains[i] for i in idx)
            new=allowed(kind,cap,old)
            if not all(new):return None
            if new!=old:
                for j,d in zip(idx,new):domains[j]=d
                changed=True
        if not changed:break
    reduced=[]
    for t,C in enumerate((ca,cb)):
        new={}
        for (u,v),(x,y) in C.items():
            k=(u^v).bit_length()-1
            p,q=domains[index(t,u,k)],domains[index(t,v,k)]
            if (p|q)&~1:new[u,v]=(x if p!=1 else 0,y if q!=1 else 0)
        reduced.append(new)
    return reduced,domains,iterations

if __name__=="__main__":
    zero=[];scalar=[];iso=[];classes=Counter();maxiter=0
    for r in todo:
        result=compute(r)
        if result is None:zero.append(r[:3]);continue
        (a,b),d,it=result
        maxiter=max(maxiter,it)
        if not (a or b):scalar.append(r[:3])
        elif all(len(x)==1 for x in comps(a)+comps(b)):
            iso.append(r[:3]);classes[(max(len(a),len(b)),sum(map(len,(a,b))))]+=1
    for name,rows in (("zero",zero),("scalar",scalar),("isolated",iso)):
        print(name,len(rows),sum(r[2] for r in rows))
        print("sample",rows[:5])
        Path(name+".tsv").write_text("".join(chr(9).join(map(str,r))+chr(10) for r in rows))
    print("isolated class",classes,"maximum iterations",maxiter,"cache",allowed.cache_info())
