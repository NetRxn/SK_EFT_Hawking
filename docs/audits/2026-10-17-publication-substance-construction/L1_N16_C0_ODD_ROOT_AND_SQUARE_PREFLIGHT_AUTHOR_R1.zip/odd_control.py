from fractions import Fraction as F
from itertools import product
from odd_network import network
from odd_run import canonical
code=6212693790810
es=((0,4),(1,5),(2,6),(3,7))
spec=tuple((e,0) for e in es)
a=network(code,spec,reverse=True)
assert a==F(7780827681,268435456)
b=network(code,spec,mutant=0)
assert b!=a
key=canonical(code,tuple((e,1) for e in es))
assert network(*key)==a
print("odd own-layer reverse and chirality cache",a,"one wrong local wedge",b)
