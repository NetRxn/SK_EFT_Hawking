# Exact odd-root isolated family and directed-square preflight

The primary packet `l1-c0-odd-core-author-r1.json` checked fresh
at `27012c18fa374e8341e124b510abbedeedb18d29`. This scratch
package uses the prior multi-edge, dual-overlap and residual-core
packages read-only. Their manifests reverified. The immediate
multi-edge input manifest digest is
`d4fcb8e11906827a6412a8326ff90dfaefdf02ed1d72dd984867818dd5fa9834`.
Prior acceptance and the independent review of this result
remain separate. No tracked file, prior artifact, notebook
or Lean slot was modified.

All 24 previously deferred odd-root reduced-isolated orbits
are evaluated exactly, covering 816 labeled occupations.
All are positive. The package also verifies a source-level
directed temporal square formula and measures its spatial
edge preflight. The square's full signed occupation and
the remaining temporal block are open.

## Complete odd-root geometry and shared Haar

The prior representation projection leaves four isolated
(1,1) temporal cores in a single connector for every one
of these 24 representatives. Twenty have the active
connector in B and four in A. The other temporal roots
have already been integrated or forced to scalar by
the exact prior support projection. Their local coframe
moments remain in the product.

A degree-one rooted curvature has one fundamental
representation in either the left or right chirality.
Temporal Schur pairing makes the two roots on an isolated
edge use the same chirality. With dimension d=2, the two
actual independent temporal Haar integrations supply
d^-2=1/4 per edge. The own spatial layer retains the
matrices D(a†)[alpha,delta] and D(c†)[gamma,beta] on its
two distinct anchors. The opposite layer retains the
character chi(b d) of its two distinct spatial anchors.
These factors follow from the conditional formula in
the prior residual-core package. The spatial Haar is
performed only after multiplying in all corresponding
coframes.

Each core's own spatial layer has two coframes, centered
at one endpoint of the edge. Fundamental center parity
in the chosen chirality forces one such coframe on
each original anchor, both in that chirality. Its
degree-two Haar denominator is 16 from the two coframe
quarters and 16 from the two independent coordinate
second moments, giving 256. The opposite layer has
four coframes with owner loads (0,4), (4,0) or (2,2).
Fundamental center parity forces an anchor split of
(1,3) or (3,1). The full coordinate moment may involve
more than one chiral group, so the correct common
six-coordinate moment denominator is 192. Including
the four original coframe quarters gives 49152.

The local odd rooted coefficient is the literal
fundamental matrix projection of the chiral coframe
bivector. The source trace identity is
Tr((-i sigma_i) U)=2 q_i. Its two spatial directions
are in the original order, and the world epsilon
is included explicitly at each root. The paired roots
of each edge have the same world sign. Ordinary
coframe edges with endpoint loads (1,1), (1,3) and
(3,1) are also integrated explicitly. Their total
edge degrees are even. An integrated edge supplies
an even local mask to each endpoint, so regrouping
different site contributions is even. The original
within-site wedge signs are kept in the signed
site-factor joins.

The original spatial character is
2(q_(b,0) q_(d,0) − sum_i q_(b,i) q_(d,i)).
The source check verifies this on both actual chiral
blocks. Direct raw products on both independent
anchors agree with the character-decorated table
for two same-owner and two mixed-owner entries.
Values include −3/8, 3/32, −3/32 and 3/64. The
largest direct raw candidate count is 1,048,576
under its two-million cap. Separate direct raw
controls for the own-layer fundamental tensor agree
on four imaginary entries, one for each endpoint
and chirality, all equal to −i/32. No imaginary
coefficients are discarded during sewing.

## Signed odd-root contraction and result

Each of the four core edges supplies a binary
chirality choice. For a fixed assignment the
conditional factorization gives one signed layer
contraction on each side, one with the fundamental
root matrices and one with the character factors.
Both use the original spatial links wherever
coframes also occur. Separately averaging the
original connector's spatial variables before
joining the two layers would integrate its
opposite-layer fundamental character to zero.
It would wrongly give zero for this entire family.

Canonicalizing the transported spatial and
chirality assignments leaves 83 layer
configurations and 117 weighted cached terms.
The global simultaneous chirality swap is
implemented by the source gamma_3 exchange of
the chiral blocks. The local odd signs cancel
across the eight odd roots. Spatial label
permutations preserve the complete layer top
and the paired world signs. A direct layer
contraction, reverse ordering and chirality
cache control agree on 7780827681/268435456.
Omitting the original wedge sign at one
vertex in that layer changes its value to zero.

The fourth-degree ordinary odd-owner and remote
character moment tables agree under two distinct
quadratic pairings. The largest remote source moment
preflight stays under the 50-million product
cap. For the complete 83-configuration run,
the largest measured site complement search
is 5,504 trials. The largest ordinary join
and terminal triangle each use 589,824
products or lookups. The peak populated
table has 65,536 rows and the peak terminal
resident input has 83,968 rows. This is within
the prior 150,000-row and signed arithmetic
caps. The complete run took about 32 seconds
and 106 MB peak RSS.

All 24 representative values are positive.
The first representative
`(37086699520,6212693790810)`, with weight 48,
is 916073923391047265625/4611686018427387904.
The exact weighted subtotal for all 816
occupations is

```
5771684842675958076255/9007199254740992.
```

Every original even scalar factor and original
m! divisor is retained. The factor 4^-4 is
from the four pairs of fundamental temporal
Haar orthogonalities. The eight odd rooted
divisors 1! are one. The table `odd-exact.tsv`
has every original representative and orbit
weight. `odd-refused.tsv` is empty.

## Connected temporal square reduction

The post-projection residual contains 774
directed single-root square components with
multiplicities (2,2,2,2). It also contains
2,659 square components with at least one
doubly rooted edge and numerous other
orientations and powers. In all, 588 residual
orbits have only isolated or single-root
square components. This is a geometry census,
not a signed value or an admission of all
square orientations.

For a directed square with one root per
edge and one incoming and outgoing
holonomy at every temporal anchor, write
the rooted word as a_r† V_next† b_r V_r.
Use matrix coefficient tensor F_r for the
rooted polynomial. Haar orthogonality makes
all four representation labels equal.
If their common representation is D with
dimension d, the exact conditional term is

```
d^-4
 * Tr(D(b_3) D(b_2) D(b_1) D(b_0))
 * Tr((F_0^T D(a_0†)) (F_1^T D(a_1†))
      (F_2^T D(a_2†)) (F_3^T D(a_3†))).
```

The four connector Haar pairings identify
the row indices separately from the column
indices. This produces the two displayed
traces with their different orders and
retains every original spatial anchor.
Both traces are paired with their original
spatial coframes before spatial Haar.

The canonical source control constructs
four actual rooted words on a directed
square and takes F01² at each root.
Direct coordinate Haar on the temporal
anchors agrees with this Schur formula
at both exact spatial points. The
identity-spatial conditional value is
155/9. The asymmetric rational point
gives 10792/675. The scalar channel is
16 at both, and the asymmetric spin
correction is the exact negative −8/675.
The largest direct raw root support has
408 entries. Its measured intermediate
support has at most 452 rows and 1,904
matched products. This is a conditional
curvature test with fixed internal
components. It is not the square's
full Berezin coefficient.

A concrete full signed pilot is the
representative `(37086699520,8935831015554)`,
weight 48. Its surviving core is the
directed (2,2,2,2) cycle 0→4→6→2→0.
It has no other nontrivial core. On
these four edges the own layer has
degree-two same-owner coframes and the
opposite layer has degree-four same-owner
coframes. The directed formula leaves
one representation index per endpoint
of each spatial edge. The remote site
equates the adjacent trace indices.
The own site couples the incoming and
outgoing indices through its actual
rooted projection F_r.

The exact spatial edge preflight uses
112 canonical adjoint and product-channel
source monomials with 36 distinct
quaternion pairs. Matching original
coordinate parities gives the following
maximum counts, equal for both coframe
owners and both rooted anchors:

| Coframe degree | Raw matched products | Products reusing each quaternion pair |
| --- | ---: | ---: |
| 2 | 37,600 | 11,632 |
| 4 | 43,266,176 | 14,198,720 |

The 50-million local product cap admits
these parity-matched counts. The dense
degree-four edge interface would require
35·70²·4²=2,744,000 rows and therefore
refuses the 150,000-row cap before
allocation. The next scalable route is
to assemble one signed sparse
quaternion-pair moment at a time,
combine the 36 groups into representation
matrices, and sew the spatial site
factors with the measured cycle indices.
Its populated spatial widths are
unmeasured. The complete signed pilot
value remains open. Zigzag orientations
and doubly rooted square cores have
different temporal invariant pairings,
so this directed preflight does not
qualify them.

## Residual and reproduction

The temporal A-only/B-only block now
has 10,458 unresolved orbits covering
903,819 labeled coarse survivors.
No signed bound on those survivors or
the other degree blocks follows from
this result. Full c0 remains open.

Compile `odd_edge.cpp` and
`square_width.cpp` with
`clang++ -std=c++20 -O3 -Wall -Wextra -Werror`.
The source tensor inputs are the
frozen canonical source exports.
Run `spin_source.py`, `own_control.py`,
`character_control.py` and
`square_control.py` with the exact
primary checkout on PYTHONPATH and
its venv Python with
PYTHONDONTWRITEBYTECODE=1. Run
`own.py`, `odd_run.py`,
`odd_control.py` and `squares.py`
in the scratch package. The native
routines, exact tables and measured
receipts are independently reviewable.
