from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import prod
from pathlib import Path
from src.core.formulas import original_spin4_link,original_quaternion_haar_moment
from src.vestigial.original_coefficients import OriginalRegulator,Polynomial,Symbol,matrix_multiply
reg=OriginalRegulator(temporal_axis=0)
x,y=reg.sites[0],reg.step(reg.sites[0],1)[0]
q=[[tuple(Symbol("q",(v,1,chi,i)) for i in range(4)) for chi in ("L","R")] for v in (x,y)]
U=[original_spin4_link(*(tuple(Polynomial.variable(s) for s in row) for row in chi)) for chi in q]
UV=matrix_multiply(*U)
for chi in range(2):
    tr=UV[2*chi][2*chi]+UV[2*chi+1][2*chi+1]
    explicit=sum((Polynomial.variable(q[0][chi][i])*Polynomial.variable(q[1][chi][i])*
                   (2 if i==0 else -2) for i in range(4)),Polynomial())
    assert tr==explicit
print("literal canonical character of two original directed anchors verified")
def sign(a,b):
    return (-1)**sum((b&((1<<i)-1)).bit_count() for i in range(16) if a>>i&1)
T=defaultdict(list)
for c,a,m,q0,r,i in (map(int,l.split()) for l in Path("edge_coframes.tsv").read_text().splitlines()):
    T[c,a].append((m,q0,r,i))
@lru_cache(None)
def moment(key):
    return prod(original_quaternion_haar_moment(tuple(key.count(k) for k in range(g,g+4)))
                for g in range(0,16,4))
def decode(code,d):
    return [(code>>(2*i))&3 for i in range(d-1,-1,-1)]
def direct(a,b,chi,l,k,m,n):
    target=m|(n<<8)
    terms=[[(u,q,r,i) for u,q,r,i in T[x,j] if u&target==u]
           for x,j in [(0,j) for j in decode(l,a)]+[(1,j) for j in decode(k,b)]]
    cap=prod(map(len,terms))
    assert cap<=2_000_000
    re=im=F(0)
    for row in product(*terms):
        mask=par=0;rr,ii=1,0;qs=[]
        for u,q,r,i in row:
            if u&mask:break
            sg=sign(mask,u);mask|=u;par^=1<<q;qs.append(q)
            rr,ii=(rr*r-ii*i)*sg,(rr*i+ii*r)*sg
        else:
            if mask!=target:continue
            for d in range(4):
                qa=4*chi+d;qb=qa+8
                if par!=((1<<qa)|(1<<qb)):continue
                s=2 if d==0 else -2
                w=F(s,256)*moment(tuple(sorted((*qs,qa,qb))))
                re+=rr*w;im+=ii*w
    return re,im,cap
rows=[tuple(map(int,line.split())) for line in Path("odd-edge.tsv").read_text().splitlines()]
for shape in ((0,4,0),(2,2,1)):
    chosen=[row for row in rows if row[:3]==shape]
    for a,b,c,l,k,m,n,r,i in [chosen[0],next((x for x in chosen if x!=chosen[0] and (x[-1] or x[-2]>0)),chosen[-1])]:
        x,y,w=direct(a,b,c,l,k,m,n)
        assert (x,y)==(F(r,49152),F(i,49152))
        print("direct character-decorated source check",(a,b,c,l,k,m,n),(x,y),"raw products",w)
