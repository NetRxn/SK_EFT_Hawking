# First 32 completed profiles from the 64-profile run

Run `python3 verify_author.py` to reconstruct each exact signed author sum
from its final case logs and complete anchor roster. Fixed assignments count
once and exchanged pairs count twice. All 32 rows are on the current accepted
predecessor roster. The factor lists pin the larger local raw and projected
tables. Independent review remains due before any subtraction.
