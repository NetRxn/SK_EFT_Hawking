from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shutil
import subprocess
import sys
import time

root=Path.cwd()
author=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
archive=root/'archive'
def identical(where,want):
    assert where.read_bytes()==want.read_bytes(),(where,want)
def review(i):
    work=root/f'lineage-{i}'
    work.mkdir()
    (work/'checkpoint').mkdir()
    shutil.copyfile(root/'parent.pkl',work/'nine-minimum-quotient-frontier.pkl')
    for name in ('prepare-label-tuple.py','reduce-label-frontier.py','contract-reduced-label.py','label-partition-roster.txt'):
        source=archive/'child01'/name
        identical(source,author/name)
        shutil.copyfile(source,work/name)
    q='checkpoint/quotient.py'
    identical(archive/'author'/q,author/q)
    shutil.copyfile(archive/'author'/q,work/q)

    def run(script,args,name,want_exit=0):
        start=time.perf_counter()
        with (work/name).open('xb') as out:
            run=subprocess.run([sys.executable,'-u',script,*args],cwd=work,stdout=out,stderr=subprocess.STDOUT,timeout=120)
        elapsed=time.perf_counter()-start
        assert run.returncode==want_exit,(i,name,run.returncode)
        identical(work/name,author/name)
        print(i,name,run.returncode,f'{elapsed:.6f}',sep='\t',flush=True)
    label=f'label-tuple-{i}-frontier.pkl'
    run('prepare-label-tuple.py',[str(i)],f'prepare-{i}.out')
    identical(work/label,author/label)
    for s in (0,1):
        tag=f'{i}-{s}'
        run('reduce-label-frontier.py',[label,tag],f'reduce-{tag}.out')
        name=f'label-{tag}-reduced-frontier.pkl'
        identical(work/name,author/name)
        run('contract-reduced-label.py',[tag],f'contract-{tag}.out',2 if s==0 else 0)
        if s==0:
            path,=work.glob(f'*-dense-label-{tag}-reduced.pkl')
            identical(path,author/path.name)
            label=path.name
        else:
            last=(work/f'contract-{tag}.out').read_text().splitlines()[-1]
            assert last+'\n'==(author/f'exact-{i}.txt').read_text()

print('tuple\tstage_receipt\texit_code\twall_seconds',flush=True)
with ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(review,(2,3,4)))
