from pathlib import Path
import re

print('tuple\tschedule\tmatched_products\twall_seconds\treceipt')
pattern=r'^exact normalized real .* independent matched products (\d+) wall seconds (\S+)$'
for i in (2,3,4):
    for method in ('sparse','sparse-support','alternate'):
        path=Path(f'{method}-{i}.out')
        m=re.search(pattern,path.read_text(),re.M)
        if i==4 and method=='alternate':
            assert m is None and 'forecast 8258112 1 2 prior 727680' in path.read_text()
            continue
        assert m is not None,path
        print(i,method,*m.groups(),path.name,sep='\t')
