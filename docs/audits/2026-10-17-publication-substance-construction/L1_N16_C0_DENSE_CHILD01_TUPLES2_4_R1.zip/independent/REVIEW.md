# Independent review of group 128 descendant (0,1), tuples 2–4

| Tuple | Exact normalized real | Imaginary |
|---|---:|---:|
| 2 | 761799400259723226207/2658455991569831745807614120560689152 | 0 |
| 3 | 341130692358955201725/166153499473114484112975882535043072 | 0 |
| 4 | 6319960913952819098631/332306998946228968225951765070086144 | 0 |

The exact subtotal of these three contributions is
**56779577789625559242855/2658455991569831745807614120560689152 + 0i**.

The source archive was read from publication checkpoint
b7e35f57067f9cc621cc781a3f01640cb05cf8fe and matched the worktree bytes.
Its manifest verified. The archived independent tuple 5 evidence pins
the descendant (0,1) parent SHA256
b75a1f1054ba76962bca3b28fed57135b9a1d6e0be78b6ae2cdb0a65551e6e94.
The archived tuple 5 operand and accepted receipt retain that descendant
and the same six-tuple roster. The author parent matches the pin and has
the exact representative conditioning (0,1). The successful values also
occur in the older descendant (0,0) ledger. This review recomputes them
from the (0,1) inputs.

Independent Cartesian enumeration checks all 256 combinations from
the eight remaining label domains. Exactly six projected assignments
satisfy all factor-local supports and belong to the eight original
projected states. Every roster entry and all nine per-factor row counts
for each assignment match. Each selected inverse lift recovers
all compatible parent rows and preserves Gaussian coefficients and
individual factor denominators. Tuples 2, 3 and 4 retain 170,864,
166,928 and 142,336 selected rows, respectively.

The clean lineage reproduces all 15 author preparation, reduction and
contraction commands byte for byte at the stored outputs and checkpoints.
Tuples 2 and 4 preserve their six-factor row-cap states. Tuple 3
preserves its four-factor join-cap state. All three terminal reduced
factor sets preserve complete label conditioning and the common factor
denominator product 40512224221827380280140849737629696.

The direct sparse and support-pruned width schedules independently agree
on all three raw Gaussian integers and exact normalized fractions. An
additional sparse order starting with the second-cheapest pair agrees
for tuples 2 and 3. It uses 637,224 products for tuple 2, compared with
5,410,560 for the minimum-product schedule. The same ordering rule for
tuple 4 reaches a forecast of 8,258,112 matches after 727,680 completed
products and refuses that join. The width schedule takes a different
initial pair from the successful minimum-product schedule and verifies
tuple 4 in 825,192 products. The refusal log remains part of the receipt.

Each completion applies the common factor denominator and external
normalization factor 1/(16*4^64) exactly once to the raw scalar.
The reported subtotal adds the three normalized values directly.
The two timing TSVs record 15 author-lineage commands and eight
successful independent terminal runs. The relative manifest includes
the copied author receipts and original archive bindings.
