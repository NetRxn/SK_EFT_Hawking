from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

author=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
tasks=[(i,name) for i in (2,3,4) for name in ('sparse','sparse-support')]
def replay(task):
    i,name=task
    path=Path(f'{name}-{i}.out')
    with path.open('xb') as handle:
        p=subprocess.run([sys.executable,'-u',f'{name}-replay.py',str(i),'1',str(author/f'label-{i}-1-reduced-frontier.pkl'),str(author/f'exact-{i}.txt')],
                         stdout=handle,stderr=subprocess.STDOUT,timeout=60)
    return i,name,p.returncode
with ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(replay,tasks):
        print(*result,sep='\t',flush=True)
