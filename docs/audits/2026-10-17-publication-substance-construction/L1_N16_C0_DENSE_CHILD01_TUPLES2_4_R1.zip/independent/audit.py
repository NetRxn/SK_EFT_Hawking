from ast import literal_eval
from collections import Counter,defaultdict
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
import pickle
import re

root=Path(__file__).resolve().parent
author=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
archive=root/'archive'
parent_raw=(root/'parent.pkl').read_bytes()
h=sha256(parent_raw).hexdigest()
pinned_parent=next(row.split()[0] for row in (archive/'independent/child01-tuple5-inputs.sha256').read_text().splitlines() if row.endswith('nine-minimum-quotient-frontier.pkl'))
assert h==pinned_parent=='b75a1f1054ba76962bca3b28fed57135b9a1d6e0be78b6ae2cdb0a65551e6e94'
assert parent_raw==(author/'nine-minimum-quotient-frontier.pkl').read_bytes()
parent=pickle.loads(parent_raw)
assert parent['conditioning']==[(('R',1,3,0,2,1),0),(('R',0,6,1,1,1),1)]
factors=parent['factors']
degree=Counter(w for scope,_,_ in factors for w in scope)
assert len(factors)==9 and all(n==2 for w,n in degree.items() if w[0]!='L')
den=prod(d for _,_,d in factors)
assert den==40512224221827380280140849737629696
scale=den*16*4**64
print('PASS exact distinct (0,1) parent',h,'rows',sum(len(r) for _,r,_ in factors),'factor denominator',den)

labels=sorted(w for w in degree if w[0]=='L')
domains=defaultdict(set)
supports=[]
for scope,rows,_ in factors:
    loc=tuple(w for w in labels if w in scope)
    pos=tuple(scope.index(w) for w in loc)
    support=Counter(tuple(row[p] for p in pos) for row in rows)
    supports.append((loc,support))
    for key in support:
        for w,value in zip(loc,key,strict=True):
            domains[w].add(value)
original=defaultdict(dict)
for line in (archive/'author/checkpoint/independent/states.tsv').read_text().splitlines():
    k,t,x,w,p,q=map(int,line.split())
    original[k][('L',t,x,w)]=(p,q)
original_projected={tuple(state[w] for w in labels) for state in original.values()}
assert len(original_projected)==8 and len(labels)==8
feasible={}
extent=0
for values in product(*(sorted(domains[w]) for w in labels)):
    extent+=1
    by_name=dict(zip(labels,values,strict=True))
    counts=[support[tuple(by_name[w] for w in loc)] for loc,support in supports]
    if all(counts):
        feasible[values]=counts
assert extent==256 and len(feasible)==6 and feasible.keys()<=original_projected
print('PASS exhaustive roster',extent,'Cartesian states',len(original_projected),'original projected states',len(feasible),'feasible states')
roster_path=archive/'child01/label-partition-roster.txt'
assert roster_path.read_bytes()==(author/'label-partition-roster.txt').read_bytes()
plans=literal_eval(roster_path.read_text())
assert len(plans)==6
assert [i for _,i,_,_ in plans]==list(range(6))
assert [tuple(a[w] for w in labels) for _,_,a,_ in plans]==list(feasible)
for total,i,assign,counts in plans:
    assert total==sum(counts) and counts==feasible[tuple(assign[w] for w in labels)]
    print('PASS roster',i,total,counts)
_,i5,a5,_=plans[5]
assert i5==5
cached=decompress((archive/'scalar-inputs/child01-tuple5.pkl.gz').read_bytes())
assert sha256(cached).hexdigest()==(root/'tuple5-derived.sha256').read_text().split()[0]
c5=pickle.loads(cached)
assert c5['conditioning']==parent['conditioning']+sorted(a5.items())
assert c5['label_partition']=={'index':5,'count':6,'values':a5}
ledger=(archive/'accepted-conditioned-values.tsv').read_text().splitlines()
receipt5=next(row.split('\t') for row in ledger if row.startswith('0,1\t'))
assert receipt5[:4]==['0,1','5','-10493250771659057325/1298074214633706907132624082305024','0']
print('PASS archived accepted (0,1) tuple 5 anchors parent and six-tuple roster',sha256(cached).hexdigest())

def stage(path,identity,arity):
    data=path.read_bytes()
    state=pickle.loads(data)
    assert (state['conditioning'],state['label_partition'])==identity
    ff=state['factors']
    assert len(ff)==arity and prod(d for _,_,d in ff)==den
    incidence=Counter(w for scope,_,_ in ff for w in scope)
    assert all(n==2 and w[0]!='L' for w,n in incidence.items())
    assert all(d>0 and len(set(scope))==len(scope) and all(len(row)==len(scope) and len(val)==2 and any(val) and all(type(x) is int for x in val) for row,val in rows.items()) for scope,rows,d in ff)
    print('PASS stage',path.name,sha256(data).hexdigest(),len(ff),sum(len(rows) for _,rows,_ in ff))
    return state

values=[]
signature=r'^exact normalized real (\S+) imaginary (\S+) '
for i in (2,3,4):
    total,idx,assignment,_=plans[i]
    assert idx==i
    identity=(parent['conditioning']+sorted(assignment.items()),{'index':i,'count':6,'values':assignment})
    start=stage(author/f'label-tuple-{i}-frontier.pkl',identity,9)
    for (scope,rows,d),(small,child,e) in zip(factors,start['factors'],strict=True):
        assert d==e and small==tuple(w for w in scope if w not in assignment)
        expected={row:val for row,val in rows.items() if all(w not in assignment or row[p]==assignment[w] for p,w in enumerate(scope))}
        lifted={}
        for row,val in child.items():
            by_name=dict(zip(small,row,strict=True))
            by_name.update(assignment)
            lifted[tuple(by_name[w] for w in scope)]=val
        assert lifted==expected
    assert total==sum(len(r) for _,r,_ in start['factors'])
    print('PASS exact projected-label inverse lift',i,total)
    stage(author/f'label-{i}-0-reduced-frontier.pkl',identity,9)
    cap,=author.glob(f'*-dense-label-{i}-0-reduced.pkl')
    kind='join' if i==3 else 'row'
    assert cap.name.startswith(f'{kind}-cap-')
    arity=4 if i==3 else 6
    stage(cap,identity,arity)
    stage(author/f'label-{i}-1-reduced-frontier.pkl',identity,arity)
    cap_line=(author/f'contract-{i}-0.out').read_text().splitlines()[-1]
    assert cap_line.startswith(f'open {kind} cap {arity} ')
    print('PASS cap receipt',i,cap_line)
    expected=tuple(map(Fraction,re.search(signature,(author/f'exact-{i}.txt').read_text(),re.M).groups()))
    raw=[]
    methods=['sparse','sparse-support']
    successes={int(k) for k,code in (line.split('\t') for line in (root/'alternate-jobs.tsv').read_text().splitlines()) if code=='0'}
    if i in successes:
        methods.append('alternate')
    for method in methods:
        text=(root/f'{method}-{i}.out').read_text()
        assert f'conditioning {identity[0]} label partition {identity[1]}' in text
        assert tuple(map(Fraction,re.search(signature,text,re.M).groups()))==expected
        r,im,d=map(int,re.search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',text,re.M).groups())
        assert den==d and (Fraction(r,scale),Fraction(im,scale))==expected
        raw.append((r,im))
    assert len(set(raw))==1
    print('PASS independent normalized (0,1) tuple',i,*expected,'raw',*raw[0])
    values.append(expected)
subtotal=tuple(sum(column,Fraction(0)) for column in zip(*values,strict=True))
print('PASS exact only tuples 2–4 subtotal',*subtotal)
