# Group 128 descendant (0,1), tuples 2–4

The accepted parent and six-entry representation roster are pinned by the
prior L1_N16_C0_DENSE_CONDITIONED_SCALARS_R1.zip. Its review of tuple 5
records the full original source, the exact (0,1) input hash and the
complete original eight-state projection. Recover the parent using that
archive's branch replay and apply the author runner to labels 4, 3 and 2.
Use only trusted regenerated pickles and check all frontier hashes before
replay. Source scripts and timing receipts are in author. The independent
reproduction and full scope are in independent/REVIEW.md, with its
independent raw exact values, lineage and replay schedules.

The attached table has both signed components and excludes tuple 5,
which is accepted separately. The prior normalization includes
1/(16*4^64). Never apply it again to normalized table values. Tuples 0
and 1 are outside this checkpoint.
