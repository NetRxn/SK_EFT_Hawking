from pathlib import Path
from re import search

report=Path('REVIEW.md')
s=report.read_text()
header='## Exact scalar and measurements'
s=s.split(header,1)[0]+header+'\n'
out=Path('retally.out').read_text()
raw,imag,den=search(r'^raw Gaussian sum (-?\d+) (-?\d+) factor denominator (\d+)',out,flags=8).groups()
real=search(r'^physical weighted (-?\d+/\d+) 0',out,flags=8)[1]
p,g,c,t,total=search(r'^author measured seconds ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)',out,flags=8).groups()
assert imag=='0' and t=='0.0'
s+=f'''
The exact raw Gaussian sum is ({raw}, {imag})
at inherited factor denominator {den}. Applying the original physical
divisor 16 × 4^64 and the cover coefficient 192 once gives
**{real} + 0i**.

The review reproduced six native row caps and all 24 continuation row
refusals across 16 retained passes. Each continuation's author refusal
visit count and available supported-product count matched the ordered
replay. Author measured components total {total} seconds, with {p}
for shared preparation, {g} for native guarding and {c} for retained
continuation. All live terms close as empty-axis scalars, so there was
no separate terminal job. These timings describe the observed Group 189
workload.

## Reproduction

Verify the relative manifest and per-ordinal original operand manifests.
Large retained pickles are external replay operands identified by checksum.
The supplied scripts default to the original author cached-original-roster
directory. Set L1_GROUP189_AUTHOR_ROOT to an equivalently laid out operand
tree if needed.

    python3 -B source-custody.py /path/to/publication-checkpoint
    bash replay-label.sh 0 3 scalar author-order
    bash replay-label.sh 2 3 scalar author-order
    bash replay-label.sh 4 3 scalar author-order
    bash replay-label.sh 5 3 scalar author-order
    bash replay-label.sh 6 2 scalar author-order
    bash replay-label.sh 7 2 scalar author-order
    python3 -B retally.py /path/to/publication-checkpoint

The signed work, cap, refusal, timing and scalar ledgers record the original
ordinals and immutable operand fingerprints. The replay writes evidence
under its current directory.
'''
report.write_text(s)
