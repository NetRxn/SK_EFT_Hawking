from os import environ
from ast import literal_eval
from collections import Counter,defaultdict
from gc import collect
from hashlib import file_digest
from itertools import combinations
from math import gcd,prod
from pathlib import Path
from pickle import load
from time import monotonic
import json
import sys

CASE=int(sys.argv[1])
AUTHOR_ORDER='--author-guard-order' in sys.argv
C=json.loads(Path(f'author/L{CASE}/pins.json').read_text())
author=Path(environ.get('L1_GROUP189_AUTHOR_ROOT', '/private/tmp/l1-geometry-component3-preparation.HJyusc/189/cached-original-roster'))/f'L{CASE}'
origin=author/'row-cap-physical-slice-dense-branch.pkl'
N=1778314369133712165932108630458368
def sha(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def read(path):
    with path.open('rb') as f:return load(f)
def positions(a,b):
    col=tuple(a.index(w) for w in b)
    return lambda key:tuple(key[j] for j in col)
def mul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def forecast(F,G):
    a,x,_=F;b,y,_=G
    edge=tuple(w for w in a if w in b)
    if not edge:return None
    u=Counter(map(positions(a,edge),x))
    v=Counter(map(positions(b,edge),y))
    return sum(u[k]*v[k] for k in u.keys()&v.keys()),len(set(a)^set(b)),len(u.keys()&v.keys())
def validate(f):
    assert prod(d for _,_,d in f)==N
    assert all(d>0 and len(a)==len(set(a)) and X for a,X,d in f)
    assert set(Counter(w for a,_,_ in f for w in a).values()) in ({2},set())

def fold(a,b,edge):
    A,X,d=a;B,Y,e=b
    al=tuple(w for w in A if w not in edge); bl=tuple(w for w in B if w not in edge)
    p,q,s,t=positions(A,edge),positions(B,edge),positions(A,al),positions(B,bl)
    L,R=defaultdict(dict),defaultdict(dict)
    for k,v in X.items():L[p(k)][s(k)]=v
    for k,v in Y.items():R[q(k)][t(k)]=v
    both=L.keys()&R.keys()
    groups=defaultdict(list)
    ordered_both=sorted(both) if AUTHOR_ORDER else both
    for k in ordered_both:
        vec=L[k]
        c=gcd(*(n for z in vec.values() for n in z))
        assert c>0
        outs=sorted(vec)
        raw=[(vec[w][0]//c,vec[w][1]//c) for w in outs]
        i=max(range(4),key=lambda i:(raw[0],(-raw[0][1],raw[0][0]),
                                      (-raw[0][0],-raw[0][1]),(raw[0][1],-raw[0][0]))[i])
        rot=((1,0),(0,1),(-1,0),(0,-1))[i]
        normalized=tuple(zip(outs,(mul(z,rot) for z in raw),strict=True))
        scale=c*rot[0],-c*rot[1]
        assert {w:mul(v,scale) for w,v in normalized}==vec
        groups[normalized].append((k,scale))
    if len(groups)==len(L)==len(R):return a,b,0
    if AUTHOR_ORDER:
        F={}
        Y={}
        assignment={}
        for v,items in groups.items():
            anchor=min(key for key,_ in items)
            F.update((anchor+k,z) for k,z in v)
            assignment.update((key,(anchor,scale)) for key,scale in items)
        for key in sorted(assignment):
            anchor,scale=assignment[key]
            for p,w in R[key].items():
                rr,ii=mul(scale,w)
                re,im=Y.get(anchor+p,(0,0))
                if rr+re or ii+im:
                    Y[anchor+p]=(rr+re,ii+im)
                else:
                    Y.pop(anchor+p,None)
        return (edge+al,F,d),(edge+bl,Y,e),len(both)-len(groups)
    F={}
    H=defaultdict(lambda:[0,0])
    for v,items in groups.items():
        anchor=min(key for key,_ in items)
        F.update((anchor+k,z) for k,z in v)
        for key,scale in items:
            for p,w in R[key].items():
                rr,ii=mul(scale,w)
                H[anchor+p][0]+=rr;H[anchor+p][1]+=ii
    return (edge+al,F,d),(edge+bl,{k:tuple(z) for k,z in H.items() if any(z)},e),len(both)-len(groups)

def inverse(source,a,b):
    scope,rows,d=source
    ax,X,u=a
    bx,Y,v=b
    edge=tuple(set(ax)&set(bx))
    assert len(edge)==1 and edge[0][0]=='exact-fiber-split' and edge[0] not in scope
    left=tuple(w for w in ax if w not in edge)
    right=tuple(w for w in bx if w not in edge)
    assert set(left+right)==set(scope) and (u,v)==(d,1)
    A=positions(ax,left);B=positions(bx,right)
    P=positions(ax,edge);Q=positions(bx,edge)
    lift=positions(left+right,scope)
    fibers=defaultdict(list)
    for key,coeff in Y.items():fibers[Q(key)].append((B(key),coeff))
    assert set(map(P,X))==fibers.keys()
    # A left coordinate has exactly one class, so every output appears once.
    assert len(set(map(A,X)))==len(X)
    count=0
    for key,value in X.items():
        x=A(key)
        for y,coeff in fibers[P(key)]:
            assert rows[lift(x+y)]==mul(value,coeff)
            count+=1
    assert count==len(rows)
    return count

def projections(peers,boundary,rank):
    atlas=[(ax,T,tuple(w for w in ax if w in boundary)) for ax,T,_ in peers]
    clues=[]
    for ax,T,touch in atlas:
        if touch:clues.append((positions(boundary,touch),set(map(positions(ax,touch),T))))
    if rank==1:return clues
    def grouped(ax,T,out,common):
        A,B=positions(ax,common),positions(ax,out)
        result=defaultdict(set)
        for row in T:result[A(row)].add(B(row))
        return result
    for (a,X,left),(b,Y,right) in combinations(atlas,2):
        if not left or not right:continue
        shared=tuple(w for w in a if w in b)
        if not shared:continue
        assert not set(left)&set(right) and not set(left+right)&set(shared)
        U=grouped(a,X,left,shared);V=grouped(b,Y,right,shared)
        common=U.keys()&V.keys()
        count=sum(len(U[k])*len(V[k]) for k in common)
        if count<=100_000:
            clues.append((positions(boundary,left+right),{x+y for k in common for x in U[k] for y in V[k]}))
    return clues

def replay(F,G,peers,expected,rank,row_stop=None):
    a,X,d=F;b,Y,e=G
    edge=tuple(w for w in a if w in b)
    out_a=tuple(w for w in a if w not in edge)
    out_b=tuple(w for w in b if w not in edge)
    ax=out_a+out_b
    P,Q=positions(a,edge),positions(b,edge)
    A,B=positions(a,out_a),positions(b,out_b)
    clues=projections(peers,ax,rank) if expected>=500_000 else []
    clues.sort(key=lambda t:-len(t[1]))
    groups=defaultdict(list)
    for k,v in Y.items():groups[Q(k)].append((B(k),v))
    seen=permitted=0
    result={}
    assert expected<=8_000_000
    def compatible():
        if AUTHOR_ORDER:
            left_groups=defaultdict(list)
            for key,v in X.items():
                left_groups[P(key)].append((A(key),v))
            for key,right in Y.items():
                t=B(key)
                for h,left in left_groups[Q(key)]:
                    yield h+t,left,right
        else:
            for key,left in reversed(X.items()):
                h=A(key)
                for t,right in reversed(groups.get(P(key),())):
                    yield h+t,left,right

    for idx,left,right in compatible():
        seen+=1
        if any(p(idx) not in s for p,s in clues):continue
        permitted+=1
        u,v=mul(left,right);rr,ii=result.get(idx,(0,0))
        value=u+rr,v+ii
        if any(value):result[idx]=value
        else:result.pop(idx,None)
        if row_stop is not None and len(result)>row_stop:
            return seen,permitted,len(result)
        # An alternate accumulation order can change the transient row count.
    assert seen==expected
    assert row_stop is None, ("independent row-cap order did not reach cap", seen, len(result))
    return (ax,result,d*e),permitted,len(clues)

def stage_events(label,end):
    log=(author/f'pass{label}.out').read_text().splitlines()
    names=(
        ('exact accepted join ', ' remaining ', 'trace'),
        ('bounded refusal ', ' cumulative ', 'refusal'),
        ('exact primitive join quotient ', None, 'trace'),
        ('exact follow join ', ' remaining ', 'trace'),
        ('follow refused ', ' work ', 'refusal'),
    )
    events=[]
    for line in log:
        for prefix,stop,kind in names:
            if line.startswith(prefix):
                entry=line.removeprefix(prefix)
                if stop:
                    entry=entry.split(stop,1)[0]
                events.append((kind,literal_eval(entry)))
                break
    assert [r for kind,r in events if kind=='trace']==end['unsharded_trace']
    assert [r for kind,r in events if kind=='refusal']==end['refused_pairs']
    return events


def check_stage(label, source_path, split_path, result_path, rank):
    source,split,end=map(read,(source_path,split_path,result_path))
    for item in (source,split,end):validate(item['factors'])
    assert split['physical_cut']==end['physical_cut']==source['physical_cut']==region
    assert 'left-row-interval' not in repr(split['physical_cut'])
    names=source.get('factor_labels',tuple((j,0) for j in range(len(source['factors']))))
    before=dict(zip(names,source['factors'],strict=True))
    live=dict(zip(split['factor_labels'],split['factors'],strict=True))
    inherited=f'pass{label}_pred_sha256'
    if label>1:
        assert split[inherited]==end[inherited]==sha(source_path)
    assert split['split_origin_sha256']==end['split_origin_sha256']==original
    field='primitive_splits' if label==1 else f'pass{label}_splits'
    specs=split[field]
    moves=[((i,0),(i,0),(i,1)) for i,*_ in specs] if label==1 else [tuple(s[:3]) for s in specs]
    for old,a,b in moves:
        n=inverse(before.pop(old),live[a],live[b])
        print('inverse exact',label,old,a,b,n,flush=True)
    kept=set(live)-{w for _,a,b in moves for w in (a,b)}
    assert set(before)==kept and all(live[k]==F for k,F in before.items())
    print('split verified',label,len(live),sum(len(t) for _,t,_ in live.values()),sha(split_path),flush=True)
    del before,source,split
    collect()
    products=0
    accepted=folds=0
    for kind,entry in stage_events(label,end):
        if kind=='refusal':
            if label==1:
                a,b,matched,author_seen,status=entry
                author_supported=None
            else:
                a,b,matched,author_seen,author_supported,status=entry
            f,g=live[a],live[b]
            assert forecast(f,g)[0]==matched and 0<author_seen<=matched<=8_000_000
            if status=='rows':
                independently_seen,supported,rows=replay(f,g,[T for k,T in live.items() if k not in (a,b)],
                                                         matched,rank,row_stop=500_000)
                assert rows==500001 and independently_seen<=matched
                if AUTHOR_ORDER:
                    assert independently_seen==author_seen
                    if author_supported is not None:
                        assert supported==author_supported
                print('independently crossed continuation row cap',label,a,b,matched,author_seen,
                      author_supported,independently_seen,supported,rows,flush=True)
            else:
                assert status=='wall' and author_seen%32768==0
                print('bound wall refusal, retained input unchanged',label,a,b,matched,author_seen,flush=True)
            continue
        if label>1 and entry[0]=='fold':
            _,a,b,n,m,x,y=entry
            f,g=live[a],live[b]
            assert forecast(f,g)[0]==n
            axes=tuple(k for k in f[0] if k in g[0])
            f,g,P=fold(f,g,axes)
            g,f,Q=fold(g,f,axes)
            assert (P,Q)==(x,y) and forecast(f,g)[0]==m
            live[a],live[b]=f,g
            folds+=1
            print('verified exact quotient',label,a,b,n,m,x,y,flush=True)
            continue
        if label==1:
            a,b,c,n,r,w,d=entry
            through=None
        else:
            _,a,b,c,n,r,w,d,through=entry
        f,g=live.pop(a),live.pop(b)
        assert forecast(f,g)[:2]==(n,w)
        z,m,gate=replay(f,g,list(live.values()),n,rank)
        assert (len(z[1]),len(z[0]),z[2])==(r,w,d)
        if through is not None:assert m==through
        live[c]=z
        products+=n
        accepted+=1
        print('verified joined table',label,a,b,c,'visits',n,'supported',m,'rows',r,'support tests',gate,flush=True)
    assert tuple(live)==end['factor_labels'] and list(live.values())==end['factors']
    refused=sum(r[3] for r in end['refused_pairs'])
    assert products+refused==end['attempted_products']
    print('stage counts',label,len(moves),accepted,folds,len(live),products,refused,flush=True)
    print('exact all retained coefficient tables',label,sha(result_path),len(live),
          sum(len(t) for _,t,_ in live.values()),'kept work',products,'refused work',refused,flush=True)
    return live


def main():
    global original,region
    started=monotonic()
    original=sha(origin)
    assert original==C['cap_sha']
    data=read(origin)
    region=data['physical_cut']
    assert len(data['factors'])==C['cap_factors'] and all(w[0]=='L' for w in region[0]) and len(region[0])==len(region[1])==12
    assert 'conditioning' not in data or not data['conditioning']
    print('original joint-L cap rows',sum(len(t) for _,t,_ in data['factors']),flush=True)
    print(f'whole original L{CASE} input',original,region,flush=True)
    del data
    collect()
    paths=[origin,author/'unsharded-result.pkl',*(author/f'pass{i}-result.pkl' for i in range(2,C['passes']+1))]
    splits=[author/'split-frontier.pkl',*(author/f'pass{i}-split.pkl' for i in range(2,C['passes']+1))]
    for n in range(1,C['passes']+1):
        stage_started=monotonic()
        f=check_stage(n,paths[n-1],splits[n-1],paths[n],min(n,2))
        print('independent stage wall seconds',n,round(monotonic()-stage_started,6),flush=True)
        if n<C['passes']:del f;collect()
    terminal_sha=sha(paths[-1])
    assert terminal_sha==C['terminal_sha']
    if C['mode'] in ('triangle','scalar_pivot','four_factor'):
        assert prod(d for _,_,d in f.values())==N
        print(f'whole original L{CASE} exact terminal {C["mode"]} ready',terminal_sha,N,'elapsed',round(monotonic()-started,6),flush=True)
    else:
        assert len(f)==1
        [(axes,rows,den)]=f.values()
        assert axes==() and rows=={():(C['expected_raw'],C['expected_imag'])}
        assert den==N
        print(f'whole original L{CASE} raw',rows[()],den,'elapsed',round(monotonic()-started,6),flush=True)

if __name__=="__main__":
    main()
