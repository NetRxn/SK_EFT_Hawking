"""Validate the accepted preparation and geometry objects without replaying dense work."""
import argparse
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from subprocess import check_output, run
from zipfile import ZipFile

CHECKPOINT='ddb06c4f5327fe529fe01839ae5c5d13a8456654'
ROOT='docs/audits/2026-10-17-publication-substance-construction'
PINS={
 'DENSE_COMPONENT3_PREPARATION':'f3fe6557f97a8aa9727c3e8f55474f6f5cc0a9695549fd16ae7e0135a18f1421',
 'DENSE_COMPONENT98_COMPLETE':'cfec23cfa3563fd18f02e24e38f7ce22a5cc09065d77dd2282d0c1d1c11c8a77',
 'DENSE_GEOMETRY_COVER':'bf3bfef6484236edc5eca2961d705f9ee27cc17b857c9c69df89114e4d99b1b4',
}


def main(repo, tip):
    def git(*args): return check_output(['git','-C',str(repo),*args])
    run(['git','-C',str(repo),'merge-base','--is-ancestor',CHECKPOINT,tip],check=True)
    print('original checkpoint',CHECKPOINT,'readback',git('rev-parse',tip).decode().strip())
    delta=git('diff','--name-only',CHECKPOINT,tip).decode().splitlines()
    print('intervening paths',delta)
    for name,digest in PINS.items():
        path=f'{ROOT}/L1_N16_C0_{name}_R1.zip'
        raw=git('show',f'{CHECKPOINT}:{path}')
        assert sha256(raw).hexdigest()==digest and raw==git('show',f'{tip}:{path}')
        print(name,'byte-identical SHA256',digest)
        if name!='DENSE_COMPONENT3_PREPARATION':continue
        with ZipFile(BytesIO(raw)) as z:
            assert z.testzip() is None
            records={n.removeprefix('./'):h for h,n in
                     (line.split(maxsplit=1) for line in z.read('review-manifest.portable.sha256').decode().splitlines())}
            names={
                'original-roster.txt':'original-roster.txt',
                'prepared-roster.tsv':'prepared-roster.tsv',
                'ordinal-roster.tsv':'ordinal-roster.tsv',
                'result.json':'accepted-result.json',
                'frontier.sha256':'frontier.sha256',
                'replay.out':'accepted-replay.out',
                'preparation.time':'author-preparation.time',
            }
            for member, local in names.items():
                key=f'group-189/{member}'
                content=z.read(key)
                assert sha256(content).hexdigest()==records[key] and Path(local).read_bytes()==content
            print('Group 189 original roster, six-live/two-zero proof and source pin members verified',len(names))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('repo',type=Path)
    p.add_argument('tip',default='HEAD',nargs='?')
    a=p.parse_args()
    main(a.repo,a.tip)
