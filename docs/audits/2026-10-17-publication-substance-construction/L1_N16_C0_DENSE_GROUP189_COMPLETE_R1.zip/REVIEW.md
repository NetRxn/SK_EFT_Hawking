# Independent complete signed Group 189 review

The original eight Group 189 joint-L ordinals are covered. Ordinals 0, 2,
4, 5, 6 and 7 have independently replayed signed terminals. Ordinals 1 and 3
give exact zero by the empty prepared restrictions certified in the accepted
component 3 preparation. The scalar ledger retains the original tuples,
Gaussian numerators and the inherited factor denominator.

The work-start continuity packet was fresh at
ddb06c4f5327fe529fe01839ae5c5d13a8456654. The accepted component 3
preparation pins the whole 88-factor prepared Group 189 parent at SHA-256
9c39d9b3674c90f1c43cbd3fea233a7e85be96b0309126d32bc2599705b01a73.
Its committed roster binds all eight disjoint original coordinates and both
zeros. Group 189 is on component 3's accepted selected side. Its original
gamma3 partner is Group 3542. The coefficient 192 is the product of the
original occupation weight 48 and the two factors of two for gamma3 and
the selected geometric side.

## Signed guard and continuation replay

The independent native replays enumerate the original support, lift the
selected signed rows into the exact prepared parent, and reconstruct the
native cap. Each crosses the 500,000-row threshold on the pinned pair.
The continuation replays verify inverse signed splits, degree-two
physical wiring, exact quotient folds, necessary peer projections, and
every retained Gaussian coefficient table. The independent work follows
the original ordered product traversal when verifying continuation guards.
This preserves the order-dependent transient row count and lets the
review independently match the author visit threshold. Every live
ordinal closes as a single empty-axis factor.

## Exact scalar and measurements

The exact raw Gaussian sum is (-4286426902081819528885127883657605484340750399349834467246080, 0)
at inherited factor denominator 1778314369133712165932108630458368. Applying the original physical
divisor 16 × 4^64 and the cover coefficient 192 once gives
**-441355151142732155747895/5192296858534827628530496329220096 + 0i**.

The review reproduced six native row caps and all 24 continuation row
refusals across 16 retained passes. Each continuation's author refusal
visit count and available supported-product count matched the ordered
replay. Author measured components total 467.891059 seconds, with 25.16
for shared preparation, 167.286636 for native guarding and 275.444423 for retained
continuation. All live terms close as empty-axis scalars, so there was
no separate terminal job. These timings describe the observed Group 189
workload.

## Reproduction

Verify the relative manifest and per-ordinal original operand manifests.
Large retained pickles are external replay operands identified by checksum.
The supplied scripts default to the original author cached-original-roster
directory. Set L1_GROUP189_AUTHOR_ROOT to an equivalently laid out operand
tree if needed.

    python3 -B source-custody.py /path/to/publication-checkpoint
    bash replay-label.sh 0 3 scalar author-order
    bash replay-label.sh 2 3 scalar author-order
    bash replay-label.sh 4 3 scalar author-order
    bash replay-label.sh 5 3 scalar author-order
    bash replay-label.sh 6 2 scalar author-order
    bash replay-label.sh 7 2 scalar author-order
    python3 -B retally.py /path/to/publication-checkpoint

The signed work, cap, refusal, timing and scalar ledgers record the original
ordinals and immutable operand fingerprints. The replay writes evidence
under its current directory.
