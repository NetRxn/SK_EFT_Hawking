from pathlib import Path
from ast import literal_eval
from time import monotonic
import subprocess,sys
plans=[line for line in Path('edge-plan.out').read_text().splitlines() if line.startswith('pattern ')]
assert len(plans)==32
for i,line in enumerate(plans):
    p=line.rindex(')')
    a,b,s,t=literal_eval(line[8:p+1])
    assert int(line.split()[-1])<=4_001_792
    start=monotonic()
    with Path(f'edge-{i:02}.out').open('w') as f:
        subprocess.run([sys.executable,'tiled_shard.py','.',str(a),str(b),repr(s),repr(t)],stdout=f,stderr=subprocess.STDOUT,check=True)
    Path('edge-selected.tsv').rename(f'raw-edges/{i:02}.tsv')
    print('edge',i,'seconds',round(monotonic()-start,2),flush=True)
