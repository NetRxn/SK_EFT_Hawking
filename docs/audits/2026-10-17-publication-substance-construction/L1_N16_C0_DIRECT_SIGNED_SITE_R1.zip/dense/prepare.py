from ast import literal_eval
from collections import defaultdict
from itertools import product
from pathlib import Path
import sys

path=Path(sys.argv[1])
codes=tuple(map(int,path.name.split('-')[:2]))
vectors=[r for r in product(range(5),repeat=3) if sum(r)<=4]
occ=tuple(tuple(vectors[(code>>(6*x))&63] for x in range(8)) for code in codes)
tables=defaultdict(list)
for line in path.read_text().splitlines():
    keys,labels=map(literal_eval,line.split('\t'))
    tables[keys].append(labels)
def scope(x):
    return tuple(sorted((t,y,k) for t in range(2) for k in range(3) for y in (x,x^(1<<k))))
t=0
x=max(range(8),key=lambda x:len(tables[scope(x)]))
keys=scope(x)
labels=tables[keys]
assert len(labels)==88
Path('location.tsv').write_text(f'{t}\t{x}\n')
with Path('states.tsv').open('w') as s, Path('anchor-plan.tsv').open('w') as plan:
    for i,row in enumerate(labels):
        st=dict(zip(keys,row))
        for (side,y,k),(l,r) in st.items():
            if l or r:
                print(i,side,y,k,l,r,sep='\t',file=s)
        for k in range(3):
            u,v=sorted((x,x^(1<<k)))
            h=sum(sum(occ[t][j])-occ[t][j][k] for j in (u,v))
            for j in (u,v):
                print(i,t,j,k,h,*st[t,j,k],*st[1-t,j,k],sep='\t',file=plan)
print('dense selected site',t,x,'local tuples',len(labels))
