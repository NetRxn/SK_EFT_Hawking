# L1 signed site factors from direct local label rosters

The direct label rosters come from L1_N16_C0_DIRECT_LOCAL_PROJECTION_R1.
Each site factor consumes only the labels at its three incident spatial
edges, including the opposite-layer labels. The preparation scripts write
local states and edge shapes for one site. They do not create global
support assignments. The generator uses the existing signed exterior and
root calculations while emitting only the selected site.

For the independently accepted 152-assignment profile, the control site
covers all 20 direct local tuples. Eighteen appear in the available
representative tables. Comparing the mask and root factor from each of
those local tuples with every corresponding representative table gave
152 byte-identical comparisons. The other two are emitted and retained
by hash but lack a comparison against those representative tables.

For the 30,976-assignment dense profile, all 88 tuples at the largest
site were assembled into 176 signed factor tables. All 32 incident edge
patterns were generated and projected. The tables remain local and are
identified by hash. This covers one site. The remaining dense sites,
temporal factors, full signed contraction and independent verification
remain owed.
