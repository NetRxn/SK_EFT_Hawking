from pathlib import Path
from ast import literal_eval
from collections import defaultdict
from itertools import product
import sys

p=Path(sys.argv[1])
data=Path(sys.argv[2])
codes=tuple(map(int,data.name.split('-')[:2]))
vectors=[r for r in product(range(5),repeat=3) if sum(r)<=4]
occ=tuple(tuple(vectors[(code>>(6*x))&63] for x in range(8)) for code in codes)
layouts=defaultdict(list)
for line in p.read_text().splitlines():
    scope,labels=map(literal_eval,line.split('\t'))
    layouts[scope].append(labels)
known={literal_eval(line[8:line.rindex(')')+1]) for line in (data/'edge-plan.out').read_text().splitlines() if line.startswith('pattern ')}
actual=defaultdict(dict)
for line in (data/'states.tsv').read_text().splitlines():
    i,t,x,k,l,r=map(int,line.split())
    actual[i][t,x,k]=(l,r)
def scope(x):
    return tuple(sorted((t,y,k) for t in range(2) for k in range(3) for y in (x,x^(1<<k))))
def anchors(t,x,st):
    for k in range(3):
        u,v=sorted((x,x^(1<<k)))
        load=lambda i:sum(occ[t][i])-occ[t][i][k]
        a,b=load(u),load(v)
        def shape(i):return (a+b,*st[t,i,k],*st[1-t,i,k])
        yield k,u,v,(a,b,shape(u),shape(v))
choices=[]
for t in range(2):
    for x in range(8):
        keys=scope(x)
        all_labels=layouts[keys]
        covered=[l for l in all_labels if all(key in known for _,_,_,key in anchors(t,x,dict(zip(keys,l))))]
        matched={tuple(st.get(k,(0,0)) for k in keys) for st in actual.values()}
        print('site',t,x,'direct',len(all_labels),'available',len(covered),'author overlap',len(matched),flush=True)
        assert matched<=set(covered)
        if len(covered)==len(all_labels):
            choices.append((len(matched),len(covered),t,x))
assert choices
overlap,n,t,x=max(choices)
assert overlap>1
keys=scope(x)
(Path('location.tsv')).write_text(f'{t}\t{x}\n')
with Path('states.tsv').open('w') as s, Path('anchor-plan.tsv').open('w') as plan, Path('case-map.tsv').open('w') as refs:
    for i,row in enumerate(layouts[keys]):
        st=dict(zip(keys,row))
        for (side,y,k),(l,r) in st.items():
            if l or r:
                print(i,side,y,k,l,r,sep='\t',file=s)
        for k,u,v,(_,_,left,right) in anchors(t,x,st):
            print(i,t,u,k,*left,sep='\t',file=plan)
            print(i,t,v,k,*right,sep='\t',file=plan)
        peers=[j for j,state in actual.items() if row==tuple(state.get(k,(0,0)) for k in keys)]
        print(i,*peers,sep='\t',file=refs)
print('selected',t,x,'all local labels',n,'author labels',overlap)
