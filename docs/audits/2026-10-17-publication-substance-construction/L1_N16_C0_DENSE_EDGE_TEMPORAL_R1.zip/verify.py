from ast import literal_eval
from collections import Counter,defaultdict
from pathlib import Path
import sys

prior,labels=map(Path,sys.argv[1:3])
projections=defaultdict(set)
for line in labels.read_text().splitlines():
    scope,row=map(literal_eval,line.split('\t'))
    projections[scope].add(row)
def scope(t,x):
    return tuple(sorted((u,y,k) for u in t for k in range(3) for y in (x,x^(1<<k))))
sites=defaultdict(dict)
for line in Path('locations.tsv').read_text().splitlines():
    i,t,x,row=line.split('\t')
    i,t,x=map(int,(i,t,x))
    labels=literal_eval(row)
    assert labels not in sites[t,x]
    sites[t,x][labels]=i
assert len(sites)==16
for (t,x),rows in sites.items():
    assert rows.keys()==projections[scope((0,1),x)]
bindings=defaultdict(set)
for line in Path('temporal-bindings.tsv').read_text().splitlines():
    t,x,h,row,shape=line.split('\t')
    t,x,h=map(int,(t,x,h))
    row,shape=literal_eval(row),literal_eval(shape)
    assert row not in bindings[t,x,h]
    bindings[t,x,h].add(row)
assert len(bindings)==32
for (t,x,h),rows in bindings.items():
    assert rows==projections[scope((t,),x)]
edgefiles=set(p.name for p in Path('raw-edges').glob('*.tsv'))
assert edgefiles=={f'{i:02}.tsv' for i in range(80)}
assert len(list(Path('rays').glob('*.tsv')))==240
expected=set()
site_count=0
t0,x0=map(int,(prior/'location.tsv').read_text().split())
prevlabels=sorted(projections[scope((0,1),x0)])
overlap=0
for (t,x),rows in sorted(sites.items()):
    for labels,i in rows.items():
        site_count+=1
        for part in ('mask','root'):
            name=f'{i}-{t}-{x}-{part}.tsv'
            expected.add(name)
            if (t,x)==(t0,x0):
                oldid=prevlabels.index(labels)
                old=prior/'site'/f'{oldid}-{t}-{x}-{part}.tsv'
                assert old.read_bytes()==(Path('site')/name).read_bytes(),(old,name)
                overlap+=1
assert overlap==176 and site_count==976
assert {p.name for p in Path('site').glob('*.tsv')}==expected
print('16 sites',site_count,'local labels',len(expected),'signed factor files;',overlap,'identical prior-site comparisons')
print('80 raw edges, 240 quotient tables and aliases, 32 temporal binding families')
