from pathlib import Path
from ast import literal_eval
from time import monotonic
import subprocess,sys
from collections import defaultdict
def patterns(p):
    return [literal_eval(line[8:line.rindex(')')+1]) for line in Path(p).read_text().splitlines() if line.startswith('pattern ')]
def moments(p):
    data=defaultdict(set)
    for line in Path(p).read_text().splitlines():
        k,row=line.split('\t',1)
        data[literal_eval(k)].add(row)
    return data
prior=Path(sys.argv[1]).resolve()
cached={p:prior/f'raw-edges/{i:02}.tsv' for i,p in enumerate(patterns(prior/'edge-plan.out'))}
old,new=moments(prior/'spatial.tsv'),moments('spatial.tsv')
current=patterns('edge-plan.out')
assert len(current)==80
for i,p in enumerate(current):
    a,b,s,t=p
    out=Path(f'raw-edges/{i:02}.tsv')
    if p in cached:
        assert old[s]==new[s] and old[t]==new[t]
        out.symlink_to(cached[p])
        print('edge',i,'reused exact moment context',flush=True)
        continue
    start=monotonic()
    with Path(f'edge-{i:02}.out').open('w') as f:
        subprocess.run([sys.executable,'tiled_shard.py','.',str(a),str(b),repr(s),repr(t)],stdout=f,stderr=subprocess.STDOUT,check=True)
    Path('edge-selected.tsv').rename(out)
    print('edge',i,'seconds',round(monotonic()-start,2),flush=True)
