# Dense L1 edge and temporal factors from direct local rosters

The dense profile has 30,976 globally admissible assignments. The
local projections from L1_N16_C0_DIRECT_LOCAL_PROJECTION_R1 supply all
edge and temporal label scopes directly. The original edge input recipe
binds 184 local label tuples at 24 locations to 80 shared exact raw edge
tables and their projected tables. The existing Haar projector binds
320 local temporal tuples to 23 shapes with 1,089 nonzero entries.

The included comparison checks 14 existing temporal shapes and all 167
entries against the accepted 152-assignment profile. For the dense
profile, all 32 reused edges and all 96 associated projected and alias
files match the earlier single-site construction byte for byte.

The exact edge files remain in the local run directory and are identified
by checksum. The 976-site-tuple roster and the assembly driver are included
for resumption. Full site-factor assembly, the combined signed contraction
and independent evaluation of this dense coefficient remain open.
