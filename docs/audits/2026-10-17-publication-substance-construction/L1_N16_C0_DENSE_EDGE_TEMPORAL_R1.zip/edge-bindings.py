from ast import literal_eval
from collections import defaultdict
from itertools import product
from pathlib import Path
import sys

labels=Path(sys.argv[1])
a,b=map(int,labels.name.split('-')[:2])
roster=[r for r in product(range(5),repeat=3) if sum(r)<=4]
occ=tuple(tuple(roster[(c>>(6*x))&63] for x in range(8)) for c in (a,b))
patterns={}
for line in Path('edge-plan.out').read_text().splitlines():
    if line.startswith('pattern '):
        p=literal_eval(line[8:line.rindex(')')+1])
        assert p not in patterns
        patterns[p]=len(patterns)
ts=defaultdict(list)
for line in labels.read_text().splitlines():
    axes,row=map(literal_eval,line.split('\t'))
    ts[axes].append(row)
used=set()
rows=0
with Path('edge-bindings.tsv').open('w') as out:
    for t in range(2):
        for u in range(8):
            for k in range(3):
                if u>>k&1:
                    continue
                v=u^(1<<k)
                axes=tuple((layer,x,k) for layer in range(2) for x in (u,v))
                al,bl=(sum(occ[t][x])-occ[t][x][k] for x in (u,v))
                for local in ts[axes]:
                    st=dict(zip(axes,local))
                    def shape(x):
                        return al+bl,*st[t,x,k],*st[1-t,x,k]
                    index=patterns[al,bl,shape(u),shape(v)]
                    used.add(index)
                    print(t,u,v,k,local,index,sep='\t',file=out)
                    rows+=1
assert used==set(range(len(patterns))) and rows==184
print('24 edge locations,',rows,'local label bindings, all',len(used),'raw/projected edge tables used')
