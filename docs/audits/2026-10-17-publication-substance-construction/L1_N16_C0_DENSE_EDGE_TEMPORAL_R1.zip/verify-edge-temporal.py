from ast import literal_eval
from collections import defaultdict
from pathlib import Path
import sys
prior,ref=map(Path,sys.argv[1:3])
def patterns(path):
    return [literal_eval(l[8:l.rindex(')')+1]) for l in path.read_text().splitlines() if l.startswith('pattern ')]
a=patterns(prior/'edge-plan.out');b=patterns(Path('edge-plan.out'))
assert len(set(a))==len(a)==32 and len(set(b))==len(b)==80
for i,p in enumerate(a):
    j=b.index(p)
    assert (prior/f'raw-edges/{i:02}.tsv').read_bytes()==Path(f'raw-edges/{j:02}.tsv').read_bytes()
    for suffix in ('','-0','-1'):
        assert (prior/f'rays/{i:02}{suffix}.tsv').read_bytes()==Path(f'rays/{j:02}{suffix}.tsv').read_bytes()
assert len(list(Path('raw-edges').glob('*.tsv')))==80
assert len(list(Path('rays').glob('*.tsv')))==240
def rows(p):
    out=defaultdict(set)
    for line in p.read_text().splitlines():
        shape,value=line.split('\t',1)
        assert value not in out[shape]
        out[shape].add(value)
    return out
baseline=rows(ref/'temporal.tsv')
control=rows(Path('temporal-control/temporal.tsv'))
actual=rows(Path('temporal.tsv'))
assert baseline==control and len(control)==14 and sum(map(len,control.values()))==167
assert len(actual)==23 and sum(map(len,actual.values()))==1089
assert len(Path('edge-bindings.tsv').read_text().splitlines())==184
assert len(Path('temporal-bindings.tsv').read_text().splitlines())==320
print('matched all 32 prior raw edges and 96 quotient and alias tables')
print('80 raw edges bound at 24 locations with 184 local assignments')
print('14 control temporal shapes and all 167 entries match exactly')
print('23 dense temporal shapes, 1089 entries, 320 local bindings')
