from ast import literal_eval
from pathlib import Path
from temporal import projector
import sys

with Path('temporal-bindings.tsv').open('w') as mapping:
    shapes=set()
    for line in Path(sys.argv[1]).read_text().splitlines():
        t,x,keys,labels=line.split('\t')
        t,x=int(t),int(x)
        keys,labels=literal_eval(keys),literal_eval(labels)
        for h in range(2):
            word=tuple((label[h],bool(t^(x!=y)))
                       for (layer,y,k),label in zip(keys,labels)
                       if layer==t and x in (y,y^(1<<k)) and label[h])
            shapes.add(word)
            print(t,x,h,labels,word,sep='\t',file=mapping)
count=0
den=0
with Path('temporal.tsv').open('w') as out:
    for shape in sorted(shapes):
        trials,rows=projector(shape)
        assert rows,shape
        den+=trials
        count+=len(rows)
        for (row,column),(r,i) in sorted(rows.items()):
            print(shape,row,column,r,i,sep='\t',file=out)
print('distinct temporal shapes',len(shapes),'candidate entries',den,'exact nonzero entries',count)
