#!/bin/bash
set -eu
order="$(python3 -B - <<'PY'
from pathlib import Path
import json
info=json.loads(Path('original-inputs.json').read_text())
print(*sorted(info,key=lambda group:(info[group]['presweep_rows'],int(group))))
PY
)"
for n in $order; do
    d="group-$n"
    source="/private/tmp/l1-geometry-component3-preparation.HJyusc/$n"
    until [ -s "$source/frontier.sha256" ] && [ -s "$source/preparation.time" ]; do sleep 5; done
    cp "$source"/{preparation.out,preparation.time,frontier.sha256} "$d/"
    (cd "$source" && shasum -a 256 -c "$OLDPWD/source-receipts/preparer-inputs.sha256") > "$d/preparer-verify.out"
    /usr/bin/time -p python3 -B -u reduce.py "$n" > "$d/replay.out" 2> "$d/replay.time"
    tail -1 "$d/replay.out"
done
