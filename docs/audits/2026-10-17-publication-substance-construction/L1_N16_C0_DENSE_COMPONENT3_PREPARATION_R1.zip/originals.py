"""Check the complete original label and selected block domain for every assigned group."""
from collections import defaultdict
from math import lcm, prod
from pathlib import Path
from runpy import run_path
import json

GROUPS=(134,158,164,183,189,201,207)

setup=run_path('source-receipts/verify.py')
plan,blocks,schema,cut=setup['load_cut']()
axes,states,_=setup['label_support'](schema,blocks)
cut_i=tuple(axes.index(w) for w in cut)
open_axes=tuple(w for w in axes if w not in cut)
indices=tuple(axes.index(w) for w in open_axes)
all_data={}
for group in GROUPS:
    g,assigned,rows,encoded,cut_key,block_ids=plan[group]
    assert group==g and assigned==8
    full=tuple(row for row in states if tuple(row[i] for i in cut_i)==cut_key)
    orig=sorted(tuple(row[i] for i in indices) for row in full)
    assert len(orig)==len(set(orig))==8 and len(open_axes)==12
    expected={name:{tuple(row[axes.index(w)] for w in label_axes) for row in full}
              for name,(label_axes,_) in schema.items()}
    actual=defaultdict(set)
    dens=defaultdict(list)
    for idx in block_ids:
        name,key,_,_,_,den=blocks[idx]
        actual[name].add(key)
        dens[name].append(den)
    fixed=dict(zip(cut,cut_key,strict=True))
    eligible=tuple(i for i,(name,key,*_) in enumerate(blocks)
                   if all(fixed[w]==v for w,v in zip(schema[name][0],key,strict=True) if w in fixed))
    assert tuple(block_ids)==eligible and set(actual)==set(expected)
    assert all(expected[name]<=actual[name] for name in actual)
    excess=sum(len(keys-expected[name]) for name,keys in actual.items())
    assert sum(blocks[i][4] for i in block_ids)==rows and sum(blocks[i][3] for i in block_ids)==encoded
    assert len(block_ids)==len(set(block_ids))
    denom=prod(lcm(*many) for many in dens.values())
    d=Path(f'group-{group}')
    d.mkdir(exist_ok=True)
    (d/'original-roster.txt').write_text(repr((open_axes,orig))+'\n')
    (d/'selected-blocks.txt').write_text(repr((cut,cut_key,block_ids))+'\n')
    all_data[group]={'presweep_rows':rows,'encoded_bytes':encoded,'selected_blocks':len(block_ids),
                     'locally_eligible_without_global_label':excess,'denominator':denom}
    print('original partition',group,'ordinals',len(orig),'blocks',len(block_ids),'rows',rows,'denominator',denom,flush=True)
Path('original-inputs.json').write_text(json.dumps(all_data,indent=2)+'\n')
