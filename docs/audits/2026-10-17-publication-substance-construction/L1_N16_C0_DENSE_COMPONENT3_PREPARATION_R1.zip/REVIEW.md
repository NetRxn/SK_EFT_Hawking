# Independent component 3 signed preparation review

The fresh continuity packet pins publication commit `7b4792bf90c3bfa17b4e5f33a8202c223d065330`. The accepted geometric cover has coefficient 192 for each of the eight selected groups in component 3. The exact directed adjacency records form a complete bipartite component with eight vertices on each side and multiplicity two for every directed edge. Group 128 remains accepted under its separate signed terminal review. This preparation review covers Groups 134, 158, 164, 183, 189, 201 and 207.

The geometric schedule ranks component 3 first among the nine partially resolved components at this checkpoint, with 15,097,734 source rows across its seven remaining selected groups. Component 14 is next at 16,114,854. Components 3 and 98 have identical multisets of source row counts on their selected sides. The accepted Group 128 result is negative and the accepted Group 1231 result is positive. The row counts rank projected preparation work, and all seven preparations here were rebuilt from their own signed data.

The original label join covers 30,976 source assignments and recovers eight distinct original joint-L tuples for each reviewed group. The independent source check verifies every selected cut and reconstructs 252 exact local blocks across 88 factor families for each group. The 88 compiled files and six preparation input files match their accepted digests. The original tuples and signed restriction outcomes appear under their original ordinals in `component-ordinal-roster.tsv`.

The independent quotient replay folds only degree-two physical axes and keeps every shared L label in the alias boundary. It checks the Gaussian scale and phase of each aliased vector and recomputes the signed coefficients. The existing two-sweep maximum and 60,000,000-product guard were preserved. All final factor scopes, coefficients and denominators agreed with their own frozen author tables. `group-preparation.tsv` records the signed-row counts, measured times, exact frontier hashes and first-empty events.

Groups **134 and 164 are exact whole-group zeros**. In each independent replay the first sweep's directed `M16 → E141` quotient took factor row counts from 992 and 2,144 to 248 and zero with 24 merged aliases. This occurred at visits 9,596,181 and 11,696,084 respectively. Both prepared products contain nine globally empty factors, so all eight original ordinals in each group have zero Gaussian numerator.

Groups **158, 183, 189, 201 and 207** have exact zero restrictions at original ordinals **1 and 3**. The exact prepared support retains original ordinals **0, 2, 4, 5, 6 and 7** in each of these five groups. This proves 26 zero ordinals among the reviewed 56 and leaves 30 independent signed terminal contractions open. No group or ordinal was relabeled.

## Reproduction

Validate `review-manifest.portable.sha256`. The committed scientific source archive names and digests appear in `source-archives.tsv`. The author frontier paths and pinned check receipts appear in the replay scripts and per-group folders. From this directory, run `python3 -B -u originals.py` to rebuild the original support, `/bin/bash replay-serial.sh` to reproduce the signed tables with the pinned author inputs available, then `python3 -B -u audit.py` for the aggregate receipts.
