# Exact shared-input performance controls

The 16 edge plans were regenerated from one exact histogram of the original
coframe roster pinned in input.sha256. The original 16 plans each scanned
the roster separately and consumed 99.86 seconds total. The shared count
took 7.09 seconds, then the 16 plans took 1.34 seconds. Each plan matched
the corresponding original output byte for byte.

The quotient benchmark regenerates each distinct raw edge input once by
SHA-256 content identity and compares all three emitted tables with the
direct run. Of 363 input tables, 94 were distinct. All 1,089 projected
tables and alias outputs matched byte for byte. The benchmark took 23.85
seconds including comparisons, versus 73.67 seconds of original quotient
stage wall time.

These are measurements of two stages on one selected cohort. The full
261.75-second run used the original stages. These experiments did not rerun
the end-to-end driver with the shared-input changes.
