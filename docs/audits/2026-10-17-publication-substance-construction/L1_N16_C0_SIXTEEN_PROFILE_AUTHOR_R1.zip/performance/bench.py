from pathlib import Path
from hashlib import sha256
from collections import Counter
from time import monotonic
import sys
base=Path(sys.argv[1])
code=(base/'edge_rays.py').read_text()
exec(code[:code.index("out=Path('rays')")])
def digest(path):
    with path.open('rb') as f:
        return sha256(f.read()).hexdigest()
records={}
total=Counter()
start=monotonic()
for line in (base/'next-cases.out').read_text().splitlines():
    a,b,w=line.split()
    profile=base/f'{a}-{b}-tiled'
    out=Path(f'{a}-{b}')
    out.mkdir()
    for path in sorted((profile/'raw-edges').glob('*.tsv')):
        identity=digest(path)
        j=path.stem
        names=(path.name,f'{j}-0.tsv',f'{j}-1.tsv')
        total['tables']+=1
        if identity in records:
            total['reused']+=1
            for name,existing in zip(names,records[identity]):
                (out/name).symlink_to(existing.resolve())
        else:
            rows,scale=read(path)
            for side in range(2):
                rows,aliases=normalize(rows,side)
                with (out/names[side+1]).open('w') as f:
                    for (word,mask),((newword,newmask),r,i) in sorted(aliases.items()):
                        print(word,mask,newword,newmask,r,i,sep='\t',file=f)
            save(out/names[0],rows,scale)
            records[identity]=tuple(out/name for name in names)
        for name in names:
            assert (profile/'rays'/name).read_bytes()==(out/name).read_bytes(),(profile,name)
print(dict(total),'unique',len(records),'seconds',round(monotonic()-start,2))
