# L1 sixteen-profile small-support exact author batch

Run `python3 verify_author.py` to reconcile all 16 rows with the accepted
predecessor residual and reconstruct each exact signed author coefficient
from its terminal case logs and four-assignment anchor roster. Chirality
fixed points count once, and exchanged pairs count twice. The large factor
tables remain local and are pinned by their per-profile checksum lists.

The sequential wall time was 261.75 seconds for this selected cohort.
The timing receipt records stage totals. This run selected only four-state,
weight-96 profiles, so its throughput applies to this cohort. Independent
review is due before recording any contribution in the accepted residual.
