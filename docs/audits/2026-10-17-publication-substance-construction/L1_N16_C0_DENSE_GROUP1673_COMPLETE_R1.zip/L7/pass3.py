from unsharded import *
from follow import relief,onefold,guarded
from gc import collect
P=Path('pass2-result.pkl')
HP='b2f8878a7bc8f8104184229105270144f514690dddd7a6fb63dd9c3ae06f6262'
MAX_STAGE=20_000_000

def main():
    t=perf_counter()
    assert sha(P)==HP
    original=read(P)
    fs=original.pop('factors')
    ids=original['factor_labels']
    assert len(fs) > 3
    live=dict(zip(ids,fs,strict=True))
    assert prod(d for _,_,d in fs)==DEN
    splits=[]
    for i,lab in enumerate(ids):
        f=fs[i]
        raw=len(f[1])
        candidates=relief(fs,i)
        best=None
        for sub,ax in candidates:
            a,b,rank=split(f,3000+i,ax)
            size=len(a[1])+len(b[1])
            print('relief tested',lab,tuple(ids[j] for j in sub),'old/new',raw,size,
                  'rows',len(a[1]),len(b[1]),'classes',rank,flush=True)
            if best is None or size<best[0]:best=(size,a,b,rank,sub)
            if best[0]*6<=raw:break
        if best and best[0]*2<raw:
            _,a,b,c,sub=best
            certify(f,a,b)
            del live[lab]
            A,B=(3000+i,0),(3000+i,1)
            live[A]=a;live[B]=b
            splits.append((lab,A,B,tuple(ids[k] for k in sub),c,len(a[1]),len(b[1]),a[2],b[2]))
            print('exact relief split',splits[-1],flush=True)
    del fs
    collect()
    original['pass3_pred_sha256']=HP
    original['pass3_splits']=splits
    checkpoint('pass3-split.pkl',original,live,[],0,[])
    forecasted={}
    for a,b in combinations(live,2):
        if s:=forecast(live[a],live[b]):forecasted[a,b]=s
    trace=[];refused=[];refused_set=set();work=0
    deadline=perf_counter()+150
    for step in range(35):
        if len(live)==1 or perf_counter()>deadline:break
        opts=[(cost*(w+1)**2,cost,w,a,b) for (a,b),(cost,w,k) in forecasted.items() if
              a[0]!=b[0] and (a,b) not in refused_set and 0<cost<=PAIR and work+cost<=MAX_STAGE]
        if not opts:break
        _,n,width,a,b=min(opts)
        if n>=500_000:
            x,y=live[a],live[b]
            sh=tuple(w for w in x[0] if w in y[0])
            u,v,s=onefold(x,y,sh)
            v,u,r=onefold(v,u,sh)
            if u is not x or v is not y:
                live[a],live[b]=u,v
                for (p,q) in forecasted:
                    if a in (p,q) or b in (p,q):forecasted[p,q]=forecast(live[p],live[q])
                now=forecasted[a,b][0]
                assert now<=n
                trace.append(('fold',a,b,n,now,s,r))
                print('exact primitive join quotient',trace[-1],flush=True)
                n=now
        print('attempt pair',a,b,'products',n,'width',width,flush=True)
        result,seen,pass_ct,status=guarded(live[a],live[b],[F for k,F in live.items() if k not in (a,b)],n,deadline)
        work+=seen
        if result is None:
            item=(a,b,n,seen,pass_ct,status)
            refused.append(item)
            refused_set.add((a,b))
            print('follow refused',item,'work',work,flush=True)
            if status=='wall':break
            continue
        label=(3100+step,0)
        live.pop(a);live.pop(b)
        forecasted={k:v for k,v in forecasted.items() if a not in k and b not in k}
        for k,F in live.items():
            if s:=forecast(F,result):forecasted[k,label]=s
        live[label]=result
        item=('join',a,b,label,seen,len(result[1]),len(result[0]),result[2],pass_ct)
        trace.append(item)
        print('exact follow join',item,'remaining',len(live),'work',work,flush=True)
    checkpoint('pass3-result.pkl',original,live,trace,work,refused)
    if len(live)==1:print('exact raw scalar',next(iter(live.values()))[1].get((),(0,0)),flush=True)
    print('follow exact terminal pair forecasts',sorted((v,a,b) for (a,b),v in forecasted.items())[:16],flush=True)
    print('follow seconds',round(perf_counter()-t,6),'RSS bytes',getrusage(RUSAGE_SELF).ru_maxrss,flush=True)

if __name__=='__main__':main()
