"""Join the independent terminal receipts to the eight author results."""
from ast import literal_eval
from pathlib import Path
import csv
import re
from zipfile import ZipFile

def review_rows(tag):
    with ZipFile(Path("independent") / f"{tag}.zip") as bundle:
        return list(csv.DictReader(bundle.read("scalar.tsv").decode().splitlines(), delimiter="\t"))

observed = {}
for tag, label_key, denominator_key in (
    ("L0", "original_joint_L_index", "inherited_factor_denominator"),
    ("L13", "original_L_assignment", "inherited_factor_denominator"),
    ("L45", "joint_L_index", "factor_denominator"),
):
    for receipt in review_rows(tag):
        assert receipt["group"] == "1673"
        assignment = int(receipt[label_key])
        assert assignment not in observed
        observed[assignment] = tuple(int(receipt[key]) for key in ("raw_real", "raw_imag", denominator_key))

for receipt in review_rows("L67"):
    assignment = int(receipt["assignment"])
    assert assignment not in observed
    assert receipt["terminal_sha256"] in (Path(f"L{assignment}") / "checkpoints.sha256").read_text()
    observed[assignment] = tuple(int(receipt[key]) for key in ("raw_re", "raw_im", "factor_denominator"))

with ZipFile("independent/L2-terminal.zip") as bundle:
    line, = (line for line in bundle.read("verify.out").decode().splitlines()
             if line.startswith("independent net scalar raw Gaussian "))
    match = re.fullmatch(r"independent net scalar raw Gaussian (\(.+\)) inherited denominator (\d+).*", line)
    assert match and 2 not in observed
    observed[2] = (*literal_eval(match[1]), int(match[2]))

author = {}
for assignment, real, imaginary, denominator in re.findall(
    r"original joint-L (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)",
    Path("AUTHOR_RETALLY.txt").read_text(),
):
    assert int(assignment) not in author
    author[int(assignment)] = int(real), int(imaginary), int(denominator)
assert sorted(observed) == list(range(8))
assert observed == author and all(imaginary == 0 for _, imaginary, _ in observed.values())
for assignment, value in sorted(observed.items()):
    print(assignment, *value, sep="\t")
