from ast import literal_eval
from fractions import Fraction
from itertools import product
from math import factorial, prod
from pathlib import Path
import re

def normalization():
    text = Path("contract-branch.py").read_text()
    codes = re.findall(r"a,b='(\d+)','(\d+)'",text)
    assert len(codes)==1
    a,b=map(int,codes[0])
    roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
    occ=[[roster[(code>>(6*x))&63] for x in range(8)] for code in (a,b)]
    edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
    world=sum((3+k)*n for sector in occ for o in sector for k,n in enumerate(o))
    cross=0
    for sector in occ:
        weights=[(u,v,sum(sector[u])-sector[u][k]+sum(sector[v])-sector[v][k]) for u,v,k in edges]
        cross+=sum(edge[2]*other[2]*(u>v) for i,edge in enumerate(weights)
                   for other in weights[i+1:] for u in edge[:2] for v in other[:2])
    total=sum(n for sector in occ for o in sector for n in o)
    mul=prod(factorial(p) for sector in occ for o in sector for p in o)
    assert total==32 and mul==16 and (world,cross)==(136,444)
    return (-1)**((world+cross)%2),mul*4**(2*total)

def raw(label):
    p=Path(f"L{label}")
    if (p/"terminal.out").is_file():
        ans=re.findall(r"triangle signed numerator [012] [012] [012] (-?\d+) (-?\d+) denominator (\d+)",(p/"terminal.out").read_text())
        assert len(ans)==2 and ans[0]==ans[1]
        return tuple(map(int,ans[0]))
    scalars=[]
    for f in sorted(p.glob("pass*.out")):
        lines=f.read_text().splitlines()
        hits=[s for s in lines if s.startswith("exact raw scalar ")]
        if not hits:continue
        assert len(hits)==1
        re_,im=literal_eval(hits[0].removeprefix("exact raw scalar "))
        last=[s for s in lines if s.startswith("exact follow join ")][-1]
        row=literal_eval(last.removeprefix("exact follow join ").split(" remaining ")[0])
        assert row[5:7]==(1,0)
        scalars.append((re_,im,row[7]))
    value, = scalars
    return value

if __name__=="__main__":
    source=Path("joint-label-roster.tsv").read_bytes()
    lines=source.decode().splitlines()
    axes=literal_eval(lines[0].split("\t")[1])
    table=[line.split("\t") for line in lines[1:]]
    assert len(set(axes))==12 and len({literal_eval(r[1]) for r in table})==8
    assert [int(r[0]) for r in table]==list(range(8))
    parts=[]
    for i,(_,_,selected,_) in enumerate(table):
        p=Path(f"L{i}")
        assert (p/"joint-label-roster.tsv").read_bytes()==source
        assert (p/"preparation.out").read_text().strip()==f"group1673 label selector {i} rows {selected} census 8"
        parts.append(raw(i))
    den, = {v[2] for v in parts}
    sign,norm=normalization()
    for i,(x,y,_) in enumerate(parts):
        print("original joint-L",i,"raw",x,y,"factor denominator",den)
    x=sum(v[0] for v in parts)
    y=sum(v[1] for v in parts)
    print("raw total",x,y)
    print("exact normalized",Fraction(sign*x,den*norm),Fraction(sign*y,den*norm))
