# L1 dense Group 1673 exact signed contraction

The original dense profile has occupation codes
`(503841882182,1461451755920)`. The previously reviewed cut-pairing archive
pins the exact prepared Group 1673 state and eight original labels of its
remaining representation indices. The prepared state hash is
`f1727decb3a1430bb85a83e5ff8528c2c5a16d38a37982a03c5c6929d3791954`.
The preceding accepted recipe reconstructs that state from original
compiled factor blocks.

Each assignment was separately selected using the full original label
tuple. The guarded contraction preserves the signed cap frontier. Its
exact inverse splits, matched joins and signed quotient operations carry
each assignment to one axis-empty factor. Each individual denominator
is inherited and kept unchanged. All imaginary terminal parts are zero.
The independent reviews check complete source-through-terminal paths,
with separate prefix and terminal reviewers for assignment 2.

To check the manifest and replay the signed normalized retally from the
archived receipts in a fresh extraction run

```sh
shasum -a 256 -c SHA256SUMS
python3 -B retally.py | cmp - AUTHOR_RETALLY.txt
python3 -B check-independents.py | cmp - INDEPENDENT_MATCH.tsv
```

To replay an author computation separately, use the original prepared
Group 1673 pickle from the preceding recipe as the source to the relevant
`L<label>/condition.py`, with the source hash shown above. Run in a clean
directory. Use the corresponding `run.py` and `contract-slice.py` to
reproduce the guarded checkpoint. Set `ROOT` in that assignment's
`unsharded.py` to the reconstructed guarded checkpoint, retaining the
original hash, shape and normalization checks. Run the unsharded stage
then the numbered follow-up stages in increasing order with the included
helpers. The checkpoint manifest pins the original outputs. Wall-time
measurements are recorded author receipts. The independent review
packages include separate exact replay commands and follow the frozen
retained joins. The independent retally includes the small, axis-empty terminal factors. The larger intermediate numerical checkpoints are supplied by replay.

Multiplying by the original orientation and occupation factor
`+1/(16*4^64)` gives the exact normalized Group 1673 value. Group 2198
has the same value by the previous exact signed chirality transfer.
The outer profile weight 48 is applied once for composition, after paired
group contributions are added. This result leaves the other dense groups,
the full signed coefficient and physical acceptance open.
