# Original N16 fixed-center continuation powers R10

## Source roster and scope

The calculation uses the original N16 closed-word, source-C seam. It
holds one S2 vertex at x and y=x+e0, one original raw contact at y,
and varies the full action exponential at w=x+e2. The actual y slots
are the literal J T_00 and the mixed J(T_00 + T_10), retaining the
same anchored J as R9.

Every nonzero term of each of the 16 actual w coframes has exterior
degree two and uses exactly one of the eight generator bits at w.
This is checked over the complete finite coframe roster. Consequently
a product with more than eight w coframes vanishes by an overlapping
exterior generator, regardless of the other incident factors. The
powers at or below that limit are exactly

| S2 power | S4 power | Exponential weight |
|---|---|---|
| 0 | 0 | 1 |
| 1 | 0 | 1 |
| 2 | 0 | 1/2 |
| 3 | 0 | 1/6 |
| 4 | 0 | 1/24 |
| 0 | 1 | 1 |
| 1 | 1 | 1 |
| 2 | 1 | 1/2 |
| 0 | 2 | 1/2 |

The weights are 1/(a!b!) from the finite exponential of the
commuting even action vertices, with original powers g2^a g1^b at w.
For a sorted w roster of multiplicities m_i the surviving canonical
multiset path has weight 1/prod_i(m_i!), accounting for the ordered
draw multiplicities. The complete raw source has 384 S2 orientations
and 24 signed S4 permutations. Twenty-four S2 groups cancel exactly,
leaving 72 live groups with the original curvature factors.

For each target, the stream uses exterior disjointness, original
ordered signs and complete commuting multisets. It indexes only
target-compatible y paths, keeps their exact signed multiplicities,
and looks up the residual key after x, w and contact factors.
The independent raw forward oracle multiplies each original w
orientation in its given coframe order using the canonical exterior
polynomial product. It forms the projected original S2 and S4 sums,
then raises them independently with 1/(a!b!) via sequential
division. The oracle groups only by the retained x and y labels.
This checks every requested complete signed coefficient independently
of the streamed multiplicity bookkeeping.

The source-power grades are disjoint. At (a,b) the requested raw
seam has exterior degree 10+4a+8b and quaternion degree 13+6a+4b,
with couplings g2^(2+a) g1^b and a single J. All nine grades have odd
quaternion degree and vanish if averaged in isolation under the
simultaneous link center reversal. This does not permit dropping
the raw coefficients before later incident factors arrive.

## Admission and evidence

The signed accumulator tests the prospective cardinality of the
entire retained output map before inserting each new record. Its
first fully labelled cubic request refused prospective record 2,049
with exactly 2,048 already retained. The exact attempted source and
stderr are preserved in the adjacent refusal files. The second variant
retained the complete x/y sum for the first cubic request with
16 records and verified its total −5i/1024 against the forward
oracle. Repeating all w paths across x branches drove the work
ledger to 15,728,765 operations after that request. The next request
reached the 20,000,000-operation cap and refused the next power
choice. The exact attempted source and stderr are preserved in the
work-refusal files.

The final variant retains w labels through local degree four. At local
degree six or eight it builds target-compatible w coefficient states
once by signed mask/key recurrence, reusing them across x branches.
The recurrence sums the grouped source vertices, multiplies with
disjoint masks, and divides each power step by its step index.
The prospective live-state cap counts the two vertex maps, previous
power map and next power map before insertion. This variant stores
the exact x/y output, along with one separately enumerated signed
w branch witness. Local-state path counts refer to the ordered
recurrence and are not compared to the low-degree multiset counts.
The raw forward oracle independently checks the full signed sum.
All variants use the same prospective output and work budgets.
Later-index records and forward products have separate prospective
caps. RSS is observed and not inferred from these logical caps.

The exact executed source imports the frozen R9 through R4 scripts,
and uses the frozen R9 JSON for branchwise sign and path-count controls.
No tracked repository or Lean work, other center construction, full
campaign, normalization, physical response or publication gate is
claimed. Powers at x and y beyond the pinned S2/contact selections,
other centers and label last-use reduction are separate work.

The first local-recurrence replay verified the same cubic coefficient
with cumulative work of 2,372,843. The next direct oracle product
refused prospective record 20,620 under the unchanged 16,384-record
scratch limit. This attempt is preserved in the oracle-refusal files.
The subsequent replay partitions only oversized oracle products into
single left coefficient rows, using the canonical exterior product for
each row, then projecting and summing the exact results before moving
to the next row. This uses distributivity of the canonical product and
keeps the same scratch and work limits. Completed exact control rows
are persisted individually to the JSONL receipt.

That partitioned replay completed twelve rows, including all three
cubic S2 requests. The literal total is −5i/1024 and the mixed total
seeded from direction zero is −i/2048. The mixed total seeded from
direction one is zero after summing 24 signed x/y groups. Its selected
complete x/w/y witness is nonzero. The next quartic target refused
prospective local state 8,193 at a cap of 8,192. The twelve JSONL rows,
attempted source and terminal trace are preserved in local-refusal
files. Each refusal describes only its attempted representation and
target under the stated caps.

The next replay scheduled smaller center degree first and completed
22 signed rows across eight alternatives. Among these, all three
S2 S4 requests have nonzero selected witnesses and cancel in the
complete sum. The literal S4^2 request gives 3i/65536. All three
S4^2 requests verified against the independent oracle. The literal
S2^2 S4 request also verified, with 12 signed groups. The next mixed
request exhausted the 20,000,000-operation ledger before another
local pair was tested. The exact code, signed receipt and terminal
trace are preserved in the schedule-refusal files.

The complement-pruned version derives the admissible final w states
from every target-compatible x/contact/y combination. In any actual
completion, the local mask is precisely the exterior complement of
those factors and the local symbol multiset is precisely the target
minus their symbol multiset. A partial w state that fits none of
these residuals cannot contribute. The prospective local cap counts
the residual map as well as the source vertices and current/next
coefficient maps. The total signed-output cap of 2,048 counts prior
accepted tables plus the current table prospectively. The oracle
continues to multiply and project original raw vertices independently.

## Terminal receipt

The final replay exited 1 after admitting 24 exact requests across
eight alternatives. Both contacts and both seed directions for the
mixed contact were exercised for each admitted alternative. All 30 R9
signed tables and path counts matched. Four minimal forbidden powers
(5,0), (3,1), (1,2), and (0,3) returned structurally empty. Of the 652
cumulative signed output records admitted, no query held more than
128. Accepted targets peaked at 32 indexed later paths and 3,274 live
local records. This is logical accounting for these maps.

Five literal S2^4 attempts each refused prospective local record
8,193. Before the next literal quartic attempt could complete, the
ledger refused a viability test at 20,000,000 charged operations.
The literal quartic and both mixed-contact quartic directions remain
unverified. The failed run has no completed summary JSON. The 24
durable signed control rows are in the progress JSONL and its
separate arithmetic audit. The earlier fully labelled cubic refusal
supplies the adverse signed-output cap test. The final run did not
reach its post-loop cap probes.

A prospective next quartic construction is to join two separately
projected S2^2/2! tables by disjoint four-generator center masks and
exact exterior and symbol complements. Divide the product by six
to recover S2^4/4!. The representation should partition retained
pair tables by center mask and retain the same direct raw controls.
This partition has not been executed.

The first intake check was fresh at d0e02889e. Fourth replay started
at that pin. The fifth and sixth replays used the same two Python
source files after ROOT advanced primary to 5a3946d00 with two Lean
paths only. The final packet reports source-only drift. The clean
source comparison and both unchanged Python hashes are retained for
ROOT's explicit reconciliation and fresh independent review.
