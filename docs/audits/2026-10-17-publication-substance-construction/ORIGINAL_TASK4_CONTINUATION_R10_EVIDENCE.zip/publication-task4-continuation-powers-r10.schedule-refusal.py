"""Bounded original fixed-center exponential queries, using exact signed exterior coefficients."""
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from fractions import Fraction
from itertools import product
from math import factorial, prod
from pathlib import Path
import importlib.util
import json
import random
import resource
import sys

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("r9_powers", HERE / "publication-task4-continuation-vertices-r9.py")
r9 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r9
spec.loader.exec_module(r9)
r8, r7, r6, r5, r4 = r9.r8, r9.r7, r9.r6, r9.r5, r9.r4
Q, P, E, S, SLOTS = r9.Q, r9.P, r9.E, r9.S, r9.SLOTS
G1, G2 = r9.G1, r9.G2
ALTERNATIVES = tuple((a,b) for b in range(3) for a in range(5-2*b))
OUTPUT_CAP = 2048
LATER_CAP = 8192
LOCAL_CAP = 8192
WORK_CAP = 20_000_000
PAIR_CAP = 16_384

@dataclass
class SignedOutput:
    cap: int
    table: dict = field(default_factory=dict)
    peak: int = 0
    seeded_coefficient: Q = Q(0)
    seeded_paths: int = 0
    local_peak: int = 0

    def put(self, key, value, paths=1):
        previous = self.table.get(key)
        if previous is None:
            prospective = len(self.table)+1
            if prospective > self.cap:
                raise RuntimeError(
                    f"signed output cap: retained {len(self.table)}, prospective {prospective}, cap {self.cap}"
                )
            self.peak = max(self.peak, prospective)
            self.table[key] = value,paths
        else:
            coefficient,previous_paths = previous
            self.table[key] = coefficient+value,previous_paths+paths

def stream_rows(operands, target, work, prefix=(0,(),Q(1))):
    """Signed path iterator with no retained full-support intermediate."""
    mask,symbols,_ = target
    def descend(i, occupied, used, left, value):
        if i == len(operands):
            work.charge("streamed_prefixes")
            yield occupied,used,left,value
            return
        for m,key,coefficient in operands[i]:
            work.charge("streamed_operand_tests")
            if m & occupied or m & mask != m:
                continue
            residue = r5.subtract(left,key)
            if residue is not None:
                yield from descend(i+1, occupied|m,tuple(sorted(used+key)),
                                   residue,value*coefficient*r5.mask_sign(occupied,m))
    occupied,used,value=prefix
    left=r5.subtract(symbols,used)
    if left is not None:
        yield from descend(0,occupied,used,left,value)

def query(target, powers, cx,hx,cw,choices,contacts,cy,hy,work, cap=OUTPUT_CAP, *, retain_w=True, seeded=None):
    """Keep each original x branch, w multiplicity tuple, and y group signed."""
    a,b = powers
    mask,symbols,slot = target
    if not a>=0 or not b>=0:
        raise ValueError("nonnegative source powers required")
    out=SignedOutput(cap)
    if 2*a+4*b>8:
        return out,0
    if mask.bit_count()!=10+4*a+8*b or symbols.count(G2)!=2+a or symbols.count(G1)!=b:
        return out,0
    def table(values):
        return {k:r7.projection(e,target,work) for k,e in values.items()}
    xc,xh,wc,yc,yh=map(table,(cx,hx,cw,cy,hy))
    d=r7.projection(contacts[slot],target,work)
    if not d:
        return out,0
    ws={2:[],4:[]}
    for key,(components,e) in choices.items():
        if (key[0]==2 and not a) or (key[0]==4 and not b):
            continue
        factors=tuple(wc[c] for c in components)
        if all(factors) and (trace:=r7.projection(e,target,work)):
            ws[key[0]].append((key,(*factors,trace)))
    def around(c,h):
        for k,trace in h.items():
            _,_,mu,nu,A,B=k
            if trace and c[mu,A] and c[nu,B]:
                yield k,(c[mu,A],c[nu,B],trace)
    later={}
    retained=0
    for key,factors in around(yc,yh):
        for m,k,_,v in stream_rows(factors,target,work):
            if retained+1>LATER_CAP:
                raise RuntimeError(f"later path cap at prospective record {retained+1}")
            retained+=1
            later.setdefault((m,k),[]).append((key,v))
    if not retain_w:
        # Materialize only target-compatible local coefficient states,
        # not the exponentially repeated w-branch path labels.
        def admit(acc,key,value,n,others):
            prev=acc.get(key)
            if prev is None:
                prospective=len(acc)+sum(map(len,others))+1
                if prospective>LOCAL_CAP:
                    raise RuntimeError(f"local DP cap at prospective record {prospective}")
                out.local_peak=max(out.local_peak,prospective)
                acc[key]=value,n
            else:
                acc[key]=prev[0]+value,prev[1]+n
        vertices={2:{},4:{}}
        for kind,branches in ws.items():
            for _,factors in branches:
                for m,k,_,v in stream_rows(factors,target,work):
                    admit(vertices[kind],(m,k),v,1,(vertices[6-kind],))
        local={}
        admit(local,(0,()),Q(1),1,tuple(vertices.values()))
        for kind,power in zip((2,4),powers,strict=True):
            for step in range(1,power+1):
                nxt={}
                for (m,k),(value,n) in local.items():
                    for (wm,wk),(wv,wn) in vertices[kind].items():
                        work.charge("local_dp_pairs")
                        if m & wm:
                            continue
                        used=tuple(sorted(k+wk))
                        if r5.subtract(symbols,used) is not None:
                            v=value*wv*r5.mask_sign(m,wm)*Fraction(1,step)
                            admit(nxt,(m|wm,used),v,n*wn,(local,*vertices.values()))
                local=nxt
        for xkey,factors in around(xc,xh):
            for m,k,left,v in stream_rows(factors,target,work):
                for (wm,wk),(wv,wn) in local.items():
                    work.charge("local_dp_outer_pairs")
                    if m & wm or r5.subtract(left,wk) is None:
                        continue
                    prefix=m|wm,tuple(sorted(k+wk)),v*wv*r5.mask_sign(m,wm)
                    for pm,_,remaining,pv in stream_rows((d,),target,work,prefix):
                        for ykey,yv in later.get((mask^pm,remaining),()):
                            work.charge("signed_output_paths")
                            out.put((xkey,(),ykey),pv*yv*r5.mask_sign(pm,mask^pm),wn)
        if seeded is not None:
            xkey,wkeys,ykey=seeded
            x_factors=dict(around(xc,xh)).get(xkey)
            w_factors=dict(ws[2]+ws[4])
            if x_factors and all(k in w_factors for k in wkeys):
                operands=(*x_factors,*(f for k in wkeys for f in w_factors[k]),d)
                weight=Fraction(1,prod(factorial(n) for n in Counter(wkeys).values()))
                for pm,_,left,pv in stream_rows(operands,target,work):
                    for actual_y,yv in later.get((mask^pm,left),()):
                        if actual_y==ykey:
                            out.seeded_coefficient+=pv*yv*r5.mask_sign(pm,mask^pm)*weight
                            out.seeded_paths+=1
        return out,retained

    def powers_walk(kind,remaining,start,prefix,keys,repeats):
        if remaining==0:
            if kind==2:
                yield from powers_walk(4,b,0,prefix,keys,1)
            else:
                yield prefix,keys
            return
        for i in range(start,len(ws[kind])):
            k,factors=ws[kind][i]
            work.charge("power_choice_tests")
            repeat=repeats+1 if keys and keys[-1]==k else 1
            for m,used,_,v in stream_rows(factors,target,work,prefix):
                yield from powers_walk(kind,remaining-1,i,
                    (m,used,v*Fraction(1,repeat)),(*keys,k),repeat)
    for xkey,factors in around(xc,xh):
        for m,k,_,v in stream_rows(factors,target,work):
            for prefix,wkey in powers_walk(2,a,0,(m,k,v),(),1):
                for pm,_,left,pv in stream_rows((d,),target,work,prefix):
                    for ykey,yv in later.get((mask^pm,left),()):
                        work.charge("signed_output_paths")
                        coefficient=pv*yv*r5.mask_sign(pm,mask^pm)
                        if (xkey,wkey,ykey)==seeded:
                            out.seeded_coefficient+=coefficient
                            out.seeded_paths+=1
                        out.put((xkey,wkey if retain_w else (),ykey),coefficient)
    return out,retained

def forward(target,powers,cx,hx,cw,raw,contacts,cy,hy,work):
    """Independent raw ordered expansion with exact canonical exterior multiplication."""
    mask,symbols,slot=target
    counts=Counter(symbols)
    def restrict(e):
        return r5.subset_factor(e,mask,counts,work)
    def mul(p,q,*retained):
        fixed=sum(map(r5.count,retained))
        left,right=r5.count(p),r5.count(q)
        if left*right+left+right+fixed<=work.oracle_record_cap:
            return restrict(work.oracle_product(p,q,*retained))
        # Each canonical product still uses the original ExteriorPolynomial
        # multiplication. Project one left coefficient row at a time and
        # admit the accumulated projected result prospectively.
        acc=E()
        for m,poly in p.terms:
            for key,value in poly.terms:
                part=E(((m,P(((key,value),))),))
                term=restrict(work.oracle_product(part,q,p,acc,*retained))
                prospective=left+right+fixed+r5.count(acc)+2*r5.count(term)
                if prospective>work.oracle_record_cap:
                    raise RuntimeError(f"oracle projected sum cap at prospective record {prospective}")
                work.oracle_max_prospective_records=max(work.oracle_max_prospective_records,prospective)
                work.charge("oracle_partitioned_products")
                acc+=term
        return acc
    one=E(((0,P.scalar(1)),))
    def multi(factors,*retained):
        p=one
        for f in factors:
            p=mul(p,f,*retained)
            if not p:
                break
        return p
    def grouped_outer(c,h):
        c={k:restrict(e) for k,e in c.items()}
        for k,e in h.items():
            _,_,mu,nu,a,b=k
            if c[mu,a] and c[nu,b]:
                p=multi((c[mu,a],c[nu,b],restrict(e)))
                if p:
                    yield k,p
    x=dict(grouped_outer(cx,hx))
    y=dict(grouped_outer(cy,hy))
    d=restrict(contacts[slot])
    w={k:restrict(e) for k,e in cw.items()}
    alternatives={2:E(),4:E()}
    for key,terms in raw.items():
        degree=key[0]
        if not powers[degree//2-1]:
            continue
        for term in terms:
            factors=tuple(w[mu,A] for _,mu,A in term.components)
            if not all(factors):
                continue
            g=G2 if degree==2 else G1
            trace=restrict(E(((0,term.coefficient*P.variable(g)),)))
            value=multi((*factors,trace),*alternatives.values(),*x.values(),*y.values())
            prospective=r5.count(alternatives[degree])+r5.count(value)
            if prospective>PAIR_CAP:
                raise RuntimeError(f"oracle vertex sum cap at prospective record {prospective}")
            alternatives[degree]+=value
    local=one
    for degree,power in zip((2,4),powers,strict=True):
        for i in range(1,power+1):
            local=mul(local,alternatives[degree],*alternatives.values(),*x.values(),*y.values())*Fraction(1,i)
    results={}
    for xkey,xb in x.items():
        for ykey,yb in y.items():
            value=r8.coefficient(multi((xb,local,d,yb),*x.values(),*y.values()),mask,symbols)
            if value:
                results[xkey,ykey]=value
    return results

def aggregate(out):
    totals=defaultdict(lambda:Q(0))
    for (x,_,y),(value,_) in out.table.items():
        totals[x,y]+=value
    return r7.nonzero(totals)

def as_r9(out):
    groups={}
    for (x,w,y),(value,n) in sorted(out.table.items()):
        values,paths=groups.setdefault((x,w[0]),({},0))
        values[y]=value
        groups[x,w[0]]=values,paths+n
    return json.loads(json.dumps([(key,r8.group_rows(values),n)
            for key,(values,n) in sorted(groups.items())]))

def setup(work):
    reg=r4.o.OriginalRegulator()
    x=reg.sites[0]
    y,w=reg.step(x,0)[0],reg.step(x,2)[0]
    cx,hx,_=r7.roster(reg,x,work)
    cy,hy,_=r7.roster(reg,y,work)
    cw,raw,choices,_=r9.source_roster(reg,w,work)
    j=P.variable(S("J",(y,0,0)))
    d0,d1=cy[0,0]*j,cy[1,0]*j
    contacts={SLOTS[0]:d0,SLOTS[1]:d0+d1}
    center_mask=255<<(8*reg.site_number(w))
    assert all((m & center_mask).bit_count()==1 and m.bit_count()==2
        for e in cw.values() for (m,_,_),_ in r4.rows(e))
    return reg,(x,y,w),(cx,hx,cw,choices,contacts,cy,hy),raw,d0,d1

def seed(powers, cx,hx,cw,choices,d,cy,hy,rng,work,seen):
    """Deterministic bounded request construction from actual disjoint source paths."""
    a,b=powers
    cache={}
    def flat(e):
        k=id(e)
        if k not in cache:
            cache[k]=tuple(r4.rows(e))
        return cache[k]
    def around(c,h,k):
        _,_,mu,nu,A,B=k
        return c[mu,A],c[nu,B],h[k]
    groups={d:tuple(k for k in choices if k[0]==d) for d in (2,4)}
    xx,yy=tuple(hx),tuple(hy)
    for attempt in range(1,2049):
        wkeys=tuple(sorted(rng.choices(groups[2],k=a)+rng.choices(groups[4],k=b)))
        xkey,ykey=rng.choice(xx),rng.choice(yy)
        wf=tuple(f for k in wkeys for f in (*(cw[t] for t in choices[k][0]),choices[k][1]))
        operands=(*wf,d,*around(cx,hx,xkey),*around(cy,hy,ykey))
        mask=0
        symbols=[]
        for e in operands:
            rr=flat(e)
            for _ in range(16):
                work.charge("seed_draws")
                (m,key,_),_=rng.choice(rr)
                if not m & mask:
                    mask|=m
                    symbols.extend(key)
                    break
            else:
                break
        else:
            core=mask,tuple(sorted(symbols))
            if core not in seen:
                yield core,(xkey,wkeys,ykey),attempt

def main():
    (HERE/"publication-task4-continuation-powers-r10.progress.jsonl").write_text("")
    work=r5.Work(cap=WORK_CAP,oracle_record_cap=PAIR_CAP)
    reg,centers,inputs,raw,d0,d1=setup(work)
    cx,hx,cw,choices,contacts,cy,hy=inputs
    prior=json.loads((HERE/"publication-task4-continuation-vertices-r9.json").read_text())
    for old in prior["targets"]:
        target=r6.decoded(old["target"])
        powers=(1,0) if old["degree"]==2 else (0,1)
        out,_=query(target,powers,*inputs,work)
        assert as_r9(out)==old["groups"],(old["seeded"],powers)
    assert len(prior["targets"])==30
    print("R9 restrictions: all 30 signed tables and path counts",file=sys.stderr,flush=True)
    rng=random.Random(20261107)
    records=[]
    refusals=[]
    seen=set()
    schedule=sorted(ALTERNATIVES,key=lambda powers: (2*powers[0]+4*powers[1], powers[0]))
    for powers in schedule:
        for slot,d,direction in ((SLOTS[0],d0,0),(SLOTS[1],d0,0),(SLOTS[1],d1,1)):
            for (mask,symbols),seeded,attempt in seed(powers,cx,hx,cw,choices,d,cy,hy,rng,work,seen):
                target=mask,symbols,slot
                # Keep all local provenance through degree four. At larger
                # powers, charge the exact output key actually retained and
                # add each completed w path immediately into the x/y table.
                retain_w=2*powers[0]+4*powers[1]<=4
                try:
                    out,later=query(target,powers,*inputs,work,retain_w=retain_w,seeded=seeded)
                except RuntimeError as exc:
                    if not str(exc).startswith(("signed output cap:", "local DP cap", "later path cap")):
                        raise
                    refusals.append(dict(powers=powers,slot=slot,direction=direction,
                                         target=r5.fingerprint(target),reason=str(exc)))
                    print("refused stream",powers,slot,direction,attempt,exc,work.used,file=sys.stderr,flush=True)
                    continue
                if not out.seeded_coefficient:
                    continue
                values=aggregate(out)
                try:
                    ref=forward(target,powers,cx,hx,cw,raw,contacts,cy,hy,work)
                except RuntimeError as exc:
                    if not str(exc).startswith(("oracle scratch cap","oracle projected sum cap","oracle vertex sum cap")):
                        raise
                    refusals.append(dict(powers=powers,slot=slot,direction=direction,
                                         target=r5.fingerprint(target),reason=str(exc)))
                    print("refused oracle",powers,slot,direction,attempt,exc,work.used,file=sys.stderr,flush=True)
                    continue
                assert values==ref,(powers,slot,direction,seeded)
                total=sum(values.values(),Q(0))
                seen.add((mask,symbols))
                print("accepted",powers,slot,direction,len(out.table),total,work.used,file=sys.stderr,flush=True)
                records.append(dict(powers=powers,slot=slot,direction=direction,
                    target=r5.fingerprint(target),seeded=seeded,attempt=attempt,
                    retained_w_labels=retain_w,seeded_coefficient=str(out.seeded_coefficient),
                    seeded_paths=out.seeded_paths,
                    table=[(k,str(v),n) for k,(v,n) in sorted(out.table.items())],
                    reference=[(k,str(v)) for k,v in sorted(ref.items())],
                    total=str(total),output_peak=out.peak,later_paths=later,local_peak=out.local_peak))
                with (HERE/"publication-task4-continuation-powers-r10.progress.jsonl").open("a") as progress:
                    print(json.dumps(records[-1]),file=progress)
                break
            else:
                raise RuntimeError(f"seed attempt cap for {powers}, {slot}, {direction}")
    row=next(t for t in records if t["output_peak"]>=2)
    target=r6.decoded(row["target"])
    controls=[]
    for cap in (0,1):
        try:
            query(target,row["powers"],*inputs,work,cap=cap)
        except RuntimeError as exc:
            assert str(exc)==f"signed output cap: retained {cap}, prospective {cap+1}, cap {cap}"
            controls.append(str(exc))
        else:
            raise AssertionError("low output cap returned a result")
    base=r6.decoded(records[-1]["target"])
    for powers in ((5,0),(3,1),(1,2),(0,3)):
        out,n=query(base,powers,*inputs,work)
        assert not out.table and n==0
    print(json.dumps(dict(
        centers=centers,extents=reg.extents,word=reg.word,convention=reg.convention,
        alternatives=ALTERNATIVES,roster=dict(S2=72,S4=24,diagonal_S2=24),
        structural_zero_beyond_center_degree=8,
        records=records,r9_restrictions=len(prior["targets"]),prospective_refusals=refusals,
        adverse_prospective_controls=controls,
        work=dict(work.counts),work_total=work.used,work_cap=WORK_CAP,
        oracle_record_cap=PAIR_CAP,oracle_prospective_peak=work.oracle_max_prospective_records,
        output_cap=OUTPUT_CAP,later_path_cap=LATER_CAP,local_dp_cap=LOCAL_CAP,
        native_peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    ),indent=2))

if __name__=="__main__":
    main()
