"""Verify the exact shape and arithmetic of the recorded R10 receipt."""
from collections import Counter,defaultdict
from fractions import Fraction
from pathlib import Path
import json
import re
import sys

path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name(
    "publication-task4-continuation-powers-r10.json"
)
partial=path.suffix==".jsonl"
result=(
    dict(records=[json.loads(line) for line in path.read_text().splitlines()],
         output_cap=2048,later_path_cap=8192,local_dp_cap=8192)
    if partial else json.loads(path.read_text())
)
alternatives={(a,b) for a in range(5) for b in range(3) if 2*a+4*b<=8}
if not partial:
    assert {tuple(p) for p in result["alternatives"]}==alternatives
    assert result["structural_zero_beyond_center_degree"]==8
    assert result["r9_restrictions"]==30
    assert result["suite_admitted"]==sum(r["output_peak"] for r in result["records"])<=result["output_cap"]
    assert result["work_total"]==sum(result["work"].values())<=result["work_cap"]
    assert result["oracle_prospective_peak"]<=result["oracle_record_cap"]
    assert result["adverse_prospective_controls"]==[
        f"signed output cap: retained {cap}, prospective {cap+1}, cap {cap}"
        for cap in (0,1)
    ]

def value(v):
    m=re.fullmatch(r"QComplex\(storage=\((-?\d+), (\d+), (-?\d+), (\d+)\)\)",v)
    assert m is not None,v
    a,b,c,d=map(int,m.groups())
    return Fraction(a,b),Fraction(c,d)

def add(a,b):
    return a[0]+b[0],a[1]+b[1]

def pair(k):
    return tuple(k[0]),tuple(k[1])

zero=(Fraction(),Fraction())
by_powers=defaultdict(Counter)
keys=set()
for row in result["records"]:
    a,b=row["powers"]
    slot=tuple(row["slot"])
    direction=row["direction"]
    identity=(a,b,slot,direction)
    assert identity not in keys
    keys.add(identity)
    target=row["target"]
    assert int(target["mask_hex"],16).bit_count()==10+4*a+8*b
    families=Counter(s[0] for s in target["symbols"])
    assert families==Counter(q=13+6*a+4*b,g2=2+a,g1=b,J=1)
    assert tuple(target["slot"])==slot
    assert len(row["table"])==row["output_peak"]<=result["output_cap"]
    assert row["later_paths"]<=result["later_path_cap"]
    assert row["local_peak"]<=result["local_dp_cap"]
    assert (row["local_peak"]==0)==row["retained_w_labels"]
    aggregated=defaultdict(lambda:zero)
    found=False
    retained=row["retained_w_labels"]
    assert retained==(2*a+4*b<=4)
    assert row["seeded_paths"]>=1 and value(row["seeded_coefficient"])!=zero
    for (x,w,y),v,n in row["table"]:
        assert n>=1
        if retained:
            assert Counter(k[0] for k in w)==Counter({2:a,4:b})
        else:
            assert w==[]
        coef=value(v)
        aggregated[tuple(x),tuple(y)]=add(aggregated[tuple(x),tuple(y)],coef)
        by_powers[a,b]["group_records"]+=1
        by_powers[a,b]["paths"]+=n
        by_powers[a,b]["repeated_branch_groups"]+=len(w)>len({tuple(k) for k in w})
        found|= [x,w,y]==row["seeded"] and coef!=zero
    assert found if retained else not found
    ref={pair(k):value(v) for k,v in row["reference"]}
    assert {k:v for k,v in aggregated.items() if v!=zero}==ref
    total=zero
    for v in ref.values():
        total=add(total,v)
    assert value(row["total"])==total
    by_powers[a,b]["zero_totals"]+=total==zero
    by_powers[a,b]["requests"]+=1
expected={(a,b,s,d) for a,b in alternatives for s,d in (((0,),0),((0,1),0),((0,1),1))}
assert (keys<=expected if partial else keys==expected)
summary=dict(
    requests=len(keys),
    missing=sorted(expected-keys),
    peak_signed_records=max(r["output_peak"] for r in result["records"]),
    cumulative_signed_records=sum(r["output_peak"] for r in result["records"]),
    peak_later_paths=max(r["later_paths"] for r in result["records"]),
    peak_live_local_records=max(r["local_peak"] for r in result["records"]),
    sums=[(powers,dict(by_powers[powers])) for powers in sorted(by_powers)],
    oracle_prospective_peak=result.get("oracle_prospective_peak"),
    work_total=result.get("work_total"),
    native_peak_rss=result.get("native_peak_rss"),
)
print(json.dumps(summary,indent=2))
