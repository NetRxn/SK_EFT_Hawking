from pathlib import Path
from collections import defaultdict, Counter
from fractions import Fraction as F
import importlib.util
import json, re, sys

base=Path('/tmp/publication-task4-continuation-powers-r10')
def read(s): return Path(str(base)+s).read_text()
def coeff(s):
    m=re.fullmatch(r'QComplex\(storage=\((-?\d+), (\d+), (-?\d+), (\d+)\)\)',s)
    assert m, s
    a,b,c,d=map(int,m.groups())
    return F(a,b),F(c,d)
def add(a,b): return a[0]+b[0],a[1]+b[1]
def z(): return F(0), F(0)
rows=[json.loads(l) for l in read('.progress.jsonl').splitlines()]
assert len(rows)==24 and not read('.json')
matrix=Counter()
charged=[]
n_records=0
for r,l in zip(rows,re.findall(r'^accepted (.*)$',read('.stderr'),re.M),strict=True):
    a,b=r['powers']
    slot=tuple(r['slot'])
    d=r['direction']
    key=(a,b,slot,d)
    matrix[key]+=1
    assert r['target']['slot']==list(slot)
    assert int(r['target']['mask_hex'],16).bit_count()==10+4*a+8*b
    types=Counter(x[0] for x in r['target']['symbols'])
    assert types=={k:v for k,v in dict(J=1,g1=b,g2=2+a,q=13+6*a+4*b).items() if v}
    out=defaultdict(z)
    group_keys=set()
    for (x,w,y),v,n in r['table']:
        x,w,y=tuple(x),tuple(map(tuple,w)),tuple(y)
        assert (x,w,y) not in group_keys and type(n) is int and n>0
        group_keys.add((x,w,y))
        if r['retained_w_labels']:
            assert Counter(k[0] for k in w)=={k:v for k,v in ((2,a),(4,b)) if v}
        else:
            assert not w
        out[x,y]=add(out[x,y],coeff(v))
    reference={(tuple(x),tuple(y)):coeff(v) for (x,y),v in r['reference']}
    assert len(reference)==len(r['reference'])
    assert {k:v for k,v in out.items() if any(v)}==reference
    result=z()
    for v in reference.values(): result=add(result,v)
    assert result==coeff(r['total']) and any(coeff(r['seeded_coefficient'])) and r['seeded_paths']>0
    n_records+=len(group_keys)
    assert r['output_peak']==len(group_keys) and n_records<=2048
    assert r['later_paths']<=8192 and r['local_peak']<=8192
    assert l.startswith(f'({a}, {b}) {slot} {d} {len(group_keys)} {r["total"]} ')
    charged.append(int(l.rsplit(' ',1)[1]))
requests={(a,b,s,d) for b in range(3) for a in range(5-2*b) for s,d in (((0,),0),((0,1),0),((0,1),1))}
assert requests-set(matrix)=={(4,0,s,d) for s,d in (((0,),0),((0,1),0),((0,1),1))}
assert set(matrix.values())=={1}
assert n_records==652 and max(charged)==15142580 and sorted(set(charged))==charged
stderr=read('.stderr')
assert stderr.count('local DP cap at prospective record 8193')==5
assert stderr.endswith('RuntimeError: fiber work cap at 20000000 on local_viability_tests plus 1\n')
assert 'prospective 2049, cap 2048' in read('.refusal.stderr')
print('ledger audit',len(rows),n_records,max(charged),max(r['local_peak'] for r in rows),flush=True)

# Bounded targeted replay, no call to R10 main, no new targets or production writes.
spec=importlib.util.spec_from_file_location('reviewed_r10',Path(str(base)+'.py'))
mod=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=mod
spec.loader.exec_module(mod)
work=mod.r5.Work(cap=2_500_000,oracle_record_cap=16384)
reg,centers,inputs,raw,*_=mod.setup(work)
cx,hx,cw,choices,contacts,cy,hy=inputs
prior=json.loads((base.parent/'publication-task4-continuation-vertices-r9.json').read_text())
for old in prior['targets']:
    target=mod.r6.decoded(old['target'])
    powers=(1,0) if old['degree']==2 else (0,1)
    out,_=mod.query(target,powers,*inputs,work)
    assert mod.as_r9(out)==old['groups']
assert len(prior['targets'])==30
for powers in ((5,0),(3,1),(1,2),(0,3)):
    out,n=mod.query(target,powers,*inputs,work)
    assert not out.table and n==0
print('R9 restrictions and forbidden replay',len(prior['targets']),work.used,flush=True)
for idx in (0,12,15):
    r=rows[idx]
    p=tuple(r['powers'])
    target=mod.r6.decoded(r['target'])
    seed=tuple(r['seeded'][0]),tuple(map(tuple,r['seeded'][1])),tuple(r['seeded'][2])
    out,n=mod.query(target,p,*inputs,work,retain_w=r['retained_w_labels'],seeded=seed)
    observed=json.loads(json.dumps([(k,str(v),n) for k,(v,n) in sorted(out.table.items())]))
    assert observed==r['table'] and str(out.seeded_coefficient)==r['seeded_coefficient']
    assert n==r['later_paths'] and out.seeded_paths==r['seeded_paths']
    ref=mod.forward(target,p,cx,hx,cw,raw,contacts,cy,hy,work)
    assert mod.aggregate(out)==ref
    assert json.loads(json.dumps([(k,str(v)) for k,v in sorted(ref.items())]))==r['reference']
    print('target replay',idx,p,work.used,flush=True)
