from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import product
from math import factorial
from random import Random
from src.vestigial.original_coefficients import ExteriorPolynomial as E, Polynomial as P, QComplex as Q, Symbol as S

rng=Random(20261107)
g=S('g2',())
marks=(S('q',(0,)),S('q',(1,)),S('q',(2,)))
fixtures=64
quartic=0
signed=0
overlap=0
selected=0
def mask(bits): return sum(1<<x for x in bits)
def join(left,right):
    lm,ls=left
    rm,rs=right
    if lm&rm: return
    il=[i for i in range(16) if (1<<i)&lm]
    ir=[i for i in range(16) if (1<<i)&rm]
    inv=sum(i>j for i,j in product(il,ir))
    return (lm|rm,tuple(sorted(ls+rs))),(-1)**inv

for _ in range(fixtures):
    generated=[]
    for i in range(16):
        # Eight center generators and eight peripheral generators. Two
        # coframes per vertex give two center and two peripheral bits.
        c=(2*(i%4),2*(i%4)+1) if i<4 else rng.sample(range(8),2)
        p=(8+2*(i%4),9+2*(i%4)) if i<4 else rng.sample(range(8,16),2)
        if i==5: c,p=([j for j in range(8) if (1<<j)&generated[4][0]],[j for j in range(8,16) if (1<<j)&generated[4][0]])
        key=(g,*sorted(rng.choices(marks,k=2))) if i!=5 else generated[4][1]
        v=Q(F(i+1,3),F((-1)**i,7)) if i!=5 else -generated[4][2]
        generated.append((mask([*c,*p]),key,v))
    assert all((m&255).bit_count()==2 and m.bit_count()==4 for m,_,_ in generated)
    direct=sum((E(((m,P(((k,v),))),)) for m,k,v in generated),E())
    # Original exterior implementation, multiplied in ordinary ordered
    # product, with factorial normalization only after the fourth factor.
    want=direct*direct*direct*direct*F(1,factorial(4))
    pairs=defaultdict(lambda:Q(0))
    for (lm,lk,lv),(rm,rk,rv) in product(generated,repeat=2):
        candidate=join((lm,lk),(rm,rk))
        if candidate is not None:
            key,sgn=candidate
            pairs[key]+=lv*rv*sgn*F(1,2)
    partitions=defaultdict(dict)
    for (m,k),v in pairs.items():
        assert (m&255).bit_count()==4
        partitions[m&255][m,k]=v
    observed=defaultdict(lambda:Q(0))
    for center,partition in partitions.items():
        for (lm,lk),lv in partition.items():
            for (rm,rk),rv in partitions.get(255^center,{}).items():
                hit=join((lm,lk),(rm,rk))
                if hit is None:
                    overlap+=1
                    continue
                key,sgn=hit
                signed+=sgn<0
                observed[key]+=lv*rv*sgn*F(1,6)
    expected={(m,k):v for m,p in want.terms for k,v in p.terms}
    assert {k:v for k,v in observed.items() if v}==expected
    quartic+=len(expected)
    # Exact full-mask and commuting-symbol complement lookup, including
    # repeated symbols. Incomplete and incompatible subtractions omitted.
    for (tm,tk),value in expected.items():
        t=Counter(tk)
        total=Q(0)
        for center,part in partitions.items():
            other=partitions.get(255^center,{})
            for (lm,lk),lv in part.items():
                c=Counter(lk)
                if lm&tm!=lm or not c<=t: continue
                rk=tuple(sorted((t-c).elements()))
                rv=other.get((tm^lm,rk),Q(0))
                key,sgn=join((lm,lk),(tm^lm,rk))
                assert key==(tm,tk)
                total+=lv*rv*sgn*F(1,6)
        assert total==value
        selected+=1
assert min(quartic,signed,overlap,selected)>0
print(f'fixtures={fixtures} quartic_nonzero={quartic} negative_sign_joins={signed} peripheral_overlap_rejections={overlap} exact_key_checks={selected}')
