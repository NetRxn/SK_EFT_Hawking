from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import pickle

root=Path(__file__).resolve().parent
networks=[]
for value in (0,1):
    with (root/f'join-cap-dense-binary-zero-child-{value}.pkl').open('rb') as handle:
        networks.append(pickle.load(handle)['factors'])
left,right=networks
domains=defaultdict(set)
for factors in networks:
    for axes,rows,_ in factors:
        for position,wire in enumerate(axes):
            if wire[0]!='L':
                domains[wire].update(row[position] for row in rows)
reflection={}
for wire,values in domains.items():
    ordered=sorted(values)
    mapping=dict(zip(ordered,reversed(ordered)))
    assert set(mapping.values())==values
    reflection[wire]=mapping
overall=Fraction(1),Fraction(0)
passed=True
for index,((axes,rows,den),(other_axes,other,other_den)) in enumerate(zip(left,right)):
    assert axes==other_axes
    transformed={
        tuple(reflection[wire][value] if wire in reflection else value for wire,value in zip(axes,row)):z
        for row,z in other.items()
    }
    assert len(transformed)==len(other)
    if rows.keys()!=transformed.keys():
        print('reflection support mismatch',index,'rows',len(rows),len(other),flush=True)
        passed=False
        break
    key=next(iter(rows))
    a,b=rows[key]
    x,y=transformed[key]
    scale=a*a+b*b
    real=x*a+y*b
    imag=y*a-x*b
    if any(x*scale!=a*real-b*imag or y*scale!=a*imag+b*real
           for key,(a,b) in rows.items() for x,y in (transformed[key],)):
        print('reflection coefficient mismatch',index,flush=True)
        passed=False
        break
    r=Fraction(real,scale)*Fraction(den,other_den)
    s=Fraction(imag,scale)*Fraction(den,other_den)
    u,v=overall
    overall=u*r-v*s,u*s+v*r
    print('reflection proportional',index,r,s,flush=True)
print('exact reflection equivalence established',passed,'relative',overall,flush=True)
