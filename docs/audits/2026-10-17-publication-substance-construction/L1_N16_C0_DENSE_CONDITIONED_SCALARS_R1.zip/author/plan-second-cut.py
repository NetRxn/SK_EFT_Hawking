from collections import Counter
from itertools import product
from pathlib import Path
import pickle

root = Path(__file__).resolve().parent
with (root / 'row-cap-physical-slice-dense-binary-zero-fixed.pkl').open('rb') as handle:
    checkpoint = pickle.load(handle)
factors = checkpoint['factors']
i, j = checkpoint['rejected_pair']
assert len(factors) == 10
degree = Counter(wire for axes, _, _ in factors for wire in axes)
assert all(count == 2 for wire, count in degree.items() if wire[0] != 'L')
shared = set(factors[i][0]) & set(factors[j][0])
candidates = set(factors[i][0]) | set(factors[j][0])
candidates = sorted(wire for wire in candidates if wire[0] != 'L' and wire not in shared)
total = sum(len(rows) for _, rows, _ in factors)
plans = []
for wire in candidates:
    incident = []
    for index, (axes, rows, _) in enumerate(factors):
        if wire in axes:
            position = axes.index(wire)
            counts = Counter(row[position] for row in rows)
            incident.append((index, counts))
    assert len(incident) == 2
    values = set(incident[0][1]) & set(incident[1][1])
    if not 2 <= len(values) <= 4:
        continue
    affected = sum(sum(counts.values()) for _, counts in incident)
    worst = max(total - affected + sum(counts[value] for _, counts in incident) for value in values)
    plans.append((worst * len(values), worst, len(values), wire, sorted(values), [index for index, _ in incident]))
for plan in sorted(plans)[:12]:
    print(repr(plan), flush=True)
assert plans
(root / 'second-cut-choice.txt').write_text(repr(min(plans)) + '\n')
print('original total', total, 'rejected pair', i, j, 'matched', checkpoint['matched'])
