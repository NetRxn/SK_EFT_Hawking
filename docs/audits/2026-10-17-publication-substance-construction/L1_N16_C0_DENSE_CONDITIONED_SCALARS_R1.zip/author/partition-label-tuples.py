from collections import Counter
from pathlib import Path
import pickle

root=Path(__file__).resolve().parent
with (root/'nine-minimum-quotient-frontier.pkl').open('rb') as handle:
    checkpoint=pickle.load(handle)
factors=checkpoint['factors']
partials=[{}]
for axes,rows,_ in factors:
    positions=[position for position,wire in enumerate(axes) if wire[0]=='L']
    scope=tuple(axes[position] for position in positions)
    projections={tuple(row[position] for position in positions) for row in rows}
    merged={}
    for old in partials:
        for values in projections:
            new=dict(zip(scope,values))
            if any(wire in old and old[wire]!=value for wire,value in new.items()):
                continue
            combined=old|new
            key=tuple(sorted(combined.items()))
            merged[key]=combined
    assert len(merged)<=100000, ('root support join cap',len(merged))
    partials=list(merged.values())
    print('label support join',len(scope),'retained tuples',len(partials),flush=True)
labels=tuple(sorted({wire for axes,_,_ in factors for wire in axes if wire[0]=='L'}))
assert all(set(partial)==set(labels) for partial in partials)
# Compare each surviving tuple against independently enumerated original branch states.
original={}
for line in (root/'checkpoint/independent/states.tsv').read_text().splitlines():
    case,time,site,direction,p,q=map(int,line.split())
    original.setdefault(case,{})[('L',time,site,direction)]=(p,q)
original_tuples={tuple(state[wire] for wire in labels) for state in original.values()}
found={tuple(partial[wire] for wire in labels) for partial in partials}
assert found<=original_tuples, ('new representation assignments',found-original_tuples)
print('surviving tuples',len(found),'original projected states',len(original_tuples),flush=True)
plans=[]
for index,partial in enumerate(sorted(partials,key=lambda item:tuple(item[wire] for wire in labels))):
    row_counts=[]
    for axes,rows,_ in factors:
        positions=[(position,partial[wire]) for position,wire in enumerate(axes) if wire in partial]
        row_counts.append(sum(all(row[position]==value for position,value in positions) for row in rows))
    plans.append((sum(row_counts),index,partial,row_counts))
    print('tuple',index,'stored rows',sum(row_counts),'per factor',row_counts,flush=True)
total,index,selected,counts=min(plans)
new_factors=[]
for axes,rows,denominator in factors:
    conditions=[(position,selected[wire]) for position,wire in enumerate(axes) if wire in selected]
    positions=[position for position,wire in enumerate(axes) if wire not in selected]
    new_rows={
        tuple(row[position] for position in positions):z
        for row,z in rows.items()
        if all(row[position]==value for position,value in conditions)
    }
    assert len(new_rows)==sum(all(row[position]==value for position,value in conditions) for row in rows)
    new_factors.append((tuple(axes[position] for position in positions),new_rows,denominator))
checkpoint['factors']=new_factors
checkpoint['conditioning']=checkpoint['conditioning']+list(sorted(selected.items()))
checkpoint['label_partition']={'index':index,'count':len(plans),'values':selected}
with (root/'label-tuple-selected-frontier.pkl').open('xb') as handle:
    pickle.dump(checkpoint,handle,protocol=5)
(root/'label-partition-roster.txt').write_text(repr(plans)+'\n')
print('selected',index,total,flush=True)
