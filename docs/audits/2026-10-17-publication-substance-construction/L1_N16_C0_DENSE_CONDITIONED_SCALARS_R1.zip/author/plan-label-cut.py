from collections import Counter
from pathlib import Path
import pickle

root=Path(__file__).resolve().parent
with (root/'nine-minimum-quotient-frontier.pkl').open('rb') as handle:
    checkpoint=pickle.load(handle)
factors=checkpoint['factors']
labels=sorted({wire for axes,_,_ in factors for wire in axes if wire[0]=='L'})
total=sum(len(rows) for _,rows,_ in factors)
plans=[]
for wire in labels:
    histograms=[]
    for index,(axes,rows,_) in enumerate(factors):
        if wire in axes:
            position=axes.index(wire)
            histograms.append((index,Counter(row[position] for row in rows)))
    values=set.intersection(*(set(histogram) for _,histogram in histograms))
    if not 2<=len(values)<=8:
        continue
    affected=sum(sum(histogram.values()) for _,histogram in histograms)
    costs={value:total-affected+sum(histogram[value] for _,histogram in histograms) for value in values}
    plans.append((max(costs.values())*len(values),max(costs.values()),len(values),wire,sorted(values),[index for index,_ in histograms],costs))
for plan in sorted(plans):
    print(plan,flush=True)
assert plans
(root/'label-cut-choice.txt').write_text(repr(min(plans))+'\n')
