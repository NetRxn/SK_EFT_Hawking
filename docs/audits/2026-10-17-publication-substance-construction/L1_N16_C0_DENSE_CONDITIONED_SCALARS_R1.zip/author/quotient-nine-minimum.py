from collections import Counter
from pathlib import Path
import pickle

root=Path(__file__).resolve().parent
exec((root/'checkpoint/quotient.py').read_text().split('\nlocal_test()\n',1)[0])
local_test()
with (root/'join-cap-dense-binary-zero-child-0.pkl').open('rb') as handle:
    checkpoint=pickle.load(handle)
factors=checkpoint['factors']
degree=Counter(wire for axes,_,_ in factors for wire in axes)
i,j=4,5
def cost():
    shared=tuple(wire for wire in factors[i][0] if wire in factors[j][0])
    histograms=[]
    for axes,rows,_ in (factors[i],factors[j]):
        positions=tuple(axes.index(wire) for wire in shared)
        histograms.append(Counter(tuple(row[p] for p in positions) for row in rows))
    left,right=histograms
    return sum(count*right[key] for key,count in left.items())
before=cost()
for a,b in ((i,j),(j,i),(i,j)):
    factors[a],factors[b],folded=quotient(factors[a],factors[b],degree)
    print('quotient',a,b,'folded',folded,'rows',len(factors[a][1]),len(factors[b][1]),flush=True)
after=cost()
print('matched products',before,'to',after,flush=True)
assert after<=before
with (root/'nine-minimum-quotient-frontier.pkl').open('xb') as handle:
    pickle.dump(checkpoint,handle,protocol=5)
