from ast import literal_eval
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import product
from math import factorial,prod
from pathlib import Path
from types import SimpleNamespace
import pickle,sys

with Path('row-cap-physical-slice-dense-binary-zero-fixed.pkl').open('rb') as f:
    obj=pickle.load(f)
wire=('R', 0, 6, 1, 1, 1)
value=int(sys.argv[1])
assert value in (0,1)
obj['conditioning']=[(('R',1,3,0,2,1),0),(wire,value)]
factors=[]
incidences=0
for axes,rows,denominator in obj['factors']:
    if wire not in axes:
        factors.append((axes,rows,denominator))
        continue
    incidences+=1
    position=axes.index(wire)
    selected={row[:position]+row[position+1:]:z for row,z in rows.items() if row[position]==value}
    assert len(selected)==sum(row[position]==value for row in rows)
    factors.append((tuple(axis for axis in axes if axis!=wire),selected,denominator))
assert incidences==2
index=f'dense-binary-zero-child-{value}'
a,b='503841882182','1461451755920'
roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occ=[[roster[(int(code)>>(6*x))&63] for x in range(8)] for code in (a,b)]
edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
cases=[SimpleNamespace(occ=occ,edges=edges)]
print('saved frontier cut',wire,value,'factors',len(factors),'prior matched work',obj['used_before'],flush=True)
from collections import defaultdict,Counter
from math import gcd
from pathlib import Path
import pickle

def rotate(a,b,n):
    return ((a,b),(-b,a),(-a,-b),(b,-a))[n]

def project(row,indices):
    return tuple(row[i] for i in indices)

def quotient(left,right,degrees):
    la,L,ld=left
    ra,R,rd=right
    shared=tuple(w for w in la if w in ra)
    closed=tuple(w for w in shared if w[0]!='L' and degrees[w]==2)
    boundary=tuple(w for w in shared if w not in closed)
    private=tuple(w for w in la if w not in shared)
    if not closed:
        return left,right,0
    # Never move coefficients between different shared boundary labels.
    li=tuple(la.index(w) for w in shared)
    ri=tuple(ra.index(w) for w in shared)
    lr=tuple(la.index(w) for w in private)
    bi=tuple(shared.index(w) for w in boundary)
    other=tuple(w for w in ra if w not in shared)
    ro=tuple(ra.index(w) for w in other)
    keys={project(row,ri) for row in R}
    slices=defaultdict(list)
    for row,(a,b) in L.items():
        key=project(row,li)
        if key in keys:
            slices[key].append((project(row,lr),a,b))
    equivalence={}
    aliases={}
    for key,items in sorted(slices.items()):
        items.sort()
        g=0
        for _,a,b in items:
            g=gcd(g,gcd(a,b))
            if g==1:
                break
        assert g>0
        _,a,b=items[0]
        phase=max(range(4),key=lambda j:rotate(a,b,j))
        signature=tuple((pos,*rotate(x//g,y//g,phase)) for pos,x,y in items)
        dst=equivalence.setdefault((project(key,bi),signature),key)
        aliases[key]=(dst,*rotate(g,0,(-phase)%4))
    if len(equivalence)==len(slices)==len(keys):
        return left,right,0
    outL={dst+pos:(a,b) for (_,signature),dst in equivalence.items() for pos,a,b in signature}
    outR={}
    for row,(a,b) in R.items():
        alias=aliases.get(project(row,ri))
        if alias is None:
            continue
        dst,x,y=alias
        key=dst+project(row,ro)
        r,n=outR.get(key,(0,0))
        z=r+a*x-b*y,n+a*y+b*x
        if any(z):
            outR[key]=z
        else:
            outR.pop(key,None)
    return (shared+private,outL,ld),(shared+other,outR,rd),len(slices)-len(equivalence)

def local_test():
    u=('L',0); p=('G',0); x=('W',0)
    left=((u,p,x),{(0,1,2):(2,0),(0,2,2):(0,4),(1,1,2):(2,0)},1)
    right=((u,p),{(0,1):(3,0),(0,2):(5,0),(1,1):(7,0)},1)
    a,b,m=quotient(left,right,Counter({u:3,p:2,x:1}))
    assert m==1
    def literal(a,b):
        A,L,_=a;B,R,_=b
        ans=defaultdict(lambda:(0,0))
        for row,(x,y) in L.items():
            s=dict(zip(A,row))
            for col,(r,t) in R.items():
                d=dict(zip(B,col))
                if all(d[k]==s[k] for k in set(A)&set(B)):
                    key=s[u],s[('W',0)]
                    d0,d1=ans[key]
                    ans[key]=d0+x*r-y*t,d1+x*t+y*r
        return ans
    assert literal(a,b)==literal(left,right)=={(0,2):(6,20),(1,2):(14,0)}
local_test()

def hist(f,shared):
    axes,rows,d=f
    pos=tuple(axes.index(k) for k in shared)
    return Counter(tuple(row[i] for i in pos) for row in rows)
def score(i,j,factors,degree):
    a,b=factors[i],factors[j]
    shared=tuple(k for k in a[0] if k in b[0])
    union=set(a[0])|set(b[0])
    closed=sum(degree[k]==(2 if k in shared else 1) for k in union)
    # First pick by cheap size proxy. Compute exact work only for shortlisted joins.
    return len(a[1])*len(b[1])*(1+len(union)-closed),i,j,shared
def intersect_targets(factors, focus=None):
    from itertools import combinations
    pairs=[(i,j) for i,j in combinations(range(len(factors)),2)
           if focus is None or focus in (i,j)]
    for i,j in pairs:
        la,lr,_=factors[i]
        ra,rr,_=factors[j]
        shared=tuple(k for k in la if k in ra)
        if not shared:
            continue
        li=tuple(la.index(k) for k in shared)
        ri=tuple(ra.index(k) for k in shared)
        left={tuple(row[u] for u in li) for row in lr}
        right={tuple(row[u] for u in ri) for row in rr}
        if left!=right:
            allowed=left&right
            for rows,positions,found in ((lr,li,left),(rr,ri,right)):
                if allowed!=found:
                    for row in list(rows):
                        if tuple(row[u] for u in positions) not in allowed:
                            del rows[row]

peak=max(len(r) for _,r,_ in factors)
intersect_targets(factors)
intersect_targets(factors)
work=0
while len(factors)>1:
    degree=Counter(k for axes,_,_ in factors for k in axes)
    from itertools import combinations
    candidates=sorted(score(i,j,factors,degree) for i,j in combinations(range(len(factors)),2))
    linked=[x for x in candidates if any(k[0]!='L' for k in x[3])]
    candidates=linked or candidates
    costs=[]
    for _,i,j,shared in candidates:
        ah,bh=hist(factors[i],shared),hist(factors[j],shared)
        matched=sum(n*bh[k] for k,n in ah.items())
        union=set(factors[i][0])|set(factors[j][0])
        width=sum(degree[k]>(2 if k in shared else 1) for k in union)
        if matched<=8_000_000 and work+matched<=40_000_000:
            costs.append((matched*(1+width)**2,matched,i,j,shared))
            if len(costs)==12:
                break
    assert costs,('no admitted join',len(factors),work)
    _,matched,i,j,shared=min(costs)
    original=matched
    if matched>50000:
        factors[i],factors[j],n=quotient(factors[i],factors[j],degree)
        factors[j],factors[i],m=quotient(factors[j],factors[i],degree)
        shared=tuple(k for k in factors[i][0] if k in factors[j][0])
        al,br=hist(factors[i],shared),hist(factors[j],shared)
        matched=sum(v*br[k] for k,v in al.items())
        assert matched<=original
        print('quotient before join',len(factors),original,matched,'slices',n+m,flush=True)
    assert matched<=8_000_000 and work+matched<=40_000_000,('products',len(factors),matched,work)
    work+=matched
    la,lr,ld=factors[i]
    ra,rr,rd=factors[j]
    li=[la.index(k) for k in shared]
    ri=[ra.index(k) for k in shared]
    left=[u for u,k in enumerate(la) if degree[k]>(2 if k in shared else 1)]
    right=[u for u,k in enumerate(ra) if k not in la and degree[k]>1]
    keys=tuple(la[u] for u in left)+tuple(ra[u] for u in right)
    lookup=defaultdict(list)
    for row,z in rr.items():
        lookup[tuple(row[u] for u in ri)].append((tuple(row[u] for u in right),z))
    checks=[]
    if matched>250000:
        for peer,(scope,rows,_) in enumerate(factors):
            if peer in (i,j):
                continue
            shared_out=tuple(k for k in scope if k in keys)
            if not shared_out:
                continue
            source_positions=tuple(scope.index(k) for k in shared_out)
            positions=tuple(keys.index(k) for k in shared_out)
            projection={tuple(row[u] for u in source_positions) for row in rows}
            checks.append((positions,projection))
        checks.sort(key=lambda x:(len(x[1]),-len(x[0])))
    out={}
    for row,(x,y) in lr.items():
        base=tuple(row[u] for u in left)
        for tail,(a0,b0) in lookup[tuple(row[u] for u in li)]:
            k=base+tail
            if any(tuple(k[i] for i in axes) not in projection for axes,projection in checks):
                continue
            r,n=out.get(k,(0,0))
            z=r+x*a0-y*b0,n+x*b0+y*a0
            if any(z):
                if k not in out and len(out)>=500000:
                    import pickle
                    envelope={'factors':factors,'used_before':work-matched,
                              'rejected_pair':(i,j),'matched':matched,'physical_cut':(wire,value),'conditioning':obj['conditioning']}
                    tmp=Path(f'row-cap-physical-slice-{index}.tmp')
                    with tmp.open('xb') as handle:
                        pickle.dump(envelope,handle,protocol=5)
                    tmp.rename(tmp.with_suffix('.pkl'))
                    print('open row cap', len(factors), matched, 'frontier saved',flush=True)
                    raise SystemExit(2)
                out[k]=z
            else:
                out.pop(k,None)
    factors.pop(j)
    factors.pop(i)
    factors.append((keys,out,ld*rd))
    intersect_targets(factors,len(factors)-1)
    if len(factors)%8==0:
        intersect_targets(factors)
    peak=max(peak,len(out))
    print('join',len(factors),matched,len(out),'axes',len(keys),flush=True)
axes,scalar,den=factors[0]
assert not axes
c=cases[0]
world=sum((3+k)*n for row in c.occ for o in row for k,n in enumerate(o))
cross=0
for m in c.occ:
    weighted=[(u,v,sum(m[u])-m[u][k]+sum(m[v])-m[v][k]) for u,v,k in c.edges]
    cross+=sum(a[2]*b[2]*(u>v) for i,a in enumerate(weighted) for b in weighted[i+1:]
               for u in a[:2] for v in b[:2])
phase=(-1)**((world+cross)%2)
total=sum(n for m in c.occ for row in m for n in row)
assert total==32
norm=den*prod(factorial(p) for m in c.occ for o in m for p in o)*4**(2*total)
re,im=scalar.get((),(0,0))
actual=Fraction(phase*re,norm)
imaginary=Fraction(phase*im,norm)
print('exact normalized real',actual,'imaginary',imaginary,'peak rows',peak,'matched products',work)
