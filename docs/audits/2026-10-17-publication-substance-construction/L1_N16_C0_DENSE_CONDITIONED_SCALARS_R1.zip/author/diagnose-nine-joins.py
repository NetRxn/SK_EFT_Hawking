from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle

root=Path(__file__).resolve().parent
with (root/'join-cap-dense-binary-zero-child-0.pkl').open('rb') as handle:
    checkpoint=pickle.load(handle)
factors=checkpoint['factors']
degree=Counter(wire for axes,_,_ in factors for wire in axes)
records=[]
for i,j in combinations(range(len(factors)),2):
    a,rows,_=factors[i]
    b,other,_=factors[j]
    shared=tuple(wire for wire in a if wire in b)
    left_positions=tuple(a.index(wire) for wire in shared)
    right_positions=tuple(b.index(wire) for wire in shared)
    left=Counter(tuple(row[p] for p in left_positions) for row in rows)
    right=Counter(tuple(row[p] for p in right_positions) for row in other)
    matched=sum(count*right[key] for key,count in left.items())
    union=set(a)|set(b)
    width=sum(degree[wire]>(2 if wire in shared else 1) for wire in union)
    records.append((matched,width,i,j,sum(wire[0]!='L' for wire in shared),len(shared)))
for record in sorted(records):
    print(record,flush=True)
print('total stored rows',sum(len(rows) for _,rows,_ in factors),flush=True)
