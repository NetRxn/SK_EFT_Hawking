# Scoped review: second cut and no-admitted-join recovery

2026-11-19. Reviewer /root/dense_binary_review. R4 packet checked first: fresh=true, changed=[]. Existing REVIEW.md and REVIEW_FIXED.md preserved. No repository/Lean mutations or large contractions performed.

## Accepted correction and conditioning

The diff contract-second-cut.py -> contract-second-cut-r2.py replaces only assert costs with a save-then-exit2 block. At this location no candidate has been admitted and no next-join accumulator exists; factors are the exact current frontier after completed joins/support filtering. Saving them, work, latest cut, full conditioning list and explicit refusal preserves the exact unfinished problem. The new control executes the frozen AST refusal block with tiny Gaussian-rational factors: terminal exit2, byte-readable equal factors/denominators/work/conditioning, temporary file removed by successful rename. The previous version lost this current frontier on assertion; R2 remedies that numerical recovery failure without changing contraction arithmetic or admission.

The temporary file is opened exclusively then renamed in the same directory, giving atomic namespace publication under normal filesystem semantics. This is not an fsync-backed power-loss durability guarantee. Path.rename can replace an existing target, so runs should continue using unique index/output names and retain prior checkpoints, as the present distinct R2 run does.

The second cut ('R',0,6,1,1,1) is a representative summation index in the already conditioned quotient network. It occurs exactly twice, both domains exactly {0,1}. Actual row counts are2,496 per value in factor2, and145,344 per value in factor4. Conditioning both factors on the same value and deleting the coordinate is injective within each slice and disjoint/exhaustive across the two slices. Earlier 400 literal controls already verify this operation for complex rational networks. The root path first cut0 -> second cut0 is recorded explicitly; no extra physical spin/event interpretation or multiplicity is warranted.

The actual saved nine-factor checkpoint contains the expected conditioning list, no remaining cut axis, used_before349056, and the same denominator product as its ten-factor parent. This structural check does not independently repeat the349056-product join arithmetic. Its terminal root log reports10->9 factors and subsequent refusal, with no scalar.

## Independently verified terminal diagnostics

Commands:

python3 /private/tmp/l1-dense-binary-review-20261119/second-controls.py > /private/tmp/l1-dense-binary-review-20261119/second-controls.out

python3 /private/tmp/l1-dense-binary-review-20261119/recovery-control.py > /private/tmp/l1-dense-binary-review-20261119/recovery-control.out

An independent direct projection-count implementation recomputes all36 pair matched-product estimates from the saved frontier without joining tensors. Every tuple equals diagnose-nine-joins.out. Minimum is9,609,472 matched products, pair4,5, retained width36, four shared non-L indices and no shared L indices. All candidates exceed the8M per-join gate. Total stored rows1,110,648. The diagnostic measures potential matched products, not completed products or resulting rows.

quotient-nine-minimum.out is terminal: three exact quotient passes fold zero slices and leave9,609,472 products. Independently comparing entire loaded checkpoints verifies nine-minimum-quotient-frontier.pkl equals the nine-factor input envelope. Thus no contraction or cost reduction was obtained; it remains over budget. The already reviewed quotient applies legitimately before join admission, since its correctness does not depend on charging the hypothetical tensor join.

## Practical next exact step

Forecast another exact representative-index partition before changing budgets. The minimum pair's four shared non-L indices are natural candidates: measure conditional histogram products for each supported value, plus predicted total retained rows and other candidate joins. Select a disjoint exhaustive cut whose child join costs fit8M, save each child's complete conditioning and recombine exact complex subtotals. A balanced binary split of9.6M would fit the product gate, but balance and output-row behavior require measurement; no success is inferred. Repeating unchanged quotient passes on pair4,5 has no measured benefit.

Rechecked the exact row-cap envelope at line234: it DOES include obj['conditioning']. My preliminary message incorrectly described it as omitting that field. Both refusal paths preserve the full conditioning chain; no such provenance defect remains in this frozen R4 driver. The continuity check remains fresh after reinspection.

A remaining L-label separator is also exact and may be more effective because it constrains multiple incident factors. Prior acceptance of all eight original branch128 assignments does not guarantee eight surviving assignments here, but conditioning on the complete feasible remaining L-label tuples provides an exact disjoint partition. Prefer measured per-child retained rows and predicted join/output sizes when choosing between L-label and non-L cuts. No L-label can be merged across values, but exhaustive explicit conditioning on it is valid.

Accepted scope is exact recovery/source reasoning plus terminal diagnostic verification. No second child total, original first contribution, branch128 subtotal, full signed coefficient, c0, physical B3 or publication acceptance follows.
