# Independently replayed exact selected scalar

2026-11-19; reviewer /root/dense_binary_review. R6 continuity check fresh=true, changed=[]. Acceptance is only label tuple5 within representative-index child(0,0) of archived branch128. No repository/Lean changes. Frozen input/output hashes: scalar-inputs.sha256.

## Exact result reproduced

Normalized real value:

-10493250771659057325 / 1298074214633706907132624082305024

Imaginary component: exactly0.

Independent raw Gaussian scalar numerator:

(-1783019300254394241636886075857867990382117316088606543052800,0)

Factor denominator product:

40512224221827380280140849737629696.

Apply external+1/(16*4^64), independently verified for this declared profile in the earlier review; dividing the raw real numerator by factor-denominator-product*16*4^64 gives the stated fraction exactly. No extra root-tuple/orbit/chirality weight was inserted.

## Independent arithmetic and bounds

python3 /private/tmp/l1-dense-binary-review-20261119/replay-selected-five.py > /private/tmp/l1-dense-binary-review-20261119/replay-selected-five.out

This new reviewer implementation imports no author quotient or contraction routine. It reads only the frozen five-reduced-frontier.pkl, verifies all indices have degree two and no remaining L axes, greedily selects joins by independently forecast matched row pairs, directly sums Gaussian integer products over every shared index, and multiplies exact integer denominators. No peer-support pruning, quotient, singleton shortcut or floating-point arithmetic enters this replay. It checks actual matched products against forecasts and checks the final denominator against the original five-factor product.

Its join schedule differs from the author's. Four joins used13,824;46,080;1,223,424;13,824 products, totaling1,297,152. Output rows13,824;46,080;13,824;1. Runtime1.2535s. These fit all assigned bounds:8M products/join,20M total,1M output rows,30s wall. The terminal equality assertion against the author's exact rational value passed, and imaginary component was zero independently. Author's73,568-product schedule used additional quotient reduction; differing product counts reflect distinct exact schedules, not an arithmetic discrepancy.

## Evidence boundary

This confirms direct exact contraction of the supplied reduced frontier and its declared normalization/provenance. REVIEW_LABEL_PARTITION.md separately accepts selected-row construction and disjoint/exhaustive six-tuple partition. Previous reviews support source-to-frontier exact transformations; this replay does not independently rebuild every archived source tensor or repeat the entire earlier contraction history.

Accepted partial scientific result: one of six remaining root-label tuples under both internal representative cuts0. The other five tuple values, the second-cut1 sibling under first-cut0, first-cut1, all other archived branch groups, full profile/coefficient/c0, physical B3 and publication readiness remain open. No subtotal beyond this exact contribution is accepted.
