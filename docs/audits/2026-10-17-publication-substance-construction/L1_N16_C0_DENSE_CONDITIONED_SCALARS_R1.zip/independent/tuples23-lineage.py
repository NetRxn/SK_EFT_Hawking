from pathlib import Path
from math import prod
from fractions import Fraction
import ast,pickle
D=Path('/private/tmp/l1-dense-resume.bbZW6V')
def load(n):
    with (D/n).open('rb') as f:return pickle.load(f)
base=load('nine-minimum-quotient-frontier.pkl');plans=ast.literal_eval((D/'label-partition-roster.txt').read_text())
for index in (2,3):
    total,_,chosen,counts=next(p for p in plans if p[1]==index);selected=load(f'label-tuple-{index}-frontier.pkl')
    for i,((a,r,d),(b,s,e)) in enumerate(zip(base['factors'],selected['factors'])):
        assert b==tuple(k for k in a if k not in chosen) and d==e and len(s)==counts[i]
        restored={tuple(chosen[k] if k in chosen else row[b.index(k)] for k in a):z for row,z in s.items()}
        assert restored=={row:z for row,z in r.items() if all(k not in chosen or row[p]==chosen[k] for p,k in enumerate(a))}
    assert selected['conditioning']==base['conditioning']+sorted(chosen.items())
    assert selected['label_partition']==dict(index=index,count=6,values=chosen)
    print('PASS tuple',index,'selection inverse-lift exact coefficients/denominators, rowcounts',counts,'total',total)
    cap='row-cap-physical-slice-dense-label-2a-reduced.pkl' if index==2 else 'join-cap-dense-label-3a-reduced.pkl'
    for n in (f'label-{index}a-reduced-frontier.pkl',cap,f'label-{index}b-reduced-frontier.pkl'):
        o=load(n);assert o['conditioning']==selected['conditioning'] and o['label_partition']==selected['label_partition']
        assert prod(d for a,r,d in o['factors'])==prod(d for a,r,d in selected['factors'])
        assert not any(k[0]=='L' for a,r,d in o['factors'] for k in a)
        print(n,'factors',len(o['factors']),'rows',sum(len(r) for a,r,d in o['factors']),'used_before',o['used_before'],'metadata/denominator PASS')
partial=sum([Fraction(761799400259723226207,2658455991569831745807614120560689152),Fraction(341130692358955201725,166153499473114484112975882535043072),Fraction(6319960913952819098631,332306998946228968225951765070086144),Fraction(-10493250771659057325,1298074214633706907132624082305024)])
print('four accepted tuple partial2+3+4+5',partial,'imaginary0; excludes tuples0,1 and wider siblings')
