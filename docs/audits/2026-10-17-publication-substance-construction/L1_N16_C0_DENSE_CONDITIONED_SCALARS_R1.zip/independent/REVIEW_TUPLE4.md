# Independent tuple4 adapter, lineage and scalar review

2026-11-19, /root/dense_binary_review. R7 continuity checked first: fresh=true, changed=[]. Earlier accepted tuple5 reports preserved. Scratch-only changes; no repository/Lean mutation. Frozen reviewed inputs: tuple4-inputs.sha256.

## Accepted exact partial scalar

6319960913952819098631 / 332306998946228968225951765070086144

Imaginary component exactly0. Acceptance is tuple4 inside representative-index child(0,0), not the six-tuple sum or any other sibling.

## Adapter and actual lineage checks

prepare-label-tuple.py reads one unique tuple index from the already independently audited frozen roster, selects every incident L value, drops only those fixed coordinates, checks projection injectivity and verifies per-factor row counts. Independent inverse lifting of the actual tuple4 output exactly recovers all selected source rows/coefficients/denominators. Total selected rows142,336. Complete conditioning equals the two preceding representative cuts plus sorted tuple4 labels; label_partition has index4,count6 and correct values.

The exact generic contraction diffs alter only input filename and output/provenance tag setup. reduce-label-frontier.py differs from accepted reduce-five.py only in input/tag arguments and widening factor-count assertion to2..9. Gaussian arithmetic, singleton criterion/injectivity, quotient routine, two-sweep schedule,60M scan bound, denominator handling, join caps and exact complex normalization remain unchanged. Actual lineage input/tag metadata was independently checked at every saved stage; argument labels alone are not used as proof of identity.

Observed stages:

- Seven-factor row-cap:456,208 rows; used_before2,136,576.
- First reduction:27 singleton indices removed,69,992 rows; zero additional folds on second sweep.
- Four-factor row-cap:579,616 rows; used_before5,015,424.
- Second reduction:one singleton index removed,28,560 rows after29904 intermediate rows.

Both row-caps preserve exact prejoin factors; incomplete candidate outputs do not enter the saved state. All four envelopes retain exactly the selected tuple conditioning and partition metadata, no remaining L axes, and identical total factor-denominator product40512224221827380280140849737629696. used_before records completed work in the corresponding invocation, not a new cumulative campaign claim. Generic reducer overwrites its descriptive second_stripped_fixed_coordinates field on each stage, while the frozen preceding checkpoints retain earlier maps; arithmetic and conditioning remain preserved.

## Independent direct replay

Commands:

python3 /private/tmp/l1-dense-binary-review-20261119/tuple4-lineage.py > /private/tmp/l1-dense-binary-review-20261119/tuple4-lineage.out

python3 /private/tmp/l1-dense-binary-review-20261119/replay-tuple4.py > /private/tmp/l1-dense-binary-review-20261119/replay-tuple4.out

Independent replay reuses the reviewer's prior direct sparse Gaussian-integer join implementation, imports no author quotient/contraction routine, and performs no quotient or support-pruning shortcuts. It verifies degree-two incidence and final denominator product. Three joins used88,416;244,800;3,456 products, totaling336,672. Output rows29,472;3,456;1. Runtime0.3694s. Assigned limits all respected:1M output rows,8M products/join,20M total,30s wall. Author's129,600-product schedule uses quotient; differing counts reflect different exact methods.

Independent raw scalar numerator4194888476577656107339869230704653970715495428672365300547584, imaginary0. Divide by factor-denominator product times16*4^64, the previously independently verified external normalization for this declared profile, to reproduce the exact author fraction above. No orbit/chirality/root-label multiplicity was added.

## Remaining boundary

This independently verifies contraction of the supplied reduced frontier, exact tuple4 selection, adapter equivalence and observed lineage metadata. Earlier accepted local algebra supports the intervening singleton/quotient reductions; this review does not rebuild every source tensor or reperform all earlier joins. Remaining tuples0..3, other representative-cut siblings, full branch/profile/coefficient/c0 and physical/publication obligations remain open.
