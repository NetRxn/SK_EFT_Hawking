from pathlib import Path
from collections import defaultdict,Counter
from itertools import product
from math import prod
import ast,pickle,random
D=Path('/private/tmp/l1-dense-child01.zdXzYQ')
def load(n):
    with (D/n).open('rb') as f:return pickle.load(f)
o=load('nine-minimum-quotient-frontier.pkl');fs=o['factors'];labels=sorted({k for a,r,d in fs for k in a if k[0]=='L'})
# Independent full Cartesian enumeration of projected-label domains, NOT the
# candidate's incremental join algorithm or its original eight-state filter.
local=[];domains=defaultdict(set)
for a,r,d in fs:
    keys=[k for k in a if k[0]=='L'];pos=[a.index(k) for k in keys];support={tuple(row[p] for p in pos) for row in r};local.append((keys,support))
    for row in support:
        for k,v in zip(keys,row):domains[k].add(v)
size=prod(len(domains[k]) for k in labels);assert size<=100000
found=[]
for row in product(*(sorted(domains[k]) for k in labels)):
    state=dict(zip(labels,row))
    if all(tuple(state[k] for k in keys) in support for keys,support in local):found.append(state)
plans=ast.literal_eval((D/'label-partition-roster.txt').read_text());assert [p[2] for p in plans]==found
assert len(plans)==len({tuple(p[2][k] for k in labels) for p in plans})==6
original=defaultdict(dict)
for l in (D/'checkpoint/independent/states.tsv').read_text().splitlines():
    case,t,x,k,p,q=map(int,l.split());original[case][('L',t,x,k)]=(p,q)
orig={tuple(s[k] for k in labels) for s in original.values()};assert len(orig)==8
assert all(tuple(s[k] for k in labels) in orig for s in found)
for total,index,state,counts in plans:
    got=[sum(all(k[0]!='L' or row[i]==state[k] for i,k in enumerate(a)) for row in r) for a,r,d in fs]
    assert got==counts and total==sum(got)
best=min(plans);assert best[1]==5 and best[0]==138400
selected=load('label-tuple-selected-frontier.pkl');state=best[2]
for (a,r,d),(b,s,e) in zip(fs,selected['factors']):
    assert d==e and b==tuple(k for k in a if k[0]!='L')
    # Inverse-lift each saved row into original coordinates; no dependence on
    # candidate's forward filtering implementation.
    restored={tuple(state[k] if k[0]=='L' else row[b.index(k)] for k in a):z for row,z in s.items()}
    assert len(restored)==len(s)
    want={row:z for row,z in r.items() if all(k[0]!='L' or row[i]==state[k] for i,k in enumerate(a))}
    assert restored==want
assert selected['conditioning']==o['conditioning']+sorted(state.items())
assert selected['label_partition']=={'index':5,'count':6,'values':state}
print('PASS independent Cartesian audit',size,'domain tuples -> six feasible projected-label tuples, unique/exhaustive; all subset of eight original projected states')
print('PASS all six plan row-count vectors; selected5=138400; inverse-lift saved factors exactly recovers selected source rows/coefficients/denominators; conditioning metadata exact')

parent=Path('/private/tmp/l1-dense-resume.bbZW6V')
with (parent/'join-cap-dense-binary-zero-child-1.pkl').open('rb') as f:original=pickle.load(f)
assert original==o
assert (D/'checkpoint/independent/states.tsv').read_bytes()==(parent/'checkpoint/independent/states.tsv').read_bytes()
assert o['conditioning']==[(('R',1,3,0,2,1),0),(('R',0,6,1,1,1),1)]
print('PASS exact root identity equals original child(0,1) checkpoint; original independent state bindings identical')
for name in ('label-5a-reduced-frontier.pkl','join-cap-dense-label-5a-reduced.pkl','label-5b-reduced-frontier.pkl'):
    child=load(name);assert child['conditioning']==selected['conditioning'] and child['label_partition']==selected['label_partition']
    assert prod(d for a,r,d in child['factors'])==prod(d for a,r,d in fs)
    print(name,'factors',len(child['factors']),'rows',sum(len(r) for a,r,d in child['factors']),'used_before',child['used_before'],'metadata/denominator PASS')
for name in ('partition-label-tuples.py','prepare-label-tuple.py','reduce-label-frontier.py','contract-reduced-label.py'):
    assert (D/name).read_bytes()==(parent/name).read_bytes()
print('PASS all four copied scientific adapters byte-identical to accepted source')
