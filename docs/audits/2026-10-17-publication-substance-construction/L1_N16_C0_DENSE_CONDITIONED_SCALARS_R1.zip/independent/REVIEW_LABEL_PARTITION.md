# Scoped remaining-label partition review

2026-11-19; /root/dense_binary_review. R5 continuity checked first fresh=true, changed=[]. R6 follow-up also checked fresh before independent scalar replay. Scratch-only ownership; no repo/Lean changes. Earlier reports preserved.

## Accepted partition

partition-label-tuples.py computes the natural join of each factor's complete L-label projection. Incrementally extending compatible partial maps and deduplicating sorted item tuples preserves exactly all label assignments admitted by every factor projection. Every global nonzero network assignment must have one such tuple. Different complete tuples are mutually exclusive. Projection consistency is necessary but need not guarantee a nonzero physical contraction; candidate tuples whose private wires conflict or amplitudes cancel simply contribute zero. This limitation cannot omit a valid nonzero assignment.

Independent exhaustive Cartesian audit uses all observed per-label domains, not the author's incremental join or the original-eight-state filter. All256 candidate combinations yield exactly the same six unique tuples. Separately decoding checkpoint/independent/states.tsv gives eight distinct original projected tuples, and all six are members. This establishes the stated subset relation for remaining labels, not a new full original-source/Haar audit. Eliminated singleton labels retain their earlier fixed values by lineage. No quotient step merged distinct L values.

The entire six-entry row-count roster was recomputed. Selected tuple5 has138,400 rows; its row counts are[1984,1232,192,11136,18688,7488,43776,3792,50112]. Independently inverse-lifting each saved selected row by restoring label values exactly reproduces the selected original factor rows, including every coefficient and denominator. Conditioning is injective within the tuple, and full metadata records both preceding representative-index cuts plus all selected label values and tuple index/count. No factorial, chirality, orbit, label multiplicity, or dimension factor is added when these six exact complex contributions are eventually summed.

## Tests and continuation evidence

python3 /private/tmp/l1-dense-binary-review-20261119/label-controls.py > /private/tmp/l1-dense-binary-review-20261119/label-controls.out

python3 /private/tmp/l1-dense-binary-review-20261119/label-literal.py > /private/tmp/l1-dense-binary-review-20261119/label-literal.out

Sixty tiny literal rational Gaussian networks verify the exact implemented label-support join and recombination against full enumeration, including sparse incompatible projections and cancellations. Actual partition and saved selected factors were audited without contracting them.

contract-selected-label-tuple.py retains the accepted Gaussian arithmetic, denominator/external normalization and complex reporting. Both refusal paths preserve conditioning and label_partition. The source loads already conditioned factors and performs no second restriction or extra weight. Terminal author log records four completed joins,2,376,192 products, and a five-factor refusal frontier. Envelope metadata, denominator product and partition identity agree with selected input.

reduce-five.py uses previously accepted globally singleton elimination, then previously accepted exact quotient across the degree-two network. Thirty globally matching singleton indices are removed injectively; remaining degree checks are explicit. Terminal source log reports675,904->18,952->16,104 rows over two quotient sweeps. Actual reduced output has five factors,16,104 rows, the same denominator product and complete conditioning/partition metadata, and no remaining L axes. The sweeps themselves were reviewed by source reasoning and prior literal quotient controls, not reproduced as a second large transformation run.

This accepts completeness/disjointness of the six-label-tuple partition and selected-factor construction. The subsequently obtained scalar for tuple5 is addressed separately by independent bounded replay. Other five tuple contributions, other internal-cut siblings, first binary1 contribution, full branch/profile/coefficient/c0 remain open.
