from pathlib import Path
import ast,pickle,tempfile,os
D=Path('/private/tmp/l1-dense-resume.bbZW6V');tree=ast.parse((D/'contract-second-cut-r2.py').read_text())
loop=next(n for n in tree.body if isinstance(n,ast.While));guard=next(n for n in loop.body if isinstance(n,ast.If) and ast.unparse(n.test)=='not costs')
factors=[((('R',9),),{(0,):(3,4)},7),((),{():(-2,1)},11)]
conditioning=[(('R',1,3,0,2,1),0),(('R',0,6,1,1,1),0)]
with tempfile.TemporaryDirectory(prefix='save-control-',dir='/private/tmp/l1-dense-binary-review-20261119') as td:
    os.chdir(td);scope=dict(Path=Path,pickle=pickle,factors=factors,work=349056,wire=conditioning[-1][0],value=0,obj={'conditioning':conditioning},index='tiny',costs=[])
    try:exec(compile(ast.Module(body=[guard],type_ignores=[]),'recovery-block','exec'),scope)
    except SystemExit as e:assert e.code==2
    else:assert False
    assert not Path('join-cap-tiny.tmp').exists()
    with Path('join-cap-tiny.pkl').open('rb') as f:saved=pickle.load(f)
    assert saved['factors']==factors and saved['conditioning']==conditioning and saved['used_before']==349056
    assert saved['physical_cut']==conditioning[-1]
print('PASS exact frozen refusal-block control: preserves Gaussian coefficients, denominators, work, full conditioning; terminal exit2 and completed rename')
