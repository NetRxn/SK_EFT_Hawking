# Independently verified tuples2 and3

2026-11-19; reviewer /root/dense_binary_review. R8 continuity checked first: fresh=true, changed=[]. Updated owning notebook read. Earlier accepted tuple4/5 reports preserved. Scratch-only work, no repository/Lean changes. Inputs/code fingerprinted in tuples23-inputs.sha256.

## Exact accepted partial values

Tuple2:761799400259723226207/2658455991569831745807614120560689152, imaginary0.

Tuple3:341130692358955201725/166153499473114484112975882535043072, imaginary0.

Each is one specific remaining-label tuple in representative-index child(0,0). No other child or branch value is inferred.

## Selection, adapters and reduction lineage

The generic scientific adapters are the same frozen source reviewed in R7. Their input/tag/index arguments change dataset identity and output names, not Gaussian arithmetic, exact quotient, singleton criterion, product/row bounds, denominator handling or external normalization. Identity is verified using actual roster values and saved metadata rather than filenames alone.

The new tuples23-lineage.py independently inverse-lifts selected saved rows into the nine-factor parent's coordinates. For both indices all selected rows, coefficients, denominators and per-factor counts match exactly; both complete conditioning lists and label_partition dictionaries equal the frozen roster entry. Tuple2 selected170,864 rows; tuple3 selected166,928 rows.

Actual tuple2 lineage: nine factors135,552 rows after first singleton/quotient reduction; six-factor row-cap303,904 rows with4,108,800 completed products; second reduction leaves six factors14,408 rows. First reduction strips27 matching singleton indices; second strips0. Actual tuple3 lineage: nine factors49,072 rows after first reduction; four-factor join-cap317,536 rows with741,568 completed products; second reduction leaves four factors4,880 rows. Its first/second singleton counts are27/5. Terminal source logs and saved envelopes agree with these counts. Every inspected stage retains identical label_partition, full conditioning, no remaining L axes, and factor-denominator product40512224221827380280140849737629696.

These checks establish actual selection and lineage invariants; source-level algebra and prior independent literal controls support intervening exact reductions. This review does not repeat every earlier root join or reconstruct all source tensors.

## Independent direct arithmetic

Commands actually executed:

python3 /private/tmp/l1-dense-binary-review-20261119/replay-tuple2.py > /private/tmp/l1-dense-binary-review-20261119/replay-tuple2.out

python3 /private/tmp/l1-dense-binary-review-20261119/replay-tuple3.py > /private/tmp/l1-dense-binary-review-20261119/replay-tuple3.out

python3 /private/tmp/l1-dense-binary-review-20261119/tuples23-lineage.py > /private/tmp/l1-dense-binary-review-20261119/tuples23-lineage.out

Both replays use the reviewer's own direct sparse Gaussian-integer summation, importing no author quotient/contraction routine and doing no quotient/support-pruning shortcuts. Initial incidence is degree two with no L axes. Actual product counts are checked against independent forecasts, and final denominator against the input product.

Tuple2: five joins51,840;102,144;404,352;4,717,440;134,784 products, total5,410,560. Peak output134,784 rows. Runtime4.8982s. Raw numerator63205761260289087030676497369132426815918067986859301011456, imaginary0.

Tuple3: three joins6,144;55,968;2,376 products, total64,488. Peak output6,144 rows. Runtime0.0705s. Raw numerator452852550788487884222827081402020081343313112302564986060800, imaginary0.

All assigned limits respected:8M products/join,20M total,1M output rows,30s wall. Divide each raw scalar by factor-denominator-product*16*4^64, the already verified external+normalization for this declared profile. Both exact fractions match terminal author outputs independently, without extra multiplicity or weight.

## Partial aggregation only

Previously accepted tuple4/5 plus independently accepted tuple2/3 sum to:

35289400209267809841255/2658455991569831745807614120560689152, imaginary0.

This is explicitly the four-tuple partial2+3+4+5 only. Tuples0 and1 remain owed at this review checkpoint, along with other representative-cut siblings, full branch/profile/coefficient/c0, physical B3 and publication obligations. Author calculations of other tuples are not accepted by this review without their separate evidence.
