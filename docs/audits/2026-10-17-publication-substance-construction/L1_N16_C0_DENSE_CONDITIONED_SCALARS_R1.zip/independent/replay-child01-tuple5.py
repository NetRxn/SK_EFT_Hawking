# Independent sparse Gaussian integer contraction. No author function imported.
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
from math import prod
from fractions import Fraction
import pickle,time
started=time.monotonic();D=Path('/private/tmp/l1-dense-child01.zdXzYQ')
with (D/'label-5b-reduced-frontier.pkl').open('rb') as f:checkpoint=pickle.load(f)
fs=checkpoint['factors'];denominator=prod(d for a,r,d in fs)
assert len(fs)==4 and not any(k[0]=='L' for a,r,d in fs for k in a)
assert all(v==2 for v in Counter(k for a,r,d in fs for k in a).values())
spent=0
while len(fs)>1:
    forecasts=[]
    for i,j in combinations(range(len(fs)),2):
        a,r,_=fs[i];b,s,_=fs[j];shared=set(a)&set(b);order=sorted(shared)
        ix=[a.index(k) for k in order];jx=[b.index(k) for k in order]
        counts=Counter(tuple(row[p] for p in jx) for row in s)
        n=sum(counts[tuple(row[p] for p in ix)] for row in r)
        forecasts.append((n,i,j,ix,jx))
    n,i,j,ix,jx=min(forecasts)
    assert n<=8000000 and spent+n<=20000000
    assert time.monotonic()-started<30
    a,r,d=fs[i];b,s,e=fs[j];li=[p for p in range(len(a)) if p not in ix];ri=[p for p in range(len(b)) if p not in jx]
    axes=tuple(a[p] for p in li)+tuple(b[p] for p in ri)
    buckets=defaultdict(list)
    for row,z in s.items():buckets[tuple(row[p] for p in jx)].append((tuple(row[p] for p in ri),z))
    out={};seen=0
    for row,(x,y) in r.items():
        prefix=tuple(row[p] for p in li)
        for suffix,(u,v) in buckets[tuple(row[p] for p in ix)]:
            seen+=1;key=prefix+suffix;old=out.get(key,(0,0));z=old[0]+x*u-y*v,old[1]+x*v+y*u
            if any(z):out[key]=z
            else:out.pop(key,None)
            assert len(out)<=1000000
            if seen%32768==0:assert time.monotonic()-started<30
    assert seen==n;spent+=n
    print('independent join',i,j,'products',n,'output rows',len(out),'remaining',len(fs)-1,flush=True)
    fs=[f for p,f in enumerate(fs) if p not in (i,j)]+[(axes,out,d*e)]
a,r,d=fs[0];assert not a and d==denominator
re,im=r.get((),(0,0));actual=Fraction(re,d*16*4**64);imag=Fraction(im,d*16*4**64)
expected=Fraction(-10493250771659057325,1298074214633706907132624082305024)
assert actual==expected and imag==0
print('PASS raw scalar numerator',re,'imaginary',im,'factor denominator',d)
print('exact normalized real',actual,'imaginary',imag,'independent matched products',spent,'wall seconds',round(time.monotonic()-started,4))
print('conditioning',checkpoint['conditioning'],'label partition',checkpoint['label_partition'])
