from pathlib import Path
from collections import defaultdict,Counter
from itertools import combinations
from math import prod
import pickle,ast
D=Path('/private/tmp/l1-dense-resume.bbZW6V')
def load(n):
    with (D/n).open('rb') as f:return pickle.load(f)
parent=load('row-cap-physical-slice-dense-binary-zero-fixed.pkl');w=('R',0,6,1,1,1)
inc=[]
for i,(a,r,d) in enumerate(parent['factors']):
    if w in a:inc.append((i,Counter(row[a.index(w)] for row in r)))
assert len(inc)==2 and all(set(v)=={0,1} for i,v in inc)
print('second cut exhaustive binary incidences',inc)
child=load('join-cap-dense-binary-zero-child-0.pkl');assert child['conditioning']==[(('R',1,3,0,2,1),0),(w,0)]
assert len(child['factors'])==9 and child['used_before']==349056
assert all(w not in a for a,r,d in child['factors'])
assert prod(d for a,r,d in parent['factors'])==prod(d for a,r,d in child['factors'])
fs=child['factors'];deg=Counter(k for a,r,d in fs for k in a)
records=[]
for i,j in combinations(range(len(fs)),2):
    a,r,_=fs[i];b,s,_=fs[j];shared=tuple(k for k in a if k in b)
    # Independently count compatible row pairs, using key projections and counts.
    positions=[a.index(k) for k in shared];other=[b.index(k) for k in shared]
    counts=defaultdict(int)
    for row in r:counts[tuple(row[p] for p in positions)]+=1
    matched=sum(counts[tuple(row[p] for p in other)] for row in s)
    width=sum(deg[k]>(2 if k in shared else 1) for k in set(a)|set(b))
    records.append((matched,width,i,j,sum(k[0]!='L' for k in shared),len(shared)))
recorded=[ast.literal_eval(l) for l in (D/'diagnose-nine-joins.out').read_text().splitlines() if l.startswith('(')]
assert sorted(records)==recorded
print('all36 matched-product measurements verified without joins; minimum',min(records),'total rows',sum(len(r) for a,r,d in fs))
q=load('nine-minimum-quotient-frontier.pkl');assert q==child
print('three-pass quotient terminal output equality: entire checkpoint unchanged; no cost reduction')
# Compile numerical drivers without executing their contraction bodies.
for name in ('contract-second-cut-r2.py','diagnose-nine-joins.py','quotient-nine-minimum.py'):compile((D/name).read_text(),name,'exec')
print('driver syntax verified')
