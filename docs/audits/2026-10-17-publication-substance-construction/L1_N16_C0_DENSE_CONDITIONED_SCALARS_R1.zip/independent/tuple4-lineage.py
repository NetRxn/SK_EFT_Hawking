from pathlib import Path
from math import prod
import ast,pickle
D=Path('/private/tmp/l1-dense-resume.bbZW6V')
def load(n):
    with (D/n).open('rb') as f:return pickle.load(f)
base=load('nine-minimum-quotient-frontier.pkl');plans=ast.literal_eval((D/'label-partition-roster.txt').read_text());plan=next(p for p in plans if p[1]==4);total,index,chosen,counts=plan
selected=load('label-tuple-4-frontier.pkl')
for i,((a,r,d),(b,s,e)) in enumerate(zip(base['factors'],selected['factors'])):
    assert b==tuple(k for k in a if k not in chosen) and d==e and len(s)==counts[i]
    restored={tuple(chosen[k] if k in chosen else row[b.index(k)] for k in a):z for row,z in s.items()}
    assert restored=={row:z for row,z in r.items() if all(k not in chosen or row[p]==chosen[k] for p,k in enumerate(a))}
assert sum(counts)==total==142336
assert selected['conditioning']==base['conditioning']+sorted(chosen.items())
assert selected['label_partition']==dict(index=4,count=6,values=chosen)
print('PASS tuple4 adapter exact inverse-lift rows/coefficients/denominators, all row counts, complete conditioning and unique roster entry')
chain=['row-cap-physical-slice-dense-label-roster-4.pkl','label-4-reduced-frontier.pkl','row-cap-physical-slice-dense-label-4-reduced.pkl','label-4b-reduced-frontier.pkl']
for n in chain:
    obj=load(n);assert obj['conditioning']==selected['conditioning'] and obj['label_partition']==selected['label_partition']
    assert prod(d for a,r,d in obj['factors'])==prod(d for a,r,d in selected['factors'])
    assert not any(k[0]=='L' for a,r,d in obj['factors'] for k in a)
    print(n,'factors',len(obj['factors']),'rows',sum(len(r) for a,r,d in obj['factors']),'used_before',obj['used_before'],'metadata/denominator PASS')
