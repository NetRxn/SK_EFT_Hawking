from fractions import Fraction as F
from itertools import product
from random import Random
from collections import defaultdict
rng=Random(27)
source=open('/private/tmp/l1-dense-resume.bbZW6V/partition-label-tuples.py').read()
fragment=source[source.index('partials=[{}]'):source.index('labels=tuple(sorted')]
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def total(fs,cond={}):
    axes=list(dict.fromkeys(k for a,r,d in fs for k in a));z=(F(0),F(0))
    for values in product(range(2),repeat=len(axes)):
        state=dict(zip(axes,values))
        if any(state[k]!=v for k,v in cond.items()):continue
        u=(F(1),F(0))
        for a,r,d in fs:u=mul(u,tuple(F(v,d) for v in r.get(tuple(state[k] for k in a),(0,0))))
        z=z[0]+u[0],z[1]+u[1]
    return z
L=('L',0);M=('L',1);W=('R',0)
# Silence only the candidate's progress-print callback, no numerical behavior.
for i in range(60):
    fs=[]
    for axes,d in (((L,W),3),((M,W),5),((L,M),7)):
        rows={k:(rng.randint(-3,3),rng.randint(-3,3)) for k in product(range(2),repeat=2) if rng.random()>.2};fs.append((axes,rows,d))
    scope={'factors':fs,'print':lambda *a,**k:None};exec(fragment,scope);parts=scope['partials']
    labels=sorted({k for a,r,d in fs for k in a if k[0]=='L'})
    assert len(parts)==len({tuple(s[k] for k in labels) for s in parts})
    z=(F(0),F(0))
    for s in parts:
        u=total(fs,s);z=z[0]+u[0],z[1]+u[1]
    assert z==total(fs)
print('PASS 60 literal rational Gaussian label-partition/recombination controls including sparse incompatible projections and cancellations')
