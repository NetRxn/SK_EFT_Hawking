# Child(0,1) tuple5 independently verified

2026-11-19; /root/dense_binary_review. R9 continuity checked first: fresh=true, changed=[]. Referenced notebook read. Scratch-only work; previous reports preserved, no repository/Lean changes. Input fingerprints: child01-tuple5-inputs.sha256.

## Accepted exact partial scalar

-10493250771659057325/1298074214633706907132624082305024, imaginary0.

Acceptance is tuple5 in representative-index child(0,1) only. Its equality to independently accepted child(0,0) tuple5 is an observed arithmetic equality, not a proved symmetry or permission to reuse other tuple results.

## Partition, source binding and lineage

The copied partition, preparation, reduction and generic contraction adapters are byte-identical to the previously accepted source. The copied nine-minimum-quotient-frontier.pkl is exactly equal as a loaded envelope to the original join-cap-dense-binary-zero-child-1.pkl. Thus its conditioning really is first representative cut0, second representative cut1; no inference from directory names is needed.

Independent exhaustive Cartesian enumeration of all256 remaining-label-domain tuples finds exactly the same six unique tuples as the candidate's incremental support join. All six lie within the eight distinct independently enumerated original projected states; the original states.tsv bytes equal the previous archived source-binding input. This is complete projection support, allowing later private-wire incompatibility or exact cancellation to produce zero contributions. It does not claim each candidate must be nonzero.

Every six-entry roster count vector was recomputed. Selected tuple5 retains138,400 rows. Inverse-lifting actual saved selected rows into parent coordinates exactly recovers all selected parent rows, Gaussian coefficients and denominators. Complete conditioning and label_partition match the roster and original sibling1 source.

Actual saved lineage: initial tuple5 -> nine-factor reduced48,312 rows -> four-factor no-join-cap392,288 rows with846,496 completed products -> four-factor reduced6,792 rows. Every envelope preserves exact conditioning/partition identity and factor-denominator product40512224221827380280140849737629696. Reduction logs use accepted singleton and exact quotient operations: first removes28 fixed indices and reaches48,312 rows; second removes5 fixed indices and reaches6,792 rows. Underlying source transformations are covered by previous mathematical/literal review; intermediate author joins were not rerun here.

## Independent replay

Commands:

python3 /private/tmp/l1-dense-binary-review-20261119/child01-controls.py > /private/tmp/l1-dense-binary-review-20261119/child01-controls.out

python3 /private/tmp/l1-dense-binary-review-20261119/replay-child01-tuple5.py > /private/tmp/l1-dense-binary-review-20261119/replay-child01-tuple5.out

The reviewer's direct Gaussian-integer join implementation imports no author quotient/contraction function and applies no quotient or peer-support shortcut. It checks initial degree-two incidence, forecasts against actual matched counts, and final denominator product. Three independent joins used6,144;68,184;4,104 products, total78,432; peak output6,144 rows; runtime0.1121s. All assigned8M/join,20M total,1M output-row and30s limits were respected.

Raw numerator-1783019300254394241636886075857867990382117316088606543052800, imaginary0. Divide by the factor-denominator product times16*4^64, the previously independently verified external normalization, to recover the exact author fraction above. No extra label/orbit/chirality multiplicity is inserted.

Other five child(0,1) tuple values and their sum, remaining cut siblings, branch128, profile/coefficient/c0, physical B3 and publication obligations remain open. No simple reversal map, equality of other tuples or branch-wide symmetry is accepted.
