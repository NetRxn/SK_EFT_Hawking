# L1 dense conditioned scalar checkpoint

This archive records five independently replayed exact conditioned contributions. Four belong to descendant (0,0), and one belongs to descendant (0,1). No complete branch 128 or profile coefficient follows.

## Source and exact scope

Scientific source is 51e7c745eccad5e99676cdc8e4b523ad73e617b1. The parent publication checkpoint is 9a9b6647d62f33154551db6400ebb89dca9e6699 on codex/publication-l1-checkpoint-20261103. Its L1_N16_C0_DENSE_BINARY_REDUCTION_R1.zip contains both ten-factor binary restart states.

The dense profile is (503841882182,1461451755920). Its 30,976 representation assignments were partitioned into 3,872 groups of eight. This computation still concerns group 128. In that group, first condition quotient representative index ('R',1,3,0,2,1) to 0, then ('R',0,6,1,1,1) to 0 or 1. The resulting internal descendants are called (0,0) and (0,1). The first internal value 1 remains separately open.

A natural join of every remaining representation-label projection gives six feasible tuples in each descendant. Independent enumeration checked all 256 possible remaining-label combinations and reproduced the exact six-tuple roster for each. Surviving tuples belong to the independently enumerated eight original projected assignments. The two omitted assignments have zero support in the conditioned descendant. The index ordering is the sorted full label tuple recorded in each roster.

## Independently accepted values

accepted-conditioned-values.tsv gives the exact normalized real and imaginary parts with individual review pointers. Descendant (0,0) tuples 2, 3, 4, 5 are accepted. Their partial sum is

35289400209267809841255/2658455991569831745807614120560689152

with imaginary part 0. Descendant (0,1) tuple 5 is separately accepted and equals descendant (0,0) tuple 5. A simple coordinate-reflection test failed to establish any wider equivalence, so this equality is used only for these two replayed values.

Each value includes its own factor-denominator product and the verified external normalization +1/(16*4^64). Do not add a further orbit weight or chirality multiplicity at this conditioned stage. Original-source bindings and external normalization retain the preceding pinned source audits.

Independent replays used separately implemented exact integer Gaussian arithmetic and different join schedules. They imported no author quotient/contraction code. Reports give product counts, output-row peaks and exact fractions. The accepted scope is each declared conditioned contribution plus the reviewed partition/reduction equivalences.

## Verification and replay

After extraction, run shasum -a256 -c manifest.sha256. Decompress scalar-inputs/*.pkl.gz, then run shasum -a256 -c scalar-inputs-uncompressed.sha256. These locally generated pickles contain exact reduced factor tables and complete conditioning metadata.

The independent scripts and outputs under independent/ document original paths. Supply the extracted scalar-inputs file for the corresponding input when reproducing each small direct replay. The scalar tables are frozen inputs, and their complete pre-reduction lineage is recorded by the author scripts and terminal logs.

To regenerate earlier descendants, extract the parent archive, decompress branch128-binary-0-frontier.pkl.gz and copy it to row-cap-physical-slice-dense-binary-zero-fixed.pkl. Copy author/checkpoint/quotient.py and author/checkpoint/independent/states.tsv into the matching checkpoint paths in the new scratch directory. Run the archived author/contract-second-cut-r2.py separately with argument 0 and argument 1. It saves the respective exact nine-factor frontier on product-limit refusal.

For descendant (0,0), author/quotient-nine-minimum.py checked the minimum candidate and preserved its unchanged exact network as nine-minimum-quotient-frontier.pkl. For descendant (0,1), that filename directly references the exact saved nine-factor state. Each directory's partition-label-tuples.py and roster describe the exhaustive decomposition. prepare-label-tuple.py selects a roster item. reduce-label-frontier.py applies the independently reviewed singleton and quotient reductions. contract-reduced-label.py produces a complete rational complex value or saves an exact prejoin frontier at the configured limits. Use fresh output tags for each reduction cycle.

The no-admitted-join path was corrected to preserve completed prior joins before refusing. Both refusal paths retain the complete conditioning list. Individual contributions retain both complex components through exact recombination.

## Work still required

For descendant (0,0), finish tuples 0 and 1 and independently replay them before recording the complete six-tuple sum. The accepted numerical author assignment l1-c0-dense-tuples01-20261119-r1 belongs to /root/dense_tuples01. Lead /root owns integration and the primary notebook. Reviewer /root/dense_binary_review owns independent acceptance. The author acknowledged a fresh continuity check and began tuple 0 in isolated scratch. Its owned work is limited to tuples 0 and 1, unchanged frozen numerical drivers and limits, four reduction/contraction cycles per tuple, and 100 million matched products total. Check the current actual process handles and saved results before resuming or redispatching.

For descendant (0,1), tuple 5 is accepted; tuples 0 through 4 remain owed. Then complete the other first-index contribution and recombine all exact complex components. Only after that is group 128 complete. The rest of this profile, the full original signed c0 construction, original denominator and physical B3 remain owed.

The accepted portfolio residual stays 9,547 orbits and 821,655 labels. These scalar contributions do not close a complete residual orbit. Publication requires the original full scientific repairs, propagation, same-revision canonical gates and independent review, qualified integration into main and final human approval. The existing disposition map retains the full 21-bundle objective and priority queue.
