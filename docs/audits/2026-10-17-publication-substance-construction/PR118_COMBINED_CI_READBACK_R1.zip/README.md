# PR118 combined validation readback

Draft PR118 source head 077348cf3b46de45f4cf454a0b58dabc84fc3308.
November 7, 2026. Exit 1 after 446.4 seconds. Canonical invocation was
scripts/validate.py --ci --no-memo in a scratch checkout. The scratch
input contains canonical regenerated compiled_pages fields in four metadata
files and three freshly compiled PDFs, listed in before-status. Before and
after tracked status agree. Lean ran against the same-head PR118 worktree
through the existing LEAN_PROJECT_DIR override, using existing build
artifacts. The Lean worktree finished clean.

74 of 85 checks passed, including axiom_closure_allowlist and paper_latex_compiles.
The check reports 1,621 warnings. It skipped claim_clusters_fresh, counts_fresh,
notebook_exec and tables_fresh on fresh-clone premises.

Ten failing paper checks: figure integrity, abstract length, prose em-dashes,
reader-facing voice, figure adequacy, structural coherence, Lean module coverage,
Stage-13 claim consistency, submission readiness and prose theorem references.
One additional failing check: Lean docstring references. That check reports zero
Mathlib names loaded and requires a separate exact-source baseline comparison
before attribution. The aggregate includes all affected papers and carries no
per-bundle waiver or acceptance. The abstract failure in this run comes from the
PR118 composition. The actual L1 lead delivery branch is PR117.

Raw output and original SHA-256 are included. User home and scratch root are
redacted from the retained log. Status files describe the scratch input and do
not establish a pristine checkout result.
