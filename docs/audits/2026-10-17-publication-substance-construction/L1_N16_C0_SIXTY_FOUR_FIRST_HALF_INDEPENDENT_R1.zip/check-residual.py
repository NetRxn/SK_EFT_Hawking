from fractions import Fraction
from pathlib import Path
import sys

def rows(path, columns):
    result = {}
    for line in Path(path).read_text().splitlines():
        data = line.split()
        assert len(data) == columns, (path, line)
        key = tuple(map(int, data[:2]))
        assert key not in result, (path, key)
        weight = int(data[2])
        assert weight > 0
        result[key] = weight if columns == 3 else (weight, Fraction(data[3]))
    return result

remaining = rows('published-base.tsv', 3)
assert len(remaining) == 9611 and sum(remaining.values()) == 827799
for table in sys.argv[1:]:
    reviewed = rows(table, 4)
    for key, (weight, value) in reviewed.items():
        assert remaining.pop(key) == weight
    print(table, len(reviewed), sum(w for w, _ in reviewed.values()),
          sum(w * v for w, v in reviewed.values()))
print('remaining', len(remaining), sum(remaining.values()))
Path('block-remaining.tsv').write_text(''.join(
    f'{left}\t{right}\t{weight}\n'
    for (left, right), weight in remaining.items()
))
