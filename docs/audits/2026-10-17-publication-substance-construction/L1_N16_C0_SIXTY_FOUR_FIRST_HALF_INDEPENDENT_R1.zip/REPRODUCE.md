# Independent acceptance of the first 32 L1 profiles

Verify manifest.sha256, then run `python3 check-residual.py independent/reviewed-exact.tsv`.
The independent review covers support, signed contractions and local factors. Full c0 and physical B3 remain open.
