# Independent review of the first 32 profiles of the L1 batch

**ACCEPT all 32 original N16 pure-EHC c0 coefficients.** Every independently computed representative agrees exactly with the frozen terminal author log. These 126 signed contractions cover 182 original support assignments. The signed results contain 56 positive, 24 negative and 46 zero values.

The 32 source profiles each occur at weight 96. The combined weighted contribution is
`18107497019336887864377332984462353820181/316912650057057350374175801344`.
Removing their 3,072 labels from the accepted predecessor leaves **9,579 orbits and 824,727 labels**. The source representative IDs, partners, multiplicities and signed values are in `signed-pairs.tsv`. The exact coefficient receipt and order-preserving residual are `reviewed-exact.tsv` and `block-remaining.tsv`.

## Frozen intake and membership

Canonical original source is `51e7c745eccad5e99676cdc8e4b523ad73e617b1`. The author manifest is identical to the one in the published first-half archive, and the accepted residual is identical to the one in the published independent higher-degree archive, both at checkpoint `94368f8a6`. The frozen author base equals the accepted predecessor byte for byte. All author, predecessor, and factor-file manifest entries verify. The normalized moment tables, edge plan, projected states and representative anchor plan consumed by the reviewer match the raw and frozen intake copies. Only the 32 profile directories named in the frozen intake were used. The continuity packet was fresh at final readback.

## Original support and source signs

I reconstructed the literal occupation-based root degrees and projected domains. Exhaustive finite constraint propagation tests both temporal SU(2) singlets, the combined spatial center parity, and the spatial minimum-load and zero-load equality tests. Fourteen profiles each have four assignments and eighteen each have seven. All 8,736 original anchor rows and 6,048 representative anchor rows agree, with anchor-plan IDs used even for the empty sparse all-scalar assignment. The maximum projected product has 16,777,216 candidates and the maximum search has 25 branch nodes. All admitted degree-three occupations have fundamental chirality (1,0) or (0,1), so the common root table covers all admitted cases.

The original gamma3 transformation exchanges the labeled Haar blocks and preserves filled site tops. Its EHC sign is even at total insertion degree 32. Exact pairing of the source tuples gives 56 exchanged pairs at multiplicity two, 26 scalar fixed assignments at multiplicity one and 44 nontrivial fixed assignments at multiplicity one. I also replayed each of the 26 scalar fixed channels as two independently contracted single-layer factors and verified the exact product.

I independently recovered all 512 stripped coframe rows and 768 original four-order EHC folding phases under the canonical normalization. The 32 original EHC insertions yield 64 coframe quarters. Both layers in every profile have even world-epsilon and cross-site wedge signs, checked with 64 literal layouts per layer. Exact original multiplicity factorials are 2,304, 20,736, 65,536 and 186,624 and are reproduced per profile in `normalization.out`.

## Local factors and signed contraction

- The source common root table matches all 4,920 candidates and 1,718 nonzeros. All 32 pinned local root tables equal the checked table byte for byte. This is the only deduplication used for factor checks.
- Whole temporal Haar moment tables cover 8,768 candidates and 1,244 nonzeros. Whole spatial moment tables cover 721,410 candidates and 44,076 nonzeros. These totals count each profile's table entries.
- Both signed spatial endpoint alias maps invert exactly, preserving native endpoint matrix indices and reconstructing all 2,930,344 raw rows across 685 profile-specific patterns. Direct source integration checks 1,136 signed targets covering every pattern, including imaginary targets where present. The maximum unfiltered candidate count is 1,048,576. The exterior filter admits at most 31,392 prefixes before direct signed arithmetic. Direct source integration has target-row scope.
- The independent split joins rebuild all 4,032 site factors, comprising 3,376,300 mask and 1,420,580 root rows. This uses exact exterior inversion signs, canonical alias gains, raw words and root matrices. Maximum site mask trial and root product counts are 134,656 and 129,600.
- All 126 independent 88-factor networks use explicit original half-edge orientation and two occurrences of each nontrivial wire. Exact tuple-key Gaussian contraction preserves coefficients under primitive proportional-slice reduction and counts admitted products before joins. Observed maxima are 263,100 initial rows, 93,184 products in a join, 368,319 matched products per network, and 10,889,337 charged scans. All imaginary coefficients vanish and no run exceeded the resource guards.

Run `bash reproduce.sh` with the frozen input symlinks in place. The author’s in-progress second-half directories were outside this review. No repository, manuscript, continuity notebook or Lean slot was changed.
