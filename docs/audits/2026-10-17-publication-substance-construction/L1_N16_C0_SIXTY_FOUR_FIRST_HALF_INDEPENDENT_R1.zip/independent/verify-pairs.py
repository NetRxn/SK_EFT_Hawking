from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path
import sys

root=Path('.')
weights={}
vals=defaultdict(dict)
for pattern in ('replay-*.out','memo-*.out','repair-*.out'):
    for path in root.glob(pattern):
        _,a,b,_=path.stem.split('-')
        key=int(a),int(b)
        for line in path.open():
            if line.startswith('EXACT '):
                _,i,z=line.split()
                i=int(i)
                num=F(z)
                assert vals[key].get(i,num)==num
                vals[key][i]=num
plans=defaultdict(dict)
for line in (root/'reviewed-pairs.tsv').open():
    *ints,kind=line.split()
    a,b,w,i,j,k,n=map(int,ints)
    weights[a,b]=w
    plans[a,b][i]=j,k,n,kind
pred={}
with (root/'RESIDUAL/block-remaining.tsv').open() as f:
    for line in f:
        a,b,w=map(int,line.split())
        assert (a,b) not in pred
        pred[a,b]=w
author_base={(a,b):w for a,b,w in (tuple(map(int,l.split())) for l in (root/"AUTHOR/published-base.tsv").open())}
assert len(pred)==9611 and sum(pred.values())==827799
assert author_base==pred
assert len(plans)==32 and sorted(sum(row[2] for row in p.values()) for p in plans.values())==[4]*14+[7]*18
assert sum(map(len,plans.values()))==126
expected={(int(a),int(b)):(int(w),F(z),F(wz)) for a,b,w,z,wz in (l.split() for l in (root/"AUTHOR/author-exact.tsv").read_text().splitlines()[1:])}
assert set(expected)==set(plans)
total=F(0)
with (root/'signed-pairs.tsv').open('w') as pairs,(root/'reviewed-exact.tsv').open('w') as exact:
    for (a,b),P in sorted(plans.items()):
        key=a,b
        w=weights[key]
        assert pred.pop(key)==w==96
        actual=vals[key]
        auth=root/'AUTHOR'/f'{a}-{b}'
        assert not(set(actual)-set(P))
        subtotal=F(0)
        count=Counter()
        for i,(j,k,n,kind) in sorted(P.items()):
            if i not in actual:continue
            rows=[l.split() for l in (auth/f'case-{i:03}.out').open() if l.startswith('EXACT ')]
            assert len(rows)==1
            row,=rows
            if row[1]=='ZERO':want=F(0)
            else:
                assert row[1]=='channel' and int(row[2])==i and F(row[4])==0
                want=F(row[3])
            assert actual[i]==want,(a,b,i,actual[i],want)
            v=actual[i]
            count[(v>0)-(v<0)]+=1
            subtotal+=n*v
            print(a,b,i,j,k,n,kind,v,sep='\t',file=pairs)
        print(a,b,'signed matches',len(actual),'of',len(P),'counts',dict(count), 'missing',sorted(set(P)-set(actual)))
        if len(actual)!=len(P):
            assert "--final" not in sys.argv,(key,"incomplete")
            continue
        assert expected[key]==(w,subtotal,w*subtotal),(key,subtotal,expected[key])
        print(a,b,w,subtotal,sep='\t',file=exact)
        print('coefficient',subtotal,'weighted',w*subtotal)
        total+=w*subtotal
print('completed weighted',total)
assert len(pred)==9579 and sum(pred.values())==824727
if "--final" in sys.argv:
    with (root/'block-remaining.tsv').open('w') as f:
        for (a,b),w in pred.items():
            print(a,b,w,sep='\t',file=f)
