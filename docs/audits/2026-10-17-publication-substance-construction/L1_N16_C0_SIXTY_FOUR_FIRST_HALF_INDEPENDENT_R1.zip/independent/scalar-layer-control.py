from contextlib import redirect_stdout
from fractions import Fraction
from io import StringIO
from pathlib import Path
from replay import roots,pilot,profile

seen=0
for l in Path('reviewed-pairs.tsv').open():
    a,b,w,c,j,k,n,kind=l.split()
    if profile!=f'{a}-{b}' or kind!='scalar-fixed':
        continue
    c=int(c)
    assert (n,j)==('1',k) and not roots[c]
    with redirect_stdout(StringIO()):
        x,y=pilot(c,0),pilot(c,1)
    v=x*y
    target=next(l.split()[2] for l in Path(f'replay-{profile}-0.out').open() if l.startswith(f'EXACT {c} '))
    assert v==Fraction(target)
    print(profile,c,'independent scalar layers',x,y,'product',v)
    seen+=1
assert seen==1
