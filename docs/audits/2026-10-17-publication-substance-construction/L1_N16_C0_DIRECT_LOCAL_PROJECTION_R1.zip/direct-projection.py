from collections import defaultdict
from itertools import product
from pathlib import Path
from time import monotonic
from os import environ

source=Path('screen.py').read_text()
source=source[:source.index('root=Path(source)')]
original=source.replace("return ('EXACT_SUPPORT',checked,len(states),maxspin,maxpower,tuple(forced))","return states,checked")
direct=source[:source.index('    def solve(state):')].replace('def solve_pilot(a,b):','def direct_projections(a,b,scopes):')
direct+='''
    def consume():
        nonlocal checked
        checked+=1
        if checked>65536:
            raise RuntimeError(('local projection cap',checked))

    def has_completion(state):
        consume()
        if not reduce(state):
            return False
        active=[k for k in state if len(state[k])>1]
        if not active:
            return True
        k=min(active,key=lambda key:(len(state[key]),-len(neighbors[key]),key))
        return any(has_completion(state|{k:(label,)}) for label in state[k])

    def local_rows(state,scope):
        consume()
        if not reduce(state):
            return
        active=[k for k in scope if k in state and len(state[k])>1]
        if not active:
            if has_completion(state):
                yield tuple(state.get(k,((0,0),))[0] for k in scope)
            return
        k=min(active,key=lambda key:(len(state[key]),-len(neighbors[key]),key))
        for label in state[k]:
            yield from local_rows(state|{k:(label,)},scope)

    relations={}
    nodes={}
    for scope in sorted(set(scopes)):
        checked=0
        rows=set(local_rows(domains.copy(),scope))
        relations[scope]=rows
        nodes[scope]=checked
    return relations,nodes
'''
# Both use the same frozen original constraints. The projection search
# stops at the first global completion per local tuple.
import sys
inputs=sys.argv[:]
exec(original)
sys.argv=inputs
exec(direct)
CAP=65536
edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
scopes=defaultdict(set)
for t in range(2):
    for u,v,k in edges:
        scopes['edge'].add(tuple(sorted((side,x,k) for side in range(2) for x in (u,v))))
    for x in range(8):
        scopes['site'].add(tuple(sorted((side,y,k) for side in range(2) for k in range(3) for y in (x,x^(1<<k)))))
        scopes['temporal'].add(tuple(sorted((t,y,k) for k in range(3) for y in (x,x^(1<<k)))))
all_scopes={s for family in scopes.values() for s in family}
for a,b,size in ((155950118473,580896423965,152),(503841882182,1461451755920,30976)):
    t=monotonic()
    projected,visits=direct_projections(a,b,all_scopes)
    elapsed=monotonic()-t
    with Path(f'{a}-{b}-local-labels.tsv').open('w') as out:
        for keys,rows in sorted(projected.items()):
            for row in sorted(rows):
                print(keys,row,sep='\t',file=out)
    old_visits='disabled'
    verification='direct only'
    if environ.get('L1_DIRECT_ONLY')!='1':
        roster,old_visits=solve_pilot(a,b)
        assert len(roster)==size
        for keys,rows in projected.items():
            expected={tuple(st.get(k,(0,0)) for k in keys) for st in roster}
            assert rows==expected,(a,b,keys,len(rows),len(expected))
        verification='verified from full roster' 
    print(a,b,'support',size,verification,'unique scopes',len(projected),
          'distinct local tuples',sum(map(len,projected.values())),
          'projection nodes total/peak',sum(visits.values()),max(visits.values()),
          'enumeration nodes',old_visits,'direct seconds',round(elapsed,2),flush=True)
