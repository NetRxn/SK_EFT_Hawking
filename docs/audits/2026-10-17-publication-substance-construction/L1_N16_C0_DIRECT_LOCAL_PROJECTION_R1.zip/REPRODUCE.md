# Direct generation of L1 local representation rosters

Use the preflight, source and residual folders from the earlier
L1_N16_C0_LOCAL_SUPPORT_JOIN_R1 archive. From this directory, run
`L1_DIRECT_ONLY=1 python3 direct-projection.py preflight source residual`
and check the local tables against labels.sha256. Run again without that
environment flag to verify the local rosters against full global enumeration.

For each distinct factor scope, the direct algorithm branches only on
unsolved local labels. It emits a local tuple exactly when constraint
propagation and a search that stops at the first witness find a global
completion. The accepted 152-assignment control and the 30,976-assignment
dense support control each have 36 distinct scope tables. The dense case
has 740 distinct local tuples. Generation without full enumeration
produces the same local table bytes as the verified run.

These are label rosters. The original signed physical matrices still need
to be built from them and carried through the full dense contraction.
