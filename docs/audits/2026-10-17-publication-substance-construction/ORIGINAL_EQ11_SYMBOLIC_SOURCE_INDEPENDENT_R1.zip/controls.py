import json
from fractions import Fraction as F
from itertools import permutations, product
from math import factorial
from src.core.formulas import original_action_factors, original_plaquette
from src.vestigial.original_coefficients import OriginalRegulator, Polynomial as P, QComplex as Q, Symbol

reg=OriginalRegulator(extents=(2,2,1,1))
site=(0,0,0,0)
x=(1,0,0,0)
y=(0,1,0,0)
variable=tuple(Symbol("q",(site,0,"L",i)) for i in range(4))
I=Q(0,1)
ident=(1,0,0,0)
turn=(0,0,1,0)
phase=(0,0,0,1)
rational=(F(3,5),F(4,5),0,0)
def block(l,r):
    def two(q):
        a,b,c,d=map(P.coerce,q)
        return ((a+d*I,c+b*I),(-c+b*I,a-d*I))
    l,r=two(l),two(r)
    return tuple(tuple(l[i][j] if i<2 and j<2 else r[i-2][j-2] if i>=2 and j>=2 else P() for j in range(4)) for i in range(4))
def links(a):
    return {(s,k):block(a if (s,k)==(site,0) else turn if (s,k)==(x,1) else ident,
                        phase if (s,k)==(y,0) else ident)
            for s,k in product(reg.sites,range(4))}
def mul(a,b):
    return tuple(tuple(sum((a[i][h]*b[h][j] for h in range(4)),P()) for j in range(4)) for i in range(4))
def dag(a):
    return tuple(tuple(a[j][i].conjugate() for j in range(4)) for i in range(4))
def fw(s,k):
    result=list(s)
    result[k]=(result[k]+1)%reg.extents[k]
    return tuple(result)
def plaq(u,k,l,word):
    a,b,c,d=u[site,k],u[fw(site,k),l],dag(u[fw(site,l),k]),dag(u[site,l])
    return mul(mul(mul(a,b),c),d) if word=="printed" else mul(mul(mul(d,c),b),a)
def eps(p):
    return (-1)**sum(a>b for i,a in enumerate(p) for b in p[i+1:])
def add(out,key,val):
    key=tuple(sorted(key))
    out[key]=out.get(key,P())+val
def tidy(d):
    return {k:v for k,v in d.items() if v}
def symbolic_source(u,word,g1,g2):
    out={}
    for p in permutations(range(4)):
        add(out,zip(range(4),p),P.scalar(g1*eps(p)))
    traces={}
    for k,l in permutations(range(4),2):
        uword=plaq(u,k,l,word)
        for a,b in product(range(4),repeat=2):
            m=mul(mul(mul(uword,reg.gamma[a]),reg.gamma[b]),reg.gamma5)
            traces[k,l,a,b]=sum((m[i][i] for i in range(4)),P())
    for k,l,m,n in permutations(range(4)):
        for a,b in product(range(4),repeat=2):
            add(out,((m,a),(n,b)),traces[k,l,a,b]*(g2*F(eps((k,l,m,n)),4)))
    return tidy(out)
def actual_source(u,word,g1,g2):
    r=OriginalRegulator(extents=reg.extents,word=word)
    out={}
    terms=original_action_factors(r,site,u)
    assert len(terms)==408
    for term in terms:
        assert all(s==site for s,_,_ in term.components)
        add(out,((m,a) for _,m,a in term.components),term.coefficient*(g1 if term.t_degree==4 else g2))
    return tidy(out)
def ring_mul(a,b,target):
    out={}
    for ka,va in a.items():
        for kb,vb in b.items():
            key=tuple(sorted(ka+kb))
            pending=list(target)
            for k in key:
                if k not in pending: break
                pending.remove(k)
            else: add(out,key,va*vb)
    return tidy(out)
def powers(poly,target,m):
    rows=[{():P.scalar(1)}]
    for _ in range(m): rows.append(ring_mul(rows[-1],poly,target))
    return rows
def coeff(s,q,cut,target):
    if len(target)>cut:return P()
    return sum((ring_mul(p,r,target).get(target,P())*F(1,factorial(k)*factorial(l))
                for k,p in enumerate(powers(s,target,len(target)))
                for l,r in enumerate(powers(q,target,len(target)))),P())
def direct(s,q,cut,target):
    if len(target)>cut:return P()
    joint=dict(s)
    for k,v in q.items():add(joint,k,v)
    return sum((r.get(target,P())*F(1,factorial(j))
                for j,r in enumerate(powers(joint,target,len(target)))),P())
u=links(tuple(P.variable(v) for v in variable))
g1,g2=Q(F(2,3),F(3,7)),Q(F(-2,5),F(1,4))
sources={word:symbolic_source(u,word,g1,g2) for word in ("printed","closed")}
rows=[]
for a in (phase,rational,ident):
    env=dict(zip(variable,a))
    exact=links(a)
    for word,s in sources.items():
        for k,l in permutations(range(4),2):
            evalp=tuple(tuple(P.scalar(v.evaluate(env)) for v in row) for row in plaq(u,k,l,word))
            assert evalp==original_plaquette(reg,site,k,l,exact,word)
        actual=actual_source(exact,word,g1,g2)
        ev=tidy({k:P.scalar(v.evaluate(env)) for k,v in s.items()})
        assert ev==actual and () not in actual and () not in s
        beta=next(k for k in actual if len(k)==2)
        betas=[(),beta,tuple(sorted(beta*2)),next(k for k in actual if len(k)==4),((0,0),)*16,((0,0),)*18]
        sigma2=F(9,4)
        q={((j,k),)*2:P.scalar(-sigma2/2) for j,k in product(range(4),repeat=2)}
        for t in betas:
            c=coeff(s,q,4*reg.volume,t)
            d=direct(actual,q,4*reg.volume,t)
            assert P.scalar(c.evaluate(env))==d
            if len(t)==16: assert d==P.scalar(F(-9,8)**8/factorial(8))
            if len(t)>16: assert not c and not d and direct(actual,q,18,t)==P.scalar(F(-9,8)**9/factorial(9))
        rows.append({"links":str(a),"word":word,"plaquette_matrices":12,"local_source_keys":len(actual),
                     "compensation_degrees":[len(t) for t in betas]})
uv=links(phase)
assert original_plaquette(reg,site,0,1,uv,"printed")[0][1]==P.scalar(I)
assert original_plaquette(reg,site,0,1,uv,"closed")[0][1]==P.scalar(-I)
print(json.dumps({"cases":rows,"word_order":"printed +i, closed -i"},indent=2))
