from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

def execute(task):
    index, prefix, pair, shard, count = task
    path = Path(f'slice-{index}-shard-{shard}.out')
    with path.open('xb') as log:
        result = subprocess.run(
            [sys.executable,'-u','close-four-shards.py',f'join-cap-dense-label-{prefix}-{index}-reduced.pkl',
             '--pair',*map(str,pair),'--shard',str(shard),str(count)],
            stdout=log,stderr=subprocess.STDOUT,timeout=135)
    print(index,shard,result.returncode,sep='\t',flush=True)

specs = [(2,'peer',(0,2),12),(3,'peer',(0,2),12),(6,'slice',(0,2),12),
         (7,'slice',(1,3),30),(8,'slice',(1,3),30)]
jobs = [(index,prefix,pair,shard,count) for index,prefix,pair,count in specs for shard in range(count)]
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(execute,jobs))
