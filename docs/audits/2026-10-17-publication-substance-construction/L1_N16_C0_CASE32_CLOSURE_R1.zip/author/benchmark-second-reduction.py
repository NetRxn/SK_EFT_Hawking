from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
import time

def run(index):
    prefix='peer' if index in (2,3) else 'slice'
    parent=f'join-cap-dense-label-{prefix}-{index}-reduced.pkl'
    tag=f'fast-{index}'
    started=time.monotonic()
    for script,args,suffix in [
        ('reduce-label-frontier.py',[parent,tag],'reduce'),
        ('contract-reduced-label.py',[tag],'contract'),
    ]:
        with Path(f'{tag}-{suffix}.out').open('xb') as receipt:
            result=subprocess.run([sys.executable,'-u',script,*args],stdout=receipt,
                                  stderr=subprocess.STDOUT,timeout=150)
        if result.returncode and suffix=='reduce':
            raise RuntimeError((index,script,result.returncode))
    status=Path(f'{tag}-contract.out').read_text().splitlines()[-1]
    print(index,result.returncode,round(time.monotonic()-started,3),status,sep='\t',flush=True)

with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run,[0,2,3,4,5,6,7,8]))
