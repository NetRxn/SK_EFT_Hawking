# L1 outer case 32 independent exact replay

The independently verified sum is **-311265394132600099496295/5192296858534827628530496329220096 + 0i**.

The canonical parent is the seven-factor child at coordinate (17, (1,)) of the 48-entry roster, at zero-based index 32. Checkpoint 046f1f1f864c307124de9f28e12f9e83fe635a26 contains the archived parent SHA and the byte-identical inner roster. The independent support census found nine potentially nonzero values of G(0,1,2), with 2,001,024 total matched pair products and a maximum of 435,456 per value. Any nonzero full contraction term must appear in this pair. The nine cuts therefore cover the full support, and their inverse lifts recovered every compatible parent row and Gaussian coefficient with unchanged denominators.

The independent scalar replays used the audited terminal reduced inputs. All retained the complete conditioning, label partition, degree two and denominator product 40512224221827380280140849737629696. Slice 1 used a seven-factor sparse contraction with 6,391,680 products and a largest join of 3,866,112. Its independent raw scalar gives the same normalized result as the author's direct receipt. The other eight replays used separate four-factor inputs and disjoint bounded row shards. They accumulate exact Gaussian sums on the outgoing boundary of the selected pair before evaluating a complement inner product. The author's method groups work by ordinal outer rows and uses cached complement evaluations inside the pair loop.

For slices 0 and 6 the selected pair is (0,2), the same pair used by the author, with the reviewer's separate boundary-first method. Slices 2 and 3 use alternate pair (1,3) versus author (0,2), slices 4 and 5 use alternate pair (0,2) versus author (1,3), and slices 7 and 8 use alternate pair (2,3) versus author (1,3). Coincident normalized values for slices 4/5 and 7/8 do not enter the argument, since exact table comparison finds different supports and each input is replayed separately. The match with the already accepted case 36 subtotal does not enter the review either.

The ordinary sparse method enforces 8M products per join, 30M matched products overall and 1M output rows. Four-factor runs enforce 8M matched outer pairs, 30M multiplications, 30M closure probes, 200,000 accumulated rows and 120 seconds per shard. They check that the disjoint block and shard sums cover both the selected pair product forecast and all selected outer rows. The author initially refused standard joins for eight slices and used an intermediate peer support filter for 2 and 3. That filter only discards keys that lack necessary support across a pair of unjoined factors, after testing equality on every shared coordinate. Allowing false positives in the projected support affects cost only. The original cap receipts and peer code diff are preserved.

The independent aggregate checks every terminal replay against the author's frozen value and checks full interval coverage plus normalized and raw Gaussian sums where the author used shards. It applies the common factor denominator and the scale 1/(16*4^64) exactly once. Earlier intermediate transformations use frozen lineage and previously reviewed algebra. This evidence covers one outer case of one dense binary child of tuple 0. The complete signed coefficient and publication gates remain open.

## Four-factor replay bounds

| Slice | Pair | Shards | Total outer matches | Peak products/shard | Peak probes/shard | Peak accumulated rows | Wall seconds |
|---:|:-:|---:|---:|---:|---:|---:|---:|
| 0 | (0, 2) | 20 | 10543104 | 4620672 | 4019328 | 2592 | 34.044 |
| 2 | (1, 3) | 96 | 52222464 | 867168 | 269760 | 6048 | 57.522 |
| 3 | (1, 3) | 96 | 52222464 | 867168 | 269760 | 6048 | 58.44 |
| 4 | (0, 2) | 19 | 10005440 | 1125070 | 522680 | 8120 | 15.459 |
| 5 | (0, 2) | 19 | 10005440 | 1125070 | 522680 | 8110 | 15.809 |
| 6 | (0, 2) | 20 | 10725120 | 3959868 | 3569304 | 9000 | 40.082 |
| 7 | (2, 3) | 144 | 76737024 | 1751864 | 1154368 | 14624 | 105.586 |
| 8 | (2, 3) | 144 | 76737024 | 1751864 | 1154368 | 14624 | 97.938 |
