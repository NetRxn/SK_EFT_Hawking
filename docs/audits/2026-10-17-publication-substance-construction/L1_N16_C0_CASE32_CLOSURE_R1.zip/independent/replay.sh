#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 -u audit-all.py > audit-archive.out
python3 -u sparse-replay.py 1 0 > slice-1-replay.out
while read -r slice left right; do
  python3 -u four.py 32 "$slice" --pair "$left" "$right" > "slice-$slice-replay.out"
done <<'PLAN'
0 0 2
4 0 2
5 0 2
2 1 3
3 1 3
6 0 2
7 2 3
8 2 3
PLAN
python3 equality-check.py > equality-check.out
python3 aggregate.py > aggregate.out
