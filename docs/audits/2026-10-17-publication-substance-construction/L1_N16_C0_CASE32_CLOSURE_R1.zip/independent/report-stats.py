from pathlib import Path
from re import search, M

root = Path(__file__).resolve().parent
print('| Slice | Pair | Shards | Total outer matches | Peak products/shard | Peak probes/shard | Peak accumulated rows | Wall seconds |')
print('|---:|:-:|---:|---:|---:|---:|---:|---:|')
for i in range(9):
    if i == 1:
        continue
    log = (root / f'slice-{i}-replay.out').read_text()
    pair = search(r'^alternate pair (\S+, \S+) forecast (\d+)', log, M)
    complete = search(r'^complete shards (\d+) left rows \d+ peak Gaussian products/shard (\d+) '
                      r'peak closure probes/shard (\d+) peak entries (\d+) total products \d+ total probes \d+ seconds (\S+)', log, M)
    assert pair and complete
    group, matches = pair.groups()
    shards, product_peak, probe_peak, row_peak, seconds = complete.groups()
    print(f'| {i} | {group} | {shards} | {matches} | {product_peak} | {probe_peak} | {row_peak} | {seconds} |')
