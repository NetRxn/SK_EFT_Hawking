from fractions import Fraction
from pathlib import Path
from re import compile, M

evidence = Path(__file__).resolve().parent
author = Path('/private/tmp/l1-c0-case32.JxbpjP')
value = compile(r'^(?:independent )?exact normalized real (\S+) imaginary (\S+)(?: |$)', M)
interval = compile(r'^left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)$', M)
resources = compile(r'^replay input (\d+) (\d+) (\d+) (\S+) ([0-9a-f]{64}) (\d+) (\d+)$', M)
raw_scalar = compile(r'raw(?: scalar numerator)? (-?\d+) (?:imaginary )?(-?\d+) factor denominator (\d+)', M)

def read_scalar(path):
    text = path.read_text()
    matches = value.findall(text)
    raw = raw_scalar.findall(text)
    assert len(matches) == len(raw) == 1, path
    ar, ai, d = map(int, raw[0])
    scalar = tuple(map(Fraction, matches[0]))
    scale = d * 16 * 4**64
    assert scalar == (Fraction(ar, scale), Fraction(ai, scale)), path
    return scalar, (ar, ai, d)

def sum_values(values):
    return tuple(sum(components, Fraction(0)) for components in zip(*values, strict=True))

audit = (evidence / 'audit-archive.out').read_text()
assert audit.endswith('PASS canonical parent/roster identity, exact nine-coordinate coverage, all nine inverse lifts and terminal input metadata\n')
binding = {int(i): (int(coord), int(matches), name, sha)
           for i, coord, matches, name, sha, _, _ in resources.findall(audit)}
assert len(binding) == 9
frozen = [line.split('\t') for line in (author / 'author-case32.tsv').read_text().splitlines()]
assert len(frozen) == 10 and frozen[-1][0] == 'sum'
values = []
for i, (coord, matches, _, sha) in sorted(binding.items()):
    replay = evidence / f'slice-{i}-replay.out'
    scalar, raw = read_scalar(replay)
    row = frozen[i]
    assert tuple(map(int, row[:3])) == (i, coord, matches)
    assert scalar == tuple(map(Fraction, row[3:]))
    if i == 1:
        direct = value.findall((author / f'slice-{i}-contract.out').read_text())
        assert len(direct) == 1 and tuple(map(Fraction, direct[0])) == scalar
        print('author direct receipt', i, 'normalized scalar agrees; independent raw numerator retained')

    else:
        shards = list(author.glob(f'slice-{i}-shard-[0-9]*.out'))
        coverage = []
        author_values = []
        author_raw = []
        for shard in shards:
            found = interval.findall(shard.read_text())
            assert len(found) == 1, shard
            coverage.append(tuple(map(int, found[0])))
            val, nums = read_scalar(shard)
            author_values.append(val)
            author_raw.append(nums)
        coverage.sort()
        end = 0
        for k, (lo, hi, total, ordinal, count) in enumerate(coverage):
            assert lo == end and hi > lo and total == coverage[0][2]
            assert ordinal == k and count == len(shards)
            end = hi
        assert end == coverage[0][2]
        assert all(d == raw[2] for _, _, d in author_raw)
        author_total_raw = (sum(r for r, _, _ in author_raw), sum(im for _, im, _ in author_raw), raw[2])
        assert (sum_values(author_values), author_total_raw) == (scalar, raw) == read_scalar(author / f'slice-{i}-shard-sum.out')
        print('author shard coverage', i, len(shards), end, 'all disjoint intervals and exact raw/normalized sum verified')
    values.append(scalar)
    print('independent scalar', i, coord, matches, *scalar, sha, flush=True)
assert len(values) == 9
total = sum_values(values)
assert total == tuple(map(Fraction, frozen[-1][1:]))
print('PASS full exact independent case 32 sum', *total)
