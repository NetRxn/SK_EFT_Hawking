from pathlib import Path
import pickle

author=Path('/private/tmp/l1-c0-case32.JxbpjP')
for left, right in ((2,3),(4,5),(7,8)):
    label='peer' if left==2 else 'slice'
    ps = [author/f'join-cap-dense-label-{label}-{i}-reduced.pkl' for i in (left,right)]
    a,b = [pickle.loads(p.read_bytes()) for p in ps]
    print(left,right,'scopes equal',[fa[0]==fb[0] for fa,fb in zip(a['factors'],b['factors'],strict=True)],
          'table equality',[fa[1]==fb[1] for fa,fb in zip(a['factors'],b['factors'],strict=True)],
          'support equality',[fa[1].keys()==fb[1].keys() for fa,fb in zip(a['factors'],b['factors'],strict=True)])
