# L1 N16 dense group 128 case 32

Scientific source 51e7c745e. Publication parent 046f1f1f8. This is the original case (17,(1,)) in the first binary child of tuple 0, descendant (0,0). Restore `row-cap-physical-slice-dense-label-case-32-2-reduced.pkl` using the `L1_N16_C0_CASE3_SCALEUP_R1.zip` directions and earlier parent archive. The uncompressed parent SHA256 is 29ad168c8dfa92ee481c38d54e604a58109459855313d0efece71b5f6b91fd6a. Deserialize only trusted checkpoint inputs.

Copy the author Python files and checkpoint directory into fresh scratch. Run the initial nine cuts, reduce the two five-factor frontiers with the peer pair support, and check the reconstructed frontier hashes.

```bash
python3 -u run-primary.py /absolute/path/to/row-cap-physical-slice-dense-label-case-32-2-reduced.pkl
for id in 2 3; do
    python3 -u reduce-label-frontier.py "join-cap-dense-label-slice-$id-reduced.pkl" "peer-$id"
    if python3 -u contract-peer.py "peer-$id"; then exit 1; else test "$?" = 2 || exit 1; fi
done
shasum -a 256 -c /absolute/path/to/archive/reconstructed-frontiers.sha256
for specification in '0 0 2' '4 1 3' '5 1 3'; do
    read -r id left right <<< "$specification"
    for ((shard=0; shard<8; shard++)); do
        python3 -u close-four-shards.py "join-cap-dense-label-slice-$id-reduced.pkl"           --pair "$left" "$right" --shard "$shard" 8 >"slice-$id-shard-$shard.out" || exit 1
    done
done
python3 -u run-remaining.py
for specification in '0 8' '2 12' '3 12' '4 8' '5 8' '6 12' '7 30' '8 30'; do
    read -r id count <<< "$specification"
    python3 sum-shards.py "$id" "$count" >"slice-$id-shard-sum.out" || exit 1
done
python3 sum-case32.py
```

The partition uses all nine G(0,1,2) values and covers 2,001,024 compatible pair matches. Slice 1 closes by direct sparse contraction. All other slices close by disjoint ordinal intervals over the sorted keys of one factor, after exact support restrictions. The independent review must cover every slice and the recombination with complex signs and exact denominators. The complete hard profile and full original coefficient remain open.

## Faster repeat-reduction benchmark

After the primary replay, run `python3 -u benchmark-second-reduction.py` from scratch containing the terminal four-factor inputs. It applies an additional exact support and quotient reduction before choosing joins. The available cases which close must match the original shard sums exactly. Unclosed cases retain their frontier and can still use the bounded scalar routines. The author's benchmark receipts and input hashes are included.

The first slice replayed in 6.707 seconds including reduction and contraction, compared with 64.822 seconds summed over the eight original shard runs. Slices 4 and 5 replayed in 4.845 and 4.790 seconds, compared with 10.806 and 10.720 shard-seconds. These are bounded local observations under concurrent work, and the compared shard times exclude input preparation. They show where the extra reduction earns its cost. They cannot establish a full-profile runtime. Later cases should try that reduction on a changed frontier before falling back to row sharding.

The `independent` directory preserves the frozen nine-cut audit, alternate contraction receipts and complete exact retally. Run `python3 independent/aggregate-archive.py` from an extracted archive to reproduce the retally. See the independent report for the arithmetic replay commands and input bindings. The exact total is -311265394132600099496295/5192296858534827628530496329220096 with zero imaginary part. The equal case 36 scalar was checked independently and is never substituted for a case 32 value.
