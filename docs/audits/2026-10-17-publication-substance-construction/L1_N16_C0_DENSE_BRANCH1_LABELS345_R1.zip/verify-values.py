from csv import DictReader
from fractions import Fraction as Q
from pathlib import Path

base = Path(__file__).resolve().parent
author = list(DictReader((base/'author/label3/author-complete.tsv').open(), delimiter='\t'))
assert len(author)==17 and author[-1]['slice']=='total'
audit = (base/'independent/label3/signed-ledger.tsv').read_text().splitlines()
peer = list(DictReader(audit[1:-1], delimiter='\t'))
assert len(peer)==len(author[:-1])==16
total = Q(0)
for a,b in zip(author[:-1],peer,strict=True):
    assert (a['slice'],a['cut'],a['projected'])==(b['slice'],f"({b['coordinate']},)",b['support'])
    assert Q(a['real'])==Q(b['value_real'])
    assert Q(a['imaginary'])==Q(b['value_imaginary'])==0
    total+=Q(a['real'])
assert total==Q(author[-1]['real'])==Q(audit[-1].split('\t')[-2])
print(3,total,0,sep='\t')
mappings=list(DictReader((base/'independent/labels45/accepted-values.tsv').open(),delimiter='\t'))
assert [r['assignment'] for r in mappings]==['4','5']
for row in mappings:
    assert Q(row['normalized_imaginary'])==0 and int(row['edges'])==32
    print(row['assignment'],Q(row['normalized_real']),0,sep='\t')
