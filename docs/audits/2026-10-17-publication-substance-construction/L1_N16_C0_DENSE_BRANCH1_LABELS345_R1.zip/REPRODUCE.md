# L1 group 128 first-index branch 1, assignments 3 to 5

Source pin: `c3d67bd0e` and the original branch-0 evidence named by the
separate independent reviews. The integer contraction carries all original
factors and denominators. The six L assignments exhaust the original
parent. The accepted sums here cover only the three listed assignments.

For assignment 3 use `python3 -B retally.py | cmp - author-complete.tsv` from
`author/label3` after checking the archive hash manifest. Each complete
G(1,5,2) cut contributes once. The scripts, original pinned operands and
output logs describe the actual computation. The 16 terminal contractions
together used 2,222,272 matched products, excluding reduction work.

Assignments 4 and 5 reuse independently accepted branch-0 scalars through
exact normalized row bijections. Their independent certificate verifies both
parent supports, all row correspondence, factor denominators and the source
lift. Exact transfer scope includes only these two assignments.

The author restart receipts provide the next route for assignments 0–2.
No value is inferred from a row cap or an incomplete roster.
