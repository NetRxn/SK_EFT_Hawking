from ast import literal_eval
from collections import Counter
from hashlib import file_digest
from math import prod
from pathlib import Path
from pickle import dump,load

parent=Path('/private/tmp/l1-dense-resume.bbZW6V/row-cap-physical-slice-dense-binary-1.pkl')
with parent.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be'
    stream.seek(0)
    original=load(stream)
F=original['factors']
assert original['physical_cut']==(('R',1,3,0,2,1),1)
header='exact surviving L assignment 1 '
values=[literal_eval(row.removeprefix(header)) for row in Path('support.out').read_text().splitlines() if row.startswith(header)]
assert len(values)==6 and len(set(values))==6
labels=tuple(w for w,_ in values[0])
views=[tuple((i,labels.index(w)) for i,w in enumerate(A) if w in labels) for A,_,_ in F]
local=[Counter(tuple(k[i] for i,_ in view) for k in rows) for view,(_,rows,_) in zip(views,F,strict=True)]
census=[]
for case,joint in enumerate(values):
    assert tuple(w for w,_ in joint)==labels
    vals=tuple(x for _,x in joint)
    row_sizes=[C[tuple(vals[k] for _,k in view)] for C,view in zip(local,views,strict=True)]
    assert all(row_sizes)
    census.append((sum(row_sizes),case))
    print(case,sum(row_sizes),row_sizes,flush=True)
size,case=census[2]
selected=dict(values[case])
factors=[]
for A,rows,d in F:
    fixed=tuple((i,selected[w]) for i,w in enumerate(A) if w in selected)
    keep=tuple(i for i,w in enumerate(A) if w not in selected)
    new={}
    for row,z in rows.items():
        if all(row[k]==v for k,v in fixed):
            projected=tuple(row[k] for k in keep)
            assert projected not in new
            new[projected]=z
    factors.append((tuple(A[k] for k in keep),new,d))
assert sum(len(rows) for _,rows,_ in factors)==size
assert prod(d for _,_,d in factors)==40512224221827380280140849737629696
assert set(Counter(w for A,_,_ in factors for w in A).values())=={2}
with Path('sparse-label-pilot.pkl').open('xb') as stream:
    dump(dict(factors=factors,physical_cut=(original['physical_cut'],('complete-L-assignment',case)),
              selected=values[case],used_before=original['used_before']),stream,protocol=5)
print('least input row label',case,'rows',size,flush=True)
