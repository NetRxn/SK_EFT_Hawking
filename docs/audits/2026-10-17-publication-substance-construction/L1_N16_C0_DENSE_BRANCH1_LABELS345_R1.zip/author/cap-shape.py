from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
import pickle
import sys

for filename in sys.argv[1:]:
    path = Path(filename)
    payload = path.read_bytes()
    data = pickle.loads(payload)
    factors = data['factors']
    degree = Counter(wire for scope,_,_ in factors for wire in scope)
    assert set(degree.values()) == {2}
    assert prod(den for _,_,den in factors) == 40512224221827380280140849737629696
    print(sha256(payload).hexdigest(), data['physical_cut'], len(factors))
    print('rows', [len(rows) for _, rows, _ in factors])
    print('rejected_pair',data.get('rejected_pair'),'products',data.get('matched'))
    for i,(axes,_,_) in enumerate(factors):
        print('incident',i,sorted((j,len(set(axes)&set(other)))
            for j,(other,_,_) in enumerate(factors) if i!=j and set(axes)&set(other)))
