from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

axes, support = literal_eval(Path('s0.roster').read_text())
assert axes == (('G', 1, 5, 2),) and len(support) == len(dict(support)) == 16
ordered = sorted(support, key=lambda pair: (pair[1], pair[0]))
assert sum(count for _, count in ordered) == 1_069_056
assert max(count for _, count in ordered) == 89_088
total = Fraction(0)
print('slice', 'cut', 'projected', 'real', 'imaginary', 'work', sep='\t')
for index, (cut, count) in enumerate(ordered):
    case = Path(f'slice{index}')
    assert Path(f's{index}.roster').read_bytes() == Path('s0.roster').read_bytes()
    assert f'pilot {cut!r} matched {count} stored rows ' in (case/'partition.out').read_text()
    assert (case/'contraction.receipt').read_text().splitlines()[0] == 'child_status 0'
    line = (case/'contraction.out').read_text().splitlines()[-1]
    scalar, rows, work = re.fullmatch(
        r'exact normalized ([-\d/]+) peak rows (\d+) matched products (\d+)', line
    ).groups()
    value = Fraction(scalar)
    total += value
    print(index, cut, count, value, 0, work, sep='\t')
print('total', '', '', total, 0, '', sep='\t')
