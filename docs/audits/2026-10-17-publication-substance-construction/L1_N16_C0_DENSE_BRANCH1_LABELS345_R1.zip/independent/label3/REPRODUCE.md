# Reproduce group 128, first-index branch 1, L assignment 3

Use fresh output and verified operand paths. Source pins are in SOURCE_PINS.txt, native-operand.sha256 and operands.sha256. Original author source and text receipts are included under author-receipts. Preserve any SHA substitutions when paths change.

Run bash reproduce.sh to enumerate the original compatible L profiles, inverse-lift label 3, reproduce the exact cap and all sixteen branch stages, and independently contract and normalize every signed scalar. The retally contains input SHA256, raw Gaussian numerators, the factor denominator, signed normalized values and observed work. The portable manifest includes the reviewer source and proof receipts. Generated large intermediate tensors are bound by operand hashes and can be recomputed from the native frontier.
