from hashlib import sha256
from pathlib import Path
import shutil

prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
branch=prep/'branch1-label3'
author=Path('/private/tmp/l1-branch1-label3-roster.AoODtn')
data={
    'source': [prep/'read-support.py',prep/'rank-labels.py',prep/'contract-with-peer.py',prep/'peer_pair.py',
               prep/'verified-pin'/'label-3-branch-1.pkl',prep/'verified-pin'/'check-3.out',
               branch/'sparse-label-pilot.pkl',branch/'dense-saturated-frontier.pkl',
               branch/'row-cap-physical-slice-dense-branch.pkl',branch/'contraction.out',
               branch/'contraction.err',branch/'contraction.receipt',branch/'support.out',
               branch/'rank-labels.py',branch/'label-rank.out'],
    'author': sorted(p for p in author.rglob('*') if p.is_file()
                     and p.suffix in ('.pkl','.out','.tsv','.py','.roster','.receipt','.err')),
}
with Path('operands.sha256').open('w') as out:
    for family,paths in data.items():
        base=prep if family=='source' else author
        for src in paths:
            digest=sha256(src.read_bytes()).hexdigest()
            print(digest,src,sep='  ',file=out)
            if src.suffix=='.pkl':
                continue
            dst=Path('author-receipts')/family/src.relative_to(base)
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,dst)
