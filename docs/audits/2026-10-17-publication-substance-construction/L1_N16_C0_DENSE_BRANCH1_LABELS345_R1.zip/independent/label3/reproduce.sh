#!/usr/bin/env bash
set -euo pipefail
author=/private/tmp/l1-branch1-label3-roster.AoODtn
python3 -u source-and-partition.py > source-and-partition.out
python3 -u lineage.py > lineage.tsv
for i in {0..15}; do
 python3 -u independent-sparse.py "$i" "$author/label-s$i-reduced-frontier.pkl" > "slice-$i-replay.out"
done
python3 -u retally.py > signed-ledger.tsv
