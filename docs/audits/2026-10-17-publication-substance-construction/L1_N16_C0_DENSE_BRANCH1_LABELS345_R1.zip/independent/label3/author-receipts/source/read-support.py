from collections import Counter
from hashlib import file_digest
from itertools import product
from pathlib import Path
from pickle import load
import sys
source=Path(sys.argv[1])
for which in (0,1):
    p=source/f'row-cap-physical-slice-dense-binary-{which}.pkl'
    with p.open('rb') as stream:
        h=file_digest(stream,'sha256').hexdigest()
        stream.seek(0)
        obj=load(stream)
    fs=obj['factors']
    assert obj['physical_cut']==(('R',1,3,0,2,1),which)
    axis=('R',0,6,1,1,1)
    positions=tuple(i for i,(a,_,_) in enumerate(fs) if axis in a)
    assert len(fs)==10 and positions==(2,4)
    i,j=obj['rejected_pair']
    if i not in positions:
        i,j=j,i
    A,X,_=fs[i]
    B,Y,_=fs[j]
    shared=tuple(w for w in A if w in B)
    ai=tuple(A.index(w) for w in shared)
    bi=tuple(B.index(w) for w in shared)
    weights=Counter(tuple(row[p] for p in bi) for row in Y)
    assert axis in A and axis not in B and i in positions
    col=A.index(axis)
    hist=Counter()
    for row in X:
        hist[row[col]]+=weights[tuple(row[p] for p in ai)]
    hist=+hist
    assert sum(hist.values())==obj['matched']
    print('first branch',which,'sha256',h,'second selector',axis,'incidence',positions,'forecasts',sorted(hist.items()),flush=True)
    pos=[tuple((k,w) for k,w in enumerate(a) if w[0]=='L') for a,_,_ in fs]
    labels=sorted({w for row in pos for _,w in row})
    native=[{tuple(k[i] for i,_ in columns) for k in table}
            for columns,(_,table,_) in zip(pos,fs,strict=True)]
    domains=[]
    for wire in labels:
        domains.append(set.intersection(*[{row[n] for row in table}
                       for columns,table in zip(pos,native,strict=True)
                       for n,(_,w) in enumerate(columns) if wire==w]))
    assert all(d for d in domains) and all(len(d)<=2 for d in domains)
    for values in product(*map(sorted,domains)):
        points=dict(zip(labels,values,strict=True))
        if all(tuple(points[w] for _,w in view) in table for view,table in zip(pos,native,strict=True)):
            print('exact surviving L assignment',which,tuple(sorted(points.items())),flush=True)
