from ast import literal_eval
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial,prod
from pathlib import Path
from pickle import loads
import csv
import re

author=Path('/private/tmp/l1-branch1-label3-roster.AoODtn')
codes=(503841882182,1461451755920)
modes=sorted((a,b,c) for a,b,c in product(range(5),repeat=3) if a+b+c<=4)
occ=[]
for code in codes:
    record=[]
    for site in range(8):
        code,digit=divmod(code,64)
        record.append(modes[digit])
    assert not code
    occ.append(record)
world=sum((k+3)*value for layer in occ for powers in layer for k,value in enumerate(powers))
# Count cross-site sign by scanning site groups weighted by their insertions.
cross=0
for layer in occ:
    prior=[0]*8
    for site in range(8):
        for k in range(3):
            if site & (2**k):
                continue
            peer=site+2**k
            weight=sum(layer[u][j] for u in (site,peer) for j in range(3) if j!=k)
            cross+=weight*(sum(prior[site+1:])+sum(prior[peer+1:]))
            prior[site]+=weight
            prior[peer]+=weight
phase=(-1)**((world+cross)%2)
P=[p for layer in occ for site in layer for p in site]
total_occ=sum(P)
multiplicity=prod(map(factorial,P))
assert (total_occ,multiplicity,phase)==(32,16,1)
N=40512224221827380280140849737629696
scale=N*multiplicity*4**(2*total_occ)
print('normalization','occupation',total_occ,'factorial',multiplicity,'quarters exponent',2*total_occ,'world',world,'cross',cross,'phase',phase,'positive denominator',scale,sep='\t')

with (author/'author-complete.tsv').open() as f:
    ledger=list(csv.DictReader(f,delimiter='\t'))
assert len(ledger)==17 and ledger[-1]['slice']=='total'
axes,rows=literal_eval((author/'s0.roster').read_text())
assert axes==(('G',1,5,2),) and len(rows)==len(set(v for v,_ in rows))==16
roster=sorted(rows,key=lambda rw:(rw[1],rw[0]))
raw_total=[0,0]
terms=[]
print('slice','coordinate','support','input_sha256','raw_real','raw_imaginary','factor_denominator','value_real','value_imaginary','independent_products','seconds',sep='\t')
for i,((value,),weight) in enumerate(roster):
    q=ledger[i]
    assert (int(q['slice']),literal_eval(q['cut']),int(q['projected']))==(i,(value,),weight)
    raw=(author/f'label-s{i}-reduced-frontier.pkl').read_bytes()
    h=sha256(raw).hexdigest()
    o=loads(raw)
    assert o['conditioning']==[(axes[0],value)]
    log=Path(f'slice-{i}-replay.out').read_text()
    assert f'operand {i} {h} cut {o["conditioning"]}' in log.splitlines()
    re_i,im_i,d=map(int,re.search(r'^raw scalar (-?\d+) (-?\d+) factor denominator (\d+)$',log,re.M).groups())
    products,elapsed=re.search(r'^replay products (\d+) wall seconds (\S+)$',log,re.M).groups()
    assert d==N
    vals=(Fraction(phase*re_i,scale),Fraction(phase*im_i,scale))
    assert vals==(Fraction(q['real']),Fraction(q['imaginary']))
    shown=(author/f'slice{i}'/'contraction.out').read_text().splitlines()[-1]
    author_value,peak,work=re.fullmatch(r'exact normalized (\S+) peak rows (\d+) matched products (\d+)',shown).groups()
    assert vals==(Fraction(author_value),Fraction(0)) and int(work)==int(q['work'])
    assert (author/f'slice{i}'/'contraction.receipt').read_text().splitlines()[0]=='child_status 0'
    print(i,value,weight,h,re_i,im_i,d,*vals,products,elapsed,sep='\t')
    terms.append(vals)
    raw_total[0]+=re_i
    raw_total[1]+=im_i
sums=tuple(map(sum,zip(*terms,strict=True)))
assert sums==tuple(Fraction(phase*k,scale) for k in raw_total)
assert sums==(Fraction(ledger[-1]['real']),Fraction(ledger[-1]['imaginary']))
print('total',*raw_total,N,*sums,sep='\t')
