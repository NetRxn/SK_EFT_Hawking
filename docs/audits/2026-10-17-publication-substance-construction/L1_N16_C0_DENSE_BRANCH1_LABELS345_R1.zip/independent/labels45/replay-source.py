from archives import archive
from pathlib import Path
from gzip import decompress
from hashlib import sha256
from sys import executable
from subprocess import run,STDOUT
from time import perf_counter
from pickle import loads

source=Path('/private/tmp/l1-dense-resume.bbZW6V')
proof=Path('source-lineage')
(proof/'checkpoint').mkdir(parents=True)
binary=archive('DENSE_BINARY_REDUCTION')
qword='checkpoint/quotient.py'
(proof/qword).write_bytes(binary.read('quotient.py'))
assert (source/qword).read_bytes()==(proof/qword).read_bytes()
raw=source/'row-cap-physical-slice-dense-binary-0.pkl'
assert sha256(raw.read_bytes()).hexdigest()=='104a3ef35a14d1cb1a0b9f24203239b2e452bf955fb3ddbe3f80b127ceb51487'
(proof/raw.name).symlink_to(raw)
def command(name,output,returncode,args=(),arc=binary):
    (proof/name).write_bytes(arc.read(name))
    start=perf_counter()
    receipt=proof/output.split('/')[-1]
    with receipt.open('xb') as log:
        result=run([executable,'-B','-u',Path(name).name,*args],cwd=proof,stdout=log,stderr=STDOUT,timeout=310)
    assert result.returncode==returncode
    assert receipt.read_bytes()==arc.read(output)
    print('verified replay',name,*args,output,'status',returncode,'seconds',round(perf_counter()-start,6),flush=True)
command('saturate-binary-zero.py','saturate-binary-zero.out',0)
p=proof/'binary-zero-saturated-frontier.pkl'
assert p.read_bytes()==(source/p.name).read_bytes()
command('strip-fixed.py','strip-fixed.out',0)
p=proof/'binary-zero-fixed-stripped-frontier.pkl'
assert p.read_bytes()==(source/p.name).read_bytes()
command('contract-binary-zero-fixed.py','contract-binary-zero-fixed.out',2)
p=proof/'row-cap-physical-slice-dense-binary-zero-fixed.pkl'
assert p.read_bytes()==decompress(binary.read('branch128-binary-0-frontier.pkl.gz'))
pin0=sha256(p.read_bytes()).hexdigest()
assert pin0=='b1ec8c9da0e2aba8b866a0fafe40ac43e53b8c7bfc4895016102d87ce78ace4e'
conditioned=archive('DENSE_CONDITIONED_SCALARS')
(proof/'contract-second-cut-r2.py').write_bytes(conditioned.read('author/contract-second-cut-r2.py'))
assert (proof/qword).read_bytes()==conditioned.read('author/checkpoint/quotient.py')
for i in (0,1):
    start=perf_counter()
    with (proof/f'descendant{i}.out').open('xb') as log:
        result=run([executable,'-B','-u','contract-second-cut-r2.py',str(i)],cwd=proof,stdout=log,stderr=STDOUT,timeout=160)
    assert result.returncode==2
    assert (proof/f'descendant{i}.out').read_bytes()==conditioned.read(f'author/contract-second-cut-r2-{i}.out')
    o=(proof/f'join-cap-dense-binary-zero-child-{i}.pkl').read_bytes()
    assert o==(source/f'join-cap-dense-binary-zero-child-{i}.pkl').read_bytes()
    print('verified source descendant',i,'common source',pin0,'child hash',sha256(o).hexdigest(),'seconds',round(perf_counter()-start,6),flush=True)
