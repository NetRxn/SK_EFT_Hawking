# Group 128 first-index branch 1, assignments 4 and 5

| Original L assignment | Exact normalized real | Imaginary |
| --- | ---: | ---: |
| 4 | 6319960913952819098631/166153499473114484112975882535043072 | 0 |
| 5 | -10493250771659057325/649037107316853453566312041152512 | 0 |

The exact original ten-factor first-index parents are pinned at 104a3ef35a14d1cb1a0b9f24203239b2e452bf955fb3ddbe3f80b127ceb51487 and 4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be. Their first representative values are 0 and 1 on R(1,3,0,2,1). Each parent has 1,190,848 stored rows and the same positive denominator product. The exact second representative selector R(0,6,1,1,1) has only values 0 and 1 at both incidences and a forecast of 698,112 products per value in each parent.

The continuity checks were fresh at source c3d67bd0e5cf2fd32b4c9661d5aee060f3b6d7de. Verified the five source archive blobs against the checkpoint and their worktree bytes. The DENSE_CHILD01_PAIRED_COMPLETE_BRANCH0 archive pins both witness files and accepted normalized donor records. The DENSE_BINARY_REDUCTION archive includes the exact raw first-index branch-1 parent and the exact stripped branch-0 checkpoint.

## Full assignment support and exact row maps

For each original ten-factor parent, exhaustive enumeration checks all 256 vectors across 12 L labels, of which four are fixed. Exactly six assignments satisfy every factor-local projection. All six belong to the eight distinct projected source assignments. Both 12-label rosters and their exact factor row-count vectors agree.

Independent selection inverse lifts recover all matching rows, coefficients and denominators for each assignment in each parent. The exact witnesses are checked as bijections of compound edge values on the actual degree-two incidence graph. Both endpoints share the same map, and the map's domain and image equal the two endpoint support unions. Complete reconstructed target dictionaries equal the actual target dictionaries. All Gaussian coefficient pairs and individual denominators are preserved exactly. Factor ordering is the identity, and the maps carry no sign multipliers.

| Assignment | Raw factors | Edge bundles | Joint edge values | Changed edge values | Signed rows per side |
| --- | ---: | ---: | ---: | ---: | ---: |
| 4 | 10 | 32 | 536 | 17 | 112,576 |
| 5 | 10 | 32 | 522 | 17 | 102,912 |

One edge assignment maps consistently at both endpoints, so equality of summed edge values survives reindexing. The matching coefficients and complete support give equal scalar sums for the selected source and target networks. Each witness covers only its stated assignment.

## Exact branch-0 scalar sources

Replayed the raw first-index branch-0 operand through the two saturation sweeps, removal of 116 singleton coordinates, and guarded refusal to the archived stripped branch-0 bytes b1ec8c9d…. The 116-coordinate projection was also checked independently by inverse-lifting every one of the 1,001,096 signed rows. The four removed L labels have the same singleton value in all six original 12-label assignments. Each original assignment therefore matches the corresponding archived eight-label vector once.

Both exact second-selector runs reproduced the archived logs and their nine-factor descendants byte for byte, with child (0,0) hash d1272085… and child (0,1) hash b75a1f10…. Both resulting factor networks independently regenerate all six projected assignments and their individual factor row counts. The exact source subtotal for assignment 4 adds its two independently accepted descendant terms, each 6319960913952819098631/332306998946228968225951765070086144. Assignment 5 uses two separately bound terms, each -10493250771659057325/1298074214633706907132624082305024. These terms have disjoint second-selector values. Their numerical equality supplies no general symmetry or further reuse.

All four donor replay logs bind the exact descendant condition and complete L assignment. Their raw Gaussian numerators independently recover the committed normalized values. Occupancy decoding confirms profile (503841882182,1461451755920), degree 32, phase +1, factorial factor 16, and Haar denominator 4^64. The factor denominator product is 40512224221827380280140849737629696. Both summands carry this same normalization exactly once, so the accepted fractional terms add directly with unit weight. The output ledger records the resulting raw integers and normalized fractions.

Assignments 0–3 and the whole group remain outside this acceptance.

## Reproduction

Run python3 -B verify.py to regenerate the two exact opposite-branch values and map receipts. In a fresh directory run python3 -B replay-source.py to regenerate the frozen raw-to-descendant checkpoints, then python3 -B source-projection.py to check the global singleton inverse lifts, two exact projected rosters and all four donor numerators. The portable manifest covers the verifier, witnesses and text receipts. The separately checked operand manifest covers the large pickle files required for source-bound rerun.
