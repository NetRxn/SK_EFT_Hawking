from verify import *
from re import search,M
from time import perf_counter

HERE=Path('source-lineage')
cut0,cut1=[loaded(HERE/f'join-cap-dense-binary-zero-child-{i}.pkl')[0] for i in (0,1)]
source,_=loaded(HERE/'binary-zero-saturated-frontier.pkl')
stripped,_=loaded(HERE/'binary-zero-fixed-stripped-frontier.pkl')
fixed=stripped['stripped_fixed_coordinates']
N=prefix()
cert,plan,values,_=archives_and_values()
donors=archive('DENSE_CONDITIONED_SCALARS')
Z=archive('DENSE_CHILD01_TUPLES2_4')
fs=source['factors']
assert len(fixed)==116 and sum(w[0]=='L' for w in fixed)==4
for (a,X,d),(b,Y,e) in zip(fs,stripped['factors'],strict=True):
    choice=tuple((p,fixed[w]) for p,w in enumerate(a) if w in fixed)
    assert len(X)==len(Y) and d==e and b==tuple(w for w in a if w not in fixed)
    to_restore={}
    for key,z in Y.items():
        r=list(key)
        for p,v in choice:r.insert(p,v)
        to_restore[tuple(r)]=z
    assert to_restore==X
print('all 116 singleton deletions independently inverse lift onto all 1001096 original signed rows')
map_src,_=loaded(BASE/'row-cap-physical-slice-dense-binary-0.pkl',PARENT[0])
roster,axes=support(map_src)
raw_roster={tuple(scope) for scope,_ in roster}
removed={w:v for w,v in fixed.items() if w[0]=='L'}
assert all(dict(v)[w]==c for v in raw_roster for w,c in removed.items())
arch_proj={tuple(sorted(assignment.items())) for _,_,assignment,_ in plan}
assert arch_proj=={tuple((w,c) for w,c in scope if w not in removed) for scope in raw_roster}
assert set(removed)==set(axes)-{w for w,_ in next(iter(arch_proj))}
for child,root in enumerate((cut0,cut1)):
    assert root['conditioning']==[(FIRST,0),(SECOND,child)]
    factors=root['factors']
    assert len(factors)==9 and prod(d for _,_,d in factors)==D
    label_values=defaultdict(set)
    data=[]
    for a,rows,d in factors:
        axis=tuple(w for w in a if w[0]=='L')
        p=positions(a,axis)
        hist=Counter(project(k,p) for k in rows)
        for k in hist:
            for w,c in zip(axis,k,strict=True): label_values[w].add(c)
        data.append((axis,hist))
    lw=sorted(label_values)
    fs={}
    for v in product(*(sorted(label_values[w]) for w in lw)):
        a=dict(zip(lw,v,strict=True))
        count=[h[tuple(a[w] for w in axis)] for axis,h in data]
        if all(count):fs[tuple(a.items())]=count
    assert set(fs)==arch_proj
    assert all(fs[tuple(sorted(ass.items()))]==count for _,_,ass,count in plan)
    for i in (4,5):
        f=plan[i][2]
        needle={'index':i,'count':6,'values':f}
        reports={(0,4):(donors,'independent/replay-tuple4.out'),(0,5):(donors,'independent/replay-selected-five.out'),
                 (1,4):(Z,'independent/sparse-4.out'),(1,5):(donors,'independent/replay-child01-tuple5.out')}
        arc,member=reports[child,i]
        log=arc.read(member).decode()
        assert str(needle) in log and str(root['conditioning']+sorted(f.items())) in log
        raw=search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',log,M)
        assert raw and int(raw[3])==D
        actual=tuple(Fraction(int(n),N) for n in raw.groups()[:2])
        assert actual==values[i][child]
        print('verified disjoint source term',i,child,member,'normalized',*actual,'raw',*raw.groups()[:2])
    print('verified all six projected descendant assignments and matched signed supports',child)
