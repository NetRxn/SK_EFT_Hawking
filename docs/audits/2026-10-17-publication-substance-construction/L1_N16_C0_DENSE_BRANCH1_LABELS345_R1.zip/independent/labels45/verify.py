from archives import archive,LATEST
from ast import literal_eval
from collections import Counter,defaultdict
from csv import DictReader
from fractions import Fraction
from gzip import decompress
from hashlib import file_digest,sha256
from itertools import product
from math import prod,factorial
from pathlib import Path
from pickle import load,loads
from time import perf_counter

BASE=Path('/private/tmp/l1-dense-resume.bbZW6V')
AUTHOR=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy/verified-pin')
D=40512224221827380280140849737629696
FIRST=('R',1,3,0,2,1)
SECOND=('R',0,6,1,1,1)
PARENT=('104a3ef35a14d1cb1a0b9f24203239b2e452bf955fb3ddbe3f80b127ceb51487',
        '4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be')
SELECT={
    (4,0):'3932bf845ecf67c2a03b2b44e85737a11fa68e22ae8a8acaa5dbc76873a3c131',
    (4,1):'f682da78003a3dd5fb748fa90f51a2de064ac95da083440ba82020eb06ec901a',
    (5,0):'800709e31a2b24040c1d8dfc3ed443e2c415b9aafc73b0526ce4cf08026705eb',
    (5,1):'cd51f45f6dede7613e22c38c32c1cdbe44130a7b1570373cbe1b631de9782013'
}

def loaded(path, expected=None):
    with path.open('rb') as f:
        h=file_digest(f,'sha256').hexdigest()
        if expected is not None: assert h==expected,(path,h)
        f.seek(0)
        return load(f),h

def wires(factors):
    return Counter(w for ax,_,_ in factors for w in ax)

def positions(ax,group):
    return tuple(ax.index(w) for w in group)
def project(row,ps):
    return tuple(row[p] for p in ps)

def marginal_traffic(F,reject,wire):
    incident=[q for q,(a,_,_) in enumerate(F) if wire in a]
    assert incident==[2,4]
    i,j=reject
    if j in incident: i,j=j,i
    a,A,_=F[i];b,B,_=F[j]
    assert wire not in b and wire in a
    both=tuple(w for w in a if w in b)
    src=Counter(project(k,positions(a,both)+(a.index(wire),)) for k in A)
    rhs=Counter(project(k,positions(b,both)) for k in B)
    traffic=Counter()
    for k,ct in src.items():
        count=rhs[k[:-1]]
        if count: traffic[k[-1]]+=ct*count
    assert traffic=={0:698112,1:698112}
    for n in incident:
        ax,R,_=F[n]
        p=ax.index(wire)
        assert {r[p] for r in R}=={0,1}
    return traffic

def support(state):
    fs=state['factors']
    domain=defaultdict(list)
    ls=[]
    all_labels=tuple(sorted(w for w in wires(fs) if w[0]=='L'))
    for a,R,d in fs:
        cols=tuple(w for w in a if w[0]=='L')
        idx=positions(a,cols)
        h=Counter(project(k,idx) for k in R)
        for i,w in enumerate(cols):
            domain[w].append({p[i] for p in h})
        ls.append((cols,h))
    allowed=[set.intersection(*domain[w]) for w in all_labels]
    incidence=Counter(map(len,allowed))
    assert incidence=={1:4,2:8}
    passed=[]
    visits=0
    for tup in product(*(sorted(x) for x in allowed)):
        visits+=1
        loc=dict(zip(all_labels,tup,strict=True))
        nums=[h[tuple(loc[w] for w in sc)] for sc,h in ls]
        if all(nums): passed.append((tuple(loc.items()),tuple(nums)))
    assert len(passed)==6 and visits==256
    return passed,all_labels

def selected(factors,which,label,scope,counts):
    checkpoint,h=loaded(AUTHOR/f'label-{label}-branch-{which}.pkl',SELECT[label,which])
    target=checkpoint['factors']
    assert checkpoint['fixed']==scope and checkpoint['source']==PARENT[which]
    assert len(target)==len(factors)==10
    assert tuple(len(t) for _,t,_ in target)==counts
    assert prod(d for _,_,d in target)==D and set(wires(target).values())=={2}
    for (A,X,d),(B,Y,e) in zip(factors,target,strict=True):
        assert B==tuple(w for w in A if w not in scope) and d==e
        inds=tuple((k,scope[w]) for k,w in enumerate(A) if w in scope)
        recovered={}
        for ot,z in Y.items():
            assert len(ot)==len(B) and all(type(c) is int for c in z) and any(z)
            lifted=list(ot)
            for pos,v in inds: lifted.insert(pos,v)
            key=tuple(lifted)
            assert key not in recovered
            recovered[key]=z
        assert recovered=={k:v for k,v in X.items() if all(k[p]==val for p,val in inds)}
    print('all selected rows signed-inverse-lift verified',label,which,counts,sum(counts),h,flush=True)
    return target,h

def incidence(factors):
    W=defaultdict(list)
    for i,(axes,rows,d) in enumerate(factors):
        assert len(axes)==len(set(axes)) and rows and d>0
        for w in axes:W[w].append(i)
    assert all(len(appear)==2 for appear in W.values())
    out=defaultdict(set)
    for w,incident in W.items():out[tuple(incident)].add(w)
    return dict(out)

def map_tables(source,target,cert):
    perm,src_names,dst_names,dictionary,signs=cert
    assert perm==tuple(range(10))
    source_graph,target_graph=map(incidence,(source,target))
    assert set(dictionary)==set(source_graph)==set(target_graph)==set(src_names)==set(dst_names)==set(signs)
    assert all(not vals for vals in signs.values())
    assert source_graph=={k:set(v) for k,v in src_names.items()}
    assert target_graph=={k:set(v) for k,v in dst_names.items()}
    assert all(len(t)==len(set(t.values())) for t in dictionary.values())
    before=defaultdict(dict)
    after=defaultdict(dict)
    for i,((a,X,d),(b,Y,e)) in enumerate(zip(source,target,strict=True)):
        assert len(X)==len(Y) and d==e
        axis_map=[]
        for edge,t in dictionary.items():
            if i not in edge:continue
            u,v=positions(a,src_names[edge]),positions(b,dst_names[edge])
            before[edge][i]={project(k,u) for k in X}
            after[edge][i]={project(k,v) for k in Y}
            axis_map.append((u,v,t))
        image={}
        for key,z in X.items():
            row=[None]*len(b)
            for ss,tt,lookup in axis_map:
                vv=lookup[project(key,ss)]
                for p,v in zip(tt,vv,strict=True):
                    assert row[p] is None
                    row[p]=v
            q=tuple(row)
            assert all(v is not None for v in q) and q not in image and any(z)
            image[q]=z
        assert image==Y
    corrected={}
    for edge,t in dictionary.items():
        i,j=edge
        assert set(t)==before[edge][i]|before[edge][j]
        assert set(t.values())==after[edge][i]|after[edge][j]
        for k in edge: assert {t[v] for v in before[edge][k]}==after[edge][k]
        corrected[edge]=sum(k!=v for k,v in t.items())
    return len(dictionary),sum(len(t) for t in dictionary.values()),sum(corrected.values())

def prefix():
    codes=(503841882182,1461451755920)
    occ=tuple(v for v in product(range(5),repeat=3) if sum(v)<=4)
    layers=[[occ[(code>>(6*i))&63] for i in range(8)] for code in codes]
    edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if (u>>k)&1==0]
    angular=0
    for layer in layers:
        boundary=[(u,v,sum(layer[u])+sum(layer[v])-layer[u][k]-layer[v][k]) for u,v,k in edges]
        for i,(u,v,s) in enumerate(boundary):
            angular+=sum(s*t*sum(a>b for a in (u,v) for b in (x,y)) for x,y,t in boundary[i+1:])
    count=sum(sum(site) for layer in layers for site in layer)
    occ_factor=prod(factorial(n) for layer in layers for site in layer for n in site)
    grading=sum((3+k)*n for layer in layers for site in layer for k,n in enumerate(site))
    assert (count,occ_factor,grading,angular)==(32,16,136,444)
    phase=(-1)**((grading+angular)%2)
    assert phase==1
    print('normalization profile codes',codes,'phase',phase,'degree',count,'factorial',occ_factor,'Haar',4**(2*count),flush=True)
    return D*occ_factor*4**(2*count)

def archives_and_values():
    current=archive(LATEST)
    binary=archive('DENSE_BINARY_REDUCTION')
    c00=archive('DENSE_CHILD00_COMPLETE')
    cond=archive('DENSE_CONDITIONED_SCALARS')
    expected=archive('DENSE_CHILD01_TUPLES2_4')
    saved=decompress(binary.read('branch128-binary-1-frontier.pkl.gz'))
    assert sha256(saved).hexdigest()==PARENT[1]
    asserts=[binary.read('frontiers-uncompressed.sha256').decode().splitlines()[1].split()[0],PARENT[1]]
    assert len(set(asserts))==1
    raw_archive=cond.read('author/checkpoint/independent/states.tsv').decode()
    labels01=literal_eval(cond.read('child01/label-partition-roster.txt').decode())
    labels00=literal_eval(c00.read('independent/DENSE_CONDITIONED_SCALARS/author/label-partition-roster.txt').decode())
    assert labels00==labels01
    rows00=[r.split('\t') for r in c00.read('independent/descendant00-independent.tsv').decode().splitlines()]
    rows01=list(DictReader(current.read('recombined.tsv').decode().splitlines(),delimiter='\t'))
    independent=[r.split('\t') for r in current.read('independent/branch0-review/independent-composition.tsv').decode().splitlines()]
    norm=lambda r:tuple(map(Fraction,r))
    values={}
    for i in (4,5):
        re,im=norm(rows00[i+1][1:3])
        assert int(rows00[i+1][0])==i
        rec=next(r for r in rows01 if r['scope']==f'child01 tuple {i}')
        val=norm((rec['normalized_real'],rec['normalized_imaginary']))
        peer=next(r for r in independent if r[:2]==['tuple',str(i)])
        assert val==norm(peer[2:])
        evidence=rec['source'].split('::')[1]
        donor=expected if i==4 else cond
        table=donor.read(evidence)
        assert sha256(table).hexdigest()==rec['source_sha256']
        candidate=[r.split('\t') for r in table.decode().splitlines()]
        if i==4:
            q=next(r for r in candidate if r[0]=='4')
            assert val==norm(q[1:3])
        else:
            q=next(r for r in candidate if r[:2]==['0,1','5'])
            assert val==norm(q[2:4])
        values[i]=(re,im),val
    original=defaultdict(dict)
    for ln in raw_archive.splitlines():
        i,t,x,w,p,q=map(int,ln.split())
        original[i][('L',t,x,w)]=(p,q)
    return current,labels00,values,original

def main():
    start=perf_counter()
    normalizer=prefix()
    current,plans,values,original=archives_and_values()
    a=[]
    for j,h in enumerate(PARENT):
        parent,_=loaded(BASE/f'row-cap-physical-slice-dense-binary-{j}.pkl',h)
        fs=parent['factors']
        assert parent['physical_cut']==(FIRST,j) and len(fs)==10 and sum(len(t) for _,t,_ in fs)==1190848
        assert prod(d for _,_,d in fs)==D
        forecast=marginal_traffic(fs,parent['rejected_pair'],SECOND)
        assert sum(forecast.values())==parent['matched']
        roster,ls=support(parent)
        assert len(ls)==12
        original_support={tuple((w,a[w]) for w in ls) for a in original.values()}
        assert len(original_support)==8 and {k for k,_ in roster}<=original_support
        print('parent full independently measured',j,h,len(ls),len(roster),len(original_support),forecast,flush=True)
        a.append((roster,fs))
    assert a[0][0]==a[1][0]
    print('ordered two-parent complete roster',a[0][0],flush=True)
    with Path('accepted-values.tsv').open('w') as out:
        print('assignment','normalized_real','normalized_imaginary','raw_real','raw_imaginary',
              'source_sha256','target_sha256','map_sha256','edges','edge_values','changed_edge_values',
              sep='\t',file=out)
    for i in (4,5):
        scope=dict(a[0][0][i][0])
        assert {w:scope[w] for w in plans[i][2]}==plans[i][2] and plans[i][1]==i
        ts=[]; hs=[]
        for j,(roster,F) in enumerate(a):
            fr,h=selected(F,j,i,scope,roster[i][1]);ts.append(fr);hs.append(h)
        witness=f'label-{i}-signed-map.pkl.gz'
        contents=(AUTHOR/witness).read_bytes()
        assert contents==current.read('branch1-preparation/'+witness)
        assert (AUTHOR/f'check-{i}.out').read_bytes()==current.read(f'branch1-preparation/check-{i}.out')
        report=map_tables(*ts,loads(decompress(contents)))
        assert report[:2]==(32,{4:536,5:522}[i])
        donors=values[i]
        value=tuple(sum(col) for col in zip(*donors,strict=True))
        raw=tuple(v*normalizer for v in value)
        assert all(x.denominator==1 for x in raw)
        print('complete exact coefficient/denominator preserving alpha map',i,*report,sha256(contents).hexdigest(),
              'source scalar terms',donors,'opposite normalized exact',*value,'raw',*raw,flush=True)
        with Path('accepted-values.tsv').open('a') as out:
            from csv import writer
            writer(out,delimiter='\t',lineterminator='\n').writerow([i,*value,*raw,*hs,sha256(contents).hexdigest(),*report])
    print('elapsed seconds',round(perf_counter()-start,6),flush=True)

if __name__=='__main__':
    main()
