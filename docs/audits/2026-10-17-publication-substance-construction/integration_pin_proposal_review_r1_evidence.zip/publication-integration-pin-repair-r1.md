# Publication integration pin/serializer proposal R1

Status: UNAPPLIED source proposal, independent/root acceptance pending. The actual candidate is `1dc710e9185411ca86c794b75b95e86552e7610b`. Repository remained clean; no repository source files were written. Initial and final checks of the SAME original `publication-integration-pin-repair-r1.json` packet returned fresh=true, changed=[]. Final per-input hash comparison also found no drift. No snapshot was refreshed.

## Boundary and actual ownership

The initial packet lists L2 metadata and `src/core/constants.py`, but all apex pins actually live in `scripts/validation/checks/bundles_readiness.py`. ROOT explicitly authorized a proposal-only patch naming that actual owner after receiving this discovery. `src/core/constants.py` was never edited and requires no patch. The serializer remains the existing `scripts/bundle_json.py`; no serializer logic is changed. The unapplied patch changes two existing numeric assignments and adds L2's missing terminal LF only. No test, predicate, noise list, roster, exemption, scientific claim, closure, human field, stage field, charter, planner, infrastructure, or proof source is changed.

Read current CLAUDE/pipeline and continuity authorities, the brief and governing notebook/roadmap, and reused the existing complete 27-case classification. Historical primary 19-failure evidence was not substituted for this candidate. Full-profile 28-failure inventory remains parent evidence, not a newly evaluated inventory in this packet. This report is not an all-28 map or a routing ledger.

## Complete current membership and provenance

The existing roster supplies 21 bundles. Every metadata file was read; no missing metadata, duplicate (bundle, full-name) structured pair, or non-uniquely-resolving structured row was found. There are 637 raw `apex_theorems` entries: 636 structured claim rows plus ONE bare string described below. All 636 structured rows resolve exactly once in the actual candidate's existing `lean/lean_deps.json`, each is `kind=theorem`, and each record's module has an actual current Lean source file. They reference 582 unique full declaration names: repeated declarations in DIFFERENT bundles intentionally remain separate claim rows. Counting global distinct theorem names would silently change the production population.

Structured/scored per-bundle population: F 31; D1 35; D2 46; D3 92; D4 62; D5 70; D6 23; D7 16; D8 35; D9 27; D10 33; D11 73; D12 11; L1 14; L2 8; L3 13; I1 6; I2 20; I3 12; E1 4; E2 5. The raw D7 population is 17; its scored population is 16. Full membership in the JSON artifact preserves every bundle, array index, complete original entry, match count, extracted type/module/kind/axiom fields, and source path. It also records metadata/index/checker/serializer/source SHA256 values. This is source/index provenance, not a new kernel verification or a claim that each prose sentence matches its theorem.

**Existing coverage debt, preserved:** D7 `apex_theorems[16]` is the bare string `SKEFTHawking.BeliefPropagation.fourCycleFree_of_pairwise_factors`. It resolves to an actual theorem (existing record core axiom list `[propext]`, no project axioms), but carries no `claims` field. Both current production loops explicitly skip non-dictionaries. Commit `19bc5e3e9f1277f0d2c4ea0b1f6bcd29a53177b4` introduced this exact string. Therefore 636 is the COMPLETE EXISTING SCORED population, **not complete claims coverage of all 637 declared apex entries**. No string-to-object conversion, invented claim, proof assumption, predicate change, or hidden exclusion is proposed. If ROOT's acceptance requires all declared entries to be scored before any floor maintenance, withhold the floor hunk until the D7 source/claims repair is independently reviewed; do not claim that the floor hunk resolves this debt.

The floor's historical anchor `b628adf044b9716abe0f4f30ddbabcaec26e0fa1` measured 634. Comparing all bundle structured name multisets from that commit to current source gives exactly one membership change group: D7 +7 / -5, net +2, introduced by its redraft `90bdcfbb2018d464e36fe041057ab045050eaf9b`. All seven additions have current uniquely-resolving theorem records and present source. The JSON preserves the full +7/-5 lists and all intervening claim-string differences separately. No newly invented rows pad the floor.

## Strictness and withheld changes

| Existing parameter | Old | Proposed | Meaning |
|---|---:|---:|---|
| APEX_CLAIMS_SCORED_FLOOR | 634 | 636 | UP by 2: n>=636 instead of n>=634, for the existing structured/resolvable domain only |
| APEX_VACUITY_CEILING | 20 | 19 | DOWN by 1: n<=19 instead of n<=20; all flagged rows retained |
| APEX_UNDISCLOSED_VACUITY_CEILING | 15 | 15 | unchanged: actual undisclosed count remains 15 |
| APEX_CLAIM_NUMERAL_CEILING | 31 | 31 | unchanged: actual count35 remains a real failing residual |

The vacuity delta is legitimate withdrawal, not disappearance from measurement: commit `327e33bb37eab25b9e7a26395479fe8b54418b78` withdrew E2's disclosed `SKEFTHawking.AcousticMetric.hawking_temp_from_surface_gravity`, retaining its name and substantive reason in `apex_theorems_withdrawn`. Historical pin comment's 20 rows include E2=1; today's exact 19 rows have the same other eight-bundle distribution. That row had disclosed thinness, so withdrawing it lowers total20→19 without lowering undisclosed15. No row is suppressed or reclassified by this proposal.

Complete current flagged membership, measured from the original production function during the allowed baseline:

| Bundle | Declaration short name | Existing detector registers | Disclosed |
|---|---|---|---|
| F | r_d_independent_count_eight | MODELING_ASSUMPTION_THEOREMS [definitional] | NO |
| D1 | hawking_temp_from_surface_gravity | trivial witness [rfl] | NO |
| D2 | e8_sigma_div_8 | thin statement [reflexive-literal (Int.instDvd.dvd n n)] | yes |
| D2 | spectral_gap | thin statement [ground-arith] | yes |
| D3 | kaul_majumdar_log_decomposition | thin statement [ground-arith] | NO |
| D4 | hopf_link_matches_S_matrix | VACUOUS_STATEMENT_BASELINE; trivial witness [identity-return (hypothesis)] | NO |
| D4 | wrt_S2xS1_eq_rank | VACUOUS_STATEMENT_BASELINE; trivial witness [rfl] | yes |
| D4 | wrt_S3_formula | trivial witness [rfl] | yes |
| D5 | entropic_gravity_no_go_count_eight | MODELING_ASSUMPTION_THEOREMS [definitional] | NO |
| D5 | padmanabhan_cosmin_no_go_no_scalar_perturbation_theory | MODELING_ASSUMPTION_THEOREMS [definitional]; trivial witness [rfl] | NO |
| D5 | r_d_anchoring_partial_rescue_does_not_save_class_b_or_class_d | MODELING_ASSUMPTION_THEOREMS [definitional] | NO |
| D5 | r_d_independent_count_eight | MODELING_ASSUMPTION_THEOREMS [definitional] | NO |
| D5 | volovikJannes_he3a_depletion_eq_one | trivial witness [rfl] | NO |
| D5 | volovikJannes_he3a_lambda_j_eq_lambda_hk_real | trivial witness [rfl] | NO |
| D5 | finazzi_liberati_sindoni_bec_violates_universal_coupling | trivial witness [rfl] | NO |
| D5 | kss_de_partial_viable_under_lv_egj_path_a | trivial witness [rfl] | NO |
| D5 | volovik_jannes_he3a_satisfies_sakharov_criterion | trivial witness [rfl] | NO |
| D8 | cliffordTCompile_eq_recursion | trivial witness [rfl] | NO |
| D10 | landauer_conductance_def | trivial witness [rfl] | NO |

This is19 distinct (bundle, apex) rows across8 bundles, with4 disclosed and15 undisclosed. The two rows named `r_d_independent_count_eight` belong to different bundles and remain separate. The production check also measured zero placeholder and zero hard thin-statement apexes. Predicate/register membership, statements and original claims remain unchanged. The remaining thin/unbacked claims still require substantive review/repair; maintenance of this down-only bound does not prove apex substance or physics.

## Canonical L2 serialization

Used the actual candidate's `dump_bundle_json(json.loads(original_bytes))`. Exact old length9692 bytes, proposed9693. `new == old + b"\n"` is true; parsed JSON objects equal and canonical reserialization of the proposed bytes is a fixed point. This proves every existing byte, including all human/stage/claims/charter data, remains unchanged before the single terminal LF.

Old SHA256 `f5231e903694eef7b637da53e759e728bfcc57da6ab158094b836c648c4bb341`. Proposed SHA256 `eb926f0fb30a8df77f38993ddb897441fe6f1aa95742c07d04811c7e7a363b0a`. The serializer itself is unchanged.

## Baseline actually executed once

Interpreter: `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python` (primary .venv). Candidate checker, registry, helpers and serializer origins all resolve to this actual l1-main-delivery checkout; exact origins are in JSON. Bytecode writes were disabled and pytest's cache provider disabled. Ran `pytest.main` once, with exactly these existing node IDs and no broad collection target:

1. `tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_the_population_floor_has_zero_headroom`
2. `tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_the_population_floor_has_zero_headroom`
3. `tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_both_ratchets_have_zero_headroom`
4. `tests/test_bundle_json_serializer.py::TestCorpusIsCanonical::test_blob_is_byte_stable_through_the_serializer[papers/L2/bundle_metadata.json]`

Arguments were `-q -p no:cacheprovider` plus those four node IDs. Pytest result: **4 FAILED in2.55s**, return1. First two:636!=634. Third:19!=20; its second assertion was not reached, so the15 undisclosed measurement comes from the production return, not that unexecuted assertion. Fourth: serializer emits the missing LF. Full stdout/stderr, exact args and all three original check results are retained in JSON.

A passive `sys.setprofile` return observer copied local populations from the original check frames during those tests. It did not replace code, monkeypatch constants, modify arguments/results, run another check, or seed a source fault. Grounded was invoked once, vacuity twice (the two named tests); both vacuity populations matched. Grounded remained measured=true, passed=false with35 numeral-gap rows above31, zero placeholders/restatements. Vacuity was measured=true, passed=true before this proposal;19<=20 and15<=15. No proposal was applied or post-application pass claimed.

The JSON includes all35 numeral-gap identities and missing-numeral sets from the original return-frame locals, beyond the function's first20+ellipsis detail output. These are the existing detector's pointers for claim/type investigation, **not35 newly adjudicated scientific defects**. No maximum was raised to erase them.

## Proposed actual negative/restoration controls for ROOT after independent review/application

No mutations ran in this assignment. After ROOT applies a reviewed candidate, first rerun the same four exact tests, and the existing `test_every_flagged_row_is_NAMED_in_the_output` case to qualify the full named population. Expected equality/serialization outcomes are proposals until measured.

For vacuity use the existing `TestApexClaimsNotVacuous::test_PRODUCTION_SEEDED_a_vacuous_apex_turns_the_real_corpus_red`: it seeds real L3 metadata through `seeded_mutation` and checks placeholder, hard-thin and undisclosed trivial-witness transitions plus actual restoration. With total pin19 and undisclosed pin15, the witness seed should grow both populations and turn the real production gate red; require restored metadata bytes/mtime and unseeded production result, not just expected counts.

For floor loss, a meaningful production control must remove ONE actual uniquely scored structured row from real bundle metadata under the existing restoration journal, then inspect BOTH original production functions' `population_floor` details/scored636→635 and restore exact source and original detail populations. Grounded is already red from35>31, so global red→red is NOT evidence that its floor fired. Its existing full production placeholder test currently fails at the initial green precondition and must not be reported as successful seeding. Existing fixture/monkeypatch population-floor tests are useful unit controls but not evidence of an actual production source transition. A production drop control requires ROOT authorization after application; no new checker or test mechanism is proposed here.

For L2, rerun the exact existing serializer case against the applied canonical file, remove only the terminal LF under the existing source-restoration journal, require the SAME serializer case to fail, restore exact bytes/mtime and require the SAME case to pass. Parsed-object equality and full-file hashes must hold throughout the control; do not alter human/stage data or substitute a serializer.

## Remaining scientific/publication work and next existing group

The grounded gate remains scientifically unchanged and red at35 numeral gaps versus31. All19 content-free registrations and15 undisclosed claims remain named and open to substantive repair. D7's bare-string claim coverage debt is retained. No human attestation or scientific finding is closed, and there is no full-suite/main/publication acceptance.

Use the existing planner output `/tmp/l1-ibp-canonical-plan-r1.json` already generated by ROOT, not a new routing map. A coherent next source-backed claim group is its queued `papers/D1/bundle_metadata.json` substrate/prose package: original `review:2026-08-15-d1-stage10-redraft:D1:1.2`, `:2.1`, `:2.4`, `:2.6`. Read each original finding and theorem/manuscript evidence before commissioning; the planner's zero-local-slot message is not live admission authority. Existing apex-claims-unbacked groups also retain D5 metadata1.2, E8/GenerationConstraint1.3 and E8/checker1.4. These are evidence of existing routing, not authorization to change physics or weaken this gate. ROOT retains L1; Executor's deep-physics lane remains separate. Original L1 human2.1 and physical B3/mode/transport obligations remain open.

## Delivery and checks

Patch: `/tmp/publication-integration-pin-repair-r1.patch`, SHA256 `b8121565392bf6bf3c565f251f387316532a41d90936f1f2346526ad7075427b`. `git apply --check` returned0 with empty output; patch remains UNAPPLIED. Report: `/tmp/publication-integration-pin-repair-r1.md`. Complete evidence: `/tmp/publication-integration-pin-repair-r1.json`. Only those three temporary outputs were written. No broad/native/Lean/LSP/extraction/cache/controller/process/simulation operations ran. No root notebook or packet was written. Final same-packet check fresh=true, changed=[]; final git status empty; all recorded current input hashes unchanged. Independent review and ROOT application/appropriate existing gates remain required.
