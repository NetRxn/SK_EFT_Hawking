# Independent review of L1 separator cases 1 and 2

Continuity packet l1-separator-batch-review-r1 checked fresh with no changed authority inputs. This review covers cases 1 and 2 of the accepted 48-case partition within the first binary child of tuple 0.

Independent histogram projection of the saved eight-factor parent reproduces the full 48-case support and its exact product counts. Case ordering is by forecast then the coordinate tuple. The selected entries are case 1 at (20, (3,)) and case 2 at (33, (3,)), each with 70,896 matched products at the projected pair. Both conditioned tables lift back bijectively to exactly the parent rows satisfying the selected coordinate tuple. Factor coefficients and denominators are preserved. Source conditioning and the original label partition match the terminal reduced tables.

The independent direct sparse Gaussian integer replay used the final reduced tables with no author quotient or contraction routines. The factor denominator product for both was 40512224221827380280140849737629696, matching the prior accepted branch-128 assembly. Normalization uses the original profile’s +1/(16*4^64), with no additional cut multiplicity.

| Case | Normalized real value | Imaginary value | Products total | Largest join | Peak output rows |
|---|---|---:|---:|---:|---:|
| 1 | 3196789373761759059327/5192296858534827628530496329220096 | 0 | 6,945,952 | 4,938,288 | 118,976 |
| 2 | 10046146121220966055407/5192296858534827628530496329220096 | 0 | 3,698,504 | 2,119,440 | 102,128 |

Both values reproduce the author results exactly and stay within the assigned bounds. Replay establishes arithmetic from the final reduced inputs. The earlier reductions use the previously reviewed identities and saved lineage. The review makes no estimate of the downstream join cost for other cases and no claim of full original-source replay.

The two cases are disjoint from one another and from the prior case 0. These acceptances leave 45 cases in this first binary child plus the entire complementary binary child and tuple 1. No complete tuple, branch, profile or c0 coefficient follows.
