from ast import literal_eval
from collections import Counter
from pathlib import Path
import pickle

root = Path('/private/tmp/l1-tuple-separators.OxRDWT')
previous = Path('/private/tmp/l1-dense-resume.bbZW6V')

def load(path):
    return pickle.loads(path.read_bytes())

def audit(source, pair, fixed_axes, plan, children):
    parent = load(source)
    factors = parent['factors']
    degree = Counter(w for axes, _, _ in factors for w in axes)
    assert set(degree.values()) == {2}
    left, right = (factors[i] for i in pair)
    common = set(left[0]).intersection(right[0])
    ordered = tuple(sorted(common))
    buckets = Counter(tuple(dict(zip(right[0], row))[a] for a in ordered) for row in right[1])
    spectrum = Counter()
    for row in left[1]:
        assignment = dict(zip(left[0], row))
        multiplicity = buckets[tuple(assignment[a] for a in ordered)]
        if multiplicity:
            spectrum[tuple(assignment[a] for a in fixed_axes)] += multiplicity
    assert spectrum == plan
    for coordinate, path in children.items():
        fixed = dict(zip(fixed_axes, coordinate))
        child = load(path)
        assert child['conditioning'] == parent['conditioning'] + list(fixed.items())
        assert child['label_partition'] == parent['label_partition']
        for (axes, rows, denominator), (small_axes, small_rows, small_denominator) in zip(factors, child['factors'], strict=True):
            assert denominator == small_denominator
            assert tuple(w for w in axes if w not in fixed) == small_axes
            expected = {row: value for row, value in rows.items()
                        if all(row[p] == fixed[w] for p,w in enumerate(axes) if w in fixed)}
            recovered = {}
            for row,value in small_rows.items():
                assignment = dict(zip(small_axes,row))
                assignment.update(fixed)
                recovered[tuple(assignment[w] for w in axes)] = value
            assert recovered == expected
    print(source.name, 'pair',pair,'cuts',fixed_axes,'cases',len(spectrum),
          'sum/max products',sum(spectrum.values()),max(spectrum.values()),'children audited',list(children),flush=True)

batch = Path('/private/tmp/l1-separator-batch.s99JBN')
source = root/'row-cap-physical-slice-dense-label-tuple0-0-reduced.pkl'
axes, raw = literal_eval((root/'pilot.roster').read_text())
counts = dict(raw)
order = sorted(counts, key=lambda x:(counts[x], x))
children = {}
for case, stage, coordinates in ((1,1,(20,(3,))), (2,2,(33,(3,)))):
    assert order[case] == coordinates
    assert literal_eval((batch/f'case-{case}.roster').read_text()) == (axes,raw)
    childfile = batch/f'case-{case}.pkl'
    children[coordinates] = childfile
    child = load(childfile)
    final = load(batch/f'label-case-{case}-{stage}-reduced-frontier.pkl')
    assert child['label_partition'] == final['label_partition']
    assert child['conditioning'] == final['conditioning']
    print('case',case,'tuple',coordinates,'full conditioning',final['conditioning'],flush=True)
audit(source,load(source)['rejected_pair'],axes,counts,children)
print('PASS independent pair coverage and inverse-lift equality for cases 1 and 2')
