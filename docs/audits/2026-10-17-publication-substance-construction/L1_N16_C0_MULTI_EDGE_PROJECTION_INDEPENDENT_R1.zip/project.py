from collections import Counter,defaultdict,deque
from functools import cache
from itertools import product
from census import occupancy,profile,components,read,write

previous="/private/tmp/l1-c0-dual-independent.iqPptEG2"
todo=[tuple(map(int,r)) for r in read(previous+"/block-remaining.tsv")]

@cache
def irrep_domain(m,dim):
    if dim==1:return tuple((p,) for p in range(m%2,m+1,2))
    return tuple((p,q) for p,q in product(range(m+1),repeat=2) if p+q<=m and (m-p-q)%2==0)

@cache
def singlet(labels):
    # Generate the possible SU(2) fused doubled spins directly, using
    # Clebsch--Gordan couplings in steps of two.
    reachable={0}
    for x in labels:
        reachable={n for y in reachable for n in range(abs(x-y),x+y+1,2)}
    return 0 in reachable

@cache
def filter_constraint(kind,limit,domains):
    viable=[set() for _ in domains]
    dim=len(domains[0][0])
    for labels in product(*domains):
        if kind=="time":
            if any(not singlet(tuple(sorted(seq))) for seq in zip(*labels)):continue
        else:
            cost=[sum(abs(x-y) for x,y in zip(labels[i],labels[i+1])) for i in (0,2)]
            if sum(cost)>limit:continue
        for support,label in zip(viable,labels):support.add(label)
    return tuple(tuple(sorted(s)) for s in viable)

@cache
def projection(a,b,dim):
    (A,_,eA),(B,_,eB)=profile(a),profile(b)
    domains={}
    temporal=defaultdict(set)
    constraints=[]
    for t,C in enumerate((A,B)):
        for (u,v,k),(p,q) in C.items():
            for x,m in ((u,p),(v,q)):
                if not m:continue
                name=t,x,k
                domains[name]=irrep_domain(m,dim)
                for y in (u,v):temporal[t,y].add(name)
    for active in temporal.values():
        constraints.append(("time",0,tuple(sorted(active))))
    for u,v,k in sorted(A.keys()|B.keys()):
        for x,t in product((u,v),range(2)):
            domains.setdefault((t,x,k),irrep_domain(0,dim))
        budget=min(sum(e.get((u,v,k),(0,0))) for e in (eA,eB))
        constraints.append(("space",budget,((0,u,k),(1,u,k),(0,v,k),(1,v,k))))
    affected=defaultdict(set)
    for i,(_,_,group) in enumerate(constraints):
        for root in group:affected[root].add(i)
    queue=deque(range(len(constraints)));scheduled=set(queue)
    while queue:
        i=queue.popleft();scheduled.remove(i)
        kind,limit,group=constraints[i]
        current=tuple(domains[x] for x in group)
        updated=filter_constraint(kind,limit,current)
        if not all(updated):return None
        for x,old,new in zip(group,current,updated):
            if old==new:continue
            domains[x]=new
            for j in affected[x]-scheduled-{i}:
                queue.append(j);scheduled.add(j)
    reduced=[];forced=[]
    for t,C in enumerate((A,B)):
        graph={}
        for (u,v,k),(p,q) in C.items():
            vals=[]
            for x,n in ((u,p),(v,q)):
                live=any(any(r) for r in domains[t,x,k])
                vals.append(n if live else 0)
                if n and not live:forced.append(n)
            if any(vals):graph[u,v,k]=tuple(vals)
        reduced.append(graph)
    return tuple(reduced),tuple(forced),domains

def geometry():
    assert len(todo)==10994 and sum(w for a,b,w in todo)==947355
    before=Counter();before_pair=Counter();after=Counter();largest=Counter()
    scalar=[];iso=[];odd=[];admit=[];final=[]
    forced=Counter();even=Counter();endpoint=Counter()
    odd_pattern=Counter()
    for a,b,w in todo:
        A,lA,eA=profile(a);B,lB,eB=profile(b)
        oc=occupancy(a)+occupancy(b)
        is_even=all(n%2==0 for row in oc for n in row)
        if is_even:even["orbits"]+=1;even["labels"]+=w
        assert (A.keys()|B.keys())&(eA.keys()|eB.keys())
        shapes=[tuple(sorted(components(c))) for c in (A,B)]
        before.update(shapes[0]+shapes[1])
        before_pair[tuple(sorted(shapes))]+=1
        full=projection(a,b,2);weak=projection(a,b,1)
        assert full is not None and weak is not None
        graphs,removed,_=full
        assert graphs==weak[0]
        forced[len(removed)]+=1
        all_components=components(graphs[0])+components(graphs[1])
        row=(a,b,w)
        if not all_components:
            assert is_even
            scalar.append(row)
            continue
        if all(s[1]==1 for s in all_components):
            iso.append(row)
            if is_even:
                assert all(sum(d) in (2,4) and all(v%2==0 for v in d) for d in (*eA.values(),*eB.values()))
                assert all(min(p)>0 for graph in graphs for p in graph.values())
                admit.append(row)
                continue
            odd.append(row)
            odd_pattern[tuple(sorted(p for c in graphs for p in c.values()))]+=1
            endpoint.update(tuple(sorted(d)) for d in (*eA.values(),*eB.values()) if any(v%2 for v in d))
        largest[max(s[1] for s in all_components)]+=1
        after.update(all_components)
        final.append(row)
    print("original common components",before.most_common(4),"largest paired class",max(before_pair.values()))
    print("original all-even",dict(even),"coframe disjoint",0)
    print("full and total support agree",len(todo),"forced counts",sorted(forced.items()))
    assert sum(n for k,n in forced.items() if k)==6787
    for name,rows,n,w in (("scalar",scalar,352,27696),("isolated",iso,184,15840),
                          ("even-admit",admit,160,15024),("odd-unresolved",odd,24,816),
                          ("block-remaining",final,10482,904635)):
        assert len(rows)==n and sum(r[2] for r in rows)==w
        write(name+".tsv",rows)
        print(name,n,w)
    print("remaining largest core",sorted(largest.items()))
    print("remaining common components",after.most_common(10))
    print("odd root patterns",odd_pattern,"odd coframe endpoint loads",endpoint)
    assert odd_pattern=={((1,1),)*4:24} and endpoint=={(1,1):96,(1,3):96}
    # Previously exact overlapping pilot remains admissible in both
    # adjoint channels at all four participating roots.
    p=projection(166856593410,8960795485785,2)[2]
    assert all((2,0) in p[t,x,0] and (0,2) in p[t,x,0] for t,x in product(range(2),(4,5)))
    print("both adjoint channels remain at every prior pilot root")
if __name__=="__main__":geometry()
