#!/bin/zsh
set -euo pipefail
cd -- "${0:A:h}"
primary=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking
frozen=/private/tmp/l1-c0-multi.TIUoLhg3
prev=/private/tmp/l1-c0-dual-independent.iqPptEG2
(cd "$primary"; python3 scripts/codex_continuity.py check .codex/continuity/l1-c0-multi-edge-independent-r1.json) > continuity.out
verify() {
    local dir=$1 digest=$2 out=$3
    (cd "$dir"; shasum -a 256 manifest.sha256; shasum -a 256 -c manifest.sha256) > "$out"
    test "$(cut -d' ' -f1 < "$out" | head -1)" = "$digest"
}
verify "$frozen" d4fcb8e11906827a6412a8326ff90dfaefdf02ed1d72dd984867818dd5fa9834 author-manifest.out
verify "$prev" 96f585f21560748dd3ab643dd5ffc4eda9a06ea9af110fc65db5c9ee80c938cc dual-manifest.out
for f in census.py classify.py contract.py edge-moments.tsv mixed.tsv source-gram.tsv bivectors.tsv imaginary-trace.tsv decorated-{0,1}-{0,1,2}.tsv; do cmp "$f" "$prev/$f"; done
for f in decorated-{0,1}-{0,1,2}.tsv imaginary-trace.tsv; do cmp "$f" "$frozen/$f"; done
sort mixed.tsv | cmp - <(sort "$frozen/mixed.tsv")
sort bivectors.tsv | cmp - <(sort "$frozen/bivectors.tsv")
export PYTHONDONTWRITEBYTECODE=1
python3 project.py > project.out
cmp odd-unresolved.tsv "$frozen/reduced-odd-unresolved.tsv"
python3 signed.py > signed.out
for f in scalar.tsv isolated.tsv scalar-exact.tsv reduced-exact.tsv; do cmp "$f" "$frozen/$f"; done
PYTHONPATH="$primary" "$primary/.venv/bin/python" control.py > control.out
