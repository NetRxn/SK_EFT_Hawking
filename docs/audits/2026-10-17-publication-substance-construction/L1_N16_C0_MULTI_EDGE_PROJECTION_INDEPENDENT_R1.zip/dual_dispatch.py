from collections import Counter
from fractions import Fraction as F
from functools import cache
from itertools import permutations,product
from math import prod,factorial
from classify import classify,coeff,degree,removed,write,triples
from census import read,occupancy,profile
from contract import value

@cache
def decorated_key(code,decorations):
    m=occupancy(code)
    options=[]
    for order in permutations(range(3)):
        image=[sum(((v>>k)&1)<<order[k] for k in range(3)) for v in range(8)]
        labels=[triples.index(tuple(row[order.index(i)] for i in range(3))) for row in m]
        for shift in range(8):
            new=sum(label<<(6*(image[v]^shift)) for v,label in enumerate(labels))
            dec=tuple(sorted((tuple(sorted((image[a]^shift,image[b]^shift))),chi) for (a,b),chi in decorations))
            exchange=tuple((e,1-chi if chi!=2 else 2) for e,chi in dec)
            options.append((new,min(dec,exchange)))
    return min(options)

def terms(a,b,scalar=False,reduced=None):
    A,lA,eA=profile(a);B,lB,eB=profile(b)
    extra=()
    if reduced is not None:
        (A,B),extra=reduced
    denom=prod(factorial(n) for t in occupancy(a)+occupancy(b) for n in t)
    overall=F(prod(coeff(n,0,0) for n in lA+lB+extra),denom)
    edge_choices=[]
    for e in sorted(A.keys()|B.keys()):
        p=A.get(e,(0,0));q=B.get(e,(0,0))
        x=sum(eA.get(e,(0,0)));y=sum(eB.get(e,(0,0)))
        constant=prod(coeff(n,0,0) for n in p+q)
        if not (any(p) and any(q)):
            assert min(x,y)<4
            overall*=constant
        elif not (x or y):
            overall*=sum(prod(coeff(n,i,j) for n in p+q)/F(((2*i+1)*(2*j+1))**4) for i,j in product(range(3),repeat=2))
        else:
            edge=e[:2]
            assert x in (0,2) and y in (0,2)
            opts=[((),(),constant)]
            if x and y:
                assert p==q==(2,2)
                opts.extend((((edge,c),),((edge,c),),F(1,d**6)) for c,d in ((0,3),(1,3),(2,4)))
            elif x:
                assert p==(2,2)
                wt=prod(3*coeff(n,1,0) for n in q)/3**7
                opts.extend((((edge,c),),(),wt) for c in range(2))
            else:
                assert q==(2,2)
                wt=prod(3*coeff(n,1,0) for n in p)/3**7
                opts.extend(((),((edge,c),),wt) for c in range(2))
            edge_choices.append(opts[:1] if scalar else opts)
    out=Counter()
    for opts in product(*edge_choices):
        L=tuple(sorted(e for x,y,z in opts for e in x))
        R=tuple(sorted(e for x,y,z in opts for e in y))
        key=tuple(sorted((decorated_key(a,L),decorated_key(b,R))))
        out[key]+=overall*prod(z for x,y,z in opts)
    return out

