from fractions import Fraction as F
from math import prod,factorial
from project import projection
from dual_dispatch import terms,decorated_key
from classify import canonical,coeff
from census import profile,occupancy,read,write
from contract import value

def roster(file):
    return [tuple(map(int,r)) for r in read(file)]
sc=roster("scalar.tsv")
re=roster("even-admit.tsv")
keys=sorted({canonical(code) for a,b,w in sc for code in (a,b)})
assert len(keys)==20
base={k:value(k) for k in keys}
sc_out=[]
for a,b,w in sc:
    m=[n for v in occupancy(a)+occupancy(b) for n in v]
    const=F(prod(coeff(n,0,0) for n in m),prod(factorial(n) for n in m))
    graphs,extra,_=projection(a,b,2)
    assert not any(graphs)
    assert sorted(extra+profile(a)[1]+profile(b)[1])==sorted(n for n in m if n)
    z=base[canonical(a)]*base[canonical(b)]*const
    assert z>0
    sc_out.append((a,b,w,z))
t0=sum(w*z for a,b,w,z in sc_out)
assert t0==F(843344393264084456134970038551,288230376151711744)
write("scalar-exact.tsv",sc_out)
print("scalar configurations",len(keys),"weighted subtotal",t0,flush=True)

cases={}
dual=0
for a,b,w in re:
    graphs,extra,_=projection(a,b,2)
    assert all(n%2==0 for n in extra)
    A,B=graphs;eA,eB=profile(a)[2],profile(b)[2]
    dual+=bool((A.keys()&B.keys())&(eA.keys()|eB.keys()))
    cases[a,b]=terms(a,b,reduced=(graphs,extra))
assert dual==6
keys=sorted({k for r in cases.values() for pair in r for k in pair})
assert len(keys)==21
D={k:value(*k) for k in keys}
def calc(rows):return sum(f*D[a]*D[b] for (a,b),f in rows.items())
re_out=[]
for a,b,w in re:
    z=calc(cases[a,b])
    assert z>0
    re_out.append((a,b,w,z))
    if (a,b)==(174372786201,41302710654530):
        graphs,extra,_=projection(a,b,2)
        assert graphs==({(2,3,0):(2,2)},{(2,3,0):(2,2)})
        assert sum(profile(a)[2][(2,3,0)])==2 and (2,3,0) not in profile(b)[2]
        shortcut=calc(terms(a,b,scalar=True,reduced=(graphs,extra)))
        assert w==96 and z==F(8604807324297538165875,281474976710656)
        assert shortcut==F(1075580423607158602875,35184372088832)
        print("shared pilot",z,"shortcut",shortcut,"difference",z-shortcut,"orbit",z*w,flush=True)
t1=sum(w*z for a,b,w,z in re_out)
assert t1==F(860014394035274407282409403,562949953421312)
write("reduced-exact.tsv",re_out)
print("reduced configurations",len(keys),"overlap",dual,"weighted subtotal",t1,flush=True)
print("signed total",len(sc_out)+len(re_out),sum(w for a,b,w,z in sc_out+re_out),t0+t1,flush=True)
key=(174372786201,(((2,3),0),))
correct=value(*key,reverse=True);adverse=value(*key,mutant=3)
assert correct==F(38840955975,8388608) and adverse==F(7719180525,8388608)
print("reverse sign control",correct,"adverse",adverse)
