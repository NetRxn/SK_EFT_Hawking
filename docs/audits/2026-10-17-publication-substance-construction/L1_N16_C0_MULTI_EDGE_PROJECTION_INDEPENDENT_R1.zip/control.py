from collections import Counter
from fractions import Fraction as F
from itertools import combinations_with_replacement,product
from src.core.formulas import original_quaternion_haar_moment, original_spin4_link
from src.vestigial.original_coefficients import Polynomial, Symbol, matrix_multiply,matrix_dagger
from project import singlet

# Compare the fusion implementation with the necessary doubled-spin
# parity and polygon rules on the complete degree<=4 temporal inputs.
tested=0
for n in range(1,7):
    for spins in combinations_with_replacement(range(5),n):
        total=sum(spins)
        assert singlet(spins)==(total%2==0 and 2*max(spins)<=total)
        tested+=1
print("SU2 finite fusion and doubled-spin tests agree on",tested,"temporal rosters")

# Construct the diagonal adjoint coefficient directly from canonical U.
def adjoint33(site):
    vars=tuple(Symbol("q",(site,1,"L",i)) for i in range(4))
    U4=original_spin4_link(tuple(Polynomial.variable(s) for s in vars),(1,0,0,0))
    U=tuple(tuple(U4[i][j] for j in range(2)) for i in range(2))
    sigma=((1,0),(0,-1))
    p=matrix_multiply(matrix_multiply(matrix_multiply(sigma,U),sigma),matrix_dagger(U))
    R=(p[0][0]+p[1][1])*F(1,2)
    expected=sum((Polynomial.variable(s)*Polynomial.variable(s)*c for s,c in zip(vars,(1,-1,-1,1))),Polynomial())
    assert R==expected
    return vars,R

def expect(p):
    total=F(0)
    for key,z in p.terms:
        assert z.imag==0
        labels={s.index[:-1] for s in key}
        moment=F(1)
        for label in labels:
            e=Counter(s.index[-1] for s in key if s.index[:-1]==label)
            moment*=original_quaternion_haar_moment(tuple(e[i] for i in range(4)))
        total+=z.real*moment
    return total
A,RA=adjoint33((0,0,0,0))
B,RB=adjoint33((0,1,0,0))
values=tuple(Polynomial.variable(s) for s in A+B)
checked=0
for n in range(4):
    for terms in combinations_with_replacement(range(8),n):
        p=RA*RB
        for i in terms:p*=values[i]
        assert expect(p)==0
        checked+=1
z=expect(RA*RB*values[3]*values[3]*values[7]*values[7])
assert z==F(1,144)
print("actual directed anchor pair moment test",checked,"monomials below degree four zero; degree four",z)
