# Scoped independent acceptance

The replay verifies both projection families, all 512 exact signed values, the nonzero shared-Haar correction and the wedge-sign control. The 24 odd-root cases and larger temporal residual remain open in this receipt.
