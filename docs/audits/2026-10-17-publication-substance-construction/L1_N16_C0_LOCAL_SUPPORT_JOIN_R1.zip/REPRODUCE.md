# Local representation support join for the L1 dense profiles

Run `python3 local-configurations.py preflight source residual` and
`python3 count-local-join.py preflight source residual` with Python 3.
Both controls use the original enumerator to build exact local projections.
The 152-assignment profile is a reviewed numerical control. The
30,976-assignment dense profile is a support control whose numerical
coefficient remains open.

Every original support constraint is contained in at least one of the
actual edge, site or temporal factor scopes. A full supported assignment
therefore occurs in every local projection. Conversely, a consistent join
of projected rows satisfies each original constraint because one of its
local rows extends to a supported assignment for that entire constraint.
Singleton domains are held fixed. Identical Boolean relations may be used
once. Variable elimination counts the joined rows without materializing
the full join. The measured dense join reaches 352 intermediate rows.

The next numerical experiment must attach the local representation labels
to the original signed matrix factors, enforce equality on every repeated
label, and contract the representation labels with the physical indices.
The sign and original factorial normalization must be preserved. The
support-only intermediate bound does not estimate the signed matrix join,
and generating local projections here still uses the enumerator.
