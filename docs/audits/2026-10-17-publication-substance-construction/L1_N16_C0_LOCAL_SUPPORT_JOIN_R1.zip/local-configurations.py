from pathlib import Path
from itertools import product
from collections import Counter
from time import monotonic

source_text=Path('screen.py').read_text()
source_text=source_text[:source_text.index('root=Path(source)')]
source_text=source_text.replace(
    "return ('EXACT_SUPPORT',checked,len(states),maxspin,maxpower,tuple(forced))",
    'return states,checked',
)
exec(source_text)
CAP=65536
edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
for a,b,prior_count in [(155950118473,580896423965,152),(503841882182,1461451755920,30976)]:
    started=monotonic()
    states,nodes=solve_pilot(a,b)
    assert len(states)==prior_count
    names=sorted(states[0])
    assert len({tuple(st[k] for k in names) for st in states})==prior_count
    scopes={}
    for t in range(2):
        for u,v,k in edges:
            scopes['edge',t,u,v,k]=tuple((layer,x,k) for layer in range(2) for x in (u,v))
        for x in range(8):
            scopes['site',t,x]=tuple((layer,y,k) for layer in range(2) for k in range(3) for y in (x,x^(1<<k)))
            scopes['temporal',t,x]=tuple((t,y,k) for k in range(3) for y in (x,x^(1<<k)))
    totals=Counter()
    peaks=Counter()
    for key,scope in sorted(scopes.items()):
        unique=len({tuple(st.get(i,(0,0)) for i in scope) for st in states})
        family=key[0]
        totals[family]+=unique
        peaks[family]=max(peaks[family],unique)
        print(a,b,*key,'scope',len(scope),'configurations',unique)
    print('profile',a,b,'support',len(states),'nodes',nodes,'sum',dict(totals),'max',dict(peaks),
          'seconds',round(monotonic()-started,2),flush=True)
