from pathlib import Path
from itertools import product
from collections import Counter
from time import monotonic

source_text=Path('screen.py').read_text()
source_text=source_text[:source_text.index('root=Path(source)')]
source_text=source_text.replace(
    "return ('EXACT_SUPPORT',checked,len(states),maxspin,maxpower,tuple(forced))",
    'return states,checked',
)
source_text=source_text.replace('return states,checked','return states,checked,constraints')
exec(source_text)
CAP=65536
edges=[(u,u^(1<<k),k) for u in range(8) for k in range(3) if not u>>k&1]
for a,b,prior_count in [(155950118473,580896423965,152),(503841882182,1461451755920,30976)]:
    started=monotonic()
    states,nodes,constraints=solve_pilot(a,b)
    assert len(states)==prior_count
    names=sorted(states[0])
    assert len({tuple(st[k] for k in names) for st in states})==prior_count
    scopes={}
    for t in range(2):
        for u,v,k in edges:
            scopes['edge',t,u,v,k]=tuple((layer,x,k) for layer in range(2) for x in (u,v))
        for x in range(8):
            scopes['site',t,x]=tuple((layer,y,k) for layer in range(2) for k in range(3) for y in (x,x^(1<<k)))
            scopes['temporal',t,x]=tuple((t,y,k) for k in range(3) for y in (x,x^(1<<k)))
    families=[set(v) for v in scopes.values()]
    assert all(any(set(group)<=scope for scope in families) for _,_,group in constraints)
    domains={k:{st[k] for st in states} for k in names}
    active={k for k,v in domains.items() if len(v)>1}
    assert all(any(k in scope for scope in families) for k in active)
    relation_set=set()
    for group in families:
        names_here=tuple(sorted(group&active))
        if names_here:
            rows=frozenset(tuple(st[k] for k in names_here) for st in states)
            relation_set.add((names_here,rows))
    initial_relations=len(relation_set)
    relations=[(scope,{row:1 for row in rows}) for scope,rows in relation_set]
    peak=max(len(rows) for _,rows in relations)
    work=0
    def join(left,right):
        global work,peak
        ls,lr=left; rs,rr=right
        shared=tuple(k for k in ls if k in rs)
        li=[ls.index(k) for k in shared]
        ri=[rs.index(k) for k in shared]
        added=[i for i,k in enumerate(rs) if k not in ls]
        lookup={}
        for row,value in rr.items():
            lookup.setdefault(tuple(row[i] for i in ri),[]).append((row,value))
        out={}
        for row,value in lr.items():
            for rhs,count in lookup.get(tuple(row[i] for i in li),()):
                work+=1
                key=row+tuple(rhs[i] for i in added)
                assert key not in out and len(out)<100000
                out[key]=value*count
        peak=max(peak,len(out))
        return ls+tuple(rs[i] for i in added),out
    max_scope=0
    while active:
        scope_by_var={k:[(s,r) for s,r in relations if k in s] for k in active}
        var=min(active,key=lambda v:(len(set().union(*(s for s,_ in scope_by_var[v]))),v))
        local=sorted(scope_by_var[var],key=lambda f:(len(f[1]),f[0]))
        assert local
        joined=local[0]
        for relation in local[1:]:
            joined=join(joined,relation)
        axes,rows=joined
        max_scope=max(max_scope,len(axes))
        omit=axes.index(var)
        reduced={}
        for row,value in rows.items():
            key=row[:omit]+row[omit+1:]
            reduced[key]=reduced.get(key,0)+value
        relations=[(s,r) for s,r in relations if var not in s]
        relations.append((axes[:omit]+axes[omit+1:],reduced))
        active.remove(var)
    from math import prod
    assert all(not axes and set(rows)=={()} for axes,rows in relations)
    exact=prod(rows[()] for _,rows in relations)
    assert exact==prior_count
    print('profile',a,b,'constraints',len(constraints),'projection tables',initial_relations,
          'exact support',exact,'peak intermediate rows',peak,'max scope',max_scope,'matched joins',work,flush=True)
