"""Exact path/cycle environment for the remaining sixteen original exterior edges."""
from collections import Counter, defaultdict
from functools import cache
from itertools import product
from pathlib import Path
import json,sys

D=Path(__file__).parent
STAR=Path('/tmp/publication-c14-edge-site-r1.nyn1YR')
BATCH=Path('/tmp/publication-c14-s4-diagonal-r1.btrcpw')
sys.path.insert(0,str(STAR))
import cut

CHIRAL=((3,5,10,12),(48,80,160,192))
RANKS=(1,2,5,6,7,9,10,11,13,14,15)
BOUNDARY=RANKS[:-1]
FULL=(15,240)

def parity_word(seq):
    return (-1)**sum(x>y for i,x in enumerate(seq) for y in seq[i+1:])

def bits(m):
    return [i for i in range(8) if m>>i&1]

def cross(x,y):
    return (-1)**cut.crossing(x,y)

def integer_add(x,y):
    return cut.add((x,0),(y,0))[0]

def integer_mul(x,y):
    return cut.scale((x,0),y)[0]

def read(path):
    with path.open() as f:
        for s in f:
            cut.work('frozen_read')
            yield json.loads(s)

def source_row():
    return cut.roster()

def rank_edges(site):
    row=source_row()
    owners=cut.star_owners(row,site)
    out=[]
    for desc in owners[:2]:
        axis,n,frames,traces=desc
        assert n==({1:(9,5),2:(10,6)}[site][axis])
        assert frames==[('S4',n,0,axis),('S4',n,1,axis)] and not traces
        a,da,sa=cut.edge_tensor(desc,site,False)
        b,db,sb=cut.edge_tensor(desc,site,True)
        assert a==b and da==db==64 and sa==sb==16 and len(a)==48
        t={}
        for (m,n0,x,y),z in a.items():
            cut.work('rank12_diagonal_equal')
            assert x==y
            if (m,n0) in t:
                assert t[m,n0]==z
            else:
                cut.reserve('rank12_degree2',(m,n0),t)
                t[m,n0]=z
        assert len(t)==12
        out.append(t)
    return out

def rank_projection(site,tables):
    out={}
    for (k,z),(j,w) in product(tables[0].items(),tables[1].items()):
        cut.work('rank12_projection')
        m,r0=k
        n,r1=j
        if m&n:
            continue
        old=255^(m|n)
        key=(old,r0,r1)
        sign=cross(old,m)*cross(old|m,n)
        direct=parity_word(bits(old)+bits(m)+bits(n))
        assert sign==direct and old.bit_count()==4
        refword=[site*8+i for i in bits(old)+bits(m)+bits(n)]
        transposed=[site*8+1 if a==site*8 else site*8 if a==site*8+1 else a for a in refword]
        assert parity_word(transposed)==-sign
        cut.reserve('rank12_projection',key,out)
        out[key]=cut.add(out.get(key,(0,0)),cut.scale(cut.times(z,w),sign))
    out={k:z for k,z in out.items() if z!=(0,0)}
    cut.write_rows(f'rank{site}-projection.jsonl',out)
    return out

def geometry():
    g=json.loads((BATCH/'graph.json').read_text())
    arr=g['pending_exterior_edges']
    edges=[tuple(x['mask_order']) for x in arr]
    assert len(edges)==16 and len({tuple(sorted(e)) for e in edges})==16
    local=defaultdict(list)
    common=None
    for i,(u,v) in enumerate(edges):
        local[u].append(2*i)
        local[v].append(2*i+1)
        exact={}
        for (m,n),(r,s) in read(BATCH/arr[i]['file']):
            assert s==0 and r in (-16,8)
            exact[m,n]=r//8
        if common is None:
            common=exact
        assert exact==common
    assert set(local)==set(RANKS)
    return edges,local,common

def pair_signature(labels):
    # A physical site pairs exactly two masks within each chirality.
    # On ranks 1/2, the prior boundary mask contains two constituent
    # pairs. A wholly occupied prior chirality block needs no endpoint.
    partners={}
    fixed=[]
    for s in RANKS:
        cut.work('orientation_site')
        terms=LOCAL[s]
        groups=[[u for u in terms if labels[u]==h] for h in (0,1)]
        if s==15:
            if any(len(v)!=2 for v in groups):
                return None
        elif s in (1,2):
            if len(groups[0])==len(groups[1])==1:
                groups[0].append(32+2*s)
                groups[1].append(32+2*s+1)
            else:
                absent=0 if not groups[0] else 1
                fixed.append((s,FULL[absent]))
        else:
            if any(len(v) not in (1,2) for v in groups):
                return None
            missing=0 if len(groups[0])==1 else 1
            groups[missing].append(32+2*s+missing)
        for group in groups:
            if group:
                assert len(group)==2
                a,b=group
                partners[a]=b
                partners[b]=a
    return partners,tuple(fixed)

def neighbors(x,partner):
    if x>=32:
        return ((partner[x],'P'),)
    return ((partner[x],'P'),(x^1,'E'))

def components(labels,partner):
    todo=set(partner)
    paths=[]
    while todo:
        heads=todo&{u for u in partner if u>=32}
        x=min(heads or todo)
        root=x
        prev=None
        word=[]
        nodes=[x]
        while True:
            cut.work('component_walk')
            nxt=[(y,k) for y,k in neighbors(x,partner) if y!=prev]
            if not nxt:
                assert x>=32 and x!=root
                break
            y,k=nxt[0]
            word.append(k)
            if y==root:
                assert root<32
                break
            nodes.append(y)
            prev,x=x,y
        todo.difference_update(nodes)
        phases=tuple((u-32)%2 if u>=32 else labels[u] for u in nodes)
        if root>=32:
            end=nodes[-1]
            assert end>=32
            paths.append((root,end,phases,tuple(word)))
        else:
            paths.append((None,None,phases,tuple(word)))
    return paths

@cache
def kernel(phases,word,closed):
    # Exact four-state products. Physical edge numerators divided by
    # eight, while every on-site pairing enforces complement and sign.
    def trans(kind,x,y):
        if kind=='E':
            return COMMON.get((x,y),0)
        if x&y or (x|y) not in FULL:
            return 0
        return cross(x,y)
    rows={}
    for first in CHIRAL[phases[0]]:
        cur={first:1}
        for i,kind in enumerate(word):
            j=(i+1)%len(phases)
            nex={}
            for x,z in cur.items():
                for y in CHIRAL[phases[j]]:
                    cut.work('transfer_matrix')
                    value=trans(kind,x,y)
                    if not value:
                        continue
                    nex[y]=integer_add(nex.get(y,0),integer_mul(z,value))
            cur=nex
        if closed:
            rows[first]=cur.get(first,0)
        else:
            for last,z in cur.items():
                if z:
                    cut.reserve('cached_transfer',(first,last),rows)
                    rows[first,last]=z
    if closed:
        value=0
        for z in rows.values():
            value=integer_add(value,z)
        return value
    return rows

def encoded_endpoint(x):
    return ((x-32)//2,(x-32)%2)

def orientation(rows_file):
    valid=[]
    degrees=Counter()
    gross=0
    support_rows=0
    with rows_file.open('wb') as f:
        for mask in range(1<<len(EDGES)):
            cut.work('chirality_orientation')
            labels=tuple(((mask>>(u//2))&1)^(u%2) for u in range(2*len(EDGES)))
            ret=pair_signature(labels)
            if ret is None:
                continue
            partner,fixed=ret
            local=components(labels,partner)
            scalar=1
            paths=[]
            for a,b,phases,word in local:
                value=kernel(phases,word,a is None)
                if a is None:
                    scalar=integer_mul(scalar,value)
                else:
                    paths.append((encoded_endpoint(a),encoded_endpoint(b),value))
            degrees[len(paths)]+=1
            if not scalar or any(not x[2] for x in paths):
                continue
            rows=1
            for _,_,m in paths:
                rows*=len(m)
            gross+=rows
            support_rows+=sum(len(m) for _,_,m in paths)
            cut.reserve('orientation_record',mask,{})
            valid.append((mask,fixed,scalar,paths))
            serial=[mask,fixed,scalar,[(a,b,[[x,y,v] for (x,y),v in sorted(mat.items())])
                                     for a,b,mat in paths]]
            cut.emit(f,serial)
    return valid,dict(degrees),gross,support_rows

def compose_boundary(fixed,paths,pairs):
    out=dict(fixed)
    for (a,b,_),(ma,mb) in zip(paths,pairs,strict=True):
        for endpoint,m in ((a,ma),(b,mb)):
            s,h=endpoint
            assert m in CHIRAL[h] and not out.get(s,0)&m
            out[s]=out.get(s,0)|m
    assert set(out)==set(BOUNDARY)
    return tuple(out[s] for s in BOUNDARY)

def lookup_boundary(record,query):
    _,fixed,scalar,paths=record
    old=dict(zip(BOUNDARY,query,strict=True))
    if any(old[s]!=m for s,m in fixed):
        return 0
    value=scalar
    assigned=dict(fixed)
    for (s,h),(t,k),mat in paths:
        x=old[s]&FULL[h]
        y=old[t]&FULL[k]
        z=mat.get((x,y),0)
        if not z:
            return 0
        assigned[s]=assigned.get(s,0)|x
        assigned[t]=assigned.get(t,0)|y
        value=integer_mul(value,z)
    if any(assigned[s]!=m for s,m in old.items()):
        return 0
    return value

def literal_reference(query):
    # Separate complete route on fixed boundary: assign exact source
    # edges, reject overlaps immediately, retain the literal mask order
    # at each rank, and multiply original sign only after saturation.
    order=(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)
    initial=dict(zip(BOUNDARY,query,strict=True))
    words={s:bits(initial.get(s,0)) for s in RANKS}
    masks={s:initial.get(s,0) for s in RANKS}
    last={s:max(u//2 for u in LOCAL[s]) for s in RANKS}
    total=0
    paths=0
    def loop(i,coeff,sgn):
        nonlocal total,paths
        if i==len(order):
            assert all(v==255 for v in masks.values())
            total=integer_add(total,integer_mul(coeff,sgn))
            paths+=1
            return
        eid=order[i]
        a,b=EDGES[eid]
        for (m,n),z in COMMON.items():
            cut.work('literal_fixed_environment')
            if masks[a]&m or masks[b]&n:
                continue
            ma,mb=masks[a],masks[b]
            if i==last[a] and (ma|m)!=255 or i==last[b] and (mb|n)!=255:
                continue
            wa,wb=words[a],words[b]
            masks[a],masks[b]=ma|m,mb|n
            words[a],words[b]=wa+bits(m),wb+bits(n)
            sign=sgn
            if i==last[a]:
                sign*=parity_word(words[a])
            if i==last[b]:
                sign*=parity_word(words[b])
            loop(i+1,integer_mul(coeff,z),sign)
            masks[a],masks[b]=ma,mb
            words[a],words[b]=wa,wb
    loop(0,1,1)
    return total,paths

def fixed_controls(records):
    controls=[]
    seen=set()
    for _,fixed,_,paths in records:
        pair_choices=[sorted(mat) for _,_,mat in paths]
        for p in product(*pair_choices):
            cut.work('propose_environment_control')
            q=compose_boundary(fixed,paths,p)
            if q in seen:
                continue
            cut.reserve('fixed_control_seen',q,seen)
            seen.add(q)
            total=0
            for r in records:
                cut.work('factored_fixed_environment')
                total=integer_add(total,lookup_boundary(r,q))
            if not total:
                continue
            direct,terms=literal_reference(q)
            assert direct==total and terms
            cut.reserve('control_result',len(controls),{})
            controls.append(dict(boundary=q,normalized_numerator=total,
                    exact_literal_paths=terms,wrong_single_site_top_orientation=-total,
                    denominator=8**16))
            print('environment control',len(controls),total,terms,flush=True)
            if len(controls)==3:
                return controls
    raise AssertionError(('environment controls',len(controls)))

def main():
    global EDGES,LOCAL,COMMON
    cut.OUT=D
    cut.ROW_CAP=120_000
    cut.rss()
    EDGES,LOCAL,COMMON=geometry()
    p=[rank_projection(s,rank_edges(s)) for s in (1,2)]
    print('rank1/rank2 projections',[len(x) for x in p],flush=True)
    data,degrees,gross,support=orientation(D/'exterior-orientations.jsonl')
    print('orientation factorization',len(data),gross,support,flush=True)
    controls=fixed_controls(data)
    cut.rss()
    out=dict(edges=EDGES,boundary_order=BOUNDARY,orientation_bit_definition='1 gives high chirality at listed endpoint 0; other endpoint opposite',
        rank1_rank2_projection_rows=list(map(len,p)),all_chirality_orientations=1<<len(EDGES),
        valid_chirality_orientation_path_count_histogram=degrees,nonzero_orientations=len(data),
        serialized_path_transfer_rows=support,flat_path_term_visits_before_boundary_coalescence=gross,
        local_edge_normalized_denominator=8,environment_denominator=8**16,
        controls=controls,charged_operations=dict(cut.WORK),storage=dict(cut.STORE),
        rss_peak_bytes=cut.RSS_PEAK,cap=dict(rows=cut.ROW_CAP,work=cut.WORK_CAP,
             accounted_bytes=cut.BYTE_CAP,serialized_bytes=cut.FILE_CAP,
             sampled_rss=cut.RSS_CEILING,scalar=cut.INT_LIMIT))
    (D/'result.json').write_text(json.dumps(out,indent=2)+'\n')
    print('bounded exact environment complete',flush=True)

if __name__=='__main__':
    main()
