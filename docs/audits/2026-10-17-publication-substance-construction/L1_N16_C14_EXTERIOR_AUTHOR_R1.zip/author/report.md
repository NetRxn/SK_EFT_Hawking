# Original N16 c14 exact signed exterior environment

The pinned source is original periodic closed source_C at clean primary
27012c18fa374e8341e124b510abbedeedb18d29. This result uses the
zero-centered (01,01,23,23) representative. The local raw rank-1
and rank-2 evidence is independent of the earlier diagonal batch.
The sewn graph uses that batch after its independent review.

## Exact rank-1 and rank-2 projections

Rank 1 receives its last two paired coframes from ranks 9 and 5
on axes 0 and 1. Rank 2 receives its last two from ranks 10 and 6
on those axes. These four degree-two tables were independently
re-extracted from original source. The canonical tables match
raw signed quarter increments and independent exact Haar moments.
Each projection closes its two new pairs against the old fused
four-generator mask and keeps the two remote masks. Each has
84 nonzero rows at denominator 4,096 in the original edge units.
Every sign agrees with literal rank-local ordering. Transposing
the first two generators reverses the sign of each admissible
site projection.

## Whole pending exterior network

The sixteen pending degree-two edge tables share the same exact
12-row exterior factor. We divide their numerators by eight,
so each edge now has denominator eight and numerators -2 or +1.
Each edge contributes one two-generator pair of opposite
chirality at its two endpoints. At each final site there must
be two pairs of each chirality and they must be complementary.
A four-generator old mask at ranks 1 or 2 is either the fixed
full complement of the two same-chirality pending pairs or the
union of two old opposite-chirality pair slots. Every other
boundary site has one old pair and rank 15 has none.

Enumerating the 65,536 chirality orientations gives exactly
2,604 admissible orientations. Within each, connect the
two same-chirality pairs at each site and connect the two
endpoints of each physical edge. This separates the constraint
graph into paths and cycles. Crossings of entire even pairs
at different sites and between the two chiralities have even
sign. The local signed complement factors give all remaining
Grassmann signs. Cycles become exact scalar coefficients and
paths become exact signed transfer matrices on their two
boundary mask slots. The frozen orientation file contains
the complete sum of these factored records.

An independent closed-form check reproduces all orientations
and all transfers. For a path with e physical edges, the
two type-A complement rows have weight (-2)^e. The four
type-B rows have weight (-1)^(e+1) times 2^(e-1). An alternating
cycle with e physical edges gives 3 times (-2)^e. The identity
follows because each type-A transition flips the mode with
one nonzero value, whereas each type-B edge is the two-by-two
all-ones matrix. Each type-B on-site complement contributes
a sign of -1. The independent readback reconstructs every
component by incidence, without multiplying the author transfer
matrices. There are 588 four-path, 1,296 five-path, and 720
six-path orientation records, totaling 78,912 stored path rows.

Three complete fixed-boundary environment coefficients agree
with literal exhaustive source-edge traversal using the actual
local generator orders. Their normalized integer numerators
are 196,608, -98,304, and -98,304 at denominator 8^16. The
literal route finds 66, 132 and 132 accepted exterior assignments.
Reversing a single site's top orientation changes each overall
sign. These controls fix the full ten-mask boundary and sum
only the pending exterior environment, rather than the
original core-to-environment scalar.

## Admission and next step

The exact environment run charged 615,373 visits against
4,000,000 and 7,298 cumulative instrumented rows against
120,000. It used 3,736,576 accounting bytes against 64 MiB
and 1,128,686 serialized bytes against 4 MiB. Process RSS
sampled during execution peaked at 110,215,168 bytes under
the sampled 384 MiB guard. Arithmetic uses prospective
checked integer bounds. Source initialization, indexing
and runtime overhead, separate readback and documentation
are outside the table meters. The memory guard is sampled.

A flat exterior-only expansion before boundary coalescence
would visit 44,432,064 terms. The first prospective refusal
in orientation order is 4,037,040 visits at orientation
13,986 against the 4,000,000 cap. No flat expansion ran.
The combined graph now specifies every factor of this
representative, with its original 512 divisor and the
pure-S4 numerator multiplier applied once. The coefficient
sum over ten shared core/environment masks has not run.
Project the actual core pair-mask relations into the paths
before selecting a joined schedule, and admit only under a
fresh bounded size and arithmetic preflight.

The representative value, the two other axis arrangements,
c14, c0, complete denominator and normalization remain open.
