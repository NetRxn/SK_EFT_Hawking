"""Independent all-orientation path/cycle check using closed transfer formulas."""
from collections import Counter,defaultdict
from pathlib import Path
import json

D=Path(__file__).parent
BATCH=Path('/tmp/publication-c14-s4-diagonal-r1.btrcpw')
edges=[tuple(t['mask_order']) for t in json.loads((BATCH/'graph.json').read_text())['pending_exterior_edges']]
atoms=((3,5,10,12),(48,80,160,192))
inc=defaultdict(list)
for i,(a,b) in enumerate(edges):
    inc[a].append((i,0))
    inc[b].append((i,1))

def expected(mask):
    adj=defaultdict(set)
    boundary={}
    fixed={}
    for site,terms in inc.items():
        q=defaultdict(list)
        for i,j in terms:
            hand=((mask>>i)&1)^j
            q[hand].append((i,j))
        if site==15:
            if len(q[0])!=2 or len(q[1])!=2:
                return None
        elif site in (1,2):
            if not q[0] or not q[1]:
                fixed[site]=15 if not q[0] else 240
        elif not q[0] or not q[1]:
            return None
        for h,g in q.items():
            if not g:
                continue
            if len(g)==1:
                x=(16+site,h)
                boundary[x]=(site,h)
                g.append(x)
            a,b=g
            adj[a].add(b)
            adj[b].add(a)
    for i in range(len(edges)):
        adj[i,0].add((i,1))
        adj[i,1].add((i,0))
    seen=set()
    paths={}
    scalar=1
    for x in adj:
        if x in seen:
            continue
        comp={x}
        pending=[x]
        while pending:
            y=pending.pop()
            extra=adj[y]-comp
            comp.update(extra)
            pending.extend(extra)
        seen.update(comp)
        e=sum(i<16 for i,j in comp)//2
        terminals=sorted(boundary[y] for y in comp if y in boundary)
        if not terminals:
            scalar*=3*(-2)**e
            continue
        assert len(terminals)==2 and e
        a,b=terminals
        x,y=atoms[a[1]],atoms[b[1]]
        matrix={(x[0],y[3]):(-2)**e,(x[3],y[0]):(-2)**e}
        z=(-1)**(e+1)*2**(e-1)
        matrix.update({(m,n):z for m in x[1:3] for n in y[1:3]})
        paths[a,b]=matrix
    return fixed,scalar,paths

with (D/'exterior-orientations.jsonl').open() as f:
    actual={}
    for line in f:
        mask,fixed,scalar,paths=json.loads(line)
        assert mask not in actual
        actual[mask]=(dict(fixed),scalar,{(tuple(a),tuple(b)):{(m,n):z for m,n,z in v} for a,b,v in paths})
seen=Counter()
gross=0
for mask in range(1<<len(edges)):
    ref=expected(mask)
    if ref is None:
        assert mask not in actual
        continue
    assert actual[mask]==ref
    seen[len(ref[2])]+=1
    gross+=6**len(ref[2])
print(json.dumps(dict(orientations=len(actual),path_count_histogram=dict(sorted(seen.items())),
                      gross_path_terms=gross,formula='A: two complement rows (-2)^e; B: four rows (-1)^(e+1)2^(e-1); cycle: 3(-2)^e'),indent=2))
