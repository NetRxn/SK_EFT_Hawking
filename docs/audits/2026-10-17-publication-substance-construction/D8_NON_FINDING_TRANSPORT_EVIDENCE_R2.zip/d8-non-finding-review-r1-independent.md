# D8 1.7 independent donor transport review R1

**HOLD.** The exact candidate fixes the reproduced D8 corpus defect and
preserves the current review graph outside the intended removals. Its
marker conflict guard still suppresses sections with two malformed
action declarations. The donor specification explicitly requires
malformed severity and verification declarations to conflict.

## Exact review

I independently archived the review corpus and relevant source paths
from clean delivery base `3f9461f0f2d1f4ba3edb433ceedebf28d3cdaa18`.
The author donor patch is byte-identical to the Git diff of
`f55b853888b017509d11156a01270a8dd04d48be`. Both patches applied cleanly.
First and final continuity receipts are byte-identical and fresh.

I read the marker-bearing historical sections and their surrounding
review material. All 25 selected sections report passed checks,
inapplicable gates or prior remediation recaps. L2 contributes three
such sections, D8 contributes eight and D11 contributes fourteen.
The D8 rerun's resolved entries summarize the older real findings.
Those older findings remain separate records. Several final sections
precede QI or closing summary material, which remains in the review
documents. The patch only adds the section-local comment markers there.

I independently extracted both corpora through the actual parser.
The population went from 1,842 to 1,817, with exactly the intended
25 IDs removed and zero IDs added. All 1,817 retained node records
and all seven active blocked-by edges were equal. Ledger bytes,
59 pre-existing dangling finding IDs and 29 pre-existing dangling
supersession targets were equal. The two fixed historical May D8
findings were retained. D8 1.7 remained open and major.

I extracted the amended Verify from the canonical finding and ran it
with PYTHONPATH unset. It exited 1 on the original parser and reported
all eight exact artifact IDs. It exited 0 on the donor parser and
retained all nine required real IDs. Changing the original May D8
1.2 heading so it was no longer parseable made the same Verify exit 1,
reporting exactly the lost actionable ID and no reminted artifacts.
The donor synthetic test also fails on the original parser and passes
on the donor parser. The amended command uses dense shell quoting to
embed Python with newlines. I found no execution or preservation
problem with that exact command. It retains the previous five-open
threshold as historical evidence and measures the reproduced defect.

## Adverse finding

In a fresh synthetic review, two marked, numbered sections ended with
the standalone strings `- **Severity**` and `- **Verify**`. Both nodes
were silently dropped. The existing conflict regex requires a colon
and the existing field parser requires a nonempty value. The same
probe retained filled colon-bearing fields, a filled colonless Verify
and an empty colon-bearing Severity. Thus the current guard is
conservative for those shapes but fails to flag the delimiter-free
empty action declarations.

The recorded corpus differential has no actionable losses. The new
adverse control demonstrates a gap in the proposed general marker
contract. Recognize standalone action labels even when both delimiter
and value are absent, add the two exact fail-closed controls and
replay the current-corpus differential. R1 has no integration or
canonical closure acceptance.

## Review evidence

Scratch directory `/tmp/d8-non-finding-independent-r1.PRBivK` holds
the independent replay and comparison, lost-actionable graph,
synthetic parser test receipts, and `conflict-independent.py` and
`conflict-independent.log`. The repository and ledger were read only.
