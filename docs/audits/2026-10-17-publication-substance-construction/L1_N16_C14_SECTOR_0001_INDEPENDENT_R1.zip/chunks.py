from collections import defaultdict
from fractions import Fraction as Q
from functools import cache
from itertools import product
from math import gcd,prod
from pathlib import Path
import json,sys
import numpy as np
A=Path(sys.argv[1])
C=Path('/tmp/publication-c14-core-sewing-r1.P8b5DO')
def rows(f):
    for line in f.open():yield json.loads(line)
def f(x):return tuple(map(f,x)) if isinstance(x,(tuple,list)) else x
def add(z,w):return z[0]+w[0],z[1]+w[1]
def mul(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def pair(z):
    a,b,c,d=z
    return Q(a,b),Q(c,d)
raw={};trace={}
for name,labels,tab in rows(A/'interior-rays.jsonl'):
    if name.startswith('trace'):trace[name]=(labels,{tuple(k):tuple(z) for k,z in tab})
    else:raw[name]=(labels,{j:{tuple(k):tuple(z) for k,z in v} for j,v in tab})
M={tuple(k):v for k,v in rows(A/'weighted-mask-amplitude-0001.jsonl')}
assert len(M)==832
basis={};middles={}
for record in rows(A/'spoke-bases.jsonl'):
    name=record['name']
    cl=defaultdict(dict);rr=defaultdict(dict)
    for i,k,z in record['column']:cl[k][i]=pair(z)
    for k,i,z in record['row']:rr[k][i]=pair(z)
    mid={int(k):{(i,j):pair(z) for i,j,z in v} for k,v in record['coordinates'].items()}
    basis[name]=(cl,rr);middles[name]=mid
    assert len(cl)==10 and len(rr)==(16 if name in 'AB' else 10) and len(mid)==(16 if name in 'AB' else 11)
    # Recover complete matrices by fixed entry dot products, exact Gaussian rationals.
    for j,source in raw[name][1].items():
        result={}
        for u,v in product(range(16),repeat=2):
            value=(0,0)
            for (i,k),z in mid[j].items():
                value=add(value,mul(mul(cl[i].get(u,(0,0)),z),rr[k].get(v,(0,0))))
            a,b=divmod(u,4); c,d=divmod(v,4)
            key=(c,d,a,b) if name in 'CD' else (a,b,c,d)
            if any(value):result[key]=value
        assert result==source
print('all 54 exact Gaussian spoke matrices reconstructed entry-by-entry',flush=True)
selected=[set(),set()]
middletuples={}
for k in M:
    a,b,c,d,e,f0=k
    terms=list(product(*(middles[n][v].items() for n,v in zip('ABCD',(a,b,c,d),strict=True))))
    middletuples[k]=terms
    for v in terms:
        selected[0].add((e,*(i for (i,j),z in v)))
        selected[1].add((f0,*(j for (i,j),z in v)))
assert sum(map(len,middletuples.values()))==168192
expected=json.loads((A/'selected-basis-keys.json').read_text())
assert selected==[set(map(tuple,expected[k])) for k in ('left','right')]

coords=[
 (('a1_0','a0_0','q02_0','q03_0'),('a1_1','a0_1','q02_1','q03_1'),('q23_0','q12_0'),('q23_1','q12_1')),
 (('q01_2','q00_2','a2_2','a3_2'),('q01_3','q00_3','a2_3','a3_3'),('q40_2','q81_2'),('q40_3','q81_3'))]
def tensor(which,j):
    name=f'trace{2*which+j}'
    labels,table=trace[name]
    k=[labels.index(a) for a in coords[which][j]+coords[which][2+j]]
    ans=np.zeros((2,4,4,4,4,16),dtype=np.int64)
    for a,z in table.items():
        x,b,c,d,e,f0=(a[i] for i in k)
        ans[:,x,b,c,d,4*e+f0]=z
    return ans
def matrix(n,which,i):
    z=np.zeros((2,4,4),dtype=np.int64)
    for idx,t in basis[n][which][i].items():
        assert all(a.denominator==1 for a in t)
        r,c=divmod(idx,4)
        z[:,r,c]=list(map(int,t))
    return z
def split_bound(a):
    return sum(int(np.max(np.abs(i))) for i in a)
max_bound=0
@cache
def transform(which,ix):
    # Apply each 4×4 Gaussian basis matrix as a separate tensor mode,
    # then contract with the complete second source trace in one exact
    # 16×256 by 256×16 integer matrix product.
    global max_bound
    u=tensor(which,0)
    v=tensor(which,1).reshape(2,256,16)
    bound=split_bound(u)
    for axis,(name,key) in enumerate(zip('ABCD',ix,strict=True)):
        z=matrix(name,which,key)
        bound*=4*split_bound(z)
        assert bound<2**63
        F=lambda a,b:np.moveaxis(np.tensordot(a,b,axes=(axis,0)),-1,axis)
        re=F(u[0],z[0])-F(u[1],z[1])
        im=F(u[0],z[1])+F(u[1],z[0])
        u=np.stack((re,im))
    u=u.reshape(2,256,16)
    bound*=256*split_bound(v)
    max_bound=max(max_bound,bound)
    assert bound<2**63
    return np.stack((u[0].T@v[0]-u[1].T@v[1],u[0].T@v[1]+u[1].T@v[0]))
from collections import Counter
res=json.loads((A/'q-result.json').read_text())
counts=[]
chunks=[]
max_bucket=[]
total_first=0
projection=0
matched_pairs=0
for side in (0,1):
    def source_prefix(j):
        labels,tab=trace[f'trace{side*2+j}']
        pos=[labels.index(k) for k in coords[side][j]]
        return [tuple(k[i] for i in pos) for k in tab]
    first=source_prefix(0)
    second=Counter(source_prefix(1))
    max_bucket.append(max(second.values()))
    active=defaultdict(list)
    for e,*ix in selected[side]:active[tuple(ix)].append(e)
    n0=0
    btot=atot=cnt=0
    for ix,es in sorted(active.items()):
        states=[]
        for n,i in zip('ABCD',ix,strict=True):
            opts=defaultdict(list)
            for entry,z in basis[n][side][i].items():
                a,b=divmod(entry,4)
                assert any(z)
                opts[a].append(b)
            states.append(opts)
        candidates=0
        paired=0
        for a in first:
            choices=[v[q] for v,q in zip(states,a,strict=True)]
            candidates+=prod(map(len,choices))
            paired+=sum(second[b] for b in product(*choices))
        pr=sum(len(raw['EF'[side]][1][e]) for e in es)
        predicted=len(first)+candidates*(1+max_bucket[-1])+pr
        actual=len(first)+candidates+paired+pr
        assert actual<=predicted<=4_000_000
        if btot+predicted>4_000_000:
            chunks.append(dict(side=('left','right')[side],basis_tuples=cnt,prospective_bound=btot,actual_work=atot))
            btot=atot=cnt=0
        btot+=predicted;atot+=actual;cnt+=1
        n0+=candidates
        total_first+=len(first); projection+=pr; matched_pairs+=paired
    chunks.append(dict(side=('left','right')[side],basis_tuples=cnt,prospective_bound=btot,actual_work=atot))
    counts.append(n0)
assert chunks==res['transform_chunks']
assert counts==[560896,3096576] and max_bucket==[4,4]
assert (total_first,projection,matched_pairs)==(1688064,160160,11725824)
assert sum(c['actual_work'] for c in chunks)==total_first+projection+matched_pairs+sum(counts)
agg=json.loads((A/'q-admission.json').read_text())
pre=10+4+832+sum(len(t[1]) for t in trace.values())+total_first
formula=pre+total_first+sum(c*(1+max_bucket[i])+max(map(len,raw['EF'[i]][1].values()))*len(selected[i]) for i,c in enumerate(counts))+sum(map(len,middletuples.values()))
assert formula==agg['prospective_worst_case']==22067214
assert sum(res['work'].values())==res['total_work']==19091694
assert pre+sum(x['actual_work'] for x in chunks)+168192==res['total_work']
assert 22067214<res['caps']['work']==24000000
assert res['per_chunk_cap']==4000000
print('all six independent chunk predictions/visits and aggregate receipts exactly match',chunks,flush=True)
