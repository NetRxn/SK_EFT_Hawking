from pathlib import Path
import sys,json
a=Path(sys.argv[1])
def rd(n):return json.loads((a/n).read_text())
s=rd('separation.json'); m=rd('mask-numeric.json'); q=rd('q-result.json')
assert s['mask_join']['previous']+s['mask_join']['exact_pair_visits']+s['mask_join']['environment_visits']>4_000_000
assert '4000001, 4000000' in (a/'separation-unindexed.log').read_text().splitlines()[-1]
assert '22067214, 4000000' in (a/'qcontract-initial-refusal.log').read_text().splitlines()[-1]
assert rd('q-admission-initial-refusal.json')['prospective_worst_case']==22067214
assert sum(s['work'].values())==1286560 and s['sampled_peak_rss_bytes']==78921728
assert sum(m['work'].values())==m['meters']['work']==3765980 and m['sampled_peak_rss_bytes']==33128448
assert m['meters']['output']==(a/'weighted-mask-amplitude-0001.jsonl').stat().st_size==38320
assert q['sampled_peak_rss']==24444928 and q['caps']['scalar']==2**127-1
for i in range(2):
    r=rd(f'raw-control-{i}.json')
    assert sum(r['operations'].values())==r['charged']==2063690<r['cap']==4000000
assert not q['other_sectors_evaluated'] and not q['full_representative_evaluated']
print('masked numeric/transform/literal refusal and cap receipts verified')
