from pathlib import Path
import json,sys
p=Path(sys.argv[1])
mod=65537
def rank(rows):
    pivots={}
    for u in rows:
        v=[x%mod for x in u]
        for i,z in sorted(pivots.items()):
            t=v[i]
            if t:v=[(x-t*y)%mod for x,y in zip(v,z,strict=True)]
        j=next((i for i,z in enumerate(v) if z),None)
        if j is not None:
            a=pow(v[j],-1,mod)
            pivots[j]=[(x*a)%mod for x in v]
    return len(pivots)
for name,l,tab in map(json.loads,(p/'interior-rays.jsonl').read_text().splitlines()):
    if name not in 'ABCD':continue
    all_rows=[];all_cols=[]
    for j,src in tab:
        m=[[0]*16 for _ in range(16)]
        for (a,b,c,d),(u,v) in src:
            x,y=4*a+b,4*c+d
            if name in 'CD':x,y=y,x
            m[x][y]=u+256*v
        all_rows+=m
        all_cols+=list(zip(*m))
    r,c=rank(all_rows),rank(all_cols)
    assert (c,r)==(10,16 if name in 'AB' else 10)
    print(name,'modular lower bounds equal reconstructed basis upper bounds',c,r)
