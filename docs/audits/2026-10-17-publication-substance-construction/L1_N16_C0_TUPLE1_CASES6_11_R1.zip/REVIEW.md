# Dense tuple 1 shared-child cases 6–11 independent exact review

The six independently replayed terms give exact subtotal **-180163826359165663080885 / 2596148429267413814265248164610048 + 0i**. Each case retains its own cut, saved checkpoint and signed scalar receipt, including pairs with equal values.

| Case | Coordinate | Exact normalized real | Imaginary |
| --- | --- | --- | --- |
| 6 | (65, (3,)) | 609323863463183052963/2596148429267413814265248164610048 | 0 |
| 7 | (66, (3,)) | -24119929540280486149875/1298074214633706907132624082305024 | 0 |
| 8 | (68, (3,)) | -24119929540280486149875/1298074214633706907132624082305024 | 0 |
| 9 | (72, (3,)) | 609323863463183052963/2596148429267413814265248164610048 | 0 |
| 10 | (129, (3,)) | -84902755924970084587311/5192296858534827628530496329220096 | 0 |
| 11 | (136, (3,)) | -84902755924970084587311/5192296858534827628530496329220096 | 0 |

At checkpoint 31e39aa98b747190462cf4f9b0f78a318b9f1618, the original separator archive pins the six-factor tuple1-0b parent to uncompressed SHA256 843afafdb587449cda97dcc3eeaf899cd02ff4776fcc23abcc8cf9eab6af7077. Independent support matching on parent pair (0, 1) recovers the 36 supported coordinates on G(0,0,2) and J(1,4,2), with 6,838,272 compatible products. All six stated coordinates have 142,464 compatible products each. The census and order match all six author records. Each inverse lift recovers its full restricted parent tables, signed coefficients and denominators.

The independent lineage code reconstructs the first reductions, all completed preliminary joins, the exact state preserved at each row-cap refusal and all six rescued terminal inputs. Cases 6 and 9 reach the refusal after 34,488 completed products and forecast 2,536,320 for the next join. Cases 7 and 8 reach it after 1,800,648 completed products with forecast 2,557,632. Cases 10 and 11 reach it after 34,488 completed products and forecast 2,657,280. Each raw cut hash and each rescue hash is unique within the batch. The common roster and all six lineages took 39.56 seconds.

Independent terminal arithmetic uses ordinary sparse Gaussian-integer joins from each case's own rescued frontier. These replays use neither author quotient routines nor peer projections. Cases 6 and 9 use 9,011,712 products each, cases 7 and 8 use 512,496 each, and cases 10 and 11 use 9,246,720 each. The largest retained output is 238,464 rows. Replay times in case order are 7.22, 0.47, 0.46, 7.33, 7.19 and 7.09 seconds. The raw numerators and denominators are retained in the per-case logs. The exact rationals apply the factor-denominator product and positive external scale 1/(16*4^64) once, with both real and imaginary components preserved.

The committed child equality binds both coarse siblings to this shared 36-case contraction. This review covers the six named terms in dense group 128 descendant (0, 0). The full child and full tuple still require recombination.

Keep the relative inputs/ and replays/ directories with the evidence. Restore separator.zip and child-equality.zip from the committed objects identified in SOURCE_PINS.txt. Run shasum -a 256 -c frozen-inputs.sha256, python3 verify-lineage.py, sh replay-terminals.sh 6 7 8 9 10 11 and python3 verify-aggregate.py. The supplied input and review manifests use relative paths.
