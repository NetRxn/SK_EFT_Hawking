# Shared tuple 1 child cases 6–11

Restore separator.zip and child-equality.zip from the Git blobs pinned in
SOURCE_PINS.txt. Run `sh rehydrate.sh` on a fresh extraction to regenerate
the 60 pinned author inputs. Use trusted original inputs for deserialization.
Follow REVIEW.md for the independent lineage and terminal replays.

Verify preceding-six.tsv against six-term-retally.tsv from the tracked
L1_N16_C0_TUPLE1_CASES2_5_R1.zip. Run `python3 retally-twelve.py` for
the exact twelve-term partial sum of one shared child. The factor of two
applies only at recombination of the complete tuple contribution.
