from ast import literal_eval
from collections import Counter
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads
from zipfile import ZipFile

from exact_factors import DEN, read, groups, overlap, reduce_factors, prune, combine, quotient, proj

case_root = Path('inputs')
indices=(6,7,8,9,10,11)
expected_slots = {6:(65,(3,)),7:(66,(3,)),8:(68,(3,)),9:(72,(3,)),10:(129,(3,)),11:(136,(3,))}
parent = read('separator.zip','row-cap-physical-slice-dense-label-tuple1-0b-reduced.pkl')
assert parent['conditioning'][-1] == (('R',0,3,0,1,0),0)
assert parent['label_partition']['index'] == 1
factors = parent['factors']
assert len(factors)==6
assert set(Counter(w for axes,_,_ in factors for w in axes).values())=={2}
assert parent['rejected_pair']==(0,1)
left,right=factors[:2]
roster=(case_root/'6/input.roster').read_bytes()
assert all((case_root/str(i)/'input.roster').read_bytes()==roster for i in indices)
cut_axes, table=literal_eval(roster.decode())
assert cut_axes == (('G',0,0,2),('J',1,4,2))
shared=overlap(left[0],right[0])
B=groups(right,shared)
join_key=proj(left[0],shared)
cut_key=proj(left[0],cut_axes)
spectrum=Counter()
for row in left[1]:
    multiplicity=len(B.get(join_key(row),()))
    if multiplicity:
        spectrum[cut_key(row)] += multiplicity
assert len(table)==len(spectrum)==36 and spectrum==dict(table)
assert sum(spectrum.values())==parent['matched']==6838272
order=sorted(spectrum,key=lambda k:(spectrum[k],k))
assert {i:order[i] for i in indices}==expected_slots
print('PASS complete 36-case roster',sum(spectrum.values()),'minimum',min(spectrum.values()),
      'maximum',max(spectrum.values()),'SHA256',sha256(roster).hexdigest(),flush=True)
with ZipFile('child-equality.zip') as equality:
    receipt=equality.read('verify.out')
    assert receipt.endswith(b'PASS identical signed six-factor contractions and normalization; disjoint full tuple1 contraction is 2 x either child\n')
    print('PASS committed child equality receipt SHA256',sha256(receipt).hexdigest(),flush=True)

def check_case(i):
    author=case_root/str(i)
    case=order[i]
    count=spectrum[case]
    assert count==142464
    fixed=dict(zip(cut_axes,case,strict=True))
    conditions=parent['conditioning']+list(fixed.items())

    def state(name):
        raw=(author/name).read_bytes()
        obj=loads(raw)
        rows=sum(len(r) for _,r,_ in obj['factors'])
        print('checkpoint',i,name,'SHA256',sha256(raw).hexdigest(),'rows',rows,flush=True)
        assert obj['conditioning']==conditions and obj['label_partition']==parent['label_partition']
        assert obj['physical_cut']==parent['physical_cut']
        assert prod(d for _,_,d in obj['factors'])==DEN
        return obj

    cut=state('input.pkl')
    for (axes,rows,d),(out,small,e) in zip(factors,cut['factors'],strict=True):
        assert d==e and out==tuple(w for w in axes if w not in fixed)
        recovered={}
        for row,z in small.items():
            lookup=dict(zip(out,row,strict=True)) | fixed
            recovered[tuple(lookup[w] for w in axes)]=z
        expected={row:z for row,z in rows.items() if all(row[j]==fixed[w] for j,w in enumerate(axes) if w in fixed)}
        assert recovered==expected
    cut_rows=sum(len(r) for _,r,_ in cut['factors'])
    assert (author/'plan.out').read_text().splitlines()[-1]==f'pilot {case!r} matched {count} stored rows {cut_rows}'
    print('PASS case',i,case,'cut rows and inverse lifts',cut_rows,flush=True)

    working=list(cut['factors'])
    reduce_factors(working)
    assert state('label-primary-reduced-frontier.pkl')['factors']==working
    prune(working)
    prune(working)
    two_joins=i in (7,8)
    stages=[(0,3,24264,14616),(2,3,1776384,145152)] if two_joins else [(0,3,34488,20952)]
    products=0
    for a,b,expected_products,expected_rows in stages:
        if expected_products>50_000:
            assert quotient(working,a,b)+quotient(working,b,a)==0
        left,right=working[a],working[b]
        shared=overlap(left[0],right[0])
        outside=tuple(w for w in left[0]+right[0] if w not in shared)
        remaining=[f for j,f in enumerate(working) if j not in (a,b)]
        checks=[]
        if expected_products>250_000:
            for axes,rows,_ in remaining:
                edge=overlap(axes,outside)
                if edge:
                    checks.append((proj(outside,edge),set(map(proj(axes,edge),rows))))
        joined,n=combine(left,right,lambda row: all(key(row) in allowed for key,allowed in checks))
        assert (n,len(joined[1]))==(expected_products,expected_rows)
        products+=n
        working=remaining+[joined]
        prune(working,len(working)-1)
    assert quotient(working,0,1)+quotient(working,1,0)==0
    cap=state('row-cap-physical-slice-dense-label-primary-reduced.pkl')
    assert cap['used_before']==products and cap['rejected_pair']==(0,1)
    assert working==cap['factors']
    ap,bp=working[:2]
    shared=overlap(ap[0],bp[0])
    A,B=groups(ap,shared),groups(bp,shared)
    forecast=sum(len(A[k])*len(B[k]) for k in A.keys() & B.keys())
    assert forecast==cap['matched']=={6:2536320,7:2557632,8:2557632,9:2536320,10:2657280,11:2657280}[i]
    assert (author/'contract.out').read_text().splitlines()[-1]==f'open row cap {len(working)} {forecast} frontier saved'
    print('PASS case',i,'row-cap lineage, completed products',products,'refused forecast',forecast,flush=True)
    reduce_factors(working)
    assert state('label-rescue-reduced-frontier.pkl')['factors']==working
    print('PASS case',i,'terminal checkpoint fully reproduced from pinned cut',flush=True)

for i in indices:
    check_case(i)
