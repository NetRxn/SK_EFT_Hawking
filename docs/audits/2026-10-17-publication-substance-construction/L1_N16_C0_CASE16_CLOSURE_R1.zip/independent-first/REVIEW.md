# Independent replay of outer case 16 slices 0 and 1

The task references canonical checkpoint c934f07d98a2bf65501a0006573bf8ece8c32040. The seven-factor parent matches the checksum in L1_N16_C0_CASE3_SCALEUP_R1.zip, and both slices bind to outer coordinate (65, (1,)) in the original canonical 48-entry roster. The inner roster matches the archived second-16 roster checksum. Independent histogram matching on the selected pair found exactly nine disjoint potentially nonzero cut values of G(0,1,2), totaling 1,021,248 products, with maximum 225,504 per value. A nonzero full-network term must have a matched row in the selected pair. The missing cut values therefore contribute zero. This forecast is local to that pair.

The first two entries in order by products then coordinate are (12,) and (48,), with 13,824 and 23,328 matched pair products. Inverse lifting both conditioned children recovered the exact compatible parent factor rows, their Gaussian coefficients and denominators. Terminal inputs carry the original label partition, all conditioning and the original factor-denominator product 40512224221827380280140849737629696.

Slice 0 direct three-factor replay uses pivot factor 1. The author uses pivot factor 0 with one pair of multiplications for every matched triple. The independent route sums the complement's adjacency inner product before multiplying by the pivot coefficient once. Its four coordinate projections are complete because each open coordinate has degree two. It observed 10,423,296 support triples and probes and 67,392 nonzero pivot rows. Exact regrouping took 10,490,688 Gaussian multiplications under the 30M bound and used a scalar output. Both the raw Gaussian numerator and normalized value agree with the author receipt. The ordinary pair route had refused before closure, with minimum ordinary pair forecast 10,423,296 against the 8M limit. The triangle path has its own 30M arithmetic/probe bounds and avoids materializing that pair.

Slice 1 direct sparse replay starts at the saved seven-factor reduced input and uses no author quotient or contraction code. It takes 1,189,248 matched products, with largest join 644,352 and peak output 64,512 rows. It matches the author exact value.

| Slice | Exact real | Exact imaginary |
|---|---|---:|
| 0 | -11685140226577673415/1298074214633706907132624082305024 | 0 |
| 1 | 960746576681676897/81129638414606681695789005144064 | 0 |

Normalization applies +1/(16*4^64) once in addition to the retained factor denominators. This review covers these two input-to-result replays and the selected cuts. Earlier reductions from the conditioned cuts use the saved lineage and previously reviewed identities. The other seven slices and complete outer 16 sum remain open in this review.
