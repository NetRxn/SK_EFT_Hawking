from fractions import Fraction
from pathlib import Path
import re

evidence = Path(__file__).resolve().parent
author = Path('/private/tmp/l1-c0-case16.HLZKWE')
value = re.compile(r'^(?:independent )?exact normalized real (\S+) imaginary (\S+)(?: |$)', re.M)
interval = re.compile(r'^left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)$', re.M)
resources = re.compile(r'^replay input (\d+) (\d+) (\d+) (\S+) ([0-9a-f]{64}) (\d+) (\d+)$', re.M)

def read_scalar(path):
    matches = value.findall(path.read_text())
    assert len(matches) == 1, path
    return tuple(map(Fraction, matches[0]))

def sum_values(values):
    return tuple(sum(components, Fraction(0)) for components in zip(*values, strict=True))

audit = (evidence / 'audit-all.out').read_text()
assert audit.endswith('PASS canonical parent/roster identity, exact nine-coordinate coverage, all nine inverse lifts and terminal input metadata\n')
binding = {int(i): (int(coord), int(matches), name, sha)
           for i, coord, matches, name, sha, _, _ in resources.findall(audit)}
assert len(binding) == 9
values = []
for row in (author / 'author-case16.tsv').read_text().splitlines():
    fields = row.split('\t')
    if fields[0] not in {str(i) for i in range(9)}:
        continue
    i, coord, matches = map(int, fields[:3])
    assert i == len(values)
    assert binding[i][:2] == (coord, matches)
    if i <= 1:
        log = evidence / f'slice-{i}-replay.out'
    elif i in (4, 5):
        log = evidence / f'slice-{i}-post-replay.out'
    else:
        log = evidence / f'slice-{i}-replay.out'
    scalar = read_scalar(log)
    assert scalar == tuple(map(Fraction, fields[3:]))
    if i in (2, 3, 6, 7, 8):
        shards = list((author.glob(f'slice-{i}-shard-[0-9]*.out')))
        coverage = []
        author_values = []
        for shard in shards:
            found = interval.findall(shard.read_text())
            assert len(found) == 1, shard
            coverage.append(tuple(map(int, found[0])))
            author_values.append(read_scalar(shard))
        coverage.sort()
        end = 0
        for k, (lo, hi, total, ordinal, count) in enumerate(coverage):
            assert lo == end and hi > lo and total == coverage[0][2]
            assert ordinal == k and count == len(shards)
            end = hi
        assert end == coverage[0][2]
        assert sum_values(author_values) == read_scalar(author / f'slice-{i}-shard-sum.out') == scalar
        print('author shard coverage', i, len(shards), end, 'all disjoint intervals and exact sum verified')
    values.append(scalar)
    print('independent scalar', i, coord, matches, *scalar, binding[i][-1])
assert len(values) == 9
total = sum_values(values)
assert total == (Fraction(9389273727582799968537, 5192296858534827628530496329220096), Fraction(0))
print('PASS full exact independent case 16 sum', *total)
