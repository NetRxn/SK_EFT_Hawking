from ast import literal_eval
from fractions import Fraction
from pathlib import Path
import re

axis, spectrum = literal_eval(Path('slice-0.roster').read_text())
assert axis == (('G',0,1,2),)
ordered = sorted(spectrum,key=lambda entry:(entry[1],entry[0]))
assert len(ordered)==len(dict(ordered))==9 and sum(n for _,n in ordered)==1_021_248
real = imaginary = Fraction(0)
for i, (coordinate, matches) in enumerate(ordered):
    assert literal_eval(Path(f'slice-{i}.roster').read_text())==(axis,spectrum)
    plan = Path(f'slice-{i}-plan.out').read_text().splitlines()[-1]
    assert plan.startswith(f'pilot {coordinate!r} matched {matches} stored rows ')
    path = ('triangle-pilot.out' if i==0 else f'slice-{i}-contract.out' if i in (1,4,5)
            else f'slice-{i}-shard-sum.out')
    text = Path(path).read_text()
    re_token, im_token = re.search(r'^exact normalized real (\S+) imaginary (\S+)',text,re.M).groups()
    re_value, im_value = Fraction(re_token),Fraction(im_token)
    real += re_value
    imaginary += im_value
    print(i,coordinate[0],matches,re_value,im_value,sep='\t')
print('sum',real,imaginary,sep='\t')
