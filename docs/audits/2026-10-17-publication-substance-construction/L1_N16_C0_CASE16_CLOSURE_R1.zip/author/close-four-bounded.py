from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import combinations
from math import prod
from pathlib import Path
import argparse
import pickle
import time

parser = argparse.ArgumentParser()
parser.add_argument('input', type=Path)
parser.add_argument('--pair', type=int, nargs=2, default=(1, 3))
args = parser.parse_args()
started = time.monotonic()
with args.input.open('rb') as handle:
    checkpoint = pickle.load(handle)
factors = checkpoint['factors']
assert len(factors) == 4 and all(len(set(axes)) == len(axes) for axes, _, _ in factors)
degree = Counter(w for axes, _, _ in factors for w in axes)
assert all(n == 2 and w[0] != 'L' for w, n in degree.items())
edges = {(a,b): tuple(w for w in factors[a][0] if w in factors[b][0])
         for a,b in combinations(range(4),2)}
symbols = {pair:{} for pair in edges}

def edge(a,b):
    return tuple(sorted((a,b)))

def encode_factor(a, neighbors):
    axes, rows, _ = factors[a]
    pairs = [edge(a,b) for b in neighbors]
    positions = [[axes.index(w) for w in edges[pair]] for pair in pairs]
    assert sum(map(len,positions))==len(axes)
    for row,z in rows.items():
        keys = []
        for pair,index in zip(pairs,positions,strict=True):
            key = tuple(row[i] for i in index)
            table = symbols[pair]
            keys.append(table.setdefault(key,len(table)))
        yield (*keys,z)

def multiply(left,right):
    x,y = left
    u,v = right
    return x*u-y*v,x*v+y*u

a,b = args.pair
assert 0 <= a < b < 4
c,d = sorted(set(range(4))-{a,b})
left = list(encode_factor(a,(b,c,d)))
right = defaultdict(list)
for join,b_to_c,b_to_d,z in encode_factor(b,(a,c,d)):
    right[join].append((b_to_c,b_to_d,z))
closure_c = defaultdict(dict)
closure_d = defaultdict(dict)
for c_to_a,c_to_b,internal,z in encode_factor(c,(a,b,d)):
    bucket=closure_c[c_to_a,c_to_b]
    assert internal not in bucket
    bucket[internal]=z
for d_to_a,d_to_b,internal,z in encode_factor(d,(a,b,c)):
    bucket=closure_d[d_to_a,d_to_b]
    assert internal not in bucket
    bucket[internal]=z
products = sum(len(right.get(join,())) for join,_,_,_ in left)
print('left pair',a,b,'candidate matches',products,'closure pair',c,d,flush=True)
assert products <= 10_000_000
probes = matched_closure = retained_outer = real = imaginary = 0

@lru_cache(maxsize=200_000)
def closure(a_to_c,b_to_c,a_to_d,b_to_d):
    global probes,matched_closure
    x = closure_c.get((a_to_c,b_to_c))
    y = closure_d.get((a_to_d,b_to_d))
    if not x or not y:
        return (0,0)
    if len(x)>len(y):
        x,y=y,x
    probes += len(x)
    assert probes<=30_000_000, ('closure probes',probes)
    re=im=0
    for key,z in x.items():
        peer=y.get(key)
        if peer is None:
            continue
        matched_closure+=1
        assert matched_closure+2*retained_outer<=30_000_000, ('arithmetic cap',matched_closure,retained_outer)
        u,v=multiply(z,peer)
        re+=u
        im+=v
    return re,im

for join,a_to_c,a_to_d,left_z in left:
    for b_to_c,b_to_d,right_z in right.get(join,()):
        partner=closure(a_to_c,b_to_c,a_to_d,b_to_d)
        if any(partner):
            retained_outer+=1
            assert matched_closure+2*retained_outer<=30_000_000
            r,s=multiply(multiply(left_z,right_z),partner)
            real+=r
            imaginary+=s
    assert time.monotonic()-started<120
print('cache',closure.cache_info(),flush=True)
denominator=prod(den for _,_,den in factors)
print('closure products',matched_closure,'retained outer matches',retained_outer,'closure probes',probes,'raw',real,imaginary,'factor denominator',denominator)
scale=denominator*16*4**64
print('exact normalized real',Fraction(real,scale),'imaginary',Fraction(imaginary,scale),
      'seconds',round(time.monotonic()-started,3),flush=True)
print('conditioning',checkpoint['conditioning'],'label partition',checkpoint['label_partition'])
