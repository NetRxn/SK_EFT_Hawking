from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

def run(job):
    receipt, script, arguments = job
    with Path(receipt+'.out').open('xb') as output:
        result = subprocess.run([sys.executable,'-u',script,*arguments],
                                stdout=output,stderr=subprocess.STDOUT,timeout=135)
    assert result.returncode == 0,(receipt,result.returncode)
    print(receipt,result.returncode,sep='\t',flush=True)

jobs = [
    ('triangle-pilot','triangle-bounded.py',['join-cap-dense-label-slice-0-reduced.pkl']),
]
for i in range(8):
    jobs.append((f'slice-3-shard-{i}','triangle-shards.py',
                 ['join-cap-dense-label-peer-3-reduced.pkl',str(i),'8']))
for index,prefix,pair,count in (
    (2,'join-cap-dense-label',(0,2),4),
    (6,'row-cap-physical-slice-dense-label',(0,2),6),
    (7,'join-cap-dense-label',(1,3),12),
    (8,'join-cap-dense-label',(1,3),12),
):
    for shard in range(count):
        jobs.append((f'slice-{index}-shard-{shard}','close-four-shards.py',
                     [f'{prefix}-slice-{index}-reduced.pkl','--pair',*map(str,pair),
                      '--shard',str(shard),str(count)]))
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run,jobs))
