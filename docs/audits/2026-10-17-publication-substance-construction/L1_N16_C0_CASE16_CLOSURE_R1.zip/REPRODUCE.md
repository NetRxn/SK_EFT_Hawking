# L1 N16 dense group 128 case 16

The calculation is for the first binary child of tuple 0 in descendant (0,0), scientific source 51e7c745e. Parent publication checkpoint c934f07d9. The original case-16 cut coordinate is (65,(1,)). This package records the nine contributions and complete outer sum. The rest of tuple 0 and the full profile are separate work.

## Restore the exact input

Restore `row-cap-physical-slice-dense-label-case-16-2-reduced.pkl` as in `L1_N16_C0_CASE3_SCALEUP_R1.zip`, using the earlier eight-factor parent archive and the original three reduction/contraction cycles. Verify its uncompressed SHA256 as 29a4dc428d009115ea3509656f746ef52938ae32aeac73963905a802cb0073cb. Deserialize only trusted checkpoint inputs. Copy the author Python files and its checkpoint directory to a fresh scratch directory.

## Author replay

```bash
python3 -u run-primary.py /absolute/path/to/row-cap-physical-slice-dense-label-case-16-2-reduced.pkl
python3 -u reduce-label-frontier.py row-cap-physical-slice-dense-label-slice-3-reduced.pkl peer-3
if python3 -u contract-peer.py peer-3; then exit 1; else test "$?" = 2 || exit 1; fi
python3 -u capture-quotient.py slice-4
python3 -u capture-quotient.py slice-5
sha256sum -c /absolute/path/to/archive/reconstructed-frontiers.sha256
python3 -u run-closures.py
for spec in '2 4' '3 8' '6 6' '7 12' '8 12'; do
    read -r slice count <<< "$spec"
    python3 sum-shards.py "$slice" "$count" >"slice-$slice-shard-sum.out"
done
python3 sum-case16.py
```

Use `shasum -a 256 -c` if `sha256sum` is unavailable. The parent partition uses the nine distinct values of G(0,1,2) and covers all 1,021,248 compatible matches of the scoped pair. It is ordered by product count, then coordinate. The plain contraction closes slices 1, 4 and 5. Slice 0 uses direct triangle closure. Slice 3 uses exact peer pair support filtering, followed by three-factor closure split across eight disjoint row intervals. Slices 2, 6, 7 and 8 use bounded cached four-factor contraction over 4, 6, 12 and 12 disjoint row intervals, respectively. The cache keys all four exterior labels and sums over the remaining shared edge of the complementary pair. Sorting the streaming factor's keys and partitioning by ordinal conserves all terms. The aggregator checks contiguous complete coverage and applies the original denominator and external normalization once to the raw sum. Refused unpartitioned attempts are retained in the author receipts.

The exact complete outer real value is 9389273727582799968537/5192296858534827628530496329220096. The imaginary part is zero. This package alone does not estimate the cost of a full hard profile or close any publication gate.

For the sharding control, run `python3 literal-shard-control.py` in the author folder. It compares direct enumerations of twelve signed Gaussian networks with all six pairings at three and five shards. The scientific case employed 42 successful shard runs. The largest used 25,045,632 Gaussian products and 20,846,592 closure probes. The shard runtimes summed to 168.963 seconds in the recorded runs, excluding the input reductions, direct slices, failed attempts and independent review.

The first two independent replays are preserved in `independent-first`. The other seven replays, canonical cut audit, and whole-case retally are in `independent`. Their scripts name the original scratch paths. To repeat the retally from an extracted archive, point `author` and `initial` in a scratch copy of `independent/aggregate.py` to the archive's `author` and `independent-first` directories. To repeat the input audit, first regenerate the factor inputs. See the independent report for the seven replay methods and intermediate inputs.
