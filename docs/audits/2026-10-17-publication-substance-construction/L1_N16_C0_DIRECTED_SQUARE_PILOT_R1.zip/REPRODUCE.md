Unzip the nested author archive into a sibling author directory. Inside
that directory extract AUTHOR.zip into AUTHOR/ and INDEPENDENT.zip into
INDEPENDENT/. Verify the four author manifests from that directory.
Inside independent/, create relative links AUTHOR -> ../author/AUTHOR,
INDEPENDENT -> ../author/INDEPENDENT and frozen -> ../author. Verify the
review manifest, then follow the commands in independent/REVIEW.md.
The family-intake directory contains author-only results, including the
independently accepted pilot. Verify its manifest from the archive root.
To rerun, place family-intake beside the extracted author's inputs and
follow its scripts, which expect the extracted author layout.
The exact residual removes only the independently accepted pilot.
