import ast,os,sys
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations_with_replacement,product
from math import factorial,prod
from pathlib import Path

sys.path.insert(0,str(Path("INDEPENDENT").absolute()))
scratch=Path.cwd()
os.chdir("INDEPENDENT")
from contract import same,mixed,integrate,occupancy,profile,local,enc,inv
source=ast.parse(Path("project.py").read_text())
source.body=[node for node in source.body if isinstance(node,(ast.FunctionDef,ast.Import,ast.ImportFrom))]
exec(compile(source,"project.py","exec"))
os.chdir(scratch)

def read(path):
    return (tuple(map(int,row.split())) for row in Path(path).open())
def plus(a,b):return a[0]+b[0],a[1]+b[1]
def times(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def conj(a):return a[0],-a[1]
widths=(1,3,3,4)
codes=(37086699520,8935831015554)
assert sum((a,b)==codes and w==48 for a,b,w in read('INDEPENDENT/block-remaining.tsv'))==1
cores,forced,domains=projection(*codes,2)
assert not cores[0]
assert len(cores[1])==4
roots={}
ends={}
for (u,v,k),(a,b) in cores[1].items():
    assert sorted((a,b))==[0,2]
    x,y=(u,v) if a else (v,u)
    roots[x]=(y,k)
    ends[y]=x
assert set(roots)==set(ends)=={0,2,4,6}
print('directed roots',roots,'forced',forced,'domains',domains)
cyc=[0]
while roots[cyc[-1]][0]!=cyc[0]:
    cyc.append(roots[cyc[-1]][0])
assert cyc==[0,4,6,2]
q=defaultdict(dict)
for o,h,d,k,w,m,i,j,r,s in read('spatial.tsv'):
    q[o,h,d,k][w,m,i,j]=(r,s)
root_table=defaultdict(list)
for a,b,c,d,k,i,j,r,s in read('root.tsv'):
    root_table[k].append(((a,b),(c,d),i,j,(r,s)))

def factors(side,k,mutation):
    occ=occupancy(codes[side]);edges=profile(codes[side])[2]
    incident=defaultdict(list)
    factors=[]
    den=1
    for edge,(a,b) in sorted(edges.items()):
        u,v,axis=edge
        active=(roots.get(u)==(v,axis) or roots.get(v)==(u,axis))
        d=a+b
        if active:
            assert not(a and b)
            owner=int(bool(b)); anchor=int(roots.get(v)==(u,axis))
            data={}
            for (w,m,i,j),coefficient in q[owner,anchor,d,k].items():
                # Decode ordered endpoint incidence of original matrix.
                state=(i,j) if anchor else (j,i)
                if side==1 and mutation!='missing-conjugation':coefficient=conj(coefficient)
                if mutation=='all-conjugated':coefficient=conj(coefficient)
                data[((0 if owner else w,m&255,state[0]),(w if owner else 0,m>>8,state[1]))]=coefficient
            den*=192*4**d
        else:
            if a and b:
                assert a==b==2
                data=mixed
            else:data=same[d] if a else {(y,x):z for (x,y),z in same[d].items()}
            if mutation=='all-conjugated':data={key:conj(z) for key,z in data.items()}
            den*=64 if d==2 else 12288
        wires=((u,v,0),(u,v,1))
        factors.append((wires,data))
        for x,wire in zip((u,v),wires):
            slot=(0 if u==x else 1)
            avail=defaultdict(set)
            for row in data:
                w,m,i=row[slot]
                assert m.bit_count()==d
                avail[w,i].add(m)
            p=(int(roots[x]==(v if x==u else u,axis)) if active else -1)
            incident[x].append((wire,axis,p,avail))
    for x,row in enumerate(occ):
        choices=[]
        if side==1 and x in roots:
            axis=roots[x][1]
            assert row[axis]==2 and sum(row)==2
            p,q1=[a for a in range(3) if a!=axis]
            for w1,w2,i,j,z in root_table[k]:
                if mutation=='all-conjugated':z=conj(z)
                words=[0,0,0]
                words[p]=enc(w1);words[q1]=enc(w2)
                choices.append((words,(j,i),z))
        else:
            for (_,words),z in local(row,-1,-1).items():
                if mutation=='all-conjugated':z=conj(z)
                for i in range(widths[k] if side==0 and x in roots else 1):
                    choices.append((tuple(map(enc,words)),(i,i),z))
        table={}
        plans=[]
        for words,indices,z in choices:
            labels=[(words[a],indices[p] if p>=0 else 0) for _,a,p,_ in incident[x]]
            groups=[D.get(s,()) for (_,_,_,D),s in zip(incident[x],labels)]
            if not all(groups):continue
            order=sorted(range(len(groups)),key=lambda i:len(groups[i]))
            plans.append((groups,order,labels,z))
        work=sum(prod(len(groups[i]) for i in order[:-1]) for groups,order,_,_ in plans)
        assert work<=2_000_000
        for groups,order,labels,z in plans:
            for prefix in product(*(groups[i] for i in order[:-1])):
                mask=0
                for a in prefix:
                    if mask&a:break
                    mask|=a
                else:
                    complement=255^mask
                    if complement not in groups[order[-1]]:continue
                    masks=dict(zip(order,(*prefix,complement)))
                    ordered=list(map(masks.__getitem__,range(len(masks))))
                    exponent=sum(inv(a,b) for i,a in enumerate(ordered) for b in ordered[i+1:])
                    if mutation=='omit-wedge' and side==1 and x==0:exponent=0
                    signed=z if exponent%2==0 else (-z[0],-z[1])
                    key=tuple((w,m,i) for (w,i),m in zip(labels,ordered))
                    table[key]=plus(table.get(key,(0,0)),signed)
                    assert len(table)<=150000
        factors.append((tuple(wire for wire,_,_,_ in incident[x]),{k:v for k,v in table.items() if any(v)}))
    assert sum(len(t) for _,t in factors)<=150000
    return factors,den

def run(mode):
    numerator=prod({2:2,4:10}[n] for t,code in enumerate(codes) for x,row in enumerate(occupancy(code)) for axis,n in enumerate(row)
                   if n and not(t==1 and x in roots and roots[x][1]==axis))
    denominator=prod(factorial(n) for code in codes for row in occupancy(code) for n in row)
    print('normalization',numerator,denominator,F(numerator,denominator))
    total=F(0)
    for k,d in enumerate(widths):
        layers=[]
        for side in (0,1):
            network,n=factors(side,k,mode)
            val,peak,work=integrate(network,mode=='reverse')
            layers.append(tuple(F(z,n) for z in val))
            print('layer',side,k,'denominator',n,'peak',peak,'work',work,flush=True)
        r,i=times(*layers)
        assert i==0
        result=F(numerator,denominator*d**4)*r
        print(k,layers,result,flush=True)
        total+=result
    print('total',mode,total)
run(sys.argv[1] if len(sys.argv)>1 else 'ordinary')
