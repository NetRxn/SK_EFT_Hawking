from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from math import prod
from functools import cache
from pathlib import Path

def add(z,w):return z[0]+w[0],z[1]+w[1]
def mul(z,w):return z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0]
def conjugate(z):return z[0],-z[1]
def scale(z,n):return z[0]*n,z[1]*n
def read(p):return (tuple(map(int,l.split())) for l in Path(p).open())
def out(p,rows):
    Path(p).write_text(''.join(' '.join(map(str,r))+'\n' for r in rows))
@cache
def h(q):
    answer=F(1)
    for g in (0,4):
        exponents=[q.count(g+j) for j in range(4)]
        if any(v%2 for v in exponents):return F(0)
        answer*=F(prod(prod(range(1,v,2)) for v in exponents),prod(range(4,4+sum(exponents),2)))
    return answer
reps=defaultdict(list)
for i in range(4):reps[0,0,0].append(((i,i),(1,0)))
for a,b,i,j,v in read('INDEPENDENT/adjoint.tsv'):
    for k in (1,2):
        offset=4*(k-1)
        reps[k,a,b].append(((offset+i,offset+j),(v,0)))
for a,b,i,j,r,s in read('INDEPENDENT/fundamental-product.tsv'):
    reps[3,a,b].append(((i,j),(r,s)))
root=defaultdict(list)
for chi,a,b,i,v in read('INDEPENDENT/bivectors.tsv'):
    root[a,b].append((4*chi+i+1,2*v))
pol=defaultdict(lambda:defaultdict(int))
for (a,b),(c,d) in product(root,repeat=2):
    word=(*sorted((a,c)),*sorted((b,d)))
    for (i,v),(j,w) in product(root[a,b],root[c,d]):
        pol[word][tuple(sorted((i,j)))]+=v*w
result={}
for word,p in pol.items():
    for (k,i,j),monomials in reps.items():
        # Exact Fourier coefficient d*int F(g)*conj(D_ij(g)).
        z=(0,0)
        for (q,v),(r,w) in product(p.items(),monomials):
            z=add(z,scale(conjugate(w),(1,3,3,4)[k]*v*h(tuple(sorted(q+r)))))
        assert all(x==int(x) for x in z)
        if any(z):result[(*word,k,i,j)]=tuple(map(int,z))
out('root.tsv',((*key,*val) for key,val in sorted(result.items())))
assert list(read('root.tsv'))==list(read('frozen/square-root-tensor.tsv'))
print(len(result),'exact root coefficients reproduce via orthogonal projection')
map_by_coordinate=defaultdict(list)
for (k,i,j),terms in reps.items():
    for q,z in terms:map_by_coordinate[q].append((k,i,j,z))
matrix=defaultdict(dict)
for o,a,d,i,j,w,m,r,s in read('signed.tsv'):
    group=matrix[o,a,d]
    for k,p,q,z in map_by_coordinate[i,j]:
        key=(k,w,m,p,q)
        group[key]=add(group.get(key,(0,0)),mul(z,(r,s)))
assert max(map(len,matrix.values()))<150000
out('spatial.tsv',((*o,*key,*val) for o,tab in sorted(matrix.items()) for key,val in sorted(tab.items()) if any(val)))
assert list(read('spatial.tsv'))==list(read('frozen/square-spatial-matrices.tsv'))
print('all spatial matrix rows reproduce via alternate exterior pairing')
