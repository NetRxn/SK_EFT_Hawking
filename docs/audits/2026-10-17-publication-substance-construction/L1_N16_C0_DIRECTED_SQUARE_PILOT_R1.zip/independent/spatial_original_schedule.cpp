#define main reference_main
#include "slice_reference.cpp"
#undef main
#include <map>
#include <numeric>
#include <set>

int sphere_weight(std::array<int,6> variables,int n) {
    std::array<int,16> powers{};
    for(int k=0;k<n;k++) powers.at(variables[k])++;
    int a=192,b=1;
    for(int g=0;g<16;g+=4){
        int degree=0;
        for(int p=g;p<g+4;p++){
            if(powers[p]&1) return 0;
            degree+=powers[p];
            for(int k=3;k<powers[p];k+=2) a*=k;
        }
        for(int k=0;k<degree;k+=2)b*=k+4;
    }
    if(a%b)throw std::runtime_error("nonintegral Haar");
    return a/b;
}
int main(){
    const auto source=read_coframes();
    std::map<std::pair<int,int>,int> coordinates;
    int a,b,i,j,r,s;
    std::ifstream adj("adjoint.tsv"), cross("fundamental-product.tsv");
    while(adj>>a>>b>>i>>j>>r)for(int c:{0,4})coordinates[{c+i,c+j}]++;
    while(cross>>a>>b>>i>>j>>r>>s)coordinates[{i,j}]++;
    if(coordinates.size()!=36) return 2;
    for(int o:{0,1}) {
        std::array<std::array<QuadRoster,4>,4> pairs{};
        for(int u=0;u<4;u++)for(int v=u;v<4;v++)pairs[u][v]=square_pair(source[o][u],source[o][v]);
        for(int h:{0,1})for(int d:{2,4}){
            const auto enumerate=[&](auto action){
                for(auto [q,m]:coordinates){
                    const int x=q.first+8*h,y=q.second+8*h;
                    const unsigned parity=(1U<<x)^(1U<<y);
                    for(int a=0;a<4;a++)for(int b=a;b<4;b++){
                        if(d==2){
                            action(q,m,x,y,a*4+b,0,&pairs[a][b],static_cast<const QuadRoster*>(nullptr),parity);
                            continue;
                        }
                        for(int c=b;c<4;c++)for(int e=c;e<4;e++)
                            action(q,m,x,y,64*a+16*b+4*c+e,
                                   0,&pairs[a][b],&pairs[c][e],parity);
                    }
                }
            };
            const auto matching=[&](const QuadRoster* P,const QuadRoster* Q,unsigned parity,auto fn) {
                std::array<int,257> bucket_map{};
                bucket_map.fill(-1);bucket_map[0]=0;
                for(int a=0;a<16;a++)for(int b=a+1;b<16;b++)bucket_map[1+16*a+b]=(1U<<a)|(1U<<b);
                for(int j=0;j<257;j++){
                    if((*P)[j].empty())continue;
                    unsigned desired=unsigned(bucket_map[j])^parity;
                    if(desired && std::popcount(desired)!=2)continue;
                    int k=desired?1+16*std::countr_zero(desired)+std::countr_zero(desired&(desired-1)):0;
                    if(Q) fn((*P)[j],&(*Q)[k]);
                    else if(k==0)fn((*P)[j],nullptr);
                }
            };
            U64 raw=0,cached=0;
            enumerate([&](auto,int mult,int,int,int,int,const auto* P,const auto* Q,unsigned parity){
                matching(P,Q,parity,[&](const auto& L,const std::vector<Quad>* R){
                    U64 n=U64(L.size())*(R?R->size():1);cached+=n;raw+=mult*n;
                });
            });
            if(cached>50'000'000)throw std::runtime_error("refused before accumulation");
            std::cerr<<"admitted owner "<<o<<" anchor "<<h<<" degree "<<d<<" raw "<<raw<<" cached "<<cached<<'\n';
            for(const auto& entry:coordinates){
            std::map<unsigned,Z> dst;
            enumerate([&](auto q,int,int x,int y,int word,int,const auto* P,const auto* Q,unsigned parity){
                if(q!=entry.first)return;
                const auto add=[&](unsigned mask,Z value){
                    unsigned key=(unsigned(word)<<16)|mask;
                    if(!dst.contains(key) && dst.size()>=150'000)throw std::runtime_error("pair row limit");
                    dst[key]+=value;
                };
                matching(P,Q,parity,[&](const auto& L,const std::vector<Quad>* R){
                    for(const auto& u:L){
                        if(R){
                            for(const auto& v:*R) if(!(u.mask&v.mask))
                                add(u.mask|v.mask,(u.value*v.value)*
                                    (sign(u.mask,v.mask)*sphere_weight({x,y,u.a,u.b,v.a,v.b},6)));
                        } else add(u.mask,u.value*sphere_weight({x,y,u.a,u.b,0,0},4));
                    }
                });
            });
            const auto q=entry.first;
            for(const auto& [key,z]:dst)if(z)
                    std::cout<<o<<' '<<h<<' '<<d<<' '<<q.first<<' '<<q.second<<' '<<(key>>16)<<' '
                             <<(key&65535)<<' '<<z.re<<' '<<z.im<<'\n';
            }
        }
    }
}
