# L1 N16 dense group 128 case 47 author checkpoint

The nine-slice author result awaits independent verification. Scientific source 51e7c745e. Parent publication checkpoint 84817299b. This is the original case (68,(2,)) of the first binary child of tuple 0 in descendant (0,0), with complete matched-pair coverage 2,280,960. The exact author sum is -266847350733101695525209/1298074214633706907132624082305024 with zero imaginary part. The full coefficient and the publication gates remain open.

Restore `row-cap-physical-slice-dense-label-case-47-2-reduced.pkl` using the `L1_N16_C0_CASE3_SCALEUP_R1.zip` instructions. Its SHA256 is 3b2571cceebe7dda9b8b55c7569ab82b351267812f185266cac295419d405ad2. Only deserialize trusted checkpoint inputs. Copy the author Python files and checkpoint directory to fresh scratch.

```bash
python3 -u run-primary.py /absolute/path/to/row-cap-physical-slice-dense-label-case-47-2-reduced.pkl
python3 -u reduce-open.py 0 2 3 4 5 6 7 8
shasum -a 256 -c /absolute/path/to/archive/reconstructed-frontiers.sha256
for slice in 2 3; do
    for ((shard=0; shard<8; shard++)); do
        python3 -u triangle-shards.py "join-cap-dense-label-rescue-$slice-1-reduced.pkl"           "$shard" 8 >"slice-$slice-shard-$shard.out" || exit 1
    done
done
for slice in 7 8; do
    for ((shard=0; shard<8; shard++)); do
        python3 -u close-four-shards.py "row-cap-physical-slice-dense-label-rescue-$slice-0-reduced.pkl"           --pair 1 3 --shard "$shard" 8 >"slice-$slice-shard-$shard.out" || exit 1
    done
done
for slice in 2 3 7 8; do
    python3 sum-shards.py "$slice" 8 >"slice-$slice-shard-sum.out" || exit 1
done
python3 sum-case47.py
```

The seven-factor initial partition uses all nine values of G(0,1,2). The direct contraction closes slice 1. Re-reduction closes 0, 4, 5 and 6, and exposes three-factor closure for 2 and 3. Re-reduction also finds a cheaper four-factor starting point for 7 and 8. The remaining terms close by the 32 bounded row-interval shards whose individual receipts and exact sums are included.
