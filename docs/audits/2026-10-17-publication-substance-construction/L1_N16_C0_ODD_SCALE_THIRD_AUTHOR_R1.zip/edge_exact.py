from ast import literal_eval
from collections import defaultdict
from fractions import Fraction
from itertools import product
from math import lcm
from pathlib import Path
import sys

base=Path(sys.argv[1])
a,b=map(int,sys.argv[2:4])
S,T=(literal_eval(v) for v in sys.argv[4:6])
assert S[0]==T[0]==a+b
WORK_CAP=8_000_000
ROW_CAP=300_000

H={shape:defaultdict(list) for shape in (S,T)}
scale=1
for row in (base/'spatial.tsv').read_text().splitlines():
    shape,indices,*mat,r,i=row.split('\t')
    shape=literal_eval(shape)
    if shape not in H:continue
    re,im=Fraction(r),Fraction(i)
    scale=lcm(scale,re.denominator,im.denominator)
    H[shape][literal_eval(indices)].append((tuple(map(literal_eval,mat)),re,im))
for table in H.values():
    for q,rows in table.items():
        table[q]=[(mat,int(r*scale),int(i*scale)) for mat,r,i in rows]

C=[defaultdict(list),defaultdict(list)]
for owner,d in enumerate((a,b)):
    if d==0:C[owner][()].append(((),0,1,0))
for row in Path('coframe-roster.tsv').open():
    owner,word,mask,indices,r,i=row.rstrip('\n').split('\t')
    if len(word)!=2*(a,b)[int(owner)]-1:continue
    C[int(owner)][tuple(map(int,indices.split(',')))].append((tuple(map(int,word.split(','))),int(mask),int(r),int(i)))

def wedge(m,n):
    return -1 if sum((n&((1<<i)-1)).bit_count() for i in range(16) if m>>i&1)%2 else 1

groups=[]
planned=0
for q1,L in C[0].items():
    for q2,R in C[1].items():
        q=tuple(sorted(q1+q2))
        X=H[S].get(tuple(i for i in q if i<8),())
        Y=H[T].get(tuple(i-8 for i in q if i>=8),())
        if X and Y:
            planned+=len(L)*len(R)*len(X)*len(Y)
            if planned>WORK_CAP:raise RuntimeError(('matched product cap',planned))
            groups.append((L,R,X,Y))
out={}
for L,R,X,Y in groups:
    for (w,m,r,i),(v,n,s,j) in product(L,R):
        if m&n:continue
        sign=wedge(m,n)
        ar,ai=sign*(r*s-i*j),sign*(r*j+i*s)
        for (x,c,d),(y,e,f) in product(X,Y):
            br,bi=c*e-d*f,c*f+d*e
            k=w,v,m|n,x,y
            old=out.get(k,(0,0))
            if k not in out and len(out)>=ROW_CAP:raise RuntimeError(('output row cap',len(out)))
            re,im=old[0]+ar*br-ai*bi,old[1]+ar*bi+ai*br
            if re or im:out[k]=re,im
            else:out.pop(k,None)
with Path('edge-selected.tsv').open('w') as dest:
    for k,(r,i) in sorted(out.items()):
        print(*k,Fraction(r,scale*scale),Fraction(i,scale*scale),sep='\t',file=dest)
print('selected',a,b,S,T,'planned',planned,'nonzero',len(out),'Haar scale',scale*scale)
