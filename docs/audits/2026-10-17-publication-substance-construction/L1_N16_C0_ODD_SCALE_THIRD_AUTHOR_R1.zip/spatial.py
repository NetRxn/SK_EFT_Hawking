from itertools import combinations_with_replacement,product
from functools import cache
from math import comb,prod
from pathlib import Path
from temporal import Q,rep
from src.vestigial.original_coefficients import Polynomial, haar_polynomial

CAP=250000
shapes={tuple(map(int,row.split()[4:])) for row in Path('anchor-plan.tsv').read_text().splitlines()}
assert sum(sum(comb(7+r,r) for r in range(h+1))*prod((v+1)**2 for v in labels) for h,*labels in shapes)<=CAP

@cache
def polynomial(indices):
    z=Polynomial.coerce(1)
    for i in indices:z*=Q[i]
    return z

@cache
def value(n,m,i,j,k,l,indices):
    A=rep(n,True); B=rep(m,False)
    moment=haar_polynomial(A[i][j]*B[k][l]*polynomial(indices)).terms
    return moment[0][1] if moment else None

for i,j,k,l in product(range(2),repeat=4):
    z=value(1,1,i,j,k,l,())
    if i==l and j==k:assert (z.real,z.imag)==(1/2,0)
    else:assert z is None

with Path('spatial.tsv').open('w') as out:
    count=0
    for h,a,b,c,d in sorted(shapes):
        admitted=0
        for degree in range(h+1):
            for indices in combinations_with_replacement(range(8),degree):
                L=tuple(i for i in indices if i<4)
                R=tuple(i-4 for i in indices if i>=4)
                if (len(L)+a+c)%2 or (len(R)+b+d)%2:continue
                for i,j,ip,jp,k,l,kp,lp in product(*(range(v+1) for v in (a,a,b,b,c,c,d,d))):
                    left=value(a,c,i,j,k,l,L); right=value(b,d,ip,jp,kp,lp,R)
                    if left is None or right is None:continue
                    val=left*right
                    print((h,a,b,c,d),indices,(i,ip),(j,jp),(k,kp),(l,lp),val.real,val.imag,sep='\t',file=out)
                    admitted+=1
        count+=admitted
        print((h,a,b,c,d),'nonzero rows',admitted)
    print('total',count,'cache',value.cache_info())
