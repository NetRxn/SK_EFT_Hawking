from ast import literal_eval as parse
from collections import Counter,defaultdict
from dataclasses import dataclass,field
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
from sys import argv
import sys

WORK=32_000_000
ROWS=800_000
BITS=256
source=Path('compact-boundary.py').read_text()
start=source.index('def width(')
end=source.index('tally=0',start)
definitions=source[start:end]
start=definitions.index('for f in factors:')
end=definitions.index('def indices',start)
definitions=definitions[:start]+definitions[end:]
start=source.index('@dataclass')
end=source.index('def bind(',start)
exec(source[start:end]+definitions)

def load(path):
    with path.open() as file:
        raw,denom,name=next(file).rstrip('\n').split('\t')
        rows={}
        for line in file:
            h,r,i=line.split()
            key=int(h,16)
            assert key not in rows and len(rows)<ROWS
            rows[key]=int(r),int(i)
    return Factor(name,parse(raw),rows,int(denom))

def eligible(fs):
    columns=defaultdict(list)
    for i,f in enumerate(fs):
        for w in f.wires:columns[w].append(i)
    assert all(len(rows)==2 for rows in columns.values())
    choices=[]
    for i,j in sorted({tuple(x) for x in columns.values()}):
        A,B=fs[i],fs[j]
        cols=indices(A,B)
        n=work(A,B,cols)
        score=n*(1+len(A.wires)+len(B.wires)-2*len(cols))
        choices.append((score,n,i,j,cols))
    return sorted(choices), columns

def splits(fs):
    choices,columns=eligible(fs)
    _,n,i,j,cols=choices[0]
    boundary=(set(fs[i].wires)|set(fs[j].wires))-set(cols)
    candidates=[]
    for w in sorted(boundary):
        if w[0]!='R':continue
        a,b=columns[w]
        ha,hb=buckets(fs[a],(w,)),buckets(fs[b],(w,))
        domain=sorted(ha.keys()&hb.keys())
        if len(domain)<2:continue
        count=[ha[k]*hb[k] for k in domain]
        width=sum(count)
        # Balance product reduction across all values on this wire.
        candidates.append((Fraction(max(count),width),-width,w,domain))
    return sorted(candidates)

# Load the original 72-factor pilot from unchanged author tables.
prefix=source[:source.index('def width(')]
exec(prefix)
fs=list(factors)
for f in fs:
    packed={encode(f.wires,k):v for k,v in f.rows.items()}
    assert len(packed)==len(f.rows)
    f.rows=packed
scalars=[f for f in fs if not f.wires]
fs=[f for f in fs if f.wires]
from math import gcd

def unpack_columns(value, wires, columns):
    # Each row is encoded in disjoint bitfields. Replace only the bond bits.
    layout_from,_=layout(columns)
    layout_to,_=layout(wires)
    return sum(((value>>layout_from[w][0])&((1<<width(w))-1))<<layout_to[w][0] for w in columns)

def rotate(r,i,n):
    return ((r,i),(-i,r),(-r,-i),(i,-r))[n]

def squeeze(A,B,cols):
    projA,projB=estimate(A.wires,cols),estimate(B.wires,cols)
    keep=tuple(w for w in A.wires if w not in cols)
    projK=estimate(A.wires,keep)
    shared={extract(row,projB) for row in B.rows}
    slices=defaultdict(list)
    for row,(r,i) in A.rows.items():
        x=extract(row,projA)
        if x in shared:slices[x].append((extract(row,projK),r,i))
    signatures={}
    aliases={}
    for x,rows in slices.items():
        rows.sort()
        g=0
        for _,r,i in rows:
            g=gcd(g,gcd(r,i))
            if g==1:break
        assert g
        _,r,i=rows[0]
        phase=max(range(4),key=lambda n:rotate(r,i,n))
        sig=tuple((k,*rotate(r//g,i//g,phase)) for k,r,i in rows)
        y=signatures.setdefault(sig,x)
        ar,ai=rotate(g,0,-phase%4)
        aliases[x]=y,ar,ai
    count=len(slices)
    distinct=len(signatures)
    if count==distinct and set(slices)==shared:return (count,distinct,False)
    left={}
    for sig,y in signatures.items():
        insert=unpack_columns(y,A.wires,cols)
        for k,r,i in sig:
            left[unpack_columns(k,A.wires,keep)|insert]=r,i
    mask=unpack_columns(-1,B.wires,cols)
    entry={}
    for row,(r,i) in B.rows.items():
        a=aliases.get(extract(row,projB))
        if a is None:continue
        y,p,q=a
        key=(row&~mask)|unpack_columns(y,B.wires,cols)
        h,j=entry.get(key,(0,0))
        result=h+r*p-i*q,j+i*p+r*q
        if any(result):entry[key]=result
        else:entry.pop(key,None)
    A.rows=left
    B.rows=entry
    A.histograms.clear()
    B.histograms.clear()
    return (count,distinct,True)

# Direct Gaussian control with two proportional slices and a nontrivial phase.
def control():
    u=('G',0,0,0)
    v=('G',0,0,1)
    A=Factor('a',(u,v),{256:(6,0),512:(0,3),257:(0,-12),513:(6,0)},1)
    B=Factor('b',(u,),{0:(2,1),1:(0,3)},1)
    init=join(A,B,(u,),4)
    assert squeeze(A,B,(u,))==(2,1,True)
    final=join(A,B,(u,),2)
    assert init.rows==final.rows

control()
def simplify(fs):
    for epoch in range(8):
        pivoted=False
        for i,A in enumerate(fs):
            for j,B in enumerate(fs):
                if i==j:continue
                cols=indices(A,B)
                if not cols:continue
                count,distinct,changed=squeeze(A,B,cols)
                if changed:
                    print('quotient',epoch,i,j,count,distinct,len(A.rows),len(B.rows),flush=True)
                    pivoted=True
                if not A.rows or not B.rows:
                    print("EXACT ZERO through proportional slices");sys.exit()
        print('pass',epoch,[len(f.rows) for f in fs],flush=True)
        if not pivoted:break

simplify(fs)
count=0
budget=160_000_000
while fs:
    for f in fs[:]:
        if not f.wires:
            scalars.append(f);fs.remove(f)
    if not fs:break
    deleted=prune(fs,rounds=2)
    if any(not f.rows for f in fs):
        print('EXACT ZERO',count);sys.exit()
    options,_=eligible(fs)
    for _,products,i,j,cols in options:
        if products>WORK or count+products>budget:continue
        count+=products
        try:
            C=join(fs[i],fs[j],cols,products)
        except RuntimeError as e:
            print('REFUSED JOIN',str(e),products,flush=True)
            continue
        print('join',len(fs),products,len(C.rows),'pruned',deleted,flush=True)
        if not C.rows:
            print('EXACT ZERO',count);sys.exit()
        fs.pop(j);fs.pop(i);fs.append(C)
        if C.wires:simplify(fs)
        break
    else:
        print('OPEN QUOTIENT',len(fs),count,min(n for _,n,*_ in options))
        sys.exit(3)
r,n=Fraction(1),Fraction(0)
for f in scalars:
    a,b=f.rows[0]
    a,b=Fraction(a,f.denom),Fraction(b,f.denom)
    r,n=r*a-n*b,r*b+n*a
total=sum(n for m in occ for row in m for n in row)
assert total==32
world=sum((3+k)*n for m in occ for row in m for k,n in enumerate(row))
cross=0
for m in occ:
    weighted=[(u,v,sum(m[u])-m[u][k]+sum(m[v])-m[v][k]) for u,v,k in edges]
    cross+=sum(a[2]*b[2]*(u>v) for i,a in enumerate(weighted) for b in weighted[i+1:]
               for u in a[:2] for v in b[:2])
phase=(-1)**((world+cross)%2)
print('epsilon and cross-site parity',world%2,cross%2)
r,n=r*phase,n*phase
denom=prod(factorial(p) for m in occ for o in m for p in o)*4**(2*total)
print('EXACT channel',case,r/denom,n/denom,'products',count)
