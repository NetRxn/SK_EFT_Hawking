#!/bin/sh
set -eu
export L1_PROFILE_CODES=140684411270,558347329670
for id in $(cut -f1 "$1/states.tsv" | sort -nr -u)
do
    prior=$(printf '%s/case-%03d.out' "$1" "$id")
    if test -f "$prior" && tail -1 "$prior" | grep -q '^EXACT'; then continue; fi
    /usr/bin/time -p python3 quotient_worklist.py "$1" . "$id" > "case-$id.out" 2> "case-$id.time" || test "$?" = 3
    printf '%s ' "$id"
    tail -1 "case-$id.out"
done
