# Third L1 odd-root scale-up author receipt

Original profile (140684411270,558347329670), weight 96. The 48 representatives of 96 chirality-paired assignments have 19 positive, one negative and 28 zero values. The two schedules agree on the 6 overlapping representatives. The coefficient is twice the sum of the 48 representative values. Independent replay must check both the values and the pairing before removing this profile from the accepted residual.

The hashes cover local raw factor tables. This archive contains case logs and selected scripts and inputs.
