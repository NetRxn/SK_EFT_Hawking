from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
import ast,json,hashlib,zipfile
P=Path('/tmp');A=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/docs/audits/2026-10-17-publication-substance-construction');prefix='l1_k4_shared_square_protected_free2';zp=A/(prefix+'_evidence.zip');mp=A/(prefix+'_manifest.json')
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(p.read_bytes())
m=json.loads(mp.read_text());assert sha(zp)==m['archive_sha256']=='c2f32c64be701b859d4847192dba8aa1c2977348e3b7aad879c48ca1fb9d5af2';z=zipfile.ZipFile(zp);entries=m['files'];assert len(entries)==len(z.namelist())==len(set(z.namelist()))==94 and {e['member'] for e in entries}==set(z.namelist()) and z.testzip() is None
for e in entries:
 b=z.read(e['member']);assert len(b)==e['bytes'] and digest(b)==e['sha256'] and b==Path(e['origin']).read_bytes()
def obj(n):return json.loads(z.read(n))
def records(stem):return [json.loads(l) for l in z.read(stem+'.out').decode().splitlines()]
def exit0(n):
 e=obj(n);assert e.get('exit_code',e.get('actual_child_exit',e.get('actual_exit')))==0
 if 'driver_exit_code' in e:assert e['driver_exit_code']==0 and not e['parent_timeout']
 if 'actual_driver_exit' in e:assert e['actual_driver_exit']==0 and not e['parent_timeout']
 return e
roster=obj('l1-residual40-author-original-evidence-roster.json');am=obj('l1-residual40-author-original-evidence-manifest.json');assert roster['file_count']==len(roster['author_files'])==am['file_count']==len(am['author_entries'])==43
for p,e in zip(roster['author_files'],am['author_entries']):assert p==e['path'] and z.read(Path(p).name)==Path(p).read_bytes() and digest(z.read(Path(p).name))==e['sha256'] and len(z.read(Path(p).name))==e['bytes']
assert len(m['prior_read_only_inputs'])==2 and m['prior_read_only_inputs']==am['supporting_existing_inputs']==roster['supporting_existing_inputs']
for e in m['prior_read_only_inputs']:assert digest(z.read(Path(e['path']).name))==e['sha256'] and len(z.read(Path(e['path']).name))==e['bytes'] and 'read only' in e['ownership']
installed=A/'l1_extended_offset_witness_k4_shared_square_protected_free_tori.py';source='l1-residual40-author-source-r1.py';psha='0cf1a5ad661240a518c1f03d66f53b71ca7d25b26dca687614ad82b7c33f73a1';ssha='a30dacedacc857ae1cf8ce32db6b4b2a62ee2cdfc33e890bf601995bfd942a98';assert sha(installed)==digest(z.read(installed.name))==psha and digest(z.read(source))==ssha
of={n.name:n for n in ast.parse(z.read(source)).body if isinstance(n,ast.FunctionDef)};pf={n.name:n for n in ast.parse(installed.read_text()).body if isinstance(n,ast.FunctionDef)};assert all(ast.dump(of[k],include_attributes=False)==ast.dump(pf[k],include_attributes=False) for k in ('geometry','data','prepare','contraction','branches','solve'))
binding=obj('l1-residual40-author-binding.json')['principal_source_sha256'];assert len(binding)==16 and all(sha(A/n)==h for n,h in binding.items());D=192**42*4**64*48**6*2**15
f=next(n for n in ast.parse(z.read('l1-110153-review-fixed-receipts.py')).body if isinstance(n,ast.FunctionDef) and n.name=='product_branches');ns={'F':F,'combinations_with_replacement':combinations_with_replacement};exec(compile(ast.Module(body=[f],type_ignores=[]),'independent_Fraction45','exec'),ns)
full={};preps={};fullbranches={};fullstats={};fixedstats={}
for word in (110,153):
 linked,other,free=((1,5),(9,13),(3,7,11,15)) if word==110 else ((0,4),(8,12),(2,6,10,14));expected=ns['product_branches'](linked,other,free)
 for mode in ('full','fixed'):
  stem=('l1-residual40-author-pilot110-r1' if word==110 else 'l1-residual40-author-full153-r1') if mode=='full' else f'l1-residual40-author-fixed{word}-r1'
  rs=records(stem);start,prep,warm=rs[:3];bs=rs[3:-1];last=rs[-1];ex=exit0(stem+'.exit.json');assert not z.read(stem+'.err') and ex['full_wall_seconds']<665 and last['preparation_seconds']==prep['seconds']<600 and (last['whole45_warm_seconds'])<60
  assert len(bs)==len(prep['support_domains'])==prep['branches']==last['branches']==45 and prep['divisor']==last['divisor']==D and start['principal_source_sha256']==binding and start['source_sha256']==last['source_sha256']==ssha
  total=F();raw=F();empty=0;computedzero=0
  for i,(b,s,(w,core)) in enumerate(zip(bs,prep['support_domains'],expected)):
   assert b['kind']==('exact-branch' if mode=='full' else 'exact-fixed-branch') and b['branch']==s['branch']==i and b['word']==word and s['protected_branch_index']==i//3 and s['free_branch_index']==i%3
   assert F(*b['weight'])==F(*s['weight'])==w and {q:tuple(tuple(v) for v in ds) for q,ds in s['core_domains']}==core and b['divisor']==D and F(b['raw_numerator'],D)==F(*b['coefficient'])
   flag=b['algebraic_empty_preparation'] if mode=='full' else b['structural_empty_preparation'];assert flag==s['algebraic_empty_preparation' if mode=='full' else 'structural_empty_preparation'];empty+=flag;computedzero+=not flag and b['raw_numerator']==0
   audit=s['prepared_graph']
   if flag:assert audit is None and b['raw_numerator']==0 and b['peak_rows']==0
   else:
    assert audit['factors']==38 and audit['labels']==32 and audit['all_labels_twice'] and {int(q):d for q,d in audit['site_degrees'].items()}==dict.fromkeys(range(16),8) and len(audit['source_factors'])==2
    if mode=='full':assert all(any(tuple(tuple(p) for p in v['labels'][:2])!=((0,0),(1,1)) for v in c['rows']) for c in s['center_support'])
   total+=w*F(*b['coefficient']);raw+=w*b['raw_numerator']
  assert raw.denominator==1 and raw.numerator==last['raw_numerator'] and total==F(*last['coefficient']) and max(b['peak_rows'] for b in bs)==last['peak_rows']
  assert prep['all_Grassmann_sites']==list(range(16)) and prep['omitted_action_center_retained_Grassmann_site']==(4 if word==110 else 5) and prep['sources']==prep['fixed_sources']==[[0,2],[1,2]] and prep['row_cap']==120000 and prep['pair_cap']==3000000
  if mode=='full':
   assert empty==0 and computedzero==18 and prep['restrictions']==[] and total==F(461966234549968960425,140737488355328);full[word]=last;preps[word]=prep;fullbranches[word]=bs;fullstats[word]={'coefficient':last['coefficient'],'actual_peak':last['peak_rows'],'cold_seconds':prep['seconds'],'whole45_warm_seconds':last['whole45_warm_seconds'],'parent_seconds':ex['full_wall_seconds']}
  else:assert empty==30 and computedzero==0 and total==F(1901385366902249675,8923232590303029767153123328);fixedstats[word]={'coefficient':last['coefficient'],'actual_peak':last['peak_rows'],'nonempty':15,'structural_empty':30}
for a,b in zip(fullbranches[110],fullbranches[153]):assert all(a[k]==b[k] for k in ('branch','weight','raw_numerator','divisor','coefficient'))
for a,b in zip(preps[110]['support_domains'],preps[153]['support_domains']):
 assert {q^1:ds for q,ds in a['core_domains']}==dict(b['core_domains']) and {c['center']^1:{k:v for k,v in c.items() if k!='center'} for c in a['center_support']}=={c['center']:{k:v for k,v in c.items() if k!='center'} for c in b['center_support']}
 targets={tuple(f['source']):f for f in b['prepared_graph']['source_factors']}
 for src in a['prepared_graph']['source_factors']:
  target=targets[src['source'][0]^1,src['source'][1]];poly=[]
  for term in src['polynomial']:
   m=term['mask'];sign=(-1)**sum(((m>>(8*q))&255).bit_count()*((m>>(8*(q^1)))&255).bit_count() for q in range(0,16,2));shift=sum(((m>>(8*q))&255)<<(8*(q^1)) for q in range(16));poly.append((shift,sign*term['real'],sign*term['imag']))
  assert sorted(poly)==sorted((v['mask'],v['real'],v['imag']) for v in target['polynomial'])
rep=records('l1-110-review-replay-r2');rex=exit0('l1-110-review-replay-r2.exit.json');rb=[v for v in rep if v['kind']=='exact-branch'];pr=[v for v in rep if v['kind']=='prepared-branch'];assert len(rb)==len(pr)==rex['actual_complete_branch_records']==45 and rex['parent_seconds']<665 and rep[-1]['cold_seconds']<600 and rep[-1]['whole45_warm_seconds']<60 and rep[-1]['coefficient']==full[110]['coefficient'] and rep[-1]['raw_numerator']==full[110]['raw_numerator']
assert all(all(r[k]==b[k] for k in ('branch','weight','raw_numerator','divisor','coefficient')) for r,b in zip(rb,fullbranches[110])) and all(p['original_L_all_center_rows_equal'] and p['all15centers_beyond_fixed'] and p['all16site_degrees8'] and p['bothsource_polynomials_equal_pilot'] for p in pr)
r1=obj('l1-110-review-replay.exit.json');assert r1['actual_child_exit']==r1['actual_driver_exit']==1 and r1['actual_complete_branch_records']==0 and b'AssertionError' in z.read('l1-110-review-replay.err');an=obj('l1-110-review-replay-attempt1-annotation.json');assert an['only_runtime_assertion_normalization_changed'] and an['schema_mock_normalized_assertion_passes']
for f,k in [('l1-110-review-replay.py','original_runner_sha256'),('l1-110-review-replay-driver.py','original_driver_sha256'),('l1-110-review-replay.out','original_stdout_sha256'),('l1-110-review-replay.err','original_stderr_sha256'),('l1-110-review-replay.exit.json','original_exit_sha256')]:assert digest(z.read(f))==an[k]
# Recorded direct tests and all accepted script/output hashes preserved exactly.
direct=records('l1-110153-review-direct');de=exit0('l1-110153-review-direct.exit.json');assert direct[-1]['kind']=='direct-controls-complete' and direct[-1]['fixed_scalar_replays_run']==direct[-1]['unrestricted_coefficients_run']==0 and de['parent_seconds']<665
assert sum(x.get('cartesian_formula_checks',0) for x in direct)==98 and sum(x.get('joint_nineface_closures',0) for x in direct)==14
for vf in ('l1-110153-review-direct-verification.json','l1-110153-review-fixed-receipts-verification.json','l1-110153-review-class-verification.json'):
 for f,h in obj(vf)['files_sha256'].items():assert digest(z.read(Path(f).name))==h
# Counter metadata: original110 bad, original153 and independentr2 good; the static mock proof remains separately labeled.
pe=obj('l1-residual40-author-pilot110-r1.exit.json');assert pe['complete_raw_branch_records']==0 and len(fullbranches[110])==45
obs=obj('l1-residual40-author-pilot110-record-contract-observation.json');assert obs['pass'] is False and obs['counter_checks'][0]['actual_fixture_count']==0
contract=obj('l1-residual40-author-full153-record-contract.json');assert contract['pass'] is True and contract['counter_checks'][0]['actual_fixture_count']==45 and obj('l1-residual40-author-full153-r1.exit.json')['complete_raw_branch_records']==45
annotation=obj('l1-residual40-author-pilot110-r1-validation.json');assert annotation['stdout_sha256']==digest(z.read('l1-residual40-author-pilot110-r1.out')) and annotation['exit_sha256']==digest(z.read('l1-residual40-author-pilot110-r1.exit.json'))
# Actual installed portable CLI: all outputs contain identical16 sibling/evaluator bindings.
clistats={}
for tag in ('census','fixed','110'):
 stem='l1-110153-portable-cli-'+tag;ex=exit0(stem+'.exit.json');rs=records(stem);assert ex['reason']=='terminal' and ex['actual_parent_wall_seconds']<ex['whole_process_limit_seconds'] and ex['source_sha256']==psha and not z.read(stem+'.err');clistats[tag]=ex
 for r in rs:assert r['source_sha256']==dict(binding,evaluator=psha) and r['manifest_sha256']=='ada6e3a7bd8b32b238a85f1a8e7070dde1d2846f5fe6bc5184068a0fc9596d5b' and r['row_cap']==120000 and r['pair_cap']==3000000
 if tag=='census':assert len(rs)==1 and rs[0]['valid_words']==[110,153] and [r['word']['index'] for r in rs[0]['entries']]==[110,153]
 elif tag=='fixed':assert [r['word'] for r in rs]==[110,153] and all(r['branches']==45 and r['coefficient']==[1901385366902249675,8923232590303029767153123328] for r in rs)
 else:
  assert len(rs)==1;cli=rs[0];assert cli['branches']==45 and cli['word']['index']==110 and cli['coefficient']==full[110]['coefficient'] and cli['raw_numerator']==full[110]['raw_numerator'] and cli['divisor']==D and cli['peak_rows']==5632 and cli['preparation_seconds']<600 and cli['whole45_warm_seconds']<60
  assert cli['Grassmann_sites']==list(range(16)) and cli['omitted_action_center_retained_site']==4 and cli['sources']==cli['fixed_sources']==[[0,2],[1,2]] and cli['fixed_action_edges']==[[[4,5,0],[[5,0]]]] and cli['live_action_labels']==[[1,0]]
assert obj('l1-residual40-author-source-attempt1.json')['exit_code']==1
copies={'derivation.md':'l1-residual40-author-derivation.md','design_review.md':'l1-residual40-review.md','design_verification.json':'l1-residual40-review-verification.json','direct_review.md':'l1-110153-review-direct.md','direct_verification.json':'l1-110153-review-direct-verification.json','fixed_review.md':'l1-110153-review-fixed-receipts.md','fixed_verification.json':'l1-110153-review-fixed-receipts-verification.json','review.md':'l1-110153-review-class.md','verification.json':'l1-110153-review-class-verification.json','portable_review.md':'l1-110153-review-portable.md','portable_verification.json':'l1-110153-review-portable-verification.json'}
assert all((A/(prefix+'_'+k)).read_bytes()==z.read(v) for k,v in copies.items())
result={'verdict':'ACCEPT complete110/153 portable CLI and canonical original-evidence archive','archive_sha256':sha(zp),'manifest_sha256':sha(mp),'all94_unique_members_CRC_size_hash_originbytes_match':True,'author43_complete':True,'two_prior_readonly_inputs_preserved_labeled':True,'installed_portable_sha256':psha,'six_original_scientific_ASTs_equal_a30':True,'principal16_and_allCLI17_bindings_match':True,'full90_branch_exact_arithmetic_and_domain_sourcecovariance':True,'fixed90_branch_exact_arithmetic':True,'direct98_Cartesian14_nineface_originals_preserved':True,'independent_replay45_complete_verified':True,'failed_replay_r1_and_successful_r2_originals_preserved':True,'original_author110_wrongcounter_preserved_annotated':True,'correct153_counter_and_staticmock_preserved':True,'actual_peaks_not_forced_equal':{'unrestricted110':5632,'unrestricted153':3024,'fixed110':1368,'fixed153':540},'actual_CLI':clistats,'actual_CLI110_cold':cli['preparation_seconds'],'actual_CLI110_whole45_warm':cli['whole45_warm_seconds'],'coefficient_each':full[110]['coefficient'],'sameaxis_subtotal':[461966234549968960425,70368744177664],'portable_scope_after_ROOT_acceptance':234,'same_after_ROOT_acceptance':140,'mixed_after_ROOT_acceptance':94,'remaining':38,'remaining_same':24,'remaining_mixed':14,'canonical_review_copies_identical':True,'no_additional_scientific_compute':True,'full_k4_sourceaction_commonZ_B3_modes_transport_main_publication':'OPEN'}
(P/'l1-110153-review-final-archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
