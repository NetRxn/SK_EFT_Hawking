from ast import literal_eval as lit
from collections import Counter
from itertools import combinations
from pathlib import Path

exec(Path('independent-support.py').read_text())
states=census(503841882182,1461451755920)
schema={}
for line in Path('schema.tsv').read_text().splitlines():
    name,labels,physical,n,r,den=line.split('\t')
    schema[name]=(lit(labels),lit(physical),int(n),int(r),int(den))
data=[]
unbound={}
value_masks={}
for line in Path('block-index.tsv').read_text().splitlines():
    name,l,start,length,rows,den=line.split('\t')
    scope=schema[name][0]
    row=lit(l)
    i=len(data)
    bit=1<<i
    data.append((name,row,int(start),int(length),int(rows),int(den)))
    for k,v in zip(scope,row):
        unbound[k]=unbound.get(k,0)|bit
        value_masks[k,v]=value_masks.get((k,v),0)|bit
ALL=(1<<len(data))-1
filter_by_value={(k,v):m|(ALL^unbound[k]) for (k,v),m in value_masks.items()}
axes=tuple(sorted(unbound))
vector=[tuple(s.get(k[1:],(0,0)) for k in axes) for s in states]
assert len(set(vector))==30976
pos={k:i for i,k in enumerate(axes)}
def items(bits):
    while bits:
        bit=bits&-bits
        yield bit.bit_length()-1
        bits^=bit

def collect(k):
    keys=tuple(sorted({w for s in k for w in schema[s][0]}))
    ids=tuple(pos[w] for w in keys)
    branches=Counter(tuple(row[i] for i in ids) for row in vector)
    assert sum(branches.values())==len(states)
    entries=[]
    for labels,n in sorted(branches.items()):
        bits=ALL
        for w,v in zip(keys,labels):
            bits&=filter_by_value[w,v]
        chosen=tuple(items(bits))
        assert len({data[i][0] for i in chosen})==88
        entries.append((sum(data[i][4] for i in chosen),sum(data[i][3] for i in chosen),n,labels,chosen))
    return keys,entries

summaries=[]
names=[f'M0{i}' for i in range(8)]
for family in (*combinations(names,2),*combinations(names,3)):
    axes_s,entries=collect(family)
    summaries.append((max(r for r,*_ in entries),len(entries),family,sum(r for r,*_ in entries),max(n for _,_,n,*_ in entries)))
for item in sorted(summaries)[:20]:
    print('peak rows, branches, cut, sum rows, largest support',item,flush=True)
best=min(summaries)
keys,entries=collect(best[2])
Path('cut-axes.tsv').write_text(repr(keys)+'\n')
with Path('cut-plan.tsv').open('w') as f:
    for j,(rows,encoded,support,labels,chosen) in enumerate(entries):
        print(j,support,rows,encoded,labels,chosen,sep='\t',file=f)
assert sum(e[2] for e in entries)==30976
print('best',best,'selected lowest input',min((e[0],i,e[2]) for i,e in enumerate(entries)),flush=True)
