# L1 dense signed contraction pause

Profile `(503841882182, 1461451755920)` has 30,976 support states. The cut at M01/M06 partitions them into 3,872 disjoint groups of eight. `cut-plan.tsv` records the cut and `selected-branch.tsv` selects branch 128. The source normalization is `+1/(16*4^64)`.

Branch 128 started with 88 factors and 1,792,198 rows. Two exact conditional quotient sweeps reduced the total to 435,604 rows. Further bounded contraction and saturation left an exact 12-factor frontier with 1,067,872 stored rows. The next join was refused before mutation at 1,439,712 predicted matched products. No signed coefficient was obtained.

Extract this archive into a scratch directory. Run `shasum -a 256 -c manifest.sha256`, then `gzip -dk frontier.pkl.gz` and `shasum -a 256 -c frontier-uncompressed.sha256`. The locally produced pickle is the prejoin frontier from `contract-final.py`. Reuse it for the next conditional quotient or exact physical partition. The scripts and logs document the preceding passes. The reuse study measures input selection only.

The independent checkpoint in `independent/CHECKPOINT.md` records verified state selection and source bindings for all eight assignments. Two reference cases reached seven factors and exceeded their join caps. Six were untouched. The independent replay can be reconstructed from the recorded bindings and the compiled and independently audited source archives linked from the disposition map. No independent subtotal is available.

The independently accepted residual stays at 9,547 orbits and 821,655 labels. The full original c0 and physical B3 remain open.
