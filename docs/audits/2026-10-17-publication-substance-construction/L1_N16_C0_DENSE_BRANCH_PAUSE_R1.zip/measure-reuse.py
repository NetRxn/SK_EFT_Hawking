from ast import literal_eval as lit
from pathlib import Path
from collections import defaultdict
blocks=[]
for line in Path('block-index.tsv').read_text().splitlines():
    name,local,start,size,r,den=line.split('\t')
    blocks.append((name,int(r)))
seen=defaultdict(set)
visits=0
slices=0
for line in Path('cut-plan.tsv').open():
    idx,support,n,bytes_,labels,raw=line.split('\t')
    numbers=lit(raw)
    grouped=defaultdict(list)
    for i in numbers:
        grouped[blocks[i][0]].append(i)
    assert len(grouped)==88
    visits+=sum(blocks[i][1] for i in numbers)
    slices+=1
    for name,items in grouped.items():seen[name].add(tuple(items))
assert slices==3872
unique=sum(sum(sum(blocks[i][1] for i in items) for items in variants) for variants in seen.values())
assert visits==10581286320
print('conditioned branches',slices,'factor selections without reuse',slices*88,
      'unique factor selections',sum(map(len,seen.values())))
print('row visits without selection reuse',visits,'within unique input selections',unique)
print('isolated input-selection reuse bound',round(visits/unique,3))
