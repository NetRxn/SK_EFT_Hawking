from hashlib import file_digest
from pathlib import Path
P=Path('.')
D=Path('/private/tmp/l1-dense-streamed-cut.TKHkIW')
prior=Path('/private/tmp/l1-dense-input-review.f0tPeN')
def read_manifest(path):
    return {name.removeprefix('./'):sha for sha,name in (l.split(maxsplit=1) for l in path.read_text().splitlines())}
def verify(p,sha):
    with p.open('rb') as r:
        assert file_digest(r,'sha256').hexdigest()==sha,p
frozen=read_manifest(D/'branch-input.sha256')
for name in ('cut-plan.tsv','cut-axes.tsv'):
    verify(D/name,frozen[name])
assert (P/'cut-axes.tsv').read_bytes()==(D/'cut-axes.tsv').read_bytes()
row,=[l.split('\t') for l in (D/'cut-plan.tsv').read_text().splitlines() if l.split('\t')[0]=='128']
assert row[0:2]+row[4:5]==(P/'cut-plan-128.tsv').read_text().strip().split('\t')
for name in ('normalization.out','geometry-check.out','wire-check.out','coverage.out'):
    verify(prior/name,read_manifest(prior/'manifest.sha256')[name])
site={f'site/{i}-{t}-{x}-{kind}.tsv' for l in (P/'binding.tsv').open() for _,t,x,i in [l.split()] for kind in ('root','mask')}
edges={f'rays/{int(l.split()[-1]):02}.tsv' for l in (P/'edge-map.tsv').open()}
for uses,manifest in ((site,'SITE/site-factors.sha256'),(edges,'AUTHOR/edge-factors.sha256')):
    digests=read_manifest(P/manifest)
    for f in sorted(uses):
        verify(P/'RAW'/f,digests[f])
    print('direct audited files',manifest,len(uses))
author=read_manifest(P/'AUTHOR/manifest.sha256')
for f in ('temporal.tsv','edge-plan.out','edge-bindings.tsv'):
    verify(P/'AUTHOR'/f,author[f])
print('continued factor authority and exact cut bytes verified')
