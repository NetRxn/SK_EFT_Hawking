from fractions import Fraction
from pathlib import Path
from re import fullmatch
import sys

values={}
for p in sorted(Path('.').glob('*.out')):
    if not p.name.startswith(('replay-','retry-','partition-')):continue
    for l in p.open():
        if not l.startswith('EXACT '):continue
        m=fullmatch(r'EXACT (\d+) (\S+)\n',l)
        if not m:continue
        c,q=m.groups()
        c=int(c)
        value=Fraction(q)
        assert values.setdefault(c,value)==value
channels={}
for l in Path('channels.tsv').open():
    i,j,s=l.split('\t')
    channels[int(i)]=(int(j),s.rstrip('\n'))
assert set(channels)==set(range(8)) and set(values)<=set(channels)
if '--final' in sys.argv:assert set(values)==set(channels)
with Path('signed-states.tsv').open('w') as f:
    for i,(j,ch) in sorted(channels.items()):
        if i in values:print(i,j,values[i],ch,sep='\t',file=f)
print('verified assignments',sorted(values),'missing',sorted(set(channels)-set(values)))
print('sign counts positive/negative/zero',*(list((q>0)-(q<0) for q in values.values()).count(k) for k in (1,-1,0)))
if values:print('exact sum over completed states only',sum(values.values(),Fraction(0)))
if set(values)!=set(channels):print('branch 128 value OPEN')
