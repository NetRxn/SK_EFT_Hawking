set -eu
test ! -f PAUSE || { echo 'Checkpoint is paused. Restore the local RAW link and clear PAUSE only when authorized.' >&2; exit 2; }
export PYTHONDONTWRITEBYTECODE=1
c=$1
case "$c" in 0|1|2|3|4|5|6|7) ;; *) exit 2 ;; esac
python3 replay.py 503841882182-1461451755920 "$c" "$((c+1))"
