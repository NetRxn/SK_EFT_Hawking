from ast import literal_eval
from itertools import product
from pathlib import Path
from support import census,occupancy

a,b=503841882182,1461451755920
keys=tuple((t,x,k) for _,t,x,k in literal_eval(Path('cut-axes.tsv').read_text()))
branch,n,s=Path('cut-plan-128.tsv').read_text().split('\t')
assert int(branch)==128 and len(set(keys))==len(keys)==16
target=literal_eval(s)
assert len(keys)==len(target)
z=(0,0)
full=census(a,b)
matches=[(original_id,st) for original_id,st in enumerate(full) if tuple(st.get(k,z) for k in keys)==target]
assert len(matches)==int(n)==8
site={}
def scope(x):
    return tuple(sorted((t,y,k) for t,k in product(range(2),range(3)) for y in (x,x^(1<<k))))
for l in Path('SITE/locations.tsv').open():
    c,t,x,labels=l.split('\t')
    c,t,x=map(int,(c,t,x))
    token=t,x,literal_eval(labels)
    assert token not in site
    site[token]=c
occ=tuple(occupancy(c) for c in (a,b))
E={}
for l in Path('AUTHOR/edge-bindings.tsv').open():
    t,u,v,k,row,i=l.split('\t')
    t,u,v,k,i=map(int,(t,u,v,k,i))
    E[t,u,v,k,literal_eval(row)]=i
shapes=[literal_eval(x[8:x.rindex(')')+1]) for x in Path('AUTHOR/edge-plan.out').open() if x.startswith('pattern ')]
with Path('states.tsv').open('w') as ss,Path('channels.tsv').open('w') as ids,Path('binding.tsv').open('w') as bind,Path('anchor-plan.tsv').open('w') as anchor,Path('edge-map.tsv').open('w') as edge:
    for j,(original,st) in enumerate(matches):
        print(j,original,repr(tuple(sorted(st.items()))),sep='\t',file=ids)
        for (t,x,k),(p,q) in sorted(st.items()):
            print(j,t,x,k,p,q,sep='\t',file=ss)
        for t,x in product(range(2),range(8)):
            token=tuple(st.get(k,z) for k in scope(x))
            print(j,t,x,site[t,x,token],sep='\t',file=bind)
        for t,u,k in product(range(2),range(8),range(3)):
            if u>>k&1:continue
            v=u^(1<<k)
            loads=tuple(sum(occ[t][x])-occ[t][x][k] for x in (u,v))
            row=tuple(st.get((s,x,k),z) for s in range(2) for x in (u,v))
            i=E[t,u,v,k,row]
            local=tuple((sum(loads),*st.get((t,x,k),z),*st.get((1-t,x,k),z)) for x in (u,v))
            assert shapes[i]==(*loads,*local)
            print(j,t,u,v,k,i,sep='\t',file=edge)
            for x,S in zip((u,v),local):
                print(j,t,x,k,*S,sep='\t',file=anchor)
print('conditioned branch',branch,'independent states',len(matches),'census positions',[j for j,_ in matches])
