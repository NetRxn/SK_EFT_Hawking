# L1 exact odd-root pilot, author result

For original representative (103607566400,1256282136720), weight 96,
the exact author coefficient is
20706441900927168861083984375/1267650600228229401496703205376.
Four open pair representatives have positive real values in
pilot-value.out. The other 14 pairs already have independent zero
certificates. Exchange contributes each solved value twice.
The residual is unchanged pending independent verification.

For a shared bond tuple x, write A(x,u)=g_x P_j(u), where g_x is an
integer gcd times a Gaussian unit and P_j is the exact primitive
slice. Group slices only when all sorted sparse entries and signed
coefficients of P_j agree. Then
sum_x A(x,u) B(x,v) = sum_j P_j(u) sum_(x in j) g_x B(x,v).
The rewrite remains exact with all other indices open. Every label
is packed into disjoint fixed-width fields and equality compares full
slices. Support gaps are removed exactly. The 128 small direct controls
cover missing support, nontrivial phases, and exact cancellation.

The sums multiply both factor denominators and keep the original
insertion multiplicity factorial product 186624. Each EHC insertion
has two quarter-normalized coframes. There are 32 insertions, hence
an additional 4^64 divisor because the frozen coframe source rows
strip the quarters. The original spatial epsilon parity is even in
both layers (axis occupancy sums 8 and 24). The separately checked
cross-site Grassmann sign is also positive in each layer. All four
results have zero imaginary part.

The former closing search reached the 400M visit cap while streaming
individual matched configurations, and the tested single-mask
slicing schedule exceeded the sparse allocation guard. Neither was
used for coefficient extraction. On the first hard channel, the
five-factor quotient reduces 1,155,584 live rows to 144 and completes
in 312 signed products. Starting from the 72 original factors and
applying the same identity before and between joins reproduces that
channel and gives the other three. The 3,821 to 5,479 reported products
count actual signed joins, excluding scans, gcd work and factor
assembly. The local table inputs are the recovered legacy factors
and accepted zero-pair mapping from the previous checkpoints.

## Replay

From this archive's scratch directory, restore OLD, SEWN and the
previous exact frontier5 using the earlier pinned archives. OLD
contains the nine-state anchor tables. SEWN contains the regenerated
spatial and site factors for those nine states.

```sh
python3 quotient_controls.py
for case in 5 6 7 8; do
  python3 quotient_pilot.py "$OLD" "$SEWN" "$case" > "quotient-pilot$case.out"
done
python3 quotient_close.py > quotient.out
shasum -a 256 -c quotient-manifest.sha256
```

The five-factor replay prints the value before the 4^64 coframe
divisor. Divide it once by 4^64 to compare with legacy case 5.
The original active candidate and publication gates remain open.
