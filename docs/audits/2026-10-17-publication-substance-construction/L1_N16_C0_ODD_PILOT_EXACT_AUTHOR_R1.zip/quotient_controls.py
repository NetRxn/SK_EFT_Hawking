# Stress the exact rewrite with support gaps and all four complex phases.
from collections import Counter,defaultdict
from dataclasses import dataclass,field
from functools import lru_cache
from math import gcd
from pathlib import Path
from random import Random
WORK=1_000_000
ROWS=100_000
BITS=256
s=Path('compact-boundary.py').read_text()
exec(s[s.index('@dataclass'):s.index('def bind(')])
part=s[s.index('def width('):s.index('def prune(')]
exec(part[:part.index('for f in factors:')]+part[part.index('def indices'):])
s=Path('quotient_pilot.py').read_text()
exec(s[s.index('def unpack_columns('):s.index('# Direct Gaussian control')])
u,v,w=(('G',0,0,k) for k in range(3))
rng=Random(141)
checks=0; grouped=0
for seed in range(128):
    left={}
    right={}
    for a in range(7):
        scale=rng.choice((1,2,4,12))
        phase=rng.randrange(4)
        pat=[[ (1,0), (0,2), (1,-2)],[(0,1),(-2,1),(0,0)]][a%2]
        if a!=4:
            for b,(r,i) in enumerate(pat):
                if r or i:left[encode((u,v),(a,b))]=rotate(r*scale,i*scale,phase)
        if a!=5:
            for c in range(4):
                r,i=rng.randrange(-2,3),rng.randrange(-2,3)
                if r or i:right[encode((u,w),(a,c))]=r,i
    A=Factor('A',(u,v),left,3)
    B=Factor('B',(u,w),right,5)
    original=join(A,B,(u,),work(A,B,(u,)))
    count,distinct,changed=squeeze(A,B,(u,))
    assert changed
    result=join(A,B,(u,),work(A,B,(u,)))
    assert original.rows==result.rows and original.denom==result.denom and original.wires==result.wires
    checks+=1
    grouped+=count-distinct
print(checks,'direct exact controls with support gaps and Gaussian phases;',grouped,'slice merges')
