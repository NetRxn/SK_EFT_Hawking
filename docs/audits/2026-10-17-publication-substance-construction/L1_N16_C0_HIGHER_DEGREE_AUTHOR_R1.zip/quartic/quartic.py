from collections import defaultdict
from functools import cache
from itertools import product
from math import comb,prod
from pathlib import Path
import sys
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import Polynomial, QComplex, Symbol, haar_polynomial

q=tuple(tuple(Polynomial.variable(Symbol('q',(0,0,chirality,j))) for j in range(4)) for chirality in ('L','R'))
U=original_spin4_link(*q)
I=(1,0,0,0)
V=defaultdict(int,{(h,a,b,i):s for h,a,b,i,s in (map(int,row.split()) for row in Path(sys.argv[1]).read_text().splitlines())})
linear={(a,b):sum((2*V[h,a,b,i]*q[h][i+1] for h,i in product(range(2),range(3))),Polynomial())
        for a,b in product(range(4),repeat=2) if a!=b}

@cache
def matrix(h,n,inverse):
    coords=q[h]
    if inverse:
        coords=(coords[0],*(-v for v in coords[1:]))
    S=original_spin4_link(*((coords,I) if h==0 else (I,coords)))
    j=2*h
    W=tuple(tuple(S[j+a][j+b] for b in range(2)) for a in range(2))
    if n==0:return ((Polynomial.coerce(1),),)
    if n==1:return W
    (a,b),(c,d)=W
    if n==2:
        return ((a*a,a*b,b*b),(2*a*c,a*d+b*c,2*b*d),(c*c,c*d,d*d))
    assert n==3
    def power(p,n):
        result=Polynomial.coerce(1)
        for _ in range(n):
            result*=p
        return result
    return tuple(tuple(sum((comb(n-j,i-k)*comb(j,k)*
                            power(a,n-j-i+k)*power(c,i-k)*power(b,j-k)*power(d,k)
                           for k in range(max(0,i-(n-j)),min(i,j)+1)),Polynomial())
                       for j in range(n+1)) for i in range(n+1))


roster={((),()):Polynomial.coerce(1)}
for power in range(1,5):
    next_roster=defaultdict(Polynomial)
    for (left,right),parent in roster.items():
        for (a,b),term in linear.items():
            key=tuple(sorted((*left,a))),tuple(sorted((*right,b)))
            next_roster[key]+=parent*term
    roster=next_roster
    print('grouped words',power,len(roster),flush=True)
    if power==2:
        expected=defaultdict(Polynomial)
        for left,right in product(linear,repeat=2):
            key=tuple(sorted((left[0],right[0]))),tuple(sorted((left[1],right[1])))
            expected[key]+=linear[left]*linear[right]
        assert expected==roster
    if power==4:
        check=Polynomial()
        for words in product(((0,1),),repeat=4):
            term=Polynomial.coerce(1)
            for word in words:
                term*=linear[word]
            check+=term
        assert roster[(0,)*4,(1,)*4]==check

with Path('quartic-scalar.tsv').open('w') as out:
    nonzero=0
    for (left,right),value in sorted(roster.items()):
        projected=haar_polynomial(value).terms
        if projected:
            ((key,z),)=projected
            assert not key
            print(4,left,right,0,0,0,0,z.real,z.imag,sep='\t',file=out)
            nonzero+=1
    print('quartic scalar nonzero rows',nonzero,flush=True)
