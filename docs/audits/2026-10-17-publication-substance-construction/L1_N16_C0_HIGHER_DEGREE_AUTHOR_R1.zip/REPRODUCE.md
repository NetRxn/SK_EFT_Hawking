# Exact L1 higher-degree author evidence

Both coefficients are reconstructed from final signed logs and the complete anchor roster. Fixed assignments count once and exchanged pairs twice. Raw factor tables remain in local run directories and are pinned by checksum. Both coefficients await independent review.
