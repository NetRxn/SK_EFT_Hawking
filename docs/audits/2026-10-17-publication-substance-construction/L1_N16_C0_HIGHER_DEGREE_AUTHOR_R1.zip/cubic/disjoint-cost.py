from ast import literal_eval
from collections import defaultdict
from fractions import Fraction
from itertools import product
from math import lcm
from pathlib import Path
import sys

base=Path(sys.argv[1])
a,b=map(int,sys.argv[2:4])
S,T=(literal_eval(v) for v in sys.argv[4:6])
assert S[0]==T[0]==a+b
WORK_CAP=8_000_000
ROW_CAP=300_000

H={shape:defaultdict(list) for shape in (S,T)}
scale=1
for row in (base/'spatial.tsv').read_text().splitlines():
    shape,indices,*mat,r,i=row.split('\t')
    shape=literal_eval(shape)
    if shape not in H:continue
    re,im=Fraction(r),Fraction(i)
    scale=lcm(scale,re.denominator,im.denominator)
    H[shape][literal_eval(indices)].append((tuple(map(literal_eval,mat)),re,im))
for table in H.values():
    for q,rows in table.items():
        table[q]=[(mat,int(r*scale),int(i*scale)) for mat,r,i in rows]

C=[defaultdict(list),defaultdict(list)]
for owner,d in enumerate((a,b)):
    if d==0:C[owner][()].append(((),0,1,0))
for owner,d in enumerate((a,b)):
    if not d:continue
    with Path('shards',f'{owner}-{d}.tsv').open() as data:
        for row in data:
            o,word,mask,indices,r,i=row.rstrip('\n').split('\t')
            assert int(o)==owner and len(word)==2*d-1
            C[owner][tuple(map(int,indices.split(',')))].append(
                (tuple(map(int,word.split(','))),int(mask),int(r),int(i)))


from collections import Counter
from functools import cache
masks=[{q:Counter(row[1] for row in rows) for q,rows in side.items()} for side in C]
@cache
def compatible(left,right):
    return sum(a*b for m,a in left for n,b in right if not m&n)
before=after=0
for q1,L in masks[0].items():
    for q2,R in masks[1].items():
        q=tuple(sorted(q1+q2))
        X=H[S].get(tuple(i for i in q if i<8),())
        Y=H[T].get(tuple(i-8 for i in q if i>=8),())
        if X and Y:
            before+=sum(L.values())*sum(R.values())*len(X)*len(Y)
            after+=compatible(tuple(sorted(L.items())),tuple(sorted(R.items())))*len(X)*len(Y)
print('matched before exterior test',before,'admitted after exterior test',after)
