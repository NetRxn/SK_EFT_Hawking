from itertools import product
from temporal import rep
from src.vestigial.original_coefficients import Polynomial

for inverse in (False, True):
    W=rep(1,inverse)
    for n in (0,1,2,3):
        actual=rep(n,inverse)
        for i,j in product(range(n+1),repeat=2):
            col=(0,)*(n-j)+(1,)*j
            expected=Polynomial()
            for row in product(range(2),repeat=n):
                if sum(row)!=i:
                    continue
                term=Polynomial.coerce(1)
                for k,h in zip(row,col):
                    term*=W[k][h]
                expected+=term
            assert actual[i][j]==expected,(n,inverse,i,j)
print('all entries match literal symmetric tensors through cubic degree in both orientations')
