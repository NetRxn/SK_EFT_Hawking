set -eu
export PYTHONDONTWRITEBYTECODE=1
repo=/Users/johnroehm/.codex/worktrees/l1-original-n16-python/SK_EFT_Hawking
python=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python
export PYTHONPATH="$repo"
here=$PWD
(cd AUTHOR && shasum -a 256 -c manifest.sha256) > author-manifest.out
(cd RESIDUAL && shasum -a 256 -c manifest.sha256) > residual-manifest.out
cmp AUTHOR/published-base.tsv RESIDUAL/block-remaining.tsv
python3 support.py > support.out
"$python" normalization.py > normalization.out
"$python" root-rebuild.py > root-rebuild.out
while read -r a b w; do
    p="$a-$b"
    (cd "RAW/$p-tiled" && shasum -a 256 -c "$here/AUTHOR/$p/frozen-factors.sha256") > "factors-$p.out"
    cmp ROOT.tsv "RAW/$p-tiled/root.tsv"
    for f in anchor-plan.tsv states.tsv edge-plan.out temporal.tsv spatial.tsv; do
        cmp "AUTHOR/$p/$f" "RAW/$p-tiled/$f"
    done
    python3 edge-reconstruct.py "$p" > "edges-$p.out"
    "$python" edge-control.py "$p" > "literal-$p.out"
    python3 site-reconstruct.py "$p" > "sites-$p.out"
    python3 replay.py "$p" 0 100 > "replay-$p-0.out"
done < profiles.tsv
awk '$8=="scalar-fixed"{print $1"-"$2}' reviewed-pairs.tsv | while read -r p; do
    python3 scalar-layer-control.py "$p" || exit
done > scalar-layer-control.out
test "$(wc -l < scalar-layer-control.out)" -eq 32
python3 verify-pairs.py --final > verification.out
python3 coverage.py > coverage.out
python3 bounds.py > bounds.out
