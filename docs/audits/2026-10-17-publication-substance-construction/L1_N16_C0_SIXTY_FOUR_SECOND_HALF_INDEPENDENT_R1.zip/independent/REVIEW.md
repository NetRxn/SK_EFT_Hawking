# Independent review of the second 32 profiles of the L1 batch

**ACCEPT all 32 original N16 pure-EHC c0 coefficients.** Every independently computed representative agrees exactly with the frozen terminal author log. These 160 signed contractions cover 224 original support assignments. The signed results contain 72 positive, 36 negative and 52 zero values.

The 32 source profiles each occur at weight 96. The combined weighted contribution is
`73773686554037613158403516323290517781/1237940039285380274899124224`.
Removing their 3,072 labels from the accepted predecessor leaves **9,547 orbits and 821,655 labels**. The source representative IDs, partners, multiplicities and signed values are in `signed-pairs.tsv`. The exact coefficient receipt and order-preserving residual are `reviewed-exact.tsv` and `block-remaining.tsv`.

## Frozen intake and membership

Canonical original source is `51e7c745eccad5e99676cdc8e4b523ad73e617b1`. The author manifest is identical to the one in the published second-half archive, and the accepted residual is identical to the one in the published independent first-half archive, both at checkpoint `42fecc79f`. The frozen author base equals the accepted predecessor byte for byte. All author, predecessor, and factor-file manifest entries verify. The normalized moment tables, edge plan, projected states and representative anchor plan consumed by the reviewer match the raw and frozen intake copies. Only the 32 profile directories named in the frozen intake were used. The continuity packet was fresh at final readback.

## Original support and source signs

I reconstructed the literal occupation-based root degrees and projected domains. Exhaustive finite constraint propagation tests both temporal SU(2) singlets, the combined spatial center parity, and the spatial minimum-load and zero-load equality tests. All 32 profiles have seven assignments. All 10,752 original anchor rows and 7,680 representative anchor rows agree, with anchor-plan IDs used even for the empty sparse all-scalar assignment. The maximum projected product has 16,777,216 candidates and the maximum search has 25 branch nodes. All original occupations have degree zero or two. The common root table covers every admitted case.

The original gamma3 transformation exchanges the labeled Haar blocks and preserves filled site tops. Its EHC sign is even at total insertion degree 32. Exact pairing of the source tuples gives 64 exchanged pairs at multiplicity two, 32 scalar fixed assignments at multiplicity one and 64 nontrivial fixed assignments at multiplicity one. Every profile has fixed source IDs 0, 2 and 5, with ID 0 all-scalar. I also replayed each of the 32 scalar fixed channels as two independently contracted single-layer factors and verified the exact product.

I independently recovered all 512 stripped coframe rows and 768 original four-order EHC folding phases under the canonical normalization. The 32 original EHC insertions yield 64 coframe quarters. Both layers in every profile have even world-epsilon and cross-site wedge signs, checked with 64 literal layouts per layer. The occupation factorial is 65,536 in each profile, with sixteen degree-two occupations and 32 zeros. The literal checks are recorded in `normalization.out`.

## Local factors and signed contraction

- The source common root table matches all 4,920 candidates and 1,718 nonzeros. All 32 pinned local root tables equal the checked table byte for byte. This is the only deduplication used for factor checks.
- Whole temporal Haar moment tables cover 7,016 candidates and 968 nonzeros. Whole spatial moment tables cover 970,580 candidates and 57,012 nonzeros. These totals count each profile's table entries.
- Both signed spatial endpoint alias maps invert exactly, preserving native endpoint matrix indices and reconstructing all 3,453,732 raw rows across 720 profile-specific patterns. Direct source integration checks 1,320 signed targets covering every pattern, including imaginary targets where present. The maximum unfiltered candidate count is 1,048,576. The exterior filter admits at most 31,392 prefixes before direct signed arithmetic. Direct source integration has target-row scope.
- The independent split joins rebuild all 5,120 site factors, comprising 3,457,144 mask and 1,281,752 root rows. This uses exact exterior inversion signs, canonical alias gains, raw words and root matrices. Maximum site mask trial and root product counts are 134,656 and 129,600.
- All 160 independent 88-factor networks use explicit original half-edge orientation and two occurrences of each nontrivial wire. Exact tuple-key Gaussian contraction preserves coefficients under primitive proportional-slice reduction and counts admitted products before joins. Observed maxima are 255,867 initial rows, 139,776 products in a join, 569,823 matched products per network, and 9,122,863 charged scans. All imaginary coefficients vanish and no run exceeded the resource guards.

Run `bash reproduce.sh` with the frozen input symlinks in place. The first-half author paths were outside the new coefficient scope. No repository, manuscript, continuity notebook or Lean slot was changed.
