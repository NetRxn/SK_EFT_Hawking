# Independent acceptance of the second 32 L1 profiles

Verify manifest.sha256, then run `python3 check-residual.py independent/reviewed-exact.tsv`.
Full c0 and physical B3 remain open.
