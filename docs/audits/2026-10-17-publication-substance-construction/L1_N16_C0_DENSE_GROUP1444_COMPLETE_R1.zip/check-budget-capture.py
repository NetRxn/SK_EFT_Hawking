"""Audit the capture-only retry and compare all retained original L6 tables."""
from difflib import unified_diff
from hashlib import file_digest
from pathlib import Path
from pickle import load
from os import environ

ROOT=Path(environ.get('L1_GROUP1444_AUTHOR_ROOT','/private/tmp/l1-component14-bounded-preparation.QaKI9c/group-1444/cached-original-roster'))/'L6'
BUDGET=ROOT/'budget-rescue'
CAP='row-cap-physical-slice-dense-branch.pkl'
ASSERT="    assert costs,('no admitted join',len(factors),work)\n"
CAPTURE="""    if not costs:
        envelope = {
            'factors': factors,
            'used_before': work,
            'rejected_pair': None,
            'matched': None,
            'physical_cut': (wire, value),
            'terminal_reason': 'no eligible native join within unchanged product limits',
        }
        destination = Path(f'row-cap-physical-slice-{index}.pkl')
        with destination.open('xb') as stream:
            pickle.dump(envelope, stream, protocol=5)
        print('open product cap', len(factors), work, 'frontier saved', flush=True)
        raise SystemExit(2)
"""


def digest(p):
    with p.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def main():
    orig=(ROOT/'contract-slice.py').read_text()
    capture=(BUDGET/'contract-slice.py').read_text()
    assert orig.count(ASSERT)==1 and orig.replace(ASSERT,CAPTURE)==capture
    assert (ROOT/'run.py').read_bytes()==(BUDGET/'run.py').read_bytes()
    assert digest(ROOT/'dense-saturated-frontier.pkl')==digest(BUDGET/'dense-saturated-frontier.pkl')
    source=(ROOT/'contraction.out').read_text()
    assert (BUDGET/'contraction.out').read_text()==source+'open product cap 11 3596820 frontier saved\n'
    assert (BUDGET/'contraction.receipt').read_text().startswith('child status 2\n')
    assert not (BUDGET/'contraction.err').stat().st_size
    with Path('L6-native-product-prefix.pkl').open('rb') as f:
        independent=load(f)
    with (BUDGET/CAP).open('rb') as f:
        author=load(f)
    assert set(author)==set(independent)|{'rejected_pair','matched','terminal_reason'}
    assert all(author[k]==v for k,v in independent.items())
    assert author['terminal_reason']=='no eligible native join within unchanged product limits'
    assert author['matched'] is None and author['rejected_pair'] is None
    destination=Path('author/L6/budget-capture')
    destination.mkdir(exist_ok=True)
    for name in ('contraction.out','contraction.err','contract-slice.py','contraction.receipt','run.py'):
        (destination/name).write_bytes((BUDGET/name).read_bytes())
    (destination/'capture-only.patch').write_text(''.join(unified_diff(orig.splitlines(keepends=True),
        capture.splitlines(keepends=True),fromfile='original native input',tofile='capture-only retry')))
    print('original selected seed',digest(ROOT/'dense-saturated-frontier.pkl'))
    print('author product capture',digest(BUDGET/CAP),len(author['factors']),
          sum(len(r) for _,r,_ in author['factors']),author['used_before'])
    print('retained physical axes',len({w for a,_,_ in author['factors'] for w in a}))
    print('reviewer complete signed prefix',digest(Path('L6-native-product-prefix.pkl')))
    print('all retained terms equal; only cap exit changed; no admitted pair or product limit change')


if __name__=='__main__':
    main()
