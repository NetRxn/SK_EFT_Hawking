from csv import DictReader
from pathlib import Path
from re import M, search

file=Path('REVIEW.md')
header='## Exact retally and measured work'
s=file.read_text().split(header,1)[0]+header+'\n'
raw=Path('retally.out').read_text()
num,den=search(r'^raw Gaussian sum (-?\d+) 0 factor denominator (\d+)',raw,M).groups()
value=search(r'^physical weighted (-?\d+/\d+) 0',raw,M)[1]
prep,guards,capture,cont,terminal,total=search(
    r'^author measured preparation/native/capture retry/continuation/extra terminal/total seconds (.*)$',raw,M)[1].split()
ip,ig,ic,it=search(r'^independent measured preparation/native/retained pass sums (.*)$',raw,M)[1].split()
advance=search(r'^author sum of original solve walls plus shared preparation ([\d.]+)',raw,M)[1]
iw=search(r'^independent sum of preparation, native and continuation walls ([\d.]+)',raw,M)[1]
caps=list(DictReader(Path('native-caps.tsv').open(),delimiter='\t'))
work=list(DictReader(Path('signed-work.tsv').open(),delimiter='\t'))
timers=list(DictReader(Path('timing.tsv').open(),delimiter='\t'))
pending_native=sum(int(row['used_before']) for row in caps)
pending_cont=sum(int(row['finished_products']) for row in work)
pending_refuse=sum(int(row['refused_visit_products']) for row in work)
triangle_review=sum(float(row['independent_extra_s']) for row in timers)
s+=f'''
The exact raw Gaussian sum is ({num}, 0) at inherited factor denominator
{den}. Applying the original physical divisor 16 × 4^64 once and the
geometric cover coefficient 192 once gives **{value} + 0i**.

Native guarded prefixes accepted {pending_native:,} product visits across
the six original live scopes. The L6 capture-only retry separately
repeated 3,596,820 accepted visits. Continuations accepted
{pending_cont:,} visits and their 19 row-refused attempts visited
{pending_refuse:,}. All 14 retained passes and every refusal's author
visit count are independently checked. The row and product refusal
ledgers preserve the distinct refusal types and scopes.

Measured author components total {total} seconds, including {prep}
preparation, {guards} initial native work, {capture} for the L6
capture-only retry, {cont} continuation and {terminal} separately timed
triangle terminals. The sum of the original solve walls with preparation
is {advance} seconds. This excludes the separate L6 capture, L6
continuation and both extra triangle terminals. The independent measured
preparation from the bound earlier replay, native review and retained
stage components are {ip}, {ig} and {ic} seconds, with subtotal {it}.
Independent full preceding-phase wall sums are {iw} seconds. The
additional independent third pivots took {triangle_review:.6f} seconds
combined. These are sums across measured stages or ordinal runs, with no
concurrent campaign wall-time inference.

## Reproduction

The archive manifest covers all receipts and the nested accepted
preparation evidence. Original large compiled factor files and exact
author frontiers are checksum-bound external inputs. The replay tools
default to the original cached-original-roster author directory. Set
L1_GROUP1444_AUTHOR_ROOT to relocate the original input tree.

    bash replay-label.sh 0 2 triangle author-order
    bash replay-label.sh 1 3 scalar author-order
    bash replay-label.sh 2 2 triangle author-order
    bash replay-label.sh 3 3 scalar author-order
    bash replay-label.sh 4 2 scalar author-order
    python3 -B product-prefix.py 6
    python3 -B check-budget-capture.py
    bash replay-budget-L6.sh 2
    python3 -B retally.py /path/to/publication-checkpoint

The frozen L6 pin receipt and accepted ordinal roster remain inputs to
the original prefix review. Product replay writes a local full checkpoint
for the capture comparison. The archive carries its checksum and exact
comparison receipt. The replay and the capture check write only beneath
the local evidence directory.
'''
file.write_text(s)
