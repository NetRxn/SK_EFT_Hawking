"""Independently evaluate the whole L2 triangle using the unused third anchor."""
from os import environ
from collections import Counter, defaultdict
from hashlib import file_digest
from math import prod
from pathlib import Path
import json
import sys
from pickle import load
import re
from time import monotonic

CASE=int(sys.argv[1])
DIR=Path(f'author/L{CASE}')
PINS=json.loads((DIR/'pins.json').read_text())
BASE=Path(environ.get('L1_GROUP1444_AUTHOR_ROOT', '/private/tmp/l1-component14-bounded-preparation.QaKI9c/group-1444/cached-original-roster'))/f'L{CASE}'
N=3556628738267424331864217260916736
BOUND=4_000_000
PIN=PINS['terminal_sha']

def project(scope,wires):
    cols=tuple(scope.index(w) for w in wires)
    return lambda row: tuple(row[i] for i in cols)

def build(factors,pivot,other_a,other_b):
    p,X,_=factors[pivot]
    a,A,_=factors[other_a]
    b,B,_=factors[other_b]
    x=tuple(w for w in p if w in a)
    y=tuple(w for w in p if w in b)
    k=tuple(w for w in a if w in b)
    assert x and y and k
    assert set(Counter(x+y+k).values())=={1}
    assert set(p)==set(x+y) and set(a)==set(x+k) and set(b)==set(y+k)
    assert len(p)==len(x+y) and len(a)==len(x+k) and len(b)==len(y+k)
    Z=[]
    for scope,rows,edge in ((a,A,x),(b,B,y)):
        keep,link=project(scope,edge),project(scope,k)
        node=defaultdict(dict)
        for key,value in rows.items():
            peers=node[keep(key)]
            within=link(key)
            assert within not in peers and any(value)
            peers[within]=value
        Z.append(node)
    return X,project(p,x),project(p,y),*Z

def replay(factors,forecast_count):
    X,px,py,L,R=build(factors,2,0,1)
    ordered=sorted(X,reverse=True)
    out=[]
    lo=n=x=y=0
    for row,key in enumerate(ordered):
        left=L.get(px(key),{})
        right=R.get(py(key),{})
        common=left.keys() & right.keys()
        degree=len(common)
        assert degree<=BOUND
        if n+degree>BOUND:
            out.append((lo,row,n,x,y))
            lo=row
            n=x=y=0
        contracted_r=contracted_i=0
        for k in common:
            a,b=left[k]
            c,d=right[k]
            contracted_r+=a*c-b*d
            contracted_i+=a*d+b*c
        a,b=X[key]
        x+=a*contracted_r-b*contracted_i
        y+=a*contracted_i+b*contracted_r
        n+=degree
    out.append((lo,len(ordered),n,x,y))
    assert out[0][0]==0 and out[-1][1]==len(X)
    assert all(l[1]==r[0] for l,r in zip(out,out[1:]))
    assert all(0<n<=BOUND for _,_,n,_,_ in out)
    with (DIR/'third-triangle-shards.tsv').open('w') as f:
        print('anchor','start','stop','triplets','raw_real','raw_imag',sep='\t',file=f)
        for values in out:
            print(2,*values,sep='\t',file=f)
    n,x,y=map(sum,zip(*(row[2:] for row in out),strict=True))
    assert n==forecast_count
    print('third anchor reverse lexical order',len(X),'rows',len(out),'bounded shards',n,'compatible triples',x,y,N,flush=True)
    return x,y

def main():
    start=monotonic()
    with (BASE/f'pass{PINS["passes"]}-result.pkl').open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==PIN
        f.seek(0)
        state=load(f)
    factors=state['factors']
    assert len(factors)==3
    assert all(w[0]!='L' for scope,_,_ in factors for w in scope)
    assert set(Counter(w for scope,_,_ in factors for w in scope).values())=={2}
    assert prod(d for _,_,d in factors)==N
    X,px,py,L,R=build(factors,2,0,1)
    n=sum(len(L.get(px(key),{}).keys() & R.get(py(key),{}).keys()) for key in X)
    print('independent third anchor forecast',CASE,len(X),n,flush=True)
    if '--forecast' in sys.argv:
        return
    assert n<=20_000_000
    del X,L,R
    result=replay(factors,n)
    print(f'whole original L{CASE} triangle raw',*result,N,'elapsed',round(monotonic()-start,6))

if __name__=='__main__':
    main()
