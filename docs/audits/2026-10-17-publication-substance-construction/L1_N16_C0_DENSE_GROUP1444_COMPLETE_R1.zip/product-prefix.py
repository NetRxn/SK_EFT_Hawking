"""Independently reconstruct the untouched L6 native prefix and product refusal."""
import argparse
from itertools import combinations
from pathlib import Path
from pickle import dump
from time import monotonic
from verify import author, forecast, read, sha, validate
import source


def main():
    started=monotonic()
    seed=source.condition()
    assert seed['joint_label_index']==6
    native=(author/'contraction.out').read_text().splitlines()
    joins=[l for l in native if l.startswith('join ')]
    folds=[l for l in native if l.startswith('quotient ')]
    facts=seed['factors']
    validate(facts)
    source.trim(facts)
    source.trim(facts)
    work=0
    for step,expected in enumerate(joins):
        planned,i,j=source.choose(facts,work)
        left,right=facts[i],facts[j]
        matched=planned
        if planned>50_000:
            left,right,n=source.native_fold(left,right)
            right,left,m=source.native_fold(right,left)
            facts[i],facts[j]=left,right
            matched=forecast(left,right)[0]
            assert folds.pop(0)==f'quotient before join {len(facts)} {planned} {matched} slices {n+m}'
        peer=[f for k,f in enumerate(facts) if k not in (i,j)]
        table=source.join(left,right,peer,matched)
        assert len(table[1])<=500_000
        facts=peer+[table]
        source.trim(facts,len(facts)-1)
        if len(facts)%8==0:
            source.trim(facts)
        assert expected==f'join {len(facts)} {matched} {len(facts[-1][1])} axes {len(facts[-1][0])}'
        work+=matched
        print('independent native accepted',step,len(facts),matched,len(facts[-1][1]),work,flush=True)
    assert not folds and len(facts)==11 and work==3_596_820
    assert (author/'contraction.receipt').read_text().splitlines()[0]=='child status 1'
    assert "('no admitted join', 11, 3596820)" in (author/'contraction.err').read_text()
    forecasts=[]
    for i,j in combinations(range(len(facts)),2):
        c=forecast(facts[i],facts[j])
        if c is None: continue
        n,width,count=c
        assert n>8_000_000 or work+n>40_000_000
        forecasts.append((n,i,j,width,count))
    assert forecasts
    with Path('L6-native-product-forecasts.tsv').open('w') as f:
        print('products','left_factor','right_factor','remaining_width','shared_key_count',sep='\t',file=f)
        for item in sorted(forecasts):
            print(*item,sep='\t',file=f)
    validate(facts)
    state={'factors':facts,'physical_cut':seed['physical_cut'],'used_before':work}
    p=Path('L6-native-product-prefix.pkl')
    with p.open('wb') as f:
        dump(state,f,protocol=5)
    print('verified original native product refusal',len(facts),sum(len(f[1]) for f in facts),
          'used',work,'minimum matching pair',min(forecasts),'linked pairs',len(forecasts),
          'independent checkpoint',sha(p),'elapsed',round(monotonic()-started,6),flush=True)


if __name__=='__main__':
    main()
