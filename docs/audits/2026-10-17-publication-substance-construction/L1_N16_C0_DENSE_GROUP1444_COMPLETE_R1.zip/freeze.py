"""Verify frozen signed receipts and create the portable review archive."""
from csv import DictReader
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

GROUP=1444
LIVE=(0,1,2,3,4,6)
root=Path('.')
manifest=Path('MANIFEST.sha256')
archive=Path(f'l1-group{GROUP}-complete-independent-review.zip')

for label in LIVE:
    folder=Path('author')/f'L{label}'
    listed=(folder/'operand.sha256').read_text().splitlines()
    confirmed=(folder/'operand-verify.out').read_text().splitlines()
    assert len(listed)==len(confirmed) and all(line.endswith(': OK') for line in confirmed)
    status=(folder/'replay-guarded.out').read_text()
    if label in (0,2):
        assert f'whole original L{label} exact terminal triangle ready' in status
        assert f'whole original L{label} triangle raw ' in (folder/'triangle-replay.out').read_text()
        assert 'both author signed sums agree' in (folder/'triangle-interval-audit.out').read_text()
    else:
        assert f'whole original L{label} raw ' in status

with Path('native-caps.tsv').open() as f:
    native=list(DictReader(f,delimiter='\t'))
    assert tuple(int(row['ordinal']) for row in native)==LIVE
    assert all(int(row['crossing_rows'])==500_001 and row['type']=='rows' for row in native if int(row['ordinal'])!=6)
    assert native[-1]['type']=='products' and int(native[-1]['projected_matches'])==8_706_048
with Path('signed-work.tsv').open() as f:
    work=list(DictReader(f,delimiter='\t'))
    assert len(work)==14
    for row in work:
        products=int(row['finished_products'])+int(row['refused_visit_products'])
        assert products<=(40_000_000 if row['pass']=='1' else 20_000_000)
with Path('continuation-refusals.tsv').open() as f:
    refusals=list(DictReader(f,delimiter='\t'))
    assert len(refusals)==19
    assert all(row['type']=='rows' and row['independent_visits']==row['author_visits'] and
               int(row['crossing_rows'])==500_001 and int(row['forecast'])<=8_000_000
               for row in refusals)

source=Path('l1-component14-groups1416-1444-preparation-independent.zip')
assert sha256(source.read_bytes()).hexdigest()=='4adadcf6f04d4c2fc6d5833d51c3446cdafe883a4584c0c7596211ec843c67ab'

files=sorted(p for p in root.rglob('*') if p.is_file() and p not in (manifest,archive)
             and '__pycache__' not in p.parts and p.suffix!='.pkl')
assert not any(path.suffix=='.pkl' for path in files)
manifest.write_text(''.join(f'{sha256(path.read_bytes()).hexdigest()}  {path}\n' for path in files))
with ZipFile(archive,'w',compression=ZIP_DEFLATED) as z:
    for path in files+[manifest]:
        z.write(path,str(path))
with ZipFile(archive) as z:
    assert z.testzip() is None
    for line in z.read(str(manifest)).decode().splitlines():
        digest,path=line.split(maxsplit=1)
        assert sha256(z.read(path)).hexdigest()==digest
print('Verified archive manifest members',len(files),archive,sha256(archive.read_bytes()).hexdigest())
