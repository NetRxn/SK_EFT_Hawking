#!/bin/bash
set -euo pipefail
base="$(printenv L1_GROUP1444_AUTHOR_ROOT || printf '%s' '/private/tmp/l1-component14-bounded-preparation.QaKI9c/group-1444/cached-original-roster')"
original="$base/L6"
a="$original/budget-rescue"
d="$PWD/author/L6"
copy="$d/budget-capture"
stage="$1"
export L1_GROUP1444_STAGE_CASE="$a"
python3 -B - "$a" "$stage" <<'PY'
from hashlib import file_digest
from pathlib import Path
import json,re,sys
a=Path(sys.argv[1])
stage=int(sys.argv[2])
def sha(p):
    with p.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()
pins=Path('author/L6/pins.json')
data=json.loads(pins.read_text())
assert data['seed_sha']==sha(a/'dense-saturated-frontier.pkl')
r,i=map(int,re.search(r'exact raw scalar \((-?\d+), (-?\d+)\)',(a/f'pass{stage}.out').read_text()).groups())
data.update(cap_sha=sha(a/'row-cap-physical-slice-dense-branch.pkl'),cap_factors=11,
            cap_type='products',native_refused=None,passes=stage,mode='scalar',
            terminal_sha=sha(a/f'pass{stage}-result.pkl'),expected_raw=r,expected_imag=i)
pins.write_text(json.dumps(data,indent=2)+'\n')
PY
(
 cd "$a"
 shasum -a 256 ../../../dense-saturated-frontier.pkl ../dense-saturated-frontier.pkl ./*.pkl
 cp ./*.py ./*.out "$copy/"
 cp ./pass*.out ./*.time "$d/"
) > "$d/operand.sha256"
cp "$base/solve-L6.out" "$d/solve.out"
cp "$base/solve-L6.time" "$d/solve.time"
python3 -B -u verify.py 6 --author-guard-order > "$d/replay-guarded.out"
(cd "$a" && shasum -a 256 -c "$d/operand.sha256") > "$d/operand-verify.out"
