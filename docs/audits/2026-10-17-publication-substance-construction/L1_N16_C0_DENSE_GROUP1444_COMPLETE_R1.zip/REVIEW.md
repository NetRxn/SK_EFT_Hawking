# Independent complete signed Group 1444 review

Group 1444 is on the accepted selected side of component 14 with original
gamma3 partner 2706. The weight 192 applies to the exact physical group
value and includes the existing occupation weight 48, the gamma3
partner and the selected geometric side once each.

The fresh starting checkpoint is a331109076abbd6638a4124ec9919b941bc26dee.
Its independent preparation archive, included here at SHA-256
4adadcf6f04d4c2fc6d5833d51c3446cdafe883a4584c0c7596211ec843c67ab,
already verifies all 252 selected source blocks, 88 prepared signed
tables and original eight-member support. The prepared frontier is
1a8ad5deea2c5ba400d6fa02b05bd7da53d698f3c57543de6864a51e5b4cb254.
Original ordinals 5 and 7 each have seven empty prepared factor
restrictions and are exact zeros. The six live ordinals retain original
coordinates 0, 1, 2, 3, 4 and 6.

## Native and continuation verification

The reviewer inverse-lifted the original selected signed rows into the
same prepared parent. Five native replays reproduced their retained
tables and crossed the 500,000-row guard. For original ordinal 6 the
untouched native runner instead reported the no-admitted-join assertion
after 77 exact native joins and 3,596,820 accepted visits. The independent
prefix reconstructs all 11 factors and 1,542,976 retained signed rows.
All 37 linked pair forecasts exceed the unchanged 8,000,000 pair
product ceiling. The minimum forecast is 8,706,048 on pair (1,6).

The capture-only retry used the exact original selected seed. Its
source differs solely by replacing the no-admitted-pair assertion with
serialization and the existing guarded status code. The original
arithmetic and limits stay fixed. The full captured terms match the
independently recomputed prefix under the original physical scope,
with author checkpoint SHA-256
7d47d8b9e4797d6b280864d146e743d9812df00bc8e2c992c866183a49a5b641.
The failed original run and the follow-up receipt are both preserved.
The capture repeats the 3,596,820 accepted native visits for custody.
That repetition appears separately in the measured time rather than
as an additional mathematical term.

Each continued stage independently checks the inverse signed splits,
exact quotient folds, necessary support projections, row refusal
visits and every retained signed table. The ordered independent
accumulation retained the transient guard order. The L6 verified
capture closes under the existing continuation limits through pass 2.
Ordinals 1, 3, 4 and 6 close as one empty-axis signed scalar table.
Ordinals 0 and 2 use triangles. Complete independent third-pivot
traversals covered 4,569,984 and 9,737,472 compatible products and
match both author pivots and author disjoint interval counts.

## Exact retally and measured work

The exact raw Gaussian sum is (2757346792452332882304526051656301507695432365051370239164416, 0) at inherited factor denominator
3556628738267424331864217260916736. Applying the original physical divisor 16 × 4^64 once and the
geometric cover coefficient 192 once gives **4542596388594604888474689/166153499473114484112975882535043072 + 0i**.

Native guarded prefixes accepted 27,859,996 product visits across
the six original live scopes. The L6 capture-only retry separately
repeated 3,596,820 accepted visits. Continuations accepted
52,194,136 visits and their 19 row-refused attempts visited
27,145,737. All 14 retained passes and every refusal's author
visit count are independently checked. The row and product refusal
ledgers preserve the distinct refusal types and scopes.

Measured author components total 559.961354 seconds, including 27.41
preparation, 200.978987 initial native work, 34.410808 for the L6
capture-only retry, 281.321559 continuation and 15.84 separately timed
triangle terminals. The sum of the original solve walls with preparation
is 500.45 seconds. This excludes the separate L6 capture, L6
continuation and both extra triangle terminals. The independent measured
preparation from the bound earlier replay, native review and retained
stage components are 31.379216, 236.549769 and 264.287806 seconds, with subtotal 532.216791.
Independent full preceding-phase wall sums are 538.762639 seconds. The
additional independent third pivots took 8.383580 seconds
combined. These are sums across measured stages or ordinal runs, with no
concurrent campaign wall-time inference.

## Reproduction

The archive manifest covers all receipts and the nested accepted
preparation evidence. Original large compiled factor files and exact
author frontiers are checksum-bound external inputs. The replay tools
default to the original cached-original-roster author directory. Set
L1_GROUP1444_AUTHOR_ROOT to relocate the original input tree.

    bash replay-label.sh 0 2 triangle author-order
    bash replay-label.sh 1 3 scalar author-order
    bash replay-label.sh 2 2 triangle author-order
    bash replay-label.sh 3 3 scalar author-order
    bash replay-label.sh 4 2 scalar author-order
    python3 -B product-prefix.py 6
    python3 -B check-budget-capture.py
    bash replay-budget-L6.sh 2
    python3 -B retally.py /path/to/publication-checkpoint

The frozen L6 pin receipt and accepted ordinal roster remain inputs to
the original prefix review. Product replay writes a local full checkpoint
for the capture comparison. The archive carries its checksum and exact
comparison receipt. The replay and the capture check write only beneath
the local evidence directory.
