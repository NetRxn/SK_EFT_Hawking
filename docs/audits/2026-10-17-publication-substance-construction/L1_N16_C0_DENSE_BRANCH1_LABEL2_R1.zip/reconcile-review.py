from ast import literal_eval
from csv import DictReader
from fractions import Fraction as Q
from pathlib import Path

p=Path(__file__).resolve().parent
norm=40512224221827380280140849737629696*16*4**64
a=list(DictReader((p/'author/roster/author-complete.tsv').open(),delimiter='\t'))
assert len(a)==29 and a[-1]['slice']=='total'
author={int(r['slice']):r for r in a[:-1]}
assert tuple(author)==tuple(range(28))
d=(p/'independent/direct/signed-ledger.tsv').read_text().splitlines()
assert d[0].split('\t')[-1]==str(norm)
direct=list(DictReader([d[1], *(row for row in d[2:-1] if row.split('\t',1)[0].isdigit())],delimiter='\t'))
assert [int(r['slice']) for r in direct]==list(range(24))
cover={}
for r in direct:
    i=int(r['slice'])
    c=author[i]
    assert literal_eval(c['coordinate'])==(int(r['coordinate']),)
    assert int(c['products'])==int(r['support'])
    value=Q(int(r['raw_real']),norm)
    assert Q(r['value_real'])==Q(c['real'])==value
    assert Q(r['value_imaginary'])==Q(c['imaginary'])==int(r['raw_imaginary'])==0
    cover[i]=value
assert sum(cover.values())==Q(d[-1].split('\t')[-2])
rows=list(DictReader((p/'independent/heavy/independent-terminal.tsv').open(),delimiter='\t'))
assert len(rows)==256 and {(int(r['outer']),int(r['inner'])) for r in rows}=={
    (i,j) for i in range(24,28) for j in range(64)}
for i in range(24,28):
    group=[r for r in rows if int(r['outer'])==i]
    assert len({(r['g152'],r['g130']) for r in group})==64
    assert all(Q(r['normalized_real'])==Q(int(r['raw_real']),norm) for r in group)
    assert all(Q(r['normalized_imaginary'])==int(r['raw_imaginary'])==0 for r in group)
    value=sum(Q(r['normalized_real']) for r in group)
    assert value==Q(author[i]['real']) and Q(author[i]['imaginary'])==0
    cover[i]=value
assert len(cover)==28 and sum(cover.values())==Q(a[-1]['real']) and Q(a[-1]['imaginary'])==0
print('0-23',sum(cover[i] for i in range(24)),0,sep='\t')
print('24-27',sum(cover[i] for i in range(24,28)),0,sep='\t')
print('total',sum(cover.values()),0,sep='\t')
