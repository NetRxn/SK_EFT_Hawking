from common import *
from rosters import OUT_IDS
from collections import defaultdict
from csv import DictReader
from fractions import Fraction
from pathlib import Path

F=Fraction
def data(path):
    return list(DictReader(path.read_text().splitlines(),delimiter='\t'))
terminal=data(Path('independent-terminal.tsv'))
groups=defaultdict(list)
for row in terminal:
    groups[int(row['outer'])].append(row)
assert set(groups)==set(C)
header='outer\tG020\touter_products\tnested_terms\tnested_products\traw_real\traw_imaginary\tnormalized_real\tnormalized_imaginary\treview_products\tauthor_products\treview_seconds_sum\tauthor_seconds_sum\tmax_reviewer_rows\tmax_author_rss_bytes\touter_cap_sha256'
frozen=(R/'author-complete.tsv').read_text().splitlines()
witnesses=set()
with Path('verified-scalars.tsv').open('x') as fout:
    print(header,file=fout)
    for n in C:
        terms=groups[n]
        d=rescue(n)
        coords=data(Path(f'roster-{n}.tsv'))
        assert len(terms)==len(coords)==64
        indices=set()
        batch={}
        for line in (d/'batch.out').read_text().splitlines():
            i,t,q=line.split('\t')
            assert t=='child_status 0' and int(i) not in batch
            batch[int(i)]=q
        assert set(batch)==set(range(1,64))
        lo,hi=0,0
        author_traffic=cost=match=0
        elapsed=elapsed_author=0.0
        for j,(a,b) in enumerate(zip(terms,coords,strict=True)):
            for k in ('outer','inner','g152','g130'): assert a[k]==b[k]
            assert int(a['inner'])==int(b['inner'])==j
            point=tuple(int(a[k]) for k in ('g152','g130'))
            assert point not in indices
            indices.add(point)
            r,s=int(a['raw_real']),int(a['raw_imaginary'])
            assert (F(r,N),F(s,N))==(F(a['normalized_real']),F(a['normalized_imaginary']))
            assert int(a['author_products'])>0
            if j:
                assert batch[j]==(d/f'slice{j}/contraction.out').read_text().splitlines()[-1]
            assert a['terminal_sha256'] not in witnesses
            witnesses.add(a['terminal_sha256'])
            lo+=r
            hi+=s
            author_traffic+=int(a['author_products'])
            cost+=int(a['review_products'])
            match+=int(b['products'])
            elapsed+=float(a['review_seconds'])
            elapsed_author+=float(a['author_seconds'])
        assert match==4605120
        r,i=F(lo,N),F(hi,N)
        assert r==sum(F(x['normalized_real']) for x in terms)
        assert i==sum(F(x['normalized_imaginary']) for x in terms)
        hit,=[z.split('\t') for z in frozen if z.startswith(f'{n}\t')]
        assert hit[:4]==[str(n),repr((OUT_IDS[n],)),'443520','64 nested exact terms']
        assert tuple(map(F,hit[4:]))==(r,i)
        cap=R/f'slice{n}/row-cap-physical-slice-dense-branch.pkl'
        print(n,OUT_IDS[n],443520,64,match,lo,hi,r,i,cost,author_traffic,f'{elapsed:.6f}',f'{elapsed_author:.6f}',
              max(int(x['review_peak_rows']) for x in terms),max(int(x['author_rss']) for x in terms),sha(cap),
              sep='\t',file=fout)
        print('accepted independent outer case',n,(OUT_IDS[n],),r,i,'nested signed coverage',len(indices),'products',cost,flush=True)
assert len(witnesses)==256
print('PASS 256 distinct terminal input hashes, all distinct cut identities, exact rational and common-scale integer sums')
