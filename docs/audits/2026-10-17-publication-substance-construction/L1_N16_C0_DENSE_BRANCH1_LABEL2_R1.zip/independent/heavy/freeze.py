from common import *
from shutil import copyfile

records={}
def append(prefix,base,include=lambda p:True,rec=True):
    for p in base.rglob('*'):
        if not p.is_file() or not include(p):continue
        records[p]=prefix/p.relative_to(base)
source=A/'branch1-label2'
append(Path('origin'),source)
for name in ('contract-with-peer.py','peer_pair.py','run-with-peer.py'):
    p=A/name
    records[p]=Path('origin')/name
ix=('contract-with-peer.py','peer_pair.py','reduce-label-frontier.py','exact-multicut.py','checkpoint/quotient.py','author-complete.tsv','s0.roster')
for name in ix:
    records[R/name]=Path('outer')/name
for n in C:
    for name in (f's{n}.pkl',f's{n}.roster',f'label-s{n}-reduced-frontier.pkl'):
        records[R/name]=Path('outer')/name
    append(Path(f'outer/slice{n}'),R/f'slice{n}')
    append(Path(f'nested-{n}'),rescue(n))
with Path('source-operands.sha256').open('x') as out:
    for p,dst in sorted(records.items()):
        print(sha(p),p,sep='  ',file=out)
        if p.suffix!='.pkl':
            q=Path('author')/dst
            q.parent.mkdir(parents=True,exist_ok=True)
            copyfile(p,q)
