from collections import Counter
from hashlib import file_digest
from math import prod
from pathlib import Path
from pickle import load

A=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
R=Path((A/'label2-roster.path').read_text().strip())
H=Path((A/'label2-heavy27-rescue.path').read_text().strip())
D=40512224221827380280140849737629696
N=D*16*4**64
C=range(24,28)
L=(('R',1,3,0,2,1),1),('complete-L-assignment',2)
def rescue(n):return H if n==27 else R/f'rescue{n}'
def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open('rb') as f:return load(f)
def positions(ax, keep):
    return tuple(ax.index(x) for x in keep)
def project(t, p):
    return tuple(t[i] for i in p)
def validate(state):
    F=state['factors']
    assert state['physical_cut']==L
    assert prod(d for _,_,d in F)==D
    assert set(Counter(w for ax,_,_ in F for w in ax).values())=={2}
    return F
