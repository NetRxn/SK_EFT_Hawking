# Group 128 branch 1, assignment 2, outer cuts 24–27

| Outer cut | G(0,2,0) | Exact normalized real | Imaginary |
| --- | ---: | ---: | ---: |
| 24 | 21 | -1649215857007425404493/10633823966279326983230456482242756608 | 0 |
| 25 | 26 | -1649215857007425404493/10633823966279326983230456482242756608 | 0 |
| 26 | 133 | -1649215857007425404493/10633823966279326983230456482242756608 | 0 |
| 27 | 138 | -1649215857007425404493/10633823966279326983230456482242756608 | 0 |

The four-term subtotal is **-1649215857007425404493/2658455991569831745807614120560689152 + 0i**. Each equal subtotal was derived separately from one distinct parent and 64 distinct inputs. The projected 64-coordinate weight rosters agree across the four parents. The 256 terminal operand hashes are all distinct. The scope is cuts 24–27 of assignment 2. Separate evidence covers cuts 0–23.

## Source and exact partition lineage

Publication checkpoint 8b2ee7976be700d65caa1807dbc769b5453705b3 supplies the exact DENSE_BRANCH1_LABELS345 archive, its assignment-2 operand hashes, and the DENSE_BINARY_REDUCTION raw branch-1 checkpoint. Independent enumeration of all 256 combinations on the 12 L axes selects exactly six factor-compatible assignments among the eight original projected states. Assignment 2 retains 188,272 exact signed rows. Its inverse lift reproduces all selected original rows and their individual denominators. The selected ten-factor denominator product is unchanged.

Replaying the original peer-aware contractor from the selected ten-factor operand reproduced its complete log and refused seven-factor state byte for byte. The recorded joins complete 525,312, 708,608 and 1,729,408 products. Exact pair histograms certify the complete 28-element G(0,2,0) roster with 6,428,928 matched products. Each of the four reviewed outer values carries 443,520 products and 522,312 selected rows. Each signed outer inverse lift was checked against the original seven-factor cap.

For each distinct outer cut the original partition, reduction and guarded contractor were byte-replayed. Each outer continuation completes 80,640, 189,696 and 243,648 products, then preserves its distinct four-factor state at the refusal for 4,605,120 prospective products. Both row-cap writers record work completed locally in that invocation. The prior 1,143,480 products entering the original assignment continuation and the 2,963,328 products entering each outer execution are visible in the frozen input receipts. These work counters carry no scalar weight.

Independent histograms confirm each exact disjoint 64-member nested partition on G(1,5,2) and G(1,3,0), covering all 4,605,120 rejected-pair products on that outer state. Per nested term, the independent inverse lift recreates the full signed selected support with the original denominator on every factor. All 256 singleton and quotient reductions reproduce the corresponding saved terminal input and receipt bytes. The 63-member author batch receipt for each cut covers indices 1–63 exactly once, with the separate accounted index 0.

## Independent arithmetic and normalization

The independent sparse contractor reorders joins by exact match count, reverses traversal of compatible tables and accumulates both Gaussian components. It imports no author contraction or quotient function. It evaluates every four-factor terminal separately. Each cut uses 1,353,432 independent matched products, with peak 11,664 output rows. The corresponding author terminals each use 750,432 total matched products. Per-term and per-cut measured timings, peak counts, operand hashes and schedules are included.

Exact integer accumulation gives raw real -34208462125710346611986212883945349991221301972914495553536 and imaginary 0 on each of the four cuts. Independent original-profile decoding gives degree 32, world 136, cross 444, phase +1, factorial 16 and Haar denominator 4^64. The common factor denominator is 40512224221827380280140849737629696. The raw normalization agrees with the independent Fraction sums, all author terminal comparisons and the frozen author outer ledger. Each nested coordinate and each outer coordinate receives unit weight and the external normalization enters once.

The two manifests cover portable scripts and evidence separately from the original large pickles. In a fresh scratch, run rosters.py, arithmetic.py, lineage.py with origin, outer and nested modes, and retally.py from the reviewer directory. The independent-terminal.tsv and roster-24.tsv through roster-27.tsv bind every signed value to its input and selected coordinate.
