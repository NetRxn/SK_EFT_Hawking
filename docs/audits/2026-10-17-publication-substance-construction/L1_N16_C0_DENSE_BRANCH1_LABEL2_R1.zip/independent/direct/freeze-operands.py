from hashlib import sha256
from pathlib import Path
import shutil

prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
branch=prep/'branch1-label2'
author=Path('/private/tmp/l1-branch1-label2-roster.KlVDAx')
tri=Path('/private/tmp/l1-branch1-label2-triangles.GlVIyy')
scoped_roster=sorted(p for p in author.iterdir() if p.is_file() and p.suffix in ('.tsv','.out','.py','.pkl','.roster'))
scoped_inner=sorted(p for i in range(24) for p in (author/f'slice{i}').glob('*')
                   if p.is_file() and p.suffix in ('.pkl','.out','.err','.receipt'))
data={
    'source': [prep/'read-support.py',prep/'rank-labels.py',prep/'contract-with-peer.py',prep/'peer_pair.py',
               prep/'verified-pin'/'label-2-branch-1.pkl',prep/'verified-pin'/'check-2.out',
               branch/'sparse-label-pilot.pkl',branch/'dense-saturated-frontier.pkl',
               branch/'row-cap-physical-slice-dense-branch.pkl',branch/'contraction.out',
               branch/'contraction.err',branch/'contraction.receipt',branch/'support.out',
               branch/'rank-labels.py',branch/'label-rank.out'],
    'author':scoped_roster+scoped_inner+[author/'checkpoint/quotient.py'],
    'triangle':sorted(p for p in tri.rglob('*') if p.is_file()
                      and p.suffix in ('.pkl','.out','.tsv','.py')),
}
with Path('operands.sha256').open('w') as out:
    for family,paths in data.items():
        base={'source':prep,'author':author,'triangle':tri}[family]
        for src in paths:
            digest=sha256(src.read_bytes()).hexdigest()
            print(digest,src,sep='  ',file=out)
            if src.suffix=='.pkl':
                continue
            dst=Path('author-receipts')/family/src.relative_to(base)
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,dst)
