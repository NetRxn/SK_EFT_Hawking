from ast import literal_eval
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import factorial,prod
from pathlib import Path
from pickle import loads
import csv
import re

author=Path('/private/tmp/l1-branch1-label2-roster.KlVDAx')
codes=(503841882182,1461451755920)
modes=sorted((a,b,c) for a,b,c in product(range(5),repeat=3) if a+b+c<=4)
occ=[]
for code in codes:
    record=[]
    for site in range(8):
        code,digit=divmod(code,64)
        record.append(modes[digit])
    assert not code
    occ.append(record)
world=sum((k+3)*value for layer in occ for powers in layer for k,value in enumerate(powers))
# Count cross-site sign by scanning site groups weighted by their insertions.
cross=0
for layer in occ:
    prior=[0]*8
    for site in range(8):
        for k in range(3):
            if site & (2**k):
                continue
            peer=site+2**k
            weight=sum(layer[u][j] for u in (site,peer) for j in range(3) if j!=k)
            cross+=weight*(sum(prior[site+1:])+sum(prior[peer+1:]))
            prior[site]+=weight
            prior[peer]+=weight
phase=(-1)**((world+cross)%2)
P=[p for layer in occ for site in layer for p in site]
total_occ=sum(P)
multiplicity=prod(map(factorial,P))
assert (total_occ,multiplicity,phase)==(32,16,1)
N=40512224221827380280140849737629696
scale=N*multiplicity*4**(2*total_occ)
print('normalization','occupation',total_occ,'factorial',multiplicity,'quarters exponent',2*total_occ,'world',world,'cross',cross,'phase',phase,'positive denominator',scale,sep='\t')

tri=Path('/private/tmp/l1-branch1-label2-triangles.GlVIyy')
tri_cases={4,5,10,11}
forecasts={int(i):tuple(map(int,rest)) for i,*rest in
           (line.split() for line in (tri/'forecast.tsv').read_text().splitlines())}
assert set(forecasts)==tri_cases
signature=r'^exact normalized real (\S+) imaginary (\S+)'
numerators=r'^raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$'
def value_of(log):
    return tuple(map(Fraction,re.search(signature,log,re.M).groups()))

def project(scope,edge):
    positions=tuple(scope.index(w) for w in edge)
    return lambda row: tuple(row[k] for k in positions)

def check_triangle(i,branch,log):
    p=tri/str(i)/'join-cap-input.pkl'
    data=p.read_bytes()
    assert data==(branch/'join-cap-physical-slice-dense-branch.pkl').read_bytes()
    h=sha256(data).hexdigest()
    assert h in log
    checkpoint=loads(data)
    assert checkpoint['physical_cut']==((('R',1,3,0,2,1),1),('complete-L-assignment',2))
    F=checkpoint['factors']
    assert len(F)==3 and prod(d for _,_,d in F)==N
    assert set(Counter(w for scope,_,_ in F for w in scope).values())=={2}
    A,X,_=F[0]
    costs=[]
    for scope,rows,_ in F[1:]:
        edge=tuple(sorted(set(A)&set(scope)))
        count=Counter(map(project(scope,edge),rows))
        choose=project(A,edge)
        costs.append([count[choose(row)] for row in sorted(X)])
    probes=[min(r) for r in zip(*costs,strict=True)]
    shape,total,parts,peak=forecasts[i]
    assert shape==len(probes)==len(X) and sum(probes)==total and parts==2
    expected=[]
    qprod=0
    counts=[]
    for shard in range(parts):
        lo,hi=shape*shard//parts,shape*(shard+1)//parts
        q=tri/str(i)/f'shard-{shard}.out'
        info=q.read_text()
        assert f'left row interval {lo} {hi} of {shape} shard {shard} of {parts}' in info.splitlines()
        count,work,checked=map(int,re.search(r'^triangle closure (\d+) nonzero-support triples (\d+) bounded probes products (\d+) output rows 1$',info,re.M).groups())
        assert work==sum(probes[lo:hi]) and checked==2*count
        a,b,d=map(int,re.search(numerators,info,re.M).groups())
        assert d==N and value_of(info)==(Fraction(phase*a,scale),Fraction(phase*b,scale))
        qprod+=count
        expected.append((a,b))
        counts.append(work)
        print('author shard',i,shard,lo,hi,work,a,b,sep='\t')
    assert max(counts)==peak
    match=re.search(r'^independent pivot [12] probes \d+ triples (\d+) nonzero pivot rows \d+ Gaussian products (\d+) wall seconds (\S+)',log,re.M)
    assert int(match[1])==qprod
    a,b=map(sum,zip(*expected,strict=True))
    re_i,im_i,d=map(int,re.search(numerators,log,re.M).groups())
    assert (a,b,N)==(re_i,im_i,d)
    return h,re_i,im_i,d,match[2],match[3]

with (author/'author-complete.tsv').open() as f:
    rows=list(csv.DictReader(f,delimiter='\t'))
assert len(rows)==29 and [int(r['slice']) for r in rows[:-1]]==list(range(28))
axes,roster=literal_eval((author/'s0.roster').read_text())
assert axes==(('G',0,2,0),) and len(roster)==len(set(v for v,_ in roster))==28
ordered=sorted(roster,key=lambda rw:(rw[1],rw[0]))
print('slice','coordinate','support','method','input_sha256','raw_real','raw_imaginary','factor_denominator','value_real','value_imaginary','independent_products','seconds',sep='\t')
raw_total=[0,0]
terms=[]
for i,((value,),weight) in enumerate(ordered[:24]):
    q=rows[i]
    assert (int(q['slice']),literal_eval(q['coordinate']),int(q['products']))==(i,(value,),weight)
    branch=author/f'slice{i}'
    if i in tri_cases:
        method='sharded-triangle'
        assert (branch/'contraction.receipt').read_text().splitlines()[0]=='child_status 2'
        log=Path(f'slice-{i}-triangle.out').read_text()
        h,re_i,im_i,d,products,elapsed=check_triangle(i,branch,log)
    else:
        method='direct'
        raw=(author/f'label-s{i}-reduced-frontier.pkl').read_bytes()
        h=sha256(raw).hexdigest()
        o=loads(raw)
        assert o['conditioning']==[(axes[0],value)]
        log=Path(f'slice-{i}-replay.out').read_text()
        assert f'operand {i} {h} cut {o["conditioning"]}' in log.splitlines()
        re_i,im_i,d=map(int,re.search(r'^raw scalar (-?\d+) (-?\d+) factor denominator (\d+)$',log,re.M).groups())
        products,elapsed=re.search(r'^replay products (\d+) wall seconds (\S+)$',log,re.M).groups()
        shown=(branch/'contraction.out').read_text().splitlines()[-1]
        author_value,*_=re.fullmatch(r'exact normalized (\S+) peak rows (\d+) matched products (\d+)',shown).groups()
        assert Fraction(author_value)==Fraction(q['real'])
        assert (branch/'contraction.receipt').read_text().splitlines()[0]=='child_status 0'
    assert d==N and q['method']==method
    vals=(Fraction(phase*re_i,scale),Fraction(phase*im_i,scale))
    assert vals==(Fraction(q['real']),Fraction(q['imaginary']))
    print(i,value,weight,method,h,re_i,im_i,d,*vals,products,elapsed,sep='\t')
    terms.append(vals)
    raw_total[0]+=re_i
    raw_total[1]+=im_i
sums=tuple(map(sum,zip(*terms,strict=True)))
assert sums==tuple(Fraction(phase*k,scale) for k in raw_total)
assert sums==tuple(sum(Fraction(v[k]) for v in rows[:24]) for k in ('real','imaginary'))
print('subtotal-0-through-23',*raw_total,N,*sums,sep='\t')
