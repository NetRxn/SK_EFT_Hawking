from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess
import sys
from time import perf_counter

prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
branch=prep/'branch1-label2'
author=Path('/private/tmp/l1-branch1-label2-roster.KlVDAx')
base=Path.cwd()/'byte-audit'
base.mkdir()
def compare(left,right):
    assert sha256(left.read_bytes()).digest()==sha256(right.read_bytes()).digest(),(left,right)
def stage(program,args,home,expected,code=0):
    target=home/expected.name
    start=perf_counter()
    with target.open('xb') as out:
        check=subprocess.run([sys.executable,'-B',str(program),*args],cwd=home,
                             stdout=out,stderr=subprocess.STDOUT,timeout=150)
    took=perf_counter()-start
    assert check.returncode==code,(home,expected,check.returncode)
    compare(target,expected)
    return took

for name in ('contract-with-peer.py','peer_pair.py'):
    compare(prep/name,author/name)
tools=base/'author-methods'
tools.mkdir()
(tools/'checkpoint').mkdir()
for name in ('contract-with-peer.py','peer_pair.py','exact-multicut.py','reduce-label-frontier.py','checkpoint/quotient.py'):
    shutil.copyfile(author/name,tools/name)
cap=base/'cap-replay'
cap.mkdir()
shutil.copyfile(branch/'sparse-label-pilot.pkl',cap/'dense-saturated-frontier.pkl')
compare(cap/'dense-saturated-frontier.pkl',branch/'dense-saturated-frontier.pkl')
assert (branch/'contraction.receipt').read_text().splitlines()[0]=='child_status 2'
elapsed=stage(tools/'contract-with-peer.py',[],cap,branch/'contraction.out',2)
name='row-cap-physical-slice-dense-branch.pkl'
compare(cap/name,branch/name)
print('cap','contraction',2,f'{elapsed:.6f}',sep='\t',flush=True)

def solve(i):
    home=base/f'lineage-{i}'
    home.mkdir()
    (home/'checkpoint').mkdir()
    for fname in ('contract-with-peer.py','peer_pair.py','exact-multicut.py',
                  'reduce-label-frontier.py','checkpoint/quotient.py'):
        shutil.copyfile(tools/fname,home/fname)
    tag=f's{i}'
    reference=author/f'slice{i}'
    prep_time=stage(home/'exact-multicut.py',[str(cap/name),f'{tag}.pkl',str(i)],
                    home,reference/'partition.out')
    compare(home/f'{tag}.pkl',author/f'{tag}.pkl')
    compare(home/f'{tag}.roster',author/f'{tag}.roster')
    reduced=f'label-{tag}-reduced-frontier.pkl'
    reduce_time=stage(home/'reduce-label-frontier.py',[f'{tag}.pkl',tag],home,reference/'reduce.out')
    compare(home/reduced,author/reduced)
    shutil.copyfile(home/reduced,home/'dense-saturated-frontier.pkl')
    compare(home/'dense-saturated-frontier.pkl',reference/'dense-saturated-frontier.pkl')
    status=int((reference/'contraction.receipt').read_text().splitlines()[0].split()[-1])
    assert status==(2 if i in (4,5,10,11) else 0)
    done_time=stage(home/'contract-with-peer.py',[],home,reference/'contraction.out',status)
    if status==2:
        leaf='join-cap-physical-slice-dense-branch.pkl'
        compare(home/leaf,reference/leaf)
    return i, status, prep_time, reduce_time, done_time

with ThreadPoolExecutor(max_workers=2) as pool:
    for i, status, *elapsed in pool.map(solve,range(24)):
        for method,t in zip(('partition','reduce','contract'),elapsed,strict=True):
            print(i,method,(status if method=="contract" else 0),f'{t:.6f}',sep='\t',flush=True)
