#!/usr/bin/env bash
set -euo pipefail
author=/private/tmp/l1-branch1-label2-roster.KlVDAx
python3 -u source-and-partition.py > source-and-partition.out
python3 -u lineage.py > lineage.tsv
for i in {0..3} {6..9} {12..23}; do
 python3 -u independent-sparse.py "$i" "$author/label-s$i-reduced-frontier.pkl" > "slice-$i-replay.out"
done
for i in 4 5 10 11; do
 python3 -u independent-triangle.py "$i" > "slice-$i-triangle.out"
done
python3 -u retally.py > signed-ledger.tsv
