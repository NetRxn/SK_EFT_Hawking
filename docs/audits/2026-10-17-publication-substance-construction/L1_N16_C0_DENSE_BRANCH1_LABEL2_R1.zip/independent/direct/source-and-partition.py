from ast import literal_eval
from collections import Counter
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from pickle import loads

prep=Path('/private/tmp/l1-group128-branch1-preparation.SlDJuy')
branch=prep/'branch1-label2'
author=Path('/private/tmp/l1-branch1-label2-roster.KlVDAx')
native=Path('/private/tmp/l1-dense-resume.bbZW6V/row-cap-physical-slice-dense-binary-1.pkl')
h=lambda p:sha256(p.read_bytes()).hexdigest()
assert h(native)=='4f7fe52fe4063781c51931cabda6d794602f30749bbc28b63d1d88e32e8706be'
cap=branch/'row-cap-physical-slice-dense-branch.pkl'
assert h(cap)=='6630d76223ed26e183b35c73af4904941e390bd01f718c034e22d8bb5d4b4b71'
root=loads(native.read_bytes())
original=[(axes,rows,d) for axes,rows,d in root['factors']]
assert root['physical_cut']==(('R',1,3,0,2,1),1) and len(original)==10

def degree(factors):
    return Counter(w for axes,_,_ in factors for w in axes)
def projection(axes,keys):
    idx=tuple(axes.index(k) for k in keys)
    return lambda row:tuple(row[i] for i in idx)
wire_set=sorted(k for k in degree(original) if k[0]=='L')
views=[]
for scope,rows,d in original:
    keys=tuple(k for k in scope if k[0]=='L')
    views.append((keys,set(map(projection(scope,keys),rows))))
domains=[]
for k in wire_set:
    allowed=[{row[keys.index(k)] for row in values} for keys,values in views if k in keys]
    domains.append(set.intersection(*allowed))
assert len(wire_set)==12 and all(d for d in domains)
compatible=[]
for values in product(*map(sorted,domains)):
    assignment=dict(zip(wire_set,values,strict=True))
    if all(tuple(assignment[k] for k in keys) in allowed for keys,allowed in views):
        compatible.append(tuple(assignment.items()))
assert len(compatible)==6 and len(set(compatible))==6
prefix='exact surviving L assignment 1 '
records=[literal_eval(line.removeprefix(prefix)) for line in (branch/'support.out').read_text().splitlines() if line.startswith(prefix)]
assert records==compatible
print('PASS full native L census',len(compatible))
for label,assignment in enumerate(compatible):
    print('L assignment',label,assignment)

fixed=dict(compatible[2])
reduced=loads((branch/'sparse-label-pilot.pkl').read_bytes())
proof=loads((prep/'verified-pin/label-2-branch-1.pkl').read_bytes())
assert reduced['selected']==compatible[2]
assert reduced['physical_cut']==(root['physical_cut'],('complete-L-assignment',2))
assert reduced['used_before']==root['used_before']==1_143_480
assert reduced['factors']==proof['factors']
assert len(reduced['factors'])==10 and sum(len(rows) for _,rows,_ in reduced['factors'])==188272
def inverse_lift(before,after,fixed):
    for (scope,rows,d),(sliced,chosen,e) in zip(before,after,strict=True):
        assert d==e and sliced==tuple(k for k in scope if k not in fixed)
        positions=tuple((i,fixed[k]) for i,k in enumerate(scope) if k in fixed)
        keep=projection(scope,sliced)
        wanted={row:z for row,z in rows.items() if all(row[i]==v for i,v in positions)}
        actual={}
        for row,z in chosen.items():
            vals=dict(zip(sliced,row,strict=True))|fixed
            restored=tuple(vals[k] for k in scope)
            assert restored not in actual and keep(restored)==row
            actual[restored]=z
        assert actual==wanted
inverse_lift(original,reduced['factors'],fixed)
shape=degree(reduced['factors'])
assert not any(k[0]=='L' for k in shape) and set(shape.values())=={2}
print('PASS complete L label2 inverse lift, stored rows',sum(len(rows) for _,rows,_ in reduced['factors']))

state=loads(cap.read_bytes())
assert state['physical_cut']==reduced['physical_cut'] and state['used_before']==2963328
f=state['factors']
assert len(f)==7 and set(degree(f).values())=={2}
axis=('G',0,2,0)
selected=[scope for scope,_,_ in f if axis in scope]
assert len(selected)==2
i,j=state['rejected_pair']
assert(i,j)==(0,2)
A,X,_=f[i]
B,Y,_=f[j]
shared=tuple(sorted(set(A)&set(B)))
assert axis in A and axis not in shared
restricted=set.intersection(*({row[scope.index(axis)] for row in rows}
                              for scope,rows,_ in f if axis in scope))
first=projection(A,shared)
second=projection(B,shared)
left=Counter((row[A.index(axis)],first(row)) for row in X)
right=Counter(map(second,Y))
traffic=Counter()
for (value,key),n in left.items():
    traffic[value]+=n*right[key]
traffic=+traffic
assert set(traffic)==restricted and len(traffic)==28
assert sum(traffic.values())==state['matched']==6428928
assert (min(traffic.values()),max(traffic.values()))==(78144,443520)
print('PASS complete disjoint G cut',axis,sorted(traffic.items()))
roster=(author/'s0.roster').read_bytes()
assert literal_eval(roster.decode())==((axis,),[((k,),n) for k,n in sorted(traffic.items())])
ordered=sorted(traffic,key=lambda key:(traffic[key],key))
D=40512224221827380280140849737629696
for i,value in enumerate(ordered):
    raw=author/f's{i}.pkl'
    r=loads(raw.read_bytes())
    clean=author/f'label-s{i}-reduced-frontier.pkl'
    c=loads(clean.read_bytes())
    assert (author/f's{i}.roster').read_bytes()==roster
    assert r['conditioning']==c['conditioning']==[(axis,value)]
    assert r['physical_cut']==c['physical_cut']==state['physical_cut']
    inverse_lift(f,r['factors'],{axis:value})
    assert prod(d for _,_,d in r['factors'])==prod(d for _,_,d in c['factors'])==D
    assert set(degree(r['factors']).values())==set(degree(c['factors']).values())=={2}
    print('PASS exact lifted case',i,value,traffic[value],h(raw),h(clean))
