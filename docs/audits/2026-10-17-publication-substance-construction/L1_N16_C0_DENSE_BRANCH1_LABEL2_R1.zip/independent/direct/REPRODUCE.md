# Reproduce first-index branch 1, original assignment 2, indices 0–23

Use fresh scratch paths and the input hashes in SOURCE_PINS.txt, native-operand.sha256 and operands.sha256. Original text receipts and source are under author-receipts/. Large tensors are represented by SHA256 and can be rebuilt from the pinned native frontier. When relocating, substitute restored operand paths.

Run bash reproduce.sh to recover the original 12-coordinate L restriction, replay its cap, independently census and inverse-lift all 28 positive-support G(0,2,0) coordinates, reproduce the 72 scoped generic stages, independently close the 20 direct and four three-factor terms, and verify normalization and signed retally. The signed ledger covers indices 0–23 only, with source operand hashes, raw Gaussian numerators and exact signed values. Indices 24–27 have inverse-lift evidence here and their terminal arithmetic is reviewed separately.
