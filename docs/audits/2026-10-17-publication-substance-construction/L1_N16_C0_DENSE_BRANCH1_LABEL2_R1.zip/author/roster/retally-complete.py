from ast import literal_eval
from fractions import Fraction as Q
from pathlib import Path
import re
import sys

source, triangles, heavy27 = map(Path, sys.argv[1:])
D = 40512224221827380280140849737629696
physical_norm = D*16*4**64
def roster(directory, count, traffic):
    rd = (directory/'s0.roster').read_bytes()
    axes, values = literal_eval(rd.decode())
    assert len(values)==len(dict(values))==count
    assert sum(n for _,n in values)==traffic
    return rd,axes,sorted(values,key=lambda row:(row[1],row[0]))
def read_child(directory,index,key,count,rd):
    assert (directory/f's{index}.roster').read_bytes()==rd
    path=directory/f'slice{index}'
    assert f'pilot {key!r} matched {count} stored rows ' in (path/'partition.out').read_text()
    return path
def scalar(path):
    assert (path/'contraction.receipt').read_text().splitlines()[0]=='child_status 0'
    return Q(re.fullmatch(r'exact normalized ([-\d/]+) peak rows \d+ matched products \d+',
              (path/'contraction.out').read_text().splitlines()[-1])[1])
def triangle(i):
    out=triangles/str(i)
    forecast={int(j):(int(n),int(p),int(s),int(w)) for j,n,p,s,w in
              (line.split() for line in (triangles/'forecast.tsv').read_text().splitlines())}
    rows,probes,shards,worst=forecast[i]
    covered=traffic=0
    total=Q(0)
    for j in range(shards):
        text=(out/f'shard-{j}.out').read_text()
        a,b,end,ordinal,num=map(int,re.search(r'left row interval (\d+) (\d+) of (\d+) shard (\d+) of (\d+)',text).groups())
        assert a==covered and b>a and end==rows and ordinal==j and num==shards
        covered=b
        traffic+=int(re.search(r'triangle closure \d+ nonzero-support triples (\d+) bounded probes',text)[1])
        re_num,im_num,den=map(int,re.search(r'raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)',text).groups())
        assert im_num==0 and den==D
        total+=Q(re_num,physical_norm)
    assert covered==rows and traffic==probes
    return total
rd,axes,support=roster(source,28,6_428_928)
assert axes==(('G',0,2,0),)
print('slice','coordinate','products','method','real','imaginary',sep='\t')
grand=Q(0)
for index,(key,count) in enumerate(support):
    child=read_child(source,index,key,count,rd)
    if index in (4,5,10,11):
        assert (child/'contraction.receipt').read_text().splitlines()[0]=='child_status 2'
        value,method=triangle(index),'sharded-triangle'
    elif 24<=index<=27:
        assert (child/'contraction.receipt').read_text().splitlines()[0]=='child_status 2'
        parent=heavy27 if index==27 else source/f'rescue{index}'
        srd,saxes,sub=roster(parent,64,4_605_120)
        assert saxes==(('G',1,5,2),('G',1,3,0))
        value=sum(scalar(read_child(parent,i,k,n,srd)) for i,(k,n) in enumerate(sub))
        method='64 nested exact terms'
    else:
        value,method=scalar(child),'direct'
    assert (value*physical_norm).denominator==1
    print(index,key,count,method,value,0,sep='\t')
    grand+=value
print('total','','','',grand,0,sep='\t')
