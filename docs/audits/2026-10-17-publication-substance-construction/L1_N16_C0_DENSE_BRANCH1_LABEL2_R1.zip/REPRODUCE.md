# L1 group 128 opposite first-index branch, assignment 2

Source revision: `8b2ee7976be700d65caa1807dbc769b5453705b3`.
The scientific source and previous 3–5 acceptance are pinned by the independent
review packages. This checkpoint verifies assignment 2 of the original
six-assignment parent, from the binary-native factor state.

To replay the author exact normalized arithmetic from archived terminal logs,
run the following from the archive root.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B author/roster/retally-complete.py author/roster author/triangles author/heavy27 | cmp - author/roster/author-complete.tsv
```

The 28 G(0,2,0) values exhaust 6,428,928 compatible products for the formerly
refused join. Each value enters with weight one. Twenty values terminate via
direct contractions, four via two-shard sparse triangles, and four through
256 nested terms across four disjoint 64-case partitions. The independent
review packets cover distinct coordinates and agree with every author subtotal.
All arithmetic uses the original normalization once.

Author preparation for assignments 0 and 1 is archived separately. The
first tested smaller partition for assignment 1 completed all 16 inner
values. Assignment 0's single-axis experiment closed a small case but still
refused a larger case. These results preserve starting points for the two
outstanding assignments.
