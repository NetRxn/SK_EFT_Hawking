from pathlib import Path
import subprocess,os,json,resource,time,sys
P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking');prefix='/tmp/publication-task2-science-r3-bounded';env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(P),'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1'})
argv=[str(P/'.venv/bin/python'),'-B','-m','pytest','-m','','tests/test_original_coefficients.py','tests/test_dependency_declaration.py','tests/test_original_coefficient_jets.py','-k','not test_original_full_small_carrier_direct_vs_auxiliary','-vv','-s','-p','no:cacheprovider','--junitxml='+prefix+'.xml']
t=time.monotonic()
with open(prefix+'.stdout','w') as out,open(prefix+'.stderr','w') as err:r=subprocess.run(argv,cwd=P,env=env,stdout=out,stderr=err)
rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
receipt={'argv':argv,'cwd':str(P),'returncode':r.returncode,'seconds':time.monotonic()-t,'child_native_peak_RSS_bytes':rss,'numeric_threads':1,'cache_provider':False,'bytecode':False,'full_scientific_test_selected':False}
Path(prefix+'.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));assert rss<512*1024**2;sys.exit(r.returncode)
