from fractions import Fraction as F
import json,resource,time
from src.vestigial import original_coefficients as o
from src.core import formulas as f
p=o.Polynomial.scalar
start=time.monotonic(); observations=[]
def observe(name,op,bits=1024,refuse=False):
 b=o.ExactBudget(100000,512*1024**2,integer_bit_limit=bits)
 try:
  with b:r=op()
 except o.BudgetExceeded as e:
  assert refuse
  r='REFUSED: '+str(e)
 else:assert not refuse
 observations.append(dict(name=name,bits=bits,products=b.products,integer_products=b.integer_products,peak_integer_bits=b.peak_integer_bits,result=str(r)))
 return r
for bits in (8,1024):
 n=127 if bits==8 else 2**1023-1
 a=o.RawJet((0,),(((),F(1)),((0,),F(1))))
 b=o.RawJet((0,),(((),F(n,6)),((0,),F(-n,10))))
 observe('rational_raw_'+str(bits),lambda:a*b,bits,True)
 def ok():
  r=a*b;assert r.slots()==(F(n,6),F(n,15),F(-n,5));return r.slots()
 observe('rational_raw_positive_'+str(bits),ok,bits+8)
a=o.RawJet.from_slots((1,1,-1,-200,-200,200));b=o.RawJet.from_slots((1,200,200,-200,200,200))
observe('mixed_cancellation',lambda:a*b,8,True)
def mixed():
 r=a*b;assert r.slots()==(1,201,199,0,0,0);return r.slots()
observe('mixed_17_positive',mixed,9)
reg=o.OriginalRegulator((2,1,1,1));x,y=reg.sites;idx={g:i for i,g in enumerate(reg.generator_order)}
mask=(1<<idx[x,'bar',0])|(1<<idx[y,'psi',0]);poly=o.ExteriorPolynomial(((mask,p(1)),))
for bits in (8,1024):
 n=127 if bits==8 else 2**1023-1
 charges={x:F(n,10),y:F(n,6)}
 observe('actual_current_'+str(bits),lambda:o.exterior_phase_derivative(poly,reg,charges),bits,True)
 def cur():
  r=o.exterior_phase_derivative(poly,reg,charges);assert r==o.ExteriorPolynomial(((mask,p(o.QComplex(0,F(n,15)))),));return r
 observe('actual_current_positive_'+str(bits),cur,bits+8)
# Original one-site coframe, numeric norm-one links, actual graded contraction.
reg=o.OriginalRegulator((1,1,1,1));x=reg.sites[0]
link=f.original_spin4_link((0,0,0,1),(0,0,0,1));links={k:link for k in reg.link_order}
T=o.assemble_coframe(reg,f.original_coframe_blocks(reg,(x,0,3),links)).to_exterior(reg)
assert (T*T*T*T).terms==((255,p(24)),)
z=o.ExteriorPolynomial();one=o.ExteriorPolynomial(((0,p(1)),))
action=o.RawJet.from_slots((T,T,z,T*2,z,z))
def make(action,measure=None,cancel=False):
 insertion=o.RawJet.constant(one,action.labels);measure=o.RawJet.constant(p(1),action.labels) if measure is None else measure
 grade=[]
 for k in action.indices():
  ts=[]
  for role,jet in (('action',action),('insertion',insertion)):
   for m,co in jet.at(k).terms:
    gs=tuple(g for i,g in enumerate(reg.generator_order) if m>>i&1)
    for key,v in co.terms:
     ts.append(o.GradedTerm(m.bit_count()//2,(0,0),tuple(sum(s.family==ff for s in key) for ff in ('J','H')),(role,),o.GeneratorLinkSupport(gs,(),tuple(sorted(set(g[0] for g in gs)))),1,v,m,key))
  if cancel and not k:
   for sign in (1,-1):ts.append(o.GradedTerm(0,(0,0),(0,0),('action',),o.GeneratorLinkSupport((),(),()),1,o.QComplex(sign),0,()))
  for key,v in measure.at(k).terms:ts.append(o.GradedTerm(0,(0,0),(0,0),('measure',),o.GeneratorLinkSupport((),(),()),1,v,None,key))
  grade.append((k,tuple(ts)))
 return o.SourceJet(action.labels,o.SourceFamilyGrading(tuple(grade)),action,insertion,measure)
rejected=[]
for k in action.indices():
 vals=dict(action.entries);vals[k]=action.at(k)+one
 try:make(o.RawJet(action.labels,tuple(vals.items())))
 except ValueError as e:assert 'positive' in str(e);rejected.append(str(k))
 else:raise AssertionError('accepted poisoned slot')
j=o.Symbol('J',('independent',));vals=dict(action.entries);vals[(0,1)]=action.at((0,1))+o.ExteriorPolynomial(((0,o.Polynomial.variable(j)),))
try:make(o.RawJet(action.labels,tuple(vals.items())))
except ValueError as e:assert 'positive' in str(e);rejected.append('formal_J_mixed')
else:raise AssertionError('accepted formal scalar action')
observations.append(dict(name='all_action_slots_refused_after_reconstruction',indices=rejected))
def contract(source):
 cert=o.SupportCertificate('independent actual original family',(),source.grading,True,reg.generator_order,reg.link_order)
 return o.contract_original(reg,source,o.CoefficientRequest(None,(),'unit',cert),o.ExactBudget(100000,512*1024**2))
for name,measure,expected,cancel in [('original_acceleration',None,(1,4,20),False),('moving_scalar_measure',o.RawJet.from_slots(tuple(map(p,(3,1,0,0,0,0)))),(3,13,68),False),('cancelled_raw_action_body',None,(1,4,20),True)]:
 source=make(action,measure,cancel)
 b=o.ExactBudget(100000,512*1024**2)
 cert=o.SupportCertificate('independent actual original family',(),source.grading,True,reg.generator_order,reg.link_order)
 r=o.contract_original(reg,source,o.CoefficientRequest(None,(),'unit',cert),b)
 got=tuple(dict(r.N)[k] for k in ((),(0,),(0,0)))
 assert got==tuple(map(p,expected))
 observations.append(dict(name=name,result=expected,products=b.products,integer_products=b.integer_products,peak_integer_bits=b.peak_integer_bits))
rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;assert rss<512*1024**2
print(json.dumps(dict(observations=observations,seconds=time.monotonic()-start,native_RSS_bytes=rss,full_science_executed=False),indent=2))
