import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[k]='1'
import json,resource,time
from fractions import Fraction as F
from src.vestigial import original_coefficients as o
from src.core import formulas as f
started=time.monotonic(); receipts=[]
def run(name,fun,bits=1024,refuse=False):
 b=o.ExactBudget(100000,512*1024**2,bits)
 try:
  with b: value=fun()
 except o.BudgetExceeded:
  assert refuse
  value='REFUSED'
 else: assert not refuse
 receipts.append(dict(name=name,bits=bits,value=str(value),products=b.products,integer_products=b.integer_products,peak_integer_bits=b.peak_integer_bits))
for bits in (8,1024):
 n=127 if bits==8 else 2**1023-1
 a=o.RawJet((0,),(((),F(1)),((0,),F(1))))
 b=o.RawJet((0,),(((),F(n,6)),((0,),F(-n,10))))
 run('one_label_height_'+str(bits),lambda:a*b,bits,True)
 def positive():
  z=a*b;assert z.slots()==(F(n,6),F(n,15),F(-n,5));return 'exact n/6,n/15,-n/5'
 run('one_label_positive_'+str(bits),positive,bits+8)
a=o.RawJet.from_slots(tuple(map(F,(1,1,-1,-200,-200,200))))
b=o.RawJet.from_slots(tuple(map(F,(1,200,200,-200,200,200))))
run('six_slot_cancel_refusal',lambda:a*b,8,True)
def pos():
 z=a*b;assert z.slots()==(F(1),F(201),F(199),F(0),F(0),F(0));return z.slots()
run('six_slot_17products',pos,9)
r=o.OriginalRegulator((2,1,1,1)); x,y=r.sites; ids={g:i for i,g in enumerate(r.generator_order)}
m=(1<<ids[x,'bar',0])|(1<<ids[y,'psi',0]);p=o.ExteriorPolynomial(((m,o.Polynomial.scalar(1)),))
for bits in (8,1024):
 n=127 if bits==8 else 2**1023-1
 charges={x:F(n,10),y:F(n,6)}
 run('actual_current_height_'+str(bits),lambda:o.exterior_phase_derivative(p,r,charges),bits,True)
 def pos():
  z=o.exterior_phase_derivative(p,r,charges)
  assert z==o.ExteriorPolynomial(((m,o.Polynomial.scalar(o.QComplex(0,F(n,15)))),));return 'exact i*n/15'
 run('actual_current_positive_'+str(bits),pos,bits+8)
run('oversized_equal_charges',lambda:o.exterior_phase_derivative(p,r,{x:2**20,y:2**20}),8,True)
run('valid_equal_charges',lambda:o.exterior_phase_derivative(p,r,{x:2**20,y:2**20}),32)
# Independent source binding helper, no test module imported.
reg=o.OriginalRegulator((1,1,1,1));unit=f.original_spin4_link((0,0,0,1),(0,0,0,1));links={a:unit for a in reg.link_order}
t=o.assemble_coframe(reg,f.original_coframe_blocks(reg,(reg.sites[0],0,3),links)).to_exterior(reg)
E=o.ExteriorPolynomial;P=o.Polynomial.scalar;zero=E();one=E(((0,P(1)),));empty=o.GeneratorLinkSupport((),(),())
def bind(action,measure=None,cancel=False):
 insertion=o.RawJet.constant(one,action.labels); measure=measure or o.RawJet.constant(P(1),action.labels);entries=[]
 for k in action.indices():
  terms=[]
  for role,jet in (('action',action),('insertion',insertion)):
   for mask,coeff in jet.at(k).terms:
    gs=tuple(g for i,g in enumerate(reg.generator_order) if mask>>i&1)
    sup=o.GeneratorLinkSupport(gs,(),tuple(sorted(set(g[0] for g in gs))))
    for key,c in coeff.terms:terms.append(o.GradedTerm(mask.bit_count()//2,(0,0),(0,0),(role,),sup,1,c,mask,key))
  for key,c in measure.at(k).terms:terms.append(o.GradedTerm(0,(0,0),(0,0),('measure',),empty,1,c,None,key))
  if cancel and k==():
   for c in (1,-1):terms.append(o.GradedTerm(0,(0,0),(0,0),('action',),empty,1,o.QComplex(c),0,()))
  entries.append((k,tuple(terms)))
 return o.SourceJet(action.labels,o.SourceFamilyGrading(tuple(entries)),action,insertion,measure)
def contract(s):
 cert=o.SupportCertificate('independent exact fixture',(),s.grading,True,reg.generator_order,reg.link_order)
 return o.contract_original(reg,s,o.CoefficientRequest(None,(),'unit',cert),o.ExactBudget(100000,512*1024**2))
for k in o.RawJet.constant(t).indices():
 values={j:(t if not j else zero) for j in o.RawJet.constant(t).indices()}; values[k]=values[k]+one
 try:bind(o.RawJet((0,1),tuple(values.items())))
 except ValueError as e: assert 'body' in str(e)
 else:raise AssertionError(('nonzero body accepted',k))
 receipts.append(dict(name='action_body_slot_'+str(k),result='REFUSED'))
fourth=t*t*t*t;assert fourth==E(((255,P(24)),))
action=o.RawJet.from_slots((t,t,zero,t*2,zero,zero))
for name,s,expected in [('acceleration',bind(action),(1,4,20)),('moving_measure',bind(action,o.RawJet.from_slots(tuple(map(P,(3,1,0,0,0,0))))),(3,13,68)),('cancelled_body',bind(o.RawJet.constant(t),cancel=True),(1,0,0))]:
 result=contract(s); assert tuple(dict(result.N)[k] for k in ((),(0,),(0,0)))==tuple(map(P,expected));receipts.append(dict(name=name,result=expected,cost=result.cost))
result={'receipts':receipts,'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'wall_seconds':time.monotonic()-started,'scientific_control_executed':False}
assert result['RSS_bytes']<512*1024**2
open('/tmp/task2-algebra-cost-r3-probe.json','w').write(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
