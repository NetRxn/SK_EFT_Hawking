from pathlib import Path
import subprocess,os,sys,time,json,resource
root=Path.cwd();env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONPATH=str(root))
argv=[sys.executable,'-B','-m','pytest','-m','','tests/test_original_coefficients.py','tests/test_dependency_declaration.py','tests/test_original_coefficient_jets.py','-k','not test_original_full_small_carrier_direct_vs_auxiliary','-vv','-s','-p','no:cacheprovider','--junitxml=/tmp/task2-algebra-cost-r3-bounded.xml']
t=time.monotonic()
with open('/tmp/task2-algebra-cost-r3-bounded.log','w') as out:r=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
p={'argv':argv,'cwd':str(root),'returncode':r.returncode,'wall_seconds':time.monotonic()-t,'child_peak_RSS_bytes':rss,'full_scientific_control_selected':False}
Path('/tmp/task2-algebra-cost-r3-run.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p));assert r.returncode==0 and rss<512*1024**2
