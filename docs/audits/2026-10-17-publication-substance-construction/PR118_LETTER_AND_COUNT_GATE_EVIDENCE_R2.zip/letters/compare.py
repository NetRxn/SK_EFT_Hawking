import ast,json,re,subprocess
PINS=['020171961','1aad9f12','115e00122']
def show(r,p):return subprocess.check_output(['git','show',f'{r}:{p}'],text=True)
def reg(r):
 a=ast.parse(show(r,'src/core/citations.py'))
 for n in a.body:
  if isinstance(n,ast.Assign) and any(getattr(t,"id",None)=="CITATION_REGISTRY" for t in n.targets):return ast.literal_eval(n.value)
  if isinstance(n,ast.AnnAssign) and getattr(n.target,'id',None)=='CITATION_REGISTRY':return ast.literal_eval(n.value)
def tokens(tex,c):
 return {item.strip() for x in re.findall(r'\\'+c+r'(?:\[[^\]]*\])?\{([^{}]+)\}',tex) for item in x.split(',')}
regs={r:reg(r) for r in PINS}
for c in ('E1','E2'):
 tex={r:show(r,f'papers/{c}/paper_draft.tex') for r in PINS}
 k={r:tokens(v,'(?:cite|citenum)') for r,v in tex.items()}
 b={r:tokens(v,'bibitem') for r,v in tex.items()}
 print(c,'frontier added citations',sorted(k[PINS[1]]-k[PINS[0]]),'removed', sorted(k[PINS[0]]-k[PINS[1]]),'frontier unbib', sorted(k[PINS[1]]-b[PINS[1]]))
 for r in PINS[1:]:
  print(c,r,'main registry differences')
  for key in sorted(k[PINS[1]]):
   x,y=regs[PINS[0]].get(key),regs[r].get(key)
   if not x or not y:
    print(key,'missing',x is None,y is None);continue
   out=[i for i in set(x)|set(y) if x.get(i)!=y.get(i)]
   if out:print(key,sorted(out))
for f,names in [('src/core/visualizations.py',['fig_polariton_regime_map','fig_stimulated_hawking_spectrum','fig_graphene_noise_spectrum','fig_graphene_hawking_temperature_sweep']),('src/core/formulas.py',['stimulated_hawking_spectrum','stimulated_hawking_gain','polariton_hawking_temperature']),('src/graphene/wkb_spectrum.py',['compute_graphene_spectrum']),('src/experimental/polariton_predictions.py',['polariton_regime_map'])]:
 def funcs(r):
  out={}
  for n in ast.parse(show(r,f)).body:
   if isinstance(n,ast.FunctionDef) and n.name in names:
    if isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):n.body.pop(0)
    out[n.name]=ast.dump(n)
  return out
 a,b,c=map(funcs,PINS)
 for k in names:print('non-docstring AST',k, ('F=M',a.get(k)==b.get(k)),('N=M',a.get(k)==c.get(k)),('F=N',b.get(k)==c.get(k)))
for r in PINS:
 j=json.loads(show(r,'docs/primary_sources_state.json'))
 for key in ['Amelio2020','AndersonBFP2014Graybody','Coutant2014','CoutantWeinfurtner2018KdV','Barcelo2011']:
  v=j['entries'].get(key);print('custody',r,key, None if v is None else (v.get('primary_source_path'),v.get('sha256')))
