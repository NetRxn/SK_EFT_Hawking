# Signed coframe Q3 pilot and complete leaf-reduced mixed subclass

The primary packet `l1-c0-coframe-q3-author-r1.json` checked fresh at
`27012c18fa374e8341e124b510abbedeedb18d29`. This work depends on the
frozen degree package
`/private/tmp/l1-n16-c0-degree.1K9GzWW5/manifest.sha256`, digest
`8f1654b9b7c52730e3840ed2020df9419e1172eb78b5f438d6c725b49a2a48b0`.
All prior entries reverified and were used read-only. The prior
support, leaf rule and signed slice derivations are under separate
independent review. This package adds the complete signed octagon
and evaluates every remaining orbit of the fully leaf-reduced
mixed subclass. It does not certify the full degree block or c0.

## Exact reduction and original normalization

The independent temporal-anchor leaf integration from the prior
report applies to each of these representatives. When a temporal
anchor is used by only one occupied root, condition on every other
link and every coframe. The actual rooted holonomy is Haar by
left and right invariance of the leaf link's independent Haar.
The resulting local moment is independent of the root's spatial
curvature anchors, while those links remain wherever coframes or
other factors use them. No residual shared spatial Haar is split
before its curvature factors have been removed by this rule.

The exact `census.py` replay finds 12 fully leaf-reduced mixed
orbits, with 312 labeled occupations. Each layer has four active
vertices, each with one temporal-curvature plane of multiplicity
four. The four remaining vertices are inactive. The eight
coframe edges each have four occurrences, all centered at their
active endpoint. Each vertex has exactly two incident coframe
edges. The graph is consequently a union of alternating cycles.
The labeled Q3 census checks every component and finds either two
four-cycles or one eight-cycle per layer. The direction pairs at
active vertices can differ. Their common signed local polynomial
is symmetric in its two coframe directions.

At an active vertex let W be the squared antisymmetric coframe
bivector polynomial from the source chiral Gram. The left and
right chiral squared lengths are each W, because the symmetrized
original Grams are identical. For one Haar chirality the exact
moments of twice a quaternion component are 1 and 2 in degree
two and four. Isotropy gives the corresponding W and 2W²
contractions. The independent left and right fourth moment
is therefore (2+2+6)W²=10W². The current source check verifies
the moments against the canonical Haar function and regenerates
the original coframe rosters and Grams byte for byte. It also
checks equality under relabeling of axes 0,1,2. The curvature
world sign is raised to the fourth power at each active root.
All eight original exponential divisors 4! are retained. Once
the temporal leaves are removed, the two spatial-layer
contractions are independent because their remaining coframes
use disjoint anchored links. Unused normalized Haar factors
integrate to one.

## Signed transfer and preflight

For an edge let E be the fourth Haar tensor with all four
coframes centered at its active endpoint. Its active interface
is a sorted symmetric quartic internal label and a degree-four
source mask, at most 35×70 entries. Its inactive interface
is only the degree-four mask, of size 70. Every quaternion
coordinate retains its original anchor and chirality. The
edge denominator is 4^4·48=12288.

Let V_A contract the two active endpoint interfaces by the
local W² coefficient and the signed complementary-mask
product. Let P contract two inactive endpoint masks by the
same original exterior complement sign. The half transfer is

```
B = P E^T V_A E.
```

The transpose is plain transpose because the sewn coefficient
is bilinear. Each edge supplies degree four at both endpoints.
Regrouping local words from different vertices gives an even
permutation. Reordering whole eight-generator site tops also
gives an even permutation. Reversing the two local degree-four
inputs leaves the complement sign unchanged, and W² is
symmetric in the two incident coframe directions. Therefore
the alternating four-cycle is trace(B²), and the alternating
eight-cycle is trace(B⁴), with all original signs included.
A four-cycle decomposition of a layer multiplies its two
signed cycle values. There is no further sign for their
separation.

The compiled stage preflight bounds the explicit matrix
buffers by 5,566,400 bytes against an 8 MiB cap. It caps
each Haar candidate grouping and matching phase separately
at 50 million products. The canonical grouping attempts
1,036,576 fourth-moment joins, the crossed pairing 1,476,800,
and the reversed endpoint grouping 1,036,576. They agree
entry by entry. The 380-entry edge tensor gives 7,344
products for E^T V_A E and a 44-bit conservative integer
intermediate bound. The source exterior implementation
independently verifies all 70 complement signs.

After collecting the exact transfer numerator and dividing
by the edge denominators, B is 45/128 times a 70×70 integer
matrix with just 38 nonzero entries. All 38 are positive
after the original active and inactive signs have been
applied. Its second and fourth integer trace powers are
3,554 and 1,371,074 respectively. The two evaluation routes
are sparse path multiplication and direct enumeration of
closed walks. The former checks 102 actual square products.
The latter admits 17,920 path candidates and finds 326
closed length-four walks. Their signed contributions
reproduce the same trace. The Python stages cap transfer
input size, products and integer height before expansion.

The signed cycle factors are

```
C4 = 3598425/8192
C8 = 2811130160625/134217728.
```

The first agrees with the prior exact checkerboard square.
The second is the new eight-site coframe-only Q3 value.
Both include all coframe quarters and both original Haar
anchors on each occupied edge.

## Adverse orientation control

Dropping the active complement signs changes 16 signs of
the open transfer. For example the original unnormalized
E^T V_A E entry at masks (53,197) is −424673280, and
the mutant gives +424673280. Applying the same wrong sign
convention at every active vertex happens to leave the
even-cycle trace unchanged in this restricted family.
That symmetric mutation would be an inadequate test.
Dropping the signs at exactly one active vertex while
retaining the others changes the normalized integer
trace-four from 1,371,074 to 846,786. Its incorrect cycle
coefficient is 1736175920625/134217728. The mutant is
a check of the orientation sensitivity, not an original
occupation. The original transfer has no negative closed
walk contributions after the signed local contraction.

## Exact named pilot and extension

For representative `(279173922820,289913962500)`, layer A
has cycles [0,1,3,2] and [4,5,7,6]. Layer B has cycle
[0,1,5,4,6,7,3,2]. The representative and its 48-member
orbit are strictly positive. The exact values are

```
representative = (10/4!)^8 C4^2 C8
               = 2167184382563530426025390625/590295810358705651712
orbit-weighted = 6501553147690591278076171875/36893488147419103232.
```

The same measured transfer evaluates all 12 fully leaf-reduced
mixed orbits. Their exact breakdown is

| Combined cycle lengths across both layers | Orbits | Labeled occupations |
| --- | ---: | ---: |
| 4,4,4,4 | 2 | 24 |
| 4,4,8 | 4 | 144 |
| 8,8 | 6 | 144 |

Each individual value is positive. The orbit-weighted subtotal
for this complete mixed subclass is

```
103138812487219824371337890625/73786976294838206464.
```

Two of the orbits were already evaluated in the prior package.
This advances the signed intake by ten orbits and 288 labeled
occupations. Together with the 22 common-axis orbits, the
combined signed census covers 34 orbits and 603 labeled
coarse survivors of the declared n=16 A-only/B-only block.
There remain 11,889 orbits and 1,020,621 labeled coarse
survivors in that block. The other degree blocks are also
outside this result. No positivity or nonvanishing of the
full c0 follows from this positive subclass.

## Reproduction and scope

The canonical and two adverse transfer modes are
`./transfer canonical`, `./transfer abs-edge`, and
`./transfer no-active-wedge`. Compile `transfer.cpp` with
`clang++ -std=c++20 -O3 -Wall -Wextra -Werror`.
The source check requires the exact primary checkout on
PYTHONPATH, its existing venv interpreter, and
PYTHONDONTWRITEBYTECODE=1. Run `source.py`, then the
compiled transfer modes, then `cycle.py` and `census.py`.
The latter reads the prior representative table read-only.
`orbit-values.tsv` retains the exact values and weights.
The native routines, matrix signs and new signed values
are scratch only and require independent review. No prior
artifact, tracked file, Git state or Lean slot was changed.
