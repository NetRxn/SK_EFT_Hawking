#define main reference_slice_entrypoint
#include "slice_reference.cpp"
#undef main
#include <map>

using Labels = std::array<int,4>;
constexpr int N = 70, ACTIVE = 35*N;

LinearRoster read_edge_coframes() {
    std::ifstream f("edge_coframes.tsv");
    LinearRoster out;
    int x,a,q,r,i;
    unsigned mask;
    while(f>>x>>a>>mask>>q>>r>>i)out.at(x).at(a).push_back({mask,q,{r,i}});
    for(const auto& v:out)
        for(const auto& r:v)
            if(r.size()!=64)throw std::runtime_error("pilot source edge roster");
    return out;
}
int main(int argc,char** argv) {
    try {
        const std::string mode=argc>1?argv[1]:"canonical";
        const auto src=read_edge_coframes();
        std::array<std::array<QuadRoster,4>,4> pairs;
        for(int a=0;a<4;++a)
            for(int b=a;b<4;++b) pairs[a][b]=square_pair(src[0][a],src[0][b]);
        std::vector<Labels> types;
        std::map<Labels,int> type_id;
        U64 budget=0;
        for(int a=0;a<4;++a)
            for(int b=a;b<4;++b)
                for(int c=b;c<4;++c)
                    for(int d=c;d<4;++d){
                        type_id[{a,b,c,d}]=types.size();
                        types.push_back({a,b,c,d});
                        budget+=candidates(pairs[a][b],pairs[c][d]);
                    }
        if(types.size()!=35||budget>MAX_MOMENT_PAIRS)
            throw std::runtime_error("pilot edge preflight cap");
        std::cout<<"same-endpoint fourth Haar candidate joins "<<budget<<'\n';
        std::array<int,256> pos;pos.fill(-1);
        std::vector<unsigned> masks;
        for(unsigned m=0;m<256;++m)
            if(std::popcount(m)==4){pos[m]=masks.size();masks.push_back(m);}
        constexpr size_t MAX_MATRIX_BUFFER=8*1024*1024;
        constexpr size_t matrix_bytes=(2*ACTIVE*N+N*N)*sizeof(Z);
        if(matrix_bytes>MAX_MATRIX_BUFFER)throw std::runtime_error("pilot matrix buffer cap");
        std::cout<<"preflight explicit matrix buffer bytes "<<matrix_bytes<<'\n';
        auto build_edge = [&](bool mixed, bool reversed) {
            std::array<std::array<QuadRoster,4>,4> rev;
            if(reversed)
                for(int a=0;a<4;++a)
                    for(int b=a;b<4;++b) rev[a][b]=square_pair(src[1][a],src[1][b]);
            const auto& roster=reversed?rev:pairs;
            U64 work=0;
            for(const auto& labels:types) {
                auto [a,b,c,d]=labels;
                if(mixed) std::swap(b,c);
                work+=candidates(roster[a][b],roster[c][d]);
            }
            if(work>MAX_MOMENT_PAIRS)throw std::runtime_error("pilot alternate edge cap");
            std::cout<<"pilot edge candidate grouping "<<mixed<<' '<<reversed<<' '<<work<<'\n';
            Matrix output(ACTIVE*N);
            for(int t=0;t<35;++t){
                auto [a,b,c,d]=types[t];
                if(mixed) std::swap(b,c);
                for(int p=0;p<257;++p)
                    for(const auto& u:roster[a][b][p])
                        for(const auto& v:roster[c][d][p]){
                            if(u.mask&v.mask)continue;
                            unsigned m=u.mask|v.mask;
                            int j=pos[m&255],k=pos[m>>8];
                            if(j<0||k<0)throw std::runtime_error("pilot mask degree");
                            if(reversed)std::swap(j,k);
                            output[(t*N+j)*N+k]+=(u.value*v.value)*(moment48(u,v)*sign(u.mask,v.mask));
                        }
            }
            return output;
        };
        Matrix e=build_edge(false,false);
        if(e!=build_edge(true,false)||e!=build_edge(false,true))
            throw std::runtime_error("pilot endpoint or pairing discrepancy");
        if(mode=="abs-edge")
            for(auto& z:e) z={std::abs(z.re),std::abs(z.im)};
        std::array<std::vector<int>,ACTIVE> support;
        U64 nnz=0,height=0;
        for(int i=0;i<ACTIVE;++i)
            for(int j=0;j<N;++j)
                if(const auto z=e[i*N+j];z){
                    support[i].push_back(j);++nnz;height=std::max(height,z.height());
                }
        std::cout<<"pilot edge nnz "<<nnz<<" height "<<height<<'\n';
        std::array<std::pair<int,int>,10> pair_labels;
        int n=0;
        for(int i=0;i<4;++i)for(int j=i;j<4;++j)pair_labels[n++]={i,j};
        auto gram=read_gram();
        std::array<std::array<int,35>,35> w2{};
        auto merge=[&](int i,int j){
            auto [a,b]=pair_labels[i];auto[c,d]=pair_labels[j];
            Labels v={a,b,c,d};std::sort(v.begin(),v.end());return type_id.at(v);
        };
        for(int a=0;a<10;++a)
            for(int b=0;b<10;++b)
                for(int c=0;c<10;++c)
                    for(int d=0;d<10;++d)
                        w2[merge(a,c)][merge(b,d)]+=gram[a][b]*gram[c][d];
        U64 products=0,local_height=0;
        for(int a=0;a<35;++a)
            for(int b=0;b<35;++b)
                if(w2[a][b]){
                    local_height=std::max(local_height,U64(std::abs(w2[a][b])));
                    for(int m=0;m<N;++m)
                        products+=support[a*N+m].size()*support[b*N+pos[255^masks[m]]].size();
                }
        const int contraction_bits=2*std::bit_width(height)+std::bit_width(local_height)+std::bit_width(products);
        std::cout<<"pilot matching products "<<products<<" local weight height "<<local_height
                 <<" conservative intermediate bits "<<contraction_bits<<'\n';
        if(products>MAX_MATCH_PRODUCTS||contraction_bits>62||14+2*contraction_bits>126)
            throw std::runtime_error("pilot matching or exact-height cap");
        Matrix middle(N*N);
        for(int a=0;a<35;++a)
            for(int b=0;b<35;++b)
                if(w2[a][b])
                    for(int m=0;m<N;++m){
                        unsigned mask=masks[m];
                        int i=a*N+m,j=b*N+pos[255^mask];
                        int s=w2[a][b]*(mode=="no-active-wedge"?1:sign(mask,255^mask));
                        for(int u:support[i])
                            for(int v:support[j])
                                middle[u*N+v]+=(e[i*N+u]*e[j*N+v])*s;
                    }
        std::ofstream out(mode=="canonical"?"transfer.tsv":"transfer-"+mode+".tsv");
        for(int u=0;u<N;++u)
            for(int v=0;v<N;++v)
                if(const Z z=middle[u*N+v];z)
                    out<<masks[u]<<'\t'<<masks[v]<<'\t'<<z.re<<'\t'<<z.im<<'\n';
        if(!out)throw std::runtime_error("transfer export failure");
        I128 re=0,im=0;
        for(int i=0;i<N;++i)
            for(int j=0;j<N;++j){
                unsigned u=masks[i],v=masks[j];
                const Z a=middle[pos[255^u]*N+j]*sign(u,255^u);
                const Z b=middle[pos[255^v]*N+i]*sign(v,255^v);
                re+=I128(a.re)*b.re-I128(a.im)*b.im;
                im+=I128(a.re)*b.im+I128(a.im)*b.re;
            }
        if(im)throw std::runtime_error("pilot imaginary top");
        std::cout<<"pilot checkerboard slice numerator "<<dec(re)<<" denominator 12288 power 4\n";
    } catch(const std::runtime_error& e) {
        std::cout<<"REFUSED "<<e.what()<<'\n';
        return 2;
    }
}
