from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import reduce
from math import gcd
from pathlib import Path
MAX_ROWS=4900
MAX_PATH_PRODUCTS=1000000
MAX_BITS=256
D=12288

assert Path("transfer.tsv").stat().st_size<=2**20
data=[tuple(map(int,x.split())) for x in Path("transfer.tsv").read_text().splitlines()]
assert len(data)<=MAX_ROWS
mid={(a,b):r for a,b,r,i in data}
assert len(mid)==len(data) and all(i==0 for a,b,r,i in data)
assert all(a.bit_count()==b.bit_count()==4 for a,b in mid)
assert all(mid[b,a]==v for (a,b),v in mid.items())
scale=reduce(gcd,mid.values())
mid={k:n//scale for k,n in mid.items()}

def sign(a,b):
    return (-1)**sum(x>y for x in range(8) if a>>x&1
                    for y in range(8) if b>>y&1)

def transfer(drop_wedge=False):
    return {(255^a,b):v*(1 if drop_wedge else sign(255^a,a))
            for (a,b),v in mid.items()}

def rows(a):
    out=defaultdict(list)
    for (i,j),n in a.items():
        out[i].append((j,n))
    return out

def mult(a,b):
    r=rows(b)
    work=sum(len(r[j]) for i,j in a)
    max_height=max((abs(v).bit_length() for v in a.values()),default=0)+max(
        (abs(v).bit_length() for v in b.values()),default=0)+max(1,work.bit_length())
    assert work<=MAX_PATH_PRODUCTS and max_height<=MAX_BITS
    out=Counter()
    for (i,j),v in a.items():
        for k,w in r[j]:
            out[i,k]+=v*w
    return {k:v for k,v in out.items() if v}, work, max_height

def traces(a):
    b,work,bits=mult(a,a)
    return sum(x*a.get((j,i),0) for (i,j),x in a.items()),sum(
        x*b.get((j,i),0) for (i,j),x in b.items()),work,bits

B=transfer()
t2,t4,work,bits=traces(B)
# Independent direct closed-walk route using the actual sparse successor
# lists, without calling the path-matrix multiplication above.
r=rows(B)
walk_bound=70*max(map(len,r.values()))**4
assert walk_bound<=MAX_PATH_PRODUCTS
assert 4*max(abs(v).bit_length() for v in B.values())+walk_bound.bit_length()<=MAX_BITS
positive=negative=walks=0
for i in r:
    for j,a in r[i]:
        for k,b in r[j]:
            for l,c in r[k]:
                for dest,d in r[l]:
                    if dest!=i: continue
                    x=a*b*c*d
                    walks+=1
                    if x<0: negative+=x
                    else: positive+=x
assert positive+negative==t4
q=F(scale,D*D)
c4=t2*q*q
c8=t4*q**4
assert c4==F(3598425,8192)
print("transfer support",len(B),"scalar numerator gcd",scale,"normalized rational scale",q)
print("square path preflight products",work,"integer bit bound",bits)
print("direct trace walk bound",walk_bound,"closed walks",walks,"positive mass",positive,"negative mass",negative)
print("unnormalized trace powers",t2,t4)
print("checkerboard Q2 square",c4)
print("coframe-only Q3 octagon",c8)
unsigned=traces({k:abs(v) for k,v in B.items()})
no_wedge=traces(transfer(True))
print("adverse control absolute transfer trace-four",unsigned[1])
print("adverse control omit inactive wedge trace-four",no_wedge[1])
Path("cycles.tsv").write_text(f"4\t{c4}\n8\t{c8}\n")

# A wrong active-site wedge convention on just one vertex cannot hide
# in the even-cycle cancellation seen when the same convention is
# incorrectly changed at every active vertex.
bad={(a,b):r//scale for a,b,r,i in
     [tuple(map(int,x.split())) for x in Path("transfer-no-active-wedge.tsv").read_text().splitlines()]}
assert len(bad)==len(mid) and set(bad)==set(mid)
different=[k for k in mid if mid[k]!=bad[k]]
assert len(different)==16 and all(mid[k]==-bad[k] for k in different)
badB={(255^a,b):v*sign(255^a,a) for (a,b),v in bad.items()}
assert traces(badB)[1]==t4
squared,_,_=mult(B,B)
cubed,_,_=mult(B,squared)
wrong_once=sum(v*cubed.get((b,a),0) for (a,b),v in badB.items())
assert wrong_once!=t4
assert all(v>0 for v in B.values())
print("adverse active complement omission changes 16 open transfer signs")
print("one wrong active vertex trace-four",wrong_once,"correct",t4)
print("one wrong active vertex coframe Q3 control",wrong_once*q**4)
