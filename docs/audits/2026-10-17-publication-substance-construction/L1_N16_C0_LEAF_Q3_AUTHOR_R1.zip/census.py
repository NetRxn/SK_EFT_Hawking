from collections import Counter
from pathlib import Path
prior=Path("/private/tmp/l1-n16-c0-degree.1K9GzWW5")
local=[(a,b,c) for a in range(5) for b in range(5-a) for c in range(5-a-b)]
def decode(code): return [local[(code>>(6*v))&63] for v in range(8)]
def strip(m):
    edges={(u,u^(1<<k)):(m[u][k],m[u^(1<<k)][k]) for u in range(8) for k in range(3)
           if u<(u^(1<<k)) and (m[u][k] or m[u^(1<<k)][k])}
    while edges:
        degree=Counter(v for edge in edges for v in edge)
        leaf=next((e for e,(a,b) in edges.items()
                   if min(degree[e[0]],degree[e[1]])==1 and min(a,b)==0),None)
        if leaf is None:return False
        assert sum(edges.pop(leaf))%2==0
    return True

def shapes(m):
    h=[[sum(r)-x for x in r] for r in m]
    edges=[(u,u^(1<<k),h[u][k],h[u^(1<<k)][k]) for u in range(8) for k in range(3)
           if u<(u^(1<<k)) and (h[u][k] or h[u^(1<<k)][k])]
    active=Counter(tuple(sorted((a,b))) for u,v,a,b in edges)
    return active,Counter(tuple(sorted(r)) for r in m)
assert (prior/"orbits-slab.tsv").stat().st_size<=2**20
rows=[]
for a,b,w in (map(int,r.split()) for r in (prior/"orbits-slab.tsv").read_text().splitlines()):
    A,B=decode(a),decode(b)
    if len({k for r in A+B for k in range(3) if r[k]})<=1 or not (strip(A) and strip(B)):
        continue
    rows.append((a,b,w))
    print(a,b,w,shapes(A),shapes(B))
assert len(rows)==12 and sum(r[2] for r in rows)==312

from fractions import Fraction as F
from collections import defaultdict
co={int(n):F(c) for n,c in (line.split() for line in Path("cycles.tsv").read_text().splitlines())}
assert set(co)=={4,8}
def components(m):
    h=[[sum(r)-x for x in r] for r in m]
    graph=[set() for _ in m]
    active={v for v,r in enumerate(m) if sum(r)}
    assert len(active)==4 and all(sorted(m[v])==[0,0,4] for v in active)
    for v in range(8):
        for k in range(3):
            w=v^(1<<k)
            if h[v][k]+h[w][k]:
                graph[v].add(w)
                assert sorted((h[v][k],h[w][k]))==[0,4]
                assert (v in active) != (w in active)
    assert all(len(x)==2 for x in graph)
    unseen=set(range(8))
    cycles=[]
    while unseen:
        start=min(unseen)
        cycle=[start]
        old,start_neighbor=start,min(graph[start])
        while start_neighbor!=start:
            assert start_neighbor not in cycle
            cycle.append(start_neighbor)
            old,start_neighbor=start_neighbor,next(iter(graph[start_neighbor]-{old}))
        unseen-=set(cycle)
        assert len(cycle) in (4,8)
        cycles.append(cycle)
    return cycles

weighted=F(0); hist=Counter();types=Counter()
values=[]
for a,b,w in rows:
    A,B=components(decode(a)),components(decode(b))
    lens=tuple(sorted(map(len,A+B)))
    exact=F(10,24)**8
    for length in lens:
        exact*=co[length]
    assert exact>0
    hist[lens]+=w
    types[lens]+=1
    weighted+=w*exact
    values.append((a,b,w,exact))
    if (a,b)==(279173922820,289913962500):
        assert lens==(4,4,8) and w==48
        print("named pilot layer cycles",A,B)
        print("named pilot exact signed value",exact,"weighted contribution",w*exact)
for typ,w in sorted(hist.items()):
    print("cycle type",typ,"orbits",types[typ],"labeled",w)
prior_mass=24
print("fully leaf-reduced mixed subtotal",weighted)
print("newly signed orbits",10,"newly signed labels",312-prior_mass)
print("remaining declared bidegree block orbits",11923-(22+12),
      "remaining labeled support",1021224-291-312)
Path("orbit-values.tsv").write_text("".join(f"{a}\t{b}\t{w}\t{z}\n" for a,b,w,z in values))
