# Author evidence pending independent review

The frozen contraction covers all 12 fully leaf-reduced mixed orbits. Full block and c0 remain open.
