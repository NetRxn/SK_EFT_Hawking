from fractions import Fraction as F
from itertools import permutations, product
from math import prod
from dataclasses import dataclass
import json

from src.vestigial.original_coefficients import (
    OriginalRegulator, Polynomial, QComplex, Symbol, assemble_dirac, determinant_jet
)

@dataclass(frozen=True)
class C:
    r: F = F(0)
    i: F = F(0)
    def __add__(self,b):
        b=b if isinstance(b,C) else C(b)
        return C(self.r+b.r,self.i+b.i)
    __radd__=__add__
    def __mul__(self,b):
        b=b if isinstance(b,C) else C(b)
        return C(self.r*b.r-self.i*b.i,self.r*b.i+self.i*b.r)
    __rmul__=__mul__
    def __neg__(self):
        return C(-self.r,-self.i)
    def bar(self):
        return C(self.r,-self.i)

O=C(); I=C(0,1); U=C(1)
def block(q):
    a,b,c,d=map(C,q)
    return ((a+d*I,c+b*I),(-c+b*I,a+(-d)*I))
def diag(l,r):
    return tuple(tuple(l[i][j] if i<2 and j<2 else r[i-2][j-2] if i>=2 and j>=2 else O
                       for j in range(4)) for i in range(4))
def dagger(M):
    return tuple(tuple(M[j][i].bar() for j in range(len(M))) for i in range(len(M)))
def mm(A,B):
    return tuple(tuple(sum((A[i][k]*B[k][j] for k in range(len(A))),O)
                       for j in range(len(B))) for i in range(len(A)))
def det(A):
    return sum((prod((A[i][p[i]] for i in range(len(A))),start=U) *
                (-1)**sum(p[i]>p[j] for i in range(len(A)) for j in range(i+1,len(A)))
                for p in permutations(range(len(A)))),O)
def gamma(a):
    B=(((O,-I),(-I,O)),((O,C(-1)),(U,O)),((-I,O),(O,I)),((U,O),(O,U)))[a]
    return tuple(tuple(B[i][j-2] if i<2<=j else B[j][i-2].bar() if j<2<=i else O
                       for j in range(4)) for i in range(4))
def inp(x):
    return QComplex(x.r,x.i)
def poly(x):
    return Polynomial.scalar(inp(x))
def out(x):
    return C(x.real,x.imag)
def dense(s):
    return tuple(tuple(out(s.at(i,j).evaluate({})) for j in range(s.size)) for i in range(s.size))
def direct_coeff(A,B,D,bidegree):
    n=len(A)
    v=O
    for p in permutations(range(n)):
        sign=(-1)**sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))
        for tags in product(range(3),repeat=n):
            if (tags.count(1),tags.count(2))==bidegree:
                v+=prod(((A,B,D)[k][i][p[i]] for i,k in enumerate(tags)),start=U)*sign
    return v

points=[(F(1,2),F(1,2),F(-1,2),F(1,2)),(F(3,5),0,F(-4,5),0),
        (0,F(4,5),0,F(3,5)),(F(1,2),F(-1,2),F(-1,2),F(-1,2)),
        (0,0,0,-1)]
entries=slots=norms=cases=nonzero_second=0
for dims, anti, convention in product(((1,1,1,1),(2,2,1,1),(3,1,1,1)),
                                     ((1,1,1,1),(-1,1,-1,1),(-1,-1,-1,-1)),
                                     ('source_C','metric_M')):
    reg=OriginalRegulator(dims,anti,convention)
    sites=tuple(product(*(range(n) for n in dims)))
    ind={x:k for k,x in enumerate(sites)}
    qq={(x,m,s):points[(2*ind[x]+m+(s=='R')*2)%len(points)]
        for x,m,s in product(sites,range(4),('L','R'))}
    links={}
    for x,m in product(sites,range(4)):
        L,R=(block(qq[x,m,s]) for s in ('L','R'))
        for b in (L,R):
            assert det(b)==U and mm(b,dagger(b))==((U,O),(O,U))
            norms+=1
        links[x,m]=diag(L,R)
    h={(x,m,a):C(F((ind[x]+m+2*a)%7-3,3)) for x,m,a in product(sites,range(4),range(4))}
    J={(x,m,a):C(F((ind[x]+a)%3-1,7),F((ind[x]+2*m+a)%5-2,11))
       for x,m,a in product(sites,range(4),range(4))}
    values={Symbol('q',(x,m,s,k)):q for (x,m,s),row in qq.items() for k,q in enumerate(row)}
    values.update({Symbol(f,k):inp(v) for f,items in (('h',h),('J',J)) for k,v in items.items()})
    actual=assemble_dirac(reg)
    numeric_links={k:tuple(tuple(poly(v) for v in row) for row in M) for k,M in links.items()}
    explicit=assemble_dirac(reg,{k:poly(h[k]+J[k]) for k in h},numeric_links)
    def weights(k, val):
        return {k:poly(val)}
    n=4*len(sites)
    def assemble(w):
        z=[[O]*n for _ in range(n)]
        for (x,m,a),v in w.items():
            f=tuple((d+1)%dims[j] if j==m else d for j,d in enumerate(x))
            b=tuple((d-1)%dims[j] if j==m else d for j,d in enumerate(x))
            sf=anti[m] if x[m]==dims[m]-1 else 1
            sb=anti[m] if x[m]==0 else 1
            g=gamma(a if convention=='source_C' else (3,0,1,2)[a])
            uf,ub=links[x,m],links[b,m]
            for y,w,sgn,B in ((x,f,sf,mm(g,dagger(uf))),(f,x,-sf,mm(uf,g)),
                              (x,b,-sb,mm(g,ub)),(b,x,sb,mm(dagger(ub),g))):
                for i,j in product(range(4),repeat=2):
                    z[4*ind[y]+i][4*ind[w]+j]+=v*B[i][j]*F(sgn,4)
        return tuple(map(tuple,z))
    oracle=assemble({k:h[k]+J[k] for k in h})
    assert dense(explicit)==oracle
    for i,j in product(range(n),repeat=2):
        assert out(actual.at(i,j).evaluate(values))==oracle[i][j]
        entries+=1
    if n==4:
        for a,b in [((sites[0],0,0),(sites[0],0,0)),
                    ((sites[0],2,3),(sites[0],1,1)),
                    ((sites[0],1,2),(sites[0],1,2)),
                    ((sites[0],2,1),(sites[0],3,0))]:
            increments=[assemble_dirac(reg,weights(k,U),numeric_links) for k in (a,b)]
            B,D=(assemble({k:U}) for k in (a,b))
            jet=determinant_jet(explicit,increments)
            for key,bd,factor in [((),(0,0),1),((0,),(1,0),1),((1,),(0,1),1),
                                  ((0,0),(2,0),2),((0,1),(1,1),1),((1,1),(0,2),2)]:
                value=direct_coeff(oracle,B,D,bd)*factor
                assert out(jet.at(key).evaluate({}))==value
                slots+=1
                nonzero_second+=int(len(key)==2 and value!=O)
    cases+=1
print(json.dumps(dict(fixtures=cases,normalized_blocks=norms,matrix_entries=entries,
                      selected_raw_slots=slots,nonzero_second_order=nonzero_second)))
