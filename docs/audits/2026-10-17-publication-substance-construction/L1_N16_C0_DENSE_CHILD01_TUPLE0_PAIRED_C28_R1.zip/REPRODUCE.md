# L1 paired coordinate 28 exact subtotal and neighbor reuse probe

The independently reviewed coordinate is (17,(3,)) in descendant (0,1), tuple 0. Its nine disjoint cuts sum to -153959781396137153207967/649037107316853453566312041152512 + 0i. The paired operand, archived exactly by hash, is reconstructed from the original branch operands checked into L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip at 383f42e573962e8f7f41c0111c82a59a605c73ff. Keep normalization 1/(16*4^64) exactly once.

Verify manifest.sha256 here and review-manifest.sha256 in independent/. From author/inner/, run python3 sum-case28.py and compare all lines to author-case28.tsv. Use sum-shards.py for cuts 5 and 6 with argument 8 to reproduce the sharded subtotals and check the full eight-interval covers. Compare with independent/audit.out and the independent raw-scalar receipts.

Recreate the branch operands as documented in the heavy-coordinate archive, checking each decompressed hash before loading. In its author/pair directory, recreate the paired and cap inputs using:

    python3 sum-branches-checked.py 28
    python3 reduce-label-frontier.py combined-28.pkl sum28
    python3 contract-reduced-label.py sum28

The last command returns 2 and saves the agreed restart. Check author/outer-inputs.sha256 from that directory. In a clean scratch copy with the scripts from author/inner/ and checkpoint/quotient.py, use that cap path for run-primary.py. Then run reduce-open.py 0 2 3 4 5 6 7 8 and finish-triangles.py, directing the primary and rescue logs to primary.tsv and rescue.tsv. Reproduce the operand checksums and signed terminal values. Independent alternate-pivot replays and byte-lineage checks are documented in independent/REPRODUCE.md and pinned by the accompanying review manifest.

The neighboring coordinate 29 investigation is author-only. Reconstruct combined-29.pkl with the original pair constructor and check neighbor/operands.sha256. Run neighbor/compare-neighbor-environment.py from the pair directory to check the unchanged five-factor environment, disjoint supports in the other two factors and exact raw connected-join forecasts. The fixed ordered-axis value-bijection test is obstructed by one unequal support marginal in factor 0. The raw environment join forecast concerns direct joins before new reductions or partitions. It does not rule out pair reuse after a different exact representation or axis permutation.
