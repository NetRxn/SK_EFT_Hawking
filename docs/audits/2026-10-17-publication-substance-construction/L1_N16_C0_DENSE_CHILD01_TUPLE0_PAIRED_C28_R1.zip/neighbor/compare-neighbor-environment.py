from collections import Counter
from itertools import combinations
from pathlib import Path
import pickle

cases = [pickle.loads(Path(f'combined-{index}.pkl').read_bytes()) for index in (28, 29)]
left, right = [case['factors'] for case in cases]
assert cases[0]['binary_sum']['coordinate'] == (17,(3,))
assert cases[1]['binary_sum']['coordinate'] == (24,(3,))
assert len(left) == len(right) == 7
assert left[2:] == right[2:]

print('factor\trows\tkey_overlap\tcoefficient_overlap')
for index, ((axes, a, d), (other, b, e)) in enumerate(zip(left, right, strict=True)):
    assert axes == other and d == e and len(a) == len(b)
    overlap = a.keys() & b.keys()
    print(index, len(a), len(overlap), sum(a[k] == b[k] for k in overlap), sep='\t')
    if index < 2:
        assert not overlap

def selected_pair_products(i, j):
    a, table_a, _ = left[i]
    b, table_b, _ = left[j]
    shared = tuple(axis for axis in a if axis in b)
    if not shared:
        return None
    pa = tuple(a.index(axis) for axis in shared)
    pb = tuple(b.index(axis) for axis in shared)
    ha = Counter(tuple(row[p] for p in pa) for row in table_a)
    hb = Counter(tuple(row[p] for p in pb) for row in table_b)
    return sum(n * hb[k] for k, n in ha.items())

print('left\tright\tcommon_environment_raw_products')
products = []
for i, j in combinations(range(2,7), 2):
    count = selected_pair_products(i,j)
    if count is not None:
        products.append(count)
        print(i,j,count,sep='\t')
print('minimum',min(products),sep='\t')
print('distinct_pair_direct_products',selected_pair_products(0,1),sep='\t')

def axis_counts(factor, axis):
    position = factor[0].index(axis)
    return sorted(Counter(row[position] for row in factor[1]).values())

axis = ('R',0,6,2,1,1)
marginal_left = axis_counts(left[0], axis)
marginal_right = axis_counts(right[0], axis)
assert marginal_left != marginal_right
print('axis_relabel_obstruction',axis, marginal_left,marginal_right,sep='\t')
