from collections import Counter
from decimal import Decimal
from pathlib import Path

print('slice\tstage_receipt\texit_code\twall_seconds')
rows=[]
for i in range(9):
    log=Path(f'lineage-{i}/stage-timing.tsv')
    for line in log.read_text().splitlines():
        ordinal,name,code,seconds=line.split('\t')
        assert int(ordinal)==i and Decimal(seconds)>0
        assert code in ('0','2') and (code=='0' or name.endswith('-contract.out'))
        rows.append((ordinal,name,code,seconds))
assert len(rows)==49 and len({x[:2] for x in rows})==49
assert Counter(code for _,_,code,_ in rows)==Counter({'0':36,'2':13})
assert sum(name.endswith('-plan.out') for _,name,_,_ in rows)==9
assert sum(name.endswith('-reduce.out') for _,name,_,_ in rows)==20
assert sum(name.endswith('-contract.out') for _,name,_,_ in rows)==20
for row in rows:
    print(*row,sep='\t')
