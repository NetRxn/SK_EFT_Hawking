from pathlib import Path
import re
print('slice\tmethod\tproducts\tseconds\treceipt')
for i in range(9):
    if i in (5,6):
        method='triangle pivot 1'
        filename=f'slice-{i}-triangle-replay.out'
        metric=r'^independent pivot 1 .* Gaussian products (\d+) wall seconds (\S+)$'
    else:
        method='plain sparse'
        filename=f'slice-{i}-replay.out'
        metric=r'^exact normalized real .* independent matched products (\d+) wall seconds (\S+)$'
    products,seconds=re.search(metric,Path(filename).read_text(),re.M).groups()
    print(i,method,products,seconds,filename,sep='\t')
