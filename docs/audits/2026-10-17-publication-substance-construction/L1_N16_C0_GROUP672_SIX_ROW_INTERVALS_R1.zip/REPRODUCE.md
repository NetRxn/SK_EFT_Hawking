# L1 group 672 six left-row intervals and bounded contrasts

Six disjoint left-row intervals fully cover the folded join for block 0 of J=(1,) in assignment 7. The complete J scalar and whole-group scalar remain open.

Restore the frozen 16-factor row cap from L1_N16_C0_GROUP672_J1_G_BLOCKS_R1.zip. Match the exact SHA256 in prepare.py. Use prepare.py with that cap, the portable next-row-blocks.tsv roster and the chosen interval index. The six exact row and product totals come from their signed sum of products. Each forced join leaves 15 factors. Run the existing guarded contractor through run-with-join-cap.py and check the exact preserved states. All six generic continuations return status 2 before a further join.

For the smallest interval, use screen-block5-quotient.py with its verified cap. The compensated fold of pair (4,8) leaves the 1,950,336-product candidate. Use contract-with-peer.py through run-with-peer.py in a fresh contrast directory. Optional two-peer support checks are exact necessary conditions with a 100,000-product limit per check. The contrast completes one additional join and reaches a 14-factor join cap. The second fold screen and contrast on pair (1,2) record the later exact operand and row-cap attempt. Consult the independent reports for the scope of review of each contrast.

Check all hashes in operands.sha256. Reproduce matching results and byte-identical exact state files in fresh scratch. Measured command times and peak child memory apply to the stated invocations. See the independent manifest for source binding and exact scope.
