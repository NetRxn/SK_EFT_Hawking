from hashlib import file_digest
from pathlib import Path
from runpy import run_path
from shutil import copyfile

tools=run_path('exact-intervals.py')
D,P=(tools[k] for k in ('D','P'))
once=('prepare.py','next-row-blocks.tsv','contract-with-join-cap.py','run-with-join-cap.py')
per=('prepare.out','contraction.out','contraction.err','contraction.receipt',
     'dense-saturated-frontier.pkl','join-cap-physical-slice-dense-branch.pkl')
paths=[P]+[D/w for w in once]+[D/f'block{i}'/w for i in range(6) for w in per]
with Path('input-operands.sha256').open('w') as digest:
    for p in paths:
        with p.open('rb') as src:
            print(file_digest(src,'sha256').hexdigest(),p,sep='  ',file=digest)
        if p.is_relative_to(D) and p.suffix!='.pkl':
            out=Path('author-receipts')/p.relative_to(D)
            out.parent.mkdir(exist_ok=True,parents=True)
            copyfile(p,out)
