from collections import Counter,defaultdict
from csv import DictReader
from hashlib import file_digest,sha256
from pathlib import Path
from pickle import dump,dumps,load
from math import prod
from time import perf_counter

D=Path('/private/tmp/l1-group672-six-row.V3TMCN')
P=Path('/private/tmp/l1-group672-g-blocks.qQMlwN/fold25/row-cap-physical-slice-dense-branch.pkl')
H='277b2bfb002805a7736cd9a27375853fcf9e68f19feae4b3c445a08ec0b8e3e8'
DEN=576173855599322741762003196268511232
PLAN='next-row-blocks.tsv'

def hashfile(p):
    with p.open('rb') as f: return file_digest(f,'sha256').hexdigest()
def read(p):
    with p.open('rb') as f: return load(f)
def project(row,positions):
    return tuple(row[i] for i in positions)

def validate_origin():
    assert hashfile(P)==H
    cap=read(P)
    F=cap['factors']
    assert len(F)==16 and cap['rejected_pair']==(2,5)
    assert cap['matched']==2734080 and cap['used_before']==0
    assert prod(d for _,_,d in F)==DEN
    degree=Counter(w for axes,_,_ in F for w in axes)
    assert set(degree.values())=={2} and all(k[0]!='L' for k in degree)
    assert cap['physical_cut'][1]==(('G',0,6,0),(81,88,193,200))
    assert cap['physical_cut'][0][1]==(('J',1,1,2),(1,))
    return cap

def specs(F):
    a, A, d=F[2]
    b, B, e=F[5]
    common=tuple(sorted(set(a)&set(b)))
    ai,bi=[tuple(scope.index(w) for w in common) for scope in (a,b)]
    f=[Counter(project(row,ix) for row in table) for table,ix in ((A,ai),(B,bi))]
    forecast=sum(n*f[1][k] for k,n in f[0].items())
    assert forecast==2734080 and len(f[0].keys()&f[1].keys())==12
    eligible=sorted((row,z,f[1][project(row,ai)]) for row,z in A.items() if f[1][project(row,ai)])
    assert len(eligible)==len(A)==2768 and sum(n for _,_,n in eligible)==forecast
    with (D/PLAN).open() as fin:
        rows=list(DictReader(fin,delimiter='\t'))
    assert len(rows)==6
    previous=0
    total=0
    for n,row in enumerate(rows):
        lo,high=map(int,(row['lo'],row['high_exclusive']))
        assert int(row['block'])==n and lo==previous<high and int(row['compatible_rows'])==high-lo
        subset=tuple((k,z) for k,z,_ in eligible[lo:high])
        assert sha256(dumps(subset,protocol=5)).hexdigest()==row['selected_rows_sha256']
        w=sum(q for _,_,q in eligible[lo:high])
        assert w==int(row['matched_product_upper_bound'])<=500000
        previous=high
        total+=w
        yield n,lo,high,w,subset
    assert previous==len(eligible) and total==forecast

def multiply(z,w):
    a,b=z
    c,d=w
    return a*c-b*d,a*d+b*c

def join(F,subset,w):
    S,A,d=F[2]
    T,B,e=F[5]
    same=tuple(sorted(set(S)&set(T)))
    left_shared,right_shared=(tuple(scope.index(k) for k in same) for scope in (S,T))
    left_keep,right_keep=(tuple(i for i,w in enumerate(scope) if w not in same) for scope in (S,T))
    left=defaultdict(list)
    for row,z in subset:
        assert A[row]==z
        left[project(row,left_shared)].append((project(row,left_keep),z))
    acc=defaultdict(lambda:(0,0))
    count=0
    for row,other in B.items():
        suffix=project(row,right_keep)
        for prefix,z in left.get(project(row,right_shared),()):
            term=multiply(z,other)
            key=prefix+suffix
            x,y=acc[key]
            acc[key]=x+term[0],y+term[1]
            count+=1
    assert count==w
    keep={row:z for row,z in acc.items() if any(z)}
    keys=tuple(S[k] for k in left_keep)+tuple(T[k] for k in right_keep)
    assert len(keep)<=len(acc)<=count
    return keys,keep,d*e

if __name__=='__main__':
    start=perf_counter()
    cap=validate_origin()
    F=cap['factors']
    print('block','lo','hi_exclusive','products','joined_rows','axes','joined_denominator','independent_sha256','seconds',sep='\t',flush=True)
    for n,lo,hi,w,subset in specs(F):
        tick=perf_counter()
        focus=join(F,subset,w)
        path=Path(f'independent-join-{n}.pkl')
        with path.open('xb') as stream: dump(focus,stream,protocol=5)
        axes,rows,d=focus
        assert prod(f[2] for i,f in enumerate(F) if i not in (2,5))*d==DEN
        print(n,lo,hi,w,len(rows),len(axes),d,hashfile(path),f'{perf_counter()-tick:.6f}',sep='\t',flush=True)
    assert len(tuple(D.glob('next-row-blocks.tsv')))==1
    print('complete support and selected row key hashes verified',f'{perf_counter()-start:.6f}',flush=True)
