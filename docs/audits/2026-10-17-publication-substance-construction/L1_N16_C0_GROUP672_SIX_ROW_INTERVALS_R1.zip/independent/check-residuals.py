from collections import Counter
from itertools import combinations
from math import prod
from pathlib import Path
from re import fullmatch
from time import perf_counter,sleep
from sys import argv
from gc import collect
from runpy import run_path

v=run_path('exact-intervals.py')
D,DEN,read,hashfile=(v[x] for x in ('D','DEN','read','hashfile'))

def indexes(a,b):
    common=tuple(w for w in a if w in b)
    return tuple(a.index(k) for k in common),tuple(b.index(k) for k in common)

def key(row,idx):
    return tuple(row[k] for k in idx)

def state_summary(F):
    degree=Counter(w for a,_,_ in F for w in a)
    assert set(degree.values())=={2}
    assert all(w[0]!='L' for w in degree)
    assert prod(d for _,_,d in F)==DEN
    return sum(len(r) for _,r,_ in F),len(degree)

def trim(F):
    fs=list(F)
    records=[]
    for sweep in range(2):
        old=sum(len(r) for _,r,_ in fs)
        for i,j in combinations(range(len(fs)),2):
            a,A,d=fs[i]
            b,B,e=fs[j]
            p,q=indexes(a,b)
            if not p: continue
            akeys={key(row,p) for row in A}
            bkeys={key(row,q) for row in B}
            common=akeys&bkeys
            if akeys!=common:
                fs[i]=a,{row:z for row,z in A.items() if key(row,p) in common},d
            if bkeys!=common:
                fs[j]=b,{row:z for row,z in B.items() if key(row,q) in common},e
        records.append(old-sum(len(r) for _,r,_ in fs))
    return fs,records

def forecasts(F):
    report=[]
    for i,j in combinations(range(len(F)),2):
        a,A,_=F[i]; b,B,_=F[j]
        p,q=indexes(a,b)
        if not p: continue
        ax=Counter(key(row,p) for row in A)
        bx=Counter(key(row,q) for row in B)
        compat=ax.keys()&bx.keys()
        report.append((sum(ax[k]*bx[k] for k in compat),i,j,len(compat),len(set(a)^set(b))))
    return sorted(report)

def status_receipt(path):
    stop=perf_counter()+210
    while not path.is_file():
        if perf_counter()>stop: raise TimeoutError(path)
        sleep(1)
    while perf_counter()<stop:
        data=path.read_text()
        m=fullmatch(r'child_status (\d+)\nelapsed_seconds (\S+)\npeak_child_rss_bytes (\d+)\n',data)
        if m: return int(m[1]),float(m[2]),int(m[3])
        sleep(1)
    raise TimeoutError(path)

def verify(n,lo,hi,w,parent):
    start=perf_counter()
    here=D/f'block{n}'
    receipt=here/'contraction.receipt'
    status,elapsed,rss=status_receipt(receipt)
    actual_input=here/'dense-saturated-frontier.pkl'
    state=read(actual_input)
    expected=[p for i,p in enumerate(parent['factors']) if i not in (2,5)]
    expected.append(read(Path(f'independent-join-{n}.pkl')))
    assert expected==state['factors']
    assert state['used_before']==w
    assert state['physical_cut']==(parent['physical_cut'],('left-row-interval',n,lo,hi))
    initial_rows,initial_axes=state_summary(state['factors'])
    print('verified exact forced input',n,'factors',len(expected),'total rows',initial_rows,
          'degree-two axes',initial_axes,'joined rows',len(expected[-1][1]),'hash',hashfile(actual_input),flush=True)
    # The guarded source does two rounds of support-only pruning before trying any join.
    if status!=2:
        raise AssertionError((n,status,elapsed,rss,'manual exact route or failure audit needed'))
    assert (here/'contraction.err').read_bytes()==b''
    lines=(here/'contraction.out').read_text().splitlines()
    assert lines[-1]=='open join cap 15 completed products 0 frontier saved'
    assert len(lines)==2
    assert str(('left-row-interval',n,lo,hi)) in lines[0]
    stopped=here/'join-cap-physical-slice-dense-branch.pkl'
    cap=read(stopped)
    assert cap['physical_cut']==state['physical_cut']
    assert cap['used_before']==w and cap['completed_this_run']==0
    assert cap['refusal']=='no eligible join within 8000000 per join and 40000000 total'
    del expected
    fs,deletions=trim(state['factors'])
    del state
    assert fs==cap['factors']
    rows,axes=state_summary(fs)
    assert sum(deletions)==initial_rows-rows and axes==initial_axes
    print('verified bounded output',n,'status',status,'seconds',elapsed,'RSS bytes',rss,'rows',rows,
          'exact support-only removals by sweep',deletions,'hash',hashfile(stopped),flush=True)
    paths=forecasts(fs)
    assert len(paths)==50 and paths[0][0]>8000000
    print('verified candidate guard',n,'all linked pairs',len(paths),'min',paths[0],'first eight',paths[:8],flush=True)
    print('scope audit seconds',n,f'{perf_counter()-start:.6f}',flush=True)

if __name__=='__main__':
    parent=v['validate_origin']()
    enabled=set(map(int,argv[1:])) or set(range(6))
    for n,lo,hi,p,subset in v['specs'](parent['factors']):
        if n in enabled:
            verify(n,lo,hi,p,parent)
            collect()
