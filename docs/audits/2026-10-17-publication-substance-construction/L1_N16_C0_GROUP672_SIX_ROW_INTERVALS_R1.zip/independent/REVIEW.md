# Group 672 folded block 0 six-row continuation

**The folded block 0 scalar, the J=(1,) scalar and the whole-group signed scalar remain open.** All six forced joins pass independent exact Gaussian arithmetic. Every guarded run stops at a distinct 15-factor join cap with zero generic completed products.

The accepted parent is the folded status-2 cap at SHA-256 `277b2bfb002805a7736cd9a27375853fcf9e68f19feae4b3c445a08ec0b8e3e8`, published in the prior J1 G-block archive and pinned at `6de0e90eecd746c9277149f348efce2f4aebf7d8`. The inherited scope is original label assignment 7, J(1,1,2)=(1,), G(0,6,0)∈{81,88,193,200} and the exact signed quotient of pair (2,5). The author interval roster and guarded scripts match the published bytes.

The independent enumeration accounts for all 12 shared quotient tuples, all 2,768 compatible left rows and all 2,734,080 matching row pairs. Every left row belongs to one disjoint lexicographic interval and its original signed coefficient matches the interval hash. The checker indexes the opposite join table and reproduces every Gaussian target entry and all untouched factors. Each of the six author forced inputs exactly equals the independent factor table reconstruction. The forced join closes the shared axes, leaving 40 outgoing axes and joined denominator 110,592. Full contraction denominator remains `576173855599322741762003196268511232`. The previously accepted external factor is positive `1/(16*4^64)`, for application once to a completed signed scalar.

| Block | Left interval | Exact forced products | Signed output rows | Saved residual rows | Minimum next forecast (pair) | Author wall seconds | Peak child RSS bytes |
|---|---|---:|---:|---:|---|---:|---:|
| 0 | [0,563) | 499,200 | 432,384 | 1,967,872 | 12,513,792 (4,8) | 15.461847 | 1,354,776,576 |
| 1 | [563,893) | 499,968 | 499,968 | 1,967,632 | 10,789,632 (4,8) | 15.764359 | 1,384,316,928 |
| 2 | [893,1544) | 499,968 | 499,968 | 2,069,264 | 14,352,384 (1,2) | 16.211238 | 1,394,360,320 |
| 3 | [1544,2015) | 499,200 | 436,992 | 1,937,824 | 11,787,264 (4,8) | 18.425123 | 1,356,005,376 |
| 4 | [2015,2437) | 499,968 | 489,216 | 1,963,936 | 11,787,264 (4,8) | 17.370161 | 1,377,927,168 |
| 5 | [2437,2768) | 235,776 | 235,776 | 1,830,608 | 8,358,912 (4,8) | 15.900842 | 1,244,250,112 |

The guarded source makes two support-only sweeps before evaluating candidate joins. At each deletion the shared edge tuple is absent from the neighbor's current support, so the row participates in no full matching configuration. Reproducing both sweeps independently matches every saved factor’s axis order, row key, signed coefficient and denominator. The saved states carry their own interval conditions and retain only the measured forced-work counters. All six distinct residual hashes are recorded in `residuals-verified.out`.

For each saved state, exact pair-support histograms over all 50 linked pairs independently put the smallest projected join beyond 8,000,000 products, the source’s per-join guard. The 40,000,000 cumulative-run guard and 500,000 output-row bound remain part of the source configuration. The author wrapper uses a 120-second timeout and records child peak RSS. The audit’s numerical scope ends at the saved residuals and gives no downstream cost bound. Assess signed pre-admission quotienting or a new disjoint cut on a single pinned residual before enlarging this measured cohort.

The forced joins and saved residual table checks can be rerun from this review directory using the pinned binary inputs in `input-operands.sha256`. The manifest binds small receipts, scripts and independent outputs. The author binaries and independent joined tables remain in scratch under their recorded hashes.
