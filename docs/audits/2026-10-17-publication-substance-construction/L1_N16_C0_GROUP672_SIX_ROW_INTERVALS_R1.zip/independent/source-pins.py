from hashlib import sha256
from io import BytesIO
from pathlib import Path
from runpy import run_path
from subprocess import check_output
from zipfile import ZipFile

v=run_path('exact-intervals.py')
a,p,h,plan=(v[k] for k in ('D','P','H','PLAN'))
pub=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
commit='6de0e90eecd746c9277149f348efce2f4aebf7d8'
file='docs/audits/2026-10-17-publication-substance-construction/L1_N16_C0_GROUP672_J1_G_BLOCKS_R1.zip'
get=lambda *cmd: check_output(['git','-C',str(pub),*cmd])
archive=get('show',f'{commit}:{file}')
assert sha256(archive).hexdigest()=='f6a2cda71aa7b3d5a44e4ba6c3cc10cfc369a3d330cac8cb06809aee40da9b25'
assert (pub/file).read_bytes()==archive
assert get('rev-parse',f'{commit}:{file}')==get('rev-parse',f'HEAD:{file}')
print('published archive',commit,get('rev-parse',f'{commit}:{file}').decode().strip(),sha256(archive).hexdigest())
with ZipFile(BytesIO(archive)) as z:
    assert f'{h}  {p}' in z.read('independent/input-operands.sha256').decode().splitlines()
    assert v['hashfile'](p)==h
    print('published folded cap',h,p)
    assert z.read(f'independent/{plan}')==(a/plan).read_bytes()
    print('published interval ledger',v['hashfile'](a/plan),a/plan)
    for path in ('contract-with-join-cap.py','run-with-join-cap.py'):
        assert z.read(f'author/{path}')==(a/path).read_bytes(),path
        print('published guarded script',v['hashfile'](a/path),path)
