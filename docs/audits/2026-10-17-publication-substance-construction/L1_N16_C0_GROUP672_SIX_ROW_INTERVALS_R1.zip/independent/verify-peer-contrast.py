from collections import Counter,defaultdict
from itertools import combinations
from math import gcd
from pathlib import Path
from runpy import run_path
from re import fullmatch
from time import perf_counter

q=run_path('exact-intervals.py')
r=run_path('check-residuals.py')
D,read,hashfile,DEN=(q[x] for x in ('D','read','hashfile','DEN'))
project=q['project']
multiply=q['multiply']
start=perf_counter()
parent=D/'resumable-fold-4-8.pkl'
assert hashfile(parent)=='c119f796e15f761b3bfadeacf83c4fa1dade6d478022409301935444d35f6abf'
start_state=read(parent)
place=D/'block5-fold48'
assert hashfile(place/'dense-saturated-frontier.pkl')==hashfile(parent)
outputs=(place/'contraction.out').read_text().splitlines()
assert outputs[-2:] == ['join 14 1950336 277632 axes 49','open join cap 14 completed products 1950336 frontier saved']
run=fullmatch(r'child_status (\d+)\nelapsed_seconds (\S+)\npeak_child_rss_bytes (\d+)\n',(place/'contraction.receipt').read_text())
assert run.groups()==('2','57.655894','1261142016')
assert not (place/'contraction.err').read_bytes()
expected=(place/'join-cap-physical-slice-dense-branch.pkl')
residue=read(expected)
assert residue['physical_cut']==start_state['physical_cut']
assert residue['completed_this_run']==1950336 and residue['used_before']==235776+1950336
assert len(residue['factors'])==14
res_rows,res_wires=r['state_summary'](residue['factors'])
print('measured signed-fold and peer result',run[1],run[2],run[3],'checkpoint',hashfile(expected),
      'remaining rows',res_rows,'physical wires',res_wires,'denominator',DEN,flush=True)

F,removed=r['trim'](start_state['factors'])
print('initial exact support removals',removed,flush=True)
assert len(F)==15
i,j=4,8
(a,A,d),(b,B,e)=F[i],F[j]
shared=tuple(w for w in a if w in b)
degree=Counter(w for wscope,_,_ in F for w in wscope)
assert all(degree[w]==2 for w in shared)
ai=tuple(a.index(w) for w in shared)
bi=tuple(b.index(w) for w in shared)
al=tuple(k for k,w in enumerate(a) if w not in shared)
bl=tuple(k for k,w in enumerate(b) if w not in shared)
axes=tuple(a[k] for k in al)+tuple(b[k] for k in bl)
assert len(axes)==49
unit=((1,0),(0,1),(-1,0),(0,-1))

def normalized_fibers(table,joint,rest):
    by=defaultdict(list)
    for row,z in table.items():
        by[project(row,joint)].append((project(row,rest),z))
    signatures=set()
    for fiber in by.values():
        c=sorted(fiber)
        content=gcd(*(z for _,xy in c for z in xy))
        assert content>0
        u=max(unit,key=lambda m:multiply(m,c[0][1]))
        signature=tuple((tail,multiply(u,(x//content,y//content))) for tail,(x,y) in c)
        assert signature not in signatures
        signatures.add(signature)
    return by
X=normalized_fibers(A,ai,al)
Y=normalized_fibers(B,bi,bl)
assert set(X)==set(Y)
assert sum(len(X[k])*len(Y[k]) for k in X)==1950336
assert 'quotient before join 15 1950336 1950336 slices 0' in outputs
print('both directions retain all unique Gaussian fibers',len(X),len(Y),flush=True)

arg_positions=lambda names,scope: tuple(scope.index(q) for q in names)
peers=[k for k in range(len(F)) if k not in (i,j)]
constraints=[]
for k in peers:
    scope,R,_=F[k]
    inside=tuple(w for w in scope if w in axes)
    if inside:
        ix=arg_positions(inside,scope)
        constraints.append((arg_positions(inside,axes),{project(row,ix) for row in R}))
claim=[]
for k,l in combinations(peers,2):
    a,A,_=F[k]
    b,B,_=F[l]
    link=tuple(w for w in a if w in b)
    l_out=tuple(w for w in a if w in axes)
    r_out=tuple(w for w in b if w in axes)
    if not link or not l_out or not r_out: continue
    assert not set(link)&set(l_out+r_out)
    assert not set(l_out)&set(r_out)
    grouped=[]
    for scope,rows,target in ((a,A,l_out),(b,B,r_out)):
        common=arg_positions(link,scope)
        boundary=arg_positions(target,scope)
        records={(project(row,common),project(row,boundary)) for row in rows}
        branches=defaultdict(set)
        for atom,candidate in records: branches[atom].add(candidate)
        grouped.append(branches)
    L,R=grouped
    possible=L.keys()&R.keys()
    probes=sum(len(L[k])*len(R[k]) for k in possible)
    if probes>100000:continue
    allowed={lhs+rhs for k in possible for rhs in R[k] for lhs in L[k]}
    claim.append(f'peer pair support {k} {l} projected products {probes} allowed {len(allowed)}')
    constraints.append((arg_positions(l_out+r_out,axes),allowed))
assert claim==[l for l in outputs if l.startswith('peer pair support ')]
print('PASS exact independent projected joint-support checks',len(claim),flush=True)
constraints.sort(key=lambda item:(len(item[1]),-len(item[0])))

joined={}
for joint in sorted(X):
    for suffix,right in Y[joint]:
        for prefix,left in X[joint]:
            row=prefix+suffix
            if any(project(row,cols) not in allowed for cols,allowed in constraints):continue
            x,y=joined.get(row,(0,0))
            k,l=multiply(left,right)
            s=(x+k,y+l)
            if any(s):joined[row]=s
            else:joined.pop(row,None)
            assert len(joined)<=500000
assert len(joined)==277632
factors=[F[k] for k in peers]+[(axes,joined,d*e)]
del F, X, Y, joined, start_state
# After an accepted join, the author makes one additional support pass incident
# to the newly added table. No other generic join was admitted.
tail=len(factors)-1
for i in range(tail):
    a,A,d=factors[i]
    b,B,e=factors[tail]
    p,q=r['indexes'](a,b)
    if not p:continue
    left={project(row,p) for row in A}
    right={project(row,q) for row in B}
    allowed=left&right
    if left!=allowed:
        factors[i]=a,{row:z for row,z in A.items() if project(row,p) in allowed},d
    if right!=allowed:
        factors[tail]=b,{row:z for row,z in B.items() if project(row,q) in allowed},e
assert factors==residue['factors']
print('PASS exact alternate Gaussian join and every final saved factor row',len(factors),res_rows,flush=True)
next=r['forecasts'](factors)
assert next and next[0][0]>8000000
print('PASS independent next-candidate refusal',len(next),'smallest',next[:6],flush=True)
print('total independent wall seconds',f'{perf_counter()-start:.6f}')
