from pathlib import Path
from re import MULTILINE, findall
from hashlib import file_digest
from subprocess import run

data=Path('residuals-verified.out').read_text()
exact=[]
for l in Path('exact-intervals.tsv').read_text().splitlines()[1:-1]:
    n,lo,hi,products,rows,axes,den,h,seconds=l.split('\t')
    exact.append((int(n),int(lo),int(hi),int(products),int(rows),int(axes),int(den),h,float(seconds)))
operator=findall(r'^verified bounded output (\d+) status 2 seconds (\S+) RSS bytes (\d+) rows (\d+) exact support-only removals by sweep \[(\d+), (\d+)\] hash (\S+)$',data,flags=MULTILINE)
guard=findall(r'^verified candidate guard (\d+) all linked pairs 50 min \((\d+), (\d+), (\d+), (\d+), (\d+)\)',data,flags=MULTILINE)
assert len(exact)==len(operator)==len(guard)==6
assert sum(q[3] for q in exact)==2734080
assert {q[5] for q in exact}=={40} and {q[6] for q in exact}=={110592}
assert len(Path('input-operands-verify.out').read_text().splitlines())==len(Path('input-operands.sha256').read_text().splitlines())==41
table=[]
hashes={}
for e,o,g in zip(exact,operator,guard,strict=True):
    i,lo,hi,products,rows,*_=e
    j,elapsed,peak,residue,first,second,h=o
    k,min_work,a,b,_,_=g
    assert i==int(j)==int(k) and int(min_work)>8000000
    assert len(h)==64
    hashes[i]=h
    table.append(f'| {i} | [{lo},{hi}) | {products:,} | {rows:,} | {int(residue):,} | {int(min_work):,} ({a},{b}) | {elapsed} | {int(peak):,} |')
assert len(set(hashes.values()))==6
report='''# Group 672 folded block 0 six-row continuation

**The folded block 0 scalar, the J=(1,) scalar and the whole-group signed scalar remain open.** All six forced joins pass independent exact Gaussian arithmetic. Every guarded run stops at a distinct 15-factor join cap with zero generic completed products.

The accepted parent is the folded status-2 cap at SHA-256 `277b2bfb002805a7736cd9a27375853fcf9e68f19feae4b3c445a08ec0b8e3e8`, published in the prior J1 G-block archive and pinned at `6de0e90eecd746c9277149f348efce2f4aebf7d8`. The inherited scope is original label assignment 7, J(1,1,2)=(1,), G(0,6,0)∈{81,88,193,200} and the exact signed quotient of pair (2,5). The author interval roster and guarded scripts match the published bytes.

The independent enumeration accounts for all 12 shared quotient tuples, all 2,768 compatible left rows and all 2,734,080 matching row pairs. Every left row belongs to one disjoint lexicographic interval and its original signed coefficient matches the interval hash. The checker indexes the opposite join table and reproduces every Gaussian target entry and all untouched factors. Each of the six author forced inputs exactly equals the independent factor table reconstruction. The forced join closes the shared axes, leaving 40 outgoing axes and joined denominator 110,592. Full contraction denominator remains `576173855599322741762003196268511232`. The previously accepted external factor is positive `1/(16*4^64)`, for application once to a completed signed scalar.

| Block | Left interval | Exact forced products | Signed output rows | Saved residual rows | Minimum next forecast (pair) | Author wall seconds | Peak child RSS bytes |
|---|---|---:|---:|---:|---|---:|---:|
'''+ '\n'.join(table)+'''

The guarded source makes two support-only sweeps before evaluating candidate joins. At each deletion the shared edge tuple is absent from the neighbor's current support, so the row participates in no full matching configuration. Reproducing both sweeps independently matches every saved factor’s axis order, row key, signed coefficient and denominator. The saved states carry their own interval conditions and retain only the measured forced-work counters. All six distinct residual hashes are recorded in `residuals-verified.out`.

For each saved state, exact pair-support histograms over all 50 linked pairs independently put the smallest projected join beyond 8,000,000 products, the source’s per-join guard. The 40,000,000 cumulative-run guard and 500,000 output-row bound remain part of the source configuration. The author wrapper uses a 120-second timeout and records child peak RSS. The audit’s numerical scope ends at the saved residuals and gives no downstream cost bound. Assess signed pre-admission quotienting or a new disjoint cut on a single pinned residual before enlarging this measured cohort.

The forced joins and saved residual table checks can be rerun from this review directory using the pinned binary inputs in `input-operands.sha256`. The manifest binds small receipts, scripts and independent outputs. The author binaries and independent joined tables remain in scratch under their recorded hashes.
'''
Path('REVIEW.md').write_text(report)
names=['REVIEW.md','continuity.json','continuity-readback.json','source-pins.py','source-pins.out',
       'exact-intervals.py','exact-intervals.tsv','exact-intervals.time','check-residuals.py',
       'residuals-verified.out','residuals-verified.time','freeze-inputs.py','input-operands.sha256',
       'input-operands-verify.out','freeze-review.py']
paths=sorted([*map(Path,names),*(p for p in Path('author-receipts').rglob('*') if p.is_file())])
m=Path('review-manifest.sha256')
with m.open('w') as file:
    for p in paths:
        with p.open('rb') as data:
            print(file_digest(data,'sha256').hexdigest(),p,sep='  ',file=file)
with Path('review-manifest-verify.out').open('w') as output:
    run(['shasum','-a','256','-c',str(m)],stdout=output,check=True)
assert len(Path('review-manifest-verify.out').read_text().splitlines())==len(paths)
with m.open('rb') as src:
    print('manifest',file_digest(src,'sha256').hexdigest(),'files',len(paths))
