from collections import Counter,defaultdict
from csv import DictReader
from hashlib import file_digest,sha256
from math import prod
from pathlib import Path
from pickle import dump,dumps,load
import sys

parent,roster=map(Path,sys.argv[1:3])
block=int(sys.argv[3])
with parent.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='277b2bfb002805a7736cd9a27375853fcf9e68f19feae4b3c445a08ec0b8e3e8'
    stream.seek(0)
    state=load(stream)
with roster.open() as stream:
    plan=list(DictReader(stream,delimiter='\t'))
orig=state['factors']
i,j=state['rejected_pair']
assert (i,j)==(2,5) and len(orig)==16
A,X,d=orig[i]
B,Y,e=orig[j]
shared=tuple(w for w in A if w in B)
ap=tuple(A.index(w) for w in shared)
bp=tuple(B.index(w) for w in shared)
ax=tuple(k for k in range(len(A)) if A[k] not in shared)
bx=tuple(k for k in range(len(B)) if B[k] not in shared)
def project(row,cols):
    return tuple(row[k] for k in cols)
right=defaultdict(list)
for row,value in Y.items():
    right[project(row,bp)].append((project(row,bx),value))
eligible=tuple((row,value) for row,value in sorted(X.items()) if project(row,ap) in right)
assert len(eligible)==2768
def unpack(q):
    return tuple(int(q[k]) for k in ('block','lo','high_exclusive','compatible_rows','matched_product_upper_bound'))
spec=[unpack(row) for row in plan]
assert [q[0] for q in spec]==list(range(6))
assert [q[1] for q in spec]==[0,*[q[2] for q in spec[:-1]]] and spec[-1][2]==len(eligible)
assert sum(q[4] for q in spec)==state['matched']==2734080
for q,row in zip(spec,plan,strict=True):
    idx,low,high,size,work=q
    selection=eligible[low:high]
    assert size==len(selection)==high-low
    assert sha256(dumps(selection,protocol=5)).hexdigest()==row['selected_rows_sha256']
    assert sum(len(right[project(key,ap)]) for key,_ in selection)==work<=500000
_,low,high,_,work=spec[block]
out={}
seen=0
for row,(x,y) in eligible[low:high]:
    prefix=project(row,ax)
    for suffix,(u,v) in right[project(row,ap)]:
        seen+=1
        key=prefix+suffix
        r,t=out.get(key,(0,0))
        value=r+x*u-y*v,t+x*v+y*u
        if any(value):
            out[key]=value
        else:
            out.pop(key,None)
assert seen==work and len(out)<=work
axes=tuple(A[k] for k in ax)+tuple(B[k] for k in bx)
factors=[f for k,f in enumerate(orig) if k not in (i,j)]
factors.append((axes,out,d*e))
assert prod(f[2] for f in factors)==prod(f[2] for f in orig)
assert all(n==2 for n in Counter(w for a,_,_ in factors for w in a).values())
with Path('dense-saturated-frontier.pkl').open('xb') as stream:
    dump(dict(factors=factors,used_before=work,physical_cut=(state['physical_cut'],('left-row-interval',block,low,high))),stream,protocol=5)
print('block',block,'interval',low,high,'forced products',seen,'retained rows',len(out),'factors',len(factors),flush=True)
