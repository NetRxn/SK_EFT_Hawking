from collections import Counter
from hashlib import file_digest
from pathlib import Path
import pickle,time
source=Path('block5/join-cap-physical-slice-dense-branch.pkl')
with source.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='8753c2760395c3a783749271204daf3e7be33e7901b56b4497a608993647ba9b'
    stream.seek(0)
    state=pickle.load(stream)
functions=Path('contract-with-join-cap.py').read_text()
start=functions.index('def rotate(')
end=functions.index('def local_test()')
namespace={}
exec('from collections import defaultdict\nfrom math import gcd\n'+functions[start:end],namespace)
quotient=namespace['quotient']
f=state['factors']
degree=Counter(w for scope,_,_ in f for w in scope)
def match(a,b):
    A,X,_=a
    B,Y,_=b
    shared=tuple(x for x in A if x in B)
    pi=tuple(A.index(x) for x in shared)
    pj=tuple(B.index(x) for x in shared)
    h=Counter(tuple(row[j] for j in pj) for row in Y)
    return sum(h[tuple(row[i] for i in pi)] for row in X)
for i,j in ((4,8),(1,2),(0,10)):
    start=time.monotonic()
    a,b=f[i],f[j]
    first=match(a,b)
    A,B,x=quotient(a,b,degree)
    B,A,y=quotient(B,A,degree)
    after=match(A,B)
    assert after<=first and A[2]==a[2] and B[2]==b[2]
    print((i,j),'before',first,'after',after,'folds',x+y,
          'rows',len(A[1]),len(B[1]),'seconds',round(time.monotonic()-start,6),flush=True)
    if after <= 8_000_000 and after:
        out=list(f)
        out[i],out[j]=A,B
        with Path(f'resumable-fold-{i}-{j}.pkl').open('xb') as stream:
            pickle.dump(dict(state,factors=out),stream,protocol=5)
