from collections import Counter
from hashlib import file_digest
from itertools import combinations
from pathlib import Path
import json,pickle,sys

for src in map(Path,sys.argv[1:]):
    with src.open('rb') as stream:
        digest=file_digest(stream,'sha256').hexdigest()
        stream.seek(0)
        st=pickle.load(stream)
    f=st['factors']
    assert len(f)==14 and st['completed_this_run']==1950336
    assert all(n==2 for n in Counter(w for a,_,_ in f for w in a).values())
    scores=[]
    for i,j in combinations(range(len(f)),2):
        A,L,_=f[i]
        B,R,_=f[j]
        shared=tuple(w for w in A if w in B)
        if not shared:
            continue
        a=tuple(A.index(w) for w in shared)
        b=tuple(B.index(w) for w in shared)
        p=Counter(tuple(row[k] for k in a) for row in L)
        q=Counter(tuple(row[k] for k in b) for row in R)
        supported={key:p[key]*q[key] for key in p.keys()&q.keys()}
        work=sum(supported.values())
        scores.append((work,i,j,len(A)+len(B)-2*len(shared),shared,supported))
    scores.sort(key=lambda row:row[:4])
    print('residual',src.parent.name,digest,len(f),sum(len(r) for _,r,_ in f),'min pair',scores[0][:5],flush=True)
    for work,i,j,width,shared,t in scores[:4]:
        print('forecast',work,(i,j),'width',width,'shared',len(shared),'tuples',len(t),'largest',max(t.values()),flush=True)
        light=[(key,count) for key,count in t.items() if count<=500000]
        over=sorted((key,count) for key,count in t.items() if count>500000)
        batches=[]
        for key,count in sorted(light,key=lambda row:(-row[1],row[0])):
            slot=next((b for b in batches if b[0]+count<=500000),None)
            if slot is None:
                batches.append([count,[key]])
            else:
                slot[0]+=count
                slot[1].append(key)
        assert sum(x[0] for x in batches)+sum(n for _,n in over)==work
        print('complete kernel tuple partition',len(batches),'bounded blocks',len(over),'tuples need row shards',flush=True)
