# PR119 architecture companion

The documentation blob is identical to reviewed donor a74733105. Both author and independent controls reproduce red on the retired reference before transfer and green after it, with the physical pre-commit hook installed. Scope is limited to the documentation fix and named checks.
