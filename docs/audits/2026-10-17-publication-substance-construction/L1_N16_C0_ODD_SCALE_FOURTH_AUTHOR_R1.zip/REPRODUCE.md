# Fourth L1 odd-root scale-up author receipt

The original profile (155950080585,580896423965) at weight 96 has 62 assignments in 31 chirality pairs. The split-site contraction evaluated all representatives, with 6 positive, 2 negative and 23 zero values. The reported coefficient doubles the representative sum. Independently verify normalization, pair symmetry, and contractions before removing this profile from the accepted residual.

On this profile, the sum of the 31 observed case wall times was 109.05 s, and the maximum was 8.43 s. These exclude edge preparation and the separately timed 77.33 s split-site stage. The factor manifests identify the local raw tables and projected tables, which are stored outside this archive.
