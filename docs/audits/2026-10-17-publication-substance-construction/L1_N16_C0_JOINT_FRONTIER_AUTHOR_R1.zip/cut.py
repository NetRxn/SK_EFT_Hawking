from itertools import combinations
from functools import lru_cache
import json

V = range(16)
AXES = range(4)
PLANES = list(combinations(AXES, 2))
E = [(x, k) for x in V for k in AXES if not x & (1 << k)]
E_INDEX = {e: i for i, e in enumerate(E)}

def edge(x, k):
    return E_INDEX[x & ~(1 << k), k]

def bitmask(items):
    return sum(1 << i for i in set(items))

def rank(columns):
    basis = {}
    for x in columns:
        while x:
            k = x.bit_length()
            if k not in basis:
                basis[k] = x
                break
            x ^= basis[k]
    return len(basis)

site_stars = [bitmask([x, *(x ^ (1 << k) for k in AXES)]) for x in V]
edge_stars = [site_stars[x] | site_stars[x ^ (1 << k)] for x, k in E]
columns = []
for x in V:
    local = []
    for k, ell in PLANES:
        u, v = sorted(set(AXES) - {k, ell})
        curv = bitmask(edge(y, axis) for y, axis in (
            (x, k), (x ^ (1 << k), ell), (x ^ (1 << ell), k), (x, ell)))
        cof = bitmask((edge(x, u), edge(x, v)))
        degrees = bitmask((x ^ (1 << u), x ^ (1 << v)))
        local.append((curv ^ cof) | (degrees << 32))
    columns.append(local)

FULL = (1 << 16) - 1

@lru_cache(None)
def subrank(subset):
    return rank(c for x in V if subset & (1 << x) for c in columns[x])

def stats(s):
    t = s ^ FULL
    return (subrank(s) + subrank(t) - subrank(FULL),
            sum(bool(m & s and m & t) for m in site_stars),
            sum(bool(m & s and m & t) for m in edge_stars))

@lru_cache(None)
def optimize(s):
    if not s:
        return ((0, 0, 0), ())
    local = stats(s)
    return min((tuple(max(a, b) for a, b in zip(prior, local)), order + (v,))
               for v in V if s & (1 << v)
               for prior, order in (optimize(s ^ (1 << v)),))

def order_stats(order):
    s = 0
    out = []
    for v in order:
        s |= 1 << v
        out.append(stats(s))
    return out

orders = {
    'lex': tuple(V),
    'checker': tuple(sorted(V, key=lambda x: (x.bit_count() % 2, x))),
    'hamming': tuple(sorted(V, key=lambda x: (x.bit_count(), x))),
    'gray': tuple(v ^ (v >> 1) for v in V),
}
# Compare widths for explicit candidate schedules. The parity-optimal first
# component can be computed by a min-max DP over every labeled cut.
orders['parity_dp'] = optimize(FULL)[1]
print("rank of all 96 centered plane columns", subrank(FULL))
for name, order in orders.items():
    seq = order_stats(order)
    print(name, 'order', order, 'widths', seq, 'max', tuple(map(max, zip(*seq))))
print("orders", json.dumps(orders, sort_keys=True))
