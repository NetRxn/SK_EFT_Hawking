# Original N16 pure-EHC joint support preflight

The packet `publication-l1-n16-c0-joint-frontier-author-r1.json` checked
fresh at the primary checkout's `27012c18fa374e8341e124b510abbedeedb18d29`.
This scratch experiment retains the original 16-site periodic closed
action, original Berezin order and 64 independently anchored Spin(4)
variables. It extends the earlier provisional reduction in
`/private/tmp/l1-n16-c0-support.ob9Wnd6j/REPORT.md`. No shared source,
notebook, controller or Lean slot was modified.

## Forward occupation preflight and refusal

A local state has six nonnegative multiplicities of the rooted curvature
planes, of sum at most four. An occurrence consumes two generators at
its center and one at each of the complementary coframe neighbors.
The local roster has exactly 210 such multiplicity vectors. At a cut
after some centers, the dynamic program carries:

- Exact partial odd-generator degree at each unfinished site. A closed
  site must have degree eight and its degree can then be forgotten.
- The XOR of curvature counts on both actual anchors plus the count of
  coframes, separately for each of the 32 undirected edges.
- A record of whether any coframe has already occurred on each unfinished
  edge. While none has, also keep the curvature parity of its first
  directed anchor. The second is inferred from the total XOR. Once
  d>0, even total parity is sufficient for an allocation of its d
  coframes at the **unresolved-chirality** level. With d=0 both separate
  anchor parities must vanish. Check either anchor as soon as both
  endpoints and every future root capable of using that anchor are
  closed. Never identify the two anchors.

This state is sufficient for the listed coarse tests. Each merge counts
the multiplicities of identical keys. At a complete cut, full degree
saturation implies 32 factors automatically. At intermediate cuts,
future degree capacity is bounded by 8 for a still-open center and 4 for
each still-open neighbor. These bounds are necessary and can allow
mutually incompatible continuations.

The linear check uses the future span of the centered plane syndrome
columns. Their union has exact rank 31 over GF(2). Site parity is already
encoded in the syndrome's edge boundary: the plaquette boundary itself
has zero vertex boundary, and the coframe incidence boundary is site
degree modulo two. Bucket the current center's 210 choices by their
coset modulo the future span. A partial syndrome can only match its own
coset. This is an exact test of linear feasibility, with integer
occupation and higher-spin constraints outside its scope.

The cut script computes every labeled subset. The exact linear
intersection dimension at a cut S is

```
rank(columns rooted in S) + rank(columns rooted outside S) - 31.
```

The max width is 31 for lexicographic and Gray orders, 29 for Hamming
order and 24 for checkerboard. The minimum max width over all center
orders is **23**, proved by the subset minimax recurrence
`B(S)=max(w(S), min_(x in S) B(S minus {x}))`. The order shown in
`cut.out` attains it. These widths are exact dimensions of relaxed
linear syndrome spaces. They do not count degree-valid states or imply
the presence of all their vectors in the occupation frontier.

Before running the large cases, the program set hard per-run limits of
one million distinct keys in a destination table, 50 million attempted
transitions, and 20,000 cached bases. A 12-second elapsed check runs
every 65,536 attempts. The previous layer may coexist with the
destination table. All large forward runs refused on the state cap.

| Schedule and support level | Last completed stage | Exact keys at that stage | Represented prefixes | First refused stage |
| --- | ---: | ---: | ---: | ---: |
| Lex, joint | 3 | 647,597 | 657,840 | 4 |
| Hamming, joint | 3 | 647,597 | 657,840 | 4 |
| Checkerboard, joint | 2 | 42,780 | 44,100 | 3 |
| Parity-width optimum, joint | 2 | 42,780 | 44,100 | 3 |
| Lex, undirected only | 3 | 611,738 | 657,840 | 4 |
| Lex, load-quotient projection | 3 | 261,234 | 382,335 | 4 |
| Checkerboard, load-quotient projection | 2 | 21,109 | 24,025 | 3 |
| Lex, degree-only load projection | 3 | 177,629 | 382,335 | 4 |

A completed row counts exactly the keys and prefixes surviving that
schedule's stated tests. In the projected cases a prefix consists of
load vectors rather than six-plane occupations. These are upper
envelopes for prefixes admitting an actual saturated continuation. At
an aborted layer, a million is a lower bound on that *schedule's*
distinct destination keys and gives no lower bound on exact completable
prefixes or physical terms. There is no state extrapolation. Darwin
wall times and peak RSS are in the receipts. The joint runs were all
under one second, with the largest measured run below 145 MB.

A tighter version recomputes future local capacity using the actual
per-site residuals s. A future center of slack s_c can make at most

```
min(4, floor(s_c/2), floor(sum_j s_j / 2), sum_j s_j - max_j s_j)
```

coframe pairs, with s_j for its four neighbors. Each pair uses two
different directions, proving both neighbor-capacity bounds. For each
neighbor, its use is separately capped by its own slack and the sum of
the other neighbors' slacks. Summing these independent local maxima
over future centers gives necessary site bounds. It also builds the
future span after deleting elementary columns that consume a fully
saturated site or require two slots at a center with fewer. Once an
edge's endpoints have both closed and no coframes are present, the
basis includes the extra first-anchor parity coordinate for that edge.
These relaxations gave zero additional rejections at every completed
early stage of the measured full-lattice runs and did not move the
refusal later. Dropping the baseline future span in lex order also
left all completed counts unchanged. The parity-width optimum alone
therefore does not identify an economical forward occupation order.

## Factored degree loads and fixed-load exact support

Write h_x=(h0,h1,h2,h3) for the number of coframes in each direction
at x. This is the vertex-degree vector of the six coframe-pair
multiplicities on the local four-direction complete graph. The center
uses sum h_x generators, while neighbor x+e_j receives h_j from this
center. Thus full site-degree saturation depends only on the h's.

`fibers.py` exhausts the local 210 choices. They give 155 distinct h's.
There are 129 one-element occupation fibers, 25 three-element fibers,
and one six-element fiber. Their respective numbers of distinct local
multiplicity parity vectors are 1, 3, and 4. In coframe-pair order
01,02,03,12,13,23, two choices with the same h differ by

```
(a,b,-a-b,-a-b,b,a)
```

for integers a,b. Modulo two the possible differences are exactly
0,30,45,51 as binary masks. Their projected undirected Haar-syndrome
columns from all sixteen sites span an exact rank-13 space W. For a
given h, its syndrome coset modulo W is independent of the local
multiplicity choice. The projected C++ frontiers carry this quotient
and drop the directed information, which must be restored later.
Even this smaller explicit projection refuses at the fourth lex stage,
and so does the further degree-only projection.

For **fixed full h**, however, the undirected syndrome rescue can be
counted exactly in at most 8192 states. Each local fiber contributes
the distribution of its syndromes with integer multiplicity. The XOR
sum over centers lies in a translate of W. When d_e=0 for an edge,
add one syndrome bit for its first directed anchor, using the full
unprojected curvature count. The second is implied by the total XOR.
The rank in this augmented space is recomputed for each fixed h.
If two to the power of the rank exceeds the prospective bound of 100,000 syndrome states,
refuse the fixed-load schedule before evaluation. Allowed local
syndrome sets can be non-affine, so rank alone does not decide rescue.

The all-one load h=(1,1,1,1) at every site is a genuine full-N16
saturated load sector. There are three local matchings at each center
and no zero-coframe edges, hence exactly 43,046,721 candidate
occupations before parity. Exactly **5,937** pass the two-anchor
coarse parity tests. The XOR DP reached its 8192-state bound, and an
independent split into two eight-center explicit product enumerations
recovered the same zero-syndrome count. Both methods preserve
multiplicities. The paired controls with h=(2,2,0,0) everywhere and its
earlier staggered mutation reproduce one survivor and zero survivors.
The latter would falsely give one survivor under undirected parity
alone. These are counts of original geometric occupations, independent
of all coefficient signs. They do not count quaternion-coordinate
monomials, address separate chiral Haar constraints, or assert those
occupations contribute nonzero to c0.

This supports a specific next scheduling decomposition. Keep the
center-load constraints factored rather than expanding a forward table
of individual load signatures, and do exact parity rescue only on
small fixed-load or tightly conditioned load sectors. Such a load
enumerator has yet to be measured. The fixed-load calculation alone
already replaces the 43-million occupation product in a real sector
by an 8192-state parity contraction. Neither repeating the explicit
frontier with a more favorable rank cut nor removing directed
conditions stays within the measured cap.

## Original-source control

The joint implementation used a degree-eight restriction consisting of
all four bars at x, the two L psis at x+e0, and the two R psis at x+e1.
Starting from the full 210 local choices at every site, with only the
restricted site-degree target, it obtained one support occupation in
all three measured modes. The independent source check reran
`source_control.py` against the exact primary checkout. It verified
the unique source center and plane, agreement between the original
ordered factor roster and the reduced action on 16 nonzero quartic
masks, curvature Frobenius second moment 24, and exact restricted
Haar/Berezin coefficient 3/4 for `S2^2/2!`. All eight used anchors
remain separate. Unused independent normalized Haar variables
integrate to one. This is a source and sign control for the small
restriction, with no full-lattice coefficient inference.

The full periodic `c0=I_top E_Haar[S2^32/32!]` remains uncomputed.
The refusal is for explicit forward state expansion at the stated
caps. It is no impossibility result for other exact algorithms.
Independent review of this scratch result remains for the lead.

## Reproduction

Use `clang++ -std=c++17 -O3 -Wall -Wextra -Werror joint.cpp -o joint`.
The executable accepts a cut name and mode as in the receipt names.
Use `python3 measure.py ./joint lex joint`, and analogously for the
remaining `*.out` receipts. Run `python3 cut.py` for the all-subset
cut analysis and `python3 fibers.py` for the rank and fixed-load
controls. For `source_control.py`, use the exact primary checkout on
PYTHONPATH and its existing venv Python with PYTHONDONTWRITEBYTECODE=1.
