#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <numeric>
#include <string>
#include <unordered_map>
#include <vector>

using Word = uint32_t;
using Centers = uint16_t;
using Weight = __uint128_t;
using Syndrome = uint64_t;
constexpr size_t STATE_LIMIT = 1000000;
constexpr uint64_t WORK_LIMIT = 50000000;
constexpr double TIME_LIMIT = 12.0;
constexpr Centers ALL = 65535;

int topbit(Syndrome x) { return 63 - __builtin_clzll(x); }
struct Basis {
    std::array<Syndrome, 64> rows{};
    Syndrome reduce(Syndrome x) const {
        Syndrome out = 0;
        while (x) {
            int i = topbit(x);
            if (rows[i]) x ^= rows[i];
            else { out |= Syndrome(1) << i; x ^= Syndrome(1) << i; }
        }
        return out;
    }
    void add(Syndrome x) {
        while (x) {
            int i = topbit(x);
            if (rows[i]) x ^= rows[i];
            else { rows[i] = x; break; }
        }
    }
};
struct Local {
    std::array<uint8_t, 16> degree{};
    uint64_t packed = 0;
    Word total_parity = 0, anchor_a = 0, coframe = 0;
};
struct Geometry {
    std::array<std::array<int, 4>, 16> edge{};
    std::array<Centers, 32> ends{}, roots_a{}, roots_b{};
    std::array<std::array<Local, 6>, 16> elementary{};
    std::array<std::vector<Local>, 16> choices;
    Geometry() {
        int n = 0;
        for (int x = 0; x < 16; ++x)
            for (int axis = 0; axis < 4; ++axis) {
                if (x & (1 << axis)) continue;
                const int y = x ^ (1 << axis);
                edge[x][axis] = edge[y][axis] = n;
                ends[n++] = (1 << x) | (1 << y);
            }
        for (int x = 0; x < 16; ++x) {
            int plane = 0;
            for (int k = 0; k < 4; ++k)
                for (int l = k + 1; l < 4; ++l) {
                    Local& p = elementary[x][plane++];
                    for (auto [v, axis] : {std::pair{x, k}, {x ^ (1 << k), l},
                                           {x ^ (1 << l), k}, {x, l}}) {
                        int e = edge[v][axis];
                        p.total_parity ^= Word(1) << e;
                        if (v & (1 << axis)) roots_b[e] |= Centers(1 << x);
                        else {
                            roots_a[e] |= Centers(1 << x);
                            p.anchor_a ^= Word(1) << e;
                        }
                    }
                    p.degree[x] = 2;
                    for (int a = 0; a < 4; ++a) {
                        if (a == k || a == l) continue;
                        int y = x ^ (1 << a);
                        p.degree[y] = 1;
                        p.coframe |= Word(1) << edge[x][a];
                        p.total_parity ^= Word(1) << edge[x][a];
                    }
                    for (int y = 0; y < 16; ++y)
                        p.packed |= uint64_t(p.degree[y]) << (4 * y);
                }
            generate(x, 0, 4, {});
            if (choices[x].size() != 210) std::abort();
        }
    }
    void load_projection(bool keep_parity) {
        Basis variations;
        for (const auto& center : elementary)
            for (int mask : {30, 45, 51}) {
                Word syndrome = 0;
                for (int i = 0; i < 6; ++i)
                    if (mask & (1 << i)) syndrome ^= center[i].total_parity;
                variations.add(syndrome);
            }
        const auto project = [&](Local& p) {
            p.total_parity = keep_parity ? variations.reduce(p.total_parity) : 0;
        };
        for (int x = 0; x < 16; ++x) {
            for (auto& p : elementary[x]) project(p);
            std::map<uint64_t, Local> unique;
            for (auto p : choices[x]) {
                project(p);
                auto [it, inserted] = unique.emplace(p.packed, p);
                if (!inserted && it->second.total_parity != p.total_parity) std::abort();
            }
            if (unique.size() != 155) std::abort();
            choices[x].clear();
            for (auto [packed, p] : unique) choices[x].push_back(p);
        }
    }
    void generate(int x, int plane, int left, Local p) {
        if (plane == 6) { choices[x].push_back(p); return; }
        const Local& q = elementary[x][plane];
        for (int n = 0; n <= left; ++n) {
            generate(x, plane + 1, left - n, p);
            p.packed += q.packed;
            p.total_parity ^= q.total_parity;
            p.anchor_a ^= q.anchor_a;
            p.coframe |= q.coframe;
            for (int y = 0; y < 16; ++y) p.degree[y] += q.degree[y];
        }
    }
};
struct Key {
    uint64_t degree = 0;
    Word parity = 0, a = 0, seen = 0;
    bool operator==(const Key& rhs) const {
        return degree == rhs.degree && parity == rhs.parity && a == rhs.a && seen == rhs.seen;
    }
};
uint64_t hashword(uint64_t x) {
    x ^= x >> 30; x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27; x *= 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}
struct Hash {
    size_t operator()(const Key& k) const {
        return hashword(k.degree) ^ hashword((uint64_t(k.parity) << 32) | k.a) ^
            hashword(k.seen + (1ULL << 32));
    }
};
std::string decimal(Weight value) {
    std::string result;
    do {
        result += char('0' + value % 10);
        value /= 10;
    } while (value);
    std::reverse(result.begin(), result.end());
    return result;
}

struct Stage {
    Centers remaining;
    std::array<int, 16> need{};
    uint64_t clear_degree = 0, closed_value = 0;
    Word close_a = 0, close_b = 0, close_total = 0;
    Basis basis;
    Stage(const Geometry& g, Centers after, const std::array<int, 16>& top)
        : remaining(after) {
        for (int v = 0; v < 16; ++v) {
            int room = after & (1 << v) ? 8 : 0;
            for (int a = 0; a < 4; ++a)
                if (after & (1 << (v ^ (1 << a)))) room += 4;
            need[v] = std::max(0, top[v] - room);
            if (!room) {
                clear_degree |= uint64_t(15) << (4 * v);
                closed_value |= uint64_t(top[v]) << (4 * v);
            }
            if (after & (1 << v))
                for (const auto& p : g.elementary[v]) basis.add(p.total_parity);
        }
        for (int e = 0; e < 32; ++e) {
            if (after & g.ends[e]) continue;
            if (!(after & g.roots_a[e])) close_a |= Word(1) << e;
            if (!(after & g.roots_b[e])) close_b |= Word(1) << e;
        }
        close_total = close_a & close_b;
    }
};

void run(const Geometry& g, const std::string& label, std::array<int, 16> order,
         bool quotient, bool directed, bool tight, bool load, const std::array<int, 16>& top,
         int expected = -1) {
    const auto start = std::chrono::steady_clock::now();
    std::unordered_map<Key, Weight, Hash> states{{{}, 1}};
    Centers after = ALL;
    uint64_t tried = 0;
    uint64_t closed_previous = 0;
    std::cout << label << " quotient " << quotient << " directed " << directed << " tight " << tight << "\n";
    for (int i = 0; i < 16; ++i) {
        const int x = order[i];
        after ^= Centers(1 << x);
        const Stage next_stage(g, after, top);
        std::unordered_map<Key, Weight, Hash> next;
        std::unordered_map<Syndrome, std::vector<const Local*>> buckets;
        for (size_t j = 0; j < g.choices[x].size(); ++j) {
            const auto& p = g.choices[x][j];
            buckets[quotient ? next_stage.basis.reduce(p.total_parity) : 0].push_back(&p);
        }
        std::unordered_map<uint64_t, Basis> dynamic_bases;
        Word forced_closed_coframe = 0;
        for (int e = 0; e < 32; ++e)
            if (!(after & g.ends[e])) forced_closed_coframe |= Word(1) << e;
        uint64_t capacity_rejected = 0, constrained_parity_rejected = 0;
        uint64_t bucket_rejected = 0, degree_rejected = 0;
        uint64_t split_rejected = 0, parity_rejected = 0, accepted = 0;
        auto refuse = [&](const char* reason) {
            double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
            std::cout << "REFUSED " << reason << " stage " << i + 1
                      << " distinct lower bound " << next.size() << " tested " << tried
                      << " accepted " << accepted << " seconds " << seconds << "\n";
        };
        for (auto [key, ways] : states) {
            auto match = buckets.find(quotient ? next_stage.basis.reduce(key.parity) : 0);
            if (match == buckets.end()) { ++bucket_rejected; continue; }
            for (auto p : match->second) {
                if (++tried > WORK_LIMIT) { refuse("transition-limit"); return; }
                if ((tried & 65535) == 0 &&
                    std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count() > TIME_LIMIT) {
                    refuse("time-limit"); return;
                }
                bool valid = true;
                for (int v = 0; v < 16; ++v) {
                    if (closed_previous & (uint64_t(1) << (4 * v))) continue;
                    int d = ((key.degree >> (4 * v)) & 15) + p->degree[v];
                    if (d < next_stage.need[v] || d > top[v]) { valid = false; break; }
                }
                if (!valid) { ++degree_rejected; continue; }
                Key out;
                out.degree = (key.degree + p->packed) & ~next_stage.clear_degree;
                out.parity = key.parity ^ p->total_parity;
                if (!load && (out.parity & next_stage.close_total)) { ++parity_rejected; continue; }
                if (directed) {
                    out.seen = key.seen | p->coframe;
                    out.a = (key.a ^ p->anchor_a) & ~out.seen;
                    const Word b_when_zero = (out.parity ^ out.a) & ~out.seen;
                    if ((out.a & next_stage.close_a) || (b_when_zero & next_stage.close_b)) {
                        ++split_rejected; continue;
                    }
                    out.a &= ~next_stage.close_total;
                    out.seen &= ~next_stage.close_total;
                }
                if (tight) {
                    std::array<int, 16> slack{}, capacity{};
                    Centers no_neighbor = 0, no_center = 0;
                    for (int v = 0; v < 16; ++v) {
                        const uint64_t bit = uint64_t(1) << (4 * v);
                        slack[v] = next_stage.clear_degree & bit
                            ? 0 : top[v] - ((out.degree >> (4 * v)) & 15);
                        if (slack[v] == 0) no_neighbor |= Centers(1 << v);
                        if (slack[v] < 2) no_center |= Centers(1 << v);
                    }
                    for (int v = 0; v < 16; ++v) {
                        if (!(after & (1 << v)) || slack[v] < 2) continue;
                        int total = 0, largest = 0;
                        for (int a = 0; a < 4; ++a) {
                            int s = slack[v ^ (1 << a)];
                            total += s;
                            largest = std::max(largest, s);
                        }
                        int local_cap = std::min({4, slack[v] / 2, total / 2, total - largest});
                        capacity[v] += 2 * local_cap;
                        for (int a = 0; a < 4; ++a) {
                            int y = v ^ (1 << a);
                            capacity[y] += std::min({local_cap, slack[y], total - slack[y]});
                        }
                    }
                    for (int v = 0; v < 16; ++v)
                        if (capacity[v] < slack[v]) { valid = false; break; }
                    if (!valid) { ++capacity_rejected; continue; }

                    const Word zero_edges = forced_closed_coframe & ~out.seen & ~next_stage.close_total;
                    uint64_t cache_key = uint64_t(no_neighbor) | (uint64_t(no_center) << 16) |
                        (uint64_t(zero_edges) << 32);
                    auto basis_it = dynamic_bases.find(cache_key);
                    if (basis_it == dynamic_bases.end()) {
                        Basis basis;
                        for (int v = 0; v < 16; ++v) {
                            if (!(after & (1 << v)) || (no_center & (1 << v))) continue;
                            for (const auto& f : g.elementary[v]) {
                                bool fits = true;
                                for (int y = 0; y < 16; ++y)
                                    if (y != v && f.degree[y] && (no_neighbor & (1 << y))) {
                                        fits = false;
                                        break;
                                    }
                                if (fits) basis.add(f.total_parity |
                                    (Syndrome(f.anchor_a & zero_edges) << 32));
                            }
                        }
                        if (dynamic_bases.size() >= 20000) { refuse("basis-cache-limit"); return; }
                        basis_it = dynamic_bases.emplace(cache_key, basis).first;
                    }
                    if (basis_it->second.reduce(out.parity | (Syndrome(out.a & zero_edges) << 32))) {
                        ++constrained_parity_rejected;
                        continue;
                    }
                }
                ++accepted;
                next[out] += ways;
                if (next.size() >= STATE_LIMIT) { refuse("state-limit"); return; }
            }
        }
        Weight represented = 0;
        for (const auto& [key, ways] : next) represented += ways;
        std::cout << "stage " << i + 1 << " vertex " << x << " states " << next.size()
                  << " represented " << decimal(represented) << " accepted " << accepted
                  << " tried_total " << tried << " bucket_rejected " << bucket_rejected
                  << " degree_rejected " << degree_rejected
                  << " split_rejected " << split_rejected << " parity_rejected " << parity_rejected
                  << " capacity_rejected " << capacity_rejected << " constrained_parity_rejected "
                  << constrained_parity_rejected << " cached_bases " << dynamic_bases.size() << "\n";
        closed_previous = next_stage.clear_degree;
        states.swap(next);
    }
    if (expected >= 0 && (states.size() != size_t(expected) ||
        (expected == 1 && states.begin()->second != 1))) std::abort();
    std::cout << "COMPLETE support-only " << states.size() << "\n";
}

int main(int argc, char** argv) {
    Geometry g;
    const std::string name = argc > 1 ? argv[1] : "lex";
    const std::string mode = argc > 2 ? argv[2] : "joint";
    const bool quotient = mode != "local";
    const bool load = mode == "load" || mode == "degree";
    const bool directed = mode != "undirected" && !load;
    if (load) g.load_projection(mode == "load");
    const bool control = name == "control";
    const bool tight = mode == "tight";
    std::array<int, 16> order, top;
    std::iota(order.begin(), order.end(), 0);
    top.fill(8);
    if (name == "checker") order = {0,3,5,6,9,10,12,15,1,2,4,7,8,11,13,14};
    if (name == "hamming") order = {0,1,2,4,8,3,5,6,9,10,12,7,11,13,14,15};
    if (name == "parity_dp") order = {0,3,5,9,6,10,12,1,15,2,4,8,7,11,13,14};
    if (control) { top.fill(0); top[0] = 4; top[1] = top[2] = 2; }
    run(g, name, order, quotient, directed, tight, load, top, control ? 1 : -1);
}
