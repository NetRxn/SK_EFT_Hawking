# Original L1 group 672, first G block

The portably reviewed scope is original joint-L assignment 7, J=(1,),
and G(0,6,0) in {81,88,193,200}. Each original row and signed weight
is included once. The earlier interval-5 result is a subset and is
not added to this result. The other two G blocks are outside this scope.

Verify SHA256SUMS on extraction. The independent archive contains the
original-source replay, signed transformation replay and terminal
calculation with their own manifests. The author scripts and receipts
report the fourth continuation starting from the independently reviewed
seven-factor cap. Large numerical operands are pinned by hashes rather
than embedded. Build their predecessors using the existing Group 672
G-block evidence and the independent replay.

The final three tables have pairwise shared axes and no free axes. Each
combination of three matching rows is counted once by anchoring at one
factor and intersecting the other two supports. Disjoint contiguous
anchor-loop chunks account for the complete support without constructing
any pair-product table. Two anchor choices agree on the raw signed value
at the inherited factor denominator. No external normalization is
applied here.
