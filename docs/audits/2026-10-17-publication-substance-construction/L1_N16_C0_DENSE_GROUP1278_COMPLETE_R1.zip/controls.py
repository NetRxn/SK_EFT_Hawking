from stages import fold, forecast, inverse, projections, replay

F=(('u','v'),{(1,0):(2,3),(2,0):(-3,2),(3,0):(0,9),(4,0):(1,2)},5)
G=(('u','w'),{(1,0):(1,0),(2,0):(0,1),(3,1):(2,1)},7)
def join(a,b):return replay(a,b,[],forecast(a,b)[0],0)[0]
f,g,n=fold(F,G,('u',))
assert n==1 and join(F,G)==join(f,g)==(('v','w'),{(0,1):(-9,18)},35)
G_bad=(G[0],G[1]|{(2,0):(0,-1)},G[2])
assert join(F,G_bad)!=join(F,G)
marginal=(('v','s'),{(0,0):(1,0),(1,1):(1,0)},1)
peer=(('w','s'),{(0,0):(1,0),(1,1):(1,0)},1)
checks=projections((marginal,peer),('v','w'),2)
assert len(checks)==3
assert all(p((0,0)) in allowed for p,allowed in checks)
assert not all(p((0,1)) in allowed for p,allowed in checks)
source=(('l','r'),{(0,0):(4,5),(1,0):(-5,4)},7)
s=('exact-fiber-split',0)
a=(('l',s),{(0,0):(1,0),(1,0):(0,1)},7)
b=((s,'r'),{(0,0):(4,5)},1)
assert inverse(source,a,b)==2
try:
    inverse(source,a,(b[0],b[1],2))
except AssertionError:
    pass
else:
    raise AssertionError('incorrect inverse denominator admitted')
print('Exact controls pass: signed phase/cancellation and wrong-phase rejection, nonmatching support, correlated peer projection exclusion, and inverse denominator rejection.')
