#!/bin/bash
set -eu -o pipefail
base=/private/tmp/l1-geometry-component98-preparation.iOKjDp/1278/cached-original-roster/L6/budget-rescue
f=author/L6/budget-rescue
test -s L6-independent-native-refusal.pkl
mkdir -p "$f"
(cd "$base" && shasum -a 256 ./*.py ./*.pkl ./*.out ./*.receipt ./*.err | sed 's%  \./%  %') > "$f/frozen-inputs.sha256"
cp "$base"/*.py "$base"/*.out "$base"/*.receipt "$base"/*.err "$f"
for x in "$base"/*.time; do if [ -f "$x" ]; then cp "$x" "$f"; fi; done
code=0
python3 -B budget_continue.py > L6-replay.out 2> L6-replay.err || code=$?
printf '%s\n' "$code" > L6-status.out
test "$code" = 0
