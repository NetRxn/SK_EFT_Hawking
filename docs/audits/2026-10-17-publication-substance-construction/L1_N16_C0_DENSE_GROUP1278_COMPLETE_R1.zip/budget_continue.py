from pathlib import Path
from ast import literal_eval
from time import monotonic
from gc import collect
from prefix import BASE,N,CAP,SEED,sha,read
import stages

start=monotonic()
index=6
original=BASE/f'L{index}'
rescue=original/'budget-rescue'
local=Path(f'author/L{index}')
capture=local/'budget-rescue'
assert (local/'contraction.receipt').read_text().startswith('child status 1\n')
assert (capture/'contraction.receipt').read_text().startswith('child status 2\n')
assert (capture/'contraction.out').read_text().splitlines()==(
        (local/'contraction.out').read_text().splitlines()+['open product cap 11 7825348 frontier saved'])
assert not (capture/'contraction.err').read_bytes()
assert sha(rescue/SEED)==sha(original/SEED)
before=(local/'contract-slice.py').read_text()
after=(capture/'contract-slice.py').read_text()
lo=after.index('    if not costs:')
hi=after.index('    _,matched,i,j,shared=min(costs)',lo)
assert before==after[:lo]+"    assert costs,('no admitted join',len(factors),work)\n"+after[hi:]
pins={}
for line in (capture/'frozen-inputs.sha256').read_text().splitlines():
    h,name=line.split(maxsplit=1)
    assert sha(rescue/name)==h
    if not name.endswith('.pkl'):assert sha(capture/name)==h
    pins[name]=h
cap=rescue/CAP
own=Path('L6-independent-native-refusal.pkl')
r=read(cap); independent=read(own)
assert r['terminal_reason']=='no eligible native join within unchanged product limits'
assert r['rejected_pair'] is None and r['matched'] is None
assert all(r[k]==v for k,v in independent.items())
assert r['used_before']==7825348 and len(r['factors'])==11
line=next(s for s in Path('L6-native-budget.out').read_text().splitlines() if
          s.startswith('independent exact no-admitted-product guard'))
assert f'independent native state sha {sha(own)} ' in line
stages.original=sha(cap); stages.region=r['physical_cut']
print('all independent guarded tables equal unchanged-budget author capture',stages.original,stages.region,flush=True)
del r,independent
collect()
logs=sorted(capture.glob('pass[1-9].out'))
assert logs and [x.name for x in logs]==[f'pass{i}.out' for i in range(1,len(logs)+1)]
paths=[cap]
splits=[]
for n,log in enumerate(logs,1):
    s,p=('split-frontier.pkl','unsharded-result.pkl') if n==1 else (f'pass{n}-split.pkl',f'pass{n}-result.pkl')
    for name in (s,p):assert f'preserved checkpoint {name} {pins[name]} ' in log.read_text()
    splits.append(rescue/s); paths.append(rescue/p)
for i in range(1,len(paths)):
    t=monotonic()
    live=stages.check_stage(i,paths[i-1],splits[i-1],paths[i],min(i,2))
    print('independent stage wall seconds',index,i,round(monotonic()-t,6),flush=True)
    if i<len(paths)-1:del live;collect()
terminal=sha(paths[-1])
if len(live)==1:
    [(axes,rows,den)]=live.values()
    expected=next(x.removeprefix('exact raw scalar ') for x in logs[-1].read_text().splitlines()
                  if x.startswith('exact raw scalar '))
    assert axes==() and den==N and set(rows)=={()} and literal_eval(expected)==rows[()] and rows[()][1]==0
    value=rows[()]
elif len(live)==3 and (capture/'terminal.out').exists():
    from triangle_review import complete
    canonical=read(paths[-1])['factors']
    assert list(live.values())==canonical
    t=monotonic()
    value=complete(list(live.values()),(capture/'terminal.out').read_text(),canonical)
    print('independent triangle wall seconds',index,round(monotonic()-t,6),flush=True)
    assert value[1]==0
else:
    print('independent verified continuation frontier',index,len(live),terminal,flush=True)
    exit()
print('exact whole original L scalar',index,value,N,'terminal',terminal,
      'elapsed',round(monotonic()-start,6),flush=True)
