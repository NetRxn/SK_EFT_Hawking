from pathlib import Path
from sys import argv
from time import monotonic
from stages import read,sha,N
from triangle_review import complete
from prefix import BASE
import re
n=int(argv[1])
path=BASE/f'L{n}'
local=Path(f'author/L{n}')
log=Path(f'L{n}-replay.out').read_text()
m=re.search(rf'^independent verified continuation frontier {n} 3 ([0-9a-f]+)$',log,re.M)
assert m
ns=[p for p in path.glob('pass*-result.pkl') if sha(p)==m[1]]
assert len(ns)==1
terminal=ns[0]
for name in ('terminal.out','terminal.time','triangle.py'):
    src=path/name
    (local/name).write_bytes(src.read_bytes())
assert (local/'terminal.time').read_text().startswith('real ')
a=read(terminal)
f=a['factors']
print('ready exact hash-bound triangle',sha(terminal),a['physical_cut'],flush=True)
t=monotonic()
v=complete(f,(local/'terminal.out').read_text(),f)
assert v[1]==0
elapsed=monotonic()-t
print('independent triangle wall seconds',n,round(elapsed,6),flush=True)
print('exact whole original L scalar',n,v,N,'terminal',sha(terminal),'elapsed',round(elapsed,6),flush=True)
