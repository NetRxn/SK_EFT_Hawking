from ast import literal_eval
from collections import Counter
from hashlib import file_digest
from itertools import product
from pathlib import Path
import pickle
import sys

source=Path(sys.argv[1])
expected=sys.argv[2]
with source.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()==expected
    stream.seek(0)
    origin=pickle.load(stream)
factors=origin['factors']
assert origin['branch']==1278 and origin['support']==8 and len(factors)==88
degree=Counter(axis for scope,_,_ in factors for axis in scope)
names=tuple(sorted(axis for axis in degree if axis[0]=='L'))
assert len(names)==12 and all(n==2 for axis,n in degree.items() if axis[0]!='L')
positions=[tuple((column,names.index(axis)) for column,axis in enumerate(scope) if axis[0]=='L')
           for scope,_,_ in factors]
local=[Counter(tuple(row[column] for column,_ in assignment) for row in table)
       for assignment,(_,table,_) in zip(positions,factors,strict=True)]
states=tuple(sorted({value for h in local for row in h for value in row}))
assert states==((0,1),(1,0))
choices=[]
for values in product(states,repeat=len(names)):
    sizes=[h[tuple(values[pos] for _,pos in assignment)] for assignment,h in zip(positions,local,strict=True)]
    if all(sizes):
        choices.append((values,sum(sizes),max(sizes)))
original_roster=Path(__file__).resolve().parents[2]/'original-label-roster.tsv'
records=[row.split('\t') for row in original_roster.read_text().splitlines()]
assert records[0][0]=='axes' and literal_eval(records[0][1])==names
original=tuple(literal_eval(row[1]) for row in records[1:])
assert len(original)==len(set(original))==8
survivors={entry[0]:entry for entry in choices}
assert set(survivors) == {original[i] for i in (0,1,2,3,4,6)}
with Path('joint-label-roster.tsv').open('x') as out:
    print('axes',repr(names),sep='\t',file=out)
    for index,values in enumerate(original):
        row=survivors.get(values,(values,0,0))
        print(index,*row,sep='\t',file=out)
selector=4
values,expected_rows,_=survivors[original[selector]]
out=[]
for (scope,table,den),locked in zip(factors,positions,strict=True):
    cols={column for column,_ in locked}
    remaining=tuple(column for column in range(len(scope)) if column not in cols)
    selected={}
    for row,amp in table.items():
        if all(row[column]==values[pos] for column,pos in locked):
            key=tuple(row[column] for column in remaining)
            assert key not in selected
            selected[key]=amp
    assert selected
    out.append((tuple(scope[i] for i in remaining),selected,den))
assert all(n==2 and axis[0]!='L' for axis,n in Counter(axis for a,_,_ in out for axis in a).items())
assert sum(len(rows) for _,rows,_ in out)==expected_rows
with Path('dense-saturated-frontier.pkl').open('xb') as stream:
    pickle.dump(dict(factors=out,used_before=0,physical_cut=(names,values),group=1278,
                     complete_label_roster=original,
                     joint_label_index=selector),stream,protocol=5)
print('group1278 label selector',selector,'rows',expected_rows,'census',len(choices),flush=True)
