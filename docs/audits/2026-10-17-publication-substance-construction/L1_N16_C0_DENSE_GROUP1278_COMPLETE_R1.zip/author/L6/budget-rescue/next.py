from pathlib import Path
from sys import argv
import hashlib

def digest(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()

stage = int(argv[1])
assert 2 <= stage <= 6
pred = Path('unsharded-result.pkl' if stage == 2 else f'pass{stage-1}-result.pkl')
code = Path('round3.py').read_text()
code = code.replace('follow-result.pkl', pred.name)
code = code.replace('e092611b8576e1117da1b563cfdbeb6d77e936b5ef12275f1b6fc0220084b1ac', digest(pred))
code = code.replace("    assert original['attempted_products']==5645306 and len(fs)==11", "    assert len(fs) > 3")
code = code.replace('300+i', f'{1000*stage}+i').replace('400+step', f'{1000*stage+100}+step')
code = code.replace("original['round3_", f"original['pass{stage}_").replace("checkpoint('round3-", f"checkpoint('pass{stage}-")
Path(f'pass{stage}.py').write_text(code)
