"""Reconstruct original Group 1278 original surviving ordinals selections and guarded prejoin caps."""
from ast import literal_eval
from collections import Counter, defaultdict
from itertools import combinations, product
from pathlib import Path
from time import monotonic
import stages
from stages import N, fold, forecast, mul, positions, read, sha, validate
from hashlib import sha256
from io import BytesIO
from subprocess import check_output
from zipfile import ZipFile
from gc import collect
from csv import DictReader
from collections import defaultdict
import re, json

PARENT=Path('/private/tmp/l1-geometry-component98-preparation.iOKjDp/1278/cached-original-roster/dense-saturated-frontier.pkl')
PARENT_SHA='31144d3b9b58967a81fa0fef3b61559155d8e931d127d2a7d3abc02ce74b7a2c'
SEED='dense-saturated-frontier.pkl'
CAP='row-cap-physical-slice-dense-branch.pkl'
ROW_LIMIT=500_000
BASE=Path('/private/tmp/l1-geometry-component98-preparation.iOKjDp/1278/cached-original-roster')
PUBLISHED=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
COMMIT='ab745fbb6ca4fd94d6b5ceebc89ce1c243deeaaf'
ARCHIVE='docs/audits/2026-10-17-publication-substance-construction/L1_N16_C0_DENSE_GROUP786_COMPLETE_R1.zip'
ARCHIVE_SHA='1a0882b350b20b64d76e22f423a6a794bc1f0b49329d5af117baaca77ec41ee2'
SURVIVORS=(0,1,2,3,4,6)
ZERO=(5,7)

def pinned_source():
    assert sha(PARENT)==sha(BASE.parent/PARENT.name)==PARENT_SHA
    src=read(PARENT)
    assert src['branch']==1278 and src['support']==8
    original=src['factors']
    assert len(original)==88
    L=tuple(sorted({w for axes,_,_ in original for w in axes if w[0]=='L'}))
    assert len(L)==12
    hist=[]
    for axes,rows,_ in original:
        edge=tuple(w for w in axes if w in L)
        hist.append((positions(L,edge),Counter(map(positions(axes,edge),rows))))
    domains=[{key[i] for a,rows,_ in original if w in a for i in [a.index(w)] for key in rows} for w in L]
    binary=((0,1),(1,0))
    assert all(d and d <= set(binary) for d in domains)
    found=[]
    for key in product(binary,repeat=len(L)):
        counts=[counts[project(key)] for project,counts in hist]
        if all(counts):
            found.append((key,sum(counts),max(counts)))
    labels=[(int(i),literal_eval(k),literal_eval(z)) for i,k,z in
            (s.split('\t') for s in Path('source/original-labels.tsv').read_text().splitlines())]
    assert [i for i,_,_ in labels]==list(range(8))
    upstream_axes,upstream_roster=literal_eval(Path('source/original-roster.txt').read_text())
    assert L==upstream_axes and [k for _,k,_ in labels]==list(upstream_roster)
    assert [i for i,k,z in labels if z]==list(ZERO)
    assert [k for k,_,_ in found]==[upstream_roster[i] for i in SURVIVORS]
    original_ordinals=[]
    for i,key,zero in labels:
        counts=[sizes[project(key)] for project,sizes in hist]
        empty=sum(n==0 for n in counts)
        assert bool(empty)==zero
        if zero:assert empty==13
        original_ordinals.append((key,sum(counts) if not empty else 0,max(counts) if not empty else 0))
    print('verified exact original ordinals and sparse prepared census',list(enumerate(original_ordinals)),flush=True)
    return original,L,original_ordinals

def condition(original,L,found,index,author):
    local=Path('author')/f'L{index}'
    assert (local/'joint-label-roster.tsv').read_bytes()==(author/'joint-label-roster.tsv').read_bytes()
    selected=read(author/SEED)
    assignment,count,peak=found[index]
    assert selected['physical_cut']==(L,assignment) and selected['group']==1278
    assert selected['joint_label_index']==index and selected['used_before']==0
    assert selected['complete_label_roster']==tuple(k for k,_,_ in found)
    fixed=dict(zip(L,assignment,strict=True))
    for (axes,rows,den),(sub,coeffs,rden) in zip(original,selected['factors'],strict=True):
        assert sub==tuple(w for w in axes if w not in fixed) and den==rden
        lifted={tuple((dict(zip(sub,k,strict=True))|fixed)[w] for w in axes):v for k,v in coeffs.items()}
        limits=tuple((i,fixed[w]) for i,w in enumerate(axes) if w in fixed)
        assert lifted=={k:v for k,v in rows.items() if all(k[i]==v for i,v in limits)}
    assert count==sum(len(r) for _,r,_ in selected['factors'])
    assert peak==max(len(r) for _,r,_ in selected['factors'])
    validate(selected['factors'])
    print('complete signed selector inverse lift',index,assignment,count,peak,sha(author/SEED),flush=True)
    return selected

def trim(factors, focus=None):
    for i,j in combinations(range(len(factors)),2):
        if focus is not None and focus not in (i,j):
            continue
        a,A,d=factors[i]; b,B,e=factors[j]
        shared=tuple(w for w in a if w in b)
        if not shared: continue
        P,Q=positions(a,shared),positions(b,shared)
        U,V=set(map(P,A)),set(map(Q,B))
        if U!=V:
            common=U&V
            if common!=U: factors[i]=(a,{k:v for k,v in A.items() if P(k) in common},d)
            if common!=V: factors[j]=(b,{k:v for k,v in B.items() if Q(k) in common},e)

def choose(factors, work):
    ladder=[]
    for i,j in combinations(range(len(factors)),2):
        a,A,_=factors[i]; b,B,_=factors[j]
        width=len(set(a)^set(b))
        if set(a)&set(b):
            ladder.append((len(A)*len(B)*(1+width),i,j))
    options=[]
    for _,i,j in sorted(ladder):
        n,w,_=forecast(factors[i],factors[j])
        if n<=8_000_000 and work+n<=40_000_000:
            options.append((n*(w+1)**2,n,i,j))
            if len(options)==12: break
    return min(options)[1:] if options else None

def native_fold(f,g):
    edge=tuple(w for w in f[0] if w in g[0])
    a,b,removed=fold(f,g,edge)
    if removed==0:
        U=set(map(positions(f[0],edge),f[1]))
        V=set(map(positions(g[0],edge),g[1]))
        if V<=U: return f,g,0
    return a,b,removed

def join(f,g,peers,expected, stop_at_cap=False):
    a,A,d=f; b,B,e=g
    edge=tuple(w for w in a if w in b)
    x=tuple(w for w in a if w not in edge); y=tuple(w for w in b if w not in edge)
    scope=x+y
    p,q,rx,ry=positions(a,edge),positions(b,edge),positions(a,x),positions(b,y)
    gates=[]
    if expected>250_000:
        for axes,rows,_ in peers:
            common=tuple(w for w in axes if w in scope)
            if common: gates.append((positions(scope,common),set(map(positions(axes,common),rows))))
        gates.sort(key=lambda pair:len(pair[1]))
    X,Y=defaultdict(list),defaultdict(list)
    for k,v in A.items():X[p(k)].append((rx(k),v))
    for k,v in B.items():Y[q(k)].append((ry(k),v))
    out={}
    visits=0
    for k in sorted(X.keys()&Y.keys(), reverse=True):
        for r,w in reversed(Y[k]):
            for l,v in reversed(X[k]):
                visits+=1
                key=l+r
                if any(P(key) not in support for P,support in gates): continue
                m,n=mul(v,w)
                u,z=out.get(key,(0,0))
                coeff=u+m,z+n
                if any(coeff):
                    out[key]=coeff
                    if stop_at_cap and len(out)>ROW_LIMIT:
                        return visits,len(out)
                else:out.pop(key,None)
    assert visits==expected
    return scope,out,d*e

def check_cap(seed,index,author):
    origin=author/CAP
    cap=read(origin)
    assert cap['physical_cut']==seed['physical_cut']
    cap_count=len(cap['factors'])
    assert cap_count>1
    factors=seed['factors']
    validate(factors)
    trim(factors)
    trim(factors)
    work=0
    logs=(author/'contraction.out').read_text().splitlines()
    joins=[line for line in logs if line.startswith('join ')]
    quotients=[line for line in logs if line.startswith('quotient ')]
    steps=len(factors)-cap_count
    for step in range(steps+1):
        opt=choose(factors,work)
        assert opt is not None
        prior,i,j=opt
        f,g=factors[i],factors[j]
        matched=prior
        if prior>50_000:
            f,g,n=native_fold(f,g)
            g,f,m=native_fold(g,f)
            factors[i],factors[j]=f,g
            matched=forecast(f,g)[0]
            assert quotients.pop(0)==f'quotient before join {len(factors)} {prior} {matched} slices {m+n}'
        peers=[F for k,F in enumerate(factors) if k not in (i,j)]
        if step==steps:
            assert not quotients and len(joins)==steps
            assert factors==cap['factors'] and cap['rejected_pair']==(i,j)
            assert cap['used_before']==work and cap['matched']==matched
            assert logs[-1]==f'open row cap {len(factors)} {matched} frontier saved'
            cap_visits,cap_rows=join(f,g,peers,matched,True)
            assert cap_rows==ROW_LIMIT+1
            validate(factors)
            assert (author/'contraction.err').stat().st_size==0
            assert (author/'contraction.receipt').read_text().splitlines()[0]=='child status 2'
            nrows=sum(len(r) for _,r,_ in factors)
            nwire=len({w for a,_,_ in factors for w in a})
            print('independent exact native cap tables',index,sha(origin), len(factors), nrows,nwire, work,(i,j),matched,cap_visits,cap_rows,flush=True)
            return
        table=join(f,g,peers,matched)
        assert len(table[1])<=ROW_LIMIT
        factors=peers+[table]
        trim(factors,len(factors)-1)
        if len(factors)%8==0: trim(factors)
        table=factors[-1]
        found=f'join {len(factors)} {matched} {len(table[1])} axes {len(table[0])}'
        assert joins[step]==found,(step,joins[step],found)
        work+=matched
        print('native accepted',step,len(factors),matched,len(table[1]),work,flush=True)


def main(index):
    start=monotonic()
    author=BASE/f'L{index}'
    local=Path('author')/f'L{index}'
    pins={}
    for line in (local/'frozen-inputs.sha256').read_text().splitlines():
        h,n=line.split(maxsplit=1)
        assert sha(author/n)==h
        if not n.endswith('.pkl'):
            assert sha(local/n)==h
        pins[n]=h
        print('checked frozen L input',index,h,n,flush=True)
    assert index in SURVIVORS
    cap=author/CAP
    paths=[cap]
    splits=[]
    logs=sorted(local.glob('pass[1-9].out'))
    assert logs and [x.name for x in logs]==[f'pass{i}.out' for i in range(1,len(logs)+1)]
    for n,log in enumerate(logs,1):
        s,p=('split-frontier.pkl','unsharded-result.pkl') if n==1 else (f'pass{n}-split.pkl',f'pass{n}-result.pkl')
        for name in (s,p):
            assert f'preserved checkpoint {name} {pins[name]} ' in log.read_text()
        splits.append(author/s)
        paths.append(author/p)
    depth=len(logs)
    terminal=sha(paths[-1])
    original,L,found=pinned_source()
    declared=(local/'joint-label-roster.tsv').read_text().splitlines()
    assert declared[0]==f'axes\t{L!r}'
    assert [(int(i),literal_eval(k),int(n),int(m)) for i,k,n,m in (s.split('\t') for s in declared[1:])]==[
        (i,*row) for i,row in enumerate(found)]
    with Path('source/ordinal-roster.tsv').open() as f:
        archived=list(DictReader(f,delimiter='\t'))
    assert found[index][1:]==tuple(int(archived[index][key]) for key in ('prepared_selected_rows','largest_prepared_factor'))
    selected=condition(original,L,found,index,author)
    del original
    collect()
    check_cap(selected,index,author)
    del selected
    collect()
    print('independent native source and cap seconds',index,round(monotonic()-start,6),flush=True)
    stages.original=sha(cap)
    stages.region=(L,found[index][0])
    for n in range(1,depth+1):
        timer=monotonic()
        live=stages.check_stage(n,paths[n-1],splits[n-1],paths[n],min(n,2))
        print('independent stage wall seconds',index,n,round(monotonic()-timer,6),flush=True)
        if n<depth:del live;collect()
    if len(live)==1:
        [(axes,rows,den)]=live.values()
        expected=next(s.removeprefix('exact raw scalar ') for s in logs[-1].read_text().splitlines() if s.startswith('exact raw scalar '))
        assert axes==() and den==N and set(rows)=={()} and literal_eval(expected)==rows[()] and rows[()][1]==0
        value=rows[()]
    elif len(live)==3 and (local/'terminal.out').exists():
        from triangle_review import complete
        canonical=read(paths[-1])['factors']
        assert list(live.values())==canonical
        time=monotonic()
        value=complete(list(live.values()),(local/'terminal.out').read_text(),canonical)
        print('independent triangle wall seconds',index,round(monotonic()-time,6),flush=True)
        assert value[1]==0
    else:
        print('independent verified continuation frontier',index,len(live),terminal,flush=True)
        return
    print('exact whole original L scalar',index,value,N,'terminal',terminal,
          'elapsed',round(monotonic()-start,6),flush=True)

if __name__=='__main__':
    from sys import argv
    main(int(argv[1]))
