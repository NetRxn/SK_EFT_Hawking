from ast import literal_eval
from collections import defaultdict,Counter
from math import prod
from stages import positions,mul,validate,N

def graph(factors,i):
    j,k=[j for j in range(3) if j!=i]
    a,x,_=factors[i]; b,y,_=factors[j]; c,z,_=factors[k]
    ab=tuple(w for w in a if w in b)
    ac=tuple(w for w in a if w in c)
    bc=tuple(w for w in b if w in c)
    assert ab and ac and bc
    assert len(set(ab+ac+bc))==len(ab+ac+bc)
    assert set(a)==set(ab+ac) and set(b)==set(ab+bc) and set(c)==set(ac+bc)
    pp,qq=positions(a,ab),positions(a,ac)
    def groups(axes,rows,p):
        op,ip=positions(axes,p),positions(axes,bc)
        groups=defaultdict(dict)
        for key,v in rows.items():
            t,s=op(key),ip(key)
            assert s not in groups[t]
            groups[t][s]=v
        return groups
    return x,pp,qq,groups(b,y,ab),groups(c,z,ac)

def complete(factors,receipt,author_order):
    assert len(factors)==3 and factors==author_order
    validate(factors)
    assert prod(d for _,_,d in factors)==N
    assert all(v==2 for v in Counter(w for a,_,_ in factors for w in a).values())
    total=0
    for line in receipt.splitlines():
        if not line.startswith('triangle forecast '):continue
        i,j,k,count=map(int,line.split()[2:6])
        assert i in (0,1) and {i,j,k}=={0,1,2}
        chunks=literal_eval(line.split(' chunks ',1)[1].split(' seconds ',1)[0])
        x,p,q,y,z=graph(author_order,i)
        assert chunks[0][0]==0 and chunks[-1][1]==len(x)
        assert all(a<b and 0<c<=8_000_000 for a,b,c in chunks)
        assert all(u[1]==v[0] for u,v in zip(chunks,chunks[1:]))
        degrees=[len(y.get(p(r),{}).keys()&z.get(q(r),{}).keys()) for r in x]
        assert sum(degrees)==count
        assert [(a,b,sum(degrees[a:b])) for a,b,_ in chunks]==chunks
        total=total or count
        assert total==count
        print('verified author matched support partitions',i,len(x),chunks,'exact products',count,flush=True)
    assert total>0
    # Third pivot. Sparse natural-key intersections; no shared bitset or author reduction ordering.
    x,p,q,y,z=graph(factors,2)
    batches=[]
    work=real=imag=seen=0
    start=0
    for i,(r,weight) in enumerate(reversed(x.items())):
        left=y.get(p(r),{})
        right=z.get(q(r),{})
        common=left.keys()&right.keys()
        if work+len(common)>8_000_000:
            assert work
            batches.append((start,i,work))
            start,work=i,0
        work+=len(common)
        for s in common:
            a,b=mul(mul(weight,left[s]),right[s])
            real+=a
            imag+=b
            seen+=1
    batches.append((start,len(x),work))
    assert all(a<b and 0<n<=8_000_000 for a,b,n in batches)
    assert seen==sum(n for _,_,n in batches)==total
    expected=[]
    for line in receipt.splitlines():
        if line.startswith('triangle signed numerator '):
            s=line.split()
            expected.append((int(s[6]),int(s[7]),int(s[9])))
    assert expected==[(real,imag,N)]*2
    print('independent third pivot',2,len(x),batches,'raw',real,imag,'denominator',N,flush=True)
    return real,imag
