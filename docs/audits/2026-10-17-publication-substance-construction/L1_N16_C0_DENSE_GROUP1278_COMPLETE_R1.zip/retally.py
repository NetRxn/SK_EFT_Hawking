from pathlib import Path
from ast import literal_eval
from fractions import Fraction
from decimal import Decimal
from csv import DictReader
from hashlib import file_digest
from pickle import load
import re
from prefix import BASE,N,SURVIVORS,ZERO,PARENT,PARENT_SHA,sha

assert sha(PARENT)==PARENT_SHA
gs=Path('geometry.tsv').read_text().splitlines()[1].split('\t')
assert gs[:4]==['1278','98','K8,8','2453']
phase,divisor,source_weight,chirality,geometry,weight,d=map(int,gs[4:])
assert (phase,divisor,source_weight,chirality,geometry,weight,d)==(1,2**132,48,2,2,192,N)
L,original=literal_eval(Path('source/original-roster.txt').read_text())
with Path('source/ordinal-roster.tsv').open() as f:
    archived=list(DictReader(f,delimiter='\t'))
assert [int(x['original_ordinal']) for x in archived]==list(range(8))
assert [literal_eval(x['original_joint_L_tuple']) for x in archived]==list(original)
assert [int(x['original_ordinal']) for x in archived if x['disposition']=='exact_zero']==list(ZERO)
values={i:(i,repr(original[i]),0,0,N,'empty_factor_zero',PARENT_SHA) for i in ZERO}
costs=[];work=[];stage_rows=[]
for i in SURVIVORS:
    assert Path(f'L{i}-status.out').read_text()=='0\n'
    assert not Path(f'L{i}-replay.err').read_bytes()
    a=BASE/f'L{i}'; f=Path(f'author/L{i}')
    original_a,original_f=a,f
    if i==6:a=a/'budget-rescue'; f=f/'budget-rescue'
    log=Path(f'L{i}-replay.out').read_text()
    if Path(f'L{i}-triangle-replay.out').exists():
        assert not Path(f'L{i}-triangle-replay.err').read_bytes()
        log+='\n'+Path(f'L{i}-triangle-replay.out').read_text()
    assert (f/'contraction.receipt').read_bytes()==(a/'contraction.receipt').read_bytes()
    assert (original_f/'joint-label-roster.tsv').read_bytes()==(original_a/'joint-label-roster.tsv').read_bytes()
    for p in f.glob('pass[1-9].out'):
        assert p.read_bytes()==(a/p.name).read_bytes()
    m=re.search(rf'^exact whole original L scalar {i} (\([^)]*\)) (\d+) terminal ([a-f0-9]+) elapsed ([.0-9]+)$',log,re.M)
    assert m and int(m[2])==N
    re_,im=literal_eval(m[1])
    assert im==0
    triangle=Decimal(0)
    p=(f/'terminal.out')
    latest=max(f.glob('pass[1-9].out'))
    stem='unsharded-result.pkl' if latest.stem=='pass1' else latest.stem+'-result.pkl'
    end=a/stem
    assert sha(end)==m[3]
    with end.open('rb') as stream:
        data=load(stream)
        assert data['physical_cut']==(L,original[i])
        fs=data['factors']
    if p.exists():
        assert (f/'terminal.time').read_bytes()==(a/'terminal.time').read_bytes()
        assert p.read_bytes()==(a/'terminal.out').read_bytes()
        sums=re.findall(r'^triangle signed numerator \d \d \d ([-\d]+) ([-\d]+) denominator (\d+)',p.read_text(),re.M)
        assert [tuple(map(int,x)) for x in sums]==[(re_,im,N)]*2
        assert len(fs)==3
        assert 'independent third pivot' in log
        triangle=Decimal((f/'terminal.time').read_text().splitlines()[0].split()[1])
        disposition='independent_triangle'
    else:
        assert fs==[((),{():(re_,0)},N)]
        disposition='independent_axis_empty'
    values[i]=(i,repr(original[i]),re_,im,N,disposition,m[3])
    guard_lines=(f/'contraction.receipt').read_text().splitlines()
    assert guard_lines[0]=='child status 2'
    guard=Decimal(guard_lines[1].split()[-1])
    passes=sorted(f.glob('pass[1-9].out'))
    author_times=[]
    for y in passes:
        matches=re.findall(r'^(?:total process seconds|follow seconds) ([.0-9]+)',y.read_text(),re.M)
        assert len(matches)==1
        author_times.append(Decimal(matches[0]))
    cont=sum(author_times)
    solve_file=f/f'solve-L{i}.time'
    solve=Decimal(solve_file.read_text().splitlines()[0].split()[1]) if solve_file.exists() else 'unmeasured'
    refused_guard=Decimal(0)
    independent_time=Decimal(m[4])
    if i==6:
        receipt=(original_f/'contraction.receipt').read_text().splitlines()
        assert receipt[0]=='child status 1'
        refused_guard=Decimal(receipt[1].split()[-1])
        refusal=Path('L6-native-budget.out').read_text()
        independent_time+=Decimal(re.search(r' elapsed ([.0-9]+)$',refusal)[1])
    costs.append((i,guard,cont,triangle,refused_guard,solve,independent_time))
    if i==6:
        refusal=Path('L6-native-budget.out').read_text()
        mm=re.search(r'linked pairs (\d+) minimum proposal \((\d+), (\d+), (\d+)\) prefix work (\d+) cap factors (\d+) cap rows (\d+)',refusal)
        linked,forecast,il,ir,earlier,nf,rows=map(int,mm.groups())
        assert forecast>8_000_000 and earlier==7825348 and nf==11
        cap_hash=sha(a/'row-cap-physical-slice-dense-branch.pkl')
        assert f'all independent guarded tables equal unchanged-budget author capture {cap_hash} ' in log
        visits='no candidate admissible'
        with (a/'row-cap-physical-slice-dense-branch.pkl').open('rb') as stream:
            factors=load(stream)['factors']
        wires=len({wire for axes,_,_ in factors for wire in axes})
        cap='product'
    else:
        matched=re.search(rf'^independent exact native cap tables {i} ([a-f0-9]+) (\d+) (\d+) (\d+) (\d+) \((\d+), (\d+)\) (\d+) (\d+) (\d+)$',log,re.M)
        cap_hash=matched[1]
        assert sha(a/'row-cap-physical-slice-dense-branch.pkl')==cap_hash
        nf,rows,wires,earlier,il,ir,forecast,visits,cap=map(int,matched.groups()[1:])
        assert cap==500001 and visits<=forecast
    stages=[list(map(int,s.split()[2:])) for s in log.splitlines() if s.startswith('stage counts ')]
    assert len(stages)==len(passes)
    for stage,elapsed in zip(stages,author_times,strict=True):stage_rows.append((i,*stage,elapsed))
    _,splits,joins,folds,_,products,refused=map(sum,zip(*stages))
    work.append((i,cap_hash,nf,rows,wires,earlier,f'({il},{ir})',forecast,visits,cap,splits,joins,folds,products,refused))
assert set(values)==set(range(8))
total=sum(values[i][2] for i in range(8))
assert sum(values[i][3] for i in range(8))==0
normalized=Fraction(total,N)
unweighted_phys=normalized*phase/divisor
weighted=unweighted_phys*weight
def save(path,header,rows):
    Path(path).write_text(header.replace(' ','\t')+'\n'+''.join('\t'.join(map(str,r))+'\n' for r in rows))
save('scalar.tsv','ordinal original_joint_L raw_re raw_im factor_denominator disposition evidence_sha256',
     [values[i] for i in range(8)])
save('timing.tsv','ordinal native_guard_s continuation_s separate_terminal_s unsuccessful_original_guard_s author_solve_wall_s independent_terminal_replay_s',costs)
save('cap-work.tsv','ordinal cap_sha256 cap_factors cap_rows cap_wires native_accepted_products refused_pair matched_products_or_minimum visited_products guard_trigger inverse_splits retained_joins signed_quotients retained_products author_discarded_trial_visits',work)
save('work-by-pass.tsv','ordinal stage inverse_splits retained_joins signed_quotients retained_factors retained_products author_discarded_visits author_s',stage_rows)
save('composition.tsv','scope exact_real exact_imaginary',
    [('raw_gaussian',total,0),('stored_factor',normalized,0),('physical_single_group',unweighted_phys,0),
     ('original_cover_coefficient',weight,0),('physical_cover_contribution',weighted,0)])
prep=Decimal(Path('source/preparation.time').read_text().splitlines()[0].split()[1])
g,c,t,b=map(sum,zip(*(x[1:5] for x in costs)))
print('measured author components (prep, native, continuation, separate triangles, unsuccessful original guard, sum)',prep,g,c,t,b,prep+g+c+t+b)
print('whole signed exact raw',total,0,'factor denominator',N,'stored normalization',normalized,'physical cover contribution',weighted,flush=True)
