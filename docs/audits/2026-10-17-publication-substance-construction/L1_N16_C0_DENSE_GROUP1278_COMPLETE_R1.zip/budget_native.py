from itertools import combinations
from pickle import dump
from pathlib import Path
from gc import collect
from time import monotonic
from prefix import BASE,SEED,choose,check_cap,condition,trim,join,native_fold,pinned_source,forecast,validate,sha
from ast import literal_eval
from csv import DictReader

start=monotonic()
index=6
author=BASE/'L6'; local=Path('author/L6')
for line in (local/'frozen-inputs.sha256').read_text().splitlines():
    h,n=line.split(maxsplit=1)
    assert sha(author/n)==h
    if not n.endswith('.pkl'):assert sha(local/n)==h
assert (local/'contraction.receipt').read_text().startswith('child status 1\n')
assert (local/'contraction.err').read_text().endswith("AssertionError: ('no admitted join', 11, 7825348)\n")
original,L,found=pinned_source()
declared=(local/'joint-label-roster.tsv').read_text().splitlines()
assert declared[0]==f'axes\t{L!r}'
assert [(int(i),literal_eval(k),int(n),int(m)) for i,k,n,m in (s.split('\t') for s in declared[1:])]==[
    (i,*row) for i,row in enumerate(found)]
with Path('source/ordinal-roster.tsv').open() as f:
    archive=list(DictReader(f,delimiter='\t'))
assert found[index][1:]==tuple(int(archive[index][key]) for key in ('prepared_selected_rows','largest_prepared_factor'))
seed=condition(original,L,found,index,author)
del original
collect()
factors=seed['factors'];validate(factors)
trim(factors);trim(factors)
work=0
logs=(local/'contraction.out').read_text().splitlines()
joins=[line for line in logs if line.startswith('join ')]
quotients=[line for line in logs if line.startswith('quotient ')]
assert len(joins)==77
for step,recorded_join in enumerate(joins):
    prior,i,j=choose(factors,work)
    f,g=factors[i],factors[j]
    matched=prior
    if prior>50_000:
        f,g,n=native_fold(f,g)
        g,f,m=native_fold(g,f)
        factors[i],factors[j]=f,g
        matched=forecast(f,g)[0]
        assert quotients.pop(0)==f'quotient before join {len(factors)} {prior} {matched} slices {m+n}'
    peers=[F for k,F in enumerate(factors) if k not in (i,j)]
    table=join(f,g,peers,matched)
    assert len(table[1])<=500_000
    factors=peers+[table]
    trim(factors,len(factors)-1)
    if len(factors)%8==0:trim(factors)
    table=factors[-1]
    assert recorded_join==f'join {len(factors)} {matched} {len(table[1])} axes {len(table[0])}'
    work+=matched
    print('native accepted',step,len(factors),matched,len(table[1]),work,flush=True)
assert not quotients and work==7825348 and len(factors)==11
assert choose(factors,work) is None
forecasts=[(m,a,b) for a,b in combinations(range(len(factors)),2) if (f:=forecast(factors[a],factors[b])) is not None for m in [f[0]]]
assert forecasts and min(forecasts)[0]>8_000_000
validate(factors)
with Path('L6-independent-native-refusal.pkl').open('xb') as stream:
    dump({'factors':factors,'used_before':work,'physical_cut':seed['physical_cut']},stream,protocol=5)
print('independent exact no-admitted-product guard',index,'linked pairs',len(forecasts),
      'minimum proposal',min(forecasts),'prefix work',work,'cap factors',len(factors),'cap rows',
      sum(len(t) for _,t,_ in factors),'independent native state sha',sha(Path('L6-independent-native-refusal.pkl')),
      'elapsed',round(monotonic()-start,6),flush=True)
