from pathlib import Path
from hashlib import sha256, file_digest
from subprocess import check_output
from zipfile import ZipFile
from io import BytesIO
from ast import literal_eval
from csv import DictReader
from itertools import product
from collections import defaultdict
from math import lcm,prod
import json
import re
from chirality_review import physical_normalization,load_cut

def archive(s,h,m):
    repo='/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103'
    head='c7fb091365d42c497c777c40e18c91027dc41c4f'
    n='docs/audits/2026-10-17-publication-substance-construction/L1_N16_C0_DENSE_'+s+'_R1.zip'
    data=check_output(['git','-C',repo,'show',head+':'+n])
    assert sha256(data).hexdigest()==h
    z=ZipFile(BytesIO(data))
    assert len(z.namelist())==len(set(z.namelist()))
    for l in z.read(m).decode().splitlines():
        digest,name=l.split(maxsplit=1)
        assert sha256(z.read(name.removeprefix('./'))).hexdigest()==digest
    print('verified committed archive and manifest',s,h,flush=True)
    return z

group=1278
den=1778314369133712165932108630458368
author=Path('/private/tmp/l1-geometry-component98-preparation.iOKjDp/1278')
with archive('COMPONENT98_PREPARATION','7bc453b3af91f71bdef58fb1deeb4885928dae083b89f9c9b855ab9416da5ad6','review-manifest.portable.sha256') as z:
    for f in ('frontier.sha256','preparation.out','preparation.time','original-labels.tsv','original-roster.txt','prepared-roster.tsv','ordinal-roster.tsv','result.json'):
        assert z.read('group-1278/'+f)==Path('source/'+f).read_bytes()
    for f in ('components.tsv','ordered-edges.tsv','gamma-pairs.tsv'):
        Path('source/'+f).write_bytes(z.read('source-receipts/'+f))
    result=json.loads(z.read('group-1278/result.json'))
    assert result['denominator']==den and result['group']==1278
    assert result['remaining_ordinals']==[0,1,2,3,4,6] and result['proved_zero_ordinals']==[5,7]
    for p in (author,author/'cached-original-roster'):
        with (p/'dense-saturated-frontier.pkl').open('rb') as f:
            assert file_digest(f,'sha256').hexdigest()==result['prepared_sha256']=='31144d3b9b58967a81fa0fef3b61559155d8e931d127d2a7d3abc02ce74b7a2c'
    assert result['source_rows']==2212402 and result['prepared_rows']==660423
    for f in ('preparation.out','preparation.time','frontier.sha256'):
        assert (author/f).read_bytes()==Path('source',f).read_bytes()
    with Path('source/ordinal-roster.tsv').open() as f:
        data=list(DictReader(f,delimiter='\t'))
    assert [int(x['original_ordinal']) for x in data]==list(range(8))
    zeros=[x for x in data if x['disposition']=='exact_zero']
    assert [int(x['original_ordinal']) for x in zeros]==[5,7]
    assert all(len(literal_eval(x['empty_prepared_factors']))==13 for x in zeros)
    print('zero scopes pinned',[(x['original_ordinal'],x['empty_prepared_factors']) for x in zeros],flush=True)
with archive('GEOMETRY_COVER','bf3bfef6484236edc5eca2961d705f9ee27cc17b857c9c69df89114e4d99b1b4','SHA256SUMS') as z:
    assert b'weights 192' in z.read('README.md')
    with ZipFile(BytesIO(z.read('ACTUAL_REVIEW.zip'))) as actual:
        assert actual.testzip() is None
        print('bound accepted geometry actual-review archive',sha256(z.read('ACTUAL_REVIEW.zip')).hexdigest(),flush=True)
with Path('source/components.tsv').open() as f:
    components=list(DictReader(f,delimiter='\t'))
matches=[row for row in components if group in literal_eval(row['selected_side'])]
assert len(matches)==1
m=matches[0]
A,B=(set(literal_eval(m[f])) for f in ('selected_side','other_side'))
assert m['kind']=='K8,8' and m['id']=='98' and len(A)==len(B)==8 and not A&B
with Path('source/ordered-edges.tsv').open() as f:
    edges={(int(x['source_canonical']),int(x['target_canonical'])):int(x['full_assignment_count'])
           for x in DictReader(f,delimiter='\t')}
assert {(a,b):n for (a,b),n in edges.items() if a in A|B or b in A|B}=={
    (a,b):2 for a,b in [*product(A,B),*product(B,A)]}
with Path('source/gamma-pairs.tsv').open() as f:
    mapping={int(k):int(v) for k,v in (l.split('\t') for l in f.read().splitlines()[1:])}
assert len(mapping)==1936 and not set(mapping)&set(mapping.values())
partner=mapping[group]
assert partner==2453
plan,blocks,_,axes=load_cut()
assert len(axes)==16 and tuple((q,p) for p,q in plan[group][4])==plan[partner][4]
for g in (group,partner):
    groups=defaultdict(list)
    for i in plan[g][5]:
        label,key,location,encoded,nrows,denom=blocks[i]
        groups[label].append(denom)
    assert len(groups)==88 and prod(lcm(*row) for row in groups.values())==den
scale,weight=physical_normalization()
assert scale==2**132 and weight==48 and 2*2*weight==int(m['whole_pair_weight'])==192
Path('geometry.tsv').write_text('group\tcomponent\tclass\tgamma_partner\tphase\tphysical_divisor\tsource_weight\tchirality_factor\tgeometry_factor\tcover_coefficient\tfactor_denominator\n'
    + '\t'.join(map(str,(group,98,'K8,8',partner,1,scale,weight,2,2,192,den)))+'\n')
print('verified selected component 98 side, all 128 directed edges of multiplicity 2, gamma partner and single coefficient 192',flush=True)
