#!/bin/bash
set -eu -o pipefail
b=/private/tmp/l1-geometry-component98-preparation.iOKjDp/1278/cached-original-roster
for i in "$@"; do
  deadline=$((SECONDS+360))
  while [ ! -s "$b/solve-L$i.time" ] || ! rg -q '(exact raw scalar|follow seconds|total process seconds)' "$b/solve-L$i.out"; do
    test "$SECONDS" -lt "$deadline"
    sleep 3
  done
  /bin/bash run_ordinal.sh "$i"
done
