from pathlib import Path
import re

for index in range(9):
    log = Path(f'slice-{index}-replay.out').read_text()
    match = re.search(r'(?:wall seconds|seconds) ([\d.]+)$', log, re.M)
    if index in (7,8):
        match = re.search(r'^complete shards .* seconds ([\d.]+)$', log, re.M)
    assert match, index
    print(f'slice {index} wall seconds {match[1]}')
print(Path('replay-timing.out').read_text(), end='')
