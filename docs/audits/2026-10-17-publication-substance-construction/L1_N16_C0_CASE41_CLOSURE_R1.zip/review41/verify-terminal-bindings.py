from pathlib import Path
from re import I, M, search

audit = Path('audit-archive.out').read_text()
for index in (2, 3, 7, 8):
    identity = search(rf'^replay input {index} \d+ \d+ \S+ ([0-9a-f]{{64}}) \d+ \d+$', audit, M)[1]
    log = Path(f'slice-{index}-replay.out').read_text()
    used = search(r'^input sha256 ([0-9a-f]{64})(?: |$)', log, M | I)[1]
    assert identity == used
    if index in (2,3):
        assert search(r'^independent pivot 1 ', log, M)
    else:
        assert search(r'^alternate pair \(1, 2\) ', log, M)
    print('PASS alternate terminal', index, 'used audited checkpoint', identity)
