from fractions import Fraction
from pathlib import Path
import re
import sys

root=Path(__file__).resolve().parent
pattern=re.compile(r'^(?:independent )?exact normalized real (\S+) imaginary (\S+)',re.M)
raw_pattern=re.compile(r'^(?:PASS )?raw(?: scalar numerator)? (-?\d+) (?:imaginary )?(-?\d+) factor denominator (\d+)',re.M)
sum_x=sum_y=Fraction()
for case in map(int,sys.argv[1:]):
    a=root/('author' if case==25 else f'author{case}')
    r=root/('review' if case==25 else f'review{case}')
    ledger=[line.split('\t') for line in (a/f'author-case{case}.tsv').read_text().splitlines()]
    assert len(ledger)==10 and [int(fields[0]) for fields in ledger[:-1]]==list(range(9))
    x=y=Fraction()
    for i,coord,n,re_value,im_value,receipt in ledger[:-1]:
        matches=[]
        for file in sorted(r.glob(f'slice-{i}-*replay.out')):
            log=file.read_text()
            scaled=pattern.search(log)
            numerator=raw_pattern.search(log)
            if scaled and numerator:
                matches.append((scaled,numerator))
        assert matches, (case,i)
        expected=Fraction(re_value),Fraction(im_value)
        assert tuple(map(Fraction,pattern.search((a/receipt).read_text()).groups()))==expected
        for scaled,numerator in matches:
            a_raw,b_raw,den=map(int,numerator.groups())
            scale=den*16*4**64
            assert tuple(map(Fraction,scaled.groups()))==(Fraction(a_raw,scale),Fraction(b_raw,scale))==expected
        x+=expected[0]
        y+=expected[1]
    assert ledger[-1]==['sum',str(x),str(y)]
    print('PASS',case,x,y)
    sum_x+=x
    sum_y+=y
print('SUBTOTAL',sum_x,sum_y)
