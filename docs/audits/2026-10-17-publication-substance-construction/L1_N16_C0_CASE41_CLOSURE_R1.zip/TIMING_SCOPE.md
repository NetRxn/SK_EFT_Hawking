# Measured time for eight difficult outer terms

The table combines elapsed time reported by each author rescue invocation and
the time reported by the terminal shard loops. It includes cap refusals in
those rescue invocations. These are sums across tasks that may overlap. They
exclude the primary pass, shard setup outside the reported loop, independent
review and the original factor generation. The table is neither CPU accounting
nor elapsed runtime for the entire calculation.

The median of the eight sums is 253.808 seconds, with a range of 236.390 to
270.492. The sample represents terms with the same two triangle and two
four-factor terminal closures. It gives a local cost estimate for this
contraction pattern. It supplies no defensible multiplier across the other
tuples, internal-index siblings, or the other 3,871 groups in this dense
profile. Measure or classify those frontiers before projecting the full cost.
