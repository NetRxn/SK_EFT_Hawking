"""Extend the frozen 43-case subtotal, retaining exact cut coordinates."""
from fractions import Fraction
from pathlib import Path
import re
import subprocess
import sys

root=Path(__file__).resolve().parent
prior=root/'partial-43.tsv'
output=subprocess.check_output([sys.executable,str(root/'verify-cases.py'),*sys.argv[1:]],text=True)
values={}
for line in prior.read_text().splitlines():
    prefix=line.split('\t',1)[0]
    if not prefix.isdigit():
        continue
    i,coord,real,imag,_=line.split('\t')
    assert int(i) not in values
    values[int(i)]=(coord,Fraction(real),Fraction(imag),'previous accepted receipt')
assert len(values)==43
from ast import literal_eval
_,schedule=literal_eval((root/'prior-separator-roster.txt').read_text())
schedule=sorted(schedule,key=lambda entry:(entry[1],entry[0]))
assert len(schedule)==48 and len(dict(schedule))==48
for i,real,imag in re.findall(r'^PASS (\d+) (\S+) (\S+)$',output,re.M):
    case=int(i)
    assert case not in values
    values[case]=(str(schedule[case][0]),Fraction(real),Fraction(imag),'new independent replay')
for i,(coord,x,y,ref) in sorted(values.items()):
    assert coord==str(schedule[i][0])
    print(i,coord,x,y,ref,sep='\t')
print('PARTIAL SUM',len(values),sum(v[1] for v in values.values()),sum(v[2] for v in values.values()),sep='\t')
print('OPEN',','.join(str(i) for i in range(48) if i not in values),sep='\t')
