# L1 N16 exact outer case 41

Scientific source 51e7c745e, publication parent 39ea78cc4. This is one outer
term of the first binary child of tuple 0 in descendant (0,0). Restore the
corresponding seven-factor parent as described by
`L1_N16_C0_CASES29_31_CLOSURE_R1.zip` under `next-frontiers`. Its SHA256 is
`3684a6f751c1b53d45dd8f9f0d7c37bb1e197a2802b01248a6756cd5a26db2f9`.
Deserialize only trusted checkpoint files.

From scratch seeded with the appropriate author folder:

```bash
python3 -u run-primary.py /absolute/path/to/restored-parent.pkl >slices.tsv
python3 -u reduce-open.py 0 1 2 3 4 5 6 7 8 >rescue.tsv
shasum -a 256 -c /absolute/path/to/archive/frontiersN.sha256
python3 -u run-final-shards.py >shard-jobs.tsv
python3 sum-caseN.py
```

Replace N with the case index. Triangles 2 and 3 and four-factor slices 7 and 8 each use eight disjoint author row intervals. The other five values close by direct or repeated support/quotient reduction. Independent evidence preserves alternate pivots and selected pairs, input bindings, and full exact shard checks. Recreate a duplicate named Git ZIP absent from a reviewer manifest from the original repository bytes by its recorded hash. See each `reviewN/REVIEW.md` for the precise lineage and evidence scope.

Run `python3 verify-cases.py 41` and `python3 retally-48.py 41` to reproduce
the independently replayed exact subtotal and update the immutable 43-case
ledger. See TIMING_SCOPE.md for the limits of the partial timing census.
