from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys

def run(pair):
    case,shard=pair
    if case in (2,3):
        args=['triangle-shards.py',f'join-cap-dense-label-rescue-{case}-1-reduced.pkl',str(shard),'8']
    else:
        args=['close-four-shards.py',f'row-cap-physical-slice-dense-label-rescue-{case}-0-reduced.pkl',
              '--pair','1','3','--shard',str(shard),'8']
    output=Path(f'slice-{case}-shard-{shard}.out')
    with output.open('xb') as log:
        result=subprocess.run([sys.executable,'-u',*args],stdout=log,
                              stderr=subprocess.STDOUT,timeout=135)
    assert result.returncode==0,(case,shard,result.returncode)
    print(case,shard,result.returncode,sep='\t',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run,[(i,j) for i in (2,3,7,8) for j in range(8)]))
for index in (2,3,7,8):
    with Path(f'slice-{index}-shard-sum.out').open('xb') as out:
        subprocess.run([sys.executable,'sum-shards.py',str(index),'8'],stdout=out,check=True)
