from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import validate_helpers as helpers
from validation.checks import prose_lean_refs as refs


def compare():
    parent = Path(sys.argv[1])
    index = refs._load_lean_name_index()
    resolved = {"OK", "MATHLIB", "PRIVATE", "PHYSLIB"}
    bundles = {}
    for code in refs.BUNDLE_CODES:
        counters = {}
        direct_files = {}
        for case, exp in (("base", False), ("base", True), ("tree", True)):
            draft = parent / case / "papers" / code / "paper_draft.tex"
            source = draft.read_text()
            tokens = Counter(t for t, _ in refs._prose_verbatim_tokens(source))
            if exp:
                files = list(refs._bundle_table_sources(draft, source))
                assert all(error is None for _, _, error in files), (code, files)
                direct_files[case] = sorted(str(path) for path, _, _ in files)
                for _, table, _ in files:
                    tokens.update(t for t, _ in refs._prose_verbatim_tokens(
                        table, macro_source=source,
                    ))
            counters[case + ("-expanded" if exp else "-raw")] = tokens
        assert counters["base-raw"] == counters["base-expanded"] == counters["tree-expanded"], code
        tiers = {}
        for token in sorted(counters["base-raw"]):
            if token in refs._PROSE_REF_ALLOWLIST:
                status = "ALLOWLIST"
            else:
                status = refs._resolve_prose_ref(token, index, deep=False)
                if status not in resolved:
                    status = (refs._resolve_prose_ref(token, index)
                              if refs._prose_token_is_reportable(token)
                              else "NOT_REPORTABLE")
            tiers[token] = status
        bundles[code] = {"counter": counters["base-raw"], "tiers": tiers,
                         "files": direct_files}
    print(json.dumps({"total_occurrences": sum(sum(b["counter"].values()) for b in bundles.values()),
                      "old_direct_files": sum(len(b["files"]["base"]) for b in bundles.values()),
                      "new_direct_files": sum(len(b["files"]["tree"]) for b in bundles.values()),
                      "catalog_sha256": hashlib.sha256(helpers.LEAN_DEPS_PATH.read_bytes()).hexdigest(),
                      "bundles": bundles}, indent=2))


def run():
    result = refs.check_prose_theorem_reference_coverage()
    print(json.dumps({"passed": result.passed, "details": [
        {"name": d.name, "passed": d.passed, "warning": d.warning, "message": d.message}
        for d in result.details
    ]}, indent=2))


if sys.argv[2] == "compare":
    compare()
else:
    run()
