import hashlib
import json
from pathlib import Path
import subprocess
import sys

from seed_journal import outstanding, seeded_mutation

path = Path("papers/D9/tables/exact.tex").resolve()
original = path.read_bytes()
st = path.stat()
journal = outstanding(include_live=True)
old = r"\lean{diamondDist\_dephasing\_eq}"
new = r"\lean{d9\_generated\_table\_reader\_missing\_probe}"
assert original.count(old.encode()) == 1
line = original[:original.index(old.encode())].count(b"\n") + 1
assert line == 9
with seeded_mutation(path, lambda s: s.replace(old, new),
                     reason="canonical generated-table reader probe"):
    result = subprocess.run(
        [sys.executable, "scripts/validate.py", "--check",
         "prose_theorem_reference_coverage", "--json"],
        text=True, capture_output=True,
    )
    assert result.returncode == 1, (result.returncode, result.stderr)
    check = json.loads(result.stdout)["checks"]["prose_theorem_reference_coverage"]
    assert check["passed"] is False and check["measured"] is True
    finding = next(d for d in check["details"]
                   if d["name"] == "unresolved:D9:d9_generated_table_reader_missing_probe")
    assert finding["passed"] is False and finding["warning"] is False
    assert f"papers/D9/tables/exact.tex:{line}" in finding["message"]
    Path(sys.argv[1]).write_text(result.stdout)
assert path.read_bytes() == original
assert path.stat().st_mtime_ns == st.st_mtime_ns
assert outstanding(include_live=True) == journal
print(json.dumps({"exit": result.returncode, "finding": finding,
                  "exact_bytes_restored": True, "mtime_restored": True,
                  "journal_restored": True, "table_sha256": hashlib.sha256(original).hexdigest()}, indent=2))
