import json
from pathlib import Path

from validation.checks.prose_lean_refs import _bundle_table_sources, _direct_table_inputs

authority = Path("/tmp/publication-table-input-lexical-controls.CYm3P0")
expect = {
    "canonical": ("tables/witness", True),
    "dot_prefix": ("./tables/witness", True),
    "newif_declaration": ("tables/witness", True),
    "false_branch": (None, False),
}
result = {}
for label, (expected, active) in expect.items():
    tex = authority / f"{label}.tex"
    source = tex.read_text()
    recognized = list(_direct_table_inputs(source))
    reads = list(_bundle_table_sources(tex, source))
    rendered = "ACTIVE TABLE WITNESS" in (authority / f"{label}.txt").read_text()
    assert rendered == active
    if active:
        assert len(recognized) == len(reads) == 1
        assert recognized[0][1:] == (expected, None)
        assert reads[0][0].as_posix() == "tables/witness.tex"
        assert reads[0][2] is None
    else:
        assert not recognized and not reads
    result[label] = {"lexical": recognized, "table_reads": [str(row[0]) for row in reads],
                     "witness_rendered_by_root_control": rendered}
print(json.dumps(result, indent=2))
