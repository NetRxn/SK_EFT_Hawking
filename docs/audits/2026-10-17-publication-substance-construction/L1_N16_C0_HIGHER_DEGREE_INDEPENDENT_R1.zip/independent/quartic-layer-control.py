from fractions import Fraction
from pathlib import Path
from replay import roots,pilot,profile
assert profile=='139627958850-131941898707840'
assert not roots[0]
x,y=pilot(0,0),pilot(0,1)
v=x*y
assert v==Fraction(next(l.split()[2] for l in Path('replay-139627958850-131941898707840-0.out').open() if l.startswith('EXACT 0 ')))
print('quartic profile scalar fixed channel',x,y,'product',v)
