from ast import literal_eval
from collections import Counter, defaultdict
from fractions import Fraction
from functools import cache
from math import lcm, factorial, prod
from pathlib import Path

P=Path('RAW/4816825782860-40901228425811-tiled')
F=Fraction
rows=[{},{}]
for l in Path('prior-coframes.tsv').open():
    o,w,m,q,r,i=map(int,l.split())
    key=(w,),(q,),m
    assert key not in rows[o]
    rows[o][key]=(r,i)

@cache
def orient(left,right):
    if left&right:return 0
    inv=0
    while right:
        bit=right&-right
        inv+=(left//(bit<<1)).bit_count()
        right^=bit
    return (-1)**(inv%2)

def restore(owner,degree):
    seeds=rows[owner]
    power={((),(),0):(1,0)}
    for d in range(1,degree+1):
        work=len(power)*len(seeds)
        assert work<=5_000_000
        out={}
        for (w,q,m),(ar,ai) in power.items():
            for (v,p,n),(br,bi) in seeds.items():
                phase=orient(m,n)
                if not phase:continue
                k=tuple(sorted(w+v)),tuple(sorted(q+p)),m|n
                x,y=out.get(k,(0,0))
                z=x+phase*(ar*br-ai*bi),y+phase*(ar*bi+ai*br)
                if any(z):
                    assert k in out or len(out)<600_000
                    out[k]=z
                elif k in out:del out[k]
        print('ordered source wedges',owner,d,'prospective',work,'retained',len(out),flush=True)
        power=out
    for l in (P/'shards'/f'{owner}-{degree}.tsv').open():
        o,w,m,q,r,i=l.split()
        assert int(o)==owner
        k=tuple(map(int,w.split(','))),tuple(map(int,q.split(','))),int(m)
        got=power.pop(k)
        perm=factorial(degree)//prod(factorial(v) for v in Counter(k[0]).values())
        assert got==(perm*int(r),perm*int(i)),(k,got,r,i,perm)
    assert not power

for owner,degree in ((0,1),(1,1),(0,2),(1,2),(0,3)):
    restore(owner,degree)

def shard(owner,degree,with_mask=True):
    out=defaultdict(list)
    for l in (P/'shards'/f'{owner}-{degree}.tsv').open():
        o,w,m,q,r,i=l.split()
        assert int(o)==owner
        v=tuple(map(int,q.split(',')))
        out[v].append((tuple(map(int,w.split(','))),int(m),int(r),int(i)))
    return out

def haar(A,B):
    tables=(defaultdict(list),defaultdict(list))
    scale=1
    for l in (P/'spatial.tsv').open():
        fields=l.rstrip('\n').split('\t')
        S,q,*keys=map(literal_eval,fields[:6])
        if S not in (A,B):continue
        r,i=map(F,fields[6:])
        scale=lcm(scale,r.denominator,i.denominator)
        for ix,shape in enumerate((A,B)):
            if S==shape:tables[ix][q].append((tuple(keys),r,i))
    return tuple({q:[(k,int(r*scale),int(i*scale)) for k,r,i in L]
                     for q,L in tab.items()} for tab in tables),scale

@cache
def keys(a,b):
    word=tuple(sorted(a+b))
    return tuple(x for x in word if x<8),tuple(x-8 for x in word if x>=8)

def index_counts(S,T,L,R):
    (H,J),_=haar(S,T)
    left={k:tuple(sorted(Counter(l[1] for l in v).items())) for k,v in L.items()}
    right={k:tuple(sorted(Counter(l[1] for l in v).items())) for k,v in R.items()}
    @cache
    def disjoint(L,R):
        return (sum(v for _,v in L)*sum(w for _,w in R),
                sum(v*w for m,v in L for n,w in R if (m|n)==(m^n)))
    before=after=probes=0
    assert len(left)*len(right)<=150_000
    for a,A in left.items():
        for b,B in right.items():
            q,p=keys(a,b)
            n=len(H.get(q,()))*len(J.get(p,()))
            if not n:continue
            k,m=disjoint(A,B)
            before+=n*k
            after+=n*m
            probes+=1
    return before,after,probes

L2=shard(0,2)
R2=shard(1,2)
L3=shard(0,3)
R1=shard(1,1)
S,T=(5,0,0,0,1),(5,0,0,0,0)
big=index_counts(S,T,L3,R2)
assert big[:2]==(227_035_136,40_270_848)
print('cubic production edge 00 aligned before, after, moment buckets',*big,flush=True)

S,T=(3,0,0,0,0),(3,0,1,0,0)
small=index_counts(S,T,L2,R1)
assert small[1]==259584 and small[1]<300_000
print('cubic production edge 04 aligned before, after, moment buckets',*small,flush=True)
(H,J),d=haar(S,T)
out={}
seen=0
for a,A in L2.items():
    for b,B in R1.items():
        q,p=keys(a,b)
        if q not in H or p not in J:continue
        for u,m,r,i in A:
            for v,n,s,j in B:
                sign=orient(m,n)
                if not sign:continue
                ar,ai=sign*(r*s-i*j),sign*(r*j+i*s)
                for x,br,bi in H[q]:
                    for y,cr,ci in J[p]:
                        seen+=1
                        x0,y0=br*cr-bi*ci,br*ci+bi*cr
                        k=u,v,m|n,x,y
                        w,z=out.get(k,(0,0))
                        val=(w+ar*x0-ai*y0,z+ar*y0+ai*x0)
                        if any(val):
                            assert k in out or len(out)<20_000
                            out[k]=val
                        else:out.pop(k,None)
assert seen==small[1]
count=len(out)
for l in (P/'raw-edges'/'04.tsv').open():
    u,v,m,x,y,r,i=l.split('\t')
    k=literal_eval(u),literal_eval(v),int(m),literal_eval(x),literal_eval(y)
    assert out.pop(k)==(F(r)*d*d,F(i)*d*d)
assert not out
print('complete cubic production edge 04, exact rows',count,'Haar denominator',d*d,flush=True)
