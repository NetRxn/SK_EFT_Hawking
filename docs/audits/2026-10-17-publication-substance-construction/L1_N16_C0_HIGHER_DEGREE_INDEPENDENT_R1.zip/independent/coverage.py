from pathlib import Path
from collections import Counter
c=Counter()
for p in Path('.').glob('edges-*.out'):
    t=p.read_text().splitlines()[-1].split()
    c['edge tables']+=int(t[7]);c['raw edge rows']+=int(t[10])
for p in Path('.').glob('sites-*.out'):
    lines=p.read_text().splitlines()
    t=lines[-1].split()
    c['site factors']+=2*(len(lines)-1)
    c['mask rows']+=int(t[-2]);c['root rows']+=int(t[-1])
    for l in lines[:-1]:
        z=l.split()
        for key,i in [('root products',5),('mask trials',8),('M peak',11),('C peak',14)]:
            c[key]=max(c[key],int(z[i]))
for p in Path('.').glob('literal-[0-9]*.out'):
    lines=p.read_text().splitlines()
    s=lines[-1].split()
    c['literal targets']+=int(s[4])
    c['literal peak']=max(c['literal peak'],int(s[-5]))
    c["literal admitted prefix peak"]=max(c["literal admitted prefix peak"],int(s[-1]))

    for l in lines[:2]:
        t=l.split()
        c[f'{t[1]} candidate entries']+=int(t[t.index('full')-1]);c[f'{t[1]} nonzero entries']+=int(t[-2])
assert c['site factors']==288 and len(list(Path('.').glob('edges-*.out')))==2
for k,v in sorted(c.items()):print(k,v)
