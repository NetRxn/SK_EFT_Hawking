# Independent higher-degree N16 c0 review

**ACCEPT** both original pure-EHC profiles.

| Profile | Original assignments and chirality multiplicity | Exact coefficient | Weight |
|---|---|---|---:|
| Cubic (4816825782860, 40901228425811) | 12 in six exchanged pairs | 3460617973479782272036640625/158456325028528675187087900672 | 48 |
| Quartic scalar (139627958850, 131941898707840) | Four in one pair and two fixed points | 116455126335618875881809375/9223372036854775808 | 96 |

The combined weighted contribution is `12004103027894607324423053062458721875/9903520314283042199192993792`. Both profiles occur at these weights in the current accepted residual, which matches the predecessor from checkpoint `7d86bdcbb` and the frozen author base byte for byte. The current scope removes 144 labels and yields 9,611 orbits and 827,799 labels. See `reviewed-exact.tsv`, `signed-pairs.tsv` and `block-remaining.tsv`.

## Support and source normalization

I regenerated the projected root domains and exhaustively imposed the two temporal SU(2) coupling constraints, combined spatial center parity, and spatial minimum-load and zero-load equality constraints. The projected Cartesian products contain 9,437,184 and 4,096 candidates, with 31 and nine search nodes. All 576/192 original and 288/144 represented anchor rows agree. Cubic root sectors actually present include (3,0), (0,3), (2,1) and (1,2), in addition to (1,0) and (0,1). Both quartic roots are scalar in every admitted state. The quartic profile contains distinct fixed IDs 0 and 2. The anchor roster explicitly retains all-scalar ID 0 with empty sparse labels.

The source gamma3 involution exchanges chiral Haar factors and preserves the local site tops. Its EHC sign is even at total insertion degree 32. Exact pairing of every supported state gives six cubic and one quartic two-member orbit, with the two separately fixed quartic assignments counted once. Both layers of each profile have even world-epsilon and cross-site wedge parities. The literal check covers 512 stripped coframe rows, 768 four-order EHC folding controls and 64 literal layouts per layer. Each profile restores `4^-64` from the 64 coframe quarters. Original occupation factorials are 20,736 and 2,359,296.

The root calculation independently expands signed canonical Spin(4) linear traces, groups world words, projects the required symmetric powers, and applies exact normalized Haar. The cubic table matches all 34,872 candidate matrix projections and 10,150 nonzeros. The quartic profile matches all 5,809 candidate projections and 1,875 nonzeros, including the complete 889-word quartic scalar root with 157 nonzeros. The degree-four slice is byte-identical to the dedicated scalar table. The independent spatial and temporal moment expansion integrates symmetric powers up to degree three on each unit quaternion using the normalized sphere moment formula. It reproduces all 27,150 spatial candidates and 1,871 nonzeros and 3,878 temporal candidates and 334 nonzeros.

## Exterior filtering and local factor coverage

I independently reconstructed signed one-owner degree-one and degree-two coframe shards for both owners and the degree-three owner-zero shard, using ordered literal wedge multiplication and zero intersection of exterior masks. Because degree-two forms commute, removing the multinomial of distinct world-word orders yields the stored sorted-word coefficient. This agrees exactly for 449,728 shard rows. The largest prospective one-owner step has 4,415,488 candidate products.

For cubic edge 00, independently rebuilt degree-three and degree-two shard masks and Haar incidence give 227,035,136 matched products before the exterior test and 40,270,848 admissible products after it. This is a count-only check for the full edge. For cubic edge 04, independent source reconstruction gives 383,488 before and 259,584 after filtering. Evaluating those disjoint products with the exterior inversion sign and the exact endpoint moments reproduces all 3,264 signed production rows. These are explicit edge-specific checks.

For all 35 spatial edge patterns, inversion of both signed projected endpoint maps preserves the original matrix-index blocks and reconstructs all 135,721 production raw rows exactly once. Literal direct integration checks 46 signed targets across all patterns, including nonreal targets. The unfiltered direct cubic control hit its own prospective guard. A second exact implementation counts admissible exterior prefixes by occupied mask before doing any signed arithmetic, and explores only disjoint continuations. The largest raw candidate count is 60,466,176 and the largest admitted-prefix count is 629,156, below its two-million gate. Direct integration of other production edges has the stated target-row scope.

All 288 split factors were independently rebuilt using the checked signed alias gains, ordered exterior top and exact root-word/matrix joins. All 415,865 mask rows and 88,879 root rows agree. The observed site maxima were 134,656 mask trials, 129,600 root products, and 29,056/20,024 mask/root rows per factor.

## Signed replay

All nine complete 88-factor networks were independently contracted with exact tuple-key Gaussian arithmetic, twofold incidence on every nontrivial wire, signed proportional-slice aggregation and prospective matched-product bounds. Cubic cases 3 and 4 are exact zeros from an empty joint mask/root site factor contraction. The remaining cubic cases are positive. Quartic cases 0 and 1 are positive and case 2 is negative. The exact imaginary coefficients vanish. A separate two-layer replay disconnects the quartic all-scalar channel and gives `11499497505/2097152` times `1236203116875/536870912`, equal to the independently sewn fixed-channel result. Largest network admission and execution metrics were 124,115 initial rows, 4,992 matched products per join, 23,235 matched products in one complete network, and 3,058,058 charged scans.

The intake archive, predecessor and all frozen factor manifests passed verification. `bash reproduce.sh` reruns the checks using the immutable input symlinks. The scope covers these two coefficients. The repository, notebooks and Lean slots were unchanged.
