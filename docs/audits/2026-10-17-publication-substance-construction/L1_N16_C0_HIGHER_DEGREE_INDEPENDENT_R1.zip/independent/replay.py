from collections import Counter,defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from itertools import combinations, count
from ast import literal_eval
from functools import lru_cache
parse=lru_cache(maxsize=85000)(literal_eval)
from fractions import Fraction as F
frac=lru_cache(maxsize=32768)(F)
from math import lcm,gcd,prod,factorial
import sys

sys.path.insert(0,str(Path("INDEPENDENT").absolute()))
from census import occupancy
profile=sys.argv[1]
codes=tuple(map(int,profile.split('-')))
O=[occupancy(code) for code in codes]
AUTHOR=Path('AUTHOR')/profile
RAW=Path('RAW')/(profile+'-tiled')

cap_rows=500_000
cap_work=2_000_000
cap_total=30_000_000
cap_bits=256
roots=defaultdict(dict)
for l in (AUTHOR/'states.tsv').read_text().splitlines():
    c,t,x,k,p,q=map(int,l.split())
    roots[c][t,x,k]=p,q
plans=defaultdict(dict)
for l in (AUTHOR/'anchor-plan.tsv').read_text().splitlines():
    c,t,x,k,*shape=map(int,l.split())
    plans[c][t,x,k]=tuple(shape)
patterns={}
for i,l in enumerate(l for l in (AUTHOR/'edge-plan.out').read_text().splitlines() if l.startswith('pattern ')):
    patterns[parse(l[8:l.rindex(')')+1])]=i
temporal=defaultdict(list)
for l in (AUTHOR/'temporal.tsv').read_text().splitlines():
    shape,rows,cols,r,s=l.split('\t')
    temporal[parse(shape)].append((tuple(x for ij in zip(parse(rows),parse(cols)) for x in ij),(frac(r),frac(s))))

serials=count()

@dataclass
class Table:
    names:tuple
    keys:tuple
    rows:dict
    scale:int
    serial:int=field(default_factory=lambda:next(serials))
def make(name,keys,entries):
    actual=tuple(k for k in keys if k is not None)
    denominator=1
    raw={}
    for row,z in entries:
        assert len(row)==len(keys)
        assert all(k is not None or not x for k,x in zip(keys,row))
        key=tuple(x for k,x in zip(keys,row) if k is not None)
        assert key not in raw and len(raw)<cap_rows
        raw[key]=z
        for v in z:denominator=lcm(denominator,v.denominator)
    assert len(actual)==len(set(actual)) 
    d=denominator
    return Table((name,),actual,{k:tuple(int(v*d) for v in z) for k,z in raw.items()},d)

def build(case,name):
    state=roots[case]
    t,x,tag=(int(k) for k in name[1:]+('0' if len(name)==3 else ''))
    def wires(layer,site,axis,column):
        return tuple((layer,site,axis,column,h) if s else None
                     for h,s in enumerate(state.get((layer,site,axis),(0,0))))
    def label(site,k):return ((t,site,k,'mask'),(t,site,k,'word'))
    if name[0]=='T':
        roster=[];ks=[]
        for (layer,y,k),s in sorted(state.items()):
            q=s[tag]
            if layer!=t or not q or x not in (y,y^(1<<k)):continue
            outgoing=(x==y)
            roster.append((q,bool(t^int(not outgoing))))
            for column in ((3,4) if outgoing else (1,2)):
                ks.append(wires(t,y,k,column)[tag])
        return make(name,tuple(ks),temporal[tuple(roster)])
    if name[0]=='E':
        k=tag;y=x^(1<<k)
        load=lambda v:sum(O[t][v])-O[t][v][k]
        p=patterns[load(x),load(y),plans[case][t,x,k],plans[case][t,y,k]]
        keys=label(x,k)+label(y,k)
        for v in (x,y):
            for side,cols in ((t,(0,1)),(1-t,(2,3))):
                for c in cols:keys+=wires(side,v,k,c)
        def entries():
            for l in (RAW/'rays'/f'{p:02}.tsv').open():
                a,b,m,A,B,r,s=l.split('\t')
                mask=int(m)
                row=(mask&255,parse(a),mask>>8,parse(b))
                row+=tuple(z for pair in (*parse(A),*parse(B)) for z in pair)
                yield row,(frac(r),frac(s))
        return make(name,keys,entries())
    assert name[0] in ('M','C')
    site_root=RAW/'scalar-fixed'/'site' if case==0 and (RAW/'scalar-fixed').is_dir() else RAW/'site'
    joint=tuple((t,x,k,'raw-word') for k in range(3))
    active=[k for k,n in enumerate(O[t][x]) if n]
    if name[0]=='M':
        keys=joint+tuple(w for k in range(3) for w in label(x,k))
        def entries():
            for line in (site_root/f'{case}-{t}-{x}-mask.tsv').open():
                w,comp,m,re,im=line.split('\t')
                values=parse(w)+tuple(z for ij in zip(parse(m),parse(comp)) for z in ij)
                yield values,(frac(re),frac(im))
        return make(name,keys,entries())
    keys=joint+tuple(k for axis in active for col in (4,0) for k in wires(t,x,axis,col))
    def entries():
        for line in (site_root/f'{case}-{t}-{x}-root.tsv').open():
            w,m,re,im=line.split('\t')
            raw=parse(m)
            assert len(raw)==2*len(active)
            result=parse(w)
            for j,k in enumerate(active):
                size=state.get((t,x,k),(0,0))[1]+1
                result+=divmod(raw[2*j],size)+divmod(raw[2*j+1],size)
            yield result,(frac(re),frac(im))
    return make(name,keys,entries())

def select(key,idx):return tuple(key[i] for i in idx)
def pairs(a,b):
    shared=tuple(x for x in a.keys if x in b.keys)
    L=tuple(a.keys.index(k) for k in shared)
    R=tuple(b.keys.index(k) for k in shared)
    return L,R
def forecast(a,b,L,R):
    left=Counter(select(k,L) for k in a.rows)
    right=Counter(select(k,R) for k in b.rows)
    return sum(v*right[k] for k,v in left.items())
def join(a,b,L,R,n):
    assert n<=cap_work
    height=[max((abs(x)+abs(y)).bit_length() for x,y in t.rows.values()) for t in (a,b)]
    assert sum(height)+n.bit_length()<=cap_bits
    p=tuple(i for i in range(len(a.keys)) if i not in L)
    q=tuple(i for i in range(len(b.keys)) if i not in R)
    groups=defaultdict(list)
    for k,z in b.rows.items():groups[select(k,R)].append((select(k,q),z))
    out={}
    seen=0
    for k,(a0,a1) in a.rows.items():
        prefix=select(k,p)
        for suffix,(b0,b1) in groups.get(select(k,L),()):
            seen+=1
            k0=prefix+suffix
            prev=out.get(k0,(0,0))
            got=(prev[0]+a0*b0-a1*b1,prev[1]+a0*b1+a1*b0)
            if any(got):
                assert k0 in out or len(out)<cap_rows
                out[k0]=got
            else:out.pop(k0,None)
    assert seen==n
    return Table(a.names+b.names,select(a.keys,p)+select(b.keys,q),out,a.scale*b.scale)

import resource
class Budget:
    def __init__(self,cap):
        self.cap=cap
        self.used=0
    def charge(self,n):
        assert self.used+n<=self.cap,('quotient scans',self.used,n)
        self.used+=n

def z_times(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def z_add(a,b):
    return a[0]+b[0],a[1]+b[1]

units=((1,0),(0,1),(-1,0),(0,-1))
def normalize(entries):
    # primitive slice, oriented by the unique Gaussian unit taking the
    # first coefficient to the half-open first quadrant
    d=0
    for k,(a,b) in entries:
        d=gcd(d,gcd(a,b))
    x,y=entries[0][1]
    choices=[j for j,u in enumerate(units)
             if (p:=z_times((x,y),u))[0]>0 and p[1]>=0]
    assert len(choices)==1 and d>0
    j,=choices
    unit=units[j]
    scale=z_times((d,0),units[-j%4])
    out=tuple((k,z_times((a//d,b//d),unit)) for k,(a,b) in entries)
    for (k,a),(l,b) in zip(entries,out):
        assert k==l and a==z_times(scale,b)
    return scale,out

def assemble(length,where,first,second):
    row=[None]*length
    for i,z in zip(where,first):row[i]=z
    j=0
    for i in range(length):
        if row[i] is None:row[i]=second[j];j+=1
    assert j==len(second)
    return tuple(row)

def reduce(a,b,L,R,budget):
    budget.charge(len(a.rows)+len(b.rows))
    available={select(k,R) for k in b.rows}
    slices=defaultdict(list)
    ext=tuple(i for i in range(len(a.keys)) if i not in L)
    for key,z in a.rows.items():
        bond=select(key,L)
        if bond in available:slices[bond].append((select(key,ext),z))
    groups={};aliases={}
    budget.charge(sum(map(len,slices.values())))
    for t,rows in slices.items():
        rows.sort()
        coeff,pattern=normalize(rows)
        y=groups.setdefault(pattern,t)
        aliases[t]=y,coeff
    if len(slices)==len(groups)==len(available) and sum(map(len,slices.values()))==len(a.rows):
        return None
    # The first table retains only canonical primitive slices, while
    # the peer accumulates every original bond preimage with its scale.
    budget.charge(len(b.rows)+sum(map(len,groups)))
    left={}
    for sig,y in groups.items():
        for key,z in sig:
            out=assemble(len(a.keys),L,y,key)
            assert out not in left and len(left)<cap_rows
            left[out]=z
    right={}
    max_right=max((abs(x)+abs(y)).bit_length() for x,y in b.rows.values())
    max_multiplier=max(((abs(x)+abs(y)).bit_length() for _,(x,y) in aliases.values()),default=0)
    assert max_right+max_multiplier+max(1,len(aliases)).bit_length()<=cap_bits
    extB=tuple(i for i in range(len(b.keys)) if i not in R)
    for key,z in b.rows.items():
        t=select(key,R)
        if t not in aliases:continue
        y,m=aliases[t]
        dst=assemble(len(b.keys),R,y,select(key,extB))
        new=z_add(right.get(dst,(0,0)),z_times(z,m))
        if any(new):
            assert dst in right or len(right)<cap_rows
            right[dst]=new
        else:right.pop(dst,None)
    assert len(left)<=len(a.rows) and len(right)<=len(b.rows)
    return (Table(a.names,a.keys,left,a.scale),Table(b.names,b.keys,right,b.scale),
            len(slices),len(groups))

def candidates(fs):
    incidence=defaultdict(list)
    for i,f in enumerate(fs):
        for k in f.keys:incidence[k].append(i)
    assert all(len(ij)==2 for ij in incidence.values())
    return sorted({tuple(ij) for ij in incidence.values()})

def sweeps(fs,budget,record,unchanged):
    for epoch in range(9):
        changes=0
        for i,j in candidates(fs):
            for a,b in ((i,j),(j,i)):
                A,B=fs[a],fs[b]
                L,R=pairs(A,B)
                key=(A.serial,B.serial)
                if key in unchanged:continue
                step=reduce(A,B,L,R,budget)
                if step is None:
                    assert len(unchanged)<50_000
                    unchanged.add(key)
                    continue
                C,D,n,k=step
                if not C.rows or not D.rows:
                    print('empty quotient',C.names,D.names,'matched slices',n,'primitive signatures',k,'remaining rows',len(C.rows),len(D.rows),flush=True)
                    return False
                assert C.keys==A.keys and D.keys==B.keys
                fs[a],fs[b]=C,D
                changes+=1
                record[0]+=1
                record[1]+=n-k
        print('sweep',epoch,'changed',changes,'rows',sum(len(f.rows) for f in fs),
              'scans',budget.used,flush=True)
        if not changes:return True
    return True

def geometry():
    for t in range(2):
        for x in range(8):
            yield f'M{t}{x}'
            yield f'C{t}{x}'
    for t in range(2):
        for u in range(8):
            for k in range(3):
                if not u>>k&1:yield f'E{t}{u}{k}'
    for t in range(2):
        for x in range(8):
            for h in range(2):yield f'T{t}{x}{h}'

def pilot(case,layer=None):
    assert layer is None or not roots[case]
    initial=[]
    initial_rows=0
    for name in geometry():
        if layer is not None and int(name[1])!=layer:continue
        table=build(case,name)
        initial_rows+=len(table.rows)
        assert initial_rows<=1_300_000
        initial.append(table)
    assert len(initial)==(88 if layer is None else 44)
    fs=[f for f in initial if f.keys]
    scalars=[f for f in initial if not f.keys]
    degree=Counter(k for f in fs for k in f.keys)
    assert set(degree.values())=={2}
    print('case',case,'factors',len(initial),'wires',len(degree),
          'initial rows',sum(len(f.rows) for f in initial),flush=True)
    if any(not f.rows for f in initial):
        print("EMPTY",case,tuple(f.names for f in initial if not f.rows),flush=True)
        print("EXACT",case,0,flush=True)
        return
    used=total=0
    peak=max(len(f.rows) for f in initial)
    budget=Budget(100_000_000)
    record=[0,0]
    unchanged=set()
    forecasts={}
    if not sweeps(fs,budget,record,unchanged):
        print('ZERO COUNTERS',case,peak,used,total,budget.used,flush=True)
        print('EXACT',case,0,flush=True)
        return
    while fs:
        choices=[]
        for i,j in candidates(fs):
            A,B=fs[i],fs[j]
            L,R=pairs(A,B)
            key=(A.serial,B.serial)
            if key not in forecasts:
                assert len(forecasts)<50_000
                budget.charge(len(A.rows)+len(B.rows))
                forecasts[key]=forecast(A,B,L,R)
            n=forecasts[key]
            choices.append((n,len(A.keys)+len(B.keys)-2*len(L),i,j,L,R))
        n,_,i,j,L,R=min(choices)
        assert total+n<=cap_total and 0<n<=cap_work
        result=join(fs[i],fs[j],L,R,n)
        assert result.rows
        total+=n
        used=max(used,n)
        peak=max(peak,len(result.rows))
        print('join',len(fs),n,len(result.rows),'total',total,flush=True)
        fs=[f for k,f in enumerate(fs) if k not in (i,j)]
        if result.keys:
            fs.append(result)
            if not sweeps(fs,budget,record,unchanged):
                print("ZERO COUNTERS",case,peak,used,total,budget.used,flush=True)
                print('EXACT',case,0,flush=True)
                return
        else:scalars.append(result)
    p=tuple(n for t,occ in enumerate(O) if layer is None or t==layer for site in occ for n in site)
    assert sum(p)==(32 if layer is None else 16)
    fact=prod(factorial(n) for n in p)
    a,b=F(1),F(0)
    for f in scalars:
        assert tuple(f.rows)==((),)
        r,i=f.rows[()]
        a,b=z_times((a,b),(F(r,f.scale),F(i,f.scale)))
    normalization=fact*4**(2*sum(p))
    ans=a/normalization,b/normalization
    print('stats',case,'peak rows',peak,'max join',used,'matched',total,'scans',budget.used,
          'quotient joins',record[0],'removed aliases',record[1],flush=True)
    print('raw factor integral',a,b,'normalized',*ans,flush=True)
    assert ans[1]==0
    print('EXACT',case,ans[0],flush=True)
    return ans[0]

if __name__=='__main__':
    low,high=map(int,sys.argv[2:4])
    for p in sorted(plans):
        if low<=p<high:pilot(p)
