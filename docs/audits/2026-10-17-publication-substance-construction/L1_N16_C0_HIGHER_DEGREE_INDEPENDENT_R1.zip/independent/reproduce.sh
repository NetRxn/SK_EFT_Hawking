set -eu
export PYTHONDONTWRITEBYTECODE=1
repo=/Users/johnroehm/.codex/worktrees/l1-original-n16-python/SK_EFT_Hawking
python=/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python
export PYTHONPATH="$repo"
here=$PWD
(cd INTAKE && shasum -a 256 -c manifest.sha256) > author-manifest.out
(cd RESIDUAL && shasum -a 256 -c manifest.sha256) > residual-manifest.out
cmp INTAKE/accepted-base.tsv RESIDUAL/block-remaining.tsv
python3 support.py > support.out
"$python" normalization.py > normalization.out
for item in cubic quartic; do
    p=4816825782860-40901228425811
    if [ "$item" = quartic ]; then p=139627958850-131941898707840; fi
    (cd "RAW/$p-tiled" && shasum -a 256 -c "$here/INTAKE/$item/frozen-factors.sha256") > "factors-$item.out"
    for f in anchor-plan.tsv edge-plan.out root.tsv spatial.tsv states.tsv temporal.tsv; do
        cmp "AUTHOR/$p/$f" "RAW/$p-tiled/$f"
    done
    "$python" root-rebuild.py "INTAKE/$item/root.tsv" > "roots-$item.out"
    python3 edge-reconstruct.py "$p" > "edges-$p.out"
    "$python" edge-control.py "$p" > "literal-$p.out"
    python3 site-reconstruct.py "$p" > "sites-$p.out"
    python3 replay.py "$p" 0 100 > "replay-$p-0.out"
done
awk -F '\t' '$1==4' INTAKE/quartic/root.tsv | cmp - INTAKE/quartic/quartic-scalar.tsv
python3 exterior.py > exterior.out
python3 quartic-layer-control.py 139627958850-131941898707840 > quartic-layer-control.out
python3 verify-pairs.py --final > verification.out
python3 coverage.py > coverage.out
python3 bounds.py > bounds.out
