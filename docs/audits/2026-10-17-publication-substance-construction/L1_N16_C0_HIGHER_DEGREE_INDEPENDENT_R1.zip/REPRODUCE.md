# Independent L1 higher-degree acceptance

Verify manifest.sha256, then run `python3 check-residual.py independent/reviewed-exact.tsv`.
The two original cubic-channel and quartic-scalar profiles are independently reviewed. Full c0 and physical B3 remain open.
