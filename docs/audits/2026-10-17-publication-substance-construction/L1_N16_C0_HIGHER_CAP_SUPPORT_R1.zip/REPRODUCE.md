# Higher-cap L1 support search

Run `python3 verify.py` to reconcile every row with the previous refusals.
To regenerate, extract the preflight and source folders from the earlier
L1_N16_C0_SUPPORT_RESCREEN_R1 archive, remove remaining-caps.tsv from a
fresh copy, and run `python3 remaining-caps.py preflight source .`.
The search cap is 65,536 nodes. The checkpoint concerns original support
counts and leaves all corresponding signed coefficients owed.
