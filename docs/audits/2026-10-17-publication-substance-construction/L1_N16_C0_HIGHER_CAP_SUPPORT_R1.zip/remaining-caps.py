from pathlib import Path
from time import monotonic
from collections import Counter
exec(Path('component.py').read_text())
CAP=65536
base={tuple(map(int,line.split())) for line in Path('accepted-base.tsv').read_text().splitlines()}
rows=[l.split() for l in Path('prior-reclassified.tsv').read_text().splitlines()]
targets=[(int(a),int(b),int(w)) for a,b,w,t,*_ in rows if t=='REFUSED']
assert len(set(targets))==len(targets)==357 and sum(w for _,_,w in targets)==26406
assert set(targets)<=base
started=monotonic()
counts=Counter()
weights=Counter()
with Path('remaining-caps.tsv').open('x') as out:
    for i,(a,b,w) in enumerate(targets,1):
        tag,n,size,spin,power,_=solve_pilot(a,b)
        counts[tag]+=1
        weights[tag]+=w
        print(a,b,w,tag,n,size,spin,power,sep='\t',file=out,flush=True)
        if i%10==0 or i==len(targets):
            print(i,dict(counts),dict(weights),round(monotonic()-started,2),flush=True)
