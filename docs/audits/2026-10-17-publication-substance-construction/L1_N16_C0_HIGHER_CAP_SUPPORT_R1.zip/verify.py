from collections import Counter
from pathlib import Path
base_list=[tuple(map(int,l.split())) for l in Path('accepted-base.tsv').read_text().splitlines()]
base=set(base_list)
assert len(base)==len(base_list)==9611 and sum(w for _,_,w in base)==827799
target={tuple(map(int,row[:3])) for row in map(str.split,Path('prior-reclassified.tsv').read_text().splitlines()) if row[3]=='REFUSED'}
assert target<=base and len(target)==357
seen=set(); counts=Counter(); weights=Counter(); maximum=0
for line in Path('remaining-caps.tsv').read_text().splitlines():
    a,b,w,t,n,s,spin,power=line.split()
    k=tuple(map(int,(a,b,w)))
    assert k in target and k not in seen
    seen.add(k)
    n,s,spin,power=map(int,(n,s,spin,power))
    if t=='REFUSED':
        assert n==65537 and s==spin==power==0
    else:
        assert t=='EXACT_SUPPORT' and n<=65536
        maximum=max(maximum,s)
    counts[t]+=1; weights[t]+=k[2]
assert seen==target
assert counts=={'EXACT_SUPPORT':325,'REFUSED':32}
assert weights=={'EXACT_SUPPORT':24882,'REFUSED':1524}
print(dict(counts),dict(weights),'largest exact support',maximum)
