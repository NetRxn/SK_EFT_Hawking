# L1 N16 dense signed contraction pilot

Groups 1189 and 1600 are distinct representatives at zero-based source-row ranks 241 and 1693. This package covers original ordinal 0 (L0) for each group. Both routes use the same pinned compiled inputs and unchanged signed contraction checks. The cached route memoizes immutable ordered projections with a 4,096-entry cache.

The two independent review archives record complete source rebuilds through their respective terminal scalars. The archived scripts, output and hash manifests bind the original and cached computations to that review. Large transient operands are identified by hash and can be regenerated from the source preparation scripts and predecessor archives identified by the review receipts.

Run `python3 -B compare.py` from this directory and compare its output to COMPARISON.txt. The solve timings exclude preparation. Group 1600 times its terminal triangle separately. These observations cover two assignments. Whole-group costs, remaining ordinals, the signed coefficient and physical B3 acceptance remain open.
