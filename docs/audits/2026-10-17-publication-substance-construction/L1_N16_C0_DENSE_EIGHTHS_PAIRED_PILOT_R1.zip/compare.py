"""Verify same signed checkpoints and report scoped elapsed differences."""
from decimal import Decimal
from pathlib import Path
import re

def real(log):
    stamp, = re.findall(r"^real (\S+)",log.read_text(),flags=re.M)
    return Decimal(stamp)

for group in (1189, 1600):
    before, after = [Path(str(group))/mode for mode in ("original", "cached")]
    assert (before/"checkpoints.sha256").read_bytes() == (after/"checkpoints.sha256").read_bytes()
    a, b = [real(run/"solve-L0.time") for run in (before,after)]
    if group == 1600:
        entries = [re.findall(r"triangle signed numerator [012] [012] [012] (-?\d+) (-?\d+) denominator (\d+)",
                              (d/"terminal.out").read_text()) for d in (before,after)]
        assert len(entries[0])==2 and len(set(entries[0]))==1 and entries[0]==entries[1]
        ac,bc=[real(run/"terminal.time") for run in (before,after)]
        print(group,"terminal triangle real seconds",ac,bc,"common raw result",entries[0][0])
    else:
        raw=[re.findall(r"^exact raw scalar (.*)",(d/"pass3.out").read_text(),flags=re.M) for d in (before,after)]
        assert len(raw[0]) == 1 and raw[0] == raw[1]
        print(group,"common raw result",raw[0][0])
    print(group,"solve real seconds",a,b,"decrease percent",round((a-b)*100/a,1))
