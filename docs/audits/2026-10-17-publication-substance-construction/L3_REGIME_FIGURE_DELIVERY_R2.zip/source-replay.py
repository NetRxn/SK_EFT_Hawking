import inspect
import math
import sys
from pathlib import Path

import numpy as np
from src.core.visualizations import fig_T_H_evolution_regime_partition as draw

mode = sys.argv[1]
figure = draw()
assert len(figure.data) == 3
left, right, matching = figure.data
for observed, end, count, model in [
    (left, 5.0, 121, lambda t: math.exp(-t)),
    (right, 4.5, 121, lambda t: (1-t/5)**(-1/3)),
    (matching, 2.0, 101, lambda t: t),
]:
    np.testing.assert_allclose(observed.x, np.linspace(0, end, count), atol=1e-14, rtol=1e-14)
    np.testing.assert_allclose(observed.y, [model(t) for t in observed.x], atol=1e-14, rtol=1e-14)
assert np.all(np.diff(left.y)<0) and np.all(np.diff(right.y)>0)
assert left.showlegend is not False and right.showlegend is not False and matching.showlegend is False
assert all(t not in figure.layout.annotations[0].text for t in ('Phase', 'Wave'))
assert '5t/t_evap' in figure.layout.xaxis.title.text and 'τ_cool' in figure.layout.xaxis.title.text
assert (matching.x[50], matching.y[50]) == (1.0, 1.0)
shapes = tuple(figure.layout.shapes)
assert all(s.xref.startswith('x2') and s.yref.startswith('y2') for s in shapes)
assert any(s.type == 'line' and s.y0 == s.y1 == 1 for s in shapes)
assert any(s.type == 'line' and s.x0 == s.x1 == 1 for s in shapes)
fills = [s for s in shapes if s.type == 'rect']
if mode == 'R2':
    assert {(s.x0,s.x1) for s in fills} == {(0,1),(1,2)}
    assert len({s.fillcolor for s in fills}) == 2
else:
    assert not fills
print(f'{mode}: all 343 plotted samples and axes passed; T ends {left.y[-1]:.14g}, {right.y[-1]:.14g}; crossing (1,1); branch fills {len(fills)}')
print(f'R1/R2 chart literal "M_c" test = {"M_c" in inspect.getsource(draw)}')
print('layout fonts', figure.layout.font.size, figure.layout.legend.font.size, figure.layout.xaxis.title.font.size, figure.layout.xaxis.tickfont.size)
