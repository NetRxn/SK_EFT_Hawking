from pathlib import Path
from collections import Counter
def load(path,header=False):
    records={}
    for line in Path(path).read_text().splitlines()[int(header):]:
        a,b,w,tag,n,s,spin,power=line.split()
        key=tuple(map(int,(a,b,w)))
        assert key not in records
        assert tag in {'EXACT_SUPPORT','REFUSED'}
        records[key]=tag,int(n),int(s),int(spin),int(power)
    return records
merged=load('initial.tsv',True)
for path,needed,cap in [('rescreen.tsv',3714,8192),('higher-cap.tsv',357,65536),('final-cap.tsv',32,262144),('last-cap.tsv',1,1048576)]:
    pending={key for key,v in merged.items() if v[0]=='REFUSED'}
    new=load(path)
    assert pending==new.keys() and len(new)==needed
    assert all(n<=cap if tag=='EXACT_SUPPORT' else n==cap+1 and s==spin==power==0
               for tag,n,s,spin,power in new.values())
    merged.update(new)
base_list=[tuple(map(int,line.split())) for line in Path('accepted-base.tsv').read_text().splitlines()]
base=set(base_list)
assert len(base)==len(base_list)==9547 and sum(w for _,_,w in base)==821655
assert base<=merged.keys()
counts=Counter(); weights=Counter(); largest=(0,None)
with Path('current-support.tsv').open('w') as out:
    for key in base_list:
        tag,n,s,spin,power=merged[key]
        largest=max(largest,(s,key))
        mode='capped' if tag=='REFUSED' else 'empty support' if not s else 'fourth power' if power>3 else 'higher spin' if spin>2 else 'larger support' if s>152 else 'within baseline'
        counts[mode]+=1
        weights[mode]+=key[2]
        print(*key,tag,n,s,spin,power,mode,sep='\t',file=out)
assert sum(counts.values())==9547 and sum(weights.values())==821655
for mode in sorted(counts):
    print(mode,counts[mode],weights[mode])
print('largest exact support',largest)
