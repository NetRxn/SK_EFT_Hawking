from pathlib import Path
from time import monotonic

exec(Path('component.py').read_text())
pending=[v.split() for v in Path('final-cap.tsv').read_text().splitlines() if 'REFUSED' in v]
assert len(pending)==1
a,b,w,*_=pending[0]
a,b,w=map(int,(a,b,w))
CAP=1048576
start=monotonic()
tag,n,count,spin,power,forced=solve_pilot(a,b)
print(a,b,w,tag,n,count,spin,power,sep='\t')
print('last-profile seconds',round(monotonic()-start,2))
