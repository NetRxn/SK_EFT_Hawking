# Complete L1 support-count reconciliation

Run `python3 reconcile.py` to merge the original bounded census with
its successive exact-count retries and reconcile the result against
the current accepted numerical residual. Each retry input is exactly the
previous refusal set. The last retry completed at 295,423 nodes and
returned 135,168 supported assignments for the weight-24 profile.

The support predicates include the projected spin and parity constraints.
A nonempty support count does not assert a nonzero signed coefficient.
All reported cohorts still require their appropriate signed contractions
to remove entries from the accepted residual.
