from pathlib import Path
import re
import sys
from unittest.mock import patch
from validation.checks import bundles_readiness as br
from validation._tex import _strip_tex_comments
from src.core import constants

mode = sys.argv[1]
original = br._rows_as_sentences
calls = []
def instrument(body):
    text = original(body)
    flattened = re.sub(r"\\[a-zA-Z]+\*?(\[[^\]]*\])?(\{[^{}]*\})?", " ", text)
    for unit in re.split(r"(?<=[.!?])\s+", flattened):
        words = unit.split()
        if len(words) > 100:
            calls.append((len(words), " ".join(words)))
    return text
with patch.object(br, "_rows_as_sentences", instrument):
    r = br.check_bundle_sentence_length()
print(r)
print("ceiling", constants.SENTENCE_OVER_100_CEILING)
assert r.measured
if mode == "before":
    assert not r.passed and len(calls) == 22 and constants.SENTENCE_OVER_100_CEILING == 18
elif mode == "after":
    assert r.passed and len(calls) == 6 and constants.SENTENCE_OVER_100_CEILING == 6
for n, text in calls:
    print("UNIT",n,text)
