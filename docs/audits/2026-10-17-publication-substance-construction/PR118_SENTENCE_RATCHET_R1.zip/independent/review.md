# PR118 sentence length ratchet independent review

Scoped ACCEPT for patch 1a13d204ed86329647604f14a47a4d7cac5e16f21ab5338b1a573bb7487b05b4 on the packet's a74733105 parent.

The three-path patch reproduced byte for byte in a fresh scratch clone. The existing checker changed from 22 over-limit units at ceiling 18 to six units at ceiling six. Exact multiset comparison found sixteen repetitions of the same 107-token census-only unit removed. The remaining six units were identical, across five bundles, with the longest still 160 words. The advisory count changed from 185 to 169. No bundle manuscripts or input traversal changed.

The filter applies to entire argumentless newcommand lines with scalar numeric, dotted numeric, or eight-character hex bodies. Six focused tests passed. An independent nested input control measured six real 101-word sentences and passed at the actual ceiling. A seventh failed. Removing the nested input failed closed with an unmeasured result. The decider still uses its existing heuristic for the six residual units. This is a measured false-positive correction, with no manuscript rewrite or publication acceptance implied.
