"""Freeze portable replay scripts and signed result receipts."""
from hashlib import file_digest
from pathlib import Path

files=[Path(n) for n in (
    'REVIEW.md','retally.tsv','retally.out','cap.tsv','work.tsv','refusals.tsv','scalar.tsv','timing.tsv',
    'run-native.sh','run-continuation.sh','run-review.sh','configure.py','retally.py',
    'verify.py','source.py','triangle_replay.py','audit_triangle.py','freeze.py',
    'original-roster.txt','original-labels.tsv','prepared-roster.tsv','zero-roster.tsv',
    'input-custody.py','input-custody.out','zeros.py','zero-readback.tsv','zero-readback.time','geometry.tsv','geometry.py',
    'geometry.out','literal-gamma-source.py','continuity.json','continuity-packet.json',
    'publication-opening-head.txt','publication-final-head.txt','checkpoint-delta.tsv',
    'source-archives.tsv','prepared-verify.log')]
files.extend(Path('.').glob('continuity-final*.json'))
files.extend(p for p in Path('source-receipts').glob('*') if p.is_file())
files.extend(p for p in Path('author').rglob('*') if p.is_file())
with Path('review-manifest.portable.sha256').open('w') as output:
    for item in sorted(set(files)):
        with item.open('rb') as stream:
            digest=file_digest(stream,'sha256').hexdigest()
        print(digest,item,sep='  ',file=output)
