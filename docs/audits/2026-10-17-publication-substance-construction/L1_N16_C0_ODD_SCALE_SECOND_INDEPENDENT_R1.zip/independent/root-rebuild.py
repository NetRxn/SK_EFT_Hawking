from ast import literal_eval as parse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
from src.core.formulas import original_spin4_link
from src.vestigial.original_coefficients import (
    OriginalRegulator,Polynomial as P,Symbol, matrix_multiply as mm,
    matrix_dagger,haar_polynomial,
)

reg=OriginalRegulator()
Q=tuple(tuple(P.variable(Symbol('q',((0,0,0,0),0,chi,i))) for i in range(4)) for chi in ('L','R'))
U=original_spin4_link(*Q)
Ud=matrix_dagger(U)
g=reg.gamma
def trace(X):
    return sum((X[i][i] for i in range(len(X))),P())
L={(a,b):trace(mm(U,mm(mm(g[a],g[b]),reg.gamma5))) for a,b in product(range(4),repeat=2) if a!=b}
expected={}
checks=0
def read_value(z):
    if not z:return 0,0
    (w,x),=z.terms
    assert not w
    return x.real,x.imag
from functools import cache
@cache
def rep(n,i,j,h):
    out=P()
    for a in range(n-j+1):
        b=i-a
        if not (0<=b<=j):continue
        z=P.scalar(comb(n-j,a)*comb(j,b))
        for val,count in ((Ud[h+1][h],a),(Ud[h][h],n-j-a),
                          (Ud[h+1][h+1],b),(Ud[h][h+1],j-b)):
            for _ in range(count):z*=val
        out+=z
    return out
for n in (1,2,3):
    basis=defaultdict(P)
    assert len(L)**n<=2048
    for keys in product(L,repeat=n):
        a,b=zip(*keys)
        w=tuple(sorted(a)),tuple(sorted(b))
        coef=P.scalar(1)
        for k in keys:coef*=L[k]
        basis[w]+=coef
    channels=((0,0),(2,0),(0,2),(1,1)) if n==2 else ((1,0),(0,1))
    assert len(basis)*sum(((p+1)*(q+1))**2 for p,q in channels)<=10000
    for (a,b),coef in basis.items():
        for p,q in channels:
            d=(p+1)*(q+1)
            for i,j,k,l in product(range(p+1),range(p+1),range(q+1),range(q+1)):
                z=read_value(haar_polynomial(coef*rep(p,i,j,0)*rep(q,k,l,2))*d)
                checks+=1
                if any(z):expected[n,a,b,p,q,i*(q+1)+k,j*(q+1)+l]=z
actual={}
for l in Path('AUTHOR/anchor/root.tsv').read_text().splitlines():
    n,a,b,p,q,i,j,r,s=l.split('\t')
    n,p,q,i,j=map(int,(n,p,q,i,j))
    k=n,parse(a),parse(b),p,q,i,j
    assert k not in actual
    actual[k]=F(r),F(s)
assert actual==expected
print('independent literal full root projections',checks,'allocated entries',len(expected),'nonzero')
