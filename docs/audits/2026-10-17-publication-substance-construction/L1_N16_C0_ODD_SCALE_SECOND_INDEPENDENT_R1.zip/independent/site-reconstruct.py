import sys
from ast import literal_eval
from collections import defaultdict
from functools import lru_cache
from itertools import product
from fractions import Fraction as F
from math import prod
from pathlib import Path

sys.path.insert(0,str(Path('INDEPENDENT').absolute()))
from census import occupancy
parse=lru_cache(maxsize=100_000)(literal_eval)
T=Path('AUTHOR/anchor')
patterns={}
A={}
for j,l in enumerate(l for l in (T/'edge-plan.out').read_text().splitlines() if l.startswith('pattern ')):
    shape=parse(l[8:l.rindex(')')+1])
    assert shape not in patterns
    patterns[shape]=j
    for side in range(2):
        rows=defaultdict(dict)
        for line in Path(f'SPLIT/rays/{j:02}-{side}.tsv').open():
            w,m,v,n,r,s=line.split('\t')
            key=parse(w)
            assert int(m) not in rows[key]
            rows[key][int(m)]=((parse(v),int(n)),(int(r),int(s)))
        A[j,side]=rows
R=defaultdict(list)
for row in (T/'root.tsv').open():
    n,w,z,l,r,i,j,re,im=row.split('\t')
    R[int(n),int(l),int(r)].append((parse(w),parse(z),(int(i),int(j)),(F(re),F(im))))
states=defaultdict(dict)
for l in (T/'states.tsv').open():
    c,t,x,k,p,q=map(int,l.split())
    states[c][t,x,k]=p,q
plans=defaultdict(dict)
for l in (T/'anchor-plan.tsv').open():
    c,t,x,k,*fields=map(int,l.split())
    plans[c][t,x,k]=tuple(fields)

def mul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def add(a,b):return a[0]+b[0],a[1]+b[1]
def inv(bits):return sum(x>y for i,x in enumerate(bits) for y in bits[i+1:])
def clean(d):return {k:z for k,z in d.items() if any(z)}

@lru_cache(maxsize=12)
def root_data(specs):
    grouped=defaultdict(dict)
    basis=[R[n,*s] for _,n,s in specs]
    count=prod(map(len,basis))
    assert count<=2_000_000
    for selection in product(*basis):
        word=[[],[],[]]
        ij=[]
        coefficient=(1,0)
        for (k,_,_), (p,q,m,z) in zip(specs,selection):
            a,b=[x for x in range(3) if x!=k]
            word[a].extend(p);word[b].extend(q)
            ij.extend(m)
            coefficient=mul(coefficient,z)
        word=tuple(tuple(sorted(v)) for v in word)
        ij=tuple(ij)
        grouped[word][ij]=add(grouped[word].get(ij,(0,0)),coefficient)
    return count,{w:clean(t) for w,t in grouped.items()}

@lru_cache(maxsize=12)
def reconstruct(site,shapes,specs):
    root_work,R0=root_data(specs)
    local=[A[p] for p in shapes]
    M0={}
    mwork=0
    order=sorted(range(3),key=lambda k:(site&~(1<<k),k))
    for word in R0:
        resources=[tab.get(w,{}) for tab,w in zip(local,word)]
        if not all(resources):continue
        a,b,c=sorted(range(3),key=lambda k:len(resources[k]))
        mwork+=len(resources[a])*len(resources[b])
        assert mwork<=2_000_000
        for i,j in product(resources[a],resources[b]):
            if i&j:continue
            rem=255^(i|j)
            if rem not in resources[c]:continue
            masks=[0]*3
            masks[a],masks[b],masks[c]=i,j,rem
            bits=[i for k in order for i in range(8) if masks[k]>>i&1]
            assert sorted(bits)==list(range(8))
            z=((-1)**inv(bits),0)
            q=[]
            for data,m in zip(resources,masks):
                label,gain=data[m]
                q.append(label)
                z=mul(z,gain)
            words,msk=map(tuple,zip(*q))
            key=word,words,msk
            assert key in M0 or len(M0)<300_000
            old=M0.get(key,(0,0))
            value=add(old,z)
            if any(value):M0[key]=value
            else:M0.pop(key,None)
    occupied_words={k[0] for k in M0}
    R1={(w,idx):z for w in occupied_words for idx,z in R0[w].items()}
    assert len(R1)<=300_000
    return root_work,mwork,M0,R1

codes=(103607566400,1261652672530)
start,stop=map(int,sys.argv[1:])
totals=[0,0]
for c,side,site in product(range(start,stop),range(2),range(8)):
    occ=occupancy(codes[side])
    specs=tuple((k,n,states[c].get((side,site,k),(0,0))) for k,n in enumerate(occ[site]) if n)
    shapes=[]
    for k in range(3):
        u,v=sorted((site,site^(1<<k)))
        a,b=(sum(occ[x])-occ[x][k] for x in (u,v))
        p=(a,b,plans[c][side,u,k],plans[c][side,v,k])
        shapes.append((patterns[p],int(v==site)))
    nw,mw,actualM,actualC=reconstruct(site,tuple(shapes),specs)
    expected=[]
    for suffix,num in (('mask',3),('root',2)):
        tab={}
        for l in Path(f'SPLIT/site/{c}-{side}-{site}-{suffix}.tsv').open():
            *attrs,r,s=l.split('\t')
            assert len(attrs)==num
            key=tuple(map(parse,attrs))
            assert key not in tab
            tab[key]=F(r),F(s)
        expected.append(tab)
    assert (actualM,actualC)==tuple(expected),(c,side,site,len(actualM),len(actualC),list(map(len,expected)))
    totals[0]+=len(actualM);totals[1]+=len(actualC)
    print(c,side,site,'root products',nw,'mask trials',mw,'M rows',len(actualM),'C rows',len(actualC),flush=True)
print('exact split totals',*totals)
