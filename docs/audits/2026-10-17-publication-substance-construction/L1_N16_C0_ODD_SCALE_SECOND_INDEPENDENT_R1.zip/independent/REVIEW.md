# Independent second odd-root scale-up review

**ACCEPT** original representative `(103607566400,1261652672530)` at
weight 96. The exact signed source-normalized value is
`2622337373666858908717529296875/649037107316853453566312041152512`.
Its weighted increment is
`7867012121000576726152587890625/20282409603651670423947251286016`.
Subtracting this one verified row leaves **9,641 unresolved orbits
and 830,631 labels**. Full original c0 remains open.

The continuity check was fresh at entry and final readback. The clean
checkpoint `af143bfd6f4b2f7cf2b7412482101109efc79101` matched its tracked
upstream. I verified all 80 author archive entries, 43 original raw-edge
entries, 577 projected factor and alias entries, and both preceding
review and residual manifests. The checkpoint copy of the author
manifest matches the frozen input. The exact residual extracted from
the accepted first scale-up archive matches the intake copy byte for
byte. It contains this representative exactly once at weight 96.
Neither of the previous two accepted representatives remains there.

## Original support and normalization

I reapplied the two-chirality projection to the original occupations
and enumerated all 1,048,576 projected tuples. The independent
temporal singlet checks, minimum spatial load and empty-anchor
equalities, and combined center parity leave exactly 28 states.
These are the 14 frozen representative rows and their chiral flips,
with no pair duplication or fixed point. The 672 retained
anchor-plan rows match. The accepted original gamma3 change of
variables swaps the two chiral labels, preserves the filled local
Grassmann tops and Haar measure, and contributes a minus sign for
each of the 32 original EHC insertions. Thus each computed value
has one equal signed partner.

I checked the original 512 quarter-stripped coframe rows from the
literal source. An EHC term uses two coframes and the unnormalized
spatial tables strip each quarter, so the original powers give the
common divisor 4⁶⁴. The local reduction of the two curvature orders
and two complementary coframe orders cancels the separate action
prefactor 1/4. All 768 canonical folding checks, including the
diagonal internal terms, agree. The original multiplicities are
30 zeros, ten ones, two twos and six threes, with factorial
`(2!)²(3!)⁶=186624`. The spatial axis sums are (12,0,4) and
(4,4,8). Both world epsilon products and both cross-site wedge signs
are positive. The independent exact sign/layout controls reproduce
64 explicit generator layouts per layer. The site masks keep the
nontrivial local wedge signs throughout.

## Proportional edges and split site factors

For each endpoint, an alias map takes an original word/mask key x to
a representative y with an exact nonzero Gaussian multiplier g(x).
The reduced edge keeps both matrix-anchor index groups unchanged.
Applying the two projections in order gives the pointwise relation

`E(x0,x1,O) = g0(x0) g1(x1) Ered(y0,y1,O)`,

where O denotes all original representation matrix indices. The
verification expands both alias preimages for every reduced row.
It checks exact coefficients, disjoint keys and exhaustive original
support, including absence of new rows. This reconstructs **all
123,544 original signed rows of all 43 spatial-edge tables**. No
claim that the reduced tensors were computed by approximate
matching is used.

At a site, fix the three original coframe words. The original mask
constraint and wedge sign depend only on the three endpoint masks
and that fixed word tuple. The root factors depend on the same words
and their own representation indices. These can therefore be separate
tensors on three new internal word wires. The mask tensor sums the
original disjoint generator partitions and retains their signs.
For each partition it applies the three exact Gaussian alias gains
and stores the canonical adjacent edge keys. For fixed words the
root tensor is then multiplied by this mask tensor and summed over
the original words. This recovers the original full site constraint.
Terms with a zero accumulated mask contribute no root factor.

The reviewer rebuilt all **448 split factors** independently from
the root Fourier values, original endpoint alias domains and
site-by-site generator inversion counts. Every one of the
2,860,624 projected mask/gain rows and 1,120,436 retained root rows
matches. Prospective root products and mask complement trials reach
207,360 and 669,824 at a site, respectively. The largest mask and
root factors have 188,992 and 92,816 rows.

The literal source independently reproduces all 1,718 nonzero
linear, quadratic and cubic Fourier coefficients in the supplied
root export, checking 4,920 full entries. Independent exact unit
quaternion integration reproduces all 121 nonzero temporal rows
from 865 candidate entries and all 1,924 nonzero spatial anchor
rows from 32,706 entries. The reviewer also checked 57 literal
signed coframe entries across all 43 unsqueezed edge patterns,
including complex targets where present. The largest prospective
literal target expansion has 1,048,576 products. The complete
production unsqueezed spatial tables are reused from their
verified inputs. This receipt checks every exact compression
row and targeted raw values rather than generating all raw
spatial-edge rows from scratch.

## Independent signed replay

Each of the 14 represented channels builds an 88-factor network on
the original wires, with two occurrences of every nontrivial
wire. The matrix factors follow the independently accepted
closed-plaquette convention. Initial row and wire cardinalities
agree with the separate frozen author receipts. The prior
independent tuple-key procedure then aggregates exactly equal
primitive Gaussian slices on full common wire tuples, applies
their exact signed gains to the peer, and performs the final
Gaussian-integer joins. Both original scales remain in each
denominator. The nine zero cases close by an empty factor after
exact transformations. No result was inferred from a code
relabelling or from the sign of another pair.

All 14 channel values match exactly, retaining two positive,
three negative, and nine zero values. See `pair-exact.tsv` for
the complete separate values. The five nonzero values are:

| Pair representative | Source-normalized signed value |
| --- | --- |
| 0 | 641365374061792544677734375/316912650057057350374175801344 |
| 1 | -9430212561620361328125/2475880078570760549798248448 |
| 2 | 30958109772071044921875/39614081257132168796771975168 |
| 3 | -122470293008056640625/4951760157141521099596496896 |
| 9 | -733381695257458282470703125/1298074214633706907132624082305024 |

The complete coefficient is twice their signed sum. The initial
network peaks at 626,457 rows spread over its factors. The largest
admitted numerical join uses 11,072 products, with 43,165 in the
largest complete numerical path. The maximum charged
quotient/histogram scan tally for a nonzero case is 26,788,004.
Prospective work and coefficient-height checks precede the
arithmetic, and the sparse insertion guards remain active.
These derived operation counts exclude original raw-edge
generation and are not a broad throughput estimate.

Only this one original coefficient is accepted here. The other
scale-up profiles fall outside this receipt. No repository,
manuscript or Lean state changed.

## Replay

Scratch links `AUTHOR` to the frozen intake, `UNSQUEEZED` to the
original edge-batch directory, `SPLIT` to the generated
projected-edge and split-site tables, `INDEPENDENT` to the
preceding original projection inputs, and `prior-coframes.tsv`
to the accepted raw source export. `residual.tsv` is extracted
from the latest accepted scale-up archive. Use science candidate
`51e7c745e` for literal controls.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 support.py > support.out
PYTHONDONTWRITEBYTECODE=1 python3 moments.py > moments.out
PYTHONDONTWRITEBYTECODE=1 python3 edge-reconstruct.py > edge-reconstruct.out
PYTHONDONTWRITEBYTECODE=1 python3 edge-control.py > edge-control.out
PYTHONDONTWRITEBYTECODE=1 python3 site-reconstruct.py 0 7 > site-0.out
PYTHONDONTWRITEBYTECODE=1 python3 site-reconstruct.py 7 14 > site-7.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" root-rebuild.py > root-rebuild.out
PYTHONPATH="$SCIENCE_CHECKOUT" PYTHONDONTWRITEBYTECODE=1 "$REPO_PYTHON" normalization.py > normalization.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py 0 1 2 3 > cases-0.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py 4 5 6 7 > cases-4.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py 8 9 10 > cases-8.out
PYTHONDONTWRITEBYTECODE=1 python3 replay.py 11 12 13 > cases-11.out
python3 verify.py > verification.out
shasum -a 256 -c manifest.sha256
```
