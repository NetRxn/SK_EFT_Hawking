from collections import Counter
from fractions import Fraction as F
from pathlib import Path

K=(103607566400,1261652672530,96)
residual=[tuple(map(int,l.split())) for l in Path('residual.tsv').read_text().splitlines()]
assert len(residual)==len(set(residual))==9642 and sum(w for a,b,w in residual)==830727
assert [r for r in residual if r[:2]==K[:2]]==[K]
assert not any(r[:2] in ((103607566400,1256282136720),(103607566400,1256282652690)) for r in residual)
values={}
meta={}
limits=[]
zero={}
joins={}
for shard in (0,4,8,11):
    for l in Path(f'cases-{shard}.out').read_text().splitlines():
        p=l.split()
        if p[0]=='case':
            j,n,w,rows=map(int,(p[1],p[3],p[5],p[8]))
            assert n==88 and j not in meta
            meta[j]=w,rows
            latest=j
            frozen=Path(f'AUTHOR/author/split-{j}.out').read_text().splitlines()[0].split()
            assert (j,n,w,rows)==tuple(map(int,(frozen[1],frozen[4],frozen[6],frozen[9])))
        elif p[0]=='EXACT':
            assert int(p[1])==latest and latest not in values
            values[latest]=F(p[2])
        elif p[0]=='stats':
            limits.append(tuple(map(int,(p[4],p[7],p[9],p[11]))))
        elif p[0]=='join':
            a,b,d=int(p[2]),int(p[3]),int(p[5])
            last=joins.get(latest,(0,0,0))
            joins[latest]=max(last[0],a),max(last[1],b),d
        elif p[:2]==['empty','quotient']:
            assert latest not in zero
            zero[latest]=l
assert set(values)==set(meta)==set(range(14))
assert len(limits)==5 and {j for j,z in values.items() if not z}==set(zero)
frozen={int(i):F(z) for i,z in (l.split() for l in Path('AUTHOR/author/pair-values.tsv').read_text().splitlines())}
assert values==frozen
q=Counter((z>0)-(z<0) for z in values.values())
assert q=={1:2,-1:3,0:9}
print('pair signs',q)
print('maximum signed nonzero factor / matched join / cumulative / scans',*[max(c) for c in zip(*limits)])
print('maximum initial resident rows',max(v for w,v in meta.values()))
print('also maximum over numerical joins (including zero cases)',*[max(c) for c in zip(*joins.values())])
scale=2*sum(values.values())
a,b,w,z=Path('AUTHOR/author-exact.tsv').read_text().split()
assert scale==F(z) and tuple(map(int,(a,b,w)))==K
print('exact normalized signed representative',scale)
print('weighted exact contribution',scale*K[2])
left=[r for r in residual if r!=K]
assert len(left)==9641 and sum(r[2] for r in left)==830631
print('residual after exactly one subtraction',len(left),sum(r[2] for r in left))
Path('reviewed-exact.tsv').write_text('\t'.join(map(str,(*K,scale)))+'\n')
Path('pair-exact.tsv').write_text(''.join(f'{j}\t{values[j]}\n' for j in sorted(values)))
