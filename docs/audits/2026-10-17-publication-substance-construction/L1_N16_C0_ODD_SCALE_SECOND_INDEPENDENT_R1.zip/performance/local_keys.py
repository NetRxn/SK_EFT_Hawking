from ast import literal_eval
from collections import Counter,defaultdict
from itertools import product
from pathlib import Path
from sys import argv

def keys(directory,codes):
    roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
    occ=[[roster[(code>>(6*x))&63] for x in range(8)] for code in codes]
    states=defaultdict(dict)
    for row in (directory/'states.tsv').read_text().splitlines():
        case,t,x,k,p,q=map(int,row.split())
        states[case][t,x,k]=p,q
    anchor={}
    for row in (directory/'anchor-plan.tsv').read_text().splitlines():
        case,t,x,k,*shape=map(int,row.split())
        anchor[case,t,x,k]=tuple(shape)
    out={}
    for case,state in sorted(states.items()):
        for t,m in enumerate(occ):
            for x,row in enumerate(m):
                ordering=tuple(sorted(range(3),key=lambda k:(min(x,x^(1<<k)),k)))
                factors=[]
                for k in range(3):
                    u,v=sorted((x,x^(1<<k)))
                    a,b=(sum(m[y])-m[y][k] for y in (u,v))
                    factors.append((a,b,anchor[case,t,u,k],anchor[case,t,v,k],int(x==v)))
                channel=tuple(state.get((t,x,k),(0,0)) for k in range(3))
                out[case,t,x]=(row,channel,ordering,tuple(factors))
    return out

sets=[]
for directory in map(Path,argv[1:]):
    a,b=map(int,directory.name.removesuffix('-tiled').split('-'))
    k=keys(directory,(a,b))
    n=len(k); c=Counter(k.values())
    print(a,b,'sites',n,'distinct',len(c),'reuse opportunities',n-len(c),'max reuse',max(c.values()))
    ready=directory/'site'
    if ready.is_dir():
        previous={}
        repeats=0
        for ident,key in k.items():
            f=ready/('-'.join(map(str,ident))+'.tsv')
            if not f.is_file():continue
            if f.stat().st_size==0:continue
            old=previous.setdefault(key,f)
            if old!=f:
                assert old.read_bytes()==f.read_bytes(),(old,f)
                repeats+=1
        print('completed equal-key byte checks',repeats)
    sets.extend(k.values())
print('cross-shape totals',len(sets),len(set(sets)))
