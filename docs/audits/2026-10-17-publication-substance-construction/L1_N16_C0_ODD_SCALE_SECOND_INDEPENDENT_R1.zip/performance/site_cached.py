from ast import literal_eval
from collections import defaultdict
from fractions import Fraction
from itertools import product
from math import prod
from pathlib import Path
import sys

base=Path(sys.argv[1])
CAP=2_000_000
roster=[p for p in product(range(5),repeat=3) if sum(p)<=4]
occupations=[[roster[(code>>(6*x))&63] for x in range(8)] for code in tuple(map(int,__import__('os').environ['L1_PROFILE_CODES'].split(',')))]
states=defaultdict(dict)
for line in (base/'states.tsv').read_text().splitlines():
    case,t,x,k,p,q=map(int,line.split())
    states[case][t,x,k]=p,q
spectra=defaultdict(lambda: defaultdict(list))
for line in (base/'root.tsv').read_text().splitlines():
    power,P,Q,left,right,i,j,r,n=line.split('\t')
    spectra[int(power),int(left),int(right)][literal_eval(P),literal_eval(Q)].append((int(i),int(j),Fraction(r),Fraction(n)))
moments={}
for i,line in enumerate(x for x in Path('edge-plan.out').read_text().splitlines() if x.startswith('pattern ')):
    text=line.removeprefix('pattern ')
    pattern=literal_eval(text[:text.rindex(')')+1])
    table=[defaultdict(set),defaultdict(set)]
    for line in Path(f'edge-batch/{i:02}.tsv').open():
        first,second,mask,*_=line.split('\t')
        mask=int(mask)
        table[0][literal_eval(first)].add(mask&255)
        table[1][literal_eval(second)].add(mask>>8)
    moments[pattern]=table
shapes={}
for line in (base/'anchor-plan.tsv').read_text().splitlines():
    case,t,x,k,*value=map(int,line.split())
    shapes[case,t,x,k]=tuple(value)

def wedge(a,b):
    return -1 if sum((b&((1<<i)-1)).bit_count() for i in range(8) if a>>i&1)%2 else 1

out=Path("site")
out.mkdir()
cache={}
for case,state in sorted(states.items()):
    for t,m in enumerate(occupations):
        for x,occupation in enumerate(m):
            edge_order=sorted(range(3),key=lambda k:(min(x,x^(1<<k)),k))
            sets=[]
            incident=[]
            for k in range(3):
                y=x^(1<<k)
                u,v=sorted((x,y))
                u_load=sum(m[u])-m[u][k]
                v_load=sum(m[v])-m[v][k]
                key=u_load,v_load,shapes[case,t,u,k],shapes[case,t,v,k]
                sets.append(moments[key][int(x==v)])
                incident.append((key,int(x==v)))
            active=[(k,p,state.get((t,x,k),(0,0))) for k,p in enumerate(occupation) if p]
            slot=tuple(occupation),tuple(active),tuple(edge_order),tuple(incident)
            destination=out/f'{case}-{t}-{x}.tsv'
            if slot in cache:
                destination.symlink_to(cache[slot].name)
                print(case,t,x,'reused',cache[slot].name,flush=True)
                continue
            alternatives=[sorted(spectra[p,*b]) for k,p,b in active]
            words=defaultdict(list)
            for reps in product(*alternatives):
                word=[[],[],[]]
                for (k,p,_),(a,b) in zip(active,reps):
                    j,h=[i for i in range(3) if i!=k]
                    word[j].extend(a);word[h].extend(b)
                words[tuple(tuple(sorted(a)) for a in word)].append(reps)
            matched=0; work=0; matrix_work=0
            plans=[]
            for word in sorted(words):
                pools=[sets[k].get(w,()) for k,w in enumerate(word)]
                if not all(pools):continue
                order=sorted(range(3),key=lambda k:len(pools[k]))
                u,v,z=order
                work+=len(pools[u])*len(pools[v])
                if work>CAP:raise RuntimeError((case,t,x,work))
                for a,b in product(pools[u],pools[v]):
                    if a&b:continue
                    if (255^(a|b)) in pools[z]:
                        matched+=1
                        masks=[0,0,0]
                        masks[u],masks[v],masks[z]=a,b,255^(a|b)
                        phase=1
                        used=0
                        for k in edge_order:
                            phase*=wedge(used,masks[k])
                            used|=masks[k]
                        assert used==255
                        matrix_plans=[tuple(spectra[p,*label][w] for (_,p,label),w in zip(active,reps)) for reps in words[word]]
                        matrix_work+=sum(prod(map(len,q)) for q in matrix_plans)
                        if matrix_work>CAP:raise RuntimeError(('matrix product cap',case,t,x,matrix_work))
                        plans.append((word,tuple(masks),phase,matrix_plans))
            result={}
            for word,masks,phase,matrix_plans in plans:
                for rows in matrix_plans:
                    for local in product(*rows):
                        r,n=Fraction(phase),Fraction(0)
                        indices=[]
                        for i,j,c,d in local:
                            r,n=r*c-n*d,r*d+n*c
                            indices.extend((i,j))
                        key=word,masks,tuple(indices)
                        a,b=result.get(key,(Fraction(0),Fraction(0)))
                        value=(a+r,b+n)
                        if any(value):result[key]=value
                        else:result.pop(key,None)
            with destination.open('w') as dest:
                for key,(r,n) in sorted(result.items()):
                    print(*key,r,n,sep='\t',file=dest)
            cache[slot]=destination
            print(case,t,x,'words',len(words),'planned',work,'valid local supports',matched,'matrix choices',matrix_work,'nonzero signed rows',len(result))
