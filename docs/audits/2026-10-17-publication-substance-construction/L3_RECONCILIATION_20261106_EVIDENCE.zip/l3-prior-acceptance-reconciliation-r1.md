# Paper27 historical acceptance / current L3 reconciliation, r1

Read-only enabling evidence for ROOT. L1 remains lead. No repository edits, tests, builds, compilation, native Lean/LSP/slots, controller, dependency repair, Git mutation, or closure writer execution. This report and its JSON companion are evidence snapshots, not a routing ledger. Original four-laws and physical regime-selection scope is retained. ROOT is sole notebook writer.

## Exact source populations and authority

Initial required continuity check returned `fresh=true, changed=[]`. Assigned delivery HEAD is `f144749d795f904e563a83c869b0dee27bdbbd99`; main baseline is `ce194cdc4bf939b108c17edc9530a7f0a14565f9`; publication checkpoint is `1805e33581cb81229e8568c450875e454d0afdd9`. Git object comparisons show identical bytes at all three for:

- `lean/SKEFTHawking/BHThermodynamicsFourLaws.lean`: SHA256 `44e8925fab13fb37768cad8bcb980cd4e4e1233209de25d605cc14a1d62d49e7`.
- `papers/L3/bundle_metadata.json`: `5a2d421686eb87ee05f1d3e1c8318f8cfc80bb3011cdd7257d1b5b6dd9c4e079`.
- `papers/L3/paper_draft.tex`: `6774386e692d9fb6e94589f28c7bd33e0c953f1fc8f89fb529b0248a7add362c`.
- `papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex`: `cfd2cb4515b85590deab415d551f4f587ee49ab0f846f19a9b22a3f1528b4bb3`.

JSON contains all comparison hashes, immutable refs, actual declaration records, original finding verifiers, and exact current canonical planner groups from `/tmp/l1-main-current-plan.json`. That planner input, not the older publication branch queue or a replacement ledger, governs this reconciliation. Priority evidence is the existing `docs/audits/2026-10-17-publication-substance-construction/REPAIR_DISPOSITION_MAP.md` in the publication checkout: L1 -> L3 -> D3. Read current primary notebook, Phase6a roadmap, CLAUDE, pipeline, claims-reviewer role, charter, mapping and review anchors.

A separate research population is `codex/publication-l3-crossing-20261103` at `f905a2873a32269c3d21651abb2b64825a212c3d`. Live GitHub [PR114](https://github.com/NetRxn/SK_EFT_Hawking/pull/114) confirms exact head, draft/open/unmerged, stacked on `codex/publication-njl-integration-20261019` at `115e001221cf143578b8d8c503caac61149492c8`. Live [PR112](https://github.com/NetRxn/SK_EFT_Hawking/pull/112) is separately draft/open/unmerged at `a34eb6b08fb85e43f3d5e5071f45db6a8e7ebf57`, base main `ce194cdc4`. PR112's body still describes its earlier crossing-only evidence while current head also contains the JETP repair; inspect actual closure/source tree, not that abbreviated body alone.

Local ancestry: main ce194 is ancestor of f144 and f905; their merge base is ce194. Neither f144, publication1805, nor focused a34 is ancestor of f905. Local research head and remote-tracking ref agree with live PR114. No descendant of f905 was observed in local refs. Fetching f905 through GitHub confirms the two added actual geometry theorems and changelog. No fetch/update/mutation of local refs occurred. Branch absence is not scientific absence, and the two L3 packages must not be flattened or discarded.

## What the old acceptance actually accepted

`papers/AutomatedReviews/2026-04-27-0100-internal-adversarial-reinvocation-4-final/paper27_bh_thermodynamics_four_laws.md` genuinely records SUBMISSION-READY after four passes, zero blocking/required items, accepted reduced structures, explicit deferred zeroth/third laws, parameter/citation repairs, and remaining advisory redundant fields/wrapper/unused references. It accepted a conditional sign/classification development with disclosed limitations, not completed physical four-laws derivations. Its statement that the fresh sweep found no substance issue was later challenged by actual source-body/primary-source review. Preserve the dated verdict and its evidence rather than deleting it or treating it as a permanent certificate.

The L3 lift later had its own May1 round1 defects and round2 GREEN, recorded in `papers/AutomatedReviews/2026-05-01-{L3,T1900-L3}-bundle-stage13/L3.md` and current metadata. These are separate L3 scoped acceptance events. They do not automatically close every differently minted review ID.

The August15 Stage10 redraft replaced the manuscript and explicitly voided previous stage verdicts in `papers/L3/bundle_metadata.json:notes`. Current stage9/10/13 are pending, `stage13_redo_required=true`, `freshness_stale=true`, readiness RED. The historical green summaries remain preserved in that same JSON. Strategy `docs/PAPER_STRATEGY.md:231–241,316–331` and mapping `docs/PAPER_DRAFT_MAPPING.md:49,185–186` still say Paper27 submission-ready and promise four laws; these prose entries are not present acceptance evidence. The retained objective is to build the science, not silently accept the redraft's narrower scope or finding5.4's retitle option.

Current `papers/L3/claims_review.json` remains an older review; no new sentence walk was performed here. Earlier findings extraction `/tmp/l3-readiness-findings-20261105-r1.json` recorded Paper27 round3 grouped CLOSED/PASS headings and May1 round2 FIXED headings as open advisory IDs. That is historical extractor evidence, not a freshly recomputed population. Use the existing closer per actual ID and Verify; no blanket historical closure or blanket live-science-defect count follows.

## Actual current-main theorem and computation backing

Read actual bodies and types, not symbol searches alone. Main/f144/publication1805 source is the same:

| Object | Actual mathematical content |
|---|---|
| `M_c`, `M_c_pos`, `classify_*_iff` | Positive defined threshold `N_f Λ/(12πα)` and exact `>`, `<`, `=` classifier equivalences. No physical mass-dynamics branch selection. |
| `T_H_schwarzschild` and monotonicity | `1/(8πM)`, positive for M>0 and strictly decreasing in M. |
| `T_H_acoustic_evolution` and monotonicity | `T0 exp(-t/τ)`, positive and strictly decreasing for positive T0,τ. Representative exponential, not Balbinot's actual affine local law or full trajectory. |
| `H_RegimePartition` (source501–507) | Includes *assumed* upper/lower rate signs and `delta=(alpha-1)Λ`. |
| `regime_partition_criterion` (525–536) | Rewrites classifier iff and applies `H.evap_dT_dt_above/below`. No chain-rule derivative or monotonicity dependency. Valid conditional transport. |
| `ADWSecondLaw` (471–473) | Scalar sign input `0≤entropy_div` and positive area. No physical current/divergence identification. |
| `FourLaws_*` (595–633) | Coupling positivity, scalar ADWSecondLaw, supplied evaporation sign; acoustic bundle also delta ansatz. No zeroth/third fields and no differential first law in those structures. |
| `delta_ADW_nonzero_iff_alpha_ADW_ne_one` | Uses the bundle's actual ansatz to prove `delta≠0 iff alpha≠1`. |
| `falsifier_alpha_ADW_dependence` | Standalone positivity of `(alpha-1)Λ` when alpha>1. Main metadata overstates it as constraining bundle delta. |
| `falsifier_third_law_form` | Generic incompatibility of unbounded approach time with a bounded alternative, not an affine-time construction or physical Israel/Reall proof. |
| Wave3 bridge | Actually imports BHEntropyMicroscopic and proves positive Kaul–Majumdar entropy at `A=4G exp(2)`; that anchor is not shown to equal the actual extremal mass/horizon. |

`lean/lean_deps.json` agrees with these types and dependencies. Source imports are Basic, LinearizedEFE, BHEntropyMicroscopic, Mathlib. The summary True marker remains non-load-bearing. No fresh native axiom/build claim is made here.

Actual numerical producers are `src/bh_thermodynamics/{regime_classifier,acoustic_evolution,four_laws_data,falsifier_checks}.py`, `src/core/formulas.py:G_N_sakharov/G_N_emergent`, canonical visualizations and figure specs. The domain package implements M_c, exponential/inverse profiles and delta directly; formula centralization/provenance must be assessed at integration without mistaking code duplication for new physical backing. `four_laws_data.py` still defaults zeroth/third check booleans true; runtime `is_valid()` cannot certify physical laws. `regime_classifier.Regime` still calls boundary a temperature maximum/smooth dT/dM crossing, the existing4.1 issue. Main `HYPOTHESIS_REGISTRY['H_RegimePartition']` at constants4126 describes GL entropy-current content, while actual structure501–507 carries threshold/sign/delta fields; source propagation must reconcile this mismatch under existing process, not accept registry prose as a theorem statement.

`BH_THERMODYNAMICS_PARAMS` constants6050ff identifies M_C_PREFACTOR12 and α range0.1–10 as dimensional/natural choices, T0=1 as normalization, χ range0.1–10 as inherited natural range. None is a measured physical calibration selecting an ADW crossover. No current-main declaration makes the original threshold a physical derivation.

Primary sources were read directly from the shared held directory `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/Lit-Search/Phase-6a/primary-sources/`; this delivery checkout does not itself expose those relative files. Balbinot `Balbinot2005PRD.source/acusticpap.tex:540,986–1023` fixes constant c, gives affine Tsonic coefficient563/(720π), calls all-time behavior an extrapolation, and explicitly defers BEC variable c. JK `JacobsonKoike2002.source/bhbu.tex:597–616` distinguishes wall/Killing temperature from superfluid-frame Doppler temperature; JV `JacobsonVolovik1998.source/EventHorIn3He13Unix.tex:707–713` explicitly cools toward extremality. Thus corrected citations1.1/1.2 are real repairs, while frame-specific D3 finding4.1 still matters. Primary-source custody is read-only here; no external publication/source-rule claim was inferred from web snippets.

## Existing findings, owners and exact closure populations

All L3 IDs below have prefix `review:2026-08-15-l3-stage10-redraft:L3:` and owning review `papers/AutomatedReviews/2026-08-15-l3-stage10-redraft/L3.md`; JSON preserves original exact Verify strings and closure records at each ref. Cross-consumer IDs belong to `papers/AutomatedReviews/2026-08-15-d3-stage10-redraft/D3.md`.

| L3 suffix | Original obligation | main/f144/1805 ledger | research f905 ledger | focused a34 ledger |
|---|---|---|---|---|
|1.1/1.2|JV cooling and constant-c scope|fixed|fixed|fixed|
|1.3|Correct Balbinot contrast JETP identity|no closure|fixed|fixed|
|2.1|Actual four-law content|no closure|no closure|no closure|
|2.2|Derived branch signs|no closure|no closure; real profile proofs exist|no closure|
|2.3|Match alpha falsifier claim|no closure|fixed|no closure|
|2.4|Proved emergent cutoff identity|no closure|no closure; real identity exists|no closure|
|2.5|GL/NEC attribution|no closure|fixed|no closure|
|3.1/3.2|Figure labels/crossing|no closure|fixed|3.2 fixed only|
|4.1|Python crossover gloss|no closure|no closure|no closure|
|5.1–5.4|Abstract, registration, used_in, charter|no closure|no closure|no closure|

These are directly read ledger records, not rerun verification or a new canonical aggregate. Current actual planner queues2.1/2.2/2.5,2.3,2.4,1.3,5.1–5.4 plus D3:3.1 criterion metadata and D3:4.1 frame attribution in the selected groups; see JSON for actual lanes, files and deferral strings. Planner `no free wtN slot (0 exist)` is a planning snapshot, not an independently checked live capacity census and not authority to acquire/reset anything. The planner omits some source obligations from its displayed groups; that is not closure.

Research2.3 fixed through `bb44c4692` by correcting metadata to standalone positivity and preserving the separate delta equivalence; source theorem itself need not be rewritten to mention H. Existing2.3 Verify was correspondingly reconciled. Similarly2.2's old verifier hardcodes `regime_partition_criterion` and dependency `T_H_schwarzschild_strict_decreasing`; a stronger direct derivative criterion need not depend on that name. Reconcile its Verify through the established reviewed amendment/closure process, preserving original science rather than making a lexical test pass.2.1's current verifier demanding *either* zeroth *or* third field is only a thin mechanical witness; it is not full original four-laws acceptance.

## Reusable construction branch: completed source science versus remaining acceptance

The prior existing reconciliation `docs/audits/2026-10-17-publication-substance-construction/L3_READINESS_RECONCILIATION_20261105.md` already identifies these exact packages. Read it and the current map rather than create duplicate assignments. Actual bodies from f905 Git objects and branch `papers/L3/change_log.md` were inspected. Primary notebook1436–1463 records independent acceptance, pinned scratch elaboration and remote readback for the newest geometry increments. Stored `/tmp/l3-profile-axioms.iJNe0C/axioms.out` contains standard-axiom reports for all three profile theorem roots; `/tmp/l3_ingoing_compatibility_r3.log` contains linter warnings, not a new run. These are prior local/source evidence, not this review's full native qualification.

| Commit/package | Strongest actual result | Boundary |
|---|---|---|
|5d2d829ea cutoff|`G_N_emerg_eval_mul_M_c_eq_inv_cutoff : G_emerg*M_c=1/Λ`; bare identity keeps α denominator; equality iff α=1|Algebraic identity, not physical crossover selection|
|b1a90e49c profiles;3ef2dea6c/680c420a7 source scope|`schwarzschild_profile_deriv`, `balbinotAffine_deriv`, `regime_partition_profile_criterion` genuinely derive HasDerivAt and strict signs. Upper branch supplies mass(t)=b.M, HasDerivAt mass dM, dM<0. Lower uses positive c,κ,A0,ε, short-time budget, positive T.|Not merely projection; physical supplied rate must equal selected derivative; no BEC/full late-time proof. Affine+remainder cooling needs R'<T0Γ.|
|d006634b1 fixed-G law|ExactSolutions computes dA along geometric mass G*M and proves dM=κ dA/(8πG); varying-G control adds M dG/G|A genuine first-law component. No charged/rotating/substrate-work or acoustic law; FourLaws fields remain old.|
|811447e35/66abb2050 exterior/horizon|Radial vacuum+asymptotic mass tail uniquely fixes lapse; actual Koszul null-generator nonaffinity half-lapse slope on regular ingoing patch|Conditional geometry, not microscopic ADW exterior selection or general zeroth-law derivation|
|bbe951706/e3ef01748/33031e63c Ricci/ADM|Full coordinate Ricci vacuum from local reduced equation; actual Cartesian finite-sphere flux, ADM limit under tail, static positive-lapse spatial pullback|Physical mass normalization/matching remain; no general ADM coordinate invariance claim|
|46a26b23e/4aaa48636/d31de80e9 variational chain|Ricci-flat densitized Ricci-square variation zero; actual Palatini current; actual EH local derivative and integrated box stationarity|Differentiability, mixed partials, domination, paired-face premises still inputs; Euler/renormalized cosmological/microscopic ADW action matching open|
|b89377dfe/9caaca0b0/f905a2873 actual background|Actual inverse/density compatibility; actual EH chart Ricci=ingoing Ricci=0 under local vacuum; base symmetry; continuity gives eventual nondegeneracy at each regular point including lapse zero|Does not instantiate all `RegularBase`/box fields or provide uniform parameter neighborhood over a box|

Source reachability matters: f905 BHThermodynamicsFourLaws imports remain Basic/LinearizedEFE/BHEntropyMicroscopic/Mathlib. New profile helpers are within that imported module; ExactSolutions imports RiemannCoordinate and RiemannDifferentialBianchi and carries the actual ingoing/EH links. The four-law bundle does not consume the ExactSolutions first-law theorem as a new field. `RiemannDifferentialBianchi.RegularBase` has explicit paramWeight,paramInverse,paramConnection,commute,spatialWeight,spatialInverse,spatialDelta and compatibility/flatness fields; f905 discharges some actual geometric components without constructing the whole witness. `eh_metric_box_stationary` additionally requires current continuity/Frechet derivatives, integrability, paired face traces, and dominated differentiation for the actual density. Hence latest theorem bodies support substantial conditional enablers, not full2.1 closure. No later successor was observed; do not redispatch already proved Ricci/base symmetry/nondegeneracy.

Neither research nor main committed `lean_deps.json` includes the new profile/cutoff/nondegeneracy roots when directly inspected. This does not negate source/local elaboration; it means extraction/full-candidate qualification remains owed. Do not claim those new roots are current registry-certified based on their presence in source or commit messages.

For acoustic entropy, actual existing types were read: `GloriosoLiu.entropy_current_exists` constructs a Noether-density current and first-order action/KMS witness; `CrooksAnalogHawking.noetherEntropyDensity_nonneg_of_SKEFTAxioms` proves density nonnegativity; `GloriosoLiu.LocalSecondLaw.divergence` ignores its current argument and returns Im L. Its existential nonnegative-divergence theorem uses reflection positivity and zeroEntropyCurrent. These are reusable conditional ingredients, not identification with physical nozzle entropy-flux divergence. Existing `/tmp/l3_entropy_bridge_packet.md`, map and prior independent controls distinguish positive outgoing thermal boundary entropy flux from local production and moving-cut accumulation. The retained on-shell construction must identify the actual density/current or evolving reduced state, physical divergence, transport/boundary conventions and sign. A steady positive outward flux can have zero bulk production. Stress two-point data alone need not determine entropy.

Discovery limit: no authorized live LSP server is available in this assignment. Earlier recorded `lean_local_search` hit the ADR008 no-lease gate; no new attempt or workaround here. Source/type/import/history search is useful but is not a complete absence audit. Any future proof assignment must first search by statement/type in the admitted pinned consumer context. Do not label the required current/analytic constructor globally unimplemented on this evidence.

## Next coherent package and D3 consumer boundary

Keep the original process and priorities. The next L3 delivery package should deliberately compose the existing reviewed L3 source and required reviewed predecessors on the actual main delivery base; retain PR112/PR114 ancestry and receipts. First reconcile exact physical/prose/producer scope and qualification prerequisites, then authoritative source build/extraction and existing gates, independent source/render/claims review, original substantive finding verifiers and canonical closure writer. The constructor frontier is the remaining analytic metric-path/box instantiation; that is already identified work, not a request here to spawn a new proof task. Original2.1 still requires physical four-laws content, ADW action/exterior/mass matching, acoustic energy/entropy balance, actual zeroth/third law content and physical branch selection, beyond these conditional constructions.

Bring existing1.3/2.3/2.5/3.1/3.2 repairs/closures with their exact scope into a qualified tree; reconcile2.2/2.4 proof verifiers and close only with actual exact-candidate extracted evidence. Resolve Python/registry/parameter/source propagation, all appropriate claim chains, current figure and PDF review, fresh Stage9/10 then Stage13; historical compile or green does not satisfy these.600-character abstract ceiling is explicitly unverified metadata; venue conformance needs its primary authority. No new infrastructure, gate waiver, title reduction or operator exemption is proposed.

D3 mapped consumption is `docs/PAPER_DRAFT_MAPPING.md:49` (L3 + D3§8 + F§6), D3 source roster154ff, strategy329–331 and claims anchors140/146/960ff. Actual D3 manuscript1395ff/1483ff consumes the same conditional criterion, first-law coupling positivity, entropy sign, delta equivalence and shared figure. Current D3 metadata's criterion-as-biconditional is original D3:3.1; actual iff belongs to classify_Schwarzschild_iff. D3:4.1 additionally owns JK frame/end-temperature attribution; F and citation registry are real consumers. D3 can consume qualified exact classifier, local profile criterion, emergent cutoff identity, fixed-G differential law and scoped geometry/ADM results with explicit assumptions once composed, but cannot inherit full four-laws or physical entropy/third-law success from old Paper27 acceptance. D3 keeps its own source/physical/stage findings. Shared figure/citation/claim propagation must cover actual D3/F/P27 producers and consumers, not merely L3 labels.

No full scientific or publication acceptance was established by this read-only reconciliation. Final continuity/head/status readback follows in JSON; any ROOT L1-only drift is returned for lead reconciliation without redoing unchanged L3 source analysis.
