# L3 primary custody reconciliation, r2

The configured primary's successful build does **not** qualify the newer f905 L3 constructions. Primary custody is clean at `4fca5970f4f4cb0b408ea33243076c72058f6e56`, branch `codex/publication-primary-custody-20261105`. Research `f905a2873a32269c3d21651abb2b64825a212c3d` is not its ancestor; their merge base is `ce194cdc4bf939b108c17edc9530a7f0a14565f9`. More decisively, actual content and the actual primary declaration index still contain the older L3 population.

Read-only follow-up for ROOT; L1 remains lead. No new proof dispatch, controller/status call, native Lean/LSP, build/test, repository helper execution, dependency/cache repair, Git mutation or repository edits. r1 MD/JSON remain byte-identical. The JSON companion preserves all source/import/root/index/receipt evidence and exact hashes.

## Stored successful epoch and its exact scope

Actual configured custody path:
`/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking`.

Read current primary HEAD/status first and re-read the primary notebook authority. Current primary status is empty. The stored epoch at its sibling `.lean-slots/epochs/public.json` is:

- `epoch_id=323eaae82597f49d8ab6fcec488d3dea03e0bab67cf57ec6a0c3a3fed81dbbb2`.
- Published `2026-11-06T00:38:11Z` for primary commit `4fca5970f4f4cb0b408ea33243076c72058f6e56`.
- Successful command `lake build SKEFTHawking.ExtractDeps`.
- Fingerprint digest `e5c844f865f261205371cba4e4ec3e384864f1c1a2fd6253a6460352e497dea7`; commit matches and all three actual file pins match: toolchain `2773c517...`, manifest `6620cd48...`, lakefile `7008b3d7...`.
- `/tmp/l1-final-custody-build-20261106.stdout` records the same complete epoch; stderr is empty. Primary notebook's November6 custody entry records controlled build54908 terminal0 and source/remote custody readback. These are stored successful execution evidence, not an execution performed by this reviewer.

The stored final status `/tmp/l1-source-package-final-slot-status-20261106.json` contains observations at `2026-11-06T00:42:41Z`, complete capacity/no conflicts, wt1 FREE, wt2 READY_TO_ABSORB at8187fc83, wt3 QUARANTINED at3505b2f8. It corroborates the preserved primary custody state and is not a fresh live capacity check or lease/admission authorization. The supplied handle7909 was not itself queried; no process/controller tool ran.

The controller's existing build implementation publishes an epoch only after the configured build command succeeds on clean committed primary. This receipt binds that source/pin population. It does not export a full native certificate to a different tree merely because individual modules are similar. No fresh certificate is inferred from source presence.

## Exact primary L3 content versus research additions

For each of the following, actual primary bytes equal actual main-delivery f144 bytes and differ from the f905 research bytes:

| Module | Primary index records | Primary differs from f905 |
|---|---:|---|
|`BHThermodynamicsFourLaws.lean`|108|yes|
|`ExactSolutions.lean`|24|yes|
|`ADMFormalism.lean`|24|yes|
|`HigherCurvatureStructure.lean`|25|yes|
|`RiemannDifferentialBianchi.lean`|18|yes|

Counts describe extracted declaration records, including generated/auxiliary entries, not authored theorem totals. JSON contains each complete record and all three exact module hashes.

The following **specified roots** are absent from both actual primary source declarations and actual primary `lean/lean_deps.json`, while their actual declarations are present in the inspected f905 source. This is a bounded population comparison, not a claim that no equivalent theorem exists anywhere:

- `BHThermodynamicsFourLaws`: new bare/emergent cutoff identities and equality control; `schwarzschild_profile_deriv`, `balbinotAffine_deriv`, `regime_partition_profile_criterion`.
- `ExactSolutions`: area-profile derivative, fixed-G first law and varying-G control; normalized exterior lapse/horizon profiles; ingoing nonaffinity and full Ricci calculation; actual EH-chart Ricci-flatness identification, background compatibility, base symmetry and pointwise eventual nondegeneracy.
- `ADMFormalism.SphericalSurface`: actual Cartesian radial flux, sphere charge, reciprocal mass limit, static metric pullback and Cartesian polar slice pullback.
- `HigherCurvatureStructure`: Ricci-square and densitized/integrated Ricci-term first-variation roots.
- `RiemannDifferentialBianchi`: new Palatini Ricci variation and actual-metric local EH/box stationarity roots.

JSON enumerates 28 exact representative roots individually; all28 are present in f905 source, zero in the primary source/index. No inference from a name-only scan is needed: the five entire construction-module source populations are demonstrably older and byte-identical to main f144, and r1 already read the differing f905 bodies/types. Primary older BHThermodynamicsFourLaws still projects assumed branch signs; FourLaws structures still carry G positivity/recorded scalar entropy sign/supplied evaporation sign. Primary ExactSolutions still has the older Schwarzschild definitions and algebraic identities, without the added differential/ingoing/EH chain.

## Actual import and extraction closure

Primary `lean/SKEFTHawking.lean` imports all five modules. Primary `lean/SKEFTHawking/ExtractDeps.lean` imports the aggregate `SKEFTHawking`, so the modules are within the successful stored build target's import scope; this is not a case of the extractor silently missing these old modules altogether.

A pure static traversal of project imports from these five roots gives38 project modules. All38 source paths resolve. Of that primary closure, exactly the five construction-module files differ from f905; the other33 corresponding f905 files match. This demonstrates a valuable shared foundation for reuse. It does not assert the full *research* closure is identical: f905 ExactSolutions adds imports of RiemannCoordinate/RiemannDifferentialBianchi, and HigherCurvatureStructure adds Curvature; full import arrays for both trees are in JSON. The source construction itself still has to be integrated and qualified through its complete actual import closure.

The actual primary declaration index contains53,530 records. Its stored source hash `lean/lean_deps.json.hash=28d4039ef3be75b6` matches an independently reproduced stdlib byte hash using the existing documented recursive-source-plus-aggregate algorithm. No extractor was executed. Thus the missing new roots are explained by the actual older indexed source population, rather than demonstrated stale extraction of already integrated f905 source. This hash check is source correspondence evidence, not a new Lean kernel acceptance.

## Reusable parts already in qualified primary custody

The exact older primary roots are present in the primary index, imported by the aggregate, and covered by the stored exact-primary build receipt:

- Positive M_c and exact classifier iff theorems.
- Positivity/strict decrease of the exponential acoustic representative and inverse-M Schwarzschild profile.
- Conditional `regime_partition_criterion` sign transport and delta-ansatz nonzero equivalence.
- The actual Kaul–Majumdar positive anchor bridge.
- Older Schwarzschild area/kappa identities on defined profiles.
- Existing GL `entropy_current_exists`, `Glorioso_Liu_local_second_law` and `noetherEntropyDensity_nonneg_of_SKEFTAxioms`, with their actual conditional/current-density scopes.

For the selected indexed roots the extracted project axiom lists are empty; core lists contain `Classical.choice`, `Quot.sound`, `propext`. JSON preserves complete actual records. These qualified older ingredients should be reused; they are not the newly derived profile signs, physical entropy-divergence identification or complete laws. The GL local divergence still returns Im L independently of its current argument, and the Noether result is density positivity. Their primary build does not turn them into a proof of the consumed physical nozzle entropy-flux divergence.

Conversely, f905's28 representative new roots remain **accepted source/prior local elaboration evidence on the research branch**, with their receipt boundaries described in unchanged r1. Primary custody323eaae does not upgrade them: they are neither integrated there nor indexed there. This check found no already-qualified primary copy of those exact additions, but it also did not search all possible equivalent APIs with an admitted live LSP. No global absence or new-proof necessity follows.

## Remaining work and continuity reconciliation

Reuse all accepted research increments and the already-qualified shared foundation. Authoritative qualification of an integrated exact source/extraction remains owed for the newer profile/cutoff/first-law/Ricci/ADM/EH/compatibility chain. The primary current source hash is coherent; this is not evidence authorizing cache/dependency repair, slot reclamation, or rebuilding unrelated older source.

The remaining *construction* boundaries stay as r1: actual analytic metric-path/RegularBase and uniform box regularity/mixed partials/domination/boundary instantiation; Euler and renormalized cosmological-term treatment; microscopic ADW exterior/action/physical mass matching; acoustic physical current/entropy balance and branch-rate identification; original full four-laws2.1. Some geometry/first-law components are already proved on f905 and must not be redispatched as missing. This report does not decide whether an equivalent next analytic helper already exists elsewhere; discovery remains incomplete without authorized type/LSP search.

At follow-up start the original continuity check returned `fresh=false, changed=[source]`. Delivery HEAD was still f144, with current ROOT L1 source/provenance/hypothesis/claims/audit updates and new R2 evidence artifacts (not merely an assumed six-file change). All four owned L3/P27 file SHA256 hashes still match r1 exactly. The static comparison deliberately uses immutable f905 and current clean primary4fca plus those unchanged owned L3 bytes; it does not read the changed L1 implementation as acceptance evidence. ROOT must reconcile this actual wider L1 change list before any new execution; no snapshot was refreshed to hide drift. r1 MD hash remains `a91cf0eaeca4d54f123a348b1902df4bc4ec4c5b7402e71cfbbc4648e3de6272`; r1 JSON remains `db8e96b1641e70ce048ca3ca936ece51c5cacde757899a81f6a2c184ae66c825`.

This resolves the primary-custody question without changing the queue, scope, charter, acceptance criteria or original obligation. L1 remains lead; no new proof dispatch or publication acceptance follows.

## Additional ancestry and integration assessment requested by ROOT

NJL base `115e001221cf143578b8d8c503caac61149492c8` **is an ancestor of f905 but is not an ancestor of primary4fca**. Neither primary4fca nor researchf905 is ancestor of the other. Both primary↔research and primary↔NJL have merge basece194. The primary/research symmetric difference is399 primary-only commits and172 research-only commits. Therefore a fast-forward of existing f905 onto current primary is unavailable. A normal ancestry-preserving merge of the whole research branch would also bring the NJL and other research ancestors absent from primary; it cannot be described as an isolated five-file proof absorption. This is an ancestry/content observation, not permission to perform that merge or a reason to retarget/reset primary.

The JSON now preserves exact name/status rosters for both:

- mergebasece194→researchf905:277 changed paths, including NJL and other predecessors;
- primary4fca→researchf905:697 differing paths, including primary-only NavierStokes/finite-process work that must be preserved. A D entry in this comparison means the file is absent in the research tree; it is emphatically not a cleanup instruction.

The L3-focused delta **above its existing NJL base115e** is19 modified paths:

```
docs/review_finding_supersessions.json
figures/fig_T_H_evolution_regime_partition.png
lean/SKEFTHawking/ADMFormalism.lean
lean/SKEFTHawking/BHThermodynamicsFourLaws.lean
lean/SKEFTHawking/ExactSolutions.lean
lean/SKEFTHawking/HigherCurvatureStructure.lean
lean/SKEFTHawking/RiemannDifferentialBianchi.lean
papers/AutomatedReviews/2026-08-15-l3-stage10-redraft/L3.md
papers/L3/append_log.json
papers/L3/bundle_metadata.json
papers/L3/change_log.md
papers/L3/figures/fig_T_H_evolution_regime_partition.png
papers/L3/paper_draft.pdf
papers/L3/paper_draft.tex
papers/L3/source_manifest.md
scripts/review_figures.py
src/core/citations.py
src/core/constants.py
src/core/visualizations.py
```

This is a source delta roster, not an instruction to copy all19 paths or transplant generated closures/index state. The37 commits after115e include two bibliography/citation-custody changes beyond the strictly named L3 result; their full oneline identities are preserved in JSON. The actual Lean addition set within this tail is the five already enumerated existing proof files; it adds no new top-level module path and needs no newly invented proof implementation.

Existing recorded process guidance is narrower than an accepted exact integration graph: the current publication `REPAIR_DISPOSITION_MAP.md` L3-preparation section calls for establishing which reviewed predecessor packages qualify against current main, then requalifying the scoped L3 candidate; it explicitly keeps PR112 scoped and preserves the broader PR114 branch. Primary notebook1935–1992 records the normal current-primary-based controlled route for the later L1 comment changes, with source applicability reconciliation and no retarget/cherry-pick/wholesale merge. No already-approved exact f905→4fca integration sequence was located in those named authority records. ROOT must choose and independently review the precise ancestry-preserving composition under the existing process, including all imported predecessor scope, before absorption. This does not require redispatching the already reviewed L3 mathematical proofs, and this report neither authorizes an alternative Git strategy nor waives controlled qualification.
