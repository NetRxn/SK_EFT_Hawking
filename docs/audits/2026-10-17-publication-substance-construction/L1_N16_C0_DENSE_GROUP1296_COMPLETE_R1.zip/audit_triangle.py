"""Independently verify the two author anchor support partitions and signed totals."""
from ast import literal_eval
from pathlib import Path
import re
from triangle_replay import CASE, DIR, BASE, N, PIN, PINS, build, file_digest, load

RECEIPT=DIR/'terminal.out'

def main():
    assert CASE in (0,1,2,3,4,6)
    replay=(DIR/'extra-replay.out').read_text()
    real,imag,den=map(int,re.search(rf'(?m)^whole original L{CASE} triangle raw (-?\d+) (-?\d+) (\d+) elapsed ',replay).groups())
    assert den==N and imag==0
    forecast_count=int(re.search(rf"(?m)^independent third anchor forecast {CASE} \d+ (\d+)$",replay)[1])
    receipt=RECEIPT.read_text()
    with (BASE/f'pass{PINS["passes"]}-result.pkl').open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==PIN
        f.seek(0)
        factors=load(f)['factors']
    with (DIR/'author-triangle-audit.tsv').open('w') as out:
        print('anchor','start','stop','triplets',sep='\t',file=out)
        for anchor,a,b in ((0,1,2),(1,0,2)):
            forecast=re.search(rf'(?m)^triangle forecast {anchor} {a} {b} (\d+) chunks (\[.*\]) seconds ',receipt)
            n=int(forecast[1])
            assert n==forecast_count
            intervals=literal_eval(forecast[2])
            X,px,py,L,R=build(factors,anchor,a,b)
            actual=idx=count=0
            assert intervals[0][0]==0
            for i,key in enumerate(X):
                count+=len(L.get(px(key),{}).keys() & R.get(py(key),{}).keys())
                lo,hi,expected=intervals[idx]
                assert count<=8_000_000
                if i+1==hi:
                    assert count==expected
                    actual+=count
                    print(anchor,lo,hi,expected,sep='\t',file=out)
                    idx+=1
                    count=0
                    if idx<len(intervals):
                        assert intervals[idx][0]==hi
            assert idx==len(intervals) and count==0 and actual==n and intervals[-1][1]==len(X)
            signed=re.search(rf'(?m)^triangle signed numerator {anchor} {a} {b} (-?\d+) (-?\d+) denominator (\d+) seconds ',receipt)
            assert tuple(map(int,signed.groups()))==(real,imag,den)
    print('independently checked both author interval covers, compatible signed products per anchor',forecast_count)
    print('both author signed sums agree with independent third anchor',real,imag,den)

if __name__=='__main__':
    main()
