from unsharded import *
from peer_pair_source import pair_checks
from time import perf_counter
from itertools import combinations,islice
from gc import collect

P=Path('unsharded-result.pkl')
HP='28896b619a18d4a17686fd3e99c81d01794381026a53bafb8ba92cbc973c9bfc'
LEADER=((6,1),(23,0),(18,0),(20,0),(8,0),(14,0),(28,0),(31,0))
MAX_STAGE=20_000_000

def relief(F,n):
    a,X,d=F[n]
    peers={j:tuple(w for w in a if w in b) for j,(b,_,_) in enumerate(F) if j!=n and set(a)&set(b)}
    order=tuple(sorted(peers))
    if len(order)<4:return candidates(F,n)
    edges=[pos(a,peers[j]) for j in order]
    sample=[tuple(pull(k,p) for p in edges) for k in islice(X,0,None,max(1,len(X)//2200))]
    marginal=[len({k[i] for k in sample}) for i in range(len(order))]
    bits=(sum(1<<i for i in range(len(order))))
    adj=lambda u:tuple(i for i in range(len(order)) if ((1<<i)&u))
    queue=set()
    active=[i for i,m in enumerate(marginal) if m>1]
    for j,k in combinations(active,2):
        placed=(1<<j)|(1<<k)
        queue.add(placed)
        linked=[]
        for n in active:
            if n in (j,k):continue
            hist=len({(r[j],r[k],r[n]) for r in sample})
            linked.append((hist,n))
        for _,i in sorted(linked)[:2]:queue.add(placed|(1<<i))
    for i in range(len(order)-1):
        mask=(1<<(i+1))-1
        if len(adj(mask))>=2 and len(adj(bits^mask))>=2:queue.add(mask)
    forecasts=[]
    for s in sorted(queue):
        t=bits^s
        x,y=adj(s),adj(t)
        if min(len(x),len(y))<2:continue
        u=len({pull(k,x) for k in sample})
        v=len({pull(k,y) for k in sample})
        if min(u,v)<4:continue
        # Reward a compact predicted full split, with both projections nonconstant.
        forecasts.append((u+v,max(u,v),-min(u,v),x,y))
    choices=[]
    seen=set()
    for *_,x,y in sorted(forecasts):
        for w in (x,y):
            sub=tuple(order[v] for v in w)
            if sub in seen:continue
            seen.add(sub)
            ids={ws for k in sub for ws in peers[k]}
            choices.append((sub,tuple(k for k in a if k in ids)))
            if len(choices)>=3:return choices
    return choices

def onefold(F,G,axes):
    A,X,d=F;B,Y,e=G
    pa,pb=[pos(ax,axes) for ax in (A,B)]
    ao=tuple(w for w in A if w not in axes); bo=tuple(w for w in B if w not in axes)
    va,vb=pos(A,ao),pos(B,bo)
    L,R=defaultdict(dict),defaultdict(dict)
    for k,z in X.items():L[pull(k,pa)][pull(k,va)]=z
    for k,z in Y.items():R[pull(k,pb)][pull(k,vb)]=z
    same=L.keys()&R.keys()
    groups={};assignment={}
    outX={};outY={}
    for q in sorted(same):
        tails,zs=zip(*sorted(L[q].items()))
        prims,scale=prim(zs)
        assert tuple(mul(v,scale) for v in prims)==zs
        signature=tails,prims
        code=groups.setdefault(signature,q)
        assignment[q]=(code,scale)
        if code==q:outX.update({q+k:z for k,z in zip(tails,prims,strict=True)})
    if len(groups)==len(L)==len(R):return F,G,0
    for q,(code,s) in assignment.items():
        for tail,z in R[q].items():
            new=code+tail
            j,k=outY.get(new,(0,0))
            x,y=mul(z,s)
            if x+j or y+k:outY[new]=x+j,y+k
            else:outY.pop(new,None)
    return (axes+ao,outX,d),(axes+bo,outY,e),len(same)-len(groups)

def guarded(A,B,peers,count,deadline):
    a,X,d=A;b,Y,e=B
    shared=tuple(w for w in a if w in b)
    ai,bi=pos(a,shared),pos(b,shared)
    ac=tuple(w for w in a if w not in shared)
    bc=tuple(w for w in b if w not in shared)
    ax=ac+bc
    ix,jx=pos(a,ac),pos(b,bc)
    blocks=defaultdict(list)
    for row,z in X.items():blocks[pull(row,ai)].append((pull(row,ix),z))
    constraints=[]
    if count>=500_000:
        for p,T,_ in peers:
            keep=tuple(w for w in p if w in ax)
            if not keep:continue
            vi=pos(p,keep)
            constraints.append((pos(ax,keep),{pull(k,vi) for k in T}))
        constraints.extend(pair_checks([A,B,*peers],(0,1),ax,product_cap=100_000))
        constraints.sort(key=lambda t:(len(t[1]),-len(t[0])))
    out={}
    seen=0
    survived=0
    for row,z in Y.items():
        tail=pull(row,jx)
        for head,w in blocks.get(pull(row,bi),()):
            seen+=1
            if seen%32768==0 and perf_counter()>deadline:return None,seen,survived,'wall'
            new=head+tail
            if constraints and any(pull(new,p) not in s for p,s in constraints):continue
            survived+=1
            x,y=mul(w,z)
            j,k=out.get(new,(0,0))
            if x+j or y+k:out[new]=x+j,y+k
            else:out.pop(new,None)
            if len(out)>ROWS:return None,seen,survived,'rows'
    assert seen==count
    return (ax,out,d*e),seen,survived,'completed'

def main():
    t=perf_counter()
    assert sha(P)==HP
    original=read(P)
    fs=original.pop('factors')
    ids=original['factor_labels']
    assert original['attempted_products']==9523595 and len(fs)==15
    live=dict(zip(ids,fs,strict=True))
    assert prod(d for _,_,d in fs)==DEN
    splits=[]
    for i,lab in enumerate(ids):
        if lab not in LEADER:continue
        f=fs[i]
        raw=len(f[1])
        candidates=relief(fs,i)
        best=None
        for sub,ax in candidates:
            a,b,rank=split(f,100+i,ax)
            size=len(a[1])+len(b[1])
            print('relief tested',lab,tuple(ids[j] for j in sub),'old/new',raw,size,
                  'rows',len(a[1]),len(b[1]),'classes',rank,flush=True)
            if best is None or size<best[0]:best=(size,a,b,rank,sub)
            if best[0]*6<=raw:break
        if best and best[0]*2<raw:
            _,a,b,c,sub=best
            certify(f,a,b)
            del live[lab]
            A,B=(100+i,0),(100+i,1)
            live[A]=a;live[B]=b
            splits.append((lab,A,B,tuple(ids[k] for k in sub),c,len(a[1]),len(b[1]),a[2],b[2]))
            print('exact relief split',splits[-1],flush=True)
    del fs
    collect()
    original['follow_pred_sha256']=HP
    original['follow_splits']=splits
    checkpoint('follow-split.pkl',original,live,[],0,[])
    forecasted={}
    for a,b in combinations(live,2):
        if s:=forecast(live[a],live[b]):forecasted[a,b]=s
    trace=[];refused=[];refused_set=set();work=0
    deadline=perf_counter()+120
    for step in range(35):
        if len(live)==1 or perf_counter()>deadline:break
        opts=[(cost*(w+1)**2,cost,w,a,b) for (a,b),(cost,w,k) in forecasted.items() if
              a[0]!=b[0] and (a,b) not in refused_set and 0<cost<=PAIR and work+cost<=MAX_STAGE]
        if not opts:break
        _,n,width,a,b=min(opts)
        if n>=500_000:
            x,y=live[a],live[b]
            sh=tuple(w for w in x[0] if w in y[0])
            u,v,s=onefold(x,y,sh)
            v,u,r=onefold(v,u,sh)
            if u is not x or v is not y:
                live[a],live[b]=u,v
                for (p,q) in forecasted:
                    if a in (p,q) or b in (p,q):forecasted[p,q]=forecast(live[p],live[q])
                now=forecasted[a,b][0]
                assert now<=n
                trace.append(('fold',a,b,n,now,s,r))
                print('exact primitive join quotient',trace[-1],flush=True)
                n=now
        print('attempt pair',a,b,'products',n,'width',width,flush=True)
        result,seen,pass_ct,status=guarded(live[a],live[b],[F for k,F in live.items() if k not in (a,b)],n,deadline)
        work+=seen
        if result is None:
            item=(a,b,n,seen,pass_ct,status)
            refused.append(item)
            refused_set.add((a,b))
            print('follow refused',item,'work',work,flush=True)
            if status=='wall':break
            continue
        label=(200+step,0)
        live.pop(a);live.pop(b)
        forecasted={k:v for k,v in forecasted.items() if a not in k and b not in k}
        for k,F in live.items():
            if s:=forecast(F,result):forecasted[k,label]=s
        live[label]=result
        item=('join',a,b,label,seen,len(result[1]),len(result[0]),result[2],pass_ct)
        trace.append(item)
        print('exact follow join',item,'remaining',len(live),'work',work,flush=True)
    checkpoint('follow-result.pkl',original,live,trace,work,refused)
    if len(live)==1:print('exact raw scalar',next(iter(live.values()))[1].get((),(0,0)),flush=True)
    print('follow exact terminal pair forecasts',sorted((v,a,b) for (a,b),v in forecasted.items())[:16],flush=True)
    print('follow seconds',round(perf_counter()-t,6),'RSS bytes',getrusage(RUSAGE_SELF).ru_maxrss,flush=True)

if __name__=='__main__':main()
