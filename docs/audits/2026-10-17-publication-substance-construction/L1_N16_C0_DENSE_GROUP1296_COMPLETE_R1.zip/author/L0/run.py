from pathlib import Path
import subprocess,sys,time

start=time.monotonic()
with Path('contraction.out').open('xb') as out, Path('contraction.err').open('xb') as err:
    try:
        status=subprocess.run([sys.executable,'-B','contract-slice.py'],
                              stdout=out,stderr=err,timeout=120).returncode
    except subprocess.TimeoutExpired:
        status=124
Path('contraction.receipt').write_text(f'child status {status}\nelapsed seconds {time.monotonic()-start:.6f}\n')
print(Path('contraction.receipt').read_text(),end='')
print(Path('contraction.out').read_text().splitlines()[-1],flush=True)
assert status in (0,2,124),status
