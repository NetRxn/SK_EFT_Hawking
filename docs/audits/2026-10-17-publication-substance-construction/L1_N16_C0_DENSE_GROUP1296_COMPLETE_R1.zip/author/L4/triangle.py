from collections import defaultdict
from itertools import permutations
from unsharded import *

def graph(factors, i, j, k):
    ax_i, x, _ = factors[i]
    ax_j, y, _ = factors[j]
    ax_k, z, _ = factors[k]
    ij = tuple(a for a in ax_i if a in ax_j)
    ik = tuple(a for a in ax_i if a in ax_k)
    jk = tuple(a for a in ax_j if a in ax_k)
    assert not (set(ij) & set(ik) or set(ij) & set(jk) or set(ik) & set(jk))
    assert set(ax_i) == set(ij + ik)
    assert set(ax_j) == set(ij + jk)
    assert set(ax_k) == set(ik + jk)
    lookup = {}
    left, right = defaultdict(dict), defaultdict(dict)
    for ax, rows, first, peers in ((ax_j,y,ij,left), (ax_k,z,ik,right)):
        p, q = pos(ax,first), pos(ax,jk)
        for key, value in rows.items():
            link = pull(key,q)
            if link not in lookup:
                lookup[link] = len(lookup)
            peers[pull(key,p)][lookup[link]] = value
    masks = [{key: sum(1<<idx for idx in nbr) for key,nbr in peer.items()} for peer in (left,right)]
    return x, pos(ax_i,ij), pos(ax_i,ik), left, right, masks

def visit(graph, evaluate=False):
    x,p,q,left,right,(lm,rm) = graph
    count = real = imaginary = 0
    chunks = []
    chunk_start = chunk_count = 0
    for row,(key,(xr,xi)) in enumerate(x.items()):
        a, b = pull(key,p), pull(key,q)
        match = lm.get(a,0) & rm.get(b,0)
        degree = match.bit_count()
        assert degree <= PAIR
        if chunk_count + degree > PAIR:
            chunks.append((chunk_start,row,chunk_count))
            chunk_start, chunk_count = row, 0
        chunk_count += degree
        count += degree
        if evaluate and match:
            candidates_left,candidates_right = left[a],right[b]
            ar = ai = 0
            while match:
                low = match & -match
                idx = low.bit_length()-1
                yr,yi = candidates_left[idx]
                zr,zi = candidates_right[idx]
                ar += yr*zr - yi*zi
                ai += yr*zi + yi*zr
                match ^= low
            real += xr*ar - xi*ai
            imaginary += xr*ai + xi*ar
    chunks.append((chunk_start,len(x),chunk_count))
    assert sum(c for _,_,c in chunks) == count
    return count,real,imaginary,chunks

if __name__ == '__main__':
    start = perf_counter()
    p = Path('pass3-result.pkl')
    assert sha(p) == '3f050b74776a21168f0f1aa1786db50108f9120d7cbb0b71f5dc6643a2c5bead'
    factors=read(p)['factors']
    assert len(factors)==3 and prod(d for _,_,d in factors)==DEN
    evaluate = '--evaluate' in argv
    for i,j,k in ((0,1,2),(1,0,2)):
        t=perf_counter()
        g=graph(factors,i,j,k)
        count,_,_,chunks=visit(g)
        print('triangle forecast',i,j,k,count, 'chunks',chunks, 'seconds',perf_counter()-t,flush=True)
        if evaluate and count<=TOTAL//2:
            observed,real,imaginary,actual=visit(g,True)
            assert observed==count and actual==chunks
            print('triangle signed numerator',i,j,k,real,imaginary,'denominator',DEN,'seconds',perf_counter()-t,flush=True)
        del g
    print('elapsed',perf_counter()-start,'RSS bytes',getrusage(RUSAGE_SELF).ru_maxrss,flush=True)
