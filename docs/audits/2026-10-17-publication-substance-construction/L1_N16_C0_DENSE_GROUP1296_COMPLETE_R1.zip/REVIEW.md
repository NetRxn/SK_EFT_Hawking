# Independent complete signed Group 1296 terminal review

Verified all eight original Group 1296 contributions. Six signed terminal replays independently match their author outcomes. Original ordinals 5 and 7 are exact zero through the separately accepted empty-factor preparation proof. The accepted prepared source has SHA-256 `4b3de456b9599c86e6e696d21ebc3331dcce3e09ed815975871465f136ae3c33`. The complete roster, factors and original labels were checked against the committed preparation archive.

The work-start continuity packet verified fresh at `1ab27ae7a3d6326ba6badf795209c9e116d02bfe`. The intervening publication checkpoint `5687ddabe554e47f7e7cb4b1e7ca88cb2cb2487f` adds the separate Group 1278 archive and edits two dispositions. All assigned scientific archive digests agree across both checkpoints. The acceptance-time r2 continuity packet verified fresh at the latter checkpoint. Both check receipts and the exact path delta are included.

For the six surviving original ordinals 0, 1, 2, 3, 4 and 6, the independent signed source inverse lifts and native guarded replays reproduce every saved ordered scope, signed coefficient table and denominator. The crossed row guard is independently observed on each exact refused pair. Selected rows range from 128,518 to 341,188; guarded cap rows range from 409,680 to 1,286,256. The refused projected-product counts range from 528,384 to 4,368,384. Every retained continuation split, fold and join was independently replayed, preserving all refusal descriptors and their separate attempted work. L1 and L2 close as empty-axis scalar factors.

| Original ordinal | Exact compatible triangle products | Independent pivot rows | Independent traversal seconds |
| --- | ---: | ---: | ---: |
| 0 | 8,896,000 | 259,584 | 4.159701 |
| 3 | 8,847,360 | 258,048 | 4.274994 |
| 4 | 8,156,160 | 345,600 | 3.746185 |
| 6 | 9,902,080 | 200,192 | 4.117013 |

Each independent terminal traversal uses a third anchor in reverse lexical order with three contiguous disjoint intervals capped at 4,000,000 products. Both original author anchor interval covers were independently counted, and both signed totals match the independent third traversal. The pinned inherited factor denominator is `4001207330550852373347244418531328` throughout.

The raw Gaussian sum is `(-23497638291886837176986770146387300780688606693773808049848320, 0)`, with reduced raw real `-5872637019449797203339613440`. The original phase is +1 and the physical divisor is `2^132`. The accepted cover coefficient of 192 combines the original occupation weight 48, chirality factor two, and selected geometric side factor two. Group 1296 is in component 98, with original chirality partner 2435. The standalone exact weighted contribution is `-68819965071677310976636095/332306998946228968225951765070086144`, with zero imaginary part.

Measured author components total 377.092866 seconds, including 27.69 seconds of preparation, 114.969176 seconds of guarded work, 205.673690 seconds of retained continuation, and 28.76 seconds of extra triangle terminals. The six recorded solve walls range from 48.29 to 71.65 seconds and sum to 332.73 seconds. Work and bounded timings are recorded in `cap.tsv`, `work.tsv` and `timing.tsv`. This acceptance covers the standalone original Group 1296 contribution.

## Reproduction

Verify the relative archive manifest. The original preparation and geometry archive hashes are in `source-archives.tsv`. With the pinned large operands present, verify each `author/L*/complete-operands.sha256` relative to the corresponding original author directory. Run `python3 -B -u source.py ORDINAL` and `python3 -B -u verify.py ORDINAL` from the review directory, using the supplied per-label pin files for original ordinals 0, 1, 2, 3, 4 and 6. For 0, 3, 4 and 6, run `python3 -B -u triangle_replay.py ORDINAL` and `python3 -B audit_triangle.py ORDINAL`. Run `python3 -B retally.py` to check the original signed scalar and normalized standalone weighted value. Retain each log with the original ordinal shown in the manifests.
