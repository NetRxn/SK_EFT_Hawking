"""Reconstruct the original L0 selected tables and native prejoin cap."""
from ast import literal_eval
from collections import Counter, defaultdict
from itertools import combinations, product
from pathlib import Path
from time import monotonic
from verify import CASE,C,author, fold, forecast, mul, origin, positions, read, sha, validate

PARENT=author.parent.parent/'dense-saturated-frontier.pkl'
PARENT_SHA='4b3de456b9599c86e6e696d21ebc3331dcce3e09ed815975871465f136ae3c33'
SEED='dense-saturated-frontier.pkl'
SEED_SHA=C['seed_sha']
CAP_SHA=C['cap_sha']
ROW_LIMIT=500_000

def condition():
    assert sha(PARENT)==PARENT_SHA and sha(author/SEED)==SEED_SHA
    src=read(PARENT)
    assert src['branch']==1296 and src['support']==8
    original=src['factors']
    assert len(original)==88
    L=tuple(sorted({w for axes,_,_ in original for w in axes if w[0]=='L'}))
    assert len(L)==12
    hist=[]
    for axes,rows,_ in original:
        edge=tuple(w for w in axes if w in L)
        hist.append((positions(L,edge),Counter(map(positions(axes,edge),rows))))
    domains=[{key[i] for a,rows,_ in original if w in a for i in [a.index(w)] for key in rows} for w in L]
    found=[]
    for key in product(*(sorted(v) for v in domains)):
        counts=[counts[project(key)] for project,counts in hist]
        if all(counts):
            found.append((key,sum(counts),max(counts)))
    declared=(author/'joint-label-roster.tsv').read_text().splitlines()
    assert L==literal_eval(declared[0].split('\t')[1])
    original_L,original_roster=literal_eval(Path('original-roster.txt').read_text())
    assert original_L==L and len(original_roster)==len(set(original_roster))==8
    by_key={k:(n,m) for k,n,m in found}
    assert by_key.keys()==set(original_roster)-{original_roster[5],original_roster[7]}
    expected=[(i,k,*by_key.get(k,(0,0))) for i,k in enumerate(original_roster)]
    assert expected==[(int(i),literal_eval(k),int(n),int(m)) for i,k,n,m in (line.split('\t') for line in declared[1:])]
    assert [(i,k,n,m) for i,k,n,m in expected if n]==[(int(i),literal_eval(k),int(n),int(m)) for i,k,n,m in (line.split('\t') for line in Path('prepared-roster.tsv').read_text().splitlines()[1:])]
    selected=read(author/SEED)
    assignment=original_roster[CASE]
    count,peak=by_key[assignment]
    assert selected['physical_cut']==(L,assignment) and selected['group']==1296
    assert selected['joint_label_index']==CASE and selected['used_before']==0
    assert set(selected['complete_label_roster']) in (set(by_key),set(original_roster))
    fixed=dict(zip(L,assignment,strict=True))
    for (axes,rows,den),(sub,coeffs,rden) in zip(original,selected['factors'],strict=True):
        assert sub==tuple(w for w in axes if w not in fixed) and den==rden
        lifted={tuple((dict(zip(sub,k,strict=True))|fixed)[w] for w in axes):v for k,v in coeffs.items()}
        limits=tuple((i,fixed[w]) for i,w in enumerate(axes) if w in fixed)
        assert lifted=={k:v for k,v in rows.items() if all(k[i]==v for i,v in limits)}
    assert count==sum(len(r) for _,r,_ in selected['factors'])==C['rows'] and peak==C['peak']
    print(f'source exact roster and complete signed L{CASE} inverse lift',L,assignment,count,peak,flush=True)
    return selected

def trim(factors, focus=None):
    for i,j in combinations(range(len(factors)),2):
        if focus is not None and focus not in (i,j):
            continue
        a,A,d=factors[i]; b,B,e=factors[j]
        shared=tuple(w for w in a if w in b)
        if not shared: continue
        P,Q=positions(a,shared),positions(b,shared)
        U,V=set(map(P,A)),set(map(Q,B))
        if U!=V:
            common=U&V
            if common!=U: factors[i]=(a,{k:v for k,v in A.items() if P(k) in common},d)
            if common!=V: factors[j]=(b,{k:v for k,v in B.items() if Q(k) in common},e)

def choose(factors, work):
    ladder=[]
    for i,j in combinations(range(len(factors)),2):
        a,A,_=factors[i]; b,B,_=factors[j]
        width=len(set(a)^set(b))
        if set(a)&set(b):
            ladder.append((len(A)*len(B)*(1+width),i,j))
    options=[]
    for _,i,j in sorted(ladder):
        n,w,_=forecast(factors[i],factors[j])
        if n<=8_000_000 and work+n<=40_000_000:
            options.append((n*(w+1)**2,n,i,j))
            if len(options)==12: break
    return min(options)[1:]

def native_fold(f,g):
    edge=tuple(w for w in f[0] if w in g[0])
    a,b,removed=fold(f,g,edge)
    if removed==0:
        U=set(map(positions(f[0],edge),f[1]))
        V=set(map(positions(g[0],edge),g[1]))
        if V<=U: return f,g,0
    return a,b,removed

def join(f,g,peers,expected, stop_at_cap=False):
    a,A,d=f; b,B,e=g
    edge=tuple(w for w in a if w in b)
    x=tuple(w for w in a if w not in edge); y=tuple(w for w in b if w not in edge)
    scope=x+y
    p,q,rx,ry=positions(a,edge),positions(b,edge),positions(a,x),positions(b,y)
    gates=[]
    if expected>250_000:
        for axes,rows,_ in peers:
            common=tuple(w for w in axes if w in scope)
            if common: gates.append((positions(scope,common),set(map(positions(axes,common),rows))))
        gates.sort(key=lambda pair:len(pair[1]))
    X,Y=defaultdict(list),defaultdict(list)
    for k,v in A.items():X[p(k)].append((rx(k),v))
    for k,v in B.items():Y[q(k)].append((ry(k),v))
    out={}
    visits=0
    for k in sorted(X.keys()&Y.keys(), reverse=True):
        for r,w in reversed(Y[k]):
            for l,v in reversed(X[k]):
                visits+=1
                key=l+r
                if any(P(key) not in support for P,support in gates): continue
                m,n=mul(v,w)
                u,z=out.get(key,(0,0))
                coeff=u+m,z+n
                if any(coeff):
                    out[key]=coeff
                    if stop_at_cap and len(out)>ROW_LIMIT:
                        return visits,len(out)
                else:out.pop(key,None)
    assert visits==expected
    return scope,out,d*e

def check_cap(seed):
    assert sha(origin)==CAP_SHA
    cap=read(origin)
    assert cap['physical_cut']==seed['physical_cut']
    assert len(cap['factors'])==C['cap_factors']
    factors=seed['factors']
    validate(factors)
    trim(factors)
    trim(factors)
    work=0
    logs=(author/'contraction.out').read_text().splitlines()
    joins=[line for line in logs if line.startswith('join ')]
    quotients=[line for line in logs if line.startswith('quotient ')]
    assert len(joins)==len(factors)-len(cap['factors'])==88-C['cap_factors']
    for step in range(len(joins)+1):
        prior,i,j=choose(factors,work)
        f,g=factors[i],factors[j]
        matched=prior
        if prior>50_000:
            f,g,n=native_fold(f,g)
            g,f,m=native_fold(g,f)
            factors[i],factors[j]=f,g
            matched=forecast(f,g)[0]
            assert quotients.pop(0)==f'quotient before join {len(factors)} {prior} {matched} slices {m+n}'
        peers=[F for k,F in enumerate(factors) if k not in (i,j)]
        if step==len(joins):
            assert not quotients
            assert factors==cap['factors'] and cap['rejected_pair']==(i,j)
            assert cap['used_before']==work and cap['matched']==matched
            assert logs[-1]==f'open row cap {len(factors)} {matched} frontier saved'
            cap_visits,cap_rows=join(f,g,peers,matched,True)
            assert cap_rows==ROW_LIMIT+1
            validate(factors)
            assert (author/'contraction.err').stat().st_size==0
            assert (author/'contraction.receipt').read_text().splitlines()[0]=='child status 2'
            nrows=sum(len(r) for _,r,_ in factors)
            nwire=len({w for a,_,_ in factors for w in a})
            print('independent exact native cap tables',CAP_SHA, len(factors), nrows,nwire, work,(i,j),matched,cap_visits,cap_rows,flush=True)
            return
        table=join(f,g,peers,matched)
        assert len(table[1])<=ROW_LIMIT
        factors=peers+[table]
        trim(factors,len(factors)-1)
        if len(factors)%8==0: trim(factors)
        table=factors[-1]
        found=f'join {len(factors)} {matched} {len(table[1])} axes {len(table[0])}'
        assert joins[step]==found,(step,joins[step],found)
        work+=matched
        print('native accepted',step,len(factors),matched,len(table[1]),work,flush=True)

if __name__=='__main__':
    start=monotonic()
    check_cap(condition())
    print('native source and cap independent seconds',round(monotonic()-start,6))
