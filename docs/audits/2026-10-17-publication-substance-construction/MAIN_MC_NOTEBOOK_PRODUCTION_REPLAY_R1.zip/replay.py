import json,sys
from pathlib import Path
import nbformat
from nbclient import NotebookClient

root=Path(sys.argv[1])
path=root/'notebooks'/'Phase5b_Synthesis_Technical.ipynb'
nb=nbformat.read(path,as_version=4)
try:
    NotebookClient(nb,timeout=120,kernel_name='python3',resources={'metadata':{'path':str(path.parent)}}).execute()
except Exception as error:
    print(json.dumps({'passed':False,'kind':type(error).__name__,'tail':str(error).splitlines()[-5:]}))
    raise SystemExit(1)
print(json.dumps({'passed':True,'code_cells':sum(c.cell_type=='code' for c in nb.cells)}))
