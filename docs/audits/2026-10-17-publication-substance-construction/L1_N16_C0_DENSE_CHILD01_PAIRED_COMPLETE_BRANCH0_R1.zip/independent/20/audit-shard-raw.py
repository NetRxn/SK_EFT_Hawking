from fractions import Fraction
from pathlib import Path
import re

author = Path('author-receipts/inner')
expected = {line.split('\t')[0]: tuple(map(Fraction,line.split('\t')[3:5]))
            for line in (author/'author-case20.tsv').read_text().splitlines()[:-1]}
denominator=40512224221827380280140849737629696
scale=denominator*16*4**64
print('slice','shard','lo','hi','raw_real','raw_imaginary','denominator','normalized_real','normalized_imaginary',sep='\t')
plan=(author/'terminal-plan.tsv').read_text().splitlines()
pins={Path(name).name:digest for digest,name in map(str.split,Path('inner-operands.sha256').read_text().splitlines())}
for line in plan:
    case,capture,*_=line.split('\t')
    case=int(case)
    log=Path(f'slice-{case}-shard-raw-replay.out').read_text()
    assert re.search(r'^input sha256 '+pins[capture]+r'(?: |$)',log,re.M|re.I)
    intervals=re.findall(r'^independent author shard (\d+) row interval (\d+) (\d+) raw (-?\d+) (-?\d+) factor denominator (\d+)$',log,re.M)
    assert len(intervals)==8
    sum_re=sum_im=end=0
    for index,raw in enumerate(intervals):
        shard,lo,hi,real,imaginary,d=map(int,raw)
        assert shard==index and end==lo and d==denominator
        end=hi
        source=(author/f'slice-{case}-shard-{shard}.out').read_text()
        match=re.search(r'^left row interval (\d+) (\d+) of (\d+) shard (\d+) of 8$',source,re.M)
        original_lo,original_hi,partition_rows,ordinal=map(int,match.groups())
        assert (lo,hi,shard)==(original_lo,original_hi,ordinal)
        assert (lo,hi)==(partition_rows*shard//8,partition_rows*(shard+1)//8)
        raw_author=re.search(r'^closure products \d+ retained outer matches \d+ closure probes \d+ raw (-?\d+) (-?\d+) factor denominator (\d+)$',source,re.M)
        assert tuple(map(int,raw_author.groups()))==(real,imaginary,denominator)
        normalized=Fraction(real,scale),Fraction(imaginary,scale)
        value=re.search(r'^exact normalized real (\S+) imaginary (\S+)',source,re.M)
        assert tuple(map(Fraction,value.groups()))==normalized
        sum_re+=real
        sum_im+=imaginary
        print(case,shard,lo,hi,real,imaginary,d,*normalized,sep='\t')
    assert end==partition_rows
    assert (Fraction(sum_re,scale),Fraction(sum_im,scale))==expected[str(case)]
