#!/usr/bin/env bash
set -euo pipefail
p=/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/probe20-inner
until test -s "$p/author-case20.tsv" && test -s inner-roster.tsv &&
      test "$(wc -l < "$p/author-case20.tsv")" -eq "$(( $(wc -l < inner-roster.tsv) + 1 ))"; do sleep 4; done
python3 -B rescue-source-pins.py 20 > terminal-source-pins.out
python3 -B -u replay-all.py 20 $(cut -f1 inner-roster.tsv) > replay-timing.tsv
python3 -B freeze-inputs.py 20
for prefix in source paired inner; do
  shasum -a 256 -c "$prefix-operands.sha256" > "$prefix-operands-verify.out"
done
/usr/bin/time -p python3 -B audit.py 20 > audit.out 2> audit.time
if rg -q 'shard-sum\.out' "$p/author-case20.tsv"; then
  python3 -B verify-shard-coverage.py 20 > shard-coverage.out
  python3 -B replay-author-raw.py > shard-raw-timing.tsv
  python3 -B audit-shard-raw.py > shard-raw-ledger.tsv
fi
python3 -B ledger-metrics.py 20 > signed-ledger.tsv
