from hashlib import sha256
from io import BytesIO
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile

P=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
HEAD='f728f2cae8337465c6a0d575a038de9c40ff3a5f'
Z=Path('docs/audits/2026-10-17-publication-substance-construction')
pinned={}
def archive(name):
    if not name.endswith('.zip'): name=f'L1_N16_C0_{name}_R1.zip'
    if name in pinned:return pinned[name][1]
    blob=check_output(['git','-C',P,'show',f'{HEAD}:{Z/name}'])
    d=sha256(blob).hexdigest()
    assert sha256((P/Z/name).read_bytes()).hexdigest()==d
    f=ZipFile(BytesIO(blob))
    entries=f.namelist();assert len(entries)==len(set(entries))
    if 'manifest.sha256' in entries:
        for raw in f.read('manifest.sha256').decode().splitlines():
            h,m=raw.split(maxsplit=1)
            assert sha256(f.read(m.removeprefix('./'))).hexdigest()==h,(name,m)
    pinned[name]=d,f
    return f

def stage(z,name,path):
    content=z.read(name)
    p=Path(path)
    p.parent.mkdir(exist_ok=True,parents=True)
    with p.open('xb') as out:out.write(content)
    return p
