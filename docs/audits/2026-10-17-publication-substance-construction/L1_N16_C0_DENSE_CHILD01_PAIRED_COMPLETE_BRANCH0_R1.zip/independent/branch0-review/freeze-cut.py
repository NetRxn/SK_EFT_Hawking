from fractions import Fraction as F
from pathlib import Path
from shutil import copyfile
from sys import argv
from inner import author,base,sha
from re import search,M

cut=int(argv[1])
here=Path(str(cut))
assert len((here/'primary-lineage.tsv').read_text().splitlines())==27
assert len((here/'rescue-lineage.tsv').read_text().splitlines())==16
assert len([s for s in (here/'inner-audit.out').read_text().splitlines() if s.startswith('PASS inverse signed lift')])==9
ledger=(here/'signed-ledger.tsv').read_text().splitlines()
assert len(ledger)==11
sum_label,re,im=ledger[-1].split('\t')
assert sum_label=='sum' and F(im)==0
coords=('(130, (2,))' if cut==21 else '(132, (1,))')
print('cut',cut,'verified',coords,re,im)
src=[author/n for n in (f'combined-{cut}.pkl',f'combine-{cut}.out',f'label-sum{cut}-reduced-frontier.pkl',
    f'row-cap-physical-slice-dense-label-sum{cut}-reduced.pkl',f'reduce-{cut}.out',f'contract-{cut}.out',
    'sum-branches-checked.py','reduce-label-frontier.py','contract-reduced-label.py','checkpoint/quotient.py')]
src += [base/f'row-cap-physical-slice-dense-label-tuple0-branch-{i}-reduced.pkl' for i in (0,1)]
src += [base/f'tuple0-branch{i}-pilot/pilot.roster' for i in (0,1)]
probe=author/f'probe{cut}-inner'
src += [path for path in sorted(probe.rglob('*')) if path.is_file() and path.suffix in ('.pkl','.out','.roster','.py','.tsv')]
with (here/'source-operands.sha256').open('x') as out:
    for p in src:
        print(sha(p),p,sep='  ',file=out)
        if p.suffix!='.pkl':
            rel=p.relative_to(base)
            dst=here/'author'/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            copyfile(p,dst)
lines=[
f'# Independent paired cut {cut}',
'',
f'The original outer coordinate {coords} contributes **{re} + {im}i** to group 128 descendant (0,1), tuple 0.',
'',
'The publication pin is f728f2cae8337465c6a0d575a038de9c40ff3a5f. Independently reconstructed the original 48-coordinate support of each binary operand, with 6,427,904 pair products per binary value. The selected outer coordinate has 106,344 products per value. Reverse-direction Gaussian accumulation reproduces every row of the exact two-value sum and the seven-factor environment, including all denominators. The original binary-summed construction and its reduction and row cap were also reproduced byte for byte.',
'',
'Independent histograms recover nine complete inner G(0,1,2) values with 1,021,248 products. The inverse lifts recover every compatible sparse row and sign. All 27 primary and 16 rescue preparation, reduction and contraction operations reproduce the author receipts and intermediate caps byte for byte. The log and checkpoint hashes bind each accepted or refused stage to its input.',
'',
'The independent width-weighted sparse schedule computes all nine signed Gaussian terminals without importing author arithmetic. It verifies both raw components, denominator product 40512224221827380280140849737629696, and external normalization 1/(16×4^64) once. The replay logs and signed ledger include each exact term, terminal input SHA, factor count and elapsed time. This is an additive subtotal for one distinct original outer coordinate.'
]
if cut==21:lines+=['','An initial reviewer invocation omitted the author receipt argument and read an unrelated default receipt after arithmetic. The corrected runs explicitly pin each receipt. Initial diagnostics are preserved in locator-correction.']
(here/'REVIEW.md').write_text('\n'.join(lines)+'\n')
names=[p.relative_to(here) for p in sorted(here.iterdir()) if p.is_file() and p.suffix in ('.out','.tsv','.md','.sha256','.time')]
names +=[p.relative_to(here) for p in sorted((here/'author').rglob('*')) if p.is_file()]
names +=[p.relative_to(here) for p in sorted((here/'locator-correction').glob('*.out'))]
names +=[Path(p) for p in ('pair-route-audit.py','pair-lineage.sh','combine-readback.sh','sparse-support-replay.py')]
with (here/'review-manifest.portable.sha256').open('x') as f:
    for p in sorted(names):
        print(sha(here/p),p,sep='  ',file=f)
