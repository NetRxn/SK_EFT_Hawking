from archives import archive,pinned,HEAD
from ast import literal_eval
from collections import Counter,defaultdict
from csv import DictReader
from fractions import Fraction as F
from gzip import decompress
from hashlib import sha256
from itertools import product
from math import factorial,prod
from pathlib import Path
from pickle import loads
from re import search,M
from sys import argv

BASE=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
D=40512224221827380280140849737629696
S=D*16*4**64
PAIR='DENSE_CHILD01_TUPLE0_PAIRED_C7_C14_C15_C16'
T1='DENSE_CHILD01_TUPLE1_COMPLETE_AND_PAIRED_PILOT'
T234='DENSE_CHILD01_TUPLES2_4'
COND='DENSE_CONDITIONED_SCALARS'
BINARY='DENSE_BINARY_REDUCTION'
CHILD00='DENSE_CHILD00_COMPLETE'
ZERO=(F(0),F(0))
axis_first=('R',1,3,0,2,1)
axis_second=('R',0,6,1,1,1)


def source_norm():
    occupations=tuple(v for v in product(range(5),repeat=3) if sum(v)<=4)
    codes=(503841882182,1461451755920)
    layers=[[occupations[(code>>(6*site))&63] for site in range(8)] for code in codes]
    edges=sorted((u,k,u^(1<<k)) for u in range(8) for k in range(3) if u<(u^(1<<k)))
    degree=sum(n for layer in layers for site in layer for n in site)
    mult=prod(factorial(n) for layer in layers for site in layer for n in site)
    world=sum((3+k)*n for layer in layers for site in layer for k,n in enumerate(site))
    cross=0
    for layer in layers:
        prepared=[(u,v,sum(layer[u])+sum(layer[v])-layer[u][k]-layer[v][k]) for u,k,v in edges]
        for p,(u,v,s) in enumerate(prepared):
            cross+=sum(s*t*sum(a>b for a in (u,v) for b in (x,y)) for x,y,t in prepared[p+1:])
    assert (degree,mult,world,cross)==(32,16,136,444)
    assert (-1)**((world+cross)%2)==1 and D*mult*4**(2*degree)==S
    print('source normalization independently decoded',codes,'degree',degree,'factorial product',mult,'phase +1',
          'Haar denominator',4**64,'tensor denominator',D)

def audit_binary_root(binary):
    source=Path('/private/tmp/l1-dense-resume.bbZW6V/resumed-eleven-saturated-frontier.pkl')
    root=read(source)
    assert len(root['factors'])==11 and sum(len(r) for _,r,_ in root['factors'])==1292272
    traffic=[]
    incidences=[]
    for i,(ax,table,d) in enumerate(root['factors']):
        if axis_first in ax:
            incidences.append(i)
            j=ax.index(axis_first)
            traffic.append(Counter(row[j] for row in table))
    assert incidences==[7,10] and traffic==[{0:16764,1:16764},{0:231680,1:231680}]
    assert prod(d for _,_,d in root['factors'])==D
    print('first representative cut support exact',axis_first,incidences,traffic,sha256(source.read_bytes()).hexdigest())

def combine(values):
    values=list(values)
    re,im=tuple(sum(term,F(0)) for term in zip(*values,strict=True))
    assert all((S*v).denominator==1 for t in values for v in t)
    for result,column in zip((re,im),zip(*values,strict=True),strict=True):
        assert result==F(sum(int(S*x) for x in column),S)
    return re,im

def get_record(text):
    if text.startswith('0\t') and text.splitlines()[-1].startswith('sum\t'):
        return tuple(map(F,text.splitlines()[-1].split('\t')[1:3]))
    by_regex=search(r'^exact normalized real (\S+) imaginary (\S+) ',text,M)
    if by_regex: return tuple(map(F,by_regex.groups()))
    raise AssertionError(text[-200:])

def check_lift(parent,child,fixed):
    assert child['conditioning']==parent['conditioning']+list(fixed.items())
    assert prod(d for _,_,d in child['factors'])==prod(d for _,_,d in parent['factors'])==D
    for (a,A,d),(b,B,e) in zip(parent['factors'],child['factors'],strict=True):
        rem=[k for k,w in enumerate(a) if w not in fixed]
        fix={k:fixed[w] for k,w in enumerate(a) if w in fixed}
        assert d==e and b==tuple(a[k] for k in rem)
        expected={x:z for x,z in A.items() if all(x[k]==v for k,v in fix.items())}
        got={}
        for key,z in B.items():
            coords=fix|dict(zip(rem,key,strict=True))
            recovered=tuple(coords[k] for k in range(len(a)))
            assert recovered not in got
            got[recovered]=z
        assert expected==got

def read(p):
    return loads(p.read_bytes())

def xscope(scope,key,fields):
    return tuple(key[scope.index(w)] for w in fields)

def roster_from_inputs():
    rosters=[(BASE/f'tuple0-branch{i}-pilot/pilot.roster').read_bytes() for i in (0,1)]
    assert rosters[0]==rosters[1]
    axes,reference=literal_eval(rosters[0].decode())
    assert axes==(('G',0,4,2),('J',1,4,2))
    table=dict(reference)
    assert len(reference)==len(table)==48 and sum(table.values())==6427904
    branches=[]
    for i in (0,1):
        p=BASE/f'row-cap-physical-slice-dense-label-tuple0-branch-{i}-reduced.pkl'
        buf=p.read_bytes()
        h=sha256(buf).hexdigest()
        assert h==('c5795431732ddb5ba8636d4ac5ee0401298439e8d6fcaa6f255e6e2bdfeee304','139f02c34fb8c162cc7834f8b69315e313005a4974aabf306a377a21655ccd0d')[i]
        branch=loads(buf);branches.append(branch)
        A,B,*environment=branch['factors']
        shared=tuple(w for w in A[0] if w in B[0])
        assert not set(shared)&set(axes) and set(axes)<=set(A[0])
        left=Counter((xscope(A[0],key,axes),xscope(A[0],key,shared)) for key in A[1])
        right=Counter(xscope(B[0],key,shared) for key in B[1])
        actual=Counter()
        for (point,key),n in left.items():
            if n1:=right[key]:actual[point]+=n*n1
        assert dict(actual)==table
        print('full original paired roster independently regenerated',i,h,len(actual),sum(actual.values()))
    return branches,axes,table,sorted(table,key=lambda k:(table[k],k))

def committed_cut_prefix(points,counts):
    anchor=archive(PAIR)
    rows=list(DictReader(anchor.read('coverage-ledger.tsv').decode().splitlines(),delimiter='\t'))
    accepted={}
    for i,rec in enumerate(rows[:48]):
        assert i==int(rec['outer_cut']) and points[i]==literal_eval(rec['coordinate'])
        assert counts[points[i]]==int(rec['pair_products_one_branch'])
        if rec['disposition']!='accepted':
            assert not rec['real'] and not rec['imaginary']
            continue
        value=F(rec['real']),F(rec['imaginary'])
        src=rec['evidence']
        ar=anchor
        if ':' in src:
            name,src=src.split(':',1)
            ar=archive(name)
        assert get_record(ar.read(src).decode())==value,(i,src)
        accepted[i]=value
    assert set(range(48))-accepted.keys()==set(range(17,23))
    print('accepted prior 42 checked against committed archive members')
    return accepted

def descendant_sources(branches):
    z=archive(COND)
    binary=archive(BINARY)
    audit_binary_root(binary)
    cut_spec=literal_eval(binary.read('cut-choice.txt').decode())
    assert cut_spec[3:]==(axis_first,[0,1],[7,10])
    specs=[literal_eval(s) for s in z.read('author/plan-second-cut.out').decode().splitlines() if s.startswith('(')]
    assert specs[0][3:]==(axis_second,[0,1],[2,4])
    assert archive(CHILD00).read('independent/descendant00-parent.sha256').decode().startswith('d12720858ba57cc926148f42e4cc53aa999a82ca2ba796fb2438b33c95ff7a2a')
    parent_file=BASE/'nine-minimum-quotient-frontier.pkl'
    blob=parent_file.read_bytes()
    hp=sha256(blob).hexdigest()
    asserted=next(r.split()[0] for r in z.read('independent/child01-tuple5-inputs.sha256').decode().splitlines() if r.endswith('nine-minimum-quotient-frontier.pkl'))
    assert hp==asserted
    parent=loads(blob)
    assert parent['conditioning']==[(axis_first,0),(axis_second,1)]
    assert prod(d for _,_,d in parent['factors'])==D
    labels=tuple(sorted({w for ax,_,_ in parent['factors'] for w in ax if w[0]=='L'}))
    domains=defaultdict(set)
    factors=[]
    for ax,rows,d in parent['factors']:
        axes=tuple(w for w in labels if w in ax)
        positions=tuple(ax.index(w) for w in axes)
        local=Counter(tuple(key[p] for p in positions) for key in rows)
        for k in local:
            for w,v in zip(axes,k,strict=True):domains[w].add(v)
        factors.append((axes,local))
    original=defaultdict(dict)
    for row in z.read('author/checkpoint/independent/states.tsv').decode().splitlines():
        n,t,c,u,p,q=map(int,row.split())
        original[n][('L',t,c,u)]=(p,q)
    projected={tuple(a[w] for w in labels) for a in original.values()}
    assert len(projected)==8
    feasible={}
    cardinality=0
    for tup in product(*(sorted(domains[w]) for w in labels)):
        cardinality+=1
        v=dict(zip(labels,tup,strict=True))
        sizes=[table[tuple(v[w] for w in axes)] for axes,table in factors]
        if all(sizes):feasible[tup]=sizes
    assert len(labels)==8 and cardinality==256 and len(feasible)==6 and feasible.keys()<=projected
    roster=z.read('child01/label-partition-roster.txt')
    assert roster==archive(T234).read('author/label-partition-roster.txt')==(BASE/'label-partition-roster.txt').read_bytes()
    plan=literal_eval(roster.decode())
    assert [i for _,i,_,_ in plan]==list(range(6))
    for w,i,fix,counts in plan:
        assert tuple(fix[j] for j in labels) in feasible
        assert feasible[tuple(fix[j] for j in labels)]==counts and w==sum(counts)
    assert set(feasible)=={tuple(fix[j] for j in labels) for _,_,fix,_ in plan}
    print('verified 6-tuple projected support from live parent tied to archive',hp,len(projected),cardinality)
    for i in range(6):
        if i==5: child=read(Path('/private/tmp/l1-dense-child01.zdXzYQ/label-tuple-selected-frontier.pkl'))
        else: child=read(BASE/f'label-tuple-{i}-frontier.pkl')
        check_lift(parent,child,dict(sorted(plan[i][2].items())))
        assert child['label_partition']=={'index':i,'count':6,'values':plan[i][2]}
        assert sum(len(rows) for _,rows,_ in child['factors'])==plan[i][0]
    print('verified all six signed parent inverse lifts')
    state=read(BASE/'label-tuple-0-frontier.pkl')
    reduced=read(BASE/'join-cap-dense-label-0-2-reduced.pkl')
    assert reduced['conditioning']==state['conditioning'] and reduced['label_partition']==state['label_partition']
    binary0=('R',0,0,2,0,1)
    for j,pre in enumerate(branches):
        assert pre['conditioning']==state['conditioning']+[(binary0,j)]
        assert pre['label_partition']==state['label_partition']
        check_lift(reduced,read(BASE/f'child01-tuple0-{j}.pkl'),{binary0:j})
    assert [set(xscope(ax,k,[binary0]) for k in table) for ax,table,d in reduced['factors'] if binary0 in ax]==[{(0,),(1,)},{(0,),(1,)}]
    print('verified tuple0 signed inverse lift and both exhaustive binary sublifts',binary0)
    return parent,plan

def accepted_tuples_and_child00(plan):
    b=archive(T1)
    r,lr=literal_eval(b.read('tuple1.roster').decode())
    assert b.read('tuple1.roster')==b.read('independent-complete/pilot.roster')
    assert r==(('G',0,0,2),('J',1,4,2))
    cnt=dict(lr)
    which=sorted(cnt,key=lambda k:(cnt[k],k))
    assert len(lr)==len(cnt)==36 and sum(cnt.values())==6838272
    inp=decompress(b.read('independent-complete/parent.pkl.gz'))
    h=sha256(inp).hexdigest()
    assert h==b.read('independent-complete/parent-unpacked.sha256').decode().split()[0]
    assert h=='ecf0158af2d0582b25bc0a26cb65a74a929a1b0c5d8bba7bbd4eac36720b664c'
    assert inp==(BASE/'row-cap-physical-slice-dense-label-1-2-reduced.pkl').read_bytes()
    t=loads(inp)
    assert t['conditioning']==[(axis_first,0),(axis_second,1)]+sorted(plan[1][2].items())
    assert t['label_partition']=={'index':1,'count':6,'values':plan[1][2]}
    assert prod(d for _,_,d in t['factors'])==D
    L,R=[t['factors'][j] for j in t['rejected_pair']]
    common=tuple(w for w in L[0] if w in R[0])
    assert set(r)<=set(L[0]) and not set(r)&set(common)
    li=tuple(L[0].index(w) for w in common)
    ri=tuple(R[0].index(w) for w in common)
    gi=tuple(L[0].index(w) for w in r)
    hist=Counter(tuple(k[j] for j in ri) for k in R[1])
    count=Counter()
    for k in L[1]:
        if n:=hist[tuple(k[j] for j in li)]:count[tuple(k[j] for j in gi)]+=n
    assert dict(count)==cnt
    print('verified tuple1 original (0,1) restart and complete 36-coordinate count',h)
    indep=list(DictReader(b.read('independent-complete/complete-ledger.tsv').decode().splitlines(),delimiter='\t'))
    author=[s.split('\t') for s in b.read('tuple1-complete.tsv').decode().splitlines()]
    assert len(indep)==37
    terms=[]
    for i,row in enumerate(indep[:-1]):
        p=literal_eval(row['coordinate'])
        assert p==which[i] and int(row['cut_products'])==cnt[p] and int(row['case'])==i
        n=F(row['normalized_real']),F(row['normalized_imag'])
        assert n==tuple(F(int(row[k]),S) for k in ('raw_real','raw_imag'))
        assert (int(author[i][0]),literal_eval(author[i][1]),int(author[i][2]))==(i,p,cnt[p])
        assert n==tuple(map(F,author[i][3:5]))
        terms.append(n)
    tup1=combine(terms)
    assert tup1==tuple(F(indep[-1][k]) for k in ('normalized_real','normalized_imag'))
    assert tup1==tuple(F(int(indep[-1][k]),S) for k in ('raw_real','raw_imag'))
    vals={1:tup1}
    w=archive(T234)
    for line in w.read('exact-tuples.tsv').decode().splitlines()[:3]:
        j,re,im=line.split('\t')
        j=int(j)
        receipt=w.read(f'independent/sparse-{j}.out').decode()
        raw=search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',receipt,M)
        assert int(raw[3])==D and str({'index':j,'count':6,'values':plan[j][2]}) in receipt
        assert str([(axis_first,0),(axis_second,1)]+sorted(plan[j][2].items())) in receipt
        vals[j]=(F(re),F(im))
        assert tuple(F(int(raw[k]),S) for k in (1,2))==vals[j]==get_record(receipt)
    z=archive(COND)
    row=next(r for r in DictReader(z.read('accepted-conditioned-values.tsv').decode().splitlines(),delimiter='\t') if r['internal_conditioning']=='0,1')
    vals[5]=F(row['real']),F(row['imaginary'])
    assert row['label_tuple']=='5'
    receipt=z.read('independent/replay-child01-tuple5.out').decode()
    assert get_record(receipt)==vals[5]
    raw=search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',receipt,M)
    assert int(raw[3])==D and vals[5]==tuple(F(int(raw[k]),S) for k in (1,2))
    assert str([(axis_first,0),(axis_second,1)]+sorted(plan[5][2].items())) in receipt
    c0=archive(CHILD00)
    author=c0.read('descendant00.tsv')
    independently=c0.read('independent/descendant00-independent.tsv')
    for label,content in [('independent',independently),('author',author)]:
        ls=content.decode().splitlines()
        xs=([['tuple',*t.split('\t')] for t in ls[1:-1]] if label=='independent' else [t.split('\t') for t in ls if t.startswith('tuple\t')])
        assert [int(x[1]) for x in xs]==list(range(6))
        result=combine(tuple(map(F,x[2:4])) for x in xs)
        assert result==tuple(map(F,ls[-1].split('\t')[-2:]))
        if label=='independent': value=result
        else: assert value==result
    assert set(vals)=={1,2,3,4,5}
    for i,term in sorted(vals.items()):print('verified tuple',i,*term)
    print('verified child00',*value)
    return vals,value

if __name__=='__main__':
    source_norm()
    branches,axes,counts,points=roster_from_inputs()
    prior=committed_cut_prefix(points,counts)
    parent,plan=descendant_sources(branches)
    rest,value00=accepted_tuples_and_child00(plan)
    for z,(d,_) in sorted(pinned.items()):print('source archive',HEAD,d,z)
    if len(argv)==1: 
        print('prepared exact prior bindings; pending accepted cut 17–22')
        raise SystemExit(0)
    verify_fresh=Path('fresh-verified.tsv')
    fresh=list(DictReader(verify_fresh.read_text().splitlines(),delimiter='\t'))
    assert [int(x['cut']) for x in fresh]==list(range(17,23))
    got=prior.copy()
    for entry in fresh:
        i=int(entry['cut'])
        assert i not in got
        data=Path(f'fresh/{i}-review-manifest.sha256').read_bytes()
        assert sha256(data).hexdigest()==entry['manifest_sha256']
        got[i]=F(entry['real']),F(entry['imaginary'])
    assert set(got)==set(range(48))
    if argv[1]!='--local':
        rows=list(DictReader(Path(argv[1]).read_text().splitlines(),delimiter='\t'))
        displayed={}
        for entry in rows:
            irec=entry['outer_cut']
            if not irec.isdigit():continue
            i=int(irec)
            assert i not in displayed and 0<=i<48 and entry['disposition']=='accepted' and points[i]==literal_eval(entry['coordinate'])
            assert counts[points[i]]==int(entry['pair_products_one_branch'])
            displayed[i]=F(entry['real']),F(entry['imaginary'])
        assert displayed==got
        print('author final 48 ledger agrees term by term with independent sources')
    with Path('independent-48.tsv').open('w') as out:
        print('outer_cut','coordinate','pair_products_one_branch','disposition','real','imaginary',sep='\t',file=out)
        for i in range(48): print(i,repr(points[i]),counts[points[i]],'accepted',*got[i],sep='\t',file=out)
    rest[0]=combine(got.values())
    value01=combine(rest.values())
    value0=combine((value00,value01))
    with Path('independent-composition.tsv').open('w') as out:
        for i,v in sorted(rest.items()):print('tuple',i,*v,sep='\t',file=out)
        print('child','0,0',*value00,sep='\t',file=out)
        print('child','0,1',*value01,sep='\t',file=out)
        print('first-index branch','0',*value0,sep='\t',file=out)
    for i,v in sorted(rest.items()):print('normalized tuple',i,*v)
    print('normalized descendant',0,1,*value01)
    print('normalized first-index branch',0,*value0)
