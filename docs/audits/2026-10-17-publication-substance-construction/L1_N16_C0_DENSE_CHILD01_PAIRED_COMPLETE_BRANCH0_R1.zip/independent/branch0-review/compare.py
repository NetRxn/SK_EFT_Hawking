from archives import archive
from csv import DictReader
from fractions import Fraction
from hashlib import sha256
from pathlib import Path

def const(row):
    return tuple(map(Fraction,row))

independent={}
for raw in Path('independent-composition.tsv').read_text().splitlines():
    label,key,re,im=raw.split('\t')
    if label=='tuple': scope=f'child01 tuple {key}'
    elif label=='child': scope=f'child{key.replace(",","")}'
    else:
        assert label=='first-index branch' and key=='0'
        scope='first-index branch0'
    independent[scope]=const((re,im))
author=list(DictReader(Path('recombined.tsv').read_text().splitlines(),delimiter='\t'))
assert len(author)==len(independent)==9
for row in author:
    assert independent.pop(row['scope'])==const((row['normalized_real'],row['normalized_imaginary']))
    source=row['source']
    if row['source_sha256']:
        if '::' in source:
            z,member=source.split('::',1)
            data=archive(z).read(member)
        else:
            data=Path(source).read_bytes()
        assert sha256(data).hexdigest()==row['source_sha256']
assert not independent
comparand=list(DictReader(Path('coverage-ledger.tsv').read_text().splitlines(),delimiter='\t'))
verified=list(DictReader(Path('independent-48.tsv').read_text().splitlines(),delimiter='\t'))
assert len(verified)==48 and len(comparand)==49
for u,v in zip(verified,comparand[:48],strict=True):
    assert all(v[k]==value for k,value in u.items())
total=comparand[-1]
assert total['disposition']=='48/48'
assert const((total['real'],total['imaginary']))==tuple(sum(Fraction(u[k]) for u in verified) for k in ('real','imaginary'))
print('PASS author vs independent 48 unique points, all tuple, child and first-branch values, and nonempty source hashes')
