from archives import archive,stage
from pathlib import Path
from subprocess import run
from gzip import decompress
from hashlib import sha256
from sys import executable
from pickle import loads
from collections import Counter
from time import perf_counter
from math import prod

binary=archive('DENSE_BINARY_REDUCTION')
cond=archive('DENSE_CONDITIONED_SCALARS')
ready=Path('child01-lineage')
ready.mkdir()
first=decompress(binary.read('branch128-binary-0-frontier.pkl.gz'))
h=sha256(first).hexdigest()
assert h==binary.read('frontiers-uncompressed.sha256').decode().splitlines()[0].split()[0]=='b1ec8c9da0e2aba8b866a0fafe40ac43e53b8c7bfc4895016102d87ce78ace4e'
parent=loads(first)
second=('R',0,6,1,1,1)
assert parent['physical_cut']==(('R',1,3,0,2,1),0)
its=[(i,Counter(r[a.index(second)] for r in table)) for i,(a,table,d) in enumerate(parent['factors']) if second in a]
assert len(its)==2 and all(set(c)=={0,1} for _,c in its)
print('binary source',h,'conditioning',parent['physical_cut'],'second representative axis',second,'two incident exact domains',its,flush=True)
(ready/'row-cap-physical-slice-dense-binary-zero-fixed.pkl').write_bytes(first)
for name in ('checkpoint/quotient.py','contract-second-cut-r2.py'):
    stage(cond,'author/'+name,ready/name)
start=perf_counter()
with (ready/'descendant01.out').open('xb') as stream:
    result=run([executable,'-u','contract-second-cut-r2.py','1'],stdout=stream,cwd=ready,timeout=180)
assert result.returncode==2
assert (ready/'descendant01.out').read_bytes()==cond.read('author/contract-second-cut-r2-1.out')
recovered=(ready/'join-cap-dense-binary-zero-child-1.pkl').read_bytes()
expected=Path('/private/tmp/l1-child01-tuples234.cugnpQ/nine-minimum-quotient-frontier.pkl').read_bytes()
target=loads(expected)
assert loads(recovered)==target
expect_hash=next(s.split()[0] for s in cond.read('independent/child01-tuple5-inputs.sha256').decode().splitlines() if s.endswith('nine-minimum-quotient-frontier.pkl'))
assert sha256(expected).hexdigest()==expect_hash
assert len(target['factors'])==9 and target['conditioning']==[(('R',1,3,0,2,1),0),(second,1)]
assert prod(d for _,_,d in target['factors'])==40512224221827380280140849737629696
print('PASS exact child01 replay versus original scoped receipt and accepted descendant envelope',expect_hash,
      'raw replay bytes hash',sha256(recovered).hexdigest(),'seconds',round(perf_counter()-start,6))
