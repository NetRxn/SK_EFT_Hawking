from pathlib import Path
from shutil import copyfile
from subprocess import run
from sys import executable
from time import perf_counter
from hashlib import file_digest

root=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
scratch=Path('tuple0-ancestry')
(scratch/'checkpoint').mkdir(parents=True)
def h(path):
    with path.open('rb') as f:return file_digest(f,'sha256').hexdigest()
for name in ('reduce-label-frontier.py','contract-reduced-label.py','checkpoint/quotient.py','exact-cut.py'):
    copyfile(root/name,scratch/name)
def command(script,args,log,expect):
    start=perf_counter()
    with (scratch/log).open('xb') as stream:
        p=run([executable,'-u',script,*args],cwd=scratch,stdout=stream,timeout=180)
    assert p.returncode==expect,(p.returncode,log)
    assert h(scratch/log)==h(root/log),log
    print(log,expect,round(perf_counter()-start,6),sep='\t',flush=True)

initial=str(root/'label-tuple-0-frontier.pkl')
for j in range(3):
    tag=f'0-{j}'
    valid=f'join-cap-dense-label-{tag}-reduced.pkl'
    command('reduce-label-frontier.py',[initial,tag],'reduce-'+tag+'.out',0)
    name=f'label-{tag}-reduced-frontier.pkl'
    assert h(scratch/name)==h(root/name)
    command('contract-reduced-label.py',[tag],'contract-'+tag+'.out',2)
    assert h(scratch/valid)==h(root/valid)
    initial=valid
for j in (0,1):
    tag=f'tuple0-branch-{j}'
    command('reduce-label-frontier.py',[str(root/f'child01-tuple0-{j}.pkl'),tag],tag+'-reduce.out',0)
    name=f'label-{tag}-reduced-frontier.pkl'
    assert h(scratch/name)==h(root/name)
    command('contract-reduced-label.py',[tag],tag+'-contract.out',2)
    cap=f'row-cap-physical-slice-dense-label-{tag}-reduced.pkl'
    assert h(scratch/cap)==h(root/cap)
    print('final binary child',j,h(scratch/cap),flush=True)
