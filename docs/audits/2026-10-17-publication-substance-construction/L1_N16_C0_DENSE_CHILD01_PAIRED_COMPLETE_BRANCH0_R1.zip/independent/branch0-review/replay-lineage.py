from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from shutil import copyfile
from subprocess import run,STDOUT
from sys import argv,executable
from time import perf_counter
from inner import author,sha

cut=int(argv[1])
mode=argv[2]
folder=author/f'probe{cut}-inner'
ptr=author/f'row-cap-physical-slice-dense-label-sum{cut}-reduced.pkl'
programs=('exact-multicut.py','reduce-label-frontier.py','contract-reduced-label.py','contract-peer.py','peer_pair.py','checkpoint/quotient.py')

def copy_set(scratch):
    (scratch/'checkpoint').mkdir(parents=True)
    for name in programs:
        copyfile(folder/name,scratch/name)

def command(scratch,i,script,args,receipt,rc):
    start=perf_counter()
    with (scratch/receipt).open('xb') as out:
        p=run([executable,'-u',script,*args],cwd=scratch,stdout=out,stderr=STDOUT,timeout=185)
    assert p.returncode==rc,(cut,i,script,args,p.returncode,rc)
    assert sha(scratch/receipt)==sha(folder/receipt),(i,receipt)
    print(cut,i,receipt,rc,round(perf_counter()-start,6),sep='\t',flush=True)

def verify(i):
    path=Path(str(cut))/f'lineage-{mode}-{i}'
    copy_set(path)
    fixed=lambda p: assert_sha(path/p,folder/p)
    tag=f'slice-{i}'
    if mode=='primary':
        name=tag+'.pkl'
        command(path,i,'exact-multicut.py',[str(ptr),name,str(i)],tag+'-plan.out',0)
        fixed(name); fixed(tag+'.roster')
        command(path,i,'reduce-label-frontier.py',[name,tag],tag+'-reduce.out',0)
        fixed(f'label-{tag}-reduced-frontier.pkl')
        receipt=tag+'-contract.out'
        caps=tuple(folder.glob(f'*-dense-label-{tag}-reduced.pkl'))
        assert len(caps)<=1
        command(path,i,'contract-reduced-label.py',[tag],receipt,2 if caps else 0)
        for cap in caps:fixed(cap.name)
    else:
        for k in range(10):
            choice=tuple(folder.glob(f'*-dense-label-{tag}-reduced.pkl'))
            if not choice:break
            p,=choice
            rt=f'rescue-{i}-{k}'
            if not (folder/f'{rt}-contract.out').is_file():break
            if p.name not in [q.name for q in path.iterdir()]:
                (path/p.name).symlink_to(p)
            command(path,i,'reduce-label-frontier.py',[p.name,rt],rt+'-reduce.out',0)
            fixed(f'label-{rt}-reduced-frontier.pkl')
            caps=tuple(folder.glob(f'*-dense-label-{rt}-reduced.pkl'))
            assert len(caps)<=1
            command(path,i,'contract-peer.py',[rt],rt+'-contract.out',2 if caps else 0)
            for cap in caps:fixed(cap.name)
            tag=rt

def assert_sha(x,y):
    assert sha(x)==sha(y),(x,y)
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(verify,map(int,argv[3:])))
