from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction
from pathlib import Path
from re import search,M
from subprocess import run,STDOUT
from sys import argv,executable
from time import perf_counter
from inner import author,inner_roster,read,validate,sha,S,D

cut=int(argv[1])
folder=author/f'probe{cut}-inner'
W=Path(str(cut)).resolve()
ledger=(folder/f'author-case{cut}.tsv').read_text().splitlines()
_,_,_,_,counts,order,_=inner_roster(cut)
assert len(ledger)==10
norm=r'^exact normalized real (\S+) imaginary (\S+) '
exact=lambda txt:tuple(map(Fraction,search(norm,txt,M).groups()))

def verify(desc):
    i,line=desc
    n,c,p,r,j,out=line.split('\t')
    assert i==int(n) and order[i]==(int(c),) and counts[order[i]]==int(p)
    assert out.endswith('-contract.out'),(cut,i,out)
    name=f'label-{out.removesuffix("-contract.out")}-reduced-frontier.pkl'
    source=folder/name
    state_i=read(folder/f'slice-{i}.pkl')
    identity=(state_i['conditioning'],state_i['label_partition'])
    state=validate(read(source),identity)
    start=perf_counter()
    dst=W/f'slice-{i}-exact-independent.out'
    with dst.open('xb') as outlog:
        p=run([executable,'-B',str(W/'sparse-support-replay.py'),str(i),'0',str(source),str(folder/out)],stdout=outlog,stderr=STDOUT,timeout=90)
    expected=(Fraction(r),Fraction(j))
    assert p.returncode==0,(cut,i,dst.read_text().splitlines()[-5:])
    text=dst.read_text()
    assert str(identity[0]) in text and str(identity[1]) in text
    a,b,d=map(int,search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',text,M).groups())
    assert d==D and (Fraction(a,S),Fraction(b,S))==expected==exact(text)==exact((folder/out).read_text())
    return i,order[i][0],counts[order[i]],a,b,str(expected[0]),str(expected[1]),name,sha(source),len(state['factors']),round(perf_counter()-start,6)

with ThreadPoolExecutor(max_workers=2) as ex:
    results=list(ex.map(verify,enumerate(ledger[:-1])))
all_real=sum((Fraction(p[5]) for p in results),Fraction())
all_imag=sum((Fraction(p[6]) for p in results),Fraction())
assert ledger[-1].split('\t')==['sum',str(all_real),str(all_imag)]
for result in results:print(*result,sep='\t')
print('sum',all_real,all_imag,sep='\t')
