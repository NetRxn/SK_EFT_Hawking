from pathlib import Path
from hashlib import file_digest
from fractions import Fraction as F
from subprocess import check_output
from csv import DictReader
from re import findall,M
from sys import argv
from recombine import S,combine,BASE

here=Path(__file__).resolve().parent
roots={i:Path('/private/tmp/l1-paired17-18-independent.fFI1db')/str(i) for i in (17,18)}
roots.update({i:Path('/private/tmp/l1-paired19-20-independent.93RP2l')/str(i) for i in (19,20)})
roots.update({i:here.parent/str(i) for i in (21,22)})
base=BASE/'tuple0-pair-equivalence'
out=Path('fresh')
out.mkdir(exist_ok=True)
print('cut','real','imaginary','manifest_sha256','manifest_entries',sep='\t')
for i,d in sorted(roots.items()):
    review=d/('review-manifest.portable.sha256' if i>=21 else 'review-manifest.sha256')
    evidence=check_output(['shasum','-a','256','-c',review.name],cwd=d)
    (out/f'{i}-review-manifest.verify.out').write_bytes(evidence)
    (out/f'{i}-review-manifest.sha256').write_bytes(review.read_bytes())
    with review.open('rb') as f: h=file_digest(f,'sha256').hexdigest()
    if i in (17,18,19):
        parent=Path((base/f'cut{i}-frontier.path').read_text().strip())
    else:
        parent=base/f'probe{i}-inner'
    lines=(parent/f'author-case{i}.tsv').read_text().splitlines()
    rows=[s.split('\t') for s in lines]
    assert rows[-1][0]=='sum'
    author={int(x[1]):tuple(map(F,x[3:5])) for x in rows[:-1]}
    terms=16 if i<=19 else 9
    assert len(rows)==terms+1 and len(author)==terms
    subtotal=tuple(map(F,rows[-1][1:3]))
    assert subtotal==combine(author.values())
    if i in (17,18):
        path=d/'cohort-terminal-audit.out'
        ticket=path.read_text()
        checked={int(w):(F(re),F(im)) for w,a,b,re,im in findall(r'^PASS exact label (\d+) .* raw (-?\d+) (-?\d+) normalized (\S+) (\S+)$',ticket,M)}
        for k,a,b,re,im in findall(r'^PASS exact label (\d+) .* raw (-?\d+) (-?\d+) normalized (\S+) (\S+)$',ticket,M):
            assert (F(int(a),S),F(int(b),S))==(F(re),F(im))
        assert ticket.splitlines()[-1]==f'PASS full cut {i} sum {subtotal[0]} {subtotal[1]}'
    else:
        path=d/'signed-ledger.tsv'
        if i>=21:
            data=[s.split('\t') for s in path.read_text().splitlines()[1:-1]]
            checked={int(r[1]):(F(r[5]),F(r[6])) for r in data}
            assert all((F(int(r[3]),S),F(int(r[4]),S))==checked[int(r[1])] for r in data)
        else:
            data=list(DictReader(path.read_text().splitlines(),delimiter='\t'))[:-1]
            c,re,im=('label','normalized_real','normalized_imaginary') if i==19 else ('inner_coordinate','norm_real','norm_imaginary')
            checked={int(r[c]):(F(r[re]),F(r[im])) for r in data}
            assert all((F(int(r['raw_real']),S),F(int(r['raw_imaginary']),S))==checked[int(r[c])] for r in data)
    assert checked==author,(i,checked,author)
    (out/f'{i}-independent-terms.tsv').write_bytes(path.read_bytes())
    (out/f'{i}-author-terms.tsv').write_text('\n'.join(lines)+'\n')
    print(i,*subtotal,h,len(evidence.splitlines()),sep='\t',flush=True)
