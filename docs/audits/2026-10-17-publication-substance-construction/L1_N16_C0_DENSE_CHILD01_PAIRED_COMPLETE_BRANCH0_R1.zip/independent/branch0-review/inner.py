from ast import literal_eval
from collections import Counter
from fractions import Fraction
from hashlib import file_digest
from math import prod
from pathlib import Path
from pickle import load
from re import search, M
from sys import argv

D=40512224221827380280140849737629696
S=D*16*4**64
base=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
author=base/'tuple0-pair-equivalence'
def read(p):
    with p.open('rb') as f:return load(f)
def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def positions(ax, names):
    return tuple(ax.index(w) for w in names)
def subset(key,ps):
    return tuple(key[p] for p in ps)
def validate(state,identity):
    assert (state['conditioning'],state['label_partition'])==identity
    assert prod(d for _,_,d in state['factors'])==D
    assert set(Counter(w for scope,_,_ in state['factors'] for w in scope).values())=={2}
    return state

def outer():
    axes,entries=literal_eval((base/'tuple0-branch0-pilot/pilot.roster').read_text())
    roster=dict(entries)
    assert len(roster)==len(entries)==48 and sum(roster.values())==6427904
    return axes,roster,sorted(roster,key=lambda coord:(roster[coord],coord))

def inner_roster(cut):
    start=read(author/f'combined-{cut}.pkl')
    ptr=author/f'row-cap-physical-slice-dense-label-sum{cut}-reduced.pkl'
    identity=(start['conditioning'],start['label_partition'])
    state=validate(read(ptr),identity)
    assert start['physical_cut']==state['physical_cut']
    expected=outer()[-1][cut]
    assert start['binary_sum']=={'summed_index':('R',0,0,2,0,1),'values':(0,1),'coordinate':expected}
    folder=author/f'probe{cut}-inner'
    ref=(folder/'slice-0.roster').read_bytes()
    axes,entries=literal_eval(ref.decode())
    assert axes==(('G',0,1,2),)
    left,right=[state['factors'][i] for i in state['rejected_pair']]
    dx,x,_=left;dy,y,_=right
    shared=tuple(w for w in dx if w in dy)
    xi,yi=positions(dx,shared),positions(dy,shared)
    pi=positions(dx,axes)
    ch=Counter(subset(row,yi) for row in y)
    counts=Counter()
    for row in x:
        v=ch[subset(row,xi)]
        if v:counts[subset(row,pi)]+=v
    assert len(counts)==len(entries)==9 and counts==dict(entries)
    assert sum(counts.values())==state['matched']
    order=sorted(counts,key=lambda coord:(counts[coord],coord))
    print('PASS exhaustive original paired coordinate and inner roster',cut,expected,axes,
          [(coord,counts[coord]) for coord in order],state['matched'],sha(ptr),flush=True)
    return folder,ptr,state,axes,counts,order,ref

def lift(source,child,fix):
    assert child['conditioning']==source['conditioning']+list(fix.items())
    validate(child,(child['conditioning'],source['label_partition']))
    for (scope,rows,d),(domain,table,e) in zip(source['factors'],child['factors'],strict=True):
        assert d==e and domain==tuple(w for w in scope if w not in fix)
        expect={key:z for key,z in rows.items() if all(key[j]==fix[w] for j,w in enumerate(scope) if w in fix)}
        lifted={}
        for key,z in table.items():
            coord=dict(zip(domain,key,strict=True))
            k=tuple(fix[w] if w in fix else coord[w] for w in scope)
            assert k not in lifted
            lifted[k]=z
        assert lifted==expect

if __name__=='__main__':
    cut=int(argv[1])
    folder,ptr,state,axes,counts,order,ref=inner_roster(cut)
    for i,key in enumerate(order):
        assert (folder/f'slice-{i}.roster').read_bytes()==ref
        source=folder/f'slice-{i}.pkl'
        state_i=read(source)
        lift(state,state_i,dict(zip(axes,key,strict=True)))
        print('PASS inverse signed lift',cut,i,*key,counts[key],sha(source),sum(len(t) for _,t,_ in state_i['factors']),flush=True)
        label=folder/f'label-slice-{i}-reduced-frontier.pkl'
        validate(read(label),(state_i['conditioning'],state_i['label_partition']))
