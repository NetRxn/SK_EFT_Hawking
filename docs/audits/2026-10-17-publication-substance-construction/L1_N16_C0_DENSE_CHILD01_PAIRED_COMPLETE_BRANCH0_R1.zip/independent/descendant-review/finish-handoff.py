from ast import literal_eval
from csv import DictReader
from fractions import Fraction
from hashlib import file_digest,sha256
from pathlib import Path
from re import M,findall,search
from shutil import copyfile

def read(path):
    return [line.split('\t') for line in Path(path).read_text().splitlines()]

def digest(path):
    with path.open('rb') as source:
        return file_digest(source,'sha256').hexdigest()

def load_inventory(path):
    inv={}
    for line in path.read_text().splitlines():
        h,n=line.split(maxsplit=1)
        assert n not in inv
        inv[n]=h
    return inv

def exact(text,case):
    last=text.splitlines()[-1].split('\t')
    if last[0] in ('sum','subtotal'):
        return tuple(map(Fraction,last[-2:]))
    for pat in (fr'^PASS full cut {case} sum (\S+) (\S+)$',
                fr'^PASS exact paired case {case} sum (\S+) (\S+)$',
                fr'^PASS exact paired case {case} subtotal (\S+) (\S+)$',
                fr'^PASS exact case {case} sum (\S+) (\S+)$'):
        if m:=search(pat,text,M):
            return tuple(map(Fraction,m.groups()))
    raise ValueError((case,text[-200:]))

roster=[(literal_eval(key),int(n)) for case,key,n in read('outer-roster.tsv')]
assert len(roster)==len(set(coord for coord,n in roster))==48
assert sum(n for coord,n in roster)==6427904
values={}
references={}
prior=read('verified-42.tsv')[1:]
for case,key,count,x,y,ref in prior:
    ordinal=int(case)
    assert roster[ordinal]==(literal_eval(key),int(count))
    assert ordinal not in values
    values[ordinal]=Fraction(x),Fraction(y)
    references[ordinal]=ref
assert len(values)==42
new=read('new-acceptance-inputs.tsv')
assert {int(row[0]) for row in new}==set(range(17,23)) and len(new)==6
new_roots=Path('new-reviews')
new_roots.mkdir(exist_ok=True)
for case,scratch,receipt in new:
    i=int(case)
    assert i not in values
    folder=Path(scratch)
    manifest=folder/'review-manifest.sha256'
    if not manifest.exists():
        manifest=folder/'review-manifest.portable.sha256'
    inv=load_inventory(manifest)
    for filename,h in inv.items():
        assert digest(folder/filename)==h,(case,filename)
    pairing='pair-route-audit.out'
    assert receipt in inv and pairing in inv
    fix=search(r'pilot (\(.+\)) \d+ [0-9a-f]{64}$',(folder/pairing).read_text(),M)
    assert literal_eval(fix[1])==roster[i][0]
    values[i]=exact((folder/receipt).read_text(),i)
    references[i]=f'reviewer-sha256 {digest(manifest)} {receipt}'
    dest=new_roots/case
    dest.mkdir(exist_ok=True)
    for name in (receipt,pairing,manifest.name):
        copyfile(folder/name,dest/name)

assert sorted(values)==list(range(48))
summed=tuple(sum(values[i][k] for i in range(48)) for k in (0,1))
assert summed[1]==0
with Path('tuple0-complete.tsv').open('w') as out:
    print('case','coordinate','products_per_binary_branch','normalized_real','normalized_imaginary','verified_reference',sep='\t',file=out)
    for i,(coord,n) in enumerate(roster):
        print(i,coord,n,*values[i],references[i],sep='\t',file=out)
    print('sum','-',sum(n for coord,n in roster),*summed,'all 48 exact',sep='\t',file=out)
with Path('six-tuple-complete.tsv').open('w') as out:
    print('tuple','normalized_real','normalized_imaginary',sep='\t',file=out)
    five=[(int(i),Fraction(x),Fraction(y)) for i,x,y in read('verified-other-five.tsv')]
    assert [row[0] for row in five]==list(range(1,6))
    six=[(0,*summed),*five]
    for row in six:
        print(*row,sep='\t',file=out)
    child=tuple(sum(row[i] for row in six) for i in (1,2))
    print('sum',*child,sep='\t',file=out)
print('PASS 48 distinct outer cuts, common branch work 6427904, tuple0 exact',*summed)
print('PASS six distinct tuple projections, single normalization, descendant (0,1) exact',*child)
