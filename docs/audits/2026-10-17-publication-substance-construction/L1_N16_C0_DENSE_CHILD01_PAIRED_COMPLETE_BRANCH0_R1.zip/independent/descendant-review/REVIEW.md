# Independent full retally of group 128 descendant (0,1)

The exact signed tuple 0 contribution is `-3421066796274305094734655/649037107316853453566312041152512 + 0i`. The full six-tuple descendant is `-17865027341916851312184266649/2658455991569831745807614120560689152 + 0i`.

The review reads the original binary branch checkpoint hashes from the committed middle23 artifact. Signed linearity applies to the two disjoint binary values with identical outside factors, shared representation conditions and matching denominators. The independently reconstructed support has 48 outer coordinates and 6,427,904 compatible pair products per binary branch. Every coordinate enters the sum once, with its exact paired value. Compatible products describe contraction work. The two original branch terms are already included in each signed paired value.

The 42 previously accepted terms were individually resolved to the exact archive members named in the committed coverage ledger at publication checkpoint `f728f2cae8337465c6a0d575a038de9c40ff3a5f`. Their 42-term subtotal was independently recovered. All six remaining independent manifests were checked in full, with the individual signed scalar and literal paired coordinate checked against each review's recorded source. The complete ledger contains all 48 coordinates exactly once. The raw normalization is applied once inside the term receipts, and the reducer adds those normalized rational numbers directly.

The packed nine-factor parent of descendant (0,1) decompresses to SHA-256 `b75a1f1054ba76962bca3b28fed57135b9a1d6e0be78b6ae2cdb0a65551e6e94`. Separate enumeration of all 256 assignments to the eight surviving dense-label axes gives exactly the six supported projections, with each of their nine retained-row counts. The retained modes use positive external factor `1/(16*4^64)`. Tuple 1 retallies from 36 distinct exact signed receipts with 6,838,272 compatible products. Tuples 2–4 and 5 each bind their prior independently verified raw numerators to that same normalization. The six-tuple ledger adds their exact values to the 48-cut tuple 0 subtotal without any further multiplicity or normalization.

The equality of this full descendant's signed scalar with the earlier (0,0) scalar is a comparison between separately sourced exact totals. This review closes descendant (0,1) of group 128 at its assigned arithmetic scope. Further contributions are outside this reviewed descendant.

The manifest binds the selected archive receipts and source manifest copies, both ordered ledgers, the packed label parent and the portable retally. Verify from this directory with Python 3.11 or newer.

```sh
shasum -a 256 -c handoff-manifest.sha256
python3 -B portable-retally.py | cmp - portable-retally.out
```
