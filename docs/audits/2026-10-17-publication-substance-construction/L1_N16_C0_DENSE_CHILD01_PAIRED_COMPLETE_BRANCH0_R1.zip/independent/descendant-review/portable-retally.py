from ast import literal_eval
from csv import DictReader
from fractions import Fraction
from gzip import decompress
from hashlib import sha256
from math import prod
from pathlib import Path
from pickle import loads
from re import M,findall,search

def read(path):
    return [line.split('\t') for line in Path(path).read_text().splitlines()]

def inventory(path):
    return {n.removeprefix('./'):h for h,n in map(str.split,path.read_text().splitlines())}

def checked(archive,member):
    root=Path('receipts')/archive.removesuffix('.zip')
    pins={}
    for manifest in root.glob('manifest*.sha256'):
        pins.update(inventory(manifest))
    raw=(root/member).read_bytes()
    assert sha256(raw).hexdigest()==pins[member]
    return raw.decode()

def value(text,i):
    last=text.splitlines()[-1].split('\t')
    if last[0] in ('sum','subtotal'):
        return tuple(map(Fraction,last[-2:]))
    expr=fr'^PASS full cut {i} sum (\S+) (\S+)$' if i in (17,18) else r'^exact normalized real (\S+) imaginary (\S+)'
    return tuple(map(Fraction,search(expr,text,M).groups()))

refs={}
for i,coord,n,x,y,ref in read('verified-42.tsv')[1:]:
    archive,member=ref.split(':',1)
    exact=Fraction(x),Fraction(y)
    assert value(checked(archive,member),int(i))==exact
    refs[int(i)]=(literal_eval(coord),int(n),exact)
for i,_,member in read('new-acceptance-inputs.tsv'):
    root=Path('new-reviews')/i
    [manifest]=root.glob('review-manifest*.sha256')
    pins=inventory(manifest)
    for name in (member,'pair-route-audit.out'):
        assert sha256((root/name).read_bytes()).hexdigest()==pins[name]
    coord=literal_eval(search(r'pilot (\(.+\)) \d+ [0-9a-f]{64}$',(root/'pair-route-audit.out').read_text(),M)[1])
    refs[int(i)]=(coord,None,value((root/member).read_text(),int(i)))
assert set(refs)==set(range(48))
outer=read('tuple0-complete.tsv')
assert len(outer)==50
roster=read('outer-roster.tsv')
points=set()
total=[Fraction(0),Fraction(0)]
weight=0
for index,(case,key,n,x,y,_) in enumerate(outer[1:-1]):
    assert index==int(case) and [case,key,n]==roster[index]
    coordinate,count,exact=refs[index]
    assert literal_eval(key)==coordinate and coordinate not in points
    assert count is None or int(n)==count
    assert exact==(Fraction(x),Fraction(y))
    points.add(coordinate)
    weight+=int(n)
    total=[total[i]+exact[i] for i in (0,1)]
assert len(points)==48 and weight==6427904
assert outer[-1][0]=='sum' and total==list(map(Fraction,outer[-1][3:5]))
tuple1='L1_N16_C0_DENSE_CHILD01_TUPLE1_COMPLETE_AND_PAIRED_PILOT_R1.zip'
tuple24='L1_N16_C0_DENSE_CHILD01_TUPLES2_4_R1.zip'
tuple5='L1_N16_C0_DENSE_CONDITIONED_SCALARS_R1.zip'
den=40512224221827380280140849737629696
fixed_normalization=16*4**64
full_den=den*fixed_normalization
parent_raw=decompress(Path('six-tuple-parent.pkl.gz').read_bytes())
assert sha256(parent_raw).hexdigest()==checked(tuple24,'author/parent.sha256').split()[0]
parent=loads(parent_raw)
assert prod(d for _,_,d in parent['factors'])==den
proof=literal_eval(Path('six-tuple-roster.txt').read_text())
assert {i for _,i,_,_ in proof}==set(range(6))
assert len({tuple(sorted(scope.items())) for _,_,scope,_ in proof})==6
assert proof==literal_eval(checked(tuple24,'author/label-partition-roster.txt'))
first=list(DictReader(checked(tuple1,'independent-complete/complete-ledger.tsv').splitlines(),delimiter='\t'))
assert len(first)==37 and first[-1]['case']=='total'
for i,row in enumerate(first[:-1]):
    assert i==int(row['case'])
    assert (Fraction(int(row['raw_real']),full_den),Fraction(int(row['raw_imag']),full_den))==tuple(map(Fraction,(row['normalized_real'],row['normalized_imag'])))
retallied_first=tuple(Fraction(sum(int(row[key]) for row in first[:-1]),full_den) for key in ('raw_real','raw_imag'))
previous={1:retallied_first}
for case,x,y,a,b in findall(r'^PASS independent normalized \(0,1\) tuple ([234]) (\S+) (\S+) raw (-?\d+) (-?\d+)$',checked(tuple24,'independent/audit.out'),M):
    norm=Fraction(int(a),full_den),Fraction(int(b),full_den)
    assert norm==tuple(map(Fraction,(x,y)))
    previous[int(case)]=norm
fifth=checked(tuple5,'independent/replay-child01-tuple5.out')
a,b,d=map(int,search(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',fifth,M).groups())
assert d==den
previous[5]=(Fraction(a,full_den),Fraction(b,full_den))
assert previous[5]==value(fifth,5)
six=read('six-tuple-complete.tsv')
assert len(six)==8
running=[Fraction(0),Fraction(0)]
for i,(index,x,y) in enumerate(six[1:-1]):
    assert i==int(index)
    expected=tuple(total) if i==0 else previous[i]
    assert expected==(Fraction(x),Fraction(y))
    running=[running[j]+expected[j] for j in (0,1)]
assert six[-1][0]=='sum' and running==list(map(Fraction,six[-1][1:]))
print('PASS portable tuple0 sum',*total)
print('PASS portable descendant (0,1) sum',*running)
