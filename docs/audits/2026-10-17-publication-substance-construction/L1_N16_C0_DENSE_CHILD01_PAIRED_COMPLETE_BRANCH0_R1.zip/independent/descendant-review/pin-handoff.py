from ast import literal_eval
from collections import Counter
from csv import DictReader
from functools import lru_cache
from fractions import Fraction
from gzip import GzipFile
from hashlib import sha256
from io import BytesIO
from itertools import product
from math import prod
from pathlib import Path
from pickle import loads
from re import findall
from subprocess import check_output
from zipfile import ZipFile

pub=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
commit='f728f2cae8337465c6a0d575a038de9c40ff3a5f'
repo_path='docs/audits/2026-10-17-publication-substance-construction'
pairroot=Path('/private/tmp/l1-child01-tuples234.cugnpQ')
roll='L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_C7_C14_C15_C16_R1.zip'
middle='L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_MIDDLE23_R1.zip'
tuple1='L1_N16_C0_DENSE_CHILD01_TUPLE1_COMPLETE_AND_PAIRED_PILOT_R1.zip'
tuple24='L1_N16_C0_DENSE_CHILD01_TUPLES2_4_R1.zip'
tuple5='L1_N16_C0_DENSE_CONDITIONED_SCALARS_R1.zip'
factor_den=40512224221827380280140849737629696
den=factor_den*16*4**64
receipts=Path('receipts')
receipts.mkdir(exist_ok=True)

@lru_cache
def archive(name):
    locator=f'{commit}:{repo_path}/{name}'
    archive_raw=check_output(['git','-C',str(pub),'show',locator])
    blob=check_output(['git','-C',str(pub),'rev-parse',locator],text=True).strip()
    zip=ZipFile(BytesIO(archive_raw))
    available=zip.namelist()
    inventory={}
    for filename in ('manifest.sha256','manifest-complete.sha256'):
        if filename not in available:
            continue
        raw=zip.read(filename)
        target=receipts/name.removesuffix('.zip')/filename
        target.parent.mkdir(exist_ok=True,parents=True)
        target.write_bytes(raw)
        for line in raw.decode().splitlines():
            h,p=line.split(maxsplit=1)
            p=p.removeprefix('./')
            assert p not in inventory or inventory[p]==h
            inventory[p]=h
    assert inventory,name
    print('archive',blob,sha256(archive_raw).hexdigest(),name)
    return zip,inventory

def selected(name,entry):
    zip,pins=archive(name)
    raw=zip.read(entry)
    assert sha256(raw).hexdigest()==pins[entry],(name,entry)
    target=receipts/name.removesuffix('.zip')/entry
    target.parent.mkdir(exist_ok=True,parents=True)
    target.write_bytes(raw)
    return raw.decode()

def independent_outer_roster():
    prior=selected(middle,'independent/paired-operands.sha256')
    pins={p:h for h,p in map(str.split,prior.splitlines())}
    roster_path=pairroot/'tuple0-branch0-pilot/pilot.roster'
    raw=roster_path.read_bytes()
    assert sha256(raw).hexdigest()==pins[str(roster_path)]
    axis,rows=literal_eval(raw.decode())
    assert len(rows)==len(dict(rows))==48
    counts=dict(rows)
    bases=[]
    for binary in (0,1):
        path=pairroot/f'row-cap-physical-slice-dense-label-tuple0-branch-{binary}-reduced.pkl'
        raw=path.read_bytes()
        assert sha256(raw).hexdigest()==pins[str(path)]
        state=loads(raw)
        a,b,*others=state['factors']
        assert state['rejected_pair']==(0,1)
        assert dict(state['conditioning'])['R',0,0,2,0,1]==binary and state['label_partition']['index']==0
        assert tuple(state['physical_cut'])==(('R',0,6,1,1,1),1)
        assert prod(d for _,_,d in state['factors'])==factor_den
        keys=tuple(sorted(set(a[0])&set(b[0])))
        pin=lambda scope,keys: tuple(scope.index(w) for w in keys)
        proj=lambda row,ids: tuple(row[i] for i in ids)
        ai,bi,ci=pin(a[0],keys),pin(b[0],keys),pin(a[0],axis)
        right=Counter(proj(row,bi) for row in b[1])
        left=Counter((proj(row,ai),proj(row,ci)) for row in a[1])
        frequencies=Counter()
        for (group,coordinate),n in left.items():
            if amount:=n*right[group]:
                frequencies[coordinate]+=amount
        assert frequencies==counts and sum(frequencies.values())==6427904
        bases.append((state['conditioning'],others))
    assert bases[0][0][:-1]==bases[1][0][:-1] and bases[0][1]==bases[1][1]
    print('PASS both original 48-domain branch histograms and common environment')
    return sorted(counts.items(),key=lambda row:(row[1],row[0]))

def exact_value(text):
    lines=text.splitlines()
    sums=[line for line in lines if line.startswith('sum\t')]
    if sums:
        [row]=sums
        return tuple(map(Fraction,row.split('\t')[1:]))
    matches=findall(r'^exact normalized real (\S+) imaginary (\S+)',text,flags=8)
    assert len(matches)==1,text[-120:]
    return tuple(map(Fraction,matches[0]))

def cross_check_42(roster):
    text=selected(roll,'coverage-ledger.tsv')
    lines=list(DictReader(text.splitlines(),delimiter='\t'))
    assert len(lines)==49
    total=lines.pop()
    values={}
    out=Path('verified-42.tsv')
    with out.open('w') as f:
        print('case\tcoordinate\tweight\treal\timaginary\treference',file=f)
        for number,row in enumerate(lines):
            assert int(row['outer_cut'])==number
            coord,count=roster[number]
            assert (literal_eval(row['coordinate']),int(row['pair_products_one_branch']))==(coord,count)
            if row['disposition']!='accepted':
                continue
            norm=tuple(map(Fraction,(row['real'],row['imaginary'])))
            ref=row['evidence']
            source,member=ref.split(':',1) if ':' in ref else (roll,ref)
            assert norm==exact_value(selected(source,member)),(number,source,member,norm)
            values[number]=norm
            print(number,coord,count,*norm,f'{source}:{member}',sep='\t',file=f)
    assert set(values)==set(range(48))-set(range(17,23))
    summed=tuple(sum(v[i] for v in values.values()) for i in (0,1))
    assert summed==tuple(map(Fraction,(total['real'],total['imaginary'])))
    print('PASS all 42 committed scalar references and subtotal',*summed)

def verify_six_label_census():
    source=pairroot/'nine-minimum-quotient-frontier.pkl'
    pin=selected(tuple24,'author/parent.sha256').split()[0]
    raw=source.read_bytes()
    assert sha256(raw).hexdigest()==pin
    with Path('six-tuple-parent.pkl.gz').open('wb') as output:
        with GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as zipped:
            zipped.write(raw)
    state=loads(raw)
    fixed=dict(state['conditioning'])
    assert fixed['R',1,3,0,2,1]==0 and fixed['R',0,6,1,1,1]==1
    factors=state['factors']
    assert len(factors)==9
    assert prod(d for _,_,d in factors)==factor_den
    tuple_roster=selected(tuple24,'author/label-partition-roster.txt')
    assert tuple_roster==selected(tuple5,'child01/label-partition-roster.txt')
    listed=literal_eval(tuple_roster)
    axes=sorted({w for scope,_,_ in factors for w in scope if w[0]=='L'})
    assert len(axes)==8
    assert {tuple(sorted(entry[2])) for entry in listed}=={tuple(axes)}
    loc=[]
    for scope,rows,_ in factors:
        shared=tuple(w for w in scope if w in axes)
        positions=[scope.index(w) for w in shared]
        loc.append((shared,Counter(tuple(row[p] for p in positions) for row in rows)))
    domains=[set(v[i] for s,counts in loc if w in s for i in (s.index(w),) for v in counts) for w in axes]
    assert prod(map(len,domains))==256
    actual={}
    for point in product(*[sorted(domain) for domain in domains]):
        assignment=dict(zip(axes,point,strict=True))
        counts=[count[tuple(assignment[w] for w in shared)] for shared,count in loc]
        if all(counts):
            actual[point]=counts
    assert len(actual)==len(listed)==6
    for count,index,values,rows in listed:
        point=tuple(values[w] for w in axes)
        assert count==sum(rows) and actual[point]==rows
    assert {i for _,i,_,_ in listed}==set(range(6))
    print('PASS complete original six-tuple label projection and retained rows from parent',pin)
    with Path('six-tuple-roster.txt').open('w') as out:
        print(repr(listed),file=out)
    return {index:values for _,index,values,_ in listed}

def verify_remaining_five(roster):
    p1=list(DictReader(selected(tuple1,'independent-complete/complete-ledger.tsv').splitlines(),delimiter='\t'))
    assert len(p1)==37 and p1[-1]['case']=='total'
    raws=[0,0]
    for i,row in enumerate(p1[:-1]):
        assert int(row['case'])==i
        coordinates=literal_eval(row['coordinate'])
        assert len(coordinates)==2 and int(row['cut_products'])>0
        for bit,key in enumerate(('raw_real','raw_imag')):
            raws[bit]+=int(row[key])
        assert (Fraction(int(row['raw_real']),den),Fraction(int(row['raw_imag']),den))==tuple(map(Fraction,(row['normalized_real'],row['normalized_imag'])))
    assert len({row['coordinate'] for row in p1[:-1]})==36
    assert sum(int(row['cut_products']) for row in p1[:-1])==6838272
    one=tuple(Fraction(i,den) for i in raws)
    assert one==tuple(map(Fraction,(p1[-1]['normalized_real'],p1[-1]['normalized_imag'])))
    [line]=[row for row in selected(tuple1,'tuple1-complete.tsv').splitlines() if row.startswith('COMPLETE SUM\t')]
    assert one==tuple(map(Fraction,line.split('\t')[2:]))
    exact={1:one}
    audits=selected(tuple24,'independent/audit.out')
    declared={case:tuple(map(Fraction,(x,y))) for case,x,y in (line.split('\t') for line in selected(tuple24,'exact-tuples.tsv').splitlines())}
    list_audit=findall(r'^PASS independent normalized \(0,1\) tuple ([234]) (\S+) (\S+) raw (-?\d+) (-?\d+)$',audits,flags=8)
    assert len(list_audit)==3
    for case,x,y,a,b in list_audit:
        result=Fraction(int(a),den),Fraction(int(b),den)
        assert result==tuple(map(Fraction,(x,y)))==declared[case]
        exact[int(case)]=result
    assert tuple(sum(exact[i][j] for i in (2,3,4)) for j in (0,1))==declared['tuples2-4']
    raw_log=selected(tuple5,'independent/replay-child01-tuple5.out')
    [raw]=findall(r'^PASS raw scalar numerator (-?\d+) imaginary (-?\d+) factor denominator (\d+)$',raw_log,flags=8)
    a,b,d=map(int,raw)
    assert d==factor_den
    five=Fraction(a,den),Fraction(b,den)
    assert five==exact_value(raw_log)
    line=next(line for line in raw_log.splitlines() if line.startswith('conditioning '))
    condition,label=line.removeprefix('conditioning ').split(' label partition ')
    assert dict(literal_eval(condition))|roster[5]==dict(literal_eval(condition))
    assert literal_eval(label)=={'index':5,'count':6,'values':roster[5]}
    exact[5]=five
    with Path('verified-other-five.tsv').open('w') as out:
        for case in range(1,6):
            print(case,*exact[case],sep='\t',file=out)
    print('PASS five accepted tuple scalars and single external normalization')

outer=independent_outer_roster()
with Path('outer-roster.tsv').open('w') as out:
    for number,(key,count) in enumerate(outer): print(number,key,count,sep='\t',file=out)
cross_check_42(outer)
verify_remaining_five(verify_six_label_census())
