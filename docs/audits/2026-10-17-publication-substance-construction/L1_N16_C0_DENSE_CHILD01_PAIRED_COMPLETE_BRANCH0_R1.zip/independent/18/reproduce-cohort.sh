#!/usr/bin/env bash
set -euo pipefail
d=/private/tmp/l1-cut18-frontier.8pVqU7
while IFS=$'\t' read -r label weight code timing note; do
 if [[ "$code" = 0 ]]; then
   python3 -u sparse-support-direct.py "$label" terminal "$d/$label/label-cut2-selected-reduced-frontier.pkl" > "label$label-pruned.out"
 elif [[ "$code" = 2 ]]; then
   python3 -u triangle.py "$label" join-cap-dense-label-cut2-selected-reduced.pkl > "label$label-alt-triangle.out"
 else
   printf 'Unexpected author generic exit %s for %s\n' "$code" "$label" >&2
   exit 1
 fi
done < "$d/cohort.tsv"
python3 -u cohort-cut-audit.py > cohort-cut-audit.out
python3 -u cohort-terminal-audit.py > cohort-terminal-audit.out
