from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from math import prod
import re
import sys

cut=int(sys.argv[1])
coord={17:'(65,(2,))',18:'(72,(1,))'}[cut]
pair=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
root=Path((pair/f'cut{cut}-frontier.path').read_text().strip())
direct,triangles=0,0
for row in (root/'cohort.tsv').read_text().splitlines():
    _,_,code,*_=row.split('\t')
    if code=='0': direct+=1
    elif code=='2': triangles+=1
    else: raise ValueError(row)
assert direct+triangles==16
audit=Path('cohort-terminal-audit.out').read_text().splitlines()
value,imag=audit[-1].removeprefix(f'PASS full cut {cut} sum ').split()
assert imag=='0'
shards=sum(line.startswith('PASS author shard ') for line in audit)
assert shards>=triangles
sum_matches,light,heavy=(34_473_600,1_436_400,2_872_800) if cut==17 else (31_075_200,1_285_200,2_599_200)
h=lambda path: sha256(path.read_bytes()).hexdigest()
hits=sum(len(Path(name).read_text().splitlines())
         for name in ('paired-operands-verify.out','cohort-operands-verify.out'))
pair_time=Path('combine-timing.out').read_text().strip()
reduce,cap=[float(line.split('\t')[1]) for line in Path('pair-lineage-timing.tsv').read_text().splitlines()[1:]]
timing=Path('cohort-timing.out').read_text().splitlines()
text=f"""# Independent review of original paired cut {cut}

The exact subtotal for {coord} is **{value} + 0i**. All 16 distinct signed terms independently match the complete author ledger. This accepts one paired coordinate of descendant (0,1), tuple 0.

The original eight-factor operands are disjoint on R(0,0,2,0,1) and share six environment factors and explicit matching denominators. Independently reconstructed support includes all 48 coordinates and 6,427,904 selected-pair matches per branch. This coordinate contributes 106,344 matches per branch. Independent signed Gaussian multiplication and addition reconstruct all seven combined factors, retaining 77,328 signed pair rows. Combined SHA256 {h(pair/f'combined-{cut}.pkl')}. The constructor, reduction, two retained joins and five-factor join-cap restart reproduce byte for byte. Restart SHA256 {h(pair/f'join-cap-dense-label-sum{cut}-reduced.pkl')}.

The complete G(1,0,2) partition recovers all 16 compatible values with {sum_matches:,} projected matches. Eight values contribute {light:,} each and eight contribute {heavy:,}. Each inverse lift restores the exact signed rows and positive denominators. All 48 generic preparation, reduction and contraction stages reproduced byte for byte, including {direct} exact generic terms and {triangles} saved triangle inputs.

Every exact direct term received a separate necessary-support-pruned contraction. Every triangle received an independent alternate-pivot contraction. The {shards} author pivot-0 shard receipts independently pass interval coverage and projected traffic checks, and their signed raw totals agree with the alternative exact arithmetic. The factor denominator 40512224221827380280140849737629696 and positive factor 1/(16*4^64) are applied once per term.

Scratch timings

{''.join(f'- {line}.\n' for line in timing)}
The checked constructor took {pair_time}. Outer reduction and cap took {reduce+cap:.3f} s. All {hits} operand hashes and every portable manifest entry passed checksum readback.
"""
Path('REVIEW.md').write_text(text)
