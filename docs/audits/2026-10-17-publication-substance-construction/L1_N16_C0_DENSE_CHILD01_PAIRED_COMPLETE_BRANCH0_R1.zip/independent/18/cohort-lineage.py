from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess
import sys
from ast import literal_eval
from time import perf_counter,sleep

pair=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence')
source=pair/'join-cap-dense-label-sum18-reduced.pkl'
author=Path((pair/'cut18-frontier.path').read_text().strip())
roster=literal_eval((author/'prepare.out').read_text().splitlines()[1].removeprefix('weighted roster '))
assert len(roster)==16
def completed():
    return {int(n):int(status) for n,_,status,*_ in
            (line.split('\t') for line in (author/'cohort.tsv').read_text().splitlines())}
def await_status(label):
    started=perf_counter()
    while label not in (ready:=completed()):
        assert perf_counter()-started<900, label
        sleep(2)
    status=ready[label]
    assert status in (0,2)
    return status
def check_file(a,b):
    assert sha256(a.read_bytes()).digest()==sha256(b.read_bytes()).digest(),(a,b)

def check(label):
    status=await_status(label)
    expected=author/str(label)
    here=Path(f'lineage-{label}').resolve()
    here.mkdir()
    (here/'checkpoint').mkdir()
    for name in ('reduce-label-frontier.py','contract-peer.py','peer_pair.py','checkpoint/quotient.py'):
        check_file(author/name,expected/name)
        shutil.copyfile(expected/name,here/name)
    prep='prepare-selected.py'
    shutil.copyfile(author/prep,here/prep)
    args=[str(source),str(label)]
    commands=((prep,args,'prepare',0),
              ('reduce-label-frontier.py',['selected.pkl','cut2-selected'],'reduction',0),
              ('contract-peer.py',['cut2-selected'],'contraction',status))
    times=[]
    for script,args,stage,code in commands:
        out=here/(stage+'.out')
        start=perf_counter()
        with out.open('xb') as output:
            p=subprocess.run([sys.executable,'-B',script,*args],stdout=output,stderr=subprocess.STDOUT,
                             cwd=here,timeout=180)
        times.append((stage,code,perf_counter()-start))
        assert p.returncode==code,(label,stage,p.returncode)
        check_file(out,expected/out.name)
    outputs=['selected.pkl','label-cut2-selected-reduced-frontier.pkl']
    if status==2:
        outputs.append('join-cap-dense-label-cut2-selected-reduced.pkl')
    for name in outputs:
        check_file(here/name,expected/name)
    return label,times

with ThreadPoolExecutor(max_workers=1) as pool:
    for label,times in pool.map(check,(k for k,_ in roster)):
        for stage,code,elapsed in times:
            print(label,stage,code,f'{elapsed:.6f}',sep='\t',flush=True)

statuses=list(completed().values())
assert len(statuses)==16 and statuses.count(0)==statuses.count(2)==8
