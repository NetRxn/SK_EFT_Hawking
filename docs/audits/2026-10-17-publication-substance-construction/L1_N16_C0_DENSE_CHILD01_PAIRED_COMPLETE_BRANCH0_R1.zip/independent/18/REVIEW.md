# Independent review of original paired cut 18

The exact subtotal for (72,(1,)) is **896319661658118850215/2596148429267413814265248164610048 + 0i**. All 16 distinct signed terms independently match the complete author ledger. This accepts one paired coordinate of descendant (0,1), tuple 0.

The original eight-factor operands are disjoint on R(0,0,2,0,1) and share six environment factors and explicit matching denominators. Independently reconstructed support includes all 48 coordinates and 6,427,904 selected-pair matches per branch. This coordinate contributes 106,344 matches per branch. Independent signed Gaussian multiplication and addition reconstruct all seven combined factors, retaining 77,328 signed pair rows. Combined SHA256 6980f13dfbbbee91f05321f4a044149dc9148f23109150ba468204738ffa9822. The constructor, reduction, two retained joins and five-factor join-cap restart reproduce byte for byte. Restart SHA256 bc6c2e758c9f57d9ed6b3c9b8db48929a51b9e15ca4794c4dc7939ca02836fb9.

The complete G(1,0,2) partition recovers all 16 compatible values with 31,075,200 projected matches. Eight values contribute 1,285,200 each and eight contribute 2,599,200. Each inverse lift restores the exact signed rows and positive denominators. All 48 generic preparation, reduction and contraction stages reproduced byte for byte, including 8 exact generic terms and 8 saved triangle inputs.

Every exact direct term received a separate necessary-support-pruned contraction. Every triangle received an independent alternate-pivot contraction. The 16 author pivot-0 shard receipts independently pass interval coverage and projected traffic checks, and their signed raw totals agree with the alternative exact arithmetic. The factor denominator 40512224221827380280140849737629696 and positive factor 1/(16*4^64) are applied once per term.

Scratch timings

- generic sum of elapsed seconds 461.152769.
- pruned products [6786864] seconds min/max/sum 8.8464 15.5044 90.2297.
- alt-triangle products [11059232] seconds min/max/sum 6.429 12.36 81.451.

The checked constructor took 1.581 seconds. Outer reduction and cap took 22.893 s. All 208 operand hashes and every portable manifest entry passed checksum readback.
