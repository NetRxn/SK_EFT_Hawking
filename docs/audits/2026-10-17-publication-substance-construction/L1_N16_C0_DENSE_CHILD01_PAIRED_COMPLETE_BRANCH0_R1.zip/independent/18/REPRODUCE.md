# Reproduce original paired cut 18

Use the original branch checkpoints, restored operands with matching hashes, and a fresh output directory. Author source and text receipts are included for readback. For this route, all 16 selected operands, including label 17, are under their individual numbered branches.

Run python3 pair-route-audit.py, bash combine-readback.sh, and bash pair-lineage.sh to recover the 48-coordinate supports, exact signed paired tensor, and five-factor join-cap lineage. Run python3 cohort-cut-audit.py to check the complete 16-label roster and each inverse lift. Run python3 cohort-lineage.py to reproduce all selector, peer reduction and generic contraction bytes. Run bash reproduce-cohort.sh to repeat all independent signed arithmetic, the interval and probe audits, and the exact signed retally.
