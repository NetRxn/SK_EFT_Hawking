from collections import Counter
from itertools import combinations
from pathlib import Path
import hashlib
import pickle

path=Path('/private/tmp/l1-child01-tuples234.cugnpQ/tuple0-pair-equivalence/join-cap-dense-label-sum18-reduced.pkl')
raw=path.read_bytes()
data=pickle.loads(raw)
fs=data['factors']
degree=Counter(w for axes, _, _ in fs for w in axes)
assert set(degree.values())=={2}
print('input',hashlib.sha256(raw).hexdigest(),'factors',len(fs),'rows',sum(len(rows) for _,rows,_ in fs))
candidates=[]
for i,j in combinations(range(len(fs)), 2):
    a,left,_=fs[i]
    b,right,_=fs[j]
    edge=tuple(sorted(set(a)&set(b)))
    ai=tuple(a.index(k) for k in edge)
    bi=tuple(b.index(k) for k in edge)
    count=Counter(tuple(row[k] for k in bi) for row in right)
    weighted=[(row,count[tuple(row[k] for k in ai)]) for row in left]
    support=[(row,n) for row,n in weighted if n]
    total=sum(n for _,n in support)
    candidates.append((total,i,j,edge,support))
    print('pair',i,j,'matches',total,'external axis count',len(a)+len(b)-2*len(edge))
matches,i,j,edge,support=min(candidates,key=lambda item:item[:3])
a=fs[i][0]
positions=()
while True:
    trials=[]
    for index,label in enumerate(a):
        if index in positions or label in edge:
            continue
        pp=positions+(index,)
        totals=Counter()
        for row,n in support:
            totals[tuple(row[p] for p in pp)]+=n
        trials.append((max(totals.values()),len(totals),index,totals))
    peak,count,index,totals=min(trials,key=lambda t:t[:3])
    positions+=(index,)
    assert sum(totals.values())==matches
    print('add axis',a[index],'cases',count,'peak',peak)
    if peak<=500000:
        break
axes=tuple(a[p] for p in positions)
Path('direct-cap-forecast.roster').write_text(repr((axes,sorted(totals.items())))+'\n')
print('forecast only:',len(totals),'cases',min(totals.values()),peak)
