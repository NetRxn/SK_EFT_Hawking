from ast import literal_eval
from csv import DictReader
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import sys

audit=Path(sys.argv[1])
coverage=Path(sys.argv[2])
heavy='L1_N16_C0_DENSE_CHILD01_TUPLE0_PAIRED_HEAVY47_R1.zip'
t1='L1_N16_C0_DENSE_CHILD01_TUPLE1_COMPLETE_AND_PAIRED_PILOT_R1.zip'
middle='L1_N16_C0_DENSE_CHILD01_TUPLES2_4_R1.zip'
t5='L1_N16_C0_DENSE_CONDITIONED_SCALARS_R1.zip'
sibling='L1_N16_C0_DENSE_CHILD00_COMPLETE_R1.zip'

def read(archive,member):
    with ZipFile(audit/archive) as z:
        data=z.read(member)
    return data.decode('utf-8',errors='strict'),f'{archive}::{member}',sha256(data).hexdigest()
def sum_exact(values):
    return tuple(sum(v[i] for v in values) for i in (0,1))
source,_,_=read(heavy,'author/tuple0-branch0-pilot/pilot.roster')
axes,support=literal_eval(source)
expected=sorted(support,key=lambda row:(row[1],row[0]))
with coverage.open() as f:
    records=list(DictReader(f,delimiter='\t'))
assert len(records)==49
assert [r['disposition'] for r in records[:-1]]==['accepted']*48
assert records[-1]['outer_cut']=='PARTIAL_SUM' and records[-1]['disposition']=='48/48'
assert [int(r['outer_cut']) for r in records[:-1]]==list(range(48))
assert len(expected)==len(set(k for k,n in expected))==48
assert sum(n for k,n in expected)==6427904
for r,(k,n) in zip(records[:-1],expected,strict=True):
    assert (literal_eval(r['coordinate']),int(r['pair_products_one_branch']))==(k,n)
    assert r['evidence']
zero=sum_exact([tuple(Q(r[k]) for k in ('real','imaginary')) for r in records[:-1]])
assert zero==tuple(Q(records[-1][k]) for k in ('real','imaginary'))
values={0:(*zero,coverage.name,sha256(coverage.read_bytes()).hexdigest())}
text,ref,h=read(t1,'independent-complete/complete-ledger.tsv')
lines=[row.split('\t') for row in text.splitlines()]
rows=lines[1:-1]
summary=lines[-1]
assert len(rows)==36 and [int(r[0]) for r in rows]==list(range(36)) and summary[0]=='total'
assert sum(int(r[2]) for r in rows)==int(summary[2])==6838272
assert len(set(r[1] for r in rows))==36
term=sum_exact([tuple(Q(r[i]) for i in (8,9)) for r in rows])
assert term==tuple(Q(summary[i]) for i in (8,9))
values[1]=(*term,ref,h)
text,ref,h=read(middle,'exact-tuples.tsv')
parts=[row.split('\t') for row in text.splitlines()]
assert [r[0] for r in parts]==['2','3','4','tuples2-4']
for row in parts[:-1]:
    values[int(row[0])]=(Q(row[1]),Q(row[2]),ref,h)
assert sum_exact([values[i] for i in (2,3,4)])==tuple(map(Q,parts[-1][1:]))
text,ref,h=read(t5,'accepted-conditioned-values.tsv')
[five]=[r for r in DictReader(text.splitlines(),delimiter='\t')
        if (r['internal_conditioning'],r['label_tuple'])==('0,1','5')]
values[5]=(Q(five['real']),Q(five['imaginary']),ref,h)
assert tuple(values)==tuple(range(6))
child01=sum_exact(list(values.values()))
text,ref,h=read(sibling,'independent/descendant00-independent.tsv')
other=list(DictReader(text.splitlines(),delimiter='\t'))
assert [r['tuple'] for r in other]==['0','1','2','3','4','5','sum']
child00=sum_exact([tuple(Q(r[k]) for k in ('normalized_real','normalized_imaginary')) for r in other[:-1]])
assert child00==tuple(Q(other[-1][k]) for k in ('normalized_real','normalized_imaginary'))
branch=sum_exact([child00,child01])
print('scope','normalized_real','normalized_imaginary','source','source_sha256',sep='\t')
for i,fields in values.items():
    print(f'child01 tuple {i}',*fields,sep='\t')
print('child01',*child01,'sum of disjoint tuples 0–5','',sep='\t')
print('child00',*child00,ref,h,sep='\t')
print('first-index branch0',*branch,'sum of disjoint child00 and child01','',sep='\t')
