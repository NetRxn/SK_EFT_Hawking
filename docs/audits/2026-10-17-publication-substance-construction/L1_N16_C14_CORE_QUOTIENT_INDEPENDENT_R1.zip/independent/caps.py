from pathlib import Path
import json,sys
a=Path(sys.argv[1])
for name,w,r,o,peak in [('quotient',1086480,39679,1324635,27639808),('coalescence',1203822,182290,6822011,124502016)]:
    j=json.loads((a/f'{name}.json').read_text())
    caps=j['caps']
    assert j['meters']==dict(work=w,rows=r,output=o)
    assert sum(j['work'].values())==w
    assert j['peak_rss_bytes']==peak<caps['rss']==384*1024**2
    assert all(j['meters'][k]<caps[k] for k in j['meters'])
    assert (caps['work'],caps['rows'],caps['output'],caps['scalar'])==(4_000_000,200000,32*1024**2,2**61-1)
    assert not j['full_representative_evaluated']
qfiles=[*a.glob('quotient-*.jsonl'),a/'orientation-quotient.jsonl',a/'components.jsonl']
assert sum(p.stat().st_size for p in qfiles)==1324635
assert (a/'coalesced-environment.jsonl').stat().st_size==6822011
print('quotient and coalescence receipts, actual serialized byte totals and caps match')
