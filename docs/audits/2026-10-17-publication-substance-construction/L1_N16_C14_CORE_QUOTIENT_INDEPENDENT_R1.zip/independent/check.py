from collections import Counter,defaultdict
from functools import cache
from itertools import product
from math import gcd,prod
from pathlib import Path
import json,sys
B,E,D,R3,R12,STAR=map(Path,sys.argv[1:])
def rows(path):
    for line in path.open():yield json.loads(line)
def f(v):return tuple(map(f,v)) if isinstance(v,(list,tuple)) else v
def j(path):return json.loads(path.read_text())
groups={
 'rank4':((6,5),D/'rank4-closure-exterior.jsonl',2),
 'rank12':((14,13),R12/'rank12-closure.jsonl',6),
 'rank3':((11,7),R3/'rank3-compact.jsonl',5),
 'rank10':((10,),D/'s4-10-axis2-exterior.jsonl',1),
 'rank9':((9,),D/'s4-9-axis3-exterior.jsonl',1)}
names=tuple(groups)
boundary=(1,2,5,6,7,9,10,11,13,14)
atom=((3,5,10,12),(48,80,160,192))
full=(15,240)
look={}
rays={}
for name,(ranks,src,split) in groups.items():
    ray={k:f(t) for k,t in rows(B/f'quotient-{name}-rays.jsonl')}
    look[name]={tuple(k):tuple(t) for k,t in rows(B/f'quotient-{name}-map.jsonl')}
    rays[name]=ray
    assert len(set(ray.values()))==len(ray)
    assert set(ray)==set(range(len(ray)))
    for t in ray.values():
        vector=[v for _,z in t for v in z if v]
        assert vector[0]>0 and gcd(*vector)==1
    reconstruct={k+ext:tuple(w*x for x in z) for ext,(id,w) in look[name].items() for k,z in ray[id]}
    exact={tuple(k):tuple(z) for k,z in rows(src)}
    assert reconstruct==exact and all(w for _,w in look[name].values())
    assert len(look[name])==(44 if len(ranks)==2 else 8)
    assert len(ray)==(11 if len(ranks)==2 else 6)
print('all five complete signed core maps reconstructed exactly from the primitive serialized rays',flush=True)

frozen_components={}
for id,sig,labels,table in rows(B/'components.jsonl'):
    s=f(sig)
    assert s not in frozen_components
    frozen_components[s]=(id,f(labels),{tuple(k):z for k,z in table})
assert len(frozen_components)==1456
assert {v[0] for v in frozen_components.values()}==set(range(1456))
quot={i:(f(fixed),sc,set(ids)) for i,fixed,sc,ids in rows(B/'orientation-quotient.jsonl')}
assert len(quot)==2604

@cache
def component(signature):
    vals=[]
    for a,b in signature:
        x,y=(atom[t[1]] for t in (a,b))
        vals.append(((x[0],y[3],2),(x[3],y[0],2),*((u,v,-1) for u in x[1:3] for v in y[1:3])))
    ends={t for p in signature for t in p}
    ranks={t[0] for t in ends}
    scope=[(name,rr) for name,(rr,_,_) in groups.items() if set(rr)<=ranks]
    half=tuple(sorted(t for t in ends if t[0] in (1,2)))
    labels=tuple([('ray',n) for n,_ in scope]+[('half',*t) for t in half])
    accepted=0
    result=defaultdict(int)
    for selection in product(*vals):
        masks={t:m for (a,b),(u,v,_) in zip(signature,selection,strict=True) for t,m in ((a,u),(b,v))}
        ix={r:m for (r,h),m in masks.items() if r not in (1,2)}
        try:
            join=[look[n][tuple(ix[r] for r in rs)] for n,rs in scope]
        except KeyError:
            continue
        accepted+=1
        keys=tuple(i for i,w in join)+tuple(masks[t] for t in half)
        result[keys]+=prod(v[2] for v in selection)*prod(w for i,w in join)
    result={k:v for k,v in result.items() if v}
    _,fs,ft=frozen_components[signature]
    assert labels==fs and result==ft
    return labels,result,accepted

def partition(paths):
    # Use set partitions of path positions, joining only where an actual
    # two-mask core slice needs endpoints of two different paths.
    owner={r:i for i,pp in enumerate(paths) for r,h in pp if r not in (1,2)}
    ids=list(range(len(paths)))
    for n,(rr,_,_) in groups.items():
        wanted={ids[owner[x]] for x in rr}
        ids=[min(wanted) if x in wanted else x for x in ids]
    return [tuple(sorted(paths[k] for k,x in enumerate(ids) if x==i)) for i in sorted(set(ids))]

env=defaultdict(int)
raw_orients=[]
seen=set()
hist=Counter()
term_count=semicount=0
first=None
for i,fixed,cycle,paths in rows(E/'exterior-orientations.jsonl'):
    fixed=f(fixed)
    raw={}
    for a,b,table in paths:
        aa,bb=tuple(a),tuple(b)
        raw[aa,bb]={(u,v):v0 for u,v,v0 in table}
    raw_orients.append((fixed,cycle,raw))
    factor=cycle
    for (a,b),t in raw.items():
        x,y=atom[a[1]],atom[b[1]]
        assert not t[x[0],y[3]]%2
        mult=t[x[0],y[3]]//2
        assert t=={(x[0],y[3]):2*mult,(x[3],y[0]):2*mult,**{(u,v):-mult for u in x[1:3] for v in y[1:3]}}
        factor*=mult
    ps=partition(tuple(raw))
    assert max(map(len,ps))<=4
    seen.update(ps)
    hist.update(map(len,ps))
    assert quot[i]==(fixed,factor,{frozen_components[s][0] for s in ps})
    parts=[component(s) for s in ps]
    z=prod(n for _,_,n in parts)
    if first is None and semicount+z>4_000_000:
        first=dict(orientation=i,previous=semicount,terms=z,prospective=semicount+z,cap=4_000_000)
    semicount+=z
    for q in product(*(list(t.items()) for _,t,_ in parts)):
        coeff=factor*prod(w for _,w in q)
        state={label:value for (labels,_,_),(key,_) in zip(parts,q,strict=True) for label,value in zip(labels,key,strict=True)}
        old=dict(fixed)
        for l,x in state.items():
            if l[0]=='half':
                s,h=l[1:]
                assert x in atom[h] and not old.get(s,0)&x
                old[s]=old.get(s,0)|x
        assert set(old)=={1,2}
        k=tuple(state['ray',n] for n in names)+(old[1],old[2])
        env[k]+=coeff
        term_count+=1
assert len(seen)==1456 and len(raw_orients)==2604 and hist=={1:2556,2:1898,3:1152,4:836}
assert semicount==24847680 and first==j(B/'semijoin.json')['first_prospective_flat_refusal']
assert term_count==810460 and all(env.values()) and len(env)==178150
assert dict(env)=={tuple(k):z for k,z in rows(B/'coalesced-environment.jsonl')}
print('all 1456 components and 2604 orientations match; 24847680 support semijoin, 810460 coalescing visits, 178150 exact signed rows',flush=True)

def native_coeff(q):
    total=0
    for fixed,cycle,tables in raw_orients:
        if any(q[r]!=m for r,m in fixed):continue
        assigned=dict(fixed)
        weight=cycle
        for (a,b),t in tables.items():
            u,v=(q[s]&full[h] for s,h in (a,b))
            if (u,v) not in t:break
            for (s,h),m in ((a,u),(b,v)):assigned[s]=assigned.get(s,0)|m
            weight*=t[u,v]
        else:
            if assigned==q:total+=weight
    return total

for c in j(B/'coalescence.json')['controls']:
    k=tuple(c['boundary'])
    choices=[[(m,w) for m,(ii,w) in look[n].items() if ii==i] for i,n in zip(k[:5],names,strict=True)]
    total=wrong=0
    assert prod(map(len,choices))==16
    for variant in product(*choices):
        q={1:k[-2],2:k[-1]}
        for n,(m,w) in zip(names,variant,strict=True):q.update(zip(groups[n][0],m,strict=True))
        w=prod(p[1] for p in variant)
        z=native_coeff(q)
        total+=w*z
        wrong+=abs(w)*z
    assert env[k]==total==c['exact_coalesced_numerator']==2251799813685248
    assert wrong==c['discarded_ray_weight_sign_numerator']==c['reverse_one_site_orientation']==-total
print('five independent native signed-boundary controls and adverse weight signs matched',flush=True)

join=j(B/'join-preflight.json')
freq=[Counter(k[i] for k in env) for i in range(7)]
for i,n in enumerate(names):
    visits=sum(num*len(rays[n][id]) for id,num in freq[i].items())
    record=join['single_environment_factor_joins'][n]
    assert visits==record['exact_pair_product_visits']
    assert (visits>4_000_000)==record['exceeds_work_cap']
for site in (1,2):
    support=Counter(k[2] for k,_ in rows(R3/f'merge-rank{site}.jsonl'))
    assert sum(num*support[old] for old,num in freq[site+4].items())==join['single_environment_factor_joins'][f'rank{site}_merge']['exact_pair_product_visits']
supports=defaultdict(set)
for (a,b,c,d),_,_ in rows(STAR/'site-factors.jsonl'):
    for i,j0 in product(rays['rank10'],rays['rank9']):
        if (c,) in dict(rays['rank10'][i]) and (d,) in dict(rays['rank9'][j0]):supports[i,j0].add((a,b))
v=join['rank8_pair_projection']
assert len(supports)==24 and v["scope_pairs"]==36 and sum(map(len,supports.values()))==228
assert sum(len(supports[k[3:5]]) for k in env)==v['exact_pair_product_visits']==1517244
occupied=set()
for k in sorted(env):
    new={(*k[:3],a,b,*k[5:]) for a,b in supports[k[3:5]]}
    if len(occupied)+len(new-occupied)>200_000:
        assert list(k)==v['first_prospective_output_refusal']['environment_key']
        assert v['first_prospective_output_refusal']['prospective']==200001
        break
    occupied|=new
else:raise AssertionError('no row refusal')
print('all schedule-specific projected joins, 228 rank8 supports and 200001-row refusal reproduced',flush=True)

g=j(B/'graph.json')
eg=j(E/'graph.json')
assert g['combined_denominator']==eg['combined_denominator']
assert g['exact_denominator_before_exponential_divisor']==eg['exact_denominator_before_exponential_divisor']
assert g['external_exponential_divisor']==512 and g['scalar_numerator_multiplier']==24**5
assert g['boundary']==[]
assert g['factor_keys']['coalesced_environment']==[*(f'ray_{n}' for n in names),'remote1','remote2']
assert not join['coefficient_join_executed']
print('fully specified closed graph remains unevaluated; inherited normalization unchanged',flush=True)
changes={'rank4_closure':'rank4','rank12_closure':'rank12','rank3_compact':'rank3','rank8_edge2':'rank10','rank8_edge3':'rank9'}
assert g['quotient_ray_files']=={k:f'quotient-{n}-rays.jsonl' for k,n in changes.items()}
replacement={k:(v[:groups[changes[k]][2]]+[f'ray_{changes[k]}'] if k in changes else v) for k,v in eg['factor_keys'].items()}
assert {k:v for k,v in g['factor_keys'].items() if k!='coalesced_environment'}==replacement
assert all(n>=2 for n in Counter(x for v in g['factor_keys'].values() for x in v).values())
