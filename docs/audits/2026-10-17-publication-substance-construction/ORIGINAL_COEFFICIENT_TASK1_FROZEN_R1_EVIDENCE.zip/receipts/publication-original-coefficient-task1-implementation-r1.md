# Original coefficient Task1 implementation R1

**Task1 implementation frozen for different independent source/scientific review and ROOT reconciliation.** Only the three assigned PRIMARY paths changed. No Git mutation, commit, controller/Lean/build/cache/dependency/registry/notebook/roadmap edit occurred.

Final bounded verification: `.venv/bin/python -m pytest tests/test_original_coefficients.py tests/test_dependency_declaration.py -q -rP` → exit0, 29 passed in 8.52s. This is 24 Task1 cases and 5 dependency cases, not full-tree acceptance. `git diff --check` → exit0.

## Implemented scope

- Exact normalized four-int QComplex; immutable sparse polynomial/exterior algebra with real quaternion/h versus complex source conjugation; per-scalar product-accumulation scopes and recursive unique-object byte accounting.
- Explicit independently validated temporal_axis/cut metadata (defaults C3/M_N0), transported as a world index; unreflected coframe/action unchanged when only cut changes; no physical kernel/adjoint inferred.
- Frozen true four-torus with paired +/- boundaries, independent anchored Spin4 direct-sum L/R links, explicit generator/Berezin order, C and Euclidean M_N conventions, both printed/closed labels, reflection embedding metadata.
- Canonical exact C gamma/chirality and plus-i quaternion matrices, all four signed quarter coframe blocks, additive assembly on self/coincident neighbors, original 4V default cutoff unchanged.
- Canonical independent printed/closed ordered words and complete raw S4/S2 factor lists, preserved scalar/diagonal trace terms and all anchor incidence before antisymmetrization. No coefficient filtering or integrated oracle.
- M_N/C dictionary for coordinates/extents/boundaries/anchors, unchanged spinor/chiral indices, coframes, world/internal epsilons, g1/g2, J/h, Q/H independent pairs, ordered frame coordinates/contact labels, phase/current site relabeling, reflection embedding, variance and Berezin orientation; nonzero unsquared g2 and g1 pre-Haar controls.
- Actual N16 coframe/Dirac structural counts, S2 eight-anchor and site twenty-link support certificates, centered local degree certificate explicitly not production-authorized, four directed determinant blocks with explicit permutation signs and complete Boolean row-subset reachability.

N16 construction returns 256 coframes, 1024 increments, 8192 scalar-slot writes, 4096 collected A slots, 16384 quaternion-coordinate terms, and 512 actual symbolic Dirac entries (8/row). Complete raw source term counts are 384 S4 and 6144 S2; each N16 S2 factor touches 8 distinct anchors, and a site factor touches 20. Four determinant blocks have explicit row/column signs and the complete 53137-mask/200076-transition support certificate per block. These are structural/Boolean counts, not integrated coefficient supports.

## Red/green and adverse evidence

- {'red': 'publication-task1-red.log', 'observed': 'Collection fails: missing original_gamma API, before implementation', 'green': '13 passed in 4.43s'}
- {'red': 'publication-task1-red2.log', 'observed': '3 failed, 15 passed: missing ScalarCost context, erroneous real J conjugation, mutable regulator extent/boundary lists', 'green': '18 passed in 4.54s'}
- {'red': 'publication-task1-red3.log', 'observed': '2 failed, 20 passed: missing factor_support and legacy_quaternion_to_c APIs', 'green': '22 passed in 4.92s'}
- {'additional_control': 'Supplied exact permutation-matrix Berezin orientation, independent of original action/W/measure', 'final': '24 Task1 +5 dependency cases pass'}
- {'red': 'publication-task1-red4-cut.log', 'observed': 'ROOT intake requested independent temporal_axis; missing field failed before fix', 'green': '29 passed final bounded run', 'preserved_pre_intake_receipt': '/tmp/publication-task1-pre-intake-tests-receipt.json'}

- Dropping last quarter increment or assigning only last same-slot block breaks one-site identity-link cancellation.
- Distinct L2 anchors retained; forward/backward q0 difference explicitly tested, rather than replacing them with one link.
- Odd axis permutation with fixed gamma5 flips S2 and g2 before Haar; nonzero g1 and unsquared g2 controls reject silent sign loss.
- Actual C3 compact-link X_(2,0)X_(3,1) coefficient is -2*g2 for both words.
- Noncentered frame support rejected, odd periodic extent refused for bipartite partition, zero extents/bad boundary signs/unknown words rejected, scalar budget refuses incomplete product.
- Complex J conjugation and mutable input poisoning were genuine failures corrected in witnessed RED-to-GREEN runs.

Every Task1 test scopes expanded scalar polynomial products at 1,000,000; largest observed count is 70,016. The complete actual symbolic 64x64 Dirac fixture has 32768 scalar coefficient slots and 9,131,398 unique object-graph bytes. Dummy 1024-bit scalar records measured 848.952 bytes/record over1000 records, below the1536-byte model. These are object-graph measurements, not RSS or proof of a future full contraction fit. No hidden polynomial multiplication is priced as one scalar.

## Source provenance and exact boundary

- coframe: Actual current FiniteGrassmannCoframe gamma/gamma5/dirac/coframe/hopping/hopping_reconstructs_coframe definitions; original ADW_COMPOSITE_SOURCES Eq1.
- words_action: Actual current FiniteGrassmannSourceAuxiliary plaquettePrinted/plaquetteClosed/cosmological/einsteinCartan_ordered/coframe_source_evaluation and explicit source -2*g2 controls.
- audit_reuse: Read checked l1_full_action_reference construction; reimplemented pure exact sparse operations in owned module. Read minus-i l1_direct_a/b kernels, applied explicit vector sign map; did not import their scientific programs or private_pairs top-level computation.
- accepted_specs: Frozen R2 narrative/structured construction and both independent physics/cost reviews; actual referenced original auxiliary/composite/Eq7 design/source review and relevant metric reflection scope.
- formal_boundary: No new Lean proof/name fabricated. Existing coframe/C3 declarations ground definitions at exact scope. Quaternion-coordinate parametrization, executable M/C transport/local8, Eq9 matrix-bilinear and Eq10 Berezin/determinant bridges still require ROOT Stage2/3 treatment; Python controls are not kernel proofs.

metric_M in this API is Euclidean M_N, an odd relabeling of source_C. It is not Executor Lorentz label L_P or its original WORLDcut P0. A displayed Gamma_LP0 can agree entrywise with gammaC3/gammaM_N0 after Executor explicit S rotation; this does not identify complete cut/field/source/antilinear-reflection maps or grant kernel/physical certificate cross-consumption.

The local centered degree8 certificate is combinatorial and explicitly not production-authorized; the production default remains4V=64 on N16 and4 on the true one-site carrier. No W/Haar/original coefficient/full-Z/phase/campaign run occurred. No future Task2/3 test is silently skipped or marked passed.

## Frozen source

- `src/core/formulas.py`: SHA256 `0293e17b4b0c73aa2e39d8741bb631acea1f30a45bf87ede9cde6375cdcd696d`, 508756 bytes, 13171 lines.
- `src/vestigial/original_coefficients.py`: SHA256 `dbda2b494204116771f44ffca72757b14f79a44ddb0dc22faf7ab1ce020323dd`, 23388 bytes, 657 lines.
- `tests/test_original_coefficients.py`: SHA256 `d50977905e85a9143d60a09291b766186f3b4282d3aba1e34be0a8f2c348794f`, 19241 bytes, 382 lines.

Exact unified diff: `/tmp/publication-original-coefficient-task1-implementation-r1.diff`, SHA256 `6acaf66795630d0a02a993157b101f7e9c51297619cc373f609bfd323722b9dd`. Full receipt, raw-log hashes and per-test scalar counts are in companion JSON. ROOT intake correction preserved pre-intake report/test hashes in JSON. Source HEAD remains `056ccb9f08454238934977de4bb6548d18c6275e`.

## Continuity and required successor

First SAME packet check: fresh=true, changed=[], exit0. Final SAME packet check: fresh=false, changed=[owned-files,source], exactly expected owned edits. Every bound authority hash is unchanged. Snapshot was not refreshed; ROOT must explicitly reconcile.

- Task2: Exact family-graded raw source jets/minors/Hermite W/Gaussian/Haar with complete contacts and refusal APIs, then separately admitted full original one-site direct versus W4 control: all 3876 source quartics, 740 center-compatible slots, complete interacting denominator and T/H/frame jets, both words and variances2/3; retain full4029 W entries/23504 queries. No generic odd-metric or derivative-order filter.
- Task3: Complete original N16 edge invariant 36-entry tables by independent direct/minor routes, full24 minor roster/projectors, actual F60/G52 and temporal/spatial contacts, all exclusions/anchors/chiral loops under separate70M allocation and source/scientific review. Expected45/4,12,etc remain regression outputs, not producer inputs.
- Task4: Exact split-factor full denominator/source frontier and viable complete allocation with bounds, then actual full coefficient computation and certified nonzero normalization; all physical source/state/adjoint/B3/window/modes/matter/transport/limits obligations remain unchanged.

## Preserved adverse observations and verification limits

- ROOT intake after first source freeze requested explicit temporal_axis independent of unreflected convention and fully qualified real Lean names. New cut test failed first; implementation corrected and final full bounded suite rerun. Pre-intake report and raw tests are preserved.
- Initial standalone .venv/bin/python -S storage probe failed ModuleNotFoundError numpy because existing src.vestigial.__init__ eagerly imports reduced scientific package modules; corrected to normal existing .venv, without install or package edits. No simulation ran.
- First guessed primary audit path was absent; actual frozen scientific audit inputs were read from the referenced cumulative checkpoint.
- Some broad combined input displays truncated. Narrower narrative/scientific-field reads and complete JSON parsing/hash checks supplied actual acceptance inputs; no claim derives from truncated output.
- Early shell test wrappers returned tail status rather than preserving pytest return code; raw red/green logs retained. Final independent subprocess receipt preserves pytest exit_code=0.
- No bare full pytest or verify_scope run: both exceed this explicit bounded Task1-only allocation; ROOT owns these broader gates. No full source/scientific review or native/full-tree readiness claim.
