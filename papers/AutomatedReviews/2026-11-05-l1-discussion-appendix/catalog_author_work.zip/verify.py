import json,re,sys,hashlib,subprocess
from pathlib import Path
from collections import Counter
R=Path.cwd();O=Path('/tmp/l1-discussion-catalog-work-20261105');B=Path('/tmp/l1-discussion-predecessor-20261105');P=Path('/tmp/l1-discussion-catalog-proposal-20261105.json');sys.path.insert(0,str(R/'scripts'))
from sentence_state import compute_sentence_id,normalize_quote,validate_claims_review
p=json.loads(P.read_text());b=json.loads((B/'claims_review.json').read_text());t=(R/'papers/L1/paper_draft.tex').read_text();c=json.loads((O/'coverage.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();v=list(t);last=0;ords=Counter();masked=re.sub(r'\\label\{[^}]*\}',lambda m:' '*len(m[0]),t)
for i,s in enumerate(p['sentences']):
 hits=list(re.finditer(r'\s+'.join(map(re.escape,s['quote'].split())),masked));assert len(hits)==1;(a,z)=hits[0].span();assert a>=last;last=z
 sec='abstract'
 for m in re.finditer(r'\\section\{([^{}]*)\}',t[:a]):sec=m[1]
 ords[sec]+=1;sid,n,h=compute_sentence_id('L1',sec,s['quote']);assert (s['id'],s['quote_normalized'],s['section'],s['section_ordinal'])==(sid,n,sec,ords[sec]);assert s['meta']['review_unit']==i
 assert s['tex_line_start']==t.count('\n',0,a)+1 and s['tex_line_end']==t.count('\n',0,z-1)+1
 for j in range(a,z):v[j]='\n' if t[j]=='\n' else ' '
g=''.join(v)[t.index('\\begin{abstract}')+len('\\begin{abstract}'):t.index('\\begin{thebibliography}')]
g=re.sub(r'(?m)(?<!\\)%[^\n]*','',g)
for pat in [r'\\(?:section|subsection|paragraph|label)\{[^{}]*\}',r'\\(?:begin|end)\{[^{}]*\}(?:\[[^\n]*\])?',r'\\includegraphics(?:\[[^\n]*\])?\{[^{}]*\}',r'\\(?:centering|maketitle|item|appendix)\b',r'\\caption\{',r'[{}]']:g=re.sub(pat,'',g)
assert not g.strip(),g.strip()
assert len({s['id'] for s in p['sentences']})==len({normalize_quote(s['quote']) for s in p['sentences']})==len(p['sentences'])
assert p['review_evidence']['discussion_appendix_refresh']['all_134_predecessor_records']==b['sentences']
for k in ['blocking_issues','non_blocking_followups','non_reproducing_prior_findings','reproducing_prior_findings','cross_bundle_findings']:assert p[k]==b[k]
for k in ['review_scope','review_evidence']:assert {x:y for x,y in p[k].items() if x not in ['discussion_appendix_refresh','discussion_appendix_r2']}==b[k]
pins=json.loads((B/'PINS.json').read_text())['files']
for f in ['claims_review.json','prose_state.json','audit_log.jsonl']:assert sha(R/'papers/L1'/f)==pins[f]['sha256'],f
assert not validate_claims_review(p)
for args,name in [(['validate',str(P)],'schema-validation.json'),(['ingest_agent_run',str(P),'--dry-run'],'ingest-dry-run.json')]:
 r=subprocess.run(['python3','scripts/sentence_state.py']+args,capture_output=True,text=True);assert r.returncode==0,r.stderr;(O/name).write_text(r.stdout)
(O/'verification.json').write_text(json.dumps({'current_source_sha256':sha(R/'papers/L1/paper_draft.tex'),'proposal_sha256':sha(P),'units':len(p['sentences']),'unique_actual_bindings_IDs_quotes':True,'actual_source_sections_ordinals_spans_order':True,'uncovered_nonstructural_body_text':g.strip(),'full134predecessors_preserved':True,'4blockers54candidates_prior_history_human_audit_preserved':True,'schema_pass':True,'existing_writer_dryrun_only':True},indent=2)+'\n')
print((O/'verification.json').read_text())
