import copy,json,re,sys,hashlib,datetime
from pathlib import Path
from collections import Counter
R=Path.cwd();O=Path('/tmp/l1-discussion-catalog-work-20261105');sys.path.insert(0,str(R/'scripts'))
from sentence_state import compute_sentence_id,normalize_quote,validate_claims_review
p=Path('/tmp/l1-discussion-catalog-proposal-20261105.json');d=json.loads((O/'proposal-80d48.json').read_text());original=copy.deepcopy(d);t=(R/'papers/L1/paper_draft.tex').read_text();masked=re.sub(r'\\label\{[^}]*\}',lambda m:' '*len(m[0]),t);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();run='claims-reviewer-v2:2026-11-05:l1-discussion-appendix-catalog-r2'
replacements={
95:('The full additive\nexclusion criterion, near-boundary restoration argument and supporting\nchecks are given in \\hyperref[sec:support]{the appendix}.','Actual named same-file appendix hyperlink replaces empty unnumbered numeric section reference; supporting additive/nearboundary/product contents unchanged. Source-route transition, not a new physics result.'),
145:('The following software and proof records support reproducibility of\nthe stated algebraic calculation.','Reader-facing recorded software/proof support for the stated algebraic calculation; historical inventory is not fresh native execution or physical normalization/mode/state evidence.'),
146:('They establish neither the microscopic\nresponse normalization nor a physical mode or state.','Recorded software/proof checks establish conditional algebra only; microscopic response normalization and physical mode/state construction remain original BUILD. No execution or readiness upgrade.')}
changes=[];ids={}
for s in d['sentences']:
 wi=s.get('meta',{}).get('walker_unit')
 if wi in replacements and s['agent_run_id']=='claims-reviewer-v2:2026-11-05:l1-discussion-appendix-catalog-r1':
  q,note=replacements[wi];oldid=s['id'];sid,norm,h=compute_sentence_id('L1',s['section'],q)
  s.update(id=sid,quote=q,quote_normalized=norm,agent_notes=note,agent_run_id=run,rewrite_of=oldid);s['raw_id_parts'].update(quote_hash=h);s['meta']['source_sha256']=sha(R/'papers/L1/paper_draft.tex');s['meta']['r2_prior_id']=oldid;s['meta']['r2_scope']='Only physical-link/reproduction-wording corrections; all scientific support/conditions unchanged.';ids[oldid]=sid
  changes.append({'walker_unit':wi,'prior_r1_id':oldid,'current_r2_id':sid,'quote':q,'verdict':s['agent_verdict'],'assessment':note})
assert len(changes)==3,changes
c=[];ords=Counter()
for i,s in enumerate(d['sentences']):
 ms=list(re.finditer(r'\s+'.join(map(re.escape,s['quote'].split())),masked));assert len(ms)==1,(i,s['quote']);a,b=ms[0].span();ords[s['section']]+=1;s.update(tex_line_start=t.count('\n',0,a)+1,tex_line_end=t.count('\n',0,b-1)+1,section_ordinal=ords[s['section']]);s['meta']['review_unit']=i
 c.append({'review_unit':i,'id':s['id'],'section':s['section'],'section_ordinal':ords[s['section']],'char_start':a,'char_end_exclusive':b,'line_start':s['tex_line_start'],'line_end':s['tex_line_end']})
for x in d['review_evidence']['discussion_appendix_refresh']['all_predecessor_lineage']:x['successor_ids']=[ids.get(k,k) for k in x['successor_ids']]
assert not validate_claims_review(d)
d['review_date']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['reviewer_run_id']=run
d['review_scope']['discussion_appendix_r2']={'agent_run_id':run,'head':'ab097b381aec6658217bb7237c2dc1ba82bbc174','current_manuscript_sha256':sha(R/'papers/L1/paper_draft.tex'),'current_pdf_sha256':sha(R/'papers/L1/paper_draft.pdf'),'prior_80d48_proposal_sha256':sha(O/'proposal-80d48.json'),'scope':'Exactly three quote/ID rebindings for two approved source replacements; same151assessments, full134predecessorhistory/physicalBLOCK retained. Earlier discussion_appendix_refresh describes historical80d48 inputs. Latest current-source pins are this r2 entry.','original_r1_review_date':original['review_date'],'original_r1_run_id':original['reviewer_run_id'],'packet_history':'R1initialFRESH/finalSTALE owned-files+source at ROOT sourcefix; lead reissued R2 after compile; no selfrefresh.'}
d['review_evidence']['discussion_appendix_r2']={'full_r1_151_records':original['sentences'],'original_r1_134_lineage':original['review_evidence']['discussion_appendix_refresh']['all_predecessor_lineage'],'original_r1_assessment_changes':original['review_evidence']['discussion_appendix_refresh']['assessment_changes'],'three_rebindings':changes,'current_source_hashes':{f:sha(R/f) for f in ['papers/L1/paper_draft.tex','papers/L1/paper_draft.pdf']},'no_science_or_physical_acceptance_change':True}
d['summary']['agent_text']+=' Boundedr2 updates exactly3quote/IDs for2sourcefixes; originalr1records andlineage retained, currentpins in discussion_appendix_r2.'
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n');(O/'coverage.json').write_text(json.dumps(c,indent=2)+'\n');(O/'r2-rebindings.json').write_text(json.dumps(changes,indent=2)+'\n');(O/'lineage.json').write_text(json.dumps(d['review_evidence']['discussion_appendix_refresh']['all_predecessor_lineage'],indent=2)+'\n')
print(json.dumps({'proposal_sha256':sha(p),'units':len(d['sentences']),'changed_quote_IDs':changes},indent=2))
