import json,re,copy,sys,hashlib,datetime
from pathlib import Path
from collections import Counter
R=Path.cwd();O=Path('/tmp/l1-discussion-catalog-work-20261105');B=Path('/tmp/l1-discussion-predecessor-20261105');sys.path.insert(0,str(R/'scripts'))
from sentence_state import compute_sentence_id,normalize_quote,validate_claims_review
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
t=(R/'papers/L1/paper_draft.tex').read_text();base=json.loads((B/'claims_review.json').read_text());old=base['sentences'];u=json.loads((O/'units.json').read_text());masked=re.sub(r'\\label\{[^}]*\}',lambda m:' '*len(m[0]),t)
assert sha(R/'papers/L1/paper_draft.tex')=='80d48ada62d9842f803d34732937b4fa4fb058fa4a753fa600000a63f04726bd'
assert sha(R/'papers/L1/claims_review.json')==sha(B/'claims_review.json')=='4fd35e9a46a87bb40e53dcf92a9083f625f22c55dfae529da98941a411274c61'
def loc(q):
 ms=list(re.finditer(r'\s+'.join(map(re.escape,q.split())),masked));assert len(ms)==1,(len(ms),q[:100]);return ms[0].span()
def sec(a):
 ms=list(re.finditer(r'\\section\{([^{}]*)\}',t[:a]));return ms[-1][1] if ms else 'abstract'
run='claims-reviewer-v2:2026-11-05:l1-discussion-appendix-catalog-r1'
scope='Current actual source/statement/carrier inspection and accepted source-preservation review only. No scientific/native/Lean/LSP/kernel/build execution; conditional real scalar algebra and recorded validation are not physical B3/window/state/tensor/matter/transport construction or publication readiness.'
# New walker-index -> predecessor indices, current type/verdict and precise backing scope.
C={
14:([14],'formal-claim','PASS','RPA filename moved to provenance only; actual W6Ext closed form/sign-stability has free unevaluated chi0/gamma_star. No physical normalization.', ['rpa']),
39:([39,40],'qualitative','INFO','Condensed forward reference preserves possible mechanisms without deriving any. Existing physical construction remains open.',[]),
42:([43],'formal-claim','PASS','Same denominator-nonzero RPA identity and sign-stability conditions; no evaluated inputs or numerical susceptibility. Removing implementation name does not alter mathematical scope.',['rpa']),
51:([52],'parameter','PASS','Defines the same conservative symmetric numerical cap tau3e-15; predicate syntax is retained in appendix.',['cap']),
52:([53],'formal-claim','PASS','Literal abs deviation<=tau is exactly LigoSatisfied unfolded; nonnegative chi and fixedtau remain. Theorem name moved to provenance.',['interval']),
62:([63],'numeric','PASS','Same lower endpoint deviation/factor and exclusion; ordinary heading/predicate prose replaced names only. No entire-range exclusion.',['lower']),
63:([64],'numeric','PASS','Same upper endpoint deviation/factor and exclusion; all numeric/domain conditions remain.',['upper']),
68:([69],'formal-claim','PASS','Same physicalc>0 subdomain of stronger every-real-nonzero-c relative-deviation endpoint statement; theorem name retained in appendix.',['realc']),
78:([79],'formal-claim','PASS','Same exact finite interval conditional on assumed law and conservative symmetric cap.',['interval']),
79:([80],'numeric','PASS','Same1±2tau+tau² endpoints and approximatechi±6e-15 versus speed±3e-15 distinction; not exact-offset or singleton claim.',['interval']),
80:([81,82],'formal-claim','PASS','Unity anchors nonzero finite interval; finite cap implies neither exact fixedpoint nor genericUV exclusion. Adopted prior limitation retained separately.',['interval']),
81:([83],'transition','TRANSITION','Actual source has exactly the three proposed possibilities; not an exhaustive physical theorem.',[]),
82:([84,40],'qualitative','INFO','Conditional symmetry/RG fixedpoint remains hypothetical, not a derived symmetry or RG flow.',['hyp']),
83:([85,86,87,40],'qualitative','INFO','Unity would lie inside the interval if symmetry realizes it; ADW realization explicitly unproved. No mechanism selection/extraction.',['interval']),
84:([88,89,39],'qualitative','INFO','Distinct metric-channel interpretation and pinning are explicitly possible model-building choices, not inferred physical likelihood.',['hyp']),
85:([91],'qualitative','INFO','Nonlinear action is a proposed research route; no exclusive necessity theorem or construction claimed.',[]),
86:([90],'qualitative','INFO','Missing dynamics does not provide a relative-likelihood inference; original limitation preserved.',[]),
87:([86,40],'formal-claim','PASS','Finite real-scalar interval theorem derives no microscopic symmetry/channel mechanism; statement concerns scope of actual theorem.',['interval']),
88:([92,93,39],'qualitative','INFO','Possible frequency-dependent law/modification remains hypothetical; original law frequency-independent. No physical dispersion derivation.',['product']),
89:([94],'qualitative','INFO','Product ansatz is real multiplication, not a matched microscopic derivative expansion.',['product']),
90:([95,96],'qualitative','INFO','Literal real100 needs physical frequency/angular-Hz/unit matching; actual product/peak statement supplies none.',['peak']),
91:([97,98],'qualitative','WARN','Gamma_H/cGW² remains unmatched; acoustic horizon symbol is not a retarded metric-source/matter transport bridge. Existing L1_REGISTRY_REVIEW49–53 BUILD, not new finding.',['product']),
92:([99,100,104],'formal-claim','PASS','Conditional assumed1e-30 coefficient bounds product at real100 belowtau only; placeholder neither measured nor derived, larger physicalcorrection not excluded.',['peak']),
93:([101,102,127],'formal-claim','PASS','Absolute-product bound constrains correction alone; additive total also depends on delta0. No total-deviation inference from correction bound alone.',['product','dispiff']),
94:([103],'formal-claim','PASS','In assumed additive model opposite-sign correction can restore sufficiently near-boundary exterior offsets, with fullBbound retained in appendix. No generic restoration.',['product']),
95:([101,102,103,127,128],'transition','TRANSITION','Actual same-file appendix contains full additivecriterion/nearboundary assertions and product witnesses; this is route confirmation, not new proof.',[]),
96:([105],'qualitative','INFO','Explicit missing microscopic dissipative parameter/normalization remains original physical BUILD.',['product']),
106:([79,81],'formal-claim','PASS','Correct final interpretation of exact finite interval under assumedlaw/sourceemissionconditions; not singleton or physical realization.',['interval']),
107:([82,61],'qualitative','PASS','Adopted comparison domain is not derived physical prior; probability requires a prior. Exactwidth comparison is not prior-independent mass.',['width']),
108:([78],'qualitative','INFO','Full physical response/domain/state/tensor/matterlight/transportunits/error construction remains open, not supplied by endpoints.',['realc']),
109:([17,18,78],'qualitative','INFO','Conditional mathematical model constrained while microscopic realization stays open; no universal absence theorem.',['interval']),
110:([115,127],'transition','TRANSITION','Appendix contents actually present, same canonicalTeX beforebibliography; no hidden source/length exemption.',[]),
111:([77,78],'qualitative','INFO','Preserved scalar checks do not construct physical modes/normalization/matching; negative scope of actual declarations.',['interval','product']),
112:([52],'parameter','PASS','Exact current LigoSatisfied definition absdelta<=fixedtau preserved; no new predicate or tolerance.',['cap']),
125:([92],'qualitative','INFO','Original frequency-independent assumedlaw retained explicitly in moved frequency subsection.',['product']),
142:([53,63,64],'theorem-ref','PASS','Actual exact declarations name finiteinterval and endpoint results. Descriptive main headings replace longnames; scoped theorem provenance only.',['interval','lower','upper']),
143:([69],'theorem-ref','PASS','Actual natural_endpoints_violate_ligo_for_every_c takesrealc!=0 with two endpoint condition; stronger claim preserved.',['realc']),
144:([14,43],'methodology','PASS','Actual VestigialSusceptibility closedform/signstability has unevaluatedbare/coupling inputs; provenance and unresolved normalization retained.',['rpa']),
145:([130,131,132,133],'methodology','INFO','Inventory is explicitly recorded historical validation, not a newexecution or physicalreadiness assertion; fulloldinventory and scopedwarnings retained.',[]),
146:([131,78],'methodology','INFO','Explicitly denies freshnativeproof/physicalconstruction certificate; no source/test receipt upgraded to physical acceptance.',[]),
}
T={
'interval':('theorem','SKEFTHawking.GravitationalWaves.c_GW_match_iff_chi_close_to_one'),
'width':('theorem','SKEFTHawking.GravitationalWaves.ligo_window_width_eq'),
'lower':('theorem','SKEFTHawking.GravitationalWaves.natural_lower_violates_ligo'),
'upper':('theorem','SKEFTHawking.GravitationalWaves.natural_upper_violates_ligo'),
'realc':('theorem','SKEFTHawking.GravitationalWaves.natural_endpoints_violate_ligo_for_every_c'),
'product':('theorem','SKEFTHawking.GravitationalWaves.dispersion_correction'),
'peak':('theorem','SKEFTHawking.GravitationalWaves.vestigial_dispersion_below_ligo_at_inspiral_peak'),
'dispiff':('theorem','SKEFTHawking.GravitationalWaves.dispersion_within_ligo_iff'),
'rpa':('theorem','SKEFTHawking.VestigialSusceptibility.W6Ext.chi_RPA_closed_form'),
'cap':('theorem','SKEFTHawking.GravitationalWaves.LigoSatisfied'),
'hyp':('hypothesis','H_VestigialModeIsGraviton')}
records=[];unch=[];moves=[];mapping={i:[] for i in range(134)};changes=[]
for i,s in enumerate(old):
 try:a,b=loc(s['quote'])
 except AssertionError:continue
 z=copy.deepcopy(s);section=sec(a)
 if section!=z['section']:
  z['section']=section;z['id'],z['quote_normalized'],h=compute_sentence_id('L1',section,z['quote']);z['raw_id_parts'].update(section_slug=z['id'].split(':')[2],quote_hash=h);z['rewrite_of']=s['id'];z['bundle_section_hint']=section;moves.append(i)
 else:unch.append(i)
 records.append(z);mapping[i].append(z['id'])
for wi,(parents,typ,v,note,ts) in C.items():
 q=u[wi]['quote'];a,b=loc(q);section=sec(a);z=copy.deepcopy(old[parents[0]]);sid,norm,h=compute_sentence_id('L1',section,q)
 z.update(id=sid,quote=q,quote_normalized=norm,section=section,type=typ,agent_verdict=v,agent_notes=note,agent_run_id=run,rewrite_of=old[parents[0]]['id'],finding_classes=[],gates_invoked=[],bundle_section_hint=section)
 z['raw_id_parts'].update(section_slug=sid.split(':')[2],quote_hash=h);z.pop('delta_pct',None)
 if ts:z['chain_proposed']={'links':[{'kind':T[k][0],'target':T[k][1],'verification_scope':scope+' '+note} for k in ts],'completeness':'partial' if v in ['WARN','INFO','UNGROUNDED'] else 'full'}
 elif typ=='transition':z.pop('chain_proposed',None)
 else:z['chain_proposed']={'links':[],'completeness':'none'}
 z['meta']={'review_unit':0,'walker_unit':wi,'source_sha256':sha(R/'papers/L1/paper_draft.tex'),'assessment_origin':'discussion-appendix-source-reassessment','prior_assessment_ids':[old[j]['id'] for j in parents],'source_scope':scope}
 records.append(z)
 for j in parents:mapping[j].append(sid)
 changes.append({'walker_unit':wi,'id':sid,'prior_indices':parents,'prior_verdicts':[old[j]['agent_verdict'] for j in parents],'verdict':v,'justification':note})
records.sort(key=lambda z:loc(z['quote'])[0]);ordinal=Counter();coverage=[]
for i,z in enumerate(records):
 a,b=loc(z['quote']);section=sec(a);assert z['section']==section;ordinal[section]+=1;z.update(tex_line_start=t.count('\n',0,a)+1,tex_line_end=t.count('\n',0,b-1)+1,section_ordinal=ordinal[section]);z['meta']['review_unit']=i
 assert compute_sentence_id('L1',section,z['quote'])[0]==z['id'];assert normalize_quote(masked[a:b])==z['quote_normalized']
 coverage.append({'review_unit':i,'id':z['id'],'section':section,'section_ordinal':ordinal[section],'char_start':a,'char_end_exclusive':b,'line_start':z['tex_line_start'],'line_end':z['tex_line_end']})
assert len(records)==len({z['id'] for z in records})==len({normalize_quote(z['quote']) for z in records})
lineage=[]
for i,z in enumerate(old):
 assert mapping[i],('unaccounted predecessor',i)
 lineage.append({'prior_index':i,'prior_id':z['id'],'successor_ids':list(dict.fromkeys(mapping[i])),'relation':'retained' if i in unch else 'same-quote-section-move-new-id' if i in moves else 'split/merge/rewrite','disposition':'Full original scientific assertion retained, moved or source-faithfully qualified in the same canonical manuscript; fulloldrecord preserved; no automatic closure and originalphysicalBUILD remains open.'})
d=copy.deepcopy(base);d.update(sentences=records,review_date=datetime.datetime.now(datetime.timezone.utc).isoformat(),reviewer_run_id=run)
d['review_scope']['discussion_appendix_refresh']={'agent_run_id':run,'base_head':'ab097b381aec6658217bb7237c2dc1ba82bbc174','prior_catalog_sha256':sha(B/'claims_review.json'),'current_manuscript_sha256':sha(R/'papers/L1/paper_draft.tex'),'current_pdf_sha256':sha(R/'papers/L1/paper_draft.pdf'),'original_top_level_review_date':base['review_date'],'original_top_level_reviewer_run_id':base['reviewer_run_id'],'scope':scope,'coverage':'One current582lineTeX, abstract/mainbody/theorem/caption/Discussion/entireappendixbeforebibliography; metadata/bibliography/comments excluded perpersona. No multi-source resolver.','acceptance':'Author proposal only, separate independent review and ROOT single canonical intake required. No human/gate/closure mutation.'}
sources=['papers/L1/paper_draft.tex','papers/L1/paper_draft.pdf','lean/SKEFTHawking/GravitationalWaves.lean','lean/SKEFTHawking/LinearizedEFE.lean','lean/SKEFTHawking/VestigialSusceptibility.lean','lean/lean_deps.json','papers/AutomatedReviews/2026-11-05-publication-computation-coverage/L1_REGISTRY_REVIEW.md']
d['review_evidence']['discussion_appendix_refresh']={'all_134_predecessor_records':copy.deepcopy(old),'all_predecessor_lineage':lineage,'prior_summary_preserved':copy.deepcopy(base['summary']),'assessment_changes':changes,'source_hashes':{f:sha(R/f) for f in sources},'accepted_preservation_review':{'path':'/tmp/l1-discussion-appendix-source-review-20261105.md','sha256':sha('/tmp/l1-discussion-appendix-source-review-20261105.md')},'scope':scope,'human_and_audit_pins':{f:sha(R/'papers/L1'/f) for f in ['prose_state.json','audit_log.jsonl']},'no_execution_or_readiness_promotion':True}
s=d['summary'];s.update(total_sentences=len(records),by_type=dict(Counter(z['type'] for z in records)),by_verdict=dict(Counter(z['agent_verdict'] for z in records)),by_finding_class=dict(Counter(c for z in records for c in z['finding_classes'])))
s['agent_text']=f'{len(records)}current units across main and samefilebeforebibliographyappendix; {len(unch)}unchanged-IDassessments and {len(moves)}samequote sectionmoves preserved; {134-len(unch)-len(moves)}rewrittenpredecessors and {len(C)}new/reassessedunits. All134fulloldrecords and lineage,4blockers54candidates/followups/human/evidence/datehistory retained. Zeroautomaticclosures. Recordedvalidation/conditionalalgebra only; fullphysicalBUILD/native/stage/main/humanpublication acceptance remain open.'
assert not validate_claims_review(d),validate_claims_review(d)
for k in ['blocking_issues','non_blocking_followups','non_reproducing_prior_findings','reproducing_prior_findings','cross_bundle_findings']:assert d[k]==base[k]
for k in ['review_scope','review_evidence']:assert all(d[k][a]==b for a,b in base[k].items())
for j in unch+moves:
 a=copy.deepcopy(old[j]);b=copy.deepcopy(next(z for z in records if z['id']==mapping[j][0]))
 for z in [a,b]:
  for k in ['tex_line_start','tex_line_end','section_ordinal']:z.pop(k,None)
  z['meta'].pop('review_unit',None)
 if j in moves:
  for z in [a,b]:
   for k in ['id','section','raw_id_parts','rewrite_of','bundle_section_hint']:z.pop(k,None)
 assert a==b,j
out=Path('/tmp/l1-discussion-catalog-proposal-20261105.json');out.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
for name,obj in [('coverage.json',coverage),('lineage.json',lineage),('reassessments.json',changes),('readback.json',{'proposal_sha256':sha(out),'units':len(records),'unchanged':len(unch),'moved':len(moves),'rewritten_predecessors':134-len(unch)-len(moves),'new_units':len(C),'unchanged_indices':unch,'moved_indices':moves,'rewritten_indices':sorted(set(range(134))-set(unch)-set(moves)),'summary':s,'schema_errors':[]})]: (O/name).write_text(json.dumps(obj,indent=2)+'\n')
print((O/'readback.json').read_text())
