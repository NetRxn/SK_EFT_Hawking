import sys,re,json,hashlib,copy,difflib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.sentence_state import compute_sentence_id,normalize_quote
root=Path('/tmp/l1-discussion-catalog-work-20261105')
src=Path('papers/L1/paper_draft.tex').read_text(); lines=src.splitlines(True)
# Maintain source offsets; mask comments and presentation-only commands without shifting.
chars=list(src)
def mask(a,b):
 for i in range(a,b):
  if chars[i]!='\n':chars[i]=' '
for m in re.finditer(r'(?m)^\s*%.*$',src):mask(*m.span())
start=src.index('\\begin{abstract}')+len('\\begin{abstract}'); end=src.index('\\begin{thebibliography}')
mask(0,start);mask(end,len(src))
for m in re.finditer(r'\\(?:section|subsection|paragraph|label)\{[^{}]*\}|\\(?:maketitle|centering|appendix)|\\(?:begin|end)\{(?:abstract|enumerate|figure)\}(?:\[[^]]*\])?|\\includegraphics(?:\[[^]]*\])?\{[^{}]*\}|\\item\s*',src):mask(*m.span())
# Caption wrapper only; prose stays.
for m in re.finditer(r'\\caption\{',src):
 a=m.end();depth=1;j=a
 while depth:
  if src[j]=='{' and src[j-1]!='\\':depth+=1
  if src[j]=='}' and src[j-1]!='\\':depth-=1
  j+=1
 mask(m.start(),a);mask(j-1,j)
text=''.join(chars)
sections=[]
for m in re.finditer(r'\\section\{([^{}]*)\}',src):sections.append((m.start(),m.group(1)))
def sec(pos):return next((s for a,s in reversed(sections) if a<pos),'abstract')
# Sentence splitter respects braces, inline math, and displayed/theorem environments.
units=[];a=start;brace=0;math=False;env=[];i=start
while i<end:
 if text[i:i+2]=='\\[':
  env.append('display');i+=2;continue
 if text[i:i+2]=='\\]':
  if env and env[-1]=='display':env.pop()
  text=text[:i]+text[i:i+2]+text[i+2:];i+=1
  # End a displayed mathematical sentence at the display boundary.
  q=text[a:i+1].strip()
  lo=a+len(text[a:i+1])-len(text[a:i+1].lstrip());hi=i+1
  if q:units.append(dict(section=sec(lo),quote=q,tex_line_start=src.count('\n',0,lo)+1,tex_line_end=src.count('\n',0,hi-1)+1))
  a=i+1;i+=1;continue
 if text[i]=='\\':
  m=re.match(r'\\(begin|end)\{(equation\*?|aligned|theorem)\}(?:\[[^]]*\])?',text[i:])
  if m:
   if m[1]=='begin':env.append(m[2])
   elif env:env.pop()
   i+=len(m[0]);continue
 if text[i]=='$' and (i==0 or text[i-1]!='\\'): math=not math
 if text[i]=='{' and text[i-1]!='\\':brace+=1
 if text[i]=='}' and text[i-1]!='\\':brace-=1
 stop=False
 if not env and not math and brace==0:
  if text[i] in '.?!' and (i+1==end or text[i+1].isspace()):
   before=text[max(a,i-12):i+1]
   if not re.search(r'(?:Eq|Fig|Sec|Refs|Ref|et al|e\.g|i\.e)\.$',before):stop=True
  if text[i]=='\n' and i+1<end and text[i+1]=='\n':stop=True
 if stop:
  q=text[a:i+1].strip()
  if q:
   lo=a+len(text[a:i+1])-len(text[a:i+1].lstrip());hi=i+1
   while hi>lo and text[hi-1].isspace():hi-=1
   units.append(dict(section=sec(lo),quote=q,tex_line_start=src.count('\n',0,lo)+1,tex_line_end=src.count('\n',0,hi-1)+1))
  a=i+1
 i+=1
q=text[a:end].strip()
if q:units.append(dict(section=sec(a),quote=q,tex_line_start=src.count('\n',0,a)+1,tex_line_end=src.count('\n',0,end-1)+1))
# Remove environment-only tail and attach theorem end markers to prior quote if needed.
units=[u for u in units if re.sub(r'\\(?:end|begin)\{[^}]*\}','',u['quote']).strip()]

(root/'units.json').write_text(json.dumps(units,indent=2))
for i,u in enumerate(units):
 print(i,u['tex_line_start'],u['quote'].replace('\n',' ')[:170])
