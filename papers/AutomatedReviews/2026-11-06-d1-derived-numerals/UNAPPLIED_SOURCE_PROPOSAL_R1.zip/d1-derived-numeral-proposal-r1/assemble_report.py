from pathlib import Path
import ast, json, hashlib, re
root=Path.cwd()
out=Path('/tmp/d1-derived-numeral-proposal-r1')
packet_path=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/d1-derived-numeral-source-proposal-r1.json')
packet=json.loads(packet_path.read_text())
audit=json.load(open('/tmp/l1-numerical-literal-audit-r1.json'))
sites0=next(f['current'] for f in audit['files'] if f['path']=='papers/D1/paper_draft.tex')
tex=(root/'papers/D1/paper_draft.tex').read_text()
lines=tex.splitlines()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
mapping={1:'heidelberg_delta_diss',2:'steinhauer_delta_diss',3:'steinhauer_delta_disp',4:'steinhauer_delta_diss',5:'heidelberg_delta_disp',6:'heidelberg_delta_diss',7:'trento_delta_disp',8:'trento_delta_diss',9:'heidelberg_delta_diss',10:'steinhauer_delta_diss',11:'trento_delta_diss',14:'dean_profile_error',15:'dean_evanescent_error',17:'lorenz_sommerfeld',19:'dean_hawking_temperature_k',20:'dean_omega_h_s1',21:'dean_channel_s1',24:'dean_sigma_q_siemens',25:'dean_johnson_psd',27:'dean_omega_h_s1',33:'paris_cavity_rate_s1',36:'penn_lp_rate_s1'}
source={12,16,18,26,28,29,30,31,34,35,37}
theorem={22,23}
gaps={13,32,38}
conditional={14,15,19,20,27}
notes={12:'Adopted source sound speed; Geurs2025 / provenance Dean_bilayer_nozzle.c_s. Retain literal.',16:'Same source/adopted sound speed in adiabaticity example; do not compute it from monolayer v_F.',18:'Same source/adopted sound speed in detection operating point.',26:'Same source/adopted sound speed in figure caption.',28:'Falque2025 reported smooth-horizon surface gravity 0.08 ps^-1; measured/source input.',29:'Falque2025 reported steep-horizon surface gravity 0.11 ps^-1; measured/source input.',30:'Same source maximum as site29, expressed in SI; unit conversion does not make measured input a physical prediction.',31:'Falque2025 effective polariton mass, source/adopted input owned by POLARITON_MASS.',34:'Wang2026TMDPolariton upper-polariton linewidth 2.3 meV; measurement.',35:'Wang2026TMDPolariton lower-polariton linewidth 1.8 meV; measurement.',37:'Falque2025 steep-horizon source maximum reused in adverse-device comparison.',22:'Exact literal 4.4e5 in statement DiracFluidWKB.dean_lowest_channel_above_four_omega_H, not a Python result. Retain literal quote.',23:'Exact literal 3.14e11 in same Lean statement. Retain quote even if physical operating-point omega_H is reconciled.',13:'Derived bilayer Fermi-liquid velocity hbar*sqrt(pi*n)/m* at n=1e12 cm^-2. Inspected bilayer_effective_mass is outside formulas.py and embeds hopping/monolayer inputs; no clean registered n/m* producer binding established. Do not replace with sqrt(2)*c_s, which changes the claimed derivation.',32:'Derived polariton mean-field noise temperature m*c_s^2/K_B. No canonical formula producer was found in inspected formulas/polariton predictions; requires existing-planner source/formula/grounding reconciliation, not a literal lambda.',38:'Same derived noise-temperature result as site32, carrying the stimulated-detection assumption; same producer gap.'}
sites=[]
positions={}
for n,s in enumerate(sites0,1):
    ctx=s['context']
    line_index=next(i for i,l in enumerate(lines) if l==ctx)
    start=positions.get(line_index,0)
    col=ctx.index(s['match'],start)
    positions[line_index]=col+len(s['match'])
    if s['leg']=='times':
        end=ctx.index('}',col)+1 if '{' in ctx[col+len(s['match']):col+len(s['match'])+2] else re.search(r'-?\d+',ctx[col+len(s['match']):]).end()+col+len(s['match'])
        if col and ctx[col-1]=='-':col-=1
        literal=ctx[col:end]
    else:
        literal=re.match(r'\d+(?:\.\d+)?',ctx[col:]).group()
    cls='measured_or_source_or_adopted_input' if n in source else 'exact_theorem_statement' if n in theorem else 'genuinely_derived'
    status='retain_literal' if n in source|theorem else 'producer_binding_incomplete' if n in gaps else 'operating_point_hold' if n in conditional else 'source_proposal_only_unexecuted'
    if n<=11:
        note='Existing D1 compute_bec_hierarchy canonical evaluator; conditional smooth-model/T=0 Beliaev value; not experimental measurement. Existing raw-TeX semantic reader must retain coverage after any input substitution.'
    else:note=notes.get(n, 'Canonical producer exists; exact input/model/unit/precision mapping is in scalar description and family map. Actual producer evaluation and independent review not performed.')
    if n in conditional:note += ' Held for Dean rounded-temperature/gradient/mean-free-path reconciliation; see substantive mismatches.'
    sites.append(dict(site=n,audit_stripped_line=s['line'],source_line=line_index+1,source_column=col+1,audit_match=s['match'],literal=literal,context=ctx,source_context='\n'.join(lines[max(0,line_index-3):line_index+4]),classification=cls,disposition=status,scalar_id=mapping.get(n),replacement=(r'\input{tables/'+mapping[n]+r'.tex}\unskip') if n in mapping else None,reason=note))
# Stable exact source replacement manifest, never applied here.
replacements=[{k:s[k] for k in ('site','source_line','source_column','literal','context','scalar_id','replacement','disposition')} for s in sites if s['scalar_id']]
additional=[]
for old,scalar in [('6.44','heidelberg_crossover_over_teff'),('10.65','steinhauer_crossover_over_teff'),('11.17','trento_crossover_over_teff'),('121','heidelberg_cutoff_over_th'),('115','steinhauer_cutoff_over_th'),('110','trento_cutoff_over_th'),('21.8','heidelberg_diss_disp_ratio')]:
    for i,line in enumerate(lines):
        # Only exact authored physical numeral occurrences, not bibliographic metadata.
        if i+1>2140:continue
        for m in re.finditer(r'(?<![\d.])'+re.escape(old)+r'(?![\d.])',line):
            additional.append(dict(source_line=i+1,source_column=m.start()+1,literal=old,context=line,scalar_id=scalar,replacement=r'\input{tables/'+scalar+r'.tex}\unskip',counted_in_38=False,disposition='coherent_BEC_companion_proposal_only'))
# Hash every source actually used for source/operating-point conclusions.
relpaths=['CLAUDE.md','docs/WAVE_EXECUTION_PIPELINE.md','docs/PAPER_STRATEGY.md','docs/dev-loops/CODEX_CONTINUITY.md','.claude/plugins/skeft-qa/agents/claims-reviewer.md','papers/D1/paper_draft.tex','papers/D1/bundle_metadata.json','papers/D3/tables.py','papers/L1/tables.py','scripts/render_paper_tables.py','scripts/paper_tables/sources.py','scripts/gen_d1_hierarchy_table.py','scripts/validation/checks/physics.py','scripts/validation/_tex.py','src/core/constants.py','src/core/formulas.py','src/core/provenance.py','src/core/transonic_background.py','src/wkb/spectrum.py','src/wkb/connection_formula.py','src/graphene/bilayer_eos.py','src/graphene/transport_counting.py','src/graphene/hawking_predictions.py','src/core/visualizations.py','src/experimental/polariton_predictions.py','tests/test_d1_hierarchy_table.py','tests/test_f_hierarchy_claims.py','lean/SKEFTHawking/DiracFluidWKB.lean','lean/SKEFTHawking/QuasiOneDReduction.lean','lean/SKEFTHawking/PolaritonTier1.lean']
pins={p:sha(root/p) for p in relpaths}
for p in [packet_path,Path('/tmp/l1-numerical-literal-audit-r1.md'),Path('/tmp/l1-numerical-literal-audit-r1.json')]:pins[str(p)]=sha(p)
for ref in [packet['references']['notebook'],packet['references']['roadmap'],packet['references']['authorities'][-1]]:pins[ref['path']]=sha(ref['path'])
spec=(out/'tables.py').read_text();ast.parse(spec)
(out/'REPLACEMENTS.json').write_text(json.dumps({'source_sha256':pins['papers/D1/paper_draft.tex'],'counted':replacements,'uncounted_BEC_companions':additional},indent=2)+'\n')
report={'task':packet['task'],'parent':packet['parent'],'candidate':packet['source']['head'],'packet_path':str(packet_path),'packet_sha256':sha(packet_path),'initial_continuity':{'fresh':True,'changed':[]},'final_continuity':None,'status':'SOURCE_PROPOSAL_ONLY_NOT_APPLICATION_READY','scope':'Off-tree proposal only; ROOT sole notebook writer and publication lead. No repository/index/Git/controller/slot mutation.','classification_counts':{'total_audited_sites':38,'genuinely_derived':25,'measured_source_or_adopted_input':11,'exact_theorem_statement':2,'canonical_producer_prospective_sites':22,'canonical_source_lower_friction_sites':17,'canonical_operating_point_hold_sites':5,'derived_producer_binding_gap_sites':3,'actual_evaluated_or_accepted_sites':0},'debt_arithmetic':{'current_count_from_parent':139,'ceiling_from_parent':117,'prospective_if_17_integrate':122,'prospective_if_all_22_integrate':117,'no_current_census_executed':True,'qualification':'Arithmetic projections only; existing BEC reader compatibility and all source/operating-point/review/evaluation gates remain.'},'source_pins':pins,'sites':sites,'counted_replacements':replacements,'uncounted_BEC_companions':additional,'spec':{'path':str(out/'tables.py'),'sha256':sha(out/'tables.py'),'executed':False,'parsed_with_stdlib_ast_only':True},'commands_actually_run':['python3 scripts/codex_continuity.py --help','python3 scripts/codex_continuity.py check --help','python3 scripts/codex_continuity.py check <same assigned packet>','read-only cat/sed/rg source and memory reads','git status --short','stdlib Python JSON/text/AST/SHA256 reporting; no project module imported or called'],'required_validation':['Independent full proposal review and exact-source/point classification','ROOT controlled compute_bec_hierarchy and canonical graphene/polariton producers; compare all unrounded/formatted values and claims','Resolve existing raw-TeX D1 semantic reader compatibility without removing its six-cell/two-crossover coverage; no new parser/gate authorized by this report','Existing renderer baseline/input mutation/output corruption/restoration controls with byte custody','Render and compile D1 out-of-tree; inspect every page and moving-caption handling','Reconcile existing D1/F cross-platform consumers, catalog/source lineage and F dependency binding via existing owners/writers','Run existing scoped D1/F/platform checks and tests, numerical_literals unchanged predicate and ceiling, broader fast/full gates as required by actual eventual change'],'acceptance_limits':['No project function evaluations, imports, tests, renderer, plots, compile, native/heavy computation or network','No source/parameter/primary-source/human verification or new kernel certificate','No inference of missing Lean proof from names/grep; source quotations only, LSP/import/history validation remains incomplete where required','No full claims-reviewer sentence-walk certification; persona used for this bounded numerical/source proposal only','No physical BUILD, no scientific closure, no publication readiness or human acceptance','Source/measurement and exact theorem constants remain literal; no threshold/predicate/registry or new machinery proposal']}
Path('/tmp/d1-derived-numeral-source-proposal-r1.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'sites':len(sites),'counts':report['classification_counts'],'spec_sha256':report['spec']['sha256'],'companion_sites':len(additional),'pins':len(pins)},indent=2))
