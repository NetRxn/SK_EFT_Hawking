"""PROPOSAL ONLY; unexecuted. Existing D1 SCALARS source-binding candidate.

Do not install before independent review and controlled evaluations. The graphene
temperature/frequency/quasi-1D subset requires operating-point adjudication.
No literal output is used as a producer. No measurement or Lean statement is
replaced by a computation. Physical BUILD obligations are unchanged.
"""
from functools import cache

from src.core.constants import GRAPHENE_PLATFORMS, K_B, HBAR, POLARITON_PLATFORMS
from src.core.formulas import (
    hawking_temperature,
    graphene_channel_cutoff_energy, quasi1d_correction_bound,
    johnson_current_psd,
)
from src.graphene.transport_counting import L_LORENZ_SOMMERFELD
from scripts.gen_d1_hierarchy_table import compute_bec_hierarchy


def _sci(value, places=2):
    mantissa, exponent = f'{value:.{places}e}'.split('e')
    return f'{mantissa}\\times10^{{{int(exponent)}}}%'


def _fixed(value, places):
    return f'{value:.{places}f}%'


@cache
def _hierarchy():
    # Reuse the accepted D1-specific evaluator, including its crossover fields.
    # platform_rows confirms the constants/solver/Beliaev provenance pattern;
    # it is not the authority for D1-specific precision or crossover semantics.
    return compute_bec_hierarchy()


_DEAN = GRAPHENE_PLATFORMS['Dean_bilayer_nozzle']


def _dean_temperature():
    # Adopt registered gradient; do not silently substitute c_s/L or 2.4 K.
    return hawking_temperature(_DEAN['gradient_s1'])


def _dean_omega_h():
    return K_B * _dean_temperature() / HBAR


def _dean_channel():
    return graphene_channel_cutoff_energy(
        0, _DEAN['channel_width_nm'] * 1e-9, _DEAN['c_s'],
    )


def _dean_quasi(component):
    # Isolate the two EXISTING additive canonical terms by zeroing the other.
    # l_ee retains the registered monolayer-v_F modelling assumption; review hold.
    omega = _dean_omega_h() if component == 'evanescent' else 0.0
    l_ee = _DEAN['l_ee_nm'] * 1e-9 if component == 'profile' else 0.0
    return quasi1d_correction_bound(
        omega, _dean_channel(), _DEAN['nozzle_throat_nm'] * 1e-9,
        _DEAN['channel_width_nm'] * 1e-9, l_ee,
    )


SCALARS = {}
for _platform in ('Steinhauer', 'Heidelberg', 'Trento'):
    for _quantity in ('delta_disp', 'delta_diss'):
        SCALARS[f'{_platform.lower()}_{_quantity}'] = {
            'description': f'D1 { _platform } { _quantity }; dimensionless; '
                           'canonical smooth-model background and T=0 Beliaev '
                           'matching at omega=kappa; three significant figures. '
                           'Heidelberg and Trento inputs remain projected; '
                           'pi/6 remains adopted normalization.',
            'value': lambda p=_platform, q=_quantity: _sci(_hierarchy()[p][q], 2),
        }
    for _field, _suffix, _places in (
        ('omega_cross_over_TH', 'crossover_over_teff', 2),
        ('omega_max_over_TH', 'cutoff_over_th', 0),
    ):
        SCALARS[f'{_platform.lower()}_{_suffix}'] = {
            'description': f'D1 {_platform} {_field}; dimensionless; existing '
                           'canonical D1 evaluator. Crossover is in T_eff '
                           'units despite the legacy field name; cutoff in '
                           'bare T_H units. Original model conditions remain.',
            'value': lambda p=_platform, q=_field, n=_places: _fixed(_hierarchy()[p][q], n),
        }

SCALARS['heidelberg_diss_disp_ratio'] = {
    'description': 'Projected Heidelberg delta_diss/abs(delta_disp), existing D1 evaluator ratio; one decimal place; neither a measured ratio nor a kappa-invariant theorem.',
    'value': lambda: _fixed(_hierarchy()['Heidelberg']['ratio'], 1),
}

SCALARS.update({
    'dean_profile_error': {
        'description': 'Conditional quasi-1D profile term at registered Dean l_ee/W; two significant figures; monolayer-v_F assumption retained explicitly.',
        'value': lambda: _sci(_dean_quasi('profile'), 1),
    },
    'dean_evanescent_error': {
        'description': 'Conditional quasi-1D evanescent term at omega_H from adopted gradient; two significant figures; physical bound remains assumed.',
        'value': lambda: _sci(_dean_quasi('evanescent'), 1),
    },
    'lorenz_sommerfeld': {
        'description': 'Existing Sommerfeld Lorenz-number producer; V^2 K^-2, three significant figures; not the measured enhanced Lorenz number.',
        'value': lambda: _sci(L_LORENZ_SOMMERFELD, 2),
    },
    'dean_hawking_temperature_k': {
        'description': 'K; canonical Hawking temperature at registered estimated Dean gradient; one decimal place; no geometry inference or measured temperature claim.',
        'value': lambda: _fixed(_dean_temperature(), 1),
    },
    'dean_omega_h_s1': {
        'description': 's^-1 angular frequency; K_B*T_H/HBAR with unrounded canonical T_H at registered Dean gradient; three significant figures; differs from old rounded-temperature route.',
        'value': lambda: _sci(_dean_omega_h(), 2),
    },
    'dean_channel_s1': {
        'description': 's^-1 angular frequency; first Dirichlet transverse channel at registered Dean W,c_s; three significant figures; not a replacement for the exact Lean statement constants.',
        'value': lambda: _sci(_dean_channel(), 2),
    },
    'dean_sigma_q_siemens': {
        'description': 'S; adopted cross-device sigma_Q=4 e^2/h converted by existing constants producer; three significant figures; not a bilayer conductance measurement.',
        'value': lambda: _sci(_DEAN['sigma_Q_SI'], 2),
    },
    'dean_johnson_psd': {
        'description': 'A^2/Hz; canonical Johnson current PSD at registered Dean electron temperature and adopted sigma_Q; two significant figures.',
        'value': lambda: _sci(johnson_current_psd(K_B, _DEAN['T_ambient_K'], 1.0 / _DEAN['sigma_Q_SI']), 1),
    },
    'paris_cavity_rate_s1': {
        'description': 's^-1; inverse adopted Paris standard cavity lifetime; three significant figures, not direct measurement reinterpretation.',
        'value': lambda: _sci(1.0 / POLARITON_PLATFORMS['Paris_standard']['tau_cav'], 2),
    },
    'penn_lp_rate_s1': {
        'description': 's^-1; existing constants producer converts measured gamma_LP_meV to rate with eV-to-J/HBAR; three significant figures; exact Lean rational retained separately.',
        'value': lambda: _sci(POLARITON_PLATFORMS['Penn_TMD_MoSe2']['Gamma_pol'], 2),
    },
})
