# D1 derived-numeral source proposal r1

**Proposal only; not application-ready.** Candidate `89a5d6d3eb233f4ffe03bd845b12f95d966ea18f`. L1/ROOT retains publication leadership, notebook authorship, integration and acceptance. This task changed only its assigned `/tmp` reports and optional proposal directory. Initial SAME-packet continuity: `fresh=true; changed=[]`.

The existing accepted audit's 38 D1 occurrences classify as **25 derived, 11 measured/source/adopted inputs, and 2 exact theorem-statement literals**. Existing canonical producers support a prospective 22-site package: 17 have lower-friction source bindings and five graphene sites need substantive operating-point reconciliation. Three more derived occurrences lack a clean canonical producer/input binding in this bounded inspection. Nothing was evaluated, rendered, applied or accepted. There is no automatic 22-site repair ready to install.

If the 17 lower-friction sites could be integrated and verified, the parent-provided 139 census would become122, still five above117. All22 would project to117, but that arithmetic is conditional on resolving the physical/source issues, preserving the existing D1 semantic guard and successful actual controls/review. No new census or gate was run here. Source measurements and exact theorem numerals are retained, so they are not counted toward repair capacity.

## Exact prospective artifacts

- `/tmp/d1-derived-numeral-proposal-r1/tables.py`: exact unexecuted SCALARS candidate, using the established renderer and percent-terminated fragments. It includes six BEC correction outputs, coherent BEC crossover/cutoff/ratio companions, and the remaining canonical producer candidates. It is syntax-parsed with stdlib AST only; no module import or evaluation occurred.
- `/tmp/d1-derived-numeral-proposal-r1/REPLACEMENTS.json`: exact current source-line/column/preimage to `\input{tables/<id>.tex}\unskip` replacements for all22 canonical-backed matching sites, plus all14 uncounted BEC companion numeral occurrences. Negative signs are inside the signed dispersive output, not duplicated at call sites. Units, math delimiters, qualifiers and physical disclosures remain outside snippets.
- `/tmp/d1-derived-numeral-source-proposal-r1.json`: complete38-site classification, seven-line source contexts, source hashes, operating-point/unit/model/precision maps, holds and validation requirements. Accepted audit offsets are retained separately from actual current TeX lines; shallow caption stripping shifts later offsets.

The candidate uses **SCALARS** inside the existing tabular and prose, preserving the table structure, nominal-temperature labels and non-BEC rows. A TABLES conversion is unnecessary for this bounded package and would additionally break the existing raw-TeX row reader. No new parser, gate, threshold, registry, exemption, controller or repository infrastructure is proposed.

## Canonical families and operating points

**BEC corrections and coherent companions (11 matching sites).** Reuse `scripts.gen_d1_hierarchy_table.compute_bec_hierarchy()` directly. This is the accepted D1-specific evaluator, not a reimplementation in tables.py. It calls the three `src.wkb.spectrum` platform factories, which call the canonical atomic/experimental parameter factories, default smooth transonic solver and Beliaev matching. The defaults are step width30 healing lengths, domain[-200,200] healing lengths,4000 points, no surface-gravity target. D uses the solver's horizon sound speed; the microscopic Beliaev estimate uses upstream density/scattering length/sound speed and the derived kappa. At the horizon-calibrated omega=kappa point, the factories retain D and Gamma_Bel/kappa in natural units c_s=kappa=1. The evaluator returns delta_disp, delta_diss, crossover, cutoff and ratio; specs read those fields, never the draft literal. This avoids a second platform/physics evaluator.

`platform_rows` confirms the canonical constants/solver/Beliaev route and is useful provenance precedent, but its formatted dissipation cells use different precision; it is not a replacement for the D1 evaluator. Correction mantissas use two decimal places (three significant figures), crossover multipliers two decimals, cutoff multipliers zero decimals and the Heidelberg ratio one decimal. Crossover multipliers refer to T_eff despite the legacy field name `omega_cross_over_TH`; cutoffs refer to bare T_H. Keep the full Planck law and floor=Gamma_H/kappa=delta_diss. Do not restore ln(2/delta), halve the floor again, change the UV temperature to T_eff or infer physical cutoff validation from numerical proximity.

Steinhauer's labels/source measurements remain distinct from smooth-model correction columns. Both Heidelberg and Trento constants/provenance say PROJECTED; no transonic experiment on either is established by the generator. The draft explicitly labels Heidelberg but gives Trento less prominent treatment; preserve projected status in any source/claims review. pi/6 is the adopted project normalization, not a physical universal coefficient derived by this proposal. The T=0 microscopic matching and finite-temperature applicability remain conditions. No shared physical dispersive-law, PDE/action/mode/state or detector BUILD closes.

**Dean quasi-1D components (two matching sites; held).** The candidate calls the existing `quasi1d_correction_bound` twice to isolate its additive terms (omega=0 for the profile term, l_ee=0 for evanescence). Inputs are registered W=1000nm, L=200nm, c_s=4.4e5m/s, electron temperature150K and the current constants-derived l_ee. All lengths convert to SI. omega_perp is `graphene_channel_cutoff_energy(0,W,c_s)`; prospective omega_H comes from the unrounded canonical temperature at registered gradient. Both outputs are dimensionless, two significant figures. The physical error scalings remain hypotheses, not results of a triangle inequality. The monolayer-v_F assumption below must be reconciled before this becomes a physically accepted computed family.

**Dean Hawking temperature/frequency (three matching sites; held).** The exact candidate chain is `hawking_temperature(Dean['gradient_s1'])`, then `K_B*T_H/HBAR`. Temperature is K with one decimal; frequency is angular s^-1 with three significant figures. This uses the adopted estimated gradient2e12s^-1; it neither silently recomputes it from c_s/L nor uses the rounded stored2.4K as if it were a new computed producer. Geometry uncertainty and the source's500mK alternative remain. The old3.14e11s^-1 and the currently plotted curve use the rounded-temperature route, so review and actual comparison must choose and propagate a coherent operating point before application. No arbitrary precision or input is selected to preserve an old numeral.

**Dean first transverse channel (one matching site).** Use the existing `graphene_channel_cutoff_energy(0,W,c_s)` with measured/adopted c_s and extracted W, Dirichlet strip boundaries; units angular s^-1, three significant figures. The exact theorem-statement numerals4.4e5 and3.14e11 at the two following sites stay literal. They describe what the actual Lean statement proves and must not float with Python parameters. A generated physical threshold alone is not a new parametric Lean bridge or physical boundary-condition validation.

**Sommerfeld Lorenz reference (one matching site).** Read existing `src.graphene.transport_counting.L_LORENZ_SOMMERFELD`, whose current source computes `(pi**2/3)*(K_B/E_CHARGE)**2`. Units V^2K^-2; three significant figures. This reuses the existing owner outside formulas.py and does not duplicate the law. It is the semiclassical reference, not the measured enhanced Lorenz number. The Majumdar monolayer measurement, cross-device adoption and lack of noise-law validation remain explicit.

**Dean conductance and Johnson background (two matching sites).** `sigma_Q_SI` is produced in constants from the adopted4e^2/h and canonical charge/HBAR. Read that computed value; three significant figures, siemens. Use `johnson_current_psd(K_B,T_ambient_K,1/sigma_Q_SI)` for the background; two significant figures, A^2/Hz. Its third argument is resistance in ohms. These remain cross-device/model inputs for the bilayer prediction, not a measurement on that nozzle. Their provenance retrofit does not validate the entire Hawking-noise spectrum, greybody profile or integration-time estimate.

**Polariton decay rates (two matching sites).** The Paris standard rate is inverse registered8ps lifetime, three significant figures in s^-1. Do not merely read its duplicate hardcoded Gamma_pol field as proof of computation. The Penn rate uses the existing post-dictionary producer from measured1.8meV linewidth via elementary-charge/HBAR conversion; three significant figures in s^-1. Measured linewidths and the Falque maximum remain literal inputs. The exact Lean rational27347*10^8 is a separate source encoding, not a live Python output; its adverse-device predicate and placeholder-v_g disclosure remain. The approximate80micro-eV versus8ps conversion must not be promoted to exact equality.

## Substantive mismatches and integration holds

1. **The existing D1 semantic guard cannot read these generated inputs.** `check_d1_hierarchy_table` reads raw `paper_draft.tex`; its `_parse_latex_number` cannot parse `\input`. Replacing six BEC cells makes them unparseable. The two crossover arguments also cease parsing; generated crossover coefficients would miss the current digit-only pattern. A TABLES input removes the inline tabular itself. This is direct source evidence, not a run result. ROOT must reconcile compatibility through the existing semantic-reader owner while preserving all comparisons and failure paths. Do not disable the gate, narrow its population, duplicate hidden literals, add an alternate parser or call rendered provenance acceptance equivalent to scientific guard acceptance. ROOT identified `draft_input_closure` as the canonical path resolver, not a TeX expander. This does not imply a new generic parser is needed. The minimum existing-check seam remains ROOT-owned under architecture-change; no implementation for this dependency is authorized by this report.

2. **Dean has three different numerical operating points.** The stated c_s and200nm geometry give c_s/L=2.2e12s^-1; the adopted gradient is2e12s^-1; the stored temperature is rounded2.4K. constants computes omega_H from the rounded temperature, whereas the Hawking-law evaluation at the registered gradient yields gradient/(2pi). The existing3.14e11 is not that latter exact result. ROOT must evaluate and quantify, adjudicate physical/source meaning, then reconcile the prose, caption, ratio/greybody/quasi-bound and figure as one family. `fig_graphene_snr_frequency` calls `compute_graphene_spectrum`; the present proposal does not regenerate it. Keep the exact Lean literal quote unchanged.

3. **Bilayer versus monolayer velocity is load-bearing.** The draft's bilayer Fermi-liquid velocity~6.2e5 is expressly distinct from monolayer1e6. Yet the sentence l_ee=HBAR*v_F/(K_B*T)=51nm follows from the latter, and canonical constants/provenance actually use that assumed monolayer value. The transport path deliberately uses measured c_s to avoid that pairing. A scalar migration must not erase this difference or silently choose a new velocity: l_ee affects the error bound, D and cutoff, not only a displayed numeral.

4. **BEC kappa-scaling prose conflicts with its producer.** The hierarchy paragraph says both corrections scale as kappa^2 and their ratio is independent of kappa. At fixed upstream n,a_s,c_s, canonical Gamma_Bel scales as kappa^2 and delta_diss=Gamma_Bel/kappa scales as kappa. delta_disp remains quadratic at fixed xi,c_s. D1's earlier linear-scaling paragraph agrees with that. Generated values cannot make the contradictory claims both correct. The exact substantive replacement below repairs this algebra within the fixed-material/phenomenological and fixed-input Beliaev scope; no repository source was changed and no original physical construction is discharged.

5. **The accepted evaluator has stale documentation labels.** Its actual repaired computation uses log(1+1/delta) and spectral_floor=delta. The return docstring and human CLI labels/footer still say ln(2/delta) and delta/2 in places. Preserve the actual accepted computation. Do not use stale labels to restore the prior floor/leading-law error. This is a documentation mismatch, not evidence of a current computed failure.

6. **Two physical noise-family claims remain outside this retrofit.** The constant-greybody positive-frequency excess omega/(exp(a*omega)-1) decreases from its zero-frequency limit, so calling it a peak at50GHz needs a stated convention/band condition. The manuscript itself notes its minute estimate is not the canonical radiometer output. Generating the Johnson background settles neither issue. They must not be credited as fixed noise-family physics.

## Derived sites deliberately left without fabricated producers

Site13's bilayer velocity claims the density/mass formula HBAR*sqrt(pi*n)/m*, with n=1e12cm^-2. `bilayer_effective_mass` exists, but embeds hopping/monolayer values outside the canonical constants/formulas owners and no clean registered density/mass binding was established. A lambda using sqrt(2)*measured c_s would replace the stated derivation with a different one. It is not proposed.

Sites32/38 quote polariton noise temperature m*c_s^2/K_B. The source formula is stated in the paper and its inputs are registered, but no canonical formula producer was found in the inspected formulas/polariton-prediction source. A new physical expression in tables.py would duplicate/extend formula authority under an assignment that forbids new machinery or invented physical laws. These two sites stay visibly incomplete until ROOT reconciles the existing formula/grounding owner through the existing planner. This is not a claim that Lean lacks a theorem: LSP/import/history proof discovery was not performed or authorized. No missing-proof assignment is minted.

## Exact substantive scaling-paragraph repair

The numerical provenance package includes this algebraic correction, not merely a warning. Exact old/new paragraph bytes and hashes are in `/tmp/d1-derived-numeral-proposal-r1/SCALING_REPLACEMENT.json`; the replacement itself is `/tmp/d1-derived-numeral-proposal-r1/hierarchy_scaling_replacement.tex`. A bounded search of18 D1 review/catalog files found no matching scaling/ratio finding; this is not a corpus-wide absence claim and no duplicate finding or ledger entry was created. ROOT retains the existing planner/disposition decision.

The backing source statements `KappaScaling.kappa_scaling_dispersive_quadratic` and `kappa_scaling_dissipative_linear` were read directly, together with the actual Beliaev and first-order-correction implementations. They describe fixed-material algebra. No new native theorem certificate is asserted. The replacement does not assume a scattering-length sweep at fixed geometry keeps the solved surface gravity fixed.

```latex
The condensate rows compare corrections with different dependence on
surface gravity. At fixed healing length, sound speed and first-order
transport coefficients, Eqs.~\eqref{eq:delta-disp} and~\eqref{eq:delta-diss}
give $\delta_{\rm disp} \propto -\kappa^2$ and
$\delta_{\rm diss} \propto \kappa$, respectively. Their ratio is therefore
\begin{equation}
\frac{\delta_{\rm diss}}{|\delta_{\rm disp}|}
  = \frac{6(\gamma_1+\gamma_2)}{\pi\xi^2\kappa},
\end{equation}
which decreases inversely with $\kappa$ under those fixed-material
conditions. The zero-temperature Beliaev matching used for the benchmark
rows has the same dependence: $\Gamma_H \propto \kappa^2$ at fixed
upstream density, scattering length and sound speed, and the correction
is $\Gamma_H/\kappa$, not $\Gamma_H$ itself. The ratio distinguishes the
benchmark configurations, but is not invariant under a surface-gravity
sweep. A scattering-length sweep changes the healing length, sound speed
and microscopic damping together; its effect on the ratio must be
computed with the background and surface gravity recomputed, rather than
assuming that fixed geometry holds $\kappa$ fixed. These are scaling
statements within the adopted transport and background models, not a
microscopic derivation of those models.
```

For graphene, the prospective selection is the **registered gradient point**: provenance explicitly labels `T_H_K` DERIVED/rounded from the adopted2e12s^-1. The geometry estimate c_s/L remains an approximation; it does not supersede that registry point. The candidate deliberately recomputes temperature before deriving higher-precision frequency. Actual changed3-significant-digit frequency, plot and downstream numerical consequences remain held for ROOT evaluations and review; no velocity convention or projected-input status changes.

## Complete per-site classification

Actual TeX lines are shown below. The JSON also preserves the accepted audit's stripped offsets, exact match strings, seven-line source contexts and every proposed preimage/replacement. D=derived; S=measured/source/adopted input; T=exact theorem-statement numeral. All D rows remain unexecuted proposals, including lower-friction rows.

| Site | TeX line | Current numeral | Class | Proposed output / disposition |
|---:|---:|---|:---:|---|
| 1 | 1143 | `1.59\times10^{-3}` | D | `heidelberg_delta_diss` |
| 2 | 1145 | `2.38\times10^{-5}` | D | `steinhauer_delta_diss` |
| 3 | 1211 | `-8.53\times10^{-5}` | D | `steinhauer_delta_disp` |
| 4 | 1211 | `2.38\times10^{-5}` | D | `steinhauer_delta_diss` |
| 5 | 1212 | `-7.32\times10^{-5}` | D | `heidelberg_delta_disp` |
| 6 | 1212 | `1.59\times10^{-3}` | D | `heidelberg_delta_diss` |
| 7 | 1213 | `-9.89\times10^{-5}` | D | `trento_delta_disp` |
| 8 | 1213 | `1.41\times10^{-5}` | D | `trento_delta_diss` |
| 9 | 1268 | `1.59\times10^{-3}` | D | `heidelberg_delta_diss` |
| 10 | 1268 | `2.38\times10^{-5}` | D | `steinhauer_delta_diss` |
| 11 | 1269 | `1.41\times10^{-5}` | D | `trento_delta_diss` |
| 12 | 1335 | `4.4\times 10^5` | S | `retain source literal` |
| 13 | 1337 | `6.2\times 10^5` | D | `producer binding incomplete` |
| 14 | 1428 | `2.6\times10^{-3}` | D | `dean_profile_error (hold)` |
| 15 | 1429 | `1.5\times10^{-2}` | D | `dean_evanescent_error (hold)` |
| 16 | 1506 | `4.4\times 10^{5}` | S | `retain source literal` |
| 17 | 1602 | `2.44\times10^{-8}` | D | `lorenz_sommerfeld` |
| 18 | 1630 | `4.4\times 10^5` | S | `retain source literal` |
| 19 | 1635 | `2.4` | D | `dean_hawking_temperature_k (hold)` |
| 20 | 1638 | `3.14\times10^{11}` | D | `dean_omega_h_s1 (hold)` |
| 21 | 1659 | `1.38\times10^{12}` | D | `dean_channel_s1` |
| 22 | 1665 | `4.4\times10^5` | T | `retain source literal` |
| 23 | 1666 | `3.14\times 10^{11}` | T | `retain source literal` |
| 24 | 1698 | `1.55\times10^{-4}` | D | `dean_sigma_q_siemens` |
| 25 | 1700 | `1.3\times10^{-24}` | D | `dean_johnson_psd` |
| 26 | 1721 | `4.4\times10^5` | S | `retain source literal` |
| 27 | 1725 | `3.14\times10^{11}` | D | `dean_omega_h_s1 (hold)` |
| 28 | 1808 | `0.08` | S | `retain source literal` |
| 29 | 1809 | `0.11` | S | `retain source literal` |
| 30 | 1811 | `1.1\times10^{11}` | S | `retain source literal` |
| 31 | 1829 | `7.0\times10^{-35}` | S | `retain source literal` |
| 32 | 1895 | `0.81` | D | `producer binding incomplete` |
| 33 | 1951 | `1.25\times10^{11}` | D | `paris_cavity_rate_s1` |
| 34 | 1970 | `2.3` | S | `retain source literal` |
| 35 | 1971 | `1.8` | S | `retain source literal` |
| 36 | 1974 | `2.73\times10^{12}` | D | `penn_lp_rate_s1` |
| 37 | 1976 | `1.1\times10^{11}` | S | `retain source literal` |
| 38 | 2029 | `0.81` | D | `producer binding incomplete` |

## Required acceptance and verification

ROOT should first commission independent full source/composition review of this proposal, including the claimed producer gaps and every operating-point hold. Then ROOT performs controlled actual canonical evaluations, compares unrounded and formatted values against all current physical claims/consumers, preserves full source custody and resolves substantive mismatches. In particular, the BEC guard compatibility must be solved without losing its six-cell, dominance and two-crossover semantic protection. No generated literal can substitute for the original physical derivation.

Only then use the existing renderer, with input-sensitivity/output-corruption/restoration controls and exact source/output custody; compile D1 out of tree and inspect every page. Moving captions need safe treatment using established conventions, not unreviewed fragile input expansion. Run change-appropriate existing D1/F/platform tests and semantic gates, the unchanged numerical-literal predicate/ceiling, broader fast/full pipeline gates required by the eventual change, and existing catalog/source/F-binding writers/reviews. Crossovers and bare/dressed temperatures must preserve the accepted full Planck/floor law. No scientific proof, human verification, current full gate or publication claim follows from this report.

Commands actually run were continuity help/check; read-only cat/sed/rg and Git status; and stdlib text/JSON/hash/AST report construction. No project module import/function execution, test, renderer, validation runner (apart from the required continuity adapter), native operation, Lean/backend, build, plot, compile, network, slot/controller or Git mutation was performed. Only the assigned off-tree files were touched. The claims-reviewer persona supplied source/claim classification discipline; this is not a full sentence-walk claims_review.json or scientific acceptance pass.

## Exact source pins

All current source/authority/proposal SHA256 pins are in the companion JSON. The following are the central source pins:

- `papers/D1/paper_draft.tex`: `badd7db66a368bc0a80620e10e552e2a56d52ac0fc65f63f60b9651b6a1ee614`
- `scripts/gen_d1_hierarchy_table.py`: `8a8c15b7e00c7dcb7e9f47d0e09ba79d8a16e8c1c8153852b4c8bc8966feb845`
- `src/wkb/spectrum.py`: `04dd00f3ea02f0931ac7f95772abebb1b64c990903d2db2053e848d3cb8cdf4e`
- `src/core/constants.py`: `10ed8fed72f61002dbfc561b24537d8e61d6cb8abd9949d260505bbe458204f0`
- `src/core/formulas.py`: `ef3e76f28ab0bcad83311ba029b1a8fb19fd2cb161e6186d161ccf7ccf7cb836`
- `src/core/provenance.py`: `301d9db0be7404cb44834233eb7847d2eee3a14283298abcb6ddab11057b5983`
- `scripts/validation/checks/physics.py`: `2bb4643658c9844ef05f59f955522a1f73bc0997c9d00125a1964902f0160bbf`
- `src/graphene/transport_counting.py`: `861be873c58f0b322511e2b15c536e8f4fc5fd69fceb63b2e07648c368648173`
- Exact proposed SCALARS file: `afbbb416577038ae4f4c36a7d681ed57d810e9c8e28560f4d5e7b3938c9593a3`.

## Final SAME-packet continuity

Final SAME-packet `codex_continuity.py check` returned **fresh=true; changed=[]**, exit0. Final `git status --short` produced no output (clean). Matching input state grants no lease, execution, review or completion authority. Only assigned off-tree artifacts were written.
