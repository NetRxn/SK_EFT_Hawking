import json,re,sys,hashlib,subprocess
from pathlib import Path
O=Path('/tmp/l1-reader-results-claims-20261105-r1');R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from sentence_state import validate_claims_review,normalize_quote,compute_sentence_id
c=json.loads((O/'coverage.json').read_text());u=json.loads((O/'units.json').read_text());d=json.loads((O/'claims_review.json').read_text());base=json.loads((R/'papers/L1/claims_review.json').read_text());t=Path('papers/L1/paper_draft.tex').read_text();bits=[False]*len(t)
for x in c:
 for i in range(x['char_start'],x['char_end_exclusive']):bits[i]=True
for a,b in zip(c,c[1:]):assert a['char_end_exclusive']<=b['char_start']
m=re.sub(r'\\(?:label|begin|end)\{[^}]*\}|\\item\s*',lambda x:' '*len(x[0]),t)
gaps=[]
for i,x in enumerate(u):
 q=re.sub(r'\\(?:begin|end)\{(?:equation\*?|aligned|theorem)\}',lambda x:' '*len(x[0]),x['quote'])
 ms=list(re.finditer(r'\s+'.join(map(re.escape,q.split())),m));assert len(ms)==1,(i,len(ms),q)
 a,b=ms[0].span();v=''.join(t[j] if not bits[j] else ' ' for j in range(a,b))
 v=re.sub(r'\\(?:begin|end)\{[^}]*\}|\\item\s*','',v)
 if v.strip():gaps.append({'walker_unit':i,'uncovered':v.strip()})
assert not gaps,gaps
coverage={'ordered_nonoverlap':True,'all_walker_units':len(u),'uncovered_prose':gaps,'note':'Walker is adapted existing scratch walker; sentence IDs, normalization and schema use canonical sentence_state helpers. Existing nonchanged unit granularity retained.'}
(O/'coverage-walk-audit.json').write_text(json.dumps(coverage,indent=2)+'\n')
# Byte preservation and exact current binding readback.
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=json.loads((O/'preservation.json').read_text());assert all(sha(R/'papers/L1'/k)==v for k,v in p['human_and_audit_pins'].items())
assert sha(R/'papers/L1/claims_review.json')=='8e53db0cdcddc0240dab137892980cd71167938683355fb57ec17285d813291c'
for s in d['sentences']:
 assert compute_sentence_id('L1',s['section'],s['quote'])[0]==s['id']
assert not validate_claims_review(d)
for command,name in [(['python3','scripts/sentence_state.py','validate',str(O/'claims_review.json')],'schema-validation.json'),(['python3','scripts/sentence_state.py','ingest_agent_run',str(O/'claims_review.json'),'--dry-run'],'ingest-dry-run.json')]:
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr;(O/name).write_text(r.stdout)
print(json.dumps({'schema':True,'walk_prose_complete':True,'canonical_human_audit_unchanged':True,'active_units':len(d['sentences']),'existing_writer_dry_run_only':True},indent=2))
