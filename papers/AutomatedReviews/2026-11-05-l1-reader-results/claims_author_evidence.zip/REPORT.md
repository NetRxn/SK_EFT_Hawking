# L1 reader-results claims catalog proposal

Complete scratch proposal only. No canonical catalog, prose-state, audit-log, notebook, Git or source write, real ingest, closure, Lean/LSP/slot/native job or scientific test run was performed. ROOT remains sole integrator/closure owner; independent catalog acceptance remains required.

The initial continuity check returned fresh=true, changed=[]. Final packet check reports authority[7]/source changed, exactly the manuscript/source revision ROOT explicitly authorized; it was preserved in continuity-final.json, not silently refreshed. ROOT subsequently explicitly authorized reconciliation of the one-phrase r3 antecedent repair, replacing “It contains” with “The compatible interval contains”. Current manuscript SHA256 is `e773c9f57a480f972f8d31304cbf6a14e9e0341ad452729c6329b1a0c8e60b6f`, equal to ROOT's `/tmp/l1-results-observation-725-r3-full.tex`. The catalog baseline remains `8e53db0cdcddc0240dab137892980cd71167938683355fb57ec17285d813291c`. HEAD readback remains `7258784b74dcdd34e8ca1a56f5d7ff67a366a292`; no silent global source refresh occurred.

## Complete coverage and preservation

- 128 current review units: 93 PASS, 6 WARN, 25 INFO, 3 TRANSITION, 1 UNGROUNDED. These are catalog/source assessments, not a full Stage10 verdict.
- 85 unaffected original assessments are structurally identical apart from actual line positions, section ordinals and review indices. This includes all unchanged scientific Discussion, abstract, RPA/range/provenance and caption subunits.
- 38 affected original records are preserved fully in the dated `review_evidence.reader_results_refresh.old_records_preserved` object; 43 successor units carry explicit predecessor references.
- `lineage.json` accounts for every one of the 123 predecessors. Scientific clauses survive split/merge/rewrite; removal of repeated process/tactic/identifier inventory is explicitly distinguished from deleting science. A removed caption inventory remains represented through actual source links; the full prior inventory remains in history.
- All four blocker objects, all followups, all reproducing objects, all 54 candidate supersessions and all prior review-scope/evidence objects remain structurally unchanged. Zero automatic closures. Human-state/audit hashes match readback.
- Every current quote has one actual manuscript binding with only labels masked, correct normalized content, existing-helper hash/ID, exact line/character span, current ordered review index and section ordinal. Current units do not overlap. Adapted existing scratch sentence walk finds no uncovered prose in 126 walker units; existing catalog granularity outside changed areas is retained.

The unchanged four blocker objects intentionally retain their original historical sentence references. `lineage.json`, also embedded in the catalog evidence, maps them to current successors. Rewriting those objects would violate the explicit preservation instruction; their unchanged IDs do not imply absence of successor coverage.

## Source assessment and actual backing

Personally read actual `GravitationalWaves.lean` speed/deviation definitions, positive-speed/relative-deviation/strict-monotonicity/zero-anchor proof bodies, fixed real tolerance and cap predicate, nonnegative-domain iff proof, strict nesting/unity/width/strict width-comparison proofs, endpoint proofs, nonzero-c theorem binders and bodies, exact three-conjunct Prop and all four falsifier bodies. Read actual scalar RPA definition/denominator hypothesis. The carrier is ordinary Mathlib Real with Set.Icc/Set.Ici, not a physical state or calibrated tensor response.

Read formula implementations, GW constants, provenance L1 dependencies, registry identity, grid and constraint wrappers, plot producer and current scientific-input tests. The tests include exact rational width/nesting, Decimal endpoint/reference/ratio/rounding and figure data/callout/unresolved-width controls. No tests were executed here. The supplied ROOT current receipt reports 89 passed in0.13s, pinned separately; all historical81/89 receipts and their dates remain intact.

Personally read the Abbott primary carrying section4 introduction, all4.1 and its right-column continuation ending immediately before4.2 in the complete held body extraction. Printed p6 explicitly bases the bound on offset/distance/emission difference, adopts26Mpc, uses simultaneous emission for the upper endpoint and10s later SGRB emission for the lower, prints the asymmetric range in Eq.(1), and discusses alternative histories broadening it. The continuation distinguishes emission lag from distance-dependent propagation. The held PDF SHA256 is `bf06bd2ae6a23cf7f7092307677c2b681ce02abab3b5bbe37bbce76a8960140a`; title, journal, DOI and current registry identity agree. No new acquisition/custody field, bibkey, prior, source-lag likelihood or parameter inference was added.

`link-resolution.json` corroborates every new linked name with actual source and the existing cached declaration index, including actual declaration kind/type and cached axiom metadata. The cached index is not a new kernel result. `theorem` link-kind for a source definition follows the existing schema's declaration-reference convention; actual kind and source-scope qualifiers are explicit.

## Assessment changes for ROOT review

The old unit49 WARN concerned a list inaccurately calling `c_GW_deviation` a lemma. The list is gone; its scientific statements are now explicit positivity, relative deviation and nonnegative monotonicity/anchor statements. Those successors receive source-scoped PASS because actual statements and proof bodies support precisely those conditions. Old WARN and all its reasoning are preserved fully. This is not a physical-law promotion.

The changed leading caption remains WARN. Explicit symmetric-envelope wording is primary-source supported, but no fresh figure/render or full provenance acceptance is inferred. Its unchanged numeric/finite-window/anchor subunits retain their existing assessments exactly.

The old conditional-law interpretive INFO maps both to the current width/conditional interpretation and explicit physical-requirements INFO. A current exact theorem-quantifier limitation receives source-scoped PASS after inspecting actual binders; no absence-of-proof inference or global impossibility claim is made. All other mathematical successor PASS assessments remain conditional/source-scoped. New observation qualifier sentences receive primary-source scoped PASS. The sole prior UNGROUNDED normalization statement and every original physical blocker remain.

The whole physical spine remains BLOCK. No B3 normalization/adopted-range derivation, physical state, tensor mode, common matter/light reference or controlled transport/frequency match has been constructed or accepted by this maintenance. ROOT reports four clean pages and3267/3750repository word-equivalents; those are supplied render/length receipts, not independently verified journal policy or native scientific acceptance.

## Validation and deliverables

`claims_review.json`, `coverage.json`, `coverage-walk-audit.json`, `lineage.json`, `preservation.json`, `readback.json`, `link-resolution.json`, `schema-validation.json`, `ingest-dry-run.json` and `claims_review.diff` are complete in this directory. `build.py`, adapted `walk.py`, and `verify.py` provide scratch reproducibility. Every generated file is under `/tmp/l1-reader-results-claims-20261105-r1/`; no tracked workspace file was touched.

Existing `scripts/sentence_state.py validate` passed with128sentences. Existing writer `ingest_agent_run --dry-run` passed with54candidates/zeroautomaticclosures and performed no real ingest. Readback asserts baseline catalog, human-state and audit bytes unchanged. Dry-run tombstones are empty because that command compares prose-state, not the full prior catalog; exhaustive predecessor accounting is supplied independently by `lineage.json`, not inferred from that empty list.

## ROOT r3 continuity reissue

ROOT explicitly reissued `l1-reader-results-claims-r3.json` after reconciling the exact one-antecedent manuscript and corresponding PDF changes. Recovery check returned fresh=true, changed=[]. The reissue receipt is `continuity-r3-reissue.json`, and its packet pin/result are appended to `readback.json`. Initial r2 freshness and final expected-stale evidence remain preserved; `continuity-final.json` is untouched. The128-unit proposal bytes and SHA256 remain unchanged at `77197b489bc16f6e6f61770dba3580f6a3d52efd779c50adeb6d837a4a01f18c`. No catalog rebuild, scientific execution, real ingest or canonical mutation was performed. Independent catalog review remains next.

## CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

No contradiction in the current manuscript science or authorized r3 antecedent repair. The existing bundle-prompt L1 anchor misleadingly calls Abbott the detection paper and gives an unqualified natural-range falsification factor; actual registry/primary identify the multimessenger ApJL paper and endpoint-only factors. This proposal follows actual source rather than that stale anchor shorthand and does not edit it. The existing Lean aggregate comment asserts independent necessity of the three Prop clauses, while actual fixed-tolerance definition/proofs give P2⇒P3prime; the manuscript correctly states dependence. ROOT's separate source-comment obligation remains open. The Results independent report also records that cross-reference occurrence counts changed, although label definitions/targets and scientific content were preserved.
