
import sys
sys.path.insert(0, '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103')
mode = 'rounded-deviation'
if mode != 'baseline':
    from src.core.provenance import PARAMETER_PROVENANCE
    for arm in ('LOWER', 'UPPER'):
        record = PARAMETER_PROVENANCE[f'GW.C_GW_DEVIATION_{arm}_BOUND']
        record['source'] = record['source'].replace('Eq. (5)', 'Eq. (1)')
if mode == 'wrong-cap':
    from src.core.constants import GW_PARAMS
    GW_PARAMS['C_GW_TWO_SIDED_CAP'] = 7e-16
if mode == 'swapped-star':
    import src.core.visualizations as visualizations
    original = visualizations.fig_c_GW_vs_ligo_constraint
    def wrong_star():
        figure = original()
        figure.data[2].x = [0.0]
        figure.data[2].y = [1.0]
        return figure
    visualizations.fig_c_GW_vs_ligo_constraint = wrong_star
if mode == 'rounded-deviation':
    import src.gravitational_waves as gw
    original = gw.ligo_compatibility_check
    def rounded_deviation(chi):
        verdict = original(chi)
        verdict.deviation = round(verdict.deviation, 2)
        return verdict
    gw.ligo_compatibility_check = rounded_deviation
import pytest
raise SystemExit(pytest.main(['-c', '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l1-checkpoint-20261103/pyproject.toml', '/tmp/l1-numeric-acceptance-author-20261105-r2/test_gravitational_waves.py', '-q', '-k', 'endpoint_deviation_rounding']))
