# L3 existing cutoff/profile composition — exact focused target R2

UNAPPLIED source proposal for existing clean focused PR112 checkout `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/.publication-l3-crossing-main`, HEAD `a34eb6b08fb85e43f3d5e5071f45db6a8e7ebf57`. Donor is immutable `f905a2873a32269c3d21651abb2b64825a212c3d`. ROOT retains L1 lead, native freeze, all integration, scientific/source acceptance and publication. No new worktree or branch route is proposed. R1 remains unchanged as the original8ad proposal.

Only `/tmp/l3-existing-cutoff-profile-composition-r2.patch`, `.md` and `.json` are written. JSON contains the exact complete four proposed source postimages, pre/post SHA256, patch hash, per-hunk provenance, focused producer text and preserved stronger3.2 section. No repository/source/notebook/Git mutation, tests/Verify/validators, scientific imports, native/Lean/LSP/MCP/extraction/build/controller/cache/runtime or process actions occurred. The explicitly required read-only continuity adapter is the sole repository helper executed.

## Actual focused target and preserved source

Initial same-packet continuity check returned exit0 `fresh=true, changed=[]`. Actual focused HEAD is a34eb6b08 with clean tracked/untracked state. Thermodynamics and metadata preimages equal the original8ad packet; actual review and manuscript differ. Read exact focused source and Git object diff rather than assuming applicability. The focused branch already carries the critical-mass crossing fromac3ef2d6 and historical scoped3.2 closure5780a47b, plus JETP source and closureb91e1caa/a34eb6b08. Those original records and source identities are preserved, not recreated or transferred from donor.

Personally read focused `fig_T_H_evolution_regime_partition` source and viewed its actual2200x1200PNG. Left data are the exponential `exp(-t)` with normalized initial temperature/timescale and a representative inverse-mass trajectory `M(t)=(1-0.2*t)^(1/3)` sampled before its illustrative endpoint. Right data evaluate `M_c_default`, canonical `G_N_emergent`, masses at ratios0..2 and normalize both lengths by the cutoff; the two traces are normalized gravitational length and constant1. Blue/amber regions mark mass ratios below/above1 and a vertical marker gives the boundary. This is direct source/image correspondence inspection, not a fresh numerical run or render acceptance.

The R2 caption retains the actual focused emergent-length/cutoff crossing and shading prose. Its only semantic changes are to call the blue curve an illustrative exponential, remove false attribution of the two plotted profiles to the old supplied-sign transport proof, and distinguish those plots from the local affine nozzle theorem. No main8ad delta-response caption or donor replacement figure is imported. No reader is told that the PNG plots the affine profile.

Original focused finding3.2 retains its complete actual production trace/crossing Verify and explanatory text, byte-for-byte; the entire3.2 section through its separator is preserved. That command evaluates actual traces, samples on each side of1, constant cutoff and branch shading. The weaker main8ad source-token proxy is not present. No3.2 command was run. Existing canonical historical closure records its earlier exit0 and independent scoped review; it is historical evidence for that panel, not approval of these new proofs or all figure science.

Actual stored source manifest is datedMay12,2026 and remains historical. Stored figure review is May6 and explicitly describes the old delta-response panel and BEC wording, despite its PASS label. Stored claims review/audit are May6 and concern the older manuscript. None binds this focused crossing PNG or new R2 source. They remain unchanged and are not promoted as fresh acceptance. Actual image still labels its exponential curve Acoustic/sonic(Balbinot2005) and the cooling annotation overlaps it; the caption now discloses the model, while producer/asset/source-claim and fresh visual review remain owed outside this four-file assignment. These observations are reported, not hidden by replacing stored reviews or regenerating outputs.

## Exact reused propositions and proof prerequisites

- Three cutoff proofs are verbatim fromf905, authored5d2d829ea138e653bb8dc2e8ba3cee34e270b2a5. Bare `G_N_sakharov*M_c=1/(alpha*Lambda)`; emergent `G_N_emerg_eval*M_c=1/Lambda`; products agree iffalpha=1. Positive alpha/Lambda/N_f imply nonzero denominators. Bare proof unfolds existing definitions and uses field_simp; emergent proof consumes the bare identity after unfolding the alpha factor; equality consumes both identities and cancellation. This establishes defined algebra, not physical crossover coefficient selection.
- `schwarzschild_profile_deriv` is verbatim fromf905/b1a90e49c. Input `HasDerivAt mass dM t`, positive mass and negative local mass derivative; conclusion is actual `HasDerivAt` of `T_H_schwarzschild(mass(s))` with derivative `-(8*pi*dM)/(8*pi*mass(t))^2>0`. The proof uses quotient/constant-multiplication differentiation directly, not order-monotonicity as a substitute for derivative existence.
- `balbinotRelativeCoolingRate`, `balbinotAffine` and `balbinotCoolingCoefficient` are verbatim definitions: lambda=`563/(720*pi)*epsilon*kappa^3*c*A0`, profile=`T0*(1-lambda*t)`, coefficient=`T0*lambda`, where T0=`c*kappa/(2*pi)`. `balbinotAffine_deriv` differentiates this explicit formula and derives strict negativity for positive c,kappa,A0,epsilon. Its mathematical derivative is true at all t; physical use remains restricted to the supplied local nozzle domain.
- `regime_partition_profile_criterion` is verbatim fromf905/b1a90e49c. Positive nozzle parameters and `0<eta<1`; upper-branch mass trajectory through b.M with actual derivative<0; lower-branch `t>=0`, `c*kappa*t<eta`, `lambda*t<1`. Proof consumes existing classifier iff theorems, mass link/BHData.M_pos, and both derivative helpers. Conclusion gives upper derivative>0, lower domain and temperature positivity plus derivative<0, and equality iff Boundary. It proves no strict sign at equality and supplies no estimate deriving the short-time budget from a remainder.
- Old `H_RegimePartition`, `regime_partition_criterion`, `classify`/Regime roots, FourLaws structures, entropy scalar bundle and falsifiers keep their exact types/proof terms. The old theorem transports supplied signs. No field/root rename, no new H structure, no new axiom or proof is introduced. Comments and metadata now disclose the old and new theorem scopes accurately.

All nine donor declarations remain exact text; all six theorem proofs and three definitions are preserved. Same direct imports: `SKEFTHawking.Basic`, `SKEFTHawking.LinearizedEFE`, `SKEFTHawking.BHEntropyMicroscopic`, `Mathlib`. Actual focused toolchain/lakefile/manifest bytes equal immutable donor (exact hashes in JSON). Existing thermodynamics provides ADWParams/BHData/M_c/temperature/classifier APIs; current LinearizedEFE supplies both coupling definitions. No additional module prerequisite is identified for this bounded source composition. This is static prerequisite/type inspection, not kernel qualification or global substrate discovery; LSP-dependent discovery remains incomplete, with no grep-missing inference.

Balbinot source parameter/local-regime reading from R1 remains applicable: actual throat-area definition, physical surface gravity c^2*kappa, dimensionlessepsilon, source short-time condition, Eq.Tsonic and complete fate section were read. The source supplies a constant-c local nozzle calculation, extrapolates its late-time tail and defers condensates. Correct bulk JV1998 cooling versus thin-film JK2002/JETP contrast attribution stays intact. Neither attribution nor additive algebra selects a physical ADW branch.

## Existing consumer and Verify semantics

Original finding2.2 identity/severity/lane/gate and Observed/Evidence/Expected/Fix remain. Proposed unexecuted Verify reconciliation now requires the extracted additive theorem and direct value dependencies on both derivative proofs and all three classifier iff results, rejects supplied H sign projections, and checks derivative/profile/domain/boundary type content plus metadata interface distinction. It no longer demands a mathematically unnecessary call to `T_H_schwarzschild_strict_decreasing`. Source/registry token predicates remain only a regression decider; independent full actual type/sign/hypothesis/proof/axiom/source correspondence review and current authoritative extraction remain necessary. Lean proof binder names may disappear when pretty-printed, so no `hshort` binder-name test is required.

Existing finding2.3 receives the exactf905 already accepted metadata-correction Verify: standalone positivity must match the corrected claim, and the separate delta-equivalence theorem must retain its actual hypothesis-linked type. This fixes consumer attribution without falsely inserting delta/H into the standalone positivity statement. No closure ledger row is copied. Existing full-laws2.1 and cutoff2.4 Verify remain unchanged. Existing3.2 production controls remain byte-exact. No commands are executed and no new check/gate/planner/threshold is introduced.

- `papers/L3/paper_draft.tex`: Cites additive profile criterion/emergent cutoff identity; focused cutoff-crossing caption retained, left exponential explicitly illustrative and distinct from affine proof; original full-laws obligations remain.
- `papers/L3/bundle_metadata.json`: Original transport root retained and honestly described; additive profile/cutoff apex entries added; old exponential/falsifier consumers corrected. No charter reduction/readiness promotion.
- `papers/AutomatedReviews/2026-08-15-l3-stage10-redraft/L3.md`: Existing 2.2 Verify retargets actual additive proof route; 2.3 follows existing metadata-correction route. Finding2.1 and2.4 deciders remain unchanged; no execution/closure. Stronger original focused3.2 section remains byte-exact.
- `papers/D3/paper_draft.tex`: Existing §regime_partition explains old criterion as conditional transport. It does not automatically consume/qualify new additive theorem; separate reviewed propagation remains owed.
- `papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex`: Existing lines308/484 old-root references preserved; historical claims do not become profile-derivative or full-laws evidence.
- `src/core/visualizations.py`: Actual focused producer computes representative exponential and normalized Schwarzschild histories plus normalized G_emerg*M/cutoff crossing at M/Mc=1; producer andPNG unchanged. Existing3.2 production trace Verify byte-exact, historical closure retained. Stale exponential attribution/annotation remain separately owed.
- `src/core/constants.py`: Existing H_RegimePartition registry entry around4126 incorrectly describes GL entropy current. No new H structure created; preserved old interface avoids a new registry dependency, but existing propagation debt remains ROOT-owned.
- `tests/test_bh_thermodynamics.py`: Existing test_regime_partition_criterion_lean_anchor checks supplied scalar signs; documentation axiom case is not kernel verification. Retained old root preserves this actual scope. No tests executed.
- `tests/test_d5_lean_substrate.py`: Existing old-root apex substance positive fixture unchanged. It is not evidence that new profile signs were elaborated.
- `tests/test_d5_bundles_readiness.py`: Existing REAL old-root fixtures unchanged; no old root or field renamed to satisfy a decider.
- `lean/SKEFTHawking.lean; lean/SKEFTHawking/ExtractDeps.lean; lean/lean_deps.json`: Existing aggregate imports thermodynamics; extractor imports aggregate. Exact-candidate build/extraction is ROOT-owned and remains unexecuted for this proposal.

## Per-hunk provenance

`lean/SKEFTHawking/BHThermodynamicsFourLaws.lean`

- `@@ -10,15 +10,16 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -33,13 +34,18 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -123,15 +129,15 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -213,9 +219,9 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -294,9 +300,8 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -308,6 +313,39 @@`: Exact f905 cutoff proof block, authored5d2d829ea; actual focused prerequisites/imports unchanged.
- `@@ -367,17 +405,13 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -394,10 +428,8 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -447,8 +479,8 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -509,18 +541,10 @@`: Inherited R1 current-source documentation scoping: physical model selection/laws and supplied transport versus affine/exponential distinction; no Lean term changes.
- `@@ -534,6 +558,86 @@`: Exact f905 three definitions/three profile theorem block, authoredb1a90e49c; no proof modification.
- `@@ -845,8 +949,8 @@`: Existing f905 GL local-equilibrium source correction2b73ca539.

`papers/AutomatedReviews/2026-08-15-l3-stage10-redraft/L3.md`

- `@@ -133,22 +133,23 @@`: R1 existing2.2 semantic Verify proposal plus exact f9052.3 correction route; actual focused3.2 and all remaining original findings preserved.

`papers/L3/bundle_metadata.json`

- `@@ -3,7 +3,7 @@`: R1 type-grounded apex consumer composition; focused non-apex metadata remains byte-identical.
- `@@ -28,7 +28,7 @@`: R1 type-grounded apex consumer composition; focused non-apex metadata remains byte-identical.
- `@@ -43,8 +43,18 @@`: R1 type-grounded apex consumer composition; focused non-apex metadata remains byte-identical.
- `@@ -63,7 +73,7 @@`: R1 type-grounded apex consumer composition; focused non-apex metadata remains byte-identical.

`papers/L3/paper_draft.tex`

- `@@ -28,15 +28,13 @@`: R1 local-source/profile/cutoff manuscript composition deriving from3ef2dea6c,680c420a7,9405f7552,4de686400 as present atf905; current scope clarifications retain original physics obligations and withhold excluded geometry.
- `@@ -49,14 +47,13 @@`: R1 local-source/profile/cutoff manuscript composition deriving from3ef2dea6c,680c420a7,9405f7552,4de686400 as present atf905; current scope clarifications retain original physics obligations and withhold excluded geometry.
- `@@ -65,28 +62,25 @@`: R1 local-source/profile/cutoff manuscript composition deriving from3ef2dea6c,680c420a7,9405f7552,4de686400 as present atf905; current scope clarifications retain original physics obligations and withhold excluded geometry.
- `@@ -103,7 +97,7 @@`: R1 local-source/profile/cutoff manuscript composition deriving from3ef2dea6c,680c420a7,9405f7552,4de686400 as present atf905; current scope clarifications retain original physics obligations and withhold excluded geometry.
- `@@ -115,7 +109,11 @@`: R1 local-source/profile/cutoff manuscript composition deriving from3ef2dea6c,680c420a7,9405f7552,4de686400 as present atf905; current scope clarifications retain original physics obligations and withhold excluded geometry.
- `@@ -169,62 +167,60 @@`: R1 local-source/profile/cutoff manuscript composition deriving from3ef2dea6c,680c420a7,9405f7552,4de686400 as present atf905; current scope clarifications retain original physics obligations and withhold excluded geometry.
- `@@ -236,12 +232,14 @@`: R1 local-source/profile/cutoff manuscript composition deriving from3ef2dea6c,680c420a7,9405f7552,4de686400 as present atf905; current scope clarifications retain original physics obligations and withhold excluded geometry.
- `@@ -303,9 +301,8 @@`: R1 local-source/profile/cutoff manuscript composition deriving from3ef2dea6c,680c420a7,9405f7552,4de686400 as present atf905; current scope clarifications retain original physics obligations and withhold excluded geometry.

## Withheld scope and unchanged original acceptance

- ExactSolutions fixed-G/varying-G first-law and ingoing vacuum/horizon/ADM manuscript paragraphs: Require actual excluded ExactSolutions and ADMFormalism source constructions plus their full qualified import closure. No scope expansion attempted.
- Figure producer, PNG/PDF, manifests, counts, historical reviews/audits and closure ledger: Existing focused crossing is retained, no donor generated outputs or closure state imported; four-file source composition only.
- Stronger focused original3.2 Verify: Retained byte-exact with historical evidence. No weaker source-token proxy introduced and no rerun implied.

No extra module or new construction is requested. Existing fixed-G/varying-G, vacuum/horizon/Ricci/ADM/EH results are credited as preserved research and are not redispatched or falsely attributed to this focused postimage. Broader donor geometry paragraphs, NJL history, generated outputs, donor census/freshness dates and closures are withheld.

Original physical first/zeroth/third laws; acoustic energy/entropy/current-divergence balance; microscopic ADW action/exterior/mass and real branch matching; physical cutoff coefficient selection; and quantitative remainder derivative control remain OPEN. For a trajectory `T0*(1-lambda*t)+R(t)`, cooling requires `R'(t)<T0*lambda`; this composition does not establish that bound. The separately preserved geometry chain still owes analytic metric-path/uniform-box/mixed-partial/domination/boundary, Euler and renormalized cosmological-term requirements. Existing GL current or density positivity alone does not identify the physical acoustic flux divergence.

All non-apex metadata values remain actualfocused, including title/charter, human/readiness/stage fields, stale flag, source-manifest date and cached counts. Existing historical review/closure source records remain untouched. Generated counts/PDF/PNG/manifests are not refreshed; no source-only comparison or old PASS is presented as current qualification. ROOT owns independent mathematical/source review of exactfourpostimages, legitimate application after freeze/admission, authoritative build/declaration refresh and original meaningful controls, canonical closure writer/readback, fullproject/main qualification, current claims/render/reader/venue review, orderedStage9/10thenfullStage13 and final human/publication acceptance. No new gate/threshold or reduced scientific charter is proposed.

## Continuity and artifact identity

Initial same-packet adapter result was exit0 `fresh=true, changed=[]`. Final same-packet check/readback is recorded below and in JSON. Unlike R1’s frozen8ad checkout, the R2 focused target begins clean with no generated hash drift. The separate main8ad generated `lean_deps.json.hash` modification belongs to ROOT’s native run; it neither changes this target packet nor qualifies these proposed proofs. R1’s three hashes are preserved in JSON and will be read back unchanged. No snapshot refresh masks changed authority.

Actual actions: read-only text/Git object/status/hash inspection; image viewing; stdlib in-memory text/JSON/diff composition restricted to three R2 outputs; initial/final continuity check. No apply/check simulation or validator ran. Exact proposed postimages are embedded in JSON for independent review without application.


Final SAMEpacket adapter check returned exit0, `fresh=true, changed=[]`.
Final focused HEAD remains `a34eb6b08fb85e43f3d5e5071f45db6a8e7ebf57`;
`git status --short` is empty. Allfour source preimages and packet references
remain unchanged. R1patch/md/json final hashes equal the initial recorded
hashes exactly. R2patch SHA256 is
`ce68d4ed3b95a30456ca424bba5909e313465f5d22f67a3e2ca56b337e80bb79`.
This is input/source-artifact correspondence only. No application,
scientific execution, current extraction, kernel/stage/closure/main or
publication acceptance is claimed.
