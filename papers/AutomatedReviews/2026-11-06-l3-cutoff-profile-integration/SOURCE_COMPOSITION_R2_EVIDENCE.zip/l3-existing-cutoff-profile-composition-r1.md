# Existing L3 cutoff/profile composition — unapplied r1

Prepared against frozen main-delivery `8ad1411526b8b8d5b49e9f3b9993b8083ec887d9` using immutable research `f905a2873a32269c3d21651abb2b64825a212c3d`. Only the adjacent `.patch`, this report and `.json` are written under `/tmp`. No repository/notebook changes, Git mutations, scientific Python imports, tests, Verify/validator, native/Lean/LSP/MCP, extraction/build/controller/cache or process actions occurred. The only executed repository helper is the explicitly required read-only continuity check. ROOT retains L1, native freeze, integration, independent acceptance and publication.

The patch is a source proposal, not applied, reviewed, elaborated, extracted, compiled, stage-accepted or canonically closed. It imports six existing theorem bodies and three existing definitions verbatim; all nine captured donor declarations remain exact text. No new mathematical proof is supplied. The donor thermodynamics delta was119lines; extra proposed lines are bounded disclosure/consumer repairs, not the broader geometry/NJL history.

## Scientific propositions and prerequisites

- Cutoff: the bare coupling times the defined `M_c` is `1/(alpha*Lambda)`; emergent coupling times it is `1/Lambda`; the products coincide iff alpha=1. Existing positive alpha/Lambda/N_f supply nonzero denominators. The bare proof unfolds `LinearizedEFE.G_N_sakharov` and `M_c`; the emergent proof unfolds `ADWParams.G_N_emerg_eval`/`LinearizedEFE.G_N_emerg` then consumes the bare identity; equality uses both identities and cancellation. This proves defined algebra, not physical scale selection.
- Schwarzschild local derivative: `HasDerivAt mass dM t`, positive `mass t` and negative `dM` give the quotient/chain-rule derivative `-(8*pi*dM)/(8*pi*mass(t))^2>0`. The exact source uses Mathlib derivative quotient and constant-multiplication rules, not the old order-monotonicity dependency.
- Affine definitions: lambda=`563/(720*pi)*epsilon*kappa^3*c*A0`; `balbinotAffine=T0*(1-lambda*t)`, T0=`c*kappa/(2*pi)`; `balbinotCoolingCoefficient=T0*lambda`. Positive c/kappa/A0/epsilon derive exact affine slope `-T0*lambda<0`. The derivative helper is mathematically true at every t; that fact is not unrestricted physical nozzle validity.
- Additive profile criterion: positive nozzle parameters, supplied `0<eta<1`, an upper-branch trajectory through b.M with actual mass derivative<0, and lower-branch `t>=0`, `c*kappa*t<eta`, `lambda*t<1`. Classifier equivalences select the implications; BHData.M_pos and the mass link supply positivity. Conclusion gives upper derivative positivity, lower domain/temperature positivity and negative affine derivative, and equality iff Boundary. Short-time bounds are supplied, not estimates derived from an error theorem. No derivative sign is assigned at equality.
- Old `H_RegimePartition`, `regime_partition_criterion`, classifier roots, FourLaws structures, all existing proof terms and falsifiers remain. Old transport consumes supplied rate signs; the new criterion supplies separate conditional model derivatives. It is not an API rename and does not prove real ADW branch identification.

The same four direct imports remain: `SKEFTHawking.Basic`, `SKEFTHawking.LinearizedEFE`, `SKEFTHawking.BHEntropyMicroscopic`, `Mathlib`. Actual current toolchain, lakefile and Lake manifest match f905 byte-for-byte (hashes in JSON). Required project definitions/types are present in the current thermodynamics and LinearizedEFE sources. Source inspection identifies no extra-module prerequisite for these nine terms. This is bounded source dependency inspection; LSP/type discovery is incomplete and cannot establish globally missing substrate.

Balbinot primary TeX was read at nozzle area definition, surface-gravity convention, epsilon definition, short-time construction and the complete fate section: A0 is throat area, physical sonic surface gravity is c^2*kappa, epsilon is dimensionless, the source is constant-c Polyakov/Unruh local backreaction, and c*kappa*t<<1 controls the stated approximation. Its late-time tail is explicitly extrapolated and its condensate extension deferred. Existing JV1998 bulk-soliton cooling versus thin-film JK2002/JETP contrast distinctions are preserved. Correct source attribution is not original science closure.

## Existing consumers and Verify reconciliation

Original finding2.2 remains the same ID and severity/lane/gate. Historical Observed/Evidence/Expected/Fix bytes remain. Its proposed Verify now looks up the additive derivative criterion, requires actual value dependencies on both derivative helpers and all three classifier equivalences, rejects projection of supplied H signs, requires derivative/profile/domain/boundary type content, and binds the two metadata interfaces. It no longer requires the mathematically unnecessary `T_H_schwarzschild_strict_decreasing` call. This is a proposal within the existing finding, not a new check/gate. No command was executed. Its source-level predicates do not substitute for independent review of actual extracted full types, formula signs, dependencies, hypotheses, kernel purity and exact source correspondence.

The same review file carries the exact already accepted f905 finding2.3 metadata-correction Verify. That route checks actual standalone positivity and the separate hypothesis-linked delta equivalence; no false claim that the positivity theorem contains delta or H is introduced. No research closure ledger row is copied. Finding2.1 full-law obligation and2.4 existing identity Verify are unchanged. Old source observations stay historical evidence, while the added composition note describes this unaccepted route.

- `papers/L3/paper_draft.tex`: Now cites actual additive profile criterion and emergent cutoff identity; old figure retains exponential/response content. Full-laws slots retain actual conditional scope.
- `papers/L3/bundle_metadata.json`: Original transport root retained and honestly described; additive profile/cutoff apex entries added; old exponential/falsifier consumers corrected. No charter reduction/readiness promotion.
- `papers/AutomatedReviews/2026-08-15-l3-stage10-redraft/L3.md`: Existing 2.2 Verify retargets actual additive proof route; 2.3 follows existing metadata-correction route. Finding2.1 and2.4 deciders remain unchanged; no execution/closure.
- `papers/D3/paper_draft.tex`: Existing §regime_partition explains old criterion as conditional transport. It does not automatically consume/qualify new additive theorem; separate reviewed propagation remains owed.
- `papers/paper27_bh_thermodynamics_four_laws/paper_draft.tex`: Existing lines308/484 old-root references preserved; historical claims do not become profile-derivative or full-laws evidence.
- `src/core/visualizations.py`: Existing fig_T_H_evolution_regime_partition producer cites old root; plots exponential and delta response. Caption matches that actual content; no donor crossing producer/asset transplanted. Existing figure findings remain open.
- `src/core/constants.py`: Existing H_RegimePartition registry entry around4126 incorrectly describes GL entropy current. No new H structure created; preserved old interface avoids a new registry dependency, but existing propagation debt remains ROOT-owned.
- `tests/test_bh_thermodynamics.py`: Existing test_regime_partition_criterion_lean_anchor checks supplied scalar signs; documentation axiom case is not kernel verification. Retained old root preserves this actual scope. No tests executed.
- `tests/test_d5_lean_substrate.py`: Existing old-root apex substance positive fixture unchanged. It is not evidence that new profile signs were elaborated.
- `tests/test_d5_bundles_readiness.py`: Existing REAL old-root fixtures unchanged; no old root or field renamed to satisfy a decider.
- `lean/SKEFTHawking.lean; lean/SKEFTHawking/ExtractDeps.lean; lean/lean_deps.json`: Existing aggregate imports thermodynamics; extractor imports aggregate. Exact-candidate build/extraction is ROOT-owned and remains unexecuted for this proposal.

## Exact per-hunk provenance

`lean/SKEFTHawking/BHThermodynamicsFourLaws.lean`

- `@@ -10,15 +10,16 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -33,13 +34,18 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -123,15 +129,15 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -213,9 +219,9 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -294,9 +300,8 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -308,6 +313,39 @@`: Verbatim three cutoff proofs from f905 / 5d2d829ea; current same-import prerequisites.
- `@@ -367,17 +405,13 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -394,10 +428,8 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -447,8 +479,8 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -509,18 +541,10 @@`: Current-base documentation correction required to distinguish local affine profile, illustrative exponential, supplied-sign transport and original open physical laws; follows prior accepted reconciliation and donor source scopes.
- `@@ -534,6 +558,86 @@`: Verbatim six local-profile declarations from f905 / b1a90e49c; no new proof terms.
- `@@ -845,8 +949,8 @@`: GL local-EFT attribution repair from f905 / 2b73ca539; no physical-current construction.

`papers/AutomatedReviews/2026-08-15-l3-stage10-redraft/L3.md`

- `@@ -133,22 +133,23 @@`: Original finding2.2 identity/evidence preserved with unexecuted semantic Verify reconciliation; adjacent 2.3 Verify verbatim f905 metadata-correction route. No closure receipt.

`papers/L3/bundle_metadata.json`

- `@@ -3,7 +3,7 @@`: Current apex consumer correction by actual theorem types; exponential/falsifier wording and cutoff/profile entries derive from f905. Non-apex metadata untouched.
- `@@ -28,7 +28,7 @@`: Current apex consumer correction by actual theorem types; exponential/falsifier wording and cutoff/profile entries derive from f905. Non-apex metadata untouched.
- `@@ -43,8 +43,18 @@`: Current apex consumer correction by actual theorem types; exponential/falsifier wording and cutoff/profile entries derive from f905. Non-apex metadata untouched.
- `@@ -63,7 +73,7 @@`: Current apex consumer correction by actual theorem types; exponential/falsifier wording and cutoff/profile entries derive from f905. Non-apex metadata untouched.

`papers/L3/paper_draft.tex`

- `@@ -28,15 +28,13 @@`: f905 local-slope and source-scoping propagation: 3ef2dea6c,680c420a7,9405f7552; explicit local criteria/remainder limit added where needed.
- `@@ -49,14 +47,13 @@`: f905 local-slope and source-scoping propagation: 3ef2dea6c,680c420a7,9405f7552; explicit local criteria/remainder limit added where needed.
- `@@ -65,28 +62,25 @@`: Current-base consumer composition: physical branch selection qualified, current figure retained, original physical laws and mass/action/current construction kept open; excluded geometry claims withheld.
- `@@ -103,7 +97,7 @@`: f905 emergent-coupling identity correction /4de686400; actual bare/emergent identities explained.
- `@@ -115,7 +109,11 @@`: f905 cutoff theorem propagation /9405f7552 plus exact bare/emergent distinction.
- `@@ -169,62 +167,60 @@`: f905 local-slope and source-scoping propagation: 3ef2dea6c,680c420a7,9405f7552; explicit local criteria/remainder limit added where needed.
- `@@ -236,12 +232,14 @@`: Current-base consumer composition: physical branch selection qualified, current figure retained, original physical laws and mass/action/current construction kept open; excluded geometry claims withheld.
- `@@ -303,9 +301,8 @@`: f905 scope distinction: background profile cooling does not construct dynamics.

## Withheld donor hunks and original acceptance

- ExactSolutions fixed-G/varying-G first-law and ingoing vacuum/horizon/ADM manuscript paragraphs: Require actual excluded ExactSolutions and ADMFormalism source constructions plus their full qualified import closure. No scope expansion attempted.
- Donor new figure right-panel caption, generated PNG/PDF/source-manifest date/counts and closure ledger: Actual current figure producer and assets are outside the four assigned files. Their donor semantic consumer cannot be transplanted independently.
- Donor figure finding lane/Verify and Python lane edits: Outside the cutoff/profile source composition; actual producer repair is not included.

No scope expansion is requested. In particular the fixed-G differential first law is preserved as existing accepted research, not falsely described as newly present in this candidate; its source and the vacuum/Ricci/ADM/EH tail are not copied. No redispatch of that completed mathematics is proposed.

Original physical first/zeroth/third laws; acoustic energy/entropy/current-divergence balance; ADW action/exterior/mass and physical branch matching; actual cutoff coefficient selection; and quantitative remainder derivative control remain OPEN. For `T=T0*(1-lambda*t)+R(t)`, cooling needs `R'(t)<T0*lambda`; no such bound is established here. The separately preserved analytic metric-path/uniform box/mixed partial/domination/boundary and Euler/renormalized cosmological requirements remain owed. Existing GL current/density results do not automatically identify the physical nozzle flux divergence.

Existing independent source/math review, authoritative exact-candidate build and declaration refresh, original affected meaningful controls and canonical finding writer/readback remain ROOT-owned before any closure. Existing Stage9/10 and subsequent full Stage13 order, original full project/main qualification, venue/reader/render acceptance and final human/publication gates remain. No new threshold, gate, planner, count, source-custody or acceptance result is invented. Metadata readiness/title/source-manifest date/cached stage/census fields remain unchanged; generated PDF/counts/source-manifest are not refreshed and must not be treated as evidence for this proposal.

## Continuity and actual execution

Initial same-packet adapter check returned exit0 `fresh=true, changed=[]`. All four owned preimages match the packet. HEAD remains8ad141152. The existing tracked `lean/lean_deps.json.hash` modification is explicitly packet-bound at SHA256 `ea586c323e81da9ef0aab4f74cde12599e1e14376c9e220441e4b91fb7e9a4cd`; it is ROOT native-profile drift from committed source, not this worker mutation or accepted extraction of proposed proofs. Final same-packet check and exact final readback are appended below and in JSON.

Actual actions were read-only cat/sed/rg/wc, Git show/log/diff/rev-parse/status, stdlib text/hash/JSON/diff composition restricted to the three output artifacts, and the continuity check. No scientific function or proposed Verify ran. No apply/check simulation, patch validator, test suite, LSP/native action or live process inspection ran.


Final same-packet adapter check: exit0, `fresh=true, changed=[]`. Final HEAD is
`8ad1411526b8b8d5b49e9f3b9993b8083ec887d9`; final status is exactly
` M lean/lean_deps.json.hash`. Its SHA256 remains
`ea586c323e81da9ef0aab4f74cde12599e1e14376c9e220441e4b91fb7e9a4cd`.
The patch SHA256 is `a74e87be6589d16d7471f9da319bca46f378f6acdd2b3c3b9a221e03c29b890a`.
All owned repository preimages remain unchanged. A matching packet is only
input correspondence; the native run still owns actual generated-output reconciliation.

ROOT subsequently reported the existing focused PR112 checkout
`.publication-l3-crossing-main` at `a34eb6b08fb85e43f3d5e5071f45db6a8e7ebf57`.
This packet/patch remains bound to8ad and is not rebased or applied there.
ROOT reports its paper already has the cutoff-length panel and its original
finding3.2 has the stronger production data Verify. Application there requires
reconciling its ACTUAL producer/figure/caption and preserving that stronger3.2
Verify. Do not blindly port8ad's response-panel caption, or replace a34's
production control with main's weaker source-token proxy. ROOT must issue the
revised actual-target packet if that focused route is used. This is a ROOT
observation and future integration constraint, not this worker's new-source
qualification or scope expansion.
