from pathlib import Path
import os,sys,subprocess,json,datetime,hashlib
primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
candidate=Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking')
sys.path.insert(0,str(primary/'scripts'))
from lean_slots.state import Inventory,directory_lock
assert Path.cwd()==primary
head=subprocess.check_output(['git','-C',str(candidate),'rev-parse','HEAD'],text=True).strip()
assert head=='d4e4494b88e15892785adac7d687459c71eb04ae'
inv=Inventory.load();assert inv.repo_root.resolve()==primary.resolve()
env=dict(os.environ,UV_PROJECT_ENVIRONMENT=str(primary/'.venv'),UV_NO_SYNC='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1')
prefix=Path('/tmp/l1-hermite-postbuild-refresh-r1')
receipt={'candidate':head,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'scope':'Existing canonical extraction/count/table producers after actual main candidate build; no epoch/runtime/slot transition'}
with directory_lock(inv.state_root/'locks/authoritative-build.lock',purpose='ROOT exact L1 post-build declaration and document refresh'):
 code="import sys;sys.path.insert(0,'scripts');import extract_lean_deps as e;e._run_extraction();d=e.load_lean_deps();names=['integrable_polynomial_gaussianReal', 'realHermite', 'eval_realHermite', 'realHermite_succ', 'integral_realHermite_succ_mul', 'integral_realHermite_mul', 'integral_hermite_mul', 'integrable_hermite_mul', 'integral_hermite_mul_pow', 'integral_hermite_mul_eq_zero', 'integral_hermite_mul_eq_factorial_coeff', 'integral_hermite_mul_pow_eq_zero', 'integral_hermite_mul_pow_self', 'natDegree_realHermite', 'integral_hermite_mul_hermite_of_ne', 'integral_hermite_mul_hermite_self'];r={x['name']:x for x in d};sel=[r['SKEFTHawking.ADW.'+n] for n in names];assert all(set(x['axiom_deps_core'])=={'propext','Classical.choice','Quot.sound'} and not x['axiom_deps_project'] for x in sel);import json;print(json.dumps({'records':len(d),'source_hash':e.compute_lean_hash(),'new_declarations':sel}))"
 commands=[('extraction',['/Users/johnroehm/.local/bin/uv','run','python','-B','-c',code]),('counts',['/Users/johnroehm/.local/bin/uv','run','python','scripts/update_counts.py']),('tables',['/Users/johnroehm/.local/bin/uv','run','python','scripts/render_paper_tables.py'])]
 for name,argv in commands:
  with Path(str(prefix)+'.'+name+'.stdout').open('w') as out,Path(str(prefix)+'.'+name+'.stderr').open('w') as err:r=subprocess.run(argv,cwd=candidate,env=env,stdout=out,stderr=err)
  receipt['steps'].append({'name':name,'returncode':r.returncode,'argv':argv})
  prefix.with_suffix('.progress.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print(name+' returncode='+str(r.returncode),flush=True)
  if r.returncode:break
 receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 receipt['status']=subprocess.check_output(['git','-C',str(candidate),'status','--porcelain'],text=True)
 prefix.with_suffix('.result.json').write_text(json.dumps(receipt,indent=2)+'\n')
sys.exit(receipt['steps'][-1]['returncode'])
