from pathlib import Path
import sys,json,hashlib,contextlib,io,copy
sys.path.insert(0,str(Path.cwd()/'scripts'));import back_fill_primary_sources as b
keys=['Barcelo2011','FinazziLiberatiSindoni2012','Kitaev2006','Wang2026TMDPolariton','Verlinde1988']
state=Path('docs/primary_sources_state.json');before=json.loads(state.read_text());Path('/tmp/l1-citation-state-before-r1.json').write_bytes(state.read_bytes())
entries={x.bibkey:x for x in b.load_entries(include_stubs=False)}
def pin(p):
 st=p.stat();return {'path':str(p),'resolved_path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':st.st_size,'mode':st.st_mode,'mtime_ns':st.st_mtime_ns}
held={}
for k in keys:
 tier,p=b.find_on_disk(entries[k]);assert p is not None and p.is_file() and p.stat().st_size>0;held[k]=pin(p)
def deny(event,args):
 if event in ['socket.connect','socket.getaddrinfo']:raise RuntimeError('Network refused in existing-file registration')
sys.addaudithook(deny)
results=[]
for k in keys:
 out=io.StringIO()
 with contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):rc=b.main(['--fetch','--bibkey',k,'--no-stubs','--sleep','0'])
 results.append({'bibkey':k,'command':['back_fill_primary_sources.main','--fetch','--bibkey',k,'--no-stubs','--sleep','0'],'exit_code':rc,'output':out.getvalue()});assert rc==0
for k in keys:
 tier,p=b.find_on_disk(entries[k]);assert pin(p)==held[k],k
actual=json.loads(state.read_text());old=before['entries'];new=actual['entries']
for k,v in old.items():assert new[k]==v,k
assert set(new)-set(old)<=set(keys)
for k in keys:
 assert new[k]['url_used'] is None and new[k]['note']=='pre-existing on disk; recorded without re-fetch',k
receipt={'steps':results,'held_before_after_exact':held,'all_old_records_preserved':True,'old_records':len(old),'new_records':len(new),'new_keys':sorted(set(new)-set(old)),'no_network':True,'no_downloads':True,'state_sha256':hashlib.sha256(state.read_bytes()).hexdigest(),'scope':'Existing held-file registration only; no content fidelity or physical science acceptance'}
Path('/tmp/l1-citation-existing-registrations-r1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['steps','held_before_after_exact']},indent=2))
