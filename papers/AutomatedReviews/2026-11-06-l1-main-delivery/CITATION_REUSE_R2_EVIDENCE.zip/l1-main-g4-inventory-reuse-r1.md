# Accepted G4 and inventory source reuse for L1 main

**Reuse is coherent without reimplementation.** Every existing path changed by implementation1550f5ff11ab6c350081abf607d4431e28e02ef1 is still an exact preimage in current main; four donor plan/spec paths are absent. The frozen citation changes touch none of those paths. Adopt the reviewed source/tests/owner/spec package, preserve current scientific files, and regenerate derivatives only through the existing authorized route. No current gate pass follows from this report.

## Binding and checks actually performed

First action was existing continuity checker on primary `.codex/continuity/l1-main-g4-inventory-reuse-r1.json`: fresh=true, changed=[]. Observed HEAD3b2ef9dbc52e20042cafbeaf662129078b98c04f plus nine frozen citation paths. Subsequent and final report-generation checks also returned fresh=true, changed=[]. JSON captures final HEAD/status and every donor path/pre/post/current SHA256.

Read primary notebook/roadmap context and assigned derivative/affected receipts, prior source/control evidence, exact Git ancestry and actual source bodies. Commands were read-only continuity checks, Git show/diff/log/status/rev-parse/merge-base/ls-tree, filesystem metadata/text searches and stdlib AST/hash comparison. No tests, imports of project modules, update_counts (including --help), production generator, graph/native/Lean/build/cache/slot action, network, notebook or repository/Git mutation occurred. Outputs are only this report and its companion JSON. Source observations and existing receipts below are not fresh runtime qualification.

1550 is a direct child of ce194cdc4bf939b108c17edc9530a7f0a14565f9. dcb9a2c5abe80bf64ab387e649975b4d9359b538 is the evidence/closure child of1550. Neither is an ancestor of current HEAD; common merge-base isce194. No cumulative publication branch merge is needed for these source changes.

## Minimal coherent package

Take1550's **21 source/test/owner/spec paths**, listed exactly in JSON under minimal_package.adopt_immutable_source_tests_owners_specs:

- Four existing scripts: scripts/build_graph.py, scripts/readiness_gates.py, scripts/validation/checks/bundles_readiness.py, scripts/architecture_inventory.py.
- Eight original test files: test_build_graph, test_readiness_gate_evaluators, test_readiness_submission_gate, test_readiness_gate_measured, test_readiness_cannot_measure, test_architecture_inventory, test_architecture_claims, test_d5_mutation_obligation.
- Five owner documents: docs/READINESS_GATES.md, ADR009, END_TO_END_MAP.md, QA_QI_INFRASTRUCTURE_MAP.md, VALIDATION_GATE_TOPOLOGY.md.
- Both original G4/inventory plans and both original design specifications under docs/superpowers/.

All17 already-existing paths above match exact donor preimages, and four plans/specs are absent. Thus donor postimages can be reused intact for these21 paths, subject to ROOT's independent current composition review. No path-level conflict or implementation dependency on the citation delta is observed. This package adds no new gate/check/classifier, alternate scanner, runner or writer. Documentation and runtime assertions must travel together.

Do **not** copy donor docs/counts.json, docs/counts.tex or SURFACE_INVENTORY.md merely because their current preimages happen to match. The current source/registry and collected-test population have changed. Do not adopt dcb's supersession ledger. Its three public evidence files may accompany the source as explicitly historical evidence; they do not establish fresh canonical Verify or main closure. No science-source restoration is part of1550.

The reviewed source has two coherent components, which may be reviewed separately but should not be partially assembled within each:

1. Formula structural population → typed declared G4 evaluator → serialization/log wording → existing submission reader → owning docs and original controls.
2. Anchored Git hook metadata observation → collect/render → existing inventory writer/comparator → schema ownership docs and original controls.

A hook-only hand patch or inventory-only count adjustment discards the accepted coherent mechanism. A Formula-only repair leaves the absent/wrong-type and false all-P1 messages unresolved.

## Exact existing behavior recovered

**Formula producer:** module-body AST enumerates public FunctionDef/AsyncFunctionDef names in source order, case-sensitive, with metadata anchored at definition lines rather than decorators. Private/nested/method/import/string lookalikes stay excluded. Parse/duplicate/read failures are diagnosed, never silently empty. Original metadata-window and test-reference heuristics remain limited static evidence.

**G4 evaluator:** retains union of PAPER_DEPENDENCIES metadata and claim grounding. Every declared target partitions into supported, insufficient kind, no valid PythonTest, absent Formula, or wrong node type. Golden/identity/roundtrip support requires a real PythonTest source node. Absent/wrong-type yields BLOCKED/unmeasured while retaining partial resolved-member evidence. Undeclared population is OPEN/unmeasured. Complete negative typed coverage is BLOCKED/measured; complete supported static coverage is PASSED/measured. This does not execute tests or establish scientific validity.

**Submission consumer:** preserves aggregate classification policy (literal BLOCKED at either priority red; outstanding nonblocked states yellow/advisory; human submission requires GREEN). Removes the false “all P1 passed” label for an OPEN P1 result and surfaces serialized G4 state/measured/evidence/blocker totals/truncation even under unrelated aggregate RED. Build-graph log changes “read nothing” to incomplete measurement with possible partial evidence. Stronger architecture runtime assertion must be retained; current main has its exact weaker donor preimage, so1550's complete replacement is appropriate here.

**Hook inventory:** resolves checkout .git through Git metadata, compares independent admin anchor with actual top/gitdir/common-dir, retains ordinary config/hooksPath precedence and refuses foreign inherited repository context. Catalog collects regular nonsample file metadata, never hook bodies, and exposes logical git-path locators plus absent/non-directory/read-failure distinctions. Listing/stat/race/query/encoding/ambiguous-answer errors cannot masquerade as an empty catalog. No runtime hook activation is claimed.

Read-only metadata observation here found a regular nonsample pre-commit hook through Git's common hook directory. The supplied candidate inventory has six plugin rows and omits it.1550's generator repair addresses that source defect; its END_TO_END_MAP edit also removes the stale temporary/working-docs/sentence_kg_schema_delta.md authority link seen in prior qualification. Promote neither the current six-hook candidate nor a hand-entered seven count. Correct collector source first, then use the existing writer and inspect actual output. The supplied derivative-limits receipt correctly withholds inventory/counts/native acceptance.

## Current L1 scientific preimages must survive

1550 changes neither src/core/formulas.py nor src/core/provenance.py. Preserve both current files, including current L1 seven-formula roster, twenty-parameter roster, exact interval/width and assumption-qualified source scope. Preserve current frozen citation identities/constants/state/bibliographies too.

Static independent source AST here finds436 public Formula identities versus410 under the old lowercase regex, with the same identities/order as the donor scientific source. Current four changed function ASTs are c_GW_from_chi_vest, c_GW_deviation_from_c, dispersion_correction_from_GammaH and c_GW_natural_range. Two remain changed even after removing docstrings. Therefore never substitute donor formulas or treat previous complete Formula dictionaries as current bodies.

Current PAPER_DEPENDENCIES has18 rows; original donor inventory reflected17. Current L1 declares:

c_GW_from_chi_vest, c_GW_deviation_from_c, dispersion_correction_from_GammaH, ligo_constraint_check, c_GW_natural_range, G_N_emergent, G_N_sakharov.

All seven exist in actual source AST; old producer omits six (all except ligo_constraint_check). Structural reuse fixes emission, while actual typed edges and resulting G4 must be measured on current source. The original donor/integration L1 OPEN/unmeasured0-roster observation is obsolete for this eighteen-row candidate. Earlier publication seven-formula PASSED is also another-source evidence, not this main gate result. Do not change roster/functions/science to match historical totals or force green.

## Original acceptance evidence and its limits

Atdcb, retain papers/AutomatedReviews/2026-10-20-g4-population-and-inventory/{SCOPED_REVIEW.md,CONTROL_EVIDENCE.json,infra.md}. They attribute genuinely nonauthor whole source/canonical/control acceptance to review SHA256b3185c2099fc2643707ae6f0c9d7e1e3b615af767a15da2c161d3cd93439b213. Public SCOPED_REVIEW and infra are lead reconciliations, not themselves fresh independent reviews. CONTROL_EVIDENCE explicitly hashes captured UTF-8 TEXT channel fields, not original OS pipe bytes; preserve that distinction.

Original evidence covers five production controls: actual case-exclusion regression, canonical definition private rename with retained declaration, real missing provenance dependency, old physical-.git-hooks regression, canonical known-row deletion. Each baseline0/seeded1/exact-restore0, with bytes/full mode/nsmtime restored, journal empty; no ctime restoration claim. G4 targeted result and consumer measurement flip is the discriminator; aggregate readiness remains red in both phases. Original source population preserves410 complete old Formula dictionaries and recovers26; this is historical corpus evidence.

The dcb ledger records four original enforced exit0 Verify commands anchored to1550. Existing /tmp/l1-g4-integration-verification.json repeats actual prior integration scoped outcomes7+23+25+57=112passes; its four original stdout/err artifacts remain available. /tmp/l1-g4-integration-review-paths.json shows25/28 exact donor paths, with historical counts and ledger union exceptions. /tmp/l1-g4-integration-review-evidence.json retains the original receipt hash1c2443beba455561376dedc9a308deeaf66dc1a607910e77bf93aed365dce465; its counts/ledger values belong to that earlier integration. Primary notebook attributes independent whole integration review SHA256ce9473cc6ea22689f99e1df6ecf8b393f3201bf7526d3b574965a09a9d1e0751 and mergef2fca05a. I read those receipts; no tests or fresh review was executed here. Historical112 passes,57 inventory cases,436/410 nodes and prior64-paper distributions cannot stand in for current qualification.

## Required proper next checks and delivery

ROOT can now adopt the21 exact source/control/owner/spec postimages, conserving all frozen citation and current L1 scientific files, retain historical dcb evidence with correct provenance, and request independent current composition review. No architecture redesign is indicated.

Subsequent authorized qualification should preserve original commands and assertions:

- uv run python -m pytest -q tests/test_build_graph.py::TestStructuralFormulaPopulation
- uv run python -m pytest -q tests/test_readiness_gate_evaluators.py::TestG4DeclaredTypedCoverage
- uv run python -m pytest -q tests/test_readiness_submission_gate.py
- uv run python -m pytest -q tests/test_architecture_inventory.py

Also run appropriate complete affected tests (including serialization/log/cannot-measure/architecture/mutation obligations) and actual current source-bound graph/typed-declared coverage comparison in the prepared authorized environment. Preserve all current Formula dictionaries and explain newly visible nodes/edges/gates; audit current L1 seven identities and real serialized measurement without claiming execution/physics. Recheck source-bound native/extraction custody before any graph-triggering call; none was authorized here.

For inventory, independent source review precedes corrected canonical baseline generation. Existing writer must derive current hook metadata plus677 citation identities and18 dependency records, and current unrelated families. Inspect every delta; only then serialize original source-regression and canonical-row-deletion controls against that baseline with exact restore and no writer under seeds, per accepted plan. Donor row totals are not current requirements. Existing count writer has native effects: do not run even --help in this read-only lane; ROOT owns its prepared authorized full delivery use. Current counts remain unaccepted until then.

Do not transplant closure ledger, counts, stage/human/publication decisions or runtime receipts as new results. ROOT's existing canonical writer owns any genuinely current finding disposition. Existing D12 public-function zero-reference, microscopic physical B3, source-body/edition and transport obligations remain open. Required broader main pipeline, native/full/scientific/render/independent and final human/publication acceptance are not satisfied by this source-reuse report.
