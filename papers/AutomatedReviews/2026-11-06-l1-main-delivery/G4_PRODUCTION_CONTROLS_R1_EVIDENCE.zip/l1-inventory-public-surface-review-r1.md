# Independent off-tree public-surface guard completion review — r1

**PASS — exact one-line completion of an existing registration obligation.** No blocking finding or correction. Acceptance is for the reviewed off-tree candidate only; application and postchecks remain ROOT-owned.

Frozen HEAD: `9c2b00f59af77ac0516a31cddefa20f27409627c`.
Current preimage SHA256: `5a38ddb87015534b9dea7638614138765f8d987a9d17d7f3d1929518ffe3e080`.
Candidate SHA256: `e96852a18276697e45d3239126966e2e63b34d8b8ad53a3348d6eda958fe3d95`.

## Existing obligation and exact repair

`tests/test_architecture_inventory.py:127` returns `validate.check_architecture_inventory_fresh` from the existing fixture. `scripts/validate.py:765` already re-exports that actual check from its freshness module. ADR-009 D2 item 8 and the existing public-surface test contract require by-name consumers to retain a reachable, callable validate export in the independently maintained EXPECTED_SURFACE guard.

The existing registration_sites source makes EXPECTED_CHECK_FUNCTIONS conditional on an actual by-name validate consumer. This consumer exists; membership is therefore owed rather than an optional coupling. The supplied current before evidence records exit 1 with exactly this mandatory site owed. Its separately reported optional sync edge does not count toward that failure; the inventory comparator does not write its artifact. No new registered check is added, so no CI check-count floor or fixture-only ceiling adjustment follows.

The complete candidate differs from the frozen current file by exactly:

```diff
 EXPECTED_CHECK_FUNCTIONS = [
+    "check_architecture_inventory_fresh",
```

This exact insertion is independently present in the historical diff of `df42dc907c78b209ff716faae781888662f0c1f3`. The candidate applies that line to the current full file; it is not a transplant of the historical full postimage, which differs elsewhere. The candidate parses. Removing only the added list element makes the entire file AST equal to current source; byte comparison confirms the single exact textual insertion and preservation of every other byte.

This adds the name to the existing EXPECTED_SURFACE parametrization and existing callable check. It completes a missing regression guard for an export already in use. It does not alter production behavior, inventory generation, the freshness reader, registrations, controller/native behavior, scientific source, a ledger, or architecture design.

## Required ROOT follow-through and limits

Apply only this exact postimage after confirming the matching current preimage, run the existing public-surface module under the approved source-bound runtime, then run existing registration discovery and preserve its actual output. Expected required-site satisfaction is a source inference here, not a post-application result: the reviewer did not apply or execute the candidate, tests or discovery tool.

This review neither refreshes broader inventory/control acceptance nor accepts G4/native/fullgraph/scientific, delivery or closure work. No source or runtime repair beyond this existing guard membership is requested.

## Final continuity

The initial/final packet SHA256 remains `caaa690c9cb3d57fb69506f98c1b72938114fceb966dfd194def4e336d952d21`. HEAD, index semantics, clean NUL-delimited status, owned preimage, candidate, before evidence, all authority references, roadmap and the lead-owned notebook match the new packet. No repository/notebook/Git writes, tests, seeds, native or project runtime operations occurred. Only the two assigned `/tmp` reports were written.
