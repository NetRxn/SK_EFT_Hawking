from pathlib import Path
import sys,subprocess,json,tempfile,os,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from seed_journal import seeded_mutation,outstanding
p=root/'tests/test_validate_public_surface.py';before=p.read_bytes();s=p.stat();snapshot=(hashlib.sha256(before).hexdigest(),s.st_mode,s.st_mtime_ns)
assert not outstanding(include_live=True)
old=subprocess.check_output(['git','show','HEAD:tests/test_validate_public_surface.py']);assert before.replace(b'    "check_architecture_inventory_fresh",\n',b'',1)==old
nodes=['tests/test_validate_public_surface.py::TestNumericalLiteralPopulationComposition::test_ceiling_matches_the_live_population','tests/test_validate_public_surface.py::TestTexQuoteReferencesAreExtracted::test_d7_no_longer_cites_a_nonexistent_theorem']
with seeded_mutation(p,old,reason='Exact preimage reproduction of two public-surface failures; no acceptance inferred'):
 with tempfile.TemporaryDirectory(prefix='l1-preimage-bytecode-') as cache:
  a=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',*nodes,'--junitxml=/tmp/l1-public-surface-preimage-replay-r1.xml']
  q=subprocess.run(a,cwd=root,env=dict(os.environ,PYTHONPYCACHEPREFIX=cache,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True,timeout=90)
  report={'argv':a,'rc':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'preimage_sha256':hashlib.sha256(old).hexdigest()}
  assert q.returncode==1
st=p.stat();assert (hashlib.sha256(p.read_bytes()).hexdigest(),st.st_mode,st.st_mtime_ns)==snapshot
assert not outstanding(include_live=True)
report['exact_restore']=True;Path('/tmp/l1-public-surface-preimage-replay-r1.json').write_text(json.dumps(report,indent=2)+'\n');print(q.stdout)
