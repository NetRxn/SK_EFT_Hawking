from pathlib import Path
import sys,os,json,hashlib,subprocess,tempfile,datetime,base64
root=Path.cwd().resolve();sys.path.insert(0,str(root/'scripts'))
from seed_journal import seeded_mutation,outstanding
assert not outstanding(include_live=True)
probe=Path('/tmp/l1-g4-current-source-probe.py')
child='''import runpy,sys,json
runpy.run_path('/tmp/l1-g4-current-source-probe.py',run_name='__main__')
r=json.load(open('/tmp/l1-g4-production-'+sys.argv[1]+'.json'))
l1=r['g4_rows']['paper:L1']['meta']
assert not r['missing_public_ids'], 'public AST definitions omitted from actual Formula producer'
assert l1['state']=='passed' and l1['measured'] is True, 'L1 declared static computation coverage is not complete and supported'
'''
report={'root':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Actual production G4 input extractors, evaluator and GateResult serialization over its input types only; NOT full graph/native/DB/submission consumer/numerical certification','probe_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'runs':[],'controls':[]}
out=Path('/tmp/l1-g4-current-controls-r1.json')
def snap(p):
 s=p.stat();return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':s.st_mode,'mtime_ns':s.st_mtime_ns}
def run(label):
 with tempfile.TemporaryDirectory(prefix='l1-g4-empty-bytecode-') as cache:
  env=dict(os.environ,PYTHONPYCACHEPREFIX=cache,PYTHONDONTWRITEBYTECODE='1')
  argv=[sys.executable,'-B','-c',child,label]
  t=datetime.datetime.now(datetime.timezone.utc).isoformat()
  p=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=90)
  data=json.load(open('/tmp/l1-g4-production-'+label+'.json'))
  row={'label':label,'time_utc':t,'argv':argv,'rc':p.returncode,'stdout_base64':base64.b64encode(p.stdout).decode(),'stderr_base64':base64.b64encode(p.stderr).decode(),'stdout_text':p.stdout.decode(),'stderr_text':p.stderr.decode(),'fresh_empty_bytecode_context':True,'environment_overrides':{'PYTHONPYCACHEPREFIX':cache,'PYTHONDONTWRITEBYTECODE':'1'},'projection_sha256':hashlib.sha256(Path('/tmp/l1-g4-production-'+label+'.json').read_bytes()).hexdigest(),'l1_serialized_payload':data['g4_rows']['paper:L1'],'omitted_public_ids':data['missing_public_ids'],'source_hashes':data['source_hashes']}
  report['runs'].append(row);print(label,p.returncode,data['g4_rows']['paper:L1']['meta']['state'],flush=True)
  return p.returncode,data

def once(s,old,new):
 assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
def provenance_missing(s):
 start=s.index("    'L1': {");tail=s[start:]
 return s[:start]+once(tail,"'formulas': ['c_GW_from_chi_vest',","'formulas': ['nonexistent_g4_control_target_20261106', 'c_GW_from_chi_vest',")
try:
 rc,r=run('controls_baseline');assert rc==0
 configs=[('producer_case_exclusion',root/'scripts/build_graph.py',lambda s:once(s,"if node.name.startswith('_'):","if node.name.startswith('_') or not node.name.islower():"),'formula:c_GW_from_chi_vest'),('retained_declaration_private_definition',root/'src/core/formulas.py',lambda s:once(s,'def G_N_emergent(','def _G_N_emergent('),'formula:G_N_emergent'),('absent_dependency_target',root/'src/core/provenance.py',provenance_missing,'formula:nonexistent_g4_control_target_20261106')]
 for name,path,mutator,target in configs:
  before=snap(path)
  with seeded_mutation(path,mutator,reason='Existing G4 declared-population actual source control: '+name):
   seeded=snap(path)
   rc,r=run(name+'_seeded');assert rc==1
   meta=r['g4_rows']['paper:L1']['meta'];assert meta['state']=='blocked' and meta['measured'] is False
   assert any(target in x and 'absent' in x for x in meta['blockers']),meta
  after=snap(path);assert before==after
  rc,r=run(name+'_restored');assert rc==0
  assert not outstanding(include_live=True)
  report['controls'].append({'name':name,'path':str(path),'before':before,'seeded':seeded,'after':after,'target':target,'exact_bytes_fullmode_nsmtime_restored':True})
 report['sequence']=[x['rc'] for x in report['runs']];assert report['sequence']==[0,1,0,1,0,1,0]
 report['journal_empty']=not outstanding(include_live=True)
finally:
 out.write_text(json.dumps(report,indent=2)+'\n')
