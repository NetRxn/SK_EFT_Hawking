# Independent prospective canonical catalog review R2

**ACCEPT the exact off-tree candidate for ROOT application through the existing writer process.** Candidate SHA256 `7a4ac6ec9485bce91d0d093e469eb9b9611c2422743926eef544327e8e931b62`; prior canonical SHA256 `3b2ba1c1baeb036c45034bb58d42d666badbaace860e56415829400a1ca307cc`. No candidate correction required. This review does not accept actual application, F bindings, full154-unit scientific backing or human/publication closure.

## Every changed unit

| Existing review_unit | Current lines | Prior hash → successor hash | Retained verdict | Scalar |
|---|---|---|---|---|
|25|105–106|ec137388 → a0363bf2|WARN|gw_relative_width|
|60|211–212|78102830 → c8300997|PASS|gw_compatible_width|
|65|225–230|f0508a9e → 6b51f402|PASS|gw_lower_ratio_detailed|
|66|232–237|98b3a2d2 → d9d70037|PASS|gw_upper_ratio_detailed|
|75|271–273|928d4e3e → 725fe8ec|WARN|gw_compatible_width|

These are existing meta.review_unit values, not one-based array positions. I independently checked each entire quote against current manuscript source with only the established label-command whitespace mask. All positions match, including mid-line starts/ends. Both theorem labels are replaced by equivalent whitespace, not silently removed substantive text. Every new quote uses the actual source's single-backslash LaTeX commands. The current normalized quotes follow actual sentence_state normalization for these strings (lowercase and whitespace collapse; none needs additional command/punctuation stripping), and independently computed SHA256 first8 values equal the IDs/raw parts. Sections and paper components remain correct. Each rewrite_of equals its exact prior ID, matching focused old_to_new_lineage and the nested source_binding prior_id. No old ID remains in active blocker/followup/cross-bundle/reproducing references; historical occurrences remain historical.

The candidate changes only quote, quote_normalized, ID, raw_id_parts quote hash, rewrite_of and one added source_binding_r1 metadata member for each of the five records. Every other field and every preexisting metadata member is deep exact: verdict, notes, deltas, assessment origin, reviewer dates/runs, backing chains, gates, prior histories, segmentation provenance, source hash, destination and tombstone. No fresh scientific assessment is falsely assigned to those successor IDs. The added member explicitly says source binding only and binds current manuscript hash. The two extra uncounted theorem ratios are approximate arithmetic evaluations rather than exact Lean statement constants, consistent with D3; no exact/adopted scientific constants change.

## Full conservation

I compared all154 records in order:149 are fully deep exact. All154 prior scientific assessments are preserved. The focused evidence archives all154 complete old records exactly, with all old top metadata exactly (all top fields except sentences/evidence are archived). Every preexisting review_evidence member is deep exact. Existing top reviewer identity/date/run, summary and other top fields are unchanged. The old summary's152-retained/2-fresh wording describes the previous historical pass; focused evidence explicitly states this operation is149 unchanged plus5 source rebindings with all154 assessments retained.

All four blocker objects/statuses remain deep exact OPEN. Seven candidate_for_supersession human decisions remain deep exact pending; no automatic closure is added. Current prose_state and audit_log hashes equal both packet and focused preimages. Human approval is not transferred through source ID changes. No wholesale legacy escaping normalization is attempted: untouched149 records remain exact, including historical double-backslash JSON values.

## Current bindings, schema and scope

I independently rehashed all4 source files,9 actual scalar outputs,4 producer inputs,2 manifests and2 human/audit preimages referenced in focused evidence; all match. Every stored scalar output payload matches the actual file's final line after its trailing percent is accounted for. Those inputs/outputs and current manuscript agree with the earlier independently accepted R2 composition. The optional short caption title is outside existing unit payloads, so units73/74 remain unchanged; unit75 alone updates its visible width source binding while preserving WARN. Existing10-page render evidence is correctly attributed rather than claimed as rerun by the catalog author.

At top level only sentences, review_scope and review_evidence differ. review_scope updates manuscript_sha256, coverage, acceptance and prior_catalog_sha256 and adds the narrow evidence pointer. Old review_scope.head, meta.source_sha256 and earlier review_evidence.source_hashes remain historical provenance, with explicit focused current binding and an explanation that old identity/head is historical. This avoids turning a source refresh into an invented full review. No later source or physical acceptance is implied.

I inspected actual scripts/sentence_state.py normalization, ID and schema contracts. All changed schema-bearing fields use existing shapes; assessment/type/enum/link fields are unchanged, IDs are unique and well formed, and raw hash/section bindings check independently. The author's actual existing helper/schema invocation reports0 errors. This reviewer did not execute project helper/schema code, consistent with the read-only assignment; no alternative normalizer, schema or persistent validator was introduced.

## Application boundary and continuity

ROOT must apply these exact bytes via the existing canonical schema/dry-run/ingest process and obtain actual application readback preserving source pins, human state and append-only audit prefix. F_SOURCE_REVIEW pins L1 source/catalog and Paper25 source and needs independent dependency-semantic rebinding plus its existing declared Verify after catalog application. Neither gate is accepted here. Original physical BUILD, all four blockers, seven pending human decisions, aggregateG11/global139>117/main/native/full project and publication acceptance remain open.

Executed only first/final prescribed continuity checks, read-only source/catalog/helper inspection and standard-library JSON/hash/source conservation analysis. Only the two assigned /tmp review reports were written. No project imports, tests, renderer, seed, compile, ingest, Git/native/controller, source or notebook mutation. Final same-packet check: fresh=true, changed=[]; snapshot freshness itself is not completion authority.
