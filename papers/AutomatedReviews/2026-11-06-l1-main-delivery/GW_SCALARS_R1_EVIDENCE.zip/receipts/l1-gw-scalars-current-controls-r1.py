from pathlib import Path
import sys,subprocess,os,tempfile,json,hashlib,base64
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from seed_journal import seeded_mutation,outstanding
assert not outstanding(include_live=True)
child='''from pathlib import Path
import sys,json,hashlib
root=Path.cwd().resolve();sys.path[:0]=[str(root),str(root/'scripts')]
def deny(event,args):
 if event in ('subprocess.Popen','socket.connect','socket.getaddrinfo'):raise RuntimeError('Scalar content-control child forbids native/network')
sys.addaudithook(deny)
import render_paper_tables as r
import src.core.constants as c
import src.gravitational_waves.ligo_constraint_check as g
origins={x.__name__:str(Path(x.__file__).resolve()) for x in [r,c,g]}
assert all(Path(x).is_relative_to(root) for x in origins.values())
rows=[]
for paper in ['L1','paper25_gravitational_waves']:
 spec=root/'papers'/paper/'tables.py';data=r._load_spec(spec)
 assert data and not data['tables']
 for key,value in data['scalars'].items():
  p=spec.parent/'tables'/(key+'.tex');expected=r._render_scalar(value);actual=p.read_text()
  rows.append({'paper':paper,'id':key,'matches_actual_renderer':actual==expected,'actual':actual,'fresh_expected':expected,'output_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert len(rows)==9
print(json.dumps({'scope':'Actual existing renderer and production scalar-file content equality; NOT global tables_fresh or independent physics correctness','origins':origins,'rows':rows,'cap':c.GW_PARAMS['C_GW_TWO_SIDED_CAP']},sort_keys=True))
sys.exit(0 if all(x['matches_actual_renderer'] for x in rows) else 1)
'''
r={'scope':'Source-scoped existing renderer/output binding only, no new persistent check or global gate claim','runs':[],'restorations':[]}
def snap(p):
 s=p.stat();return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':s.st_mode,'mtime_ns':s.st_mtime_ns}
def run(label):
 with tempfile.TemporaryDirectory(prefix='gw-scalars-empty-bytecode-') as cache:
  a=[sys.executable,'-B','-c',child];p=subprocess.run(a,env=dict(os.environ,PYTHONPYCACHEPREFIX=cache,PYTHONDONTWRITEBYTECODE='1'),cwd=root,capture_output=True,timeout=60)
  data=json.loads(p.stdout);r['runs'].append({'label':label,'argv':a,'rc':p.returncode,'stdout_base64':base64.b64encode(p.stdout).decode(),'stderr_base64':base64.b64encode(p.stderr).decode(),'result':data});print(label,p.returncode,flush=True);return p.returncode,data
try:
 rc,d=run('baseline');assert rc==0
 jobs=[('canonical_cap_changes_values',root/'src/core/constants.py',"'C_GW_TWO_SIDED_CAP': 3.0e-15,","'C_GW_TWO_SIDED_CAP': 6.0e-15,"),('actual_width_output_corrupt',root/'papers/L1/tables/gw_compatible_width.tex',r'1.2\times10^{-14}%',r'9.9\times10^{-14}%')]
 for name,p,a,b in jobs:
  before=snap(p)
  def mutate(t):
   assert t.count(a)==1;return t.replace(a,b)
  with seeded_mutation(p,mutate,reason='Current GW scalar producer/artifact binding control '+name):
   seeded=snap(p);rc,d=run(name);assert rc==1
   bad=[(x['paper'],x['id']) for x in d['rows'] if not x['matches_actual_renderer']]
   assert len(bad)==(9 if name=='canonical_cap_changes_values' else 1),bad
  after=snap(p);assert after==before;assert run(name+'_restored')[0]==0;assert not outstanding(include_live=True)
  r['restorations'].append({'path':str(p),'before':before,'seeded':seeded,'after':after})
 r['journal_empty']=not outstanding(include_live=True)
finally:
 Path('/tmp/l1-gw-scalars-current-controls-r1.json').write_text(json.dumps(r,indent=2)+'\n')
