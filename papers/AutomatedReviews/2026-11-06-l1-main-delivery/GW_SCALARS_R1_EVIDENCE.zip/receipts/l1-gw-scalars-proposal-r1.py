from pathlib import Path
import re,json,hashlib
root=Path.cwd();dest=Path('/tmp/l1-gw-scalars-proposal-r1');dest.mkdir(exist_ok=True)
common='''from __future__ import annotations

from src.core.constants import GW_PARAMS
from src.gravitational_waves.ligo_constraint_check import ligo_compatibility_check


def _sci(value: float, places: int) -> str:
    mantissa, exponent = f'{value:.{places}e}'.split('e')
    return f'{mantissa}\\\\times10^{{{int(exponent)}}}%'


def _width() -> float:
    # Stable preimage width; do not subtract rounded endpoints near unity.
    cap = GW_PARAMS['C_GW_TWO_SIDED_CAP']
    return 4.0 * cap if cap <= 1.0 else (1.0 + cap) ** 2


def _ratio(key: str) -> float:
    return ligo_compatibility_check(GW_PARAMS[key]).violation_factor


'''
common = common.replace(chr(92)*4 + 'times', chr(92)*2 + 'times')
l1='''"""Derived numerals for L1's conditional GW170817 comparison.

SCALARS uses the existing paper-table renderer. Inputs remain the adopted
GW_PARAMS cap and comparison endpoints, not microscopic measurements.
The exact width identity is GravitationalWaves.ligo_window_width_eq; the
formatted values are rounded evaluations, not new physical derivations.
"""

'''+common+'''SCALARS = {
    'gw_compatible_width': {
        'description': 'Conditional nonnegative susceptibility preimage width at the adopted GW_PARAMS cap; formatted to two significant figures.',
        'value': lambda: _sci(_width(), 1),
    },
    'gw_relative_width': {
        'description': 'Conditional compatible width divided by the adopted comparison interval width, without a probability interpretation.',
        'value': lambda: _sci(_width() / (GW_PARAMS['CHI_VEST_NATURAL_UPPER'] - GW_PARAMS['CHI_VEST_NATURAL_LOWER']), 1),
    },
    'gw_lower_ratio_detailed': {
        'description': 'Absolute assumed-law speed deviation at the adopted lower endpoint divided by the adopted cap, three significant figures.',
        'value': lambda: _sci(_ratio('CHI_VEST_NATURAL_LOWER'), 2),
    },
    'gw_upper_ratio_detailed': {
        'description': 'Absolute assumed-law speed deviation at the adopted upper endpoint divided by the adopted cap, three significant figures.',
        'value': lambda: _sci(_ratio('CHI_VEST_NATURAL_UPPER'), 2),
    },
}
'''
p25='''"""Derived numerals for Paper25's conditional GW170817 comparison.

The existing SCALARS renderer evaluates the adopted GW_PARAMS cap/endpoints
through the canonical compatibility helper. These formatted arithmetic
values do not derive a microscopic mode, response, range or transport law.
"""

'''+common+'''SCALARS = {
    'gw_compatible_width': {
        'description': 'Conditional nonnegative susceptibility preimage width at the adopted cap; two significant figures, avoiding endpoint subtraction.',
        'value': lambda: _sci(_width(), 1),
    },
    'gw_lower_ratio_detailed': {
        'description': 'Lower adopted endpoint deviation/cap ratio, three significant figures.',
        'value': lambda: _sci(_ratio('CHI_VEST_NATURAL_LOWER'), 2),
    },
    'gw_upper_ratio_detailed': {
        'description': 'Upper adopted endpoint deviation/cap ratio, three significant figures.',
        'value': lambda: _sci(_ratio('CHI_VEST_NATURAL_UPPER'), 2),
    },
    'gw_lower_ratio_rounded': {
        'description': 'Lower adopted endpoint deviation/cap ratio, two significant figures for abstract/caption.',
        'value': lambda: _sci(_ratio('CHI_VEST_NATURAL_LOWER'), 1),
    },
    'gw_upper_ratio_rounded': {
        'description': 'Upper adopted endpoint deviation/cap ratio, two significant figures for abstract/caption.',
        'value': lambda: _sci(_ratio('CHI_VEST_NATURAL_UPPER'), 1),
    },
}
'''
files={}; replacements=[]
for paper,spec in [('L1',l1),('paper25_gravitational_waves',p25)]:
 path=f'papers/{paper}/tables.py';assert not (root/path).exists();files[path]=spec
 path=f'papers/{paper}/paper_draft.tex';s=(root/path).read_text();old=s
 rules=[(r'1\.2\s*\\times\s*10\^\{-14\}','gw_compatible_width',2),(r'2\.28\s*\\times\s*10\^\{14\}','gw_lower_ratio_detailed',1),(r'7\.21\s*\\times\s*10\^\{14\}','gw_upper_ratio_detailed',1)]
 if paper=='L1':rules+=[(r'1\.2\s*\\times\s*10\^\{-15\}','gw_relative_width',1)]
 else:rules+=[(r'2\.3\s*\\times\s*10\^\{14\}','gw_lower_ratio_rounded',2),(r'7\.2\s*\\times\s*10\^\{14\}','gw_upper_ratio_rounded',2)]
 for pat,key,count in rules:
  hits=list(re.finditer(pat,s));assert len(hits)==count,(paper,key,len(hits));new=r'\input{tables/'+key+r'.tex}\unskip';s=re.sub(pat,lambda m:new,s);replacements.append({'paper':paper,'id':key,'occurrences':count,'old_rendered_values':[h.group() for h in hits],'new_tex':new})
 files[path]=s
for p,s in files.items():
 q=dest/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
m={'scope':'Existing SCALARS pipeline, 13 derived numeral sites (11 counted plus two coherent L1 caption sites); no claims/physics/roster/human change. All original BUILD and canonical reviews still owed.','source_head':'ddc3a0d1932e4a24f2b0305f08679547348b68b3','files':{p:{'preimage_sha256':hashlib.sha256((root/p).read_bytes()).hexdigest() if (root/p).exists() else None,'candidate_sha256':hashlib.sha256(s.encode()).hexdigest()} for p,s in files.items()},'replacements':replacements,'expected_counted_debt':'150 ->139, not whole117ceiling acceptance','original_theorem_source_constants_retained':True}
(dest/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'candidate':str(dest),'files':list(files),'sites':sum(x['occurrences'] for x in replacements)},indent=2))
