Narrow L1 scalar source catalog candidate (off-tree only)

Candidate: /tmp/l1-gw-catalog-candidate-r1.json

SHA256: 7a4ac6ec9485bce91d0d093e469eb9b9611c2422743926eef544327e8e931b62

154 units; five source quote/ID bindings changed (units 25, 60, 65, 66, 75);149 full records deep exact;154 prior scientific assessments preserved.

Existing sentence_state.compute_sentence_id (the actual helper name), normalize_quote and validate_claims_review used; schema errors0. No new normalizer/registry.

Top historical review identity unchanged. Full154 old records and prior top metadata preserved in the focused review_evidence entry; every old evidence/history member retained deep exact.

All five successor quotes literally bind current manuscript with existing label-command whitespace mask; changed theorem labels remain masked as in prior records.149 unchanged records retain all escaping byte-equivalent at JSON-value level.

Optional short caption title is outside existing unit payloads: units73/74 unchanged; only unit75 width quote rebinds. Two endpoint ratio changes are approximate evaluations, not exact Lean constants.

No active followup/blocker references point to any replaced ID; historical old IDs remain in historical records.

All4 blocker objects exact OPEN;7pending human candidates exact;0auto-closures. All verdicts, notes, deltas, old dates/run IDs/backing chains and assessment metadata exact.

Only review_scope current manuscript/coverage/acceptance fields and one focused review_evidence entry change outside five records. Complete prior top metadata retained.

Nine actual scalar artifacts and four producer files match R2 manifest hashes. Existing10page pixel-identity receipt is attributed, not personally rerun.

ID map:

sentence:L1:introduction:ec137388 -> sentence:L1:introduction:a0363bf2

sentence:L1:formal-setup-and-result:78102830 -> sentence:L1:formal-setup-and-result:c8300997

sentence:L1:formal-setup-and-result:f0508a9e -> sentence:L1:formal-setup-and-result:6b51f402

sentence:L1:formal-setup-and-result:98b3a2d2 -> sentence:L1:formal-setup-and-result:d9d70037

sentence:L1:formal-setup-and-result:928d4e3e -> sentence:L1:formal-setup-and-result:725fe8ec

Preservation witnesses and artifact hashes: /tmp/l1-gw-catalog-author-r1.json

Required: independent candidate review, ROOT application/intake/Fbindings via existing writers, original physical BUILD and human/publication gates. No self-certification or ingest.

Execution: read-only/helper schema checks and off-tree authoring only. No repo/notebook writes, tests/render/scientific/Lean/native/slot/Git mutations.

Final continuity check follows separately and will be recorded in report.

Final same-packet continuity: fresh=true, changed=[]; source/catalog/prose/audit/notebook packet snapshot unchanged.
