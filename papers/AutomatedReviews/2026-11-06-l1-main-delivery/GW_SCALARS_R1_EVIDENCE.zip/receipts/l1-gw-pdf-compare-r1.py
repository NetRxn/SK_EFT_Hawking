from pathlib import Path
import subprocess,concurrent.futures,json,hashlib
from PIL import Image,ImageChops
out=Path('/tmp/l1-gw-scalars-render-r1');out.mkdir(exist_ok=True)
jobs=[]
for paper in ['L1','paper25_gravitational_waves']:
 for stage,pdf in [('before',Path('/tmp/l1-gw-scalars-before-r1')/('papers__'+paper+'__paper_draft.pdf')),('after',Path('papers')/paper/'paper_draft.pdf')]:
  d=out/(paper+'-'+stage);d.mkdir(exist_ok=True);jobs.append((paper,stage,pdf,d))
def render(job):
 paper,stage,pdf,d=job;a=['pdftoppm','-png','-r','120',str(pdf),str(d/'page')];p=subprocess.run(a,capture_output=True,text=True,timeout=90);assert p.returncode==0,(a,p.stderr);return {'paper':paper,'stage':stage,'argv':a,'rc':p.returncode,'stderr':p.stderr,'pages':len(list(d.glob('page-*.png')))}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:receipt=list(pool.map(render,jobs))
comparison={}
for paper in ['L1','paper25_gravitational_waves']:
 before=sorted((out/(paper+'-before')).glob('page-*.png'));after=sorted((out/(paper+'-after')).glob('page-*.png'));assert len(before)==len(after)==5;rows=[]
 for a,b in zip(before,after):
  ia=Image.open(a).convert('RGB');ib=Image.open(b).convert('RGB');same=ia.size==ib.size and ImageChops.difference(ia,ib).getbbox() is None
  rows.append({'page':a.name,'pixel_identical':same,'before_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
 comparison[paper]=rows
r={'render_receipts':receipt,'comparisons':comparison};Path('/tmp/l1-gw-pdf-compare-r1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({p:[x['pixel_identical'] for x in d] for p,d in comparison.items()},indent=2))
