# Independent actual composition review R2

**ACCEPT exact current source, nine generated outputs, two caption syntax repairs and bounded render/control composition.** Current hashes all match `/tmp/l1-gw-scalars-proposal-r2/MANIFEST.json` (SHA256 `2d2f536654b08425c497306e029794b3d26e73f548f60dcd0b38881983268b62`). This accepts neither the separate canonical catalog candidate nor F rebinding, and grants no scientific BUILD, aggregate G11, main/native, human or publication acceptance.

## Source and syntax

All four current source hashes and all nine output hashes independently match the R2 manifest. Both specs are byte-identical to accepted R1. Compared with R1 postimages, manuscript changes consist only of optional short-caption arguments: L1 `Conditional GW170817 susceptibility window`, Paper25 `Adopted speed-law endpoint comparisons`. Long visible captions are unchanged. This uses existing E1 caption syntax. Short list-entry titles do not assert stronger science and avoid expanding fragile input commands in the moving argument; displayed values still use the existing generated snippets.

R1 failure is real: kept debug log shows `Argument of \Hy@tempa has an extra }` and runaway caption arguments at L1's figure caption, with2 TeX errors; R1 Paper25 produced no PDF. This failure was not silently promoted to acceptance. R2 retained log reports both5-page compilations with0 errors/overfull/unresolved/dropped options. I inspected the actual kept R2 logs and independently confirmed both current PDF files are byte-identical to the corresponding kept compile PDFs. Logs contain actual scalar input reads. The retained temp directories have no saved TeX copy; source is instead bound by current manifest/packet and the inspected two-line delta. An initial readback attempt assumed a kept TeX copy, failed on absent file, and was corrected to verify retained PDF/log artifacts only. No compile was run by this reviewer.

## Values and scope

Current output values are:

| Paper | Field | Actual value line |
|---|---|---|
| L1 | compatible width | `1.2\times10^{-14}%` |
| L1 | relative width | `1.2\times10^{-15}%` |
| L1 | lower / upper detailed ratios | `2.28\times10^{14}%` / `7.21\times10^{14}%` |
| Paper25 | compatible width | `1.2\times10^{-14}%` |
| Paper25 | lower / upper detailed ratios | `2.28\times10^{14}%` / `7.21\times10^{14}%` |
| Paper25 | lower / upper rounded ratios | `2.3\times10^{14}%` / `7.2\times10^{14}%` |

R1's independent arithmetic/source assessment carries only because the spec bytes and adopted cap/endpoints are unchanged: cap3e-15, interval[0.1,10], width4cap, relative width4cap/9.9, canonical-helper absolute speed deviation/cap at each endpoint. Width uses the stable general preimage piecewise expression, not subtraction of rounded endpoints. Scientific formatting retains two/three significant figures, including prior relative-width rounding. Literal percent suppresses snippet newline and call-site unskip remains. These are conditional evaluations, not a microscopic normalization/range or physical response/state/transport derivation.

The corrected descriptor is accurate: two extra uncounted L1 sites are approximate lower/upper ratios in Theorem environments, not captions. Under the D3 precedent, these approximate evaluations differ from exact constants in the underlying Lean statements. Exact/adopted cap/endpoints, anchor, square-root expressions and conservative Lean-bound arguments are preserved. Five L1 plus eight Paper25 substitutions form the whole width/endpoint-ratio family;11 counted sites are removed. Actual census receipt is139, still above117. No global gate PASS follows.

## Render conservation

I read the actual comparison script and receipts. It renders both prior and current PDFs through pdftoppm at120dpi and compares RGB pixels. Independently rehashing all20 PNG files verifies every before/after pair has the receipt hash and is byte-identical, across all10 compared pages. Thus visible content/layout are conserved at this resolution. I also visually inspected L1 page3 and Paper25 page4 containing the changed captions; generated numbers and surrounding conditional language render correctly. This is bounded visible conservation against the supplied baseline, not PDF metadata/semantic identity or new whole-paper scientific review.

## Actual controls

The temporary control script invokes the existing renderer loader and scalar renderer, compares all9 production output files against freshly evaluated scalar content and does not write them. The child forbids native subprocess/network, asserts module origins under the actual checkout, uses fresh temporary bytecode prefix plus-B/no-write-bytecode, and records raw channels and decoded results. No new persistent gate, registry or validator is introduced.

I independently decoded every raw stdout and checked exact equality to the recorded result and empty stderr. Receipt sequence:

| State | Exit | Mismatches |
|---|---|---|
| Baseline |0|0/9|
| Actual canonical cap doubled to6e-15 |1|9/9|
| Cap restored |0|0/9|
| One actual width output corrupted |1|1/9|
| Output restored |0|0/9|

The cap mutation doubles both widths and halves every endpoint ratio, so all9 value differences are causally appropriate. Output-only corruption affects exactly its own file. I independently compared current restored constants/output hash, full st_mode and nanosecond mtime against before/after restoration receipts; both match exactly. Journal-empty status is recorded, and the script uses the existing seed journal's outstanding checks. No writer runs while seeded. These controls establish bounded producer/artifact sensitivity and restoration, not independent physics correctness, global tables_fresh, a full project run or a scientific certificate. I did not rerun mutations or project imports.

## Pending owners and continuity

Canonical L1 catalog source/quote/ID/lineage reconciliation, independent proposal/application review and existing writer readback remain pending. F_SOURCE_REVIEW hashes both manuscripts and L1 catalog, so its independent dependency-semantic rebinding and existing declared Verify remain pending after the canonical catalog settles. No source/report here closes original B3/mode/normalization/range/state/transport work or changes human decisions/history.

Only read-only file inspection, standard-library JSON/base64/hash comparisons and image viewing were performed; only the assigned R2 Markdown/JSON reports were written. No tests, project imports, rendering/compiling, seeds, Git/native/controller, source/catalog/notebook writes. First/final same-packet continuity: fresh=true, changed=[]; snapshot freshness is not acceptance authority.
