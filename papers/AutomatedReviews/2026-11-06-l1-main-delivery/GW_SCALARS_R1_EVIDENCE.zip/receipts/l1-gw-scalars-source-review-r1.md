# Independent prospective L1 / Paper25 scalar source review

**ACCEPT the exact four postimages identified by MANIFEST.json** (manifest SHA256 `14cb94ca52061c5d3461721099110f68b5952eac44701fcfe45b3da41170c502`), at source HEAD `ddc3a0d1932e4a24f2b0305f08679547348b68b3`, for source-provenance application only. No source changes are required. No whole-stage, full-tree, human, physical BUILD or publication acceptance follows.

I read current CLAUDE.md, WAVE_EXECUTION_PIPELINE.md (including authoring, claim, sync and review boundaries), continuity guide/ADR-017 and ADR-008 scope, the referenced roadmap/notebook, actual paper-authoring skill and its prohibited-pattern reference, both candidate specs/manuscript diffs, existing D3 precedent, owning render engine and scalar discovery/output ownership, GW_PARAMS, canonical deviation/helper bodies, the exact Lean width statement, current L1 canonical claims and prose state, and current F dependency review. First continuity check was fresh.

## Inputs and field dispositions

All nine fields ACCEPT:

| Paper | Scalar | Operating point / arithmetic | Raw value | Display / uses |
|---|---|---|---|---|
| L1 | gw_compatible_width | cap=3e-15; stable4cap | 1.2e-14 | 1.2 times10^-14;2 |
| L1 | gw_relative_width | width/(10-0.1) | 1.2121212121212121e-15 | 1.2 times10^-15;1 |
| L1 | gw_lower_ratio_detailed | abs(deviation(0.1))/cap | 2.2792407799438734e14 | 2.28 times10^14;1 |
| L1 | gw_upper_ratio_detailed | abs(deviation(10))/cap | 7.207592200561265e14 | 7.21 times10^14;1 |
| Paper25 | gw_compatible_width | same cap/width | 1.2e-14 | 1.2 times10^-14;2 |
| Paper25 | gw_lower_ratio_detailed | same lower endpoint | 2.2792407799438734e14 | 2.28 times10^14;1 |
| Paper25 | gw_upper_ratio_detailed | same upper endpoint | 7.207592200561265e14 | 7.21 times10^14;1 |
| Paper25 | gw_lower_ratio_rounded | same lower endpoint | 2.2792407799438734e14 | 2.3 times10^14;2 |
| Paper25 | gw_upper_ratio_rounded | same upper endpoint | 7.207592200561265e14 | 7.2 times10^14;2 |

Values above were independently checked with standard-library arithmetic, not project imports. Candidate ratios call the canonical ligo_compatibility_check, whose violation_factor is abs(c_GW_deviation_from_c(chi))/GW_PARAMS cap. The deviation evaluator is the stable form of sqrt(chi)-1 under the assumed law; it does not derive the law or input range. Adopted lower/upper comparison endpoints are not microscopic predictions. Width reuses the D3 scalar precedent and canonical helper's documented preimage identity: for finite nonnegative cap it is4cap up to1, and(1+cap)^2 beyond1. No subtraction of floating endpoints near unity occurs. Lean ligo_window_width_eq checks the fixed-cap polynomial identity; no new theorem/general physical claim is inferred from the formatting helpers.

Formatting uses scientific mantissas with one decimal place (two significant figures) or two (three significant figures). Detailed/rounded versions are intentional presentation variants at the same operating point. The relative-width value is rounded to two significant figures just as before; its ~1% rounding is not a new precision claim. Each value ends with literal `%`, suppressing its file newline, and all13 call sites immediately use `\unskip`. The engine's comment-only header preserves math context. TeX whitespace differences in Paper25 scientific notation do not alter display. Abstract/caption expansion and final PDF layout still require actual compile/render review.

## Exact conservation and family completeness

I independently hashed all four candidate files and checked both original manuscript hashes / absence of both new specs against the manifest. Reversing the manifest's13 actual substitutions reconstructs both current manuscripts byte-for-byte. All nine preview values equal every corresponding old numeral modulo TeX whitespace. Source/core/formulas/constants/helper/Lean/render engine remain unchanged; no scientific sentence, theorem constant, observation, source-emission assumption, conditional interval result, adopted-range qualification or prior-dependent probability statement is removed or strengthened.

The D3 precedent explicitly excludes exact constants of Lean theorem statements from scalar re-derivation. The two L1 Theorem-environment replacements are nevertheless appropriate: both are introduced by approximate equality and evaluate abs(sqrt(0.1)-1)/tau and abs(sqrt(10)-1)/tau. Those formatted2.28e14/7.21e14 values are not exact constants asserted by natural_lower_violates_ligo/natural_upper_violates_ligo; the latter prove strict cap violations via conservative square-root bounds. Their placement in a prose Theorem environment does not turn an approximate arithmetic display into a fixed Lean statement constant. Exact square-root expressions, adopted0.1/10/cap, anchor and Lean-bound proof arguments stay untouched. This preserves the D3 distinction rather than silently broadening it.

The package covers the complete present absolute/relative-compatible-width and endpoint violation-ratio family in both manuscripts, including detailed and abstract/caption precision variants. It does not manufacture an arbitrary quantity of migrations to reach a count ceiling. Source-defined cap/endpoints, exact theorem constants, fixed anchor and separately presented approximate speed deviations remain as they were. No new machinery/registry/validator or swallowed microscopic gap appears.

One report-label correction: the two extra uncounted L1 substitutions are the detailed endpoint ratios in its Lower/Upper endpoint theorems (source lines228/235), **not caption sites**. The earlier literal audit counts L1's relative width, body width and caption width (3) plus Paper25's8 sites. Thus13 sites comprise5 L1+8 Paper25;11 counted sites predict150->139, still above117. This does not require a candidate change. ROOT must correct the descriptor metadata wording deliberately after final review; the frozen manifest was not modified.

## Required downstream acceptance, without catalog edits here

1. Apply only these exact candidates and generate nine scalar outputs through the existing renderer; run appropriate existing controls. This review did not execute the renderer or gates.
2. Compile L1 and Paper25 using the existing compile owner and independently inspect PDF values, captions and abstract. Existing reader/claims/adversarial boundaries remain intact.
3. Reconcile current L1 claims_review.json after the raw TeX substitutions. Its154-unit catalog currently binds the old source and assessments. sentence_state.normalize_quote does not remove input/unskip, so quote hashes/IDs can change even when displayed mathematics does not. Preserve complete predecessor lineage and original open blockers; use the existing schema/ingest/audit process with independent catalog and actual application review. Preserve human state and audit prefix; do not reset or claim automatic scientific closure. Paper25 has no existing claims_review.json in this checkout; handle its source review through the existing owning flow rather than invent a catalog or mechanism.
4. Rebind the existing `papers/AutomatedReviews/2026-11-06-l1-main-delivery/F_SOURCE_REVIEW.json` after source/catalog/compiled artifacts settle. Its source_hashes explicitly pin L1 TeX, L1 claims and Paper25 TeX. Independent semantic refresh must inspect whether unchanged F spans still carry the same conditional conclusions, retain prior histories/closure, and rerun the already declared Verify. F's legacy claims_review.json is not the current154-unit L1 catalog and must not be overwritten. F manuscript rewriting is not justified by this value-conserving package.

Original B3/mode, physical normalization/range, state/transport, unit/frequency matching, controlled expansion and all other scientific BUILDs remain open. This review is source/value conservation at the fixed adopted inputs, not revalidation of their primary-source standing, a native build, full project gates or publication approval.

## Executed work and continuity

Read-only shell reads/diffs/searches; standard-library JSON/hash/exact-reverse/value checks; first and final prescribed continuity checks. No tests, project imports, renderer, compiler, Git operations, native/controller operation, network or checkout/notebook/catalog writes. Only `/tmp/l1-gw-scalars-source-review-r1.md` and `.json` written. Final packet check: fresh=true, changed=[]; it certifies snapshot freshness only.
