# Reviewer-stage lifecycle data repair proposal

UNAPPLIED. The unchanged existing canonical reviewer-ordering check rejects
D6/D8/D10 Stage10 status strings encoding a redraft event/date. Existing
pending-redo expresses the actual state: another review is owed.

Replace only those three string values. Every other byte/field is identical,
including exact dated redraft notes, prior review-doc references, scientific
caveats, all apex records, Stages9/13 and redo flags. No fresh reviewer verdict
or publication acceptance is invented; record_review.py only records actual
green/yellow/red reviewer verdicts and none is earned by this correction.
The prior diagnosis already identifies these same defects; no new machine
or enum, checker change, weakened criterion or closed science is proposed.

The actual unchanged check was invoked in an isolated process with only its
metadata reader temporarily supplied all21 immutable actual Git blobs:
baseline fails exactly three invalid-status details; proposed three values pass
all21. This is proposal measurement, not an executed MAIN post-apply gate.
All three source preimages also exactly equal clean primary7fc0 metadata.
Independent source/chronology review precedes applying this to MAIN after its
currently live full-profile run terminates. Existing chronology tests and
actual canonical check/fault/restoration follow application.
