# SK-EFT Hawking — Paper Communication Strategy

**Status:** Active strategy document. Supersedes the per-wave-paper convention from Phases 1–6f for *external* communication; the per-wave drafting work in `papers/paperN_*` continues as internal source material that is then consolidated into the bundles defined here.

**Created:** 2026-04-28 from program-wide gap analysis (`temporary/Research-Overview/research_overview_analysis.md`) + paper-strategy reframing.

**Authority:** This document is the canonical reference for paper-deliverable structure and sequencing. Phase 6i Wave 7 (Paper Strategy Integration) wires this into the review pipeline. The per-paper drafts in `papers/paperN_*` remain in the repository as historical/source material; their consolidation into the bundles defined here is tracked in `PAPER_DRAFT_MAPPING.md`.

---

## 1. Diagnosis of the prior "one paper per wave" strategy

The project entered Phase 6 with thirty-two paper drafts and zero submissions. This is not a productivity issue — the per-wave drafting cadence has been an extremely effective *internal* discipline: each wave produces a paper-shaped deliverable, the Stage 13 adversarial reviewer keeps each draft honest, and the sentence-level provenance ties each claim to a Lean theorem. But the resulting paper map is inward-facing in three concrete ways:

**Headline results are buried.** "First quantum group in any proof assistant," "first formally verified four laws of black-hole mechanics partitioned by regime," "GW170817 falsifies the vestigial-second-sound graviton ID by 7 × 10¹⁴" — each of these is striking enough on its own to be the door into the program, but each currently sits inside a draft (Paper 11, Paper 27, Paper 25) that an external reader encounters as an isolated technical result. There is no flagship that says "here is what this research program is about" for them to land in.

**NO-GO theorems lose first-class status.** The program is unusual in that negative structural results are a deliberate output: Volovik q-theory dark energy, the vestigial-graviton GW170817 falsification, Fang-Gu torsion DM kinematic exclusion, fracton hydrodynamics → full GR, the BCS-branch seesaw lepton-number-violation requirement, perturbative Wen-ADW gravity, EW baryogenesis under crossover, abelian-MTC at the BH horizon. Distributed across many drafts, these read like incidental obstructions. Consolidated, they are a coherent statement about *which* parts of the standard map of physics are reachable from condensed-matter substrates and *why* — a genuine field-clearing contribution. Phase 5y already understands this internally (six closure rounds, formal scope memo, `ARCHITECTURE_SCOPE.md`). The paper strategy did not previously reflect it externally.

**Methodology is invisible to physicists.** The project's verification pipeline — Lean + Aristotle + adversarial review + sentence-level provenance + the 14-stage wave execution + the preemptive-strengthening discipline — is genuinely novel as a way to *do* theoretical physics, not just as a tool for proof-assistant developers. Critically, the verification has produced physics that wouldn't otherwise exist: Aristotle disproved the original FirstOrderKMS axiom (too weak); Aristotle disproved the gap-solution-bounded conjecture; the chirality-wall axiom decomposition surfaced hidden dependencies; the strengthening-pass discipline has caught dozens of structural-tautology theorems. Buried in a methods paper that only formal-verification people will read, this contribution is invisible to the physics audience that should hear it.

The paper strategy below is designed to fix all three.

---

## 2. Architecture — four-tier, falsifiability-led

The new structure is **twenty-one publication targets**, organized as one flagship + twelve themed deep papers + three PRL-style headline letters + three infrastructure papers + two experimental letters. This is roughly a 1.9:1 collapse from the thirty-two drafts (offset by the new verification-native deep papers D6/D7/D8 that have no pre-strategy draft antecedent). Every existing draft maps cleanly into one of the targets (see `PAPER_DRAFT_MAPPING.md`). (Bundle architecture went 13 → 14 in Phase 6n Session 4 with the I3 authorization for "Verified Stochastic Calculus for Mathlib4"; 14 → 15 in Phase 6v Wave 6v.1 with the D6 authorization for "Formally Verified Fault-Tolerant Quantum Computation Substrate"; 15 → 16 in Phase 6w Wave 6w.6 with the D7 authorization for "Classical Simulability and Quantum Advantage via Tensor Networks"; 16 → 17 on 2026-05-31 with the **D8 authorization** for "Kernel-Verified Universal Quantum Gate Compilation" — consolidating the Phase 6p/6t/6u/6x/6x′/6y/6z verified-compilation corpus that had outgrown the D4 §9.x showcase container; original v1 figure of "eleven" headline drift was a long-standing miscount that earlier revisions corrected; 17 → 18 on **2026-06-10** with the **D9 authorization** for "Kernel-Verified Quantum-Network and Device-Characterization Certification Substrate" — consolidating the Phase 6AA→6AL QI-analytics/network corpus plus the 6AM/6AN/6AP/6AQ envelope waves that had no bundle home; 18 → 20 on **2026-06-29** with the **D10 + D11 authorizations** (the public substrate-breadth extension, Phases 6BA–6BC and 6CA–6CE); 20 → 21 on **2026-07-27** with the **D12 authorization** for "Kernel-Verified Detector & Readout Metrology" — the `6E*` verified device-physics metrology series (Phases 6EA/6EB/6EC/6EE; Phase 6ED simultaneously joined D11's sources as its concrete graphene band-structure thread).)

Three principles drive the architecture:

1. **Falsifiability-led ordering.** The PRL-style headline letters (Tier 2) lead with the program's strongest falsifiable results — GW170817 vs vestigial-graviton (a 10¹⁵ confinement of χ_vest, with both natural-range endpoints excluded at ~7 × 10¹⁴), three generations from modular invariance, BCH four laws by regime. These are the door-openers. Readers arrive through them.
2. **NO-GOs as first-class deliverables.** The dark-sector deep paper (Tier 1 #5) is built around the structural-NO-GO architecture. The flagship's Layer-3 scope statement makes the predictive-boundary explicit. The methodology paper documents specific cases where verification produced negative content the conventional process would have missed.
3. **The flagship is the citation anchor.** Tier 0 — one *Reviews of Modern Physics* / *Physics Reports* / *Annual Review* article — is the canonical entry point. Every other paper in the program cites it. It ships *last*, after the Tier 1 papers are out, so it can cite them and serve as the stable reference rather than a snapshot.

### 2.1 Tier 0 — flagship review (1 paper)

**Paper F: "Fluid-Based Approaches to Fundamental Physics — A Formally Verified Survey"**

Target journal: *Reviews of Modern Physics*, *Physics Reports*, or *Annual Review of Nuclear and Particle Science*.

Length: 80–150 pages.

Audience: the broad theoretical physics community plus mathematical physics and formal-verification readers.

Five jobs at once:
- Present the three-layer architecture (lattice → SK-EFT → emergent SM+GR) as the unifying frame.
- Index every machine-checked headline result and every formal NO-GO with cross-references to Tier 1 deep papers.
- Establish the verification methodology as a unifying thread (not a methods footnote).
- Lift `ARCHITECTURE_SCOPE.md` into the published literature: Layer 3 is in scope for SM+GR-sector emergent physics; the dark-energy sector is outside the tested predictive scope under Volovik mechanisms (and the Phase 6m verdict on causal-set / entropic-gravity / Jacobson-thermodynamic-GR routes, when shipped).
- Serve as the citation anchor that every other paper in the program references.

Outline (roughly 12 sections):
1. Introduction: the question and the methodology.
2. Three-layer architecture and predictive scope.
3. Emergent gauge fields: gauge erasure + topological-order routes.
4. Analog Hawking radiation across three platforms (summary; full content in Tier 1 #1).
5. Anomaly constraints on Standard-Model particle content (summary; full in Tier 1 #2).
6. Emergent gravity from microscopy (summary; full in Tier 1 #3).
7. Topological quantum computation foundations (summary; full in Tier 1 #4).
8. Dark sector under substrate constraints (summary; full in Tier 1 #5).
9. Verification methodology (summary; full in Tier 3 #1).
10. Architectural scope statement: what is and is not predicted.
11. Open program — Phase 6 forward roadmap.
12. Outlook: experimental access and future-work register.

This paper is *the* paper that says what the program is. Submitted last; built incrementally throughout the Tier 1 roll-out; final form benefits from ~12 months of accumulated cross-citation.

### 2.2 Tier 1 — themed deep papers (12 papers, D1–D12)

Each is a PRD/JHEP-style article aimed at one subcommunity. Each is the canonical reference for its slice. Each is 20–60 pages with full Lean theorem cross-references.

**Paper D1: Formally Verified Analog Hawking Radiation Across Three Platforms**

Target: *Physical Review D* (long article).

Audience: analog-gravity, condensed matter (BEC / polariton / Dirac-fluid graphene), gravitational-wave-adjacent.

Content: SK-EFT corrections to all orders; transport coefficient counting `count(N) = ⌊(N+1)/2⌋ + 1`; CGL FDR derivation; parity alternation theorem; exact WKB connection formula with the three non-perturbative effects (broken unitarity, FDR-mandated noise floor, spectral floor at ~6 T_H); positivity-forced relations at second order; KMS optimality; BEC predictions; polariton Tier-1 with stimulated-Hawking amplification; graphene Dirac-fluid 3×3 metric block-diagonalization, 92% Lean theorem reuse, Wiedemann-Franz violation, closed-form noise spectrum from Keldysh FDT + Landauer-Büttiker. Sidebar: how Aristotle's counterexample fixed the FirstOrderKMS axiom.

Sources: Papers 1, 2, 4, 12, 16a; Phase 5w + Phase 5d + Phase 5u material.

Companion: Tier 4 letters for Paris-LKB and Dean-Kim-Lucas experimental teams.

**Paper D2: Anomaly Constraints on Standard-Model Particle Content**

Target: *PRD* or *JHEP*.

Audience: high-energy theory, particle physics, lattice QFT, mathematical physics (anomaly classification, bordism).

Content: Three generations from Z₁₆ + modular invariance; the 16-convergence (SM Weyl, Z₁₆ classification, Rokhlin's 16, Kitaev DIII period — all from the quaternionic structure); the gravitational-anomaly argument for ν_R; the chirality-wall three-pillar synthesis (GS no-go evasion, GT positive construction, Z₁₆ algebraic anchor); the master TPF-evasion theorem; the 4+1D gapped-interface axiom and its 1+1D + 2+1D Fidkowski-Kitaev evidence; the change-of-rings discharge of topological hypothesis H2; the open H1/H3/H4 hypotheses pending Mathlib algebraic-topology infrastructure. The first machine-checked Ext^n_{A(1)}(F₂, F₂) computation in any proof assistant features as a section, not a separate paper.

Sources: Papers 7, 8, 9, 10; Phase 5b/5c/5q/5r/5h material.

**Paper D3: Emergent Gravity from Microscopy — Linearized EFE through Black-Hole Thermodynamics**

Target: *PRD* (long article), possibly *Annals of Physics*.

Audience: gravitational physics, BH thermodynamics, emergent-gravity community, holography-adjacent.

Content: ADW gap equation `G_c = 8π² / (N_f Λ²)`; the tetrad gap equation as the first explicit derivation in the literature; the bifurcation theorem; Vergeles unitarity Props; the gauge erasure selection rule (only U(1) survives the fluid layer; non-Abelian erased); the perturbative Wen-ADW deficit (G_Wen / G_c ≈ 1/6000 — route formally closed); fracton-hydrodynamics → full GR no-go; the linearized EFE result `G_N^emerg = α_ADW · 12π / (N_f Λ²)`; FLRW reduction with Friedmann I/II + Bianchi consistency; the GW170817 falsification of the vestigial-second-sound graviton identification (the headline negative result, reported in full); the Bekenstein-Hawking entropy from MTC state counting `S = A/(4G_N) − (3/2) log(A/(4G_N))` with Kaul-Majumdar SU(2)_k decomposition and the abelian-MTC F2 falsifier; the BCH four laws partitioned by regime at `M_c = (N_f Λ_UV) / (12π α_ADW)`; the Schwarzschild-vs-ADW-extremality regime criterion. Cross-bridges to QCD strong-coupling closure (Phase 6d Track A: confinement, χSSB GMOR, CFL ℤ_3 ≡ QCD center-ℤ_3) as a section.

Sources: Papers 3, 5, 22, 23, 25, 26, 27, 36, 37, 38; Phase 3 + Phase 5d + Phase 5f + Phase 5z W3 + Phase 6a + Phase 6d material.

**Paper D4: Topological Quantum Computation — First Machine-Verified Foundations**

Target: *PRD*, *PRX Quantum*, or split between mathematical-physics journal (*Communications in Mathematical Physics*) for the categorical content and *PRX Quantum* for the universality/gate content.

Audience: topological quantum computation, mathematical physics, formal verification (math-flavor).

Content: the longest verified mathematical chain in any proof assistant — Onsager-algebra → Inönü-Wigner contraction → U_q(sl₂) (first quantum group) → Hopf algebra (first non-trivial Hopf-algebra instance) → restricted u_q(sl₂) → SU(2)_k fusion at k=1,2,3 → S-matrix unitarity + Verlinde formula → algebraic number fields Q(√2), Q(√5), Q(ζ₅), Q(ζ₁₆) → F-symbols + R-matrices → hexagon equations → ribbon → trefoil = −1 (first verified knot invariant) → figure-eight knot → TQFT partition functions → WRT surgery invariants → Temperley-Lieb → Jones-Wenzl → Fibonacci universality (Lie-algebra spanning proof). Plus U_q(sl₃) (first rank-2 quantum group) → SU(3)_k fusion (first SU(3)_k formalization) → generic `QuantumGroup k A` → Kac-Walton fusion. Plus Muger center, Frobenius-Perron from fusion-matrix eigenvalues, dual-closure theorem, string-net. Plus the Fermi-Hubbard doublon SWAP + minimal Berry-phase theorem (first formally verified symmetry-protected two-qubit gate). Sidebar: industry relevance (Microsoft Majorana = our verified Ising; Google surface codes = our toric code via Vec_{ℤ/2} string-net; Fibonacci universality = our verified proof).

Sources: Papers 11, 14, 16b, 18; Phase 5b–5p material.

**Paper D5: The Dark Sector under Substrate Constraints**

Target: *PRD* or *Physics Reports* (review-flavored if the Phase 6m closure adds Tracks A/B/C verdicts).

Audience: cosmology, dark matter, dark energy, particle astrophysics.

Content: The structural NO-GO architecture for the dark-energy sector under tested mechanisms — Gibbs-Duhem locking `w_vac ≡ −1` for any single-scalar self-tuning emergent-vacuum framework; the q-theory realization-independent NO-GO across all four KV constructions; the four-factor orthogonality decomposition (Gibbs-Duhem ∩ c_s² ≥ 0 ∩ natural T_c ∩ MICROSCOPE); the closed-form vestigial EOS `w_vest(τ) = (1−τ²)/(5τ²−1)` and its catastrophic-c_s² gradient instability on the natural branch; the Zhitnitsky topological-DE absorption (within ≤ 3 orders of observed Λ, no free parameters); the combined-mechanism falsifier (Zhitnitsky + KV q-theory both active gives ×240 the observed value, forcing single-DE-mechanism commitment); the Phase 5y Layer-3 scope recalibration; the Phase 6m Tracks A/B/C closure for causal-set, entropic-gravity, and Jacobson-thermodynamic-GR routes (when those waves return). Plus the dark-matter classification: SFDM cluster-merger forecast at 3.5–5.7σ (Bullet, El Gordo, Pandora, A520, MACS J0025; Rankine-Hugoniot density-jump closed form; first 3σ detectable around 2028 with Euclid × Roman); fracton DM viability in p-wave dipole superfluid phase at MeV–TeV; Z₁₆-classified hidden-sector T-0 TQFT (invisible to all planned direct detection); Fang-Gu torsion DM kinematic exclusion at CDM level.

Sources: Papers 17, 32, plus the new Phase 6m verdict modules.

**Paper D6: Formally Verified Fault-Tolerant Quantum Computation Substrate**

Target: *PRD*, *PRX Quantum*, or *JHEP*.

Audience: fault-tolerant quantum computation, quantum error correction, gate compilation, mathematical physics, formal verification.

Content: The substrate-level kernel-verified content of the fault-tolerant-quantum-computation frontier as of 2025–2026. Four interlocking results: (i) the Williamson-Yoder gauging-of-logical-operators auxiliary-qubit overhead bound — linear in operator weight up to a polylogarithmic factor, with a falsifier proving the quadratic baseline is genuinely worse (Wave 6v.1, the bundle-creating wave); (ii) the Phase 6t quantitative Solovay-Kitaev tight-ε headline, retroactively absorbed as the canonical universal-compilation primitive consumed by the other sections; (iii) the affine-permutation-matrix LDPC code family over the project's cyclotomic substrate plus a Shannon-capacity hashing bound derived from the existing LDP / Cramér substrate (Wave 6v.5); (iv) the Kyoto-Hiroshima W-state single-shot projective-measurement decomposition in Q(ζ_N) cyclotomic coordinates (Wave 6v.6); plus (v) the Google/Caltech Shor T-gate counts for ECC-256 and RSA-2048, building on (ii) as the compiler primitive (Wave 6v.2). Together these form the first end-to-end kernel-verified substrate (code → measurement → compiler → universal logic) for the FT-QC frontier. Sibling relationship to D4 (TQC foundations): D4 retains its Fibonacci/topological-foundations focus; D6 covers the fault-tolerant-computation substrate.

Sources: Wave 6v.1, Wave 6v.2, Wave 6v.5, Wave 6v.6 deliverables (Phase 6v); Phase 6t Solovay-Kitaev retroactive absorption; FaultTolerance/ module family; QCyc*.lean cyclotomic infrastructure.

**Paper D7: Classical Simulability and Quantum Advantage via Tensor Networks: A Formally Verified Demarcation**

Target: *PRX Quantum* or *Physical Review X*.

Audience: tensor-network methodology, classical-quantum simulation boundary, fault-tolerant-QC roadmap planning, mathematical physics, formal verification, condensed-matter / analog-gravity downstream consumers.

Content: A unified kernel-verified demarcation theorem characterizing when classical tensor-network simulation suffices vs when quantum processors retain a structural advantage on quantum many-body dynamics. Headline `analog_hawking_quantum_advantage_demarcation` (Lean module `AnalogHawkingDemarcation.lean`): a system on factor graph `G` with factor weights `f_a` and categorical-Chern data `(c_0, c_1)` is classically simulable iff (i) the LDP rate function of the loop-correction terms is below threshold (BP-LDP-favorable: tree-like topology + non-negative factor weights) AND (ii) the Chern coefficient `c_1` vanishes. Six contributing Lean modules: `KibbleZurekUnruh.lean` (analog-Hawking application via KZ-U correspondence), `BeliefPropagation.lean` (24-theorem Mathlib-PR-quality BP substrate per Yedidia-Freeman-Weiss 2003), `BPLDPSimulability.lean` (BP-LDP biconditional), `ChebyshevTN.lean` + `AperiodicLattice.lean` (Aalto-style Chebyshev-TN + Penrose-tiling-style aperiodic predicates), `ChernBridge.lean` (categorical ↔ real-space Chern bridge), `AnalogHawkingDemarcation.lean` (combined headline). 67 substantive theorems total; all kernel-only `[propext, Classical.choice, Quot.sound]`; zero new project-local axioms. The substrate is fully generic over the factor-graph type parameters and applies beyond analog Hawking to any LDP-controlled-BP / Chebyshev-TN classification setting (the basis for the spin-out authorization). Primary anchors: Tindall-Sels Science 392, 868 (2026) (BP-on-PEPS classical simulation matching D-Wave Advantage2 on 300+ qubits) + Antão-Sun-Fumega-Lado PRL 136, 156601 (2026), Editor's Suggestion (Chebyshev-TN quasicrystal Chern markers on hundreds of millions of sites). Analog Hawking instantiation worked out as the application section via the KZ-U correspondence (Wave 6w.1 substrate).

Sources: Phase 6w Waves 6w.1 through 6w.6 deliverables (Lean-only / D.4 sourceless). Bundle creation triggered 2026-05-26 PM at Phase 6w Wave 6w.7 absorption pass per the Phase 6w strategy-synthesis decision-rule conditional authorization (generality criterion met).

**Paper D8: Kernel-Verified Universal Quantum Gate Compilation — Alphabet-Agnostic Solovay-Kitaev across Dimensions**

Target: *PRX Quantum* or *Quantum*, with the Lie-theoretic substrate content optionally split to a mathematical-physics venue (*Communications in Mathematical Physics*) if reviewer feedback recommends.

Audience: quantum compilation / gate synthesis, fault-tolerant quantum computation, topological quantum computation, formal verification (math-flavor and systems-flavor), and the trapped-ion / superconducting hardware-vendor research community.

Content: The first end-to-end **machine-checked theory of universal quantum gate compilation** — not a single algorithm but the *alphabet-agnostic, dimension-agnostic* substrate plus its instantiations, all kernel-pure. Six interlocking results: (i) the **alphabet-independent quantitative Solovay-Kitaev substrate** (Phase 6u): the Dawson-Nielsen super-quadratic recursion, Cartan-v4 density-from-witness, BCH bracket-closure, and ε₀-net packaged behind a generic `GeneratingSet` abstraction, so a new universal gate set ships its verified quantitative compiler by *instantiation* rather than re-derivation — demonstrated unconditionally on Clifford+T (`solovayKitaev_dawson_nielsen_quantitative_cliffordT_strict_constructive_tight_unconditional`, with ⟨H,T⟩ density via a Niven algebraic-integer obstruction); (ii) the **lift of the entire substrate to arbitrary dimension SU(d)** (Phase 6y): the first kernel-verified quantitative Solovay-Kitaev at general d (`solovayKitaev_dawson_nielsen_quantitative_generic_sud_strict_constructive_tight`), with the existential-radius regime blocker eliminated by a novel **concrete-radius matrix logarithm** (`matrixMercatorLog` / `exp_matrixMercatorLog`, Mathlib-PR-eligible) and the word-length exponent corrected and discharged at the honest `log 5 / log(3/2) ≈ 3.97` value; (iii) a **five-alphabet instantiation survey** — Fibonacci (D4-anchored), Clifford+T, Read-Rezayi `SU(2)_5`/`SU(2)_7` (Chebyshev-`T₇` and triple-angle Niven obstructions), trapped-ion Mølmer-Sørensen at SU(4) (`trappedIonSU4_solovayKitaev_headline_unconditional`), and Clifford+CCZ at SU(8) (`cliffordCCZSU8_solovayKitaev_headline_unconditional`); (iv) **two complementary, honest density mechanisms for the same SU(8) target** (Phase 6y per-qubit-T over-complete route vs Phase 6z **T-free, CCZ-essential** literal route `cliffordCCZLiteral_dense` / `cliffordCCZLiteral_solovayKitaev_headline_unconditional`) — a publishable pairing demonstrating universality via fundamentally distinct routes; (v) the **Mukhopadhyay resource theory** (Phase 6x′): an *unconditional* machine-checked Toffoli-count lower bound `T^of(U) ≥ sde₂(Û)` (`channelSde2_le_toffoliCost`) via the signed-parity-invariant `sde₂` measure on the channel representation, the dyadic-entry Lemma 3.10 (`channelRep_interp_isRat`), and the Clifford-only-not-dense converse (`cliffordOnly_not_dense`, confirming CCZ is genuinely essential — not over-complete); plus (vi) the **Mathlib-upstream contribution portfolio** — concrete-radius matrix logarithm, generic BCH order-2 cubic estimate, SU(d) Cartan density-from-witness, matrix-exponential local-homeomorphism. Sidebar: industry alignment (the trapped-ion SU(4) and Clifford+CCZ SU(8) instances target the gate sets actually realized on production hardware), with the explicit scope note that *runtime compiler implementation, vendor-specific tuning, certificate formats, and length-optimality engineering are outside this paper's scope* — D8 is the verified **existence / universality / lower-bound** theory; the runnable-compiler layer is a separate engineering deliverable.

Relationship to siblings: **D4** retains the Fibonacci-universality + topological/categorical-foundations focus; D8 cites D4 for the Fibonacci anchor and lifts the universality machinery to the general alphabet/dimension setting. **D6** consumes D8's quantitative Solovay-Kitaev as the canonical universal-compilation primitive (the relationship the D6 scope previously assigned to the Phase 6t Fibonacci headline is now served, more generally, by D8). The Phase 6p Fibonacci density + Phase 6t quantitative-SK content that the draft mapping previously routed to D4 §9.1–9.5 is re-pointed to D8 as the substrate's origin point, with a D4 cross-reference paragraph retained.

Sources: Phase 6p (Fibonacci density), Phase 6t (quantitative SK + reference-compiler skeleton), Phase 6u (generic substrate + Clifford+T), Phase 6x (Read-Rezayi k5/k7 + alphabet substrates + Mathlib tracks), Phase 6x′ (Mukhopadhyay channel-rep + Toffoli bounds), Phase 6y (SU(d) lift + SU(4)/SU(8) instances), Phase 6z (T-free CCZ-essential SU(8) density). Bundle authorized 2026-05-31 per Pipeline Invariant #14; all source content is Lean-only / D.4-sourceless, kernel-pure, zero project-local axioms.

**Paper D9: Kernel-Verified Quantum-Network and Device-Characterization Certification Substrate**

Target: PRX Quantum / Quantum. Length: ~40pp. **Authorized 2026-06-10** per Pipeline Invariant #14 (defensive-publication posture per the going-forward origination rule: textbook/published math lives in the public substrate, at full strength, first try).

Content: the kernel-verified analytic substrate for certifying quantum networks and quantum devices from universally-stated parameters, in five interlocking layers, all kernel-pure: (i) the **diamond-norm program** (Phases 6AF–6AH): trace distance, Uhlmann fidelity, both Fuchs–van de Graaf bounds, the Watrous Choi sandwich (both one-sided bounds), SDP duality and attainment, exact diamond distances for named channel families (Pauli, generalized amplitude-damping, erasure); (ii) the **entropy/majorization corpus** (6AF–6AL + 6AM W6): von Neumann entropy, Klein inequality, subadditivity, concavity, Gibbs variational principle, Fannes–Audenaert and the **sharp unconditional Audenaert form** for density operators, Lidskii–Wielandt majorization, plus the negativity/PPT/partial-transpose ladder; (iii) **network envelopes** (6AA–6AE, 6AN W2): Werner swap chains, DEJMPS distillation, teleportation thresholds, BB84 secret-key rates, repeater-chain and W-state rates, PLOB and erasure two-way rate ceilings (two-layer posture), and network capacity with flow/cut weak duality, MFMC-witnessed optimality, and strong duality (built in-project — Mathlib has no max-flow/min-cut); (iv) the **device-characterization envelope family** (6AK, 6AN W3/W4, 6AM W4, 6AQ): the coherence-limited average-gate-fidelity ceiling, composed-gate fidelity, SPAM process fidelity, randomized-benchmarking certificate, the classical Johnson–Nyquist and **derived quantum Callen–Welton (½ℏω·coth) FDT noise floors** (the latter instantiated from a PhysLib canonical ensemble), and the **readout-window envelopes** (relaxation decay probability and the thermal-population assignment floor derived from the PhysLib two-state ensemble), each with rational-enclosure corollaries usable at device operating points with no floating-point transcendentals; (v) the **kernel-only rational-enclosure technique** itself (`expNeg_enclosure` Bernoulli brackets + Taylor squeezes) as the cross-cutting numerical-certification method. The methodological through-line — and the paper's honest-scoping contribution — is the **two-layer posture**: the formula layer is Lean-verified; the device/channel identification layer is literature-cited and never conflated, with model hypotheses explicit in every floor/ceiling theorem.

Relationship to siblings: **D8** supplies the compiled-gate diamond certificate (`diamondDist_cliffordTCompile_le`) that joins compilation to channel certification — D9 cites D8 for the compiler layer and owns the channel/measurement-certification layer; **D6** retains the fault-tolerant code/measurement/logic substrate (D9's device envelopes characterize the physical layer beneath D6's logical layer); **I3** retains the stochastic-calculus/LDP foundations D9's rare-event tails consume. Known walls documented honestly: the Caves phase-insensitive-amplifier added-noise bound stays a cited hypothesis (bosonic CCR ladder algebra absent from PhysLib).

Sources: Phases 6AA–6AL (QI-analytics + network corpus), 6AM W1–W4 + W6, 6AN W2–W4, 6AP W1/W2/W4, 6AQ (readout envelopes); staging draft `papers/phase6AA_qnetwork_preprint/preprint_draft.md`. All Lean-only / D.4-sourceless, kernel-pure, zero project-local axioms.

**Paper D10: Kernel-Verified Foundations of Computational Quantum Chemistry & Open-System Dynamics**

Target: *PRD* / *PRX Quantum* / *J. Chem. Phys.* Length: ~40pp. **Authorized 2026-06-29** per Pipeline Invariant #14 (defensive-publication posture; a public substrate-breadth extension enabled by the PhysLib dependency).

Content: the verified foundations of the electronic-structure / open-system stack, in three kernel-pure layers: (i) **non-equilibrium Green's-function (NEGF) transport** (Phase 6BA): retarded/advanced Green's functions, the Landauer–Büttiker / Meir–Wingreen conductance, and a conductance-quantization certificate on PhysLib's unbounded-operator resolvent — the first NEGF/Landauer *conductance* transport in any proof assistant; (ii) **density-functional-theory foundations** (Phase 6BB): Kato–Rellich self-adjointness of the molecular many-body Coulomb Hamiltonian, the Hohenberg–Kohn I uniqueness theorem, HK II variational principle, and the Levy–Lieb constrained-search functional, on PhysLib's Schmüdgen-grade unbounded spectral substrate; (iii) **open-system dynamics** (Phase 6BC): the Lindblad/GKSL generator with complete positivity via the PhysLib Choi layer, the GKSL structure theorem, and the Markovian semigroup (`Matrix.exp` of the non-Hermitian Liouvillian). Two-layer honest scoping throughout (formula layer verified; device/material identification literature-cited).

Relationship to siblings: sibling to **D11** (the condensed-matter / metamaterial band-theory substrate); both are the 2026-06-29 public substrate-breadth extension. The Jordan–Wigner/Trotter fermionic-simulation substrate (Phase 6BD; novelty refuted by QBlue, Rocq arXiv:2509.18583) routes to **D8**, not here.

Sources: Phases 6BA, 6BB, 6BC. Authorized 2026-06-29; all Lean substrate, kernel-pure, zero project-local axioms. **On-disk scaffolding (`scripts/bundle_registry.py` record, `papers/D10/`) executes at first content-lift** per `BUNDLE_LIFT_PROCEDURE` — not at authorization time (avoids standing up an empty bundle).

**Paper D11: Kernel-Verified Topological Band Theory & Metamaterial Substrate**

Target: *PRD* / *PRX Quantum* / *PRB* / *Comm. Math. Phys.* Length: ~40pp. **Authorized 2026-06-29** per Pipeline Invariant #14 (defensive-publication posture).

Content: the verified topological- and metamaterial-band-theory stack, in four kernel-pure threads: (i) **topological band theory** (Phase 6CA): a genuine **integer-valued lattice Chern number** on a discrete Brillouin torus via the Fukui–Hatsugai–Suzuki construction — `latticeChern : ℤ` by construction, with unconditional integrality (`sum_plaquetteArg_eq_two_pi_mul_latticeChern`) and gauge invariance (`latticeChern_gaugeInvariant`), plus the model-independent frame adapter that carries both to any admissible band frame (`blochLatticeChern_integrality`, `blochLatticeChern_rephase`). Chern is `loogle`-confirmed absent from Mathlib (checked 2026-06-29) and is built here. **⚠️ Scope correction, 2026-07-30 (D11 first-lift substrate audit):** this block previously advertised *Berry curvature* and a *bulk–boundary correspondence shipped conditional on a disclosed tracked Prop*. **Neither is in the tree.** `berryCurvature`/`berryConnection` have zero occurrences project-wide (6CA W1's `berryCurvature_def` + gauge-covariance box is still open); no bulk–boundary module and no `H_BulkBoundaryLandmark` Prop exist, so that wave is **deferred, not conditional** — 6CA W3 was never executed. The continuum invariant `C = (1/2π)∫_BZ F ∈ ℤ` is likewise **route-C DEFERRED** (Mathlib has no manifold form-integration, Stokes, de Rham, or Brouwer degree; costed at 4k–15k+ LOC of foundational build). The live status ledger for this thread is `docs/roadmaps/Phase6CA_prime_Roadmap.md` (2026-07-20), **not** the stale `Phase6CA_Roadmap.md` header. D11 must scope thread (i) as finite-lattice FHS Chern + gauge invariance and state the rest as deferred; (ii) **acoustic/phononic band structure** (Phase 6CB): a Bloch–Floquet diatomic acoustic operator and a certified band-gap existence theorem with rational enclosure — we are aware of no prior acoustic Bloch/Floquet formalization in any proof assistant; (iii) **non-Hermitian physics** (Phase 6CD): non-Hermitian Bloch Hamiltonians and exceptional-point degeneracies in-tree (NOT via PhysLib — the non-Hermitian modules import only Mathlib and each other; corrected 2026-07-31) (a defective-eigenvalue criterion — full Jordan normal form not required), PT-symmetry and EP order; (iv) **effective-medium homogenization** (Phase 6CE): the algebraic Maxwell–Garnett effective-permittivity certificate with a constituent-bracket enclosure (NOT Hashin–Shtrikman, which is strictly tighter and is not formalized — corrected 2026-07-31, D11 Stage-13) (the two-scale-convergence path is a documented substrate-stall, avoided). The **2D-class-D SPT/Pin⁺ condensed-matter reframe** (Phase 6CC) — a conditional reframe consuming the existing Pin⁺ ℤ/16 arc, coordinated with the active 5q.G `/goal` — attaches here or to **D2** (the 16-convergence owner) at first lift.

Relationship to siblings: sibling to **D10**; **D2** owns the high-energy 16-convergence that 6CC reframes in condensed-matter language. **Corrected 2026-07-30:** this line previously read "Two deep waves (6CA bulk-boundary, 6CC Pin⁺) ship conditional via disclosed tracked-Prop landmarks." 6CA bulk-boundary was never executed (see thread (i) above) and 6CC is PARKED pending 5q.G's L2, so **neither conditional wave exists**. The accurate statement is stronger than the plan: **D11 as shipped carries zero tracked-hypothesis Props and zero project-local axioms** — every result is unconditional given its explicit mathematical hypotheses.

A fifth thread joined 2026-07-27: (v) **graphene electronic structure** (Phase 6ED, `6E*` series): honeycomb tight-binding in the `blochPauli` d·σ frame, Dirac-point dispersion with explicit remainder bounds, the sublattice Berry phase, and the **Haldane-model concrete Chern witness** through the shipped FHS lattice machinery — the concrete named-lattice completion that thread (i) explicitly deferred (coordinated with 6CA's gated QWZ spike; whichever lands first, the other reuses its instantiation pattern).

Sources: Phases 6CA, 6CB, 6CD, 6CE (+ 6CC reframe → D2 or here), authorized 2026-06-29; Phase 6ED (graphene electronic structure), **authorized into this bundle 2026-07-27**. All Lean substrate, kernel-pure. **On-disk scaffolding executes at first content-lift** per `BUNDLE_LIFT_PROCEDURE`.

**Paper D12: Kernel-Verified Detector & Readout Metrology — From Photon Statistics to Composite Fidelity Ceilings**

Target: *PRX Quantum* / *Quantum* / *Physical Review Applied*. Length: ~35pp. **Authorized 2026-07-27** per Pipeline Invariant #14 (defensive-publication posture per the going-forward origination rule: textbook/published math lives in the public substrate, at full strength, first try).

Audience: quantum-device instrumentation, precision measurement, single-photon/cryogenic detector communities, readout engineering, formal verification (systems-flavor).

Content: the kernel-verified floor-and-ceiling theory of physical readout chains — the layer *beneath* D9's channel/device envelopes — in five kernel-pure layers: (i) **Poisson & Gaussian discrimination floors** (Phase 6EA): the Bhattacharyya/Le Cam universal average-error floor for Poisson discrimination `P_e ≥ (1/4)·exp(−(√N_a−√N_b)²)`, the dark-baseline zero-false-alarm optimum `e^{−N_a}`, kernel-checked **refutations of the folklore `e^{−N_diff}` miss floor** (false-strict against realizable counters at bright baselines AND exponentially fail-open as an average-error screen — the refutation pair is a first-class deliverable), Gaussian threshold-error algebra with two-sided tail enclosures, shot-noise/thinning reference-plane algebra, and the classical↔quantum seam to the Helstrom/Bhattacharyya corpus. **⚠️ Scope correction, 2026-07-30 (D12 first-lift substrate audit):** this parenthetical previously read "first project consumption of the PhysLib POVM / hypothesis-testing substrate," and **both halves were wrong.** (a) The POVM layer consumed is the *project's own* D9-family `QuantumNetwork/HelstromDiscrimination.lean` (`IsBinaryPOVM`, `quarter_sqrtFidelity_sq_le_povmAvgError`) — not PhysLib — so this is a **D12→D9 consumption edge**, not a PhysLib first. (b) PhysLib's hypothesis-testing substrate (`OptimalHypothesisRate`) is **not consumed at all**: the single occurrence in `Detection/` is a docstring explicitly disclaiming it, and the registered kernel no-go `6ea-optimalhypothesisrate-quantum-seam` (verdict `dead`, type-level impossible two independent ways) forbids any D12-facing text from claiming that consumption unless it actually happens. Relatedly, 6EA's **original novelty claim was refuted by a live prior-art sweep** (2026-07-28): Mathlib already kernel-checks a sub-Gaussian Chernoff bound at our own pin, and PhysLib already kernel-checks quantum hypothesis testing — D12 may state the narrowed, knowledge-hedged form only, and two prior-art checks (`RemyDegenne/testing-lower-bounds`; Isabelle/AFP + Coq `infotheo`) are **blocking pre-submission gates** for this bundle; (ii) **filtered-readout floors** (Phase 6EB): ENBW and the matched-boxcar single-shot realizability bound `ENBW·T ≥ 1/2` (Cauchy–Schwarz, with the boxcar equality characterization), NEP reference-plane + quadrature algebra, the `σ = R·NEP·√ENBW` composition, and matched-filter optimality over the admissible class; (iii) **electrothermal detector physics** (Phase 6EC): the linearized voltage-biased bolometer model, ETF loop gain with the stability dichotomy `ℒ > −1` as an iff, the `(1+ℒ)` responsivity correction, and phonon/Johnson bolometric NEP floors — the first electrothermal-device formalization in any prover; (iv) **two-level control** (Phase 6EE W1–W2): the rotating-wave reduction as an explicit-remainder *inequality* (Bloch–Siegert scale, never an equality), signed projected-drive calibration algebra (duration/phase laws, matrix-element suppression), and Kramers degeneracy; (v) **composite readout ceilings** (Phase 6EE W3): end-to-end assignment-fidelity ceilings assembling relaxation + thermal (existing D9-family envelopes) + photon-budget + filtered-noise + detector floors under explicit attribution hypotheses, each ceiling carrying `norm_num` non-vacuity witnesses on both sides. Methodological through-line, inherited from D9 and pushed one layer down the physical stack: the two-layer posture (formula layer Lean-verified; device identification hypotheses explicit and never conflated) + the kernel-only rational-enclosure certification technique.

Relationship to siblings: **D9** owns the channel/network certification layer and the qubit-level readout-window envelopes; D12 owns the physical detection layer beneath them — the stack now descends D6 (logical) → D9 (channel/device) → D12 (physical detection), with D12's ceilings consuming D9's relaxation/thermal envelopes as cited floors and D9 gaining a citable physical floor beneath its device envelopes. **D11** owns the band-theory substrate including Phase 6ED's graphene electronic structure; D12's floors are material-agnostic and cite D11/6ED only for worked material-platform instantiations if included at lift time. **I3** retains the LDP foundations the Chernoff-exponent seam consumes.

Sources: Phases 6EA, 6EB, 6EC, 6EE (`6E*` series head: `roadmaps/Phase6EA_Roadmap.md`). Authorized 2026-07-27; Lean substrate, kernel-pure. **On-disk scaffolding (`scripts/bundle_registry.py` record, `papers/D12/`) executes at first content-lift** per `BUNDLE_LIFT_PROCEDURE` — not at authorization time.

### 2.3 Tier 2 — PRL-style headline letters (3 papers)

Each is four pages, citing flagship + one Tier 1 paper. Each is a stand-alone news-attractor.

**Paper L1: GW170817 Confines the Vestigial-Second-Sound Graviton Identification to One Part in 10¹⁵ of Its Natural Range**

Target: *Physical Review Letters*.

Length: 4 pages.

⚠️ **REWRITTEN 2026-08-15. This entry described a falsification, and the result is not one.**
`natural_range_disjoint_from_ligo_window` was a statement about the two ENDPOINTS χ_vest ∈ {0.1, 10}; the prose read it as an interval disjointness. The GW170817-compatible window is nested strictly *inside* [0.1, 10] and meets it at χ_vest = 1, which satisfies the cap. See `papers/AutomatedReviews/2026-08-14-l1-stage13/L1.md` §3.1/§4.1.

Lede: Volovik identifies the vestigial second-sound mode as the graviton — in arXiv:2601.00639 and arXiv:2410.04392, **not** in the vestigial-gravity note (JETP Lett. **119, 330**, 2024; the "119, 564" this entry previously carried belongs to no paper we could find). On his own de Sitter background the Landau formula gives `s₂ = c` **exactly** — structural, not tunable — and he records GW170817 as satisfied. The χ-dependent speed `c_GW = c·√χ_vest` is **this project's** construction, obtained by transplanting his identification onto the ADW substrate, whose metric-channel susceptibility does not fix χ_vest. GW170817 then confines χ_vest to a window of width 4τ ≈ 1.2 × 10⁻¹⁴ against a natural-range width of 9.9 — narrower by >14 orders of magnitude — while both endpoints are excluded at ~7 × 10¹⁴ by Lean falsifier theorems. The value the datum selects is the value Volovik's own construction already produces, so it **corroborates** him and constrains our substrate.

Why it ships first: stand-alone, four pages, depends on no other paper and on no open Phase-6 closure. ⚠️ Its *rationale* has changed — "clean falsification, news-attractive" no longer describes it, and whether a confinement result is still the right door-opener is an **open portfolio decision reserved for the operator**. The ordering below is unchanged pending that call.

Source: Paper 25 + Phase 6a Wave 2 material.

**Paper L2: Three Generations of Standard-Model Fermions from Modular Invariance — A Machine-Checked Derivation**

Target: *Physical Review Letters*.

Length: 4 pages.

Lede: The number of Standard-Model fermion generations is forced to be a multiple of three by the combination of (i) the chiral central charge `c₋ = 8 N_f` from particle content and (ii) modular invariance `24 | c₋`. The smallest nontrivial solution is `N_f = 3`. The first machine-checked Ext^n_{A(1)}(F₂, F₂) computation through degree 5 (in any proof assistant) backs the algebraic core. Three textbook topology hypotheses (H1/H3/H4) remain pending Lean's algebraic-topology library; each is independently verifiable by a topologist.

Why it ships early: zero project-originated axioms in the algebraic layer; the headline "why three generations" question is broadly recognized; the proof-assistant first is news.

Source: Paper 10 + Phase 5b/5c/5q/5r material.

**Paper L3: Bardeen-Carter-Hawking Four Laws Partitioned by Regime in an Emergent-Gravity Substrate**

Target: *Physical Review Letters*.

Length: 4 pages.

Lede: We give the first machine-checked formulation of the four laws of black-hole mechanics partitioned by regime — Schwarzschild (heats up under accretion, finite-time evaporation) versus ADW-extremality (cools toward extremality, infinite-time near-extremal asymptote) — separated by `M_c = (N_f Λ_UV) / (12π α_ADW)`. The Jacobson-Koike form `T_H(v) = T_H(0) (1 − v²/c_⊥²)` is the structural anchor. The second law follows from Glorioso-Liu SK-EFT entropy-current monotonicity without invoking pointwise NEC. The third law preserves Israel's strong form in the natural Schottky branch but admits Kehle-Unger-style violation in BPS-violating matter sectors.

Why it ships early: Paper 27 is already submission-ready (cleared a 4-pass Stage 13 adversarial review); the regime-partition criterion is genuinely new; the formalization is a "first."

Source: Paper 27 + Phase 6a Wave 5 material.

### 2.4 Tier 3 — infrastructure papers (3 papers)

**Paper I1: Formal Verification at Scale in Theoretical Physics — A Methodology with Worked Cases**

Target: *Computer Physics Communications* or *Physics Reports*.

Audience: physicists *and* formal-verification researchers.

Content: Why machine verification changes what theoretical physics can do — by catching axioms that turn out to be false, by proving conjectures false, by forcing decomposition that surfaces hidden assumptions, by enabling adversarial-review automation. Three concrete worked cases: (1) Aristotle's counterexample to the original FirstOrderKMS axiom (constrained 4/9 components only; all 9 needed); (2) Aristotle's disproof of the gap-solution-bounded conjecture (explicit unbounded-in-G witness); (3) the chirality-wall axiom decomposition (1 opaque axiom → 4 focused topology hypotheses + 1 4+1D gapped-interface assumption with 1+1D and 2+1D evidence). Plus the 14-stage wave execution pipeline; the preemptive-strengthening discipline (six anti-patterns and their detection); sentence-level provenance with cross-paper consistency clusters; the three-layer Python ↔ Lean ↔ Aristotle architecture; the Stage 13 adversarial-reviewer pattern. Critically, this paper is aimed at the physics audience that needs to *believe* formal verification is worth the friction, not just at proof-assistant developers who already do.

Source: Paper 15 + WAVE_EXECUTION_PIPELINE.md + a curated trace of representative reviewer-driven corrections.

**Paper I2: Verified Statistical Estimators and the lean-tensor-categories Library**

Target: *Journal of Open Source Software* or *Computer Physics Communications* (software paper) plus companion Mathlib upstream PRs (Phase 5o Wave 5).

Audience: lattice physics, formal-verification community, mathematical-physics readers needing infrastructure.

Content: First verified jackknife and autocorrelation estimators (with the jackknife-variance-non-negative theorem); the 114-theorem lean-tensor-categories library covering the categorical hierarchy (Pivotal → Spherical → Balanced → Ribbon → Semisimple → Fusion → Modular), Hopf-algebra extensions (QuasitriangularBialgebra, RibbonHopfAlgebra), decidable algebraic number fields (Q(√2), Q(√5), Q(ζ₅), Q(ζ₁₆), Q(ζ₅) extensions, ComputableAdjoinRoot), and concrete instances (SU(2)_k fusion at k=1..5, Ising MTC, Fibonacci MTC, SU(3)_k k=1, 2). Mathlib upstream coordination memo. Reusable for any project needing verified MTC infrastructure (downstream: TPF construction, fault-tolerant-quantum-computing certification, anyonic-gate verification, conformal-field-theory partition functions).

Source: Phase 5c VerifiedJackknife + Phase 5o Wave 5 lean-tensor-categories work.

**Paper I3: Verified Stochastic Calculus for Mathlib4 — Stochastic Integral, Quadratic Variation, Itô's Lemma, and Large-Deviation Foundations**

Target: *Journal of Open Source Software* (primary) or *Computer Physics Communications* (fallback); tertiary fallback is upstream Mathlib4 PR series + community blog post.

Audience: the Mathlib probability working group (Degenne / Marion / Ledvinka / Pfaffelhuber); formal-verification community (Lean / ITP / CPP / FSCD); mathematical-probability-meets-formalization readers; the program's downstream physics consumers (D3 / D5 / E1) that will invoke the `LDPCompatibleSKEFT` typeclass.

Content: First formalization in any proof assistant of (i) the stochastic integral against semi-martingales (`StochasticIntegral`, `ItoIsometry`); (ii) quadratic variation and covariation (`QuadraticVariation`, `Semimartingale`); (iii) Itô's lemma for vector semimartingales (`ItoLemma`); (iv) Novikov's condition and Girsanov sketch (`Novikov`); (v) the foundational large-deviation framework — Cramér-iid + Sanov via method-of-types + contraction principle (`CramerIID`, `Sanov`, `Contraction`); (vi) Cramér lower bound via Esscher tilting + Varadhan-style upper bound (`CramerLowerBound`, `Varadhan`); plus (vii) the `LDPCompatibleSKEFT` typeclass that surfaces LDP-rate-function content in the program's existing SK-EFT Glorioso-Liu monotonicity statements (cross-bridge to D3 / D5 / E1). Companion Mathlib upstream coordination memo documents PR cadence and the coordination plan with the Mathlib probability-theory community (Degenne et al. on Brownian motion + Markov kernels). Builds on the recently-completed Mathlib Brownian-motion (Degenne, Ledvinka, Marion, Pfaffelhuber, "Formalization of Brownian motion in Lean", arXiv:2511.20118, 2025), Doob martingales (Ying–Degenne 2022), and Markov kernels (Degenne, "Markov kernels in Mathlib's probability library", arXiv:2510.04070, 2025) substrates — the latter primary-source-verified Phase 7 absorption Session 5 2026-05-08, superseding the carry-forward "Marion arXiv:2510.04070" misattribution; closes the four-to-five-module gap (stochastic integral / semimartingale / Itô / Novikov / Stratonovich) those substrates leave.

Source: Phase 6n Session 4 I3 bundle authorization (Pipeline Invariant #14) + Phase 6o.ζ Lean module synthesis (no per-paper substrate; analogous to I2's lean-tensor-categories framing). Source manifest at `temporary/working-docs/phase6n/i3_bundle_scoping.md`.

### 2.5 Tier 4 — experimental letters (2 papers)

**Paper E1: A Falsifiable Hawking Spectrum for Polariton Microcavities at the Paris LKB Device Parameters**

Target: *Physical Review Letters* (Letter), *Physical Review Research*, or as an extended cover-letter document.

Length: 2–3 pages.

Audience: the Paris LKB polariton-Hawking experimental team (Falque / Bramati / Giacobino) primarily; broader analog-gravity-experimental community secondarily.

Content: The SK-EFT predicted Hawking spectrum and noise floor `n_noise = δ_k / 2` evaluated at the Paris-LKB device's published parameters. Signal-to-noise estimate for spontaneous detection at their cavity Q. Stimulated-Hawking amplification factor for stimulated-mode runs. The falsifiable frequency window where the SK-EFT noise-floor formula makes the cleanest prediction. A request for current device-parameter values to allow band-tightening.

Sources: Phase 5u Wave 21 (the new wave appended 2026-04-28); Paper 12 main material.

**Paper E2: Detecting Analog Hawking Radiation in the Bilayer-Graphene Dirac Fluid**

Target: *PRL* or *Physical Review Research*.

Length: 2–3 pages.

Audience: the Dean group (Columbia, sonic-horizon realization 2025); the Kim group (Harvard, noise thermometer); the Lucas group (theoretical noise-spectroscopy framework); broader graphene-electronic-Dirac-fluid community.

Content: T_H ≈ 2.4 K predicted for the Dean bilayer nozzle (10⁹× BEC). Negligible dissipative correction (δ_diss ~ 10⁻¹³, 11 orders below dispersive δ_disp ~ −3%). Wiedemann-Franz violation L/L₀ > 200× from two-channel transport. Closed-form noise-spectrum prediction `ΔS_I(ω) = 2ℏω σ_Q Γ(ω) n_H(ω)` from Keldysh FDT + Landauer-Büttiker. Bandwidth-cumulative SNR = 1 in ~1 minute at the Dean device. Principal device-specific uncertainty: greybody factor `Γ(ω)`.

Sources: Phase 5w material; Paper 16a main content.

---

## 3. Sequencing — order of submission and dependencies

The order matters. Three principles:

1. **Clear the arXiv-voucher gate with the easiest stand-alone PRL.** L1 (GW170817 vs vestigial-graviton) is the strongest candidate on STRUCTURE — stand-alone, no Phase-6 dependency, fits in 4 pages, news-attractive, doesn't require any other paper to be out, doesn't depend on uncertain content.

2. **Tier 1 papers ship before Tier 0.** The flagship cites the Tier 1 papers; trying to write the flagship without them done is a snapshot. Tier 1 papers ship roughly in parallel after the voucher, with priority weighted toward shipping-ready material.

3. **Experimental letters ship paired with their Tier 1 anchor.** Tier 4 letters are most useful when the experimental team can simultaneously read the formal Tier 1 #1 paper (analog Hawking) for full backing.

Recommended sequence (approximate, conditional on user-authorization gates and Phase 6 closure of dependent waves):

- **Month 0:** L1 (GW170817 / vestigial-graviton). Voucher cleared.
- **Month 1–2:** L3 (BCH four laws by regime — Paper 27 already submission-ready), D3 (emergent gravity through BH thermo — absorbs L3's content as a section + adds the architectural context). These can ship in close succession; L3 as the splash, D3 as the deep companion.
- **Month 2–3:** L2 (three generations from modular invariance) + D2 (anomaly constraints on SM particle content). Same pattern: splash + deep.
- **Month 3–4:** D1 (analog Hawking across three platforms) + E1 (Paris LKB letter) + E2 (Dean-Kim-Lucas letter). Three publications same window because they reinforce each other and reach distinct experimental teams.
- **Month 4–5:** D4 (topological quantum computation foundations).
- **Month 4–6:** I1 (methodology) + I2 (lean-tensor-categories + verified statistics). Aligned with Phase 5o Wave 5 Mathlib upstream cycle.
- **Month 5–8:** D5 (dark sector). Ships after Phase 6m Tracks A/B/C return verdicts (estimated ~4–6 months from now). The paper is much stronger as a closed predictive-scope statement than as a partial Volovik-only closure.
- **Month 8–12:** F (flagship). Drafted incrementally throughout the roll-out; final form benefits from cross-citation of Tier 1 papers and the Phase 6m closure.

Twelve months from voucher to flagship is the rough envelope. The Phase 6 deep-research dispatches (six per Track in Phase 6m, plus the Phase 6j-6l Wave-1 dossiers) operate in parallel.

### Dependency graph (compressed)

- L1 has no dependencies; ships first.
- L3 ships after Paper 27 Stage-13 closure (already done) + arXiv voucher (from L1).
- L2 ships after L1 voucher; depends on no Phase-6 closure.
- D3 depends on L3 content + Phase 6d Track A closure (already shipped) + Phase 6a closure (already shipped). Ready.
- D2 depends on L2 content + the Phase 5b/5c chain (already shipped). Ready.
- D1 depends on Phase 5w closure (already shipped) + Phase 5d/5u closure (already shipped) + the WKB chain (already shipped). Ready.
- D4 depends on Phase 5b–5p categorical chain (already shipped) + Phase 5t doublon-gate (already shipped). Ready.
- D5 depends on Phase 5y closure (shipped) + Phase 6m Tracks A/B/C closure (in progress). Blocked on Phase 6m.
- F depends on D1–D5 + I1 + I2 + L1–L3 all shipped.
- I1 has no dependencies; can ship any time.
- I2 depends on Phase 5o Wave 5 Mathlib upstream cycle in progress; ships when first Mathlib PR is in review.
- E1 depends on D1 ready + Phase 5u Wave 21 cover-letter draft.
- E2 depends on D1 ready + Phase 5w material.

The critical path is L1 → voucher → everything else. The slowest path is Phase 6m → D5 → F. The flagship lands roughly when Phase 6m closes.

**⚠️ Status note — CORRECTED 2026-08-15. The 2026-05-07 note this replaces was false, and it was the sentence a reader planned from.** It said: *"All 14 bundles have shipped Stage 9 + Stage 10 + Stage 13 reviewer triples GREEN … the critical-path L1 → voucher gate is the only remaining program-level blocker."* Measured against `BUNDLE_READINESS_HEATMAP.md` on 2026-08-15: **0 GREEN, 4 YELLOW, 17 RED, 1 UNMEASURED across 21 bundles** — and the roster is 21, not 14. There were **209 open blocking findings on the submission bundles** (plus 518 on legacy `paperNN` source drafts), with `FixPropagation` blocking 58 of 64 papers.

Two lessons are worth keeping over the number itself. First, the note aged into a fiction because it stated a *census* in a narrative — the failure `CLAUDE.md` architecture rule 3 exists to prevent; the live figures belong in the heatmap and `SURFACE_INVENTORY.md`, and this note should say where to look rather than what the count is. Second, part of that 209 was never real: 34 of them were false positives from a checker that asserted `\bibitem` presence as a proxy for whether a citation resolves, which is wrong for every BibTeX draft (retired 2026-08-15, commit `d39d2ffb`).

**For current state, read `BUNDLE_READINESS_HEATMAP.md` and `docs/architecture/PUBLICATION_PORTFOLIO_MAP.md`, not this document.** The sequencing above is still the intended order; the readiness claims are not current.

---

## 4. Cross-cutting principles

**NO-GOs are first-class.** Every Tier 1 deep paper that contains a structural NO-GO presents it as a result, not a footnote: D3 with vestigial-graviton + perturbative-Wen-ADW + non-Abelian-gauge-erasure + fracton-GR; D5 with q-theory + vestigial-graviton-cross-bridge + Fang-Gu + abelian-MTC-horizon. The flagship's §2 (architectural scope) and §10 (scope statement) explicitly section the predictive boundary. This is a deliberate communication choice; the program's negative content is unusually high-quality and deserves visibility.

**The methodology paper aims at physicists.** I1 is *not* primarily a formal-verification-community paper. The audience is the theorist who currently does not believe machine verification is worth the friction. The argument is empirical: here are three concrete cases where verification produced physics that would not otherwise exist. The formal-verification audience consumes I2 (the software paper) and the Mathlib upstream PRs.

**Every paper carries the scope statement.** Each paper includes (in the discussion or as a sidebar) the relevant slice of `ARCHITECTURE_SCOPE.md` — what this paper claims to predict, and what is explicitly outside the tested predictive scope under the mechanisms exercised here. This insulates each paper against implicit-overclaim review findings (e.g., "this paper says the substrate gives gravity but doesn't say anything about dark energy — is that an oversight?").

**Sentence-level provenance survives the rebundling.** The Phase 5v/Phase 6i sentence-state infrastructure (`prose_state.json`, `audit_log.jsonl`) tracks each sentence's claim cluster, primary source, and Lean theorem backing. When existing Paper 11 content lifts into D4, the sentence-level metadata moves with it — no claim becomes orphaned, no Lean reference rots. Phase 6i Wave 7 wires this re-mapping into the QI process.

**Adversarial review continues per bundle.** Stage 13 adversarial review applies to the new bundles, not just the old per-wave drafts. Each bundle gets at least one full-pass review before submission, with a pre-submission re-invocation pass after any substantive revision. The reviewer prompts are updated to know the bundle architecture.

**The flagship can be re-released.** RMP-style reviews are typically updated every few years. The flagship is designed for re-release: append-only sections covering Phase 7+ as the program continues, while the structural backbone (architecture, scope, methodology) stays stable.

---

## 5. Open questions and risks

**Will the experimental teams cooperate?** Tier 4 letters (E1, E2) are most useful when the experimental teams find them actionable. The Paris LKB group has the most engaged track record on polariton-Hawking; Dean-Kim-Lucas have the device but no announced Hawking-detection program. E1 has a higher probability of catalyzing measurement; E2 may end up more of a "Theory has the prediction; experimentalists have the device; here's how they meet" position paper. Both are worth shipping; the latter is hedged.

**Will Mathlib accept the lean-tensor-categories upstream?** I2's joint-paper structure assumes the Mathlib PR cycle (Phase 5o Wave 5) lands at least the first atomic PR (QSqrt2 + ComputableAdjoinRoot bridge) within the I2 timeline. If Mathlib's AI-content policy delays merging beyond ~6 months, I2 ships as a software-only paper without the Mathlib-acceptance hook; the upstream cycle becomes a separate JOSS update later.

**Will Phase 6m return all-NO-GO across Tracks A/B/C?** D5 (dark sector) is much stronger if it ships as a closed predictive-scope statement covering Volovik *and* the three new mechanism families. If any one of Tracks A/B/C returns PARTIAL-VIABLE, D5 still ships, but the framing changes from "dark-energy sector outside scope under tested mechanisms" to "dark-energy sector is a multi-mechanism landscape with one viable substrate-derived candidate." Both versions are publishable; the framing is determined by the closure outcome.

**Should D4 be split?** The longest-verified-mathematical-chain content has natural sub-audiences: the categorical-MTC/quantum-group content fits a *Communications in Mathematical Physics* split, while the Fibonacci-universality + doublon-gate content fits *PRX Quantum*. A single D4 paper is recommended for first publication (more impact unified), but a split into D4a (math-physics) + D4b (quantum computation) is acceptable if reviewer feedback during the bundle's Stage 13 strongly recommends it. The decision is deferred to the bundle's Stage 1 scoping.

**What about HepLean coordination for D2?** The anomaly-constraints paper (D2) and the latent Phase 6k Wave 4 (CKM apex substrate constraint) both touch HepLean's territory. Coordination is required: D2 should reference HepLean's CKM catalog where relevant, and Phase 6k Wave 4 will consume HepLean's CKM API once the Mathlib coordination work establishes the relationship-channel. D2 itself does not depend on Phase 6k.

**What if a striking new result lands during the roll-out?** The architecture is intentionally append-friendly. A new Tier 2 PRL splash can be added if a Phase 6 wave produces a 4-page-PRL-shaped headline (e.g., a Phase 6m Track returning VIABLE with a specific substrate-realization, or a Phase 6h activation if Gate Z.4 flips). The flagship's outline accommodates incremental additions.

**Citation hygiene infrastructure (2026-05-07 status).** The 51-PDF primary-source backfill cycle ran during Phase 7 absorption Session 5 (264 cached / 0 missing as of 2026-05-08). Primary-source WebFetch + verify is now standing project policy: when a numerical magnitude in a Lean constant, paper claim, or registry entry is registry-anchored or unverified, the primary-source PDF is fetched and the claim verified before publication-grade prose relies on it. This protocol surfaced the Luciano arXiv:2506.03019 Table II AIC-vs-Bayes methodology mislabel + the `BelgiornoCacciatori2024` hallucinated-citation cache entry during Session 5, and is the standing safeguard against bibitem-title fabrication for the remainder of the publication roll-out.

---

## 6. Summary table

| Tier | Paper | Title (short) | Target | Length | Ships | Dependencies |
|---|---|---|---|---|---|---|
| 2 | L1 | GW170817 / vestigial-graviton | PRL | 4pp | Month 0 | (voucher gate) |
| 2 | L2 | Three generations from modular invariance | PRL | 4pp | Month 2–3 | L1 voucher |
| 2 | L3 | BCH four laws by regime | PRL | 4pp | Month 1–2 | L1 voucher |
| 1 | D1 | Analog Hawking across three platforms | PRD long | ~40pp | Month 3–4 | L1 voucher |
| 1 | D2 | Anomaly constraints on SM | PRD/JHEP | ~30pp | Month 2–3 | L1 voucher |
| 1 | D3 | Emergent gravity through BH thermo | PRD long | ~50pp | Month 1–2 | L1 voucher |
| 1 | D4 | Topological QC foundations | PRD/PRX-Q | ~40pp | Month 4–5 | L1 voucher |
| 1 | D5 | Dark sector under substrate constraints | PRD/Phys Rep | ~40pp | Month 5–8 | Phase 6m closure |
| 1 | D6 | FT-QC substrate (gauging-QEC + SK + APM-LDPC + W-state) | PRD/PRX-Q/JHEP | ~40pp | Month 6–9 | Phase 6v Waves 6v.1, 6v.2, 6v.5, 6v.6 ship; consumes D8 SK primitive |
| 1 | D7 | Classical simulability ↔ quantum advantage (tensor-network demarcation) | PRX-Q/PRX | ~40pp | Month 6–9 | Phase 6w Waves 6w.1–6w.6 ship |
| 1 | D8 | Universal quantum gate compilation (alphabet-agnostic SK across SU(d) + Toffoli bounds) | PRX-Q/Quantum | ~45pp | Month 5–9 | Phase 6p/6t/6u/6x/6x′/6y/6z ship (all complete); L1 voucher |
| 1 | D9 | QN + device-characterization certification substrate (diamond program + entropy corpus + network/readout envelopes) | PRX-Q/Quantum | ~40pp | Month 6–10 | Phases 6AA–6AL + 6AM/6AN/6AP/6AQ ship (all complete); defensive-pub posture |
| 1 | D10 | Comp-chem & open-system foundations (NEGF + Hohenberg–Kohn DFT + Lindblad) | PRD/PRX-Q | ~40pp | (after phase exec) | Phases 6BA/6BB/6BC; **authorized 2026-06-29**, scaffolding at first-lift |
| 1 | D11 | Topological & metamaterial band theory (**finite-lattice FHS Chern** — bulk-boundary DEFERRED, see §2.2 — + phononic gaps + non-Herm/EP + Maxwell–Garnett + graphene band structure) | PRD/PRX-Q/PRB | ~40pp | (after phase exec) | Phases 6CA/6CB/6CD/6CE (+6CC→D2 or here); **authorized 2026-06-29**; +6ED (graphene/Haldane) **2026-07-27**; scaffolding at first-lift |
| 1 | D12 | Detector & readout metrology (Poisson/Gaussian floors + ENBW/NEP/matched filter + electrothermal + control + composite ceilings) | PRX-Q/Quantum/PRApplied | ~35pp | (after phase exec) | Phases 6EA/6EB/6EC/6EE; **authorized 2026-07-27**, scaffolding at first-lift |
| 3 | I1 | Methodology | CPC/Phys Rep | ~25pp | Month 4–6 | (none) |
| 3 | I2 | Verified estimators + lean-tensor-categories | JOSS/CPC | ~15pp | Month 4–6 | Phase 5o W5 |
| 3 | I3 | Verified stochastic calculus + LDP foundations for Mathlib4 | JOSS/CPC | ~15pp | Month 5–7 | Phase 6n W2c IsLDPRateFunction + Phase 6o W3b lift |
| 4 | E1 | Polariton experimental letter | PRL/PRR | 2–3pp | Month 3–4 | D1 ready + Phase 5u W21 |
| 4 | E2 | Graphene Dirac-fluid letter | PRL/PRR | 2–3pp | Month 3–4 | D1 ready |
| 0 | F | Flagship review | RMP/Phys Rep | 80–150pp | Month 8–12 | All above |

Twenty-one publication targets (1 flagship + 12 Tier 1 deep + 3 Tier 2 PRL + 3 Tier 3 infrastructure including I3 + 2 Tier 4 experimental). Approximate twelve-month roll-out from voucher. The flagship is the citation anchor. (The figure was previously stated as "thirteen" before I3 authorization in Phase 6n Session 4 under Pipeline Invariant #14, "fourteen" before D6 authorization in Phase 6v Wave 6v.1, "fifteen" before D7 authorization in Phase 6w Wave 6w.6 — 2026-05-26 PM conditional-authorization trigger per generality-criterion satisfaction — "sixteen" before D8 authorization 2026-05-31 — consolidating the verified-compilation corpus that had outgrown the D4 §9.x showcase — "seventeen" before **D9 authorization 2026-06-10** (QN + device-characterization certification substrate), "eighteen" before the **D10 + D11 authorizations 2026-06-29** (public computational-chemistry / open-system substrate, Phases 6BA–6BC; topological & metamaterial band theory, Phases 6CA–6CE) — "twenty" before the **D12 authorization 2026-07-27** (kernel-verified detector & readout metrology, Phases 6EA/6EB/6EC/6EE of the `6E*` series; Phase 6ED simultaneously joined D11's sources as its concrete graphene band-structure thread) — and "eleven" in v1 of this table — all are superseded by the present twenty-one-target architecture. **D10/D11/D12 on-disk scaffolding (the `scripts/bundle_registry.py` record, `papers/D10`+`papers/D11`+`papers/D12`) is deferred to first content-lift per `BUNDLE_LIFT_PROCEDURE`** — the roster authorization is recorded here; the empty bundles are not stood up until they have source content.)

---

## 7. Cross-references

- **Draft mapping:** `PAPER_DRAFT_MAPPING.md` — explicit per-draft → per-bundle assignment for each of the 32 existing drafts.
- **Phase 6i Wave 7:** Paper Strategy Integration into the QI review process; updates Stage 13 reviewer prompts, sentence-level-provenance bundle assignment, and cross-paper consistency clusters.
- **Pipeline:** `WAVE_EXECUTION_PIPELINE.md` — the 14-stage process per wave; per-bundle Stage-13 adversarial-review re-invocation is defined in Phase 6i Wave 7.
- **Architecture scope:** `ARCHITECTURE_SCOPE.md` — Layer-3 predictive-boundary statement; lifted into the flagship's §2 + §10.
- **Research status:** `RESEARCH_STATUS_OVERVIEW.md` — the snapshot inventory of proven chains, open targets, and NO-GOs that the bundles consolidate.
- **Phase roadmaps:** `roadmaps/Phase{1..6}*_Roadmap.md` — per-wave execution plans whose deliverables flow into the bundles.
- **Module census:** `docs/MODULE_CENSUS.md` — module-level ground truth for Python, derived from docstrings.
- **Knowledge graph:** `KNOWLEDGE_GRAPH.md` and the provenance dashboard's KG tab — the cross-paper claim-cluster infrastructure that survives the re-bundling.

---

*Created 2026-04-28. Active strategy document. Updates atomically as bundles ship and Phase 6 waves close.*
