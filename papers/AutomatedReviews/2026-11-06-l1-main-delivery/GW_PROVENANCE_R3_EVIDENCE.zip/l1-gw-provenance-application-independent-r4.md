# Independent actual-application R4: ACCEPT within narrow provenance scope

Candidate base: `e301c7b9a6dc315153b48c5daa251b5ff1e502de`. Actual [provenance source](/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking/src/core/provenance.py) SHA256: `301d9db0be7404cb44834233eb7847d2eee3a14283298abcb6ddab11057b5983`.

**ACCEPT** the actual six-entry metadata and existing-writer application at that hash. Initial and final checks of the same R4 packet both returned `fresh=true, changed=[]`. This resolves the final-packet freshness condition for this review. The earlier R3 drift reports are preserved; they are not overwritten or recast as fresh.

## Independent comparisons

I replayed the accepted patch in memory against `/tmp/l1-gw-provenance-actual-preimage-r3.py` (SHA256 `eba5b4ed81cd21fba3ce78d281d3af60224a94c035dc36afadfb348087dc31ae`) and verified exact equality with the accepted metadata after-image. I reran the independent selected-entry AST, registry-order, numeric-token and unselected-source-byte checks on those preimage/after-image files, including exact correspondence to the proposal JSON. I rechecked all six accepted writer operations and their complete historical notes against the fixture, with no repository writer execution. The actual file is byte-for-byte identical to the entire independently accepted fixture, not merely AST-equivalent.

Consequently, actual lower/upper/default/gamma entries have the four intended FLAGGED notes while their null dates stay null; peak/probe have the intended REJECTED historical automatic-verification withdrawal notes and null dates. All complete previous human notes remain verbatim with their dates marked historical. No approval is granted. All values/numeric literal spellings, DOI/LLM historical records, registry order, unselected entries and unrelated source bytes are preserved. The writer's flattening of the two old parenthesized human-note literals is confined to the intended changed fields and exactly matches the accepted fixture. The R4 packet records only `src/core/provenance.py` as changed. No other source or notebook was edited by this reviewer.

Scientific interpretation remains the [independent proposal assessment](/tmp/l1-gw-provenance-independent-r3.md): the three chi entries are adopted inputs for the assumed normalized law; gamma is an unmatched numerical coefficient multiplied by the probe once; 100 and its alias are adopted probes, without an established measured scalar peak-strain attribution in the inspected detection body. The qualified Vergeles lattice-unitarity body and actual Lean/Python definitions support the factual correction, not a physical response construction. Human operations neither endorse the old assertions nor reject use of the numerical probe.

Pins: accepted patch SHA256 `28223731243ea2278a5ea298aebb8ced2c7814493e0896d88f81727b3d677e0c`; human-operations SHA256 `efbc4091ce12b0d189a63281ea144781f93f57114e795212cf3bf87593648b89`.

## Validation limits and acceptance boundary

I read the terminal receipts rather than running gates. Focused tests report **109 passed in 0.84s**. The scoped canonical run is **FAILED**, reporting **87 failed, 6687 passed, 42 skipped, 92 deselected and 30 errors**; architecture inventory and counts freshness failed, module census passed. Its self-dirty result also failed because the run generated counts output; ROOT reports preserving that output off-tree and restoring the original generated file. The fresh R4 packet's tracked-change snapshot is consistent with that restoration. No global gate is accepted.

The failed-slice log/XML reproduces 87 failures and 30 errors. I independently parsed candidate and baseline XML: exactly the selected 24 nonnative citation/cache/serializer cases have the same failure outcome, with zero outcome differences. The baseline JSON identifies an exact pre-change metadata replay and restoration to the actual hash. This bounded evidence establishes unchanged outcomes for those 24 cases only; the other **93 failed/error cases remain unqualified**. Neither full-suite nonregression nor full project/publication acceptance follows. I did not assess any moving run, run tests/native tools, or change source/Git/DB/graph/runtime state.

No manuscript/catalog change or canonical closure is accepted here. The known `sentence:L1:formal-setup-and-result:b81984d5` remains UNGROUNDED. Original physical B3 response/normalization/window, positive physical state, tensor mode, same matter/light reference and coupling, microscopic transport, frequency convention and coefficient-unit matching, and a nonempty error-controlled band remain full BUILD. Open human review/closure remains open. ROOT retains final application acceptance, handling of failed gates, manuscript propagation and archive ownership. This narrow ACCEPT authorizes no readiness or publication claim.

Final same-packet check: **fresh=true, changed=[]**, task `l1-gw-provenance-application-review-r4`.
