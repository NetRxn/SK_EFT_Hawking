# R3 narrow provenance proposal — author handback, not acceptance

Candidate: `e301c7b9a6dc315153b48c5daa251b5ff1e502de`. Packet: `l1-gw-provenance-proposal-r3.json`. FIRST packet check was fresh. ROOT is the sole candidate writer. The patch is off-tree and changes only 24 metadata fields across the six assigned entries in `src/core/provenance.py`. No repository file was edited. No source writer, gate, project test, native proof/build, DB/graph, Git or slot action was run. The existing writer was exercised only against a `/tmp` copy under the primary checkout's existing Python environment.

## Scientific disposition

| Registry key | Value preserved | Proposed tier | Corrected interpretation |
|---|---:|---|---|
| `GW.CHI_VEST_NATURAL_LOWER` | 0.1 | PROJECTED, unchanged | Adopted comparison-window endpoint of free normalized dimensionless response |
| `GW.CHI_VEST_NATURAL_UPPER` | 10.0 | PROJECTED, unchanged | Adopted comparison-window endpoint; larger responses are not physically excluded by this adoption |
| `GW.CHI_VEST_DEFAULT` | 1.0 | PROJECTED, unchanged | Chosen exactly luminal anchor; no microscopic selection |
| `GW.GAMMA_H_VESTIGIAL_DEFAULT` | 1.0e-30 | PROJECTED, unchanged | Numerical coefficient BEFORE the helper multiplies by the probe exactly once |
| `GW.GW170817_PEAK_FREQ_HZ` | 100.0 | PROJECTED, formerly MEASURED | Legacy name for adopted numerical probe; scalar measured 100 Hz peak-strain attribution unestablished by inspected source |
| `GW.GW_FREQ_HZ_PROBE` | 100.0 | PROJECTED, formerly DERIVED | Exact operational alias of that adopted probe; no derivation from a measured parameter |

The two tier changes are **FACTUAL provenance corrections**, not a physical scope escape. `DERIVED` in the registry means computed from measured values; aliasing a project input establishes equality but does not turn it into a measured-derived quantity. The adopted probe itself is not refuted. A chirp's instantaneous frequency, Fourier-domain strain maximum, noise-weighted SNR maximum and detector-noise sensitivity minimum are different quantities. No claim that every definition of “peak at 100 Hz” is false follows from this audit.

The old `dimensionless (× Λ²)` units and purported resulting one-loop normalization are replaced by the assumed normalized dimensionless response actually passed to `c_GW=c*sqrt(chi_vest)`. The current RPA input values and their physical metric-channel normalization are unevaluated. Its algebra supplies no selected number or interval. The separate companion `alpha_ADW` is not `chi_vest`; equality of selected comparison endpoints or fiducials proves no coefficient identity. The old lower-endpoint fine-tuning assertion and upper-endpoint physical exclusion are unsupported by merely adopting a window.

The gamma metadata previously included the probe in its claimed coefficient unit, whereas `src/core/formulas.py:8609` returns `gamma_h_dimensionless * omega_hz / 1.0`. Current docstrings explicitly describe an illustrative numerical product with physical normalization unmatched. `GravitationalWaves.dispersion_correction` is a free-real product. `SecondOrderSK.GammaH` is a different acoustic horizon damping rate, with stated units s^-1; identifying it with a metric-channel coefficient divided by a speed squared is not established. The legacy API labels, keys, values and numeric assertions remain unchanged.

## Direct evidence and limits

1. Actual current L1 body was read, including the abstract, assumed law, prior literature comparison, RPA paragraph, endpoint/compatible-interval construction, physical scope, Discussion, companion comparison, supporting predicate/product appendix and bibliography. The abstract states: “Microscopic mode, normalization and range are not derived; only this kinematic model is constrained.” The appendix calls `omega=100` a formal real-number probe and states that interpreting it as 100 Hz requires frequency convention and normalization. Those are scope disclosures, not physical evidence for a range.
2. `lean/SKEFTHawking/VestigialSusceptibility.lean:99` defines `bubble_integral=(log(Lambda^2/r_e)-1)/(16*pi^2)`. `W6Ext.chi_RPA` defines `chi_0/(1-gamma_star*chi_0)`; its closed-form identity assumes nonzero denominator and its positivity result assumes positive bare response and stable coupling. None selects the physical normalized metric response or its [0.1,10] window. This is source/type/proof-body reading, not fresh kernel execution or a general absence claim about the repository.
3. **Vergeles local PDF**, `Lit-Search/Phase-5d/primary-sources/Vergeles2025.pdf`, arXiv:2506.00036v2, 24 Sep 2025, retained DOI `10.1103/PhysRevD.112.054509`. Its abstract explicitly limits its proof to lattices conserving the number of degrees of freedom. Sec IV, Statement 3: “The operation of time evolution (3.9) is unitary and it preserves the class of functions on which unitarity is proven”. Eqs (4.8)–(4.10) use the Hermitian operator/eigenbasis and phases. The degree-changing discussion in Sec V requires `F{V1}=const` in Eq (5.7) and says: “Unfortunately, we do not know how to prove Eq. (5.7) at present.” Thus the retained DOI supplies qualified lattice-unitarity context, not the physical susceptibility range. No universal positive physical state, tensor mode or source matching is inferred.
4. **Abbott detection local published PDF**, `Lit-Search/Phase-1-and-Background/primary-sources/Abbott2017GW170817Detection.pdf`, PRL 119,161101, published 16 Oct 2017, retained DOI `10.1103/PhysRevLett.119.161101`. This is the detection paper, distinct from the ApJL 848,L13 speed-bound paper. Sec I p161101-2 describes approximately 100 **seconds**, starting at 24 Hz, not a scalar 100 Hz peak. Fig1 p2 says: “The amplitude scale in each detector is normalized to that detector’s noise amplitude spectral density.” Sec IV p4 says: “As the orbit shrinks and the gravitational-wave frequency grows rapidly,” and reports Bayesian analysis in the “30–2048 Hz” range. Fig2 p3 displays a noise glitch, with waveform strain too small to see in its bottom panel; it does not supply a peak-strain estimate. TableI reports masses, distance, angle, tidal deformability and related source properties, not that peak quantity. SecV.B pp7–8 discusses searches up to 4kHz and no postmerger signal evidence; SecV.C refers propagation tests to the distinct multimessenger paper. These are positive body/figure/table qualifications. The claimed measured scalar 100Hz peak remains unestablished by this source, rather than factually contradicted solely by a keyword search.

Both PDF SHA256 pins and exact pre/post metadata records are in the JSON. The original DOI, LLM date and full LLM notes remain byte-for-byte in the base patch as **history**, not a renewed endorsement of their old assertions. No new verification stamp is introduced.

## Surviving manuscript statement: immediate factual repair still owed

Current exact canonical sentence: `sentence:L1:formal-setup-and-result:b81984d5`, current TeX lines159–164, currently **UNGROUNDED**:

> The natural range
> $\chivest \in [0.1, 10]$
> is an \emph{adopted} naturalness window: the one-loop bubble
> normalization is $\mathcal{O}(\Lambda_{\rm UV}^2/16\pi^2)$ by
> dimensional analysis, where $\Lambda_{\rm UV}$ is the ultraviolet cutoff, and we take the $\pm 1$-decade window about
> the resulting unit-normalized central value.

Proposed immediate replacement, for a separate ROOT-owned manuscript edit and independent review:

> We adopt the comparison window $\chivest\in[0.1,10]$, centered geometrically on the chosen exactly luminal anchor $\chivest=1$. Neither the RPA identity nor dimensional analysis determines the physical normalization, center or endpoints. Constructing the physical metric-channel response, including its normalization and domain, and establishing the susceptibility window from the microscopic theory remain required.

This is an immediate **FACTUAL prose-attribution correction**. It does not derive or cancel the original target: physical O(Lambda²/16pi²) normalization and [0.1,10] as a computed result remain full BUILD. The six-entry metadata proposal does not edit TeX or the claims catalog, cannot close the existing UNGROUNDED assessment, and does not claim source propagation complete. It does not use that unsupported paragraph as physical evidence.

## Proposed existing-writer operations, separate from base patch

The JSON's `human_writer_operations` contains four `annotate_human_verified` calls for lower/upper/default/gamma and two `withdraw_human_verified` calls for peak/probe. The latter withdraw the historical **automatic** approval of a source attribution the cited body does not establish. This is not rejection of a genuine operator sign-off: the actual prior note explicitly says “auto-flipped after categorization sweep.” ROOT and the independent reviewer must assess this source qualification before applying those recommendations. If they choose to retain either approval pending operator disposition, the existing `annotate_human_verified` operation is available to persist the concern while leaving the date unchanged; that alternative must not be described as withdrawal.

All full old notes are embedded verbatim in proposed replacement notes with their old dates explicitly marked historical. Original preimages also remain in JSON and source history. No operation calls `set_human_verified` or grants a human date. The base patch touches no human field at all. Fixture operations alone produce six null human dates, preserving all other field values. The existing writer implementation is untouched.

## Concrete human review card

The eventual operator can review whether 0.1,10,1 and 1e-30 are accurately recorded as **adopted inputs** under the assumed normalized speed law and illustrative product; whether the real-number probe100 and its alias accurately record code conventions; and whether original historical source context and uncertainty are stated honestly. Reviewing those statements supplies no approval of a derived physical range or a physical realization.

The physical response normalization and window, positive physical state, propagating tensor mode, coupling to the same matter/light reference, microscopic transport, ordinary/angular frequency and unit matching, and a nonempty controlled band with error bounds remain required. Original L1 B3 and related physical acceptance duties remain full BUILD. Their acceptance is separate from this human metadata review.

## Preservation and bounded verification

AST verification on off-tree before/after images established the same registry key order/count, unchanged numeric literal spelling and values, exact DOI/LLM date/LLM notes and human fields, and unchanged unselected entries. The patch replaces only `unit`, `tier`, `source`, `detail`, `notes` string values; every other source byte is conserved by construction. The JSON contains exact changed-field lists and complete selected preimages. The source writer, formulas, constants, Lean bodies, tests, claims catalog and all other repository files are unmodified.

Existing writer fixture: all six proposed operations succeeded in dry run and actual `/tmp`-fixture mode using `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.venv/bin/python`. `PROVENANCE_PATH` was explicitly redirected to `/tmp/l1-gw-provenance-proposal-r3.writer-fixture.py`. Only human notes and the two selected old automatic dates changed in that fixture; all other fields remained exact. This is a writer compatibility check, not a project gate, native qualification or independent scientific acceptance.

Deliverables: `/tmp/l1-gw-provenance-proposal-r3.patch`, `/tmp/l1-gw-provenance-proposal-r3.md`, `/tmp/l1-gw-provenance-proposal-r3.json`. Additional off-tree after-image and fixture are included for reviewer comparison. ROOT must independently review, apply the narrow metadata change, use the existing writer for accepted human-field operations, propagate the surviving manuscript correction, and run the existing actual-change gates. No canonical closure or new readiness state is claimed.

FINAL same-packet check: **fresh=true, changed=[]**. Separate proposed writer operations are `/tmp/l1-gw-provenance-proposal-r3.human-operations.json`; these are proposal data, not authorization to approve.
