from pathlib import Path
import os,sys,subprocess,json,datetime
primary=Path('/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking')
candidate=Path('/Users/johnroehm/.codex/worktrees/l1-main-delivery/SK_EFT_Hawking')
sys.path.insert(0,str(primary/'scripts'))
from lean_slots.state import Inventory,directory_lock
assert Path.cwd()==primary
head=subprocess.check_output(['git','-C',str(candidate),'rev-parse','HEAD'],text=True).strip()
assert head=='c9b223abfe3f2856e4fe9abbbc4839e390489ca1'
prior=json.loads(Path('/tmp/l1-affine-main-native-r1.result.json').read_text());assert prior['returncode']==0 and prior['candidate']==head
inv=Inventory.load();assert inv.repo_root.resolve()==primary.resolve()
env=dict(os.environ,UV_PROJECT_ENVIRONMENT=str(primary/'.venv'),UV_NO_SYNC='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1')
prefix=Path('/tmp/l1-affine-main-refresh-r1');assert not prefix.with_suffix('.invocation.json').exists()
receipt={'candidate':head,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'scope':'Existing canonical extraction, counts, paper tables and fast sync after actual main native build; no slot transition'}
code="import sys;sys.path.insert(0,'scripts');import extract_lean_deps as e;e._run_extraction();d=e.load_lean_deps();sel=[x for x in d if x.get('module')=='SKEFTHawking.ADW.GaussianPolynomialAffine'];assert len(sel)>=10,(len(sel),[x.get('module') for x in d[-10:]]);assert all(set(x['axiom_deps_core'])=={'propext','Classical.choice','Quot.sound'} and not x['axiom_deps_project'] for x in sel);import json;print(json.dumps({'records':len(d),'source_hash':e.compute_lean_hash(),'new_declarations':sel}))"
commands=[('extraction',['/Users/johnroehm/.local/bin/uv','run','python','-B','-c',code]),('counts',['/Users/johnroehm/.local/bin/uv','run','python','scripts/update_counts.py']),('tables',['/Users/johnroehm/.local/bin/uv','run','python','scripts/render_paper_tables.py']),('fast-sync',['/Users/johnroehm/.local/bin/uv','run','python','scripts/sync.py','--fast'])]
with directory_lock(inv.state_root/'locks/authoritative-build.lock',purpose='ROOT exact L1 affine canonical artifact refresh'):
 prefix.with_suffix('.invocation.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print('STARTED '+head,flush=True)
 for name,argv in commands:
  with Path(str(prefix)+'.'+name+'.stdout').open('w') as out,Path(str(prefix)+'.'+name+'.stderr').open('w') as err:r=subprocess.run(argv,cwd=candidate,env=env,stdout=out,stderr=err)
  receipt['steps'].append({'name':name,'returncode':r.returncode,'argv':argv});prefix.with_suffix('.progress.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print(name+' returncode='+str(r.returncode),flush=True)
  if r.returncode:break
 receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['status']=subprocess.check_output(['git','-C',str(candidate),'status','--porcelain'],text=True)
 prefix.with_suffix('.result.json').write_text(json.dumps(receipt,indent=2)+'\n')
sys.exit(receipt['steps'][-1]['returncode'])
