# Gaussian polynomial IBP — exact target verified; commit blocked

Task `l1-gaussian-polynomial-ibp-wt1-r1`, parent `publication-remediation`. ROOT is lead, primary notebook writer and acceptance reviewer. Primary notebook: `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-remediation-notebook.md`. Roadmap: `docs/roadmaps/Phase6a_Roadmap.md`.

Owned source ONLY `/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.claude/worktrees/wt1/lean/SKEFTHawking/ADW/GaussianPolynomialIBP.lean`, plus this report and its JSON companion. Base `4fca5970f4f4cb0b408ea33243076c72058f6e56`; ACTIVE public wt1 client codex, epoch323eaae82597f49d8ab6fcec488d3dea03e0bab67cf57ec6a0c3a3fed81dbbb2. ROOT retains heartbeat, builds, integration and review.

## Exact result

```lean
SKEFTHawking.ADW.integral_mul_polynomial_gaussianReal
    (p : Polynomial ℝ) :
    (∫ z : ℝ, z * p.eval z ∂ProbabilityTheory.gaussianReal 0 1) =
      ∫ z : ℝ, p.derivative.eval z ∂ProbabilityTheory.gaussianReal 0 1
```

No extra assumptions, degree bound, moment hypothesis, assumed integrability/Stein identity, fitted Gaussian or abstract averaging. The exact original target is preserved.

Source SHA256: `ffb651c528b22d256b05e8a5ea5118ff3d6fb5bf917d00cd9544b25daccfb396`. Complete source is embedded in JSON for ROOT readback.

Proof chain:
- `integrable_polynomial_mul_gaussian`: all real polynomials times exp(-z²/2) are Lebesgue integrable, by polynomial monomial/add induction and the existing all-power rpow Gaussian integrability theorem.
- `integral_mul_polynomial_gaussian_weight`: applies actual `MeasureTheory.integral_mul_deriv_eq_deriv_mul_of_integrable` with u=p.eval and v=exp(-z²/2). The Gaussian derivative is proved to be -z exp(-z²/2). The three required product integrabilities follow from the first helper, at p, p.derivative and X*p. No boundary limit or integration identity is assumed.
- `integral_mul_polynomial_gaussianReal`: actual Gaussian density conversion and normalization transfer the weighted identity to mean0 variance1 probability.

Direct imports are Gaussian.Real, GaussianIntegral, IntegralEqImproper, Deriv.Polynomial; all available to the admitted matching LSP. No new project import olean or build was needed. Aggregate imports untouched.

## Validation receipts

Final formatted source: all ordinary fun lambdas use ↦, no lines longer than100 characters.

Final actual `skeft_wt1 lean_diagnostic_messages`: success=true, timed_out=false, items=[], failed_dependencies=[].

Fresh `lean_verify(scan_source=true)` for EACH of:
- `SKEFTHawking.ADW.integrable_polynomial_mul_gaussian`
- `SKEFTHawking.ADW.integral_mul_polynomial_gaussian_weight`
- `SKEFTHawking.ADW.integral_mul_polynomial_gaussianReal`

Every result: axioms=[propext, Classical.choice, Quot.sound], warnings=[]. JSON retains all actual receipts, source and outline/types. The main live `lean_goal` after its last tactic returned goals_after=[]. Prior successful multi_attempt candidates returned goals=[], diagnostics=[], timed_out=false.

No build, cache/dependency repair, clean, shell Lean, new axiom, native_decide, maxHeartbeats, residual sorry, integration, controller, notebook, aggregate-import or registry modification.

## Continuity and process

First action NEW packet check: fresh=true, changed=[]. Read the new brief/current notebook and continuity contract; reused unchanged authorities/discovery and directly read accepted ADW source for source scope.

Before editing, primary `slotctl status --json` recorded wt1 lease ACTIVE, repo_role public, client codex, exact assigned base/epoch/heartbeat. The sandbox still could not observe ps/endpoints, already reconciled by ROOT in discovery; matching actual MCP calls succeeded.

Used the requested Lean4 autonomous prove phases: explicit exact statement, live outline/goal/search, candidate multi_attempts, helper/main proof work and final review/diagnostics/purity. Project ownership restrictions kept workflow state in these reports rather than creating extra state/registry files. No deep agent or build fallback.

One local-search call mistakenly supplied a .lean source file as project_root and returned:
`Invalid project root .../lean/.lake/packages/mathlib/Mathlib/Analysis/Calculus/Deriv/Polynomial.lean: Lean project path ... must contain lean-toolchain and either lakefile.lean or lakefile.toml.`
Reported immediately to ROOT; it was an argument error, not lease/runtime failure, and subsequent calls used the actual project root. No endpoint or infrastructure workaround.

Final packet check exits1 as EXPECTED:
```json
{"fresh": false, "changed": ["owned-files", "source"]}
```
The new assigned file causes this discrepancy. No packet refresh; ROOT must reconcile the candidate. No other input drift was reported.

## Exact Git blocker

After all proof, formatting and verification gates above:
```
git add lean/SKEFTHawking/ADW/GaussianPolynomialIBP.lean
fatal: Unable to create '/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.git/worktrees/wt1/index.lock': Operation not permitted
```
Exit128. Stopped immediately; no retry, escalation, index repair, lock deletion, build workaround or commit. The attempted path set was exactly the one assigned module. Actual staged set after mandatory stop is UNKNOWN; no successful staging call or commit exists. The pre-staging status showed only untracked `lean/SKEFTHawking/ADW/`. ROOT received the exact error and source hash.

Required handoff: ROOT performs normal authorized assigned-only staging, verifies the exact staged set, and commits. Worker cannot report a commit hash.

## Acceptance boundary and remaining work

This is the exact first polynomial analytic brick, locally LSP/kernel verified. ROOT still owes independent source/mathematical review, normal commit/absorption, aggregate import decision and authoritative full-project qualification.

The full accepted signed auxiliary/source identity still owes all-degree Hermite lowering and factorial/parity coefficients, σ scaling, constructed finite signed W, original128-generator coframe grading/nilpotence, C2 source/test preservation and undivided derivative-of-W observable correction. No physical CAR/B3/state/metric/dynamics, main, publication or human acceptance follows.
