# Independent PR 117 G3 review

Scoped verdict: accept the producer repair and regression test. L1 G3 remains measured and blocked. Historical source dates become visible in the derived graph; this review records no new operator approval or scientific attestation. Publication, live dashboard behavior, and full-tree certification are outside the scoped result.

## Exact inputs and isolation

- The primary continuity check for `l1-g3-provenance-date-seam-independent-r1.json` returned `fresh: true` with no changed inputs.
- Candidate parent `260a75597b930624bf414bb8d0a1eb4a120fca61`. I cloned without copying working-tree edits, checked out the exact detached parent, applied the test hunk first, and applied the producer hunk after the baseline evidence was captured. `git diff --abbrev=9` reproduced the frozen patch byte for byte, SHA-256 `7d3f127c335773c6b94181e0926c1cbbf1d290c86e9efaa2535f28dafcf1383c`. `git diff --check` exited 0.
- The only production edit is two additive `meta` fields in `scripts/build_graph.py`. The registry digest stayed `714ecf00f68e403174f8508dc58d30fcef1d1aecf6f362a66a90388cfa0b05a7`. The checked-in Lean dependency input reported fresh.

## Independent results

- Exact regression `tests/test_build_graph.py::TestExtractParameterNodes::test_parameter_verification_dates_reach_graph_consumers` red with only the test applied (exit 1, `TEST.verified` incorrectly remained a blocker), then green with the producer hunk (exit 0, 1 pass). See `red.log` and `regression-green.log`.
- `python -m pytest -q -p no:cacheprovider tests/test_build_graph.py tests/test_readiness_gate_evaluators.py` returned 144 passed, 1 skipped, 15 deselected. See `core-green.log`.
- In separate Python processes, ran `extract_readiness_gate_nodes()` from `scripts.build_graph` against the exact parent and candidate. Both exited 0. L1 retained the same 20 graph dependencies. The parent reported 0 human-verified and 20 blockers. The candidate reported 13 human-verified and seven blockers. The other six changed gate records were G3 records and all retained `blocked` state. Across the 704 gate IDs, after excluding evaluation timestamps, all other nodes were identical. See `production-base.json`, `production-candidate.json` and `gate-delta.json`.
- For each L1 dependency, independently compared the real candidate node to `PARAMETER_PROVENANCE`, ran the existing link-state helper and node timestamp annotator, and recorded source-line Git attribution in `source-reconciliation.json`. All 20 LLM dates are `2026-04-25` from `e4c4afa66bd210d01014e64857324f6f71ab43d9`. All 13 recorded human dates are `2026-04-28` from `dc4f6ba84aec5077380a502748f294dbec9d7f70`. The other seven human dates remain null.

Remaining L1 G3 blockers:

- `GW.CHI_VEST_NATURAL_LOWER`
- `GW.CHI_VEST_NATURAL_UPPER`
- `GW.CHI_VEST_DEFAULT`
- `GW.GW170817_PEAK_FREQ_HZ`
- `GW.GAMMA_H_VESTIGIAL_DEFAULT`
- `GRAV.ALPHA_ADW_LOWER`
- `GRAV.ALPHA_ADW_UPPER`

## Consumer and cache boundaries

- The existing booleans, verification labels and node/edge shape remain available. The additive metadata preserves source values including null. G3 checks the existing date field, and freshness timestamp annotation can now use the date under its existing priority order. The graph payload and AGE serializer use flexible metadata objects.
- The link-state helper gives `human_verified` for the 13 dated L1 nodes and `llm_verified_only` for the seven pending ones. The production graph invokes `annotate_last_modified`. The helper has no production call site in this revision. `BACKED_BY` emission and the dashboard chain renderer have separate link-state paths, so this repair establishes the date input and helper behavior without establishing a visible badge change.
- The dashboard cache fingerprint includes mtime and size of imported repo modules including the graph builder. A fresh dashboard process imports the candidate code. An already-running Python process may continue to hold its imported pre-change implementation even after an mtime-based graph rebuild. The published graph `source_hash` was `562af3e2785d2fe0` on both revisions because it fingerprints registry/Lean input content, and does not distinguish the old and new derived payload. Serialized exports need regeneration using the updated producer.
- The cold private checkout run with bytecode disabled hit the existing cache fail-safe for absent `scripts/__pycache__`. Both parent and candidate reproduced the same two cache test failures under that setup. A first candidate run with bytecode enabled observed a `validate_helpers` bytecode file created during the build and deliberately discarded the read set. These diagnostics are kept in `green.log`, `base-cache.log` and `candidate-cache-standard.log`.
- The candidate dashboard-cache suite then passed all nine tests with standard bytecode enabled in the warmed private checkout. See `candidate-cache-warm.log`.
