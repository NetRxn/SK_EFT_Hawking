# L1 inherited source propagation proposal R1

OFF-TREE AUTHOR PROPOSAL ONLY. Candidate remains frozen. No repository file was written and no scientific, canonical-finding, gate, publication, native or integration acceptance is claimed.

Artifacts: `/tmp/l1-main-source-propagation-proposal-r1.patch`, matching `.json`, and proposed file copies under `/tmp/l1-main-source-propagation-proposal-r1-files/`. Reproduction script `/tmp/build_l1_source_proposal_r1.py` reads the repository and writes only `/tmp`.

## Narrow corrections and evidence

1. `HYPOTHESIS_REGISTRY.H_VestigialModeIsGraviton`: change only `statement`, `source`, `elimination_path`, and `prose`. The actual Lean definition at lines480–483 is exactly scalar positivity, fixed-cap compatibility and strict sub-half deviation. It contains no state, propagator, polarization, matter coupling or microscopic dynamics. At fixed tau, P2 implies P3prime and, on the nonnegative carrier, P1. The unity witness and four counterexamples remain intact; they establish scalar satisfiability/refutations. Proposed wording makes no universal no-go assertion.

2. `GW_PARAMS` comments: distinguish a free dimensionless normalized response and adopted [0.1,10] window from a computed microscopic susceptibility/range. Preserve every key and numerical expression. Remove unsupported attribution of that normalization to Vergeles, and distinguish numerical probes and literal gamma*omega from physical frequency/transport matching.

3. Four canonical GW helper docstrings: state the actual assumed sqrt law; give the nonzero-reference condition for relative deviation; describe the exact numerical coefficient*probe product without a second frequency factor inside the coefficient; replace exponential fine-tuning language with the exact finite interval and width4tau under the fixed scalar cap. No formula body changes. `ligo_constraint_check` already describes its literal fixed-cap predicate and is left unchanged.

4. GW test documentation: rename the quarter-witness test to `test_p1_does_not_imply_p3prime`, explicitly state its one-way nonimplication, distinguish the adopted scalar law and product ansatz from derived leading physics, identify100 as a numerical probe, and clarify exact real width versus rounded endpoints. Every assertion, witness, expression, decorator, import, parameterization and numerical value is identical. No test is weakened.

## Tier versus original physical BUILD

Keep `tier=external_boundary`, `status=active`, `eliminability=open`, key/module/risk/circularity and every unrelated registry entry exactly. The tier classifies the present boundary of the scalar formalization; it grants no scientific deferral. Reclassification would be a separate planner/owner decision and is neither needed nor justified by this documentary repair.

The elimination path expressly retains the current original L1 B3/Wave2 construction: metric-channel operator/source/projector, regulator, response normalization and independently justified parameter/stability conditions making the original stated range a RESULT; physical state and stable constrained propagator, spin/polarization and matter coupling; actual transport coefficients, units, ordinary/angular frequency and controlled observational-band errors. These obligations remain full-strength OPEN BUILD. Scalar compatibility neither discharges them nor proves a physical construction impossible. The current Phase6a roadmap opening and existing REPAIR_DISPOSITION_MAP priority/debt entries, not the superseded historical SHIPPED/O.1 wording, govern this assessment.

## Source access and attribution

- Actually read the entire short primary body of [Volovik2601.00639v1](https://arxiv.org/html/2601.00639v1), including SectionIII Eqs6–9 and SectionIV. It derives luminal entropy-wave second sound within its de Sitter two-fluid model and discusses possible scalar/helicity interpretations. This supports correcting the date/source, not identifying that mode with the L1 microscopic tensor/matter construction.
- Obtained [Vergeles2506.00036](https://arxiv.org/html/2506.00036) HTML and extracted the actual locally held v2 PDF to `/tmp/l1-vergeles2025-source-proposal-r1.txt` (808lines). Its introduction and construction concern ECP lattice gravity and unitarity with conserved DOF; text inspection found no susceptibility/RPA/bubble/[0.1,10] calculation. The supported correction is removal of its false attribution as the source of the adopted window. This matches the existing provenance detail and current L1 range paragraph. HTML drops much equation content, so the actual PDF text was also consulted; no new equation from that source is asserted here.
- Read actual `SecondOrderSK.GammaH` source/comments, including its acoustic damping interpretation and units[s^-1], actual `GravitationalWaves` product/predicate definitions, and current complete L1 source sections for range, physical scope, correction and predicate audit. [CGL1511.03646](https://arxiv.org/html/1511.03646) was acquired; its general SK framework is not being claimed as a derivation of this helper. Proposed helper attribution is to the project ansatz itself.
- No new primary-source characterization is introduced for Abbott; the existing citation remains attached to its observational bound rather than the susceptibility ansatz.
- Read governing CLAUDE/pipeline, continuity contract packet, ROOT notebook current entries, current roadmap opening and existing disposition queue, and `/tmp/l1-main-composed-source-review-r1.md` findings R1.1/R1.2. No memory-derived evidence used.

Required source access for this bounded proposal is complete at the named claim locations. This is no independent derivation of any missing physical matching.

## Executable and metadata invariants

The JSON gives original/proposed SHA256 for all three full files, normalized executable AST SHA256, assertion counts and patch SHA256. Comparison removes only genuine leading module/class/function docstrings and normalizes exactly the one test rename. For constants only, it masks exactly the four allowed scientific narrative fields within the one registry entry. The full resulting ASTs are equal. Thus every executable value, body, import and every other registry field is preserved. Separately the ordered assertion ASTs are identical: constants1, formulas1, GW tests165. The test module normalization does not mask arbitrary function names.

`git apply --check /tmp/l1-main-source-propagation-proposal-r1.patch` passed against the frozen source; it did not apply anything. Python parsed every proposed file during AST verification. No pytest, Lean, full validation, renderer, writer, seeding, closure or derived-view regeneration was run under this author-only frozen assignment. ROOT owns independent review, application after the freeze, canonical hypothesis rendering/freshness/ledger and focused GW verification, plus the existing project/publication acceptance route. This proposal creates no second routing ledger and touches no catalogs, Lean, machinery, provenance or human/date fields.
