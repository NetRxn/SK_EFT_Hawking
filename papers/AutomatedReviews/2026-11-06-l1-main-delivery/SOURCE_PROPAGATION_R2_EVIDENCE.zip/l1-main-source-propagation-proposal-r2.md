# Grouped L1 source propagation proposal R2

OFF-TREE AUTHOR PROPOSAL ONLY against clean frozen candidate f144749d795f904e563a83c869b0dee27bdbbd99. Five proposed files; no repository writes, tests, render, native/graph/DB/controller action, Git mutation or canonical closure. ROOT remains sole repository/notebook writer and acceptance reviewer.

Artifacts: `/tmp/l1-main-source-propagation-proposal-r2.patch`, `.json`, and exact proposed copies under `/tmp/l1-main-source-propagation-proposal-r2-files/`. Construction/verification script: `/tmp/build_l1_source_proposal_r2.py`; primary PDF extraction/hash receipts: `/tmp/l1-main-source-propagation-proposal-r2-evidence/`.

## Coherent repair

The R1 three proposed files are reused byte-for-byte, including the four allowed hypothesis narratives, GW_PARAMS commentary, four formula docstrings, documentary test wording and one test rename. Their original/post hashes and executable AST/assertion invariants are embedded in the R2 JSON. R1's scientific rationale remains valid and is incorporated by reference at `/tmp/l1-main-source-propagation-proposal-r1.md`; R1 artifacts remain preserved.

R2 additionally changes only `notes` for the three affected Volovik citation entries, and `provides`/`notes` for Baker/CV/SJ/EZ/Abbott. The summaries distinguish vestigial metric order, equilibrium thermodynamics and de Sitter second sound from the L1 assumed spin-2 susceptibility law; affected operator/model sectors from whole-theory elimination; conditional bimetric and galileon inferences from unconditional bounds; and the multimessenger speed paper from the detection report. The adopted finite window is not represented as excluded or as a physically derived range.

The L1 prompt block names actual bibkey `Abbott2017GW170817`, ApJL848L13, distinguishes detection PRL119161101, and records the source assumptions, symmetric project envelope, adopted response window, endpoint factors about2.28e14/7.21e14, and finite interior interval containingunity with exact width4tau. Its existing D3 character-for-character cap consistency requirement and source-cache/doi_verified control remain. No gate/workflow or bundle roster is changed; only the anchor's mistaken scientific/bibliographic object is corrected.

## Personally consulted source evidence

Precise short quotations below locate the physical qualifications. Longer equations and implications were read in their surrounding primary sections, not inferred from title/abstract summaries. Held PDF and extracted-text SHA256 values are in the R2 JSON. Local text line references refer to the named files under the evidence directory.

| Source/body location | Short exact evidence | Warranted summary |
|---|---|---|
| [Volovik2312.09435v2](https://arxiv.org/html/2312.09435v2), III Eqs18–22 | “the bilinear order parameter (tetrad) vanishes” | Metric order precedes nonzero tetrad expectation. Connected versus factorized response and boson/fermion correspondence are not automatically irrelevant. This paper supplies no L1 sqrt-chi speed law. |
| [Volovik2601.00639v1](https://arxiv.org/html/2601.00639v1), III Eqs6–9, IV | “a massless graviton with zero helicity” | A possible interpretation, not a derived L1 spin-2 substrate tensor/matter bridge. The luminal entropy-wave result is within its stated two-fluid background. |
| Held Volovik2410.04392v11, IV Eqs18–29, text475–519 | “the normal component in this two-fluid thermodynamics” | The gravitational component is stiff matter within this framework. Keep its role separate from the2026 second-sound source and project kinematic susceptibility law. |
| Held Baker1710.06394v1, bimetric/Caveats/conclusions, text231–272 | “assuming similar amplitudes for both modes” | Bimetric mass inference is conditional; the action-level restrictions also retain no-finely-tuned-cancellation/background qualifications. Source explicitly discusses present epoch and cosmological versus short-wavelength propagation. |
| Held CV1710.05877v3, EFT/covariant action, text104–170 | “a small change of the background solution” | No-tuning demands nearby-background robustness and precise operator relations. The held body is June2018v3; this proposal does not certify identity with original2017 published content. |
| Held SJ1710.05893v3, astrophysical tests and quartic-galileon section, text90–137,194–230,270–299 | “for representative values of c0 ∼ O(1)” | Separate cluster/stellar beyond-Horndeski constraints from GW plus M87 inference about cosmological relevance of the specific quartic model. Do not exclude all galileon/scalar-tensor theories. |
| Held EZ1710.05901v2, final enumeration, text345–360 | “including some sectors of Hořava gravity” | GW-speed-modifying couplings/sectors are constrained. Viable alternatives and matter-coupling conditions remain. Its adopted5e-16 comparison is distinct from L1's conservative3e-15 envelope. Text uses decomposed diacritics in extraction; quoted typography is normalized. |
| Held Abbott1710.05834, Section4.1 Eq1, text330–365 | “we conservatively use here D = 26 Mpc” | Asymmetric speed interval uses distance/emission assumptions; alternate emission histories broaden it. L1 symmetrizes this source interval. This is ApJL848L13, not the detection PRL. |

Current L1 manuscript actual source SHA25629f926fef642a352ffb24b2d1fb0d851c1fb58d5c2a50ba7ffaf3083e3c1c5a2 and the actual151-unit claims artifact/report govern the repair. The report's grouped R1.1 propagation defects are addressed at these assigned five source surfaces. The claims catalog is evidence, not proof of primary claims. The actual primary bodies above were consulted directly for the new source summaries.

## Exact preservation and source limitations

All citation bibliographic identities/titles/authors/journals/years/DOIs/arXiv IDs, verification fields, primary_source_path fields, used_in rosters and every field besides the listed summary fields are identical. Whole citations AST equality is checked after masking only those explicit summary fields at the eight named keys. All other executable source is exact. The historical2026-08-14 registration/correction and review identity remain. Both historical TITLE PROVENANCE caveats survive byte-exact as string values; no fresh-fetch/verification/custody completion is claimed or written. Existing2026-08-09 abstract-check history comments are untouched. Online primary reading in this task does not retroactively replace those historical metadata controls.

The held CV source version is explicitly qualified; original2017-vs-v3 full equivalence remains unestablished. The Abbott higher-curvature/Stelle translation is preserved as the existing separate paper40 attribution, not independently rederived or accepted here. R2 does not inspect every full microscopic literature route or make a universal absence claim. No underspecified new physical premise is introduced to settle a construction or weaken the original objective. All needed primary claim locations for these narrow summaries were accessible; the remaining limitations are precisely version equivalence, custody/metadata verification and unperformed original physical construction.

R1 invariants remain: normalized executable ASTs preserve formula bodies/values and all statements except four authorized registry narrative fields;165 GW test assertion ASTs plus the unchanged constants/formulas assertions are identical. The one test rename does not alter its quarter witness. JSON retains original/proposed full-file hashes. Proposed Python files parse. The prompt change is restricted to the exact L1 anchor/control paragraph; its surrounding file is exact.

## Original acceptance boundary

Preserve active/open key and tier external_boundary. This classifies the present scalar formalization boundary; it grants no deferral of original L1 B3/Wave2 BUILD. Physical normalization and range as a RESULT, state, operator/source/projector/regulator, stable constrained tensor/polarization/matter/light dynamics, actual transport coefficient and frequency/unit/error matching remain full-strength OPEN under the owning roadmap. Scalar witnesses and endpoint violations supply neither that construction nor a universal no-go. No title/physical-natural-range acceptance, D3 layout acceptance, canonical finding closure, whole-project gates or final human/publication approval is requested or inferred.

ROOT owns independent proposal review, later application, existing hypothesis renderer/ledger/freshness and actual focused gates, followed by current claims/audit/finding reconciliation through existing writers. This proposal does not introduce another catalog, routing ledger, gate or workflow.
