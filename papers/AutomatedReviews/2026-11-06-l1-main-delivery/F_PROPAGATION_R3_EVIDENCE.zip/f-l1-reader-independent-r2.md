# Independent F mapped-L1 reader/render review r2

**Verdict: REVISE (rendering); scoped prose ACCEPT with one nonblocking copyedit.**

The corrected argument is readable in source and consistently conditional. The actual PDF introduces a serious collision with a new L1 passage on page13. This review does not establish whole-F scientific acceptance, Stage9/10/13 closure, publication readiness, or human approval. ROOT owns acceptance.

## Pinned artifacts and coverage

Source SHA256 `f924e5b80d6a36a37c60886ba2ebdc042e60ce0419db24c2aab3ba8b62c9b9be`; actual candidate PDF SHA256 `68f1191292ab3d195793a8eb6f5c7f0aa01efab25fca33e76efeb093481981fd`. Read the whole current source in order through line2627 (end of document), complete baseline/current diff, current replacements in context, supplied assessment/manifest, roles, authoring floor, CLAUDE/WAVE and owning-roadmap context. Surveyed all24 pages in `/tmp/f-l1-layout-survey-r2.png`. Directly viewed pages1,2,3,6,10,11,13,19,23,24. Additionally rendered and directly viewed baseline pages12,13 from the supplied frozen baseline PDF. No compiler, tests, Lean tools, slots, Git or repository mutations.

## Required restructuring instruction

Repair the collision before accepting this rendering. Candidate page13: the long `EinsteinCartanExtension.torsionAtCosmologicalBackground_at_planck_natural_below_kostelecky` citation at source line1249 extends from the left column across the right column and overprints the new paragraph at lines1298-1303, including “normalization, propagating mode and common matter/light reference.” Break/wrap this citation, or otherwise protect the new paragraph. Preserve the paragraph's complete physical-construction obligations. Have ROOT recompile/render and independently recheck page13 and any reflowed carrying pages.

This is an inherited overflowing identifier with a **new collision target**, not a wholly new overfull box. In baseline page13 the same identifier crossed the deferred-figure box at the page top. In candidate page13 it crosses the newly authored L1 limitation, materially reducing readability. The identical 309.86821pt width is therefore not proof of no regression. Candidate PDF word coordinates independently locate the collision: theorem spans x63.963..607.792, y495.522..505.855pt; the new right-column words occupy x317.014..562.094, y497.008..505.855pt. See `/tmp/f-l1-candidate-p13-reader-r2.html` and the directly viewed baseline/candidate PNGs.

## Exact overflow comparison

Both supplied canonical compilations report24 pages,25 overfull boxes, zero TeX errors/unresolved references/dropped class options. I did not rerun them. Parsed actual retained `paper_draft.log` files, not just the wrapper summaries. Twenty-three records have identical width and TeX diagnostic content after removing changed source-line locations. Records6/7 are changed:

| Record | Baseline source lines | Baseline width | Candidate source lines | Candidate width | Assessment |
|---|---:|---:|---:|---:|---|
| 6 | 1043–1066 | 42.11743pt | 1063–1075 | 6.2077pt | New biconditional theorem citation; minor readable protrusion on p11 |
| 7 | 1043–1066 | 60.3768pt | 1079–1097 | 0.90448pt | Same interval-width theorem reflowed; minor readable protrusion on p11 |
| 13 | 1215–1222 | 309.86821pt | 1248–1255 | 309.86821pt | Inherited identifier, newly serious overlap with new L1 paragraph on p13 |

The companion JSON includes every before/after overflow record and classification. The baseline already has serious theorem spills elsewhere, including cosmological, torsion, Riemann/Penrose and QEC citations. Those remain inherited publication-layout debt. This focused review does **not** demand fixing all25 before accepting the source correction; it requires protecting the new L1 text from the newly located collision.

## Scoped reader outcome

The L1 passages now say that an assumed scalar law constrains a free nonnegative normalized response. They distinguish the electromagnetic speed reference from the additional physical tensor/matter identification; adopted endpoints from the finite compatible interior including unity; interval width from probability; and speed tolerance tau from susceptibility offsets. The discussion separates the2024 quartet proposal from the2026 de Sitter luminal-second-sound model and preserves the absent response/induced-Newton matching. Primary-source fidelity and theorem adequacy are the independent source auditor's responsibility, not adjudicated here.

Section VI.B carries the argument; VI.I, X.B and XII.B propagate its meaning coherently. The rewritten abstract and gauge synthesis no longer assert general GW falsification or unique ADW selection. The register's inherited “Falsified” heading is broader than its GW item, but its immediate introduction and bold conditional item explicitly distinguish the claim; moving to a dedicated conditional-constraint register would be a later structural improvement, not a blocker for this scoped correction. Remove the stray article in lines1280-1281: “The D3 and L1 use” should read “D3 and L1 use.”

Where the scoped reader stops: actual p13, at the overprinted construction-obligations line. In source alone the scoped argument is followable. What the scoped manuscript is about: a conditional susceptibility constraint under an assumed GW-speed law, with finite surviving responses and open physical construction requirements.

## Whole-F limits preserved

The whole source is a program survey with a substrate-identity synthesis; the global abstract opens with program consolidation rather than a result. Whole-F internal taxonomy, process narration and argument ballast remain inherited, as do global prose-gate FAILs. The full manuscript is24 pages against the metadata charter80–150 pages; this is not full-length acceptance. New GW symbols c, chi and tau are defined locally; no new undefined load-bearing symbol was found. Stage9/10/13 remain pending and readiness RED. The legacy May4 Stage10-round3 claims file was not touched. No historical closures, canon ingestion or human-state promotion occurred. The original B3/state/tensor/matter/light/G_N-response/transport/band BUILD remains OPEN. Focused tests reported by ROOT are not full-tree or scientific qualification.

Final continuity check: same packet **fresh=true**, changed=[] immediately before handoff.
