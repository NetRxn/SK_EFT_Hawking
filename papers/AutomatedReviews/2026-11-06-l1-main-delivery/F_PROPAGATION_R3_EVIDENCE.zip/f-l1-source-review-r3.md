# F actual candidate independent source review r3

**ACCEPT_SOURCE_PROPAGATION**, bounded to all20 frozen R1 mapped F/L1 inventory IDs and the complete actual F/citation diff. Packet `f-l1-source-candidate-review-r3.json` initially fresh. Actual F SHA256 `e8f1e0e8b448fd8b6a3a232d10a9656cfd584bb3861900cf793eab486a0eef89`. No remaining correction is required within this source-propagation scope.

This is an independent semantic read of the actual candidate and all carrying changed contexts, not a lexical-marker check or acceptance inferred from ROOT's manifest. The two R2 residuals are repaired: the overview states intended PRL-letter strategy and retains physical/venue/final-review obligations; the combined register is accurately headed Exclusions and conditional constraints. The crossbridge article is corrected.

## Scientific scope

Volovik2024 §III/Eqs18–20 supports expectation-valued quartet metric order before tetrad order. Volovik2026 §III/Eqs6–9 derives luminal second sound in its de Sitter thermodynamic model, while §IV leaves graviton interpretation open. Neither yields this substrate's susceptibility-dependent speed law, physical state, tensor polarizations or common matter/light reference. Abbott's printed §4.1/Eq1 source-emission premises, asymmetric interval and adopted symmetric envelope are distinguished. Current wording does not promote source-model luminality to acceptance of an unmatched substrate.

The actual assumed law and fixed-cap result are correctly carried: chi≥0, c≠0 for the relative-deviation identity, tau=3e-15 and chi∈[(1−tau)²,(1+tau)²]. Finite tolerance admits an interval including1. The endpoint theorem excludes the two chosen comparison endpoints; neither it nor the conjunction named vestigial_natural_range_violates_ligo establishes universal interval exclusion. Width4tau, strict10^14 width comparison and exact susceptibility offsets−2tau+tau²,+2tau+tau² agree with actual theorem bodies. Tau bounds speed deviation, not susceptibility offset. A width fraction supplies no probability without a prior. The new passages introduce no false independent-clause or exclusive-counterexample claims.

The abstract, synthesis, cleared-register comparison and crossbridge disclose the extra free GW response and unconstructed induced-Newton-to-response normalization. Conditional RPA with unevaluated inputs and matched numerical window endpoints do not compute physical normalization or the window. The GW branch supplies no unique ADW-selection theorem, and the revised source explicitly says so. Statistical classification is coherent: a speed/cap ratio is neither sigma significance nor Bayes factor, and GW is a conditional constraint with surviving interior.

## Exact custody and preservation

Verified all13 actual backing hashes and all3 full primary-PDF pins. Eleven backing files remain exactly R1 bytes; F and citations are the only changes among them. The citation source is exactly the before file with F appended once to Volovik2026SecondSound.used_in. All unchanged source/Lean/Python editions and full primary PDFs supporting R1's actual carrying-section/body review were rehashed here; source-level assessment does not claim exhaustive discovery or native proof acceptance.

**Count correction:** my earlier prose summaries incorrectly said15FAIL/5neutral. Immutable R1 JSON actually has16FAIL/4INFO. All20 original IDs and individual R1 records remain unchanged. All four INFO quotes remain exact. This correction changes no source scope or disposition; ROOT was informed before this report.

Legacy F claims JSON remains byte-identical: May4 stage10 round3 GREEN bridge is historical, not current acceptance. F metadata remains RED with Stage10/13 pending. Original thermal-crossover repair and separate VestigialEOS/H4/q-theory passages remain intact. No partial F sentence catalog is substituted.

The three theorem-reference wrappers preserve exact mathematical identifier spelling. The local leanref macro uses path with hyperref already loaded. This source review accepts identifier preservation, not rendered layout or ROOT's reported59-token producer result. ROOT's tests, compilation and rendering receipts remain separate executions; this reviewer ran none of those and did not run the Verify contract.

## Acceptance boundary

Original physical B3 response/normalization/domain/window, physical state and positive dynamics, G_N-to-response matching, tensor mode/constraints/poles, common matter/light source reference, actual transport/Kubo/frequency/units/remainder and a controlled nonempty band remain full-strength BUILD and OPEN. No full L1/F Stage10/13, full-project/native, venue, publication or human approval follows. Conditional source propagation does not recharter the physical L1 objective as a completed conditional mathematics letter.

This decision supports only existing source-binding and normal focused-finding disposition by ROOT; this assessor performs zero canonical closures and grants zero human approvals. ROOT retains ordinary L1/F authoring, review, render, catalog, qualification and integration responsibilities. Reader/render acceptance is separate.

Companion `/tmp/f-l1-source-review-r3.json` contains identical complete20-ID required/accepted sets, exact13 current backing hashes,3 actual-PDF hashes and per-span current quotes/lines/semantic dispositions with immutable R1 quote/line history and R2 outcomes. These are focused review evidence, not a replacement catalog or new routing ledger. Required continuity check is repeated after artifact generation.
