# Exact117 outcome reconciliation

Read-only triage; ROOT owns acceptance. Current failed slice:87FAILED/30ERROR. All117 unique test identities appear once below and in JSON with full emitted XML traceback, source snippets, log anchors and four-source byte comparisons. Only24 selected non-native statuses are reproduced on the exact supplied prechange replay; other93 remain UNQUALIFIED. No runtime action was taken.

## Identity correction

Prior91 and current117 share89 IDs. Current has28 newly present IDs and2 prior IDs are absent, hence net+26. The two absent IDs are `tests/test_d5_freshness.py::TestCountsFreshness::test_the_cheap_split_agrees_with_the_full_counter`, `tests/test_readiness_gate_measured.py::TestG4CompleteInternalEvidence::test_partial_measurement_log_does_not_claim_nothing_was_read`. A failed-slice omission is not passing evidence.

## Causal groups

| Group | Outcomes |
|---|---:|
|external_workspace_citation_cache_fixture|21|
|architecture_inventory_corpus_and_managed_path|1|
|extractdeps_environment_cascade|53|
|serializer_canonical_newline|1|
|external_workspace_artifact_fixture|2|
|module_reach_corpus|2|
|stage_metadata|1|
|long_sentence_corpus|2|
|open_finding_population_mixed_environment|4|
|apex_grounding_population|4|
|apex_vacuity_population|3|
|manual_table_corpus|2|
|count_literal_population|2|
|prose_reference_corpus|2|
|review_verify_contract|1|
|review_routing_contract|1|
|host_process_or_loopback_fixture_current_unqualified|5|
|host_workspace_write_fixture|1|
|citation_cache_path_and_state_debt|1|
|citation_registry_corpus|1|
|numerical_literal_corpus|2|
|extractdeps_environment_dashboard_cascade|4|
|stale_D7_regression_already_repaired_primary|1|

## Interpretation and minimum actions

ExtractDeps acquisition fails at scripts/extract_lean_deps.py:161: Physlib clone DNS failure. Its graph/closure/native-debt/readiness/dashboard dependents are unmeasured. Four mixed required-finding tests also expose genuine population debt; they are kept separate. Missing Lit-Search custody yields cache/fidelity/venue/phase/anchor fixture failures; zero cached records does not prove titles corrected or justify lowering citation ceilings. One selected registry failure reports13 missing cited keys, while the path/state test names five unresolved unsucceeded cache declarations and431 tolerated sync-drift entries; these require corpus/custody reconciliation rather than an exemption. L2 canonical newline is direct byte debt. Architecture inventory reports stale derivation and a dangling sentence schema path.

Six current host fixtures: two process signatures returnNone, three localhost binds are denied, and the newly present live-MCP test attempts state_root mkdir before its live-file check. Historical five-fixture passes do not qualify this current run. The two close_finding tests fail because their actual external artifact is unavailable; the refusal is expected fail-closed behavior, not demonstrated writer malfunction.

Existing repair reuse: D7 `06c7d8eb2`/finding `review:2026-10-15-d7-current-theorem-regression:infra:1.1`; census/apex `30b82f375` (derive actual count89 rather than copy historic91/primary90); coupled G4/inventory `1550f5ff1`; citation `f28cc370f`; serializer `6a6cd7ee6`/`b8f352bd8`. Source byte comparisons establish where donor source differs, never donor/current runtime equivalence. These are prospective integration recommendations with retained independent review and current qualification.

1. ROOT review this receipt and reconcile existing planner/known accepted packages before authoring new repair.
2. Reconcile exact reusable D7/census/apex/canonical writer/inventory/citation donor preimages under existing architecture and independent composition review. Measure actual current populations using existing producers in qualified environment; never increase ceilings to absorb debt.
3. Resolve real corpus obligations (module reach, stage vocabulary, prose length, required/unattributed findings, apex numeral/content disclosure, tables, numerical literals, references, Verify/routing) through existing owners/producers/close_finding; acquire full producer diagnostics for elided rows.
4. Qualify actual candidate through existing authorized route with actual Lit-Search custody, host fixture capability, prepared extraction/native environment. No native-dependent retries in this checkout; no new runner/cache/timestamp workaround.
5. Freeze exact composed source, perform existing required scoped/full main pipeline and independent source/render review; retain original scientificBUILD and final human/publication gates.

Collect machinery defects for one existing architecture review: external corpus fixture custody, managed-worktree live-MCP state-root construction, and transitive extraction qualification. No ad-hoc fix, new gate/ledger/ceiling/runner/cache workaround is authorized. Existing planner: `docs/audits/2026-10-17-publication-substance-construction/REPAIR_DISPOSITION_MAP.md`; existing L1 scientific identity: `review:2026-08-14-l1-stage13:L1:4.1`, parents1.1/5.1. No canonical closure/main qualification follows.

## Exact identity ledger

| Status | ID | Group | Prior91 | Selected prechange replay | Slice summary line |
|---|---|---|---|---|---:|
|FAILED|`tests/test_apm_ldpc_hashing_bound.py::test_komoto_kasai_primary_source_cache`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2587|
|FAILED|`tests/test_architecture_inventory.py::TestTheFreshnessCheck::test_the_live_tree_is_fresh`|architecture_inventory_corpus_and_managed_path|False|UNQUALIFIED|2588|
|FAILED|`tests/test_build_graph.py::TestExtractLeanTheoremNodes::test_extract_lean_theorem_nodes`|extractdeps_environment_cascade|True|UNQUALIFIED|2589|
|ERROR|`tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_has_multiple_types`|extractdeps_environment_cascade|True|UNQUALIFIED|2674|
|ERROR|`tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_axiom_nodes_have_eliminability`|extractdeps_environment_cascade|True|UNQUALIFIED|2675|
|ERROR|`tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_nodes_have_shape`|extractdeps_environment_cascade|True|UNQUALIFIED|2676|
|ERROR|`tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_structure_has_field_constraints`|extractdeps_environment_cascade|True|UNQUALIFIED|2677|
|ERROR|`tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_no_duplicate_ids`|extractdeps_environment_cascade|True|UNQUALIFIED|2678|
|ERROR|`tests/test_build_graph.py::TestExtractLeanDeclarationNodes::test_count_greater_than_500`|extractdeps_environment_cascade|True|UNQUALIFIED|2679|
|ERROR|`tests/test_build_graph.py::TestDependsOnAxiomEdges::test_edges_point_to_axioms`|extractdeps_environment_cascade|True|UNQUALIFIED|2680|
|ERROR|`tests/test_build_graph.py::TestDependsOnAxiomEdges::test_edges_have_correct_type`|extractdeps_environment_cascade|True|UNQUALIFIED|2681|
|ERROR|`tests/test_build_graph.py::TestDependsOnAxiomEdges::test_no_self_edges`|extractdeps_environment_cascade|True|UNQUALIFIED|2682|
|ERROR|`tests/test_build_graph.py::TestVerifiesEdges::test_edges_carry_test_kind`|extractdeps_environment_cascade|True|UNQUALIFIED|2683|
|ERROR|`tests/test_build_graph.py::TestFlagsEdges::test_edge_shape`|extractdeps_environment_cascade|True|UNQUALIFIED|2684|
|ERROR|`tests/test_build_graph.py::TestReportsEdges::test_edges_carry_delta`|extractdeps_environment_cascade|True|UNQUALIFIED|2685|
|FAILED|`tests/test_build_graph_memo.py::TestTheMemoCannotOutliveABuild::test_the_memo_is_drained_after_a_build`|extractdeps_environment_cascade|True|UNQUALIFIED|2590|
|FAILED|`tests/test_build_graph_memo.py::TestTheMemoCannotOutliveABuild::test_an_extractor_called_outside_a_build_reads_LIVE_state`|extractdeps_environment_cascade|True|UNQUALIFIED|2591|
|FAILED|`tests/test_build_graph_memo.py::TestTheMemoIsSemanticallyInvisible::test_the_memoized_build_equals_the_unmemoized_build`|extractdeps_environment_cascade|True|UNQUALIFIED|2592|
|FAILED|`tests/test_build_graph_memo.py::TestASeededMutationSurvivesTheMemo::test_a_finding_seeded_into_the_REAL_corpus_is_visible_to_the_next_build`|extractdeps_environment_cascade|True|UNQUALIFIED|2593|
|FAILED|`tests/test_build_graph_memo.py::TestASeededMutationSurvivesTheMemo::test_removing_the_seeded_finding_is_visible_too`|extractdeps_environment_cascade|True|UNQUALIFIED|2594|
|FAILED|`tests/test_bundle_closure.py::TestD11ModuleSetIsDerived::test_derived_set_is_nonempty_and_path_shaped`|extractdeps_environment_cascade|True|UNQUALIFIED|2595|
|FAILED|`tests/test_bundle_closure.py::TestD11ModuleSetIsDerived::test_empty_closure_raises_rather_than_guessing`|extractdeps_environment_cascade|True|UNQUALIFIED|2596|
|FAILED|`tests/test_bundle_json_serializer.py::TestCorpusIsCanonical::test_blob_is_byte_stable_through_the_serializer[papers/L2/bundle_metadata.json]`|serializer_canonical_newline|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2597|
|FAILED|`tests/test_close_finding.py::TestOutOfRepoArtifactAnchor::test_the_artifact_anchor_is_accepted_without_a_commit`|external_workspace_artifact_fixture|False|UNQUALIFIED|2598|
|FAILED|`tests/test_close_finding.py::TestOutOfRepoArtifactAnchor::test_the_recorded_path_is_the_ON_DISK_spelling`|external_workspace_artifact_fixture|False|UNQUALIFIED|2599|
|FAILED|`tests/test_d5_bundles_readiness.py::TestProducerDemotesGreenOnBlockedP1::test_the_helper_exists_and_returns_a_mapping`|extractdeps_environment_cascade|True|UNQUALIFIED|2600|
|FAILED|`tests/test_d5_bundles_readiness.py::TestBundleLeanModuleCoverage::test_the_ratchet_has_zero_headroom`|module_reach_corpus|True|UNQUALIFIED|2601|
|FAILED|`tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_live_state_passes`|extractdeps_environment_cascade|True|UNQUALIFIED|2602|
|FAILED|`tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_every_ceiling_has_zero_headroom`|extractdeps_environment_cascade|True|UNQUALIFIED|2603|
|FAILED|`tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_a_bundle_absent_from_the_map_is_asserted_zero`|extractdeps_environment_cascade|True|UNQUALIFIED|2604|
|FAILED|`tests/test_d5_bundles_readiness.py::TestBundleNativeDecideDebt::test_growth_past_the_ceiling_fails`|extractdeps_environment_cascade|True|UNQUALIFIED|2605|
|FAILED|`tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_an_empty_native_decide_set_is_UNVERIFIED_not_clean`|extractdeps_environment_cascade|True|UNQUALIFIED|2606|
|FAILED|`tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_no_measurable_closure_is_UNVERIFIED_not_clean`|extractdeps_environment_cascade|True|UNQUALIFIED|2607|
|FAILED|`tests/test_d5_bundles_readiness.py::TestNativeDecideSeamGuard::test_the_live_population_is_plausible`|extractdeps_environment_cascade|True|UNQUALIFIED|2608|
|FAILED|`tests/test_d5_bundles_readiness.py::TestUnmeasuredIsDistinctFromYellow::test_stage_status_enum_covers_the_live_vocabulary`|stage_metadata|True|UNQUALIFIED|2609|
|FAILED|`tests/test_d5_bundles_readiness.py::TestSentenceLengthRatchet::test_gate_is_green_at_the_frozen_ratchet`|long_sentence_corpus|True|UNQUALIFIED|2610|
|FAILED|`tests/test_d5_bundles_readiness.py::TestSentenceLengthRatchet::test_ceiling_matches_the_live_measurement`|long_sentence_corpus|True|UNQUALIFIED|2611|
|FAILED|`tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_check_is_green_at_the_frozen_ceilings`|open_finding_population_mixed_environment|True|UNQUALIFIED|2612|
|FAILED|`tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_A_REAL_NEW_BLOCKING_FINDING_TURNS_THE_LEG_RED`|open_finding_population_mixed_environment|True|UNQUALIFIED|2613|
|FAILED|`tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_per_bundle_ratchet_has_zero_headroom`|open_finding_population_mixed_environment|True|UNQUALIFIED|2614|
|FAILED|`tests/test_d5_bundles_readiness.py::TestTheOpenRequiredPopulationRatchets::test_the_unattributed_ratchet_has_zero_headroom`|open_finding_population_mixed_environment|True|UNQUALIFIED|2615|
|FAILED|`tests/test_d5_bundles_readiness.py::TestLeanModuleDeregistration::test_PRODUCTION_SEEDED_a_false_deregistration_turns_the_real_corpus_red`|module_reach_corpus|True|UNQUALIFIED|2616|
|FAILED|`tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_live_state_passes`|apex_grounding_population|True|UNQUALIFIED|2617|
|FAILED|`tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_the_population_floor_has_zero_headroom`|apex_grounding_population|True|UNQUALIFIED|2618|
|FAILED|`tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_the_numeral_ratchet_has_zero_headroom`|apex_grounding_population|True|UNQUALIFIED|2619|
|FAILED|`tests/test_d5_bundles_readiness.py::TestApexTheoremClaimsGrounded::test_PRODUCTION_SEEDED_a_placeholder_claim_turns_the_real_corpus_red`|apex_grounding_population|True|UNQUALIFIED|2620|
|FAILED|`tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_the_population_floor_has_zero_headroom`|apex_vacuity_population|True|UNQUALIFIED|2621|
|FAILED|`tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_both_ratchets_have_zero_headroom`|apex_vacuity_population|True|UNQUALIFIED|2622|
|FAILED|`tests/test_d5_bundles_readiness.py::TestApexClaimsNotVacuous::test_every_flagged_row_is_NAMED_in_the_output`|apex_vacuity_population|True|UNQUALIFIED|2623|
|FAILED|`tests/test_d5_citations.py::TestBibitemTitlePrimarySource::test_the_live_drift_ceiling_has_ZERO_headroom`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2624|
|FAILED|`tests/test_d5_citations.py::TestCitationCacheVenueAgreementProduction::test_real_registry_volume_drift_is_caught`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2625|
|FAILED|`tests/test_d5_citations.py::TestCitationCacheVenueAgreementProduction::test_real_registry_journal_drift_is_caught`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2626|
|FAILED|`tests/test_d5_citations.py::TestCitationCacheVenueAgreementProduction::test_real_registry_page_drift_is_caught`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2627|
|FAILED|`tests/test_d5_citations.py::TestCitationCacheVenueAgreementProduction::test_declared_phase_tokens_match_on_disk_case_sensitively`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2628|
|FAILED|`tests/test_d5_citations.py::TestCitationCacheVenueAgreementProduction::test_the_PROMOTE_SIDECAR_carries_the_same_spellings`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2629|
|FAILED|`tests/test_d5_citations.py::TestAbstractIsNotFullText::test_the_fidelity_flag_FIRES_on_the_production_corpus`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2630|
|FAILED|`tests/test_d5_citations.py::TestAbstractIsNotFullText::test_the_flag_is_ADVISORY_and_does_not_block`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2631|
|FAILED|`tests/test_d5_citations.py::TestAbstractIsNotFullText::test_the_DISCRIMINATOR_is_the_abstract_extension_not_mere_presence`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2632|
|FAILED|`tests/test_d5_citations.py::TestMetadataIsNotFullText::test_the_metadata_flag_FIRES_on_the_production_corpus`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2633|
|FAILED|`tests/test_d5_citations.py::TestMetadataIsNotFullText::test_the_flag_is_ADVISORY_and_does_not_block`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2634|
|FAILED|`tests/test_d5_citations.py::TestMetadataIsNotFullText::test_the_metadata_population_is_a_strict_subset_of_cached`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2635|
|FAILED|`tests/test_d5_citations.py::TestExemptionIsClaimedNotInferred::test_seeding_a_DOI_onto_a_declared_textbook_KEEPS_it_exempt`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2636|
|FAILED|`tests/test_d5_freshness.py::TestBundleSourceFreshness::test_an_absent_source_directory_is_UNMEASURABLE_not_fresh`|extractdeps_environment_cascade|True|UNQUALIFIED|2637|
|FAILED|`tests/test_d5_freshness.py::TestBundleCountsFresh::test_live_tree_is_fresh`|extractdeps_environment_cascade|True|UNQUALIFIED|2638|
|FAILED|`tests/test_d5_papers_prose.py::TestBundleTablesUsePipeline::test_the_ceiling_has_ZERO_HEADROOM_against_the_live_tree`|manual_table_corpus|True|UNQUALIFIED|2639|
|FAILED|`tests/test_d5_prose_checks.py::TestSpelledOutCensusFigures::test_the_live_ceiling_has_ZERO_headroom`|count_literal_population|True|UNQUALIFIED|2640|
|FAILED|`tests/test_d5_prose_lean_refs.py::TestProseTheoremReferenceCoverage::test_the_live_legacy_ceiling_has_ZERO_headroom`|prose_reference_corpus|True|UNQUALIFIED|2641|
|FAILED|`tests/test_d5_reviews.py::TestReviewVerifyIsOneCommand::test_the_live_corpus_is_clean`|review_verify_contract|True|UNQUALIFIED|2642|
|FAILED|`tests/test_d5_reviews.py::TestChainBackingTargetsResolve::test_a_dangling_link_seeded_past_the_ceiling_fails`|extractdeps_environment_cascade|True|UNQUALIFIED|2643|
|FAILED|`tests/test_d5_reviews.py::TestChainBackingTargetsResolve::test_the_ceiling_carries_no_headroom`|extractdeps_environment_cascade|True|UNQUALIFIED|2644|
|FAILED|`tests/test_d5_reviews.py::TestBlockedByResolvesLeg::test_a_dangling_blocked_by_in_a_REAL_document_turns_the_check_red`|review_routing_contract|True|UNQUALIFIED|2645|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_the_review_corpus_is_in_the_watched_read_set`|extractdeps_environment_cascade|True|UNQUALIFIED|2686|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_editing_a_review_document_moves_the_key`|extractdeps_environment_cascade|True|UNQUALIFIED|2687|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheKeyCoversTheReviewCorpus::test_editing_the_ledger_moves_the_key`|extractdeps_environment_cascade|True|UNQUALIFIED|2688|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheKeyCoversFilesThatDoNotExistYet::test_the_corpus_root_itself_is_watched`|extractdeps_environment_cascade|True|UNQUALIFIED|2689|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheKeyCoversFilesThatDoNotExistYet::test_creating_a_new_finding_directory_moves_the_key`|extractdeps_environment_cascade|True|UNQUALIFIED|2690|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheCacheStillCaches::test_an_unchanged_tree_keeps_the_key_stable`|extractdeps_environment_cascade|True|UNQUALIFIED|2691|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheCacheStillCaches::test_an_unchanged_tree_serves_the_cached_object`|extractdeps_environment_cascade|True|UNQUALIFIED|2692|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheFailSafeDirection::test_no_read_set_yields_a_key_that_cannot_match`|extractdeps_environment_cascade|True|UNQUALIFIED|2693|
|ERROR|`tests/test_dashboard_graph_cache.py::TestTheSeam::test_a_newly_filed_finding_reaches_the_dashboard_graph`|extractdeps_environment_cascade|True|UNQUALIFIED|2694|
|ERROR|`tests/test_flags_ratchet_seam.py::test_both_surfaces_are_non_empty`|extractdeps_environment_cascade|True|UNQUALIFIED|2695|
|ERROR|`tests/test_flags_ratchet_seam.py::test_every_finding_in_a_bundle_ratchet_flags_that_bundle`|extractdeps_environment_cascade|True|UNQUALIFIED|2696|
|ERROR|`tests/test_flags_ratchet_seam.py::test_every_bundle_flagged_by_a_finding_counts_it_in_its_ratchet`|extractdeps_environment_cascade|True|UNQUALIFIED|2697|
|ERROR|`tests/test_flags_ratchet_seam.py::test_every_bundle_the_aggregation_iterates_has_a_paper_node`|extractdeps_environment_cascade|True|UNQUALIFIED|2698|
|FAILED|`tests/test_gauging_qec.py::test_williamson_yoder_primary_source_cache_file_exists`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2646|
|FAILED|`tests/test_lean_slots.py::test_global_backend_limit_counts_other_repository_roles`|host_process_or_loopback_fixture_current_unqualified|True|UNQUALIFIED|2647|
|FAILED|`tests/test_lean_slots.py::test_one_physical_slot_cannot_have_two_repository_backends`|host_process_or_loopback_fixture_current_unqualified|True|UNQUALIFIED|2648|
|FAILED|`tests/test_lean_slots.py::test_the_live_workspace_mcp_config_classifies_without_raising`|host_workspace_write_fixture|False|UNQUALIFIED|2649|
|FAILED|`tests/test_lean_slots.py::test_an_idle_slot_mints_a_session_on_initialize`|host_process_or_loopback_fixture_current_unqualified|True|UNQUALIFIED|2650|
|FAILED|`tests/test_lean_slots.py::test_each_initialize_mints_a_distinct_session`|host_process_or_loopback_fixture_current_unqualified|True|UNQUALIFIED|2651|
|FAILED|`tests/test_lean_slots.py::test_the_minted_session_does_not_weaken_the_lease_gate`|host_process_or_loopback_fixture_current_unqualified|True|UNQUALIFIED|2652|
|FAILED|`tests/test_nbre_triplet_spt.py::test_colangelo_primary_source_cache`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2653|
|FAILED|`tests/test_phase6i_wave1.py::test_paper_to_phase_values_exist_on_disk`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2654|
|FAILED|`tests/test_phase6i_wave1.py::test_external_cache_paths_resolve_when_set`|citation_cache_path_and_state_debt|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2655|
|FAILED|`tests/test_phase6i_wave1.py::test_no_missing_from_registry`|citation_registry_corpus|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2656|
|FAILED|`tests/test_polariton_tier1_tmds.py::test_penn_tmd_primary_source_cache_file_exists`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2657|
|FAILED|`tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[count_literals]`|count_literal_population|True|UNQUALIFIED|2658|
|FAILED|`tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[numerical_literals]`|numerical_literal_corpus|True|UNQUALIFIED|2659|
|FAILED|`tests/test_ratchets_have_zero_headroom.py::TestRatchetsHaveZeroHeadroom::test_population_equals_ceiling[bundle_tables_use_pipeline]`|manual_table_corpus|True|UNQUALIFIED|2660|
|ERROR|`tests/test_readiness_blocker_refs.py::test_fix_propagation_keeps_the_finding_id_it_already_has`|extractdeps_environment_cascade|True|UNQUALIFIED|2699|
|ERROR|`tests/test_readiness_blocker_refs.py::test_the_refs_carry_the_routing_fields_the_operator_needs`|extractdeps_environment_cascade|True|UNQUALIFIED|2700|
|ERROR|`tests/test_readiness_blocker_refs.py::test_an_absent_lane_reads_unclassified_and_never_a_default`|extractdeps_environment_cascade|True|UNQUALIFIED|2701|
|ERROR|`tests/test_readiness_blocker_refs.py::test_the_evaluator_no_longer_truncates_before_it_counts[blocked]`|extractdeps_environment_cascade|True|UNQUALIFIED|2702|
|ERROR|`tests/test_readiness_blocker_refs.py::test_the_evaluator_no_longer_truncates_before_it_counts[needs-recheck]`|extractdeps_environment_cascade|True|UNQUALIFIED|2703|
|FAILED|`tests/test_readiness_cannot_measure.py::TestUncomputableGatesWithholdGreen::test_healthy_path_returns_a_mapping`|extractdeps_environment_cascade|True|UNQUALIFIED|2661|
|FAILED|`tests/test_readiness_gate_measured.py::TestTheReaderHasAProductionCaller::test_an_unmeasured_gate_reaches_the_log`|extractdeps_environment_cascade|True|UNQUALIFIED|2662|
|FAILED|`tests/test_readiness_gate_measured.py::TestTheReaderHasAProductionCaller::test_a_measured_gate_is_SILENT`|extractdeps_environment_cascade|True|UNQUALIFIED|2663|
|FAILED|`tests/test_shor_tgate_count.py::test_primary_source_cache_file_exists[BabbushGidneyEtAl2026ECC256Shor]`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2664|
|FAILED|`tests/test_shor_tgate_count.py::test_primary_source_cache_file_exists[BravyiKitaev2005MagicState]`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2665|
|FAILED|`tests/test_template_contract.py::test_each_tab_returns_200_with_its_own_panel_active`|extractdeps_environment_dashboard_cascade|True|UNQUALIFIED|2666|
|FAILED|`tests/test_template_contract.py::test_exactly_one_panel_is_active_per_request`|extractdeps_environment_dashboard_cascade|True|UNQUALIFIED|2667|
|FAILED|`tests/test_template_contract.py::test_a_partial_backed_tab_carries_its_own_partials_marker`|extractdeps_environment_dashboard_cascade|True|UNQUALIFIED|2668|
|FAILED|`tests/test_template_contract.py::test_the_default_tab_matches_the_servers_own_default`|extractdeps_environment_dashboard_cascade|True|UNQUALIFIED|2669|
|FAILED|`tests/test_validate_prose_checks.py::TestLiveRepoSmoke::test_prose_theorem_reference_coverage_passes`|prose_reference_corpus|True|UNQUALIFIED|2670|
|FAILED|`tests/test_validate_public_surface.py::TestNumericalLiteralPopulationComposition::test_ceiling_matches_the_live_population`|numerical_literal_corpus|True|UNQUALIFIED|2671|
|FAILED|`tests/test_validate_public_surface.py::TestTexQuoteReferencesAreExtracted::test_d7_no_longer_cites_a_nonexistent_theorem`|stale_D7_regression_already_repaired_primary|True|UNQUALIFIED|2672|
|FAILED|`tests/test_w_state_qft.py::test_dur_vidal_cirac_primary_source_cache`|external_workspace_citation_cache_fixture|False|PRECHANGE_SELECTED_STATUS_REPRODUCED|2673|

## Current emitted populations and planner routing

Current extraction-independent or mixed corpus diagnostics report module absence185/147, long sentences23/18, unattributed required57/44, scored apex636/634, apex numeral omissions35/31 (prior triage reported33), vacuity19/20, handwritten tables15/1, spelled census67/71, count literals89/95, legacy unresolved94/90, malformed Verify56/272 and numerical literals150/117. These are exact current output observations; shared prior IDs do not make populations identical. Elided required-per-bundle rows and cited keys still require existing full producer diagnostics in a qualified environment.

Existing planner: infra; src/core/provenance.py; `review:2026-07-31-1730-internal-adversarial:D12:2.2`, `review:2026-07-31-1823-internal-adversarial:D12:2.1`, `review:2026-07-31-2022-internal-adversarial:D12:2.1`, `review:2026-07-31-2103-internal-adversarial:D12:2.1`, `review:2026-07-31-2220-internal-adversarial:D12:2.1`, `review:2026-08-14-l1-stage13:L1:2.1`.

Existing planner: infra; src/core/constants.py; `review:2026-08-12-substrate-lane-refile:substrate-lane-refile:3`, `review:2026-08-14-l1-stage13:L1:2.3`, `review:2026-08-15-apex-claims-unbacked:infra:1.6`.

Existing planner: prose; papers/L1/paper_draft.tex; `review:2026-08-14-l1-stage13:L1:3.4`, `review:2026-08-14-l1-stage13:L1:5.3`.

Existing planner: lean; lean/SKEFTHawking/GravitationalWaves.lean; `review:2026-08-14-l1-stage13:L1:4.2`.

Existing planner: lean; lean/SKEFTHawking/GravitationalWaves.lean (+1); `review:2026-08-14-l1-stage13:L1:3.3`.

The supplied canonical planner receipt is read-only evidence. Its local slot count0 grants no lease, retarget, reclamation or alternate native route. Source-scoped finding targets require ROOT reconciliation before dispatch.

## Source repair location limits

Read-only ancestry checks confirm06c7d8eb2 and30b82f375 in primary4fca,1550f5ff1 in publicatione383, and6a6cd7ee6 in primary4fca. These named commits are not ancestors of current9d645 or maince194. f28cc370f andb8f352bd8 are historical repair candidates from prior readback, not ancestors of any of these four pinned heads; source-equivalent reconciliation elsewhere is not ruled out. JSON records per-file SHA256 for maince194/publicatione383/primary4fca/candidate9d645/working tree and separately marks missing pathsnull. Review actual repair composition before reuse; no whole-tree absence claim.

Final SAME-packet continuity check: fresh=true, changed=[]. No repository/notebook/Git/runtime mutation performed.
