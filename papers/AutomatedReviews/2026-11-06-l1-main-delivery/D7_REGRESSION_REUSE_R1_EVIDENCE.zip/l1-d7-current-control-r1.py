from pathlib import Path
import sys,os,subprocess,json,tempfile,hashlib,base64,datetime
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from seed_journal import seeded_mutation,outstanding
assert not outstanding(include_live=True)
p=root/'papers/D7/paper_draft.tex';s=p.stat();before={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':s.st_mode,'mtime_ns':s.st_mtime_ns};runs=[]
def run(label):
 with tempfile.TemporaryDirectory(prefix='l1-d7-actual-fresh-bytecode-') as cache:
  argv=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider','tests/test_validate_public_surface.py::TestTexQuoteReferencesAreExtracted','--junitxml=/tmp/l1-d7-control-'+label+'.xml']
  q=subprocess.run(argv,cwd=root,env=dict(os.environ,PYTHONPYCACHEPREFIX=cache,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,timeout=60)
  runs.append({'label':label,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'rc':q.returncode,'stdout_base64':base64.b64encode(q.stdout).decode(),'stderr_base64':base64.b64encode(q.stderr).decode(),'stdout':q.stdout.decode(),'stderr':q.stderr.decode()});print(label,q.returncode,flush=True);return q.returncode
report={'scope':'Actual current D7 citation-regression controls only; saved name index not native/kernel acceptance','before':before,'runs':runs}
try:
 assert run('baseline')==0
 def mutate(x):
  a='theorem analog_hawking_fourCycleFree_demarcation';assert x.count(a)==1;return x.replace(a,'theorem missing_D7_headline_seed')
 with seeded_mutation(p,mutate,reason='Known-present current D7 headline removal must fail source-backed regression'):
  report['seeded_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();assert run('missing_headline')==1
 assert run('restored')==0
 s=p.stat();after={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':s.st_mode,'mtime_ns':s.st_mtime_ns};assert before==after;report['after']=after;assert not outstanding(include_live=True);report['journal_empty']=True
finally:
 Path('/tmp/l1-d7-current-control-r1.json').write_text(json.dumps(report,indent=2)+'\n')
