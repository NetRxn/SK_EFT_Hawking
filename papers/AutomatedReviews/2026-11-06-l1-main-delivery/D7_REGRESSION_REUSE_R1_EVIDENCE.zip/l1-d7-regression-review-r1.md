# Independent D7 regression review r1

Verdict: ACCEPT for the exact static test repair only. No necessary corrections.

Task: l1-d7-regression-review-r1; parent: publication-remediation; reviewer: l1_d7_regression_review. ROOT is notebook writer and acceptance reviewer. Outputs owned only at /tmp/l1-d7-regression-review-r1.md and .json. No repository edits were made.

Candidate: /tmp/l1-d7-regression-candidate-r1.py
SHA256: 7a417431b8ea94ebea77e7ac7974ff003617225ae64ec0cd404539e06a22cc8f
Historical donor: 06c7d8eb28541f9b664350f17594a61336ec8a2f.
Supplied patch SHA256: ac9882d09b8820b241f956c9c57c3260de9e23fe9ad17c48d5231173f684a533.

## Contract and exact conservation

First action was the required packet check; fresh=true, changed=[]. Read packet, referenced primary AGENTS/CLAUDE/pipeline/continuity/ADR guidance, primary roadmap current L1 section, notebook latest qualification contract, original finding, candidate, historical patch and actual relevant source. Primary roadmap retains physical B3/dynamics/transport OPEN BUILD. Notebook freezes source and restricts this to existing D7 test reuse.

Read-only git show confirmed the supplied patch is exactly the donor commit's test-file patch. A standard-library difflib comparison of changed preimage/postimage regions confirmed candidate changes are byte-identical to the donor's test changes. The sole differences from current file are the new parametrized phantom test and replacement body of test_d7_no_longer_cites_a_nonexistent_theorem (current lines 538 onward). Every unrelated byte is conserved. Existing Path import at line 58 supports the updated body. EXPECTED_SURFACE is AST-identical, including check_architecture_inventory_fresh at line 70. Candidate AST parses; this is syntax inspection, not test execution.

## Actual present-source witnesses

- papers/D7/paper_draft.tex:1055-1064 has a verbatim theorem block headed analog_hawking_fourCycleFree_demarcation at line 1056, followed by the nonnegative-weight, zero loop-rate and Chern-equality statement.
- lean/SKEFTHawking/AnalogHawkingDemarcation.lean:143-156 contains the actual headline declaration, binders and proof via fourCycleFree_nonneg_iff_ldp_rate_zero and crystalline_eq_quasicrystalline_iff_c1_zero. This is positive source evidence, not inference from an absent grep match.
- The separate actual long companion analog_hawking_simulable_iff_fourCycleFree_and_nonneg_and_c1_zero exists at line 164 with its binders and constructor proof. The old regression's escaped prefix is therefore not evidence of a missing companion theorem; it is the wrong expected current manuscript citation.
- Plain JSON parsing of lean/lean_deps.json finds exact fully qualified headline and companion theorem records in SKEFTHawking.AnalogHawkingDemarcation. Both saved records have axiom_deps_project=[] and core axioms Classical.choice, Quot.sound, propext. This is saved cache evidence only; freshness/kernel verification was not run.
- The same cache has no declaration name containing analog_hawking_quantum_advantage_demarcation. Full runtime absence resolution was not executed; negative behavior is reviewed from code and remains for ROOT to verify.

## Reviewed positive and negative conditions

1. Three independent parametrized inputs cover escaped TeX quote, escaped texttt, and plain verb delimiter spelling of the obsolete phantom. Each asserts real _prose_verbatim_tokens extraction through the existing _tokens helper AND ABSENT from the existing production resolver/index. They do not substitute a hand-built fake name index or mock success.
2. The current manuscript test rejects the phantom after existing unescape_tex_identifier removes escapes, retaining rejection of both plain and escaped spellings across the actual manuscript. It requires the current headline immediately after begin{verbatim} and theorem, with a word boundary, rather than accepting arbitrary prose mention.
3. The same positive requires the fully qualified name in index names, an actual unindented theorem declaration spelling in current Lean source, and OK from production _resolve_prose_ref(current,index,deep=False). It also requires phantom ABSENT against that same production index.
4. Inspection of prose_lean_refs.py:338+ confirms _load_lean_name_index calls validate_helpers.load_lean_deps. validate_helpers.py:98-110 parses JSON directly and explicitly does not trigger the hash-refresh extractor. The index also reads counts and registry/formula keys. Resolver at line 517+ returns OK for present indexed names/suffixes before source scans; deep=False would not permit source fallback to rescue a missing cache declaration. Phantom deep=True additionally scans project and optional PhysLib source through existing read-only functions, with no build/download call in these functions.
5. These conditions reject manuscript headline removal/rename, phantom reintroduction, missing exact indexed headline, missing source declaration, failed positive production resolution, or phantom becoming resolvable. Runtime mutation sensitivity has not been measured in this assignment.

## Scientific and acceptance boundaries

This changes tests only; manuscript, Lean proofs, production validator, registries, ceilings, routing and scientific claims remain byte-exact. Lean source explicitly states four-cycle freeness is a necessary combinatorial screen weaker than a tree, not proof of classical simulability. This test repair introduces no stronger physical interpretation. The source regex is a textual presence guard rather than a semantic Lean elaboration check; the saved depcache is not a fresh kernel witness.

No tests, project imports, seeded mutations, native commands, builds, runtime/controller operations, cache repairs, finding closure, Git mutations, commits, pushes or notebook edits were executed. Commands were required continuity checks, read-only cat/sed/rg/head/wc and git show/diff inspection, plus standard-library Python AST/JSON/hash/diff inspection. git diff --no-index returned the expected difference exit status 1; it was inspection, not a failed test.

ROOT must apply the exact accepted delta, execute the original Verify (complete TestTexQuoteReferencesAreExtracted class), reproduce the actual failing baseline and meaningful runtime negative controls through the existing authorized journal, restore exact source bytes/state, and use ordinary integration/closure. This ACCEPT does not grant native authority or close broader paper debt. No fresh-kernel, full D7, G11, whole-tree/main qualification or publication acceptance is claimed.

## Final same-packet check

Repeated the SAME original packet check after inspection: exit 0; fresh=true; changed=[]; task=l1-d7-regression-review-r1; meaning="Input snapshot matches; no execution or completion authority." Reports are outside the frozen packet source and do not refresh or replace its authority.
