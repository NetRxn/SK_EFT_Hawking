# D7 actual current acceptance review r2

Verdict: ACCEPT for the scoped D7 citation regression repair, actual application and supplied runtime controls. No necessary corrections. This is not full-module, native/kernel, physical D7, simulability, G11, main or publication acceptance.

Task l1-d7-regression-current-acceptance-r2, parent publication-remediation. ROOT remains notebook writer, integrator and acceptance/closure owner. Only this report and its JSON were written.

## Current authority and conservation

FIRST action: python3 scripts/codex_continuity.py check the NEW primary packet l1-d7-regression-current-acceptance-r2.json. Exit 0, fresh=true, changed=[]. Read new packet, latest primary notebook and referenced authority/roadmap boundaries; earlier unchanged guidance and exact historical delta review remain applicable. Current notebook explicitly retains native/extraction/physical/main gates and numeric debt.

Actual tests/test_validate_public_surface.py is byte-identical to the reviewed /tmp candidate with SHA256 7a417431b8ea94ebea77e7ac7974ff003617225ae64ec0cd404539e06a22cc8f. Read current full delta against HEAD; it is the same prior accepted donor delta from 06c7d8eb28541f9b664350f17594a61336ec8a2f. HEAD test preimage SHA256 is e96852a18276697e45d3239126966e2e63b34d8b8ad53a3348d6eda958fe3d95. Unrelated test bytes, existing Path import and check_architecture_inventory_fresh surface entry are conserved.

Read-only git inspection shows only the intended tracked test modification and restored untracked canonical finding directory. Actual production prose_lean_refs.py, validate_helpers.py and _tex.py, Lean source, manuscript and lean_deps.json all equal HEAD bytes. The original static report remains unchanged. No science/validator/registry/ceiling change is introduced.

## Original finding and portable Verify

Canonical finding papers/AutomatedReviews/2026-10-15-d7-current-theorem-regression/infra.md SHA256 2edb0edce6aea3ca4ca84f121959a13f5b9ad25bc60fe53f10819421b6e7e98f retains ID 1.1, minor severity, infra lane, location and original substantive requirements. Comparison with /tmp/l1-d7-regression-original-finding-r1.md proves all original requirements byte-identical after replacing the one Verify interpreter prefix and removing the added environment explanation.

Verify now reads uv run --no-sync python -m pytest tests/test_validate_public_surface.py::TestTexQuoteReferencesAreExtracted -q. Same class and assertions are selected. The appendix explains managed-worktree UV_PROJECT_ENVIRONMENT selection and no dependency sync/kernel implication. This portable command is appropriate; its exact execution through the canonical close_finding.py writer remains ROOT's post-commit duty. Supplied execution receipts used the existing primary Python directly with -B and no pytest cache; they are not represented as canonical writer execution.

## Actual baseline and current class receipts

Parsed the XML files directly with the standard library, including every D7 testcase/failure, and cross-read the supplied JSON stdout/argv/return codes.

- /tmp/l1-inventory-public-surface-current-r1.xml: 70 tests, 68 passed, 2 failed, no errors/skips. The old D7 failure is exactly the absent escaped analog_hawking_simulable_iff_fourCycleFree manuscript prefix at old line 543. The other failure is numerical literal 15+135 >117. This is the actual unchanged preimage defect, not a claim that its long Lean companion is absent.
- /tmp/l1-d7-current-class-r1.xml: all 7 tests passed. Includes three separate parametrized phantom-format cases, the real current manuscript/source/index/resolver positive, and original quote/ordinary-English/dotted extraction guards.
- /tmp/l1-d7-current-module-r1.xml and matching JSON: 73 tests, 72 passed, 1 failed, no errors/skips, exit 1. Sole failure is unchanged numerical population 150>117. The 4-pass increase corresponds to repaired former D7 failure plus 3 added parametrized phantom cases. No full-module PASS is claimed.

## Meaningful production controls

Reviewed /tmp/l1-d7-current-control-r1.py in full without executing it. It uses the existing seeded_mutation journal, checks no outstanding entries before/after, runs the complete actual D7 class with a fresh temporary bytecode prefix, -B, PYTHONDONTWRITEBYTECODE=1 and disabled pytest cache. It requires actual baseline rc0, actual mutation rc1, and restored rc0. Mutation replaces exactly one known-present actual paper headline theorem name with missing_D7_headline_seed; it is not a fake manuscript fixture or mock resolver.

The JSON report and all three phase XML files agree:

1. baseline: exit0, 7 PASS;
2. missing_headline: exit1, 1 FAIL/6 PASS; the only failure is test_d7_no_longer_cites_a_nonexistent_theorem at the intended current verbatim headline assertion (line566), with the expected message D7 must cite its current headline declaration in the theorem block;
3. restored: exit0, 7 PASS.

All three phantom spelling inputs continue to pass in all phases. Each exercises actual extraction plus ABSENT from the production _load_lean_name_index/_resolve_prose_ref, without synthetic index or mocked result. This is meaningful negative resolution coverage for escaped quote, escaped texttt and plain verb spelling. The paper-removal seed independently proves the real current positive is required. No claim is made that all possible source/index/validator mutation families were exercised.

Report before/after both record paper hash 7ce4326306eeb4bb27cdcc614d963b3bb1558d9122955d43a58213c0904255de, full st_mode33188, mtime_ns1793929292721536141. Independent current stat/hash inspection matches BOTH records exactly. Current .seed-journal/*.json entries are empty, agreeing with the report's journal_empty=true. The journal implementation restores on normal/exceptional exit; no source mutation was performed by this reviewer.

## Actual theorem/source boundaries

Current D7 verbatim block begins at paper line1055, headline line1056. Actual Lean headline is at line143 with full binders and proof via the existing four-cycle-rate and Chern bridge lemmas; actual longer companion is at line164. Both saved fully qualified theorem records remain in lean_deps.json (SHA256942279d0b9a4480b6396acd0717a1709a763aeee1a74289bfefbdb41d0664e6d), as positively verified in r1. This does not certify freshness of the saved extraction or kernel environment. The current notebook explicitly reports extraction stale, not refreshed.

Production _load_lean_name_index uses validate_helpers.load_lean_deps's direct JSON reader. The current positive requires the exact fully qualified index name, real Lean declaration spelling and production shallow OK; phantom checks require deep ABSENT through existing read-only source tiers. No production validator changed. The Lean honesty scope still says four-cycle freeness is a necessary combinatorial screen strictly weaker than a tree, not proof of classical simulability. This review grants no stronger physical interpretation.

## Remaining acceptance work and final continuity

ROOT still owns ordinary reviewed source commit/integration and canonical close_finding.py execution of the declared portable Verify. Numeric population debt 150>117, extraction freshness/native/kernel admission, all physical D7/L1 obligations, G11 and full main/publication gates remain OPEN. No closure ledger mutation has been reviewed or authorized by this report itself.

Reviewer commands were required continuity checks, read-only source/receipt/notebook inspection, git show/diff/status, and standard-library XML/JSON/hash/stat/comparison analysis. No pytest, project imports, seeded changes, native/build/controller/runtime/cache repair, Git mutation or notebook edit was executed. One read probe for optional /tmp/l1-d7-current-class-r1.json found no file; the required XML exists and was reviewed, so no acceptance evidence is inferred from that absent optional file.

Final SAME new packet check: exit0, fresh=true, changed=[], task=l1-d7-regression-current-acceptance-r2. No packet refresh was performed. This confirms frozen inputs, not broader execution or completion authority.
