# Numerical-literal source audit r1

Checkout HEAD `edb5de74a7400baf3ecc8e02c18782e136787fa4`; baseline `ce194cdc4bf939b108c17edc9530a7f0a14565f9`.

Both initial and final continuity checks are required; final result appended below. ROOT is sole primary-notebook writer; this audit writes only the two assigned /tmp reports.

## Finding and attribution

Actual existing `validation._tex.find_inline_numerical_literals` with `validate_helpers.all_paper_drafts` gives **150 =15 unit +135 times**. Same predicate over original-main Git-object texts gives **149 =15 unit +134 times**. Both select the same64 `papers/*/paper_draft.tex` files; no additions/removals. The117 ceiling is exceeded by33 now and32 at original main. Thus this is principally inherited source debt, with net+1 in current composition. It is not a test-predicate or floor regression.

Only two files change their matching population: L1 6→3 (-3); paper25 4→8 (+4). All other positive per-file populations below are identical at original main. Matching strings alone stop at `\times10^`; the JSON retains complete exponent/unit/source-line contexts for every occurrence, both baseline and current. Its line numbers use the gate’s stripped-text offsets.

| File | Baseline | Current | Delta |
|---|---:|---:|---:|
| `papers/D1/paper_draft.tex` | 38 | 38 | +0 |
| `papers/D4/paper_draft.tex` | 1 | 1 | +0 |
| `papers/D5/paper_draft.tex` | 7 | 7 | +0 |
| `papers/D6/paper_draft.tex` | 14 | 14 | +0 |
| `papers/D9/paper_draft.tex` | 11 | 11 | +0 |
| `papers/E2/paper_draft.tex` | 1 | 1 | +0 |
| `papers/F/paper_draft.tex` | 5 | 5 | +0 |
| `papers/L1/paper_draft.tex` | 6 | 3 | -3 |
| `papers/paper12_polariton/paper_draft.tex` | 2 | 2 | +0 |
| `papers/paper1_first_order/paper_draft.tex` | 2 | 2 | +0 |
| `papers/paper21_majorana_rung/paper_draft.tex` | 1 | 1 | +0 |
| `papers/paper23_linearized_efe/paper_draft.tex` | 2 | 2 | +0 |
| `papers/paper25_gravitational_waves/paper_draft.tex` | 4 | 8 | +4 |
| `papers/paper2_second_order/paper_draft.tex` | 15 | 15 | +0 |
| `papers/paper32_strong_cp_de/paper_draft.tex` | 11 | 11 | +0 |
| `papers/paper34_equivalence_principle/paper_draft.tex` | 4 | 4 | +0 |
| `papers/paper37_chiral_ssb/paper_draft.tex` | 9 | 9 | +0 |
| `papers/paper39_heat_kernel_expansion/paper_draft.tex` | 2 | 2 | +0 |
| `papers/paper42b_cc_emergent/paper_draft.tex` | 9 | 9 | +0 |
| `papers/paper43_einstein_cartan/paper_draft.tex` | 4 | 4 | +0 |
| `papers/paper4_wkb_connection/paper_draft.tex` | 1 | 1 | +0 |

The remaining43 selected files have zero matches at both revisions.

## Exact changed-file values

L1 baseline: four width occurrences `1.2×10^-14`, endpoint ratio `2.28×10^14`, endpoint ratio `7.21×10^14`. Current: relative width `1.2×10^-15` once; absolute width `1.2×10^-14` twice. These count changes accompany the conditional source corrections; source comparison does not justify restoring misleading physics to regain counts.

paper25 baseline: width `1.2×10^-14` twice; endpoint ratios `2.28×10^14` and `7.21×10^14` once each. Current: width twice; detailed endpoint ratios once each; rounded ratios `2.3×10^14` and `7.2×10^14` twice each (abstract and caption continuation). The predicate deliberately strips captions with its existing shallow regex; the continued caption’s ratio lines remain detected. Do not alter that existing detection behavior.

## Reuse existing machinery and accepted repair pattern

`docs/WAVE_EXECUTION_PIPELINE.md` Stage12 specifies `papers/<key>/tables.py` → `scripts/render_paper_tables.py --paper <key>` → `papers/<key>/tables/<id>.tex` → `\input{tables/<id>.tex}`. `scripts/render_paper_tables.py` already supports both TABLES and SCALARS; `_load_spec`, `_spec_ids`, `spec_output_paths` own discovery/output relationships. No new registry, macro framework, exemption or parser is needed.

`papers/D3/tables.py` is the exact scalar-provenance pattern: SCALARS value lambdas read constants/formulas, produce formatted math fragments, end value text with `%` to consume trailing newline, and drafts use `\input{tables/id.tex}\unskip`. Reuse framework, data owners and formatting approach, not D3’s unrelated physics.

Commit `d8ea552f5be686128761b6da37f0e288af7c298e` introduced16 rendered D3 scalar specs and removed13 counted computed literals. Its explicit boundary: rational constants belonging to kernel-checked theorem statements stay literal; Python rederivation must not become the authority for a theorem’s own statement. Current `scripts/validation/_tex.py` D37 commentary independently states the same source-anchored/theorem-vs-derived distinction and rejects narrowing the dimensionless scientific-notation leg.

Commit `521f574e91bc0bdf6cfea4bff160f0697e6eb1c4` later reused D3 scalar infrastructure while reconciling reviewed GW repairs. It did not create L1/paper25 specs. No prior exact L1/paper25 scalar retrofit was found in the inspected relevant history. This is bounded history inspection, not an all-objects theorem of absence.

## Coherent minimum repair recommendation

1. Retrofit the11 existing GW occurrences using existing SCALARS, preserving all conditional wording and primary-source/theorem constants. Use `GW_PARAMS` as adopted parameter owner, `c_GW_deviation_from_c` / `ligo_compatibility_check` for endpoint ratios, and algebraic width `4*tau` for tau≤1. Reuse existing D3 width strategy: avoid subtracting rounded near-unity endpoints. Scalar snippets for L1 relative width and paper25 rounded/detailed endpoint ratios may differ only in precision, with the same underlying canonical inputs. This is source/provenance correction to existing substrate; it does not derive an action, tensor mode, physical frequency normalization, transport or natural range. Original BUILD remains owed.

2. The resulting139 still exceeds117 by22. A separate coherent D1 derived-value retrofit is the strongest existing-substrate candidate: D1 has38 currently matching sites, including six platform table cells, repeated correction magnitudes, and graphene prediction/noise/frequency evaluations. Existing producers include `src.core.formulas.hawking_temperature`, `beliaev_transport_coefficients`, dispersive corrections and graphene formulas; `scripts.paper_tables.sources.platform_rows` shows how to obtain canonical platform backgrounds/transport. A D1 TABLES/SCALARS spec can own these evaluations with stated operating points. Inspect current values against those producers before edits, preserve scientific claims and fix actual value mismatches rather than echoing literals into generator lambdas. At least22 additional actual matches must be removed if step1 is used; migrate the complete coherent derived families rather than selecting arbitrary22 just to pass.

D1 includes literal source measurements (e.g. polariton reported0.07/0.08/0.11 ps^-1, 2.3/1.8 meV) and adopted/theorem constants; those are not automatically computed debt. Every such site needs D37’s explicit classification. If the properly classified computed subset does not supply22, keep the failure visible and plan another genuine provenance package through the existing remediation planner. No new routing ledger or floor increase.

3. Do not casually choose paper2’s15 cells as easy debt: `papers/paper2_second_order/tables.py` and `docs/PAPER_TABLES_STATUS.md` explicitly defer its off-shell Bogoliubov correction table pending a physics convention/Lean-backed source. A raw literal-to-spec copy would hide debt without establishing freshness. paper37 is also primarily published PDG/FLAG constants mixed with derived GMOR values. paper42b mixes observed/source inputs and computed values. They need scientific source classifications before retrofit.

## Classification and future proofing

The150 census is an engineering qualification witness, not evidence that all150 values are scientifically false. Existing scientific obligations remain separately BUILD, CORRECT-TO-SUBSTRATE or FACTUAL under the substance-first remediation plan. Generating conditional arithmetic is CORRECT-TO-SUBSTRATE/provenance work. Unsupported measured/provenance claims remain FACTUAL; microscopic derivations remain BUILD. No computed file may transform adopted inputs into measured results or discharge BUILD by a scope caveat.

Future proofing already exists: renderer discovers specs, SCALARS outputs are in freshness ownership, manuscripts input values, and the unchanged detector/test/frozen ceiling enforce the debt. Once a complete scientifically reviewed source retrofit brings the census below117, tighten the ceiling to the measured actual population in that same repair per existing down-only policy. Do not raise it, narrow matching legs, exclude corpus paths, or adjust tests. No additional infrastructure is indicated by this audit.

ROOT should independently review source classification/operating points and renderer outputs, then run actual change-appropriate gates and compilation. This audit did not run them. Full project/publication acceptance and original BUILD are unchanged.

## Limits

- Read-only existing helper imports via primary virtualenv and Git-object/source reads; no tests, renderer, validation runners, plotting, native work, builds, network, controller or repository mutation.
- Full occurrence inventory including every baseline/current context is in companion JSON.
- Producer suggestions are source inspection only, not recalculation or primary-source adjudication.
- D7 belongs to the independent reviewer and was not re-audited.
- Initial continuity check was fresh with no changed inputs. Final check follows.

Final continuity check: **fresh=true; changed=[]**. It certifies only input snapshot conservation; no execution, review, lease or completion authority.
