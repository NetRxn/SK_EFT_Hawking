# Complex auxiliary proof worker return

Task `publication-l1-complex-auxiliary-proof-r1`; parent `publication-remediation`.
Worker `complex-auxiliary-wt1-worker`, public codex wt1.
ROOT alone writes the primary notebook:
`/Users/johnroehm/Programming/PythonEnvironments/Physics/Fluid-Based-Physics-Research/SK_EFT_Hawking/.codex/continuity/publication-remediation-notebook.md`.
Owning roadmap is the packet-pinned cumulative Phase6a continuation; primary roadmap remains older source context. Original design, independent prospective approval and complete original 98-line auxiliary construction govern this implementation.

Candidate: `e0c51ec2ed709c30a2d331fe0a52edd50a84bc39` on `worktree-wt1`, parent source `2c201cd00cd1d17e7665ea0a6711344abc1c1524`.
Only new assigned file `lean/SKEFTHawking/ADW/GaussianAuxiliaryComplex.lean`, 624 lines, SHA256 `91b9884a4194980538b2889f8b57f6c09cf995dfdfa1db71241c00723472375f`. Clean worktree; no aggregate/import registry/notebook changes.

## Result and exact strength

A-D implemented without shrinking the approved contract. Arbitrary `P : MvPolynomial ι ℂ`, all finite coordinate types including empty, every positive sigma, actual product Gaussian probability with variance v=sigma², every Finsupp multiindex beta and arbitrary polynomial degree.

- A: explicit finite Hermite weight with inverse sigma-degree and unmodified complex coefficients; actual independent Bochner integrability of W times every coordinate monomial, and W itself.
- B: raw affine-product integral, coordinatewise off-order vanishing, full scale/product-factorial cancellation, all-order centered Gaussian recurrence/even/odd moments, and normalized integral coefficient convolution. Headline `integral_auxiliaryWeight_mul_monomial_normalized`.
- C: actual `PowerSeries.subst Q (PowerSeries.exp ℂ)`, proved zero constant and HasSubst; independent coefficient theorem `auxiliaryGaussianSeries_coeff`. Existing Mathlib coordinate-squaring expand plus polynomial multinomial theorem isolate the unique exponential summand and cancel its factorial. No replacement Gaussian series defined by desired coefficients.
- D: `auxiliarySeries` is defined only by actual normalized integrals. `auxiliarySeries_eq_exp_quadratic_mul` proves the complete formal series equality using B and C.

All seven approved control categories carry actual theorem/integral instances. Quadratic sigma2 normalized values are 1,I,0,2I,-2 and raw order4=-48. Mixed coordinate controls force product factorials; off-order controls vanish for (2,0) versus (1,8) and 5 versus4. Degree7 preserves I and raw5040I, with explicit sigma2 and sigma1/2 high-tail coefficients 2I and I/8. Empty Fin0 preserves -2+3I. All-sigma diagonal and mixed controls establish scale cancellation. Unweighted all-sigma orders0..4 force the positive quadratic sign.

## Actual verification

Matching wt1 MCP only, sequential calls; JSON companion includes 105 directly captured request/response records including failing discovery/candidate attempts and final checks. One early moment-name search response was initially only in the conversation; its identical actual query was replayed and the complete replay response is included transparently as the final record.

Final file diagnostics: success=true, items=[], failed_dependencies=[], timed_out=false. All 40 theorem exports individually checked with lean_verify: precisely propext, Classical.choice, Quot.sound; warnings=[] throughout. Core proof-state calls show closing goals and the final recurrence multi-attempt has three successful zero-goal alternatives. No sorry, native_decide, heartbeat override or project axiom. A temporary run_code heartbeat failure came from ambiguous nested casts; explicit real-to-complex annotations fixed it without a heartbeat change.

Only the assigned file was staged. Staged diff check passed. Standard git commit succeeded; leak guard ran, and the existing worktree hook explicitly skipped main-oriented sync for lead integration. No worker shell build, lean_build, clean/cache/dependency repair, controller mutation, integration, push or shared notebook write occurred.

## Authority and continuity

Initial assigned packet check: fresh=true, changed=[].
Required primary slotctl census under the restricted observer returned ps/loopback observation errors. ROOT reconciled using its actual unrestricted complete/noerrors/noconflicts ACTIVE/public/codex epoch85a44ba7 receipt and native 21-tool probe. First guessed GaussianAffine filename was wrong and returned a path validation error; corrected GaussianPolynomialAffine outline succeeded and exposed real typed APIs. No lifecycle repair was attempted.

Final identical packet check correctly returns fresh=false, changed=[owned-files,source], due to the expected assigned implementation and commit. Worker did not refresh it. Source is frozen for ROOT's deliberate reconciliation and new review packet.

## Remaining acceptance boundary

No mathematical A-D obligation remains in the assigned source candidate. Fresh independent source/kernel review and ROOT authoritative aggregate/import integration, module build, extraction and project gates remain required; worker MCP checks are not native integration or publication acceptance.

Original Eq4 compensation/truncation, actual Grassmann algebra/coframes/even commutation/nilpotence/evaluation, source matrix signs/Berezin determinant, compact-link continuity and integral exchanges, Eq11 weighted insertion, normalized-observable Z nonzero, and physical B3/state/domain/source/response/dynamics/transport remain downstream OPEN. No positive sampling measure or scalar physical reduction is inferred.

