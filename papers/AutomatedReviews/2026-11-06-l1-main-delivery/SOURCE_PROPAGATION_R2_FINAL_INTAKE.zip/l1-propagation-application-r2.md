# Independent actual L1 propagation application R2

Verdict: **ACCEPT_SCOPED_ACTUAL_APPLICATION**. No necessary repair identified in this actual six-file documentary application. This is a new application review, based on actual carrying files, generated output and execution receipts; proposal acceptance alone was not treated as application evidence.

Candidate: f144749d795f904e563a83c869b0dee27bdbbd99 plus the frozen six-file applied diff and evidence artifacts. First check of primary `.codex/continuity/l1-main-propagation-applied-r2.json` was fresh. Exact file/archive/member hashes are in the companion JSON.

## Actual source and generated-view verification

Independently verified every applied original/proposed hash, current file equality with the five reviewed proposal copies, archived preimage equality with HEAD, and exact six-path tracked diff roster. Both SOURCE_PROPAGATION_R2 archives pass CRC checks. The five-file patch remains SHA2561dd24a9bf0aca1dbabfd719247e867693449598ebef2761090ad2e6f620dd5df. The actual generated hypothesis view is SHA2569887ebc65a2a2b2314c18e18034bf47d193df8a749981c0d2812fc84cfda7d1d.

Recomputed actual-before/after AST invariants independently from the archived preimages and current files: only genuine docstrings, the single specified test rename, four narrative fields in the one hypothesis record, and explicitly allowed citation summary fields are normalized. Whole normalized executable ASTs agree. Ordered assertion ASTs agree: constants1, formulas1, GW tests165, citations0. No code/proof/value/test-strength change is present. Proposal-stage historical caveat/metadata/anchor checks transfer through proved exact byte equality, not assumed approval.

Read the actual generated H_VestigialModeIsGraviton entry and renderer source. Only its four scientific narratives changed; all bytes outside this one entry are identical to the archived/HEAD view. Each rendered statement/posture/discharge-path/source string equals the corresponding actual registry value. Status active, eliminability open, module, risk and tier grouping survive. The derived text correctly states scalar compatibility, P2-dependent clauses and one-way quarter-witness logic, assumed speed law, source-model-limited luminality and original physical BUILD. Its external_boundary tier is honest only as the explicitly stated present formalization boundary; it confers no deferral.

The prior independent scientific assessment remains applicable because the actual five source files equal the reviewed source bytes. Actual scalar proof types and primary-source qualifications have not changed. The finite compatible interior, exact4tau width, endpoint-only rejection, adopted rather than derived window, and unmatched product coefficient/frequency units survive. There is no new physics claim, dimensional identification, false independence or physical-mode construction.

## Actual execution evidence and limits

Personally read archived terminal test stdout: 124 passed in12.82s; stderr empty. ROOT's separately supplied `/tmp/l1-main-propagation-execution-receipt-r2.json` records session26218, terminal exit0, actual worktree cwd and the exact command using the primary existing environment:

`uv run --no-sync python -m pytest tests/test_gravitational_waves.py tests/test_dependency_declaration.py tests/test_seed_residue_guard.py -q`

UV_PROJECT_ENVIRONMENT points to the existing primary .venv and UV_CACHE_DIR to /tmp/skeft-uv-cache. Independently matched the receipt's stdout/stderr hashes to both actual temporary logs and archive members. Scope is those three test modules; it is not a full test run. The session's terminal metadata is attributed ROOT tool evidence, not a reviewer-executed job.

Archived actual hypothesis stdout gives2/2 PASS: tracked_hypothesis_ledger and tracked_hypotheses_fresh, with24consumed/24covered and48registry entries. The first renderer baseline attempt failed under plain Python because numpy was absent; the corrected existing-environment baseline returned FRESH, actual renderer wrote the view, and subsequent gates passed. Both raw baseline attempts remain preserved. This is an environment invocation correction, not suppressed scientific failure.

The ledger result measures stored-manifest/registry coverage, and freshness measures the generated view. It does not elaborate proofs or establish a new Lean/kernel/build result. Actual lean_deps.json and GravitationalWaves.lean are byte-identical to HEAD. Reviewer ran only read-only comparisons and git diff --check (PASS), not tests, renderer, seeding, native/slot/controller/DB/graph/dependency operations.

## Preservation and remaining acceptance

Actual L1/D3/Paper25 TeX, Lean source/manifest, L1 claims/audit/prose_state equal HEAD. All three actual PDFs equal the prior actual-render archive byte-for-byte, including the ignored D3 PDF; no claim is based on its absence from Git. The canonical and three consumer GW PNGs retain the prior actual hashcd3c1de52d177dd19ef6fb49d79319484c66674329624a1e6dd80702c1474976. No recompilation or new visual acceptance is inferred.

The current151-unit catalog and all four original blockers remain unchanged/open. ROOT still owes canonical current backing/claims/audit/finding reconciliation through existing writers; this reviewer does not close the aggregate propagation finding or modify human/history state. Proper scoped documentary disposition may follow the existing acceptance chain; it cannot close physical construction.

Original operator/source/projector/regulator/state, susceptibility normalization and justified physical range as a RESULT, stable constrained tensor/polarization dynamics, matter/light matching, physical transport/frequency/unit/error-control construction remain full-strength OPEN BUILD. Full exact-candidate project/publication/merge gates, D3 overflow and title/natural-range debts, and final human/publication acceptance remain separate and unwaived. No new source catalog, runner or routing ledger was introduced.

Reviewer wrote only `/tmp/check_l1_application_independent_r2.py`, `/tmp/l1-propagation-application-r2.md` and `.json`. The temporary helper is independent review scratch, not repository machinery. No working-tree file was touched.

Final same-packet continuity check fresh=true, changed=[]; review-document marker contract PASS.
