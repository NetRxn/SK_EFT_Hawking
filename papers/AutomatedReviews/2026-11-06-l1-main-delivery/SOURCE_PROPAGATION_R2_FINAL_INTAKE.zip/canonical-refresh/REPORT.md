# Scoped L1 canonical source-propagation refresh R2

Proposed existing canonical artifact: `/tmp/l1-main-canonical-propagation-refresh-r2/claims_review.json`, SHA256 `292ef58319215c0dd487e5333c9b1e136c14dba24a41ec521a95a44b3124787f`.

This refresh records applied documentary progress on existing `L1-fix-propagation`. It is explicitly NOT a new151sentence walk or scientific reassessment. All151sentence objects, assessment verdicts, IDs, chains, lineage and runIDs are byte-value-identical after JSON parsing. Original top-level review date/run and summary remain exact. Full scientific BUILD, title/natural-range tension, D3 overflows, fullG11 closure, current application acceptance, main/human/publication readiness remain open.

## Exact changes and preservation

Base canonical SHA256 is `a0a9e36b0a76ca1a768c9f3a168a5941f6b56599b184d70dcc5141df7a7ffef8`. Only three child objects are appended:

- `/review_scope/source_propagation_scoped_r2`
- `/review_evidence/source_propagation_scoped_r2`
- `/blocking_issues/3/source_propagation_progress_r2`

Removing exactly those three children reproduces the entire original parsed catalog exactly. This is stronger than comparing only selected sentence fields. Every preexisting field/object is unchanged, including all four blocker statuses/identities/summary/anchors, prior followups and supersession candidates, complete historical69mainrecords/5followups and donor151/54provenance. No closure, human ratification or donor acceptance is introduced. `preservation.json` names these allowed paths, hashes the unchanged sentence array/summary and records actual current audit/prose state hashes.

Current audit SHA256: `d87669616f4500c35532298c741340883a221cfbe43724d4d75444c18419ecf7`.
Current prose_state SHA256: `f3e0464c5745c6dc0fe11558709d2ed9eff7ba0445f00973ae7385ffc1616627`.
Neither file was written. The originalR1 report's absent prose_state observation remains correctly historical; current state created by ROOT's existing intake is pinned here, not seeded from donor history.

## Actual backing inspected

First same-packet continuity check of primary `l1-main-propagation-applied-r2.json` returned fresh. Actual HEAD is `f144749d795f904e563a83c869b0dee27bdbbd99`, plus frozen six-file composition. Personally read the actual diff, current scalar hypothesis record, GW helper docstrings and renamed test, citation summary/edition limitations, corrected L1 anchor, and generated hypothesis view. Read R2 proposal/independent scientific review and carrying receipt members in `SOURCE_PROPAGATION_R2_EVIDENCE.zip`; all archive members passCRC and have hashes embedded in proposed evidence. No archive full-primary texts are copied.

All five actual carrying file hashes equal the exact archived independently accepted proposal hashes. The sixth changed file is the existing generated `docs/PERMANENT_TRACKED_HYPOTHESES.md`, whose changes describe the same scalar predicate and retain active/open/external_boundary taxonomy while explicitly denying deferral of original physical BUILD. It no longer presents scalar satisfiability as a physical graviton construction or calls the original bridge out of scope.

The applied documentary surfaces now correctly distinguish assumed scalar speed law, adopted normalized response/window, unevaluated RPA inputs, dependent scalar clauses and one-wayP1↛P3 counterexample, unmatched gamma*omega transport/frequency conventions, source-specific graviton interpretations, primary edition limits and endpoint-only confinement with finite interior. The unchanged legacy risk description remains subordinate to the explicit scalar-only statement/prose; it does not revive physical nonvacuity acceptance.

Existing named formulas/theorems/parameter/citation targets are unchanged. No implementation, input-value, proof-domain or physical-selection upgrade follows. Source chains referring to these targets now have better documentary descriptions, while historicalR1 notes describing the former residues remain tied to their original assessment run. A scoped progress record explains that chronology without silently changing those151assessments or their WARN/INFO/UNGROUNDED findings. `scoped_backing_chain_impacts` lists every relevant sentence anchor considered for this documentary update.

The independently reviewed R2 semantic preservation checks report unchanged normalized executable ASTs/formulas/values, imports and165GW assertions, with only the authorized four hypothesis narratives, eight citation notes/provides, documentary test rename and L1 anchor updated. This author checks exact carrying hashes and attributes those independent AST checks; this was not another implementation review or execution of the scientific suite.

Archived stdout reports124focusedPASS in12.82s; carrying readback records terminal0. Existing tracked-hypothesis ledger/freshness stdout reports2/2PASS. These are actual retained ROOT executions, not tests/gates performed by this reviewer and not fullG11 acceptance. The carrying readback says application review pending, which the proposal explicitly retains. A separately running application reviewer may later supply current acceptance through ROOT's normal intake; elapsed time is not acceptance.

## Validation and ROOT integration

The existing strict `python3 scripts/sentence_state.py validate /tmp/l1-main-canonical-propagation-refresh-r2/claims_review.json` returns0 with151sentences. Actual output is retained in `schema-validation.json`. `build.py` proves exact semantic restoration, carrying proposal hashes and archiveCRC; `preservation.json` and `readback.json` preserve those results and current source/audit/state hashes. The report uses the existing emitted-artifact contract; no new canonical catalog, routing ledger, sidecar state machinery or validator is introduced.

After independent intake ROOT can install the accepted JSON using existing `scripts.bundle_json.write_bundle_json`, then use existing `sentence_state.py validate`, `ingest_agent_run --dry-run` and actual `ingest_agent_run` under ROOT authority. No ingestion, dry-run ingestion, audit/prose state/ledger write, tests/build/graph/DB/Lean/native/controller/resource operation or repository mutation occurred here.

Only `/tmp/l1-main-canonical-propagation-refresh-r2/` was written: `build.py`, proposed `claims_review.json`, `preservation.json`, `readback.json`, `schema-validation.json`, this report and final continuity/readback receipts. ROOT is sole repository/notebook writer; other reviewers' work is preserved.

## CONTRADICTIONS BETWEEN THE BRIEF AND THE SOURCES

None. The key chronology qualification is deliberate:151assessment objects retainR1 observations even though source documentation now differs. Current evidence records the bounded documentary progress and exact new hashes; it does not relabel old review dates/hashes as current or claim a fresh whole-paper pass. All four original blockers remainOPEN, including physical normalization/window/state/tensor/matter/light and controlled transport/frequency/units/error construction.
